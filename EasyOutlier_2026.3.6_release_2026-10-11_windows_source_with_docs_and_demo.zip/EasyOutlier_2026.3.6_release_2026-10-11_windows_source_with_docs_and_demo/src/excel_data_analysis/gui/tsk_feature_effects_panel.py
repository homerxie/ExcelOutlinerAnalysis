"""Bind the saved feature inference report; fitting never runs in this widget."""
from __future__ import annotations

import math
import json

from PySide6.QtCore import QModelIndex, QSignalBlocker, Qt
from PySide6.QtWidgets import QDialog, QHeaderView, QWidget

from .tsk_feature_panel import _FeatureTableModel
from .ratio_filter_header import ColumnFilterHeader
from .table_filter import TableFilterController
from .table_filter_model import ColumnFilterProxyModel
from .ui_tsk_feature_effects_panel import Ui_TskFeatureEffectsPanelForm
from .ui_tsk_fixed_zero_assumption_dialog import Ui_TskFixedZeroAssumptionDialogForm


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _number(value):
    return f"{value:.6g}" if _finite(value) else ""


class _FeatureEffectsTableModel(_FeatureTableModel):
    """Expose form-defined header help without changing the shared table model."""

    def __init__(self, headers, parent=None):
        super().__init__(headers, parent)
        self.header_tooltips = {}

    def set_header_tooltips(self, values):
        self.header_tooltips = dict(values)
        self.headerDataChanged.emit(Qt.Horizontal, 0, self.columnCount() - 1)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.ToolTipRole:
            return self.header_tooltips.get(section)
        return super().headerData(section, orientation, role)


class TskFeatureEffectsPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskFeatureEffectsPanelForm()
        self.ui.setupUi(self)
        self.report = {}
        self.features = []
        self.choices = []
        self._binding = False
        self._filter_group = None
        self._filtered_feature = None
        self._table_filters = []
        self._assumption_dialog = None
        self.overview_model, self.overview_proxy = self._attach_table(self.ui.overviewTableView)
        self.levels_model, self.levels_proxy = self._attach_table(self.ui.levelsTableView)
        self.pairwise_model, self.pairwise_proxy = self._attach_table(self.ui.pairwiseTableView)
        self._plot_axis_labels = {plot: plot.property("axisLabel") for plot in
                                  (self.ui.levelsPlot, self.ui.pairwisePlot)}
        self._levels_tab_text = self.ui.effectsTabWidget.tabText(
            self.ui.effectsTabWidget.indexOf(self.ui.levelsTab))
        self._explanation_text = self.ui.explanationLabel.text()
        self._assumption_tooltip = self.ui.assumptionDetailsButton.toolTip()
        self.ui.featureComboBox.currentIndexChanged.connect(self._feature_changed)
        self.ui.overviewTableView.selectionModel().currentRowChanged.connect(self._overview_selected)
        self.overview_proxy.rowsRemoved.connect(self._overview_filter_changed)
        self.overview_proxy.rowsInserted.connect(self._overview_filter_changed)
        self.overview_proxy.modelReset.connect(self._overview_filter_changed)
        self.ui.levelOrderComboBox.currentIndexChanged.connect(self._feature_changed)
        self.ui.assumptionDetailsButton.clicked.connect(self._show_assumption_details)

    def _attach_table(self, table):
        model = _FeatureEffectsTableModel(table.property("columnHeaders"), self)
        proxy = ColumnFilterProxyModel(table)
        proxy.setSourceModel(model)
        proxy.setSortRole(Qt.UserRole)
        self._table_filters.append(TableFilterController(table, table.findChild(ColumnFilterHeader)))
        table.setModel(proxy)
        table.sortByColumn(-1, Qt.AscendingOrder)
        table.horizontalHeader().setResizeContentsPrecision(100)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        return model, proxy

    @staticmethod
    def _cell(value, *, numeric=False, pp=False, tooltip=""):
        raw = value * 100 if pp and _finite(value) else value
        display = _number(raw) if numeric or pp else str(value if value is not None else "")
        return display, raw, tooltip

    def _interval(self, row, prefix="", *, tooltip=""):
        lower, upper = row.get(prefix + "ci_lower"), row.get(prefix + "ci_upper")
        if not (_finite(lower) and _finite(upper)):
            return self._cell(None, tooltip=tooltip)
        return self._cell(self.property("intervalFormat").format(lower=_number(lower), upper=_number(upper)), tooltip=tooltip)

    def _or_tooltips(self, feature, row=None, *, pair=False):
        if feature.get("kind") == "spatial":
            explanation = str(self.property("spatialExplanation"))
            return explanation, explanation
        if pair:
            direction = (self.property("pairOrTooltipFormat").format(
                a=row.get("level_a", ""), b=row.get("level_b", "")) if row is not None
                else self.property("pairOrHeaderText"))
        elif feature.get("kind") == "numeric":
            level = row if row is not None else next(iter(feature.get("levels") or []), {})
            direction = self.property("numericOrTooltipFormat").format(
                feature=feature.get("feature", ""), scale=_number(level.get("scale", feature.get("scale"))))
        else:
            values = {"reference": feature.get("reference_level", "")}
            if row is not None:
                values["level"] = row.get("level", "")
            direction = self.property("levelOrTooltipFormat" if row is not None else "levelOrHeaderFormat").format(**values)
        tooltip = "\n".join((str(direction), str(self.property("oddsExplanation"))))
        if feature.get("role") == "tsk_type":
            tooltip += "\n" + str(self.property("jointTypeOrExplanation" if self._joint() else "typeOrExplanation"))
        if self._conditional():
            tooltip += "\n" + str(self.property("conditionalOrScope"))
        if self._joint():
            return tooltip, tooltip + "\n" + str(self.property("jointCalibrationText"))
        if self._simulation():
            return tooltip, tooltip + "\n" + str(self.property("simulationScopeText"))
        return tooltip, "\n".join((tooltip, str(self.property("orIntervalExplanation"))))

    def _conditional(self):
        return self.report.get("inference_mode") == "fixed_zero_conditional"

    def _simulation(self):
        return self.report.get("inference_mode") == "free_boundary_simulation"

    def _joint(self):
        return (self.report.get("methods") or {}).get("contrast_identifiability") == "joint_logistic_full_nuisance_profile_verified_contrast"

    def _show_assumption_details(self):
        if not (self._conditional() or self._simulation()):
            return
        if self._assumption_dialog is None:
            self._assumption_dialog = QDialog(self)
            self._assumption_dialog_ui = Ui_TskFixedZeroAssumptionDialogForm()
            self._assumption_dialog_ui.setupUi(self._assumption_dialog)
            self._assumption_dialog_title = self._assumption_dialog.windowTitle()
            self._assumption_dialog_ui.simulationDiagnosticsCheckBox.toggled.connect(
                self._assumption_dialog_ui.simulationDiagnosticsTextEdit.setVisible)
        details = self._assumption_dialog_ui.detailsTextEdit
        self._assumption_dialog_ui.simulationDiagnosticsCheckBox.setVisible(self._simulation())
        self._assumption_dialog_ui.simulationDiagnosticsCheckBox.setChecked(False)
        self._assumption_dialog_ui.simulationDiagnosticsTextEdit.hide()
        if self._simulation():
            self._assumption_dialog.setWindowTitle(self._assumption_dialog.property("simulationTitle"))
            summaries = []
            for feature in self.features:
                lrt = feature.get("lrt") or {}
                sim = lrt.get("simulation") or {}
                summaries.append(details.property("simulationFeatureFormat").format(
                    feature=feature.get("feature", ""), decision=self._decision(lrt),
                    p_value=_number(lrt.get("p_value")), p_adjusted=_number(lrt.get("p_adjusted")),
                    completed=sim.get("replicates_completed", 0), requested=sim.get("replicates_requested", 0),
                    failed=sim.get("replicates_failed", 0), exceedances=_number(sim.get("exceedances")),
                    mc_interval=self._interval({"ci_lower": sim.get("p_value_mc_lower"),
                                                "ci_upper": sim.get("p_value_mc_upper")})[0],
                    mc_se=_number(sim.get("p_value_mc_se")),
                    full_zero="、".join(map(str, sim.get("observed_full_zero_tsk_ids") or [])),
                    reduced_zero="、".join(map(str, sim.get("observed_reduced_zero_tsk_ids") or [])),
                    full_changes=sim.get("full_zero_mask_changed_count", 0),
                    reduced_changes=sim.get("reduced_zero_mask_changed_count", 0), reason=lrt.get("reason") or ""))
            settings = self.report.get("simulation_settings") or {}
            details.setPlainText(details.property("simulationFormat").format(
                warning=self.report.get("experimental_warning") or self.property("simulationScopeText"),
                replicates=settings.get("replicates", ""), seed=settings.get("seed", ""),
                scope=self.property("simulationScopeText"), summary="\n\n".join(summaries)))
            self._assumption_dialog_ui.simulationDiagnosticsTextEdit.setPlainText(json.dumps({
                "simulation_settings": settings,
                "features": [{"feature": row.get("feature"), "lrt": row.get("lrt")} for row in self.features]},
                ensure_ascii=False, indent=2))
        else:
            self._assumption_dialog.setWindowTitle(self._assumption_dialog_title)
            details.setPlainText(details.property("displayFormat").format(
            tsk_ids="、".join(map(str, self.report.get("fixed_zero_tsk_ids") or [])),
            warning=self.report.get("assumption_warning") or details.property("defaultWarning"),
            scope=self.property("conditionalOrScope")))
        self._assumption_dialog.open()

    def _bind_inference_scope(self):
        conditional = self._conditional()
        simulation = self._simulation()
        joint = self._joint()
        self.ui.explanationLabel.setText(self.ui.explanationLabel.property("jointText") if joint else
                                         self.property("simulationExplanation") if simulation else self.ui.explanationLabel.property("conditionalText")
                                         if conditional else self._explanation_text)
        label = self.ui.assumptionLabel
        self.ui.assumptionWidget.setVisible(conditional or simulation)
        self.ui.assumptionDetailsButton.setToolTip(self.property("simulationDetailsTooltip") if simulation else self._assumption_tooltip)
        if self._assumption_dialog is not None:
            self._assumption_dialog.reject()
        if conditional:
            label.setText(label.property("displayFormat").format(count=len(self.report.get("fixed_zero_tsk_ids") or [])))
        elif simulation:
            label.setText(self.property("simulationBannerText"))
        for table, model in ((self.ui.overviewTableView, self.overview_model),
                             (self.ui.levelsTableView, self.levels_model),
                             (self.ui.pairwiseTableView, self.pairwise_model)):
            model.headers = list(table.property("jointColumnHeaders" if joint else
                                               "simulationColumnHeaders" if simulation and table == self.ui.overviewTableView
                                               else "conditionalColumnHeaders" if conditional else "columnHeaders"))
            model.headerDataChanged.emit(Qt.Horizontal, 0, model.columnCount() - 1)
        for plot, default_label in self._plot_axis_labels.items():
            plot.setProperty("axisLabel", plot.property("jointAxisLabel") if joint else
                             plot.property("conditionalAxisLabel") if conditional else default_label)
            plot.update()

    def _decision(self, row):
        if row.get("status") == "simulation_experimental" and _finite(row.get("p_adjusted")):
            flag = row.get("experimental_significant")
            return str(self.property("significantText" if flag is True else
                                     "notSignificantText" if flag is False else "unavailableText"))
        # Only the inference engine's adjusted decision may establish significance.
        if row.get("status") == "boundary_uncalibrated":
            return str(self.property("uncalibratedText"))
        valid = row.get("status") == "ok" and _finite(row.get("p_adjusted"))
        significant = row.get("significant") if valid else None
        key = "significantText" if significant is True else "notSignificantText" if significant is False else "unavailableText"
        return str(self.property(key))

    def _kind(self, row):
        return str(self.property({"categorical": "categoricalText", "spatial": "spatialText"}.get(
            row.get("kind"), "numericText")))

    def _overview_tooltips(self):
        alpha = self.report.get("alpha")
        if not (_finite(alpha) and 0 < alpha < 1):
            confidence = self.report.get("confidence_level", .95)
            alpha = 1 - confidence if _finite(confidence) and 0 < confidence < 1 else .05
        tooltips = {column: text.format(threshold=_number(alpha)) for column, text in
                    enumerate(self.ui.overviewTableView.property("columnTooltips")) if text}
        if self._simulation():
            tooltips.update({column: str(self.property("simulationScopeText")) for column in (3, 5, 6, 12, 13, 14)})
            tooltips[2] = self.property("simulationDecisionExplanation").format(threshold=_number(alpha))
        if self._joint():
            tooltips.update({column: str(self.property("jointCalibrationText")) for column in (2, 4, 5, 6)})
        return tooltips

    def _pair_decision(self, row):
        if row.get("status") == "fixed_zero_assumption":
            return str(self.property("fixedZeroAssumptionText"))
        if self._boundary_text(row, pair=True):
            return str(self.property({"both_lower": "boundaryBothLowerStatusText",
                                      "both_upper": "boundaryBothUpperStatusText"}.get(
                                          row.get("boundary_state"), "boundaryPairStatusText")))
        if row.get("status") == "point_estimate_only" and _finite(row.get("difference")):
            return str(self.property("pairPointEstimateOnlyText"))
        valid = row.get("status") == "ok" and _finite(row.get("p_adjusted"))
        if valid and row.get("significant") is False:
            return str(self.property("pairNotSignificantText"))
        difference = row.get("difference")
        if valid and row.get("significant") is True and _finite(difference) and difference != 0:
            key = "pairHigherFormat" if difference > 0 else "pairLowerFormat"
            return self.property(key).format(a=row.get("level_a", ""), b=row.get("level_b", ""))
        return str(self.property("unavailableText"))

    def _boundary_text(self, row, *, pair=False):
        state = row.get("boundary_state")
        basis = row.get("direction_basis")
        if basis not in {"fitted_boundary", "fixed_zero_assumption", "type_only_boundary"}:
            return ""
        if not pair:
            probability = row.get("boundary_probability")
            if state == "lower" and probability == 0:
                return str(self.property("boundaryFixedLowerText" if basis == "fixed_zero_assumption"
                                         else "boundaryLowerText"))
            if state == "upper" and probability == 1:
                return str(self.property("boundaryUpperText"))
            return ""
        if state in {"both_lower", "both_upper"}:
            return str(self.property("boundaryBothLowerText" if state == "both_lower" else "boundaryBothUpperText"))
        expected = {"a_lower": "b_higher", "b_lower": "b_lower", "a_upper": "b_lower",
                    "b_upper": "b_higher", "lower_upper": "b_higher", "upper_lower": "b_lower"}
        if state not in expected or row.get("direction") != expected[state]:
            return ""
        return str(self.property({"a_lower": "boundaryALowerText", "b_lower": "boundaryBLowerText",
            "a_upper": "boundaryAUpperText", "b_upper": "boundaryBUpperText",
            "lower_upper": "boundaryLowerUpperText", "upper_lower": "boundaryUpperLowerText"}[state]))

    def _boundary_tooltip(self, row):
        names = (self.property("boundaryPairNamesFormat").format(a=row.get("level_a", ""), b=row.get("level_b", ""))
                 if "level_a" in row else "")
        return "\n".join(filter(None, (names, str(self.property("boundaryExplanation")), row.get("boundary_note"))))

    @staticmethod
    def _resize(table):
        table.resizeColumnsToContents()
        lower, upper = int(table.property("textColumnMinimumWidth")), int(table.property("textColumnMaximumWidth"))
        for column in range(table.model().columnCount()):
            table.setColumnWidth(column, min(upper, max(lower, table.columnWidth(column))))

    def set_group(self, group):
        self._binding = True
        if group is not self._filter_group:
            for proxy in (self.overview_proxy, self.levels_proxy, self.pairwise_proxy):
                proxy.clear_column_filters()
        self._filter_group = group
        previous = self.ui.featureComboBox.currentData()
        self.report = (group or {}).get("feature_effects") or {}
        self.features = list(self.report.get("features") or [])
        type_effects = self.report.get("type_effects")
        self.choices = self.features + ([type_effects] if isinstance(type_effects, dict) and type_effects else [])
        self._bind_inference_scope()
        combo = self.ui.featureComboBox
        with QSignalBlocker(combo):
            combo.clear()
            for row in self.choices:
                is_type = row.get("role") == "tsk_type"
                name = str(row.get("label") or row.get("feature", ""))
                label = (self.property("tskTypeText") if is_type else
                         self.property("featureChoiceFormat").format(feature=name)
                         if type_effects and name == self.property("tskTypeText") else name)
                combo.addItem(str(label), {"role": "tsk_type"} if is_type else row.get("feature"))
            chosen = combo.findData(previous)
            combo.setCurrentIndex(chosen if chosen >= 0 else 0 if self.choices else -1)
        combo.setEnabled(bool(self.choices))
        self.ui.effectsTabWidget.setTabEnabled(self.ui.effectsTabWidget.indexOf(self.ui.overviewTab), bool(self.features))
        if not self.features and self.choices and self.ui.effectsTabWidget.currentWidget() == self.ui.overviewTab:
            self.ui.effectsTabWidget.setCurrentWidget(self.ui.levelsTab)
        overview_tooltips = self._overview_tooltips()
        self.overview_model.set_header_tooltips(overview_tooltips)
        overview = []
        for row in self.features:
            lrt, impact = row.get("lrt") or {}, row.get("deletion_impact") or {}
            simulation = lrt.get("simulation") or {}
            reason = "\n".join(dict.fromkeys(str(value) for value in
                (row.get("reason"), lrt.get("reason"), impact.get("reason")) if value))
            available_impact = impact.get("status") == "ok"
            lrt_reason = ("\n".join(dict.fromkeys(str(value) for value in
                (row.get("reason"), lrt.get("reason")) if value))
                if lrt.get("status") != "ok" else "")
            impact_reason = str(impact.get("reason") or "") if not available_impact else ""
            cells = [
                self._cell(row.get("label") or row.get("feature"), tooltip=reason), self._cell(self._kind(row)),
                self._cell(self._decision(lrt), tooltip=lrt_reason),
                *[self._cell(lrt.get(field), numeric=True, tooltip=lrt_reason) for field in
                  ("statistic", "df", "p_value", "p_adjusted")],
                *[self._cell(impact.get(field) if available_impact else None, pp=True, tooltip=impact_reason) for field in
                  ("mean_abs_probability_change", "max_abs_probability_change", "rms_probability_change")],
                self._cell(impact.get("instance_count"), numeric=True, tooltip=impact_reason),
                self._cell(reason, tooltip=reason),
            ]
            if self._simulation():
                mc = {"ci_lower": simulation.get("p_value_mc_lower"), "ci_upper": simulation.get("p_value_mc_upper")}
                cells.extend([self._cell(self.property("simulationMcCountFormat").format(
                    completed=simulation.get("replicates_completed", 0), requested=simulation.get("replicates_requested", 0),
                    failed=simulation.get("replicates_failed", 0))),
                    self._cell(simulation.get("p_value_mc_se"), numeric=True), self._interval(mc)])
            overview.append([(display, raw, "\n".join(dict.fromkeys(value for value in
                (overview_tooltips.get(column), tooltip) if value)))
                for column, (display, raw, tooltip) in enumerate(cells)])
        self.overview_model.set_rows(overview)
        self.ui.overviewTableView.setColumnHidden(4, self._simulation())
        header = self.ui.overviewTableView.horizontalHeader()
        column_order = ([*range(7), 12, 13, 14, *range(7, 12)] if self._simulation()
                        else list(range(self.overview_model.columnCount())))
        for position, column in enumerate(column_order):
            header.moveSection(header.visualIndex(column), position)
        self._resize(self.ui.overviewTableView)
        if not group:
            status = self.ui.statusLabel.property("emptyText")
        elif not self.report:
            status = self.ui.statusLabel.property("missingReportText")
        elif not self.features:
            status = (self.ui.statusLabel.property("typesOnlyText") if self.choices else
                      self.report.get("reason") or self.ui.statusLabel.property("emptyText"))
        else:
            status = self.ui.statusLabel.property("summaryFormat").format(
                count=len(self.features),
                estimated=sum(any(not level.get("reference") and _finite(level.get("coefficient"))
                                  for level in row.get("levels") or []) or
                              any(_finite(pair.get("difference")) for pair in row.get("pairwise") or []) or
                              (row.get("kind") == "spatial" and (row.get("deletion_impact") or {}).get("status") == "ok")
                              for row in self.features),
                deletion=sum((row.get("deletion_impact") or {}).get("status") == "ok" for row in self.features),
                significant=sum(self._decision(row.get("lrt") or {}) == self.property("significantText")
                                for row in self.features),
                uncalibrated=sum((row.get("lrt") or {}).get("status") == "boundary_uncalibrated" for row in self.features),
                unavailable=sum(self._decision(row.get("lrt") or {}) == self.property("unavailableText") for row in self.features))
        if self._simulation():
            status += self.property("simulationSummaryFormat").format(
                completed=sum((row.get("lrt") or {}).get("status") == "simulation_experimental" for row in self.features))
        if type_effects:
            status += self.ui.statusLabel.property("typeSummaryFormat").format(count=len(type_effects.get("levels") or []))
        spatial_count = sum(row.get("kind") == "spatial" for row in self.features)
        if spatial_count:
            status += self.ui.statusLabel.property("spatialSummaryFormat").format(count=spatial_count)
        if any(_finite(row.get("ci_lower")) and _finite(row.get("ci_upper"))
               for feature in self.choices for row in [*(feature.get("levels") or []), *(feature.get("pairwise") or [])]):
            confidence = self.report.get("confidence_level", .95)
            status += self.ui.statusLabel.property(
                "conditionalIntervalSummaryFormat" if self._conditional() else "intervalSummaryFormat").format(
                confidence=f"{confidence:.0%}" if _finite(confidence) else "")
        self.ui.statusLabel.setText(str(status))
        notes = [self.property("simulationScopeText") if self._simulation() else self.ui.notesTextEdit.property("baseNotes")]
        if self._conditional():
            notes.append(self.ui.assumptionLabel.text())
        if self.report.get("reason"):
            notes.append(str(self.report["reason"]))
        if self.report.get("model_scope"):
            notes.append(str(self.report["model_scope"]))
        if spatial_count:
            notes.append(str(self.property("spatialExplanation")))
        notes.extend(str(value) for value in self.report.get("warnings", []) if value)
        self.ui.notesTextEdit.setPlainText("\n\n".join(notes))
        self._binding = False
        self._feature_changed()
        self._overview_filter_changed()

    def _overview_filter_changed(self, *_args):
        if self._binding:
            return
        table = self.ui.overviewTableView
        selected_index = self.ui.featureComboBox.currentIndex()
        if selected_index >= len(self.features):
            return
        if not self.overview_proxy.rowCount():
            if self.overview_proxy.has_column_filters():
                self.ui.featureComboBox.setCurrentIndex(-1)
        elif not table.currentIndex().isValid():
            table.setCurrentIndex(self.overview_proxy.index(0, 0))

    def _overview_selected(self, current, _previous):
        if self._binding or not current.isValid():
            return
        source = self.overview_proxy.mapToSource(current)
        self.ui.featureComboBox.setCurrentIndex(source.row())

    def _feature_changed(self, *_args):
        if self._binding:
            return
        index = self.ui.featureComboBox.currentIndex()
        selected = self.choices[index] if 0 <= index < len(self.choices) else {}
        if selected is not self._filtered_feature:
            self.levels_proxy.clear_column_filters()
            self.pairwise_proxy.clear_column_filters()
        self._filtered_feature = selected
        is_type = selected.get("role") == "tsk_type"
        is_spatial = selected.get("kind") == "spatial"
        self.ui.effectsTabWidget.setTabText(self.ui.effectsTabWidget.indexOf(self.ui.levelsTab),
            str(self.property("spatialLevelsTabText")) if is_spatial else self._levels_tab_text)
        for widget in (self.ui.levelsSplitter, self.ui.orderLabel, self.ui.levelOrderComboBox,
                       self.ui.pairwiseSplitter):
            widget.setVisible(not is_spatial)
        self._binding = True
        if selected and not is_type:
            self.ui.overviewTableView.setCurrentIndex(self.overview_proxy.mapFromSource(self.overview_model.index(index, 0)))
        elif is_type:
            self.ui.overviewTableView.clearSelection()
            self.ui.overviewTableView.setCurrentIndex(QModelIndex())
        self._binding = False
        lrt = selected.get("lrt") or {}
        if is_type:
            detail = self.property("typeDetailFormat").format(reference=selected.get("reference_level") or "—",
                                                            reason=selected.get("reason") or "")
        elif selected:
            detail = self.property("featureDetailFormat").format(feature=selected.get("label") or selected.get("feature"), kind=self._kind(selected),
                decision=self._decision(lrt), reason=lrt.get("reason") or selected.get("reason") or "")
            if selected.get("kind") == "categorical":
                detail += "\n" + self.property("referenceFormat").format(reference=selected.get("reference_level", ""))
            elif is_spatial:
                detail += "\n" + str(self.property("spatialExplanation"))
            else:
                level = next(iter(selected.get("levels") or []), {})
                detail += "\n" + self.property("numericScaleFormat").format(
                    mean=_number(level.get("mean", selected.get("mean"))), scale=_number(level.get("scale", selected.get("scale"))))
        else:
            detail = self.ui.featureDetailLabel.property("emptyText")
        if self._joint() and selected.get("pairwise"):
            available = sum(_finite(row.get("difference")) for row in selected["pairwise"])
            detail += "\n" + self.property("jointContrastAvailabilityFormat").format(
                available=available, total=len(selected["pairwise"]))
        self.ui.featureDetailLabel.setText(str(detail))
        level_or_help, level_interval_help = self._or_tooltips(selected)
        pair_or_help, pair_interval_help = self._or_tooltips(selected, pair=True)
        self.levels_model.set_header_tooltips({4: level_or_help, 5: level_interval_help,
                                              8: self.property("boundaryExplanation")})
        self.pairwise_model.set_header_tooltips({3: pair_or_help, 4: pair_interval_help,
                                                9: self.property("boundaryExplanation")})
        for table, column in ((self.ui.levelsTableView, 8), (self.ui.pairwiseTableView, 9)):
            table.setColumnHidden(column, not is_type)
            header = table.horizontalHeader()
            header.moveSection(header.visualIndex(column), 1 if is_type else column)
        levels = [] if is_spatial else list(selected.get("levels") or [])
        order = self.ui.levelOrderComboBox.currentIndex()
        if order:
            available = [row for row in levels if _finite(row.get("coefficient"))]
            unavailable = [row for row in levels if not _finite(row.get("coefficient"))]
            levels = sorted(available, key=lambda row: row["coefficient"], reverse=order == 1) + unavailable
        level_rows, plot_rows = [], []
        for row in levels:
            boundary = self._boundary_text(row) if is_type else ""
            status = (self.property("fixedZeroAssumptionText") if row.get("status") == "fixed_zero_assumption" else
                      self.property("boundaryEstimateStatusText") if boundary else
                      self.property("referenceText") if row.get("status") == "reference_coding" else
                      self.property("conditionalEstimatedText" if self._conditional() else "estimatedText")
                      if row.get("status") == "ok" else
                      self.property("pointEstimateOnlyText") if row.get("status") == "point_estimate_only"
                      and _finite(row.get("coefficient")) else self.property("unavailableText"))
            reason = str(row.get("reason") or "")
            tooltip = "\n".join((str(row.get("level", "")), str(status), reason))
            or_tooltip, or_interval_tooltip = self._or_tooltips(selected, row)
            level_rows.append([self._cell(row.get("level"), tooltip=tooltip), self._cell(row.get("coefficient"), numeric=True),
                self._cell(row.get("se"), numeric=True), self._interval(row),
                self._cell(row.get("odds_ratio"), numeric=True, tooltip=or_tooltip),
                self._interval(row, "or_", tooltip=or_interval_tooltip), self._cell(status, tooltip=reason), self._cell(reason, tooltip=reason),
                self._cell(boundary, tooltip=self._boundary_tooltip(row))])
            plot_rows.append({"label": row.get("level"), "estimate": row.get("coefficient"),
                "ci_lower": row.get("ci_lower"), "ci_upper": row.get("ci_upper"),
                "reference": row.get("reference"), "tooltip": tooltip,
                "unavailable_label": boundary})
        self.levels_model.set_rows(level_rows)
        self.ui.levelsPlot.set_rows(plot_rows)
        self._resize(self.ui.levelsTableView)
        pair_rows, pair_plot = [], []
        for row in ([] if is_spatial else selected.get("pairwise") or []):
            label = self.property("pairFormat").format(a=row.get("level_a", ""), b=row.get("level_b", ""))
            reason = str(row.get("reason") or "")
            tooltip = "\n".join((label, self._pair_decision(row), reason))
            or_tooltip, or_interval_tooltip = self._or_tooltips(selected, row, pair=True)
            pair_rows.append([self._cell(label, tooltip=tooltip), self._cell(row.get("difference"), numeric=True),
                self._interval(row), self._cell(row.get("odds_ratio"), numeric=True, tooltip=or_tooltip),
                self._interval(row, "or_", tooltip=or_interval_tooltip),
                self._cell(row.get("p_value"), numeric=True), self._cell(row.get("p_adjusted"), numeric=True),
                self._cell(self._pair_decision(row), tooltip=tooltip), self._cell(reason, tooltip=reason),
                self._cell(self._boundary_text(row, pair=True) if is_type else "", tooltip=self._boundary_tooltip(row))])
            pair_plot.append({"label": label, "estimate": row.get("difference"),
                "ci_lower": row.get("ci_lower"), "ci_upper": row.get("ci_upper"), "tooltip": tooltip,
                "unavailable_label": self._boundary_text(row, pair=True) if is_type else ""})
        self.pairwise_model.set_rows(pair_rows)
        self.ui.pairwisePlot.set_rows(pair_plot)
        self._resize(self.ui.pairwiseTableView)
        pair_hint = (self.property("spatialPairwiseText") if is_spatial else
                     self.ui.pairwiseHintLabel.property(
            "typeText" if is_type else "numericText" if selected.get("kind") == "numeric" else "defaultText"))
        if self._joint() and selected.get("pairwise"):
            pair_hint = str(self.ui.pairwiseHintLabel.property("jointText")) + "\n" + self.property("jointContrastAvailabilityFormat").format(
                available=sum(_finite(row.get("difference")) for row in selected["pairwise"]), total=len(selected["pairwise"]))
        if is_type and not pair_rows and selected.get("reason"):
            pair_hint += "\n" + str(selected["reason"])
        self.ui.pairwiseHintLabel.setText(pair_hint)
