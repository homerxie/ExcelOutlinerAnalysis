"""Bounded process parallelism for independent TSK fits.

Only the parent reports progress. Layouts are sent once per worker, native
numeric libraries use one thread, and nested analyses share the outer budget.
"""
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from concurrent.futures.process import BrokenProcessPool
from dataclasses import dataclass
import logging
import multiprocessing
from numbers import Integral
import os
from queue import Empty, Full
import threading
import sys
import shlex
from time import monotonic

from .compute_resources import limit_process_workers


_SPAWN_ENV_LOCK = threading.Lock()
_THREAD_ENV = ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS",
               "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS")
_IN_WORKER = False
_COMMON = None
_FUNCTION = None
_THREAD_LIMIT = None
_STARTUP_GATE = None
_PROGRESS_QUEUE = None


def require_parallel_runtime():
    """Report missing native-thread controls before starting failing children."""
    try:
        from threadpoolctl import threadpool_limits
    except ImportError as error:
        if getattr(sys, "frozen", False):
            remedy = "请重新安装包含完整依赖的程序包。"
        else:
            command = ([sys.executable, "-m", "pip", "install", "threadpoolctl>=3.1,<4"])
            formatted = (f'& "{sys.executable}" -m pip install "threadpoolctl>=3.1,<4"'
                         if os.name == "nt" else shlex.join(command))
            remedy = f"请在启动本程序的 Python 环境执行：\n{formatted}"
        raise RuntimeError(f"多进程计算依赖 threadpoolctl 无法加载：{error}\n{remedy}\n安装后请重新启动程序。") from error
    return threadpool_limits


@dataclass(frozen=True)
class _WorkerResult:
    value: object
    pid: int
    detail: object = None


class _Heartbeat:
    """Optional, small progress messages; statistical work never waits on IPC."""

    def __init__(self, report=None, poll=None):
        self.report, self.poll = report, poll
        self.started = monotonic()
        self.last_sent = None
        self.latest = None
        self.sequence = 0

    def __call__(self, detail=None):
        if self.poll is not None:
            self.poll()
        if self.report is None:
            return
        if isinstance(detail, dict):
            # Keep the pipe payload small even if a caller supplies a full context.
            self.latest = {"message": str(detail.get("message", ""))[:768]}
            value = detail.get("progress")
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                self.latest["progress"] = max(0., min(100., float(value)))
        if self.latest is None:
            return
        now = monotonic()
        if self.last_sent is None or now - self.last_sent >= 1.:
            self.last_sent = now
            self.report(self.event(now=now))

    # Jobs can detect this method while still accepting older zero-argument
    # heartbeat functions supplied by external callers or test adapters.
    detail = __call__

    def event(self, *, now=None, completed=False):
        if self.latest is None:
            return None
        self.sequence += 1
        return {**self.latest, "elapsed_seconds": max(0., (monotonic() if now is None else now) - self.started),
                "pid": os.getpid(), "sequence": self.sequence,
                "phase": "completed" if completed else "running"}


def in_parallel_worker():
    return _IN_WORKER


def validate_analysis_workers(workers):
    if isinstance(workers, bool) or not isinstance(workers, Integral) or not 0 <= workers <= 64:
        raise ValueError("analysis_workers must be an integer between 0 and 64 (0 means automatic).")
    return int(workers)


def worker_count(workers, task_count, min_parallel_items=2):
    workers = validate_analysis_workers(workers)
    if _IN_WORKER or task_count < 2:
        return 1
    if workers == 0:
        if task_count < min_parallel_items:
            return 1
        workers = min(8, max((os.cpu_count() or 1) - 1, 1))
    return limit_process_workers(min(workers, task_count, 61 if os.name == "nt" else 64))


def _initialize(function, common, prepare_common, gate, log_queue=None, progress_queue=None):
    from .process_logging import install_process_logging

    install_process_logging(log_queue)
    threadpool_limits = require_parallel_runtime()

    global _IN_WORKER, _COMMON, _FUNCTION, _THREAD_LIMIT, _STARTUP_GATE, _PROGRESS_QUEUE
    _IN_WORKER = True
    _FUNCTION, _STARTUP_GATE = function, gate
    _PROGRESS_QUEUE = progress_queue
    if progress_queue is not None:
        # Progress is best effort. A full pipe must not hold worker shutdown;
        # the final detail also travels with the task's authoritative result.
        progress_queue.cancel_join_thread()
    _THREAD_LIMIT = threadpool_limits(limits=1)
    parent = multiprocessing.parent_process()
    if parent is not None:
        def parent_died():
            from multiprocessing.connection import wait
            wait([parent.sentinel])
            os._exit(0)
        threading.Thread(target=parent_died, name="tsk-parent-watch", daemon=True).start()
    _COMMON = prepare_common(common) if prepare_common is not None else common


def _ready():
    _STARTUP_GATE.wait()


def _run(item, index=None):
    def report(event):
        try:
            _PROGRESS_QUEUE.put_nowait((index, event))
        except (Full, OSError, ValueError):
            pass
    heartbeat = _Heartbeat(report if _PROGRESS_QUEUE is not None and index is not None else None)
    value = _FUNCTION(_COMMON, item, heartbeat)
    return _WorkerResult(value, os.getpid(), heartbeat.event(completed=True))


def _shutdown(pool, *, terminate=False):
    if pool is None:
        return
    if not terminate:
        pool.shutdown(wait=True, cancel_futures=True)
        return
    # Python 3.10 lacks the public terminate_workers API.
    processes = list((getattr(pool, "_processes", None) or {}).values())
    for process in processes:
        if process.is_alive():
            process.terminate()
    for process in processes:
        process.join(timeout=.2)
        if process.is_alive():
            process.kill()
            process.join(timeout=2.)
    # The manager can still be handling a worker's exit while join() above
    # races its own reaping. Wait for that thread as well before returning;
    # otherwise cancellation may leave an active child visible to the caller.
    pool.shutdown(wait=True, cancel_futures=True)


def ordered_parallel_map(function, items, *, common=None, prepare_common=None, workers=0,
                         progress_callback=None, min_parallel_items=2, execution=None,
                         detail_callback=None):
    """Map ``function(common, item, heartbeat)`` in input order.

    ``prepare_common`` builds worker-local reusable state once. The callback is
    called with (completed, total), including while waiting, and may cancel by
    raising. Infrastructure failures retry only unfinished items serially;
    computation exceptions propagate. Completion drives progress and refill;
    only the returned list is ordered. Callers must provide side-effect-free jobs.
    Jobs may call ``heartbeat.detail({"progress": percent, "message": text})``.
    Optional ``detail_callback(index, event)`` runs only in the parent, receives
    at most one live event per second per job plus its final detail, and may
    cancel by raising. Queue saturation drops only progress, never task results.
    """
    items = list(items)
    total = len(items)
    count = worker_count(workers, total, min_parallel_items)
    progress = progress_callback or (lambda *_: None)
    execution = execution if execution is not None else {}
    execution.update(workers_requested=int(workers), workers_used=count,
                     execution_backend="serial" if count == 1 else "spawn_process_pool",
                     execution_warnings=[], worker_pids=[], workers_observed=0,
                     phase="serial" if count == 1 else "starting", completed_tasks=0)
    missing = object()
    output = [missing] * total
    completed = 0
    worker_pids = set()
    local_common = None
    local_ready = False

    def serial_tail():
        nonlocal local_common, local_ready, completed
        execution["phase"] = "serial"
        if not local_ready:
            local_common = prepare_common(common) if prepare_common is not None else common
            local_ready = True
        for index, item in enumerate(items):
            if output[index] is not missing:
                continue
            heartbeat = _Heartbeat(
                (lambda event: detail_callback(index, event)) if detail_callback is not None else None,
                poll=lambda: progress(completed, total))
            heartbeat()
            output[index] = function(local_common, item, heartbeat)
            if detail_callback is not None and heartbeat.latest is not None:
                detail_callback(index, heartbeat.event(completed=True))
            completed += 1
            execution["completed_tasks"] = completed
            progress(completed, total)
        execution["phase"] = "completed"
        return output

    if count == 1 or not items:
        return serial_tail()
    require_parallel_runtime()
    from .process_logging import get_process_log_queue
    pool = None
    pending = {}
    detail_queue = None
    detail_sequences = {}

    def report_detail(index, event):
        if detail_callback is None or event is None:
            return
        sequence = event.get("sequence", 0)
        if sequence > detail_sequences.get(index, -1):
            detail_sequences[index] = sequence
            detail_callback(index, event)

    def drain_details():
        if detail_queue is None:
            return
        while True:
            try:
                index, event = detail_queue.get_nowait()
            except Empty:
                break
            except (EOFError, OSError, ValueError):
                # Progress transport is optional; authoritative task results
                # still determine success or the infrastructure fallback.
                close_details()
                break
            report_detail(index, event)

    def close_details():
        nonlocal detail_queue
        if detail_queue is not None:
            detail_queue.close()
            detail_queue.cancel_join_thread()
            detail_queue = None

    def collect_ready(futures):
        nonlocal completed
        broken = None
        for future in futures:
            index = pending.pop(future)
            if future.cancelled():
                continue  # Infrastructure shutdown cancelled this unstarted item.
            try:
                result = future.result()
            except BrokenProcessPool as error:
                broken = error
                continue
            if isinstance(result, _WorkerResult):
                worker_pids.add(result.pid)
                report_detail(index, result.detail)
                result = result.value
            output[index] = result
            completed += 1
        execution.update(completed_tasks=completed, worker_pids=sorted(worker_pids),
                         workers_observed=len(worker_pids), phase="running" if completed else "starting")
        return broken

    def fallback(error):
        nonlocal pool
        # A submission/startup failure can occur outside wait()'s last ready
        # snapshot. Preserve all already-returned work and propagate any real
        # computation failure, including fit-invalidating numerical errors.
        collect_ready([future for future in pending if future.done()])
        _shutdown(pool, terminate=True)
        pool = None
        collect_ready([future for future in pending if future.done()])
        close_details()
        execution.update(workers_used=1, execution_backend="serial_after_process_failure")
        warning = f"TSK 子进程不可用，保留已完成结果，其余串行继续：{type(error).__name__}: {error}"
        execution["execution_warnings"].append(warning)
        logging.getLogger(__name__).warning(warning)
        return serial_tail()

    try:
        progress(0, total)
        try:
            with _SPAWN_ENV_LOCK:
                previous = {key: os.environ.get(key) for key in _THREAD_ENV}
                try:
                    os.environ.update({key: "1" for key in _THREAD_ENV})
                    spawn = multiprocessing.get_context("spawn")
                    gate = spawn.Event()
                    if detail_callback is not None:
                        detail_queue = spawn.Queue(maxsize=max(16, 4 * count))
                    pool = ProcessPoolExecutor(max_workers=count, mp_context=spawn,
                        initializer=_initialize, initargs=(function, common, prepare_common, gate,
                                                          get_process_log_queue(), detail_queue))
                    for _ in range(count):
                        pool.submit(_ready)
                    gate.set()
                finally:
                    for key, value in previous.items():
                        if value is None:
                            os.environ.pop(key, None)
                        else:
                            os.environ[key] = value
        except (OSError, RuntimeError) as error:
            return fallback(error)
        next_submit = 0
        while completed < total:
            try:
                while next_submit < total and len(pending) < 2 * count:
                    pending[pool.submit(_run, items[next_submit], next_submit)] = next_submit
                    next_submit += 1
                progress(completed, total)
                ready, _ = wait(pending, timeout=.1, return_when=FIRST_COMPLETED)
                drain_details()
                broken = collect_ready(ready)
                if broken is not None:
                    return fallback(broken)
            except BrokenProcessPool as error:
                return fallback(error)
            progress(completed, total)
    except BaseException:
        _shutdown(pool, terminate=True)
        pool = None
        raise
    finally:
        try:
            _shutdown(pool)
        finally:
            close_details()
    execution["phase"] = "completed"
    return output
