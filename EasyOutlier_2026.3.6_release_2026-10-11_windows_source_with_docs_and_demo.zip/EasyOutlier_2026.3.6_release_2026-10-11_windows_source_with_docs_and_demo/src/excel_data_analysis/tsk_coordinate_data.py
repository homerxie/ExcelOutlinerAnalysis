"""Layout and observed chain rates for the coordinate view, without TSK fitting."""
from dataclasses import asdict


def coordinate_preview_from_template(template):
    config = getattr(template, "tsk_analysis", None)
    if config is None:
        return {}
    return {"topology": [asdict(row) for row in config.instances], "groups": [],
            "coordinate_view_mode": "layout",
            "provenance": {"template_snapshot": {"tsk_analysis": {"coordinate_unit": config.coordinate_unit}}}}


def coordinate_preview_from_snapshot(snapshot, settings=None):
    """Reuse Analyze's final statuses, scope, node pooling and batch semantics."""
    from .tsk_observations import template_for_snapshot, selected_snapshot_rows, observations_from_snapshot
    from .tsk_service import _batch_settings

    settings = settings or {}
    template = template_for_snapshot(snapshot)
    batch = _batch_settings(template, **{name: settings[name] for name in
                            ("batch_mode", "batch_dimension", "batch_mapping") if name in settings})
    observations = observations_from_snapshot(snapshot, template, selected_snapshot_rows(snapshot, settings), batch,
                                              node_mode=settings.get("node_mode", "separate"))
    payload = coordinate_preview_from_template(template)
    payload["coordinate_view_mode"] = "observed"
    payload["groups"] = [{"label": group["label"], "node": group["node"], "stratum": group.get("stratum", {}),
        "chains": [{**row, "observed_probability": row["n_failed"] / row["n_tested"] if row["n_tested"] else None}
                   for row in group["counts"]]} for group in observations]
    return payload
