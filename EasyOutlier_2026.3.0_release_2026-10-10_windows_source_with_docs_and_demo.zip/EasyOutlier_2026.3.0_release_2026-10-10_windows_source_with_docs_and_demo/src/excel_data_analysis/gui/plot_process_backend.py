"""Bounded process actors for demand-driven Plot Inspector tiles.

The GUI polls futures and explicitly releases completed image slots after
decoding. No executor callback touches Qt or allocates hover objects. Closing
starts a bounded reaper thread; only rasterization runs in child processes.
"""
from __future__ import annotations

from collections import OrderedDict
from concurrent.futures import Future, ProcessPoolExecutor
from concurrent.futures.process import BrokenProcessPool
from dataclasses import dataclass, field
import logging
import multiprocessing as mp
from multiprocessing.shared_memory import SharedMemory
import os
from threading import Event, Thread
from time import monotonic
from typing import Any

from PySide6.QtGui import QGuiApplication, QImage

from ..compute_resources import limit_process_workers
from .plot_process_worker import process_request, serialize_font, transport_canvas_width_floor

_LOG = logging.getLogger(__name__)
_MAX_SLOT_BYTES = 64 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class ProcessCompletion:
    actor: int
    token: Any
    result: dict[str, Any] | None = None
    error: Exception | None = None


@dataclass(slots=True)
class _Pending:
    future: Future
    token: Any
    cache_key: tuple | None
    epoch: int
    started: float
    reset: bool


@dataclass(slots=True)
class _Actor:
    executor: ProcessPoolExecutor | None = None
    slot: SharedMemory | None = None
    pending: _Pending | None = None
    completion: ProcessCompletion | None = None
    known: OrderedDict = field(default_factory=OrderedDict)
    crashes: int = 0
    reset: bool = False


def _close_slot(slot: SharedMemory | None) -> None:
    if slot is None:
        return
    try:
        slot.close()
    finally:
        try:
            slot.unlink()
        except FileNotFoundError:
            pass


def _reap(resources: list[tuple[ProcessPoolExecutor | None, SharedMemory | None]], done: Event) -> None:
    """Keep close nonblocking and reclaim slots only after writers have exited."""
    try:
        processes = []
        for executor, _ in resources:
            if executor is not None:
                # Python 3.10 has no public terminate_workers(). Capture the
                # child handles before shutdown clears its internal mapping.
                processes.extend((getattr(executor, "_processes", None) or {}).values())
                executor.shutdown(wait=False, cancel_futures=True)
        deadline = monotonic() + 3.0
        for process in processes:
            process.join(max(0.0, deadline - monotonic()))
        for process in processes:
            if process.is_alive():
                process.terminate()
        for process in processes:
            process.join(1.0)
            if process.is_alive():
                process.kill()
                process.join(1.0)
    except Exception:
        _LOG.exception("Plot rendering process cleanup failed")
    finally:
        for _, slot in resources:
            try:
                _close_slot(slot)
            except Exception:
                _LOG.exception("Plot rendering shared-memory cleanup failed")
        done.set()


class PlotProcessBackend:
    """One in-flight tile per actor, with stable metric affinity and local LRU.

    Always pass original ``series`` to submit. Only cache misses serialize it.
    Every item returned by poll must be released after decoding or discarding;
    even a completed actor cannot overwrite its slot before that release.
    Calls other than wait_closed belong to the GUI thread.
    """

    def __init__(self, workers: int | None = None, cache_capacity: int = 32,
                 task_timeout: float = 60.0) -> None:
        if QGuiApplication.instance() is None:
            raise RuntimeError("Create the Qt application before the plot backend")
        self.count = limit_process_workers(max(1, min(4, workers if workers is not None else (os.cpu_count() or 1))))
        self.cache_capacity = max(1, int(cache_capacity))
        self.task_timeout = max(0.01, float(task_timeout))
        self._actors = [_Actor() for _ in range(self.count)]
        self._epoch = 0
        self._closed = False
        self._shutdown = Event()
        self._retired: list[Event] = []
        font = QGuiApplication.font()
        self._font_data = serialize_font(font)
        self._font_resolve_mask = font.resolveMask()
        self._platform = QGuiApplication.platformName()
        self._canvas_width_floor = transport_canvas_width_floor()
        probe = QImage(1, 1, QImage.Format.Format_ARGB32_Premultiplied)
        self._image_dpm = (probe.dotsPerMeterX(), probe.dotsPerMeterY())

    def refresh_context(self) -> bool:
        """Refresh raster font/DPI after a GUI font or display change.

        The viewport must cancel old results and drop its image/axis caches
        when this returns True. Children invalidate prepared geometry when
        these fields change; their original-series cache remains reusable.
        DPR is independently supplied on every render request.
        """
        if self._closed:
            return False
        font = QGuiApplication.font()
        font_data = serialize_font(font)
        font_resolve_mask = font.resolveMask()
        probe = QImage(1, 1, QImage.Format.Format_ARGB32_Premultiplied)
        image_dpm = (probe.dotsPerMeterX(), probe.dotsPerMeterY())
        changed = (font_data != self._font_data or font_resolve_mask != self._font_resolve_mask
                   or image_dpm != self._image_dpm)
        self._font_data, self._image_dpm = font_data, image_dpm
        self._font_resolve_mask = font_resolve_mask
        return changed

    @property
    def closed(self) -> bool:
        return self._closed

    @property
    def shutdown_finished(self) -> bool:
        return self._shutdown.is_set() and all(event.is_set() for event in self._retired)

    @property
    def running_count(self) -> int:
        return sum(actor.pending is not None or actor.completion is not None for actor in self._actors)

    @property
    def cached_metric_count(self) -> int:
        return sum(len(actor.known) for actor in self._actors)

    def actor_for(self, metric_id: int) -> int:
        return int(metric_id) % self.count

    def can_submit(self, metric_id: int) -> bool:
        actor = self._actors[self.actor_for(metric_id)]
        # A disabled actor remains available so submit raises a concrete error
        # and the viewport can mark the tile failed instead of spinning.
        return not self._closed and actor.pending is None and actor.completion is None

    def invalidate(self) -> None:
        """Drop old metric data inside each child on its next request."""
        self._epoch += 1
        for actor in self._actors:
            actor.known.clear()
            actor.reset = True

    def warmup(self) -> None:
        """Start idle actors asynchronously; drain token-None completions normally."""
        for index in range(self.count):
            if self.can_submit(index):
                self.submit({"op": "warmup", "metric_id": index}, token=None)

    def _ensure_slot(self, actor: _Actor, request: dict[str, Any]) -> None:
        dpr = float(request.get("dpr", 1.0))
        width = max(1, round(max(self._canvas_width_floor, int(request.get("width", 957))) * dpr))
        lanes = len(request.get("lane_indices", ())) or len(request.get("series", ())) or 1
        height = max(1, round(lanes * int(request.get("lane_height", 30)) * dpr))
        if request.get("include_header", True):
            height += max(1, round(66 * dpr))
        needed = width * height * 4
        if needed > _MAX_SLOT_BYTES:
            return  # Oversize requests use bytes rather than retain huge slots.
        if actor.slot is not None and actor.slot.size >= needed:
            return
        _close_slot(actor.slot)
        actor.slot = None
        try:
            actor.slot = SharedMemory(create=True, size=max(1024 * 1024, needed))
        except OSError:
            _LOG.warning("Shared image memory unavailable; using byte transport", exc_info=True)

    def submit(self, request: dict[str, Any], token: Any = None) -> int:
        if self._closed:
            raise RuntimeError("Plot rendering backend is closed")
        index = self.actor_for(request["metric_id"])
        actor = self._actors[index]
        if not self.can_submit(request["metric_id"]):
            raise RuntimeError("Plot rendering actor still owns an unreleased result")
        if actor.crashes >= 2:
            raise RuntimeError("Plot rendering process repeatedly exited; reopen Plot Inspector to retry")
        if actor.executor is None:
            actor.executor = ProcessPoolExecutor(max_workers=1, mp_context=mp.get_context("spawn"))
        outgoing = dict(request)
        outgoing.update(font_data=self._font_data, font_resolve_mask=self._font_resolve_mask,
                        image_dpm=self._image_dpm,
                        qt_platform=self._platform, cache_capacity=self.cache_capacity)
        cache_key = None
        if outgoing.get("op", "render") == "render":
            cache_key = (request["metric_id"], request.get("generation", 0), tuple(request.get("lane_headers", ())))
            if cache_key in actor.known and not actor.reset:
                outgoing.pop("series", None)
            elif "series" not in outgoing:
                raise ValueError("An uncached plot metric needs its original series")
            self._ensure_slot(actor, request)
            if actor.slot is not None:
                outgoing.update(shm_name=actor.slot.name, shm_capacity=actor.slot.size)
        if actor.reset:
            outgoing["reset_cache"] = True
        try:
            future = actor.executor.submit(process_request, outgoing)
        except BrokenProcessPool:
            self._retire(actor)
            actor.crashes += 1
            actor.known.clear()
            raise
        actor.pending = _Pending(future, token, cache_key, self._epoch, monotonic(), actor.reset)
        return index

    def _retire(self, actor: _Actor) -> None:
        done = Event()
        resources = [(actor.executor, actor.slot)]
        actor.executor = None
        actor.slot = None
        self._retired = [event for event in self._retired if not event.is_set()]
        self._retired.append(done)
        Thread(target=_reap, args=(resources, done), name="plot-process-reaper", daemon=True).start()

    def poll(self) -> list[ProcessCompletion]:
        if self._closed:
            return []
        completed = []
        for index, actor in enumerate(self._actors):
            pending = actor.pending
            if pending is None:
                continue
            timed_out = monotonic() - pending.started > self.task_timeout
            if not pending.future.done() and not timed_out:
                continue
            result, error = None, None
            try:
                if not pending.future.done():
                    raise TimeoutError("Plot rendering process did not finish in time")
                result = pending.future.result()
                if pending.epoch == self._epoch:
                    if pending.reset:
                        actor.reset = False
                    if pending.cache_key is not None:
                        actor.known[pending.cache_key] = True
                        actor.known.move_to_end(pending.cache_key)
                        while len(actor.known) > self.cache_capacity:
                            actor.known.popitem(last=False)
            except Exception as exc:
                error = exc
                actor.known.clear()
                actor.reset = True
                if isinstance(exc, (BrokenProcessPool, TimeoutError)):
                    actor.crashes += 1
                    self._retire(actor)
            completion = ProcessCompletion(index, pending.token, result, error)
            actor.pending = None
            actor.completion = completion
            completed.append(completion)
        return completed

    def release(self, completion: ProcessCompletion) -> None:
        if self._closed:
            return
        actor = self._actors[completion.actor]
        if actor.completion is not completion:
            raise ValueError("This plot result was already released or belongs to another backend")
        actor.completion = None

    def close(self, wait: bool = False) -> None:
        if not self._closed:
            self._closed = True
            resources = []
            for actor in self._actors:
                if actor.pending is not None:
                    actor.pending.future.cancel()
                actor.pending = None
                actor.completion = None
                actor.known.clear()
                resources.append((actor.executor, actor.slot))
                actor.executor = None
                actor.slot = None
            Thread(target=_reap, args=(resources, self._shutdown),
                   name="plot-process-reaper", daemon=True).start()
        if wait:
            self.wait_closed()

    def wait_closed(self, timeout: float | None = None) -> bool:
        deadline = None if timeout is None else monotonic() + timeout
        for event in (self._shutdown, *self._retired):
            remaining = None if deadline is None else max(0.0, deadline - monotonic())
            if not event.wait(remaining):
                return False
        return True
