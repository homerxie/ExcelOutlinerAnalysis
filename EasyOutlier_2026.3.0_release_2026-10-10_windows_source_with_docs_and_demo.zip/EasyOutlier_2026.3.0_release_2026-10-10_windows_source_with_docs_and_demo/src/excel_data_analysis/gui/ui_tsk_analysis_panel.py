# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_analysis_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QDoubleSpinBox, QFrame, QGridLayout, QGroupBox,
    QHeaderView, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QSpinBox, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget)

class Ui_TskAnalysisPanelForm(object):
    def setupUi(self, TskAnalysisPanelForm):
        if not TskAnalysisPanelForm.objectName():
            TskAnalysisPanelForm.setObjectName(u"TskAnalysisPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskAnalysisPanelForm.sizePolicy().hasHeightForWidth())
        TskAnalysisPanelForm.setSizePolicy(sizePolicy)
        self.panelLayout = QVBoxLayout(TskAnalysisPanelForm)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.settingsScrollArea = QScrollArea(TskAnalysisPanelForm)
        self.settingsScrollArea.setObjectName(u"settingsScrollArea")
        self.settingsScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.settingsScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.settingsScrollArea.setWidgetResizable(True)
        self.settingsContent = QWidget()
        self.settingsContent.setObjectName(u"settingsContent")
        self.settingsLayout = QVBoxLayout(self.settingsContent)
        self.settingsLayout.setSpacing(12)
        self.settingsLayout.setObjectName(u"settingsLayout")
        self.introLabel = QLabel(self.settingsContent)
        self.introLabel.setObjectName(u"introLabel")
        self.introLabel.setWordWrap(True)

        self.settingsLayout.addWidget(self.introLabel)

        self.topologyGroupBox = QGroupBox(self.settingsContent)
        self.topologyGroupBox.setObjectName(u"topologyGroupBox")
        self.topologyLayout = QVBoxLayout(self.topologyGroupBox)
        self.topologyLayout.setObjectName(u"topologyLayout")
        self.topologySummaryLabel = QLabel(self.topologyGroupBox)
        self.topologySummaryLabel.setObjectName(u"topologySummaryLabel")
        self.topologySummaryLabel.setWordWrap(True)

        self.topologyLayout.addWidget(self.topologySummaryLabel)

        self.contextLabel = QLabel(self.topologyGroupBox)
        self.contextLabel.setObjectName(u"contextLabel")
        self.contextLabel.setWordWrap(True)

        self.topologyLayout.addWidget(self.contextLabel)


        self.settingsLayout.addWidget(self.topologyGroupBox)

        self.scopeGroupBox = QGroupBox(self.settingsContent)
        self.scopeGroupBox.setObjectName(u"scopeGroupBox")
        self.scopeLayout = QGridLayout(self.scopeGroupBox)
        self.scopeLayout.setObjectName(u"scopeLayout")
        self.scopeLayout.setHorizontalSpacing(12)
        self.scopeLayout.setVerticalSpacing(10)
        self.sourceLabel = QLabel(self.scopeGroupBox)
        self.sourceLabel.setObjectName(u"sourceLabel")

        self.scopeLayout.addWidget(self.sourceLabel, 0, 0, 1, 1)

        self.sourceComboBox = QComboBox(self.scopeGroupBox)
        self.sourceComboBox.addItem("")
        self.sourceComboBox.addItem("")
        self.sourceComboBox.setObjectName(u"sourceComboBox")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.sourceComboBox.sizePolicy().hasHeightForWidth())
        self.sourceComboBox.setSizePolicy(sizePolicy1)

        self.scopeLayout.addWidget(self.sourceComboBox, 0, 1, 1, 1)

        self.scopeLabel = QLabel(self.scopeGroupBox)
        self.scopeLabel.setObjectName(u"scopeLabel")

        self.scopeLayout.addWidget(self.scopeLabel, 1, 0, 1, 1)

        self.scopeComboBox = QComboBox(self.scopeGroupBox)
        self.scopeComboBox.addItem("")
        self.scopeComboBox.addItem("")
        self.scopeComboBox.setObjectName(u"scopeComboBox")
        sizePolicy1.setHeightForWidth(self.scopeComboBox.sizePolicy().hasHeightForWidth())
        self.scopeComboBox.setSizePolicy(sizePolicy1)

        self.scopeLayout.addWidget(self.scopeComboBox, 1, 1, 1, 1)

        self.importsListWidget = QListWidget(self.scopeGroupBox)
        self.importsListWidget.setObjectName(u"importsListWidget")
        self.importsListWidget.setEnabled(False)
        self.importsListWidget.setMinimumSize(QSize(0, 90))
        self.importsListWidget.setMaximumSize(QSize(16777215, 140))
        self.importsListWidget.setWordWrap(True)

        self.scopeLayout.addWidget(self.importsListWidget, 2, 0, 1, 2)

        self.refreshButton = QPushButton(self.scopeGroupBox)
        self.refreshButton.setObjectName(u"refreshButton")
        sizePolicy1.setHeightForWidth(self.refreshButton.sizePolicy().hasHeightForWidth())
        self.refreshButton.setSizePolicy(sizePolicy1)

        self.scopeLayout.addWidget(self.refreshButton, 3, 1, 1, 1)

        self.nodesLabel = QLabel(self.scopeGroupBox)
        self.nodesLabel.setObjectName(u"nodesLabel")

        self.scopeLayout.addWidget(self.nodesLabel, 4, 0, 1, 1)

        self.nodesEdit = QLineEdit(self.scopeGroupBox)
        self.nodesEdit.setObjectName(u"nodesEdit")

        self.scopeLayout.addWidget(self.nodesEdit, 4, 1, 1, 1)

        self.samplesLabel = QLabel(self.scopeGroupBox)
        self.samplesLabel.setObjectName(u"samplesLabel")

        self.scopeLayout.addWidget(self.samplesLabel, 5, 0, 1, 1)

        self.samplesEdit = QLineEdit(self.scopeGroupBox)
        self.samplesEdit.setObjectName(u"samplesEdit")

        self.scopeLayout.addWidget(self.samplesEdit, 5, 1, 1, 1)

        self.scopeLayout.setColumnStretch(1, 1)

        self.settingsLayout.addWidget(self.scopeGroupBox)

        self.batchGroupBox = QGroupBox(self.settingsContent)
        self.batchGroupBox.setObjectName(u"batchGroupBox")
        self.batchLayout = QGridLayout(self.batchGroupBox)
        self.batchLayout.setObjectName(u"batchLayout")
        self.batchLayout.setHorizontalSpacing(12)
        self.batchLayout.setVerticalSpacing(10)
        self.batchModeLabel = QLabel(self.batchGroupBox)
        self.batchModeLabel.setObjectName(u"batchModeLabel")

        self.batchLayout.addWidget(self.batchModeLabel, 0, 0, 1, 1)

        self.batchModeComboBox = QComboBox(self.batchGroupBox)
        self.batchModeComboBox.addItem("")
        self.batchModeComboBox.addItem("")
        self.batchModeComboBox.addItem("")
        self.batchModeComboBox.setObjectName(u"batchModeComboBox")
        sizePolicy1.setHeightForWidth(self.batchModeComboBox.sizePolicy().hasHeightForWidth())
        self.batchModeComboBox.setSizePolicy(sizePolicy1)

        self.batchLayout.addWidget(self.batchModeComboBox, 0, 1, 1, 1)

        self.batchDimensionLabel = QLabel(self.batchGroupBox)
        self.batchDimensionLabel.setObjectName(u"batchDimensionLabel")

        self.batchLayout.addWidget(self.batchDimensionLabel, 1, 0, 1, 1)

        self.batchDimensionComboBox = QComboBox(self.batchGroupBox)
        self.batchDimensionComboBox.setObjectName(u"batchDimensionComboBox")
        self.batchDimensionComboBox.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.batchDimensionComboBox.sizePolicy().hasHeightForWidth())
        self.batchDimensionComboBox.setSizePolicy(sizePolicy1)
        self.batchDimensionComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.batchDimensionComboBox.setMinimumContentsLength(12)

        self.batchLayout.addWidget(self.batchDimensionComboBox, 1, 1, 1, 1)

        self.batchScopeHintLabel = QLabel(self.batchGroupBox)
        self.batchScopeHintLabel.setObjectName(u"batchScopeHintLabel")
        self.batchScopeHintLabel.setWordWrap(True)

        self.batchLayout.addWidget(self.batchScopeHintLabel, 2, 0, 1, 2)

        self.scanBatchesButton = QPushButton(self.batchGroupBox)
        self.scanBatchesButton.setObjectName(u"scanBatchesButton")
        self.scanBatchesButton.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.scanBatchesButton.sizePolicy().hasHeightForWidth())
        self.scanBatchesButton.setSizePolicy(sizePolicy1)

        self.batchLayout.addWidget(self.scanBatchesButton, 3, 0, 1, 2)

        self.batchMappingHintLabel = QLabel(self.batchGroupBox)
        self.batchMappingHintLabel.setObjectName(u"batchMappingHintLabel")
        self.batchMappingHintLabel.setVisible(False)
        self.batchMappingHintLabel.setWordWrap(True)

        self.batchLayout.addWidget(self.batchMappingHintLabel, 4, 0, 1, 2)

        self.batchMappingTableWidget = QTableWidget(self.batchGroupBox)
        if (self.batchMappingTableWidget.columnCount() < 2):
            self.batchMappingTableWidget.setColumnCount(2)
        __qtablewidgetitem = QTableWidgetItem()
        self.batchMappingTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.batchMappingTableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        self.batchMappingTableWidget.setObjectName(u"batchMappingTableWidget")
        self.batchMappingTableWidget.setVisible(False)
        self.batchMappingTableWidget.setEnabled(False)
        self.batchMappingTableWidget.setMinimumSize(QSize(0, 96))
        self.batchMappingTableWidget.setMaximumSize(QSize(16777215, 170))
        self.batchMappingTableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.batchMappingTableWidget.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.batchMappingTableWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.batchMappingTableWidget.setAlternatingRowColors(True)
        self.batchMappingTableWidget.setSortingEnabled(False)
        self.batchMappingTableWidget.horizontalHeader().setDefaultSectionSize(180)
        self.batchMappingTableWidget.horizontalHeader().setStretchLastSection(True)
        self.batchMappingTableWidget.verticalHeader().setVisible(False)

        self.batchLayout.addWidget(self.batchMappingTableWidget, 5, 0, 1, 2)

        self.batchScanHintLabel = QLabel(self.batchGroupBox)
        self.batchScanHintLabel.setObjectName(u"batchScanHintLabel")
        self.batchScanHintLabel.setVisible(False)
        self.batchScanHintLabel.setWordWrap(True)

        self.batchLayout.addWidget(self.batchScanHintLabel, 6, 0, 1, 2)

        self.batchLayout.setColumnStretch(1, 1)

        self.settingsLayout.addWidget(self.batchGroupBox)

        self.modelGroupBox = QGroupBox(self.settingsContent)
        self.modelGroupBox.setObjectName(u"modelGroupBox")
        self.modelLayout = QGridLayout(self.modelGroupBox)
        self.modelLayout.setObjectName(u"modelLayout")
        self.modelLayout.setHorizontalSpacing(12)
        self.modelLayout.setVerticalSpacing(10)
        self.sharedFailRulesLabel = QLabel(self.modelGroupBox)
        self.sharedFailRulesLabel.setObjectName(u"sharedFailRulesLabel")
        self.sharedFailRulesLabel.setWordWrap(True)
        self.sharedFailRulesLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.modelLayout.addWidget(self.sharedFailRulesLabel, 0, 0, 1, 2)

        self.sharedFailRulesHintLabel = QLabel(self.modelGroupBox)
        self.sharedFailRulesHintLabel.setObjectName(u"sharedFailRulesHintLabel")
        self.sharedFailRulesHintLabel.setWordWrap(True)

        self.modelLayout.addWidget(self.sharedFailRulesHintLabel, 1, 0, 1, 2)

        self.missingPolicyLabel = QLabel(self.modelGroupBox)
        self.missingPolicyLabel.setObjectName(u"missingPolicyLabel")
        self.missingPolicyLabel.setWordWrap(True)

        self.modelLayout.addWidget(self.missingPolicyLabel, 2, 0, 1, 2)

        self.featureModelLabel = QLabel(self.modelGroupBox)
        self.featureModelLabel.setObjectName(u"featureModelLabel")

        self.modelLayout.addWidget(self.featureModelLabel, 3, 0, 1, 1)

        self.featureModelValueLabel = QLabel(self.modelGroupBox)
        self.featureModelValueLabel.setObjectName(u"featureModelValueLabel")
        sizePolicy1.setHeightForWidth(self.featureModelValueLabel.sizePolicy().hasHeightForWidth())
        self.featureModelValueLabel.setSizePolicy(sizePolicy1)

        self.modelLayout.addWidget(self.featureModelValueLabel, 3, 1, 1, 1)

        self.featureModelHintLabel = QLabel(self.modelGroupBox)
        self.featureModelHintLabel.setObjectName(u"featureModelHintLabel")
        self.featureModelHintLabel.setWordWrap(True)
        self.featureModelHintLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.modelLayout.addWidget(self.featureModelHintLabel, 4, 0, 1, 2)

        self.includeXYCheckBox = QCheckBox(self.modelGroupBox)
        self.includeXYCheckBox.setObjectName(u"includeXYCheckBox")
        self.includeXYCheckBox.setEnabled(False)
        self.includeXYCheckBox.setChecked(False)

        self.modelLayout.addWidget(self.includeXYCheckBox, 5, 0, 1, 2)

        self.xyModelLabel = QLabel(self.modelGroupBox)
        self.xyModelLabel.setObjectName(u"xyModelLabel")
        self.xyModelLabel.setEnabled(False)

        self.modelLayout.addWidget(self.xyModelLabel, 6, 0, 1, 1)

        self.xyModelComboBox = QComboBox(self.modelGroupBox)
        self.xyModelComboBox.addItem("")
        self.xyModelComboBox.addItem("")
        self.xyModelComboBox.setObjectName(u"xyModelComboBox")
        self.xyModelComboBox.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.xyModelComboBox.sizePolicy().hasHeightForWidth())
        self.xyModelComboBox.setSizePolicy(sizePolicy1)
        self.xyModelComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.xyModelComboBox.setMinimumContentsLength(10)

        self.modelLayout.addWidget(self.xyModelComboBox, 6, 1, 1, 1)

        self.xyModelHintLabel = QLabel(self.modelGroupBox)
        self.xyModelHintLabel.setObjectName(u"xyModelHintLabel")
        self.xyModelHintLabel.setEnabled(False)
        self.xyModelHintLabel.setWordWrap(True)

        self.modelLayout.addWidget(self.xyModelHintLabel, 7, 0, 1, 2)

        self.featuresLabel = QLabel(self.modelGroupBox)
        self.featuresLabel.setObjectName(u"featuresLabel")

        self.modelLayout.addWidget(self.featuresLabel, 8, 0, 1, 2)

        self.featuresListWidget = QListWidget(self.modelGroupBox)
        self.featuresListWidget.setObjectName(u"featuresListWidget")
        self.featuresListWidget.setEnabled(False)
        self.featuresListWidget.setMinimumSize(QSize(0, 70))
        self.featuresListWidget.setMaximumSize(QSize(16777215, 120))
        self.featuresListWidget.setWordWrap(True)

        self.modelLayout.addWidget(self.featuresListWidget, 9, 0, 1, 2)

        self.logisticCoefficientBoundLabel = QLabel(self.modelGroupBox)
        self.logisticCoefficientBoundLabel.setObjectName(u"logisticCoefficientBoundLabel")
        self.logisticCoefficientBoundLabel.setEnabled(False)

        self.modelLayout.addWidget(self.logisticCoefficientBoundLabel, 10, 0, 1, 1)

        self.logisticCoefficientBoundSpinBox = QDoubleSpinBox(self.modelGroupBox)
        self.logisticCoefficientBoundSpinBox.setObjectName(u"logisticCoefficientBoundSpinBox")
        self.logisticCoefficientBoundSpinBox.setEnabled(False)
        self.logisticCoefficientBoundSpinBox.setDecimals(1)
        self.logisticCoefficientBoundSpinBox.setMinimum(1.000000000000000)
        self.logisticCoefficientBoundSpinBox.setMaximum(700.000000000000000)
        self.logisticCoefficientBoundSpinBox.setSingleStep(5.000000000000000)
        self.logisticCoefficientBoundSpinBox.setValue(35.000000000000000)
        sizePolicy1.setHeightForWidth(self.logisticCoefficientBoundSpinBox.sizePolicy().hasHeightForWidth())
        self.logisticCoefficientBoundSpinBox.setSizePolicy(sizePolicy1)

        self.modelLayout.addWidget(self.logisticCoefficientBoundSpinBox, 10, 1, 1, 1)

        self.logisticCoefficientBoundHintLabel = QLabel(self.modelGroupBox)
        self.logisticCoefficientBoundHintLabel.setObjectName(u"logisticCoefficientBoundHintLabel")
        self.logisticCoefficientBoundHintLabel.setEnabled(False)
        self.logisticCoefficientBoundHintLabel.setWordWrap(True)

        self.modelLayout.addWidget(self.logisticCoefficientBoundHintLabel, 11, 0, 1, 2)

        self.intervalLabel = QLabel(self.modelGroupBox)
        self.intervalLabel.setObjectName(u"intervalLabel")
        self.intervalLabel.setWordWrap(True)

        self.modelLayout.addWidget(self.intervalLabel, 12, 0, 1, 2)

        self.featureEffectsModeLabel = QLabel(self.modelGroupBox)
        self.featureEffectsModeLabel.setObjectName(u"featureEffectsModeLabel")

        self.modelLayout.addWidget(self.featureEffectsModeLabel, 13, 0, 1, 1)

        self.featureEffectsModeComboBox = QComboBox(self.modelGroupBox)
        self.featureEffectsModeComboBox.addItem("")
        self.featureEffectsModeComboBox.addItem("")
        self.featureEffectsModeComboBox.setObjectName(u"featureEffectsModeComboBox")

        self.modelLayout.addWidget(self.featureEffectsModeComboBox, 13, 1, 1, 1)

        self.simulationReplicatesLabel = QLabel(self.modelGroupBox)
        self.simulationReplicatesLabel.setObjectName(u"simulationReplicatesLabel")
        self.simulationReplicatesLabel.setEnabled(False)

        self.modelLayout.addWidget(self.simulationReplicatesLabel, 14, 0, 1, 1)

        self.simulationReplicatesSpinBox = QSpinBox(self.modelGroupBox)
        self.simulationReplicatesSpinBox.setObjectName(u"simulationReplicatesSpinBox")
        self.simulationReplicatesSpinBox.setEnabled(False)
        self.simulationReplicatesSpinBox.setMinimum(99)
        self.simulationReplicatesSpinBox.setMaximum(19999)
        self.simulationReplicatesSpinBox.setSingleStep(100)
        self.simulationReplicatesSpinBox.setValue(999)

        self.modelLayout.addWidget(self.simulationReplicatesSpinBox, 14, 1, 1, 1)

        self.simulationSeedLabel = QLabel(self.modelGroupBox)
        self.simulationSeedLabel.setObjectName(u"simulationSeedLabel")
        self.simulationSeedLabel.setEnabled(False)

        self.modelLayout.addWidget(self.simulationSeedLabel, 15, 0, 1, 1)

        self.simulationSeedSpinBox = QSpinBox(self.modelGroupBox)
        self.simulationSeedSpinBox.setObjectName(u"simulationSeedSpinBox")
        self.simulationSeedSpinBox.setEnabled(False)
        self.simulationSeedSpinBox.setMaximum(2147483647)
        self.simulationSeedSpinBox.setValue(1729)

        self.modelLayout.addWidget(self.simulationSeedSpinBox, 15, 1, 1, 1)

        self.simulationWorkersLabel = QLabel(self.modelGroupBox)
        self.simulationWorkersLabel.setObjectName(u"simulationWorkersLabel")
        self.simulationWorkersLabel.setEnabled(False)

        self.modelLayout.addWidget(self.simulationWorkersLabel, 16, 0, 1, 1)

        self.simulationWorkersSpinBox = QSpinBox(self.modelGroupBox)
        self.simulationWorkersSpinBox.setObjectName(u"simulationWorkersSpinBox")
        self.simulationWorkersSpinBox.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.simulationWorkersSpinBox.sizePolicy().hasHeightForWidth())
        self.simulationWorkersSpinBox.setSizePolicy(sizePolicy1)
        self.simulationWorkersSpinBox.setMaximum(64)
        self.simulationWorkersSpinBox.setValue(0)

        self.modelLayout.addWidget(self.simulationWorkersSpinBox, 16, 1, 1, 1)

        self.simulationHintLabel = QLabel(self.modelGroupBox)
        self.simulationHintLabel.setObjectName(u"simulationHintLabel")
        self.simulationHintLabel.setVisible(False)
        self.simulationHintLabel.setWordWrap(True)

        self.modelLayout.addWidget(self.simulationHintLabel, 17, 0, 1, 2)

        self.modelLayout.setColumnStretch(1, 1)

        self.settingsLayout.addWidget(self.modelGroupBox)

        self.settingsSpacer = QSpacerItem(20, 10, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.settingsLayout.addItem(self.settingsSpacer)

        self.settingsScrollArea.setWidget(self.settingsContent)

        self.panelLayout.addWidget(self.settingsScrollArea)

        self.runButton = QPushButton(TskAnalysisPanelForm)
        self.runButton.setObjectName(u"runButton")
        self.runButton.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.runButton.sizePolicy().hasHeightForWidth())
        self.runButton.setSizePolicy(sizePolicy1)

        self.panelLayout.addWidget(self.runButton)

        self.saveHtmlButton = QPushButton(TskAnalysisPanelForm)
        self.saveHtmlButton.setObjectName(u"saveHtmlButton")
        self.saveHtmlButton.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.saveHtmlButton.sizePolicy().hasHeightForWidth())
        self.saveHtmlButton.setSizePolicy(sizePolicy1)

        self.panelLayout.addWidget(self.saveHtmlButton)

#if QT_CONFIG(shortcut)
        self.sourceLabel.setBuddy(self.sourceComboBox)
        self.scopeLabel.setBuddy(self.scopeComboBox)
        self.nodesLabel.setBuddy(self.nodesEdit)
        self.samplesLabel.setBuddy(self.samplesEdit)
        self.batchModeLabel.setBuddy(self.batchModeComboBox)
        self.batchDimensionLabel.setBuddy(self.batchDimensionComboBox)
        self.xyModelLabel.setBuddy(self.xyModelComboBox)
        self.featuresLabel.setBuddy(self.featuresListWidget)
        self.logisticCoefficientBoundLabel.setBuddy(self.logisticCoefficientBoundSpinBox)
        self.featureEffectsModeLabel.setBuddy(self.featureEffectsModeComboBox)
        self.simulationReplicatesLabel.setBuddy(self.simulationReplicatesSpinBox)
        self.simulationSeedLabel.setBuddy(self.simulationSeedSpinBox)
        self.simulationWorkersLabel.setBuddy(self.simulationWorkersSpinBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskAnalysisPanelForm)

        QMetaObject.connectSlotsByName(TskAnalysisPanelForm)
    # setupUi

    def retranslateUi(self, TskAnalysisPanelForm):
        self.introLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u72ec\u7acb\u4f30\u8ba1 TSK \u5355\u5b9e\u4f8b\u5f02\u5e38\u6982\u7387\u3002\u4f7f\u7528 Setup \u4e2d\u7684\u6a21\u677f\u4e0e\u8def\u5f84\uff0c\u6bcf\u4e2a\u53ef\u9760\u6027\u8282\u70b9\u6309\u6240\u9009\u6279\u6b21\u65b9\u5f0f\u5206\u522b\u62df\u5408\uff1b\u4e0d\u4f9d\u8d56\u666e\u901a Analyze \u7684\u8f93\u51fa\u3002", None))
        self.topologyGroupBox.setTitle(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6a21\u677f\u4e2d\u7684 Chain\u2013TSK \u7ec4\u6210", None))
        self.topologySummaryLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u8bf7\u52a0\u8f7d\u542b\u6709 TSK \u5b9e\u4f8b\u7ec4\u6210\u7684\u6a21\u677f\u3002", None))
        self.topologySummaryLabel.setProperty(u"emptyText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u5f53\u524d\u6a21\u677f\u672a\u914d\u7f6e TSK \u5b9e\u4f8b\u7ec4\u6210\u3002", None))
        self.topologySummaryLabel.setProperty(u"disabledText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u6a21\u677f\u4e2d\u7684 TSK \u5206\u6790\u672a\u542f\u7528\u3002", None))
        self.contextLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"TSK_instance_ID \u6807\u8bc6\u5b9e\u4f8b\uff1b\u540c\u4e00 TSK_ID \u7684\u91cd\u590d\u5b9e\u4f8b\u5747\u53c2\u4e0e\u8ba1\u7b97\u3002", None))
        self.scopeGroupBox.setTitle(QCoreApplication.translate("TskAnalysisPanelForm", u"\u672c\u6b21 TSK \u5206\u6790\u8303\u56f4", None))
        self.sourceLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6570\u636e\u6e90", None))
        self.sourceComboBox.setItemText(0, QCoreApplication.translate("TskAnalysisPanelForm", u"Database \u00b7 \u5f53\u524d\u6570\u636e\u5e93", None))
        self.sourceComboBox.setItemText(1, QCoreApplication.translate("TskAnalysisPanelForm", u"Input \u00b7 Setup \u4e2d\u7684\u8f93\u5165\u6587\u4ef6", None))

        self.scopeLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6570\u636e\u5e93\u8303\u56f4", None))
        self.scopeComboBox.setItemText(0, QCoreApplication.translate("TskAnalysisPanelForm", u"Entire Database \u00b7 \u5168\u90e8\u5bfc\u5165", None))
        self.scopeComboBox.setItemText(1, QCoreApplication.translate("TskAnalysisPanelForm", u"Selected Imports \u00b7 \u52fe\u9009\u5bfc\u5165", None))

        self.refreshButton.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u5237\u65b0\u5bfc\u5165\u5217\u8868", None))
        self.nodesLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"Nodes", None))
        self.nodesEdit.setPlaceholderText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u7559\u7a7a\u4f7f\u7528\u5168\u90e8\u8282\u70b9\uff1b\u591a\u4e2a\u503c\u7528\u9017\u53f7\u5206\u9694", None))
        self.samplesLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"Sample IDs", None))
        self.samplesEdit.setPlaceholderText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u7559\u7a7a\u4f7f\u7528\u5168\u90e8\u6837\u54c1\uff1b\u591a\u4e2a\u503c\u7528\u9017\u53f7\u5206\u9694", None))
#if QT_CONFIG(tooltip)
        self.samplesEdit.setToolTip(QCoreApplication.translate("TskAnalysisPanelForm", u"\u7ec4\u5408 Sample ID \u6309\u6a21\u677f\u5b57\u6bb5\u987a\u5e8f\u7528\u201c | \u201d\u8fde\u63a5\uff0c\u4f8b\u5982 Lot1 | Sample2\u3002\u4e5f\u53ef\u586b\u5199\u6700\u540e\u4e00\u4e2a\u8eab\u4efd\u5b57\u6bb5\u7684\u503c\uff1b\u540c\u540d\u503c\u4f1a\u5339\u914d\u591a\u4e2a\u7ec4\u5408 ID\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.batchGroupBox.setTitle(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6279\u6b21\u5206\u6790\uff08\u4ec5 TSK\uff09", None))
        self.batchModeLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6279\u6b21\u6a21\u5f0f", None))
        self.batchModeComboBox.setItemText(0, QCoreApplication.translate("TskAnalysisPanelForm", u"\u4e0d\u5206\u5c42 \u00b7 \u5408\u5e76\u6240\u9009 Lot", None))
        self.batchModeComboBox.setItemText(1, QCoreApplication.translate("TskAnalysisPanelForm", u"\u6309\u539f\u6279\u6b21\u5206\u5c42", None))
        self.batchModeComboBox.setItemText(2, QCoreApplication.translate("TskAnalysisPanelForm", u"\u6309\u6bcd\u6279\u5206\u5c42", None))

#if QT_CONFIG(tooltip)
        self.batchModeComboBox.setToolTip(QCoreApplication.translate("TskAnalysisPanelForm", u"\u4e0d\u5206\u5c42\uff1a\u5c06\u6240\u9009\u8303\u56f4\u5185\u7684\u6240\u6709 Lot \u5408\u5e76\uff0c\u6bcf\u4e2a\u53ef\u9760\u6027\u8282\u70b9\u62df\u5408\u4e00\u7ec4\u3002\u539f\u6279\u6b21\u5206\u5c42\uff1a\u6bcf\u4e2a\u539f\u6279\u6b21\u5404\u62df\u5408\u4e00\u7ec4\u3002\u6bcd\u6279\u5206\u5c42\uff1a\u6bcd\u6279\u7f16\u53f7\u76f8\u540c\u7684\u539f\u6279\u6b21\u5408\u5e76\u62df\u5408\u3002\u4e09\u79cd\u6a21\u5f0f\u5747\u4fdd\u6301\u8282\u70b9\u72ec\u7acb\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.batchDimensionLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u539f\u6279\u6b21\u5b57\u6bb5", None))
        self.batchDimensionComboBox.setProperty(u"noBatchFieldText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u65e0\u6279\u6b21\u5b57\u6bb5 \u00b7 \u4f7f\u7528\u552f\u4e00 Sample ID", None))
#if QT_CONFIG(tooltip)
        self.batchDimensionComboBox.setToolTip(QCoreApplication.translate("TskAnalysisPanelForm", u"\u9009\u62e9\u771f\u5b9e\u6279\u6b21\u5b57\u6bb5\u53ef\u533a\u5206\u4e0d\u540c Lot \u4e2d\u76f8\u540c\u7684 Sample ID\u3002\u65e0\u6279\u6b21\u5b57\u6bb5\u65f6\u6309\u6a21\u677f\u5b9a\u4e49\u7684\u552f\u4e00 Sample ID \u8bc6\u522b\u6837\u54c1\uff1b\u6309\u539f\u6279\u6b21\u6216\u6bcd\u6279\u5206\u5c42\u5fc5\u987b\u9009\u62e9\u6279\u6b21\u5b57\u6bb5\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.batchScopeHintLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u5206\u5c42\u4ec5\u63a7\u5236\u6279\u6b21\uff1b\u53ef\u9760\u6027\u8282\u70b9\u59cb\u7ec8\u5206\u522b\u5206\u6790\u3002", None))
        self.scanBatchesButton.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u626b\u63cf\u5f53\u524d\u8303\u56f4\u4e2d\u7684\u6279\u6b21", None))
        self.batchMappingHintLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u626b\u63cf\u663e\u793a\u5f53\u524d\u8303\u56f4\u4e2d\u7684\u539f\u6279\u6b21\uff1b\u6bcf\u4e2a\u539f\u6279\u6b21\u5206\u522b\u62df\u5408\u3002", None))
        self.batchMappingHintLabel.setProperty(u"separateText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u626b\u63cf\u663e\u793a\u5f53\u524d\u8303\u56f4\u4e2d\u7684\u539f\u6279\u6b21\uff1b\u6bcf\u4e2a\u539f\u6279\u6b21\u5206\u522b\u62df\u5408\u3002", None))
        self.batchMappingHintLabel.setProperty(u"parentText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u7f16\u8f91\u6bcd\u6279\u7f16\u53f7\uff1a\u7f16\u53f7\u76f8\u540c\u7684\u539f\u6279\u6b21\u5408\u5e76\u62df\u5408\u3002\u5f53\u524d\u8303\u56f4\u5185\u6bcf\u4e2a\u539f\u6279\u6b21\u90fd\u9700\u8981\u975e\u7a7a\u6bcd\u6279\u7f16\u53f7\u3002", None))
        ___qtablewidgetitem = self.batchMappingTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u539f\u6279\u6b21", None))
        ___qtablewidgetitem1 = self.batchMappingTableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6bcd\u6279\u7f16\u53f7\uff08\u53ef\u7f16\u8f91\uff09", None))
        self.batchScanHintLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u66f4\u6539\u6570\u636e\u8303\u56f4\u540e\u8bf7\u91cd\u65b0\u626b\u63cf\uff1b\u5df2\u586b\u5199\u7684\u6bcd\u6279\u5bf9\u5e94\u5173\u7cfb\u4f1a\u4fdd\u7559\u3002", None))
        self.modelGroupBox.setTitle(QCoreApplication.translate("TskAnalysisPanelForm", u"\u5f02\u5e38\u5224\u636e\u4e0e\u6a21\u578b", None))
        self.sharedFailRulesLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"Analyze Fail \u89c4\u5219\u5c06\u5728\u52a0\u8f7d\u6a21\u677f\u540e\u663e\u793a\u3002", None))
        self.sharedFailRulesLabel.setProperty(u"emptyText", QCoreApplication.translate("TskAnalysisPanelForm", u"Analyze Fail \u89c4\u5219\u5c06\u5728\u52a0\u8f7d\u6a21\u677f\u540e\u663e\u793a\u3002", None))
        self.sharedFailRulesLabel.setProperty(u"summaryFormat", QCoreApplication.translate("TskAnalysisPanelForm", u"Fail \u5224\u636e\uff1a{method} \u00b7 \u9ed8\u8ba4 Z \u9608\u503c\uff1a{threshold}\n"
"\u7a7a\u503c\u6807\u8bb0\u4e3a Fail\uff1a{empty}", None))
        self.sharedFailRulesLabel.setProperty(u"unknownText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u672a\u63d0\u4f9b", None))
        self.sharedFailRulesLabel.setProperty(u"emptyEnabledText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u5f00\u542f", None))
        self.sharedFailRulesLabel.setProperty(u"emptyDisabledText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u5173\u95ed", None))
        self.sharedFailRulesLabel.setProperty(u"modifiedZScoreText", QCoreApplication.translate("TskAnalysisPanelForm", u"Modified Z Score", None))
        self.sharedFailRulesLabel.setProperty(u"goldenDeviationText", QCoreApplication.translate("TskAnalysisPanelForm", u"Golden Deviation", None))
        self.sharedFailRulesLabel.setProperty(u"combinedAndText", QCoreApplication.translate("TskAnalysisPanelForm", u"Modified Z Score AND Golden Deviation", None))
        self.sharedFailRulesLabel.setProperty(u"combinedOrText", QCoreApplication.translate("TskAnalysisPanelForm", u"Modified Z Score OR Golden Deviation", None))
        self.sharedFailRulesHintLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u7edf\u4e00\u4f7f\u7528 Analyze \u5f53\u524d\u7684 Fail \u5224\u636e\u3001\u9608\u503c\u548c\u5408\u5e76\u89c4\u5219\uff1b\u8bf7\u5728 Analyze \u4fee\u6539\u3002", None))
        self.missingPolicyLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6cbf\u7528 Analyze \u7684\u7a7a\u503c\u4e0e\u5408\u5e76\u89c4\u5219\uff1b\u5408\u5e76\u540e\u4ecd\u65e0\u6709\u6548\u5224\u5b9a\u7684\u6837\u54c1\u8bb0\u4e3a Missing\uff0c\u4e0d\u8ba1\u5165\u6709\u6548\u5206\u6bcd\u3002", None))
        self.featureModelLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u7279\u5f81\u6a21\u578b", None))
        self.featureModelValueLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"Logistic", None))
        self.featureModelHintLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u4f4d\u7f6e\u66f2\u9762\u4e0e\u5176\u4ed6\u7279\u5f81\u5171\u540c\u5f71\u54cd logit(p)\uff0c\u94fe\u7ea7\u62df\u5408\u4e0d\u4fdd\u8bc1\u51f8\u6027\u3002\u672a\u9009\u62e9\u7279\u5f81\u65f6\uff0c\u4f7f\u7528\u6bcf\u79cd TSK \u5171\u4eab\u5931\u6548\u6982\u7387\u7684\u57fa\u7840\u7c7b\u578b\u6a21\u578b\u3002", None))
        self.includeXYCheckBox.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u52a0\u5165 X / Y \u4f4d\u7f6e\u6821\u6b63", None))
        self.xyModelLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"XY \u7a7a\u95f4\u6a21\u578b", None))
        self.xyModelComboBox.setItemText(0, QCoreApplication.translate("TskAnalysisPanelForm", u"\u539f\u70b9\u5bf9\u79f0\u66f2\u9762\uff08\u9ed8\u8ba4\uff09", None))
        self.xyModelComboBox.setItemText(1, QCoreApplication.translate("TskAnalysisPanelForm", u"\u7ebf\u6027 X/Y\uff08\u65e7\u7248\uff09", None))

#if QT_CONFIG(tooltip)
        self.xyModelComboBox.setToolTip(QCoreApplication.translate("TskAnalysisPanelForm", u"\u539f\u70b9\u5bf9\u79f0\u66f2\u9762\u4f7f\u7528\u7269\u7406\u539f\u70b9\u6784\u9020 X\u00b2\u3001Y\u00b2\u3001X\u2074\u3001X\u00b2Y\u00b2\u3001Y\u2074\uff1b\u7ebf\u6027 X/Y \u4fdd\u7559\u65e7\u7248\u65b9\u5411\u8d8b\u52bf\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.xyModelHintLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u539f\u70b9\u5bf9\u79f0\u66f2\u9762\u53ef\u8868\u8fbe\u6301\u7eed\u5347\u9ad8\u6216\u5916\u56f4\u56de\u843d\uff1b\u4e0d\u5f3a\u5236\u4e2d\u5fc3\u6700\u4f4e\u3001\u5355\u5cf0\u6216\u692d\u5706\u5f62\uff0c\u4e5f\u4e0d\u8981\u6c42\u6570\u636e\u8303\u56f4\u5916\u7684\u5cf0\u503c\u53ef\u786e\u5b9a\u3002\u603b\u89c8\u53d6\u539f\u59cb X/Y \u5747\u503c\u5750\u6807\uff0cChain \u4f7f\u7528\u5b9e\u9645\u5750\u6807\u3002", None))
        self.featuresLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u989d\u5916\u7279\u5f81\uff08\u6570\u503c / \u7c7b\u522b\uff0c\u53ef\u9009\uff09", None))
#if QT_CONFIG(tooltip)
        self.featuresListWidget.setToolTip(QCoreApplication.translate("TskAnalysisPanelForm", u"\u7c7b\u578b\u7531\u6a21\u677f\u5b9a\u4e49\u3002bump \u5c3a\u5bf8\u53ef\u4f5c\u4e3a\u6570\u503c\uff0c\u6216\u5728 categorical_feature_columns \u4e2d\u58f0\u660e\u4e3a\u7c7b\u522b\uff1b\u7c7b\u522b\u81ea\u52a8\u7f16\u7801\uff0c\u4e0d\u5047\u5b9a\u5927\u5c0f\u6216\u7b49\u8ddd\u5173\u7cfb\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.featuresListWidget.setProperty(u"categoricalItemText", QCoreApplication.translate("TskAnalysisPanelForm", u"{name}\uff08\u7c7b\u522b\uff09", None))
        self.featuresListWidget.setProperty(u"categoricalHintText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u7c7b\u522b\u7279\u5f81\uff1a\u5206\u522b\u4f30\u8ba1\u5404\u7c7b\u522b\u76f8\u5bf9\u57fa\u51c6\u7c7b\u522b\u7684\u5f71\u54cd\uff0c\u4e0d\u6309\u6807\u7b7e\u7684\u6570\u503c\u5927\u5c0f\u62df\u5408\u8d8b\u52bf\u3002", None))
        self.featuresListWidget.setProperty(u"numericHintText", QCoreApplication.translate("TskAnalysisPanelForm", u"\u6570\u503c\u7279\u5f81\uff1a\u6309\u6570\u503c\u5927\u5c0f\u62df\u5408\u8fde\u7eed\u8d8b\u52bf\u3002\u5404\u5b9e\u4f8b\u987b\u4f7f\u7528\u540c\u4e00\u5355\u4f4d\u3002", None))
        self.logisticCoefficientBoundLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"Logistic \u7cfb\u6570\u7edd\u5bf9\u503c\u4e0a\u9650", None))
#if QT_CONFIG(tooltip)
        self.logisticCoefficientBoundSpinBox.setToolTip(QCoreApplication.translate("TskAnalysisPanelForm", u"\u4ec5\u7528\u4e8e\u542b\u7279\u5f81\u7684 Logistic\uff1a\u521d\u59cb\u62df\u5408\u9650\u5236\u5728 \u00b1 \u6b64\u503c\u5185\uff1b\u8fb9\u754c\u590d\u6838\u5141\u8bb8 TSK odds \u53d6 0\uff0c\u5171\u4eab\u7279\u5f81\u7cfb\u6570\u4ecd\u53d7\u9650\u3002\u589e\u5927\u4e0a\u9650\u4e0d\u4fdd\u8bc1\u53ef\u8bc6\u522b\u6027\u6216\u533a\u95f4\u53ef\u7528\uff0c\u9ed8\u8ba4 35\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.logisticCoefficientBoundHintLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u521d\u59cb Logistic \u62df\u5408\u9650\u5236\u5728 \u00b1 \u6b64\u503c\u5185\uff1b\u8fb9\u754c\u590d\u6838\u5141\u8bb8 TSK odds \u53d6 0\uff0c\u5171\u4eab\u7279\u5f81\u7cfb\u6570\u4ecd\u53d7\u9650\u3002", None))
        self.intervalLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u9ed8\u8ba4 95% \u533a\u95f4\uff1b\u96f6\u8fb9\u754c\u4f30\u8ba1\u663e\u793a\u53ef\u7528\u7684\u5355\u4fa7\u4e0a\u9650\uff0c\u8fd1\u4f3c\u65b9\u6cd5\u660e\u786e\u6807\u6ce8\u3002\u7c7b\u522b\u7ec4\u5408\u6309\u6240\u9009\u7c7b\u522b\u6bd4\u8f83\uff0cXY \u548c\u5176\u4ed6\u6570\u503c\u7279\u5f81\u56fa\u5b9a\u5728\u8bad\u7ec3\u5747\u503c\u3002\u96f6\u8fb9\u754c\u4f30\u8ba1\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002", None))
        self.featureEffectsModeLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u7279\u5f81\u5f71\u54cd\u68c0\u9a8c", None))
        self.featureEffectsModeComboBox.setItemText(0, QCoreApplication.translate("TskAnalysisPanelForm", u"\u56fa\u5b9a\u96f6\u6761\u4ef6\u5206\u6790", None))
        self.featureEffectsModeComboBox.setItemText(1, QCoreApplication.translate("TskAnalysisPanelForm", u"\u81ea\u7531\u8fb9\u754c\u6a21\u62df\u68c0\u9a8c\uff08\u5b9e\u9a8c\u6027\uff09", None))

        self.simulationReplicatesLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6a21\u62df\u6b21\u6570", None))
        self.simulationSeedLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u968f\u673a\u79cd\u5b50", None))
        self.simulationWorkersLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u6a21\u62df\u8fdb\u7a0b\u6570", None))
        self.simulationWorkersSpinBox.setSpecialValueText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u81ea\u52a8", None))
#if QT_CONFIG(tooltip)
        self.simulationWorkersSpinBox.setToolTip(QCoreApplication.translate("TskAnalysisPanelForm", u"0\uff1a\u81ea\u52a8\u9009\u62e9\uff08\u6700\u591a 8 \u4e2a\u8fdb\u7a0b\uff0c\u5e76\u4e3a\u754c\u9762\u4fdd\u7559\u4e00\u4e2a\u903b\u8f91\u6838\u5fc3\uff09\uff1b1\uff1a\u4e32\u884c\uff1b\u5176\u4ed6\u6570\u503c\uff1a\u6307\u5b9a\u8fdb\u7a0b\u6570\u3002\u76f8\u540c\u968f\u673a\u79cd\u5b50\u4e0b\uff0c\u5404\u8fdb\u7a0b\u6570\u4f7f\u7528\u76f8\u540c\u7684\u6a21\u62df\u6570\u636e\u3002\u66f4\u591a\u8fdb\u7a0b\u4f1a\u589e\u52a0\u5185\u5b58\u5360\u7528\uff0c\u5c11\u91cf\u6a21\u62df\u81ea\u52a8\u4f7f\u7528\u4e32\u884c\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.simulationHintLabel.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u5b9e\u9a8c\u6027\uff1a\u5141\u8bb8\u96f6\u98ce\u9669\u5728\u91cd\u62df\u5408\u4e2d\u8fdb\u5165\u6216\u9000\u51fa\u8fb9\u754c\uff0c\u4ec5\u5bf9\u7279\u5f81\u6574\u4f53\u68c0\u9a8c\u8ba1\u7b97\u6a21\u62df p\uff1b\u4e0d\u63d0\u4f9b\u5df2\u9a8c\u8bc1\u7684\u7cfb\u6570\u533a\u95f4\u6216\u6b63\u5f0f\u663e\u8457\u6027\u3002\u9ed8\u8ba4\u81ea\u52a8\u5e76\u884c\uff1b\u8fdb\u7a0b\u6570\u8bbe\u4e3a 1 \u4f7f\u7528\u4e32\u884c\u3002\u589e\u52a0\u6a21\u62df\u6b21\u6570\u4f1a\u589e\u52a0\u8fd0\u884c\u65f6\u95f4\uff0c\u53ef\u53d6\u6d88\u3002", None))
        self.runButton.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790", None))
        self.saveHtmlButton.setText(QCoreApplication.translate("TskAnalysisPanelForm", u"\u4fdd\u5b58\u7ed3\u679c\u4e3a HTML", None))
#if QT_CONFIG(tooltip)
        self.saveHtmlButton.setToolTip(QCoreApplication.translate("TskAnalysisPanelForm", u"\u5c06\u6240\u6709\u8282\u70b9\uff0f\u6279\u6b21\u7684\u5df2\u8ba1\u7b97 TSK \u7ed3\u679c\u4fdd\u5b58\u4e3a\u5355\u4e2a\u79bb\u7ebf HTML \u62a5\u544a\uff0c\u4fdd\u7559\u56fe\u8868\u3001\u7b5b\u9009\u548c\u660e\u7ec6\u3002\u8fd0\u884c\u5206\u6790\u6216\u6253\u5f00\u5df2\u6709\u7ed3\u679c\u540e\u53ef\u7528\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.saveHtmlButton.setProperty(u"dialogTitle", QCoreApplication.translate("TskAnalysisPanelForm", u"\u4fdd\u5b58 TSK \u7ed3\u679c\u4e3a HTML", None))
        self.saveHtmlButton.setProperty(u"fileFilter", QCoreApplication.translate("TskAnalysisPanelForm", u"HTML \u62a5\u544a (*.html)", None))
        self.saveHtmlButton.setProperty(u"defaultFilename", QCoreApplication.translate("TskAnalysisPanelForm", u"tsk_results.html", None))
        self.saveHtmlButton.setProperty(u"taskTitle", QCoreApplication.translate("TskAnalysisPanelForm", u"\u5bfc\u51fa TSK HTML \u62a5\u544a", None))
        self.saveHtmlButton.setProperty(u"savedFormat", QCoreApplication.translate("TskAnalysisPanelForm", u"TSK HTML \u62a5\u544a\u5df2\u4fdd\u5b58\uff1a{path}", None))
        pass
    # retranslateUi

