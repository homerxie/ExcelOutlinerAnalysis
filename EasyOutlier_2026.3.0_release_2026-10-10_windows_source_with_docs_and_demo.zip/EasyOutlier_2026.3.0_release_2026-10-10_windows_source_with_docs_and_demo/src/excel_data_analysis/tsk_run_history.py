"""Reusable TSK display results, identified by their actual analysis inputs.

File content hashes survive a database/workspace copy. A process-local metadata
cache avoids rereading large unchanged measurement files on each mode switch;
size, inode, device, mtime and ctime must all match before a hash is reused.
GUI state, exports and copied import files are deliberately not analysis inputs.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
from typing import Any

from .measurement_storage import COMPRESSED_MEASUREMENTS_FILENAME, LEGACY_MEASUREMENTS_FILENAME


HISTORY_VERSION = 1
_FILE_HASHES: dict[str, tuple[tuple[int, ...], str]] = {}
_SIMULATION_SETTINGS = {"simulation_replicates", "simulation_seed", "simulation_workers"}
_EXPORT_FIELDS = {"saved_analyses", "active_analysis_key"}


def empty_history() -> dict:
    return {"version": HISTORY_VERSION, "active_key": None, "entries": []}


def _json_value(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return _json_value(asdict(value))
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if isinstance(value, (set, frozenset)):
        return sorted((_json_value(item) for item in value), key=str)
    if isinstance(value, Path):
        return str(value)
    return value


def _digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(_json_value(value), sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def _file_digest(path: str | Path) -> str:
    source = Path(path)
    key = str(source.resolve())
    for _ in range(2):
        before = source.stat()
        identity = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
        cached = _FILE_HASHES.get(key)
        if cached is not None and cached[0] == identity:
            return cached[1]
        digest = hashlib.sha256()
        with source.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
        after = source.stat()
        if identity == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            fingerprint = digest.hexdigest()
            _FILE_HASHES[key] = (identity, fingerprint)
            return fingerprint
    raise OSError(f"TSK analysis input changed while reading: {source}")


def run_signature(request: dict) -> dict:
    """Identify an exact run and its shared-data context; never read fit outputs."""
    settings = deepcopy(request.get("settings") or {})
    for retired in ("group_by_dimensions", "fail_method", "classification_pool"):
        settings.pop(retired, None)
    mode = settings.get("feature_effects_mode", "fixed_zero")
    settings["feature_effects_mode"] = mode
    source = request.get("source", "database")
    if source == "input":
        path = request.get("input_path")
        if not path:
            raise ValueError("TSK input file is required")
        data = {"sha256": _file_digest(path), "suffix": Path(path).suffix.lower()}
    elif source == "database":
        if not request.get("storage_path"):
            raise ValueError("TSK database path is required")
        root = Path(request["storage_path"])
        path = root / COMPRESSED_MEASUREMENTS_FILENAME
        if not path.exists():
            path = root / LEGACY_MEASUREMENTS_FILENAME
        data = {"sha256": _file_digest(path), "format": path.name}
    else:
        raise ValueError(f"Unsupported TSK source: {source}")
    template = request.get("analysis_template")
    template_path = request.get("template_path")
    if template is None:
        from .template import load_template
        template = load_template(template_path)
    context_settings = {name: value for name, value in settings.items()
                        if name not in _SIMULATION_SETTINGS | {"feature_effects_mode"}}
    context = {"version": HISTORY_VERSION, "source": source, "data": data,
               "template": _json_value(template),
               "template_file": _file_digest(template_path) if template_path else None,
               "golden": _file_digest(request["golden_path"]) if request.get("golden_path") else None,
               "include_all_combinations": bool(request.get("include_all_combinations", False)),
               "settings": context_settings}
    context_key = _digest(context)
    run_settings = {"mode": mode}
    if mode == "boundary_simulation":
        run_settings.update(simulation_replicates=settings.get("simulation_replicates", 999),
                            simulation_seed=settings.get("simulation_seed", 1729))
    return {"key": _digest({"context_key": context_key, **run_settings}),
            "context_key": context_key, "mode": mode, "settings": _json_value(settings)}


def find_run(history: dict, key: str) -> dict | None:
    if not isinstance(history, dict):
        return None
    return next((entry for entry in history.get("entries", [])
                 if isinstance(entry, dict) and entry.get("key") == key
                 and isinstance(entry.get("result"), dict)), None)


def can_reuse_run(entry: dict | None) -> bool:
    """Incomplete simulations remain viewable, but a Run click must retry them."""
    if not isinstance(entry, dict) or not isinstance(entry.get("result"), dict):
        return False
    if entry.get("mode") != "boundary_simulation":
        return True
    groups = entry["result"].get("groups")
    if not isinstance(groups, list) or not groups:
        return False
    requested = (entry.get("settings") or {}).get("simulation_replicates", 999)
    for group in groups:
        report = group.get("feature_effects") if isinstance(group, dict) else None
        if not isinstance(report, dict):
            return False
        features = report.get("features")
        if report.get("status") == "no_features" and features == []:
            continue
        if report.get("status") != "simulation_experimental" or not isinstance(features, list) or not features:
            return False
        for feature in features:
            lrt = feature.get("lrt") if isinstance(feature, dict) else None
            if not isinstance(lrt, dict):
                return False
            if lrt.get("status") == "no_variation":
                continue
            simulation = lrt.get("simulation") or {}
            if (lrt.get("status") != "simulation_experimental"
                    or not isinstance(simulation, dict)
                    or simulation.get("replicates_requested") != requested
                    or simulation.get("replicates_completed") != requested
                    or simulation.get("replicates_failed") != 0
                    or simulation.get("stopped_early", False)
                    or simulation.get("replicates_unattempted", 0) != 0
                    or any(not isinstance(lrt.get(name), (int, float))
                           or isinstance(lrt[name], bool) or not math.isfinite(lrt[name])
                           for name in ("p_value", "p_adjusted"))):
                return False
    return True


def store_run(history: dict, signature: dict, result: dict) -> dict:
    """Retain live fit data in memory; persistence separately saves display data."""
    entry = {name: deepcopy(signature[name]) for name in ("key", "context_key", "mode", "settings")}
    entry.update(created_at=datetime.now(timezone.utc).isoformat(), result=result)
    history.update(version=HISTORY_VERSION, active_key=entry["key"],
                   entries=[item for item in history.get("entries", [])
                            if isinstance(item, dict) and item.get("key") != entry["key"]] + [entry])
    return entry


def _without_history(result: dict) -> dict:
    return {name: value for name, value in result.items() if name not in _EXPORT_FIELDS}


def export_payload(result: dict, history: dict) -> dict:
    """Attach only same-context saved runs, without recursive result histories."""
    active = find_run(history, history.get("active_key")) if isinstance(history, dict) else None
    if active is None:
        return _without_history(result) if _EXPORT_FIELDS.intersection(result) else result
    payload = _without_history(result)
    payload["active_analysis_key"] = active["key"]
    payload["saved_analyses"] = [
        {**{name: deepcopy(entry[name]) for name in ("key", "context_key", "mode", "settings", "created_at")},
         "result": _without_history(entry["result"])}
        for entry in history.get("entries", [])
        if isinstance(entry, dict) and entry.get("context_key") == active["context_key"]
        and isinstance(entry.get("result"), dict)]
    return payload


def encode_history(history: dict) -> dict:
    from .tsk_result_state import encode_tsk_result
    encoded = empty_history()
    if not isinstance(history, dict):
        return encoded
    for entry in history.get("entries", []):
        if not _valid_entry(entry):
            continue
        encoded["entries"].append({**{name: deepcopy(entry[name]) for name in
            ("key", "context_key", "mode", "settings", "created_at")},
            "result": encode_tsk_result(_without_history(entry["result"]))})
    keys = {entry["key"] for entry in encoded["entries"]}
    encoded["active_key"] = history.get("active_key") if history.get("active_key") in keys else None
    return encoded


def _valid_entry(entry: Any) -> bool:
    return (isinstance(entry, dict)
            and all(isinstance(entry.get(name), str) and entry[name]
                    for name in ("key", "context_key", "mode", "created_at"))
            and isinstance(entry.get("settings"), dict) and isinstance(entry.get("result"), dict))


def decode_history(value: Any) -> tuple[dict, list[str]]:
    """Isolate a broken cached entry so other saved runs remain accessible."""
    from .tsk_result_state import decode_tsk_result
    import zlib
    decoded, errors = empty_history(), []
    if not isinstance(value, dict) or value.get("version") != HISTORY_VERSION or not isinstance(value.get("entries"), list):
        return decoded, ["Invalid saved TSK history"]
    seen = set()
    for index, entry in enumerate(value["entries"]):
        try:
            if not _valid_entry(entry) or entry["key"] in seen:
                raise ValueError("Invalid or duplicate saved TSK history entry")
            result = decode_tsk_result(entry["result"])
            decoded["entries"].append({**{name: deepcopy(entry[name]) for name in
                ("key", "context_key", "mode", "settings", "created_at")}, "result": _without_history(result)})
            seen.add(entry["key"])
        except (ValueError, OSError, EOFError, KeyError, TypeError, zlib.error) as exc:
            errors.append(f"TSK history entry {index + 1}: {exc}")
    decoded["active_key"] = value.get("active_key") if value.get("active_key") in seen else None
    return decoded, errors
