"""Bounded process parallelism for independent TSK fits.

Only the parent reports progress. Layouts are sent once per worker, native
numeric libraries use one thread, and nested analyses share the outer budget.
"""
from concurrent.futures import ProcessPoolExecutor, TimeoutError
from concurrent.futures.process import BrokenProcessPool
import multiprocessing
from numbers import Integral
import os
import threading

from .compute_resources import limit_process_workers


_SPAWN_ENV_LOCK = threading.Lock()
_THREAD_ENV = ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS",
               "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS")
_IN_WORKER = False
_COMMON = None
_FUNCTION = None
_THREAD_LIMIT = None
_STARTUP_GATE = None


def in_parallel_worker():
    return _IN_WORKER


def validate_analysis_workers(workers):
    if isinstance(workers, bool) or not isinstance(workers, Integral) or not 0 <= workers <= 64:
        raise ValueError("analysis_workers must be an integer between 0 and 64 (0 means automatic).")
    return int(workers)


def worker_count(workers, task_count, min_parallel_items=2):
    workers = validate_analysis_workers(workers)
    if _IN_WORKER or task_count < 2:
        return 1
    if workers == 0:
        if task_count < min_parallel_items:
            return 1
        workers = min(8, max((os.cpu_count() or 1) - 1, 1))
    return limit_process_workers(min(workers, task_count, 61 if os.name == "nt" else 64))


def _initialize(function, common, prepare_common, gate):
    from threadpoolctl import threadpool_limits

    global _IN_WORKER, _COMMON, _FUNCTION, _THREAD_LIMIT, _STARTUP_GATE
    _IN_WORKER = True
    _FUNCTION, _STARTUP_GATE = function, gate
    _THREAD_LIMIT = threadpool_limits(limits=1)
    parent = multiprocessing.parent_process()
    if parent is not None:
        def parent_died():
            from multiprocessing.connection import wait
            wait([parent.sentinel])
            os._exit(0)
        threading.Thread(target=parent_died, name="tsk-parent-watch", daemon=True).start()
    _COMMON = prepare_common(common) if prepare_common is not None else common


def _ready():
    _STARTUP_GATE.wait()


def _run(item):
    return _FUNCTION(_COMMON, item, lambda: None)


def _shutdown(pool, *, terminate=False):
    if pool is None:
        return
    if not terminate:
        pool.shutdown(wait=True, cancel_futures=True)
        return
    # Python 3.10 lacks the public terminate_workers API.
    processes = list((getattr(pool, "_processes", None) or {}).values())
    for process in processes:
        if process.is_alive():
            process.terminate()
    pool.shutdown(wait=False, cancel_futures=True)
    for process in processes:
        process.join(timeout=.2)
        if process.is_alive():
            process.kill()
            process.join(timeout=.2)


def ordered_parallel_map(function, items, *, common=None, prepare_common=None, workers=0,
                         progress_callback=None, min_parallel_items=2, execution=None):
    """Map ``function(common, item, heartbeat)`` in input order.

    ``prepare_common`` builds worker-local reusable state once. The callback is
    called with (completed, total), including while waiting, and may cancel by
    raising. Infrastructure failures retry only unfinished items serially;
    computation exceptions propagate. Callers must provide side-effect-free jobs.
    """
    items = list(items)
    total = len(items)
    count = worker_count(workers, total, min_parallel_items)
    progress = progress_callback or (lambda *_: None)
    execution = execution if execution is not None else {}
    execution.update(workers_requested=int(workers), workers_used=count,
                     execution_backend="serial" if count == 1 else "spawn_process_pool",
                     execution_warnings=[])
    output = []
    local_common = None
    local_ready = False

    def serial_tail():
        nonlocal local_common, local_ready
        if not local_ready:
            local_common = prepare_common(common) if prepare_common is not None else common
            local_ready = True
        for item in items[len(output):]:
            heartbeat = lambda: progress(len(output), total)
            heartbeat()
            output.append(function(local_common, item, heartbeat))
            progress(len(output), total)
        return output

    if count == 1 or not items:
        return serial_tail()
    pool = None
    pending = {}
    try:
        try:
            with _SPAWN_ENV_LOCK:
                previous = {key: os.environ.get(key) for key in _THREAD_ENV}
                try:
                    os.environ.update({key: "1" for key in _THREAD_ENV})
                    spawn = multiprocessing.get_context("spawn")
                    gate = spawn.Event()
                    pool = ProcessPoolExecutor(max_workers=count, mp_context=spawn,
                        initializer=_initialize, initargs=(function, common, prepare_common, gate))
                    for _ in range(count):
                        pool.submit(_ready)
                    gate.set()
                finally:
                    for key, value in previous.items():
                        if value is None:
                            os.environ.pop(key, None)
                        else:
                            os.environ[key] = value
        except (OSError, RuntimeError) as error:
            _shutdown(pool, terminate=True)
            pool = None
            execution.update(workers_used=1, execution_backend="serial_after_process_failure")
            execution["execution_warnings"].append(f"TSK 子进程不可用，串行继续：{type(error).__name__}: {error}")
            return serial_tail()
        next_submit = 0
        for index in range(total):
            try:
                while next_submit < total and len(pending) < 2 * count:
                    pending[next_submit] = pool.submit(_run, items[next_submit])
                    next_submit += 1
                future = pending.pop(index)
                while True:
                    progress(len(output), total)
                    try:
                        result = future.result(timeout=.1)
                        break
                    except TimeoutError:
                        if future.done():
                            # It can complete between the timeout and this
                            # check. Read the result again to distinguish that
                            # race from a task's own TimeoutError.
                            result = future.result()
                            break
            except BrokenProcessPool as error:
                _shutdown(pool, terminate=True)
                pool = None
                execution.update(workers_used=1, execution_backend="serial_after_process_failure")
                execution["execution_warnings"].append(f"TSK 子进程中断，未完成项串行重算：{error}")
                return serial_tail()
            output.append(result)
            progress(len(output), total)
    except BaseException:
        _shutdown(pool, terminate=True)
        pool = None
        raise
    finally:
        _shutdown(pool)
    return output
