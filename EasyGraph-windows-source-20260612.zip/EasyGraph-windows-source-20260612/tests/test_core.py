import math
import pathlib
import sys
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import app


class EasyGraphCoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qapp = app.QApplication.instance() or app.QApplication([])

    def setUp(self):
        self.settings = app.ChartSettings()
        self.df = app.sample_data()

    def test_wide_table_is_converted_to_plot_data(self):
        clean = app.prepare_plot_data(self.df, self.settings)

        self.assertEqual(list(self.df.columns), ["Control", "Low dose", "High dose"])
        self.assertEqual(len(clean), 103)
        self.assertEqual(set(clean.columns), {"group", "value"})
        self.assertEqual(set(clean["group"]), {"Control", "Low dose", "High dose"})

    def test_outlier_detection_finds_sample_high_dose_outlier(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        outliers = app.mark_outliers(clean, self.settings)

        self.assertEqual(len(outliers), 1)
        self.assertEqual(outliers.iloc[0]["group"], "High dose")
        self.assertAlmostEqual(outliers.iloc[0]["value"], 8.7)

    def test_box_whisker_modes_map_to_matplotlib_whis_values(self):
        self.assertEqual(app.box_whis("Tukey 1.5 IQR"), 1.5)
        self.assertEqual(app.box_whis("Min-Max"), (0, 100))
        self.assertEqual(app.box_whis("Percentile 5-95"), (5, 95))
        self.assertEqual(app.box_whis("Percentile 10-90"), (10, 90))

    def test_default_jitter_mode_is_quasirandom(self):
        self.assertEqual(app.ChartSettings().jitter_mode, "Quasirandom")

    def test_apply_app_theme_uses_pyqtdarktheme_stylesheet(self):
        original_qdarktheme = app.qdarktheme

        class FakeDarkTheme:
            @staticmethod
            def load_stylesheet():
                return "QWidget { background: #111111; }"

        try:
            app.qdarktheme = FakeDarkTheme()
            self.assertTrue(app.apply_app_theme(self.qapp))
            self.assertIn("#111111", self.qapp.styleSheet())
            self.assertIn("QComboBox QAbstractItemView", self.qapp.styleSheet())
            self.assertIn("QSpinBox", self.qapp.styleSheet())
            self.assertIn("QPushButton", self.qapp.styleSheet())
            self.assertIn("border-radius: 6px", self.qapp.styleSheet())
        finally:
            self.qapp.setStyleSheet("")
            app.qdarktheme = original_qdarktheme

    def test_combo_boxes_expand_for_long_options(self):
        window = app.MainWindow()
        longest = "Exclude from distribution"
        expected_width = window.outlier_effect.fontMetrics().horizontalAdvance(longest) + app.COMBO_TEXT_WIDTH_PADDING

        self.assertEqual(window.template_combo.sizePolicy().horizontalPolicy(), app.QSizePolicy.Expanding)
        self.assertEqual(window.outlier_effect.minimumWidth(), window.outlier_effect.maximumWidth())
        self.assertGreaterEqual(window.outlier_effect.minimumWidth(), expected_width)
        self.assertGreaterEqual(window.outlier_effect.view().minimumWidth(), expected_width)

    def test_settings_forms_align_labels_left_and_values_right(self):
        window = app.MainWindow()
        longest = "Exclude from distribution"
        expected_width = window.outlier_effect.fontMetrics().horizontalAdvance(longest) + app.COMBO_TEXT_WIDTH_PADDING
        expected_width = min(max(expected_width, app.COMBO_MIN_WIDTH), 280)
        field_layout = window.ui.outlierForm.itemAt(3, app.QFormLayout.FieldRole).layout()
        margins = window.ui.outlierForm.contentsMargins()

        self.assertEqual(window.outlier_effect.width(), expected_width)
        self.assertEqual(margins.left(), 8)
        self.assertEqual(margins.right(), 8)
        self.assertEqual(window.ui.outlierForm.fieldGrowthPolicy(), app.QFormLayout.AllNonFixedFieldsGrow)
        self.assertEqual(field_layout.itemAt(1).widget(), window.outlier_effect)
        self.assertIsNone(field_layout.itemAt(0).widget())

    def test_legend_layout_has_own_group_with_right_aligned_controls(self):
        window = app.MainWindow()

        all_sizes_field = window.ui.fontForm.itemAt(0, app.QFormLayout.FieldRole).layout()
        self.assertEqual(window.legend_group.title(), "Legend")
        self.assertEqual(window.show_legend.parent(), window.legend_group)
        self.assertEqual(window.legend_width.parent(), window.legend_group)
        self.assertEqual(window.legend_columns.parent(), window.legend_group)
        self.assertEqual(window.legend_font_size.parent(), window.ui.fontGroup)
        self.assertTrue(window.show_legend.isChecked())
        self.assertTrue(window.settings.show_legend)
        self.assertEqual(window.ui.allFontSizesLabel.text(), "All sizes")
        self.assertEqual(all_sizes_field.itemAt(1).widget(), window.decrease_all_fonts_button)
        self.assertEqual(all_sizes_field.itemAt(2).widget(), window.increase_all_fonts_button)
        self.assertEqual(all_sizes_field.spacing(), 6)
        self.assertEqual(window.legend_form.fieldGrowthPolicy(), app.QFormLayout.AllNonFixedFieldsGrow)
        self.assertEqual(window.legend_form.contentsMargins().left(), 8)
        self.assertEqual(window.legend_form.contentsMargins().right(), 8)
        show_field = window.legend_form.itemAt(0, app.QFormLayout.FieldRole).layout()
        width_field = window.legend_form.itemAt(1, app.QFormLayout.FieldRole).layout()
        columns_field = window.legend_form.itemAt(2, app.QFormLayout.FieldRole).layout()
        font_field = window.ui.fontForm.itemAt(window.ui.fontForm.rowCount() - 1, app.QFormLayout.FieldRole).layout()

        self.assertEqual(show_field.itemAt(1).widget(), window.show_legend)
        self.assertEqual(width_field.itemAt(1).widget(), window.legend_width)
        self.assertEqual(columns_field.itemAt(1).widget(), window.legend_columns)
        self.assertEqual(font_field.itemAt(1).widget(), window.legend_font_size)

        window.show_legend.setChecked(False)
        window.update_settings()

        self.assertFalse(window.settings.show_legend)
        self.assertFalse(window.legend_width.isEnabled())
        self.assertFalse(window.legend_columns.isEnabled())
        self.assertFalse(window.legend_font_size.isEnabled())

    def test_adjust_all_font_sizes_uses_office_like_steps(self):
        window = app.MainWindow()
        window.title_font_size.setValue(16)
        window.axis_label_font_size.setValue(12)
        window.tick_font_size.setValue(10)
        window.legend_font_size.setValue(10)
        window.line_value_font_size.setValue(9)
        window.stat_table_font_size.setValue(9)

        with mock.patch.object(window, "render"):
            window.increase_all_fonts_button.click()

        self.assertEqual(window.title_font_size.value(), 18)
        self.assertEqual(window.axis_label_font_size.value(), 14)
        self.assertEqual(window.tick_font_size.value(), 11)
        self.assertEqual(window.legend_font_size.value(), 11)
        self.assertEqual(window.line_value_font_size.value(), 10)
        self.assertEqual(window.stat_table_font_size.value(), 10)
        self.assertEqual(window.settings.title_font_size, 18)
        self.assertEqual(window.settings.axis_label_font_size, 14)
        self.assertEqual(window.settings.tick_font_size, 11)
        self.assertEqual(window.settings.legend_font_size, 11)
        self.assertEqual(window.settings.line_value_font_size, 10)
        self.assertEqual(window.settings.stat_table_font_size, 10)

        with mock.patch.object(window, "render"):
            window.decrease_all_fonts_button.click()

        self.assertEqual(window.title_font_size.value(), 16)
        self.assertEqual(window.axis_label_font_size.value(), 12)
        self.assertEqual(window.tick_font_size.value(), 10)
        self.assertEqual(window.legend_font_size.value(), 10)
        self.assertEqual(window.line_value_font_size.value(), 9)
        self.assertEqual(window.stat_table_font_size.value(), 9)

    def test_adjust_all_font_sizes_updates_disabled_module_fonts(self):
        window = app.MainWindow()
        window.show_legend.setChecked(False)
        window.show_stat_table.setChecked(False)
        window.line_overlay_stat.setCurrentText("Median")
        window.show_line_values.setChecked(False)
        window.update_settings()

        self.assertFalse(window.legend_font_size.isEnabled())
        self.assertFalse(window.stat_table_font_size.isEnabled())
        self.assertFalse(window.line_value_font_size.isEnabled())

        with mock.patch.object(window, "render"):
            window.increase_all_fonts_button.click()

        self.assertEqual(window.legend_font_size.value(), 11)
        self.assertEqual(window.stat_table_font_size.value(), 10)
        self.assertEqual(window.line_value_font_size.value(), 10)
        self.assertEqual(window.settings.legend_font_size, 11)
        self.assertEqual(window.settings.stat_table_font_size, 10)
        self.assertEqual(window.settings.line_value_font_size, 10)

    def test_right_sidebar_minimum_width_preserves_settings_rows(self):
        window = app.MainWindow()

        self.assertGreaterEqual(window.ui.controlsScroll.minimumWidth(), 420)
        self.assertGreaterEqual(window.ui.controlsContent.minimumWidth(), 400)

    def test_single_line_controls_use_matching_heights(self):
        window = app.MainWindow()

        for widget in [
            window.outlier_effect,
            window.outlier_threshold,
            window.width,
            window.line_overlay_stat,
            window.line_overlay_style,
            window.line_overlay_width,
            window.line_overlay_point_size,
            window.line_value_position,
            window.line_value_decimals,
            window.line_value_font_size,
            window.stat_table_font_size,
            window.edit_group_colors_button,
            window.ui.addColumnButton,
            window.ui.deleteColumnButton,
            window.ui.loadTemplateButton,
            window.ui.copyImageButton,
        ]:
            with self.subTest(widget=widget.objectName()):
                self.assertEqual(widget.minimumHeight(), app.APP_CONTROL_HEIGHT)
                self.assertEqual(widget.maximumHeight(), app.APP_CONTROL_HEIGHT)

    def test_settings_spinboxes_commit_keyboard_input_on_enter_or_focus_out(self):
        window = app.MainWindow()

        for spin_box in window._spin_boxes():
            with self.subTest(spin_box=spin_box.objectName()):
                self.assertFalse(spin_box.keyboardTracking())

    def test_group_color_button_sits_with_preset_controls(self):
        window = app.MainWindow()

        def layout_widgets(layout):
            return [
                item.widget()
                for index in range(layout.count())
                if (item := layout.itemAt(index)) is not None and item.widget() is not None
            ]

        self.assertIn(window.edit_group_colors_button, layout_widgets(window.ui.presetComboFieldLayout))
        self.assertNotIn(window.edit_group_colors_button, layout_widgets(window.ui.groupOrderLayout))
        self.assertEqual(window.ui.presetComboFieldLayout.spacing(), 6)

    def test_group_filter_button_is_defined_in_chart_group(self):
        window = app.MainWindow()

        self.assertIs(window.group_filter_button, window.ui.groupFilterButton)
        self.assertEqual(window.group_filter_button.parent(), window.ui.chartGroup)

    def test_plot_canvas_has_zoom_to_fit_button(self):
        window = app.MainWindow()

        button = window.canvas.findChild(app.QPushButton, "zoomToFitButton")

        self.assertIsNotNone(button)
        self.assertEqual(button.text(), "Fit")

    def test_title_and_axis_label_edits_debounce_render(self):
        window = app.MainWindow()

        with mock.patch.object(window.canvas, "render") as render, mock.patch.object(window.canvas.canvas, "draw_idle") as draw_idle:
            window.title.setPlainText("First title")
            window.title.setPlainText("Final title")

            self.assertEqual(window.settings.title, "Final title")
            self.assertTrue(window._render_timer.isActive())
            render.assert_not_called()

            window.flush_pending_render()

        render.assert_not_called()
        draw_idle.assert_called_once()
        self.assertEqual(window.canvas.figure.axes[0].get_title(), "Final title")

    def test_secondary_axis_title_edits_debounce_render_with_stat_table(self):
        window = app.MainWindow()
        window.add_custom_overlay_row()
        window.custom_overlay_secondary_axis.setChecked(True)
        for col in range(window.table.columnCount()):
            window.table.setItem(1, col, app.QTableWidgetItem(str(50 + col * 10)))
        window.update_settings()

        with mock.patch.object(window.canvas, "render") as render, mock.patch.object(window.canvas.canvas, "draw_idle") as draw_idle:
            window.secondary_y_label.setPlainText("Secondary Axis")
            self.assertEqual(window.settings.secondary_y_label, "Secondary Axis")
            self.assertTrue(window._render_timer.isActive())
            render.assert_not_called()

            window.flush_pending_render()

        render.assert_not_called()
        draw_idle.assert_called_once()
        secondary_ax = next(axis for axis in window.canvas.figure.axes if axis.get_gid() == "secondary-axis")
        self.assertEqual(secondary_ax.yaxis.label.get_text(), "Secondary Axis")

    def test_multiline_secondary_axis_title_uses_full_render_for_layout_width(self):
        window = app.MainWindow()
        window.add_custom_overlay_row()
        window.custom_overlay_secondary_axis.setChecked(True)
        for col in range(window.table.columnCount()):
            window.table.setItem(1, col, app.QTableWidgetItem(str(50 + col * 10)))
        window.update_settings()
        initial_width = window.canvas.canvas.width()

        with mock.patch.object(window.canvas.canvas, "draw_idle") as draw_idle:
            window.secondary_y_label.setPlainText("Secondary\nAxis\nTitle")
            window.flush_pending_render()

        draw_idle.assert_not_called()
        self.assertGreater(window.canvas.canvas.width(), initial_width)
        secondary_ax = next(axis for axis in window.canvas.figure.axes if axis.get_gid() == "secondary-axis")
        self.assertEqual(secondary_ax.yaxis.label.get_text(), "Secondary\nAxis\nTitle")

    def test_text_only_render_falls_back_without_axes(self):
        window = app.MainWindow()
        window.title.setPlainText("Fallback title")
        window.canvas.figure.clf()

        with mock.patch.object(window.canvas, "render") as render:
            window.flush_pending_render()

        render.assert_called_once()

    def test_multiline_title_edit_uses_full_render_for_layout_height(self):
        window = app.MainWindow()
        initial_height = window.canvas.canvas.height()

        with mock.patch.object(window.canvas.canvas, "draw_idle") as draw_idle:
            window.title.setPlainText("Line 1\nLine 2\nLine 3")
            window.flush_pending_render()

        draw_idle.assert_not_called()
        self.assertGreater(window.canvas.canvas.height(), initial_height)
        self.assertEqual(window.canvas.figure.axes[0].get_title(), "Line 1\nLine 2\nLine 3")

    def test_full_render_overrides_pending_text_only_render(self):
        window = app.MainWindow()

        with mock.patch.object(window.canvas, "render") as render:
            window.title.setPlainText("Pending title")
            self.assertTrue(window._render_timer.isActive())

            window.chart_type.setCurrentText("Ridge")

        self.assertFalse(window._render_pending)
        self.assertFalse(window._render_timer.isActive())
        render.assert_called_once()

    def test_trackpad_gesture_zoom_is_disabled(self):
        window = app.MainWindow()

        self.assertFalse(hasattr(window.canvas, "handle_zoom_event"))

    def test_user_preset_change_clears_custom_group_colors(self):
        window = app.MainWindow()
        window.settings.custom_colors = {"Control": "#446688"}
        window.settings.custom_overlay_colors = {"custom:0": "#884466"}

        window.preset.setCurrentText("Presentation")

        self.assertEqual(window.settings.preset, "Presentation")
        self.assertEqual(window.settings.custom_colors, {})
        self.assertEqual(window.settings.custom_overlay_colors, {})

    def test_apply_settings_keeps_loaded_custom_group_colors(self):
        window = app.MainWindow()
        window.settings.preset = "Presentation"
        window.settings.custom_colors = {"Control": "#446688"}

        window.apply_settings_to_controls()

        self.assertEqual(window.preset.currentText(), "Presentation")
        self.assertEqual(window.settings.custom_colors, {"Control": "#446688"})

    def test_apply_settings_does_not_overwrite_loaded_spinbox_values(self):
        window = app.MainWindow()
        window.x_tick_rotation.setValue(0)
        window.settings.x_tick_rotation = 65
        window.settings.line_overlay_width = 2.7
        window.settings.point_size = 6.5

        window.apply_settings_to_controls()

        self.assertEqual(window.x_tick_rotation.value(), 65)
        self.assertEqual(window.settings.x_tick_rotation, 65)
        self.assertAlmostEqual(window.line_overlay_width.value(), 2.7)
        self.assertAlmostEqual(window.settings.line_overlay_width, 2.7)
        self.assertAlmostEqual(window.point_size.value(), 6.5)
        self.assertAlmostEqual(window.settings.point_size, 6.5)

    def test_auto_y_range_disables_and_syncs_y_limit_controls(self):
        window = app.MainWindow()
        window.auto_y_range.setChecked(True)
        window.update_settings()
        y_min, y_max = window.canvas.figure.axes[0].get_ylim()

        self.assertFalse(window.y_min.isEnabled())
        self.assertFalse(window.y_max.isEnabled())
        self.assertFalse(window.ui.yMinLabel.isEnabled())
        self.assertFalse(window.ui.yMaxLabel.isEnabled())
        self.assertAlmostEqual(window.y_min.value(), y_min, places=2)
        self.assertAlmostEqual(window.y_max.value(), y_max, places=2)
        self.assertAlmostEqual(window.settings.y_min, y_min)
        self.assertAlmostEqual(window.settings.y_max, y_max)

        window.auto_y_range.setChecked(False)
        window.update_settings()

        self.assertTrue(window.y_min.isEnabled())
        self.assertTrue(window.y_max.isEnabled())
        self.assertTrue(window.ui.yMinLabel.isEnabled())
        self.assertTrue(window.ui.yMaxLabel.isEnabled())

    def test_ridge_auto_range_controls_sync_x_axis(self):
        window = app.MainWindow()
        window.chart_type.setCurrentText("Ridge")
        window.auto_y_range.setChecked(True)
        window.update_settings()
        x_min, x_max = window.canvas.figure.axes[0].get_xlim()

        self.assertEqual(window.ui.autoYLabel.text(), "Auto Primary X Range")
        self.assertEqual(window.ui.yMinLabel.text(), "Primary X min")
        self.assertEqual(window.ui.yMaxLabel.text(), "Primary X max")
        self.assertFalse(window.y_min.isEnabled())
        self.assertFalse(window.y_max.isEnabled())
        self.assertAlmostEqual(window.y_min.value(), x_min, places=2)
        self.assertAlmostEqual(window.y_max.value(), x_max, places=2)
        self.assertAlmostEqual(window.settings.y_min, x_min)
        self.assertAlmostEqual(window.settings.y_max, x_max)

    def test_auto_y_range_spinboxes_match_final_overlay_expanded_axis(self):
        window = app.MainWindow()
        window.line_overlay_stat.setCurrentText("Median")
        window.add_custom_overlay_row()
        for column, value in enumerate(["10", "1", "2"]):
            item = window.table.item(1, column)
            self.assertIsNotNone(item)
            item.setText(value)
        window.show_line_values.setChecked(True)
        window.line_value_position.setCurrentText("Bottom axis")
        window.custom_line_value_position.setCurrentText("Below")
        window.auto_y_range.setChecked(True)
        window.update_settings()

        y_min, y_max = window.canvas.figure.axes[0].get_ylim()

        self.assertLess(y_min, 0.0)
        self.assertEqual(window.y_min.value(), y_min)
        self.assertEqual(window.y_max.value(), y_max)
        self.assertEqual(window.settings.y_min, y_min)
        self.assertEqual(window.settings.y_max, y_max)

    def test_auto_y_range_spinboxes_match_axis_overlay_label_positions(self):
        base_window = app.MainWindow()
        base_window.line_overlay_stat.setCurrentText("Median")
        base_window.show_line_values.setChecked(True)
        base_window.line_value_position.setCurrentText("Above")
        base_window.auto_y_range.setChecked(True)
        base_window.update_settings()
        base_y_min, base_y_max = base_window.canvas.figure.axes[0].get_ylim()

        for position in ("Top axis", "Bottom axis"):
            with self.subTest(position=position):
                window = app.MainWindow()
                window.line_overlay_stat.setCurrentText("Median")
                window.show_line_values.setChecked(True)
                window.line_value_position.setCurrentText(position)
                window.auto_y_range.setChecked(True)
                window.update_settings()
                y_min, y_max = window.canvas.figure.axes[0].get_ylim()

                self.assertEqual(window.y_min.value(), y_min)
                self.assertEqual(window.y_max.value(), y_max)
                self.assertEqual(window.settings.y_min, y_min)
                self.assertEqual(window.settings.y_max, y_max)
                if position == "Top axis":
                    self.assertEqual(y_min, base_y_min)
                    self.assertGreaterEqual(y_max, base_y_max)
                else:
                    self.assertLessEqual(y_min, base_y_min)
                    self.assertEqual(y_max, base_y_max)

    def test_switching_auto_y_to_manual_keeps_synced_axis_range(self):
        window = app.MainWindow()
        window.line_overlay_stat.setCurrentText("Median")
        window.add_custom_overlay_row()
        for column, value in enumerate(["1", "2", "10"]):
            item = window.table.item(1, column)
            self.assertIsNotNone(item)
            item.setText(value)
        window.show_line_values.setChecked(True)
        window.line_value_position.setCurrentText("Bottom axis")
        window.custom_line_value_position.setCurrentText("Auto")
        window.auto_y_range.setChecked(True)
        window.update_settings()
        synced_range = (window.y_min.value(), window.y_max.value())

        window.auto_y_range.setChecked(False)

        self.assertEqual(window.canvas.figure.axes[0].get_ylim(), synced_range)
        self.assertEqual((window.settings.y_min, window.settings.y_max), synced_range)

    def test_line_overlay_style_controls_disable_when_no_overlay_is_active(self):
        window = app.MainWindow()
        controlled_widgets = [
            window.ui.lineOverlayWidthLabel,
            window.line_overlay_width,
            window.ui.lineOverlayStyleLabel,
            window.line_overlay_style,
            window.ui.lineOverlayPointSizeLabel,
            window.line_overlay_point_size,
            window.ui.showLineValuesLabel,
            window.show_line_values,
            window.ui.lineValueScientificLabel,
            window.line_value_scientific,
            window.ui.lineValueDecimalsLabel,
            window.line_value_decimals,
        ]
        line_value_size_widgets = [window.ui.lineValueSizeLabel, window.line_value_font_size]

        window.line_overlay_stat.setCurrentText("None")
        window.extra_custom_overlay.setChecked(False)
        window.update_settings()

        self.assertTrue(window.line_overlay_stat.isEnabled())
        self.assertTrue(all(not widget.isEnabled() for widget in controlled_widgets))
        self.assertTrue(all(not widget.isEnabled() for widget in line_value_size_widgets))
        self.assertFalse(window.ui.lineValuePositionLabel.isEnabled())
        self.assertFalse(window.line_value_position.isEnabled())
        self.assertFalse(window.ui.customLineValuePositionLabel.isEnabled())
        self.assertFalse(window.custom_line_value_position.isEnabled())

        window.line_overlay_stat.setCurrentText("Median")
        window.update_settings()

        self.assertTrue(all(widget.isEnabled() for widget in controlled_widgets))
        self.assertTrue(all(not widget.isEnabled() for widget in line_value_size_widgets))
        self.assertTrue(window.ui.lineValuePositionLabel.isEnabled())
        self.assertTrue(window.line_value_position.isEnabled())
        self.assertFalse(window.ui.customLineValuePositionLabel.isEnabled())
        self.assertFalse(window.custom_line_value_position.isEnabled())

        window.show_line_values.setChecked(True)
        window.update_settings()

        self.assertTrue(all(widget.isEnabled() for widget in line_value_size_widgets))

        window.line_overlay_stat.setCurrentText("None")
        window.add_custom_overlay_row()
        window.extra_custom_overlay.setChecked(True)
        window.update_settings()

        self.assertFalse(window.ui.lineValuePositionLabel.isEnabled())
        self.assertFalse(window.line_value_position.isEnabled())
        self.assertTrue(window.ui.customLineValuePositionLabel.isEnabled())
        self.assertTrue(window.custom_line_value_position.isEnabled())

    def test_overlay_label_position_controls_are_split_by_series_type(self):
        window = app.MainWindow()

        stat_options = [window.line_value_position.itemText(index) for index in range(window.line_value_position.count())]
        extra_options = [
            window.custom_line_value_position.itemText(index)
            for index in range(window.custom_line_value_position.count())
        ]

        self.assertIn("Top axis", stat_options)
        self.assertIn("Bottom axis", stat_options)
        self.assertNotIn("Top axis", extra_options)
        self.assertNotIn("Bottom axis", extra_options)
        self.assertNotIn("Axis left", extra_options)
        self.assertNotIn("Axis right", extra_options)

        window.chart_type.setCurrentText("Ridge")
        stat_options = [window.line_value_position.itemText(index) for index in range(window.line_value_position.count())]

        self.assertIn("Axis left", stat_options)
        self.assertIn("Axis right", stat_options)
        self.assertNotIn("Top axis", stat_options)
        self.assertNotIn("Bottom axis", stat_options)

    def test_group_and_value_labels_map_by_chart_type(self):
        settings = app.ChartSettings(x_label="Group label", y_label="Value label")

        settings.chart_type = "Box"
        self.assertEqual(app.axis_labels_for_chart(settings), ("Group label", "Value label"))

        settings.chart_type = "Violin"
        self.assertEqual(app.axis_labels_for_chart(settings), ("Group label", "Value label"))

        settings.chart_type = "Ridge"
        self.assertEqual(app.axis_labels_for_chart(settings), ("Value label", "Group label"))

    def test_axis_title_controls_use_logical_names(self):
        window = app.MainWindow()

        self.assertEqual(window.ui.xLabelLabel.text(), "Group axis title")
        self.assertEqual(" ".join(window.ui.yLabelLabel.text().split()), "Primary value axis title")
        self.assertEqual(" ".join(window.secondary_y_label_label.text().split()), "Secondary value axis title")
        window.secondary_y_label.setPlainText("Rate\nIndex")
        self.assertEqual(window.secondary_y_label.toPlainText(), "Rate\nIndex")

    def test_custom_overlay_secondary_axis_control_toggles_secondary_range_controls(self):
        window = app.MainWindow()

        self.assertEqual(window.custom_overlay_secondary_axis_label.text(), "叠加线使用次坐标轴")
        self.assertEqual(window.custom_overlay_secondary_axis_label.parent(), window.ui.axisGroup)
        self.assertEqual(window.custom_overlay_secondary_axis.parent(), window.ui.axisGroup)
        self.assertFalse(window.custom_overlay_secondary_axis_label.isEnabled())
        self.assertFalse(window.custom_overlay_secondary_axis.isEnabled())
        self.assertFalse(window.secondary_auto_y_range.isEnabled())
        self.assertFalse(window.secondary_y_min.isEnabled())
        self.assertFalse(window.secondary_y_max.isEnabled())
        self.assertFalse(window.secondary_auto_tick_interval.isEnabled())
        self.assertFalse(window.secondary_tick_interval.isEnabled())
        self.assertFalse(window.split_secondary_axis.isEnabled())
        self.assertFalse(window.secondary_axis_split_ratio.isEnabled())

        window.custom_overlay_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertFalse(window.custom_overlay_secondary_axis.isChecked())
        self.assertFalse(window.settings.custom_overlay_secondary_axis)

        window.add_custom_overlay_row()

        self.assertTrue(window.custom_overlay_secondary_axis_label.isEnabled())
        self.assertTrue(window.custom_overlay_secondary_axis.isEnabled())

        window.custom_overlay_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.settings.custom_overlay_secondary_axis)
        self.assertTrue(window.secondary_auto_y_range.isEnabled())
        self.assertFalse(window.secondary_y_min.isEnabled())
        self.assertFalse(window.secondary_y_max.isEnabled())
        self.assertTrue(window.secondary_auto_tick_interval.isEnabled())
        self.assertFalse(window.secondary_tick_interval.isEnabled())
        self.assertTrue(window.split_secondary_axis.isEnabled())
        self.assertFalse(window.secondary_axis_split_ratio.isEnabled())

        window.split_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.secondary_axis_split_ratio.isEnabled())

        window.secondary_auto_y_range.setChecked(False)
        window.update_settings()

        self.assertTrue(window.secondary_y_min.isEnabled())
        self.assertTrue(window.secondary_y_max.isEnabled())

        window.secondary_auto_tick_interval.setChecked(False)
        window.update_settings()

        self.assertTrue(window.secondary_tick_interval.isEnabled())

        window.extra_custom_overlay.setChecked(False)
        window.update_settings()

        self.assertFalse(window.custom_overlay_secondary_axis.isChecked())
        self.assertFalse(window.settings.custom_overlay_secondary_axis)
        self.assertFalse(window.custom_overlay_secondary_axis.isEnabled())
        self.assertFalse(window.secondary_auto_y_range.isEnabled())

    def test_value_axis_tick_interval_labels_follow_chart_type(self):
        window = app.MainWindow()

        self.assertEqual(window.ui.autoYLabel.text(), "Auto Primary Y Range")
        self.assertEqual(window.primary_tick_interval_label.text(), "Primary Y tick interval")
        self.assertEqual(window.secondary_auto_y_range_label.text(), "Auto Secondary Y Range")
        self.assertEqual(window.secondary_y_min_label.text(), "Secondary Y min")
        self.assertEqual(window.secondary_y_max_label.text(), "Secondary Y max")
        self.assertEqual(window.secondary_tick_interval_label.text(), "Secondary Y tick interval")

        window.chart_type.setCurrentText("Ridge")
        window.update_settings()

        self.assertEqual(window.ui.autoYLabel.text(), "Auto Primary X Range")
        self.assertEqual(window.primary_tick_interval_label.text(), "Primary X tick interval")
        self.assertEqual(window.secondary_auto_y_range_label.text(), "Auto Secondary X Range")
        self.assertEqual(window.secondary_y_min_label.text(), "Secondary X min")
        self.assertEqual(window.secondary_y_max_label.text(), "Secondary X max")
        self.assertEqual(window.secondary_tick_interval_label.text(), "Secondary X tick interval")

    def test_ridge_secondary_x_axis_controls_support_split_frame(self):
        window = app.MainWindow()
        window.add_custom_overlay_row()
        window.chart_type.setCurrentText("Ridge")
        window.custom_overlay_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.secondary_auto_y_range.isEnabled())
        self.assertEqual(window.secondary_auto_y_range_label.text(), "Auto Secondary X Range")
        self.assertEqual(window.secondary_y_min_label.text(), "Secondary X min")
        self.assertEqual(window.secondary_y_max_label.text(), "Secondary X max")
        self.assertTrue(window.split_secondary_axis.isEnabled())

        window.split_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.settings.split_secondary_axis)
        self.assertTrue(window.secondary_axis_split_ratio.isEnabled())

    def test_secondary_frame_ratio_changes_render_immediately(self):
        window = app.MainWindow()
        window.add_custom_overlay_row()
        window.custom_overlay_secondary_axis.setChecked(True)
        window.split_secondary_axis.setChecked(True)
        window.update_settings()

        with mock.patch.object(window, "render") as render:
            window.secondary_axis_split_ratio.setValue(0.45)

        render.assert_called()
        self.assertEqual(window.settings.secondary_axis_split_ratio, 0.45)

    def test_group_order_controls_plot_order(self):
        df = app.pd.DataFrame({
            "B": [3, 4],
            "A": [1, 2],
            "C": [5, 6],
        })

        settings = app.ChartSettings(group_order="Table order")
        clean = app.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["B", "A", "C"])

        settings.group_order = "Name A-Z"
        clean = app.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["A", "B", "C"])

        settings.group_order = "Mean descending"
        clean = app.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["C", "B", "A"])

        settings.group_order = "Manual"
        settings.manual_group_order = ["B", "C", "A"]
        clean = app.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["B", "C", "A"])

    def test_group_filter_hides_groups_from_plot_data_without_deleting_table_data(self):
        df = app.pd.DataFrame({
            "B": [3, 4],
            "A": [1, 2],
            "C": [5, 6],
        })
        settings = app.ChartSettings(group_hidden=["A"])

        clean = app.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["B", "C"])

        full_clean = app.prepare_plot_data(df, settings, include_hidden=True)
        self.assertEqual(list(full_clean["group"].drop_duplicates()), ["B", "A", "C"])

    def test_hidden_group_color_still_occupies_palette_color(self):
        df = app.pd.DataFrame({
            "A": [1, 2],
            "B": [3, 4],
        })
        settings = app.ChartSettings(group_hidden=["A"])
        full_clean = app.prepare_plot_data(df, settings, include_hidden=True)
        clean = app.prepare_plot_data(df, settings)
        all_groups = list(full_clean["group"].drop_duplicates())

        full_palette = app.palette_for(full_clean, settings, color_groups=all_groups)
        visible_palette = app.palette_for(clean, settings, color_groups=all_groups)

        self.assertEqual(visible_palette, [full_palette[1]])

    def test_line_overlay_statistics_use_mean_or_median(self):
        df = app.pd.DataFrame({
            "group": ["A", "A", "A", "B", "B"],
            "value": [1, 2, 100, 4, 8],
        })
        settings = app.ChartSettings(line_overlay_stat="Median")

        self.assertEqual(app.group_overlay_statistics(df, settings), [("A", 2.0), ("B", 6.0)])

        settings.line_overlay_stat = "Mean"
        self.assertEqual(app.group_overlay_statistics(df, settings), [("A", 103 / 3), ("B", 6.0)])

    def test_custom_overlay_rows_insert_above_sample_values(self):
        window = app.MainWindow()
        first_sample = window.table.item(1, 0).text()

        window.add_custom_overlay_row()
        window.add_custom_overlay_row()

        self.assertEqual(window.table.verticalHeaderItem(1).text(), "Overlay 1")
        self.assertEqual(window.table.verticalHeaderItem(2).text(), "Overlay 2")
        self.assertEqual(window.table.verticalHeaderItem(3).text(), "1")
        self.assertEqual(window.table.item(3, 0).text(), first_sample)
        self.assertEqual(window.table.dataframe().iloc[0, 0], first_sample)
        self.assertEqual(window.table.item(1, 0).textAlignment(), app.Qt.AlignLeft | app.Qt.AlignVCenter)
        self.assertNotEqual(window.table.item(1, 0).background().color().name().upper(), "#EAF2FF")

    def test_rename_overlay_row_uses_multiline_text_dialog(self):
        window = app.MainWindow()
        window.add_custom_overlay_row()

        with mock.patch.object(app.QInputDialog, "getMultiLineText", return_value=("Target\nDay 2", True)) as get_name:
            window.rename_overlay_row(1)

        get_name.assert_called_once()
        self.assertEqual(window.settings.custom_overlay_series[0]["name"], "Target\nDay 2")
        self.assertEqual(window.table.verticalHeaderItem(1).text(), "Target\nDay 2")

    def test_hiding_custom_overlay_preserves_table_values(self):
        window = app.MainWindow()
        window.add_custom_overlay_row()
        window.add_custom_overlay_row()
        window.table.item(1, 0).setText("12")
        window.table.item(2, 0).setText("34")
        window.settings.custom_overlay_hidden = [1]
        window.update_settings()

        self.assertEqual(window.custom_overlay_row_count(), 2)
        self.assertEqual(window.table.item(1, 0).text(), "12")
        self.assertEqual(window.table.item(2, 0).text(), "34")
        clean = app.prepare_plot_data(window.table.dataframe(), window.settings)
        self.assertEqual([series["name"] for series in app.line_overlay_series(clean, window.settings)], ["Overlay 1"])

    def test_hidden_overlay_keeps_custom_color_when_reshown(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1"}},
                {"name": "Overlay 2", "values": {"Control": "2"}},
            ],
            custom_overlay_hidden=[1],
            custom_overlay_colors={app.overlay_custom_color_key(1): "#123456"},
        )

        self.assertEqual([series["name"] for series in app.line_overlay_series(clean, settings)], ["Overlay 1"])
        self.assertEqual(settings.custom_overlay_colors[app.overlay_custom_color_key(1)], "#123456")

        settings.custom_overlay_hidden = []

        series = app.line_overlay_series(clean, settings)
        colors = app.overlay_palette_for(clean, settings, len(series))
        self.assertEqual([item["name"] for item in series], ["Overlay 1", "Overlay 2"])
        self.assertEqual(colors[1], "#123456")

    def test_remove_custom_overlay_confirms_before_deleting_values(self):
        window = app.MainWindow()
        window.add_custom_overlay_row()
        window.table.item(1, 0).setText("12")
        window.table.setCurrentCell(1, 0)

        with mock.patch.object(app.QMessageBox, "warning", return_value=app.QMessageBox.No):
            window.remove_custom_overlay_row()

        self.assertEqual(window.custom_overlay_row_count(), 1)
        self.assertEqual(window.table.item(1, 0).text(), "12")

        with mock.patch.object(app.QMessageBox, "warning", return_value=app.QMessageBox.Yes):
            window.remove_custom_overlay_row()

        self.assertEqual(window.custom_overlay_row_count(), 0)
        self.assertEqual(window.settings.custom_overlay_series, [])

    def test_table_editor_arrow_key_commits_and_moves_to_next_cell(self):
        window = app.MainWindow()
        window.table.setCurrentCell(1, 0)
        window.table.editItem(window.table.item(1, 0))
        self.qapp.processEvents()
        editor = window.table.findChild(app.QLineEdit)

        self.assertIsNotNone(editor)
        editor.setText("123")
        event = app.QKeyEvent(app.QEvent.KeyPress, app.Qt.Key_Right, app.Qt.KeypadModifier)
        self.qapp.sendEvent(editor, event)
        self.qapp.processEvents()

        self.assertEqual(window.table.item(1, 0).text(), "123")
        self.assertEqual((window.table.currentRow(), window.table.currentColumn()), (1, 1))
        self.assertIsNotNone(window.table.findChild(app.QLineEdit))

    def test_table_editor_return_key_commits_and_moves_down(self):
        window = app.MainWindow()
        window.table.setCurrentCell(1, 0)
        window.table.editItem(window.table.item(1, 0))
        self.qapp.processEvents()
        editor = window.table.findChild(app.QLineEdit)

        self.assertIsNotNone(editor)
        editor.setText("456")
        event = app.QKeyEvent(app.QEvent.KeyPress, app.Qt.Key_Return, app.Qt.NoModifier)
        self.qapp.sendEvent(editor, event)
        self.qapp.processEvents()

        self.assertEqual(window.table.item(1, 0).text(), "456")
        self.assertEqual((window.table.currentRow(), window.table.currentColumn()), (2, 0))

    def test_table_undo_redo_actions_use_standard_shortcuts(self):
        window = app.MainWindow()

        self.assertEqual(window.undo_table_action.shortcuts(), app.QKeySequence.keyBindings(app.QKeySequence.Undo))
        self.assertEqual(window.redo_table_action.shortcuts(), app.QKeySequence.keyBindings(app.QKeySequence.Redo))
        self.assertFalse(window.undo_table_action.isEnabled())
        self.assertFalse(window.redo_table_action.isEnabled())

    def test_file_actions_use_platform_standard_shortcuts(self):
        window = app.MainWindow()

        self.assertEqual(window.ui.actionOpenProject.shortcuts(), app.QKeySequence.keyBindings(app.QKeySequence.Open))
        self.assertEqual(window.ui.actionSaveProject.shortcuts(), app.QKeySequence.keyBindings(app.QKeySequence.Save))
        self.assertEqual(window.ui.actionSaveProjectAs.shortcuts(), app.QKeySequence.keyBindings(app.QKeySequence.SaveAs))
        self.assertEqual(window.ui.actionCopyFigure.shortcut(), app.QKeySequence("Ctrl+Shift+C"))
        self.assertNotIn(window.ui.actionCopyFigure.shortcut(), app.QKeySequence.keyBindings(app.QKeySequence.Copy))

    def test_table_cell_edit_can_be_undone_and_redone(self):
        window = app.MainWindow()
        original = window.table.item(1, 0).text()

        window.table.item(1, 0).setText("99")

        self.assertTrue(window.undo_table_action.isEnabled())
        self.assertFalse(window.redo_table_action.isEnabled())
        self.assertEqual(window.table.item(1, 0).text(), "99")

        window.undo_table_change()

        self.assertEqual(window.table.item(1, 0).text(), original)
        self.assertFalse(window.undo_table_action.isEnabled())
        self.assertTrue(window.redo_table_action.isEnabled())

        window.redo_table_change()

        self.assertEqual(window.table.item(1, 0).text(), "99")
        self.assertTrue(window.undo_table_action.isEnabled())
        self.assertFalse(window.redo_table_action.isEnabled())

    def test_custom_overlay_series_can_create_multiple_plot_lines(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_count=2,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Index", "values": {"Control": "10", "Low dose": "", "High dose": "30"}},
            ],
        )

        series = app.line_overlay_series(clean, settings)

        self.assertEqual([item["name"] for item in series], ["Target", "Index"])
        self.assertEqual(series[0]["values"], [5.0, 6.0, 7.0])
        self.assertTrue(math.isnan(series[1]["values"][1]))

    def test_custom_overlay_series_can_use_secondary_axis(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        series = app.line_overlay_series(clean, settings)

        self.assertTrue(series[0]["secondary_axis"])

    def test_secondary_axis_draws_extra_overlay_on_twin_axis(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            line_overlay_stat="None",
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        self.assertGreaterEqual(len(canvas.figure.axes), 2)
        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.yaxis.label.get_text() == "Rate")
        self.assertEqual(secondary_ax.yaxis.label.get_text(), "Rate")
        primary_overlay_lines = [line for line in primary_ax.lines if line.get_gid() == "overlay-line"]
        secondary_overlay_lines = [line for line in secondary_ax.lines if line.get_gid() == "overlay-line"]
        self.assertEqual(len(primary_overlay_lines), 0)
        self.assertEqual(len(secondary_overlay_lines), 1)

    def test_manual_secondary_y_range_applies_to_twin_axis(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            line_overlay_stat="None",
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            secondary_auto_y_range=False,
            secondary_y_min=40.0,
            secondary_y_max=80.0,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        self.assertEqual(secondary_ax.get_ylim(), (40.0, 80.0))

    def test_manual_primary_tick_interval_applies_to_box_y_axis(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            auto_y_range=False,
            y_min=0.0,
            y_max=10.0,
            primary_auto_tick_interval=False,
            primary_tick_interval=2.0,
        )

        canvas.render(self.df, settings)

        ticks = canvas.figure.axes[0].get_yticks()
        visible_ticks = [tick for tick in ticks if 0.0 <= tick <= 10.0]
        self.assertGreaterEqual(len(visible_ticks), 2)
        self.assertTrue(all(math.isclose(float(app.np.diff(visible_ticks)[index]), 2.0) for index in range(len(visible_ticks) - 1)))

    def test_auto_primary_tick_interval_syncs_spinbox_to_axis_ticks(self):
        window = app.MainWindow()
        window.settings = app.ChartSettings(auto_y_range=False, y_min=0.0, y_max=10.0, primary_auto_tick_interval=True)
        window.apply_settings_to_controls()

        window.render()

        expected_interval = window._auto_tick_interval_for_axis(window.canvas.figure.axes[0])
        self.assertIsNotNone(expected_interval)
        self.assertAlmostEqual(window.primary_tick_interval.value(), expected_interval)
        self.assertAlmostEqual(window.settings.primary_tick_interval, expected_interval)

    def test_manual_primary_tick_interval_falls_back_to_auto_when_too_dense(self):
        window = app.MainWindow()
        window.settings = app.ChartSettings(
            auto_y_range=False,
            y_min=0.0,
            y_max=10000.0,
            primary_auto_tick_interval=False,
            primary_tick_interval=0.000001,
        )
        window.apply_settings_to_controls()

        window.render()

        self.assertTrue(window.primary_auto_tick_interval.isChecked())
        self.assertTrue(window.settings.primary_auto_tick_interval)
        self.assertFalse(window.primary_tick_interval.isEnabled())
        self.assertGreater(window.primary_tick_interval.value(), 0.000001)

    def test_manual_primary_tick_interval_applies_to_ridge_x_axis(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            chart_type="Ridge",
            auto_y_range=False,
            y_min=0.0,
            y_max=10.0,
            primary_auto_tick_interval=False,
            primary_tick_interval=2.5,
        )

        canvas.render(self.df, settings)

        ticks = canvas.figure.axes[0].get_xticks()
        visible_ticks = [tick for tick in ticks if 0.0 <= tick <= 10.0]
        self.assertGreaterEqual(len(visible_ticks), 2)
        self.assertTrue(all(math.isclose(float(app.np.diff(visible_ticks)[index]), 2.5) for index in range(len(visible_ticks) - 1)))

    def test_manual_secondary_tick_interval_applies_to_twin_axis(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            line_overlay_stat="None",
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            secondary_auto_y_range=False,
            secondary_y_min=40.0,
            secondary_y_max=80.0,
            secondary_auto_tick_interval=False,
            secondary_tick_interval=10.0,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        ticks = secondary_ax.get_yticks()
        visible_ticks = [tick for tick in ticks if 40.0 <= tick <= 80.0]
        self.assertGreaterEqual(len(visible_ticks), 2)
        self.assertTrue(all(math.isclose(float(app.np.diff(visible_ticks)[index]), 10.0) for index in range(len(visible_ticks) - 1)))

    def test_manual_secondary_tick_interval_falls_back_to_auto_when_too_dense(self):
        window = app.MainWindow()
        window.add_custom_overlay_row()
        window.custom_overlay_secondary_axis.setChecked(True)
        window.secondary_auto_y_range.setChecked(False)
        window.secondary_y_min.setValue(0.0)
        window.secondary_y_max.setValue(10000.0)
        window.secondary_auto_tick_interval.setChecked(False)
        window.secondary_tick_interval.setValue(0.000001)

        window.update_settings()

        self.assertTrue(window.secondary_auto_tick_interval.isChecked())
        self.assertTrue(window.settings.secondary_auto_tick_interval)
        self.assertFalse(window.secondary_tick_interval.isEnabled())
        self.assertGreater(window.secondary_tick_interval.value(), 0.000001)

    def test_split_secondary_axis_draws_extra_overlay_in_upper_frame(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            show_stat_table=False,
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            secondary_axis_split_ratio=0.30,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        primary_position = primary_ax.get_position()
        secondary_position = secondary_ax.get_position()

        self.assertAlmostEqual(primary_position.x0, secondary_position.x0)
        self.assertAlmostEqual(primary_position.width, secondary_position.width)
        self.assertAlmostEqual(primary_position.y1, secondary_position.y0)
        total_plot_height = primary_position.height + secondary_position.height
        self.assertAlmostEqual(secondary_position.height / total_plot_height, 0.30)
        self.assertEqual(primary_ax.xaxis.label.get_text(), settings.x_label)
        self.assertEqual(secondary_ax.xaxis.label.get_text(), "")
        self.assertEqual([label.get_text() for label in primary_ax.get_xticklabels()], ["Control", "Low dose", "High dose"])
        self.assertEqual([label.get_text() for label in secondary_ax.get_xticklabels()], [])
        self.assertEqual(primary_ax.get_title(), "")
        self.assertEqual(secondary_ax.get_title(), settings.title)
        self.assertEqual(secondary_ax.yaxis.label.get_text(), "Rate")
        self.assertEqual(secondary_ax.yaxis.get_label_position(), "right")

        primary_overlay_lines = [line for line in primary_ax.lines if line.get_gid() == "overlay-line"]
        secondary_overlay_lines = [line for line in secondary_ax.lines if line.get_gid() == "overlay-line"]
        self.assertEqual(len(primary_overlay_lines), 0)
        self.assertEqual(len(secondary_overlay_lines), 1)

    def test_ridge_split_secondary_axis_draws_extra_overlay_in_upper_x_frame(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            chart_type="Ridge",
            show_stat_table=False,
            line_overlay_stat="None",
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            secondary_axis_split_ratio=0.30,
            secondary_auto_y_range=False,
            secondary_y_min=40.0,
            secondary_y_max=80.0,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        primary_position = primary_ax.get_position()
        secondary_position = secondary_ax.get_position()

        self.assertAlmostEqual(primary_position.x0, secondary_position.x0)
        self.assertAlmostEqual(primary_position.width, secondary_position.width)
        self.assertAlmostEqual(primary_position.y1, secondary_position.y0)
        total_plot_height = primary_position.height + secondary_position.height
        self.assertAlmostEqual(secondary_position.height / total_plot_height, 0.30)
        self.assertEqual(primary_ax.get_title(), "")
        self.assertEqual(secondary_ax.get_title(), settings.title)
        self.assertEqual(secondary_ax.xaxis.label.get_text(), "Rate")
        self.assertEqual(secondary_ax.xaxis.get_label_position(), "top")
        self.assertEqual(secondary_ax.get_ylabel(), "")
        self.assertEqual(secondary_ax.get_xlim(), (40.0, 80.0))
        self.assertEqual(secondary_ax.get_ylim(), primary_ax.get_ylim())
        self.assertEqual([label.get_text() for label in secondary_ax.get_yticklabels()], [])

        primary_overlay_lines = [line for line in primary_ax.lines if line.get_gid() == "overlay-line"]
        secondary_overlay_lines = [line for line in secondary_ax.lines if line.get_gid() == "overlay-line"]
        self.assertEqual(len(primary_overlay_lines), 0)
        self.assertEqual(len(secondary_overlay_lines), 1)
        self.assertEqual(list(secondary_overlay_lines[0].get_xdata()), [50.0, 60.0, 70.0])

    def test_multiline_split_secondary_title_uses_secondary_frame_and_expands_height(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            show_stat_table=False,
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )
        canvas.render(self.df, settings)
        single_line_height = canvas.figure.get_figheight()

        settings.title = "Distribution plot\nSecondary overlay\nNormalized rate"
        canvas.render(self.df, settings)

        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        self.assertGreater(canvas.figure.get_figheight(), single_line_height)
        self.assertEqual(primary_ax.get_title(), "")
        self.assertEqual(secondary_ax.get_title(), settings.title)

    def test_extra_overlay_palette_defaults_to_mono_and_supports_custom_colors(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            preset="Tableau 10",
            extra_custom_overlay=True,
            custom_overlay_count=2,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Index", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        expected = app.expanded_preset_palette(app.DEFAULT_OVERLAY_PALETTE, 2)

        self.assertEqual(app.overlay_palette_for(clean, settings, 2), expected)

        settings.custom_overlay_palette = "Dark Slide"
        self.assertEqual(app.overlay_palette_for(clean, settings, 2), app.expanded_preset_palette("Dark Slide", 2))

        settings.custom_overlay_colors = {app.overlay_custom_color_key(1): "#123456"}
        self.assertEqual(app.overlay_palette_for(clean, settings, 2)[1], "#123456")

    def test_overlay_palette_skips_colors_already_used_by_custom_overlays(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Overlay 2", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
                {"name": "Overlay 3", "values": {"Control": "15", "Low dose": "25", "High dose": "35"}},
            ],
        )
        first_color = app.expanded_preset_palette("Dark Slide", 3)[0]
        settings.custom_overlay_colors = {app.overlay_custom_color_key(1): first_color}

        palette = app.overlay_palette_for(clean, settings, 3)

        self.assertEqual(palette[1], app.QColor(first_color).name())
        self.assertEqual(len(palette), 3)
        self.assertEqual(len(set(palette)), 3)

    def test_overlay_color_panel_defaults_to_first_unused_palette_color(self):
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {}},
                {"name": "Overlay 2", "values": {}},
                {"name": "Overlay 3", "values": {}},
            ],
        )
        palette = app.expanded_preset_palette("Dark Slide", 3)
        settings.custom_overlay_colors = {app.overlay_custom_color_key(1): palette[2]}

        color_map = app.overlay_color_map_for_keys(app.all_overlay_color_keys(settings), settings)

        self.assertEqual(color_map[app.overlay_custom_color_key(1)], app.QColor(palette[2]).name())
        self.assertEqual(color_map[app.overlay_custom_color_key(2)], app.QColor(palette[1]).name())

    def test_filtering_custom_overlay_preserves_palette_slot_colors(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Overlay 2", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        before = app.overlay_palette_for(clean, settings, 2)[1]

        settings.custom_overlay_hidden = [0]

        self.assertEqual(app.overlay_palette_for(clean, settings, 1)[0], before)

    def test_hidden_overlay_color_still_occupies_palette_color(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Overlay 2", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        all_palette = app.overlay_palette_for(clean, settings, 2)

        settings.custom_overlay_hidden = [0]

        self.assertEqual(app.overlay_palette_for(clean, settings, 1)[0], all_palette[1])

    def test_filtering_custom_overlay_preserves_palette_slot_colors_with_stat_line(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Overlay 2", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        before = app.overlay_palette_for(clean, settings, 3)[2]

        settings.custom_overlay_hidden = [0]

        self.assertEqual(app.overlay_palette_for(clean, settings, 2)[1], before)

    def test_stat_overlay_uses_fixed_foreground_color(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(line_overlay_stat="Median", preset="Tableau 10")

        self.assertEqual(app.overlay_palette_for(clean, settings, 1), [app.stat_overlay_color(settings)])
        self.assertEqual(app.stat_overlay_color(settings), "#222222")

        settings.preset = "Dark Slide"
        self.assertEqual(app.overlay_palette_for(clean, settings, 1), ["#F9FAFB"])

    def test_stat_overlay_color_is_not_customizable(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            custom_overlay_colors={app.overlay_stat_color_key("Median"): "#123456"},
        )

        self.assertEqual(app.overlay_palette_for(clean, settings, 1), [app.stat_overlay_color(settings)])
        self.assertEqual(app.overlay_color_items(clean, settings), [])

    def test_stat_overlay_does_not_occupy_custom_overlay_palette_slot(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
            ],
        )

        palette = app.overlay_palette_for(clean, settings, 2)

        self.assertEqual(palette[0], app.stat_overlay_color(settings))
        self.assertEqual(palette[1], app.expanded_preset_palette("Dark Slide", 1)[0])

    def test_line_overlay_value_formatting(self):
        settings = app.ChartSettings(line_value_decimals=3)

        self.assertEqual(app.format_overlay_value(12.34567, settings), "12.346")

        settings.line_value_scientific = True
        settings.line_value_decimals = 2
        self.assertEqual(app.format_overlay_value(0.001234, settings), "1.23e-03")

    def test_line_overlay_style_controls_apply_to_plot_line(self):
        settings = app.ChartSettings(
            show_line_overlay=True,
            line_overlay_width=2.7,
            line_overlay_style="Dash-dot",
            line_overlay_point_size=8.0,
        )
        window = app.PlotCanvas()

        window.render(self.df, settings)
        overlay_line = window.figure.axes[0].lines[-1]

        self.assertEqual(overlay_line.get_linewidth(), 2.7)
        self.assertEqual(overlay_line.get_linestyle(), "-.")
        self.assertEqual(overlay_line.get_markersize(), 8.0)
        self.assertEqual(overlay_line.get_color(), app.stat_overlay_color(settings))
        self.assertEqual(overlay_line.get_alpha(), app.STAT_OVERLAY_ALPHA)

    def test_custom_group_color_sets_base_and_derives_point_color(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        self.settings.custom_colors = {"High dose": "#336699"}

        palette = app.palette_for(clean, self.settings)
        point_color = app.derived_group_color("#336699", "point")
        edge_color = app.derived_group_color("#336699", "edge")

        self.assertEqual(palette[2], "#336699")
        self.assertNotEqual(point_color, "#336699")
        self.assertNotEqual(edge_color, "#336699")
        self.assertTrue(point_color.startswith("#"))
        self.assertTrue(edge_color.startswith("#"))

    def test_palette_expands_without_repeating_for_many_groups(self):
        df = app.pd.DataFrame({
            "group": [f"Group {index}" for index in range(10)],
            "value": list(range(10)),
        })

        palette = app.palette_for(df, self.settings)

        self.assertEqual(len(palette), 10)
        self.assertEqual(len(set(palette)), 10)

    def test_group_palette_skips_colors_already_used_by_custom_groups(self):
        df = app.pd.DataFrame({
            "group": ["Group 1", "Group 2", "Group 3"],
            "value": [1, 2, 3],
        })
        first_color = app.expanded_preset_palette(self.settings.preset, 3)[0]
        self.settings.custom_colors = {"Group 2": first_color}

        palette = app.palette_for(df, self.settings)

        self.assertEqual(palette[1], app.QColor(first_color).name())
        self.assertEqual(len(palette), 3)
        self.assertEqual(len(set(palette)), 3)

    def test_palette_choices_offer_extra_colors_for_current_group_count(self):
        choices = app.palette_choices_for_group_count("Paper Clean", 10)

        self.assertGreater(len(choices), 10)
        self.assertEqual(len(set(choices)), len(choices))

    def test_common_palette_counts_are_loaded_from_precomputed_cache(self):
        app._precomputed_palette_cache.cache_clear()
        app._expanded_preset_palette_cached.cache_clear()

        with mock.patch.object(app, "_style_matched_palette_candidates", side_effect=AssertionError("dynamic palette generation used")):
            choices = app.expanded_preset_palette("Paper Clean", 18)

        self.assertEqual(len(choices), 18)
        self.assertEqual(
            choices[:5],
            [app.QColor(color).name() for color in app.PRESETS["Paper Clean"]["palette"]],
        )

    def test_palette_counts_over_precomputed_limit_use_dynamic_generation(self):
        app._precomputed_palette_cache.cache_clear()
        app._expanded_preset_palette_cached.cache_clear()

        with mock.patch.object(app, "_expanded_preset_palette_cached", return_value=tuple(["#111111"] * 101)) as dynamic_palette:
            choices = app.expanded_preset_palette("Paper Clean", 101)

        dynamic_palette.assert_called_once_with("Paper Clean", 101)
        self.assertEqual(len(choices), 101)

    def test_all_preset_palettes_expand_for_many_groups(self):
        for preset_name in app.PRESETS:
            with self.subTest(preset=preset_name):
                choices = app.palette_choices_for_group_count(preset_name, 12)

                self.assertGreater(len(choices), 12)
                self.assertEqual(len(set(choices)), len(choices))

    def test_categorical_palette_extensions_keep_visual_distance(self):
        excluded = app.SEQUENTIAL_PALETTE_PRESETS | {"Mono Print"}
        for preset_name in app.PRESETS:
            if preset_name in excluded:
                continue
            with self.subTest(preset=preset_name):
                choices = app.expanded_preset_palette(preset_name, 18)
                distances = [
                    app._minimum_lab_distance(color, choices[:index] + choices[index + 1:])
                    for index, color in enumerate(choices)
                ]

                self.assertGreaterEqual(min(distances), 16)

    def test_sequential_palette_extensions_resample_existing_gradient(self):
        choices = app.expanded_preset_palette("Viridis", 18)

        self.assertEqual(choices[0], app.PRESETS["Viridis"]["palette"][0].lower())
        self.assertEqual(choices[-1], app.PRESETS["Viridis"]["palette"][-1].lower())
        self.assertEqual(len(set(choices)), len(choices))

    def test_monochrome_palette_expands_only_with_grayscale_colors(self):
        choices = app.palette_choices_for_group_count("Mono Print", 10)

        self.assertGreater(len(choices), 10)
        for color in choices:
            qcolor = app.QColor(color)
            self.assertEqual(qcolor.red(), qcolor.green())
            self.assertEqual(qcolor.green(), qcolor.blue())

    def test_expanded_palette_keeps_custom_group_color_override(self):
        df = app.pd.DataFrame({
            "group": [f"Group {index}" for index in range(10)],
            "value": list(range(10)),
        })
        self.settings.custom_colors = {"Group 9": "#123456"}

        palette = app.palette_for(df, self.settings)

        self.assertEqual(palette[9], "#123456")

    def test_stat_table_data_includes_selected_plot_statistics(self):
        df = app.pd.DataFrame({
            "group": ["A", "A", "A", "B", "B"],
            "value": [1, 2, 3, 10, 14],
        })
        settings = app.ChartSettings(line_value_decimals=1)
        settings.show_stat_q1 = True
        settings.show_stat_q3 = True
        settings.show_stat_sd = True
        settings.show_stat_sample_size = True
        settings.show_stat_min = False
        settings.show_stat_sem = False

        groups, rows = app.stat_table_data(df, settings)

        self.assertEqual(groups, ["A", "B"])
        self.assertIn(("Mean", ["2.0", "12.0"]), rows)
        self.assertIn(("Median", ["2.0", "12.0"]), rows)
        self.assertIn(("Q1", ["1.5", "11.0"]), rows)
        self.assertIn(("Q3", ["2.5", "13.0"]), rows)
        self.assertIn(("Max", ["3.0", "14.0"]), rows)
        self.assertIn(("SD", ["1.0", "2.8"]), rows)
        self.assertIn(("Sample", ["3", "2"]), rows)
        self.assertNotIn("Min", [label for label, _ in rows])
        self.assertNotIn("SEM", [label for label, _ in rows])

    def test_stat_table_master_switch_keeps_checked_options(self):
        window = app.MainWindow()
        first_item = window.stat_table_options.item(0)
        df = app.prepare_plot_data(self.df, window.settings)

        self.assertEqual(first_item.checkState(), app.Qt.Checked)

        window.show_stat_table.setChecked(False)
        groups, rows = app.stat_table_data(df, window.settings)

        self.assertFalse(window.settings.show_stat_table)
        self.assertTrue(window.settings.show_stat_mean)
        self.assertEqual(first_item.checkState(), app.Qt.Checked)
        self.assertEqual(groups, [])
        self.assertEqual(rows, [])

    def test_stat_table_defaults_to_mean_median_min_max(self):
        settings = app.ChartSettings()
        enabled_labels = [
            label
            for setting_name, label in app.STAT_TABLE_OPTIONS
            if getattr(settings, setting_name)
        ]

        self.assertEqual(enabled_labels, ["Mean", "Median", "Max", "Min"])

    def test_stat_table_layout_uses_fixed_row_height_and_group_centers(self):
        window = app.MainWindow()
        settings = app.ChartSettings(show_stat_median=False, show_stat_q1=False, show_stat_q3=False)
        settings.show_stat_max = False
        settings.show_stat_min = False
        settings.show_stat_sd = False
        settings.show_stat_sem = False
        settings.show_stat_sample_size = False
        settings.stat_table_font_size = 9
        window.canvas.render(window.table.dataframe(), settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        one_row_height = table_ax.get_position().height * window.canvas.figure.get_figheight()

        settings.show_stat_sample_size = True
        window.canvas.render(window.table.dataframe(), settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        two_row_height = table_ax.get_position().height * window.canvas.figure.get_figheight() / 2

        self.assertEqual(plot_ax.get_xlim(), table_ax.get_xlim())
        self.assertAlmostEqual(one_row_height, two_row_height)

    def test_stat_table_row_labels_stay_inside_figure(self):
        window = app.MainWindow()
        df = app.pd.DataFrame({"Group 2": [1, 2, 3]})
        settings = app.ChartSettings()
        settings.show_stat_q1 = False
        settings.show_stat_q3 = False
        settings.show_stat_sd = False
        settings.show_stat_sem = False
        settings.show_stat_sample_size = False
        settings.show_stat_header = True

        window.canvas.render(df, settings)
        table_ax = window.canvas.figure.axes[1]
        renderer = window.canvas.canvas.get_renderer()
        row_label_edges = [
            text.get_window_extent(renderer).x0
            for text in table_ax.texts
            if text.get_text() in {"Mean", "Median", "Max", "Min"}
        ]

        self.assertGreaterEqual(min(row_label_edges), 0)

    def test_stat_table_extends_figure_without_shrinking_plot_height(self):
        window = app.MainWindow()
        settings = app.ChartSettings()
        settings.width = 15.0
        settings.height = 10.0
        settings.show_stat_header = True

        window.canvas.render(window.table.dataframe(), settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        figure_width = window.canvas.figure.get_figwidth()
        figure_height = window.canvas.figure.get_figheight()
        plot_width = plot_ax.get_position().width * figure_width
        plot_height = plot_ax.get_position().height * figure_height
        table_height = table_ax.get_position().height * figure_height

        self.assertAlmostEqual(plot_width, settings.width / 2.54)
        self.assertAlmostEqual(plot_height, settings.height / 2.54)
        self.assertGreater(figure_width, settings.width / 2.54)
        self.assertGreater(figure_height, settings.height / 2.54)
        self.assertGreater(table_height, 0)

    def test_plot_area_size_is_fixed_when_legend_is_outside(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "Control": [1, 2, 3],
            "Low dose": [2, 3, 4],
            "High dose": [3, 4, 10],
        })
        settings = app.ChartSettings(
            width=15.0,
            height=10.0,
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "TCT1000 cycle结果", "values": {"Control": "1", "Low dose": "2", "High dose": "10"}},
            ],
            legend_font_size=11,
            legend_width=2.8,
            legend_columns=1,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        legend = ax.get_legend()
        figure_width = canvas.figure.get_figwidth()
        figure_height = canvas.figure.get_figheight()
        plot_width = ax.get_position().width * figure_width
        plot_height = ax.get_position().height * figure_height

        self.assertAlmostEqual(plot_width, settings.width / 2.54)
        self.assertAlmostEqual(plot_height, settings.height / 2.54)
        self.assertEqual(legend.get_texts()[0].get_text(), "TCT1000\ncycle结果")
        self.assertLessEqual(legend.get_window_extent(renderer).x1, canvas.figure.bbox.x1)

    def test_plot_frame_has_four_sides_with_and_without_secondary_axis(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
        })

        for uses_secondary_axis in (False, True):
            settings = app.ChartSettings(
                show_stat_table=False,
                custom_overlay_secondary_axis=uses_secondary_axis,
                extra_custom_overlay=uses_secondary_axis,
                custom_overlay_series=[
                    {"name": "Overlay", "values": {"A": "3", "B": "4"}},
                ],
            )
            canvas.render(df, settings)

            ax = canvas.figure.axes[0]
            for side in ("left", "right", "top", "bottom"):
                self.assertTrue(ax.spines[side].get_visible())
                self.assertAlmostEqual(ax.spines[side].get_linewidth(), settings.axis_line_width)

    def test_stat_table_layout_accounts_for_multiline_axis_text(self):
        window = app.MainWindow()
        settings = app.ChartSettings(show_stat_median=False, show_stat_q1=False, show_stat_q3=False)
        settings.show_stat_max = False
        settings.show_stat_min = False
        settings.show_stat_sd = False
        settings.show_stat_sem = False
        settings.show_stat_sample_size = False
        window.canvas.render(window.table.dataframe(), settings)
        single_line_bottom = window.canvas.figure.axes[0].get_position().y0

        df = app.pd.DataFrame({
            "Control\nDay 1": [1, 2, 3],
            "Low dose\nDay 1": [4, 5, 6],
            "High dose\nDay 1": [7, 8, 9],
        })
        settings.x_label = "Group\nCondition"
        window.canvas.render(df, settings)
        multiline_bottom = window.canvas.figure.axes[0].get_position().y0

        self.assertGreater(multiline_bottom, single_line_bottom)

    def test_multiline_value_label_expands_figure_width(self):
        window = app.MainWindow()
        settings = app.ChartSettings()
        settings.show_stat_table = False
        window.canvas.render(window.table.dataframe(), settings)
        single_line_width = window.canvas.figure.get_figwidth()

        settings.y_label = "Value\nRelative change\nNormalized units"
        window.canvas.render(window.table.dataframe(), settings)
        multiline_width = window.canvas.figure.get_figwidth()

        self.assertGreater(multiline_width, single_line_width)

    def test_multiline_secondary_value_label_expands_figure_width(self):
        window = app.MainWindow()
        settings = app.ChartSettings(show_stat_table=False, custom_overlay_secondary_axis=True)
        window.canvas.render(window.table.dataframe(), settings)
        single_line_width = window.canvas.figure.get_figwidth()

        settings.secondary_y_label = "Rate\nNormalized index\nSecondary units"
        window.canvas.render(window.table.dataframe(), settings)
        multiline_width = window.canvas.figure.get_figwidth()

        self.assertGreater(multiline_width, single_line_width)

    def test_right_overlay_legend_avoids_secondary_axis_title(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = app.ChartSettings(
            show_stat_table=False,
            custom_overlay_secondary_axis=True,
            secondary_y_label="Secondary\nAxis\nTitle",
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Secondary overlay", "values": {"A": "30", "B": "40", "C": "50"}},
            ],
            legend_font_size=10,
            legend_width=3.0,
            legend_columns=1,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        legend = ax.get_legend()
        legend_bounds = legend.get_window_extent(renderer)
        title_bounds = secondary_ax.yaxis.label.get_window_extent(renderer)
        gap_px = legend_bounds.x0 - title_bounds.x1

        self.assertGreaterEqual(gap_px, app.LEGEND_SECONDARY_AXIS_GAP_PX - 1.0)
        self.assertLess(gap_px, 24.0)

    def test_stat_table_gap_accounts_for_rotated_ticks_and_bottom_axis_labels(self):
        window = app.MainWindow()
        df = app.pd.DataFrame({
            "Control": app.pd.Series([4.1, 4.6, 5.0]),
            "Low dose": app.pd.Series([5.1, 5.7, 6.3]),
            "High dose": app.pd.Series([5.8, 6.3, 7.1]),
            "Group 4": app.pd.Series([1, 2, 3, 5]),
            "Group 5": app.pd.Series([1, 2, 3]),
            "Group 6": app.pd.Series([2, 2, 3]),
            "Group 7": app.pd.Series([2, 4, 4]),
            "a": app.pd.Series([3.4, 4.6, 5.5]),
            "c": app.pd.Series([4.6, 5.6, 6.9]),
            "v": app.pd.Series([5.0, 6.3, 7.5]),
            "b": app.pd.Series([1, 2, 3, 4, 5]),
            "t": app.pd.Series([1, 2, 3]),
            "q": app.pd.Series([2, 2.5, 3]),
            "w": app.pd.Series([2, 4, 4]),
            "e": app.pd.Series([3, 3, 4]),
        })
        settings = app.ChartSettings(
            show_line_overlay=True,
            show_line_values=True,
            line_value_position="Bottom axis",
            line_value_decimals=2,
            x_tick_rotation=65,
            show_stat_header=False,
        )

        window.canvas.render(df, settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        renderer = window.canvas.canvas.get_renderer()
        table_top = table_ax.get_window_extent(renderer).y1
        plot_bottom_artists = [
            artist
            for artist in [plot_ax.xaxis.label, *plot_ax.get_xticklabels(), *plot_ax.texts]
            if artist.get_visible() and artist.get_text()
        ]

        lowest_plot_text = min(artist.get_window_extent(renderer).y0 for artist in plot_bottom_artists)

        self.assertGreater(lowest_plot_text, table_top)

    def test_stat_table_header_supports_multiline_group_names(self):
        window = app.MainWindow()
        df = app.pd.DataFrame({
            "Control\nDay 1": [1, 2, 3],
            "Low dose\nDay 1": [4, 5, 6],
            "High dose\nDay 1": [7, 8, 9],
        })
        settings = app.ChartSettings(show_stat_header=True, show_stat_median=False, show_stat_q1=False, show_stat_q3=False)
        settings.show_stat_max = False
        settings.show_stat_min = False
        settings.show_stat_sd = False
        settings.show_stat_sem = False
        settings.show_stat_sample_size = False

        window.canvas.render(df, settings)
        table_ax = window.canvas.figure.axes[1]

        self.assertGreater(table_ax.get_ylim()[1], 2.0)
        self.assertTrue(any("\n" in text.get_text() for text in table_ax.texts))

    def test_line_overlay_label_offsets_avoid_close_points(self):
        self.assertEqual(app.overlay_label_offset(0, [1.0, 1.02, 3.0], "Auto", is_ridge=False), (0, 13, "center", "bottom"))
        self.assertEqual(app.overlay_label_offset(1, [1.0, 1.02, 3.0], "Auto", is_ridge=False), (0, -13, "center", "top"))
        self.assertEqual(app.overlay_label_offset(1, [1.0, 1.02, 3.0], "Auto", is_ridge=True), (-12, 0, "right", "center"))
        self.assertEqual(
            app.overlay_label_offset(0, [1.0, 1.02, 3.0], "Auto", is_ridge=False, series_index=1),
            (8, -13, "center", "top"),
        )
        self.assertEqual(app.overlay_label_offset(0, [1.0], "Right", is_ridge=False), (12, 0, "left", "center"))

    def test_axis_line_overlay_labels_keep_distribution_plots_clear(self):
        df = app.pd.DataFrame({"A": [1, 2, 3], "B": [10, 11, 12], "C": [20, 21, 22]})
        for chart_type in ("Box", "Violin"):
            for position in ("Top axis", "Bottom axis"):
                with self.subTest(chart_type=chart_type, position=position):
                    settings = app.ChartSettings(
                        chart_type=chart_type,
                        show_line_overlay=True,
                        show_line_values=True,
                        line_value_position=position,
                        line_value_decimals=0,
                    )
                    window = app.PlotCanvas()
                    window.render(df, settings)
                    renderer = window.canvas.get_renderer()
                    ax = window.figure.axes[0]
                    label_bounds = [
                        artist.get_window_extent(renderer)
                        for artist in ax.texts
                        if artist.get_text() in {"2", "11", "21"}
                    ]

                    self.assertEqual(len(label_bounds), 3)
                    if position == "Bottom axis":
                        data_min_y = ax.transData.transform((0, 1))[1]
                        self.assertGreater(data_min_y, max(bounds.y1 for bounds in label_bounds))
                    else:
                        data_max_y = ax.transData.transform((0, 22))[1]
                        self.assertLess(data_max_y, min(bounds.y0 for bounds in label_bounds))

    def test_axis_line_overlay_padding_preserves_auto_y_base_range(self):
        base_canvas = app.PlotCanvas()
        base_canvas.render(
            app.sample_data(),
            app.ChartSettings(line_overlay_stat="Median", show_line_values=True, line_value_position="Above"),
        )
        base_y_min, base_y_max = base_canvas.figure.axes[0].get_ylim()

        for position in ("Top axis", "Bottom axis"):
            with self.subTest(position=position):
                canvas = app.PlotCanvas()
                canvas.render(
                    app.sample_data(),
                    app.ChartSettings(line_overlay_stat="Median", show_line_values=True, line_value_position=position),
                )
                y_min, y_max = canvas.figure.axes[0].get_ylim()

                self.assertLessEqual(y_min, base_y_min)
                self.assertGreaterEqual(y_max, base_y_max)

    def test_axis_line_overlay_padding_uses_label_height_not_chart_height(self):
        df = app.pd.DataFrame({"A": [1, 2, 3], "B": [10, 11, 12], "C": [20, 21, 22]})
        for position in ("Top axis", "Bottom axis"):
            gaps = []
            for height in (6, 18):
                settings = app.ChartSettings(
                    height=height,
                    show_line_overlay=True,
                    show_line_values=True,
                    line_value_position=position,
                    line_value_decimals=0,
                )
                window = app.PlotCanvas()
                window.render(df, settings)
                renderer = window.canvas.get_renderer()
                ax = window.figure.axes[0]
                label_bounds = [
                    artist.get_window_extent(renderer)
                    for artist in ax.texts
                    if artist.get_text() in {"2", "11", "21"}
                ]

                if position == "Bottom axis":
                    data_y = ax.transData.transform((0, 1))[1]
                    gaps.append(data_y - max(bounds.y1 for bounds in label_bounds))
                else:
                    data_y = ax.transData.transform((0, 22))[1]
                    gaps.append(min(bounds.y0 for bounds in label_bounds) - data_y)

            self.assertAlmostEqual(gaps[0], gaps[1], delta=2.0)

    def test_auto_y_axis_line_overlay_labels_keep_points_inside_plot(self):
        df = app.sample_data()
        for position in ("Top axis", "Bottom axis"):
            with self.subTest(position=position):
                settings = app.ChartSettings(
                    auto_y_range=True,
                    show_points=True,
                    show_outliers=True,
                    show_line_overlay=True,
                    show_line_values=True,
                    line_value_position=position,
                    line_value_decimals=2,
                )
                window = app.PlotCanvas()
                window.render(df, settings)
                renderer = window.canvas.get_renderer()
                ax = window.figure.axes[0]
                ax_bounds = ax.get_window_extent(renderer)

                for collection in ax.collections:
                    offsets = collection.get_offsets()
                    if len(offsets) == 0:
                        continue
                    points = ax.transData.transform(offsets)
                    finite_y = [point[1] for point in points if app.math.isfinite(point[1])]
                    if not finite_y:
                        continue
                    sizes = collection.get_sizes()
                    marker_radius_points = (max(sizes) ** 0.5) / 2.0 if len(sizes) else 0.0
                    marker_radius_px = renderer.points_to_pixels(marker_radius_points)

                    self.assertGreaterEqual(min(finite_y) - marker_radius_px, ax_bounds.y0)
                    self.assertLessEqual(max(finite_y) + marker_radius_px, ax_bounds.y1)

    def test_duplicate_group_names_are_combined_for_plotting(self):
        df = app.pd.DataFrame(
            [
                [1, 3, 10],
                [2, 4, 11],
            ],
            columns=["A", "A", "B"],
        )

        clean = app.prepare_plot_data(df, self.settings)

        self.assertEqual(list(clean["group"].drop_duplicates()), ["A", "B"])
        self.assertEqual(clean[clean["group"] == "A"]["value"].tolist(), [1.0, 2.0, 3.0, 4.0])

    def test_duplicate_group_names_sort_by_combined_values(self):
        df = app.pd.DataFrame(
            [
                [10, 30, 1],
                [20, 40, 2],
            ],
            columns=["A", "A", "B"],
        )
        settings = app.ChartSettings(group_order="Mean descending")

        clean = app.prepare_plot_data(df, settings)

        self.assertEqual(list(clean["group"].drop_duplicates()), ["A", "B"])

    def test_jitter_positions_are_stable_across_zoom_redraws(self):
        window = app.MainWindow()
        clean = app.prepare_plot_data(window.table.dataframe(), window.settings)
        outliers = app.mark_outliers(clean, window.settings)

        for mode in ["Beeswarm", "Quasirandom", "Random"]:
            window.settings.jitter_mode = mode
            first = window.canvas._point_positions(clean, window.settings)
            window.canvas.zoom_by(1.12)
            second = window.canvas._point_positions(clean, window.settings)
            self.assertAlmostEqual(
                float(first.loc[outliers.index[0]]),
                float(second.loc[outliers.index[0]]),
            )

    def test_zoom_to_fit_scales_to_viewport_without_resize_autofit(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(width=30.0, height=20.0)
        canvas.resize(420, 320)
        canvas.show()
        self.qapp.processEvents()
        canvas.render(self.df, settings)
        canvas.reset_zoom()
        self.qapp.processEvents()

        canvas.zoom_to_fit()
        fitted_zoom = canvas.preview_zoom
        canvas.resize(840, 640)
        self.qapp.processEvents()

        self.assertLess(fitted_zoom, 1.0)
        self.assertEqual(canvas.preview_zoom, fitted_zoom)
        canvas.close()

    def test_open_project_zoom_to_fit_after_loading(self):
        window = app.MainWindow()
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "fit_on_open.eg"
            app.write_project(path, self.df, self.settings)

            with mock.patch.object(app.QFileDialog, "getOpenFileName", return_value=(str(path), "")):
                with mock.patch.object(window.canvas, "zoom_to_fit") as zoom_to_fit:
                    window.open_project()

        self.assertEqual(window.current_project, path)
        self.assertGreaterEqual(zoom_to_fit.call_count, 1)

    def test_export_figure_svg_filter_appends_svg_suffix(self):
        window = app.MainWindow()
        with mock.patch.object(
            app.QFileDialog,
            "getSaveFileName",
            return_value=("/tmp/easygraph_export", "SVG Vector (*.svg)"),
        ):
            with mock.patch.object(window.canvas, "export") as export:
                window.export_figure()

        export.assert_called_once_with("/tmp/easygraph_export.svg", window.settings)

    def test_export_figure_keeps_explicit_suffix(self):
        window = app.MainWindow()
        with mock.patch.object(
            app.QFileDialog,
            "getSaveFileName",
            return_value=("/tmp/easygraph_export.pdf", "SVG Vector (*.svg)"),
        ):
            with mock.patch.object(window.canvas, "export") as export:
                window.export_figure()

        export.assert_called_once_with("/tmp/easygraph_export.pdf", window.settings)

    def test_export_figure_appends_suffix_for_windows_style_path(self):
        window = app.MainWindow()
        windows_path = r"C:\Users\Public\easygraph_export"
        with mock.patch.object(
            app.QFileDialog,
            "getSaveFileName",
            return_value=(windows_path, "SVG Vector (*.svg)"),
        ):
            with mock.patch.object(window.canvas, "export") as export:
                window.export_figure()

        export.assert_called_once_with(f"{windows_path}.svg", window.settings)

    def test_project_roundtrip_preserves_new_settings(self):
        self.settings.jitter_mode = "Quasirandom"
        self.settings.outlier_effect = "Exclude from distribution"
        self.settings.box_whisker_mode = "Min-Max"
        self.settings.group_order = "Mean descending"
        self.settings.manual_group_order = ["High dose", "Control", "Low dose"]
        self.settings.group_hidden = ["Low dose"]
        self.settings.transparent_background = True
        self.settings.show_line_overlay = True
        self.settings.line_overlay_stat = "Mean"
        self.settings.line_overlay_width = 2.4
        self.settings.line_overlay_style = "Dashed"
        self.settings.line_overlay_point_size = 7.5
        self.settings.show_line_values = True
        self.settings.line_value_position = "Below"
        self.settings.custom_line_value_position = "Left"
        self.settings.secondary_y_label = "Rate"
        self.settings.custom_overlay_secondary_axis = True
        self.settings.custom_overlay_hidden = [1]
        self.settings.secondary_auto_y_range = False
        self.settings.secondary_y_min = 40.0
        self.settings.secondary_y_max = 80.0
        self.settings.split_secondary_axis = True
        self.settings.secondary_axis_split_ratio = 0.42
        self.settings.line_value_scientific = True
        self.settings.line_value_decimals = 4
        self.settings.line_value_font_size = 11
        self.settings.custom_colors = {"High dose": "#336699"}
        self.settings.custom_overlay_palette = "Dark Slide"
        self.settings.custom_overlay_colors = {"custom:0": "#884466"}
        self.settings.x_tick_rotation = 65
        self.settings.preset = "Tableau 10"
        self.settings.point_size = 5.5
        self.settings.point_alpha = 0.42
        self.settings.axis_line_width = 1.8
        self.settings.show_grid = False
        self.settings.auto_y_range = False
        self.settings.y_min = -1.0
        self.settings.y_max = 12.0
        self.settings.box_width = 0.72
        self.settings.violin_width = 0.66
        self.settings.kde_bandwidth = 1.4
        self.settings.ridge_overlap = 0.82
        self.settings.fill_alpha = 0.51
        self.settings.show_stat_min = False
        self.settings.show_stat_sem = False
        self.settings.show_stat_header = True
        self.settings.stat_table_font_size = 10
        path = pathlib.Path(tempfile.gettempdir()) / "easygraph_test_roundtrip.eg"

        app.write_project(path, self.df, self.settings)
        roundtrip_df, roundtrip_settings = app.read_project(path)

        self.assertEqual(roundtrip_df.shape, self.df.shape)
        self.assertEqual(app.asdict(roundtrip_settings), app.asdict(self.settings))

    def test_save_project_syncs_current_ui_settings(self):
        window = app.MainWindow()
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "ui_sync.eg"
            window.current_project = path
            window.x_tick_rotation.setValue(0)
            window.x_tick_rotation.lineEdit().setText("65")
            window.preset.setCurrentText("Tableau 10")
            window.settings.x_tick_rotation = 0

            window.save_project()
            _roundtrip_df, roundtrip_settings = app.read_project(path)

        self.assertEqual(roundtrip_settings.x_tick_rotation, 65)
        self.assertEqual(roundtrip_settings.preset, "Tableau 10")

    def test_blank_project_data_has_three_empty_columns(self):
        df = app.blank_project_data()

        self.assertEqual(list(df.columns), ["Group 1", "Group 2", "Group 3"])
        self.assertEqual(df.shape[1], 3)
        self.assertTrue((df == "").all().all())

    def test_new_project_starts_with_three_blank_columns(self):
        window = app.MainWindow()

        window.new_project()

        self.assertEqual(window.table.columnCount(), 3)
        self.assertEqual(list(window.table.dataframe().columns), ["Group 1", "Group 2", "Group 3"])
        self.assertTrue((window.table.dataframe() == "").all().all())

    def test_new_project_applies_current_template_settings(self):
        window = app.MainWindow()
        template_settings = app.ChartSettings(
            chart_type="Violin",
            title="Template title",
            width=22.0,
            group_order="Manual",
            manual_group_order=["Old group"],
        )
        window.template_combo.blockSignals(True)
        try:
            window.template_combo.clear()
            window.template_combo.addItem("Template A")
            window.template_combo.setCurrentText("Template A")
        finally:
            window.template_combo.blockSignals(False)

        with mock.patch.object(app, "read_style_template", return_value=template_settings):
            window.new_project()

        self.assertEqual(window.settings.chart_type, "Violin")
        self.assertEqual(window.chart_type.currentText(), "Violin")
        self.assertEqual(window.settings.title, "Template title")
        self.assertEqual(window.title.toPlainText(), "Template title")
        self.assertEqual(window.settings.width, 22.0)
        self.assertEqual(list(window.table.dataframe().columns), ["Group 1", "Group 2", "Group 3"])
        self.assertTrue((window.table.dataframe() == "").all().all())
        self.assertEqual(window.settings.manual_group_order, ["Group 1", "Group 2", "Group 3"])

    def test_style_template_roundtrip_preserves_settings(self):
        self.settings.chart_type = "Ridge"
        self.settings.title = "Saved style"
        self.settings.width = 22.0
        self.settings.transparent_background = False
        self.settings.show_line_overlay = True
        self.settings.line_overlay_stat = "Mean"
        self.settings.line_overlay_width = 2.2
        self.settings.line_overlay_style = "Dotted"
        self.settings.line_overlay_point_size = 6.5
        self.settings.line_value_position = "Right"
        self.settings.custom_line_value_position = "Below"
        self.settings.line_value_font_size = 12
        self.settings.custom_colors = {"Control": "#446688"}
        self.settings.x_tick_rotation = 65
        self.settings.preset = "Viridis"
        self.settings.auto_y_range = False
        self.settings.y_min = -2.0
        self.settings.y_max = 9.0
        self.settings.line_value_decimals = 4
        self.settings.line_value_scientific = True
        self.settings.show_stat_q1 = False
        self.settings.stat_table_font_size = 8
        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)

            path = app.write_style_template(" My style/template ", self.settings, template_dir)
            loaded = app.read_style_template(path.stem, template_dir)

        self.assertEqual(path.name, "My style_template.json")
        self.assertEqual(app.asdict(loaded), app.asdict(self.settings))

    def test_import_style_template_copies_external_json(self):
        self.settings.chart_type = "Violin"
        self.settings.title = "External style"
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = pathlib.Path(tmp)
            external = tmp_path / "external style.json"
            external.write_text(app.json.dumps(app.asdict(self.settings)), encoding="utf-8")

            name, loaded = app.import_style_template(external, tmp_path / "templates")

            self.assertEqual(name, "external style")
            self.assertTrue((tmp_path / "templates" / "external style.json").exists())
            self.assertEqual(loaded.chart_type, "Violin")
            self.assertEqual(loaded.title, "External style")

    def test_all_chart_types_render_offscreen(self):
        window = app.MainWindow()

        for chart_type in ["Box", "Violin", "Ridge"]:
            with self.subTest(chart_type=chart_type):
                window.settings.chart_type = chart_type
                window.canvas.render(window.table.dataframe(), window.settings)

    def test_ridge_uses_y_tick_labels_for_group_names(self):
        window = app.MainWindow()
        window.settings.chart_type = "Ridge"
        window.canvas.render(window.table.dataframe(), window.settings)
        ax = window.canvas.figure.axes[0]

        labels = [tick.get_text() for tick in ax.get_yticklabels()]
        self.assertEqual(labels, ["Control", "Low dose", "High dose"])

    def test_ridge_manual_range_applies_to_x_axis(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(chart_type="Ridge", auto_y_range=False, y_min=-2.0, y_max=9.0)

        canvas.render(self.df, settings)

        self.assertEqual(canvas.figure.axes[0].get_xlim(), (-2.0, 9.0))

    def test_ridge_auto_x_range_includes_extra_overlay(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "Control": [1, 2, 3],
            "Treatment": [2, 3, 4],
        })
        settings = app.ChartSettings(
            chart_type="Ridge",
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "100", "Treatment": "110"}},
            ],
        )

        canvas.render(df, settings)

        self.assertGreater(canvas.figure.axes[0].get_xlim()[1], 110)

    def test_ridge_stat_overlay_supports_axis_left_and_right_labels(self):
        df = app.pd.DataFrame({"A": [1, 2, 3], "B": [10, 11, 12]})
        for position in ("Axis left", "Axis right"):
            with self.subTest(position=position):
                canvas = app.PlotCanvas()
                settings = app.ChartSettings(
                    chart_type="Ridge",
                    line_overlay_stat="Median",
                    show_line_values=True,
                    line_value_position=position,
                    line_value_decimals=0,
                )

                canvas.render(df, settings)

                ax = canvas.figure.axes[0]
                labels = [
                    text
                    for text in ax.texts
                    if text.get_text() in {"2", "11"}
                ]
                label_offsets = [
                    text.get_position()[0]
                    for text in ax.texts
                    if text.get_text() in {"2", "11"}
                ]
                label_alignments = [text.get_ha() for text in labels]
                expected_offset = -app.OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS if position == "Axis right" else app.OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                expected_alignment = "right" if position == "Axis right" else "left"
                self.assertEqual(label_offsets, [expected_offset] * 2)
                self.assertEqual(label_alignments, [expected_alignment] * 2)

    def test_overlay_value_labels_stay_inside_axis_bounds(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "Control": [4, 5, 6],
            "Low dose": [5, 6, 7],
            "High dose": [6, 7, 8],
        })
        settings = app.ChartSettings(
            chart_type="Ridge",
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1", "Low dose": "2", "High dose": "3"}},
            ],
            show_line_values=True,
            line_value_position="Axis left",
            custom_line_value_position="Left",
            line_value_decimals=2,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        axis_bounds = ax.get_window_extent(renderer)
        for text in ax.texts:
            if text.get_gid() == "overlay-value-label":
                bounds = text.get_bbox_patch().get_window_extent(renderer)
                self.assertGreaterEqual(bounds.x0, axis_bounds.x0 - 0.5)
                self.assertLessEqual(bounds.x1, axis_bounds.x1 + 0.5)
                self.assertGreaterEqual(bounds.y0, axis_bounds.y0 - 0.5)
                self.assertLessEqual(bounds.y1, axis_bounds.y1 + 0.5)

    def test_overlay_value_labels_do_not_overlap_each_other(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({"Control": [1, 2, 3]})
        settings = app.ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=2,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "2"}},
                {"name": "Overlay 2", "values": {"Control": "2"}},
            ],
            show_line_values=True,
            custom_line_value_position="Above",
            line_value_decimals=2,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        labels = [
            text
            for text in canvas.figure.axes[0].texts
            if text.get_gid() == "overlay-value-label"
        ]
        bounds = [label.get_bbox_patch().get_window_extent(renderer) for label in labels]
        self.assertEqual(len(bounds), 2)
        for left_index, left_bounds in enumerate(bounds):
            for right_bounds in bounds[left_index + 1:]:
                overlap_x = min(left_bounds.x1, right_bounds.x1) - max(left_bounds.x0, right_bounds.x0)
                overlap_y = min(left_bounds.y1, right_bounds.y1) - max(left_bounds.y0, right_bounds.y0)
                self.assertTrue(overlap_x <= 0.5 or overlap_y <= 0.5)

    def test_stat_overlay_labels_keep_priority_over_extra_overlay_labels(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({"Control": [1, 2, 3]})
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "2"}},
            ],
            show_line_values=True,
            line_value_position="Above",
            custom_line_value_position="Above",
            line_value_decimals=2,
        )

        canvas.render(df, settings)

        ax = canvas.figure.axes[0]
        stat_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and getattr(text, "_easygraph_overlay_priority", None) == 0
        )
        extra_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and getattr(text, "_easygraph_overlay_priority", None) == 1
        )

        self.assertEqual(stat_label.get_position(), (0, 13))
        self.assertNotEqual(extra_label.get_position(), (0, 13))

    def test_overlay_value_labels_offset_away_from_line_overlay_points(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({"Control": [1, 2, 3]})
        settings = app.ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "2"}},
            ],
            show_line_values=True,
            custom_line_value_position="Right",
            line_overlay_point_size=30.0,
            line_value_decimals=2,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        label = next(text for text in ax.texts if text.get_gid() == "overlay-value-label")
        label_bounds = label.get_bbox_patch().get_window_extent(renderer)
        point_x, point_y = ax.transData.transform((0, 2))
        marker_radius_px = settings.line_overlay_point_size * canvas.figure.dpi / 72.0 / 2.0

        self.assertGreater(label_bounds.x0, point_x + marker_radius_px)

    def test_auto_y_range_expands_before_moving_below_overlay_label_over_marker(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "10", "Low dose": "1", "High dose": "2"}},
            ],
            show_line_values=True,
            line_value_position="Bottom axis",
            custom_line_value_position="Below",
            line_value_decimals=2,
            auto_y_range=True,
        )

        canvas.render(app.sample_data(), settings)

        ax = canvas.figure.axes[0]
        low_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and text.get_text() == "1.00"
        )

        self.assertLess(ax.get_ylim()[0], 0.0)
        self.assertLess(low_label.get_position()[1], 0.0)

    def test_custom_auto_overlay_avoids_bottom_axis_stat_labels(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1", "Low dose": "2", "High dose": "10"}},
            ],
            show_line_values=True,
            line_value_position="Bottom axis",
            custom_line_value_position="Auto",
            line_value_decimals=2,
        )

        canvas.render(app.sample_data(), settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        control_stat_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
            and getattr(text, "_easygraph_overlay_priority", None) == 0
            and getattr(text, "xy", (None, None))[0] == 0
        )
        control_custom_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
            and getattr(text, "_easygraph_overlay_priority", None) == 1
            and text.get_text() == "1.00"
        )

        self.assertEqual(getattr(control_custom_label, "_easygraph_overlay_position", None), "Above")
        stat_bounds = canvas._overlay_label_bounds(control_stat_label, renderer)
        custom_bounds = canvas._overlay_label_bounds(control_custom_label, renderer)
        overlap_x = min(stat_bounds.x1, custom_bounds.x1) - max(stat_bounds.x0, custom_bounds.x0)
        overlap_y = min(stat_bounds.y1, custom_bounds.y1) - max(stat_bounds.y0, custom_bounds.y0)
        self.assertTrue(overlap_x <= 0.5 or overlap_y <= 0.5)

    def test_manual_y_range_is_not_expanded_for_axis_overlay_labels(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            auto_y_range=False,
            y_min=-0.53,
            y_max=10.45,
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1", "Low dose": "2", "High dose": "10"}},
            ],
            show_line_values=True,
            line_value_position="Bottom axis",
            custom_line_value_position="Auto",
            line_value_decimals=2,
        )

        canvas.render(app.sample_data(), settings)

        self.assertEqual(canvas.figure.axes[0].get_ylim(), (-0.53, 10.45))

    def test_manual_y_range_clips_out_of_range_overlay_value_labels(self):
        canvas = app.PlotCanvas()
        settings = app.ChartSettings(
            auto_y_range=False,
            y_min=2.0,
            y_max=9.0,
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1", "Low dose": "4", "High dose": "10"}},
            ],
            show_line_values=True,
            custom_line_value_position="Below",
            line_value_decimals=2,
        )

        canvas.render(app.sample_data(), settings)

        ax = canvas.figure.axes[0]
        label_texts = [
            text.get_text()
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
        ]
        self.assertEqual(ax.get_ylim(), (2.0, 9.0))
        self.assertNotIn("1.00", label_texts)
        self.assertIn("4.00", label_texts)
        self.assertNotIn("10.00", label_texts)

    def test_overlay_legend_is_placed_outside_axis_on_the_right(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = app.ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=2,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"A": "3", "B": "4", "C": "5"}},
                {"name": "Overlay 2", "values": {"A": "2.8", "B": "3.8", "C": "4.8"}},
            ],
            show_line_values=True,
            custom_line_value_position="Above",
            line_value_decimals=1,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        legend = ax.get_legend()
        self.assertIsNotNone(legend)
        legend_bounds = legend.get_window_extent(renderer)
        axis_bounds = ax.get_window_extent(renderer)

        self.assertGreaterEqual(legend_bounds.x0, axis_bounds.x1)

    def test_show_legend_can_hide_overlay_legend(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = app.ChartSettings(
            show_legend=False,
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Overlay", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
            legend_width=8.0,
        )

        canvas.render(df, settings)

        ax = canvas.figure.axes[0]
        figure_width = canvas.figure.get_figwidth()
        plot_width = ax.get_position().width * figure_width

        self.assertIsNone(ax.get_legend())
        self.assertAlmostEqual(plot_width, settings.width / 2.54)

    def test_overlay_legend_uses_custom_font_size_and_manual_columns_wrap(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = app.ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Very long overlay legend label", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
            legend_font_size=7,
            legend_width=1.2,
            legend_columns=1,
        )

        canvas.render(df, settings)

        legend = canvas.figure.axes[0].get_legend()
        legend_text = legend.get_texts()[0]
        self.assertEqual(legend_text.get_fontsize(), 7)
        self.assertIn("\n", legend_text.get_text())

    def test_overlay_legend_supports_manual_wrap_with_auto_columns(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
        })
        settings = app.ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Manual\\nLegend", "values": {"A": "3", "B": "4"}},
            ],
        )

        canvas.render(df, settings)

        legend = canvas.figure.axes[0].get_legend()
        self.assertEqual(legend.get_texts()[0].get_text(), "Manual\nLegend")

    def test_overlay_legend_auto_columns_use_total_width_without_wrapping(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = app.ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=3,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"A": "3", "B": "4", "C": "5"}},
                {"name": "Overlay 2", "values": {"A": "2.8", "B": "3.8", "C": "4.8"}},
                {"name": "Overlay 3", "values": {"A": "2.6", "B": "3.6", "C": "4.6"}},
            ],
            legend_width=8.0,
            legend_columns=0,
        )

        canvas.render(df, settings)

        legend = canvas.figure.axes[0].get_legend()
        self.assertGreaterEqual(getattr(legend, "_ncols", 1), 2)
        self.assertNotIn("\n", legend.get_texts()[0].get_text())

    def test_overlay_legend_auto_columns_wrap_when_total_width_is_too_small(self):
        canvas = app.PlotCanvas()
        df = app.pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = app.ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Very long overlay legend label", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
            legend_font_size=7,
            legend_width=1.2,
            legend_columns=0,
        )

        canvas.render(df, settings)

        legend = canvas.figure.axes[0].get_legend()
        self.assertEqual(getattr(legend, "_ncols", 1), 1)
        self.assertIn("\n", legend.get_texts()[0].get_text())

    def test_ridge_expands_left_margin_for_long_row_labels(self):
        window = app.MainWindow()
        df = app.pd.DataFrame({
            "A very long control group\nwith two lines": [1, 2, 3, 4],
            "低剂量处理组\n第二行": [2, 3, 4, 5],
            "High dose": [3, 4, 5, 6],
        })
        settings = app.ChartSettings(chart_type="Ridge", show_stat_table=True)
        window.canvas.render(df, settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        renderer = window.canvas.canvas.get_renderer()
        left_edges = [label.get_window_extent(renderer).x0 for label in plot_ax.get_yticklabels()]

        self.assertGreaterEqual(min(left_edges), 0)
        self.assertAlmostEqual(plot_ax.get_position().x0, table_ax.get_position().x0)

    def test_chinese_font_is_configured_for_matplotlib(self):
        self.assertNotEqual(app.DEFAULT_FONT_FAMILY, "DejaVu Sans")

    def test_chinese_text_renders_without_error(self):
        window = app.MainWindow()
        for col, label in enumerate(["对照组", "低剂量", "高剂量"]):
            window.table.setItem(0, col, app.QTableWidgetItem(label))
        window.settings.title = "分布图\n含所有数据点"
        window.settings.x_label = "分组\n处理条件"
        window.settings.y_label = "数值\n相对表达"
        window.canvas.render(window.table.dataframe(), window.settings)

    def test_multiline_labels_are_read_from_ui(self):
        window = app.MainWindow()
        window.title.setPlainText("Line 1\nLine 2")
        window.x_label.setPlainText("X 1\nX 2")
        window.y_label.setPlainText("Y 1\nY 2")
        window.update_settings()

        self.assertEqual(window.settings.title, "Line 1\nLine 2")
        self.assertEqual(window.settings.x_label, "X 1\nX 2")
        self.assertEqual(window.settings.y_label, "Y 1\nY 2")

    def test_multiline_group_names_are_preserved(self):
        window = app.MainWindow()
        window.table.setItem(0, 0, app.QTableWidgetItem("Control\nDay 1"))
        window.update_table_header_height()
        df = window.table.dataframe()
        clean = app.prepare_plot_data(df, window.settings)

        self.assertEqual(df.columns[0], "Control\nDay 1")
        self.assertIn("Control\nDay 1", set(clean["group"]))

        window.settings.chart_type = "Ridge"
        window.canvas.render(df, window.settings)
        labels = [tick.get_text() for tick in window.canvas.figure.axes[0].get_yticklabels()]
        self.assertIn("Control\nDay 1", labels)

    def test_table_header_height_grows_for_multiline_group_names(self):
        window = app.MainWindow()
        one_line_height = window.table.rowHeight(0)
        window.table.setItem(0, 0, app.QTableWidgetItem("A\nB\nC"))
        window.update_table_header_height()

        self.assertGreater(window.table.rowHeight(0), one_line_height)

    def test_table_columns_are_user_resizable(self):
        window = app.MainWindow()

        self.assertEqual(
            window.table.horizontalHeader().sectionResizeMode(0),
            app.QHeaderView.Interactive,
        )

    def test_copy_table_selection_uses_tsv_for_excel(self):
        window = app.MainWindow()
        window.table.setRangeSelected(app.QTableWidgetSelectionRange(0, 0, 1, 1), True)
        window.copy_table_selection()

        self.assertEqual(app.QApplication.clipboard().text(), "Control\tLow dose\n4.801\t6.29")

    def test_copy_table_selection_quotes_multiline_group_names(self):
        window = app.MainWindow()
        window.table.setItem(0, 0, app.QTableWidgetItem("Control\nDay 1"))
        window.table.setRangeSelected(app.QTableWidgetSelectionRange(0, 0, 0, 1), True)
        window.copy_table_selection()

        self.assertEqual(app.QApplication.clipboard().text(), '"Control\nDay 1"\tLow dose')

    def test_paste_table_selection_expands_table(self):
        window = app.MainWindow()
        window.table.setCurrentCell(34, 2)
        app.QApplication.clipboard().setText("1\t2\n3\t4")
        window.paste_table_selection()

        self.assertGreaterEqual(window.table.rowCount(), 36)
        self.assertGreaterEqual(window.table.columnCount(), 4)
        self.assertEqual(window.table.item(34, 2).text(), "1")
        self.assertEqual(window.table.item(35, 3).text(), "4")

    def test_paste_table_selection_undo_redo_is_single_table_change(self):
        window = app.MainWindow()
        original_rows = window.table.rowCount()
        original_cols = window.table.columnCount()
        window.table.setCurrentCell(34, 2)
        app.QApplication.clipboard().setText("1\t2\n3\t4")

        window.paste_table_selection()

        self.assertEqual(window.table.item(34, 2).text(), "1")

        window.undo_table_change()

        self.assertEqual(window.table.rowCount(), original_rows)
        self.assertEqual(window.table.columnCount(), original_cols)

        window.redo_table_change()

        self.assertGreaterEqual(window.table.rowCount(), 36)
        self.assertGreaterEqual(window.table.columnCount(), 4)
        self.assertEqual(window.table.item(35, 3).text(), "4")

    def test_paste_table_selection_can_replace_group_name_row(self):
        window = app.MainWindow()
        window.table.setCurrentCell(0, 0)
        app.QApplication.clipboard().setText('"Control\nDay 1"\tTreatment\n1\t2')
        window.paste_table_selection()

        self.assertEqual(window.table.item(0, 0).text(), "Control\nDay 1")
        self.assertEqual(list(window.table.dataframe().columns[:2]), ["Control\nDay 1", "Treatment"])

    def test_settings_still_refresh_after_excel_paste(self):
        window = app.MainWindow()
        window.table.setCurrentCell(0, 0)
        app.QApplication.clipboard().setText("A\tB\n1\t2\n3\t4")
        window.paste_table_selection()

        window.chart_type.setCurrentText("Ridge")
        app.QApplication.processEvents()

        self.assertEqual(window.canvas._last_settings.chart_type, "Ridge")

    def test_delete_column_removes_current_column(self):
        window = app.MainWindow()
        window.table.setCurrentCell(0, 1)
        window.delete_column()

        self.assertEqual(window.table.columnCount(), 2)
        self.assertEqual(window.table.item(0, 1).text(), "High dose")

    def test_delete_column_syncs_manual_group_order(self):
        window = app.MainWindow()
        window.settings.group_order = "Manual"
        window.settings.manual_group_order = ["High dose", "Low dose", "Control"]
        window.table.setCurrentCell(0, 1)
        window.delete_column()

        self.assertEqual(window.settings.manual_group_order, ["High dose", "Control"])


if __name__ == "__main__":
    unittest.main()
