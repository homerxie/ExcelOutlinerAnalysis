# EasyGraph

EasyGraph is a local Python/PySide6 desktop demo for lightweight scientific distribution plots. It is intentionally simpler than GraphPad-style software and focuses on a fast workflow for box plots, violin plots, and ridge plots.

## Quick Start

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
source .venv/bin/activate
python src/app.py
```

If dependencies are missing:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
source .venv/bin/activate
pip install -r requirements.txt
```

## Windows Packaging

For Windows wheel installation and PyInstaller packaging notes, see
`WINDOWS_BUILD.md`. The Windows dependency file is `requirements-windows.txt`.

Create a source package for transfer to Windows:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
python scripts/package_windows_release.py
```

## Core Features

- Editable in-app table using a wide data format.
- Box plot, violin plot, and ridge plot.
- Show all data points over distributions.
- Data point jitter modes: `Quasirandom` by default, plus `Beeswarm` and `Random`.
- Outlier detection with IQR, Z-score, MAD, or percentile rules.
- Outlier behavior: `Mark only` or `Exclude from distribution`.
- Box whisker modes: Tukey 1.5 IQR, Min-Max, Percentile 5-95, Percentile 10-90.
- Professional presets and transparent background support.
- Copy current figure to clipboard as PNG, with transparent background when enabled.
- Export PNG, SVG, PDF, TIFF, TIF, JPG, or JPEG through Matplotlib.
- Save/open project files with the `.eg` suffix.
- Import/export Excel and CSV.
- Manual group ordering, including a drag-and-drop order dialog.

## Important Data Model

The table is wide-format:

```text
row 1: group names
row 2+: numeric values
```

The first visible row is not a normal data row. It is the group-name row and is styled differently in the UI. When plotting, EasyGraph treats row 1 as the group labels and all rows below it as values.

Group names support forced line breaks. Multiline group names are preserved in:

- the table
- plotted tick labels
- project files
- Excel/TSV copy and paste

Copy/paste is TSV-compatible for Excel. When a group name contains a newline, the TSV writer quotes the cell so Excel can keep it as one cell.

Duplicate group names are allowed. During plotting, duplicate-named columns are combined into one group. Group sorting by mean/median uses the combined values.

## Project File Format

Project files use the `.eg` suffix. The file is a zip archive, not a custom binary format.

```text
example.eg
├── data.csv
├── settings.json
└── project.json
```

- `data.csv`: the wide table. CSV headers are the group names; rows below are values.
- `settings.json`: serialized `ChartSettings` from `src/app.py`.
- `project.json`: metadata, currently `{ "version": 1, "app": "EasyGraph" }`.

Older `.gplite` files use the same internal structure. They can still be opened through `All Files (*)` in the open dialog.

## Main Files

```text
src/app.py
src/ui_main_window.py
src/ui_group_order_dialog.py
ui/main_window.ui
ui/group_order_dialog.ui
tests/test_core.py
requirements.txt
```

- `src/app.py`: application logic, plotting, file I/O, table behavior, settings, and tests-facing helpers.
- `ui/main_window.ui`: main UI source of truth.
- `ui/group_order_dialog.ui`: manual group-order dialog source of truth.
- `src/ui_main_window.py`: generated from `ui/main_window.ui`.
- `src/ui_group_order_dialog.py`: generated from `ui/group_order_dialog.ui`.
- `tests/test_core.py`: regression tests for plotting data, table behavior, copy/paste, project roundtrip, UI settings, Chinese text, and duplicate group names.

## UI Workflow

All UI layout/widget changes should be made in `.ui` files first.

Regenerate generated Python after editing the main window:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
./.venv/bin/pyside6-uic ui/main_window.ui -o src/ui_main_window.py
```

Regenerate generated Python after editing the group-order dialog:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o src/ui_group_order_dialog.py
```

Do not hand-edit generated `src/ui_*.py` files unless there is a temporary debugging reason. Regenerate them from `.ui` instead.

## Translation Workflow

EasyGraph uses Qt's native translation toolchain. Static UI text comes from
`ui/*.ui`, generated `src/ui_*.py` files use `QCoreApplication.translate(...)`,
and runtime text in `src/app.py` should use `self.tr(...)`.

Simplified Chinese is available from the app's `Language` menu. Changing the
language preference is saved with `QSettings` and takes effect after restarting
EasyGraph. The `EASYGRAPH_LANGUAGE` environment variable can override the saved
preference for testing, for example:

```bash
EASYGRAPH_LANGUAGE=zh_CN python src/app.py
```

When UI text changes, update the translation source file:

```bash
./scripts/update_translations.sh
```

Then open `translations/easygraph_zh_CN.ts` in Qt Linguist, review any
unfinished entries, and compile the runtime translation file:

```bash
./scripts/compile_translations.sh
```

Keep chart option values such as `Box`, `Median`, and `Table order` in English.
They are project/template settings values, not ordinary UI labels.

## Plotting Stack

- Matplotlib owns the figure, canvas, export, clipboard image, and detailed rendering.
- Seaborn is used as a styling and categorical-plot helper for box/violin behavior.
- SciPy `gaussian_kde` is used for ridge distributions.
- Pandas is still used internally for table-to-plot transformations and Excel/CSV I/O.

The app does not support double-click-to-edit plot elements. Plot style is controlled from the right-side settings panel.

## Canvas Behavior

The plot preview uses a fixed physical size in centimeters from settings:

- Width and height are stored in cm.
- Preview has scrollbars if the canvas is larger than the center viewport.
- Ctrl+wheel zoom is supported.
- Trackpad/native pinch zoom is handled where Qt exposes native/pinch gestures.

The rendered figure can have a transparent background. Clipboard copy and export respect the transparent background setting.

## Table Behavior

- The first table row is the group-name row.
- The top horizontal header only shows numeric column indices for resizing/orientation.
- Columns are user-resizable.
- Add row, add column, rename group, delete column are supported.
- Copy/paste works with Excel-style TSV.
- Pasting can expand row/column count.
- Delete clears selected cells.
- Editing row 1 updates group names, manual group order, row height, and plot rendering.

Important implementation details:

- `MainWindow.table_dataframe()` converts the visible table to a pandas DataFrame.
- `MainWindow.set_table_dataframe()` loads a DataFrame into the visible table with group names in row 1.
- `prepare_plot_data()` converts wide data to long plot data.
- `values_for_group()` combines duplicate group-name columns safely.
- `ordered_group_columns()` handles table order, manual order, name sorting, and statistic sorting.

## Settings Highlights

`ChartSettings` in `src/app.py` is the project-serializable settings object. Important fields include:

- `chart_type`: Box, Violin, Ridge.
- `preset`: visual preset key.
- `group_order`: Table order, Manual, Name A-Z, Name Z-A, Mean ascending/descending, Median ascending/descending.
- `manual_group_order`: saved manual order list.
- title/group label/value label text, including multiline text.
- canvas width/height in cm, DPI, transparent background.
- title/axis/tick font sizes.
- grid, axis range, axis line width, tick rotation.
- point display, point size, point alpha, jitter mode, jitter amount.
- outlier method, threshold, highlight, and effect.
- box/violin/ridge-specific width/bandwidth/overlap controls.

## Testing

Run the full test suite headlessly:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest discover -s tests -v
```

Compile-check key Python files:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
./.venv/bin/python -m py_compile src/app.py src/ui_main_window.py src/ui_group_order_dialog.py tests/test_core.py
```

Current expected test count at this handoff: 25 tests.

## Known Warnings

The test suite may show Seaborn/Matplotlib warnings such as:

- `PendingDeprecationWarning: vert: bool will be deprecated...`
- Qt font alias timing warnings.

These warnings are currently non-fatal and tests pass with them.

## Agent Handoff Notes

- The project lives at `/Users/xiezihong/Documents/Programming/EasyGraph`, not the current Codex workspace.
- In the Codex sandbox, this path may require escalated shell permissions.
- Prefer `rg` for searching.
- Use `apply_patch` for manual edits.
- UI changes must start in `.ui` files, then regenerate `src/ui_*.py`.
- Avoid reverting user changes.
- The app is not currently a git repo in this folder.
- If paste/refresh bugs appear, inspect table event handling, `paste_table_selection()`, and `handle_table_item_changed()` first.
- If plotting crashes after editing group names, check duplicate group-name handling in `values_for_group()` and `ordered_group_columns()`.
- If Chinese text renders as boxes, inspect `configure_matplotlib_fonts()` and available system fonts.
