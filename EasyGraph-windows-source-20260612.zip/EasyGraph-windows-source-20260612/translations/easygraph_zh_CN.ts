<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>GroupOrderDialog</name>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="6"/>
        <source>Edit Group Order</source>
        <translation>编辑分组顺序</translation>
    </message>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="15"/>
        <source>Drag groups to change plot order.</source>
        <translation>拖动分组以调整绘图顺序。</translation>
    </message>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="37"/>
        <source>Table Order</source>
        <translation>表格顺序</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/app.py" line="2039"/>
        <source>Colors</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2067"/>
        <source>Legend size</source>
        <translation>图例字号</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2068"/>
        <source>Legend</source>
        <translation>图例</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2088"/>
        <location filename="../src/app.py" line="3942"/>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Auto wrap</source>
        <translation type="vanished">自动换行</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2090"/>
        <source>Columns</source>
        <translation>列数</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2423"/>
        <source>Overlay filter</source>
        <translation>叠加线过滤器</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2429"/>
        <source>Show custom overlays</source>
        <translation>显示自定义叠加线</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2535"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2539"/>
        <source>System</source>
        <translation>跟随系统</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2541"/>
        <source>Simplified Chinese</source>
        <translation>简体中文</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2560"/>
        <source>Language changed</source>
        <translation>语言已更改</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2561"/>
        <source>Restart EasyGraph to apply the language change.</source>
        <translation>重启 EasyGraph 后语言更改会生效。</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2854"/>
        <location filename="../src/app.py" line="2859"/>
        <source>Group Filter</source>
        <translation>分组过滤器</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2855"/>
        <source>Add a group first.</source>
        <translation>请先一个添加分组。</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2900"/>
        <source>Overlay: {name}</source>
        <translation>叠加线：{name}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2918"/>
        <source>Edit Group Colors</source>
        <translation>编辑分组颜色</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2922"/>
        <source>Palette</source>
        <translation>调色板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2934"/>
        <source>Overlay palette</source>
        <translation>叠加线调色板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3084"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2871"/>
        <location filename="../src/app.py" line="3126"/>
        <location filename="../src/app.py" line="3466"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2044"/>
        <source>Secondary value 
axis title</source>
        <translation>次数值
坐标轴标题</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2872"/>
        <location filename="../src/app.py" line="3127"/>
        <location filename="../src/app.py" line="3467"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3360"/>
        <source>Style template applied: {name}</source>
        <translation>已应用样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3368"/>
        <location filename="../src/app.py" line="3836"/>
        <location filename="../src/app.py" line="3860"/>
        <source>Template load failed</source>
        <translation>模板加载失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3413"/>
        <source>Delete Overlay</source>
        <translation>删除叠加线</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3414"/>
        <source>Delete overlay &apos;{name}&apos;? Its values will be permanently lost.</source>
        <translation>确认删除叠加线{name}? 叠加线对应数值将被永久删除。</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3448"/>
        <location filename="../src/app.py" line="3453"/>
        <source>Overlay Filter</source>
        <translation>叠加线过滤器</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3449"/>
        <source>Add an overlay row first.</source>
        <translation>请先添加一行叠加线。</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3490"/>
        <source>Rename Overlay</source>
        <translation>重命名叠加线</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3490"/>
        <source>Legend name</source>
        <translation>图例名称</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3533"/>
        <source>Group name</source>
        <translation>分组名称</translation>
    </message>
    <message>
        <source>Auto X range</source>
        <translation type="vanished">自动 X 范围</translation>
    </message>
    <message>
        <source>X min</source>
        <translation type="vanished">X 最小值</translation>
    </message>
    <message>
        <source>X max</source>
        <translation type="vanished">X 最大值</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3842"/>
        <source>Save Style Template</source>
        <translation>保存样式模板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3842"/>
        <source>Template name</source>
        <translation>模板名称</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3848"/>
        <source>Template save failed</source>
        <translation>模板保存失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3851"/>
        <source>Style template saved: {name}</source>
        <translation>已保存样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3854"/>
        <source>Load Style Template</source>
        <translation>加载样式模板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3854"/>
        <source>Style Template (*.json);;All Files (*)</source>
        <translation>样式模板 (*.json);;所有文件 (*)</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3865"/>
        <source>Style template loaded: {name}</source>
        <translation>已加载样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3875"/>
        <location filename="../src/app.py" line="3881"/>
        <source>EasyGraph Project (*.eg);;All Files (*)</source>
        <translation>EasyGraph 项目 (*.eg);;所有文件 (*)</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4018"/>
        <source>Figure image copied to clipboard</source>
        <translation>图形图片已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4020"/>
        <source>Copy failed</source>
        <translation>复制失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4020"/>
        <source>Could not copy the figure to the clipboard.</source>
        <translation>无法将图形复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="14"/>
        <source>EasyGraph</source>
        <translation>EasyGraph</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="55"/>
        <source>Data</source>
        <translation>数据</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="67"/>
        <source>+ Row</source>
        <translation>+ 行</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="74"/>
        <source>+ Column</source>
        <translation>+ 列</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="81"/>
        <source>- Column</source>
        <translation>- 列</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3533"/>
        <location filename="../ui/main_window.ui" line="88"/>
        <source>Rename Group</source>
        <translation>重命名分组</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="180"/>
        <source>Style Templates</source>
        <translation>样式模板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="206"/>
        <source>Load...</source>
        <translation>加载...</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="213"/>
        <source>Save Current</source>
        <translation>保存当前</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="225"/>
        <source>Chart</source>
        <translation>图表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="258"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="300"/>
        <source>Preset</source>
        <translation>预设</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="342"/>
        <source>Group order</source>
        <translation>分组顺序</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="382"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="391"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2051"/>
        <location filename="../ui/main_window.ui" line="413"/>
        <location filename="../ui/main_window.ui" line="442"/>
        <location filename="../ui/main_window.ui" line="472"/>
        <source>Enter to line break</source>
        <translation>按 Enter 换行</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="420"/>
        <source>Group axis title</source>
        <translation>分组坐标轴标题</translation>
    </message>
    <message>
        <source>Primary value axis title</source>
        <translation type="vanished">主数值坐标轴标题</translation>
    </message>
    <message>
        <source>Secondary value axis title</source>
        <translation type="vanished">次数值坐标轴标题</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2173"/>
        <source>Use secondary axis</source>
        <translation>使用次坐标轴</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2099"/>
        <source>Auto Secondary Y Range</source>
        <translation>自动次 Y 范围</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2109"/>
        <source>Secondary Y min</source>
        <translation>次 Y 轴 min</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2116"/>
        <source>Secondary Y max</source>
        <translation>次 Y 轴 max</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2123"/>
        <source>Split secondary frame</source>
        <translation>拆分次坐标轴绘图区</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2133"/>
        <source>Secondary frame ratio</source>
        <translation>次坐标轴绘图区占比</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="2089"/>
        <source>Width (cm)</source>
        <translation>宽度 (cm)</translation>
    </message>
    <message>
        <source>Height (cm)</source>
        <translation type="vanished">高度 (cm)</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="583"/>
        <source>Export DPI</source>
        <translation>导出 DPI</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="635"/>
        <source>Transparent bg</source>
        <translation>透明背景</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="725"/>
        <location filename="../ui/main_window.ui" line="2962"/>
        <source>Copy as Image</source>
        <translation>复制为图片</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="737"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="823"/>
        <source>Title size</source>
        <translation>标题字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="872"/>
        <source>Axis label size</source>
        <translation>坐标轴标签字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="921"/>
        <source>Tick size</source>
        <translation>刻度字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="970"/>
        <source>Overlay value size</source>
        <translation>叠加数值字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1022"/>
        <source>Stats table size</source>
        <translation>统计表字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1077"/>
        <source>Axis</source>
        <translation>坐标轴</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1110"/>
        <source>Show grid</source>
        <translation>显示网格</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3707"/>
        <location filename="../ui/main_window.ui" line="1152"/>
        <source>Auto Primary Y Range</source>
        <translation>自动主 Y 范围</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3708"/>
        <location filename="../ui/main_window.ui" line="1194"/>
        <source>Primary Y min</source>
        <translation>主 Y 轴 min</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3709"/>
        <location filename="../ui/main_window.ui" line="1246"/>
        <source>Primary Y max</source>
        <translation>主 Y 轴 max</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1298"/>
        <source>Axis line width</source>
        <translation>坐标轴线宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1350"/>
        <source>X label rotation</source>
        <translation>X 标签旋转</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1405"/>
        <source>Data Points</source>
        <translation>数据点</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1438"/>
        <source>Show all points</source>
        <translation>显示所有点</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1480"/>
        <location filename="../ui/main_window.ui" line="1993"/>
        <source>Point size</source>
        <translation>点大小</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1532"/>
        <source>Point alpha</source>
        <translation>点透明度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1584"/>
        <source>Jitter mode</source>
        <translation>抖动模式</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1626"/>
        <source>Jitter</source>
        <translation>抖动</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1681"/>
        <source>Line Overlay</source>
        <translation>折线叠加</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1714"/>
        <source>Show line</source>
        <translation>显示折线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1756"/>
        <source>Trend overlay</source>
        <translation>趋势叠加</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1798"/>
        <source>Extra custom overlay</source>
        <translation>额外自定义叠加线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1840"/>
        <source>Custom line count</source>
        <translation>自定义线数量</translation>
    </message>
    <message>
        <source>Statistic</source>
        <translation type="vanished">统计量</translation>
    </message>
    <message>
        <source>Overlay +</source>
        <translation type="vanished">叠加线 +</translation>
    </message>
    <message>
        <source>Overlay -</source>
        <translation type="vanished">叠加线 -</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="95"/>
        <source>+ Overlay</source>
        <translation>+ 叠加线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="102"/>
        <source>- Overlay</source>
        <translation>- 叠加线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="449"/>
        <source>Primary value 
axis title</source>
        <translation>主数值
坐标轴标题</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="479"/>
        <source>Plot area width (cm)</source>
        <translation>绘图区宽度 (cm)</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="531"/>
        <source>Plot area height (cm)</source>
        <translation>绘图区高度 (cm)</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="677"/>
        <source>Group filter</source>
        <translation>分组过滤器</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="699"/>
        <location filename="../ui/main_window.ui" line="1890"/>
        <source>Filter</source>
        <translation>过滤</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="770"/>
        <source>All sizes</source>
        <translation>全部字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="807"/>
        <source>A-</source>
        <translation>A-</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="814"/>
        <source>A+</source>
        <translation>A+</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1899"/>
        <source>Line width</source>
        <translation>线宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1951"/>
        <source>Line style</source>
        <translation>线型</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2045"/>
        <source>Show values</source>
        <translation>显示数值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2087"/>
        <source>Label position</source>
        <translation>标签位置</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2129"/>
        <source>Extra label position</source>
        <translation>额外标签位置</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2171"/>
        <source>Scientific</source>
        <translation>科学计数法</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2213"/>
        <source>Decimals</source>
        <translation>小数位数</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2268"/>
        <source>Stats Table</source>
        <translation>统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2289"/>
        <source>Show statistics table</source>
        <translation>显示统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2299"/>
        <source>Show header</source>
        <translation>显示表头</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2334"/>
        <source>Outliers</source>
        <translation>离群值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2367"/>
        <source>Highlight</source>
        <translation>高亮</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2409"/>
        <source>Method</source>
        <translation>方法</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2451"/>
        <source>Threshold</source>
        <translation>阈值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2503"/>
        <source>Effect</source>
        <translation>效果</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2548"/>
        <source>Type-specific</source>
        <translation>类型专属</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2581"/>
        <source>Box width</source>
        <translation>箱体宽度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2633"/>
        <source>Box whisker mode</source>
        <translation>箱线须模式</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2675"/>
        <source>Violin width</source>
        <translation>小提琴宽度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2727"/>
        <source>KDE bandwidth</source>
        <translation>KDE 带宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2779"/>
        <source>Ridge overlap</source>
        <translation>山脊重叠</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2831"/>
        <source>Fill alpha</source>
        <translation>填充透明度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2914"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2932"/>
        <source>New</source>
        <translation>新建</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3881"/>
        <location filename="../ui/main_window.ui" line="2937"/>
        <source>Open Project</source>
        <translation>打开项目</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3875"/>
        <location filename="../ui/main_window.ui" line="2942"/>
        <source>Save Project</source>
        <translation>保存项目</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2947"/>
        <source>Save Project As</source>
        <translation>项目另存为</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3966"/>
        <location filename="../ui/main_window.ui" line="2952"/>
        <source>Import Excel</source>
        <translation>导入 Excel</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3966"/>
        <source>Excel Files (*.xlsx *.xls);;CSV Files (*.csv)</source>
        <translation>Excel 文件 (*.xlsx *.xls);;CSV 文件 (*.csv)</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3974"/>
        <source>Import failed</source>
        <translation>导入失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3977"/>
        <location filename="../ui/main_window.ui" line="2957"/>
        <source>Export Excel</source>
        <translation>导出 Excel</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3977"/>
        <source>Excel File (*.xlsx);;CSV File (*.csv)</source>
        <translation>Excel 文件 (*.xlsx);;CSV 文件 (*.csv)</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3988"/>
        <source>Export failed</source>
        <translation>导出失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4000"/>
        <location filename="../ui/main_window.ui" line="2967"/>
        <source>Export Figure</source>
        <translation>导出图形</translation>
    </message>
</context>
</TS>
