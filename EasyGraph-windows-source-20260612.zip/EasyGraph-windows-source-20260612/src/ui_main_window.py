# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QDoubleSpinBox, QFormLayout, QFrame, QGroupBox,
    QHBoxLayout, QHeaderView, QLabel, QListWidget,
    QListWidgetItem, QMainWindow, QMenu, QMenuBar,
    QPlainTextEdit, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QSpinBox, QSplitter, QStatusBar,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1280, 760)
        self.actionNew = QAction(MainWindow)
        self.actionNew.setObjectName(u"actionNew")
        self.actionOpenProject = QAction(MainWindow)
        self.actionOpenProject.setObjectName(u"actionOpenProject")
        self.actionSaveProject = QAction(MainWindow)
        self.actionSaveProject.setObjectName(u"actionSaveProject")
        self.actionSaveProjectAs = QAction(MainWindow)
        self.actionSaveProjectAs.setObjectName(u"actionSaveProjectAs")
        self.actionImportExcel = QAction(MainWindow)
        self.actionImportExcel.setObjectName(u"actionImportExcel")
        self.actionExportExcel = QAction(MainWindow)
        self.actionExportExcel.setObjectName(u"actionExportExcel")
        self.actionCopyFigure = QAction(MainWindow)
        self.actionCopyFigure.setObjectName(u"actionCopyFigure")
        self.actionExportFigure = QAction(MainWindow)
        self.actionExportFigure.setObjectName(u"actionExportFigure")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralLayout = QHBoxLayout(self.centralwidget)
        self.centralLayout.setObjectName(u"centralLayout")
        self.centralLayout.setContentsMargins(0, 0, 0, 0)
        self.mainSplitter = QSplitter(self.centralwidget)
        self.mainSplitter.setObjectName(u"mainSplitter")
        self.mainSplitter.setOrientation(Qt.Orientation.Horizontal)
        self.dataPanel = QWidget(self.mainSplitter)
        self.dataPanel.setObjectName(u"dataPanel")
        self.dataLayout = QVBoxLayout(self.dataPanel)
        self.dataLayout.setSpacing(8)
        self.dataLayout.setObjectName(u"dataLayout")
        self.dataLayout.setContentsMargins(10, 10, 8, 10)
        self.dataLabel = QLabel(self.dataPanel)
        self.dataLabel.setObjectName(u"dataLabel")

        self.dataLayout.addWidget(self.dataLabel)

        self.dataButtonLayout = QHBoxLayout()
        self.dataButtonLayout.setSpacing(6)
        self.dataButtonLayout.setObjectName(u"dataButtonLayout")
        self.addRowButton = QPushButton(self.dataPanel)
        self.addRowButton.setObjectName(u"addRowButton")

        self.dataButtonLayout.addWidget(self.addRowButton)

        self.addColumnButton = QPushButton(self.dataPanel)
        self.addColumnButton.setObjectName(u"addColumnButton")

        self.dataButtonLayout.addWidget(self.addColumnButton)

        self.deleteColumnButton = QPushButton(self.dataPanel)
        self.deleteColumnButton.setObjectName(u"deleteColumnButton")

        self.dataButtonLayout.addWidget(self.deleteColumnButton)

        self.renameColumnButton = QPushButton(self.dataPanel)
        self.renameColumnButton.setObjectName(u"renameColumnButton")

        self.dataButtonLayout.addWidget(self.renameColumnButton)

        self.addOverlayButton = QPushButton(self.dataPanel)
        self.addOverlayButton.setObjectName(u"addOverlayButton")

        self.dataButtonLayout.addWidget(self.addOverlayButton)

        self.removeOverlayButton = QPushButton(self.dataPanel)
        self.removeOverlayButton.setObjectName(u"removeOverlayButton")

        self.dataButtonLayout.addWidget(self.removeOverlayButton)


        self.dataLayout.addLayout(self.dataButtonLayout)

        self.dataTable = QTableWidget(self.dataPanel)
        self.dataTable.setObjectName(u"dataTable")
        self.dataTable.setAlternatingRowColors(True)

        self.dataLayout.addWidget(self.dataTable)

        self.mainSplitter.addWidget(self.dataPanel)
        self.plotHost = QWidget(self.mainSplitter)
        self.plotHost.setObjectName(u"plotHost")
        self.plotHostLayout = QVBoxLayout(self.plotHost)
        self.plotHostLayout.setObjectName(u"plotHostLayout")
        self.plotHostLayout.setContentsMargins(0, 0, 0, 0)
        self.mainSplitter.addWidget(self.plotHost)
        self.controlsScroll = QScrollArea(self.mainSplitter)
        self.controlsScroll.setObjectName(u"controlsScroll")
        self.controlsScroll.setMinimumSize(QSize(420, 0))
        self.controlsScroll.setFrameShape(QFrame.Shape.NoFrame)
        self.controlsScroll.setWidgetResizable(True)
        self.controlsContent = QWidget()
        self.controlsContent.setObjectName(u"controlsContent")
        self.controlsContent.setGeometry(QRect(0, 0, 554, 2330))
        self.controlsContent.setMinimumSize(QSize(420, 0))
        self.controlsLayout = QVBoxLayout(self.controlsContent)
        self.controlsLayout.setSpacing(10)
        self.controlsLayout.setObjectName(u"controlsLayout")
        self.controlsLayout.setContentsMargins(8, 10, 10, 10)
        self.templateGroup = QGroupBox(self.controlsContent)
        self.templateGroup.setObjectName(u"templateGroup")
        self.templateLayout = QVBoxLayout(self.templateGroup)
        self.templateLayout.setSpacing(8)
        self.templateLayout.setObjectName(u"templateLayout")
        self.templateLayout.setContentsMargins(8, 10, 8, 8)
        self.templateCombo = QComboBox(self.templateGroup)
        self.templateCombo.setObjectName(u"templateCombo")

        self.templateLayout.addWidget(self.templateCombo)

        self.templateButtonLayout = QHBoxLayout()
        self.templateButtonLayout.setObjectName(u"templateButtonLayout")
        self.loadTemplateButton = QPushButton(self.templateGroup)
        self.loadTemplateButton.setObjectName(u"loadTemplateButton")

        self.templateButtonLayout.addWidget(self.loadTemplateButton)

        self.saveTemplateButton = QPushButton(self.templateGroup)
        self.saveTemplateButton.setObjectName(u"saveTemplateButton")

        self.templateButtonLayout.addWidget(self.saveTemplateButton)


        self.templateLayout.addLayout(self.templateButtonLayout)


        self.controlsLayout.addWidget(self.templateGroup)

        self.chartGroup = QGroupBox(self.controlsContent)
        self.chartGroup.setObjectName(u"chartGroup")
        self.chartForm = QFormLayout(self.chartGroup)
        self.chartForm.setObjectName(u"chartForm")
        self.chartForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.chartForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.chartForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.chartForm.setHorizontalSpacing(12)
        self.chartForm.setVerticalSpacing(6)
        self.chartForm.setContentsMargins(8, 10, 8, 8)
        self.chartTypeLabel = QLabel(self.chartGroup)
        self.chartTypeLabel.setObjectName(u"chartTypeLabel")

        self.chartForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.chartTypeLabel)

        self.chartTypeComboFieldLayout = QHBoxLayout()
        self.chartTypeComboFieldLayout.setSpacing(0)
        self.chartTypeComboFieldLayout.setObjectName(u"chartTypeComboFieldLayout")
        self.chartTypeComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.chartTypeComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.chartTypeComboFieldLayout.addItem(self.chartTypeComboLeftSpacer)

        self.chartTypeCombo = QComboBox(self.chartGroup)
        self.chartTypeCombo.setObjectName(u"chartTypeCombo")

        self.chartTypeComboFieldLayout.addWidget(self.chartTypeCombo)


        self.chartForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.chartTypeComboFieldLayout)

        self.presetLabel = QLabel(self.chartGroup)
        self.presetLabel.setObjectName(u"presetLabel")

        self.chartForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.presetLabel)

        self.presetComboFieldLayout = QHBoxLayout()
        self.presetComboFieldLayout.setSpacing(6)
        self.presetComboFieldLayout.setObjectName(u"presetComboFieldLayout")
        self.presetComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.presetComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.presetComboFieldLayout.addItem(self.presetComboLeftSpacer)

        self.presetCombo = QComboBox(self.chartGroup)
        self.presetCombo.setObjectName(u"presetCombo")

        self.presetComboFieldLayout.addWidget(self.presetCombo)


        self.chartForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.presetComboFieldLayout)

        self.groupOrderLabel = QLabel(self.chartGroup)
        self.groupOrderLabel.setObjectName(u"groupOrderLabel")

        self.chartForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.groupOrderLabel)

        self.groupOrderLayout = QHBoxLayout()
        self.groupOrderLayout.setSpacing(6)
        self.groupOrderLayout.setObjectName(u"groupOrderLayout")
        self.groupOrderLayout.setContentsMargins(0, 0, 0, 0)
        self.groupOrderLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.groupOrderLayout.addItem(self.groupOrderLeftSpacer)

        self.groupOrderCombo = QComboBox(self.chartGroup)
        self.groupOrderCombo.setObjectName(u"groupOrderCombo")

        self.groupOrderLayout.addWidget(self.groupOrderCombo)

        self.editGroupOrderButton = QPushButton(self.chartGroup)
        self.editGroupOrderButton.setObjectName(u"editGroupOrderButton")

        self.groupOrderLayout.addWidget(self.editGroupOrderButton)


        self.chartForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.groupOrderLayout)

        self.titleLabel = QLabel(self.chartGroup)
        self.titleLabel.setObjectName(u"titleLabel")

        self.chartForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.titleLabel)

        self.titleEdit = QPlainTextEdit(self.chartGroup)
        self.titleEdit.setObjectName(u"titleEdit")
        self.titleEdit.setMinimumSize(QSize(0, 44))
        self.titleEdit.setMaximumSize(QSize(16777215, 48))
        self.titleEdit.setTabChangesFocus(True)

        self.chartForm.setWidget(4, QFormLayout.ItemRole.FieldRole, self.titleEdit)

        self.xLabelLabel = QLabel(self.chartGroup)
        self.xLabelLabel.setObjectName(u"xLabelLabel")

        self.chartForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.xLabelLabel)

        self.xLabelEdit = QPlainTextEdit(self.chartGroup)
        self.xLabelEdit.setObjectName(u"xLabelEdit")
        self.xLabelEdit.setMinimumSize(QSize(0, 44))
        self.xLabelEdit.setMaximumSize(QSize(16777215, 48))
        self.xLabelEdit.setTabChangesFocus(True)

        self.chartForm.setWidget(5, QFormLayout.ItemRole.FieldRole, self.xLabelEdit)

        self.yLabelLabel = QLabel(self.chartGroup)
        self.yLabelLabel.setObjectName(u"yLabelLabel")

        self.chartForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.yLabelLabel)

        self.yLabelEdit = QPlainTextEdit(self.chartGroup)
        self.yLabelEdit.setObjectName(u"yLabelEdit")
        self.yLabelEdit.setMinimumSize(QSize(0, 44))
        self.yLabelEdit.setMaximumSize(QSize(16777215, 48))
        self.yLabelEdit.setTabChangesFocus(True)

        self.chartForm.setWidget(6, QFormLayout.ItemRole.FieldRole, self.yLabelEdit)

        self.widthLabel = QLabel(self.chartGroup)
        self.widthLabel.setObjectName(u"widthLabel")

        self.chartForm.setWidget(7, QFormLayout.ItemRole.LabelRole, self.widthLabel)

        self.widthSpinFieldLayout = QHBoxLayout()
        self.widthSpinFieldLayout.setSpacing(0)
        self.widthSpinFieldLayout.setObjectName(u"widthSpinFieldLayout")
        self.widthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.widthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.widthSpinFieldLayout.addItem(self.widthSpinLeftSpacer)

        self.widthSpin = QDoubleSpinBox(self.chartGroup)
        self.widthSpin.setObjectName(u"widthSpin")
        self.widthSpin.setMinimum(4.000000000000000)
        self.widthSpin.setMaximum(40.000000000000000)
        self.widthSpin.setSingleStep(0.500000000000000)

        self.widthSpinFieldLayout.addWidget(self.widthSpin)


        self.chartForm.setLayout(7, QFormLayout.ItemRole.FieldRole, self.widthSpinFieldLayout)

        self.heightLabel = QLabel(self.chartGroup)
        self.heightLabel.setObjectName(u"heightLabel")

        self.chartForm.setWidget(8, QFormLayout.ItemRole.LabelRole, self.heightLabel)

        self.heightSpinFieldLayout = QHBoxLayout()
        self.heightSpinFieldLayout.setSpacing(0)
        self.heightSpinFieldLayout.setObjectName(u"heightSpinFieldLayout")
        self.heightSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.heightSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.heightSpinFieldLayout.addItem(self.heightSpinLeftSpacer)

        self.heightSpin = QDoubleSpinBox(self.chartGroup)
        self.heightSpin.setObjectName(u"heightSpin")
        self.heightSpin.setMinimum(4.000000000000000)
        self.heightSpin.setMaximum(30.000000000000000)
        self.heightSpin.setSingleStep(0.500000000000000)

        self.heightSpinFieldLayout.addWidget(self.heightSpin)


        self.chartForm.setLayout(8, QFormLayout.ItemRole.FieldRole, self.heightSpinFieldLayout)

        self.dpiLabel = QLabel(self.chartGroup)
        self.dpiLabel.setObjectName(u"dpiLabel")

        self.chartForm.setWidget(9, QFormLayout.ItemRole.LabelRole, self.dpiLabel)

        self.dpiSpinFieldLayout = QHBoxLayout()
        self.dpiSpinFieldLayout.setSpacing(0)
        self.dpiSpinFieldLayout.setObjectName(u"dpiSpinFieldLayout")
        self.dpiSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.dpiSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.dpiSpinFieldLayout.addItem(self.dpiSpinLeftSpacer)

        self.dpiSpin = QSpinBox(self.chartGroup)
        self.dpiSpin.setObjectName(u"dpiSpin")
        self.dpiSpin.setMinimum(72)
        self.dpiSpin.setMaximum(1200)
        self.dpiSpin.setSingleStep(25)

        self.dpiSpinFieldLayout.addWidget(self.dpiSpin)


        self.chartForm.setLayout(9, QFormLayout.ItemRole.FieldRole, self.dpiSpinFieldLayout)

        self.transparentLabel = QLabel(self.chartGroup)
        self.transparentLabel.setObjectName(u"transparentLabel")

        self.chartForm.setWidget(10, QFormLayout.ItemRole.LabelRole, self.transparentLabel)

        self.transparentBackgroundCheckFieldLayout = QHBoxLayout()
        self.transparentBackgroundCheckFieldLayout.setSpacing(0)
        self.transparentBackgroundCheckFieldLayout.setObjectName(u"transparentBackgroundCheckFieldLayout")
        self.transparentBackgroundCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.transparentBackgroundCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.transparentBackgroundCheckFieldLayout.addItem(self.transparentBackgroundCheckLeftSpacer)

        self.transparentBackgroundCheck = QCheckBox(self.chartGroup)
        self.transparentBackgroundCheck.setObjectName(u"transparentBackgroundCheck")

        self.transparentBackgroundCheckFieldLayout.addWidget(self.transparentBackgroundCheck)


        self.chartForm.setLayout(10, QFormLayout.ItemRole.FieldRole, self.transparentBackgroundCheckFieldLayout)

        self.groupFilterLabel = QLabel(self.chartGroup)
        self.groupFilterLabel.setObjectName(u"groupFilterLabel")

        self.chartForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.groupFilterLabel)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.groupFilterButton = QPushButton(self.chartGroup)
        self.groupFilterButton.setObjectName(u"groupFilterButton")

        self.horizontalLayout.addWidget(self.groupFilterButton)


        self.chartForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.horizontalLayout)

        self.copyFigureButtonFieldLayout = QHBoxLayout()
        self.copyFigureButtonFieldLayout.setSpacing(0)
        self.copyFigureButtonFieldLayout.setObjectName(u"copyFigureButtonFieldLayout")
        self.copyFigureButtonFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.copyImageButton = QPushButton(self.chartGroup)
        self.copyImageButton.setObjectName(u"copyImageButton")

        self.copyFigureButtonFieldLayout.addWidget(self.copyImageButton)


        self.chartForm.setLayout(11, QFormLayout.ItemRole.SpanningRole, self.copyFigureButtonFieldLayout)


        self.controlsLayout.addWidget(self.chartGroup)

        self.fontGroup = QGroupBox(self.controlsContent)
        self.fontGroup.setObjectName(u"fontGroup")
        self.fontForm = QFormLayout(self.fontGroup)
        self.fontForm.setObjectName(u"fontForm")
        self.fontForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.fontForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.fontForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.fontForm.setHorizontalSpacing(12)
        self.fontForm.setVerticalSpacing(6)
        self.fontForm.setContentsMargins(8, 10, 8, 8)
        self.allFontSizesLabel = QLabel(self.fontGroup)
        self.allFontSizesLabel.setObjectName(u"allFontSizesLabel")

        self.fontForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.allFontSizesLabel)

        self.allFontSizesButtonLayout = QHBoxLayout()
        self.allFontSizesButtonLayout.setSpacing(6)
        self.allFontSizesButtonLayout.setObjectName(u"allFontSizesButtonLayout")
        self.allFontSizesButtonLayout.setContentsMargins(0, 0, 0, 0)
        self.allFontSizesLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.allFontSizesButtonLayout.addItem(self.allFontSizesLeftSpacer)

        self.decreaseAllFontsButton = QPushButton(self.fontGroup)
        self.decreaseAllFontsButton.setObjectName(u"decreaseAllFontsButton")

        self.allFontSizesButtonLayout.addWidget(self.decreaseAllFontsButton)

        self.increaseAllFontsButton = QPushButton(self.fontGroup)
        self.increaseAllFontsButton.setObjectName(u"increaseAllFontsButton")

        self.allFontSizesButtonLayout.addWidget(self.increaseAllFontsButton)


        self.fontForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.allFontSizesButtonLayout)

        self.titleSizeLabel = QLabel(self.fontGroup)
        self.titleSizeLabel.setObjectName(u"titleSizeLabel")

        self.fontForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.titleSizeLabel)

        self.titleFontSizeSpinFieldLayout = QHBoxLayout()
        self.titleFontSizeSpinFieldLayout.setSpacing(0)
        self.titleFontSizeSpinFieldLayout.setObjectName(u"titleFontSizeSpinFieldLayout")
        self.titleFontSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.titleFontSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.titleFontSizeSpinFieldLayout.addItem(self.titleFontSizeSpinLeftSpacer)

        self.titleFontSizeSpin = QSpinBox(self.fontGroup)
        self.titleFontSizeSpin.setObjectName(u"titleFontSizeSpin")
        self.titleFontSizeSpin.setMinimum(6)
        self.titleFontSizeSpin.setMaximum(60)

        self.titleFontSizeSpinFieldLayout.addWidget(self.titleFontSizeSpin)


        self.fontForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.titleFontSizeSpinFieldLayout)

        self.axisLabelSizeLabel = QLabel(self.fontGroup)
        self.axisLabelSizeLabel.setObjectName(u"axisLabelSizeLabel")

        self.fontForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.axisLabelSizeLabel)

        self.axisLabelFontSizeSpinFieldLayout = QHBoxLayout()
        self.axisLabelFontSizeSpinFieldLayout.setSpacing(0)
        self.axisLabelFontSizeSpinFieldLayout.setObjectName(u"axisLabelFontSizeSpinFieldLayout")
        self.axisLabelFontSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.axisLabelFontSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.axisLabelFontSizeSpinFieldLayout.addItem(self.axisLabelFontSizeSpinLeftSpacer)

        self.axisLabelFontSizeSpin = QSpinBox(self.fontGroup)
        self.axisLabelFontSizeSpin.setObjectName(u"axisLabelFontSizeSpin")
        self.axisLabelFontSizeSpin.setMinimum(6)
        self.axisLabelFontSizeSpin.setMaximum(48)

        self.axisLabelFontSizeSpinFieldLayout.addWidget(self.axisLabelFontSizeSpin)


        self.fontForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.axisLabelFontSizeSpinFieldLayout)

        self.tickSizeLabel = QLabel(self.fontGroup)
        self.tickSizeLabel.setObjectName(u"tickSizeLabel")

        self.fontForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.tickSizeLabel)

        self.tickFontSizeSpinFieldLayout = QHBoxLayout()
        self.tickFontSizeSpinFieldLayout.setSpacing(0)
        self.tickFontSizeSpinFieldLayout.setObjectName(u"tickFontSizeSpinFieldLayout")
        self.tickFontSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.tickFontSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.tickFontSizeSpinFieldLayout.addItem(self.tickFontSizeSpinLeftSpacer)

        self.tickFontSizeSpin = QSpinBox(self.fontGroup)
        self.tickFontSizeSpin.setObjectName(u"tickFontSizeSpin")
        self.tickFontSizeSpin.setMinimum(5)
        self.tickFontSizeSpin.setMaximum(36)

        self.tickFontSizeSpinFieldLayout.addWidget(self.tickFontSizeSpin)


        self.fontForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.tickFontSizeSpinFieldLayout)

        self.lineValueSizeLabel = QLabel(self.fontGroup)
        self.lineValueSizeLabel.setObjectName(u"lineValueSizeLabel")

        self.fontForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.lineValueSizeLabel)

        self.lineValueFontSizeSpinFieldLayout = QHBoxLayout()
        self.lineValueFontSizeSpinFieldLayout.setSpacing(0)
        self.lineValueFontSizeSpinFieldLayout.setObjectName(u"lineValueFontSizeSpinFieldLayout")
        self.lineValueFontSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineValueFontSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineValueFontSizeSpinFieldLayout.addItem(self.lineValueFontSizeSpinLeftSpacer)

        self.lineValueFontSizeSpin = QSpinBox(self.fontGroup)
        self.lineValueFontSizeSpin.setObjectName(u"lineValueFontSizeSpin")
        self.lineValueFontSizeSpin.setMinimum(5)
        self.lineValueFontSizeSpin.setMaximum(36)
        self.lineValueFontSizeSpin.setValue(9)

        self.lineValueFontSizeSpinFieldLayout.addWidget(self.lineValueFontSizeSpin)


        self.fontForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.lineValueFontSizeSpinFieldLayout)

        self.statTableSizeLabel = QLabel(self.fontGroup)
        self.statTableSizeLabel.setObjectName(u"statTableSizeLabel")

        self.fontForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.statTableSizeLabel)

        self.statTableFontSizeSpinFieldLayout = QHBoxLayout()
        self.statTableFontSizeSpinFieldLayout.setSpacing(0)
        self.statTableFontSizeSpinFieldLayout.setObjectName(u"statTableFontSizeSpinFieldLayout")
        self.statTableFontSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.statTableFontSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.statTableFontSizeSpinFieldLayout.addItem(self.statTableFontSizeSpinLeftSpacer)

        self.statTableFontSizeSpin = QSpinBox(self.fontGroup)
        self.statTableFontSizeSpin.setObjectName(u"statTableFontSizeSpin")
        self.statTableFontSizeSpin.setMinimum(5)
        self.statTableFontSizeSpin.setMaximum(36)
        self.statTableFontSizeSpin.setValue(9)

        self.statTableFontSizeSpinFieldLayout.addWidget(self.statTableFontSizeSpin)


        self.fontForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.statTableFontSizeSpinFieldLayout)


        self.controlsLayout.addWidget(self.fontGroup)

        self.axisGroup = QGroupBox(self.controlsContent)
        self.axisGroup.setObjectName(u"axisGroup")
        self.axisForm = QFormLayout(self.axisGroup)
        self.axisForm.setObjectName(u"axisForm")
        self.axisForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.axisForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.axisForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.axisForm.setHorizontalSpacing(12)
        self.axisForm.setVerticalSpacing(6)
        self.axisForm.setContentsMargins(8, 10, 8, 8)
        self.showGridLabel = QLabel(self.axisGroup)
        self.showGridLabel.setObjectName(u"showGridLabel")

        self.axisForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.showGridLabel)

        self.showGridCheckFieldLayout = QHBoxLayout()
        self.showGridCheckFieldLayout.setSpacing(0)
        self.showGridCheckFieldLayout.setObjectName(u"showGridCheckFieldLayout")
        self.showGridCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showGridCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showGridCheckFieldLayout.addItem(self.showGridCheckLeftSpacer)

        self.showGridCheck = QCheckBox(self.axisGroup)
        self.showGridCheck.setObjectName(u"showGridCheck")

        self.showGridCheckFieldLayout.addWidget(self.showGridCheck)


        self.axisForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showGridCheckFieldLayout)

        self.autoYLabel = QLabel(self.axisGroup)
        self.autoYLabel.setObjectName(u"autoYLabel")

        self.axisForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.autoYLabel)

        self.autoYRangeCheckFieldLayout = QHBoxLayout()
        self.autoYRangeCheckFieldLayout.setSpacing(0)
        self.autoYRangeCheckFieldLayout.setObjectName(u"autoYRangeCheckFieldLayout")
        self.autoYRangeCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.autoYRangeCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.autoYRangeCheckFieldLayout.addItem(self.autoYRangeCheckLeftSpacer)

        self.autoYRangeCheck = QCheckBox(self.axisGroup)
        self.autoYRangeCheck.setObjectName(u"autoYRangeCheck")

        self.autoYRangeCheckFieldLayout.addWidget(self.autoYRangeCheck)


        self.axisForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.autoYRangeCheckFieldLayout)

        self.yMinLabel = QLabel(self.axisGroup)
        self.yMinLabel.setObjectName(u"yMinLabel")

        self.axisForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.yMinLabel)

        self.yMinSpinFieldLayout = QHBoxLayout()
        self.yMinSpinFieldLayout.setSpacing(0)
        self.yMinSpinFieldLayout.setObjectName(u"yMinSpinFieldLayout")
        self.yMinSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.yMinSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.yMinSpinFieldLayout.addItem(self.yMinSpinLeftSpacer)

        self.yMinSpin = QDoubleSpinBox(self.axisGroup)
        self.yMinSpin.setObjectName(u"yMinSpin")
        self.yMinSpin.setMinimum(-1000000.000000000000000)
        self.yMinSpin.setMaximum(1000000.000000000000000)
        self.yMinSpin.setSingleStep(0.500000000000000)

        self.yMinSpinFieldLayout.addWidget(self.yMinSpin)


        self.axisForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.yMinSpinFieldLayout)

        self.yMaxLabel = QLabel(self.axisGroup)
        self.yMaxLabel.setObjectName(u"yMaxLabel")

        self.axisForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.yMaxLabel)

        self.yMaxSpinFieldLayout = QHBoxLayout()
        self.yMaxSpinFieldLayout.setSpacing(0)
        self.yMaxSpinFieldLayout.setObjectName(u"yMaxSpinFieldLayout")
        self.yMaxSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.yMaxSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.yMaxSpinFieldLayout.addItem(self.yMaxSpinLeftSpacer)

        self.yMaxSpin = QDoubleSpinBox(self.axisGroup)
        self.yMaxSpin.setObjectName(u"yMaxSpin")
        self.yMaxSpin.setMinimum(-1000000.000000000000000)
        self.yMaxSpin.setMaximum(1000000.000000000000000)
        self.yMaxSpin.setSingleStep(0.500000000000000)

        self.yMaxSpinFieldLayout.addWidget(self.yMaxSpin)


        self.axisForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.yMaxSpinFieldLayout)

        self.axisLineWidthLabel = QLabel(self.axisGroup)
        self.axisLineWidthLabel.setObjectName(u"axisLineWidthLabel")

        self.axisForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.axisLineWidthLabel)

        self.axisLineWidthSpinFieldLayout = QHBoxLayout()
        self.axisLineWidthSpinFieldLayout.setSpacing(0)
        self.axisLineWidthSpinFieldLayout.setObjectName(u"axisLineWidthSpinFieldLayout")
        self.axisLineWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.axisLineWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.axisLineWidthSpinFieldLayout.addItem(self.axisLineWidthSpinLeftSpacer)

        self.axisLineWidthSpin = QDoubleSpinBox(self.axisGroup)
        self.axisLineWidthSpin.setObjectName(u"axisLineWidthSpin")
        self.axisLineWidthSpin.setMinimum(0.200000000000000)
        self.axisLineWidthSpin.setMaximum(5.000000000000000)
        self.axisLineWidthSpin.setSingleStep(0.100000000000000)

        self.axisLineWidthSpinFieldLayout.addWidget(self.axisLineWidthSpin)


        self.axisForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.axisLineWidthSpinFieldLayout)

        self.xRotationLabel = QLabel(self.axisGroup)
        self.xRotationLabel.setObjectName(u"xRotationLabel")

        self.axisForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.xRotationLabel)

        self.xTickRotationSpinFieldLayout = QHBoxLayout()
        self.xTickRotationSpinFieldLayout.setSpacing(0)
        self.xTickRotationSpinFieldLayout.setObjectName(u"xTickRotationSpinFieldLayout")
        self.xTickRotationSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.xTickRotationSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xTickRotationSpinFieldLayout.addItem(self.xTickRotationSpinLeftSpacer)

        self.xTickRotationSpin = QSpinBox(self.axisGroup)
        self.xTickRotationSpin.setObjectName(u"xTickRotationSpin")
        self.xTickRotationSpin.setMinimum(0)
        self.xTickRotationSpin.setMaximum(90)
        self.xTickRotationSpin.setSingleStep(5)

        self.xTickRotationSpinFieldLayout.addWidget(self.xTickRotationSpin)


        self.axisForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.xTickRotationSpinFieldLayout)

        self.customOverlaySecondaryAxisLabel = QLabel(self.axisGroup)
        self.customOverlaySecondaryAxisLabel.setObjectName(u"customOverlaySecondaryAxisLabel")

        self.axisForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.customOverlaySecondaryAxisLabel)

        self.customOverlaySecondaryAxisCheckFieldLayout = QHBoxLayout()
        self.customOverlaySecondaryAxisCheckFieldLayout.setSpacing(0)
        self.customOverlaySecondaryAxisCheckFieldLayout.setObjectName(u"customOverlaySecondaryAxisCheckFieldLayout")
        self.customOverlaySecondaryAxisCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.customOverlaySecondaryAxisCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.customOverlaySecondaryAxisCheckFieldLayout.addItem(self.customOverlaySecondaryAxisCheckLeftSpacer)

        self.customOverlaySecondaryAxisCheck = QCheckBox(self.axisGroup)
        self.customOverlaySecondaryAxisCheck.setObjectName(u"customOverlaySecondaryAxisCheck")

        self.customOverlaySecondaryAxisCheckFieldLayout.addWidget(self.customOverlaySecondaryAxisCheck)


        self.axisForm.setLayout(6, QFormLayout.ItemRole.FieldRole, self.customOverlaySecondaryAxisCheckFieldLayout)


        self.controlsLayout.addWidget(self.axisGroup)

        self.pointsGroup = QGroupBox(self.controlsContent)
        self.pointsGroup.setObjectName(u"pointsGroup")
        self.pointsForm = QFormLayout(self.pointsGroup)
        self.pointsForm.setObjectName(u"pointsForm")
        self.pointsForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.pointsForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.pointsForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.pointsForm.setHorizontalSpacing(12)
        self.pointsForm.setVerticalSpacing(6)
        self.pointsForm.setContentsMargins(8, 10, 8, 8)
        self.showPointsLabel = QLabel(self.pointsGroup)
        self.showPointsLabel.setObjectName(u"showPointsLabel")

        self.pointsForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.showPointsLabel)

        self.showPointsCheckFieldLayout = QHBoxLayout()
        self.showPointsCheckFieldLayout.setSpacing(0)
        self.showPointsCheckFieldLayout.setObjectName(u"showPointsCheckFieldLayout")
        self.showPointsCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showPointsCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showPointsCheckFieldLayout.addItem(self.showPointsCheckLeftSpacer)

        self.showPointsCheck = QCheckBox(self.pointsGroup)
        self.showPointsCheck.setObjectName(u"showPointsCheck")

        self.showPointsCheckFieldLayout.addWidget(self.showPointsCheck)


        self.pointsForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showPointsCheckFieldLayout)

        self.pointSizeLabel = QLabel(self.pointsGroup)
        self.pointSizeLabel.setObjectName(u"pointSizeLabel")

        self.pointsForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.pointSizeLabel)

        self.pointSizeSpinFieldLayout = QHBoxLayout()
        self.pointSizeSpinFieldLayout.setSpacing(0)
        self.pointSizeSpinFieldLayout.setObjectName(u"pointSizeSpinFieldLayout")
        self.pointSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.pointSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.pointSizeSpinFieldLayout.addItem(self.pointSizeSpinLeftSpacer)

        self.pointSizeSpin = QDoubleSpinBox(self.pointsGroup)
        self.pointSizeSpin.setObjectName(u"pointSizeSpin")
        self.pointSizeSpin.setMinimum(1.000000000000000)
        self.pointSizeSpin.setMaximum(14.000000000000000)
        self.pointSizeSpin.setSingleStep(0.500000000000000)

        self.pointSizeSpinFieldLayout.addWidget(self.pointSizeSpin)


        self.pointsForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.pointSizeSpinFieldLayout)

        self.pointAlphaLabel = QLabel(self.pointsGroup)
        self.pointAlphaLabel.setObjectName(u"pointAlphaLabel")

        self.pointsForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.pointAlphaLabel)

        self.pointAlphaSpinFieldLayout = QHBoxLayout()
        self.pointAlphaSpinFieldLayout.setSpacing(0)
        self.pointAlphaSpinFieldLayout.setObjectName(u"pointAlphaSpinFieldLayout")
        self.pointAlphaSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.pointAlphaSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.pointAlphaSpinFieldLayout.addItem(self.pointAlphaSpinLeftSpacer)

        self.pointAlphaSpin = QDoubleSpinBox(self.pointsGroup)
        self.pointAlphaSpin.setObjectName(u"pointAlphaSpin")
        self.pointAlphaSpin.setMinimum(0.100000000000000)
        self.pointAlphaSpin.setMaximum(1.000000000000000)
        self.pointAlphaSpin.setSingleStep(0.050000000000000)

        self.pointAlphaSpinFieldLayout.addWidget(self.pointAlphaSpin)


        self.pointsForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.pointAlphaSpinFieldLayout)

        self.jitterModeLabel = QLabel(self.pointsGroup)
        self.jitterModeLabel.setObjectName(u"jitterModeLabel")

        self.pointsForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.jitterModeLabel)

        self.jitterModeComboFieldLayout = QHBoxLayout()
        self.jitterModeComboFieldLayout.setSpacing(0)
        self.jitterModeComboFieldLayout.setObjectName(u"jitterModeComboFieldLayout")
        self.jitterModeComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.jitterModeComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.jitterModeComboFieldLayout.addItem(self.jitterModeComboLeftSpacer)

        self.jitterModeCombo = QComboBox(self.pointsGroup)
        self.jitterModeCombo.setObjectName(u"jitterModeCombo")

        self.jitterModeComboFieldLayout.addWidget(self.jitterModeCombo)


        self.pointsForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.jitterModeComboFieldLayout)

        self.jitterLabel = QLabel(self.pointsGroup)
        self.jitterLabel.setObjectName(u"jitterLabel")

        self.pointsForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.jitterLabel)

        self.jitterSpinFieldLayout = QHBoxLayout()
        self.jitterSpinFieldLayout.setSpacing(0)
        self.jitterSpinFieldLayout.setObjectName(u"jitterSpinFieldLayout")
        self.jitterSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.jitterSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.jitterSpinFieldLayout.addItem(self.jitterSpinLeftSpacer)

        self.jitterSpin = QDoubleSpinBox(self.pointsGroup)
        self.jitterSpin.setObjectName(u"jitterSpin")
        self.jitterSpin.setMinimum(0.000000000000000)
        self.jitterSpin.setMaximum(0.600000000000000)
        self.jitterSpin.setSingleStep(0.020000000000000)

        self.jitterSpinFieldLayout.addWidget(self.jitterSpin)


        self.pointsForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.jitterSpinFieldLayout)


        self.controlsLayout.addWidget(self.pointsGroup)

        self.lineOverlayGroup = QGroupBox(self.controlsContent)
        self.lineOverlayGroup.setObjectName(u"lineOverlayGroup")
        self.lineOverlayForm = QFormLayout(self.lineOverlayGroup)
        self.lineOverlayForm.setObjectName(u"lineOverlayForm")
        self.lineOverlayForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.lineOverlayForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.lineOverlayForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.lineOverlayForm.setHorizontalSpacing(12)
        self.lineOverlayForm.setVerticalSpacing(6)
        self.lineOverlayForm.setContentsMargins(8, 10, 8, 8)
        self.showLineOverlayLabel = QLabel(self.lineOverlayGroup)
        self.showLineOverlayLabel.setObjectName(u"showLineOverlayLabel")

        self.lineOverlayForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.showLineOverlayLabel)

        self.showLineOverlayCheckFieldLayout = QHBoxLayout()
        self.showLineOverlayCheckFieldLayout.setSpacing(0)
        self.showLineOverlayCheckFieldLayout.setObjectName(u"showLineOverlayCheckFieldLayout")
        self.showLineOverlayCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showLineOverlayCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showLineOverlayCheckFieldLayout.addItem(self.showLineOverlayCheckLeftSpacer)

        self.showLineOverlayCheck = QCheckBox(self.lineOverlayGroup)
        self.showLineOverlayCheck.setObjectName(u"showLineOverlayCheck")

        self.showLineOverlayCheckFieldLayout.addWidget(self.showLineOverlayCheck)


        self.lineOverlayForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showLineOverlayCheckFieldLayout)

        self.lineOverlayStatLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayStatLabel.setObjectName(u"lineOverlayStatLabel")

        self.lineOverlayForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.lineOverlayStatLabel)

        self.lineOverlayStatComboFieldLayout = QHBoxLayout()
        self.lineOverlayStatComboFieldLayout.setSpacing(0)
        self.lineOverlayStatComboFieldLayout.setObjectName(u"lineOverlayStatComboFieldLayout")
        self.lineOverlayStatComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayStatComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayStatComboFieldLayout.addItem(self.lineOverlayStatComboLeftSpacer)

        self.lineOverlayStatCombo = QComboBox(self.lineOverlayGroup)
        self.lineOverlayStatCombo.setObjectName(u"lineOverlayStatCombo")

        self.lineOverlayStatComboFieldLayout.addWidget(self.lineOverlayStatCombo)


        self.lineOverlayForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.lineOverlayStatComboFieldLayout)

        self.extraCustomOverlayLabel = QLabel(self.lineOverlayGroup)
        self.extraCustomOverlayLabel.setObjectName(u"extraCustomOverlayLabel")

        self.lineOverlayForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.extraCustomOverlayLabel)

        self.extraCustomOverlayCheckFieldLayout = QHBoxLayout()
        self.extraCustomOverlayCheckFieldLayout.setSpacing(0)
        self.extraCustomOverlayCheckFieldLayout.setObjectName(u"extraCustomOverlayCheckFieldLayout")
        self.extraCustomOverlayCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.extraCustomOverlayCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.extraCustomOverlayCheckFieldLayout.addItem(self.extraCustomOverlayCheckLeftSpacer)

        self.extraCustomOverlayCheck = QCheckBox(self.lineOverlayGroup)
        self.extraCustomOverlayCheck.setObjectName(u"extraCustomOverlayCheck")

        self.extraCustomOverlayCheckFieldLayout.addWidget(self.extraCustomOverlayCheck)


        self.lineOverlayForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.extraCustomOverlayCheckFieldLayout)

        self.customOverlayCountLabel = QLabel(self.lineOverlayGroup)
        self.customOverlayCountLabel.setObjectName(u"customOverlayCountLabel")

        self.lineOverlayForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.customOverlayCountLabel)

        self.customOverlayCountSpinFieldLayout = QHBoxLayout()
        self.customOverlayCountSpinFieldLayout.setSpacing(0)
        self.customOverlayCountSpinFieldLayout.setObjectName(u"customOverlayCountSpinFieldLayout")
        self.customOverlayCountSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.customOverlayCountSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.customOverlayCountSpinFieldLayout.addItem(self.customOverlayCountSpinLeftSpacer)

        self.customOverlayCountSpin = QSpinBox(self.lineOverlayGroup)
        self.customOverlayCountSpin.setObjectName(u"customOverlayCountSpin")
        self.customOverlayCountSpin.setMinimum(1)
        self.customOverlayCountSpin.setMaximum(12)
        self.customOverlayCountSpin.setValue(1)

        self.customOverlayCountSpinFieldLayout.addWidget(self.customOverlayCountSpin)

        self.customOverlayFilterButton = QPushButton(self.lineOverlayGroup)
        self.customOverlayFilterButton.setObjectName(u"customOverlayFilterButton")

        self.customOverlayCountSpinFieldLayout.addWidget(self.customOverlayFilterButton)


        self.lineOverlayForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.customOverlayCountSpinFieldLayout)

        self.lineOverlayWidthLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayWidthLabel.setObjectName(u"lineOverlayWidthLabel")

        self.lineOverlayForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.lineOverlayWidthLabel)

        self.lineOverlayWidthSpinFieldLayout = QHBoxLayout()
        self.lineOverlayWidthSpinFieldLayout.setSpacing(0)
        self.lineOverlayWidthSpinFieldLayout.setObjectName(u"lineOverlayWidthSpinFieldLayout")
        self.lineOverlayWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayWidthSpinFieldLayout.addItem(self.lineOverlayWidthSpinLeftSpacer)

        self.lineOverlayWidthSpin = QDoubleSpinBox(self.lineOverlayGroup)
        self.lineOverlayWidthSpin.setObjectName(u"lineOverlayWidthSpin")
        self.lineOverlayWidthSpin.setMinimum(0.200000000000000)
        self.lineOverlayWidthSpin.setMaximum(10.000000000000000)
        self.lineOverlayWidthSpin.setSingleStep(0.100000000000000)

        self.lineOverlayWidthSpinFieldLayout.addWidget(self.lineOverlayWidthSpin)


        self.lineOverlayForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.lineOverlayWidthSpinFieldLayout)

        self.lineOverlayStyleLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayStyleLabel.setObjectName(u"lineOverlayStyleLabel")

        self.lineOverlayForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.lineOverlayStyleLabel)

        self.lineOverlayStyleComboFieldLayout = QHBoxLayout()
        self.lineOverlayStyleComboFieldLayout.setSpacing(0)
        self.lineOverlayStyleComboFieldLayout.setObjectName(u"lineOverlayStyleComboFieldLayout")
        self.lineOverlayStyleComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayStyleComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayStyleComboFieldLayout.addItem(self.lineOverlayStyleComboLeftSpacer)

        self.lineOverlayStyleCombo = QComboBox(self.lineOverlayGroup)
        self.lineOverlayStyleCombo.setObjectName(u"lineOverlayStyleCombo")

        self.lineOverlayStyleComboFieldLayout.addWidget(self.lineOverlayStyleCombo)


        self.lineOverlayForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.lineOverlayStyleComboFieldLayout)

        self.lineOverlayPointSizeLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayPointSizeLabel.setObjectName(u"lineOverlayPointSizeLabel")

        self.lineOverlayForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.lineOverlayPointSizeLabel)

        self.lineOverlayPointSizeSpinFieldLayout = QHBoxLayout()
        self.lineOverlayPointSizeSpinFieldLayout.setSpacing(0)
        self.lineOverlayPointSizeSpinFieldLayout.setObjectName(u"lineOverlayPointSizeSpinFieldLayout")
        self.lineOverlayPointSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayPointSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayPointSizeSpinFieldLayout.addItem(self.lineOverlayPointSizeSpinLeftSpacer)

        self.lineOverlayPointSizeSpin = QDoubleSpinBox(self.lineOverlayGroup)
        self.lineOverlayPointSizeSpin.setObjectName(u"lineOverlayPointSizeSpin")
        self.lineOverlayPointSizeSpin.setMinimum(0.000000000000000)
        self.lineOverlayPointSizeSpin.setMaximum(20.000000000000000)
        self.lineOverlayPointSizeSpin.setSingleStep(0.500000000000000)

        self.lineOverlayPointSizeSpinFieldLayout.addWidget(self.lineOverlayPointSizeSpin)


        self.lineOverlayForm.setLayout(6, QFormLayout.ItemRole.FieldRole, self.lineOverlayPointSizeSpinFieldLayout)

        self.showLineValuesLabel = QLabel(self.lineOverlayGroup)
        self.showLineValuesLabel.setObjectName(u"showLineValuesLabel")

        self.lineOverlayForm.setWidget(7, QFormLayout.ItemRole.LabelRole, self.showLineValuesLabel)

        self.showLineValuesCheckFieldLayout = QHBoxLayout()
        self.showLineValuesCheckFieldLayout.setSpacing(0)
        self.showLineValuesCheckFieldLayout.setObjectName(u"showLineValuesCheckFieldLayout")
        self.showLineValuesCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showLineValuesCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showLineValuesCheckFieldLayout.addItem(self.showLineValuesCheckLeftSpacer)

        self.showLineValuesCheck = QCheckBox(self.lineOverlayGroup)
        self.showLineValuesCheck.setObjectName(u"showLineValuesCheck")

        self.showLineValuesCheckFieldLayout.addWidget(self.showLineValuesCheck)


        self.lineOverlayForm.setLayout(7, QFormLayout.ItemRole.FieldRole, self.showLineValuesCheckFieldLayout)

        self.lineValuePositionLabel = QLabel(self.lineOverlayGroup)
        self.lineValuePositionLabel.setObjectName(u"lineValuePositionLabel")

        self.lineOverlayForm.setWidget(8, QFormLayout.ItemRole.LabelRole, self.lineValuePositionLabel)

        self.lineValuePositionComboFieldLayout = QHBoxLayout()
        self.lineValuePositionComboFieldLayout.setSpacing(0)
        self.lineValuePositionComboFieldLayout.setObjectName(u"lineValuePositionComboFieldLayout")
        self.lineValuePositionComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineValuePositionComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineValuePositionComboFieldLayout.addItem(self.lineValuePositionComboLeftSpacer)

        self.lineValuePositionCombo = QComboBox(self.lineOverlayGroup)
        self.lineValuePositionCombo.setObjectName(u"lineValuePositionCombo")

        self.lineValuePositionComboFieldLayout.addWidget(self.lineValuePositionCombo)


        self.lineOverlayForm.setLayout(8, QFormLayout.ItemRole.FieldRole, self.lineValuePositionComboFieldLayout)

        self.customLineValuePositionLabel = QLabel(self.lineOverlayGroup)
        self.customLineValuePositionLabel.setObjectName(u"customLineValuePositionLabel")

        self.lineOverlayForm.setWidget(9, QFormLayout.ItemRole.LabelRole, self.customLineValuePositionLabel)

        self.customLineValuePositionComboFieldLayout = QHBoxLayout()
        self.customLineValuePositionComboFieldLayout.setSpacing(0)
        self.customLineValuePositionComboFieldLayout.setObjectName(u"customLineValuePositionComboFieldLayout")
        self.customLineValuePositionComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.customLineValuePositionComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.customLineValuePositionComboFieldLayout.addItem(self.customLineValuePositionComboLeftSpacer)

        self.customLineValuePositionCombo = QComboBox(self.lineOverlayGroup)
        self.customLineValuePositionCombo.setObjectName(u"customLineValuePositionCombo")

        self.customLineValuePositionComboFieldLayout.addWidget(self.customLineValuePositionCombo)


        self.lineOverlayForm.setLayout(9, QFormLayout.ItemRole.FieldRole, self.customLineValuePositionComboFieldLayout)

        self.lineValueScientificLabel = QLabel(self.lineOverlayGroup)
        self.lineValueScientificLabel.setObjectName(u"lineValueScientificLabel")

        self.lineOverlayForm.setWidget(10, QFormLayout.ItemRole.LabelRole, self.lineValueScientificLabel)

        self.lineValueScientificCheckFieldLayout = QHBoxLayout()
        self.lineValueScientificCheckFieldLayout.setSpacing(0)
        self.lineValueScientificCheckFieldLayout.setObjectName(u"lineValueScientificCheckFieldLayout")
        self.lineValueScientificCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineValueScientificCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineValueScientificCheckFieldLayout.addItem(self.lineValueScientificCheckLeftSpacer)

        self.lineValueScientificCheck = QCheckBox(self.lineOverlayGroup)
        self.lineValueScientificCheck.setObjectName(u"lineValueScientificCheck")

        self.lineValueScientificCheckFieldLayout.addWidget(self.lineValueScientificCheck)


        self.lineOverlayForm.setLayout(10, QFormLayout.ItemRole.FieldRole, self.lineValueScientificCheckFieldLayout)

        self.lineValueDecimalsLabel = QLabel(self.lineOverlayGroup)
        self.lineValueDecimalsLabel.setObjectName(u"lineValueDecimalsLabel")

        self.lineOverlayForm.setWidget(11, QFormLayout.ItemRole.LabelRole, self.lineValueDecimalsLabel)

        self.lineValueDecimalsSpinFieldLayout = QHBoxLayout()
        self.lineValueDecimalsSpinFieldLayout.setSpacing(0)
        self.lineValueDecimalsSpinFieldLayout.setObjectName(u"lineValueDecimalsSpinFieldLayout")
        self.lineValueDecimalsSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineValueDecimalsSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineValueDecimalsSpinFieldLayout.addItem(self.lineValueDecimalsSpinLeftSpacer)

        self.lineValueDecimalsSpin = QSpinBox(self.lineOverlayGroup)
        self.lineValueDecimalsSpin.setObjectName(u"lineValueDecimalsSpin")
        self.lineValueDecimalsSpin.setMinimum(0)
        self.lineValueDecimalsSpin.setMaximum(8)
        self.lineValueDecimalsSpin.setValue(2)

        self.lineValueDecimalsSpinFieldLayout.addWidget(self.lineValueDecimalsSpin)


        self.lineOverlayForm.setLayout(11, QFormLayout.ItemRole.FieldRole, self.lineValueDecimalsSpinFieldLayout)


        self.controlsLayout.addWidget(self.lineOverlayGroup)

        self.statsTableGroup = QGroupBox(self.controlsContent)
        self.statsTableGroup.setObjectName(u"statsTableGroup")
        self.statsTableLayout = QVBoxLayout(self.statsTableGroup)
        self.statsTableLayout.setSpacing(6)
        self.statsTableLayout.setObjectName(u"statsTableLayout")
        self.statsTableLayout.setContentsMargins(8, 10, 8, 8)
        self.showStatTableCheck = QCheckBox(self.statsTableGroup)
        self.showStatTableCheck.setObjectName(u"showStatTableCheck")
        self.showStatTableCheck.setChecked(True)

        self.statsTableLayout.addWidget(self.showStatTableCheck)

        self.showStatHeaderCheck = QCheckBox(self.statsTableGroup)
        self.showStatHeaderCheck.setObjectName(u"showStatHeaderCheck")

        self.statsTableLayout.addWidget(self.showStatHeaderCheck)

        self.statTableOptionsList = QListWidget(self.statsTableGroup)
        self.statTableOptionsList.setObjectName(u"statTableOptionsList")
        self.statTableOptionsList.setMinimumSize(QSize(0, 150))
        self.statTableOptionsList.setMaximumSize(QSize(16777215, 190))
        self.statTableOptionsList.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.statTableOptionsList.setAlternatingRowColors(False)
        self.statTableOptionsList.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)

        self.statsTableLayout.addWidget(self.statTableOptionsList)


        self.controlsLayout.addWidget(self.statsTableGroup)

        self.outlierGroup = QGroupBox(self.controlsContent)
        self.outlierGroup.setObjectName(u"outlierGroup")
        self.outlierForm = QFormLayout(self.outlierGroup)
        self.outlierForm.setObjectName(u"outlierForm")
        self.outlierForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.outlierForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.outlierForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.outlierForm.setHorizontalSpacing(12)
        self.outlierForm.setVerticalSpacing(6)
        self.outlierForm.setContentsMargins(8, 10, 8, 8)
        self.highlightLabel = QLabel(self.outlierGroup)
        self.highlightLabel.setObjectName(u"highlightLabel")

        self.outlierForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.highlightLabel)

        self.showOutliersCheckFieldLayout = QHBoxLayout()
        self.showOutliersCheckFieldLayout.setSpacing(0)
        self.showOutliersCheckFieldLayout.setObjectName(u"showOutliersCheckFieldLayout")
        self.showOutliersCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showOutliersCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showOutliersCheckFieldLayout.addItem(self.showOutliersCheckLeftSpacer)

        self.showOutliersCheck = QCheckBox(self.outlierGroup)
        self.showOutliersCheck.setObjectName(u"showOutliersCheck")

        self.showOutliersCheckFieldLayout.addWidget(self.showOutliersCheck)


        self.outlierForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showOutliersCheckFieldLayout)

        self.outlierMethodLabel = QLabel(self.outlierGroup)
        self.outlierMethodLabel.setObjectName(u"outlierMethodLabel")

        self.outlierForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.outlierMethodLabel)

        self.outlierMethodComboFieldLayout = QHBoxLayout()
        self.outlierMethodComboFieldLayout.setSpacing(0)
        self.outlierMethodComboFieldLayout.setObjectName(u"outlierMethodComboFieldLayout")
        self.outlierMethodComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.outlierMethodComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.outlierMethodComboFieldLayout.addItem(self.outlierMethodComboLeftSpacer)

        self.outlierMethodCombo = QComboBox(self.outlierGroup)
        self.outlierMethodCombo.setObjectName(u"outlierMethodCombo")

        self.outlierMethodComboFieldLayout.addWidget(self.outlierMethodCombo)


        self.outlierForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.outlierMethodComboFieldLayout)

        self.thresholdLabel = QLabel(self.outlierGroup)
        self.thresholdLabel.setObjectName(u"thresholdLabel")

        self.outlierForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.thresholdLabel)

        self.outlierThresholdSpinFieldLayout = QHBoxLayout()
        self.outlierThresholdSpinFieldLayout.setSpacing(0)
        self.outlierThresholdSpinFieldLayout.setObjectName(u"outlierThresholdSpinFieldLayout")
        self.outlierThresholdSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.outlierThresholdSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.outlierThresholdSpinFieldLayout.addItem(self.outlierThresholdSpinLeftSpacer)

        self.outlierThresholdSpin = QDoubleSpinBox(self.outlierGroup)
        self.outlierThresholdSpin.setObjectName(u"outlierThresholdSpin")
        self.outlierThresholdSpin.setMinimum(0.100000000000000)
        self.outlierThresholdSpin.setMaximum(10.000000000000000)
        self.outlierThresholdSpin.setSingleStep(0.100000000000000)

        self.outlierThresholdSpinFieldLayout.addWidget(self.outlierThresholdSpin)


        self.outlierForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.outlierThresholdSpinFieldLayout)

        self.effectLabel = QLabel(self.outlierGroup)
        self.effectLabel.setObjectName(u"effectLabel")

        self.outlierForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.effectLabel)

        self.outlierEffectComboFieldLayout = QHBoxLayout()
        self.outlierEffectComboFieldLayout.setSpacing(0)
        self.outlierEffectComboFieldLayout.setObjectName(u"outlierEffectComboFieldLayout")
        self.outlierEffectComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.outlierEffectComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.outlierEffectComboFieldLayout.addItem(self.outlierEffectComboLeftSpacer)

        self.outlierEffectCombo = QComboBox(self.outlierGroup)
        self.outlierEffectCombo.setObjectName(u"outlierEffectCombo")

        self.outlierEffectComboFieldLayout.addWidget(self.outlierEffectCombo)


        self.outlierForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.outlierEffectComboFieldLayout)


        self.controlsLayout.addWidget(self.outlierGroup)

        self.specificGroup = QGroupBox(self.controlsContent)
        self.specificGroup.setObjectName(u"specificGroup")
        self.specificForm = QFormLayout(self.specificGroup)
        self.specificForm.setObjectName(u"specificForm")
        self.specificForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.specificForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.specificForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.specificForm.setHorizontalSpacing(12)
        self.specificForm.setVerticalSpacing(6)
        self.specificForm.setContentsMargins(8, 10, 8, 8)
        self.boxWidthLabel = QLabel(self.specificGroup)
        self.boxWidthLabel.setObjectName(u"boxWidthLabel")

        self.specificForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.boxWidthLabel)

        self.boxWidthSpinFieldLayout = QHBoxLayout()
        self.boxWidthSpinFieldLayout.setSpacing(0)
        self.boxWidthSpinFieldLayout.setObjectName(u"boxWidthSpinFieldLayout")
        self.boxWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.boxWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.boxWidthSpinFieldLayout.addItem(self.boxWidthSpinLeftSpacer)

        self.boxWidthSpin = QDoubleSpinBox(self.specificGroup)
        self.boxWidthSpin.setObjectName(u"boxWidthSpin")
        self.boxWidthSpin.setMinimum(0.200000000000000)
        self.boxWidthSpin.setMaximum(1.000000000000000)
        self.boxWidthSpin.setSingleStep(0.050000000000000)

        self.boxWidthSpinFieldLayout.addWidget(self.boxWidthSpin)


        self.specificForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.boxWidthSpinFieldLayout)

        self.boxWhiskerLabel = QLabel(self.specificGroup)
        self.boxWhiskerLabel.setObjectName(u"boxWhiskerLabel")

        self.specificForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.boxWhiskerLabel)

        self.boxWhiskerModeComboFieldLayout = QHBoxLayout()
        self.boxWhiskerModeComboFieldLayout.setSpacing(0)
        self.boxWhiskerModeComboFieldLayout.setObjectName(u"boxWhiskerModeComboFieldLayout")
        self.boxWhiskerModeComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.boxWhiskerModeComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.boxWhiskerModeComboFieldLayout.addItem(self.boxWhiskerModeComboLeftSpacer)

        self.boxWhiskerModeCombo = QComboBox(self.specificGroup)
        self.boxWhiskerModeCombo.setObjectName(u"boxWhiskerModeCombo")

        self.boxWhiskerModeComboFieldLayout.addWidget(self.boxWhiskerModeCombo)


        self.specificForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.boxWhiskerModeComboFieldLayout)

        self.violinWidthLabel = QLabel(self.specificGroup)
        self.violinWidthLabel.setObjectName(u"violinWidthLabel")

        self.specificForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.violinWidthLabel)

        self.violinWidthSpinFieldLayout = QHBoxLayout()
        self.violinWidthSpinFieldLayout.setSpacing(0)
        self.violinWidthSpinFieldLayout.setObjectName(u"violinWidthSpinFieldLayout")
        self.violinWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.violinWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.violinWidthSpinFieldLayout.addItem(self.violinWidthSpinLeftSpacer)

        self.violinWidthSpin = QDoubleSpinBox(self.specificGroup)
        self.violinWidthSpin.setObjectName(u"violinWidthSpin")
        self.violinWidthSpin.setMinimum(0.200000000000000)
        self.violinWidthSpin.setMaximum(1.000000000000000)
        self.violinWidthSpin.setSingleStep(0.050000000000000)

        self.violinWidthSpinFieldLayout.addWidget(self.violinWidthSpin)


        self.specificForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.violinWidthSpinFieldLayout)

        self.kdeBandwidthLabel = QLabel(self.specificGroup)
        self.kdeBandwidthLabel.setObjectName(u"kdeBandwidthLabel")

        self.specificForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.kdeBandwidthLabel)

        self.kdeBandwidthSpinFieldLayout = QHBoxLayout()
        self.kdeBandwidthSpinFieldLayout.setSpacing(0)
        self.kdeBandwidthSpinFieldLayout.setObjectName(u"kdeBandwidthSpinFieldLayout")
        self.kdeBandwidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.kdeBandwidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.kdeBandwidthSpinFieldLayout.addItem(self.kdeBandwidthSpinLeftSpacer)

        self.kdeBandwidthSpin = QDoubleSpinBox(self.specificGroup)
        self.kdeBandwidthSpin.setObjectName(u"kdeBandwidthSpin")
        self.kdeBandwidthSpin.setMinimum(0.200000000000000)
        self.kdeBandwidthSpin.setMaximum(3.000000000000000)
        self.kdeBandwidthSpin.setSingleStep(0.100000000000000)

        self.kdeBandwidthSpinFieldLayout.addWidget(self.kdeBandwidthSpin)


        self.specificForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.kdeBandwidthSpinFieldLayout)

        self.ridgeOverlapLabel = QLabel(self.specificGroup)
        self.ridgeOverlapLabel.setObjectName(u"ridgeOverlapLabel")

        self.specificForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.ridgeOverlapLabel)

        self.ridgeOverlapSpinFieldLayout = QHBoxLayout()
        self.ridgeOverlapSpinFieldLayout.setSpacing(0)
        self.ridgeOverlapSpinFieldLayout.setObjectName(u"ridgeOverlapSpinFieldLayout")
        self.ridgeOverlapSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.ridgeOverlapSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.ridgeOverlapSpinFieldLayout.addItem(self.ridgeOverlapSpinLeftSpacer)

        self.ridgeOverlapSpin = QDoubleSpinBox(self.specificGroup)
        self.ridgeOverlapSpin.setObjectName(u"ridgeOverlapSpin")
        self.ridgeOverlapSpin.setMinimum(0.200000000000000)
        self.ridgeOverlapSpin.setMaximum(2.000000000000000)
        self.ridgeOverlapSpin.setSingleStep(0.050000000000000)

        self.ridgeOverlapSpinFieldLayout.addWidget(self.ridgeOverlapSpin)


        self.specificForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.ridgeOverlapSpinFieldLayout)

        self.fillAlphaLabel = QLabel(self.specificGroup)
        self.fillAlphaLabel.setObjectName(u"fillAlphaLabel")

        self.specificForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.fillAlphaLabel)

        self.fillAlphaSpinFieldLayout = QHBoxLayout()
        self.fillAlphaSpinFieldLayout.setSpacing(0)
        self.fillAlphaSpinFieldLayout.setObjectName(u"fillAlphaSpinFieldLayout")
        self.fillAlphaSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.fillAlphaSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.fillAlphaSpinFieldLayout.addItem(self.fillAlphaSpinLeftSpacer)

        self.fillAlphaSpin = QDoubleSpinBox(self.specificGroup)
        self.fillAlphaSpin.setObjectName(u"fillAlphaSpin")
        self.fillAlphaSpin.setMinimum(0.100000000000000)
        self.fillAlphaSpin.setMaximum(1.000000000000000)
        self.fillAlphaSpin.setSingleStep(0.050000000000000)

        self.fillAlphaSpinFieldLayout.addWidget(self.fillAlphaSpin)


        self.specificForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.fillAlphaSpinFieldLayout)


        self.controlsLayout.addWidget(self.specificGroup)

        self.controlsSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.controlsLayout.addItem(self.controlsSpacer)

        self.controlsScroll.setWidget(self.controlsContent)
        self.mainSplitter.addWidget(self.controlsScroll)

        self.centralLayout.addWidget(self.mainSplitter)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1280, 30))
        self.menuFile = QMenu(self.menubar)
        self.menuFile.setObjectName(u"menuFile")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.menubar.addAction(self.menuFile.menuAction())
        self.menuFile.addAction(self.actionNew)
        self.menuFile.addAction(self.actionOpenProject)
        self.menuFile.addAction(self.actionSaveProject)
        self.menuFile.addAction(self.actionSaveProjectAs)
        self.menuFile.addSeparator()
        self.menuFile.addAction(self.actionImportExcel)
        self.menuFile.addAction(self.actionExportExcel)
        self.menuFile.addSeparator()
        self.menuFile.addAction(self.actionCopyFigure)
        self.menuFile.addAction(self.actionExportFigure)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"EasyGraph", None))
        self.actionNew.setText(QCoreApplication.translate("MainWindow", u"New", None))
        self.actionOpenProject.setText(QCoreApplication.translate("MainWindow", u"Open Project", None))
        self.actionSaveProject.setText(QCoreApplication.translate("MainWindow", u"Save Project", None))
        self.actionSaveProjectAs.setText(QCoreApplication.translate("MainWindow", u"Save Project As", None))
        self.actionImportExcel.setText(QCoreApplication.translate("MainWindow", u"Import Excel", None))
        self.actionExportExcel.setText(QCoreApplication.translate("MainWindow", u"Export Excel", None))
        self.actionCopyFigure.setText(QCoreApplication.translate("MainWindow", u"Copy as Image", None))
        self.actionExportFigure.setText(QCoreApplication.translate("MainWindow", u"Export Figure", None))
        self.dataLabel.setText(QCoreApplication.translate("MainWindow", u"Data", None))
        self.addRowButton.setText(QCoreApplication.translate("MainWindow", u"+ Row", None))
        self.addColumnButton.setText(QCoreApplication.translate("MainWindow", u"+ Column", None))
        self.deleteColumnButton.setText(QCoreApplication.translate("MainWindow", u"- Column", None))
        self.renameColumnButton.setText(QCoreApplication.translate("MainWindow", u"Rename Group", None))
        self.addOverlayButton.setText(QCoreApplication.translate("MainWindow", u"+ Overlay", None))
        self.removeOverlayButton.setText(QCoreApplication.translate("MainWindow", u"- Overlay", None))
        self.templateGroup.setTitle(QCoreApplication.translate("MainWindow", u"Style Templates", None))
        self.loadTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Load...", None))
        self.saveTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Save Current", None))
        self.chartGroup.setTitle(QCoreApplication.translate("MainWindow", u"Chart", None))
        self.chartTypeLabel.setText(QCoreApplication.translate("MainWindow", u"Type", None))
        self.presetLabel.setText(QCoreApplication.translate("MainWindow", u"Preset", None))
        self.groupOrderLabel.setText(QCoreApplication.translate("MainWindow", u"Group order", None))
        self.editGroupOrderButton.setText(QCoreApplication.translate("MainWindow", u"Edit", None))
        self.titleLabel.setText(QCoreApplication.translate("MainWindow", u"Title", None))
        self.titleEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter to line break", None))
        self.xLabelLabel.setText(QCoreApplication.translate("MainWindow", u"Group axis title", None))
        self.xLabelEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter to line break", None))
        self.yLabelLabel.setText(QCoreApplication.translate("MainWindow", u"Primary value \n"
"axis title", None))
        self.yLabelEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter to line break", None))
        self.widthLabel.setText(QCoreApplication.translate("MainWindow", u"Plot area width (cm)", None))
        self.heightLabel.setText(QCoreApplication.translate("MainWindow", u"Plot area height (cm)", None))
        self.dpiLabel.setText(QCoreApplication.translate("MainWindow", u"Export DPI", None))
        self.transparentLabel.setText(QCoreApplication.translate("MainWindow", u"Transparent bg", None))
        self.groupFilterLabel.setText(QCoreApplication.translate("MainWindow", u"Group filter", None))
        self.groupFilterButton.setText(QCoreApplication.translate("MainWindow", u"Filter", None))
        self.copyImageButton.setText(QCoreApplication.translate("MainWindow", u"Copy as Image", None))
        self.fontGroup.setTitle(QCoreApplication.translate("MainWindow", u"Font", None))
        self.allFontSizesLabel.setText(QCoreApplication.translate("MainWindow", u"All sizes", None))
        self.decreaseAllFontsButton.setText(QCoreApplication.translate("MainWindow", u"A-", None))
        self.increaseAllFontsButton.setText(QCoreApplication.translate("MainWindow", u"A+", None))
        self.titleSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Title size", None))
        self.axisLabelSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Axis label size", None))
        self.tickSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Tick size", None))
        self.lineValueSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Overlay value size", None))
        self.statTableSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Stats table size", None))
        self.axisGroup.setTitle(QCoreApplication.translate("MainWindow", u"Axis", None))
        self.showGridLabel.setText(QCoreApplication.translate("MainWindow", u"Show grid", None))
        self.autoYLabel.setText(QCoreApplication.translate("MainWindow", u"Auto Primary Y Range", None))
        self.yMinLabel.setText(QCoreApplication.translate("MainWindow", u"Primary Y min", None))
        self.yMaxLabel.setText(QCoreApplication.translate("MainWindow", u"Primary Y max", None))
        self.axisLineWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Axis line width", None))
        self.xRotationLabel.setText(QCoreApplication.translate("MainWindow", u"X label rotation", None))
        self.customOverlaySecondaryAxisLabel.setText(QCoreApplication.translate("MainWindow", u"\u53e0\u52a0\u7ebf\u4f7f\u7528\u6b21\u5750\u6807\u8f74", None))
        self.pointsGroup.setTitle(QCoreApplication.translate("MainWindow", u"Data Points", None))
        self.showPointsLabel.setText(QCoreApplication.translate("MainWindow", u"Show all points", None))
        self.pointSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Point size", None))
        self.pointAlphaLabel.setText(QCoreApplication.translate("MainWindow", u"Point alpha", None))
        self.jitterModeLabel.setText(QCoreApplication.translate("MainWindow", u"Jitter mode", None))
        self.jitterLabel.setText(QCoreApplication.translate("MainWindow", u"Jitter", None))
        self.lineOverlayGroup.setTitle(QCoreApplication.translate("MainWindow", u"Line Overlay", None))
        self.showLineOverlayLabel.setText(QCoreApplication.translate("MainWindow", u"Show line", None))
        self.lineOverlayStatLabel.setText(QCoreApplication.translate("MainWindow", u"Trend overlay", None))
        self.extraCustomOverlayLabel.setText(QCoreApplication.translate("MainWindow", u"Extra custom overlay", None))
        self.customOverlayCountLabel.setText(QCoreApplication.translate("MainWindow", u"Custom line count", None))
        self.customOverlayFilterButton.setText(QCoreApplication.translate("MainWindow", u"Filter", None))
        self.lineOverlayWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Line width", None))
        self.lineOverlayStyleLabel.setText(QCoreApplication.translate("MainWindow", u"Line style", None))
        self.lineOverlayPointSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Point size", None))
        self.showLineValuesLabel.setText(QCoreApplication.translate("MainWindow", u"Show values", None))
        self.lineValuePositionLabel.setText(QCoreApplication.translate("MainWindow", u"Label position", None))
        self.customLineValuePositionLabel.setText(QCoreApplication.translate("MainWindow", u"Extra label position", None))
        self.lineValueScientificLabel.setText(QCoreApplication.translate("MainWindow", u"Scientific", None))
        self.lineValueDecimalsLabel.setText(QCoreApplication.translate("MainWindow", u"Decimals", None))
        self.statsTableGroup.setTitle(QCoreApplication.translate("MainWindow", u"Stats Table", None))
        self.showStatTableCheck.setText(QCoreApplication.translate("MainWindow", u"Show statistics table", None))
        self.showStatHeaderCheck.setText(QCoreApplication.translate("MainWindow", u"Show header", None))
        self.outlierGroup.setTitle(QCoreApplication.translate("MainWindow", u"Outliers", None))
        self.highlightLabel.setText(QCoreApplication.translate("MainWindow", u"Highlight", None))
        self.outlierMethodLabel.setText(QCoreApplication.translate("MainWindow", u"Method", None))
        self.thresholdLabel.setText(QCoreApplication.translate("MainWindow", u"Threshold", None))
        self.effectLabel.setText(QCoreApplication.translate("MainWindow", u"Effect", None))
        self.specificGroup.setTitle(QCoreApplication.translate("MainWindow", u"Type-specific", None))
        self.boxWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Box width", None))
        self.boxWhiskerLabel.setText(QCoreApplication.translate("MainWindow", u"Box whisker mode", None))
        self.violinWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Violin width", None))
        self.kdeBandwidthLabel.setText(QCoreApplication.translate("MainWindow", u"KDE bandwidth", None))
        self.ridgeOverlapLabel.setText(QCoreApplication.translate("MainWindow", u"Ridge overlap", None))
        self.fillAlphaLabel.setText(QCoreApplication.translate("MainWindow", u"Fill alpha", None))
        self.menuFile.setTitle(QCoreApplication.translate("MainWindow", u"File", None))
    # retranslateUi

