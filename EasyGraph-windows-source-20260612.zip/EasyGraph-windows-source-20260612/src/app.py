from __future__ import annotations

import json
import math
import os
import csv
import re
import tempfile
import unicodedata
import zipfile
from copy import deepcopy
from enum import Enum
from functools import lru_cache
from io import BytesIO, StringIO
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

os.environ.setdefault(
    "MPLCONFIGDIR",
    str(Path(tempfile.gettempdir()) / "easygraph_matplotlib"),
)
Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import font_manager, rcParams
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle
from matplotlib.ticker import AutoLocator, MultipleLocator
from scipy.stats import gaussian_kde
try:
    import qdarktheme
except ImportError:
    qdarktheme = None

from PySide6.QtCore import QEvent, QLocale, QSettings, QSize, Qt, QTimer, QTranslator
from PySide6.QtGui import QAction, QBrush, QColor, QFont, QImage, QKeyEvent, QKeySequence, QPalette, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QScrollArea,
    QSplitter,
    QTableWidgetSelectionRange,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


def configure_matplotlib_fonts() -> str:
    candidates = [
        "Microsoft YaHei",
        "SimHei",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "PingFang SC",
        "Heiti SC",
        "Hiragino Sans GB",
        "Songti SC",
        "Arial Unicode MS",
        "WenQuanYi Micro Hei",
        "DejaVu Sans",
    ]
    available = {font.name for font in font_manager.fontManager.ttflist}
    selected = next((name for name in candidates if name in available), "DejaVu Sans")
    rcParams["font.family"] = "sans-serif"
    rcParams["font.sans-serif"] = [selected] + [name for name in candidates if name != selected]
    rcParams["axes.unicode_minus"] = False
    return selected


DEFAULT_FONT_FAMILY = configure_matplotlib_fonts()
APP_DIR = Path(__file__).resolve().parents[1]
TEMPLATE_DIR = APP_DIR / "template"
TRANSLATION_DIR = APP_DIR / "translations"
LANGUAGE_ENV_VAR = "EASYGRAPH_LANGUAGE"
LANGUAGE_SETTING_KEY = "language"
APP_CONTROL_HEIGHT = 26
COMBO_TEXT_WIDTH_PADDING = 55
COMBO_MIN_WIDTH = 96
APP_RENDER_DEBOUNCE_MS = 150
OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS = 3
OVERLAY_AXIS_LABEL_FIXED_PAD_POINTS = 4
OFFICE_FONT_SIZE_STEPS = [5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 60, 72]
LEGEND_MAX_COLUMNS = 6
LEGEND_COLUMN_SPACING = 1.0
LEGEND_SECONDARY_AXIS_GAP_PX = 8.0
MAX_MANUAL_TICK_COUNT = 1000
APP_THEME_OVERRIDES = """
QComboBox,
QSpinBox,
QDoubleSpinBox,
QPushButton {
    border-radius: 6px;
    min-height: 20px;
    max-height: 20px;
}

QComboBox {
    padding: 2px 20px 2px 10px;
}

QSpinBox,
QDoubleSpinBox {
    padding: 2px 18px 2px 8px;
}

QPushButton {
    padding: 2px 10px;
}

QComboBox::drop-down {
    width: 16px;
    border-top-right-radius: 6px;
    border-bottom-right-radius: 6px;
}

QComboBox QAbstractItemView {
    border-radius: 6px;
    padding: 4px;
    outline: 0;
}
"""


class RenderMode(Enum):
    FULL = "full"
    TEXT_ONLY = "text_only"


def apply_app_theme(app: QApplication) -> bool:
    base_stylesheet = qdarktheme.load_stylesheet() if qdarktheme is not None else ""
    app.setStyleSheet(f"{base_stylesheet}\n{APP_THEME_OVERRIDES}")
    return qdarktheme is not None


def normalize_language_code(language: str | None) -> str:
    if not language:
        return "system"
    code = language.strip().replace("-", "_")
    if code in {"system", "en", "zh_CN"}:
        return code
    if code.lower().startswith("zh"):
        return "zh_CN"
    if code.lower().startswith("en"):
        return "en"
    return "system"


def stored_language_preference() -> str:
    settings = QSettings("EasyGraph", "EasyGraph")
    return normalize_language_code(str(settings.value(LANGUAGE_SETTING_KEY, "system")))


def save_language_preference(language: str) -> None:
    settings = QSettings("EasyGraph", "EasyGraph")
    settings.setValue(LANGUAGE_SETTING_KEY, normalize_language_code(language))


def effective_language_code(language: str | None = None) -> str:
    preference = normalize_language_code(os.environ.get(LANGUAGE_ENV_VAR) or language or stored_language_preference())
    if preference == "system":
        return normalize_language_code(QLocale.system().name())
    return preference


def install_app_translator(app: QApplication, language: str | None = None) -> str:
    code = effective_language_code(language)
    if code == "en":
        return code

    translator = QTranslator(app)
    translation_file = TRANSLATION_DIR / f"easygraph_{code}.qm"
    if translator.load(str(translation_file)):
        app.installTranslator(translator)
        app._easygraph_translator = translator
    return code


class ScrollFriendlyFigureCanvas(FigureCanvasQTAgg):
    def __init__(self, figure, owner=None) -> None:
        self.owner = owner
        super().__init__(figure)

    def wheelEvent(self, event) -> None:
        if event.modifiers() & Qt.ControlModifier and self.owner is not None:
            delta = event.angleDelta().y()
            if delta:
                self.owner.zoom_by(1.12 if delta > 0 else 1 / 1.12)
                event.accept()
                return
        event.ignore()


PRESETS = {
    "Paper Clean": {
        "palette": ["#4E79A7", "#E15759", "#59A14F", "#F28E2B", "#B07AA1"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.72,
    },
    "Nature Style": {
        "palette": ["#3B6EA8", "#C44E52", "#55A868", "#8172B3", "#CCB974"],
        "background": "#FFFFFF",
        "grid": False,
        "font_size": 9,
        "line_width": 0.9,
        "point_alpha": 0.68,
    },
    "Presentation": {
        "palette": ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#F0E442"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 14,
        "line_width": 1.8,
        "point_alpha": 0.8,
    },
    "Colorblind Safe": {
        "palette": ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.75,
    },
    "Okabe-Ito": {
        "palette": ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9", "#F0E442", "#000000"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.76,
    },
    "Tableau 10": {
        "palette": ["#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F", "#EDC948", "#B07AA1", "#FF9DA7", "#9C755F", "#BAB0AC"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.74,
    },
    "Brewer Set2": {
        "palette": ["#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.05,
        "point_alpha": 0.72,
    },
    "Brewer Dark2": {
        "palette": ["#1B9E77", "#D95F02", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D", "#666666"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.15,
        "point_alpha": 0.74,
    },
    "Brewer Paired": {
        "palette": ["#A6CEE3", "#1F78B4", "#B2DF8A", "#33A02C", "#FB9A99", "#E31A1C", "#FDBF6F", "#FF7F00", "#CAB2D6", "#6A3D9A"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.05,
        "point_alpha": 0.72,
    },
    "Viridis": {
        "palette": ["#440154", "#482878", "#3E4989", "#31688E", "#26828E", "#1F9E89", "#35B779", "#6DCD59", "#B4DE2C", "#FDE725"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.75,
    },
    "Cividis": {
        "palette": ["#00204D", "#123570", "#3B496C", "#575D6D", "#707173", "#8A8678", "#A59C74", "#C3B369", "#E1CC55", "#FFE945"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.75,
    },
    "Tol Bright": {
        "palette": ["#4477AA", "#EE6677", "#228833", "#CCBB44", "#66CCEE", "#AA3377", "#BBBBBB"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.74,
    },
    "Mono Print": {
        "palette": ["#111111", "#666666", "#999999", "#CCCCCC", "#444444"],
        "background": "#FFFFFF",
        "grid": False,
        "font_size": 10,
        "line_width": 1.2,
        "point_alpha": 0.7,
    },
    "Dark Slide": {
        "palette": ["#7FDBFF", "#FF851B", "#2ECC40", "#F012BE", "#FFDC00"],
        "background": "#111827",
        "grid": True,
        "font_size": 13,
        "line_width": 1.6,
        "point_alpha": 0.86,
    },
}


STAT_TABLE_OPTIONS = [
    ("show_stat_mean", "Mean"),
    ("show_stat_median", "Median"),
    ("show_stat_q1", "Q1"),
    ("show_stat_q3", "Q3"),
    ("show_stat_max", "Max"),
    ("show_stat_min", "Min"),
    ("show_stat_sd", "SD"),
    ("show_stat_sem", "SEM"),
    ("show_stat_sample_size", "Sample"),
]

SEQUENTIAL_PALETTE_PRESETS = {"Viridis", "Cividis"}
DEFAULT_OVERLAY_PALETTE = "Mono Print"
STAT_OVERLAY_ALPHA = 0.78
PRECOMPUTED_PALETTE_COUNT = 100
PRECOMPUTED_PALETTE_PATH = Path(__file__).with_name("palette_cache.json")


@dataclass
class ChartSettings:
    chart_type: str = "Box"
    preset: str = "Paper Clean"
    group_order: str = "Table order"
    manual_group_order: list[str] = field(default_factory=list)
    group_hidden: list[str] = field(default_factory=list)
    group_col: str = "group"
    value_col: str = "value"
    title: str = "Distribution plot"
    x_label: str = "Group"
    y_label: str = "Value"
    secondary_y_axis: bool = False
    secondary_y_label: str = "Secondary value"
    show_points: bool = True
    point_size: float = 4.0
    point_alpha: float = 0.75
    jitter_mode: str = "Quasirandom"
    jitter: float = 0.18
    show_line_overlay: bool = False
    line_overlay_stat: str = "None"
    extra_custom_overlay: bool = False
    custom_overlay_count: int = 1
    custom_overlay_series: list[dict] = field(default_factory=list)
    custom_overlay_hidden: list[int] = field(default_factory=list)
    line_overlay_width: float = 1.6
    line_overlay_style: str = "Solid"
    line_overlay_point_size: float = 5.0
    show_line_values: bool = False
    line_value_position: str = "Auto"
    custom_line_value_position: str = "Auto"
    custom_overlay_secondary_axis: bool = False
    split_secondary_axis: bool = False
    secondary_axis_split_ratio: float = 0.35
    line_value_scientific: bool = False
    line_value_decimals: int = 2
    line_value_font_size: int = 9
    show_stat_table: bool = True
    show_stat_mean: bool = True
    show_stat_median: bool = True
    show_stat_q1: bool = False
    show_stat_q3: bool = False
    show_stat_max: bool = True
    show_stat_min: bool = True
    show_stat_sd: bool = False
    show_stat_sem: bool = False
    show_stat_sample_size: bool = False
    show_stat_header: bool = False
    stat_table_font_size: int = 9
    show_outliers: bool = True
    outlier_method: str = "IQR"
    outlier_threshold: float = 1.5
    outlier_effect: str = "Mark only"
    width: float = 15.0
    height: float = 10.0
    dpi: int = 300
    title_font_size: int = 16
    axis_label_font_size: int = 12
    tick_font_size: int = 10
    show_legend: bool = True
    legend_font_size: int = 10
    legend_width: float = 3.6
    legend_height: float = 0.0
    legend_auto_wrap: bool = True
    legend_columns: int = 0
    axis_line_width: float = 1.1
    show_grid: bool = True
    x_tick_rotation: int = 0
    auto_y_range: bool = True
    y_min: float = 0.0
    y_max: float = 10.0
    primary_auto_tick_interval: bool = True
    primary_tick_interval: float = 1.0
    secondary_auto_y_range: bool = True
    secondary_y_min: float = 0.0
    secondary_y_max: float = 10.0
    secondary_auto_tick_interval: bool = True
    secondary_tick_interval: float = 1.0
    transparent_background: bool = True
    fill_alpha: float = 0.75
    box_width: float = 0.55
    box_whisker_mode: str = "Tukey 1.5 IQR"
    violin_width: float = 0.8
    kde_bandwidth: float = 1.0
    ridge_overlap: float = 0.75
    custom_colors: dict[str, str] = field(default_factory=dict)
    custom_overlay_palette: str = DEFAULT_OVERLAY_PALETTE
    custom_overlay_colors: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.show_line_overlay and self.line_overlay_stat == "None":
            self.line_overlay_stat = "Median"
        self.show_line_overlay = self.line_overlay_stat != "None"
        self.group_hidden = sorted({str(group) for group in self.group_hidden})
        self.custom_overlay_count = max(1, int(self.custom_overlay_count))
        self.custom_overlay_hidden = sorted(
            {
                int(index)
                for index in self.custom_overlay_hidden
                if isinstance(index, int) or str(index).lstrip("-").isdigit()
            }
        )


def sample_data() -> pd.DataFrame:
    rng = np.random.default_rng(7)
    columns = {}
    for group, center, spread in [
        ("Control", 4.8, 0.55),
        ("Low dose", 5.6, 0.65),
        ("High dose", 6.4, 0.7),
    ]:
        values = [round(float(v), 3) for v in rng.normal(center, spread, 34)]
        if group == "High dose":
            values.append(8.7)
        columns[group] = values
    return pd.DataFrame({name: pd.Series(values) for name, values in columns.items()})


def blank_project_data(rows: int = 12, columns: int = 3) -> pd.DataFrame:
    return pd.DataFrame(
        [["" for _ in range(columns)] for _ in range(rows)],
        columns=[f"Group {col + 1}" for col in range(columns)],
    )


def chart_settings_from_dict(data: dict) -> ChartSettings:
    known_fields = {field.name for field in fields(ChartSettings)}
    settings = ChartSettings(**{key: value for key, value in data.items() if key in known_fields})
    if data.get("show_line_overlay") is False:
        settings.line_overlay_stat = "None"
    elif data.get("show_line_overlay") is True and settings.line_overlay_stat == "None":
        settings.line_overlay_stat = "Median"
    settings.show_line_overlay = settings.line_overlay_stat != "None"
    settings.custom_overlay_count = max(1, int(settings.custom_overlay_count))
    return settings


def template_file_name(name: str) -> str:
    stem = re.sub(r"[^\w .()-]+", "_", name.strip(), flags=re.UNICODE)
    stem = re.sub(r"\s+", " ", stem).strip(" .")
    if not stem:
        raise ValueError("Template name cannot be empty.")
    return f"{stem}.json"


def write_style_template(name: str, settings: ChartSettings, template_dir: Path = TEMPLATE_DIR) -> Path:
    template_dir.mkdir(parents=True, exist_ok=True)
    path = template_dir / template_file_name(name)
    path.write_text(json.dumps(asdict(settings), ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def read_style_template(name: str, template_dir: Path = TEMPLATE_DIR) -> ChartSettings:
    path = template_dir / template_file_name(name)
    return read_style_template_file(path)


def read_style_template_file(path: Path) -> ChartSettings:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Style template must be a JSON object.")
    return chart_settings_from_dict(data)


def import_style_template(path: Path, template_dir: Path = TEMPLATE_DIR) -> tuple[str, ChartSettings]:
    settings = read_style_template_file(path)
    imported_path = write_style_template(path.stem, settings, template_dir)
    return imported_path.stem, settings


def list_style_templates(template_dir: Path = TEMPLATE_DIR) -> list[str]:
    if not template_dir.exists():
        return []
    return sorted(path.stem for path in template_dir.glob("*.json") if path.is_file())


class DataTable(QTableWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setAlternatingRowColors(True)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

    def set_dataframe(self, df: pd.DataFrame) -> None:
        self.blockSignals(True)
        self.setRowCount(len(df) + 1)
        self.setColumnCount(len(df.columns))
        self.setHorizontalHeaderLabels([str(c + 1) for c in range(len(df.columns))])
        for c, col in enumerate(df.columns):
            self.setItem(0, c, QTableWidgetItem(str(col)))
        for r in range(len(df)):
            for c, col in enumerate(df.columns):
                value = df.iloc[r, c]
                text = "" if pd.isna(value) else str(value)
                self.setItem(r + 1, c, QTableWidgetItem(text))
        self.blockSignals(False)

    def dataframe(self) -> pd.DataFrame:
        headers = [
            self.item(0, c).text() if self.item(0, c) and self.item(0, c).text().strip() else f"Group {c+1}"
            for c in range(self.columnCount())
        ]
        data = []
        for r in range(1, self.rowCount()):
            row = []
            for c in range(self.columnCount()):
                item = self.item(r, c)
                row.append(item.text() if item else "")
            data.append(row)
        return pd.DataFrame(data, columns=headers)


class PlotCanvas(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.preview_ppi = 140
        self.preview_zoom = 1.0
        self.figure = None
        self.canvas = None
        self.toolbar = None
        self.zoom_bar = QWidget()
        zoom_layout = QHBoxLayout(self.zoom_bar)
        zoom_layout.setContentsMargins(6, 4, 6, 4)
        zoom_layout.addStretch()
        zoom_out = QPushButton("−")
        zoom_reset = QPushButton("100%")
        zoom_fit = QPushButton("Fit")
        zoom_in = QPushButton("+")
        zoom_fit.setObjectName("zoomToFitButton")
        zoom_out.clicked.connect(lambda: self.zoom_by(1 / 1.12))
        zoom_reset.clicked.connect(self.reset_zoom)
        zoom_fit.clicked.connect(self.zoom_to_fit)
        zoom_in.clicked.connect(lambda: self.zoom_by(1.12))
        zoom_layout.addWidget(zoom_out)
        zoom_layout.addWidget(zoom_reset)
        zoom_layout.addWidget(zoom_fit)
        zoom_layout.addWidget(zoom_in)
        self._canvas_size: tuple[int, int] | None = None
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignCenter)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setStyleSheet("QScrollArea { background: #2f2f2f; border: 0; }")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.addWidget(self.zoom_bar)
        self.layout.addWidget(self.scroll)
        self._replace_canvas(15 / 2.54, 10 / 2.54)

    def _replace_canvas(self, width_in: float, height_in: float) -> None:
        width_px = max(1, int(width_in * self.preview_ppi * self.preview_zoom))
        height_px = max(1, int(height_in * self.preview_ppi * self.preview_zoom))
        size = (width_px, height_px)
        if size == self._canvas_size and self.figure is not None and self.canvas is not None:
            return

        if self.toolbar is not None:
            self.layout.removeWidget(self.toolbar)
            self.toolbar.deleteLater()
            self.toolbar = None

        old_canvas = self.scroll.takeWidget()
        if old_canvas is not None:
            old_canvas.deleteLater()

        self.figure = Figure(figsize=(width_in, height_in), dpi=self.preview_ppi * self.preview_zoom)
        self.canvas = ScrollFriendlyFigureCanvas(self.figure, owner=self)
        self.canvas.setFixedSize(width_px, height_px)
        self.canvas.setAutoFillBackground(True)
        self.canvas.setFocusPolicy(Qt.NoFocus)
        self.toolbar = NavigationToolbar2QT(self.canvas, self)
        self.layout.insertWidget(0, self.toolbar)
        self.scroll.setWidget(self.canvas)
        self._canvas_size = size

    def zoom_by(self, factor: float) -> None:
        self.preview_zoom = min(4.0, max(0.25, self.preview_zoom * factor))
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self.render(self._last_df, self._last_settings)

    def reset_zoom(self) -> None:
        self.preview_zoom = 1.0
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self.render(self._last_df, self._last_settings)

    def zoom_to_fit(self) -> None:
        if self.canvas is None:
            return
        base_width_px = self.canvas.width() / max(self.preview_zoom, 0.001)
        base_height_px = self.canvas.height() / max(self.preview_zoom, 0.001)
        if base_width_px <= 0 or base_height_px <= 0:
            return
        viewport_size = self.scroll.viewport().size()
        available_width = max(1, viewport_size.width() - 12)
        available_height = max(1, viewport_size.height() - 12)
        target_zoom = min(available_width / base_width_px, available_height / base_height_px)
        target_zoom = min(4.0, max(0.25, target_zoom))
        if math.isclose(target_zoom, self.preview_zoom, rel_tol=0.001, abs_tol=0.001):
            return
        self.preview_zoom = target_zoom
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self.render(self._last_df, self._last_settings)

    def render(self, df: pd.DataFrame, settings: ChartSettings) -> None:
        self._last_df = df.copy()
        self._last_settings = ChartSettings(**asdict(settings))
        self._auto_tick_interval_fallbacks: set[str] = set()
        plot_width_in = settings.width / 2.54
        plot_height_in = settings.height / 2.54

        full_clean = prepare_plot_data(df, settings, include_hidden=True)
        clean = prepare_plot_data(df, settings)
        preset = PRESETS[settings.preset]
        all_groups = [str(group) for group in full_clean[settings.group_col].dropna().drop_duplicates()] if not full_clean.empty else []
        palette = palette_for(clean, settings, color_groups=all_groups)
        text_color = "#F9FAFB" if preset["background"] != "#FFFFFF" else "#222222"

        if clean.empty:
            self._replace_canvas(plot_width_in, plot_height_in)
            self.figure.clf()
            self.figure.patch.set_facecolor(preset["background"])
            ax = self.figure.add_axes([0.0, 0.0, 1.0, 1.0])
            ax.set_facecolor(preset["background"])
            ax.text(0.5, 0.5, "No numeric data", ha="center", va="center", fontsize=settings.axis_label_font_size)
            self.canvas.draw()
            self.canvas.repaint()
            self.scroll.viewport().repaint()
            return

        out = mark_outliers(clean, settings)
        distribution = clean.drop(index=out.index) if settings.outlier_effect == "Exclude from distribution" else clean
        if distribution.empty:
            distribution = clean
        stat_groups, stat_rows = stat_table_data(distribution, settings)
        x_axis_label, y_axis_label = axis_labels_for_chart(settings)

        plot_groups = [str(group) for group in distribution[settings.group_col].dropna().drop_duplicates()]
        left_margin_in = self._plot_left_margin_inches(settings, plot_groups, y_axis_label, stat_rows)
        right_margin_in = self._plot_right_margin_inches(settings)
        table_height_in = self._stat_table_height_inches(stat_groups, stat_rows, settings) if stat_rows else 0.0
        gap_in = self._stat_table_gap_inches(settings, stat_groups, x_axis_label) if stat_rows else 0.0
        bottom_in = 0.14 if stat_rows else self._plot_bottom_margin_inches(settings, stat_groups, x_axis_label)
        top_in = self._plot_top_margin_inches(settings)
        total_width_in = left_margin_in + plot_width_in + right_margin_in
        total_height_in = plot_height_in + table_height_in + gap_in + bottom_in + top_in

        self._replace_canvas(total_width_in, total_height_in)
        self.figure.clf()
        self.figure.patch.set_facecolor(preset["background"])

        table_ax = None
        secondary_ax = None
        plot_left = left_margin_in / total_width_in
        plot_width = plot_width_in / total_width_in
        plot_bottom = (bottom_in + table_height_in + gap_in) / total_height_in
        plot_height = plot_height_in / total_height_in
        split_secondary_frame = self._split_secondary_frame_enabled(settings)
        if stat_rows:
            table_bottom = bottom_in / total_height_in
            table_height = table_height_in / total_height_in
            if split_secondary_frame:
                secondary_height = plot_height * self._secondary_axis_split_ratio(settings)
                primary_height = plot_height - secondary_height
                ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, primary_height])
                secondary_ax = self.figure.add_axes([plot_left, plot_bottom + primary_height, plot_width, secondary_height])
            else:
                ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, plot_height])
            table_ax = self.figure.add_axes([plot_left, table_bottom, plot_width, table_height])
            table_ax.set_facecolor(preset["background"])
        else:
            if split_secondary_frame:
                secondary_height = plot_height * self._secondary_axis_split_ratio(settings)
                primary_height = plot_height - secondary_height
                ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, primary_height])
                secondary_ax = self.figure.add_axes([plot_left, plot_bottom + primary_height, plot_width, secondary_height])
            else:
                ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, plot_height])
        ax.set_facecolor(preset["background"])
        if secondary_ax is not None:
            secondary_ax.set_gid("secondary-axis")
            secondary_ax.set_facecolor(preset["background"])
        elif settings.custom_overlay_secondary_axis:
            secondary_ax = ax.twiny() if settings.chart_type == "Ridge" else ax.twinx()
            secondary_ax.set_gid("secondary-axis")
            secondary_ax.set_facecolor("none")

        if settings.chart_type == "Box":
            self._draw_box(ax, distribution, settings, palette)
        elif settings.chart_type == "Violin":
            self._draw_violin(ax, distribution, settings, palette)
        else:
            self._draw_ridge(ax, distribution, clean, settings, palette, text_color)
        if settings.chart_type != "Ridge":
            ax.set_xlim(-0.5, len(stat_groups or palette_for(distribution, settings)) - 0.5)
            if split_secondary_frame and secondary_ax is not None:
                secondary_ax.set_xlim(ax.get_xlim())

        point_positions = None
        if settings.chart_type != "Ridge":
            point_positions = self._point_positions(clean, settings)
            if settings.show_points:
                self._draw_points(ax, clean, settings, palette, preset, point_positions)

        if settings.chart_type != "Ridge" and settings.show_outliers:
            if not out.empty and point_positions is not None:
                ax.scatter(
                    point_positions.loc[out.index],
                    out[settings.value_col],
                    s=max(settings.point_size * 18, 45),
                    facecolors="none",
                    edgecolors="#D62728",
                    linewidths=1.3,
                    zorder=6,
                    label="Outlier",
                )

        if settings.show_line_overlay or settings.extra_custom_overlay:
            self._draw_line_overlay(ax, distribution, settings, text_color, secondary_ax=secondary_ax)

        if settings.chart_type == "Ridge":
            self._apply_ridge_x_range(ax, settings)
        elif not settings.auto_y_range:
            ax.set_ylim(settings.y_min, settings.y_max)
        if secondary_ax is not None and not settings.secondary_auto_y_range:
            if settings.chart_type == "Ridge":
                secondary_ax.set_xlim(settings.secondary_y_min, settings.secondary_y_max)
            else:
                secondary_ax.set_ylim(settings.secondary_y_min, settings.secondary_y_max)

        ax.set_title("" if split_secondary_frame else settings.title, fontsize=settings.title_font_size, color=text_color)
        ax.set_xlabel(x_axis_label, fontsize=settings.axis_label_font_size, color=text_color)
        ax.set_ylabel(y_axis_label, fontsize=settings.axis_label_font_size, color=text_color)
        ax.tick_params(colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        ax.tick_params(axis="x", labelrotation=settings.x_tick_rotation)
        self._style_plot_frame(ax, settings, text_color)
        ax.grid(bool(settings.show_grid), color="#D1D5DB" if preset["background"] == "#FFFFFF" else "#374151", alpha=0.55)
        if secondary_ax is not None:
            if split_secondary_frame:
                self._style_split_secondary_axis(secondary_ax, ax, stat_groups, settings, text_color)
            else:
                self._style_secondary_axis(secondary_ax, settings, text_color)
        if table_ax is not None:
            self._draw_stat_table(table_ax, stat_groups, stat_rows, settings, text_color)
        self._apply_overlay_axis_label_y_padding(ax, settings)
        self._place_legend_outside(ax, text_color, settings, extra_axes=[secondary_ax] if secondary_ax is not None else None)
        self.canvas.draw()
        if settings.auto_y_range:
            self._expand_axes_for_overlay_value_labels(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._expand_axes_for_overlay_value_labels(secondary_ax, settings)
        self.canvas.draw()
        if settings.auto_y_range:
            self._expand_axes_for_overlay_label_conflicts(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._expand_axes_for_overlay_label_conflicts(secondary_ax, settings)
        self.canvas.draw()
        if settings.auto_y_range:
            self._separate_overlay_value_labels(ax)
            self._expand_axes_for_overlay_value_labels(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._separate_overlay_value_labels(secondary_ax)
            self._expand_axes_for_overlay_value_labels(secondary_ax, settings)
        self._apply_value_axis_tick_interval(ax, settings)
        if secondary_ax is not None:
            self._apply_value_axis_tick_interval(secondary_ax, settings, secondary=True)
        self.canvas.draw()
        self.canvas.repaint()
        self.scroll.viewport().repaint()

    def _apply_value_axis_tick_interval(self, ax, settings: ChartSettings, secondary: bool = False) -> None:
        auto_tick_interval = settings.secondary_auto_tick_interval if secondary else settings.primary_auto_tick_interval
        axis = ax.xaxis if settings.chart_type == "Ridge" else ax.yaxis
        if auto_tick_interval:
            return
        tick_interval = settings.secondary_tick_interval if secondary else settings.primary_tick_interval
        if not self._manual_tick_interval_is_safe(ax, tick_interval, settings):
            axis.set_major_locator(AutoLocator())
            self._auto_tick_interval_fallbacks.add("secondary" if secondary else "primary")
            return
        axis.set_major_locator(MultipleLocator(tick_interval))

    def _manual_tick_interval_is_safe(self, ax, tick_interval: float, settings: ChartSettings) -> bool:
        if not math.isfinite(tick_interval) or tick_interval <= 0:
            return False
        axis_min, axis_max = ax.get_xlim() if settings.chart_type == "Ridge" else ax.get_ylim()
        if not math.isfinite(axis_min) or not math.isfinite(axis_max):
            return False
        span = abs(axis_max - axis_min)
        if span <= 0:
            return True
        return math.ceil(span / tick_interval) + 1 <= MAX_MANUAL_TICK_COUNT

    def _apply_ridge_x_range(self, ax, settings: ChartSettings) -> None:
        if not settings.auto_y_range:
            ax.set_xlim(settings.y_min, settings.y_max)
            return

        x_min, x_max = ax.dataLim.intervalx
        if not math.isfinite(x_min) or not math.isfinite(x_max):
            return
        if math.isclose(x_min, x_max, rel_tol=0.0, abs_tol=1e-12):
            pad = max(abs(x_min) * 0.05, 0.5)
        else:
            pad = (x_max - x_min) * 0.05
        ax.set_xlim(x_min - pad, x_max + pad)

    def _point_positions(self, df: pd.DataFrame, settings: ChartSettings) -> pd.Series:
        order = list(df[settings.group_col].dropna().unique())
        xpos = {group: idx for idx, group in enumerate(order)}
        positions = pd.Series(index=df.index, dtype=float)
        for group in order:
            mask = df[settings.group_col] == group
            values = df.loc[mask, settings.value_col].to_numpy(dtype=float)
            offsets = self._jitter_offsets(values, settings.jitter, settings.jitter_mode, str(group))
            positions.loc[mask] = xpos[group] + offsets
        return positions

    def _draw_points(
        self,
        ax,
        df: pd.DataFrame,
        settings: ChartSettings,
        palette: list[str],
        preset: dict,
        positions: pd.Series,
    ) -> None:
        order = list(df[settings.group_col].dropna().unique())
        colors = {group: palette[idx % len(palette)] for idx, group in enumerate(order)}
        for group in order:
            group_df = df[df[settings.group_col] == group]
            color = colors[group]
            ax.scatter(
                positions.loc[group_df.index],
                group_df[settings.value_col],
                s=settings.point_size * 12,
                c=derived_group_color(color, "point", preset["background"]),
                alpha=settings.point_alpha,
                edgecolors=derived_group_color(color, "edge", preset["background"]),
                linewidths=0.35,
                zorder=5,
            )

    def _draw_box(self, ax, df: pd.DataFrame, settings: ChartSettings, palette: list[str]) -> None:
        sns.boxplot(
            data=df,
            x=settings.group_col,
            y=settings.value_col,
            ax=ax,
            hue=settings.group_col,
            palette=palette,
            legend=False,
            width=settings.box_width,
            showfliers=False,
            whis=box_whis(settings.box_whisker_mode),
            linewidth=PRESETS[settings.preset]["line_width"],
        )
        for patch in ax.patches:
            patch.set_alpha(settings.fill_alpha)

    def _draw_violin(self, ax, df: pd.DataFrame, settings: ChartSettings, palette: list[str]) -> None:
        sns.violinplot(
            data=df,
            x=settings.group_col,
            y=settings.value_col,
            ax=ax,
            hue=settings.group_col,
            palette=palette,
            legend=False,
            width=settings.violin_width,
            inner="quartile",
            cut=0,
            bw_adjust=settings.kde_bandwidth,
            linewidth=PRESETS[settings.preset]["line_width"],
        )
        for collection in ax.collections:
            collection.set_alpha(settings.fill_alpha)

    def _draw_ridge(
        self,
        ax,
        df: pd.DataFrame,
        point_df: pd.DataFrame,
        settings: ChartSettings,
        palette: list[str],
        text_color: str,
    ) -> None:
        groups = list(df[settings.group_col].dropna().unique())
        values = pd.to_numeric(point_df[settings.value_col], errors="coerce").dropna()
        xmin, xmax = float(values.min()), float(values.max())
        pad = max((xmax - xmin) * 0.08, 1e-3)
        xs = np.linspace(xmin - pad, xmax + pad, 300)
        y_positions = np.arange(len(groups))[::-1]
        max_density = 0.0
        densities = []

        for group in groups:
            vals = pd.to_numeric(df[df[settings.group_col] == group][settings.value_col], errors="coerce").dropna()
            if len(vals) < 2 or math.isclose(float(vals.std()), 0.0):
                density = np.zeros_like(xs)
            else:
                kde = gaussian_kde(vals, bw_method=settings.kde_bandwidth)
                density = kde(xs)
            max_density = max(max_density, float(density.max()))
            densities.append(density)

        scale = settings.ridge_overlap / max_density if max_density > 0 else 1.0
        for idx, (group, density) in enumerate(zip(groups, densities)):
            y0 = y_positions[idx]
            color = palette[idx % len(palette)]
            y = y0 + density * scale
            ax.fill_between(xs, y0, y, color=color, alpha=settings.fill_alpha, linewidth=0)
            ax.plot(xs, y, color=color, linewidth=PRESETS[settings.preset]["line_width"])
            if settings.show_points:
                group_points = point_df[point_df[settings.group_col] == group]
                vals = pd.to_numeric(group_points[settings.value_col], errors="coerce").dropna()
                offsets = self._jitter_offsets(vals.to_numpy(dtype=float), settings.jitter, settings.jitter_mode, str(group))
                ax.scatter(
                    vals,
                    np.full(len(vals), y0) + offsets,
                    s=settings.point_size * 8,
                    color=color,
                    alpha=settings.point_alpha,
                    edgecolors="#222222",
                    linewidths=0.25,
                )
                if settings.show_outliers:
                    out = mark_outliers(point_df, settings)
                    group_out = out[out[settings.group_col] == group]
                    if not group_out.empty:
                        offset_by_index = pd.Series(offsets, index=vals.index)
                        ax.scatter(
                            group_out[settings.value_col],
                            np.full(len(group_out), y0) + offset_by_index.loc[group_out.index],
                            s=max(settings.point_size * 18, 45),
                            facecolors="none",
                            edgecolors="#D62728",
                            linewidths=1.3,
                            zorder=6,
                        )

        ax.set_yticks(y_positions)
        ax.set_yticklabels([str(group) for group in groups], color=text_color, fontsize=settings.tick_font_size)
        ax.tick_params(axis="y", length=0, pad=10)
        ax.set_ylim(-0.4, len(groups) - 1 + settings.ridge_overlap + 0.25)
        ax.set_xlim(xmin - pad, xmax + pad)

    def _style_plot_frame(self, ax, settings: ChartSettings, text_color: str) -> None:
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(text_color)
            spine.set_linewidth(settings.axis_line_width)

    def _split_secondary_frame_enabled(self, settings: ChartSettings) -> bool:
        return bool(settings.custom_overlay_secondary_axis and settings.split_secondary_axis)

    def _secondary_axis_split_ratio(self, settings: ChartSettings) -> float:
        return max(0.15, min(float(settings.secondary_axis_split_ratio), 0.85))

    def _style_split_secondary_axis(self, secondary_ax, primary_ax, groups: list[str], settings: ChartSettings, text_color: str) -> None:
        secondary_ax.set_title(settings.title, fontsize=settings.title_font_size, color=text_color)
        if settings.chart_type == "Ridge":
            secondary_ax.set_xlabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            secondary_ax.set_ylabel("", fontsize=settings.axis_label_font_size, color=text_color)
            secondary_ax.set_ylim(primary_ax.get_ylim())
            secondary_ax.set_yticks(primary_ax.get_yticks())
            secondary_ax.set_yticklabels([])
            secondary_ax.xaxis.set_label_position("top")
            secondary_ax.xaxis.tick_top()
            secondary_ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            secondary_ax.tick_params(axis="x", top=True, labeltop=True, bottom=False, labelbottom=False)
            secondary_ax.tick_params(axis="y", left=False, labelleft=False, right=False, labelright=False)
            self._style_plot_frame(secondary_ax, settings, text_color)
            secondary_ax.grid(bool(settings.show_grid), color="#D1D5DB" if PRESETS[settings.preset]["background"] == "#FFFFFF" else "#374151", alpha=0.55)
            return

        secondary_ax.set_xlabel("", fontsize=settings.axis_label_font_size, color=text_color)
        secondary_ax.set_ylabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
        secondary_ax.yaxis.set_label_position("right")
        secondary_ax.yaxis.tick_right()
        secondary_ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        secondary_ax.tick_params(axis="y", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        secondary_ax.tick_params(axis="y", left=False, labelleft=False, right=True, labelright=True)
        secondary_ax.set_xlim(primary_ax.get_xlim())
        secondary_ax.set_xticks(np.arange(len(groups)))
        secondary_ax.set_xticklabels([])
        secondary_ax.tick_params(axis="x", top=False, labeltop=False, bottom=False, labelbottom=False)
        self._style_plot_frame(secondary_ax, settings, text_color)
        secondary_ax.grid(bool(settings.show_grid), color="#D1D5DB" if PRESETS[settings.preset]["background"] == "#FFFFFF" else "#374151", alpha=0.55)

    def _style_secondary_axis(self, ax, settings: ChartSettings, text_color: str) -> None:
        if settings.chart_type == "Ridge":
            ax.set_xlabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            ax.tick_params(axis="y", left=False, labelleft=False)
            ax.spines["top"].set_visible(True)
            ax.spines["right"].set_visible(False)
        else:
            ax.set_ylabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            ax.tick_params(axis="y", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            ax.tick_params(axis="x", bottom=False, labelbottom=False)
            ax.spines["right"].set_visible(True)
            ax.spines["top"].set_visible(False)
        for spine in ax.spines.values():
            spine.set_color(text_color)
            spine.set_linewidth(settings.axis_line_width)
        ax.grid(False)

    def _draw_line_overlay(self, ax, df: pd.DataFrame, settings: ChartSettings, text_color: str, secondary_ax=None) -> None:
        series_list = line_overlay_series(df, settings)
        if not series_list:
            return
        line_width = max(settings.line_overlay_width, 0.1)
        line_style = overlay_line_style(settings.line_overlay_style)
        point_size = max(settings.line_overlay_point_size, 0.0)
        overlay_colors = overlay_palette_for(df, settings, len(series_list))
        for series_index, series in enumerate(series_list):
            groups = series["groups"]
            values = series["values"]
            is_custom_overlay = series.get("kind") == "custom"
            target_ax = secondary_ax if series.get("secondary_axis") and secondary_ax is not None else ax
            label_position = overlay_label_position_for_series(settings, is_custom_overlay)
            preferred_auto_position = overlay_auto_avoidance_position(settings, is_custom_overlay)
            line_color = overlay_colors[series_index % len(overlay_colors)]
            line_alpha = 1.0 if is_custom_overlay else STAT_OVERLAY_ALPHA
            finite_values = [value for value in values if math.isfinite(value)]
            if settings.chart_type == "Ridge":
                y_positions = np.arange(len(groups))[::-1]
                line, = target_ax.plot(
                    values,
                    y_positions,
                    color=line_color,
                    marker="o",
                    markersize=point_size,
                    linewidth=line_width,
                    linestyle=line_style,
                    alpha=line_alpha,
                    label=series["name"],
                    zorder=8 + series_index,
                )
                self._mark_overlay_line(line)
                if settings.show_line_values:
                    for index, (x_value, y_value) in enumerate(zip(values, y_positions)):
                        if not math.isfinite(x_value):
                            continue
                        if not self._overlay_label_anchor_is_visible(x_value, y_value, settings, uses_secondary_axis=target_ax is secondary_ax):
                            continue
                        if not is_custom_overlay and label_position in {"Axis left", "Axis right"}:
                            is_right_axis = label_position == "Axis right"
                            x_fraction = 1.0 if is_right_axis else 0.0
                            offset_x = -OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS if is_right_axis else OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                            horizontal_align = "right" if is_right_axis else "left"
                            annotation = target_ax.annotate(
                                format_overlay_value(x_value, settings),
                                xy=(x_fraction, y_value),
                                xycoords=target_ax.get_yaxis_transform(),
                                xytext=(offset_x, 0),
                                textcoords="offset points",
                                ha=horizontal_align,
                                va="center",
                                color=line_color,
                                fontsize=settings.line_value_font_size,
                                bbox=overlay_label_bbox(settings),
                                clip_on=False,
                                zorder=10 + series_index,
                            )
                            self._mark_overlay_value_label(annotation, is_custom_overlay, label_position)
                            continue
                        actual_label_position = resolve_overlay_label_position(
                            index,
                            finite_values,
                            label_position,
                            is_ridge=True,
                            series_index=series_index,
                            preferred_auto_position=preferred_auto_position,
                        )
                        offset_x, offset_y, horizontal_align, vertical_align = overlay_label_offset(
                            index,
                            finite_values,
                            actual_label_position,
                            is_ridge=True,
                            series_index=series_index,
                            marker_size_points=point_size,
                        )
                        annotation = target_ax.annotate(
                            format_overlay_value(x_value, settings),
                            xy=(x_value, y_value),
                            xytext=(offset_x, offset_y),
                            textcoords="offset points",
                            ha=horizontal_align,
                            va=vertical_align,
                            color=line_color,
                            fontsize=settings.line_value_font_size,
                            bbox=overlay_label_bbox(settings),
                            arrowprops=overlay_label_arrow(line_color),
                            zorder=10 + series_index,
                        )
                        self._mark_overlay_value_label(annotation, is_custom_overlay, actual_label_position)
                continue

            x_positions = np.arange(len(values))
            line, = target_ax.plot(
                x_positions,
                values,
                color=line_color,
                marker="o",
                markersize=point_size,
                linewidth=line_width,
                linestyle=line_style,
                alpha=line_alpha,
                label=series["name"],
                zorder=8 + series_index,
            )
            self._mark_overlay_line(line)
            if settings.show_line_values:
                for index, (x_value, y_value) in enumerate(zip(x_positions, values)):
                    if not math.isfinite(y_value):
                        continue
                    if not self._overlay_label_anchor_is_visible(x_value, y_value, settings, uses_secondary_axis=target_ax is secondary_ax):
                        continue
                    if not is_custom_overlay and label_position in {"Top axis", "Bottom axis"}:
                        is_top_axis = label_position == "Top axis"
                        y_fraction = 1.0 if is_top_axis else 0.0
                        offset_y = -OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS if is_top_axis else OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                        vertical_align = "top" if is_top_axis else "bottom"
                        annotation = target_ax.annotate(
                            format_overlay_value(y_value, settings),
                            xy=(x_value, y_fraction),
                            xycoords=target_ax.get_xaxis_transform(),
                            xytext=(0, offset_y),
                            textcoords="offset points",
                            ha="center",
                            va=vertical_align,
                            color=line_color,
                            fontsize=settings.line_value_font_size,
                            bbox=overlay_label_bbox(settings),
                            clip_on=False,
                            zorder=10 + series_index,
                        )
                        self._mark_overlay_value_label(annotation, is_custom_overlay, label_position)
                        continue
                    actual_label_position = resolve_overlay_label_position(
                        index,
                        finite_values,
                        label_position,
                        is_ridge=False,
                        series_index=series_index,
                        preferred_auto_position=preferred_auto_position,
                    )
                    offset_x, offset_y, horizontal_align, vertical_align = overlay_label_offset(
                        index,
                        finite_values,
                        actual_label_position,
                        is_ridge=False,
                        series_index=series_index,
                        marker_size_points=point_size,
                    )
                    annotation = target_ax.annotate(
                        format_overlay_value(y_value, settings),
                        xy=(x_value, y_value),
                        xytext=(offset_x, offset_y),
                        textcoords="offset points",
                        ha=horizontal_align,
                        va=vertical_align,
                        color=line_color,
                        fontsize=settings.line_value_font_size,
                        bbox=overlay_label_bbox(settings),
                        arrowprops=overlay_label_arrow(line_color),
                        zorder=10 + series_index,
                    )
                    self._mark_overlay_value_label(annotation, is_custom_overlay, actual_label_position)
    def _apply_overlay_axis_label_y_padding(self, ax, settings: ChartSettings) -> None:
        if settings.chart_type == "Ridge":
            return
        if not settings.auto_y_range:
            return
        if not settings.show_line_overlay or not settings.show_line_values:
            return
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        if line_value_position not in {"Top axis", "Bottom axis"}:
            return

        current_y_min, current_y_max = ax.get_ylim()
        if settings.auto_y_range:
            y_min, y_max = ax.dataLim.intervaly
        else:
            y_min, y_max = current_y_min, current_y_max
        if not math.isfinite(y_min) or not math.isfinite(y_max) or y_max < y_min:
            return

        y_range = y_max - y_min
        if math.isclose(y_range, 0.0):
            y_range = max(abs(y_min), abs(y_max), 1.0)
        axes_height_points = max(ax.get_position().height * self.figure.get_figheight() * 72.0, 1.0)
        label_height_points = max(settings.line_value_font_size, 1) * 1.35
        label_margin_points = label_height_points + OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS + OVERLAY_AXIS_LABEL_FIXED_PAD_POINTS
        marker_margin_points = self._overlay_axis_marker_margin_points(settings) if settings.auto_y_range else 0.0
        bottom_margin_points = marker_margin_points
        top_margin_points = marker_margin_points
        if line_value_position == "Bottom axis":
            bottom_margin_points += label_margin_points
        else:
            top_margin_points += label_margin_points

        bottom_fraction = bottom_margin_points / axes_height_points
        top_fraction = top_margin_points / axes_height_points
        total_fraction = min(max(bottom_fraction + top_fraction, 0.0), 0.80)
        if total_fraction <= 0.0:
            return

        scale = y_range / (1.0 - total_fraction)
        bottom_pad = scale * bottom_fraction
        top_pad = scale * top_fraction
        padded_y_min = y_min - bottom_pad
        padded_y_max = y_max + top_pad
        if settings.auto_y_range:
            padded_y_min = min(padded_y_min, current_y_min)
            padded_y_max = max(padded_y_max, current_y_max)
        ax.set_ylim(padded_y_min, padded_y_max)

    def _fit_ridge_axis_overlay_margin(self, ax, table_ax, settings: ChartSettings) -> None:
        if settings.chart_type != "Ridge" or not settings.show_line_overlay or not settings.show_line_values:
            return
        if normalize_overlay_label_position(settings.line_value_position, settings.chart_type) not in {"Axis left", "Axis right"}:
            return

        for _ in range(3):
            self.canvas.draw()
            renderer = self.canvas.get_renderer()
            figure_width = max(self.figure.bbox.width, 1.0)
            text_bounds = [text.get_window_extent(renderer) for text in ax.texts if text.get_visible() and text.get_text()]
            if not text_bounds:
                return

            left_overflow = max(0.0, 6.0 - min(bounds.x0 for bounds in text_bounds))
            right_overflow = max(0.0, max(bounds.x1 for bounds in text_bounds) - (self.figure.bbox.width - 6.0))
            if left_overflow <= 0.0 and right_overflow <= 0.0:
                return

            position = ax.get_position()
            new_left = position.x0 + left_overflow / figure_width
            new_right = position.x1 - right_overflow / figure_width
            if new_right - new_left < 0.20:
                return
            ax.set_position([new_left, position.y0, new_right - new_left, position.height])
            if table_ax is not None:
                table_position = table_ax.get_position()
                table_ax.set_position([new_left, table_position.y0, new_right - new_left, table_position.height])

    def _expand_axes_for_overlay_value_labels(self, ax, settings: ChartSettings) -> None:
        if not settings.auto_y_range:
            return
        for _ in range(3):
            if not self._expand_axes_once_for_overlay_value_labels(ax):
                return
            self.canvas.draw()

    def _expand_axes_for_overlay_label_conflicts(self, ax, settings: ChartSettings) -> None:
        if not settings.auto_y_range:
            return
        for _ in range(3):
            if not self._expand_axes_once_for_overlay_label_conflicts(ax):
                return
            self.canvas.draw()

    def _overlay_label_anchor_is_visible(
        self,
        x_value: float,
        y_value: float,
        settings: ChartSettings,
        uses_secondary_axis: bool = False,
    ) -> bool:
        if uses_secondary_axis:
            if settings.secondary_auto_y_range:
                return True
            low, high = sorted((settings.secondary_y_min, settings.secondary_y_max))
            return low <= (x_value if settings.chart_type == "Ridge" else y_value) <= high
        if settings.auto_y_range:
            return True
        if settings.chart_type == "Ridge":
            low, high = sorted((settings.y_min, settings.y_max))
            return low <= x_value <= high
        low, high = sorted((settings.y_min, settings.y_max))
        return low <= y_value <= high

    def _expand_axes_once_for_overlay_label_conflicts(self, ax) -> bool:
        labels = [
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and text.get_visible() and text.get_text()
        ]
        if len(labels) < 2:
            return False

        renderer = self.canvas.get_renderer()
        axes_bounds = ax.get_window_extent(renderer)
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        x_per_px = abs(x_max - x_min) / max(axes_bounds.width, 1.0)
        y_per_px = abs(y_max - y_min) / max(axes_bounds.height, 1.0)
        padding_px = 2.0
        expand_left = expand_right = expand_bottom = expand_top = 0.0
        bounds_by_label = {label: self._overlay_label_bounds(label, renderer) for label in labels}

        for left_index, left_label in enumerate(labels):
            left_bounds = bounds_by_label[left_label]
            for right_label in labels[left_index + 1:]:
                right_bounds = bounds_by_label[right_label]
                overlap_x = min(left_bounds.x1, right_bounds.x1) - max(left_bounds.x0, right_bounds.x0) + padding_px
                overlap_y = min(left_bounds.y1, right_bounds.y1) - max(left_bounds.y0, right_bounds.y0) + padding_px
                if overlap_x <= 0.0 or overlap_y <= 0.0:
                    continue
                moving_label = self._lower_priority_overlay_label(left_label, right_label)
                position = getattr(moving_label, "_easygraph_overlay_position", "Auto")
                if position == "Below":
                    expand_bottom = max(expand_bottom, overlap_y)
                elif position == "Above":
                    expand_top = max(expand_top, overlap_y)
                elif position == "Left":
                    expand_left = max(expand_left, overlap_x)
                elif position == "Right":
                    expand_right = max(expand_right, overlap_x)

        if max(expand_left, expand_right, expand_bottom, expand_top) <= 0.05:
            return False

        ax.set_xlim(x_min - expand_left * x_per_px, x_max + expand_right * x_per_px)
        ax.set_ylim(y_min - expand_bottom * y_per_px, y_max + expand_top * y_per_px)
        return True

    def _expand_axes_once_for_overlay_value_labels(self, ax) -> bool:
        renderer = self.canvas.get_renderer()
        axes_bounds = ax.get_window_extent(renderer)
        padding_px = 2.0
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        x_per_px = abs(x_max - x_min) / max(axes_bounds.width, 1.0)
        y_per_px = abs(y_max - y_min) / max(axes_bounds.height, 1.0)
        expand_left = expand_right = expand_bottom = expand_top = 0.0

        for text in ax.texts:
            if text.get_gid() != "overlay-value-label" or not text.get_visible() or not text.get_text():
                continue
            bounds = self._overlay_label_bounds(text, renderer)
            if bounds.x0 < axes_bounds.x0 + padding_px:
                expand_left = max(expand_left, axes_bounds.x0 + padding_px - bounds.x0)
            elif bounds.x1 > axes_bounds.x1 - padding_px:
                expand_right = max(expand_right, bounds.x1 - (axes_bounds.x1 - padding_px))
            if bounds.y0 < axes_bounds.y0 + padding_px:
                expand_bottom = max(expand_bottom, axes_bounds.y0 + padding_px - bounds.y0)
            elif bounds.y1 > axes_bounds.y1 - padding_px:
                expand_top = max(expand_top, bounds.y1 - (axes_bounds.y1 - padding_px))

        if max(expand_left, expand_right, expand_bottom, expand_top) <= 0.05:
            return False

        ax.set_xlim(x_min - expand_left * x_per_px, x_max + expand_right * x_per_px)
        ax.set_ylim(y_min - expand_bottom * y_per_px, y_max + expand_top * y_per_px)
        return True

    def _separate_overlay_value_labels(self, ax) -> None:
        labels = [
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and text.get_visible() and text.get_text()
        ]
        labels.sort(key=lambda text: getattr(text, "_easygraph_overlay_priority", 1))
        if not labels:
            return

        padding_px = 2.0
        for _ in range(4):
            self.canvas.draw()
            renderer = self.canvas.get_renderer()
            bounds_by_label = {label: self._overlay_label_bounds(label, renderer) for label in labels}
            moved = False
            for left_index, left_label in enumerate(labels):
                left_bounds = bounds_by_label[left_label]
                for right_label in labels[left_index + 1:]:
                    right_bounds = bounds_by_label[right_label]
                    overlap_x = min(left_bounds.x1, right_bounds.x1) - max(left_bounds.x0, right_bounds.x0) + padding_px
                    overlap_y = min(left_bounds.y1, right_bounds.y1) - max(left_bounds.y0, right_bounds.y0) + padding_px
                    if overlap_x <= 0.0 or overlap_y <= 0.0:
                        continue

                    left_center_x = (left_bounds.x0 + left_bounds.x1) / 2.0
                    right_center_x = (right_bounds.x0 + right_bounds.x1) / 2.0
                    left_center_y = (left_bounds.y0 + left_bounds.y1) / 2.0
                    right_center_y = (right_bounds.y0 + right_bounds.y1) / 2.0

                    moving_label = self._lower_priority_overlay_label(left_label, right_label)
                    fixed_bounds = right_bounds if moving_label is left_label else left_bounds
                    moving_bounds = left_bounds if moving_label is left_label else right_bounds
                    fixed_center_x = (fixed_bounds.x0 + fixed_bounds.x1) / 2.0
                    moving_center_x = (moving_bounds.x0 + moving_bounds.x1) / 2.0
                    fixed_center_y = (fixed_bounds.y0 + fixed_bounds.y1) / 2.0
                    moving_center_y = (moving_bounds.y0 + moving_bounds.y1) / 2.0

                    if overlap_x < overlap_y:
                        direction = 1.0 if moving_center_x >= fixed_center_x else -1.0
                        self._move_overlay_label(moving_label, direction * overlap_x, 0.0)
                    else:
                        direction = 1.0 if moving_center_y >= fixed_center_y else -1.0
                        self._move_overlay_label(moving_label, 0.0, direction * overlap_y)
                    moved = True

            if not moved:
                return

    def _move_overlay_label(self, text, dx_px: float, dy_px: float) -> None:
        pixel_to_points = 72.0 / max(self.figure.dpi, 1.0)
        x_offset, y_offset = text.get_position()
        text.set_position((x_offset + dx_px * pixel_to_points, y_offset + dy_px * pixel_to_points))

    def _mark_overlay_value_label(self, text, is_custom_overlay: bool, label_position: str) -> None:
        text.set_gid("overlay-value-label")
        text._easygraph_overlay_priority = 1 if is_custom_overlay else 0
        text._easygraph_overlay_position = label_position

    def _mark_overlay_line(self, line) -> None:
        line.set_gid("overlay-line")

    def _lower_priority_overlay_label(self, first, second):
        first_priority = getattr(first, "_easygraph_overlay_priority", 1)
        second_priority = getattr(second, "_easygraph_overlay_priority", 1)
        if first_priority > second_priority:
            return first
        return second

    def _overlay_label_bounds(self, text, renderer):
        bbox_patch = text.get_bbox_patch()
        if bbox_patch is not None:
            return bbox_patch.get_window_extent(renderer)
        return text.get_window_extent(renderer)

    def _place_legend_outside(self, ax, text_color: str, settings: ChartSettings, extra_axes: list | None = None) -> None:
        if not settings.show_legend:
            existing_legend = ax.get_legend()
            if existing_legend is not None:
                existing_legend.remove()
            return
        handles, labels = ax.get_legend_handles_labels()
        for extra_ax in extra_axes or []:
            if extra_ax is None:
                continue
            extra_handles, extra_labels = extra_ax.get_legend_handles_labels()
            handles.extend(extra_handles)
            labels.extend(extra_labels)
        if not labels:
            return

        existing_legend = ax.get_legend()
        if existing_legend is not None:
            existing_legend.remove()
        self.canvas.draw()
        renderer = self.canvas.get_renderer()
        columns = self._legend_column_count(labels, settings, renderer)
        force_wrap = self._legend_force_wrap(labels, settings, renderer)
        labels = [self._legend_label_text(label, settings, columns, renderer, force_wrap=force_wrap) for label in labels]
        legend_anchor_x = self._legend_right_anchor_x(ax, settings)
        legend = ax.legend(
            handles,
            labels,
            loc="upper left",
            bbox_to_anchor=(legend_anchor_x, 1.0),
            borderaxespad=0.0,
            frameon=False,
            fontsize=settings.legend_font_size,
            ncol=columns,
            columnspacing=1.0,
        )
        for text in legend.get_texts():
            text.set_color(text_color)

    def _legend_right_anchor_x(self, ax, settings: ChartSettings) -> float:
        base_anchor = 1.02
        if settings.chart_type == "Ridge" or not settings.custom_overlay_secondary_axis:
            return base_anchor

        secondary_ax = next((axis for axis in self.figure.axes if axis.get_gid() == "secondary-axis"), None)
        if secondary_ax is None or not secondary_ax.yaxis.label.get_text():
            return base_anchor

        renderer = self.canvas.get_renderer()
        axis_bounds = ax.get_window_extent(renderer)
        label_bounds = secondary_ax.yaxis.label.get_window_extent(renderer)
        if label_bounds.width <= 0.0:
            return base_anchor

        reserved_right_px = max(axis_bounds.x1, label_bounds.x1 + LEGEND_SECONDARY_AXIS_GAP_PX)
        anchor_x = 1.0 + (reserved_right_px - axis_bounds.x1) / max(axis_bounds.width, 1.0)
        return max(base_anchor, anchor_x)

    def _legend_label_text(
        self,
        label: object,
        settings: ChartSettings,
        columns: int = 1,
        renderer=None,
        force_wrap: bool = False,
    ) -> str:
        text = str(label).replace("\\n", "\n")
        if settings.legend_columns <= 0 and not force_wrap:
            return text
        if renderer is None:
            max_units = self._legend_wrap_units(settings, columns)
            wrapped_lines = []
            for line in text.splitlines() or [""]:
                wrapped_lines.extend(self._wrap_visual_units(line, max_units) or [""])
            return "\n".join(wrapped_lines)
        max_width_in = self._legend_text_width_inches(settings, columns)
        wrapped_lines = []
        for line in text.splitlines() or [""]:
            wrapped_lines.extend(self._wrap_text_to_width(line, max_width_in, settings.legend_font_size, renderer) or [""])
        return "\n".join(wrapped_lines)

    def _legend_wrap_units(self, settings: ChartSettings, columns: int = 1) -> float:
        width_in = self._legend_text_width_inches(settings, columns)
        return max(4.0, width_in * 72.0 / (max(settings.legend_font_size, 1) * 0.52))

    def _legend_text_width_inches(self, settings: ChartSettings, columns: int = 1) -> float:
        column_width_in = self._legend_column_width_inches(settings, columns)
        return max(0.20, column_width_in - self._legend_handle_space_inches(settings))

    def _legend_total_width_inches(self, settings: ChartSettings) -> float:
        return max(settings.legend_width, 0.5) / 2.54

    def _legend_handle_space_inches(self, settings: ChartSettings) -> float:
        return max(settings.legend_font_size, 1) * 2.65 / 72.0

    def _legend_column_gap_inches(self, settings: ChartSettings) -> float:
        return max(settings.legend_font_size, 1) * LEGEND_COLUMN_SPACING / 72.0

    def _legend_column_width_inches(self, settings: ChartSettings, columns: int) -> float:
        columns = max(1, columns)
        available_width = self._legend_total_width_inches(settings) - self._legend_column_gap_inches(settings) * (columns - 1)
        return max(0.25, available_width / columns)

    def _wrap_text_to_width(self, text: str, max_width_in: float, font_size: int, renderer) -> list[str]:
        if self._measured_text_width_inches(text, font_size, renderer) <= max_width_in:
            return [text]

        pieces = [piece for piece in re.split(r"(\s+|[-/_:;,，。；：、]+)", text) if piece]
        if len(pieces) <= 1:
            return self._wrap_unbreakable_text(text, max_width_in, font_size, renderer)

        lines = []
        current = ""
        token_tolerance_in = max_width_in * 1.25
        for piece in pieces:
            candidate = f"{current}{piece}" if current else piece.lstrip()
            if not candidate:
                continue
            if self._measured_text_width_inches(candidate.rstrip(), font_size, renderer) <= max_width_in:
                current = candidate
                continue
            if current.strip():
                lines.append(current.rstrip())
                current = piece.lstrip()
                if current and self._measured_text_width_inches(current, font_size, renderer) > max_width_in:
                    if self._measured_text_width_inches(current, font_size, renderer) <= token_tolerance_in:
                        lines.append(current)
                    else:
                        lines.extend(self._wrap_unbreakable_text(current, max_width_in, font_size, renderer))
                    current = ""
            else:
                stripped = piece.strip()
                if self._measured_text_width_inches(stripped, font_size, renderer) <= token_tolerance_in:
                    lines.append(stripped)
                else:
                    lines.extend(self._wrap_unbreakable_text(stripped, max_width_in, font_size, renderer))
                current = ""
        if current.strip():
            lines.append(current.rstrip())
        return lines

    def _wrap_unbreakable_text(self, text: str, max_width_in: float, font_size: int, renderer) -> list[str]:
        lines = []
        current = ""
        for char in text:
            candidate = f"{current}{char}"
            if current and self._measured_text_width_inches(candidate, font_size, renderer) > max_width_in:
                lines.append(current)
                current = char
            else:
                current = candidate
        if current or not lines:
            lines.append(current)
        return lines

    def _measured_text_width_inches(self, text: str, font_size: int, renderer) -> float:
        artist = self.figure.text(0, 0, text, fontsize=font_size, alpha=0.0)
        try:
            return artist.get_window_extent(renderer).width / max(self.figure.dpi, 1.0)
        finally:
            artist.remove()

    def _wrap_visual_units(self, text: str, max_units: float) -> list[str]:
        if self._text_visual_units(text) <= max_units:
            return [text]
        lines = []
        current = ""
        current_units = 0.0
        for char in text:
            char_units = 2.0 if unicodedata.east_asian_width(char) in {"F", "W"} else 1.0
            if current and current_units + char_units > max_units:
                lines.append(current.rstrip())
                current = char
                current_units = char_units
            else:
                current += char
                current_units += char_units
        if current or not lines:
            lines.append(current.rstrip())
        return lines

    def _legend_column_count(self, labels: list[str], settings: ChartSettings, renderer=None) -> int:
        item_count = max(1, len(labels))
        if settings.legend_columns > 0:
            return min(max(1, settings.legend_columns), item_count)

        max_item_width = max(
            (self._legend_unwrapped_item_width_inches(label, settings, renderer) for label in labels),
            default=self._legend_handle_space_inches(settings),
        )
        column_gap = self._legend_column_gap_inches(settings)
        total_width = self._legend_total_width_inches(settings)
        columns_that_fit = math.floor((total_width + column_gap) / max(max_item_width + column_gap, 0.01))
        return min(max(1, columns_that_fit), item_count, LEGEND_MAX_COLUMNS)

    def _legend_force_wrap(self, labels: list[str], settings: ChartSettings, renderer=None) -> bool:
        if settings.legend_columns > 0:
            return True
        max_item_width = max(
            (self._legend_unwrapped_item_width_inches(label, settings, renderer) for label in labels),
            default=self._legend_handle_space_inches(settings),
        )
        return self._legend_total_width_inches(settings) < max_item_width

    def _legend_unwrapped_item_width_inches(self, label: object, settings: ChartSettings, renderer=None) -> float:
        text = str(label).replace("\\n", "\n")
        lines = text.splitlines() or [""]
        if renderer is None:
            text_width = self._max_text_width_inches(lines, settings.legend_font_size)
        else:
            text_width = max((self._measured_text_width_inches(line, settings.legend_font_size, renderer) for line in lines), default=0.0)
        return text_width + self._legend_handle_space_inches(settings)

    def _overlay_axis_marker_margin_points(self, settings: ChartSettings) -> float:
        marker_areas = []
        if settings.show_points:
            marker_areas.append(settings.point_size * 12)
        if settings.show_outliers:
            marker_areas.append(max(settings.point_size * 18, 45))
        if not marker_areas:
            return 0.0
        return math.sqrt(max(marker_areas)) / 2.0 + 1.0

    def _draw_stat_table(
        self,
        table_ax,
        groups: list[str],
        rows: list[tuple[str, list[str]]],
        settings: ChartSettings,
        text_color: str,
    ) -> None:
        if not groups or not rows:
            return
        table_ax.set_xlim(-0.5, len(groups) - 0.5)
        font_size = settings.stat_table_font_size
        all_rows = [("", [str(group) for group in groups])] if settings.show_stat_header else []
        all_rows.extend(rows)
        row_heights = self._stat_table_row_height_units(groups, rows, settings)
        total_height = sum(row_heights)
        table_ax.set_ylim(0, total_height)
        table_ax.axis("off")
        preset = PRESETS[settings.preset]
        edge_color = "#D1D5DB" if preset["background"] == "#FFFFFF" else "#4B5563"
        header_face = "#F3F4F6" if preset["background"] == "#FFFFFF" else "#1F2937"
        cell_face = "#FFFFFF" if preset["background"] == "#FFFFFF" else "#111827"

        y_cursor = total_height
        row_edges = [total_height]
        for row_index, (label, values) in enumerate(all_rows):
            row_height = row_heights[row_index]
            y_cursor -= row_height
            row_edges.append(y_cursor)
            facecolor = header_face if settings.show_stat_header and row_index == 0 else cell_face
            if label:
                table_ax.text(
                    -0.58,
                    y_cursor + row_height / 2,
                    label,
                    ha="right",
                    va="center",
                    color=text_color,
                    fontsize=font_size,
                    clip_on=False,
                    linespacing=1.15,
                )
            for column, value in enumerate(values):
                table_ax.add_patch(Rectangle((column - 0.5, y_cursor), 1, row_height, facecolor=facecolor, edgecolor="none", linewidth=0))
                table_ax.text(
                    column,
                    y_cursor + row_height / 2,
                    value,
                    ha="center",
                    va="center",
                    color=text_color,
                    fontsize=font_size,
                    linespacing=1.15,
                )
        line_width = 0.6
        for x_value in np.arange(-0.5, len(groups) + 0.5, 1.0):
            table_ax.vlines(x_value, 0, total_height, colors=edge_color, linewidth=line_width, clip_on=False)
        for y_value in row_edges:
            table_ax.hlines(y_value, -0.5, len(groups) - 0.5, colors=edge_color, linewidth=line_width, clip_on=False)

    def _fit_table_left_margin(self, ax, table_ax, settings: ChartSettings) -> None:
        for _ in range(3):
            self.canvas.draw()
            renderer = self.canvas.get_renderer()
            text_artists = [text for text in table_ax.texts if text.get_visible()]
            text_artists.append(ax.yaxis.label)
            if settings.chart_type == "Ridge":
                text_artists.extend(label for label in ax.get_yticklabels() if label.get_visible())
            left_edges = [
                artist.get_window_extent(renderer).x0
                for artist in text_artists
                if artist.get_text()
            ]
            if not left_edges:
                return
            overflow_px = 6.0 - min(left_edges)
            if overflow_px <= 0:
                return
            delta = overflow_px / max(self.figure.bbox.width, 1.0)
            for target_ax in (ax, table_ax):
                position = target_ax.get_position()
                new_left = min(position.x0 + delta, position.x1 - 0.20)
                target_ax.set_position([new_left, position.y0, position.x1 - new_left, position.height])

    def _stat_table_row_height_inches(self, settings: ChartSettings) -> float:
        font_height = max(settings.stat_table_font_size, 1) / 72.0
        return font_height + 0.10

    def _stat_table_height_inches(self, groups: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings) -> float:
        return self._stat_table_row_height_inches(settings) * sum(self._stat_table_row_height_units(groups, rows, settings))

    def _stat_table_row_height_units(self, groups: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings) -> list[float]:
        heights = []
        if settings.show_stat_header:
            heights.append(max(1.0, self._max_line_count(groups) * 0.96))
        heights.extend(1.0 for _ in rows)
        return heights

    def _stat_table_gap_inches(self, settings: ChartSettings, groups: list[str], x_axis_label: str) -> float:
        tick_height = max(settings.tick_font_size, 1) / 72.0 * self._max_line_count(groups) * 1.15
        tick_width = self._max_text_width_inches(groups, settings.tick_font_size)
        rotation = math.radians(abs(settings.x_tick_rotation))
        rotated_tick_height = tick_width * math.sin(rotation) + tick_height * math.cos(rotation)
        label_height = max(settings.axis_label_font_size, 1) / 72.0 * self._line_count(x_axis_label) * 1.25 if x_axis_label else 0.0
        overlay_height = 0.0
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        if settings.show_line_overlay and settings.show_line_values and line_value_position == "Bottom axis":
            overlay_height = (
                max(settings.line_value_font_size, 1) * 1.35
                + OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                + OVERLAY_AXIS_LABEL_FIXED_PAD_POINTS
            ) / 72.0
        tick_pad = 0.10 if groups else 0.0
        label_pad = 0.08 if x_axis_label else 0.0
        table_pad = 0.08
        return tick_pad + rotated_tick_height + label_pad + label_height + overlay_height + table_pad

    def _plot_left_margin_inches(
        self,
        settings: ChartSettings,
        groups: list[object],
        y_axis_label: str,
        stat_rows: list[tuple[str, list[str]]],
    ) -> float:
        left_margin_in = 0.62
        if y_axis_label:
            left_margin_in = max(left_margin_in, self._rotated_axis_label_width_inches(y_axis_label, settings.axis_label_font_size))
        if settings.chart_type == "Ridge":
            tick_width_in = self._max_text_width_inches(groups, settings.tick_font_size)
            axis_label_in = self._rotated_axis_label_width_inches(y_axis_label, settings.axis_label_font_size, pad=0.0) if y_axis_label else 0.0
            left_margin_in = max(left_margin_in, tick_width_in + axis_label_in + 0.38)
        if stat_rows:
            row_labels = [label for label, _values in stat_rows if label]
            left_margin_in = max(left_margin_in, self._max_text_width_inches(row_labels, settings.stat_table_font_size) + 0.62)
        if (
            settings.chart_type == "Ridge"
            and settings.show_line_overlay
            and settings.show_line_values
            and normalize_overlay_label_position(settings.line_value_position, settings.chart_type) == "Axis left"
        ):
            left_margin_in += max(settings.line_value_font_size, 1) * 3.0 / 72.0
        return left_margin_in

    def _rotated_axis_label_width_inches(self, text: str, font_size: int, pad: float = 0.30) -> float:
        return max(font_size, 1) / 72.0 * (self._line_count(text) + 0.9) + pad

    def _plot_right_margin_inches(self, settings: ChartSettings) -> float:
        right_margin_in = self._legend_right_margin_inches(settings) if self._legend_outside_needed(settings) else 0.20
        if settings.custom_overlay_secondary_axis and settings.chart_type != "Ridge":
            right_margin_in += max(
                0.62,
                self._rotated_axis_label_width_inches(settings.secondary_y_label, settings.axis_label_font_size),
            )
        if (
            settings.chart_type == "Ridge"
            and settings.show_line_overlay
            and settings.show_line_values
            and normalize_overlay_label_position(settings.line_value_position, settings.chart_type) == "Axis right"
        ):
            right_margin_in += max(settings.line_value_font_size, 1) * 3.0 / 72.0
        return right_margin_in

    def _legend_outside_needed(self, settings: ChartSettings) -> bool:
        return bool(
            settings.show_legend
            and (
                (settings.chart_type != "Ridge" and settings.show_outliers)
                or settings.line_overlay_stat != "None"
                or settings.extra_custom_overlay
            )
        )

    def _legend_right_margin_inches(self, settings: ChartSettings) -> float:
        return max(0.45, settings.legend_width / 2.54) + 0.35

    def _legend_labels_for_settings(self, settings: ChartSettings) -> list[str]:
        if not settings.show_legend:
            return []
        labels = []
        if settings.chart_type != "Ridge" and settings.show_outliers:
            labels.append("Outlier")
        if settings.line_overlay_stat != "None":
            labels.append(settings.line_overlay_stat)
        if settings.extra_custom_overlay:
            for index in visible_custom_overlay_indexes(settings):
                name = ""
                if index < len(settings.custom_overlay_series):
                    name = str(settings.custom_overlay_series[index].get("name", "")).strip()
                labels.append(name or f"Overlay {index + 1}")
        return labels

    def _plot_top_margin_inches(self, settings: ChartSettings) -> float:
        title_height = max(settings.title_font_size, 1) / 72.0 * self._line_count(settings.title)
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        overlay_extra = 0.06 if settings.show_line_overlay and settings.show_line_values and line_value_position == "Top axis" else 0.0
        secondary_label_height = 0.0
        if settings.custom_overlay_secondary_axis and settings.chart_type == "Ridge":
            secondary_label_height = (
                max(settings.axis_label_font_size, 1) / 72.0 * self._line_count(settings.secondary_y_label) * 1.25
                if settings.secondary_y_label
                else 0.0
            )
        secondary_tick_height = max(settings.tick_font_size, 1) / 72.0 * 1.15 if settings.custom_overlay_secondary_axis and settings.chart_type == "Ridge" else 0.0
        return 0.16 + title_height * 1.15 + overlay_extra + secondary_tick_height + secondary_label_height

    def _plot_bottom_margin_inches(self, settings: ChartSettings, groups: list[str], x_axis_label: str) -> float:
        tick_height = max(settings.tick_font_size, 1) / 72.0 * self._max_line_count(groups) * 1.15
        tick_width = self._max_text_width_inches(groups, settings.tick_font_size)
        rotation = math.radians(abs(settings.x_tick_rotation))
        rotated_tick_height = tick_width * math.sin(rotation) + tick_height * math.cos(rotation)
        label_height = max(settings.axis_label_font_size, 1) / 72.0 * self._line_count(x_axis_label) * 1.25 if x_axis_label else 0.0
        overlay_height = 0.0
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        if settings.show_line_overlay and settings.show_line_values and line_value_position == "Bottom axis":
            overlay_height = (
                max(settings.line_value_font_size, 1) * 1.35
                + OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                + OVERLAY_AXIS_LABEL_FIXED_PAD_POINTS
            ) / 72.0
        tick_pad = 0.10 if groups else 0.0
        label_pad = 0.08 if x_axis_label else 0.0
        return 0.12 + tick_pad + rotated_tick_height + label_pad + label_height + overlay_height

    def _line_count(self, text: object) -> int:
        return max(1, str(text).count("\n") + 1)

    def _max_line_count(self, values: list[object]) -> int:
        return max([self._line_count(value) for value in values] or [1])

    def _max_text_width_inches(self, values: list[object], font_size: int) -> float:
        max_units = 0.0
        for value in values:
            for line in str(value).splitlines() or [""]:
                max_units = max(max_units, self._text_visual_units(line))
        return max_units * max(font_size, 1) * 0.52 / 72.0

    def _text_visual_units(self, text: str) -> float:
        return sum(2.0 if unicodedata.east_asian_width(char) in {"F", "W"} else 1.0 for char in text)

    def _jitter_offsets(self, values: np.ndarray, width: float, mode: str, key: str) -> np.ndarray:
        values = np.asarray(values, dtype=float)
        count = len(values)
        if count == 0 or width <= 0:
            return np.zeros(count)
        if mode == "Random":
            return self._random_offsets(key, count, width)
        if mode == "Quasirandom":
            return self._quasirandom_offsets(values, width)
        return self._beeswarm_offsets(values, width)

    def _random_offsets(self, key: str, count: int, width: float) -> np.ndarray:
        seed = 20240527 + sum(ord(ch) for ch in key)
        rng = np.random.default_rng(seed)
        return rng.uniform(-width, width, count)

    def _beeswarm_offsets(self, values: np.ndarray, width: float) -> np.ndarray:
        count = len(values)
        offsets = np.zeros(count)
        if count <= 1:
            return offsets

        finite = values[np.isfinite(values)]
        if len(finite) == 0:
            return offsets
        value_span = float(np.max(finite) - np.min(finite))
        bin_width = max(value_span / 24, 1e-9)
        bins = np.floor((values - float(np.min(finite))) / bin_width).astype(int)

        for bin_id in np.unique(bins):
            idx = np.where(bins == bin_id)[0]
            idx = idx[np.argsort(values[idx], kind="mergesort")]
            n = len(idx)
            if n == 1:
                offsets[idx[0]] = 0.0
                continue
            max_level = max(1, math.ceil((n - 1) / 2))
            step = width / max_level
            sequence = [0.0]
            for level in range(1, max_level + 1):
                sequence.extend([-level * step, level * step])
            offsets[idx] = np.array(sequence[:n])
        return np.clip(offsets, -width, width)

    def _quasirandom_offsets(self, values: np.ndarray, width: float) -> np.ndarray:
        count = len(values)
        if count <= 1:
            return np.zeros(count)

        order = np.argsort(values, kind="mergesort")
        base_offsets = np.array([self._van_der_corput(i + 1) for i in range(count)]) - 0.5
        base_offsets *= 2 * width

        density_scale = np.ones(count)
        finite = values[np.isfinite(values)]
        if len(finite) > 2 and not math.isclose(float(np.std(finite)), 0.0):
            try:
                kde = gaussian_kde(finite)
                density = kde(values)
                max_density = float(np.max(density))
                if max_density > 0:
                    density_scale = 0.25 + 0.75 * density / max_density
            except Exception:
                density_scale = np.ones(count)

        offsets = np.zeros(count)
        offsets[order] = base_offsets * density_scale[order]
        return np.clip(offsets, -width, width)

    def _van_der_corput(self, index: int, base: int = 2) -> float:
        result = 0.0
        denominator = 1.0
        while index:
            index, remainder = divmod(index, base)
            denominator *= base
            result += remainder / denominator
        return result

    def export(self, path: str, settings: ChartSettings) -> None:
        suffix = Path(path).suffix.lower()
        kwargs = {
            "dpi": settings.dpi,
            "facecolor": "none" if settings.transparent_background else self.figure.get_facecolor(),
            "bbox_inches": "tight",
            "transparent": settings.transparent_background,
        }
        if suffix in {".png", ".tif", ".tiff", ".jpg", ".jpeg", ".pdf", ".svg"}:
            self.figure.savefig(path, **kwargs)

    def copy_to_clipboard(self, settings: ChartSettings) -> bool:
        buffer = BytesIO()
        self.figure.savefig(
            buffer,
            format="png",
            dpi=settings.dpi,
            facecolor="none" if settings.transparent_background else self.figure.get_facecolor(),
            bbox_inches="tight",
            transparent=settings.transparent_background,
        )
        image = QImage()
        image.loadFromData(buffer.getvalue(), "PNG")
        if image.isNull():
            return False
        QApplication.clipboard().setImage(image)
        return True


from ui_main_window import Ui_MainWindow
from ui_group_order_dialog import Ui_GroupOrderDialog


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.settings = ChartSettings()
        self.current_project: Path | None = None
        self._applying_settings = False
        self._committing_control_edits = False
        self._custom_overlay_rows = 0
        self._table_undo_stack: list[dict] = []
        self._table_redo_stack: list[dict] = []
        self._last_table_snapshot: dict | None = None
        self._table_history_restoring = False
        self._table_history_suspended = False
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.setInterval(APP_RENDER_DEBOUNCE_MS)
        self._render_timer.timeout.connect(self.flush_pending_render)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.table = self.ui.dataTable
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.table.set_dataframe = self.set_table_dataframe
        self.table.dataframe = self.table_dataframe
        self.canvas = PlotCanvas()
        self.ui.plotHostLayout.addWidget(self.canvas)
        self._bind_ui_widgets()
        self._populate_ui_options()
        self.refresh_template_combo()
        self._polish_input_controls()
        self.table.set_dataframe(sample_data())
        self.reset_table_history()
        self.apply_settings_to_controls()
        self._connect_generated_ui()
        self.render()

    def _bind_ui_widgets(self) -> None:
        self.template_combo = self.ui.templateCombo
        self.chart_type = self.ui.chartTypeCombo
        self.preset = self.ui.presetCombo
        self.group_order = self.ui.groupOrderCombo
        self.group_filter_button = self.ui.groupFilterButton
        self.edit_group_colors_button = QPushButton(self.tr("Colors"))
        self.ui.presetComboFieldLayout.addWidget(self.edit_group_colors_button)
        self.title = self.ui.titleEdit
        self.x_label = self.ui.xLabelEdit
        self.y_label = self.ui.yLabelEdit
        self.secondary_y_label_label = QLabel(self.tr("Secondary value \naxis title"), self.ui.chartGroup)
        self.secondary_y_label_label.setObjectName("secondaryYLabelLabel")
        self.secondary_y_label = QPlainTextEdit(self.ui.chartGroup)
        self.secondary_y_label.setObjectName("secondaryYLabelEdit")
        self.secondary_y_label.setMinimumSize(QSize(0, 44))
        self.secondary_y_label.setMaximumSize(QSize(16777215, 48))
        self.secondary_y_label.setTabChangesFocus(True)
        self.secondary_y_label.setPlaceholderText(self.tr("Enter to line break"))
        self.secondary_y_label.setPlainText(self.settings.secondary_y_label)
        self.ui.chartForm.insertRow(6, self.secondary_y_label_label, self.secondary_y_label)
        self.width = self.ui.widthSpin
        self.height = self.ui.heightSpin
        self.dpi = self.ui.dpiSpin
        self.transparent_background = self.ui.transparentBackgroundCheck
        self.title_font_size = self.ui.titleFontSizeSpin
        self.axis_label_font_size = self.ui.axisLabelFontSizeSpin
        self.tick_font_size = self.ui.tickFontSizeSpin
        self.decrease_all_fonts_button = self.ui.decreaseAllFontsButton
        self.increase_all_fonts_button = self.ui.increaseAllFontsButton
        self.legend_font_size = QSpinBox(self.ui.fontGroup)
        self.legend_font_size.setObjectName("legendFontSizeSpin")
        self.legend_font_size.setRange(5, 36)
        self.legend_font_size.setValue(self.settings.legend_font_size)
        self._add_right_aligned_form_row(self.ui.fontForm, self.tr("Legend size"), self.legend_font_size)
        self.legend_group = QGroupBox(self.tr("Legend"), self.ui.controlsContent)
        self.legend_group.setObjectName("legendGroup")
        self.legend_form = QFormLayout(self.legend_group)
        self.legend_form.setObjectName("legendForm")
        self.legend_form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.legend_form.setLabelAlignment(Qt.AlignmentFlag.AlignLeading | Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.legend_form.setFormAlignment(Qt.AlignmentFlag.AlignLeading | Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.legend_form.setHorizontalSpacing(12)
        self.legend_form.setVerticalSpacing(6)
        self.legend_form.setContentsMargins(8, 10, 8, 8)
        legend_insert_index = self.ui.controlsLayout.indexOf(self.ui.fontGroup) + 1
        self.ui.controlsLayout.insertWidget(legend_insert_index, self.legend_group)
        self.show_legend = QCheckBox(self.legend_group)
        self.show_legend.setObjectName("showLegendCheck")
        self.show_legend.setChecked(self.settings.show_legend)
        self.legend_width = QDoubleSpinBox(self.legend_group)
        self.legend_width.setObjectName("legendWidthSpin")
        self.legend_width.setRange(0.5, 20.0)
        self.legend_width.setSingleStep(0.1)
        self.legend_width.setDecimals(2)
        self.legend_width.setValue(self.settings.legend_width)
        self.legend_columns = QComboBox(self.legend_group)
        self.legend_columns.setObjectName("legendColumnsCombo")
        self.legend_columns.addItems([self.tr("Auto"), "1", "2", "3", "4", "5", "6"])
        self._add_right_aligned_form_row(self.legend_form, self.tr("Show legend"), self.show_legend)
        self._add_right_aligned_form_row(self.legend_form, self.tr("Width (cm)"), self.legend_width)
        self._add_right_aligned_form_row(self.legend_form, self.tr("Columns"), self.legend_columns)
        self.line_value_font_size = self.ui.lineValueFontSizeSpin
        self.stat_table_font_size = self.ui.statTableFontSizeSpin
        self.show_grid = self.ui.showGridCheck
        self.auto_y_range = self.ui.autoYRangeCheck
        self.axis_line_width = self.ui.axisLineWidthSpin
        self.x_tick_rotation = self.ui.xTickRotationSpin
        self.y_min = self.ui.yMinSpin
        self.y_max = self.ui.yMaxSpin
        self.primary_auto_tick_interval_label = QLabel(self.tr("Auto Primary Y Tick Interval"), self.ui.axisGroup)
        self.primary_auto_tick_interval_label.setObjectName("primaryAutoTickIntervalLabel")
        self.primary_auto_tick_interval = QCheckBox(self.ui.axisGroup)
        self.primary_auto_tick_interval.setObjectName("primaryAutoTickIntervalCheck")
        self.primary_auto_tick_interval.setChecked(self.settings.primary_auto_tick_interval)
        self.primary_tick_interval_label = QLabel(self.tr("Primary Y tick interval"), self.ui.axisGroup)
        self.primary_tick_interval_label.setObjectName("primaryTickIntervalLabel")
        self.primary_tick_interval = QDoubleSpinBox(self.ui.axisGroup)
        self.primary_tick_interval.setObjectName("primaryTickIntervalSpin")
        self.primary_tick_interval.setRange(0.000001, 1_000_000)
        self.primary_tick_interval.setSingleStep(0.5)
        self.primary_tick_interval.setDecimals(6)
        self.primary_tick_interval.setValue(self.settings.primary_tick_interval)
        self.secondary_auto_y_range_label = QLabel(self.tr("Auto Secondary Y Range"), self.ui.axisGroup)
        self.secondary_auto_y_range_label.setObjectName("secondaryAutoYLabel")
        self.secondary_auto_y_range = QCheckBox(self.ui.axisGroup)
        self.secondary_auto_y_range.setObjectName("secondaryAutoYRangeCheck")
        self.secondary_auto_y_range.setChecked(self.settings.secondary_auto_y_range)
        self.secondary_y_min_label = QLabel(self.tr("Secondary Y min"), self.ui.axisGroup)
        self.secondary_y_min_label.setObjectName("secondaryYMinLabel")
        self.secondary_y_min = QDoubleSpinBox(self.ui.axisGroup)
        self.secondary_y_min.setObjectName("secondaryYMinSpin")
        self.secondary_y_min.setRange(-1_000_000, 1_000_000)
        self.secondary_y_min.setSingleStep(0.5)
        self.secondary_y_min.setValue(self.settings.secondary_y_min)
        self.secondary_y_max_label = QLabel(self.tr("Secondary Y max"), self.ui.axisGroup)
        self.secondary_y_max_label.setObjectName("secondaryYMaxLabel")
        self.secondary_y_max = QDoubleSpinBox(self.ui.axisGroup)
        self.secondary_y_max.setObjectName("secondaryYMaxSpin")
        self.secondary_y_max.setRange(-1_000_000, 1_000_000)
        self.secondary_y_max.setSingleStep(0.5)
        self.secondary_y_max.setValue(self.settings.secondary_y_max)
        self.secondary_auto_tick_interval_label = QLabel(self.tr("Auto Secondary Y Tick Interval"), self.ui.axisGroup)
        self.secondary_auto_tick_interval_label.setObjectName("secondaryAutoTickIntervalLabel")
        self.secondary_auto_tick_interval = QCheckBox(self.ui.axisGroup)
        self.secondary_auto_tick_interval.setObjectName("secondaryAutoTickIntervalCheck")
        self.secondary_auto_tick_interval.setChecked(self.settings.secondary_auto_tick_interval)
        self.secondary_tick_interval_label = QLabel(self.tr("Secondary Y tick interval"), self.ui.axisGroup)
        self.secondary_tick_interval_label.setObjectName("secondaryTickIntervalLabel")
        self.secondary_tick_interval = QDoubleSpinBox(self.ui.axisGroup)
        self.secondary_tick_interval.setObjectName("secondaryTickIntervalSpin")
        self.secondary_tick_interval.setRange(0.000001, 1_000_000)
        self.secondary_tick_interval.setSingleStep(0.5)
        self.secondary_tick_interval.setDecimals(6)
        self.secondary_tick_interval.setValue(self.settings.secondary_tick_interval)
        self.split_secondary_axis_label = QLabel(self.tr("Split secondary frame"), self.ui.axisGroup)
        self.split_secondary_axis_label.setObjectName("splitSecondaryAxisLabel")
        self.split_secondary_axis = QCheckBox(self.ui.axisGroup)
        self.split_secondary_axis.setObjectName("splitSecondaryAxisCheck")
        self.split_secondary_axis.setChecked(self.settings.split_secondary_axis)
        self.secondary_axis_split_ratio_label = QLabel(self.tr("Secondary frame ratio"), self.ui.axisGroup)
        self.secondary_axis_split_ratio_label.setObjectName("secondaryAxisSplitRatioLabel")
        self.secondary_axis_split_ratio = QDoubleSpinBox(self.ui.axisGroup)
        self.secondary_axis_split_ratio.setObjectName("secondaryAxisSplitRatioSpin")
        self.secondary_axis_split_ratio.setRange(0.15, 0.85)
        self.secondary_axis_split_ratio.setSingleStep(0.05)
        self.secondary_axis_split_ratio.setDecimals(2)
        self.secondary_axis_split_ratio.setValue(self.settings.secondary_axis_split_ratio)
        self.ui.axisForm.addRow(
            self.primary_auto_tick_interval_label,
            self._right_aligned_field_layout(self.primary_auto_tick_interval),
        )
        self.ui.axisForm.addRow(
            self.primary_tick_interval_label,
            self._right_aligned_field_layout(self.primary_tick_interval),
        )
        self.ui.axisForm.addRow(
            self.secondary_auto_y_range_label,
            self._right_aligned_field_layout(self.secondary_auto_y_range),
        )
        secondary_y_min_field_layout = QHBoxLayout()
        secondary_y_min_field_layout.setSpacing(0)
        secondary_y_min_field_layout.setContentsMargins(0, 0, 0, 0)
        secondary_y_min_field_layout.addStretch(1)
        secondary_y_min_field_layout.addWidget(self.secondary_y_min)
        self.ui.axisForm.addRow(self.secondary_y_min_label, secondary_y_min_field_layout)
        secondary_y_max_field_layout = QHBoxLayout()
        secondary_y_max_field_layout.setSpacing(0)
        secondary_y_max_field_layout.setContentsMargins(0, 0, 0, 0)
        secondary_y_max_field_layout.addStretch(1)
        secondary_y_max_field_layout.addWidget(self.secondary_y_max)
        self.ui.axisForm.addRow(self.secondary_y_max_label, secondary_y_max_field_layout)
        self.ui.axisForm.addRow(
            self.secondary_auto_tick_interval_label,
            self._right_aligned_field_layout(self.secondary_auto_tick_interval),
        )
        self.ui.axisForm.addRow(
            self.secondary_tick_interval_label,
            self._right_aligned_field_layout(self.secondary_tick_interval),
        )
        self.ui.axisForm.addRow(
            self.split_secondary_axis_label,
            self._right_aligned_field_layout(self.split_secondary_axis),
        )
        secondary_axis_split_ratio_field_layout = QHBoxLayout()
        secondary_axis_split_ratio_field_layout.setSpacing(0)
        secondary_axis_split_ratio_field_layout.setContentsMargins(0, 0, 0, 0)
        secondary_axis_split_ratio_field_layout.addStretch(1)
        secondary_axis_split_ratio_field_layout.addWidget(self.secondary_axis_split_ratio)
        self.ui.axisForm.addRow(self.secondary_axis_split_ratio_label, secondary_axis_split_ratio_field_layout)
        self.show_points = self.ui.showPointsCheck
        self.point_size = self.ui.pointSizeSpin
        self.point_alpha = self.ui.pointAlphaSpin
        self.jitter_mode = self.ui.jitterModeCombo
        self.jitter = self.ui.jitterSpin
        self.show_line_overlay = self.ui.showLineOverlayCheck
        self.line_overlay_stat = self.ui.lineOverlayStatCombo
        self.extra_custom_overlay = self.ui.extraCustomOverlayCheck
        self.custom_overlay_count = self.ui.customOverlayCountSpin
        self.add_overlay_button = self.ui.addOverlayButton
        self.remove_overlay_button = self.ui.removeOverlayButton
        self.custom_overlay_filter_button = self.ui.customOverlayFilterButton
        self.custom_overlay_secondary_axis_label = self.ui.customOverlaySecondaryAxisLabel
        self.custom_overlay_secondary_axis = self.ui.customOverlaySecondaryAxisCheck
        self.custom_overlay_secondary_axis.setChecked(self.settings.custom_overlay_secondary_axis)
        self.line_overlay_width = self.ui.lineOverlayWidthSpin
        self.line_overlay_style = self.ui.lineOverlayStyleCombo
        self.line_overlay_point_size = self.ui.lineOverlayPointSizeSpin
        self.show_line_values = self.ui.showLineValuesCheck
        self.line_value_position = self.ui.lineValuePositionCombo
        self.custom_line_value_position = self.ui.customLineValuePositionCombo
        self.line_value_scientific = self.ui.lineValueScientificCheck
        self.line_value_decimals = self.ui.lineValueDecimalsSpin
        self.show_stat_table = self.ui.showStatTableCheck
        self.show_stat_header = self.ui.showStatHeaderCheck
        self.stat_table_options = self.ui.statTableOptionsList
        self.show_outliers = self.ui.showOutliersCheck
        self.outlier_method = self.ui.outlierMethodCombo
        self.outlier_threshold = self.ui.outlierThresholdSpin
        self.outlier_effect = self.ui.outlierEffectCombo
        self.box_width = self.ui.boxWidthSpin
        self.box_whisker_mode = self.ui.boxWhiskerModeCombo
        self.violin_width = self.ui.violinWidthSpin
        self.kde_bandwidth = self.ui.kdeBandwidthSpin
        self.ridge_overlap = self.ui.ridgeOverlapSpin
        self.fill_alpha = self.ui.fillAlphaSpin

    def _add_right_aligned_form_row(self, form: QFormLayout, label: str, widget: QWidget) -> None:
        field_layout = QHBoxLayout()
        field_layout.setSpacing(0)
        field_layout.setContentsMargins(0, 0, 0, 0)
        field_layout.addStretch(1)
        field_layout.addWidget(widget)
        form.addRow(label, field_layout)

    def _right_aligned_field_layout(self, widget: QWidget) -> QHBoxLayout:
        field_layout = QHBoxLayout()
        field_layout.setSpacing(0)
        field_layout.setContentsMargins(0, 0, 0, 0)
        field_layout.addStretch(1)
        field_layout.addWidget(widget)
        return field_layout

    def _populate_ui_options(self) -> None:
        self.chart_type.addItems(["Box", "Violin", "Ridge"])
        self.preset.addItems(list(PRESETS))
        self.group_order.addItems([
            "Table order",
            "Manual",
            "Name A-Z",
            "Name Z-A",
            "Mean ascending",
            "Mean descending",
            "Median ascending",
            "Median descending",
        ])
        self.jitter_mode.addItems(["Beeswarm", "Quasirandom", "Random"])
        self.line_overlay_stat.addItems(["None", "Median", "Mean"])
        self.line_overlay_style.addItems(["Solid", "Dashed", "Dotted", "Dash-dot"])
        self._refresh_line_value_position_options()
        self.custom_line_value_position.addItems(["Auto", "Above", "Below", "Left", "Right"])
        self.outlier_method.addItems(["IQR", "Z-score", "MAD", "Percentile"])
        self.outlier_effect.addItems(["Mark only", "Exclude from distribution"])
        self.box_whisker_mode.addItems(["Tukey 1.5 IQR", "Min-Max", "Percentile 5-95", "Percentile 10-90"])
        self._populate_stat_table_options()

    def _populate_stat_table_options(self) -> None:
        self.stat_table_options.clear()
        for setting_name, label in STAT_TABLE_OPTIONS:
            item = QListWidgetItem(label)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if getattr(self.settings, setting_name) else Qt.Unchecked)
            item.setSizeHint(QSize(0, 22))
            self.stat_table_options.addItem(item)

    def _stat_table_option_checked(self, setting_name: str) -> bool:
        for index, (option_name, _label) in enumerate(STAT_TABLE_OPTIONS):
            if option_name == setting_name:
                item = self.stat_table_options.item(index)
                return item is not None and item.checkState() == Qt.Checked
        return False

    def _apply_stat_table_options_to_controls(self) -> None:
        self.stat_table_options.blockSignals(True)
        try:
            for index, (setting_name, _label) in enumerate(STAT_TABLE_OPTIONS):
                item = self.stat_table_options.item(index)
                if item is not None:
                    item.setCheckState(Qt.Checked if getattr(self.settings, setting_name) else Qt.Unchecked)
        finally:
            self.stat_table_options.blockSignals(False)

    def _line_value_position_options(self) -> list[str]:
        axis_options = ["Axis left", "Axis right"] if self.chart_type.currentText() == "Ridge" else ["Top axis", "Bottom axis"]
        return ["Auto", "Above", "Below", "Left", "Right", *axis_options]

    def _refresh_line_value_position_options(self, preferred: str | None = None) -> None:
        options = self._line_value_position_options()
        current_options = [self.line_value_position.itemText(index) for index in range(self.line_value_position.count())]
        current = preferred if preferred is not None else self.line_value_position.currentText()
        selected = normalize_overlay_label_position(current, self.chart_type.currentText())
        if current_options == options:
            self.line_value_position.setCurrentText(selected)
            return

        self.line_value_position.blockSignals(True)
        try:
            self.line_value_position.clear()
            self.line_value_position.addItems(options)
            self.line_value_position.setCurrentText(selected)
        finally:
            self.line_value_position.blockSignals(False)

    def _legend_columns_control_value(self) -> int:
        text = self.legend_columns.currentText()
        return int(text) if text.isdigit() else 0

    def _combo_boxes(self) -> list[QComboBox]:
        return [
            self.chart_type,
            self.preset,
            self.group_order,
            self.legend_columns,
            self.jitter_mode,
            self.line_overlay_stat,
            self.line_overlay_style,
            self.line_value_position,
            self.custom_line_value_position,
            self.outlier_method,
            self.outlier_effect,
            self.box_whisker_mode,
        ]

    def _spin_boxes(self) -> list[QSpinBox | QDoubleSpinBox]:
        return [
            self.width,
            self.height,
            self.dpi,
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.legend_font_size,
            self.legend_width,
            self.line_value_font_size,
            self.stat_table_font_size,
            self.custom_overlay_count,
            self.line_overlay_width,
            self.line_overlay_point_size,
            self.axis_line_width,
            self.x_tick_rotation,
            self.y_min,
            self.y_max,
            self.primary_tick_interval,
            self.secondary_y_min,
            self.secondary_y_max,
            self.secondary_tick_interval,
            self.secondary_axis_split_ratio,
            self.point_size,
            self.point_alpha,
            self.jitter,
            self.line_value_decimals,
            self.outlier_threshold,
            self.box_width,
            self.violin_width,
            self.kde_bandwidth,
            self.ridge_overlap,
            self.fill_alpha,
        ]

    def _buttons(self) -> list[QPushButton]:
        return [
            self.ui.addRowButton,
            self.ui.addColumnButton,
            self.ui.deleteColumnButton,
            self.ui.renameColumnButton,
            self.add_overlay_button,
            self.remove_overlay_button,
            self.custom_overlay_filter_button,
            self.ui.copyImageButton,
            self.ui.editGroupOrderButton,
            self.group_filter_button,
            self.edit_group_colors_button,
            self.decrease_all_fonts_button,
            self.increase_all_fonts_button,
            self.ui.loadTemplateButton,
            self.ui.saveTemplateButton,
        ]

    def _font_size_controls(self) -> list[QSpinBox]:
        return [
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.legend_font_size,
            self.line_value_font_size,
            self.stat_table_font_size,
        ]

    def _office_adjacent_font_size(self, current: int, direction: int, minimum: int, maximum: int) -> int:
        if direction > 0:
            candidates = [size for size in OFFICE_FONT_SIZE_STEPS if size > current]
            target = candidates[0] if candidates else maximum
        else:
            candidates = [size for size in OFFICE_FONT_SIZE_STEPS if size < current]
            target = candidates[-1] if candidates else minimum
        return min(max(target, minimum), maximum)

    def adjust_all_font_sizes(self, direction: int) -> None:
        controls = self._font_size_controls()
        changed = False
        for control in controls:
            target = self._office_adjacent_font_size(control.value(), direction, control.minimum(), control.maximum())
            if target != control.value():
                changed = True
            control.blockSignals(True)
            control.setValue(target)
            control.blockSignals(False)
        if changed:
            self.update_settings()

    def _polish_combo_box(self, combo: QComboBox) -> None:
        combo.setFixedHeight(APP_CONTROL_HEIGHT)
        combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        if combo.count() == 0:
            return
        max_text_width = max(combo.fontMetrics().horizontalAdvance(combo.itemText(index)) for index in range(combo.count()))
        max_text_length = max(len(combo.itemText(index)) for index in range(combo.count()))
        minimum_width = min(max(max_text_width + COMBO_TEXT_WIDTH_PADDING, COMBO_MIN_WIDTH), 280)
        combo.setMinimumContentsLength(min(max(max_text_length + 2, 10), 36))
        combo.setFixedWidth(minimum_width)
        combo.view().setMinimumWidth(minimum_width)

    def _polish_template_combo_box(self) -> None:
        self.template_combo.setFixedHeight(APP_CONTROL_HEIGHT)
        self.template_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.template_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        if self.template_combo.count() == 0:
            return
        max_text_width = max(self.template_combo.fontMetrics().horizontalAdvance(self.template_combo.itemText(index)) for index in range(self.template_combo.count()))
        max_text_length = max(len(self.template_combo.itemText(index)) for index in range(self.template_combo.count()))
        minimum_width = min(max(max_text_width + COMBO_TEXT_WIDTH_PADDING, COMBO_MIN_WIDTH), 280)
        self.template_combo.setMinimumContentsLength(min(max(max_text_length + 2, 10), 36))
        self.template_combo.setMinimumWidth(COMBO_MIN_WIDTH)
        self.template_combo.view().setMinimumWidth(minimum_width)

    def _polish_input_controls(self) -> None:
        self._polish_template_combo_box()
        for combo in self._combo_boxes():
            self._polish_combo_box(combo)
        for spin_box in self._spin_boxes():
            spin_box.setKeyboardTracking(False)
            spin_box.setFixedHeight(APP_CONTROL_HEIGHT)
            spin_box.setFixedWidth(COMBO_MIN_WIDTH)
        for button in self._buttons():
            button.setFixedHeight(APP_CONTROL_HEIGHT)
        self.custom_overlay_count.hide()
        self.ui.customOverlayCountLabel.setText(self.tr("Overlay filter"))
        if hasattr(self.ui.lineOverlayForm, "setRowVisible"):
            self.ui.lineOverlayForm.setRowVisible(self.ui.showLineOverlayLabel, False)
        else:
            self.ui.showLineOverlayLabel.hide()
            self.show_line_overlay.hide()
        self.ui.extraCustomOverlayLabel.setText(self.tr("Show custom overlays"))

    def _connect_generated_ui(self) -> None:
        self._build_edit_menu()
        self._build_language_menu()
        self._configure_file_action_shortcuts()
        self.ui.actionNew.triggered.connect(self.new_project)
        self.ui.actionOpenProject.triggered.connect(self.open_project)
        self.ui.actionSaveProject.triggered.connect(self.save_project)
        self.ui.actionSaveProjectAs.triggered.connect(self.save_project_as)
        self.ui.actionImportExcel.triggered.connect(self.import_excel)
        self.ui.actionExportExcel.triggered.connect(self.export_excel)
        self.ui.actionCopyFigure.triggered.connect(self.copy_figure_image)
        self.ui.actionExportFigure.triggered.connect(self.export_figure)
        self.ui.addRowButton.clicked.connect(self.add_row)
        self.add_overlay_button.clicked.connect(self.add_custom_overlay_row)
        self.remove_overlay_button.clicked.connect(self.remove_custom_overlay_row)
        self.ui.addColumnButton.clicked.connect(self.add_column)
        self.ui.renameColumnButton.clicked.connect(self.rename_column)
        self.ui.deleteColumnButton.clicked.connect(self.delete_column)
        self.ui.copyImageButton.clicked.connect(self.copy_figure_image)
        self.ui.editGroupOrderButton.clicked.connect(self.edit_group_order)
        self.group_filter_button.clicked.connect(self.edit_group_filter)
        self.custom_overlay_filter_button.clicked.connect(self.edit_custom_overlay_filter)
        self.edit_group_colors_button.clicked.connect(self.edit_group_colors)
        self.template_combo.currentTextChanged.connect(self.apply_selected_template)
        self.ui.loadTemplateButton.clicked.connect(self.load_external_template)
        self.ui.saveTemplateButton.clicked.connect(self.save_current_template)
        QShortcut(QKeySequence.Copy, self.table, activated=self.copy_table_selection)
        QShortcut(QKeySequence.Paste, self.table, activated=self.paste_table_selection)
        QShortcut(QKeySequence.Delete, self.table, activated=self.clear_table_selection)
        QShortcut(QKeySequence.Undo, self.table, activated=self.undo_table_change)
        QShortcut(QKeySequence.Redo, self.table, activated=self.redo_table_change)
        self.table.installEventFilter(self)
        self.table.viewport().installEventFilter(self)
        QApplication.instance().installEventFilter(self)
        self._connect_table()

        for widget in [
            self.chart_type,
            self.group_order,
            self.legend_columns,
            self.jitter_mode,
            self.line_overlay_stat,
            self.line_overlay_style,
            self.line_value_position,
            self.custom_line_value_position,
            self.outlier_method,
            self.outlier_effect,
            self.box_whisker_mode,
        ]:
            widget.currentTextChanged.connect(self.update_settings)
        self.preset.currentTextChanged.connect(self.handle_preset_changed)
        for widget in [self.title, self.x_label, self.y_label]:
            widget.textChanged.connect(self.update_settings)
        self.secondary_y_label.textChanged.connect(self.update_settings)
        self.decrease_all_fonts_button.clicked.connect(lambda: self.adjust_all_font_sizes(-1))
        self.increase_all_fonts_button.clicked.connect(lambda: self.adjust_all_font_sizes(1))
        for widget in [
            self.width,
            self.height,
            self.dpi,
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.legend_font_size,
            self.legend_width,
            self.line_value_font_size,
            self.stat_table_font_size,
            self.custom_overlay_count,
            self.line_overlay_width,
            self.line_overlay_point_size,
            self.axis_line_width,
            self.x_tick_rotation,
            self.y_min,
            self.y_max,
            self.primary_tick_interval,
            self.secondary_y_min,
            self.secondary_y_max,
            self.secondary_tick_interval,
            self.secondary_axis_split_ratio,
            self.point_size,
            self.point_alpha,
            self.jitter,
            self.line_value_decimals,
            self.outlier_threshold,
            self.box_width,
            self.violin_width,
            self.kde_bandwidth,
            self.ridge_overlap,
            self.fill_alpha,
        ]:
            widget.valueChanged.connect(self.update_settings)
        for widget in [
            self.transparent_background,
            self.show_grid,
            self.auto_y_range,
            self.primary_auto_tick_interval,
            self.secondary_auto_y_range,
            self.secondary_auto_tick_interval,
            self.split_secondary_axis,
            self.show_legend,
            self.show_points,
            self.show_line_overlay,
            self.extra_custom_overlay,
            self.custom_overlay_secondary_axis,
            self.show_line_values,
            self.line_value_scientific,
            self.show_stat_table,
            self.show_stat_header,
            self.show_outliers,
        ]:
            widget.stateChanged.connect(self.update_settings)
        self.stat_table_options.itemChanged.connect(self.update_settings)

    def _configure_file_action_shortcuts(self) -> None:
        self.ui.actionOpenProject.setShortcuts(QKeySequence.Open)
        self.ui.actionSaveProject.setShortcuts(QKeySequence.Save)
        self.ui.actionSaveProjectAs.setShortcuts(QKeySequence.SaveAs)
        self.ui.actionCopyFigure.setShortcut(QKeySequence("Ctrl+Shift+C"))

    def _build_language_menu(self) -> None:
        self.language_menu = self.ui.menubar.addMenu(self.tr("Language"))
        self.language_actions: dict[str, QAction] = {}
        current_language = stored_language_preference()
        for language, label in [
            ("system", self.tr("System")),
            ("en", "English"),
            ("zh_CN", self.tr("Simplified Chinese")),
        ]:
            action = QAction(label, self)
            action.setCheckable(True)
            action.setChecked(current_language == language)
            action.triggered.connect(lambda _checked=False, *, code=language: self.change_language_preference(code))
            self.language_menu.addAction(action)
            self.language_actions[language] = action

    def _build_edit_menu(self) -> None:
        self.edit_menu = self.ui.menubar.addMenu(self.tr("Edit"))
        self.undo_table_action = QAction(self.tr("Undo Table Change"), self)
        self.undo_table_action.setShortcuts(QKeySequence.Undo)
        self.undo_table_action.triggered.connect(self.undo_table_change)
        self.edit_menu.addAction(self.undo_table_action)
        self.redo_table_action = QAction(self.tr("Redo Table Change"), self)
        self.redo_table_action.setShortcuts(QKeySequence.Redo)
        self.redo_table_action.triggered.connect(self.redo_table_change)
        self.edit_menu.addAction(self.redo_table_action)
        self.update_table_history_actions()

    def change_language_preference(self, language: str) -> None:
        language = normalize_language_code(language)
        if stored_language_preference() == language:
            self.language_actions[language].setChecked(True)
            return
        save_language_preference(language)
        for code, action in self.language_actions.items():
            action.setChecked(code == language)
        QMessageBox.information(
            self,
            self.tr("Language changed"),
            self.tr("Restart EasyGraph to apply the language change."),
        )

    def eventFilter(self, watched, event) -> bool:
        table_editor_event = isinstance(watched, QLineEdit) and self.table.isAncestorOf(watched)
        if event.type() == QEvent.KeyPress and (self._table_or_child_has_focus() or table_editor_event):
            if self.handle_table_editor_navigation(event, watched):
                return True
            if event.matches(QKeySequence.Undo):
                self.undo_table_change()
                return True
            if event.matches(QKeySequence.Redo):
                self.redo_table_change()
                return True
            if event.matches(QKeySequence.Copy):
                self.copy_table_selection()
                return True
            if event.matches(QKeySequence.Paste):
                self.paste_table_selection()
                return True
            if event.matches(QKeySequence.Delete):
                self.clear_table_selection()
                return True
        return super().eventFilter(watched, event)

    def _table_or_child_has_focus(self) -> bool:
        focus = QApplication.focusWidget()
        return focus is self.table or self.table.isAncestorOf(focus)

    def handle_table_editor_navigation(self, event: QKeyEvent, editor: QWidget | None = None) -> bool:
        if not isinstance(editor, QLineEdit) or not self.table.isAncestorOf(editor):
            editor = QApplication.focusWidget()
        if not isinstance(editor, QLineEdit) or not self.table.isAncestorOf(editor):
            return False
        modifiers = event.modifiers() & ~Qt.KeypadModifier
        if modifiers != Qt.NoModifier:
            return False

        moves = {
            Qt.Key_Left: (0, -1),
            Qt.Key_Right: (0, 1),
            Qt.Key_Up: (-1, 0),
            Qt.Key_Down: (1, 0),
            Qt.Key_Return: (1, 0),
            Qt.Key_Enter: (1, 0),
        }
        move = moves.get(event.key())
        if move is None:
            return False

        row = self.table.currentRow()
        col = self.table.currentColumn()
        next_row = row + move[0]
        next_col = col + move[1]
        if not (0 <= next_row < self.table.rowCount() and 0 <= next_col < self.table.columnCount()):
            return False

        item = self.table.item(row, col)
        if item is None:
            item = QTableWidgetItem("")
            self.table.setItem(row, col, item)
        before = self.table_snapshot()
        self._table_history_suspended = True
        try:
            item.setText(editor.text())
        finally:
            self._table_history_suspended = False

        self.table.setCurrentCell(next_row, next_col)
        next_item = self.table.item(next_row, next_col)
        if next_item is None:
            next_item = QTableWidgetItem("")
            self.table.setItem(next_row, next_col, next_item)
        QTimer.singleShot(0, lambda item=next_item: self.table.editItem(item))
        self.record_table_history_change(before)
        return True

    def table_snapshot(self) -> dict:
        return {
            "cells": [
                [
                    self.table.item(row, col).text() if self.table.item(row, col) else ""
                    for col in range(self.table.columnCount())
                ]
                for row in range(self.table.rowCount())
            ],
            "current_row": self.table.currentRow(),
            "current_col": self.table.currentColumn(),
            "custom_overlay_rows": self._custom_overlay_rows,
            "custom_overlay_series": deepcopy(self.settings.custom_overlay_series),
            "custom_overlay_count": self.settings.custom_overlay_count,
            "extra_custom_overlay": self.settings.extra_custom_overlay,
            "custom_overlay_hidden": list(self.settings.custom_overlay_hidden),
            "manual_group_order": list(self.settings.manual_group_order),
            "group_hidden": list(self.settings.group_hidden),
        }

    def restore_table_snapshot(self, snapshot: dict) -> None:
        cells = snapshot.get("cells", [])
        row_count = len(cells)
        col_count = max((len(row) for row in cells), default=0)
        self._table_history_restoring = True
        was_blocked = self.table.signalsBlocked()
        self.table.blockSignals(True)
        try:
            self._custom_overlay_rows = int(snapshot.get("custom_overlay_rows", 0))
            self.settings.custom_overlay_series = deepcopy(snapshot.get("custom_overlay_series", []))
            self.settings.custom_overlay_count = int(snapshot.get("custom_overlay_count", max(1, len(self.settings.custom_overlay_series))))
            self.settings.extra_custom_overlay = bool(snapshot.get("extra_custom_overlay", bool(self.settings.custom_overlay_series)))
            self.settings.custom_overlay_hidden = list(snapshot.get("custom_overlay_hidden", []))
            self.settings.manual_group_order = list(snapshot.get("manual_group_order", []))
            self.settings.group_hidden = list(snapshot.get("group_hidden", []))
            self.table.setRowCount(row_count)
            self.table.setColumnCount(col_count)
            for row in range(row_count):
                for col in range(col_count):
                    value = cells[row][col] if col < len(cells[row]) else ""
                    self.table.setItem(row, col, QTableWidgetItem(value))
            row = min(max(int(snapshot.get("current_row", 0)), 0), max(row_count - 1, 0))
            col = min(max(int(snapshot.get("current_col", 0)), 0), max(col_count - 1, 0))
            if row_count and col_count:
                self.table.setCurrentCell(row, col)
            self.update_column_headers()
            self.style_table_rows()
            self.update_table_header_height()
            self.update_row_headers()
            self.sync_manual_group_order()
        finally:
            self.table.blockSignals(was_blocked)
            self._table_history_restoring = False
        self._sync_custom_overlay_visibility()
        self._sync_custom_overlay_visibility_to_controls()
        self.render()

    def reset_table_history(self) -> None:
        self._table_undo_stack = []
        self._table_redo_stack = []
        self._last_table_snapshot = self.table_snapshot()
        self.update_table_history_actions()

    def record_table_history_change(self, before: dict | None = None) -> None:
        if self._table_history_restoring or self._table_history_suspended:
            return
        before = before if before is not None else self._last_table_snapshot
        after = self.table_snapshot()
        if before is not None and before != after:
            self._table_undo_stack.append(deepcopy(before))
            self._table_undo_stack = self._table_undo_stack[-100:]
            self._table_redo_stack = []
            self._last_table_snapshot = deepcopy(after)
        else:
            self._last_table_snapshot = deepcopy(after)
        self.update_table_history_actions()

    def update_table_history_actions(self) -> None:
        if hasattr(self, "undo_table_action"):
            self.undo_table_action.setEnabled(bool(self._table_undo_stack))
        if hasattr(self, "redo_table_action"):
            self.redo_table_action.setEnabled(bool(self._table_redo_stack))

    def undo_table_change(self) -> None:
        if not self._table_undo_stack:
            return
        current = self.table_snapshot()
        snapshot = self._table_undo_stack.pop()
        self._table_redo_stack.append(deepcopy(current))
        self.restore_table_snapshot(snapshot)
        self._last_table_snapshot = self.table_snapshot()
        self.update_table_history_actions()

    def redo_table_change(self) -> None:
        if not self._table_redo_stack:
            return
        current = self.table_snapshot()
        snapshot = self._table_redo_stack.pop()
        self._table_undo_stack.append(deepcopy(current))
        self.restore_table_snapshot(snapshot)
        self._last_table_snapshot = self.table_snapshot()
        self.update_table_history_actions()

    def _sync_custom_overlay_visibility_to_controls(self) -> None:
        if not hasattr(self, "extra_custom_overlay"):
            return
        self.extra_custom_overlay.blockSignals(True)
        self.custom_overlay_count.blockSignals(True)
        try:
            self.extra_custom_overlay.setChecked(self.settings.extra_custom_overlay)
            self.custom_overlay_count.setValue(max(1, len(self.settings.custom_overlay_series), self.settings.custom_overlay_count))
        finally:
            self.custom_overlay_count.blockSignals(False)
            self.extra_custom_overlay.blockSignals(False)
        self._sync_custom_overlay_visibility()
        self._update_dependent_control_states()

    def set_table_dataframe(self, df: pd.DataFrame, overlay_series: list[dict] | None = None) -> None:
        overlay_series = overlay_series if overlay_series is not None else self.settings.custom_overlay_series
        overlay_series = list(overlay_series)
        self.table.blockSignals(True)
        try:
            self._custom_overlay_rows = len(overlay_series)
            self.table.setRowCount(len(df) + len(overlay_series) + 1)
            self.table.setColumnCount(len(df.columns))
            self.update_column_headers()
            for c, col in enumerate(df.columns):
                self.table.setItem(0, c, QTableWidgetItem(str(col)))
            self.update_table_header_height()
            for r, series in enumerate(overlay_series):
                values = series.get("values", {}) if isinstance(series, dict) else {}
                for c, col in enumerate(df.columns):
                    value = values.get(str(col), "") if isinstance(values, dict) else ""
                    self.table.setItem(r + 1, c, QTableWidgetItem("" if pd.isna(value) else str(value)))
            sample_start = self.sample_start_row()
            for r in range(len(df)):
                for c, col in enumerate(df.columns):
                    value = df.iloc[r, c]
                    text = "" if pd.isna(value) else str(value)
                    self.table.setItem(sample_start + r, c, QTableWidgetItem(text))
            self.style_table_rows()
            self.update_row_headers()
        finally:
            self.table.blockSignals(False)

    def table_dataframe(self) -> pd.DataFrame:
        headers = [
            self.group_name_at(c)
            for c in range(self.table.columnCount())
        ]
        data = []
        for r in range(self.sample_start_row(), self.table.rowCount()):
            row = []
            for c in range(self.table.columnCount()):
                item = self.table.item(r, c)
                row.append(item.text() if item else "")
            data.append(row)
        return pd.DataFrame(data, columns=headers)

    def custom_overlay_row_count(self) -> int:
        return self._custom_overlay_rows

    def sample_start_row(self) -> int:
        return 1 + self._custom_overlay_rows

    def custom_overlay_series_from_table(self) -> list[dict]:
        if self.custom_overlay_row_count() == 0:
            return list(self.settings.custom_overlay_series)
        groups = self.table_group_names()
        series = []
        for row in range(1, min(self.sample_start_row(), self.table.rowCount())):
            header = self.table.verticalHeaderItem(row)
            name = header.text().strip() if header and header.text().strip() else f"Overlay {row}"
            values = {}
            for col, group in enumerate(groups):
                item = self.table.item(row, col)
                values[str(group)] = item.text() if item else ""
            series.append({"name": name, "values": values})
        return series

    def sync_custom_overlay_rows(self, sample_df: pd.DataFrame | None = None, existing_series: list[dict] | None = None) -> None:
        target_count = len(self.settings.custom_overlay_series)
        if existing_series is not None:
            target_count = len(existing_series)
        if self.custom_overlay_row_count() == target_count:
            self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
            self.settings.custom_overlay_count = max(1, len(self.settings.custom_overlay_series))
            self._sync_custom_overlay_visibility()
            self.update_row_headers()
            self.style_table_rows()
            return
        df = sample_df if sample_df is not None else self.table_dataframe()
        existing = existing_series if existing_series is not None else self.custom_overlay_series_from_table()
        self.settings.custom_overlay_series = list(existing)
        self.settings.custom_overlay_count = max(1, len(self.settings.custom_overlay_series))
        self._sync_custom_overlay_visibility()
        self.set_table_dataframe(df, self.settings.custom_overlay_series)

    def _sync_custom_overlay_visibility(self) -> None:
        count = len(self.settings.custom_overlay_series)
        hidden = {
            int(index)
            for index in self.settings.custom_overlay_hidden
            if isinstance(index, int) or str(index).lstrip("-").isdigit()
        }
        self.settings.custom_overlay_hidden = sorted(index for index in hidden if 0 <= index < count)

    def update_row_headers(self) -> None:
        labels = [""]
        for row in range(1, self.sample_start_row()):
            series_index = row - 1
            name = "Overlay"
            if series_index < len(self.settings.custom_overlay_series):
                name = str(self.settings.custom_overlay_series[series_index].get("name", "")).strip()
            labels.append(name or f"Overlay {series_index + 1}")
        sample_count = max(0, self.table.rowCount() - self.sample_start_row())
        labels.extend(str(index + 1) for index in range(sample_count))
        self.table.setVerticalHeaderLabels(labels)
        self.table.verticalHeader().setMinimumWidth(86 if self.custom_overlay_row_count() else 34)

    def copy_table_selection(self) -> None:
        ranges = self.table.selectedRanges()
        if not ranges:
            return
        selected = ranges[0]
        rows = []
        for row in range(selected.topRow(), selected.bottomRow() + 1):
            values = []
            for col in range(selected.leftColumn(), selected.rightColumn() + 1):
                item = self.table.item(row, col)
                values.append(item.text() if item else "")
            rows.append(values)
        buffer = StringIO()
        writer = csv.writer(buffer, delimiter="\t", lineterminator="\n")
        writer.writerows(rows)
        QApplication.clipboard().setText(buffer.getvalue().rstrip("\n"))

    def paste_table_selection(self) -> None:
        text = QApplication.clipboard().text()
        if not text:
            return
        rows = list(csv.reader(StringIO(text), delimiter="\t"))
        if not rows:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True

        try:
            start_row = self.table.currentRow()
            start_col = self.table.currentColumn()
            if start_row < 0:
                start_row = 0
            if start_col < 0:
                start_col = 0

            needed_rows = start_row + len(rows)
            needed_cols = start_col + max(len(row) for row in rows)
            while self.table.rowCount() < needed_rows:
                self.table.insertRow(self.table.rowCount())
            while self.table.columnCount() < needed_cols:
                col = self.table.columnCount()
                self.table.insertColumn(col)
                self.table.setItem(0, col, QTableWidgetItem(f"Group {col + 1}"))
            self.update_column_headers()

            was_blocked = self.table.signalsBlocked()
            self.table.blockSignals(True)
            try:
                for r, row_values in enumerate(rows):
                    for c, value in enumerate(row_values):
                        self.table.setItem(start_row + r, start_col + c, QTableWidgetItem(value))
            finally:
                self.table.blockSignals(was_blocked)
            self.style_group_name_row()
            self.update_table_header_height()
            self.update_row_headers()
            self.sync_manual_group_order()
            self.render()
        finally:
            self._table_history_suspended = False
        self.record_table_history_change(before)

    def clear_table_selection(self) -> None:
        selected = self.table.selectedItems()
        if not selected:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True
        self.table.blockSignals(True)
        try:
            for item in selected:
                item.setText("")
        finally:
            self.table.blockSignals(False)
            self._table_history_suspended = False
        self.render()
        self.record_table_history_change(before)

    def update_table_header_height(self) -> None:
        max_lines = 1
        for col in range(self.table.columnCount()):
            item = self.table.item(0, col)
            if item is not None:
                max_lines = max(max_lines, item.text().count("\n") + 1)
        metrics = self.table.fontMetrics()
        height = metrics.lineSpacing() * max_lines + 14
        self.table.setRowHeight(0, height)

    def update_column_headers(self) -> None:
        self.table.setHorizontalHeaderLabels([str(col + 1) for col in range(self.table.columnCount())])

    def group_name_at(self, col: int) -> str:
        item = self.table.item(0, col)
        name = item.text().strip() if item else ""
        return name or f"Group {col + 1}"

    def style_group_name_row(self) -> None:
        self.style_table_rows()

    def style_table_rows(self) -> None:
        was_blocked = self.table.signalsBlocked()
        self.table.blockSignals(True)
        try:
            if self.table.rowCount() == 0:
                self.table.setRowCount(1)
            header_font = QFont(self.table.font())
            header_font.setBold(True)
            background = QBrush(QColor("#3E4A56"))
            foreground = QBrush(QColor("#F3F4F6"))
            for col in range(self.table.columnCount()):
                item = self.table.item(0, col)
                if item is None:
                    item = QTableWidgetItem(f"Group {col + 1}")
                    self.table.setItem(0, col, item)
                item.setFont(header_font)
                item.setBackground(background)
                item.setForeground(foreground)
                item.setTextAlignment(Qt.AlignCenter)
            overlay_font = QFont(self.table.font())
            overlay_font.setBold(True)
            palette = self.table.palette()
            base_color = palette.color(QPalette.ColorRole.Base)
            highlight_color = palette.color(QPalette.ColorRole.Highlight)
            text_color = palette.color(QPalette.ColorRole.Text)
            overlay_background = QBrush(blend_qcolors(base_color, highlight_color, 0.18))
            overlay_foreground = QBrush(text_color)
            sample_font = QFont(self.table.font())
            for row in range(1, self.table.rowCount()):
                is_overlay = row < self.sample_start_row()
                for col in range(self.table.columnCount()):
                    item = self.table.item(row, col)
                    if item is None:
                        item = QTableWidgetItem("")
                        self.table.setItem(row, col, item)
                    item.setFont(overlay_font if is_overlay else sample_font)
                    item.setBackground(overlay_background if is_overlay else QBrush())
                    item.setForeground(overlay_foreground if is_overlay else QBrush())
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        finally:
            self.table.blockSignals(was_blocked)

    def table_group_names(self) -> list[str]:
        return [
            self.group_name_at(col)
            for col in range(self.table.columnCount())
        ]

    def sync_manual_group_order(self) -> None:
        columns = self.table_group_names()
        existing = [group for group in self.settings.manual_group_order if group in columns]
        existing.extend(group for group in columns if group not in existing)
        self.settings.manual_group_order = existing
        self.settings.group_hidden = [
            group for group in self.settings.group_hidden if group in {str(column) for column in columns}
        ]

    def edit_group_order(self) -> None:
        self.sync_manual_group_order()
        dialog = QDialog(self)
        ui = Ui_GroupOrderDialog()
        ui.setupUi(dialog)

        def populate(groups: list[str]) -> None:
            ui.groupList.clear()
            for group in groups:
                ui.groupList.addItem(group)

        populate(self.settings.manual_group_order)
        ui.tableOrderButton.clicked.connect(lambda: populate(self.table_group_names()))
        if dialog.exec() == QDialog.Accepted:
            self.settings.manual_group_order = [
                ui.groupList.item(row).text() for row in range(ui.groupList.count())
            ]
            self.group_order.setCurrentText("Manual")
            self.render()

    def edit_group_filter(self) -> None:
        self.sync_manual_group_order()
        groups = [str(group) for group in self.table_group_names()]
        if not groups:
            QMessageBox.information(
                self,
                self.tr("Group Filter"),
                self.tr("Add a group first."),
            )
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(self.tr("Group Filter"))
        layout = QVBoxLayout(dialog)
        list_widget = QListWidget(dialog)
        hidden = hidden_group_names(self.settings)
        for group in groups:
            item = QListWidgetItem(group)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked if group in hidden else Qt.Checked)
            list_widget.addItem(item)
        layout.addWidget(list_widget)
        button_row = QHBoxLayout()
        button_row.addStretch()
        cancel_button = QPushButton(self.tr("Cancel"), dialog)
        ok_button = QPushButton(self.tr("OK"), dialog)
        button_row.addWidget(cancel_button)
        button_row.addWidget(ok_button)
        layout.addLayout(button_row)
        cancel_button.clicked.connect(dialog.reject)
        ok_button.clicked.connect(dialog.accept)
        if dialog.exec() != QDialog.Accepted:
            return
        self.settings.group_hidden = [
            list_widget.item(index).text()
            for index in range(list_widget.count())
            if list_widget.item(index).checkState() != Qt.Checked
        ]
        self.render()

    def edit_group_colors(self) -> None:
        groups = unique_groups(self.table_group_names())
        if not groups:
            return
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        overlay_items = overlay_color_items(self.table.dataframe(), self.settings)
        color_items = [
            {"key": str(group), "label": str(group), "palette_index": index, "kind": "group"}
            for index, group in enumerate(groups)
        ]
        color_items.extend(
            {
                "key": key,
                "label": self.tr("Overlay: {name}").format(name=name),
                "palette_index": len(groups) + overlay_palette_slot_for_color_key(self.settings, key, index),
                "kind": "overlay",
            }
            for index, (key, name) in enumerate(overlay_items)
        )

        original_preset = self.settings.preset
        original_custom_colors = dict(self.settings.custom_colors)
        original_custom_overlay_palette = self.settings.custom_overlay_palette
        original_custom_overlay_colors = dict(self.settings.custom_overlay_colors)
        selected_preset = self.settings.preset
        selected_overlay_preset = self.settings.custom_overlay_palette if self.settings.custom_overlay_palette in PRESETS else DEFAULT_OVERLAY_PALETTE
        selected_colors = dict(self.settings.custom_colors)
        selected_overlay_colors = dict(self.settings.custom_overlay_colors)
        valid_group_keys = {str(group) for group in groups}
        valid_overlay_keys = {key for key, _label in overlay_items}
        dialog = QDialog(self)
        dialog.setWindowTitle(self.tr("Edit Group Colors"))
        layout = QVBoxLayout(dialog)

        palette_row = QHBoxLayout()
        palette_row.addWidget(QLabel(self.tr("Palette")))
        palette_combo = QComboBox()
        palette_combo.addItems(list(PRESETS))
        palette_combo.setCurrentText(selected_preset)
        self._polish_combo_box(palette_combo)
        palette_row.addWidget(palette_combo)
        palette_row.addStretch()
        layout.addLayout(palette_row)

        overlay_palette_combo = None
        if overlay_items:
            overlay_palette_row = QHBoxLayout()
            overlay_palette_row.addWidget(QLabel(self.tr("Overlay palette")))
            overlay_palette_combo = QComboBox()
            overlay_palette_combo.addItems(list(PRESETS))
            overlay_palette_combo.setCurrentText(selected_overlay_preset)
            self._polish_combo_box(overlay_palette_combo)
            overlay_palette_row.addWidget(overlay_palette_combo)
            overlay_palette_row.addStretch()
            layout.addLayout(overlay_palette_row)

        palette_cache: dict[str, list[str]] = {}
        overlay_palette_cache: dict[tuple[str, int], list[str]] = {}

        def current_palette() -> list[str]:
            if selected_preset not in palette_cache:
                palette_cache[selected_preset] = palette_choices_for_group_count(selected_preset, len(groups))
            return palette_cache[selected_preset]

        def current_overlay_palette() -> list[str]:
            overlay_slots = [
                int(item["palette_index"]) - len(groups)
                for item in color_items
                if item["kind"] == "overlay"
            ]
            overlay_count = max(overlay_slots, default=0) + 1
            cache_key = (selected_overlay_preset, overlay_count)
            if cache_key not in overlay_palette_cache:
                overlay_palette_cache[cache_key] = palette_choices_for_group_count(selected_overlay_preset, overlay_count)
            return overlay_palette_cache[cache_key]

        def palette_for_item(item: dict) -> list[str]:
            return current_overlay_palette() if item["kind"] == "overlay" else current_palette()

        def color_for_item(item: dict) -> str:
            key = str(item["key"])
            selected = selected_overlay_colors if item["kind"] == "overlay" else selected_colors
            if item["kind"] == "overlay":
                color_map = overlay_color_map_for_keys(
                    all_overlay_color_keys(self.settings),
                    self.settings,
                    custom_overlay_colors=selected_overlay_colors,
                    overlay_preset=selected_overlay_preset,
                )
                if key in color_map:
                    return color_map[key]
                palette = palette_for_item(item)
                palette_index = int(item["palette_index"]) - len(groups)
                return selected.get(key, palette[palette_index % len(palette)])
            color_map = group_color_map_for_groups(
                groups,
                self.settings,
                custom_colors=selected_colors,
                preset_name=selected_preset,
            )
            if key in color_map:
                return color_map[key]
            palette = palette_for_item(item)
            palette_index = int(item["palette_index"])
            return selected.get(key, palette[palette_index % len(palette)])

        def style_swatch(button: QPushButton, color: str, selected: bool = False) -> None:
            border = "#111827" if selected else "#D1D5DB"
            button.setFixedSize(24, 24)
            button.setText("")
            button.setStyleSheet(f"QPushButton {{ background: {color}; border: 2px solid {border}; border-radius: 4px; }}")

        def sync_main_preset_combo(preset: str) -> None:
            self.preset.blockSignals(True)
            try:
                self.preset.setCurrentText(preset)
            finally:
                self.preset.blockSignals(False)

        def apply_preview() -> None:
            self.settings.preset = selected_preset
            self.settings.custom_colors = {
                group: color
                for group, color in selected_colors.items()
                if group in valid_group_keys
            }
            self.settings.custom_overlay_colors = dict(selected_overlay_colors)
            self.settings.custom_overlay_palette = selected_overlay_preset
            sync_main_preset_combo(selected_preset)
            self.render()

        swatches: dict[str, list[tuple[int, QPushButton]]] = {}
        current_buttons: dict[str, QPushButton] = {}
        rows_container = QWidget()
        rows_layout = QVBoxLayout(rows_container)
        rows_layout.setContentsMargins(0, 0, 0, 0)
        rows_layout.setSpacing(6)
        rows_scroll = QScrollArea()
        rows_scroll.setWidgetResizable(True)
        rows_scroll.setMinimumWidth(460)
        rows_scroll.setMinimumHeight(220)
        rows_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        rows_scroll.setWidget(rows_container)
        layout.addWidget(rows_scroll, 1)

        def refresh_item(item: dict, palette: list[str] | None = None) -> None:
            if palette is None:
                palette = palette_for_item(item)
            key = str(item["key"])
            active_color = color_for_item(item)
            for color_index, button in swatches[key]:
                color = palette[color_index % len(palette)]
                style_swatch(button, color, selected=active_color == color)
            current_buttons[key].setStyleSheet(
                f"QPushButton {{ background: {active_color}; border: 1px solid #6B7280; border-radius: 4px; }}"
            )

        def refresh_all_items() -> None:
            for item in color_items:
                refresh_item(item)

        for item in color_items:
            row = QHBoxLayout()
            name_label = QLabel(str(item["label"]))
            name_label.setMinimumWidth(120)
            row.addWidget(name_label)
            current_button = QPushButton()
            current_button.setEnabled(False)
            current_button.setFixedSize(34, 24)
            key = str(item["key"])
            current_buttons[key] = current_button
            row.addWidget(current_button)
            swatches[key] = []
            swatch_grid = QGridLayout()
            swatch_grid.setContentsMargins(0, 0, 0, 0)
            swatch_grid.setHorizontalSpacing(5)
            swatch_grid.setVerticalSpacing(5)

            for color_index, _color in enumerate(palette_for_item(item)):
                button = QPushButton()
                swatches[key].append((color_index, button))

                def choose_color(_checked=False, *, item_key=key, item_kind=str(item["kind"]), selected_index=color_index) -> None:
                    palette = current_overlay_palette() if item_kind == "overlay" else current_palette()
                    chosen = palette[selected_index % len(palette)]
                    if item_kind == "overlay":
                        selected_overlay_colors[item_key] = chosen
                    else:
                        selected_colors[item_key] = chosen
                    apply_preview()
                    refresh_all_items()

                button.clicked.connect(choose_color)
                swatch_grid.addWidget(button, color_index // 8, color_index % 8)

            row.addLayout(swatch_grid)

            reset_button = QPushButton(self.tr("Reset"))

            def reset_color(_checked=False, *, item_key=key, item_kind=str(item["kind"])) -> None:
                if item_kind == "overlay":
                    selected_overlay_colors.pop(item_key, None)
                else:
                    selected_colors.pop(item_key, None)
                apply_preview()
                refresh_all_items()

            reset_button.clicked.connect(reset_color)
            row.addWidget(reset_button)
            row.addStretch()
            rows_layout.addLayout(row)
            refresh_item(item)
        rows_layout.addStretch()

        def choose_palette(preset: str) -> None:
            nonlocal selected_preset
            if preset not in PRESETS:
                return
            selected_preset = preset
            selected_colors.clear()
            apply_preview()
            refresh_all_items()

        palette_combo.currentTextChanged.connect(choose_palette)

        def choose_overlay_palette(preset: str) -> None:
            nonlocal selected_overlay_preset
            if preset not in PRESETS:
                return
            selected_overlay_preset = preset
            selected_overlay_colors.clear()
            apply_preview()
            refresh_all_items()

        if overlay_palette_combo is not None:
            overlay_palette_combo.currentTextChanged.connect(choose_overlay_palette)

        button_row = QHBoxLayout()
        button_row.addStretch()
        cancel_button = QPushButton(self.tr("Cancel"))
        ok_button = QPushButton(self.tr("OK"))
        cancel_button.clicked.connect(dialog.reject)
        ok_button.clicked.connect(dialog.accept)
        button_row.addWidget(cancel_button)
        button_row.addWidget(ok_button)
        layout.addLayout(button_row)

        if dialog.exec() == QDialog.Accepted:
            apply_preview()
        else:
            self.settings.preset = original_preset
            self.settings.custom_colors = original_custom_colors
            self.settings.custom_overlay_palette = original_custom_overlay_palette
            self.settings.custom_overlay_colors = original_custom_overlay_colors
            sync_main_preset_combo(original_preset)
            self.render()

    def _build_menu(self) -> None:
        file_menu = self.menuBar().addMenu("File")
        actions = [
            ("New", self.new_project),
            ("Open Project", self.open_project),
            ("Save Project", self.save_project),
            ("Save Project As", self.save_project_as),
            ("Import Excel", self.import_excel),
            ("Export Excel", self.export_excel),
            ("Copy as Image", self.copy_figure_image),
            ("Export Figure", self.export_figure),
        ]
        for label, callback in actions:
            action = QAction(label, self)
            action.triggered.connect(callback)
            file_menu.addAction(action)

    def _build_layout(self) -> None:
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel("Data"))
        button_row = QHBoxLayout()
        add_row = QPushButton("+ Row")
        add_col = QPushButton("+ Column")
        rename_col = QPushButton("Rename Group")
        add_row.clicked.connect(lambda: self.table.insertRow(self.table.rowCount()))
        add_col.clicked.connect(self.add_column)
        rename_col.clicked.connect(self.rename_column)
        button_row.addWidget(add_row)
        button_row.addWidget(add_col)
        button_row.addWidget(rename_col)
        left_layout.addLayout(button_row)
        left_layout.addWidget(self.table)

        splitter = QSplitter(Qt.Horizontal)
        controls_scroll = QScrollArea()
        controls_scroll.setWidget(self.controls)
        controls_scroll.setWidgetResizable(True)
        controls_scroll.setMinimumWidth(300)
        splitter.addWidget(left)
        splitter.addWidget(self.canvas)
        splitter.addWidget(controls_scroll)
        splitter.setSizes([360, 620, 300])
        self.setCentralWidget(splitter)

    def _build_controls(self) -> None:
        layout = QVBoxLayout(self.controls)
        layout.addWidget(self._chart_group())
        layout.addWidget(self._font_group())
        layout.addWidget(self._axis_group())
        layout.addWidget(self._points_group())
        layout.addWidget(self._outlier_group())
        layout.addWidget(self._specific_group())
        layout.addStretch()

    def _chart_group(self) -> QGroupBox:
        group = QGroupBox("Chart")
        form = QFormLayout(group)
        self.chart_type = QComboBox()
        self.chart_type.addItems(["Box", "Violin", "Ridge"])
        self.preset = QComboBox()
        self.preset.addItems(list(PRESETS))
        self.title = QLineEdit(self.settings.title)
        self.x_label = QLineEdit(self.settings.x_label)
        self.y_label = QLineEdit(self.settings.y_label)
        self.width = spin(4, 40, self.settings.width, 0.5)
        self.height = spin(4, 30, self.settings.height, 0.5)
        self.dpi = spin_int(72, 1200, self.settings.dpi, 25)
        self.transparent_background = QCheckBox()
        self.transparent_background.setChecked(self.settings.transparent_background)
        copy_image_button = QPushButton("Copy as Image")
        copy_image_button.clicked.connect(self.copy_figure_image)

        for widget in [self.chart_type, self.preset]:
            widget.currentTextChanged.connect(self.update_settings)
        for widget in [self.title, self.x_label, self.y_label]:
            widget.textChanged.connect(self.update_settings)
        for widget in [self.width, self.height, self.dpi]:
            widget.valueChanged.connect(self.update_settings)
        self.transparent_background.stateChanged.connect(self.update_settings)

        form.addRow("Type", self.chart_type)
        form.addRow("Preset", self.preset)
        form.addRow("Title", self.title)
        form.addRow("X label", self.x_label)
        form.addRow("Y label", self.y_label)
        form.addRow("Plot area width (cm)", self.width)
        form.addRow("Plot area height (cm)", self.height)
        form.addRow("Export DPI", self.dpi)
        form.addRow("Transparent bg", self.transparent_background)
        form.addRow("", copy_image_button)
        return group

    def _font_group(self) -> QGroupBox:
        group = QGroupBox("Font")
        form = QFormLayout(group)
        self.title_font_size = spin_int(6, 60, self.settings.title_font_size, 1)
        self.axis_label_font_size = spin_int(6, 48, self.settings.axis_label_font_size, 1)
        self.tick_font_size = spin_int(5, 36, self.settings.tick_font_size, 1)
        for widget in [self.title_font_size, self.axis_label_font_size, self.tick_font_size]:
            widget.valueChanged.connect(self.update_settings)
        form.addRow("Title size", self.title_font_size)
        form.addRow("Axis label size", self.axis_label_font_size)
        form.addRow("Tick size", self.tick_font_size)
        return group

    def _axis_group(self) -> QGroupBox:
        group = QGroupBox("Axis")
        form = QFormLayout(group)
        self.show_grid = QCheckBox()
        self.show_grid.setChecked(self.settings.show_grid)
        self.auto_y_range = QCheckBox()
        self.auto_y_range.setChecked(self.settings.auto_y_range)
        self.axis_line_width = spin(0.2, 5.0, self.settings.axis_line_width, 0.1)
        self.x_tick_rotation = spin_int(0, 90, self.settings.x_tick_rotation, 5)
        self.y_min = spin(-1_000_000, 1_000_000, self.settings.y_min, 0.5)
        self.y_max = spin(-1_000_000, 1_000_000, self.settings.y_max, 0.5)
        for widget in [self.show_grid, self.auto_y_range]:
            widget.stateChanged.connect(self.update_settings)
        for widget in [self.axis_line_width, self.x_tick_rotation, self.y_min, self.y_max]:
            widget.valueChanged.connect(self.update_settings)
        form.addRow("Show grid", self.show_grid)
        form.addRow("Auto Y range", self.auto_y_range)
        form.addRow("Y min", self.y_min)
        form.addRow("Y max", self.y_max)
        form.addRow("Axis line width", self.axis_line_width)
        form.addRow("X label rotation", self.x_tick_rotation)
        return group

    def _points_group(self) -> QGroupBox:
        group = QGroupBox("Data Points")
        form = QFormLayout(group)
        self.show_points = QCheckBox()
        self.show_points.setChecked(self.settings.show_points)
        self.point_size = spin(1, 14, self.settings.point_size, 0.5)
        self.point_alpha = spin(0.1, 1.0, self.settings.point_alpha, 0.05)
        self.jitter_mode = QComboBox()
        self.jitter_mode.addItems(["Beeswarm", "Quasirandom", "Random"])
        self.jitter_mode.setCurrentText(self.settings.jitter_mode)
        self.jitter = spin(0, 0.6, self.settings.jitter, 0.02)
        for widget in [self.show_points, self.point_size, self.point_alpha, self.jitter]:
            signal = widget.stateChanged if isinstance(widget, QCheckBox) else widget.valueChanged
            signal.connect(self.update_settings)
        self.jitter_mode.currentTextChanged.connect(self.update_settings)
        form.addRow("Show all points", self.show_points)
        form.addRow("Point size", self.point_size)
        form.addRow("Point alpha", self.point_alpha)
        form.addRow("Jitter mode", self.jitter_mode)
        form.addRow("Jitter", self.jitter)
        return group

    def _outlier_group(self) -> QGroupBox:
        group = QGroupBox("Outliers")
        form = QFormLayout(group)
        self.show_outliers = QCheckBox()
        self.show_outliers.setChecked(self.settings.show_outliers)
        self.outlier_method = QComboBox()
        self.outlier_method.addItems(["IQR", "Z-score", "MAD", "Percentile"])
        self.outlier_threshold = spin(0.1, 10, self.settings.outlier_threshold, 0.1)
        self.outlier_effect = QComboBox()
        self.outlier_effect.addItems(["Mark only", "Exclude from distribution"])
        self.outlier_effect.setCurrentText(self.settings.outlier_effect)
        for widget in [self.show_outliers, self.outlier_method, self.outlier_threshold, self.outlier_effect]:
            signal = widget.stateChanged if isinstance(widget, QCheckBox) else widget.currentTextChanged if isinstance(widget, QComboBox) else widget.valueChanged
            signal.connect(self.update_settings)
        form.addRow("Highlight", self.show_outliers)
        form.addRow("Method", self.outlier_method)
        form.addRow("Threshold", self.outlier_threshold)
        form.addRow("Effect", self.outlier_effect)
        return group

    def _specific_group(self) -> QGroupBox:
        group = QGroupBox("Type-specific")
        form = QFormLayout(group)
        self.box_width = spin(0.2, 1.0, self.settings.box_width, 0.05)
        self.box_whisker_mode = QComboBox()
        self.box_whisker_mode.addItems(["Tukey 1.5 IQR", "Min-Max", "Percentile 5-95", "Percentile 10-90"])
        self.box_whisker_mode.setCurrentText(self.settings.box_whisker_mode)
        self.violin_width = spin(0.2, 1.0, self.settings.violin_width, 0.05)
        self.kde_bandwidth = spin(0.2, 3.0, self.settings.kde_bandwidth, 0.1)
        self.ridge_overlap = spin(0.2, 2.0, self.settings.ridge_overlap, 0.05)
        self.fill_alpha = spin(0.1, 1.0, self.settings.fill_alpha, 0.05)
        for widget in [self.box_width, self.violin_width, self.kde_bandwidth, self.ridge_overlap, self.fill_alpha]:
            widget.valueChanged.connect(self.update_settings)
        self.box_whisker_mode.currentTextChanged.connect(self.update_settings)
        form.addRow("Box width", self.box_width)
        form.addRow("Box whisker mode", self.box_whisker_mode)
        form.addRow("Violin width", self.violin_width)
        form.addRow("KDE bandwidth", self.kde_bandwidth)
        form.addRow("Ridge overlap", self.ridge_overlap)
        form.addRow("Fill alpha", self.fill_alpha)
        return group

    def _connect_table(self) -> None:
        self.table.itemChanged.connect(self.handle_table_item_changed)
        self.table.verticalHeader().sectionDoubleClicked.connect(self.rename_overlay_row)

    def refresh_template_combo(self, selected: str | None = None) -> None:
        current = selected or self.template_combo.currentText()
        self.template_combo.blockSignals(True)
        self.template_combo.clear()
        templates = list_style_templates()
        if templates:
            self.template_combo.addItems(templates)
            if current in templates:
                self.template_combo.setCurrentText(current)
        else:
            self.template_combo.addItem("No templates saved")
        self.template_combo.blockSignals(False)
        self._polish_template_combo_box()

    def apply_style_template(self, name: str, settings: ChartSettings) -> None:
        self.settings = settings
        self.sync_manual_group_order()
        self.apply_settings_to_controls()
        self.render()
        self.statusBar().showMessage(self.tr("Style template applied: {name}").format(name=name), 2500)

    def apply_selected_template(self, name: str) -> None:
        if not name or name == "No templates saved":
            return
        try:
            settings = read_style_template(name)
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template load failed"), str(exc))
            self.refresh_template_combo()
            return
        self.apply_style_template(name, settings)

    def handle_table_item_changed(self, item: QTableWidgetItem) -> None:
        if self._table_history_restoring:
            return
        if item.row() == 0:
            self.style_table_rows()
            self.update_table_header_height()
            self.sync_manual_group_order()
        if 0 < item.row() < self.sample_start_row():
            self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        self.render()
        self.record_table_history_change()

    def add_row(self) -> None:
        before = self.table_snapshot()
        self._table_history_suspended = True
        self.table.insertRow(self.table.rowCount())
        self.update_row_headers()
        self.style_table_rows()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def add_custom_overlay_row(self) -> None:
        before = self.table_snapshot()
        self._table_history_suspended = True
        self.settings.extra_custom_overlay = True
        self.extra_custom_overlay.setChecked(True)
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        self.settings.custom_overlay_series.append({"name": f"Overlay {len(self.settings.custom_overlay_series) + 1}", "values": {}})
        self.settings.custom_overlay_count = max(1, len(self.settings.custom_overlay_series))
        self.settings.extra_custom_overlay = True
        self._sync_custom_overlay_visibility()
        self.set_table_dataframe(self.table_dataframe(), self.settings.custom_overlay_series)
        row = self.sample_start_row() - 1
        if row > 0:
            self.table.setCurrentCell(row, 0)
        self._update_dependent_control_states()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def remove_custom_overlay_row(self) -> None:
        if self.custom_overlay_row_count() == 0:
            return
        row = self.table.currentRow()
        if not (0 < row < self.sample_start_row()):
            row = self.sample_start_row() - 1
        header = self.table.verticalHeaderItem(row)
        name = header.text() if header and header.text().strip() else f"Overlay {row}"
        answer = QMessageBox.warning(
            self,
            self.tr("Delete Overlay"),
            self.tr("Delete overlay '{name}'? Its values will be permanently lost.").format(name=name),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True
        sample_df = self.table_dataframe()
        series = self.custom_overlay_series_from_table()
        index = row - 1
        if 0 <= index < len(series):
            series.pop(index)
        hidden = []
        for hidden_index in self.settings.custom_overlay_hidden:
            if hidden_index == index:
                continue
            hidden.append(hidden_index - 1 if hidden_index > index else hidden_index)
        self.settings.custom_overlay_hidden = hidden
        self.settings.custom_overlay_series = series
        self.settings.custom_overlay_count = max(1, len(series))
        if not series:
            self.extra_custom_overlay.blockSignals(True)
            self.extra_custom_overlay.setChecked(False)
            self.extra_custom_overlay.blockSignals(False)
            self.settings.extra_custom_overlay = False
        self._sync_custom_overlay_visibility()
        self.set_table_dataframe(sample_df, self.settings.custom_overlay_series)
        self._update_dependent_control_states()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def edit_custom_overlay_filter(self) -> None:
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        if not self.settings.custom_overlay_series:
            QMessageBox.information(
                self,
                self.tr("Overlay Filter"),
                self.tr("Add an overlay row first."),
            )
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(self.tr("Overlay Filter"))
        layout = QVBoxLayout(dialog)
        list_widget = QListWidget(dialog)
        hidden = set(self.settings.custom_overlay_hidden)
        for index, series in enumerate(self.settings.custom_overlay_series):
            name = str(series.get("name", "")).strip() if isinstance(series, dict) else ""
            item = QListWidgetItem(name or f"Overlay {index + 1}")
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked if index in hidden else Qt.Checked)
            list_widget.addItem(item)
        layout.addWidget(list_widget)
        button_row = QHBoxLayout()
        button_row.addStretch()
        cancel_button = QPushButton(self.tr("Cancel"), dialog)
        ok_button = QPushButton(self.tr("OK"), dialog)
        button_row.addWidget(cancel_button)
        button_row.addWidget(ok_button)
        layout.addLayout(button_row)
        cancel_button.clicked.connect(dialog.reject)
        ok_button.clicked.connect(dialog.accept)
        if dialog.exec() != QDialog.Accepted:
            return
        self.settings.custom_overlay_hidden = [
            index
            for index in range(list_widget.count())
            if list_widget.item(index).checkState() != Qt.Checked
        ]
        self.extra_custom_overlay.setChecked(any(index not in self.settings.custom_overlay_hidden for index in range(list_widget.count())))
        self.settings.extra_custom_overlay = self.extra_custom_overlay.isChecked()
        self._sync_custom_overlay_visibility()
        self._update_dependent_control_states()
        self.render()

    def rename_overlay_row(self, row: int) -> None:
        if not (0 < row < self.sample_start_row()):
            return
        current = self.table.verticalHeaderItem(row).text() if self.table.verticalHeaderItem(row) else f"Overlay {row}"
        name, ok = QInputDialog.getMultiLineText(self, self.tr("Rename Overlay"), self.tr("Legend name"), text=current)
        if not ok:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True
        name = name.strip() or f"Overlay {row}"
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        index = row - 1
        while len(self.settings.custom_overlay_series) <= index:
            self.settings.custom_overlay_series.append({"name": f"Overlay {len(self.settings.custom_overlay_series) + 1}", "values": {}})
        self.settings.custom_overlay_series[index]["name"] = name
        self.update_row_headers()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def add_column(self) -> None:
        before = self.table_snapshot()
        self._table_history_suspended = True
        col = self.table.columnCount()
        self.table.insertColumn(col)
        self.table.setItem(0, col, QTableWidgetItem(f"Group {col + 1}"))
        self.update_column_headers()
        self.style_group_name_row()
        self.update_table_header_height()
        self.update_row_headers()
        self.sync_manual_group_order()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def delete_column(self) -> None:
        col = self.table.currentColumn()
        if col < 0:
            col = self.table.columnCount() - 1
        if col < 0:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True
        self.table.removeColumn(col)
        self.update_column_headers()
        self.update_table_header_height()
        self.update_row_headers()
        self.sync_manual_group_order()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def rename_column(self) -> None:
        col = self.table.currentColumn()
        if col < 0:
            col = max(0, self.table.columnCount() - 1)
        if col < 0:
            return
        current = self.group_name_at(col)
        name, ok = QInputDialog.getMultiLineText(self, self.tr("Rename Group"), self.tr("Group name"), text=current)
        if ok and name.strip():
            before = self.table_snapshot()
            self._table_history_suspended = True
            new_name = name.strip()
            self.settings.manual_group_order = [
                new_name if group == current else group for group in self.settings.manual_group_order
            ]
            self.table.setItem(0, col, QTableWidgetItem(new_name))
            self.style_group_name_row()
            self.update_table_header_height()
            self.sync_manual_group_order()
            self.render()
            self._table_history_suspended = False
            self.record_table_history_change(before)

    def update_settings(self, *_args) -> None:
        if self._applying_settings:
            return
        self._commit_pending_control_edits()
        sample_df = self.table_dataframe()
        existing_overlay_series = self.custom_overlay_series_from_table()
        self.settings.chart_type = self.chart_type.currentText()
        self.settings.preset = self.preset.currentText()
        self.settings.group_order = self.group_order.currentText()
        self.sync_manual_group_order()
        self.settings.title = self.title.toPlainText()
        self.settings.x_label = self.x_label.toPlainText()
        self.settings.y_label = self.y_label.toPlainText()
        self.settings.secondary_y_label = self.secondary_y_label.toPlainText()
        self.settings.show_points = self.show_points.isChecked()
        self.settings.point_size = self.point_size.value()
        self.settings.point_alpha = self.point_alpha.value()
        self.settings.jitter_mode = self.jitter_mode.currentText()
        self.settings.jitter = self.jitter.value()
        self.settings.line_overlay_stat = self.line_overlay_stat.currentText()
        self.settings.show_line_overlay = self.settings.line_overlay_stat != "None"
        self.settings.extra_custom_overlay = self.extra_custom_overlay.isChecked() and bool(existing_overlay_series)
        self.settings.custom_overlay_count = max(1, len(existing_overlay_series))
        if self.settings.extra_custom_overlay and len(self.settings.custom_overlay_hidden) >= len(existing_overlay_series):
            self.settings.custom_overlay_hidden = []
        custom_overlay_secondary_axis_enabled = self.settings.extra_custom_overlay
        if not custom_overlay_secondary_axis_enabled and self.custom_overlay_secondary_axis.isChecked():
            self.custom_overlay_secondary_axis.blockSignals(True)
            self.custom_overlay_secondary_axis.setChecked(False)
            self.custom_overlay_secondary_axis.blockSignals(False)
        self.settings.custom_overlay_secondary_axis = (
            self.custom_overlay_secondary_axis.isChecked() and custom_overlay_secondary_axis_enabled
        )
        self.sync_custom_overlay_rows(sample_df, existing_overlay_series)
        self.settings.line_overlay_width = self.line_overlay_width.value()
        self.settings.line_overlay_style = self.line_overlay_style.currentText()
        self.settings.line_overlay_point_size = self.line_overlay_point_size.value()
        self.settings.show_line_values = self.show_line_values.isChecked()
        self._refresh_line_value_position_options()
        self.settings.line_value_position = self.line_value_position.currentText()
        self.settings.custom_line_value_position = self.custom_line_value_position.currentText()
        self.settings.line_value_scientific = self.line_value_scientific.isChecked()
        self.settings.line_value_decimals = self.line_value_decimals.value()
        self.settings.line_value_font_size = self.line_value_font_size.value()
        self.settings.show_stat_table = self.show_stat_table.isChecked()
        for setting_name, _label in STAT_TABLE_OPTIONS:
            setattr(self.settings, setting_name, self._stat_table_option_checked(setting_name))
        self.settings.show_stat_header = self.show_stat_header.isChecked()
        self.settings.stat_table_font_size = self.stat_table_font_size.value()
        self.settings.show_outliers = self.show_outliers.isChecked()
        self.settings.outlier_method = self.outlier_method.currentText()
        self.settings.outlier_threshold = self.outlier_threshold.value()
        self.settings.outlier_effect = self.outlier_effect.currentText()
        self.settings.width = self.width.value()
        self.settings.height = self.height.value()
        self.settings.dpi = self.dpi.value()
        self.settings.title_font_size = self.title_font_size.value()
        self.settings.axis_label_font_size = self.axis_label_font_size.value()
        self.settings.tick_font_size = self.tick_font_size.value()
        self.settings.show_legend = self.show_legend.isChecked()
        self.settings.legend_font_size = self.legend_font_size.value()
        self.settings.legend_width = self.legend_width.value()
        self.settings.legend_columns = self._legend_columns_control_value()
        self.settings.axis_line_width = self.axis_line_width.value()
        self.settings.show_grid = self.show_grid.isChecked()
        self.settings.x_tick_rotation = self.x_tick_rotation.value()
        self.settings.auto_y_range = self.auto_y_range.isChecked()
        self.settings.y_min = self.y_min.value()
        self.settings.y_max = self.y_max.value()
        self.settings.primary_auto_tick_interval = self.primary_auto_tick_interval.isChecked()
        self.settings.primary_tick_interval = self.primary_tick_interval.value()
        self.settings.secondary_auto_y_range = self.secondary_auto_y_range.isChecked()
        self.settings.secondary_y_min = self.secondary_y_min.value()
        self.settings.secondary_y_max = self.secondary_y_max.value()
        self.settings.secondary_auto_tick_interval = self.secondary_auto_tick_interval.isChecked()
        self.settings.secondary_tick_interval = self.secondary_tick_interval.value()
        self.settings.split_secondary_axis = self.split_secondary_axis.isChecked()
        self.settings.secondary_axis_split_ratio = self.secondary_axis_split_ratio.value()
        self.settings.transparent_background = self.transparent_background.isChecked()
        self.settings.fill_alpha = self.fill_alpha.value()
        self.settings.box_width = self.box_width.value()
        self.settings.box_whisker_mode = self.box_whisker_mode.currentText()
        self.settings.violin_width = self.violin_width.value()
        self.settings.kde_bandwidth = self.kde_bandwidth.value()
        self.settings.ridge_overlap = self.ridge_overlap.value()
        self._update_dependent_control_states()
        if self.sender() in (self.title, self.x_label, self.y_label, self.secondary_y_label):
            self.schedule_render(RenderMode.TEXT_ONLY)
        else:
            self.render()

    def _commit_pending_control_edits(self) -> None:
        if self._committing_control_edits:
            return
        self._committing_control_edits = True
        try:
            for spin_box in self._spin_boxes():
                spin_box.interpretText()
        finally:
            self._committing_control_edits = False

    def handle_preset_changed(self, *_args) -> None:
        if not self._applying_settings:
            self.settings.custom_colors = {}
            self.settings.custom_overlay_colors = {}
        self.update_settings()

    def schedule_render(self, mode: RenderMode = RenderMode.FULL) -> None:
        if mode == RenderMode.FULL or not self._render_timer.isActive():
            self._scheduled_render_mode = mode
        self._render_pending = True
        self._render_timer.start()

    def flush_pending_render(self) -> None:
        if not self._render_pending:
            return
        if self._render_timer.isActive():
            self._render_timer.stop()
        mode = self._scheduled_render_mode
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        if mode == RenderMode.TEXT_ONLY and self._render_text_only():
            return
        self.render()

    def _render_text_only(self) -> bool:
        if self.canvas.figure is None or self.canvas.canvas is None or not self.canvas.figure.axes:
            return False
        last_settings = getattr(self.canvas, "_last_settings", None)
        if last_settings is None or self._text_layout_signature(last_settings) != self._text_layout_signature(self.settings):
            return False
        ax = self.canvas.figure.axes[0]
        preset = PRESETS.get(self.settings.preset)
        if preset is None:
            return False
        text_color = "#F9FAFB" if preset["background"] != "#FFFFFF" else "#222222"
        x_axis_label, y_axis_label = axis_labels_for_chart(self.settings)
        split_secondary_frame = self.canvas._split_secondary_frame_enabled(self.settings)
        ax.set_title("" if split_secondary_frame else self.settings.title, fontsize=self.settings.title_font_size, color=text_color)
        ax.set_xlabel(x_axis_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        ax.set_ylabel(y_axis_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        secondary_ax = self._secondary_axis_for_sync() if self.settings.custom_overlay_secondary_axis else None
        if secondary_ax is not None:
            if self.settings.chart_type == "Ridge":
                if split_secondary_frame:
                    secondary_ax.set_title(self.settings.title, fontsize=self.settings.title_font_size, color=text_color)
                secondary_ax.set_xlabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
            elif split_secondary_frame:
                secondary_ax.set_title(self.settings.title, fontsize=self.settings.title_font_size, color=text_color)
                secondary_ax.set_xlabel("", fontsize=self.settings.axis_label_font_size, color=text_color)
                secondary_ax.set_ylabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
            else:
                secondary_ax.set_ylabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        self.canvas.canvas.draw_idle()
        return True

    def _text_layout_signature(self, settings: ChartSettings) -> tuple[tuple[int, bool], tuple[int, bool], tuple[int, bool], tuple[int, bool]]:
        x_axis_label, y_axis_label = axis_labels_for_chart(settings)

        def footprint(text: str) -> tuple[int, bool]:
            return (self.canvas._line_count(text), bool(text))

        secondary_label = settings.secondary_y_label if settings.custom_overlay_secondary_axis else ""
        return (footprint(settings.title), footprint(x_axis_label), footprint(y_axis_label), footprint(secondary_label))

    def render(self) -> None:
        if self._render_timer.isActive():
            self._render_timer.stop()
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        self.canvas.render(self.table.dataframe(), self.settings)
        self._sync_auto_y_axis_controls()
        self._sync_auto_tick_interval_controls()

    def _update_dependent_control_states(self) -> None:
        ridge_numeric_axis = self.chart_type.currentText() == "Ridge"
        value_axis_name = "X" if ridge_numeric_axis else "Y"
        self.ui.autoYLabel.setText(self.tr(f"Auto Primary {value_axis_name} Range"))
        self.ui.yMinLabel.setText(self.tr(f"Primary {value_axis_name} min"))
        self.ui.yMaxLabel.setText(self.tr(f"Primary {value_axis_name} max"))
        self.primary_auto_tick_interval_label.setText(self.tr(f"Auto Primary {value_axis_name} Tick Interval"))
        self.primary_tick_interval_label.setText(self.tr(f"Primary {value_axis_name} tick interval"))
        self.secondary_auto_y_range_label.setText(self.tr(f"Auto Secondary {value_axis_name} Range"))
        self.secondary_y_min_label.setText(self.tr(f"Secondary {value_axis_name} min"))
        self.secondary_y_max_label.setText(self.tr(f"Secondary {value_axis_name} max"))
        self.secondary_auto_tick_interval_label.setText(self.tr(f"Auto Secondary {value_axis_name} Tick Interval"))
        self.secondary_tick_interval_label.setText(self.tr(f"Secondary {value_axis_name} tick interval"))

        auto_y_enabled = self.auto_y_range.isChecked()
        for widget in [self.ui.yMinLabel, self.y_min, self.ui.yMaxLabel, self.y_max]:
            widget.setEnabled(not auto_y_enabled)
        primary_auto_tick_enabled = self.primary_auto_tick_interval.isChecked()
        self.primary_tick_interval_label.setEnabled(not primary_auto_tick_enabled)
        self.primary_tick_interval.setEnabled(not primary_auto_tick_enabled)
        custom_overlay_axis_available = self.settings.extra_custom_overlay
        if not custom_overlay_axis_available and self.custom_overlay_secondary_axis.isChecked():
            self.custom_overlay_secondary_axis.blockSignals(True)
            self.custom_overlay_secondary_axis.setChecked(False)
            self.custom_overlay_secondary_axis.blockSignals(False)
            self.settings.custom_overlay_secondary_axis = False

        secondary_axis_enabled = self.custom_overlay_secondary_axis.isChecked() and custom_overlay_axis_available
        if hasattr(self.ui.chartForm, "setRowVisible"):
            self.ui.chartForm.setRowVisible(self.secondary_y_label_label, secondary_axis_enabled)
        else:
            self.secondary_y_label_label.setVisible(secondary_axis_enabled)
            self.secondary_y_label.setVisible(secondary_axis_enabled)
        secondary_auto_y_enabled = self.secondary_auto_y_range.isChecked()
        split_secondary_enabled = secondary_axis_enabled
        for widget in [
            self.secondary_auto_y_range_label,
            self.secondary_auto_y_range,
            self.secondary_y_min_label,
            self.secondary_y_min,
            self.secondary_y_max_label,
            self.secondary_y_max,
            self.secondary_auto_tick_interval_label,
            self.secondary_auto_tick_interval,
            self.secondary_tick_interval_label,
            self.secondary_tick_interval,
            self.split_secondary_axis_label,
            self.split_secondary_axis,
            self.secondary_axis_split_ratio_label,
            self.secondary_axis_split_ratio,
        ]:
            widget.setEnabled(secondary_axis_enabled)
        for widget in [self.secondary_y_min_label, self.secondary_y_min, self.secondary_y_max_label, self.secondary_y_max]:
            widget.setEnabled(secondary_axis_enabled and not secondary_auto_y_enabled)
        secondary_auto_tick_enabled = self.secondary_auto_tick_interval.isChecked()
        self.secondary_tick_interval_label.setEnabled(secondary_axis_enabled and not secondary_auto_tick_enabled)
        self.secondary_tick_interval.setEnabled(secondary_axis_enabled and not secondary_auto_tick_enabled)
        self.split_secondary_axis_label.setEnabled(split_secondary_enabled)
        self.split_secondary_axis.setEnabled(split_secondary_enabled)
        self.secondary_axis_split_ratio_label.setEnabled(split_secondary_enabled and self.split_secondary_axis.isChecked())
        self.secondary_axis_split_ratio.setEnabled(split_secondary_enabled and self.split_secondary_axis.isChecked())

        stat_overlay_enabled = self.line_overlay_stat.currentText() != "None"
        custom_overlay_enabled = self.extra_custom_overlay.isChecked()
        line_overlay_enabled = stat_overlay_enabled or custom_overlay_enabled
        line_value_font_enabled = line_overlay_enabled and self.show_line_values.isChecked()
        has_custom_overlay_rows = self.custom_overlay_row_count() > 0
        self.add_overlay_button.setEnabled(True)
        self.remove_overlay_button.setEnabled(has_custom_overlay_rows)
        self.custom_overlay_filter_button.setEnabled(has_custom_overlay_rows)
        self.ui.customOverlayCountLabel.setEnabled(has_custom_overlay_rows)
        self.custom_overlay_secondary_axis_label.setEnabled(custom_overlay_axis_available)
        self.custom_overlay_secondary_axis.setEnabled(custom_overlay_axis_available)
        for widget in [
            self.ui.lineOverlayWidthLabel,
            self.line_overlay_width,
            self.ui.lineOverlayStyleLabel,
            self.line_overlay_style,
            self.ui.lineOverlayPointSizeLabel,
            self.line_overlay_point_size,
            self.ui.showLineValuesLabel,
            self.show_line_values,
            self.ui.customLineValuePositionLabel,
            self.custom_line_value_position,
            self.ui.lineValueScientificLabel,
            self.line_value_scientific,
            self.ui.lineValueDecimalsLabel,
            self.line_value_decimals,
        ]:
            widget.setEnabled(line_overlay_enabled)
        self.ui.lineValueSizeLabel.setEnabled(line_value_font_enabled)
        self.line_value_font_size.setEnabled(line_value_font_enabled)
        self.ui.lineValuePositionLabel.setEnabled(stat_overlay_enabled)
        self.line_value_position.setEnabled(stat_overlay_enabled)
        self.ui.customLineValuePositionLabel.setEnabled(custom_overlay_enabled)
        self.custom_line_value_position.setEnabled(custom_overlay_enabled)
        legend_enabled = self.show_legend.isChecked()
        legend_font_label = self.ui.fontForm.labelForField(self.legend_font_size)
        if legend_font_label is not None:
            legend_font_label.setEnabled(legend_enabled)
        self.legend_font_size.setEnabled(legend_enabled)
        self.legend_width.setEnabled(legend_enabled)
        self.legend_columns.setEnabled(legend_enabled)
        stat_table_enabled = self.show_stat_table.isChecked()
        self.ui.statTableSizeLabel.setEnabled(stat_table_enabled)
        self.stat_table_font_size.setEnabled(stat_table_enabled)

    def _sync_auto_y_axis_controls(self) -> None:
        if not self.canvas.figure.axes:
            return
        ax = self.canvas.figure.axes[0]
        if self.settings.auto_y_range:
            y_min, y_max = ax.get_xlim() if self.settings.chart_type == "Ridge" else ax.get_ylim()
            if math.isfinite(y_min) and math.isfinite(y_max):
                self._sync_range_spin_boxes(self.y_min, self.y_max, y_min, y_max)
                self.settings.y_min = float(self.y_min.value())
                self.settings.y_max = float(self.y_max.value())
                if self.settings.chart_type == "Ridge":
                    ax.set_xlim(self.settings.y_min, self.settings.y_max)
                else:
                    ax.set_ylim(self.settings.y_min, self.settings.y_max)
        secondary_ax = self._secondary_axis_for_sync()
        if self.settings.custom_overlay_secondary_axis and self.settings.secondary_auto_y_range and secondary_ax is not None:
            y_min, y_max = secondary_ax.get_xlim() if self.settings.chart_type == "Ridge" else secondary_ax.get_ylim()
            if math.isfinite(y_min) and math.isfinite(y_max):
                self._sync_range_spin_boxes(self.secondary_y_min, self.secondary_y_max, y_min, y_max)
                self.settings.secondary_y_min = float(self.secondary_y_min.value())
                self.settings.secondary_y_max = float(self.secondary_y_max.value())
                if self.settings.chart_type == "Ridge":
                    secondary_ax.set_xlim(self.settings.secondary_y_min, self.settings.secondary_y_max)
                else:
                    secondary_ax.set_ylim(self.settings.secondary_y_min, self.settings.secondary_y_max)
        self.canvas.canvas.draw()

    def _sync_range_spin_boxes(self, min_spin: QDoubleSpinBox, max_spin: QDoubleSpinBox, min_value: float, max_value: float) -> None:
        for spin_box, value in [(min_spin, min_value), (max_spin, max_value)]:
            spin_box.blockSignals(True)
            try:
                spin_box.setValue(float(value))
            finally:
                spin_box.blockSignals(False)

    def _sync_auto_tick_interval_controls(self) -> None:
        if not self.canvas.figure.axes:
            return
        fallback_axes = getattr(self.canvas, "_auto_tick_interval_fallbacks", set())
        ax = self.canvas.figure.axes[0]
        if "primary" in fallback_axes:
            self._set_check_box_without_signal(self.primary_auto_tick_interval, True)
            self.settings.primary_auto_tick_interval = True
        if self.settings.primary_auto_tick_interval:
            self._sync_tick_interval_spin_box(self.primary_tick_interval, ax)
            self.settings.primary_tick_interval = float(self.primary_tick_interval.value())

        secondary_ax = self._secondary_axis_for_sync()
        if secondary_ax is not None:
            if "secondary" in fallback_axes:
                self._set_check_box_without_signal(self.secondary_auto_tick_interval, True)
                self.settings.secondary_auto_tick_interval = True
            if self.settings.custom_overlay_secondary_axis and self.settings.secondary_auto_tick_interval:
                self._sync_tick_interval_spin_box(self.secondary_tick_interval, secondary_ax)
                self.settings.secondary_tick_interval = float(self.secondary_tick_interval.value())
        if fallback_axes:
            self._update_dependent_control_states()

    def _sync_tick_interval_spin_box(self, spin_box: QDoubleSpinBox, ax) -> None:
        interval = self._auto_tick_interval_for_axis(ax)
        if interval is None:
            return
        spin_box.blockSignals(True)
        try:
            spin_box.setValue(interval)
        finally:
            spin_box.blockSignals(False)

    def _auto_tick_interval_for_axis(self, ax) -> float | None:
        ticks = ax.get_xticks() if self.settings.chart_type == "Ridge" else ax.get_yticks()
        finite_ticks = sorted(float(tick) for tick in ticks if math.isfinite(float(tick)))
        diffs = [
            finite_ticks[index + 1] - finite_ticks[index]
            for index in range(len(finite_ticks) - 1)
            if finite_ticks[index + 1] > finite_ticks[index]
        ]
        if not diffs:
            return None
        interval = float(np.median(diffs))
        return interval if math.isfinite(interval) and interval > 0 else None

    def _set_check_box_without_signal(self, check_box: QCheckBox, checked: bool) -> None:
        check_box.blockSignals(True)
        try:
            check_box.setChecked(checked)
        finally:
            check_box.blockSignals(False)

    def _secondary_axis_for_sync(self):
        for axis in self.canvas.figure.axes[1:]:
            if axis.get_gid() == "secondary-axis":
                return axis
            if self.settings.chart_type == "Ridge" and axis.xaxis.label.get_text() == self.settings.secondary_y_label:
                return axis
            if self.settings.chart_type != "Ridge" and axis.yaxis.label.get_text() == self.settings.secondary_y_label:
                return axis
        return None

    def new_project(self) -> None:
        self.current_project = None
        self.settings = self._settings_for_new_project()
        self.table.set_dataframe(blank_project_data())
        self.sync_manual_group_order()
        self.apply_settings_to_controls()
        self.reset_table_history()
        self.render()

    def _settings_for_new_project(self) -> ChartSettings:
        template_name = self.template_combo.currentText()
        if not template_name or template_name == "No templates saved":
            return ChartSettings()
        try:
            return read_style_template(template_name)
        except Exception as exc:
            QMessageBox.warning(self, self.tr("Template load failed"), str(exc))
            self.refresh_template_combo()
            return ChartSettings()

    def save_current_template(self) -> None:
        self.update_settings()
        name, ok = QInputDialog.getText(self, self.tr("Save Style Template"), self.tr("Template name"))
        if not ok:
            return
        try:
            path = write_style_template(name, self.settings)
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template save failed"), str(exc))
            return
        self.refresh_template_combo(path.stem)
        self.statusBar().showMessage(self.tr("Style template saved: {name}").format(name=path.stem), 2500)

    def load_external_template(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Load Style Template"), "", self.tr("Style Template (*.json);;All Files (*)"))
        if not path:
            return
        try:
            name, settings = import_style_template(Path(path))
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template load failed"), str(exc))
            self.refresh_template_combo()
            return
        self.refresh_template_combo(name)
        self.apply_style_template(name, settings)
        self.statusBar().showMessage(self.tr("Style template loaded: {name}").format(name=name), 2500)

    def save_project(self) -> None:
        if not self.current_project:
            self.save_project_as()
            return
        self.update_settings()
        write_project(self.current_project, self.table.dataframe(), self.settings)

    def save_project_as(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, self.tr("Save Project"), "", self.tr("EasyGraph Project (*.eg);;All Files (*)"))
        if path:
            self.current_project = Path(path if path.lower().endswith(".eg") else f"{path}.eg")
            self.save_project()

    def open_project(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Open Project"), "", self.tr("EasyGraph Project (*.eg);;All Files (*)"))
        if not path:
            return
        df, settings = read_project(Path(path))
        self.current_project = Path(path)
        self.settings = settings
        self.table.set_dataframe(df)
        self.apply_settings_to_controls()
        self.reset_table_history()
        self.render()
        self.canvas.zoom_to_fit()
        QTimer.singleShot(0, self.canvas.zoom_to_fit)

    def apply_settings_to_controls(self) -> None:
        self._applying_settings = True
        try:
            self.chart_type.setCurrentText(self.settings.chart_type)
            self.preset.setCurrentText(self.settings.preset)
            self.group_order.setCurrentText(self.settings.group_order)
            self.title.setPlainText(self.settings.title)
            self.x_label.setPlainText(self.settings.x_label)
            self.y_label.setPlainText(self.settings.y_label)
            self.secondary_y_label.setPlainText(self.settings.secondary_y_label)
            self.show_points.setChecked(self.settings.show_points)
            self.point_size.setValue(self.settings.point_size)
            self.point_alpha.setValue(self.settings.point_alpha)
            self.jitter_mode.setCurrentText(self.settings.jitter_mode)
            self.jitter.setValue(self.settings.jitter)
            self.show_line_overlay.setChecked(self.settings.line_overlay_stat != "None")
            self.line_overlay_stat.setCurrentText(self.settings.line_overlay_stat)
            self.extra_custom_overlay.setChecked(self.settings.extra_custom_overlay)
            self.custom_overlay_count.setValue(max(1, len(self.settings.custom_overlay_series), self.settings.custom_overlay_count))
            self.custom_overlay_secondary_axis.setChecked(self.settings.custom_overlay_secondary_axis)
            self.sync_custom_overlay_rows()
            self.line_overlay_width.setValue(self.settings.line_overlay_width)
            self.line_overlay_style.setCurrentText(self.settings.line_overlay_style)
            self.line_overlay_point_size.setValue(self.settings.line_overlay_point_size)
            self.show_line_values.setChecked(self.settings.show_line_values)
            self._refresh_line_value_position_options(self.settings.line_value_position)
            self.line_value_position.setCurrentText(self.settings.line_value_position)
            self.custom_line_value_position.setCurrentText(
                normalize_overlay_label_position(self.settings.custom_line_value_position, self.settings.chart_type, is_custom_overlay=True)
            )
            self.line_value_scientific.setChecked(self.settings.line_value_scientific)
            self.line_value_decimals.setValue(self.settings.line_value_decimals)
            self.line_value_font_size.setValue(self.settings.line_value_font_size)
            self.show_stat_table.setChecked(self.settings.show_stat_table)
            self._apply_stat_table_options_to_controls()
            self.show_stat_header.setChecked(self.settings.show_stat_header)
            self.stat_table_font_size.setValue(self.settings.stat_table_font_size)
            self.show_outliers.setChecked(self.settings.show_outliers)
            self.outlier_method.setCurrentText(self.settings.outlier_method)
            self.outlier_threshold.setValue(self.settings.outlier_threshold)
            self.outlier_effect.setCurrentText(self.settings.outlier_effect)
            self.width.setValue(self.settings.width)
            self.height.setValue(self.settings.height)
            self.dpi.setValue(self.settings.dpi)
            self.title_font_size.setValue(self.settings.title_font_size)
            self.axis_label_font_size.setValue(self.settings.axis_label_font_size)
            self.tick_font_size.setValue(self.settings.tick_font_size)
            self.show_legend.setChecked(self.settings.show_legend)
            self.legend_font_size.setValue(self.settings.legend_font_size)
            self.legend_width.setValue(self.settings.legend_width)
            self.legend_columns.setCurrentText(self.tr("Auto") if self.settings.legend_columns <= 0 else str(self.settings.legend_columns))
            self.axis_line_width.setValue(self.settings.axis_line_width)
            self.show_grid.setChecked(self.settings.show_grid)
            self.x_tick_rotation.setValue(self.settings.x_tick_rotation)
            self.auto_y_range.setChecked(self.settings.auto_y_range)
            self.y_min.setValue(self.settings.y_min)
            self.y_max.setValue(self.settings.y_max)
            self.primary_auto_tick_interval.setChecked(self.settings.primary_auto_tick_interval)
            self.primary_tick_interval.setValue(self.settings.primary_tick_interval)
            self.secondary_auto_y_range.setChecked(self.settings.secondary_auto_y_range)
            self.secondary_y_min.setValue(self.settings.secondary_y_min)
            self.secondary_y_max.setValue(self.settings.secondary_y_max)
            self.secondary_auto_tick_interval.setChecked(self.settings.secondary_auto_tick_interval)
            self.secondary_tick_interval.setValue(self.settings.secondary_tick_interval)
            self.split_secondary_axis.setChecked(self.settings.split_secondary_axis)
            self.secondary_axis_split_ratio.setValue(self.settings.secondary_axis_split_ratio)
            self.transparent_background.setChecked(self.settings.transparent_background)
            self.fill_alpha.setValue(self.settings.fill_alpha)
            self.box_width.setValue(self.settings.box_width)
            self.box_whisker_mode.setCurrentText(self.settings.box_whisker_mode)
            self.violin_width.setValue(self.settings.violin_width)
            self.kde_bandwidth.setValue(self.settings.kde_bandwidth)
            self.ridge_overlap.setValue(self.settings.ridge_overlap)
            self._update_dependent_control_states()
        finally:
            self._applying_settings = False

    def import_excel(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Import Excel"), "", self.tr("Excel Files (*.xlsx *.xls);;CSV Files (*.csv)"))
        if not path:
            return
        try:
            df = pd.read_csv(path) if path.lower().endswith(".csv") else pd.read_excel(path)
            self.table.set_dataframe(df)
            self.reset_table_history()
            self.render()
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Import failed"), str(exc))

    def export_excel(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, self.tr("Export Excel"), "", self.tr("Excel File (*.xlsx);;CSV File (*.csv)"))
        if not path:
            return
        df = self.table.dataframe()
        try:
            if path.lower().endswith(".csv"):
                df.to_csv(path, index=False)
            else:
                out = path if path.lower().endswith(".xlsx") else f"{path}.xlsx"
                df.to_excel(out, index=False)
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Export failed"), str(exc))

    def export_figure(self) -> None:
        filters = (
            "SVG Vector (*.svg);;"
            "PNG Image (*.png);;"
            "PDF Document (*.pdf);;"
            "TIFF Image (*.tif *.tiff);;"
            "JPEG Image (*.jpg *.jpeg)"
        )
        path, selected_filter = QFileDialog.getSaveFileName(
            self,
            self.tr("Export Figure"),
            "",
            filters,
            "SVG Vector (*.svg)",
        )
        if path:
            suffix = export_suffix_for_filter(selected_filter)
            if suffix and not Path(path).suffix:
                path = f"{path}{suffix}"
            self.flush_pending_render()
            self.canvas.export(path, self.settings)

    def copy_figure(self) -> None:
        self.copy_figure_image()

    def copy_figure_image(self) -> None:
        self.flush_pending_render()
        if self.canvas.copy_to_clipboard(self.settings):
            self.statusBar().showMessage(self.tr("Figure image copied to clipboard"), 2500)
        else:
            QMessageBox.warning(self, self.tr("Copy failed"), self.tr("Could not copy the figure to the clipboard."))


def spin(minimum: float, maximum: float, value: float, step: float) -> QDoubleSpinBox:
    widget = QDoubleSpinBox()
    widget.setKeyboardTracking(False)
    widget.setRange(minimum, maximum)
    widget.setValue(value)
    widget.setSingleStep(step)
    widget.setDecimals(2)
    return widget


def spin_int(minimum: int, maximum: int, value: int, step: int) -> QSpinBox:
    widget = QSpinBox()
    widget.setKeyboardTracking(False)
    widget.setRange(minimum, maximum)
    widget.setValue(value)
    widget.setSingleStep(step)
    return widget


def export_suffix_for_filter(selected_filter: str) -> str:
    if "*.svg" in selected_filter:
        return ".svg"
    if "*.png" in selected_filter:
        return ".png"
    if "*.pdf" in selected_filter:
        return ".pdf"
    if "*.tif" in selected_filter or "*.tiff" in selected_filter:
        return ".tif"
    if "*.jpg" in selected_filter or "*.jpeg" in selected_filter:
        return ".jpg"
    return ""


def prepare_plot_data(df: pd.DataFrame, settings: ChartSettings, include_hidden: bool = False) -> pd.DataFrame:
    rows = []
    for column in ordered_group_columns(df, settings):
        if not include_hidden and str(column) in hidden_group_names(settings):
            continue
        values = values_for_group(df, column)
        for value in values:
            rows.append({settings.group_col: str(column), settings.value_col: float(value)})
    return pd.DataFrame(rows, columns=[settings.group_col, settings.value_col])


def hidden_group_names(settings: ChartSettings) -> set[str]:
    return {str(group) for group in settings.group_hidden}


def unique_groups(columns) -> list:
    groups = []
    for column in columns:
        if column not in groups:
            groups.append(column)
    return groups


def values_for_group(df: pd.DataFrame, group) -> pd.Series:
    matching_indices = [idx for idx, column in enumerate(df.columns) if column == group]
    if not matching_indices:
        return pd.Series(dtype=float)
    parts = [
        pd.to_numeric(df.iloc[:, idx], errors="coerce").dropna()
        for idx in matching_indices
    ]
    return pd.concat(parts, ignore_index=True) if parts else pd.Series(dtype=float)


def ordered_group_columns(df: pd.DataFrame, settings: ChartSettings) -> list:
    columns = unique_groups(df.columns)
    if settings.group_order == "Manual":
        ordered = [group for group in settings.manual_group_order if group in columns]
        ordered.extend(group for group in columns if group not in ordered)
        return ordered
    if settings.group_order == "Name A-Z":
        return sorted(columns, key=lambda column: str(column).lower())
    if settings.group_order == "Name Z-A":
        return sorted(columns, key=lambda column: str(column).lower(), reverse=True)
    if settings.group_order in {
        "Mean ascending",
        "Mean descending",
        "Median ascending",
        "Median descending",
    }:
        use_median = settings.group_order.startswith("Median")
        descending = settings.group_order.endswith("descending")

        def sort_key(column):
            values = values_for_group(df, column)
            if values.empty:
                stat = math.inf if not descending else -math.inf
            else:
                stat = float(values.median() if use_median else values.mean())
            return (stat, str(column).lower())

        return sorted(columns, key=sort_key, reverse=descending)
    return columns


def palette_for(df: pd.DataFrame, settings: ChartSettings, color_groups: list | None = None) -> list[str]:
    groups = list(df[settings.group_col].dropna().unique()) if not df.empty else []
    color_map = group_color_map_for_groups(color_groups if color_groups is not None else groups, settings)
    colors = [color_map[str(group)] for group in groups if str(group) in color_map]
    return colors or expanded_preset_palette(settings.preset, max(len(groups), 1))


def group_color_map_for_groups(
    groups: list,
    settings: ChartSettings,
    custom_colors: dict[str, str] | None = None,
    preset_name: str | None = None,
) -> dict[str, str]:
    custom_colors = settings.custom_colors if custom_colors is None else custom_colors
    preset_name = settings.preset if preset_name is None else preset_name
    base = expanded_preset_palette(preset_name, len(groups) + len(custom_colors) + 4)
    group_keys = {str(item) for item in groups}
    used_colors = {
        normalize_color_name(color)
        for group, color in custom_colors.items()
        if str(group) in group_keys and QColor(color).isValid()
    }
    color_map = {}
    for group in groups:
        key = str(group)
        custom_color = custom_colors.get(key)
        if custom_color is not None and QColor(custom_color).isValid():
            color_map[key] = QColor(custom_color).name()
            continue
        color = first_unused_palette_color(base, used_colors)
        color_map[key] = color
        used_colors.add(normalize_color_name(color))
    return color_map


def normalize_color_name(color: str) -> str:
    qcolor = QColor(color)
    return qcolor.name() if qcolor.isValid() else str(color).lower()


def first_unused_palette_color(palette: list[str], used_colors: set[str]) -> str:
    for color in palette:
        normalized = normalize_color_name(color)
        if normalized not in used_colors:
            return normalized
    for color in palette:
        qcolor = QColor(color)
        if qcolor.isValid():
            return qcolor.name()
    return "#000000"


def palette_choices_for_group_count(preset_name: str, group_count: int) -> list[str]:
    max_core_count = max(len(preset["palette"]) for preset in PRESETS.values())
    target_count = max(max_core_count, group_count + 4)
    return expanded_preset_palette(preset_name, target_count)


def expanded_preset_palette(preset_name: str, count: int) -> list[str]:
    precomputed = _precomputed_palette_for(preset_name, count)
    if precomputed is not None:
        return list(precomputed)
    return list(_expanded_preset_palette_cached(preset_name, count))


def _precomputed_palette_for(preset_name: str, count: int) -> tuple[str, ...] | None:
    if count <= 0 or count > PRECOMPUTED_PALETTE_COUNT:
        return None
    colors = _precomputed_palette_cache().get(preset_name)
    if colors is None or len(colors) < count:
        return None
    preset = PRESETS.get(preset_name)
    if preset is None:
        return None
    base = tuple(QColor(color).name() for color in preset["palette"] if QColor(color).isValid())
    if colors[:len(base)] != base:
        return None
    return colors[:count]


@lru_cache(maxsize=1)
def _precomputed_palette_cache() -> dict[str, tuple[str, ...]]:
    try:
        raw_data = json.loads(PRECOMPUTED_PALETTE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    cache: dict[str, tuple[str, ...]] = {}
    if not isinstance(raw_data, dict):
        return cache
    for preset_name, colors in raw_data.items():
        if not isinstance(preset_name, str) or not isinstance(colors, list):
            continue
        normalized = tuple(
            QColor(color).name()
            for color in colors
            if isinstance(color, str) and QColor(color).isValid()
        )
        if normalized:
            cache[preset_name] = normalized
    return cache


@lru_cache(maxsize=256)
def _expanded_preset_palette_cached(preset_name: str, count: int) -> tuple[str, ...]:
    preset = PRESETS[preset_name]
    base = [QColor(color).name() for color in preset["palette"] if QColor(color).isValid()]
    if count <= 0:
        return tuple(base)
    if count <= len(base):
        return tuple(base[:count])
    if _palette_is_monochrome(base):
        return tuple(_expanded_monochrome_palette(base, count, preset["background"]))
    if preset_name in SEQUENTIAL_PALETTE_PRESETS:
        return tuple(_resampled_sequential_palette(base, count))

    colors = list(base)
    candidates = _style_matched_palette_candidates(base, preset["background"], count)
    _append_farthest_lab_colors(colors, candidates, count)

    attempts = 0
    while len(colors) < count:
        attempts += 1
        candidates = _style_matched_palette_candidates(base, preset["background"], count + attempts * 8)
        candidates = [color for color in candidates if color not in colors]
        if not candidates:
            break
        _append_farthest_lab_colors(colors, candidates, count)
    return tuple(colors[:count])


def _append_farthest_lab_colors(colors: list[str], candidates: list[str], count: int) -> None:
    if not candidates:
        return
    selected_labs = [_qcolor_to_lab(QColor(color)) for color in colors]
    candidate_labs = {color: _qcolor_to_lab(QColor(color)) for color in candidates}
    min_distances = {
        color: min(_lab_distance(candidate_labs[color], selected_lab) for selected_lab in selected_labs)
        for color in candidates
    }

    while len(colors) < count and candidates:
        selected = max(candidates, key=lambda color: min_distances[color])
        selected_lab = candidate_labs[selected]
        colors.append(selected)
        candidates.remove(selected)
        min_distances.pop(selected, None)
        for candidate in candidates:
            min_distances[candidate] = min(min_distances[candidate], _lab_distance(candidate_labs[candidate], selected_lab))


def _style_matched_palette_candidates(base: list[str], background: str, count: int) -> list[str]:
    lightness_values: list[float] = []
    saturation_values: list[float] = []
    hue_values: list[float] = []
    for color in base:
        hue, saturation, lightness, _alpha = QColor(color).getHslF()
        if hue >= 0:
            hue_values.append(hue)
        saturation_values.append(saturation)
        lightness_values.append(lightness)

    saturation = float(np.median(saturation_values)) if saturation_values else 0.62
    lightness = float(np.median(lightness_values)) if lightness_values else 0.48
    saturation_low = max(saturation - 0.08, 0.36)
    saturation_high = min(saturation + 0.08, 0.78)
    if background == "#FFFFFF":
        lightness_low = max(lightness - 0.08, 0.36)
        lightness_high = min(lightness + 0.08, 0.62)
    else:
        lightness_low = max(lightness - 0.08, 0.52)
        lightness_high = min(lightness + 0.08, 0.76)

    start_hue = float(np.median(hue_values)) if hue_values else 0.0
    golden_angle = 0.618033988749895
    candidate_count = max(240, min(500, count * 36))
    background_color = QColor(background)
    minimum_contrast = 1.45 if background == "#FFFFFF" else 2.0

    candidates: list[str] = []
    seen = set(base)
    attempts = 0
    while len(candidates) < candidate_count and attempts < candidate_count * 6:
        attempts += 1
        hue = (start_hue + attempts * golden_angle) % 1.0
        saturation_phase = ((attempts * 37) % 101) / 100
        lightness_phase = ((attempts * 53) % 101) / 100
        sat = saturation_low + (saturation_high - saturation_low) * saturation_phase
        light = lightness_low + (lightness_high - lightness_low) * lightness_phase
        candidate = QColor.fromHslF(hue, sat, light).name()
        if candidate in seen:
            continue
        if background_color.isValid() and _contrast_ratio(candidate, background) < minimum_contrast:
            continue
        seen.add(candidate)
        candidates.append(candidate)
    return candidates


def _resampled_sequential_palette(base: list[str], count: int) -> list[str]:
    if not base or count <= 0:
        return []
    if count == 1 or len(base) == 1:
        return [base[0]]

    qcolors = [QColor(color) for color in base]
    colors: list[str] = []
    for index in range(count):
        position = index * (len(qcolors) - 1) / (count - 1)
        lower = int(math.floor(position))
        upper = min(lower + 1, len(qcolors) - 1)
        fraction = position - lower
        red = round(qcolors[lower].red() * (1 - fraction) + qcolors[upper].red() * fraction)
        green = round(qcolors[lower].green() * (1 - fraction) + qcolors[upper].green() * fraction)
        blue = round(qcolors[lower].blue() * (1 - fraction) + qcolors[upper].blue() * fraction)
        candidate = QColor(red, green, blue).name()
        if candidate not in colors:
            colors.append(candidate)

    if len(colors) < count:
        return colors + [color for color in base if color not in colors][:count - len(colors)]
    return colors[:count]


def _palette_is_monochrome(colors: list[str]) -> bool:
    for color in colors:
        qcolor = QColor(color)
        if max(qcolor.red(), qcolor.green(), qcolor.blue()) - min(qcolor.red(), qcolor.green(), qcolor.blue()) > 2:
            return False
    return True


def _expanded_monochrome_palette(base: list[str], count: int, background: str) -> list[str]:
    colors = list(base)
    lower, upper = (18, 214) if background == "#FFFFFF" else (58, 248)
    candidate_values = list(range(lower, upper + 1))

    def gray_value(color: str) -> int:
        return QColor(color).red()

    while len(colors) < count and candidate_values:
        existing_values = [gray_value(color) for color in colors]
        selected = max(candidate_values, key=lambda value: min(abs(value - existing) for existing in existing_values))
        candidate_values.remove(selected)
        candidate = QColor(selected, selected, selected).name()
        if candidate not in colors:
            colors.append(candidate)
    return colors[:count]


def _minimum_lab_distance(color: str, existing_colors: list[str]) -> float:
    candidate = _qcolor_to_lab(QColor(color))
    distances = []
    for existing in existing_colors:
        current = _qcolor_to_lab(QColor(existing))
        distances.append(_lab_distance(candidate, current))
    return min(distances) if distances else math.inf


def _lab_distance(first: tuple[float, float, float], second: tuple[float, float, float]) -> float:
    return math.sqrt(
        (first[0] - second[0]) ** 2
        + (first[1] - second[1]) ** 2
        + (first[2] - second[2]) ** 2
    )


def _qcolor_to_lab(color: QColor) -> tuple[float, float, float]:
    def linearize(value: float) -> float:
        value = value / 255
        if value <= 0.04045:
            return value / 12.92
        return ((value + 0.055) / 1.055) ** 2.4

    red = linearize(color.red())
    green = linearize(color.green())
    blue = linearize(color.blue())
    x = red * 0.4124564 + green * 0.3575761 + blue * 0.1804375
    y = red * 0.2126729 + green * 0.7151522 + blue * 0.0721750
    z = red * 0.0193339 + green * 0.1191920 + blue * 0.9503041
    x /= 0.95047
    z /= 1.08883

    def pivot(value: float) -> float:
        if value > 0.008856:
            return value ** (1 / 3)
        return 7.787 * value + 16 / 116

    fx = pivot(x)
    fy = pivot(y)
    fz = pivot(z)
    return (
        116 * fy - 16,
        500 * (fx - fy),
        200 * (fy - fz),
    )


def _contrast_ratio(color: str, background: str) -> float:
    foreground_luminance = _relative_luminance(QColor(color))
    background_luminance = _relative_luminance(QColor(background))
    lighter = max(foreground_luminance, background_luminance)
    darker = min(foreground_luminance, background_luminance)
    return (lighter + 0.05) / (darker + 0.05)


def _relative_luminance(color: QColor) -> float:
    def channel(value: int) -> float:
        value = value / 255
        if value <= 0.03928:
            return value / 12.92
        return ((value + 0.055) / 1.055) ** 2.4

    return 0.2126 * channel(color.red()) + 0.7152 * channel(color.green()) + 0.0722 * channel(color.blue())


def blend_qcolors(base: QColor, overlay: QColor, amount: float) -> QColor:
    amount = max(0.0, min(float(amount), 1.0))
    inverse = 1.0 - amount
    return QColor(
        round(base.red() * inverse + overlay.red() * amount),
        round(base.green() * inverse + overlay.green() * amount),
        round(base.blue() * inverse + overlay.blue() * amount),
    )


def derived_group_color(color: str, role: str, background: str = "#FFFFFF") -> str:
    qcolor = QColor(color)
    if not qcolor.isValid():
        return color
    if role == "edge":
        return qcolor.darker(145).name()
    if role == "point":
        return qcolor.lighter(108 if background == "#FFFFFF" else 125).name()
    return qcolor.name()


def line_overlay_series(df: pd.DataFrame, settings: ChartSettings, include_hidden: bool = False) -> list[dict]:
    series = []
    stat_values = group_overlay_statistics(df, settings)
    if stat_values:
        series.append({
            "name": settings.line_overlay_stat,
            "kind": "stat",
            "color_key": overlay_stat_color_key(settings.line_overlay_stat),
            "groups": [group for group, _value in stat_values],
            "values": [value for _group, value in stat_values],
        })
    if settings.extra_custom_overlay and settings.custom_overlay_series and not df.empty:
        groups = [str(group) for group in df[settings.group_col].dropna().drop_duplicates()]
        overlay_indexes = all_custom_overlay_indexes(settings) if include_hidden else visible_custom_overlay_indexes(settings)
        for index in overlay_indexes:
            custom_series = settings.custom_overlay_series[index]
            if not isinstance(custom_series, dict):
                continue
            raw_values = custom_series.get("values", {})
            if not isinstance(raw_values, dict):
                continue
            values = []
            has_value = False
            for group in groups:
                value = pd.to_numeric(raw_values.get(str(group), ""), errors="coerce")
                if pd.isna(value):
                    values.append(float("nan"))
                else:
                    has_value = True
                    values.append(float(value))
            if has_value:
                name = str(custom_series.get("name", "")).strip() or f"Overlay {index + 1}"
                series.append({
                    "name": name,
                    "kind": "custom",
                    "secondary_axis": bool(settings.custom_overlay_secondary_axis),
                    "color_key": overlay_custom_color_key(index),
                    "groups": groups,
                    "values": values,
                })
    return series


def visible_custom_overlay_indexes(settings: ChartSettings) -> list[int]:
    if not settings.extra_custom_overlay:
        return []
    hidden = {
        int(index)
        for index in settings.custom_overlay_hidden
        if isinstance(index, int) or str(index).lstrip("-").isdigit()
    }
    return [
        index
        for index, series in enumerate(settings.custom_overlay_series or [])
        if index not in hidden and isinstance(series, dict)
    ]


def all_custom_overlay_indexes(settings: ChartSettings) -> list[int]:
    if not settings.extra_custom_overlay:
        return []
    return [
        index
        for index, series in enumerate(settings.custom_overlay_series or [])
        if isinstance(series, dict)
    ]


def overlay_palette_for(df: pd.DataFrame, settings: ChartSettings, count: int) -> list[str]:
    series = line_overlay_series(df, settings)
    color_map = overlay_color_map_for_series(line_overlay_series(df, settings, include_hidden=True), settings)
    colors = [
        stat_overlay_color(settings) if item.get("kind") == "stat" else color_map.get(str(item.get("color_key", "")), "#000000")
        for item in series[:count]
    ]
    return colors or expanded_preset_palette(DEFAULT_OVERLAY_PALETTE, max(count, 1))


def stat_overlay_color(settings: ChartSettings) -> str:
    background = PRESETS.get(settings.preset, PRESETS["Paper Clean"])["background"]
    return "#F9FAFB" if background != "#FFFFFF" else "#222222"


def default_overlay_color(settings: ChartSettings, series: dict, group_count: int, overlay_index: int) -> str:
    overlay_preset = settings.custom_overlay_palette if settings.custom_overlay_palette in PRESETS else DEFAULT_OVERLAY_PALETTE
    palette_slot = overlay_palette_slot_for_color_key(settings, str(series.get("color_key", "")), overlay_index)
    overlay_palette = expanded_preset_palette(overlay_preset, palette_slot + 1)
    return overlay_palette[palette_slot % len(overlay_palette)]


def overlay_color_map_for_series(
    series_list: list[dict],
    settings: ChartSettings,
    custom_overlay_colors: dict[str, str] | None = None,
    overlay_preset: str | None = None,
) -> dict[str, str]:
    return overlay_color_map_for_keys(
        [str(series.get("color_key", "")) for series in series_list],
        settings,
        custom_overlay_colors=custom_overlay_colors,
        overlay_preset=overlay_preset,
    )


def overlay_color_map_for_keys(
    color_keys: list[str],
    settings: ChartSettings,
    custom_overlay_colors: dict[str, str] | None = None,
    overlay_preset: str | None = None,
) -> dict[str, str]:
    custom_overlay_colors = settings.custom_overlay_colors if custom_overlay_colors is None else custom_overlay_colors
    overlay_preset = settings.custom_overlay_palette if overlay_preset is None else overlay_preset
    overlay_preset = overlay_preset if overlay_preset in PRESETS else DEFAULT_OVERLAY_PALETTE
    color_keys = [str(key) for key in color_keys if str(key) and not str(key).startswith("stat:")]
    palette = expanded_preset_palette(overlay_preset, len(color_keys) + len(custom_overlay_colors) + 4)
    series_keys = set(color_keys)
    used_colors = {
        normalize_color_name(color)
        for key, color in custom_overlay_colors.items()
        if str(key) in series_keys and QColor(color).isValid()
    }
    color_map = {}
    for key in color_keys:
        custom_color = custom_overlay_colors.get(key)
        if custom_color is not None and QColor(custom_color).isValid():
            color_map[key] = QColor(custom_color).name()
            continue
        color = first_unused_palette_color(palette, used_colors)
        color_map[key] = color
        used_colors.add(normalize_color_name(color))
    return color_map


def all_overlay_color_keys(settings: ChartSettings) -> list[str]:
    keys = []
    if settings.extra_custom_overlay:
        keys.extend(overlay_custom_color_key(index) for index in all_custom_overlay_indexes(settings))
    return keys


def overlay_palette_slot_for_color_key(settings: ChartSettings, color_key: str, fallback_index: int) -> int:
    if color_key.startswith("custom:"):
        try:
            custom_index = int(color_key.split(":", 1)[1])
        except ValueError:
            return fallback_index
        return max(0, custom_index)
    return max(0, fallback_index)


def overlay_color_items(df: pd.DataFrame, settings: ChartSettings) -> list[tuple[str, str]]:
    items = []
    if settings.extra_custom_overlay:
        series = settings.custom_overlay_series or []
        for index in visible_custom_overlay_indexes(settings):
            name = f"Overlay {index + 1}"
            if index < len(series) and isinstance(series[index], dict):
                name = str(series[index].get("name", "")).strip() or name
            items.append((overlay_custom_color_key(index), name))
    return items


def overlay_stat_color_key(stat: str) -> str:
    return f"stat:{stat}"


def overlay_custom_color_key(index: int) -> str:
    return f"custom:{index}"


def group_overlay_statistics(df: pd.DataFrame, settings: ChartSettings) -> list[tuple[str, float]]:
    if df.empty:
        return []
    if settings.line_overlay_stat == "None":
        return []
    use_mean = settings.line_overlay_stat == "Mean"
    stats = []
    for group in df[settings.group_col].dropna().drop_duplicates():
        values = pd.to_numeric(df.loc[df[settings.group_col] == group, settings.value_col], errors="coerce").dropna()
        if values.empty:
            continue
        value = values.mean() if use_mean else values.median()
        stats.append((str(group), float(value)))
    return stats


def stat_table_data(df: pd.DataFrame, settings: ChartSettings) -> tuple[list[str], list[tuple[str, list[str]]]]:
    if df.empty or not settings.show_stat_table:
        return ([], [])

    groups = [str(group) for group in df[settings.group_col].dropna().drop_duplicates()]
    if not groups:
        return ([], [])

    group_values = []
    for group in groups:
        values = pd.to_numeric(df.loc[df[settings.group_col].astype(str) == group, settings.value_col], errors="coerce").dropna()
        group_values.append(values)

    def formatted(values: pd.Series, calculation) -> str:
        if values.empty:
            return ""
        value = calculation(values)
        if pd.isna(value):
            return ""
        return format_overlay_value(float(value), settings)

    def sample_sd(values: pd.Series) -> float:
        return values.std(ddof=1) if len(values) > 1 else np.nan

    def sample_sem(values: pd.Series) -> float:
        if len(values) <= 1:
            return np.nan
        return values.std(ddof=1) / np.sqrt(len(values))

    row_specs = [
        ("Mean", settings.show_stat_mean, lambda values: values.mean()),
        ("Median", settings.show_stat_median, lambda values: values.median()),
        ("Q1", settings.show_stat_q1, lambda values: values.quantile(0.25)),
        ("Q3", settings.show_stat_q3, lambda values: values.quantile(0.75)),
        ("Max", settings.show_stat_max, lambda values: values.max()),
        ("Min", settings.show_stat_min, lambda values: values.min()),
        ("SD", settings.show_stat_sd, sample_sd),
        ("SEM", settings.show_stat_sem, sample_sem),
    ]

    rows = [
        (label, [formatted(values, calculation) for values in group_values])
        for label, enabled, calculation in row_specs
        if enabled
    ]
    if settings.show_stat_sample_size:
        rows.append(("Sample", [str(len(values)) for values in group_values]))
    return (groups, rows)


def format_overlay_value(value: float, settings: ChartSettings) -> str:
    decimals = max(0, min(int(settings.line_value_decimals), 12))
    format_type = "e" if settings.line_value_scientific else "f"
    return f"{value:.{decimals}{format_type}}"


def overlay_label_bbox(settings: ChartSettings) -> dict:
    preset = PRESETS[settings.preset]
    facecolor = "#FFFFFF" if preset["background"] == "#FFFFFF" else "#111827"
    edgecolor = "#D1D5DB" if preset["background"] == "#FFFFFF" else "#4B5563"
    return {
        "boxstyle": "round,pad=0.22",
        "facecolor": facecolor,
        "edgecolor": edgecolor,
        "alpha": 0.86,
        "linewidth": 0.55,
    }


def overlay_label_arrow(color: str) -> dict:
    return {
        "arrowstyle": "-",
        "color": color,
        "alpha": 0.65,
        "linewidth": 0.7,
        "shrinkA": 2,
        "shrinkB": 4,
    }


def overlay_line_style(style: str) -> str:
    return {
        "Solid": "-",
        "Dashed": "--",
        "Dotted": ":",
        "Dash-dot": "-.",
    }.get(style, "-")


def overlay_label_position_for_series(settings: ChartSettings, is_custom_overlay: bool) -> str:
    position = settings.custom_line_value_position if is_custom_overlay else settings.line_value_position
    return normalize_overlay_label_position(position, settings.chart_type, is_custom_overlay)


def overlay_auto_avoidance_position(settings: ChartSettings, is_custom_overlay: bool) -> str | None:
    if not is_custom_overlay or settings.line_overlay_stat == "None":
        return None
    stat_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
    if settings.chart_type == "Ridge":
        if stat_position == "Axis left":
            return "Right"
        if stat_position == "Axis right":
            return "Left"
    else:
        if stat_position == "Bottom axis":
            return "Above"
        if stat_position == "Top axis":
            return "Below"
    return None


def normalize_overlay_label_position(position: str, chart_type: str, is_custom_overlay: bool = False) -> str:
    point_positions = {"Auto", "Above", "Below", "Left", "Right"}
    if is_custom_overlay:
        return position if position in point_positions else "Auto"
    axis_positions = {"Axis left", "Axis right"} if chart_type == "Ridge" else {"Top axis", "Bottom axis"}
    valid_positions = point_positions | axis_positions
    if position in valid_positions:
        return position
    if chart_type == "Ridge" and position == "Top axis":
        return "Axis right"
    if chart_type == "Ridge" and position == "Bottom axis":
        return "Axis left"
    if chart_type != "Ridge" and position == "Axis right":
        return "Top axis"
    if chart_type != "Ridge" and position == "Axis left":
        return "Bottom axis"
    return "Auto"


def resolve_overlay_label_position(
    index: int,
    values: list[float],
    position: str,
    is_ridge: bool,
    series_index: int = 0,
    preferred_auto_position: str | None = None,
) -> str:
    point_positions = {"Above", "Below", "Left", "Right"}
    if position != "Auto":
        return position
    if preferred_auto_position in point_positions:
        return preferred_auto_position

    crowded = overlay_values_are_close(index, values)
    if is_ridge:
        prefer_right = (series_index + (1 if crowded and index % 2 else 0)) % 2 == 0
        return "Right" if prefer_right else "Left"
    prefer_above = (series_index + (1 if crowded and index % 2 else 0)) % 2 == 0
    return "Above" if prefer_above else "Below"


def overlay_label_offset(
    index: int,
    values: list[float],
    position: str,
    is_ridge: bool,
    series_index: int = 0,
    marker_size_points: float = 0.0,
) -> tuple[int, int, str, str]:
    position = resolve_overlay_label_position(index, values, position, is_ridge, series_index)

    stagger = max(series_index, 0) * 8
    side_gap = int(max(12, marker_size_points / 2.0 + 6))
    vertical_gap = int(max(13, marker_size_points / 2.0 + 6))

    if position == "Below":
        return (stagger, -vertical_gap, "center", "top")
    if position == "Left":
        return (-side_gap, -stagger, "right", "center")
    if position == "Right":
        return (side_gap, stagger, "left", "center")
    return (stagger, vertical_gap, "center", "bottom")


def overlay_values_are_close(index: int, values: list[float]) -> bool:
    if len(values) < 2:
        return False
    value_range = max(values) - min(values)
    threshold = max(value_range * 0.08, 1e-9)
    value = values[index]
    neighbors = []
    if index > 0:
        neighbors.append(values[index - 1])
    if index + 1 < len(values):
        neighbors.append(values[index + 1])
    return any(abs(value - neighbor) <= threshold for neighbor in neighbors)


def box_whis(mode: str):
    if mode == "Min-Max":
        return (0, 100)
    if mode == "Percentile 5-95":
        return (5, 95)
    if mode == "Percentile 10-90":
        return (10, 90)
    return 1.5


def axis_labels_for_chart(settings: ChartSettings) -> tuple[str, str]:
    group_label = settings.x_label
    value_label = settings.y_label
    if settings.chart_type == "Ridge":
        return value_label, group_label
    return group_label, value_label


def mark_outliers(df: pd.DataFrame, settings: ChartSettings) -> pd.DataFrame:
    outlier_parts = []
    for _, group_df in df.groupby(settings.group_col):
        values = group_df[settings.value_col]
        if len(values) < 3:
            continue
        if settings.outlier_method == "IQR":
            q1, q3 = values.quantile([0.25, 0.75])
            iqr = q3 - q1
            low = q1 - settings.outlier_threshold * iqr
            high = q3 + settings.outlier_threshold * iqr
            mask = (values < low) | (values > high)
        elif settings.outlier_method == "Z-score":
            std = values.std(ddof=0)
            mask = pd.Series(False, index=values.index) if std == 0 else ((values - values.mean()).abs() / std > settings.outlier_threshold)
        elif settings.outlier_method == "MAD":
            median = values.median()
            mad = (values - median).abs().median()
            mask = pd.Series(False, index=values.index) if mad == 0 else (0.6745 * (values - median).abs() / mad > settings.outlier_threshold)
        else:
            pct = settings.outlier_threshold
            low = values.quantile(max(0.0, pct / 100.0))
            high = values.quantile(min(1.0, 1.0 - pct / 100.0))
            mask = (values < low) | (values > high)
        outlier_parts.append(group_df[mask])
    return pd.concat(outlier_parts) if outlier_parts else pd.DataFrame(columns=df.columns)


def write_project(path: Path, df: pd.DataFrame, settings: ChartSettings) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        df.to_csv(tmp_path / "data.csv", index=False)
        (tmp_path / "settings.json").write_text(json.dumps(asdict(settings), indent=2), encoding="utf-8")
        (tmp_path / "project.json").write_text(json.dumps({"version": 1, "app": "EasyGraph"}, indent=2), encoding="utf-8")
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for file in tmp_path.iterdir():
                archive.write(file, arcname=file.name)


def read_project(path: Path) -> tuple[pd.DataFrame, ChartSettings]:
    with zipfile.ZipFile(path, "r") as archive:
        with archive.open("data.csv") as data_file:
            df = pd.read_csv(data_file)
        settings_data = json.loads(archive.read("settings.json").decode("utf-8"))
    return df, chart_settings_from_dict(settings_data)


def main() -> None:
    app = QApplication([])
    install_app_translator(app)
    apply_app_theme(app)
    window = MainWindow()
    window.show()
    app.exec()


if __name__ == "__main__":
    main()
