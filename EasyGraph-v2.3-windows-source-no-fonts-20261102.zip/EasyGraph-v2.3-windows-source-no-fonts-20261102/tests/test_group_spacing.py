from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import pandas as pd
from matplotlib.collections import PolyCollection

from easygraph.data import attach_group_metadata, prepare_plot_frames
from easygraph.grouping import GroupingSettings
from easygraph.plotting.canvas import PlotCanvas
from easygraph.plotting.group_layout import build_group_layout
from easygraph.project_io import read_project, write_project
from easygraph.settings import ChartSettings
from easygraph.template_io import read_style_template_file, write_style_template
from tests.easygraph_case import EasyGraphQtTestCase


class GroupSpacingTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.ids = ["a", "b", "c"]
        self.frame = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6], "C": [7, 8, 9]})
        self.grouping = GroupingSettings(parents=[
            {"id": "parent", "name": "Experiment", "column_ids": self.ids},
        ])

    def make_canvas(self):
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        return canvas

    def test_single_level_columns_keep_configured_gaps_without_parent_metadata(self):
        for grouping in (None, GroupingSettings()):
            for inner, outer in ((1.0, 2.7), (0.7, 1.4), (2.0, 0.2), (2.0, 0.1), (2.0, 0.0)):
                with self.subTest(grouping=grouping, inner=inner, outer=outer):
                    settings = ChartSettings(group_inner_spacing=inner, group_outer_spacing=outer)
                    prepared = prepare_plot_frames(attach_group_metadata(self.frame, self.ids), settings)
                    layout = build_group_layout(prepared.visible, settings, grouping, self.ids)
                    np.testing.assert_allclose(list(layout.positions.values()), [0, 1 + outer, 2 * (1 + outer)])
                    self.assertEqual(layout.parents, ())
                    self.assertEqual(layout.cell_width, 1)

    def test_project_and_style_template_preserve_zero_and_small_gaps(self):
        for gap in (0.0, 0.01, 0.1):
            with self.subTest(gap=gap), TemporaryDirectory() as directory:
                settings = ChartSettings(group_inner_spacing=gap, group_outer_spacing=gap)
                project = Path(directory) / "spacing.eg"
                write_project(project, self.frame, settings)
                _, loaded = read_project(project)
                template = write_style_template("Spacing", settings, Path(directory))
                styled = read_style_template_file(template)
                for restored in (loaded, styled):
                    self.assertEqual(restored.group_inner_spacing, gap)
                    self.assertEqual(restored.group_outer_spacing, gap)

    def test_spacing_changes_visible_gaps_without_scaling_artists_or_losing_alignment(self):
        for grouped in (False, True):
            for chart_type in ("Box", "Bar", "Violin", "Ridge"):
                canvas = self.make_canvas()
                previous_gap = None
                previous_widths = None
                for gap in (0.0, 0.1, 0.2, 0.7, 1.4, 3.2):
                    with self.subTest(grouped=grouped, chart_type=chart_type, gap=gap):
                        settings = ChartSettings(
                            chart_type=chart_type, group_inner_spacing=gap if grouped else 0.2,
                            group_outer_spacing=4.0 if grouped else gap,
                            jitter=0, line_overlay_stat="Mean", show_stat_table=True,
                            show_stat_mean=True, show_stat_header=True,
                            extra_custom_overlay=True, custom_overlay_secondary_axis=True,
                            custom_overlay_series=[{"name": "Response", "values": dict(zip(self.ids, [10, 20, 30]))}],
                        )
                        canvas.render(self.frame, settings, grouping=self.grouping if grouped else None,
                                      column_ids=self.ids)
                        layout = canvas._group_layout
                        np.testing.assert_allclose(list(layout.positions.values()), [0, 1 + gap, 2 * (1 + gap)])
                        ridge = chart_type == "Ridge"
                        dimension = 1 if ridge else 0
                        positions = [layout.coordinate(key, ridge=ridge) for key in self.ids]
                        ax = canvas.figure.axes[0]
                        secondary = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
                        for axis, label in ((ax, "Mean"), (secondary, "Response")):
                            line = next(line for line in axis.lines if line.get_label() == label)
                            np.testing.assert_allclose(line.get_ydata() if ridge else line.get_xdata(), positions)
                        points = [artist for artist in ax.collections if artist.get_gid() == "data-points"]
                        np.testing.assert_allclose(
                            np.concatenate([artist.get_offsets()[:, dimension] for artist in points]),
                            np.repeat(positions, 3),
                        )
                        table = next(axis for axis in canvas.figure.axes if not axis.axison)
                        leaves = [text for text in table.texts if text.get_gid() == "stat-leaf-header"]
                        for text, position in zip(leaves, positions):
                            expected = ax.transData.transform((0, position) if ridge else (position, 0))[dimension]
                            self.assertAlmostEqual(text.get_transform().transform(text.get_position())[dimension], expected)
                        if ridge:
                            # Ridge table rows have a fixed physical height.
                            # Check the plotted density gap relative to its height.
                            widths = [np.ptp(artist.get_paths()[0].vertices[:, 1])
                                      for artist in ax.collections if isinstance(artist, PolyCollection)]
                            visible_gap = abs(ax.transData.transform((0, positions[0] - widths[1]))[1]
                                              - ax.transData.transform((0, positions[1]))[1])
                        else:
                            for left, right in zip(leaves, leaves[1:]):
                                self.assertAlmostEqual(right._stat_cell_bounds[0] - left._stat_cell_bounds[1], gap)
                            visible_gap = (table.transData.transform((leaves[1]._stat_cell_bounds[0], 0))[0]
                                           - table.transData.transform((leaves[0]._stat_cell_bounds[1], 0))[0])
                            if chart_type == "Bar":
                                widths = [patch.get_width() for patch in ax.patches]
                            elif chart_type == "Box":
                                widths = [np.ptp(patch.get_path().vertices[:, 0]) for patch in ax.patches]
                            else:
                                widths = [np.ptp(artist.get_paths()[0].vertices[:, 0])
                                          for artist in ax.collections if isinstance(artist, PolyCollection)]
                        self.assertEqual(len(widths), 3)
                        if previous_widths is not None:
                            np.testing.assert_allclose(widths, previous_widths)
                        if previous_gap is not None:
                            self.assertGreater(visible_gap, previous_gap)
                        previous_gap = visible_gap
                        previous_widths = widths
