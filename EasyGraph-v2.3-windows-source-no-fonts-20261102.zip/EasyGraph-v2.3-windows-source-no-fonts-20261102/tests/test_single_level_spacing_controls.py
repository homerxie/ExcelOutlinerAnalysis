from __future__ import annotations

from pathlib import Path
from unittest import mock

import numpy as np
import pandas as pd
from PySide6.QtCore import QTranslator
from PySide6.QtWidgets import QDialog

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.ui.grouping_controls import GroupDisplayDialog
from easygraph.workbook import SHEET_MODE_XY


class SingleLevelSpacingControlsTests(EasyGraphQtTestCase):
    def test_single_level_spacing_control_updates_rendered_columns(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6], "C": [7, 8, 9]}))
        window.settings.group_inner_spacing = 2.0
        window.apply_settings_to_controls()
        window.initialize_preview()
        window.handle_plot_object_selection("category_axis")
        self.assertTrue(window.ui.categoryAxisForm.isRowVisible(window.ui.parentGroupSpacingLabel))
        self.assertTrue(window.group_outer_spacing.isVisibleTo(window.ui.categoryAxisGroup))
        self.assertEqual(window.ui.parentGroupSpacingLabel.text(), "Column spacing")
        self.assertFalse(window.ui.categoryAxisForm.isRowVisible(window.ui.groupLayoutButton))

        self.assertEqual(window.group_outer_spacing.minimum(), 0.0)
        for spacing in (0.0, 0.01, 0.1, 0.2, 0.7, 1.6, 3.2):
            with self.subTest(spacing=spacing):
                window.group_outer_spacing.setValue(spacing)
                self.assertEqual(window.settings.group_outer_spacing, spacing)
                window.flush_pending_render()
                np.testing.assert_allclose(np.diff(list(window.canvas._group_layout.positions.values())), 1 + spacing)
                window.group_outer_spacing.stepUp()
                self.assertAlmostEqual(window.settings.group_outer_spacing, spacing + 0.2)
                window.group_outer_spacing.stepDown()
                self.assertAlmostEqual(window.settings.group_outer_spacing, spacing)

    def test_single_parent_dialog_updates_inner_spacing_and_undo_restores_it(self):
        window = self.make_window()
        self.select_table_range(window.table, 0, 0, 0, 1)
        self.assertTrue(window.grouping_controls.create_selected_parent("Experiment"))
        original = (window.settings.group_inner_spacing, window.settings.group_outer_spacing)
        for inner, outer in ((0.0, 0.0), (0.01, 0.03), (0.1, 0.1), (1.5, 3.4)):
            with self.subTest(inner=inner, outer=outer):
                dialog = GroupDisplayDialog(window.settings, window.workbook.active_sheet.grouping, window)
                dialog.inner.setValue(inner)
                dialog.outer.setValue(outer)
                with mock.patch("easygraph.ui.grouping_controls.GroupDisplayDialog", return_value=dialog), mock.patch.object(
                    dialog, "exec", return_value=QDialog.Accepted
                ):
                    window.ui.groupLayoutButton.click()
                self.assertEqual(window.settings.group_inner_spacing, inner)
                self.assertEqual(window.settings.group_outer_spacing, outer)
                self.assertEqual(window.group_outer_spacing.minimum(), inner)
                self.assertEqual(window.group_outer_spacing.value(), outer)
                window.undo_table_change()
                self.assertEqual((window.settings.group_inner_spacing, window.settings.group_outer_spacing), original)

    def test_spacing_stays_available_after_removing_parent_headers_and_undo(self):
        window = self.make_window()
        self.select_table_range(window.table, 0, 0, 0, 1)
        self.assertTrue(window.grouping_controls.create_selected_parent("Experiment"))
        self.assertEqual(window.ui.parentGroupSpacingLabel.text(), "Parent group spacing")
        self.assertTrue(window.ui.categoryAxisForm.isRowVisible(window.ui.groupLayoutButton))
        spacing = window.group_outer_spacing.value()

        window.table.horizontalHeader().select_parent_columns([0, 1])
        self.assertTrue(window.grouping_controls.unmerge_selected_headers())
        self.assertTrue(window.ui.categoryAxisForm.isRowVisible(window.ui.parentGroupSpacingLabel))
        self.assertEqual(window.ui.parentGroupSpacingLabel.text(), "Column spacing")
        self.assertFalse(window.ui.categoryAxisForm.isRowVisible(window.ui.groupLayoutButton))
        self.assertEqual(window.group_outer_spacing.minimum(), 0.0)
        self.assertEqual(window.group_outer_spacing.value(), spacing)

        window.undo_table_change()
        self.assertEqual(window.ui.parentGroupSpacingLabel.text(), "Parent group spacing")
        self.assertEqual(window.group_outer_spacing.value(), spacing)

    def test_spacing_control_is_available_for_all_groups_charts_and_hidden_for_xy(self):
        window = self.make_window()
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            with self.subTest(chart_type=chart_type):
                window.chart_type.setCurrentText(chart_type)
                self.assertTrue(window.ui.categoryAxisForm.isRowVisible(window.ui.parentGroupSpacingLabel))
                self.assertEqual(window.ui.parentGroupSpacingLabel.text(), "Column spacing")
        window.add_sheet(SHEET_MODE_XY)
        self.assertFalse(window.ui.categoryAxisForm.isRowVisible(window.ui.parentGroupSpacingLabel))
        self.assertFalse(window.ui.categoryAxisForm.isRowVisible(window.ui.groupLayoutButton))
        window.sheet_tab_bar.setCurrentIndex(0)
        self.assertTrue(window.ui.categoryAxisForm.isRowVisible(window.ui.parentGroupSpacingLabel))
        self.assertEqual(window.ui.parentGroupSpacingLabel.text(), "Column spacing")

    def test_spacing_labels_are_translated_for_both_header_levels(self):
        translator = QTranslator()
        self.assertTrue(translator.load(str(Path(__file__).resolve().parents[1] / "translations/easygraph_zh_CN.qm")))
        self.qapp.installTranslator(translator)
        try:
            window = self.make_window()
            self.assertEqual(window.ui.parentGroupSpacingLabel.text(), "列间距")
            self.assertEqual(window.group_outer_spacing.toolTip(), "列之间的空白，以列宽为单位；0 表示无额外空白。")
            self.select_table_range(window.table, 0, 0, 0, 1)
            self.assertTrue(window.grouping_controls.create_selected_parent("Experiment"))
            self.assertEqual(window.ui.parentGroupSpacingLabel.text(), "一级组间距")
            self.assertEqual(window.group_outer_spacing.toolTip(), "一级组之间的空白，以列宽为单位；0 表示无额外空白。")
            dialog = GroupDisplayDialog(window.settings, window.workbook.active_sheet.grouping, window)
            self.assertEqual(dialog.inner.toolTip(), "同一一级组内各列之间的空白，以列宽为单位；0 表示无额外空白。")
            self.assertEqual(dialog.outer.toolTip(), window.group_outer_spacing.toolTip())
        finally:
            self.qapp.removeTranslator(translator)
