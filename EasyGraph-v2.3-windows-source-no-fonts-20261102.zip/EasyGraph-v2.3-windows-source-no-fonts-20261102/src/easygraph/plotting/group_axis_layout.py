"""Physical label layout for single- and two-level categorical X axes."""
from __future__ import annotations

from dataclasses import dataclass

from matplotlib.font_manager import FontProperties

from easygraph.plotting.group_label_metrics import text_width_points, wrap_label


@dataclass(frozen=True)
class GroupAxisLabels:
    mode: str
    rotation: float
    leaves: tuple[str, ...]
    parents: tuple[str, ...]

    def parent_height_points(self, font_size: float) -> float:
        return max((label.count("\n") + 1 for label in self.parents), default=0) * font_size * 1.35


def prepare_group_axis_labels(layout, settings, plot_width_points: float) -> GroupAxisLabels | None:
    if settings.chart_type == "Ridge":
        return None
    mode = getattr(settings, "group_axis_label_layout", "Wrap")
    rotation = float(settings.x_tick_rotation)
    if not layout.parents:
        # A saved hierarchy style must not introduce rotation or empty parent
        # rows after grouping is removed. Single-level axes follow their angle.
        mode = "Bottom" if rotation else "Wrap"
    else:
        if mode == "Wrap" and rotation:
            mode = "Bottom"
        if mode == "Bottom" and not rotation:
            rotation = 45.0
        if mode == "Wrap":
            rotation = 0.0

    low, high = layout.limits
    scale = plot_width_points / max(high - low, 1e-9)
    font_size = max(settings.tick_font_size, 1)
    leaf_font = FontProperties(size=font_size)
    parent_font = FontProperties(size=font_size, weight="medium")
    positions = [layout.positions[key] for key in layout.order]
    leaves = []
    for index, key in enumerate(layout.order):
        label = "" if layout.hide_leaf_labels else layout.labels[key]
        if not rotation and label and "\n" not in label:
            x = positions[index]
            left = x - positions[index - 1] if index else 2 * (x - low)
            right = positions[index + 1] - x if index + 1 < len(positions) else 2 * (high - x)
            width = max(font_size, min(left, right) * scale - 6.0)
            label = wrap_label(label, width, leaf_font)
        leaves.append(label)

    if not rotation:
        # Restore a short whole word when its neighbours leave enough room.
        # This avoids needless "Contr\nol" without allowing labels to collide.
        widths = [text_width_points(label, leaf_font) for label in leaves]
        for index, key in enumerate(layout.order):
            original = "" if layout.hide_leaf_labels else layout.labels[key]
            if not original or "\n" in original or leaves[index] == original:
                continue
            width = text_width_points(original, leaf_font)
            if width > max(font_size, plot_width_points - 6.0):
                continue
            left_clear = (not index or (width + widths[index - 1]) / 2 + 4.0
                          <= (positions[index] - positions[index - 1]) * scale)
            right_clear = (index + 1 == len(positions) or (width + widths[index + 1]) / 2 + 4.0
                           <= (positions[index + 1] - positions[index]) * scale)
            if left_clear and right_clear:
                leaves[index] = original
                widths[index] = width

    # A title may use the whitespace beside a narrow bracket. Its centred
    # allocation stops before the midpoint to the neighbouring parent title.
    centers = [parent.center for parent in layout.parents]
    parents = []
    for index, parent in enumerate(layout.parents):
        real_width = (parent.end - parent.start + layout.cell_width) * scale
        neighbour_distances = []
        if index:
            neighbour_distances.append((parent.center - centers[index - 1]) * scale)
        if index + 1 < len(centers):
            neighbour_distances.append((centers[index + 1] - parent.center) * scale)
        available = min(neighbour_distances) - 10.0 if neighbour_distances else plot_width_points
        # Never enlarge the bracket to match this independent text allocation.
        width = max(font_size, min(real_width + 2 * font_size, available, plot_width_points) - 4.0)
        parents.append(parent.label if "\n" in parent.label else wrap_label(parent.label, width, parent_font))
    return GroupAxisLabels(mode, rotation, tuple(leaves), tuple(parents))
