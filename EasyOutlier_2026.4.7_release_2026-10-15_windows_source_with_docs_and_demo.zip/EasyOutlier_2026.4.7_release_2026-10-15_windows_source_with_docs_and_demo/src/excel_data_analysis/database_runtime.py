"""Short-lived application files owned by the currently opened database.

Only resolved paths are exposed to running workers. These directories are not
durable data references and are never included in workspace/database copies.
The owning TemporaryDirectory object controls each job's lifetime.
"""
from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

from .database_paths import WORKSPACE_MARKER_FILENAME, database_root_for_storage


RUNTIME_DIRNAME = ".runtime"


def runtime_directory(storage_root: str | Path) -> Path:
    """Return the database-owned scratch parent, creating it when necessary."""
    root = database_root_for_storage(storage_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    directory = root / RUNTIME_DIRNAME
    if directory.is_symlink():
        raise ValueError("Database runtime directory must not be a symbolic link")
    directory.mkdir(exist_ok=True)
    return directory


def temporary_database_directory(storage_root: str | Path, *, prefix: str) -> TemporaryDirectory:
    """Create an automatically cleaned scratch directory inside its database."""
    return TemporaryDirectory(prefix=prefix, dir=runtime_directory(storage_root))


def database_root_for_snapshot(snapshot_path: str | Path) -> Path:
    """Locate a snapshot's owner without relying on the process directory.

    GUI snapshots have an explicit runtime or saved-analysis location. Older
    direct API callers may supply an arbitrary archive; its own directory is
    then the explicit local owner of temporary recovery files.
    """
    parent = Path(snapshot_path).absolute().parent
    markers = (WORKSPACE_MARKER_FILENAME, ".excel_data_analysis_gui_state.json",
               "datasets.jsonl", "measurements.jsonl", "measurements.jsonl.gz")
    for candidate in (parent, *parent.parents):
        if candidate.name == RUNTIME_DIRNAME:
            return candidate.parent
        if any((candidate / name).is_file() for name in markers):
            return database_root_for_storage(candidate)
        if candidate.name == "analysis" and candidate.parent.name == "result":
            return candidate.parent.parent
    return parent


def temporary_snapshot_directory(snapshot_path: str | Path, *, prefix: str) -> TemporaryDirectory:
    """Keep recovery scratch alongside the database that owns its archive."""
    return temporary_database_directory(database_root_for_snapshot(snapshot_path), prefix=prefix)
