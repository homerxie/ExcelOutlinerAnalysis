"""TSK estimation and export from completed Analyze results.

The GUI consumes its completed Analyze snapshot. Programmatic raw-source calls
first run the same Analyze engine without creating workbooks.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone
from functools import wraps
import hashlib
import json
import math
from pathlib import Path
from time import monotonic, perf_counter
from typing import Any, Callable

from .field_names import preferred_batch_field, row_fields
from .analyzer import _golden_reference_key_resolver
from .compact_analysis import ColumnarMeasurements
from .io import build_measurements, load_table
from .models import TemplateConfig
from .repository import Repository
from .reporting import (
    _build_columns, _build_rows, _build_rows_from_measurements,
    _build_zscore_map, _build_report_golden_values, _load_built_golden_reference,
    _collect_outlier_summary_artifacts, _build_sample_node_orders, _fail_mode_requires_golden,
    _select_zscore_reference,
    _sample_key_display, _sample_key_from_dimensions,
    _validate_report_row_identities,
    apply_analysis_exclusions,
)
from .merge_config import chain_level, column_levels
from .template import load_template, template_to_payload, validate_report_identity
from .tsk_sorting import natural_sort_key
from .tsk_parallel import validate_analysis_workers, worker_count
from .tsk_hybrid_parallel import ordered_group_map
from .compute_resources import automatic_tsk_budget, limit_process_workers
from .tsk_observations import (
    read_analysis_snapshot, template_for_snapshot, selected_snapshot_rows,
    observations_from_snapshot, validate_node_mode, resolve_snapshot_node_groups,
)


_AUTO_BATCH_FIELD = object()


def _unscorable_z_metrics(measurements, z_values, golden_reference=None):
    if golden_reference is not None:
        dimensions = golden_reference.reference_dimensions
        reference_key_for = _golden_reference_key_resolver(golden_reference)
        selected_keys = {
            (reference_key_for(record), record.logical_metric)
            for record in measurements
        }
        return {
            metric.logical_metric: "样本不足 3" if metric.sample_size < 3 else "MAD 为 0"
            for metric in golden_reference.metrics
            if (tuple((name, metric.reference_key.get(name, "")) for name in dimensions), metric.logical_metric)
            in selected_keys and (metric.sample_size < 3 or metric.zscore_mad == 0)
        }
    counts = defaultdict(int)
    informative = set()
    for measurement in measurements:
        counts[measurement.logical_metric] += 1
        entry = z_values.get((measurement.dataset_id, measurement.row_number, measurement.raw_column))
        if entry is not None and entry.value is not None and abs(entry.value) > 0:
            informative.add(measurement.logical_metric)
    # Informational only: Analyze's actual leaf state remains authoritative.
    return {metric: "样本不足 3" if count < 3 else "MAD 为 0"
            for metric, count in counts.items() if count < 3 or metric not in informative}


def _batch_settings(template, *, batch_mode="none", batch_dimension=_AUTO_BATCH_FIELD, batch_mapping=None):
    if batch_mode not in {"none", "separate", "parent"}:
        raise ValueError(f"不支持的 TSK 批次模式：{batch_mode}")
    # Legacy callers can omit the batch field. Recognize a declared lot field
    # when possible; otherwise their explicitly defined sample key is the identity.
    if batch_dimension is _AUTO_BATCH_FIELD:
        batch_dimension = (preferred_batch_field(d.name for d in template.row_dimensions
                           if d.name != template.report.reliability_node_dimension)
                           if batch_mode == "none" else None)
    dimension = (row_fields(template).resolve(batch_dimension, strict=True)
                 if batch_dimension is not None or batch_mode != "none" else None)
    if dimension == template.report.reliability_node_dimension:
        raise ValueError("批次字段不能使用可靠性节点；请使用节点分析方式设置节点组合。")
    if batch_mode == "none":
        return {"batch_mode": "none", "batch_dimension": dimension, "batch_mapping": {}}
    if batch_mapping is not None and not isinstance(batch_mapping, dict):
        raise ValueError("原批次到母批编号的对应关系必须为字典。")
    mapping = {}
    for source, parent in (batch_mapping or {}).items():
        if not isinstance(source, str) or not isinstance(parent, str):
            raise ValueError("原批次和母批编号必须是文本。")
        mapping[source] = parent.strip()
    return {"batch_mode": batch_mode, "batch_dimension": dimension, "batch_mapping": mapping}


def _batch_value(dimensions, dimension):
    value = dimensions.get(dimension)
    if value is None or not str(value).strip():
        raise ValueError(f"TSK 批次字段 {dimension!r} 存在空值，请先补全批次信息。")
    return str(value)


def _pool_batch_groups(groups, batch):
    """Pool sufficient counts, never type estimates or cross-batch sample IDs."""
    output = {}
    for group in groups:
        source = group.pop("source_batch")
        parent = (batch["batch_mapping"][source] if batch["batch_mode"] == "parent" else
                  source if batch["batch_mode"] == "separate" else "")
        key = (group.get("node_group_index", group["node"]), parent)
        if key not in output:
            description = "母批" if batch["batch_mode"] == "parent" else batch["batch_dimension"]
            label = group["label"] if batch["batch_mode"] == "none" else f"{group['label']} | {description}={parent}"
            output[key] = {**group, "label": label,
                           "batch_mode": batch["batch_mode"], "batch_dimension": batch["batch_dimension"],
                           "parent_batch_id": parent if batch["batch_mode"] == "parent" else None,
                           "source_batches": [], "batch_counts": [], "counts": {},
                           "sample_outcomes": [], "classification_warnings": []}
        target = output[key]
        target["source_batches"].append(source)
        target["classification_warnings"].extend(group["classification_warnings"])
        target["sample_outcomes"].extend({**row, "source_batch": source} for row in group["sample_outcomes"])
        target["batch_counts"].extend({"source_batch": source, **row} for row in group["counts"])
        for row in group["counts"]:
            total = target["counts"].setdefault(row["chain_id"], {"chain_id": row["chain_id"],
                "n_tested": 0, "n_failed": 0, "n_passed": 0, "n_missing": 0})
            for name in ("n_tested", "n_failed", "n_passed", "n_missing"):
                total[name] += row[name]
    for group in output.values():
        group["counts"] = sorted(group["counts"].values(), key=lambda row: natural_sort_key(row["chain_id"]))
        group["classification_warnings"] = list(dict.fromkeys(group["classification_warnings"]))
    # Observation order follows the template sequence / user's group order.
    return list(output.values())


def collect_tsk_observations(template, measurements, rows, *, golden_path=None,
                             batch_mode="none", batch_dimension=_AUTO_BATCH_FIELD,
                             batch_mapping=None, progress_callback=None, node_mode="separate", node_groups=None):
    """Classify the selected scope with Analyze's rules, then count unique samples.

    Empty cells follow ``outlier_treat_empty_cells_as_fail`` exactly. A known
    sample/chain with no retained leaf is Missing. Analyze's sample identity must
    distinguish original batches before their final counts can be pooled.
    """
    from .template import validate_tsk_analysis_config

    validate_report_identity(template)
    validate_tsk_analysis_config(template, require_instances=True)
    fail_method = template.report.outlier_fail_method
    if fail_method not in {"modified_z_score", "golden_deviation", "zscore_and_golden", "zscore_or_golden"}:
        raise ValueError(f"Unsupported Analyze Fail criterion: {fail_method}")
    if _fail_mode_requires_golden(fail_method) and not golden_path:
        raise ValueError("Analyze 当前规则包含 Golden 判据，请在 Setup 中选择 Golden 文件。")
    measurements, rows = _filter_tsk_analysis_scope(template, measurements, rows)
    _validate_report_row_identities(template, rows)
    columns = _build_columns(template, {}, sorted({item.raw_column for item in measurements}))
    prefix_length = column_levels(template).index(chain_level(template)) + 1
    chain_keys = {tuple(item.chain_key): item.chain_id for item in template.tsk_analysis.instances}
    selected_columns = [c for c in columns if tuple(c.header_values[:prefix_length]) in chain_keys]
    if not selected_columns:
        raise ValueError("TSK 实例表未匹配到测量列。请检查完整 Chain 键。")
    # Retain the original columns and row identities so excluded intersections
    # remain Missing in TSK, including a chain with no retained numeric cells.
    measurements, rows = apply_analysis_exclusions(template, measurements, rows)
    batch = _batch_settings(template, batch_mode=batch_mode, batch_dimension=batch_dimension,
                            batch_mapping=batch_mapping)
    if progress_callback:
        progress_callback(18, "TSK：按 Analyze 规则计算所选范围的测量判据…")
    # Match Analyze's effective global threshold while retaining the priority
    # of explicit template thresholds. Pool before any batch split.
    golden = _load_built_golden_reference(golden_path) if golden_path else None
    zscore_reference = _select_zscore_reference(template, fail_method, golden)
    z_values = _build_zscore_map(measurements, template.report.zscore_thresholds, columns,
                                zscore_threshold_override=template.report.zscore_thresholds.default,
                                golden_reference=zscore_reference)
    unscorable = _unscorable_z_metrics(measurements, z_values, zscore_reference)
    affected = len(set(unscorable) & {column.logical_metric for column in selected_columns})
    classification_warnings = ([f"Modified Z Score 有 {affected} 个测项样本不足 3 或 MAD 为 0；遵循 Analyze 的现有输出（Z 分数为 0），不在 TSK 中改判 Missing。"]
                               if affected and fail_method != "golden_deviation" else [])
    golden_values = _build_report_golden_values(measurements, template, columns, golden_reference=golden)
    if _fail_mode_requires_golden(fail_method):
        selected_raw_columns = {column.raw_column for column in selected_columns}
        unmatched = sum(row.raw_column in selected_raw_columns and
                        (row.dataset_id, row.row_number, row.raw_column) not in golden_values
                        for row in measurements)
        if unmatched:
            classification_warnings.append(f"有 {unmatched} 个数值测量未匹配 Golden；遵循 Analyze，将对应 Golden Fail 项视为 False 后组合判据，不在 TSK 中改判 Missing。")
    artifacts = _collect_outlier_summary_artifacts(
        template, columns, rows, z_values, golden_values, _build_sample_node_orders(rows, template),
        outlier_fail_method_override=fail_method,
    )
    snapshot = {"template": template, "columns": columns, "rows": rows, "summary_artifacts": artifacts}
    selected_template = template_for_snapshot(snapshot)
    return observations_from_snapshot(snapshot, selected_template, rows, batch, classification_warnings,
                                      node_mode=node_mode, node_groups=node_groups)


def _filter_tsk_analysis_scope(template, measurements, rows):
    from .service import _filter_measurements, build_dimension_filters

    filters = template.report.analysis_dimension_filters
    dimension_filters = build_dimension_filters(
        sample_keys=filters.include.get("sample_key", []),
        exclude_sample_keys=filters.exclude.get("sample_key", []),
        sample_dimension_names=template.report.sample_dimension_names,
        reliability_node_dimension=template.report.reliability_node_dimension,
        reliability_nodes=filters.include.get("reliability_node", []),
        exclude_reliability_nodes=filters.exclude.get("reliability_node", []),
    )
    column_filters = asdict(template.report.analysis_column_filters)
    if dimension_filters or any(column_filters.values()):
        missing_columns_by_dataset = {row.dataset_id: row.missing_columns for row in rows}
        measurements = _filter_measurements(measurements, dimension_filters=dimension_filters,
            column_filters=column_filters, template=template, compact=True)
        rows = _build_rows_from_measurements(measurements, missing_columns_by_dataset)
        if not rows:
            raise ValueError("Analyze 筛选范围没有样品数据。")
    return measurements, rows


def _load_tsk_selection(template, *, source, storage_path, input_path, options):
    """Use identical import/node/sample scopes for discovery and estimation."""
    warnings = []
    dataset_ids = set(options.get("dataset_ids", []))
    if source == "input":
        if not input_path:
            raise ValueError("请在 Setup 中选择 Input Excel/CSV。")
        table = load_table(input_path, template=template)
        rows = _build_rows(template, table.rows, input_path)
        measurements = ColumnarMeasurements(build_measurements(template, table.rows, "ad-hoc-report", str(Path(input_path).resolve())))
        del table
    elif source == "database":
        if not storage_path:
            raise ValueError("请先打开数据库。")
        if options.get("analysis_scope") == "checked_imports" and not dataset_ids:
            raise ValueError("请在 TSK Analysis 页勾选至少一个导入记录。")
        from .service import _missing_columns_by_dataset

        repository = Repository(storage_path)
        measurements = ColumnarMeasurements(m for m in repository.iter_measurements()
                        if options.get("analysis_scope") != "checked_imports" or m.dataset_id in dataset_ids)
        rows = _build_rows_from_measurements(
            measurements, _missing_columns_by_dataset(None, repository, template=template),
        )
        warnings.append("数据库只保留可解析的数值测量；导入时整行没有数值的样品无法恢复。Missing 计数仅覆盖已知样品/节点，完整曝光数请使用原始输入文件核对。")
    else:
        raise ValueError(f"Unsupported TSK source: {source}")
    measurements, rows = _filter_tsk_analysis_scope(template, measurements, rows)
    nodes, sample_ids = set(options.get("nodes", [])), set(options.get("sample_ids", []))
    def included(row):
        sample = _sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names)
        return ((not nodes or row.dimensions.get(template.report.reliability_node_dimension) in nodes)
                and (not sample_ids or _sample_key_display(sample) in sample_ids or (sample and sample[-1] in sample_ids)))
    rows = [row for row in rows if included(row)]
    selected_rows = {(row.dataset_id, row.row_number) for row in rows}
    measurements = ColumnarMeasurements(m for m in measurements if (m.dataset_id, m.row_number) in selected_rows)
    if not rows:
        raise ValueError("所选 TSK 分析范围没有样品数据。")
    return measurements, rows, warnings


def discover_tsk_batches(*, template_path: str, source: str = "database", storage_path: str | None = None,
                         input_path: str | None = None, settings: dict | None = None,
                         analysis_template: TemplateConfig | None = None,
                         analysis_snapshot_path: str | None = None,
                         progress_callback: Callable | None = None) -> list[str]:
    """Read the current TSK scope, without fitting or modifying the database."""
    options = dict(settings or {})
    # Retired controls from saved workspaces must never silently split new fits.
    for retired in ("group_by_dimensions", "fail_method", "classification_pool"):
        options.pop(retired, None)
    snapshot = read_analysis_snapshot(analysis_snapshot_path) if analysis_snapshot_path or source == "analyze" else None
    template = (template_for_snapshot(snapshot) if snapshot is not None else
                deepcopy(analysis_template) if analysis_template is not None else load_template(template_path))
    batch = _batch_settings(template, batch_mode="separate", batch_dimension=options.get("batch_dimension"))
    progress = progress_callback or (lambda value, message: None)
    progress(5, "TSK：读取所选范围的原批次…")
    if snapshot is not None:
        rows = selected_snapshot_rows(snapshot, options)
        selection_snapshot = snapshot
    else:
        _, rows, _ = _load_tsk_selection(template, source=source, storage_path=storage_path,
                                         input_path=input_path, options={**options, "nodes": [], "sample_ids": []})
        selection_snapshot = {"template": template, "rows": rows}
        rows = selected_snapshot_rows(selection_snapshot, options)
    if options.get("node_mode") in {"sequence_groups", "combined_new"}:
        groups = resolve_snapshot_node_groups(selection_snapshot, options)
        terminal_nodes = {group[-1] for group in groups}
        rows = [row for row in rows if row.dimensions[template.report.reliability_node_dimension] in terminal_nodes]
    values = sorted({_batch_value(row.dimensions, batch["batch_dimension"]) for row in rows})
    progress(100, f"TSK：发现 {len(values)} 个原批次。")
    return values


def _empty_prediction_context(instances, categorical_names, feature_names, options):
    """Keep the full layout grid for an all-Missing group, without a fit."""
    from .tsk_features import category_label
    from .tsk_spatial import (DEFAULT_XY_MODEL, SPATIAL_TERMS, build_spatial_transform,
                              spatial_feature_groups)

    type_ids = sorted({item.tsk_id for item in instances}, key=natural_sort_key)
    categories = {}
    columns = [(name, None) for name in feature_names if name not in categorical_names]
    for name in categorical_names:
        levels = sorted({category_label(item.features[name], name) for item in instances})
        categories[name] = {"encoding": "reference_one_hot", "levels": levels, "reference": levels[0],
                            "active_levels": [], "missing_levels": list(levels)}
        columns.extend((name, level) for level in levels[1:])
    numeric_reference = {}
    for name, level in columns:
        if level is None:
            values = [item.x if name == "x" else item.y if name == "y" else item.features.get(name)
                      for item in instances]
            if all(isinstance(value, (int, float)) and math.isfinite(value) for value in values):
                numeric_reference[name] = float(sum(values) / len(values))
    spatial_transform = None
    if options.use_xy and options.xy_model == DEFAULT_XY_MODEL:
        columns = [(name, level) for name, level in columns if name not in {"x", "y"}]
        columns.extend((name, None) for name, _, _ in SPATIAL_TERMS)
        # An all-Missing group has no fitted numeric environment. Retain a
        # layout-based encoding only when its coordinates are actually known.
        if all(isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
               for item in instances for value in (item.x, item.y)):
            spatial_transform = build_spatial_transform(instances)
    return {"version": 1, "model": f"instance_{options.feature_model}_features", "converged": False,
            "xy_model": options.xy_model if options.use_xy else None,
            "spatial_transform": spatial_transform, "feature_groups": spatial_feature_groups(spatial_transform),
            "clipped": False, "boundary_fit": None, "negative_log_likelihood": 0.,
            "confidence_level": options.confidence_level, "coefficients": [0.] * (len(type_ids) + len(columns)),
            "design": [], "chain_index": [], "chain_ids": [], "n_tested": [], "n_failed": [],
            "type_ids": type_ids, "all_type_ids": type_ids, "coefficient_columns": columns,
            "categorical_features": categories, "numeric_reference": numeric_reference,
            "topology": [{"chain_id": item.chain_id, "instance_id": item.instance_id, "tsk_id": item.tsk_id,
                          "categories": {name: category_label(item.features[name], name) for name in categorical_names}}
                         for item in instances]}


def _observation_fit_key(counts):
    # Labels, Missing counts and sample outcomes are attached by the parent;
    # only these sufficient statistics enter an otherwise identical fit.
    return tuple(sorted((row["chain_id"], row["n_tested"], row["n_failed"]) for row in counts))


_COMBINATION_TASK = ("combinations", "组合概率与区间")
_TERMINAL_TASK_STATES = {"completed", "skipped", "failed", "cancelled"}
_RESULT_MODULES = ("fit", "reference_risk", "type_intervals", "chain_members", "joint_risk", "feature_effects")


def _display_group_snapshot(observation, result, *, completed=False, combinations_pending=False):
    """Detach a usable preview without publishing the frozen fit or mutating it."""
    from .tsk_result_state import GROUP_FIELDS, compact_tsk_result, failed_sample_outcomes

    group = compact_tsk_result({"groups": [result]})["groups"][0]
    group.pop("saved_display_only", None)
    group.update({key: deepcopy(value) for key, value in observation.items() if key in GROUP_FIELDS})
    failures = failed_sample_outcomes(observation)
    if failures is not None:
        group["failed_sample_outcomes"] = deepcopy(failures)
    fitted = {row["chain_id"]: row for row in group.get("chains", [])}
    group["chains"] = [{**fitted.get(row["chain_id"], {}), **row}
                       for row in sorted(observation["counts"], key=lambda row: natural_sort_key(row["chain_id"]))]
    group.setdefault("types", [])
    completed_modules = list(_RESULT_MODULES) if completed else []
    if completed and result.get("combination_views"):
        completed_modules.insert(2, "combinations")
    group["completed_modules"] = list(result.get("completed_modules", completed_modules))
    group["analysis_status"] = result.get("analysis_status", "completed" if completed else "running")
    if combinations_pending and group["analysis_status"] == "completed":
        group["analysis_status"] = "running"
    return group


class _ActivityMonitor:
    """Transient task state: never stored with fitted data or numerical results."""

    def __init__(self, callback):
        self.callback = callback
        self.states = {}
        self.started = {}

    def __call__(self, event):
        if event.get("event") == "plan":
            for group in event.get("groups", []):
                for task in group.get("tasks", []):
                    self.states[(group["id"], task["id"])] = {
                        "event": "task", "group_id": group["id"], "task_id": task["id"],
                        "task_label": task["label"], "state": "queued", "progress": None,
                        "elapsed_seconds": 0., "message": "等待执行。"}
        elif event.get("event") == "task":
            key = (event["group_id"], event["task_id"])
            previous = self.states.get(key, {})
            if event.get("state") == "running" and (key not in self.started or
                    previous.get("attempt_id") != event.get("attempt_id")):
                self.started[key] = monotonic()
            self.states[key] = dict(event)
        self.callback(event)

    def abort(self, error):
        cancelled = isinstance(error, KeyboardInterrupt) or "cancel" in type(error).__name__.lower()
        for key, event in list(self.states.items()):
            if event["state"] in _TERMINAL_TASK_STATES:
                continue
            running = event["state"] == "running"
            self({**event, "state": "cancelled" if cancelled else "failed" if running else "skipped",
                  "elapsed_seconds": max(event["elapsed_seconds"], monotonic() - self.started[key])
                  if key in self.started else event["elapsed_seconds"],
                  "message": str(error) if running else "操作已取消。" if cancelled else "前置计算中断，本任务未执行。"})


def _with_activity_monitor(function):
    @wraps(function)
    def run(*args, **kwargs):
        callback = kwargs.get("activity_callback")
        if callback is None:
            return function(*args, **kwargs)
        monitor = _ActivityMonitor(callback)
        kwargs["activity_callback"] = monitor
        try:
            return function(*args, **kwargs)
        except BaseException as error:
            try:
                monitor.abort(error)
            except BaseException:
                pass  # Do not replace the original cancellation or failure.
            raise
    return run


def _task_event(callback, index, task, state, message, *, progress=None, elapsed_seconds=0., **counts):
    if callback is not None:
        callback({"event": "task", "group_id": str(index), "task_id": task[0], "task_label": task[1],
                  "state": state, "progress": progress, "elapsed_seconds": elapsed_seconds,
                  "message": str(message)[:512], **counts})


def _group_activity(callback, index):
    def forward(event):
        if callback is not None and event.get("event") == "task":
            callback({**event, "group_id": str(index),
                      "task_label": event.get("label", event.get("task_label", event["task_id"]))})
    return forward if callback is not None else None


def _worker_progress(heartbeat, task_definitions, *, include_results=False):
    """Keep every latest stage so a final heartbeat repairs dropped IPC updates."""
    tasks = {task_id: {"task_id": task_id, "label": label, "state": "queued", "progress": None,
                      "elapsed_seconds": 0., "message": "等待执行。"} for task_id, label in task_definitions}
    latest = {"progress": 0., "message": ""}

    def report(value, message):
        _job_progress(heartbeat, value, message, tasks=list(tasks.values()),
                      result_snapshot=latest.get("result_snapshot"),
                      result_sequence=latest.get("result_sequence"))

    def progress(value, message):
        latest.update(progress=value, message=message)
        report(value, message)

    def activity(event):
        tasks[event["task_id"]] = {key: event[key] for key in
            ("task_id", "label", "state", "progress", "elapsed_seconds", "message", "completed", "total")
            if key in event}
        tasks[event["task_id"]]["label"] = event.get("label", event.get("task_label", event["task_id"]))
        report(latest["progress"], event["message"])

    def result(snapshot):
        latest["result_snapshot"] = snapshot
        latest["result_sequence"] = latest.get("result_sequence", 0) + 1
        report(latest["progress"], latest["message"])

    progress.activity_callback = activity
    if include_results:
        progress.result_callback = result
    return progress


def _fit_observation_group(common, counts, heartbeat):
    from .tsk_analysis import analysis_tasks, TskChainObservation, analyze_tsk

    instances, options, *stream = common
    combination_settings = stream[1] if len(stream) > 1 else None
    observations = [TskChainObservation(chain, tested, failed) for chain, tested, failed in counts]
    # Automatic stages retain their timing probes. The coordinator context
    # supplies the live quota without changing saved scientific options.
    result = analyze_tsk(instances, observations, options,
                         progress_callback=_worker_progress(heartbeat,
                             analysis_tasks(combination_settings is not None),
                             include_results=bool(stream and stream[0])),
                         **({"combination_settings": combination_settings} if combination_settings is not None else {}))
    result.options = options
    return result.to_dict()


def _job_progress(heartbeat, value, message, *, tasks=None, result_snapshot=None, result_sequence=None):
    report = getattr(heartbeat, "detail", None)
    if report is None:
        heartbeat()
    else:
        report({"progress": value, "message": message, **({"tasks": tasks} if tasks is not None else {}),
                **({"result_snapshot": result_snapshot, "result_sequence": result_sequence}
                   if result_snapshot is not None else {})})


class _GroupProgress:
    """Parent-side labels and completed-group progress, independent of job %s."""

    def __init__(self, callback, labels, group_count, start, span, action, execution, activity_callback=None,
                 result_callback=None):
        self.callback, self.labels = callback, labels
        self.group_count, self.start, self.span = group_count, start, span
        self.action, self.execution = action, execution
        self.started = perf_counter()
        self.completed = 0
        self.latest = {}
        self.last_render = None
        self.activity_callback = activity_callback
        self.task_states = {}
        self.attempts = {}
        self.result_callback = result_callback
        self.result_versions = {}

    def detail(self, index, event):
        now = perf_counter()
        status = {key: value for key, value in event.items() if key not in {"result_snapshot", "result_sequence"}}
        self.latest[index] = (status, now)
        group_index, label = self.labels[index]
        self.execution.setdefault("group_progress", {})[str(index)] = {
            **{key: value for key, value in status.items() if key != "tasks"},
            "group_index": group_index, "label": label}
        version = (event.get("pid", "local"), event.get("result_sequence"))
        if (self.result_callback is not None and event.get("result_snapshot") is not None
                and self.result_versions.get(index) != version):
            self.result_versions[index] = version
            self.result_callback(index, event["result_snapshot"])
        if self.activity_callback is not None:
            attempt = str(event.get("pid", "local"))
            for task in event.get("tasks", []):
                key = (index, task["task_id"])
                if self.task_states.get(key) == task and self.attempts.get(key) == attempt:
                    continue
                self.task_states[key] = dict(task)
                self.attempts[key] = attempt
                self.activity_callback({"progress": None, "elapsed_seconds": 0., **task,
                    "event": "task", "group_id": str(group_index - 1),
                    "task_label": task.get("label", task["task_id"]), "group_label": label, "attempt_id": attempt})
        self._render(now)

    def progress(self, completed, total):
        now = perf_counter()
        changed = completed != self.completed
        self.completed = completed
        if changed or self.last_render is None or now - self.last_render >= 1.:
            self._render(now)

    def _render(self, now):
        self.last_render = now
        total = len(self.labels)
        message = (f"TSK：{self.action} · 已完成 {self.completed}/{total} 个唯一组"
                   f" · 总耗时 {now - self.started:.0f}s")
        plan = self.execution.get("hybrid_plan")
        if plan:
            state = self.execution.get("compute_budget", {})
            quotas = [str(group["quota"]) for group in state.get("groups", {}).values() if not group["done"]]
            message += (f" · 总计算预算 {plan['total_budget']} · 最多 {plan['group_workers']} 组并行"
                        f" · 计算槽 {state.get('used', 0)}/{plan['total_budget']}")
            if quotas:
                message += " · 活动组预算 " + "/".join(quotas)
        if self.execution.get("phase") == "starting":
            message += (f" · 正在启动计算进程 · 已就绪 {self.execution.get('startup_workers_ready', 0)}"
                        f"/{self.execution.get('workers_used', '?')}"
                        f" · 第 {self.execution.get('startup_attempts', 1)} 次启动")
        elif self.execution.get("execution_backend") == "serial_after_process_failure":
            message += " · 子进程不可用，当前串行继续（保留已完成结果）"
        active = [(received, index, event) for index, (event, received) in self.latest.items()
                  if event.get("phase") != "completed"]
        if active:
            received, index, event = max(active)
            group_index, label = self.labels[index]
            elapsed = event.get("elapsed_seconds", 0.) + max(0., now - received)
            message += f" · 组 {group_index}/{self.group_count} · {label} · 组内 {event.get('progress', 0.):.0f}%"
            message += f" · 该组已用 {elapsed:.0f}s · {event.get('message', '')}"
        self.callback(self.start + int(self.span * self.completed / max(1, total)), message)


@_with_activity_monitor
def analyze_tsk_workspace(*, template_path: str, source: str = "database", storage_path: str | None = None,
                          input_path: str | None = None, golden_path: str | None = None,
                          analysis_template: TemplateConfig | None = None,
                          analysis_snapshot_path: str | None = None,
                          include_all_combinations: bool = False,
                          settings: dict | None = None, progress_callback: Callable | None = None,
                          activity_callback: Callable | None = None,
                          result_callback: Callable | None = None) -> dict:
    """Fit completed Analyze states without reloading or reclassifying their source.

    ``result_callback`` receives one ``initial`` workspace event, followed by
    ``group`` events containing stable indices and cumulative display snapshots.
    Frozen fits remain private until the authoritative return value is ready.
    """
    from .tsk_analysis import analysis_tasks, TskInstance, TskChainObservation, TskAnalysisOptions, analyze_tsk
    from .template import validate_tsk_analysis_config
    from .tsk_spatial import DEFAULT_XY_MODEL, validate_xy_model

    options = dict(settings or {})
    validate_analysis_workers(options.get("analysis_workers", 0))
    node_mode = validate_node_mode(options.get("node_mode", "separate"))
    if include_all_combinations:
        options.setdefault("extrapolate", False)
    # Ignore retired controls, including stale or invalid fields in saved workspaces.
    for retired in ("group_by_dimensions", "fail_method", "classification_pool"):
        options.pop(retired, None)
    snapshot = read_analysis_snapshot(analysis_snapshot_path) if analysis_snapshot_path or source == "analyze" else None
    template = (template_for_snapshot(snapshot) if snapshot is not None else
                deepcopy(analysis_template) if analysis_template is not None else load_template(template_path))
    if not template.tsk_analysis.enabled:
        raise ValueError("请先在模板 tsk_analysis 设置中启用 TSK 分析并填写真实实例对应表；可先使用 examples/tsk_risk_demo 示例。")
    validate_tsk_analysis_config(template, require_instances=True)
    feature_model = options.get("feature_model", template.tsk_analysis.feature_model)
    if feature_model == "linear_hazard":
        raise ValueError("TSK feature_model 'linear_hazard' has been removed; change it to 'logistic' and rerun the analysis.")
    if feature_model != "logistic":
        raise ValueError("TSK feature_model must be 'logistic'.")
    xy_model = validate_xy_model(options.get("xy_model", getattr(template.tsk_analysis, "xy_model", DEFAULT_XY_MODEL)))
    progress = progress_callback or (lambda value, message: None)
    result_callback = result_callback or getattr(progress_callback, "result_callback", None)
    progress(3, "TSK：读取模板与测量数据…")
    if snapshot is not None:
        source = "analyze"
        rows = selected_snapshot_rows(snapshot, options)
        warnings = []
    else:
        # Every TSK node means New. Keep predecessors during classification,
        # including for a single selected node, to preserve Analyze's history.
        selection = {**options, "nodes": []}
        measurements, rows, warnings = _load_tsk_selection(template, source=source, storage_path=storage_path,
                                                           input_path=input_path, options=selection)
        from .reporting import analyze_outlier_report_from_measurements

        snapshot = analyze_outlier_report_from_measurements(
            template_path, measurements, built_golden_path=golden_path,
            analysis_template=template, input_rows=rows,
            zscore_threshold_override=template.report.zscore_thresholds.default,
            progress_callback=lambda value, message: progress(3 + int(value * .15), message),
        )
        template = template_for_snapshot(snapshot)
        rows = selected_snapshot_rows(snapshot, options)
    batch = _batch_settings(template, **{name: options[name] for name in
                            ("batch_mode", "batch_dimension", "batch_mapping") if name in options})
    progress(18, "TSK：读取 Analyze 已完成的链路判定结果…")
    observations = observations_from_snapshot(snapshot, template, rows, batch, node_mode=node_mode,
                                              node_groups=resolve_snapshot_node_groups(snapshot, options))
    if activity_callback is not None:
        activity_callback({"event": "plan", "groups": [
            {"id": str(index), "label": group["label"], "tasks": [
                {"id": task_id, "label": label} for task_id, label in analysis_tasks(True)]}
            for index, group in enumerate(observations)]})
        if not include_all_combinations:
            for index in range(len(observations)):
                _task_event(activity_callback, index, _COMBINATION_TASK, "skipped", "本次未请求组合概率与区间。")
    include_xy = bool(options.get("include_xy", template.tsk_analysis.use_xy))
    features = tuple(options.get("feature_names", template.tsk_analysis.feature_columns))
    undeclared = set(features) - set(template.tsk_analysis.feature_columns)
    if undeclared:
        raise ValueError("所选 TSK 特征未在模板 feature_columns 中声明：" + ", ".join(sorted(undeclared)))
    categorical_features = tuple(name for name in features if name in template.tsk_analysis.categorical_feature_columns)
    instances = [TskInstance(chain_id=i.chain_id, instance_id=i.tsk_instance_id, tsk_id=i.tsk_id,
                             x=i.x, y=i.y, features=dict(i.features)) for i in template.tsk_analysis.instances]
    fit_options = TskAnalysisOptions(use_xy=include_xy, feature_names=features, xy_model=xy_model,
                                    confidence_level=float(options.get("confidence_level", .95)),
                                    categorical_feature_names=categorical_features,
                                    feature_model=feature_model,
                                    logistic_coefficient_bound=options.get("logistic_coefficient_bound", 35.),
                                    feature_effects_mode=options.get("feature_effects_mode", "fixed_zero"),
                                    include_deletion_analysis=options.get("include_deletion_analysis", False),
                                    simulation_replicates=options.get("simulation_replicates", 999),
                                    simulation_seed=options.get("simulation_seed", 1729),
                                    simulation_workers=options.get("simulation_workers", 0),
                                    analysis_workers=options.get("analysis_workers", 0))
    combination_settings = ({"extrapolate": bool(options.get("extrapolate", False))}
                            if include_all_combinations else None)
    fit_arguments = ({"combination_settings": combination_settings} if include_all_combinations else {})
    fit_common = (instances, fit_options, result_callback is not None)
    if include_all_combinations:
        fit_common += (combination_settings,)
    # Source metadata stays stable while fitting consumes its own observations.
    # Keep preview counts separate: equivalent fits can have different Missing
    # counts, labels and batches and must update every original group in place.
    preview_observations = [dict(group) for group in observations] if result_callback is not None else []
    fit_aliases = defaultdict(list)
    if result_callback is not None:
        for group_index, group in enumerate(observations):
            fit_aliases[_observation_fit_key(group["counts"])].append(group_index)

    def publish_group(index, result, *, completed=False):
        if result_callback is None:
            return
        group = _display_group_snapshot(preview_observations[index], result, completed=completed,
            combinations_pending=bool(include_all_combinations and categorical_features
                                      and not result.get("combination_views")))
        result_callback({"event": "group", "group_index": index, "group": group})

    def publish_fit(key, result):
        for group_index in fit_aliases[key]:
            publish_group(group_index, result)

    if result_callback is not None:
        initial_groups = [_display_group_snapshot(group, {
            "options": asdict(fit_options), "analysis_status": "queued", "completed_modules": [],
            "feature_effects": {"status": "pending", "features": [], "reason": "该模块尚未完成。"},
            "joint_risk": {"status": "pending", "rows": []}}) for group in preview_observations]
        result_callback({"event": "initial", "payload": {
            "groups": initial_groups, "analysis_status": "running",
            "topology": [asdict(item) for item in sorted(template.tsk_analysis.instances,
                key=lambda item: (natural_sort_key(item.chain_id), natural_sort_key(item.tsk_instance_id)))],
            "warnings": list(dict.fromkeys([*warnings, *(warning for group in observations
                for warning in group.get("classification_warnings", []))])),
            "provenance": {"source": source, "analysis_rule_source": "analyze_result",
                "settings": {**options, **batch, "node_mode": node_mode, "include_xy": include_xy,
                    "feature_names": list(features), "categorical_feature_names": list(categorical_features),
                    "feature_model": feature_model, "xy_model": xy_model},
                "template_snapshot": {"tsk_analysis": {
                    "feature_columns": list(features), "categorical_feature_columns": list(categorical_features)}}}}})
    results = []
    fit_progress_span = 69 if include_all_combinations else 65
    remaining_fits = Counter(_observation_fit_key(group["counts"]) for group in observations
                             if any(row["n_tested"] for row in group["counts"]))
    unique_counts = list(remaining_fits)
    group_labels = {}
    for group_index, group in enumerate(observations, 1):
        group_labels.setdefault(_observation_fit_key(group["counts"]), (group_index, group["label"]))
    type_count = len({item.tsk_id for item in instances})
    # Large simulations already fill the worker budget within a single group.
    # Small ordinary fits stay local to avoid paying more for spawn than fitting.
    substantial_groups = bool((include_xy or features) and (
        type_count * len(unique_counts) >= 12 or len(instances) * len(unique_counts) >= 500))
    prefer_simulations = (fit_options.include_deletion_analysis and fit_options.feature_effects_mode == "boundary_simulation"
                          and fit_options.simulation_replicates >= 16
                          and len(unique_counts) < 4 and fit_options.simulation_workers != 1)
    threshold = 2 if substantial_groups and not prefer_simulations else len(unique_counts) + 1
    candidate_workers = worker_count(fit_options.analysis_workers, len(unique_counts), threshold)
    # Many substantial groups already amortize spawn. Waiting for their first
    # full fit can idle the whole budget for hours. Smaller automatic batches
    # still measure and retain a real pilot; explicit selections bypass it.
    total_budget = limit_process_workers(automatic_tsk_budget(
        process_limit=fit_options.analysis_workers or None))
    direct_groups = bool(unique_counts) and total_budget > 1 and (
        substantial_groups or fit_options.analysis_workers > 1 or prefer_simulations)
    fitted_groups = {}
    group_execution = None
    if direct_groups:
        group_execution = {}
        group_progress = _GroupProgress(progress, [group_labels[key] for key in unique_counts],
            len(observations), 30, fit_progress_span, "并行分析节点／批次", group_execution, activity_callback,
            result_callback=lambda index, result: publish_fit(unique_counts[index], result))
        fitted = ordered_group_map(_fit_observation_group, unique_counts,
            common=fit_common,
            total_budget=total_budget, execution=group_execution,
            progress_callback=group_progress.progress, detail_callback=group_progress.detail)
        group_execution.update(workers_requested=fit_options.analysis_workers,
            scheduling_reason="hybrid_substantial_groups" if not fit_options.analysis_workers else "hybrid_explicit_budget")
        fitted_groups.update(zip(unique_counts, fitted))
        del fitted
        warnings.extend(group_execution["execution_warnings"])
    for index, observation in enumerate(observations):
        group_progress_label = f"TSK：组 {index + 1}/{len(observations)} · {observation['label']}"
        if group_execution is None:
            progress(30 + int(fit_progress_span * index / max(1, len(observations))), f"{group_progress_label} · 开始拟合…")
        counts = sorted(observation.pop("counts"), key=lambda row: natural_sort_key(row["chain_id"]))
        warnings.extend(observation.pop("classification_warnings", []))
        all_observations = [TskChainObservation(c["chain_id"], c["n_tested"], c["n_failed"]) for c in counts]
        if any(item.n_tested for item in all_observations):
            fit_key = _observation_fit_key(counts)
            if fit_key not in fitted_groups:
                started = monotonic()
                automatic_groups = (fit_options.analysis_workers == 0 and candidate_workers > 1
                                    and sum(count > 0 for count in remaining_fits.values()) >= 3)
                # This pilot runs in the parent before any outer group pool.
                # Its own adaptive queries may use the available worker budget;
                # analyze_tsk closes those sessions before returning. Later
                # admitted coordinators share their budget with leaf workers.
                def local_progress(value, message):
                    progress(
                        30 + int(fit_progress_span * (index + value / 100) / max(1, len(observations))),
                        f"{group_progress_label} · {message}")
                local_progress.activity_callback = _group_activity(activity_callback, index)
                if result_callback is not None:
                    local_progress.result_callback = lambda result, key=fit_key: publish_fit(key, result)
                fitted_result = analyze_tsk(instances, all_observations, fit_options,
                                           progress_callback=local_progress, **fit_arguments)
                elapsed = monotonic() - started
                fitted_result.options = fit_options
                fitted_groups[fit_key] = fitted_result.to_dict()
                if automatic_groups and elapsed >= 1.:
                    pending_counts = [key for key in unique_counts
                                      if remaining_fits[key] and key not in fitted_groups]
                    remaining_workers = worker_count(0, len(pending_counts))
                    if remaining_workers > 1:
                        group_execution = {}
                        group_start = 30 + int(fit_progress_span * (index + 1) / len(observations))
                        group_progress = _GroupProgress(progress, [group_labels[key] for key in pending_counts],
                            len(observations), group_start, 30 + fit_progress_span - group_start,
                            "并行分析剩余节点／批次", group_execution, activity_callback,
                            result_callback=lambda index, result: publish_fit(pending_counts[index], result))
                        fitted = ordered_group_map(_fit_observation_group, pending_counts,
                            common=fit_common,
                            total_budget=total_budget, execution=group_execution,
                            progress_callback=group_progress.progress, detail_callback=group_progress.detail)
                        group_execution.update(workers_requested=0, pilot_fit_seconds=elapsed,
                                               pilot_groups_completed=index + 1)
                        fitted_groups.update(zip(pending_counts, fitted))
                        del fitted
                        warnings.extend(group_execution["execution_warnings"])
            remaining_fits[fit_key] -= 1
            result = (deepcopy(fitted_groups[fit_key]) if remaining_fits[fit_key]
                      else fitted_groups.pop(fit_key))
            if group_labels[fit_key][0] != index + 1:
                for task in analysis_tasks(include_all_combinations):
                    _task_event(activity_callback, index, task, "skipped",
                        f"有效 Chain 计数相同，复用组 {group_labels[fit_key][0]} 的计算结果（包括其可用性判定）；本组未重复计算。")
        else:
            for task in analysis_tasks():
                _task_event(activity_callback, index, task, "skipped", "本组没有有效 Chain 观测；未拟合或计算推断。")
            type_names = sorted({item.tsk_id for item in instances}, key=natural_sort_key)
            result = {"types": [{"tsk_id": name, "probability": None, "ci_lower": None, "ci_upper": None,
                                  "identifiable": False, "status": "no_data", "interval_method": None,
                                  "instance_count": sum(item.tsk_id == name for item in instances), "test_exposure": 0}
                                 for name in type_names],
                      "chains": [], "options": asdict(fit_options),
                      "feature_effects": {"version": 1, "status": "no_data", "features": [],
                                          "confidence_level": fit_options.confidence_level,
                                          "reason": "本组没有有效 Chain 观测，无法检验特征影响。"},
                      "diagnostics": {"converged": False, "rank": 0, "parameter_count": len(type_names),
                                      "chain_count": 0, "confidence_level": fit_options.confidence_level,
                                      "interval_method": None, "reference_environment": None,
                                      "model": f"instance_{feature_model}_features" if include_xy or features else "type_only",
                                      "warnings": ["本组所有 Chain 状态均为 Missing，未拟合。"]},
                      "joint_risk": {"version": 1, "status": "no_data", "rows": [], "omitted_count": 0,
                                     "notes": ["本组没有有效 Chain 观测，联合风险留空。"]}}
            if categorical_features or (include_xy and xy_model == DEFAULT_XY_MODEL):
                numeric_names = tuple(dict.fromkeys(("x", "y") + features)) if include_xy else features
                result["prediction_context"] = _empty_prediction_context(
                    instances, categorical_features, numeric_names, fit_options)
                context = result["prediction_context"]
                result["diagnostics"].update(
                    xy_model=xy_model if include_xy else None,
                    spatial_transform=context.get("spatial_transform"),
                    feature_groups=context.get("feature_groups", {}),
                    parameter_count=len(context["coefficients"]))
            if include_all_combinations:
                if categorical_features:
                    from .tsk_prediction import ALL_CATEGORY_COMBINATIONS

                    grid_progress = (30 + int(fit_progress_span * index / max(1, len(observations)))
                                     if group_execution is None else 30 + fit_progress_span)
                    view = _run_combination_query(context,
                        lambda value, message: progress(grid_progress, f"{group_progress_label} · {message}"),
                        activity_callback, group_index=index,
                        dimension=ALL_CATEGORY_COMBINATIONS, extrapolate=combination_settings["extrapolate"],
                        analysis_workers=fit_options.analysis_workers)
                    result["combination_views"] = [_stamp_combination_view(context, view)]
                else:
                    _task_event(activity_callback, index, _COMBINATION_TASK, "skipped", "本组没有类别组合拟合快照。")
        fitted = {c["chain_id"]: c for c in result["chains"]}
        result["chains"] = [{**c, **fitted.get(c["chain_id"], {
            "status": "no_data", "observed_probability": None, "predicted_probability": None,
            "residual": None, "deviance_residual": None,
        })} for c in counts]
        if not any(item.n_tested for item in all_observations):
            from .tsk_chain_members import build_chain_members

            members = build_chain_members(instances, result["chains"], result["types"],
                feature_names=features, categorical_feature_names=categorical_features, use_xy=include_xy)
            for chain_row in result["chains"]:
                chain_row["members"] = members.get(chain_row["chain_id"], [])
        results.append({**observation, **result})
        publish_group(index, results[-1], completed=True)
    import numpy, scipy
    template_snapshot = template_to_payload(template)
    snapshot_hash = hashlib.sha256(json.dumps(template_snapshot, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    provenance = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(), "source": source,
        "template_path": str(Path(template_path).resolve()),
        "template_sha256": (hashlib.sha256(Path(template_path).read_bytes()).hexdigest()
                            if source != "analyze" and Path(template_path).is_file() else None),
        "template_snapshot_sha256": snapshot_hash,
        "input_path": input_path, "storage_path": storage_path, "golden_path": golden_path,
        "settings": {**options, **batch, "node_mode": node_mode, "include_xy": include_xy, "feature_names": list(features),
                     "xy_model": xy_model,
                     "categorical_feature_names": list(categorical_features), "feature_model": feature_model,
                     "logistic_coefficient_bound": fit_options.logistic_coefficient_bound,
                     "feature_effects_mode": fit_options.feature_effects_mode,
                     "include_deletion_analysis": fit_options.include_deletion_analysis,
                     "simulation_replicates": fit_options.simulation_replicates,
                     "simulation_seed": fit_options.simulation_seed,
                     "simulation_workers": fit_options.simulation_workers,
                     "analysis_workers": fit_options.analysis_workers},
        "analysis_rule_source": "analyze_result",
        "analysis_result": deepcopy(snapshot["result"]),
        "analysis_rules": {
            "outlier_fail_method": template.report.outlier_fail_method,
            "zscore_use_golden_reference": template.report.zscore_use_golden_reference,
            "zscore_threshold_override": template.report.zscore_thresholds.default,
            "outlier_treat_empty_cells_as_fail": template.report.outlier_treat_empty_cells_as_fail,
            "initial_column_merge_fail_rule": template.report.outlier_merged_test_fail_rule,
            "final_column_merge_fail_rule": template.report.outlier_test_group_fail_rule,
            "initial_row_merge_fail_rule": template.report.outlier_merged_sample_fail_rule,
            "final_row_merge_fail_rule": template.report.outlier_node_fail_rule,
        },
        "merge_order": template.report.outlier_merge_order,
        "missing_policy": "遵循 Analyze 空值规则：启用空值为 Fail 时直接计 Fail；关闭时跳过空单元格。有剩余测量按相同合并规则判定，样品/节点/Chain 无剩余 leaf 才为 Missing 并排除有效分母。",
        "observation_semantics": "new_failures_terminal_cohort_v1",
        "classification_scope": (
            "直接使用已完成 Analyze 的 New 标记；默认逐节点分析新增失效，可排除节点。"
            "每组仅纳入末节点的样品及该节点有有效判定的 Chain；组内任一节点为 New 则计 Fail，"
            "否则计 Pass（未新增，含 Existed / Recovered）。末节点缺失计 Missing 并排除有效分母。"
            "同一原批次、唯一样品、Chain 在组内只计一次，未到达末节点的样品不计入分子或分母。"
            "节点选择不重算 New / Existed，不恢复 Analyze 已排除的链路。"),
        "numpy_version": numpy.__version__, "scipy_version": scipy.__version__,
        "template_snapshot": template_snapshot,
    }
    if group_execution is not None:
        provenance["parallel_execution"] = {"groups": group_execution}
    if batch["batch_mode"] == "parent":
        warnings.append("母批将成员原批的有效 Fail/Pass 计数合并后重新拟合，假设同一母批、节点分析范围内共享 TSK 风险；合并本身不会消除批间风险差异。")
    elif batch["batch_mode"] == "none" and any(len(group.get("source_batches", [])) > 1 for group in results):
        warnings.append("不分层：所有所选原批按节点分析范围汇总有效 Fail/Pass 计数后拟合，假设该范围内共享 TSK 风险；混合本身不会消除批间风险差异。")
    warnings.append("区间按模型中的独立观测假设计算；同一 die 多链共同异常可能使区间偏窄。结果是基于串联假设的风险估计。")
    payload = {"groups": results, "topology": [asdict(i) for i in sorted(
                   template.tsk_analysis.instances, key=lambda item: (natural_sort_key(item.chain_id),
                                                                     natural_sort_key(item.tsk_instance_id)))],
               "warnings": list(dict.fromkeys(warnings)), "provenance": provenance}
    progress(100, "基于 Analyze 结果的 TSK 分析完成。")
    return payload


def _run_combination_query(context, progress_callback, activity_callback, *, group_index=0, **query):
    from .tsk_prediction import predict_tsk_combinations

    started = monotonic()
    last_report = None
    _task_event(activity_callback, group_index, _COMBINATION_TASK, "running", "计算组合概率与区间。", progress=0.)

    def progress(value, message):
        nonlocal last_report
        now = monotonic()
        if last_report is None or now - last_report >= 1.:
            _task_event(activity_callback, group_index, _COMBINATION_TASK, "running", message,
                progress=value, elapsed_seconds=now - started)
            last_report = now
        if progress_callback is not None:
            progress_callback(value, message)

    try:
        view = predict_tsk_combinations(deepcopy(context), progress_callback=progress, **query)
    except BaseException as error:
        cancelled = isinstance(error, KeyboardInterrupt) or "cancel" in type(error).__name__.lower()
        try:
            _task_event(activity_callback, group_index, _COMBINATION_TASK, "cancelled" if cancelled else "failed",
                str(error) or type(error).__name__, elapsed_seconds=monotonic() - started)
        except BaseException:
            pass
        raise
    rows = view.get("rows", [])
    no_data = not rows or all(row.get("status") == "no_data" for row in rows)
    failed = any(row.get("interval_error") or row.get("status") in {"unavailable", "fit_not_converged", "interval_unavailable"}
                 for row in rows)
    state = "skipped" if no_data else "failed" if failed else "completed"
    _task_event(activity_callback, group_index, _COMBINATION_TASK, state,
        "本组没有可计算的组合观测；结果保留为空。" if no_data else
        "组合遍历完成，部分概率或区间未通过计算；具体原因保留在结果中。" if failed else
        "组合概率与区间计算结束；无数据和不可识别的组合保持留空。",
        progress=100. if state == "completed" else None, elapsed_seconds=monotonic() - started,
        completed=len(rows), total=len(rows))
    return view


@_with_activity_monitor
def analyze_tsk_combinations(payload: dict, *, group_index: int, settings: dict,
                             progress_callback: Callable | None = None,
                             activity_callback: Callable | None = None) -> dict:
    """Query a frozen fit without re-reading input, labels, or Analyze controls."""
    groups = payload.get("groups", [])
    if isinstance(group_index, bool) or not isinstance(group_index, int) or not 0 <= group_index < len(groups):
        raise ValueError("请选择有效的 TSK 节点 / 批次结果。")
    if activity_callback is not None:
        activity_callback({"event": "plan", "groups": [{"id": str(group_index),
            "label": groups[group_index].get("label", f"组 {group_index + 1}"),
            "tasks": [{"id": _COMBINATION_TASK[0], "label": _COMBINATION_TASK[1]}]}]})
    context = groups[group_index].get("prediction_context")
    if not context:
        _task_event(activity_callback, group_index, _COMBINATION_TASK, "failed", "本组没有类别组合拟合快照。")
        raise ValueError("该结果没有类别组合拟合快照，请选中类别特征后重新运行 TSK 分析。")
    options = deepcopy(settings)
    analysis_workers = options.get("analysis_workers", groups[group_index].get("options", {}).get("analysis_workers", 0))
    view = _run_combination_query(
        context, progress_callback, activity_callback, group_index=group_index, dimension=options.get("dimension"),
        fixed_categories=options.get("fixed_categories"), reference_level=options.get("reference_level"),
        tsk_ids=options.get("tsk_ids"), extrapolate=options.get("extrapolate", True),
        analysis_workers=analysis_workers,
    )
    return {"group_index": group_index, "view": _stamp_combination_view(context, view)}


def _stamp_combination_view(context, view):
    from .tsk_prediction import stamp_combination_view

    return stamp_combination_view(context, view)


def store_tsk_combination_view(payload: dict, group_index: int, view: dict) -> None:
    """Keep each computed slice once; put the latest slice last for restoration."""
    group = payload["groups"][group_index]
    views = [item for item in group.get("combination_views", []) if item.get("query_key") != view.get("query_key")]
    group["combination_views"] = [*views, deepcopy(view)]


def export_tsk_result(payload: dict, output_path: str) -> str:
    """Export fitted results, missing counts, paired observations and provenance."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from .tsk_boundary_display import boundary_limit, effect_level_boundary_row
    import os
    import tempfile

    target = Path(output_path)
    if target.suffix.lower() != ".xlsx":
        target = target.with_suffix(".xlsx")
    target.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    workbook.remove(workbook.active)

    def display_limits(record, display_row=None):
        # Numeric columns remain usable for analysis. Adjacent display columns
        # make JSON-safe boundary metadata readable without pretending infinity
        # is a finite estimate, or replacing missing inference with zero.
        display_row = record if display_row is None else display_row
        labels = {"negative_infinity": "−∞", "positive_infinity": "+∞", "zero": "0",
                  "undefined": "未定义", "undetermined": "方向未确定"}
        result = {}
        for key, value in record.items():
            result[key] = value
            if key in {"coefficient", "difference", "odds_ratio"}:
                result[key + "_display"] = labels.get(boundary_limit(display_row, key), value)
        return result

    def sheet(name, records, columns=None):
        ws = workbook.create_sheet(name)
        columns = columns or list(dict.fromkeys(key for row in records for key in row))
        ws.append(columns or ["No data"])
        for row_index, record in enumerate(records, 2):
            for column_index, key in enumerate(columns, 1):
                value = record.get(key)
                if isinstance(value, (dict, list, tuple)):
                    value = json.dumps(value, ensure_ascii=False, allow_nan=False)
                if isinstance(value, float) and not math.isfinite(value):
                    value = None
                cell = ws.cell(row_index, column_index, value)
                if isinstance(value, str):
                    cell.data_type = "s"
                if name not in {"Feature Levels", "Feature Contrasts", "TSK Type Levels", "TSK Type Contrasts"} and key in {"probability", "ci_lower", "ci_upper", "observed_probability", "predicted_probability", "residual",
                           "delta_probability", "delta_ci_lower", "delta_ci_upper", "reference_probability"}:
                    cell.number_format = ("0.00E+00%" if name == "Joint Risk" and isinstance(value, (int, float))
                                          and 0 < abs(value) < 5e-5 else "0.00%")
                if key in {"p_value", "p_adjusted"}:
                    cell.number_format = "0.0000E+00"
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="355C7D")
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for column in ws.columns:
            ws.column_dimensions[column[0].column_letter].width = min(65, max(15, max(len(str(c.value or "")) for c in column) + 2))

    def diagnostic_parts(value):
        from .tsk_analysis import _plain

        value = _plain(value)
        if isinstance(value, (dict, list, tuple)):
            value = json.dumps(value, ensure_ascii=False, allow_nan=False)
        if not isinstance(value, str):
            return [value]
        # Excel's cell limit is measured in UTF-16 units. Splitting on Python
        # character boundaries preserves astral Unicode characters as well.
        pieces, start, units = [], 0, 0
        for index, character in enumerate(value):
            width = 2 if ord(character) > 0xFFFF else 1
            if units + width > 30000:
                pieces.append(value[start:index])
                start, units = index, 0
            units += width
        return [*pieces, value[start:]]

    type_rows, chain_rows, diagnostic_rows, sample_rows, batch_rows = [], [], [], [], []
    combination_rows, contrast_rows, view_rows, fit_rows, view_details = [], [], [], [], []
    feature_coefficient_rows, feature_risk_rows = [], []
    joint_rows, joint_report_rows = [], []
    chain_member_rows, chain_member_details = [], []
    effect_report_rows, effect_test_rows, effect_level_rows, effect_pair_rows, effect_deletion_rows = [], [], [], [], []
    type_effect_level_rows, type_effect_pair_rows = [], []
    effect_simulation_rows = []
    from .tsk_feature_summary import summarize_tsk_features

    for group_index, group in enumerate(payload.get("groups", [])):
        prefix = {"group": group["label"], "node": group["node"], "stratum": group.get("stratum", {})}
        prefix.update({name: group[name] for name in
                       ("node_mode", "source_nodes", "denominator_node", "node_group_index") if name in group})
        if group.get("source_batches"):
            prefix.update({key: group.get(key) for key in
                           ("batch_mode", "batch_dimension", "parent_batch_id", "source_batches")})
        diagnostics = group.get("diagnostics", {})
        context = group.get("prediction_context") or {}
        model = diagnostics.get("model", context.get("model", "type_only"))
        categorical = context.get("categorical_features", diagnostics.get("categorical_features", {}))
        numeric = context.get("numeric_reference", {
            name: values.get("mean") for name, values in diagnostics.get("feature_scaling", {}).items()})
        risk_conditions = {"categories": {name: value["reference"] for name, value in categorical.items()},
                           "numeric": numeric}
        reference_environment = ("本模型未选择特征；表示所选节点/条件下的共同 TSK 风险。" if model == "type_only" else
                                 "条件风险：类别固定为所列基准、数值固定为所列布局均值；不是各实例概率的平均值。")
        type_rows.extend({**prefix, **row, "model": model, "risk_conditions": risk_conditions,
                          "reference_environment": reference_environment} for row in group.get("types", []))
        feature_summary = summarize_tsk_features(group)
        feature_prefix = {**prefix, "model": feature_summary["model"], "formula": feature_summary["formula"]}
        feature_coefficient_rows.extend({**feature_prefix, **display_limits(row)} for row in feature_summary["coefficients"])
        feature_risk_rows.extend({**feature_prefix, **row} for row in feature_summary["risks"])
        effects = group.get("feature_effects")
        if isinstance(effects, dict):
            effect_report_rows.append({**prefix, **{key: value for key, value in effects.items() if key not in {"features", "type_effects"}}})
            joint_profile = (effects.get("inference_mode") == "joint_boundary_profile_likelihood" or
                (effects.get("methods") or {}).get("coefficient_interval") ==
                "joint_full_nuisance_profile_lr_chi_square_1_reference")
            joint_effects = (joint_profile or effects.get("inference_mode") == "joint_boundary_descriptive" or
                (effects.get("methods") or {}).get("contrast_identifiability") ==
                "joint_logistic_full_nuisance_profile_verified_contrast")
            joint_metadata = ({"inference_mode": effects.get("inference_mode"),
                               "interval_scope": "no_calibrated_coefficient_intervals",
                               "p_adjustment": "unavailable_at_joint_boundary"} if joint_effects else {})
            profile_metadata = ({"interval_scope": "pointwise_profile_lr_chi_square_1_reference",
                                 "p_adjustment": "holm_reference_unavailable_as_one",
                                 "inference_calibration": "chi_square_1_reference_not_boundary_calibrated",
                                 "inference_method": "joint_full_nuisance_profile_likelihood_ratio",
                                 "contrast_interval_method": (effects.get("methods") or {}).get("coefficient_interval"),
                                 "contrast_test_method": (effects.get("methods") or {}).get("pairwise_test")}
                                if joint_profile else {})
            for effect in effects.get("features", []):
                effect_prefix = {**prefix, "feature": effect.get("feature"), "kind": effect.get("kind"),
                                 "reference_level": effect.get("reference_level"),
                                 "confidence_level": effects.get("confidence_level"),
                                 "interval_scope": "pointwise", "p_adjustment": "Holm"}
                if effects.get("inference_mode") == "fixed_zero_conditional":
                    effect_prefix.update({"inference_mode": effects["inference_mode"],
                        "fixed_zero_tsk_ids": effects.get("fixed_zero_tsk_ids", []),
                        "assumption_warning": effects.get("assumption_warning"),
                        "interval_scope": "conditional_pointwise",
                        "effect_scope": "其余 TSK 的共享特征效应；OR 不适用于固定零风险 TSK"})
                if effects.get("inference_mode") == "free_boundary_simulation":
                    effect_prefix.update({key: effects.get(key) for key in
                        ("inference_mode", "calibration_status", "experimental_warning", "simulation_settings")})
                    effect_prefix["interval_scope"] = "no_calibrated_coefficient_intervals"
                effect_prefix.update(joint_metadata)
                deletion = effect.get("deletion_impact") or {}
                lrt = effect.get("lrt") or {}
                simulation = lrt.get("simulation")
                simulation_summary = {}
                if isinstance(simulation, dict):
                    parts = diagnostic_parts(simulation)
                    effect_simulation_rows.extend({**effect_prefix, "part": index + 1, "parts": len(parts), "value": part}
                                                  for index, part in enumerate(parts))
                    simulation_summary = {"simulation_" + key: value for key, value in simulation.items()
                                          if not isinstance(value, (list, dict, tuple))}
                    simulation_summary["simulation_details_sheet"] = "Feature Simulation Details"
                effect_test_rows.append({**effect_prefix, **{key: value for key, value in lrt.items() if key != "simulation"},
                    **simulation_summary,
                    "mean_abs_probability_change": deletion.get("mean_abs_probability_change"),
                    "max_abs_probability_change": deletion.get("max_abs_probability_change"),
                    "deletion_status": deletion.get("status"), "deletion_reason": deletion.get("reason")})
                effect_level_rows.extend({**effect_prefix, **profile_metadata, **display_limits(row)} for row in effect.get("levels", []))
                effect_pair_rows.extend({**effect_prefix, **profile_metadata, **display_limits(row)} for row in effect.get("pairwise", []))
                deletion_metadata = {key: value for key, value in deletion.items() if key != "by_tsk"}
                effect_deletion_rows.append({**effect_prefix, "scope": "all_active_instances", **deletion_metadata})
                effect_deletion_rows.extend({**effect_prefix, "scope": "tsk_active_instances",
                    "weighting": deletion.get("weighting"), **row} for row in deletion.get("by_tsk", []))
            type_effect = effects.get("type_effects")
            if isinstance(type_effect, dict) and type_effect:
                type_prefix = {**prefix, "role": "tsk_type", "reference_level": type_effect.get("reference_level"),
                    "confidence_level": effects.get("confidence_level"), "interval_scope": "pointwise",
                    "p_adjustment": "Holm", "comparison_scope": "相同特征条件下的 TSK 类型截距差；来自同一次联合拟合，不逐对重拟合",
                    "type_effect_status": type_effect.get("status"), "type_effect_reason": type_effect.get("reason")}
                type_prefix.update({key: type_effect[key] for key in
                    ("pairwise_count", "computed_pairwise_count", "computed_point_pairwise_count",
                     "computed_reference_interval_count", "pairwise_limit", "pairwise_omitted_count")
                    if key in type_effect})
                if effects.get("inference_mode") == "fixed_zero_conditional":
                    type_prefix.update({"inference_mode": effects["inference_mode"],
                        "fixed_zero_tsk_ids": effects.get("fixed_zero_tsk_ids", []),
                        "assumption_warning": effects.get("assumption_warning"), "interval_scope": "conditional_pointwise",
                        "effect_scope": "未固定零风险的 TSK 之间的截距比较；固定零风险 TSK 不提供有限 log odds 或 OR 区间"})
                if effects.get("inference_mode") == "free_boundary_simulation":
                    type_prefix.update({key: effects.get(key) for key in
                        ("inference_mode", "calibration_status", "experimental_warning", "simulation_settings")})
                    type_prefix["interval_scope"] = "no_calibrated_coefficient_intervals"
                type_prefix.update(joint_metadata)
                type_prefix.update(profile_metadata)
                if joint_effects:
                    type_prefix["comparison_scope"] = ("相同特征条件下的 TSK 类型截距差；点值来自同一次联合拟合，各对比保留全部干扰参数自由并逐项剖面复核；"
                        + ("区间与 p 仅采用 χ²₁ 渐近参考，Holm 按预设 TSK 对比族调整，边界覆盖率与检验大小未经校准" if joint_profile else
                           "不提供未经校准的区间或显著性"))
                type_effect_level_rows.extend({**type_prefix, **display_limits(row, effect_level_boundary_row(type_effect, row))}
                                              for row in type_effect.get("levels", []))
                type_effect_pair_rows.extend({**type_prefix, **display_limits(row)} for row in type_effect.get("pairwise", []))
        for row in group.get("chains", []):
            chain_rows.append({**prefix, **{key: value for key, value in row.items() if key != "members"}})
            for member_index, member in enumerate(row.get("members", []), 1):
                member_prefix = {**prefix, "group_index": group_index, "chain_id": row["chain_id"],
                                 "member_index": member_index}
                summary = dict(member)
                for key, value in summary.items():
                    if isinstance(value, (dict, list, tuple, str)):
                        chunks = diagnostic_parts(value)
                        if len(chunks) > 1:
                            summary[key] = chunks[0] + "… [完整内容见 Chain Member Details]"
                chain_member_rows.append({**member_prefix, **summary})
                pieces = diagnostic_parts(member)
                chain_member_details.extend({**member_prefix, "part": index + 1, "parts": len(pieces), "value": piece}
                                            for index, piece in enumerate(pieces))
        for key, value in group.get("diagnostics", {}).items():
            pieces = diagnostic_parts(value)
            diagnostic_rows.extend({**prefix, "item": key, "value": piece,
                                    "group_index": group_index, "part": index + 1, "parts": len(pieces)}
                                   for index, piece in enumerate(pieces))
        joint = group.get("joint_risk")
        if isinstance(joint, dict):
            pieces = diagnostic_parts(joint)
            joint_report_rows.extend({**prefix, "group_index": group_index, "part": index + 1,
                                      "parts": len(pieces), "value": piece}
                                     for index, piece in enumerate(pieces))
            for row in joint.get("rows", []):
                summary = {key: value for key, value in row.items() if key != "certificate"}
                # The complete report, including topology certificates and long
                # member lists, is losslessly chunked in Joint Risk Details.
                for key, value in summary.items():
                    if isinstance(value, (dict, list, tuple, str)):
                        chunks = diagnostic_parts(value)
                        if len(chunks) > 1:
                            summary[key] = chunks[0] + "… [完整内容见 Joint Risk Details]"
                joint_rows.append({**prefix, "group_index": group_index, **summary})
        sample_rows.extend({**prefix, **row} for row in group.get("sample_outcomes", []))
        batch_rows.extend({**prefix, **row} for row in group.get("batch_counts", []))
        for view_index, view in enumerate(group.get("combination_views", []), 1):
            view_prefix = {**prefix, "view_id": view_index,
                           **{key: view.get(key) for key in ("dimension", "reference_level", "fixed_categories",
                                                            "numeric_reference", "confidence_level", "extrapolate")}}
            metadata = {key: value for key, value in view.items() if key != "rows"}
            summary = dict(metadata)
            for key, value in summary.items():
                if isinstance(value, (dict, list, tuple, str)):
                    pieces = diagnostic_parts(value)
                    if len(pieces) > 1:
                        summary[key] = pieces[0] + "… [完整内容见 Combination View Details]"
            view_rows.append({**view_prefix, **summary})
            pieces = diagnostic_parts(metadata)
            view_details.extend({**prefix, "group_index": group_index, "view_id": view_index,
                                 "part": index + 1, "parts": len(pieces), "value": piece}
                                for index, piece in enumerate(pieces))
            for row in view.get("rows", []):
                combination_rows.append({**view_prefix, **{key: value for key, value in row.items()
                                                          if not key.startswith("delta_") and key != "reference_probability"}})
                contrast_rows.append({**view_prefix, **{key: value for key, value in row.items()
                    if key.startswith("delta_") or key in {"tsk_id", "level", "categories", "reference_probability",
                                                           "support_status", "chain_count", "chain_test_exposure"}}})
        context = group.get("prediction_context")
        if context and not group.get("saved_display_only"):
            pieces = diagnostic_parts(context)
            fit_rows.extend({"group_index": group_index, **prefix, "part": index + 1, "parts": len(pieces), "value": piece}
                            for index, piece in enumerate(pieces))
    sheet("TSK Risk", type_rows)
    sheet("Chain Fit", chain_rows)
    if chain_member_rows:
        sheet("Chain Members", chain_member_rows)
        sheet("Chain Member Details", chain_member_details)
    sheet("Diagnostics", diagnostic_rows)
    sheet("Topology", payload.get("topology", []))
    sheet("Sample Outcomes", sample_rows)
    if batch_rows:
        sheet("Batch Counts", batch_rows)
    if view_rows:
        sheet("Combination Risk", combination_rows)
        sheet("Category Contrasts", contrast_rows)
        sheet("Combination Views", view_rows)
        sheet("Combination View Details", view_details)
    if feature_coefficient_rows:
        sheet("Feature Coefficients", feature_coefficient_rows)
    if feature_risk_rows:
        sheet("Feature Risk", feature_risk_rows)
    if effect_report_rows:
        sheet("Feature Effect Reports", effect_report_rows)
        sheet("Feature Tests", effect_test_rows)
        sheet("Feature Levels", effect_level_rows)
        sheet("Feature Contrasts", effect_pair_rows)
        sheet("Feature Deletion", effect_deletion_rows)
    if type_effect_level_rows:
        sheet("TSK Type Levels", type_effect_level_rows)
    if type_effect_pair_rows:
        sheet("TSK Type Contrasts", type_effect_pair_rows)
    if effect_simulation_rows:
        sheet("Feature Simulation Details", effect_simulation_rows)
    if joint_report_rows:
        sheet("Joint Risk", joint_rows)
        sheet("Joint Risk Details", joint_report_rows)
    if fit_rows:
        sheet("Prediction Context", fit_rows)
    metadata = []
    for key, value in payload.get("provenance", {}).items():
        if isinstance(value, (dict, list, tuple)):
            value = json.dumps(value, ensure_ascii=False, allow_nan=False)
        if isinstance(value, str) and len(value) > 30000:
            # Excel truncates strings after 32767 characters. Ordered chunks
            # preserve large topology/template snapshots exactly for replay.
            pieces = [value[start:start + 30000] for start in range(0, len(value), 30000)]
            metadata.extend({"item": key, "part": i + 1, "parts": len(pieces), "value": piece}
                            for i, piece in enumerate(pieces))
        else:
            metadata.append({"item": key, "part": 1, "parts": 1, "value": value})
    sheet("Run Settings", metadata + [{"item": "warning", "part": 1, "parts": 1, "value": w} for w in payload.get("warnings", [])],
          ["item", "part", "parts", "value"])
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".xlsx", delete=False) as handle:
            temporary = Path(handle.name)
        workbook.save(temporary)
        os.replace(temporary, target)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)
        workbook.close()
    return str(target.resolve())
