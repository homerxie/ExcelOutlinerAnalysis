"""Compile template row/column intersections that analysis treats as no data."""
from __future__ import annotations

from .compact_analysis import ColumnarMeasurements


class ExclusionMatcher:
    """Match any rule, with all of a rule's row and column clauses required."""

    def __init__(self, template):
        rules = template.report.analysis_exclusions
        self.active = bool(rules)
        self._rows_by_column = {}
        if not rules:
            return
        compiled = [
            (tuple((key, frozenset(values)) for key, values in rule.row_filters.items()),
             tuple((key, frozenset(values)) for key, values in rule.column_filters.items()))
            for rule in rules
        ]
        for group in template.analysis_groups:
            for column in group.columns:
                context = {
                    "id": group.id, "display_name": group.display_name,
                    "raw_column": column.name,
                    "logical_metric": (group.id if group.analysis_mode == "pooled_columns"
                                       else f"{group.id}::{column.name}"),
                    "unit": group.unit or "",
                    **{level.name: str(value) for level, value
                       in zip(template.column_header_levels, column.header_values)},
                }
                matches = tuple(row_rules for row_rules, column_rules in compiled
                                if all(context.get(key, "") in values for key, values in column_rules))
                if matches:
                    self._rows_by_column[column.name] = matches

    def matches(self, dimensions, raw_column):
        rules = self._rows_by_column.get(raw_column)
        if not rules:
            return False
        return any(all(str(dimensions.get(key, "")) in values for key, values in row_rules)
                   for row_rules in rules)


def filter_analysis_measurements(template, measurements, *, matcher=None):
    """Remove excluded numeric cells from the statistical pool, never storage."""
    matcher = matcher if matcher is not None else ExclusionMatcher(template)
    if not matcher.active:
        return measurements
    records = (item for item in measurements
               if not matcher.matches(item.dimensions, item.raw_column))
    return ColumnarMeasurements(records) if isinstance(measurements, ColumnarMeasurements) else list(records)
