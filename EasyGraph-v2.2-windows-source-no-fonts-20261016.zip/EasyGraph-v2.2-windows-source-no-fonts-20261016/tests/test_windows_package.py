from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path
import zipfile

from tests.easygraph_case import ROOT, EasyGraphTestCase


class WindowsPackageTests(EasyGraphTestCase):
    def test_without_fonts_creates_only_source_archive(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run(
                [sys.executable, str(ROOT / "scripts" / "package_windows_release.py"),
                 "--output-dir", tmp, "--name", "EasyGraph-test", "--without-fonts"],
                cwd=ROOT, capture_output=True, text=True, timeout=30,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(len(list(Path(tmp).glob("*.zip"))), 1)
            with zipfile.ZipFile(Path(result.stdout.strip())) as source:
                paths = {Path(*Path(name).parts[1:]).as_posix() for name in source.namelist()}
                self.assertFalse(any(name.startswith("src/easygraph/resources/fonts/") for name in paths))
                self.assertIn("CHANGELOG.md", paths)
                self.assertIn("src/easygraph/chart_fonts.py", paths)

    def test_split_packages_restore_the_complete_source_tree(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run(
                [sys.executable, str(ROOT / "scripts" / "package_windows_release.py"),
                 "--output-dir", tmp, "--name", "EasyGraph-test", "--split-fonts"],
                cwd=ROOT, capture_output=True, text=True, timeout=30,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            source_path, font_path = map(Path, result.stdout.strip().splitlines())
            with zipfile.ZipFile(source_path) as source, zipfile.ZipFile(font_path) as fonts:
                self.assertIsNone(source.testzip())
                self.assertIsNone(fonts.testzip())
                source_paths = {Path(*Path(name).parts[1:]).as_posix() for name in source.namelist()}
                font_paths = set(fonts.namelist())
                self.assertTrue(font_paths)
                self.assertTrue(all(name.startswith("src/easygraph/resources/fonts/") for name in font_paths))
                self.assertFalse(any(name.startswith("src/easygraph/resources/fonts/") for name in source_paths))
                expected_fonts = {
                    path.relative_to(ROOT).as_posix()
                    for path in (ROOT / "src/easygraph/resources/fonts").rglob("*")
                    if path.is_file() and path.name != ".DS_Store"
                }
                self.assertEqual(font_paths, expected_fonts)
                self.assertIn("CHANGELOG.md", source_paths)
                self.assertIn("WINDOWS_BUILD.md", source_paths)

    def test_source_package_supports_external_output_and_contains_smoke_tools(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "scripts" / "package_windows_release.py"),
                    "--output-dir",
                    tmp,
                    "--name",
                    "EasyGraph-test",
                ],
                cwd=ROOT,
                capture_output=True,
                text=True,
                check=False,
                timeout=30,
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            archive_path = Path(result.stdout.strip())
            self.assertTrue(archive_path.is_absolute())
            self.assertTrue(archive_path.is_file())
            with zipfile.ZipFile(archive_path) as archive:
                packaged_paths = {
                    Path(name).parts[-2:]
                    for name in archive.namelist()
                    if not name.endswith("/")
                }

        for expected in (
            ("windows", "EasyGraph.ico"),
            (
                "EasyGraph_Project_Icon_Pack",
                "EasyGraph_Project_Icon_Windows.ico",
            ),
            ("translations", "easygraph_zh_CN.qm"),
            ("scripts", "generate_windows_icons.py"),
            ("scripts", "build_and_smoke_windows.ps1"),
            ("scripts", "package_windows_release.py"),
            ("scripts", "windows_version_info.py"),
            ("easygraph", "packaging_smoke.py"),
            ("easygraph", "chart_fonts.py"),
            ("source-han-sans", "SourceHanSansSC-Regular.otf"),
            ("source-han-sans", "SourceHanSansSC-Medium.otf"),
            ("source-han-sans", "SourceHanSansSC-Bold.otf"),
            ("source-han-sans", "LICENSE.txt"),
            ("source-han-sans", "SOURCE.json"),
            ("easygraph", "file_association.py"),
            ("prism_io", "pzfx.py"),
            ("src", "ui_prism_import_dialog.py"),
            ("ui", "prism_import_dialog.ui"),
            ("src", "ui_startup_dialog.py"),
            ("ui", "startup_dialog.ui"),
            ("scripts", "inspect_prism_samples.py"),
            ("plans", "2026-07-16-prism-raw-data-import.md"),
            ("prism_samples", "SOURCES.md"),
            ("tests", "test_packaging_smoke.py"),
            ("tests", "test_file_association.py"),
            ("tests", "test_prism_pzfx.py"),
            ("tests", "test_windows_package.py"),
        ):
            with self.subTest(expected=expected):
                self.assertIn(expected, packaged_paths)
