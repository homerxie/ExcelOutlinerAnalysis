"""Header dialogs preserve the user's line breaks through edits and undo."""
from __future__ import annotations

from unittest import mock

import pandas as pd
from PySide6.QtCore import QPoint, Qt
from PySide6.QtTest import QTest

from easygraph.app_theme import configure_matplotlib_fonts
from easygraph.plotting.group_axis_layout import prepare_group_axis_labels
from easygraph.plotting.group_layout import GroupLayout, ParentSpan
from easygraph.settings import ChartSettings
from tests.easygraph_case import EasyGraphQtTestCase


class HeaderMultilineEditingTests(EasyGraphQtTestCase):
    def make_header_window(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame(
            [[1, 2, 3], [3, 4, 5]], columns=['Control', 'Treatment', 'Recovery'],
        ))
        return window

    def test_parent_double_click_opens_multiline_dialog_and_undo_preserves_data(self):
        window = self.make_header_window()
        header = window.table.horizontalHeader()
        header.select_parent_columns([0, 1])
        self.assertTrue(window.grouping_controls.merge_selected_headers('Original'))
        before = window.table_dataframe().copy()
        window.show()
        self.qapp.processEvents()
        position = QPoint(header.sectionViewportPosition(0) + header.sectionSize(0) // 2,
                          header.parent_band_rect().center().y())
        name = '高温高湿试验\nLong-term reliability'
        with mock.patch('easygraph.ui.grouping_controls.QInputDialog.getMultiLineText',
                        return_value=(name, True)) as dialog:
            QTest.mouseDClick(header.viewport(), Qt.LeftButton, pos=position)
        dialog.assert_called_once()
        self.assertEqual(dialog.call_args.kwargs['text'], 'Original')
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]['name'], name)
        pd.testing.assert_frame_equal(window.table_dataframe(), before)
        window.undo_table_change()
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]['name'], 'Original')
        window.redo_table_change()
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]['name'], name)

    def test_leaf_double_click_preserves_manual_lines_and_cancelling_is_not_an_edit(self):
        window = self.make_header_window()
        window.show()
        self.qapp.processEvents()
        position = window.table.visualRect(window.table.table_model.index(0, 0)).center()
        name = '长期循环后强度\nStrength (MPa)'
        with mock.patch('easygraph.ui.main_window.QInputDialog.getMultiLineText',
                        return_value=(name, True)) as dialog:
            QTest.mouseDClick(window.table.viewport(), Qt.LeftButton, pos=position)
        dialog.assert_called_once()
        self.assertEqual(dialog.call_args.kwargs['text'], 'Control')
        self.assertEqual(window.table.table_model.cell_text(0, 0), name)
        with mock.patch('easygraph.ui.main_window.QInputDialog.getMultiLineText',
                        return_value=('discarded\ntext', False)) as dialog:
            window.rename_column(window.table, 0)
        self.assertEqual(dialog.call_args.kwargs['text'], name)
        self.assertEqual(window.table.table_model.cell_text(0, 0), name)
        window.undo_table_change()
        self.assertEqual(window.table.table_model.cell_text(0, 0), 'Control')
        window.redo_table_change()
        self.assertEqual(window.table.table_model.cell_text(0, 0), name)

    def test_parent_creation_merge_and_insertion_accept_multiline_names(self):
        for command in ('create', 'merge', 'insert'):
            with self.subTest(command=command):
                window = self.make_header_window()
                self.select_table_range(window.table, 0, 0, 0, 1)
                header = window.table.horizontalHeader()
                if command != 'create':
                    header.select_parent_columns([0, 1])
                name = '试验阶段\nExperiment phase'
                with mock.patch('easygraph.ui.grouping_controls.QInputDialog.getMultiLineText',
                                return_value=(name, True)) as dialog:
                    controls = window.grouping_controls
                    changed = (controls.create_selected_parent() if command == 'create'
                               else controls.merge_selected_headers() if command == 'merge'
                               else controls.insert_selected_parent(True))
                self.assertTrue(changed)
                dialog.assert_called_once()
                self.assertEqual(window.workbook.active_sheet.grouping.parents[0]['name'], name)

    def test_cancelled_parent_rename_keeps_the_existing_manual_lines(self):
        window = self.make_header_window()
        self.select_table_range(window.table, 0, 0, 0, 1)
        name = '第一阶段\nPhase one'
        window.grouping_controls.create_selected_parent(name)
        parent_id = window.workbook.active_sheet.grouping.parents[0]['id']
        with mock.patch('easygraph.ui.grouping_controls.QInputDialog.getMultiLineText',
                        return_value=('discarded\ntext', False)) as dialog:
            self.assertFalse(window.grouping_controls.rename_parent(parent_id))
        self.assertEqual(dialog.call_args.kwargs['text'], name)
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]['name'], name)
        window.undo_table_change()
        self.assertFalse(window.workbook.active_sheet.grouping.parents)

    def test_axis_labels_use_manual_breaks_instead_of_rewrapping_each_line(self):
        configure_matplotlib_fonts()
        parent = '手动指定的较长第一行\nParent heading'
        leaf = '手动指定的较长第二级\nTensile strength (MPa)'
        for parents in ((), (ParentSpan('parent', parent, 0, 1),)):
            with self.subTest(grouped=bool(parents)):
                layout = GroupLayout(
                    order=('a', 'b'), labels={'a': leaf, 'b': 'Control'},
                    positions={'a': 0, 'b': 1}, colors={}, parents=parents, legend=(),
                )
                plan = prepare_group_axis_labels(layout, ChartSettings(), 60)
                self.assertEqual(plan.leaves[0], leaf)
                self.assertEqual(plan.parents, (parent,) if parents else ())
