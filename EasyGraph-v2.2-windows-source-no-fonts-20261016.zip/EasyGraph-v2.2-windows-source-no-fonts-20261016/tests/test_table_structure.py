from unittest import mock

from PySide6.QtCore import QItemSelection, QItemSelectionModel

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.data_table import DataTable
from easygraph.table_structure import (
    TableSelection,
    delete_table_rows,
    expanded_pair_columns,
    insert_table_rows,
    selected_table_columns,
    shift_cells_down,
    shift_cells_up,
    table_selection,
)


class TableStructureTests(EasyGraphQtTestCase):
    def test_selection_ranges_preserve_disjoint_shape_without_model_indexes(self):
        table = DataTable(5, 4)
        self.addCleanup(table.close)
        model = table.table_model
        selection_model = table.selectionModel()
        selection_model.select(
            QItemSelection(model.index(1, 0), model.index(3, 1)), QItemSelectionModel.Select,
        )
        selection_model.select(
            QItemSelection(model.index(2, 3), model.index(4, 3)), QItemSelectionModel.Select,
        )
        expected = {(row, col) for row in (1, 2, 3) for col in (0, 1)} | {(row, 3) for row in (2, 3, 4)}

        with mock.patch.object(selection_model, "selectedIndexes", side_effect=AssertionError("expanded selection")):
            selection = table_selection(table)
            self.assertEqual(selection, TableSelection.from_positions(expected))
            self.assertFalse(selection.is_rectangular)
            self.assertEqual(selected_table_columns(table), (0, 1, 3))

    def test_selection_reports_rectangular_and_disjoint_shapes(self):
        rectangle = TableSelection.from_positions(
            ((row, column) for row in (2, 3) for column in (1, 2))
        )
        self.assertTrue(rectangle.is_rectangular)
        self.assertEqual((rectangle.top, rectangle.bottom), (2, 3))
        self.assertEqual((rectangle.left, rectangle.right), (1, 2))
        self.assertEqual((rectangle.row_span, rectangle.column_span), (2, 2))

        disjoint = TableSelection.from_positions(((2, 1), (3, 2)))
        self.assertFalse(disjoint.is_rectangular)

    def test_pair_expansion_includes_each_complete_pair(self):
        self.assertEqual(expanded_pair_columns((1,), 6), (0, 1))
        self.assertEqual(expanded_pair_columns((1, 4), 6), (0, 1, 4, 5))
        self.assertEqual(expanded_pair_columns((4,), 5), (4,))

    def test_shift_cells_down_preserves_tail_and_only_moves_target_columns(self):
        table = DataTable(4, 2)
        for row, value in enumerate(("name", "1", "2", "3")):
            table.table_model.set_cell_text(row, 0, value)
        for row, value in enumerate(("other", "a", "b", "c")):
            table.table_model.set_cell_text(row, 1, value)

        self.assertTrue(shift_cells_down(table.table_model, 2, (0,), 1))
        self.assertEqual(
            [table.table_model.cell_text(row, 0) for row in range(5)],
            ["name", "1", "", "2", "3"],
        )
        self.assertEqual(
            [table.table_model.cell_text(row, 1) for row in range(5)],
            ["other", "a", "b", "c", ""],
        )

    def test_shift_cells_up_blanks_tail_without_changing_shape(self):
        table = DataTable(5, 2)
        for row, value in enumerate(("name", "1", "2", "3", "4")):
            table.table_model.set_cell_text(row, 0, value)

        self.assertTrue(shift_cells_up(table.table_model, 2, (0,), 2))
        self.assertEqual(table.table_model.rowCount(), 5)
        self.assertEqual(
            [table.table_model.cell_text(row, 0) for row in range(5)],
            ["name", "1", "4", "", ""],
        )

    def test_row_helpers_insert_and_delete_at_selection(self):
        table = DataTable(3, 1)
        for row, value in enumerate(("name", "1", "2")):
            table.table_model.set_cell_text(row, 0, value)

        self.assertTrue(insert_table_rows(table.table_model, 2, 2))
        self.assertEqual(
            [table.table_model.cell_text(row, 0) for row in range(5)],
            ["name", "1", "", "", "2"],
        )
        self.assertTrue(delete_table_rows(table.table_model, 1, 2))
        self.assertEqual(
            [table.table_model.cell_text(row, 0) for row in range(3)],
            ["name", "", "2"],
        )


if __name__ == "__main__":
    import unittest

    unittest.main()
