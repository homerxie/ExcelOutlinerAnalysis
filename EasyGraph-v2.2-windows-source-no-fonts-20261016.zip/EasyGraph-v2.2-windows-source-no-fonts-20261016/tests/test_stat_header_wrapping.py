from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory

import matplotlib
import numpy as np
import pandas as pd
from matplotlib.transforms import Bbox

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.grouping import GroupingSettings
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings


class StatHeaderWrappingTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.ids = [f"column-{index}" for index in range(6)]
        self.frame = pd.DataFrame(
            [[index + row + 1 for index in range(6)] for row in range(4)],
            columns=["长期循环后抗拉强度 Retention (%)", "短时强度 Strength (MPa)", "Control", "Low dose", "High dose", "恢复阶段 Recovery"],
        )
        self.grouping = GroupingSettings(parents=[
            {"id": "narrow", "name": "高温高湿环境下的长期可靠性验证第一阶段", "column_ids": self.ids[:2]},
            {"id": "wide", "name": "常规实验与恢复阶段 Reference and recovery", "column_ids": self.ids[2:]},
        ])
        self.canvas = PlotCanvas()
        self.addCleanup(self.canvas.close)

    def make_settings(self, **overrides):
        values = dict(width=16, height=7, show_points=False, show_stat_table=True, show_stat_header=True,
                      show_stat_mean=True, stat_table_font_size=10, group_inner_spacing=0.45,
                      group_outer_spacing=2.7, x_tick_rotation=0)
        values.update(overrides)
        return ChartSettings(**values)

    def render(self, *, grouped=True, **overrides):
        settings = self.make_settings(**overrides)
        before = asdict(settings)
        names = list(self.frame.columns)
        groups = deepcopy(asdict(self.grouping))
        self.canvas.render(self.frame, settings, grouping=self.grouping if grouped else None, column_ids=self.ids)
        self.assertEqual(asdict(settings), before)
        self.assertEqual(list(self.frame.columns), names)
        self.assertEqual(asdict(self.grouping), groups)
        return settings, self.canvas.figure.axes[0], next(axis for axis in self.canvas.figure.axes if not axis.axison)

    def header_texts(self, table, level):
        return [text for text in table.texts if text.get_gid() == f"stat-{level}-header"]

    def assert_cells_contain_text(self, table):
        renderer = self.canvas.canvas.get_renderer()
        frame = self.canvas.figure.bbox
        for text in table.texts:
            if not hasattr(text, "_stat_cell_bounds") or not text.get_text():
                continue
            left, right, bottom, top = text._stat_cell_bounds
            cell = table.transData.transform_bbox(Bbox.from_extents(left, bottom, right, top))
            ink = text.get_window_extent(renderer)
            with self.subTest(text=text.get_text()):
                self.assertGreaterEqual(ink.x0, cell.x0 - 0.5)
                self.assertLessEqual(ink.x1, cell.x1 + 0.5)
                self.assertGreaterEqual(ink.y0, cell.y0 - 0.5)
                self.assertLessEqual(ink.y1, cell.y1 + 0.5)
                self.assertGreaterEqual(ink.x0, frame.x0)
                self.assertLessEqual(ink.x1, frame.x1)
                self.assertGreaterEqual(ink.y0, frame.y0)
                self.assertLessEqual(ink.y1, frame.y1)

    def test_single_and_grouped_headers_wrap_without_changing_names_or_plot_width(self):
        for grouped in (False, True):
            with self.subTest(grouped=grouped):
                settings, ax, table = self.render(grouped=grouped)
                leaves = self.header_texts(table, "leaf")
                parents = self.header_texts(table, "parent")
                self.assertEqual(len(leaves), 6)
                self.assertTrue(any("\n" in text.get_text() for text in leaves[:2]))
                self.assertEqual(len(parents), 2 if grouped else 0)
                if grouped:
                    self.assertTrue(any("\n" in text.get_text() for text in parents))
                self.assertAlmostEqual(ax.get_window_extent().width / self.canvas.figure.dpi, settings.width / 2.54)
                self.assertAlmostEqual(ax.get_window_extent().height / self.canvas.figure.dpi, settings.height / 2.54)
                for original, text in zip(self.frame.columns, leaves):
                    self.assertEqual(text.get_text().replace("\n", ""), original)
                for key, text in zip(self.canvas._group_layout.order, leaves):
                    expected = ax.transData.transform((self.canvas._group_layout.positions[key], 0))[0]
                    self.assertAlmostEqual(text.get_transform().transform(text.get_position())[0], expected)
                self.assert_cells_contain_text(table)

    def test_parent_headers_span_exact_group_cells_and_have_separate_row_height(self):
        _settings, _ax, table = self.render()
        parents = self.header_texts(table, "parent")
        leaves = self.header_texts(table, "leaf")
        renderer = self.canvas.canvas.get_renderer()
        for parent, text in zip(self.canvas._group_layout.parents, parents):
            left, right, bottom, top = text._stat_cell_bounds
            half = self.canvas._group_layout.inner_spacing / 2
            self.assertAlmostEqual(left, parent.start - half)
            self.assertAlmostEqual(right, parent.end + half)
            self.assertGreater(top, bottom)
        self.assertGreater(min(text.get_window_extent(renderer).y0 for text in parents),
                           max(text.get_window_extent(renderer).y1 for text in leaves))
        self.assert_cells_contain_text(table)

    def test_manual_header_lines_are_exact_and_only_necessary_width_is_added(self):
        leaf = "按用户手动保留这一整段首行 Manual line\n第二行"
        parent = "一级标题按用户保留完整首行\n第二行\n第三行"
        self.frame.columns = [leaf, *self.frame.columns[1:]]
        self.grouping.parents[0]["name"] = parent
        for split in (False, True):
            with self.subTest(split=split):
                settings, ax, table = self.render(width=10, extra_custom_overlay=True,
                    custom_overlay_secondary_axis=True, split_secondary_axis=split,
                    custom_overlay_series=[{"name": "Response", "values": dict(zip(self.ids, range(10, 70, 10)))}])
                self.assertEqual(self.header_texts(table, "leaf")[0].get_text(), leaf)
                self.assertEqual(self.header_texts(table, "parent")[0].get_text(), parent)
                self.assertGreater(ax.get_window_extent().width / self.canvas.figure.dpi, settings.width / 2.54)
                secondary = next(axis for axis in self.canvas.figure.axes if axis.get_gid() == "secondary-axis")
                self.assertAlmostEqual(ax.get_window_extent().width, secondary.get_window_extent().width)
                self.assertAlmostEqual(ax.get_window_extent().width, table.get_window_extent().width)
                self.assert_cells_contain_text(table)

    def test_header_switch_hides_both_levels_without_adding_empty_rows(self):
        settings, _ax, table = self.render(show_stat_header=False)
        self.assertFalse(self.header_texts(table, "leaf"))
        self.assertFalse(self.header_texts(table, "parent"))
        rows = [text for text in table.texts if text.get_position()[0] < table.get_xlim()[0]]
        expected = len(rows) * self.canvas._stat_table_row_height_inches(settings)
        self.assertAlmostEqual(table.get_window_extent().height / self.canvas.figure.dpi, expected)

    def test_ridge_side_headers_wrap_and_row_bands_remain_aligned_and_separate(self):
        self.frame.columns = ["长期循环高温高湿环境下处理后的测量结果 Retention " * 2, "用户手动首行\n第二行\n第三行\n第四行\n第五行", *self.frame.columns[2:]]
        for split in (False, True):
            with self.subTest(split=split):
                settings, ax, _table = self.render(chart_type="Ridge", width=8, height=4,
                    extra_custom_overlay=True, custom_overlay_secondary_axis=True, split_secondary_axis=split,
                    custom_overlay_series=[{"name": "Response", "values": dict(zip(self.ids, range(10, 70, 10)))}])
                table = next(axis for axis in self.canvas.figure.axes if axis.get_gid() == "ridge-stat-table")
                labels = self.header_texts(table, "leaf")
                self.assertIn("\n", labels[0].get_text())
                self.assertEqual(labels[1].get_text(), self.frame.columns[1])
                self.assertGreater(ax.get_window_extent().height / self.canvas.figure.dpi, settings.height / 2.54)
                self.assert_cells_contain_text(table)
                renderer = self.canvas.canvas.get_renderer()
                for key, text in zip(self.canvas._group_layout.order, labels):
                    position = self.canvas._group_layout.coordinate(key, ridge=True)
                    expected = ax.transData.transform((0, position))[1]
                    bounds = text.get_window_extent(renderer)
                    self.assertAlmostEqual((bounds.y0 + bounds.y1) / 2, expected)
                for upper, lower in zip(labels, labels[1:]):
                    self.assertGreater(upper._stat_cell_bounds[2], lower._stat_cell_bounds[3])
                secondary = next(axis for axis in self.canvas.figure.axes if axis.get_gid() == "secondary-axis")
                self.assertAlmostEqual(ax.get_window_extent().height, secondary.get_window_extent().height)

    def test_headers_export_with_same_lines_and_alignment_at_multiple_dpi(self):
        _settings, ax, table = self.render()
        texts = [*self.header_texts(table, "parent"), *self.header_texts(table, "leaf")]
        original = [text.get_text() for text in texts]
        original_dpi = self.canvas.figure.dpi
        centers = [text.get_transform().transform(text.get_position()) / original_dpi for text in texts]
        with TemporaryDirectory() as folder, matplotlib.rc_context({"svg.fonttype": "none"}):
            for dpi in (72, 300):
                self.canvas.figure.set_dpi(dpi)
                self.canvas.canvas.draw()
                self.assert_cells_contain_text(table)
                for center, text in zip(centers, texts):
                    np.testing.assert_allclose(text.get_transform().transform(text.get_position()) / dpi, center)
                self.assertEqual([text.get_text() for text in texts], original)
                for suffix in ("png", "svg", "pdf"):
                    path = Path(folder) / f"statistics-{dpi}.{suffix}"
                    self.canvas.export(str(path), ChartSettings(dpi=dpi))
                    self.assertGreater(path.stat().st_size, 1000)
                svg = (Path(folder) / f"statistics-{dpi}.svg").read_text()
                self.assertIn("stat-parent-header", svg)
                self.assertIn("stat-leaf-header", svg)
                self.assertIn("<text", svg)
        self.canvas.figure.set_dpi(original_dpi)
