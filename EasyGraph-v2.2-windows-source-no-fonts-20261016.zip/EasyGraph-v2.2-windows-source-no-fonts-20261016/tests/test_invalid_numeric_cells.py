from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtGui import QBrush, QColor

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph import table_model
from easygraph.table_model import EasyGraphTableModel


class InvalidNumericCellTests(EasyGraphQtTestCase):
    def test_headers_empty_cells_and_valid_numbers_are_not_flagged(self):
        model = EasyGraphTableModel()
        values = ["", " \t\n", "1", " -2.5 ", ".5", "1e3", "25%", " 25 ％ ", "inf", "文字", "1x", "NaN", "1,000"]
        model.replace_cells([["Header"] * len(values), values])

        self.assertEqual(model.invalid_numeric_cells(), ((1, 9), (1, 10), (1, 11), (1, 12)))
        self.assertEqual(model.invalid_numeric_cell_count, 4)
        self.assertEqual(model.cells_copy()[1], values)
        self.assertIsNone(model.data(model.index(1, 6), Qt.BackgroundRole))
        self.assertEqual(model.data(model.index(1, 9), Qt.BackgroundRole).color().name(), "#fff1cc")

    def test_overlay_cells_are_flagged_without_changing_source_data(self):
        model = EasyGraphTableModel()
        model.replace_from_dataframe(pd.DataFrame({"Group": ["bad sample", "25%"]}), [
            {"name": "Target", "values": {"Group": "bad overlay"}},
        ])
        model.configure_style(2, QBrush(QColor("blue")), QBrush(QColor("white")))

        self.assertEqual(model.invalid_numeric_cells(), ((1, 0), (2, 0)))
        self.assertEqual(model.data(model.index(1, 0), Qt.BackgroundRole).color().name(), "#fff1cc")
        self.assertEqual(model.overlay_series(2, [])[0]["values"], {"Group": "bad overlay"})
        self.assertEqual(model.sample_dataframe().iloc[:, 0].tolist(), ["bad sample", "25%"])

    def test_edit_updates_count_and_background_and_clearing_removes_warning(self):
        model = EasyGraphTableModel()
        model.replace_cells([["Header"], ["1"]])
        counts, roles = [], []
        model.invalidNumericCellsChanged.connect(counts.append)
        model.dataChanged.connect(lambda first, last, changed_roles: roles.append(changed_roles))

        model.set_cell_text(1, 0, "bad")
        self.assertEqual(model.invalid_numeric_cells(), ((1, 0),))
        model.set_cell_text(1, 0, "other bad text")
        model.set_cell_text(1, 0, "  ")

        self.assertEqual(counts, [1, 0])
        self.assertTrue(all(Qt.BackgroundRole in changed_roles for changed_roles in roles))
        self.assertEqual(model.invalid_numeric_cells(), ())
        self.assertIsNone(model.data(model.index(1, 0), Qt.BackgroundRole))

    def test_bulk_edit_checks_changed_cells_only_and_notifies_once(self):
        model = EasyGraphTableModel()
        model.replace_cells([["Header"] * 10] + [["1"] * 10 for _ in range(200)])
        counts, updates = [], []
        model.invalidNumericCellsChanged.connect(counts.append)
        model.dataChanged.connect(lambda *args: updates.append(args))

        with mock.patch.object(table_model, "_invalid_numeric_text", wraps=table_model._invalid_numeric_text) as check:
            model.set_cells_text([(1, 0, "bad"), (200, 9, "bad"), (0, 0, "Title"), (1, 1, "1")])

        self.assertEqual(check.call_count, 2)
        self.assertEqual(counts, [2])
        self.assertEqual(len(updates), 1)
        self.assertEqual(model.invalid_numeric_cells(), ((1, 0), (200, 9)))

    def test_repeated_text_reuses_numeric_conversion(self):
        model = EasyGraphTableModel()
        table_model._invalid_numeric_text.cache_clear()
        with mock.patch.object(table_model, "coerce_numeric_value", wraps=table_model.coerce_numeric_value) as convert:
            model.replace_cells([["Header"] * 10] + [["bad"] * 10 for _ in range(100)])

        self.assertEqual(convert.call_count, 1)
        self.assertEqual(model.invalid_numeric_cell_count, 1000)

    def test_model_replacement_rebuilds_index_and_returns_independent_coordinates(self):
        model = EasyGraphTableModel()
        counts = []
        model.invalidNumericCellsChanged.connect(counts.append)
        model.replace_cells([["Header"], ["bad"]])
        coordinates = model.invalid_numeric_cells()
        model.replace_cells([["Other", "Header"], ["2", "25%"]])

        self.assertEqual(counts, [1, 0])
        self.assertEqual(coordinates, ((1, 0),))
        self.assertEqual(model.invalid_numeric_cells(), ())

    def test_row_and_column_changes_move_or_remove_invalid_coordinates(self):
        model = EasyGraphTableModel()
        model.replace_cells([["A", "B"], ["bad", "1"], ["2", "bad"]])
        model.insertRows(1, 2)
        model.insertColumns(1, 2)
        self.assertEqual(model.invalid_numeric_cells(), ((3, 0), (4, 3)))
        model.removeRows(2, 2)
        self.assertEqual(model.invalid_numeric_cells(), ((2, 3),))
        model.removeColumns(0, 2)
        self.assertEqual(model.invalid_numeric_cells(), ((2, 1),))
        model.resize(2, 1)
        self.assertEqual(model.invalid_numeric_cells(), ())

    def test_removing_and_inserting_first_row_reclassifies_header_cells(self):
        model = EasyGraphTableModel()
        model.replace_cells([["Header", "2"], ["bad", "bad"], ["3", "bad"]])
        model.removeRows(0, 1)
        self.assertEqual(model.invalid_numeric_cells(), ((1, 1),))
        model.insertRows(0, 2)
        self.assertEqual(model.invalid_numeric_cells(), ((2, 0), (2, 1), (3, 1)))
        model.removeRows(0, model.rowCount())
        self.assertEqual(model.invalid_numeric_cells(), ())
