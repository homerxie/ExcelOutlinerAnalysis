from __future__ import annotations

from dataclasses import replace
from io import BytesIO
from unittest import mock

import numpy as np
import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.chart_fonts import BUNDLED_FONT_FAMILY
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings, LEGEND_POSITION_INSIDE
from easygraph.xy_series import XYSeriesSpec, XYSettings


class TitleRenderingTests(EasyGraphQtTestCase):
    def make_canvas(self):
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        return canvas

    def assert_title_geometry(self, canvas):
        from easygraph.plotting.title_layout import measured_text_bounds

        renderer = canvas.canvas.get_renderer()
        frame = canvas.figure.bbox
        for ax in canvas.figure.axes:
            if not ax.axison:
                continue
            titles = [ax.title]
            if ax.xaxis.get_visible():
                titles.append(ax.xaxis.label)
            if ax.yaxis.get_visible():
                titles.append(ax.yaxis.label)
            for artist in titles:
                if not artist.get_visible() or not artist.get_text():
                    continue
                box = measured_text_bounds(artist, renderer)
                self.assertGreaterEqual(box.x0, frame.x0 - 0.1)
                self.assertGreaterEqual(box.y0, frame.y0 - 0.1)
                self.assertLessEqual(box.x1, frame.x1 + 0.1)
                self.assertLessEqual(box.y1, frame.y1 + 0.1)
            if ax.yaxis.get_visible() and ax.get_ylabel():
                ybox = measured_text_bounds(ax.yaxis.label, renderer)
                axes_box = ax.get_window_extent(renderer)
                self.assertGreaterEqual(ybox.y0, axes_box.y0 - 0.1)
                self.assertLessEqual(ybox.y1, axes_box.y1 + 0.1)
                for other in (ax.title, ax.xaxis.label):
                    if other.get_visible() and other.get_text():
                        self.assertFalse(ybox.overlaps(measured_text_bounds(other, renderer)))

    def test_long_titles_expand_width_and_wrap_vertical_labels_across_chart_types(self):
        canvas = self.make_canvas()
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            with self.subTest(chart_type=chart_type):
                settings = ChartSettings(
                    chart_type=chart_type, width=9, height=5,
                    title="长期可靠性测试 WWWiii 强度变化与环境影响 " * 3,
                    x_label="不同实验条件下的样品分组及处理方式 " * 4,
                    y_label="测量结果与初始基准的相对变化 WWWiii " * 4,
                    show_stat_table=True,
                )
                canvas.render(self.df, settings)
                ax = canvas.figure.axes[0]
                self.assertEqual(ax.get_title(), settings.title)
                self.assertIn("\n", ax.get_ylabel())
                self.assertNotIn("\n", ax.get_xlabel())
                self.assertAlmostEqual(ax.get_position().width * canvas.figure.get_figwidth(), settings.width / 2.54)
                self.assertAlmostEqual(ax.get_position().height * canvas.figure.get_figheight(), settings.height / 2.54)
                self.assert_title_geometry(canvas)
                # Wrapping must not turn the vertical text into extra page height.
                self.assertLess(canvas.figure.get_figheight(), 7)

    def test_xy_and_split_secondary_axis_titles_fit_their_own_axis_height(self):
        canvas = self.make_canvas()
        settings = ChartSettings(
            title="长标题 Title " * 12, x_label="Horizontal axis 中文 " * 8,
            y_label="纵轴测量值 Measurement " * 12,
            secondary_y_label="副轴响应 Secondary response " * 10,
            width=10, height=6, show_stat_table=False,
        )
        xy = XYSettings(default_x_column_id="x", series=[XYSeriesSpec(id="s", name="Series", y_column_id="y")])
        canvas.render(pd.DataFrame({"X": [1, 2, 3], "Y": [2, 4, 3]}), settings,
                      xy_settings=xy, column_ids=["x", "y"])
        self.assert_title_geometry(canvas)
        for split in (False, True):
            with self.subTest(split=split):
                secondary_settings = replace(settings, extra_custom_overlay=True,
                    custom_overlay_secondary_axis=True, split_secondary_axis=split,
                    custom_overlay_series=[{"name": "Response", "values": {"A": "10", "B": "20"}}])
                canvas.render(pd.DataFrame({"A": [1, 2, 3], "B": [3, 4, 5]}), secondary_settings)
                self.assert_title_geometry(canvas)

    def test_live_preview_only_renders_text_and_keeps_plot_artists_and_size(self):
        canvas = self.make_canvas()
        settings = ChartSettings(show_stat_table=False)
        canvas.render(self.df, settings)
        figure = canvas.figure
        axes = figure.axes[0]
        size = figure.get_size_inches().copy()
        original = axes.get_title()
        edited = replace(settings, title="实时输入的超长标题 " * 15,
                         y_label="自动换行纵轴标签 " * 8)
        with mock.patch.object(canvas.canvas, "draw", side_effect=AssertionError("Full draw during typing")):
            self.assertTrue(canvas.preview_text_settings(edited))
        self.assertIs(canvas.figure, figure)
        self.assertIs(canvas.figure.axes[0], axes)
        self.assertEqual(axes.get_title(), original)
        np.testing.assert_array_equal(figure.get_size_inches(), size)
        self.assertEqual(canvas._last_settings.title, edited.title)
        canvas.render(self.df, edited)
        self.assertFalse(canvas._text_preview_layer.isVisible())
        self.assertEqual(canvas.figure.axes[0].get_title(), edited.title)
        self.assert_title_geometry(canvas)

    def test_canvas_expansion_preserves_inside_legend_offset_from_plot(self):
        canvas = self.make_canvas()
        settings = ChartSettings(show_stat_table=False, show_line_overlay=True,
            line_overlay_stat="Mean", legend_position=LEGEND_POSITION_INSIDE,
            legend_inside_x=0.25, legend_inside_y=0.3)
        offsets = []
        for title in ("短标题", "长标题 Long title " * 12):
            canvas.render(self.df, replace(settings, title=title))
            ax = canvas.figure.axes[0]
            renderer = canvas.canvas.get_renderer()
            plot = ax.get_window_extent(renderer)
            legend = ax.get_legend().get_window_extent(renderer)
            offsets.append((legend.x0 - plot.x0, legend.y0 - plot.y0))
        np.testing.assert_allclose(offsets[0], offsets[1], atol=0.1)

    def test_indivisible_vertical_math_keeps_horizontal_titles_clear_of_statistics(self):
        from easygraph.plotting.title_layout import measured_text_bounds

        canvas = self.make_canvas()
        settings = ChartSettings(width=8, height=3, show_stat_table=True,
            title="Main title extends across the complete figure " * 3,
            x_label="Horizontal axis with all experimental conditions " * 3,
            y_label="$ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ$")
        canvas.render(self.df, settings)
        ax, table = canvas.figure.axes[:2]
        renderer = canvas.canvas.get_renderer()
        ybox = measured_text_bounds(ax.yaxis.label, renderer)
        xbox = measured_text_bounds(ax.xaxis.label, renderer)
        title = measured_text_bounds(ax.title, renderer)
        self.assertFalse(ybox.overlaps(xbox))
        self.assertFalse(ybox.overlaps(title))
        self.assertGreater(xbox.y0, table.get_window_extent(renderer).y1)
        self.assertGreaterEqual(ybox.y0, 0)
        self.assertLessEqual(ybox.y1, canvas.figure.bbox.height)

    def test_background_capture_keeps_final_pixels_and_export_title_font(self):
        from matplotlib import font_manager
        from matplotlib.backends.backend_agg import FigureCanvasAgg

        canvas = self.make_canvas()
        settings = ChartSettings(title="思源黑体真实渲染 ABC", show_stat_table=False)
        canvas.render(self.df, settings)
        actual = np.asarray(canvas.canvas.buffer_rgba()).copy()
        self.assertIsNotNone(canvas._text_preview_background)
        # An unmodified Agg draw must be pixel-identical to the cached-body path.
        FigureCanvasAgg.draw(canvas.canvas)
        expected = np.asarray(canvas.canvas.buffer_rgba()).copy()
        np.testing.assert_array_equal(actual, expected)
        artist = canvas.figure.axes[0].title
        resolved = font_manager.FontProperties(fname=font_manager.findfont(artist.get_fontproperties()))
        self.assertEqual(resolved.get_name(), BUNDLED_FONT_FAMILY)
        output = BytesIO()
        canvas._savefig_without_interaction_feedback(output, format="png", dpi=300)
        self.assertGreater(len(output.getvalue()), 1000)
