from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.backends.backend_agg import RendererAgg
from matplotlib.figure import Figure
from matplotlib.font_manager import FontProperties
from matplotlib.transforms import Affine2D
import numpy as np
from PySide6.QtCore import QEvent, QPoint, Qt
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QApplication, QScrollArea

from easygraph.plotting import title_preview
from easygraph.plotting.title_preview import TextPreviewLayer


FONT = Path(__file__).resolve().parents[1] / "src/easygraph/resources/fonts/source-han-sans/SourceHanSansSC-Regular.otf"


def image_pixels(image):
    image = image.convertToFormat(QImage.Format.Format_RGBA8888)
    return np.frombuffer(image.bits(), np.uint8).reshape(image.height(), image.width(), 4).copy()


class TitlePreviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.figure = Figure(figsize=(3, 2.2), dpi=100)
        self.axes = self.figure.add_axes((0.25, 0.25, 0.65, 0.5))
        self.axes.plot([1, 2, 3], [2, 1, 4])
        self.font = FontProperties(fname=str(FONT), size=15)
        self.axes.set_title("原始标题", fontproperties=self.font)
        self.axes.set_xlabel("横轴", fontproperties=self.font)
        self.axes.set_ylabel("纵轴", fontproperties=self.font)
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.canvas.setFixedSize(300, 220)
        self.scroll = QScrollArea()
        self.scroll.resize(1100, 550)
        self.scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scroll.setWidget(self.canvas)
        self.scroll.show()
        self.app.processEvents()
        self.canvas.draw()
        self.app.processEvents()
        self.owner = SimpleNamespace(figure=self.figure, canvas=self.canvas, scroll=self.scroll)
        self.layer = TextPreviewLayer(self.owner)
        self.artists = [self.axes.title, self.axes.xaxis.label, self.axes.yaxis.label]
        self.background = self._title_free_background()
        self.canvas.draw()
        self.app.processEvents()

    def tearDown(self):
        self.layer.finish()
        self.scroll.close()
        self.scroll.deleteLater()
        self.app.sendPostedEvents(None, QEvent.Type.DeferredDelete)

    def _title_free_background(self):
        with mock.patch.object(self.axes.title, "draw"), mock.patch.object(self.axes.xaxis.label, "draw"), mock.patch.object(self.axes.yaxis.label, "draw"):
            self.canvas.draw()
            buffer = self.canvas.buffer_rgba()
            height, width = buffer.shape[:2]
            image = QImage(buffer, width, height, width * 4, QImage.Format.Format_RGBA8888).copy()
            image.setDevicePixelRatio(self.canvas.device_pixel_ratio)
            return image

    def _bindings(self, title="输入中的中文标题", xlabel="横轴", ylabel="纵轴"):
        return list(zip(self.artists, (title, xlabel, ylabel)))

    def test_preview_draws_only_detached_titles_and_preserves_committed_figure(self):
        before_text = [artist.get_text() for artist in self.artists]
        before_position = [artist.get_position() for artist in self.artists]
        before_transforms = [artist.get_transform().get_matrix().copy() for artist in self.artists]
        before_bounds = self.axes.get_position().bounds
        before_pixels = np.asarray(self.canvas.buffer_rgba()).copy()
        self.figure.stale = False
        with mock.patch.object(self.canvas, "draw", side_effect=AssertionError("full canvas draw")), mock.patch.object(self.figure, "draw", side_effect=AssertionError("full figure draw")):
            self.assertTrue(self.layer.update_preview(self.background, self._bindings(ylabel="自动换行的很长纵轴标题" * 5)))
            self.app.processEvents()
        self.assertFalse(self.figure.stale)
        self.assertEqual([artist.get_text() for artist in self.artists], before_text)
        self.assertEqual([artist.get_position() for artist in self.artists], before_position)
        for artist, matrix in zip(self.artists, before_transforms):
            np.testing.assert_array_equal(artist.get_transform().get_matrix(), matrix)
        self.assertEqual(self.axes.get_position().bounds, before_bounds)
        np.testing.assert_array_equal(np.asarray(self.canvas.buffer_rgba()), before_pixels)

    def test_long_chinese_title_is_visible_outside_original_canvas(self):
        before = image_pixels(self.scroll.viewport().grab().toImage())
        self.layer.update_preview(self.background, self._bindings(title="不换行的中文大标题" * 4))
        self.app.processEvents()
        after = image_pixels(self.scroll.viewport().grab().toImage())
        origin = self.canvas.mapTo(self.scroll.viewport(), QPoint(0, 0))
        ratio = self.scroll.viewport().devicePixelRatioF()
        outside = np.ones(after.shape[:2], dtype=bool)
        outside[:, int(origin.x() * ratio):int((origin.x() + self.canvas.width()) * ratio)] = False
        changed = np.any(before != after, axis=2)
        self.assertGreater(np.count_nonzero(changed & outside), 100)
        sprite = self.layer._images[0]
        self.assertLess(sprite.left_px, 0)
        self.assertGreater(sprite.left_px + sprite.image.width(), self.background.width())
        self.assertTrue(self.layer.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents))

    def test_unedited_title_layers_match_full_agg_pixels(self):
        before = image_pixels(self.scroll.viewport().grab().toImage())
        self.layer.update_preview(self.background, [(artist, artist.get_text()) for artist in self.artists])
        self.app.processEvents()
        after = image_pixels(self.scroll.viewport().grab().toImage())
        np.testing.assert_array_equal(after, before)

    def test_vertical_label_wraps_within_plot_span_and_does_not_reuse_old_source(self):
        source = "中文纵坐标标题" * 7
        self.axes.yaxis.label._title_layout_source_text = "previous source"
        self.axes.yaxis.label._title_layout_wrapped_text = source
        with mock.patch.object(title_preview, "wrap_vertical_title", wraps=title_preview.wrap_vertical_title) as wrap:
            self.layer.update_preview(self.background, [(self.axes.yaxis.label, source)])
        self.assertEqual(wrap.call_count, 1)
        clone = wrap.call_args.args[0]
        self.assertIn("\n", clone.get_text())
        self.assertEqual(clone.get_text().replace("\n", ""), source)
        sprite = self.layer._images[0]
        alpha = image_pixels(sprite.image)[:, :, 3]
        visible_rows = np.flatnonzero(np.any(alpha, axis=1))
        ink_top = sprite.top_px + visible_rows[0]
        ink_bottom = sprite.top_px + visible_rows[-1]
        plot = self.axes.get_window_extent()
        self.assertGreaterEqual(ink_top, self.figure.bbox.height - plot.y1)
        self.assertLessEqual(ink_bottom, self.figure.bbox.height - plot.y0)

    def test_rotated_chinese_punctuation_is_not_cropped_or_drawn_into_y_ticks(self):
        self.canvas.setFixedSize(300, 550)
        self.axes.set_position((0.25, 0.15, 0.65, 0.6))
        self.app.processEvents()
        self.background = self._title_free_background()
        self.canvas.draw()
        text = "相对于初始基准强度的变化百\n分比与长期可靠性评价结果\n（经过温度和湿度校正）"
        with mock.patch.object(title_preview, "wrap_vertical_title", wraps=title_preview.wrap_vertical_title) as wrap:
            self.layer.update_preview(self.background, [(self.axes.yaxis.label, text)])
        clone = wrap.call_args.args[0]
        sprite = self.layer._images[0]
        alpha = image_pixels(sprite.image)[:, :, 3]
        # Render the same final clone with ample extra space. Any ink in the
        # extra border proves that the supposedly measured crop lost glyphs.
        padding = 50
        wide = RendererAgg(sprite.image.width() + 2 * padding, sprite.image.height() + 2 * padding, self.figure.dpi)
        clone.set_transform(clone.get_transform() + Affine2D().translate(padding, padding))
        clone.draw(wide)
        wide_alpha = np.asarray(wide.buffer_rgba())[:, :, 3]
        np.testing.assert_array_equal(wide_alpha[padding:-padding, padding:-padding], alpha)
        outside = wide_alpha.copy()
        outside[padding:-padding, padding:-padding] = 0
        self.assertFalse(np.any(outside), "The preview crop discarded rotated glyph pixels")
        right_ink = sprite.left_px + np.nonzero(alpha)[1].max() + 1
        ticks_left = min(tick.get_window_extent(self.canvas.get_renderer()).x0
                         for tick in self.axes.yaxis.get_ticklabels() if tick.get_visible() and tick.get_text())
        self.assertLess(right_ink, ticks_left)

    def test_unchanged_titles_reuse_bitmaps_and_finish_releases_cached_images(self):
        with mock.patch.object(title_preview, "_render_title", wraps=title_preview._render_title) as render:
            self.layer.update_preview(self.background, self._bindings(title="一"))
            self.assertEqual(render.call_count, 3)
            self.layer.update_preview(self.background, self._bindings(title="一二"))
            self.assertEqual(render.call_count, 4)
        self.layer.finish()
        self.assertFalse(self.layer.isVisible())
        self.assertIsNone(self.layer._background)
        self.assertFalse(self.layer._images)
        self.assertFalse(self.layer._image_cache)

    def test_high_dpi_sprite_uses_background_ratio_and_scroll_resize_keeps_viewport_overlay(self):
        background = QImage(self.background)
        background.setDevicePixelRatio(2)
        self.layer.update_preview(background, self._bindings())
        self.assertTrue(all(sprite.image.devicePixelRatioF() == 2 for sprite in self.layer._images))
        self.scroll.resize(180, 160)
        self.app.processEvents()
        self.scroll.horizontalScrollBar().setValue(70)
        self.scroll.verticalScrollBar().setValue(30)
        self.app.processEvents()
        self.assertEqual(self.layer.geometry(), self.scroll.viewport().rect())
        self.assertLess(self.canvas.mapTo(self.scroll.viewport(), QPoint(0, 0)).x(), 0)
        self.assertFalse(self.layer.grab().toImage().isNull())

    def test_empty_title_is_removed_from_cached_background(self):
        self.layer.update_preview(self.background, [(artist, "") for artist in self.artists])
        self.assertFalse(self.layer._images)
        self.app.processEvents()
        origin = self.canvas.mapTo(self.scroll.viewport(), QPoint(0, 0))
        grab = self.scroll.viewport().grab().toImage()
        ratio = grab.devicePixelRatioF()
        shown = grab.copy(round(origin.x() * ratio), round(origin.y() * ratio), round(self.canvas.width() * ratio), round(self.canvas.height() * ratio))
        np.testing.assert_array_equal(image_pixels(shown), image_pixels(self.background))


class TitleExportPreviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_export_restores_preview_label_positions_before_the_next_edit(self):
        from easygraph.data import sample_data
        from easygraph.plotting.canvas import PlotCanvas
        from easygraph.settings import ChartSettings

        chart = PlotCanvas()
        chart.resize(1200, 850)
        chart.show()
        settings = ChartSettings(title="原始图片标题", x_label="横坐标标题", y_label="纵坐标标题")
        try:
            chart.render(sample_data(), settings)
            self.app.processEvents()
            artists = chart._text_preview_artists()
            anchors = [artist.get_transform().transform(artist.get_unitless_position()) for artist in artists]
            renderer_size = chart.canvas.get_renderer().get_canvas_width_height()
            before_background = image_pixels(chart._text_preview_background)
            with tempfile.TemporaryDirectory() as directory:
                for suffix in ("png", "svg"):
                    with self.subTest(format=suffix):
                        chart.export(str(Path(directory) / f"title-test.{suffix}"), settings)
                        for artist, anchor in zip(artists, anchors):
                            np.testing.assert_allclose(artist.get_transform().transform(artist.get_unitless_position()), anchor)
                        self.assertEqual(chart.canvas.get_renderer().get_canvas_width_height(), renderer_size)
                        np.testing.assert_array_equal(image_pixels(chart._text_preview_background), before_background)
                        settings.title = "导出后继续编辑标题"
                        with mock.patch.object(chart.canvas, "draw", side_effect=AssertionError("typing drew full canvas")):
                            self.assertTrue(chart.preview_text_settings(settings))
                        self.assertTrue(chart._text_preview_layer.isVisible())
                        chart.finish_text_preview()
        finally:
            chart.close()
            chart.deleteLater()
            self.app.sendPostedEvents(None, QEvent.Type.DeferredDelete)


if __name__ == "__main__":
    unittest.main()
