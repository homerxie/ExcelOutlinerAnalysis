from __future__ import annotations

import sys
from unittest import mock

import pandas as pd
from PySide6.QtCore import QSignalBlocker

from tests.easygraph_case import EasyGraphQtTestCase


class SheetSelectionTransitionTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        # Qt reports slot exceptions via excepthook instead of propagating them.
        self.slot_errors = []
        patcher = mock.patch.object(sys, "excepthook", side_effect=lambda *error: self.slot_errors.append(error))
        patcher.start()
        self.addCleanup(patcher.stop)

    def prepare_wide_sheet(self, window, selection="range"):
        columns = ["Control", "Low dose", "High dose"] * 3 + ["Control"]
        window.set_table_dataframe(pd.DataFrame(
            [[row + column for column in range(10)] for row in range(1000)],
            columns=columns,
        ))
        window.table.table_model.set_cell_text(1, 7, "999")
        window.table.setCurrentIndex(window.table.table_model.index(5, 7))
        if selection == "range":
            self.select_table_range(window.table, 5, 4, 9, 7)
        elif selection in {"parent", "parent_and_current"}:
            window.table.horizontalHeader().select_parent_columns([6, 7])
            if selection == "parent_and_current":
                with QSignalBlocker(window.table.selectionModel()):
                    window.table.setCurrentIndex(window.table.table_model.index(5, 7))
        elif selection == "current":
            window.table.clearSelection()
        window.table_tools.activate(window.table)
        return window.table_dataframe().copy(deep=True)

    def assert_blank_active_sheet(self, window):
        self.assertEqual(self.slot_errors, [])
        self.assertEqual(list(window.table_dataframe().columns), ["Group 1", "Group 2", "Group 3"])
        self.assertTrue((window.table_dataframe() == "").all().all())
        self.assertEqual(window.table.table_model.columnCount(), len(window.workbook.active_sheet.column_ids))
        self.assertEqual(window.results_table.model().columnCount(), 3)
        self.assertEqual(window.table.horizontalHeader().selected_parent_columns(), [])
        self.assertFalse(window.table.selectionModel().signalsBlocked())
        self.assertFalse(window.table.horizontalHeader().signalsBlocked())

    def test_add_blank_sheet_after_wide_selection_preserves_source_and_history(self):
        for selection in ("current", "range", "parent", "parent_and_current"):
            with self.subTest(selection=selection):
                self.slot_errors.clear()
                window = self.make_window()
                source = self.prepare_wide_sheet(window, selection)
                current = window.table.currentIndex()
                previous_cell = (current.row(), current.column())

                window.add_sheet()

                self.assertEqual(window.workbook.active_index, 1)
                self.assertEqual(window.sheet_tab_bar.currentIndex(), 1)
                self.assert_blank_active_sheet(window)
                pd.testing.assert_frame_equal(window.workbook.sheets[0].dataframe, source)
                self.assertFalse(window._table_controller.history.can_undo)

                window.sheet_tab_bar.setCurrentIndex(0)
                pd.testing.assert_frame_equal(window.table_dataframe(), source)
                if previous_cell[0] >= 0:
                    current = window.table.currentIndex()
                    self.assertEqual((current.row(), current.column()), previous_cell)
                window.undo_table_change()
                self.assertEqual(window.table.table_model.cell_text(1, 7), "7")
                window.sheet_tab_bar.setCurrentIndex(1)
                self.assert_blank_active_sheet(window)

    def test_switch_from_wide_selection_to_existing_blank_sheet(self):
        window = self.make_window()
        window.add_sheet()
        window.sheet_tab_bar.setCurrentIndex(0)
        source = self.prepare_wide_sheet(window)

        window.sheet_tab_bar.setCurrentIndex(1)

        self.assert_blank_active_sheet(window)
        pd.testing.assert_frame_equal(window.workbook.sheets[0].dataframe, source)

    def test_delete_wide_active_sheet_loads_remaining_blank_sheet(self):
        window = self.make_window()
        window.add_sheet()
        remaining_id = window.workbook.active_sheet_id
        window.sheet_tab_bar.setCurrentIndex(0)
        self.prepare_wide_sheet(window)

        window.delete_sheet(0, confirm=False)

        self.assertEqual(len(window.workbook.sheets), 1)
        self.assertEqual(window.workbook.active_sheet_id, remaining_id)
        self.assertEqual(window.sheet_tab_bar.count(), 1)
        self.assertEqual(window.sheet_tab_bar.currentIndex(), 0)
        self.assert_blank_active_sheet(window)
