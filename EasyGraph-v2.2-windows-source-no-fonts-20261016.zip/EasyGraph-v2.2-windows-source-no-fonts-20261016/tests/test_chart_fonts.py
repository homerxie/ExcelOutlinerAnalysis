from __future__ import annotations

import copy
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import warnings

from easygraph import chart_fonts


ROOT = Path(__file__).resolve().parents[1]


class BundledChartFontTests(unittest.TestCase):
    def test_font_helpers_do_not_import_matplotlib(self):
        result = subprocess.run(
            [sys.executable, "-c", "import sys; import easygraph.chart_fonts; "
             "assert not any(n == 'matplotlib' or n.startswith('matplotlib.') for n in sys.modules)"],
            env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
            capture_output=True,
            text=True,
            timeout=15,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_official_files_match_pinned_source_manifest_and_license(self):
        directory = chart_fonts.bundled_font_directory()
        manifest = json.loads((directory / "SOURCE.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["release_tag"], "2.005R")
        self.assertEqual(set(manifest["files"]), {*chart_fonts.BUNDLED_FONT_FILENAMES, "LICENSE.txt"})
        for filename, details in manifest["files"].items():
            with self.subTest(filename=filename):
                content = (directory / filename).read_bytes()
                self.assertEqual(hashlib.sha256(content).hexdigest(), details["sha256"])
                self.assertEqual(len(content), details["bytes"])
                self.assertTrue(details["url"].startswith(
                    "https://raw.githubusercontent.com/adobe-fonts/source-han-sans/2.005R/"
                ))
        license_text = (directory / "LICENSE.txt").read_text(encoding="utf-8")
        self.assertIn("Copyright 2014-2025 Adobe", license_text)
        self.assertIn("SIL OPEN FONT LICENSE Version 1.1", license_text)
        self.assertIn("DISCLAIMER", license_text)

    def test_package_relative_directory_also_resolves_inside_frozen_bundle(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            module_path = Path(temp_dir) / "easygraph" / "chart_fonts.py"
            with mock.patch.object(chart_fonts, "__file__", str(module_path)):
                self.assertEqual(
                    chart_fonts.bundled_font_directory(),
                    module_path.parent.resolve() / "resources" / "fonts" / "source-han-sans",
                )

    def test_registration_prefers_private_fonts_over_installed_family_and_resolves_weights(self):
        from matplotlib import font_manager

        # Simulate a machine with an existing same-name family. Use the real
        # system-font entry structure, without relying on any installed CJK font.
        manager = copy.copy(font_manager.fontManager)
        regular_path = chart_fonts.bundled_font_paths()[0]
        with tempfile.TemporaryDirectory() as temp_dir:
            installed_path = Path(temp_dir) / regular_path.name
            shutil.copyfile(regular_path, installed_path)
            manager.ttflist = []
            manager.addfont(str(installed_path))
            with mock.patch.object(font_manager, "fontManager", manager):
                self.assertEqual(chart_fonts.register_bundled_chart_fonts(), "Source Han Sans SC")
                for weight, expected_path in zip(
                    ("normal", "medium", "bold"), chart_fonts.bundled_font_paths()
                ):
                    with self.subTest(weight=weight):
                        resolved = manager.findfont(
                            font_manager.FontProperties(family="Source Han Sans SC", weight=weight),
                            fallback_to_default=False,
                        )
                        self.assertEqual(Path(resolved), expected_path)

    def test_missing_bundle_fails_explicitly_instead_of_changing_font(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            missing_font = Path(temp_dir) / "missing.otf"
            with mock.patch.object(chart_fonts, "bundled_font_paths", return_value=(missing_font,)):
                with self.assertRaisesRegex(FileNotFoundError, "Bundled chart font is missing"):
                    chart_fonts.register_bundled_chart_fonts()

    def test_mixed_chinese_latin_greek_and_symbols_export_without_missing_glyphs(self):
        from matplotlib import font_manager, rc_context
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        from matplotlib.figure import Figure

        from easygraph import app_theme

        with rc_context(), mock.patch.object(app_theme, "DEFAULT_FONT_FAMILY", None):
            family = app_theme.configure_matplotlib_fonts()
            self.assertEqual(family, "Source Han Sans SC")
            figure = Figure(figsize=(5, 2))
            FigureCanvasAgg(figure)
            label = "抗拉强度 Tensile strength (MPa) 123 − μ α β"
            for row, weight in enumerate(("normal", "medium", "bold")):
                figure.text(0.05, 0.8 - row * 0.3, label, fontweight=weight)
                resolved = font_manager.findfont(
                    font_manager.FontProperties(family=family, weight=weight),
                    fallback_to_default=False,
                )
                charmap = font_manager.get_font(resolved).get_charmap()
                self.assertTrue(all(ord(character) in charmap for character in label))
            with warnings.catch_warnings(record=True) as captured:
                warnings.simplefilter("always")
                for extension in ("png", "svg", "pdf"):
                    with self.subTest(extension=extension):
                        output = io.BytesIO()
                        figure.savefig(output, format=extension)
                        self.assertGreater(len(output.getvalue()), 100)
            missing = [str(item.message) for item in captured if "missing from font" in str(item.message)]
            self.assertEqual(missing, [])

    def test_all_build_paths_include_fonts_and_their_license(self):
        spec = (ROOT / "EasyGraph.spec").read_text(encoding="utf-8")
        macos = (ROOT / "scripts" / "build_and_smoke_macos.sh").read_text(encoding="utf-8")
        windows = (ROOT / "scripts" / "build_and_smoke_windows.ps1").read_text(encoding="utf-8")
        self.assertIn("('src/easygraph/resources/fonts', 'easygraph/resources/fonts')", spec)
        self.assertIn('--add-data "src/easygraph/resources/fonts:easygraph/resources/fonts"', macos)
        self.assertIn('--add-data "src\\easygraph\\resources\\fonts;easygraph\\resources\\fonts"', windows)


if __name__ == "__main__":
    unittest.main()
