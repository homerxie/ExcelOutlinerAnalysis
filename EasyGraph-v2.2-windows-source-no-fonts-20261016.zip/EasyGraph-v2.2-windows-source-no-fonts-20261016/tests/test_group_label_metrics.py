from __future__ import annotations

import io
import math
from pathlib import Path
import unittest

import matplotlib
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.font_manager import FontProperties
import numpy as np

from easygraph.plotting.group_label_metrics import (
    normal_center_offset_points,
    position_rotated_label,
    text_ink_bounds_points,
    text_width_points,
    wrap_label,
)


FONT = Path(__file__).resolve().parents[1] / "src/easygraph/resources/fonts/source-han-sans/SourceHanSansSC-Regular.otf"


class GroupLabelMetricsTests(unittest.TestCase):
    def setUp(self):
        self.font = FontProperties(fname=str(FONT), size=16)

    def make_label(self, text, *, rotation=45, dpi=144, **kwargs):
        figure = Figure(figsize=(4, 4), dpi=dpi, facecolor=(1, 1, 1, 0))
        canvas = FigureCanvasAgg(figure)
        label = figure.text(
            0.5, 0.5, text, fontproperties=self.font, rotation=rotation,
            rotation_mode="anchor", ha="right" if rotation >= 0 else "left",
            va="baseline", color="black", **kwargs,
        )
        return figure, canvas, label

    def assert_no_text_lost(self, original, wrapped):
        self.assertEqual(wrapped.replace("\n", ""), original.replace("\n", ""))

    def test_advance_width_uses_actual_glyphs_and_font_size(self):
        self.assertGreater(text_width_points("WWW", self.font), text_width_points("iii", self.font) * 2)
        larger = self.font.copy()
        larger.set_size(32)
        self.assertAlmostEqual(text_width_points("强度 MPa", larger), 2 * text_width_points("强度 MPa", self.font))
        self.assertEqual(text_width_points("", self.font), 0)

    def test_english_words_are_kept_together_and_spaces_are_preserved(self):
        original = "Alpha beta gamma"
        width = text_width_points("gamma ", self.font) + 0.01
        wrapped = wrap_label(original, width, self.font)
        self.assertEqual([line.strip() for line in wrapped.split("\n")], ["Alpha", "beta", "gamma"])
        self.assert_no_text_lost(original, wrapped)
        self.assertTrue(all(text_width_points(line, self.font) <= width for line in wrapped.split("\n")))

    def test_space_at_exact_word_boundary_does_not_create_an_empty_line(self):
        width = text_width_points("Alpha", self.font)
        wrapped = wrap_label("Alpha beta", width, self.font)
        self.assertEqual(wrapped, "Alpha \nbeta")

    def test_explicit_newlines_and_empty_lines_survive_wrapping(self):
        original = "强度\n\nTensile strength\n"
        wrapped = wrap_label(original, text_width_points("Tensile ", self.font) + 0.01, self.font)
        self.assertTrue(wrapped.startswith("强度\n\n"))
        self.assertTrue(wrapped.endswith("\n"))
        self.assert_no_text_lost(original, wrapped)
        self.assertEqual(wrap_label(original, 0, self.font), original)

    def test_cjk_punctuation_stays_with_neighboring_text(self):
        original = "长期循环（强度），测量结果。"
        width = text_width_points("长期循", self.font)
        wrapped = wrap_label(original, width, self.font)
        self.assert_no_text_lost(original, wrapped)
        for line in wrapped.split("\n"):
            self.assertNotIn(line[0], "），。")
            self.assertNotIn(line[-1], "（")
            self.assertLessEqual(text_width_points(line, self.font), width + 1e-8)

    def test_tiny_width_and_long_words_never_lose_characters(self):
        for original in ("Supercalifragilistic", "（强度）", "e\u0301e\u0301", "长期循环"):
            wrapped = wrap_label(original, 0.01, self.font)
            self.assert_no_text_lost(original, wrapped)
            self.assertTrue(all(not line.startswith("\u0301") for line in wrapped.split("\n")))

    def test_math_expression_is_not_split_or_measured_as_dollar_characters(self):
        expression = r"$\frac{x^2}{y}$"
        original = "强度 " + expression + " MPa"
        wrapped = wrap_label(original, text_width_points("强度 ", self.font), self.font)
        self.assertIn(expression, wrapped)
        self.assert_no_text_lost(original, wrapped)
        self.assertNotAlmostEqual(
            text_width_points(expression, self.font),
            text_width_points(expression, self.font, parse_math=False),
        )

    def test_normal_correction_centers_rendered_ink_for_both_angles_and_multiline(self):
        for rotation in (45, -45, 70):
            for text in ("强度 MPa", "长期循环\nStrength (MPa)", r"强度 $x^2$"):
                with self.subTest(rotation=rotation, text=text):
                    figure, canvas, label = self.make_label(text, rotation=rotation, linespacing=1.5)
                    renderer = canvas.get_renderer()
                    position_rotated_label(label, renderer)
                    canvas.draw()
                    rgba = np.asarray(canvas.buffer_rgba())
                    rows, columns = np.nonzero(rgba[:, :, 3] > 32)
                    theta = math.radians(rotation)
                    projections = -math.sin(theta) * (columns + 0.5) + math.cos(theta) * (rgba.shape[0] - rows - 0.5)
                    anchor = figure.transFigure.transform(label.get_position())
                    expected = -math.sin(theta) * anchor[0] + math.cos(theta) * anchor[1]
                    self.assertAlmostEqual((projections.min() + projections.max()) / 2, expected, delta=1.6)

    def test_correction_is_idempotent_and_scales_when_export_dpi_changes(self):
        figure, canvas, label = self.make_label("强度 MPa", rotation=45)
        renderer = canvas.get_renderer()
        correction = position_rotated_label(label, renderer)
        first = label.get_transform().transform(label.get_position())
        self.assertNotEqual(correction, 0)
        position_rotated_label(label, renderer)
        np.testing.assert_allclose(label.get_transform().transform(label.get_position()), first)
        figure.set_dpi(288)
        np.testing.assert_allclose(label.get_transform().transform(label.get_position()), first * 2)
        canvas.draw()
        self.assertEqual(label.get_text(), "强度 MPa")
        with matplotlib.rc_context({"svg.fonttype": "none"}):
            result = io.StringIO()
            figure.savefig(result, format="svg")
        self.assertIn("<text", result.getvalue())
        self.assertIn("强度 MPa", result.getvalue())

    def test_empty_ink_is_safe_and_font_changes_are_remeasured(self):
        figure, canvas, label = self.make_label("  \n ")
        renderer = canvas.get_renderer()
        self.assertIsNone(text_ink_bounds_points(label, renderer))
        self.assertEqual(normal_center_offset_points(label, renderer), 0)
        label.set_text("强度 MPa")
        before = normal_center_offset_points(label, renderer)
        label.set_fontsize(32)
        self.assertAlmostEqual(normal_center_offset_points(label, renderer), before * 2)

    def test_literal_dollars_respect_parse_math_false(self):
        figure, canvas, label = self.make_label("$x^2$", parse_math=False)
        renderer = canvas.get_renderer()
        literal = text_ink_bounds_points(label, renderer)
        label.set_parse_math(True)
        parsed = text_ink_bounds_points(label, renderer)
        self.assertGreater(literal.width, parsed.width)


if __name__ == "__main__":
    unittest.main()
