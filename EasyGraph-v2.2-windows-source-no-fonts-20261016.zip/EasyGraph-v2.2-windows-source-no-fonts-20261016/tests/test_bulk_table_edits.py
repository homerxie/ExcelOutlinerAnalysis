from unittest import mock

from PySide6.QtCore import QItemSelection, QItemSelectionModel, Qt

from easygraph.data_table import DataTable
from easygraph.table_clipboard import (
    clear_selected_table_items,
    paste_rows_into_table,
    selected_table_cells,
)
from easygraph.table_model import EasyGraphTableModel
from tests.easygraph_case import EasyGraphQtTestCase


class BulkTableEditTests(EasyGraphQtTestCase):
    def test_bulk_write_coalesces_view_update_and_preserves_recovery_events(self):
        model = EasyGraphTableModel()
        model.replace_cells([["A", "B"], ["1", "2"], ["3", "4"]])
        view_updates = []
        edits = []
        model.dataChanged.connect(
            lambda first, last, roles: view_updates.append(
                ((first.row(), first.column()), (last.row(), last.column()), roles)
            )
        )
        model.cellEdited.connect(lambda *edit: edits.append(edit))
        revision = model.revision

        self.assertTrue(model.set_cells_text([
            (1, 0, "10"), (2, 1, "40"), (0, 0, "A"), (-1, 0, "ignored"),
        ]))

        self.assertEqual(model.cells_copy(), [["A", "B"], ["10", "2"], ["3", "40"]])
        self.assertEqual(edits, [(1, 0, "1", "10"), (2, 1, "4", "40")])
        self.assertEqual(view_updates, [((1, 0), (2, 1), [Qt.DisplayRole, Qt.EditRole, Qt.BackgroundRole])])
        self.assertEqual(model.revision, revision + 2)

    def test_bulk_noop_does_not_notify_or_advance_revision(self):
        model = EasyGraphTableModel()
        model.replace_cells([["A", ""]])
        view_updates, edits = mock.Mock(), mock.Mock()
        model.dataChanged.connect(view_updates)
        model.cellEdited.connect(edits)
        revision = model.revision

        self.assertFalse(model.set_cells_text([(0, 0, "A"), (0, 1, ""), (10, 10, "x")]))

        view_updates.assert_not_called()
        edits.assert_not_called()
        self.assertEqual(model.revision, revision)

    def test_disjoint_clear_preserves_unselected_cells_without_expanding_indexes(self):
        table = DataTable()
        self.addCleanup(table.deleteLater)
        model = table.table_model
        model.replace_cells([["A", "B", "C"], ["1", "2", "3"], ["4", "5", "6"]])
        selection_model = table.selectionModel()
        selection_model.select(
            QItemSelection(model.index(0, 0), model.index(1, 0)),
            QItemSelectionModel.ClearAndSelect,
        )
        selection_model.select(
            QItemSelection(model.index(1, 2), model.index(2, 2)),
            QItemSelectionModel.Select,
        )
        view_updates = mock.Mock()
        model.dataChanged.connect(view_updates)

        with mock.patch.object(selection_model, "selectedIndexes", side_effect=AssertionError("expanded selection")):
            self.assertEqual(set(selected_table_cells(table)), {(0, 0), (1, 0), (1, 2), (2, 2)})
            self.assertTrue(clear_selected_table_items(table))

        self.assertEqual(model.cells_copy(), [["", "B", "C"], ["", "2", ""], ["4", "5", ""]])
        view_updates.assert_called_once()

    def test_select_all_clear_notifies_view_once_for_large_block(self):
        table = DataTable()
        self.addCleanup(table.deleteLater)
        model = table.table_model
        model.replace_cells([["value"] * 20 for _ in range(500)])
        table.selectAll()
        edits = []
        view_updates = mock.Mock()
        model.cellEdited.connect(lambda *edit: edits.append(edit))
        model.dataChanged.connect(view_updates)

        with mock.patch.object(model, "set_cell_text", side_effect=AssertionError("per-cell view mutation")):
            self.assertTrue(clear_selected_table_items(table))

        view_updates.assert_called_once()
        self.assertEqual(len(edits), 10000)
        self.assertTrue(all(not any(row) for row in model.cells_copy()))

    def test_bulk_paste_preserves_ragged_rows_and_initializes_headers(self):
        table = DataTable()
        self.addCleanup(table.deleteLater)
        model = table.table_model
        model.replace_cells([["A", "", "C"], ["old1", "old2", "old3"], ["keep1", "keep2", "keep3"]])
        view_updates = mock.Mock()
        model.dataChanged.connect(view_updates)

        with mock.patch.object(model, "set_cell_text", side_effect=AssertionError("per-cell view mutation")):
            paste_rows_into_table(table, [["new1", "new2"], ["last"]], 1, 1)

        self.assertEqual(model.cells_copy(), [
            ["A", "Group 2", "C"], ["old1", "new1", "new2"], ["keep1", "last", "keep3"],
        ])
        view_updates.assert_called_once()
