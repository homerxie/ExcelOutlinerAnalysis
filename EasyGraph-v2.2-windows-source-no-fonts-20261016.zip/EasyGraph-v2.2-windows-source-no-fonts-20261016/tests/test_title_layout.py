from __future__ import annotations

import copy
import io
from pathlib import Path
import unittest

import matplotlib
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.font_manager import FontProperties
import numpy as np

from easygraph.plotting.title_layout import (
    fit_axis_titles,
    measured_text_bounds,
    wrap_vertical_title,
)


FONT = Path(__file__).resolve().parents[1] / "src/easygraph/resources/fonts/source-han-sans/SourceHanSansSC-Regular.otf"


class TitleLayoutTests(unittest.TestCase):
    def make_figure(self, *, dpi=144):
        figure = Figure(figsize=(4, 3), dpi=dpi)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_axes((0.17, 0.2, 0.67, 0.62))
        ax.plot((0, 1), (0, 1))
        self.style_titles(ax)
        return figure, canvas, ax

    def style_titles(self, ax):
        for artist in (ax.title, ax.xaxis.label, ax.yaxis.label):
            artist.set_fontproperties(FontProperties(fname=str(FONT), size=16))

    def settle(self, figure, canvas, axes):
        canvas.draw()
        for _ in range(5):
            result = fit_axis_titles(figure, axes, canvas.get_renderer())
            if not result.changed and not result.needs_expansion:
                return
            if result.needs_expansion:
                width, height = figure.bbox.size
                left, right, bottom, top = result.margins
                positions = {ax: ax.get_position().frozen() for ax in figure.axes}
                new_width, new_height = width + left + right, height + bottom + top
                figure.set_size_inches(new_width / figure.dpi, new_height / figure.dpi)
                for ax, position in positions.items():
                    ax.set_position((
                        (position.x0 * width + left) / new_width,
                        (position.y0 * height + bottom) / new_height,
                        position.width * width / new_width,
                        position.height * height / new_height,
                    ))
            canvas.draw()
        self.fail("Title layout did not settle after five measurement draws")

    def assert_inside(self, bbox, container, *, margin=0, tolerance=1e-5):
        self.assertGreaterEqual(bbox.x0, container.x0 + margin - tolerance)
        self.assertGreaterEqual(bbox.y0, container.y0 + margin - tolerance)
        self.assertLessEqual(bbox.x1, container.x1 - margin + tolerance)
        self.assertLessEqual(bbox.y1, container.y1 - margin + tolerance)

    def test_long_title_and_xlabel_expand_canvas_preserving_axes_and_table_size(self):
        figure, canvas, ax = self.make_figure()
        table = figure.add_axes((0.17, 0.03, 0.67, 0.07))
        table.axis("off")
        title = "很长的大标题：混合中文与 English WWW iii 123 " * 3
        xlabel = "横坐标轴标题 Measurement conditions " * 4
        ax.set_title(title, fontproperties=ax.title.get_fontproperties())
        ax.set_xlabel(xlabel, fontproperties=ax.xaxis.label.get_fontproperties())
        before = {item: item.get_window_extent().size for item in (ax, table)}
        self.settle(figure, canvas, (ax,))
        self.assertGreater(figure.get_figwidth(), 4)
        self.assertEqual(ax.title.get_text(), title)
        self.assertEqual(ax.xaxis.label.get_text(), xlabel)
        margin = canvas.get_renderer().points_to_pixels(3)
        for artist in (ax.title, ax.xaxis.label):
            self.assert_inside(measured_text_bounds(artist, canvas.get_renderer()), figure.bbox, margin=margin)
        for item in (ax, table):
            np.testing.assert_allclose(item.get_window_extent().size, before[item])

    def test_vertical_titles_wrap_into_axis_height_without_hitting_horizontal_titles(self):
        sources = (
            "纵轴标题包含很多汉字并且应当换行以保持它在坐标轴区域内" * 2,
            "Measured response after multiple consecutive treatment cycles " * 3,
            "LongWordWithoutAnySpaces" * 7,
            "已有换行\n\nSecond paragraph with words and punctuation（实验）。\n",
        )
        for source in sources:
            with self.subTest(source=source):
                figure, canvas, ax = self.make_figure()
                ax.set_title("整个图片的大标题 " * 6, fontproperties=ax.title.get_fontproperties())
                ax.set_xlabel("横轴标题 Measurement " * 6, fontproperties=ax.xaxis.label.get_fontproperties())
                ax.set_ylabel(source, fontproperties=ax.yaxis.label.get_fontproperties())
                before_height = ax.get_window_extent().height
                self.settle(figure, canvas, (ax,))
                renderer = canvas.get_renderer()
                ybounds = measured_text_bounds(ax.yaxis.label, renderer)
                self.assertIn("\n", ax.yaxis.label.get_text())
                self.assertEqual(ax.yaxis.label.get_text().replace("\n", ""), source.replace("\n", ""))
                self.assertGreaterEqual(ybounds.y0, ax.bbox.y0 + renderer.points_to_pixels(3) - 0.01)
                self.assertLessEqual(ybounds.y1, ax.bbox.y1 - renderer.points_to_pixels(3) + 0.01)
                self.assertFalse(ybounds.overlaps(measured_text_bounds(ax.title, renderer)))
                self.assertFalse(ybounds.overlaps(measured_text_bounds(ax.xaxis.label, renderer)))
                self.assert_inside(ybounds, figure.bbox, margin=renderer.points_to_pixels(3))
                self.assertAlmostEqual(ax.bbox.height, before_height)

    def test_twinned_and_split_axes_have_independent_vertical_limits(self):
        for split in (False, True):
            with self.subTest(split=split):
                figure, canvas, ax = self.make_figure()
                if split:
                    ax.set_position((0.17, 0.2, 0.67, 0.26))
                    second = figure.add_axes((0.17, 0.61, 0.67, 0.23))
                else:
                    second = ax.twinx()
                self.style_titles(second)
                ax.set_ylabel("主坐标轴的中文标题 " * 6, fontproperties=ax.yaxis.label.get_fontproperties())
                second.set_ylabel("SecondaryAxisVeryLongTitle" * 6, fontproperties=second.yaxis.label.get_fontproperties())
                second.set_title("分区图的大标题 " * 6, fontproperties=second.title.get_fontproperties())
                self.settle(figure, canvas, (ax, second))
                for target in (ax, second):
                    bbox = measured_text_bounds(target.yaxis.label, canvas.get_renderer())
                    self.assertGreaterEqual(bbox.y0, target.bbox.y0 - 0.01)
                    self.assertLessEqual(bbox.y1, target.bbox.y1 + 0.01)
                    self.assert_inside(bbox, figure.bbox)

    def test_wrap_restarts_from_original_after_dpi_height_or_text_change(self):
        figure, canvas, ax = self.make_figure()
        source = "循环测试标题 long words " * 3
        ax.set_ylabel(source, fontproperties=ax.yaxis.label.get_fontproperties())
        canvas.draw()
        renderer = canvas.get_renderer()
        self.assertTrue(wrap_vertical_title(ax.yaxis.label, renderer, 100))
        narrow = ax.yaxis.label.get_text()
        wrap_vertical_title(ax.yaxis.label, renderer, 1000)
        self.assertLess(ax.yaxis.label.get_text().count("\n"), narrow.count("\n"))
        ax.yaxis.label.set_text("新标题")
        wrap_vertical_title(ax.yaxis.label, renderer, 1000)
        self.assertEqual(ax.yaxis.label.get_text(), "新标题")
        clone = copy.copy(ax.yaxis.label)
        clone.set_text(source)
        wrap_vertical_title(clone, renderer, 100)
        self.assertEqual(ax.yaxis.label.get_text(), "新标题")
        self.assertIn("\n", clone.get_text())

    def test_width_depends_on_actual_glyphs_and_zoom_remeasures_without_losing_text(self):
        widths = []
        for text in ("W" * 40, "i" * 40):
            figure, canvas, ax = self.make_figure()
            ax.set_title(text, fontproperties=ax.title.get_fontproperties())
            self.settle(figure, canvas, (ax,))
            widths.append(figure.get_figwidth())
            figure.set_dpi(288)
            self.settle(figure, canvas, (ax,))
            self.assert_inside(measured_text_bounds(ax.title, canvas.get_renderer()), figure.bbox)
            self.assertEqual(ax.title.get_text(), text)
        self.assertGreater(widths[0], widths[1] * 1.4)

    def test_long_tick_labels_expand_only_canvas(self):
        figure, canvas, ax = self.make_figure()
        ax.set_xlim(0, 1)
        ax.set_xticks((0, 1))
        ax.set_xticklabels(("左边很长的横坐标 " * 6, "Long right coordinate " * 8))
        for label in ax.get_xticklabels():
            label.set_fontproperties(FontProperties(fname=str(FONT), size=14))
        before = ax.get_window_extent().size
        self.settle(figure, canvas, (ax,))
        for label in ax.get_xticklabels():
            self.assert_inside(measured_text_bounds(label, canvas.get_renderer()), figure.bbox)
        np.testing.assert_allclose(ax.get_window_extent().size, before)

    def test_invisible_axes_do_not_reserve_title_or_tick_space(self):
        figure, canvas, ax = self.make_figure()
        ax.set_xlabel("Hidden horizontal title " * 30)
        ax.set_ylabel("Hidden vertical title " * 30)
        ax.set_xticks((0, 1), ("Hidden tick " * 30, "Hidden tick " * 30))
        ax.xaxis.set_visible(False)
        ax.yaxis.set_visible(False)
        canvas.draw()
        result = fit_axis_titles(figure, (ax,), canvas.get_renderer())
        self.assertFalse(result.needs_expansion)
        self.assertFalse(result.changed)

    def test_indivisible_math_preserves_expression_and_separates_horizontal_titles(self):
        figure, canvas, ax = self.make_figure()
        expression = "$" + "abcdefghijklmnopqrstuvwxy" * 2 + "$"
        ax.set_ylabel(expression, fontproperties=ax.yaxis.label.get_fontproperties())
        ax.set_title("Large main title " * 10, fontproperties=ax.title.get_fontproperties())
        ax.set_xlabel("Large horizontal title " * 10, fontproperties=ax.xaxis.label.get_fontproperties())
        before = ax.get_window_extent().size
        self.settle(figure, canvas, (ax,))
        renderer = canvas.get_renderer()
        ybounds = measured_text_bounds(ax.yaxis.label, renderer)
        self.assertEqual(ax.yaxis.label.get_text(), expression)
        self.assert_inside(ybounds, figure.bbox)
        for artist in (ax.title, ax.xaxis.label):
            self.assertFalse(ybounds.overlaps(measured_text_bounds(artist, renderer)))
            self.assert_inside(measured_text_bounds(artist, renderer), figure.bbox)
        np.testing.assert_allclose(ax.get_window_extent().size, before)

    def test_measured_bounds_enclose_actual_pixels_for_multiline_rotated_and_italic_text(self):
        for rotation in (0, 90, 270, 45):
            for mode in ("default", "anchor"):
                with self.subTest(rotation=rotation, mode=mode):
                    figure = Figure(figsize=(4, 4), dpi=144, facecolor=(1, 1, 1, 0))
                    canvas = FigureCanvasAgg(figure)
                    label = figure.text(
                        0.5, 0.5, "Italic ffff\nWider line", fontsize=24,
                        fontstyle="italic", rotation=rotation, rotation_mode=mode,
                        ha="center", va="center", color="black",
                    )
                    canvas.draw()
                    pixels = np.asarray(canvas.buffer_rgba())
                    rows, columns = np.nonzero(pixels[:, :, 3] > 0)
                    bounds = measured_text_bounds(label, canvas.get_renderer())
                    self.assertGreaterEqual(columns.min(), bounds.x0 - 2)
                    self.assertLessEqual(columns.max() + 1, bounds.x1 + 2)
                    self.assertGreaterEqual(pixels.shape[0] - rows.max() - 1, bounds.y0 - 2)
                    self.assertLessEqual(pixels.shape[0] - rows.min(), bounds.y1 + 2)

    def test_rotated_cjk_parenthesis_bearing_is_measured_from_actual_agg_bitmap(self):
        text = "相对于初始基准强度的变化百\n分比与长期可靠性评价结果\n（经过温度和湿度校正）"
        for dpi in (140, 280):
            for rotation in (0, 90, 270, 45):
                with self.subTest(dpi=dpi, rotation=rotation):
                    figure = Figure(figsize=(6, 6), dpi=dpi, facecolor=(1, 1, 1, 0))
                    canvas = FigureCanvasAgg(figure)
                    label = figure.text(
                        0.5, 0.5, text,
                        fontproperties=FontProperties(fname=str(FONT), size=12),
                        rotation=rotation, rotation_mode="anchor", ha="center", va="bottom",
                    )
                    canvas.draw()
                    pixels = np.asarray(canvas.buffer_rgba())
                    rows, columns = np.nonzero(pixels[:, :, 3] > 0)
                    bounds = measured_text_bounds(label, canvas.get_renderer())
                    self.assertGreaterEqual(columns.min(), bounds.x0)
                    self.assertLessEqual(columns.max() + 1, bounds.x1)
                    self.assertGreaterEqual(pixels.shape[0] - rows.max() - 1, bounds.y0)
                    self.assertLessEqual(pixels.shape[0] - rows.min(), bounds.y1)

    def test_rotated_cjk_title_keeps_measured_gap_from_left_and_right_ticks(self):
        text = "相对于初始基准强度的变化百\n分比与长期可靠性评价结果\n（经过温度和湿度校正）"
        for side in ("left", "right"):
            with self.subTest(side=side):
                figure, canvas, ax = self.make_figure(dpi=140)
                ax.set_ylabel(text, fontproperties=FontProperties(fname=str(FONT), size=12))
                ax.yaxis.set_label_position(side)
                ax.yaxis.set_ticks_position(side)
                self.settle(figure, canvas, (ax,))
                renderer = canvas.get_renderer()
                bounds = measured_text_bounds(ax.yaxis.label, renderer)
                low, high = sorted(ax.get_ylim())
                ticks = [
                    tick.label1 if side == "left" else tick.label2
                    for tick in ax.yaxis.get_major_ticks()
                    if low <= tick.get_loc() <= high
                ]
                tick_bounds = [measured_text_bounds(label, renderer) for label in ticks]
                margin = renderer.points_to_pixels(3)
                if side == "left":
                    self.assertLessEqual(bounds.x1, min(box.x0 for box in tick_bounds) - margin)
                else:
                    self.assertGreaterEqual(bounds.x0, max(box.x1 for box in tick_bounds) + margin)

    def test_svg_keeps_wrapped_titles_as_editable_text(self):
        figure, canvas, ax = self.make_figure()
        ax.set_ylabel("纵轴标题中文 English " * 4, fontproperties=ax.yaxis.label.get_fontproperties())
        self.settle(figure, canvas, (ax,))
        with matplotlib.rc_context({"svg.fonttype": "none"}):
            output = io.StringIO()
            figure.savefig(output, format="svg")
        self.assertIn("<text", output.getvalue())
        self.assertIn("纵轴标题中文", output.getvalue())


if __name__ == "__main__":
    unittest.main()
