"""Reject unsupported Excel header levels before changing the existing table."""
from __future__ import annotations

from unittest import mock

import pandas as pd
from PySide6.QtWidgets import QApplication, QMessageBox

from easygraph.ui.table_clipboard_mime import set_table_clipboard_mime
from tests.easygraph_case import EasyGraphQtTestCase


def three_header_row_excel_table(data_rows: int) -> tuple[str, str]:
    """A three-column Excel range with merges in both of the first two rows."""
    values = [[str(row), str(row + 1), str(row + 2)] for row in range(data_rows)]
    text_rows = [["Experiment", "", ""], ["Treatment", "", "Control"],
                 ["A", "B", "C"], *values]
    text = "\n".join("\t".join(row) for row in text_rows)
    html = (
        '<html xmlns:x="urn:schemas-microsoft-com:office:excel"><body>'
        '<!--StartFragment--><table><tr><td colspan="3">Experiment</td></tr>'
        '<tr><td colspan="2">Treatment</td><td>Control</td></tr>'
        '<tr><td>A</td><td>B</td><td>C</td></tr>'
        + "".join("<tr>" + "".join(f"<td>{value}</td>" for value in row) + "</tr>"
                  for row in values)
        + '</table><!--EndFragment--></body></html>'
    )
    return text, html


class MultilevelClipboardRejectionTests(EasyGraphQtTestCase):
    def test_copying_from_last_merged_header_preserves_two_levels_and_data(self):
        window = self.make_window()
        self.addCleanup(QApplication.clipboard().clear)
        window.set_table_dataframe(pd.DataFrame({"Old A": ["10"], "Old B": ["20"]}))
        controller = window._table_controller
        controller.reset_history()
        window.table.setCurrentIndex(window.table.table_model.index(0, 0))
        before = controller.snapshot()
        text, html = three_header_row_excel_table(300)
        text = text.split("\n", 1)[1]
        html = html.replace('<tr><td colspan="3">Experiment</td></tr>', '')
        set_table_clipboard_mime(text, html)

        with mock.patch.object(QMessageBox, "information") as information:
            window.paste_table_selection(window.table)

        information.assert_not_called()
        model = window.table.table_model
        self.assertEqual(model.cells_copy()[0][:3], ["A", "B", "C"])
        self.assertEqual(model.cells_copy()[1][:3], ["0", "1", "2"])
        self.assertEqual(model.cells_copy()[300][:3], ["299", "300", "301"])
        self.assertEqual([parent['name'] for parent in window.workbook.active_sheet.grouping.parents], ["Treatment", "Control"])
        self.assertEqual(len(controller.history.undo_stack), 1)
        controller.undo()
        self.assertEqual(controller.snapshot()["cells"], before["cells"])
        self.assertEqual(controller.snapshot()["grouping"], before["grouping"])

    def test_three_header_rows_warn_before_changing_table_or_history(self):
        window = self.make_window()
        self.addCleanup(QApplication.clipboard().clear)
        window.set_table_dataframe(pd.DataFrame({"Old A": ["10"], "Old B": ["20"]}))
        controller = window._table_controller
        controller.reset_history()
        window.table.setCurrentIndex(window.table.table_model.index(0, 0))
        before = controller.snapshot()

        for data_rows in (100, 300):
            with self.subTest(data_rows=data_rows):
                set_table_clipboard_mime(*three_header_row_excel_table(data_rows))

                with mock.patch.object(QMessageBox, "information") as information:
                    window.paste_table_selection(window.table)

                information.assert_called_once_with(
                    window,
                    window.tr("Paste table"),
                    window.tr(
                        "Only two header levels are supported. Merged cells must be horizontal "
                        "and in the first copied row. Copy only the last merged header row, "
                        "the column names, and the data, or unmerge extra cells in Excel."
                    ),
                )
                self.assertEqual(controller.snapshot(), before)
                self.assertFalse(controller.history.can_undo)
                self.assertFalse(controller.history.can_redo)
