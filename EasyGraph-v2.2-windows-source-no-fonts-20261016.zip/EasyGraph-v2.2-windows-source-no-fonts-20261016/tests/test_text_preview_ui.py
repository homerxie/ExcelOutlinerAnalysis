from __future__ import annotations

from unittest import mock

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QFocusEvent, QInputMethodEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.ui import main_window


class TextPreviewUiTests(EasyGraphQtTestCase):
    def test_text_fields_preview_immediately_without_reading_other_controls(self):
        window = self.make_window()

        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True) as preview,
            mock.patch.object(window, "render") as render,
            mock.patch.object(window, "custom_overlay_series_from_table") as overlay_rows,
            mock.patch.object(window, "_update_dependent_control_states") as inspector,
            mock.patch.object(window, "_commit_pending_control_edits") as commit_controls,
        ):
            for name in ("title", "x_label", "y_label", "secondary_y_label"):
                with self.subTest(field=name):
                    editor = getattr(window, name)
                    editor.setPlainText(f"Updated {name}")
                    self.assertEqual(getattr(window.settings, name), f"Updated {name}")
                    preview.assert_called_with(window.settings)
                    self.assertTrue(window._render_timer.isActive())
                    self.assertEqual(window._render_timer.interval(), 300)
                    self.assertEqual(window._scheduled_render_mode, main_window.RenderMode.FULL)
                    render.assert_not_called()
            overlay_rows.assert_not_called()
            inspector.assert_not_called()
            commit_controls.assert_not_called()
            window.flush_pending_render()
            render.assert_called_once_with()

    def test_full_render_waits_for_300_ms_after_the_last_edit(self):
        window = self.make_window()
        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True),
            mock.patch.object(window, "render") as render,
        ):
            window.title.setPlainText("First")
            QTest.qWait(190)
            window.title.setPlainText("Latest")
            QTest.qWait(190)
            render.assert_not_called()
            QTest.qWait(160)
            render.assert_called_once_with()
            self.assertFalse(window._render_pending)

    def test_ime_pauses_pending_render_until_committed_text_settles(self):
        window = self.make_window()
        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True) as preview,
            mock.patch.object(window, "render") as render,
        ):
            window.title.setPlainText("Title ")
            QApplication.sendEvent(window.title, QInputMethodEvent("zhong", []))
            self.assertFalse(window._render_timer.isActive())
            window.schedule_render()
            self.assertFalse(window._render_timer.isActive())
            QTest.qWait(350)
            render.assert_not_called()

            committed = QInputMethodEvent()
            committed.setCommitString("中")
            QApplication.sendEvent(window.title, committed)
            self.qapp.processEvents()
            self.assertIn("中", window.settings.title)
            preview.assert_called_with(window.settings)
            self.assertTrue(window._render_timer.isActive())
            self.assertEqual(window._render_timer.interval(), 300)
            QTest.qWait(190)
            render.assert_not_called()
            QTest.qWait(160)
            render.assert_called_once_with()

    def test_cancelled_composition_resumes_an_existing_pending_render(self):
        window = self.make_window()
        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True),
            mock.patch.object(window, "render") as render,
        ):
            window.title.setPlainText("Committed text")
            QApplication.sendEvent(window.title, QInputMethodEvent("pinyin", []))
            QApplication.sendEvent(window.title, QInputMethodEvent())
            self.qapp.processEvents()
            self.assertTrue(window._render_timer.isActive())
            self.assertEqual(window._render_timer.interval(), 300)
            window.flush_pending_render()
            render.assert_called_once_with()

    def test_focus_loss_flushes_pending_text_without_waiting_for_debounce(self):
        window = self.make_window()
        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True),
            mock.patch.object(window, "render") as render,
        ):
            window.title.setPlainText("Final title")
            QApplication.sendEvent(window.title, QFocusEvent(QEvent.Type.FocusOut))
            self.qapp.processEvents()
            render.assert_called_once_with()
            self.assertFalse(window._render_timer.isActive())

    def test_composition_popup_does_not_trigger_a_focus_loss_render(self):
        window = self.make_window()
        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True),
            mock.patch.object(window, "render") as render,
        ):
            window.title.setPlainText("Title")
            QApplication.sendEvent(window.title, QInputMethodEvent("pinyin", []))
            QApplication.sendEvent(
                window.title,
                QFocusEvent(QEvent.Type.FocusOut, Qt.FocusReason.PopupFocusReason),
            )
            self.qapp.processEvents()
            render.assert_not_called()
            self.assertFalse(window._render_timer.isActive())
            self.assertIn(window.title, window._text_composing_editors)

    def test_queued_focus_loss_does_not_flush_a_new_ime_composition(self):
        window = self.make_window()
        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True),
            mock.patch.object(window, "render") as render,
        ):
            window.title.setPlainText("Title")
            QApplication.sendEvent(window.title, QFocusEvent(QEvent.Type.FocusOut))
            QApplication.sendEvent(window.title, QFocusEvent(QEvent.Type.FocusIn))
            QApplication.sendEvent(window.title, QInputMethodEvent("pinyin", []))
            self.qapp.processEvents()
            render.assert_not_called()
            self.assertFalse(window._render_timer.isActive())
            self.assertIn(window.title, window._text_composing_editors)

            committed = QInputMethodEvent()
            committed.setCommitString("拼音")
            QApplication.sendEvent(window.title, committed)
            self.qapp.processEvents()
            self.assertIn("拼音", window.settings.title)
            self.assertEqual(window._render_timer.interval(), 300)
            self.assertTrue(window._render_timer.isActive())
            window.flush_pending_render()
            render.assert_called_once_with()

    def test_unavailable_preview_still_defers_one_full_render(self):
        window = self.make_window()
        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=False),
            mock.patch.object(window, "render") as render,
        ):
            window.title.setPlainText("No existing rendered axes")
            render.assert_not_called()
            self.assertTrue(window._render_pending)
            window.flush_pending_render()
            render.assert_called_once_with()

    def test_export_commits_ime_and_renders_before_taking_the_snapshot(self):
        window = self.make_window()
        calls = []

        def commit_composition():
            calls.append("commit")
            committed = QInputMethodEvent()
            committed.setCommitString("中")
            QApplication.sendEvent(window.title, committed)

        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True),
            mock.patch.object(window, "render", side_effect=lambda: calls.append("render")),
            mock.patch.object(window.canvas, "export", side_effect=lambda *_args: calls.append("export")),
            mock.patch.object(
                main_window.QFileDialog, "getSaveFileName", return_value=("/tmp/title-preview.png", "PNG Image (*.png)")
            ),
            mock.patch.object(QApplication.inputMethod(), "commit", side_effect=commit_composition),
        ):
            window.title.setPlainText("Export ")
            QApplication.sendEvent(window.title, QInputMethodEvent("zhong", []))
            window.export_figure()
            self.assertEqual(calls, ["commit", "render", "export"])
            self.assertIn("中", window.settings.title)
            self.assertFalse(window._render_pending)

    def test_copy_renders_latest_title_before_taking_the_snapshot(self):
        window = self.make_window()
        calls = []
        with (
            mock.patch.object(window.canvas, "preview_text_settings", return_value=True),
            mock.patch.object(window, "render", side_effect=lambda: calls.append("render")),
            mock.patch.object(
                window.canvas, "copy_to_clipboard", side_effect=lambda *_args: calls.append("copy") or True
            ),
        ):
            window.title.setPlainText("Latest copied title")
            window.copy_figure_image()
            self.assertEqual(calls, ["render", "copy"])
            self.assertFalse(window._render_pending)
