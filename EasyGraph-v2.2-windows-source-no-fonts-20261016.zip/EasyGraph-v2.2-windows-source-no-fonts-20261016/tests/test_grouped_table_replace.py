from copy import deepcopy
from dataclasses import asdict
from unittest import mock

from PySide6.QtGui import QKeySequence
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from easygraph.clipboard_table import (
    CellMerge,
    ClipboardTable,
    clipboard_table_to_html,
    clipboard_table_to_tsv,
)
from easygraph.ui.main_window import MainWindow
from easygraph.ui.table_clipboard_mime import set_table_clipboard_mime
from easygraph.workbook import SHEET_MODE_GROUPS
from tests.easygraph_case import EasyGraphQtTestCase, patch_qsettings


class GroupedTableReplaceTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        template = mock.patch.object(MainWindow, "_style_template_for_new_sheet", return_value=(None, None))
        template.start()
        self.addCleanup(template.stop)
        preferences, _values = patch_qsettings()
        preferences.start()
        self.addCleanup(preferences.stop)
        self.addCleanup(QApplication.clipboard().clear)

    def grouped_window(self):
        window = self.make_window()
        window.initialize_startup_project(SHEET_MODE_GROUPS, demo=True, grouped_demo=True)
        window.table_tools.activate(window.table)
        window._table_controller.reset_history()
        return window

    def assert_shared_plot(self, window):
        window.render()
        sheet = window.workbook.active_sheet
        layout = window.canvas._group_layout
        self.assertTrue(sheet.grouping.shared_subgroups)
        self.assertEqual([parent.label for parent in layout.parents], ["WT", "KO"])
        self.assertEqual([label for label, _color in layout.legend], ["Control", "Low dose", "High dose"])
        for index in range(3):
            first, second = sheet.column_ids[index], sheet.column_ids[index + 3]
            self.assertEqual(sheet.grouping.subgroup_ids[first], sheet.grouping.subgroup_ids[second])
            self.assertEqual(layout.colors[first], layout.colors[second])
        return dict(layout.legend)

    def test_select_all_clear_includes_parent_text_and_undo_redo_preserve_structure(self):
        window = self.grouped_window()
        table = window.table
        before_cells = table.table_model.cells_copy()
        before_grouping = asdict(window.workbook.active_sheet.grouping)
        expected_empty = deepcopy(before_grouping)
        for parent in expected_empty["parents"]:
            parent["name"] = ""
        window.show()
        table.setFocus()
        self.qapp.processEvents()
        QTest.keySequence(table, QKeySequence(QKeySequence.SelectAll))
        self.assertEqual(
            sum(selected.width() * selected.height() for selected in table.selectionModel().selection()),
            table.table_model.rowCount() * table.table_model.columnCount(),
        )

        QTest.keySequence(table, QKeySequence(QKeySequence.Delete))

        self.assertEqual(asdict(window.workbook.active_sheet.grouping), expected_empty)
        self.assertEqual([label for _key, label, _rect in table.horizontalHeader().group_rects()], ["", ""])
        self.assertTrue(all(not any(row) for row in table.table_model.cells_copy()[window.sample_start_row():]))
        self.assertEqual(len(window._table_controller.history.undo_stack), 1)
        window.undo_table_change()
        self.assertEqual(asdict(window.workbook.active_sheet.grouping), before_grouping)
        self.assertEqual([label for _key, label, _rect in table.horizontalHeader().group_rects()], ["WT", "KO"])
        self.assertEqual(table.table_model.cells_copy(), before_cells)
        window.redo_table_change()
        self.assertEqual(asdict(window.workbook.active_sheet.grouping), expected_empty)
        self.assertEqual([label for _key, label, _rect in table.horizontalHeader().group_rects()], ["", ""])

    def test_clear_then_excel_replacement_keeps_shared_colors_and_single_legend_entries(self):
        window = self.grouped_window()
        table = window.table
        sheet = window.workbook.active_sheet
        window.settings.custom_colors[sheet.column_ids[1]] = "#c2185b"
        original_colors = self.assert_shared_plot(window)
        table.selectAll()
        copied = window._table_controller.copy_selection_data(column_limit=6)
        # Excel's HTML contains merged cells but no EasyGraph header metadata.
        external = ClipboardTable(copied.rows, copied.merges)
        window.clear_table_selection(table)
        window.undo_table_change()
        self.assertEqual(self.assert_shared_plot(window), original_colors)
        window.redo_table_change()
        self.assertTrue(all(parent["name"] == "" for parent in sheet.grouping.parents))
        blank_cells = table.table_model.cells_copy()
        blank_grouping = asdict(sheet.grouping)
        table.setCurrentIndex(table.table_model.index(0, 0))
        set_table_clipboard_mime(clipboard_table_to_tsv(external), clipboard_table_to_html(external))

        window.paste_table_selection(table)

        self.assertEqual(self.assert_shared_plot(window), original_colors)
        self.assertEqual(table.table_model.cells_copy()[0][:6], ["Control", "Low dose", "High dose"] * 2)
        self.assertEqual(len(window._table_controller.history.undo_stack), 2)
        window.undo_table_change()
        self.assertEqual(table.table_model.cells_copy(), blank_cells)
        self.assertEqual(asdict(sheet.grouping), blank_grouping)
        window.redo_table_change()
        self.assertEqual(self.assert_shared_plot(window), original_colors)

    def test_clear_samples_does_not_change_either_header_level_or_shared_categories(self):
        window = self.grouped_window()
        table = window.table
        before_cells = table.table_model.cells_copy()
        before_grouping = asdict(window.workbook.active_sheet.grouping)
        self.select_table_range(table, window.sample_start_row(), 0,
                                table.table_model.rowCount() - 1, table.table_model.columnCount() - 1)

        window.clear_table_selection(table)

        self.assertEqual(asdict(window.workbook.active_sheet.grouping), before_grouping)
        self.assertEqual(table.table_model.cells_copy()[0], before_cells[0])
        self.assertTrue(all(not any(row) for row in table.table_model.cells_copy()[window.sample_start_row():]))
        window.undo_table_change()
        self.assertEqual(table.table_model.cells_copy(), before_cells)

    def test_excel_repeat_headers_on_fresh_sheet_enable_shared_colors_and_undo_atomically(self):
        window = self.make_window()
        window.initialize_startup_project(SHEET_MODE_GROUPS, demo=False)
        table = window.table
        sheet = window.workbook.active_sheet
        self.assertFalse(sheet.grouping.shared_subgroups)
        self.assertFalse(sheet.grouping.parents)
        window.settings.group_color_mode = "Parent"
        window._table_controller.reset_history()
        before_cells = table.table_model.cells_copy()
        table.setCurrentIndex(table.table_model.index(0, 0))
        external = ClipboardTable(
            [["WT", "", "", "KO", "", ""],
             ["Control", "Low dose", "High dose"] * 2,
             ["1", "2", "3", "4", "5", "6"],
             ["2", "3", "4", "5", "6", "7"]],
            [CellMerge(0, 0, colspan=3), CellMerge(0, 3, colspan=3)],
        )
        set_table_clipboard_mime(clipboard_table_to_tsv(external), clipboard_table_to_html(external))

        window.paste_table_selection(table)

        self.assertEqual(window.settings.group_color_mode, "Subgroup")
        expected_colors = self.assert_shared_plot(window)
        self.assertEqual(len(window._table_controller.history.undo_stack), 1)
        window.undo_table_change()
        self.assertFalse(sheet.grouping.shared_subgroups)
        self.assertFalse(sheet.grouping.parents)
        self.assertEqual(window.settings.group_color_mode, "Parent")
        self.assertEqual(table.table_model.cells_copy(), before_cells)
        window.redo_table_change()
        self.assertEqual(self.assert_shared_plot(window), expected_colors)

    def test_parent_header_only_clear_preserves_values_and_other_parent(self):
        window = self.grouped_window()
        table = window.table
        before_cells = table.table_model.cells_copy()
        before_grouping = asdict(window.workbook.active_sheet.grouping)
        expected = deepcopy(before_grouping)
        expected["parents"][0]["name"] = ""
        table.setCurrentIndex(table.table_model.index(window.sample_start_row(), 4))
        table.horizontalHeader().select_parent_columns([0])
        self.assertFalse(table.currentIndex().isValid())
        self.assertFalse(table.selectionModel().hasSelection())
        self.assertTrue(window.ui.tableClearButton.isEnabled())

        window.ui.tableClearButton.click()

        self.assertEqual(asdict(window.workbook.active_sheet.grouping), expected)
        self.assertEqual([label for _key, label, _rect in table.horizontalHeader().group_rects()], ["", "KO"])
        self.assertEqual(table.table_model.cells_copy(), before_cells)
        window.undo_table_change()
        self.assertEqual(asdict(window.workbook.active_sheet.grouping), before_grouping)
