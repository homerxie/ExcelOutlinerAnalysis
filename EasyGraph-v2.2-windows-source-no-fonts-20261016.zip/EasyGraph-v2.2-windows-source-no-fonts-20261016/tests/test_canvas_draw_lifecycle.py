from __future__ import annotations

from dataclasses import replace
from types import SimpleNamespace
import unittest
from unittest import mock

from matplotlib.backend_bases import Event, MouseEvent
import numpy as np
from PySide6.QtCore import QEvent, QPoint, QPointF, Qt
from PySide6.QtGui import QImage, QWheelEvent
from PySide6.QtWidgets import QApplication

from easygraph.data import sample_data
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings


def image_pixels(image):
    image = image.convertToFormat(QImage.Format.Format_RGBA8888)
    return np.frombuffer(image.bits(), np.uint8).reshape(image.height(), image.width(), 4).copy()


class CanvasDrawLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.chart = PlotCanvas()
        self.chart.resize(1400, 1000)
        self.chart.show()
        self.data = sample_data()
        self.settings = ChartSettings(width=15, height=10, title="Original canvas title",
                                      y_label="Value", show_stat_table=False, show_legend=False)
        self.chart.render(self.data, self.settings)
        self.app.processEvents()
        self.retired = []

    def tearDown(self):
        for widget in (*self.retired, self.chart):
            try:
                widget.close()
                widget.deleteLater()
            except RuntimeError:
                pass
        self.app.sendPostedEvents(None, QEvent.Type.DeferredDelete)

    def replace_canvas(self, settings):
        previous = self.chart.canvas
        # Reproduce the interval after replacement and before Qt delivers
        # DeferredDelete, independently of platform event-loop ordering.
        with mock.patch.object(previous, "deleteLater"):
            self.chart.render(self.data, settings)
        self.retired.append(previous)
        self.assertIsNot(previous, self.chart.canvas)
        return previous

    def test_retired_draw_cannot_mix_figures_or_replace_current_body_and_blit_cache(self):
        old_pixels = np.asarray(self.chart.canvas.buffer_rgba()).copy()
        old = self.replace_canvas(replace(self.settings, width=10, height=6, title="New canvas title"))
        body = image_pixels(self.chart._text_preview_background)
        blit = np.asarray(self.chart._blit_background).copy()
        current = np.asarray(self.chart.canvas.buffer_rgba()).copy()

        old.draw()

        with self.subTest(cache="body"):
            np.testing.assert_array_equal(image_pixels(self.chart._text_preview_background), body)
        with self.subTest(cache="blit"):
            np.testing.assert_array_equal(np.asarray(self.chart._blit_background), blit)
        with self.subTest(canvas="retired"):
            np.testing.assert_array_equal(np.asarray(old.buffer_rgba()), old_pixels)
        self.chart._redraw_interaction_artists()
        np.testing.assert_array_equal(np.asarray(self.chart.canvas.buffer_rgba()), current)

    def test_queued_draw_idle_from_before_zoom_does_not_publish_retired_pixels(self):
        old = self.chart.canvas
        old_pixels = np.asarray(old.buffer_rgba()).copy()
        with mock.patch.object(old, "deleteLater"), mock.patch.object(old, "draw", wraps=old.draw) as deferred_draw:
            old.draw_idle()
            self.chart.zoom_by(0.75)
            self.retired.append(old)
            self.assertIsNot(old, self.chart.canvas)
            current = np.asarray(self.chart.canvas.buffer_rgba()).copy()
            body = image_pixels(self.chart._text_preview_background)
            self.app.processEvents()
            self.assertGreater(deferred_draw.call_count, 0, "The queued retired draw was not exercised")

        np.testing.assert_array_equal(np.asarray(old.buffer_rgba()), old_pixels)
        np.testing.assert_array_equal(image_pixels(self.chart._text_preview_background), body)
        self.chart._redraw_interaction_artists()
        np.testing.assert_array_equal(np.asarray(self.chart.canvas.buffer_rgba()), current)

    def test_retired_draw_after_title_expansion_preserves_selection_and_live_preview(self):
        previous_width = self.chart.canvas.width()
        settings = replace(self.settings, width=10, height=6, title="自动扩宽的图片标题 Long title " * 5)
        old = self.replace_canvas(settings)
        self.assertGreater(self.chart.canvas.width(), previous_width)
        target = next(item for item in self.chart._interaction_targets if item["kind"] == "plot_area")
        self.chart._set_feedback_patch("_selected_feedback_patch", target["bbox"], selected=True)
        selected_pixels = np.asarray(self.chart.canvas.buffer_rgba()).copy()
        edited = replace(settings, title="接着输入的新标题")
        self.assertTrue(self.chart.preview_text_settings(edited))
        preview_body = image_pixels(self.chart._text_preview_layer._background)
        preview_titles = [(sprite.left_px, sprite.top_px, image_pixels(sprite.image))
                          for sprite in self.chart._text_preview_layer._images]
        self.chart.finish_text_preview()

        old.draw()
        self.chart._redraw_interaction_artists()
        np.testing.assert_array_equal(np.asarray(self.chart.canvas.buffer_rgba()), selected_pixels)
        self.assertTrue(self.chart.preview_text_settings(edited))
        np.testing.assert_array_equal(image_pixels(self.chart._text_preview_layer._background), preview_body)
        for expected, actual in zip(preview_titles, self.chart._text_preview_layer._images):
            self.assertEqual((actual.left_px, actual.top_px), expected[:2])
            np.testing.assert_array_equal(image_pixels(actual.image), expected[2])


    def test_retired_pointer_events_preserve_current_hover_and_selection(self):
        old = self.replace_canvas(replace(self.settings, width=10, height=6))
        events = (
            Event("figure_leave_event", old),
            MouseEvent("motion_notify_event", old, 0, 0),
            MouseEvent("button_press_event", old, 0, 0, button=1),
        )
        for event in events:
            with self.subTest(event=event.name):
                self.chart._hover_object_kind = "primary_axis"
                self.chart._hover_series_id = "current-hover"
                self.chart._selected_object_kind = "title_axis"
                with mock.patch.object(self.chart, "selection_callback") as selection:
                    old.callbacks.process(event.name, event)
                    selection.assert_not_called()
                self.assertEqual(self.chart._hover_object_kind, "primary_axis")
                self.assertEqual(self.chart._hover_series_id, "current-hover")
                self.assertEqual(self.chart._selected_object_kind, "title_axis")

    def test_retired_release_cannot_finish_a_current_figure_drag(self):
        old = self.replace_canvas(replace(self.settings, width=10, height=6))
        self.chart._fit_equation_drag_state = {"current_drag": True}
        event = MouseEvent("button_release_event", old, 0, 0, button=1)
        try:
            with (
                mock.patch.object(self.chart, "_drag_fit_equation_to_event") as drag,
                mock.patch.object(self.chart, "_finish_fit_equation_drag") as finish,
            ):
                old.callbacks.process(event.name, event)
                drag.assert_not_called()
                finish.assert_not_called()
        finally:
            self.chart._fit_equation_drag_state = None

    def test_control_wheel_only_zooms_the_current_canvas(self):
        old = self.replace_canvas(replace(self.settings, width=10, height=6))

        def wheel_event():
            return QWheelEvent(
                QPointF(10, 10), QPointF(10, 10), QPoint(), QPoint(0, 120),
                Qt.MouseButton.NoButton, Qt.KeyboardModifier.ControlModifier,
                Qt.ScrollPhase.NoScrollPhase, False,
            )

        with mock.patch.object(self.chart, "zoom_by") as zoom:
            retired_event = wheel_event()
            old.wheelEvent(retired_event)
            zoom.assert_not_called()
            self.assertFalse(retired_event.isAccepted())
            current_event = wheel_event()
            self.chart.canvas.wheelEvent(current_event)
            zoom.assert_called_once_with(1.12)
            self.assertTrue(current_event.isAccepted())

    def test_current_and_canvas_free_events_keep_existing_interactions(self):
        for canvas_fields in ({}, {"canvas": self.chart.canvas}):
            with self.subTest(has_canvas=bool(canvas_fields)):
                event = SimpleNamespace(x=0, y=0, button=1, **canvas_fields)
                self.chart._hover_object_kind = "primary_axis"
                self.chart._handle_plot_motion(event)
                self.assertIsNone(self.chart._hover_object_kind)
                self.chart._hover_object_kind = "primary_axis"
                self.chart._handle_plot_leave(event)
                self.assertIsNone(self.chart._hover_object_kind)
                with mock.patch.object(self.chart, "clear_plot_selection") as clear:
                    self.chart._handle_plot_click(event)
                    clear.assert_called_once_with()
                self.chart._fit_equation_drag_state = {"current_drag": True}
                try:
                    with (
                        mock.patch.object(self.chart, "_drag_fit_equation_to_event") as drag,
                        mock.patch.object(self.chart, "_finish_fit_equation_drag") as finish,
                    ):
                        self.chart._handle_plot_release(event)
                        drag.assert_called_once_with(event)
                        finish.assert_called_once_with()
                finally:
                    self.chart._fit_equation_drag_state = None


if __name__ == "__main__":
    unittest.main()
