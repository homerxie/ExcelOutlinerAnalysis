from __future__ import annotations

from dataclasses import asdict
from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory

import matplotlib
import numpy as np
import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.grouping import GroupingSettings
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings


class GroupAxisLayoutRenderingTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.ids = [f"column-{index}" for index in range(6)]
        self.frame = pd.DataFrame(
            [[1 + index, 2 + index, 3 + index] for index in range(6)],
            index=["短时强度 Strength (MPa)", "长期循环后强度 Retention (%)", "Control", "Low dose", "High dose", "Recovery"],
        ).T
        self.grouping = GroupingSettings(parents=[
            {"id": "narrow", "name": "高温高湿环境下长期可靠性验证试验第一阶段", "column_ids": self.ids[:2]},
            {"id": "wide", "name": "常规实验与恢复阶段 Reference and recovery", "column_ids": self.ids[2:]},
        ])
        self.canvas = PlotCanvas()
        self.addCleanup(self.canvas.close)

    def render(self, mode="Bottom", angle=45, **kwargs):
        settings = ChartSettings(
            group_axis_label_layout=mode, x_tick_rotation=angle,
            width=16, height=7, group_inner_spacing=0.45, group_outer_spacing=2.7,
            show_points=False, title="中英混排 Axis layout", **kwargs,
        )
        before = asdict(settings)
        self.canvas.render(self.frame, settings, grouping=self.grouping, column_ids=self.ids)
        self.assertEqual(asdict(settings), before)
        return self.canvas.figure.axes[0]

    def texts(self, ax):
        return [text for text in ax.texts if text.get_gid() == "group-parent-label"]

    def test_default_wrap_keeps_short_names_horizontal_and_wraps_only_long_labels(self):
        ax = self.render("Wrap", 0)
        labels = ax.get_xticklabels()
        self.assertIn("\n", labels[0].get_text())
        self.assertEqual(labels[2].get_text(), "Control")
        self.assertTrue(all(label.get_rotation() == 0 for label in labels))
        self.assertFalse(any(line.get_gid() == "group-parent-guide" for line in ax.lines))
        for old, label in zip(self.frame.columns, labels):
            self.assertEqual(old, label.get_text().replace("\n", ""))

    def test_slanted_guides_connect_real_cell_edges_to_equal_width_brackets(self):
        ax = self.render()
        layout = self.canvas._group_layout
        brackets = [line for line in ax.lines if line.get_gid() == "group-parent-bracket"]
        guides = [line for line in ax.lines if line.get_gid() == "group-parent-guide"]
        self.assertEqual(len(guides), 4)
        shifts = []
        for index, (parent, bracket, title) in enumerate(zip(layout.parents, brackets, self.texts(ax))):
            actual = bracket.get_transform().transform(bracket.get_xydata())
            bounds = [parent.start - layout.inner_spacing / 2, parent.end + layout.inner_spacing / 2]
            expected = ax.transData.transform([(bounds[0], 0), (bounds[1], 0)])
            self.assertAlmostEqual(actual[1, 0] - actual[0, 0], expected[1, 0] - expected[0, 0])
            self.assertAlmostEqual(title.get_transform().transform(title.get_position())[0], actual[:, 0].mean())
            for edge_index in range(2):
                guide = guides[index * 2 + edge_index]
                line = guide.get_transform().transform(guide.get_xydata())
                np.testing.assert_allclose(line[1], actual[edge_index], atol=1e-6)
                self.assertAlmostEqual(line[0, 0], expected[edge_index, 0])
                self.assertAlmostEqual((line[1, 1] - line[0, 1]) / (line[1, 0] - line[0, 0]), 1)
                shifts.append(line[1] - line[0])
        np.testing.assert_allclose(shifts, np.tile(shifts[0], (4, 1)), atol=1e-6)
        titles = self.texts(ax)
        self.assertGreater(titles[0].get_text().count("\n"), 1)
        renderer = self.canvas.canvas.get_renderer()
        tops = [title.get_window_extent(renderer).y1 for title in titles]
        self.assertAlmostEqual(tops[0], tops[1])
        self.assertLess(titles[0].get_window_extent(renderer).x1, titles[1].get_window_extent(renderer).x0)

    def test_top_mode_places_parents_above_both_secondary_axis_arrangements(self):
        for split in (False, True):
            with self.subTest(split=split):
                ax = self.render("Top", 45, extra_custom_overlay=True,
                                 custom_overlay_secondary_axis=True, split_secondary_axis=split,
                                 title_font_size=19,
                                 custom_overlay_series=[{"name": "Response", "values": dict(zip(self.ids, [10, 20, 30, 40, 50, 60]))}])
                renderer = self.canvas.canvas.get_renderer()
                secondary = next(axis for axis in self.canvas.figure.axes if axis.get_gid() == "secondary-axis")
                parent_bounds = [text.get_window_extent(renderer) for text in self.texts(ax)]
                self.assertGreater(min(bound.y0 for bound in parent_bounds), secondary.get_window_extent(renderer).y1)
                host = secondary if split else ax
                self.assertGreater(host.title.get_window_extent(renderer).y0, max(bound.y1 for bound in parent_bounds))
                self.assertEqual(host.title.get_fontsize(), 19)
                self.assertFalse(any(line.get_gid() == "group-parent-guide" for line in ax.lines))
                self.assertTrue(all(label.get_rotation() == 45 for label in ax.get_xticklabels()))

    def test_top_labels_clear_scientific_axis_offsets(self):
        self.frame *= 100000000
        ax = self.render("Top", 45)
        renderer = self.canvas.canvas.get_renderer()
        offset = ax.yaxis.get_offset_text()
        self.assertTrue(offset.get_text())
        bracket_bottom = min(line.get_window_extent(renderer).y0 for line in ax.lines
                             if line.get_gid() == "group-parent-bracket")
        self.assertGreater(bracket_bottom, offset.get_window_extent(renderer).y1)

    def test_shallow_angles_use_bounded_leaders_instead_of_expanding_the_page(self):
        for angle in (1, 5, -1, -5):
            with self.subTest(angle=angle):
                ax = self.render("Bottom", angle)
                self.assertLess(self.canvas.figure.get_figwidth() * 2.54, 33)
                guides = [line for line in ax.lines if line.get_gid() == "group-parent-guide"]
                for guide in guides:
                    vertices = guide.get_transform().transform(guide.get_xydata())
                    self.assertEqual(len(vertices), 3)
                    self.assertAlmostEqual(vertices[1, 0], vertices[2, 0])
                    self.assertLess(vertices[2, 1], vertices[1, 1])
                    slope = (vertices[1, 1] - vertices[0, 1]) / (vertices[1, 0] - vertices[0, 0])
                    self.assertAlmostEqual(slope, np.tan(np.deg2rad(angle)))

    def test_ridge_legend_only_still_hides_subgroup_tick_text(self):
        self.grouping.shared_subgroups = True
        self.grouping.subgroup_ids = dict(zip(self.ids, self.ids))
        settings = ChartSettings(chart_type="Ridge", group_label_mode="Legend only", show_legend=True)
        self.canvas.render(self.frame, settings, grouping=self.grouping, column_ids=self.ids)
        self.assertTrue(all(not label.get_text() for label in self.canvas.figure.axes[0].get_yticklabels()))

    def test_bottom_parent_labels_axis_title_and_statistics_never_overlap_or_clip(self):
        for angle in (30, 45, 90, -45):
            with self.subTest(angle=angle):
                ax = self.render("Bottom", angle, show_stat_table=True, show_stat_mean=True)
                renderer = self.canvas.canvas.get_renderer()
                table = self.canvas.figure.axes[1]
                labels = [*self.texts(ax), *ax.get_xticklabels(), ax.xaxis.label]
                bounds = [label.get_window_extent(renderer) for label in labels]
                self.assertGreater(min(bound.y0 for bound in bounds), table.get_window_extent(renderer).y1)
                for bound in bounds:
                    self.assertGreaterEqual(bound.x0, 0)
                    self.assertGreaterEqual(bound.y0, 0)
                    self.assertLessEqual(bound.x1, self.canvas.figure.bbox.width)
                parent_low = min(text.get_window_extent(renderer).y0 for text in self.texts(ax))
                self.assertLess(ax.xaxis.label.get_window_extent(renderer).y1, parent_low)

    def test_wrapped_leaf_labels_clear_statistics_in_both_horizontal_modes(self):
        for mode in ("Wrap", "Top"):
            with self.subTest(mode=mode):
                ax = self.render(mode, 0, show_stat_table=True, show_stat_mean=True)
                renderer = self.canvas.canvas.get_renderer()
                table_top = self.canvas.figure.axes[1].get_window_extent(renderer).y1
                self.assertIn("\n", ax.get_xticklabels()[0].get_text())
                for label in [*ax.get_xticklabels(), ax.xaxis.label]:
                    self.assertGreater(label.get_window_extent(renderer).y0, table_top)

    def test_single_level_horizontal_labels_wrap_without_parent_artists(self):
        for chart_type in ("Box", "Bar", "Violin"):
            for show_table in (False, True):
                with self.subTest(chart_type=chart_type, show_table=show_table):
                    settings = ChartSettings(
                        chart_type=chart_type, width=12, height=7, x_tick_rotation=0,
                        show_points=False, show_stat_table=show_table, show_stat_mean=True,
                    )
                    before = asdict(settings)
                    self.canvas.render(self.frame, settings, column_ids=self.ids)
                    self.assertEqual(asdict(settings), before)
                    ax = self.canvas.figure.axes[0]
                    renderer = self.canvas.canvas.get_renderer()
                    labels = ax.get_xticklabels()
                    self.assertTrue(any("\n" in label.get_text() for label in labels[:2]))
                    self.assertEqual(labels[2].get_text(), "Control")
                    for original, label in zip(self.frame.columns, labels):
                        self.assertEqual(original, label.get_text().replace("\n", ""))
                        self.assertEqual(label.get_rotation(), 0)
                        self.assertEqual(label.get_horizontalalignment(), "center")
                        self.assertEqual(label.get_fontproperties().get_name(), "Source Han Sans SC")
                    self.assertFalse(self.canvas._group_axis_artists)
                    self.assertFalse(self.texts(ax))
                    self.assertFalse(any((line.get_gid() or "").startswith("group-parent-") for line in ax.lines))
                    bounds = [label.get_window_extent(renderer) for label in labels]
                    for left, right in zip(bounds, bounds[1:]):
                        self.assertLess(left.x1, right.x0)
                    for bound in [*bounds, ax.xaxis.label.get_window_extent(renderer)]:
                        self.assertGreaterEqual(bound.x0, 0)
                        self.assertGreaterEqual(bound.y0, 0)
                        self.assertLessEqual(bound.x1, self.canvas.figure.bbox.width)
                        if show_table:
                            self.assertGreater(bound.y0, self.canvas.figure.axes[1].get_window_extent(renderer).y1)

    def test_single_level_ignores_parent_mode_without_changing_actual_rotation(self):
        for mode in ("Wrap", "Bottom", "Top"):
            for angle in (0, 45, -45):
                with self.subTest(mode=mode, angle=angle):
                    settings = ChartSettings(
                        width=12, height=7, group_axis_label_layout=mode,
                        x_tick_rotation=angle, show_points=False,
                    )
                    self.canvas.render(self.frame, settings, column_ids=self.ids)
                    ax = self.canvas.figure.axes[0]
                    labels = ax.get_xticklabels()
                    self.assertTrue(all(label.get_rotation() == angle % 360 for label in labels))
                    self.assertFalse(self.canvas._group_axis_artists)
                    self.assertFalse(self.texts(ax))
                    if angle:
                        self.assertEqual([label.get_text() for label in labels], list(self.frame.columns))
                        for label in labels:
                            self.assertEqual(label.get_verticalalignment(), "baseline")
                            self.assertIs(label.get_transform(), label._group_ink_corrected_transform)
                    else:
                        self.assertTrue(any("\n" in label.get_text() for label in labels))

    def test_single_level_explicit_line_breaks_survive_wrapping_and_ridge_stays_unchanged(self):
        self.frame.columns = ["长期循环后\nTensile strength (MPa)", *self.frame.columns[1:]]
        for chart_type in ("Box", "Ridge"):
            with self.subTest(chart_type=chart_type):
                settings = ChartSettings(chart_type=chart_type, width=12, height=7, x_tick_rotation=0)
                self.canvas.render(self.frame, settings, column_ids=self.ids)
                ax = self.canvas.figure.axes[0]
                labels = ax.get_yticklabels() if chart_type == "Ridge" else ax.get_xticklabels()
                if chart_type == "Ridge":
                    self.assertEqual([label.get_text() for label in labels], list(self.frame.columns))
                    self.assertIsNone(self.canvas._group_axis_labels)
                else:
                    self.assertIn("长期循环后\n", labels[0].get_text())
                    for original, label in zip(self.frame.columns, labels):
                        self.assertEqual(original.replace("\n", ""), label.get_text().replace("\n", ""))

    def test_one_category_does_not_restore_an_overlong_label_to_one_line(self):
        original = "长期循环后抗拉强度 Tensile strength (MPa) " * 5
        frame = self.frame.iloc[:, :1].copy()
        frame.columns = [original]
        settings = ChartSettings(width=8, height=7, x_tick_rotation=0, show_points=False)
        self.canvas.render(frame, settings)
        ax = self.canvas.figure.axes[0]
        label = ax.get_xticklabels()[0]
        self.assertIn("\n", label.get_text())
        self.assertEqual(label.get_text().replace("\n", ""), original)
        renderer = self.canvas.canvas.get_renderer()
        self.assertLess(label.get_window_extent(renderer).width, ax.get_window_extent(renderer).width)

    def test_single_level_wrapping_is_stable_across_dpi_and_export_formats(self):
        settings = ChartSettings(width=12, height=7, x_tick_rotation=0, show_points=False)
        self.canvas.render(self.frame, settings, column_ids=self.ids)
        ax = self.canvas.figure.axes[0]
        original_labels = [label.get_text() for label in ax.get_xticklabels()]
        original_dpi = self.canvas.figure.dpi
        anchors = [label.get_transform().transform(label.get_position()) / original_dpi
                   for label in ax.get_xticklabels()]
        with TemporaryDirectory() as folder, matplotlib.rc_context({"svg.fonttype": "none"}):
            for dpi in (72, 300):
                self.canvas.figure.set_dpi(dpi)
                self.canvas.figure.canvas.draw()
                for expected, label in zip(anchors, ax.get_xticklabels()):
                    np.testing.assert_allclose(label.get_transform().transform(label.get_position()) / dpi, expected)
                self.assertEqual([label.get_text() for label in ax.get_xticklabels()], original_labels)
                for suffix in ("png", "svg", "pdf"):
                    path = Path(folder) / f"single-{dpi}.{suffix}"
                    self.canvas.export(str(path), ChartSettings(dpi=dpi))
                    self.assertGreater(path.stat().st_size, 1000)
                svg = (Path(folder) / f"single-{dpi}.svg").read_text()
                self.assertIn("<text", svg)
                for label in original_labels:
                    for line in label.split("\n"):
                        self.assertIn(line, svg)
        self.canvas.figure.set_dpi(original_dpi)

    def test_export_dpi_keeps_guide_and_bracket_geometry_and_editable_svg_text(self):
        ax = self.render()
        lines = [line for line in ax.lines if line.get_gid() in {"group-parent-guide", "group-parent-bracket"}]
        original_dpi = self.canvas.figure.dpi
        original = [line.get_transform().transform(line.get_xydata()) / original_dpi for line in lines]
        self.canvas.figure.set_dpi(300)
        self.canvas.figure.canvas.draw()
        for expected, line in zip(original, lines):
            np.testing.assert_allclose(line.get_transform().transform(line.get_xydata()) / 300, expected, atol=1e-6)
        with TemporaryDirectory() as folder, matplotlib.rc_context({"svg.fonttype": "none"}):
            for suffix in ("png", "svg", "pdf"):
                path = Path(folder) / f"chart.{suffix}"
                self.canvas.export(str(path), ChartSettings(dpi=300))
                self.assertGreater(path.stat().st_size, 1000)
            self.assertIn("<text", (Path(folder) / "chart.svg").read_text())
        self.canvas.figure.set_dpi(original_dpi)
