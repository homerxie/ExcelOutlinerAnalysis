from __future__ import annotations

from dataclasses import replace
from types import SimpleNamespace
import unittest
from unittest import mock

import numpy as np
from PySide6.QtCore import QEvent
from PySide6.QtWidgets import QApplication

from easygraph.data import sample_data
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings


class PlotInteractionResizeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.chart = PlotCanvas()
        self.chart.resize(1100, 800)
        self.settings = ChartSettings(
            title="首次显示前已经绘制的中文标题", x_label="横坐标分组", y_label="纵轴测量结果",
            show_stat_table=False, width=10, height=6,
        )
        self.chart.render(sample_data(), self.settings)

    def tearDown(self):
        self.chart.close()
        self.chart.deleteLater()
        self.app.sendPostedEvents(None, QEvent.Type.DeferredDelete)

    def process_events(self):
        # Show/resize schedules the draw; its completed draw schedules one
        # hit-box refresh after deferred title painting has finished.
        for _ in range(3):
            self.app.processEvents()

    def title_target(self):
        return next(target for target in self.chart._interaction_targets if target["kind"] == "title_axis")

    def select_title(self):
        box = self.title_target()["hit_bboxes"][0]
        self.chart._handle_plot_selection_click(SimpleNamespace(
            x=(box.x0 + box.x1) / 2, y=(box.y0 + box.y1) / 2, button=1,
        ))
        self.assertEqual(self.chart._selected_object_kind, "title_axis")

    def assert_title_boxes_match_drawn_positions(self):
        renderer = self.chart.canvas.get_renderer()
        ax = self.chart.figure.axes[0]
        expected = [artist.get_window_extent(renderer).bounds
                    for artist in (ax.title, ax.xaxis.label, ax.yaxis.label)]
        actual = [box.bounds for box in self.title_target()["hit_bboxes"]]
        np.testing.assert_allclose(actual, expected, atol=1e-6)

    def test_initial_show_refreshes_hit_boxes_and_selection_at_current_dpi(self):
        # With QT_SCALE_FACTOR=2 this is an actual 140 -> 280 DPI transition;
        # at scale 1 it also exercises Qt's initial integer-pixel resize.
        self.select_title()
        self.chart.show()
        self.process_events()
        self.assert_title_boxes_match_drawn_positions()
        self.assertEqual(self.chart._selected_object_kind, "title_axis")
        for patch, box in zip(self.chart._selected_feedback_patch, self.title_target()["feedback_bboxes"]):
            x0, y0, x1, y1 = self.chart._bbox_to_figure_rect(box)
            expected = self.chart.figure.transFigure.transform(((x0, y0), (x1, y1)))
            np.testing.assert_allclose(patch.get_window_extent().get_points(), expected, atol=1e-6)

    def test_normal_draws_do_not_rebuild_hit_boxes_and_resize_refreshes_once(self):
        self.chart.show()
        self.process_events()
        self.select_title()
        with mock.patch.object(self.chart, "_refresh_interaction_targets", wraps=self.chart._refresh_interaction_targets) as refresh:
            for _ in range(3):
                self.chart.canvas.draw()
                self.process_events()
            self.assertEqual(refresh.call_count, 0)
            self.chart.canvas.setFixedSize(self.chart.canvas.width() + 20, self.chart.canvas.height() + 10)
            self.process_events()
            self.assertEqual(refresh.call_count, 1)
            self.assert_title_boxes_match_drawn_positions()
            self.chart.canvas.draw()
            self.process_events()
            self.assertEqual(refresh.call_count, 1)

    def test_retired_canvas_resize_and_queued_finish_preserve_current_state(self):
        retired = self.chart.canvas
        self.chart.render(sample_data(), replace(self.settings, width=13))
        self.assertIsNot(retired, self.chart.canvas)
        background = self.chart._blit_background
        self.assertIsNotNone(background)
        self.chart._blit_refresh_pending = True
        self.chart._handle_canvas_resize(SimpleNamespace(canvas=retired))
        self.chart._finish_canvas_draw_blit(retired)
        self.assertIs(self.chart._blit_background, background)
        self.assertTrue(self.chart._blit_refresh_pending)
        self.chart._handle_canvas_resize(None)
        self.assertIsNone(self.chart._blit_background)


if __name__ == "__main__":
    unittest.main()
