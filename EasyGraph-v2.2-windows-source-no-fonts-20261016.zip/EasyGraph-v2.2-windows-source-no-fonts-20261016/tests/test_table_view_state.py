from unittest import mock

import pandas as pd
from PySide6.QtCore import QItemSelection, QItemSelectionModel

from easygraph.data_table import DataTable
from tests.easygraph_case import EasyGraphQtTestCase


class TableViewStateTests(EasyGraphQtTestCase):
    def selected_cells(self, table):
        return {
            (index.row(), index.column())
            for index in table.selectionModel().selectedIndexes()
        }

    def test_large_selection_is_captured_as_ranges_and_restored_in_one_update(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({name: range(300) for name in ("A", "B", "C")}))
        table = window.table
        table.selectAll()
        selection_model = table.selectionModel()
        original_selection = self.selected_cells(table)
        selection_model.setCurrentIndex(table.model().index(20, 1), QItemSelectionModel.NoUpdate)
        with mock.patch.object(selection_model, "selectedIndexes", side_effect=AssertionError("expanded selection")):
            state = window._table_view_state(table)
        self.assertEqual(len(state["ranges"]), 1)
        selection_model.clearSelection()
        changed = mock.Mock()
        selection_model.selectionChanged.connect(changed)

        window._restore_table_view_state(table, state)

        changed.assert_called_once()
        self.assertEqual(self.selected_cells(table), original_selection)
        self.assertEqual((table.currentIndex().row(), table.currentIndex().column()), (20, 1))

    def test_disjoint_cell_selection_is_clipped_after_table_shrinks(self):
        window = self.make_window()
        table = DataTable(6, 5)
        self.addCleanup(table.deleteLater)
        model = table.model()
        selection_model = table.selectionModel()
        selection = QItemSelection(model.index(0, 0), model.index(1, 0))
        selection.select(model.index(2, 2), model.index(5, 4))
        selection_model.select(selection, QItemSelectionModel.ClearAndSelect)
        selection_model.setCurrentIndex(model.index(5, 4), QItemSelectionModel.NoUpdate)
        state = window._table_view_state(table)
        model.resize(4, 4)

        window._restore_table_view_state(table, state)

        self.assertEqual(self.selected_cells(table), {(0, 0), (1, 0), (2, 2), (2, 3), (3, 2), (3, 3)})
        self.assertEqual((table.currentIndex().row(), table.currentIndex().column()), (3, 3))

    def test_row_and_column_scopes_expand_with_new_table_shape(self):
        window = self.make_window()
        for scope in ("rows", "columns"):
            with self.subTest(scope=scope):
                table = DataTable(3, 3)
                self.addCleanup(table.deleteLater)
                model = table.model()
                self.select_table_range(table, 1, 1, 1, 1)
                window._table_selection_origins[table] = scope
                state = window._table_view_state(table)
                model.resize(5, 5)

                window._restore_table_view_state(table, state)

                expected = {(1, index) for index in range(5)} if scope == "rows" else {(index, 1) for index in range(5)}
                self.assertEqual(self.selected_cells(table), expected)
                self.assertEqual(window._table_selection_origins[table], scope)

    def test_empty_saved_selection_clears_existing_selection(self):
        window = self.make_window()
        table = DataTable(3, 3)
        self.addCleanup(table.deleteLater)
        state = window._table_view_state(table)
        table.selectAll()

        window._restore_table_view_state(table, state)

        self.assertFalse(table.selectionModel().hasSelection())
