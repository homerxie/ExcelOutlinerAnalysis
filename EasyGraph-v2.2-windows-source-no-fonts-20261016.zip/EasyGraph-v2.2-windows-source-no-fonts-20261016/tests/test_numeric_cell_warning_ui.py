"""Non-numeric clipboard cells remain editable while their warning stays current."""
from __future__ import annotations

from unittest import mock

import pandas as pd
from PySide6.QtCore import QMimeData, Qt
from PySide6.QtWidgets import QApplication

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.data import prepare_plot_frames
from easygraph.workbook import SHEET_MODE_XY


class NumericCellWarningUITests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.addCleanup(QApplication.clipboard().clear)

    def paste_text(self, window, table, text, *, row=1, column=0):
        table.setCurrentIndex(table.table_model.index(row, column))
        window.table_tools.activate(table)
        QApplication.clipboard().setText(text)
        window.paste_table_selection(table)

    def assert_warning(self, window, *, main=False, paired=False):
        self.assertEqual(not window.ui.nonNumericWarningLabel.isHidden(), main)
        self.assertEqual(not window.ui.xyNonNumericWarningLabel.isHidden(), paired)
        self.assertEqual(not window.ui.clearNonNumericButton.isHidden(), main)
        self.assertEqual(not window.ui.clearXYNonNumericButton.isHidden(), paired)
        for label in (window.ui.nonNumericWarningLabel, window.ui.xyNonNumericWarningLabel):
            self.assertEqual(
                label.text(),
                window.tr("Non-numeric characters found; automatically skipped."),
            )

    def test_tsv_paste_marks_only_invalid_samples_and_keeps_source_text(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Control": [""], "Drug": [""]}))
        window.reset_table_history()
        model = window.table.table_model
        text = "25%\tnot a number\n\t2\n-12.5 %\t80％"

        self.paste_text(window, window.table, text)

        self.assertEqual(model.invalid_numeric_cell_count, 1)
        self.assert_warning(window, main=True)
        warning_background = model.data(model.index(1, 1), Qt.BackgroundRole)
        self.assertIsNotNone(warning_background)
        self.assertNotEqual(warning_background.style(), Qt.NoBrush)
        self.assertNotEqual(warning_background, model.data(model.index(0, 1), Qt.BackgroundRole))
        for row, column in ((1, 0), (2, 0), (2, 1), (3, 0), (3, 1)):
            self.assertIsNone(model.data(model.index(row, column), Qt.BackgroundRole))

        plotted = prepare_plot_frames(window.table_dataframe(), window.settings)
        self.assertEqual(sorted(plotted.visible["value"].tolist()), [-0.125, 0.25, 0.8, 2.0])
        self.assertEqual(model.cell_text(1, 1), "not a number")
        self.select_table_range(window.table, 1, 0, 3, 1)
        window.copy_table_selection(window.table)
        self.assertEqual(QApplication.clipboard().text(), text)

        window.undo_table_change()
        self.assertEqual(model.invalid_numeric_cell_count, 0)
        self.assert_warning(window)
        window.redo_table_change()
        self.assertEqual(model.cell_text(1, 1), "not a number")
        self.assert_warning(window, main=True)

    def test_excel_merged_headers_are_not_warnings_and_edits_update_history(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Old": [""]}))
        window.reset_table_history()
        table = window.table
        model = table.table_model
        table.setCurrentIndex(model.index(0, 0))
        window.table_tools.activate(table)
        mime = QMimeData()
        mime.setText("Treatment\t\nControl\tDrug\n25%\tmissing\n\t50％")
        mime.setHtml(
            '<html xmlns:x="urn:schemas-microsoft-com:office:excel"><body>'
            '<table><tr><td colspan="2">Treatment</td></tr>'
            '<tr><td>Control</td><td>Drug</td></tr>'
            '<tr><td x:num="0.25">25%</td><td>missing</td></tr>'
            '<tr><td></td><td x:num="0.5">50％</td></tr></table>'
            '</body></html>'
        )
        QApplication.clipboard().setMimeData(mime)

        window.paste_table_selection(table)

        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]["name"], "Treatment")
        self.assertEqual(window.table_group_names(), ["Control", "Drug"])
        self.assertEqual(model.invalid_numeric_cell_count, 1)
        self.assert_warning(window, main=True)
        sample_row = window.sample_start_row()
        self.assertEqual(model.cell_text(sample_row, 1), "missing")

        model.setData(model.index(sample_row, 1), "1.5", Qt.EditRole)
        self.assert_warning(window)
        self.assertIsNone(model.data(model.index(sample_row, 1), Qt.BackgroundRole))
        window.undo_table_change()
        self.assertEqual(model.cell_text(sample_row, 1), "missing")
        self.assert_warning(window, main=True)
        window.redo_table_change()
        self.assert_warning(window)

        model.setData(model.index(sample_row, 1), "unavailable", Qt.EditRole)
        self.assert_warning(window, main=True)
        model.setData(model.index(sample_row, 1), "", Qt.EditRole)
        self.assertEqual(model.invalid_numeric_cell_count, 0)
        self.assert_warning(window)
        window.undo_table_change()
        self.assertEqual(model.cell_text(sample_row, 1), "unavailable")
        self.assert_warning(window, main=True)
        window.redo_table_change()
        self.assertEqual(model.cell_text(sample_row, 1), "")
        self.assert_warning(window)

    def test_clear_button_removes_all_invalid_cells_as_one_undoable_change(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Control": [""], "Drug": [""]}))
        text = "25%\tmissing\n缺失\t2\n\t80％"
        self.paste_text(window, window.table, text)
        window.reset_table_history()
        model = window.table.table_model
        original_cells = model.cells_copy()
        self.assertEqual(model.invalid_numeric_cell_count, 2)

        window.ui.clearNonNumericButton.click()

        self.assertEqual(model.cell_text(1, 1), "")
        self.assertEqual(model.cell_text(2, 0), "")
        self.assertEqual(model.cell_text(0, 0), "Control")
        self.assertEqual(model.cell_text(0, 1), "Drug")
        self.assertEqual(model.cell_text(1, 0), "25%")
        self.assertEqual(model.cell_text(2, 1), "2")
        self.assertEqual(model.cell_text(3, 0), "")
        self.assertEqual(model.cell_text(3, 1), "80％")
        self.assertEqual(model.invalid_numeric_cell_count, 0)
        self.assert_warning(window)
        self.assertEqual(len(window._table_controller.history.undo_stack), 1)

        window.undo_table_change()
        self.assertEqual(model.cells_copy(), original_cells)
        self.assertEqual(model.invalid_numeric_cell_count, 2)
        self.assert_warning(window, main=True)
        window.redo_table_change()
        self.assertEqual(model.cell_text(1, 1), "")
        self.assertEqual(model.cell_text(2, 0), "")
        self.assert_warning(window)

    def test_groups_and_xy_tables_keep_independent_warning_visibility(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Group": ["invalid group"]}))
        self.assert_warning(window, main=True)

        with mock.patch.object(window, "render"), mock.patch.object(window, "schedule_render"):
            window.add_sheet(SHEET_MODE_XY)
            self.assert_warning(window)

            self.paste_text(window, window.table, "1\tinvalid shared\n2\t3")
            self.assert_warning(window, main=True)
            self.paste_text(window, window.xy_independent_table, "invalid independent\t5\n6\t7")
            self.assert_warning(window, main=True, paired=True)

            window.ui.clearNonNumericButton.click()
            self.assertEqual(window.table.table_model.cell_text(1, 1), "")
            self.assertEqual(
                window.xy_independent_table.table_model.cell_text(1, 0), "invalid independent"
            )
            self.assert_warning(window, paired=True)
            window.undo_table_change()
            self.assertEqual(window.table.table_model.cell_text(1, 1), "invalid shared")
            self.assertEqual(
                window.xy_independent_table.table_model.cell_text(1, 0), "invalid independent"
            )
            self.assert_warning(window, main=True, paired=True)
            window.redo_table_change()
            self.assert_warning(window, paired=True)
            window.switch_sheet(0)
            self.assertEqual(window.table.table_model.cell_text(1, 0), "invalid group")
            self.assert_warning(window, main=True)

            window.switch_sheet(1)
            self.assert_warning(window, paired=True)
            paired_model = window.xy_independent_table.table_model
            self.assertEqual(paired_model.cell_text(1, 0), "invalid independent")
            window.ui.clearXYNonNumericButton.click()
            self.assertEqual(paired_model.cell_text(1, 0), "")
            self.assertEqual(paired_model.cell_text(1, 1), "5")
            self.assert_warning(window)
            window.undo_table_change()
            self.assertEqual(paired_model.cell_text(1, 0), "invalid independent")
            self.assertEqual(window.table.table_model.cell_text(1, 1), "")
            self.assert_warning(window, paired=True)
            window.redo_table_change()
            self.assertEqual(paired_model.cell_text(1, 0), "")
            self.assert_warning(window)
