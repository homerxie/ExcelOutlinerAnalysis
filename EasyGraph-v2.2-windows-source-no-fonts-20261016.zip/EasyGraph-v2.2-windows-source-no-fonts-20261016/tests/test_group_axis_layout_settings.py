from pathlib import Path
import tempfile
from types import SimpleNamespace

from PySide6.QtCore import QTranslator

from tests.easygraph_case import EasyGraphQtTestCase, EasyGraphTestCase
from easygraph.project_io import chart_settings_from_dict, read_project, write_project
from easygraph.settings import ChartSettings
from easygraph.template_io import read_style_template_file, write_style_template
from easygraph.workbook import SHEET_MODE_XY


class GroupAxisLayoutSettingsTests(EasyGraphTestCase):
    def test_default_and_legacy_layouts(self):
        self.assertEqual(ChartSettings().group_axis_label_layout, 'Wrap')
        self.assertEqual(ChartSettings(group_axis_label_layout='unknown').group_axis_label_layout, 'Wrap')
        self.assertEqual(chart_settings_from_dict({}).group_axis_label_layout, 'Wrap')
        self.assertEqual(chart_settings_from_dict({'x_tick_rotation': 60}).group_axis_label_layout, 'Bottom')
        explicit_top = chart_settings_from_dict({'group_axis_label_layout': 'Top', 'x_tick_rotation': 60})
        self.assertEqual(explicit_top.group_axis_label_layout, 'Top')
        self.assertEqual(explicit_top.x_tick_rotation, 60)

    def test_project_and_style_template_preserve_layout_and_angle(self):
        for layout, angle in [('Wrap', 0), ('Bottom', 45), ('Top', 60)]:
            with self.subTest(layout=layout), tempfile.TemporaryDirectory() as directory:
                settings = ChartSettings(group_axis_label_layout=layout, x_tick_rotation=angle)
                project = Path(directory) / 'layout.eg'
                write_project(project, self.df, settings)
                _, loaded = read_project(project)
                template = write_style_template('Layout', settings, Path(directory))
                styled = read_style_template_file(template)
                for restored in (loaded, styled):
                    self.assertEqual(restored.group_axis_label_layout, layout)
                    self.assertEqual(restored.x_tick_rotation, angle)


class GroupAxisLayoutControlsTests(EasyGraphQtTestCase):
    def make_grouped_window(self):
        window = self.make_window()
        self.select_table_range(window.table, 0, 0, 0, 1)
        self.assertTrue(window.grouping_controls.create_selected_parent('Experiment'))
        return window

    def choose_layout(self, window, layout):
        combo = window.group_axis_label_layout
        index = combo.findData(layout)
        self.assertGreaterEqual(index, 0)
        combo.setCurrentIndex(index)

    def test_layout_choices_update_angle_and_undo_as_one_edit(self):
        window = self.make_grouped_window()
        self.choose_layout(window, 'Bottom')
        self.assertEqual(window.settings.group_axis_label_layout, 'Bottom')
        self.assertEqual(window.settings.x_tick_rotation, 45)
        self.assertEqual(window.x_tick_rotation.value(), 45)

        self.choose_layout(window, 'Top')
        self.assertEqual(window.settings.group_axis_label_layout, 'Top')
        self.assertEqual(window.settings.x_tick_rotation, 45)

        self.choose_layout(window, 'Wrap')
        self.assertEqual(window.settings.group_axis_label_layout, 'Wrap')
        self.assertEqual(window.settings.x_tick_rotation, 0)
        self.assertEqual(window.x_tick_rotation.value(), 0)

        window.undo_table_change()
        self.assertEqual(window.settings.group_axis_label_layout, 'Top')
        self.assertEqual(window.settings.x_tick_rotation, 45)
        self.assertEqual(window.x_tick_rotation.value(), 45)
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Top')
        window.redo_table_change()
        self.assertEqual(window.settings.group_axis_label_layout, 'Wrap')
        self.assertEqual(window.settings.x_tick_rotation, 0)
        self.assertEqual(window.x_tick_rotation.value(), 0)
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Wrap')

    def test_changing_angle_switches_to_bottom_but_loading_top_does_not(self):
        window = self.make_grouped_window()
        window.settings.group_axis_label_layout = 'Top'
        window.settings.x_tick_rotation = 30
        window.apply_settings_to_controls()
        self.assertEqual(window.settings.group_axis_label_layout, 'Top')
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Top')
        window.update_settings()
        self.assertEqual(window.settings.group_axis_label_layout, 'Top')
        window.x_tick_rotation.setValue(60)
        self.assertEqual(window.settings.group_axis_label_layout, 'Bottom')
        self.assertEqual(window.settings.x_tick_rotation, 60)
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Bottom')
        window.x_tick_rotation.setValue(0)
        self.assertEqual(window.settings.group_axis_label_layout, 'Wrap')
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Wrap')
        self.choose_layout(window, 'Top')
        self.assertEqual(window.settings.x_tick_rotation, 0)
        self.assertEqual(window.settings.group_axis_label_layout, 'Top')

    def test_clicking_x_axis_exposes_layout_for_single_and_parent_headers(self):
        for grouped in (False, True):
            with self.subTest(grouped=grouped):
                window = self.make_grouped_window() if grouped else self.make_window()
                window.initialize_preview()
                target = next(target for target in window.canvas._interaction_targets
                              if target['kind'] == 'category_axis')
                box = target['hit_bboxes'][0]
                window.canvas._handle_plot_click(SimpleNamespace(
                    x=(box.x0 + box.x1) / 2, y=(box.y0 + box.y1) / 2, button=1,
                ))
                self.assertEqual(window._selected_plot_object_kind, 'category_axis')
                self.assertFalse(window.ui.categoryAxisGroup.isHidden())
                self.assertTrue(window.ui.categoryAxisForm.isRowVisible(window.ui.groupAxisLabelLayoutLabel))
                combo = window.group_axis_label_layout
                self.assertTrue(combo.isVisibleTo(window.ui.categoryAxisGroup))
                self.assertEqual([combo.itemData(i) for i in range(combo.count())],
                                 ['Wrap', 'Bottom', 'Top'] if grouped else ['Wrap', 'Bottom'])
                self.choose_layout(window, 'Bottom')
                self.assertEqual(window.x_tick_rotation.value(), 45)
                self.choose_layout(window, 'Wrap')
                self.assertEqual(window.x_tick_rotation.value(), 0)
                self.assertEqual(window._selected_plot_object_kind, 'category_axis')

    def test_single_level_layout_stays_available_when_parent_groups_are_removed(self):
        window = self.make_grouped_window()
        self.choose_layout(window, 'Top')
        window.table.horizontalHeader().select_parent_columns([0, 1])
        self.assertTrue(window.grouping_controls.unmerge_selected_headers())
        self.assertTrue(window.ui.categoryAxisForm.isRowVisible(window.ui.groupAxisLabelLayoutLabel))
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Wrap')
        window.group_axis_label_layout.activated.emit(window.group_axis_label_layout.currentIndex())
        self.assertEqual(window.settings.group_axis_label_layout, 'Wrap')
        window.undo_table_change()
        self.assertEqual(window.settings.group_axis_label_layout, 'Top')
        self.assertFalse(window.workbook.active_sheet.grouping.parents)
        window.undo_table_change()
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Top')
        self.assertEqual(window.settings.group_axis_label_layout, 'Top')

    def test_layout_control_tracks_sheet_switches_and_ignores_ridge_and_xy(self):
        window = self.make_grouped_window()
        self.choose_layout(window, 'Top')
        window.chart_type.setCurrentText('Ridge')
        self.assertFalse(window.ui.categoryAxisForm.isRowVisible(window.ui.groupAxisLabelLayoutLabel))
        window.x_tick_rotation.setValue(60)
        self.assertEqual(window.settings.group_axis_label_layout, 'Top')
        window.chart_type.setCurrentText('Box')
        self.assertTrue(window.ui.categoryAxisForm.isRowVisible(window.ui.groupAxisLabelLayoutLabel))
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Top')
        window.add_sheet(SHEET_MODE_XY)
        self.assertFalse(window.ui.categoryAxisForm.isRowVisible(window.ui.groupAxisLabelLayoutLabel))
        window.sheet_tab_bar.setCurrentIndex(0)
        self.assertEqual(window.group_axis_label_layout.currentData(), 'Top')
        self.assertEqual(window.x_tick_rotation.value(), 60)

    def test_sidebar_layout_labels_are_translated(self):
        translator = QTranslator()
        self.assertTrue(translator.load(str(Path(__file__).resolve().parents[1] / 'translations/easygraph_zh_CN.qm')))
        self.qapp.installTranslator(translator)
        try:
            window = self.make_grouped_window()
            self.assertEqual(window.ui.groupAxisLabelLayoutLabel.text(), '标签布局')
            combo = window.group_axis_label_layout
            self.assertEqual([combo.itemText(i) for i in range(combo.count())],
                             ['自动换行（默认）', '底部双层（倾斜）', '上下分离（一级在上）'])
        finally:
            self.qapp.removeTranslator(translator)
