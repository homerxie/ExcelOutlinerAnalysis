from __future__ import annotations

from copy import deepcopy
from unittest import mock

import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.clipboard_table import (
    CellMerge,
    ClipboardTable,
    clipboard_table_from_html,
    clipboard_table_to_html,
)
from easygraph.data_table import DataTable
from easygraph.data import prepare_plot_frames
from easygraph.grouping import create_parent
from easygraph.plotting.group_layout import build_group_layout
from easygraph.table_history import StructureSnapshotEdit
from easygraph.ui.table_controller import TableController, TableControllerHooks
from easygraph.workbook import SheetDocument


class GroupedClipboardControllerTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.sheet = SheetDocument(
            "Sheet 1",
            pd.DataFrame({"A": ["25%"], "B": ["3"], "C": ["4"], "D": ["5"]}),
        )
        self.table = DataTable()
        self.addCleanup(self.table.close)
        self.controller = TableController(
            self.table,
            settings=lambda: self.sheet.settings,
            sheet=lambda: self.sheet,
            hooks=TableControllerHooks(
                render=mock.Mock(),
                update_history_actions=mock.Mock(),
                update_dependent_controls=mock.Mock(),
                sync_overlay_controls=mock.Mock(),
            ),
        )
        self.controller.set_dataframe(self.sheet.dataframe)
        create_parent(self.sheet.grouping, self.sheet.column_ids[:2], "First")
        create_parent(self.sheet.grouping, self.sheet.column_ids[2:], "Second")
        self.controller.refresh_structure()
        self.controller.reset_history()

    def test_copy_preserves_both_header_levels_and_clips_merges_to_selection(self):
        self.select_table_range(self.table, 0, 1, 1, 3)
        data = self.controller.copy_selection_data()
        self.assertEqual(data.rows, [["First", "Second", ""], ["B", "C", "D"], ["3", "4", "5"]])
        self.assertEqual(data.header_rows, 2)
        self.assertEqual(data.merges, [CellMerge(0, 1, colspan=2)])
        self.assertEqual(clipboard_table_from_html(clipboard_table_to_html(data)), data)

    def test_numeric_selection_does_not_acquire_headers(self):
        self.select_table_range(self.table, 1, 0, 1, 1)
        data = self.controller.copy_selection_data()
        self.assertEqual(data, ClipboardTable([["25%", "3"]], header_rows=0))

    def test_parent_only_copy_and_spare_column_limit(self):
        self.table.horizontalHeader().select_parent_columns([0, 1, 2, 3])
        data = self.controller.copy_selection_data(column_limit=3)
        self.assertEqual(data, ClipboardTable([["First", "", "Second"]], [CellMerge(0, 0, colspan=2)], 1))
        self.table.horizontalHeader().clear_parent_selection()
        self.select_table_range(self.table, 0, 3, 1, 3)
        self.assertIsNone(self.controller.copy_selection_data(column_limit=3))

    def test_foreign_excel_headers_expand_and_undo_redo_atomically(self):
        self.table.setCurrentIndex(self.table.table_model.index(0, 2))
        before = self.controller.snapshot()
        data = ClipboardTable(
            [["New", "", "Solo"], ["A", "B", "C"], ["12.5%", "2", "3"]],
            [CellMerge(0, 0, colspan=2)],
        )
        self.assertTrue(self.controller.paste_clipboard(data))
        self.assertEqual(self.table.table_model.cells_copy()[0], ["A", "B", "A", "B", "C"])
        self.assertEqual(self.table.table_model.cell_text(1, 2), "12.5%")
        self.assertEqual([parent["name"] for parent in self.sheet.grouping.parents], ["First", "New", "Solo"])
        self.assertEqual(len(self.sheet.column_ids), 5)
        self.assertEqual(len(self.controller.history.undo_stack), 1)
        self.assertIsInstance(self.controller.history.undo_stack[0], StructureSnapshotEdit)
        after = self.controller.snapshot()
        self.controller.undo()
        self.assertEqual(self.controller.snapshot()["cells"], before["cells"])
        self.assertEqual(self.controller.snapshot()["grouping"], before["grouping"])
        self.assertEqual(self.sheet.column_ids, before["column_ids"])
        self.controller.redo()
        self.assertEqual(self.controller.snapshot()["grouping"], after["grouping"])
        self.assertEqual(self.controller.snapshot()["cells"], after["cells"])

    def test_parent_target_plain_text_does_not_touch_stale_current_cell(self):
        self.table.setCurrentIndex(self.table.table_model.index(1, 3))
        self.table.horizontalHeader().select_parent_columns([0, 3])
        before = self.table.table_model.cells_copy()
        parent_before = deepcopy(self.sheet.grouping.parents[0])
        self.assertTrue(self.controller.paste_clipboard(ClipboardTable([["Renamed"]])))
        self.assertEqual(self.table.table_model.cells_copy(), before)
        self.assertEqual(self.sheet.grouping.parents[0]["name"], "Renamed")
        self.assertEqual(self.sheet.grouping.parents[-1]["name"], "Second")
        self.assertEqual(len(self.sheet.grouping.parents), 2)
        self.assertEqual(self.sheet.grouping.parents[0]["column_ids"], parent_before["column_ids"])
        self.assertEqual(self.sheet.grouping.parents[0]["id"], parent_before["id"])
        self.controller.undo()
        self.assertEqual(self.sheet.grouping.parents[0], parent_before)

    def test_overwriting_middle_of_existing_merge_leaves_separate_merged_pieces(self):
        old = create_parent(self.sheet.grouping, self.sheet.column_ids, "Original")
        before = deepcopy(self.sheet.grouping)
        self.table.setCurrentIndex(self.table.table_model.index(0, 1))
        self.controller.paste_clipboard(ClipboardTable([["New", ""]], [CellMerge(0, 0, colspan=2)], 1))
        parents = self.sheet.grouping.parents
        self.assertEqual([parent["name"] for parent in parents], ["Original", "New", "Original"])
        self.assertEqual([parent["column_ids"] for parent in parents], [self.sheet.column_ids[:1], self.sheet.column_ids[1:3], self.sheet.column_ids[3:]])
        self.assertEqual(parents[0]["id"], old["id"])
        self.assertNotEqual(parents[2]["id"], old["id"])
        self.assertEqual(len(self.controller.history.undo_stack), 1)
        self.controller.undo()
        self.assertEqual(self.sheet.grouping, before)

    def test_blank_merged_parent_remains_merged(self):
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))
        self.controller.paste_clipboard(ClipboardTable([["", ""]], [CellMerge(0, 0, colspan=2)], 1))
        parent = self.sheet.grouping.parents[0]
        self.assertEqual(parent["name"], "")
        self.assertEqual(parent["column_ids"], self.sheet.column_ids[:2])
        self.table.horizontalHeader().select_parent_columns([0])
        self.assertEqual(self.controller.copy_selection_data().merges, [CellMerge(0, 0, colspan=2)])

    def test_replacing_subset_preserves_unaffected_shared_names(self):
        self.sheet.grouping.shared_subgroups = True
        self.sheet.grouping.subgroup_ids = dict(zip(self.sheet.column_ids, ["a", "b", "a", "b"]))
        before = deepcopy(self.sheet.grouping)
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))
        self.controller.paste_clipboard(ClipboardTable([["Other", ""], ["X", "Y"]], [CellMerge(0, 0, colspan=2)], 2))
        self.assertEqual(self.table.table_model.cells_copy()[0], ["X", "Y", "C", "D"])
        for key in self.sheet.column_ids[2:]:
            self.assertEqual(self.sheet.grouping.subgroup_ids[key], before.subgroup_ids[key])
        for key in self.sheet.column_ids[:2]:
            self.assertNotIn(self.sheet.grouping.subgroup_ids[key], {"a", "b"})
        self.assertEqual(self.sheet.grouping.parents[-1], before.parents[-1])

    def shared_clipboard(self, names=None):
        names = names or ["Control", "Dose", "Control", "Dose"]
        self.sheet.grouping.shared_subgroups = True
        self.sheet.grouping.subgroup_ids = dict(zip(self.sheet.column_ids, ["control", "dose", "control", "dose"]))
        self.table.table_model.set_cells_text((0, index, name) for index, name in enumerate(names))
        self.controller.reset_history()
        return ClipboardTable(
            [["First", "", "Second", ""], names, ["1", "2", "3", "4"]],
            [CellMerge(0, 0, colspan=2), CellMerge(0, 2, colspan=2)],
        )

    def assert_shared_plot_categories(self):
        ids = self.sheet.column_ids
        prepared = prepare_plot_frames(self.controller.dataframe(), self.sheet.settings)
        layout = build_group_layout(prepared.visible, self.sheet.settings, self.sheet.grouping, ids)
        self.assertEqual([name for name, _color in layout.legend], ["Control", "Dose"])
        self.assertEqual(layout.colors[ids[0]], layout.colors[ids[2]])
        self.assertEqual(layout.colors[ids[1]], layout.colors[ids[3]])
        self.assertNotEqual(layout.colors[ids[0]], layout.colors[ids[1]])
        self.assertEqual(len(layout.order), 4)

    def test_clear_then_excel_paste_restores_shared_legend_and_category_colors(self):
        data = self.shared_clipboard()
        categories = dict(self.sheet.grouping.subgroup_ids)
        self.sheet.settings.custom_colors = {"control": "#ff0000", "dose": "#0000ff"}
        self.table.selectAll()
        self.controller.clear_selection()
        self.controller.refresh_structure()
        cleared = self.controller.snapshot()
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))

        self.assertTrue(self.controller.paste_clipboard(data))

        self.assertEqual(self.sheet.grouping.subgroup_ids, categories)
        self.assert_shared_plot_categories()
        pasted = self.controller.snapshot()
        self.controller.undo()
        self.assertEqual(self.controller.snapshot()["grouping"], cleared["grouping"])
        self.controller.redo()
        self.assertEqual(self.controller.snapshot()["grouping"], pasted["grouping"])
        self.assert_shared_plot_categories()

    def test_shared_paste_without_existing_categories_rebuilds_repeated_leaf_names(self):
        data = self.shared_clipboard()
        self.sheet.grouping.subgroup_ids.clear()
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))

        self.controller.paste_clipboard(data)

        ids = self.sheet.column_ids
        categories = self.sheet.grouping.subgroup_ids
        self.assertEqual(categories[ids[0]], categories[ids[2]])
        self.assertEqual(categories[ids[1]], categories[ids[3]])
        self.assertNotEqual(categories[ids[0]], categories[ids[1]])
        self.assert_shared_plot_categories()

    def test_repeated_leaf_names_across_pasted_parents_enable_shared_colors(self):
        data = self.shared_clipboard()
        self.sheet.grouping.shared_subgroups = False
        self.sheet.grouping.subgroup_ids.clear()
        self.sheet.grouping.parents.clear()
        self.sheet.settings.group_color_mode = "Parent"
        self.controller.reset_history()
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))

        self.controller.paste_clipboard(data)

        self.assertTrue(self.sheet.grouping.shared_subgroups)
        self.assertEqual(self.sheet.settings.group_color_mode, "Subgroup")
        self.assert_shared_plot_categories()
        self.controller.undo()
        self.assertFalse(self.sheet.grouping.shared_subgroups)
        self.assertEqual(self.sheet.grouping.parents, [])
        self.assertEqual(self.sheet.settings.group_color_mode, "Parent")
        self.controller.redo()
        self.assertTrue(self.sheet.grouping.shared_subgroups)
        self.assert_shared_plot_categories()

    def test_without_cross_parent_repeated_names_paste_keeps_independent_mode(self):
        for names in (
            ["A", "B", "C", "D"],
            ["Repeated", "Repeated", "C", "D"],
            ["", "", "", ""],
        ):
            with self.subTest(names=names):
                data = self.shared_clipboard(names)
                self.sheet.grouping.shared_subgroups = False
                self.sheet.grouping.subgroup_ids.clear()
                self.table.setCurrentIndex(self.table.table_model.index(0, 0))

                self.controller.paste_clipboard(data)

                self.assertFalse(self.sheet.grouping.shared_subgroups)
                self.assertEqual(self.sheet.grouping.subgroup_ids, {})

    def test_flat_paste_and_parent_only_paste_do_not_infer_shared_leaf_names(self):
        self.shared_clipboard()
        self.sheet.grouping.shared_subgroups = False
        self.sheet.grouping.subgroup_ids.clear()
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))
        for data in (
            ClipboardTable([["First", "", "Second", ""]],
                           [CellMerge(0, 0, colspan=2), CellMerge(0, 2, colspan=2)], 1),
            ClipboardTable([["A", "B", "A", "B"], ["1", "2", "3", "4"]], header_rows=0),
        ):
            with self.subTest(header_rows=data.header_rows):
                self.controller.paste_clipboard(data)

                self.assertFalse(self.sheet.grouping.shared_subgroups)
                self.assertEqual(self.sheet.grouping.subgroup_ids, {})

    def test_automatic_shared_paste_reuses_existing_parent_categories_but_not_flat_columns(self):
        data = self.shared_clipboard()
        self.sheet.grouping.shared_subgroups = False
        self.sheet.grouping.parents.clear()
        self.sheet.grouping.subgroup_ids.clear()
        self.controller.set_dataframe(pd.DataFrame(
            [["1"] * 7], columns=["Old A", "Old B", "Old C", "Old D", "Control", "Dose", "Control"],
        ))
        self.controller._reconcile_sheet_column_ids()
        ids = self.sheet.column_ids
        create_parent(self.sheet.grouping, ids[4:6], "Untouched")
        self.sheet.grouping.subgroup_ids = {ids[4]: "existing-control", ids[5]: "existing-dose"}
        untouched = deepcopy(self.sheet.grouping.parents[0])
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))

        self.controller.paste_clipboard(data)

        self.assertTrue(self.sheet.grouping.shared_subgroups)
        categories = self.sheet.grouping.subgroup_ids
        self.assertEqual([categories[key] for key in ids[:6]],
                         ["existing-control", "existing-dose"] * 3)
        self.assertNotIn(ids[6], categories)
        self.assertEqual(self.sheet.grouping.parents[-1], untouched)

    def test_pasting_only_parent_headers_preserves_existing_categories(self):
        self.shared_clipboard()
        categories = dict(self.sheet.grouping.subgroup_ids)
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))

        self.controller.paste_clipboard(ClipboardTable(
            [["One parent", "", "", ""]], [CellMerge(0, 0, colspan=4)], 1,
        ))

        self.assertEqual(self.sheet.grouping.subgroup_ids, categories)
        self.assertEqual(self.table.table_model.cells_copy()[0], ["Control", "Dose", "Control", "Dose"])

    def test_shared_paste_repeated_names_share_color_without_merging_data_columns(self):
        data = self.shared_clipboard(["Repeated", "Repeated", "Repeated", "Repeated"])
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))

        self.controller.paste_clipboard(data)

        ids = self.sheet.column_ids
        categories = self.sheet.grouping.subgroup_ids
        self.assertEqual(len({categories[key] for key in ids}), 1)
        prepared = prepare_plot_frames(self.controller.dataframe(), self.sheet.settings)
        layout = build_group_layout(prepared.visible, self.sheet.settings, self.sheet.grouping, ids)
        self.assertEqual([name for name, _color in layout.legend], ["Repeated"])
        self.assertEqual(len(set(layout.colors.values())), 1)
        self.assertEqual(len(layout.order), 4)
        self.assertEqual(self.table.table_model.cells_copy()[1], ["1", "2", "3", "4"])

    def test_reordered_shared_leaf_names_keep_their_existing_color_categories(self):
        data = self.shared_clipboard()
        data.rows[1] = ["Dose", "Control", "Dose", "Control"]
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))

        self.controller.paste_clipboard(data)

        self.assertEqual(
            [self.sheet.grouping.subgroup_ids[key] for key in self.sheet.column_ids],
            ["dose", "control", "dose", "control"],
        )

    def test_partial_paste_same_leaf_names_reuses_untouched_shared_categories(self):
        data = self.shared_clipboard()
        categories = dict(self.sheet.grouping.subgroup_ids)
        unaffected = deepcopy(self.sheet.grouping.parents[1])
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))

        self.controller.paste_clipboard(ClipboardTable(
            [row[:2] for row in data.rows], [CellMerge(0, 0, colspan=2)],
        ))

        self.assertEqual(self.sheet.grouping.subgroup_ids, categories)
        self.assertEqual(self.sheet.grouping.parents[-1], unaffected)

    def test_unsupported_body_or_vertical_merge_is_rejected_before_changes(self):
        before = self.controller.snapshot()
        for merge in (CellMerge(0, 0, rowspan=2), CellMerge(1, 0, colspan=2)):
            with self.subTest(merge=merge), self.assertRaisesRegex(ValueError, "Merged cells must be horizontal"):
                self.controller.paste_clipboard(ClipboardTable([["A", "B"], ["1", "2"]], [merge]))
            self.assertEqual(self.controller.snapshot(), before)
        self.assertFalse(self.controller.history.can_undo)
