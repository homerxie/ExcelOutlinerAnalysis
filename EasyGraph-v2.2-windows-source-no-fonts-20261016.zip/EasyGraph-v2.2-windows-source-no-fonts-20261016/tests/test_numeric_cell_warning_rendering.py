"""Check the warning pixels painted by a real themed Qt table viewport."""
from __future__ import annotations

import unittest

import pandas as pd
from PySide6.QtCore import QModelIndex
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication

from easygraph.app_theme import apply_app_theme, qdarktheme
from easygraph.data_table import DataTable
from easygraph.table_style import apply_table_row_styles


@unittest.skipIf(qdarktheme is None, "The app's optional qdarktheme is unavailable")
class NumericCellWarningRenderingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        stylesheet = self.app.styleSheet()
        font = self.app.font()
        icon = self.app.windowIcon()
        self.addCleanup(self.app.setWindowIcon, icon)
        self.addCleanup(self.app.setFont, font)
        self.addCleanup(self.app.setStyleSheet, stylesheet)
        self.table = DataTable()
        self.table.setObjectName("dataTable")
        self.table.set_dataframe(pd.DataFrame({
            "Invalid": ["oops"], "Number": ["1.5"], "Blank": [""], "Rate": ["25%"],
        }))
        self.table.resize(560, 180)
        self.addCleanup(self.table.deleteLater)
        self.addCleanup(self.table.close)
        self.table.show()

    def apply_theme(self, theme):
        apply_app_theme(self.app, theme)
        self.app.processEvents()
        apply_table_row_styles(
            self.table, sample_start_row=1,
            blend_colors=lambda base, highlight, ratio: QColor.fromRgbF(
                *(base.getRgbF()[index] * (1 - ratio) + highlight.getRgbF()[index] * ratio
                  for index in range(3))
            ),
        )

    def image(self):
        self.app.processEvents()
        return self.table.viewport().grab().toImage()

    @staticmethod
    def pixel(image, x, y):
        # QWidget geometry is in logical pixels; native Retina grabs are not.
        ratio = image.devicePixelRatio()
        return image.pixelColor(int((x + 0.5) * ratio), int((y + 0.5) * ratio))

    def cell_background(self, image, row, column):
        rect = self.table.visualRect(self.table.table_model.index(row, column))
        return self.pixel(image, rect.right() - 12, rect.center().y())

    def test_warning_background_survives_themes_and_disappears_after_correction(self):
        model = self.table.table_model
        for theme, expected in (("light", "#fff1cc"), ("dark", "#5b421c")):
            with self.subTest(theme=theme):
                model.set_cell_text(1, 0, "oops")
                self.table.clearSelection()
                self.table.setCurrentIndex(QModelIndex())
                self.apply_theme(theme)
                image = self.image()
                warning = QColor(expected)

                self.assertEqual(self.cell_background(image, 1, 0), warning)
                for row, column in ((0, 0), (1, 1), (1, 2), (1, 3)):
                    self.assertNotEqual(self.cell_background(image, row, column), warning)

                model.set_cell_text(1, 0, "3.5")
                corrected = self.image()
                self.assertNotEqual(self.cell_background(corrected, 1, 0), warning)
                self.assertEqual(
                    self.cell_background(corrected, 1, 0),
                    self.cell_background(corrected, 1, 1),
                )

    def test_selected_invalid_cell_keeps_warning_fill_and_selection_border(self):
        model = self.table.table_model
        index = model.index(1, 0)
        for theme, expected in (("light", "#fff1cc"), ("dark", "#5b421c")):
            with self.subTest(theme=theme):
                self.apply_theme(theme)
                self.table.clearSelection()
                self.table.setCurrentIndex(QModelIndex())
                unselected = self.image()
                self.table.setCurrentIndex(index)
                self.table.setFocus()
                selected = self.image()
                rect = self.table.visualRect(index)

                self.assertEqual(self.cell_background(selected, 1, 0), QColor(expected))
                # Scan just inside the left edge so both one- and two-pixel
                # native selection outlines provide visible blue feedback.
                edge_colors = [
                    self.pixel(selected, rect.left() + offset, rect.center().y())
                    for offset in (0, 1, 2)
                ]
                self.assertTrue(any(color.blue() > color.red() for color in edge_colors))
                self.assertTrue(any(
                    color != self.pixel(unselected, rect.left() + offset, rect.center().y())
                    for offset, color in zip((0, 1, 2), edge_colors)
                ))
