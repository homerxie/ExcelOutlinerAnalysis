from __future__ import annotations

from unittest import mock

import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.settings import ChartSettings
from easygraph.table_history import BlockEdit, CellEdit
from easygraph.ui.table_controller import TableController, TableControllerHooks


class ClearNonNumericCellsTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.settings = ChartSettings()
        self.table = DataTable()
        self.addCleanup(self.table.deleteLater)
        self.render = mock.Mock()
        self.update_history_actions = mock.Mock()
        self.sync_overlay_controls = mock.Mock()
        self.update_dependent_controls = mock.Mock()
        self.controller = TableController(
            self.table,
            settings=lambda: self.settings,
            hooks=TableControllerHooks(
                render=self.render,
                update_history_actions=self.update_history_actions,
                update_dependent_controls=self.update_dependent_controls,
                sync_overlay_controls=self.sync_overlay_controls,
            ),
        )

    def test_clears_only_invalid_text_in_one_undoable_bulk_edit(self):
        self.controller.set_dataframe(pd.DataFrame({
            "Group label": ["12", "bad", "", "25%", "2e3"],
            "Other label": ["中文", "-3.5", "  ", "12％", "#VALUE!"],
        }))
        self.controller.reset_history()
        model = self.table.table_model
        original = model.cells_copy()
        self.table.setCurrentIndex(model.index(1, 0))
        self.select_table_range(self.table, 1, 0, 1, 0)
        updates = mock.Mock()
        edits = []
        model.dataChanged.connect(updates)
        model.cellEdited.connect(lambda *edit: edits.append(edit))
        self.controller.dataframe()

        with mock.patch.object(model, "set_cell_text", side_effect=AssertionError("per-cell update")):
            self.assertTrue(self.controller.clear_non_numeric_cells())
            cleared = model.cells_copy()
            self.assertEqual(cleared, [
                ["Group label", "Other label"],
                ["12", ""], ["", "-3.5"], ["", "  "], ["25%", "12％"], ["2e3", ""],
            ])
            self.assertEqual(self.controller.dataframe().iloc[1, 0], "")
            self.assertEqual(len(self.controller.history.undo_stack), 1)
            self.assertIsInstance(self.controller.history.undo_stack[0], BlockEdit)
            self.assertEqual(len(self.controller.history.undo_stack[0].cells), 3)
            self.controller.undo()
            self.assertEqual(model.cells_copy(), original)
            self.controller.redo()
            self.assertEqual(model.cells_copy(), cleared)

        self.assertEqual(updates.call_count, 3)
        self.assertEqual(len(edits), 9)
        self.assertEqual(self.render.call_count, 3)
        self.assertEqual((self.table.currentIndex().row(), self.table.currentIndex().column()), (1, 0))

    def test_overlay_clear_updates_settings_and_restores_them_with_undo(self):
        overlay = [{"name": "Limit", "values": {"A": "invalid", "B": "10%"}}]
        self.settings.custom_overlay_series = overlay
        self.controller.set_dataframe(pd.DataFrame({"A": ["2"], "B": ["bad sample"]}), overlay)
        self.controller.reset_history()

        self.assertTrue(self.controller.clear_non_numeric_cells())

        self.assertEqual(self.settings.custom_overlay_series, [
            {"name": "Limit", "values": {"A": "", "B": "10%"}},
        ])
        self.assertEqual(self.table.table_model.cells_copy(), [["A", "B"], ["", "10%"], ["2", ""]])
        self.sync_overlay_controls.assert_called_once_with()
        self.update_dependent_controls.assert_called_once_with()
        self.assertEqual(len(self.controller.history.undo_stack), 1)
        self.controller.undo()
        self.assertEqual(self.settings.custom_overlay_series, overlay)
        self.assertEqual(self.table.table_model.cell_text(1, 0), "invalid")
        self.assertEqual(self.table.table_model.cell_text(2, 1), "bad sample")
        self.controller.redo()
        self.assertEqual(self.settings.custom_overlay_series[0]["values"]["A"], "")

    def test_no_invalid_cells_preserves_history_redo_and_render_state(self):
        self.controller.set_dataframe(pd.DataFrame({"Text header": ["1", "25%", "", "  "]}))
        self.controller.reset_history()
        redo = CellEdit(1, 0, "1", "2")
        self.controller.history.redo_stack.append(redo)
        self.update_history_actions.reset_mock()
        revision = self.controller.data_revision

        self.assertFalse(self.controller.clear_non_numeric_cells())

        self.assertEqual(self.controller.history.undo_stack, [])
        self.assertEqual(self.controller.history.redo_stack, [redo])
        self.assertEqual(self.controller.data_revision, revision)
        self.render.assert_not_called()
        self.update_history_actions.assert_not_called()
