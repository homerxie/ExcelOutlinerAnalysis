from copy import deepcopy
from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QFontMetrics
from PySide6.QtWidgets import QHeaderView

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.analysis_results import AnalysisTableResult
from easygraph.data_table import DataTable
from easygraph.ui.analysis_results_table import AnalysisResultsTable
from easygraph.ui.header_text_layout import header_text_layout


class TableHeaderWrappingTests(EasyGraphQtTestCase):
    def settle(self):
        for _ in range(3):
            self.qapp.processEvents()

    def make_table(self, names):
        table = DataTable()
        self.addCleanup(table.deleteLater)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        table.set_dataframe(pd.DataFrame([[1, 2], [3, 4]], columns=names))
        table.resize(600, 360)
        table.show()
        self.settle()
        return table

    def test_data_names_wrap_to_column_width_without_changing_data_or_selection(self):
        names = ['长期循环之后的抗拉强度 Tensile strength', 'Short']
        table = self.make_table(names)
        before = table.table_model.cells_copy()
        table.setCurrentIndex(table.model().index(1, 1))
        table.setColumnWidth(0, 75)
        self.settle()
        narrow_height = table.rowHeight(0)
        self.assertGreater(narrow_height, table.fontMetrics().lineSpacing() * 2)
        sample_height = table.rowHeight(1)
        table.setColumnWidth(0, 440)
        self.settle()
        self.assertLess(table.rowHeight(0), narrow_height)
        self.assertEqual(table.rowHeight(1), sample_height)
        self.assertEqual(table.currentIndex(), table.model().index(1, 1))
        self.assertEqual(table.table_model.cells_copy(), before)
        self.assertEqual(list(table.dataframe().columns), names)

    def test_manual_name_breaks_are_never_automatically_split_again(self):
        manual = 'A very long manually chosen first line\n第二行也很长但保留用户换行'
        table = self.make_table([manual, 'Short'])
        table.setColumnWidth(0, 45)
        self.settle()
        font = table.model().data(table.model().index(0, 0), Qt.FontRole)
        expected = table.rowHeight(0)
        self.assertGreaterEqual(expected, QFontMetrics(font).lineSpacing() * 2 + 14)
        table.setColumnWidth(0, 420)
        self.settle()
        self.assertEqual(table.rowHeight(0), expected)
        self.assertEqual(table.table_model.cell_text(0, 0), manual)
        self.assertEqual(table.model().data(table.model().index(0, 0), Qt.ToolTipRole), manual)

    def test_name_edits_and_font_changes_update_height(self):
        table = self.make_table(['Short', 'Other'])
        table.setColumnWidth(0, 65)
        self.settle()
        initial_height = table.rowHeight(0)
        table.table_model.set_cell_text(0, 0, 'Extended treatment duration without recovery')
        self.settle()
        long_height = table.rowHeight(0)
        self.assertGreater(long_height, initial_height)
        font = QFont(table.font())
        font.setPointSize(font.pointSize() + 4)
        table.setFont(font)
        self.settle()
        self.assertGreater(table.rowHeight(0), long_height)
        table.table_model.set_cell_text(0, 0, 'A')
        self.settle()
        self.assertLess(table.rowHeight(0), long_height)

    def test_name_painter_preserves_manual_breaks_after_qt_style_conversion(self):
        manual = 'Long manually chosen first line\nSecond manual line'
        table = self.make_table([manual, 'Other'])
        table.setColumnWidth(0, 65)
        self.settle()
        with mock.patch('easygraph.data_table.header_text_layout', wraps=header_text_layout) as layout_call:
            table.grab()
        painted_texts = [call.args[0] for call in layout_call.call_args_list]
        self.assertIn(manual, painted_texts)
        self.assertNotIn(manual.replace('\n', '\u2028'), painted_texts)

    def test_parent_uses_merged_width_and_preserves_selection_on_resize(self):
        table = self.make_table(['Control', 'Drug'])
        header = table.horizontalHeader()
        parents = [{'id': 'p', 'name': '长期循环实验与恢复处理对照 Extended recovery experiment', 'column_ids': ['a', 'b']}]
        original = deepcopy(parents)
        header.set_grouping(parents, ['a', 'b'])
        header.select_parent_columns([0])
        for column in range(2):
            table.setColumnWidth(column, 55)
        self.settle()
        narrow_height = header.band_height()
        self.assertGreater(narrow_height, header.fontMetrics().lineSpacing() * 2)
        table.setColumnWidth(1, 360)
        self.settle()
        self.assertLess(header.band_height(), narrow_height)
        self.assertGreaterEqual(header.height(), header.sizeHint().height())
        self.assertEqual(header.selected_parent_columns(), [0, 1])
        self.assertEqual(header.parent_columns_at(header.parent_band_rect().center()), [0, 1])
        self.assertEqual(parents, original)

    def test_manual_parent_lines_keep_their_count_at_narrow_widths(self):
        table = self.make_table(['A', 'B'])
        header = table.horizontalHeader()
        text = 'Long first line chosen by user\n用户指定的很长第二行'
        header.set_grouping([{'id': 'p', 'name': text, 'column_ids': ['a']}], ['a', 'b'])
        table.setColumnWidth(0, 45)
        self.settle()
        expected = header.band_height()
        self.assertGreaterEqual(expected, header.fontMetrics().lineSpacing() * 2 + 10)
        table.setColumnWidth(0, 400)
        self.settle()
        self.assertEqual(header.band_height(), expected)

    def test_analysis_headers_wrap_both_levels_and_keep_clipboard_names(self):
        table = AnalysisResultsTable()
        self.addCleanup(table.deleteLater)
        columns = ('长期实验之后的强度 Tensile strength', 'Long manual first line\nUser second line')
        table.set_result(AnalysisTableResult(key='test', title='Test', columns=columns,
                                           row_labels=('Mean',), values=(('2', '3'),)))
        parent = '恢复处理与未经处理实验比较 Recovery experiment'
        table.set_grouping([{'id': 'p', 'name': parent, 'column_ids': ['a', 'b']}], ['a', 'b'])
        table.resize(600, 420)
        table.show()
        for column in range(2):
            table.setColumnWidth(column, 65)
        self.settle()
        header = table.horizontalHeader()
        narrow_leaf = header.section_label_height()
        narrow_parent = header.band_height()
        self.assertGreater(narrow_leaf, header.fontMetrics().lineSpacing() * 2 + 10)
        self.assertGreater(narrow_parent, header.fontMetrics().lineSpacing() + 10)
        table.setColumnWidth(0, 400)
        self.settle()
        self.assertEqual(header.section_label_height(), header.fontMetrics().lineSpacing() * 2 + 10)
        self.assertLess(header.band_height(), narrow_parent)
        self.assertGreaterEqual(header.height(), header.sizeHint().height())
        self.assertEqual(table.results_model.result.columns, columns)
        self.assertEqual(table.table_clipboard_data().rows[:2], [['', parent, ''], ['', *columns]])
        table.grab()  # Exercise both custom painting paths, including manual lines.

    def test_layout_keeps_unicode_and_empty_manual_lines(self):
        font = QFont(self.qapp.font())
        automatic = header_text_layout('实验🧪名称MixedUnicode', font, 35)
        manual = header_text_layout('实验🧪名称\n\nMixedUnicode', font, 35)
        self.assertGreater(automatic.line_count, 1)
        self.assertEqual(manual.line_count, 3)

    def test_fallback_cjk_lines_fit_the_measured_height_without_overlapping(self):
        layout = header_text_layout('中文混合Text与很长的实验处理名称再加几行', QFont('Arial', 12), 50)
        lines = [paragraph.lineAt(i) for paragraph in layout.paragraphs for i in range(paragraph.lineCount())]
        self.assertGreater(len(lines), 2)
        for previous, current in zip(lines, lines[1:]):
            self.assertGreaterEqual(current.y(), previous.y() + previous.height())
        self.assertGreaterEqual(layout.height, lines[-1].y() + lines[-1].height())
