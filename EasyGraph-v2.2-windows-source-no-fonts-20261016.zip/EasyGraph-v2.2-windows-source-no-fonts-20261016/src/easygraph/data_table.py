from __future__ import annotations

import pandas as pd
from PySide6.QtCore import QEvent, Qt, QTimer, Signal
from PySide6.QtGui import QPalette, QPen
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QStyle,
    QStyleFactory,
    QStyledItemDelegate,
    QStyleOptionViewItem,
    QTableView,
    QWidget,
)

from easygraph.table_model import EasyGraphTableModel
from easygraph.ui.group_header import GroupHeaderView
from easygraph.ui.header_text_layout import header_text_layout


class DataTableItemDelegate(QStyledItemDelegate):
    """Coordinate inline-editor navigation before Qt's default handling."""

    navigation_requested = Signal(QWidget, object)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        # Native macOS item painting can cover BackgroundRole under the app's
        # stylesheet. Use a stylesheet-free Qt style for warning cells while
        # retaining the table's font, palette, text layout, and editing behavior.
        self._numeric_warning_style = QStyleFactory.create("Fusion")
        self._numeric_warning_style.setParent(self)

    def paint(self, painter, option, index) -> None:
        if index.row() == 0:
            self._paint_name(painter, option, index)
            return
        if not index.model().is_invalid_numeric_cell(index.row(), index.column()):
            super().paint(painter, option, index)
            return
        warning_option = QStyleOptionViewItem(option)
        self.initStyleOption(warning_option, index)
        selected = bool(warning_option.state & QStyle.StateFlag.State_Selected)
        warning_option.state &= ~(
            QStyle.StateFlag.State_Selected | QStyle.StateFlag.State_HasFocus
        )
        warning_option.features &= ~QStyleOptionViewItem.ViewItemFeature.Alternate
        self._numeric_warning_style.drawControl(
            QStyle.ControlElement.CE_ItemViewItem,
            warning_option,
            painter,
            warning_option.widget,
        )
        if selected:
            painter.save()
            try:
                painter.setPen(QPen(option.palette.highlight().color(), 2))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRect(option.rect.adjusted(1, 1, -1, -1))
            finally:
                painter.restore()

    def _paint_name(self, painter, option, index) -> None:
        name_option = QStyleOptionViewItem(option)
        self.initStyleOption(name_option, index)
        # initStyleOption converts newlines to Unicode line separators. Read
        # the original value so explicit user breaks still disable auto-wrap.
        text = str(index.data(Qt.DisplayRole) or '')
        name_option.text = ''
        widget = name_option.widget or self.parent()
        widget.style().drawControl(QStyle.CE_ItemViewItem, name_option, painter, widget)
        painter.save()
        try:
            painter.setFont(name_option.font)
            role = (QPalette.ColorRole.HighlightedText if name_option.state & QStyle.StateFlag.State_Selected
                    else QPalette.ColorRole.Text)
            painter.setPen(name_option.palette.color(role))
            rect = option.rect.adjusted(6, 7, -6, -7)
            header_text_layout(text, name_option.font, rect.width()).draw(painter, rect)
        finally:
            painter.restore()

    def eventFilter(self, editor, event) -> bool:
        if event.type() == QEvent.Type.KeyPress:
            # Give the table controller first chance to commit and navigate.
            # Returning True here prevents QStyledItemDelegate from attempting
            # a second commit for the same editor.
            event.ignore()
            self.navigation_requested.emit(editor, event)
            if event.isAccepted():
                return True
        return super().eventFilter(editor, event)


class DataTable(QTableView):
    """QTableView configured around EasyGraph's dataframe-backed table model."""

    headerCellDoubleClicked = Signal(int)

    def __init__(self, rows=0, columns=0, parent=None) -> None:
        if not isinstance(rows, int):
            parent = rows
            rows = 0
            columns = 0
        super().__init__(parent)
        self.setHorizontalHeader(GroupHeaderView(self))
        self.table_model = EasyGraphTableModel(self)
        self.setModel(self.table_model)
        self.table_item_delegate = DataTableItemDelegate(self)
        self.setItemDelegate(self.table_item_delegate)
        self._header_resize_timer = QTimer(self)
        self._header_resize_timer.setSingleShot(True)
        self._header_resize_timer.timeout.connect(self.update_header_row_height)
        self.horizontalHeader().sectionResized.connect(self._schedule_header_row_resize)
        self.table_model.modelReset.connect(self._schedule_header_row_resize)
        self.table_model.columnsInserted.connect(self._schedule_header_row_resize)
        self.table_model.columnsRemoved.connect(self._schedule_header_row_resize)
        self.table_model.rowsInserted.connect(self._schedule_header_row_resize)
        self.table_model.rowsRemoved.connect(self._schedule_header_row_resize)
        self.table_model.dataChanged.connect(self._header_data_changed)
        self.setAlternatingRowColors(True)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.horizontalHeader().setObjectName("dataTableHorizontalHeader")
        self.verticalHeader().setObjectName("dataTableVerticalHeader")
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        if rows or columns:
            self.table_model.resize(rows, columns)

    def _schedule_header_row_resize(self, *_args) -> None:
        self._header_resize_timer.start(0)

    def _header_data_changed(self, first, _last, _roles=None) -> None:
        if first.row() == 0:
            self._schedule_header_row_resize()

    def update_header_row_height(self) -> None:
        if not self.table_model.rowCount():
            return
        from easygraph.table_style import header_row_height
        height = header_row_height(self)
        if self.rowHeight(0) != height:
            self.setRowHeight(0, height)
        self.viewport().update()

    def changeEvent(self, event) -> None:
        super().changeEvent(event)
        if event.type() in {QEvent.FontChange, QEvent.ApplicationFontChange, QEvent.StyleChange} and hasattr(self, '_header_resize_timer'):
            self._schedule_header_row_resize()

    def set_dataframe(self, df: pd.DataFrame, overlay_series: list[dict] | None = None) -> None:
        self.table_model.replace_from_dataframe(df, list(overlay_series or []))

    def dataframe(self) -> pd.DataFrame:
        return self.table_model.sample_dataframe()

    def mouseDoubleClickEvent(self, event) -> None:
        index = self.indexAt(event.position().toPoint())
        if index.isValid() and index.row() == 0:
            self.setCurrentIndex(index)
            self.headerCellDoubleClicked.emit(index.column())
            event.accept()
            return
        super().mouseDoubleClickEvent(event)
