from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QBrush, QColor, QPalette

from easygraph.data_table import DataTable
from easygraph.ui.header_text_layout import header_text_layout


def header_row_height(table: DataTable, padding: int = 14) -> int:
    text_height = max(
        (
            header_text_layout(
                table.table_model.cell_text(0, column),
                table.table_model.data(table.table_model.index(0, column), Qt.FontRole) or table.font(),
                table.columnWidth(column) - 12 - int(table.showGrid()),
            ).height
            for column in range(table.table_model.columnCount())
            if not table.isColumnHidden(column)
        ),
        default=table.fontMetrics().lineSpacing(),
    )
    return text_height + padding


def row_header_min_width(overlay_row_count: int) -> int:
    return 86 if overlay_row_count else 34


def apply_table_row_styles(table: DataTable, sample_start_row: int, blend_colors) -> None:
    if table.table_model.rowCount() == 0:
        table.table_model.resize(1, table.table_model.columnCount())
    was_blocked = table.signalsBlocked()
    table.blockSignals(True)
    try:
        table.table_model.set_cells_text(
            (0, column, f"Group {column + 1}")
            for column in range(table.table_model.columnCount())
            if not table.table_model.cell_text(0, column).strip()
        )
    finally:
        table.blockSignals(was_blocked)
    # A stylesheet-backed palette is resolved lazily.  The table is styled
    # before the main window is shown, so polish it before caching theme colors.
    table.ensurePolished()
    palette = table.palette()
    base_color = palette.color(QPalette.ColorRole.Base)
    highlight_color = palette.color(QPalette.ColorRole.Highlight)
    text_color = palette.color(QPalette.ColorRole.Text)
    table.table_model.configure_style(
        sample_start_row,
        QBrush(blend_colors(base_color, highlight_color, 0.18)),
        QBrush(text_color),
        QBrush(blend_colors(base_color, highlight_color, 0.12)),
        QBrush(text_color),
        invalid_numeric_background=QBrush(QColor(
            "#5B421C" if base_color.lightness() < 128 else "#FFF1CC"
        )),
    )
