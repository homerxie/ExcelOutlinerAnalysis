"""Renderer-measured plot and axis titles, independent of the Qt canvas.

The caller draws once to settle automatic axis-label positions, applies the
returned margins without changing the axes' physical sizes, then draws again.
Only vertical axis titles are automatically wrapped; explicit newlines in all
titles remain editable text for vector export.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from functools import lru_cache
import math
import weakref

from matplotlib.backends.backend_agg import RendererAgg, get_hinting_flag
from matplotlib.text import Text
from matplotlib.transforms import Affine2D, Bbox, ScaledTranslation
import numpy as np

from easygraph.plotting.group_label_metrics import (
    _clusters,
    _legal_break,
    _preferred_break,
    text_ink_bounds_points,
)


@dataclass(frozen=True)
class TitleLayoutResult:
    left_px: int = 0
    right_px: int = 0
    bottom_px: int = 0
    top_px: int = 0
    changed: bool = False

    @property
    def margins(self) -> tuple[int, int, int, int]:
        return self.left_px, self.right_px, self.bottom_px, self.top_px

    @property
    def needs_expansion(self) -> bool:
        return any(self.margins)


def _transformed_bounds(bounds: Bbox, transform) -> Bbox:
    # Bbox.transformed assumes axis-aligned scale/translation and collapses
    # a 90-degree rectangle. Transform all four corners for rotated text.
    corners = transform.transform((
        (bounds.x0, bounds.y0), (bounds.x0, bounds.y1),
        (bounds.x1, bounds.y0), (bounds.x1, bounds.y1),
    ))
    return Bbox.from_extents(*corners.min(axis=0), *corners.max(axis=0))


@lru_cache(maxsize=2048)
def _agg_line_bitmap_bounds(renderer_ref, text, font_properties, antialiased, hinting):
    """Read the same FreeType bitmap that RendererAgg.draw_text draws.

    Cache immutable measurements, never FreeType's mutable image/font object.
    A weak renderer reference avoids retaining discarded preview canvases.
    """
    renderer = renderer_ref()
    if renderer is None:
        return None
    font = renderer._prepare_font(font_properties)
    font.set_text(text, 0, flags=hinting)
    font.draw_glyphs_to_bitmap(antialiased=antialiased)
    bitmap = np.asarray(font.get_image())
    columns = np.flatnonzero(bitmap.any(axis=0))
    rows = np.flatnonzero(bitmap.any(axis=1))
    if not len(columns) or not len(rows):
        return None
    height = bitmap.shape[0]
    bounds = (
        float(columns[0]), float(height - rows[-1] - 1),
        float(columns[-1] + 1), float(height - rows[0]),
    )
    x_offset, y_offset = font.get_bitmap_offset()
    return bounds, x_offset / 64.0, y_offset / 64.0, font.get_descent() / 64.0


def _agg_text_ink_bounds(artist: Text, renderer) -> Bbox | None:
    """Match Agg's per-line raster positioning, including rotated bearings."""
    if not isinstance(renderer, RendererAgg) or artist.get_usetex():
        return None
    _, lines, _ = artist._get_layout(renderer)
    anchor = artist.get_transform().transform(artist.get_unitless_position())
    canvas_height = renderer.get_canvas_width_height()[1]
    angle = artist.get_rotation()
    sine, cosine = math.sin(math.radians(angle)), math.cos(math.radians(angle))
    rotation = Affine2D().rotate_deg(angle)
    bounds = []
    for line, _dimensions, x, y in lines:
        clean_line, ismath = artist._preprocess_math(line)
        if ismath:
            # Mathtext has a different drawing path; use outline bounds for
            # the complete title below rather than partially measuring it.
            return None
        if not clean_line:
            continue
        measured = _agg_line_bitmap_bounds(
            weakref.ref(renderer), clean_line, artist.get_fontproperties().copy(),
            artist.get_antialiased(), get_hinting_flag(),
        )
        if measured is None:
            continue
        ink, x_offset, y_offset, descent = measured
        # Agg adds the unrotated bitmap's bearing to *display* x even when
        # rotating. Rotating outline bounds misses this, notably for CJK
        # opening parentheses with a substantial left side bearing.
        draw_x = round(anchor[0] + x + x_offset + descent * sine)
        draw_y = canvas_height - (
            round(canvas_height - anchor[1] - y + y_offset + descent * cosine) + 1
        )
        raster_bounds = _transformed_bounds(
            Bbox.from_extents(*ink), rotation + Affine2D().translate(draw_x, draw_y)
        )
        # Account for the support of Agg's rotated bitmap sampling, at most
        # one pixel past the transformed bitmap's occupied pixel cells.
        bounds.append(Bbox.from_extents(
            math.floor(raster_bounds.x0) - 1, math.floor(raster_bounds.y0) - 1,
            math.ceil(raster_bounds.x1) + 1, math.ceil(raster_bounds.y1) + 1,
        ))
    return Bbox.union(bounds) if bounds else None


def measured_text_bounds(artist: Text, renderer) -> Bbox:
    """Measure layout and glyph overhangs in final renderer display pixels.

    Matplotlib's layout extent contains advances (including whitespace), but
    italic glyphs can extend beyond it. Agg is measured from the actual
    FreeType bitmaps, including its per-line raster bearing offsets; other
    renderers and mathtext use outlines. A separate call-site margin provides
    intentional spacing without guessing widths from a character count.
    """
    layout_bounds = artist.get_window_extent(renderer)
    if not artist.get_visible() or not artist.get_text():
        return layout_bounds
    raster_bounds = _agg_text_ink_bounds(artist, renderer)
    if raster_bounds is not None:
        return Bbox.union((layout_bounds, raster_bounds))
    probe = copy.copy(artist)
    probe.set_rotation(0)
    probe.set_transform_rotates_text(False)
    ink = text_ink_bounds_points(probe, renderer)
    if ink is None:
        return layout_bounds
    _, original_lines, _ = artist._get_layout(renderer)
    _, unrotated_lines, _ = probe._get_layout(renderer)
    if not original_lines or not unrotated_lines:
        return layout_bounds
    rotation = Affine2D().rotate_deg(artist.get_rotation())
    original_baseline = original_lines[0][2:4]
    unrotated_baseline = rotation.transform(unrotated_lines[0][2:4])
    anchor = artist.get_transform().transform(artist.get_unitless_position())
    transform = (
        Affine2D().scale(renderer.points_to_pixels(1.0))
        + rotation
        + Affine2D().translate(
            anchor[0] + original_baseline[0] - unrotated_baseline[0],
            anchor[1] + original_baseline[1] - unrotated_baseline[1],
        )
    )
    ink_bounds = _transformed_bounds(ink, transform)
    return Bbox.union((layout_bounds, ink_bounds))


def _wrap_with_renderer(artist: Text, text: str, renderer, limit_px: float) -> str:
    probe = copy.copy(artist)
    probe.set_rotation(0)
    probe.set_transform_rotates_text(False)
    probe.set_wrap(False)
    widths: dict[str, float] = {}

    def fits(value: str) -> bool:
        if value not in widths:
            probe.set_text(value)
            widths[value] = probe.get_window_extent(renderer).width
        return widths[value] <= limit_px + 1e-7

    def ink_fits(value: str) -> bool:
        probe.set_text(value)
        return measured_text_bounds(probe, renderer).width <= limit_px + 1e-7

    paragraphs: list[str] = []
    for paragraph in text.split("\n"):
        clusters = _clusters(paragraph)
        lines: list[str] = []
        while clusters:
            # Discover a small measured prefix bound before binary search.
            # Measuring the entire remaining paragraph on every line makes
            # wrapping very long pasted titles unnecessarily quadratic.
            low, high = 0, min(16, len(clusters))
            while high < len(clusters) and fits("".join(clusters[:high])):
                low, high = high, min(high * 2, len(clusters))
            if (high == len(clusters) and fits("".join(clusters))
                    and ink_fits("".join(clusters))):
                lines.append("".join(clusters))
                break
            # Binary search avoids a measurement for every growing prefix of
            # long pasted labels. Final complete lines are measured again.
            while low + 1 < high:
                middle = (low + high) // 2
                if fits("".join(clusters[:middle])):
                    low = middle
                else:
                    high = middle
            candidates = [
                count for count in range(1, low + 1)
                if _legal_break(clusters[count - 1], clusters[count])
            ]
            preferred = [
                count for count in candidates
                if _preferred_break(clusters[count - 1], clusters[count])
            ]
            if preferred:
                split = preferred[-1]
            elif candidates:
                split = candidates[-1]
            else:
                # An indivisible math expression, grapheme, or punctuation
                # pair is retained intact even if it exceeds a tiny limit.
                split = max(1, low)
                while split < len(clusters) and not _legal_break(
                    clusters[split - 1], clusters[split]
                ):
                    split += 1
            # Prefix search uses renderer advances; check the chosen line's
            # actual ink before accepting it, including italic overhangs.
            while split > 1 and not ink_fits("".join(clusters[:split])):
                earlier = [count for count in candidates if count < split]
                if not earlier:
                    break
                split = earlier[-1]
            lines.append("".join(clusters[:split]))
            clusters = clusters[split:]
        paragraphs.append("\n".join(lines))
    return "\n".join(paragraphs)


def wrap_vertical_title(artist: Text, renderer, available_height_px: float) -> bool:
    """Wrap a vertical title using its renderer and retain its original text.

    Safe on a shallow copy for an input-only preview. The caller passes the
    height after subtracting its desired end margins. Existing explicit
    newlines and all original characters are preserved; Latin words stay
    together when they fit, while long words and CJK can break by grapheme.
    """
    if not math.isfinite(available_height_px) or available_height_px <= 0:
        return False
    current = artist.get_text()
    previous = getattr(artist, "_title_layout_wrapped_text", None)
    source = (
        getattr(artist, "_title_layout_source_text", current)
        if current == previous else current
    )
    signature = (
        source, round(available_height_px, 6),
        artist.get_fontproperties().copy(), renderer.points_to_pixels(1.0),
        artist.get_parse_math(), artist.get_usetex(),
    )
    if (current == previous and not artist.get_wrap()
            and getattr(artist, "_title_layout_wrap_signature", None) == signature):
        return False
    # Reserve one pixel for centering a raster box around a fractional-pixel
    # axes center, then verify the fully rotated multiline result as well.
    wrap_width = max(1.0, available_height_px - 1.0)
    wrapped = _wrap_with_renderer(artist, source, renderer, wrap_width)
    if math.isclose(artist.get_rotation() % 180, 90, abs_tol=1e-6):
        probe = copy.copy(artist)
        probe.set_wrap(False)
        probe.set_text(wrapped)
        for _ in range(3):
            overflow = measured_text_bounds(probe, renderer).height - available_height_px + 1
            if overflow <= 1e-6:
                break
            wrap_width = max(1.0, wrap_width - overflow - 1)
            candidate = _wrap_with_renderer(artist, source, renderer, wrap_width)
            if candidate == wrapped:
                break  # One indivisible expression cannot be wrapped more.
            wrapped = candidate
            probe.set_text(wrapped)
    artist._title_layout_source_text = source
    artist._title_layout_wrapped_text = wrapped
    artist._title_layout_wrap_signature = signature
    changed = current != wrapped or artist.get_wrap()
    artist.set_wrap(False)
    if current != wrapped:
        artist.set_text(wrapped)
    return changed


def fit_axis_titles(figure, axes, renderer, *, margin_points: float = 3.0) -> TitleLayoutResult:
    """Wrap vertical titles and return required extra figure margins.

    The y title stays within its own axis span so a long horizontal title can
    extend across the figure without intersecting it. This also works for
    right-side twins and separate upper/lower axes. Axes and table geometry
    are never resized here. Call after existing labels/guides are positioned.
    """
    margin_px = max(0.0, renderer.points_to_pixels(margin_points))
    bounds: list[Bbox] = []
    changed = False
    active_axes = [
        ax for ax in axes
        if ax is not None and ax.get_visible() and ax.axison
    ]
    oversized_vertical_titles: list[Bbox] = []
    for ax in active_axes:
        axis_bounds = ax.get_window_extent(renderer)
        label = ax.yaxis.label
        if ax.yaxis.get_visible() and label.get_visible() and label.get_text():
            changed |= wrap_vertical_title(
                label, renderer, max(1.0, axis_bounds.height - 2 * margin_px)
            )
            label_bounds = measured_text_bounds(label, renderer)
            # Use the measured box center, including ink overhangs, rather
            # than assuming that Text's anchor is its geometric midpoint.
            delta_px = (
                (axis_bounds.y0 + axis_bounds.y1)
                - (label_bounds.y0 + label_bounds.y1)
            ) / 2.0
            # Agg places bitmap ink on integer pixels, so its center cannot
            # always equal an axes center at a fractional pixel. Avoid an
            # endless half-pixel centering oscillation on subsequent draws.
            if abs(delta_px) > 0.51:
                anchor = label.get_transform().transform(label.get_unitless_position())
                new_position = label.get_transform().inverted().transform(
                    (anchor[0], anchor[1] + delta_px)
                )
                label.set_position(new_position)
                changed = True
            label_bounds = measured_text_bounds(label, renderer)
            low, high = sorted(ax.get_ylim())
            ticks = [
                text for tick in (*ax.yaxis.get_major_ticks(), *ax.yaxis.get_minor_ticks())
                if low <= tick.get_loc() <= high
                for text in (tick.label1, tick.label2)
                if text.get_visible() and text.get_text()
            ]
            tick_bounds = [measured_text_bounds(text, renderer) for text in ticks]
            if ax.yaxis.get_label_position() == "right":
                target = max([axis_bounds.x1, *(bbox.x1 for bbox in tick_bounds)]) + margin_px
                horizontal_shift = math.ceil(max(0.0, target - label_bounds.x0))
            else:
                target = min([axis_bounds.x0, *(bbox.x0 for bbox in tick_bounds)]) - margin_px
                horizontal_shift = -math.ceil(max(0.0, label_bounds.x1 - target))
            if horizontal_shift:
                ax.yaxis.labelpad += abs(horizontal_shift) / renderer.points_to_pixels(1)
                anchor = label.get_transform().transform(label.get_unitless_position())
                label.set_position(label.get_transform().inverted().transform(
                    (anchor[0] + horizontal_shift, anchor[1])
                ))
                changed = True
            if label_bounds.height > axis_bounds.height - 2 * margin_px + 1e-6:
                oversized_vertical_titles.append(measured_text_bounds(label, renderer))

    # A single grapheme or complete math expression may be taller than its
    # axis even when on a line of its own. Keep that content intact and move
    # horizontal titles out of its way; the resulting outer margins expand
    # the figure, without shrinking the font or changing the plot size.
    for ax in active_axes:
        for title in (ax.title, ax._left_title, ax._right_title):
            if not title.get_visible() or not title.get_text():
                continue
            title_bounds = measured_text_bounds(title, renderer)
            obstacles = [bbox for bbox in oversized_vertical_titles
                         if bbox.x0 < title_bounds.x1 and bbox.x1 > title_bounds.x0
                         and bbox.y0 < title_bounds.y1 and bbox.y1 > title_bounds.y0]
            if obstacles:
                delta_px = max(bbox.y1 for bbox in obstacles) + margin_px - title_bounds.y0
                title.set_transform(title.get_transform() + ScaledTranslation(
                    0, delta_px / figure.dpi, figure.dpi_scale_trans,
                ))
                changed = True
        xlabel = ax.xaxis.label
        if ax.xaxis.get_visible() and xlabel.get_visible() and xlabel.get_text():
            label_bounds = measured_text_bounds(xlabel, renderer)
            obstacles = [bbox for bbox in oversized_vertical_titles
                         if bbox.x0 < label_bounds.x1 and bbox.x1 > label_bounds.x0
                         and bbox.y0 < label_bounds.y1 and bbox.y1 > label_bounds.y0]
            if obstacles:
                if ax.xaxis.get_label_position() == "top":
                    delta_px = max(bbox.y1 for bbox in obstacles) + margin_px - label_bounds.y0
                else:
                    delta_px = label_bounds.y1 - min(bbox.y0 for bbox in obstacles) + margin_px
                ax.xaxis.labelpad += delta_px / renderer.points_to_pixels(1)
                changed = True

    for ax in active_axes:
        titles = [ax.title, ax._left_title, ax._right_title]
        if ax.xaxis.get_visible():
            titles.append(ax.xaxis.label)
        if ax.yaxis.get_visible():
            titles.append(ax.yaxis.label)
        for title in titles:
            if not title.get_visible() or not title.get_text():
                continue
            if title.get_wrap():
                title.set_wrap(False)
                changed = True
            bbox = measured_text_bounds(title, renderer)
            if all(math.isfinite(value) for value in bbox.extents):
                bounds.append(bbox)
        # Long horizontal coordinates can extend past the figure even when
        # the axis title fits. Preserve the chart's existing tick rotation
        # and wrapping; only reserve canvas around their measured bounds.
        if not ax.xaxis.get_visible():
            continue
        low, high = sorted(ax.get_xlim())
        for tick in (*ax.xaxis.get_major_ticks(), *ax.xaxis.get_minor_ticks()):
            if not low <= tick.get_loc() <= high:
                continue
            for tick_label in (tick.label1, tick.label2):
                if not tick_label.get_visible() or not tick_label.get_text():
                    continue
                bbox = measured_text_bounds(tick_label, renderer)
                if all(math.isfinite(value) for value in bbox.extents):
                    bounds.append(bbox)
    if not bounds:
        return TitleLayoutResult(changed=changed)
    all_bounds = Bbox.union(bounds)
    figure_bounds = figure.bbox
    return TitleLayoutResult(
        left_px=math.ceil(max(0.0, figure_bounds.x0 + margin_px - all_bounds.x0)),
        right_px=math.ceil(max(0.0, all_bounds.x1 + margin_px - figure_bounds.x1)),
        bottom_px=math.ceil(max(0.0, figure_bounds.y0 + margin_px - all_bounds.y0)),
        top_px=math.ceil(max(0.0, all_bounds.y1 + margin_px - figure_bounds.y1)),
        changed=changed,
    )
