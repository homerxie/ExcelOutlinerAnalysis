"""Display-only wrapping and physical sizing for chart statistics headers."""
from __future__ import annotations

from dataclasses import dataclass

from matplotlib.font_manager import FontProperties
from matplotlib.text import Text

from easygraph.plotting.group_label_metrics import wrap_label


@dataclass(frozen=True)
class StatHeaderCell:
    left: float
    right: float
    text: str
    level: str

    @property
    def center(self) -> float:
        return (self.left + self.right) / 2


@dataclass(frozen=True)
class StatHeaderRow:
    cells: tuple[StatHeaderCell, ...]
    height_points: float


@dataclass(frozen=True)
class StatHeaderLayout:
    rows: tuple[StatHeaderRow, ...]
    plot_width_points: float

    @property
    def height_points(self) -> float:
        return sum(row.height_points for row in self.rows)


@dataclass(frozen=True)
class RidgeStatHeaderLayout:
    labels: tuple[str, ...]
    column_widths_inches: tuple[float, ...]
    row_heights_inches: tuple[float, ...]
    header_height_inches: float


def _font(settings, *, parent=False) -> FontProperties:
    return FontProperties(size=max(settings.stat_table_font_size, 1), weight="medium" if parent else "normal")


def _measure(text, font, figure, renderer) -> tuple[float, float]:
    probe = Text(0, 0, str(text), fontproperties=font, ha="center", va="center", linespacing=1.15)
    probe.set_figure(figure)
    bounds = probe.get_window_extent(renderer)
    scale = renderer.points_to_pixels(1)
    return bounds.width / scale, bounds.height / scale


def _display_text(source: str, width_points: float, font: FontProperties) -> str:
    # A newline is an explicit user layout, not just a paragraph to reflow.
    return source if "\n" in source else wrap_label(source, width_points, font)


def prepare_stat_header_layout(layout, groups, settings, plot_width_points, figure, renderer) -> StatHeaderLayout:
    """Prepare real parent spans and leaf cells without changing source names.

    Normal names wrap within the requested plot width. Explicit manual lines
    and indivisible expressions may require more width; the caller applies
    that width to both the chart and the table so column centers stay aligned.
    """
    half_width = layout.inner_spacing / 2
    low, high = layout.limits
    coordinate_width = max(high - low, 1e-9)
    base_height = max(settings.stat_table_font_size, 1) + 7.2
    sources = []
    if layout.parents:
        parents = [StatHeaderCell(parent.start - half_width, parent.end + half_width, parent.label, "parent")
                   for parent in layout.parents]
        covered = {key for key in groups if any(cell.left < layout.positions[key] < cell.right for cell in parents)}
        parents.extend(StatHeaderCell(layout.positions[key] - half_width, layout.positions[key] + half_width, "", "parent")
                       for key in groups if key not in covered)
        sources.append(sorted(parents, key=lambda cell: cell.left))
    sources.append([StatHeaderCell(layout.positions[key] - half_width, layout.positions[key] + half_width,
                                   layout.labels[key], "leaf") for key in groups])
    width = plot_width_points
    for _attempt in range(3):
        result = []
        required_width = width
        for row in sources:
            cells = []
            height = base_height
            for source in row:
                span = source.right - source.left
                font = _font(settings, parent=source.level == "parent")
                available = max(font.get_size_in_points(), span * width / coordinate_width - 4)
                text = _display_text(source.text, available, font)
                measured_width, measured_height = _measure(text, font, figure, renderer)
                height = max(height, measured_height + 6)
                # Two points of slack between wrap budget and fitting budget
                # absorb font hinting without widening normally wrapped cells.
                required_width = max(required_width, (measured_width + 2) * coordinate_width / span)
                cells.append(StatHeaderCell(source.left, source.right, text, source.level))
            result.append(StatHeaderRow(tuple(cells), height))
        if required_width <= width + 0.01:
            break
        width = required_width
    return StatHeaderLayout(tuple(result), width)


def prepare_ridge_stat_header_layout(labels, rows, settings, plot_width_points, figure, renderer) -> RidgeStatHeaderLayout:
    """Wrap the side table's category column, leaving numeric columns intact."""
    font = _font(settings)
    target_width = max(48, min(144, plot_width_points * 0.35))
    display = tuple(_display_text(str(label), target_width, font) for label in labels)
    columns = [["", *display], *[[label, *values] for label, values in rows]]
    widths = tuple((max(_measure(value, font, figure, renderer)[0] for value in column) + 14.4) / 72
                   for column in columns)
    base_height = max(settings.stat_table_font_size, 1) + 7.2
    heights = tuple(max(base_height, _measure(label, font, figure, renderer)[1] + 6) / 72 for label in display)
    header_height = max([base_height, *[_measure(label, font, figure, renderer)[1] + 6 for label, _ in rows]]) / 72
    return RidgeStatHeaderLayout(display, widths, heights, header_height)
