"""Small Agg text layers displayed over a cached chart while titles are edited."""
from __future__ import annotations

from collections.abc import Iterable
from copy import copy
from dataclasses import dataclass
import math

from matplotlib.backends.backend_agg import RendererAgg
from matplotlib.text import Text
from matplotlib.transforms import Affine2D, IdentityTransform
from PySide6.QtCore import QEvent, QPoint, QPointF, Qt
from PySide6.QtGui import QImage, QPainter
from PySide6.QtWidgets import QWidget

from easygraph.plotting.title_layout import measured_text_bounds, wrap_vertical_title


@dataclass(frozen=True)
class _TitleImage:
    image: QImage
    left_px: float
    top_px: float


def _render_title(artist: Text, text: str, dpi: float, ratio: float) -> _TitleImage | None:
    """Render only a detached title, retaining its original display-pixel anchor.

    In particular, do not call Figure.draw, canvas.draw, or modify the source
    artist: the cached full chart and export state remain the committed state.
    """
    if not text or not artist.get_visible():
        return None
    title = copy(artist)
    title.stale_callback = None
    title._fontproperties = copy(artist.get_fontproperties())
    if title.get_bbox_patch() is not None:
        title._bbox_patch = copy(title.get_bbox_patch())
        title._bbox_patch.stale_callback = None
    # A source label can already contain the layout helper's automatic wraps.
    # Every preview starts from the actual current input, not that old source.
    for name in ("_title_layout_source_text", "_title_layout_wrapped_text"):
        title.__dict__.pop(name, None)
    title.set_text(text)
    title.set_wrap(False)
    title.set_clip_on(False)
    anchor = artist.get_transform().transform(artist.get_unitless_position())
    title.set_position(anchor)
    title.set_transform(IdentityTransform())
    title.set_transform_rotates_text(False)
    title.set_rotation(artist.get_rotation())

    measure = RendererAgg(1, 1, dpi)
    # Axis-owned Text objects do not necessarily expose ``artist.axes``.
    axes = next((ax for ax in artist.figure.axes if artist is ax.yaxis.label), None)
    unchanged = text in (artist.get_text(), getattr(artist, "_title_layout_source_text", None))
    if axes is not None and unchanged:
        # Keep already settled labels pixel-identical when another field is
        # edited, including the automatic line breaks of a committed label.
        title.set_text(artist.get_text())
    elif axes is not None:
        span = axes.get_window_extent(measure)
        wrap_vertical_title(title, measure, max(1.0, span.height - 2 * measure.points_to_pixels(3)))
        box = measured_text_bounds(title, measure)
        source = copy(artist)
        source.stale_callback = None
        source_bounds = measured_text_bounds(source, measure)
        # The original label's measured edge is the stable boundary next to
        # the ticks. Rotation and glyph bearings can make a wrapped title
        # extend past its anchor, so align actual bounds instead of assuming
        # that ha/va makes that edge stationary.
        ticks = [label for tick in (*axes.yaxis.majorTicks, *axes.yaxis.minorTicks)
                 for label in (tick.label1, tick.label2)
                 if label.get_visible() and label.get_text()]
        tick_bounds = [tick.get_window_extent(measure) for tick in ticks]
        gap = measure.points_to_pixels(axes.yaxis.labelpad)
        if axes.yaxis.get_label_position() == "right":
            edge = source_bounds.x0
            if tick_bounds:
                edge = max(edge, max(tick.x1 for tick in tick_bounds) + gap)
            dx = edge - box.x0
        else:
            edge = source_bounds.x1
            if tick_bounds:
                edge = min(edge, min(tick.x0 for tick in tick_bounds) - gap)
            dx = edge - box.x1
        title.set_position((
            title.get_position()[0] + dx,
            title.get_position()[1] + (span.y0 + span.y1 - box.y0 - box.y1) / 2,
        ))

    bounds = measured_text_bounds(title, measure)
    if not all(math.isfinite(value) for value in bounds.extents):
        return None
    # Use outward-rounded renderer bounds, including negative glyph bearings,
    # and a small physical-pixel allowance for antialiasing at the crop edge.
    left = math.floor(bounds.x0) - 3
    bottom = math.floor(bounds.y0) - 3
    right = math.ceil(bounds.x1) + 3
    top = math.ceil(bounds.y1) + 3
    width, height = max(1, right - left), max(1, top - bottom)
    renderer = RendererAgg(width, height, dpi)
    title.set_transform(Affine2D().translate(-left, -bottom))
    title.draw(renderer)
    image = QImage(renderer.buffer_rgba(), width, height, width * 4, QImage.Format.Format_RGBA8888).copy()
    image.setDevicePixelRatio(ratio)
    return _TitleImage(image, left, artist.figure.bbox.height - top)


class TextPreviewLayer(QWidget):
    """Viewport overlay that permits text to extend past the old figure edge.

    ``owner`` provides ``scroll``, ``canvas`` and ``figure``. ``background`` is
    the complete title-free Agg buffer, with the canvas device-pixel ratio.
    ``bindings`` contains every visible title artist and its current raw text,
    including unchanged titles and empty strings used to remove a title.
    """

    def __init__(self, owner) -> None:
        viewport = owner.scroll.viewport()
        super().__init__(viewport)
        self._owner = owner
        self._background: QImage | None = None
        self._images: list[_TitleImage] = []
        self._image_cache: dict[tuple[int, str], _TitleImage | None] = {}
        self._canvas = None
        self.setObjectName("titleInputPreviewLayer")
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setAutoFillBackground(False)
        self.setGeometry(viewport.rect())
        viewport.installEventFilter(self)
        owner.scroll.horizontalScrollBar().valueChanged.connect(self._update_position)
        owner.scroll.verticalScrollBar().valueChanged.connect(self._update_position)
        self.hide()

    def update_preview(self, background: QImage, bindings: Iterable[tuple[Text, str]]) -> bool:
        canvas = self._owner.canvas
        figure = self._owner.figure
        if background is None or background.isNull() or canvas is None or figure is None:
            self.finish()
            return False
        if self._canvas is not canvas:
            if self._canvas is not None:
                try:
                    self._canvas.removeEventFilter(self)
                except RuntimeError:
                    pass  # A replaced FigureCanvas may already be deleted.
            self._canvas = canvas
            canvas.installEventFilter(self)
        if self._background is None or self._background.cacheKey() != background.cacheKey():
            self._image_cache.clear()
        self._background = QImage(background)
        ratio = background.devicePixelRatioF()
        images = []
        current_cache = {}
        for artist, text in bindings:
            key = (id(artist), text)
            if key in self._image_cache:
                rendered = self._image_cache[key]
            else:
                rendered = _render_title(artist, text, figure.dpi, ratio)
            current_cache[key] = rendered
            if rendered is not None:
                images.append(rendered)
        self._image_cache = current_cache
        self._images = images
        self.setGeometry(self.parentWidget().rect())
        self.show()
        self.raise_()
        self.update()
        return True

    def finish(self) -> None:
        self.hide()
        self._background = None
        self._images.clear()
        self._image_cache.clear()

    def _update_position(self, *_args) -> None:
        if self._background is not None:
            self.update()

    def eventFilter(self, watched, event) -> bool:
        if watched is self.parentWidget() and event.type() == QEvent.Type.Resize:
            self.setGeometry(watched.rect())
            self._update_position()
        elif watched is self._canvas and event.type() in (QEvent.Type.Move, QEvent.Type.Resize):
            self._update_position()
        return super().eventFilter(watched, event)

    def paintEvent(self, event) -> None:
        if self._background is None or self._canvas is None:
            return
        origin = self._canvas.mapTo(self.parentWidget(), QPoint(0, 0))
        ratio = self._background.devicePixelRatioF()
        painter = QPainter(self)
        painter.drawImage(origin, self._background)
        for rendered in self._images:
            painter.drawImage(
                QPointF(origin.x() + rendered.left_px / ratio, origin.y() + rendered.top_px / ratio),
                rendered.image,
            )
