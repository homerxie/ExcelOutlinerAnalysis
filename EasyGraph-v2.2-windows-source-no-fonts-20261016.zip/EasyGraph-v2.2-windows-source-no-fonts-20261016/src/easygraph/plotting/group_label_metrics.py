"""Font-based wrapping and ink centering for hierarchical axis labels.

All public measurements use typographic points.  Text remains a Matplotlib
``Text`` artist; glyph outlines are used only for measurement, not rendering.
"""
from __future__ import annotations

import copy
from functools import lru_cache
import math
import re
import unicodedata

from matplotlib.font_manager import FontProperties
from matplotlib.path import Path
from matplotlib.text import Text
from matplotlib.textpath import TextToPath
from matplotlib.transforms import Affine2D, Bbox, ScaledTranslation


_TEXT_TO_PATH = TextToPath()
_OPENING = frozenset("([{（［｛〈《「『【〔〖〘〚‘“")
_CLOSING = frozenset(")]}）］｝〉》」』】〕〗〙〛’”，。、；：！？,.!?;:%‰°")
_MATH_SPAN = re.compile(r"(?<!\\)\$(?:\\.|[^$])*(?<!\\)\$")


def text_width_points(
    text: str,
    font_properties: FontProperties,
    *,
    parse_math: bool = True,
    usetex: bool = False,
) -> float:
    """Return the widest line's advance width, including spaces and kerning.

    Mathtext uses the same preprocessing as a normal Matplotlib ``Text``.
    The measurement does not depend on a window, renderer DPI, or Qt.
    """
    probe = Text(parse_math=parse_math, usetex=usetex)
    widths = []
    for line in str(text).split("\n"):
        clean, ismath = probe._preprocess_math(line)
        widths.append(_TEXT_TO_PATH.get_text_width_height_descent(
            clean, font_properties, ismath
        )[0])
    return max(widths, default=0.0)


def _clusters(text: str) -> list[str]:
    """Keep combining characters and complete math expressions together."""
    result: list[str] = []
    position = 0
    math_spans = {match.start(): match for match in _MATH_SPAN.finditer(text)}
    while position < len(text):
        expression = math_spans.get(position)
        if expression is not None:
            result.append(expression.group())
            position = expression.end()
            continue
        char = text[position]
        if result and (unicodedata.combining(char) or char in "\ufe0e\ufe0f\u200d"
                       or result[-1].endswith("\u200d")):
            result[-1] += char
        else:
            result.append(char)
        position += 1
    return result


def _legal_break(left: str, right: str) -> bool:
    return left[-1] not in _OPENING and right[0] not in _CLOSING


def _preferred_break(left: str, right: str) -> bool:
    if left[-1].isspace():
        return not right[0].isspace()
    if right[0].isspace():
        return False
    return (
        left[-1] in "-/–—"
        or unicodedata.east_asian_width(left[-1]) in {"W", "F"}
        or unicodedata.east_asian_width(right[0]) in {"W", "F"}
    )


def wrap_label(text: str, max_width_points: float, font_properties: FontProperties) -> str:
    """Wrap at real font advances, preserving every original character.

    Existing newlines remain explicit paragraph boundaries.  Latin words are
    kept together when they fit; long words may be split.  CJK characters can
    break individually, while opening/closing punctuation stays attached.
    Complete ``$mathtext$`` expressions and combining-character clusters are
    indivisible, so those (or a single glyph) can exceed an extremely narrow
    limit.  No characters or spaces are discarded, including at line ends; preserved
    trailing spaces may extend past the limit without adding visible ink.
    A nonpositive or nonfinite width leaves the original text unchanged.
    """
    text = str(text)
    if max_width_points <= 0 or not math.isfinite(max_width_points):
        return text
    widths: dict[str, float] = {}

    def fits(value: str) -> bool:
        if value not in widths:
            widths[value] = text_width_points(value, font_properties)
        return widths[value] <= max_width_points + 1e-9

    paragraphs: list[str] = []
    for paragraph in text.split("\n"):
        remaining = _clusters(paragraph)
        lines: list[str] = []
        while remaining:
            if fits("".join(remaining)):
                lines.append("".join(remaining))
                break
            fit_count = 0
            for count in range(1, len(remaining) + 1):
                if not fits("".join(remaining[:count])):
                    break
                fit_count = count
            candidates = [
                count for count in range(1, min(fit_count, len(remaining) - 1) + 1)
                if _legal_break(remaining[count - 1], remaining[count])
            ]
            preferred = [count for count in candidates
                         if _preferred_break(remaining[count - 1], remaining[count])]
            if preferred:
                split = preferred[-1]
            elif candidates:
                split = candidates[-1]
            else:
                # A punctuation pair or one indivisible glyph can be wider
                # than the available space; keep it intact instead of losing it.
                split = max(1, fit_count)
                while split < len(remaining) and not _legal_break(remaining[split - 1], remaining[split]):
                    split += 1
            # Keep a separating space with the preceding word rather than
            # creating an indented line or a line containing only that space.
            while split < len(remaining) and remaining[split].isspace():
                split += 1
            lines.append("".join(remaining[:split]))
            remaining = remaining[split:]
        paragraphs.append("\n".join(lines))
    return "\n".join(paragraphs)


@lru_cache(maxsize=2048)
def _line_ink_extents(
    line: str, font_properties: FontProperties, ismath: bool | str
) -> tuple[float, float, float, float] | None:
    # This is TextPath's underlying outline generator, with an explicit math
    # mode so parse_math=False and escaped dollar signs match the real Text.
    vertices, codes = _TEXT_TO_PATH.get_text_path(font_properties, line, ismath=ismath)
    if len(vertices) == 0:
        return None
    scale = font_properties.get_size_in_points() / _TEXT_TO_PATH.FONT_SCALE
    bounds = Path(vertices, codes).get_extents(Affine2D().scale(scale))
    if not all(math.isfinite(value) for value in bounds.extents):
        return None
    return tuple(float(value) for value in bounds.extents)


def text_ink_bounds_points(text_artist: Text, renderer) -> Bbox | None:
    """Return unrotated ink bounds relative to the artist's anchor, in points.

    Unlike ``get_window_extent``, these bounds come from the actual outlines.
    The original Text layout supplies each line's baseline, honoring multiline
    alignment, line spacing, mathtext, and empty lines.  The only private API
    coupling is Matplotlib's own line-layout/preprocessing interface, kept here
    rather than duplicating its baseline algorithm in the chart renderer.
    """
    probe = copy.copy(text_artist)
    probe.set_rotation(0)
    probe.set_transform_rotates_text(False)
    pixels_per_point = renderer.points_to_pixels(1.0)
    _, lines, _ = probe._get_layout(renderer)
    bounds: list[Bbox] = []
    for line, _dimensions, x, y in lines:
        clean_line, ismath = probe._preprocess_math(line)
        if not clean_line:
            continue
        # Copy properties before caching: FontProperties is hashable but
        # mutable, and callers may subsequently change a tick's font size.
        extents = _line_ink_extents(clean_line, probe.get_fontproperties().copy(), ismath)
        if extents is None:
            continue
        x0, y0, x1, y1 = extents
        bounds.append(Bbox.from_extents(
            x0 + x / pixels_per_point, y0 + y / pixels_per_point,
            x1 + x / pixels_per_point, y1 + y / pixels_per_point,
        ))
    return Bbox.union(bounds) if bounds else None


def normal_center_offset_points(text_artist: Text, renderer) -> float:
    """Local vertical translation that puts the complete ink block on y=0."""
    bounds = text_ink_bounds_points(text_artist, renderer)
    return 0.0 if bounds is None else -(bounds.y0 + bounds.y1) / 2.0


def position_rotated_label(text_artist: Text, renderer) -> float:
    """Center ink about the anchor's rotated baseline; return the shift in pt.

    Set ``rotation_mode='anchor'`` before calling.  For axis labels, use
    ``va='baseline'``, and ``ha='right'`` for positive angles (``left`` for
    negative angles).  The whole label moves along its local normal; its
    advance direction and editable Text content stay intact.  Translations
    use figure DPI transforms, so export at a different DPI scales correctly.
    Repeated calls replace the previous correction instead of accumulating it.
    """
    if text_artist.get_rotation_mode() != "anchor":
        raise ValueError("Ink centering requires rotation_mode='anchor'.")
    figure = text_artist.get_figure()
    if figure is None:
        raise ValueError("Ink centering requires a Text attached to a figure.")
    correction = normal_center_offset_points(text_artist, renderer)
    current = text_artist.get_transform()
    previous = getattr(text_artist, "_group_ink_corrected_transform", None)
    base = (text_artist._group_ink_base_transform
            if current is previous else current)
    angle = math.radians(text_artist.get_rotation())
    translation = ScaledTranslation(
        -math.sin(angle) * correction / 72.0,
        math.cos(angle) * correction / 72.0,
        figure.dpi_scale_trans,
    )
    corrected = base + translation
    text_artist._group_ink_base_transform = base
    text_artist._group_ink_corrected_transform = corrected
    text_artist.set_transform(corrected)
    return correction
