"""Shared display-only text layout for table names and merged headers."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QFont, QFontMetrics, QTextLayout, QTextOption


@dataclass(frozen=True)
class HeaderTextLayout:
    paragraphs: tuple[QTextLayout, ...]
    height: int
    line_count: int

    def draw(self, painter, rect) -> None:
        rect = QRectF(rect)
        origin = QPointF(rect.left(), rect.top() + (rect.height() - self.height) / 2)
        painter.save()
        try:
            painter.setClipRect(rect, Qt.ClipOperation.IntersectClip)
            for paragraph in self.paragraphs:
                paragraph.draw(painter, origin)
        finally:
            painter.restore()


def header_text_layout(text: str, font: QFont, width: float) -> HeaderTextLayout:
    return _cached_layout(str(text), font.toString(), max(1, int(width)))


@lru_cache(maxsize=1024)
def _cached_layout(text: str, font_description: str, width: int) -> HeaderTextLayout:
    font = QFont()
    font.fromString(font_description)
    spacing = QFontMetrics(font).lineSpacing()
    normalized = text.replace('\r\n', '\n').replace('\r', '\n').replace('\u2028', '\n').replace('\u2029', '\n')
    manual = '\n' in normalized
    paragraphs = normalized.split('\n')
    layouts = []
    line_count = 0
    height = 0
    for paragraph in paragraphs:
        layout = QTextLayout(paragraph, font)
        option = QTextOption(Qt.AlignmentFlag.AlignHCenter)
        option.setWrapMode(QTextOption.WrapMode.NoWrap if manual else QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
        layout.setTextOption(option)
        layout.beginLayout()
        first_line = True
        while True:
            line = layout.createLine()
            if not line.isValid():
                if first_line:
                    line_count += 1
                    height += spacing
                break
            first_line = False
            line.setLineWidth(width)
            line.setPosition(QPointF(0, height))
            # Fallback CJK glyphs may have larger ascenders/descenders than
            # the Latin UI font. Use the shaped line's metrics, not just the
            # primary font, to keep successive lines and their ink apart.
            height += max(
                spacing,
                math.ceil(line.height()),
                round(line.ascent() + line.descent() + max(0, line.leading())),
            )
            line_count += 1
        layout.endLayout()
        layouts.append(layout)
    return HeaderTextLayout(tuple(layouts), max(spacing, height), max(1, line_count))
