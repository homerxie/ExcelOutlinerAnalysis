"""Localized explanations for statistic selectors, keyed by stable statistic names."""

from html import escape

from PySide6.QtCore import QCoreApplication, QT_TRANSLATE_NOOP


_STATISTIC_TEXT = {
    "Mean": (
        QT_TRANSLATE_NOOP("StatisticLabels", "Mean (arithmetic mean)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "Sum of the valid numeric values divided by their count."),
    ),
    "Median": (
        QT_TRANSLATE_NOOP("StatisticLabels", "Median (50th percentile)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "Middle value after sorting; for an even number of values, the average of the two middle values."),
    ),
    "Q1": (
        QT_TRANSLATE_NOOP("StatisticLabels", "Q1 (first quartile)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "25th percentile: the lower quartile of the sorted values."),
    ),
    "Q3": (
        QT_TRANSLATE_NOOP("StatisticLabels", "Q3 (third quartile)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "75th percentile: the upper quartile of the sorted values."),
    ),
    "Max": (
        QT_TRANSLATE_NOOP("StatisticLabels", "Max (maximum)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "Largest valid numeric value."),
    ),
    "Min": (
        QT_TRANSLATE_NOOP("StatisticLabels", "Min (minimum)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "Smallest valid numeric value."),
    ),
    "SD": (
        QT_TRANSLATE_NOOP("StatisticLabels", "SD (sample standard deviation)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "Spread of individual values around the mean, calculated using n - 1 in the denominator. Requires at least 2 valid numeric values."),
    ),
    "SEM": (
        QT_TRANSLATE_NOOP("StatisticLabels", "SEM (standard error of the mean)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "SE means standard error; SEM is the standard error of the mean. SEM = SD / √n, where n is the sample size. It estimates uncertainty in the mean, while SD describes the spread of individual values. Requires at least 2 valid numeric values."),
    ),
    "Sum": (
        QT_TRANSLATE_NOOP("StatisticLabels", "Sum (total)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "Sum of all valid numeric values."),
    ),
    "Sample": (
        QT_TRANSLATE_NOOP("StatisticLabels", "Sample (sample size, n)"),
        QT_TRANSLATE_NOOP("StatisticLabels", "Number of valid numeric values used in the calculation; blank and non-numeric cells are excluded."),
    ),
}


def statistic_option_text(statistic: str) -> tuple[str, str]:
    """Return the display label and tooltip in the active application language."""
    label, tooltip = _STATISTIC_TEXT.get(statistic, (statistic, ""))
    tooltip = QCoreApplication.translate("StatisticLabels", tooltip)
    return (
        QCoreApplication.translate("StatisticLabels", label),
        f"<qt>{escape(tooltip)}</qt>" if tooltip else "",
    )
