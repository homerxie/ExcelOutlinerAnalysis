from __future__ import annotations

from pathlib import Path


BUNDLED_FONT_FAMILY = "Source Han Sans SC"
BUNDLED_FONT_FILENAMES = (
    "SourceHanSansSC-Regular.otf",
    "SourceHanSansSC-Medium.otf",
    "SourceHanSansSC-Bold.otf",
)


def bundled_font_directory() -> Path:
    """Return the private font directory in source and PyInstaller builds.

    PyInstaller preserves this package-relative location through its data
    mapping, so fonts never need to be installed in the operating system.
    """
    return Path(__file__).resolve().parent / "resources" / "fonts" / "source-han-sans"


def bundled_font_paths() -> tuple[Path, ...]:
    directory = bundled_font_directory()
    return tuple(directory / filename for filename in BUNDLED_FONT_FILENAMES)


def register_bundled_chart_fonts() -> str:
    """Register pinned chart fonts without importing Matplotlib at UI startup."""
    from matplotlib import font_manager

    paths = bundled_font_paths()
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(f"Bundled chart font is missing: {path}")

    manager = font_manager.fontManager
    entries = []
    for path in paths:
        manager.addfont(str(path))
        entries.append(manager.ttflist.pop())
    # Equal font matches are resolved in list order. Prefer our pinned copies
    # even if a different Source Han Sans version is installed on the computer.
    # addfont also invalidates Matplotlib's font lookup cache.
    manager.ttflist[0:0] = entries
    return BUNDLED_FONT_FAMILY
