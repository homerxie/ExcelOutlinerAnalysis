# TSK 概率估算数学原理

本文给出 Logistic 模型下，单个 testkey instance 的条件失效概率、串联 chain 的失效概率，以及由 chain 观测反推参数的方法。分析范围为一个可靠性节点与一个选定批次分组；不同节点分别拟合，不构成连续时间寿命模型。文中 `TSK` 表示 testkey，所有对数均为自然对数。

## 1. 从单个 instance 到串联 chain

### 1.1 失效事件与串联合成

串联合成基于两个假设：

- chain 失效，当且仅当其中至少一个 instance 发生所定义的失效事件。
- 给定类型和所选特征后，同一 chain 内各 instance 的失效相互独立。

Fail 判据应与上述事件一致；累积电性漂移等机制不自动满足该假设。

$$
\boxed{q_c=1-\prod_{j\in\mathcal J_c}(1-p_j)}
$$

其中，$c$ 为 chain 索引，$\mathcal J_c$ 为其 instance 集合；$j$ 为 instance 索引，$p_j$ 为该实例在当前分析条件下的失效概率，$q_c$ 为 chain $c$ 的失效概率。

同一 `TSK_ID` 的不同实例分别参与乘积，不能去重；串联次序不影响结果。

例如，两个实例的失效概率分别为 1% 和 2%，则 chain 失效概率为 $1-0.99\times0.98=2.98\%$。

### 1.2 等价的风险量表达

$$
\boxed{h_j=-\ln(1-p_j),\qquad
H_c=\sum_{j\in\mathcal J_c}h_j,\qquad
q_c=1-e^{-H_c}.}
$$

其中，$h_j$ 为 instance 的负对数通过概率，是无量纲、非负的风险量；$H_c$ 为 chain 的负对数通过概率，由各实例的 $h_j$ 相加得到。$p_j=1$ 对应 $h_j=+\infty$。

使用 $h_j$ 将通过概率的乘法转为加法，不增加物理假设，也不丢失概率信息。$h_j$ 本身不是失效概率，其物理解释边界见附录 B。

## 2. 从 TSK ID、XY 和其他特征估计 instance 概率

### 2.1 输入及编码

| 输入 | 模型中的作用 |
| --- | --- |
| `TSK_instance_ID` | 标识链内具体实例，保留重复数量；不单独拟合实例自由参数 |
| `TSK_ID` | 类型标签，每种类型对应一个截距；编号不作为连续数值 |
| X、Y | 启用后作为两个数值特征；不自动添加径向、平方或空间相关项 |
| 其他数值特征 | 标准化后进入模型 |
| 类别特征 | 采用参考水平编码；各非参考水平各有一个系数 |

数值特征标准化为：

$$
z_{jr}=\frac{x_{jr}-\mu_r}{s_r}.
$$

其中，$r$ 为已选数值特征索引，包括启用的 X、Y；$x_{jr}$ 与 $z_{jr}$ 分别为 instance $j$ 的原始值与标准化值。$\mu_r$、$s_r$ 为有有效 chain 观测的布局实例中，该特征的均值与总体标准差，不按测试次数重复加权。

常量特征的尺度置为 1，其标准化值为 0，并报告常量列诊断。

类别参考水平由完整选定拓扑中的规范化标签按字典序确定，跨数据稀疏分组保持一致；参考水平的系数固定为 0，不代表该类别没有物理风险。

### 2.2 Logistic 概率关系

$$
\eta_j
=\alpha_{t(j)}
+\sum_r\beta_r z_{jr}
+\sum_f\sum_{\ell\ne\ell_{f,0}}
\gamma_{f,\ell}\,I(v_{jf}=\ell).
$$

其中，$\eta_j$ 为 instance 的线性预测值，即失效概率的 log-odds；$t(j)$ 为其 TSK 类型，$\alpha_t$ 为类型 $t$ 的截距。$\beta_r$ 表示数值特征 $r$ 每增加一个标准差所对应的 log-odds 增量。

类别部分中，$f$ 为已选类别特征索引，$v_{jf}$ 为 instance $j$ 的该特征取值；$\ell$ 为类别水平，$\ell_{f,0}$ 为参考水平，$\gamma_{f,\ell}$ 为相对参考水平的 log-odds 差。$I(\cdot)$ 在条件成立时取 1，否则取 0。未启用的特征不进入求和。

$$
\boxed{
p_j=\sigma(\eta_j)=\frac{1}{1+e^{-\eta_j}},\qquad
h_j=\ln(1+e^{\eta_j})
}
$$

其中，$\sigma(\cdot)$ 为 Logistic 函数，$h_j$ 与第 1 节的定义一致。有限 $\eta_j$ 对应 $0<p_j<1$；零概率边界使用附录 I 所述参数化处理。

当前模型具有两项结构约束：

- 每种 TSK 有独立截距；数值和类别系数在 TSK 类型间共享。
- 未显式加入 `TSK × 类别`、类别间乘积或更高阶交互项。

因此，相同 TSK、相同已选特征的实例具有相同预测概率。特征在线性预测值上相加，其概率变化及对 $h_j$ 的变化通常依赖原有风险水平。

TSK 总览采用参考环境概率：

$$
p_t^{\mathrm{ref}}=\sigma(\alpha_t).
$$

其中，$p_t^{\mathrm{ref}}$ 为数值特征均取训练布局均值、类别特征均取参考水平时，类型 $t$ 的单实例概率；不是该类型所有实例概率的平均值。chain 预测使用每个实例的实际特征，不使用总览概率替代。

未启用 XY 或其他特征时，只估计各类型概率；等价的数值实现见附录 E。

## 3. 从 chain 观测反推类型和特征影响

### 3.1 从单次测试到二项分布

每个分析分组需要 chain 组成、逐实例特征，以及各 chain 的 Fail/Pass 计数。Missing 不进入有效测试次数。

$$
Y_{ci}=\begin{cases}
1,&\text{第 }i\text{ 次有效测试为 Fail},\\
0,&\text{第 }i\text{ 次有效测试为 Pass},
\end{cases}
\qquad K_c=\sum_{i=1}^{n_c}Y_{ci}.
$$

其中，$i$ 为有效测试索引，$Y_{ci}$ 为 chain $c$ 单次测试的失效指示变量；$n_c$ 为有效测试次数，即 Fail 与 Pass 的总数；$K_c$ 为随机失效计数，其实际观测值记为 $k_c$。

同一 chain 的有效测试假定相互独立，且具有共同失效概率：

$$
P(Y_{ci}=1\mid\theta)=q_c(\theta),\qquad
P(Y_{ci}=0\mid\theta)=1-q_c(\theta).
$$

其中，$\theta$ 为全部待估参数，由 $\alpha_t$、$\beta_r$ 和 $\gamma_{f,\ell}$ 组成；$q_c(\theta)$ 为该参数下的 chain 失效概率。此处的重复测试指同一分析条件下的独立样本；对同一器件的相关重测或持续退化过程，不自动满足这一假设。

指定恰好 $k_c$ 个测试位置为 Fail、其余位置为 Pass 时，由独立性，该结果序列的概率为：

$$
q_c(\theta)^{k_c}\bigl[1-q_c(\theta)\bigr]^{n_c-k_c}.
$$

上述表达式对应一种结果排列。共有 $\binom{n_c}{k_c}=n_c!/[k_c!(n_c-k_c)!]$ 种不同排列，每种概率相同且事件互斥；其中 $!$ 表示阶乘。因此，不区分失效位置、只记录失效次数时：

$$
\boxed{
P(K_c=k_c\mid\theta)
=\binom{n_c}{k_c}
q_c(\theta)^{k_c}\bigl[1-q_c(\theta)\bigr]^{n_c-k_c}
},\qquad k_c=0,1,\ldots,n_c.
$$

因此，失效计数服从二项分布，记为 $K_c\sim\operatorname{Binomial}(n_c,q_c(\theta))$。该分布描述 $n_c$ 次独立、同概率的二元测试中，失效次数的概率规律。[二项分布定义](https://www.itl.nist.gov/div898/handbook/eda/section3/eda366i.htm)

观测失效率记为：

$$
f_c=\frac{k_c}{n_c},\qquad n_c>0.
$$

其中，$f_c$ 是样本比例，用于估计单次 chain 失效概率；$P(K_c=k_c\mid\theta)$ 则是整组测试恰好出现该失效次数的概率，二者不是同一量。例如，$n_c=10$、$q_c=0.2$、$k_c=2$ 时，$f_c=0.2$，但 $P(K_c=2)=\binom{10}{2}0.2^2\,0.8^8\approx0.302$。在独立同概率假设下，$K_c/n_c$ 随样本量增加几乎必然收敛到真实的 $q_c$；有限样本不要求二者相等。

### 3.2 从联合似然到参数估计

第 2 节的 Logistic 关系与第 1 节的串联合成共同给出正向预测：

$$
q_c(\theta)
=1-\exp\left[-\sum_{j\in\mathcal J_c}
\ln\left(1+e^{\eta_j(\theta)}\right)\right].
$$

其中，$\eta_j(\theta)$ 为第 2 节的线性预测值，显式标记其对待估参数的依赖。所有 chain 的预测由同一组类型截距和特征系数决定。

固定已观测的 $n_c$、$k_c$，将上述计数概率视为 $\theta$ 的函数，得到似然。不同 chain 的计数观测也假定相互独立，因此联合似然为：

$$
L(\theta)
=\prod_c P(K_c=k_c\mid\theta)
=\prod_c\binom{n_c}{k_c}
q_c(\theta)^{k_c}\bigl[1-q_c(\theta)\bigr]^{n_c-k_c}.
$$

其中，$L(\theta)$ 为全部有效 chain 计数的联合似然；它比较不同参数对已观测数据的支持程度，不是参数本身的概率分布。取自然对数，将乘积转为求和、幂次转为系数：

$$
\begin{aligned}
\ln L(\theta)
&=\sum_c\left[
\ln\binom{n_c}{k_c}
+k_c\ln q_c(\theta)
+(n_c-k_c)\ln\bigl(1-q_c(\theta)\bigr)
\right]\\
&=C+\sum_c\left[
k_c\ln q_c(\theta)
+(n_c-k_c)\ln\bigl(1-q_c(\theta)\bigr)
\right].
\end{aligned}
$$

其中，$C=\sum_c\ln\binom{n_c}{k_c}$ 只由观测计数决定，与 $\theta$ 无关。对数严格递增，因此最大化 $L$ 与最大化 $\ln L$ 等价；删除常数 $C$ 也不改变最优参数，得到：

$$
\boxed{
\begin{aligned}
\widehat\theta
&=\underset{\theta}{\operatorname{argmax}}\;L(\theta)\\
&=\underset{\theta}{\operatorname{argmax}}\;
\sum_c\left[
k_c\ln q_c(\theta)
+(n_c-k_c)\ln\bigl(1-q_c(\theta)\bigr)
\right]
\end{aligned}
}
$$

其中，$\widehat\theta$ 为最大似然估计（maximum likelihood estimation，MLE）所得的参数；$\operatorname{argmax}$ 返回使目标最大的参数，而非目标函数值。求解范围为模型允许的参数集合；该写法要求最大值可达到。若仅在参数趋于无穷时达到似然上确界，则不存在有限参数估计，需区分边界极限与有限解，见附录 I。[似然与对数似然的推导](https://online.stat.psu.edu/stat504/Lesson01)

数值实现等价地最小化省略常数后的**负对数似然**：

$$
\boxed{
F(\theta)=-\sum_c\left[
k_c\ln q_c(\theta)
+(n_c-k_c)\ln\bigl(1-q_c(\theta)\bigr)
\right],\qquad
\widehat\theta=\underset{\theta}{\operatorname{argmin}}\;F(\theta).
}
$$

其中，$F(\theta)$ 为当前**拟合损失**。概率边界按连续极限处理：没有对应观测的项记为 0，例如 $k_c=0$ 时的 $k_c\ln q_c$；若模型给已发生事件的概率为 0，则损失为 $+\infty$。

若某条 chain 的概率 $q_c$ 可独立自由估计，在 $0<k_c<n_c$ 时，对其对数似然求导可得：

$$
\begin{aligned}
\frac{d}{dq_c}
\left[k_c\ln q_c+(n_c-k_c)\ln(1-q_c)\right]
&=\frac{k_c}{q_c}-\frac{n_c-k_c}{1-q_c}\\
&=\frac{k_c-n_cq_c}{q_c(1-q_c)}.
\end{aligned}
$$

令导数为 0，得到 $\widehat q_c=k_c/n_c=f_c$。

其中，$\widehat q_c$ 为自由 chain 概率的最大似然估计；该对数似然在内部严格凹，故驻点为最大值。全通过与全失效时，最大值分别位于 $\widehat q_c=0$、$\widehat q_c=1$ 的边界。

当前模型中，各 $q_c(\theta)$ 受共享参数约束，通常不能同时等于各自的 $f_c$，必须联合拟合。即使各 chain 的结构均不重复，这种共享约束仍然存在。各类型与特征系数共同估计，不先把 chain 失效次数分配给某个实例；与最小二乘的区别及选择依据见附录 J。

测试次数通过二项似然影响拟合权重；链内实例数量通过串联公式影响预测。实际特征求解采用三个确定性起点，并检查收敛与数值边界，不保证找到全局最优。

### 3.3 系数影响与概率贡献

系数在 log-odds 尺度上可加。其他条件保持不变时，其含义如下。

| 条件变化 | 系数含义 |
| --- | --- |
| 数值特征增加一个标准差 | odds 乘以 $e^{\beta_r}$ |
| 类别从参考水平变为 $\ell$ | odds 乘以 $e^{\gamma_{f,\ell}}$ |
| 更换 TSK 类型 | 两种类型的截距之差等于 log-odds 差 |

概率尺度上的影响通过条件对比定义：

$$
\Delta p_j
=\sigma(\eta_j+\Delta\eta_j)-\sigma(\eta_j).
$$

其中，$\Delta\eta_j$ 为指定条件变更引起的线性预测值变化，其他条件固定；$\Delta p_j$ 为对应的单实例预测概率差。例如，类别由水平 $\ell_1$ 改为 $\ell_2$，对应系数差 $\gamma_{f,\ell_2}-\gamma_{f,\ell_1}$，参考水平系数按 0 处理。

chain 层的影响应更新相关实例概率后重新合成，不能直接相加各实例的 $\Delta p_j$；不同因素的概率差一般也不能相加成总概率。条件对比是模型内的关联量，不等同于已发生故障的原因份额，也不自动具有因果解释。

### 3.4 可识别性与不确定性

不同 chain 的 TSK 组成、类别搭配和数值特征必须提供足够变化。若某种材料始终只伴随一个 TSK，类型和材料影响可能混淆。增加相同布局的测试次数可提高该组合的估计精度，但不能消除结构混淆。

结果解释需检查三个方面：

- **可识别性**：chain 概率可确定，不代表各类型截距或单实例概率均可独立确定；不可识别的单项不应强行分摊。
- **区间适用性**：当前条件概率主要采用轮廓似然区间，类别概率差采用联合信息矩阵的 Delta 近似，特殊零边界另作处理。区间依赖模型与独立观测假设。
- **拟合可靠性**：在相同数据范围下结合负对数似然、chain 残差、偏差、收敛与参数边界判断；训练拟合改善本身不能证明物理机制成立。

当前未加入 die/wafer 共享随机效应或实例间空间相关性，相关观测可能使独立模型给出的区间偏窄。

## 4. 各 TSK 失效概率的置信区间

### 4.1 区间对应的估计对象

类型汇总中的区间对应第 2 节的参考环境概率；类别组合图中的区间对应所选类别、数值特征取训练布局均值时的条件概率。目标概率在有限 log-odds 下表示为：

$$
p_t^{\star}(\theta)=\sigma\bigl(\eta_t^{\star}(\theta)\bigr).
$$

其中，$p_t^{\star}$ 为类型 $t$ 在指定条件下的单实例失效概率，$\eta_t^{\star}$ 为该条件对应的线性预测值；上标 $\star$ 标识固定的预测条件。在参考环境中，$\eta_t^{\star}=\alpha_t$、$p_t^{\star}=p_t^{\mathrm{ref}}$；未启用其他特征时，目标就是该类型共享的概率。

概率 0、1 属于扩展边界，对应无限 log-odds 的极限；非负 odds 参数化可直接表示零概率，不能将其解释为有限截距。

区间描述由有限 chain 观测引起的参数估计不确定性。布局、特征值及标准化均值和尺度均作为已知输入固定，不在区间计算中重新抽样。一般情况下，各 TSK 没有直接观测的失效次数，区间由全部 chain 的联合似然确定。

### 4.2 轮廓似然与区间端点

沿用第 3.2 节省略常数后的负对数似然，记最优拟合损失为：

$$
\widehat F=F(\widehat\theta).
$$

其中，$\widehat F$ 为拟合点 $\widehat\theta$ 处的损失。理论上使用最大似然解，实际计算以已收敛的最佳候选解为基准。

计算类型 $t$ 的区间时，将其目标概率依次固定为候选值，并重新优化其余参数：

$$
F_t(u)=\min_{\theta:\,p_t^{\star}(\theta)=u}F(\theta).
$$

其中，$u$ 为候选概率，$F_t(u)$ 为该约束下的最小负对数似然。其他 TSK 的截距、数值特征系数及类别系数均可随候选值调整，因此区间包含参数之间的共同估计不确定性。

轮廓似然置信集合及其上下界定义为：

$$
\mathcal C_t=
\left\{u\in[0,1]:2\bigl[F_t(u)-\widehat F\bigr]
\le\chi^2_{1,\,1-\delta}\right\},\qquad
[p_{t,L},p_{t,U}]=[\inf\mathcal C_t,\sup\mathcal C_t].
$$

其中，$1-\delta$ 为置信水平，默认取 0.95；$\chi^2_{1,\,1-\delta}$ 为自由度 1 的卡方分布分位数；$\mathcal C_t$ 为未超过似然比阈值的候选概率集合，$p_{t,L}$、$p_{t,U}$ 为区间下限与上限。自由度为 1，是因为每次限制一个目标概率，其余参数仍参与优化。[似然比卡方近似的依据](https://www.itl.nist.gov/div898/handbook/apr/section2/apr233.htm)

95% 区间使用 $\chi^2_{1,0.95}\approx3.8415$，等价于允许负对数似然较最优值增加约 1.9207。上述公式给出目标置信集合；程序从点估计向两侧搜索并求解阈值交点，通常得到不对称区间。非凸模型下，该过程不保证找全可能分离的置信集合。

常规含特征、未进入非负 odds 分支时，类型汇总固定 $\alpha_t=\operatorname{logit}(u)$，重新拟合其余系数，并将求得的端点通过 Logistic 函数转换为概率。类别组合固定的是指定条件下的完整线性预测值 $\eta_t^{\star}=\operatorname{logit}(u)$，其截距与特征系数可在约束下共同变化。无特征时，程序等价地固定 $h_t=-\ln(1-u)$ 后拟合其他类型风险。

### 4.3 特殊情况下的精确区间

**单类型、等实例数的链。** 未启用其他特征，且全部有效 chain 总共只涉及同一种 TSK、每条链均含相同的 $m$ 个实例时，先合并 chain 计数并计算 Clopper–Pearson 等尾二项区间，再转换到单实例概率：

$$
N=\sum_c n_c,\qquad K=\sum_c k_c.
$$

其中，$N$、$K$ 为合并后的 chain 测试次数与 Fail 次数。共同 chain 失效概率的区间端点为：

$$
q_L=\begin{cases}
0,&K=0,\\
B^{-1}_{K,N-K+1}(\delta/2),&K>0,
\end{cases}
\qquad
q_U=\begin{cases}
1,&K=N,\\
B^{-1}_{K+1,N-K}(1-\delta/2),&K<N,
\end{cases}
$$

其中，$q_L$、$q_U$ 为 chain 概率的下限与上限，$B^{-1}_{a,b}(v)$ 为形状参数 $a,b$ 的 Beta 分布在累计概率 $v$ 处的分位数。该精确方法在二项模型下的覆盖率不低于名义水平，通常偏保守。[Clopper–Pearson 方法说明](https://www.stat.math.ethz.ch/R-manual/R-devel/library/stats/html/binom.test.html)

$$
[p_{t,L},p_{t,U}]
=\left[1-(1-q_L)^{1/m},\;1-(1-q_U)^{1/m}\right].
$$

其中，$m$ 为每条链中该类型的实例数。此分支优先于下述无特征零失效与全失效分支；即使 $K=0$ 或 $K=N$，仍保留等尾区间的 $\delta/2$ 口径。例如，单条链含两个同类实例、100 次测试均通过时，95% 上限约为 1.8275%。

**零失效上界。** 在满足下表条件时，程序利用全部通过事件计算单侧上界：

$$
E_t=\sum_{c\in\mathcal S_t}n_c m_{ct}^{\star},\qquad
[p_{t,L},p_{t,U}]=\left[0,\;1-\delta^{1/E_t}\right].
$$

其中，$\mathcal S_t$ 为按拓扑与特征条件确定的 chain 集合，$m_{ct}^{\star}$ 为 chain $c$ 中与目标概率相对应的实例数量，$E_t$ 为这些实例的测试暴露量。该集合先按输入条件确定，再检查是否全部通过，不能从混合结果中挑选通过的链。

| 适用情形 | 所用 chain 与实例 |
| --- | --- |
| 无其他特征，全部有效 chain 均无 Fail | 所有包含类型 $t$ 的 chain，计入其中该类型的全部实例 |
| 无其他特征，类型估计处于零边界，存在全部通过的纯类型子集 | 所有仅含类型 $t$ 的有效 chain；该子集必须整体无 Fail |
| 启用特征，非负 odds 拟合给出零概率 | 所有含目标条件实例的有效 chain；TSK、全部已选数值与类别特征均须匹配，且这些 chain 必须整体无 Fail |

若所用 chain 仅含目标条件实例，全部通过概率为 $(1-p_t^{\star})^{E_t}$，令其等于 $\delta$ 即得上界。若还包含其他实例，全部通过概率不大于该表达式，所得上界保守。该暴露量公式只适用于上述特例，不能替代一般模型的联合似然。

带特征的零估计若不满足精确分支条件，则在非负参考 odds 参数下计算轮廓似然上界，下限取 0。当前仍使用自由度 1 的卡方阈值，标记为近似边界区间，未采用边界混合分布或另行校准的单侧阈值。

**全失效下界。** 无其他特征、类型估计处于概率 1 边界，且所有仅含该类型的有效 chain 均失效时，使用该纯类型子集求解：

$$
\prod_{c\in\mathcal S_t}
\left[1-(1-p_{t,L})^{m_{ct}}\right]^{n_c}=\delta,
\qquad p_{t,U}=1.
$$

其中，此处 $\mathcal S_t$ 为仅含类型 $t$ 的有效 chain 集合，$m_{ct}$ 为链内该类型实例数。程序数值求解单侧下限；其他混合 chain 不参与此精确界的计数。无纯类型支持时，若目标仍可识别，则按一般轮廓似然处理。

当前无特征分支以估计概率不大于 $10^{-9}$、不小于 $1-10^{-9}$ 分别判定低、高边界；非负 odds 引擎的零概率分支则要求估计值恰为 0。

### 4.4 数值诊断与区间解释

区间计算首先要求拟合收敛且目标概率可识别。某类型未出现在任何有效 chain 中，或其拟合未收敛、概率不可识别时，不发布该类型的概率与区间。类别组合缺少直接布局支持时，另按外推设置处理；若点估计可用而区间求解失败，则保留点估计，将上下限留空，并记录 `interval_unavailable` 与具体原因。

常规类型汇总的轮廓优化沿用系数边界，默认绝对值上限为 35。若任一轮廓参数触及边界、约束拟合未收敛，或发现优于原拟合的解，程序不发布该区间。常规类别组合使用约束后的自由方向优化；若搜索到足够极端的 log-odds 仍未跨越阈值，当前实现将相应端点记为 0 或 1，这是数值边界约定。进入非负 odds 分支后，两类查询使用同一边界求解方法。

95% 为重复抽样覆盖率的名义水平，不表示已得到的区间有 95% 的概率包含固定真值。轮廓似然的卡方近似依赖常规大样本条件，在稀疏数据、边界或弱识别情况下不保证精确覆盖。各 TSK 区间均为逐项区间，未作多重比较校正，也不表示所有 TSK 同时具有 95% 覆盖率。

总体损失函数与各次约束拟合均可能存在数值优化困难；区间可靠性还依赖第 3 节的独立观测与模型假设。单侧、双侧及精确、近似的区分应以实际 `interval_method` 为准：当前无特征的部分单侧分支仍保留默认的 `interval_sidedness` 字段，不能仅凭该字段判断区间口径。

<a id="feature-effects"></a>

## 5. 特征整体检验与同一特征的档位比较

本章对应 **TSK Results → 特征影响**。目标有两个：判断某个已选特征在其他特征之外是否提供额外解释能力；比较同一类别特征各档位对**单个 TSK 实例**失效概率的作用。它不把不同特征强行排成“第一、第二”，也不把系数解释为已发生故障的责任比例。

本章沿用前文的 $\alpha_t$、$\beta_r$、$\gamma_{f,\ell}$、$\eta_j$、$p_j$、$q_c$ 与负对数似然 $F$。显著性水平继续用 $\delta$，与第 4 节置信水平 $1-\delta$ 对应；默认 $\delta=0.05$。**$\alpha_t$ 始终表示 TSK 截距，不改作显著性水平。** 检验的 p 值写作 $p_{\mathrm{test}}$，以区别失效概率 $p_j$。

### 5.1 影响大小为什么使用系数差或优势比

对类别特征 $f$ 的两个档位 $\ell_1$、$\ell_2$，其他实例条件相同时定义：

$$
\Delta_{f;\ell_2:\ell_1}
=\gamma_{f,\ell_2}-\gamma_{f,\ell_1},
\qquad
OR_{f;\ell_2:\ell_1}=e^{\Delta_{f;\ell_2:\ell_1}}.
$$

其中，$\Delta$ 是“档位 $\ell_2$ 减去档位 $\ell_1$”的 log-odds 差，$OR$ 是两个条件的失效优势比（odds ratio）；参考档位的 $\gamma$ 固定为 0。$\Delta>0$ 或 $OR>1$ 表示 $\ell_2$ 的预测失效率更高；$\Delta<0$ 或 $OR<1$ 表示更低。点估计大小由 $\widehat\Delta$ 和 $\widehat{OR}$ 表示。

更换参考档位会移动系数原点，但不会改变这两个档位的差值。由于 Logistic 函数严格递增，有限参数下，档位系数的点估计顺序与固定其他条件后的单实例失效概率顺序一致。

若档位 $\ell_1$ 的单实例概率为 $p_1$，档位 $\ell_2$ 的概率为 $p_2$，则：

$$
\frac{p_2}{1-p_2}=OR\frac{p_1}{1-p_1},
\qquad
p_2=\frac{OR\,p_1}{1-p_1+OR\,p_1}.
$$

同样的 $OR=3$，在 $p_1=1\%$ 时得到 $p_2\approx2.94\%$，在 $p_1=10\%$ 时得到 $p_2=25\%$。因此系数差和 OR 适合体现主效应模型中的相对作用，概率差适合解释某个具体环境。OR 为 3 不是失效率必然变为 3 倍，更不是增加 3 个百分点。

共享系数使该档位差及 OR 在所有 TSK 类型之间相同；这是第 2 节无交互项模型的结构假设。各 TSK 的绝对概率变化仍可以不同。若真实作用随 TSK 或另一特征改变，本章检验不能代替交互项模型的建立与验证。

数值特征 $r$ 用 $\beta_r$ 表示原始值增加一个训练布局标准差 $s_r$ 的效应，$e^{\beta_r}$ 是对应 OR。软件不会把连续数值自动切成类别档位；确需逐档比较的尺寸等输入，应在模板中显式声明为类别特征。

### 5.2 成对差值、标准误、区间与 Wald p 值

把全部参数写成前文的向量 $\theta$。为某一档位比较构造列向量 $\boldsymbol a$：档位 $\ell_2$ 对应位置为 $+1$，档位 $\ell_1$ 对应位置为 $-1$，其余位置为 0；参考档位没有自由参数，因此不添加该位置。于是：

$$
\widehat\Delta=\boldsymbol a^{\mathsf T}\widehat\theta,
\qquad
s_\Delta^2=\boldsymbol a^{\mathsf T}\widehat V\boldsymbol a,
\qquad
SE(\widehat\Delta)=s_\Delta.
$$

其中，$\widehat V$ 是整组参数估计量的协方差矩阵，计算见[附录 L](#parameter-covariance)。这不是参数在迭代过程中的波动，也不是原始特征值的方差。两个档位都不是参考档位时，上式展开为：

$$
s_\Delta^2
=\widehat{\operatorname{Var}}(\widehat\gamma_{f,\ell_2})
+\widehat{\operatorname{Var}}(\widehat\gamma_{f,\ell_1})
-2\widehat{\operatorname{Cov}}(\widehat\gamma_{f,\ell_2},\widehat\gamma_{f,\ell_1}).
$$

原假设为 $\Delta=0$。在可辨识、有限内部解及常规大样本条件下，Wald 检验使用：

$$
\boxed{
z_\Delta=\frac{\widehat\Delta}{s_\Delta},
\qquad p_{\mathrm{test}}=2\left[1-\Phi(|z_\Delta|)\right].
}
$$

其中，$\Phi$ 为标准正态分布的累计分布函数，$z_\Delta$ 是差值相对于其标准误的大小；它不同于第 2 节的标准化特征 $z_{jr}$。双侧检验同时考虑正向和反向偏离，故尾概率乘以 2。

相应的逐项（pointwise）Wald 区间为：

$$
[\Delta_L,\Delta_U]
=\widehat\Delta\pm z_{1-\delta/2}s_\Delta,
\qquad
[OR_L,OR_U]=[e^{\Delta_L},e^{\Delta_U}],
$$

其中，$z_{1-\delta/2}=\Phi^{-1}(1-\delta/2)$，95% 时约为 1.96。OR 区间通常不对称。仅对同一个**未经多重比较校正**的双侧 Wald 检验，差值区间不包含 0、OR 区间不包含 1，与 $p_{\mathrm{test}}<\delta$ 等价。软件的最终显著性使用第 5.4 节的 Holm 校正 p 值，因此不能由普通 95% 误差线直接替代最终结论。

例如 $\widehat\Delta=0.70$、$s_\Delta=0.50$ 时，$z_\Delta=1.40$，$p_{\mathrm{test}}\approx0.1615$，95% 区间约为 $[-0.28,1.68]$。这表示当前数据尚不能明确区分先后，不表示真实差值等于 0。

### 5.3 删除整个特征并重新拟合：似然比检验

待检验的一个完整特征记为 $\mathcal F$。完整模型保留全部已选特征；约简模型删除 $\mathcal F$ 的全部自由参数，并**重新拟合所有保留参数**。两者使用完全相同的有效 chain、$n_c$、$k_c$、类型、保留特征编码与标准化，不重新分类 Fail/Pass，也不按删除特征后的新条件筛掉样本。

对类别特征，原假设是所有档位具有相同效应；在参考编码下，就是所有非参考档位系数均为 0。对数值特征，原假设是相应 $\beta_r=0$。TSK 类型截距始终作为模型基础保留，不列入本页待删除特征。

令 $\widehat F_{\mathrm{full}}$、$\widehat F_{-\mathcal F}$ 分别为完整及约简模型的最小负对数似然，定义：

$$
\boxed{
T_{\mathcal F}=2\left(\widehat F_{-\mathcal F}-\widehat F_{\mathrm{full}}\right)
=-2\ln\frac{\widehat L_{-\mathcal F}}{\widehat L_{\mathrm{full}}}.
}
$$

其中，$\widehat L$ 是对应模型最大化后的似然。省略二项组合常数不影响差值，因为两模型使用同一批观测。$T_{\mathcal F}$ 使用**原始总 NLL**，不能先除以测试次数，也不能用概率平方误差替换。完整模型包含约简模型，所以理论上的 $T_{\mathcal F}\ge0$；若约简拟合明显优于保存的完整拟合，说明至少一个优化结果不可靠，不能截为 0 后继续发布 p 值。只允许在数值容差内消除浮点级负值。

在常规内部、可辨识等正则条件下，原假设成立时：

$$
T_{\mathcal F}\ \overset{\mathrm{approx}}{\sim}\ \chi^2_{d_{\mathcal F}},
\qquad
\boxed{p_{\mathrm{test},\mathcal F}
=P(\chi^2_{d_{\mathcal F}}\ge T_{\mathcal F}).}
$$

$d_{\mathcal F}$ 是两模型之间独立、可辨识限制的数量。全秩、所有水平都有可用信息时，$L_f$ 档类别特征通常为 $L_f-1$，单个数值特征为 1。不能在缺失水平、共线性或 chain 层无法分辨时仅数列数就宣称这些自由度有效；本页对不能可靠独立检验的特征保留原因而不发布常规 p 值。[似然比检验的定义与卡方近似](https://www.itl.nist.gov/div898/handbook/apr/section2/apr233.htm)

教学例：三档材料增加两个可辨识参数，若 $\widehat F_{\mathrm{full}}=120$、$\widehat F_{-\mathcal F}=124$，则 $T_{\mathcal F}=8$，自由度为 2，未经校正的 p 值约为 0.0183。5% 的单项临界值约为 5.991，因此该单项整体检验显著。它只支持“至少存在某种档位差异”，不能直接推出每两个档位都不同；具体哪一对不同，仍看第 5.2 节。

### 5.4 多个检验的 Holm 校正与判定范围

一次同时检验很多特征或档位时，只要每个检验都使用 5% 门槛，“至少一次误报”的概率就可能超过 5%。本页使用 Holm 方法控制预先定义的比较族中至少一次误报的概率，其常规有效性不要求族内各检验相互独立，但要求输入的每项 p 值本身有效。[R 官方多重比较说明](https://stat.ethz.ch/R-manual/R-devel/library/stats/html/p.adjust.html)

设一个比较族共有 $m$ 项，将原始 p 值从小到大排列为 $p_{(1)},\ldots,p_{(m)}$，则：

$$
\boxed{
\widetilde p_{(i)}
=\min\left\{1,\ \max_{1\le j\le i}\bigl[(m-j+1)p_{(j)}\bigr]\right\}.
}
$$

其中，括号下标表示排序位置，$\widetilde p$ 是校正后的 p 值；算完后再映射回原特征或档位比较。最终以 $\widetilde p\le\delta$ 标记显著。顺序检验的等价说法是：从最小 p 值开始，依次与 $\delta/m,\delta/(m-1),\ldots$ 比较，遇到首个未通过者即停止拒绝。

本页的比较族在查看结果前由分析请求确定：

- **特征整体检验族**：同一节点/批次分组中全部请求的特征，包括启用的 X、Y。
- **档位成对比较族**：同一节点/批次、同一个类别特征预设全部 $L_f(L_f-1)/2$ 对比较；不同类别特征分别校正。

不可检验项在内部以 p 值 1 占据预设比较族的位置，界面仍将其 p 值留空并解释原因；不能因为删掉难以检验的项目而缩小校正范围。这不是给不可检验项赋予“没有作用”的科学结论。

例：原始 p 值为 0.01、0.03、0.20，Holm 后为 0.03、0.06、0.20；只有第一项在 5% 水平显著。普通 95% 区间仍为逐项区间，不自动升级为整个比较族同时覆盖 95% 的区间。这里也没有跨所有节点、批次、不同特征的档位族再做全局校正，不能声称整份报告所有结论合在一起的误报率都不超过 5%。

### 5.5 怎样展示档位大小与不确定顺序

档位图以 $\widehat\gamma_{f,\ell}$ 或相对参考档位的 $\widehat{OR}$ 展示点估计大小，并附逐项区间。系数越高，固定其他条件后的预测失效率越高；参考档位的 0 是编码锚点，不是零失效率。参考水平没有自由系数，它的固定零点也不能解释为基础概率估计完全没有不确定性。

成对结果逐行给出比较方向、系数差、标准误、逐项区间、OR、原始及 Holm p 值。**不能通过“两根系数误差线是否重叠”代替成对检验**，也不能因为 C/A 显著而 B/A 不显著，就推断 C/B 显著。

下面是可独立复算的教学例：同一种 TSK，三条各含一个实例的 chain 分别使用材料 A、B、C，每条测试 10000 次，Fail 次数分别为 100、110、300，且链间观测独立。A 为参考，拟合得到 $\widehat\gamma_A=0$、$\widehat\gamma_B\approx0.0963$、$\widehat\gamma_C\approx1.1190$。

| 比较方向 | log-odds 差 | OR | 差值的逐项 95% 区间 | Holm p 值 | 判读 |
| --- | ---: | ---: | --- | ---: | --- |
| B 减 A | 0.0963 | 1.1011 | [−0.1759, 0.3686] | 0.4880 | 未检出明确差异，先后不确定 |
| C 减 A | 1.1190 | 3.0619 | [0.8910, 1.3471] | $2.02\times10^{-21}$ | C 显著更高 |
| C 减 B | 1.0227 | 2.7807 | [0.8024, 1.2430] | $1.80\times10^{-19}$ | C 显著更高 |

可以表述为“点估计 A < B < C；C 高于 A、B 有证据，A/B 的先后不确定”。不能写成已经证明 A=B<C。未检出差异不具有传递性：A/B、B/C 分别不显著，也不能自动把三者归成一个相等组。本页保留每对结论，而不强行给出确定名次或相等组。

### 5.6 删去特征后，预测失效率改变多少

显著性衡量证据强弱，不能代替实际影响大小。本页还在**原完整拟合中有有效观测的拓扑实例**上比较完整与约简模型的预测。记该实例集合为 $\mathcal J_{\mathrm{obs}}$，定义：

$$
b_j=p_{j,-\mathcal F}-p_{j,\mathrm{full}},\qquad j\in\mathcal J_{\mathrm{obs}}.
$$

其中，$b_j$ 是删去特征并重新拟合后，该实例预测概率的有符号变化；正号表示约简模型预测更高。汇总绝对变化的均值、最大值与均方根：

$$
M_{\mathcal F}=\frac1{|\mathcal J_{\mathrm{obs}}|}\sum_j|b_j|,
\quad
B_{\mathcal F}=\max_j|b_j|,
\quad
R_{\mathcal F}=\sqrt{\frac1{|\mathcal J_{\mathrm{obs}}|}\sum_j b_j^2}.
$$

$|\mathcal J_{\mathrm{obs}}|$ 为实例数，每个布局实例等权，不再按 chain 测试次数加权；同类型的重复物理实例仍分别计数。按 TSK 汇总时，改在对应类型的实例子集内计算；也保存有符号变化 $b_j$ 的均值。若汇总范围中有实例概率不可辨识，不挑出可识别实例后冒充全范围平均，而将该范围结果留空，并保留可用实例数及原因。概率差乘以 100 后以**百分点**展示，不是相对百分比。

这些量比较两套已拟合模型在现有布局上的预测，不是独立测试集的预测误差，也不是删除某个真实物理因素后的因果效果。它们可以帮助识别“统计显著但概率变化很小”，不能证明以后新布局或新批次也受同样影响。是否小到工程上可忽略，需要另定业务容许阈值；本页不自动作等效性结论。

### 5.7 报告状态与适用限制

- **整体影响显著**：整体 LRT 的 Holm p 值不大于 $\delta$，支持该特征在其余已选特征之外有额外关联作用。
- **尚未检出显著独立影响**：常规检验可用，但校正 p 值未过门槛。不能改写为“没有作用”或“可以无代价删掉”。
- **无法独立判断／推断不可用**：特征与类型/其他特征混淆、信息不足、拟合不收敛、参数边界或其他数值检查未通过。没有 p 值不等于 p 值大。

Wald 推断要求完整拟合可靠、处于有限内部且目标对比可辨识；整体 LRT 还要求对应约简拟合通过收敛、边界和信息秩检查。单个约简拟合失败时，该特征的整体检验及删除预测变化不可用，但不因此否定完整拟合下仍可辨识的档位对比。若完整拟合存在零风险边界、触限或未可靠收敛，或者从约简结果发现了优于保存值的完整模型候选，则整份常规推断停用。部分不可比较方向不会因使用矩阵伪逆而变得可比较。当前实现没有用参数自助法、边界混合分布或聚类稳健方差对这些情形另行校准。

程序还用线性规划检查完整及约简模型是否存在充分的单调分离证书：让含 Fail 和 Pass 的 chain 中全部实例 logit 不变，让全 Pass 链中的实例 logit 均不增加、全 Fail 链中的实例 logit 均不减少，并至少有一个严格变化。这样的方向会持续改善似然，说明有限最大似然解不存在；检出后停止对应的普通推断，检查本身数值失败时也不发布相应检验。该检查只找充分证书，未检出不构成有限 MLE 存在或全局最优的保证。

链内串联独立性、chain 测试观测独立性、共享主效应和 Fail 事件定义均延续第 1–3 节。若同一 die/wafer 上的 chain 状态存在未建模相关性，模型方差及 p 值可能偏乐观；Holm 校正只处理多重检验，不能修复单项统计模型失配。

## 附录 A. Odds 与 log-odds

$$
\operatorname{odds}(p)=\frac{p}{1-p},\qquad
\operatorname{logit}(p)=\ln\frac{p}{1-p}.
$$

其中，$p$ 为任一单实例失效概率，$0<p<1$；odds 为失效概率与通过概率的比值，logit 为其自然对数，也称 log-odds。odds 不同于两个条件之间的 odds ratio。

当 $p=1\%$、$p=50\%$、$p=90\%$ 时，logit 分别约为 $-4.595$、0、$2.197$。Logistic 模型令 $\eta_j=\operatorname{logit}(p_j)$。log-odds 与 $h_j$ 不同：前者可正可负，后者非负。

## 附录 B. 负对数通过概率的意义

$$
S_j=1-p_j=e^{-h_j},\qquad
-\ln\prod_{j\in\mathcal J_c}S_j=\sum_{j\in\mathcal J_c}h_j.
$$

其中，$S_j$ 为 instance $j$ 的通过概率。负对数使独立串联的乘积转为非负可加量，因此选取 $h_j=-\ln(1-p_j)$。$h_j=1$ 对应 $p_j\approx63.2\%$，仅在低风险时有 $h_j\approx p_j$。该变换本身不要求任何缺陷数量或寿命分布假设。

具体物理解释需要额外模型。若致命缺陷数量服从 Poisson 分布，至少一个缺陷导致失效，则：

$$
P(N_j=0)=e^{-\nu_j},\qquad h_j=\nu_j.
$$

其中，$N_j$ 为 instance $j$ 的致命缺陷数量，$\nu_j$ 为其 Poisson 均值。此时 $h_j$ 才等于平均致命缺陷数量。

若建立连续时间寿命模型，则：

$$
h_j(\tau)=\int_0^\tau\lambda_j(u)\,du.
$$

其中，$\tau$ 为观察时刻，$u$ 为时间积分变量，$\lambda_j(u)$ 为 instance $j$ 的瞬时失效率；$h_j(\tau)$ 为截至 $\tau$ 的累计风险，与瞬时失效率不同。

当前代码未拟合上述缺陷过程或连续时间模型；不能直接把 $h_j$ 当作真实缺陷数或每小时失效率。

## 附录 C. 类型、实例、截距与线性预测值

A、B、C 仅表示不同 `TSK_ID`，不是额外特征或算法参数。A_001、A_002 可为两个不同实例，类型均为 A；类型相同不意味着是同一个物理器件。

$\alpha_t$ 是类型截距：数值特征标准化值为 0、类别取参考水平时，$\eta_j=\alpha_{t(j)}$。这里的数值特征为 0 指训练均值，不一定对应原始坐标原点。有特征时，完整的 $\eta_j$ 应称线性预测值，不能称为截距；无特征时二者才相等。

## 附录 D. 类别水平与特征数量

一个特征有五个互斥水平时，参考编码使用四个系数，每个实例只属于其中一个水平。五个不同的二元特征则可以同时出现，主效应模型使用五个共享特征系数。

后者有 $2^5=32$ 种条件组合。固定一种 TSK 后，若每个组合具有任意独立风险，需要 32 个参数：1 个基础项、5 个主效应、10 个二阶、10 个三阶、5 个四阶和 1 个五阶交互；并非当前 Logistic 模型的参数数量。

当前模型以共享的 log-odds 效应约束组合概率，不为各 TSK 分别拟合类别敏感系数，也不估计全部组合交互。这减少了参数数量，但不能任意表示所有物理协同模式。

## 附录 E. 仅有 TSK ID 时的等价参数化

$$
p_t=\sigma(\alpha_t)=1-e^{-h_t},\qquad
h_t=\ln(1+e^{\alpha_t}),\qquad
\alpha_t=\ln(e^{h_t}-1).
$$

其中，$p_t$、$h_t$ 为未启用其他特征时，类型 $t$ 共享的概率与负对数通过概率；有限互换公式适用于 $0<p_t<1$。每种类型只有一个自由风险参数，$p_t$、$h_t$、$\alpha_t$ 是其不同刻度，不是三个独立参数。

当前无特征分支直接拟合 $h_t\ge0$，以处理零风险边界并简化数值优化。这是类型模型的等价计算方式，不增加另一种特征关系。chain 风险量为：

$$
H_c=\sum_t m_{ct}h_t.
$$

其中，$m_{ct}$ 为 chain $c$ 中类型 $t$ 的实例数量。

此时二项负对数似然对 $h_t$ 为凸函数；直接改用 $\alpha_t$ 优化时不必保持凸性。在无额外参数限制的内部域，上述可逆变换不改变最优似然，也不会新增非全局的内部局部极小。若最优类型概率唯一且正确求解，两种刻度得到同一组概率。

数值停止条件、不可识别性和有限参数范围仍可使两次实际拟合不同。边界处，$p_t=0$ 对应 $h_t=0$、$\alpha_t\to-\infty$，$p_t=1$ 对应 $h_t\to+\infty$、$\alpha_t\to+\infty$。

加入共享特征系数后，$h_j=\ln(1+e^{\eta_j})$ 的非线性是模型结构的一部分，不能将其替换为任意其他特征关系后继续视为单纯换刻度。

## 附录 F. 属性相加与跨实例搭配

对一个属性为 `TSK1、small、stack1` 的实例：

$$
\eta_j
=(\alpha_{\mathrm{TSK1}}+\gamma_{\mathrm{size,small}})
+\gamma_{\mathrm{stack,stack1}}
=\alpha_{\mathrm{TSK1}}
+(\gamma_{\mathrm{size,small}}+\gamma_{\mathrm{stack,stack1}}).
$$

其中，下标 `size,small` 与 `stack,stack1` 分别标识对应类别系数；若取值为参考水平，其系数为 0。加法顺序、括号或字段顺序不改变预测。

将 small 从 TSK1 实例移至 TSK2 实例，会改变两个实例的条件，chain 风险可以随之变化。不同实例失效相互独立，不意味着同一类别对不同 TSK 必须产生相同的概率增量。

## 附录 G. 共享类别效应与基础风险

$$
p'=\frac{Rp}{1-p+Rp},\qquad
h'-h=\ln\bigl[1+(R-1)p\bigr].
$$

其中，$p$、$h$ 为条件变更前的单实例概率与负对数通过概率，$p'$、$h'$ 为变更后的对应值；$\Delta\eta$ 为该条件变更的共享 log-odds 增量，$R=e^{\Delta\eta}$ 为 odds ratio。

当 $R>1$ 时，同样的类别变化作用于更高的基础 $p$，产生更大的 $h$ 增量；这不等同于概率增量在所有风险区间都单调增加。

例：small 相对 large 的 $R=3$，其他条件固定。

| TSK | large 概率 | small 概率 |
| --- | ---: | ---: |
| A | 1% | 2.941% |
| B | 10% | 25% |

相应地，`A-small + B-large` 的 chain 概率约为 12.647%，`A-large + B-small` 则为 25.750%。两条 chain 的类型数量和类别数量相同，但类别与类型的搭配不同。该差异来自 Logistic 概率关系，不需要额外的 `TSK × small` 参数。

## 附录 H. 危险因素集中与模型隐含协同

$$
g(u)=\ln(1+e^u),\qquad
g''(u)=\sigma(u)\bigl[1-\sigma(u)\bigr]>0.
$$

其中，$u$ 为任意有限线性预测值，$g$ 为将线性预测值转换为 $h$ 的函数。$g$ 的凸性使相同的正向 log-odds 增量在较高起点产生较大的 $h$ 增量。

两个基础条件相同的实例，集中与分散两个正向效应满足：

$$
\underbrace{g(\eta+a+b)+g(\eta)}_{H_{\mathrm{集中}}}
\;\ge\;
\underbrace{g(\eta+a)+g(\eta+b)}_{H_{\mathrm{分散}}}.
$$

其中，$\eta$ 为两个实例共同的基础线性预测值，$a,b\ge0$ 为两个危险条件引起的 log-odds 增量；$H_{\mathrm{集中}}$ 为两个条件同落在一个实例时的 chain 风险量，$H_{\mathrm{分散}}$ 为各落在一个实例时的风险量。

由第 1 节可得，集中时 chain 失效概率不低于分散时；两个增量均正且参数有限时严格较高。该结论要求共同基线和正向增量，不能推广成任意搭配均满足的物理定律。

当前模型以少量共享系数产生这种特定的非线性协同；训练拟合良好不能单独证明真实的物理相互作用，也不能替代局部失效分析。

## 附录 I. 优化、边界与结果解释

一般带特征的 chain Logistic 负对数似然不保证凸性，不能套用直接观测单实例标签的普通 Logistic 回归结论。常规求解的截距和特征系数采用有限数值边界，默认绝对值上限为 35。触边不等同于获得稳定有限估计，需结合诊断判断。

参考 odds 定义为 $o_t=e^{\alpha_t}\ge0$。当有限 log-odds 表示接近零风险或触边时，程序可在非负参考 odds 下复核；$o_t=0$ 是扩展模型边界，不是有限的 $\alpha_t$。在有限观测和模型约束下，最大似然解可以为零；不等于真实世界风险已被证明为零，应同时报告上限与边界状态。

chain 拟合、单类型概率识别、因素系数识别和物理根因确认是不同目标。前一个成立不自动保证后一个成立。

实现对应：`src/excel_data_analysis/tsk_analysis.py`（概率、编码、似然与类型估计）、`tsk_logistic_boundary.py`（零 odds 边界）、`tsk_prediction.py`（条件预测与概率差）、`tsk_chain_members.py`（实际实例条件预测）。

## 附录 J. 二项似然与最小二乘的选择

### J.1 两种目标如何衡量误差

沿用正文的观测失效率 $f_c=k_c/n_c$，无权最小二乘可定义为：

$$
S(\theta)=\sum_c\left[f_c-q_c(\theta)\right]^2.
$$

其中，$S$ 为各 chain 的概率偏差平方和，仅对 $n_c>0$ 的 chain 求和。该目标对各 chain 的同等概率偏差给予相同惩罚，不区分估计该失效率所用的测试次数。

当目标是给每种 chain 相同的工程重要性时，等权误差可能符合该目标；这种重要性权重与观测的统计精度是不同概念。加权最小二乘也可反映精度差异，但其权重及区间构造须与所用统计假设一致。[加权最小二乘与观测精度](https://www.itl.nist.gov/div898/handbook/pmd/section1/pmd143.htm)

在正文的二项观测模型下，观测比例的抽样方差为：

$$
\operatorname{Var}\!\left(\frac{K_c}{n_c}\right)
=\frac{q_c(1-q_c)}{n_c}.
$$

其中，$K_c$ 为随机 Fail 次数，$q_c$ 为二项模型中的 chain 失效概率。增加测试次数可减小比例估计的波动；即使各链的 $n_c$ 相同，方差仍随 $q_c(1-q_c)$ 变化。因此，MLE 与无权最小二乘的区别不限于全通过或全失效的数据。

chain 结构各不相同，也不意味着其预测可以独立调整。当前模型共享 TSK 截距与特征系数，同一参数变化通常同时改变多条 chain 的 $q_c(\theta)$。两种目标需要在这些共同约束下作出取舍。若每条链的概率完全自由，二者均得到 $\widehat q_c=f_c$，边界值也一样。

### J.2 二项损失怎样评价同样的概率误差

令每条 chain 都可自由取 $q_c=f_c$，相应的饱和模型损失为：

$$
F_{\mathrm{sat}}
=-\sum_c n_c\left[f_c\ln f_c+(1-f_c)\ln(1-f_c)\right].
$$

其中，$F_{\mathrm{sat}}$ 使用与正文 $F$ 相同的约定，省略组合常数，并取 $0\ln0=0$。饱和模型不一定能由当前共享参数模型实现。相对这一基准，有精确恒等式：

$$
F(\theta)-F_{\mathrm{sat}}
=\sum_c n_c\left[
f_c\ln\frac{f_c}{q_c(\theta)}
+(1-f_c)\ln\frac{1-f_c}{1-q_c(\theta)}
\right].
$$

边界项按极限理解；若预测使已经发生的观测事件不可能，损失为无穷大。此式表明，二项损失同时考虑测试次数及概率所在区间，而不是只看绝对误差。

式中的 $n_c$ 来自多次测试的对数似然累加；概率相关的差异来自通过和失效两种事件的对数概率。这些差异由所采用的计数模型决定，不表示某种 chain 具有更高的工程重要性。

例如，两条链各测 1000 次，将观测率 0.01 预测成 0.02，与将观测率 0.50 预测成 0.51，均产生 $0.01^2$ 的平方误差；各自相对饱和拟合的负对数似然增量却约为 3.119 与 0.200。这是两个非边界例子，说明损失评价不同，并不单凭此证明某次拟合必然更准确。

### J.3 与局部加权最小二乘的关系

当 $0<f_c<1$，且各预测 $q_c(\theta)$ 足够接近 $f_c$ 时，对上式作二阶展开得到：

$$
F(\theta)-F_{\mathrm{sat}}
\approx\sum_c\frac{n_c}{2f_c(1-f_c)}
\left[q_c(\theta)-f_c\right]^2.
$$

这里的权重由该点附近的二项波动确定；这只是局部近似，不能在 $f_c=0$ 或 $1$ 时使用，也不能据此把零观测方差解释为风险已经确定。

各链测试次数相同，且观测率集中在远离 0、1 的狭窄区间时，上述权重近似相同，两种目标在该局部区域较为接近，但不保证最优参数完全一致。仅按测试次数加权，仍未体现概率相关的方差项。

若将分母改成预测值 $q_c(\theta)[1-q_c(\theta)]$，再直接最小化所得 Pearson 平方和，权重本身也随参数变化，求导时会产生额外项，因此一般不等价于 MLE。某些特殊约束下两种方法可以同解，但不能推广为一般结论。

### J.4 当前实现选择 MLE 的理由

本程序观测的是给定测试次数下的 Fail 计数。选用二项 MLE，是让拟合目标与这一观测模型一致，并让样本量和概率相关的波动进入损失计算；第 4 节的轮廓似然区间也沿用同一损失。不能把原始平方和的差直接代入似然比卡方阈值。

最小二乘是可选的估计准则，MLE 不保证每个有限样本中的概率误差都更小。全通过或全失效时，二项模型仍成立，但点估计可能位于边界，仍须报告适当的上限或下限。若二项假设、共同概率或观测独立性不成立，采用 MLE 本身也不能修复模型偏差或保证区间覆盖率。

<a id="chi-square"></a>

## 附录 K. 卡方分布、尾概率与显著性水平

### K.1 “卡方”是什么分布

“卡方分布”的英文是 **chi-square distribution**，符号为 $\chi^2$，其中 $\chi$ 是希腊字母 chi。它不是失效率本身的分布。本项目用它近似描述某些检验统计量在原假设成立时的波动。

若 $Z_1,\ldots,Z_d$ 是相互独立的标准正态随机变量，每个都具有均值 0、方差 1，则平方和：

$$
W_d=\sum_{a=1}^{d}Z_a^2\sim\chi^2_d.
$$

其中，$W_d$ 是非负随机变量，$d$ 称自由度。这里的 $a$ 只是求和索引，与第 5 节的对比向量 $\boldsymbol a$ 无关。自由度表示独立的标准化变化方向数，并不等于样本数，也不必等于类别数。[NIST 卡方分布定义](https://www.itl.nist.gov/div898/handbook/eda/section3/eda3666.htm)

由于每一项被平方，$W_d\ge0$。一个很大的正向或负向正态偏离都会使平方和增大。对上述定义直接求期望及方差，得到：

$$
E(W_d)=d,\qquad\operatorname{Var}(W_d)=2d.
$$

卡方分布通常右偏；自由度不同，其典型大小也不同，所以不能对所有特征使用同一个 LRT 数值门槛。自由度 1 时，$W_1=Z_1^2$，于是：

$$
P(W_1\ge z^2)=P(|Z_1|\ge|z|)=2[1-\Phi(|z|)].
$$

这解释了单参数 Wald 检验中“标准正态双侧 p 值”与“$z^2$ 的一自由度卡方右尾 p 值”为何一致；它不表示有限样本下 Wald 与似然比检验的统计量必然完全相同。

### K.2 密度、累计概率和尾概率各表示什么

对 $x>0$，卡方概率密度为：

$$
\rho_d(x)=\frac{x^{d/2-1}e^{-x/2}}{2^{d/2}\Gamma(d/2)},
\qquad
\Gamma(v)=\int_0^\infty u^{v-1}e^{-u}\,du,\quad v>0.
$$

$\Gamma$ 是 Gamma 函数，大写 $\Gamma$ 不同于类别系数小写 $\gamma_{f,\ell}$。这里用 $\rho_d$ 表示密度，避免与正文观测失效率 $f_c$ 混用。

密度曲线某一点的高度不是“恰好等于该点”的概率；连续分布恰好取某个指定值的概率为 0。**概率对应一段范围下面的面积**。累计分布函数和右尾函数分别为：

$$
G_d(x)=P(W_d\le x)=\int_0^x\rho_d(u)\,du,
\qquad
S_d(x)=P(W_d\ge x)=1-G_d(x).
$$

此处 $G_d$ 是累计分布函数，不复用已代表 NLL 的 $F$；$S_d$ 带自由度下标并以数值 $x$ 为自变量，不同于附录 B 的实例通过概率 $S_j$。

第 5 节中较大的 LRT 统计量表示约简模型与完整模型差得更多。因此观察到 $T_{\mathcal F}=x$ 后，原始 p 值取**右尾面积** $S_d(x)$，而不是密度高度 $\rho_d(x)$、左侧面积 $G_d(x)$ 或两者模型的概率差。

自由度为 2 时有特别简单的表达式：

$$
\rho_2(x)=\frac12e^{-x/2},\qquad
G_2(x)=1-e^{-x/2},\qquad
S_2(x)=e^{-x/2}.
$$

所以 $T_{\mathcal F}=8$、$d=2$ 时，p 值为 $e^{-4}\approx0.0183156$。其他自由度一般交给统计库计算积分及尾概率；极小 p 值宜直接用生存函数（`sf`），避免 `1-cdf` 在浮点数上相减损失精度。[SciPy 卡方分布接口](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.chi2.html)

### K.3 为什么似然比检验会出现卡方分布

在一个可靠的有限内部最大似然解附近，负对数似然可作二次近似：

$$
F(\theta)\approx F(\widehat\theta)
+\frac12(\theta-\widehat\theta)^{\mathsf T}
\mathcal H(\widehat\theta)(\theta-\widehat\theta),
$$

其中，$\mathcal H=\nabla^2F$ 为观测损失的 Hessian，区别于 chain 风险量 $H_c$。常规大样本理论同时使可辨识参数估计误差在适当标准化后近似正态。

给完整模型加上 $d$ 个独立限制，并让其他参数重新拟合，相当于只保留数据无法通过其余参数补偿的 $d$ 个偏离方向。局部二次损失差乘以 2 后，近似成为这 $d$ 个标准正态方向的平方和。因此，原假设成立时，$2(\widehat F_{-\mathcal F}-\widehat F_{\mathrm{full}})$ 近似服从 $\chi^2_d$。[Wilks 似然比渐近分布原始论文](https://doi.org/10.1214/aoms/1177732360)

这段解释依赖模型正确、有限内部解、可辨识、光滑似然和足够信息等正则条件。它不是“任何两个损失的差都服从卡方分布”的代数恒等式。零概率边界、稀疏失效、非收敛、参数混淆或相关观测均可能破坏该近似。删除一个 $L_f$ 档特征通常增加 $L_f-1$ 个相等性限制，而不是增加 $L_f$ 个；若这些限制并不独立可辨识，不能直接使用这个计数。

### K.4 5% 门槛、p 值和置信区间

显著性水平 $\delta$ 是事先设定的误报率目标。在原假设确实成立、检验分布适用的重复实验中，规则错误地拒绝原假设的长期比例受它控制。设定 5% 不表示“本次结论有 5% 概率错误”，也不表示效应只有 5%。

临界值 $x_{d,1-\delta}$ 定义为：

$$
G_d(x_{d,1-\delta})=1-\delta,
\qquad
P(W_d>x_{d,1-\delta})=\delta.
$$

它就是正文写作 $\chi^2_{d,1-\delta}$ 的分位数。在单项、未经校正的 LRT 中，$T_{\mathcal F}>x_{d,1-\delta}$ 与 $p_{\mathrm{test}}<\delta$ 等价。

| 自由度 $d$ | 5% 右尾临界值 | 1% 右尾临界值 |
| --- | ---: | ---: |
| 1 | 3.8415 | 6.6349 |
| 2 | 5.9915 | 9.2103 |
| 3 | 7.8147 | 11.3449 |
| 4 | 9.4877 | 13.2767 |
| 5 | 11.0705 | 15.0863 |

这些门槛是对应卡方分布的分位数，不是系数差或失效率差的固定大小。[NIST 卡方分位数表](https://www.itl.nist.gov/div898/handbook/eda/section3/eda3674.htm)

p 值的完整含义是：**假设原假设成立，按该检验统计量衡量，得到当前这么极端或更极端数据证据的概率。** 它不是原假设成立的概率，不是效应大小，也不是未来预测出错的概率。观察到 $p_{\mathrm{test}}=0.02$ 不能改写为“这个特征有 98% 概率有作用”。[美国统计协会 p 值声明](https://www.amstat.org/asa/files/pdfs/p-valuestatement.pdf)

第 4 节轮廓似然区间使用同一思想：每个候选目标概率对应一个限制，保留其 LRT 统计量未超过一自由度阈值的全部候选。95% 时允许 NLL 增加约 $3.8415/2=1.9207$。95% 置信水平描述重复抽样的名义覆盖率，不能赋予已实现区间包含固定真值的后验概率。

若同时检验多个特征或档位，需要第 5.4 节的多重比较处理。卡方表中的单项 5% 门槛不直接等于 Holm 后每一项适用的门槛。

### K.5 与本页公式对应的计算代码

```python
from scipy.stats import chi2, norm

# 系数差的双侧 Wald 检验。
log_odds_difference = 0.70
standard_error = 0.50
wald_z = log_odds_difference / standard_error
pair_p_value = 2 * norm.sf(abs(wald_z))  # 约 0.161513

# 三档类别整体检验：保留两个自由系数，或把它们同时约束为 0。
full_nll = 120.0
reduced_nll = 124.0
likelihood_ratio_statistic = 2 * (reduced_nll - full_nll)
feature_p_value = chi2.sf(likelihood_ratio_statistic, df=2)  # 约 0.018316
critical_value = chi2.ppf(0.95, df=2)                     # 约 5.991465
```

此代码只演示分布计算；正式结果还要检查拟合、边界、可辨识性并进行预设比较族的 Holm 校正。

<a id="parameter-covariance"></a>

## 附录 L. 参数估计量的方差、协方差与 Fisher 信息

### L.1 估计的究竟是哪一种方差

真实模型参数视为固定而未知；由于观测计数 $K_c$ 随重复采样而变化，由它们拟合出的 $\widehat\theta$ 也是随机量。参数估计量的方差描述：固定布局、样本量和模型，重新生成观测并拟合时，估计系数会如何波动。

设 $\theta_a$、$\theta_b$ 为参数向量的两个分量，则：

$$
\begin{aligned}
\operatorname{Var}(\widehat\theta_a)
&=E\!\left[(\widehat\theta_a-E\widehat\theta_a)^2\right],\\
\operatorname{Cov}(\widehat\theta_a,\widehat\theta_b)
&=E\!\left[(\widehat\theta_a-E\widehat\theta_a)
(\widehat\theta_b-E\widehat\theta_b)\right].
\end{aligned}
$$

协方差为正表示两个估计倾向一起偏高或偏低；负值表示一个偏高时另一个倾向偏低。标准误是估计方差的平方根。它们不同于原始特征值的标准差，也不同于优化迭代轨迹的变化量。只有一批数据时，可以利用模型中的观测波动及似然局部形状，近似估计这种重复抽样不确定性。

### L.2 从二项计数推导联合 Fisher 信息

先在有限、内部参数及 $0<q_c<1$ 的情况下推导。第 3 节的单链对数似然为：

$$
\ln L_c(\theta)
=\ln\binom{n_c}{K_c}+K_c\ln q_c+(n_c-K_c)\ln(1-q_c).
$$

对全部参数求导得到得分向量（score）：

$$
\boldsymbol U_c(\theta)
=\nabla_\theta\ln L_c(\theta)
=\frac{K_c-n_cq_c}{q_c(1-q_c)}\nabla_\theta q_c.
$$

得分不是模型评分，它表示对数似然在各参数方向的斜率。二项模型给出 $E(K_c)=n_cq_c$ 和 $\operatorname{Var}(K_c)=n_cq_c(1-q_c)$，所以 $E(\boldsymbol U_c)=\boldsymbol0$，其协方差为：

$$
E(\boldsymbol U_c\boldsymbol U_c^{\mathsf T})
=\frac{n_c}{q_c(1-q_c)}
(\nabla_\theta q_c)(\nabla_\theta q_c)^{\mathsf T}.
$$

在不同 chain 计数独立的假设下，对总得分 $\boldsymbol U=\sum_c\boldsymbol U_c$ 的协方差求和，得到整批数据的期望 Fisher 信息矩阵：

$$
\boxed{
\mathcal I(\theta)
=\sum_c\frac{n_c}{q_c(1-q_c)}
(\nabla_\theta q_c)(\nabla_\theta q_c)^{\mathsf T}.
}
$$

$\mathcal I$ 使用花体，区别于类别指示函数 $I(\cdot)$。矩阵包含所有类型截距与特征系数之间的信息，不能逐个系数孤立计算。已使用全体 $n_c$，因此后面求逆时不能再额外除以总样本数。

为对应实现，令 $\boldsymbol d_j$ 为实例设计列向量，满足 $\eta_j=\boldsymbol d_j^{\mathsf T}\theta$，并沿用 $h_j=\ln(1+e^{\eta_j})$、$H_c=\sum_jh_j$。链式求导给出：

$$
\frac{\partial h_j}{\partial\eta_j}=p_j,
\qquad
\boldsymbol g_c=\nabla_\theta H_c
=\sum_{j\in\mathcal J_c}p_j\boldsymbol d_j,
\qquad
\nabla_\theta q_c=(1-q_c)\boldsymbol g_c.
$$

代回通式：

$$
\boxed{
\mathcal I(\theta)
=\sum_c\frac{n_c(1-q_c)}{q_c}\boldsymbol g_c\boldsymbol g_c^{\mathsf T}.
}
$$

这就是当前有限 Logistic 分支的实现形式。Chain 失效由多个实例合成，但没有人为分配“哪一个实例失败”的计数；全部信息通过 $q_c$ 对共同参数的导数进入矩阵。

### L.3 为什么信息矩阵求逆能够估计方差

设真实参数为 $\theta_0$。在常规内部 MLE 附近，总得分满足 $\boldsymbol U(\widehat\theta)=0$。对得分作一阶展开并用期望曲率近似观测曲率：

$$
\boldsymbol0
\approx\boldsymbol U(\theta_0)
-\mathcal I(\theta_0)(\widehat\theta-\theta_0),
\qquad
\widehat\theta-\theta_0
\approx\mathcal I(\theta_0)^{-1}\boldsymbol U(\theta_0).
$$

因为 $\operatorname{Cov}(\boldsymbol U)=\mathcal I$，误差线性变换的协方差为：

$$
\operatorname{Cov}(\widehat\theta)
\approx\mathcal I^{-1}\mathcal I\mathcal I^{-1}
=\mathcal I^{-1}.
$$

真实参数未知，计算时用拟合值代入：

$$
\boxed{\widehat V=\mathcal I(\widehat\theta)^{-1}.}
$$

这是一种模型下的大样本近似，不是每个有限样本都精确成立的等式。[最大似然的渐近方差说明](https://www.stat.cmu.edu/~cshalizi/dst/18/lectures/14/lecture-14.html)

观测 Hessian 为 $\mathcal H(\theta)=\nabla^2F(\theta)$。正则条件下，$E[\mathcal H(\theta)]=\mathcal I(\theta)$；两者在有限数据中通常不同。当前联合协方差采用期望 Fisher 信息，不是直接把优化器返回的近似逆 Hessian 当作统计结果。

### L.4 为什么必须对整个矩阵求逆

考虑一个仅为解释矩阵运算的二参数信息矩阵：

$$
\mathcal I=
\begin{pmatrix}100&80\\80&100\end{pmatrix},
\qquad
\mathcal I^{-1}
=\frac1{3600}
\begin{pmatrix}100&-80\\-80&100\end{pmatrix}.
$$

因此两个参数的方差均约为 0.02778、协方差约为 −0.02222。若错误地只把信息对角线取倒数，会得到 0.01，忽略另一个参数能补偿当前参数的变化，从而低估不确定性。

这两个参数差值的方差为：

$$
0.02778+0.02778-2(-0.02222)=0.10,
$$

而两个参数和的方差约为 0.01111。数据可以很好地约束两者的和，却较难区分谁贡献更多，这正是 Chain 反推中常见的现象。

第 5.5 节三条独立单实例链的例子还说明另一种协方差来源。记三个档位各自的 logit 估计为 $\widehat u_A,\widehat u_B,\widehat u_C$，则参考编码下：

$$
\widehat\gamma_B=\widehat u_B-\widehat u_A,
\quad
\widehat\gamma_C=\widehat u_C-\widehat u_A,
\quad
\operatorname{Cov}(\widehat\gamma_B,\widehat\gamma_C)
=\operatorname{Var}(\widehat u_A).
$$

尽管三条链独立，两个类别系数因为共享参考档位仍正相关。计算 C−B 时，参考档位的不确定性应抵消；保留协方差项恰好完成该抵消。

### L.5 单参数特例与样本量的作用

若只有一种单实例概率，观察 $n$ 次独立测试，Logistic 参数为 $\theta=\ln[p/(1-p)]$。因 $dp/d\theta=p(1-p)$，信息及方差近似为：

$$
\mathcal I(\theta)=np(1-p),
\qquad
\widehat{\operatorname{Var}}(\widehat\theta)
\approx\frac1{n\widehat p(1-\widehat p)}.
$$

$n=1000$、观察到 100 次失效时，$\widehat p=0.1$，logit 方差约为 0.01111，标准误约为 0.10541。在相同概率、设计和独立性条件下把样本量扩大为 4 倍，信息扩大为 4 倍，方差缩小到四分之一，标准误约减半。

该特例没有其他待估参数。多参数情况下必须使用完整矩阵；失效为 0 或全失效时，有限 logit MLE 不存在，不能把边界样本比例直接代入上式构造普通标准误。

### L.6 SVD、不可辨识方向与数值实现

令加权 Jacobian 矩阵的第 $c$ 行为：

$$
A_{c,:}=\sqrt{\frac{n_c(1-q_c)}{q_c}}\boldsymbol g_c^{\mathsf T},
\qquad \mathcal I=A^{\mathsf T}A.
$$

对 $A$ 作奇异值分解 $A=U\Sigma R^{\mathsf T}$，保留大于数值阈值的奇异值及对应右奇异向量 $s_a,\boldsymbol r_a$，则已有信息子空间上的协方差为：

$$
\widehat V=\sum_{a:\,s_a>\mathrm{tol}}\frac1{s_a^2}\boldsymbol r_a\boldsymbol r_a^{\mathsf T}.
$$

满秩时，这等于通常的矩阵逆；秩不足时，这对应信息矩阵的广义逆。广义逆只给数据已经约束住的方向求逆，**不表示被丢弃方向的真实方差为 0**。

对第 5 节的目标 $\Delta=\boldsymbol a^{\mathsf T}\theta$，必须先确认 $\boldsymbol a$ 位于有效信息行空间，并满足设计及 chain 层的可辨识性检查，才可以使用 $\boldsymbol a^{\mathsf T}\widehat V\boldsymbol a$。一个特征始终与某种 TSK 绑定时，再多重复测试也不一定解除这种结构混淆。

当前协方差计算见 [`tsk_prediction.py` 的 `_FrozenFit`](../src/excel_data_analysis/tsk_prediction.py)，新特征检验沿用同一 chain 似然和信息口径。数值秩阈值用于浮点计算稳定性，它不是显著性水平，也不证明保留下来的每个方向都估计得精确。

### L.7 近似不可靠时如何报告

边界、极少失效、弱识别、错误的共同概率假设或相关观测均可能使普通 Fisher 方差失真。若同一 die 的多条 chain 有相关性，总得分的真实协方差还包含跨链项；当前独立二项信息公式没有计入这些项。简单增加测试计数或对 p 值做 Holm 校正不能修复该问题。

参数自助法、按独立样品聚类的稳健协方差或适当随机效应模型可以用于进一步研究，但需要与数据生成过程及真实独立采样单位匹配；当前页未自动实现这些替代方法。遇到边界或无法可靠辨识时，保留“推断不可用”的原因比发布一个没有适用依据的标准误或 p 值更准确。
