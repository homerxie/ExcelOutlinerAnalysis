"""Export a self-contained browser report from already calculated TSK results."""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile

from .tsk_analysis import _plain
from .tsk_feature_summary import summarize_tsk_features
from .tsk_features import category_label
from .tsk_result_state import compact_tsk_result
from .tsk_sorting import natural_sort_key


def _combination_chain_index(payload, group):
    """Link saved layout membership to whole-chain results, without prediction."""
    context = group.get("prediction_context") or {}
    definitions = context.get("categorical_features") or group.get("diagnostics", {}).get("categorical_features", {})
    names = sorted(group.get("options", {}).get("categorical_feature_names") or definitions)
    sources = payload.get("topology") or context.get("topology")
    if not sources:
        legacy = group.get("chain_members", {})
        chains = {str(chain["chain_id"]): chain for chain in group.get("chains", [])}
        sources = [{**member, "chain_id": chain_id}
                   for chain_id in set(chains) | set(legacy)
                   for member in chains.get(chain_id, {}).get("members", legacy.get(chain_id, []))]
    memberships, incomplete = {}, set()
    for source in sources:
        tsk_id = str(source.get("tsk_id"))
        values = {**(source.get("features") or {}), **(source.get("categories") or {})}
        try:
            categories = [category_label(values.get(name), name) for name in names]
        except ValueError:
            incomplete.add(tsk_id)
            continue
        if source.get("chain_id") is None:
            incomplete.add(tsk_id)
            continue
        key = json.dumps([tsk_id, categories], ensure_ascii=False, separators=(",", ":"))
        memberships.setdefault(key, set()).add(str(source["chain_id"]))
    return {"dimensions": names, "available": bool(sources), "incomplete_types": sorted(incomplete),
            "chains_by_key": {key: sorted(ids, key=natural_sort_key) for key, ids in memberships.items()}}


def build_tsk_html_report(payload: dict, *, view_state: dict | None = None) -> dict:
    """Keep all display records; GUI filters affect only the initial view."""
    if not isinstance(payload, dict) or not payload.get("groups"):
        raise ValueError("暂无可导出的 TSK 结果，请先运行分析或打开已保存的结果。")
    report = compact_tsk_result(payload)
    for original, group in zip(payload["groups"], report["groups"]):
        group["feature_summary"] = summarize_tsk_features(group)
        group["combination_chain_index"] = _combination_chain_index(payload, original)
    report.update(
        version=1,
        exported_at=datetime.now(timezone.utc).isoformat(),
        view_state=deepcopy(view_state or {}),
    )
    return _plain(report)


def export_tsk_html(payload: dict, output_path: str, *, view_state: dict | None = None) -> str:
    """Atomically write one UTF-8 file, with no fitting or remote dependencies."""
    from .tsk_html_render import render_tsk_html

    html = render_tsk_html(build_tsk_html_report(payload, view_state=view_state))
    target = Path(output_path).expanduser()
    if target.suffix.lower() != ".html":
        target = target.with_suffix(".html")
    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_path = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(html)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, target)
    finally:
        try:
            os.unlink(temporary_path)
        except FileNotFoundError:
            pass
    return str(target)
