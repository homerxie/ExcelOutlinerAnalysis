"""Read-only coefficient and conditional-feature views of an existing TSK fit.

No probability, confidence limit or optimization is calculated here.  Feature
risks are selected from saved combination rows with all other categories at
their fitted references; coefficients retain the model's original units.
"""

from __future__ import annotations

from copy import deepcopy
import math
from numbers import Real
from typing import Any, Mapping

from .tsk_features import ALL_CATEGORY_COMBINATIONS, category_label


def _finite(value):
    return float(value) if isinstance(value, Real) and not isinstance(value, bool) and math.isfinite(value) else None


def _categories(values: Mapping[str, Any]) -> dict[str, str]:
    return {name: category_label(value, name) for name, value in values.items()}


def summarize_tsk_features(group: Mapping[str, Any], view: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Expose identifiable fitted terms and already-computed reference slices."""
    diagnostics = group.get("diagnostics", {})
    context = group.get("prediction_context") or {}
    model = diagnostics.get("model", context.get("model", "type_only"))
    context_model = context.get("model")
    selected_model = group.get("options", {}).get("feature_model")
    if (model not in {"type_only", "instance_logistic_features"}
            or (context_model is not None and context_model != model)
            or (model != "type_only" and selected_model not in (None, "logistic"))):
        reason = "该模型已停用，请使用 Logistic 重新运行；旧系数不能按 Logistic 解释。"
        return {"model": model, "formula": "", "coefficients": [], "risks": [],
                "numeric_scaling": {}, "category_references": {}, "risk_reason": reason,
                "notes": [reason]}
    logistic = model == "instance_logistic_features"
    coefficient_scale = "logit（对数优势）" if logistic else "hazard（负对数存活率）"
    formulas = {
        "instance_logistic_features": "η = α_TSK + Σ β_j·(x_j−mean_j)/scale_j + Σ γ_(feature,level)·I(category=level)；p = 1/(1+exp(−η))",
        "type_only": "p_TSK = 1−exp(−h_TSK)，h_TSK ≥ 0；仅 TSK ID 时的等价数值参数化",
    }
    categorical = diagnostics.get("categorical_features") or context.get("categorical_features", {})
    categorical = {name: definition for name, definition in categorical.items()
                   if isinstance(definition, Mapping) and definition.get("levels")
                   and definition.get("reference") is not None}
    references = _categories({name: definition["reference"] for name, definition in categorical.items()})
    scaling = deepcopy(diagnostics.get("feature_scaling", {}))
    numeric_reference = dict(context.get("numeric_reference") or {
        name: values.get("mean") for name, values in scaling.items()})
    boundary_fit = context.get("boundary_fit") or diagnostics.get("boundary_fit") or {}
    validated_boundary = (logistic and boundary_fit.get("version") == 1
                          and boundary_fit.get("converged") is True and boundary_fit.get("feature_clipped") is False)
    stable = bool(diagnostics.get("converged", context.get("converged")))
    stable = (stable and context.get("converged", True)
              and (not context.get("clipped", False) or validated_boundary)
              and (diagnostics.get("finite_mle", True) is not False or validated_boundary))
    types = {row["tsk_id"]: row for row in group.get("types", [])}
    context_coefficients = dict(zip(context.get("type_ids", []), context.get("coefficients", [])))
    terms = []

    def term(*, kind, name, value, identifiable, reference=False, tsk_id=None, feature=None,
             level=None, mean=None, scale=None, note="", coefficient_status=None):
        if reference:
            coefficient, status = 0., "reference_coding"
        elif coefficient_status == "boundary_unbounded":
            coefficient, identifiable, status = None, False, "boundary_unbounded"
        elif not stable:
            coefficient, identifiable, status = None, False, "fit_not_converged"
        elif identifiable is not True:
            coefficient, status = None, "not_identifiable" if identifiable is False else "unavailable"
        else:
            coefficient = _finite(value)
            status = "ok" if coefficient is not None else "unavailable"
        terms.append({"kind": kind, "term": name, "tsk_id": tsk_id, "feature": feature, "level": level,
                      "coefficient": coefficient, "identifiable": identifiable, "reference": reference,
                      "status": status, "mean": mean, "scale": scale,
                      "coefficient_scale": coefficient_scale, "note": note})

    for tsk_id, row in (types.items() if model != "type_only" else []):
        value = context_coefficients.get(tsk_id)
        identified = row.get("identifiable")
        if value is None and stable and row.get("identifiable"):
            probability = _finite(row.get("probability"))
            if probability is not None:
                if logistic and 0 < probability < 1:
                    value = math.log(probability) - math.log1p(-probability)
        term(kind="type_intercept", name=f"α[{tsk_id}]", value=value,
             identifiable=identified, tsk_id=tsk_id,
             coefficient_status=row.get("coefficient_status"),
             note=("系数趋向无穷边界，不存在有限估计；数值优化上限不是可发布的系数。"
                   if row.get("coefficient_status") == "boundary_unbounded" else
                   "该 TSK 在数值特征均值、类别参考水平下的截距；系数不是风险概率。"))

    feature_values = diagnostics.get("feature_coefficients", {})
    feature_identifiable = diagnostics.get("feature_coefficient_identifiable", {})
    numeric_names = list(dict.fromkeys([*scaling, *(name for name in feature_values if name not in categorical)]))
    for name in numeric_names:
        values = scaling.get(name, {})
        term(kind="numeric", name=f"β[{name}]", value=feature_values.get(name),
             identifiable=feature_identifiable.get(name), feature=name,
             mean=values.get("mean"), scale=values.get("scale"),
             note="作用于 (数值−mean)/scale；数值增加一个 scale 时的模型线性项变化，不是概率变化。")
    for name, definition in categorical.items():
        values = {category_label(level, name): value for level, value in feature_values.get(name, {}).items()}
        identified = {category_label(level, name): value for level, value in feature_identifiable.get(name, {}).items()}
        for raw_level in definition["levels"]:
            level = category_label(raw_level, name)
            reference = level == references[name]
            term(kind="categorical", name=f"γ[{name}={level}]", value=values.get(level),
                 identifiable=None if reference else identified.get(level), reference=reference,
                 feature=name, level=level,
                 note="参考类别固定编码为 0，不是独立估计的参数。" if reference else
                      f"相对 {name}={references[name]} 的模型线性项差异；系数不是风险概率。")

    saved_views = [view] if view is not None else list(reversed(group.get("combination_views", [])))
    full_views = [item for item in saved_views if item.get("dimension") == ALL_CATEGORY_COMBINATIONS]
    candidates = full_views[:1] if full_views else saved_views
    selected = {}
    for candidate in candidates:
        dimension = candidate.get("dimension")
        full = dimension == ALL_CATEGORY_COMBINATIONS
        dimensions = list(categorical) if full else [dimension] if dimension in categorical else []
        for feature in dimensions:
            conditions = {name: level for name, level in references.items() if name != feature}
            if not full and _categories(candidate.get("fixed_categories", {})) != conditions:
                continue
            for row in candidate.get("rows", []):
                categories = _categories(row.get("categories", {}))
                if set(categories) != set(references) or any(categories[name] != level for name, level in conditions.items()):
                    continue
                level = categories[feature]
                if level not in {category_label(value, feature) for value in categorical[feature]["levels"]}:
                    continue
                key = (feature, row["tsk_id"], level)
                if key in selected:
                    continue
                record = {field: deepcopy(row.get(field)) for field in (
                    "tsk_id", "probability", "ci_lower", "ci_upper", "status", "interval_error", "support_status",
                    "estimate_kind", "interval_sidedness", "interval_method", "identifiable")}
                record.update(feature=feature, level=level, categories=categories, conditions=conditions,
                              numeric_reference=deepcopy(candidate.get("numeric_reference", numeric_reference)),
                              confidence_level=row.get("confidence_level", candidate.get("confidence_level", diagnostics.get("confidence_level"))),
                              extrapolate=bool(candidate.get("extrapolate", True)))
                if record["status"] == "no_data" or record.get("identifiable") is False:
                    record.update(probability=None, ci_lower=None, ci_upper=None)
                selected[key] = record
    risks = list(selected.values())
    reason = None if risks else ("本次模型没有类别特征。" if not categorical else
                                "尚无其他类别固定在参考水平的组合结果；请先计算全部类别组合。")
    return {
        "model": model, "formula": formulas.get(model, ""), "coefficients": terms, "risks": risks,
        "numeric_scaling": scaling, "category_references": references, "risk_reason": reason,
        "notes": ["系数的单位是模型线性项，不是概率；类别参考水平的 0 是编码约定，不是独立估计。",
                  "数值特征按 (数值−mean)/scale 标准化；模型仅含共享主效应，没有 TSK 与特征或特征之间的交互项。"],
    }
