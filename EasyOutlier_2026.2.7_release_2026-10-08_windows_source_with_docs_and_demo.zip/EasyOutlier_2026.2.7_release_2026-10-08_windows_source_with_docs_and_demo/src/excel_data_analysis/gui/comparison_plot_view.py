"""Virtual plot surface with bounded, demand-driven image/hover caches.

The view owns geometry and interactions, not analysis. A bounded process pool
generates visible images first; obsolete work is drained without displaying it.
The GUI retains numeric hover indexes and retrieves original points on demand.
"""
from __future__ import annotations

from bisect import bisect_right
from collections import OrderedDict
from collections.abc import Mapping
from dataclasses import dataclass, replace
from math import ceil, isfinite, ulp
import sys
from time import perf_counter

import numpy as np
from PySide6.QtCore import QEvent, QPointF, QRectF, QTimer, Qt, Signal
from PySide6.QtGui import QColor, QCursor, QImage, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QAbstractScrollArea, QApplication, QToolTip, QWidget

from ..comparison_models import MetricDescriptor, PlotPoint, PlotSeries
from .plot_hover_index import CompactPayload
from .plot_process_backend import PlotProcessBackend
from .plot_process_worker import unpack_compact_result


@dataclass(frozen=True, slots=True)
class PlotViewGroup:
    group_index: int
    descriptor: MetricDescriptor
    title: str
    series: tuple[PlotSeries, ...]
    lane_indices: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class _TileKey:
    source: int
    group_index: int
    lanes: tuple[int, ...]
    width: int
    dpr: float
    plot_type: str
    lane_height: int
    axis: tuple[float, float] | None
    pinned: tuple[str, str, int, str] | None
    headers: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class _TileSpec:
    key: _TileKey
    group: PlotViewGroup
    top: int
    first_lane: int


@dataclass(slots=True)
class _CachedTile:
    payload: CompactPayload
    pixmap: QPixmap
    cost: int
    sample_records: np.ndarray | None = None
    sample_pixmap: QPixmap | None = None
    sample_pixmap_offset: float = 0.0


@dataclass(slots=True)
class _ActiveTile:
    serial: int
    spec: _TileSpec
    estimated_cost: int
    cancelled: bool = False


@dataclass(slots=True)
class _PanDrag:
    group_index: int
    origin: QPointF
    bounds: tuple[float, float]
    width: float
    started: bool = False


class ComparisonPlotViewport(QAbstractScrollArea):
    renderingProgress = Signal(int, int, str)
    renderingReady = Signal()
    renderFailed = Signal(str)
    workersFinished = Signal()

    HEADER_HEIGHT = 66
    MARGIN = 8
    GAP = 12
    TILE_LANES = 8
    RESIZE_DELAY_MS = 150
    ZOOM_DELAY_MS = 30
    PLOT_RIGHT_MARGIN = 48  # Matches ComparisonRenderer's data rectangle.
    SAMPLE_VECTOR_LIMIT = 16
    SAMPLE_OVERLAY_LIMIT_BYTES = 16 * 1024 * 1024
    SAMPLE_OVERLAY_PADDING = 12

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cache_limit_bytes = 192 * 1024 * 1024
        self._cache: OrderedDict[_TileKey, _CachedTile] = OrderedDict()
        self._headers: OrderedDict[tuple, tuple[QPixmap, int]] = OrderedDict()
        self._prepared = OrderedDict()
        self._cache_bytes = 0
        self._groups: list[PlotViewGroup] = []
        self._group_by_index: dict[int, PlotViewGroup] = {}
        self._group_tops: dict[int, int] = {}
        self._tops: list[int] = []
        self._total_height = 0
        self._sources: dict[int, tuple[tuple[PlotSeries, ...], int]] = {}
        self._next_source = 0
        self._data_generation = None
        self._lane_headers: tuple[str, ...] = ()
        self._plot_type = "Ridge Plot"
        self._lane_height = 30
        self._ranges: dict[int, tuple[float, float]] = {}
        self._zoom_pending: dict[int, tuple[float, float]] = {}
        self._native_zoom_position: QPointF | None = None
        self._pan_drag: _PanDrag | None = None
        self._pointer_position: QPointF | None = None
        self._pointer_inside = False
        self._pointer_modifiers = Qt.NoModifier
        self._cursor_mode = None
        self._zoom_cursor: QCursor | None = None
        self._zoom_cursor_key = None
        self._pinned: dict[int, tuple[str, str, int, str]] = {}
        self._search: tuple[int, int | None] | None = None
        self._sample_highlights: Mapping[str, tuple[np.ndarray, ...]] | None = None
        self._sample_overlay_tiles: dict[int, _CachedTile] = {}
        self._sample_marker_sprites: OrderedDict[tuple, tuple[QPixmap, QPixmap, float]] = OrderedDict()
        self._hover_keys: frozenset[tuple[str, int, str]] = frozenset()
        self._hover_group: int | None = None
        self._backend: PlotProcessBackend | None = None
        self._backend_error: str | None = None
        self._serial = 0
        self._active: dict[int, _ActiveTile] = {}
        self._closed = False
        self._ready_notified = False
        self._failed_keys: set[_TileKey] = set()
        self._failure_counts: dict[_TileKey, int] = {}
        self._prefetch_blocked: set[_TileKey] = set()
        self._rendered_tiles = 0
        self._last_render_ms = 0.0
        self._last_paint_ms = 0.0
        self._preparation_hits = self._preparation_misses = 0
        self._worker_pids: set[int] = set()
        self._width = 0
        self._dpr = 0.0
        self._resize_pending = False
        self._scroll_direction = 1
        self._last_scroll = 0
        self._pump = QTimer(self)
        self._pump.setSingleShot(True)
        self._pump.timeout.connect(self._request_next)
        self._result_timer = QTimer(self)
        self._result_timer.setInterval(3)
        self._result_timer.timeout.connect(self._poll_results)
        self._resize_timer = QTimer(self)
        self._resize_timer.setSingleShot(True)
        self._resize_timer.timeout.connect(self._finish_resize)
        self._zoom_timer = QTimer(self)
        self._zoom_timer.setSingleShot(True)
        self._zoom_timer.timeout.connect(self._flush_zoom_requests)
        self._idle_timer = QTimer(self)
        self._idle_timer.setSingleShot(True)
        self._idle_timer.timeout.connect(self._check_idle)
        self.verticalScrollBar().valueChanged.connect(self._on_scroll)
        self.horizontalScrollBar().valueChanged.connect(self._on_horizontal_scroll)
        self.viewport().setMouseTracking(True)
        # Modifier changes must reach the cursor even when the search field
        # still owns keyboard focus and the mouse has not moved.
        QApplication.instance().installEventFilter(self)

    def set_groups(self, groups, *, lane_headers, plot_type, lane_height=30, data_generation=None):
        if self._closed:
            return
        self._clear_pending_zoom()
        preserved_scroll = self.verticalScrollBar().value()
        if data_generation is not None and data_generation != self._data_generation:
            self.clear()
        self._data_generation = data_generation
        self._cancel_active()
        self._resize_timer.stop()
        self._resize_pending = False
        next_groups = []
        sources = dict(self._sources) if data_generation is not None else {}
        for group in groups:
            indices = tuple(i for i in group.lane_indices if 0 <= i < len(group.series))
            if not indices:
                continue
            if indices != group.lane_indices:
                group = PlotViewGroup(group.group_index, group.descriptor, group.title, group.series, indices)
            previous = self._sources.get(group.group_index)
            if previous is None or previous[0] is not group.series:
                self._next_source += 1
                token = self._next_source
                self._ranges.pop(group.group_index, None)
                self._pinned.pop(group.group_index, None)
            else:
                token = previous[1]
            sources[group.group_index] = (group.series, token)
            next_groups.append(group)
        self._groups, self._sources = next_groups, sources
        self._group_by_index = {group.group_index: group for group in self._groups}
        self._lane_headers, self._plot_type = tuple(lane_headers), plot_type
        self._lane_height = max(1, lane_height)
        self._width, self._dpr = self._current_width(), self.devicePixelRatioF()
        self._tops, self._group_tops = [], {}
        top = self.MARGIN
        for group in self._groups:
            self._tops.append(top)
            self._group_tops[group.group_index] = top
            top += self.HEADER_HEIGHT + len(group.lane_indices) * self._lane_height + self.GAP
        self._total_height = top - self.GAP + self.MARGIN if self._groups else 0
        active_sources = {value[1] for value in sources.values()}
        for key in list(self._cache):
            if key.source not in active_sources:
                self._cache_bytes -= self._cache.pop(key).cost
        for key in list(self._headers):
            if key[0] not in active_sources:
                self._cache_bytes -= self._headers.pop(key)[1]
        for key in list(self._prepared):
            if key[0] not in active_sources:
                self._prepared.pop(key)
        self._failed_keys.clear()
        self._failure_counts.clear()
        self._prefetch_blocked.clear()
        self._clear_hover()
        self._update_scroll_ranges()
        self.verticalScrollBar().setValue(preserved_scroll)
        self._changed()

    def displayed_lane_indices(self, group_index):
        group = self._group_by_index.get(group_index)
        return group.lane_indices if group else ()

    def metric_range(self, group_index):
        if group_index in self._ranges:
            return self._ranges[group_index]
        source = self._sources.get(group_index)
        prepared = self._prepared.get((source[1], self._lane_headers)) if source else None
        if prepared is not None:
            return prepared
        if source:
            for key, tile in reversed(self._cache.items()):
                if key.source == source[1] and key.axis is None:
                    return tile.payload.minimum, tile.payload.maximum
        return None

    def set_metric_range(self, group_index, range_override=None, pinned_point_key=None):
        if group_index not in self._sources:
            return
        self._cancel_pan()
        self._zoom_pending.pop(group_index, None)
        if not self._zoom_pending:
            self._zoom_timer.stop()
        self._native_zoom_position = None
        for active in self._active.values():
            if active.spec.group.group_index == group_index:
                active.cancelled = True
        if range_override is None:
            self._ranges.pop(group_index, None)
            self._pinned.pop(group_index, None)
        else:
            self._ranges[group_index] = tuple(range_override)
            if pinned_point_key is not None:
                self._pinned[group_index] = pinned_point_key
        self._clear_hover()
        self._changed()

    def _clear_pending_zoom(self):
        timer = getattr(self, "_zoom_timer", None)
        if timer is not None:
            timer.stop()
        self._zoom_pending.clear()
        self._native_zoom_position = None
        self._cancel_pan()

    @staticmethod
    def _zoom_modifiers():
        # Qt maps Command to ControlModifier and physical Control to Meta on
        # macOS. Keep both existing macOS shortcuts; Windows uses Ctrl.
        return Qt.ControlModifier | (Qt.MetaModifier if sys.platform == "darwin" else Qt.NoModifier)

    def _pan_modifier_held(self, modifiers):
        return bool(modifiers & Qt.AltModifier) and not bool(modifiers & self._zoom_modifiers())

    def _axis_geometry(self, position, *, body_only=False):
        if self._closed or self._resize_pending:
            return None
        group = self._zoom_group_at(position)
        if group is None:
            return None
        if body_only:
            top = self._group_tops[group.group_index]
            scroll = self.verticalScrollBar().value()
            end = top + self.HEADER_HEIGHT + len(group.lane_indices) * self._lane_height
            if (position.y() + scroll < top + self.HEADER_HEIGHT
                    or top < scroll < end and position.y() < min(self.HEADER_HEIGHT, end - scroll)):
                return None
        source = self._sources[group.group_index][1]
        local_x = position.x() - self.MARGIN + self.horizontalScrollBar().value()
        for key, tile in reversed(self._cache.items()):
            if (key.source == source and key.width == self._width and key.dpr == self._dpr
                    and key.plot_type == self._plot_type and key.headers == self._lane_headers):
                left = tile.payload.label_margin
                right = tile.pixmap.deviceIndependentSize().width() - self.PLOT_RIGHT_MARGIN
                if right > left and left <= local_x <= right:
                    return group, left, right
                return None
        return None

    def _remember_pointer(self, event):
        self._pointer_position = QPointF(event.position())
        self._pointer_inside = self.viewport().rect().contains(event.position().toPoint())
        self._pointer_modifiers = event.modifiers()

    def _magnifier_cursor(self):
        svg = self.property("zoomCursorSvg") or ""
        dpr = self.devicePixelRatioF()
        key = (svg, dpr)
        if self._zoom_cursor_key != key:
            if svg:
                renderer = QSvgRenderer(svg.encode("utf-8"))
                pixmap = QPixmap(ceil(32 * dpr), ceil(32 * dpr))
                pixmap.setDevicePixelRatio(dpr)
                pixmap.fill(Qt.transparent)
                painter = QPainter(pixmap)
                renderer.render(painter, QRectF(0, 0, 32, 32))
                painter.end()
                self._zoom_cursor = QCursor(pixmap, 12, 12)
            else:
                # Standalone viewport consumers may not load the .ui form.
                self._zoom_cursor = QCursor(Qt.SizeHorCursor)
            self._zoom_cursor_key = key
        return self._zoom_cursor

    def _refresh_cursor(self):
        if not hasattr(self, "_pan_drag"):
            return
        if self._pan_drag is not None:
            mode = "closed"
        elif (not self._closed and self._pointer_inside and self._pointer_position is not None
              and self._pointer_modifiers & (self._zoom_modifiers() | Qt.AltModifier)
              and self._axis_geometry(self._pointer_position) is not None):
            if self._pointer_modifiers & self._zoom_modifiers():
                mode = "zoom"
            elif (self._pointer_modifiers & Qt.AltModifier
                  and self._axis_geometry(self._pointer_position, body_only=True) is not None):
                mode = "open"
            else:
                mode = "arrow"
        else:
            mode = "arrow"
        # Cache the small high-DPI cursor; never build it for every mouse move.
        cursor_key = (mode, self.devicePixelRatioF())
        if self._cursor_mode == cursor_key:
            return
        self._cursor_mode = cursor_key
        cursor = {"closed": Qt.ClosedHandCursor, "open": Qt.OpenHandCursor, "arrow": Qt.ArrowCursor}
        self.viewport().setCursor(self._magnifier_cursor() if mode == "zoom" else cursor[mode])

    def _cancel_pan(self):
        self._pan_drag = None
        self._refresh_cursor()

    def eventFilter(self, watched, event):
        if not hasattr(self, "_pan_drag") or self._closed:
            return super().eventFilter(watched, event)
        kind = event.type()
        if kind in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease):
            if isinstance(watched, QWidget) and watched.window() == self.window():
                modifiers = event.modifiers()
                flag = {Qt.Key_Control: Qt.ControlModifier, Qt.Key_Meta: Qt.MetaModifier,
                        Qt.Key_Alt: Qt.AltModifier}.get(event.key())
                if flag is not None:
                    modifiers = modifiers | flag if kind == QEvent.Type.KeyPress else modifiers & ~flag
                self._pointer_modifiers = modifiers
                if (not self._pan_modifier_held(modifiers)
                        or kind == QEvent.Type.KeyPress and event.key() == Qt.Key_Escape):
                    self._cancel_pan()
                if modifiers & self._zoom_modifiers():
                    self._clear_hover()
                self._refresh_cursor()
        elif (kind == QEvent.Type.ApplicationDeactivate
              or kind == QEvent.Type.WindowDeactivate and watched == self.window()):
            self._pointer_inside = False
            self._pointer_modifiers = Qt.NoModifier
            self._cancel_pan()
            self._clear_hover()
        elif kind == QEvent.Type.WindowActivate and watched == self.window():
            self._pointer_position = QPointF(self.viewport().mapFromGlobal(QCursor.pos()))
            self._pointer_inside = self.viewport().isVisible() and self.viewport().rect().contains(
                self._pointer_position.toPoint())
            self._pointer_modifiers = QApplication.keyboardModifiers()
            self._refresh_cursor()
        return super().eventFilter(watched, event)

    def _zoom_group_at(self, position):
        if not self._groups or not self.viewport().rect().contains(position.toPoint()):
            return None
        scroll = self.verticalScrollBar().value()
        index = max(0, bisect_right(self._tops, scroll) - 1)
        group = self._groups[index]
        end = self._tops[index] + self.HEADER_HEIGHT + len(group.lane_indices) * self._lane_height
        if self._tops[index] < scroll < end and position.y() < min(self.HEADER_HEIGHT, end - scroll):
            return group
        logical_y = position.y() + scroll
        index = bisect_right(self._tops, logical_y) - 1
        if index < 0:
            return None
        group = self._groups[index]
        end = self._tops[index] + self.HEADER_HEIGHT + len(group.lane_indices) * self._lane_height
        return group if logical_y < end else None

    def zoom_at(self, position, factor):
        """Queue horizontal zoom of the pointed metric; factor > 1 zooms in."""
        if self._closed or self._resize_pending or not isfinite(factor) or factor <= 0:
            return False
        geometry = self._axis_geometry(position)
        if geometry is None:
            return False
        group, left, right = geometry
        group_index = group.group_index
        bounds = self._zoom_pending.get(group_index) or self.metric_range(group_index)
        if bounds is None or not all(isfinite(value) for value in bounds):
            return False
        low, high = bounds
        span = high - low
        if not isfinite(span) or span <= 0:
            return False
        source = self._sources[group_index][1]
        local_x = position.x() - self.MARGIN + self.horizontalScrollBar().value()
        ratio = (local_x - left) / (right - left)
        anchor = low + span * ratio
        base = self._prepared.get((source, self._lane_headers), (low, high))
        base_span = base[1] - base[0]
        if not isfinite(base_span) or base_span <= 0:
            return False
        minimum_span = max(1e-9, base_span * 1e-6, ulp(max(abs(low), abs(high))) * 16)
        maximum_span = min(1e300, base_span * 1e6)
        new_span = min(maximum_span, max(minimum_span, span / factor))
        new_low = anchor - new_span * ratio
        new_high = anchor + new_span * (1 - ratio)
        if (not all(isfinite(value) for value in (new_low, new_high))
                or new_high <= new_low or (new_low, new_high) == (low, high)):
            return False
        self._zoom_pending[group_index] = (new_low, new_high)
        # Throttle, rather than restarting a trailing-only debounce: a long
        # pinch still produces intermediate frames and stores just one target.
        if not self._zoom_timer.isActive():
            self._zoom_timer.start(self.ZOOM_DELAY_MS)
        return True

    def _zoom_position_is_axis(self, position):
        return self._axis_geometry(position) is not None

    def _flush_zoom_requests(self):
        if self._closed or self._resize_pending:
            self._clear_pending_zoom()
            return
        changed = False
        visible = self._specs(False) if self._backend is not None else ()
        for group_index, bounds in tuple(self._zoom_pending.items()):
            if group_index not in self._group_by_index:
                self._zoom_pending.pop(group_index, None)
                continue
            if (any(active.spec.group.group_index == group_index for active in self._active.values())
                    or self._backend is not None and not self._backend.can_submit(group_index)):
                continue
            if any(spec.group.group_index == group_index and spec.key not in self._failed_keys
                   and (spec.key not in self._cache or self._header_key(spec) not in self._headers)
                   for spec in visible):
                # Finish this metric's visible frame before advancing. Without
                # this, a long drag can repeatedly replace tile 1 before tile
                # 2 is drawn and show no intermediate frames at all.
                continue
            self._zoom_pending.pop(group_index, None)
            self._ranges[group_index] = bounds
            changed = True
        if changed:
            self._clear_hover()
            self._changed()
        if self._zoom_pending and not self._zoom_timer.isActive():
            # Warmup or another metric on the same actor may own its slot.
            # Retain only the latest target and retry even without a tile job.
            self._zoom_timer.start(self.ZOOM_DELAY_MS)

    def wheelEvent(self, event):
        self._remember_pointer(event)
        self._cancel_pan()
        self._refresh_cursor()
        if event.modifiers() & self._zoom_modifiers():
            delta = event.pixelDelta().y() if not event.pixelDelta().isNull() else event.angleDelta().y() / 3
            if delta:
                changed = self.zoom_at(event.position(), 2.0 ** max(-8.0, min(8.0, delta / 240.0)))
                if changed or self._zoom_position_is_axis(event.position()):
                    event.accept()
                    return
        super().wheelEvent(event)

    def viewportEvent(self, event):
        kind = event.type()
        if kind == QEvent.Type.Enter and hasattr(self, "_pointer_inside"):
            self._pointer_position = QPointF(event.position())
            self._pointer_inside = True
            self._pointer_modifiers = QApplication.keyboardModifiers()
            self._refresh_cursor()
        elif kind == QEvent.Type.Leave and hasattr(self, "_pointer_inside"):
            self._pointer_inside = False
            # Qt's implicit mouse grab keeps an active drag alive outside the
            # viewport until release. The cursor recovers even off the plot.
            self._refresh_cursor()
            self._clear_hover()
        elif kind in (QEvent.Type.Hide, QEvent.Type.UngrabMouse) and hasattr(self, "_pan_drag"):
            self._pointer_inside = False
            self._cancel_pan()
        if kind == QEvent.Type.NativeGesture:
            self._cancel_pan()
            gesture = event.gestureType()
            if gesture == Qt.NativeGestureType.BeginNativeGesture:
                self._native_zoom_position = None
            elif gesture == Qt.NativeGestureType.EndNativeGesture:
                self._native_zoom_position = None
                self._zoom_timer.stop()
                self._flush_zoom_requests()
            elif gesture == Qt.NativeGestureType.ZoomNativeGesture:
                position = self._native_zoom_position or event.position()
                if self.zoom_at(position, 1.0 + event.value()) or self._zoom_position_is_axis(position):
                    self._native_zoom_position = QPointF(position)
                    event.accept()
                    return True
        return super().viewportEvent(event)

    def scroll_to(self, group_index, lane_index=None):
        group = self._group_by_index.get(group_index)
        if group is None:
            return
        top = self._group_tops[group_index]
        if lane_index is not None:
            try:
                lane = group.lane_indices.index(lane_index)
            except ValueError:
                return
            top += lane * self._lane_height
        self.verticalScrollBar().setValue(max(0, top - self.MARGIN))
        self._changed()

    def set_search_highlight(self, group_index, lane_index=None):
        self._search = None if group_index is None else (group_index, lane_index)
        self.viewport().update()

    def set_sample_highlights(self, indices_by_metric: Mapping[str, tuple[np.ndarray, ...]] | None = None):
        """Overlay immutable original-point selections without rebuilding images.

        Each metric maps to one sorted numeric point-index array per original
        lane, including lanes hidden by the metric/lane filter.
        """
        if indices_by_metric is self._sample_highlights:
            return
        self._sample_highlights = indices_by_metric
        self._clear_sample_overlay_cache()
        self.viewport().update()

    def _clear_sample_overlay_cache(self):
        for tile in self._sample_overlay_tiles.values():
            self._clear_tile_sample_overlay(tile)
        self._sample_overlay_tiles.clear()

    @staticmethod
    def _clear_tile_sample_overlay(tile):
        tile.sample_records = None
        tile.sample_pixmap = None
        tile.sample_pixmap_offset = 0.0

    def _sample_overlay_image_bytes(self):
        return sum(tile.sample_pixmap.width() * tile.sample_pixmap.height() * 4
                   for tile in self._sample_overlay_tiles.values() if tile.sample_pixmap is not None)

    def clear(self):
        self._clear_pending_zoom()
        self._cancel_active()
        self._resize_timer.stop()
        self._pump.stop()
        self._groups.clear()
        self._group_by_index.clear()
        self._group_tops.clear()
        self._tops.clear()
        self._sources.clear()
        self._data_generation = None
        self._cache.clear()
        self._headers.clear()
        self._prepared.clear()
        self._cache_bytes = self._total_height = 0
        self._ranges.clear()
        self._pinned.clear()
        self._search = None
        self._sample_highlights = None
        self._clear_sample_overlay_cache()
        self._failed_keys.clear()
        self._failure_counts.clear()
        self._prefetch_blocked.clear()
        self._clear_hover()
        self._update_scroll_ranges()
        self._refresh_cursor()
        self.viewport().update()

        if self._backend is not None and not self._backend.closed:
            self._backend.invalidate()
            if self._backend.running_count:
                self._result_timer.start()

    def _ensure_backend(self):
        if self._closed or self._backend_error:
            return False
        if self._backend is None:
            try:
                self._backend = PlotProcessBackend()
            except Exception as exc:
                self._backend_error = str(exc)
                self.renderFailed.emit(f"Could not start plot workers: {exc}")
                return False
        return True

    def prewarm(self):
        """Start font/process initialization while the window loads its data."""
        if self._ensure_backend():
            try:
                self._backend.warmup()
                if self._backend.running_count:
                    self._result_timer.start()
            except Exception as exc:
                self._backend_error = str(exc)
                self.renderFailed.emit(f"Could not start plot workers: {exc}")

    def shutdown(self, wait=False):
        self._closed = True
        QApplication.instance().removeEventFilter(self)
        self._clear_pending_zoom()
        self.set_sample_highlights(None)
        self._sample_marker_sprites.clear()
        self._cancel_active()
        self._pump.stop()
        self._result_timer.stop()
        self._resize_timer.stop()
        self._active.clear()
        if self._backend is not None:
            self._backend.close()
            if wait:
                self._backend.wait_closed()
        self._idle_timer.start(0)

    def workers_running(self):
        if self._backend is None:
            return False
        if self._backend.closed:
            return not self._backend.shutdown_finished
        return self._backend.running_count > 0

    def _check_idle(self):
        if self.workers_running():
            self._idle_timer.start(30)
        else:
            self.workersFinished.emit()

    def cache_info(self):
        visible = self._specs(prefetch=False)
        return {
            "bytes": self._cache_bytes, "limit": self.cache_limit_bytes,
            "tiles": len(self._cache), "prepared_metrics": len(self._prepared),
            "rendered_tiles": self._rendered_tiles, "visible_tiles": len(visible),
            "ready": all(spec.key in self._cache and self._header_key(spec) in self._headers for spec in visible),
            "active_workers": self._backend.running_count if self._backend is not None else 0,
            "last_render_ms": self._last_render_ms, "last_paint_ms": self._last_paint_ms,
            "backend": "process", "worker_pids": sorted(self._worker_pids),
            "preparation_hits": self._preparation_hits, "preparation_misses": self._preparation_misses,
            "hover_bytes": sum(tile.payload.index.estimated_nbytes for tile in self._cache.values()),
            "sample_overlay_bytes": sum(tile.sample_records.nbytes for tile in self._sample_overlay_tiles.values()
                                        if tile.sample_records is not None),
            "sample_overlay_image_bytes": self._sample_overlay_image_bytes(),
            "sample_overlay_image_limit": self.SAMPLE_OVERLAY_LIMIT_BYTES,
        }

    def _current_width(self):
        return max(1, self.viewport().width() - 2 * self.MARGIN)

    def _update_scroll_ranges(self):
        self.verticalScrollBar().setPageStep(self.viewport().height())
        self.verticalScrollBar().setSingleStep(self._lane_height)
        self.verticalScrollBar().setRange(0, max(0, self._total_height - self.viewport().height()))
        widest = max((tile.pixmap.deviceIndependentSize().width() for key, tile in self._cache.items()
                      if key.width == self._width and key.dpr == self._dpr and key.plot_type == self._plot_type),
                     default=self._width)
        self.horizontalScrollBar().setRange(0, max(0, int(widest + 2 * self.MARGIN - self.viewport().width())))

    def _on_scroll(self, value):
        self._cancel_pan()
        self._scroll_direction = 1 if value >= self._last_scroll else -1
        self._last_scroll = value
        self._prefetch_blocked.clear()
        self._clear_hover()
        self._changed()

    def _on_horizontal_scroll(self, value):
        self._cancel_pan()
        self._clear_hover()
        self.viewport().update()

    def scrollContentsBy(self, dx, dy):
        self.viewport().update()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not hasattr(self, "_width"):
            return
        self._cancel_pan()
        width, dpr = self._current_width(), self.devicePixelRatioF()
        if width != self._width or dpr != self._dpr:
            self._clear_pending_zoom()
            self._cancel_active()
            self._width, self._dpr = width, dpr
            self._resize_pending = True
            self._clear_hover()
            self._resize_timer.start(self.RESIZE_DELAY_MS)
        self._update_scroll_ranges()
        self._changed()

    def event(self, event):
        result = super().event(event)
        if hasattr(self, "_pan_drag"):
            if event.type() in (QEvent.Type.Hide, QEvent.Type.WindowDeactivate):
                self._pointer_inside = False
                self._cancel_pan()
            elif event.type() in (QEvent.Type.FontChange, QEvent.Type.ApplicationFontChange,
                                  QEvent.Type.DevicePixelRatioChange, QEvent.Type.ScreenChangeInternal):
                self._cancel_pan()
        if (hasattr(self, "_backend") and self._backend is not None and not self._closed
                and event.type() in (QEvent.Type.ApplicationFontChange, QEvent.Type.FontChange,
                                     QEvent.Type.DevicePixelRatioChange, QEvent.Type.ScreenChangeInternal)
                and self._backend.refresh_context()):
            self._clear_pending_zoom()
            self._cancel_active()
            self._cache.clear()
            self._headers.clear()
            self._prepared.clear()
            self._cache_bytes = 0
            self._failed_keys.clear()
            self._failure_counts.clear()
            self._clear_hover()
            self._resize_pending = True
            self._resize_timer.start(self.RESIZE_DELAY_MS)
            self.viewport().update()
        # Moving between displays can change DPR without changing logical size.
        if hasattr(self, "_resize_timer") and self.devicePixelRatioF() != self._dpr:
            self._clear_pending_zoom()
            self._dpr = self.devicePixelRatioF()
            self._cancel_active()
            self._resize_pending = True
            self._resize_timer.start(self.RESIZE_DELAY_MS)
        return result

    def _finish_resize(self):
        self._resize_pending = False
        self._prefetch_blocked.clear()
        self._changed()

    def _changed(self):
        self._ready_notified = False
        if not self._closed:
            self._pump.start(0)
        self._refresh_cursor()
        self.viewport().update()

    def _cancel_active(self):
        # No unbounded executor queue: each actor finishes at most one obsolete
        # tile. Its shared slot cannot be reused until the result is discarded.
        for active in self._active.values():
            active.cancelled = True

    def _specs(self, prefetch=False):
        if not self._groups:
            return []
        scroll = self.verticalScrollBar().value()
        height = self.viewport().height()
        extra = height if prefetch else 0
        low, high = max(0, scroll - extra), scroll + height + extra
        index = max(0, bisect_right(self._tops, low) - 1)
        specs = []
        while index < len(self._groups) and self._tops[index] < high:
            group = self._groups[index]
            body_top = self._tops[index] + self.HEADER_HEIGHT
            count = len(group.lane_indices)
            first = max(0, (low - body_top) // self._lane_height)
            last = min(count, max(1, (high - body_top + self._lane_height - 1) // self._lane_height))
            # A partly visible header still needs the first tile to prepare its axis.
            for lane_start in range((first // self.TILE_LANES) * self.TILE_LANES, last, self.TILE_LANES):
                lanes = group.lane_indices[lane_start:lane_start + self.TILE_LANES]
                key = _TileKey(
                    self._sources[group.group_index][1], group.group_index, lanes,
                    self._width, self._dpr, self._plot_type, self._lane_height,
                    self._ranges.get(group.group_index), self._pinned.get(group.group_index), self._lane_headers,
                )
                specs.append(_TileSpec(key, group, body_top + lane_start * self._lane_height, lane_start))
            index += 1
        return specs

    @staticmethod
    def _header_key(spec):
        key = spec.key
        return (key.source, key.width, key.dpr, key.axis, key.headers, spec.group.title)

    def _plan(self):
        visible = self._specs(False)
        keys = {spec.key for spec in visible}
        near = [spec for spec in self._specs(True) if spec.key not in keys]
        center = self.verticalScrollBar().value() + self.viewport().height() / 2
        near.sort(key=lambda spec: (0 if (spec.top - center) * self._scroll_direction >= 0 else 1, abs(spec.top - center)))
        return visible, visible + near

    def _estimated_tile_cost(self, spec):
        point_count = sum(len(spec.group.series[index].points) for index in spec.key.lanes)
        pixel_width = round(max(spec.key.width, 274) * spec.key.dpr)
        pixel_height = round(len(spec.key.lanes) * self._lane_height * spec.key.dpr)
        # Numeric records/order, bounded lazy lookup caches, and bucket offsets.
        estimate = pixel_width * pixel_height * 8 + point_count * 40 + 80 * 1024
        if self._header_key(spec) not in self._headers:
            estimate += pixel_width * round(self.HEADER_HEIGHT * spec.key.dpr) * 4
        return estimate

    def _request_next(self):
        if self._closed or self._resize_pending:
            return
        visible, plan = self._plan()
        desired = {spec.key for spec in plan}
        visible_keys = {spec.key for spec in visible}
        ready = sum(spec.key in self._cache and self._header_key(spec) in self._headers for spec in visible)
        if ready == len(visible):
            if not self._ready_notified:
                self._ready_notified = True
                self.renderingReady.emit()
        elif not any(spec.key in self._failed_keys for spec in visible):
            self.renderingProgress.emit(ready, len(visible), "Preparing visible plots")
        for active in self._active.values():
            if active.spec.key not in desired:
                active.cancelled = True
        if not plan or not self._ensure_backend():
            return
        pending = {active.spec.key for active in self._active.values() if not active.cancelled}
        reserved = sum(active.estimated_cost for active in self._active.values() if not active.cancelled)
        for spec in plan:
            if (spec.key in self._cache and self._header_key(spec) in self._headers
                    or spec.key in self._failed_keys or spec.key in pending):
                continue
            if not self._backend.can_submit(spec.group.group_index):
                continue
            estimate = self._estimated_tile_cost(spec)
            if spec.key not in visible_keys:
                if spec.group.group_index in self._zoom_pending:
                    # The latest gesture target gets the next free slot; do
                    # not let old-range prefetch prolong input latency.
                    continue
                # Reserve all in-flight allocations as well as retained images.
                if spec.key in self._prefetch_blocked or self._cache_bytes + reserved + estimate > self.cache_limit_bytes:
                    continue
            self._serial += 1
            key = spec.key
            request = {
                "op": "render", "metric_id": spec.group.group_index, "generation": key.source,
                "series": spec.group.series, "lane_indices": key.lanes, "lane_headers": key.headers,
                "plot_type": key.plot_type, "lane_height": key.lane_height,
                "width": key.width, "dpr": key.dpr, "range_override": key.axis,
                "pinned_point_key": key.pinned, "title": spec.group.title,
                "include_header": self._header_key(spec) not in self._headers,
            }
            try:
                actor = self._backend.submit(request, token=self._serial)
            except Exception as exc:
                self._tile_failed(spec, str(exc))
                continue
            self._active[actor] = _ActiveTile(self._serial, spec, estimate)
            pending.add(key)
            reserved += estimate
        if self._backend.running_count:
            self._result_timer.start()

    def _poll_results(self):
        if self._closed or self._backend is None:
            self._result_timer.stop()
            return
        completions = self._backend.poll()
        if not completions:
            if not self._backend.running_count:
                self._result_timer.stop()
            return
        desired = {spec.key for spec in self._plan()[1]} if not self._resize_pending else set()
        for completion in completions:
            active = self._active.pop(completion.actor, None)
            try:
                if completion.result is not None and completion.result.get("pid"):
                    self._worker_pids.add(completion.result["pid"])
                if active is None:  # Font/process prewarm has no tile attached.
                    if completion.error is not None:
                        self.renderFailed.emit(f"Plot worker initialization failed: {completion.error}")
                    continue
                if (active.serial != completion.token or active.cancelled
                        or active.spec.key not in desired):
                    continue
                if completion.error is not None:
                    self._tile_failed(active.spec, str(completion.error))
                    continue
                wire = completion.result
                payload, header = unpack_compact_result(wire, active.spec.group.series)
                self._tile_ready(active.spec, payload, header, wire)
            except Exception as exc:
                if active is not None and not active.cancelled:
                    self._tile_failed(active.spec, str(exc))
            finally:
                # Decoding copied the image; only now can this actor overwrite
                # its shared slot. Obsolete results take the same release path.
                self._backend.release(completion)
        if not self._backend.running_count:
            self._result_timer.stop()
        if self._zoom_pending and not self._zoom_timer.isActive():
            self._flush_zoom_requests()
        self._pump.start(0)

    def _tile_ready(self, spec, payload, header, wire):
        self._rendered_tiles += 1
        self._last_render_ms = wire.get("worker_ms", 0.0)
        self._failure_counts.pop(spec.key, None)
        prepared_key = (spec.key.source, spec.key.headers)
        self._prepared[prepared_key] = tuple(wire["base_range"])
        self._prepared.move_to_end(prepared_key)
        # Only two axis bounds stay in the parent; point/statistics preparation
        # remains in the four bounded child caches.
        while len(self._prepared) > 128:
            self._prepared.popitem(last=False)
        if wire.get("prepared_hit"):
            self._preparation_hits += 1
        else:
            self._preparation_misses += 1
        cost = payload.image.sizeInBytes() * 2 + payload.index.reserved_nbytes
        if spec.key in self._cache:
            self._cache_bytes -= self._cache.pop(spec.key).cost
        self._cache[spec.key] = _CachedTile(payload, QPixmap.fromImage(payload.image), cost)
        self._cache_bytes += cost
        if header is not None:
            header_key = self._header_key(spec)
            if header_key in self._headers:
                self._cache_bytes -= self._headers.pop(header_key)[1]
            header_cost = header.sizeInBytes()
            self._headers[header_key] = (QPixmap.fromImage(header), header_cost)
            self._cache_bytes += header_cost
        if spec.key.axis is not None:
            self._trim_zoom_history(spec)
        self._trim_cache()
        if spec.key not in self._cache:
            self._prefetch_blocked.add(spec.key)
        self._update_scroll_ranges()
        self._refresh_cursor()
        self.viewport().update()

    def _tile_failed(self, spec, message):
        attempts = self._failure_counts.get(spec.key, 0) + 1
        self._failure_counts[spec.key] = attempts
        if attempts < 2:
            self._pump.start(0)
            return
        self._failed_keys.add(spec.key)
        self.renderFailed.emit(message)

    def _trim_cache(self):
        visible = self._specs(False)
        displayed = self._display_specs(visible)
        protected = {spec.key for spec in visible + displayed}
        for key in list(self._cache):
            if self._cache_bytes <= self.cache_limit_bytes:
                break
            if key not in protected:
                self._cache_bytes -= self._cache.pop(key).cost
        protected_headers = {self._header_key(spec) for spec in visible + displayed}
        for key in list(self._headers):
            if self._cache_bytes <= self.cache_limit_bytes:
                break
            if key not in protected_headers:
                self._cache_bytes -= self._headers.pop(key)[1]

    def _trim_zoom_history(self, spec):
        key = spec.key
        family = (key.source, key.width, key.dpr, key.plot_type, key.lane_height, key.headers, key.pinned)
        keep_axes = {None, key.axis}
        for displayed in self._display_specs(self._specs(False)):
            if displayed.key.source == key.source and displayed.key.axis != key.axis:
                keep_axes.add(displayed.key.axis)
        # A partially rendered intermediate range may be newer in the LRU than
        # the complete frame still on screen. Preserve that complete frame
        # until its replacement has all visible lanes and the matching ruler.
        if len(keep_axes) < 3:
            for candidate in reversed(self._cache):
                if ((candidate.source, candidate.width, candidate.dpr, candidate.plot_type,
                     candidate.lane_height, candidate.headers, candidate.pinned) == family
                        and candidate.axis not in keep_axes):
                    keep_axes.add(candidate.axis)
                    break
        for candidate in list(self._cache):
            if ((candidate.source, candidate.width, candidate.dpr, candidate.plot_type,
                 candidate.lane_height, candidate.headers, candidate.pinned) == family
                    and candidate.axis not in keep_axes):
                self._cache_bytes -= self._cache.pop(candidate).cost
        # Continuous gestures must not evict unrelated metrics by accumulating
        # hundreds of intermediate image/ruler pairs.
        used_axes = {candidate.axis for candidate in self._cache
                     if (candidate.source, candidate.width, candidate.dpr, candidate.headers)
                     == (key.source, key.width, key.dpr, key.headers)}
        for header in list(self._headers):
            if ((header[0], header[1], header[2], header[4])
                    == (key.source, key.width, key.dpr, key.headers) and header[3] not in used_axes):
                self._cache_bytes -= self._headers.pop(header)[1]

    def _display_specs(self, specs):
        """Keep all visible lanes and their ruler on one complete axis frame."""
        grouped = {}
        for spec in specs:
            grouped.setdefault(spec.group.group_index, []).append(spec)
        substitutions = {}
        for group_specs in grouped.values():
            if all(spec.key in self._cache and self._header_key(spec) in self._headers for spec in group_specs):
                continue
            first = group_specs[0]
            key = first.key
            for candidate in reversed(self._cache):
                if ((candidate.source, candidate.lanes, candidate.width, candidate.dpr, candidate.plot_type,
                     candidate.lane_height, candidate.pinned, candidate.headers)
                        != (key.source, key.lanes, key.width, key.dpr, key.plot_type,
                            key.lane_height, key.pinned, key.headers) or candidate.axis == key.axis):
                    continue
                previous = [replace(spec, key=replace(spec.key, axis=candidate.axis)) for spec in group_specs]
                if all(spec.key in self._cache and self._header_key(spec) in self._headers for spec in previous):
                    substitutions.update((original.key, old) for original, old in zip(group_specs, previous))
                    break
        return [substitutions.get(spec.key, spec) for spec in specs]

    def _preview(self, spec):
        # Reuse only identical data/lanes/style/axis at a previous width while
        # resizing. These preview pixels never participate in hit testing.
        key = spec.key
        for candidate in reversed(self._cache):
            if (candidate.source, candidate.lanes, candidate.plot_type, candidate.axis, candidate.pinned, candidate.headers) == (
                key.source, key.lanes, key.plot_type, key.axis, key.pinned, key.headers
            ):
                return self._cache[candidate]
        # Cross-axis previews are allowed only when the entire visible metric
        # and ruler can share that old frame. A newly scrolled-in lane without
        # an old tile must not borrow pixels with different ruler bounds.
        for displayed in self._display_specs(self._specs(False)):
            if (displayed.group.group_index == spec.group.group_index
                    and displayed.key.lanes == key.lanes and displayed.key != key):
                return self._cache.get(displayed.key)
        return None

    def paintEvent(self, event):
        started = perf_counter()
        painter = QPainter(self.viewport())
        painter.fillRect(self.viewport().rect(), QColor("#ffffff"))
        scroll = self.verticalScrollBar().value()
        x = self.MARGIN - self.horizontalScrollBar().value()
        specs = self._display_specs(self._specs(False))
        drawn_headers = set()
        sample_tiles = {}
        for spec in specs:
            tile = self._cache.get(spec.key)
            y = spec.top - scroll
            if tile is not None:
                painter.drawPixmap(QPointF(x, y), tile.pixmap)
                self._cache.move_to_end(spec.key)
            else:
                preview = self._preview(spec)
                if preview is not None:
                    painter.drawPixmap(
                        QRectF(x, y, self._width, len(spec.key.lanes) * self._lane_height),
                        preview.pixmap, QRectF(preview.pixmap.rect()),
                    )
                    # Match the temporary image transform while resizing; its
                    # coordinates and clipping bounds belong to that old tile.
                    painter.save()
                    painter.translate(x, y)
                    size = preview.pixmap.deviceIndependentSize()
                    painter.scale(self._width / size.width(),
                                  len(spec.key.lanes) * self._lane_height / size.height())
                    self._draw_sample_overlays(painter, spec, preview, 0, 0)
                    painter.restore()
                    sample_tiles[id(preview)] = preview
                else:
                    painter.setPen(QColor("#6b7882"))
                    painter.drawText(QRectF(x + 8, max(0, y), max(1, self._width - 16), 30), Qt.AlignLeft | Qt.AlignVCenter,
                                     str(self.property("loadingText") or ""))
            if spec.group.group_index not in drawn_headers:
                self._draw_header(painter, spec, x, self._group_tops[spec.group.group_index] - scroll)
                drawn_headers.add(spec.group.group_index)
            if tile is not None:
                self._draw_point_overlays(painter, spec, tile, x, y)
                self._draw_sample_overlays(painter, spec, tile, x, y)
                sample_tiles[id(tile)] = tile
        # Only this frame's tiles retain the compact overlay lookup. This does
        # not keep evicted background images or historical queries alive.
        for tile_id, tile in self._sample_overlay_tiles.items():
            if tile_id not in sample_tiles:
                self._clear_tile_sample_overlay(tile)
        self._sample_overlay_tiles = sample_tiles if self._sample_highlights is not None else {}
        self._draw_search(painter, x, scroll)
        if self._groups:
            index = max(0, bisect_right(self._tops, scroll) - 1)
            group = self._groups[index]
            top = self._tops[index]
            end = top + self.HEADER_HEIGHT + len(group.lane_indices) * self._lane_height
            if top < scroll < end:
                spec = next((item for item in specs if item.group.group_index == group.group_index), None)
                if spec is not None:
                    self._draw_header(painter, spec, x, min(0, end - scroll - self.HEADER_HEIGHT))
        elif self.property("emptyText"):
            painter.setPen(QColor("#6b7882"))
            painter.drawText(self.viewport().rect(), Qt.AlignCenter, str(self.property("emptyText")))
        painter.end()
        self._last_paint_ms = (perf_counter() - started) * 1000

    def _draw_header(self, painter, spec, x, y):
        if y + self.HEADER_HEIGHT < 0 or y > self.viewport().height():
            return
        key = self._header_key(spec)
        cached = self._headers.get(key)
        if cached is not None:
            painter.drawPixmap(QPointF(x, y), cached[0])
            self._headers.move_to_end(key)
        else:
            painter.fillRect(QRectF(x, y, self._width, self.HEADER_HEIGHT), QColor("#ffffff"))
            painter.setPen(QColor("#6b7882"))
            painter.drawText(QRectF(x + 8, y, max(1, self._width - 16), 24), Qt.AlignLeft | Qt.AlignVCenter, spec.group.title)

    def _draw_search(self, painter, x, scroll):
        if self._search is None:
            return
        group_index, lane_index = self._search
        group = self._group_by_index.get(group_index)
        if group is None:
            return
        top = self._group_tops[group_index] + self.HEADER_HEIGHT
        height = len(group.lane_indices) * self._lane_height
        if lane_index is not None:
            try:
                top += group.lane_indices.index(lane_index) * self._lane_height
            except ValueError:
                return
            height = self._lane_height
        band = QRectF(x, top - scroll, self._width, height)
        painter.fillRect(band, QColor(46, 94, 70, 24))
        painter.fillRect(QRectF(band.left(), band.top(), 4, band.height()), QColor("#1f5c4a"))
        painter.setPen(QPen(QColor("#1f5c4a"), 1))
        painter.setBrush(Qt.NoBrush)
        painter.drawRect(band.adjusted(.5, .5, -.5, -.5))

    def _draw_point_overlays(self, painter, spec, tile, x, y):
        marked = []
        if self._hover_group == spec.group.group_index:
            marked.extend(tile.payload.index.record_hit(int(index))
                          for index in tile.payload.index.merge_keys_indices(self._hover_keys))
        pinned_key = self._pinned.get(spec.group.group_index)
        if pinned_key is not None:
            pinned = tile.payload.index.point_key_index(pinned_key)
            if pinned is not None:
                marked.append(tile.payload.index.record_hit(pinned))
        painter.setBrush(Qt.NoBrush)
        for item in marked:
            position = item.position + QPointF(x, y)
            radius = max(5.5, item.radius + 4)
            painter.setPen(QPen(QColor("#ffffff"), 3))
            painter.drawEllipse(position, radius + 1.5, radius + 1.5)
            painter.setPen(QPen(QColor("#1f5c4a"), 2))
            painter.drawEllipse(position, radius, radius)

    def _sample_record_indices(self, spec, tile):
        self._sample_overlay_tiles[id(tile)] = tile
        if tile.sample_records is not None:
            return tile.sample_records
        selections = (self._sample_highlights.get(spec.group.descriptor.logical_metric)
                      if self._sample_highlights is not None else None)
        records = tile.payload.index.records
        selected = np.zeros(len(records), dtype=bool)
        if selections is not None:
            # Resolve the source identities with numeric operations. No hover
            # objects, sample dictionaries or per-point keys are copied.
            for lane in spec.key.lanes:
                if lane >= len(selections) or not len(selections[lane]):
                    continue
                candidates = np.flatnonzero(records["lane"] == lane)
                source_indices = records["point_index"][candidates]
                wanted = selections[lane]
                positions = np.searchsorted(wanted, source_indices)
                valid = positions < len(wanted)
                matches = np.zeros(len(candidates), dtype=bool)
                matches[valid] = wanted[positions[valid]] == source_indices[valid]
                selected[candidates[matches]] = True
        result = np.flatnonzero(selected).astype(np.int32)
        result.flags.writeable = False
        tile.sample_records = result
        return result

    def _draw_sample_overlays(self, painter, spec, tile, x, y):
        if self._sample_highlights is None:
            return
        selected = self._sample_record_indices(spec, tile)
        if len(selected) > self.SAMPLE_VECTOR_LIMIT:
            if tile.sample_pixmap is None:
                dpr = tile.payload.image.devicePixelRatio()
                padding = ceil(self.SAMPLE_OVERLAY_PADDING * dpr)
                width = tile.payload.image.width() + 2 * padding
                height = tile.payload.image.height() + 2 * padding
                cost = width * height * 4
                if self._sample_overlay_image_bytes() + cost <= self.SAMPLE_OVERLAY_LIMIT_BYTES:
                    image = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
                    image.setDevicePixelRatio(dpr)
                    image.fill(Qt.transparent)
                    overlay_painter = QPainter(image)
                    offset = padding / dpr
                    # Padding preserves rings crossing a tile boundary.
                    self._draw_dense_sample_overlays(overlay_painter, tile, selected, offset, offset)
                    overlay_painter.end()
                    tile.sample_pixmap = QPixmap.fromImage(image)
                    tile.sample_pixmap_offset = offset
            if tile.sample_pixmap is not None:
                offset = tile.sample_pixmap_offset
                painter.drawPixmap(QPointF(x - offset, y - offset), tile.sample_pixmap)
            else:
                # Extremely large displays remain correct when the visible
                # overlays exceed the separate, strictly bounded image budget.
                self._draw_dense_sample_overlays(painter, tile, selected, x, y)
            return
        path = QPainterPath()
        index = tile.payload.index
        for record_index in selected:
            record = index.records[record_index]
            point = index.point_at(int(record_index))
            position = QPointF(float(record["x"]) + x, float(record["y"]) + y)
            direction = _sample_marker_direction(point.value, tile.payload.minimum, tile.payload.maximum)
            if direction:
                # Same triangle geometry as ComparisonPlotRenderer, enlarged
                # to frame the marker without covering its original color.
                path.moveTo(position + QPointF(direction * 7.65, 0))
                path.lineTo(position + QPointF(-direction * 5.44, -4.76))
                path.lineTo(position + QPointF(-direction * 5.44, 4.76))
                path.closeSubpath()
            else:
                radius = max(5.5, float(record["radius"]) + 3.2)
                path.addEllipse(position, radius, radius)
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(Qt.NoBrush)
        # Small selections retain exact vector geometry. Dense selections use
        # the raster path above, avoiding expensive intersecting curve strokes.
        # Complete all halos before drawing any yellow outlines.
        painter.setPen(QPen(QColor("#ffffff"), 4))
        painter.drawPath(path)
        painter.setPen(QPen(QColor("#e6b800"), 2))
        painter.drawPath(path)
        painter.restore()

    def _sample_sprite(self, dpr, direction, radius):
        key = (dpr, direction, radius if not direction else 0.0)
        if key in self._sample_marker_sprites:
            self._sample_marker_sprites.move_to_end(key)
            return self._sample_marker_sprites[key]
        extent = 7.65 if direction else radius
        pixel_size = max(1, ceil((extent + 3) * 2 * dpr))
        center = pixel_size / (2 * dpr)
        position = QPointF(center, center)
        images = []
        for color, width in (("#ffffff", 4), ("#e6b800", 2)):
            image = QImage(pixel_size, pixel_size, QImage.Format.Format_ARGB32_Premultiplied)
            image.setDevicePixelRatio(dpr)
            image.fill(Qt.transparent)
            painter = QPainter(image)
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(color), width))
            if direction:
                path = QPainterPath()
                path.moveTo(position + QPointF(direction * 7.65, 0))
                path.lineTo(position + QPointF(-direction * 5.44, -4.76))
                path.lineTo(position + QPointF(-direction * 5.44, 4.76))
                path.closeSubpath()
                painter.drawPath(path)
            else:
                painter.drawEllipse(position, radius, radius)
            painter.end()
            images.append(QPixmap.fromImage(image))
        sprites = (images[0], images[1], center)
        self._sample_marker_sprites[key] = sprites
        while len(self._sample_marker_sprites) > 32:
            self._sample_marker_sprites.popitem(last=False)
        return sprites

    def _draw_dense_sample_overlays(self, painter, tile, selected, x, y):
        # Blit a few tiny antialiased marker shapes instead of repeatedly
        # stroking thousands of overlapping curves. No selected point is lost.
        # Two passes keep later white halos from erasing earlier yellow rings.
        index = tile.payload.index
        dpr = tile.payload.image.devicePixelRatio()
        painter.save()
        for color_pass in (0, 1):
            for record_index in selected:
                record = index.records[record_index]
                point = index.point_at(int(record_index))
                direction = _sample_marker_direction(point.value, tile.payload.minimum, tile.payload.maximum)
                radius = max(5.5, float(record["radius"]) + 3.2)
                sprites = self._sample_sprite(dpr, direction, radius)
                position = QPointF(float(record["x"]) + x - sprites[2], float(record["y"]) + y - sprites[2])
                painter.drawPixmap(position, sprites[color_pass])
        painter.restore()

    def _hit(self, position):
        x = self.MARGIN - self.horizontalScrollBar().value()
        scroll = self.verticalScrollBar().value()
        logical_y = position.y() + scroll
        if self._groups:
            index = max(0, bisect_right(self._tops, scroll) - 1)
            group = self._groups[index]
            end = self._tops[index] + self.HEADER_HEIGHT + len(group.lane_indices) * self._lane_height
            if self._tops[index] < scroll < end and position.y() < min(self.HEADER_HEIGHT, end - scroll):
                return None
        desired = self._specs(False)
        displayed = {spec.group.group_index: spec.key.axis for spec in self._display_specs(desired)}
        for spec in desired:
            if not spec.top <= logical_y < spec.top + len(spec.key.lanes) * self._lane_height:
                continue
            if displayed.get(spec.group.group_index) != spec.key.axis:
                return None
            tile = self._cache.get(spec.key)
            if tile is None:
                return None
            local = QPointF(position.x() - x, logical_y - spec.top)
            best = tile.payload.index.hit_test(local.x(), local.y())
            return (spec, best) if best is not None else None
        return None

    def _point_at(self, position):
        hit = self._hit(position)
        return (hit[0].group.group_index, hit[1].point) if hit else None

    def mousePressEvent(self, event):
        self._remember_pointer(event)
        if event.button() == Qt.LeftButton and self._pan_modifier_held(event.modifiers()):
            geometry = self._axis_geometry(event.position(), body_only=True)
            if geometry is not None:
                group, left, right = geometry
                bounds = self._zoom_pending.get(group.group_index) or self.metric_range(group.group_index)
                if (bounds is not None and all(isfinite(value) for value in bounds)
                        and isfinite(bounds[1] - bounds[0]) and bounds[1] > bounds[0]):
                    self._pan_drag = _PanDrag(group.group_index, QPointF(event.position()), bounds, right - left)
                    self._native_zoom_position = None
                    self._clear_hover()
                    self._refresh_cursor()
                    event.accept()
                    return
        self._refresh_cursor()
        super().mousePressEvent(event)

    def _move_pan(self, position):
        drag = self._pan_drag
        if drag is None:
            return
        dx = position.x() - drag.origin.x()
        if not isfinite(dx) or not drag.started and abs(dx) < QApplication.startDragDistance():
            return
        low, high = drag.bounds
        span = high - low
        offset = -(dx / drag.width) * span
        bounds = (low + offset, high + offset)
        new_span = bounds[1] - bounds[0]
        if (not all(isfinite(value) for value in bounds) or new_span <= 0
                or abs(new_span - span) > max(ulp(span) * 16, span * 1e-10)):
            return
        drag.started = True
        if bounds != (self._zoom_pending.get(drag.group_index) or self.metric_range(drag.group_index)):
            self._zoom_pending[drag.group_index] = bounds
            if not self._zoom_timer.isActive():
                self._zoom_timer.start(self.ZOOM_DELAY_MS)

    def mouseReleaseEvent(self, event):
        self._remember_pointer(event)
        if event.button() == Qt.LeftButton and self._pan_drag is not None:
            if self._pan_modifier_held(event.modifiers()):
                self._move_pan(event.position())
            self._cancel_pan()
            self._zoom_timer.stop()
            self._flush_zoom_requests()
            event.accept()
            return
        self._refresh_cursor()
        super().mouseReleaseEvent(event)

    def mouseMoveEvent(self, event):
        self._remember_pointer(event)
        if self._pan_drag is not None:
            if event.buttons() & Qt.LeftButton and self._pan_modifier_held(event.modifiers()):
                self._move_pan(event.position())
                self._refresh_cursor()
                event.accept()
                return
            # A popup or OS gesture can consume the release event.
            self._cancel_pan()
        self._refresh_cursor()
        if event.modifiers() & self._zoom_modifiers():
            self._clear_hover()
            event.accept()
            return
        hit = self._hit(event.position())
        if hit is None:
            self._clear_hover()
        else:
            spec, item = hit
            keys = frozenset(item.point.merge_outlier_keys)
            if keys != self._hover_keys or self._hover_group != spec.group.group_index:
                self._hover_keys, self._hover_group = keys, spec.group.group_index
                self.viewport().update()
            QToolTip.showText(event.globalPosition().toPoint(), _tooltip(item.point), self.viewport())
        super().mouseMoveEvent(event)

    def _clear_hover(self):
        changed = bool(self._hover_keys)
        self._hover_keys = frozenset()
        self._hover_group = None
        QToolTip.hideText()
        if changed:
            self.viewport().update()

    def leaveEvent(self, event):
        self._pointer_inside = False
        self._refresh_cursor()
        self._clear_hover()
        super().leaveEvent(event)

    def mouseDoubleClickEvent(self, event):
        self._cancel_pan()
        hit = self._hit(event.position())
        if hit is not None:
            spec, item = hit
            tile = self._cache.get(spec.key)
            bounds = ((tile.payload.minimum, tile.payload.maximum) if tile is not None
                      else self.metric_range(spec.group.group_index))
            value = item.point.value
            if bounds and not bounds[0] <= value <= bounds[1]:
                low, high = bounds
                # A triangle represents the compressed side, so expand every
                # source lane on that side while leaving the other bound fixed.
                if value < low:
                    low = min(low, min(point.value for lane in spec.group.series for point in lane.points))
                    low -= max(high - low, abs(low) * .01, 1e-9) * .06
                else:
                    high = max(high, max(point.value for lane in spec.group.series for point in lane.points))
                    high += max(high - low, abs(high) * .01, 1e-9) * .06
                pinned = self._pinned.get(spec.group.group_index, _point_key(item.point))
                self.set_metric_range(spec.group.group_index, (low, high), pinned)
                event.accept()
                return
        logical_y = event.position().y() + self.verticalScrollBar().value()
        if self._groups:
            index = max(0, bisect_right(self._tops, logical_y) - 1)
            self.set_metric_range(self._groups[index].group_index)
        event.accept()


def _sample_marker_direction(value, minimum, maximum):
    """Return the triangle orientation of the actual cached image, or a circle."""
    return -1 if value < minimum else 1 if value > maximum else 0


def _point_key(point):
    return point.dataset_id, point.source_file, point.row_number, point.raw_column


def _merge_key(point):
    return point.dataset_id, point.row_number, point.raw_column


def _optional(value):
    return "" if value is None else f"{value:.6g}"


def _tooltip(point: PlotPoint):
    dimensions = [f"{key}: {value}" for key, value in sorted(point.dimensions.items()) if value]
    reference = ""
    if point.golden_center is not None or point.golden_lower_bound is not None or point.golden_upper_bound is not None:
        ranges = ", ".join(f"{_optional(low)} - {_optional(high)}" for low, high in point.golden_allowed_ranges)
        ranges = ranges or f"{_optional(point.golden_lower_bound)} - {_optional(point.golden_upper_bound)}"
        reference = f"\ngolden center: {_optional(point.golden_center)}\ngolden range: {ranges}"
    merged = "not a raw outlier" if not point.outlier else "merged outlier" if point.merged_outlier else "raw outlier only" if point.merge_block_key else "not evaluated"
    return (f"{point.metric}\n{point.sample_id}\nvalue: {point.value:.6g}\nraw_column: {point.raw_column}\n"
            f"logical_metric: {point.logical_metric}\nmerged_outlier_block: {merged}\nz_score: {_optional(point.z_score)}"
            f"{reference}\ndataset_id: {point.dataset_id}\nrow_number: {point.row_number}\n"
            f"outlier: {'yes' if point.outlier else 'no'}\n" + "\n".join(dimensions))
