from __future__ import annotations

from collections import defaultdict
from functools import lru_cache
import json
from pathlib import Path
import re
import shutil
from typing import Any, Iterable

from .field_names import COLUMN_FILTER_ALIASES, FieldNames, row_fields, column_filter_fields

from .analyzer import (
    build_golden_reference,
    summarize_golden_coverage,
)
from .debug_bundle import export_debug_bundle
from .io import build_measurements, load_table
from .models import (
    AnomalyResult,
    GoldenAllowedRange,
    GoldenMetricRange,
    GoldenReference,
    GoldenRuleConfig,
    MeasurementRecord,
)
from .reporting import (
    collect_outlier_summary_rows_from_measurements,
    collect_outlier_ratio_rows,
    collect_outlier_ratio_rows_from_measurements,
    collect_outlier_summary_artifacts,
    collect_outlier_summary_artifacts_from_measurements,
    collect_outlier_summary_rows,
    collect_report_failures,
    generate_chip_report_from_measurements,
    generate_chip_report,
)
from .repository import Repository
from .compact_analysis import ColumnarMeasurements
from .template import load_template
from .workspace import (
    clear_database_root,
    database_workspace_path,
    delete_database_workspace,
    database_workspace_differs,
    ensure_database_workspace,
    merge_database_workspace,
    reset_database_workspace,
    save_database_workspace_as,
)

MAX_TEMPLATE_GROUP_MISMATCH_EXAMPLES = 10

REPEAT_DIMENSION_NAME = "repeat_id"
SAMPLE_KEY_FILTER = "__sample_key__"

NATURAL_SORT_SPLIT_RE = re.compile(r"(\d+)")


@lru_cache(maxsize=8192)
def _natural_sort_key_cached(value: str) -> tuple[Any, ...]:
    parts = NATURAL_SORT_SPLIT_RE.split(value)
    key: list[Any] = []
    for part in parts:
        if not part:
            continue
        if part.isdigit():
            key.append((0, int(part)))
        else:
            key.append((1, part.lower()))
    return tuple(key)


def _natural_sort_key(value: Any) -> tuple[Any, ...]:
    return _natural_sort_key_cached(str(value or ""))


def _emit_progress(
    callback: Any | None,
    value: int,
    message: str,
) -> None:
    if callback is None:
        return
    callback(value, message)


def import_dataset(
    template_path: str,
    input_path: str,
    storage_path: str,
    conflict_mode: str = "error",
    progress_callback: Any | None = None,
) -> dict:
    if conflict_mode not in {"error", "replace", "append"}:
        raise ValueError(
            f"Unsupported conflict_mode: {conflict_mode}. Expected error, replace, or append."
        )
    _emit_progress(progress_callback, 5, "Loading template...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 20, "Reading input workbook...")
    table = load_table(input_path, template=template)
    repository = Repository(storage_path)
    dataset_id = repository.new_dataset_id()
    _emit_progress(progress_callback, 40, "Building measurement records...")
    incoming_measurements = build_measurements(
        template=template,
        rows=table.rows,
        dataset_id=dataset_id,
        source_file=str(Path(input_path).resolve()),
    )
    _emit_progress(progress_callback, 60, "Comparing with existing database rows...")
    existing_measurements = repository.load_measurements()
    preview = _build_import_preview(existing_measurements, incoming_measurements)

    if preview["conflict_row_count"] and conflict_mode == "error":
        raise ValueError(_format_import_conflict_message(preview))

    final_measurements = incoming_measurements
    removed_measurements = 0
    repeat_shifted_rows = 0

    if conflict_mode == "replace" and preview["conflict_row_count"]:
        _emit_progress(progress_callback, 80, "Replacing existing conflicting rows...")
        filtered_existing = [
            item
            for item in existing_measurements
            if _row_identity_key(item.dimensions) not in preview["conflict_keys"]
        ]
        removed_measurements = len(existing_measurements) - len(filtered_existing)
        repository.replace_measurements([*filtered_existing, *final_measurements])
        repository.save_dataset_entry(
            _build_dataset_payload(
                dataset_id=dataset_id,
                source_file=str(Path(input_path).resolve()),
                template_name=template.name,
                measurement_count=len(final_measurements),
                metadata={
                    "conflict_mode": "replace",
                    "removed_measurements": removed_measurements,
                    "removed_row_count": preview["existing_conflict_row_count"],
                    "imported_row_count": preview["incoming_row_count"],
                    "conflict_row_count": preview["conflict_row_count"],
                },
            )
        )
        repository.reconcile_dataset_entries()
    elif conflict_mode == "append" and preview["conflict_row_count"]:
        _emit_progress(progress_callback, 80, "Appending rows and shifting repeat index...")
        final_measurements, repeat_shifted_rows = _append_with_shifted_repeats(
            existing_measurements,
            incoming_measurements,
        )
        repository.save_import(
            dataset_id=dataset_id,
            source_file=str(Path(input_path).resolve()),
            template_name=template.name,
            measurements=final_measurements,
            metadata={
                "conflict_mode": "append",
                "shifted_repeat_row_count": repeat_shifted_rows,
                "imported_row_count": preview["incoming_row_count"],
                "conflict_row_count": preview["conflict_row_count"],
            },
        )
    else:
        _emit_progress(progress_callback, 80, "Writing imported rows into current database...")
        repository.save_import(
            dataset_id=dataset_id,
            source_file=str(Path(input_path).resolve()),
            template_name=template.name,
            measurements=final_measurements,
            metadata={
                "conflict_mode": "none" if preview["conflict_row_count"] == 0 else conflict_mode,
                "imported_row_count": preview["incoming_row_count"],
                "conflict_row_count": preview["conflict_row_count"],
            },
        )
    _emit_progress(progress_callback, 100, "Import completed.")
    storage_summary = describe_storage(storage_path, template_path=template_path, limit=20)

    return {
        "dataset_id": dataset_id,
        "template": template.name,
        "imported_measurements": len(final_measurements),
        "imported_rows": preview["incoming_row_count"],
        "preview": {
            "existing_measurements": preview["existing_measurement_count"],
            "incoming_measurements": preview["incoming_measurement_count"],
            "existing_rows": preview["existing_row_count"],
            "incoming_rows": preview["incoming_row_count"],
        },
        "conflict_mode": conflict_mode,
        "conflict_rows": preview["conflict_row_count"],
        "existing_conflict_rows": preview["existing_conflict_row_count"],
        "shifted_repeat_rows": repeat_shifted_rows,
        "removed_measurements": removed_measurements,
        "storage": str(Path(storage_path).resolve()),
        "storage_summary": {
            "dataset_count": storage_summary["dataset_count"],
            "measurement_count": storage_summary["measurement_count"],
            "row_count": storage_summary["row_count"],
            "import_history_count": storage_summary["import_history_count"],
        },
    }


def preview_import(
    template_path: str,
    input_path: str,
    storage_path: str,
) -> dict[str, Any]:
    template = load_template(template_path)
    table = load_table(input_path, template=template)
    repository = Repository(storage_path)
    dataset_id = repository.new_dataset_id()
    incoming_measurements = build_measurements(
        template=template,
        rows=table.rows,
        dataset_id=dataset_id,
        source_file=str(Path(input_path).resolve()),
    )
    return _build_import_preview(repository.load_measurements(), incoming_measurements)


def describe_storage(
    storage_path: str,
    template_path: str | None = None,
    limit: int = 500,
) -> dict[str, Any]:
    repository = Repository(storage_path)
    measurements = repository.load_measurements()
    dataset_entries = repository.load_dataset_entries()
    ordered_dimensions = _resolve_dimension_order(template_path, measurements)
    rows = list(_collect_row_records(measurements).values())
    rows.sort(
        key=lambda item: tuple(
            _natural_sort_key(item["dimensions"].get(name, ""))
            for name in ordered_dimensions
        )
    )
    snapshot_rows: list[dict[str, Any]] = []
    grouped_rows: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for item in rows:
        payload = {name: item["dimensions"].get(name, "") for name in ordered_dimensions}
        payload["measurement_count"] = item["measurement_count"]
        payload["dataset_id"] = item["dataset_id"]
        payload["source_file"] = item["source_file"]
        payload["row_number"] = item["row_number"]
        snapshot_rows.append(payload)
        grouped_rows[(item["dataset_id"], item["source_file"])].append(payload)
    entries_by_id = {entry["dataset_id"]: entry for entry in dataset_entries}
    imports = []
    for (dataset_id, source_file), batch_rows in grouped_rows.items():
        entry = entries_by_id.get(dataset_id, {})
        imports.append({
            "dataset_id": dataset_id,
            "source_file": source_file,
            "template_name": entry.get("template_name", ""),
            "created_at_utc": entry.get("created_at_utc", ""),
            **_storage_snapshot_view(batch_rows, ordered_dimensions, limit),
        })
    return {
        "storage": str(Path(storage_path).resolve()),
        "dataset_count": len({item.dataset_id for item in measurements}),
        "dimensions": ordered_dimensions,
        **_storage_snapshot_view(snapshot_rows, ordered_dimensions, limit),
        "imports": imports,
        "import_history_count": len(dataset_entries),
    }


def _storage_snapshot_view(rows: list[dict[str, Any]], dimensions: list[str], limit: int) -> dict[str, Any]:
    # Determine shared values over the entire view, never just the first page.
    # A differing value beyond the preview limit must keep its column visible.
    shared = {}
    if rows:
        for name in [*dimensions, "measurement_count"]:
            value = rows[0].get(name, "")
            if all(item.get(name, "") == value for item in rows):
                shared[name] = value
    return {
        "rows": rows[:limit],
        "row_count": len(rows),
        "measurement_count": sum(item["measurement_count"] for item in rows),
        "common_values": shared,
        "truncated": len(rows) > limit,
    }


def list_import_history(storage_path: str) -> list[dict[str, Any]]:
    repository = Repository(storage_path)
    entries = repository.load_dataset_entries()
    return sorted(
        entries,
        key=lambda item: (
            str(item.get("created_at_utc", "")),
            str(item.get("dataset_id", "")),
        ),
        reverse=True,
    )


def copy_storage(
    source_storage_path: str,
    target_storage_path: str,
    if_exists: str = "overwrite",
) -> dict[str, Any]:
    source = Path(source_storage_path)
    if not source.exists() or not source.is_dir():
        raise ValueError(f"Source database folder does not exist: {source}")
    from .output_paths import prepare_output_directory

    destination = prepare_output_directory(target_storage_path, if_exists=if_exists)
    shutil.copytree(source, destination, dirs_exist_ok=True)
    return {
        "source": str(source.resolve()),
        "destination": str(destination.resolve()),
    }


def ensure_storage_workspace(
    storage_root_path: str,
) -> dict[str, Any]:
    workspace = ensure_database_workspace(storage_root_path)
    return {
        "database_root": str(Path(storage_root_path).resolve()),
        "workspace": str(workspace.resolve()),
    }


def storage_workspace_differs(
    storage_root_path: str,
) -> dict[str, Any]:
    return {
        "database_root": str(Path(storage_root_path).resolve()),
        "workspace": str(ensure_database_workspace(storage_root_path).resolve()),
        "differs": database_workspace_differs(storage_root_path),
    }


def discard_storage_workspace_changes(
    storage_root_path: str,
) -> dict[str, Any]:
    workspace = reset_database_workspace(storage_root_path)
    return {
        "database_root": str(Path(storage_root_path).resolve()),
        "workspace": str(workspace.resolve()),
    }


def save_storage_workspace(
    storage_root_path: str,
) -> dict[str, Any]:
    workspace = merge_database_workspace(storage_root_path)
    return {
        "database_root": str(Path(storage_root_path).resolve()),
        "workspace": str(workspace.resolve()),
    }


def delete_storage_workspace(
    storage_root_path: str,
) -> dict[str, Any]:
    cleared_root = delete_database_workspace(storage_root_path)
    return {
        "database_root": str(Path(storage_root_path).resolve()),
        "workspace": str(database_workspace_path(cleared_root).resolve()),
    }


def save_storage_workspace_as(
    storage_root_path: str,
    target_storage_root_path: str,
) -> dict[str, Any]:
    target_root, target_workspace = save_database_workspace_as(
        storage_root_path,
        target_storage_root_path,
    )
    return {
        "source_database_root": str(Path(storage_root_path).resolve()),
        "target_database_root": str(target_root.resolve()),
        "target_workspace": str(target_workspace.resolve()),
    }


def clear_storage_root(
    storage_root_path: str,
) -> dict[str, Any]:
    cleared_root = clear_database_root(storage_root_path)
    return {
        "database_root": str(cleared_root.resolve()),
    }


def delete_storage_rows(
    storage_path: str,
    row_selectors: list[dict[str, Any]],
) -> dict[str, Any]:
    normalized_selectors = [
        (
            str(item.get("dataset_id", "")).strip(),
            str(item.get("source_file", "")).strip(),
            int(item.get("row_number")),
        )
        for item in row_selectors
        if str(item.get("dataset_id", "")).strip()
        and str(item.get("source_file", "")).strip()
        and item.get("row_number") is not None
    ]
    repository = Repository(storage_path)
    existing_rows = _collect_row_records(repository.load_measurements())
    existing_row_keys = set(existing_rows.keys())
    matched_row_keys = {
        (dataset_id, source_file, row_number)
        for dataset_id, source_file, row_number in normalized_selectors
        if (dataset_id, source_file, row_number) in existing_row_keys
    }
    deleted_measurement_count = repository.delete_measurements(normalized_selectors)
    return {
        "storage": str(Path(storage_path).resolve()),
        "deleted_row_count": len(matched_row_keys),
        "deleted_measurement_count": deleted_measurement_count,
    }


def delete_storage_import(
    storage_path: str,
    dataset_id: str,
    source_file: str,
) -> dict[str, Any]:
    """Delete one complete import without loading the database into memory."""
    if not storage_path or not storage_path.strip():
        raise ValueError("Database Folder is required.")
    if not dataset_id or not dataset_id.strip() or not source_file or not source_file.strip():
        raise ValueError("A specific import ID and source file are required.")
    repository = Repository(storage_path)
    deleted_rows: set[int] = set()
    deleted_measurement_count = 0

    def remaining_measurements():
        nonlocal deleted_measurement_count
        for item in repository.iter_measurements():
            if (item.dataset_id, item.source_file) == (dataset_id, source_file):
                deleted_rows.add(item.row_number)
                deleted_measurement_count += 1
            else:
                yield item

    # Storage writes a temporary file before replacing the original, then
    # reconciles the import history with the remaining measurements.
    repository.replace_measurements(remaining_measurements())
    return {
        "storage": str(Path(storage_path).resolve()),
        "dataset_id": dataset_id,
        "source_file": source_file,
        "deleted_row_count": len(deleted_rows),
        "deleted_measurement_count": deleted_measurement_count,
    }


def save_debug_bundle(
    bundle_path: str,
    gui_settings: dict[str, Any],
    current_results: dict[str, Any],
    log_text: str,
    template_path: str | None = None,
    input_path: str | None = None,
    storage_path: str | None = None,
    golden_path: str | None = None,
    output_path: str | None = None,
    if_exists: str = "overwrite",
) -> dict[str, Any]:
    storage_summary = None
    import_history = None
    resolved_template_path = template_path if template_path and Path(template_path).exists() else None
    if storage_path and Path(storage_path).exists():
        storage_summary = describe_storage(
            storage_path,
            template_path=resolved_template_path,
            limit=500,
        )
        import_history = list_import_history(storage_path)
    return export_debug_bundle(
        bundle_path=bundle_path,
        gui_settings=gui_settings,
        current_results=current_results,
        log_text=log_text,
        template_path=template_path,
        input_path=input_path,
        storage_path=storage_path,
        golden_path=golden_path,
        output_path=output_path,
        storage_summary=storage_summary,
        import_history=import_history,
        if_exists=if_exists,
    )


def generate_report(
    template_path: str,
    input_path: str,
    output_path: str,
    built_golden_path: str | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    column_filters: dict[str, dict[str, list[str]]] | None = None,
    if_exists: str = "overwrite",
    progress_callback: Any | None = None,
) -> dict:
    if dimension_filters or column_filters:
        _emit_progress(progress_callback, 5, "Loading template...")
        template = load_template(template_path)
        _emit_progress(progress_callback, 15, "Reading input workbook...")
        table = load_table(input_path, template=template)
        _emit_progress(progress_callback, 25, "Building filtered measurement scope...")
        measurements = build_measurements(
            template=template,
            rows=table.rows,
            dataset_id="ad-hoc-report",
            source_file=str(Path(input_path).resolve()),
        )
        filtered_measurements = _filter_measurements(
            measurements,
            dimension_filters=dimension_filters,
            column_filters=column_filters,
            template=template,
        )
        if not filtered_measurements:
            raise ValueError("Current analysis scope does not contain any measurement data.")
        return generate_chip_report_from_measurements(
            template_path=template_path,
            measurements=filtered_measurements,
            output_path=output_path,
            built_golden_path=built_golden_path,
            outlier_fail_method_override=outlier_fail_method_override,
            outlier_merge_order_override=outlier_merge_order_override,
            outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
            zscore_threshold_override=zscore_threshold_override,
            source_label=str(Path(input_path).resolve()),
            if_exists=if_exists,
            progress_callback=progress_callback,
        )
    return generate_chip_report(
        template_path,
        input_path,
        output_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        outlier_merge_order_override=outlier_merge_order_override,
        outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
        zscore_threshold_override=zscore_threshold_override,
        if_exists=if_exists,
        progress_callback=progress_callback,
    )


def generate_report_from_storage(
    template_path: str,
    storage_path: str,
    output_path: str,
    built_golden_path: str | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    dataset_ids: list[str] | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    column_filters: dict[str, dict[str, list[str]]] | None = None,
    if_exists: str = "overwrite",
    progress_callback: Any | None = None,
    include_summary_artifacts: bool = False,
) -> dict[str, Any]:
    repository = Repository(storage_path)
    template = load_template(template_path) if column_filters else None
    _emit_progress(progress_callback, 10, "Loading measurements from current database...")
    measurements = _filter_measurements(
        repository.iter_measurements(),
        dataset_ids=dataset_ids,
        dimension_filters=dimension_filters,
        column_filters=column_filters,
        template=template,
        compact=True,
    )
    if not measurements:
        raise ValueError("Current database scope does not contain any measurement data.")
    return generate_chip_report_from_measurements(
        template_path=template_path,
        measurements=measurements,
        output_path=output_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        outlier_merge_order_override=outlier_merge_order_override,
        outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
        zscore_threshold_override=zscore_threshold_override,
        source_label=str(Path(storage_path).resolve()),
        if_exists=if_exists,
        progress_callback=progress_callback,
        include_summary_artifacts=include_summary_artifacts,
    )


def analyze_report_failures(
    template_path: str,
    input_path: str,
    built_golden_path: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[AnomalyResult]:
    return collect_report_failures(
        template_path,
        input_path,
        built_golden_path=built_golden_path,
        zscore_threshold_override=zscore_threshold_override,
    )


def analyze_report_outlier_summary(
    template_path: str,
    input_path: str,
    built_golden_path: str | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, str]]:
    return collect_outlier_summary_rows(
        template_path,
        input_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )


def analyze_report_outlier_summary_artifacts(
    template_path: str,
    input_path: str,
    built_golden_path: str | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    column_filters: dict[str, dict[str, list[str]]] | None = None,
    progress_callback: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    if dimension_filters or column_filters:
        _emit_progress(progress_callback, 5, "Loading template for outlier summary...")
        template = load_template(template_path)
        _emit_progress(progress_callback, 20, "Reading input workbook for outlier summary...")
        table = load_table(input_path, template=template)
        _emit_progress(progress_callback, 35, "Building filtered measurement scope for outlier summary...")
        measurements = build_measurements(
            template=template,
            rows=table.rows,
            dataset_id="ad-hoc-report",
            source_file=str(Path(input_path).resolve()),
        )
        filtered_measurements = _filter_measurements(
            measurements,
            dimension_filters=dimension_filters,
            column_filters=column_filters,
            template=template,
        )
        if not filtered_measurements:
            return {"summary_rows": [], "ratio_rows": []}
        return collect_outlier_summary_artifacts_from_measurements(
            template_path=template_path,
            measurements=filtered_measurements,
            built_golden_path=built_golden_path,
            outlier_fail_method_override=outlier_fail_method_override,
            outlier_merge_order_override=outlier_merge_order_override,
            outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
            zscore_threshold_override=zscore_threshold_override,
            progress_callback=progress_callback,
        )
    return collect_outlier_summary_artifacts(
        template_path,
        input_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        outlier_merge_order_override=outlier_merge_order_override,
        outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def analyze_report_outlier_ratios(
    template_path: str,
    input_path: str,
    built_golden_path: str | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, Any]]:
    return collect_outlier_ratio_rows(
        template_path,
        input_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )


def analyze_report_outlier_summary_from_storage(
    template_path: str,
    storage_path: str,
    built_golden_path: str | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
    dataset_ids: list[str] | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
) -> list[dict[str, str]]:
    repository = Repository(storage_path)
    measurements = _filter_measurements(
        repository.load_measurements(),
        dataset_ids=dataset_ids,
        dimension_filters=dimension_filters,
    )
    if not measurements:
        return []
    return collect_outlier_summary_rows_from_measurements(
        template_path=template_path,
        measurements=measurements,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )


def analyze_report_outlier_summary_artifacts_from_storage(
    template_path: str,
    storage_path: str,
    built_golden_path: str | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    dataset_ids: list[str] | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    column_filters: dict[str, dict[str, list[str]]] | None = None,
    progress_callback: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    repository = Repository(storage_path)
    template = load_template(template_path) if column_filters else None
    _emit_progress(progress_callback, 10, "Loading measurements from current database for outlier summary...")
    measurements = _filter_measurements(
        repository.load_measurements(),
        dataset_ids=dataset_ids,
        dimension_filters=dimension_filters,
        column_filters=column_filters,
        template=template,
    )
    if not measurements:
        return {"summary_rows": [], "ratio_rows": []}
    return collect_outlier_summary_artifacts_from_measurements(
        template_path=template_path,
        measurements=measurements,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        outlier_merge_order_override=outlier_merge_order_override,
        outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def analyze_report_outlier_ratios_from_storage(
    template_path: str,
    storage_path: str,
    built_golden_path: str | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
    dataset_ids: list[str] | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
) -> list[dict[str, Any]]:
    repository = Repository(storage_path)
    measurements = _filter_measurements(
        repository.load_measurements(),
        dataset_ids=dataset_ids,
        dimension_filters=dimension_filters,
    )
    if not measurements:
        return []
    return collect_outlier_ratio_rows_from_measurements(
        template_path=template_path,
        measurements=measurements,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )


def summarize_built_golden_coverage_for_input(
    template_path: str,
    input_path: str,
    golden_path: str,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    column_filters: dict[str, dict[str, list[str]]] | None = None,
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    _emit_progress(progress_callback, 10, "Loading template for built golden coverage...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 25, "Reading input workbook for built golden coverage...")
    table = load_table(input_path, template=template)
    _emit_progress(progress_callback, 45, "Building measurement scope for built golden coverage...")
    measurements = build_measurements(
        template=template,
        rows=table.rows,
        dataset_id="coverage-preview",
        source_file=str(Path(input_path).resolve()),
    )
    measurements = _filter_measurements(
        measurements,
        dimension_filters=dimension_filters,
        column_filters=column_filters,
        template=template,
    )
    _emit_progress(progress_callback, 70, "Loading built golden file...")
    golden = GoldenReference.from_dict(
        json.loads(Path(golden_path).read_text(encoding="utf-8"))
    )
    _emit_progress(progress_callback, 90, "Matching measurements against built golden...")
    payload = summarize_golden_coverage(measurements, golden)
    payload.update(
        {
            "scope": "current_input_file",
            "input": str(Path(input_path).resolve()),
            "golden": str(Path(golden_path).resolve()),
        }
    )
    return payload


def summarize_built_golden_coverage_for_storage(
    storage_path: str,
    golden_path: str,
    dataset_ids: list[str] | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    column_filters: dict[str, dict[str, list[str]]] | None = None,
    template_path: str | None = None,
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    repository = Repository(storage_path)
    template = load_template(template_path) if column_filters and template_path else None
    _emit_progress(progress_callback, 20, "Loading measurements from current database for built golden coverage...")
    measurements = _filter_measurements(
        repository.load_measurements(),
        dataset_ids=dataset_ids,
        dimension_filters=dimension_filters,
        column_filters=column_filters,
        template=template,
    )
    _emit_progress(progress_callback, 70, "Loading built golden file...")
    golden = repository.load_golden(golden_path)
    _emit_progress(progress_callback, 90, "Matching measurements against built golden...")
    payload = summarize_golden_coverage(measurements, golden)
    payload.update(
        {
            "scope": "database",
            "storage": str(Path(storage_path).resolve()),
            "golden": str(Path(golden_path).resolve()),
        }
    )
    return payload


def create_golden_reference(
    storage_path: str,
    name: str,
    reference_dimensions: list[str],
    filters: dict[str, str],
    center_method: str,
    outlier_golden_method: str,
    relative_limit: float | None,
    sigma_multiplier: float | None,
    absolute_lower_bound: float | None,
    absolute_upper_bound: float | None,
    overwrite_lowerbound: float | None,
    overwrite_upperbound: float | None,
    continuous_interval: bool,
    empty_range_fallback_to_absolute: bool = False,
    template_path: str | None = None,
    analysis_group_conflict_mode: str = "error",
    if_exists: str = "overwrite",
    progress_callback: Any | None = None,
) -> tuple[GoldenReference, str]:
    repository = Repository(storage_path)
    _emit_progress(progress_callback, 15, "Loading measurements from current database...")
    measurements = repository.load_measurements()
    group_rule_overrides: dict[str, GoldenRuleConfig] = {}
    if template_path:
        template = load_template(
            template_path,
            analysis_group_conflict_mode=analysis_group_conflict_mode,
        )
        fields = row_fields(template)
        reference_dimensions = [fields.resolve(name) for name in reference_dimensions]
        filters = fields.mapping(filters)
        _validate_measurement_groups_match_template(measurements, template)
        for group in template.analysis_groups:
            if not group.outlier_golden_method:
                continue
            group_rule_overrides[group.id] = GoldenRuleConfig(
                outlier_golden_method=group.outlier_golden_method,
                relative_limit=group.golden_relative_limit,
                sigma_multiplier=group.golden_sigma_multiplier,
                absolute_lower_bound=group.golden_absolute_lower_bound,
                absolute_upper_bound=group.golden_absolute_upper_bound,
                overwrite_lowerbound=group.golden_overwrite_lowerbound,
                overwrite_upperbound=group.golden_overwrite_upperbound,
                continuous_interval=group.golden_continuous_interval,
                empty_range_fallback_to_absolute=(
                    group.golden_empty_range_fallback_to_absolute
                    if group.golden_empty_range_fallback_to_absolute is not None
                    else empty_range_fallback_to_absolute
                ),
            )
    _emit_progress(progress_callback, 65, "Building golden reference...")
    reference = build_golden_reference(
        name=name,
        measurements=measurements,
        reference_dimensions=reference_dimensions,
        filters=filters,
        center_method=center_method,
        outlier_golden_method=outlier_golden_method,
        relative_limit=relative_limit,
        sigma_multiplier=sigma_multiplier,
        absolute_lower_bound=absolute_lower_bound,
        absolute_upper_bound=absolute_upper_bound,
        overwrite_lowerbound=overwrite_lowerbound,
        overwrite_upperbound=overwrite_upperbound,
        continuous_interval=continuous_interval,
        empty_range_fallback_to_absolute=empty_range_fallback_to_absolute,
        group_rule_overrides=group_rule_overrides,
    )
    _emit_progress(progress_callback, 90, "Saving golden reference file...")
    path = repository.save_golden(reference, if_exists=if_exists)
    _export_golden_reference_excel(
        reference,
        measurements,
        Path(path).with_suffix(".xlsx"),
    )
    _emit_progress(progress_callback, 100, "Golden reference created.")
    return reference, str(path.resolve())


def _export_golden_reference_excel(
    reference: GoldenReference,
    measurements: list[MeasurementRecord],
    output_path: Path,
) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError as exc:  # pragma: no cover - dependency is required by packaging
        raise RuntimeError(
            "Writing built golden Excel requires openpyxl. Run `pip3 install -e .` first."
        ) from exc

    max_allowed_ranges = max(
        (
            len(_metric_allowed_ranges_for_excel(metric))
            for metric in reference.metrics
        ),
        default=0,
    )
    reference_key_headers = [
        f"reference_key.{dimension}" for dimension in reference.reference_dimensions
    ]
    metric_headers = [
        "sample_size",
        "center",
        "stdev",
        "lower_bound",
        "upper_bound",
        "outlier_golden_method",
        "relative_limit",
        "sigma_multiplier",
        "absolute_lower_bound",
        "absolute_upper_bound",
        "overwrite_lowerbound",
        "overwrite_upperbound",
        "continuous_interval",
        "empty_range_fallback_used",
        "empty_range_fallback_reason",
    ]
    allowed_range_headers = [
        f"allowed_range_{index}_{field}"
        for index in range(1, max_allowed_ranges + 1)
        for field in ("lower_bound", "upper_bound")
    ]
    headers = [
        "column name",
        "logic metric",
        *reference_key_headers,
        *metric_headers,
        *allowed_range_headers,
    ]

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Golden Reference"
    worksheet.append(headers)

    raw_columns_by_metric_key = _build_golden_raw_column_lookup(reference, measurements)
    for metric in reference.metrics:
        reference_key = tuple(
            (dimension, metric.reference_key.get(dimension, ""))
            for dimension in reference.reference_dimensions
        )
        raw_columns = raw_columns_by_metric_key.get(
            (reference_key, metric.logical_metric),
            [""],
        )
        allowed_ranges = _metric_allowed_ranges_for_excel(metric)
        for raw_column in raw_columns:
            row = [
                raw_column,
                metric.logical_metric,
                *(
                    metric.reference_key.get(dimension, "")
                    for dimension in reference.reference_dimensions
                ),
                metric.sample_size,
                metric.center,
                metric.stdev,
                metric.lower_bound,
                metric.upper_bound,
                metric.outlier_golden_method,
                metric.relative_limit,
                metric.sigma_multiplier,
                metric.absolute_lower_bound,
                metric.absolute_upper_bound,
                metric.overwrite_lowerbound,
                metric.overwrite_upperbound,
                bool(metric.continuous_interval),
                bool(metric.empty_range_fallback_used),
                metric.empty_range_fallback_reason,
            ]
            for allowed_range in allowed_ranges:
                row.extend([allowed_range.lower_bound, allowed_range.upper_bound])
            row.extend([""] * (len(headers) - len(row)))
            worksheet.append(row)

    header_fill = PatternFill("solid", fgColor="D9EAF7")
    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = worksheet.dimensions
    for column_index, header in enumerate(headers, start=1):
        column_letter = get_column_letter(column_index)
        max_length = len(str(header))
        for cell in worksheet[column_letter]:
            if cell.value is not None:
                max_length = max(max_length, len(str(cell.value)))
        worksheet.column_dimensions[column_letter].width = min(
            max(max_length + 2, 12),
            42,
        )

    workbook.save(output_path)


def _build_golden_raw_column_lookup(
    reference: GoldenReference,
    measurements: list[MeasurementRecord],
) -> dict[tuple[tuple[tuple[str, str], ...], str], list[str]]:
    raw_columns: dict[tuple[tuple[tuple[str, str], ...], str], set[str]] = defaultdict(
        set
    )
    for measurement in measurements:
        if not _dimensions_match_filter(measurement.dimensions, reference.filters):
            continue
        reference_key = tuple(
            (dimension, measurement.dimensions.get(dimension, ""))
            for dimension in reference.reference_dimensions
        )
        raw_columns[(reference_key, measurement.logical_metric)].add(
            measurement.raw_column
        )
    return {
        key: sorted(values, key=_natural_sort_key)
        for key, values in raw_columns.items()
    }


def _dimensions_match_filter(
    dimensions: dict[str, str],
    expected: dict[str, str],
) -> bool:
    for key, value in expected.items():
        expected_values = [item.strip() for item in str(value).split(",") if item.strip()]
        if not expected_values:
            expected_values = [str(value).strip()]
        if dimensions.get(key) not in expected_values:
            return False
    return True


def _metric_allowed_ranges_for_excel(
    metric: GoldenMetricRange,
) -> list[GoldenAllowedRange]:
    if metric.allowed_ranges:
        return list(metric.allowed_ranges)
    if metric.lower_bound is not None and metric.upper_bound is not None:
        return [GoldenAllowedRange(metric.lower_bound, metric.upper_bound)]
    return []


def _validate_measurement_groups_match_template(
    measurements: list[MeasurementRecord],
    template,
) -> None:
    template_group_ids = {group.id for group in template.analysis_groups}
    raw_column_to_group_ids: dict[str, set[str]] = defaultdict(set)
    for group in template.analysis_groups:
        for column in group.columns:
            raw_column_to_group_ids[column.name].add(group.id)

    mismatches: list[dict[str, str]] = []
    seen_keys: set[tuple[str, str, str, str]] = set()
    for measurement in measurements:
        expected_group_ids = raw_column_to_group_ids.get(measurement.raw_column, set())
        raw_column_expected_group_id = (
            next(iter(expected_group_ids))
            if len(expected_group_ids) == 1
            else ""
        )
        is_missing_in_template = measurement.group_id not in template_group_ids
        is_raw_column_group_mismatch = bool(
            raw_column_expected_group_id
            and measurement.group_id != raw_column_expected_group_id
        )
        if not is_missing_in_template and not is_raw_column_group_mismatch:
            continue
        key = (
            measurement.group_id,
            measurement.raw_column,
            raw_column_expected_group_id,
            measurement.logical_metric,
        )
        if key in seen_keys:
            continue
        seen_keys.add(key)
        mismatches.append(
            {
                "group_id": measurement.group_id,
                "raw_column": measurement.raw_column,
                "logical_metric": measurement.logical_metric,
                "expected_group_id": raw_column_expected_group_id,
            }
        )

    if not mismatches:
        return

    detail_lines: list[str] = []
    for item in mismatches[:MAX_TEMPLATE_GROUP_MISMATCH_EXAMPLES]:
        expected_group_id = item["expected_group_id"]
        if expected_group_id:
            detail_lines.append(
                f"- raw_column '{item['raw_column']}' currently has group_id '{item['group_id']}', "
                f"but the current template maps it to '{expected_group_id}'. "
                f"(logical_metric='{item['logical_metric']}')"
            )
        else:
            detail_lines.append(
                f"- raw_column '{item['raw_column']}' currently has group_id '{item['group_id']}', "
                "but this group_id was not found in the current template. "
                f"(logical_metric='{item['logical_metric']}')"
            )
    if len(mismatches) > MAX_TEMPLATE_GROUP_MISMATCH_EXAMPLES:
        detail_lines.append(
            f"- ... and {len(mismatches) - MAX_TEMPLATE_GROUP_MISMATCH_EXAMPLES} more mismatched group entries."
        )

    raise ValueError(
        "Build golden stopped because some measurement group_id values do not match the current template analysis_groups.\n"
        "Those measurements were not imported with the current template grouping, so continuing would silently fall back to default golden rules.\n"
        "Please verify the template, or re-import / refresh group_id using the current template before building golden again.\n"
        + "\n".join(detail_lines)
    )


def parse_csv_items(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def parse_semicolon_items(value: str) -> list[str]:
    return [item.strip() for item in value.split(";") if item.strip()]


def parse_filters(items: list[str]) -> dict[str, str]:
    filters: dict[str, str] = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"Invalid filter: {item}. Expected key=value")
        key, raw_value = item.split("=", 1)
        normalized_key = key.strip()
        parsed_values = parse_csv_items(raw_value)
        normalized_value = ",".join(parsed_values) if parsed_values else raw_value.strip()
        if normalized_key in filters and normalized_value:
            merged_values = parse_csv_items(filters[normalized_key])
            for value_item in parsed_values:
                if value_item not in merged_values:
                    merged_values.append(value_item)
            filters[normalized_key] = ",".join(merged_values)
        else:
            filters[normalized_key] = normalized_value
    return filters


def parse_filter_text(value: str) -> dict[str, str]:
    lines = [line.strip() for line in value.splitlines() if line.strip()]
    return parse_filters(lines)


def build_column_filters(
    template,
    include_tests: list[str] | None = None,
    exclude_tests: list[str] | None = None,
) -> dict[str, dict[str, list[str]]]:
    alias_map, allowed_values = _column_filter_metadata(template)
    filters: dict[str, dict[str, list[str]]] = {}
    if include_tests:
        filters["include"] = _normalize_column_filter_rules(
            include_tests,
            alias_map,
            allowed_values,
            label="test",
        )
    if exclude_tests:
        filters["exclude"] = _normalize_column_filter_rules(
            exclude_tests,
            alias_map,
            allowed_values,
            label="exclude test",
        )
    return filters


def _column_filter_metadata(
    template,
) -> tuple[FieldNames, dict[str, set[str]]]:
    alias_map = column_filter_fields(template)
    allowed_values: dict[str, set[str]] = {
        "id": set(),
        "display_name": set(),
        "raw_column": set(),
        "logical_metric": set(),
        "unit": set(),
    }
    for level in getattr(template, "column_header_levels", []):
        canonical_name = str(level.name).strip()
        if not canonical_name:
            continue
        allowed_values.setdefault(canonical_name, set())
    for group in getattr(template, "analysis_groups", []):
        allowed_values["id"].add(str(group.id))
        allowed_values["display_name"].add(str(group.display_name))
        if group.unit is not None:
            allowed_values["unit"].add(str(group.unit))
        for column in group.columns:
            allowed_values["raw_column"].add(str(column.name))
            logical_metric = (
                group.id
                if group.analysis_mode == "pooled_columns"
                else f"{group.id}::{column.name}"
            )
            allowed_values["logical_metric"].add(str(logical_metric))
            for level, header_value in zip(template.column_header_levels, column.header_values):
                allowed_values[str(level.name)].add(str(header_value))
    return alias_map, allowed_values


def _normalize_column_filter_rules(
    raw_values: list[str],
    alias_map: FieldNames,
    allowed_values: dict[str, set[str]],
    *,
    label: str,
) -> dict[str, list[str]]:
    normalized_filters: dict[str, list[str]] = {}
    supported_fields = ", ".join(sorted(allowed_values))
    for item in raw_values:
        raw_text = str(item).strip()
        if not raw_text:
            continue
        if "=" not in raw_text:
            raise ValueError(
                f"Invalid {label} filter: {raw_text}. "
                "Expected semicolon-separated field=value1,value2 entries."
            )
        raw_key, raw_value = raw_text.split("=", 1)
        try:
            canonical_key = alias_map.resolve(raw_key, strict=True)
        except ValueError as exc:
            raise ValueError(
                f"Unsupported {label} filter field: {raw_key}. "
                f"Supported fields: {supported_fields}. {exc}"
            ) from exc
        values = [part.strip() for part in raw_value.split(",") if part.strip()]
        if not values:
            raise ValueError(f"{label.title()} filter value cannot be empty: {raw_text}.")
        known_values = allowed_values.get(canonical_key, set())
        for value in values:
            if known_values and value not in known_values:
                raise ValueError(
                    f"Unsupported {label} filter value for {canonical_key}: {value}. "
                    f"Known values: {', '.join(sorted(known_values))}."
                )
        existing = normalized_filters.setdefault(canonical_key, [])
        for value in values:
            if value not in existing:
                existing.append(value)
    return normalized_filters


def _build_column_filter_context_map(template) -> dict[str, dict[str, str]]:
    context_by_raw_column: dict[str, dict[str, str]] = {}
    for group in template.analysis_groups:
        for column in group.columns:
            logical_metric = (
                group.id
                if group.analysis_mode == "pooled_columns"
                else f"{group.id}::{column.name}"
            )
            context = {
                "id": str(group.id),
                "display_name": str(group.display_name),
                "raw_column": str(column.name),
                "logical_metric": str(logical_metric),
                "unit": "" if group.unit is None else str(group.unit),
            }
            for level, header_value in zip(template.column_header_levels, column.header_values):
                context[str(level.name)] = str(header_value)
            context_by_raw_column[str(column.name)] = context
    return context_by_raw_column


def _matches_column_filters(
    measurement: MeasurementRecord,
    filters: dict[str, dict[str, list[str]]],
    context_by_raw_column: dict[str, dict[str, str]],
) -> bool:
    context = context_by_raw_column.get(
        measurement.raw_column,
        {
            "id": str(measurement.group_id),
            "display_name": str(measurement.group_display_name),
            "raw_column": str(measurement.raw_column),
            "logical_metric": str(measurement.logical_metric),
            "unit": "",
        },
    )
    include_filters = filters.get("include", {})
    exclude_filters = filters.get("exclude", {})
    for key, values in include_filters.items():
        if values and context.get(key, "") not in values:
            return False
    if exclude_filters and all(
        (not values) or context.get(key, "") in values
        for key, values in exclude_filters.items()
    ):
        return False
    return True


def build_dimension_filters(
    sample_keys: list[str] | None = None,
    sample_dimension_names: list[str] | None = None,
    reliability_nodes: list[str] | None = None,
    exclude_sample_keys: list[str] | None = None,
    exclude_reliability_nodes: list[str] | None = None,
    reliability_node_dimension: str = "reliability_node",
) -> dict[str, dict[str, list[str]]]:
    filters: dict[str, dict[str, list[str]]] = {}
    normalized_sample_dimension_names = [
        str(item).strip() for item in (sample_dimension_names or []) if str(item).strip()
    ]
    if sample_keys or exclude_sample_keys:
        if not normalized_sample_dimension_names:
            raise ValueError(
                "Template must define report.sample_dimension_names before sample-key filtering can be used."
            )
        sample_key_filter = filters.setdefault(SAMPLE_KEY_FILTER, {})
        sample_key_filter["dimension_names"] = normalized_sample_dimension_names
        if sample_keys:
            sample_key_filter["include"] = _normalize_sample_key_filters(
                sample_keys,
                normalized_sample_dimension_names,
            )
        if exclude_sample_keys:
            sample_key_filter["exclude"] = _normalize_sample_key_filters(
                exclude_sample_keys,
                normalized_sample_dimension_names,
            )
    if reliability_nodes:
        filters.setdefault(reliability_node_dimension, {})["include"] = [
            item for item in reliability_nodes if item
        ]
    if exclude_reliability_nodes:
        filters.setdefault(reliability_node_dimension, {})["exclude"] = [
            item for item in exclude_reliability_nodes if item
        ]
    return filters


def _normalize_sample_key_filters(
    raw_values: list[str],
    sample_dimension_names: list[str],
) -> list[str]:
    normalized: list[str] = []
    expected_count = len(sample_dimension_names)
    expected_label = ",".join(sample_dimension_names)
    for item in raw_values:
        raw_text = str(item).strip()
        if not raw_text:
            continue
        if expected_count == 2 and ":" in raw_text:
            first_value, raw_second_values = raw_text.split(":", 1)
            first_value = first_value.strip()
            second_values = [part.strip() for part in raw_second_values.split(",") if part.strip()]
            if not first_value or not second_values:
                raise ValueError(
                    "Invalid sample key filter: "
                    f"{raw_text}. Expected grouped format like "
                    f"{sample_dimension_names[0]}:{sample_dimension_names[1]}1,{sample_dimension_names[1]}2. "
                    "Separate multiple groups with ';'."
                )
            for second_value in second_values:
                normalized.append(";".join([first_value, second_value]))
            continue
        parts = [part.strip() for part in raw_text.split(",")]
        if len(parts) != expected_count or any(part == "" for part in parts):
            raise ValueError(
                "Invalid sample key filter: "
                f"{raw_text}. Expected {expected_count} value(s) joined by ',' "
                f"to match sample_dimension_names ({expected_label}). "
                "Separate multiple keys with ';'. "
                "For two-part sample keys, grouped format like 'LotA:S001,S002;LotB:S003' is also supported."
            )
        normalized.append(";".join(parts))
    return normalized


def _build_dataset_payload(
    dataset_id: str,
    source_file: str,
    template_name: str,
    measurement_count: int,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = {
        "dataset_id": dataset_id,
        "source_file": source_file,
        "template_name": template_name,
        "measurement_count": measurement_count,
    }
    if metadata:
        payload.update(metadata)
    return payload


def _filter_measurements(
    measurements: Iterable[MeasurementRecord],
    dataset_ids: list[str] | None = None,
    dimension_filters: dict[str, dict[str, list[str]]] | None = None,
    column_filters: dict[str, dict[str, list[str]]] | None = None,
    template=None,
    *,
    compact: bool = False,
) -> list[MeasurementRecord] | ColumnarMeasurements:
    dataset_id_set = {item for item in (dataset_ids or []) if item}
    normalized_dimension_filters: dict[str, dict[str, object]] = {}
    for key, config in (dimension_filters or {}).items():
        if key == SAMPLE_KEY_FILTER:
            include_values = {value for value in config.get("include", []) if value}
            exclude_values = {value for value in config.get("exclude", []) if value}
            dimension_names = [
                str(item).strip()
                for item in config.get("dimension_names", [])
                if str(item).strip()
            ]
            if include_values or exclude_values:
                normalized_dimension_filters[key] = {
                    "include": include_values,
                    "exclude": exclude_values,
                    "dimension_names": list(dimension_names),
                }
            continue
        include_values = {value for value in config.get("include", []) if value}
        exclude_values = {value for value in config.get("exclude", []) if value}
        if include_values or exclude_values:
            normalized_dimension_filters[key] = {
                "include": include_values,
                "exclude": exclude_values,
            }
    normalized_column_filters: dict[str, dict[str, list[str]]] = {}
    if column_filters:
        if template is None:
            raise ValueError("Template is required when column filters are used.")
        column_fields = column_filter_fields(template)
        for mode in ("include", "exclude"):
            config = column_filters.get(mode, {})
            if not isinstance(config, dict):
                continue
            normalized_config: dict[str, list[str]] = {}
            for key, values in config.items():
                normalized_values = [str(value).strip() for value in values if str(value).strip()]
                if normalized_values:
                    canonical = column_fields.resolve(key, strict=True)
                    existing = normalized_config.setdefault(canonical, [])
                    existing.extend(value for value in normalized_values if value not in existing)
            if normalized_config:
                normalized_column_filters[mode] = normalized_config
    context_by_raw_column = (
        _build_column_filter_context_map(template) if normalized_column_filters else {}
    )
    filtered = ColumnarMeasurements() if compact else []
    dimension_rule_cache = {}
    for item in measurements:
        if dataset_id_set and item.dataset_id not in dataset_id_set:
            continue
        if normalized_dimension_filters:
            shape = tuple(item.dimensions)
            if shape not in dimension_rule_cache:
                fields = row_fields(template) if template is not None else FieldNames(shape)
                rules = {}
                for key, config in normalized_dimension_filters.items():
                    canonical = key if key == SAMPLE_KEY_FILTER else fields.resolve(key)
                    config = {**config, "include": set(config["include"]), "exclude": set(config["exclude"])}
                    if key == SAMPLE_KEY_FILTER:
                        config["dimension_names"] = [fields.resolve(name) for name in config["dimension_names"]]
                    if canonical in rules:
                        for mode in ("include", "exclude"):
                            rules[canonical][mode] |= config[mode]
                    else:
                        rules[canonical] = config
                dimension_rule_cache[shape] = rules
            if not _matches_dimension_filters(item.dimensions, dimension_rule_cache[shape]):
                continue
        if normalized_column_filters and not _matches_column_filters(
            item,
            normalized_column_filters,
            context_by_raw_column,
        ):
            continue
        filtered.append(item)
    return filtered


def _matches_dimension_filters(
    dimensions: dict[str, str],
    filters: dict[str, dict[str, object]],
) -> bool:
    for key, filter_config in filters.items():
        if key == SAMPLE_KEY_FILTER:
            raw_dimension_names = filter_config.get("dimension_names", [])
            dimension_names = [
                str(item).strip() for item in raw_dimension_names if str(item).strip()
            ]
            value = ";".join(str(dimensions.get(name, "") or "").strip() for name in dimension_names)
        else:
            value = dimensions.get(key, "")
        include_values = filter_config.get("include", set())
        exclude_values = filter_config.get("exclude", set())
        if include_values and value not in include_values:
            return False
        if exclude_values and value in exclude_values:
            return False
    return True


def _build_import_preview(
    existing_measurements: list[MeasurementRecord],
    incoming_measurements: list[MeasurementRecord],
) -> dict[str, Any]:
    existing_rows = _collect_row_records(existing_measurements)
    incoming_rows = _collect_row_records(incoming_measurements)

    existing_row_groups = list(existing_rows.values())
    incoming_row_groups = list(incoming_rows.values())

    existing_keys = {_row_identity_key(item["dimensions"]) for item in existing_row_groups}
    incoming_keys = {_row_identity_key(item["dimensions"]) for item in incoming_row_groups}
    conflict_keys = existing_keys & incoming_keys

    existing_conflicts = [
        item for item in existing_row_groups if _row_identity_key(item["dimensions"]) in conflict_keys
    ]
    incoming_conflicts = [
        item for item in incoming_row_groups if _row_identity_key(item["dimensions"]) in conflict_keys
    ]

    ordered_dimensions = _resolve_dimension_order(None, [*existing_measurements, *incoming_measurements])

    return {
        "existing_measurement_count": len(existing_measurements),
        "incoming_measurement_count": len(incoming_measurements),
        "existing_row_count": len(existing_row_groups),
        "incoming_row_count": len(incoming_row_groups),
        "existing_conflict_row_count": len(existing_conflicts),
        "conflict_row_count": len(incoming_conflicts),
        "conflict_keys": conflict_keys,
        "conflict_rows_preview": [
            {name: item["dimensions"].get(name, "") for name in ordered_dimensions}
            for item in incoming_conflicts[:20]
        ],
        "has_repeat_dimension": all(
            REPEAT_DIMENSION_NAME in item["dimensions"]
            and str(item["dimensions"].get(REPEAT_DIMENSION_NAME, "")).strip() != ""
            for item in incoming_conflicts
        ),
        "dimensions": ordered_dimensions,
    }


def _format_import_conflict_message(preview: dict[str, Any]) -> str:
    lines = [
        (
            "Detected duplicate sample attributes in current database. "
            "Please choose replace or append."
        ),
        (
            f"Incoming conflicting rows: {preview['conflict_row_count']}, "
            f"existing rows affected: {preview['existing_conflict_row_count']}."
        ),
    ]
    if preview["conflict_rows_preview"]:
        lines.append("Examples:")
        for item in preview["conflict_rows_preview"][:5]:
            text = ", ".join(f"{key}={value}" for key, value in item.items() if value != "")
            lines.append(f"- {text}")
    if not preview["has_repeat_dimension"]:
        lines.append(
            "Append is unavailable because this template does not provide repeat_id."
        )
    return "\n".join(lines)


def _append_with_shifted_repeats(
    existing_measurements: list[MeasurementRecord],
    incoming_measurements: list[MeasurementRecord],
) -> tuple[list[MeasurementRecord], int]:
    existing_rows = _collect_row_records(existing_measurements)
    incoming_rows = _collect_row_records(incoming_measurements)
    existing_repeat_max = _build_repeat_index_map(existing_rows.values())

    grouped_incoming: dict[tuple[tuple[str, str], ...], list[dict[str, Any]]] = defaultdict(list)
    for row in incoming_rows.values():
        grouped_incoming[_row_identity_key(row["dimensions"])].append(row)

    row_repeat_updates: dict[tuple[str, str, int], str] = {}
    shifted_row_count = 0

    for base_key, rows in grouped_incoming.items():
        if base_key not in existing_repeat_max:
            continue
        if any(REPEAT_DIMENSION_NAME not in row["dimensions"] for row in rows):
            raise ValueError(
                "Append mode requires repeat_id for all conflicting rows."
            )
        rows.sort(
            key=lambda item: (
                _parse_repeat_index(item["dimensions"].get(REPEAT_DIMENSION_NAME)) or 0,
                item["row_number"],
            )
        )
        next_repeat = existing_repeat_max[base_key]
        for row in rows:
            next_repeat += 1
            row_repeat_updates[row["row_key"]] = str(next_repeat)
            shifted_row_count += 1

    adjusted_measurements: list[MeasurementRecord] = []
    for item in incoming_measurements:
        row_key = (item.dataset_id, item.source_file, item.row_number)
        if row_key in row_repeat_updates:
            dimensions = dict(item.dimensions)
            dimensions[REPEAT_DIMENSION_NAME] = row_repeat_updates[row_key]
            adjusted_measurements.append(
                MeasurementRecord(
                    dataset_id=item.dataset_id,
                    source_file=item.source_file,
                    row_number=item.row_number,
                    logical_metric=item.logical_metric,
                    group_id=item.group_id,
                    group_display_name=item.group_display_name,
                    presentation_group=item.presentation_group,
                    raw_column=item.raw_column,
                    value=item.value,
                    dimensions=dimensions,
                )
            )
        else:
            adjusted_measurements.append(item)
    return adjusted_measurements, shifted_row_count


def _collect_row_records(measurements: list) -> dict[tuple[str, str, int], dict[str, Any]]:
    rows: dict[tuple[str, str, int], dict[str, Any]] = {}
    for item in measurements:
        row_key = (item.dataset_id, item.source_file, item.row_number)
        entry = rows.setdefault(
            row_key,
            {
                "row_key": row_key,
                "dataset_id": item.dataset_id,
                "source_file": item.source_file,
                "row_number": item.row_number,
                "dimensions": dict(item.dimensions),
                "measurement_count": 0,
            },
        )
        entry["measurement_count"] += 1
    return rows


def _build_repeat_index_map(rows: Any) -> dict[tuple[tuple[str, str], ...], int]:
    repeat_map: dict[tuple[tuple[str, str], ...], int] = {}
    for row in rows:
        repeat_value = row["dimensions"].get(REPEAT_DIMENSION_NAME)
        repeat_index = _parse_repeat_index(repeat_value)
        if repeat_index is None:
            continue
        base_key = _row_identity_key(row["dimensions"])
        repeat_map[base_key] = max(repeat_map.get(base_key, 0), repeat_index)
    return repeat_map


def _parse_repeat_index(value: str | None) -> int | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        return int(text)
    except ValueError as exc:
        raise ValueError(
            f"repeat_id must be an integer when append mode is used. Got: {text}"
        ) from exc


def _row_identity_key(dimensions: dict[str, str]) -> tuple[tuple[str, str], ...]:
    return tuple(
        sorted(
            (key, value)
            for key, value in dimensions.items()
            if key != REPEAT_DIMENSION_NAME
        )
    )


def _resolve_dimension_order(
    template_path: str | None,
    measurements: list,
) -> list[str]:
    if template_path:
        try:
            template = load_template(template_path)
            ordered = [item.name for item in sorted(template.row_dimensions, key=lambda item: item.priority)]
            existing = {
                key
                for measurement in measurements
                for key in measurement.dimensions.keys()
            }
            return ordered + sorted(existing - set(ordered))
        except Exception:
            pass
    dimension_names = {
        key
        for measurement in measurements
        for key in measurement.dimensions.keys()
    }
    return sorted(dimension_names)
