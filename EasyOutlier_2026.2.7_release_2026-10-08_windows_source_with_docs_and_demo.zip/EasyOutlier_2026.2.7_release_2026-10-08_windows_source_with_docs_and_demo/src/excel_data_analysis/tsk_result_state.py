"""Small, lossless display snapshots; fitted likelihood inputs stay in memory."""
from __future__ import annotations

import base64
from copy import deepcopy
import gzip
import json


TSK_DISPLAY_FORMAT = "tsk-display-v1"
GROUP_FIELDS = (
    "label", "node", "stratum", "batch_mode", "batch_dimension", "parent_batch_id",
    "source_batches", "batch_counts", "types", "chains", "options", "joint_risk",
    "combination_views", "feature_effects",
)
CONTEXT_FIELDS = (
    "version", "model", "confidence_level", "converged", "clipped", "type_ids",
    "all_type_ids", "coefficients", "categorical_features", "numeric_reference",
    "numeric_scaling",
)
DIAGNOSTIC_FIELDS = (
    "model", "converged", "rank", "parameter_count", "chain_count", "confidence_level",
    "interval_method", "reference_environment", "warnings", "finite_mle",
    "feature_scaling", "feature_coefficients", "feature_coefficient_identifiable",
    "categorical_features", "fit_debug_report", "deviance", "identifiable_type_count",
)


def _select(value: dict, fields: tuple[str, ...]) -> dict:
    return {key: deepcopy(value[key]) for key in fields if key in value}


def _boundary_summary(value) -> dict | None:
    return _select(value, ("version", "converged", "feature_clipped")) if isinstance(value, dict) else None


def compact_tsk_result(payload: dict) -> dict:
    """Preserve displayed estimates exactly, without sample outcomes or fit matrices."""
    groups = payload.get("groups", [])
    if not isinstance(groups, list) or not all(isinstance(group, dict) for group in groups):
        raise ValueError("Invalid saved TSK groups")
    result = _select(payload, ("topology", "warnings"))
    raw_provenance = payload.get("provenance") or {}
    provenance = _select(raw_provenance, tuple(key for key in raw_provenance if key != "template_snapshot"))
    provenance["saved_display_only"] = True
    result["provenance"] = provenance
    template = raw_provenance.get("template_snapshot", {})
    if isinstance(template, dict) and isinstance(template.get("tsk_analysis"), dict):
        # The topology table needs category declarations, not a duplicate of
        # every template instance, parser option and Analyze configuration.
        provenance["template_snapshot"] = {"tsk_analysis": _select(template["tsk_analysis"], (
            "categorical_feature_columns", "feature_columns", "feature_model", "use_xy"))}
    result.update(groups=[], saved_display_only=True)
    for group in groups:
        saved = _select(group, GROUP_FIELDS)
        saved["saved_display_only"] = True
        saved["diagnostics"] = _select(group.get("diagnostics") or {}, DIAGNOSTIC_FIELDS)
        context = group.get("prediction_context")
        if isinstance(context, dict):
            saved["prediction_context"] = _select(context, CONTEXT_FIELDS)
            saved["prediction_context"]["boundary_fit"] = _boundary_summary(context.get("boundary_fit"))
        boundary = _boundary_summary((group.get("diagnostics") or {}).get("boundary_fit"))
        if boundary is not None:
            saved["diagnostics"]["boundary_fit"] = boundary
        # Older results stored this mapping separately from chain rows.
        members = group.get("chain_members", {})
        for chain in saved.get("chains", []):
            if "members" not in chain and chain.get("chain_id") in members:
                chain["members"] = deepcopy(members[chain["chain_id"]])
        result["groups"].append(saved)
    return result


def encode_tsk_result(payload: dict) -> dict:
    data = json.dumps(compact_tsk_result(payload), ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")
    return {"format": TSK_DISPLAY_FORMAT,
            "data": base64.b64encode(gzip.compress(data, compresslevel=6, mtime=0)).decode("ascii")}


def decode_tsk_result(payload: dict) -> dict:
    if "format" in payload and payload["format"] != TSK_DISPLAY_FORMAT:
        raise ValueError("Unsupported saved TSK result format")
    if payload.get("format") == TSK_DISPLAY_FORMAT:
        data = gzip.decompress(base64.b64decode(payload["data"], validate=True))
        payload = json.loads(data.decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("Invalid saved TSK result")
    # Compact legacy inline results as well: reopening is a display operation.
    return compact_tsk_result(payload)
