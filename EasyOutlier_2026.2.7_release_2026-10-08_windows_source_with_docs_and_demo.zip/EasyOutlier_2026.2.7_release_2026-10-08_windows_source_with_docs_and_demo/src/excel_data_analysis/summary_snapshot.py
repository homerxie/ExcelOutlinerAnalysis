"""Analysis settings and source revisions used by Summary plot navigation."""
from __future__ import annotations

from copy import deepcopy
import hashlib
from pathlib import Path

from .measurement_storage import MeasurementStorage
from .template import load_template, template_to_payload


def _file_revision(path: Path) -> dict:
    try:
        stat = path.stat()
    except FileNotFoundError:
        return {"path": str(path.resolve()), "revision": None}
    return {"path": str(path.resolve()), "revision": [stat.st_size, stat.st_mtime_ns]}


def _source_revisions(context: dict) -> dict:
    storage = MeasurementStorage(context["storage_path"])
    source = storage.path if storage.path.exists() else storage.legacy_path
    revisions = {"measurements": _file_revision(source)}
    if context.get("golden_path"):
        revisions["golden"] = _file_revision(Path(context["golden_path"]))
    return revisions


def capture_summary_snapshot(payload: dict) -> dict:
    """Capture once before analysis; later UI edits must not change this scope.

    Large measurement files stay on disk. Revision checks reject changed data
    instead of silently associating a saved Summary with another population.
    The template itself is small enough to retain, including one-run settings.
    """
    template = deepcopy(payload.get("template_payload"))
    if template is None:
        template = template_to_payload(load_template(payload["template_path"]))
    report = template["report"]
    for parameter, field in (
        ("outlier_fail_method_override", "outlier_fail_method"),
        ("outlier_merge_order_override", "outlier_merge_order"),
        ("outlier_treat_empty_cells_as_fail_override", "outlier_treat_empty_cells_as_fail"),
    ):
        if payload.get(parameter) is not None:
            report[field] = payload[parameter]
    threshold = payload.get("zscore_threshold_override")
    if threshold is not None:
        report["zscore_thresholds"] = {"default": threshold, "overrides": {}}
    context = {
        "template_path": str(Path(payload["template_path"]).resolve()),
        "template_payload": template,
        "analysis_scope": payload["analysis_scope"],
        "storage_path": str(Path(payload["storage_path"]).resolve()),
        "golden_path": str(Path(payload["built_golden_path"]).resolve()) if payload.get("built_golden_path") else "",
        "dataset_ids": deepcopy(payload.get("dataset_ids")) if payload["analysis_scope"] == "checked_imports" else None,
        "dimension_filters": deepcopy(payload.get("dimension_filters")),
        "column_filters": deepcopy(payload.get("column_filters")),
        "outlier_fail_method": report["outlier_fail_method"],
        "zscore_threshold": None,
    }
    return {"version": 1, "context": context, "sources": _source_revisions(context)}


def summary_snapshot_error(snapshot: dict | None) -> str:
    if not isinstance(snapshot, dict) or snapshot.get("version") != 1:
        return "This saved result has no plot navigation context. Run Analysis again to enable sample links."
    context = snapshot.get("context")
    if not isinstance(context, dict) or not context.get("template_payload") or not context.get("storage_path"):
        return "The saved analysis context is incomplete. Run Analysis again to enable sample links."
    try:
        current = _source_revisions(context)
    except (OSError, ValueError, TypeError):
        return "The original analysis data is unavailable. Restore it or run Analysis again."
    if any(item["revision"] is None for item in current.values()):
        return "The original database or Golden file is unavailable. Restore it or run Analysis again."
    if current != snapshot.get("sources"):
        return "The database or Golden file has changed since this Summary was generated. Run Analysis again before opening its sample links."
    return ""


def _measurement_file(storage_path: str | Path) -> Path:
    storage = MeasurementStorage(storage_path)
    return storage.path if storage.path.exists() else storage.legacy_path


def _file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def prepare_summary_snapshot_for_copy(snapshot: dict | None, source_storage: str | Path) -> dict | None:
    """Validate before a known lossless workspace save can compact its files.

    A saved-root snapshot may also describe its untouched copy2 workspace.
    Changed workspaces must not inherit an older root's analysis association.
    The result is an ephemeral preparation token, not persistent GUI state.
    """
    if summary_snapshot_error(snapshot):
        return None
    try:
        source = _measurement_file(source_storage)
        active = _file_revision(source)
        original = snapshot["sources"]["measurements"]
        if not source.is_file() or active["revision"] != original["revision"]:
            return None
        if Path(active["path"]).name != Path(original["path"]).name:
            return None
        prepared = deepcopy(snapshot)
        preparation = {"source_storage": str(Path(source_storage).resolve())}
        golden = snapshot["context"].get("golden_path")
        if golden:
            preparation["golden_digest"] = _file_digest(Path(golden))
            # Do not bless a file which changed while its digest was read.
            if _file_revision(Path(golden)) != snapshot["sources"]["golden"]:
                return None
        prepared["_copy_preparation"] = preparation
        return prepared
    except (OSError, ValueError, TypeError, KeyError):
        return None


def rebase_summary_snapshot_after_copy(
    prepared: dict | None,
    source_root: str | Path,
    destination_root: str | Path,
    destination_storage: str | Path,
) -> dict | None:
    """Complete a successful save using its pre-save validation token.

    The save itself guarantees measurement equivalence, including format
    compaction and Save As source-path rewriting. Golden files are smaller and
    checked by content, because the workspace may hold a newer same-name file.
    """
    if not isinstance(prepared, dict) or not isinstance(prepared.get("_copy_preparation"), dict):
        return None
    try:
        preparation = prepared["_copy_preparation"]
        source_storage = Path(preparation["source_storage"]).resolve()
        source_root = Path(source_root).resolve()
        destination_root = Path(destination_root).resolve()
        destination_storage = Path(destination_storage).resolve()
        if not _measurement_file(destination_storage).is_file():
            return None
        result = deepcopy(prepared)
        result.pop("_copy_preparation")
        context = result["context"]
        context["storage_path"] = str(destination_storage)
        golden = context.get("golden_path")
        if golden:
            original = Path(golden).resolve()
            candidates: list[Path] = []
            for base, copied_names in (
                (source_storage, {"golden", "imports"}),
                (source_root, {"golden", "imports", "result"}),
            ):
                try:
                    relative = original.relative_to(base)
                except ValueError:
                    continue
                if relative.parts and relative.parts[0] in copied_names:
                    candidates.append(destination_root / relative)
            digest = preparation["golden_digest"]
            for candidate in candidates:
                if candidate.is_file() and _file_digest(candidate) == digest:
                    context["golden_path"] = str(candidate.resolve())
                    break
            else:
                # External and uncopied Golden files retain their source. An
                # overwritten/deleted source cannot be replaced by names alone.
                if _file_revision(original) != result["sources"]["golden"]:
                    return None
                if _file_digest(original) != digest:
                    return None
        result["sources"] = _source_revisions(context)
        return result if not summary_snapshot_error(result) else None
    except (OSError, ValueError, TypeError, KeyError):
        return None
