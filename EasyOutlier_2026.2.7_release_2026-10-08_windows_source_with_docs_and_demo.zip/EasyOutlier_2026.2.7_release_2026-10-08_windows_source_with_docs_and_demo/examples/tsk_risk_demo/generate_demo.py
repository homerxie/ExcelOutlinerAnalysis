"""Regenerate the synthetic multi-feature Logistic demo with a fixed seed."""
from __future__ import annotations

import csv
from itertools import product
import json
import math
from pathlib import Path
import random
from statistics import fmean, pstdev
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from excel_data_analysis.models import (  # noqa: E402
    AnalysisColumn, AnalysisGroup, ColumnHeaderLevel, ReportConfig, RowDimension,
    RowDimensionSource, TemplateConfig, ThresholdConfig, TSKAnalysisConfig, TSKInstance,
)
from excel_data_analysis.template import save_template  # noqa: E402


SEED = 20260922
SAMPLE_COUNT = 400
TYPE_INTERCEPTS = {"TSK_A": -5.1, "TSK_B": -4.5, "TSK_C": -3.9}
CATEGORY_EFFECTS = {
    "bump_size": {"large": 0.0, "medium": 0.35, "small": 0.8},
    "stack": {"stack1": 0.0, "stack2": 0.3, "stack3": 0.6},
    "material": {"aluminum": 0.0, "copper": 0.25},
}
NUMERIC_EFFECTS = {
    "x": {"center": 0.0, "scale": 1000.0, "coefficient": 0.30},
    "y": {"center": 0.0, "scale": 1000.0, "coefficient": -0.20},
    "metal_A_density": {"center": 0.5, "scale": 0.2, "coefficient": 0.25},
}
NODE_EFFECTS = {"T0": 0.0, "T1": 0.45}
FEATURE_COLUMNS = [*CATEGORY_EFFECTS, "metal_A_density"]
LAYOUT_REPETITIONS = 4
TYPE_COUNTS = [
    (1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0),
    (1, 0, 1), (0, 1, 1), (2, 1, 0), (0, 2, 1),
    (1, 0, 2), (2, 2, 1), (1, 2, 2), (3, 1, 2),
]


def instance_probability(instance: TSKInstance, node: str) -> float:
    eta = TYPE_INTERCEPTS[instance.tsk_id] + NODE_EFFECTS[node]
    eta += sum(effects[instance.features[name]] for name, effects in CATEGORY_EFFECTS.items())
    for name, effect in NUMERIC_EFFECTS.items():
        value = getattr(instance, name) if name in ("x", "y") else instance.features[name]
        eta += effect["coefficient"] * (value - effect["center"]) / effect["scale"]
    return 1.0 / (1.0 + math.exp(-eta))


def build_demo(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    random_source = random.Random(SEED)
    layouts = TYPE_COUNTS * LAYOUT_REPETITIONS
    chains = [f"Chain_{index:02d}" for index in range(1, len(layouts) + 1)]
    combinations = list(product(*(effects.keys() for effects in CATEGORY_EFFECTS.values())))
    categories_by_type = {}
    for type_index, tsk_id in enumerate(TYPE_INTERCEPTS):
        count = sum(layout[type_index] for layout in layouts)
        # Every type covers the full category grid, with repeated instances.
        # Shuffle within type so categories do not encode TSK identity or chain order.
        repeats, remainder = divmod(count, len(combinations))
        categories = combinations * repeats + random_source.sample(combinations, remainder)
        random_source.shuffle(categories)
        categories_by_type[tsk_id] = categories
    topology = []
    for chain, counts in zip(chains, layouts):
        for tsk_id, count in zip(TYPE_INTERCEPTS, counts):
            for occurrence in range(count):
                # Deliberately varied positions; identical designs use different
                # physical instances, even when labels occur in another chain.
                x = round(random_source.uniform(-1200, 1200), 3)
                y = round(random_source.uniform(-1200, 1200), 3)
                features = dict(zip(CATEGORY_EFFECTS, categories_by_type[tsk_id].pop()))
                features["metal_A_density"] = round(random_source.uniform(0.15, 0.85), 4)
                topology.append(TSKInstance(
                    chain_id=chain, tsk_instance_id=f"{chain}_{tsk_id}_{occurrence + 1}",
                    tsk_id=tsk_id, x=x, y=y, features=features, chain_key=["DemoDesign", chain],
                ))
    template = TemplateConfig(
        name="SYNTHETIC_TSK_DEMO_NOT_REAL_TOPOLOGY", schema_version=3,
        test_data_header_row=0, row_header_row=0, test_data_start_row=1,
        column_header_levels=[ColumnHeaderLevel("Design", 1), ColumnHeaderLevel("Chain Name", 2), ColumnHeaderLevel("Test Type", 3)],
        row_dimensions=[
            RowDimension("lot_id", [RowDimensionSource("Lot")], 1),
            RowDimension("sample_id", [RowDimensionSource("Sample")], 2),
            RowDimension("reliability_node", [RowDimensionSource("Node")], 3),
            RowDimension("repeat_id", [RowDimensionSource("Repeat")], 4),
        ],
        analysis_groups=[AnalysisGroup(
            id=chain, display_name=chain, analysis_mode="per_column", unit="Ohm",
            columns=[AnalysisColumn(f"R_{chain}", ["DemoDesign", chain, "Resistance"], 1)],
        ) for chain in chains],
        report=ReportConfig(
            zscore_thresholds=ThresholdConfig(3.5), node_orders=[["T0", "T1"]],
            sample_dimension_names=["lot_id", "sample_id"],
            reliability_node_dimension="reliability_node", chain_column_level="Chain Name",
            initial_row_merge_level="repeat_id", initial_column_merge_level="Test Type",
            outlier_fail_method="modified_z_score", outlier_treat_empty_cells_as_fail=False,
        ),
        tsk_analysis=TSKAnalysisConfig(
            enabled=True, use_xy=False, coordinate_unit="um",
            instances=topology, feature_columns=FEATURE_COLUMNS,
            categorical_feature_columns=list(CATEGORY_EFFECTS), feature_model="logistic",
        ),
    )
    save_template(template, directory / "template.json")
    save_template(template, directory / "template.xlsx")
    instances_by_chain = {chain: [item for item in topology if item.chain_id == chain] for chain in chains}
    probabilities = {(node, item.tsk_instance_id): instance_probability(item, node)
                     for node in NODE_EFFECTS for item in topology}
    fail_counts = {(node, chain): 0 for node in ("T0", "T1") for chain in chains}
    with (directory / "data.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["Lot", "Sample", "Node", "Repeat", *(f"R_{chain}" for chain in chains)])
        for sample in range(1, SAMPLE_COUNT + 1):
            uniforms = {item.tsk_instance_id: random_source.random() for item in topology}
            for node in NODE_EFFECTS:
                measurements = []
                for chain in chains:
                    failed = False
                    for instance in instances_by_chain[chain]:
                        failed |= uniforms[instance.tsk_instance_id] < probabilities[node, instance.tsk_instance_id]
                    fail_counts[node, chain] += int(failed)
                    # Uniform small noise keeps every healthy cell well within
                    # modified-z 3.5; deliberately injected failures are 1000.
                    measurements.append(round((1000 if failed else 100) + random_source.uniform(-1, 1), 6))
                writer.writerow(["SYNTHETIC_LOT", f"S{sample:04d}", node, "1", *measurements])
    with (directory / "expected_chain_counts.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["Lot", "Node", "CHAIN_ID", "n", "k"])
        for (node, chain), count in fail_counts.items():
            writer.writerow(["SYNTHETIC_LOT", node, chain, SAMPLE_COUNT, count])

    standardization = {}
    intercept_shift = 0.0
    for name, effect in NUMERIC_EFFECTS.items():
        values = [getattr(item, name) if name in ("x", "y") else item.features[name] for item in topology]
        mean, scale = fmean(values), pstdev(values)
        standardization[name] = {
            "mean": mean, "scale": scale,
            "coefficient_per_layout_sd": effect["coefficient"] * scale / effect["scale"],
        }
        intercept_shift += effect["coefficient"] * (mean - effect["center"]) / effect["scale"]
    truth = {
        "synthetic": True, "seed": SEED, "samples_per_node": SAMPLE_COUNT,
        "chain_count": len(chains), "instance_count": len(topology), "feature_model": "logistic",
        "type_intercepts": TYPE_INTERCEPTS, "category_log_odds_effects": CATEGORY_EFFECTS,
        "numeric_log_odds_effects": NUMERIC_EFFECTS, "node_log_odds_effects": NODE_EFFECTS,
        "category_reference": {name: min(effects) for name, effects in CATEGORY_EFFECTS.items()},
        "layout_standardization": standardization,
        "type_intercepts_at_layout_mean_T0": {
            name: value + intercept_shift for name, value in TYPE_INTERCEPTS.items()
        },
        "chain_probabilities": {
            node: {chain: 1.0 - math.prod(1.0 - probabilities[node, item.tsk_instance_id]
                                        for item in instances_by_chain[chain]) for chain in chains}
            for node in NODE_EFFECTS
        },
        "note": "Invented topology and effects, not physical measurements. Numeric effects use coefficient * (value - center) / scale. Standardized truth assumes all features and XY are enabled and all chains are active. T0/T1 share instance thresholds; fit nodes separately.",
    }
    (directory / "simulation_truth.json").write_text(json.dumps(truth, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    from generate_batch_demo import build_batch_demo

    directory = Path(__file__).resolve().parent
    build_demo(directory)
    build_batch_demo(directory)
