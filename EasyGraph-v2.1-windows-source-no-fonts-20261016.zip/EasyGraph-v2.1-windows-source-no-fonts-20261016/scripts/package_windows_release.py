from __future__ import annotations

import argparse
import datetime as dt
import zipfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PACKAGE_NAME = "EasyGraph-v2.1-windows-source"
FONT_RESOURCE_PATH = Path("src/easygraph/resources/fonts")

INCLUDE_PATHS = [
    "src",
    "icon/dark",
    "icon/light",
    "icon/tabler",
    "icon/lucide",
    "icon/EasyGraph_Project_Icon_Pack/EasyGraph_Project_Icon_Windows.ico",
    "icon/windows",
    "scripts/build_and_smoke_windows.ps1",
    "scripts/generate_windows_icons.py",
    "scripts/inspect_prism_samples.py",
    "scripts/package_windows_release.py",
    "scripts/windows_version_info.py",
    "docs/plans/2026-07-16-prism-raw-data-import.md",
    "demo/prism_samples/SOURCES.md",
    "ui",
    "translations",
    "template/.gitkeep",
    "tests",
    "requirements.txt",
    "requirements-windows.txt",
    "README.md",
    "CHANGELOG.md",
    "WINDOWS_BUILD.md",
]

EXCLUDE_PARTS = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".DS_Store",
}

EXCLUDE_SUFFIXES = {
    ".pyc",
    ".pyo",
}


def iter_package_files(*, include_fonts: bool = True) -> list[Path]:
    files: list[Path] = []
    for include in INCLUDE_PATHS:
        path = PROJECT_ROOT / include
        if not path.exists():
            raise FileNotFoundError(f"Missing required package path: {include}")
        if path.is_file():
            files.append(path)
            continue
        for child in path.rglob("*"):
            if not child.is_file():
                continue
            relative = child.relative_to(PROJECT_ROOT)
            if not include_fonts and FONT_RESOURCE_PATH in relative.parents:
                continue
            if any(part in EXCLUDE_PARTS for part in relative.parts):
                continue
            if child.suffix in EXCLUDE_SUFFIXES:
                continue
            if relative.match("template/*.json"):
                continue
            files.append(child)
    return sorted(files)


def build_package(output_dir: Path, package_name: str, *, include_fonts: bool = True) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d")
    archive_path = output_dir / f"{package_name}-{stamp}.zip"
    package_root = archive_path.stem

    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in iter_package_files(include_fonts=include_fonts):
            relative = path.relative_to(PROJECT_ROOT)
            archive.write(path, Path(package_root) / relative)

    return archive_path


def build_font_package(output_dir: Path, package_name: str) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d")
    archive_path = output_dir / f"{package_name}-fonts-{stamp}.zip"
    # No wrapper directory: extract this ZIP directly into the source root.
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in iter_package_files():
            relative = path.relative_to(PROJECT_ROOT)
            if FONT_RESOURCE_PATH in relative.parents:
                archive.write(path, relative)
    return archive_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Create the EasyGraph Windows source package.")
    parser.add_argument(
        "--output-dir",
        default=PROJECT_ROOT / "dist",
        type=Path,
        help="Directory where the zip archive will be written.",
    )
    parser.add_argument(
        "--name",
        default=DEFAULT_PACKAGE_NAME,
        help="Base package name. The current UTC date and .zip suffix are added automatically.",
    )
    parser.add_argument(
        "--split-fonts",
        action="store_true",
        help="Create a no-fonts source ZIP and a separate font resource ZIP.",
    )
    args = parser.parse_args()

    source_name = f"{args.name}-no-fonts" if args.split_fonts else args.name
    archives = [build_package(args.output_dir, source_name, include_fonts=not args.split_fonts)]
    if args.split_fonts:
        font_name = args.name.removesuffix("-windows-source")
        archives.append(build_font_package(args.output_dir, font_name))
    for archive_path in archives:
        try:
            display_path = archive_path.relative_to(PROJECT_ROOT)
        except ValueError:
            display_path = archive_path
        print(display_path)


if __name__ == "__main__":
    main()
