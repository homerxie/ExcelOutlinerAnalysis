"""Short-lived application files owned by the currently opened database.

Every managed directory holds a shared OS lease throughout its lifetime. A
collector may reclaim abandoned directories only while exclusively owning that
same database lease. Durable snapshots and TSK history never live here.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shutil
import stat
from tempfile import TemporaryDirectory
import weakref

from .database_paths import WORKSPACE_MARKER_FILENAME, database_root_for_storage
from .runtime_lease import RUNTIME_LEASE_FILENAME, RuntimeLease, boot_time as _boot_time, is_redirected


RUNTIME_DIRNAME = ".runtime"
RUNTIME_OWNER_FILENAME = ".runtime-owner.json"
_OWNER_RECORD = {"application": "excel-data-analysis", "runtime_version": 1}
_MANAGED_PREFIXES = (
    "analysis-template-", "analysis-result-", "import-template-", "restored-result-",
    "tsk-input-", "workbook-", "saved-", "save-files-", "tsk-sample-identities-",
)
_LEGACY_FILES = {
    "analysis-template-": {"template.json"},
    "import-template-": {"template.json"},
    "analysis-result-": {"analysis.pickle", "analysis.json.gz", "tsk-analysis.json.gz",
                         "zscore-cache-input.pickle", "zscore-cache-output.pickle"},
    "restored-result-": {"analysis.json.gz"},
    "tsk-input-": {"tsk-analysis.json.gz"},
    "tsk-sample-identities-": {"tsk-analysis.json.gz"},
}


def runtime_directory(storage_root: str | Path) -> Path:
    """Return the database-owned scratch parent, creating it when necessary."""
    root = database_root_for_storage(storage_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    directory = root / RUNTIME_DIRNAME
    try:
        if is_redirected(directory):
            raise ValueError("Database runtime directory must not be a symbolic link or junction")
    except FileNotFoundError:
        pass
    directory.mkdir(exist_ok=True)
    return directory


def _remove_owned_directory(name: str, lease: RuntimeLease, owner_pid: int,
                            *, ignore_errors: bool = False) -> None:
    try:
        # A fork inherits both the object and its descriptor, but it does not
        # inherit permission to retire files still owned by the parent.
        if os.getpid() == owner_pid:
            TemporaryDirectory._rmtree(name, ignore_errors=ignore_errors)
    finally:
        lease.close()


class _DatabaseTemporaryDirectory(TemporaryDirectory):
    def __init__(self, directory: Path, prefix: str):
        # Acquire before allocation: an exclusive collector cannot observe a
        # newly allocated directory before its owner has become protected.
        lease = RuntimeLease(directory)
        try:
            super().__init__(prefix=prefix, dir=directory)
            self._lease = lease
            self._owner_pid = os.getpid()
            self._finalizer.detach()
            self._finalizer = weakref.finalize(self, _remove_owned_directory, self.name, lease,
                                             self._owner_pid,
                                             ignore_errors=True)
            (Path(self.name) / RUNTIME_OWNER_FILENAME).write_text(
                json.dumps(_OWNER_RECORD), encoding="utf-8")
        except BaseException:
            if hasattr(self, "_lease"):
                self.cleanup()
            else:
                lease.close()
            raise

    def cleanup(self) -> None:
        if self._finalizer.detach() or Path(self.name).exists():
            _remove_owned_directory(self.name, self._lease, self._owner_pid)
        else:
            self._lease.close()


def temporary_database_directory(storage_root: str | Path, *, prefix: str) -> TemporaryDirectory:
    """Create leased scratch inside its database; refuse unprotected allocation."""
    return _DatabaseTemporaryDirectory(runtime_directory(storage_root), prefix)


def _managed_prefix(name: str) -> str | None:
    for prefix in _MANAGED_PREFIXES:
        if name.startswith(prefix) and re.fullmatch(r"[a-z0-9_]{8}", name[len(prefix):]):
            return prefix
    return None


def _plain_tree(directory: Path) -> list[Path] | None:
    """Never reclaim redirected trees or directories containing special files."""
    pending, entries = [directory], []
    while pending:
        current = pending.pop()
        if is_redirected(current):
            return None
        info = current.lstat()
        if stat.S_ISDIR(info.st_mode):
            pending.extend(current.iterdir())
        elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            return None
        entries.append(current)
    return entries


def _reclaimable(directory: Path, prefix: str, boot_epoch: float | None) -> bool:
    entries = _plain_tree(directory)
    if entries is None:
        return False
    marker = directory / RUNTIME_OWNER_FILENAME
    if marker.exists():
        # Unknown/future schemas or damaged ownership records remain untouched.
        return (marker.is_file() and marker.stat().st_size <= 1024
                and json.loads(marker.read_text(encoding="utf-8")) == _OWNER_RECORD)
    # An older application does not take our lease. Only files untouched since
    # before this machine booted can be proven unused by that application. In
    # particular, unknown/current-boot legacy leftovers must be preserved.
    if boot_epoch is None:
        return False
    cutoff = boot_epoch - 60.0
    for path in entries:
        info = path.lstat()
        if max(info.st_mtime, info.st_ctime, getattr(info, "st_birthtime", 0)) >= cutoff:
            return False
        if path == directory:
            continue
        if not path.is_file() or path.parent != directory:
            return False
        if prefix == "workbook-":
            if not re.fullmatch(r"openpyxl\.[a-zA-Z0-9_.-]+", path.name):
                return False
        elif path.name not in _LEGACY_FILES.get(prefix, set()):
            return False
    # Arbitrary saved-/save-files- payloads have no reliable legacy signature.
    return prefix in _LEGACY_FILES or prefix == "workbook-"


def cleanup_database_runtime(storage_root: str | Path) -> list[Path]:
    """Best-effort orphan collection, skipping the whole DB while any owner lives.

    Only recognized application scratch is removed. Unmarked legacy files from
    the current boot, malformed metadata, unknown contents and redirected paths
    are intentionally preserved. The permanent lease file is never removed.
    Failure to establish exclusive ownership always means no cleanup.
    """
    removed = []
    try:
        directory = database_root_for_storage(storage_root).resolve() / RUNTIME_DIRNAME
        if not directory.exists() or is_redirected(directory) or not directory.is_dir():
            return removed
        with RuntimeLease(directory, exclusive=True, blocking=False):
            boot_epoch = _boot_time()
            for candidate in directory.iterdir():
                prefix = _managed_prefix(candidate.name)
                if prefix is None:
                    continue
                try:
                    if (is_redirected(candidate) or not candidate.is_dir()
                            or not _reclaimable(candidate, prefix, boot_epoch)):
                        continue
                    shutil.rmtree(candidate)
                    removed.append(candidate)
                except (OSError, ValueError, UnicodeError, RecursionError):
                    # One inaccessible/damaged orphan must not block opening,
                    # closing, or recovery of other independent directories.
                    continue
    except (OSError, ValueError):
        pass
    return removed


def database_root_for_snapshot(snapshot_path: str | Path) -> Path:
    """Locate a snapshot's owner without relying on the process directory.

    GUI snapshots have an explicit runtime or saved-analysis location. Older
    direct API callers may supply an arbitrary archive; its own directory is
    then the explicit local owner of temporary recovery files.
    """
    parent = Path(snapshot_path).absolute().parent
    markers = (WORKSPACE_MARKER_FILENAME, ".excel_data_analysis_gui_state.json",
               "datasets.jsonl", "measurements.jsonl", "measurements.jsonl.gz")
    for candidate in (parent, *parent.parents):
        if candidate.name == RUNTIME_DIRNAME:
            return candidate.parent
        if any((candidate / name).is_file() for name in markers):
            return database_root_for_storage(candidate)
        if candidate.name == "analysis" and candidate.parent.name == "result":
            return candidate.parent.parent
    return parent


def temporary_snapshot_directory(snapshot_path: str | Path, *, prefix: str) -> TemporaryDirectory:
    """Keep recovery scratch alongside the database that owns its archive."""
    return temporary_database_directory(database_root_for_snapshot(snapshot_path), prefix=prefix)
