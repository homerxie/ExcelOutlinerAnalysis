# EasyGraph

EasyGraph is a local Python/PySide6 desktop demo for lightweight scientific distribution plots. It is intentionally simpler than GraphPad-style software and focuses on a fast workflow for box plots, violin plots, and ridge plots.

## Quick Start

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
source .venv/bin/activate
python src/app.py
```

If dependencies are missing:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
source .venv/bin/activate
pip install -r requirements.txt
```

## Windows Packaging

For Windows wheel installation and PyInstaller packaging notes, see
`WINDOWS_BUILD.md`. The Windows dependency file is `requirements-windows.txt`.

Create a source package for transfer to Windows:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
python scripts/package_windows_release.py
```

## Core Features

- Editable in-app table using a wide data format.
- Box plot, violin plot, and ridge plot.
- Show all data points over distributions.
- Data point jitter modes: `Quasirandom` by default, plus `Beeswarm` and `Random`.
- Outlier detection with IQR, Z-score, MAD, or percentile rules.
- Outlier behavior: `Mark only` or `Exclude from distribution`.
- Box whisker modes: Tukey 1.5 IQR, Min-Max, Percentile 5-95, Percentile 10-90.
- Professional presets and transparent background support.
- Copy current figure to clipboard as PNG, with transparent background when enabled.
- Export PNG, SVG, PDF, TIFF, TIF, JPG, or JPEG through Matplotlib.
- Save/open project files with the `.eg` suffix.
- Import/export Excel and CSV.
- Manual group ordering, including a drag-and-drop order dialog.

## Important Data Model

The table is wide-format:

```text
row 1: group names
row 2+: numeric values
```

The first visible row is not a normal data row. It is the group-name row and is styled differently in the UI. When plotting, EasyGraph treats row 1 as the group labels and all rows below it as values.

Group names support forced line breaks. Multiline group names are preserved in:

- the table
- plotted tick labels
- project files
- Excel/TSV copy and paste

Copy/paste is TSV-compatible for Excel. When a group name contains a newline, the TSV writer quotes the cell so Excel can keep it as one cell.

Duplicate group names are allowed. During plotting, duplicate-named columns are combined into one group. Group sorting by mean/median uses the combined values.

## Project File Format

Project files use the `.eg` suffix. The file is a zip archive, not a custom binary format.

```text
example.eg
├── data.csv
├── settings.json
└── project.json
```

- `data.csv`: the wide table. CSV headers are the group names; rows below are values.
- `settings.json`: serialized `ChartSettings` from `src/easygraph/settings.py`.
- `project.json`: metadata, currently `{ "version": 1, "app": "EasyGraph" }`.

Older `.gplite` files use the same internal structure. They can still be opened through `All Files (*)` in the open dialog.

## Main Files

```text
src/app.py
src/easygraph/data.py
src/easygraph/overlay_series.py
src/easygraph/palette.py
src/easygraph/plotting/__init__.py
src/easygraph/plotting/canvas.py
src/easygraph/project_io.py
src/easygraph/settings.py
src/easygraph/spreadsheet_io.py
src/easygraph/template_io.py
src/ui_main_window.py
src/ui_group_order_dialog.py
ui/main_window.ui
ui/group_order_dialog.ui
tests/test_core.py
tests/test_architecture.py
tests/easygraph_case.py
tests/test_app_preferences.py
tests/test_data.py
tests/test_data_module.py
tests/test_overlay_series_module.py
tests/test_palette.py
tests/test_palette_module.py
tests/test_plotting.py
tests/test_project_io.py
tests/test_spreadsheet_io.py
tests/test_settings_module.py
tests/test_template_io.py
requirements.txt
```

- `src/easygraph/data.py`: owner of the wide-to-long conversion, duplicate-group aggregation, group ordering, outlier detection, sample/blank data creation, box-whisker values, and chart-axis label semantics.
- `src/easygraph/overlay_series.py`: owner of overlay series construction, visibility, statistics-table data, color allocation, and line-style policy. It uses QtGui `QColor` without importing Qt Widgets or the plotting stack.
- `src/easygraph/palette.py`: owner of palette expansion, `QColor`-based color derivation and contrast calculations, and precomputed palette-cache loading. It uses QtGui `QColor` without importing Qt Widgets, Matplotlib, Seaborn, or SciPy.
- `src/easygraph/plotting/canvas.py`: owner of the Qt/Matplotlib plot canvas lifecycle, zooming, interaction feedback, figure export/clipboard image, and the still-intact chart rendering/layout methods. It currently still contains chart rendering, legend/layout, statistics-table, and Matplotlib overlay rendering internals; those are intentionally not split yet.
- `src/easygraph/project_io.py`: owner of current `.eg` ZIP persistence and strict current-field `ChartSettings` decoding. Unknown or retired fields fail, missing current fields default through `ChartSettings`, and no legacy migrations are applied.
- `src/easygraph/settings.py`: owner of `ChartSettings`, visual presets, and settings-related constants.
- `src/easygraph/spreadsheet_io.py`: owner of overlay-row DataFrames and actual CSV/Excel access. Reads handle CSV specially and use Excel otherwise so `.xls` input is accepted; writes recognize only `.csv` and `.xlsx`, appending `.xlsx` for other or missing suffixes.
- `src/easygraph/template_io.py`: owner of style-template JSON, the default `src/template` path, filename/list/import helpers, and indexed group colors. It may import QtGui `QColor`, but not Qt Widgets or the plotting stack.
- `src/app.py`: remains the executable application module, compatibility facade, and UI coordinator. It directly reexports `PlotCanvas` and canvas helper names, and owns UI delegates, dialogs, translated errors, table behavior, `MainWindow`, tests-facing helpers, and recent-project `QSettings` helpers.
- `ui/main_window.ui`: main UI source of truth.
- `ui/group_order_dialog.ui`: manual group-order dialog source of truth.
- `src/ui_main_window.py`: generated from `ui/main_window.ui`.
- `src/ui_group_order_dialog.py`: generated from `ui/group_order_dialog.ui`.
- `tests/easygraph_case.py`: shared test fixtures, including the `QApplication`-free base case and the Qt-aware integration base case.
- `tests/test_app_preferences.py`: recent-project preferences and menu behavior tests.
- `tests/test_data.py`: non-UI, `QApplication`-free data-shaping and validation tests.
- `tests/test_data_module.py`: data-module ownership, compatibility-reexport, and GUI/plotting-free import tests.
- `tests/test_overlay_series_module.py`: overlay-module ownership and exact compatibility-reexport identity checks, behavior checks, and direct-import boundary checks under normal and optimized Python.
- `tests/test_palette.py`: non-UI, `QApplication`-free palette and overlay-policy tests.
- `tests/test_palette_module.py`: palette-module ownership, compatibility-reexport, cache-path, and import-boundary tests.
- `tests/test_plotting.py`: plotting-module contract tests.
- `tests/test_project_io.py`: `QApplication`-free project-format and persistence tests.
- `tests/test_spreadsheet_io.py`: spreadsheet-module and spreadsheet UI integration tests.
- `tests/test_settings_module.py`: settings-module ownership, compatibility-reexport, and GUI/plotting-free import tests.
- `tests/test_template_io.py`: template-module ownership and style-template persistence tests.
- `tests/test_core.py`: remaining Qt and plot integration tests, including table behavior, rendering, and UI settings.
- `tests/test_architecture.py`: architecture checks that keep the generated main-window UI and application code boundaries explicit.

## UI Workflow

The fixed main-window structure is defined in `ui/main_window.ui`. Removed Python
widget-builder methods were unreachable legacy code, not an alternate UI source.
Live programmatic widgets and dialogs have not all moved to `.ui` files; that is
reserved for a later phase.

Regenerate generated Python after editing the main window:

```bash
./.venv/bin/pyside6-uic ui/main_window.ui -o src/ui_main_window.py
```

Regenerate generated Python after editing the group-order dialog:

```bash
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o src/ui_group_order_dialog.py
```

Do not hand-edit generated `src/ui_*.py` files unless there is a temporary debugging reason. Regenerate them from `.ui` instead.

## Translation Workflow

EasyGraph uses Qt's native translation toolchain. Static UI text comes from
`ui/*.ui`, generated `src/ui_*.py` files use `QCoreApplication.translate(...)`,
and runtime text in `src/app.py` should use `self.tr(...)`.

Simplified Chinese is available from the app's `Language` menu. Changing the
language preference is saved with `QSettings` and takes effect after restarting
EasyGraph. The `EASYGRAPH_LANGUAGE` environment variable can override the saved
preference for testing, for example:

```bash
EASYGRAPH_LANGUAGE=zh_CN python src/app.py
```

When UI text changes, update the translation source file:

```bash
./scripts/update_translations.sh
```

Then open `translations/easygraph_zh_CN.ts` in Qt Linguist, review any
unfinished entries, and compile the runtime translation file:

```bash
./scripts/compile_translations.sh
```

Keep chart option values such as `Box`, `Median`, and `Table order` in English.
They are project/template settings values, not ordinary UI labels.

## Plotting Stack

- Matplotlib owns the figure, canvas, export, clipboard image, and detailed rendering.
- Seaborn is used as a styling and categorical-plot helper for box/violin behavior.
- SciPy `gaussian_kde` is used for ridge distributions.
- Pandas is still used internally for table-to-plot transformations and Excel/CSV I/O.

The app does not support double-click-to-edit plot elements. Plot style is controlled from the right-side settings panel.

## Canvas Behavior

The plot preview uses a fixed physical size in centimeters from settings:

- Width and height are stored in cm.
- Preview has scrollbars if the canvas is larger than the center viewport.
- Ctrl+wheel zoom is supported.
- Trackpad/native pinch zoom is handled where Qt exposes native/pinch gestures.

The rendered figure can have a transparent background. Clipboard copy and export respect the transparent background setting.

## Table Behavior

- The first table row is the group-name row.
- The top horizontal header only shows numeric column indices for resizing/orientation.
- Columns are user-resizable.
- Add row, add column, rename group, delete column are supported.
- Copy/paste works with Excel-style TSV.
- Pasting can expand row/column count.
- Delete clears selected cells.
- Editing row 1 updates group names, manual group order, row height, and plot rendering.

Important implementation details:

- `MainWindow.table_dataframe()` converts the visible table to a pandas DataFrame.
- `MainWindow.set_table_dataframe()` loads a DataFrame into the visible table with group names in row 1.
- `easygraph.data.prepare_plot_data()` converts wide data to long plot data.
- `easygraph.data.values_for_group()` combines duplicate group-name columns safely.
- `easygraph.data.ordered_group_columns()` handles table order, manual order, name sorting, and statistic sorting.

`src/app.py` reexports these former data-helper names for compatibility.

## Settings Highlights

`ChartSettings` in `src/easygraph/settings.py` is the project-serializable settings object. `src/app.py` reexports it and the existing settings constants for compatibility. Important fields include:

- `chart_type`: Box, Violin, Ridge.
- `preset`: visual preset key.
- `group_order`: Table order, Manual, Name A-Z, Name Z-A, Mean ascending/descending, Median ascending/descending.
- `manual_group_order`: saved manual order list.
- title/group label/value label text, including multiline text.
- canvas width/height in cm, DPI, transparent background.
- title/axis/tick font sizes.
- grid, axis range, axis line width, tick rotation.
- point display, point size, point alpha, jitter mode, jitter amount.
- outlier method, threshold, highlight, and effect.
- box/violin/ridge-specific width/bandwidth/overlap controls.

## Testing

Run these commands from the repository root.

Run the full concise timed suite:

```bash
./.venv/bin/python scripts/run_tests.py
```

Run a focused test by dotted name:

```bash
./.venv/bin/python scripts/run_tests.py -v tests.test_data.DataTests.test_wide_table_is_converted_to_plot_data
```

For direct `unittest` diagnostics without the concise runner:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest discover -s tests -t . -q
```

Compile-check key Python files:

```bash
./.venv/bin/python -m py_compile src/app.py src/easygraph/data.py src/easygraph/overlay_series.py src/easygraph/palette.py src/easygraph/plotting/__init__.py src/easygraph/plotting/canvas.py src/easygraph/project_io.py src/easygraph/settings.py src/easygraph/spreadsheet_io.py src/easygraph/template_io.py src/ui_main_window.py src/ui_group_order_dialog.py tests/easygraph_case.py tests/test_architecture.py tests/test_app_preferences.py tests/test_data.py tests/test_data_module.py tests/test_overlay_series_module.py tests/test_palette.py tests/test_palette_module.py tests/test_plotting.py tests/test_project_io.py tests/test_settings_module.py tests/test_spreadsheet_io.py tests/test_template_io.py tests/test_core.py tests/test_support.py tests/test_warning_policy.py tests/test_test_runner.py scripts/run_tests.py
```

The current expected full-suite count is **260 tests**. The non-UI test classes
use `EasyGraphTestCase` and do not initialize `QApplication`, although they still
import application modules where needed. UI tests that do not need an initial
plot can use `self.make_window()`; tests needing an initial render construct
`app.MainWindow()`.

On a macOS development machine on 2026-06-19, comparable runs of
`./.venv/bin/python scripts/run_tests.py --slow 20` around commit `d8e9b003`
observed about 211–213 seconds of `unittest` time. This is a diagnostic
observation, not a guaranteed benchmark or hard speed claim.

## Known Test Output

The known Seaborn `vert` `PendingDeprecationWarning` is narrowly suppressed by
the test warning policy. The policy suppresses only this known warning; all other
warnings follow Python's normal warning filters.

Qt may still print font-alias or `propagateSizeHints` diagnostics. Slow-test
reporting is diagnostic. These warnings and diagnostics are textual; no
screenshot is transmitted unless an image or screenshot tool is explicitly used.

## Agent Handoff Notes

- The project folder is `/Users/xiezihong/Documents/Programming/EasyGraph`; confirm the active workspace and permissions before editing.
- Prefer `rg` for searching.
- Use `apply_patch` for manual edits.
- Fixed main-window and group-order-dialog structural changes must start in their `.ui` files and regenerate `src/ui_*.py`; live programmatic widgets and dialog shells remain in `src/app.py` until their later migration.
- Avoid reverting user changes.
- This folder is a Git repository; inspect the active branch and working tree before editing.
- If paste/refresh bugs appear, inspect table event handling, `paste_table_selection()`, and `handle_table_item_changed()` first.
- If plotting crashes after editing group names, check duplicate group-name handling in `values_for_group()` and `ordered_group_columns()`.
- If Chinese text renders as boxes, inspect `configure_matplotlib_fonts()` and available system fonts.
