# EasyGraph Incremental App Refactor Design

## Goal

Reduce the maintenance cost of `src/app.py` and the test suite without changing
application behavior or breaking the existing public API used by tests and
external callers.

## Current State

- `src/app.py` has 7,164 lines.
- `MainWindow` has 2,935 lines and mixes UI coordination, table editing,
  settings synchronization, dialogs, file operations, and rendering triggers.
- `PlotCanvas` has 2,276 lines and mixes canvas lifecycle, chart rendering,
  layout calculation, overlays, interaction feedback, and export.
- `tests/test_core.py` has 4,514 lines and 226 tests.
- The tests construct `MainWindow` 115 times, construct `PlotCanvas` 56 times,
  and repeatedly perform real Matplotlib renders.
- A complete headless run takes about 220 seconds of test time and about 240
  seconds wall-clock time on the current development machine.
- Repeated Seaborn `PendingDeprecationWarning` output consumes substantial
  terminal/context tokens but is not the primary runtime cost.
- Some fixed controls and dialog shells are still created in Python even though
  `.ui` files are intended to be the source of truth.
- The README test count and repository handoff notes are stale.

## Constraints

1. Use an incremental, low-risk migration.
2. Keep application behavior and the current serialized project format stable.
   Legacy or unknown settings fields are not supported during this refactor.
3. Preserve existing imports such as `import app`, `app.ChartSettings`,
   `app.MainWindow`, and `app.prepare_plot_data` during the migration.
4. Every migration stage must leave a runnable application and passing tests.
5. Fixed UI structure must be changed in `.ui` files first. Generated
   `src/ui_*.py` files must never be edited by hand.
6. Avoid a framework rewrite or an unnecessary conversion from `unittest` as
   part of this refactor.

## Target Module Structure

```text
src/
├── app.py
└── easygraph/
    ├── __init__.py
    ├── settings.py
    ├── data.py
    ├── palette.py
    ├── overlay_series.py
    ├── project_io.py
    ├── spreadsheet_io.py
    ├── template_io.py
    ├── plotting/
    │   ├── __init__.py
    │   ├── canvas.py
    │   ├── chart_renderers.py
    │   ├── layout.py
    │   └── overlay_renderer.py
    └── ui/
        ├── __init__.py
        ├── main_window.py
        ├── table_controller.py
        ├── dialogs.py
        └── line_style_delegate.py
```

`src/app.py` remains the executable and compatibility facade. During the
migration it imports and re-exports names from the new modules so existing
callers do not need to change atomically.

## Responsibility Boundaries

### Settings and pure data logic

`settings.py` owns `ChartSettings`, presets, and settings-related constants.
`data.py` owns wide-to-long conversion, group ordering, duplicate-group
handling, outlier detection, and statistics that do not depend on Qt or
Matplotlib. `palette.py` owns color expansion, contrast, color mapping, and
palette selection.

### Overlay boundary

`overlay_series.py` owns pure overlay rules: series construction, visibility,
statistics, stable color/style keys, and other operations that can be tested
without Qt or Matplotlib.

`plotting/overlay_renderer.py` owns Matplotlib-specific overlay work: artist
creation, label placement, collision avoidance, bounding boxes, arrows, and
axis integration. UI code may depend on `overlay_series.py` but must not depend
on `overlay_renderer.py` merely to populate a dialog.

### Persistence boundary

`project_io.py` owns the current `.eg` ZIP format and conversion of current
settings dictionaries into `ChartSettings`. Unknown or retired settings fields
raise `ValueError`; missing current fields use `ChartSettings` defaults. The
module does not contain legacy-field migrations and does not depend on Qt.

`template_io.py` owns style-template JSON, template file naming and listing,
and indexed group-color mapping. It follows the same strict settings-field
policy as `project_io.py`. It may use QtGui `QColor` to preserve current color
validation and normalization, but it must not import Qt Widgets.

`spreadsheet_io.py` owns CSV/XLSX reading and writing plus the overlay-row
DataFrame format. It depends on pandas and the standard library, not Qt or the
project/template modules.

File chooser dialogs, translated error messages, current-project state, recent
project preferences, and synchronization of imported data into `MainWindow`
remain in `app.py`. `app.py` imports and re-exports the three modules' public
names during the migration.

### Plotting boundary

`plotting/canvas.py` owns the Qt canvas lifecycle, zooming, interaction events,
export, and orchestration of a render. Chart-specific drawing moves to
`chart_renderers.py`, while physical sizing, margins, legends, and statistics
table layout move to `layout.py`.

The first plotting migration moves `PlotCanvas` intact. Internal extraction is
performed only after imports and compatibility tests are stable.

### Main window boundary

`ui/main_window.py` owns top-level window orchestration. Table history,
clipboard operations, table mutations, and table-to-DataFrame conversion move
to `table_controller.py`. Dialog coordination moves to `dialogs.py`; fixed
dialog shells are defined by `.ui` files.

The final `MainWindow` should primarily load generated UI classes, bind model
objects, connect top-level signals, and coordinate file operations and renders.

## UI Source-of-Truth Policy

- Fixed widgets, layouts, menus, actions, labels, and dialog shells belong in
  `ui/*.ui`.
- Runtime Python may populate options, connect signals, insert the Matplotlib
  canvas into a predefined host layout, create recent-project menu entries, or
  create rows whose count is determined by user data.
- Existing programmatically-created fixed controls, including legend and
  secondary-axis controls, move into `ui/main_window.ui` before their Python
  binding code is simplified.
- New fixed dialogs receive their own `.ui` files. Data-dependent row contents
  may still be generated at runtime inside a `.ui`-defined container.
- Every `.ui` edit is followed by `pyside6-uic` regeneration.
- A verification command regenerates UI Python files and requires a clean Git
  diff, preventing generated files from drifting away from `.ui` sources.

## Test Strategy

Split the monolithic suite by responsibility while keeping `unittest`:

```text
tests/
├── test_data.py
├── test_overlay_series.py
├── test_palette.py
├── test_project_io.py
├── test_spreadsheet_io.py
├── test_template_io.py
├── test_plotting.py
├── test_main_window.py
└── test_integration.py
```

- Pure modules are tested without creating `QApplication`, `MainWindow`, or a
  Matplotlib figure.
- `MainWindow` gains a backward-compatible `initial_render=True` argument.
  UI-focused tests pass `False` to avoid an unrelated full render.
- Plotting tests reuse a canvas when isolation permits and close Qt/Matplotlib
  resources in teardown.
- A small integration suite retains complete window creation and real plotting.
- Daily development runs only affected modules; the complete suite remains the
  merge/phase gate.
- Suppress only the known third-party Seaborn warning by category, message, and
  source module. Do not globally suppress application warnings.
- Use quiet output by default so successful runs do not flood agent context.
- Add duration reporting or a small timing runner so performance regressions
  can be identified without reading verbose output.

Warnings are text output, not screenshots. Offscreen Qt and Matplotlib renders
remain local unless a screenshot/image tool explicitly opens or returns them.

## Migration Stages

### Stage 0: Test feedback and documentation

Split tests, add targeted warning filtering, introduce the optional initial
render switch, ensure resource cleanup, document fast and full test commands,
and correct stale README statements. Establish timing baselines before and
after the changes.

### Stage 1: Remove unreachable legacy UI builders

Prove that the old `_build_layout`, `_build_controls`, `_chart_group`, and
related methods have no callers, then remove them. No live UI is redesigned in
this stage.

### Stage 2: Extract pure modules

Extract `settings.py`, `data.py`, `palette.py`, and `overlay_series.py` one at a
time. Add compatibility re-exports to `app.py` and run the relevant focused
tests plus the full suite after each extraction.

### Stage 3: Extract project and spreadsheet I/O

Extract persistence in three low-risk steps with explicit filenames:

1. Move current `.eg` ZIP serialization and strict settings decoding to
   `project_io.py`.
2. Move style-template JSON and indexed color mapping to `template_io.py`.
3. Move CSV/XLSX data and overlay-row format handling to `spreadsheet_io.py`.

Unknown or retired settings fields are rejected instead of translated or
silently ignored. Missing current fields continue to use current defaults.
File chooser dialogs and UI coordination remain in `MainWindow`; they delegate
actual reading and writing to the focused modules. Recent-project `QSettings`
helpers remain application-preference logic and are not part of Stage 3.

### Stage 4: Extract plotting

Move `PlotCanvas` intact to `plotting/canvas.py`, then separately extract
`overlay_renderer.py`, `layout.py`, and `chart_renderers.py`. Preserve public
methods during every step.

### Stage 5: Make `.ui` authoritative

Move fixed runtime-created controls and dialog shells to `.ui` files, regenerate
the generated Python modules, and reduce `_bind_ui_widgets` to aliases and
runtime initialization.

### Stage 6: Reduce MainWindow

Extract table behavior and dialog coordination. Keep `MainWindow` as the
application coordinator and retain `app.MainWindow` as a compatibility export.

### Stage 7: Final cleanup

Remove compatibility aliases only if they are proven unnecessary and explicitly
approved. Update README architecture documentation, test counts, commands, and
UI workflow. Record final file sizes and test timings against the baseline.

## Phase Gates and Rollback

Each stage is a separate commit or short series of focused commits. A stage is
complete only when:

1. Focused tests pass.
2. The full suite passes.
3. Generated UI files match their `.ui` sources when UI files are involved.
4. The working tree contains no unrelated changes.
5. `app.py` compatibility imports used by existing tests still work.

The pre-refactor state is recoverable through `main`, the retained
`codex/top-toolbar-inspector` branch, and the annotated tag
`backup/pre-app-refactor-2026-06-19`.

## Out of Scope

- Redesigning chart appearance or application workflows.
- Changing the current `.eg` container or current settings field names.
- Supporting or migrating retired project/template settings fields.
- Replacing PySide6, Matplotlib, Seaborn, or `unittest`.
- Converting all dynamic, data-dependent UI rows into static `.ui` widgets.
- Removing compatibility exports during the initial refactor.
