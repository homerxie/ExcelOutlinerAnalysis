# Extract Settings Module Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move `ChartSettings`, visual presets, and settings-schema constants into a GUI-independent `easygraph.settings` module while preserving every existing `app.*` import.

**Architecture:** Create an empty `easygraph` package and a dependency-light settings module that imports only standard-library dataclass features. `src/app.py` explicitly imports and therefore re-exports the moved names. Qt style mappings, plotting layout constants, Excel row markers, palette-cache paths, and I/O functions remain in `app.py` for later focused extraction.

**Tech Stack:** Python 3.10 dataclasses, PySide6 application compatibility, `unittest`

---

## Extraction Boundary

Move these names to `src/easygraph/settings.py`:

```text
PRESETS
STAT_TABLE_OPTIONS
SEQUENTIAL_PALETTE_PRESETS
DEFAULT_OVERLAY_PALETTE
LINE_OVERLAY_RENDER_STYLES
LINE_OVERLAY_STYLES
LEGEND_POSITION_RIGHT
LEGEND_POSITION_INSIDE
LEGEND_INSIDE_AUTO_POSITION
ChartSettings
STYLE_TEMPLATE_CONTENT_FIELDS
GROUP_COLOR_TEMPLATE_KEY_PREFIX
```

Keep these categories in `app.py`:

- `LINE_OVERLAY_STYLE_TO_MPL`, `LINE_OVERLAY_STYLE_TO_QT`, and Qt icon sizes.
- palette-cache paths, Lab/color calculations, and palette expansion logic.
- Excel overlay row markers and project/template I/O functions.
- legend geometry constants used by rendering rather than serialized settings.
- all Qt widgets and Matplotlib rendering code.

### Task 1: Define the settings-module compatibility contract

**Files:**
- Create: `src/easygraph/__init__.py`
- Create: `tests/test_settings_module.py`

- [ ] **Step 1: Create the package marker**

Create `src/easygraph/__init__.py`:

```python
"""EasyGraph application modules."""
```

- [ ] **Step 2: Write failing compatibility and dependency tests**

Create `tests/test_settings_module.py`:

```python
import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class SettingsModuleTests(EasyGraphTestCase):
    def test_app_reexports_settings_module_api(self):
        from easygraph import settings

        exported_names = (
            "PRESETS",
            "STAT_TABLE_OPTIONS",
            "SEQUENTIAL_PALETTE_PRESETS",
            "DEFAULT_OVERLAY_PALETTE",
            "LINE_OVERLAY_RENDER_STYLES",
            "LINE_OVERLAY_STYLES",
            "LEGEND_POSITION_RIGHT",
            "LEGEND_POSITION_INSIDE",
            "LEGEND_INSIDE_AUTO_POSITION",
            "ChartSettings",
            "STYLE_TEMPLATE_CONTENT_FIELDS",
            "GROUP_COLOR_TEMPLATE_KEY_PREFIX",
        )

        for name in exported_names:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(settings, name))

    def test_settings_module_imports_without_gui_or_plotting_stack(self):
        env = os.environ.copy()
        env["PYTHONPATH"] = str(ROOT / "src")
        code = """
import sys
from easygraph.settings import ChartSettings, PRESETS
assert ChartSettings().preset in PRESETS
assert not any(name == 'PySide6' or name.startswith('PySide6.') for name in sys.modules)
assert not any(name == 'matplotlib' or name.startswith('matplotlib.') for name in sys.modules)
"""

        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
```

- [ ] **Step 3: Run RED and verify both failures are meaningful**

Run:

```bash
./.venv/bin/python -m unittest tests.test_settings_module -v
```

Expected:

- the re-export test errors because `easygraph.settings` does not exist;
- the subprocess exits nonzero for the same missing module;
- neither failure is caused by a syntax error in the test.

- [ ] **Step 4: Commit the RED contract tests**

Do not commit a permanently failing intermediate state. Proceed directly to
Task 2 after recording RED output; commit the package marker and tests together
with the GREEN implementation.

### Task 2: Move settings definitions and preserve `app` exports

**Files:**
- Create: `src/easygraph/settings.py`
- Modify: `src/app.py`
- Include from Task 1: `src/easygraph/__init__.py`, `tests/test_settings_module.py`

- [ ] **Step 1: Create the dependency-light settings module**

Start `src/easygraph/settings.py` with:

```python
from __future__ import annotations

from dataclasses import dataclass, field

LEGEND_POSITION_RIGHT = "right"
LEGEND_POSITION_INSIDE = "inside"
LEGEND_INSIDE_AUTO_POSITION = -1.0
```

Move the audited definitions from `app.py` into this module without changing
their values or `ChartSettings.__post_init__` behavior. Preserve their logical
order:

```text
PRESETS
STAT_TABLE_OPTIONS
SEQUENTIAL_PALETTE_PRESETS
DEFAULT_OVERLAY_PALETTE
LINE_OVERLAY_RENDER_STYLES
LINE_OVERLAY_STYLES
ChartSettings
STYLE_TEMPLATE_CONTENT_FIELDS
GROUP_COLOR_TEMPLATE_KEY_PREFIX
```

End the module with:

```python
__all__ = [
    "ChartSettings",
    "DEFAULT_OVERLAY_PALETTE",
    "GROUP_COLOR_TEMPLATE_KEY_PREFIX",
    "LEGEND_INSIDE_AUTO_POSITION",
    "LEGEND_POSITION_INSIDE",
    "LEGEND_POSITION_RIGHT",
    "LINE_OVERLAY_RENDER_STYLES",
    "LINE_OVERLAY_STYLES",
    "PRESETS",
    "SEQUENTIAL_PALETTE_PRESETS",
    "STAT_TABLE_OPTIONS",
    "STYLE_TEMPLATE_CONTENT_FIELDS",
]
```

- [ ] **Step 2: Import and re-export from `app.py`**

After third-party/Qt imports and before the first use of these constants, add:

```python
from easygraph.settings import (
    ChartSettings,
    DEFAULT_OVERLAY_PALETTE,
    GROUP_COLOR_TEMPLATE_KEY_PREFIX,
    LEGEND_INSIDE_AUTO_POSITION,
    LEGEND_POSITION_INSIDE,
    LEGEND_POSITION_RIGHT,
    LINE_OVERLAY_RENDER_STYLES,
    LINE_OVERLAY_STYLES,
    PRESETS,
    SEQUENTIAL_PALETTE_PRESETS,
    STAT_TABLE_OPTIONS,
    STYLE_TEMPLATE_CONTENT_FIELDS,
)
```

Delete the corresponding original definitions from `app.py`. Remove
`dataclass` and `field` from the `dataclasses` import there, retaining `asdict`,
`fields`, and any other still-used names.

- [ ] **Step 3: Run GREEN settings tests**

Run:

```bash
./.venv/bin/python -m unittest tests.test_settings_module -v
```

Expected: two tests pass. The subprocess must prove the settings module itself
does not load PySide6 or Matplotlib.

- [ ] **Step 4: Run focused compatibility tests**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 5 \
  tests.test_data.DataTests.test_default_jitter_mode_is_quasirandom \
  tests.test_palette.PaletteTests.test_all_preset_palettes_expand_for_many_groups \
  tests.test_project_io.ProjectIOTests.test_project_roundtrip_preserves_new_settings \
  tests.test_core.EasyGraphCoreTests.test_apply_settings_keeps_loaded_custom_group_colors
```

Expected: four tests pass through the unchanged `app.*` compatibility API.

- [ ] **Step 5: Run static boundary checks**

Run:

```bash
./.venv/bin/python -m py_compile src/easygraph/__init__.py src/easygraph/settings.py src/app.py tests/test_settings_module.py
rg -n "^class ChartSettings|^PRESETS =|^STAT_TABLE_OPTIONS =|^STYLE_TEMPLATE_CONTENT_FIELDS =" src/app.py
```

Expected: compilation succeeds and `rg` finds no local definitions in
`app.py`; the names remain available only through the explicit import.

- [ ] **Step 6: Commit the settings extraction**

```bash
git add src/easygraph/__init__.py src/easygraph/settings.py src/app.py tests/test_settings_module.py
git commit -m "refactor: extract settings module"
```

### Task 3: Document and fully verify the module boundary

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update architecture and test inventory**

In README:

- Add `src/easygraph/settings.py` as the owner of `ChartSettings`, presets, and
  settings constants.
- Clarify `src/app.py` remains the executable compatibility facade and still
  re-exports settings names.
- Add `tests/test_settings_module.py` to the inventory and compile command.
- Change the expected count from 237 to 239.
- Do not claim data, palette, plotting, I/O, or MainWindow extraction is done.

- [ ] **Step 2: Measure file sizes for handoff**

Run:

```bash
wc -l src/app.py src/easygraph/settings.py
```

Report exact counts in the phase handoff, not as a permanent README metric.

- [ ] **Step 3: Run complete verification**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 20
./.venv/bin/python -m py_compile \
  src/app.py src/easygraph/__init__.py src/easygraph/settings.py \
  tests/test_architecture.py tests/test_settings_module.py \
  tests/easygraph_case.py tests/test_data.py tests/test_palette.py \
  tests/test_project_io.py tests/test_core.py tests/test_support.py \
  tests/test_warning_policy.py tests/test_test_runner.py scripts/run_tests.py
./.venv/bin/pyside6-uic ui/main_window.ui -o /tmp/easygraph_ui_main_window.py
cmp src/ui_main_window.py /tmp/easygraph_ui_main_window.py
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o /tmp/easygraph_ui_group_order_dialog.py
cmp src/ui_group_order_dialog.py /tmp/easygraph_ui_group_order_dialog.py
git diff --check
```

Expected: 239 tests pass, both generated UI comparisons are exact, compilation
succeeds, and diff check is clean.

- [ ] **Step 4: Commit documentation**

```bash
git add README.md
git commit -m "docs: describe settings module"
```

## Final Review Checklist

- [ ] `easygraph.settings` imports without PySide6 or Matplotlib.
- [ ] `app.ChartSettings is easygraph.settings.ChartSettings` and the same
      identity rule holds for every moved constant.
- [ ] Serialized project/template behavior remains unchanged.
- [ ] No settings definition is duplicated in `app.py`.
- [ ] No production caller was forced to change from `app.*` imports.
- [ ] Full suite reports 239 passing tests.
