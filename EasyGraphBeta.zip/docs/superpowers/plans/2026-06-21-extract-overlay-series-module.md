# Extract Overlay Series Module Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move the 22 data-, statistics-, color-, and line-style-policy helpers for overlays into `easygraph.overlay_series` while preserving behavior and the existing `app.*` API.

**Architecture:** `easygraph.overlay_series` owns only pure overlay series construction and policy. It may use NumPy, pandas, QtGui `QColor`, settings, and palette helpers, but it must not import Qt Widgets or any plotting stack; rendering, label layout, line-style preview icons, and all UI remain in `app.py`. `app.py` explicitly imports the same 22 function objects so callers retain identity without wrappers.

**Tech Stack:** Python 3.10, NumPy, pandas, PySide6 QtGui, `unittest`

---

## File Structure and Extraction Boundary

- Create `src/easygraph/overlay_series.py`: overlay series construction, visibility, statistics-table data, overlay color allocation, and overlay render-style selection.
- Modify `src/app.py`: explicitly re-export all 22 moved functions and delete only their original definitions.
- Create `tests/test_overlay_series_module.py`: exact ownership/re-export contract and direct-import boundary tests in normal and optimized Python.
- Modify `README.md`: document the new ownership boundary, file inventory, compile command, and 247-test total.
- Do not modify `ui/main_window.ui`, `ui/group_order_dialog.ui`, `src/ui_main_window.py`, or `src/ui_group_order_dialog.py`.
- Do not move app-local constants, Matplotlib rendering, overlay label positioning/collision logic, `overlay_line_style`, `draw_line_style_preview`, `line_style_icon`, Qt painting/icon code, or `MainWindow` behavior.

Move exactly these 22 functions, preserving signatures and bodies:

```text
line_overlay_series
visible_custom_overlay_indexes
all_custom_overlay_indexes
overlay_palette_for
stat_overlay_color
default_overlay_color
overlay_color_map_for_series
overlay_color_map_for_keys
all_overlay_color_keys
overlay_palette_slot_for_color_key
overlay_color_items
overlay_style_items
overlay_stat_color_key
overlay_custom_color_key
group_overlay_statistics
stat_table_header_required
stat_table_header_enabled
stat_table_data
format_overlay_value
custom_overlay_style_for_key
auto_overlay_style
overlay_style_for_series
```

The new module imports settings only as follows:

```python
from easygraph.settings import (
    ChartSettings,
    DEFAULT_OVERLAY_PALETTE,
    LINE_OVERLAY_RENDER_STYLES,
    LINE_OVERLAY_STYLES,
    PRESETS,
)
```

It imports palette helpers only as follows:

```python
from easygraph.palette import (
    expanded_preset_palette,
    first_unused_palette_color,
    normalize_color_name,
)
```

Allowed third-party dependencies are NumPy, pandas, and `PySide6.QtGui.QColor`. Forbidden dependencies are `PySide6.QtWidgets`, Matplotlib, Seaborn, and SciPy.

### Task 1: Define ownership, compatibility, and import boundaries (RED)

**Files:**
- Create: `tests/test_overlay_series_module.py`

- [ ] **Step 1: Write the failing module-contract tests**

Create `tests/test_overlay_series_module.py` with exactly three tests:

```python
import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class OverlaySeriesModuleTests(EasyGraphTestCase):
    PUBLIC_EXPORTS = (
        "line_overlay_series",
        "visible_custom_overlay_indexes",
        "all_custom_overlay_indexes",
        "overlay_palette_for",
        "stat_overlay_color",
        "default_overlay_color",
        "overlay_color_map_for_series",
        "overlay_color_map_for_keys",
        "all_overlay_color_keys",
        "overlay_palette_slot_for_color_key",
        "overlay_color_items",
        "overlay_style_items",
        "overlay_stat_color_key",
        "overlay_custom_color_key",
        "group_overlay_statistics",
        "stat_table_header_required",
        "stat_table_header_enabled",
        "stat_table_data",
        "format_overlay_value",
        "custom_overlay_style_for_key",
        "auto_overlay_style",
        "overlay_style_for_series",
    )

    def test_app_reexports_exact_overlay_series_api(self):
        from easygraph import overlay_series

        self.assertEqual(overlay_series.__all__, list(self.PUBLIC_EXPORTS))
        for name in self.PUBLIC_EXPORTS:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(overlay_series, name))

    def _run_direct_import_contract(self, *, optimized: bool) -> None:
        source_path = str(ROOT / "src")
        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = source_path + (
            os.pathsep + existing_pythonpath if existing_pythonpath else ""
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
import pandas as pd
from easygraph.overlay_series import (
    line_overlay_series,
    overlay_color_map_for_keys,
    stat_table_data,
)
from easygraph.settings import ChartSettings

frame = pd.DataFrame({{
    "group": ["A", "A", "B", "B"],
    "value": [1.0, 3.0, 5.0, 7.0],
}})
settings = ChartSettings(
    line_overlay_stat="Median",
    extra_custom_overlay=True,
    custom_overlay_palette="Dark Slide",
    custom_overlay_series=[{{
        "name": "Target",
        "values": {{"A": "10", "B": "20"}},
    }}],
    show_stat_table=True,
    show_stat_mean=True,
    show_stat_median=False,
    show_stat_max=False,
    show_stat_min=False,
)
series = line_overlay_series(frame, settings)
if [item["name"] for item in series] != ["Median", "Target"]:
    raise SystemExit("unexpected overlay series")
groups, rows = stat_table_data(frame, settings)
if groups != ["A", "B"] or rows != [("Mean", ["2.00", "6.00"])]:
    raise SystemExit("unexpected statistics table")
colors = overlay_color_map_for_keys(["custom:0"], settings)
if list(colors) != ["custom:0"] or not colors["custom:0"].startswith("#"):
    raise SystemExit("unexpected overlay color map")
if "PySide6.QtWidgets" in sys.modules:
    raise SystemExit("QtWidgets imported")
for forbidden in ("matplotlib", "seaborn", "scipy"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit(forbidden + " imported")
"""
        command = [sys.executable]
        if optimized:
            command.append("-O")
        command.extend(["-c", code])
        result = subprocess.run(
            command,
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=False,
            timeout=15,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_direct_import_runs_overlay_contract_without_ui_or_plotting(self):
        self._run_direct_import_contract(optimized=False)

    def test_optimized_direct_import_keeps_overlay_contract_effective(self):
        self._run_direct_import_contract(optimized=True)
```

The subprocess intentionally uses explicit `SystemExit` checks instead of bare
`assert`, so the same behavioral and dependency contract remains active under
`python -O`.

- [ ] **Step 2: Run the new tests and verify meaningful RED**

Run:

```bash
./.venv/bin/python -m unittest tests.test_overlay_series_module -v
```

Expected: all three tests error or fail because `easygraph.overlay_series` does
not exist. The failure must be the missing module, not a syntax or fixture error.
Keep this RED test file uncommitted so the next task can commit tests and the
working implementation together.

- [ ] **Step 3: Confirm existing tests do not patch the old owner**

Run:

```bash
rg -n "mock\.patch|patch\.object" tests/test_data.py tests/test_palette.py tests/test_core.py
```

Expected: no patch targets any of the 22 moved helper names. Therefore no
existing test adaptation is planned. If implementation reveals a missed patch,
change only that patch target from `app` to `easygraph.overlay_series`, because
the extracted function's globals belong to the new module; do not add wrappers
or weaken identity assertions.

### Task 2: Extract the implementation and preserve `app` identity (GREEN)

**Files:**
- Create: `src/easygraph/overlay_series.py`
- Modify: `src/app.py:5717-5968`
- Modify: `src/app.py:6103-6119`
- Include: `tests/test_overlay_series_module.py`
- Test: `tests/test_data.py`
- Test: `tests/test_palette.py`

- [ ] **Step 1: Create the focused module header**

Start `src/easygraph/overlay_series.py` with:

```python
from __future__ import annotations

import numpy as np
import pandas as pd
from PySide6.QtGui import QColor

from easygraph.palette import (
    expanded_preset_palette,
    first_unused_palette_color,
    normalize_color_name,
)
from easygraph.settings import (
    ChartSettings,
    DEFAULT_OVERLAY_PALETTE,
    LINE_OVERLAY_RENDER_STYLES,
    LINE_OVERLAY_STYLES,
    PRESETS,
)
```

Do not import anything from `app`; that would invert the dependency and re-load
the GUI/plotting stack during direct module import.

- [ ] **Step 2: Move the 22 bodies without behavioral edits**

Cut the exact 22 functions listed in the extraction boundary from `src/app.py`
and paste them after the module imports. Preserve their signatures, type hints,
control flow, literal values, and ordering. In particular, keep the nested
`formatted`, `sample_sd`, and `sample_sem` helpers inside `stat_table_data`;
they are implementation details, not additional module exports.

Leave the intervening functions beginning with `overlay_label_bbox`,
`overlay_label_arrow`, `overlay_line_style`, `overlay_line_qt_pen_style`,
`draw_line_style_preview`, and `line_style_icon` in `app.py`. Also leave all
functions beginning with `overlay_label_position_for_series` and later label
layout/rendering functions in `app.py`.

- [ ] **Step 3: Add the exact public export surface**

End `src/easygraph/overlay_series.py` with:

```python
__all__ = [
    "line_overlay_series",
    "visible_custom_overlay_indexes",
    "all_custom_overlay_indexes",
    "overlay_palette_for",
    "stat_overlay_color",
    "default_overlay_color",
    "overlay_color_map_for_series",
    "overlay_color_map_for_keys",
    "all_overlay_color_keys",
    "overlay_palette_slot_for_color_key",
    "overlay_color_items",
    "overlay_style_items",
    "overlay_stat_color_key",
    "overlay_custom_color_key",
    "group_overlay_statistics",
    "stat_table_header_required",
    "stat_table_header_enabled",
    "stat_table_data",
    "format_overlay_value",
    "custom_overlay_style_for_key",
    "auto_overlay_style",
    "overlay_style_for_series",
]
```

- [ ] **Step 4: Explicitly re-export the same objects from `app.py`**

After the existing `easygraph.palette` import block and before the
`easygraph.data` block, add:

```python
from easygraph.overlay_series import (
    all_custom_overlay_indexes,
    all_overlay_color_keys,
    auto_overlay_style,
    custom_overlay_style_for_key,
    default_overlay_color,
    format_overlay_value,
    group_overlay_statistics,
    line_overlay_series,
    overlay_color_items,
    overlay_color_map_for_keys,
    overlay_color_map_for_series,
    overlay_custom_color_key,
    overlay_palette_for,
    overlay_palette_slot_for_color_key,
    overlay_stat_color_key,
    overlay_style_for_series,
    overlay_style_items,
    stat_overlay_color,
    stat_table_data,
    stat_table_header_enabled,
    stat_table_header_required,
    visible_custom_overlay_indexes,
)
```

Use direct imports only. Do not create wrappers, assignments to replacement
functions, lazy imports, or wildcard imports. Keep `np`, `pd`, and `QColor` in
`app.py`: substantial unmoved code still uses them. Keep the imported settings
and palette names already present in `app.py` because unmoved UI and rendering
code and the compatibility surface still use them.

- [ ] **Step 5: Run the new contract tests (GREEN)**

Run:

```bash
./.venv/bin/python -m unittest tests.test_overlay_series_module -v
```

Expected: `Ran 3 tests` and `OK`, including the optimized subprocess case.

- [ ] **Step 6: Run focused data and palette regressions**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 10 tests.test_data tests.test_palette
```

Expected: the existing data and palette suites pass with no new warnings. Do
not update expected values: extraction must not change series order, hidden
overlay handling, statistics, colors, or style cycling.

- [ ] **Step 7: Verify syntax, ownership, and dependency direction**

Run:

```bash
./.venv/bin/python -m py_compile src/easygraph/overlay_series.py src/app.py tests/test_overlay_series_module.py
rg -n "^def (line_overlay_series|visible_custom_overlay_indexes|all_custom_overlay_indexes|overlay_palette_for|stat_overlay_color|default_overlay_color|overlay_color_map_for_series|overlay_color_map_for_keys|all_overlay_color_keys|overlay_palette_slot_for_color_key|overlay_color_items|overlay_style_items|overlay_stat_color_key|overlay_custom_color_key|group_overlay_statistics|stat_table_header_required|stat_table_header_enabled|stat_table_data|format_overlay_value|custom_overlay_style_for_key|auto_overlay_style|overlay_style_for_series)\b" src/app.py
rg -n "PySide6\.QtWidgets|matplotlib|seaborn|scipy|from app|import app" src/easygraph/overlay_series.py
```

Expected: compile succeeds and both `rg` commands return no matches. The first
search proves the 22 functions no longer have local definitions in `app.py`;
the second proves the module does not cross the UI/plotting boundary.

- [ ] **Step 8: Run the complete suite**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 20
```

Expected: `Ran 247 tests` and `OK` (244 existing tests plus three new contract
tests).

- [ ] **Step 9: Commit the working extraction**

Run:

```bash
git add src/easygraph/overlay_series.py src/app.py tests/test_overlay_series_module.py
git commit -m "refactor: extract overlay series module"
```

Expected: one commit containing the RED contract tests and GREEN extraction,
with no README or UI changes.

### Task 3: Document the boundary and run final verification

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update the file inventory and ownership descriptions**

Make these exact documentation changes:

- Add `src/easygraph/overlay_series.py` beside the other `easygraph` modules in
  the Main Files tree.
- Add `tests/test_overlay_series_module.py` beside the other module-contract
  tests.
- Describe `overlay_series.py` as owner of overlay series construction,
  visibility, statistics-table data, color allocation, and line-style policy.
- State that it uses QtGui `QColor` but imports neither Qt Widgets nor the
  plotting stack.
- Update the `app.py` description to say it explicitly re-exports overlay
  series helpers for compatibility while continuing to own rendering, label
  layout, Qt line-style previews/icons, file I/O, table behavior, and
  `MainWindow`.
- Describe `tests/test_overlay_series_module.py` as the ownership, compatibility
  re-export, behavior, optimized-Python, and import-boundary contract.
- Add `src/easygraph/overlay_series.py` and
  `tests/test_overlay_series_module.py` to the compile command.
- Change the documented full-suite count from 244 to 247.
- Do not claim that `plotting/overlay_renderer.py`, Matplotlib overlay drawing,
  label layout, Qt icons, or any UI has already been extracted.

- [ ] **Step 2: Compile every documented Python entry point**

Run the README compile command after updating it. It must be:

```bash
./.venv/bin/python -m py_compile src/app.py src/easygraph/data.py src/easygraph/overlay_series.py src/easygraph/palette.py src/easygraph/settings.py src/ui_main_window.py src/ui_group_order_dialog.py tests/easygraph_case.py tests/test_architecture.py tests/test_data.py tests/test_data_module.py tests/test_overlay_series_module.py tests/test_palette.py tests/test_palette_module.py tests/test_project_io.py tests/test_settings_module.py tests/test_core.py tests/test_support.py tests/test_warning_policy.py tests/test_test_runner.py scripts/run_tests.py
```

Expected: exit status 0 and no output.

- [ ] **Step 3: Regenerate both UI modules to temporary files and compare**

Run:

```bash
tmp_main=$(mktemp)
./.venv/bin/pyside6-uic ui/main_window.ui -o "$tmp_main"
cmp -s "$tmp_main" src/ui_main_window.py
rm "$tmp_main"

tmp_group=$(mktemp)
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o "$tmp_group"
cmp -s "$tmp_group" src/ui_group_order_dialog.py
rm "$tmp_group"
```

Expected: every command exits 0 with no comparison output. This verifies the
generated Python still exactly matches its `.ui` source without modifying
either generated file.

- [ ] **Step 4: Run static/AST ownership and import-boundary gates**

Run:

```bash
./.venv/bin/python -c 'import ast, pathlib, sys; names=set("line_overlay_series visible_custom_overlay_indexes all_custom_overlay_indexes overlay_palette_for stat_overlay_color default_overlay_color overlay_color_map_for_series overlay_color_map_for_keys all_overlay_color_keys overlay_palette_slot_for_color_key overlay_color_items overlay_style_items overlay_stat_color_key overlay_custom_color_key group_overlay_statistics stat_table_header_required stat_table_header_enabled stat_table_data format_overlay_value custom_overlay_style_for_key auto_overlay_style overlay_style_for_series".split()); tree=ast.parse(pathlib.Path("src/app.py").read_text()); found=sorted(node.name for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names); print("app ownership OK") if not found else sys.exit("local moved definitions remain: " + ", ".join(found))'
rg -n "PySide6\.QtWidgets|matplotlib|seaborn|scipy|from app|import app" src/easygraph/overlay_series.py
```

Expected: the AST command prints `app ownership OK`; `rg` returns no matches.
The normal and optimized subprocess contract tests remain the executable import
boundary check.

- [ ] **Step 5: Run final regression and cleanliness gates**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 20
git diff --check
wc -l src/app.py src/easygraph/overlay_series.py
git status --short
```

Expected: 247 tests pass; `git diff --check` is silent; line counts show
`app.py` decreased and the focused module is substantially smaller; status
shows only the intended README change after the implementation commit.

- [ ] **Step 6: Commit documentation**

Run:

```bash
git add README.md
git commit -m "docs: describe overlay series module"
```

Expected: a documentation-only commit.

## Final Review Checklist

- [ ] The new module owns exactly the 22 approved functions and has exactly the
      22-name `__all__` in the contract-tested order.
- [ ] Every `app.<moved_name>` object is identical to the corresponding
      `easygraph.overlay_series` object; there are no compatibility wrappers.
- [ ] No app-local constants, rendering, label layout, Qt preview/icon logic,
      `MainWindow` behavior, `.ui`, or generated UI Python moved.
- [ ] The module directly imports only the approved settings and palette names,
      NumPy, pandas, and QtGui `QColor`.
- [ ] Neither normal nor optimized direct import loads Qt Widgets, Matplotlib,
      Seaborn, or SciPy.
- [ ] Existing data and palette behavior remains unchanged.
- [ ] Both generated UI modules compare byte-for-byte with fresh `.ui` output.
- [ ] The full suite reports 247 tests and all compile, AST, import-boundary,
      whitespace, and working-tree checks pass.
