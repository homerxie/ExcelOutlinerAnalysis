# Test Suite Decomposition Phase 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Split the first pure-test domains out of `tests/test_core.py` and remove unnecessary initial Matplotlib renders from a conservative group of UI-only tests while preserving all 235 behaviors.

**Architecture:** Introduce reusable non-Qt and Qt-aware test bases without moving application code. Move existing test methods byte-for-byte according to explicit manifests into data, palette, and project-I/O modules. Add a `make_window()` helper whose default is `initial_render=False`, then adopt it only in tests that do not require an already-rendered axis.

**Tech Stack:** Python 3.10, `unittest`, PySide6, Matplotlib, existing `scripts/run_tests.py`

---

## File Structure

- Create `tests/easygraph_case.py`: application import setup, shared fixtures, Qt fixture, window factory, and `patch_qsettings`.
- Create `tests/test_data.py`: pure table transformation, grouping, outlier, overlay-series, and statistics tests.
- Create `tests/test_palette.py`: pure palette, overlay color, and line-style policy tests.
- Create `tests/test_project_io.py`: pure project/template/Excel format tests.
- Modify `tests/test_core.py`: consume shared fixtures, remove methods moved to domain modules, and use the no-initial-render factory in the approved UI-only manifest.
- Modify `README.md`: document the first decomposed modules and record the measured full-suite time.

## Invariants

1. Test count remains exactly 235 throughout method relocation.
2. A moved test body and name are unchanged except for imports and class indentation.
3. No production file or `.ui` file changes in this plan.
4. `app.MainWindow()` production behavior remains unchanged.
5. Tests not listed in the UI-only manifest retain their current `app.MainWindow()` construction.
6. Every created window is registered with `addCleanup(window.close)` through the shared factory.

### Task 1: Add shared application test cases

**Files:**
- Create: `tests/easygraph_case.py`
- Modify: `tests/test_core.py:1-45`

- [ ] **Step 1: Record the pre-change focused and discovery baseline**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 3 \
  tests.test_core.EasyGraphCoreTests.test_wide_table_is_converted_to_plot_data \
  tests.test_core.EasyGraphCoreTests.test_combo_boxes_expand_for_long_options \
  tests.test_core.EasyGraphCoreTests.test_plot_frame_has_four_sides_with_and_without_secondary_axis
./.venv/bin/python -m unittest discover -s tests -t . -q
```

Expected: the focused three tests pass and discovery reports 235 passing tests.

- [ ] **Step 2: Create the shared fixture module**

Create `tests/easygraph_case.py` with:

```python
from __future__ import annotations

import pathlib
import sys
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tests.test_support import WarningConfiguredTestCase

import app


def patch_qsettings(values=None):
    values = {} if values is None else values

    class FakeSettings:
        def __init__(self, *args):
            pass

        def value(self, key, default=None):
            return values.get(key, default)

        def setValue(self, key, value):
            values[key] = value

    return mock.patch.object(app, "QSettings", FakeSettings), values


class EasyGraphTestCase(WarningConfiguredTestCase):
    def setUp(self):
        super().setUp()
        self.settings = app.ChartSettings()
        self.df = app.sample_data()


class EasyGraphQtTestCase(EasyGraphTestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.qapp = app.QApplication.instance() or app.QApplication([])

    def make_window(self, *, initial_render: bool = False):
        window = app.MainWindow(initial_render=initial_render)
        self.addCleanup(window.close)
        return window
```

- [ ] **Step 3: Refactor `test_core.py` to use the shared Qt base**

Replace local path setup, `import app`, `patch_qsettings`, and the base fixture
methods with:

```python
from tests.easygraph_case import EasyGraphQtTestCase, app, patch_qsettings


class EasyGraphCoreTests(EasyGraphQtTestCase):
```

Keep imports such as `math`, `tempfile`, `SimpleNamespace`, `mock`, `QPoint`, and
`QStyleOptionSpinBox` that are still used by the remaining methods. Remove only
imports proven unused by `rg` or a compile check.

- [ ] **Step 4: Verify fixture equivalence**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 3 \
  tests.test_core.EasyGraphCoreTests.test_wide_table_is_converted_to_plot_data \
  tests.test_core.EasyGraphCoreTests.test_combo_boxes_expand_for_long_options \
  tests.test_core.EasyGraphCoreTests.test_plot_frame_has_four_sides_with_and_without_secondary_axis
./.venv/bin/python -m py_compile tests/easygraph_case.py tests/test_core.py
```

Expected: three tests pass and compilation exits 0.

- [ ] **Step 5: Commit shared fixtures**

```bash
git add tests/easygraph_case.py tests/test_core.py
git commit -m "test: share EasyGraph test fixtures"
```

### Task 2: Extract pure data tests

**Files:**
- Create: `tests/test_data.py`
- Modify: `tests/test_core.py`

- [ ] **Step 1: Create the destination class**

Start `tests/test_data.py` with:

```python
from tests.easygraph_case import EasyGraphTestCase, app


class DataTests(EasyGraphTestCase):
    pass
```

Run:

```bash
./.venv/bin/python -m unittest tests.test_data -v
```

Expected: `Ran 0 tests`. This verifies the module imports without Qt fixture
creation before moving methods.

- [ ] **Step 2: Move the exact data-test manifest**

Move these methods unchanged from `EasyGraphCoreTests` to `DataTests`, replacing
the temporary `pass`:

```python
DATA_TEST_METHODS = (
    "test_wide_table_is_converted_to_plot_data",
    "test_outlier_detection_finds_sample_high_dose_outlier",
    "test_box_whisker_modes_map_to_matplotlib_whis_values",
    "test_default_jitter_mode_is_quasirandom",
    "test_group_and_value_labels_map_by_chart_type",
    "test_group_filter_hides_groups_from_plot_data_without_deleting_table_data",
    "test_hidden_group_color_still_occupies_palette_color",
    "test_line_overlay_statistics_use_mean_or_median",
    "test_custom_overlay_series_can_create_multiple_plot_lines",
    "test_custom_overlay_series_can_use_secondary_axis",
    "test_stat_table_data_includes_selected_plot_statistics",
    "test_stat_table_defaults_to_mean_median_min_max",
    "test_duplicate_group_names_are_combined_for_plotting",
    "test_duplicate_group_names_sort_by_combined_values",
    "test_blank_project_data_has_three_empty_columns",
)
```

Do not leave forwarding wrappers or copies in `test_core.py`; discovery must see
each name exactly once.

- [ ] **Step 3: Verify the extracted module and total count**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 3 tests.test_data
./.venv/bin/python -m unittest discover -s tests -t . -q
```

Expected: `tests.test_data` runs 15 tests and full discovery remains 235.

- [ ] **Step 4: Commit data-test extraction**

```bash
git add tests/test_data.py tests/test_core.py
git commit -m "test: extract data tests"
```

### Task 3: Extract pure palette and overlay-style policy tests

**Files:**
- Create: `tests/test_palette.py`
- Modify: `tests/test_core.py`

- [ ] **Step 1: Create the destination module and move the manifest**

Create this header and move the listed methods unchanged beneath it:

```python
from tests.easygraph_case import EasyGraphTestCase, app


class PaletteTests(EasyGraphTestCase):
    pass


PALETTE_TEST_METHODS = (
    "test_extra_overlay_palette_defaults_to_mono_and_supports_custom_colors",
    "test_overlay_palette_skips_colors_already_used_by_custom_overlays",
    "test_filtering_custom_overlay_preserves_palette_slot_colors",
    "test_hidden_overlay_color_still_occupies_palette_color",
    "test_filtering_custom_overlay_preserves_palette_slot_colors_with_stat_line",
    "test_stat_overlay_uses_fixed_foreground_color",
    "test_stat_overlay_color_is_not_customizable",
    "test_stat_overlay_does_not_occupy_custom_overlay_palette_slot",
    "test_line_overlay_value_formatting",
    "test_extra_line_overlay_styles_map_to_custom_dash_patterns",
    "test_auto_line_overlay_style_cycles_render_styles",
    "test_custom_overlay_style_overrides_auto_line_style",
    "test_custom_group_color_sets_base_and_derives_point_color",
    "test_palette_expands_without_repeating_for_many_groups",
    "test_group_palette_skips_colors_already_used_by_custom_groups",
    "test_palette_choices_offer_extra_colors_for_current_group_count",
    "test_common_palette_counts_are_loaded_from_precomputed_cache",
    "test_palette_counts_over_precomputed_limit_use_dynamic_generation",
    "test_all_preset_palettes_expand_for_many_groups",
    "test_categorical_palette_extensions_keep_visual_distance",
    "test_sequential_palette_extensions_resample_existing_gradient",
    "test_monochrome_palette_expands_only_with_grayscale_colors",
    "test_expanded_palette_keeps_custom_group_color_override",
)
```

The tuple is a move manifest for implementation/review and must not be written
to the runtime test file. Replace `pass` with the actual 23 moved methods.

- [ ] **Step 2: Verify palette isolation and discovery**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 3 tests.test_palette
./.venv/bin/python -m unittest discover -s tests -t . -q
```

Expected: palette module runs 23 tests; total remains 235.

- [ ] **Step 3: Commit palette-test extraction**

```bash
git add tests/test_palette.py tests/test_core.py
git commit -m "test: extract palette tests"
```

### Task 4: Extract pure project and template format tests

**Files:**
- Create: `tests/test_project_io.py`
- Modify: `tests/test_core.py`

- [ ] **Step 1: Create the destination module with required imports**

Use this header:

```python
import pathlib
import tempfile

from tests.easygraph_case import EasyGraphTestCase, app


class ProjectIOTests(EasyGraphTestCase):
    pass
```

Add another standard-library import only when a moved method demonstrably uses
it. Do not import PySide6 widgets into this pure module.

- [ ] **Step 2: Move the exact project-I/O manifest**

Move these methods unchanged and remove them from `test_core.py`:

```python
PROJECT_IO_TEST_METHODS = (
    "test_excel_overlay_dataframe_roundtrip_preserves_custom_overlay_rows",
    "test_recent_project_paths_keep_newest_unique_and_limited",
    "test_project_roundtrip_preserves_new_settings",
    "test_style_template_roundtrip_preserves_settings",
    "test_style_template_does_not_save_custom_overlay_data",
    "test_style_template_load_ignores_legacy_custom_overlay_data",
    "test_style_template_group_colors_are_indexed_not_name_bound",
    "test_style_template_ignores_legacy_name_bound_group_colors",
    "test_import_style_template_copies_external_json",
)
```

Replace the temporary `pass` with the nine method bodies. Retain all dialog and
`MainWindow` file-action tests in `test_core.py`.

- [ ] **Step 3: Verify pure project tests and total count**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 3 tests.test_project_io
./.venv/bin/python -m unittest discover -s tests -t . -q
```

Expected: project-I/O module runs nine tests; total remains 235.

- [ ] **Step 4: Commit project-I/O extraction**

```bash
git add tests/test_project_io.py tests/test_core.py
git commit -m "test: extract project IO tests"
```

### Task 5: Skip initial rendering in conservative UI-only tests

**Files:**
- Modify: `tests/test_core.py`

- [ ] **Step 1: Replace construction only in the approved manifest**

Within the following test methods, replace each `app.MainWindow()` with
`self.make_window()` and make no other behavioral edit:

```python
UI_ONLY_NO_INITIAL_RENDER = (
    "test_combo_boxes_expand_for_long_options",
    "test_settings_forms_align_labels_left_and_values_right",
    "test_legend_layout_has_own_group_with_right_aligned_controls",
    "test_legend_auto_width_and_auto_columns_are_mutually_adjusted",
    "test_adjust_all_font_sizes_uses_office_like_steps",
    "test_adjust_all_font_sizes_updates_disabled_module_fonts",
    "test_right_sidebar_minimum_width_preserves_settings_rows",
    "test_single_line_controls_use_matching_heights",
    "test_line_style_combo_items_show_preview_icons",
    "test_settings_spinboxes_commit_keyboard_input_on_enter_or_focus_out",
    "test_group_color_button_sits_with_chart_toolbar_controls",
    "test_group_filter_button_is_defined_in_chart_group",
    "test_plot_object_selection_maps_to_context_sections",
    "test_plot_object_selection_focuses_related_inspector_groups",
    "test_plot_canvas_has_zoom_to_fit_button",
    "test_plot_canvas_keeps_coordinates_without_matplotlib_buttons",
    "test_trackpad_gesture_zoom_is_disabled",
    "test_user_preset_change_clears_custom_group_colors",
    "test_apply_settings_keeps_loaded_custom_group_colors",
    "test_apply_settings_does_not_overwrite_loaded_spinbox_values",
    "test_line_overlay_style_controls_disable_when_no_overlay_is_active",
    "test_overlay_label_position_controls_are_split_by_series_type",
    "test_axis_title_controls_use_logical_names",
    "test_custom_overlay_secondary_axis_control_toggles_secondary_range_controls",
    "test_value_axis_tick_interval_labels_follow_chart_type",
    "test_ridge_disables_x_tick_rotation_control",
    "test_ridge_secondary_x_axis_controls_support_split_frame",
    "test_table_undo_redo_actions_use_standard_shortcuts",
    "test_file_actions_use_platform_standard_shortcuts",
    "test_file_menu_contains_open_recent_submenu",
    "test_table_columns_are_user_resizable",
    "test_copy_table_selection_uses_tsv_for_excel",
    "test_copy_table_selection_quotes_multiline_group_names",
    "test_table_context_menu_contains_clipboard_actions_with_standard_shortcuts",
)
```

This manifest has 34 tests. Do not convert tests that inspect rendered artists,
axis limits, initial zoom, or figure geometry.

- [ ] **Step 2: Run the converted manifest as focused tests**

Run the 34 dotted names through `scripts/run_tests.py --slow 10`. Construct the
command directly from the manifest above so every converted test is included.

Expected: 34 tests pass, no Seaborn warning flood, and the slowest list contains
no duplicate test caused by discovery/import mistakes.

- [ ] **Step 3: Verify full count and measure the new runtime**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 20
```

Expected: all 235 tests pass. Record the exact duration and compare it to the
220.886-second baseline.

- [ ] **Step 4: Commit no-initial-render adoption**

```bash
git add tests/test_core.py
git commit -m "test: skip initial plots in UI-only cases"
```

### Task 6: Update test documentation and verify phase integrity

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update README test layout and measured count**

Update the Main Files or Testing section to list:

```text
tests/easygraph_case.py
tests/test_data.py
tests/test_palette.py
tests/test_project_io.py
tests/test_core.py
```

Keep the current expected count at 235. Add one sentence stating that
pure domain tests no longer initialize `QApplication`, and UI-only tests should
use `self.make_window()` unless they explicitly require an initial rendered
figure. Record the actual full-suite duration from Task 5 without claiming a
speedup unless it is lower than the 220.886-second baseline.

- [ ] **Step 2: Run all verification gates**

Run:

```bash
./.venv/bin/python -m py_compile \
  tests/easygraph_case.py tests/test_data.py tests/test_palette.py \
  tests/test_project_io.py tests/test_core.py
./.venv/bin/python scripts/run_tests.py --slow 20
./.venv/bin/pyside6-uic ui/main_window.ui -o /tmp/easygraph_ui_main_window.py
cmp src/ui_main_window.py /tmp/easygraph_ui_main_window.py
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o /tmp/easygraph_ui_group_order_dialog.py
cmp src/ui_group_order_dialog.py /tmp/easygraph_ui_group_order_dialog.py
git diff --check
```

Expected: 235 passing tests, both UI comparisons exact, compile success, and no
diff-check errors.

- [ ] **Step 3: Commit documentation**

```bash
git add README.md
git commit -m "docs: describe decomposed test suite"
```

## Final Review Checklist

- [ ] `rg -n '^class .*Tests' tests/test_*.py` shows each domain class once.
- [ ] Each moved test name appears exactly once across `tests/`.
- [ ] Pure domain classes inherit `EasyGraphTestCase`, not `EasyGraphQtTestCase`.
- [ ] `test_core.py` inherits `EasyGraphQtTestCase`.
- [ ] Only the 34 approved UI tests use `self.make_window()` in this phase.
- [ ] Full count is 235 and all tests pass.
- [ ] Production and `.ui` files are unchanged from plan start.
