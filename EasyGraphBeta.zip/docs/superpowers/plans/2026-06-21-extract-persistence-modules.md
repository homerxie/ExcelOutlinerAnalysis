# Extract Persistence Modules Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Split current-project ZIP persistence, style-template persistence, and spreadsheet persistence into three explicitly named modules while enforcing the approved current-fields-only settings policy and preserving the existing `app.*` API.

**Architecture:** `easygraph.project_io` owns `.eg` ZIP files and the strict `ChartSettings` dictionary codec; `easygraph.template_io` owns style-template JSON and indexed group-color mapping; `easygraph.spreadsheet_io` owns the overlay-row tabular format and actual CSV/Excel reads and writes. `app.py` remains the executable/UI coordinator and directly imports every migrated public object, so compatibility identity is preserved without wrappers; recent-project `QSettings` preferences stay in `app.py`.

**Tech Stack:** Python 3.10, pandas, PySide6 QtGui `QColor`, standard-library `json`/`zipfile`/`tempfile`, `unittest`

---

## Locked Boundaries and Resulting File Map

- Create `src/easygraph/project_io.py`: strict current-settings decoding plus `.eg` ZIP read/write.
- Create `src/easygraph/template_io.py`: style-template JSON, filename/list/import helpers, and indexed group-color mapping.
- Create `src/easygraph/spreadsheet_io.py`: overlay-row DataFrame format plus CSV/XLS/XLSX read and CSV/XLSX write helpers.
- Modify `src/app.py`: remove the migrated definitions/constants, directly import and re-export them, and leave dialogs, translated errors, state synchronization, current-project state, and recent-project preferences in place.
- Rewrite `tests/test_project_io.py` so it contains only `.eg`, strict-codec, and project-module contract tests.
- Create `tests/test_template_io.py`, `tests/test_spreadsheet_io.py`, and `tests/test_app_preferences.py` with the existing tests moved by responsibility before adding contracts.
- Modify `tests/test_core.py`: move the existing recent-project and spreadsheet tests, and change the legacy legend migration expectation into a current-default expectation.
- Modify `README.md`: record the three ownership boundaries and the final 256-test inventory.
- Do not modify `ui/main_window.ui`, `ui/group_order_dialog.ui`, `src/ui_main_window.py`, or `src/ui_group_order_dialog.py`.

The current baseline is commit `26d1d91` with 247 tests. Rehoming existing tests keeps 247. The three module phases add exactly three tests apiece:

| Phase | Added tests | Expected total |
|---|---:|---:|
| Test rehoming | 0 | 247 |
| `project_io.py` | 3 | 250 |
| `template_io.py` | 3 | 253 |
| `spreadsheet_io.py` | 3 | 256 |

### Strict settings policy

`chart_settings_from_dict(data)` is the only settings-dictionary codec. Its behavior is locked:

```python
def chart_settings_from_dict(data: dict) -> ChartSettings:
    if not isinstance(data, dict):
        raise ValueError("Chart settings must be a dictionary.")
    current_fields = {field.name for field in fields(ChartSettings)}
    unknown_fields = sorted(str(key) for key in data if key not in current_fields)
    if unknown_fields:
        raise ValueError(
            "Unknown ChartSettings fields: " + ", ".join(unknown_fields)
        )
    return ChartSettings(**data)
```

Consequences:

- Unknown and retired fields fail with a sorted field-name list.
- Missing current fields are omitted from the constructor and therefore use `ChartSettings` defaults.
- There is no `show_line_overlay` migration branch, no legacy legend-width branch, no filtered-dictionary fallback, and no post-construction mutation in the codec.
- Current consistency behavior remains centralized in `ChartSettings.__post_init__`.
- `show_line_overlay` itself is still a current dataclass field and is therefore accepted. A made-up retired key such as `legacy_show_line_overlay` is rejected.

### Exact public APIs

`easygraph.project_io.__all__` is exactly:

```python
[
    "chart_settings_from_dict",
    "read_project",
    "write_project",
]
```

`easygraph.template_io.__all__` is exactly 13 names: two constants and the 11 existing functions (the approved inventory was “12” provisionally; source inspection confirms 11 functions):

```python
[
    "TEMPLATE_DIR",
    "TEMPLATE_NONE_NAME",
    "apply_style_template_settings",
    "group_colors_for_target_groups",
    "import_style_template",
    "indexed_group_colors_from_settings",
    "list_style_templates",
    "read_style_template",
    "read_style_template_file",
    "style_template_settings_data",
    "template_file_name",
    "template_indexed_group_colors",
    "write_style_template",
]
```

`easygraph.spreadsheet_io.__all__` is exactly:

```python
[
    "OVERLAY_EXPORT_CUSTOM_ROW",
    "OVERLAY_EXPORT_NAME_COLUMN",
    "OVERLAY_EXPORT_ROW_TYPE_COLUMN",
    "OVERLAY_EXPORT_SAMPLE_ROW",
    "excel_export_dataframe",
    "excel_import_parts",
    "read_spreadsheet",
    "write_spreadsheet",
]
```

Every name above is explicitly imported by `app.py`; tests assert `app.name is module.name`. Do not use wrappers, duplicate constants, wildcard imports, module-level forwarding via `__getattr__`, or replacement assignments.

## Task 1: Rehome Existing Tests by Responsibility

**Files:**
- Modify: `tests/test_project_io.py`
- Create: `tests/test_template_io.py`
- Create: `tests/test_spreadsheet_io.py`
- Create: `tests/test_app_preferences.py`
- Modify: `tests/test_core.py`

- [ ] **Step 1: Reduce `test_project_io.py` to the project round-trip test**

Keep the existing imports required by `test_project_roundtrip_preserves_new_settings`, the `ProjectIOTests(EasyGraphTestCase)` class, and that test body unchanged. Move, rather than copy, the other eight tests. At this step `tests/test_project_io.py` has exactly one test.

- [ ] **Step 2: Move the six template-policy tests into `test_template_io.py`**

Create `TemplateIOTests(EasyGraphTestCase)` and move these bodies without behavioral edits:

```text
test_style_template_roundtrip_preserves_settings
test_style_template_does_not_save_custom_overlay_data
test_style_template_load_ignores_legacy_custom_overlay_data
test_style_template_group_colors_are_indexed_not_name_bound
test_style_template_ignores_legacy_name_bound_group_colors
test_import_style_template_copies_external_json
```

Use this import order so `tests.easygraph_case` installs `src` on `sys.path` before any future direct EasyGraph imports:

```python
import json
import pathlib
import tempfile

from tests.easygraph_case import EasyGraphTestCase, app
```

Rename two tests because their inputs contain current fields and the behavior is current template-content policy, not legacy-field compatibility:

```text
test_style_template_load_ignores_legacy_custom_overlay_data
  -> test_style_template_load_clears_content_overlay_data
test_style_template_ignores_legacy_name_bound_group_colors
  -> test_style_template_keeps_only_indexed_group_colors
```

Only names change here. Mechanically replace the five `app.json.dumps` /
`app.json.loads` references in the moved bodies with `json.dumps` /
`json.loads`; JSON is a test dependency, not part of the `app` compatibility
surface. All behavioral assertions remain identical.

- [ ] **Step 3: Move spreadsheet tests into `test_spreadsheet_io.py`**

Move `test_excel_overlay_dataframe_roundtrip_preserves_custom_overlay_rows` from `test_project_io.py` into `SpreadsheetIOTests(EasyGraphTestCase)`. Move these three UI integration tests from `test_core.py` into `SpreadsheetUIIntegrationTests(EasyGraphQtTestCase)`:

```text
test_export_excel_writes_overlay_rows
test_import_excel_restores_overlay_rows
test_import_plain_excel_clears_existing_overlay_rows
```

Use:

```python
import pathlib
import tempfile
from unittest import mock

from tests.easygraph_case import EasyGraphQtTestCase, EasyGraphTestCase, app
```

Preserve their bodies at this task. They still exercise `app.MainWindow`, dialogs, and the existing app-owned spreadsheet functions until Task 4.

- [ ] **Step 4: Move recent-project preference tests into `test_app_preferences.py`**

Move the helper test from `test_project_io.py` and the four recent-menu tests from `test_core.py`:

```text
test_recent_project_paths_keep_newest_unique_and_limited
test_file_menu_contains_open_recent_submenu
test_open_project_adds_path_to_recent_menu
test_open_recent_project_loads_file_and_moves_it_to_top
test_open_recent_project_removes_missing_file
```

Use `AppPreferenceTests(EasyGraphQtTestCase)` with:

```python
import pathlib
import tempfile
from unittest import mock

from tests.easygraph_case import EasyGraphQtTestCase, app, patch_qsettings
```

The helper-only test is allowed in the Qt-aware class to keep the file small. Do not move or change `RECENT_PROJECTS_SETTING_KEY`, `MAX_RECENT_PROJECTS`, `normalized_recent_project_paths`, `stored_recent_project_paths`, `save_recent_project_paths`, `remember_recent_project`, `forget_recent_project`, or their `QSettings` patch owner; they deliberately remain in `app.py`.

- [ ] **Step 5: Verify the move is behavior-neutral**

Run:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest tests.test_project_io tests.test_template_io tests.test_spreadsheet_io tests.test_app_preferences -v
```

Expected: `Ran 16 tests` and `OK`.

Run:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/run_tests.py
```

Expected: `247 tests`, all passing.

- [ ] **Step 6: Commit the test-only reorganization**

```bash
git add tests/test_project_io.py tests/test_template_io.py tests/test_spreadsheet_io.py tests/test_app_preferences.py tests/test_core.py
git commit -m "test: split persistence tests by responsibility"
```

After the commit, perform the standard two-stage checkpoint: first a spec-compliance review confirming all 16 tests were moved once with no assertion changes other than the two semantic renames; then a code-quality review checking imports, class ownership, cleanup, and patch owners. Resolve review findings before starting Task 2.

## Task 2: Extract Strict `.eg` Project Persistence (RED/GREEN)

**Files:**
- Create: `src/easygraph/project_io.py`
- Modify: `src/app.py`
- Modify: `tests/test_project_io.py`
- Modify: `tests/test_core.py`

- [ ] **Step 1: Add three failing project-module tests**

Add imports after `tests.easygraph_case`:

```python
import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase, app
```

Add the following three tests to `ProjectIOTests`:

```python
def test_strict_settings_codec_rejects_non_dict_and_sorted_unknown_fields(self):
    from easygraph import project_io

    with self.assertRaisesRegex(
        ValueError,
        r"^Chart settings must be a dictionary\.$",
    ):
        project_io.chart_settings_from_dict([])

    with self.assertRaisesRegex(
        ValueError,
        r"^Unknown ChartSettings fields: legacy_show_line_overlay, retired_legend_mode$",
    ):
        project_io.chart_settings_from_dict({
            "retired_legend_mode": "fixed",
            "legacy_show_line_overlay": True,
        })

def test_app_reexports_exact_project_io_api(self):
    from easygraph import project_io

    expected = [
        "chart_settings_from_dict",
        "read_project",
        "write_project",
    ]
    self.assertEqual(project_io.__all__, expected)
    for name in expected:
        with self.subTest(name=name):
            self.assertIs(getattr(app, name), getattr(project_io, name))

def test_direct_project_io_import_contract_in_normal_and_optimized_python(self):
    source_path = str(ROOT / "src")
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = source_path + (
        os.pathsep + existing_pythonpath if existing_pythonpath else ""
    )
    code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.project_io import chart_settings_from_dict

settings = chart_settings_from_dict({{"legend_columns": 1}})
if settings.legend_auto_width is not True:
    raise SystemExit("missing current field did not use its default")
try:
    chart_settings_from_dict({{"removed_field": 1}})
except ValueError as exc:
    if str(exc) != "Unknown ChartSettings fields: removed_field":
        raise SystemExit("unexpected strict-field error: " + str(exc))
else:
    raise SystemExit("unknown field was accepted")
for forbidden in ("PySide6", "matplotlib", "seaborn", "scipy"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit(forbidden + " imported")
"""
    for optimized in (False, True):
        command = [sys.executable]
        if optimized:
            command.append("-O")
        command.extend(["-c", code])
        with self.subTest(optimized=optimized):
            result = subprocess.run(
                command,
                cwd=ROOT,
                env=env,
                capture_output=True,
                text=True,
                check=False,
                timeout=15,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
```

The subprocess uses `SystemExit`, not bare `assert`, so `-O` cannot erase the contract.

- [ ] **Step 2: Replace the obsolete legacy legend expectation**

In `tests/test_core.py`, rename and update the existing test:

```python
def test_missing_legend_auto_width_uses_current_default(self):
    settings = app.chart_settings_from_dict({
        "legend_width": 1.2,
        "legend_columns": 1,
    })

    self.assertTrue(settings.legend_auto_width)
    self.assertEqual(settings.legend_width, 1.2)
    self.assertEqual(settings.legend_columns, 1)
```

This expectation follows the current dataclass default (`legend_auto_width=True`) and `ChartSettings.__post_init__`; it does not simulate an old file.

- [ ] **Step 3: Run meaningful RED**

```bash
./.venv/bin/python -m unittest tests.test_project_io -v
```

Expected: three newly added tests fail because `easygraph.project_io` does not exist; the existing project round-trip still passes. The failure must be missing-module/ownership failure, not a syntax or import-order error.

- [ ] **Step 4: Create `project_io.py` with the complete implementation**

Create:

```python
from __future__ import annotations

import json
import tempfile
import zipfile
from dataclasses import asdict, fields
from pathlib import Path

import pandas as pd

from easygraph.settings import ChartSettings


def chart_settings_from_dict(data: dict) -> ChartSettings:
    if not isinstance(data, dict):
        raise ValueError("Chart settings must be a dictionary.")
    current_fields = {field.name for field in fields(ChartSettings)}
    unknown_fields = sorted(str(key) for key in data if key not in current_fields)
    if unknown_fields:
        raise ValueError(
            "Unknown ChartSettings fields: " + ", ".join(unknown_fields)
        )
    return ChartSettings(**data)


def write_project(path: Path, df: pd.DataFrame, settings: ChartSettings) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        df.to_csv(tmp_path / "data.csv", index=False)
        (tmp_path / "settings.json").write_text(
            json.dumps(asdict(settings), indent=2),
            encoding="utf-8",
        )
        (tmp_path / "project.json").write_text(
            json.dumps({"version": 1, "app": "EasyGraph"}, indent=2),
            encoding="utf-8",
        )
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for file in tmp_path.iterdir():
                archive.write(file, arcname=file.name)


def read_project(path: Path) -> tuple[pd.DataFrame, ChartSettings]:
    with zipfile.ZipFile(path, "r") as archive:
        with archive.open("data.csv") as data_file:
            df = pd.read_csv(data_file)
        settings_data = json.loads(archive.read("settings.json").decode("utf-8"))
    return df, chart_settings_from_dict(settings_data)


__all__ = [
    "chart_settings_from_dict",
    "read_project",
    "write_project",
]
```

`project_io.py` may import only standard-library modules, pandas, and `easygraph.settings`. It must not import Qt, `app`, `template_io`, `spreadsheet_io`, palette, overlays, or plotting.

- [ ] **Step 5: Replace app definitions with direct imports**

Add after the settings import block and before modules that may depend on the codec:

```python
from easygraph.project_io import (
    chart_settings_from_dict,
    read_project,
    write_project,
)
```

Delete the three original definitions from `app.py`. Remove `import zipfile` and
`fields` from app imports because their remaining uses disappear. Keep
`import json` temporarily: the app-local template functions still use it until
Task 3. Retain `tempfile`, `asdict`, `deepcopy`, `re`, `Path`, and pandas because
unmoved app code still uses them.

- [ ] **Step 6: Verify GREEN and the 250-test gate**

```bash
./.venv/bin/python -m unittest tests.test_project_io tests.test_core.EasyGraphCoreTests.test_missing_legend_auto_width_uses_current_default -v
```

Expected: `Ran 5 tests` and `OK`.

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/run_tests.py
```

Expected: `250 tests`, all passing.

- [ ] **Step 7: Verify ownership and dependency boundaries**

```bash
./.venv/bin/python - <<'PY'
import ast
from pathlib import Path

app_tree = ast.parse(Path("src/app.py").read_text(encoding="utf-8"))
forbidden_defs = {"chart_settings_from_dict", "read_project", "write_project"}
remaining = sorted(
    node.name for node in app_tree.body
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    and node.name in forbidden_defs
)
if remaining:
    raise SystemExit("definitions still in app.py: " + ", ".join(remaining))
PY
```

Expected: exit 0 and no output.

```bash
if rg -n 'PySide6|matplotlib|seaborn|scipy|easygraph\.(template_io|spreadsheet_io)|(^| )import app|from app' src/easygraph/project_io.py; then
  echo 'unexpected project_io dependency'
  exit 1
else
  echo 'project_io dependency boundary clean'
fi
```

Expected: `project_io dependency boundary clean`. Here `rg` exit 1 means “no match” and is intentionally handled by the `if` condition.

- [ ] **Step 8: Commit and review Task 2**

```bash
git add src/easygraph/project_io.py src/app.py tests/test_project_io.py tests/test_core.py
git commit -m "refactor: extract strict project persistence"
```

Run a spec-compliance review first (exact strict policy, three-name `__all__`, identity, dependency boundary, no legacy branches), then a code-quality review (ZIP resource handling, deterministic error text, test robustness). Fix and re-run focused/full verification before Task 3.

## Task 3: Extract Style-Template Persistence (RED/GREEN)

**Files:**
- Create: `src/easygraph/template_io.py`
- Modify: `src/app.py`
- Modify: `tests/test_template_io.py`
- Modify: `tests/test_core.py`

- [ ] **Step 1: Add three failing template-module tests**

Add `os`, `subprocess`, and `sys`, and import `ROOT` from `tests.easygraph_case`. Add:

```python
def test_style_template_rejects_unknown_settings_fields(self):
    data = app.asdict(self.settings)
    data["retired_template_setting"] = True
    with tempfile.TemporaryDirectory() as tmp:
        path = pathlib.Path(tmp) / "strict.json"
        path.write_text(json.dumps(data), encoding="utf-8")
        with self.assertRaisesRegex(
            ValueError,
            r"^Unknown ChartSettings fields: retired_template_setting$",
        ):
            app.read_style_template_file(path)

def test_app_reexports_exact_template_io_api(self):
    from easygraph import template_io

    expected = [
        "TEMPLATE_DIR",
        "TEMPLATE_NONE_NAME",
        "apply_style_template_settings",
        "group_colors_for_target_groups",
        "import_style_template",
        "indexed_group_colors_from_settings",
        "list_style_templates",
        "read_style_template",
        "read_style_template_file",
        "style_template_settings_data",
        "template_file_name",
        "template_indexed_group_colors",
        "write_style_template",
    ]
    self.assertEqual(template_io.__all__, expected)
    for name in expected:
        with self.subTest(name=name):
            self.assertIs(getattr(app, name), getattr(template_io, name))
    self.assertEqual(template_io.TEMPLATE_DIR, ROOT / "src" / "template")

def test_direct_template_io_import_contract_in_normal_and_optimized_python(self):
    source_path = str(ROOT / "src")
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = source_path + (
        os.pathsep + existing_pythonpath if existing_pythonpath else ""
    )
    code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.settings import ChartSettings
from easygraph.template_io import (
    TEMPLATE_DIR,
    group_colors_for_target_groups,
    style_template_settings_data,
)

settings = ChartSettings(
    manual_group_order=["A", "B"],
    custom_colors={{"B": "#446688"}},
)
data = style_template_settings_data(settings)
if data["custom_colors"] != {{"group:1": "#446688"}}:
    raise SystemExit("indexed template colors changed")
if group_colors_for_target_groups(data["custom_colors"], ["X", "Y"]) != {{"Y": "#446688"}}:
    raise SystemExit("target group mapping changed")
if str(TEMPLATE_DIR) != {str(ROOT / "src" / "template")!r}:
    raise SystemExit("default template path changed")
if "PySide6.QtWidgets" in sys.modules:
    raise SystemExit("QtWidgets imported")
for forbidden in ("matplotlib", "seaborn", "scipy"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit(forbidden + " imported")
"""
    for optimized in (False, True):
        command = [sys.executable]
        if optimized:
            command.append("-O")
        command.extend(["-c", code])
        with self.subTest(optimized=optimized):
            result = subprocess.run(
                command,
                cwd=ROOT,
                env=env,
                capture_output=True,
                text=True,
                check=False,
                timeout=15,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
```

- [ ] **Step 2: Rename the remaining misleading integration test**

In `tests/test_core.py`, rename:

```text
test_legacy_overlay_template_does_not_insert_overlay_rows
  -> test_style_template_content_policy_does_not_insert_overlay_rows
```

Change only local display text such as `"Legacy"` to `"Style policy"` if it improves intent; keep the current-field JSON input and behavioral assertions. `custom_overlay_series`, `custom_overlay_hidden`, and related fields remain current `ChartSettings` fields; the template loader clears them because they are in `STYLE_TEMPLATE_CONTENT_FIELDS`, not because they are legacy.

- [ ] **Step 3: Run meaningful RED**

```bash
./.venv/bin/python -m unittest tests.test_template_io -v
```

Expected: the six moved behavior tests and the strict-field regression pass
against the already-strict Task 2 codec. The exact-module and direct-import
tests fail because `easygraph.template_io` does not exist. Total: `Ran 9 tests`
with two meaningful missing-module failures/errors; do not weaken the already
GREEN strict regression merely to manufacture another RED.

- [ ] **Step 4: Create the focused module**

Start `src/easygraph/template_io.py` with:

```python
from __future__ import annotations

import json
import re
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path

from PySide6.QtGui import QColor

from easygraph.project_io import chart_settings_from_dict
from easygraph.settings import (
    ChartSettings,
    GROUP_COLOR_TEMPLATE_KEY_PREFIX,
    STYLE_TEMPLATE_CONTENT_FIELDS,
)

TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "template"
TEMPLATE_NONE_NAME = "None"
```

Move the exact bodies and signatures of these 11 functions from `app.py`, in their current order:

```text
style_template_settings_data
indexed_group_colors_from_settings
template_indexed_group_colors
group_colors_for_target_groups
apply_style_template_settings
template_file_name
write_style_template
read_style_template
read_style_template_file
import_style_template
list_style_templates
```

Do not change the current template-content reset policy: `read_style_template_file` must validate that the JSON top level is a dictionary, reset every `STYLE_TEMPLATE_CONTENT_FIELDS` entry to the current default, retain only indexed valid colors, and then call strict `project_io.chart_settings_from_dict`. Unknown keys remain in `data`, so the strict codec rejects them.

End with the exact 13-name `__all__` listed in this plan's API section.

Dependencies are limited to standard library, `PySide6.QtGui.QColor`, the three specified settings names, and `project_io.chart_settings_from_dict`. Do not import QtWidgets, `app`, plotting, palette, overlays, or spreadsheet persistence.

- [ ] **Step 5: Replace app definitions/constants with direct imports**

Delete app-local `TEMPLATE_DIR`, `TEMPLATE_NONE_NAME`, and the 11 function definitions. Add after the `project_io` block:

```python
from easygraph.template_io import (
    TEMPLATE_DIR,
    TEMPLATE_NONE_NAME,
    apply_style_template_settings,
    group_colors_for_target_groups,
    import_style_template,
    indexed_group_colors_from_settings,
    list_style_templates,
    read_style_template,
    read_style_template_file,
    style_template_settings_data,
    template_file_name,
    template_indexed_group_colors,
    write_style_template,
)
```

Keep `re`, `asdict`, and `deepcopy` in `app.py`: unmoved text layout,
canvas/settings snapshots, and rendering still use them. Now remove `import
json` from `app.py`; before doing so, add `import json` to `tests/test_core.py`
and change the remaining template-policy fixture from `app.json.dumps(data)`
to `json.dumps(data)`. This is the last tests-only use of `app.json`.

- [ ] **Step 6: Check mock ownership before GREEN**

Run:

```bash
rg -n 'patch\.object\(app, "(read_style_template|write_style_template|read_style_template_file|import_style_template)"' tests
```

Expected matches remain in UI tests that patch the `app.py` global used by `MainWindow`; keep those patch owners unchanged. There must be no test patching an internal collaborator such as `app.chart_settings_from_dict` to affect a function now owned by `template_io`. If such an internal patch exists, retarget only that patch to `easygraph.template_io.chart_settings_from_dict`; never add an app wrapper.

- [ ] **Step 7: Verify GREEN and the 253-test gate**

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest tests.test_template_io tests.test_core.EasyGraphCoreTests.test_style_template_content_policy_does_not_insert_overlay_rows -v
```

Expected: `Ran 10 tests` and `OK`.

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/run_tests.py
```

Expected: `253 tests`, all passing.

- [ ] **Step 8: Verify static boundaries**

```bash
if rg -n 'PySide6\.QtWidgets|matplotlib|seaborn|scipy|easygraph\.(palette|overlay_series|spreadsheet_io)|(^| )import app|from app' src/easygraph/template_io.py; then
  echo 'unexpected template_io dependency'
  exit 1
else
  echo 'template_io dependency boundary clean'
fi
```

Expected: boundary-clean message; no-match exit 1 is handled.

- [ ] **Step 9: Commit and review Task 3**

```bash
git add src/easygraph/template_io.py src/app.py tests/test_template_io.py tests/test_core.py
git commit -m "refactor: extract style template persistence"
```

Perform spec review first (11 functions, two constants, default path, strict unknown-field failure, current content policy, identity), then quality review (JSON validation, path behavior, color validation, imports). Fix and reverify before Task 4.

## Task 4: Extract Spreadsheet Format and File Access (RED/GREEN)

**Files:**
- Create: `src/easygraph/spreadsheet_io.py`
- Modify: `src/app.py`
- Modify: `tests/test_spreadsheet_io.py`

- [ ] **Step 1: Add three failing spreadsheet-module tests**

Add `os`, `subprocess`, and `sys`, import `ROOT`, and add:

```python
def test_read_and_write_spreadsheet_preserve_path_policy_and_overlay_rows(self):
    from easygraph import spreadsheet_io

    df = app.pd.DataFrame({"A": [1, 2], "B": [3, 4]})
    overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]
    with tempfile.TemporaryDirectory() as tmp:
        root = pathlib.Path(tmp)

        csv_path = spreadsheet_io.write_spreadsheet(root / "data.csv", df, overlay)
        self.assertEqual(csv_path, root / "data.csv")
        csv_df, csv_overlay = spreadsheet_io.read_spreadsheet(csv_path)
        app.pd.testing.assert_frame_equal(csv_df, df)
        self.assertEqual(csv_overlay, overlay)

        xlsx_path = spreadsheet_io.write_spreadsheet(root / "book", df, overlay)
        self.assertEqual(xlsx_path, root / "book.xlsx")
        xlsx_df, xlsx_overlay = spreadsheet_io.read_spreadsheet(xlsx_path)
        app.pd.testing.assert_frame_equal(xlsx_df, df)
        self.assertEqual(xlsx_overlay, overlay)

        xls_output = spreadsheet_io.write_spreadsheet(root / "old.xls", df, overlay)
        self.assertEqual(xls_output, root / "old.xls.xlsx")

    encoded = spreadsheet_io.excel_export_dataframe(df, overlay)
    with mock.patch.object(
        spreadsheet_io.pd,
        "read_excel",
        return_value=encoded,
    ) as read_excel:
        imported_df, imported_overlay = spreadsheet_io.read_spreadsheet(
            pathlib.Path("input.xls")
        )
    read_excel.assert_called_once_with(pathlib.Path("input.xls"))
    app.pd.testing.assert_frame_equal(imported_df, df)
    self.assertEqual(imported_overlay, overlay)

def test_app_reexports_exact_spreadsheet_io_api(self):
    from easygraph import spreadsheet_io

    expected = [
        "OVERLAY_EXPORT_CUSTOM_ROW",
        "OVERLAY_EXPORT_NAME_COLUMN",
        "OVERLAY_EXPORT_ROW_TYPE_COLUMN",
        "OVERLAY_EXPORT_SAMPLE_ROW",
        "excel_export_dataframe",
        "excel_import_parts",
        "read_spreadsheet",
        "write_spreadsheet",
    ]
    self.assertEqual(spreadsheet_io.__all__, expected)
    for name in expected:
        with self.subTest(name=name):
            self.assertIs(getattr(app, name), getattr(spreadsheet_io, name))

def test_direct_spreadsheet_import_contract_in_normal_and_optimized_python(self):
    source_path = str(ROOT / "src")
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = source_path + (
        os.pathsep + existing_pythonpath if existing_pythonpath else ""
    )
    code = f"""
import sys
sys.path.insert(0, {source_path!r})
import pandas as pd
from easygraph.spreadsheet_io import excel_export_dataframe, excel_import_parts

frame = pd.DataFrame({{"A": [1], "B": [2]}})
overlay = [{{"name": "Target", "values": {{"A": "10", "B": "20"}}}}]
decoded_frame, decoded_overlay = excel_import_parts(excel_export_dataframe(frame, overlay))
if decoded_frame.to_dict("list") != {{"A": [1], "B": [2]}}:
    raise SystemExit("spreadsheet sample round-trip changed")
if decoded_overlay != overlay:
    raise SystemExit("spreadsheet overlay round-trip changed")
for forbidden in ("PySide6", "matplotlib", "seaborn", "scipy"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit(forbidden + " imported")
"""
    for optimized in (False, True):
        command = [sys.executable]
        if optimized:
            command.append("-O")
        command.extend(["-c", code])
        with self.subTest(optimized=optimized):
            result = subprocess.run(
                command,
                cwd=ROOT,
                env=env,
                capture_output=True,
                text=True,
                check=False,
                timeout=15,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
```

This single path-policy test explicitly locks `.xls` input to the Excel reader while locking `.xls` output to the existing UI behavior `old.xls.xlsx`. The save dialog offers only CSV and XLSX; only `.csv` and `.xlsx` are recognized output suffixes.

- [ ] **Step 2: Run meaningful RED**

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest tests.test_spreadsheet_io -v
```

Expected: the four moved tests pass; the three new tests fail because `easygraph.spreadsheet_io` and the two path helpers do not exist. Total: `Ran 7 tests` with three meaningful failures/errors.

- [ ] **Step 3: Create the complete spreadsheet module**

Start with:

```python
from __future__ import annotations

from pathlib import Path

import pandas as pd

OVERLAY_EXPORT_ROW_TYPE_COLUMN = "__easygraph_row_type"
OVERLAY_EXPORT_NAME_COLUMN = "__easygraph_overlay_name"
OVERLAY_EXPORT_SAMPLE_ROW = "sample"
OVERLAY_EXPORT_CUSTOM_ROW = "overlay"
```

Move the exact existing bodies/signatures of `excel_export_dataframe` and `excel_import_parts` from `app.py`, then add:

```python
def read_spreadsheet(path: Path) -> tuple[pd.DataFrame, list[dict]]:
    input_path = Path(path)
    raw_df = (
        pd.read_csv(input_path)
        if input_path.suffix.casefold() == ".csv"
        else pd.read_excel(input_path)
    )
    return excel_import_parts(raw_df)


def write_spreadsheet(
    path: Path,
    df: pd.DataFrame,
    overlay_series: list[dict] | None = None,
) -> Path:
    output_path = Path(path)
    exported = excel_export_dataframe(df, overlay_series)
    if output_path.suffix.casefold() == ".csv":
        exported.to_csv(output_path, index=False)
    else:
        if output_path.suffix.casefold() != ".xlsx":
            output_path = Path(f"{output_path}.xlsx")
        exported.to_excel(output_path, index=False)
    return output_path
```

End with the exact eight-name `__all__` listed above. The module imports only `Path` and pandas. It does not import Qt, app, settings, project/template persistence, or plotting.

- [ ] **Step 4: Directly re-export from app and delegate UI methods**

Delete the four app-local constants and two existing DataFrame helper definitions. Add:

```python
from easygraph.spreadsheet_io import (
    OVERLAY_EXPORT_CUSTOM_ROW,
    OVERLAY_EXPORT_NAME_COLUMN,
    OVERLAY_EXPORT_ROW_TYPE_COLUMN,
    OVERLAY_EXPORT_SAMPLE_ROW,
    excel_export_dataframe,
    excel_import_parts,
    read_spreadsheet,
    write_spreadsheet,
)
```

Keep file dialogs, translated errors, and state synchronization in `MainWindow`. Replace only the actual file access in `import_excel`:

```python
try:
    df, overlay_series = read_spreadsheet(Path(path))
    self.settings.custom_overlay_series = overlay_series
    self.settings.custom_overlay_count = max(1, len(overlay_series))
    self.settings.extra_custom_overlay = bool(overlay_series)
    self.settings.custom_overlay_hidden = []
    self.set_table_dataframe(df, overlay_series)
    self._sync_custom_overlay_visibility_to_controls()
    self.sync_manual_group_order()
    self.reset_table_history()
    self.render()
except Exception as exc:
    QMessageBox.critical(self, self.tr("Import failed"), str(exc))
```

Replace `export_excel` file access with:

```python
try:
    write_spreadsheet(
        Path(path),
        self.table.dataframe(),
        self.custom_overlay_series_from_table()
        if self.custom_overlay_row_count()
        else [],
    )
except Exception as exc:
    QMessageBox.critical(self, self.tr("Export failed"), str(exc))
```

Do not move `QFileDialog`, `QMessageBox`, translated titles/filters, settings mutations, table synchronization, render calls, or history reset into the module.

- [ ] **Step 5: Verify mock owners and GREEN**

Run:

```bash
rg -n 'patch\.object\(app\.QFileDialog|patch\.object\(spreadsheet_io\.pd' tests/test_spreadsheet_io.py
```

Expected: UI dialog patches remain on `app.QFileDialog`; the `.xls` reader branch patch is on the true collaborator owner `spreadsheet_io.pd`. Do not patch `app.pd.read_excel` to control `read_spreadsheet`, and do not add wrappers.

Run:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest tests.test_spreadsheet_io -v
```

Expected: `Ran 7 tests` and `OK`.

Run:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/run_tests.py
```

Expected: `256 tests`, all passing.

- [ ] **Step 6: Verify the dependency boundary**

```bash
if rg -n 'PySide6|matplotlib|seaborn|scipy|easygraph\.|(^| )import app|from app' src/easygraph/spreadsheet_io.py; then
  echo 'unexpected spreadsheet_io dependency'
  exit 1
else
  echo 'spreadsheet_io dependency boundary clean'
fi
```

Expected: boundary-clean message; no-match exit 1 is handled.

- [ ] **Step 7: Commit and review Task 4**

```bash
git add src/easygraph/spreadsheet_io.py src/app.py tests/test_spreadsheet_io.py
git commit -m "refactor: extract spreadsheet persistence"
```

Perform spec review first (four constants, four functions, `.xls` asymmetry, direct identity, UI boundary), then quality review (path types, pandas calls, exception ownership, round-trip tests). Fix and reverify before documentation.

## Task 5: Holistic Structural Verification and Documentation

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Prove stable moved bodies were not edited accidentally**

Compare the 15 behavior-preserving moved functions against baseline `26d1d91`. Exclude `chart_settings_from_dict` because its strict rewrite is intentional, and exclude the two new spreadsheet path helpers because they have no baseline body:

```bash
./.venv/bin/python - <<'PY'
import ast
import subprocess
from pathlib import Path

baseline_source = subprocess.check_output(
    ["git", "show", "26d1d91:src/app.py"],
    text=True,
)
baseline_tree = ast.parse(baseline_source)

def functions(tree):
    return {
        node.name: node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }

before = functions(baseline_tree)
checks = {
    "src/easygraph/project_io.py": ["read_project", "write_project"],
    "src/easygraph/template_io.py": [
        "style_template_settings_data",
        "indexed_group_colors_from_settings",
        "template_indexed_group_colors",
        "group_colors_for_target_groups",
        "apply_style_template_settings",
        "template_file_name",
        "write_style_template",
        "read_style_template",
        "read_style_template_file",
        "import_style_template",
        "list_style_templates",
    ],
    "src/easygraph/spreadsheet_io.py": [
        "excel_export_dataframe",
        "excel_import_parts",
    ],
}

for path, names in checks.items():
    after = functions(ast.parse(Path(path).read_text(encoding="utf-8")))
    for name in names:
        if name not in before or name not in after:
            raise SystemExit(f"missing AST for {name}")
        if ast.dump(before[name], include_attributes=False) != ast.dump(
            after[name], include_attributes=False
        ):
            raise SystemExit(f"unexpected body change: {name}")
print("15 stable moved function bodies match baseline")
PY
```

Expected: exact success message. This command always raises a concrete `SystemExit` message on failure; it never uses `raise None`.

- [ ] **Step 2: Prove app contains no migrated definitions and imports direct identities**

```bash
./.venv/bin/python - <<'PY'
import ast
from pathlib import Path

moved = {
    "chart_settings_from_dict", "read_project", "write_project",
    "style_template_settings_data", "indexed_group_colors_from_settings",
    "template_indexed_group_colors", "group_colors_for_target_groups",
    "apply_style_template_settings", "template_file_name",
    "write_style_template", "read_style_template", "read_style_template_file",
    "import_style_template", "list_style_templates",
    "excel_export_dataframe", "excel_import_parts",
    "read_spreadsheet", "write_spreadsheet",
}
tree = ast.parse(Path("src/app.py").read_text(encoding="utf-8"))
remaining = sorted(
    node.name for node in tree.body
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    and node.name in moved
)
if remaining:
    raise SystemExit("migrated definitions remain: " + ", ".join(remaining))
print("no migrated function definitions remain in app.py")
PY
```

Then run the three module test files; their exact `is` assertions prove compatibility identity:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest tests.test_project_io tests.test_template_io tests.test_spreadsheet_io -v
```

Expected: `Ran 20 tests` and `OK` (4 project + 9 template + 7 spreadsheet).

- [ ] **Step 3: Check for stale patch owners**

```bash
if rg -n 'patch\.object\(app, "(chart_settings_from_dict|excel_export_dataframe|excel_import_parts|template_indexed_group_colors|group_colors_for_target_groups)"' tests; then
  echo 'stale internal-collaborator patch owner found'
  exit 1
else
  echo 'no stale internal-collaborator patch owners'
fi
```

Expected: no-stale-owner message. `rg` no-match exit 1 is handled. UI-level patches of `app.read_style_template`, `app.read_project`, `app.QFileDialog`, or other globals invoked directly by `MainWindow` are valid and are not included in this gate.

- [ ] **Step 4: Update README ownership and inventory**

Update the main-file list and descriptions with:

```text
src/easygraph/project_io.py
src/easygraph/template_io.py
src/easygraph/spreadsheet_io.py
tests/test_app_preferences.py
tests/test_spreadsheet_io.py
tests/test_template_io.py
```

Document precisely:

- `project_io.py` owns current `.eg` ZIP persistence and strict current-field decoding; unknown/retired fields fail, missing current fields default, and there are no legacy migrations.
- `template_io.py` owns style-template JSON, default `src/template` path, filename/list/import helpers, and indexed group colors. It may import QtGui `QColor` but not QtWidgets or plotting.
- `spreadsheet_io.py` owns overlay-row DataFrames and actual CSV/Excel access. Reads treat CSV specially and otherwise use the Excel reader, so `.xls` input remains accepted. Writes recognize only `.csv` and `.xlsx`; any other suffix or no suffix receives `.xlsx`.
- `app.py` remains the compatibility facade and UI coordinator. Recent-project `QSettings` helpers remain in `app.py`; do not claim they moved into a production module.
- `tests/test_app_preferences.py` owns recent-project preferences/menu behavior; the other two new test files match their module names.
- The expected full-suite count is 256.

Update the compile command to include all three production modules and all three new test files.

- [ ] **Step 5: Compile all touched and documented Python files**

```bash
./.venv/bin/python -m py_compile src/app.py src/easygraph/data.py src/easygraph/overlay_series.py src/easygraph/palette.py src/easygraph/settings.py src/easygraph/project_io.py src/easygraph/template_io.py src/easygraph/spreadsheet_io.py src/ui_main_window.py src/ui_group_order_dialog.py tests/easygraph_case.py tests/test_architecture.py tests/test_app_preferences.py tests/test_data.py tests/test_data_module.py tests/test_overlay_series_module.py tests/test_palette.py tests/test_palette_module.py tests/test_project_io.py tests/test_spreadsheet_io.py tests/test_template_io.py tests/test_settings_module.py tests/test_core.py tests/test_support.py tests/test_warning_policy.py tests/test_test_runner.py scripts/run_tests.py
```

Expected: exit 0 and no output.

- [ ] **Step 6: Verify generated UI is exactly reproducible without touching tracked files**

```bash
./.venv/bin/pyside6-uic ui/main_window.ui -o /tmp/easygraph-ui-main.py
cmp /tmp/easygraph-ui-main.py src/ui_main_window.py
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o /tmp/easygraph-ui-group-order.py
cmp /tmp/easygraph-ui-group-order.py src/ui_group_order_dialog.py
```

Expected: both `cmp` commands exit 0 with no output. Also run:

```bash
git diff --exit-code -- ui/main_window.ui ui/group_order_dialog.ui src/ui_main_window.py src/ui_group_order_dialog.py
```

Expected: exit 0 and no diff.

- [ ] **Step 7: Run final full suite and measure file sizes**

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/run_tests.py --slow 20
```

Expected: `256 tests`, all passing. Slow-test reporting is diagnostic; warnings remain textual and no screenshot is transmitted unless an image/screenshot tool is explicitly called.

```bash
wc -l src/app.py src/easygraph/project_io.py src/easygraph/template_io.py src/easygraph/spreadsheet_io.py
git diff --check
git status --short
```

Expected: `app.py` is shorter, each new module is focused, `git diff --check` is clean, and status contains only the intended README change plus any reviewed uncommitted documentation change.

- [ ] **Step 8: Commit documentation and perform final reviews**

```bash
git add README.md
git commit -m "docs: describe persistence module boundaries"
```

Run a holistic spec-compliance review against `docs/superpowers/specs/2026-06-19-incremental-app-refactor-design.md` and this plan, then a holistic code-quality review across the branch diff from `26d1d91`. After any fix, re-run compile, the 256-test suite, dependency/AST gates, UI comparisons, `git diff --check`, and `git status --short` before reporting completion.

## Self-Review Record

- **Spec coverage:** All three production boundaries, strict current-field behavior, exact app identity, `.xls` asymmetry, UI ownership, recent-preference non-migration, `.ui` prohibition, named test files, per-phase counts, per-phase full tests/reviews, README, AST, imports, UI comparisons, and line-count reporting have explicit tasks.
- **Placeholder scan:** The plan contains no unresolved placeholder or “similar
  to another task” implementation gaps. Every new production function and new
  test is shown, while behavior-preserving moves name the exact existing
  functions/tests and require AST equality.
- **Type consistency:** `read_spreadsheet(Path) -> tuple[pd.DataFrame, list[dict]]` and `write_spreadsheet(Path, pd.DataFrame, list[dict] | None) -> Path` are used consistently by tests and `MainWindow`; all `__all__` inventories match direct app imports.
- **Count consistency:** Rehoming moves 16 tests without duplication; project/template/spreadsheet add 3 each, producing exactly 256 from 247. Final focused persistence total is 4 + 9 + 7 = 20.
