# Remove Legacy UI Builders Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Remove unreachable Python-built UI code that predates `ui/main_window.ui`, reducing `src/app.py` without changing the live interface.

**Architecture:** Add an architecture regression test proving the obsolete private builders and their spin-box factories no longer exist. Delete only code whose references are confined to the obsolete builder cluster, remove the now-unused `QSplitter` import, and keep all live `.ui`-generated bindings unchanged.

**Tech Stack:** Python 3.10, PySide6, `unittest`, Qt Designer `.ui` generation

---

## Audited Dead-Code Set

The following methods have no call sites outside their own obsolete cluster:

```text
MainWindow._build_menu
MainWindow._build_layout
MainWindow._build_controls
MainWindow._chart_group
MainWindow._font_group
MainWindow._axis_group
MainWindow._points_group
MainWindow._outlier_group
MainWindow._specific_group
```

The module-level `spin()` and `spin_int()` factories are referenced only by
those methods. `QSplitter` is imported into `src/app.py` only for
`_build_layout`; the live splitter is generated in `src/ui_main_window.py` from
`ui/main_window.ui`.

### Task 1: Prove and remove the obsolete UI builders

**Files:**
- Create: `tests/test_architecture.py`
- Modify: `src/app.py:69,4969-5160,6153-6170`

- [ ] **Step 1: Write failing architecture tests**

Create `tests/test_architecture.py`:

```python
from tests.easygraph_case import EasyGraphTestCase, app


class ArchitectureTests(EasyGraphTestCase):
    def test_legacy_programmatic_ui_builders_are_removed(self):
        legacy_builders = (
            "_build_menu",
            "_build_layout",
            "_build_controls",
            "_chart_group",
            "_font_group",
            "_axis_group",
            "_points_group",
            "_outlier_group",
            "_specific_group",
        )

        for name in legacy_builders:
            with self.subTest(name=name):
                self.assertFalse(hasattr(app.MainWindow, name))

    def test_legacy_spin_factories_are_removed(self):
        self.assertFalse(hasattr(app, "spin"))
        self.assertFalse(hasattr(app, "spin_int"))
```

- [ ] **Step 2: Run RED and verify the intended failure**

Run:

```bash
./.venv/bin/python -m unittest tests.test_architecture -v
```

Expected: both tests fail because the nine methods and two factories still
exist. The failure must not be an import or syntax error.

- [ ] **Step 3: Delete the dead cluster and unused import**

In `src/app.py`:

1. Delete the complete method definitions from `_build_menu` through
   `_specific_group`, stopping immediately before `_connect_table`.
2. Delete the complete module-level `spin` and `spin_int` functions, leaving
   `export_suffix_for_filter` as the next definition.
3. Remove `QSplitter` from the `PySide6.QtWidgets` import list.

Do not delete `QAction`, `QFormLayout`, `QScrollArea`, `QVBoxLayout`, spin-box
classes, or other widgets: they still have live call sites elsewhere.

- [ ] **Step 4: Run GREEN and static reference checks**

Run:

```bash
./.venv/bin/python -m unittest tests.test_architecture -v
rg -n "def (_build_menu|_build_layout|_build_controls|_chart_group|_font_group|_axis_group|_points_group|_outlier_group|_specific_group|spin|spin_int)\b|\bQSplitter\b" src/app.py
./.venv/bin/python -m py_compile src/app.py tests/test_architecture.py
```

Expected: two tests pass, `rg` returns no matches, and compilation exits 0.

- [ ] **Step 5: Run focused live-UI regression tests**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 5 \
  tests.test_core.EasyGraphCoreTests.test_combo_boxes_expand_for_long_options \
  tests.test_core.EasyGraphCoreTests.test_primary_settings_are_promoted_to_top_toolbar_and_pinned_sidebar \
  tests.test_core.EasyGraphCoreTests.test_file_menu_contains_open_recent_submenu \
  tests.test_core.EasyGraphCoreTests.test_all_chart_types_render_offscreen
```

Expected: four tests pass, demonstrating the generated UI, menu actions,
control bindings, and plotting still operate.

- [ ] **Step 6: Commit dead-code removal**

```bash
git add src/app.py tests/test_architecture.py
git commit -m "refactor: remove legacy UI builders"
```

### Task 2: Document and verify the smaller application shell

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update the architecture and test count**

In README:

- Change the expected test count from 235 to 237.
- Add `tests/test_architecture.py` to the test file inventory and compile-check
  command.
- State that fixed main-window structure is defined in `ui/main_window.ui`; the
  removed Python builders were unreachable legacy code, not an alternative UI
  source.
- Do not claim that all remaining programmatic widgets have moved to `.ui`;
  fixed live controls and dialog shells are handled in a later phase.

- [ ] **Step 2: Measure the actual line reduction**

Run:

```bash
wc -l src/app.py
git show HEAD^:src/app.py | wc -l
```

Record the exact before/after line counts in the phase handoff. Do not hard-code
line counts into README because they will change during later extraction.

- [ ] **Step 3: Run complete verification**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 20
./.venv/bin/python -m py_compile \
  src/app.py tests/test_architecture.py tests/easygraph_case.py \
  tests/test_data.py tests/test_palette.py tests/test_project_io.py \
  tests/test_core.py tests/test_support.py tests/test_warning_policy.py \
  tests/test_test_runner.py scripts/run_tests.py
./.venv/bin/pyside6-uic ui/main_window.ui -o /tmp/easygraph_ui_main_window.py
cmp src/ui_main_window.py /tmp/easygraph_ui_main_window.py
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o /tmp/easygraph_ui_group_order_dialog.py
cmp src/ui_group_order_dialog.py /tmp/easygraph_ui_group_order_dialog.py
git diff --check
```

Expected: 237 tests pass, compile succeeds, both UI files compare exactly, and
the diff check is clean.

- [ ] **Step 4: Commit documentation**

```bash
git add README.md
git commit -m "docs: record legacy UI cleanup"
```

## Final Review Checklist

- [ ] The architecture tests demonstrated RED before deletion and GREEN after.
- [ ] Only the audited nine methods, two factories, and unused `QSplitter`
      import were removed from production code.
- [ ] No `.ui` or generated `src/ui_*.py` file changed.
- [ ] README does not overstate completion of the later UI migration.
- [ ] Full discovery reports 237 passing tests.
