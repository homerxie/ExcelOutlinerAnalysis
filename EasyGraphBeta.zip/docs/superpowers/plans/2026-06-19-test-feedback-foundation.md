# Test Feedback Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Establish a low-noise, measurable test foundation that later refactor stages can use to avoid unnecessary Qt/Matplotlib renders.

**Architecture:** Add a backward-compatible constructor seam that lets UI tests skip the initial render, centralize narrowly-scoped third-party warning filtering in test support, and add a quiet timing runner. Keep the current monolithic test file in this first sub-project; moving tests by domain is a separate follow-up plan so test infrastructure and test relocation are not mixed in one change.

**Tech Stack:** Python 3.10, `unittest`, PySide6, Matplotlib, Seaborn

---

## File Structure

- Create `tests/__init__.py` so focused tests can be loaded by dotted name.
- Create `tests/test_support.py` for common warning configuration.
- Create `tests/test_warning_policy.py` to verify the warning rule remains narrow.
- Create `scripts/run_tests.py` for quiet full/focused runs and slow-test reporting.
- Modify `src/app.py` only to add the optional initial-render seam.
- Modify `tests/test_core.py` to test and begin using that seam.
- Modify `README.md` to document accurate counts, quiet commands, warnings, and timing.

### Task 1: Add a backward-compatible initial-render seam

**Files:**
- Modify: `tests/test_core.py:38`
- Modify: `src/app.py:3216-3254`

- [ ] **Step 1: Write the failing constructor test**

Add this test immediately after `EasyGraphCoreTests.setUp`:

```python
    def test_main_window_can_skip_initial_render(self):
        with mock.patch.object(app.MainWindow, "render") as render:
            window = app.MainWindow(initial_render=False)
            self.addCleanup(window.close)

        render.assert_not_called()
        self.assertFalse(hasattr(window.canvas, "_last_df"))
```

- [ ] **Step 2: Run the focused test and verify it fails**

Run:

```bash
QT_QPA_PLATFORM=offscreen PYTHONWARNINGS=ignore ./.venv/bin/python -m unittest \
  tests.test_core.EasyGraphCoreTests.test_main_window_can_skip_initial_render -v
```

Expected: `ERROR` with `TypeError: MainWindow.__init__() got an unexpected keyword argument 'initial_render'`.

- [ ] **Step 3: Implement the constructor seam**

Apply these two exact changes to the constructor declaration and its final
render block:

```diff
 class MainWindow(QMainWindow):
-    def __init__(self) -> None:
+    def __init__(self, initial_render: bool = True) -> None:

         self._connect_generated_ui()
-        self.render()
-        self._fit_initial_plot_to_viewport()
+        if initial_render:
+            self.render()
+            self._fit_initial_plot_to_viewport()
```

Do not move or otherwise edit the intervening initialization statements. The
default remains `True`, preserving `MainWindow()` behavior.

- [ ] **Step 4: Run constructor behavior tests**

Run:

```bash
QT_QPA_PLATFORM=offscreen PYTHONWARNINGS=ignore ./.venv/bin/python -m unittest \
  tests.test_core.EasyGraphCoreTests.test_main_window_can_skip_initial_render \
  tests.test_core.EasyGraphCoreTests.test_open_project_zoom_to_fit_after_loading -v
```

Expected: `Ran 2 tests` and `OK`.

- [ ] **Step 5: Compile-check the edited files**

Run:

```bash
./.venv/bin/python -m py_compile src/app.py tests/test_core.py
```

Expected: exit code 0 with no output.

- [ ] **Step 6: Commit the seam**

```bash
git add src/app.py tests/test_core.py
git commit -m "test: allow windows to skip initial render"
```

### Task 2: Centralize narrow third-party warning filtering

**Files:**
- Create: `tests/__init__.py`
- Create: `tests/test_support.py`
- Create: `tests/test_warning_policy.py`
- Modify: `tests/test_core.py:1-15`

- [ ] **Step 1: Make `tests` importable**

Create `tests/__init__.py`:

```python
"""EasyGraph test package."""
```

- [ ] **Step 2: Write a failing warning-policy test**

Create `tests/test_warning_policy.py`:

```python
import unittest
from unittest import mock

from tests import test_support


class WarningPolicyTests(unittest.TestCase):
    def test_warning_filter_targets_only_known_seaborn_warning(self):
        with mock.patch.object(test_support.warnings, "filterwarnings") as filterwarnings:
            test_support.configure_warning_filters()

        filterwarnings.assert_called_once_with(
            "ignore",
            message=r"vert: bool will be deprecated.*",
            category=PendingDeprecationWarning,
            module=r"seaborn\.categorical",
        )
```

At this point create `tests/test_support.py` with only imports so the failure is
specifically the missing function:

```python
"""Shared configuration for EasyGraph tests."""

import warnings
```

- [ ] **Step 3: Run the policy test and verify it fails**

Run:

```bash
./.venv/bin/python -m unittest \
  tests.test_warning_policy.WarningPolicyTests.test_warning_filter_targets_only_known_seaborn_warning -v
```

Expected: `ERROR` with `AttributeError` for `configure_warning_filters`.

- [ ] **Step 4: Implement and install the narrow filter**

Complete `tests/test_support.py`:

```python
"""Shared configuration for EasyGraph tests."""

import warnings


def configure_warning_filters() -> None:
    warnings.filterwarnings(
        "ignore",
        message=r"vert: bool will be deprecated.*",
        category=PendingDeprecationWarning,
        module=r"seaborn\.categorical",
    )
```

Add the following before `import app` in `tests/test_core.py`:

```python
from tests.test_support import configure_warning_filters

configure_warning_filters()
```

Do not suppress all `PendingDeprecationWarning` instances. A new warning from
EasyGraph or another dependency must remain visible.

- [ ] **Step 5: Verify the policy and a warning-producing plot test**

Run:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest \
  tests.test_warning_policy \
  tests.test_core.EasyGraphCoreTests.test_plot_frame_has_four_sides_with_and_without_secondary_axis -v
```

Expected: tests pass and no `seaborn/categorical.py:700` warning is printed.

- [ ] **Step 6: Commit the warning policy**

```bash
git add tests/__init__.py tests/test_support.py tests/test_warning_policy.py tests/test_core.py
git commit -m "test: filter known seaborn warning"
```

### Task 3: Add a quiet runner with slow-test reporting

**Files:**
- Create: `scripts/run_tests.py`
- Create: `tests/test_test_runner.py`

- [ ] **Step 1: Write failing tests for duration ordering**

Create `tests/test_test_runner.py`:

```python
import unittest

from scripts.run_tests import slowest_tests


class TestRunnerTests(unittest.TestCase):
    def test_slowest_tests_returns_longest_first_and_respects_limit(self):
        durations = [
            ("test_fast", 0.1),
            ("test_slow", 2.5),
            ("test_medium", 1.0),
        ]

        self.assertEqual(
            slowest_tests(durations, limit=2),
            [("test_slow", 2.5), ("test_medium", 1.0)],
        )
```

- [ ] **Step 2: Run the runner test and verify it fails**

Run:

```bash
./.venv/bin/python -m unittest tests.test_test_runner -v
```

Expected: import failure because `scripts/run_tests.py` does not exist.

- [ ] **Step 3: Implement the runner**

Create `scripts/run_tests.py`:

```python
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "easygraph_matplotlib"))
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from tests.test_support import configure_warning_filters


def slowest_tests(durations: list[tuple[str, float]], limit: int = 10) -> list[tuple[str, float]]:
    return sorted(durations, key=lambda item: item[1], reverse=True)[:limit]


class TimingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.durations: list[tuple[str, float]] = []
        self._started_at = 0.0

    def startTest(self, test) -> None:
        self._started_at = time.perf_counter()
        super().startTest(test)

    def stopTest(self, test) -> None:
        self.durations.append((test.id(), time.perf_counter() - self._started_at))
        super().stopTest(test)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run EasyGraph tests with concise timing output.")
    parser.add_argument("tests", nargs="*", help="Optional dotted test names")
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("--slow", type=int, default=10, help="Number of slow tests to report")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    configure_warning_filters()
    loader = unittest.defaultTestLoader
    suite = (
        loader.loadTestsFromNames(args.tests)
        if args.tests
        else loader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    )
    runner = unittest.TextTestRunner(
        verbosity=2 if args.verbose else 1,
        resultclass=TimingResult,
    )
    result = runner.run(suite)
    print("\nSlowest tests:")
    for name, duration in slowest_tests(result.durations, args.slow):
        print(f"{duration:8.3f}s  {name}")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
```

- [ ] **Step 4: Verify runner unit tests and compilation**

Run:

```bash
./.venv/bin/python -m unittest tests.test_test_runner -v
./.venv/bin/python -m py_compile scripts/run_tests.py tests/test_test_runner.py
```

Expected: `Ran 1 test`, `OK`, and compile-check exit code 0.

- [ ] **Step 5: Verify a focused real run**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 2 \
  tests.test_core.EasyGraphCoreTests.test_wide_table_is_converted_to_plot_data \
  tests.test_warning_policy.WarningPolicyTests.test_warning_filter_targets_only_known_seaborn_warning
```

Expected: two passing tests followed by exactly two timing rows and no Seaborn
warning flood.

- [ ] **Step 6: Commit the runner**

```bash
git add scripts/run_tests.py tests/test_test_runner.py
git commit -m "test: add quiet timed runner"
```

### Task 4: Document accurate test workflows and baseline

**Files:**
- Modify: `README.md:211-251`

- [ ] **Step 1: Replace the stale testing section**

Replace the current Testing and Known Warnings sections with:

````markdown
## Testing

Run the full suite headlessly with concise output and a slow-test summary:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
./.venv/bin/python scripts/run_tests.py
```

Run one test or a focused group by dotted name:

```bash
./.venv/bin/python scripts/run_tests.py -v \
  tests.test_core.EasyGraphCoreTests.test_wide_table_is_converted_to_plot_data
```

Run the underlying unittest command directly when diagnosing runner behavior:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest discover -s tests -t . -q
```

Compile-check key Python files:

```bash
./.venv/bin/python -m py_compile \
  src/app.py src/ui_main_window.py src/ui_group_order_dialog.py \
  tests/test_core.py scripts/run_tests.py
```

Current baseline before test decomposition: 229 tests. The pre-refactor suite
contained 226 tests and took about 220 seconds of unittest time on the primary
development machine.

## Known Test Output

The test configuration narrowly suppresses Seaborn's repeated
`PendingDeprecationWarning` for the deprecated `vert` argument. Other Python
warnings remain visible. Qt's offscreen plugin may still print occasional font
alias or `propagateSizeHints` diagnostic messages; these are text diagnostics,
not screenshots sent to an AI model.
````

The expected count is 229: 226 existing tests plus the constructor seam,
warning-policy, and timing-order tests.

- [ ] **Step 2: Correct stale repository handoff statements**

In Agent Handoff Notes:

- Replace the statement that this folder is not a Git repository with:
  `- This folder is a Git repository; inspect the active branch and working tree before editing.`
- Keep the instruction that all fixed UI changes begin in `.ui` files.
- Remove any obsolete expected test count elsewhere in the README.

- [ ] **Step 3: Verify README commands and references**

Run:

```bash
rg -n "25 tests|not currently a git repo|scripts/run_tests.py|229 tests" README.md
./.venv/bin/python scripts/run_tests.py --slow 1 tests.test_test_runner
```

Expected: no stale statements, the new commands are present, and the focused
runner test passes.

- [ ] **Step 4: Commit the documentation**

```bash
git add README.md
git commit -m "docs: document concise test workflow"
```

### Task 5: Establish the new full-suite baseline

**Files:**
- Modify only if verification exposes a defect in Tasks 1-4.

- [ ] **Step 1: Run the complete suite through the new runner**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 20
```

Expected: 229 tests pass, no repeated Seaborn warning output, and the 20
slowest tests are printed once at the end.

- [ ] **Step 2: Run direct unittest discovery**

Run:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest discover -s tests -t . -q
```

Expected: 229 tests pass. This confirms that the repository does not depend on
the custom runner to configure imports or make tests succeed.

- [ ] **Step 3: Verify source and UI generation integrity**

Run:

```bash
./.venv/bin/python -m py_compile \
  src/app.py src/ui_main_window.py src/ui_group_order_dialog.py \
  tests/test_core.py tests/test_support.py tests/test_warning_policy.py \
  tests/test_test_runner.py scripts/run_tests.py
./.venv/bin/pyside6-uic ui/main_window.ui -o /tmp/easygraph_ui_main_window.py
cmp src/ui_main_window.py /tmp/easygraph_ui_main_window.py
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o /tmp/easygraph_ui_group_order_dialog.py
cmp src/ui_group_order_dialog.py /tmp/easygraph_ui_group_order_dialog.py
git status --short
```

Expected: all commands exit 0 and `git status --short` prints nothing.

- [ ] **Step 4: Record the measured baseline**

Amend the README's baseline sentence only if the measured full-suite duration
differs materially from the original 220-second measurement. Record the actual
test count and elapsed test time printed by the runner; do not estimate them.

- [ ] **Step 5: Commit any evidence-driven documentation adjustment**

If Step 4 changed README:

```bash
git add README.md
git commit -m "docs: record test feedback baseline"
```

If Step 4 made no change, do not create an empty commit.

## Follow-up Plan Sequence

After this plan is complete, write and approve these independent plans in order:

1. Test-suite decomposition and conversion of UI-only cases to
   `MainWindow(initial_render=False)`.
2. Removal of unreachable legacy UI builders.
3. Extraction of `settings.py`, `data.py`, `palette.py`, and
   `overlay_series.py` with `app.py` compatibility exports.
4. Extraction of `project_io.py`.
5. Extraction of `PlotCanvas`, `overlay_renderer.py`, layout, and chart
   renderers.
6. Migration of fixed runtime-created widgets into `.ui` files.
7. Extraction of table/dialog controllers and final `MainWindow` cleanup.
