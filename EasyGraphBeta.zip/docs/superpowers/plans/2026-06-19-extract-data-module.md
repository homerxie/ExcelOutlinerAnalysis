# Extract Data Module Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move DataFrame transformation, grouping, ordering, outlier, and chart-axis semantic helpers into a GUI-independent `easygraph.data` module while keeping the `app.*` API intact.

**Architecture:** `easygraph.data` depends only on NumPy, pandas, the standard library, and `easygraph.settings.ChartSettings`. `src/app.py` explicitly imports and re-exports every moved function. Palette, overlay, persistence, plotting, and Qt behavior remain in their current owners for later extraction.

**Tech Stack:** Python 3.10, NumPy, pandas, `unittest`

---

## Extraction Boundary

Move exactly these functions:

```text
sample_data
blank_project_data
prepare_plot_data
hidden_group_names
unique_groups
values_for_group
ordered_group_columns
box_whis
axis_labels_for_chart
mark_outliers
```

### Task 1: Define the data-module contract (RED)

**Files:**
- Create: `tests/test_data_module.py`

- [ ] **Step 1: Write the failing contract tests**

Create `tests/test_data_module.py`:

```python
import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class DataModuleTests(EasyGraphTestCase):
    def test_app_reexports_data_module_api(self):
        from easygraph import data

        expected_exports = (
            "axis_labels_for_chart",
            "blank_project_data",
            "box_whis",
            "hidden_group_names",
            "mark_outliers",
            "ordered_group_columns",
            "prepare_plot_data",
            "sample_data",
            "unique_groups",
            "values_for_group",
        )

        self.assertEqual(data.__all__, list(expected_exports))
        for name in expected_exports:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(data, name))

    def test_data_module_imports_without_gui_or_plotting_stack(self):
        source_path = str(ROOT / "src")
        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = source_path + (os.pathsep + existing_pythonpath if existing_pythonpath else "")
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.data import sample_data
assert sample_data().shape[1] == 3
assert not any(name == 'PySide6' or name.startswith('PySide6.') for name in sys.modules)
assert not any(name == 'matplotlib' or name.startswith('matplotlib.') for name in sys.modules)
"""

        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
```

- [ ] **Step 2: Verify meaningful RED**

Run:

```bash
./.venv/bin/python -m unittest tests.test_data_module -v
```

Expected: both tests fail because `easygraph.data` does not exist, not because
of test syntax or subprocess path setup.

- [ ] **Step 3: Review RED tests before implementation**

Compile the test and run `git diff --check`. Do not commit the failing state;
carry it into Task 2 after spec and quality review.

### Task 2: Move pure data functions and preserve compatibility (GREEN)

**Files:**
- Create: `src/easygraph/data.py`
- Modify: `src/app.py`
- Include: `tests/test_data_module.py`

- [ ] **Step 1: Create the module and move functions unchanged**

Create `src/easygraph/data.py` with:

```python
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from easygraph.settings import ChartSettings
```

Move the ten audited function definitions without changing their signatures or
bodies. End with:

```python
__all__ = [
    "axis_labels_for_chart",
    "blank_project_data",
    "box_whis",
    "hidden_group_names",
    "mark_outliers",
    "ordered_group_columns",
    "prepare_plot_data",
    "sample_data",
    "unique_groups",
    "values_for_group",
]
```

- [ ] **Step 2: Import and re-export from `app.py`**

Add an explicit import next to the settings import:

```python
from easygraph.data import (
    axis_labels_for_chart,
    blank_project_data,
    box_whis,
    hidden_group_names,
    mark_outliers,
    ordered_group_columns,
    prepare_plot_data,
    sample_data,
    unique_groups,
    values_for_group,
)
```

Delete the original ten definitions from `app.py`. Keep `math`, NumPy, and
pandas imports there because live plotting, palette, and I/O code still uses
them.

- [ ] **Step 3: Run GREEN and focused domain regression tests**

Run:

```bash
./.venv/bin/python -m unittest tests.test_data_module -v
./.venv/bin/python scripts/run_tests.py --slow 5 tests.test_data
```

Expected: two module-contract tests and all 15 existing data tests pass.

- [ ] **Step 4: Run static ownership and compilation checks**

Run:

```bash
./.venv/bin/python -m py_compile src/easygraph/data.py src/app.py tests/test_data_module.py
rg -n "^def (sample_data|blank_project_data|prepare_plot_data|hidden_group_names|unique_groups|values_for_group|ordered_group_columns|box_whis|axis_labels_for_chart|mark_outliers)\b" src/app.py
git diff --check
```

Expected: compile and diff checks pass; `rg` finds no local definitions in
`app.py`.

- [ ] **Step 5: Run full compatibility suite**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 20
```

Expected: 241 tests pass.

- [ ] **Step 6: Commit extraction**

```bash
git add src/easygraph/data.py src/app.py tests/test_data_module.py
git commit -m "refactor: extract data module"
```

### Task 3: Document and verify the data boundary

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update architecture and test inventory**

- Add `src/easygraph/data.py` as owner of wide-to-long conversion, duplicate
  group handling, group ordering, outlier detection, sample/blank data, and
  chart-axis label semantics.
- State `src/app.py` re-exports former data helper names.
- Add `tests/test_data_module.py` to inventory and compile command.
- Change expected count from 239 to 241.
- Do not claim palette, overlay, plotting, persistence, or MainWindow extraction.

- [ ] **Step 2: Run final gates**

Run:

```bash
./.venv/bin/python scripts/run_tests.py --slow 20
./.venv/bin/python -m py_compile \
  src/app.py src/easygraph/settings.py src/easygraph/data.py \
  tests/test_architecture.py tests/test_settings_module.py \
  tests/test_data_module.py tests/easygraph_case.py tests/test_data.py \
  tests/test_palette.py tests/test_project_io.py tests/test_core.py \
  tests/test_support.py tests/test_warning_policy.py tests/test_test_runner.py \
  scripts/run_tests.py
./.venv/bin/pyside6-uic ui/main_window.ui -o /tmp/easygraph_ui_main_window.py
cmp src/ui_main_window.py /tmp/easygraph_ui_main_window.py
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o /tmp/easygraph_ui_group_order_dialog.py
cmp src/ui_group_order_dialog.py /tmp/easygraph_ui_group_order_dialog.py
git diff --check
```

Expected: 241 tests pass, compilation succeeds, and both UI comparisons are
exact.

- [ ] **Step 3: Record file sizes and commit docs**

Run `wc -l src/app.py src/easygraph/data.py`, report the counts in the handoff,
then commit README only:

```bash
git add README.md
git commit -m "docs: describe data module"
```

## Final Review Checklist

- [ ] Exact ten-name `__all__` and app identity re-exports.
- [ ] `easygraph.data` imports without Qt or Matplotlib.
- [ ] Function signatures and bodies are unchanged.
- [ ] No duplicate data definitions remain in `app.py`.
- [ ] Full suite reports 241 passing tests.
