# Extract Plot Canvas Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move the existing `PlotCanvas` implementation out of `src/app.py` into `easygraph.plotting.canvas` without changing plotting behavior or the public `app.PlotCanvas` API.

**Architecture:** This is the first Stage 4 plotting step from the incremental refactor design. Move `ScrollFriendlyFigureCanvas`, `CoordinatesToolbar`, `PlotCanvas`, and the canvas-owned overlay label/line-style helpers as one intact unit so the new module does not import `app.py`. `src/app.py` remains the executable UI coordinator and directly imports/re-exports the moved public names for compatibility.

**Tech Stack:** Python 3.10, PySide6, Matplotlib, Seaborn, SciPy, pandas, NumPy, `unittest`

---

## Locked Boundaries

- Create `src/easygraph/plotting/__init__.py`.
- Create `src/easygraph/plotting/canvas.py`.
- Create `tests/test_plotting.py`.
- Modify `src/app.py`.
- Modify `README.md`.
- Do not modify `ui/main_window.ui`, `ui/group_order_dialog.ui`, `src/ui_main_window.py`, or `src/ui_group_order_dialog.py`.
- Do not split chart rendering, legend layout, overlay rendering, or statistics-table layout in this plan. That happens after the intact class move is stable.
- Do not import `app` from `easygraph.plotting.canvas`; that creates a circular dependency because `MainWindow` imports `PlotCanvas`.

## Current Source Ranges

Move these exact class/function bodies from `src/app.py`:

- `ScrollFriendlyFigureCanvas`: lines 445-457 at plan creation.
- `CoordinatesToolbar`: lines 524-535 at plan creation.
- `PlotCanvas`: lines 538-2813 at plan creation.
- `overlay_label_bbox`: lines 5575-5585 at plan creation.
- `overlay_label_arrow`: lines 5588-5596 at plan creation.
- `overlay_line_style`: lines 5599-5600 at plan creation.
- `overlay_line_qt_pen_style`: lines 5603-5604 at plan creation.
- `draw_line_style_preview`: lines 5607-5684 at plan creation.
- `line_style_icon`: lines 5687-5704 at plan creation.
- `overlay_label_position_for_series`: lines 5707-5709 at plan creation.
- `overlay_auto_avoidance_position`: lines 5712-5726 at plan creation.
- `normalize_overlay_label_position`: lines 5729-5745 at plan creation.
- `resolve_overlay_label_position`: lines 5748-5767 at plan creation.
- `overlay_label_offset`: lines 5770-5790 at plan creation.
- `overlay_values_are_close`: lines 5793-5804 at plan creation.

Move these constants from `src/app.py` to `src/easygraph/plotting/canvas.py` and import/re-export them from `app.py`:

```python
OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO
OVERLAY_CONTENT_MARGIN_RATIO
AUTO_AXIS_RANGE_PADDING_FRACTION
LEGEND_MAX_COLUMNS
LEGEND_COLUMN_SPACING
LEGEND_HANDLE_LENGTH
LEGEND_HANDLE_SPACE_UNITS
LEGEND_SECONDARY_AXIS_GAP_PX
MAX_MANUAL_TICK_COUNT
STAT_OVERLAY_ALPHA
LINE_OVERLAY_STYLE_TO_MPL
LINE_OVERLAY_STYLE_TO_QT
LINE_STYLE_ICON_SIZE
LINE_STYLE_ICON_DEVICE_RATIOS
LINE_STYLE_POPUP_PREVIEW_WIDTH
LINE_STYLE_POPUP_ROW_HEIGHT
LINE_STYLE_PREVIEW_STROKE_WIDTH
LINE_STYLE_PREVIEW_DOT_RADIUS
```

`DataTable`, `LineStyleItemDelegate`, `MainWindow`, file dialogs, translated error text, current project state, table synchronization, and recent-project preferences remain in `src/app.py`.

## Exact Public API

`easygraph.plotting.canvas.__all__` is exactly:

```python
[
    "AUTO_AXIS_RANGE_PADDING_FRACTION",
    "CoordinatesToolbar",
    "LEGEND_COLUMN_SPACING",
    "LEGEND_HANDLE_LENGTH",
    "LEGEND_HANDLE_SPACE_UNITS",
    "LEGEND_MAX_COLUMNS",
    "LEGEND_SECONDARY_AXIS_GAP_PX",
    "LINE_OVERLAY_STYLE_TO_MPL",
    "LINE_OVERLAY_STYLE_TO_QT",
    "LINE_STYLE_ICON_DEVICE_RATIOS",
    "LINE_STYLE_ICON_SIZE",
    "LINE_STYLE_POPUP_PREVIEW_WIDTH",
    "LINE_STYLE_POPUP_ROW_HEIGHT",
    "LINE_STYLE_PREVIEW_DOT_RADIUS",
    "LINE_STYLE_PREVIEW_STROKE_WIDTH",
    "MAX_MANUAL_TICK_COUNT",
    "OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS",
    "OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO",
    "OVERLAY_CONTENT_MARGIN_RATIO",
    "PlotCanvas",
    "STAT_OVERLAY_ALPHA",
    "ScrollFriendlyFigureCanvas",
    "draw_line_style_preview",
    "line_style_icon",
    "normalize_overlay_label_position",
    "overlay_auto_avoidance_position",
    "overlay_label_arrow",
    "overlay_label_bbox",
    "overlay_label_offset",
    "overlay_label_position_for_series",
    "overlay_line_qt_pen_style",
    "overlay_line_style",
    "overlay_values_are_close",
    "resolve_overlay_label_position",
]
```

`src/app.py` must import every name above directly from `easygraph.plotting.canvas`. Existing tests and callers continue to use `app.PlotCanvas`, `app.CoordinatesToolbar`, `app.STAT_OVERLAY_ALPHA`, `app.line_style_icon`, and the overlay label helper functions.

## Import Rules for `canvas.py`

`src/easygraph/plotting/canvas.py` may import:

- Standard library: `math`, `os`, `re`, `tempfile`, `unicodedata`, `BytesIO`, `asdict`, `Path`.
- NumPy, pandas, Seaborn, SciPy `gaussian_kde`.
- Matplotlib: `FigureCanvasQTAgg`, `NavigationToolbar2QT`, `PathCollection`, `Figure`, `Rectangle`, `AutoLocator`, `MultipleLocator`, `Bbox`.
- PySide6: `Qt`, `QTimer`, `QColor`, `QIcon`, `QImage`, `QPainter`, `QPen`, `QPixmap`, `QApplication`, `QHBoxLayout`, `QPushButton`, `QScrollArea`, `QSizePolicy`, `QVBoxLayout`, `QWidget`.
- Existing focused EasyGraph modules:
  - `easygraph.settings`
  - `easygraph.data`
  - `easygraph.palette`
  - `easygraph.overlay_series`

`canvas.py` must not import `app`, `easygraph.project_io`, `easygraph.template_io`, `easygraph.spreadsheet_io`, generated UI modules, or Qt `.ui` classes.

Because `canvas.py` imports Matplotlib directly, it must set up `MPLCONFIGDIR` before Matplotlib imports, matching the app's existing local temp behavior:

```python
os.environ.setdefault(
    "MPLCONFIGDIR",
    str(Path(tempfile.gettempdir()) / "easygraph_matplotlib"),
)
Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)
```

## Test Count

The current full suite has 256 tests. This plan adds four plotting contract tests, so the expected full-suite count after Stage 4A is 260.

## Task 1: Add Plotting Module Contract Tests (RED)

**Files:**
- Create: `tests/test_plotting.py`

- [ ] **Step 1: Create `tests/test_plotting.py` with four contract tests**

Use this complete file:

```python
import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphQtTestCase, EasyGraphTestCase, app


class PlottingModuleContractTests(EasyGraphTestCase):

    def test_plotting_canvas_api_is_exact_and_shared_with_app(self):
        from easygraph.plotting import canvas

        expected = [
            "AUTO_AXIS_RANGE_PADDING_FRACTION",
            "CoordinatesToolbar",
            "LEGEND_COLUMN_SPACING",
            "LEGEND_HANDLE_LENGTH",
            "LEGEND_HANDLE_SPACE_UNITS",
            "LEGEND_MAX_COLUMNS",
            "LEGEND_SECONDARY_AXIS_GAP_PX",
            "LINE_OVERLAY_STYLE_TO_MPL",
            "LINE_OVERLAY_STYLE_TO_QT",
            "LINE_STYLE_ICON_DEVICE_RATIOS",
            "LINE_STYLE_ICON_SIZE",
            "LINE_STYLE_POPUP_PREVIEW_WIDTH",
            "LINE_STYLE_POPUP_ROW_HEIGHT",
            "LINE_STYLE_PREVIEW_DOT_RADIUS",
            "LINE_STYLE_PREVIEW_STROKE_WIDTH",
            "MAX_MANUAL_TICK_COUNT",
            "OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS",
            "OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO",
            "OVERLAY_CONTENT_MARGIN_RATIO",
            "PlotCanvas",
            "STAT_OVERLAY_ALPHA",
            "ScrollFriendlyFigureCanvas",
            "draw_line_style_preview",
            "line_style_icon",
            "normalize_overlay_label_position",
            "overlay_auto_avoidance_position",
            "overlay_label_arrow",
            "overlay_label_bbox",
            "overlay_label_offset",
            "overlay_label_position_for_series",
            "overlay_line_qt_pen_style",
            "overlay_line_style",
            "overlay_values_are_close",
            "resolve_overlay_label_position",
        ]
        self.assertEqual(canvas.__all__, expected)
        for name in expected:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(canvas, name))

    def test_direct_plotting_canvas_import_does_not_import_app(self):
        source_path = str(ROOT / "src")
        environment = os.environ.copy()
        existing_pythonpath = environment.get("PYTHONPATH", "")
        environment["PYTHONPATH"] = source_path + (
            os.pathsep + existing_pythonpath if existing_pythonpath else ""
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.plotting import canvas

if "app" in sys.modules:
    raise SystemExit("canvas imported app")
required = ["PlotCanvas", "ScrollFriendlyFigureCanvas", "CoordinatesToolbar"]
missing = [name for name in required if not hasattr(canvas, name)]
if missing:
    raise SystemExit("missing: " + ", ".join(missing))
if canvas.overlay_label_offset(0, [1.0], "Above", False) != (0, 13, "center", "bottom"):
    raise SystemExit("overlay helper behavior changed")
"""
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=20,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )


class PlottingModuleQtTests(EasyGraphQtTestCase):

    def test_plot_canvas_constructs_scroll_friendly_canvas_and_toolbar(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)

        self.assertIsInstance(plot_canvas.canvas, canvas.ScrollFriendlyFigureCanvas)
        self.assertIsInstance(plot_canvas.toolbar, canvas.CoordinatesToolbar)
        self.assertIs(plot_canvas.canvas.owner, plot_canvas)
        self.assertIsNotNone(plot_canvas.findChild(app.QPushButton, "zoomToFitButton"))

    def test_main_window_uses_extracted_plot_canvas(self):
        from easygraph.plotting import canvas

        window = self.make_window(initial_render=False)

        self.assertIsInstance(window.canvas, canvas.PlotCanvas)
        self.assertIs(window.canvas.selection_callback.__self__, window)
        self.assertIs(
            window.canvas.selection_callback.__func__,
            window.handle_plot_object_selection.__func__,
        )
        self.assertIs(window.canvas.legend_position_callback.__self__, window)
        self.assertIs(
            window.canvas.legend_position_callback.__func__,
            window.handle_legend_drag_position.__func__,
        )
```

- [ ] **Step 2: Run meaningful RED**

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest tests.test_plotting -v
```

Expected: `Ran 4 tests` with failures/errors because `easygraph.plotting.canvas` does not exist. Existing app-backed behavior may still work, but the new module import must fail before production code is added.

- [ ] **Step 3: Commit nothing yet**

Keep the RED test uncommitted until Task 2 creates the module and the tests pass. This keeps one coherent extraction commit.

## Task 2: Move PlotCanvas Intact and Preserve App Compatibility (GREEN)

**Files:**
- Create: `src/easygraph/plotting/__init__.py`
- Create: `src/easygraph/plotting/canvas.py`
- Modify: `src/app.py`
- Modify: `tests/test_plotting.py`

- [ ] **Step 1: Create the plotting package**

Create `src/easygraph/plotting/__init__.py` as an empty package marker.

- [ ] **Step 2: Create `src/easygraph/plotting/canvas.py`**

Start the file with:

```python
from __future__ import annotations

import math
import os
import re
import tempfile
import unicodedata
from dataclasses import asdict
from io import BytesIO
from pathlib import Path

os.environ.setdefault(
    "MPLCONFIGDIR",
    str(Path(tempfile.gettempdir()) / "easygraph_matplotlib"),
)
Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.collections import PathCollection
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle
from matplotlib.ticker import AutoLocator, MultipleLocator
from matplotlib.transforms import Bbox
from scipy.stats import gaussian_kde

from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QColor, QIcon, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)
```

Then import the focused EasyGraph dependencies:

```python
from easygraph.settings import (
    ChartSettings,
    LEGEND_INSIDE_AUTO_POSITION,
    LEGEND_POSITION_INSIDE,
    PRESETS,
)
from easygraph.data import (
    axis_labels_for_chart,
    box_whis,
    mark_outliers,
    prepare_plot_data,
)
from easygraph.palette import (
    _relative_luminance,
    derived_group_color,
    palette_for,
)
from easygraph.overlay_series import (
    format_overlay_value,
    line_overlay_series,
    overlay_palette_for,
    overlay_style_for_series,
    stat_table_data,
    stat_table_header_enabled,
    visible_custom_overlay_indexes,
)
```

- [ ] **Step 3: Move constants and helper functions**

Move the constants listed in this plan's "Current Source Ranges" section from `app.py` to `canvas.py`.

Move the 12 helper function bodies listed in "Current Source Ranges" from `app.py` to `canvas.py` without changing their bodies. Keep their order.

- [ ] **Step 4: Move the three canvas classes intact**

Move the exact class bodies for `ScrollFriendlyFigureCanvas`, `CoordinatesToolbar`, and `PlotCanvas` from `app.py` into `canvas.py` without changing method bodies.

Do not move `DataTable`.

- [ ] **Step 5: Add `__all__`**

End `canvas.py` with the exact `__all__` list from the "Exact Public API" section.

- [ ] **Step 6: Import/re-export canvas names from `app.py`**

In `src/app.py`, after the overlay-series import block and before any classes that use line-style helpers, add:

```python
from easygraph.plotting.canvas import (
    AUTO_AXIS_RANGE_PADDING_FRACTION,
    CoordinatesToolbar,
    LEGEND_COLUMN_SPACING,
    LEGEND_HANDLE_LENGTH,
    LEGEND_HANDLE_SPACE_UNITS,
    LEGEND_MAX_COLUMNS,
    LEGEND_SECONDARY_AXIS_GAP_PX,
    LINE_OVERLAY_STYLE_TO_MPL,
    LINE_OVERLAY_STYLE_TO_QT,
    LINE_STYLE_ICON_DEVICE_RATIOS,
    LINE_STYLE_ICON_SIZE,
    LINE_STYLE_POPUP_PREVIEW_WIDTH,
    LINE_STYLE_POPUP_ROW_HEIGHT,
    LINE_STYLE_PREVIEW_DOT_RADIUS,
    LINE_STYLE_PREVIEW_STROKE_WIDTH,
    MAX_MANUAL_TICK_COUNT,
    OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS,
    OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO,
    OVERLAY_CONTENT_MARGIN_RATIO,
    PlotCanvas,
    STAT_OVERLAY_ALPHA,
    ScrollFriendlyFigureCanvas,
    draw_line_style_preview,
    line_style_icon,
    normalize_overlay_label_position,
    overlay_auto_avoidance_position,
    overlay_label_arrow,
    overlay_label_bbox,
    overlay_label_offset,
    overlay_label_position_for_series,
    overlay_line_qt_pen_style,
    overlay_line_style,
    overlay_values_are_close,
    resolve_overlay_label_position,
)
```

Delete the moved constants, helper function definitions, and class definitions from `app.py`. Keep imports used by the remaining application code. Remove imports that become unused only after verifying with static search.

- [ ] **Step 7: Verify no moved definitions remain in `app.py`**

```bash
./.venv/bin/python - <<'PY'
import ast
from pathlib import Path

moved = {
    "ScrollFriendlyFigureCanvas",
    "CoordinatesToolbar",
    "PlotCanvas",
    "overlay_label_bbox",
    "overlay_label_arrow",
    "overlay_line_style",
    "overlay_line_qt_pen_style",
    "draw_line_style_preview",
    "line_style_icon",
    "overlay_label_position_for_series",
    "overlay_auto_avoidance_position",
    "normalize_overlay_label_position",
    "resolve_overlay_label_position",
    "overlay_label_offset",
    "overlay_values_are_close",
}
tree = ast.parse(Path("src/app.py").read_text(encoding="utf-8"))
remaining = sorted(
    node.name for node in tree.body
    if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
    and node.name in moved
)
if remaining:
    raise SystemExit("moved definitions remain: " + ", ".join(remaining))
print("no moved plotting definitions remain in app.py")
PY
```

Expected: exact success message.

- [ ] **Step 8: Verify AST-equivalent moved bodies**

Compare against the plan-start commit. Use the actual base commit before Task 1 as `BASE_SHA`:

```bash
export BASE_SHA="$(git rev-parse HEAD)"
./.venv/bin/python - <<'PY'
import ast
import os
import subprocess
from pathlib import Path

base_sha = os.environ["BASE_SHA"]
baseline_source = subprocess.check_output(["git", "show", f"{base_sha}:src/app.py"], text=True)
before = {
    node.name: node
    for node in ast.parse(baseline_source).body
    if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
}
after = {
    node.name: node
    for node in ast.parse(Path("src/easygraph/plotting/canvas.py").read_text(encoding="utf-8")).body
    if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
}
names = [
    "ScrollFriendlyFigureCanvas",
    "CoordinatesToolbar",
    "PlotCanvas",
    "overlay_label_bbox",
    "overlay_label_arrow",
    "overlay_line_style",
    "overlay_line_qt_pen_style",
    "draw_line_style_preview",
    "line_style_icon",
    "overlay_label_position_for_series",
    "overlay_auto_avoidance_position",
    "normalize_overlay_label_position",
    "resolve_overlay_label_position",
    "overlay_label_offset",
    "overlay_values_are_close",
]
for name in names:
    if ast.dump(before[name], include_attributes=False) != ast.dump(after[name], include_attributes=False):
        raise SystemExit(f"unexpected body change: {name}")
print("plot canvas moved bodies match baseline")
PY
```

Expected: exact success message. If the shell environment does not preserve `BASE_SHA` through the here-doc command runner, replace `os.environ["BASE_SHA"]` with the literal base SHA captured before editing.

- [ ] **Step 9: Run focused GREEN tests**

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest tests.test_plotting -v
```

Expected: `Ran 4 tests` and `OK`.

Run a focused existing PlotCanvas smoke set:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest \
  tests.test_core.EasyGraphCoreTests.test_plot_canvas_keeps_coordinates_without_matplotlib_buttons \
  tests.test_core.EasyGraphCoreTests.test_zoom_to_fit_scales_to_viewport_without_resize_autofit \
  tests.test_core.EasyGraphCoreTests.test_initial_render_zoom_to_fit_after_startup \
  tests.test_core.EasyGraphCoreTests.test_line_overlay_label_offsets_avoid_close_points \
  tests.test_core.EasyGraphCoreTests.test_auto_y_range_uses_double_default_padding \
  -v
```

Expected: `Ran 5 tests` and `OK`.

- [ ] **Step 10: Verify import boundaries**

```bash
if rg -n '(^| )import app|from app|easygraph\.(project_io|template_io|spreadsheet_io)|ui_main_window|ui_group_order_dialog' src/easygraph/plotting/canvas.py; then
  echo 'unexpected canvas dependency'
  exit 1
else
  echo 'plotting canvas dependency boundary clean'
fi
```

Expected: boundary-clean message.

- [ ] **Step 11: Compile and run full suite**

```bash
./.venv/bin/python -m py_compile src/app.py src/easygraph/plotting/__init__.py src/easygraph/plotting/canvas.py tests/test_plotting.py tests/test_core.py
```

Expected: exit 0 and no output.

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/run_tests.py
```

Expected: `260 tests`, all passing.

- [ ] **Step 12: Commit extraction**

```bash
git add src/easygraph/plotting/__init__.py src/easygraph/plotting/canvas.py src/app.py tests/test_plotting.py
git commit -m "refactor: extract plot canvas"
```

After the commit, perform spec review first, then code-quality review. Fix review findings before Task 3.

## Task 3: Document Plot Canvas Boundary and Verify UI Stability

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update README main-file list**

Add:

```text
src/easygraph/plotting/__init__.py
src/easygraph/plotting/canvas.py
tests/test_plotting.py
```

- [ ] **Step 2: Update README descriptions**

Document:

- `src/easygraph/plotting/canvas.py` owns the Qt/Matplotlib plot canvas lifecycle, zooming, interaction feedback, figure export/clipboard image, and the still-intact chart rendering/layout methods.
- It currently still contains chart rendering, legend/layout, statistics-table, and Matplotlib overlay rendering internals. Those are intentionally not split yet.
- `src/app.py` remains the executable application module, compatibility facade, and UI coordinator; it directly re-exports `PlotCanvas` and canvas helper names.
- `tests/test_plotting.py` owns plotting-module contract tests.
- The expected full-suite count is 260.

- [ ] **Step 3: Update compile command in README**

Add `src/easygraph/plotting/__init__.py`, `src/easygraph/plotting/canvas.py`, and `tests/test_plotting.py` to the documented `py_compile` command.

- [ ] **Step 4: Verify generated UI files are unchanged**

```bash
./.venv/bin/pyside6-uic ui/main_window.ui -o /tmp/easygraph-ui-main.py
cmp /tmp/easygraph-ui-main.py src/ui_main_window.py
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o /tmp/easygraph-ui-group-order.py
cmp /tmp/easygraph-ui-group-order.py src/ui_group_order_dialog.py
git diff --exit-code -- ui/main_window.ui ui/group_order_dialog.ui src/ui_main_window.py src/ui_group_order_dialog.py
```

Expected: all commands exit 0 with no diff.

- [ ] **Step 5: Run final verification**

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/run_tests.py --slow 20
```

Expected: `260 tests`, all passing. Slow-test reporting is diagnostic; warnings remain textual and no screenshot is transmitted unless an image/screenshot tool is explicitly called.

```bash
wc -l src/app.py src/easygraph/plotting/canvas.py
git diff --check
git status --short
```

Expected: `app.py` is shorter, `canvas.py` contains the moved class, `git diff --check` is clean, and status contains only the intended README change.

- [ ] **Step 6: Commit documentation**

```bash
git add README.md
git commit -m "docs: describe plot canvas boundary"
```

After the commit, perform a holistic spec review against `docs/superpowers/specs/2026-06-19-incremental-app-refactor-design.md` and this plan, then a holistic code-quality review across the stage diff. Fix review findings and re-run the relevant verification gates before reporting completion.

## Self-Review Record

- **Spec coverage:** This plan implements Stage 4's first step only: move `PlotCanvas` intact to `plotting/canvas.py`. It explicitly defers `overlay_renderer.py`, `layout.py`, and `chart_renderers.py` until the intact move is stable.
- **Placeholder scan:** No `TBD`, `TODO`, or "similar to" placeholders remain. The contract tests, public API, moved names, file list, and verification commands are explicit.
- **Type consistency:** The public compatibility surface stays object-identity based through direct imports from `app.py`; tests assert `app.name is canvas.name` for every public plotting-canvas name.
- **Count consistency:** Four new plotting contract tests increase the full-suite count from 256 to 260.
