# Extract Palette Module Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move palette selection, expansion, color-space, contrast, and derived-color logic into `easygraph.palette` while preserving `app.*` compatibility and exact color behavior.

**Architecture:** Preserve the existing `QColor` implementation to avoid color-rounding changes. The new module may depend on `PySide6.QtGui.QColor`, NumPy, pandas, and settings, but must not import Qt Widgets, Matplotlib, Seaborn, or SciPy. The precomputed cache continues to read `src/palette_cache.json` after the module moves under `src/easygraph/`.

**Tech Stack:** Python 3.10, PySide6 QtGui, NumPy, pandas, `unittest`

---

## Extraction Boundary

Move constants:

```text
PRECOMPUTED_PALETTE_COUNT
PRECOMPUTED_PALETTE_PATH
```

Move functions:

```text
palette_for
group_color_map_for_groups
normalize_color_name
first_unused_palette_color
palette_choices_for_group_count
expanded_preset_palette
_precomputed_palette_for
_precomputed_palette_cache
_expanded_preset_palette_cached
_append_farthest_lab_colors
_style_matched_palette_candidates
_resampled_sequential_palette
_palette_is_monochrome
_expanded_monochrome_palette
_minimum_lab_distance
_lab_distance
_qcolor_to_lab
_contrast_ratio
_relative_luminance
blend_qcolors
derived_group_color
```

### Task 1: Define palette ownership and dependency contracts (RED)

**Files:**
- Create: `tests/test_palette_module.py`

- [ ] **Step 1: Write failing module-contract tests**

Create `tests/test_palette_module.py`:

```python
import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class PaletteModuleTests(EasyGraphTestCase):
    def test_app_reexports_palette_module_api(self):
        from easygraph import palette

        public_exports = (
            "PRECOMPUTED_PALETTE_COUNT",
            "PRECOMPUTED_PALETTE_PATH",
            "blend_qcolors",
            "derived_group_color",
            "expanded_preset_palette",
            "first_unused_palette_color",
            "group_color_map_for_groups",
            "normalize_color_name",
            "palette_choices_for_group_count",
            "palette_for",
        )
        private_helpers = (
            "_append_farthest_lab_colors",
            "_contrast_ratio",
            "_expanded_monochrome_palette",
            "_expanded_preset_palette_cached",
            "_lab_distance",
            "_minimum_lab_distance",
            "_palette_is_monochrome",
            "_precomputed_palette_cache",
            "_precomputed_palette_for",
            "_qcolor_to_lab",
            "_relative_luminance",
            "_resampled_sequential_palette",
            "_style_matched_palette_candidates",
        )

        self.assertEqual(palette.__all__, list(public_exports))
        for name in (*public_exports, *private_helpers):
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(palette, name))

    def test_palette_module_imports_without_widgets_or_plotting_stack(self):
        source_path = str(ROOT / "src")
        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = source_path + (os.pathsep + existing_pythonpath if existing_pythonpath else "")
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.palette import expanded_preset_palette
assert len(expanded_preset_palette('Paper Clean', 8)) == 8
assert 'PySide6.QtWidgets' not in sys.modules
assert not any(name == 'matplotlib' or name.startswith('matplotlib.') for name in sys.modules)
assert not any(name == 'seaborn' or name.startswith('seaborn.') for name in sys.modules)
assert not any(name == 'scipy' or name.startswith('scipy.') for name in sys.modules)
"""
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=False,
            timeout=15,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_palette_cache_path_stays_at_src_root(self):
        from easygraph import palette

        self.assertEqual(palette.PRECOMPUTED_PALETTE_PATH, ROOT / "src" / "palette_cache.json")
        self.assertTrue(palette.PRECOMPUTED_PALETTE_PATH.is_file())
```

- [ ] **Step 2: Verify meaningful RED**

Run `./.venv/bin/python -m unittest tests.test_palette_module -v`.
Expected: three tests fail because `easygraph.palette` does not exist; compile
and diff checks still pass. Do not commit the failing state.

### Task 2: Move palette implementation and preserve compatibility (GREEN)

**Files:**
- Create: `src/easygraph/palette.py`
- Modify: `src/app.py`
- Include: `tests/test_palette_module.py`

- [ ] **Step 1: Create module dependencies and stable cache path**

Start the module with:

```python
from __future__ import annotations

import json
import math
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from PySide6.QtGui import QColor

from easygraph.settings import PRESETS, SEQUENTIAL_PALETTE_PRESETS, ChartSettings

PRECOMPUTED_PALETTE_COUNT = 100
PRECOMPUTED_PALETTE_PATH = Path(__file__).resolve().parents[1] / "palette_cache.json"
```

The path expression intentionally differs from the old `with_name` expression
so it resolves to the same existing `src/palette_cache.json` after relocation.

- [ ] **Step 2: Move function bodies unchanged**

Move all 21 listed functions without changing signatures/bodies. End with the
exact `__all__` required by the RED test:

```python
__all__ = [
    "PRECOMPUTED_PALETTE_COUNT",
    "PRECOMPUTED_PALETTE_PATH",
    "blend_qcolors",
    "derived_group_color",
    "expanded_preset_palette",
    "first_unused_palette_color",
    "group_color_map_for_groups",
    "normalize_color_name",
    "palette_choices_for_group_count",
    "palette_for",
]
```

- [ ] **Step 3: Explicitly import all moved names into `app.py`**

Import both public exports and 13 private helpers from `easygraph.palette` so
existing tests/callers retain object identity. Delete the two original constants
and 21 original definitions. Keep `QColor`, JSON, math, `lru_cache`, Path,
NumPy, and pandas imports in `app.py` when other live code still uses them;
remove an import only after `rg` proves it unused.

- [ ] **Step 4: Run GREEN, palette regressions, and static checks**

Run:

```bash
./.venv/bin/python -m unittest tests.test_palette_module -v
./.venv/bin/python scripts/run_tests.py --slow 10 tests.test_palette
./.venv/bin/python -m py_compile src/easygraph/palette.py src/app.py tests/test_palette_module.py
rg -n "^def (palette_for|group_color_map_for_groups|normalize_color_name|first_unused_palette_color|palette_choices_for_group_count|expanded_preset_palette|_precomputed_palette_for|_precomputed_palette_cache|_expanded_preset_palette_cached|_append_farthest_lab_colors|_style_matched_palette_candidates|_resampled_sequential_palette|_palette_is_monochrome|_expanded_monochrome_palette|_minimum_lab_distance|_lab_distance|_qcolor_to_lab|_contrast_ratio|_relative_luminance|blend_qcolors|derived_group_color)\b|^PRECOMPUTED_PALETTE_(COUNT|PATH)" src/app.py
```

Expected: three contract and 23 existing palette tests pass; static search finds
no local definitions in `app.py`.

- [ ] **Step 5: Run full suite and commit**

Run `./.venv/bin/python scripts/run_tests.py --slow 20`; expect 244 tests.
Then:

```bash
git add src/easygraph/palette.py src/app.py tests/test_palette_module.py
git commit -m "refactor: extract palette module"
```

### Task 3: Document and fully verify palette ownership

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update README**

- Add `src/easygraph/palette.py` as owner of palette expansion, QColor-based
  color derivation, contrast, and precomputed cache loading.
- Explicitly state it uses QtGui `QColor` but not Qt Widgets or Matplotlib.
- State `app.py` re-exports former palette helper names.
- Add `tests/test_palette_module.py` to inventory/compile command.
- Change expected count 241→244.
- Do not claim overlay-series or plotting extraction.

- [ ] **Step 2: Run final gates**

Run full 244-test suite, compile all current modules/tests, regenerate and
compare both UI files, run `git diff --check`, and run
`wc -l src/app.py src/easygraph/palette.py` for the handoff.

- [ ] **Step 3: Commit docs**

```bash
git add README.md
git commit -m "docs: describe palette module"
```

## Final Review Checklist

- [ ] All 23 moved names preserve `app` identity.
- [ ] Public `__all__` is exactly ten names; private helpers remain importable
      through explicit app compatibility imports.
- [ ] Cache path still targets the existing root `src/palette_cache.json`.
- [ ] No Qt Widgets, Matplotlib, Seaborn, or SciPy import from palette module.
- [ ] Existing palette outputs and caches remain unchanged.
- [ ] Full suite reports 244 tests.
