from __future__ import annotations

import argparse
import datetime as dt
import zipfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PACKAGE_NAME = "EasyGraph-windows-source"

INCLUDE_PATHS = [
    "src",
    "ui",
    "translations",
    "template/.gitkeep",
    "tests",
    "requirements.txt",
    "requirements-windows.txt",
    "README.md",
    "WINDOWS_BUILD.md",
]

EXCLUDE_PARTS = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
}

EXCLUDE_SUFFIXES = {
    ".pyc",
    ".pyo",
}


def iter_package_files() -> list[Path]:
    files: list[Path] = []
    for include in INCLUDE_PATHS:
        path = PROJECT_ROOT / include
        if not path.exists():
            raise FileNotFoundError(f"Missing required package path: {include}")
        if path.is_file():
            files.append(path)
            continue
        for child in path.rglob("*"):
            if not child.is_file():
                continue
            relative = child.relative_to(PROJECT_ROOT)
            if any(part in EXCLUDE_PARTS for part in relative.parts):
                continue
            if child.suffix in EXCLUDE_SUFFIXES:
                continue
            if relative.match("template/*.json"):
                continue
            files.append(child)
    return sorted(files)


def build_package(output_dir: Path, package_name: str) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d")
    archive_path = output_dir / f"{package_name}-{stamp}.zip"
    package_root = archive_path.stem

    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in iter_package_files():
            relative = path.relative_to(PROJECT_ROOT)
            archive.write(path, Path(package_root) / relative)

    return archive_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Create the EasyGraph Windows source package.")
    parser.add_argument(
        "--output-dir",
        default=PROJECT_ROOT / "dist",
        type=Path,
        help="Directory where the zip archive will be written.",
    )
    parser.add_argument(
        "--name",
        default=DEFAULT_PACKAGE_NAME,
        help="Base package name. The current UTC date and .zip suffix are added automatically.",
    )
    args = parser.parse_args()

    archive_path = build_package(args.output_dir, args.name)
    print(archive_path.relative_to(PROJECT_ROOT))


if __name__ == "__main__":
    main()
