#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

./.venv/bin/pyside6-lrelease \
  translations/easygraph_zh_CN.ts \
  -qm translations/easygraph_zh_CN.qm
