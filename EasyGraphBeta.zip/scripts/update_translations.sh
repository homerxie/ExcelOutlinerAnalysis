#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

./.venv/bin/pyside6-lupdate \
  src/app.py \
  ui/main_window.ui \
  ui/group_order_dialog.ui \
  -source-language en_US \
  -target-language zh_CN \
  -ts translations/easygraph_zh_CN.ts
