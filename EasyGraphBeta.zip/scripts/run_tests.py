#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "easygraph_matplotlib")
)
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from tests.test_support import configure_warning_filters


def slowest_tests(
    durations: list[tuple[str, float]], limit: int = 10
) -> list[tuple[str, float]]:
    return sorted(durations, key=lambda item: item[1], reverse=True)[:limit]


def non_negative_int(value: str) -> int:
    number = int(value)
    if number < 0:
        raise argparse.ArgumentTypeError("value must be a non-negative integer")
    return number


class TimingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.durations: list[tuple[str, float]] = []
        self._started_at = 0.0

    def startTest(self, test) -> None:
        self._started_at = time.perf_counter()
        super().startTest(test)

    def stopTest(self, test) -> None:
        self.durations.append((test.id(), time.perf_counter() - self._started_at))
        super().stopTest(test)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run EasyGraph tests with concise timing output."
    )
    parser.add_argument("tests", nargs="*", help="Optional dotted test names")
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument(
        "--slow",
        type=non_negative_int,
        default=10,
        help="Number of slow tests to report",
    )
    return parser.parse_args()


def run_suite(
    suite, *, verbose: bool, slow_limit: int, stream=None
) -> unittest.TestResult:
    stream = sys.stdout if stream is None else stream
    runner = unittest.TextTestRunner(
        stream=stream,
        verbosity=2 if verbose else 1,
        resultclass=TimingResult,
    )
    result = runner.run(suite)
    stream.write("\nSlowest tests:\n")
    for name, duration in slowest_tests(result.durations, slow_limit):
        stream.write(f"{duration:8.3f}s  {name}\n")
    stream.flush()
    return result


def main() -> int:
    args = parse_args()
    configure_warning_filters()
    loader = unittest.defaultTestLoader
    suite = (
        loader.loadTestsFromNames(args.tests)
        if args.tests
        else loader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    )
    result = run_suite(suite, verbose=args.verbose, slow_limit=args.slow)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
