from __future__ import annotations

import json
import re
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path

from PySide6.QtGui import QColor

from easygraph.project_io import chart_settings_from_dict
from easygraph.settings import (
    ChartSettings,
    GROUP_COLOR_TEMPLATE_KEY_PREFIX,
    STYLE_TEMPLATE_CONTENT_FIELDS,
)

TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "template"
TEMPLATE_NONE_NAME = "None"

__all__ = [
    "TEMPLATE_DIR",
    "TEMPLATE_NONE_NAME",
    "apply_style_template_settings",
    "group_colors_for_target_groups",
    "import_style_template",
    "indexed_group_colors_from_settings",
    "list_style_templates",
    "read_style_template",
    "read_style_template_file",
    "style_template_settings_data",
    "template_file_name",
    "template_indexed_group_colors",
    "write_style_template",
]


def style_template_settings_data(settings: ChartSettings) -> dict:
    data = asdict(settings)
    defaults = asdict(ChartSettings())
    for key in STYLE_TEMPLATE_CONTENT_FIELDS:
        data[key] = deepcopy(defaults[key])
    data["custom_colors"] = indexed_group_colors_from_settings(settings)
    return data


def indexed_group_colors_from_settings(settings: ChartSettings) -> dict[str, str]:
    groups = [str(group) for group in settings.manual_group_order]
    indexed: dict[str, str] = {}
    for index, group in enumerate(groups):
        color = settings.custom_colors.get(group)
        if color is not None and QColor(color).isValid():
            indexed[f"{GROUP_COLOR_TEMPLATE_KEY_PREFIX}{index}"] = QColor(color).name()
    for key, color in settings.custom_colors.items():
        key_text = str(key)
        if key_text.startswith(GROUP_COLOR_TEMPLATE_KEY_PREFIX) and key_text.split(":", 1)[1].isdigit() and QColor(color).isValid():
            indexed[key_text] = QColor(color).name()
    return indexed


def template_indexed_group_colors(custom_colors: dict) -> dict[str, str]:
    return {
        str(key): QColor(color).name()
        for key, color in custom_colors.items()
        if str(key).startswith(GROUP_COLOR_TEMPLATE_KEY_PREFIX)
        and str(key).split(":", 1)[1].isdigit()
        and QColor(color).isValid()
    }


def group_colors_for_target_groups(custom_colors: dict, groups: list[str]) -> dict[str, str]:
    colors = template_indexed_group_colors(custom_colors)
    mapped: dict[str, str] = {}
    for key, color in colors.items():
        index = int(str(key).split(":", 1)[1])
        if 0 <= index < len(groups):
            mapped[str(groups[index])] = color
    return mapped


def apply_style_template_settings(current: ChartSettings, template: ChartSettings, groups: list[str] | None = None) -> ChartSettings:
    data = asdict(template)
    for key in STYLE_TEMPLATE_CONTENT_FIELDS:
        data[key] = deepcopy(getattr(current, key))
    target_groups = [str(group) for group in (groups if groups is not None else current.manual_group_order)]
    data["custom_colors"] = group_colors_for_target_groups(template.custom_colors, target_groups)
    data["custom_overlay_count"] = max(1, len(data["custom_overlay_series"]))
    return ChartSettings(**data)


def template_file_name(name: str) -> str:
    if name.strip().casefold() == TEMPLATE_NONE_NAME.casefold():
        raise ValueError("Template name is reserved.")
    stem = re.sub(r"[^\w .()-]+", "_", name.strip(), flags=re.UNICODE)
    stem = re.sub(r"\s+", " ", stem).strip(" .")
    if not stem:
        raise ValueError("Template name cannot be empty.")
    return f"{stem}.json"


def write_style_template(name: str, settings: ChartSettings, template_dir: Path = TEMPLATE_DIR) -> Path:
    template_dir.mkdir(parents=True, exist_ok=True)
    path = template_dir / template_file_name(name)
    path.write_text(json.dumps(style_template_settings_data(settings), ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def read_style_template(name: str, template_dir: Path = TEMPLATE_DIR) -> ChartSettings:
    path = template_dir / template_file_name(name)
    return read_style_template_file(path)


def read_style_template_file(path: Path) -> ChartSettings:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Style template must be a JSON object.")
    data = dict(data)
    defaults = asdict(ChartSettings())
    for key in STYLE_TEMPLATE_CONTENT_FIELDS:
        data[key] = deepcopy(defaults[key])
    data["custom_colors"] = template_indexed_group_colors(data.get("custom_colors", {}))
    return chart_settings_from_dict(data)


def import_style_template(path: Path, template_dir: Path = TEMPLATE_DIR) -> tuple[str, ChartSettings]:
    settings = read_style_template_file(path)
    imported_path = write_style_template(path.stem, settings, template_dir)
    return imported_path.stem, settings


def list_style_templates(template_dir: Path = TEMPLATE_DIR) -> list[str]:
    if not template_dir.exists():
        return []
    return sorted(
        path.stem
        for path in template_dir.glob("*.json")
        if path.is_file() and path.stem.casefold() != TEMPLATE_NONE_NAME.casefold()
    )
