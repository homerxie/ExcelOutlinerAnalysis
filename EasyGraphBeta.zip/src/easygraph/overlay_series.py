from __future__ import annotations

import numpy as np
import pandas as pd
from PySide6.QtGui import QColor

from easygraph.palette import (
    expanded_preset_palette,
    first_unused_palette_color,
    normalize_color_name,
)
from easygraph.settings import (
    ChartSettings,
    DEFAULT_OVERLAY_PALETTE,
    LINE_OVERLAY_RENDER_STYLES,
    LINE_OVERLAY_STYLES,
    PRESETS,
)


__all__ = [
    "line_overlay_series",
    "visible_custom_overlay_indexes",
    "all_custom_overlay_indexes",
    "overlay_palette_for",
    "stat_overlay_color",
    "default_overlay_color",
    "overlay_color_map_for_series",
    "overlay_color_map_for_keys",
    "all_overlay_color_keys",
    "overlay_palette_slot_for_color_key",
    "overlay_color_items",
    "overlay_style_items",
    "overlay_stat_color_key",
    "overlay_custom_color_key",
    "group_overlay_statistics",
    "stat_table_header_required",
    "stat_table_header_enabled",
    "stat_table_data",
    "format_overlay_value",
    "custom_overlay_style_for_key",
    "auto_overlay_style",
    "overlay_style_for_series",
]


def line_overlay_series(df: pd.DataFrame, settings: ChartSettings, include_hidden: bool = False) -> list[dict]:
    series = []
    stat_values = group_overlay_statistics(df, settings)
    if stat_values:
        series.append({
            "name": settings.line_overlay_stat,
            "kind": "stat",
            "color_key": overlay_stat_color_key(settings.line_overlay_stat),
            "groups": [group for group, _value in stat_values],
            "values": [value for _group, value in stat_values],
        })
    if settings.extra_custom_overlay and settings.custom_overlay_series and not df.empty:
        groups = [str(group) for group in df[settings.group_col].dropna().drop_duplicates()]
        overlay_indexes = all_custom_overlay_indexes(settings) if include_hidden else visible_custom_overlay_indexes(settings)
        for index in overlay_indexes:
            custom_series = settings.custom_overlay_series[index]
            if not isinstance(custom_series, dict):
                continue
            raw_values = custom_series.get("values", {})
            if not isinstance(raw_values, dict):
                continue
            values = []
            has_value = False
            for group in groups:
                value = pd.to_numeric(raw_values.get(str(group), ""), errors="coerce")
                if pd.isna(value):
                    values.append(float("nan"))
                else:
                    has_value = True
                    values.append(float(value))
            if has_value:
                name = str(custom_series.get("name", "")).strip() or f"Overlay {index + 1}"
                series.append({
                    "name": name,
                    "kind": "custom",
                    "secondary_axis": bool(settings.custom_overlay_secondary_axis),
                    "color_key": overlay_custom_color_key(index),
                    "groups": groups,
                    "values": values,
                })
    return series


def visible_custom_overlay_indexes(settings: ChartSettings) -> list[int]:
    if not settings.extra_custom_overlay:
        return []
    hidden = {
        int(index)
        for index in settings.custom_overlay_hidden
        if isinstance(index, int) or str(index).lstrip("-").isdigit()
    }
    return [
        index
        for index, series in enumerate(settings.custom_overlay_series or [])
        if index not in hidden and isinstance(series, dict)
    ]


def all_custom_overlay_indexes(settings: ChartSettings) -> list[int]:
    if not settings.extra_custom_overlay:
        return []
    return [
        index
        for index, series in enumerate(settings.custom_overlay_series or [])
        if isinstance(series, dict)
    ]


def overlay_palette_for(df: pd.DataFrame, settings: ChartSettings, count: int) -> list[str]:
    series = line_overlay_series(df, settings)
    color_map = overlay_color_map_for_series(line_overlay_series(df, settings, include_hidden=True), settings)
    colors = [
        stat_overlay_color(settings) if item.get("kind") == "stat" else color_map.get(str(item.get("color_key", "")), "#000000")
        for item in series[:count]
    ]
    return colors or expanded_preset_palette(DEFAULT_OVERLAY_PALETTE, max(count, 1))


def stat_overlay_color(settings: ChartSettings) -> str:
    background = PRESETS.get(settings.preset, PRESETS["Paper Clean"])["background"]
    return "#F9FAFB" if background != "#FFFFFF" else "#222222"


def default_overlay_color(settings: ChartSettings, series: dict, group_count: int, overlay_index: int) -> str:
    overlay_preset = settings.custom_overlay_palette if settings.custom_overlay_palette in PRESETS else DEFAULT_OVERLAY_PALETTE
    palette_slot = overlay_palette_slot_for_color_key(settings, str(series.get("color_key", "")), overlay_index)
    overlay_palette = expanded_preset_palette(overlay_preset, palette_slot + 1)
    return overlay_palette[palette_slot % len(overlay_palette)]


def overlay_color_map_for_series(
    series_list: list[dict],
    settings: ChartSettings,
    custom_overlay_colors: dict[str, str] | None = None,
    overlay_preset: str | None = None,
) -> dict[str, str]:
    return overlay_color_map_for_keys(
        [str(series.get("color_key", "")) for series in series_list],
        settings,
        custom_overlay_colors=custom_overlay_colors,
        overlay_preset=overlay_preset,
    )


def overlay_color_map_for_keys(
    color_keys: list[str],
    settings: ChartSettings,
    custom_overlay_colors: dict[str, str] | None = None,
    overlay_preset: str | None = None,
) -> dict[str, str]:
    custom_overlay_colors = settings.custom_overlay_colors if custom_overlay_colors is None else custom_overlay_colors
    overlay_preset = settings.custom_overlay_palette if overlay_preset is None else overlay_preset
    overlay_preset = overlay_preset if overlay_preset in PRESETS else DEFAULT_OVERLAY_PALETTE
    color_keys = [str(key) for key in color_keys if str(key) and not str(key).startswith("stat:")]
    palette = expanded_preset_palette(overlay_preset, len(color_keys) + len(custom_overlay_colors) + 4)
    series_keys = set(color_keys)
    used_colors = {
        normalize_color_name(color)
        for key, color in custom_overlay_colors.items()
        if str(key) in series_keys and QColor(color).isValid()
    }
    color_map = {}
    for key in color_keys:
        custom_color = custom_overlay_colors.get(key)
        if custom_color is not None and QColor(custom_color).isValid():
            color_map[key] = QColor(custom_color).name()
            continue
        color = first_unused_palette_color(palette, used_colors)
        color_map[key] = color
        used_colors.add(normalize_color_name(color))
    return color_map


def all_overlay_color_keys(settings: ChartSettings) -> list[str]:
    keys = []
    if settings.extra_custom_overlay:
        keys.extend(overlay_custom_color_key(index) for index in all_custom_overlay_indexes(settings))
    return keys


def overlay_palette_slot_for_color_key(settings: ChartSettings, color_key: str, fallback_index: int) -> int:
    if color_key.startswith("custom:"):
        try:
            custom_index = int(color_key.split(":", 1)[1])
        except ValueError:
            return fallback_index
        return max(0, custom_index)
    return max(0, fallback_index)


def overlay_color_items(df: pd.DataFrame, settings: ChartSettings) -> list[tuple[str, str]]:
    items = []
    if settings.extra_custom_overlay:
        series = settings.custom_overlay_series or []
        for index in visible_custom_overlay_indexes(settings):
            name = f"Overlay {index + 1}"
            if index < len(series) and isinstance(series[index], dict):
                name = str(series[index].get("name", "")).strip() or name
            items.append((overlay_custom_color_key(index), name))
    return items


def overlay_style_items(df: pd.DataFrame, settings: ChartSettings) -> list[tuple[str, str]]:
    return overlay_color_items(df, settings)


def overlay_stat_color_key(stat: str) -> str:
    return f"stat:{stat}"


def overlay_custom_color_key(index: int) -> str:
    return f"custom:{index}"


def group_overlay_statistics(df: pd.DataFrame, settings: ChartSettings) -> list[tuple[str, float]]:
    if df.empty:
        return []
    if settings.line_overlay_stat == "None":
        return []
    use_mean = settings.line_overlay_stat == "Mean"
    stats = []
    for group in df[settings.group_col].dropna().drop_duplicates():
        values = pd.to_numeric(df.loc[df[settings.group_col] == group, settings.value_col], errors="coerce").dropna()
        if values.empty:
            continue
        value = values.mean() if use_mean else values.median()
        stats.append((str(group), float(value)))
    return stats


def stat_table_header_required(settings: ChartSettings) -> bool:
    return settings.chart_type == "Ridge" and settings.show_stat_table


def stat_table_header_enabled(settings: ChartSettings) -> bool:
    return settings.show_stat_header or stat_table_header_required(settings)


def stat_table_data(df: pd.DataFrame, settings: ChartSettings) -> tuple[list[str], list[tuple[str, list[str]]]]:
    if df.empty or not settings.show_stat_table:
        return ([], [])

    groups = [str(group) for group in df[settings.group_col].dropna().drop_duplicates()]
    if not groups:
        return ([], [])

    group_values = []
    for group in groups:
        values = pd.to_numeric(df.loc[df[settings.group_col].astype(str) == group, settings.value_col], errors="coerce").dropna()
        group_values.append(values)

    def formatted(values: pd.Series, calculation) -> str:
        if values.empty:
            return ""
        value = calculation(values)
        if pd.isna(value):
            return ""
        return format_overlay_value(float(value), settings)

    def sample_sd(values: pd.Series) -> float:
        return values.std(ddof=1) if len(values) > 1 else np.nan

    def sample_sem(values: pd.Series) -> float:
        if len(values) <= 1:
            return np.nan
        return values.std(ddof=1) / np.sqrt(len(values))

    row_specs = [
        ("Mean", settings.show_stat_mean, lambda values: values.mean()),
        ("Median", settings.show_stat_median, lambda values: values.median()),
        ("Q1", settings.show_stat_q1, lambda values: values.quantile(0.25)),
        ("Q3", settings.show_stat_q3, lambda values: values.quantile(0.75)),
        ("Max", settings.show_stat_max, lambda values: values.max()),
        ("Min", settings.show_stat_min, lambda values: values.min()),
        ("SD", settings.show_stat_sd, sample_sd),
        ("SEM", settings.show_stat_sem, sample_sem),
    ]

    rows = [
        (label, [formatted(values, calculation) for values in group_values])
        for label, enabled, calculation in row_specs
        if enabled
    ]
    if settings.show_stat_sample_size:
        rows.append(("Sample", [str(len(values)) for values in group_values]))
    return (groups, rows)


def format_overlay_value(value: float, settings: ChartSettings) -> str:
    decimals = max(0, min(int(settings.line_value_decimals), 12))
    format_type = "e" if settings.line_value_scientific else "f"
    return f"{value:.{decimals}{format_type}}"


def custom_overlay_style_for_key(settings: ChartSettings, key: str) -> str:
    style = settings.custom_overlay_styles.get(str(key), settings.line_overlay_style)
    return style if style in LINE_OVERLAY_STYLES else settings.line_overlay_style


def auto_overlay_style(series_index: int) -> str:
    return LINE_OVERLAY_RENDER_STYLES[series_index % len(LINE_OVERLAY_RENDER_STYLES)]


def overlay_style_for_series(settings: ChartSettings, series: dict, series_index: int = 0) -> str:
    if series.get("kind") == "custom":
        style = custom_overlay_style_for_key(settings, str(series.get("color_key", "")))
    else:
        style = settings.line_overlay_style
    return auto_overlay_style(series_index) if style == "Auto" else style
