from __future__ import annotations

from pathlib import Path

import pandas as pd


OVERLAY_EXPORT_ROW_TYPE_COLUMN = "__easygraph_row_type"
OVERLAY_EXPORT_NAME_COLUMN = "__easygraph_overlay_name"
OVERLAY_EXPORT_SAMPLE_ROW = "sample"
OVERLAY_EXPORT_CUSTOM_ROW = "overlay"


def excel_export_dataframe(df: pd.DataFrame, overlay_series: list[dict] | None = None) -> pd.DataFrame:
    overlay_series = list(overlay_series or [])
    if not overlay_series:
        return df.copy()

    group_columns = list(df.columns)
    rows = []
    for series in overlay_series:
        values = series.get("values", {}) if isinstance(series, dict) else {}
        name = str(series.get("name", "")) if isinstance(series, dict) else ""
        rows.append(
            [
                OVERLAY_EXPORT_CUSTOM_ROW,
                name,
                *[
                    "" if pd.isna(values.get(str(column), "")) else values.get(str(column), "")
                    for column in group_columns
                ],
            ]
        )
    for row_index in range(len(df)):
        rows.append(
            [
                OVERLAY_EXPORT_SAMPLE_ROW,
                "",
                *[df.iloc[row_index, col_index] for col_index in range(len(group_columns))],
            ]
        )
    return pd.DataFrame(rows, columns=[OVERLAY_EXPORT_ROW_TYPE_COLUMN, OVERLAY_EXPORT_NAME_COLUMN, *group_columns])


def excel_import_parts(df: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    columns = list(df.columns)
    if OVERLAY_EXPORT_ROW_TYPE_COLUMN not in columns or OVERLAY_EXPORT_NAME_COLUMN not in columns:
        return df, []

    row_type_index = columns.index(OVERLAY_EXPORT_ROW_TYPE_COLUMN)
    name_index = columns.index(OVERLAY_EXPORT_NAME_COLUMN)
    group_indexes = [
        index
        for index, column in enumerate(columns)
        if index not in {row_type_index, name_index}
    ]
    group_columns = [columns[index] for index in group_indexes]
    sample_rows = []
    overlay_series = []

    for _, row in df.iterrows():
        row_type = "" if pd.isna(row.iloc[row_type_index]) else str(row.iloc[row_type_index]).strip().casefold()
        if row_type == OVERLAY_EXPORT_CUSTOM_ROW:
            name = "" if pd.isna(row.iloc[name_index]) else str(row.iloc[name_index])
            values = {}
            for group, index in zip(group_columns, group_indexes):
                value = row.iloc[index]
                values[str(group)] = "" if pd.isna(value) else str(value)
            overlay_series.append({"name": name, "values": values})
        elif row_type in {"", OVERLAY_EXPORT_SAMPLE_ROW}:
            sample_rows.append([row.iloc[index] for index in group_indexes])

    return pd.DataFrame(sample_rows, columns=group_columns), overlay_series


def read_spreadsheet(path: Path) -> tuple[pd.DataFrame, list[dict]]:
    input_path = Path(path)
    raw_df = pd.read_csv(input_path) if input_path.suffix.casefold() == ".csv" else pd.read_excel(input_path)
    return excel_import_parts(raw_df)


def write_spreadsheet(
    path: Path,
    df: pd.DataFrame,
    overlay_series: list[dict] | None = None,
) -> Path:
    output_path = Path(path)
    exported = excel_export_dataframe(df, overlay_series)
    if output_path.suffix.casefold() == ".csv":
        exported.to_csv(output_path, index=False)
    else:
        if output_path.suffix.casefold() != ".xlsx":
            output_path = Path(f"{output_path}.xlsx")
        exported.to_excel(output_path, index=False)
    return output_path


__all__ = [
    "OVERLAY_EXPORT_CUSTOM_ROW",
    "OVERLAY_EXPORT_NAME_COLUMN",
    "OVERLAY_EXPORT_ROW_TYPE_COLUMN",
    "OVERLAY_EXPORT_SAMPLE_ROW",
    "excel_export_dataframe",
    "excel_import_parts",
    "read_spreadsheet",
    "write_spreadsheet",
]
