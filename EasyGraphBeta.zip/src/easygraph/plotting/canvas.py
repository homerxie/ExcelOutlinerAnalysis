from __future__ import annotations

import math
import os
import re
import tempfile
import unicodedata
from dataclasses import asdict
from io import BytesIO
from pathlib import Path

os.environ.setdefault(
    "MPLCONFIGDIR",
    str(Path(tempfile.gettempdir()) / "easygraph_matplotlib"),
)
Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.collections import PathCollection
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle
from matplotlib.ticker import AutoLocator, MultipleLocator
from matplotlib.transforms import Bbox
from scipy.stats import gaussian_kde

from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QColor, QIcon, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import QApplication, QHBoxLayout, QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget

from easygraph.settings import ChartSettings, LEGEND_INSIDE_AUTO_POSITION, LEGEND_POSITION_INSIDE, PRESETS
from easygraph.data import axis_labels_for_chart, box_whis, mark_outliers, prepare_plot_data
from easygraph.palette import _relative_luminance, derived_group_color, palette_for
from easygraph.overlay_series import (
    format_overlay_value,
    line_overlay_series,
    overlay_palette_for,
    overlay_style_for_series,
    stat_table_data,
    stat_table_header_enabled,
    visible_custom_overlay_indexes,
)


__all__ = [
    'AUTO_AXIS_RANGE_PADDING_FRACTION',
    'CoordinatesToolbar',
    'LEGEND_COLUMN_SPACING',
    'LEGEND_HANDLE_LENGTH',
    'LEGEND_HANDLE_SPACE_UNITS',
    'LEGEND_MAX_COLUMNS',
    'LEGEND_SECONDARY_AXIS_GAP_PX',
    'LINE_OVERLAY_STYLE_TO_MPL',
    'LINE_OVERLAY_STYLE_TO_QT',
    'LINE_STYLE_ICON_DEVICE_RATIOS',
    'LINE_STYLE_ICON_SIZE',
    'LINE_STYLE_POPUP_PREVIEW_WIDTH',
    'LINE_STYLE_POPUP_ROW_HEIGHT',
    'LINE_STYLE_PREVIEW_DOT_RADIUS',
    'LINE_STYLE_PREVIEW_STROKE_WIDTH',
    'MAX_MANUAL_TICK_COUNT',
    'OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS',
    'OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO',
    'OVERLAY_CONTENT_MARGIN_RATIO',
    'PlotCanvas',
    'STAT_OVERLAY_ALPHA',
    'ScrollFriendlyFigureCanvas',
    'draw_line_style_preview',
    'line_style_icon',
    'normalize_overlay_label_position',
    'overlay_auto_avoidance_position',
    'overlay_label_arrow',
    'overlay_label_bbox',
    'overlay_label_offset',
    'overlay_label_position_for_series',
    'overlay_line_qt_pen_style',
    'overlay_line_style',
    'overlay_values_are_close',
    'resolve_overlay_label_position',
]


OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS = 3


OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO = 0.5


OVERLAY_CONTENT_MARGIN_RATIO = 0.10


AUTO_AXIS_RANGE_PADDING_FRACTION = 0.10


LEGEND_MAX_COLUMNS = 6


LEGEND_COLUMN_SPACING = 1.0


LEGEND_HANDLE_LENGTH = 3.0


LEGEND_HANDLE_SPACE_UNITS = 3.8


LEGEND_SECONDARY_AXIS_GAP_PX = 8.0


MAX_MANUAL_TICK_COUNT = 1000


class ScrollFriendlyFigureCanvas(FigureCanvasQTAgg):
    def __init__(self, figure, owner=None) -> None:
        self.owner = owner
        super().__init__(figure)

    def wheelEvent(self, event) -> None:
        if event.modifiers() & Qt.ControlModifier and self.owner is not None:
            delta = event.angleDelta().y()
            if delta:
                self.owner.zoom_by(1.12 if delta > 0 else 1 / 1.12)
                event.accept()
                return
        event.ignore()


STAT_OVERLAY_ALPHA = 0.78


LINE_OVERLAY_STYLE_TO_MPL = {
    "Solid": "-",
    "Dashed": "--",
    "Dotted": ":",
    "Dash-dot": "-.",
    "Long dash": (0, (10, 3)),
    "Dense dash": (0, (4, 1.5)),
    "Loose dot": (0, (1, 5)),
    "Dash-dot-dot": (0, (7, 2, 1, 2, 1, 2)),
}


LINE_OVERLAY_STYLE_TO_QT = {
    "Solid": Qt.PenStyle.SolidLine,
    "Dashed": Qt.PenStyle.DashLine,
    "Dotted": Qt.PenStyle.DotLine,
    "Dash-dot": Qt.PenStyle.DashDotLine,
    "Long dash": Qt.PenStyle.DashLine,
    "Dense dash": Qt.PenStyle.DashLine,
    "Loose dot": Qt.PenStyle.DotLine,
    "Dash-dot-dot": Qt.PenStyle.DashDotDotLine,
}


LINE_STYLE_ICON_SIZE = QSize(96, 22)


LINE_STYLE_ICON_DEVICE_RATIOS = (1, 2, 3)


LINE_STYLE_POPUP_PREVIEW_WIDTH = 120


LINE_STYLE_POPUP_ROW_HEIGHT = 34


LINE_STYLE_PREVIEW_STROKE_WIDTH = 3.4


LINE_STYLE_PREVIEW_DOT_RADIUS = 2.0


class CoordinatesToolbar(NavigationToolbar2QT):
    toolitems: tuple = ()

    def __init__(self, canvas, parent=None) -> None:
        super().__init__(canvas, parent, coordinates=True)
        self.setObjectName("plotCoordinatesToolbar")
        self.setFloatable(False)
        self.setMovable(False)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setStyleSheet("QToolBar#plotCoordinatesToolbar { border: 0; background: transparent; padding: 0; }")
        self.locLabel.setObjectName("plotCoordinatesLabel")
        self.locLabel.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)


class PlotCanvas(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.preview_ppi = 140
        self.preview_zoom = 1.0
        self.figure = None
        self.canvas = None
        self.toolbar = None
        self.selection_callback = None
        self.legend_position_callback = None
        self._interaction_targets: list[dict] = []
        self._hover_feedback_patch = None
        self._selected_feedback_patch = None
        self._hover_object_kind: str | None = None
        self._selected_object_kind: str | None = None
        self._legend_drag_state: dict | None = None
        self._legend_plot_union_bbox = None
        self._legend_layout_token = 0
        self.zoom_bar = QWidget()
        self.zoom_layout = QHBoxLayout(self.zoom_bar)
        self.zoom_layout.setContentsMargins(6, 4, 6, 4)
        self.zoom_layout.addStretch()
        zoom_out = QPushButton("−")
        zoom_reset = QPushButton("100%")
        zoom_fit = QPushButton("Fit")
        zoom_in = QPushButton("+")
        zoom_fit.setObjectName("zoomToFitButton")
        zoom_out.clicked.connect(lambda: self.zoom_by(1 / 1.12))
        zoom_reset.clicked.connect(self.reset_zoom)
        zoom_fit.clicked.connect(self.zoom_to_fit)
        zoom_in.clicked.connect(lambda: self.zoom_by(1.12))
        self.zoom_layout.addWidget(zoom_out)
        self.zoom_layout.addWidget(zoom_reset)
        self.zoom_layout.addWidget(zoom_fit)
        self.zoom_layout.addWidget(zoom_in)
        self._canvas_size: tuple[int, int] | None = None
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignCenter)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setStyleSheet("QScrollArea { background: #2f2f2f; border: 0; }")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.addWidget(self.zoom_bar)
        self.layout.addWidget(self.scroll)
        self._replace_canvas(15 / 2.54, 10 / 2.54)

    def _replace_canvas(self, width_in: float, height_in: float) -> None:
        width_px = max(1, int(width_in * self.preview_ppi * self.preview_zoom))
        height_px = max(1, int(height_in * self.preview_ppi * self.preview_zoom))
        size = (width_px, height_px)
        if size == self._canvas_size and self.figure is not None and self.canvas is not None:
            return

        if self.toolbar is not None:
            self.zoom_layout.removeWidget(self.toolbar)
            self.toolbar.deleteLater()
            self.toolbar = None

        old_canvas = self.scroll.takeWidget()
        if old_canvas is not None:
            old_canvas.deleteLater()

        self.figure = Figure(figsize=(width_in, height_in), dpi=self.preview_ppi * self.preview_zoom)
        self.canvas = ScrollFriendlyFigureCanvas(self.figure, owner=self)
        self.canvas.setFixedSize(width_px, height_px)
        self.canvas.setAutoFillBackground(True)
        self.canvas.setFocusPolicy(Qt.NoFocus)
        self.canvas.mpl_connect("motion_notify_event", self._handle_plot_motion)
        self.canvas.mpl_connect("figure_leave_event", self._handle_plot_leave)
        self.canvas.mpl_connect("button_press_event", self._handle_plot_click)
        self.canvas.mpl_connect("button_release_event", self._handle_plot_release)
        self.toolbar = CoordinatesToolbar(self.canvas, self.zoom_bar)
        self.zoom_layout.insertWidget(0, self.toolbar, 1)
        self.scroll.setWidget(self.canvas)
        self._canvas_size = size

    def zoom_by(self, factor: float) -> None:
        self.preview_zoom = min(4.0, max(0.25, self.preview_zoom * factor))
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self.render(self._last_df, self._last_settings)

    def reset_zoom(self) -> None:
        self.preview_zoom = 1.0
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self.render(self._last_df, self._last_settings)

    def zoom_to_fit(self) -> None:
        if self.canvas is None:
            return
        base_width_px = self.canvas.width() / max(self.preview_zoom, 0.001)
        base_height_px = self.canvas.height() / max(self.preview_zoom, 0.001)
        if base_width_px <= 0 or base_height_px <= 0:
            return
        viewport_size = self.scroll.viewport().size()
        available_width = max(1, viewport_size.width() - 12)
        available_height = max(1, viewport_size.height() - 12)
        target_zoom = min(available_width / base_width_px, available_height / base_height_px)
        target_zoom = min(4.0, max(0.25, target_zoom))
        if math.isclose(target_zoom, self.preview_zoom, rel_tol=0.001, abs_tol=0.001):
            return
        self.preview_zoom = target_zoom
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self.render(self._last_df, self._last_settings)

    def render(self, df: pd.DataFrame, settings: ChartSettings) -> None:
        self._last_df = df.copy()
        self._last_settings = ChartSettings(**asdict(settings))
        self._auto_tick_interval_fallbacks: set[str] = set()
        self._clear_plot_feedback(clear_selection=False)
        self._interaction_targets = []
        plot_width_in = settings.width / 2.54
        plot_height_in = settings.height / 2.54

        full_clean = prepare_plot_data(df, settings, include_hidden=True)
        clean = prepare_plot_data(df, settings)
        preset = PRESETS[settings.preset]
        all_groups = [str(group) for group in full_clean[settings.group_col].dropna().drop_duplicates()] if not full_clean.empty else []
        palette = palette_for(clean, settings, color_groups=all_groups)
        text_color = "#F9FAFB" if preset["background"] != "#FFFFFF" else "#222222"

        if clean.empty:
            self._replace_canvas(plot_width_in, plot_height_in)
            self.figure.clf()
            self.figure.patch.set_facecolor(preset["background"])
            ax = self.figure.add_axes([0.0, 0.0, 1.0, 1.0])
            ax.set_facecolor(preset["background"])
            ax.text(0.5, 0.5, "No numeric data", ha="center", va="center", fontsize=settings.axis_label_font_size)
            self.canvas.draw()
            self.canvas.repaint()
            self.scroll.viewport().repaint()
            return

        out = mark_outliers(clean, settings)
        distribution = clean.drop(index=out.index) if settings.outlier_effect == "Exclude from distribution" else clean
        if distribution.empty:
            distribution = clean
        stat_groups, stat_rows = stat_table_data(distribution, settings)
        x_axis_label, y_axis_label = axis_labels_for_chart(settings)

        plot_groups = [str(group) for group in distribution[settings.group_col].dropna().drop_duplicates()]
        custom_overlay_secondary_axis_active = self._custom_overlay_secondary_axis_active(settings)
        split_secondary_frame = self._split_secondary_frame_enabled(settings)
        left_margin_in = self._plot_left_margin_inches(settings, plot_groups, y_axis_label, stat_rows)
        right_margin_in = self._plot_right_margin_inches(settings)
        table_height_in = self._stat_table_height_inches(stat_groups, stat_rows, settings) if stat_rows else 0.0
        gap_in = self._stat_table_gap_inches(settings, stat_groups, x_axis_label) if stat_rows else 0.0
        bottom_in = 0.14 if stat_rows else self._plot_bottom_margin_inches(settings, stat_groups, x_axis_label)
        top_in = self._plot_top_margin_inches(settings)
        if settings.chart_type in {"Box", "Violin"}:
            primary_height_in = plot_height_in
            primary_center_in = bottom_in + table_height_in + gap_in + plot_height_in / 2.0
            if split_secondary_frame:
                secondary_height_in = plot_height_in * self._secondary_axis_split_ratio(settings)
                primary_height_in = plot_height_in - secondary_height_in
                primary_center_in = bottom_in + table_height_in + gap_in + primary_height_in / 2.0
            extra_bottom, extra_top = self._rotated_value_axis_label_height_overflow_inches(
                y_axis_label,
                settings,
                bottom_in + table_height_in + gap_in + plot_height_in + top_in,
                primary_center_in,
            )
            bottom_in += extra_bottom
            top_in += extra_top
            if custom_overlay_secondary_axis_active:
                secondary_center_in = bottom_in + table_height_in + gap_in + plot_height_in / 2.0
                if split_secondary_frame:
                    secondary_center_in = bottom_in + table_height_in + gap_in + primary_height_in + secondary_height_in / 2.0
                extra_bottom, extra_top = self._rotated_value_axis_label_height_overflow_inches(
                    settings.secondary_y_label,
                    settings,
                    bottom_in + table_height_in + gap_in + plot_height_in + top_in,
                    secondary_center_in,
                )
                bottom_in += extra_bottom
                top_in += extra_top
        if settings.chart_type == "Ridge":
            primary_width_in = plot_width_in
            primary_center_in = left_margin_in + plot_width_in / 2.0
            if split_secondary_frame:
                secondary_width_in = plot_width_in * self._secondary_axis_split_ratio(settings)
                primary_width_in = plot_width_in - secondary_width_in
                primary_center_in = left_margin_in + primary_width_in / 2.0
            extra_left, extra_right = self._horizontal_axis_label_width_overflow_inches(
                x_axis_label,
                settings,
                left_margin_in + plot_width_in + right_margin_in,
                primary_center_in,
            )
            left_margin_in += extra_left
            right_margin_in += extra_right
            if custom_overlay_secondary_axis_active:
                secondary_center_in = left_margin_in + plot_width_in / 2.0
                if split_secondary_frame:
                    secondary_center_in = left_margin_in + primary_width_in + secondary_width_in / 2.0
                extra_left, extra_right = self._horizontal_axis_label_width_overflow_inches(
                    settings.secondary_y_label,
                    settings,
                    left_margin_in + plot_width_in + right_margin_in,
                    secondary_center_in,
                )
                left_margin_in += extra_left
                right_margin_in += extra_right
        total_width_in = left_margin_in + plot_width_in + right_margin_in
        total_height_in = plot_height_in + table_height_in + gap_in + bottom_in + top_in

        self._replace_canvas(total_width_in, total_height_in)
        self.figure.clf()
        self.figure.patch.set_facecolor(preset["background"])

        table_ax = None
        secondary_ax = None
        plot_left = left_margin_in / total_width_in
        plot_width = plot_width_in / total_width_in
        plot_bottom = (bottom_in + table_height_in + gap_in) / total_height_in
        plot_height = plot_height_in / total_height_in
        if stat_rows:
            table_bottom = bottom_in / total_height_in
            table_height = table_height_in / total_height_in
            if split_secondary_frame:
                if settings.chart_type == "Ridge":
                    secondary_width = plot_width * self._secondary_axis_split_ratio(settings)
                    primary_width = plot_width - secondary_width
                    ax = self.figure.add_axes([plot_left, plot_bottom, primary_width, plot_height])
                    secondary_ax = self.figure.add_axes([plot_left + primary_width, plot_bottom, secondary_width, plot_height])
                else:
                    secondary_height = plot_height * self._secondary_axis_split_ratio(settings)
                    primary_height = plot_height - secondary_height
                    ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, primary_height])
                    secondary_ax = self.figure.add_axes([plot_left, plot_bottom + primary_height, plot_width, secondary_height])
            else:
                ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, plot_height])
            table_ax = self.figure.add_axes([plot_left, table_bottom, plot_width, table_height])
            table_ax.set_facecolor("none")
        else:
            if split_secondary_frame:
                if settings.chart_type == "Ridge":
                    secondary_width = plot_width * self._secondary_axis_split_ratio(settings)
                    primary_width = plot_width - secondary_width
                    ax = self.figure.add_axes([plot_left, plot_bottom, primary_width, plot_height])
                    secondary_ax = self.figure.add_axes([plot_left + primary_width, plot_bottom, secondary_width, plot_height])
                else:
                    secondary_height = plot_height * self._secondary_axis_split_ratio(settings)
                    primary_height = plot_height - secondary_height
                    ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, primary_height])
                    secondary_ax = self.figure.add_axes([plot_left, plot_bottom + primary_height, plot_width, secondary_height])
            else:
                ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, plot_height])
        ax.set_facecolor(preset["background"])
        if secondary_ax is not None:
            secondary_ax.set_gid("secondary-axis")
            secondary_ax.set_facecolor(preset["background"])
            if split_secondary_frame:
                # The legend belongs to the primary axis and may span both split
                # frames. Draw that axis last so the secondary frame cannot cover it.
                ax.set_zorder(secondary_ax.get_zorder() + 1)
        elif custom_overlay_secondary_axis_active:
            secondary_ax = ax.twiny() if settings.chart_type == "Ridge" else ax.twinx()
            secondary_ax.set_gid("secondary-axis")
            secondary_ax.set_facecolor("none")

        if settings.chart_type == "Box":
            self._draw_box(ax, distribution, settings, palette)
        elif settings.chart_type == "Violin":
            self._draw_violin(ax, distribution, settings, palette)
        else:
            self._draw_ridge(ax, distribution, clean, settings, palette, text_color)
        if settings.chart_type != "Ridge":
            ax.set_xlim(-0.5, len(stat_groups or palette_for(distribution, settings)) - 0.5)
            if split_secondary_frame and secondary_ax is not None:
                secondary_ax.set_xlim(ax.get_xlim())

        point_positions = None
        if settings.chart_type != "Ridge":
            point_positions = self._point_positions(clean, settings)
            if settings.show_points:
                self._draw_points(ax, clean, settings, palette, preset, point_positions)

        if settings.chart_type != "Ridge" and settings.show_outliers:
            if not out.empty and point_positions is not None:
                outlier_points = ax.scatter(
                    point_positions.loc[out.index],
                    out[settings.value_col],
                    s=max(settings.point_size * 18, 45),
                    facecolors="none",
                    edgecolors="#D62728",
                    linewidths=1.3,
                    zorder=6,
                    label="Outlier",
                )
                self._mark_point_artist(outlier_points)

        if settings.show_line_overlay or settings.extra_custom_overlay:
            self._draw_line_overlay(ax, distribution, settings, text_color, secondary_ax=secondary_ax)

        if settings.chart_type == "Ridge":
            self._apply_ridge_x_range(ax, settings)
        elif not settings.auto_y_range:
            ax.set_ylim(settings.y_min, settings.y_max)
        else:
            self._apply_auto_value_axis_padding(ax, settings)
        if secondary_ax is not None and not settings.secondary_auto_y_range:
            if settings.chart_type == "Ridge":
                secondary_ax.set_xlim(settings.secondary_y_min, settings.secondary_y_max)
            else:
                secondary_ax.set_ylim(settings.secondary_y_min, settings.secondary_y_max)
        elif secondary_ax is not None:
            self._apply_auto_value_axis_padding(secondary_ax, settings)

        ax.set_title("" if split_secondary_frame else settings.title, fontsize=settings.title_font_size, color=text_color)
        ax.set_xlabel(x_axis_label, fontsize=settings.axis_label_font_size, color=text_color)
        ax.set_ylabel(y_axis_label, fontsize=settings.axis_label_font_size, color=text_color)
        ax.tick_params(colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        x_tick_rotation = 0 if settings.chart_type == "Ridge" else settings.x_tick_rotation
        ax.tick_params(axis="x", labelrotation=x_tick_rotation)
        self._style_plot_frame(ax, settings, text_color)
        ax.grid(bool(settings.show_grid), color="#D1D5DB" if preset["background"] == "#FFFFFF" else "#374151", alpha=0.55)
        if secondary_ax is not None:
            if split_secondary_frame:
                self._style_split_secondary_axis(secondary_ax, ax, stat_groups, settings, text_color)
            else:
                self._style_secondary_axis(secondary_ax, settings, text_color)
        if table_ax is not None:
            self._draw_stat_table(table_ax, stat_groups, stat_rows, settings, text_color)
        self._apply_overlay_axis_label_y_padding(ax, settings)
        self._place_legend(ax, text_color, settings, extra_axes=[secondary_ax] if secondary_ax is not None else None)
        self.canvas.draw()
        if settings.auto_y_range:
            self._expand_axes_for_plot_content(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._expand_axes_for_plot_content(secondary_ax, settings)
        self.canvas.draw()
        if settings.auto_y_range:
            self._expand_axes_for_overlay_label_conflicts(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._expand_axes_for_overlay_label_conflicts(secondary_ax, settings)
        self.canvas.draw()
        if settings.auto_y_range:
            self._separate_overlay_value_labels(ax)
            self._expand_axes_for_plot_content(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._separate_overlay_value_labels(secondary_ax)
            self._expand_axes_for_plot_content(secondary_ax, settings)
        self._apply_value_axis_tick_interval(ax, settings)
        if secondary_ax is not None:
            self._apply_value_axis_tick_interval(secondary_ax, settings, secondary=True)
        self.canvas.draw()
        self._finalize_inside_legend(ax, secondary_ax, settings)
        self.canvas.draw()
        self._refresh_interaction_targets(settings, ax, table_ax, secondary_ax)
        self._last_settings = ChartSettings(**asdict(settings))
        self.canvas.repaint()
        self.scroll.viewport().repaint()
        self._schedule_legend_layout_finalize(settings, ax, table_ax, secondary_ax)

    def _handle_plot_motion(self, event) -> None:
        if self._legend_drag_state is not None:
            self._drag_legend_to_event(event)
            return
        target = self._interaction_target_at_event(event, include_point_targets=False)
        kind = self._selection_kind_for_target(target)
        if kind == self._hover_object_kind:
            return
        self._hover_object_kind = kind
        self._set_feedback_patch("_hover_feedback_patch", self._feedback_bboxes_for_target(target), selected=False)

    def _handle_plot_leave(self, _event) -> None:
        if self._legend_drag_state is not None:
            return
        self._hover_object_kind = None
        self._set_feedback_patch("_hover_feedback_patch", None, selected=False)

    def _handle_plot_click(self, event) -> None:
        if getattr(event, "button", None) != 1:
            return
        target = self._interaction_target_at_event(event)
        if target is None:
            self.clear_plot_selection()
            return
        if target.get("kind") == "legend" and self._legend_drag_enabled():
            self._start_legend_drag(event, target)
        self._selected_object_kind = self._selection_kind_for_target(target)
        self._set_feedback_patch("_selected_feedback_patch", self._feedback_bboxes_for_target(target), selected=True)
        if callable(self.selection_callback):
            self.selection_callback(self._selected_object_kind)

    def _handle_plot_release(self, event) -> None:
        if getattr(event, "button", None) != 1 or self._legend_drag_state is None:
            return
        self._drag_legend_to_event(event)
        self._finish_legend_drag()

    def _legend_drag_enabled(self) -> bool:
        settings = getattr(self, "_last_settings", None)
        return bool(settings is not None and settings.legend_position == LEGEND_POSITION_INSIDE)

    def _start_legend_drag(self, event, target: dict) -> None:
        legend = target.get("artist")
        bounds = self._legend_plot_union_bbox
        if legend is None or bounds is None:
            return
        bbox = target.get("bbox")
        if bbox is None:
            return
        self._legend_drag_state = {
            "legend": legend,
            "offset_x": float(getattr(event, "x", bbox.x0) - bbox.x0),
            "offset_y": float(bbox.y1 - getattr(event, "y", bbox.y1)),
            "bounds": bounds,
        }

    def _drag_legend_to_event(self, event) -> None:
        state = self._legend_drag_state
        if state is None or self.figure is None or self.canvas is None:
            return
        legend = state["legend"]
        bounds = state["bounds"]
        renderer = self.canvas.get_renderer()
        legend_bbox = self._legend_outer_bbox(legend, renderer)
        left = float(getattr(event, "x", legend_bbox.x0) - state["offset_x"])
        top = float(getattr(event, "y", legend_bbox.y1) + state["offset_y"])
        left, top = self._clamped_legend_left_top(left, top, legend_bbox, bounds)
        self._set_legend_outer_left_top(legend, left, top, renderer)
        self._set_feedback_patch("_selected_feedback_patch", self._legend_outer_bbox(legend, renderer), selected=True)
        self.canvas.draw_idle()

    def _finish_legend_drag(self) -> None:
        state = self._legend_drag_state
        self._legend_drag_state = None
        if state is None or self.canvas is None:
            return
        legend = state["legend"]
        bounds = state["bounds"]
        renderer = self.canvas.get_renderer()
        bbox = self._legend_outer_bbox(legend, renderer)
        left, top = self._clamped_legend_left_top(bbox.x0, bbox.y1, bbox, bounds)
        anchor_left, anchor_top = self._set_legend_outer_left_top(legend, left, top, renderer)
        x, y = self._legend_inside_position_from_display(anchor_left, anchor_top, bounds)
        if callable(self.legend_position_callback):
            self.legend_position_callback(x, y)

    def _clamped_legend_left_top(self, left: float, top: float, legend_bbox, bounds) -> tuple[float, float]:
        max_left = bounds.x1 - legend_bbox.width
        min_top = bounds.y0 + legend_bbox.height
        if max_left < bounds.x0:
            left = bounds.x0
        else:
            left = min(max(left, bounds.x0), max_left)
        if min_top > bounds.y1:
            top = bounds.y1
        else:
            top = min(max(top, min_top), bounds.y1)
        return (float(left), float(top))

    def _legend_inside_position_from_display(self, left: float, top: float, bounds) -> tuple[float, float]:
        return (
            min(max((left - bounds.x0) / max(bounds.width, 1.0), 0.0), 1.0),
            min(max((bounds.y1 - top) / max(bounds.height, 1.0), 0.0), 1.0),
        )

    def clear_plot_selection(self) -> None:
        self._selected_object_kind = None
        self._set_feedback_patch("_selected_feedback_patch", None, selected=True)
        if callable(self.selection_callback):
            self.selection_callback(None)

    def _clear_plot_feedback(self, clear_selection: bool = True) -> None:
        self._hover_object_kind = None
        if clear_selection:
            self._selected_object_kind = None
        self._remove_feedback_patch("_hover_feedback_patch")
        self._remove_feedback_patch("_selected_feedback_patch")

    def _feedback_bboxes_for_target(self, target):
        if target is None:
            return None
        return target.get("feedback_bboxes") or target.get("bbox")

    def _selection_kind_for_target(self, target) -> str | None:
        if target is None:
            return None
        return str(target.get("selection_kind") or target["kind"])

    def _set_feedback_patch(self, attribute: str, bboxes, selected: bool) -> None:
        self._remove_feedback_patch(attribute)
        if bboxes is None or self.figure is None or self.canvas is None:
            if self.canvas is not None:
                self.canvas.draw_idle()
            return
        if not isinstance(bboxes, (list, tuple)):
            bboxes = [bboxes]
        patches = []
        for bbox in bboxes:
            x0, y0, x1, y1 = self._bbox_to_figure_rect(bbox)
            if x1 <= x0 or y1 <= y0:
                continue
            patch = Rectangle(
                (x0, y0),
                x1 - x0,
                y1 - y0,
                transform=self.figure.transFigure,
                facecolor="#2563EB",
                edgecolor="#2563EB",
                alpha=0.08 if selected else 0.045,
                linewidth=1.5 if selected else 1.0,
                linestyle="-" if selected else "--",
                zorder=1000,
                clip_on=False,
            )
            self.figure.add_artist(patch)
            patches.append(patch)
        setattr(self, attribute, patches or None)
        self.canvas.draw_idle()

    def _remove_feedback_patch(self, attribute: str) -> None:
        patches = getattr(self, attribute, None)
        if patches is None:
            setattr(self, attribute, None)
            return
        if not isinstance(patches, (list, tuple)):
            patches = [patches]
        for patch in patches:
            try:
                patch.remove()
            except ValueError:
                pass
        setattr(self, attribute, None)

    def _bbox_to_figure_rect(self, bbox) -> tuple[float, float, float, float]:
        padded = self._padded_bbox(bbox, 4.0)
        (x0, y0), (x1, y1) = self.figure.transFigure.inverted().transform(
            [(padded.x0, padded.y0), (padded.x1, padded.y1)]
        )
        return (
            min(max(float(x0), 0.0), 1.0),
            min(max(float(y0), 0.0), 1.0),
            min(max(float(x1), 0.0), 1.0),
            min(max(float(y1), 0.0), 1.0),
        )

    def _refresh_interaction_targets(self, settings: ChartSettings, ax, table_ax, secondary_ax) -> None:
        if self.canvas is None or self.figure is None:
            self._interaction_targets = []
            return
        renderer = self.canvas.get_renderer()
        targets: list[dict] = []
        for axis in self.figure.axes:
            for line in axis.lines:
                if line.get_gid() == "overlay-line":
                    line.set_picker(6)
                    targets.append(
                        {
                            "kind": "line_overlay",
                            "artist": line,
                            "bbox": self._artist_bbox_or_axes_bbox(line, axis, renderer),
                            "priority": 10,
                        }
                    )
            for collection in axis.collections:
                if collection.get_gid() == "data-points":
                    collection.set_picker(6)
                    targets.append(
                        {
                            "kind": "points",
                            "artist": collection,
                            "bbox": axis.get_window_extent(renderer),
                            "priority": 20,
                        }
                    )

        legend = ax.get_legend()
        if legend is not None and legend.get_visible():
            targets.append(
                {
                    "kind": "legend",
                    "artist": legend,
                    "use_artist_contains": False,
                    "bbox": self._legend_outer_bbox(legend, renderer),
                    "priority": 0,
                }
            )
        if table_ax is not None:
            targets.append(
                {
                    "kind": "stats_table",
                    "bbox": table_ax.get_window_extent(renderer),
                    "priority": 5,
                }
            )
        split_secondary_frame = self._split_secondary_frame_enabled(settings)
        plot_axes = [candidate for candidate in (ax, secondary_ax) if candidate is not None]
        self._legend_plot_union_bbox = self._inside_legend_bounds(plot_axes, renderer, settings)
        for plot_axis in plot_axes:
            target = {
                "kind": "plot_area",
                "bbox": plot_axis.get_window_extent(renderer),
                "priority": 80,
            }
            if split_secondary_frame and plot_axis is secondary_ax:
                target["selection_kind"] = "line_overlay"
            targets.append(
                target
            )
        all_axis_feedback_boxes = [
            feedback_box
            for plot_axis in plot_axes
            for feedback_box in self._axis_feedback_boxes(plot_axis, renderer)
        ]
        for axis in plot_axes:
            axis_boxes = self._axis_interaction_boxes(axis, renderer)
            if axis_boxes:
                targets.append(
                    {
                        "kind": "axis",
                        "bbox": Bbox.union(axis_boxes),
                        "hit_bboxes": axis_boxes,
                        "feedback_bboxes": all_axis_feedback_boxes,
                        "priority": 30,
                    }
                )
        title_boxes = self._title_interaction_boxes([candidate for candidate in (ax, secondary_ax) if candidate is not None], renderer)
        if title_boxes:
            targets.append(
                {
                    "kind": "title_axis",
                    "bbox": Bbox.union(title_boxes),
                    "hit_bboxes": title_boxes,
                    "feedback_bboxes": title_boxes,
                    "priority": 25,
                }
            )
        self._interaction_targets = sorted(targets, key=lambda target: int(target.get("priority", 100)))

    def _interaction_target_at_event(self, event, include_point_targets: bool = True):
        x = getattr(event, "x", None)
        y = getattr(event, "y", None)
        if x is None or y is None:
            return None
        for target in self._interaction_targets:
            if not include_point_targets and target.get("kind") == "points":
                continue
            artist = target.get("artist")
            if artist is not None and target.get("use_artist_contains", True):
                try:
                    contains, _details = artist.contains(event)
                except Exception:
                    contains = False
                if contains:
                    return target
                continue
            bbox = target.get("bbox")
            hit_bboxes = target.get("hit_bboxes")
            if hit_bboxes is not None and any(hit_bbox.contains(x, y) for hit_bbox in hit_bboxes):
                return target
            if hit_bboxes is None and bbox is not None and bbox.contains(x, y):
                return target
        return None

    def _axis_interaction_boxes(self, ax, renderer):
        boxes = self._axis_feedback_boxes(ax, renderer, band=12.0)
        artists = [*ax.get_xticklabels(), *ax.get_yticklabels()]
        for artist in artists:
            if artist.get_visible() and artist.get_text():
                boxes.append(artist.get_window_extent(renderer))
        return boxes

    def _axis_feedback_boxes(self, ax, renderer, band: float = 3.0):
        axis_bounds = ax.get_window_extent(renderer)
        return [
            Bbox.from_extents(axis_bounds.x0 - band, axis_bounds.y0 - band, axis_bounds.x1 + band, axis_bounds.y0 + band),
            Bbox.from_extents(axis_bounds.x0 - band, axis_bounds.y1 - band, axis_bounds.x1 + band, axis_bounds.y1 + band),
            Bbox.from_extents(axis_bounds.x0 - band, axis_bounds.y0 - band, axis_bounds.x0 + band, axis_bounds.y1 + band),
            Bbox.from_extents(axis_bounds.x1 - band, axis_bounds.y0 - band, axis_bounds.x1 + band, axis_bounds.y1 + band),
        ]

    def _title_interaction_boxes(self, axes, renderer):
        boxes = []
        for ax in axes:
            artists = [ax.title, ax.xaxis.label, ax.yaxis.label]
            for artist in artists:
                if artist is not None and artist.get_visible() and artist.get_text():
                    boxes.append(artist.get_window_extent(renderer))
        return boxes

    def _artist_bbox_or_axes_bbox(self, artist, ax, renderer):
        try:
            bbox = artist.get_window_extent(renderer)
            if bbox.width > 0 and bbox.height > 0:
                return self._padded_bbox(bbox, 6.0)
        except Exception:
            pass
        return ax.get_window_extent(renderer)

    def _padded_bbox(self, bbox, padding: float):
        return Bbox.from_extents(bbox.x0 - padding, bbox.y0 - padding, bbox.x1 + padding, bbox.y1 + padding)

    def _apply_value_axis_tick_interval(self, ax, settings: ChartSettings, secondary: bool = False) -> None:
        auto_tick_interval = settings.secondary_auto_tick_interval if secondary else settings.primary_auto_tick_interval
        axis = ax.xaxis if settings.chart_type == "Ridge" else ax.yaxis
        if auto_tick_interval:
            return
        tick_interval = settings.secondary_tick_interval if secondary else settings.primary_tick_interval
        if not self._manual_tick_interval_is_safe(ax, tick_interval, settings):
            axis.set_major_locator(AutoLocator())
            self._auto_tick_interval_fallbacks.add("secondary" if secondary else "primary")
            return
        axis.set_major_locator(MultipleLocator(tick_interval))

    def _manual_tick_interval_is_safe(self, ax, tick_interval: float, settings: ChartSettings) -> bool:
        if not math.isfinite(tick_interval) or tick_interval <= 0:
            return False
        axis_min, axis_max = ax.get_xlim() if settings.chart_type == "Ridge" else ax.get_ylim()
        if not math.isfinite(axis_min) or not math.isfinite(axis_max):
            return False
        span = abs(axis_max - axis_min)
        if span <= 0:
            return True
        return math.ceil(span / tick_interval) + 1 <= MAX_MANUAL_TICK_COUNT

    def _apply_ridge_x_range(self, ax, settings: ChartSettings) -> None:
        if not settings.auto_y_range:
            ax.set_xlim(settings.y_min, settings.y_max)
            return

        self._apply_auto_value_axis_padding(ax, settings)

    def _apply_auto_value_axis_padding(self, ax, settings: ChartSettings) -> None:
        axis_min, axis_max = ax.dataLim.intervalx if settings.chart_type == "Ridge" else ax.dataLim.intervaly
        if not math.isfinite(axis_min) or not math.isfinite(axis_max):
            return
        if math.isclose(axis_min, axis_max, rel_tol=0.0, abs_tol=1e-12):
            pad = max(abs(axis_min) * AUTO_AXIS_RANGE_PADDING_FRACTION, 0.5)
        else:
            pad = (axis_max - axis_min) * AUTO_AXIS_RANGE_PADDING_FRACTION
        if settings.chart_type == "Ridge":
            ax.set_xlim(axis_min - pad, axis_max + pad)
        else:
            ax.set_ylim(axis_min - pad, axis_max + pad)

    def _point_positions(self, df: pd.DataFrame, settings: ChartSettings) -> pd.Series:
        order = list(df[settings.group_col].dropna().unique())
        xpos = {group: idx for idx, group in enumerate(order)}
        positions = pd.Series(index=df.index, dtype=float)
        for group in order:
            mask = df[settings.group_col] == group
            values = df.loc[mask, settings.value_col].to_numpy(dtype=float)
            offsets = self._jitter_offsets(values, settings.jitter, settings.jitter_mode, str(group))
            positions.loc[mask] = xpos[group] + offsets
        return positions

    def _draw_points(
        self,
        ax,
        df: pd.DataFrame,
        settings: ChartSettings,
        palette: list[str],
        preset: dict,
        positions: pd.Series,
    ) -> None:
        order = list(df[settings.group_col].dropna().unique())
        colors = {group: palette[idx % len(palette)] for idx, group in enumerate(order)}
        for group in order:
            group_df = df[df[settings.group_col] == group]
            color = colors[group]
            points = ax.scatter(
                positions.loc[group_df.index],
                group_df[settings.value_col],
                s=settings.point_size * 12,
                c=derived_group_color(color, "point", preset["background"]),
                alpha=settings.point_alpha,
                edgecolors=derived_group_color(color, "edge", preset["background"]),
                linewidths=0.35,
                zorder=5,
            )
            self._mark_point_artist(points)

    def _draw_box(self, ax, df: pd.DataFrame, settings: ChartSettings, palette: list[str]) -> None:
        existing_lines = set(ax.lines)
        existing_patches = set(ax.patches)
        existing_collections = set(ax.collections)
        sns.boxplot(
            data=df,
            x=settings.group_col,
            y=settings.value_col,
            ax=ax,
            hue=settings.group_col,
            palette=palette,
            legend=False,
            width=settings.box_width,
            showfliers=False,
            whis=box_whis(settings.box_whisker_mode),
            linewidth=PRESETS[settings.preset]["line_width"],
        )
        for patch in ax.patches:
            patch.set_alpha(settings.fill_alpha)
        for artist in [
            *(line for line in ax.lines if line not in existing_lines),
            *(patch for patch in ax.patches if patch not in existing_patches),
            *(collection for collection in ax.collections if collection not in existing_collections),
        ]:
            self._mark_plot_content_artist(artist)

    def _draw_violin(self, ax, df: pd.DataFrame, settings: ChartSettings, palette: list[str]) -> None:
        existing_lines = set(ax.lines)
        existing_patches = set(ax.patches)
        existing_collections = set(ax.collections)
        sns.violinplot(
            data=df,
            x=settings.group_col,
            y=settings.value_col,
            ax=ax,
            hue=settings.group_col,
            palette=palette,
            legend=False,
            width=settings.violin_width,
            inner="quartile",
            cut=0,
            bw_adjust=settings.kde_bandwidth,
            linewidth=PRESETS[settings.preset]["line_width"],
        )
        for collection in ax.collections:
            collection.set_alpha(settings.fill_alpha)
        for artist in [
            *(line for line in ax.lines if line not in existing_lines),
            *(patch for patch in ax.patches if patch not in existing_patches),
            *(collection for collection in ax.collections if collection not in existing_collections),
        ]:
            self._mark_plot_content_artist(artist)

    def _draw_ridge(
        self,
        ax,
        df: pd.DataFrame,
        point_df: pd.DataFrame,
        settings: ChartSettings,
        palette: list[str],
        text_color: str,
    ) -> None:
        groups = list(df[settings.group_col].dropna().unique())
        values = pd.to_numeric(point_df[settings.value_col], errors="coerce").dropna()
        xmin, xmax = float(values.min()), float(values.max())
        pad = max((xmax - xmin) * 0.08, 1e-3)
        xs = np.linspace(xmin - pad, xmax + pad, 300)
        y_positions = np.arange(len(groups))[::-1]
        max_density = 0.0
        densities = []

        for group in groups:
            vals = pd.to_numeric(df[df[settings.group_col] == group][settings.value_col], errors="coerce").dropna()
            if len(vals) < 2 or math.isclose(float(vals.std()), 0.0):
                density = np.zeros_like(xs)
            else:
                kde = gaussian_kde(vals, bw_method=settings.kde_bandwidth)
                density = kde(xs)
            max_density = max(max_density, float(density.max()))
            densities.append(density)

        scale = settings.ridge_overlap / max_density if max_density > 0 else 1.0
        outlier_label_added = False
        for idx, (group, density) in enumerate(zip(groups, densities)):
            y0 = y_positions[idx]
            color = palette[idx % len(palette)]
            y = y0 + density * scale
            ridge_fill = ax.fill_between(xs, y0, y, color=color, alpha=settings.fill_alpha, linewidth=0)
            ridge_line, = ax.plot(xs, y, color=color, linewidth=PRESETS[settings.preset]["line_width"])
            self._mark_plot_content_artist(ridge_fill)
            self._mark_plot_content_artist(ridge_line)
            if settings.show_points:
                group_points = point_df[point_df[settings.group_col] == group]
                vals = pd.to_numeric(group_points[settings.value_col], errors="coerce").dropna()
                offsets = self._jitter_offsets(vals.to_numpy(dtype=float), settings.jitter, settings.jitter_mode, str(group))
                points = ax.scatter(
                    vals,
                    np.full(len(vals), y0) + offsets,
                    s=settings.point_size * 8,
                    color=color,
                    alpha=settings.point_alpha,
                    edgecolors="#222222",
                    linewidths=0.25,
                )
                self._mark_point_artist(points)
                if settings.show_outliers:
                    out = mark_outliers(point_df, settings)
                    group_out = out[out[settings.group_col] == group]
                    if not group_out.empty:
                        offset_by_index = pd.Series(offsets, index=vals.index)
                        outlier_points = ax.scatter(
                            group_out[settings.value_col],
                            np.full(len(group_out), y0) + offset_by_index.loc[group_out.index],
                            s=max(settings.point_size * 18, 45),
                            facecolors="none",
                            edgecolors="#D62728",
                            linewidths=1.3,
                            zorder=6,
                            label="Outlier" if not outlier_label_added else "_nolegend_",
                        )
                        self._mark_point_artist(outlier_points)
                        outlier_label_added = True

        ax.set_yticks(y_positions)
        ax.set_yticklabels([str(group) for group in groups], color=text_color, fontsize=settings.tick_font_size)
        ax.tick_params(axis="y", length=0, pad=10)
        ax.set_ylim(-0.4, len(groups) - 1 + settings.ridge_overlap + 0.25)
        ax.set_xlim(xmin - pad, xmax + pad)

    def _style_plot_frame(self, ax, settings: ChartSettings, text_color: str) -> None:
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(text_color)
            spine.set_linewidth(settings.axis_line_width)

    def _custom_overlay_secondary_axis_active(self, settings: ChartSettings) -> bool:
        return bool(settings.custom_overlay_secondary_axis and settings.extra_custom_overlay and visible_custom_overlay_indexes(settings))

    def _split_secondary_frame_enabled(self, settings: ChartSettings) -> bool:
        return bool(self._custom_overlay_secondary_axis_active(settings) and settings.split_secondary_axis)

    def _secondary_axis_split_ratio(self, settings: ChartSettings) -> float:
        return max(0.15, min(float(settings.secondary_axis_split_ratio), 0.85))

    def _set_split_secondary_title(self, secondary_ax, primary_ax, settings: ChartSettings, text_color: str) -> None:
        title_x = 0.5
        if settings.chart_type == "Ridge":
            primary_position = primary_ax.get_position()
            secondary_position = secondary_ax.get_position()
            combined_center = (primary_position.x0 + secondary_position.x1) / 2.0
            title_x = (combined_center - secondary_position.x0) / max(secondary_position.width, 1e-9)
        secondary_ax.set_title(settings.title, fontsize=settings.title_font_size, color=text_color, x=title_x)

    def _style_split_secondary_axis(self, secondary_ax, primary_ax, groups: list[str], settings: ChartSettings, text_color: str) -> None:
        self._set_split_secondary_title(secondary_ax, primary_ax, settings, text_color)
        if settings.chart_type == "Ridge":
            secondary_ax.set_xlabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            secondary_ax.set_ylabel("", fontsize=settings.axis_label_font_size, color=text_color)
            secondary_ax.set_ylim(primary_ax.get_ylim())
            secondary_ax.set_yticks(primary_ax.get_yticks())
            secondary_ax.set_yticklabels([])
            secondary_ax.xaxis.set_label_position("top")
            secondary_ax.xaxis.tick_top()
            secondary_ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            secondary_ax.tick_params(axis="x", top=True, labeltop=True, bottom=False, labelbottom=False)
            secondary_ax.tick_params(axis="y", left=False, labelleft=False, right=False, labelright=False)
            self._style_plot_frame(secondary_ax, settings, text_color)
            secondary_ax.grid(bool(settings.show_grid), color="#D1D5DB" if PRESETS[settings.preset]["background"] == "#FFFFFF" else "#374151", alpha=0.55)
            return

        secondary_ax.set_xlabel("", fontsize=settings.axis_label_font_size, color=text_color)
        secondary_ax.set_ylabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
        secondary_ax.yaxis.set_label_position("right")
        secondary_ax.yaxis.tick_right()
        secondary_ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        secondary_ax.tick_params(axis="y", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        secondary_ax.tick_params(axis="y", left=False, labelleft=False, right=True, labelright=True)
        secondary_ax.set_xlim(primary_ax.get_xlim())
        secondary_ax.set_xticks(np.arange(len(groups)))
        secondary_ax.set_xticklabels([])
        secondary_ax.tick_params(axis="x", top=False, labeltop=False, bottom=False, labelbottom=False)
        self._style_plot_frame(secondary_ax, settings, text_color)
        secondary_ax.grid(bool(settings.show_grid), color="#D1D5DB" if PRESETS[settings.preset]["background"] == "#FFFFFF" else "#374151", alpha=0.55)

    def _style_secondary_axis(self, ax, settings: ChartSettings, text_color: str) -> None:
        if settings.chart_type == "Ridge":
            ax.set_xlabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            ax.tick_params(axis="y", left=False, labelleft=False)
            ax.spines["top"].set_visible(True)
            ax.spines["right"].set_visible(False)
        else:
            ax.set_ylabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            ax.tick_params(axis="y", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            ax.tick_params(axis="x", bottom=False, labelbottom=False)
            ax.spines["right"].set_visible(True)
            ax.spines["top"].set_visible(False)
        for spine in ax.spines.values():
            spine.set_color(text_color)
            spine.set_linewidth(settings.axis_line_width)
        ax.grid(False)

    def _draw_line_overlay(self, ax, df: pd.DataFrame, settings: ChartSettings, text_color: str, secondary_ax=None) -> None:
        series_list = line_overlay_series(df, settings)
        if not series_list:
            return
        line_width = max(settings.line_overlay_width, 0.1)
        point_size = max(settings.line_overlay_point_size, 0.0)
        overlay_colors = overlay_palette_for(df, settings, len(series_list))
        for series_index, series in enumerate(series_list):
            groups = series["groups"]
            values = series["values"]
            is_custom_overlay = series.get("kind") == "custom"
            target_ax = secondary_ax if series.get("secondary_axis") and secondary_ax is not None else ax
            label_position = overlay_label_position_for_series(settings, is_custom_overlay)
            preferred_auto_position = overlay_auto_avoidance_position(settings, is_custom_overlay)
            line_color = overlay_colors[series_index % len(overlay_colors)]
            line_style = overlay_line_style(overlay_style_for_series(settings, series, series_index))
            line_alpha = 1.0 if is_custom_overlay else STAT_OVERLAY_ALPHA
            finite_values = [value for value in values if math.isfinite(value)]
            if settings.chart_type == "Ridge":
                y_positions = np.arange(len(groups))[::-1]
                line, = target_ax.plot(
                    values,
                    y_positions,
                    color=line_color,
                    marker="o",
                    markersize=point_size,
                    linewidth=line_width,
                    linestyle=line_style,
                    dash_capstyle="round",
                    solid_capstyle="round",
                    alpha=line_alpha,
                    label=series["name"],
                    zorder=8 + series_index,
                )
                self._mark_overlay_line(line)
                if settings.show_line_values:
                    for index, (x_value, y_value) in enumerate(zip(values, y_positions)):
                        if not math.isfinite(x_value):
                            continue
                        if not self._overlay_label_anchor_is_visible(x_value, y_value, settings, uses_secondary_axis=target_ax is secondary_ax):
                            continue
                        if not is_custom_overlay and label_position in {"Axis left", "Axis right"}:
                            is_right_axis = label_position == "Axis right"
                            x_fraction = 1.0 if is_right_axis else 0.0
                            offset_x = -OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS if is_right_axis else OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                            horizontal_align = "right" if is_right_axis else "left"
                            annotation = target_ax.annotate(
                                format_overlay_value(x_value, settings),
                                xy=(x_fraction, y_value),
                                xycoords=target_ax.get_yaxis_transform(),
                                xytext=(offset_x, 0),
                                textcoords="offset points",
                                ha=horizontal_align,
                                va="center",
                                color=line_color,
                                fontsize=settings.line_value_font_size,
                                bbox=overlay_label_bbox(settings),
                                clip_on=False,
                                zorder=10 + series_index,
                            )
                            self._mark_overlay_value_label(annotation, is_custom_overlay, label_position)
                            continue
                        actual_label_position = resolve_overlay_label_position(
                            index,
                            finite_values,
                            label_position,
                            is_ridge=True,
                            series_index=series_index,
                            preferred_auto_position=preferred_auto_position,
                        )
                        offset_x, offset_y, horizontal_align, vertical_align = overlay_label_offset(
                            index,
                            finite_values,
                            actual_label_position,
                            is_ridge=True,
                            series_index=series_index,
                            marker_size_points=point_size,
                        )
                        annotation = target_ax.annotate(
                            format_overlay_value(x_value, settings),
                            xy=(x_value, y_value),
                            xytext=(offset_x, offset_y),
                            textcoords="offset points",
                            ha=horizontal_align,
                            va=vertical_align,
                            color=line_color,
                            fontsize=settings.line_value_font_size,
                            bbox=overlay_label_bbox(settings),
                            arrowprops=overlay_label_arrow(line_color),
                            zorder=10 + series_index,
                        )
                        self._mark_overlay_value_label(annotation, is_custom_overlay, actual_label_position)
                continue

            x_positions = np.arange(len(values))
            line, = target_ax.plot(
                x_positions,
                values,
                color=line_color,
                marker="o",
                markersize=point_size,
                linewidth=line_width,
                linestyle=line_style,
                dash_capstyle="round",
                solid_capstyle="round",
                alpha=line_alpha,
                label=series["name"],
                zorder=8 + series_index,
            )
            self._mark_overlay_line(line)
            if settings.show_line_values:
                for index, (x_value, y_value) in enumerate(zip(x_positions, values)):
                    if not math.isfinite(y_value):
                        continue
                    if not self._overlay_label_anchor_is_visible(x_value, y_value, settings, uses_secondary_axis=target_ax is secondary_ax):
                        continue
                    if not is_custom_overlay and label_position in {"Top axis", "Bottom axis"}:
                        is_top_axis = label_position == "Top axis"
                        y_fraction = 1.0 if is_top_axis else 0.0
                        offset_y = -OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS if is_top_axis else OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                        vertical_align = "top" if is_top_axis else "bottom"
                        annotation = target_ax.annotate(
                            format_overlay_value(y_value, settings),
                            xy=(x_value, y_fraction),
                            xycoords=target_ax.get_xaxis_transform(),
                            xytext=(0, offset_y),
                            textcoords="offset points",
                            ha="center",
                            va=vertical_align,
                            color=line_color,
                            fontsize=settings.line_value_font_size,
                            bbox=overlay_label_bbox(settings),
                            clip_on=False,
                            zorder=10 + series_index,
                        )
                        self._mark_overlay_value_label(annotation, is_custom_overlay, label_position)
                        continue
                    actual_label_position = resolve_overlay_label_position(
                        index,
                        finite_values,
                        label_position,
                        is_ridge=False,
                        series_index=series_index,
                        preferred_auto_position=preferred_auto_position,
                    )
                    offset_x, offset_y, horizontal_align, vertical_align = overlay_label_offset(
                        index,
                        finite_values,
                        actual_label_position,
                        is_ridge=False,
                        series_index=series_index,
                        marker_size_points=point_size,
                    )
                    annotation = target_ax.annotate(
                        format_overlay_value(y_value, settings),
                        xy=(x_value, y_value),
                        xytext=(offset_x, offset_y),
                        textcoords="offset points",
                        ha=horizontal_align,
                        va=vertical_align,
                        color=line_color,
                        fontsize=settings.line_value_font_size,
                        bbox=overlay_label_bbox(settings),
                        arrowprops=overlay_label_arrow(line_color),
                        zorder=10 + series_index,
                    )
                    self._mark_overlay_value_label(annotation, is_custom_overlay, actual_label_position)
    def _apply_overlay_axis_label_y_padding(self, ax, settings: ChartSettings) -> None:
        if settings.chart_type == "Ridge":
            return
        if not settings.auto_y_range:
            return
        if not settings.show_line_overlay or not settings.show_line_values:
            return
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        if line_value_position not in {"Top axis", "Bottom axis"}:
            return

        current_y_min, current_y_max = ax.get_ylim()
        if settings.auto_y_range:
            y_min, y_max = ax.dataLim.intervaly
        else:
            y_min, y_max = current_y_min, current_y_max
        if not math.isfinite(y_min) or not math.isfinite(y_max) or y_max < y_min:
            return

        y_range = y_max - y_min
        if math.isclose(y_range, 0.0):
            y_range = max(abs(y_min), abs(y_max), 1.0)
        axes_height_points = max(ax.get_position().height * self.figure.get_figheight() * 72.0, 1.0)
        label_margin_points = self._overlay_axis_label_margin_points(settings)
        marker_margin_points = self._overlay_axis_marker_margin_points(settings) if settings.auto_y_range else 0.0
        bottom_margin_points = marker_margin_points
        top_margin_points = marker_margin_points
        if line_value_position == "Bottom axis":
            bottom_margin_points += label_margin_points
        else:
            top_margin_points += label_margin_points

        bottom_fraction = bottom_margin_points / axes_height_points
        top_fraction = top_margin_points / axes_height_points
        total_fraction = min(max(bottom_fraction + top_fraction, 0.0), 0.80)
        if total_fraction <= 0.0:
            return

        scale = y_range / (1.0 - total_fraction)
        bottom_pad = scale * bottom_fraction
        top_pad = scale * top_fraction
        padded_y_min = y_min - bottom_pad
        padded_y_max = y_max + top_pad
        if line_value_position == "Top axis":
            padded_y_min = min(padded_y_min, current_y_min)
        else:
            padded_y_max = max(padded_y_max, current_y_max)
        ax.set_ylim(padded_y_min, padded_y_max)

    def _overlay_axis_label_margin_points(self, settings: ChartSettings) -> float:
        label_height_points = max(settings.line_value_font_size, 1) * 1.35
        label_data_pad_points = label_height_points * OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO
        return label_height_points + OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS + label_data_pad_points

    def _fit_ridge_axis_overlay_margin(self, ax, table_ax, settings: ChartSettings) -> None:
        if settings.chart_type != "Ridge" or not settings.show_line_overlay or not settings.show_line_values:
            return
        if normalize_overlay_label_position(settings.line_value_position, settings.chart_type) not in {"Axis left", "Axis right"}:
            return

        for _ in range(3):
            self.canvas.draw()
            renderer = self.canvas.get_renderer()
            figure_width = max(self.figure.bbox.width, 1.0)
            text_bounds = [text.get_window_extent(renderer) for text in ax.texts if text.get_visible() and text.get_text()]
            if not text_bounds:
                return

            left_overflow = max(0.0, 6.0 - min(bounds.x0 for bounds in text_bounds))
            right_overflow = max(0.0, max(bounds.x1 for bounds in text_bounds) - (self.figure.bbox.width - 6.0))
            if left_overflow <= 0.0 and right_overflow <= 0.0:
                return

            position = ax.get_position()
            new_left = position.x0 + left_overflow / figure_width
            new_right = position.x1 - right_overflow / figure_width
            if new_right - new_left < 0.20:
                return
            ax.set_position([new_left, position.y0, new_right - new_left, position.height])
            if table_ax is not None:
                table_position = table_ax.get_position()
                table_ax.set_position([new_left, table_position.y0, new_right - new_left, table_position.height])

    def _expand_axes_for_plot_content(self, ax, settings: ChartSettings) -> None:
        for _ in range(6):
            if not self._expand_axes_once_for_plot_content(ax, settings):
                return
            self.canvas.draw()

    def _expand_axes_for_overlay_label_conflicts(self, ax, settings: ChartSettings) -> None:
        for _ in range(3):
            if not self._expand_axes_once_for_overlay_label_conflicts(ax):
                return
            self.canvas.draw()

    def _overlay_label_anchor_is_visible(
        self,
        x_value: float,
        y_value: float,
        settings: ChartSettings,
        uses_secondary_axis: bool = False,
    ) -> bool:
        if uses_secondary_axis:
            if settings.secondary_auto_y_range:
                return True
            low, high = sorted((settings.secondary_y_min, settings.secondary_y_max))
            return low <= (x_value if settings.chart_type == "Ridge" else y_value) <= high
        if settings.auto_y_range:
            return True
        if settings.chart_type == "Ridge":
            low, high = sorted((settings.y_min, settings.y_max))
            return low <= x_value <= high
        low, high = sorted((settings.y_min, settings.y_max))
        return low <= y_value <= high

    def _expand_axes_once_for_overlay_label_conflicts(self, ax) -> bool:
        labels = [
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and text.get_visible() and text.get_text()
        ]
        if len(labels) < 2:
            return False

        renderer = self.canvas.get_renderer()
        axes_bounds = ax.get_window_extent(renderer)
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        x_per_px = abs(x_max - x_min) / max(axes_bounds.width, 1.0)
        y_per_px = abs(y_max - y_min) / max(axes_bounds.height, 1.0)
        padding_px = 2.0
        expand_left = expand_right = expand_bottom = expand_top = 0.0
        bounds_by_label = {label: self._overlay_label_bounds(label, renderer) for label in labels}

        for left_index, left_label in enumerate(labels):
            left_bounds = bounds_by_label[left_label]
            for right_label in labels[left_index + 1:]:
                right_bounds = bounds_by_label[right_label]
                overlap_x = min(left_bounds.x1, right_bounds.x1) - max(left_bounds.x0, right_bounds.x0) + padding_px
                overlap_y = min(left_bounds.y1, right_bounds.y1) - max(left_bounds.y0, right_bounds.y0) + padding_px
                if overlap_x <= 0.0 or overlap_y <= 0.0:
                    continue
                moving_label = self._lower_priority_overlay_label(left_label, right_label)
                position = getattr(moving_label, "_easygraph_overlay_position", "Auto")
                if position == "Below":
                    expand_bottom = max(expand_bottom, overlap_y)
                elif position == "Above":
                    expand_top = max(expand_top, overlap_y)
                elif position == "Left":
                    expand_left = max(expand_left, overlap_x)
                elif position == "Right":
                    expand_right = max(expand_right, overlap_x)

        if max(expand_left, expand_right, expand_bottom, expand_top) <= 0.05:
            return False

        ax.set_xlim(x_min - expand_left * x_per_px, x_max + expand_right * x_per_px)
        ax.set_ylim(y_min - expand_bottom * y_per_px, y_max + expand_top * y_per_px)
        return True

    def _expand_axes_once_for_plot_content(self, ax, settings: ChartSettings) -> bool:
        renderer = self.canvas.get_renderer()
        axes_bounds = ax.get_window_extent(renderer)
        labels = [
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
            and text.get_visible()
            and text.get_text()
            and getattr(text, "_easygraph_overlay_position", "Auto")
            not in {"Top axis", "Bottom axis", "Axis left", "Axis right"}
        ]
        content_bounds = [self._overlay_label_bounds(text, renderer) for text in labels]
        for artist in [*ax.lines, *ax.patches, *ax.collections]:
            if artist.get_gid() not in {"plot-content", "data-points", "overlay-line"} or not artist.get_visible():
                continue
            bounds = self._plot_content_artist_bounds(artist, ax, renderer)
            if bounds is not None:
                content_bounds.append(bounds)
        if not content_bounds:
            return False

        plot_content_bounds = Bbox.union(content_bounds)
        category_padding_px = 2.0
        if settings.chart_type == "Ridge":
            value_padding_px = plot_content_bounds.width * OVERLAY_CONTENT_MARGIN_RATIO
        else:
            value_padding_px = plot_content_bounds.height * OVERLAY_CONTENT_MARGIN_RATIO

        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        x_per_px = abs(x_max - x_min) / max(axes_bounds.width, 1.0)
        y_per_px = abs(y_max - y_min) / max(axes_bounds.height, 1.0)
        if settings.chart_type == "Ridge":
            horizontal_padding_px = value_padding_px
            vertical_padding_px = category_padding_px
        else:
            horizontal_padding_px = category_padding_px
            vertical_padding_px = value_padding_px

        expand_left = max(0.0, axes_bounds.x0 + horizontal_padding_px - plot_content_bounds.x0)
        expand_right = max(0.0, plot_content_bounds.x1 - (axes_bounds.x1 - horizontal_padding_px))
        expand_bottom = max(0.0, axes_bounds.y0 + vertical_padding_px - plot_content_bounds.y0)
        expand_top = max(0.0, plot_content_bounds.y1 - (axes_bounds.y1 - vertical_padding_px))

        if max(expand_left, expand_right, expand_bottom, expand_top) <= 0.05:
            return False

        ax.set_xlim(x_min - expand_left * x_per_px, x_max + expand_right * x_per_px)
        ax.set_ylim(y_min - expand_bottom * y_per_px, y_max + expand_top * y_per_px)
        return True

    def _plot_content_artist_bounds(self, artist, ax, renderer):
        if isinstance(artist, PathCollection):
            offsets = np.asarray(artist.get_offsets(), dtype=float)
            if offsets.size:
                display_offsets = artist.get_offset_transform().transform(offsets)
                finite_offsets = display_offsets[np.isfinite(display_offsets).all(axis=1)]
                if finite_offsets.size:
                    sizes = np.asarray(artist.get_sizes(), dtype=float)
                    marker_radius = math.sqrt(float(np.nanmax(sizes))) * self.figure.dpi / 144.0 if sizes.size else 0.0
                    return Bbox.from_extents(
                        float(finite_offsets[:, 0].min()) - marker_radius,
                        float(finite_offsets[:, 1].min()) - marker_radius,
                        float(finite_offsets[:, 0].max()) + marker_radius,
                        float(finite_offsets[:, 1].max()) + marker_radius,
                    )

        bounds = artist.get_window_extent(renderer)
        if np.isfinite(bounds.extents).all():
            return bounds
        if hasattr(artist, "get_datalim"):
            data_bounds = artist.get_datalim(ax.transData)
            if np.isfinite(data_bounds.extents).all():
                return ax.transData.transform_bbox(data_bounds)
        return None

    def _separate_overlay_value_labels(self, ax) -> None:
        labels = [
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and text.get_visible() and text.get_text()
        ]
        labels.sort(key=lambda text: getattr(text, "_easygraph_overlay_priority", 1))
        if not labels:
            return

        padding_px = 2.0
        for _ in range(4):
            self.canvas.draw()
            renderer = self.canvas.get_renderer()
            bounds_by_label = {label: self._overlay_label_bounds(label, renderer) for label in labels}
            moved = False
            for left_index, left_label in enumerate(labels):
                left_bounds = bounds_by_label[left_label]
                for right_label in labels[left_index + 1:]:
                    right_bounds = bounds_by_label[right_label]
                    overlap_x = min(left_bounds.x1, right_bounds.x1) - max(left_bounds.x0, right_bounds.x0) + padding_px
                    overlap_y = min(left_bounds.y1, right_bounds.y1) - max(left_bounds.y0, right_bounds.y0) + padding_px
                    if overlap_x <= 0.0 or overlap_y <= 0.0:
                        continue

                    left_center_x = (left_bounds.x0 + left_bounds.x1) / 2.0
                    right_center_x = (right_bounds.x0 + right_bounds.x1) / 2.0
                    left_center_y = (left_bounds.y0 + left_bounds.y1) / 2.0
                    right_center_y = (right_bounds.y0 + right_bounds.y1) / 2.0

                    moving_label = self._lower_priority_overlay_label(left_label, right_label)
                    fixed_bounds = right_bounds if moving_label is left_label else left_bounds
                    moving_bounds = left_bounds if moving_label is left_label else right_bounds
                    fixed_center_x = (fixed_bounds.x0 + fixed_bounds.x1) / 2.0
                    moving_center_x = (moving_bounds.x0 + moving_bounds.x1) / 2.0
                    fixed_center_y = (fixed_bounds.y0 + fixed_bounds.y1) / 2.0
                    moving_center_y = (moving_bounds.y0 + moving_bounds.y1) / 2.0

                    if overlap_x < overlap_y:
                        direction = 1.0 if moving_center_x >= fixed_center_x else -1.0
                        self._move_overlay_label(moving_label, direction * overlap_x, 0.0)
                    else:
                        direction = 1.0 if moving_center_y >= fixed_center_y else -1.0
                        self._move_overlay_label(moving_label, 0.0, direction * overlap_y)
                    moved = True

            if not moved:
                return

    def _move_overlay_label(self, text, dx_px: float, dy_px: float) -> None:
        pixel_to_points = 72.0 / max(self.figure.dpi, 1.0)
        x_offset, y_offset = text.get_position()
        text.set_position((x_offset + dx_px * pixel_to_points, y_offset + dy_px * pixel_to_points))

    def _mark_overlay_value_label(self, text, is_custom_overlay: bool, label_position: str) -> None:
        text.set_gid("overlay-value-label")
        text._easygraph_overlay_priority = 1 if is_custom_overlay else 0
        text._easygraph_overlay_position = label_position

    def _mark_overlay_line(self, line) -> None:
        line.set_gid("overlay-line")
        line.set_picker(6)

    def _mark_plot_content_artist(self, artist) -> None:
        artist.set_gid("plot-content")

    def _mark_point_artist(self, artist) -> None:
        artist.set_gid("data-points")
        artist.set_picker(6)

    def _lower_priority_overlay_label(self, first, second):
        first_priority = getattr(first, "_easygraph_overlay_priority", 1)
        second_priority = getattr(second, "_easygraph_overlay_priority", 1)
        if first_priority > second_priority:
            return first
        return second

    def _overlay_label_bounds(self, text, renderer):
        bbox_patch = text.get_bbox_patch()
        if bbox_patch is not None:
            return bbox_patch.get_window_extent(renderer)
        return text.get_window_extent(renderer)

    def _place_legend(self, ax, text_color: str, settings: ChartSettings, extra_axes: list | None = None) -> None:
        if not settings.show_legend:
            existing_legend = ax.get_legend()
            if existing_legend is not None:
                existing_legend.remove()
            return
        handles, labels = ax.get_legend_handles_labels()
        for extra_ax in extra_axes or []:
            if extra_ax is None:
                continue
            extra_handles, extra_labels = extra_ax.get_legend_handles_labels()
            handles.extend(extra_handles)
            labels.extend(extra_labels)
        if not labels:
            return

        existing_legend = ax.get_legend()
        if existing_legend is not None:
            existing_legend.remove()
        self.canvas.draw()
        renderer = self.canvas.get_renderer()
        columns = self._legend_column_count(labels, settings, renderer)
        force_wrap = self._legend_force_wrap(labels, settings, renderer)
        labels = [self._legend_label_text(label, settings, columns, renderer, force_wrap=force_wrap) for label in labels]
        if settings.legend_position == LEGEND_POSITION_INSIDE:
            legend = self._place_legend_inside(ax, handles, labels, text_color, settings, columns, extra_axes)
            for text in legend.get_texts():
                text.set_color(text_color)
            self._style_legend_frame(legend, settings)
            return
        legend_anchor_x = self._legend_right_anchor_x(ax, settings)
        legend = ax.legend(
            handles,
            labels,
            loc="upper left",
            bbox_to_anchor=(legend_anchor_x, 1.0),
            borderaxespad=0.0,
            frameon=False,
            fontsize=settings.legend_font_size,
            ncol=columns,
            columnspacing=1.0,
            handlelength=LEGEND_HANDLE_LENGTH,
        )
        for text in legend.get_texts():
            text.set_color(text_color)

    def _place_legend_inside(
        self,
        ax,
        handles: list,
        labels: list[str],
        text_color: str,
        settings: ChartSettings,
        columns: int,
        extra_axes: list | None = None,
    ):
        has_saved_position = (
            settings.legend_inside_x != LEGEND_INSIDE_AUTO_POSITION
            and settings.legend_inside_y != LEGEND_INSIDE_AUTO_POSITION
        )
        if has_saved_position:
            self.canvas.draw()
            renderer = self.canvas.get_renderer()
            bounds = self._inside_legend_bounds([ax, *(extra_axes or [])], renderer, settings)
            left = bounds.x0 + settings.legend_inside_x * bounds.width
            top = bounds.y1 - settings.legend_inside_y * bounds.height
            fig_x, fig_y = self.figure.transFigure.inverted().transform((left, top))
            legend = ax.legend(
                handles,
                labels,
                loc="upper left",
                bbox_to_anchor=(float(fig_x), float(fig_y)),
                bbox_transform=self.figure.transFigure,
                borderaxespad=0.0,
                frameon=True,
                fontsize=settings.legend_font_size,
                ncol=columns,
                columnspacing=1.0,
                handlelength=LEGEND_HANDLE_LENGTH,
            )
            return legend

        legend = ax.legend(
            handles,
            labels,
            loc="best",
            borderaxespad=0.0,
            frameon=True,
            fontsize=settings.legend_font_size,
            ncol=columns,
            columnspacing=1.0,
            handlelength=LEGEND_HANDLE_LENGTH,
        )
        return legend

    def _style_legend_frame(self, legend, settings: ChartSettings) -> None:
        legend.set_zorder(100)
        frame = legend.get_frame()
        if frame is None:
            return
        preset = PRESETS.get(settings.preset, PRESETS[ChartSettings().preset])
        background = QColor(str(preset["background"]))
        is_light_background = not background.isValid() or _relative_luminance(background) >= 0.52
        frame.set_facecolor("#FFFFFF" if is_light_background else "#111827")
        frame.set_edgecolor("#222222" if is_light_background else "#F9FAFB")
        frame.set_alpha(0.78 if is_light_background else 0.72)
        frame.set_linewidth(settings.axis_line_width)
        frame.set_boxstyle("square,pad=0.25")

    def _clamp_inside_legend_artist(self, legend, bounds, settings: ChartSettings) -> None:
        renderer = self.canvas.get_renderer()
        bbox = self._legend_outer_bbox(legend, renderer)
        left, top = self._clamped_legend_left_top(bbox.x0, bbox.y1, bbox, bounds)
        anchor_left, anchor_top = self._set_legend_outer_left_top(legend, left, top, renderer)
        x, y = self._legend_inside_position_from_display(anchor_left, anchor_top, bounds)
        settings.legend_inside_x = x
        settings.legend_inside_y = y

    def _legend_outer_bbox(self, legend, renderer):
        frame = legend.get_frame()
        if frame is not None and frame.get_visible():
            return frame.get_window_extent(renderer)
        return legend.get_window_extent(renderer)

    def _set_legend_outer_left_top(self, legend, left: float, top: float, renderer) -> tuple[float, float]:
        outer_bbox = self._legend_outer_bbox(legend, renderer)
        legend_bbox = legend.get_window_extent(renderer)
        anchor_left = legend_bbox.x0 + (left - outer_bbox.x0)
        anchor_top = legend_bbox.y1 + (top - outer_bbox.y1)
        fig_x, fig_y = self.figure.transFigure.inverted().transform((anchor_left, anchor_top))
        legend.set_loc("upper left")
        legend.set_bbox_to_anchor((float(fig_x), float(fig_y)), transform=self.figure.transFigure)
        return anchor_left, anchor_top

    def _finalize_inside_legend(self, ax, secondary_ax, settings: ChartSettings) -> None:
        if settings.legend_position != LEGEND_POSITION_INSIDE:
            return
        legend = ax.get_legend()
        if legend is None or not legend.get_visible():
            return
        renderer = self.canvas.get_renderer()
        bounds = self._inside_legend_bounds(
            [candidate for candidate in (ax, secondary_ax) if candidate is not None],
            renderer,
            settings,
        )
        self._clamp_inside_legend_artist(legend, bounds, settings)

    def _schedule_legend_layout_finalize(self, settings, ax, table_ax, secondary_ax) -> None:
        self._legend_layout_token += 1
        if settings.legend_position != LEGEND_POSITION_INSIDE or self.canvas is None:
            return
        token = self._legend_layout_token
        canvas = self.canvas
        QTimer.singleShot(
            0,
            lambda: self._finalize_legend_after_qt_layout(
                token, canvas, settings, ax, table_ax, secondary_ax
            ),
        )

    def _finalize_legend_after_qt_layout(self, token, canvas, settings, ax, table_ax, secondary_ax) -> None:
        if token != self._legend_layout_token or canvas is not self.canvas:
            return
        canvas.draw()
        self._finalize_inside_legend(ax, secondary_ax, settings)
        canvas.draw()
        self._refresh_interaction_targets(settings, ax, table_ax, secondary_ax)
        canvas.repaint()

    def _inside_legend_bounds(self, axes: list, renderer, settings: ChartSettings):
        bounds = self._plot_axes_union_bbox(axes, renderer)
        inset = max(1.0, renderer.points_to_pixels(max(settings.axis_line_width, 0.0)) / 2.0 + 0.5)
        width = max(1.0, bounds.width - inset * 2.0)
        height = max(1.0, bounds.height - inset * 2.0)
        return Bbox.from_bounds(bounds.x0 + inset, bounds.y0 + inset, width, height)

    def _plot_axes_union_bbox(self, axes: list, renderer):
        boxes = [axis.get_window_extent(renderer) for axis in axes if axis is not None]
        if not boxes:
            return Bbox.from_bounds(0.0, 0.0, max(self.figure.bbox.width, 1.0), max(self.figure.bbox.height, 1.0))
        return Bbox.union(boxes)

    def _legend_right_anchor_x(self, ax, settings: ChartSettings) -> float:
        base_anchor = 1.02
        if settings.chart_type == "Ridge":
            if not self._split_secondary_frame_enabled(settings):
                return base_anchor
            secondary_ax = next((axis for axis in self.figure.axes if axis.get_gid() == "secondary-axis"), None)
            if secondary_ax is None:
                return base_anchor
            renderer = self.canvas.get_renderer()
            axis_bounds = ax.get_window_extent(renderer)
            secondary_bounds = secondary_ax.get_window_extent(renderer)
            return base_anchor + max(0.0, secondary_bounds.x1 - axis_bounds.x1) / max(axis_bounds.width, 1.0)
        if not self._custom_overlay_secondary_axis_active(settings):
            return base_anchor

        secondary_ax = next((axis for axis in self.figure.axes if axis.get_gid() == "secondary-axis"), None)
        if secondary_ax is None or not secondary_ax.yaxis.label.get_text():
            return base_anchor

        renderer = self.canvas.get_renderer()
        axis_bounds = ax.get_window_extent(renderer)
        label_bounds = secondary_ax.yaxis.label.get_window_extent(renderer)
        if label_bounds.width <= 0.0:
            return base_anchor

        reserved_right_px = max(axis_bounds.x1, label_bounds.x1 + LEGEND_SECONDARY_AXIS_GAP_PX)
        anchor_x = 1.0 + (reserved_right_px - axis_bounds.x1) / max(axis_bounds.width, 1.0)
        return max(base_anchor, anchor_x)

    def _legend_label_text(
        self,
        label: object,
        settings: ChartSettings,
        columns: int = 1,
        renderer=None,
        force_wrap: bool = False,
    ) -> str:
        text = str(label).replace("\\n", "\n")
        if self._legend_auto_width_enabled(settings):
            return text
        if settings.legend_columns <= 0 and not force_wrap:
            return text
        if renderer is None:
            max_units = self._legend_wrap_units(settings, columns)
            wrapped_lines = []
            for line in text.splitlines() or [""]:
                wrapped_lines.extend(self._wrap_visual_units(line, max_units) or [""])
            return "\n".join(wrapped_lines)
        max_width_in = self._legend_text_width_inches(settings, columns)
        wrapped_lines = []
        for line in text.splitlines() or [""]:
            wrapped_lines.extend(self._wrap_text_to_width(line, max_width_in, settings.legend_font_size, renderer) or [""])
        return "\n".join(wrapped_lines)

    def _legend_wrap_units(self, settings: ChartSettings, columns: int = 1) -> float:
        width_in = self._legend_text_width_inches(settings, columns)
        return max(4.0, width_in * 72.0 / (max(settings.legend_font_size, 1) * 0.52))

    def _legend_text_width_inches(self, settings: ChartSettings, columns: int = 1) -> float:
        column_width_in = self._legend_column_width_inches(settings, columns)
        return max(0.20, column_width_in - self._legend_handle_space_inches(settings))

    def _legend_total_width_inches(self, settings: ChartSettings) -> float:
        return max(settings.legend_width, 0.5) / 2.54

    def _legend_auto_width_enabled(self, settings: ChartSettings) -> bool:
        return bool(settings.legend_columns > 0 and settings.legend_auto_width)

    def _legend_handle_space_inches(self, settings: ChartSettings) -> float:
        return max(settings.legend_font_size, 1) * LEGEND_HANDLE_SPACE_UNITS / 72.0

    def _legend_column_gap_inches(self, settings: ChartSettings) -> float:
        return max(settings.legend_font_size, 1) * LEGEND_COLUMN_SPACING / 72.0

    def _legend_column_width_inches(self, settings: ChartSettings, columns: int) -> float:
        columns = max(1, columns)
        available_width = self._legend_total_width_inches(settings) - self._legend_column_gap_inches(settings) * (columns - 1)
        return max(0.25, available_width / columns)

    def _wrap_text_to_width(self, text: str, max_width_in: float, font_size: int, renderer) -> list[str]:
        if self._measured_text_width_inches(text, font_size, renderer) <= max_width_in:
            return [text]

        pieces = [piece for piece in re.split(r"(\s+|[-/_:;,，。；：、]+)", text) if piece]
        if len(pieces) <= 1:
            return self._wrap_unbreakable_text(text, max_width_in, font_size, renderer)

        lines = []
        current = ""
        token_tolerance_in = max_width_in * 1.5
        for piece in pieces:
            candidate = f"{current}{piece}" if current else piece.lstrip()
            if not candidate:
                continue
            if self._measured_text_width_inches(candidate.rstrip(), font_size, renderer) <= max_width_in:
                current = candidate
                continue
            if current.strip():
                lines.append(current.rstrip())
                current = piece.lstrip()
                if current and self._measured_text_width_inches(current, font_size, renderer) > max_width_in:
                    if self._measured_text_width_inches(current, font_size, renderer) <= token_tolerance_in:
                        lines.append(current)
                    else:
                        lines.extend(self._wrap_unbreakable_text(current, max_width_in, font_size, renderer))
                    current = ""
            else:
                stripped = piece.strip()
                if self._measured_text_width_inches(stripped, font_size, renderer) <= token_tolerance_in:
                    lines.append(stripped)
                else:
                    lines.extend(self._wrap_unbreakable_text(stripped, max_width_in, font_size, renderer))
                current = ""
        if current.strip():
            lines.append(current.rstrip())
        return lines

    def _wrap_unbreakable_text(self, text: str, max_width_in: float, font_size: int, renderer) -> list[str]:
        lines = []
        current = ""
        for char in text:
            candidate = f"{current}{char}"
            if current and self._measured_text_width_inches(candidate, font_size, renderer) > max_width_in:
                lines.append(current)
                current = char
            else:
                current = candidate
        if current or not lines:
            lines.append(current)
        return lines

    def _measured_text_width_inches(self, text: str, font_size: int, renderer) -> float:
        artist = self.figure.text(0, 0, text, fontsize=font_size, alpha=0.0)
        try:
            return artist.get_window_extent(renderer).width / max(self.figure.dpi, 1.0)
        finally:
            artist.remove()

    def _wrap_visual_units(self, text: str, max_units: float) -> list[str]:
        if self._text_visual_units(text) <= max_units:
            return [text]
        lines = []
        current = ""
        current_units = 0.0
        for char in text:
            char_units = 2.0 if unicodedata.east_asian_width(char) in {"F", "W"} else 1.0
            if current and current_units + char_units > max_units:
                lines.append(current.rstrip())
                current = char
                current_units = char_units
            else:
                current += char
                current_units += char_units
        if current or not lines:
            lines.append(current.rstrip())
        return lines

    def _legend_column_count(self, labels: list[str], settings: ChartSettings, renderer=None) -> int:
        item_count = max(1, len(labels))
        if settings.legend_columns > 0:
            return min(max(1, settings.legend_columns), item_count)

        max_item_width = max(
            (self._legend_unwrapped_item_width_inches(label, settings, renderer) for label in labels),
            default=self._legend_handle_space_inches(settings),
        )
        column_gap = self._legend_column_gap_inches(settings)
        total_width = self._legend_total_width_inches(settings)
        columns_that_fit = math.floor((total_width + column_gap) / max(max_item_width + column_gap, 0.01))
        return min(max(1, columns_that_fit), item_count, LEGEND_MAX_COLUMNS)

    def _legend_force_wrap(self, labels: list[str], settings: ChartSettings, renderer=None) -> bool:
        if self._legend_auto_width_enabled(settings):
            return False
        if settings.legend_columns > 0:
            return True
        max_item_width = max(
            (self._legend_unwrapped_item_width_inches(label, settings, renderer) for label in labels),
            default=self._legend_handle_space_inches(settings),
        )
        return self._legend_total_width_inches(settings) < max_item_width

    def _legend_unwrapped_item_width_inches(self, label: object, settings: ChartSettings, renderer=None) -> float:
        text = str(label).replace("\\n", "\n")
        lines = text.splitlines() or [""]
        if renderer is None:
            text_width = self._max_text_width_inches(lines, settings.legend_font_size)
        else:
            text_width = max((self._measured_text_width_inches(line, settings.legend_font_size, renderer) for line in lines), default=0.0)
        return text_width + self._legend_handle_space_inches(settings)

    def _overlay_axis_marker_margin_points(self, settings: ChartSettings) -> float:
        marker_areas = []
        if settings.show_points:
            marker_areas.append(settings.point_size * 12)
        if settings.show_outliers:
            marker_areas.append(max(settings.point_size * 18, 45))
        if not marker_areas:
            return 0.0
        return math.sqrt(max(marker_areas)) / 2.0 + 1.0

    def _draw_stat_table(
        self,
        table_ax,
        groups: list[str],
        rows: list[tuple[str, list[str]]],
        settings: ChartSettings,
        text_color: str,
    ) -> None:
        if not groups or not rows:
            return
        table_ax.set_xlim(-0.5, len(groups) - 0.5)
        font_size = settings.stat_table_font_size
        all_rows = [("", [str(group) for group in groups])] if stat_table_header_enabled(settings) else []
        all_rows.extend(rows)
        row_heights = self._stat_table_row_height_units(groups, rows, settings)
        total_height = sum(row_heights)
        table_ax.set_ylim(0, total_height)
        table_ax.axis("off")
        preset = PRESETS[settings.preset]
        edge_color = "#D1D5DB" if preset["background"] == "#FFFFFF" else "#4B5563"

        y_cursor = total_height
        row_edges = [total_height]
        for row_index, (label, values) in enumerate(all_rows):
            row_height = row_heights[row_index]
            y_cursor -= row_height
            row_edges.append(y_cursor)
            if label:
                table_ax.text(
                    -0.58,
                    y_cursor + row_height / 2,
                    label,
                    ha="right",
                    va="center",
                    color=text_color,
                    fontsize=font_size,
                    clip_on=False,
                    linespacing=1.15,
                )
            for column, value in enumerate(values):
                table_ax.text(
                    column,
                    y_cursor + row_height / 2,
                    value,
                    ha="center",
                    va="center",
                    color=text_color,
                    fontsize=font_size,
                    linespacing=1.15,
                )
        line_width = 0.6
        for x_value in np.arange(-0.5, len(groups) + 0.5, 1.0):
            table_ax.vlines(x_value, 0, total_height, colors=edge_color, linewidth=line_width, clip_on=False)
        for y_value in row_edges:
            table_ax.hlines(y_value, -0.5, len(groups) - 0.5, colors=edge_color, linewidth=line_width, clip_on=False)

    def _fit_table_left_margin(self, ax, table_ax, settings: ChartSettings) -> None:
        for _ in range(3):
            self.canvas.draw()
            renderer = self.canvas.get_renderer()
            text_artists = [text for text in table_ax.texts if text.get_visible()]
            text_artists.append(ax.yaxis.label)
            if settings.chart_type == "Ridge":
                text_artists.extend(label for label in ax.get_yticklabels() if label.get_visible())
            left_edges = [
                artist.get_window_extent(renderer).x0
                for artist in text_artists
                if artist.get_text()
            ]
            if not left_edges:
                return
            overflow_px = 6.0 - min(left_edges)
            if overflow_px <= 0:
                return
            delta = overflow_px / max(self.figure.bbox.width, 1.0)
            for target_ax in (ax, table_ax):
                position = target_ax.get_position()
                new_left = min(position.x0 + delta, position.x1 - 0.20)
                target_ax.set_position([new_left, position.y0, position.x1 - new_left, position.height])

    def _stat_table_row_height_inches(self, settings: ChartSettings) -> float:
        font_height = max(settings.stat_table_font_size, 1) / 72.0
        return font_height + 0.10

    def _stat_table_height_inches(self, groups: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings) -> float:
        return self._stat_table_row_height_inches(settings) * sum(self._stat_table_row_height_units(groups, rows, settings))

    def _stat_table_row_height_units(self, groups: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings) -> list[float]:
        heights = []
        if stat_table_header_enabled(settings):
            heights.append(max(1.0, self._max_line_count(groups) * 0.96))
        heights.extend(1.0 for _ in rows)
        return heights

    def _stat_table_gap_inches(self, settings: ChartSettings, groups: list[str], x_axis_label: str) -> float:
        tick_height = max(settings.tick_font_size, 1) / 72.0 * self._max_line_count(groups) * 1.15
        tick_width = self._max_text_width_inches(groups, settings.tick_font_size)
        x_tick_rotation = 0 if settings.chart_type == "Ridge" else settings.x_tick_rotation
        rotation = math.radians(abs(x_tick_rotation))
        rotated_tick_height = tick_width * math.sin(rotation) + tick_height * math.cos(rotation)
        label_height = max(settings.axis_label_font_size, 1) / 72.0 * self._line_count(x_axis_label) * 1.25 if x_axis_label else 0.0
        overlay_height = 0.0
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        if settings.show_line_overlay and settings.show_line_values and line_value_position == "Bottom axis":
            overlay_height = self._overlay_axis_label_margin_points(settings) / 72.0
        tick_pad = 0.10 if groups else 0.0
        label_pad = 0.08 if x_axis_label else 0.0
        table_pad = 0.08
        return tick_pad + rotated_tick_height + label_pad + label_height + overlay_height + table_pad

    def _plot_left_margin_inches(
        self,
        settings: ChartSettings,
        groups: list[object],
        y_axis_label: str,
        stat_rows: list[tuple[str, list[str]]],
    ) -> float:
        left_margin_in = 0.62
        if y_axis_label:
            left_margin_in = max(left_margin_in, self._rotated_axis_label_width_inches(y_axis_label, settings.axis_label_font_size))
        if settings.chart_type == "Ridge":
            tick_width_in = self._max_text_width_inches(groups, settings.tick_font_size)
            axis_label_in = self._rotated_axis_label_width_inches(y_axis_label, settings.axis_label_font_size, pad=0.0) if y_axis_label else 0.0
            left_margin_in = max(left_margin_in, tick_width_in + axis_label_in + 0.38)
        if stat_rows:
            row_labels = [label for label, _values in stat_rows if label]
            left_margin_in = max(left_margin_in, self._max_text_width_inches(row_labels, settings.stat_table_font_size) + 0.62)
        if (
            settings.chart_type == "Ridge"
            and settings.show_line_overlay
            and settings.show_line_values
            and normalize_overlay_label_position(settings.line_value_position, settings.chart_type) == "Axis left"
        ):
            left_margin_in += max(settings.line_value_font_size, 1) * 3.0 / 72.0
        return left_margin_in

    def _rotated_axis_label_width_inches(self, text: str, font_size: int, pad: float = 0.30) -> float:
        return max(font_size, 1) / 72.0 * (self._line_count(text) + 0.9) + pad

    def _plot_right_margin_inches(self, settings: ChartSettings) -> float:
        right_margin_in = self._legend_right_margin_inches(settings) if self._legend_outside_needed(settings) else 0.20
        if self._custom_overlay_secondary_axis_active(settings) and settings.chart_type != "Ridge":
            right_margin_in += max(
                0.62,
                self._rotated_axis_label_width_inches(settings.secondary_y_label, settings.axis_label_font_size),
            )
        if (
            settings.chart_type == "Ridge"
            and settings.show_line_overlay
            and settings.show_line_values
            and normalize_overlay_label_position(settings.line_value_position, settings.chart_type) == "Axis right"
        ):
            right_margin_in += max(settings.line_value_font_size, 1) * 3.0 / 72.0
        return right_margin_in

    def _legend_outside_needed(self, settings: ChartSettings) -> bool:
        if settings.legend_position == LEGEND_POSITION_INSIDE:
            return False
        outlier_legend_needed = settings.show_outliers and (settings.chart_type != "Ridge" or settings.show_points)
        return bool(
            settings.show_legend
            and (
                outlier_legend_needed
                or settings.line_overlay_stat != "None"
                or settings.extra_custom_overlay
            )
        )

    def _legend_right_margin_inches(self, settings: ChartSettings) -> float:
        labels = self._legend_labels_for_settings(settings)
        legend_width_in = self._legend_render_width_inches(labels, settings) if labels else self._legend_total_width_inches(settings)
        return max(0.45, legend_width_in) + 0.50

    def _legend_render_width_inches(self, labels: list[str], settings: ChartSettings) -> float:
        if not labels:
            return self._legend_total_width_inches(settings)
        columns = self._legend_column_count(labels, settings)
        if self._legend_auto_width_enabled(settings):
            widest_item_width = max(
                (self._legend_unwrapped_item_width_inches(label, settings) for label in labels),
                default=self._legend_handle_space_inches(settings),
            )
            return widest_item_width * columns + self._legend_column_gap_inches(settings) * (columns - 1)
        force_wrap = self._legend_force_wrap(labels, settings)
        wrapped_labels = [
            self._legend_label_text(label, settings, columns, force_wrap=force_wrap)
            for label in labels
        ]
        item_widths = [
            self._legend_unwrapped_item_width_inches(label, settings)
            for label in wrapped_labels
        ]
        if columns <= 1:
            content_width = max(item_widths, default=self._legend_handle_space_inches(settings))
        else:
            widest_columns = sorted(item_widths, reverse=True)[:columns]
            content_width = sum(widest_columns) + self._legend_column_gap_inches(settings) * (len(widest_columns) - 1)
        return max(self._legend_total_width_inches(settings), content_width)

    def _legend_labels_for_settings(self, settings: ChartSettings) -> list[str]:
        if not settings.show_legend:
            return []
        labels = []
        if settings.show_outliers and (settings.chart_type != "Ridge" or settings.show_points):
            labels.append("Outlier")
        if settings.line_overlay_stat != "None":
            labels.append(settings.line_overlay_stat)
        if settings.extra_custom_overlay:
            for index in visible_custom_overlay_indexes(settings):
                name = ""
                if index < len(settings.custom_overlay_series):
                    name = str(settings.custom_overlay_series[index].get("name", "")).strip()
                labels.append(name or f"Overlay {index + 1}")
        return labels

    def _plot_top_margin_inches(self, settings: ChartSettings) -> float:
        title_height = max(settings.title_font_size, 1) / 72.0 * self._line_count(settings.title)
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        overlay_extra = 0.06 if settings.show_line_overlay and settings.show_line_values and line_value_position == "Top axis" else 0.0
        secondary_label_height = 0.0
        custom_overlay_secondary_axis_active = self._custom_overlay_secondary_axis_active(settings)
        if custom_overlay_secondary_axis_active and settings.chart_type == "Ridge":
            secondary_label_height = (
                max(settings.axis_label_font_size, 1) / 72.0 * self._line_count(settings.secondary_y_label) * 1.25
                if settings.secondary_y_label
                else 0.0
            )
        secondary_tick_height = max(settings.tick_font_size, 1) / 72.0 * 1.15 if custom_overlay_secondary_axis_active and settings.chart_type == "Ridge" else 0.0
        return 0.16 + title_height * 1.15 + overlay_extra + secondary_tick_height + secondary_label_height

    def _plot_bottom_margin_inches(self, settings: ChartSettings, groups: list[str], x_axis_label: str) -> float:
        tick_height = max(settings.tick_font_size, 1) / 72.0 * self._max_line_count(groups) * 1.15
        tick_width = self._max_text_width_inches(groups, settings.tick_font_size)
        x_tick_rotation = 0 if settings.chart_type == "Ridge" else settings.x_tick_rotation
        rotation = math.radians(abs(x_tick_rotation))
        rotated_tick_height = tick_width * math.sin(rotation) + tick_height * math.cos(rotation)
        label_height = max(settings.axis_label_font_size, 1) / 72.0 * self._line_count(x_axis_label) * 1.25 if x_axis_label else 0.0
        overlay_height = 0.0
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        if settings.show_line_overlay and settings.show_line_values and line_value_position == "Bottom axis":
            overlay_height = self._overlay_axis_label_margin_points(settings) / 72.0
        tick_pad = 0.10 if groups else 0.0
        label_pad = 0.08 if x_axis_label else 0.0
        return 0.12 + tick_pad + rotated_tick_height + label_pad + label_height + overlay_height

    def _rotated_value_axis_label_height_overflow_inches(
        self,
        y_axis_label: str,
        settings: ChartSettings,
        total_height_in: float,
        label_center_in: float,
    ) -> tuple[float, float]:
        if not y_axis_label:
            return (0.0, 0.0)
        label_height_in = self._max_text_width_inches([y_axis_label], settings.axis_label_font_size)
        if label_height_in <= 0.0:
            return (0.0, 0.0)
        pad_in = 0.12
        half_label_in = label_height_in / 2.0 + pad_in
        extra_bottom_in = max(0.0, half_label_in - label_center_in)
        extra_top_in = max(0.0, half_label_in - (total_height_in - label_center_in))
        return (extra_bottom_in, extra_top_in)

    def _horizontal_axis_label_width_overflow_inches(
        self,
        x_axis_label: str,
        settings: ChartSettings,
        total_width_in: float,
        label_center_in: float,
    ) -> tuple[float, float]:
        if not x_axis_label:
            return (0.0, 0.0)
        label_width_in = self._max_text_width_inches([x_axis_label], settings.axis_label_font_size)
        if label_width_in <= 0.0:
            return (0.0, 0.0)
        pad_in = 0.12
        half_label_in = label_width_in / 2.0 + pad_in
        extra_left_in = max(0.0, half_label_in - label_center_in)
        extra_right_in = max(0.0, half_label_in - (total_width_in - label_center_in))
        return (extra_left_in, extra_right_in)

    def _line_count(self, text: object) -> int:
        return max(1, str(text).count("\n") + 1)

    def _max_line_count(self, values: list[object]) -> int:
        return max([self._line_count(value) for value in values] or [1])

    def _max_text_width_inches(self, values: list[object], font_size: int) -> float:
        max_units = 0.0
        for value in values:
            for line in str(value).splitlines() or [""]:
                max_units = max(max_units, self._text_visual_units(line))
        return max_units * max(font_size, 1) * 0.52 / 72.0

    def _text_visual_units(self, text: str) -> float:
        return sum(2.0 if unicodedata.east_asian_width(char) in {"F", "W"} else 1.0 for char in text)

    def _jitter_offsets(self, values: np.ndarray, width: float, mode: str, key: str) -> np.ndarray:
        values = np.asarray(values, dtype=float)
        count = len(values)
        if count == 0 or width <= 0:
            return np.zeros(count)
        if mode == "Random":
            return self._random_offsets(key, count, width)
        if mode == "Quasirandom":
            return self._quasirandom_offsets(values, width)
        return self._beeswarm_offsets(values, width)

    def _random_offsets(self, key: str, count: int, width: float) -> np.ndarray:
        seed = 20240527 + sum(ord(ch) for ch in key)
        rng = np.random.default_rng(seed)
        return rng.uniform(-width, width, count)

    def _beeswarm_offsets(self, values: np.ndarray, width: float) -> np.ndarray:
        count = len(values)
        offsets = np.zeros(count)
        if count <= 1:
            return offsets

        finite = values[np.isfinite(values)]
        if len(finite) == 0:
            return offsets
        value_span = float(np.max(finite) - np.min(finite))
        bin_width = max(value_span / 24, 1e-9)
        bins = np.floor((values - float(np.min(finite))) / bin_width).astype(int)

        for bin_id in np.unique(bins):
            idx = np.where(bins == bin_id)[0]
            idx = idx[np.argsort(values[idx], kind="mergesort")]
            n = len(idx)
            if n == 1:
                offsets[idx[0]] = 0.0
                continue
            max_level = max(1, math.ceil((n - 1) / 2))
            step = width / max_level
            sequence = [0.0]
            for level in range(1, max_level + 1):
                sequence.extend([-level * step, level * step])
            offsets[idx] = np.array(sequence[:n])
        return np.clip(offsets, -width, width)

    def _quasirandom_offsets(self, values: np.ndarray, width: float) -> np.ndarray:
        count = len(values)
        if count <= 1:
            return np.zeros(count)

        order = np.argsort(values, kind="mergesort")
        base_offsets = np.array([self._van_der_corput(i + 1) for i in range(count)]) - 0.5
        base_offsets *= 2 * width

        density_scale = np.ones(count)
        finite = values[np.isfinite(values)]
        if len(finite) > 2 and not math.isclose(float(np.std(finite)), 0.0):
            try:
                kde = gaussian_kde(finite)
                density = kde(values)
                max_density = float(np.max(density))
                if max_density > 0:
                    density_scale = 0.25 + 0.75 * density / max_density
            except Exception:
                density_scale = np.ones(count)

        offsets = np.zeros(count)
        offsets[order] = base_offsets * density_scale[order]
        return np.clip(offsets, -width, width)

    def _van_der_corput(self, index: int, base: int = 2) -> float:
        result = 0.0
        denominator = 1.0
        while index:
            index, remainder = divmod(index, base)
            denominator *= base
            result += remainder / denominator
        return result

    def export(self, path: str, settings: ChartSettings) -> None:
        suffix = Path(path).suffix.lower()
        kwargs = {
            "dpi": settings.dpi,
            "facecolor": "none" if settings.transparent_background else self.figure.get_facecolor(),
            "bbox_inches": "tight",
            "transparent": settings.transparent_background,
        }
        if suffix in {".png", ".tif", ".tiff", ".jpg", ".jpeg", ".pdf", ".svg"}:
            self._savefig_without_interaction_feedback(path, **kwargs)

    def copy_to_clipboard(self, settings: ChartSettings) -> bool:
        buffer = BytesIO()
        self._savefig_without_interaction_feedback(
            buffer,
            format="png",
            dpi=settings.dpi,
            facecolor="none" if settings.transparent_background else self.figure.get_facecolor(),
            bbox_inches="tight",
            transparent=settings.transparent_background,
        )
        image = QImage()
        image.loadFromData(buffer.getvalue(), "PNG")
        if image.isNull():
            return False
        QApplication.clipboard().setImage(image)
        return True

    def _savefig_without_interaction_feedback(self, *args, **kwargs) -> None:
        patches = []
        for attribute in ("_hover_feedback_patch", "_selected_feedback_patch"):
            feedback = getattr(self, attribute, None)
            if feedback is None:
                continue
            if isinstance(feedback, (list, tuple)):
                patches.extend(feedback)
            else:
                patches.append(feedback)
        visibility = [(patch, patch.get_visible()) for patch in patches]
        try:
            for patch, _visible in visibility:
                patch.set_visible(False)
            self.figure.savefig(*args, **kwargs)
        finally:
            for patch, visible in visibility:
                patch.set_visible(visible)
            if visibility and self.canvas is not None:
                self.canvas.draw_idle()


def overlay_label_bbox(settings: ChartSettings) -> dict:
    preset = PRESETS[settings.preset]
    facecolor = "#FFFFFF" if preset["background"] == "#FFFFFF" else "#111827"
    edgecolor = "#D1D5DB" if preset["background"] == "#FFFFFF" else "#4B5563"
    return {
        "boxstyle": "round,pad=0.22",
        "facecolor": facecolor,
        "edgecolor": edgecolor,
        "alpha": 0.86,
        "linewidth": 0.55,
    }


def overlay_label_arrow(color: str) -> dict:
    return {
        "arrowstyle": "-",
        "color": color,
        "alpha": 0.65,
        "linewidth": 0.7,
        "shrinkA": 2,
        "shrinkB": 4,
    }


def overlay_line_style(style: str) -> str | tuple:
    return LINE_OVERLAY_STYLE_TO_MPL.get(style, "-")


def overlay_line_qt_pen_style(style: str) -> Qt.PenStyle:
    return LINE_OVERLAY_STYLE_TO_QT.get(style, Qt.PenStyle.SolidLine)


def draw_line_style_preview(painter: QPainter, style: str, color: QColor | str, left: float, right: float, y: float) -> None:
    line_color = QColor(color)
    if not line_color.isValid():
        line_color = QColor("#F9FAFB")
    pen = QPen(line_color)
    pen.setWidthF(LINE_STYLE_PREVIEW_STROKE_WIDTH)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)

    def draw_segment(start: float, end: float) -> None:
        painter.setPen(pen)
        painter.drawLine(start, y, min(end, right), y)

    def draw_dot(center: float) -> None:
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(line_color)
        painter.drawEllipse(
            center - LINE_STYLE_PREVIEW_DOT_RADIUS,
            y - LINE_STYLE_PREVIEW_DOT_RADIUS,
            LINE_STYLE_PREVIEW_DOT_RADIUS * 2,
            LINE_STYLE_PREVIEW_DOT_RADIUS * 2,
        )

    def draw_manual_pattern(pattern: tuple[str, ...]) -> None:
        x = left
        dash_lengths = {
            "dash": 22.0,
            "long_dash": 34.0,
            "dense_dash": 12.0,
        }
        gaps = {
            "dash": 8.0,
            "long_dash": 8.0,
            "dense_dash": 5.0,
            "dot": 8.0,
            "loose_dot": 14.0,
        }
        while x < right:
            for token in pattern:
                if token in dash_lengths:
                    draw_segment(x, x + dash_lengths[token])
                    x += dash_lengths[token] + gaps[token]
                elif token in {"dot", "loose_dot"}:
                    center = x + LINE_STYLE_PREVIEW_DOT_RADIUS
                    if center <= right - LINE_STYLE_PREVIEW_DOT_RADIUS:
                        draw_dot(center)
                    x = center + LINE_STYLE_PREVIEW_DOT_RADIUS + gaps[token]
                if x >= right:
                    break

    if style == "Auto":
        section_width = (right - left) / 3.0
        draw_line_style_preview(painter, "Solid", line_color, left, left + section_width - 6, y)
        draw_line_style_preview(painter, "Dashed", line_color, left + section_width, left + section_width * 2 - 6, y)
        draw_line_style_preview(painter, "Dotted", line_color, left + section_width * 2, right, y)
        return
    if style == "Dotted":
        draw_manual_pattern(("dot",))
        return
    if style == "Dash-dot":
        draw_manual_pattern(("dash", "dot"))
        return
    if style == "Long dash":
        draw_manual_pattern(("long_dash",))
        return
    if style == "Dense dash":
        draw_manual_pattern(("dense_dash",))
        return
    if style == "Loose dot":
        draw_manual_pattern(("loose_dot",))
        return
    if style == "Dash-dot-dot":
        draw_manual_pattern(("dash", "dot", "dot"))
        return

    pen.setStyle(overlay_line_qt_pen_style(style))
    painter.setPen(pen)
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.drawLine(left, y, right, y)


def line_style_icon(style: str, color: QColor | str) -> QIcon:
    icon = QIcon()
    line_color = QColor(color)
    if not line_color.isValid():
        line_color = QColor("#F9FAFB")
    for ratio in LINE_STYLE_ICON_DEVICE_RATIOS:
        pixmap = QPixmap(LINE_STYLE_ICON_SIZE.width() * ratio, LINE_STYLE_ICON_SIZE.height() * ratio)
        pixmap.setDevicePixelRatio(ratio)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            y = LINE_STYLE_ICON_SIZE.height() / 2
            draw_line_style_preview(painter, style, line_color, 10, LINE_STYLE_ICON_SIZE.width() - 10, y)
        finally:
            painter.end()
        icon.addPixmap(pixmap)
    return icon


def overlay_label_position_for_series(settings: ChartSettings, is_custom_overlay: bool) -> str:
    position = settings.custom_line_value_position if is_custom_overlay else settings.line_value_position
    return normalize_overlay_label_position(position, settings.chart_type, is_custom_overlay)


def overlay_auto_avoidance_position(settings: ChartSettings, is_custom_overlay: bool) -> str | None:
    if not is_custom_overlay or settings.line_overlay_stat == "None":
        return None
    stat_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
    if settings.chart_type == "Ridge":
        if stat_position == "Axis left":
            return "Right"
        if stat_position == "Axis right":
            return "Left"
    else:
        if stat_position == "Bottom axis":
            return "Above"
        if stat_position == "Top axis":
            return "Below"
    return None


def normalize_overlay_label_position(position: str, chart_type: str, is_custom_overlay: bool = False) -> str:
    point_positions = {"Auto", "Above", "Below", "Left", "Right"}
    if is_custom_overlay:
        return position if position in point_positions else "Auto"
    axis_positions = {"Axis left", "Axis right"} if chart_type == "Ridge" else {"Top axis", "Bottom axis"}
    valid_positions = point_positions | axis_positions
    if position in valid_positions:
        return position
    if chart_type == "Ridge" and position == "Top axis":
        return "Axis right"
    if chart_type == "Ridge" and position == "Bottom axis":
        return "Axis left"
    if chart_type != "Ridge" and position == "Axis right":
        return "Top axis"
    if chart_type != "Ridge" and position == "Axis left":
        return "Bottom axis"
    return "Auto"


def resolve_overlay_label_position(
    index: int,
    values: list[float],
    position: str,
    is_ridge: bool,
    series_index: int = 0,
    preferred_auto_position: str | None = None,
) -> str:
    point_positions = {"Above", "Below", "Left", "Right"}
    if position != "Auto":
        return position
    if preferred_auto_position in point_positions:
        return preferred_auto_position

    crowded = overlay_values_are_close(index, values)
    if is_ridge:
        prefer_right = (series_index + (1 if crowded and index % 2 else 0)) % 2 == 0
        return "Right" if prefer_right else "Left"
    prefer_above = (series_index + (1 if crowded and index % 2 else 0)) % 2 == 0
    return "Above" if prefer_above else "Below"


def overlay_label_offset(
    index: int,
    values: list[float],
    position: str,
    is_ridge: bool,
    series_index: int = 0,
    marker_size_points: float = 0.0,
) -> tuple[int, int, str, str]:
    position = resolve_overlay_label_position(index, values, position, is_ridge, series_index)

    stagger = max(series_index, 0) * 8
    side_gap = int(max(12, marker_size_points / 2.0 + 6))
    vertical_gap = int(max(13, marker_size_points / 2.0 + 6))

    if position == "Below":
        return (stagger, -vertical_gap, "center", "top")
    if position == "Left":
        return (-side_gap, -stagger, "right", "center")
    if position == "Right":
        return (side_gap, stagger, "left", "center")
    return (stagger, vertical_gap, "center", "bottom")


def overlay_values_are_close(index: int, values: list[float]) -> bool:
    if len(values) < 2:
        return False
    value_range = max(values) - min(values)
    threshold = max(value_range * 0.08, 1e-9)
    value = values[index]
    neighbors = []
    if index > 0:
        neighbors.append(values[index - 1])
    if index + 1 < len(values):
        neighbors.append(values[index + 1])
    return any(abs(value - neighbor) <= threshold for neighbor in neighbors)
