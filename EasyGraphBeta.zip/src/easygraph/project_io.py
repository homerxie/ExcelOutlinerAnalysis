from __future__ import annotations

import json
import tempfile
import zipfile
from dataclasses import asdict, fields
from pathlib import Path

import pandas as pd

from easygraph.settings import ChartSettings

__all__ = ["chart_settings_from_dict", "read_project", "write_project"]


def chart_settings_from_dict(data):
    if not isinstance(data, dict):
        raise ValueError("Chart settings must be a dictionary.")
    current_fields = {field.name for field in fields(ChartSettings)}
    unknown_fields = sorted(str(key) for key in data if key not in current_fields)
    if unknown_fields:
        raise ValueError("Unknown ChartSettings fields: " + ", ".join(unknown_fields))
    return ChartSettings(**data)


def write_project(path: Path, df: pd.DataFrame, settings: ChartSettings) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        df.to_csv(tmp_path / "data.csv", index=False)
        (tmp_path / "settings.json").write_text(
            json.dumps(asdict(settings), indent=2),
            encoding="utf-8",
        )
        (tmp_path / "project.json").write_text(
            json.dumps({"version": 1, "app": "EasyGraph"}, indent=2),
            encoding="utf-8",
        )
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for file in tmp_path.iterdir():
                archive.write(file, arcname=file.name)


def read_project(path: Path) -> tuple[pd.DataFrame, ChartSettings]:
    with zipfile.ZipFile(path, "r") as archive:
        with archive.open("data.csv") as data_file:
            df = pd.read_csv(data_file)
        settings_data = json.loads(archive.read("settings.json").decode("utf-8"))
    return df, chart_settings_from_dict(settings_data)
