from __future__ import annotations

import math

import numpy as np
import pandas as pd

from easygraph.settings import ChartSettings

__all__ = [
    "axis_labels_for_chart",
    "blank_project_data",
    "box_whis",
    "hidden_group_names",
    "mark_outliers",
    "ordered_group_columns",
    "prepare_plot_data",
    "sample_data",
    "unique_groups",
    "values_for_group",
]


def sample_data() -> pd.DataFrame:
    rng = np.random.default_rng(7)
    columns = {}
    for group, center, spread in [
        ("Control", 4.8, 0.55),
        ("Low dose", 5.6, 0.65),
        ("High dose", 6.4, 0.7),
    ]:
        values = [round(float(v), 3) for v in rng.normal(center, spread, 34)]
        if group == "High dose":
            values.append(8.7)
        columns[group] = values
    return pd.DataFrame({name: pd.Series(values) for name, values in columns.items()})


def blank_project_data(rows: int = 12, columns: int = 3) -> pd.DataFrame:
    return pd.DataFrame(
        [["" for _ in range(columns)] for _ in range(rows)],
        columns=[f"Group {col + 1}" for col in range(columns)],
    )


def prepare_plot_data(df: pd.DataFrame, settings: ChartSettings, include_hidden: bool = False) -> pd.DataFrame:
    rows = []
    for column in ordered_group_columns(df, settings):
        if not include_hidden and str(column) in hidden_group_names(settings):
            continue
        values = values_for_group(df, column)
        for value in values:
            rows.append({settings.group_col: str(column), settings.value_col: float(value)})
    return pd.DataFrame(rows, columns=[settings.group_col, settings.value_col])


def hidden_group_names(settings: ChartSettings) -> set[str]:
    return {str(group) for group in settings.group_hidden}


def unique_groups(columns) -> list:
    groups = []
    for column in columns:
        if column not in groups:
            groups.append(column)
    return groups


def values_for_group(df: pd.DataFrame, group) -> pd.Series:
    matching_indices = [idx for idx, column in enumerate(df.columns) if column == group]
    if not matching_indices:
        return pd.Series(dtype=float)
    parts = [
        pd.to_numeric(df.iloc[:, idx], errors="coerce").dropna()
        for idx in matching_indices
    ]
    return pd.concat(parts, ignore_index=True) if parts else pd.Series(dtype=float)


def ordered_group_columns(df: pd.DataFrame, settings: ChartSettings) -> list:
    columns = unique_groups(df.columns)
    if settings.group_order == "Manual":
        ordered = [group for group in settings.manual_group_order if group in columns]
        ordered.extend(group for group in columns if group not in ordered)
        return ordered
    if settings.group_order == "Name A-Z":
        return sorted(columns, key=lambda column: str(column).lower())
    if settings.group_order == "Name Z-A":
        return sorted(columns, key=lambda column: str(column).lower(), reverse=True)
    if settings.group_order in {
        "Mean ascending",
        "Mean descending",
        "Median ascending",
        "Median descending",
    }:
        use_median = settings.group_order.startswith("Median")
        descending = settings.group_order.endswith("descending")

        def sort_key(column):
            values = values_for_group(df, column)
            if values.empty:
                stat = math.inf if not descending else -math.inf
            else:
                stat = float(values.median() if use_median else values.mean())
            return (stat, str(column).lower())

        return sorted(columns, key=sort_key, reverse=descending)
    return columns


def box_whis(mode: str):
    if mode == "Min-Max":
        return (0, 100)
    if mode == "Percentile 5-95":
        return (5, 95)
    if mode == "Percentile 10-90":
        return (10, 90)
    return 1.5


def axis_labels_for_chart(settings: ChartSettings) -> tuple[str, str]:
    group_label = settings.x_label
    value_label = settings.y_label
    if settings.chart_type == "Ridge":
        return value_label, group_label
    return group_label, value_label


def mark_outliers(df: pd.DataFrame, settings: ChartSettings) -> pd.DataFrame:
    outlier_parts = []
    for _, group_df in df.groupby(settings.group_col):
        values = group_df[settings.value_col]
        if len(values) < 3:
            continue
        if settings.outlier_method == "IQR":
            q1, q3 = values.quantile([0.25, 0.75])
            iqr = q3 - q1
            low = q1 - settings.outlier_threshold * iqr
            high = q3 + settings.outlier_threshold * iqr
            mask = (values < low) | (values > high)
        elif settings.outlier_method == "Z-score":
            std = values.std(ddof=0)
            mask = pd.Series(False, index=values.index) if std == 0 else ((values - values.mean()).abs() / std > settings.outlier_threshold)
        elif settings.outlier_method == "MAD":
            median = values.median()
            mad = (values - median).abs().median()
            mask = pd.Series(False, index=values.index) if mad == 0 else (0.6745 * (values - median).abs() / mad > settings.outlier_threshold)
        else:
            pct = settings.outlier_threshold
            low = values.quantile(max(0.0, pct / 100.0))
            high = values.quantile(min(1.0, 1.0 - pct / 100.0))
            mask = (values < low) | (values > high)
        outlier_parts.append(group_df[mask])
    return pd.concat(outlier_parts) if outlier_parts else pd.DataFrame(columns=df.columns)
