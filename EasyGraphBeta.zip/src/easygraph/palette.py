from __future__ import annotations

import json
import math
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from PySide6.QtGui import QColor

from easygraph.settings import ChartSettings, PRESETS, SEQUENTIAL_PALETTE_PRESETS


PRECOMPUTED_PALETTE_COUNT = 100
PRECOMPUTED_PALETTE_PATH = Path(__file__).resolve().parents[1] / "palette_cache.json"

__all__ = [
    "PRECOMPUTED_PALETTE_COUNT",
    "PRECOMPUTED_PALETTE_PATH",
    "blend_qcolors",
    "derived_group_color",
    "expanded_preset_palette",
    "first_unused_palette_color",
    "group_color_map_for_groups",
    "normalize_color_name",
    "palette_choices_for_group_count",
    "palette_for",
]


def palette_for(df: pd.DataFrame, settings: ChartSettings, color_groups: list | None = None) -> list[str]:
    groups = list(df[settings.group_col].dropna().unique()) if not df.empty else []
    color_map = group_color_map_for_groups(color_groups if color_groups is not None else groups, settings)
    colors = [color_map[str(group)] for group in groups if str(group) in color_map]
    return colors or expanded_preset_palette(settings.preset, max(len(groups), 1))


def group_color_map_for_groups(
    groups: list,
    settings: ChartSettings,
    custom_colors: dict[str, str] | None = None,
    preset_name: str | None = None,
) -> dict[str, str]:
    custom_colors = settings.custom_colors if custom_colors is None else custom_colors
    preset_name = settings.preset if preset_name is None else preset_name
    base = expanded_preset_palette(preset_name, len(groups) + len(custom_colors) + 4)
    group_keys = {str(item) for item in groups}
    used_colors = {
        normalize_color_name(color)
        for group, color in custom_colors.items()
        if str(group) in group_keys and QColor(color).isValid()
    }
    color_map = {}
    for group in groups:
        key = str(group)
        custom_color = custom_colors.get(key)
        if custom_color is not None and QColor(custom_color).isValid():
            color_map[key] = QColor(custom_color).name()
            continue
        color = first_unused_palette_color(base, used_colors)
        color_map[key] = color
        used_colors.add(normalize_color_name(color))
    return color_map


def normalize_color_name(color: str) -> str:
    qcolor = QColor(color)
    return qcolor.name() if qcolor.isValid() else str(color).lower()


def first_unused_palette_color(palette: list[str], used_colors: set[str]) -> str:
    for color in palette:
        normalized = normalize_color_name(color)
        if normalized not in used_colors:
            return normalized
    for color in palette:
        qcolor = QColor(color)
        if qcolor.isValid():
            return qcolor.name()
    return "#000000"


def palette_choices_for_group_count(preset_name: str, group_count: int) -> list[str]:
    max_core_count = max(len(preset["palette"]) for preset in PRESETS.values())
    target_count = max(max_core_count, group_count + 4)
    return expanded_preset_palette(preset_name, target_count)


def expanded_preset_palette(preset_name: str, count: int) -> list[str]:
    precomputed = _precomputed_palette_for(preset_name, count)
    if precomputed is not None:
        return list(precomputed)
    return list(_expanded_preset_palette_cached(preset_name, count))


def _precomputed_palette_for(preset_name: str, count: int) -> tuple[str, ...] | None:
    if count <= 0 or count > PRECOMPUTED_PALETTE_COUNT:
        return None
    colors = _precomputed_palette_cache().get(preset_name)
    if colors is None or len(colors) < count:
        return None
    preset = PRESETS.get(preset_name)
    if preset is None:
        return None
    base = tuple(QColor(color).name() for color in preset["palette"] if QColor(color).isValid())
    if colors[:len(base)] != base:
        return None
    return colors[:count]


@lru_cache(maxsize=1)
def _precomputed_palette_cache() -> dict[str, tuple[str, ...]]:
    try:
        raw_data = json.loads(PRECOMPUTED_PALETTE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    cache: dict[str, tuple[str, ...]] = {}
    if not isinstance(raw_data, dict):
        return cache
    for preset_name, colors in raw_data.items():
        if not isinstance(preset_name, str) or not isinstance(colors, list):
            continue
        normalized = tuple(
            QColor(color).name()
            for color in colors
            if isinstance(color, str) and QColor(color).isValid()
        )
        if normalized:
            cache[preset_name] = normalized
    return cache


@lru_cache(maxsize=256)
def _expanded_preset_palette_cached(preset_name: str, count: int) -> tuple[str, ...]:
    preset = PRESETS[preset_name]
    base = [QColor(color).name() for color in preset["palette"] if QColor(color).isValid()]
    if count <= 0:
        return tuple(base)
    if count <= len(base):
        return tuple(base[:count])
    if _palette_is_monochrome(base):
        return tuple(_expanded_monochrome_palette(base, count, preset["background"]))
    if preset_name in SEQUENTIAL_PALETTE_PRESETS:
        return tuple(_resampled_sequential_palette(base, count))

    colors = list(base)
    candidates = _style_matched_palette_candidates(base, preset["background"], count)
    _append_farthest_lab_colors(colors, candidates, count)

    attempts = 0
    while len(colors) < count:
        attempts += 1
        candidates = _style_matched_palette_candidates(base, preset["background"], count + attempts * 8)
        candidates = [color for color in candidates if color not in colors]
        if not candidates:
            break
        _append_farthest_lab_colors(colors, candidates, count)
    return tuple(colors[:count])


def _append_farthest_lab_colors(colors: list[str], candidates: list[str], count: int) -> None:
    if not candidates:
        return
    selected_labs = [_qcolor_to_lab(QColor(color)) for color in colors]
    candidate_labs = {color: _qcolor_to_lab(QColor(color)) for color in candidates}
    min_distances = {
        color: min(_lab_distance(candidate_labs[color], selected_lab) for selected_lab in selected_labs)
        for color in candidates
    }

    while len(colors) < count and candidates:
        selected = max(candidates, key=lambda color: min_distances[color])
        selected_lab = candidate_labs[selected]
        colors.append(selected)
        candidates.remove(selected)
        min_distances.pop(selected, None)
        for candidate in candidates:
            min_distances[candidate] = min(min_distances[candidate], _lab_distance(candidate_labs[candidate], selected_lab))


def _style_matched_palette_candidates(base: list[str], background: str, count: int) -> list[str]:
    lightness_values: list[float] = []
    saturation_values: list[float] = []
    hue_values: list[float] = []
    for color in base:
        hue, saturation, lightness, _alpha = QColor(color).getHslF()
        if hue >= 0:
            hue_values.append(hue)
        saturation_values.append(saturation)
        lightness_values.append(lightness)

    saturation = float(np.median(saturation_values)) if saturation_values else 0.62
    lightness = float(np.median(lightness_values)) if lightness_values else 0.48
    saturation_low = max(saturation - 0.08, 0.36)
    saturation_high = min(saturation + 0.08, 0.78)
    if background == "#FFFFFF":
        lightness_low = max(lightness - 0.08, 0.36)
        lightness_high = min(lightness + 0.08, 0.62)
    else:
        lightness_low = max(lightness - 0.08, 0.52)
        lightness_high = min(lightness + 0.08, 0.76)

    start_hue = float(np.median(hue_values)) if hue_values else 0.0
    golden_angle = 0.618033988749895
    candidate_count = max(240, min(500, count * 36))
    background_color = QColor(background)
    minimum_contrast = 1.45 if background == "#FFFFFF" else 2.0

    candidates: list[str] = []
    seen = set(base)
    attempts = 0
    while len(candidates) < candidate_count and attempts < candidate_count * 6:
        attempts += 1
        hue = (start_hue + attempts * golden_angle) % 1.0
        saturation_phase = ((attempts * 37) % 101) / 100
        lightness_phase = ((attempts * 53) % 101) / 100
        sat = saturation_low + (saturation_high - saturation_low) * saturation_phase
        light = lightness_low + (lightness_high - lightness_low) * lightness_phase
        candidate = QColor.fromHslF(hue, sat, light).name()
        if candidate in seen:
            continue
        if background_color.isValid() and _contrast_ratio(candidate, background) < minimum_contrast:
            continue
        seen.add(candidate)
        candidates.append(candidate)
    return candidates


def _resampled_sequential_palette(base: list[str], count: int) -> list[str]:
    if not base or count <= 0:
        return []
    if count == 1 or len(base) == 1:
        return [base[0]]

    qcolors = [QColor(color) for color in base]
    colors: list[str] = []
    for index in range(count):
        position = index * (len(qcolors) - 1) / (count - 1)
        lower = int(math.floor(position))
        upper = min(lower + 1, len(qcolors) - 1)
        fraction = position - lower
        red = round(qcolors[lower].red() * (1 - fraction) + qcolors[upper].red() * fraction)
        green = round(qcolors[lower].green() * (1 - fraction) + qcolors[upper].green() * fraction)
        blue = round(qcolors[lower].blue() * (1 - fraction) + qcolors[upper].blue() * fraction)
        candidate = QColor(red, green, blue).name()
        if candidate not in colors:
            colors.append(candidate)

    if len(colors) < count:
        return colors + [color for color in base if color not in colors][:count - len(colors)]
    return colors[:count]


def _palette_is_monochrome(colors: list[str]) -> bool:
    for color in colors:
        qcolor = QColor(color)
        if max(qcolor.red(), qcolor.green(), qcolor.blue()) - min(qcolor.red(), qcolor.green(), qcolor.blue()) > 2:
            return False
    return True


def _expanded_monochrome_palette(base: list[str], count: int, background: str) -> list[str]:
    colors = list(base)
    lower, upper = (18, 214) if background == "#FFFFFF" else (58, 248)
    candidate_values = list(range(lower, upper + 1))

    def gray_value(color: str) -> int:
        return QColor(color).red()

    while len(colors) < count and candidate_values:
        existing_values = [gray_value(color) for color in colors]
        selected = max(candidate_values, key=lambda value: min(abs(value - existing) for existing in existing_values))
        candidate_values.remove(selected)
        candidate = QColor(selected, selected, selected).name()
        if candidate not in colors:
            colors.append(candidate)
    return colors[:count]


def _minimum_lab_distance(color: str, existing_colors: list[str]) -> float:
    candidate = _qcolor_to_lab(QColor(color))
    distances = []
    for existing in existing_colors:
        current = _qcolor_to_lab(QColor(existing))
        distances.append(_lab_distance(candidate, current))
    return min(distances) if distances else math.inf


def _lab_distance(first: tuple[float, float, float], second: tuple[float, float, float]) -> float:
    return math.sqrt(
        (first[0] - second[0]) ** 2
        + (first[1] - second[1]) ** 2
        + (first[2] - second[2]) ** 2
    )


def _qcolor_to_lab(color: QColor) -> tuple[float, float, float]:
    def linearize(value: float) -> float:
        value = value / 255
        if value <= 0.04045:
            return value / 12.92
        return ((value + 0.055) / 1.055) ** 2.4

    red = linearize(color.red())
    green = linearize(color.green())
    blue = linearize(color.blue())
    x = red * 0.4124564 + green * 0.3575761 + blue * 0.1804375
    y = red * 0.2126729 + green * 0.7151522 + blue * 0.0721750
    z = red * 0.0193339 + green * 0.1191920 + blue * 0.9503041
    x /= 0.95047
    z /= 1.08883

    def pivot(value: float) -> float:
        if value > 0.008856:
            return value ** (1 / 3)
        return 7.787 * value + 16 / 116

    fx = pivot(x)
    fy = pivot(y)
    fz = pivot(z)
    return (
        116 * fy - 16,
        500 * (fx - fy),
        200 * (fy - fz),
    )


def _contrast_ratio(color: str, background: str) -> float:
    foreground_luminance = _relative_luminance(QColor(color))
    background_luminance = _relative_luminance(QColor(background))
    lighter = max(foreground_luminance, background_luminance)
    darker = min(foreground_luminance, background_luminance)
    return (lighter + 0.05) / (darker + 0.05)


def _relative_luminance(color: QColor) -> float:
    def channel(value: int) -> float:
        value = value / 255
        if value <= 0.03928:
            return value / 12.92
        return ((value + 0.055) / 1.055) ** 2.4

    return 0.2126 * channel(color.red()) + 0.7152 * channel(color.green()) + 0.0722 * channel(color.blue())


def blend_qcolors(base: QColor, overlay: QColor, amount: float) -> QColor:
    amount = max(0.0, min(float(amount), 1.0))
    inverse = 1.0 - amount
    return QColor(
        round(base.red() * inverse + overlay.red() * amount),
        round(base.green() * inverse + overlay.green() * amount),
        round(base.blue() * inverse + overlay.blue() * amount),
    )


def derived_group_color(color: str, role: str, background: str = "#FFFFFF") -> str:
    qcolor = QColor(color)
    if not qcolor.isValid():
        return color
    if role == "edge":
        return qcolor.darker(145).name()
    if role == "point":
        return qcolor.lighter(108 if background == "#FFFFFF" else 125).name()
    return qcolor.name()
