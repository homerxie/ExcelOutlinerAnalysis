# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'group_order_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QDialog,
    QDialogButtonBox, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_GroupOrderDialog(object):
    def setupUi(self, GroupOrderDialog):
        if not GroupOrderDialog.objectName():
            GroupOrderDialog.setObjectName(u"GroupOrderDialog")
        GroupOrderDialog.setModal(True)
        self.verticalLayout = QVBoxLayout(GroupOrderDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.hintLabel = QLabel(GroupOrderDialog)
        self.hintLabel.setObjectName(u"hintLabel")

        self.verticalLayout.addWidget(self.hintLabel)

        self.groupList = QListWidget(GroupOrderDialog)
        self.groupList.setObjectName(u"groupList")
        self.groupList.setDragDropMode(QAbstractItemView.InternalMove)
        self.groupList.setDefaultDropAction(Qt.MoveAction)
        self.groupList.setSelectionMode(QAbstractItemView.SingleSelection)

        self.verticalLayout.addWidget(self.groupList)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.tableOrderButton = QPushButton(GroupOrderDialog)
        self.tableOrderButton.setObjectName(u"tableOrderButton")

        self.buttonLayout.addWidget(self.tableOrderButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonLayout.addItem(self.horizontalSpacer)

        self.buttonBox = QDialogButtonBox(GroupOrderDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.buttonLayout.addWidget(self.buttonBox)


        self.verticalLayout.addLayout(self.buttonLayout)


        self.retranslateUi(GroupOrderDialog)
        self.buttonBox.accepted.connect(GroupOrderDialog.accept)
        self.buttonBox.rejected.connect(GroupOrderDialog.reject)

        QMetaObject.connectSlotsByName(GroupOrderDialog)
    # setupUi

    def retranslateUi(self, GroupOrderDialog):
        GroupOrderDialog.setWindowTitle(QCoreApplication.translate("GroupOrderDialog", u"Edit Group Order", None))
        self.hintLabel.setText(QCoreApplication.translate("GroupOrderDialog", u"Drag groups to change plot order.", None))
        self.tableOrderButton.setText(QCoreApplication.translate("GroupOrderDialog", u"Table Order", None))
    # retranslateUi

