from __future__ import annotations

import math
import os
import csv
import re
import tempfile
import unicodedata
from copy import deepcopy
from enum import Enum
from io import BytesIO, StringIO
from dataclasses import asdict
from pathlib import Path

os.environ.setdefault(
    "MPLCONFIGDIR",
    str(Path(tempfile.gettempdir()) / "easygraph_matplotlib"),
)
Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import font_manager, rcParams
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.collections import PathCollection
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle
from matplotlib.ticker import AutoLocator, MultipleLocator
from matplotlib.transforms import Bbox
from scipy.stats import gaussian_kde
try:
    import qdarktheme
except ImportError:
    qdarktheme = None

from PySide6.QtCore import QEvent, QLocale, QSettings, QSize, Qt, QTimer, QTranslator
from PySide6.QtGui import QAction, QBrush, QColor, QFont, QIcon, QImage, QKeyEvent, QKeySequence, QPainter, QPalette, QPen, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QAbstractSpinBox,
    QApplication,
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QScrollArea,
    QStyle,
    QStyleOptionSpinBox,
    QStyledItemDelegate,
    QStyleOptionViewItem,
    QTableWidgetSelectionRange,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from easygraph.settings import (
    ChartSettings,
    DEFAULT_OVERLAY_PALETTE,
    GROUP_COLOR_TEMPLATE_KEY_PREFIX,
    LEGEND_INSIDE_AUTO_POSITION,
    LEGEND_POSITION_INSIDE,
    LEGEND_POSITION_RIGHT,
    LINE_OVERLAY_RENDER_STYLES,
    LINE_OVERLAY_STYLES,
    PRESETS,
    SEQUENTIAL_PALETTE_PRESETS,
    STAT_TABLE_OPTIONS,
    STYLE_TEMPLATE_CONTENT_FIELDS,
)
from easygraph.project_io import chart_settings_from_dict, read_project, write_project
from easygraph.spreadsheet_io import (
    OVERLAY_EXPORT_CUSTOM_ROW,
    OVERLAY_EXPORT_NAME_COLUMN,
    OVERLAY_EXPORT_ROW_TYPE_COLUMN,
    OVERLAY_EXPORT_SAMPLE_ROW,
    excel_export_dataframe,
    excel_import_parts,
    read_spreadsheet,
    write_spreadsheet,
)
from easygraph.template_io import (
    TEMPLATE_DIR,
    TEMPLATE_NONE_NAME,
    apply_style_template_settings,
    group_colors_for_target_groups,
    import_style_template,
    indexed_group_colors_from_settings,
    list_style_templates,
    read_style_template,
    read_style_template_file,
    style_template_settings_data,
    template_file_name,
    template_indexed_group_colors,
    write_style_template,
)
from easygraph.palette import (
    PRECOMPUTED_PALETTE_COUNT,
    PRECOMPUTED_PALETTE_PATH,
    _append_farthest_lab_colors,
    _contrast_ratio,
    _expanded_monochrome_palette,
    _expanded_preset_palette_cached,
    _lab_distance,
    _minimum_lab_distance,
    _palette_is_monochrome,
    _precomputed_palette_cache,
    _precomputed_palette_for,
    _qcolor_to_lab,
    _relative_luminance,
    _resampled_sequential_palette,
    _style_matched_palette_candidates,
    blend_qcolors,
    derived_group_color,
    expanded_preset_palette,
    first_unused_palette_color,
    group_color_map_for_groups,
    normalize_color_name,
    palette_choices_for_group_count,
    palette_for,
)
from easygraph.data import (
    axis_labels_for_chart,
    blank_project_data,
    box_whis,
    hidden_group_names,
    mark_outliers,
    ordered_group_columns,
    prepare_plot_data,
    sample_data,
    unique_groups,
    values_for_group,
)
from easygraph.overlay_series import (
    line_overlay_series,
    visible_custom_overlay_indexes,
    all_custom_overlay_indexes,
    overlay_palette_for,
    stat_overlay_color,
    default_overlay_color,
    overlay_color_map_for_series,
    overlay_color_map_for_keys,
    all_overlay_color_keys,
    overlay_palette_slot_for_color_key,
    overlay_color_items,
    overlay_style_items,
    overlay_stat_color_key,
    overlay_custom_color_key,
    group_overlay_statistics,
    stat_table_header_required,
    stat_table_header_enabled,
    stat_table_data,
    format_overlay_value,
    custom_overlay_style_for_key,
    auto_overlay_style,
    overlay_style_for_series,
)

from easygraph.plotting.canvas import (
    AUTO_AXIS_RANGE_PADDING_FRACTION,
    CoordinatesToolbar,
    LEGEND_COLUMN_SPACING,
    LEGEND_HANDLE_LENGTH,
    LEGEND_HANDLE_SPACE_UNITS,
    LEGEND_MAX_COLUMNS,
    LEGEND_SECONDARY_AXIS_GAP_PX,
    LINE_OVERLAY_STYLE_TO_MPL,
    LINE_OVERLAY_STYLE_TO_QT,
    LINE_STYLE_ICON_DEVICE_RATIOS,
    LINE_STYLE_ICON_SIZE,
    LINE_STYLE_POPUP_PREVIEW_WIDTH,
    LINE_STYLE_POPUP_ROW_HEIGHT,
    LINE_STYLE_PREVIEW_DOT_RADIUS,
    LINE_STYLE_PREVIEW_STROKE_WIDTH,
    MAX_MANUAL_TICK_COUNT,
    OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS,
    OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO,
    OVERLAY_CONTENT_MARGIN_RATIO,
    PlotCanvas,
    STAT_OVERLAY_ALPHA,
    ScrollFriendlyFigureCanvas,
    draw_line_style_preview,
    line_style_icon,
    normalize_overlay_label_position,
    overlay_auto_avoidance_position,
    overlay_label_arrow,
    overlay_label_bbox,
    overlay_label_offset,
    overlay_label_position_for_series,
    overlay_line_qt_pen_style,
    overlay_line_style,
    overlay_values_are_close,
    resolve_overlay_label_position,
)


def configure_matplotlib_fonts() -> str:
    candidates = [
        "Microsoft YaHei",
        "SimHei",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "PingFang SC",
        "Heiti SC",
        "Hiragino Sans GB",
        "Songti SC",
        "Arial Unicode MS",
        "WenQuanYi Micro Hei",
        "DejaVu Sans",
    ]
    available = {font.name for font in font_manager.fontManager.ttflist}
    selected = next((name for name in candidates if name in available), "DejaVu Sans")
    rcParams["font.family"] = "sans-serif"
    rcParams["font.sans-serif"] = [selected] + [name for name in candidates if name != selected]
    rcParams["axes.unicode_minus"] = False
    return selected


DEFAULT_FONT_FAMILY = configure_matplotlib_fonts()
APP_DIR = Path(__file__).resolve().parents[1]
TRANSLATION_DIR = APP_DIR / "translations"
LANGUAGE_ENV_VAR = "EASYGRAPH_LANGUAGE"
LANGUAGE_SETTING_KEY = "language"
RECENT_PROJECTS_SETTING_KEY = "recentProjects"
MAX_RECENT_PROJECTS = 10
APP_CONTROL_HEIGHT = 26
COMBO_TEXT_WIDTH_PADDING = 55
COMBO_MIN_WIDTH = 96
COMPACT_SPIN_TEXT_PADDING = 12
APP_RENDER_DEBOUNCE_MS = 150
OFFICE_FONT_SIZE_STEPS = [5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 60, 72]
APP_THEME_OVERRIDES = """
QComboBox,
QSpinBox,
QDoubleSpinBox,
QPushButton {
    border-radius: 6px;
    min-height: 20px;
    max-height: 20px;
}

QComboBox {
    padding: 2px 20px 2px 10px;
}

QSpinBox,
QDoubleSpinBox {
    padding: 2px 18px 2px 8px;
}

QPushButton {
    padding: 2px 10px;
}

QComboBox::drop-down {
    width: 16px;
    border-top-right-radius: 6px;
    border-bottom-right-radius: 6px;
}

QComboBox QAbstractItemView {
    border-radius: 6px;
    padding: 4px;
    outline: 0;
}

QMenu {
    border-radius: 6px;
    padding: 4px;
}

QMenu::item {
    border-radius: 4px;
    padding: 4px 20px;
}
"""
COMPACT_SPIN_STYLE = """
QSpinBox {
    padding: 2px 0 2px 6px;
}

QSpinBox::up-button {
    subcontrol-origin: border;
    subcontrol-position: top right;
    width: 18px;
}

QSpinBox::down-button {
    subcontrol-origin: border;
    subcontrol-position: bottom right;
    width: 18px;
}

QDoubleSpinBox {
    padding: 2px 0 2px 6px;
}

QDoubleSpinBox::up-button {
    subcontrol-origin: border;
    subcontrol-position: top right;
    width: 18px;
}

QDoubleSpinBox::down-button {
    subcontrol-origin: border;
    subcontrol-position: bottom right;
    width: 18px;
}
"""


class RenderMode(Enum):
    FULL = "full"
    TEXT_ONLY = "text_only"


class LineStyleItemDelegate(QStyledItemDelegate):
    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index) -> None:
        style_name = str(index.data(Qt.ItemDataRole.DisplayRole) or "")
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        opt.text = ""
        opt.icon = QIcon()
        widget_style = opt.widget.style() if opt.widget is not None else QApplication.style()
        widget_style.drawControl(QStyle.ControlElement.CE_ItemViewItem, opt, painter, opt.widget)

        selected = bool(opt.state & QStyle.StateFlag.State_Selected)
        color_role = QPalette.ColorRole.HighlightedText if selected else QPalette.ColorRole.Text
        line_color = opt.palette.color(color_role)
        painter.save()
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            preview_left = opt.rect.left() + 12
            preview_right = preview_left + LINE_STYLE_POPUP_PREVIEW_WIDTH
            preview_y = opt.rect.center().y()
            draw_line_style_preview(painter, style_name, line_color, preview_left, preview_right, preview_y)

            text_rect = opt.rect.adjusted(LINE_STYLE_POPUP_PREVIEW_WIDTH + 28, 0, -8, 0)
            painter.setPen(line_color)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, style_name)
        finally:
            painter.restore()

    def sizeHint(self, option: QStyleOptionViewItem, index) -> QSize:
        hint = super().sizeHint(option, index)
        return QSize(max(hint.width(), LINE_STYLE_POPUP_PREVIEW_WIDTH + 150), max(hint.height(), LINE_STYLE_POPUP_ROW_HEIGHT))


def apply_app_theme(app: QApplication) -> bool:
    base_stylesheet = qdarktheme.load_stylesheet() if qdarktheme is not None else ""
    app.setStyleSheet(f"{base_stylesheet}\n{APP_THEME_OVERRIDES}")
    return qdarktheme is not None


def normalize_language_code(language: str | None) -> str:
    if not language:
        return "system"
    code = language.strip().replace("-", "_")
    if code in {"system", "en", "zh_CN"}:
        return code
    if code.lower().startswith("zh"):
        return "zh_CN"
    if code.lower().startswith("en"):
        return "en"
    return "system"


def easygraph_settings() -> QSettings:
    return QSettings("EasyGraph", "EasyGraph")


def stored_language_preference() -> str:
    settings = easygraph_settings()
    return normalize_language_code(str(settings.value(LANGUAGE_SETTING_KEY, "system")))


def save_language_preference(language: str) -> None:
    settings = easygraph_settings()
    settings.setValue(LANGUAGE_SETTING_KEY, normalize_language_code(language))


def _settings_string_list(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [str(item) for item in value if str(item)]
    text = str(value)
    return [text] if text else []


def _project_path_key(path: Path) -> str:
    return os.path.normcase(str(Path(path).expanduser()))


def normalized_recent_project_paths(paths) -> list[Path]:
    recent: list[Path] = []
    seen: set[str] = set()
    for raw_path in paths:
        if not raw_path:
            continue
        path = Path(str(raw_path)).expanduser()
        key = _project_path_key(path)
        if key in seen:
            continue
        recent.append(path)
        seen.add(key)
        if len(recent) >= MAX_RECENT_PROJECTS:
            break
    return recent


def stored_recent_project_paths() -> list[Path]:
    settings = easygraph_settings()
    return normalized_recent_project_paths(_settings_string_list(settings.value(RECENT_PROJECTS_SETTING_KEY, [])))


def save_recent_project_paths(paths) -> None:
    settings = easygraph_settings()
    settings.setValue(RECENT_PROJECTS_SETTING_KEY, [str(path) for path in normalized_recent_project_paths(paths)])


def remember_recent_project(path: Path) -> None:
    project_path = Path(path).expanduser()
    save_recent_project_paths([project_path, *stored_recent_project_paths()])


def forget_recent_project(path: Path) -> None:
    key = _project_path_key(Path(path))
    save_recent_project_paths([recent_path for recent_path in stored_recent_project_paths() if _project_path_key(recent_path) != key])


def effective_language_code(language: str | None = None) -> str:
    preference = normalize_language_code(os.environ.get(LANGUAGE_ENV_VAR) or language or stored_language_preference())
    if preference == "system":
        return normalize_language_code(QLocale.system().name())
    return preference


def install_app_translator(app: QApplication, language: str | None = None) -> str:
    code = effective_language_code(language)
    if code == "en":
        return code

    translator = QTranslator(app)
    translation_file = TRANSLATION_DIR / f"easygraph_{code}.qm"
    if translator.load(str(translation_file)):
        app.installTranslator(translator)
        app._easygraph_translator = translator
    return code






class DataTable(QTableWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setAlternatingRowColors(True)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

    def set_dataframe(self, df: pd.DataFrame) -> None:
        self.blockSignals(True)
        self.setRowCount(len(df) + 1)
        self.setColumnCount(len(df.columns))
        self.setHorizontalHeaderLabels([str(c + 1) for c in range(len(df.columns))])
        for c, col in enumerate(df.columns):
            self.setItem(0, c, QTableWidgetItem(str(col)))
        for r in range(len(df)):
            for c, col in enumerate(df.columns):
                value = df.iloc[r, c]
                text = "" if pd.isna(value) else str(value)
                self.setItem(r + 1, c, QTableWidgetItem(text))
        self.blockSignals(False)

    def dataframe(self) -> pd.DataFrame:
        headers = [
            self.item(0, c).text() if self.item(0, c) and self.item(0, c).text().strip() else f"Group {c+1}"
            for c in range(self.columnCount())
        ]
        data = []
        for r in range(1, self.rowCount()):
            row = []
            for c in range(self.columnCount()):
                item = self.item(r, c)
                row.append(item.text() if item else "")
            data.append(row)
        return pd.DataFrame(data, columns=headers)






from ui_main_window import Ui_MainWindow
from ui_group_order_dialog import Ui_GroupOrderDialog


class MainWindow(QMainWindow):
    def __init__(self, initial_render: bool = True) -> None:
        super().__init__()
        self.settings = ChartSettings()
        self.current_project: Path | None = None
        self._applying_settings = False
        self._committing_control_edits = False
        self._custom_overlay_rows = 0
        self._table_undo_stack: list[dict] = []
        self._table_redo_stack: list[dict] = []
        self._last_table_snapshot: dict | None = None
        self._table_history_restoring = False
        self._table_history_suspended = False
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.setInterval(APP_RENDER_DEBOUNCE_MS)
        self._render_timer.timeout.connect(self.flush_pending_render)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.table = self.ui.dataTable
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.table.set_dataframe = self.set_table_dataframe
        self.table.dataframe = self.table_dataframe
        self.canvas = PlotCanvas()
        self.canvas.selection_callback = self.handle_plot_object_selection
        self.canvas.legend_position_callback = self.handle_legend_drag_position
        self.ui.plotHostLayout.addWidget(self.canvas)
        self._bind_ui_widgets()
        self._populate_ui_options()
        self.refresh_template_combo()
        self._polish_input_controls()
        self.table.set_dataframe(sample_data())
        self.reset_table_history()
        self.apply_settings_to_controls()
        self._connect_generated_ui()
        if initial_render:
            self.render()
            self._fit_initial_plot_to_viewport()

    def _fit_initial_plot_to_viewport(self) -> None:
        self.canvas.zoom_to_fit()
        QTimer.singleShot(0, self.canvas.zoom_to_fit)

    def handle_plot_object_selection(self, object_kind: str | None) -> None:
        self._apply_inspector_focus(object_kind)
        section = self._section_for_plot_object(object_kind)
        if section is None:
            return
        self.ui.controlsScroll.ensureWidgetVisible(section, 0, 8)

    def handle_legend_drag_position(self, x: float, y: float) -> None:
        self.settings.legend_position = LEGEND_POSITION_INSIDE
        self.settings.legend_inside_x = min(max(float(x), 0.0), 1.0)
        self.settings.legend_inside_y = min(max(float(y), 0.0), 1.0)
        self.render()

    def _section_for_plot_object(self, object_kind: str | None) -> QWidget | None:
        if object_kind == "legend":
            return self.legend_group
        if object_kind == "stats_table":
            return self.ui.statsTableGroup
        if object_kind == "axis":
            return self.ui.axisGroup
        if object_kind == "title_axis":
            return self.ui.titleAxisGroup
        if object_kind == "plot_area":
            return self.ui.chartGroup
        if object_kind == "points":
            return self.ui.chartGroup
        if object_kind == "line_overlay":
            return self.ui.lineOverlayGroup
        return None

    def _inspector_groups(self) -> list[QGroupBox]:
        return [
            self.ui.titleAxisGroup,
            self.ui.chartGroup,
            self.ui.axisGroup,
            self.ui.secondaryAxisGroup,
            self.ui.pointsGroup,
            self.ui.lineOverlayGroup,
            self.ui.statsTableGroup,
            self.ui.specificGroup,
            self.legend_group,
        ]

    def _inspector_groups_for_plot_object(self, object_kind: str | None) -> set[QGroupBox] | None:
        if object_kind is None:
            return None
        if object_kind in {"plot_area", "points"}:
            return {self.ui.chartGroup, self.ui.pointsGroup, self.ui.specificGroup}
        if object_kind == "line_overlay":
            return {self.ui.lineOverlayGroup}
        if object_kind == "axis":
            return {self.ui.axisGroup, self.ui.secondaryAxisGroup}
        if object_kind == "title_axis":
            return {self.ui.titleAxisGroup}
        if object_kind == "stats_table":
            return {self.ui.statsTableGroup}
        if object_kind == "legend":
            return {self.legend_group}
        return None

    def _apply_inspector_focus(self, object_kind: str | None) -> None:
        visible_groups = self._inspector_groups_for_plot_object(object_kind)
        for group in self._inspector_groups():
            group.setVisible(visible_groups is None or group in visible_groups)

    def _polish_inspector_groups(self) -> None:
        self.ui.controlsLayout.setAlignment(Qt.AlignTop)
        for group in self._inspector_groups():
            group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)

    def _bind_ui_widgets(self) -> None:
        self.template_combo = self.ui.templateCombo
        self.chart_type = self.ui.chartTypeCombo
        self.preset = self.ui.presetCombo
        self.group_order = self.ui.groupOrderCombo
        self.group_filter_button = self.ui.groupFilterButton
        self.edit_group_colors_button = self.ui.editGroupColorsButton
        self.title = self.ui.titleEdit
        self.x_label = self.ui.xLabelEdit
        self.y_label = self.ui.yLabelEdit
        self.secondary_y_label_label = QLabel(self.tr("Secondary value \naxis title"), self.ui.titleAxisGroup)
        self.secondary_y_label_label.setObjectName("secondaryYLabelLabel")
        self.secondary_y_label = QPlainTextEdit(self.ui.titleAxisGroup)
        self.secondary_y_label.setObjectName("secondaryYLabelEdit")
        self.secondary_y_label.setMinimumSize(QSize(0, 44))
        self.secondary_y_label.setMaximumSize(QSize(16777215, 48))
        self.secondary_y_label.setTabChangesFocus(True)
        self.secondary_y_label.setPlaceholderText(self.tr("Enter to line break"))
        self.secondary_y_label.setPlainText(self.settings.secondary_y_label)
        self.ui.titleAxisForm.addRow(self.secondary_y_label_label, self.secondary_y_label)
        self.width = self.ui.widthSpin
        self.height = self.ui.heightSpin
        self.dpi = self.ui.dpiSpin
        self.transparent_background = self.ui.transparentBackgroundCheck
        self.title_font_size = self.ui.titleFontSizeSpin
        self.axis_label_font_size = self.ui.axisLabelFontSizeSpin
        self.tick_font_size = self.ui.tickFontSizeSpin
        self.decrease_all_fonts_button = self.ui.decreaseAllFontsButton
        self.increase_all_fonts_button = self.ui.increaseAllFontsButton
        self.legend_font_size = self.ui.legendFontSizeSpin
        self.legend_group = QGroupBox(self.tr("Legend"), self.ui.controlsContent)
        self.legend_group.setObjectName("legendGroup")
        self.legend_form = QFormLayout(self.legend_group)
        self.legend_form.setObjectName("legendForm")
        self.legend_form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.legend_form.setLabelAlignment(Qt.AlignmentFlag.AlignLeading | Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.legend_form.setFormAlignment(Qt.AlignmentFlag.AlignLeading | Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.legend_form.setHorizontalSpacing(12)
        self.legend_form.setVerticalSpacing(6)
        self.legend_form.setContentsMargins(8, 10, 8, 8)
        legend_insert_index = self.ui.controlsLayout.indexOf(self.ui.statsTableGroup) + 1
        self.ui.controlsLayout.insertWidget(legend_insert_index, self.legend_group)
        self.show_legend = QCheckBox(self.legend_group)
        self.show_legend.setObjectName("showLegendCheck")
        self.show_legend.setChecked(self.settings.show_legend)
        self.legend_position = QComboBox(self.legend_group)
        self.legend_position.setObjectName("legendPositionCombo")
        self.legend_position.addItems([self.tr("Right side"), self.tr("Inside plot")])
        self.legend_position.setCurrentText(
            self.tr("Inside plot") if self.settings.legend_position == LEGEND_POSITION_INSIDE else self.tr("Right side")
        )
        self.legend_auto_width = QCheckBox(self.legend_group)
        self.legend_auto_width.setObjectName("legendAutoWidthCheck")
        self.legend_auto_width.setChecked(self.settings.legend_auto_width)
        self.legend_width = QDoubleSpinBox(self.legend_group)
        self.legend_width.setObjectName("legendWidthSpin")
        self.legend_width.setRange(0.5, 20.0)
        self.legend_width.setSingleStep(0.1)
        self.legend_width.setDecimals(2)
        self.legend_width.setValue(self.settings.legend_width)
        self.legend_columns = QComboBox(self.legend_group)
        self.legend_columns.setObjectName("legendColumnsCombo")
        self.legend_columns.addItems([self.tr("Auto"), "1", "2", "3", "4", "5", "6"])
        self.legend_columns.setCurrentText(self.tr("Auto") if self.settings.legend_columns <= 0 else str(self.settings.legend_columns))
        self._add_right_aligned_form_row(self.legend_form, self.tr("Show legend"), self.show_legend)
        self._add_right_aligned_form_row(self.legend_form, self.tr("Position"), self.legend_position)
        self._add_right_aligned_form_row(self.legend_form, self.tr("Auto width"), self.legend_auto_width)
        self._add_right_aligned_form_row(self.legend_form, self.tr("Width (cm)"), self.legend_width)
        self._add_right_aligned_form_row(self.legend_form, self.tr("Columns"), self.legend_columns)
        self.line_value_font_size = self.ui.lineValueFontSizeSpin
        self.stat_table_font_size = self.ui.statTableFontSizeSpin
        self.show_grid = self.ui.showGridCheck
        self.auto_y_range = self.ui.autoYRangeCheck
        self.axis_line_width = self.ui.axisLineWidthSpin
        self.x_tick_rotation = self.ui.xTickRotationSpin
        self.y_min = self.ui.yMinSpin
        self.y_max = self.ui.yMaxSpin
        self._ensure_axis_groups()
        self.primary_auto_tick_interval_label = QLabel(self.tr("Auto Primary Y Tick Interval"), self.ui.primaryAxisGroup)
        self.primary_auto_tick_interval_label.setObjectName("primaryAutoTickIntervalLabel")
        self.primary_auto_tick_interval = QCheckBox(self.ui.primaryAxisGroup)
        self.primary_auto_tick_interval.setObjectName("primaryAutoTickIntervalCheck")
        self.primary_auto_tick_interval.setChecked(self.settings.primary_auto_tick_interval)
        self.primary_tick_interval_label = QLabel(self.tr("Primary Y tick interval"), self.ui.primaryAxisGroup)
        self.primary_tick_interval_label.setObjectName("primaryTickIntervalLabel")
        self.primary_tick_interval = QDoubleSpinBox(self.ui.primaryAxisGroup)
        self.primary_tick_interval.setObjectName("primaryTickIntervalSpin")
        self.primary_tick_interval.setRange(0.000001, 1_000_000)
        self.primary_tick_interval.setSingleStep(0.5)
        self.primary_tick_interval.setDecimals(6)
        self.primary_tick_interval.setValue(self.settings.primary_tick_interval)
        self.secondary_auto_y_range_label = QLabel(self.tr("Auto Secondary Y Range"), self.ui.secondaryAxisGroup)
        self.secondary_auto_y_range_label.setObjectName("secondaryAutoYLabel")
        self.secondary_auto_y_range = QCheckBox(self.ui.secondaryAxisGroup)
        self.secondary_auto_y_range.setObjectName("secondaryAutoYRangeCheck")
        self.secondary_auto_y_range.setChecked(self.settings.secondary_auto_y_range)
        self.secondary_y_min_label = QLabel(self.tr("Secondary Y min"), self.ui.secondaryAxisGroup)
        self.secondary_y_min_label.setObjectName("secondaryYMinLabel")
        self.secondary_y_min = QDoubleSpinBox(self.ui.secondaryAxisGroup)
        self.secondary_y_min.setObjectName("secondaryYMinSpin")
        self.secondary_y_min.setRange(-1_000_000, 1_000_000)
        self.secondary_y_min.setSingleStep(0.5)
        self.secondary_y_min.setValue(self.settings.secondary_y_min)
        self.secondary_y_max_label = QLabel(self.tr("Secondary Y max"), self.ui.secondaryAxisGroup)
        self.secondary_y_max_label.setObjectName("secondaryYMaxLabel")
        self.secondary_y_max = QDoubleSpinBox(self.ui.secondaryAxisGroup)
        self.secondary_y_max.setObjectName("secondaryYMaxSpin")
        self.secondary_y_max.setRange(-1_000_000, 1_000_000)
        self.secondary_y_max.setSingleStep(0.5)
        self.secondary_y_max.setValue(self.settings.secondary_y_max)
        self.secondary_auto_tick_interval_label = QLabel(self.tr("Auto Secondary Y Tick Interval"), self.ui.secondaryAxisGroup)
        self.secondary_auto_tick_interval_label.setObjectName("secondaryAutoTickIntervalLabel")
        self.secondary_auto_tick_interval = QCheckBox(self.ui.secondaryAxisGroup)
        self.secondary_auto_tick_interval.setObjectName("secondaryAutoTickIntervalCheck")
        self.secondary_auto_tick_interval.setChecked(self.settings.secondary_auto_tick_interval)
        self.secondary_tick_interval_label = QLabel(self.tr("Secondary Y tick interval"), self.ui.secondaryAxisGroup)
        self.secondary_tick_interval_label.setObjectName("secondaryTickIntervalLabel")
        self.secondary_tick_interval = QDoubleSpinBox(self.ui.secondaryAxisGroup)
        self.secondary_tick_interval.setObjectName("secondaryTickIntervalSpin")
        self.secondary_tick_interval.setRange(0.000001, 1_000_000)
        self.secondary_tick_interval.setSingleStep(0.5)
        self.secondary_tick_interval.setDecimals(6)
        self.secondary_tick_interval.setValue(self.settings.secondary_tick_interval)
        self.split_secondary_axis_label = QLabel(self.tr("Split secondary frame"), self.ui.secondaryAxisGroup)
        self.split_secondary_axis_label.setObjectName("splitSecondaryAxisLabel")
        self.split_secondary_axis = QCheckBox(self.ui.secondaryAxisGroup)
        self.split_secondary_axis.setObjectName("splitSecondaryAxisCheck")
        self.split_secondary_axis.setChecked(self.settings.split_secondary_axis)
        self.secondary_axis_split_ratio_label = QLabel(self.tr("Secondary frame ratio"), self.ui.secondaryAxisGroup)
        self.secondary_axis_split_ratio_label.setObjectName("secondaryAxisSplitRatioLabel")
        self.secondary_axis_split_ratio = QDoubleSpinBox(self.ui.secondaryAxisGroup)
        self.secondary_axis_split_ratio.setObjectName("secondaryAxisSplitRatioSpin")
        self.secondary_axis_split_ratio.setRange(0.15, 0.85)
        self.secondary_axis_split_ratio.setSingleStep(0.05)
        self.secondary_axis_split_ratio.setDecimals(2)
        self.secondary_axis_split_ratio.setValue(self.settings.secondary_axis_split_ratio)
        self.ui.axisForm.addRow(
            self.primary_auto_tick_interval_label,
            self._right_aligned_field_layout(self.primary_auto_tick_interval),
        )
        self.ui.axisForm.addRow(
            self.primary_tick_interval_label,
            self._right_aligned_field_layout(self.primary_tick_interval),
        )
        self.ui.secondaryAxisForm.addRow(
            self.secondary_auto_y_range_label,
            self._right_aligned_field_layout(self.secondary_auto_y_range),
        )
        secondary_y_min_field_layout = QHBoxLayout()
        secondary_y_min_field_layout.setSpacing(0)
        secondary_y_min_field_layout.setContentsMargins(0, 0, 0, 0)
        secondary_y_min_field_layout.addStretch(1)
        secondary_y_min_field_layout.addWidget(self.secondary_y_min)
        self.ui.secondaryAxisForm.addRow(self.secondary_y_min_label, secondary_y_min_field_layout)
        secondary_y_max_field_layout = QHBoxLayout()
        secondary_y_max_field_layout.setSpacing(0)
        secondary_y_max_field_layout.setContentsMargins(0, 0, 0, 0)
        secondary_y_max_field_layout.addStretch(1)
        secondary_y_max_field_layout.addWidget(self.secondary_y_max)
        self.ui.secondaryAxisForm.addRow(self.secondary_y_max_label, secondary_y_max_field_layout)
        self.ui.secondaryAxisForm.addRow(
            self.secondary_auto_tick_interval_label,
            self._right_aligned_field_layout(self.secondary_auto_tick_interval),
        )
        self.ui.secondaryAxisForm.addRow(
            self.secondary_tick_interval_label,
            self._right_aligned_field_layout(self.secondary_tick_interval),
        )
        self.ui.secondaryAxisForm.addRow(
            self.split_secondary_axis_label,
            self._right_aligned_field_layout(self.split_secondary_axis),
        )
        secondary_axis_split_ratio_field_layout = QHBoxLayout()
        secondary_axis_split_ratio_field_layout.setSpacing(0)
        secondary_axis_split_ratio_field_layout.setContentsMargins(0, 0, 0, 0)
        secondary_axis_split_ratio_field_layout.addStretch(1)
        secondary_axis_split_ratio_field_layout.addWidget(self.secondary_axis_split_ratio)
        self.ui.secondaryAxisForm.addRow(self.secondary_axis_split_ratio_label, secondary_axis_split_ratio_field_layout)
        self.show_points = self.ui.showPointsCheck
        self.point_size = self.ui.pointSizeSpin
        self.point_alpha = self.ui.pointAlphaSpin
        self.jitter_mode = self.ui.jitterModeCombo
        self.jitter = self.ui.jitterSpin
        self.show_line_overlay = self.ui.showLineOverlayCheck
        self.line_overlay_stat = self.ui.lineOverlayStatCombo
        self.extra_custom_overlay = self.ui.extraCustomOverlayCheck
        self.custom_overlay_count = self.ui.customOverlayCountSpin
        self.add_overlay_button = self.ui.addOverlayButton
        self.remove_overlay_button = self.ui.removeOverlayButton
        self.custom_overlay_filter_button = self.ui.customOverlayFilterButton
        self.custom_overlay_secondary_axis_label = self.ui.customOverlaySecondaryAxisLabel
        self.custom_overlay_secondary_axis = self.ui.customOverlaySecondaryAxisCheck
        self.custom_overlay_secondary_axis.setChecked(self.settings.custom_overlay_secondary_axis)
        self.line_overlay_width = self.ui.lineOverlayWidthSpin
        self.line_overlay_style = self.ui.lineOverlayStyleCombo
        self.edit_overlay_styles_button = QPushButton(self.tr("Custom styles"), self.ui.lineOverlayGroup)
        self.edit_overlay_styles_button.setObjectName("editOverlayStylesButton")
        self.ui.lineOverlayForm.insertRow(6, self.tr("Custom line styles"), self._right_aligned_field_layout(self.edit_overlay_styles_button))
        self.line_overlay_point_size = self.ui.lineOverlayPointSizeSpin
        self.show_line_values = self.ui.showLineValuesCheck
        self.line_value_position = self.ui.lineValuePositionCombo
        self.custom_line_value_position = self.ui.customLineValuePositionCombo
        self.line_value_scientific = self.ui.lineValueScientificCheck
        self.line_value_decimals = self.ui.lineValueDecimalsSpin
        self.show_stat_table = self.ui.showStatTableCheck
        self.show_stat_header = self.ui.showStatHeaderCheck
        self.stat_table_options = self.ui.statTableOptionsList
        self.show_outliers = self.ui.showOutliersCheck
        self.outlier_method = self.ui.outlierMethodCombo
        self.outlier_threshold = self.ui.outlierThresholdSpin
        self.outlier_effect = self.ui.outlierEffectCombo
        self.box_width = self.ui.boxWidthSpin
        self.box_whisker_mode = self.ui.boxWhiskerModeCombo
        self.violin_width = self.ui.violinWidthSpin
        self.kde_bandwidth = self.ui.kdeBandwidthSpin
        self.ridge_overlap = self.ui.ridgeOverlapSpin
        self.fill_alpha = self.ui.fillAlphaSpin

    def _ensure_axis_groups(self) -> None:
        if not hasattr(self.ui, "primaryAxisGroup"):
            self.ui.primaryAxisGroup = self.ui.axisGroup
            self.ui.primaryAxisForm = self.ui.axisForm
            self.ui.primaryAxisGroup.setTitle(self.tr("Primary Axis"))
        if hasattr(self.ui, "secondaryAxisGroup"):
            return

        self.ui.secondaryAxisGroup = QGroupBox(self.tr("Secondary Axis"), self.ui.controlsContent)
        self.ui.secondaryAxisGroup.setObjectName("secondaryAxisGroup")
        self.ui.secondaryAxisForm = QFormLayout(self.ui.secondaryAxisGroup)
        self.ui.secondaryAxisForm.setObjectName("secondaryAxisForm")
        self.ui.secondaryAxisForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.ui.secondaryAxisForm.setLabelAlignment(
            Qt.AlignmentFlag.AlignLeading | Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        )
        self.ui.secondaryAxisForm.setFormAlignment(
            Qt.AlignmentFlag.AlignLeading | Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop
        )
        self.ui.secondaryAxisForm.setHorizontalSpacing(12)
        self.ui.secondaryAxisForm.setVerticalSpacing(6)
        self.ui.secondaryAxisForm.setContentsMargins(8, 10, 8, 8)

        primary_index = self.ui.controlsLayout.indexOf(self.ui.primaryAxisGroup)
        self.ui.controlsLayout.insertWidget(primary_index + 1, self.ui.secondaryAxisGroup)
        if hasattr(self.ui.axisForm, "takeRow"):
            self.ui.axisForm.takeRow(self.ui.customOverlaySecondaryAxisLabel)
        self.ui.customOverlaySecondaryAxisLabel.setText(self.tr("叠加线使用次坐标轴"))
        self.ui.secondaryAxisForm.addRow(
            self.ui.customOverlaySecondaryAxisLabel,
            self._right_aligned_field_layout(self.ui.customOverlaySecondaryAxisCheck),
        )

    def _add_right_aligned_form_row(self, form: QFormLayout, label: str, widget: QWidget) -> None:
        field_layout = QHBoxLayout()
        field_layout.setSpacing(0)
        field_layout.setContentsMargins(0, 0, 0, 0)
        field_layout.addStretch(1)
        field_layout.addWidget(widget)
        form.addRow(label, field_layout)

    def _right_aligned_field_layout(self, widget: QWidget) -> QHBoxLayout:
        field_layout = QHBoxLayout()
        field_layout.setSpacing(0)
        field_layout.setContentsMargins(0, 0, 0, 0)
        field_layout.addStretch(1)
        field_layout.addWidget(widget)
        return field_layout

    def _populate_ui_options(self) -> None:
        self.chart_type.addItems(["Box", "Violin", "Ridge"])
        self.preset.addItems(list(PRESETS))
        self.group_order.addItems([
            "Table order",
            "Manual",
            "Name A-Z",
            "Name Z-A",
            "Mean ascending",
            "Mean descending",
            "Median ascending",
            "Median descending",
        ])
        self.jitter_mode.addItems(["Beeswarm", "Quasirandom", "Random"])
        self.line_overlay_stat.addItems(["None", "Median", "Mean"])
        self._populate_line_style_combo(self.line_overlay_style)
        self._refresh_line_value_position_options()
        self.custom_line_value_position.addItems(["Auto", "Above", "Below", "Left", "Right"])
        self.outlier_method.addItems(["IQR", "Z-score", "MAD", "Percentile"])
        self.outlier_effect.addItems(["Mark only", "Exclude from distribution"])
        self.box_whisker_mode.addItems(["Tukey 1.5 IQR", "Min-Max", "Percentile 5-95", "Percentile 10-90"])
        self._populate_stat_table_options()

    def _populate_line_style_combo(self, combo: QComboBox) -> None:
        combo.clear()
        combo.setIconSize(LINE_STYLE_ICON_SIZE)
        combo.view().setIconSize(LINE_STYLE_ICON_SIZE)
        combo.view().setItemDelegate(LineStyleItemDelegate(combo.view()))
        icon_color = combo.palette().color(QPalette.ColorRole.ButtonText)
        if not icon_color.isValid():
            icon_color = combo.palette().color(QPalette.ColorRole.Text)
        for style in LINE_OVERLAY_STYLES:
            combo.addItem(line_style_icon(style, icon_color), style)

    def _populate_stat_table_options(self) -> None:
        self.stat_table_options.clear()
        for setting_name, label in STAT_TABLE_OPTIONS:
            item = QListWidgetItem(label)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if getattr(self.settings, setting_name) else Qt.Unchecked)
            item.setSizeHint(QSize(0, 22))
            self.stat_table_options.addItem(item)

    def _stat_table_option_checked(self, setting_name: str) -> bool:
        for index, (option_name, _label) in enumerate(STAT_TABLE_OPTIONS):
            if option_name == setting_name:
                item = self.stat_table_options.item(index)
                return item is not None and item.checkState() == Qt.Checked
        return False

    def _apply_stat_table_options_to_controls(self) -> None:
        self.stat_table_options.blockSignals(True)
        try:
            for index, (setting_name, _label) in enumerate(STAT_TABLE_OPTIONS):
                item = self.stat_table_options.item(index)
                if item is not None:
                    item.setCheckState(Qt.Checked if getattr(self.settings, setting_name) else Qt.Unchecked)
        finally:
            self.stat_table_options.blockSignals(False)

    def _stat_table_header_forced(self) -> bool:
        return self.chart_type.currentText() == "Ridge" and self.show_stat_table.isChecked()

    def _set_stat_table_header_checked(self, checked: bool) -> None:
        signals_blocked = self.show_stat_header.blockSignals(True)
        try:
            self.show_stat_header.setChecked(checked)
        finally:
            self.show_stat_header.blockSignals(signals_blocked)

    def _sync_stat_table_header_control(self, restore_stored: bool = False) -> bool:
        forced = self._stat_table_header_forced()
        if forced:
            self._set_stat_table_header_checked(True)
        elif restore_stored:
            self._set_stat_table_header_checked(self.settings.show_stat_header)
        self.show_stat_header.setEnabled(not forced)
        return forced

    def _line_value_position_options(self) -> list[str]:
        axis_options = ["Axis left", "Axis right"] if self.chart_type.currentText() == "Ridge" else ["Top axis", "Bottom axis"]
        return ["Auto", "Above", "Below", "Left", "Right", *axis_options]

    def _refresh_line_value_position_options(self, preferred: str | None = None) -> None:
        options = self._line_value_position_options()
        current_options = [self.line_value_position.itemText(index) for index in range(self.line_value_position.count())]
        current = preferred if preferred is not None else self.line_value_position.currentText()
        selected = normalize_overlay_label_position(current, self.chart_type.currentText())
        if current_options == options:
            self.line_value_position.setCurrentText(selected)
            return

        self.line_value_position.blockSignals(True)
        try:
            self.line_value_position.clear()
            self.line_value_position.addItems(options)
            self.line_value_position.setCurrentText(selected)
        finally:
            self.line_value_position.blockSignals(False)

    def _legend_columns_control_value(self) -> int:
        text = self.legend_columns.currentText()
        return int(text) if text.isdigit() else 0

    def _legend_position_control_value(self) -> str:
        return LEGEND_POSITION_INSIDE if self.legend_position.currentText() == self.tr("Inside plot") else LEGEND_POSITION_RIGHT

    def _set_legend_position_value(self, position: str) -> None:
        self.legend_position.blockSignals(True)
        try:
            self.legend_position.setCurrentText(self.tr("Inside plot") if position == LEGEND_POSITION_INSIDE else self.tr("Right side"))
        finally:
            self.legend_position.blockSignals(False)

    def _set_legend_auto_width_checked(self, checked: bool) -> None:
        self.legend_auto_width.blockSignals(True)
        try:
            self.legend_auto_width.setChecked(checked)
        finally:
            self.legend_auto_width.blockSignals(False)

    def _set_legend_columns_value(self, columns: int) -> None:
        self.legend_columns.blockSignals(True)
        try:
            self.legend_columns.setCurrentText(self.tr("Auto") if columns <= 0 else str(columns))
        finally:
            self.legend_columns.blockSignals(False)

    def handle_legend_columns_changed(self, _text: str | None = None) -> None:
        if self._legend_columns_control_value() <= 0:
            self._set_legend_auto_width_checked(False)
        self.update_settings()

    def handle_legend_auto_width_changed(self, _state: int | None = None) -> None:
        if self.legend_auto_width.isChecked() and self._legend_columns_control_value() <= 0:
            self._set_legend_columns_value(1)
        self.update_settings()

    def _custom_overlay_axis_available(self, existing_overlay_series: list[dict] | None = None) -> bool:
        if existing_overlay_series is None:
            existing_overlay_series = self.custom_overlay_series_from_table()
        return self.extra_custom_overlay.isChecked() and bool(existing_overlay_series)

    def _combo_boxes(self) -> list[QComboBox]:
        return [
            self.chart_type,
            self.preset,
            self.group_order,
            self.legend_position,
            self.legend_columns,
            self.jitter_mode,
            self.line_overlay_stat,
            self.line_overlay_style,
            self.line_value_position,
            self.custom_line_value_position,
            self.outlier_method,
            self.outlier_effect,
            self.box_whisker_mode,
        ]

    def _spin_boxes(self) -> list[QSpinBox | QDoubleSpinBox]:
        return [
            self.width,
            self.height,
            self.dpi,
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.legend_font_size,
            self.legend_width,
            self.line_value_font_size,
            self.stat_table_font_size,
            self.custom_overlay_count,
            self.line_overlay_width,
            self.line_overlay_point_size,
            self.axis_line_width,
            self.x_tick_rotation,
            self.y_min,
            self.y_max,
            self.primary_tick_interval,
            self.secondary_y_min,
            self.secondary_y_max,
            self.secondary_tick_interval,
            self.secondary_axis_split_ratio,
            self.point_size,
            self.point_alpha,
            self.jitter,
            self.line_value_decimals,
            self.outlier_threshold,
            self.box_width,
            self.violin_width,
            self.kde_bandwidth,
            self.ridge_overlap,
            self.fill_alpha,
        ]

    def _buttons(self) -> list[QPushButton]:
        return [
            self.ui.addRowButton,
            self.ui.addColumnButton,
            self.ui.deleteColumnButton,
            self.ui.renameColumnButton,
            self.add_overlay_button,
            self.remove_overlay_button,
            self.custom_overlay_filter_button,
            self.edit_overlay_styles_button,
            self.ui.copyImageButton,
            self.ui.editGroupOrderButton,
            self.group_filter_button,
            self.edit_group_colors_button,
            self.decrease_all_fonts_button,
            self.increase_all_fonts_button,
            self.ui.loadTemplateButton,
            self.ui.saveTemplateButton,
        ]

    def _font_size_controls(self) -> list[QSpinBox]:
        return [
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.legend_font_size,
            self.line_value_font_size,
            self.stat_table_font_size,
        ]

    def _top_toolbar_compact_spin_boxes(self) -> list[QSpinBox | QDoubleSpinBox]:
        return [
            *self._font_size_controls(),
            self.width,
            self.height,
            self.dpi,
        ]

    def _office_adjacent_font_size(self, current: int, direction: int, minimum: int, maximum: int) -> int:
        if direction > 0:
            candidates = [size for size in OFFICE_FONT_SIZE_STEPS if size > current]
            target = candidates[0] if candidates else maximum
        else:
            candidates = [size for size in OFFICE_FONT_SIZE_STEPS if size < current]
            target = candidates[-1] if candidates else minimum
        return min(max(target, minimum), maximum)

    def adjust_all_font_sizes(self, direction: int) -> None:
        controls = self._font_size_controls()
        changed = False
        for control in controls:
            target = self._office_adjacent_font_size(control.value(), direction, control.minimum(), control.maximum())
            if target != control.value():
                changed = True
            control.blockSignals(True)
            control.setValue(target)
            control.blockSignals(False)
        if changed:
            self.update_settings()

    def _polish_combo_box(self, combo: QComboBox) -> None:
        combo.setFixedHeight(APP_CONTROL_HEIGHT)
        combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        if combo.count() == 0:
            return
        max_text_width = max(combo.fontMetrics().horizontalAdvance(combo.itemText(index)) for index in range(combo.count()))
        has_icons = any(not combo.itemIcon(index).isNull() for index in range(combo.count()))
        if has_icons:
            max_text_width += combo.iconSize().width() + 8
        max_text_length = max(len(combo.itemText(index)) for index in range(combo.count()))
        minimum_width = min(max(max_text_width + COMBO_TEXT_WIDTH_PADDING, COMBO_MIN_WIDTH), 280)
        popup_minimum_width = minimum_width
        if isinstance(combo.view().itemDelegate(), LineStyleItemDelegate):
            popup_width = LINE_STYLE_POPUP_PREVIEW_WIDTH + max_text_width + COMBO_TEXT_WIDTH_PADDING + 24
            popup_minimum_width = min(max(popup_minimum_width, popup_width), 320)
        combo.setMinimumContentsLength(min(max(max_text_length + 2, 10), 36))
        combo.setFixedWidth(minimum_width)
        combo.view().setMinimumWidth(popup_minimum_width)

    def _polish_template_combo_box(self) -> None:
        self.template_combo.setFixedHeight(APP_CONTROL_HEIGHT)
        self.template_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.template_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        if self.template_combo.count() == 0:
            return
        max_text_width = max(self.template_combo.fontMetrics().horizontalAdvance(self.template_combo.itemText(index)) for index in range(self.template_combo.count()))
        max_text_length = max(len(self.template_combo.itemText(index)) for index in range(self.template_combo.count()))
        minimum_width = min(max(max_text_width + COMBO_TEXT_WIDTH_PADDING, COMBO_MIN_WIDTH), 280)
        self.template_combo.setMinimumContentsLength(min(max(max_text_length + 2, 10), 36))
        self.template_combo.setMinimumWidth(COMBO_MIN_WIDTH)
        self.template_combo.view().setMinimumWidth(minimum_width)

    def _combo_full_text_width(self, combo: QComboBox) -> int:
        if combo.count() == 0:
            return COMBO_MIN_WIDTH
        max_text_width = max(combo.fontMetrics().horizontalAdvance(combo.itemText(index)) for index in range(combo.count()))
        has_icons = any(not combo.itemIcon(index).isNull() for index in range(combo.count()))
        if has_icons:
            max_text_width += combo.iconSize().width() + 8
        return max(max_text_width + COMBO_TEXT_WIDTH_PADDING, COMBO_MIN_WIDTH)

    def _spin_box_widest_text(self, spin_box: QSpinBox | QDoubleSpinBox) -> str:
        candidates = [
            spin_box.textFromValue(spin_box.minimum()),
            spin_box.textFromValue(spin_box.maximum()),
            spin_box.textFromValue(spin_box.value()),
        ]
        return max(candidates, key=spin_box.fontMetrics().horizontalAdvance)

    def _compact_spin_box_width(self, spin_box: QSpinBox | QDoubleSpinBox) -> int:
        sample_text = self._spin_box_widest_text(spin_box)
        minimum_edit_width = spin_box.fontMetrics().horizontalAdvance(sample_text) + COMPACT_SPIN_TEXT_PADDING
        start_width = max(minimum_edit_width, APP_CONTROL_HEIGHT)
        for width in range(start_width, COMBO_MIN_WIDTH + 1):
            spin_box.setFixedWidth(width)
            option = QStyleOptionSpinBox()
            spin_box.initStyleOption(option)
            edit_rect = spin_box.style().subControlRect(
                QStyle.ComplexControl.CC_SpinBox,
                option,
                QStyle.SubControl.SC_SpinBoxEditField,
                spin_box,
            )
            button_rect = spin_box.style().subControlRect(
                QStyle.ComplexControl.CC_SpinBox,
                option,
                QStyle.SubControl.SC_SpinBoxUp,
                spin_box,
            )
            if edit_rect.width() >= minimum_edit_width and button_rect.width() > 0:
                return width
        return COMBO_MIN_WIDTH

    def _polish_chart_basics_combo_boxes(self) -> None:
        order_width = self._combo_full_text_width(self.group_order)
        self.ui.topToolbarLayout.setColumnStretch(9, 0)
        self.ui.topToolbarLayout.setColumnMinimumWidth(9, order_width)
        self.ui.topToolbarLayout.setColumnStretch(19, 1)
        for combo in (self.chart_type, self.preset, self.group_order):
            combo.setFixedWidth(order_width)
            combo.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

    def _polish_input_controls(self) -> None:
        self._polish_inspector_groups()
        self._polish_template_combo_box()
        for combo in self._combo_boxes():
            self._polish_combo_box(combo)
        self._polish_chart_basics_combo_boxes()
        compact_spin_boxes = set(self._top_toolbar_compact_spin_boxes())
        for spin_box in self._spin_boxes():
            spin_box.setKeyboardTracking(False)
            spin_box.setFixedHeight(APP_CONTROL_HEIGHT)
            if spin_box in compact_spin_boxes:
                spin_box.setStyleSheet(COMPACT_SPIN_STYLE)
                spin_box.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.UpDownArrows)
                spin_width = self._compact_spin_box_width(spin_box)
            else:
                spin_width = COMBO_MIN_WIDTH
            spin_box.setFixedWidth(spin_width)
        for button in self._buttons():
            button.setFixedHeight(APP_CONTROL_HEIGHT)
        self.transparent_background.setFixedHeight(APP_CONTROL_HEIGHT)
        self.custom_overlay_count.hide()
        self.ui.customOverlayCountLabel.setText(self.tr("Overlay filter"))
        if hasattr(self.ui.lineOverlayForm, "setRowVisible"):
            self.ui.lineOverlayForm.setRowVisible(self.ui.showLineOverlayLabel, False)
        else:
            self.ui.showLineOverlayLabel.hide()
            self.show_line_overlay.hide()
        self.ui.extraCustomOverlayLabel.setText(self.tr("Show custom overlays"))

    def _connect_generated_ui(self) -> None:
        self._build_recent_projects_menu()
        self._build_edit_menu()
        self._build_language_menu()
        self._configure_file_action_shortcuts()
        self.ui.actionNew.triggered.connect(self.new_project)
        self.ui.actionOpenProject.triggered.connect(self.open_project)
        self.ui.actionSaveProject.triggered.connect(self.save_project)
        self.ui.actionSaveProjectAs.triggered.connect(self.save_project_as)
        self.ui.actionImportExcel.triggered.connect(self.import_excel)
        self.ui.actionExportExcel.triggered.connect(self.export_excel)
        self.ui.actionCopyFigure.triggered.connect(self.copy_figure_image)
        self.ui.actionExportFigure.triggered.connect(self.export_figure)
        self.ui.addRowButton.clicked.connect(self.add_row)
        self.add_overlay_button.clicked.connect(self.add_custom_overlay_row)
        self.remove_overlay_button.clicked.connect(self.remove_custom_overlay_row)
        self.ui.addColumnButton.clicked.connect(self.add_column)
        self.ui.renameColumnButton.clicked.connect(self.rename_column)
        self.ui.deleteColumnButton.clicked.connect(self.delete_column)
        self.ui.copyImageButton.clicked.connect(self.copy_figure_image)
        self.ui.editGroupOrderButton.clicked.connect(self.edit_group_order)
        self.group_filter_button.clicked.connect(self.edit_group_filter)
        self.custom_overlay_filter_button.clicked.connect(self.edit_custom_overlay_filter)
        self.edit_overlay_styles_button.clicked.connect(self.edit_custom_overlay_styles)
        self.edit_group_colors_button.clicked.connect(self.edit_group_colors)
        self.template_combo.currentTextChanged.connect(self.apply_selected_template)
        self.ui.loadTemplateButton.clicked.connect(self.load_external_template)
        self.ui.saveTemplateButton.clicked.connect(self.save_current_template)
        QShortcut(QKeySequence.Copy, self.table, activated=self.copy_table_selection)
        QShortcut(QKeySequence.Paste, self.table, activated=self.paste_table_selection)
        QShortcut(QKeySequence.Cut, self.table, activated=self.cut_table_selection)
        QShortcut(QKeySequence.Delete, self.table, activated=self.clear_table_selection)
        QShortcut(QKeySequence.Undo, self.table, activated=self.undo_table_change)
        QShortcut(QKeySequence.Redo, self.table, activated=self.redo_table_change)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_table_context_menu)
        self.table.installEventFilter(self)
        self.table.viewport().installEventFilter(self)
        QApplication.instance().installEventFilter(self)
        self._connect_table()

        for widget in [
            self.chart_type,
            self.group_order,
            self.legend_position,
            self.jitter_mode,
            self.line_overlay_stat,
            self.line_overlay_style,
            self.line_value_position,
            self.custom_line_value_position,
            self.outlier_method,
            self.outlier_effect,
            self.box_whisker_mode,
        ]:
            widget.currentTextChanged.connect(self.update_settings)
        self.legend_columns.currentTextChanged.connect(self.handle_legend_columns_changed)
        self.preset.currentTextChanged.connect(self.handle_preset_changed)
        for widget in [self.title, self.x_label, self.y_label]:
            widget.textChanged.connect(self.update_settings)
        self.secondary_y_label.textChanged.connect(self.update_settings)
        self.decrease_all_fonts_button.clicked.connect(lambda: self.adjust_all_font_sizes(-1))
        self.increase_all_fonts_button.clicked.connect(lambda: self.adjust_all_font_sizes(1))
        for widget in [
            self.width,
            self.height,
            self.dpi,
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.legend_font_size,
            self.legend_width,
            self.line_value_font_size,
            self.stat_table_font_size,
            self.custom_overlay_count,
            self.line_overlay_width,
            self.line_overlay_point_size,
            self.axis_line_width,
            self.x_tick_rotation,
            self.y_min,
            self.y_max,
            self.primary_tick_interval,
            self.secondary_y_min,
            self.secondary_y_max,
            self.secondary_tick_interval,
            self.secondary_axis_split_ratio,
            self.point_size,
            self.point_alpha,
            self.jitter,
            self.line_value_decimals,
            self.outlier_threshold,
            self.box_width,
            self.violin_width,
            self.kde_bandwidth,
            self.ridge_overlap,
            self.fill_alpha,
        ]:
            widget.valueChanged.connect(self.update_settings)
        for widget in [
            self.transparent_background,
            self.show_grid,
            self.auto_y_range,
            self.primary_auto_tick_interval,
            self.secondary_auto_y_range,
            self.secondary_auto_tick_interval,
            self.split_secondary_axis,
            self.show_legend,
            self.show_points,
            self.show_line_overlay,
            self.extra_custom_overlay,
            self.custom_overlay_secondary_axis,
            self.show_line_values,
            self.line_value_scientific,
            self.show_stat_table,
            self.show_stat_header,
            self.show_outliers,
        ]:
            widget.stateChanged.connect(self.update_settings)
        self.legend_auto_width.stateChanged.connect(self.handle_legend_auto_width_changed)
        self.stat_table_options.itemChanged.connect(self.update_settings)

    def _configure_file_action_shortcuts(self) -> None:
        self.ui.actionOpenProject.setShortcuts(QKeySequence.Open)
        self.ui.actionSaveProject.setShortcuts(QKeySequence.Save)
        self.ui.actionSaveProjectAs.setShortcuts(QKeySequence.SaveAs)
        self.ui.actionCopyFigure.setShortcut(QKeySequence("Ctrl+Shift+C"))

    def _build_recent_projects_menu(self) -> None:
        self.recent_projects_menu = self.ui.menuOpenRecent
        self.recent_projects_menu.aboutToShow.connect(self.update_recent_projects_menu)
        self.update_recent_projects_menu()

    def update_recent_projects_menu(self) -> None:
        self.recent_projects_menu.clear()
        recent_paths = stored_recent_project_paths()
        if not recent_paths:
            empty_action = self.recent_projects_menu.addAction(self.tr("No Recent Projects"))
            empty_action.setEnabled(False)
            return

        for index, path in enumerate(recent_paths, start=1):
            shortcut_prefix = f"&{index} " if index < 10 else ""
            action = self.recent_projects_menu.addAction(f"{shortcut_prefix}{path}")
            action.setData(str(path))
            action.setStatusTip(str(path))
            action.triggered.connect(lambda _checked=False, *, project_path=path: self.open_recent_project(project_path))

        self.recent_projects_menu.addSeparator()
        clear_action = self.recent_projects_menu.addAction(self.tr("Clear Recent Projects"))
        clear_action.triggered.connect(self.clear_recent_projects)

    def clear_recent_projects(self) -> None:
        save_recent_project_paths([])
        self.update_recent_projects_menu()

    def _build_language_menu(self) -> None:
        self.language_menu = self.ui.menubar.addMenu(self.tr("Language"))
        self.language_actions: dict[str, QAction] = {}
        current_language = stored_language_preference()
        for language, label in [
            ("system", self.tr("System")),
            ("en", "English"),
            ("zh_CN", self.tr("Simplified Chinese")),
        ]:
            action = QAction(label, self)
            action.setCheckable(True)
            action.setChecked(current_language == language)
            action.triggered.connect(lambda _checked=False, *, code=language: self.change_language_preference(code))
            self.language_menu.addAction(action)
            self.language_actions[language] = action

    def _build_edit_menu(self) -> None:
        self.edit_menu = self.ui.menubar.addMenu(self.tr("Edit"))
        self.undo_table_action = QAction(self.tr("Undo Table Change"), self)
        self.undo_table_action.setShortcuts(QKeySequence.Undo)
        self.undo_table_action.triggered.connect(self.undo_table_change)
        self.edit_menu.addAction(self.undo_table_action)
        self.redo_table_action = QAction(self.tr("Redo Table Change"), self)
        self.redo_table_action.setShortcuts(QKeySequence.Redo)
        self.redo_table_action.triggered.connect(self.redo_table_change)
        self.edit_menu.addAction(self.redo_table_action)
        self.update_table_history_actions()

    def change_language_preference(self, language: str) -> None:
        language = normalize_language_code(language)
        if stored_language_preference() == language:
            self.language_actions[language].setChecked(True)
            return
        save_language_preference(language)
        for code, action in self.language_actions.items():
            action.setChecked(code == language)
        QMessageBox.information(
            self,
            self.tr("Language changed"),
            self.tr("Restart EasyGraph to apply the language change."),
        )

    def eventFilter(self, watched, event) -> bool:
        table_editor_event = isinstance(watched, QLineEdit) and self.table.isAncestorOf(watched)
        if event.type() == QEvent.KeyPress and (self._table_or_child_has_focus() or table_editor_event):
            if self.handle_table_editor_navigation(event, watched):
                return True
            if event.matches(QKeySequence.Undo):
                self.undo_table_change()
                return True
            if event.matches(QKeySequence.Redo):
                self.redo_table_change()
                return True
            if event.matches(QKeySequence.Copy):
                self.copy_table_selection()
                return True
            if event.matches(QKeySequence.Paste):
                self.paste_table_selection()
                return True
            if event.matches(QKeySequence.Cut):
                self.cut_table_selection()
                return True
            if event.matches(QKeySequence.Delete):
                self.clear_table_selection()
                return True
        return super().eventFilter(watched, event)

    def _table_or_child_has_focus(self) -> bool:
        focus = QApplication.focusWidget()
        return focus is self.table or self.table.isAncestorOf(focus)

    def handle_table_editor_navigation(self, event: QKeyEvent, editor: QWidget | None = None) -> bool:
        if not isinstance(editor, QLineEdit) or not self.table.isAncestorOf(editor):
            editor = QApplication.focusWidget()
        if not isinstance(editor, QLineEdit) or not self.table.isAncestorOf(editor):
            return False
        modifiers = event.modifiers() & ~Qt.KeypadModifier
        if modifiers != Qt.NoModifier:
            return False

        moves = {
            Qt.Key_Left: (0, -1),
            Qt.Key_Right: (0, 1),
            Qt.Key_Up: (-1, 0),
            Qt.Key_Down: (1, 0),
            Qt.Key_Return: (1, 0),
            Qt.Key_Enter: (1, 0),
        }
        move = moves.get(event.key())
        if move is None:
            return False

        row = self.table.currentRow()
        col = self.table.currentColumn()
        next_row = row + move[0]
        next_col = col + move[1]
        if not (0 <= next_row < self.table.rowCount() and 0 <= next_col < self.table.columnCount()):
            return False

        item = self.table.item(row, col)
        if item is None:
            item = QTableWidgetItem("")
            self.table.setItem(row, col, item)
        before = self.table_snapshot()
        self._table_history_suspended = True
        try:
            item.setText(editor.text())
        finally:
            self._table_history_suspended = False

        self.table.setCurrentCell(next_row, next_col)
        next_item = self.table.item(next_row, next_col)
        if next_item is None:
            next_item = QTableWidgetItem("")
            self.table.setItem(next_row, next_col, next_item)
        QTimer.singleShot(0, lambda item=next_item: self.table.editItem(item))
        self.record_table_history_change(before)
        return True

    def table_snapshot(self) -> dict:
        return {
            "cells": [
                [
                    self.table.item(row, col).text() if self.table.item(row, col) else ""
                    for col in range(self.table.columnCount())
                ]
                for row in range(self.table.rowCount())
            ],
            "current_row": self.table.currentRow(),
            "current_col": self.table.currentColumn(),
            "custom_overlay_rows": self._custom_overlay_rows,
            "custom_overlay_series": deepcopy(self.settings.custom_overlay_series),
            "custom_overlay_count": self.settings.custom_overlay_count,
            "extra_custom_overlay": self.settings.extra_custom_overlay,
            "custom_overlay_hidden": list(self.settings.custom_overlay_hidden),
            "custom_overlay_styles": dict(self.settings.custom_overlay_styles),
            "manual_group_order": list(self.settings.manual_group_order),
            "group_hidden": list(self.settings.group_hidden),
        }

    def restore_table_snapshot(self, snapshot: dict) -> None:
        cells = snapshot.get("cells", [])
        row_count = len(cells)
        col_count = max((len(row) for row in cells), default=0)
        self._table_history_restoring = True
        was_blocked = self.table.signalsBlocked()
        self.table.blockSignals(True)
        try:
            self._custom_overlay_rows = int(snapshot.get("custom_overlay_rows", 0))
            self.settings.custom_overlay_series = deepcopy(snapshot.get("custom_overlay_series", []))
            self.settings.custom_overlay_count = int(snapshot.get("custom_overlay_count", max(1, len(self.settings.custom_overlay_series))))
            self.settings.extra_custom_overlay = bool(snapshot.get("extra_custom_overlay", bool(self.settings.custom_overlay_series)))
            self.settings.custom_overlay_hidden = list(snapshot.get("custom_overlay_hidden", []))
            self.settings.custom_overlay_styles = dict(snapshot.get("custom_overlay_styles", {}))
            self.settings.manual_group_order = list(snapshot.get("manual_group_order", []))
            self.settings.group_hidden = list(snapshot.get("group_hidden", []))
            self.table.setRowCount(row_count)
            self.table.setColumnCount(col_count)
            for row in range(row_count):
                for col in range(col_count):
                    value = cells[row][col] if col < len(cells[row]) else ""
                    self.table.setItem(row, col, QTableWidgetItem(value))
            row = min(max(int(snapshot.get("current_row", 0)), 0), max(row_count - 1, 0))
            col = min(max(int(snapshot.get("current_col", 0)), 0), max(col_count - 1, 0))
            if row_count and col_count:
                self.table.setCurrentCell(row, col)
            self.update_column_headers()
            self.style_table_rows()
            self.update_table_header_height()
            self.update_row_headers()
            self.sync_manual_group_order()
        finally:
            self.table.blockSignals(was_blocked)
            self._table_history_restoring = False
        self._sync_custom_overlay_visibility()
        self._sync_custom_overlay_visibility_to_controls()
        self.render()

    def reset_table_history(self) -> None:
        self._table_undo_stack = []
        self._table_redo_stack = []
        self._last_table_snapshot = self.table_snapshot()
        self.update_table_history_actions()

    def record_table_history_change(self, before: dict | None = None) -> None:
        if self._table_history_restoring or self._table_history_suspended:
            return
        before = before if before is not None else self._last_table_snapshot
        after = self.table_snapshot()
        if before is not None and before != after:
            self._table_undo_stack.append(deepcopy(before))
            self._table_undo_stack = self._table_undo_stack[-100:]
            self._table_redo_stack = []
            self._last_table_snapshot = deepcopy(after)
        else:
            self._last_table_snapshot = deepcopy(after)
        self.update_table_history_actions()

    def update_table_history_actions(self) -> None:
        if hasattr(self, "undo_table_action"):
            self.undo_table_action.setEnabled(bool(self._table_undo_stack))
        if hasattr(self, "redo_table_action"):
            self.redo_table_action.setEnabled(bool(self._table_redo_stack))

    def undo_table_change(self) -> None:
        if not self._table_undo_stack:
            return
        current = self.table_snapshot()
        snapshot = self._table_undo_stack.pop()
        self._table_redo_stack.append(deepcopy(current))
        self.restore_table_snapshot(snapshot)
        self._last_table_snapshot = self.table_snapshot()
        self.update_table_history_actions()

    def redo_table_change(self) -> None:
        if not self._table_redo_stack:
            return
        current = self.table_snapshot()
        snapshot = self._table_redo_stack.pop()
        self._table_undo_stack.append(deepcopy(current))
        self.restore_table_snapshot(snapshot)
        self._last_table_snapshot = self.table_snapshot()
        self.update_table_history_actions()

    def _sync_custom_overlay_visibility_to_controls(self) -> None:
        if not hasattr(self, "extra_custom_overlay"):
            return
        self.extra_custom_overlay.blockSignals(True)
        self.custom_overlay_count.blockSignals(True)
        try:
            self.extra_custom_overlay.setChecked(self.settings.extra_custom_overlay)
            self.custom_overlay_count.setValue(max(1, len(self.settings.custom_overlay_series), self.settings.custom_overlay_count))
        finally:
            self.custom_overlay_count.blockSignals(False)
            self.extra_custom_overlay.blockSignals(False)
        self._sync_custom_overlay_visibility()
        self._update_dependent_control_states()

    def set_table_dataframe(self, df: pd.DataFrame, overlay_series: list[dict] | None = None) -> None:
        overlay_series = overlay_series if overlay_series is not None else self.settings.custom_overlay_series
        overlay_series = list(overlay_series)
        self.table.blockSignals(True)
        try:
            self._custom_overlay_rows = len(overlay_series)
            self.table.setRowCount(len(df) + len(overlay_series) + 1)
            self.table.setColumnCount(len(df.columns))
            self.update_column_headers()
            for c, col in enumerate(df.columns):
                self.table.setItem(0, c, QTableWidgetItem(str(col)))
            self.update_table_header_height()
            for r, series in enumerate(overlay_series):
                values = series.get("values", {}) if isinstance(series, dict) else {}
                for c, col in enumerate(df.columns):
                    value = values.get(str(col), "") if isinstance(values, dict) else ""
                    self.table.setItem(r + 1, c, QTableWidgetItem("" if pd.isna(value) else str(value)))
            sample_start = self.sample_start_row()
            for r in range(len(df)):
                for c, col in enumerate(df.columns):
                    value = df.iloc[r, c]
                    text = "" if pd.isna(value) else str(value)
                    self.table.setItem(sample_start + r, c, QTableWidgetItem(text))
            self.style_table_rows()
            self.update_row_headers()
        finally:
            self.table.blockSignals(False)

    def table_dataframe(self) -> pd.DataFrame:
        headers = [
            self.group_name_at(c)
            for c in range(self.table.columnCount())
        ]
        data = []
        for r in range(self.sample_start_row(), self.table.rowCount()):
            row = []
            for c in range(self.table.columnCount()):
                item = self.table.item(r, c)
                row.append(item.text() if item else "")
            data.append(row)
        return pd.DataFrame(data, columns=headers)

    def custom_overlay_row_count(self) -> int:
        return self._custom_overlay_rows

    def sample_start_row(self) -> int:
        return 1 + self._custom_overlay_rows

    def custom_overlay_series_from_table(self) -> list[dict]:
        if self.custom_overlay_row_count() == 0:
            return list(self.settings.custom_overlay_series)
        groups = self.table_group_names()
        series = []
        for row in range(1, min(self.sample_start_row(), self.table.rowCount())):
            header = self.table.verticalHeaderItem(row)
            name = header.text().strip() if header and header.text().strip() else f"Overlay {row}"
            values = {}
            for col, group in enumerate(groups):
                item = self.table.item(row, col)
                values[str(group)] = item.text() if item else ""
            series.append({"name": name, "values": values})
        return series

    def sync_custom_overlay_rows(self, sample_df: pd.DataFrame | None = None, existing_series: list[dict] | None = None) -> None:
        target_count = len(self.settings.custom_overlay_series)
        if existing_series is not None:
            target_count = len(existing_series)
        if self.custom_overlay_row_count() == target_count:
            self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
            self.settings.custom_overlay_count = max(1, len(self.settings.custom_overlay_series))
            self._sync_custom_overlay_visibility()
            self.update_row_headers()
            self.style_table_rows()
            return
        df = sample_df if sample_df is not None else self.table_dataframe()
        existing = existing_series if existing_series is not None else self.custom_overlay_series_from_table()
        self.settings.custom_overlay_series = list(existing)
        self.settings.custom_overlay_count = max(1, len(self.settings.custom_overlay_series))
        self._sync_custom_overlay_visibility()
        self.set_table_dataframe(df, self.settings.custom_overlay_series)

    def _sync_custom_overlay_visibility(self) -> None:
        count = len(self.settings.custom_overlay_series)
        hidden = {
            int(index)
            for index in self.settings.custom_overlay_hidden
            if isinstance(index, int) or str(index).lstrip("-").isdigit()
        }
        self.settings.custom_overlay_hidden = sorted(index for index in hidden if 0 <= index < count)

    def update_row_headers(self) -> None:
        labels = [""]
        for row in range(1, self.sample_start_row()):
            series_index = row - 1
            name = "Overlay"
            if series_index < len(self.settings.custom_overlay_series):
                name = str(self.settings.custom_overlay_series[series_index].get("name", "")).strip()
            labels.append(name or f"Overlay {series_index + 1}")
        sample_count = max(0, self.table.rowCount() - self.sample_start_row())
        labels.extend(str(index + 1) for index in range(sample_count))
        self.table.setVerticalHeaderLabels(labels)
        self.table.verticalHeader().setMinimumWidth(86 if self.custom_overlay_row_count() else 34)

    def table_selection_tsv(self) -> str:
        ranges = self.table.selectedRanges()
        if not ranges:
            return ""
        selected = ranges[0]
        rows = []
        for row in range(selected.topRow(), selected.bottomRow() + 1):
            values = []
            for col in range(selected.leftColumn(), selected.rightColumn() + 1):
                item = self.table.item(row, col)
                values.append(item.text() if item else "")
            rows.append(values)
        buffer = StringIO()
        writer = csv.writer(buffer, delimiter="\t", lineterminator="\n")
        writer.writerows(rows)
        return buffer.getvalue().rstrip("\n")

    def copy_table_selection(self) -> None:
        text = self.table_selection_tsv()
        if text:
            QApplication.clipboard().setText(text)

    def cut_table_selection(self) -> None:
        text = self.table_selection_tsv()
        if not text:
            return
        QApplication.clipboard().setText(text)
        self.clear_table_selection()

    def table_context_menu(self) -> QMenu:
        has_selection = bool(self.table.selectedRanges())
        menu = QMenu(self.table)
        copy_action = menu.addAction(self.tr("Copy"))
        copy_action.setShortcut(QKeySequence.Copy)
        copy_action.setEnabled(has_selection)
        copy_action.triggered.connect(self.copy_table_selection)
        paste_action = menu.addAction(self.tr("Paste"))
        paste_action.setShortcut(QKeySequence.Paste)
        paste_action.triggered.connect(self.paste_table_selection)
        cut_action = menu.addAction(self.tr("Cut"))
        cut_action.setShortcut(QKeySequence.Cut)
        cut_action.setEnabled(has_selection)
        cut_action.triggered.connect(self.cut_table_selection)
        return menu

    def show_table_context_menu(self, position) -> None:
        item = self.table.itemAt(position)
        if item is not None and not item.isSelected():
            self.table.setCurrentCell(item.row(), item.column())

        menu = self.table_context_menu()
        menu.exec(self.table.viewport().mapToGlobal(position))

    def paste_table_selection(self) -> None:
        text = QApplication.clipboard().text()
        if not text:
            return
        rows = list(csv.reader(StringIO(text), delimiter="\t"))
        if not rows:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True

        try:
            start_row = self.table.currentRow()
            start_col = self.table.currentColumn()
            if start_row < 0:
                start_row = 0
            if start_col < 0:
                start_col = 0

            needed_rows = start_row + len(rows)
            needed_cols = start_col + max(len(row) for row in rows)
            while self.table.rowCount() < needed_rows:
                self.table.insertRow(self.table.rowCount())
            while self.table.columnCount() < needed_cols:
                col = self.table.columnCount()
                self.table.insertColumn(col)
                self.table.setItem(0, col, QTableWidgetItem(f"Group {col + 1}"))
            self.update_column_headers()

            was_blocked = self.table.signalsBlocked()
            self.table.blockSignals(True)
            try:
                for r, row_values in enumerate(rows):
                    for c, value in enumerate(row_values):
                        self.table.setItem(start_row + r, start_col + c, QTableWidgetItem(value))
            finally:
                self.table.blockSignals(was_blocked)
            self.style_group_name_row()
            self.update_table_header_height()
            self.update_row_headers()
            self.sync_manual_group_order()
            self.render()
        finally:
            self._table_history_suspended = False
        self.record_table_history_change(before)

    def clear_table_selection(self) -> None:
        selected = self.table.selectedItems()
        if not selected:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True
        self.table.blockSignals(True)
        try:
            for item in selected:
                item.setText("")
        finally:
            self.table.blockSignals(False)
            self._table_history_suspended = False
        self.render()
        self.record_table_history_change(before)

    def update_table_header_height(self) -> None:
        max_lines = 1
        for col in range(self.table.columnCount()):
            item = self.table.item(0, col)
            if item is not None:
                max_lines = max(max_lines, item.text().count("\n") + 1)
        metrics = self.table.fontMetrics()
        height = metrics.lineSpacing() * max_lines + 14
        self.table.setRowHeight(0, height)

    def update_column_headers(self) -> None:
        self.table.setHorizontalHeaderLabels([str(col + 1) for col in range(self.table.columnCount())])

    def group_name_at(self, col: int) -> str:
        item = self.table.item(0, col)
        name = item.text().strip() if item else ""
        return name or f"Group {col + 1}"

    def style_group_name_row(self) -> None:
        self.style_table_rows()

    def style_table_rows(self) -> None:
        was_blocked = self.table.signalsBlocked()
        self.table.blockSignals(True)
        try:
            if self.table.rowCount() == 0:
                self.table.setRowCount(1)
            header_font = QFont(self.table.font())
            header_font.setBold(True)
            background = QBrush(QColor("#3E4A56"))
            foreground = QBrush(QColor("#F3F4F6"))
            for col in range(self.table.columnCount()):
                item = self.table.item(0, col)
                if item is None:
                    item = QTableWidgetItem(f"Group {col + 1}")
                    self.table.setItem(0, col, item)
                item.setFont(header_font)
                item.setBackground(background)
                item.setForeground(foreground)
                item.setTextAlignment(Qt.AlignCenter)
            overlay_font = QFont(self.table.font())
            overlay_font.setBold(True)
            palette = self.table.palette()
            base_color = palette.color(QPalette.ColorRole.Base)
            highlight_color = palette.color(QPalette.ColorRole.Highlight)
            text_color = palette.color(QPalette.ColorRole.Text)
            overlay_background = QBrush(blend_qcolors(base_color, highlight_color, 0.18))
            overlay_foreground = QBrush(text_color)
            sample_font = QFont(self.table.font())
            for row in range(1, self.table.rowCount()):
                is_overlay = row < self.sample_start_row()
                for col in range(self.table.columnCount()):
                    item = self.table.item(row, col)
                    if item is None:
                        item = QTableWidgetItem("")
                        self.table.setItem(row, col, item)
                    item.setFont(overlay_font if is_overlay else sample_font)
                    item.setBackground(overlay_background if is_overlay else QBrush())
                    item.setForeground(overlay_foreground if is_overlay else QBrush())
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        finally:
            self.table.blockSignals(was_blocked)

    def table_group_names(self) -> list[str]:
        return [
            self.group_name_at(col)
            for col in range(self.table.columnCount())
        ]

    def sync_manual_group_order(self) -> None:
        columns = self.table_group_names()
        existing = [group for group in self.settings.manual_group_order if group in columns]
        existing.extend(group for group in columns if group not in existing)
        self.settings.manual_group_order = existing
        self.settings.group_hidden = [
            group for group in self.settings.group_hidden if group in {str(column) for column in columns}
        ]

    def edit_group_order(self) -> None:
        self.sync_manual_group_order()
        dialog = QDialog(self)
        ui = Ui_GroupOrderDialog()
        ui.setupUi(dialog)

        def populate(groups: list[str]) -> None:
            ui.groupList.clear()
            for group in groups:
                ui.groupList.addItem(group)

        populate(self.settings.manual_group_order)
        ui.tableOrderButton.clicked.connect(lambda: populate(self.table_group_names()))
        if dialog.exec() == QDialog.Accepted:
            self.settings.manual_group_order = [
                ui.groupList.item(row).text() for row in range(ui.groupList.count())
            ]
            self.group_order.setCurrentText("Manual")
            self.render()

    def edit_group_filter(self) -> None:
        self.sync_manual_group_order()
        groups = [str(group) for group in self.table_group_names()]
        if not groups:
            QMessageBox.information(
                self,
                self.tr("Group Filter"),
                self.tr("Add a group first."),
            )
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(self.tr("Group Filter"))
        layout = QVBoxLayout(dialog)
        list_widget = QListWidget(dialog)
        hidden = hidden_group_names(self.settings)
        for group in groups:
            item = QListWidgetItem(group)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked if group in hidden else Qt.Checked)
            list_widget.addItem(item)
        layout.addWidget(list_widget)
        button_row = QHBoxLayout()
        button_row.addStretch()
        cancel_button = QPushButton(self.tr("Cancel"), dialog)
        ok_button = QPushButton(self.tr("OK"), dialog)
        button_row.addWidget(cancel_button)
        button_row.addWidget(ok_button)
        layout.addLayout(button_row)
        cancel_button.clicked.connect(dialog.reject)
        ok_button.clicked.connect(dialog.accept)
        if dialog.exec() != QDialog.Accepted:
            return
        self.settings.group_hidden = [
            list_widget.item(index).text()
            for index in range(list_widget.count())
            if list_widget.item(index).checkState() != Qt.Checked
        ]
        self.render()

    def edit_group_colors(self) -> None:
        groups = unique_groups(self.table_group_names())
        if not groups:
            return
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        overlay_items = overlay_color_items(self.table.dataframe(), self.settings)
        color_items = [
            {"key": str(group), "label": str(group), "palette_index": index, "kind": "group"}
            for index, group in enumerate(groups)
        ]
        color_items.extend(
            {
                "key": key,
                "label": self.tr("Overlay: {name}").format(name=name),
                "palette_index": len(groups) + overlay_palette_slot_for_color_key(self.settings, key, index),
                "kind": "overlay",
            }
            for index, (key, name) in enumerate(overlay_items)
        )

        original_preset = self.settings.preset
        original_custom_colors = dict(self.settings.custom_colors)
        original_custom_overlay_palette = self.settings.custom_overlay_palette
        original_custom_overlay_colors = dict(self.settings.custom_overlay_colors)
        selected_preset = self.settings.preset
        selected_overlay_preset = self.settings.custom_overlay_palette if self.settings.custom_overlay_palette in PRESETS else DEFAULT_OVERLAY_PALETTE
        selected_colors = dict(self.settings.custom_colors)
        selected_overlay_colors = dict(self.settings.custom_overlay_colors)
        valid_group_keys = {str(group) for group in groups}
        valid_overlay_keys = {key for key, _label in overlay_items}
        dialog = QDialog(self)
        dialog.setWindowTitle(self.tr("Edit Group Colors"))
        layout = QVBoxLayout(dialog)

        palette_row = QHBoxLayout()
        palette_row.addWidget(QLabel(self.tr("Palette")))
        palette_combo = QComboBox()
        palette_combo.addItems(list(PRESETS))
        palette_combo.setCurrentText(selected_preset)
        self._polish_combo_box(palette_combo)
        palette_row.addWidget(palette_combo)
        palette_row.addStretch()
        layout.addLayout(palette_row)

        overlay_palette_combo = None
        if overlay_items:
            overlay_palette_row = QHBoxLayout()
            overlay_palette_row.addWidget(QLabel(self.tr("Overlay palette")))
            overlay_palette_combo = QComboBox()
            overlay_palette_combo.addItems(list(PRESETS))
            overlay_palette_combo.setCurrentText(selected_overlay_preset)
            self._polish_combo_box(overlay_palette_combo)
            overlay_palette_row.addWidget(overlay_palette_combo)
            overlay_palette_row.addStretch()
            layout.addLayout(overlay_palette_row)

        palette_cache: dict[str, list[str]] = {}
        overlay_palette_cache: dict[tuple[str, int], list[str]] = {}

        def current_palette() -> list[str]:
            if selected_preset not in palette_cache:
                palette_cache[selected_preset] = palette_choices_for_group_count(selected_preset, len(groups))
            return palette_cache[selected_preset]

        def current_overlay_palette() -> list[str]:
            overlay_slots = [
                int(item["palette_index"]) - len(groups)
                for item in color_items
                if item["kind"] == "overlay"
            ]
            overlay_count = max(overlay_slots, default=0) + 1
            cache_key = (selected_overlay_preset, overlay_count)
            if cache_key not in overlay_palette_cache:
                overlay_palette_cache[cache_key] = palette_choices_for_group_count(selected_overlay_preset, overlay_count)
            return overlay_palette_cache[cache_key]

        def palette_for_item(item: dict) -> list[str]:
            return current_overlay_palette() if item["kind"] == "overlay" else current_palette()

        def color_for_item(item: dict) -> str:
            key = str(item["key"])
            selected = selected_overlay_colors if item["kind"] == "overlay" else selected_colors
            if item["kind"] == "overlay":
                color_map = overlay_color_map_for_keys(
                    all_overlay_color_keys(self.settings),
                    self.settings,
                    custom_overlay_colors=selected_overlay_colors,
                    overlay_preset=selected_overlay_preset,
                )
                if key in color_map:
                    return color_map[key]
                palette = palette_for_item(item)
                palette_index = int(item["palette_index"]) - len(groups)
                return selected.get(key, palette[palette_index % len(palette)])
            color_map = group_color_map_for_groups(
                groups,
                self.settings,
                custom_colors=selected_colors,
                preset_name=selected_preset,
            )
            if key in color_map:
                return color_map[key]
            palette = palette_for_item(item)
            palette_index = int(item["palette_index"])
            return selected.get(key, palette[palette_index % len(palette)])

        def style_swatch(button: QPushButton, color: str, selected: bool = False) -> None:
            border = "#111827" if selected else "#D1D5DB"
            button.setFixedSize(24, 24)
            button.setText("")
            button.setStyleSheet(f"QPushButton {{ background: {color}; border: 2px solid {border}; border-radius: 4px; }}")

        def sync_main_preset_combo(preset: str) -> None:
            self.preset.blockSignals(True)
            try:
                self.preset.setCurrentText(preset)
            finally:
                self.preset.blockSignals(False)

        def apply_preview() -> None:
            self.settings.preset = selected_preset
            self.settings.custom_colors = {
                group: color
                for group, color in selected_colors.items()
                if group in valid_group_keys
            }
            self.settings.custom_overlay_colors = dict(selected_overlay_colors)
            self.settings.custom_overlay_palette = selected_overlay_preset
            sync_main_preset_combo(selected_preset)
            self.render()

        swatches: dict[str, list[tuple[int, QPushButton]]] = {}
        current_buttons: dict[str, QPushButton] = {}
        rows_container = QWidget()
        rows_layout = QVBoxLayout(rows_container)
        rows_layout.setContentsMargins(0, 0, 0, 0)
        rows_layout.setSpacing(6)
        rows_scroll = QScrollArea()
        rows_scroll.setWidgetResizable(True)
        rows_scroll.setMinimumWidth(460)
        rows_scroll.setMinimumHeight(220)
        rows_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        rows_scroll.setWidget(rows_container)
        layout.addWidget(rows_scroll, 1)

        def refresh_item(item: dict, palette: list[str] | None = None) -> None:
            if palette is None:
                palette = palette_for_item(item)
            key = str(item["key"])
            active_color = color_for_item(item)
            for color_index, button in swatches[key]:
                color = palette[color_index % len(palette)]
                style_swatch(button, color, selected=active_color == color)
            current_buttons[key].setStyleSheet(
                f"QPushButton {{ background: {active_color}; border: 1px solid #6B7280; border-radius: 4px; }}"
            )

        def refresh_all_items() -> None:
            for item in color_items:
                refresh_item(item)

        for item in color_items:
            row = QHBoxLayout()
            name_label = QLabel(str(item["label"]))
            name_label.setMinimumWidth(120)
            row.addWidget(name_label)
            current_button = QPushButton()
            current_button.setEnabled(False)
            current_button.setFixedSize(34, 24)
            key = str(item["key"])
            current_buttons[key] = current_button
            row.addWidget(current_button)
            swatches[key] = []
            swatch_grid = QGridLayout()
            swatch_grid.setContentsMargins(0, 0, 0, 0)
            swatch_grid.setHorizontalSpacing(5)
            swatch_grid.setVerticalSpacing(5)

            for color_index, _color in enumerate(palette_for_item(item)):
                button = QPushButton()
                swatches[key].append((color_index, button))

                def choose_color(_checked=False, *, item_key=key, item_kind=str(item["kind"]), selected_index=color_index) -> None:
                    palette = current_overlay_palette() if item_kind == "overlay" else current_palette()
                    chosen = palette[selected_index % len(palette)]
                    if item_kind == "overlay":
                        selected_overlay_colors[item_key] = chosen
                    else:
                        selected_colors[item_key] = chosen
                    apply_preview()
                    refresh_all_items()

                button.clicked.connect(choose_color)
                swatch_grid.addWidget(button, color_index // 8, color_index % 8)

            row.addLayout(swatch_grid)

            reset_button = QPushButton(self.tr("Reset"))

            def reset_color(_checked=False, *, item_key=key, item_kind=str(item["kind"])) -> None:
                if item_kind == "overlay":
                    selected_overlay_colors.pop(item_key, None)
                else:
                    selected_colors.pop(item_key, None)
                apply_preview()
                refresh_all_items()

            reset_button.clicked.connect(reset_color)
            row.addWidget(reset_button)
            row.addStretch()
            rows_layout.addLayout(row)
            refresh_item(item)
        rows_layout.addStretch()

        def choose_palette(preset: str) -> None:
            nonlocal selected_preset
            if preset not in PRESETS:
                return
            selected_preset = preset
            selected_colors.clear()
            apply_preview()
            refresh_all_items()

        palette_combo.currentTextChanged.connect(choose_palette)

        def choose_overlay_palette(preset: str) -> None:
            nonlocal selected_overlay_preset
            if preset not in PRESETS:
                return
            selected_overlay_preset = preset
            selected_overlay_colors.clear()
            apply_preview()
            refresh_all_items()

        if overlay_palette_combo is not None:
            overlay_palette_combo.currentTextChanged.connect(choose_overlay_palette)

        button_row = QHBoxLayout()
        button_row.addStretch()
        cancel_button = QPushButton(self.tr("Cancel"))
        ok_button = QPushButton(self.tr("OK"))
        cancel_button.clicked.connect(dialog.reject)
        ok_button.clicked.connect(dialog.accept)
        button_row.addWidget(cancel_button)
        button_row.addWidget(ok_button)
        layout.addLayout(button_row)

        if dialog.exec() == QDialog.Accepted:
            apply_preview()
        else:
            self.settings.preset = original_preset
            self.settings.custom_colors = original_custom_colors
            self.settings.custom_overlay_palette = original_custom_overlay_palette
            self.settings.custom_overlay_colors = original_custom_overlay_colors
            sync_main_preset_combo(original_preset)
            self.render()

    def _connect_table(self) -> None:
        self.table.itemChanged.connect(self.handle_table_item_changed)
        self.table.verticalHeader().sectionDoubleClicked.connect(self.rename_overlay_row)

    def refresh_template_combo(self, selected: str | None = None) -> None:
        current = self.template_combo.currentText() if selected is None else selected
        self.template_combo.blockSignals(True)
        self.template_combo.clear()
        self.template_combo.addItem(TEMPLATE_NONE_NAME)
        templates = list_style_templates()
        self.template_combo.addItems(templates)
        if current in [TEMPLATE_NONE_NAME, *templates]:
            self.template_combo.setCurrentText(current)
        else:
            self.template_combo.setCurrentText(TEMPLATE_NONE_NAME)
        self.template_combo.blockSignals(False)
        self._polish_template_combo_box()

    def apply_style_template(self, name: str, settings: ChartSettings) -> None:
        self.update_settings()
        self.settings = apply_style_template_settings(self.settings, settings, self.table_group_names())
        self.sync_manual_group_order()
        self.apply_settings_to_controls()
        self.render()
        self.statusBar().showMessage(self.tr("Style template applied: {name}").format(name=name), 2500)

    def apply_selected_template(self, name: str) -> None:
        if not name or name == TEMPLATE_NONE_NAME:
            return
        try:
            settings = read_style_template(name)
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template load failed"), str(exc))
            self.refresh_template_combo()
            return
        self.apply_style_template(name, settings)

    def handle_table_item_changed(self, item: QTableWidgetItem) -> None:
        if self._table_history_restoring:
            return
        if item.row() == 0:
            self.style_table_rows()
            self.update_table_header_height()
            self.sync_manual_group_order()
        if 0 < item.row() < self.sample_start_row():
            self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        self.render()
        self.record_table_history_change()

    def add_row(self) -> None:
        before = self.table_snapshot()
        self._table_history_suspended = True
        self.table.insertRow(self.table.rowCount())
        self.update_row_headers()
        self.style_table_rows()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def add_custom_overlay_row(self) -> None:
        before = self.table_snapshot()
        self._table_history_suspended = True
        self.settings.extra_custom_overlay = True
        self.extra_custom_overlay.setChecked(True)
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        self.settings.custom_overlay_series.append({"name": f"Overlay {len(self.settings.custom_overlay_series) + 1}", "values": {}})
        self.settings.custom_overlay_count = max(1, len(self.settings.custom_overlay_series))
        self.settings.extra_custom_overlay = True
        self._sync_custom_overlay_visibility()
        self.set_table_dataframe(self.table_dataframe(), self.settings.custom_overlay_series)
        row = self.sample_start_row() - 1
        if row > 0:
            self.table.setCurrentCell(row, 0)
        self._update_dependent_control_states()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def remove_custom_overlay_row(self) -> None:
        if self.custom_overlay_row_count() == 0:
            return
        row = self.table.currentRow()
        if not (0 < row < self.sample_start_row()):
            row = self.sample_start_row() - 1
        header = self.table.verticalHeaderItem(row)
        name = header.text() if header and header.text().strip() else f"Overlay {row}"
        answer = QMessageBox.warning(
            self,
            self.tr("Delete Overlay"),
            self.tr("Delete overlay '{name}'? Its values will be permanently lost.").format(name=name),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True
        sample_df = self.table_dataframe()
        series = self.custom_overlay_series_from_table()
        index = row - 1
        if 0 <= index < len(series):
            series.pop(index)
        hidden = []
        for hidden_index in self.settings.custom_overlay_hidden:
            if hidden_index == index:
                continue
            hidden.append(hidden_index - 1 if hidden_index > index else hidden_index)
        self.settings.custom_overlay_hidden = hidden
        self.settings.custom_overlay_series = series
        self.settings.custom_overlay_count = max(1, len(series))
        if not series:
            self.extra_custom_overlay.blockSignals(True)
            self.extra_custom_overlay.setChecked(False)
            self.extra_custom_overlay.blockSignals(False)
            self.settings.extra_custom_overlay = False
        self._sync_custom_overlay_visibility()
        self.set_table_dataframe(sample_df, self.settings.custom_overlay_series)
        self._update_dependent_control_states()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def edit_custom_overlay_filter(self) -> None:
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        if not self.settings.custom_overlay_series:
            QMessageBox.information(
                self,
                self.tr("Overlay Filter"),
                self.tr("Add an overlay row first."),
            )
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(self.tr("Overlay Filter"))
        layout = QVBoxLayout(dialog)
        list_widget = QListWidget(dialog)
        hidden = set(self.settings.custom_overlay_hidden)
        for index, series in enumerate(self.settings.custom_overlay_series):
            name = str(series.get("name", "")).strip() if isinstance(series, dict) else ""
            item = QListWidgetItem(name or f"Overlay {index + 1}")
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked if index in hidden else Qt.Checked)
            list_widget.addItem(item)
        layout.addWidget(list_widget)
        button_row = QHBoxLayout()
        button_row.addStretch()
        cancel_button = QPushButton(self.tr("Cancel"), dialog)
        ok_button = QPushButton(self.tr("OK"), dialog)
        button_row.addWidget(cancel_button)
        button_row.addWidget(ok_button)
        layout.addLayout(button_row)
        cancel_button.clicked.connect(dialog.reject)
        ok_button.clicked.connect(dialog.accept)
        if dialog.exec() != QDialog.Accepted:
            return
        self.settings.custom_overlay_hidden = [
            index
            for index in range(list_widget.count())
            if list_widget.item(index).checkState() != Qt.Checked
        ]
        self.extra_custom_overlay.setChecked(any(index not in self.settings.custom_overlay_hidden for index in range(list_widget.count())))
        self.settings.extra_custom_overlay = self.extra_custom_overlay.isChecked()
        self._sync_custom_overlay_visibility()
        self._update_dependent_control_states()
        self.render()

    def edit_custom_overlay_styles(self) -> None:
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        style_items = overlay_style_items(self.table.dataframe(), self.settings)
        if not style_items:
            QMessageBox.information(
                self,
                self.tr("Custom Overlay Line Styles"),
                self.tr("Add an overlay row first."),
            )
            return

        original_styles = dict(self.settings.custom_overlay_styles)
        selected_styles = dict(self.settings.custom_overlay_styles)
        valid_keys = {key for key, _label in style_items}
        dialog = QDialog(self)
        dialog.setWindowTitle(self.tr("Custom Overlay Line Styles"))
        layout = QVBoxLayout(dialog)

        def apply_preview() -> None:
            self.settings.custom_overlay_styles = {
                key: style
                for key, style in selected_styles.items()
                if key in valid_keys and style in LINE_OVERLAY_STYLES
            }
            self.render()

        rows_container = QWidget()
        rows_layout = QVBoxLayout(rows_container)
        rows_layout.setContentsMargins(0, 0, 0, 0)
        rows_layout.setSpacing(6)
        rows_scroll = QScrollArea()
        rows_scroll.setWidgetResizable(True)
        rows_scroll.setMinimumWidth(360)
        rows_scroll.setMinimumHeight(160)
        rows_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        rows_scroll.setWidget(rows_container)
        layout.addWidget(rows_scroll, 1)

        for key, name in style_items:
            row = QHBoxLayout()
            name_label = QLabel(self.tr("Overlay: {name}").format(name=name))
            name_label.setMinimumWidth(140)
            row.addWidget(name_label)
            style_combo = QComboBox()
            self._populate_line_style_combo(style_combo)
            style_combo.setCurrentText(custom_overlay_style_for_key(self.settings, key))
            self._polish_combo_box(style_combo)

            def choose_style(style: str, *, item_key=key) -> None:
                if style == self.settings.line_overlay_style:
                    selected_styles.pop(item_key, None)
                else:
                    selected_styles[item_key] = style
                apply_preview()

            style_combo.currentTextChanged.connect(choose_style)
            row.addWidget(style_combo)
            reset_button = QPushButton(self.tr("Reset"))

            def reset_style(_checked=False, *, item_key=key, combo=style_combo) -> None:
                selected_styles.pop(item_key, None)
                combo.blockSignals(True)
                try:
                    combo.setCurrentText(self.settings.line_overlay_style)
                finally:
                    combo.blockSignals(False)
                apply_preview()

            reset_button.clicked.connect(reset_style)
            row.addWidget(reset_button)
            row.addStretch()
            rows_layout.addLayout(row)
        rows_layout.addStretch()

        button_row = QHBoxLayout()
        button_row.addStretch()
        cancel_button = QPushButton(self.tr("Cancel"), dialog)
        ok_button = QPushButton(self.tr("OK"), dialog)
        button_row.addWidget(cancel_button)
        button_row.addWidget(ok_button)
        layout.addLayout(button_row)
        cancel_button.clicked.connect(dialog.reject)
        ok_button.clicked.connect(dialog.accept)

        if dialog.exec() == QDialog.Accepted:
            apply_preview()
        else:
            self.settings.custom_overlay_styles = original_styles
            self.render()

    def rename_overlay_row(self, row: int) -> None:
        if not (0 < row < self.sample_start_row()):
            return
        current = self.table.verticalHeaderItem(row).text() if self.table.verticalHeaderItem(row) else f"Overlay {row}"
        name, ok = QInputDialog.getMultiLineText(self, self.tr("Rename Overlay"), self.tr("Legend name"), text=current)
        if not ok:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True
        name = name.strip() or f"Overlay {row}"
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        index = row - 1
        while len(self.settings.custom_overlay_series) <= index:
            self.settings.custom_overlay_series.append({"name": f"Overlay {len(self.settings.custom_overlay_series) + 1}", "values": {}})
        self.settings.custom_overlay_series[index]["name"] = name
        self.update_row_headers()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def add_column(self) -> None:
        before = self.table_snapshot()
        self._table_history_suspended = True
        col = self.table.columnCount()
        self.table.insertColumn(col)
        self.table.setItem(0, col, QTableWidgetItem(f"Group {col + 1}"))
        self.update_column_headers()
        self.style_group_name_row()
        self.update_table_header_height()
        self.update_row_headers()
        self.sync_manual_group_order()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def delete_column(self) -> None:
        col = self.table.currentColumn()
        if col < 0:
            col = self.table.columnCount() - 1
        if col < 0:
            return
        before = self.table_snapshot()
        self._table_history_suspended = True
        self.table.removeColumn(col)
        self.update_column_headers()
        self.update_table_header_height()
        self.update_row_headers()
        self.sync_manual_group_order()
        self.render()
        self._table_history_suspended = False
        self.record_table_history_change(before)

    def rename_column(self) -> None:
        col = self.table.currentColumn()
        if col < 0:
            col = max(0, self.table.columnCount() - 1)
        if col < 0:
            return
        current = self.group_name_at(col)
        name, ok = QInputDialog.getMultiLineText(self, self.tr("Rename Group"), self.tr("Group name"), text=current)
        if ok and name.strip():
            before = self.table_snapshot()
            self._table_history_suspended = True
            new_name = name.strip()
            self.settings.manual_group_order = [
                new_name if group == current else group for group in self.settings.manual_group_order
            ]
            self.table.setItem(0, col, QTableWidgetItem(new_name))
            self.style_group_name_row()
            self.update_table_header_height()
            self.sync_manual_group_order()
            self.render()
            self._table_history_suspended = False
            self.record_table_history_change(before)

    def update_settings(self, *_args) -> None:
        if self._applying_settings:
            return
        self._commit_pending_control_edits()
        sample_df = self.table_dataframe()
        existing_overlay_series = self.custom_overlay_series_from_table()
        self.settings.chart_type = self.chart_type.currentText()
        self.settings.preset = self.preset.currentText()
        self.settings.group_order = self.group_order.currentText()
        self.sync_manual_group_order()
        self.settings.title = self.title.toPlainText()
        self.settings.x_label = self.x_label.toPlainText()
        self.settings.y_label = self.y_label.toPlainText()
        self.settings.secondary_y_label = self.secondary_y_label.toPlainText()
        self.settings.show_points = self.show_points.isChecked()
        self.settings.point_size = self.point_size.value()
        self.settings.point_alpha = self.point_alpha.value()
        self.settings.jitter_mode = self.jitter_mode.currentText()
        self.settings.jitter = self.jitter.value()
        self.settings.line_overlay_stat = self.line_overlay_stat.currentText()
        self.settings.show_line_overlay = self.settings.line_overlay_stat != "None"
        self.settings.extra_custom_overlay = self.extra_custom_overlay.isChecked() and bool(existing_overlay_series)
        self.settings.custom_overlay_count = max(1, len(existing_overlay_series))
        if self.settings.extra_custom_overlay and len(self.settings.custom_overlay_hidden) >= len(existing_overlay_series):
            self.settings.custom_overlay_hidden = []
        self.settings.custom_overlay_secondary_axis = self.custom_overlay_secondary_axis.isChecked()
        self.sync_custom_overlay_rows(sample_df, existing_overlay_series)
        self.settings.line_overlay_width = self.line_overlay_width.value()
        self.settings.line_overlay_style = self.line_overlay_style.currentText()
        self.settings.line_overlay_point_size = self.line_overlay_point_size.value()
        self.settings.show_line_values = self.show_line_values.isChecked()
        self._refresh_line_value_position_options()
        self.settings.line_value_position = self.line_value_position.currentText()
        self.settings.custom_line_value_position = self.custom_line_value_position.currentText()
        self.settings.line_value_scientific = self.line_value_scientific.isChecked()
        self.settings.line_value_decimals = self.line_value_decimals.value()
        self.settings.line_value_font_size = self.line_value_font_size.value()
        self.settings.show_stat_table = self.show_stat_table.isChecked()
        for setting_name, _label in STAT_TABLE_OPTIONS:
            setattr(self.settings, setting_name, self._stat_table_option_checked(setting_name))
        restore_stored_stat_header = self.sender() in (self.chart_type, self.show_stat_table)
        stat_header_forced = self._sync_stat_table_header_control(restore_stored=restore_stored_stat_header)
        if not stat_header_forced:
            self.settings.show_stat_header = self.show_stat_header.isChecked()
        self.settings.stat_table_font_size = self.stat_table_font_size.value()
        self.settings.show_outliers = self.show_outliers.isChecked()
        self.settings.outlier_method = self.outlier_method.currentText()
        self.settings.outlier_threshold = self.outlier_threshold.value()
        self.settings.outlier_effect = self.outlier_effect.currentText()
        self.settings.width = self.width.value()
        self.settings.height = self.height.value()
        self.settings.dpi = self.dpi.value()
        self.settings.title_font_size = self.title_font_size.value()
        self.settings.axis_label_font_size = self.axis_label_font_size.value()
        self.settings.tick_font_size = self.tick_font_size.value()
        self.settings.show_legend = self.show_legend.isChecked()
        self.settings.legend_font_size = self.legend_font_size.value()
        self.settings.legend_width = self.legend_width.value()
        self.settings.legend_columns = self._legend_columns_control_value()
        self.settings.legend_auto_width = self.legend_auto_width.isChecked() and self.settings.legend_columns > 0
        previous_legend_position = self.settings.legend_position
        self.settings.legend_position = self._legend_position_control_value()
        if previous_legend_position != self.settings.legend_position and self.settings.legend_position == LEGEND_POSITION_INSIDE:
            self.settings.legend_inside_x = LEGEND_INSIDE_AUTO_POSITION
            self.settings.legend_inside_y = LEGEND_INSIDE_AUTO_POSITION
        self.settings.axis_line_width = self.axis_line_width.value()
        self.settings.show_grid = self.show_grid.isChecked()
        self.settings.x_tick_rotation = self.x_tick_rotation.value()
        self.settings.auto_y_range = self.auto_y_range.isChecked()
        self.settings.y_min = self.y_min.value()
        self.settings.y_max = self.y_max.value()
        self.settings.primary_auto_tick_interval = self.primary_auto_tick_interval.isChecked()
        self.settings.primary_tick_interval = self.primary_tick_interval.value()
        self.settings.secondary_auto_y_range = self.secondary_auto_y_range.isChecked()
        self.settings.secondary_y_min = self.secondary_y_min.value()
        self.settings.secondary_y_max = self.secondary_y_max.value()
        self.settings.secondary_auto_tick_interval = self.secondary_auto_tick_interval.isChecked()
        self.settings.secondary_tick_interval = self.secondary_tick_interval.value()
        self.settings.split_secondary_axis = self.split_secondary_axis.isChecked()
        self.settings.secondary_axis_split_ratio = self.secondary_axis_split_ratio.value()
        self.settings.transparent_background = self.transparent_background.isChecked()
        self.settings.fill_alpha = self.fill_alpha.value()
        self.settings.box_width = self.box_width.value()
        self.settings.box_whisker_mode = self.box_whisker_mode.currentText()
        self.settings.violin_width = self.violin_width.value()
        self.settings.kde_bandwidth = self.kde_bandwidth.value()
        self.settings.ridge_overlap = self.ridge_overlap.value()
        self._update_dependent_control_states()
        if self.sender() in (self.title, self.x_label, self.y_label, self.secondary_y_label):
            self.schedule_render(RenderMode.TEXT_ONLY)
        else:
            self.render()

    def _commit_pending_control_edits(self) -> None:
        if self._committing_control_edits:
            return
        self._committing_control_edits = True
        try:
            for spin_box in self._spin_boxes():
                spin_box.interpretText()
        finally:
            self._committing_control_edits = False

    def handle_preset_changed(self, *_args) -> None:
        if not self._applying_settings:
            self.settings.custom_colors = {}
            self.settings.custom_overlay_colors = {}
        self.update_settings()

    def schedule_render(self, mode: RenderMode = RenderMode.FULL) -> None:
        if mode == RenderMode.FULL or not self._render_timer.isActive():
            self._scheduled_render_mode = mode
        self._render_pending = True
        self._render_timer.start()

    def flush_pending_render(self) -> None:
        if not self._render_pending:
            return
        if self._render_timer.isActive():
            self._render_timer.stop()
        mode = self._scheduled_render_mode
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        if mode == RenderMode.TEXT_ONLY and self._render_text_only():
            return
        self.render()

    def _render_text_only(self) -> bool:
        if self.canvas.figure is None or self.canvas.canvas is None or not self.canvas.figure.axes:
            return False
        last_settings = getattr(self.canvas, "_last_settings", None)
        if last_settings is None or self._text_layout_signature(last_settings) != self._text_layout_signature(self.settings):
            return False
        ax = self.canvas.figure.axes[0]
        preset = PRESETS.get(self.settings.preset)
        if preset is None:
            return False
        text_color = "#F9FAFB" if preset["background"] != "#FFFFFF" else "#222222"
        x_axis_label, y_axis_label = axis_labels_for_chart(self.settings)
        custom_overlay_secondary_axis_active = self.canvas._custom_overlay_secondary_axis_active(self.settings)
        split_secondary_frame = self.canvas._split_secondary_frame_enabled(self.settings)
        ax.set_title("" if split_secondary_frame else self.settings.title, fontsize=self.settings.title_font_size, color=text_color)
        ax.set_xlabel(x_axis_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        ax.set_ylabel(y_axis_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        secondary_ax = self._secondary_axis_for_sync() if custom_overlay_secondary_axis_active else None
        if secondary_ax is not None:
            if self.settings.chart_type == "Ridge":
                if split_secondary_frame:
                    self.canvas._set_split_secondary_title(secondary_ax, ax, self.settings, text_color)
                secondary_ax.set_xlabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
            elif split_secondary_frame:
                self.canvas._set_split_secondary_title(secondary_ax, ax, self.settings, text_color)
                secondary_ax.set_xlabel("", fontsize=self.settings.axis_label_font_size, color=text_color)
                secondary_ax.set_ylabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
            else:
                secondary_ax.set_ylabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        self.canvas.canvas.draw_idle()
        return True

    def _text_layout_signature(
        self,
        settings: ChartSettings,
    ) -> tuple[tuple[int, bool], tuple[int, bool], tuple[int, bool], tuple[int, bool], tuple[int, int]]:
        x_axis_label, y_axis_label = axis_labels_for_chart(settings)

        def footprint(text: str) -> tuple[int, bool]:
            return (self.canvas._line_count(text), bool(text))

        y_overflow = 0
        x_overflow = 0
        if settings.chart_type in {"Box", "Violin"} and y_axis_label:
            label_height_in = self.canvas._max_text_width_inches([y_axis_label], settings.axis_label_font_size)
            y_overflow = max(0, int(math.ceil((label_height_in - settings.height / 2.54) * 100)))
            if self.canvas._custom_overlay_secondary_axis_active(settings) and settings.secondary_y_label:
                secondary_label_height_in = self.canvas._max_text_width_inches([settings.secondary_y_label], settings.axis_label_font_size)
                y_overflow = max(y_overflow, max(0, int(math.ceil((secondary_label_height_in - settings.height / 2.54) * 100))))
        if settings.chart_type == "Ridge" and x_axis_label:
            label_width_in = self.canvas._max_text_width_inches([x_axis_label], settings.axis_label_font_size)
            x_overflow = max(0, int(math.ceil((label_width_in - settings.width / 2.54) * 100)))
            if self.canvas._custom_overlay_secondary_axis_active(settings) and settings.secondary_y_label:
                secondary_label_width_in = self.canvas._max_text_width_inches([settings.secondary_y_label], settings.axis_label_font_size)
                x_overflow = max(x_overflow, max(0, int(math.ceil((secondary_label_width_in - settings.width / 2.54) * 100))))

        secondary_label = settings.secondary_y_label if self.canvas._custom_overlay_secondary_axis_active(settings) else ""
        return (
            footprint(settings.title),
            footprint(x_axis_label),
            footprint(y_axis_label),
            footprint(secondary_label),
            (y_overflow, x_overflow),
        )

    def render(self) -> None:
        if self._render_timer.isActive():
            self._render_timer.stop()
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        self.canvas.render(self.table.dataframe(), self.settings)
        self._sync_auto_y_axis_controls()
        self._sync_auto_tick_interval_controls()

    def _update_dependent_control_states(self) -> None:
        ridge_numeric_axis = self.chart_type.currentText() == "Ridge"
        value_axis_name = "X" if ridge_numeric_axis else "Y"
        self.ui.autoYLabel.setText(self.tr(f"Auto Primary {value_axis_name} Range"))
        self.ui.yMinLabel.setText(self.tr(f"Primary {value_axis_name} min"))
        self.ui.yMaxLabel.setText(self.tr(f"Primary {value_axis_name} max"))
        self.primary_auto_tick_interval_label.setText(self.tr(f"Auto Primary {value_axis_name} Tick Interval"))
        self.primary_tick_interval_label.setText(self.tr(f"Primary {value_axis_name} tick interval"))
        self.secondary_auto_y_range_label.setText(self.tr(f"Auto Secondary {value_axis_name} Range"))
        self.secondary_y_min_label.setText(self.tr(f"Secondary {value_axis_name} min"))
        self.secondary_y_max_label.setText(self.tr(f"Secondary {value_axis_name} max"))
        self.secondary_auto_tick_interval_label.setText(self.tr(f"Auto Secondary {value_axis_name} Tick Interval"))
        self.secondary_tick_interval_label.setText(self.tr(f"Secondary {value_axis_name} tick interval"))
        self.ui.xRotationLabel.setEnabled(not ridge_numeric_axis)
        self.x_tick_rotation.setEnabled(not ridge_numeric_axis)

        auto_y_enabled = self.auto_y_range.isChecked()
        for widget in [self.ui.yMinLabel, self.y_min, self.ui.yMaxLabel, self.y_max]:
            widget.setEnabled(not auto_y_enabled)
        primary_auto_tick_enabled = self.primary_auto_tick_interval.isChecked()
        self.primary_tick_interval_label.setEnabled(not primary_auto_tick_enabled)
        self.primary_tick_interval.setEnabled(not primary_auto_tick_enabled)
        custom_overlay_axis_available = self._custom_overlay_axis_available()

        secondary_axis_enabled = self.custom_overlay_secondary_axis.isChecked() and custom_overlay_axis_available
        if hasattr(self.ui.titleAxisForm, "setRowVisible"):
            self.ui.titleAxisForm.setRowVisible(self.secondary_y_label_label, secondary_axis_enabled)
        else:
            self.secondary_y_label_label.setVisible(secondary_axis_enabled)
            self.secondary_y_label.setVisible(secondary_axis_enabled)
        secondary_auto_y_enabled = self.secondary_auto_y_range.isChecked()
        split_secondary_enabled = secondary_axis_enabled
        for widget in [
            self.secondary_auto_y_range_label,
            self.secondary_auto_y_range,
            self.secondary_y_min_label,
            self.secondary_y_min,
            self.secondary_y_max_label,
            self.secondary_y_max,
            self.secondary_auto_tick_interval_label,
            self.secondary_auto_tick_interval,
            self.secondary_tick_interval_label,
            self.secondary_tick_interval,
            self.split_secondary_axis_label,
            self.split_secondary_axis,
            self.secondary_axis_split_ratio_label,
            self.secondary_axis_split_ratio,
        ]:
            widget.setEnabled(secondary_axis_enabled)
        for widget in [self.secondary_y_min_label, self.secondary_y_min, self.secondary_y_max_label, self.secondary_y_max]:
            widget.setEnabled(secondary_axis_enabled and not secondary_auto_y_enabled)
        secondary_auto_tick_enabled = self.secondary_auto_tick_interval.isChecked()
        self.secondary_tick_interval_label.setEnabled(secondary_axis_enabled and not secondary_auto_tick_enabled)
        self.secondary_tick_interval.setEnabled(secondary_axis_enabled and not secondary_auto_tick_enabled)
        self.split_secondary_axis_label.setEnabled(split_secondary_enabled)
        self.split_secondary_axis.setEnabled(split_secondary_enabled)
        self.secondary_axis_split_ratio_label.setEnabled(split_secondary_enabled and self.split_secondary_axis.isChecked())
        self.secondary_axis_split_ratio.setEnabled(split_secondary_enabled and self.split_secondary_axis.isChecked())

        stat_overlay_enabled = self.line_overlay_stat.currentText() != "None"
        custom_overlay_enabled = self.extra_custom_overlay.isChecked()
        line_overlay_enabled = stat_overlay_enabled or custom_overlay_enabled
        line_value_font_enabled = line_overlay_enabled and self.show_line_values.isChecked()
        has_custom_overlay_rows = self.custom_overlay_row_count() > 0
        self.add_overlay_button.setEnabled(True)
        self.remove_overlay_button.setEnabled(has_custom_overlay_rows)
        self.custom_overlay_filter_button.setEnabled(has_custom_overlay_rows)
        self.edit_overlay_styles_button.setEnabled(has_custom_overlay_rows)
        self.ui.customOverlayCountLabel.setEnabled(has_custom_overlay_rows)
        self.custom_overlay_secondary_axis_label.setEnabled(custom_overlay_axis_available)
        self.custom_overlay_secondary_axis.setEnabled(custom_overlay_axis_available)
        for widget in [
            self.ui.lineOverlayWidthLabel,
            self.line_overlay_width,
            self.ui.lineOverlayStyleLabel,
            self.line_overlay_style,
            self.ui.lineOverlayPointSizeLabel,
            self.line_overlay_point_size,
            self.ui.showLineValuesLabel,
            self.show_line_values,
            self.ui.customLineValuePositionLabel,
            self.custom_line_value_position,
            self.ui.lineValueScientificLabel,
            self.line_value_scientific,
            self.ui.lineValueDecimalsLabel,
            self.line_value_decimals,
        ]:
            widget.setEnabled(line_overlay_enabled)
        self.ui.lineValueSizeLabel.setEnabled(line_value_font_enabled)
        self.line_value_font_size.setEnabled(line_value_font_enabled)
        self.ui.lineValuePositionLabel.setEnabled(stat_overlay_enabled)
        self.line_value_position.setEnabled(stat_overlay_enabled)
        self.ui.customLineValuePositionLabel.setEnabled(custom_overlay_enabled)
        self.custom_line_value_position.setEnabled(custom_overlay_enabled)
        legend_enabled = self.show_legend.isChecked()
        self.ui.toolbarLegendSizeLabel.setEnabled(legend_enabled)
        self.legend_font_size.setEnabled(legend_enabled)
        self.legend_position.setEnabled(legend_enabled)
        self.legend_auto_width.setEnabled(legend_enabled)
        self.legend_width.setEnabled(legend_enabled and not self.legend_auto_width.isChecked())
        self.legend_columns.setEnabled(legend_enabled)
        stat_table_enabled = self.show_stat_table.isChecked()
        self._sync_stat_table_header_control()
        self.ui.statTableSizeLabel.setEnabled(stat_table_enabled)
        self.stat_table_font_size.setEnabled(stat_table_enabled)

    def _sync_auto_y_axis_controls(self) -> None:
        if not self.canvas.figure.axes:
            return
        ax = self.canvas.figure.axes[0]
        if self.settings.auto_y_range:
            y_min, y_max = ax.get_xlim() if self.settings.chart_type == "Ridge" else ax.get_ylim()
            if math.isfinite(y_min) and math.isfinite(y_max):
                self._sync_range_spin_boxes(self.y_min, self.y_max, y_min, y_max)
                self.settings.y_min = float(self.y_min.value())
                self.settings.y_max = float(self.y_max.value())
                if self.settings.chart_type == "Ridge":
                    ax.set_xlim(self.settings.y_min, self.settings.y_max)
                else:
                    ax.set_ylim(self.settings.y_min, self.settings.y_max)
        secondary_ax = self._secondary_axis_for_sync()
        if self.settings.custom_overlay_secondary_axis and self.settings.secondary_auto_y_range and secondary_ax is not None:
            y_min, y_max = secondary_ax.get_xlim() if self.settings.chart_type == "Ridge" else secondary_ax.get_ylim()
            if math.isfinite(y_min) and math.isfinite(y_max):
                self._sync_range_spin_boxes(self.secondary_y_min, self.secondary_y_max, y_min, y_max)
                self.settings.secondary_y_min = float(self.secondary_y_min.value())
                self.settings.secondary_y_max = float(self.secondary_y_max.value())
                if self.settings.chart_type == "Ridge":
                    secondary_ax.set_xlim(self.settings.secondary_y_min, self.settings.secondary_y_max)
                else:
                    secondary_ax.set_ylim(self.settings.secondary_y_min, self.settings.secondary_y_max)
        self.canvas.canvas.draw()

    def _sync_range_spin_boxes(self, min_spin: QDoubleSpinBox, max_spin: QDoubleSpinBox, min_value: float, max_value: float) -> None:
        for spin_box, value in [(min_spin, min_value), (max_spin, max_value)]:
            spin_box.blockSignals(True)
            try:
                spin_box.setValue(float(value))
            finally:
                spin_box.blockSignals(False)

    def _sync_auto_tick_interval_controls(self) -> None:
        if not self.canvas.figure.axes:
            return
        fallback_axes = getattr(self.canvas, "_auto_tick_interval_fallbacks", set())
        ax = self.canvas.figure.axes[0]
        if "primary" in fallback_axes:
            self._set_check_box_without_signal(self.primary_auto_tick_interval, True)
            self.settings.primary_auto_tick_interval = True
        if self.settings.primary_auto_tick_interval:
            self._sync_tick_interval_spin_box(self.primary_tick_interval, ax)
            self.settings.primary_tick_interval = float(self.primary_tick_interval.value())

        secondary_ax = self._secondary_axis_for_sync()
        if secondary_ax is not None:
            if "secondary" in fallback_axes:
                self._set_check_box_without_signal(self.secondary_auto_tick_interval, True)
                self.settings.secondary_auto_tick_interval = True
            if self.settings.custom_overlay_secondary_axis and self.settings.secondary_auto_tick_interval:
                self._sync_tick_interval_spin_box(self.secondary_tick_interval, secondary_ax)
                self.settings.secondary_tick_interval = float(self.secondary_tick_interval.value())
        if fallback_axes:
            self._update_dependent_control_states()

    def _sync_tick_interval_spin_box(self, spin_box: QDoubleSpinBox, ax) -> None:
        interval = self._auto_tick_interval_for_axis(ax)
        if interval is None:
            return
        spin_box.blockSignals(True)
        try:
            spin_box.setValue(interval)
        finally:
            spin_box.blockSignals(False)

    def _auto_tick_interval_for_axis(self, ax) -> float | None:
        ticks = ax.get_xticks() if self.settings.chart_type == "Ridge" else ax.get_yticks()
        finite_ticks = sorted(float(tick) for tick in ticks if math.isfinite(float(tick)))
        diffs = [
            finite_ticks[index + 1] - finite_ticks[index]
            for index in range(len(finite_ticks) - 1)
            if finite_ticks[index + 1] > finite_ticks[index]
        ]
        if not diffs:
            return None
        interval = float(np.median(diffs))
        return interval if math.isfinite(interval) and interval > 0 else None

    def _set_check_box_without_signal(self, check_box: QCheckBox, checked: bool) -> None:
        check_box.blockSignals(True)
        try:
            check_box.setChecked(checked)
        finally:
            check_box.blockSignals(False)

    def _secondary_axis_for_sync(self):
        for axis in self.canvas.figure.axes[1:]:
            if axis.get_gid() == "secondary-axis":
                return axis
            if self.settings.chart_type == "Ridge" and axis.xaxis.label.get_text() == self.settings.secondary_y_label:
                return axis
            if self.settings.chart_type != "Ridge" and axis.yaxis.label.get_text() == self.settings.secondary_y_label:
                return axis
        return None

    def new_project(self) -> None:
        self.current_project = None
        self.table.set_dataframe(blank_project_data())
        self.settings = self._settings_for_new_project()
        self.sync_manual_group_order()
        self.apply_settings_to_controls()
        self.reset_table_history()
        self.render()

    def _settings_for_new_project(self) -> ChartSettings:
        template_name = self.template_combo.currentText()
        if not template_name or template_name == TEMPLATE_NONE_NAME:
            return ChartSettings()
        try:
            return apply_style_template_settings(ChartSettings(), read_style_template(template_name), self.table_group_names())
        except Exception as exc:
            QMessageBox.warning(self, self.tr("Template load failed"), str(exc))
            self.refresh_template_combo()
            return ChartSettings()

    def save_current_template(self) -> None:
        self.update_settings()
        name, ok = QInputDialog.getText(self, self.tr("Save Style Template"), self.tr("Template name"))
        if not ok:
            return
        try:
            path = write_style_template(name, self.settings)
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template save failed"), str(exc))
            return
        self.refresh_template_combo(path.stem)
        self.statusBar().showMessage(self.tr("Style template saved: {name}").format(name=path.stem), 2500)

    def load_external_template(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Load Style Template"), "", self.tr("Style Template (*.json);;All Files (*)"))
        if not path:
            return
        try:
            name, settings = import_style_template(Path(path))
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template load failed"), str(exc))
            self.refresh_template_combo()
            return
        self.refresh_template_combo(name)
        self.apply_style_template(name, settings)
        self.statusBar().showMessage(self.tr("Style template loaded: {name}").format(name=name), 2500)

    def save_project(self) -> None:
        if not self.current_project:
            self.save_project_as()
            return
        self.update_settings()
        write_project(self.current_project, self.table.dataframe(), self.settings)
        remember_recent_project(self.current_project)
        self.update_recent_projects_menu()

    def save_project_as(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, self.tr("Save Project"), "", self.tr("EasyGraph Project (*.eg);;All Files (*)"))
        if path:
            self.current_project = Path(path if path.lower().endswith(".eg") else f"{path}.eg")
            self.save_project()

    def open_project(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Open Project"), "", self.tr("EasyGraph Project (*.eg);;All Files (*)"))
        if not path:
            return
        self.open_project_path(Path(path))

    def open_recent_project(self, path: Path) -> None:
        project_path = Path(path)
        if not project_path.is_file():
            forget_recent_project(project_path)
            self.update_recent_projects_menu()
            QMessageBox.warning(
                self,
                self.tr("Recent project unavailable"),
                self.tr("The selected recent project could not be found:\n{path}").format(path=project_path),
            )
            return
        try:
            self.open_project_path(project_path)
        except FileNotFoundError:
            forget_recent_project(project_path)
            self.update_recent_projects_menu()
            QMessageBox.warning(
                self,
                self.tr("Recent project unavailable"),
                self.tr("The selected recent project could not be found:\n{path}").format(path=project_path),
            )
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Project open failed"), str(exc))

    def open_project_path(self, path: Path) -> None:
        df, settings = read_project(path)
        self.current_project = path
        self.settings = settings
        self.table.set_dataframe(df)
        self.refresh_template_combo(TEMPLATE_NONE_NAME)
        self.apply_settings_to_controls()
        self.reset_table_history()
        self.render()
        self.canvas.zoom_to_fit()
        QTimer.singleShot(0, self.canvas.zoom_to_fit)
        remember_recent_project(path)
        self.update_recent_projects_menu()

    def apply_settings_to_controls(self) -> None:
        self._applying_settings = True
        try:
            self.chart_type.setCurrentText(self.settings.chart_type)
            self.preset.setCurrentText(self.settings.preset)
            self.group_order.setCurrentText(self.settings.group_order)
            self.title.setPlainText(self.settings.title)
            self.x_label.setPlainText(self.settings.x_label)
            self.y_label.setPlainText(self.settings.y_label)
            self.secondary_y_label.setPlainText(self.settings.secondary_y_label)
            self.show_points.setChecked(self.settings.show_points)
            self.point_size.setValue(self.settings.point_size)
            self.point_alpha.setValue(self.settings.point_alpha)
            self.jitter_mode.setCurrentText(self.settings.jitter_mode)
            self.jitter.setValue(self.settings.jitter)
            self.show_line_overlay.setChecked(self.settings.line_overlay_stat != "None")
            self.line_overlay_stat.setCurrentText(self.settings.line_overlay_stat)
            self.extra_custom_overlay.setChecked(self.settings.extra_custom_overlay)
            self.custom_overlay_count.setValue(max(1, len(self.settings.custom_overlay_series), self.settings.custom_overlay_count))
            self.custom_overlay_secondary_axis.setChecked(self.settings.custom_overlay_secondary_axis)
            self.sync_custom_overlay_rows()
            self.line_overlay_width.setValue(self.settings.line_overlay_width)
            self.line_overlay_style.setCurrentText(self.settings.line_overlay_style)
            self.line_overlay_point_size.setValue(self.settings.line_overlay_point_size)
            self.show_line_values.setChecked(self.settings.show_line_values)
            self._refresh_line_value_position_options(self.settings.line_value_position)
            self.line_value_position.setCurrentText(self.settings.line_value_position)
            self.custom_line_value_position.setCurrentText(
                normalize_overlay_label_position(self.settings.custom_line_value_position, self.settings.chart_type, is_custom_overlay=True)
            )
            self.line_value_scientific.setChecked(self.settings.line_value_scientific)
            self.line_value_decimals.setValue(self.settings.line_value_decimals)
            self.line_value_font_size.setValue(self.settings.line_value_font_size)
            self.show_stat_table.setChecked(self.settings.show_stat_table)
            self._apply_stat_table_options_to_controls()
            self.show_stat_header.setChecked(self.settings.show_stat_header)
            self._sync_stat_table_header_control()
            self.stat_table_font_size.setValue(self.settings.stat_table_font_size)
            self.show_outliers.setChecked(self.settings.show_outliers)
            self.outlier_method.setCurrentText(self.settings.outlier_method)
            self.outlier_threshold.setValue(self.settings.outlier_threshold)
            self.outlier_effect.setCurrentText(self.settings.outlier_effect)
            self.width.setValue(self.settings.width)
            self.height.setValue(self.settings.height)
            self.dpi.setValue(self.settings.dpi)
            self.title_font_size.setValue(self.settings.title_font_size)
            self.axis_label_font_size.setValue(self.settings.axis_label_font_size)
            self.tick_font_size.setValue(self.settings.tick_font_size)
            self.show_legend.setChecked(self.settings.show_legend)
            self.legend_font_size.setValue(self.settings.legend_font_size)
            self.legend_width.setValue(self.settings.legend_width)
            self._set_legend_position_value(self.settings.legend_position)
            self._set_legend_auto_width_checked(self.settings.legend_auto_width)
            self._set_legend_columns_value(self.settings.legend_columns)
            self.axis_line_width.setValue(self.settings.axis_line_width)
            self.show_grid.setChecked(self.settings.show_grid)
            self.x_tick_rotation.setValue(self.settings.x_tick_rotation)
            self.auto_y_range.setChecked(self.settings.auto_y_range)
            self.y_min.setValue(self.settings.y_min)
            self.y_max.setValue(self.settings.y_max)
            self.primary_auto_tick_interval.setChecked(self.settings.primary_auto_tick_interval)
            self.primary_tick_interval.setValue(self.settings.primary_tick_interval)
            self.secondary_auto_y_range.setChecked(self.settings.secondary_auto_y_range)
            self.secondary_y_min.setValue(self.settings.secondary_y_min)
            self.secondary_y_max.setValue(self.settings.secondary_y_max)
            self.secondary_auto_tick_interval.setChecked(self.settings.secondary_auto_tick_interval)
            self.secondary_tick_interval.setValue(self.settings.secondary_tick_interval)
            self.split_secondary_axis.setChecked(self.settings.split_secondary_axis)
            self.secondary_axis_split_ratio.setValue(self.settings.secondary_axis_split_ratio)
            self.transparent_background.setChecked(self.settings.transparent_background)
            self.fill_alpha.setValue(self.settings.fill_alpha)
            self.box_width.setValue(self.settings.box_width)
            self.box_whisker_mode.setCurrentText(self.settings.box_whisker_mode)
            self.violin_width.setValue(self.settings.violin_width)
            self.kde_bandwidth.setValue(self.settings.kde_bandwidth)
            self.ridge_overlap.setValue(self.settings.ridge_overlap)
            self._update_dependent_control_states()
        finally:
            self._applying_settings = False

    def import_excel(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Import Excel"), "", self.tr("Excel Files (*.xlsx *.xls);;CSV Files (*.csv)"))
        if not path:
            return
        try:
            df, overlay_series = read_spreadsheet(Path(path))
            self.settings.custom_overlay_series = overlay_series
            self.settings.custom_overlay_count = max(1, len(overlay_series))
            self.settings.extra_custom_overlay = bool(overlay_series)
            self.settings.custom_overlay_hidden = []
            self.set_table_dataframe(df, overlay_series)
            self._sync_custom_overlay_visibility_to_controls()
            self.sync_manual_group_order()
            self.reset_table_history()
            self.render()
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Import failed"), str(exc))

    def export_excel(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, self.tr("Export Excel"), "", self.tr("Excel File (*.xlsx);;CSV File (*.csv)"))
        if not path:
            return
        try:
            write_spreadsheet(
                Path(path),
                self.table.dataframe(),
                self.custom_overlay_series_from_table() if self.custom_overlay_row_count() else [],
            )
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Export failed"), str(exc))

    def export_figure(self) -> None:
        filters = (
            "SVG Vector (*.svg);;"
            "PNG Image (*.png);;"
            "PDF Document (*.pdf);;"
            "TIFF Image (*.tif *.tiff);;"
            "JPEG Image (*.jpg *.jpeg)"
        )
        path, selected_filter = QFileDialog.getSaveFileName(
            self,
            self.tr("Export Figure"),
            "",
            filters,
            "SVG Vector (*.svg)",
        )
        if path:
            suffix = export_suffix_for_filter(selected_filter)
            if suffix and not Path(path).suffix:
                path = f"{path}{suffix}"
            self.flush_pending_render()
            self.canvas.export(path, self.settings)

    def copy_figure(self) -> None:
        self.copy_figure_image()

    def copy_figure_image(self) -> None:
        self.flush_pending_render()
        if self.canvas.copy_to_clipboard(self.settings):
            self.statusBar().showMessage(self.tr("Figure image copied to clipboard"), 2500)
        else:
            QMessageBox.warning(self, self.tr("Copy failed"), self.tr("Could not copy the figure to the clipboard."))


def export_suffix_for_filter(selected_filter: str) -> str:
    if "*.svg" in selected_filter:
        return ".svg"
    if "*.png" in selected_filter:
        return ".png"
    if "*.pdf" in selected_filter:
        return ".pdf"
    if "*.tif" in selected_filter or "*.tiff" in selected_filter:
        return ".tif"
    if "*.jpg" in selected_filter or "*.jpeg" in selected_filter:
        return ".jpg"
    return ""



























def main() -> None:
    app = QApplication([])
    install_app_translator(app)
    apply_app_theme(app)
    window = MainWindow()
    window.show()
    app.exec()


if __name__ == "__main__":
    main()
