import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class OverlaySeriesModuleTests(EasyGraphTestCase):
    PUBLIC_EXPORTS = (
        "line_overlay_series",
        "visible_custom_overlay_indexes",
        "all_custom_overlay_indexes",
        "overlay_palette_for",
        "stat_overlay_color",
        "default_overlay_color",
        "overlay_color_map_for_series",
        "overlay_color_map_for_keys",
        "all_overlay_color_keys",
        "overlay_palette_slot_for_color_key",
        "overlay_color_items",
        "overlay_style_items",
        "overlay_stat_color_key",
        "overlay_custom_color_key",
        "group_overlay_statistics",
        "stat_table_header_required",
        "stat_table_header_enabled",
        "stat_table_data",
        "format_overlay_value",
        "custom_overlay_style_for_key",
        "auto_overlay_style",
        "overlay_style_for_series",
    )

    def test_app_reexports_exact_overlay_series_api(self):
        from easygraph import overlay_series

        self.assertEqual(overlay_series.__all__, list(self.PUBLIC_EXPORTS))
        for name in self.PUBLIC_EXPORTS:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(overlay_series, name))

    def _run_direct_import_contract(self, *, optimized: bool) -> None:
        source_path = str(ROOT / "src")
        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = source_path + (
            os.pathsep + existing_pythonpath if existing_pythonpath else ""
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
import pandas as pd
from easygraph.overlay_series import (
    line_overlay_series,
    overlay_color_map_for_keys,
    stat_table_data,
)
from easygraph.settings import ChartSettings

frame = pd.DataFrame({{
    "group": ["A", "A", "B", "B"],
    "value": [1.0, 3.0, 5.0, 7.0],
}})
settings = ChartSettings(
    line_overlay_stat="Median",
    extra_custom_overlay=True,
    custom_overlay_palette="Dark Slide",
    custom_overlay_series=[{{
        "name": "Target",
        "values": {{"A": "10", "B": "20"}},
    }}],
    show_stat_table=True,
    show_stat_mean=True,
    show_stat_median=False,
    show_stat_max=False,
    show_stat_min=False,
)
series = line_overlay_series(frame, settings)
if [item["name"] for item in series] != ["Median", "Target"]:
    raise SystemExit("unexpected overlay series")
groups, rows = stat_table_data(frame, settings)
if groups != ["A", "B"] or rows != [("Mean", ["2.00", "6.00"])]:
    raise SystemExit("unexpected statistics table")
colors = overlay_color_map_for_keys(["custom:0"], settings)
if list(colors) != ["custom:0"] or not colors["custom:0"].startswith("#"):
    raise SystemExit("unexpected overlay color map")
if "PySide6.QtWidgets" in sys.modules:
    raise SystemExit("QtWidgets imported")
for forbidden in ("matplotlib", "seaborn", "scipy"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit(forbidden + " imported")
"""
        command = [sys.executable]
        if optimized:
            command.append("-O")
        command.extend(["-c", code])
        result = subprocess.run(
            command,
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=False,
            timeout=15,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_direct_import_runs_overlay_contract_without_ui_or_plotting(self):
        self._run_direct_import_contract(optimized=False)

    def test_optimized_direct_import_keeps_overlay_contract_effective(self):
        self._run_direct_import_contract(optimized=True)
