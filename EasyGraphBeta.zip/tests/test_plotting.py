from __future__ import annotations

import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphQtTestCase, EasyGraphTestCase, app


class PlottingModuleContractTests(EasyGraphTestCase):
    def test_plotting_canvas_api_is_exact_and_shared_with_app(self):
        from easygraph.plotting import canvas

        expected = [
            "AUTO_AXIS_RANGE_PADDING_FRACTION",
            "CoordinatesToolbar",
            "LEGEND_COLUMN_SPACING",
            "LEGEND_HANDLE_LENGTH",
            "LEGEND_HANDLE_SPACE_UNITS",
            "LEGEND_MAX_COLUMNS",
            "LEGEND_SECONDARY_AXIS_GAP_PX",
            "LINE_OVERLAY_STYLE_TO_MPL",
            "LINE_OVERLAY_STYLE_TO_QT",
            "LINE_STYLE_ICON_DEVICE_RATIOS",
            "LINE_STYLE_ICON_SIZE",
            "LINE_STYLE_POPUP_PREVIEW_WIDTH",
            "LINE_STYLE_POPUP_ROW_HEIGHT",
            "LINE_STYLE_PREVIEW_DOT_RADIUS",
            "LINE_STYLE_PREVIEW_STROKE_WIDTH",
            "MAX_MANUAL_TICK_COUNT",
            "OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS",
            "OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO",
            "OVERLAY_CONTENT_MARGIN_RATIO",
            "PlotCanvas",
            "STAT_OVERLAY_ALPHA",
            "ScrollFriendlyFigureCanvas",
            "draw_line_style_preview",
            "line_style_icon",
            "normalize_overlay_label_position",
            "overlay_auto_avoidance_position",
            "overlay_label_arrow",
            "overlay_label_bbox",
            "overlay_label_offset",
            "overlay_label_position_for_series",
            "overlay_line_qt_pen_style",
            "overlay_line_style",
            "overlay_values_are_close",
            "resolve_overlay_label_position",
        ]
        self.assertEqual(canvas.__all__, expected)
        for name in expected:
            self.assertIs(getattr(app, name), getattr(canvas, name))

    def test_direct_plotting_canvas_import_does_not_import_app(self):
        code = f"""
import sys
sys.path.insert(0, {str(ROOT / "src")!r})
from easygraph.plotting import canvas
if "app" in sys.modules:
    raise SystemExit("imported app")
for name in ("PlotCanvas", "ScrollFriendlyFigureCanvas", "CoordinatesToolbar"):
    getattr(canvas, name)
assert canvas.overlay_label_offset(0, [1.0], "Above", False) == (0, 13, "center", "bottom")
"""
        env = os.environ.copy()
        env["PYTHONPATH"] = str(ROOT / "src")
        for args in ([sys.executable, "-c", code], [sys.executable, "-O", "-c", code]):
            with self.subTest(args=args):
                result = subprocess.run(
                    args,
                    cwd=ROOT,
                    env=env,
                    text=True,
                    capture_output=True,
                    timeout=20,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )


class PlottingModuleQtTests(EasyGraphQtTestCase):
    def test_plot_canvas_constructs_scroll_friendly_canvas_and_toolbar(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)

        self.assertIsInstance(plot_canvas.canvas, canvas.ScrollFriendlyFigureCanvas)
        self.assertIsInstance(plot_canvas.toolbar, canvas.CoordinatesToolbar)
        self.assertIs(plot_canvas.canvas.owner, plot_canvas)
        self.assertIsNotNone(plot_canvas.findChild(app.QPushButton, "zoomToFitButton"))

    def test_main_window_uses_extracted_plot_canvas(self):
        from easygraph.plotting import canvas

        window = self.make_window(initial_render=False)

        self.assertIsInstance(window.canvas, canvas.PlotCanvas)
        self.assertIs(window.canvas.selection_callback.__self__, window)
        self.assertIs(
            window.canvas.selection_callback.__func__,
            window.handle_plot_object_selection.__func__,
        )
        self.assertIs(window.canvas.legend_position_callback.__self__, window)
        self.assertIs(
            window.canvas.legend_position_callback.__func__,
            window.handle_legend_drag_position.__func__,
        )
