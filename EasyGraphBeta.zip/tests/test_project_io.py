import os
import pathlib
import subprocess
import sys
import tempfile

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class ProjectIOTests(EasyGraphTestCase):

    def test_chart_settings_codec_rejects_invalid_and_unknown_fields(self):
        from easygraph import project_io

        with self.assertRaisesRegex(ValueError, r"^Chart settings must be a dictionary\.$"):
            project_io.chart_settings_from_dict([])
        with self.assertRaisesRegex(
            ValueError,
            r"^Unknown ChartSettings fields: 1$",
        ):
            project_io.chart_settings_from_dict({1: "bad"})
        with self.assertRaisesRegex(
            ValueError,
            r"^Unknown ChartSettings fields: legacy_show_line_overlay, retired_legend_mode$",
        ):
            project_io.chart_settings_from_dict({
                "retired_legend_mode": True,
                "legacy_show_line_overlay": False,
            })

    def test_project_io_api_is_exact_and_shared_with_app(self):
        from easygraph import project_io

        self.assertEqual(
            project_io.__all__,
            ["chart_settings_from_dict", "read_project", "write_project"],
        )
        self.assertIs(app.chart_settings_from_dict, project_io.chart_settings_from_dict)
        self.assertIs(app.read_project, project_io.read_project)
        self.assertIs(app.write_project, project_io.write_project)

    def test_project_io_contract_is_strict_with_and_without_optimization(self):
        code = """
import sys
from easygraph import project_io

settings = project_io.chart_settings_from_dict({"legend_columns": 1})
if settings.legend_auto_width is not True:
    raise SystemExit("missing legend_auto_width did not use the current default")
try:
    project_io.chart_settings_from_dict({"removed_field": True})
except ValueError as error:
    if str(error) != "Unknown ChartSettings fields: removed_field":
        raise SystemExit(f"unexpected error: {error}")
else:
    raise SystemExit("unknown field was accepted")
for forbidden in ("PySide6", "matplotlib", "seaborn", "scipy"):
    if any(
        name == forbidden or name.startswith(forbidden + ".")
        for name in sys.modules
    ):
        raise SystemExit(f"forbidden dependency loaded: {forbidden}")
"""
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(ROOT / "src")
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )

    def test_project_roundtrip_preserves_new_settings(self):
        self.settings.jitter_mode = "Quasirandom"
        self.settings.outlier_effect = "Exclude from distribution"
        self.settings.box_whisker_mode = "Min-Max"
        self.settings.group_order = "Mean descending"
        self.settings.manual_group_order = ["High dose", "Control", "Low dose"]
        self.settings.group_hidden = ["Low dose"]
        self.settings.transparent_background = True
        self.settings.show_line_overlay = True
        self.settings.line_overlay_stat = "Mean"
        self.settings.line_overlay_width = 2.4
        self.settings.line_overlay_style = "Dashed"
        self.settings.line_overlay_point_size = 7.5
        self.settings.show_line_values = True
        self.settings.line_value_position = "Below"
        self.settings.custom_line_value_position = "Left"
        self.settings.secondary_y_label = "Rate"
        self.settings.custom_overlay_secondary_axis = True
        self.settings.custom_overlay_hidden = [1]
        self.settings.secondary_auto_y_range = False
        self.settings.secondary_y_min = 40.0
        self.settings.secondary_y_max = 80.0
        self.settings.split_secondary_axis = True
        self.settings.secondary_axis_split_ratio = 0.42
        self.settings.line_value_scientific = True
        self.settings.line_value_decimals = 4
        self.settings.line_value_font_size = 11
        self.settings.custom_colors = {"High dose": "#336699"}
        self.settings.custom_overlay_palette = "Dark Slide"
        self.settings.custom_overlay_colors = {"custom:0": "#884466"}
        self.settings.custom_overlay_styles = {"custom:0": "Dash-dot"}
        self.settings.x_tick_rotation = 65
        self.settings.preset = "Tableau 10"
        self.settings.point_size = 5.5
        self.settings.point_alpha = 0.42
        self.settings.axis_line_width = 1.8
        self.settings.show_grid = False
        self.settings.auto_y_range = False
        self.settings.y_min = -1.0
        self.settings.y_max = 12.0
        self.settings.box_width = 0.72
        self.settings.violin_width = 0.66
        self.settings.kde_bandwidth = 1.4
        self.settings.ridge_overlap = 0.82
        self.settings.fill_alpha = 0.51
        self.settings.show_stat_min = False
        self.settings.show_stat_sem = False
        self.settings.show_stat_header = True
        self.settings.stat_table_font_size = 10
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "roundtrip.eg"
            app.write_project(path, self.df, self.settings)
            roundtrip_df, roundtrip_settings = app.read_project(path)

        self.assertEqual(roundtrip_df.shape, self.df.shape)
        self.assertEqual(app.asdict(roundtrip_settings), app.asdict(self.settings))
