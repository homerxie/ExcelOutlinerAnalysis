from __future__ import annotations

import pathlib
import sys
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tests.test_support import WarningConfiguredTestCase

import app


def patch_qsettings(values=None):
    values = {} if values is None else values

    class FakeSettings:
        def __init__(self, *args):
            pass

        def value(self, key, default=None):
            return values.get(key, default)

        def setValue(self, key, value):
            values[key] = value

    return mock.patch.object(app, "QSettings", FakeSettings), values


class EasyGraphTestCase(WarningConfiguredTestCase):
    def setUp(self):
        super().setUp()
        self.settings = app.ChartSettings()
        self.df = app.sample_data()


class EasyGraphQtTestCase(EasyGraphTestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.qapp = app.QApplication.instance() or app.QApplication([])

    def make_window(self, *, initial_render: bool = False):
        window = app.MainWindow(initial_render=initial_render)
        self.addCleanup(window.close)
        return window
