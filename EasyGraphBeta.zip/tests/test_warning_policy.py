import unittest
import warnings
from unittest import mock

from tests import test_support


class WarningPolicyTests(unittest.TestCase):
    def test_warning_configured_test_case_applies_policy_in_set_up_class(self):
        with mock.patch.object(test_support, "configure_warning_filters") as configure:
            test_support.WarningConfiguredTestCase.setUpClass()

        configure.assert_called_once_with()

    def test_warning_filter_targets_only_known_seaborn_warning(self):
        with mock.patch.object(test_support.warnings, "filterwarnings") as filterwarnings:
            test_support.configure_warning_filters()

        filterwarnings.assert_called_once_with(
            "ignore",
            message=r"vert: bool will be deprecated.*",
            category=PendingDeprecationWarning,
            module=r"^seaborn\.categorical$",
        )

    def test_warning_filter_preserves_unrelated_warnings(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            test_support.configure_warning_filters()

            warnings.warn_explicit(
                "vert: bool will be deprecated target",
                PendingDeprecationWarning,
                "seaborn/categorical.py",
                700,
                module="seaborn.categorical",
            )
            warnings.warn_explicit(
                "vert: bool will be deprecated project",
                PendingDeprecationWarning,
                "src/app.py",
                1,
                module="app",
            )
            warnings.warn_explicit(
                "different seaborn warning",
                PendingDeprecationWarning,
                "seaborn/categorical.py",
                701,
                module="seaborn.categorical",
            )
            warnings.warn_explicit(
                "vert: bool will be deprecated category",
                DeprecationWarning,
                "seaborn/categorical.py",
                702,
                module="seaborn.categorical",
            )
            warnings.warn_explicit(
                "vert: bool will be deprecated submodule",
                PendingDeprecationWarning,
                "seaborn/categorical/extra.py",
                1,
                module="seaborn.categorical.extra",
            )

        self.assertEqual(
            [str(warning.message) for warning in caught],
            [
                "vert: bool will be deprecated project",
                "different seaborn warning",
                "vert: bool will be deprecated category",
                "vert: bool will be deprecated submodule",
            ],
        )
        self.assertEqual(
            [warning.category for warning in caught],
            [
                PendingDeprecationWarning,
                PendingDeprecationWarning,
                DeprecationWarning,
                PendingDeprecationWarning,
            ],
        )
