import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class SettingsModuleTests(EasyGraphTestCase):
    def test_app_reexports_settings_module_api(self):
        from easygraph import settings

        expected_exports = (
            "ChartSettings",
            "DEFAULT_OVERLAY_PALETTE",
            "GROUP_COLOR_TEMPLATE_KEY_PREFIX",
            "LEGEND_INSIDE_AUTO_POSITION",
            "LEGEND_POSITION_INSIDE",
            "LEGEND_POSITION_RIGHT",
            "LINE_OVERLAY_RENDER_STYLES",
            "LINE_OVERLAY_STYLES",
            "PRESETS",
            "SEQUENTIAL_PALETTE_PRESETS",
            "STAT_TABLE_OPTIONS",
            "STYLE_TEMPLATE_CONTENT_FIELDS",
        )
        self.assertEqual(settings.__all__, list(expected_exports))
        for name in expected_exports:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(settings, name))

    def test_settings_module_imports_without_gui_or_plotting_stack(self):
        environment = os.environ.copy()
        source_path = str(ROOT / "src")
        existing_pythonpath = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = (
            source_path + os.pathsep + existing_pythonpath
            if existing_pythonpath
            else source_path
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.settings import ChartSettings, PRESETS

assert ChartSettings().preset in PRESETS
assert not any(name == "PySide6" or name.startswith("PySide6.") for name in sys.modules)
assert not any(name == "matplotlib" or name.startswith("matplotlib.") for name in sys.modules)
"""

        result = subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True,
            text=True,
            env=environment,
            cwd=ROOT,
            check=False,
            timeout=10,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
