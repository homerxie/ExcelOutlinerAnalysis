import json
import os
import pathlib
import subprocess
import sys
import tempfile

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class TemplateIOTests(EasyGraphTestCase):

    def test_style_template_rejects_unknown_settings_fields(self):
        data = app.asdict(self.settings)
        data["retired_template_setting"] = True

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "strict.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            with self.assertRaises(ValueError) as raised:
                app.read_style_template_file(path)

        self.assertEqual(
            str(raised.exception),
            "Unknown ChartSettings fields: retired_template_setting",
        )

    def test_template_io_api_is_exact_and_shared_with_app(self):
        from easygraph import template_io

        expected_exports = [
            "TEMPLATE_DIR",
            "TEMPLATE_NONE_NAME",
            "apply_style_template_settings",
            "group_colors_for_target_groups",
            "import_style_template",
            "indexed_group_colors_from_settings",
            "list_style_templates",
            "read_style_template",
            "read_style_template_file",
            "style_template_settings_data",
            "template_file_name",
            "template_indexed_group_colors",
            "write_style_template",
        ]
        self.assertEqual(template_io.__all__, expected_exports)
        for name in expected_exports:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(template_io, name))
        self.assertEqual(template_io.TEMPLATE_DIR, ROOT / "src" / "template")

    def test_template_io_contract_runs_without_ui_or_plotting_dependencies(self):
        code = """
import inspect
import sys
from easygraph.settings import ChartSettings
from easygraph.template_io import (
    TEMPLATE_DIR,
    group_colors_for_target_groups,
    style_template_settings_data,
    write_style_template,
)

settings = ChartSettings(
    manual_group_order=["A", "B"],
    custom_colors={"B": "#446688"},
)
data = style_template_settings_data(settings)
if data["custom_colors"] != {"group:1": "#446688"}:
    raise SystemExit("group color was not indexed")
mapped = group_colors_for_target_groups(data["custom_colors"], ["X", "Y"])
if mapped != {"Y": "#446688"}:
    raise SystemExit("indexed group color was not mapped")
if inspect.signature(write_style_template).parameters["template_dir"].default != TEMPLATE_DIR:
    raise SystemExit("unexpected default template path")
if "PySide6.QtWidgets" in sys.modules:
    raise SystemExit("QtWidgets imported")
for forbidden in ("matplotlib", "seaborn", "scipy"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit(forbidden + " imported")
"""
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(ROOT / "src")
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_style_template_roundtrip_preserves_settings(self):
        self.settings.chart_type = "Ridge"
        self.settings.title = "Saved style"
        self.settings.x_label = "Saved group label"
        self.settings.y_label = "Saved value label"
        self.settings.secondary_y_label = "Saved secondary label"
        self.settings.width = 22.0
        self.settings.transparent_background = False
        self.settings.show_line_overlay = True
        self.settings.line_overlay_stat = "Mean"
        self.settings.line_overlay_width = 2.2
        self.settings.line_overlay_style = "Dotted"
        self.settings.line_overlay_point_size = 6.5
        self.settings.line_value_position = "Right"
        self.settings.custom_line_value_position = "Below"
        self.settings.line_value_font_size = 12
        self.settings.manual_group_order = ["Low dose", "Control", "High dose"]
        self.settings.group_hidden = ["High dose"]
        self.settings.custom_colors = {"Control": "#446688"}
        self.settings.custom_overlay_styles = {"custom:0": "Dashed"}
        self.settings.x_tick_rotation = 65
        self.settings.preset = "Viridis"
        self.settings.auto_y_range = False
        self.settings.y_min = -2.0
        self.settings.y_max = 9.0
        self.settings.line_value_decimals = 4
        self.settings.line_value_scientific = True
        self.settings.show_stat_q1 = False
        self.settings.stat_table_font_size = 8
        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)

            path = app.write_style_template(" My style/template ", self.settings, template_dir)
            loaded = app.read_style_template(path.stem, template_dir)

        self.assertEqual(path.name, "My style_template.json")
        expected = app.asdict(self.settings)
        defaults = app.asdict(app.ChartSettings())
        for key in app.STYLE_TEMPLATE_CONTENT_FIELDS:
            expected[key] = defaults[key]
        expected["custom_colors"] = {"group:1": "#446688"}
        self.assertEqual(app.asdict(loaded), expected)

    def test_style_template_does_not_save_custom_overlay_data(self):
        self.settings.extra_custom_overlay = True
        self.settings.custom_overlay_count = 1
        self.settings.custom_overlay_hidden = [0]
        self.settings.custom_overlay_secondary_axis = True
        self.settings.split_secondary_axis = True
        self.settings.custom_overlay_series = [
            {"name": "Overlay 1", "values": {"Control": "30", "Low dose": "20"}},
        ]

        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = app.write_style_template("Overlay style", self.settings, template_dir)
            saved = json.loads(path.read_text(encoding="utf-8"))
            loaded = app.read_style_template(path.stem, template_dir)

        self.assertTrue(saved["extra_custom_overlay"])
        self.assertEqual(saved["custom_overlay_count"], 1)
        self.assertEqual(saved["custom_overlay_series"], [])
        self.assertEqual(saved["custom_overlay_hidden"], [])
        self.assertTrue(saved["custom_overlay_secondary_axis"])
        self.assertTrue(saved["split_secondary_axis"])
        self.assertTrue(loaded.extra_custom_overlay)
        self.assertEqual(loaded.custom_overlay_series, [])
        self.assertEqual(loaded.custom_overlay_hidden, [])
        self.assertTrue(loaded.custom_overlay_secondary_axis)
        self.assertTrue(loaded.split_secondary_axis)

    def test_style_template_load_clears_content_overlay_data(self):
        data = app.asdict(self.settings)
        data["extra_custom_overlay"] = True
        data["custom_overlay_count"] = 1
        data["custom_overlay_hidden"] = [0]
        data["custom_overlay_secondary_axis"] = True
        data["split_secondary_axis"] = True
        data["custom_overlay_series"] = [
            {"name": "Legacy overlay", "values": {"Control": "30"}},
        ]

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "legacy.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            loaded = app.read_style_template_file(path)

        self.assertTrue(loaded.extra_custom_overlay)
        self.assertEqual(loaded.custom_overlay_count, 1)
        self.assertEqual(loaded.custom_overlay_series, [])
        self.assertEqual(loaded.custom_overlay_hidden, [])
        self.assertTrue(loaded.custom_overlay_secondary_axis)
        self.assertTrue(loaded.split_secondary_axis)

    def test_style_template_group_colors_are_indexed_not_name_bound(self):
        self.settings.manual_group_order = ["Control", "Low dose", "High dose"]
        self.settings.custom_colors = {"Low dose": "#446688"}

        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = app.write_style_template("Indexed colors", self.settings, template_dir)
            saved = json.loads(path.read_text(encoding="utf-8"))
            loaded = app.read_style_template(path.stem, template_dir)

        self.assertEqual(saved["custom_colors"], {"group:1": "#446688"})
        self.assertEqual(loaded.custom_colors, {"group:1": "#446688"})

    def test_style_template_keeps_only_indexed_group_colors(self):
        data = app.asdict(self.settings)
        data["custom_colors"] = {"Control": "#446688", "group:1": "#884466"}

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "legacy_colors.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            loaded = app.read_style_template_file(path)

        self.assertEqual(loaded.custom_colors, {"group:1": "#884466"})

    def test_import_style_template_copies_external_json(self):
        self.settings.chart_type = "Violin"
        self.settings.title = "External style"
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = pathlib.Path(tmp)
            external = tmp_path / "external style.json"
            external.write_text(json.dumps(app.asdict(self.settings)), encoding="utf-8")

            name, loaded = app.import_style_template(external, tmp_path / "templates")

            self.assertEqual(name, "external style")
            self.assertTrue((tmp_path / "templates" / "external style.json").exists())
            self.assertEqual(loaded.chart_type, "Violin")
            self.assertEqual(loaded.title, "Distribution plot")
