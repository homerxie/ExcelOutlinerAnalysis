import pathlib
import tempfile
from unittest import mock

from tests.easygraph_case import EasyGraphQtTestCase, app, patch_qsettings


class AppPreferenceTests(EasyGraphQtTestCase):

    def test_recent_project_paths_keep_newest_unique_and_limited(self):
        settings_patch, _values = patch_qsettings()
        paths = [pathlib.Path(f"/tmp/project_{index}.eg") for index in range(app.MAX_RECENT_PROJECTS + 2)]
        with settings_patch:
            app.save_recent_project_paths(paths)

            self.assertEqual(app.stored_recent_project_paths(), paths[: app.MAX_RECENT_PROJECTS])

            app.remember_recent_project(paths[3])

            recent_paths = app.stored_recent_project_paths()

        self.assertEqual(recent_paths[0], paths[3])
        self.assertEqual(len(recent_paths), app.MAX_RECENT_PROJECTS)
        self.assertEqual(recent_paths.count(paths[3]), 1)

    def test_file_menu_contains_open_recent_submenu(self):
        settings_patch, _values = patch_qsettings()
        with settings_patch:
            window = self.make_window()

        actions = window.ui.menuFile.actions()
        recent_index = actions.index(window.ui.actionOpenProject) + 1
        self.assertEqual(actions[recent_index], window.ui.menuOpenRecent.menuAction())
        self.assertEqual(window.ui.menuOpenRecent.title(), "Open Recent")
        self.assertEqual(window.ui.menuOpenRecent.actions()[0].text(), "No Recent Projects")
        self.assertFalse(window.ui.menuOpenRecent.actions()[0].isEnabled())

    def test_open_project_adds_path_to_recent_menu(self):
        settings_patch, _values = patch_qsettings()
        self.settings.title = "Recent project title"
        with settings_patch:
            window = self.make_window(initial_render=True)
            with tempfile.TemporaryDirectory() as tmp:
                path = pathlib.Path(tmp) / "recent_open.eg"
                app.write_project(path, self.df, self.settings)

                with mock.patch.object(app.QFileDialog, "getOpenFileName", return_value=(str(path), "")):
                    window.open_project()

                recent_action = window.ui.menuOpenRecent.actions()[0]

            self.assertEqual(app.stored_recent_project_paths(), [path])

        self.assertEqual(window.current_project, path)
        self.assertEqual(window.settings.title, "Recent project title")
        self.assertEqual(recent_action.data(), str(path))

    def test_open_recent_project_loads_file_and_moves_it_to_top(self):
        settings_patch, _values = patch_qsettings()
        first_settings = app.ChartSettings(title="First")
        second_settings = app.ChartSettings(title="Second")
        with settings_patch:
            window = self.make_window(initial_render=True)
            with tempfile.TemporaryDirectory() as tmp:
                first_path = pathlib.Path(tmp) / "first.eg"
                second_path = pathlib.Path(tmp) / "second.eg"
                app.write_project(first_path, self.df, first_settings)
                app.write_project(second_path, self.df, second_settings)
                app.save_recent_project_paths([second_path, first_path])

                window.open_recent_project(first_path)

                self.assertEqual(window.current_project, first_path)
                self.assertEqual(window.settings.title, "First")
                self.assertEqual(app.stored_recent_project_paths(), [first_path, second_path])

    def test_open_recent_project_removes_missing_file(self):
        settings_patch, _values = patch_qsettings()
        missing_path = pathlib.Path("/tmp/missing_recent_project.eg")
        with settings_patch:
            window = self.make_window(initial_render=True)
            app.save_recent_project_paths([missing_path])
            window.update_recent_projects_menu()

            with mock.patch.object(app.QMessageBox, "warning") as warning:
                window.open_recent_project(missing_path)

            self.assertEqual(app.stored_recent_project_paths(), [])
            self.assertEqual(window.ui.menuOpenRecent.actions()[0].text(), "No Recent Projects")
            warning.assert_called_once()
