from tests.easygraph_case import EasyGraphTestCase, app


class ArchitectureTests(EasyGraphTestCase):
    def test_legacy_programmatic_ui_builders_are_removed(self):
        legacy_builders = (
            "_build_menu",
            "_build_layout",
            "_build_controls",
            "_chart_group",
            "_font_group",
            "_axis_group",
            "_points_group",
            "_outlier_group",
            "_specific_group",
        )
        for name in legacy_builders:
            with self.subTest(name=name):
                self.assertFalse(hasattr(app.MainWindow, name))

    def test_legacy_spin_factories_are_removed(self):
        self.assertFalse(hasattr(app, "spin"))
        self.assertFalse(hasattr(app, "spin_int"))
