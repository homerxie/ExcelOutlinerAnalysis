"""Shared configuration for EasyGraph tests."""

import unittest
import warnings


def configure_warning_filters() -> None:
    warnings.filterwarnings(
        "ignore",
        message=r"vert: bool will be deprecated.*",
        category=PendingDeprecationWarning,
        module=r"^seaborn\.categorical$",
    )


class WarningConfiguredTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        configure_warning_filters()
