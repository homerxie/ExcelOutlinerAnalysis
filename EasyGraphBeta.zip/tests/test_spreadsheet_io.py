import os
import pathlib
import subprocess
import sys
import tempfile
from unittest import mock

from tests.easygraph_case import ROOT, EasyGraphQtTestCase, EasyGraphTestCase, app


class SpreadsheetIOTests(EasyGraphTestCase):

    def test_excel_overlay_dataframe_roundtrip_preserves_custom_overlay_rows(self):
        df = app.pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        overlay = [
            {"name": "Target", "values": {"A": "10", "B": "20"}},
            {"name": "Limit", "values": {"A": "7.5", "B": ""}},
        ]

        exported = app.excel_export_dataframe(df, overlay)
        imported_df, imported_overlay = app.excel_import_parts(exported)

        self.assertEqual(list(exported.columns), [
            app.OVERLAY_EXPORT_ROW_TYPE_COLUMN,
            app.OVERLAY_EXPORT_NAME_COLUMN,
            "A",
            "B",
        ])
        app.pd.testing.assert_frame_equal(imported_df, df)
        self.assertEqual(imported_overlay, overlay)

    def test_spreadsheet_paths_and_roundtrips_follow_format_policy(self):
        from easygraph import spreadsheet_io

        df = app.pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]

        with tempfile.TemporaryDirectory() as tmp:
            directory = pathlib.Path(tmp)
            csv_path = directory / "data.csv"
            self.assertEqual(
                spreadsheet_io.write_spreadsheet(csv_path, df, overlay),
                csv_path,
            )
            csv_df, csv_overlay = spreadsheet_io.read_spreadsheet(csv_path)
            app.pd.testing.assert_frame_equal(csv_df, df)
            self.assertEqual(csv_overlay, overlay)

            book_path = directory / "book"
            xlsx_path = directory / "book.xlsx"
            self.assertEqual(
                spreadsheet_io.write_spreadsheet(book_path, df, overlay),
                xlsx_path,
            )
            xlsx_df, xlsx_overlay = spreadsheet_io.read_spreadsheet(xlsx_path)
            app.pd.testing.assert_frame_equal(xlsx_df, df)
            self.assertEqual(xlsx_overlay, overlay)

            old_path = directory / "old.xls"
            self.assertEqual(
                spreadsheet_io.write_spreadsheet(old_path, df, overlay),
                directory / "old.xls.xlsx",
            )

        encoded = spreadsheet_io.excel_export_dataframe(df, overlay)
        input_path = pathlib.Path("input.xls")
        with mock.patch.object(spreadsheet_io.pd, "read_excel", return_value=encoded) as read_excel:
            imported_df, imported_overlay = spreadsheet_io.read_spreadsheet(input_path)
        read_excel.assert_called_once_with(input_path)
        app.pd.testing.assert_frame_equal(imported_df, df)
        self.assertEqual(imported_overlay, overlay)

    def test_app_reexports_exact_spreadsheet_io_api(self):
        from easygraph import spreadsheet_io

        expected = [
            "OVERLAY_EXPORT_CUSTOM_ROW",
            "OVERLAY_EXPORT_NAME_COLUMN",
            "OVERLAY_EXPORT_ROW_TYPE_COLUMN",
            "OVERLAY_EXPORT_SAMPLE_ROW",
            "excel_export_dataframe",
            "excel_import_parts",
            "read_spreadsheet",
            "write_spreadsheet",
        ]
        self.assertEqual(spreadsheet_io.__all__, expected)
        for name in expected:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(spreadsheet_io, name))

    def test_direct_spreadsheet_contract_works_with_and_without_optimization(self):
        code = """
import sys
import pandas as pd
from easygraph import spreadsheet_io

frame = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]
encoded = spreadsheet_io.excel_export_dataframe(frame, overlay)
decoded, decoded_overlay = spreadsheet_io.excel_import_parts(encoded)
if not decoded.equals(frame):
    raise SystemExit("spreadsheet frame roundtrip failed")
if decoded_overlay != overlay:
    raise SystemExit("spreadsheet overlay roundtrip failed")
for forbidden in ("PySide6", "matplotlib", "seaborn", "scipy"):
    if any(
        name == forbidden or name.startswith(forbidden + ".")
        for name in sys.modules
    ):
        raise SystemExit(f"forbidden dependency loaded: {forbidden}")
"""
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(ROOT / "src")
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=15,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )


class SpreadsheetUIIntegrationTests(EasyGraphQtTestCase):

    def test_export_excel_writes_overlay_rows(self):
        window = self.make_window(initial_render=True)
        df = app.pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]
        window.settings.custom_overlay_series = overlay
        window.settings.extra_custom_overlay = True
        window.set_table_dataframe(df, overlay)

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "overlay_export.xlsx"
            with mock.patch.object(app.QFileDialog, "getSaveFileName", return_value=(str(path), "")):
                window.export_excel()

            imported_df, imported_overlay = app.excel_import_parts(app.pd.read_excel(path))

        app.pd.testing.assert_frame_equal(imported_df, df)
        self.assertEqual(imported_overlay, overlay)

    def test_import_excel_restores_overlay_rows(self):
        window = self.make_window(initial_render=True)
        df = app.pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "overlay_import.xlsx"
            app.excel_export_dataframe(df, overlay).to_excel(path, index=False)
            with mock.patch.object(app.QFileDialog, "getOpenFileName", return_value=(str(path), "")):
                window.import_excel()

        self.assertEqual(window.custom_overlay_row_count(), 1)
        self.assertTrue(window.settings.extra_custom_overlay)
        self.assertEqual(window.settings.custom_overlay_series, overlay)
        self.assertEqual(window.table.verticalHeaderItem(1).text(), "Target")
        self.assertEqual(window.table.item(1, 0).text(), "10")
        app.pd.testing.assert_frame_equal(window.table.dataframe(), df.astype(str))

    def test_import_plain_excel_clears_existing_overlay_rows(self):
        window = self.make_window(initial_render=True)
        window.add_custom_overlay_row()
        window.table.item(1, 0).setText("10")
        df = app.pd.DataFrame({"A": [1, 2], "B": [3, 4]})

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "plain_import.xlsx"
            df.to_excel(path, index=False)
            with mock.patch.object(app.QFileDialog, "getOpenFileName", return_value=(str(path), "")):
                window.import_excel()

        self.assertEqual(window.custom_overlay_row_count(), 0)
        self.assertFalse(window.settings.extra_custom_overlay)
        self.assertEqual(window.settings.custom_overlay_series, [])
        self.assertEqual(window.sample_start_row(), 1)
        app.pd.testing.assert_frame_equal(window.table.dataframe(), df.astype(str))
