import argparse
import io
import unittest

from scripts import run_tests


class TestRunnerTests(unittest.TestCase):
    def test_slowest_tests_returns_longest_first_and_respects_limit(self):
        durations = [
            ("test_fast", 0.1),
            ("test_slow", 2.5),
            ("test_medium", 1.0),
        ]

        self.assertEqual(
            run_tests.slowest_tests(durations, limit=2),
            [("test_slow", 2.5), ("test_medium", 1.0)],
        )

    def test_non_negative_int_accepts_zero_and_positive_values(self):
        self.assertEqual(run_tests.non_negative_int("0"), 0)
        self.assertEqual(run_tests.non_negative_int("3"), 3)

    def test_non_negative_int_rejects_negative_values(self):
        with self.assertRaises(argparse.ArgumentTypeError):
            run_tests.non_negative_int("-1")

    def test_run_suite_writes_summary_before_slowest_tests_to_same_stream(self):
        stream = io.StringIO()
        suite = unittest.TestSuite([unittest.FunctionTestCase(lambda: None)])

        result = run_tests.run_suite(
            suite, verbose=False, slow_limit=1, stream=stream
        )

        output = stream.getvalue()
        self.assertTrue(result.wasSuccessful())
        self.assertLess(output.index("OK"), output.index("Slowest tests:"))
        self.assertEqual(output.count("<lambda>"), 1)

    def test_run_suite_with_zero_slow_limit_writes_no_timing_rows(self):
        stream = io.StringIO()
        suite = unittest.TestSuite([unittest.FunctionTestCase(lambda: None)])

        run_tests.run_suite(suite, verbose=False, slow_limit=0, stream=stream)

        slow_section = stream.getvalue().split("Slowest tests:", 1)[1]
        self.assertEqual(slow_section.strip(), "")
