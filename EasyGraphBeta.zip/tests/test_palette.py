from unittest import mock

from tests.easygraph_case import EasyGraphTestCase, app
from easygraph import palette as palette_module


class PaletteTests(EasyGraphTestCase):

    def test_extra_overlay_palette_defaults_to_mono_and_supports_custom_colors(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            preset="Tableau 10",
            extra_custom_overlay=True,
            custom_overlay_count=2,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Index", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        expected = app.expanded_preset_palette(app.DEFAULT_OVERLAY_PALETTE, 2)

        self.assertEqual(app.overlay_palette_for(clean, settings, 2), expected)

        settings.custom_overlay_palette = "Dark Slide"
        self.assertEqual(app.overlay_palette_for(clean, settings, 2), app.expanded_preset_palette("Dark Slide", 2))

        settings.custom_overlay_colors = {app.overlay_custom_color_key(1): "#123456"}
        self.assertEqual(app.overlay_palette_for(clean, settings, 2)[1], "#123456")

    def test_overlay_palette_skips_colors_already_used_by_custom_overlays(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Overlay 2", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
                {"name": "Overlay 3", "values": {"Control": "15", "Low dose": "25", "High dose": "35"}},
            ],
        )
        first_color = app.expanded_preset_palette("Dark Slide", 3)[0]
        settings.custom_overlay_colors = {app.overlay_custom_color_key(1): first_color}

        palette = app.overlay_palette_for(clean, settings, 3)

        self.assertEqual(palette[1], app.QColor(first_color).name())
        self.assertEqual(len(palette), 3)
        self.assertEqual(len(set(palette)), 3)

    def test_filtering_custom_overlay_preserves_palette_slot_colors(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Overlay 2", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        before = app.overlay_palette_for(clean, settings, 2)[1]

        settings.custom_overlay_hidden = [0]

        self.assertEqual(app.overlay_palette_for(clean, settings, 1)[0], before)

    def test_hidden_overlay_color_still_occupies_palette_color(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Overlay 2", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        all_palette = app.overlay_palette_for(clean, settings, 2)

        settings.custom_overlay_hidden = [0]

        self.assertEqual(app.overlay_palette_for(clean, settings, 1)[0], all_palette[1])

    def test_filtering_custom_overlay_preserves_palette_slot_colors_with_stat_line(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Overlay 2", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        before = app.overlay_palette_for(clean, settings, 3)[2]

        settings.custom_overlay_hidden = [0]

        self.assertEqual(app.overlay_palette_for(clean, settings, 2)[1], before)

    def test_stat_overlay_uses_fixed_foreground_color(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(line_overlay_stat="Median", preset="Tableau 10")

        self.assertEqual(app.overlay_palette_for(clean, settings, 1), [app.stat_overlay_color(settings)])
        self.assertEqual(app.stat_overlay_color(settings), "#222222")

        settings.preset = "Dark Slide"
        self.assertEqual(app.overlay_palette_for(clean, settings, 1), ["#F9FAFB"])

    def test_stat_overlay_color_is_not_customizable(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            custom_overlay_colors={app.overlay_stat_color_key("Median"): "#123456"},
        )

        self.assertEqual(app.overlay_palette_for(clean, settings, 1), [app.stat_overlay_color(settings)])
        self.assertEqual(app.overlay_color_items(clean, settings), [])

    def test_stat_overlay_does_not_occupy_custom_overlay_palette_slot(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        settings = app.ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
            ],
        )

        palette = app.overlay_palette_for(clean, settings, 2)

        self.assertEqual(palette[0], app.stat_overlay_color(settings))
        self.assertEqual(palette[1], app.expanded_preset_palette("Dark Slide", 1)[0])

    def test_line_overlay_value_formatting(self):
        settings = app.ChartSettings(line_value_decimals=3)

        self.assertEqual(app.format_overlay_value(12.34567, settings), "12.346")

        settings.line_value_scientific = True
        settings.line_value_decimals = 2
        self.assertEqual(app.format_overlay_value(0.001234, settings), "1.23e-03")

    def test_extra_line_overlay_styles_map_to_custom_dash_patterns(self):
        self.assertEqual(app.overlay_line_style("Long dash"), (0, (10, 3)))
        self.assertEqual(app.overlay_line_style("Dense dash"), (0, (4, 1.5)))
        self.assertEqual(app.overlay_line_style("Loose dot"), (0, (1, 5)))
        self.assertEqual(app.overlay_line_style("Dash-dot-dot"), (0, (7, 2, 1, 2, 1, 2)))

    def test_auto_line_overlay_style_cycles_render_styles(self):
        settings = app.ChartSettings(line_overlay_style="Auto")
        series = {"kind": "custom", "color_key": app.overlay_custom_color_key(0)}

        resolved = [
            app.overlay_style_for_series(settings, series, index)
            for index in range(len(app.LINE_OVERLAY_RENDER_STYLES) + 2)
        ]

        self.assertEqual(resolved[: len(app.LINE_OVERLAY_RENDER_STYLES)], list(app.LINE_OVERLAY_RENDER_STYLES))
        self.assertEqual(resolved[-2:], list(app.LINE_OVERLAY_RENDER_STYLES[:2]))

    def test_custom_overlay_style_overrides_auto_line_style(self):
        settings = app.ChartSettings(
            line_overlay_style="Auto",
            custom_overlay_styles={app.overlay_custom_color_key(0): "Loose dot"},
        )
        series = {"kind": "custom", "color_key": app.overlay_custom_color_key(0)}

        self.assertEqual(app.overlay_style_for_series(settings, series, 3), "Loose dot")

    def test_custom_group_color_sets_base_and_derives_point_color(self):
        clean = app.prepare_plot_data(self.df, self.settings)
        self.settings.custom_colors = {"High dose": "#336699"}

        palette = app.palette_for(clean, self.settings)
        point_color = app.derived_group_color("#336699", "point")
        edge_color = app.derived_group_color("#336699", "edge")

        self.assertEqual(palette[2], "#336699")
        self.assertNotEqual(point_color, "#336699")
        self.assertNotEqual(edge_color, "#336699")
        self.assertTrue(point_color.startswith("#"))
        self.assertTrue(edge_color.startswith("#"))

    def test_palette_expands_without_repeating_for_many_groups(self):
        df = app.pd.DataFrame({
            "group": [f"Group {index}" for index in range(10)],
            "value": list(range(10)),
        })

        palette = app.palette_for(df, self.settings)

        self.assertEqual(len(palette), 10)
        self.assertEqual(len(set(palette)), 10)

    def test_group_palette_skips_colors_already_used_by_custom_groups(self):
        df = app.pd.DataFrame({
            "group": ["Group 1", "Group 2", "Group 3"],
            "value": [1, 2, 3],
        })
        first_color = app.expanded_preset_palette(self.settings.preset, 3)[0]
        self.settings.custom_colors = {"Group 2": first_color}

        palette = app.palette_for(df, self.settings)

        self.assertEqual(palette[1], app.QColor(first_color).name())
        self.assertEqual(len(palette), 3)
        self.assertEqual(len(set(palette)), 3)

    def test_palette_choices_offer_extra_colors_for_current_group_count(self):
        choices = app.palette_choices_for_group_count("Paper Clean", 10)

        self.assertGreater(len(choices), 10)
        self.assertEqual(len(set(choices)), len(choices))

    def test_common_palette_counts_are_loaded_from_precomputed_cache(self):
        app._precomputed_palette_cache.cache_clear()
        app._expanded_preset_palette_cached.cache_clear()

        with mock.patch.object(palette_module, "_style_matched_palette_candidates", side_effect=AssertionError("dynamic palette generation used")):
            choices = app.expanded_preset_palette("Paper Clean", 18)

        self.assertEqual(len(choices), 18)
        self.assertEqual(
            choices[:5],
            [app.QColor(color).name() for color in app.PRESETS["Paper Clean"]["palette"]],
        )

    def test_palette_counts_over_precomputed_limit_use_dynamic_generation(self):
        app._precomputed_palette_cache.cache_clear()
        app._expanded_preset_palette_cached.cache_clear()

        with mock.patch.object(palette_module, "_expanded_preset_palette_cached", return_value=tuple(["#111111"] * 101)) as dynamic_palette:
            choices = app.expanded_preset_palette("Paper Clean", 101)

        dynamic_palette.assert_called_once_with("Paper Clean", 101)
        self.assertEqual(len(choices), 101)

    def test_all_preset_palettes_expand_for_many_groups(self):
        for preset_name in app.PRESETS:
            with self.subTest(preset=preset_name):
                choices = app.palette_choices_for_group_count(preset_name, 12)

                self.assertGreater(len(choices), 12)
                self.assertEqual(len(set(choices)), len(choices))

    def test_categorical_palette_extensions_keep_visual_distance(self):
        excluded = app.SEQUENTIAL_PALETTE_PRESETS | {"Mono Print"}
        for preset_name in app.PRESETS:
            if preset_name in excluded:
                continue
            with self.subTest(preset=preset_name):
                choices = app.expanded_preset_palette(preset_name, 18)
                distances = [
                    app._minimum_lab_distance(color, choices[:index] + choices[index + 1:])
                    for index, color in enumerate(choices)
                ]

                self.assertGreaterEqual(min(distances), 16)

    def test_sequential_palette_extensions_resample_existing_gradient(self):
        choices = app.expanded_preset_palette("Viridis", 18)

        self.assertEqual(choices[0], app.PRESETS["Viridis"]["palette"][0].lower())
        self.assertEqual(choices[-1], app.PRESETS["Viridis"]["palette"][-1].lower())
        self.assertEqual(len(set(choices)), len(choices))

    def test_monochrome_palette_expands_only_with_grayscale_colors(self):
        choices = app.palette_choices_for_group_count("Mono Print", 10)

        self.assertGreater(len(choices), 10)
        for color in choices:
            qcolor = app.QColor(color)
            self.assertEqual(qcolor.red(), qcolor.green())
            self.assertEqual(qcolor.green(), qcolor.blue())

    def test_expanded_palette_keeps_custom_group_color_override(self):
        df = app.pd.DataFrame({
            "group": [f"Group {index}" for index in range(10)],
            "value": list(range(10)),
        })
        self.settings.custom_colors = {"Group 9": "#123456"}

        palette = app.palette_for(df, self.settings)

        self.assertEqual(palette[9], "#123456")
