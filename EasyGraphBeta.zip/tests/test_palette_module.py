import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase, app


class PaletteModuleTests(EasyGraphTestCase):
    def test_app_reexports_palette_module_api(self):
        from easygraph import palette

        expected_exports = (
            "PRECOMPUTED_PALETTE_COUNT",
            "PRECOMPUTED_PALETTE_PATH",
            "blend_qcolors",
            "derived_group_color",
            "expanded_preset_palette",
            "first_unused_palette_color",
            "group_color_map_for_groups",
            "normalize_color_name",
            "palette_choices_for_group_count",
            "palette_for",
        )
        private_exports = (
            "_append_farthest_lab_colors",
            "_contrast_ratio",
            "_expanded_monochrome_palette",
            "_expanded_preset_palette_cached",
            "_lab_distance",
            "_minimum_lab_distance",
            "_palette_is_monochrome",
            "_precomputed_palette_cache",
            "_precomputed_palette_for",
            "_qcolor_to_lab",
            "_relative_luminance",
            "_resampled_sequential_palette",
            "_style_matched_palette_candidates",
        )

        self.assertEqual(palette.__all__, list(expected_exports))
        for name in expected_exports + private_exports:
            with self.subTest(name=name):
                self.assertIs(getattr(app, name), getattr(palette, name))

    def test_palette_module_imports_without_widgets_or_plotting_stack(self):
        environment = os.environ.copy()
        source_path = str(ROOT / "src")
        existing_pythonpath = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = (
            source_path + os.pathsep + existing_pythonpath
            if existing_pythonpath
            else source_path
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.palette import expanded_preset_palette

colors = expanded_preset_palette("Paper Clean", 8)
if len(colors) != 8:
    raise SystemExit(f"expected 8 palette colors, got {{len(colors)}}")
if "PySide6.QtWidgets" in sys.modules:
    raise SystemExit("easygraph.palette imported PySide6.QtWidgets")
for forbidden_root in ("matplotlib", "seaborn", "scipy"):
    if any(
        name == forbidden_root or name.startswith(forbidden_root + ".")
        for name in sys.modules
    ):
        raise SystemExit(f"easygraph.palette imported {{forbidden_root}}")
"""

        result = subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True,
            text=True,
            env=environment,
            cwd=ROOT,
            check=False,
            timeout=15,
        )

        self.assertEqual(result.returncode, 0, result.stderr)

    def test_precomputed_palette_path_points_to_packaged_cache(self):
        from easygraph import palette

        self.assertEqual(
            palette.PRECOMPUTED_PALETTE_PATH,
            ROOT / "src" / "palette_cache.json",
        )
        self.assertTrue(palette.PRECOMPUTED_PALETTE_PATH.is_file())
