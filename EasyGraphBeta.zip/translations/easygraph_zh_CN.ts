<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>GroupOrderDialog</name>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="6"/>
        <source>Edit Group Order</source>
        <translation>编辑分组顺序</translation>
    </message>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="15"/>
        <source>Drag groups to change plot order.</source>
        <translation>拖动分组以调整绘图顺序。</translation>
    </message>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="37"/>
        <source>Table Order</source>
        <translation>表格顺序</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ui/main_window.ui" line="289"/>
        <source>Colors</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Legend size</source>
        <translation type="vanished">图例字号</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3360"/>
        <location filename="../ui/main_window.ui" line="186"/>
        <source>Legend</source>
        <translation>图例</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3392"/>
        <location filename="../src/app.py" line="3393"/>
        <location filename="../src/app.py" line="3721"/>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Auto wrap</source>
        <translation type="vanished">自动换行</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3398"/>
        <source>Columns</source>
        <translation>列数</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3408"/>
        <source>Auto Primary Y Tick Interval</source>
        <translation>自动主Y轴刻度间距</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3413"/>
        <source>Primary Y tick interval</source>
        <translation>主Y轴刻度间距</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3440"/>
        <source>Auto Secondary Y Tick Interval</source>
        <translation>自动次Y轴刻度间距</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3445"/>
        <source>Secondary Y tick interval</source>
        <translation>次Y轴刻度间距</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3525"/>
        <source>Custom styles</source>
        <translation>自定义样式</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3527"/>
        <source>Custom line styles</source>
        <translation>自定义线形状</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3957"/>
        <source>Overlay filter</source>
        <translation>叠加线过滤器</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3963"/>
        <source>Show custom overlays</source>
        <translation>显示自定义叠加线</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4100"/>
        <source>No Recent Projects</source>
        <translation>没有最近项目</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4112"/>
        <source>Clear Recent Projects</source>
        <translation>清除最近项目</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4120"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4124"/>
        <source>System</source>
        <translation>跟随系统</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4126"/>
        <source>Simplified Chinese</source>
        <translation>简体中文</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4137"/>
        <source>Undo Table Change</source>
        <translation>撤回表格修改</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4141"/>
        <source>Redo Table Change</source>
        <translation>重做表格修改</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4157"/>
        <source>Language changed</source>
        <translation>语言已更改</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4158"/>
        <source>Restart EasyGraph to apply the language change.</source>
        <translation>重启 EasyGraph 后语言更改会生效。</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4492"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4496"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4499"/>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4678"/>
        <location filename="../src/app.py" line="4683"/>
        <source>Group Filter</source>
        <translation>分组过滤器</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4679"/>
        <source>Add a group first.</source>
        <translation>请先一个添加分组。</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4724"/>
        <location filename="../src/app.py" line="5366"/>
        <source>Overlay: {name}</source>
        <translation>叠加线：{name}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4742"/>
        <source>Edit Group Colors</source>
        <translation>编辑分组颜色</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4746"/>
        <location filename="../ui/main_window.ui" line="279"/>
        <source>Palette</source>
        <translation>调色板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4758"/>
        <source>Overlay palette</source>
        <translation>叠加线调色板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4908"/>
        <location filename="../src/app.py" line="5383"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5332"/>
        <location filename="../src/app.py" line="5341"/>
        <source>Custom Overlay Line Styles</source>
        <translation>自定义叠加线线型</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5696"/>
        <source>Auto Primary {value_axis_name} Range</source>
        <translation>自动主坐标轴 {value_axis_name} 范围</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5697"/>
        <source>Primary {value_axis_name} min</source>
        <translation>主坐标轴 {value_axis_name} 最小值</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5698"/>
        <source>Primary {value_axis_name} max</source>
        <translation>主坐标轴 {value_axis_name} 最大值</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5699"/>
        <source>Auto Primary {value_axis_name} Tick Interval</source>
        <translation>自动主坐标轴 {value_axis_name} 刻度间距</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5700"/>
        <source>Primary {value_axis_name} tick interval</source>
        <translation>主坐标轴 {value_axis_name} 刻度间距</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5701"/>
        <source>Auto Secondary {value_axis_name} Range</source>
        <translation>自动次坐标轴 {value_axis_name} 范围</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5702"/>
        <source>Secondary {value_axis_name} min</source>
        <translation>次坐标轴 {value_axis_name} 最小值</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5703"/>
        <source>Secondary {value_axis_name} max</source>
        <translation>次坐标轴 {value_axis_name} 最大值</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5704"/>
        <source>Auto Secondary {value_axis_name} Tick Interval</source>
        <translation>自动次坐标轴 {value_axis_name} 刻度间距</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5705"/>
        <source>Secondary {value_axis_name} tick interval</source>
        <translation>次坐标轴 {value_axis_name} 刻度间距</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4695"/>
        <location filename="../src/app.py" line="4950"/>
        <location filename="../src/app.py" line="5306"/>
        <location filename="../src/app.py" line="5402"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3340"/>
        <source>Secondary value 
axis title</source>
        <translation>次数值
坐标轴标题</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3377"/>
        <location filename="../src/app.py" line="3379"/>
        <location filename="../src/app.py" line="3707"/>
        <source>Right side</source>
        <translation>右侧</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3377"/>
        <location filename="../src/app.py" line="3379"/>
        <location filename="../src/app.py" line="3702"/>
        <location filename="../src/app.py" line="3707"/>
        <source>Inside plot</source>
        <translation>绘图区内</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3394"/>
        <source>Show legend</source>
        <translation>显示图例</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3395"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3396"/>
        <source>Auto width</source>
        <translation>自动宽度</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4696"/>
        <location filename="../src/app.py" line="4951"/>
        <location filename="../src/app.py" line="5307"/>
        <location filename="../src/app.py" line="5403"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5185"/>
        <source>Style template applied: {name}</source>
        <translation>已应用样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5193"/>
        <location filename="../src/app.py" line="5913"/>
        <location filename="../src/app.py" line="5937"/>
        <source>Template load failed</source>
        <translation>模板加载失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5249"/>
        <source>Delete Overlay</source>
        <translation>删除叠加线</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5250"/>
        <source>Delete overlay &apos;{name}&apos;? Its values will be permanently lost.</source>
        <translation>确认删除叠加线{name}? 叠加线对应数值将被永久删除。</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5288"/>
        <location filename="../src/app.py" line="5293"/>
        <source>Overlay Filter</source>
        <translation>叠加线过滤器</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5289"/>
        <location filename="../src/app.py" line="5333"/>
        <source>Add an overlay row first.</source>
        <translation>请先添加一行叠加线。</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5420"/>
        <source>Rename Overlay</source>
        <translation>重命名叠加线</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5420"/>
        <source>Legend name</source>
        <translation>图例名称</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5475"/>
        <source>Group name</source>
        <translation>分组名称</translation>
    </message>
    <message>
        <source>Auto X range</source>
        <translation type="vanished">自动 X 范围</translation>
    </message>
    <message>
        <source>X min</source>
        <translation type="vanished">X 最小值</translation>
    </message>
    <message>
        <source>X max</source>
        <translation type="vanished">X 最大值</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5919"/>
        <source>Save Style Template</source>
        <translation>保存样式模板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5919"/>
        <source>Template name</source>
        <translation>模板名称</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5925"/>
        <source>Template save failed</source>
        <translation>模板保存失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5928"/>
        <source>Style template saved: {name}</source>
        <translation>已保存样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5931"/>
        <source>Load Style Template</source>
        <translation>加载样式模板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5931"/>
        <source>Style Template (*.json);;All Files (*)</source>
        <translation>样式模板 (*.json);;所有文件 (*)</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5942"/>
        <source>Style template loaded: {name}</source>
        <translation>已加载样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5954"/>
        <location filename="../src/app.py" line="5960"/>
        <source>EasyGraph Project (*.eg);;All Files (*)</source>
        <translation>EasyGraph 项目 (*.eg);;所有文件 (*)</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5972"/>
        <location filename="../src/app.py" line="5983"/>
        <source>Recent project unavailable</source>
        <translation>最近项目不可用</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5973"/>
        <location filename="../src/app.py" line="5984"/>
        <source>The selected recent project could not be found:
{path}</source>
        <translation>找不到所选的最近项目：
{path}</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5987"/>
        <source>Project open failed</source>
        <translation>项目打开失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6147"/>
        <source>Figure image copied to clipboard</source>
        <translation>图形图片已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6149"/>
        <source>Copy failed</source>
        <translation>复制失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6149"/>
        <source>Could not copy the figure to the clipboard.</source>
        <translation>无法将图形复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="14"/>
        <source>EasyGraph</source>
        <translation>EasyGraph</translation>
    </message>
    <message>
        <source>Data</source>
        <translation type="vanished">数据</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="499"/>
        <source>+ Row</source>
        <translation>+ 行</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="506"/>
        <source>+ Column</source>
        <translation>+ 列</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="513"/>
        <source>- Column</source>
        <translation>- 列</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5475"/>
        <location filename="../ui/main_window.ui" line="520"/>
        <source>Rename Group</source>
        <translation>重命名分组</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="329"/>
        <source>Style Templates</source>
        <translation>样式模板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="339"/>
        <source>Load...</source>
        <translation>加载...</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="346"/>
        <source>Save Current</source>
        <translation>保存当前</translation>
    </message>
    <message>
        <source>Chart</source>
        <translation type="vanished">图表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="269"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Preset</source>
        <translation type="vanished">预设</translation>
    </message>
    <message>
        <source>Group order</source>
        <translation type="vanished">分组顺序</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="4136"/>
        <location filename="../ui/main_window.ui" line="306"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="135"/>
        <location filename="../ui/main_window.ui" line="618"/>
        <location filename="../ui/main_window.ui" line="651"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3347"/>
        <location filename="../ui/main_window.ui" line="673"/>
        <location filename="../ui/main_window.ui" line="702"/>
        <location filename="../ui/main_window.ui" line="732"/>
        <source>Enter to line break</source>
        <translation>按 Enter 换行</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="680"/>
        <source>Group axis title</source>
        <translation>分组坐标轴标题</translation>
    </message>
    <message>
        <source>Primary value axis title</source>
        <translation type="vanished">主数值坐标轴标题</translation>
    </message>
    <message>
        <source>Secondary value axis title</source>
        <translation type="vanished">次数值坐标轴标题</translation>
    </message>
    <message>
        <source>Use secondary axis</source>
        <translation type="vanished">使用次坐标轴</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3421"/>
        <source>Auto Secondary Y Range</source>
        <translation>自动次 Y 范围</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3426"/>
        <source>Secondary Y min</source>
        <translation>次 Y 轴 min</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3433"/>
        <source>Secondary Y max</source>
        <translation>次 Y 轴 max</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3453"/>
        <source>Split secondary frame</source>
        <translation>拆分次坐标轴绘图区</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3458"/>
        <source>Secondary frame ratio</source>
        <translation>次坐标轴绘图区占比</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3397"/>
        <source>Width (cm)</source>
        <translation>宽度 (cm)</translation>
    </message>
    <message>
        <source>Height (cm)</source>
        <translation type="vanished">高度 (cm)</translation>
    </message>
    <message>
        <source>Export DPI</source>
        <translation type="vanished">导出 DPI</translation>
    </message>
    <message>
        <source>Transparent bg</source>
        <translation type="vanished">透明背景</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2706"/>
        <source>Copy as Image</source>
        <translation>复制为图片</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="102"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Title size</source>
        <translation type="vanished">标题字号</translation>
    </message>
    <message>
        <source>Axis label size</source>
        <translation type="vanished">坐标轴标签字号</translation>
    </message>
    <message>
        <source>Tick size</source>
        <translation type="vanished">刻度字号</translation>
    </message>
    <message>
        <source>Overlay value size</source>
        <translation type="vanished">叠加数值字号</translation>
    </message>
    <message>
        <source>Stats table size</source>
        <translation type="vanished">统计表字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="152"/>
        <source>Axis</source>
        <translation>坐标轴</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="842"/>
        <source>Show grid</source>
        <translation>显示网格</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="884"/>
        <source>Auto Primary Y Range</source>
        <translation>自动主 Y 范围</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="926"/>
        <source>Primary Y min</source>
        <translation>主 Y 轴 min</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="978"/>
        <source>Primary Y max</source>
        <translation>主 Y 轴 max</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1030"/>
        <source>Axis line width</source>
        <translation>坐标轴线宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1082"/>
        <source>X label rotation</source>
        <translation>X 标签旋转</translation>
    </message>
    <message>
        <source>Data Points</source>
        <translation type="vanished">数据点</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1212"/>
        <source>Show all points</source>
        <translation>显示所有点</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1254"/>
        <location filename="../ui/main_window.ui" line="1945"/>
        <source>Point size</source>
        <translation>点大小</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1306"/>
        <source>Point alpha</source>
        <translation>点透明度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1358"/>
        <source>Jitter mode</source>
        <translation>抖动模式</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1400"/>
        <source>Jitter</source>
        <translation>抖动</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1633"/>
        <source>Line Overlay</source>
        <translation>折线叠加</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1666"/>
        <source>Show line</source>
        <translation>显示折线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1708"/>
        <source>Trend overlay</source>
        <translation>趋势叠加</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1750"/>
        <source>Extra custom overlay</source>
        <translation>额外自定义叠加线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1792"/>
        <source>Custom line count</source>
        <translation>自定义线数量</translation>
    </message>
    <message>
        <source>Statistic</source>
        <translation type="vanished">统计量</translation>
    </message>
    <message>
        <source>Overlay +</source>
        <translation type="vanished">叠加线 +</translation>
    </message>
    <message>
        <source>Overlay -</source>
        <translation type="vanished">叠加线 -</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="527"/>
        <source>+ Overlay</source>
        <translation>+ 叠加线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="534"/>
        <source>- Overlay</source>
        <translation>- 叠加线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="709"/>
        <source>Primary value 
axis title</source>
        <translation>主数值
坐标轴标题</translation>
    </message>
    <message>
        <source>Plot area width (cm)</source>
        <translation type="vanished">绘图区宽度 (cm)</translation>
    </message>
    <message>
        <source>Plot area height (cm)</source>
        <translation type="vanished">绘图区高度 (cm)</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="775"/>
        <source>Group filter</source>
        <translation>分组过滤器</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="797"/>
        <location filename="../ui/main_window.ui" line="1842"/>
        <source>Filter</source>
        <translation>过滤</translation>
    </message>
    <message>
        <source>All sizes</source>
        <translation type="vanished">全部字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="128"/>
        <source>A-</source>
        <translation>A-</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="115"/>
        <source>A+</source>
        <translation>A+</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="72"/>
        <source>Clipboard</source>
        <translation>剪贴板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="79"/>
        <source>Copy Image</source>
        <translation>复制为图片</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="169"/>
        <source>Tick</source>
        <translation>刻度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="206"/>
        <source>Data label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="226"/>
        <source>Stats table</source>
        <translation>统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="262"/>
        <source>Chart Basics</source>
        <translation>图表基础</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="296"/>
        <source>Order</source>
        <translation>顺序</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="369"/>
        <source>Export &amp; Canvas</source>
        <translation>输出&amp;画布</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="376"/>
        <source>W</source>
        <translation>宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="396"/>
        <source>H</source>
        <translation>高</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="416"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="451"/>
        <source>Transparent</source>
        <translation>透明背景</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="742"/>
        <source>Selection / Filter</source>
        <translation>选择 / 过滤</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="809"/>
        <source>Axis &amp; Range</source>
        <translation>坐标轴 &amp; 范围</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1134"/>
        <source>Use secondary axis for lines</source>
        <translation>叠加线使用次坐标轴</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3552"/>
        <source>Primary Axis</source>
        <translation>主坐标轴</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3556"/>
        <source>Secondary Axis</source>
        <translation>次坐标轴</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="3575"/>
        <source>叠加线使用次坐标轴</source>
        <translation>叠加线使用次坐标轴</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1179"/>
        <source>Data Points &amp; Outliers</source>
        <translation>数据点 &amp; 异常值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1851"/>
        <source>Line width</source>
        <translation>线宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1903"/>
        <source>Line style</source>
        <translation>线型</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1997"/>
        <source>Show values</source>
        <translation>显示数值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2039"/>
        <source>Label position</source>
        <translation>标签位置</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2081"/>
        <source>Extra label position</source>
        <translation>额外标签位置</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2123"/>
        <source>Scientific</source>
        <translation>科学计数法</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2165"/>
        <source>Decimals</source>
        <translation>小数位数</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2220"/>
        <source>Stats Table</source>
        <translation>统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2241"/>
        <source>Show statistics table</source>
        <translation>显示统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2251"/>
        <source>Show header</source>
        <translation>显示表头</translation>
    </message>
    <message>
        <source>Outliers</source>
        <translation type="vanished">离群值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1452"/>
        <source>Highlight</source>
        <translation>高亮</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1494"/>
        <source>Method</source>
        <translation>方法</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1536"/>
        <source>Threshold</source>
        <translation>阈值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1588"/>
        <source>Effect</source>
        <translation>效果</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2286"/>
        <source>Type-specific</source>
        <translation>类型专属</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2319"/>
        <source>Box width</source>
        <translation>箱体宽度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2371"/>
        <source>Box whisker mode</source>
        <translation>箱线须模式</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2413"/>
        <source>Violin width</source>
        <translation>小提琴宽度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2465"/>
        <source>KDE bandwidth</source>
        <translation>KDE 带宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2517"/>
        <source>Ridge overlap</source>
        <translation>山脊重叠</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2569"/>
        <source>Fill alpha</source>
        <translation>填充透明度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2652"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2656"/>
        <source>Open Recent</source>
        <translation>打开最近项目</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2676"/>
        <source>New</source>
        <translation>新建</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5960"/>
        <location filename="../ui/main_window.ui" line="2681"/>
        <source>Open Project</source>
        <translation>打开项目</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="5954"/>
        <location filename="../ui/main_window.ui" line="2686"/>
        <source>Save Project</source>
        <translation>保存项目</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2691"/>
        <source>Save Project As</source>
        <translation>项目另存为</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6084"/>
        <location filename="../ui/main_window.ui" line="2696"/>
        <source>Import Excel</source>
        <translation>导入 Excel</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6084"/>
        <source>Excel Files (*.xlsx *.xls);;CSV Files (*.csv)</source>
        <translation>Excel 文件 (*.xlsx *.xls);;CSV 文件 (*.csv)</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6100"/>
        <source>Import failed</source>
        <translation>导入失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6103"/>
        <location filename="../ui/main_window.ui" line="2701"/>
        <source>Export Excel</source>
        <translation>导出 Excel</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6103"/>
        <source>Excel File (*.xlsx);;CSV File (*.csv)</source>
        <translation>Excel 文件 (*.xlsx);;CSV 文件 (*.csv)</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6117"/>
        <source>Export failed</source>
        <translation>导出失败</translation>
    </message>
    <message>
        <location filename="../src/app.py" line="6129"/>
        <location filename="../ui/main_window.ui" line="2711"/>
        <source>Export Figure</source>
        <translation>导出图形</translation>
    </message>
</context>
</TS>
