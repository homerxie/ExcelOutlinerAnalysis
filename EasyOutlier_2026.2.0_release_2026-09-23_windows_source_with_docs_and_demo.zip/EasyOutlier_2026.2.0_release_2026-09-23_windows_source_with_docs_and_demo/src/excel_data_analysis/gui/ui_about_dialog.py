# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'about_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QHBoxLayout, QLabel, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_AboutDialog(object):
    def setupUi(self, AboutDialog):
        if not AboutDialog.objectName():
            AboutDialog.setObjectName(u"AboutDialog")
        AboutDialog.resize(520, 220)
        self.verticalLayout = QVBoxLayout(AboutDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.contentLayout = QHBoxLayout()
        self.contentLayout.setObjectName(u"contentLayout")
        self.iconLabel = QLabel(AboutDialog)
        self.iconLabel.setObjectName(u"iconLabel")
        self.iconLabel.setMinimumSize(QSize(144, 144))
        self.iconLabel.setMaximumSize(QSize(160, 160))
        self.iconLabel.setAlignment(Qt.AlignCenter)

        self.contentLayout.addWidget(self.iconLabel)

        self.textLayout = QVBoxLayout()
        self.textLayout.setObjectName(u"textLayout")
        self.summaryLabel = QLabel(AboutDialog)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)
        self.summaryLabel.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)

        self.textLayout.addWidget(self.summaryLabel)

        self.versionLabel = QLabel(AboutDialog)
        self.versionLabel.setObjectName(u"versionLabel")

        self.textLayout.addWidget(self.versionLabel)

        self.teamLabel = QLabel(AboutDialog)
        self.teamLabel.setObjectName(u"teamLabel")

        self.textLayout.addWidget(self.teamLabel)

        self.textSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.textLayout.addItem(self.textSpacer)


        self.contentLayout.addLayout(self.textLayout)


        self.verticalLayout.addLayout(self.contentLayout)

        self.buttonBox = QDialogButtonBox(AboutDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(AboutDialog)
        self.buttonBox.accepted.connect(AboutDialog.accept)

        QMetaObject.connectSlotsByName(AboutDialog)
    # setupUi

    def retranslateUi(self, AboutDialog):
        AboutDialog.setWindowTitle(QCoreApplication.translate("AboutDialog", u"About Easy Outlier", None))
        self.iconLabel.setText(QCoreApplication.translate("AboutDialog", u"Icon", None))
        self.summaryLabel.setText(QCoreApplication.translate("AboutDialog", u"Easy Outlier helps teams import evolving test data, compare it with golden or z-score criteria, and generate highly configurable outlier reports with node-aware tracking.", None))
        self.versionLabel.setText(QCoreApplication.translate("AboutDialog", u"Version: 2026.2.0", None))
        self.teamLabel.setText(QCoreApplication.translate("AboutDialog", u"Team: XXX", None))
    # retranslateUi

