"""Independent TSK controls and result binding; form geometry lives in .ui files."""
from __future__ import annotations

from dataclasses import asdict, is_dataclass
import json
import math
from pathlib import Path
import re

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, Signal
from PySide6.QtWidgets import QApplication, QAbstractItemView, QHeaderView, QLineEdit, QListWidgetItem, QTableWidgetItem, QWidget

from ..field_names import field_key

from .ui_tsk_analysis_panel import Ui_TskAnalysisPanelForm
from .ui_tsk_results_panel import Ui_TskResultsPanelForm


def _mapping(value):
    if isinstance(value, dict):
        return value
    return asdict(value) if is_dataclass(value) else {}


def _values(text):
    return list(dict.fromkeys(part.strip() for part in re.split(r"[,，\n]+", text) if part.strip()))


def _finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


class TskAnalysisPanel(QWidget):
    run_requested = Signal(object)
    refresh_requested = Signal()
    batch_scan_requested = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskAnalysisPanelForm()
        self.ui.setupUi(self)
        self.template = None
        self._template_ready = False
        self._ready_override = None
        self._pending_dataset_ids = set()
        self._pending_feature_names = None
        self._batch_mode = "none"
        self._batch_dimension = ""
        self._batch_mappings = {}
        self._batch_values = {}
        for combo, codes in (
            (self.ui.sourceComboBox, ("database", "input")),
            (self.ui.scopeComboBox, ("entire_database", "checked_imports")),
            (self.ui.failMethodComboBox, ("modified_z_score", "golden_deviation", "zscore_and_golden", "zscore_or_golden")),
            (self.ui.batchModeComboBox, ("none", "separate", "parent")),
            (self.ui.classificationPoolComboBox, ("original_batch", "selected_scope")),
        ):
            for index, code in enumerate(codes):
                combo.setItemData(index, code)
        self.ui.sourceComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.scopeComboBox.currentIndexChanged.connect(self._update_state)
        self.ui.importsListWidget.itemChanged.connect(self._imports_changed)
        self.ui.featuresListWidget.itemChanged.connect(self._features_changed)
        self.ui.batchModeComboBox.currentIndexChanged.connect(self._batch_mode_changed)
        self.ui.batchDimensionComboBox.currentIndexChanged.connect(self._batch_dimension_changed)
        self.ui.batchMappingTableWidget.itemChanged.connect(self._batch_mapping_changed)
        self.ui.scanBatchesButton.clicked.connect(lambda: self.batch_scan_requested.emit(self.settings()))
        self.ui.refreshButton.clicked.connect(self.refresh_requested)
        self.ui.runButton.clicked.connect(lambda: self.run_requested.emit(self.settings()))

    @staticmethod
    def _checked_values(widget):
        return [str(widget.item(index).data(Qt.UserRole)) for index in range(widget.count())
                if widget.item(index).checkState() == Qt.Checked]

    @staticmethod
    def _select_code(combo, code):
        index = combo.findData(code)
        if index >= 0:
            combo.setCurrentIndex(index)

    def _imports_changed(self, *_args):
        self._pending_dataset_ids = set(self._checked_values(self.ui.importsListWidget))

    def _features_changed(self, *_args):
        self._pending_feature_names = self._checked_values(self.ui.featuresListWidget)

    def set_template(self, template):
        self.template = template
        config = _mapping(getattr(template, "tsk_analysis", None))
        instances = [_mapping(item) for item in config.get("instances", [])]
        self._template_ready = bool(config.get("enabled") and instances)
        self._ready_override = None
        complete_xy = sum(_finite(item.get("x")) and _finite(item.get("y")) for item in instances)
        if not instances:
            summary = self.ui.topologySummaryLabel.property("emptyText")
        else:
            chains = {tuple(item.get("chain_key") or [item.get("chain_id", "")]) for item in instances}
            types = {item.get("tsk_id") for item in instances}
            summary = (f"{len(chains)} Chains · {len(types)} TSK types · {len(instances)} instances\n"
                       f"有效 XY：{complete_xy}/{len(instances)} · 坐标单位：{config.get('coordinate_unit') or '未指定'}")
        if not config.get("enabled"):
            summary = f"{self.ui.topologySummaryLabel.property('disabledText')}\n{summary}"
        self.ui.topologySummaryLabel.setText(str(summary))
        self.ui.includeXYCheckBox.setEnabled(bool(complete_xy))
        self.ui.includeXYCheckBox.setChecked(bool(config.get("use_xy")))
        self.ui.groupDimensionsEdit.setText(", ".join(config.get("group_by_dimensions", [])))
        self._select_code(self.ui.failMethodComboBox, getattr(getattr(template, "report", None), "outlier_fail_method", "modified_z_score"))
        features = sorted(set(config.get("feature_columns", [])) |
                          {key for item in instances for key in item.get("features", {})}, key=str.casefold)
        selected = set(config.get("feature_columns", []))
        self.ui.featuresListWidget.blockSignals(True)
        self.ui.featuresListWidget.clear()
        for name in features:
            item = QListWidgetItem(name)
            item.setData(Qt.UserRole, name)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if name in selected else Qt.Unchecked)
            self.ui.featuresListWidget.addItem(item)
        self.ui.featuresListWidget.blockSignals(False)
        self._pending_feature_names = None
        self.ui.featuresListWidget.setEnabled(bool(features))
        dimensions = [dimension.name for dimension in getattr(template, "row_dimensions", [])]
        node = getattr(getattr(template, "report", None), "reliability_node_dimension", "")
        available = [name for name in dimensions if name != node]
        self.ui.dimensionHintLabel.setText(f"Node 自动分组：{node or '未配置'}；可用条件字段：{', '.join(available) or '无'}")
        self.ui.groupDimensionsEdit.setToolTip(", ".join(available))
        self._reset_batch_dimensions(available)
        self._update_state()

    def _reset_batch_dimensions(self, dimensions):
        self.ui.batchModeComboBox.blockSignals(True)
        self.ui.batchDimensionComboBox.blockSignals(True)
        self.ui.batchModeComboBox.setCurrentIndex(0)
        self.ui.classificationPoolComboBox.setCurrentIndex(0)
        self.ui.batchDimensionComboBox.clear()
        for name in dimensions:
            self.ui.batchDimensionComboBox.addItem(name, name)
        def preference(name):
            key = field_key(name)
            return 0 if key == "lotid" else 1 if "lot" in key else 2 if "batch" in key else 3 if "批次" in key else 4
        if dimensions:
            self._select_code(self.ui.batchDimensionComboBox, min(dimensions, key=preference))
        self.ui.batchModeComboBox.blockSignals(False)
        self.ui.batchDimensionComboBox.blockSignals(False)
        self._batch_mode = "none"
        self._batch_dimension = str(self.ui.batchDimensionComboBox.currentData() or "")
        self._batch_mappings.clear()
        self._batch_values.clear()
        self._render_batch_values()

    def _commit_batch_editor(self):
        """Read the current editor before run, scan, persistence or hiding rows."""
        table = self.ui.batchMappingTableWidget
        editor = QApplication.focusWidget()
        if isinstance(editor, QLineEdit) and table.isAncestorOf(editor):
            index = table.currentIndex()
            if index.isValid() and index.column() == 1:
                table.itemDelegateForIndex(index).setModelData(editor, table.model(), index)

    def _remember_batch_mapping(self):
        self._commit_batch_editor()
        if not self._batch_dimension:
            return
        mapping = self._batch_mappings.setdefault(self._batch_dimension, {})
        table = self.ui.batchMappingTableWidget
        for row in range(table.rowCount()):
            source, parent = table.item(row, 0), table.item(row, 1)
            if source is not None and parent is not None:
                mapping[str(source.data(Qt.UserRole))] = parent.text().strip()

    def _batch_mode_changed(self, *_args):
        self._remember_batch_mapping()
        mode = str(self.ui.batchModeComboBox.currentData() or "none")
        if self._batch_mode == "none" and mode != "none":
            self._select_code(self.ui.classificationPoolComboBox, "original_batch")
        self._batch_mode = mode
        self._update_state()

    def _batch_dimension_changed(self, *_args):
        self._remember_batch_mapping()
        self._batch_dimension = str(self.ui.batchDimensionComboBox.currentData() or "")
        self._render_batch_values()
        self._update_state()

    def _batch_mapping_changed(self, item):
        if item.column() == 1 and self._batch_dimension:
            source = self.ui.batchMappingTableWidget.item(item.row(), 0)
            if source is not None:
                self._batch_mappings.setdefault(self._batch_dimension, {})[str(source.data(Qt.UserRole))] = item.text().strip()

    def _render_batch_values(self):
        table = self.ui.batchMappingTableWidget
        values = self._batch_values.get(self._batch_dimension, [])
        mapping = self._batch_mappings.get(self._batch_dimension, {})
        table.blockSignals(True)
        table.setRowCount(0)
        table.setRowCount(len(values))
        for row, value in enumerate(values):
            source = QTableWidgetItem(value)
            source.setData(Qt.UserRole, value)
            source.setFlags(source.flags() & ~Qt.ItemIsEditable)
            parent = QTableWidgetItem(mapping.get(value, value))
            if self._batch_mode != "parent":
                parent.setFlags(parent.flags() & ~Qt.ItemIsEditable)
            table.setItem(row, 0, source)
            table.setItem(row, 1, parent)
        table.blockSignals(False)

    def set_batch_values(self, values: list[str]):
        self._remember_batch_mapping()
        if not self._batch_dimension:
            return
        values = list(dict.fromkeys(str(value) for value in values))
        mapping = self._batch_mappings.setdefault(self._batch_dimension, {})
        for value in values:
            mapping.setdefault(value, value)
        self._batch_values[self._batch_dimension] = values
        self._render_batch_values()
        self._update_state()

    def set_import_entries(self, entries):
        selected = self._pending_dataset_ids | set(self._checked_values(self.ui.importsListWidget))
        self.ui.importsListWidget.blockSignals(True)
        self.ui.importsListWidget.clear()
        for entry in entries or []:
            dataset_id = str(entry.get("dataset_id", ""))
            if not dataset_id:
                continue
            label = (f"{entry.get('created_at_utc', '')} | {dataset_id} | "
                     f"{Path(str(entry.get('source_file') or '')).name} | {entry.get('measurement_count', '')} measurements")
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, dataset_id)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if dataset_id in selected else Qt.Unchecked)
            self.ui.importsListWidget.addItem(item)
        self.ui.importsListWidget.blockSignals(False)
        self._pending_dataset_ids = selected
        self._update_state()

    def set_context(self, mapping_summary: str = "", *, ready: bool | None = None):
        if mapping_summary:
            self.ui.contextLabel.setText(mapping_summary)
        self._ready_override = ready
        self._update_state()

    def _update_state(self, *_args):
        database = self.ui.sourceComboBox.currentData() == "database"
        self.ui.scopeComboBox.setEnabled(database)
        self.ui.refreshButton.setEnabled(database)
        self.ui.importsListWidget.setEnabled(database and self.ui.scopeComboBox.currentData() == "checked_imports")
        self.ui.runButton.setEnabled(self._template_ready if self._ready_override is None else self._ready_override)
        batch_enabled = self._batch_mode != "none"
        parent_mode = self._batch_mode == "parent"
        self.ui.batchDimensionComboBox.setEnabled(batch_enabled and self.ui.batchDimensionComboBox.count() > 0)
        self.ui.classificationPoolComboBox.setEnabled(batch_enabled)
        self.ui.scanBatchesButton.setEnabled(batch_enabled and bool(self._batch_dimension))
        for widget in (self.ui.batchMappingHintLabel, self.ui.batchMappingTableWidget, self.ui.batchScanHintLabel):
            widget.setVisible(batch_enabled)
        self.ui.batchMappingHintLabel.setText(self.ui.batchMappingHintLabel.property("parentText" if parent_mode else "separateText"))
        table = self.ui.batchMappingTableWidget
        table.setEnabled(batch_enabled)
        table.setColumnHidden(1, not parent_mode)
        table.setEditTriggers((QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed | QAbstractItemView.SelectedClicked)
                              if parent_mode else QAbstractItemView.NoEditTriggers)
        table.blockSignals(True)
        for row in range(table.rowCount()):
            item = table.item(row, 1)
            item.setFlags((item.flags() | Qt.ItemIsEditable) if parent_mode else (item.flags() & ~Qt.ItemIsEditable))
        table.blockSignals(False)

    def settings(self):
        self._remember_batch_mapping()
        return {
            "source": self.ui.sourceComboBox.currentData(),
            "analysis_scope": self.ui.scopeComboBox.currentData(),
            "dataset_ids": self._checked_values(self.ui.importsListWidget),
            "fail_method": self.ui.failMethodComboBox.currentData(),
            "nodes": _values(self.ui.nodesEdit.text()),
            "sample_ids": _values(self.ui.samplesEdit.text()),
            "group_by_dimensions": _values(self.ui.groupDimensionsEdit.text()),
            "batch_mode": self._batch_mode,
            "batch_dimension": self._batch_dimension,
            "batch_mapping": dict(self._batch_mappings.get(self._batch_dimension, {})),
            "classification_pool": self.ui.classificationPoolComboBox.currentData() if self._batch_mode != "none" else "selected_scope",
            "include_xy": self.ui.includeXYCheckBox.isChecked(),
            "feature_names": self._checked_values(self.ui.featuresListWidget),
            "confidence_level": .95,
        }

    def restore_settings(self, settings):
        if not isinstance(settings, dict):
            return
        for name, combo in (("source", self.ui.sourceComboBox), ("analysis_scope", self.ui.scopeComboBox),
                            ("fail_method", self.ui.failMethodComboBox)):
            if name in settings:
                self._select_code(combo, settings[name])
        for name, edit in (("nodes", self.ui.nodesEdit), ("sample_ids", self.ui.samplesEdit),
                           ("group_by_dimensions", self.ui.groupDimensionsEdit)):
            if isinstance(settings.get(name), list):
                edit.setText(", ".join(str(value) for value in settings[name]))
        if "include_xy" in settings:
            self.ui.includeXYCheckBox.setChecked(bool(settings["include_xy"]))
        for name, widget in (("dataset_ids", self.ui.importsListWidget), ("feature_names", self.ui.featuresListWidget)):
            if not isinstance(settings.get(name), list):
                continue
            selected = set(str(value) for value in settings[name])
            widget.blockSignals(True)
            for index in range(widget.count()):
                item = widget.item(index)
                item.setCheckState(Qt.Checked if str(item.data(Qt.UserRole)) in selected else Qt.Unchecked)
            widget.blockSignals(False)
            if name == "dataset_ids":
                self._pending_dataset_ids = selected
            else:
                self._pending_feature_names = list(selected)
        if "batch_dimension" in settings:
            # A removed field must be chosen again, never silently mapped to another dimension.
            self.ui.batchDimensionComboBox.setCurrentIndex(self.ui.batchDimensionComboBox.findData(settings["batch_dimension"]))
        if "batch_mode" in settings:
            self._select_code(self.ui.batchModeComboBox, settings["batch_mode"])
        if "classification_pool" in settings:
            self._select_code(self.ui.classificationPoolComboBox, settings["classification_pool"])
        if isinstance(settings.get("batch_mapping"), dict) and self._batch_dimension:
            mapping = {str(source): "" if parent is None else str(parent) for source, parent in settings["batch_mapping"].items()}
            self._batch_mappings[self._batch_dimension] = mapping
            self._batch_values[self._batch_dimension] = list(mapping)
            self._render_batch_values()
        self._update_state()


class _ResultTableModel(QAbstractTableModel):
    """Numeric sorting and lazy cells for compact results and larger topologies."""

    def __init__(self, columns, headers, parent=None):
        super().__init__(parent)
        self.columns = list(columns)
        self.headers = list(headers)
        self.rows = []
        self._sort_column = -1
        self._sort_order = Qt.AscendingOrder

    def set_rows(self, rows, *, columns=None, headers=None):
        self.beginResetModel()
        self.rows = list(rows)
        if columns is not None:
            self.columns = list(columns)
        if headers is not None:
            self.headers = list(headers)
        if 0 <= self._sort_column < len(self.columns):
            self._sort()
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.columns)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole:
            return self.headers[section] if orientation == Qt.Horizontal else str(section + 1)
        return None

    def _raw(self, row, key):
        if key == "n_passed":
            return max(0, int(row.get("n_tested", 0)) - int(row.get("n_failed", 0)))
        if key in {"probability", "ci_lower", "ci_upper"} and row.get("identifiable") is False:
            return None
        if key.startswith("features."):
            return row.get("features", {}).get(key.removeprefix("features."))
        return row.get(key)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        key, kind = self.columns[index.column()]
        value = self._raw(self.rows[index.row()], key)
        if role == Qt.TextAlignmentRole and kind in {"percent", "pp", "number", "integer"}:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        if role not in {Qt.DisplayRole, Qt.ToolTipRole}:
            return None
        if value is None or isinstance(value, float) and not math.isfinite(value):
            return "—"
        if kind == "bool":
            return "是" if value else "否"
        if kind == "percent":
            return f"{float(value):.4%}"
        if kind == "pp":
            return f"{float(value) * 100:+.4f}"
        if kind == "number" and _finite(value):
            return f"{value:.6g}"
        if kind == "path" and isinstance(value, (list, tuple)):
            return " / ".join(str(part) for part in value)
        return str(value)

    def _sort(self):
        key = self.columns[self._sort_column][0]
        def sort_key(row):
            value = self._raw(row, key)
            if value is None:
                return (2, "")
            return (0, float(value)) if _finite(value) else (1, str(value).casefold())
        self.rows.sort(key=sort_key, reverse=self._sort_order == Qt.DescendingOrder)

    def sort(self, column, order=Qt.AscendingOrder):
        if not 0 <= column < len(self.columns):
            return
        self.beginResetModel()
        self._sort_column, self._sort_order = column, order
        self._sort()
        self.endResetModel()


class TskResultsPanel(QWidget):
    export_requested = Signal()
    TYPE_COLUMNS = [("tsk_id", "text"), ("probability", "percent"), ("ci_lower", "percent"),
                    ("ci_upper", "percent"), ("identifiable", "bool"), ("status", "text"),
                    ("instance_count", "integer"), ("interval_method", "text")]
    CHAIN_COLUMNS = [("chain_id", "text"), ("n_tested", "integer"), ("n_failed", "integer"),
                     ("n_passed", "integer"), ("n_missing", "integer"), ("observed_probability", "percent"),
                     ("predicted_probability", "percent"), ("residual", "pp"), ("deviance_residual", "number")]
    TOPOLOGY_COLUMNS = [("chain_id", "text"), ("tsk_instance_id", "text"), ("tsk_id", "text"),
                        ("x", "number"), ("y", "number"), ("chain_key", "path")]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskResultsPanelForm()
        self.ui.setupUi(self)
        self.result = {}
        self.types_model = self._table_model(self.ui.typesTableView, self.TYPE_COLUMNS)
        self.chains_model = self._table_model(self.ui.chainsTableView, self.CHAIN_COLUMNS)
        self.topology_model = self._table_model(self.ui.topologyTableView, self.TOPOLOGY_COLUMNS)
        self.ui.groupComboBox.currentIndexChanged.connect(self._show_group)
        self.ui.exportButton.clicked.connect(self.export_requested)

    @staticmethod
    def _table_model(table, columns):
        model = _ResultTableModel(columns, table.property("columnHeaders") or [], table)
        table.setModel(model)
        table.horizontalHeader().setResizeContentsPrecision(100)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        table.horizontalHeader().setStretchLastSection(True)
        return model

    @property
    def current_group(self):
        index = self.ui.groupComboBox.currentIndex()
        groups = self.result.get("groups", [])
        return groups[index] if 0 <= index < len(groups) else None

    def set_result(self, payload):
        self.result = _mapping(payload)
        self.ui.groupComboBox.blockSignals(True)
        self.ui.groupComboBox.clear()
        for index, group in enumerate(self.result.get("groups", [])):
            self.ui.groupComboBox.addItem(str(group.get("label") or group.get("node") or f"Group {index + 1}"), index)
        self.ui.groupComboBox.blockSignals(False)
        groups = self.result.get("groups", [])
        self.ui.groupComboBox.setEnabled(bool(groups))
        self.ui.exportButton.setEnabled(bool(groups))
        topology = [_mapping(row) for row in self.result.get("topology", [])]
        features = sorted({name for row in topology for name in row.get("features", {})}, key=str.casefold)
        columns = self.TOPOLOGY_COLUMNS + [("features." + name, "number") for name in features]
        headers = list(self.ui.topologyTableView.property("columnHeaders") or []) + features
        self.topology_model.set_rows(topology, columns=columns, headers=headers)
        self._show_group()

    def clear_result(self, message: str = ""):
        self.set_result({})
        self.ui.summaryLabel.setText(message or self.ui.summaryLabel.property("emptyText"))

    def _show_group(self, *_args):
        group = self.current_group or {}
        types = list(group.get("types", []))
        chains = list(group.get("chains", []))
        self.types_model.set_rows(types)
        self.chains_model.set_rows(chains)
        self.ui.riskPlot.set_rows(types)
        self.ui.chainPlot.set_rows(chains)
        diagnostics = group.get("diagnostics", {})
        warnings = list(self.result.get("warnings", [])) + list(diagnostics.get("warnings", []))
        unique_warnings = list(dict.fromkeys(str(item) for item in warnings if item))
        self.ui.warningsLabel.setVisible(bool(unique_warnings))
        self.ui.warningsLabel.setText("\n".join(unique_warnings[:3]) + (f"\n另有 {len(unique_warnings) - 3} 条提示（悬停查看全部）" if len(unique_warnings) > 3 else ""))
        self.ui.warningsLabel.setToolTip("\n".join(unique_warnings))
        if not group:
            self.ui.summaryLabel.setText(self.ui.summaryLabel.property("emptyText"))
            self.ui.summaryLabel.setToolTip("")
            self.ui.referenceLabel.clear()
            self.ui.referenceLabel.setToolTip("")
            self.ui.riskLegendLabel.setToolTip("")
            return
        convergence = "已收敛" if diagnostics.get("converged") else "未确认收敛"
        rank = diagnostics.get("rank", "—")
        parameters = diagnostics.get("parameter_count", "—")
        summary = f"{len(types)} TSK types · {len(chains)} Chains · {convergence} · 秩 {rank}/{parameters}"
        source_batches = [str(value) for value in group.get("source_batches", [])]
        batch_mode = group.get("batch_mode", "none")
        if batch_mode != "none" and source_batches:
            members = ", ".join(source_batches[:6]) + (f" 等 {len(source_batches)} 批" if len(source_batches) > 6 else "")
            summary += (f"\n母批：{group.get('parent_batch_id', '')} · 原批：{members}" if batch_mode == "parent" else f"\n原批：{members}")
        details = [f"原批次字段：{group.get('batch_dimension', '')}", f"原批次成员：{', '.join(source_batches)}"] if source_batches else []
        details.extend(f"{row.get('source_batch', '')} / {row.get('chain_id', '')}: "
                       f"Tested={row.get('n_tested', 0)}, Fail={row.get('n_failed', 0)}, "
                       f"Pass={row.get('n_passed', 0)}, Missing={row.get('n_missing', 0)}"
                       for row in group.get("batch_counts", []))
        self.ui.summaryLabel.setText(summary)
        self.ui.summaryLabel.setToolTip("\n".join(details))
        reference = diagnostics.get("reference_environment")
        options = group.get("options", {})
        reference_text = json.dumps(reference, ensure_ascii=False) if isinstance(reference, (list, dict)) else str(reference or "")
        self.ui.referenceLabel.setToolTip(reference_text)
        model = diagnostics.get("model")
        if model == "instance_logistic_features" or (model != "type_only" and (
                options.get("include_xy") or options.get("use_xy") or options.get("feature_names"))):
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("featureText"))
        elif model == "type_only" or not reference:
            self.ui.referenceLabel.setText(self.ui.referenceLabel.property("typeOnlyText"))
        else:
            self.ui.referenceLabel.setText(f"概率参照环境：{reference_text}")
        self.ui.riskLegendLabel.setToolTip(str(diagnostics.get("interval_method", "")))
