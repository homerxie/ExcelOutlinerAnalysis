# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_results_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFrame,
    QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QScrollArea, QSizePolicy, QTabWidget, QTableView,
    QVBoxLayout, QWidget)

from excel_data_analysis.gui.tsk_plot import (TskChainFitPlot, TskRiskPlot)

class Ui_TskResultsPanelForm(object):
    def setupUi(self, TskResultsPanelForm):
        if not TskResultsPanelForm.objectName():
            TskResultsPanelForm.setObjectName(u"TskResultsPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskResultsPanelForm.sizePolicy().hasHeightForWidth())
        TskResultsPanelForm.setSizePolicy(sizePolicy)
        self.panelLayout = QVBoxLayout(TskResultsPanelForm)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.selectionLayout = QHBoxLayout()
        self.selectionLayout.setObjectName(u"selectionLayout")
        self.groupLabel = QLabel(TskResultsPanelForm)
        self.groupLabel.setObjectName(u"groupLabel")

        self.selectionLayout.addWidget(self.groupLabel)

        self.groupComboBox = QComboBox(TskResultsPanelForm)
        self.groupComboBox.setObjectName(u"groupComboBox")
        self.groupComboBox.setEnabled(False)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.groupComboBox.sizePolicy().hasHeightForWidth())
        self.groupComboBox.setSizePolicy(sizePolicy1)
        self.groupComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.groupComboBox.setMinimumContentsLength(8)

        self.selectionLayout.addWidget(self.groupComboBox)

        self.exportButton = QPushButton(TskResultsPanelForm)
        self.exportButton.setObjectName(u"exportButton")
        self.exportButton.setEnabled(False)

        self.selectionLayout.addWidget(self.exportButton)


        self.panelLayout.addLayout(self.selectionLayout)

        self.summaryLabel = QLabel(TskResultsPanelForm)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)

        self.panelLayout.addWidget(self.summaryLabel)

        self.warningsLabel = QLabel(TskResultsPanelForm)
        self.warningsLabel.setObjectName(u"warningsLabel")
        self.warningsLabel.setVisible(False)
        self.warningsLabel.setWordWrap(True)
        self.warningsLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.panelLayout.addWidget(self.warningsLabel)

        self.detailsTabWidget = QTabWidget(TskResultsPanelForm)
        self.detailsTabWidget.setObjectName(u"detailsTabWidget")
        self.riskTab = QWidget()
        self.riskTab.setObjectName(u"riskTab")
        self.riskLayout = QVBoxLayout(self.riskTab)
        self.riskLayout.setObjectName(u"riskLayout")
        self.riskLegendLabel = QLabel(self.riskTab)
        self.riskLegendLabel.setObjectName(u"riskLegendLabel")
        self.riskLegendLabel.setWordWrap(True)

        self.riskLayout.addWidget(self.riskLegendLabel)

        self.referenceLabel = QLabel(self.riskTab)
        self.referenceLabel.setObjectName(u"referenceLabel")
        self.referenceLabel.setWordWrap(True)

        self.riskLayout.addWidget(self.referenceLabel)

        self.riskScrollArea = QScrollArea(self.riskTab)
        self.riskScrollArea.setObjectName(u"riskScrollArea")
        self.riskScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.riskScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.riskScrollArea.setWidgetResizable(True)
        self.riskPlot = TskRiskPlot()
        self.riskPlot.setObjectName(u"riskPlot")
        self.riskPlot.setMinimumSize(QSize(0, 190))
        sizePolicy.setHeightForWidth(self.riskPlot.sizePolicy().hasHeightForWidth())
        self.riskPlot.setSizePolicy(sizePolicy)
        self.riskScrollArea.setWidget(self.riskPlot)

        self.riskLayout.addWidget(self.riskScrollArea)

        self.detailsTabWidget.addTab(self.riskTab, "")
        self.chainFitTab = QWidget()
        self.chainFitTab.setObjectName(u"chainFitTab")
        self.chainFitLayout = QVBoxLayout(self.chainFitTab)
        self.chainFitLayout.setObjectName(u"chainFitLayout")
        self.chainLegendLabel = QLabel(self.chainFitTab)
        self.chainLegendLabel.setObjectName(u"chainLegendLabel")
        self.chainLegendLabel.setWordWrap(True)

        self.chainFitLayout.addWidget(self.chainLegendLabel)

        self.chainPlot = TskChainFitPlot(self.chainFitTab)
        self.chainPlot.setObjectName(u"chainPlot")
        self.chainPlot.setMinimumSize(QSize(0, 210))
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.chainPlot.sizePolicy().hasHeightForWidth())
        self.chainPlot.setSizePolicy(sizePolicy2)

        self.chainFitLayout.addWidget(self.chainPlot)

        self.chainsTableView = QTableView(self.chainFitTab)
        self.chainsTableView.setObjectName(u"chainsTableView")
        self.chainsTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.chainsTableView.setAlternatingRowColors(True)
        self.chainsTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.chainsTableView.setSortingEnabled(True)

        self.chainFitLayout.addWidget(self.chainsTableView)

        self.chainFitLayout.setStretch(1, 3)
        self.chainFitLayout.setStretch(2, 2)
        self.detailsTabWidget.addTab(self.chainFitTab, "")
        self.riskDetailsTab = QWidget()
        self.riskDetailsTab.setObjectName(u"riskDetailsTab")
        self.riskDetailsLayout = QVBoxLayout(self.riskDetailsTab)
        self.riskDetailsLayout.setObjectName(u"riskDetailsLayout")
        self.typesTableView = QTableView(self.riskDetailsTab)
        self.typesTableView.setObjectName(u"typesTableView")
        self.typesTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.typesTableView.setAlternatingRowColors(True)
        self.typesTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.typesTableView.setSortingEnabled(True)

        self.riskDetailsLayout.addWidget(self.typesTableView)

        self.detailsTabWidget.addTab(self.riskDetailsTab, "")
        self.topologyTab = QWidget()
        self.topologyTab.setObjectName(u"topologyTab")
        self.topologyLayout = QVBoxLayout(self.topologyTab)
        self.topologyLayout.setObjectName(u"topologyLayout")
        self.topologyHintLabel = QLabel(self.topologyTab)
        self.topologyHintLabel.setObjectName(u"topologyHintLabel")
        self.topologyHintLabel.setWordWrap(True)

        self.topologyLayout.addWidget(self.topologyHintLabel)

        self.topologyTableView = QTableView(self.topologyTab)
        self.topologyTableView.setObjectName(u"topologyTableView")
        self.topologyTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.topologyTableView.setAlternatingRowColors(True)
        self.topologyTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.topologyTableView.setSortingEnabled(True)

        self.topologyLayout.addWidget(self.topologyTableView)

        self.detailsTabWidget.addTab(self.topologyTab, "")

        self.panelLayout.addWidget(self.detailsTabWidget)

#if QT_CONFIG(shortcut)
        self.groupLabel.setBuddy(self.groupComboBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskResultsPanelForm)

        self.detailsTabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(TskResultsPanelForm)
    # setupUi

    def retranslateUi(self, TskResultsPanelForm):
        self.groupLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8282\u70b9 / \u6761\u4ef6", None))
        self.exportButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5bfc\u51fa XLSX", None))
        self.summaryLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.summaryLabel.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.warningsLabel.setText("")
        self.riskLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6761\u5f62\uff1a\u5355\u5b9e\u4f8b P_fail \u00b7 \u8bef\u5dee\u7ebf\uff1a95% \u7f6e\u4fe1\u533a\u95f4\u3002\n"
"\u901a\u5e38\u4e3a\u8f6e\u5ed3\u4f3c\u7136\u8fd1\u4f3c\uff1b\u8fb9\u754c\u91c7\u7528\u9002\u7528\u7684\u7cbe\u786e\u65b9\u6cd5\u3002", None))
        self.referenceLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u53ef\u663e\u793a\u7684\u62df\u5408\u7ed3\u679c\u3002", None))
        self.referenceLabel.setProperty(u"typeOnlyText", QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u578b\u6a21\u578b\uff1a\u540c\u4e00 TSK_ID \u7684\u5404\u5b9e\u4f8b\u5171\u4eab\u5f02\u5e38\u6982\u7387\u3002", None))
        self.referenceLabel.setProperty(u"featureText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u56fa\u5b9a\u6240\u6709\u7279\u5f81\u5728\u8be5\u7ec4\u8bad\u7ec3\u5747\u503c\uff0c\u6bd4\u8f83 TSK \u6761\u4ef6\u6982\u7387\u3002", None))
        self.riskPlot.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"P_fail(TSK_ID)\uff08%\uff09", None))
        self.riskPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a TSK \u6982\u7387\u4e0e\u533a\u95f4\u3002", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.riskTab), QCoreApplication.translate("TskResultsPanelForm", u"\u98ce\u9669\u56fe", None))
        self.chainLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bcf\u70b9\u4ee3\u8868\u4e00\u6761 Chain\uff1b\u5bf9\u89d2\u7ebf\u8868\u793a\u89c2\u5bdf\u4e0e\u9884\u6d4b\u4e00\u81f4\u3002\u6b8b\u5dee = \u89c2\u5bdf \u2212 \u9884\u6d4b\u3002", None))
        self.chainPlot.setProperty(u"xAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u9884\u6d4b Chain \u5f02\u5e38\u7387\uff08%\uff09", None))
        self.chainPlot.setProperty(u"yAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u5f02\u5e38\u7387\uff08%\uff09", None))
        self.chainPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a Chain \u62df\u5408\u504f\u5dee\u3002", None))
        self.chainsTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"Chain ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u6837\u54c1\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Fail", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Pass", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Missing", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u9884\u6d4b\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6b8b\u5dee (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Deviance residual", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.chainFitTab), QCoreApplication.translate("TskResultsPanelForm", u"Chain \u62df\u5408", None))
        self.typesTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u5b9e\u4f8b\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"95% \u4e0b\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"95% \u4e0a\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u53ef\u5355\u72ec\u8bc6\u522b", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u65b9\u6cd5", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.riskDetailsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u98ce\u9669\u660e\u7ec6", None))
        self.topologyHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bcf\u884c\u8868\u793a\u4e00\u4e2a\u7269\u7406\u5b9e\u4f8b\uff1b\u9644\u52a0\u7279\u5f81\u5217\u6765\u81ea\u6a21\u677f\u3002Chain \u5b8c\u6574\u8def\u5f84\u7528\u4e8e\u533a\u5206\u540c\u540d\u94fe\u8def\u3002", None))
        self.topologyTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"CHAIN_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"TSK_instance_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"TSK_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"X", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Y", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Chain \u5b8c\u6574\u8def\u5f84", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.topologyTab), QCoreApplication.translate("TskResultsPanelForm", u"\u5b9e\u4f8b\u7ec4\u6210", None))
        pass
    # retranslateUi

