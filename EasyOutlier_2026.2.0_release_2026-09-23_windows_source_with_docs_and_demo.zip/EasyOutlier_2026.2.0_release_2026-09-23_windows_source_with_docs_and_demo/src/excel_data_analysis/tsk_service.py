"""Independent TSK workflow: observations, estimation and reproducible export.

The existing report criterion and merge order are reused as definitions, without
running Analyze or creating an ordinary report. Unknown measurements propagate
through the monotone any/all rules using lower/upper Boolean bounds.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Callable

from .field_names import row_fields
from .compact_analysis import ColumnarMeasurements
from .io import build_measurements, load_table
from .models import TemplateConfig
from .repository import Repository
from .reporting import (
    _build_columns, _build_rows, _build_rows_from_measurements,
    _build_zscore_map, _build_report_golden_values, _load_built_golden_reference,
    _fail_mode_requires_golden, _merge_rule_for_step, _outlier_merge_steps,
    _row_metric_key, _sample_key_display, _sample_key_from_dimensions,
    _target_prefix_lengths, _validate_report_row_identities,
)
from .merge_config import chain_level, column_levels
from .template import load_template, template_to_payload, validate_report_identity


@dataclass(slots=True)
class _State:
    row_key: tuple[str, ...]
    column_key: tuple[str, ...]
    sample_key: tuple[str, ...]
    lower: bool
    upper: bool


def _combine(values: list[tuple[bool, bool]], rule: str) -> tuple[bool, bool]:
    operation = all if rule == "all_fail" else any
    return operation(v[0] for v in values), operation(v[1] for v in values)


def _measurement_state(mode, z_entry, golden_entry, present):
    if not present:
        return False, True
    z = (bool(z_entry.is_fail),) * 2 if z_entry is not None else (False, True)
    golden = (bool(golden_entry.is_fail),) * 2 if golden_entry is not None else (False, True)
    if mode == "modified_z_score":
        return z
    if mode == "golden_deviation":
        return golden
    return _combine([z, golden], "all_fail" if mode == "zscore_and_golden" else "any_fail")


def _unscorable_z_metrics(measurements, z_values):
    counts = defaultdict(int)
    informative = set()
    for measurement in measurements:
        counts[measurement.logical_metric] += 1
        entry = z_values.get((measurement.dataset_id, measurement.row_number, measurement.raw_column))
        if entry is not None and entry.value is not None and abs(entry.value) > 0:
            informative.add(measurement.logical_metric)
    # The shared scorer returns zero for MAD=0, and None scores are displayed
    # as zero by the report. A TSK probability cannot treat undefined dispersion
    # as evidence of health: make this criterion Unknown in this workflow.
    return {metric: "样本不足 3" if count < 3 else "MAD 为 0"
            for metric, count in counts.items() if count < 3 or metric not in informative}


def _merge_states(records: list[_State], template: TemplateConfig) -> list[_State]:
    for step in _outlier_merge_steps(template):
        row_length, column_length = _target_prefix_lengths(template, step)
        grouped = defaultdict(list)
        for record in records:
            # Retain explicit sample identity even when a custom template has
            # unusual dimension ordering. Never merge different dies together.
            key = (record.sample_key, record.row_key[:row_length], record.column_key[:column_length])
            grouped[key].append((record.lower, record.upper))
        records = [
            _State(row, column, sample, *_combine(values, _merge_rule_for_step(template, step)))
            for (sample, row, column), values in grouped.items()
        ]
    return records


def _batch_settings(template, *, batch_mode="none", batch_dimension=None, batch_mapping=None,
                    classification_pool="original_batch"):
    if batch_mode not in {"none", "separate", "parent"}:
        raise ValueError(f"不支持的 TSK 批次模式：{batch_mode}")
    if batch_mode == "none":
        return {"batch_mode": "none", "batch_dimension": None, "batch_mapping": {},
                "classification_pool": "selected_scope"}
    dimension = row_fields(template).resolve(batch_dimension, strict=True)
    if dimension == template.report.reliability_node_dimension:
        raise ValueError("批次字段不能使用可靠性节点；各节点始终分别分析。")
    if classification_pool not in {"original_batch", "selected_scope"}:
        raise ValueError(f"不支持的 TSK 判据数据池：{classification_pool}")
    if batch_mapping is not None and not isinstance(batch_mapping, dict):
        raise ValueError("原批次到母批编号的对应关系必须为字典。")
    mapping = {}
    for source, parent in (batch_mapping or {}).items():
        if not isinstance(source, str) or not isinstance(parent, str):
            raise ValueError("原批次和母批编号必须是文本。")
        mapping[source] = parent.strip()
    return {"batch_mode": batch_mode, "batch_dimension": dimension, "batch_mapping": mapping,
            "classification_pool": classification_pool}


def _batch_value(dimensions, dimension):
    value = dimensions.get(dimension)
    if value is None or not str(value).strip():
        raise ValueError(f"TSK 批次字段 {dimension!r} 存在空值，请先补全批次信息。")
    return str(value)


def _pool_batch_groups(groups, batch):
    """Pool sufficient counts, never type estimates or cross-batch sample IDs."""
    output = {}
    for group in groups:
        source = group.pop("source_batch")
        parent = batch["batch_mapping"][source] if batch["batch_mode"] == "parent" else source
        key = (group["node"], tuple(group["stratum"].items()), parent)
        if key not in output:
            description = "母批" if batch["batch_mode"] == "parent" else batch["batch_dimension"]
            output[key] = {**group, "label": f"{group['label']} | {description}={parent}",
                           "batch_mode": batch["batch_mode"], "batch_dimension": batch["batch_dimension"],
                           "parent_batch_id": parent if batch["batch_mode"] == "parent" else None,
                           "source_batches": [], "batch_counts": [], "counts": {},
                           "sample_outcomes": [], "classification_warnings": []}
        target = output[key]
        target["source_batches"].append(source)
        target["classification_warnings"].extend(group["classification_warnings"])
        target["sample_outcomes"].extend({**row, "source_batch": source} for row in group["sample_outcomes"])
        target["batch_counts"].extend({"source_batch": source, **row} for row in group["counts"])
        for row in group["counts"]:
            total = target["counts"].setdefault(row["chain_id"], {"chain_id": row["chain_id"],
                "n_tested": 0, "n_failed": 0, "n_passed": 0, "n_missing": 0})
            for name in ("n_tested", "n_failed", "n_passed", "n_missing"):
                total[name] += row[name]
    for group in output.values():
        group["counts"] = list(group["counts"].values())
        group["classification_warnings"] = list(dict.fromkeys(group["classification_warnings"]))
    return [output[key] for key in sorted(output)]


def collect_tsk_observations(template, measurements, rows, *, fail_method, golden_path=None,
                             group_by_dimensions=(), batch_mode="none", batch_dimension=None,
                             batch_mapping=None, classification_pool="original_batch", progress_callback=None):
    """Return grouped counts including Missing and paired sample outcomes.

    All-empty rows can be supplied by an input workbook; a measurement-only
    database cannot reconstruct rows that were discarded at import time.
    """
    from .template import validate_tsk_analysis_config

    validate_report_identity(template)
    validate_tsk_analysis_config(template, require_instances=True)
    _validate_report_row_identities(template, rows)
    if fail_method not in {"modified_z_score", "golden_deviation", "zscore_and_golden", "zscore_or_golden"}:
        raise ValueError(f"Unsupported TSK Fail criterion: {fail_method}")
    if _fail_mode_requires_golden(fail_method) and not golden_path:
        raise ValueError("TSK 分析选择了 Golden 判据，请在 Setup 中选择 Golden 文件。")
    columns = _build_columns(template, {}, [])
    prefix_length = column_levels(template).index(chain_level(template)) + 1
    chain_keys = {tuple(item.chain_key): item.chain_id for item in template.tsk_analysis.instances}
    selected_columns = [c for c in columns if tuple(c.header_values[:prefix_length]) in chain_keys]
    if not selected_columns:
        raise ValueError("TSK 实例表未匹配到测量列。请检查完整 Chain 键。")
    fields = row_fields(template)
    group_names = list(dict.fromkeys(fields.resolve(name, strict=True) for name in group_by_dimensions))
    node_name = template.report.reliability_node_dimension
    group_names = [name for name in group_names if name != node_name]
    batch = _batch_settings(template, batch_mode=batch_mode, batch_dimension=batch_dimension,
                            batch_mapping=batch_mapping, classification_pool=classification_pool)
    batched = batch["batch_mode"] != "none"
    dimension = batch["batch_dimension"]
    source_batches = sorted({_batch_value(row.dimensions, dimension) for row in rows}) if batched else []
    if batch["batch_mode"] == "parent":
        unmapped = [source for source in source_batches if not batch["batch_mapping"].get(source)]
        if unmapped:
            raise ValueError("请为所有所选原批次填写母批编号：" + ", ".join(unmapped))
    if batched:
        group_names = [name for name in group_names if name != dimension]
    row_names = [d.name for d in sorted(template.row_dimensions, key=lambda d: d.priority)]
    if progress_callback:
        progress_callback(18, "TSK：计算独立分析范围的测量判据…")
    selected_metrics = {c.logical_metric for c in selected_columns}
    pools = defaultdict(list)
    per_batch_pool = batched and batch["classification_pool"] == "original_batch"
    if per_batch_pool:
        for measurement in measurements:
            pools[_batch_value(measurement.dimensions, dimension)].append(measurement)
    else:
        pools[""] = measurements
    classifications = {}
    for pool_id, pool in pools.items():
        z_values = _build_zscore_map(pool, template.report.zscore_thresholds, columns) if fail_method != "golden_deviation" else {}
        unscorable = _unscorable_z_metrics(pool, z_values) if fail_method != "golden_deviation" else {}
        affected = len(set(unscorable) & selected_metrics)
        prefix = f"原批次 {pool_id}：" if per_batch_pool else ""
        messages = [f"{prefix}Modified Z Score 有 {affected} 个测项的数据池样本不足 3 或 MAD 为 0，相关 Z 判据按 Missing/未知处理。可改用有效 Golden 判据。"] if affected else []
        classifications[pool_id] = (z_values, unscorable, messages)
    golden = _load_built_golden_reference(golden_path) if _fail_mode_requires_golden(fail_method) else None
    golden_values = _build_report_golden_values(measurements, template, columns, golden_reference=golden) if golden else {}
    grouped = defaultdict(list)
    for row in rows:
        source_batch = _batch_value(row.dimensions, dimension) if batched else ""
        z_values, unscorable, _ = classifications.get(source_batch if per_batch_pool else "", ({}, {}, []))
        stratum = tuple(str(row.dimensions.get(name, "")) for name in group_names)
        if any(not value for value in stratum):
            raise ValueError("TSK 分组字段存在空值，请修正数据或调整分组字段。")
        group_key = (row.dimensions[node_name], stratum, source_batch)
        sample = _sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names)
        row_key = tuple(str(row.dimensions.get(name, "")) for name in row_names)
        for column in selected_columns:
            key = _row_metric_key(row, column.raw_column)
            present = column.raw_column in row.values and math.isfinite(row.values[column.raw_column])
            z_entry = None if column.logical_metric in unscorable else z_values.get(key)
            lower, upper = _measurement_state(fail_method, z_entry, golden_values.get(key), present)
            grouped[group_key].append(_State(row_key, tuple(column.header_values), sample, lower, upper))
    output = []
    for (node, stratum, source_batch), records in sorted(grouped.items()):
        final = _merge_states(records, template)
        outcomes = defaultdict(list)
        for record in final:
            outcomes[(record.sample_key, chain_keys[record.column_key])].append((record.lower, record.upper))
        counts = {chain: {"chain_id": chain, "n_tested": 0, "n_failed": 0, "n_passed": 0, "n_missing": 0} for chain in chain_keys.values()}
        paired = []
        for (sample, chain), states in sorted(outcomes.items()):
            if len(states) != 1:
                raise ValueError("一个样品/节点/Chain 合并后仍有多个状态，请检查模板行层级和分组。")
            lower, upper = states[0]
            status = "Missing" if lower != upper else "Fail" if lower else "Pass"
            count = counts[chain]
            count[{"Missing": "n_missing", "Fail": "n_failed", "Pass": "n_passed"}[status]] += 1
            count["n_tested"] += int(status != "Missing")
            paired.append({"sample_key": list(sample), "chain_id": chain, "status": status})
        stratum_dict = dict(zip(group_names, stratum))
        label = " | ".join([f"{node_name}={node}", *(f"{name}={value}" for name, value in stratum_dict.items())])
        classification_warnings = classifications.get(source_batch if per_batch_pool else "", ({}, {}, []))[2]
        output.append({"label": label, "node": node, "stratum": stratum_dict, "counts": list(counts.values()),
                       "sample_outcomes": paired, "classification_warnings": classification_warnings,
                       **({"source_batch": source_batch} if batched else {})})
    return _pool_batch_groups(output, batch) if batched else output


def _load_tsk_selection(template, *, source, storage_path, input_path, options):
    """Use identical import/node/sample scopes for discovery and estimation."""
    warnings = []
    dataset_ids = set(options.get("dataset_ids", []))
    if source == "input":
        if not input_path:
            raise ValueError("请在 Setup 中选择 Input Excel/CSV。")
        table = load_table(input_path, template=template)
        rows = _build_rows(template, table.rows, input_path)
        measurements = ColumnarMeasurements(build_measurements(template, table.rows, "ad-hoc-report", str(Path(input_path).resolve())))
        del table
    elif source == "database":
        if not storage_path:
            raise ValueError("请先打开数据库。")
        if options.get("analysis_scope") == "checked_imports" and not dataset_ids:
            raise ValueError("请在 TSK Analysis 页勾选至少一个导入记录。")
        measurements = ColumnarMeasurements(m for m in Repository(storage_path).iter_measurements()
                        if options.get("analysis_scope") != "checked_imports" or m.dataset_id in dataset_ids)
        rows = _build_rows_from_measurements(measurements)
        warnings.append("数据库只保留可解析的数值测量；导入时整行没有数值的样品无法恢复。Missing 计数仅覆盖已知样品/节点，完整曝光数请使用原始输入文件核对。")
    else:
        raise ValueError(f"Unsupported TSK source: {source}")
    nodes, sample_ids = set(options.get("nodes", [])), set(options.get("sample_ids", []))
    def included(row):
        sample = _sample_key_from_dimensions(row.dimensions, template.report.sample_dimension_names)
        return ((not nodes or row.dimensions.get(template.report.reliability_node_dimension) in nodes)
                and (not sample_ids or _sample_key_display(sample) in sample_ids or (sample and sample[-1] in sample_ids)))
    rows = [row for row in rows if included(row)]
    selected_rows = {(row.dataset_id, row.row_number) for row in rows}
    measurements = ColumnarMeasurements(m for m in measurements if (m.dataset_id, m.row_number) in selected_rows and math.isfinite(m.value))
    if not rows:
        raise ValueError("所选 TSK 分析范围没有样品数据。")
    return measurements, rows, warnings


def discover_tsk_batches(*, template_path: str, source: str = "database", storage_path: str | None = None,
                         input_path: str | None = None, settings: dict | None = None,
                         progress_callback: Callable | None = None) -> list[str]:
    """Read the current TSK scope, without fitting or modifying the database."""
    options = dict(settings or {})
    template = load_template(template_path)
    batch = _batch_settings(template, batch_mode="separate", batch_dimension=options.get("batch_dimension"))
    progress = progress_callback or (lambda value, message: None)
    progress(5, "TSK：读取所选范围的原批次…")
    _, rows, _ = _load_tsk_selection(template, source=source, storage_path=storage_path,
                                     input_path=input_path, options=options)
    values = sorted({_batch_value(row.dimensions, batch["batch_dimension"]) for row in rows})
    progress(100, f"TSK：发现 {len(values)} 个原批次。")
    return values


def analyze_tsk_workspace(*, template_path: str, source: str = "database", storage_path: str | None = None,
                          input_path: str | None = None, golden_path: str | None = None,
                          settings: dict | None = None, progress_callback: Callable | None = None) -> dict:
    """Execute a complete independent run; no ordinary reports or workspace writes."""
    from .tsk_analysis import TskInstance, TskChainObservation, TskAnalysisOptions, analyze_tsk
    from .template import validate_tsk_analysis_config

    options = dict(settings or {})
    template = load_template(template_path)
    if not template.tsk_analysis.enabled:
        raise ValueError("请先在模板 tsk_analysis 设置中启用 TSK 分析并填写真实实例对应表；可先使用 examples/tsk_risk_demo 示例。")
    validate_tsk_analysis_config(template, require_instances=True)
    progress = progress_callback or (lambda value, message: None)
    progress(3, "TSK：读取模板与测量数据…")
    measurements, rows, warnings = _load_tsk_selection(template, source=source, storage_path=storage_path,
                                                      input_path=input_path, options=options)
    batch = _batch_settings(template, **{name: options[name] for name in
                            ("batch_mode", "batch_dimension", "batch_mapping", "classification_pool") if name in options})
    fail_method = options.get("fail_method") or template.report.outlier_fail_method
    group_by = options.get("group_by_dimensions", template.tsk_analysis.group_by_dimensions)
    effective_group_by = list(dict.fromkeys(row_fields(template).resolve(name, strict=True) for name in group_by))
    effective_group_by = [name for name in effective_group_by
                          if name != template.report.reliability_node_dimension
                          and (batch["batch_mode"] == "none" or name != batch["batch_dimension"])]
    observations = collect_tsk_observations(template, measurements, rows, fail_method=fail_method,
                                          golden_path=golden_path, group_by_dimensions=group_by,
                                          progress_callback=progress, **batch)
    include_xy = bool(options.get("include_xy", template.tsk_analysis.use_xy))
    features = tuple(options.get("feature_names", template.tsk_analysis.feature_columns))
    instances = [TskInstance(chain_id=i.chain_id, instance_id=i.tsk_instance_id, tsk_id=i.tsk_id,
                             x=i.x, y=i.y, features=dict(i.features)) for i in template.tsk_analysis.instances]
    fit_options = TskAnalysisOptions(use_xy=include_xy, feature_names=features,
                                    confidence_level=float(options.get("confidence_level", .95)))
    results = []
    for index, observation in enumerate(observations):
        progress(30 + int(65 * index / max(1, len(observations))), f"TSK：拟合 {observation['label']}…")
        counts = observation.pop("counts")
        warnings.extend(observation.pop("classification_warnings", []))
        effective = [TskChainObservation(c["chain_id"], c["n_tested"], c["n_failed"]) for c in counts if c["n_tested"]]
        if effective:
            result = analyze_tsk(instances, effective, fit_options,
                progress_callback=lambda value, message: progress(
                    30 + int(65 * (index + value / 100) / max(1, len(observations))), message)).to_dict()
        else:
            type_names = sorted({item.tsk_id for item in instances})
            result = {"types": [{"tsk_id": name, "probability": None, "ci_lower": None, "ci_upper": None,
                                  "identifiable": False, "status": "no_data", "interval_method": None,
                                  "instance_count": sum(item.tsk_id == name for item in instances), "test_exposure": 0}
                                 for name in type_names],
                      "chains": [], "options": asdict(fit_options),
                      "diagnostics": {"converged": False, "rank": 0, "parameter_count": len(type_names),
                                      "chain_count": 0, "confidence_level": fit_options.confidence_level,
                                      "interval_method": None, "reference_environment": None,
                                      "model": "instance_logistic_features" if include_xy or features else "type_only",
                                      "warnings": ["本组所有 Chain 状态均为 Missing，未拟合。"]}}
        fitted = {c["chain_id"]: c for c in result["chains"]}
        result["chains"] = [{**c, **fitted.get(c["chain_id"], {
            "status": "no_data", "observed_probability": None, "predicted_probability": None,
            "residual": None, "deviance_residual": None,
        })} for c in counts]
        results.append({**observation, **result})
    import numpy, scipy
    provenance = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(), "source": source,
        "template_path": str(Path(template_path).resolve()),
        "template_sha256": hashlib.sha256(Path(template_path).read_bytes()).hexdigest(),
        "input_path": input_path, "storage_path": storage_path, "golden_path": golden_path,
        "fail_method": fail_method, "settings": {**options, **batch, "include_xy": include_xy, "feature_names": list(features), "group_by_dimensions": list(group_by)},
        "effective_group_by_dimensions": effective_group_by,
        "merge_order": template.report.outlier_merge_order,
        "missing_policy": "三态合并：any_fail 有已知Fail即Fail，all_fail有已知Pass即Pass；其余不确定状态为Missing，不计入有效分母。",
        "classification_pool": ("在各原批次内，按所选节点、样品和导入范围的全部测量计算；Modified Z Score 沿用模板逻辑测项分池。"
                                if batch["classification_pool"] == "original_batch" else
                                "所选节点、样品和导入范围的全部测量；Modified Z Score 沿用模板逻辑测项分池。"),
        "numpy_version": numpy.__version__, "scipy_version": scipy.__version__,
        "template_snapshot": template_to_payload(template),
    }
    if batch["batch_mode"] == "parent":
        warnings.append("母批将成员原批的有效 Fail/Pass 计数合并后重新拟合，假设同一母批、节点和条件下共享 TSK 风险；合并本身不会消除批间风险差异。")
    warnings.append("区间按模型中的独立观测假设计算；同一 die 多链共同异常可能使区间偏窄。结果是基于串联假设的风险估计。")
    progress(100, "TSK 独立分析完成。")
    return {"groups": results, "topology": [asdict(i) for i in template.tsk_analysis.instances],
            "warnings": list(dict.fromkeys(warnings)), "provenance": provenance}


def export_tsk_result(payload: dict, output_path: str) -> str:
    """Export fitted results, missing counts, paired observations and provenance."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    import os
    import tempfile

    target = Path(output_path)
    if target.suffix.lower() != ".xlsx":
        target = target.with_suffix(".xlsx")
    target.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    workbook.remove(workbook.active)
    def sheet(name, records, columns=None):
        ws = workbook.create_sheet(name)
        columns = columns or list(dict.fromkeys(key for row in records for key in row))
        ws.append(columns or ["No data"])
        for row_index, record in enumerate(records, 2):
            for column_index, key in enumerate(columns, 1):
                value = record.get(key)
                if isinstance(value, (dict, list, tuple)):
                    value = json.dumps(value, ensure_ascii=False, allow_nan=False)
                if isinstance(value, float) and not math.isfinite(value):
                    value = None
                cell = ws.cell(row_index, column_index, value)
                if isinstance(value, str):
                    cell.data_type = "s"
                if key in {"probability", "ci_lower", "ci_upper", "observed_probability", "predicted_probability", "residual"}:
                    cell.number_format = "0.00%"
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="355C7D")
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for column in ws.columns:
            ws.column_dimensions[column[0].column_letter].width = min(65, max(15, max(len(str(c.value or "")) for c in column) + 2))
    type_rows, chain_rows, diagnostic_rows, sample_rows, batch_rows = [], [], [], [], []
    for group in payload.get("groups", []):
        prefix = {"group": group["label"], "node": group["node"], "stratum": group.get("stratum", {})}
        if group.get("batch_mode") in {"separate", "parent"}:
            prefix.update({key: group.get(key) for key in
                           ("batch_mode", "batch_dimension", "parent_batch_id", "source_batches")})
        type_rows.extend({**prefix, **row} for row in group.get("types", []))
        chain_rows.extend({**prefix, **row} for row in group.get("chains", []))
        diagnostic_rows.extend({**prefix, "item": key, "value": value} for key, value in group.get("diagnostics", {}).items())
        sample_rows.extend({**prefix, **row} for row in group.get("sample_outcomes", []))
        batch_rows.extend({**prefix, **row} for row in group.get("batch_counts", []))
    sheet("TSK Risk", type_rows)
    sheet("Chain Fit", chain_rows)
    sheet("Diagnostics", diagnostic_rows)
    sheet("Topology", payload.get("topology", []))
    sheet("Sample Outcomes", sample_rows)
    if batch_rows:
        sheet("Batch Counts", batch_rows)
    metadata = []
    for key, value in payload.get("provenance", {}).items():
        if isinstance(value, (dict, list, tuple)):
            value = json.dumps(value, ensure_ascii=False, allow_nan=False)
        if isinstance(value, str) and len(value) > 30000:
            # Excel truncates strings after 32767 characters. Ordered chunks
            # preserve large topology/template snapshots exactly for replay.
            pieces = [value[start:start + 30000] for start in range(0, len(value), 30000)]
            metadata.extend({"item": key, "part": i + 1, "parts": len(pieces), "value": piece}
                            for i, piece in enumerate(pieces))
        else:
            metadata.append({"item": key, "part": 1, "parts": 1, "value": value})
    sheet("Run Settings", metadata + [{"item": "warning", "part": 1, "parts": 1, "value": w} for w in payload.get("warnings", [])],
          ["item", "part", "parts", "value"])
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".xlsx", delete=False) as handle:
            temporary = Path(handle.name)
        workbook.save(temporary)
        os.replace(temporary, target)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)
        workbook.close()
    return str(target.resolve())
