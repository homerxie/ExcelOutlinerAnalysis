from __future__ import annotations

import json
import re
from math import isfinite
from pathlib import Path
from typing import Any

from .golden_rules import validate_golden_rule_config
from .field_names import (
    FieldNames, FieldLookup, field_key, column_filter_fields,
    configuration_fields, normalize_template_references,
)
from .models import (
    AnalysisColumnFilterConfig,
    AnalysisDimensionFilterConfig,
    AnalysisColumn,
    AnalysisGroup,
    ColumnHeaderLevel,
    GoldenReferenceDefaults,
    NumericCleanupConfig,
    OutlierRatioStatConfig,
    ReportConfig,
    RowDimension,
    RowDimensionSource,
    TemplateConfig,
    TSKAnalysisConfig,
    TSKInstance,
    ThresholdConfig,
)
from .output_paths import resolve_output_path
from .template_guidance import SHEET_COLUMN_GUIDANCE, column_guidance
from .merge_config import (
    TEMPLATE_SCHEMA_VERSION, MERGE_RULE_FIELDS, normalize_merge_order,
    row_levels, column_levels, chain_level, initial_row_level, initial_column_level,
    retained_level, validate_merge_levels,
)

TEMPLATE_WORKBOOK_SHEETS = {
    "info": "template_info",
    "row_dimensions": "row_dimensions",
    "column_header_levels": "column_header_levels",
    "analysis_groups": "analysis_groups",
    "node_orders": "node_orders",
    "analysis_dimension_filters": "analysis_dimension_filters",
    "analysis_column_filters": "analysis_column_filters",
    "outlier_ratio_stats": "outlier_ratio_stats",
    "tsk_analysis": "tsk_analysis",
    "tsk_instances": "tsk_instances",
    "readme": "README",
}

OUTLIER_MERGE_ORDER_OPTIONS = [
    "column merge -> column group -> row merge -> row node",
    "row merge -> row node -> column merge -> column group",
    "column merge -> row merge -> column group -> row node",
    "row merge -> column merge -> row node -> column group",
    "column merge -> row merge -> row node -> column group",
    "row merge -> column merge -> column group -> row node",
]

OUTLIER_MERGE_ORDER_OPTIONS = [normalize_merge_order(value) for value in OUTLIER_MERGE_ORDER_OPTIONS]

ANALYSIS_GROUP_CONFLICT_MODE_ERROR = "error"
ANALYSIS_GROUP_CONFLICT_MODE_FIRST_NON_EMPTY = "first_non_empty"
ANALYSIS_GROUP_CONFLICT_MODES = {
    ANALYSIS_GROUP_CONFLICT_MODE_ERROR,
    ANALYSIS_GROUP_CONFLICT_MODE_FIRST_NON_EMPTY,
}

ANALYSIS_GROUP_SHARED_FIELD_SPECS = (
    ("display_name", ("display_name",), "Display Name", "text"),
    ("analysis_mode", ("analysis_mode",), "Analysis Mode", "text"),
    ("unit", ("unit",), "Unit", "text"),
    ("outlier_golden_method", ("outlier_golden_method",), "Outlier Golden Method", "text"),
    ("golden_relative_limit", ("golden_relative_limit",), "Golden Relative Limit", "float"),
    ("golden_sigma_multiplier", ("golden_sigma_multiplier",), "Golden Sigma Multiplier", "float"),
    (
        "golden_absolute_lower_bound",
        ("golden_absolute_lower_bound", "golden_lower_bound"),
        "Golden Lower Bound",
        "float",
    ),
    (
        "golden_absolute_upper_bound",
        ("golden_absolute_upper_bound", "golden_upper_bound"),
        "Golden Upper Bound",
        "float",
    ),
    (
        "golden_overwrite_lowerbound",
        (
            "golden_overwrite_lowerbound",
            "golden_overwrite_lower_bound",
            "golden_overwrite_min",
            "overwrite_lowerbound",
            "overwrite_lower_bound",
            "overwrite_min",
        ),
        "Golden Overwrite Lower Bound",
        "float",
    ),
    (
        "golden_overwrite_upperbound",
        (
            "golden_overwrite_upperbound",
            "golden_overwrite_upper_bound",
            "golden_overwrite_max",
            "overwrite_upperbound",
            "overwrite_upper_bound",
            "overwrite_max",
        ),
        "Golden Overwrite Upper Bound",
        "float",
    ),
    (
        "golden_continuous_interval",
        ("golden_continuous_interval", "continuous_interval"),
        "Golden Continuous Interval",
        "bool",
    ),
    (
        "golden_empty_range_fallback_to_absolute",
        (
            "golden_empty_range_fallback_to_absolute",
            "empty_range_fallback_to_absolute",
        ),
        "Golden Empty Range Fallback To Absolute",
        "bool",
    ),
)


def load_template(
    path: str | Path,
    *,
    analysis_group_conflict_mode: str = ANALYSIS_GROUP_CONFLICT_MODE_FIRST_NON_EMPTY,
) -> TemplateConfig:
    template_path = Path(path)
    suffix = template_path.suffix.lower()
    normalized_conflict_mode = _normalize_analysis_group_conflict_mode(
        analysis_group_conflict_mode
    )
    if suffix == ".json":
        payload = json.loads(template_path.read_text(encoding="utf-8"))
        return _parse_template(payload)
    if suffix in {".xlsx", ".xlsm"}:
        payload = _load_template_workbook_payload(
            template_path,
            analysis_group_conflict_mode=normalized_conflict_mode,
        )
        return _parse_template(payload)
    raise ValueError(f"Unsupported template format: {template_path.suffix}")


def save_template(
    template: TemplateConfig,
    path: str | Path,
    if_exists: str = "overwrite",
) -> Path:
    template_path = resolve_output_path(path, if_exists=if_exists)
    payload = template_to_payload(template)
    suffix = template_path.suffix.lower()
    if suffix == ".json":
        template_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return template_path
    if suffix == ".xlsx":
        _save_template_workbook(payload, template_path)
        return template_path
    raise ValueError(f"Unsupported template output format: {template_path.suffix}")


def validate_template_file(
    path: str | Path,
    *,
    analysis_group_conflict_mode: str = ANALYSIS_GROUP_CONFLICT_MODE_ERROR,
) -> TemplateConfig:
    template = load_template(
        path,
        analysis_group_conflict_mode=analysis_group_conflict_mode,
    )
    validate_report_identity(template)
    return template


def validate_report_identity(template: TemplateConfig, *, validate_merge: bool = True) -> None:
    """Reject ambiguous report keys without changing the user's sample identity."""
    normalize_template_references(template)
    names = [item.name for item in sorted(template.row_dimensions, key=lambda item: item.priority)]
    node = template.report.reliability_node_dimension
    sample = template.report.sample_dimension_names
    if node not in names:
        raise ValueError(
            f"reliability_node_dimension={node!r} must name an existing row dimension. "
            "Select the reliability node dimension in template_info or the GUI."
        )
    required = names[:names.index(node)]
    if not sample or len(sample) != len(set(sample)) or set(sample) != set(required):
        raise ValueError(
            f"Ambiguous sample unique ID: sample_dimension_names={';'.join(sample) or '(empty)'}. "
            f"With reliability_node_dimension={node}, node grouping retains "
            f"{';'.join(required) or '(no sample dimensions)'}. "
            "The unique ID must contain exactly these dimensions (in your chosen order), "
            "excluding the node and lower site/repeat dimensions. "
            "Check sample_dimension_names and row_dimensions.priority in template_info/GUI. "
            "No dimensions will be added automatically."
        )
    if not validate_merge:
        return
    if template.schema_version >= 2 or template.report.initial_row_merge_level:
        validate_merge_levels(template)
    else:
        merge_dimension = template.report.outlier_row_merge_max_dimension
        if merge_dimension not in names or names.index(merge_dimension) <= names.index(node):
            raise ValueError("outlier_row_merge_max_dimension must name a row dimension below the selected node.")


def collect_analysis_group_conflicts(path: str | Path) -> list[dict[str, Any]]:
    template_path = Path(path)
    suffix = template_path.suffix.lower()
    if suffix in {".json"}:
        return []
    if suffix not in {".xlsx", ".xlsm"}:
        raise ValueError(f"Unsupported template format: {template_path.suffix}")
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError(
            "Reading template xlsx requires openpyxl. Run `pip3 install -e .` first."
        ) from exc
    workbook = load_workbook(template_path, data_only=True)
    column_header_levels = _load_column_header_levels_sheet(workbook)
    rows = _load_rows_from_sheet(
        workbook,
        TEMPLATE_WORKBOOK_SHEETS["analysis_groups"],
        required_headers={"id"},
    )
    if not rows or "column_name" not in rows[0]:
        return []
    return _detect_analysis_group_shared_field_conflicts(
        rows,
        [item["name"] for item in column_header_levels],
    )


def summarize_template(template: TemplateConfig) -> dict[str, Any]:
    return {
        "name": template.name,
        "row_dimension_count": len(template.row_dimensions),
        "analysis_group_count": len(template.analysis_groups),
        "golden_reference_default_filter_count": len(
            template.golden_reference_defaults.filters
        ),
        "zscore_threshold_override_count": len(
            template.report.zscore_thresholds.overrides
        ),
        "outlier_ratio_stat_count": len(template.report.outlier_ratio_stats),
        "analysis_column_filter_field_count": len(
            template.report.analysis_column_filters.include
        )
        + len(template.report.analysis_column_filters.exclude),
        "node_order_count": len(_effective_node_orders(template.report)[0])
        if _effective_node_orders(template.report)
        else 0,
        "node_sequence_count": len(_effective_node_orders(template.report)),
        "sample_dimension_names": list(template.report.sample_dimension_names),
        "reliability_node_dimension": template.report.reliability_node_dimension,
        "test_data_header_row": template.test_data_header_row,
        "row_header_row": template.row_header_row,
        "test_data_start_column": template.test_data_start_column,
        "unit_row": template.unit_row,
        "test_data_start_row": template.test_data_start_row,
        "column_header_level_count": len(template.column_header_levels),
        "numeric_cleanup_enabled": template.numeric_cleanup.enabled,
        "numeric_cleanup_mode": template.numeric_cleanup.mode,
        "numeric_cleanup_character_count": len(template.numeric_cleanup.characters),
    }


def template_to_payload(template: TemplateConfig) -> dict[str, Any]:
    normalize_template_references(template)
    validate_tsk_analysis_config(template)
    report_payload: dict[str, Any] = {
        "zscore_thresholds": _threshold_config_to_payload(
            template.report.zscore_thresholds
        ),
        "sample_dimension_names": list(template.report.sample_dimension_names),
        "reliability_node_dimension": template.report.reliability_node_dimension,
        "outlier_fail_method": template.report.outlier_fail_method,
        "initial_column_merge_fail_rule": template.report.outlier_merged_test_fail_rule,
        "final_column_merge_fail_rule": template.report.outlier_test_group_fail_rule,
        "initial_row_merge_fail_rule": template.report.outlier_merged_sample_fail_rule,
        "final_row_merge_fail_rule": template.report.outlier_node_fail_rule,
        "initial_row_merge_level": initial_row_level(template),
        "initial_column_merge_level": initial_column_level(template),
        "chain_column_level": chain_level(template),
        "outlier_merge_order": normalize_merge_order(template.report.outlier_merge_order),
        "outlier_treat_empty_cells_as_fail": template.report.outlier_treat_empty_cells_as_fail,
        "analysis_dimension_filters": _analysis_dimension_filters_to_payload(
            template.report.analysis_dimension_filters
        ),
        "analysis_column_filters": _analysis_column_filters_to_payload(
            template.report.analysis_column_filters
        ),
        "outlier_ratio_stats": [
            _outlier_ratio_stat_to_payload(item)
            for item in template.report.outlier_ratio_stats
        ],
    }
    node_orders = _effective_node_orders(template.report)
    report_payload["node_orders"] = [list(item) for item in node_orders]

    return {
        "schema_version": TEMPLATE_SCHEMA_VERSION,
        "name": template.name,
        "test_data_header_row": template.test_data_header_row,
        "row_header_row": template.row_header_row,
        "test_data_start_column": template.test_data_start_column,
        "unit_row": template.unit_row,
        "test_data_start_row": template.test_data_start_row,
        "column_header_levels": [
            _column_header_level_to_payload(item)
            for item in template.column_header_levels
        ],
        "numeric_cleanup": _numeric_cleanup_to_payload(template.numeric_cleanup),
        "row_dimensions": [
            _row_dimension_to_payload(item) for item in template.row_dimensions
        ],
        "analysis_groups": [
            _analysis_group_to_payload(item) for item in template.analysis_groups
        ],
        "golden_reference_defaults": _golden_reference_defaults_to_payload(
            template.golden_reference_defaults
        ),
        "report": report_payload,
        "tsk_analysis": _tsk_analysis_to_payload(template.tsk_analysis),
    }


def _row_dimension_to_payload(item: RowDimension) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "name": item.name,
        "priority": item.priority,
        "sources": [
            _row_dimension_source_to_payload(source) for source in item.sources
        ],
    }
    if item.optional:
        payload["optional"] = True
    if item.display_name is not None:
        payload["display_name"] = item.display_name
    if item.default_value is not None:
        payload["default_value"] = item.default_value
    return payload


def _row_dimension_source_to_payload(source: RowDimensionSource) -> dict[str, Any]:
    payload: dict[str, Any] = {"column": source.column}
    if source.split_delimiters:
        payload["split_delimiters"] = list(source.split_delimiters)
    if source.split_position is not None:
        payload["default_split_position"] = source.split_position
    if source.split_position_by_column is not None:
        payload["split_position_by_column"] = source.split_position_by_column
    if source.split_position_map:
        payload["split_position_map"] = {
            str(key): int(value) for key, value in source.split_position_map.items()
        }
    if source.skip_empty_parts:
        payload["skip_empty_parts"] = True
    return payload


def _analysis_group_to_payload(item: AnalysisGroup) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "id": item.id,
        "display_name": item.display_name,
        "columns": [
            {
                **({"column_order": column.column_order} if column.column_order is not None else {}),
                "name": column.name,
                "header_values": list(column.header_values),
            }
            for column in item.columns
        ],
        "analysis_mode": item.analysis_mode,
    }
    if item.unit is not None:
        payload["unit"] = item.unit
    if item.outlier_golden_method is not None:
        payload["outlier_golden_method"] = item.outlier_golden_method
    if item.golden_relative_limit is not None:
        payload["golden_relative_limit"] = _serialize_number(item.golden_relative_limit)
    if item.golden_sigma_multiplier is not None:
        payload["golden_sigma_multiplier"] = _serialize_number(item.golden_sigma_multiplier)
    if item.golden_absolute_lower_bound is not None:
        payload["golden_absolute_lower_bound"] = _serialize_number(item.golden_absolute_lower_bound)
    if item.golden_absolute_upper_bound is not None:
        payload["golden_absolute_upper_bound"] = _serialize_number(item.golden_absolute_upper_bound)
    if item.golden_overwrite_lowerbound is not None:
        payload["golden_overwrite_lowerbound"] = _serialize_number(
            item.golden_overwrite_lowerbound
        )
    if item.golden_overwrite_upperbound is not None:
        payload["golden_overwrite_upperbound"] = _serialize_number(
            item.golden_overwrite_upperbound
        )
    if item.golden_continuous_interval is not None:
        payload["golden_continuous_interval"] = bool(item.golden_continuous_interval)
    if item.golden_empty_range_fallback_to_absolute is not None:
        payload["golden_empty_range_fallback_to_absolute"] = bool(
            item.golden_empty_range_fallback_to_absolute
        )
    return payload


def _column_header_level_to_payload(item: ColumnHeaderLevel) -> dict[str, Any]:
    return {
        "name": item.name,
        "priority": item.priority,
    }


def _threshold_config_to_payload(config: ThresholdConfig) -> dict[str, Any]:
    payload: dict[str, Any] = {"default": _serialize_number(config.default)}
    if config.overrides:
        payload["overrides"] = {
            key: _serialize_number(value) for key, value in config.overrides.items()
        }
    return payload


def _golden_reference_defaults_to_payload(
    defaults: GoldenReferenceDefaults,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "reference_dimensions": list(defaults.reference_dimensions),
        "filters": dict(defaults.filters),
        "center_method": defaults.center_method,
        "outlier_golden_method": defaults.outlier_golden_method,
    }
    if defaults.relative_limit is not None:
        payload["relative_limit"] = _serialize_number(defaults.relative_limit)
    if defaults.sigma_multiplier is not None:
        payload["sigma_multiplier"] = _serialize_number(defaults.sigma_multiplier)
    if defaults.absolute_lower_bound is not None:
        payload["absolute_lower_bound"] = _serialize_number(defaults.absolute_lower_bound)
    if defaults.absolute_upper_bound is not None:
        payload["absolute_upper_bound"] = _serialize_number(defaults.absolute_upper_bound)
    if defaults.overwrite_lowerbound is not None:
        payload["overwrite_lowerbound"] = _serialize_number(
            defaults.overwrite_lowerbound
        )
    if defaults.overwrite_upperbound is not None:
        payload["overwrite_upperbound"] = _serialize_number(
            defaults.overwrite_upperbound
        )
    payload["continuous_interval"] = bool(defaults.continuous_interval)
    payload["empty_range_fallback_to_absolute"] = bool(
        defaults.empty_range_fallback_to_absolute
    )
    return payload


def _numeric_cleanup_to_payload(config: NumericCleanupConfig) -> dict[str, Any]:
    return {
        "enabled": config.enabled,
        "mode": config.mode,
        "characters": list(config.characters),
    }


def _analysis_column_filters_to_payload(
    config: AnalysisColumnFilterConfig,
) -> dict[str, dict[str, list[str]]]:
    payload: dict[str, dict[str, list[str]]] = {}
    if config.include:
        payload["include"] = {
            str(key): [str(value) for value in values]
            for key, values in config.include.items()
            if values
        }
    if config.exclude:
        payload["exclude"] = {
            str(key): [str(value) for value in values]
            for key, values in config.exclude.items()
            if values
        }
    return payload

def _effective_group_by_dimensions(item: OutlierRatioStatConfig) -> list[str]:
    return [
        str(value).strip()
        for value in (item.group_by_dimensions or [item.group_by_dimension])
        if str(value).strip()
    ]


def _parse_group_by_dimensions(item: dict[str, Any]) -> list[str]:
    values = [
        str(value).strip()
        for value in item.get("group_by_dimensions", [])
        if str(value).strip()
    ]
    if values:
        return values
    single = str(item.get("group_by_dimension", "")).strip()
    return [single] if single else []


def _parse_sample_dimension_names(report_payload: dict[str, Any]) -> list[str]:
    values = [
        str(value).strip()
        for value in report_payload.get("sample_dimension_names", [])
        if str(value).strip()
    ]
    if values:
        return values
    single = str(report_payload.get("sample_dimension_name", "")).strip()
    return [single] if single else []


def _parse_analysis_column_filters(
    report_payload: dict[str, Any],
) -> AnalysisColumnFilterConfig:
    raw_payload = report_payload.get("analysis_column_filters", {})
    if not isinstance(raw_payload, dict):
        return AnalysisColumnFilterConfig()
    normalized: dict[str, dict[str, list[str]]] = {}
    for mode in ("include", "exclude"):
        raw_mode_payload = raw_payload.get(mode, {})
        if not isinstance(raw_mode_payload, dict):
            continue
        mode_payload: dict[str, list[str]] = {}
        for key, values in raw_mode_payload.items():
            normalized_values = [
                str(value).strip() for value in values if str(value).strip()
            ]
            if normalized_values:
                mode_payload[str(key).strip()] = normalized_values
        if mode_payload:
            normalized[mode] = mode_payload
    return AnalysisColumnFilterConfig(
        include=normalized.get("include", {}),
        exclude=normalized.get("exclude", {}),
    )


def _analysis_dimension_filters_to_payload(
    config: AnalysisDimensionFilterConfig,
) -> dict[str, dict[str, list[str]]]:
    payload: dict[str, dict[str, list[str]]] = {}
    for mode_name, values in (("include", config.include), ("exclude", config.exclude)):
        normalized = {
            str(key): [str(item) for item in items]
            for key, items in values.items()
            if items
        }
        if normalized:
            payload[mode_name] = normalized
    return payload


def _parse_analysis_dimension_filters(
    report_payload: dict[str, Any],
) -> AnalysisDimensionFilterConfig:
    raw_payload = report_payload.get("analysis_dimension_filters", {})
    if not isinstance(raw_payload, dict):
        return AnalysisDimensionFilterConfig()
    normalized: dict[str, dict[str, list[str]]] = {}
    for mode in ("include", "exclude"):
        raw_mode_payload = raw_payload.get(mode, {})
        if not isinstance(raw_mode_payload, dict):
            continue
        mode_payload: dict[str, list[str]] = {}
        for key, values in raw_mode_payload.items():
            normalized_values = [
                str(value).strip() for value in values if str(value).strip()
            ]
            if normalized_values:
                mode_payload[str(key).strip()] = normalized_values
        if mode_payload:
            normalized[mode] = mode_payload
    return AnalysisDimensionFilterConfig(
        include=normalized.get("include", {}),
        exclude=normalized.get("exclude", {}),
    )


def _outlier_ratio_stat_to_payload(item: OutlierRatioStatConfig) -> dict[str, Any]:
    group_by_dimensions = _effective_group_by_dimensions(item)
    payload: dict[str, Any] = {
        "id": item.id,
        "numerator": item.numerator,
    }
    if len(group_by_dimensions) == 1:
        payload["group_by_dimension"] = group_by_dimensions[0]
    else:
        payload["group_by_dimensions"] = list(group_by_dimensions)
    if item.display_name is not None:
        payload["display_name"] = item.display_name
    if item.group_ids:
        payload["group_ids"] = list(item.group_ids)
    if item.group_display_names:
        payload["group_display_names"] = list(item.group_display_names)
    if item.test_types:
        payload["test_types"] = list(item.test_types)
    if item.chain_names:
        payload["chain_names"] = list(item.chain_names)
    if item.column_names:
        payload["column_names"] = list(item.column_names)
    if item.units:
        payload["units"] = list(item.units)
    if item.chains:
        payload["chains"] = list(item.chains)
    if item.raw_columns:
        payload["raw_columns"] = list(item.raw_columns)
    if item.logical_metrics:
        payload["logical_metrics"] = list(item.logical_metrics)
    return payload


def _tsk_analysis_to_payload(config: TSKAnalysisConfig) -> dict[str, Any]:
    return {
        "enabled": config.enabled,
        "use_xy": config.use_xy,
        "coordinate_unit": config.coordinate_unit,
        "feature_columns": list(config.feature_columns),
        "group_by_dimensions": list(config.group_by_dimensions),
        "instances": [
            {
                "chain_id": instance.chain_id,
                "tsk_instance_id": instance.tsk_instance_id,
                "tsk_id": instance.tsk_id,
                "chain_key": list(instance.chain_key),
                "x": instance.x,
                "y": instance.y,
                "features": dict(instance.features),
            }
            for instance in config.instances
        ],
    }


def _tsk_string_list(value: Any, field_name: str) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError(f"{field_name} must be a list of non-empty strings.")
    return [item.strip() for item in value]


def _tsk_number(value: Any, field_name: str) -> float | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be a finite number.")
    try:
        number = float(value)
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError(f"{field_name} must be a finite number.") from exc
    if not isfinite(number):
        raise ValueError(f"{field_name} must be a finite number.")
    return number


def _parse_tsk_analysis(payload: Any) -> TSKAnalysisConfig:
    if payload is None:
        payload = {}
    if not isinstance(payload, dict):
        raise ValueError("tsk_analysis must be an object.")
    raw_instances = payload.get("instances", [])
    if not isinstance(raw_instances, list):
        raise ValueError("tsk_analysis.instances must be a list.")
    instances = []
    for index, item in enumerate(raw_instances, start=1):
        context = f"tsk_analysis.instances[{index}]"
        if not isinstance(item, dict):
            raise ValueError(f"{context} must be an object.")
        features = item.get("features", {})
        if not isinstance(features, dict):
            raise ValueError(f"{context}.features must be an object.")
        instances.append(TSKInstance(
            chain_id=str(item.get("chain_id", "") or "").strip(),
            tsk_instance_id=str(item.get("tsk_instance_id", "") or "").strip(),
            tsk_id=str(item.get("tsk_id", "") or "").strip(),
            chain_key=_tsk_string_list(item.get("chain_key", []), f"{context}.chain_key"),
            x=_tsk_number(item.get("x"), f"{context}.x"),
            y=_tsk_number(item.get("y"), f"{context}.y"),
            features={str(key).strip(): _tsk_number(value, f"{context}.features.{key}")
                      for key, value in features.items()},
        ))
    return TSKAnalysisConfig(
        enabled=_coerce_bool_value(payload.get("enabled", False)),
        use_xy=_coerce_bool_value(payload.get("use_xy", False)),
        coordinate_unit=str(payload.get("coordinate_unit", "um") or "").strip(),
        feature_columns=_tsk_string_list(payload.get("feature_columns", []), "tsk_analysis.feature_columns"),
        group_by_dimensions=_tsk_string_list(payload.get("group_by_dimensions", []), "tsk_analysis.group_by_dimensions"),
        instances=instances,
    )


def validate_tsk_analysis_config(template: TemplateConfig, *, require_instances: bool = False) -> None:
    """Validate topology, resolving unambiguous chain names to complete paths.

    Disabled example topology may remain while users edit ordinary analysis
    columns. Execution calls with require_instances=True to reject stale links.
    """
    config = template.tsk_analysis
    strict = config.enabled or require_instances
    if not config.coordinate_unit:
        raise ValueError("tsk_analysis.coordinate_unit cannot be empty.")
    feature_keys = [field_key(name) for name in config.feature_columns]
    reserved = {field_key(name) for name in ("CHAIN_ID", "TSK_instance_ID", "TSK_ID", "X", "Y", "CHAIN_KEY")}
    if len(set(feature_keys)) != len(feature_keys) or any(not name or name in reserved for name in feature_keys):
        raise ValueError("tsk_analysis.feature_columns must be unique and cannot use reserved instance column names.")
    row_names = row_levels(template)
    row_fields = FieldNames(row_names, ((item.display_name, item.name) for item in template.row_dimensions if item.display_name))
    config.group_by_dimensions = [row_fields.resolve(name, strict=True) for name in config.group_by_dimensions]
    if len(set(config.group_by_dimensions)) != len(config.group_by_dimensions):
        raise ValueError("tsk_analysis.group_by_dimensions contains duplicate dimensions.")
    if strict and not config.instances:
        raise ValueError("TSK analysis requires at least one instance in tsk_instances.")
    levels = column_levels(template)
    chain = chain_level(template)
    prefix_length = levels.index(chain) + 1 if chain in levels else 0
    known_keys = {
        tuple(column.header_values[:prefix_length])
        for group in template.analysis_groups for column in group.columns
        if prefix_length and len(column.header_values) >= prefix_length
    }
    seen = set()
    chain_ids = {}
    key_ids = {}
    for instance in config.instances:
        if not instance.chain_id or not instance.tsk_instance_id or not instance.tsk_id:
            raise ValueError("Each TSK instance requires CHAIN_ID, TSK_instance_ID and TSK_ID.")
        if not instance.chain_key:
            matches = [key for key in known_keys if key[-1] == instance.chain_id]
            if len(matches) == 1:
                instance.chain_key = list(matches[0])
            elif strict:
                detail = "ambiguous" if matches else "unknown"
                raise ValueError(f"TSK CHAIN_ID {instance.chain_id!r} is {detail}; set CHAIN_KEY to the complete column path.")
        key = tuple(instance.chain_key)
        if strict and key not in known_keys:
            raise ValueError(f"TSK CHAIN_KEY {list(key)!r} does not match a complete chain path in analysis_groups.")
        identity_key = key or (instance.chain_id,)
        if instance.chain_id in chain_ids and chain_ids[instance.chain_id] != identity_key:
            raise ValueError(f"TSK CHAIN_ID {instance.chain_id!r} maps to more than one CHAIN_KEY; use distinct IDs.")
        if identity_key in key_ids and key_ids[identity_key] != instance.chain_id:
            raise ValueError(f"TSK CHAIN_KEY {list(key)!r} has multiple CHAIN_ID aliases.")
        chain_ids[instance.chain_id] = identity_key
        key_ids[identity_key] = instance.chain_id
        identity = (identity_key, instance.tsk_instance_id)
        if identity in seen:
            raise ValueError(f"Duplicate TSK instance {instance.tsk_instance_id!r} in chain {instance.chain_id!r}.")
        seen.add(identity)
        for name in ("x", "y"):
            value = getattr(instance, name)
            if value is not None:
                setattr(instance, name, _tsk_number(value, f"TSK {instance.tsk_instance_id}.{name}"))
        if strict and config.use_xy and (instance.x is None or instance.y is None):
            raise ValueError(f"TSK instance {instance.tsk_instance_id!r} requires both X and Y when use_xy is enabled.")
        if set(instance.features) - set(config.feature_columns):
            raise ValueError(f"TSK instance {instance.tsk_instance_id!r} contains features not declared in feature_columns.")
        for name, value in instance.features.items():
            if value is None or _tsk_number(value, f"TSK {instance.tsk_instance_id}.{name}") is None:
                raise ValueError(f"TSK instance {instance.tsk_instance_id!r} feature {name!r} must be a finite number.")
        if strict and set(instance.features) != set(config.feature_columns):
            raise ValueError(f"TSK instance {instance.tsk_instance_id!r} is missing declared numeric features.")


def _parse_template(payload: dict[str, Any]) -> TemplateConfig:
    payload = configuration_fields(payload)
    row_dimensions = [
        RowDimension(
            name=item["name"],
            priority=int(item["priority"]),
            sources=[
                RowDimensionSource(
                    column=source["column"],
                    split_delimiters=[
                        str(delimiter)
                        for delimiter in source.get("split_delimiters", [])
                        if str(delimiter)
                    ],
                    split_position=source.get(
                        "default_split_position",
                        source.get("split_position"),
                    ),
                    split_position_by_column=(
                        str(source.get("split_position_by_column")).strip()
                        if source.get("split_position_by_column") not in {None, ""}
                        else None
                    ),
                    split_position_map={
                        str(key).strip(): int(value)
                        for key, value in source.get("split_position_map", {}).items()
                        if str(key).strip() != ""
                    },
                    skip_empty_parts=source.get("skip_empty_parts", False),
                )
                for source in item.get("sources", [])
            ],
            optional=item.get("optional", False),
            display_name=item.get("display_name"),
            default_value=item.get("default_value"),
        )
        for item in payload.get("row_dimensions", [])
    ]
    column_header_levels = [
        ColumnHeaderLevel(
            name=str(item["name"]).strip(),
            priority=int(item["priority"]),
        )
        for item in payload.get("column_header_levels", [])
    ]
    row_dimensions.sort(key=lambda item: item.priority)
    column_header_levels.sort(key=lambda item: item.priority)
    analysis_groups = [
        AnalysisGroup(
            id=item["id"],
            display_name=item.get("display_name", item["id"]),
            columns=[
                AnalysisColumn(
                    name=column["name"],
                    header_values=[
                        str(value).strip()
                        for value in column.get("header_values", [])
                        if str(value).strip()
                    ],
                    column_order=_parse_optional_int_value(column.get("column_order")),
                )
                for column in item["columns"]
            ],
            analysis_mode=item["analysis_mode"],
            unit=item.get("unit"),
            outlier_golden_method=item.get("outlier_golden_method"),
            golden_relative_limit=_parse_optional_float_value(
                item.get("golden_relative_limit")
            ),
            golden_sigma_multiplier=_parse_optional_float_value(
                item.get("golden_sigma_multiplier")
            ),
            golden_absolute_lower_bound=_parse_optional_float_value(
                item.get("golden_absolute_lower_bound")
            ),
            golden_absolute_upper_bound=_parse_optional_float_value(
                item.get("golden_absolute_upper_bound")
            ),
            golden_overwrite_lowerbound=_parse_optional_float_value(
                item.get(
                    "golden_overwrite_lowerbound",
                    item.get(
                        "golden_overwrite_lower_bound",
                        item.get(
                            "golden_overwrite_min",
                            item.get(
                                "overwrite_lower_bound",
                                item.get("overwrite_min"),
                            ),
                        ),
                    ),
                )
            ),
            golden_overwrite_upperbound=_parse_optional_float_value(
                item.get(
                    "golden_overwrite_upperbound",
                    item.get(
                        "golden_overwrite_upper_bound",
                        item.get(
                            "golden_overwrite_max",
                            item.get(
                                "overwrite_upper_bound",
                                item.get("overwrite_max"),
                            ),
                        ),
                    ),
                )
            ),
            golden_continuous_interval=(
                _coerce_bool_value(
                    item.get(
                        "golden_continuous_interval",
                        item.get("continuous_interval"),
                    )
                )
                if item.get("golden_continuous_interval", item.get("continuous_interval")) not in {None, ""}
                else None
            ),
            golden_empty_range_fallback_to_absolute=(
                _coerce_bool_value(
                    item.get(
                        "golden_empty_range_fallback_to_absolute",
                        item.get("empty_range_fallback_to_absolute"),
                    )
                )
                if item.get(
                    "golden_empty_range_fallback_to_absolute",
                    item.get("empty_range_fallback_to_absolute"),
                )
                not in {None, ""}
                else None
            ),
        )
        for item in payload.get("analysis_groups", [])
    ]
    report_payload = payload.get("report", {})
    for forbidden in ("final_row_merge_level", "final_column_merge_level"):
        if report_payload.get(forbidden) not in {None, ""}:
            raise ValueError(f"{forbidden} is fixed by reliability_node_dimension / chain_column_level and cannot be set independently.")
    analysis_dimension_filters = _parse_analysis_dimension_filters(report_payload)
    analysis_column_filters = _parse_analysis_column_filters(report_payload)
    outlier_ratio_stats = [
        OutlierRatioStatConfig(
            id=item["id"],
            display_name=item.get("display_name"),
            group_by_dimension=_parse_group_by_dimensions(item)[0],
            group_by_dimensions=_parse_group_by_dimensions(item),
            numerator=item.get("numerator", "new_outlier_samples"),
            group_ids=[str(value).strip() for value in item.get("group_ids", []) if str(value).strip()],
            group_display_names=[
                str(value).strip()
                for value in item.get("group_display_names", [])
                if str(value).strip()
            ],
            test_types=[str(value).strip() for value in item.get("test_types", []) if str(value).strip()],
            chain_names=[
                str(value).strip()
                for value in item.get("chain_names", [])
                if str(value).strip()
            ],
            column_names=[
                str(value).strip()
                for value in item.get("column_names", [])
                if str(value).strip()
            ],
            units=[str(value).strip() for value in item.get("units", []) if str(value).strip()],
            chains=[str(value).strip() for value in item.get("chains", []) if str(value).strip()],
            raw_columns=[str(value).strip() for value in item.get("raw_columns", []) if str(value).strip()],
            logical_metrics=[str(value).strip() for value in item.get("logical_metrics", []) if str(value).strip()],
        )
        for item in report_payload.get("outlier_ratio_stats", [])
    ]
    node_orders = _parse_node_orders_payload(report_payload)
    golden_reference_payload = payload.get("golden_reference_defaults", {})
    relative_limit_raw = golden_reference_payload.get("relative_limit")
    sigma_multiplier_raw = golden_reference_payload.get("sigma_multiplier")
    absolute_lower_bound_raw = golden_reference_payload.get("absolute_lower_bound")
    absolute_upper_bound_raw = golden_reference_payload.get("absolute_upper_bound")
    overwrite_lowerbound_raw = golden_reference_payload.get(
        "overwrite_lowerbound",
        golden_reference_payload.get(
            "overwrite_lower_bound",
            golden_reference_payload.get("overwrite_min"),
        ),
    )
    overwrite_upperbound_raw = golden_reference_payload.get(
        "overwrite_upperbound",
        golden_reference_payload.get(
            "overwrite_upper_bound",
            golden_reference_payload.get("overwrite_max"),
        ),
    )
    continuous_interval_raw = golden_reference_payload.get("continuous_interval")
    empty_range_fallback_raw = golden_reference_payload.get(
        "empty_range_fallback_to_absolute"
    )
    template = TemplateConfig(
        name=payload["name"],
        tsk_analysis=_parse_tsk_analysis(payload.get("tsk_analysis")),
        test_data_header_row=payload.get(
            "test_data_header_row",
            payload.get("test_header_row", 0),
        ),
        row_header_row=payload.get(
            "row_header_row",
            payload.get(
                "test_data_header_row",
                payload.get("test_header_row", 0),
            ),
        ),
        test_data_start_column=payload.get(
            "test_data_start_column",
            payload.get("test_start_column"),
        ),
        unit_row=payload.get("unit_row"),
        test_data_start_row=payload.get(
            "test_data_start_row",
            payload.get("data_start_row"),
        ),
        column_header_levels=column_header_levels,
        numeric_cleanup=NumericCleanupConfig(
            enabled=bool(payload.get("numeric_cleanup", {}).get("enabled", False)),
            mode=str(payload.get("numeric_cleanup", {}).get("mode", "all_non_numeric")),
            characters=[
                str(item)
                for item in payload.get("numeric_cleanup", {}).get("characters", [])
                if str(item)
            ],
        ),
        row_dimensions=row_dimensions,
        analysis_groups=analysis_groups,
        golden_reference_defaults=GoldenReferenceDefaults(
            reference_dimensions=[
                str(item).strip()
                for item in golden_reference_payload.get("reference_dimensions", [])
                if str(item).strip()
            ],
            filters={
                str(key): str(value)
                for key, value in golden_reference_payload.get("filters", {}).items()
            },
            center_method=golden_reference_payload.get("center_method", "mean"),
            outlier_golden_method=golden_reference_payload.get(
                "outlier_golden_method", "relative"
            ),
            relative_limit=(
                0.2
                if relative_limit_raw in {None, ""}
                else _parse_optional_float_value(relative_limit_raw)
            ),
            sigma_multiplier=(
                3.0
                if sigma_multiplier_raw in {None, ""}
                else _parse_optional_float_value(sigma_multiplier_raw)
            ),
            absolute_lower_bound=_parse_optional_float_value(absolute_lower_bound_raw),
            absolute_upper_bound=_parse_optional_float_value(absolute_upper_bound_raw),
            overwrite_lowerbound=_parse_optional_float_value(overwrite_lowerbound_raw),
            overwrite_upperbound=_parse_optional_float_value(overwrite_upperbound_raw),
            continuous_interval=(
                _coerce_bool_value(continuous_interval_raw)
                if continuous_interval_raw not in {None, ""}
                else False
            ),
            empty_range_fallback_to_absolute=(
                _coerce_bool_value(empty_range_fallback_raw)
                if empty_range_fallback_raw not in {None, ""}
                else False
            ),
        ),
        report=ReportConfig(
            zscore_thresholds=_parse_threshold_config(
                report_payload.get("zscore_thresholds"),
                default=3.5,
            ),
            node_order=list(node_orders[0]) if node_orders else [],
            node_orders=node_orders,
            sample_dimension_names=_parse_sample_dimension_names(report_payload),
            reliability_node_dimension=str(report_payload.get("reliability_node_dimension", "reliability_node")).strip(),
            chain_column_level=report_payload.get("chain_column_level"),
            initial_row_merge_level=report_payload.get("initial_row_merge_level"),
            initial_column_merge_level=report_payload.get("initial_column_merge_level"),
            outlier_fail_method=report_payload.get(
                "outlier_fail_method", "modified_z_score"
            ),
            outlier_merged_test_fail_rule=_resolve_report_rule_value(
                report_payload,
                "outlier_merged_test_fail_rule",
                default="any_fail",
                legacy_field_names=("outlier_test_fail_rule",),
            ),
            outlier_test_group_fail_rule=_resolve_report_rule_value(
                report_payload,
                "outlier_test_group_fail_rule",
                default="any_fail",
                legacy_field_names=("outlier_test_fail_rule",),
            ),
            outlier_merged_sample_fail_rule=_resolve_report_rule_value(
                report_payload,
                "outlier_merged_sample_fail_rule",
                default="any_fail",
                legacy_field_names=("outlier_sample_fail_rule",),
            ),
            outlier_node_fail_rule=_resolve_report_rule_value(
                report_payload,
                "outlier_node_fail_rule",
                default="any_fail",
            ),
            outlier_row_merge_max_dimension=report_payload.get(
                "outlier_row_merge_max_dimension"
            ),
            outlier_test_merge_max_level=report_payload.get(
                "outlier_test_merge_max_level"
            ),
            outlier_merge_order=report_payload.get(
                "outlier_merge_order",
                OUTLIER_MERGE_ORDER_OPTIONS[0],
            ),
            outlier_treat_empty_cells_as_fail=_coerce_bool_value(
                report_payload.get("outlier_treat_empty_cells_as_fail", True)
            ),
            analysis_dimension_filters=analysis_dimension_filters,
            analysis_column_filters=analysis_column_filters,
            outlier_ratio_stats=outlier_ratio_stats,
        ),
    )
    normalize_template_references(template)
    template.report.analysis_dimension_filters = _normalize_analysis_dimension_filter_config(
        template.report.analysis_dimension_filters, template
    )
    template.report.analysis_column_filters = _normalize_analysis_column_filter_config(
        template.report.analysis_column_filters,
        template,
    )
    source_version = int(payload.get("schema_version", 1))
    if source_version > TEMPLATE_SCHEMA_VERSION:
        raise ValueError(f"Unsupported future template schema_version: {source_version}")
    template.schema_version = TEMPLATE_SCHEMA_VERSION
    template.migration_required = source_version < TEMPLATE_SCHEMA_VERSION
    template.report.outlier_merge_order = normalize_merge_order(template.report.outlier_merge_order)
    # v2 already uses retained levels. A layout-only upgrade must not reinterpret them.
    if source_version < 2:
        template.report.chain_column_level = chain_level(template)
        rows, columns = row_levels(template), column_levels(template)
        if not template.report.initial_row_merge_level:
            template.report.initial_row_merge_level = (
                retained_level(rows, template.report.outlier_row_merge_max_dimension)
                if template.report.outlier_row_merge_max_dimension else (rows[-1] if rows else None)
            )
        if not template.report.initial_column_merge_level:
            template.report.initial_column_merge_level = (
                retained_level(columns, template.report.outlier_test_merge_max_level)
                if template.report.outlier_test_merge_max_level else (columns[-2] if len(columns) > 1 else None)
            )
        if columns and not template.report.initial_column_merge_level:
            template.migration_issues.append("旧列合并起点没有上一级，无法等价转换。请先选择 Chain 层级和 Initial column 保留层级，再确认升级。")
    _validate_template(template)
    validate_tsk_analysis_config(template)
    return template


def _parse_threshold_config(
    payload: dict | float | int | None, default: float
) -> ThresholdConfig:
    if payload is None:
        return ThresholdConfig(default=default)
    if isinstance(payload, (int, float)):
        return ThresholdConfig(default=float(payload))
    return ThresholdConfig(
        default=float(payload.get("default", default)),
        overrides={
            str(key): float(value) for key, value in payload.get("overrides", {}).items()
        },
    )


def _resolve_report_rule_value(
    payload: dict[str, Any],
    field_name: str,
    *,
    default: str,
    legacy_field_names: tuple[str, ...] = (),
) -> str:
    public_name = next((new for new, old in MERGE_RULE_FIELDS.items() if old == field_name), field_name)
    if public_name != field_name and payload.get(public_name) not in {None, ""}:
        if payload.get(field_name) not in {None, "", payload[public_name]}:
            raise ValueError(f"Conflicting merge fields: {public_name} and {field_name}.")
        return str(payload[public_name]).strip()
    for candidate in (field_name, *legacy_field_names):
        value = payload.get(candidate)
        if value not in {None, ""}:
            return str(value).strip()
    return default


def _parse_node_orders_payload(report_payload: dict[str, Any]) -> list[list[str]]:
    if "node_orders" in report_payload and report_payload.get("node_orders") is not None:
        payload = report_payload.get("node_orders")
        if not isinstance(payload, list):
            raise ValueError("report.node_orders must be a list of node sequences.")
        node_orders: list[list[str]] = []
        for index, item in enumerate(payload, start=1):
            if not isinstance(item, list):
                raise ValueError(
                    f"report.node_orders[{index}] must be a list of node names."
                )
            nodes = [str(node).strip() for node in item if str(node).strip()]
            node_orders.append(nodes)
        return node_orders
    legacy_payload = report_payload.get("node_order", [])
    if legacy_payload and isinstance(legacy_payload, list) and isinstance(legacy_payload[0], list):
        return [
            [str(node).strip() for node in item if str(node).strip()]
            for item in legacy_payload
        ]
    return [[str(item).strip() for item in legacy_payload if str(item).strip()]]


def _canonical_analysis_column_filter_field(field_name: str, template: TemplateConfig) -> str:
    try:
        return column_filter_fields(template).resolve(field_name, strict=True)
    except ValueError as exc:
        raise ValueError(f"report.analysis_column_filters uses an unsupported field: {field_name}. {exc}") from exc


def _analysis_column_filter_allowed_values(template: TemplateConfig) -> dict[str, set[str]]:
    allowed_values: dict[str, set[str]] = {
        "id": set(),
        "display_name": set(),
        "raw_column": set(),
        "logical_metric": set(),
        "unit": set(),
    }
    for level in template.column_header_levels:
        allowed_values.setdefault(level.name, set())
    for group in template.analysis_groups:
        allowed_values["id"].add(str(group.id))
        allowed_values["display_name"].add(str(group.display_name))
        if group.unit is not None:
            allowed_values["unit"].add(str(group.unit))
        for column in group.columns:
            allowed_values["raw_column"].add(str(column.name))
            logical_metric = (
                group.id
                if group.analysis_mode == "pooled_columns"
                else f"{group.id}::{column.name}"
            )
            allowed_values["logical_metric"].add(str(logical_metric))
            for level, header_value in zip(template.column_header_levels, column.header_values):
                allowed_values[level.name].add(str(header_value))
    return allowed_values


def _normalize_analysis_column_filter_config(
    config: AnalysisColumnFilterConfig,
    template: TemplateConfig,
) -> AnalysisColumnFilterConfig:
    allowed_values = _analysis_column_filter_allowed_values(template)
    normalized_payload: dict[str, dict[str, list[str]]] = {}
    for mode_name, raw_filters in (
        ("include", config.include),
        ("exclude", config.exclude),
    ):
        mode_filters: dict[str, list[str]] = {}
        for raw_key, raw_values in raw_filters.items():
            canonical_key = _canonical_analysis_column_filter_field(str(raw_key), template)
            normalized_values = []
            seen_values: set[str] = set()
            for raw_value in raw_values:
                value = str(raw_value).strip()
                if not value or value in seen_values:
                    continue
                if allowed_values.get(canonical_key) and value not in allowed_values[canonical_key]:
                    raise ValueError(
                        "report.analysis_column_filters contains an unsupported value "
                        f"for {canonical_key}: {value}."
                    )
                seen_values.add(value)
                normalized_values.append(value)
            if normalized_values:
                existing = mode_filters.setdefault(canonical_key, [])
                existing.extend(value for value in normalized_values if value not in existing)
        if mode_filters:
            normalized_payload[mode_name] = mode_filters
    return AnalysisColumnFilterConfig(
        include=normalized_payload.get("include", {}),
        exclude=normalized_payload.get("exclude", {}),
    )


def _canonical_analysis_dimension_filter_field(field_name: str, template=None) -> str:
    aliases = {
        "sample_key": "sample_key",
        "sample_keys": "sample_key",
        "sample": "sample_key",
        "sample_id": "sample_key",
        "sample_ids": "sample_key",
        "node": "reliability_node",
        "nodes": "reliability_node",
        "reliability_node": "reliability_node",
        "reliability_nodes": "reliability_node",
    }
    # These are role filters (the selected sample identity and node), not a
    # new generic row-filter feature. Accept the configured node's own Name.
    if template is not None:
        aliases[template.report.reliability_node_dimension] = "reliability_node"
        for dimension in template.row_dimensions:
            if dimension.name == template.report.reliability_node_dimension and dimension.display_name:
                aliases[dimension.display_name] = "reliability_node"
    try:
        return FieldNames(('sample_key', 'reliability_node'), aliases.items()).resolve(field_name, strict=True)
    except ValueError as exc:
        raise ValueError(f"report.analysis_dimension_filters uses an unsupported field: {field_name}. {exc}") from exc


def _normalize_analysis_dimension_filter_config(
    config: AnalysisDimensionFilterConfig,
    template=None,
) -> AnalysisDimensionFilterConfig:
    normalized_payload: dict[str, dict[str, list[str]]] = {}
    for mode_name, raw_filters in (
        ("include", config.include),
        ("exclude", config.exclude),
    ):
        mode_filters: dict[str, list[str]] = {}
        for raw_key, raw_values in raw_filters.items():
            canonical_key = _canonical_analysis_dimension_filter_field(raw_key, template)
            normalized_values: list[str] = []
            seen_values: set[str] = set()
            for raw_value in raw_values:
                value = str(raw_value).strip()
                if not value or value in seen_values:
                    continue
                seen_values.add(value)
                normalized_values.append(value)
            if normalized_values:
                existing = mode_filters.setdefault(canonical_key, [])
                existing.extend(value for value in normalized_values if value not in existing)
        if mode_filters:
            normalized_payload[mode_name] = mode_filters
    return AnalysisDimensionFilterConfig(
        include=normalized_payload.get("include", {}),
        exclude=normalized_payload.get("exclude", {}),
    )


def _validate_template(template: TemplateConfig) -> None:
    seen_dimensions: set[str] = set()
    seen_row_priorities: set[int] = set()
    for dimension in template.row_dimensions:
        if dimension.name in seen_dimensions:
            raise ValueError(f"Duplicate row dimension: {dimension.name}")
        seen_dimensions.add(dimension.name)
        if dimension.priority in seen_row_priorities:
            raise ValueError(
                f"Duplicate row dimension priority: {dimension.priority}"
            )
        seen_row_priorities.add(dimension.priority)
        if not dimension.sources:
            raise ValueError(f"Row dimension {dimension.name} must define at least one source.")
        for source_index, source in enumerate(dimension.sources, start=1):
            if not source.column:
                raise ValueError(
                    f"Row dimension {dimension.name} source {source_index} must define a column."
                )
            has_split_logic = (
                source.split_position is not None
                or bool(source.split_position_map)
                or source.split_position_by_column is not None
            )
            if has_split_logic and not source.split_delimiters:
                raise ValueError(
                    f"Row dimension {dimension.name} source {source_index} uses split logic and must define split_delimiters."
                )
            if source.split_position_by_column and not source.split_position_map:
                raise ValueError(
                    f"Row dimension {dimension.name} source {source_index} defines split_position_by_column but no split_position_map."
                )
            if source.split_position_map and not source.split_position_by_column:
                raise ValueError(
                    f"Row dimension {dimension.name} source {source_index} defines split_position_map but no split_position_by_column."
                )
            for match_value, split_position in source.split_position_map.items():
                if split_position < 0:
                    raise ValueError(
                        f"Row dimension {dimension.name} source {source_index} has negative split position for match value {match_value!r}."
                    )

    if (
        template.test_data_start_column is not None
        and template.test_data_start_column < 0
    ):
        raise ValueError(
            "test_data_start_column must be a non-negative integer when provided."
        )
    if template.test_data_start_row is None:
        raise ValueError("test_data_start_row must be defined explicitly in the template.")
    if template.test_data_start_row < 0:
        raise ValueError("test_data_start_row must be a non-negative integer.")

    if not template.column_header_levels:
        raise ValueError("column_header_levels must define at least one header level.")
    seen_column_level_names: set[str] = set()
    seen_column_level_priorities: set[int] = set()
    for index, value in enumerate(template.column_header_levels, start=1):
        if not str(value.name).strip():
            raise ValueError(f"column_header_levels[{index}] cannot be empty.")
        normalized_name = value.name.strip().lower()
        if normalized_name in seen_column_level_names:
            raise ValueError("column_header_levels contains duplicate labels.")
        seen_column_level_names.add(normalized_name)
        if value.priority in seen_column_level_priorities:
            raise ValueError(
                f"Duplicate column header level priority: {value.priority}"
            )
        seen_column_level_priorities.add(value.priority)

    seen_groups: set[str] = set()
    seen_columns: set[str] = set()
    for group in template.analysis_groups:
        if group.id in seen_groups:
            raise ValueError(f"Duplicate analysis group id: {group.id}")
        seen_groups.add(group.id)
        if group.analysis_mode not in {"pooled_columns", "per_column"}:
            raise ValueError(
                f"Unsupported analysis mode for group {group.id}: {group.analysis_mode}"
            )
        for column in group.columns:
            if not column.name or not str(column.name).strip():
                raise ValueError(
                    f"Analysis group {group.id} contains a column without a name."
                )
            if len(column.header_values) != len(template.column_header_levels):
                raise ValueError(
                    f"Analysis group {group.id} column {column.name} must define exactly "
                    f"{len(template.column_header_levels)} header values."
                )
            if any(not str(value).strip() for value in column.header_values):
                raise ValueError(
                    f"Analysis group {group.id} column {column.name} contains empty header values."
                )
            if column.name in seen_columns:
                raise ValueError(
                    f"Column {column.name} is mapped by more than one analysis group."
                )
            seen_columns.add(column.name)
        if group.outlier_golden_method is not None:
            group.outlier_golden_method = validate_golden_rule_config(
                f"analysis_groups[{group.id}]",
                group.outlier_golden_method,
                group.golden_relative_limit,
                group.golden_sigma_multiplier,
                group.golden_absolute_lower_bound,
                group.golden_absolute_upper_bound,
                group.golden_overwrite_lowerbound,
                group.golden_overwrite_upperbound,
                bool(group.golden_continuous_interval),
                bool(group.golden_empty_range_fallback_to_absolute),
            )

    if template.report.outlier_fail_method not in {
        "modified_z_score",
        "golden_deviation",
        "zscore_and_golden",
        "zscore_or_golden",
    }:
        raise ValueError(
            "report.outlier_fail_method must be one of modified_z_score, golden_deviation, zscore_and_golden, or zscore_or_golden."
        )

    if template.report.outlier_merged_test_fail_rule not in {"any_fail", "all_fail"}:
        raise ValueError(
            "report.initial_column_merge_fail_rule must be one of any_fail or all_fail."
        )
    if template.report.outlier_test_group_fail_rule not in {"any_fail", "all_fail"}:
        raise ValueError(
            "report.final_column_merge_fail_rule must be one of any_fail or all_fail."
        )
    if template.report.outlier_merged_sample_fail_rule not in {"any_fail", "all_fail"}:
        raise ValueError(
            "report.initial_row_merge_fail_rule must be one of any_fail or all_fail."
        )
    if template.report.outlier_node_fail_rule not in {"any_fail", "all_fail"}:
        raise ValueError(
            "report.final_row_merge_fail_rule must be one of any_fail or all_fail."
        )

    for stat in template.report.outlier_ratio_stats:
        if stat.numerator not in {"new_outlier_samples", "outlier_samples", "recovered_samples"}:
            raise ValueError(
                f"report.outlier_ratio_stats[{stat.id}].numerator must be one of new_outlier_samples, outlier_samples, or recovered_samples."
            )
        group_dimensions = _effective_group_by_dimensions(stat)
        if not group_dimensions:
            raise ValueError(
                f"report.outlier_ratio_stats[{stat.id}].group_by_dimensions must be defined explicitly."
            )

    if template.row_dimensions:
        if not template.report.sample_dimension_names:
            raise ValueError(
                "report.sample_dimension_names must be defined and must match existing row dimensions."
            )
        seen_sample_dimensions: set[str] = set()
        for dimension_name in template.report.sample_dimension_names:
            if dimension_name in seen_sample_dimensions:
                raise ValueError(
                    "report.sample_dimension_names contains duplicate dimension names."
                )
            seen_sample_dimensions.add(dimension_name)
            if dimension_name not in seen_dimensions:
                raise ValueError(
                    "report.sample_dimension_names must match existing row dimensions."
                )
        if template.report.outlier_row_merge_max_dimension and template.report.outlier_row_merge_max_dimension not in seen_dimensions:
            raise ValueError(
                "report.outlier_row_merge_max_dimension must match an existing row dimension."
            )

    if normalize_merge_order(template.report.outlier_merge_order) not in OUTLIER_MERGE_ORDER_OPTIONS:
        raise ValueError(
            "report.outlier_merge_order must be one of the six supported merge execution orders."
        )

    seen_column_level_names = [item.name for item in template.column_header_levels]
    if template.column_header_levels:
        if template.report.outlier_test_merge_max_level and template.report.outlier_test_merge_max_level not in seen_column_level_names:
            raise ValueError(
                "report.outlier_test_merge_max_level must match an existing column header level."
            )
    if template.report.outlier_row_merge_max_dimension or template.report.initial_row_merge_level:
        ordered_row_dimension_names = [item.name for item in template.row_dimensions]
        node_dimension = template.report.reliability_node_dimension
        # Loading remains possible so the GUI can repair a legacy/mistyped role.
        # validate_report_identity enforces the role before validation/analysis.
        if node_dimension in ordered_row_dimension_names:
            node_index = ordered_row_dimension_names.index(node_dimension)
            merge_index = (
                ordered_row_dimension_names.index(template.report.initial_row_merge_level) + 1
                if template.report.initial_row_merge_level in ordered_row_dimension_names
                else ordered_row_dimension_names.index(template.report.outlier_row_merge_max_dimension)
            )
            if merge_index <= node_index:
                raise ValueError(
                    f"report.outlier_row_merge_max_dimension must be lower priority than {node_dimension}."
                )
            allowed_ratio_dimensions = set(ordered_row_dimension_names[: node_index + 1])
            allowed_ratio_dimensions.update(seen_column_level_names)
            for stat in template.report.outlier_ratio_stats:
                for dimension_name in _effective_group_by_dimensions(stat):
                    if dimension_name not in allowed_ratio_dimensions:
                        raise ValueError(
                            f"report.outlier_ratio_stats[{stat.id}].group_by_dimensions can only use reliability_node, higher-priority row dimensions, or column header levels."
                        )
        else:
            allowed_ratio_dimensions = set(ordered_row_dimension_names)
            allowed_ratio_dimensions.update(seen_column_level_names)
            for stat in template.report.outlier_ratio_stats:
                for dimension_name in _effective_group_by_dimensions(stat):
                    if dimension_name not in allowed_ratio_dimensions:
                        raise ValueError(
                            f"report.outlier_ratio_stats[{stat.id}].group_by_dimensions must match existing row_dimensions or column_header_levels. Invalid value: {dimension_name}."
                        )

    # Loading permits incomplete settings so the GUI can repair them. Analysis,
    # explicit validation, and migration require complete, safe retained levels.

    for index, node_order in enumerate(_effective_node_orders(template.report), start=1):
        if not node_order:
            raise ValueError(f"report.node_orders[{index}] cannot be empty.")
        if len(set(node_order)) != len(node_order):
            raise ValueError(
                f"report.node_orders[{index}] contains duplicate nodes."
            )
    _validate_node_order_consistency(_effective_node_orders(template.report))

    if template.golden_reference_defaults.center_method not in {"mean", "median"}:
        raise ValueError(
            "golden_reference_defaults.center_method must be one of mean or median."
        )
    template.golden_reference_defaults.outlier_golden_method = validate_golden_rule_config(
        "golden_reference_defaults",
        template.golden_reference_defaults.outlier_golden_method,
        template.golden_reference_defaults.relative_limit,
        template.golden_reference_defaults.sigma_multiplier,
        template.golden_reference_defaults.absolute_lower_bound,
        template.golden_reference_defaults.absolute_upper_bound,
        template.golden_reference_defaults.overwrite_lowerbound,
        template.golden_reference_defaults.overwrite_upperbound,
        template.golden_reference_defaults.continuous_interval,
        template.golden_reference_defaults.empty_range_fallback_to_absolute,
    )
    if template.numeric_cleanup.mode not in {"all_non_numeric", "specified_chars"}:
        raise ValueError(
            "numeric_cleanup.mode must be one of all_non_numeric or specified_chars."
        )


def _load_template_workbook_payload(
    path: Path,
    *,
    analysis_group_conflict_mode: str = ANALYSIS_GROUP_CONFLICT_MODE_FIRST_NON_EMPTY,
) -> dict[str, Any]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError(
            "Reading template xlsx requires openpyxl. Run `pip3 install -e .` first."
        ) from exc

    # Read cached formula results at workbook-load time so all downstream
    # template parsing sees concrete values instead of formula text.
    workbook = load_workbook(path, data_only=True)
    info = _load_template_info_sheet(workbook)
    column_header_levels = _load_column_header_levels_sheet(workbook)
    payload: dict[str, Any] = {
        "schema_version": info["schema_version"],
        "name": info["name"],
        "test_data_header_row": info["test_data_header_row"],
        "row_header_row": info["row_header_row"],
        "test_data_start_column": info["test_data_start_column"],
        "unit_row": info["unit_row"],
        "test_data_start_row": info["test_data_start_row"],
        "column_header_levels": column_header_levels,
        "numeric_cleanup": {
            "enabled": info["numeric_cleanup_enabled"],
            "mode": info["numeric_cleanup_mode"],
            "characters": info["numeric_cleanup_characters"],
        },
        "row_dimensions": _load_row_dimensions_sheet(workbook),
        "analysis_groups": _load_analysis_groups_sheet(
            workbook,
            [item["name"] for item in column_header_levels],
            analysis_group_conflict_mode=analysis_group_conflict_mode,
        ),
        "golden_reference_defaults": {
            "reference_dimensions": info["golden_reference_dimensions"],
            "filters": info["golden_reference_filters"],
            "center_method": info["golden_center_method"],
            "outlier_golden_method": info["golden_outlier_golden_method"],
            "relative_limit": info["golden_relative_limit"],
            "sigma_multiplier": info["golden_sigma_multiplier"],
            "absolute_lower_bound": info["golden_absolute_lower_bound"],
            "absolute_upper_bound": info["golden_absolute_upper_bound"],
            "overwrite_lowerbound": info["golden_overwrite_lowerbound"],
            "overwrite_upperbound": info["golden_overwrite_upperbound"],
            "continuous_interval": info["golden_continuous_interval"],
            "empty_range_fallback_to_absolute": info[
                "golden_empty_range_fallback_to_absolute"
            ],
        },
        "report": {
            "zscore_thresholds": {"default": info["report_default_zscore_threshold"]},
            "node_orders": _load_node_orders_sheet(workbook, fallback=info["node_order"]),
            "sample_dimension_names": info["sample_dimension_names"],
            "reliability_node_dimension": info["reliability_node_dimension"],
            "chain_column_level": info["chain_column_level"],
            "initial_column_merge_level": info["initial_column_merge_level"],
            "initial_row_merge_level": info["initial_row_merge_level"],
            "analysis_dimension_filters": _load_analysis_dimension_filters_sheet(
                workbook
            ),
            "analysis_column_filters": _load_analysis_column_filters_sheet(workbook),
            "outlier_ratio_stats": _load_outlier_ratio_stats_sheet(workbook),
            "outlier_fail_method": info["outlier_fail_method"],
            "outlier_merged_test_fail_rule": info["outlier_merged_test_fail_rule"],
            "outlier_test_group_fail_rule": info["outlier_test_group_fail_rule"],
            "outlier_merged_sample_fail_rule": info["outlier_merged_sample_fail_rule"],
            "outlier_node_fail_rule": info["outlier_node_fail_rule"],
            "outlier_row_merge_max_dimension": info["outlier_row_merge_max_dimension"],
            "outlier_test_merge_max_level": info["outlier_test_merge_max_level"],
            "outlier_merge_order": info["outlier_merge_order"],
            "outlier_treat_empty_cells_as_fail": info["outlier_treat_empty_cells_as_fail"],
        },
        "tsk_analysis": _load_tsk_workbook_payload(workbook),
    }
    return payload


def _load_tsk_workbook_payload(workbook) -> dict[str, Any]:
    """Both sheets are optional for existing templates."""
    payload: dict[str, Any] = {}
    settings_sheet = TEMPLATE_WORKBOOK_SHEETS["tsk_analysis"]
    if settings_sheet in workbook.sheetnames:
        settings = FieldLookup({
            _clean_cell(row.get("field")): row.get("value")
            for row in _load_rows_from_sheet(workbook, settings_sheet, {"field", "value"})
            if _clean_cell(row.get("field"))
        })
        payload = {
            "enabled": _coerce_bool_value(settings.get("enabled", False)),
            "use_xy": _coerce_bool_value(settings.get("use_xy", False)),
            "coordinate_unit": _parse_optional_string(settings.get("coordinate_unit"), "um"),
            "feature_columns": _parse_semicolon_list(settings.get("feature_columns")),
            "group_by_dimensions": _parse_semicolon_list(settings.get("group_by_dimensions")),
        }
    sheet_name = TEMPLATE_WORKBOOK_SHEETS["tsk_instances"]
    payload["instances"] = []
    if sheet_name not in workbook.sheetnames:
        return payload
    feature_columns = payload.get("feature_columns", [])
    reserved = {field_key(name) for name in ("CHAIN_ID", "TSK_instance_ID", "TSK_ID", "X", "Y", "CHAIN_KEY", "_sheet_row_number")}
    allowed_headers = reserved | {field_key(name) for name in feature_columns}
    for row in _load_rows_from_sheet(workbook, sheet_name, {"CHAIN_ID", "TSK_instance_ID", "TSK_ID"}):
        unknown = [name for name in row if field_key(name) not in allowed_headers and row[name] not in (None, "")]
        if unknown:
            raise ValueError(f"tsk_instances has undeclared feature columns: {', '.join(unknown)}. Add them to tsk_analysis.feature_columns.")
        raw_key = _clean_cell(row.get("CHAIN_KEY"))
        try:
            chain_key = json.loads(raw_key) if raw_key else []
        except (TypeError, ValueError) as exc:
            raise ValueError(f"tsk_instances row {row['_sheet_row_number']} CHAIN_KEY must be a JSON array, for example [\"Group A\", \"Chain 1\"].") from exc
        payload["instances"].append({
            "chain_id": _clean_cell(row.get("CHAIN_ID")),
            "tsk_instance_id": _clean_cell(row.get("TSK_instance_ID")),
            "tsk_id": _clean_cell(row.get("TSK_ID")),
            "chain_key": chain_key,
            "x": row.get("X"),
            "y": row.get("Y"),
            "features": {name: row.get(name) for name in feature_columns if row.get(name) not in (None, "")},
        })
    return payload


def _write_tsk_workbook_sheets(workbook, payload: dict[str, Any]) -> None:
    config = payload.get("tsk_analysis", {})
    readme_index = workbook.sheetnames.index(TEMPLATE_WORKBOOK_SHEETS["readme"])
    settings = workbook.create_sheet(TEMPLATE_WORKBOOK_SHEETS["tsk_analysis"], readme_index)
    _write_sheet_rows(settings, [
        ("Field", "Value", "Notes"),
        ("enabled", config.get("enabled", False), "是否配置 TSK 反推。普通 Analyze 不运行本模块。内置实例映射仅为假设示例，请先换成真实拓扑。"),
        ("use_xy", config.get("use_xy", False), "默认是否考虑实例 XY 位置。可在 TSK 窗口切换；启用时所有实例必须有 X/Y。"),
        ("coordinate_unit", config.get("coordinate_unit", "um"), "所有实例 X/Y 使用同一长度单位和坐标原点，如 um。"),
        ("feature_columns", ";".join(config.get("feature_columns", [])), "tsk_instances 中额外数值特征的列名，多个名称用英文分号分隔。"),
        ("group_by_dimensions", ";".join(config.get("group_by_dimensions", [])), "独立拟合的行维度，多个名称用英文分号分隔；先按这些维度分区再执行合并。节点始终分别统计。"),
    ], wrap_columns={3})
    _style_header_row(settings, fill_color="5B9BD5", font_color="FFFFFF")
    _set_sheet_widths(settings, {"A": 26, "B": 34, "C": 92})
    settings.freeze_panes = "A2"
    for row in range(2, settings.max_row + 1):
        settings.row_dimensions[row].height = 42
    sheet = workbook.create_sheet(TEMPLATE_WORKBOOK_SHEETS["tsk_instances"], readme_index + 1)
    feature_columns = config.get("feature_columns", [])
    rows = [("CHAIN_ID", "TSK_instance_ID", "TSK_ID", "X", "Y", "CHAIN_KEY", *feature_columns)]
    for item in config.get("instances", []):
        rows.append((item["chain_id"], item["tsk_instance_id"], item["tsk_id"], item.get("x"), item.get("y"),
                     json.dumps(item.get("chain_key", []), ensure_ascii=False),
                     *(item.get("features", {}).get(name) for name in feature_columns)))
    _write_sheet_rows(sheet, rows)
    _style_header_row(sheet, fill_color="5B9BD5", font_color="FFFFFF")
    _set_sheet_widths(sheet, {"A": 23, "B": 27, "C": 22, "D": 16, "E": 16, "F": 44,
                              **_indexed_widths(7, len(feature_columns), 24)})
    sheet.freeze_panes = "A2"
    for row in sheet.iter_rows(min_row=2, min_col=4, max_col=5):
        for cell in row:
            cell.number_format = "0.######"


def _save_template_workbook(payload: dict[str, Any], path: Path) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
    except ImportError as exc:
        raise RuntimeError(
            "Writing template xlsx requires openpyxl. Run `pip3 install -e .` first."
        ) from exc

    workbook = Workbook()
    info_sheet = workbook.active
    info_sheet.title = TEMPLATE_WORKBOOK_SHEETS["info"]
    info_rows = [
        ("Field", "Value", "Notes"),
        ("name", payload["name"], "Template name"),
        (
            "test_data_header_row",
            payload.get("test_data_header_row", 0),
            "Zero-based header row for the test-data area",
        ),
        (
            "row_header_row",
            payload.get("row_header_row"),
            "Zero-based row/sample attribute header row",
        ),
        (
            "test_data_start_column",
            payload.get("test_data_start_column"),
            "Zero-based first column of the test-data area; from this column onward row_header_row is ignored for headers",
        ),
        ("unit_row", payload.get("unit_row"), "Zero-based; optional"),
        (
            "test_data_start_row",
            payload.get("test_data_start_row"),
            "Zero-based first data row of the test-data area; required",
        ),
        (
            "node_order",
            None,
            "Deprecated in Excel template; edit node_orders sheet instead",
        ),
        (
            "reliability_node_dimension",
            payload.get("report", {}).get("reliability_node_dimension", "reliability_node"),
            "Plain text. Enter the node field name, e.g. stage, before or after defining row_dimensions. It must match a defined name before analysis. display_name only changes the visible label.",
        ),
        (
            "sample_dimension_names",
            ";".join(payload.get("report", {}).get("sample_dimension_names", [])),
            "Use ';' for multiple values. Example: lot_id;sample_id. Ordered tuple forming the unique sample ID. Must explicitly include all row dimensions above reliability_node_dimension, and exclude the node and lower site/repeat dimensions. Nothing is added automatically",
        ),
        (
            "outlier_fail_method",
            payload.get("report", {}).get("outlier_fail_method", "modified_z_score"),
            "modified_z_score / golden_deviation / zscore_and_golden / zscore_or_golden",
        ),
        (
            "outlier_merged_test_fail_rule",
            payload.get("report", {}).get("outlier_merged_test_fail_rule", "any_fail"),
            "Inside one merged test pool, any_fail means any leaf test fails => merged test pool fails; all_fail means all leaf tests must fail => merged test pool fails.",
        ),
        (
            "outlier_test_group_fail_rule",
            payload.get("report", {}).get("outlier_test_group_fail_rule", "any_fail"),
            "Then higher column levels above outlier_test_merge_max_level are aggregated upward with this rule until the top-level test group is decided. any_fail = any child pool fails; all_fail = all child pools fail.",
        ),
        (
            "outlier_merged_sample_fail_rule",
            payload.get("report", {}).get("outlier_merged_sample_fail_rule", "any_fail"),
            "After fixing the higher row dimensions outside the pool, this rule decides pass/fail inside one merged row pool. any_fail = any raw row in the pool fails; all_fail = every raw row in the pool must fail.",
        ),
        (
            "outlier_node_fail_rule",
            payload.get("report", {}).get("outlier_node_fail_rule", "any_fail"),
            "After fixing sample + reliability_node, this rule decides pass/fail across multiple merged row pools under that node. any_fail = any pool fails; all_fail = every pool must fail.",
        ),
        (
            "outlier_row_merge_max_dimension",
            payload.get("report", {}).get("outlier_row_merge_max_dimension"),
            "This chooses where row merging starts. This dimension and all lower-priority row dimensions go into the same row pool; higher-priority dimensions stay outside. It must be lower priority than reliability_node. Example: lot_id -> sample_id -> reliability_node -> site_id -> repeat_id with outlier_row_merge_max_dimension=site_id means site_id + repeat_id merge first, then the node result is decided across sites.",
        ),
        (
            "outlier_test_merge_max_level",
            payload.get("report", {}).get("outlier_test_merge_max_level"),
            "Column header levels at this column_header_levels.name and all lower-priority column levels are merged into one test pool. Higher-priority levels stay outside the pool. Example: Test Type",
        ),
        (
            "outlier_merge_order",
            payload.get("report", {}).get("outlier_merge_order", OUTLIER_MERGE_ORDER_OPTIONS[0]),
            "Choose one of the 6 supported merge execution orders. Example: column merge -> row merge -> column group -> row node",
        ),
        (
            "outlier_treat_empty_cells_as_fail",
            payload.get("report", {}).get("outlier_treat_empty_cells_as_fail", True),
            "When True, an expected test cell that is blank or non-numeric after numeric cleanup is treated as a raw failing cell in outlier analysis. Empty cells never participate in golden calculation.",
        ),
        (
            "report_default_zscore_threshold",
            payload.get("report", {}).get("zscore_thresholds", {}).get("default", 3.5),
            "Default zscore threshold used by report/export",
        ),
        (
            "golden_reference_dimensions",
            ";".join(
                payload.get("golden_reference_defaults", {}).get(
                    "reference_dimensions", []
                )
            ),
            "Use ';' for multiple values. Example: lot_id;sample_id;reliability_node. Default reference dims for Build Golden",
        ),
        (
            "golden_reference_filters",
            _format_filters_cell(
                payload.get("golden_reference_defaults", {}).get("filters", {})
            ),
            "Use ';' for multiple key=value pairs. Example: reliability_node=T0;site_id=A;temp=25C",
        ),
        (
            "golden_reference_center_method",
            payload.get("golden_reference_defaults", {}).get("center_method", "mean"),
            "mean or median",
        ),
        (
            "golden_reference_outlier_golden_method",
            payload.get("golden_reference_defaults", {}).get("outlier_golden_method", "relative"),
            "Any expression using relative, sigma, absolute, and, or, parentheses, plus optional suffix modifiers + overwrite_lowerbound / + overwrite_upperbound. Example: relative or absolute + overwrite_upperbound",
        ),
        (
            "golden_reference_relative_limit",
            payload.get("golden_reference_defaults", {}).get("relative_limit", 0.2),
            "Optional numeric default used when the global method contains relative",
        ),
        (
            "golden_reference_sigma_multiplier",
            payload.get("golden_reference_defaults", {}).get("sigma_multiplier", 3.0),
            "Optional numeric default used when the global method contains sigma",
        ),
        (
            "golden_reference_absolute_lower_bound",
            payload.get("golden_reference_defaults", {}).get("absolute_lower_bound"),
            "Optional numeric default used when the global method contains absolute",
        ),
        (
            "golden_reference_absolute_upper_bound",
            payload.get("golden_reference_defaults", {}).get("absolute_upper_bound"),
            "Optional numeric default used when the global method contains absolute",
        ),
        (
            "golden_reference_overwrite_lowerbound",
            payload.get("golden_reference_defaults", {}).get("overwrite_lowerbound"),
            "Optional numeric default used when the global method contains overwrite_lowerbound. It directly rewrites the final lowest allowed bound.",
        ),
        (
            "golden_reference_overwrite_upperbound",
            payload.get("golden_reference_defaults", {}).get("overwrite_upperbound"),
            "Optional numeric default used when the global method contains overwrite_upperbound. It directly rewrites the final highest allowed bound.",
        ),
        (
            "golden_reference_continuous_interval",
            payload.get("golden_reference_defaults", {}).get("continuous_interval", False),
            "True makes the final allowed result use one continuous interval by taking the minimum lower bound and maximum upper bound across all resulting ranges.",
        ),
        (
            "golden_empty_range_fallback_to_absolute",
            payload.get("golden_reference_defaults", {}).get(
                "empty_range_fallback_to_absolute",
                False,
            ),
            "True means Build Golden falls back to absolute lower/upper bounds when an AND/overlap rule produces no allowed range, and records a warning.",
        ),
        (
            "numeric_cleanup_enabled",
            payload.get("numeric_cleanup", {}).get("enabled", False),
            "Enable numeric text cleanup before parsing float values",
        ),
        (
            "numeric_cleanup_mode",
            payload.get("numeric_cleanup", {}).get("mode", "all_non_numeric"),
            "all_non_numeric / specified_chars",
        ),
        (
            "numeric_cleanup_characters",
            ";".join(payload.get("numeric_cleanup", {}).get("characters", [])),
            "Use ';' for multiple values. Example: ,;%;mV;ohm",
        ),
    ]
    notes = {
        "initial_column_merge_fail_rule": "第一阶段列合并。any_fail：任一子项失败就失败；all_fail：全部子项失败才失败。",
        "final_column_merge_fail_rule": "最终列汇总到选定的 Chain 层级。any_fail：任一子组失败；all_fail：全部子组失败。",
        "initial_row_merge_fail_rule": "第一阶段行合并。any_fail：任一子项失败就失败；all_fail：全部子项失败才失败。",
        "final_row_merge_fail_rule": "最终行汇总到可靠性节点。any_fail：任一子组失败；all_fail：全部子组失败。",
        "initial_row_merge_level": "行合并后保留到哪一层，默认节点层级。只合并下方层级；必须等于或低于节点。填写 row_dimensions 的 Name。",
        "initial_column_merge_level": "列合并后保留到哪一层，默认 Chain 的下一层；Chain 已在最底层时默认同层。只合并下方层级。填写 column_header_levels 的 Name。",
        "outlier_merge_order": "四步执行顺序。每个方向的 Initial 必须早于 Final，可选六种顺序。Final 行目标固定为节点，Final 列目标固定为 Chain。",
    }
    renames = {old: new for new, old in MERGE_RULE_FIELDS.items()}
    renames.update({"outlier_row_merge_max_dimension": "initial_row_merge_level", "outlier_test_merge_max_level": "initial_column_merge_level"})
    refreshed_rows = [info_rows[0], ("schema_version", TEMPLATE_SCHEMA_VERSION, "模板格式版本，由程序维护。")]
    for key, value, note in info_rows[1:]:
        if key == "node_order":
            continue
        key = renames.get(key, key)
        if key in notes:
            value = payload["report"].get(key)
            note = notes[key]
        refreshed_rows.append((key, value, note))
    refreshed_rows.append(("chain_column_level", payload["report"].get("chain_column_level"), "哪一列层级代表 Chain。填写 column_header_levels 的 Name，Final column merge 固定保留到此层，不能另设最终目标。"))
    info_rows = refreshed_rows
    _write_sheet_rows(info_sheet, info_rows, wrap_columns={1, 2, 3})
    _style_header_row(info_sheet, fill_color="1F4E78", font_color="FFFFFF")
    info_sheet.freeze_panes = "A2"
    info_sheet.column_dimensions["A"].width = 28
    info_sheet.column_dimensions["B"].width = 32
    info_sheet.column_dimensions["C"].width = 42

    row_dimensions_sheet = workbook.create_sheet(TEMPLATE_WORKBOOK_SHEETS["row_dimensions"])
    max_source_delimiters = max(
        1,
        max(
            (
                len(source.get("split_delimiters", []))
                for item in payload.get("row_dimensions", [])
                for source in item.get("sources", [])
            ),
            default=0,
        ),
    )
    row_dimensions_rows = [
        tuple(
            [
                "Name",
                "Display Name",
                "Priority",
                "Optional",
                "Default Value",
                "Source Order",
                "Source Column",
                "Default Split Position",
                "Split Position By Column",
                "Match Value",
                "Mapped Split Position",
                "Skip Empty Parts",
                *_indexed_headers("delimiter", max_source_delimiters),
            ]
        )
    ]
    for item in payload.get("row_dimensions", []):
        sources = item.get("sources", []) or [{}]
        for source_index, source in enumerate(sources, start=1):
            split_map = source.get("split_position_map", {})
            mapping_rows = sorted(
                split_map.items(),
                key=lambda item: (str(item[0]).lower(), str(item[0])),
            ) or [(None, None)]
            for match_value, mapped_position in mapping_rows:
                row_dimensions_rows.append(
                    tuple(
                        [
                            item["name"],
                            item.get("display_name"),
                            item.get("priority"),
                            item.get("optional", False),
                            item.get("default_value"),
                            source_index,
                            source.get("column"),
                            source.get("default_split_position", source.get("split_position")),
                            source.get("split_position_by_column"),
                            match_value,
                            mapped_position,
                            source.get("skip_empty_parts", False),
                            *_pad_list(source.get("split_delimiters", []), max_source_delimiters),
                        ]
                    )
                )
    _write_sheet_rows(row_dimensions_sheet, row_dimensions_rows)
    _style_header_row(row_dimensions_sheet, fill_color="2F75B5", font_color="FFFFFF")
    row_dimensions_sheet.freeze_panes = "A2"
    _set_sheet_widths(
        row_dimensions_sheet,
        _merge_width_maps(
            {
                "A": 24,
                "B": 24,
                "C": 10,
                "D": 12,
                "E": 18,
                "F": 14,
                "G": 28,
                "H": 14,
                "I": 24,
                "J": 18,
                "K": 18,
                "L": 16,
            },
            _indexed_widths(start_column=13, count=max_source_delimiters, width=14),
        ),
    )

    column_header_levels_sheet = workbook.create_sheet(TEMPLATE_WORKBOOK_SHEETS["column_header_levels"])
    column_header_level_rows = [
        ("Name", "Priority"),
    ]
    for item in payload.get("column_header_levels", []):
        column_header_level_rows.append((item.get("name"), item.get("priority")))
    _write_sheet_rows(column_header_levels_sheet, column_header_level_rows)
    _style_header_row(column_header_levels_sheet, fill_color="4F81BD", font_color="FFFFFF")
    column_header_levels_sheet.freeze_panes = "A2"
    _set_sheet_widths(
        column_header_levels_sheet,
        {
            "A": 24,
            "B": 12,
        },
    )

    analysis_groups_sheet = workbook.create_sheet(TEMPLATE_WORKBOOK_SHEETS["analysis_groups"])
    column_header_levels = [
        item.get("name")
        for item in payload.get("column_header_levels", [])
        if item.get("name")
    ] or ["Header Level 1"]
    analysis_group_rows = [
        (
            "ID",
            "Display Name",
            "Analysis Mode",
            "Unit",
            "Outlier Golden Method",
            "Golden Relative Limit",
            "Golden Sigma Multiplier",
            "Golden Lower Bound",
            "Golden Upper Bound",
            "Golden Overwrite Lower Bound",
            "Golden Overwrite Upper Bound",
            "Golden Continuous Interval",
            "Golden Empty Range Fallback To Absolute",
            "Column Order",
            "Column Name",
            *column_header_levels,
        )
    ]
    for item in payload.get("analysis_groups", []):
        group_columns = item.get("columns", []) or [{}]
        for index, column_item in enumerate(group_columns, start=1):
            analysis_group_rows.append(
                (
                    item["id"],
                    item.get("display_name"),
                    item["analysis_mode"],
                    item.get("unit"),
                    item.get("outlier_golden_method"),
                    item.get("golden_relative_limit"),
                    item.get("golden_sigma_multiplier"),
                    item.get("golden_absolute_lower_bound"),
                    item.get("golden_absolute_upper_bound"),
                    item.get("golden_overwrite_lowerbound"),
                    item.get("golden_overwrite_upperbound"),
                    item.get("golden_continuous_interval"),
                    item.get("golden_empty_range_fallback_to_absolute"),
                    column_item.get("column_order", index),
                    column_item.get("name"),
                    *_pad_list(column_item.get("header_values", []), len(column_header_levels)),
                )
            )
    _write_sheet_rows(analysis_groups_sheet, analysis_group_rows)
    _style_header_row(analysis_groups_sheet, fill_color="5B9BD5", font_color="FFFFFF")
    analysis_groups_sheet.freeze_panes = "A2"
    _set_sheet_widths(
        analysis_groups_sheet,
        _merge_width_maps(
            {
                "A": 24,
                "B": 24,
                "C": 18,
                "D": 12,
                "E": 28,
                "F": 18,
                "G": 20,
                "H": 18,
                "I": 18,
                "J": 18,
                "K": 18,
                "L": 14,
                "M": 36,
            },
            _indexed_widths(start_column=14, count=len(column_header_levels), width=18),
        ),
    )

    node_orders_sheet = workbook.create_sheet(TEMPLATE_WORKBOOK_SHEETS["node_orders"])
    node_orders = _payload_node_orders(payload.get("report", {}))
    max_nodes = max(1, max((len(item) for item in node_orders), default=0))
    node_order_rows = [tuple(["Sequence Name", *_indexed_headers("node", max_nodes)])]
    for index, node_order in enumerate(node_orders, start=1):
        node_order_rows.append(
            tuple([f"Sequence {index}", *_pad_list(node_order, max_nodes)])
        )
    if len(node_order_rows) == 1:
        node_order_rows.append(tuple(["Sequence 1", *_pad_list([], max_nodes)]))
    _write_sheet_rows(node_orders_sheet, node_order_rows)
    _style_header_row(node_orders_sheet, fill_color="8064A2", font_color="FFFFFF")
    node_orders_sheet.freeze_panes = "A2"
    _set_sheet_widths(
        node_orders_sheet,
        _merge_width_maps(
            {"A": 20},
            _indexed_widths(start_column=2, count=max_nodes, width=18),
        ),
    )

    analysis_dimension_filters_sheet = workbook.create_sheet(
        TEMPLATE_WORKBOOK_SHEETS["analysis_dimension_filters"]
    )
    analysis_dimension_filter_rows = [
        ("Mode", "Dimension", "Value Order", "Value")
    ]
    for mode_name in ("include", "exclude"):
        for field_name, values in payload.get("report", {}).get(
            "analysis_dimension_filters", {}
        ).get(mode_name, {}).items():
            for index, value in enumerate(values, start=1):
                analysis_dimension_filter_rows.append(
                    (mode_name, field_name, index, value)
                )
    if len(analysis_dimension_filter_rows) == 1:
        analysis_dimension_filter_rows.append(("", "", "", ""))
    _write_sheet_rows(analysis_dimension_filters_sheet, analysis_dimension_filter_rows)
    _style_header_row(
        analysis_dimension_filters_sheet,
        fill_color="5B9BD5",
        font_color="FFFFFF",
    )
    analysis_dimension_filters_sheet.freeze_panes = "A2"
    _set_sheet_widths(
        analysis_dimension_filters_sheet,
        {"A": 14, "B": 22, "C": 12, "D": 36},
    )

    analysis_column_filters_sheet = workbook.create_sheet(
        TEMPLATE_WORKBOOK_SHEETS["analysis_column_filters"]
    )
    analysis_column_filter_rows = [
        ("Mode", "Field", "Value Order", "Value")
    ]
    for mode_name in ("include", "exclude"):
        for field_name, values in payload.get("report", {}).get(
            "analysis_column_filters", {}
        ).get(mode_name, {}).items():
            for index, value in enumerate(values, start=1):
                analysis_column_filter_rows.append(
                    (mode_name, field_name, index, value)
                )
    if len(analysis_column_filter_rows) == 1:
        analysis_column_filter_rows.append(("", "", "", ""))
    _write_sheet_rows(analysis_column_filters_sheet, analysis_column_filter_rows)
    _style_header_row(analysis_column_filters_sheet, fill_color="70AD47", font_color="FFFFFF")
    analysis_column_filters_sheet.freeze_panes = "A2"
    _set_sheet_widths(
        analysis_column_filters_sheet,
        {"A": 14, "B": 22, "C": 12, "D": 36},
    )

    ratio_stats_sheet = workbook.create_sheet(TEMPLATE_WORKBOOK_SHEETS["outlier_ratio_stats"])
    ratio_stat_rows = [
        (
            "ID",
            "Display Name",
            "Group By Dimension",
            "Numerator",
            "Filter Type",
            "Filter Order",
            "Filter Value",
        )
    ]
    for item in payload.get("report", {}).get("outlier_ratio_stats", []):
        filters: list[tuple[str, str]] = []
        filters.extend(("id", value) for value in item.get("group_ids", []))
        filters.extend(
            ("display_name", value) for value in item.get("group_display_names", [])
        )
        filters.extend(("test_type", value) for value in item.get("test_types", []))
        filters.extend(("chain_name", value) for value in item.get("chain_names", []))
        filters.extend(("column_name", value) for value in item.get("column_names", []))
        filters.extend(("unit", value) for value in item.get("units", []))
        filters.extend(("chain", value) for value in item.get("chains", []))
        filters.extend(("raw_column", value) for value in item.get("raw_columns", []))
        filters.extend(("logical_metric", value) for value in item.get("logical_metrics", []))
        if not filters:
            filters = [("", "")]
        for index, (filter_type, filter_value) in enumerate(filters, start=1):
            ratio_stat_rows.append(
                (
                    item["id"],
                    item.get("display_name"),
                    ";".join(
                        item.get(
                            "group_by_dimensions",
                            [item.get("group_by_dimension", "reliability_node")],
                        )
                    ),
                    item.get("numerator", "new_outlier_samples"),
                    filter_type,
                    index,
                    filter_value,
                )
            )
    if len(ratio_stat_rows) == 1:
        ratio_stat_rows.append(
            ("", "", "", "", "", "", "")
        )
    _write_sheet_rows(ratio_stats_sheet, ratio_stat_rows)
    _style_header_row(ratio_stats_sheet, fill_color="A5A5A5", font_color="FFFFFF")
    ratio_stats_sheet.freeze_panes = "A2"
    _set_sheet_widths(
        ratio_stats_sheet,
        {"A": 24, "B": 28, "C": 22, "D": 24, "E": 16, "F": 14, "G": 36},
    )

    readme_sheet = workbook.create_sheet(TEMPLATE_WORKBOOK_SHEETS["readme"])
    readme_rows = [
        ("section", "content"),
        ("Purpose", "This workbook is an editable view of the JSON template."),
        ("Rows", "配置页第 1 行是中文填写说明，第 2 行是英文表头，第 3 行起填写。不要改英文表头。template_info 和 README 保持原布局。旧版第 1 行表头仍可读取，GUI 导入时会备份并升级。"),
        ("Lists", "Excel template writes one item per cell when possible. If one cell must contain multiple values, always use ';'. Complex examples: lot_id;sample_id, reliability_node;lot_id, reliability_node=T0;site_id=A;temp=25C."),
        ("Row Indexes", "test_data_header_row, row_header_row, unit_row, and test_data_start_row are zero-based. test_data_start_row must be filled explicitly."),
        (
            "Node Orders",
            "Use node_orders sheet for multiple node sequences; one node per cell.",
        ),
        (
            "Thresholds",
            "Default zscore threshold is edited in template_info. Built golden defaults and per-analysis-group rules control golden deviation behavior.",
        ),
        (
            "Sample Primary Key",
            "Set sample_dimension_names in template_info to one or more row dimension names joined by ';'. Complex example: lot_id;sample_id",
        ),
        (
            "Numeric Cleanup",
            "Use numeric_cleanup_enabled and related fields in template_info when input numeric cells may contain units or extra characters. Complex example for numeric_cleanup_characters: ,;%;mV;ohm",
        ),
        (
            "Empty Test Cell Fail Handling",
            "template_info.outlier_treat_empty_cells_as_fail controls whether an expected test cell that is blank or non-numeric after numeric cleanup is treated as a raw outlier failure. Empty cells never participate in golden calculation.",
        ),
        (
            "Dynamic Split Position",
            "In row_dimensions, use Split Position By Column + Match Value + Mapped Split Position to choose split position from another column value.",
        ),
        (
            "Outlier Ratio Stats",
            "Use outlier_ratio_stats sheet to define ratio rows for Outlier Summary. Excel multi-value cells use ';'. Complex examples: group_by_dimensions=reliability_node;lot_id, group_by_dimension=Chain Name. Filters can use id=link4_voltage, display_name=Link4 Voltage, test_type=Voltage, chain_name=Link4, column_name=V_Link4_1A, unit=V. group_by_dimensions can use reliability_node, higher-priority row dimensions, or column header levels; lower row dimensions should be filtered instead.",
        ),
        (
            "Analyze Test Filters",
            "GUI Analyze tab supports Tests / Exclude Tests as analysis-start column filters. Use semicolon-separated field=value1,value2 entries. Supported fields come from column_header_levels plus analysis_groups metadata like id, display_name, raw_column(column_name), logical_metric, and unit.",
        ),
        (
            "Merged Test Fail Rule",
            "template_info.outlier_merged_test_fail_rule works across leaf columns inside one merged test pool. any_fail = any leaf test fails; all_fail = all leaf tests fail.",
        ),
        (
            "Test Group Fail Rule",
            "template_info.outlier_test_group_fail_rule then aggregates higher column levels above outlier_test_merge_max_level upward until the top-level test group is decided. any_fail = any child group fails; all_fail = all child groups fail.",
        ),
        (
            "Merged Sample Fail Rule",
            "First fix the higher row dimensions outside the pool, then look at all raw rows inside one merged row pool. any_fail = any raw row fails; all_fail = all raw rows fail.",
        ),
        (
            "Node Fail Rule",
            "Then fix sample + reliability_node and combine the merged row pools under that node. any_fail = any pool fails; all_fail = all pools fail.",
        ),
        (
            "Merge Order",
            "template_info.outlier_merge_order chooses how the four modules run: column merge, column group, row merge, row node. Pick one of the six supported execution orders.",
        ),
    ]
    readme_replacements = {
        "Merged Test Fail Rule": "initial_column_merge_fail_rule：第一阶段列合并的判据。初次合并只处理 initial_column_merge_level 下方的层级，保留该层及其上方分组。",
        "Test Group Fail Rule": "final_column_merge_fail_rule：最终列汇总判据。最终保留到 chain_column_level 指定的 Chain 层级，不允许另设 Final 层级。",
        "Merged Sample Fail Rule": "initial_row_merge_fail_rule：第一阶段行合并的判据。初次合并只处理 initial_row_merge_level 下方的维度，保留该层及其上方分组。",
        "Node Fail Rule": "final_row_merge_fail_rule：最终行汇总判据。最终保留到 reliability_node_dimension 指定的节点，批次、样品及节点仍分别保留。",
        "Merge Order": "Initial column merge / Final column merge / Initial row merge / Final row merge。每个方向 Initial 在 Final 前，可交错执行。any_fail 表示任一子项失败，all_fail 表示所有子项失败。顺序可能影响结果。",
    }
    readme_titles = {
        "Merged Test Fail Rule": "Initial column merge",
        "Test Group Fail Rule": "Final column merge",
        "Merged Sample Fail Rule": "Initial row merge",
        "Node Fail Rule": "Final row merge",
    }
    readme_rows = [(readme_titles.get(key, key), readme_replacements.get(key, value)) for key, value in readme_rows]
    _write_sheet_rows(readme_sheet, readme_rows, wrap_columns={2})
    _style_header_row(readme_sheet, fill_color="7F7F7F", font_color="FFFFFF")
    readme_sheet.freeze_panes = "A2"
    _set_sheet_widths(readme_sheet, {"A": 18, "B": 80})
    for cell in readme_sheet[1]:
        cell.font = Font(bold=True)
    _write_tsk_workbook_sheets(workbook, payload)
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if cell.row > 1 and isinstance(cell.value, str) and "\n" in cell.value:
                    cell.alignment = Alignment(wrap_text=True, vertical="top")
        if sheet.title in SHEET_COLUMN_GUIDANCE:
            _add_column_guidance_row(sheet)
    workbook.save(path)


def _load_template_info_sheet(workbook) -> dict[str, Any]:
    sheet_name = TEMPLATE_WORKBOOK_SHEETS["info"]
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"Template workbook is missing required sheet: {sheet_name}")
    sheet = workbook[sheet_name]
    rows = list(sheet.iter_rows(values_only=True))
    if not rows:
        raise ValueError(f"Sheet {sheet_name} is empty.")
    header = [_normalize_header(item) for item in rows[0]]
    if "field" not in header or "value" not in header:
        raise ValueError(
            f"Sheet {sheet_name} must contain 'field' and 'value' headers."
        )
    field_index = header.index("field")
    value_index = header.index("value")
    values: dict[str, Any] = {}
    for row in rows[1:]:
        field = _clean_cell(row[field_index] if field_index < len(row) else None)
        if not field:
            continue
        values[field] = row[value_index] if value_index < len(row) else None

    values = FieldLookup(values)
    for forbidden in ("final_row_merge_level", "final_column_merge_level"):
        if values.get(forbidden) not in {None, ""}:
            raise ValueError(f"{forbidden} is read-only; select reliability_node_dimension / chain_column_level instead.")

    return {
        "schema_version": _parse_int_value(values.get("schema_version", 1), field_name="schema_version"),
        "chain_column_level": _parse_optional_string(values.get("chain_column_level"), default=None),
        "initial_column_merge_level": _parse_optional_string(values.get("initial_column_merge_level"), default=None),
        "initial_row_merge_level": _parse_optional_string(values.get("initial_row_merge_level"), default=None),
        "name": _require_string(values, "name", sheet_name),
        "test_data_header_row": _parse_int_value(
            values.get("test_data_header_row", values.get("test_header_row")),
            field_name="test_data_header_row",
        ),
        "row_header_row": _parse_int_value(
            values.get("row_header_row"), field_name="row_header_row"
        ),
        "test_data_start_column": _parse_optional_int_value(
            values.get("test_data_start_column", values.get("test_start_column"))
        ),
        "unit_row": _parse_optional_int_value(values.get("unit_row")),
        "test_data_start_row": _parse_optional_int_value(
            values.get("test_data_start_row", values.get("data_start_row"))
        ),
        "node_order": _parse_list_cell(values.get("node_order")),
        "reliability_node_dimension": _parse_optional_string(
            values.get("reliability_node_dimension"), default="reliability_node"
        ),
        "sample_dimension_names": (
            _parse_semicolon_list(values.get("sample_dimension_names"))
            or _parse_semicolon_list(values.get("sample_dimension_name"))
        ),
        "report_default_zscore_threshold": _coalesce_optional_float(
            values.get("report_default_zscore_threshold"),
            3.5,
        ),
        "outlier_fail_method": _parse_optional_string(
            values.get("outlier_fail_method"), default="modified_z_score"
        ),
        "outlier_merged_test_fail_rule": _resolve_report_rule_value(
            values,
            "outlier_merged_test_fail_rule",
            default="any_fail",
            legacy_field_names=("outlier_test_fail_rule",),
        ),
        "outlier_test_group_fail_rule": _resolve_report_rule_value(
            values,
            "outlier_test_group_fail_rule",
            default="any_fail",
            legacy_field_names=("outlier_test_fail_rule",),
        ),
        "outlier_merged_sample_fail_rule": _resolve_report_rule_value(
            values,
            "outlier_merged_sample_fail_rule",
            default="any_fail",
            legacy_field_names=("outlier_sample_fail_rule",),
        ),
        "outlier_node_fail_rule": _resolve_report_rule_value(
            values,
            "outlier_node_fail_rule",
            default="any_fail",
        ),
        "outlier_row_merge_max_dimension": _parse_optional_string(
            values.get("outlier_row_merge_max_dimension"),
            default=None,
        ),
        "outlier_test_merge_max_level": _parse_optional_string(
            values.get("outlier_test_merge_max_level"),
            default=None,
        ),
        "outlier_merge_order": _parse_optional_string(
            values.get("outlier_merge_order"),
            default=OUTLIER_MERGE_ORDER_OPTIONS[0],
        ),
        "outlier_treat_empty_cells_as_fail": _coerce_bool_value(
            values.get("outlier_treat_empty_cells_as_fail", True)
        ),
        "golden_reference_dimensions": _parse_semicolon_list(
            values.get("golden_reference_dimensions")
        ),
        "golden_reference_filters": _parse_filter_cell(
            values.get("golden_reference_filters")
        ),
        "golden_center_method": _parse_optional_string(
            values.get("golden_reference_center_method"),
            default="mean"
        ),
        "golden_outlier_golden_method": _parse_optional_string(
            values.get("golden_reference_outlier_golden_method"),
            default="relative"
        ),
        "golden_relative_limit": _parse_optional_float_value(
            values.get("golden_reference_relative_limit")
        ),
        "golden_sigma_multiplier": _parse_optional_float_value(
            values.get("golden_reference_sigma_multiplier")
        ),
        "golden_absolute_lower_bound": _parse_optional_float_value(
            values.get("golden_reference_absolute_lower_bound")
        ),
        "golden_absolute_upper_bound": _parse_optional_float_value(
            values.get("golden_reference_absolute_upper_bound")
        ),
        "golden_overwrite_lowerbound": _parse_optional_float_value(
            values.get(
                "golden_reference_overwrite_lowerbound",
                values.get(
                    "golden_reference_overwrite_lower_bound",
                    values.get("golden_reference_overwrite_min"),
                ),
            )
        ),
        "golden_overwrite_upperbound": _parse_optional_float_value(
            values.get(
                "golden_reference_overwrite_upperbound",
                values.get(
                    "golden_reference_overwrite_upper_bound",
                    values.get("golden_reference_overwrite_max"),
                ),
            )
        ),
        "golden_continuous_interval": (
            _coerce_bool_value(
                values.get("golden_reference_continuous_interval")
            )
            if values.get("golden_reference_continuous_interval") not in {None, ""}
            else False
        ),
        "golden_empty_range_fallback_to_absolute": (
            _coerce_bool_value(
                values.get("golden_empty_range_fallback_to_absolute")
            )
            if values.get("golden_empty_range_fallback_to_absolute") not in {None, ""}
            else False
        ),
        "numeric_cleanup_enabled": _coerce_bool_value(
            values.get("numeric_cleanup_enabled")
        ),
        "numeric_cleanup_mode": _parse_optional_string(
            values.get("numeric_cleanup_mode"),
            default="all_non_numeric",
        ),
        "numeric_cleanup_characters": _parse_semicolon_list(
            values.get("numeric_cleanup_characters")
        ),
    }


def _load_column_header_levels_sheet(workbook) -> list[dict[str, Any]]:
    rows = _load_rows_from_sheet(
        workbook,
        TEMPLATE_WORKBOOK_SHEETS["column_header_levels"],
        required_headers={"name", "priority"},
    )
    payload: list[dict[str, Any]] = []
    for row in rows:
        name = _clean_cell(row.get("name"))
        if not name:
            continue
        priority = _parse_int_value(row.get("priority"), field_name=f"{name}.priority")
        payload.append({"name": name, "priority": priority})
    return payload


def _load_row_dimensions_sheet(workbook) -> list[dict[str, Any]]:
    rows = _load_rows_from_sheet(
        workbook,
        TEMPLATE_WORKBOOK_SHEETS["row_dimensions"],
        required_headers={
            "name",
            "display_name",
            "priority",
            "optional",
            "default_value",
            "source_order",
            "source_column",
            "default_split_position",
            "split_position_by_column",
            "match_value",
            "mapped_split_position",
            "skip_empty_parts",
        },
    )
    grouped_rows: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        name = _clean_cell(row.get("name"))
        if not name:
            continue
        grouped_rows.setdefault(name, []).append(row)

    payload: list[dict[str, Any]] = []
    for name, dimension_rows in grouped_rows.items():
        sorted_rows = sorted(
            dimension_rows,
            key=lambda item: (
                _parse_optional_int_value(item.get("source_order")) or 10**9,
                _natural_text_sort_key(_clean_cell(item.get("source_column"))),
            ),
        )
        item: dict[str, Any] = {
            "name": name,
            "priority": _parse_int_value(
                _first_non_empty(dimension_rows, "priority"),
                field_name=f"{name}.priority",
            ),
            "sources": [],
        }
        display_name = _first_non_empty(dimension_rows, "display_name")
        if display_name:
            item["display_name"] = display_name
        if _coalesce_bool(dimension_rows, "optional"):
            item["optional"] = True
        default_value = _first_non_empty(dimension_rows, "default_value")
        if default_value:
            item["default_value"] = default_value

        for row in sorted_rows:
            source_column = _clean_cell(row.get("source_column"))
            if not source_column:
                continue
            source_order = _parse_optional_int_value(row.get("source_order")) or 10**9
            source_key = (source_order, source_column)
            source_payload = next(
                (
                    existing
                    for existing in item["sources"]
                    if existing.get("_source_key") == source_key
                ),
                None,
            )
            if source_payload is None:
                source_payload = {
                    "column": source_column,
                    "_source_key": source_key,
                }
                item["sources"].append(source_payload)
            split_position = _parse_optional_int_value(
                row.get("default_split_position")
            )
            if split_position is None:
                split_position = _parse_optional_int_value(row.get("split_position"))
            if split_position is not None:
                source_payload["split_position"] = split_position
            if _parse_bool_value(row.get("skip_empty_parts")):
                source_payload["skip_empty_parts"] = True
            split_position_by_column = _clean_cell(row.get("split_position_by_column"))
            if split_position_by_column:
                source_payload["split_position_by_column"] = split_position_by_column
            match_value = _clean_cell(row.get("match_value"))
            mapped_split_position = _parse_optional_int_value(
                row.get("mapped_split_position")
            )
            if match_value and mapped_split_position is not None:
                source_payload.setdefault("split_position_map", {})[
                    match_value
                ] = mapped_split_position
            split_delimiters = _extract_list_values(
                row,
                single_cell_key="split_delimiters",
                indexed_prefix="delimiter_",
            )
            if split_delimiters:
                source_payload["split_delimiters"] = split_delimiters

        if not item["sources"]:
            raise ValueError(f"Row dimension {name} must define at least one source.")
        for source_payload in item["sources"]:
            source_payload.pop("_source_key", None)
        payload.append(item)
    return payload


def _load_analysis_groups_sheet(
    workbook,
    column_header_levels: list[str],
    *,
    analysis_group_conflict_mode: str = ANALYSIS_GROUP_CONFLICT_MODE_FIRST_NON_EMPTY,
) -> list[dict[str, Any]]:
    rows = _load_rows_from_sheet(
        workbook,
        TEMPLATE_WORKBOOK_SHEETS["analysis_groups"],
        required_headers={"id"},
    )
    if rows and "column_name" in rows[0]:
        return _load_analysis_groups_long_rows(
            rows,
            column_header_levels,
            analysis_group_conflict_mode=analysis_group_conflict_mode,
        )
    payload: list[dict[str, Any]] = []
    for row in rows:
        group_id = _clean_cell(row.get("id"))
        if not group_id:
            continue
        column_name = _clean_cell(row.get("column_name"))
        if not column_name:
            raise ValueError(f"Analysis group {group_id} must define at least one column.")
        item: dict[str, Any] = {
            "id": group_id,
            "display_name": _clean_cell(row.get("display_name")) or group_id,
            "analysis_mode": _require_clean_value(
                row.get("analysis_mode"),
                field_name=f"{group_id}.analysis_mode",
            ),
            "columns": [
                {
                    "name": column_name,
                    "column_order": _parse_optional_int_value(row.get("column_order")),
                    "header_values": [
                        _require_clean_value(
                            row.get(_normalize_header(level_name)),
                            field_name=f"{group_id}.{column_name}.{level_name}",
                        )
                        for level_name in column_header_levels
                    ],
                }
            ],
        }
        unit = _clean_cell(row.get("unit"))
        if unit:
            item["unit"] = unit
        outlier_golden_method = _clean_cell(row.get("outlier_golden_method"))
        if outlier_golden_method:
            item["outlier_golden_method"] = outlier_golden_method
        field_candidates = {
            "golden_relative_limit": ("golden_relative_limit",),
            "golden_sigma_multiplier": ("golden_sigma_multiplier",),
            "golden_absolute_lower_bound": (
                "golden_absolute_lower_bound",
                "golden_lower_bound",
            ),
            "golden_absolute_upper_bound": (
                "golden_absolute_upper_bound",
                "golden_upper_bound",
            ),
            "golden_overwrite_lowerbound": (
                "golden_overwrite_lowerbound",
                "golden_overwrite_lower_bound",
                "golden_overwrite_min",
                "overwrite_lowerbound",
                "overwrite_lower_bound",
                "overwrite_min",
            ),
            "golden_overwrite_upperbound": (
                "golden_overwrite_upperbound",
                "golden_overwrite_upper_bound",
                "golden_overwrite_max",
                "overwrite_upperbound",
                "overwrite_upper_bound",
                "overwrite_max",
            ),
        }
        for field_name, candidates in field_candidates.items():
            parsed = None
            for candidate in candidates:
                parsed = _parse_optional_float_value(row.get(candidate))
                if parsed is not None:
                    break
            if parsed is not None:
                item[field_name] = parsed
        continuous_interval_value = row.get("golden_continuous_interval", row.get("continuous_interval"))
        if continuous_interval_value not in {None, ""}:
            item["golden_continuous_interval"] = _coerce_bool_value(
                continuous_interval_value
            )
        fallback_value = row.get(
            "golden_empty_range_fallback_to_absolute",
            row.get("empty_range_fallback_to_absolute"),
        )
        if fallback_value not in {None, ""}:
            item["golden_empty_range_fallback_to_absolute"] = _coerce_bool_value(
                fallback_value
            )
        payload.append(item)
    return payload


def _load_analysis_groups_long_rows(
    rows: list[dict[str, Any]],
    column_header_levels: list[str],
    *,
    analysis_group_conflict_mode: str = ANALYSIS_GROUP_CONFLICT_MODE_FIRST_NON_EMPTY,
) -> list[dict[str, Any]]:
    conflicts = _detect_analysis_group_shared_field_conflicts(rows, column_header_levels)
    if (
        conflicts
        and _normalize_analysis_group_conflict_mode(analysis_group_conflict_mode)
        == ANALYSIS_GROUP_CONFLICT_MODE_ERROR
    ):
        raise ValueError(_format_analysis_group_conflict_message(conflicts))
    grouped_rows: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        group_id = _clean_cell(row.get("id"))
        if not group_id:
            continue
        grouped_rows.setdefault(group_id, []).append(row)

    payload: list[dict[str, Any]] = []
    for group_id, group_rows in grouped_rows.items():
        sorted_rows = sorted(
            group_rows,
            key=lambda item: (
                _parse_optional_int_value(item.get("column_order")) or 10**9,
                _natural_text_sort_key(_clean_cell(item.get("column_name"))),
            ),
        )
        display_name = _first_non_empty(group_rows, "display_name") or group_id
        analysis_mode = _require_clean_value(
            _first_non_empty(group_rows, "analysis_mode"),
            field_name=f"{group_id}.analysis_mode",
        )
        unit = _first_non_empty(group_rows, "unit")
        columns = []
        for row in sorted_rows:
            column_name = _clean_cell(row.get("column_name"))
            if not column_name:
                continue
            columns.append(
                {
                    "name": column_name,
                    "column_order": _parse_optional_int_value(row.get("column_order")),
                    "header_values": [
                        _require_clean_value(
                            row.get(_normalize_header(level_name)),
                            field_name=f"{group_id}.{column_name}.{level_name}",
                        )
                        for level_name in column_header_levels
                    ],
                }
            )
        if not columns:
            raise ValueError(f"Analysis group {group_id} must define at least one column.")
        item: dict[str, Any] = {
            "id": group_id,
            "display_name": display_name,
            "columns": columns,
            "analysis_mode": analysis_mode,
        }
        if unit:
            item["unit"] = unit
        outlier_golden_method = _first_non_empty(group_rows, "outlier_golden_method")
        if outlier_golden_method:
            item["outlier_golden_method"] = outlier_golden_method
        field_candidates = {
            "golden_relative_limit": ("golden_relative_limit",),
            "golden_sigma_multiplier": ("golden_sigma_multiplier",),
            "golden_absolute_lower_bound": (
                "golden_absolute_lower_bound",
                "golden_lower_bound",
            ),
            "golden_absolute_upper_bound": (
                "golden_absolute_upper_bound",
                "golden_upper_bound",
            ),
            "golden_overwrite_lowerbound": (
                "golden_overwrite_lowerbound",
                "golden_overwrite_lower_bound",
                "golden_overwrite_min",
                "overwrite_lowerbound",
                "overwrite_lower_bound",
                "overwrite_min",
            ),
            "golden_overwrite_upperbound": (
                "golden_overwrite_upperbound",
                "golden_overwrite_upper_bound",
                "golden_overwrite_max",
                "overwrite_upperbound",
                "overwrite_upper_bound",
                "overwrite_max",
            ),
        }
        for field_name, candidates in field_candidates.items():
            parsed = None
            for candidate in candidates:
                parsed = _parse_optional_float_value(
                    _first_non_empty(group_rows, candidate)
                )
                if parsed is not None:
                    break
            if parsed is not None:
                item[field_name] = parsed
        continuous_interval_raw = _first_non_empty(
            group_rows,
            "golden_continuous_interval",
        ) or _first_non_empty(group_rows, "continuous_interval")
        if continuous_interval_raw not in {None, ""}:
            item["golden_continuous_interval"] = _coerce_bool_value(
                continuous_interval_raw
            )
        fallback_raw = _first_non_empty(
            group_rows,
            "golden_empty_range_fallback_to_absolute",
        ) or _first_non_empty(group_rows, "empty_range_fallback_to_absolute")
        if fallback_raw not in {None, ""}:
            item["golden_empty_range_fallback_to_absolute"] = _coerce_bool_value(
                fallback_raw
            )
        payload.append(item)
    return payload


def _load_node_orders_sheet(workbook, fallback: list[str]) -> list[list[str]]:
    sheet_name = TEMPLATE_WORKBOOK_SHEETS["node_orders"]
    if sheet_name not in workbook.sheetnames:
        return [fallback] if fallback else []
    rows = _load_rows_from_sheet(
        workbook,
        sheet_name,
        required_headers={"sequence_name"},
    )
    payload: list[list[str]] = []
    for row in rows:
        nodes = _extract_list_values(row, single_cell_key="nodes", indexed_prefix="node_")
        if nodes:
            payload.append(nodes)
    return payload or ([fallback] if fallback else [])


def _load_analysis_column_filters_sheet(workbook) -> dict[str, dict[str, list[str]]]:
    sheet_name = TEMPLATE_WORKBOOK_SHEETS["analysis_column_filters"]
    if sheet_name not in workbook.sheetnames:
        return {}
    rows = _load_rows_from_sheet(
        workbook,
        sheet_name,
        required_headers={"mode", "field", "value"},
    )
    ordered_values: dict[tuple[str, str], list[tuple[int, str]]] = {}
    for row in rows:
        mode = _clean_cell(row.get("mode")).lower()
        field_name = _clean_cell(row.get("field"))
        value = _clean_cell(row.get("value"))
        if not mode or not field_name or not value:
            continue
        if mode not in {"include", "exclude"}:
            raise ValueError("analysis_column_filters.mode must be include or exclude.")
        order = _parse_optional_int_value(row.get("value_order"))
        ordered_values.setdefault((mode, field_name), []).append(
            (order if order is not None else 10**9, value)
        )

    payload: dict[str, dict[str, list[str]]] = {}
    for (mode, field_name), values in ordered_values.items():
        payload.setdefault(mode, {})[field_name] = [
            value
            for _sort_order, value in sorted(
                values,
                key=lambda item: (item[0], item[1]),
            )
        ]
    return payload


def _load_analysis_dimension_filters_sheet(workbook) -> dict[str, dict[str, list[str]]]:
    sheet_name = TEMPLATE_WORKBOOK_SHEETS["analysis_dimension_filters"]
    if sheet_name not in workbook.sheetnames:
        return {}
    rows = _load_rows_from_sheet(
        workbook,
        sheet_name,
        required_headers={"mode", "dimension", "value"},
    )
    ordered_values: dict[tuple[str, str], list[tuple[int, str]]] = {}
    for row in rows:
        mode = _clean_cell(row.get("mode")).lower()
        field_name = _clean_cell(row.get("dimension"))
        value = _clean_cell(row.get("value"))
        if not mode or not field_name or not value:
            continue
        if mode not in {"include", "exclude"}:
            raise ValueError(
                "analysis_dimension_filters.mode must be include or exclude."
            )
        order = _parse_optional_int_value(row.get("value_order"))
        ordered_values.setdefault((mode, field_name), []).append(
            (order if order is not None else 10**9, value)
        )

    payload: dict[str, dict[str, list[str]]] = {}
    for (mode, field_name), values in ordered_values.items():
        payload.setdefault(mode, {})[field_name] = [
            value
            for _sort_order, value in sorted(values, key=lambda item: (item[0], item[1]))
        ]
    return payload


def _load_outlier_ratio_stats_sheet(workbook) -> list[dict[str, Any]]:
    sheet_name = TEMPLATE_WORKBOOK_SHEETS["outlier_ratio_stats"]
    if sheet_name not in workbook.sheetnames:
        return []
    rows = _load_rows_from_sheet(
        workbook,
        sheet_name,
        required_headers={"id", "group_by_dimension", "numerator"},
    )
    grouped_rows: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        stat_id = _clean_cell(row.get("id"))
        if not stat_id:
            continue
        grouped_rows.setdefault(stat_id, []).append(row)

    payload: list[dict[str, Any]] = []
    for stat_id, stat_rows in grouped_rows.items():
        sorted_rows = sorted(
            stat_rows,
            key=lambda item: (
                _parse_optional_int_value(item.get("filter_order")) or 10**9,
                _natural_text_sort_key(_clean_cell(item.get("filter_value"))),
            ),
        )
        item: dict[str, Any] = {
            "id": stat_id,
            "display_name": _first_non_empty(stat_rows, "display_name") or stat_id,
            "group_by_dimensions": _parse_semicolon_list(
                _first_non_empty(stat_rows, "group_by_dimension")
            )
            or ["reliability_node"],
            "group_by_dimension": (
                _parse_semicolon_list(_first_non_empty(stat_rows, "group_by_dimension"))
                or ["reliability_node"]
            )[0],
            "numerator": _first_non_empty(stat_rows, "numerator") or "new_outlier_samples",
            "group_ids": [],
            "group_display_names": [],
            "test_types": [],
            "chain_names": [],
            "column_names": [],
            "units": [],
            "chains": [],
            "raw_columns": [],
            "logical_metrics": [],
        }
        for row in sorted_rows:
            filter_type = FieldNames(("chain", "id", "display_name", "test_type", "chain_name",
                                      "column_name", "unit", "raw_column", "logical_metric"),
                                     (("group_id", "id"), ("group_display_name", "display_name"))).resolve(
                _clean_cell(row.get("filter_type")))
            filter_value = _clean_cell(row.get("filter_value"))
            if not filter_type or not filter_value:
                continue
            if filter_type == "chain":
                item["chains"].append(filter_value)
            elif filter_type == "id":
                item["group_ids"].append(filter_value)
            elif filter_type == "display_name":
                item["group_display_names"].append(filter_value)
            elif filter_type == "test_type":
                item["test_types"].append(filter_value)
            elif filter_type == "chain_name":
                item["chain_names"].append(filter_value)
            elif filter_type == "column_name":
                item["column_names"].append(filter_value)
            elif filter_type == "unit":
                item["units"].append(filter_value)
            elif filter_type == "raw_column":
                item["raw_columns"].append(filter_value)
            elif filter_type == "logical_metric":
                item["logical_metrics"].append(filter_value)
            else:
                raise ValueError(
                    f"Unsupported filter_type in {sheet_name}: {filter_type}. Expected id, display_name, test_type, chain_name, column_name, unit, chain, raw_column, or logical_metric."
                )
        payload.append(item)
    return payload


def _load_key_value_sheet(
    workbook,
    sheet_name: str,
    key_header: str,
    value_header: str,
    numeric_values: bool,
) -> dict[str, Any]:
    if sheet_name not in workbook.sheetnames:
        return {}
    rows = _load_rows_from_sheet(
        workbook,
        sheet_name,
        required_headers={key_header, value_header},
    )
    payload: dict[str, Any] = {}
    for row in rows:
        key = _clean_cell(row.get(key_header))
        if not key:
            continue
        raw_value = row.get(value_header)
        if numeric_values:
            payload[key] = _parse_float_value(raw_value, field_name=f"{sheet_name}.{key}")
        else:
            payload[key] = _clean_cell(raw_value)
    return payload


def _load_threshold_sheet(
    workbook,
    sheet_name: str,
    default_value: float,
) -> dict[str, Any]:
    if sheet_name not in workbook.sheetnames:
        return {"default": default_value, "overrides": {}}
    rows = _load_rows_from_sheet(
        workbook,
        sheet_name,
        required_headers={"metric_key", "value"},
    )
    payload: dict[str, Any] = {"default": default_value, "overrides": {}}
    for row in rows:
        metric_key = _clean_cell(row.get("metric_key"))
        if not metric_key:
            continue
        value = _parse_float_value(row.get("value"), field_name=f"{sheet_name}.{metric_key}")
        if metric_key == "default":
            payload["default"] = value
        else:
            payload["overrides"][metric_key] = value
    return payload


def _load_rows_from_sheet(
    workbook,
    sheet_name: str,
    required_headers: set[str],
) -> list[dict[str, Any]]:
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"Template workbook is missing required sheet: {sheet_name}")
    sheet = workbook[sheet_name]
    rows = list(sheet.iter_rows(values_only=True))
    if not rows:
        raise ValueError(f"Sheet {sheet_name} is empty.")
    header_index = 0
    header = [_normalize_header(item) for item in rows[header_index]]
    # v1/v2 put headers first; v3 adds a single explanatory row above them.
    # Explanatory prose must not be mistaken for the schema header row.
    recognized = set()
    for index, candidate in enumerate(rows[:2]):
        recognized = {_normalize_header(value) for value in candidate if str(value or "").isascii()}
        if {field_key(name) for name in required_headers}.issubset({field_key(name) for name in recognized}):
            header_index = index
            header = [_normalize_header(item) for item in candidate]
            break
    missing = [item for item in required_headers if field_key(item) not in {field_key(name) for name in recognized}]
    if missing:
        raise ValueError(
            f"Sheet {sheet_name} is missing required columns: {', '.join(sorted(missing))}"
        )
    payload_rows: list[dict[str, Any]] = []
    for sheet_row_number, row in enumerate(rows[header_index + 1:], start=header_index + 2):
        row_payload: dict[str, Any] = FieldLookup()
        for index, column_name in enumerate(header):
            if not column_name:
                continue
            row_payload[column_name] = row[index] if index < len(row) else None
        if any(_clean_cell(value) not in {"", None} for value in row_payload.values()):
            row_payload["_sheet_row_number"] = sheet_row_number
            payload_rows.append(row_payload)
    return payload_rows


def _add_column_guidance_row(sheet) -> None:
    from math import ceil
    from unicodedata import east_asian_width
    from openpyxl.styles import Alignment, Font, PatternFill

    headers = [cell.value for cell in sheet[1]]
    descriptions = column_guidance(sheet.title, headers)
    if sheet.title in {"analysis_groups", "node_orders"}:
        last_column = sheet.cell(1, len(headers)).column_letter
        sheet.column_dimensions[last_column].width = max(32, sheet.column_dimensions[last_column].width or 13)
    # insert_rows moves cells, but row dimensions need to be shifted explicitly.
    from copy import copy
    dimensions = {index: copy(value) for index, value in sheet.row_dimensions.items()}
    sheet.insert_rows(1)
    sheet.row_dimensions.clear()
    for index, value in dimensions.items():
        sheet.row_dimensions[index + 1] = value
        sheet.row_dimensions[index + 1].index = index + 1
    max_lines = 1
    for index, text in enumerate(descriptions, 1):
        cell = sheet.cell(1, index, text)
        cell.font = Font(name="Arial", size=10, color="334155")
        cell.fill = PatternFill("solid", fgColor="F1F5F9")
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        width = sheet.column_dimensions[cell.column_letter].width or 13
        units = sum(2 if east_asian_width(char) in {"W", "F"} else 1 for char in text)
        max_lines = max(max_lines, ceil(units / max(1, width - 2)))
    sheet.row_dimensions[1].height = max_lines * 15 + 12
    header_lines = 1
    for cell in sheet[2]:
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        width = sheet.column_dimensions[cell.column_letter].width or 13
        header_lines = max(header_lines, ceil(len(str(cell.value or "")) / max(1, width - 2)))
    sheet.row_dimensions[2].height = header_lines * 15 + 8
    sheet.freeze_panes = "A3"


def _write_sheet_rows(sheet, rows: list[tuple[Any, ...]], wrap_columns: set[int] | None = None) -> None:
    wrap_columns = wrap_columns or set()
    try:
        from openpyxl.styles import Alignment
    except ImportError:
        Alignment = None
    for row_index, row_values in enumerate(rows, start=1):
        for column_index, value in enumerate(row_values, start=1):
            cell = sheet.cell(row=row_index, column=column_index, value=value)
            if column_index in wrap_columns and Alignment is not None:
                cell.alignment = Alignment(wrap_text=True, vertical="top")


def _style_header_row(sheet, fill_color: str, font_color: str) -> None:
    try:
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        return
    fill = PatternFill(fill_type="solid", fgColor=fill_color)
    font = Font(color=font_color, bold=True)
    for cell in sheet[1]:
        cell.fill = fill
        cell.font = font


def _set_sheet_widths(sheet, widths: dict[str, float]) -> None:
    for column, width in widths.items():
        sheet.column_dimensions[column].width = width


def _normalize_header(value: Any) -> str:
    text = _clean_cell(value).lower()
    if not text:
        return ""
    return re.sub(r"[\W_]+", "_", text, flags=re.UNICODE).strip("_")


def _clean_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    return str(value).strip()


def _parse_list_cell(value: Any) -> list[str]:
    text = _clean_cell(value)
    if not text:
        return []
    normalized = text.replace("\r\n", "\n").replace(";", "\n").replace(",", "\n")
    return [item.strip() for item in normalized.split("\n") if item.strip()]


def _normalize_analysis_group_conflict_mode(value: str | None) -> str:
    normalized = str(value or "").strip().lower()
    if normalized not in ANALYSIS_GROUP_CONFLICT_MODES:
        raise ValueError(
            "analysis_group_conflict_mode must be one of: "
            + ", ".join(sorted(ANALYSIS_GROUP_CONFLICT_MODES))
        )
    return normalized


def _detect_analysis_group_shared_field_conflicts(
    rows: list[dict[str, Any]],
    column_header_levels: list[str],
) -> list[dict[str, Any]]:
    del column_header_levels
    grouped_rows: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        group_id = _clean_cell(row.get("id"))
        if not group_id:
            continue
        grouped_rows.setdefault(group_id, []).append(row)

    conflicts: list[dict[str, Any]] = []
    for group_id, group_rows in grouped_rows.items():
        for field_name, candidates, label, value_type in ANALYSIS_GROUP_SHARED_FIELD_SPECS:
            occurrences = _collect_analysis_group_field_occurrences(
                group_rows,
                candidates,
                value_type=value_type,
            )
            unique_values = {
                occurrence["normalized_value"] for occurrence in occurrences
            }
            if len(unique_values) <= 1:
                continue
            conflicts.append(
                {
                    "group_id": group_id,
                    "field": field_name,
                    "label": label,
                    "selected_value": _resolve_first_non_empty_group_field_value(
                        group_rows,
                        candidates,
                    ),
                    "occurrences": [
                        {
                            "row_number": occurrence["row_number"],
                            "source_field": occurrence["source_field"],
                            "value": occurrence["value"],
                        }
                        for occurrence in occurrences
                    ],
                }
            )
    return conflicts


def _collect_analysis_group_field_occurrences(
    rows: list[dict[str, Any]],
    candidates: tuple[str, ...],
    *,
    value_type: str,
) -> list[dict[str, Any]]:
    occurrences: list[dict[str, Any]] = []
    for row in rows:
        row_number = int(row.get("_sheet_row_number", 0) or 0)
        for candidate in candidates:
            value = row.get(candidate)
            normalized_value = _normalize_analysis_group_field_value(
                value,
                value_type=value_type,
            )
            if normalized_value is None:
                continue
            occurrences.append(
                {
                    "row_number": row_number,
                    "source_field": candidate,
                    "value": normalized_value,
                    "normalized_value": normalized_value,
                }
            )
            break
    return occurrences


def _normalize_analysis_group_field_value(value: Any, *, value_type: str) -> str | None:
    if value_type == "float":
        parsed = _parse_optional_float_value(value)
        if parsed is None:
            return None
        return f"{parsed:g}"
    cleaned = _clean_cell(value)
    return cleaned or None


def _resolve_first_non_empty_group_field_value(
    rows: list[dict[str, Any]],
    candidates: tuple[str, ...],
) -> str:
    for candidate in candidates:
        value = _first_non_empty(rows, candidate)
        if value:
            return value
    return ""


def _format_analysis_group_conflict_message(conflicts: list[dict[str, Any]]) -> str:
    lines = [
        "analysis_groups sheet contains conflicting shared-field values under the same id.",
        "Fix the template so each shared field is consistent within one id, or force the current first-non-empty behavior.",
    ]
    for conflict in conflicts:
        group_id = str(conflict["group_id"])
        label = str(conflict["label"])
        selected_value = str(conflict.get("selected_value", ""))
        details = ", ".join(
            f"row {item['row_number']} ({item['source_field']})={item['value']}"
            for item in conflict.get("occurrences", [])
        )
        lines.append(
            f"- id '{group_id}' field '{label}' has conflicting values: {details}. "
            f"Current first-non-empty selection would use '{selected_value}'."
        )
    return "\n".join(lines)


def _parse_semicolon_list(value: Any) -> list[str]:
    text = _clean_cell(value)
    if not text:
        return []
    return [item.strip() for item in re.split(r"[;\n\r]+", text) if item.strip()]


def _format_filters_cell(filters: dict[str, str]) -> str:
    return "; ".join(
        f"{key}={value}" for key, value in filters.items() if str(key).strip()
    )


def _parse_filter_cell(value: Any) -> dict[str, str]:
    text = _clean_cell(value)
    if not text:
        return {}
    parts = re.split(r"[;\n\r]+", text)
    filters: dict[str, str] = {}
    for item in parts:
        entry = item.strip()
        if not entry:
            continue
        if "=" not in entry:
            raise ValueError(
                "golden_reference_filters must use key=value pairs separated by ';'."
            )
        key, raw_value = entry.split("=", 1)
        normalized_key = key.strip()
        normalized_value = raw_value.strip()
        if normalized_key in filters:
            merged_values = [
                item.strip()
                for item in filters[normalized_key].split(",")
                if item.strip()
            ]
            for value_item in (
                item.strip() for item in normalized_value.split(",") if item.strip()
            ):
                if value_item not in merged_values:
                    merged_values.append(value_item)
            filters[normalized_key] = ",".join(merged_values)
        else:
            filters[normalized_key] = normalized_value
    return filters


def _parse_bool_value(value: Any) -> bool:
    text = _clean_cell(value).lower()
    if not text:
        return False
    if text in {"1", "true", "yes", "y"}:
        return True
    if text in {"0", "false", "no", "n"}:
        return False
    raise ValueError(f"Invalid boolean value: {value}")


def _coerce_bool_value(value: Any) -> bool:
    if value is None or _clean_cell(value) == "":
        return False
    return _parse_bool_value(value)


def _parse_optional_string(value: Any, default: str) -> str:
    text = _clean_cell(value)
    return text or default


def _parse_int_value(value: Any, field_name: str) -> int:
    if value is None or _clean_cell(value) == "":
        raise ValueError(f"{field_name} is required.")
    return int(float(value))


def _parse_optional_int_value(value: Any) -> int | None:
    if value is None or _clean_cell(value) == "":
        return None
    return int(float(value))


def _parse_float_value(value: Any, field_name: str) -> float:
    if value is None or _clean_cell(value) == "":
        raise ValueError(f"{field_name} is required.")
    return float(value)


def _parse_optional_float_value(value: Any) -> float | None:
    if value is None or _clean_cell(value) == "":
        return None
    return float(value)


def _coalesce_optional_float(value: Any, default: float) -> float:
    parsed = _parse_optional_float_value(value)
    if parsed is None:
        return default
    return parsed


def _require_string(values: dict[str, Any], field_name: str, sheet_name: str) -> str:
    value = _clean_cell(values.get(field_name))
    if not value:
        raise ValueError(f"Sheet {sheet_name} requires a value for {field_name}.")
    return value


def _require_clean_value(value: Any, field_name: str) -> str:
    text = _clean_cell(value)
    if not text:
        raise ValueError(f"{field_name} is required.")
    return text


def _serialize_number(value: float) -> int | float:
    numeric = float(value)
    if numeric.is_integer():
        return int(numeric)
    return numeric


def _effective_node_orders(report: ReportConfig) -> list[list[str]]:
    if report.node_orders:
        return [list(item) for item in report.node_orders if item]
    if report.node_order:
        return [list(report.node_order)]
    return []


def _payload_node_orders(report_payload: dict[str, Any]) -> list[list[str]]:
    if "node_orders" in report_payload:
        return [
            [str(node).strip() for node in item if str(node).strip()]
            for item in report_payload.get("node_orders", [])
            if item
        ]
    primary = _primary_node_order(report_payload)
    return [primary] if primary else []


def _primary_node_order(report_payload: dict[str, Any]) -> list[str]:
    if "node_orders" in report_payload and report_payload.get("node_orders"):
        first = report_payload["node_orders"][0]
        return [str(node).strip() for node in first if str(node).strip()]
    return [str(node).strip() for node in report_payload.get("node_order", []) if str(node).strip()]


def _validate_node_order_consistency(node_orders: list[list[str]]) -> None:
    seen_pairs: dict[tuple[str, str], int] = {}
    for sequence_index, node_order in enumerate(node_orders, start=1):
        for left_index, left_node in enumerate(node_order):
            for right_node in node_order[left_index + 1 :]:
                reverse_key = (right_node, left_node)
                if reverse_key in seen_pairs:
                    other_sequence_index = seen_pairs[reverse_key]
                    raise ValueError(
                        "report.node_orders contains conflicting node directions: "
                        f"sequence {other_sequence_index} requires {right_node} before {left_node}, "
                        f"but sequence {sequence_index} requires {left_node} before {right_node}."
                    )
                seen_pairs[(left_node, right_node)] = sequence_index


def _indexed_headers(prefix: str, count: int) -> list[str]:
    label = prefix.replace("_", " ").title()
    return [f"{label} {index}" for index in range(1, count + 1)]


def _pad_list(values: list[Any], count: int) -> list[Any]:
    padded = list(values[:count])
    while len(padded) < count:
        padded.append(None)
    return padded


def _merge_width_maps(*maps: dict[str, float]) -> dict[str, float]:
    merged: dict[str, float] = {}
    for item in maps:
        merged.update(item)
    return merged


def _indexed_widths(start_column: int, count: int, width: float) -> dict[str, float]:
    return {
        _column_letter_from_index(start_column + offset): width
        for offset in range(count)
    }


def _column_letter_from_index(index: int) -> str:
    letters: list[str] = []
    value = index
    while value > 0:
        value, remainder = divmod(value - 1, 26)
        letters.append(chr(65 + remainder))
    return "".join(reversed(letters))


def _extract_list_values(
    row: dict[str, Any],
    single_cell_key: str,
    indexed_prefix: str,
) -> list[str]:
    indexed_values = [
        (key, value)
        for key, value in row.items()
        if key.startswith(indexed_prefix)
    ]
    if indexed_values:
        return [
            _clean_cell(value)
            for key, value in sorted(indexed_values, key=lambda item: _indexed_key_sort(item[0], indexed_prefix))
            if _clean_cell(value)
        ]
    return _parse_list_cell(row.get(single_cell_key))


def _indexed_key_sort(key: str, prefix: str) -> int:
    suffix = key[len(prefix) :]
    if suffix.isdigit():
        return int(suffix)
    return 10**9


def _first_non_empty(rows: list[dict[str, Any]], key: str) -> str:
    for row in rows:
        value = _clean_cell(row.get(key))
        if value:
            return value
    return ""


def _coalesce_bool(rows: list[dict[str, Any]], key: str) -> bool:
    for row in rows:
        if _parse_bool_value(row.get(key)):
            return True
    return False


def _natural_text_sort_key(value: str) -> tuple[Any, ...]:
    return _split_natural_parts(value)


def _split_natural_parts(value: str) -> tuple[Any, ...]:
    parts = re.split(r"(\d+)", value or "")
    key: list[Any] = []
    for part in parts:
        if not part:
            continue
        if part.isdigit():
            key.append(int(part))
        else:
            key.append(part.lower())
    return tuple(key)
