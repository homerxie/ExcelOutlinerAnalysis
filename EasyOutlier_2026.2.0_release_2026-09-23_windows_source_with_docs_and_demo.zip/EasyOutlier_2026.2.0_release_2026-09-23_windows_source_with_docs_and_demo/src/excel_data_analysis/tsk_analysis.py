"""Independent-instance noisy-OR inference from chain Fail/Pass counts.

The observations must already represent the intended physical or operational
failure event.  This module does not turn an outlier flag or a missing value into
a failure.  Confidence intervals assume independent observations; correlations
between chains measured on the same die are not accounted for here.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import math
from numbers import Integral, Real
from typing import Any, Callable, Sequence

import numpy as np
from scipy.optimize import brentq, linprog, minimize
from scipy.special import expit
from scipy.stats import beta, chi2


@dataclass(slots=True)
class TskInstance:
    chain_id: str
    instance_id: str
    tsk_id: str
    x: float | None = None
    y: float | None = None
    features: dict[str, float] = field(default_factory=dict)


@dataclass(slots=True)
class TskChainObservation:
    chain_id: str
    n_tested: int
    n_failed: int


@dataclass(slots=True)
class TskAnalysisOptions:
    use_xy: bool = False
    feature_names: tuple[str, ...] = ()
    confidence_level: float = 0.95


@dataclass(slots=True)
class TskTypeEstimate:
    tsk_id: str
    probability: float | None
    ci_lower: float | None
    ci_upper: float | None
    identifiable: bool
    status: str
    instance_count: int
    test_exposure: int
    interval_method: str | None = None


@dataclass(slots=True)
class TskChainEstimate:
    chain_id: str
    n_tested: int
    n_failed: int
    observed_probability: float | None
    predicted_probability: float | None
    residual: float | None
    deviance_residual: float | None
    status: str = "ok"


@dataclass(slots=True)
class TskAnalysisResult:
    types: list[TskTypeEstimate]
    chains: list[TskChainEstimate]
    diagnostics: dict[str, Any]
    options: TskAnalysisOptions

    def to_dict(self) -> dict[str, Any]:
        """Return strict-JSON-compatible values, including failed fit results."""
        return _plain(asdict(self))


def _plain(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    if isinstance(value, np.generic):
        return _plain(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _name(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be a nonempty string.")
    return value.strip()


def _numeric(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
        raise ValueError(f"{label} must be a finite number.")
    return float(value)


def _rank_identifiable(matrix: np.ndarray) -> tuple[int, np.ndarray]:
    """A coefficient is structurally identified iff every null vector is zero there."""
    width = matrix.shape[1]
    if not width:
        return 0, np.ones(0, dtype=bool)
    if not matrix.size:
        return 0, np.zeros(width, dtype=bool)
    # Avoid allocating a chains-by-chains U matrix for tall count matrices.
    _, singular, vh = np.linalg.svd(matrix, full_matrices=matrix.shape[0] < width)
    tolerance = max(matrix.shape) * np.finfo(float).eps * singular[0] * 100
    rank = int(np.sum(singular > tolerance))
    null_space = vh[rank:]
    identified = np.ones(width, dtype=bool) if rank == width else np.linalg.norm(null_space, axis=0) < 1e-7
    return rank, identified


def _loss_and_slope(hazard: np.ndarray, n: np.ndarray, k: np.ndarray) -> tuple[float, np.ndarray]:
    positive = k > 0
    if np.any(hazard[positive] <= 0):
        return math.inf, np.full_like(hazard, math.nan)
    value = float(np.dot(n - k, hazard))
    slope = (n - k).copy()
    # exp(-eta) / (1-exp(-eta)) is stable both near zero and for large eta.
    if np.any(positive):
        selected = hazard[positive]
        failed_probability = -np.expm1(-selected)
        value -= float(np.dot(k[positive], np.log(failed_probability)))
        slope[positive] -= k[positive] * np.exp(-selected) / failed_probability
    return value, slope


def _optimizer_converged(fit, sample_count: float, lower: float, upper: float = math.inf) -> bool:
    if not math.isfinite(fit.fun):
        return False
    # A successful termination based only on objective reduction is insufficient:
    # a line-search trial with zero probability for an observed Fail can leave
    # L-BFGS-B at its initial point while reporting success. Conversely it may
    # report a precision failure at a stationary optimum. Always verify the
    # bound-constrained first-order condition, normalized per observation.
    gradient = np.asarray(fit.jac).copy()
    gradient[(fit.x <= lower + 1e-10) & (gradient > 0)] = 0
    gradient[(fit.x >= upper - 1e-10) & (gradient < 0)] = 0
    return bool(np.all(np.isfinite(gradient)) and np.max(np.abs(gradient), initial=0) / max(sample_count, 1) < 1e-8)


def _minimize_bound_constrained(objective, initial, sample_count, lower, upper=math.inf, hessian=None):
    """Fit with an explicit stationarity check and an independent fallback.

    SLSQP uses a different line search from L-BFGS-B. Scaling its objective per
    observation avoids very large trial steps for large binomial counts. A
    fallback is accepted only if it also satisfies the projected-gradient test;
    otherwise the caller withholds the fit or interval instead of reporting a
    false optimum.
    """
    bounds = [(lower, None if math.isinf(upper) else upper)] * len(initial)
    options = {"ftol": 1e-12, "gtol": 1e-8, "maxiter": 1500, "maxls": 50}
    fit = minimize(objective, initial, jac=True, method="L-BFGS-B", bounds=bounds, options=options)
    if _optimizer_converged(fit, sample_count, lower, upper):
        return fit, True

    scale = max(float(sample_count), 1.)

    def scaled_objective(values):
        value, gradient = objective(values)
        return value / scale, gradient / scale

    start = fit.x if math.isfinite(fit.fun) and np.all(np.isfinite(fit.x)) else initial
    fallback = minimize(scaled_objective, start, jac=True, method="SLSQP", bounds=bounds,
                        options={"ftol": 1e-16, "maxiter": 1500})
    fallback.fun, fallback.jac = objective(fallback.x)
    if _optimizer_converged(fallback, sample_count, lower, upper):
        return fallback, True

    # SLSQP's objective-based stopping criterion can finish slightly before the
    # required stationarity tolerance; polish its improved feasible point.
    if math.isfinite(fallback.fun) and np.all(np.isfinite(fallback.x)):
        polished = minimize(objective, fallback.x, jac=True, method="L-BFGS-B", bounds=bounds,
                            options={**options, "ftol": 0.})
        if _optimizer_converged(polished, sample_count, lower, upper):
            return polished, True
        if math.isfinite(polished.fun) and polished.fun < fallback.fun:
            fallback = polished
    if math.isfinite(fallback.fun) and (not math.isfinite(fit.fun) or fallback.fun < fit.fun):
        fit = fallback
    if hessian is not None and math.isfinite(fit.fun):
        # Near a convex optimum, an objective reduction smaller than floating-
        # point resolution can still leave a detectable gradient. Exact Newton
        # corrections resolve it without weakening the convergence criterion.
        for _ in range(20):
            free = ~(((fit.x <= lower + 1e-10) & (fit.jac >= 0)) |
                     ((fit.x >= upper - 1e-10) & (fit.jac <= 0)))
            if not np.any(free):
                break
            curvature = hessian(fit.x)[np.ix_(free, free)]
            if not np.all(np.isfinite(curvature)):
                break
            direction = np.zeros_like(fit.x)
            try:
                direction[free] = np.linalg.lstsq(curvature, -fit.jac[free], rcond=None)[0]
            except np.linalg.LinAlgError:
                break
            if not np.all(np.isfinite(direction)) or fit.jac @ direction >= 0:
                break
            step = 1.
            negative, positive = direction < 0, direction > 0
            if np.any(negative):
                step = min(step, float(np.min((lower - fit.x[negative]) / direction[negative])))
            if math.isfinite(upper) and np.any(positive):
                step = min(step, float(np.min((upper - fit.x[positive]) / direction[positive])))
            if step <= 0:
                break
            for _ in range(50):
                candidate = np.clip(fit.x + step * direction, lower, upper)
                value, gradient = objective(candidate)
                roundoff = 8 * np.finfo(float).eps * max(abs(fit.fun), 1.)
                if math.isfinite(value) and value <= fit.fun + roundoff:
                    fit.x, fit.fun, fit.jac = candidate, value, gradient
                    break
                step *= .5
            else:
                break
            if _optimizer_converged(fit, sample_count, lower, upper):
                return fit, True
    return fit, False


class _BaselineModel:
    def __init__(self, counts: np.ndarray, n: np.ndarray, k: np.ndarray):
        self.counts, self.n, self.k = counts, n, k
        self.width = counts.shape[1]
        self.unbounded = (counts.T @ (n - k) == 0) & (counts.sum(axis=0) > 0)

    def fit(self, fixed: tuple[int, float] | None = None, start: np.ndarray | None = None):
        """Analytically saturate unconstrained hazards having no observed passes.

        A fixed value of +inf represents p=1 exactly, without multiplying zeros
        by infinity.  The remaining optimization has a finite nonnegative MLE.
        """
        width = self.width
        fixed_index, fixed_value = fixed if fixed is not None else (-1, 0.0)
        free = np.arange(width) != fixed_index
        infinite = self.unbounded & free
        if math.isinf(fixed_value):
            if np.any((self.counts[:, fixed_index] > 0) & (self.n > self.k)):
                return math.inf, np.zeros(width), np.zeros(len(self.n)), True
            infinite[fixed_index] = True
        saturated = np.any(self.counts[:, infinite] > 0, axis=1)
        selected = ~saturated
        finite = free & ~infinite
        matrix = self.counts[selected][:, finite]
        n, k = self.n[selected], self.k[selected]
        offset = np.zeros(len(n))
        if fixed_index >= 0 and not math.isinf(fixed_value):
            offset = self.counts[selected, fixed_index] * fixed_value
        # A profiled p=0 can make an observed failure impossible regardless of
        # the nuisance parameters. This is an infinite likelihood penalty, not
        # an optimizer convergence failure.
        if np.any((k > 0) & (offset == 0) & (matrix.sum(axis=1) == 0)):
            return math.inf, np.zeros(width), np.zeros(len(self.n)), True
        h = np.zeros(width)
        h[infinite] = math.inf
        if fixed_index >= 0:
            h[fixed_index] = fixed_value
        converged = True
        if finite.any():
            if np.any(k):
                initial_rate = min(max(float(k.sum() / max(n.sum(), 1)), 1e-5), 0.9)
                initial = np.full(int(finite.sum()), -math.log1p(-initial_rate) / max(float(matrix.sum(axis=1).mean()), 1))
                if start is not None:
                    candidate = start[finite]
                    if np.all(np.isfinite(candidate)):
                        initial = np.maximum(candidate, 1e-9)

                def objective(values):
                    value, slope = _loss_and_slope(offset + matrix @ values, n, k)
                    return value, matrix.T @ slope

                def hessian(values):
                    hazard = offset + matrix @ values
                    weight = np.zeros(len(n))
                    positive = k > 0
                    survival = np.exp(-hazard[positive])
                    failure = -np.expm1(-hazard[positive])
                    weight[positive] = k[positive] * survival / failure ** 2
                    return matrix.T @ (weight[:, None] * matrix)

                fit, converged = _minimize_bound_constrained(objective, initial, float(n.sum()), 0., hessian=hessian)
                h[finite] = fit.x
            # All selected rows pass: zero free hazards is the exact optimum.
        hazard = offset + matrix @ h[finite]
        value, _ = _loss_and_slope(hazard, n, k)
        predicted = np.ones(len(self.n))
        predicted[selected] = -np.expm1(-hazard)
        return value, h, predicted, converged

    def identifiability(self, h: np.ndarray) -> tuple[int, np.ndarray]:
        rank, _ = _rank_identifiable(self.counts)
        finite = ~self.unbounded
        selected = ~np.any(self.counts[:, self.unbounded] > 0, axis=1)
        effective = self.counts[selected][:, finite]
        _, identified_finite = _rank_identifiable(effective)
        identified = np.zeros(self.width, dtype=bool)
        identified[finite] = identified_finite
        # p=1 is forced only if at least one all-Fail chain has this type as its
        # sole unconstrained saturation mechanism. Otherwise any value can fit.
        unbounded_count = np.sum(self.counts[:, self.unbounded] > 0, axis=1)
        for index in np.flatnonzero(self.unbounded):
            identified[index] = bool(np.any((self.counts[:, index] > 0) & (unbounded_count == 1)))
        if finite.any():
            # With zero-failure rows, full design rank alone need not make the
            # realized likelihood strictly convex. Its exact flat directions
            # preserve the positive-failure hazards and the total pass exposure.
            n, k = self.n[selected], self.k[selected]
            dependence = np.vstack([effective[k > 0], (n - k) @ effective])
            dep_rank, _ = _rank_identifiable(dependence)
            if dep_rank < int(finite.sum()):
                nonzero = np.max(np.abs(dependence), axis=1) > 0
                equality = dependence[nonzero]
                equality = equality / np.max(np.abs(equality), axis=1)[:, None]
                target = equality @ h[finite]
                for local, index in enumerate(np.flatnonzero(finite)):
                    if not identified[index]:
                        continue
                    direction = np.zeros(effective.shape[1])
                    direction[local] = 1
                    low = linprog(direction, A_eq=equality, b_eq=target, bounds=(0, None), method="highs")
                    high = linprog(-direction, A_eq=equality, b_eq=target, bounds=(0, None), method="highs")
                    if not low.success or not high.success or -high.fun - low.fun > 1e-7:
                        identified[index] = False
        return rank, identified


class _FeatureModel:
    def __init__(self, counts, n, k, instances, chain_ids, type_ids, feature_names):
        self.counts, self.n, self.k = counts, n, k
        self.type_count = len(type_ids)
        type_index = {value: index for index, value in enumerate(type_ids)}
        chain_index = {value: index for index, value in enumerate(chain_ids)}
        self.chain_index = np.array([chain_index[row.chain_id] for row in instances], dtype=int)
        self.type_index = np.array([type_index[row.tsk_id] for row in instances], dtype=int)
        values = np.array([[row.x if name == "x" else row.y if name == "y" else row.features.get(name)
                            for name in feature_names] for row in instances], dtype=float)
        self.means = values.mean(axis=0)
        self.scales = values.std(axis=0)
        self.constant_features = [name for name, scale in zip(feature_names, self.scales) if scale <= 1e-12]
        self.scales[self.scales <= 1e-12] = 1
        standardized = (values - self.means) / self.scales
        self.design = np.column_stack([np.eye(self.type_count)[self.type_index], standardized])
        self.width = self.design.shape[1]
        self.feature_names = feature_names

    def evaluate(self, theta):
        logits = self.design @ theta
        probability = expit(logits)
        hazards = np.bincount(self.chain_index, weights=np.logaddexp(0, logits), minlength=len(self.n))
        derivative = np.zeros((len(self.n), self.width))
        np.add.at(derivative, self.chain_index, probability[:, None] * self.design)
        value, slope = _loss_and_slope(hazards, self.n, self.k)
        return value, derivative.T @ slope, -np.expm1(-hazards), derivative

    def fit(self, start=None, fixed=None, multistart=False):
        fixed_index, fixed_value = fixed if fixed is not None else (-1, 0.)
        free = np.arange(self.width) != fixed_index
        if start is None:
            rate = np.clip(self.k.sum() / max(self.n.sum(), 1), 1e-5, .95)
            component = -np.expm1(np.log1p(-rate) / max(self.counts.sum(axis=1).mean(), 1))
            start = np.zeros(self.width)
            start[:self.type_count] = math.log(component / (1 - component))
        starts = [start.copy()]
        if multistart:
            for sign in (-1, 1):
                other = start.copy()
                other[self.type_count:] += sign * .5
                starts.append(other)
        fits = []
        for initial in starts:
            if fixed_index >= 0:
                initial[fixed_index] = fixed_value

            def objective(values):
                theta = initial.copy()
                theta[free] = values
                value, gradient, _, _ = self.evaluate(theta)
                return value, gradient[free]

            if free.any():
                fit, converged = _minimize_bound_constrained(objective, initial[free], float(self.n.sum()), -35., 35.)
                theta = initial.copy()
                theta[free] = fit.x
                fits.append((float(fit.fun), theta, converged))
            else:
                fits.append((self.evaluate(initial)[0], initial, True))
        value, theta, converged = min(fits, key=lambda row: row[0])
        _, _, predicted, derivative = self.evaluate(theta)
        return value, theta, predicted, converged and math.isfinite(value), derivative


def _profile_interval(estimate: float, objective, minimum: float, confidence: float,
                      lower: float, upper: float) -> tuple[float, float]:
    threshold = minimum + float(chi2.ppf(confidence, 1)) / 2

    def root(value):
        return objective(value) - threshold

    low = lower if root(lower) <= 0 else brentq(root, lower, estimate, xtol=1e-9)
    high = upper if root(upper) <= 0 else brentq(root, estimate, upper, xtol=1e-9)
    return float(low), float(high)


def _binomial_interval(n: int, k: int, confidence: float) -> tuple[float, float]:
    tail = (1 - confidence) / 2
    return (0. if k == 0 else float(beta.ppf(tail, k, n - k + 1)),
            1. if k == n else float(beta.ppf(1 - tail, k + 1, n - k)))


def _deviance(n: int, k: int, q: float) -> float | None:
    observed = k / n
    if (q == 0 and k > 0) or (q == 1 and k < n):
        return None
    value = 0.
    if k:
        value += k * math.log(observed / q)
    if k < n:
        value += (n - k) * math.log((1 - observed) / (1 - q))
    return math.copysign(math.sqrt(max(2 * value, 0.)), observed - q) if value else 0.


def analyze_tsk(
    instances: Sequence[TskInstance],
    observations: Sequence[TskChainObservation],
    options: TskAnalysisOptions | None = None,
    progress_callback: Callable[[int, str], None] | None = None,
) -> TskAnalysisResult:
    """Estimate instance-type risk from one homogeneous condition/node group.

    ``residual`` is observed minus predicted chain probability. With features,
    type bars represent the conditional probability at the mean of each input
    feature over the measured layout instances (not a mean predicted risk).
    ``instance_id`` must be unique within its chain. Repeated TSK types are
    counted separately. Missing and invalid tests must be excluded from n.
    """
    options = options or TskAnalysisOptions()
    if not 0 < options.confidence_level < 1:
        raise ValueError("confidence_level must be strictly between 0 and 1.")
    feature_names = list(dict.fromkeys((["x", "y"] if options.use_xy else []) + list(options.feature_names)))
    for name in feature_names:
        _name(name, "Feature name")
    progress = progress_callback or (lambda *_: None)
    progress(0, "Validating TSK composition and chain observations")
    normalized = []
    seen = set()
    for instance in instances:
        chain_id = _name(instance.chain_id, "chain_id")
        instance_id = _name(instance.instance_id, "instance_id")
        tsk_id = _name(instance.tsk_id, "tsk_id")
        key = (chain_id, instance_id)
        if key in seen:
            raise ValueError(f"Duplicate physical instance {instance_id!r} in chain {chain_id!r}.")
        seen.add(key)
        normalized.append(TskInstance(chain_id, instance_id, tsk_id, instance.x, instance.y, dict(instance.features)))
    if not normalized:
        raise ValueError("TSK composition is empty.")
    composition_chains = {row.chain_id for row in normalized}
    observation_map = {}
    for row in observations:
        chain_id = _name(row.chain_id, "chain_id")
        if chain_id in observation_map:
            raise ValueError(f"Duplicate observation for chain {chain_id!r}; aggregate one condition/node before fitting.")
        if chain_id not in composition_chains:
            raise ValueError(f"Chain {chain_id!r} has observations but no TSK composition.")
        if any(isinstance(value, bool) or not isinstance(value, Integral) for value in (row.n_tested, row.n_failed)):
            raise ValueError(f"Counts for chain {chain_id!r} must be integers.")
        if not 0 <= row.n_failed <= row.n_tested:
            raise ValueError(f"Chain {chain_id!r} requires 0 <= n_failed <= n_tested.")
        observation_map[chain_id] = TskChainObservation(chain_id, int(row.n_tested), int(row.n_failed))
    chain_ids = sorted(key for key, row in observation_map.items() if row.n_tested > 0)
    if not chain_ids:
        raise ValueError("No chain has a positive number of valid tested samples.")
    active_chain_ids = set(chain_ids)
    active_instances = [row for row in normalized if row.chain_id in active_chain_ids]
    for row in active_instances:
        for name in feature_names:
            value = row.x if name == "x" else row.y if name == "y" else row.features.get(name)
            _numeric(value, f"{row.chain_id}/{row.instance_id}: {name}")
    type_ids = sorted({row.tsk_id for row in active_instances})
    all_type_ids = sorted({row.tsk_id for row in normalized})
    chain_lookup = {name: index for index, name in enumerate(chain_ids)}
    type_lookup = {name: index for index, name in enumerate(type_ids)}
    counts = np.zeros((len(chain_ids), len(type_ids)))
    for row in active_instances:
        counts[chain_lookup[row.chain_id], type_lookup[row.tsk_id]] += 1
    n = np.array([observation_map[name].n_tested for name in chain_ids], dtype=float)
    k = np.array([observation_map[name].n_failed for name in chain_ids], dtype=float)
    warnings = ["Intervals assume independent chain observations; shared die/wafer effects are not included."]
    unused_chains = composition_chains - set(chain_ids)
    if unused_chains:
        warnings.append(f"{len(unused_chains)} composition chains have no valid tested samples and were excluded.")
    diagnostics = {
        "warnings": warnings, "confidence_level": options.confidence_level,
        "interval_method": "profile_likelihood_approximate_with_exact_boundary_special_cases",
        "reference_environment": "Common type probability within the selected condition/node; no feature effects.",
        "model": "type_only", "parameter_count": len(type_ids), "chain_count": len(chain_ids),
        "failure_definition": "Caller-supplied Fail event; missing tests must be excluded from the denominator.",
    }
    progress(10, "Fitting chain failure probabilities")
    if feature_names:
        model = _FeatureModel(counts, n, k, active_instances, chain_ids, type_ids, feature_names)
        minimum, coefficients, predicted, converged, derivative = model.fit(multistart=True)
        rank, identified_all = _rank_identifiable(derivative)
        _, design_identified = _rank_identifiable(model.design)
        identified = identified_all[:len(type_ids)] & design_identified[:len(type_ids)]
        clipped = bool(np.any(np.abs(coefficients) >= 34.9))
        if clipped:
            identified[:] = False
            warnings.append("Feature coefficients reached numerical bounds; a finite, stable logistic fit was not established.")
        if model.constant_features:
            warnings.append("Constant feature columns: " + ", ".join(model.constant_features))
        probabilities = expit(coefficients[:len(type_ids)])
        diagnostics.update({
            "model": "instance_logistic_features", "parameter_count": model.width,
            "reference_environment": "Conditional type probability with every feature fixed at its training-layout mean; not an average over instance probabilities.",
            "feature_scaling": {name: {"mean": float(mean), "scale": float(scale)} for name, mean, scale in zip(feature_names, model.means, model.scales)},
            "feature_coefficients": {name: float(value) for name, value in zip(feature_names, coefficients[len(type_ids):])},
            "interval_method": "profile_likelihood_approximate_conditional_mean_environment",
            "optimization": "Three deterministic starting points; global optimality is not guaranteed.",
        })
    else:
        model = _BaselineModel(counts, n, k)
        minimum, coefficients, predicted, converged = model.fit()
        rank, identified = model.identifiability(coefficients)
        probabilities = -np.expm1(-coefficients)
    diagnostics.update({"converged": bool(converged), "rank": rank, "negative_log_likelihood": float(minimum)})
    if not converged:
        identified[:] = False
        warnings.append("The optimizer did not converge; type estimates and intervals are withheld.")
    if rank < diagnostics["parameter_count"]:
        warnings.append("The model is rank deficient; affected type probabilities cannot be independently identified.")
    if not np.all(identified):
        warnings.append("Unidentifiable type estimates are withheld; chain predictions can remain identifiable.")
    progress(35, "Computing type probability intervals")
    type_rows = []
    for position, type_id in enumerate(all_type_ids):
        instance_count = sum(row.tsk_id == type_id for row in normalized)
        if type_id not in type_lookup:
            type_rows.append(TskTypeEstimate(type_id, None, None, None, False, "no_data", instance_count, 0))
            continue
        index = type_lookup[type_id]
        exposure = int(np.dot(n, counts[:, index]))
        if not identified[index]:
            type_rows.append(TskTypeEstimate(type_id, None, None, None, False,
                                             "unidentifiable" if converged else "fit_not_converged", instance_count, exposure))
            progress(35 + int(60 * (position + 1) / len(all_type_ids)), f"TSK {type_id}: not independently identifiable")
            continue
        estimate = float(probabilities[index])
        method = "profile_likelihood_approximate"
        status = "boundary" if estimate <= 1e-9 or estimate >= 1 - 1e-9 else "ok"
        pure = (counts[:, index] > 0) & (np.count_nonzero(counts, axis=1) == 1)
        exact_boundary_subset = bool(np.any(pure) and (
            (estimate <= 1e-9 and not np.any(k[pure])) or
            (estimate >= 1 - 1e-9 and np.all(k[pure] == n[pure]))))
        try:
            if not feature_names and len(type_ids) == 1 and np.all(counts[:, 0] == counts[0, 0]):
                lo_q, hi_q = _binomial_interval(int(n.sum()), int(k.sum()), options.confidence_level)
                copies = counts[0, 0]
                low = -math.expm1(math.log1p(-lo_q) / copies) if lo_q < 1 else 1.
                high = -math.expm1(math.log1p(-hi_q) / copies) if hi_q < 1 else 1.
                method = "exact_binomial_transformed"
            elif not feature_names and not np.any(k):
                low, high = 0., -math.expm1(math.log(1 - options.confidence_level) / exposure)
                method = "exact_one_sided_zero_failure_upper_bound"
            elif not feature_names and exact_boundary_subset:
                # A directly observed pure-type subset supplies a conservative
                # exact one-sided boundary bound, without nuisance estimation.
                alpha = 1 - options.confidence_level
                if estimate <= 1e-9:
                    low, high = 0., -math.expm1(math.log(alpha) / float(n[pure] @ counts[pure, index]))
                    method = "exact_one_sided_zero_failure_upper_bound_pure_type_subset"
                else:
                    def all_fail_log_probability(value):
                        if value == 0:
                            return -math.inf
                        if value == 1:
                            return 0.
                        q = -np.expm1(counts[pure, index] * math.log1p(-value))
                        return float(n[pure] @ np.log(q))
                    low = brentq(lambda value: all_fail_log_probability(value) - math.log(alpha), 0., 1.)
                    high = 1.
                    method = "exact_one_sided_all_failure_lower_bound_pure_type_subset"
            elif feature_names:
                def objective(value):
                    result = model.fit(start=coefficients, fixed=(index, value))
                    if not result[3]:
                        raise RuntimeError("Profile nuisance optimization did not converge.")
                    if result[0] < minimum - max(1e-5, abs(minimum) * 1e-8):
                        raise RuntimeError("Profile found a better logistic optimum; an interval around the original fit is not reliable.")
                    return result[0]
                low_logit, high_logit = _profile_interval(float(coefficients[index]), objective, minimum,
                                                        options.confidence_level, -35., 35.)
                low, high = float(expit(low_logit)), float(expit(high_logit))
                if low_logit == -35.:
                    low = 0.
                if high_logit == 35.:
                    high = 1.
                method = "profile_likelihood_approximate_conditional_mean_environment"
            else:
                def objective(value):
                    hazard = -math.log1p(-value) if value < 1 else math.inf
                    result = model.fit(fixed=(index, hazard), start=coefficients)
                    if not result[3]:
                        raise RuntimeError("Profile nuisance optimization did not converge.")
                    return result[0]
                low, high = _profile_interval(estimate, objective, minimum, options.confidence_level, 0., 1.)
                if status == "boundary":
                    method = "profile_likelihood_approximate_boundary"
        except (RuntimeError, ValueError, FloatingPointError) as error:
            low = high = None
            status = "interval_unavailable"
            method = None
            warnings.append(f"TSK {type_id}: confidence interval unavailable ({error}).")
        type_rows.append(TskTypeEstimate(type_id, estimate, low, high, True, status, instance_count, exposure, method))
        progress(35 + int(60 * (position + 1) / len(all_type_ids)), f"Computed interval for TSK {type_id}")
    chain_rows = []
    for chain_id, observation in sorted(observation_map.items()):
        tested, failed = observation.n_tested, observation.n_failed
        if not tested:
            chain_rows.append(TskChainEstimate(chain_id, tested, failed, None, None, None, None, "no_data"))
            continue
        observed = failed / tested
        prediction = float(predicted[chain_lookup[chain_id]])
        chain_rows.append(TskChainEstimate(chain_id, tested, failed, observed, prediction, observed - prediction,
                                          _deviance(tested, failed, prediction), "ok" if converged else "fit_not_converged"))
    diagnostics["deviance"] = sum(row.deviance_residual ** 2 for row in chain_rows if row.deviance_residual is not None)
    diagnostics["identifiable_type_count"] = sum(row.identifiable for row in type_rows)
    progress(100, "TSK analysis complete")
    return TskAnalysisResult(type_rows, chain_rows, _plain(diagnostics), options)
