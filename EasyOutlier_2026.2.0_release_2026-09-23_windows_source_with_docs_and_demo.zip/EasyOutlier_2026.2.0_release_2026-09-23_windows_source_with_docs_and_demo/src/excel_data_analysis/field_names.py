"""Resolve user-entered field references without changing declared names or values."""
from __future__ import annotations

from collections import defaultdict
from functools import lru_cache
import re
import unicodedata


@lru_cache(maxsize=4096)
def field_key(value: str) -> str:
    # Preserve non-ASCII names and meaningful punctuation such as +, / and .
    text = unicodedata.normalize('NFKC', str(value)).strip().casefold()
    return re.sub(r'[\s_\-]+', '', text)


class FieldNames:
    def __init__(self, names, aliases=()):
        self.names = set(names)
        self.matches = defaultdict(set)
        for name in self.names:
            self.matches[field_key(name)].add(name)
        for alias, name in aliases:
            self.matches[field_key(alias)].add(name)

    def resolve(self, value, *, strict=False):
        text = str(value or '').strip()
        if text in self.names:
            return text
        matches = self.matches.get(field_key(text), set())
        if len(matches) > 1:
            raise ValueError(f"Ambiguous field name / 字段名存在歧义: {text!r}. "
                             f"Use an exact Name: {', '.join(sorted(matches))}.")
        if matches:
            return next(iter(matches))
        if strict:
            raise ValueError(f"Unsupported field / 不存在的字段: {text!r}. "
                             f"Available names: {', '.join(sorted(self.names))}.")
        return text

    def mapping(self, values):
        result = {}
        for key, value in values.items():
            canonical = self.resolve(key)
            if canonical in result and result[canonical] != value:
                raise ValueError(f"Conflicting values for field {canonical!r} after name normalization.")
            result[canonical] = value
        return result


def row_fields(template):
    return FieldNames((d.name for d in template.row_dimensions),
                      ((d.display_name, d.name) for d in template.row_dimensions if d.display_name))


COLUMN_FILTER_ALIASES = {
    'id': 'id', 'display_name': 'display_name', 'raw_column': 'raw_column',
    'logical_metric': 'logical_metric', 'unit': 'unit',
    'group_id': 'id', 'group_display_name': 'display_name', 'column_name': 'raw_column',
}


def column_filter_fields(template):
    return FieldNames(
        ['id', 'display_name', 'raw_column', 'logical_metric', 'unit',
         *(level.name for level in template.column_header_levels)],
        COLUMN_FILTER_ALIASES.items(),
    )


def normalize_template_references(template):
    """Canonicalize references once at configuration boundaries, before analysis."""
    rows = row_fields(template)
    columns = FieldNames(level.name for level in template.column_header_levels)
    report = template.report
    for field in ('reliability_node_dimension', 'initial_row_merge_level', 'outlier_row_merge_max_dimension'):
        value = getattr(report, field)
        if value:
            setattr(report, field, rows.resolve(value))
    for field in ('chain_column_level', 'initial_column_merge_level', 'outlier_test_merge_max_level'):
        value = getattr(report, field)
        if value:
            setattr(report, field, columns.resolve(value))
    report.sample_dimension_names = [rows.resolve(value) for value in report.sample_dimension_names]
    grouped = FieldNames([*(d.name for d in template.row_dimensions),
                          *(level.name for level in template.column_header_levels)],
                         ((d.display_name, d.name) for d in template.row_dimensions if d.display_name))
    for stat in report.outlier_ratio_stats:
        stat.group_by_dimension = grouped.resolve(stat.group_by_dimension)
        stat.group_by_dimensions = [grouped.resolve(value) for value in stat.group_by_dimensions]
    golden = template.golden_reference_defaults
    golden.reference_dimensions = [rows.resolve(value) for value in golden.reference_dimensions]
    golden.filters = rows.mapping(golden.filters)


class FieldLookup(dict):
    """Read template dictionaries using the shared field spelling rules.

    Iteration preserves the original keys, so IDs, filter values and declared
    dimension names are not rewritten. Used only while decoding configuration.
    """
    def __missing__(self, key):
        if not isinstance(key, str):
            raise KeyError(key)
        canonical = FieldNames(self).resolve(key)
        if dict.__contains__(self, canonical):
            return dict.__getitem__(self, canonical)
        raise KeyError(key)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default

    def __contains__(self, key):
        try:
            self[key]
            return True
        except KeyError:
            return False


def configuration_fields(value):
    if isinstance(value, dict):
        return FieldLookup({key: configuration_fields(item) for key, item in value.items()})
    if isinstance(value, list):
        return [configuration_fields(item) for item in value]
    return value
