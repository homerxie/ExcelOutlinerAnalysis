"""Regenerate the explicitly synthetic TSK example with a fixed random seed."""
from __future__ import annotations

import csv
import math
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from excel_data_analysis.models import (  # noqa: E402
    AnalysisColumn, AnalysisGroup, ColumnHeaderLevel, ReportConfig, RowDimension,
    RowDimensionSource, TemplateConfig, ThresholdConfig, TSKAnalysisConfig, TSKInstance,
)
from excel_data_analysis.template import save_template  # noqa: E402


SEED = 20260922
SAMPLE_COUNT = 400
TYPE_HAZARDS = {"TSK_A": 0.006, "TSK_B": 0.012, "TSK_C": 0.021}
TYPE_COUNTS = [
    (1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0),
    (1, 0, 1), (0, 1, 1), (2, 1, 0), (0, 2, 1),
    (1, 0, 2), (2, 2, 1), (1, 2, 2), (3, 1, 2),
]


def build_demo(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    random_source = random.Random(SEED)
    chains = [f"Chain_{index:02d}" for index in range(1, len(TYPE_COUNTS) + 1)]
    topology = []
    for chain_index, (chain, counts) in enumerate(zip(chains, TYPE_COUNTS)):
        for type_index, (tsk_id, count) in enumerate(zip(TYPE_HAZARDS, counts)):
            for occurrence in range(count):
                # Deliberately varied positions; identical designs use different
                # physical instances, even when labels occur in another chain.
                x = round(random_source.uniform(-1200, 1200), 3)
                y = round(random_source.uniform(-1200, 1200), 3)
                topology.append(TSKInstance(
                    chain_id=chain, tsk_instance_id=f"{chain}_{tsk_id}_{occurrence + 1}",
                    tsk_id=tsk_id, x=x, y=y, chain_key=["DemoDesign", chain],
                ))
    template = TemplateConfig(
        name="SYNTHETIC_TSK_DEMO_NOT_REAL_TOPOLOGY", schema_version=3,
        test_data_header_row=0, row_header_row=0, test_data_start_row=1,
        column_header_levels=[ColumnHeaderLevel("Design", 1), ColumnHeaderLevel("Chain Name", 2), ColumnHeaderLevel("Test Type", 3)],
        row_dimensions=[
            RowDimension("lot_id", [RowDimensionSource("Lot")], 1),
            RowDimension("sample_id", [RowDimensionSource("Sample")], 2),
            RowDimension("reliability_node", [RowDimensionSource("Node")], 3),
            RowDimension("repeat_id", [RowDimensionSource("Repeat")], 4),
        ],
        analysis_groups=[AnalysisGroup(
            id=chain, display_name=chain, analysis_mode="per_column", unit="Ohm",
            columns=[AnalysisColumn(f"R_{chain}", ["DemoDesign", chain, "Resistance"], 1)],
        ) for chain in chains],
        report=ReportConfig(
            zscore_thresholds=ThresholdConfig(3.5), node_orders=[["T0", "T1"]],
            sample_dimension_names=["lot_id", "sample_id"],
            reliability_node_dimension="reliability_node", chain_column_level="Chain Name",
            initial_row_merge_level="repeat_id", initial_column_merge_level="Test Type",
            outlier_fail_method="modified_z_score", outlier_treat_empty_cells_as_fail=False,
        ),
        tsk_analysis=TSKAnalysisConfig(
            enabled=True, use_xy=False, coordinate_unit="um",
            group_by_dimensions=["lot_id"], instances=topology,
        ),
    )
    save_template(template, directory / "template.json")
    save_template(template, directory / "template.xlsx")
    instances_by_chain = {chain: [item for item in topology if item.chain_id == chain] for chain in chains}
    fail_counts = {(node, chain): 0 for node in ("T0", "T1") for chain in chains}
    with (directory / "data.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["Lot", "Sample", "Node", "Repeat", *(f"R_{chain}" for chain in chains)])
        for sample in range(1, SAMPLE_COUNT + 1):
            uniforms = {item.tsk_instance_id: random_source.random() for item in topology}
            for node, multiplier in (("T0", 1.0), ("T1", 1.8)):
                measurements = []
                for chain in chains:
                    failed = False
                    for instance in instances_by_chain[chain]:
                        hazard = TYPE_HAZARDS[instance.tsk_id] * multiplier * math.exp(0.30 * instance.x / 1000 - 0.20 * instance.y / 1000)
                        failed |= uniforms[instance.tsk_instance_id] < -math.expm1(-hazard)
                    fail_counts[node, chain] += int(failed)
                    # Uniform small noise keeps every healthy cell well within
                    # modified-z 3.5; deliberately injected failures are 1000.
                    measurements.append(round((1000 if failed else 100) + random_source.uniform(-1, 1), 6))
                writer.writerow(["SYNTHETIC_LOT", f"S{sample:04d}", node, "1", *measurements])
    with (directory / "expected_chain_counts.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["Lot", "Node", "CHAIN_ID", "n", "k"])
        for (node, chain), count in fail_counts.items():
            writer.writerow(["SYNTHETIC_LOT", node, chain, SAMPLE_COUNT, count])


if __name__ == "__main__":
    build_demo(Path(__file__).resolve().parent)
