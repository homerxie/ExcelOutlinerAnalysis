# TSK 风险反推示例

这里的拓扑、坐标、测量值和失效概率全部为假设数据，用于演示及回归测试。它们不代表任何真实芯片、版图或 TSK 的可靠性。

1. 在软件中选择 `template.json` 或等价的 `template.xlsx`。
2. 将 `data.csv` 导入一个新的测试数据库。
3. 打开独立的 TSK 分析页运行。无需先执行 Analyze，也不需要 Golden 文件。
4. 默认只拟合 TSK 类型；勾选考虑 XY 后，可使用实例坐标拟合位置影响。每个可靠性节点独立拟合。

数据包含 400 个唯一样品、T0/T1 两个节点、12 条 Chain 和 3 种 TSK 类型。各 Chain 包含不同的 TSK 数量，`TSK_A/B/C` 是设计类型，`TSK_instance_ID` 是各链中的不同物理实例。同链重复的设计类型必须逐行保留。所有 Chain 的完整键为 `["DemoDesign", "Chain_XX"]`，不能省掉 Design 后将不同设计的同名链混为一条。

测量值为约 100 Ohm 的正常值和约 1000 Ohm 的注入失效值，叠加 [-1, 1] 内的随机噪声。模板使用 modified z-score 3.5 判据；该构造保证正常值与注入失效可以明确分离。真实项目需要另行确认 Fail 判据是否代表物理开路，不能把一般统计离群等同于开路。

`expected_chain_counts.csv` 记录注入模型产生的各节点、各链总样品数 n 和失败样品数 k，可与软件结果核对。T1 沿用 T0 的实例随机阈值并提高风险，因此此例没有恢复，且不包含缺失测量。分母每个样品只计算一次，不是测试点或重复次数。

固定随机种子为 20260922。实例 X/Y 范围约为 -1200 至 1200 um。假设瞬时累计风险为：

```text
h_instance = h_type × node_multiplier × exp(0.30 × X / 1000 - 0.20 × Y / 1000)
p_instance = 1 - exp(-h_instance)
```

`h_type` 分别为 0.006、0.012、0.021；节点系数 T0=1、T1=1.8。链中任一实例失败即为该链失败。有限样本的估计不会精确等于这些参数；忽略 XY 时的类型模型也有意省略了生成过程中的位置因素。

需要重新生成时，在仓库根目录运行：

```bash
./.venv/bin/python examples/tsk_risk_demo/generate_demo.py
```

## 分批与母批示例

`batch_data.csv` 是同一组模拟测量的三批版本，继续使用上面的 `template.xlsx`：L001 有 100 个样品、L002 和 L003 各有 150 个样品，每批都包含 T0/T1。各批的样品编号都从 S0001 重新开始，因此也可核对软件不会跨批合并重号样品。

1. Setup 选择 `batch_data.csv` 和 `template.xlsx`，TSK Analysis 的数据来源选择输入文件；也可导入一个新的测试数据库后选择该导入记录。
2. 批次模式选择“按原批次分别统计”，批次字段选 `lot_id`，读取批次。运行后应有 3 批 × 2 节点共 6 组。
3. 改为母批合并模式，将 L001、L002 的母批编号都填为 M001，L003 填为 M002。判据数据池保持“原批次”。
4. 运行后共有 4 组。M001 每节点、每链有效分母是 250，M002 是 150；各组有自己的 TSK 概率和区间。
5. 导出结果的 `Batch Counts` 保留原批计数，可与 `batch_expected_counts.csv` 核对。`batch_settings.json` 是上述运行参数的程序调用示例，不是另一个拓扑模板。

这是批次操作演示：只改变原示例的批次标签和样品编号，没有人为注入额外的批次风险效应。合并要求使用者判断所选原批是否适合共享一套风险参数。

重新生成三批版本：`./.venv/bin/python examples/tsk_risk_demo/generate_batch_demo.py`。

## 模板字段说明

JSON 顶层 `tsk_analysis` 与 Excel 两张独立工作表对应：

| 字段 | 作用 |
| --- | --- |
| `enabled` | 是否启用当前模板的 TSK 配置。普通 Analyze 不会自动执行本模块。 |
| `use_xy` | 默认是否考虑坐标，运行页可切换。 |
| `coordinate_unit` | 所有 X/Y 的统一长度单位。 |
| `group_by_dimensions` | 先按指定行维度分区再合并，每区独立拟合。多个 Excel 值使用英文分号。节点始终分别计算。 |
| `feature_columns` | 额外数值特征列的名称，默认空列表。模板会无损保存这些值。实际参与拟合的特征由所选模型决定。 |
| `instances` | 每行一个物理实例，对应 `tsk_instances` 工作表。 |

实例字段为 `chain_id`、`tsk_instance_id`、`tsk_id`、`chain_key`、`x`、`y`、`features`。Excel 表头分别是 `CHAIN_ID`、`TSK_instance_ID`、`TSK_ID`、`CHAIN_KEY`、`X`、`Y`，以及已声明的特征列。`CHAIN_KEY` 使用 JSON 数组，例如 `["DemoDesign", "Chain_01"]`。如果 Chain 名在整个模板中唯一，可以只填 `CHAIN_ID`，完整键会自动补齐；重名时必须填写完整键并给各链不同的 `CHAIN_ID`。

未配置新字段或新工作表的旧模板仍可正常使用，默认关闭 TSK。软件内置普通模板中的 `EXAMPLE_*` 实例也是假设占位，保持关闭；真实分析前必须替换成真实映射并启用。
