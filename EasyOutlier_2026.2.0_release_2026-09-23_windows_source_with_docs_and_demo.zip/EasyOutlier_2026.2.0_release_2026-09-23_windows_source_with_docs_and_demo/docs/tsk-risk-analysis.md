# Independent TSK risk analysis

TSK Analysis is a separate workbench tab. It uses the paths in Setup but has its own data source, import selection, node/sample scope, Fail criterion, condition and batch grouping, classification pool, and XY/feature selection. Running Analyze does not run TSK estimation. TSK Results does not replace existing Analyze results. Batch settings described below apply only to this module.

完整中文推导、置信区间解释及可复现算例见 [TSK 数学原理（LaTeX Markdown）](tsk-risk-mathematical-principles.md)。适合有高等数学基础、尚未系统学习概率统计的读者。

## Try the hypothetical example

1. In Setup, select `examples/tsk_risk_demo/template.xlsx` (or `template.json`) and `examples/tsk_risk_demo/data.csv` as the input.
2. Open **TSK Analysis**, choose **Input · Setup 中的输入文件**, and click **运行 TSK 风险分析**. No Golden file or database import is needed for this example.
3. Select T0 or T1 in **TSK Results**. Risk bars show single-instance probabilities; whiskers show 95% intervals. Chain fit compares observed and predicted proportions; the table reports residuals in percentage points.
4. Optionally enable XY or select numeric attributes and run again. Feature-model type risks refer to the training-layout mean environment, not an average of the probabilities across the type's actual instances.
5. Export XLSX for type estimates, bounds, chain counts, sample outcomes, topology, diagnostics and the configuration snapshot. Long JSON metadata is split into ordered parts to avoid Excel truncation.

The demo has 12 chains, three TSK types, 400 samples and two nodes. Its topology and values are invented and clearly labelled. The bundled ordinary template contains disabled EXAMPLE placeholders; replace them with real topology before enabling TSK analysis.

## Original batches and parent batches

Choose an existing row dimension such as `lot_id` as the batch field. It must be different from the reliability-node dimension. Batch settings affect how this run is classified and fitted; they do not rename the source data, change the template's sample identity, or replace batch values used to match Golden references.

| Batch mode | Fit groups |
| --- | --- |
| `none` — previous grouping behavior | Use the selected node and condition fields without a dedicated batch rule. The classification pool is the whole selected scope, preserving previous behavior. |
| `separate` — original batches | Fit each original batch separately, within each node and remaining condition group. |
| `parent` — parent batches | Map original batches to parent IDs, sum their final chain counts within each node and remaining condition group, then run maximum likelihood again. |

For a runnable example, use [batch_data.csv](../examples/tsk_risk_demo/batch_data.csv) with the same demo template. It contains L001 with 100 samples, L002 with 150, and L003 with 150, at both T0 and T1. Sample numbers restart within each batch. The run settings are also provided in [batch_settings.json](../examples/tsk_risk_demo/batch_settings.json), and expected counts in [batch_expected_counts.csv](../examples/tsk_risk_demo/batch_expected_counts.csv).

To combine L001 and L002 while keeping L003 separate:

1. Select the intended data/imports, nodes and samples in **TSK Analysis**.
2. Select original-batch mode with `lot_id` as the batch field to inspect L001, L002 and L003 separately.
3. To fit parent batches, choose parent-batch mode and enter `L001 → M001`, `L002 → M001`, `L003 → M002`. Every original batch present in the selected analysis scope needs a nonempty parent ID; an unmapped batch is not silently dropped.
4. Keep other desired condition fields, such as temperature. The chosen batch field is removed from additional condition grouping so it cannot prevent L001 and L002 from joining M001. Nodes and the other conditions still receive separate fits.
5. Select the classification pool, run the analysis, and inspect **Batch Counts** in the export alongside the parent results. Risk results retain `parent_batch_id` and `source_batches` for traceability.

For this complete-data example, separate mode yields six groups. Parent mode yields four groups: M001 at each node has 250 effective samples per chain, and M002 has 150. These files illustrate aggregation and repeated sample numbers across batches; they do not introduce or prove a separate batch-effect model.

The classification pool and the final fit group serve different purposes:

- **Original batch** (`classification_pool="original_batch"`, the default when batch mode is enabled): calculate each logical measurement's Modified Z-score within each original batch. Each pool includes that batch's selected nodes and conditions; it is not recomputed for every node or final fit group. Mapping L001/L002 to M001 does not combine their Z-score pools.
- **Whole selected scope** (`classification_pool="selected_scope"`): calculate each logical measurement's Modified Z-score across all selected batches, nodes and conditions, matching the previous pool definition. This is always used with `batch_mode="none"`.

Small pools with fewer than three valid values, or pools with zero MAD, produce an unknown Z-score criterion and follow the existing three-state rules. Golden matching and thresholds are unchanged. Per-batch Z-scores define outliers relative to each batch and can therefore give different labels from a combined pool; selecting this option does not statistically correct batch effects.

Parent aggregation happens **after each original batch has merged its repeats and resolved Pass / Fail / Missing**. Sample `S01` from L001 and sample `S01` from L002 remain different observations. For each chain, sum Fail and Pass counts to obtain the effective denominator; sum Missing separately and exclude it from that denominator. The engine fits these summed counts, never an average of fitted TSK probabilities.

Pooling assumes a common TSK probability vector within the parent/node/condition group, or common type and feature coefficients when features are enabled, using the same chain topology. Unequal batches contribute according to their valid counts in the binomial likelihood. A larger batch therefore contributes more information than a smaller batch. The mapping itself neither verifies this common-risk assumption nor removes differences between heterogeneous batches. The mathematical derivation and an unequal-size example are in [§6.6 of the mathematical guide](tsk-risk-mathematical-principles.md#batch-likelihood).

The corresponding runtime settings are:

```python
settings = {
    "batch_mode": "parent",  # none | separate | parent
    "batch_dimension": "lot_id",
    "batch_mapping": {"L001": "M001", "L002": "M001", "L003": "M002"},
    "classification_pool": "original_batch",  # original_batch | selected_scope
    "group_by_dimensions": [],  # optionally add other declared row fields
}
```

These controls are TSK run settings. Existing runs without `batch_mode` continue to use `none` and the whole-scope classification pool.

## Template

The JSON `tsk_analysis` section corresponds to the Excel `tsk_analysis` settings sheet and `tsk_instances` table. Each instance row contains `CHAIN_ID`, `TSK_instance_ID`, `TSK_ID`, `X`, `Y`, an optional explicit `CHAIN_KEY`, and declared numeric feature columns. `CHAIN_KEY` is a JSON array containing the complete column header path through the Chain level. A unique Chain name can be resolved automatically; ambiguous names require explicit paths and distinct external IDs.

Repeated TSK types are counted, not deduplicated. An instance ID must be unique within its chain. Coordinates must use a common coordinate system and unit. Density values require a consistent fraction/percentage convention and measurement window. The optional settings are `enabled`, `use_xy`, `coordinate_unit`, `feature_columns` and `group_by_dimensions`. Ordinary old templates remain compatible.

## Observation and missing-data rules

- One observation is a unique sample at a node for one chain. Repeats, sites and measurement columns follow the template's merge order and any/all definitions; they do not increase the number of independent dies.
- Nodes are always fitted separately. Explicit condition fields partition the data before merging, including lower-level temperature or site fields if selected. With batch mode enabled, each original batch is also kept separate during this stage; only completed counts are combined for parent fits. Partitioning by a repeat does not make repeated observations independent.
- Fail and Pass are determined using the selected criterion and the saved template's thresholds. The unrelated Analyze controls and filters are not implicitly applied.
- Unknown values propagate through three-state merging. For any_fail, a known Fail determines Fail; otherwise unknown contributors prevent a certain Pass. For all_fail, a known Pass determines Pass; otherwise unknown contributors prevent a certain Fail. Unresolved outcomes are Missing and excluded from the valid denominator.
- Missing Golden matches remain unknown. Unlike ordinary report display, this module also treats Modified Z-score pools with fewer than three values or zero MAD as unknown, rather than treating an undefined dispersion estimate as evidence of health.
- Original input files preserve identified all-empty sample rows. Measurement-only databases cannot recover rows with no numeric measurements at import; the result explicitly warns about that exposure limitation.

## Model and intervals

For each node/condition and configured original or parent batch, the type-only model uses `q_i = 1 - product_t((1-p_t)**C_it)`, where C is the instance-count matrix. Nonnegative log-survival parameters are fitted by binomial maximum likelihood. Rank and realized-likelihood checks suppress unidentifiable type estimates.

With XY or additional features, each instance uses a type intercept plus standardized linear feature effects on the logit scale. Instance survival probabilities are then multiplied within each chain. Multiple starts are used; global optimality is not guaranteed. This first version uses linear XY effects, not a nonlinear spatial surface or a full-die heatmap.

Intervals are profile-likelihood approximations, with appropriate exact transformations or bounds in supported boundary cases. Parent fits recompute intervals from their summed-count likelihood; the intervals are not averaged from the original batches and do not estimate between-batch variability. Each type row records its interval method. Nonconvergence, boundary estimates and unavailable intervals are explicit. A probability of zero is not evidence that true risk is exactly zero.

The inference assumes that a chain's Fail event is the OR of its instance failures, with conditional independence. Multi-instance accumulated drift or correlated defects can violate that assumption. Intervals currently assume independent chain observations; correlations between chains on the same die or between repeated nodes are not corrected by a cluster bootstrap. The data and paired sample outcomes remain available for follow-up validation. Fits estimate risk under these assumptions, not a directly observed root cause.

## Runtime and development

NumPy and SciPy are declared project dependencies. Install through the existing `pip install -e .` setup. The UI uses PySide6/QPainter and adds no browser/chart runtime. All controls and layouts are defined in `.ui` and checked-in generated modules.

Automated coverage includes known-risk recovery, repeated instances, identifiability, zero/all-failure boundaries, feature scaling, JSON/XLSX round trips, three-state missing handling, node/condition separation, independent execution, persistence and export. Native macOS Cocoa geometry and horizontal expansion are checked separately. Windows execution and frozen distributions require validation on Windows; this change does not claim a newly tested Windows executable.
