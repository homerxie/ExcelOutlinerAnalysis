# TSK risk analysis development plan

2026-09-22. Baseline `codex/chunked-sheet-export` (including existing field-name changes) was fast-forwarded into `main` at `12daa7f`. All feature work belongs to `codex/tsk-risk-analysis`.

## Scope and workflow

- Add an independent **TSK Analysis** workbench tab and **TSK Results** result tab. Ordinary Analyze must not start TSK estimation or require topology.
- Reuse the current workspace paths and template's classification/merge definitions, but run a separate service with its own import selection, node/condition scope, Fail method, XY switch and optional numeric features.
- Define topology in JSON and Excel templates: CHAIN_ID, TSK_instance_ID, TSK_ID, X, Y and extensible numeric attributes. Preserve repeated TSK types as distinct instances; resolve chains using full header paths. Old templates remain valid.
- Supply clearly labelled hypothetical topology and a reproducible standalone demo template/data set. No invented mapping should be presented as real layout information.

## Statistical contract

- Observation unit: unique sample × node × chain within a fixed stratum; repeated measurements do not inflate sample size. Classify Fail / Pass / Missing using the selected existing measurement criterion and three-state merge semantics. Missing is not Pass; incomplete database exposure is disclosed.
- Fit `q_i = 1 - product_t((1-p_t)**C_it)` using nonnegative log-survival parameters and binomial maximum likelihood.
- Optional XY and selected numeric features use a low-complexity logistic instance model, then aggregate instance survival within each chain. Scale features, detect confounding, and disclose that this extension is not guaranteed convex.
- Check structural and numerical identifiability; do not publish arbitrary individual rankings for unidentifiable types.
- Report 95% profile-likelihood approximate intervals, explicit boundary/fitting status, and the independent-observation assumption. For feature models, type risks refer to the training-mean feature environment, stated on screen and in exports.

## Results and UI

- TSK probability bars with interval whiskers; missing/unidentifiable estimates labelled explicitly.
- Observed versus predicted chain probabilities and residuals; detail tables with Fail, Pass, Missing and counts.
- Topology preview, model diagnostics and XLSX export with provenance and actual options.
- Define all widgets, static text, defaults, layouts and size policies in `.ui` files; regenerate with `.venv/bin/pyside6-uic`. Controllers handle events and dynamic state only. Use a Qt-painted plot widget declared in `.ui`.

## Implementation ownership

1. Template models, JSON/XLSX round trips, guidance and examples.
2. Independent numeric engine and statistical tests.
3. Dedicated `.ui` panels, generated modules, plots and GUI tests.
4. Independent data service, MainWindow wiring, dependencies, end-to-end tests and documentation.

## Verification

- Baseline: 1,136 tests and 7 subtests passed (`pytest tests`, offscreen).
- Exact synthetic parameter recovery; repeated instances; rank deficiency; zero/all Fail; interval boundary behavior; feature scaling and confounding.
- Template backward compatibility and JSON/XLSX round trips.
- Missing and repeated measurements, node/condition separation, Golden and Z-score classification, separate execution from Analyze, export checks.
- Complete test suite, generated-UI consistency, macOS Cocoa display and horizontal resizing. Windows packaging limitations, if any, reported explicitly.

## Progress

### Batch extension plan (2026-09-23)

- Extend only TSK Analysis/Results on the existing feature branch. Preserve the current behavior when batch mode is disabled.
- Add original-batch and parent-batch modes, a row-dimension selector, scope-aware batch discovery and an editable original-to-parent mapping. Save settings with the database workspace.
- Classify and merge repeated observations within original batches, then sum chain Fail/Pass/Missing counts inside each parent × node × remaining condition group and refit. Keep original sample identities and per-batch counts for traceability.
- Offer original-batch versus selected-scope classification pools; use the former by default when batch analysis is enabled. Never silently combine nodes or retain the batch field as an extra stratum that prevents the requested pooling.
- Display parent identifiers/members with existing probability bars and confidence intervals; export parent identifiers and original-batch counts. Document the common-risk assumption and pooled likelihood.
- Verify duplicate sample IDs across batches, unequal exposures, incomplete mappings, Missing, source selection, persistence, exports and native macOS layout before delivery.

- [x] Save and verify existing work, merge into main, create feature branch.
- [x] Record development plan before implementation.
- [x] Implement template, engine, service and UI.
- [x] Verify synthetic and existing regression tests, native UI and exports.

## Completed verification

- Latest suite (2026-09-23): **1,227 tests and 7 subtests passed** (`QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m pytest tests -q`).
- The [detailed mathematical guide](tsk-risk-mathematical-principles.md) includes independently checked profile endpoints. This cross-check exposed premature optimizer termination; the engine now verifies stationarity and uses a checked fallback before reporting intervals.
- All three changed/new generated UI modules exactly match `pyside6-uic` output; `git diff --check` and `pip check` pass.
- The demo's 24 node/chain counts match the injected Fail/Tested counts. Type-only and optional XY models converge with ranks 3 and 5 respectively.
- Native macOS Cocoa MainWindow loads the Excel demo template, executes the real background analysis for T0/T1, renders probability bars and intervals, and exports the full result workbook. Panel width expands from 589 to 807 pixels when the window grows from 1080 to 1440 pixels.
- Export includes 9,600 paired sample/chain outcomes. Direct row indexing avoids repeated worksheet scans; large configuration snapshots are split into ordered Excel-safe chunks.
- Windows and frozen executables were not built or executed in this macOS development run.

### Batch extension verification

- Completed the dedicated TSK batch controls, scope-aware discovery, database-state persistence, parent refitting, source traceability, export and mathematical explanation.
- Added 21 service/model regression cases and 5 GUI regression cases. A 1/1 batch plus a 0/9 batch produces pooled probability 1/10, preserving the appropriate sample weighting. Duplicate sample IDs in different original batches remain separate, including templates whose sample key does not include the batch field.
- The three-batch fixture yields six original-batch groups or four parent-batch groups. All 120 node/chain counts across both modes match independently retained injected labels.
- A native Cocoa MainWindow loaded a relocated copy of the demo database, restored mappings and four saved results, scanned batches through the actual button, ran four converged parent fits and six converged original-batch fits, and retained parent IDs when switching modes. Native controls expand correctly from 1080 to 1440 window width.
- The new portable `TSK_Batch_Demo` includes CSV input, topology template, populated database, saved parent settings/results and an XLSX result export. The original single-batch demo remains available.
