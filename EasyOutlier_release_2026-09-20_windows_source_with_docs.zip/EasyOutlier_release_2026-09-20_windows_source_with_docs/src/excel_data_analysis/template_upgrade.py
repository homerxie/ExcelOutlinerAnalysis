from __future__ import annotations

from copy import deepcopy
from datetime import datetime
from pathlib import Path
import os
import shutil
import tempfile

from .merge_config import TEMPLATE_SCHEMA_VERSION, chain_level, validate_merge_levels
from .models import TemplateConfig
from .template import load_template, save_template


def upgrade_template_file(path: str | Path, template: TemplateConfig | None = None,
                          *, repair_chain_boundary: bool = False) -> tuple[Path, Path | None]:
    """Upgrade explicitly, keeping a byte-for-byte backup and replacing atomically."""
    source = Path(path)
    current = deepcopy(template or load_template(source))
    if not current.migration_required:
        return source, None
    if current.migration_issues and repair_chain_boundary:
        # Old start=Chain's child is equivalent to new retained target=Chain.
        current.report.initial_column_merge_level = chain_level(current)
        current.report.outlier_test_merge_max_level = None
    if current.migration_issues and not current.report.initial_column_merge_level:
        raise ValueError("initial_column_merge_level: 旧配置会合掉 Chain，请确认修正后再升级。")
    validate_merge_levels(current)
    current.schema_version = TEMPLATE_SCHEMA_VERSION
    current.migration_required = False
    current.migration_issues = []
    target = source.with_suffix(".xlsx") if source.suffix.lower() == ".xlsm" else source
    if target != source and target.exists():
        raise FileExistsError(f"Upgrade destination already exists: {target}")
    backup = source.with_name(f"{source.stem}.legacy-backup-{datetime.now():%Y%m%d-%H%M%S-%f}{source.suffix}")
    fd, temporary = tempfile.mkstemp(prefix=".template-upgrade-", suffix=target.suffix, dir=target.parent)
    os.close(fd)
    try:
        save_template(current, temporary)
        # Validate the serialized merge config before touching the original.
        validate_merge_levels(load_template(temporary))
        shutil.copy2(source, backup)
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return target, backup
