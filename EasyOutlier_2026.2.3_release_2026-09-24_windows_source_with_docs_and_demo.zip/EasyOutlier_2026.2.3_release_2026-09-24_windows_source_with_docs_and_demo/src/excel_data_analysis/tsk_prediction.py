"""Conditional category predictions from a frozen TSK likelihood fit.

The query is read-only: it does not classify measurements, reload a template,
or refit the unconstrained model. Confidence limits profile the original chain
likelihood; category contrasts use its joint expected information matrix.
"""

from __future__ import annotations

import math
from itertools import product
from typing import Any, Callable, Mapping, Sequence

import numpy as np
from scipy.optimize import brentq
from scipy.special import expit
from scipy.stats import chi2, norm

from .tsk_analysis import _feature_loss_and_derivative, _minimize_bound_constrained, _plain
from .tsk_features import ALL_CATEGORY_COMBINATIONS, category_combination_label, category_label
from .tsk_linear import (
    linear_hazard_contrast_identifiable, linear_hazard_evaluate, linear_hazard_profile_interval,
)


MAX_COMBINATION_CELLS = 200
PROBABILITY_INTERVAL_METHOD = "profile_likelihood_approximate_linear_contrast"
LINEAR_PROBABILITY_INTERVAL_METHOD = "profile_likelihood_approximate_linear_hazard_contrast"
DELTA_INTERVAL_METHOD = "joint_expected_information_delta_method_pointwise"


def _row_basis(matrix: np.ndarray) -> np.ndarray:
    """Return orthonormal columns spanning the parameter-space row space."""
    if not matrix.size:
        return np.zeros((matrix.shape[1], 0))
    _, singular, right = np.linalg.svd(matrix, full_matrices=False)
    tolerance = max(matrix.shape) * np.finfo(float).eps * singular[0] * 100
    return right[singular > tolerance].T


def _in_row_space(vector: np.ndarray, basis: np.ndarray) -> bool:
    residual = vector - basis @ (basis.T @ vector)
    return bool(np.linalg.norm(residual) <= 1e-7 * max(np.linalg.norm(vector), 1e-15))


class _FrozenFit:
    def __init__(self, context: Mapping[str, Any]):
        if context.get("version") != 1 or context.get("model") not in {
                "instance_logistic_features", "instance_linear_hazard_features"}:
            raise ValueError("Unsupported TSK prediction context; run the categorical model again.")
        self.context = context
        self.linear_hazard = context["model"] == "instance_linear_hazard_features"
        self.interval_method = LINEAR_PROBABILITY_INTERVAL_METHOD if self.linear_hazard else PROBABILITY_INTERVAL_METHOD
        self.design = np.asarray(context["design"], dtype=float)
        self.chain_index = np.asarray(context["chain_index"], dtype=int)
        self.n = np.asarray(context["n_tested"], dtype=float)
        self.k = np.asarray(context["n_failed"], dtype=float)
        self.theta = np.asarray(context["coefficients"], dtype=float)
        self.boundary_engine = None
        self.minimum = float(context["negative_log_likelihood"])
        self.width = len(self.theta)
        if (self.design.ndim != 2 or self.design.shape[1] != self.width
                or self.chain_index.shape != (len(self.design),) or self.n.shape != self.k.shape
                or len(self.n) != len(context["chain_ids"]) or not len(self.n)
                or np.any(self.chain_index < 0) or np.any(self.chain_index >= len(self.n))
                or np.any(self.n <= 0) or np.any(self.k < 0) or np.any(self.k > self.n)
                or not all(np.all(np.isfinite(value)) for value in (self.design, self.n, self.k, self.theta))
                or not math.isfinite(self.minimum)):
            raise ValueError("The TSK prediction context contains invalid fitted arrays or counts.")
        self.design_basis = _row_basis(self.design)
        boundary_state = context.get("boundary_fit")
        if not self.linear_hazard and boundary_state is not None:
            from .tsk_logistic_boundary import LogisticBoundaryFit
            self.boundary_engine = LogisticBoundaryFit(
                self.design, self.chain_index, self.n, self.k, len(context["type_ids"]),
                coefficient_bound=float(context.get("logistic_coefficient_bound", 35.)))
            self.boundary_engine.load_state(boundary_state)
            self.theta = np.asarray(boundary_state["params"], dtype=float)
            self.interval_method = "profile_likelihood_approximate_odds_contrast"
        _, _, predicted, derivative = self.evaluate(self.theta)
        self.derivative = derivative
        self._identifiable_contrasts = {}
        self.likelihood_basis = _row_basis(derivative)
        if self.boundary_engine is not None:
            self.boundary = bool(boundary_state["zero_type_indices"])
            q = predicted
            survival = 1. - q
        else:
            instance_hazards = (self.design @ self.theta if self.linear_hazard
                                else np.logaddexp(0, self.design @ self.theta))
            if self.linear_hazard and np.min(instance_hazards, initial=0.) < -1e-8:
                raise ValueError("The stored linear-risk fit violates nonnegative instance hazards.")
            self.boundary = bool(self.linear_hazard and np.any(instance_hazards <= 1e-9))
            hazards = np.bincount(self.chain_index, weights=np.maximum(instance_hazards, 0.), minlength=len(self.n))
            q = -np.expm1(-hazards)
            survival = np.exp(-hazards)
        weights = np.divide(self.n * survival, q, out=np.zeros_like(q), where=q > 0)
        weighted_derivative = np.sqrt(weights)[:, None] * derivative
        self.information_basis = _row_basis(weighted_derivative)
        _, singular, right = np.linalg.svd(weighted_derivative, full_matrices=False)
        rank = self.information_basis.shape[1]
        retained = right[:rank].T
        self.covariance = (retained / singular[:rank]) @ (retained / singular[:rank]).T
        self.valid_fit = bool(context.get("converged") and (
            boundary_state.get("converged") and not boundary_state.get("feature_clipped")
            if self.boundary_engine is not None else not context.get("clipped")))
        self.last_interval_method = self.interval_method

    def evaluate(self, theta):
        if self.boundary_engine is not None:
            return self.boundary_engine.evaluate(theta)
        if self.linear_hazard:
            return linear_hazard_evaluate(self.design, self.chain_index, self.n, self.k, theta)
        return _feature_loss_and_derivative(self.design, self.chain_index, self.n, self.k, theta)

    def probability(self, vector):
        if not self.identifiable(vector):
            return None
        if self.boundary_engine is not None:
            return self.boundary_engine.probability(self.theta, vector)
        value = float(vector @ self.theta)
        if self.linear_hazard:
            # Training-instance constraints do not imply a valid hazard at an
            # unobserved combination of categories and numeric layout means.
            return None if value < -1e-9 else float(-np.expm1(-max(value, 0.)))
        return float(expit(value))

    def probability_gradient(self, probability, vector):
        if self.boundary_engine is not None:
            return self.boundary_engine.probability_gradient(self.theta, vector)
        return (1 - probability) * vector if self.linear_hazard else probability * (1 - probability) * vector

    def estimate_kind(self, vector):
        if self.boundary_engine is not None and vector is not None:
            index = int(np.argmax(vector[:self.boundary_engine.type_count]))
            if self.theta[index] == 0:
                return "boundary_low"
        return "interior"

    def identifiable(self, vector):
        if self.boundary_engine is not None:
            return bool(self.valid_fit and vector is not None and _in_row_space(vector, self.design_basis)
                        and self.boundary_engine.identifiable(self.theta, vector))
        identified = (self.valid_fit and vector is not None
                      and _in_row_space(vector, self.design_basis)
                      and _in_row_space(vector, self.likelihood_basis))
        if identified and self.linear_hazard:
            key = tuple(vector)
            if key not in self._identifiable_contrasts:
                self._identifiable_contrasts[key] = linear_hazard_contrast_identifiable(
                    self.design, self.derivative, self.n, self.k, self.theta, vector)
            return self._identifiable_contrasts[key]
        return identified

    def profile_interval(self, vector: np.ndarray, confidence: float) -> tuple[float, float]:
        """Profile eta=r theta after removing only exact design-null directions."""
        if self.boundary_engine is not None:
            low, high, self.last_interval_method = self.boundary_engine.profile_interval(self.theta, vector, confidence)
            return low, high
        if self.linear_hazard:
            return linear_hazard_profile_interval(self.design, self.chain_index, self.n, self.k,
                                                  self.theta, vector, self.minimum, confidence)
        reduced = self.design_basis.T @ vector
        length = float(np.linalg.norm(reduced))
        if length <= 1e-12:
            raise RuntimeError("The requested logit contrast has no estimable direction.")
        direction = reduced / length
        # eta is the first coordinate of this orthogonal parameterization;
        # every nuisance direction is free. No individual alpha must be fixed.
        _, _, orthogonal = np.linalg.svd(direction[None, :], full_matrices=True)
        nuisance_basis = self.design_basis @ orthogonal[1:].T
        eta_direction = self.design_basis @ direction / length
        initial = nuisance_basis.T @ self.theta
        estimate = float(vector @ self.theta)
        cutoff = self.minimum + float(chi2.ppf(confidence, 1)) / 2
        cache: dict[float, float] = {}

        def objective(eta):
            key = float(eta)
            if key in cache:
                return cache[key]
            offset = eta_direction * eta

            def nuisance_objective(values):
                value, gradient, _, _ = self.evaluate(offset + nuisance_basis @ values)
                return value, nuisance_basis.T @ gradient

            if initial.size:
                fit, converged = _minimize_bound_constrained(
                    nuisance_objective, initial, float(self.n.sum()), -math.inf)
                if not converged:
                    raise RuntimeError("Profile nuisance optimization did not converge.")
                value = float(fit.fun)
            else:
                value = float(nuisance_objective(initial)[0])
            if not math.isfinite(value):
                raise RuntimeError("Profile likelihood became non-finite.")
            if value < self.minimum - max(1e-5, abs(self.minimum) * 1e-8):
                raise RuntimeError("Profile found a better optimum than the stored fit.")
            cache[key] = value - cutoff
            return cache[key]

        variance = float(vector @ self.covariance @ vector)
        step = max(.5, float(norm.ppf((1 + confidence) / 2)) * math.sqrt(max(variance, 0.)))

        def endpoint(sign):
            # Finite numerical limits correspond to probability 0/1 if the
            # likelihood-ratio cutoff is never crossed toward that boundary.
            boundary = min(-40., estimate - 40.) if sign < 0 else max(40., estimate + 40.)
            distance = step
            while True:
                candidate = max(boundary, estimate - distance) if sign < 0 else min(boundary, estimate + distance)
                if objective(candidate) >= 0:
                    lo, hi = sorted((estimate, candidate))
                    eta = brentq(objective, lo, hi, xtol=1e-8)
                    return float(expit(eta))
                if candidate == boundary:
                    return 0. if sign < 0 else 1.
                distance *= 2

        return endpoint(-1), endpoint(1)


def predict_tsk_combinations(
    context: Mapping[str, Any], *, dimension: str,
    fixed_categories: Mapping[str, Any] | None = None,
    reference_level: Any | None = None,
    tsk_ids: Sequence[str] | None = None,
    extrapolate: bool = True,
    progress_callback: Callable[[int, str], None] | None = None,
) -> dict[str, Any]:
    """Predict a category slice or every categorical combination for each TSK.

    Numeric fields stay at the frozen fit's layout means. Support counts refer
    to the exact categorical combination, not to an exact numeric mean value.
    Chain test exposure counts each matching active chain once, even if that
    chain contains several matching instances. Intervals are pointwise. With
    extrapolation disabled, combinations without active data remain blank and
    cannot serve as the reference for probability differences.
    """
    if not isinstance(context, Mapping):
        raise ValueError("A categorical TSK prediction context is required.")
    categorical = context.get("categorical_features", {})
    all_combinations = dimension == ALL_CATEGORY_COMBINATIONS
    if not categorical or (not all_combinations and dimension not in categorical):
        raise ValueError(f"{dimension!r} is not a categorical dimension in this fitted model.")
    fixed = dict(fixed_categories or {})
    if all_combinations and fixed:
        raise ValueError("All categorical combinations cannot also have fixed categories.")
    if dimension in fixed:
        raise ValueError("The displayed dimension cannot also be a fixed category.")
    unknown = set(fixed) - set(categorical)
    if unknown:
        raise ValueError("Unknown fixed categorical dimensions: " + ", ".join(sorted(unknown)))
    all_types = list(context["all_type_ids"])
    selected_types = all_types if tsk_ids is None else list(dict.fromkeys(tsk_ids))
    if not selected_types or any(value not in all_types for value in selected_types):
        raise ValueError("Select one or more TSK IDs present in the fitted topology.")
    level_count = (math.prod(len(encoding["levels"]) for encoding in categorical.values())
                   if all_combinations else len(categorical[dimension]["levels"]))
    if len(selected_types) * level_count > MAX_COMBINATION_CELLS:
        raise ValueError(f"This query exceeds {MAX_COMBINATION_CELLS} combination cells; select fewer TSK IDs.")
    if all_combinations:
        combinations = [dict(zip(categorical, values))
                        for values in product(*(encoding["levels"] for encoding in categorical.values()))]
        levels = [category_combination_label(categories) for categories in combinations]
        reference = (str(reference_level) if reference_level is not None else
                     category_combination_label({name: encoding["reference"] for name, encoding in categorical.items()}))
    else:
        for name, encoding in categorical.items():
            if name == dimension:
                continue
            fixed[name] = category_label(fixed.get(name, encoding["reference"]), name)
            if fixed[name] not in encoding["levels"]:
                raise ValueError(f"Unknown category {fixed[name]!r} for {name!r}.")
        levels = list(categorical[dimension]["levels"])
        combinations = [{**fixed, dimension: level} for level in levels]
        reference = category_label(reference_level if reference_level is not None
                                   else categorical[dimension]["reference"], dimension)
    if reference not in levels:
        raise ValueError(f"Unknown reference category {reference!r} for {dimension!r}.")
    categories_by_level = dict(zip(levels, combinations))
    confidence = float(context["confidence_level"])
    if not 0 < confidence < 1:
        raise ValueError("The stored confidence level must be strictly between 0 and 1.")
    fit = _FrozenFit(context)
    progress = progress_callback or (lambda *_: None)
    progress(0, "Computing conditional TSK category combinations")
    type_index = {name: index for index, name in enumerate(context["type_ids"])}
    chain_n = dict(zip(context["chain_ids"], context["n_tested"]))
    warnings = [
        "Predictions are conditional on numeric layout means and the selected categories; they are not observed instance Fail rates or causal effects.",
        "Intervals are pointwise and assume independent chain observations; shared die/wafer effects are not included.",
        "Probability limits use profile likelihood; probability-difference limits use a joint-information normal approximation, not subtraction of endpoint limits.",
    ]
    if fit.linear_hazard:
        warnings.append("Linear-risk predictions require nonnegative hazard at the requested reference point; invalid extrapolations are withheld. Convexity does not guarantee a unique or well-fitting model.")
        if fit.boundary:
            warnings.append("The linear-risk fit has active nonnegative-hazard boundaries; normal-approximation category-difference intervals are withheld.")
    else:
        warnings.append("Identifiability includes a local likelihood-Jacobian check; the feature fit does not guarantee a globally unique optimum.")
        if fit.boundary_engine is not None:
            warnings.append("Zero-boundary probabilities use a nonnegative-odds fit with constrained identifiability checks. "
                            "Zero estimates do not guarantee zero true risk; exact/conservative and approximate upper limits are labelled separately.")
    if not fit.valid_fit:
        warnings.append("The stored feature fit did not establish a stable finite optimum; predictions are withheld.")
    if not extrapolate:
        warnings.append("Combinations without active observed categorical support are left blank; their model extrapolations and reference contrasts are withheld.")
    rows = []
    vectors = {}
    probabilities = {}
    supports = {}

    def vector_for(tsk_id, categories):
        if tsk_id not in type_index:
            return None
        vector = np.zeros(fit.width)
        vector[type_index[tsk_id]] = 1.
        for index, (name, level) in enumerate(context["coefficient_columns"], start=len(type_index)):
            if level is not None and categories[name] == level:
                vector[index] = 1.
        return vector

    for tsk_id in selected_types:
        for level in levels:
            categories = categories_by_level[level]
            matching = [row for row in context["topology"]
                        if row["tsk_id"] == tsk_id and row["categories"] == categories]
            active = [row for row in matching if row["chain_id"] in chain_n]
            supports[tsk_id, level] = matching, active
            vector = vector_for(tsk_id, categories)
            probability = fit.probability(vector) if extrapolate or active else None
            vectors[tsk_id, level] = vector
            probabilities[tsk_id, level] = probability

    for tsk_id in selected_types:
        for level in levels:
            categories = categories_by_level[level]
            matching, active = supports[tsk_id, level]
            category_description = level if all_combinations else f"{dimension}={level}"
            active_chains = {row["chain_id"] for row in active}
            support_status = "observed" if active else "no_active_support" if matching else "extrapolated"
            no_data = not extrapolate and not active
            reference_no_data = not extrapolate and not supports[tsk_id, reference][1]
            probability = probabilities[tsk_id, level]
            vector = vectors[tsk_id, level]
            reference_probability = None if no_data else probabilities[tsk_id, reference]
            reference_vector = vectors[tsk_id, reference]
            row = {
                "tsk_id": tsk_id, "level": level, "categories": categories,
                "probability": probability, "ci_lower": None, "ci_upper": None,
                "identifiable": probability is not None,
                "status": ("no_data" if no_data else "ok" if probability is not None else "outside_model_domain" if fit.identifiable(vector)
                           else "not_identifiable" if fit.valid_fit else "fit_not_converged"),
                "interval_method": None, "interval_error": None,
                "estimate_kind": fit.estimate_kind(vector) if probability is not None else None,
                "interval_sidedness": "upper" if probability is not None and fit.estimate_kind(vector) == "boundary_low" else "two_sided",
                "confidence_level": confidence,
                "layout_instance_count": len(matching), "active_instance_count": len(active),
                "chain_count": len(active_chains),
                "chain_test_exposure": int(sum(chain_n[chain_id] for chain_id in active_chains)),
                "support_status": support_status,
                "reference_probability": reference_probability,
                "delta_probability": None, "delta_ci_lower": None, "delta_ci_upper": None,
                "delta_interval_method": None, "delta_interval_error": None,
                "delta_status": "no_data" if no_data or reference_no_data else "not_identifiable",
            }
            if probability is not None:
                if row["estimate_kind"] == "boundary_low":
                    row["status"] = "boundary_low"
                progress(int(100 * len(rows) / (len(selected_types) * len(levels))),
                         f"Computing interval for TSK {tsk_id}, {category_description}")
                try:
                    row["ci_lower"], row["ci_upper"] = fit.profile_interval(vector, confidence)
                    row["interval_method"] = fit.last_interval_method
                except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                    row["status"] = "interval_unavailable"
                    row["interval_error"] = str(error) or type(error).__name__
                    warnings.append(f"TSK {tsk_id}, {category_description}: probability interval unavailable ({error}).")
            if probability is not None and reference_probability is not None:
                difference = probability - reference_probability
                gradient = (fit.probability_gradient(probability, vector)
                            - fit.probability_gradient(reference_probability, reference_vector))
                row["delta_probability"] = difference
                if np.array_equal(vector, reference_vector):
                    row.update(delta_ci_lower=0., delta_ci_upper=0.,
                               delta_interval_method=DELTA_INTERVAL_METHOD, delta_status="ok")
                elif not fit.boundary and _in_row_space(gradient, fit.information_basis):
                    variance = float(gradient @ fit.covariance @ gradient)
                    half_width = float(norm.ppf((1 + confidence) / 2)) * math.sqrt(max(variance, 0.))
                    row.update(delta_ci_lower=max(-1., difference - half_width),
                               delta_ci_upper=min(1., difference + half_width),
                               delta_interval_method=DELTA_INTERVAL_METHOD,
                               delta_status="ok")
                else:
                    row["delta_status"] = ("boundary_interval_unavailable"
                                           if fit.boundary and fit.boundary_engine is not None
                                           else "interval_unavailable")
                    row["delta_interval_error"] = (
                        "The Logistic fit has active zero-risk boundaries; the normal-approximation difference interval is unavailable."
                        if fit.boundary and fit.boundary_engine is not None else
                        "The linear-risk fit has active nonnegative-hazard boundaries; the normal-approximation difference interval is unavailable."
                        if fit.boundary else
                        "The probability-difference gradient is not identifiable from the joint expected information.")
            rows.append(row)
            progress(int(100 * len(rows) / (len(selected_types) * len(levels))),
                     f"Computed TSK {tsk_id}, {category_description}")
    return _plain({
        "dimension": dimension, "levels": levels, "fixed_categories": fixed,
        "categorical_dimensions": list(categorical), "extrapolate": bool(extrapolate),
        "reference_level": reference, "numeric_reference": dict(context.get("numeric_reference", {})),
        "confidence_level": confidence, "rows": rows, "warnings": warnings,
        "probability_interval_method": fit.interval_method,
        "delta_interval_method": DELTA_INTERVAL_METHOD,
        "model_scope": "Shared categorical main effects; no TSK-by-category or category-by-category interactions.",
    })
