"""Read-only feature-effect views for the standalone TSK HTML report."""

FEATURE_EFFECTS_SCRIPT = r'''
function effectConclusion(row) {
    if(row?.status==='boundary_uncalibrated')return '边界检验未校准';
    if(row?.status!=='ok'||!finite(row?.p_adjusted))return '无法判断';
    return row?.significant === true ? '影响显著' : row?.significant === false ? '尚未检出显著影响' : '无法判断';
}
function effectPairConclusion(row) {
    if(row?.status==='point_estimate_only'&&finite(row.difference))return '仅点估计；差异尚未检验';
    if(row?.status!=='ok'||!finite(row?.p_adjusted))return '无法判断';
    if (row.significant === true && finite(row.difference) && row.difference!==0) return row.difference > 0 ? row.level_b+' 高于 '+row.level_a : row.level_b+' 低于 '+row.level_a;
    return row.significant === false ? '尚未检出明确差异；先后不确定' : '无法判断';
}
function effectEstimateStatus(row) {
    if(row.status==='reference_coding')return '参考档（固定 0）';
    if(row.status==='ok')return '可估计';
    return row.status==='point_estimate_only'&&finite(row.coefficient??row.difference)?'仅点估计':'无法判断';
}
function effectSummary(features) {
    const estimated=features.filter(feature=>(feature.levels||[]).some(row=>!row.reference&&finite(row.coefficient))||
        (feature.pairwise||[]).some(row=>finite(row.difference))).length;
    const deletion=features.filter(feature=>feature.deletion_impact?.status==='ok').length;
    const significant=features.filter(feature=>feature.lrt?.status==='ok'&&feature.lrt?.significant===true).length;
    const uncalibrated=features.filter(feature=>feature.lrt?.status==='boundary_uncalibrated').length;
    const unavailable=features.filter(feature=>effectConclusion(feature.lrt)==='无法判断').length;
    return features.length+' 个特征 · '+estimated+' 个有点估计 · '+deletion+' 个有删除预测变化 · '+significant+' 个整体显著 · '+uncalibrated+' 个检验未校准 · '+unavailable+' 个无法判断（整体检验）';
}
function effectInterval(row, odds=false) {
    const lower=odds?row.or_ci_lower:row.ci_lower, upper=odds?row.or_ci_upper:row.ci_upper;
    return finite(lower)&&finite(upper)?'['+number(lower)+', '+number(upper)+']':'—';
}
function effectOddsTooltip(feature,pairs,row=null,interval=false){
    let direction;
    if(pairs)direction=row?'本行比较：'+row.level_b+' 相对 '+row.level_a+'（后档 / 前档）。':'比较方向：后档位 B 相对前档位 A。';
    else if(feature.kind==='numeric')direction='比较方向：数值增加一个 scale 后，相对增加前的条件。';
    else direction=row?'本行比较：'+row.level+' 相对参考档 '+feature.reference_level+'。':'比较方向：当前档位相对参考档 '+feature.reference_level+'。';
    return '固定其他条件，失效优势 odds = p/(1−p) = 失效率 ÷ 通过率。\n'+
        'OR = 对比条件的 odds ÷ 参考条件的 odds = exp(系数差)。\n'+direction+'\n'+
        'OR=1 表示优势相同；>1 更高，<1 更低。OR 是倍数，不是相减的变化量；OR=2 不代表失效率一定变为 2 倍。'+
        (interval?'\n此处是 OR 的逐项置信区间；包含 1 表示该区间允许无差异，最终显著性以 Holm 校正 p 值为准。仅点估计时没有已校准的区间或显著性结论。':'');
}
function effectOverviewTooltips(report){
    const threshold=number(report.alpha??(1-(report.confidence_level??.95)));
    return {
        statistic:'D = 2 ×（删去该特征并重拟合后的负对数似然 − 完整模型的负对数似然）。越大说明删去后拟合损失越大，不是失效率变化百分比。边界下可显示 D，但未经分布校准不能据此判断显著性。',
        df:'常规内部解下，两模型独立可估计参数数量之差决定 D 对应的卡方分布。L 档类别通常为 L−1，单个数值特征通常为 1；不是样本数。边界分布未校准时留空。',
        p_value:'假设该特征没有额外解释能力，出现当前或更大 D 的近似概率。越小，反对该假设的证据越强；尚未做多重检验校正，不是“该特征无影响的概率”。边界分布未校准时留空。',
        p_adjusted:'同一节点／批次全部特征的整体检验经 Holm 多重校正后的 p 值，用于控制多项检验带来的误报风险。最终显著性看此列。',
        significant:'有效检验的 Holm p ≤ '+threshold+'（当前阈值）判为显著，表示存在额外关联证据；不显著只表示证据不足，不等于没有影响。边界检验未校准时不报告显著性；“无法判断”请看检验说明。',
        mean_change:'删去该特征并重新拟合其余参数后，各有效布局实例的预测失效率绝对差等权平均。单位为百分点（pp），只表示变化幅度；不是实测误差或因果效果。',
        max_change:'同一次删去并重拟合后，有效布局实例中预测失效率绝对差的最大值，表示变化最大的实例。单位为百分点（pp），不表示所有实例都改变这么多，也不表示升降方向。',
    };
}
function effectPlot(parent, rows, pairs) {
    const usable=rows.filter(row=>finite(pairs?row.difference:row.coefficient));
    if(!usable.length){empty(parent,'没有可显示的系数或差值估计。');return;}
    const s=state(), range=pager(parent,usable.length,24,s.effectsPlotPage||1,value=>{s.effectsPlotPage=value;renderMain();});
    const shown=usable.slice(...range), host=el('div');parent.append(host);
    const width=Math.max(320,parent.clientWidth-4), left=Math.min(210,Math.max(90,width*.22)), right=width-24;
    const values=[0,...shown.flatMap(r=>[pairs?r.difference:r.coefficient,r.ci_lower,r.ci_upper].filter(finite))];
    let lo=Math.min(...values),hi=Math.max(...values),padding=(hi-lo||1)*.08;lo-=padding;hi+=padding;
    const x=value=>left+(value-lo)/(hi-lo)*(right-left), top=30, bottom=top+shown.length*51, height=bottom+48;
    const chart=svg('svg',{viewBox:'0 0 '+width+' '+height,width:'100%',role:'img','aria-label':pairs?'档位系数差及逐项置信区间':'档位系数及逐项置信区间'});
    chart.append(svg('rect',{x:left,y:top-16,width:right-left,height:bottom-top+16,fill:'none',stroke:'var(--line)'}));
    chart.append(svg('line',{x1:x(0),x2:x(0),y1:top-16,y2:bottom,stroke:'var(--muted)','stroke-width':1}));
    const label=(value,attrs)=>{const t=svg('text',{fill:'var(--ink)','font-size':12,...attrs});t.textContent=value;chart.append(t);return t;};
    shown.forEach((row,index)=>{
        const y=top+index*51+5, value=pairs?row.difference:row.coefficient;
        const name=pairs?row.level_b+' − '+row.level_a:String(row.level);
        const maxChars=Math.max(8,Math.floor((left-14)/13));
        label(name.length>maxChars?name.slice(0,maxChars-1)+'…':name,{x:left-10,y:y+4,'text-anchor':'end'});
        if(!pairs)chart.append(svg('rect',{x:Math.min(x(0),x(value)),y:y-7,width:Math.abs(x(value)-x(0)),height:14,fill:'var(--blue)',opacity:.3}));
        if(finite(row.ci_lower)&&finite(row.ci_upper)) {
            chart.append(svg('line',{x1:x(row.ci_lower),x2:x(row.ci_upper),y1:y,y2:y,stroke:'var(--blue)','stroke-width':2}));
            for(const bound of [row.ci_lower,row.ci_upper])chart.append(svg('line',{x1:x(bound),x2:x(bound),y1:y-5,y2:y+5,stroke:'var(--blue)','stroke-width':2}));
        }
        chart.append(svg('circle',{cx:x(value),cy:y,r:4,fill:'var(--blue)'}));
        const pointOnly=!row.reference&&!(finite(row.ci_lower)&&finite(row.ci_upper));
        const detail=label(number(value)+(row.reference?' · 参考编码':pointOnly?' · 仅点估计':''),{x:left+5,y:y+22});
        const title=svg('title');title.textContent=name+'：'+number(value)+'；逐项区间 '+effectInterval(row)+
            (pointOnly?'；区间不可用':'')+'；'+(pairs?effectPairConclusion(row):effectEstimateStatus(row))+(row.reason?'；'+row.reason:'');detail.append(title);
    });
    for(let i=0;i<=4;i++){const value=lo+(hi-lo)*i/4;label(Number(value.toPrecision(3)).toString(),{x:x(value),y:bottom+18,'text-anchor':i===0?'start':i===4?'end':'middle'});}
    label(pairs?'系数差（log-odds）；0 表示相同':'档位系数（log-odds）',{x:(left+right)/2,y:bottom+40,'text-anchor':'middle'});
    host.append(chart);
}
function renderEffects(parent) {
    const s=state(), g=groups[groupIndex], report=g.feature_effects;
    parent.append(el('h2','特征影响'));
    if(!report){empty(parent,'此历史结果未保存特征影响报告；请在应用中重新运行 TSK Analysis。');return;}
    if(report.reason)notice(parent,report.reason);
    if(report.warnings?.length)warnings(parent,report.warnings);
    const features=report.features||[];
    if(!features.length){empty(parent,report.reason||'本次没有可检验的特征。');return;}
    if(!s.effectsView)s.effectsView=groupIndex===initial.group_index&&['overall','levels','pairs'].includes(initial.effects_view)?initial.effects_view:'overall';
    if(!features.some(f=>f.feature===s.effectsFeature))s.effectsFeature=features.some(f=>f.feature===initial.effects_feature)?initial.effects_feature:features[0].feature;
    parent.append(el('p',effectSummary(features),'caption'));
    parent.append(el('p','关注单实例失效；共享主效应。可检验时，显著性使用 Holm 校正 p 值，阈值 '+number(report.alpha??1-(report.confidence_level||.95))+'。已计算的区间是逐项 '+pct(report.confidence_level||.95)+' 区间。边界下保留可辨识的点估计及可用的删除预测变化，未校准的检验不报告显著性。','muted'));
    if(report.status==='point_estimate_only')parent.append(el('p','共享 OR 由有信息的条件支持，不能视为已验证了零风险 TSK 的风险倍数。','caption'));
    subTabs(parent,[['overall','整体影响'],['levels','档位系数'],['pairs','档位两两比较']],s.effectsView,value=>{s.effectsView=value;s.effectsPlotPage=1;renderMain();});
    if(s.effectsView==='overall') {
        const rows=features.map(feature=>({...feature,...(feature.lrt||{}),deletion:feature.deletion_impact||{}}));
        const help=effectOverviewTooltips(report);
        const explain=(key,impact=false)=>({tooltip:help[key],cellTooltip:row=>{
            const outcome=impact?row.deletion:row;
            return help[key]+(outcome.status!=='ok'&&outcome.reason?'\n本项说明：'+outcome.reason:'');
        }});
        pagedTable(parent,rows,[
            {key:'feature',title:'特征'}, {key:'kind',title:'类型',format:r=>r.kind==='categorical'?'类别':'数值'},
            {key:'statistic',title:'似然比 D',numeric:true,format:r=>number(r.statistic),...explain('statistic')},
            {key:'df',title:'自由度',numeric:true,format:r=>number(r.df),...explain('df')},
            {key:'p_value',title:'原始 p',numeric:true,format:r=>number(r.p_value),...explain('p_value')},
            {key:'p_adjusted',title:'Holm p',numeric:true,format:r=>number(r.p_adjusted),...explain('p_adjusted')},
            {key:'significant',title:'整体结论',format:effectConclusion,...explain('significant')},
            {key:'mean_change',title:'删去后平均绝对变化',format:r=>pp(r.deletion.mean_abs_probability_change),...explain('mean_change',true)},
            {key:'max_change',title:'删去后最大绝对变化',format:r=>pp(r.deletion.max_abs_probability_change),...explain('max_change',true)},
            {key:'reason',title:'检验说明',wide:true},
            {key:'deletion_reason',title:'预测变化说明',wide:true,format:r=>r.deletion.reason||'—'}
        ],'特征',row=>{s.effectsFeature=row.feature;s.effectsView='levels';s.effectsPlotPage=1;renderMain();});
        parent.append(el('p','删除后变化按原有效拓扑实例等权统计，是两个拟合模型的预测差；不显著不等于没有作用，预测变化不构成因果或实测实例验证。','caption'));
        return;
    }
    const controls=el('div',null,'row'),select=el('select');select.setAttribute('aria-label','特征');
    features.forEach(feature=>{const option=el('option',feature.feature);option.value=feature.feature;select.append(option);});
    select.value=s.effectsFeature;select.addEventListener('change',()=>{s.effectsFeature=select.value;s.effectsPlotPage=1;renderMain();});
    controls.append(el('span','特征'),select);parent.append(controls);
    const feature=features.find(f=>f.feature===s.effectsFeature),pairs=s.effectsView==='pairs';
    if(feature.reason)notice(parent,feature.reason);
    parent.append(el('p',pairs?'方向为后档位减前档位；可检验时，比较结论按本特征内全部档位对比的 Holm 校正 p 值。仅点估计时，差异尚未检验。':'点估计顺序不保证真实顺序；参考档位 0 是编码约定，不代表零风险。数值特征按增加一个标准化尺度解释。','caption'));
    const rows=feature[pairs?'pairwise':'levels']||[];
    if(!rows.length){empty(parent,pairs&&feature.kind==='numeric'?'数值特征没有离散档位的两两比较。':'没有可显示的档位结果。');return;}
    effectPlot(parent,rows,pairs);
    const columns=pairs?[
        {key:'level_a',title:'前档位 A'},{key:'level_b',title:'后档位 B'},
        {key:'difference',title:'差值 B−A',numeric:true,format:r=>number(r.difference)}
    ]:[{key:'level',title:'档位／变化'},{key:'point_rank',title:'点估计序位',numeric:true},
        {key:'coefficient',title:'系数',numeric:true,format:r=>number(r.coefficient)},
        {key:'reference',title:'参考档位',format:r=>r.reference?'是':'否'}];
    columns.push({key:'se',title:'标准误',numeric:true,format:r=>number(r.se)},
        {key:'ci_lower',title:'逐项系数区间',format:r=>effectInterval(r)},
        {key:'odds_ratio',title:'OR',numeric:true,format:r=>number(r.odds_ratio),
            tooltip:effectOddsTooltip(feature,pairs),cellTooltip:r=>effectOddsTooltip(feature,pairs,r)},
        {key:'or_ci_lower',title:'逐项 OR 区间',format:r=>effectInterval(r,true),
            tooltip:effectOddsTooltip(feature,pairs,null,true),cellTooltip:r=>effectOddsTooltip(feature,pairs,r,true)});
    if(pairs)columns.push({key:'p_value',title:'原始 p',numeric:true,format:r=>number(r.p_value)},
        {key:'p_adjusted',title:'Holm p',numeric:true,format:r=>number(r.p_adjusted)},
        {key:'significant',title:'比较结论',format:effectPairConclusion});
    columns.push({key:'status',title:'状态',format:effectEstimateStatus},{key:'reason',title:'说明',wide:true});
    pagedTable(parent,rows,columns,pairs?'档位对比':'档位');
}
'''
