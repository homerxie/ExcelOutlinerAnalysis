"""Conditional feature inference for a frozen, independent-chain Logistic fit.

Instance risks are latent.  All refits retain the original noisy-OR binomial
chain likelihood; an instance row is never treated as an observed Fail label.
Ordinary Wald and likelihood-ratio results require a finite interior fit and
locally identifiable contrasts.  They are approximate, not causal evidence.
"""

from __future__ import annotations

from itertools import combinations
import math
from time import monotonic
from typing import Any, Callable, Mapping

import numpy as np
from scipy.optimize import linprog
from scipy.special import expit
from scipy.stats import chi2, norm

from .tsk_analysis import _feature_loss_and_derivative, _minimize_bound_constrained, _plain
from .tsk_logistic_boundary import KKT_TOLERANCE, LogisticBoundaryFit
from .tsk_prediction import _FrozenFit, _in_row_space


_METHODS = {
    "coefficient_interval": "joint_expected_fisher_information_wald_pointwise",
    "pairwise_test": "two_sided_wald_within_feature_holm",
    "overall_test": "drop_feature_refit_chain_binomial_likelihood_ratio_holm",
    "multiplicity": "unavailable_tests_count_as_p_one_in_each_prespecified_family",
    "deletion_impact": "in_sample_model_sensitivity_not_instance_validation",
    "finite_mle_guard": "sufficient_monotone_chain_separation_linear_program",
}


def _status(status: str, reason: str) -> dict[str, Any]:
    return {"status": status, "reason": reason}


def _empty_contrast(status: str, reason: str) -> dict[str, Any]:
    return {**_status(status, reason), "difference": None, "se": None,
            "ci_lower": None, "ci_upper": None, "odds_ratio": None,
            "or_ci_lower": None, "or_ci_upper": None,
            "p_value": None, "p_adjusted": None, "significant": None}


def _empty_lrt(status: str, reason: str, minimum: float) -> dict[str, Any]:
    return {**_status(status, reason), "df": None, "statistic": None,
            "p_value": None, "p_adjusted": None, "significant": None,
            "full_nll": minimum, "reduced_nll": None,
            "critical_value": None, "full_refit_nll": None}


def _empty_impact(status: str, reason: str, count: int) -> dict[str, Any]:
    return {**_status(status, reason), "weighting": "active_layout_instances_equal",
            "direction": "reduced_minus_full", "instance_count": count,
            "evaluated_instance_count": 0, "mean_abs_probability_change": None,
            "max_abs_probability_change": None, "rms_probability_change": None,
            "mean_signed_probability_change": None, "by_tsk": []}


def _exp(value: float) -> float | None:
    return math.exp(value) if value <= math.log(np.finfo(float).max) else None


def _estimable(fit: _FrozenFit, vector: np.ndarray) -> bool:
    return bool(fit.identifiable(vector) and _in_row_space(vector, fit.information_basis))


def _wald(fit: _FrozenFit, vector: np.ndarray, cutoff: float) -> dict[str, Any]:
    if not _estimable(fit, vector):
        return _empty_contrast("not_identifiable", "现有 Chain 观测无法独立识别这个系数差异。")
    difference = float(vector @ fit.theta)
    variance = float(vector @ fit.covariance @ vector)
    if not math.isfinite(variance) or variance <= 0:
        return _empty_contrast("information_unavailable", "该对比没有可用的正有限方差，不能给出常规检验。")
    se = math.sqrt(variance)
    low, high = difference - cutoff * se, difference + cutoff * se
    return {**_status("ok", "基于联合预期信息矩阵的近似双侧 Wald 检验；区间为逐项区间。"),
            "difference": difference, "se": se, "ci_lower": low, "ci_upper": high,
            "odds_ratio": _exp(difference), "or_ci_lower": _exp(low), "or_ci_upper": _exp(high),
            "p_value": float(2 * norm.sf(abs(difference / se))),
            "p_adjusted": None, "significant": None}


def _boundary_contrast(fit: _FrozenFit, vector: np.ndarray) -> dict[str, Any]:
    """Check a shared-beta contrast in the actual scaled-odds coordinates.

    Probability-query APIs require a TSK indicator and cannot be used for a
    coefficient contrast. Feasible flat directions must preserve the positive
    failure-chain hazards and the aggregate Pass contribution. Zero odds may
    move inward, rather than being fixed as if known nuisance parameters.
    """
    if not _in_row_space(vector, fit.design_basis):
        return _empty_contrast("not_identifiable", "现有设计无法独立识别这个系数差异。")
    dependence = np.vstack([fit.derivative[fit.k > 0], (fit.n - fit.k) @ fit.derivative])
    equality = dependence[np.max(np.abs(dependence), axis=1) > 0]
    if len(equality):
        equality = equality / np.max(np.abs(equality), axis=1)[:, None]
    column_norm = np.linalg.norm(equality, axis=0) if len(equality) else np.ones(fit.width)
    column_scale = np.divide(1., column_norm, out=np.ones(fit.width), where=column_norm > 0)
    equality = equality * column_scale[None, :]
    if len(equality):
        equality /= np.maximum(np.max(np.abs(equality), axis=1), 1e-300)[:, None]
    contrast = vector * column_scale
    contrast /= max(float(np.linalg.norm(contrast)), 1e-300)
    type_count = fit.boundary_engine.type_count
    bounds = [(0., 1.) if index < type_count and fit.theta[index] == 0 else (-1., 1.)
              for index in range(fit.width)]
    try:
        arguments = dict(A_eq=equality if len(equality) else None,
                         b_eq=np.zeros(len(equality)) if len(equality) else None,
                         bounds=bounds, method="highs")
        low, high = linprog(contrast, **arguments), linprog(-contrast, **arguments)
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError):
        return _empty_contrast("identifiability_check_failed", "边界条件下的可辨识检查未完成，暂不报告该效应。")
    if not low.success or not high.success:
        return _empty_contrast("identifiability_check_failed", "边界条件下的可辨识检查未完成，暂不报告该效应。")
    if max(abs(low.fun), abs(high.fun)) > 1e-7:
        return _empty_contrast("not_identifiable", "现有 Chain 观测无法独立识别这个系数差异。")
    difference = float(vector @ fit.theta)
    if not math.isfinite(difference):
        return _empty_contrast("nonfinite_effect", "该共享特征对比没有有限点估计。")
    result = _empty_contrast("point_estimate_only", "零风险边界下保留局部可辨识的有限点估计；标准误、区间和显著性尚未校准。")
    result.update(difference=difference, odds_ratio=_exp(difference))
    return result


def _holm(rows: list[dict[str, Any]], alpha: float) -> None:
    """Keep every predeclared comparison in the family, including unavailable ones."""
    ordered = sorted(enumerate(rows), key=lambda item: (
        item[1]["p_value"] if item[1].get("p_value") is not None else 1., item[0]))
    previous = 0.
    for rank, (_, row) in enumerate(ordered):
        p = row.get("p_value")
        adjusted = min(1., max(previous, (len(rows) - rank) * (p if p is not None else 1.)))
        previous = adjusted
        if p is not None and row.get("status") == "ok":
            row["p_adjusted"] = adjusted
            row["significant"] = bool(adjusted <= alpha)


def _rows_estimable(fit: _FrozenFit) -> np.ndarray:
    matrix = fit.design
    if fit.boundary_engine is not None:
        return np.asarray([fit.identifiable(vector) for vector in matrix], dtype=bool)
    valid = np.ones(len(matrix), dtype=bool)
    sizes = np.maximum(np.linalg.norm(matrix, axis=1), 1e-15)
    for basis in (fit.design_basis, fit.likelihood_basis, fit.information_basis):
        residual = matrix - (matrix @ basis) @ basis.T
        valid &= np.linalg.norm(residual, axis=1) <= 1e-7 * sizes
    return valid


def _change_metrics(delta: np.ndarray) -> dict[str, Any]:
    return {"mean_abs_probability_change": float(np.mean(np.abs(delta))),
            "max_abs_probability_change": float(np.max(np.abs(delta))),
            "rms_probability_change": float(np.sqrt(np.mean(delta * delta))),
            "mean_signed_probability_change": float(np.mean(delta))}


def _deletion_impact(full: _FrozenFit, reduced: _FrozenFit) -> dict[str, Any]:
    valid = _rows_estimable(full) & _rows_estimable(reduced)
    def probabilities(fit):
        if fit.boundary_engine is not None:
            return np.asarray([fit.boundary_engine.probability(fit.theta, vector) for vector in fit.design])
        return expit(fit.design @ fit.theta)

    delta = probabilities(reduced) - probabilities(full)
    reason = "原有效拓扑中每个实例等权比较；这是模型预测变化，不是实测实例验证或等效性证明。"
    result = _empty_impact("ok", reason, len(delta))
    result["evaluated_instance_count"] = int(valid.sum())
    if valid.all() and len(delta):
        result.update(_change_metrics(delta))
    else:
        result.update(_status("not_identifiable", "部分实例风险不可独立识别，未给出全部实例的变化汇总；可查看可识别 TSK。"))
    for index, tsk_id in enumerate(full.context["type_ids"]):
        mask = full.design[:, index] != 0
        row = {"tsk_id": tsk_id, "instance_count": int(mask.sum()),
               "evaluated_instance_count": int(valid[mask].sum()),
               "mean_abs_probability_change": None, "max_abs_probability_change": None,
               "rms_probability_change": None, "mean_signed_probability_change": None}
        if mask.any() and valid[mask].all():
            row.update(_status("ok", reason), **_change_metrics(delta[mask]))
        else:
            row.update(_status("not_identifiable", "该 TSK 的部分实例风险不可独立识别，变化量不予报告。"))
        result["by_tsk"].append(row)
    return result


def _fit_once(design, chain_index, n, k, start, bound, heartbeat):
    def objective(theta):
        heartbeat()
        value, gradient, _, _ = _feature_loss_and_derivative(design, chain_index, n, k, theta)
        return value, gradient

    result, converged = _minimize_bound_constrained(
        objective, np.clip(start, -bound, bound), float(n.sum()), -bound, bound)
    return float(result.fun), np.asarray(result.x), bool(converged)


def _refit_reduced(fit: _FrozenFit, keep: np.ndarray, heartbeat):
    matrix = fit.design[:, keep]
    type_count = len(fit.context["type_ids"])
    bound = float(fit.context.get("logistic_coefficient_bound", 35.))
    rate = np.clip(fit.k.sum() / max(fit.n.sum(), 1.), 1e-5, .95)
    count = max(len(fit.design) / max(len(fit.n), 1), 1.)
    component = -np.expm1(np.log1p(-rate) / count)
    baseline = np.zeros(int(keep.sum()))
    baseline[:type_count] = math.log(component / (1 - component))
    starts = [fit.theta[keep], baseline]
    for sign in (-1., 1.):
        candidate = baseline.copy()
        candidate[type_count:] += sign * .5
        if not any(np.array_equal(candidate, start) for start in starts):
            starts.append(candidate)
    results = [_fit_once(matrix, fit.chain_index, fit.n, fit.k, start, bound, heartbeat) for start in starts]
    finite = [row for row in results if math.isfinite(row[0]) and np.all(np.isfinite(row[1]))]
    if not finite:
        return math.inf, starts[0], False
    return min(finite, key=lambda row: row[0])


def _likelihood_tolerance(value: float) -> float:
    return max(1e-7, abs(value) * np.finfo(float).eps * 64)


def _monotone_separation_certificate(design, chain_index, n, k) -> dict[str, Any]:
    """Find a sufficient certificate that no finite Logistic MLE exists.

    A direction holds every instance in mixed-outcome chains fixed, decreases
    logits in all-Pass chains, and increases them in all-Fail chains.  If one
    inequality is strict, moving along the direction strictly improves the
    noisy-OR likelihood at *every* finite parameter vector.  This includes
    both type-only and shared-feature separation, without a coefficient cap.
    It is a sufficient certificate, not an exhaustive finite-MLE theorem for
    the nonlinear aggregated likelihood.  Numerical LP failure is not a pass.
    """
    passed = k[chain_index] == 0
    failed = k[chain_index] == n[chain_index]
    pure = passed | failed
    if not np.any(pure):
        return _status("no_certificate", "所有有效 Chain 均包含 Pass 和 Fail，未出现该单调分离证书。")
    # Row scaling preserves each constraint while keeping the LP independent
    # of a large numerical feature unit. Every valid row has a TSK indicator.
    scaled = design / np.maximum(np.linalg.norm(design, axis=1), 1e-15)[:, None]
    signs = np.where(passed[pure], 1., -1.)
    inequality = signs[:, None] * scaled[pure]
    equality = scaled[~pure]
    objective = inequality.sum(axis=0)
    try:
        solution = linprog(
            objective, A_ub=inequality, b_ub=np.zeros(len(inequality)),
            A_eq=equality if len(equality) else None,
            b_eq=np.zeros(len(equality)) if len(equality) else None,
            bounds=[(-1., 1.)] * design.shape[1], method="highs",
            options={"primal_feasibility_tolerance": 1e-9, "dual_feasibility_tolerance": 1e-9},
        )
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        return {**_status("check_failed", "分离方向检查出现数值异常，不能认定满足常规有限参数推断条件。"),
                "diagnostic_error": str(error)}
    if not solution.success or solution.x is None or not np.all(np.isfinite(solution.x)):
        return {**_status("check_failed", "分离方向线性规划未可靠完成，不能认定满足常规有限参数推断条件。"),
                "diagnostic_error": str(solution.message)}
    direction = np.asarray(solution.x)
    margins = inequality @ direction
    if (np.max(margins, initial=0.) > 1e-8
            or np.max(np.abs(equality @ direction), initial=0.) > 1e-8
            or np.max(np.abs(direction), initial=0.) > 1 + 1e-8):
        return _status("check_failed", "分离方向的数值约束复核未通过，常规推断暂不可用。")
    improvement = float(objective @ direction)
    threshold = 1e-8 * max(float(np.linalg.norm(objective, ord=1)), 1.)
    if improvement < -threshold:
        return {**_status("separation", "发现单调分离方向：至少一条纯 Pass/Fail 链的似然可持续改善，有限系数最优解不存在。"),
                "direction": direction.tolist(), "objective_value": improvement}
    return _status("no_certificate", "未发现该充分单调分离证书；这不构成有限或唯一全局最优解的证明。")


def _drop_feature(fit: _FrozenFit, feature: str, indices: list[int], alpha: float, heartbeat):
    minimum = fit.minimum
    count = len(fit.design)
    separation_check = None

    def unavailable(status, reason):
        lrt = _empty_lrt(status, reason, minimum)
        if separation_check is not None:
            lrt["finite_mle_check"] = separation_check
        return lrt, _empty_impact(status, reason, count)

    if not indices:
        return unavailable("no_variation", "该特征只有一个档位，没有可删除的效应参数，无法检验档位差异。")
    if not all(_estimable(fit, np.eye(fit.width)[index]) for index in indices):
        return unavailable("not_identifiable", "该特征的整组效应不能与其他参数独立区分，不能报告普通整体显著性。")
    keep = np.ones(fit.width, dtype=bool)
    keep[indices] = False
    separation_check = _monotone_separation_certificate(fit.design[:, keep], fit.chain_index, fit.n, fit.k)
    if separation_check["status"] == "separation":
        return unavailable("reduced_nonfinite_mle", "删组模型存在分离方向、没有有限系数最优解，普通整体检验与删除影响不予报告。")
    if separation_check["status"] != "no_certificate":
        return unavailable("reduced_finite_mle_check_failed", separation_check["reason"])
    reduced_nll, theta, converged = _refit_reduced(fit, keep, heartbeat)
    tolerance = _likelihood_tolerance(minimum)
    if math.isfinite(reduced_nll) and reduced_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "删组模型得到更低损失，说明完整模型未建立可信最优解；本次推断全部停用。")
        lrt["reduced_nll"] = reduced_nll
        return lrt, impact
    if not converged or not math.isfinite(reduced_nll):
        return unavailable("reduced_fit_not_converged", "删去该特征后重新拟合未收敛，不能计算可靠的整体检验。")
    bound = float(fit.context.get("logistic_coefficient_bound", 35.))
    if np.any(np.abs(theta) >= bound - .1):
        return unavailable("reduced_fit_boundary", "删组模型参数触及数值边界，普通卡方近似不适用。")
    # The reduced optimum supplies an independent start for the full model.
    # Any substantially better feasible value invalidates inference around the
    # stored candidate, even if that new optimization has not yet converged.
    lifted = np.zeros(fit.width)
    lifted[keep] = theta
    audited_nll, _, _ = _fit_once(fit.design, fit.chain_index, fit.n, fit.k, lifted, bound, heartbeat)
    if not math.isfinite(audited_nll):
        return unavailable("full_refit_check_failed", "从删组解启动的完整模型复核未得到有限损失，本项整体检验暂不可用。")
    if math.isfinite(audited_nll) and audited_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "从删组结果重新启动完整模型找到更低损失；本次推断全部停用，请重新拟合。")
        lrt.update(reduced_nll=reduced_nll, full_refit_nll=audited_nll)
        return lrt, impact
    reduced_context = dict(fit.context)
    type_count = len(fit.context["type_ids"])
    reduced_context.update(
        design=fit.design[:, keep], coefficients=theta, negative_log_likelihood=reduced_nll,
        converged=True, clipped=False, boundary_fit=None,
        coefficient_columns=[column for index, column in enumerate(fit.context["coefficient_columns"], type_count) if keep[index]],
        categorical_features={name: value for name, value in fit.context.get("categorical_features", {}).items() if name != feature},
    )
    reduced = _FrozenFit(reduced_context)
    degrees = fit.information_basis.shape[1] - reduced.information_basis.shape[1]
    if degrees != len(indices) or degrees <= 0:
        return unavailable("rank_changed", "完整模型与删组模型的信息秩不满足常规嵌套检验条件，未套用卡方分布。")
    statistic = max(0., 2 * (reduced_nll - minimum))
    lrt = {**_status("ok", "保持相同 Chain 观测，删去整组参数后重拟合；显著性采用本组特征间 Holm 校正。"),
           "df": degrees, "statistic": statistic, "p_value": float(chi2.sf(statistic, degrees)),
           "p_adjusted": None, "significant": None, "full_nll": minimum, "reduced_nll": reduced_nll,
           "critical_value": float(chi2.ppf(1 - alpha, degrees)), "full_refit_nll": audited_nll,
           "finite_mle_check": separation_check}
    return lrt, _deletion_impact(fit, reduced)


def _boundary_logit_start(engine: LogisticBoundaryFit, params: np.ndarray) -> np.ndarray:
    """Finite optimizer seeds, never reported as estimates of zero odds."""
    type_count = engine.type_count
    exposure = np.maximum(engine.counts.T @ engine.n, 1.)
    values = np.asarray(params, dtype=float).copy()
    positive = values[:type_count] > 0
    intercepts = -np.maximum(30., np.log(exposure) + 10.)
    intercepts[positive] = np.log(values[:type_count][positive]) + np.log(engine.odds_scale[positive])
    values[:type_count] = intercepts
    return values


def _boundary_refit(fit: _FrozenFit, design: np.ndarray, start: np.ndarray, heartbeat):
    engine = LogisticBoundaryFit(
        design, fit.chain_index, fit.n, fit.k, len(fit.context["type_ids"]),
        coefficient_bound=fit.boundary_engine.coefficient_bound,
        progress_callback=lambda *_: heartbeat())
    engine.fit(start)
    return engine


def _boundary_separation(engine: LogisticBoundaryFit, params: np.ndarray) -> dict[str, Any]:
    # Type-only negative recession is the supported zero-odds closure. Remove
    # only its exact-zero instances; retain ordinary checks on every positive
    # instance, including positive shared-feature recession in all-Fail chains.
    active = np.asarray(params)[engine.type_index] > 0
    return _monotone_separation_certificate(
        engine.design[active], engine.chain_index[active], engine.n, engine.k)


def _drop_boundary_feature(fit: _FrozenFit, feature: str, indices: list[int], heartbeat):
    """Boundary-aware descriptive deletion fit; no chi-square calibration.

    Both engines optimize *all* nonnegative type odds, including the types
    whose saved estimates are zero. Coefficient identifiability does not gate
    this descriptive refit: identified predictions can survive aliased effects.
    """
    minimum, count = fit.minimum, len(fit.design)

    def unavailable(status, reason):
        return _empty_lrt(status, reason, minimum), _empty_impact(status, reason, count)

    if not indices:
        return unavailable("no_variation", "该特征只有一个档位，没有可删除的效应参数，无法检验档位差异。")
    keep = np.ones(fit.width, dtype=bool)
    keep[indices] = False
    start = _boundary_logit_start(fit.boundary_engine, fit.theta)
    engine = _boundary_refit(fit, fit.design[:, keep], start[keep], heartbeat)
    state = engine.state
    reduced_nll = float(state["minimum"]) if state["minimum"] is not None else math.inf
    tolerance = _likelihood_tolerance(minimum)
    if reduced_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "边界删组模型得到更低损失，说明完整模型未建立可信最优解；本次效应分析全部停用。")
        lrt["reduced_nll"] = reduced_nll
        return lrt, impact
    if not state.get("converged") or state.get("feature_clipped") or not math.isfinite(reduced_nll):
        lrt, impact = unavailable("reduced_fit_not_converged", "边界删组拟合未建立可靠收敛或存在发散特征，删除影响暂不可用。")
        lrt["reduced_fit_validation"] = state.get("validation", {})
        return lrt, impact
    separation = _boundary_separation(engine, np.asarray(state["params"]))
    if separation["status"] != "no_certificate":
        status = "reduced_nonfinite_mle" if separation["status"] == "separation" else "reduced_finite_mle_check_failed"
        lrt, impact = unavailable(status, "边界删组模型的有限共享效应检查未通过，删除影响暂不可用。")
        lrt["finite_mle_check"] = separation
        return lrt, impact
    lifted = np.zeros(fit.width)
    lifted[keep] = _boundary_logit_start(engine, np.asarray(state["params"]))
    audited = _boundary_refit(fit, fit.design, lifted, heartbeat)
    audited_nll = audited.state["minimum"]
    if audited_nll is not None and audited_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "从边界删组结果重启完整模型找到更低损失；本次效应分析全部停用，请重新拟合。")
        lrt.update(reduced_nll=reduced_nll, full_refit_nll=audited_nll)
        return lrt, impact
    if not audited.state.get("converged") or audited_nll is None or not math.isfinite(audited_nll):
        return unavailable("full_refit_check_failed", "从边界删组解启动的完整模型复核未可靠收敛，本项删除影响暂不可用。")
    if _boundary_separation(audited, np.asarray(audited.state["params"]))["status"] != "no_certificate":
        return unavailable("full_refit_check_failed", "边界完整模型重拟合的有限共享效应检查未通过，本项删除影响暂不可用。")
    reduced_context = dict(fit.context)
    type_count = engine.type_count
    reduced_context.update(
        design=fit.design[:, keep], coefficients=_boundary_logit_start(engine, np.asarray(state["params"])),
        negative_log_likelihood=reduced_nll, converged=True, clipped=False, boundary_fit=state,
        coefficient_columns=[column for index, column in enumerate(fit.context["coefficient_columns"], type_count) if keep[index]],
        categorical_features={name: value for name, value in fit.context.get("categorical_features", {}).items() if name != feature},
    )
    reduced = _FrozenFit(reduced_context)
    lrt = {**_empty_lrt("boundary_uncalibrated", "采用非负 odds 边界模型重拟合；仅报告似然损失与原始 LR 统计量，参考分布尚未校准，不能判断显著性。", minimum),
           "statistic": max(0., 2 * (reduced_nll - minimum)), "reduced_nll": reduced_nll,
           "full_refit_nll": audited_nll}
    return lrt, _deletion_impact(fit, reduced)


def _boundary_validation(fit: _FrozenFit, heartbeat) -> tuple[str, str] | None:
    """Recheck saved feasibility and finite shared effects without logit caps."""
    engine = fit.boundary_engine
    state = engine.state
    value, gradient, _, derivative = engine.evaluate(fit.theta)
    if (not math.isfinite(value) or abs(value - fit.minimum) > _likelihood_tolerance(fit.minimum)
            or state.get("minimum") is None
            or abs(float(state["minimum"]) - fit.minimum) > _likelihood_tolerance(fit.minimum)):
        return "fit_not_converged", "零风险边界快照的参数与似然损失不一致，请重新拟合。"
    if np.any(np.abs(fit.theta[engine.type_count:]) >= engine.coefficient_bound - .1):
        return "boundary", "共享特征触及数值边界，不能把截断系数当作有限效应估计。"
    bounds = [(0., None)] * engine.type_count + [(-engine.coefficient_bound, engine.coefficient_bound)] * (fit.width - engine.type_count)
    if engine._kkt(fit.theta, gradient, derivative, bounds) >= KKT_TOLERANCE:
        audited = _boundary_refit(fit, fit.design, _boundary_logit_start(engine, fit.theta), heartbeat)
        audited_nll = audited.state.get("minimum")
        if audited_nll is not None and audited_nll < fit.minimum - _likelihood_tolerance(fit.minimum):
            return "full_fit_not_optimal", "重新启动边界完整模型找到更低损失；本次效应分析全部停用，请重新拟合。"
        return "fit_not_converged", "零风险边界参数未通过单侧驻点复核，不能报告稳定的效应点估计。"
    return None


def _unavailable_feature(feature: dict, status: str, reason: str) -> None:
    feature.update(_status(status, reason))
    for row in feature["levels"]:
        if row["reference"]:
            continue
        row.update(_empty_contrast(status, reason), coefficient=None, point_rank=None)
    for row in feature["levels"]:
        row["point_rank"] = None
    for row in feature["pairwise"]:
        row.update(_empty_contrast(status, reason))
    feature["lrt"].update(_status(status, reason), statistic=None, p_value=None,
                          p_adjusted=None, significant=None, critical_value=None)
    feature["deletion_impact"] = _empty_impact(status, reason, feature["deletion_impact"]["instance_count"])


def build_tsk_feature_effects(
    context: Mapping[str, Any], *, confidence_level: float | None = None,
    progress_callback: Callable[[float, str], None] | None = None,
) -> dict[str, Any]:
    """Return JSON-safe inference and descriptive deletion sensitivity, without mutation.

    Holm families are declared before testing: all selected features for LRTs,
    and every unordered pair of declared levels within each category.  A test
    that cannot be computed stays in its family with a placeholder p of one.
    Reference zeros are encoding conventions, never independently estimated
    effects.  Pointwise confidence intervals are not Holm-adjusted intervals.
    """
    if not isinstance(context, Mapping):
        raise ValueError("A frozen TSK Logistic context is required.")
    confidence = float(context.get("confidence_level", .95) if confidence_level is None else confidence_level)
    if not math.isfinite(confidence) or not 0 < confidence < 1:
        raise ValueError("Confidence level must be strictly between zero and one.")
    categorical = context.get("categorical_features", {})
    columns = list(context.get("coefficient_columns", []))
    type_count = len(context.get("type_ids", []))
    if any(not isinstance(column, (tuple, list)) or len(column) != 2 for column in columns):
        raise ValueError("Invalid fitted feature coefficient columns.")
    if len(columns) + type_count != len(context.get("coefficients", [])):
        raise ValueError("Feature coefficient columns do not match the fitted parameters.")
    names = list(dict.fromkeys([*(column[0] for column in columns), *categorical]))
    progress = progress_callback or (lambda *_: None)
    progress(0, "计算特征效应与整体删组检验…")
    # Positive-odds snapshots retain the ordinary finite-logit path. Active
    # zeros instead use the saved scaled-odds parameters, never capped logits.
    ordinary_context = dict(context)
    ordinary_context["boundary_fit"] = None
    fit = _FrozenFit(ordinary_context)
    alpha = 1 - confidence
    result = {"version": 1, **_status("ok", "已完成特征效应分析。"),
              "confidence_level": confidence, "alpha": alpha,
              "model_scope": "共享主效应 Logistic：控制其他条件后比较单实例风险；不同 TSK 共用档位系数与 OR。",
              "methods": dict(_METHODS), "features": [],
              "warnings": [
                  "系数和 OR 是条件关联；OR 不是失效率倍数，也不是因果影响。",
                  "区间是未作多重比较校正的逐项区间；显著与否依据 Holm 校正后的 p 值。",
                  "未检出显著差异不代表相同或等效，点估计顺序也不代表顺序已经证实。",
                  "检验采用大样本近似并假设 Chain 观测独立，尚未修正同一 die/wafer 内的相关性。",
                  "可辨识检查基于设计及局部信息；多起点检查不保证全局唯一最优。",
                  "删除影响仅描述原有效布局上的模型预测变化，不自动给出可安全删除或等效结论。",
              ]}
    boundary = context.get("boundary_fit") or {}
    boundary_mode = bool(boundary.get("zero_type_indices"))
    invalid = None
    if boundary_mode:
        try:
            fit = _FrozenFit(context)
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError):
            invalid = ("boundary", "零风险边界快照不完整或无效，请重新拟合后计算特征影响。")
    if invalid is None and (not fit.valid_fit or (boundary and (not boundary.get("converged") or boundary.get("feature_clipped")))):
        invalid = ("fit_not_converged", "完整模型未建立稳定收敛的有限解，不能给出常规效应推断。")
    elif invalid is None and boundary_mode:
        try:
            invalid = _boundary_validation(fit, lambda: progress(2, "复核零风险边界完整模型…"))
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError):
            invalid = ("fit_not_converged", "零风险边界完整模型复核遇到数值异常，暂不报告效应。")
    elif invalid is None and np.any(np.abs(fit.theta) >= float(context.get("logistic_coefficient_bound", 35.)) - .1):
        invalid = ("boundary", "完整模型参数触及数值边界，不能把截断系数当作有限效应估计。")
    if invalid:
        result["finite_mle_check"] = _status("not_checked", "完整模型已有不可用状态，不继续分离检查。")
    else:
        result["finite_mle_check"] = (_boundary_separation(fit.boundary_engine, fit.theta) if boundary_mode else
                                      _monotone_separation_certificate(fit.design, fit.chain_index, fit.n, fit.k))
        if result["finite_mle_check"]["status"] == "separation":
            invalid = ("nonfinite_mle", "数据存在分离方向，系数可趋向无穷而继续改善似然；即使优化器称已收敛，也不能报告普通 Wald 或 LRT。")
        elif result["finite_mle_check"]["status"] != "no_certificate":
            invalid = ("finite_mle_check_failed", result["finite_mle_check"]["reason"])
    if boundary_mode:
        result["methods"].update(
            coefficient_interval="unavailable_at_zero_odds_boundary",
            pairwise_test="unavailable_at_zero_odds_boundary",
            overall_test="boundary_odds_drop_feature_raw_likelihood_ratio_uncalibrated",
            contrast_identifiability="scaled_odds_local_feasible_flat_direction_check",
        )
        result["warnings"][1] = "完整模型含零风险边界：仅保留可辨识的有限效应点估计及可靠的删除预测变化；不提供未经校准的标准误、区间或显著性。"
        result["warnings"][3] = "边界 LR 仅是原始似然比较统计量，不使用普通卡方分布或固定混合卡方分布计算 p 值。"
        result["warnings"].append("模型仍假设 Chain 观测独立，尚未修正同一 die/wafer 内的相关性。")
        result["warnings"].append("共享 OR 由有信息的 TSK 支持；零风险 TSK 的两档 odds 同为 0，不能将共享 OR 解释为该类型已被数据独立证实的 0/0 比值。")
    cutoff = float(norm.ppf((1 + confidence) / 2))
    for feature_index, name in enumerate(names):
        base_progress = 5 + 90 * feature_index / max(len(names), 1)
        progress(base_progress, f"特征 {name}：计算档位对比并重拟合删组模型…")
        last_update = monotonic()

        def heartbeat():
            nonlocal last_update
            if monotonic() - last_update >= .25:
                progress(base_progress, f"特征 {name}：正在重拟合与核查最优解…")
                last_update = monotonic()

        indices = [type_count + index for index, column in enumerate(columns) if column[0] == name]
        definition = categorical.get(name)
        reference = str(definition["reference"]) if definition else None
        feature = {"feature": name, "kind": "categorical" if definition else "numeric",
                   "reference_level": reference, **_status("ok", "效应可计算；是否显著请查看对应检验。"),
                   "levels": [], "pairwise": [],
                   "lrt": _empty_lrt("unavailable", "尚未计算整体检验。", fit.minimum),
                   "deletion_impact": _empty_impact("unavailable", "尚未计算删除影响。", len(fit.design))}
        vectors = {}
        levels = [str(level) for level in definition["levels"]] if definition else ["增加一个 scale"]
        column_map = {str(column[1]): type_count + index for index, column in enumerate(columns) if column[0] == name}
        for level in levels:
            vector = np.zeros(fit.width)
            is_reference = bool(definition and level == reference)
            if not is_reference:
                index = column_map.get(level) if definition else (indices[0] if len(indices) == 1 else None)
                if index is None:
                    raise ValueError(f"Missing fitted coefficient for {name!r}, {level!r}.")
                vector[index] = 1.
            vectors[level] = vector
            if is_reference:
                data = _empty_contrast("reference_coding", "参考档固定编码为 0、OR 为 1；没有独立标准误，不代表失效率为 0。")
                data.update(difference=0., odds_ratio=1.)
            elif invalid:
                data = _empty_contrast(*invalid)
            elif boundary_mode:
                data = _boundary_contrast(fit, vector)
            else:
                data = _wald(fit, vector, cutoff)
            row = {"level": level, "reference": is_reference, **data,
                   "coefficient": data["difference"], "point_rank": None}
            if not definition:
                row.update(context.get("numeric_scaling", {}).get(name, {}))
            feature["levels"].append(row)
        if definition:
            for level_a, level_b in combinations(levels, 2):
                vector = vectors[level_b] - vectors[level_a]
                data = (_empty_contrast(*invalid) if invalid else
                        _boundary_contrast(fit, vector) if boundary_mode else _wald(fit, vector, cutoff))
                feature["pairwise"].append({"level_a": level_a, "level_b": level_b,
                                            "contrast": "b_minus_a", **data})
            _holm(feature["pairwise"], alpha)
            if all(row["coefficient"] is not None for row in feature["levels"]):
                rank, previous = 0, None
                for row in sorted(feature["levels"], key=lambda item: item["coefficient"]):
                    if previous is None or row["coefficient"] != previous:
                        rank += 1
                    row["point_rank"] = rank
                    previous = row["coefficient"]
        if invalid:
            feature["lrt"] = _empty_lrt(*invalid, fit.minimum)
            feature["deletion_impact"] = _empty_impact(*invalid, len(fit.design))
            _unavailable_feature(feature, *invalid)
        else:
            try:
                feature["lrt"], feature["deletion_impact"] = (
                    _drop_boundary_feature(fit, name, indices, heartbeat) if boundary_mode else
                    _drop_feature(fit, name, indices, alpha, heartbeat))
            except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                reason = "该特征的删组拟合或信息矩阵计算遇到数值异常，整体检验与删除影响暂不可用。"
                feature["lrt"] = _empty_lrt("numerical_error", reason, fit.minimum)
                feature["lrt"]["diagnostic_error"] = str(error)
                feature["deletion_impact"] = _empty_impact("numerical_error", reason, len(fit.design))
            if boundary_mode and feature["lrt"]["status"] == "boundary_uncalibrated":
                feature.update(_status("point_estimate_only", "零风险边界下逐项保留可辨识点估计及删除预测变化；显著性尚未校准。"))
            elif feature["lrt"]["status"] != "ok":
                feature.update(_status(feature["lrt"]["status"], feature["lrt"]["reason"]))
        result["features"].append(feature)
        if feature["lrt"]["status"] == "full_fit_not_optimal":
            invalid = ("full_fit_not_optimal", feature["lrt"]["reason"])
    if invalid:
        result.update(_status(*invalid))
        for feature in result["features"]:
            _unavailable_feature(feature, *invalid)
    else:
        _holm([feature["lrt"] for feature in result["features"]], alpha)
        if not names:
            result.update(_status("no_features", "当前模型没有可检验的特征。"))
        elif boundary_mode and all(feature["status"] == "point_estimate_only" for feature in result["features"]):
            result.update(_status("point_estimate_only", "零风险边界下已完成可辨识效应点估计与删除预测变化；标准误、区间和显著性尚未校准。"))
        elif any(feature["status"] != "ok" for feature in result["features"]):
            result.update(_status("partial", "部分特征无法进行常规检验，请查看各项原因。"))
    progress(100, "特征效应分析完成。")
    return _plain(result)
