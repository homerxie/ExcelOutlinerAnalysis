"""Bind the saved feature inference report; fitting never runs in this widget."""
from __future__ import annotations

import math

from PySide6.QtCore import QSignalBlocker, QSortFilterProxyModel, Qt
from PySide6.QtWidgets import QHeaderView, QWidget

from .tsk_feature_panel import _FeatureTableModel
from .ui_tsk_feature_effects_panel import Ui_TskFeatureEffectsPanelForm


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _number(value):
    return f"{value:.6g}" if _finite(value) else ""


class _FeatureEffectsTableModel(_FeatureTableModel):
    """Expose form-defined header help without changing the shared table model."""

    def __init__(self, headers, parent=None):
        super().__init__(headers, parent)
        self.header_tooltips = {}

    def set_header_tooltips(self, values):
        self.header_tooltips = dict(values)
        self.headerDataChanged.emit(Qt.Horizontal, 0, self.columnCount() - 1)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.ToolTipRole:
            return self.header_tooltips.get(section)
        return super().headerData(section, orientation, role)


class TskFeatureEffectsPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskFeatureEffectsPanelForm()
        self.ui.setupUi(self)
        self.report = {}
        self.features = []
        self._binding = False
        self.overview_model, self.overview_proxy = self._attach_table(self.ui.overviewTableView)
        self.levels_model, self.levels_proxy = self._attach_table(self.ui.levelsTableView)
        self.pairwise_model, self.pairwise_proxy = self._attach_table(self.ui.pairwiseTableView)
        self.ui.featureComboBox.currentIndexChanged.connect(self._feature_changed)
        self.ui.overviewTableView.selectionModel().currentRowChanged.connect(self._overview_selected)
        self.ui.levelOrderComboBox.currentIndexChanged.connect(self._feature_changed)

    def _attach_table(self, table):
        model = _FeatureEffectsTableModel(table.property("columnHeaders"), self)
        proxy = QSortFilterProxyModel(table)
        proxy.setSourceModel(model)
        proxy.setSortRole(Qt.UserRole)
        table.setModel(proxy)
        table.sortByColumn(-1, Qt.AscendingOrder)
        table.horizontalHeader().setResizeContentsPrecision(100)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        return model, proxy

    @staticmethod
    def _cell(value, *, numeric=False, pp=False, tooltip=""):
        raw = value * 100 if pp and _finite(value) else value
        display = _number(raw) if numeric or pp else str(value if value is not None else "")
        return display, raw, tooltip

    def _interval(self, row, prefix="", *, tooltip=""):
        lower, upper = row.get(prefix + "ci_lower"), row.get(prefix + "ci_upper")
        if not (_finite(lower) and _finite(upper)):
            return self._cell(None, tooltip=tooltip)
        return self._cell(self.property("intervalFormat").format(lower=_number(lower), upper=_number(upper)), tooltip=tooltip)

    def _or_tooltips(self, feature, row=None, *, pair=False):
        if pair:
            direction = (self.property("pairOrTooltipFormat").format(
                a=row.get("level_a", ""), b=row.get("level_b", "")) if row is not None
                else self.property("pairOrHeaderText"))
        elif feature.get("kind") == "numeric":
            level = row if row is not None else next(iter(feature.get("levels") or []), {})
            direction = self.property("numericOrTooltipFormat").format(
                feature=feature.get("feature", ""), scale=_number(level.get("scale", feature.get("scale"))))
        else:
            values = {"reference": feature.get("reference_level", "")}
            if row is not None:
                values["level"] = row.get("level", "")
            direction = self.property("levelOrTooltipFormat" if row is not None else "levelOrHeaderFormat").format(**values)
        tooltip = "\n".join((str(direction), str(self.property("oddsExplanation"))))
        return tooltip, "\n".join((tooltip, str(self.property("orIntervalExplanation"))))

    def _decision(self, row):
        # Only the inference engine's adjusted decision may establish significance.
        if row.get("status") == "boundary_uncalibrated":
            return str(self.property("uncalibratedText"))
        valid = row.get("status") == "ok" and _finite(row.get("p_adjusted"))
        significant = row.get("significant") if valid else None
        key = "significantText" if significant is True else "notSignificantText" if significant is False else "unavailableText"
        return str(self.property(key))

    def _kind(self, row):
        return str(self.property("categoricalText" if row.get("kind") == "categorical" else "numericText"))

    def _overview_tooltips(self):
        alpha = self.report.get("alpha")
        if not (_finite(alpha) and 0 < alpha < 1):
            confidence = self.report.get("confidence_level", .95)
            alpha = 1 - confidence if _finite(confidence) and 0 < confidence < 1 else .05
        return {column: text.format(threshold=_number(alpha)) for column, text in
                enumerate(self.ui.overviewTableView.property("columnTooltips")) if text}

    def _pair_decision(self, row):
        if row.get("status") == "point_estimate_only" and _finite(row.get("difference")):
            return str(self.property("pairPointEstimateOnlyText"))
        valid = row.get("status") == "ok" and _finite(row.get("p_adjusted"))
        if valid and row.get("significant") is False:
            return str(self.property("pairNotSignificantText"))
        difference = row.get("difference")
        if valid and row.get("significant") is True and _finite(difference) and difference != 0:
            key = "pairHigherFormat" if difference > 0 else "pairLowerFormat"
            return self.property(key).format(a=row.get("level_a", ""), b=row.get("level_b", ""))
        return str(self.property("unavailableText"))

    @staticmethod
    def _resize(table):
        table.resizeColumnsToContents()
        lower, upper = int(table.property("textColumnMinimumWidth")), int(table.property("textColumnMaximumWidth"))
        for column in range(table.model().columnCount()):
            table.setColumnWidth(column, min(upper, max(lower, table.columnWidth(column))))

    def set_group(self, group):
        self._binding = True
        previous = self.ui.featureComboBox.currentData()
        self.report = (group or {}).get("feature_effects") or {}
        self.features = list(self.report.get("features") or [])
        combo = self.ui.featureComboBox
        with QSignalBlocker(combo):
            combo.clear()
            for row in self.features:
                combo.addItem(str(row.get("feature", "")), row.get("feature"))
            chosen = combo.findData(previous)
            combo.setCurrentIndex(chosen if chosen >= 0 else 0 if self.features else -1)
        combo.setEnabled(bool(self.features))
        overview_tooltips = self._overview_tooltips()
        self.overview_model.set_header_tooltips(overview_tooltips)
        overview = []
        for row in self.features:
            lrt, impact = row.get("lrt") or {}, row.get("deletion_impact") or {}
            reason = "\n".join(dict.fromkeys(str(value) for value in
                (row.get("reason"), lrt.get("reason"), impact.get("reason")) if value))
            available_impact = impact.get("status") == "ok"
            lrt_reason = ("\n".join(dict.fromkeys(str(value) for value in
                (row.get("reason"), lrt.get("reason")) if value))
                if lrt.get("status") != "ok" else "")
            impact_reason = str(impact.get("reason") or "") if not available_impact else ""
            cells = [
                self._cell(row.get("feature"), tooltip=reason), self._cell(self._kind(row)),
                self._cell(self._decision(lrt), tooltip=lrt_reason),
                *[self._cell(lrt.get(field), numeric=True, tooltip=lrt_reason) for field in
                  ("statistic", "df", "p_value", "p_adjusted")],
                *[self._cell(impact.get(field) if available_impact else None, pp=True, tooltip=impact_reason) for field in
                  ("mean_abs_probability_change", "max_abs_probability_change", "rms_probability_change")],
                self._cell(impact.get("instance_count"), numeric=True, tooltip=impact_reason),
                self._cell(reason, tooltip=reason),
            ]
            overview.append([(display, raw, "\n".join(dict.fromkeys(value for value in
                (overview_tooltips.get(column), tooltip) if value)))
                for column, (display, raw, tooltip) in enumerate(cells)])
        self.overview_model.set_rows(overview)
        self._resize(self.ui.overviewTableView)
        if not group:
            status = self.ui.statusLabel.property("emptyText")
        elif not self.report:
            status = self.ui.statusLabel.property("missingReportText")
        elif not self.features:
            status = self.report.get("reason") or self.ui.statusLabel.property("emptyText")
        else:
            status = self.ui.statusLabel.property("summaryFormat").format(
                count=len(self.features),
                estimated=sum(any(not level.get("reference") and _finite(level.get("coefficient"))
                                  for level in row.get("levels") or []) or
                              any(_finite(pair.get("difference")) for pair in row.get("pairwise") or [])
                              for row in self.features),
                deletion=sum((row.get("deletion_impact") or {}).get("status") == "ok" for row in self.features),
                significant=sum((row.get("lrt") or {}).get("status") == "ok" and
                                (row.get("lrt") or {}).get("significant") is True for row in self.features),
                uncalibrated=sum((row.get("lrt") or {}).get("status") == "boundary_uncalibrated" for row in self.features),
                unavailable=sum(self._decision(row.get("lrt") or {}) == self.property("unavailableText") for row in self.features))
            if any(_finite(row.get("ci_lower")) and _finite(row.get("ci_upper"))
                   for feature in self.features for row in [*(feature.get("levels") or []), *(feature.get("pairwise") or [])]):
                confidence = self.report.get("confidence_level", .95)
                status += self.ui.statusLabel.property("intervalSummaryFormat").format(
                    confidence=f"{confidence:.0%}" if _finite(confidence) else "")
        self.ui.statusLabel.setText(str(status))
        notes = [self.ui.notesTextEdit.property("baseNotes")]
        if self.report.get("reason"):
            notes.append(str(self.report["reason"]))
        if self.report.get("model_scope"):
            notes.append(str(self.report["model_scope"]))
        notes.extend(str(value) for value in self.report.get("warnings", []) if value)
        self.ui.notesTextEdit.setPlainText("\n\n".join(notes))
        self._binding = False
        self._feature_changed()

    def _overview_selected(self, current, _previous):
        if self._binding or not current.isValid():
            return
        source = self.overview_proxy.mapToSource(current)
        self.ui.featureComboBox.setCurrentIndex(source.row())

    def _feature_changed(self, *_args):
        if self._binding:
            return
        index = self.ui.featureComboBox.currentIndex()
        selected = self.features[index] if 0 <= index < len(self.features) else {}
        self._binding = True
        if selected:
            self.ui.overviewTableView.setCurrentIndex(self.overview_proxy.mapFromSource(self.overview_model.index(index, 0)))
        self._binding = False
        lrt = selected.get("lrt") or {}
        if selected:
            detail = self.property("featureDetailFormat").format(feature=selected.get("feature"), kind=self._kind(selected),
                decision=self._decision(lrt), reason=lrt.get("reason") or selected.get("reason") or "")
            if selected.get("kind") == "categorical":
                detail += "\n" + self.property("referenceFormat").format(reference=selected.get("reference_level", ""))
            else:
                level = next(iter(selected.get("levels") or []), {})
                detail += "\n" + self.property("numericScaleFormat").format(
                    mean=_number(level.get("mean", selected.get("mean"))), scale=_number(level.get("scale", selected.get("scale"))))
        else:
            detail = self.ui.featureDetailLabel.property("emptyText")
        self.ui.featureDetailLabel.setText(str(detail))
        level_or_help, level_interval_help = self._or_tooltips(selected)
        pair_or_help, pair_interval_help = self._or_tooltips(selected, pair=True)
        self.levels_model.set_header_tooltips({4: level_or_help, 5: level_interval_help})
        self.pairwise_model.set_header_tooltips({3: pair_or_help, 4: pair_interval_help})
        levels = list(selected.get("levels") or [])
        order = self.ui.levelOrderComboBox.currentIndex()
        if order:
            available = [row for row in levels if _finite(row.get("coefficient"))]
            unavailable = [row for row in levels if not _finite(row.get("coefficient"))]
            levels = sorted(available, key=lambda row: row["coefficient"], reverse=order == 1) + unavailable
        level_rows, plot_rows = [], []
        for row in levels:
            status = (self.property("referenceText") if row.get("reference") else
                      self.property("estimatedText") if row.get("status") == "ok" else
                      self.property("pointEstimateOnlyText") if row.get("status") == "point_estimate_only"
                      and _finite(row.get("coefficient")) else self.property("unavailableText"))
            reason = str(row.get("reason") or "")
            tooltip = "\n".join((str(row.get("level", "")), str(status), reason))
            or_tooltip, or_interval_tooltip = self._or_tooltips(selected, row)
            level_rows.append([self._cell(row.get("level"), tooltip=tooltip), self._cell(row.get("coefficient"), numeric=True),
                self._cell(row.get("se"), numeric=True), self._interval(row),
                self._cell(row.get("odds_ratio"), numeric=True, tooltip=or_tooltip),
                self._interval(row, "or_", tooltip=or_interval_tooltip), self._cell(status, tooltip=reason), self._cell(reason, tooltip=reason)])
            plot_rows.append({"label": row.get("level"), "estimate": row.get("coefficient"),
                "ci_lower": row.get("ci_lower"), "ci_upper": row.get("ci_upper"),
                "reference": row.get("reference"), "tooltip": tooltip})
        self.levels_model.set_rows(level_rows)
        self.ui.levelsPlot.set_rows(plot_rows)
        self._resize(self.ui.levelsTableView)
        pair_rows, pair_plot = [], []
        for row in selected.get("pairwise") or []:
            label = self.property("pairFormat").format(a=row.get("level_a", ""), b=row.get("level_b", ""))
            reason = str(row.get("reason") or "")
            tooltip = "\n".join((label, self._pair_decision(row), reason))
            or_tooltip, or_interval_tooltip = self._or_tooltips(selected, row, pair=True)
            pair_rows.append([self._cell(label, tooltip=tooltip), self._cell(row.get("difference"), numeric=True),
                self._interval(row), self._cell(row.get("odds_ratio"), numeric=True, tooltip=or_tooltip),
                self._interval(row, "or_", tooltip=or_interval_tooltip),
                self._cell(row.get("p_value"), numeric=True), self._cell(row.get("p_adjusted"), numeric=True),
                self._cell(self._pair_decision(row), tooltip=tooltip), self._cell(reason, tooltip=reason)])
            pair_plot.append({"label": label, "estimate": row.get("difference"),
                "ci_lower": row.get("ci_lower"), "ci_upper": row.get("ci_upper"), "tooltip": tooltip})
        self.pairwise_model.set_rows(pair_rows)
        self.ui.pairwisePlot.set_rows(pair_plot)
        self._resize(self.ui.pairwiseTableView)
        self.ui.pairwiseHintLabel.setText(self.ui.pairwiseHintLabel.property(
            "numericText" if selected.get("kind") == "numeric" else "defaultText"))
