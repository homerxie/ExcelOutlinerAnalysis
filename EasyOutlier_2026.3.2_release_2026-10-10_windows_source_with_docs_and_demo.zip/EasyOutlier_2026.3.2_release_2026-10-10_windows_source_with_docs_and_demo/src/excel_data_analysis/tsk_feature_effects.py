"""Conditional feature inference for a frozen, independent-chain Logistic fit.

Instance risks are latent.  All refits retain the original noisy-OR binomial
chain likelihood; an instance row is never treated as an observed Fail label.
Ordinary Wald and likelihood-ratio results require a finite interior fit and
locally identifiable contrasts.  They are approximate, not causal evidence.
"""

from __future__ import annotations

from itertools import combinations
import math
from time import monotonic
from typing import Any, Callable, Mapping

import numpy as np
from scipy.optimize import linprog
from scipy.special import expit
from scipy.stats import chi2, norm

from .tsk_analysis import _feature_loss_and_derivative, _minimize_bound_constrained, _plain
from .tsk_logistic_boundary import KKT_TOLERANCE, LogisticBoundaryFit
from .tsk_prediction import _FrozenFit, _in_row_space
from .tsk_parallel import ordered_parallel_map, validate_analysis_workers, worker_count


_METHODS = {
    "coefficient_interval": "joint_expected_fisher_information_wald_pointwise",
    "pairwise_test": "two_sided_wald_within_feature_holm",
    "overall_test": "drop_feature_refit_chain_binomial_likelihood_ratio_holm",
    "multiplicity": "unavailable_tests_count_as_p_one_in_each_prespecified_family",
    "deletion_impact": "in_sample_model_sensitivity_not_instance_validation",
    "finite_mle_guard": "sufficient_monotone_chain_separation_linear_program",
    "type_effects": "same_feature_conditions_type_log_odds_contrast_joint_covariance",
    "type_pairwise_test": "two_sided_wald_holm_separate_all_tsk_pairs_family",
}
MAX_TYPE_PAIRS = 5000


def _feature_definitions(context: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Group fitted basis columns without changing their likelihood coding."""
    columns = list(context.get("coefficient_columns", []))
    categorical = context.get("categorical_features", {})
    groups = context.get("feature_groups", {})
    owners = {}
    for name, definition in groups.items():
        if definition.get("kind") != "spatial":
            continue
        for column in definition.get("columns", []):
            if column in owners:
                raise ValueError(f"Fitted feature column {column!r} belongs to multiple groups.")
            owners[column] = name
    names = list(dict.fromkeys([*(owners.get(column[0], column[0]) for column in columns), *categorical]))
    result = []
    for name in names:
        definition = groups.get(name, {})
        spatial = definition.get("kind") == "spatial"
        members = set(definition.get("columns", [])) if spatial else {name}
        if spatial and any(column[0] == name and name not in members for column in columns):
            raise ValueError(f"Feature group {name!r} conflicts with an ordinary fitted feature.")
        result.append({"name": name, "kind": "spatial" if spatial else "categorical" if name in categorical else "numeric",
                       "label": definition.get("label", name) if spatial else name,
                       "column_names": list(dict.fromkeys(column[0] for column in columns if column[0] in members)),
                       "indices": [len(context["type_ids"]) + index for index, column in enumerate(columns)
                                   if column[0] in members]})
    return result


def _status(status: str, reason: str) -> dict[str, Any]:
    return {"status": status, "reason": reason}


def _empty_contrast(status: str, reason: str) -> dict[str, Any]:
    return {**_status(status, reason), "difference": None, "se": None,
            "ci_lower": None, "ci_upper": None, "odds_ratio": None,
            "or_ci_lower": None, "or_ci_upper": None,
            "p_value": None, "p_adjusted": None, "significant": None}


def _empty_lrt(status: str, reason: str, minimum: float) -> dict[str, Any]:
    return {**_status(status, reason), "df": None, "statistic": None,
            "p_value": None, "p_adjusted": None, "significant": None,
            "full_nll": minimum, "reduced_nll": None,
            "critical_value": None, "full_refit_nll": None}


def _empty_impact(status: str, reason: str, count: int) -> dict[str, Any]:
    return {**_status(status, reason), "weighting": "active_layout_instances_equal",
            "direction": "reduced_minus_full", "instance_count": count,
            "evaluated_instance_count": 0, "mean_abs_probability_change": None,
            "max_abs_probability_change": None, "rms_probability_change": None,
            "mean_signed_probability_change": None, "by_tsk": []}


def _exp(value: float) -> float | None:
    return math.exp(value) if value <= math.log(np.finfo(float).max) else None


def _estimable(fit: _FrozenFit, vector: np.ndarray) -> bool:
    return bool(fit.identifiable(vector) and _in_row_space(vector, fit.information_basis))


def _wald(fit: _FrozenFit, vector: np.ndarray, cutoff: float) -> dict[str, Any]:
    if not _estimable(fit, vector):
        return _empty_contrast("not_identifiable", "现有 Chain 观测无法独立识别这个系数差异。")
    difference = float(vector @ fit.theta)
    variance = float(vector @ fit.covariance @ vector)
    if not math.isfinite(variance) or variance <= 0:
        return _empty_contrast("information_unavailable", "该对比没有可用的正有限方差，不能给出常规检验。")
    se = math.sqrt(variance)
    low, high = difference - cutoff * se, difference + cutoff * se
    return {**_status("ok", "基于联合预期信息矩阵的近似双侧 Wald 检验；区间为逐项区间。"),
            "difference": difference, "se": se, "ci_lower": low, "ci_upper": high,
            "odds_ratio": _exp(difference), "or_ci_lower": _exp(low), "or_ci_upper": _exp(high),
            "p_value": float(2 * norm.sf(abs(difference / se))),
            "p_adjusted": None, "significant": None}


def _boundary_point_contrast(fit: _FrozenFit, vector: np.ndarray,
                             gradient: np.ndarray, difference: float) -> dict[str, Any]:
    """Check a finite contrast using its gradient in scaled-odds coordinates.

    Probability-query APIs require a TSK indicator and cannot be used for a
    coefficient contrast. Feasible flat directions must preserve the positive
    failure-chain hazards and the aggregate Pass contribution. Zero odds may
    move inward, rather than being fixed as if known nuisance parameters.
    """
    if not _in_row_space(vector, fit.design_basis):
        return _empty_contrast("not_identifiable", "现有设计无法独立识别这个系数差异。")
    if not math.isfinite(difference) or not np.all(np.isfinite(gradient)):
        return _empty_contrast("nonfinite_effect", "该对比没有可供复核的有限点估计或导数。")
    cached = getattr(fit, "_effect_contrast_constraints", None)
    if cached is None:
        dependence = np.vstack([fit.derivative[fit.k > 0], (fit.n - fit.k) @ fit.derivative])
        equality = dependence[np.max(np.abs(dependence), axis=1) > 0]
        if len(equality):
            equality = equality / np.max(np.abs(equality), axis=1)[:, None]
        column_norm = np.linalg.norm(equality, axis=0) if len(equality) else np.ones(fit.width)
        column_scale = np.divide(1., column_norm, out=np.ones(fit.width), where=column_norm > 0)
        equality = equality * column_scale[None, :]
        if len(equality):
            equality /= np.maximum(np.max(np.abs(equality), axis=1), 1e-300)[:, None]
        type_count = fit.boundary_engine.type_count
        bounds = [(0., 1.) if index < type_count and fit.theta[index] == 0 else (-1., 1.)
                  for index in range(fit.width)]
        arguments = dict(A_eq=equality if len(equality) else None,
                         b_eq=np.zeros(len(equality)) if len(equality) else None,
                         bounds=bounds, method="highs")
        cached = fit._effect_contrast_constraints = (column_scale, arguments)
    column_scale, arguments = cached
    contrast = gradient * column_scale
    contrast /= max(float(np.linalg.norm(contrast)), 1e-300)
    try:
        low, high = linprog(contrast, **arguments), linprog(-contrast, **arguments)
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError):
        return _empty_contrast("identifiability_check_failed", "边界条件下的可辨识检查未完成，暂不报告该效应。")
    if not low.success or not high.success:
        return _empty_contrast("identifiability_check_failed", "边界条件下的可辨识检查未完成，暂不报告该效应。")
    if max(abs(low.fun), abs(high.fun)) > 1e-7:
        return _empty_contrast("not_identifiable", "现有 Chain 观测无法独立识别这个系数差异。")
    result = _empty_contrast("point_estimate_only", "零风险边界下保留局部可辨识的有限点估计；标准误、区间和显著性尚未校准。")
    result.update(difference=difference, odds_ratio=_exp(difference))
    return result


def _boundary_contrast(fit: _FrozenFit, vector: np.ndarray) -> dict[str, Any]:
    """Shared-beta contrasts are linear in both fitted parameterizations."""
    return _boundary_point_contrast(fit, vector, vector, float(vector @ fit.theta))


def _boundary_level_direction(side: str, basis: str) -> dict[str, Any]:
    """Describe a verified fitted/assumed endpoint without serializing infinity."""
    lower = side == "lower"
    probability = 0. if lower else 1.
    if basis == "fixed_zero_assumption":
        note = "原拟合风险触及计算下边界，本分析强制固定 p=0（低风险，log odds 趋于 −∞）。这是后续分析的固定约束，不代表真实风险确实为 0；区间与检验以此约束为条件。"
    else:
        note = (f"当前拟合处于{'低' if lower else '高'}风险边界（p={int(probability)}，"
                f"log odds 趋于 {'−∞' if lower else '+∞'}）；这是本次样本下的边界估计，"
                f"不代表真实失效概率确实为 {int(probability)}，也不证明与其他类型存在显著差异。")
    return {"boundary_state": side, "boundary_probability": probability,
            "direction": "low_risk_boundary" if lower else "high_risk_boundary",
            "direction_basis": basis, "log_odds_limit": "negative_infinity" if lower else "positive_infinity",
            "odds_limit": "zero" if lower else "positive_infinity", "boundary_note": note}


def _boundary_pair_direction(left: str, right: str, basis: str) -> dict[str, Any]:
    """B-A limiting direction applies only to the current verified fit/assumption."""
    if left == right and left in {"lower", "upper"}:
        state = "both_lower" if left == "lower" else "both_upper"
        note = (f"两者在{'当前固定零约束' if basis == 'fixed_zero_assumption' else '当前拟合'}下均为 p={0 if left == 'lower' else 1}；"
                "log odds 差及 OR 的边界比值未定义，不能据此排序或认定风险相同。")
        return {"boundary_state": state, "direction": "undetermined", "direction_basis": basis,
                "log_odds_limit": "undefined", "odds_ratio_limit": "undefined", "boundary_note": note}
    higher = left == "lower" or right == "upper"
    if left in {"lower", "upper"} and right in {"lower", "upper"}:
        state = f"{left}_{right}"
    else:
        state = f"a_{left}" if left in {"lower", "upper"} else f"b_{right}"
    scope = "固定零约束下的当前条件拟合" if basis == "fixed_zero_assumption" else "当前拟合"
    note = (f"{scope}中 B 风险{'高于' if higher else '低于'} A；B−A 的 log odds 差趋于 {'+∞' if higher else '−∞'}，"
            f"OR 趋于 {'+∞' if higher else '0'}。这仅描述边界方向，不是有限系数估计、可靠区间或显著性结论；真实风险未必处于该边界。")
    return {"boundary_state": state, "direction": "b_higher" if higher else "b_lower",
            "direction_basis": basis, "log_odds_limit": "positive_infinity" if higher else "negative_infinity",
            "odds_ratio_limit": "positive_infinity" if higher else "zero", "boundary_note": note}


def _add_boundary_direction(row: dict, metadata: dict) -> dict:
    row.update(metadata)
    row["reason"] += " " + metadata["boundary_note"]
    return row


def _type_risk_identifiable(fit: _FrozenFit, index: int) -> bool:
    """Use an observed environment, not an arbitrary zero-feature reference.

    At zero odds an identified probability at any finite observed environment
    identifies the type's zero odds. The boundary engine also probes remote
    reallocations in mixed chains; a single arbitrary zero allocation is not
    enough to claim a low-risk direction.
    """
    cache = getattr(fit, "_type_direction_identified", None)
    if cache is None:
        cache = fit._type_direction_identified = {}
    if index in cache:
        return cache[index]
    rows = np.flatnonzero(fit.design[:, index] > 0)
    if not len(rows):
        return False
    try:
        cache[index] = fit.identifiable(fit.design[rows[0]])
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError):
        cache[index] = False
    return cache[index]


def _boundary_type_contrast(fit: _FrozenFit, left: int, right: int) -> dict[str, Any]:
    """Positive-type log odds use log(u) + log(scale), never capped logits."""
    if fit.theta[left] == 0 or fit.theta[right] == 0:
        if not _type_risk_identifiable(fit, left) or not _type_risk_identifiable(fit, right):
            return _empty_contrast("not_identifiable", "当前候选拟合包含 p=0，但相关类型的风险分配不能独立识别；不能据此判断谁的风险更低或给出边界 OR 方向。")
        return _add_boundary_direction(
            _empty_contrast("nonfinite_effect", "对比涉及零风险 TSK，没有有限的 log odds 差及有限 OR 对比；不使用数值截断值代替。"),
            _boundary_pair_direction("lower" if fit.theta[left] == 0 else "interior",
                                     "lower" if fit.theta[right] == 0 else "interior", "fitted_boundary"))
    vector = np.zeros(fit.width)
    vector[right], vector[left] = 1., -1.
    scales = fit.boundary_engine.odds_scale
    difference = (math.log(fit.theta[right]) + math.log(scales[right])
                  - math.log(fit.theta[left]) - math.log(scales[left]))
    # d(log u_b - log u_a) / du = (+1/u_b, -1/u_a).
    # A common positive factor keeps this LP direction finite even for tiny u.
    gradient = np.zeros(fit.width)
    common = min(fit.theta[left], fit.theta[right])
    gradient[right], gradient[left] = common / fit.theta[right], -common / fit.theta[left]
    return _boundary_point_contrast(fit, vector, gradient, difference)


def _holm(rows: list[dict[str, Any]], alpha: float) -> None:
    """Keep every predeclared comparison in the family, including unavailable ones."""
    ordered = sorted(enumerate(rows), key=lambda item: (
        item[1]["p_value"] if item[1].get("p_value") is not None else 1., item[0]))
    previous = 0.
    for rank, (_, row) in enumerate(ordered):
        p = row.get("p_value")
        adjusted = min(1., max(previous, (len(rows) - rank) * (p if p is not None else 1.)))
        previous = adjusted
        if p is not None and row.get("status") == "ok":
            row["p_adjusted"] = adjusted
            row["significant"] = bool(adjusted <= alpha)


def _type_effects(fit: _FrozenFit, cutoff: float, alpha: float,
                  invalid: tuple[str, str] | None = None, *, boundary_mode=False) -> dict[str, Any]:
    """TSK contrasts are differences of intercepts at identical feature values."""
    types = list(fit.context["type_ids"])
    pair_count = len(types) * (len(types) - 1) // 2
    limited = pair_count > MAX_TYPE_PAIRS
    reference_index = (next((index for index in range(len(types)) if fit.theta[index] > 0), None)
                       if boundary_mode and fit.boundary_engine is not None else 0 if types else None)
    reference = types[reference_index] if reference_index is not None else None
    reason = "在相同数值与类别特征条件下比较 TSK；系数是相对参考 TSK 的 log odds 差，OR 为赔率比。"
    if boundary_mode:
        reason += " 自由边界下仅保留正风险 TSK 间可辨识的有限点估计；标准误、区间和显著性尚未校准。"
        if reference_index is None:
            reason += " 所有 TSK 均处于零风险边界，没有有限 log odds 参考类型。"
        elif reference_index != 0:
            reason += f" 首个 TSK 为零风险，改用首个正风险 TSK {reference} 作为参考。"
    result = {"feature": "TSK 类型", "kind": "categorical", "role": "tsk_type",
              "reference_level": reference, **_status("ok", reason), "levels": [], "pairwise": [],
              "pairwise_count": pair_count, "computed_pairwise_count": 0,
              "pairwise_limit": MAX_TYPE_PAIRS, "pairwise_omitted_count": pair_count if limited else 0,
              "lrt": _empty_lrt("not_applicable", "TSK 类型仅报告档位与两两对比，不进行删除 TSK 的整体检验。", fit.minimum),
              "deletion_impact": _empty_impact("not_applicable", "TSK 类型不进行删除影响分析。", len(fit.design))}
    unavailable = invalid
    if limited and not unavailable:
        unavailable = ("computation_limited", f"TSK 共 {pair_count} 个两两对比，超过 {MAX_TYPE_PAIRS} 个的计算上限；本组类型区间与检验未计算，未截取部分对比缩小校正族。")
    for index, name in enumerate(types):
        if unavailable:
            data = _empty_contrast(*unavailable)
        elif boundary_mode and fit.theta[index] == 0:
            data = _empty_contrast("nonfinite_effect", "该 TSK 位于零风险边界，没有有限 log odds，不能提供相对系数与有限 OR；不使用数值截断值代替。")
        elif index == reference_index:
            data = _empty_contrast("reference_coding", "参考 TSK 的相对系数编码为 0、OR 为 1；不是该 TSK 的绝对 log odds 或零风险声明。")
            data.update(difference=0., odds_ratio=1.)
        else:
            vector = np.zeros(fit.width)
            vector[index], vector[reference_index] = 1., -1.
            data = (_boundary_type_contrast(fit, reference_index, index) if boundary_mode
                    else _wald(fit, vector, cutoff))
        if not invalid and boundary_mode and fit.theta[index] == 0:
            if _type_risk_identifiable(fit, index):
                _add_boundary_direction(data, _boundary_level_direction("lower", "fitted_boundary"))
            elif not unavailable:
                data = _empty_contrast("not_identifiable", "当前候选拟合将该 TSK 取为 p=0，但风险分配不能独立识别；不能将它认定为已识别的低风险类型。")
        result["levels"].append({"level": name, "reference": index == reference_index, **data,
                                 "coefficient": data["difference"], "point_rank": None})
    for (left, name_a), (right, name_b) in ([] if limited else combinations(enumerate(types), 2)):
        vector = np.zeros(fit.width)
        vector[right], vector[left] = 1., -1.
        data = (_empty_contrast(*unavailable) if unavailable else
                _boundary_type_contrast(fit, left, right) if boundary_mode else _wald(fit, vector, cutoff))
        result["pairwise"].append({"level_a": name_a, "level_b": name_b, "contrast": "b_minus_a", **data})
    # A p=1 type-only MLE has no finite Logistic parameterization. Preserve
    # separately verified endpoint descriptions despite withholding inference;
    # arbitrary optimizer failures never enter this narrowly audited branch.
    endpoint_sides = fit.context.get("_verified_type_only_endpoint_sides")
    if endpoint_sides and invalid and invalid[0] == "nonfinite_mle":
        for index, level in enumerate(result["levels"]):
            if endpoint_sides[index] in {"lower", "upper"}:
                _add_boundary_direction(level, _boundary_level_direction(endpoint_sides[index], "type_only_boundary"))
        for pair in result["pairwise"]:
            left, right = (endpoint_sides[types.index(pair[name])] for name in ("level_a", "level_b"))
            if left and right and (left != "interior" or right != "interior"):
                _add_boundary_direction(pair, _boundary_pair_direction(left, right, "type_only_boundary"))
    result["computed_pairwise_count"] = sum(row["p_value"] is not None for row in result["pairwise"])
    _holm(result["pairwise"], alpha)
    if unavailable:
        result.update(_status(*unavailable))
    elif boundary_mode:
        result.update(_status("point_estimate_only" if any(row["difference"] is not None for row in result["pairwise"])
                              else "nonfinite_effect" if reference_index is None else "partial", reason))
    elif any(row["status"] != "ok" for row in result["pairwise"]):
        result.update(_status("partial", reason + " 部分 TSK 对比无法由现有观测独立识别。"))
    elif len(types) < 2:
        result.update(_status("no_variation", "只有一个活跃 TSK，不能进行类型间比较；参考编码不代表独立效应估计。"))
    if result["levels"] and all(row["coefficient"] is not None for row in result["levels"]):
        rank, previous = 0, None
        for row in sorted(result["levels"], key=lambda item: item["coefficient"]):
            if previous is None or row["coefficient"] != previous:
                rank += 1
            row["point_rank"] = rank
            previous = row["coefficient"]
    return result


def _verified_type_only_endpoints(context: Mapping[str, Any], hazards: np.ndarray) -> list[str | None] | None:
    """Audit the saturated hazard solution; mixed all-Fail aliases get no label."""
    from .tsk_analysis import _BaselineModel, _loss_and_slope
    if not context.get("converged") or context.get("clipped"):
        return None
    try:
        design = np.asarray(context["design"], dtype=float)
        chains = np.asarray(context["chain_index"], dtype=int)
        n, k = np.asarray(context["n_tested"], dtype=float), np.asarray(context["n_failed"], dtype=float)
        if (design.shape != (len(chains), len(hazards)) or n.shape != k.shape or not len(n)
                or np.any(chains < 0) or np.any(chains >= len(n)) or np.any(n <= 0)
                or np.any(k < 0) or np.any(k > n) or not np.all(np.isfinite(design))
                or not np.all(np.isfinite(n)) or not np.all(np.isfinite(k))
                or not np.all((design == 0) | (design == 1)) or not np.all(design.sum(axis=1) == 1)):
            return None
        counts = np.zeros((len(n), len(hazards)))
        np.add.at(counts, chains, design)
        infinite = np.isinf(hazards)
        model = _BaselineModel(counts, n, k)
        if not np.array_equal(infinite, model.unbounded):
            return None
        saturated = np.any(counts[:, infinite] > 0, axis=1)
        if np.any((n > k) & saturated):
            return None
        finite = ~infinite
        matrix = counts[~saturated][:, finite]
        value, slope = _loss_and_slope(matrix @ hazards[finite], n[~saturated], k[~saturated])
        gradient = matrix.T @ slope
        projected = np.where(hazards[finite] == 0, np.minimum(gradient, 0.), gradient)
        if (not math.isfinite(value) or not np.all(np.isfinite(projected))
                or abs(value - float(context["negative_log_likelihood"])) > _likelihood_tolerance(value)
                or np.max(np.abs(projected), initial=0.) / max(float(n[~saturated].sum()), 1.) >= 1e-8):
            return None
        _, identified = model.identifiability(hazards)
        return [None if not identified[index] else "upper" if infinite[index]
                else "lower" if value == 0 else "interior" for index, value in enumerate(hazards)]
    except (RuntimeError, ValueError, KeyError, TypeError, FloatingPointError, np.linalg.LinAlgError):
        return None


def _type_only_logistic_context(context: Mapping[str, Any]) -> dict[str, Any]:
    """Convert type-only negative-log-survival parameters without changing fit."""
    converted = dict(context, model="instance_logistic_features")
    hazards = np.asarray(context["coefficients"], dtype=float)
    if hazards.shape != (len(context["type_ids"]),) or np.any(hazards < 0) or np.any(np.isnan(hazards)):
        raise ValueError("Invalid type-only hazard parameters.")
    if np.any(np.isinf(hazards)):
        # No finite log odds exists at p=1. Values below are schema-only seeds
        # for an explicitly invalid report and are never exposed as estimates.
        converted.update(coefficients=np.zeros(len(hazards)), converged=False, boundary_fit=None,
                         _type_only_invalid=("nonfinite_mle", "至少一个 TSK 的风险位于 1 边界，没有有限 log odds；普通类型区间和检验不可用。"))
        sides = _verified_type_only_endpoints(context, hazards)
        if sides is not None:
            converted["_verified_type_only_endpoint_sides"] = sides
        return converted
    positive = hazards > 0
    logits = np.zeros(len(hazards))
    logits[positive] = hazards[positive] + np.log(-np.expm1(-hazards[positive]))
    # The original hazard fit has no +/-35 logit constraint. Its finite
    # converted estimates must not be mistaken for optimizer clipping.
    bound = max(float(context.get("logistic_coefficient_bound", 35.)), float(np.max(np.abs(logits), initial=0)) + 1.)
    logits[~positive] = -bound
    converted.update(coefficients=logits, boundary_fit=None, logistic_coefficient_bound=bound)
    if np.any(logits[positive] >= math.log(np.finfo(float).max)):
        converted.update(converged=False, _type_only_invalid=("nonfinite_mle", "TSK odds 超出有限数值范围，类型区间和检验不可用。"))
        return converted
    scales = np.ones(len(hazards))
    scales[positive] = np.exp(logits[positive])
    state = {
        "version": 1, "parameterization": "scaled_type_odds", "type_count": len(hazards),
        "params": positive.astype(float).tolist(), "odds_scale": scales.tolist(),
        "coefficient_bound": bound, "converged": bool(context.get("converged")),
        "minimum": context["negative_log_likelihood"], "feature_clipped": False,
        "zero_type_indices": np.flatnonzero(~positive).tolist(),
    }
    # Conversion reuses the saved fit, so check both its likelihood and KKT
    # directly even when no ordinary feature exists to trigger a drop audit.
    engine = LogisticBoundaryFit(context["design"], context["chain_index"], context["n_tested"],
                                 context["n_failed"], len(hazards), coefficient_bound=bound)
    engine.load_state(state)
    params = np.asarray(state["params"])
    value, gradient, _, derivative = engine.evaluate(params)
    if (not math.isfinite(value) or abs(value - float(state["minimum"])) > _likelihood_tolerance(float(state["minimum"]))
            or engine._kkt(params, gradient, derivative, [(0., None)] * len(hazards)) >= KKT_TOLERANCE):
        converted.update(converged=False, _type_only_invalid=("fit_not_converged", "TSK hazard 快照未通过转换后的似然和驻点复核，不能给出类型区间或检验。"))
        state["converged"] = False
    if np.any(~positive):
        converted["boundary_fit"] = state
    return converted


def _rows_estimable(fit: _FrozenFit, heartbeat=None) -> np.ndarray:
    notify = heartbeat or (lambda *_: None)
    count = len(fit.design)
    notify(0, count)
    cached = getattr(fit, "_effect_rows_estimable", None)
    if cached is not None:
        notify(count, count)
        return cached
    matrix = fit.design
    if fit.boundary_engine is not None:
        valid = np.empty(count, dtype=bool)
        queries = {}
        for index, vector in enumerate(matrix):
            key = vector.tobytes()
            if key not in queries:
                queries[key] = fit.identifiable(vector)
                # Check between distinct LP/profile queries. Cache only the
                # completed array, so cancellation never exposes partial data.
                notify(index + 1, count)
            elif (index + 1) % 1024 == 0:
                notify(index + 1, count)
            valid[index] = queries[key]
    else:
        valid = np.ones(len(matrix), dtype=bool)
        sizes = np.maximum(np.linalg.norm(matrix, axis=1), 1e-15)
        for basis in (fit.design_basis, fit.likelihood_basis, fit.information_basis):
            notify(0, count)
            residual = matrix - (matrix @ basis) @ basis.T
            valid &= np.linalg.norm(residual, axis=1) <= 1e-7 * sizes
    notify(count, count)
    fit._effect_rows_estimable = valid
    return valid


def _change_metrics(delta: np.ndarray) -> dict[str, Any]:
    return {"mean_abs_probability_change": float(np.mean(np.abs(delta))),
            "max_abs_probability_change": float(np.max(np.abs(delta))),
            "rms_probability_change": float(np.sqrt(np.mean(delta * delta))),
            "mean_signed_probability_change": float(np.mean(delta))}


def _deletion_impact(full: _FrozenFit, reduced: _FrozenFit, heartbeat=None) -> dict[str, Any]:
    """Compare frozen fits; optional heartbeat receives stage, done and total."""
    notify = heartbeat or (lambda *_: None)
    valid = (_rows_estimable(full, lambda done, total: notify("完整模型实例可识别性", done, total))
             & _rows_estimable(reduced, lambda done, total: notify("删特征模型实例可识别性", done, total)))
    def probabilities(fit, stage):
        count = len(fit.design)
        notify(stage, 0, count)
        cached = getattr(fit, "_effect_instance_probabilities", None)
        if cached is not None:
            notify(stage, count, count)
            return cached
        if fit.boundary_engine is not None:
            # FrozenFit parameters never change. Identical scalar calls have
            # identical results, so preserve the original arithmetic while
            # evaluating repeated categorical/layout conditions only once.
            queries = getattr(fit, "_effect_boundary_probability_queries", None)
            if queries is None:
                queries = fit._effect_boundary_probability_queries = {}
            values = np.empty(count, dtype=float)
            for index, vector in enumerate(fit.design):
                # Packed float bytes retain exact equality without allocating
                # another tuple of scalar objects for every wide design row.
                key = vector.tobytes()
                if key not in queries:
                    queries[key] = fit.boundary_engine.probability(fit.theta, vector)
                    notify(stage, index + 1, count)
                elif (index + 1) % 1024 == 0:
                    notify(stage, index + 1, count)
                values[index] = queries[key]
        else:
            values = expit(fit.design @ fit.theta)
        notify(stage, count, count)
        fit._effect_instance_probabilities = values
        return values

    delta = probabilities(reduced, "删特征模型实例概率") - probabilities(full, "完整模型实例概率")
    reason = "原有效拓扑中每个实例等权比较；这是模型预测变化，不是实测实例验证或等效性证明。"
    result = _empty_impact("ok", reason, len(delta))
    result["evaluated_instance_count"] = int(valid.sum())
    if valid.all() and len(delta):
        result.update(_change_metrics(delta))
    else:
        result.update(_status("not_identifiable", "部分实例风险不可独立识别，未给出全部实例的变化汇总；可查看可识别 TSK。"))
    for index, tsk_id in enumerate(full.context["type_ids"]):
        mask = full.design[:, index] != 0
        row = {"tsk_id": tsk_id, "instance_count": int(mask.sum()),
               "evaluated_instance_count": int(valid[mask].sum()),
               "mean_abs_probability_change": None, "max_abs_probability_change": None,
               "rms_probability_change": None, "mean_signed_probability_change": None}
        if mask.any() and valid[mask].all():
            row.update(_status("ok", reason), **_change_metrics(delta[mask]))
        else:
            row.update(_status("not_identifiable", "该 TSK 的部分实例风险不可独立识别，变化量不予报告。"))
        result["by_tsk"].append(row)
    return result


def _fit_once(design, chain_index, n, k, start, bound, heartbeat):
    derivative_index = (chain_index[:, None] * design.shape[1] + np.arange(design.shape[1])).ravel()
    def objective(theta):
        heartbeat()
        value, gradient, _, _ = _feature_loss_and_derivative(design, chain_index, n, k, theta, derivative_index)
        return value, gradient

    # A fixed-zero model may retain all-Pass chains with no free-risk instance.
    # They have constant likelihood and must not dilute the gradient tolerance.
    informative_n = float(n[np.unique(chain_index)].sum())
    result, converged = _minimize_bound_constrained(
        objective, np.clip(start, -bound, bound), informative_n, -bound, bound)
    return float(result.fun), np.asarray(result.x), bool(converged)


def _refit_reduced(fit: _FrozenFit, keep: np.ndarray, heartbeat):
    matrix = fit.design[:, keep]
    type_count = len(fit.context["type_ids"])
    bound = float(fit.context.get("logistic_coefficient_bound", 35.))
    informative = np.unique(fit.chain_index)
    rate = np.clip(fit.k[informative].sum() / max(fit.n[informative].sum(), 1.), 1e-5, .95)
    count = max(len(fit.design) / max(len(informative), 1), 1.)
    component = -np.expm1(np.log1p(-rate) / count)
    baseline = np.zeros(int(keep.sum()))
    baseline[:type_count] = math.log(component / (1 - component))
    starts = [fit.theta[keep]]
    if not np.array_equal(baseline, starts[0]):
        starts.append(baseline)
    for sign in (-1., 1.):
        candidate = baseline.copy()
        candidate[type_count:] += sign * .5
        if not any(np.array_equal(candidate, start) for start in starts):
            starts.append(candidate)
    results = [_fit_once(matrix, fit.chain_index, fit.n, fit.k, start, bound, heartbeat) for start in starts]
    finite = [row for row in results if math.isfinite(row[0]) and np.all(np.isfinite(row[1]))]
    if not finite:
        return math.inf, starts[0], False
    return min(finite, key=lambda row: row[0])


def _likelihood_tolerance(value: float) -> float:
    return max(1e-7, abs(value) * np.finfo(float).eps * 64)


def _monotone_separation_certificate(design, chain_index, n, k) -> dict[str, Any]:
    """Find a sufficient certificate that no finite Logistic MLE exists.

    A direction holds every instance in mixed-outcome chains fixed, decreases
    logits in all-Pass chains, and increases them in all-Fail chains.  If one
    inequality is strict, moving along the direction strictly improves the
    noisy-OR likelihood at *every* finite parameter vector.  This includes
    both type-only and shared-feature separation, without a coefficient cap.
    It is a sufficient certificate, not an exhaustive finite-MLE theorem for
    the nonlinear aggregated likelihood.  Numerical LP failure is not a pass.
    """
    passed = k[chain_index] == 0
    failed = k[chain_index] == n[chain_index]
    pure = passed | failed
    if not np.any(pure):
        return _status("no_certificate", "所有有效 Chain 均包含 Pass 和 Fail，未出现该单调分离证书。")
    # Row scaling preserves each constraint while keeping the LP independent
    # of a large numerical feature unit. Every valid row has a TSK indicator.
    scaled = design / np.maximum(np.linalg.norm(design, axis=1), 1e-15)[:, None]
    signs = np.where(passed[pure], 1., -1.)
    inequality = signs[:, None] * scaled[pure]
    equality = scaled[~pure]
    objective = inequality.sum(axis=0)
    try:
        solution = linprog(
            objective, A_ub=inequality, b_ub=np.zeros(len(inequality)),
            A_eq=equality if len(equality) else None,
            b_eq=np.zeros(len(equality)) if len(equality) else None,
            bounds=[(-1., 1.)] * design.shape[1], method="highs",
            options={"primal_feasibility_tolerance": 1e-9, "dual_feasibility_tolerance": 1e-9},
        )
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        return {**_status("check_failed", "分离方向检查出现数值异常，不能认定满足常规有限参数推断条件。"),
                "diagnostic_error": str(error)}
    if not solution.success or solution.x is None or not np.all(np.isfinite(solution.x)):
        return {**_status("check_failed", "分离方向线性规划未可靠完成，不能认定满足常规有限参数推断条件。"),
                "diagnostic_error": str(solution.message)}
    direction = np.asarray(solution.x)
    margins = inequality @ direction
    if (np.max(margins, initial=0.) > 1e-8
            or np.max(np.abs(equality @ direction), initial=0.) > 1e-8
            or np.max(np.abs(direction), initial=0.) > 1 + 1e-8):
        return _status("check_failed", "分离方向的数值约束复核未通过，常规推断暂不可用。")
    improvement = float(objective @ direction)
    threshold = 1e-8 * max(float(np.linalg.norm(objective, ord=1)), 1.)
    if improvement < -threshold:
        return {**_status("separation", "发现单调分离方向：至少一条纯 Pass/Fail 链的似然可持续改善，有限系数最优解不存在。"),
                "direction": direction.tolist(), "objective_value": improvement}
    return _status("no_certificate", "未发现该充分单调分离证书；这不构成有限或唯一全局最优解的证明。")


def _drop_feature(fit: _FrozenFit, feature: str, indices: list[int], alpha: float, heartbeat, *, allow_aliased=False):
    minimum = fit.minimum
    count = len(fit.design)
    separation_check = None

    def unavailable(status, reason):
        lrt = _empty_lrt(status, reason, minimum)
        if separation_check is not None:
            lrt["finite_mle_check"] = separation_check
        return lrt, _empty_impact(status, reason, count)

    if not indices:
        return unavailable("no_variation", "该特征只有一个档位，没有可删除的效应参数，无法检验档位差异。")
    coefficients_estimable = all(_estimable(fit, np.eye(fit.width)[index]) for index in indices)
    if not coefficients_estimable and not allow_aliased:
        return unavailable("not_identifiable", "该特征的整组效应不能与其他参数独立区分，不能报告普通整体显著性。")
    keep = np.ones(fit.width, dtype=bool)
    keep[indices] = False
    separation_check = _monotone_separation_certificate(fit.design[:, keep], fit.chain_index, fit.n, fit.k)
    if separation_check["status"] == "separation":
        return unavailable("reduced_nonfinite_mle", "删组模型存在分离方向、没有有限系数最优解，普通整体检验与删除影响不予报告。")
    if separation_check["status"] != "no_certificate":
        return unavailable("reduced_finite_mle_check_failed", separation_check["reason"])
    reduced_nll, theta, converged = _refit_reduced(fit, keep, heartbeat)
    tolerance = _likelihood_tolerance(minimum)
    if math.isfinite(reduced_nll) and reduced_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "删组模型得到更低损失，说明完整模型未建立可信最优解；本次推断全部停用。")
        lrt["reduced_nll"] = reduced_nll
        return lrt, impact
    if not converged or not math.isfinite(reduced_nll):
        return unavailable("reduced_fit_not_converged", "删去该特征后重新拟合未收敛，不能计算可靠的整体检验。")
    bound = float(fit.context.get("logistic_coefficient_bound", 35.))
    # The reduced optimum supplies an independent start for the full model.
    # Any substantially better feasible value invalidates inference around the
    # stored candidate, even if that new optimization has not yet converged.
    lifted = np.zeros(fit.width)
    lifted[keep] = theta
    audited_nll, _, _ = _fit_once(fit.design, fit.chain_index, fit.n, fit.k, lifted, bound, heartbeat)
    if not math.isfinite(audited_nll):
        return unavailable("full_refit_check_failed", "从删组解启动的完整模型复核未得到有限损失，本项整体检验暂不可用。")
    if math.isfinite(audited_nll) and audited_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "从删组结果重新启动完整模型找到更低损失；本次推断全部停用，请重新拟合。")
        lrt.update(reduced_nll=reduced_nll, full_refit_nll=audited_nll)
        return lrt, impact
    # A tiny positive type odds can satisfy a logit-gradient stopping rule
    # without touching its numerical cap. Check the actual nonnegative-odds
    # optimum before claiming the reduced model is regular (mixed-outcome
    # chains need not give the sufficient monotone-separation certificate).
    reduced_engine = _boundary_refit(fit, fit.design[:, keep], theta, heartbeat)
    checked_nll = reduced_engine.evaluate(np.asarray(reduced_engine.state["params"]))[0]
    if math.isfinite(checked_nll) and checked_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "非负 odds 删组复核找到比完整模型更低的损失；本次推断全部停用，请重新拟合。")
        lrt.update(reduced_nll=checked_nll, full_refit_nll=audited_nll)
        return lrt, impact
    odds_check = _odds_refit_validation(reduced_engine)
    if odds_check["status"] != "ok":
        lrt, impact = unavailable("reduced_fit_not_converged", "删组模型的非负 odds、驻点或有限共享效应复核未通过，普通整体检验暂不可用。")
        lrt["reduced_fit_validation"] = odds_check
        return lrt, impact
    reduced_nll = checked_nll
    theta = _boundary_logit_start(reduced_engine, np.asarray(reduced_engine.state["params"]))
    lifted[keep] = theta
    audited_engine = _boundary_refit(fit, fit.design, lifted, heartbeat)
    boundary_audited_nll = audited_engine.evaluate(np.asarray(audited_engine.state["params"]))[0]
    if math.isfinite(boundary_audited_nll) and boundary_audited_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "从非负 odds 删组解重启完整模型找到更低损失；本次推断全部停用，请重新拟合。")
        lrt.update(reduced_nll=reduced_nll, full_refit_nll=boundary_audited_nll)
        return lrt, impact
    full_odds_check = _odds_refit_validation(audited_engine)
    if full_odds_check["status"] != "ok":
        lrt, impact = unavailable("full_refit_check_failed", "从非负 odds 删组解启动的完整模型复核未通过，本项整体检验暂不可用。")
        lrt["full_fit_validation"] = full_odds_check
        return lrt, impact
    audited_nll = boundary_audited_nll
    reduced_zeros = list(reduced_engine.state["zero_type_indices"])
    if not reduced_zeros and np.any(np.abs(theta) >= bound - .1):
        return unavailable("reduced_fit_boundary", "删组模型参数触及数值边界，普通卡方近似不适用。")
    reduced_context = dict(fit.context)
    type_count = len(fit.context["type_ids"])
    reduced_context.update(
        design=fit.design[:, keep], coefficients=theta, negative_log_likelihood=reduced_nll,
        converged=True, clipped=False, boundary_fit=reduced_engine.state if reduced_zeros else None,
        coefficient_columns=[column for index, column in enumerate(fit.context["coefficient_columns"], type_count) if keep[index]],
        categorical_features={name: value for name, value in fit.context.get("categorical_features", {}).items() if name != feature},
    )
    reduced = _FrozenFit(reduced_context)
    impact = _deletion_impact(fit, reduced)
    if reduced_zeros:
        lrt = _empty_lrt("boundary_uncalibrated", "非负 odds 复核发现删组模型新增零风险边界；保留已验证 LR 与删除影响，不套用普通卡方显著性。", minimum)
        lrt.update(statistic=max(0., 2 * (reduced_nll - minimum)), reduced_nll=reduced_nll,
                   full_refit_nll=audited_nll, finite_mle_check=separation_check,
                   reduced_zero_tsk_ids=[fit.context["type_ids"][index] for index in reduced_zeros],
                   reduced_fit_validation=odds_check, full_fit_validation=full_odds_check)
        return lrt, impact
    degrees = fit.information_basis.shape[1] - reduced.information_basis.shape[1]
    if not coefficients_estimable:
        lrt = _empty_lrt("not_identifiable", "空间基底系数不能全部独立识别，未采用普通卡方近似；逐项保留可识别实例的删组预测变化。", minimum)
        lrt.update(statistic=max(0., 2 * (reduced_nll - minimum)), reduced_nll=reduced_nll,
                   full_refit_nll=audited_nll, finite_mle_check=separation_check)
        return lrt, impact
    if degrees != len(indices) or degrees <= 0:
        if allow_aliased:
            lrt = _empty_lrt("rank_changed", "完整模型与删组模型的信息秩不满足常规嵌套检验条件；保留可识别实例的删组预测变化。", minimum)
            lrt.update(statistic=max(0., 2 * (reduced_nll - minimum)), reduced_nll=reduced_nll,
                       full_refit_nll=audited_nll, finite_mle_check=separation_check)
            return lrt, impact
        return unavailable("rank_changed", "完整模型与删组模型的信息秩不满足常规嵌套检验条件，未套用卡方分布。")
    statistic = max(0., 2 * (reduced_nll - minimum))
    lrt = {**_status("ok", "保持相同 Chain 观测，删去整组参数后重拟合；显著性采用本组特征间 Holm 校正。"),
           "df": degrees, "statistic": statistic, "p_value": float(chi2.sf(statistic, degrees)),
           "p_adjusted": None, "significant": None, "full_nll": minimum, "reduced_nll": reduced_nll,
           "critical_value": float(chi2.ppf(1 - alpha, degrees)), "full_refit_nll": audited_nll,
           "finite_mle_check": separation_check}
    return lrt, impact


def _boundary_logit_start(engine: LogisticBoundaryFit, params: np.ndarray) -> np.ndarray:
    """Finite optimizer seeds, never reported as estimates of zero odds."""
    type_count = engine.type_count
    exposure = np.maximum(engine.counts.T @ engine.n, 1.)
    values = np.asarray(params, dtype=float).copy()
    positive = values[:type_count] > 0
    intercepts = -np.maximum(30., np.log(exposure) + 10.)
    intercepts[positive] = np.log(values[:type_count][positive]) + np.log(engine.odds_scale[positive])
    values[:type_count] = intercepts
    return values


def _boundary_refit(fit: _FrozenFit, design: np.ndarray, start: np.ndarray, heartbeat):
    engine = LogisticBoundaryFit(
        design, fit.chain_index, fit.n, fit.k, len(fit.context["type_ids"]),
        coefficient_bound=(fit.boundary_engine.coefficient_bound if fit.boundary_engine is not None
                           else float(fit.context.get("logistic_coefficient_bound", 35.))),
        progress_callback=lambda *_: heartbeat())
    engine.fit(start)
    return engine


def _odds_refit_validation(engine: LogisticBoundaryFit) -> dict[str, Any]:
    """Validate an odds-coordinate audit without interpreting capped logits."""
    state = engine.state
    params = np.asarray(state["params"], dtype=float)
    value, gradient, _, derivative = engine.evaluate(params)
    minimum = state.get("minimum")
    if (not state.get("converged") or state.get("feature_clipped") or minimum is None or not math.isfinite(minimum)
            or not math.isfinite(value) or abs(value - minimum) > _likelihood_tolerance(value)):
        return _status("fit_not_converged", "非负 odds 参数未可靠收敛或与保存似然不一致。")
    if np.any(np.abs(params[engine.type_count:]) >= engine.coefficient_bound - .1):
        return _status("boundary", "共享特征系数触及数值界限，不能认定为有限效应。")
    bounds = [(0., None)] * engine.type_count + [(-engine.coefficient_bound, engine.coefficient_bound)] * (engine.width - engine.type_count)
    residual = engine._kkt(params, gradient, derivative, bounds)
    if not math.isfinite(residual) or residual >= KKT_TOLERANCE:
        return {**_status("fit_not_converged", "非负 odds 参数未通过单侧 KKT 驻点复核。"), "kkt_residual": residual}
    separation = _boundary_separation(engine, params)
    if separation["status"] != "no_certificate":
        return {**_status("finite_mle_check_failed", "非负 odds 复核的有限共享效应检查未通过。"), "finite_mle_check": separation}
    return {**_status("ok", "已复核非负 odds 似然、单侧 KKT 与有限共享效应。"),
            "negative_log_likelihood": value, "kkt_residual": residual, "kkt_threshold": KKT_TOLERANCE,
            "zero_type_indices": np.flatnonzero(params[:engine.type_count] == 0).tolist(), "finite_mle_check": separation}


def _boundary_separation(engine: LogisticBoundaryFit, params: np.ndarray) -> dict[str, Any]:
    # Type-only negative recession is the supported zero-odds closure. Remove
    # only its exact-zero instances; retain ordinary checks on every positive
    # instance, including positive shared-feature recession in all-Fail chains.
    active = np.asarray(params)[engine.type_index] > 0
    return _monotone_separation_certificate(
        engine.design[active], engine.chain_index[active], engine.n, engine.k)


def _drop_boundary_feature(fit: _FrozenFit, feature: str, indices: list[int], heartbeat):
    """Boundary-aware descriptive deletion fit; no chi-square calibration.

    Both engines optimize *all* nonnegative type odds, including the types
    whose saved estimates are zero. Coefficient identifiability does not gate
    this descriptive refit: identified predictions can survive aliased effects.
    """
    minimum, count = fit.minimum, len(fit.design)

    def unavailable(status, reason):
        return _empty_lrt(status, reason, minimum), _empty_impact(status, reason, count)

    if not indices:
        return unavailable("no_variation", "该特征只有一个档位，没有可删除的效应参数，无法检验档位差异。")
    keep = np.ones(fit.width, dtype=bool)
    keep[indices] = False
    start = _boundary_logit_start(fit.boundary_engine, fit.theta)
    engine = _boundary_refit(fit, fit.design[:, keep], start[keep], heartbeat)
    state = engine.state
    reduced_nll = float(state["minimum"]) if state["minimum"] is not None else math.inf
    tolerance = _likelihood_tolerance(minimum)
    if reduced_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "边界删组模型得到更低损失，说明完整模型未建立可信最优解；本次效应分析全部停用。")
        lrt["reduced_nll"] = reduced_nll
        return lrt, impact
    if not state.get("converged") or state.get("feature_clipped") or not math.isfinite(reduced_nll):
        lrt, impact = unavailable("reduced_fit_not_converged", "边界删组拟合未建立可靠收敛或存在发散特征，删除影响暂不可用。")
        lrt["reduced_fit_validation"] = state.get("validation", {})
        return lrt, impact
    separation = _boundary_separation(engine, np.asarray(state["params"]))
    if separation["status"] != "no_certificate":
        status = "reduced_nonfinite_mle" if separation["status"] == "separation" else "reduced_finite_mle_check_failed"
        lrt, impact = unavailable(status, "边界删组模型的有限共享效应检查未通过，删除影响暂不可用。")
        lrt["finite_mle_check"] = separation
        return lrt, impact
    lifted = np.zeros(fit.width)
    lifted[keep] = _boundary_logit_start(engine, np.asarray(state["params"]))
    audited = _boundary_refit(fit, fit.design, lifted, heartbeat)
    audited_nll = audited.state["minimum"]
    if audited_nll is not None and audited_nll < minimum - tolerance:
        lrt, impact = unavailable("full_fit_not_optimal", "从边界删组结果重启完整模型找到更低损失；本次效应分析全部停用，请重新拟合。")
        lrt.update(reduced_nll=reduced_nll, full_refit_nll=audited_nll)
        return lrt, impact
    if not audited.state.get("converged") or audited_nll is None or not math.isfinite(audited_nll):
        return unavailable("full_refit_check_failed", "从边界删组解启动的完整模型复核未可靠收敛，本项删除影响暂不可用。")
    if _boundary_separation(audited, np.asarray(audited.state["params"]))["status"] != "no_certificate":
        return unavailable("full_refit_check_failed", "边界完整模型重拟合的有限共享效应检查未通过，本项删除影响暂不可用。")
    reduced_context = dict(fit.context)
    type_count = engine.type_count
    reduced_context.update(
        design=fit.design[:, keep], coefficients=_boundary_logit_start(engine, np.asarray(state["params"])),
        negative_log_likelihood=reduced_nll, converged=True, clipped=False, boundary_fit=state,
        coefficient_columns=[column for index, column in enumerate(fit.context["coefficient_columns"], type_count) if keep[index]],
        categorical_features={name: value for name, value in fit.context.get("categorical_features", {}).items() if name != feature},
    )
    reduced = _FrozenFit(reduced_context)
    lrt = {**_empty_lrt("boundary_uncalibrated", "采用非负 odds 边界模型重拟合；仅报告似然损失与原始 LR 统计量，参考分布尚未校准，不能判断显著性。", minimum),
           "statistic": max(0., 2 * (reduced_nll - minimum)), "reduced_nll": reduced_nll,
           "full_refit_nll": audited_nll}
    return lrt, _deletion_impact(fit, reduced)


def _boundary_validation(fit: _FrozenFit, heartbeat) -> tuple[str, str] | None:
    """Recheck saved feasibility and finite shared effects without logit caps."""
    engine = fit.boundary_engine
    state = engine.state
    value, gradient, _, derivative = engine.evaluate(fit.theta)
    if (not math.isfinite(value) or abs(value - fit.minimum) > _likelihood_tolerance(fit.minimum)
            or state.get("minimum") is None
            or abs(float(state["minimum"]) - fit.minimum) > _likelihood_tolerance(fit.minimum)):
        return "fit_not_converged", "零风险边界快照的参数与似然损失不一致，请重新拟合。"
    if np.any(np.abs(fit.theta[engine.type_count:]) >= engine.coefficient_bound - .1):
        return "boundary", "共享特征触及数值边界，不能把截断系数当作有限效应估计。"
    bounds = [(0., None)] * engine.type_count + [(-engine.coefficient_bound, engine.coefficient_bound)] * (fit.width - engine.type_count)
    if engine._kkt(fit.theta, gradient, derivative, bounds) >= KKT_TOLERANCE:
        audited = _boundary_refit(fit, fit.design, _boundary_logit_start(engine, fit.theta), heartbeat)
        audited_nll = audited.state.get("minimum")
        if audited_nll is not None and audited_nll < fit.minimum - _likelihood_tolerance(fit.minimum):
            return "full_fit_not_optimal", "重新启动边界完整模型找到更低损失；本次效应分析全部停用，请重新拟合。"
        return "fit_not_converged", "零风险边界参数未通过单侧驻点复核，不能报告稳定的效应点估计。"
    return None


def _prepare_feature_refits(common):
    context, alpha, boundary_mode = common
    return _FrozenFit(context), alpha, boundary_mode


def _feature_refit_task(common, grouped, heartbeat):
    fit, alpha, boundary_mode = common
    try:
        return (_drop_boundary_feature(fit, grouped["name"], grouped["indices"], heartbeat) if boundary_mode else
                _drop_feature(fit, grouped["name"], grouped["indices"], alpha, heartbeat,
                              allow_aliased=grouped["kind"] == "spatial"))
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        reason = "该特征的删组拟合或信息矩阵计算遇到数值异常，整体检验与删除影响暂不可用。"
        lrt = _empty_lrt("numerical_error", reason, fit.minimum)
        lrt["diagnostic_error"] = str(error)
        return lrt, _empty_impact("numerical_error", reason, len(fit.design))


def _unavailable_feature(feature: dict, status: str, reason: str) -> None:
    feature.update(_status(status, reason))
    for row in feature["levels"]:
        if row["reference"]:
            continue
        row.update(_empty_contrast(status, reason), coefficient=None, point_rank=None)
    for row in feature["levels"]:
        row["point_rank"] = None
    for row in feature["pairwise"]:
        row.update(_empty_contrast(status, reason))
    feature["lrt"].update(_status(status, reason), statistic=None, p_value=None,
                          p_adjusted=None, significant=None, critical_value=None)
    feature["deletion_impact"] = _empty_impact(status, reason, feature["deletion_impact"]["instance_count"])


_FIXED_ZERO_WARNING = (
    "列出的 TSK 在原拟合中触及风险下边界，本页在所有特征条件下将其模型失效概率强制固定为 0。"
    "保留全部原始 Chain 观测，仅移除这些 TSK 的风险贡献，并基于其余 TSK 重新拟合。"
    "区间和检验均以这些风险固定为 0 为条件，不包含被固定风险仍可能为正的不确定性，"
    "也未校正根据同一批数据选择固定零类型的影响。"
    "若真实风险并非 0，而是样本数量不足导致估计为 0，其他因素的效应、区间和显著性可能存在偏差，"
    "区间也可能过窄。"
)


def _fixed_zero_layout_impact(impact: dict[str, Any], original: Mapping[str, Any],
                            zero_indices: list[int]) -> None:
    """Restore fixed-zero instances to the original equal-instance layout metric."""
    design = np.asarray(original["design"])
    active_count, total_count = impact["instance_count"], len(design)
    impact["instance_count"] = total_count
    if impact["status"] not in ("ok", "not_identifiable"):
        return
    impact["evaluated_instance_count"] += total_count - active_count
    if impact["mean_abs_probability_change"] is not None:
        for key in ("mean_abs_probability_change", "mean_signed_probability_change"):
            impact[key] *= active_count / total_count
        impact["rms_probability_change"] *= math.sqrt(active_count / total_count)
    fixed = []
    for index in zero_indices:
        count = int(np.count_nonzero(design[:, index]))
        fixed.append({"tsk_id": original["type_ids"][index], "instance_count": count,
                      "evaluated_instance_count": count, **_status("ok", "模型风险固定为 0 的条件下，该 TSK 的删组预测变化恒为 0。"),
                      **_change_metrics(np.zeros(max(count, 1)))})
    rows = {row["tsk_id"]: row for row in [*impact["by_tsk"], *fixed]}
    impact["by_tsk"] = [rows[name] for name in original["type_ids"] if name in rows]


def _restore_fixed_zero_type_effects(report: dict[str, Any], original: Mapping[str, Any], fixed_ids: list[str]) -> None:
    types = list(original["type_ids"])
    fixed = set(fixed_ids)
    row = report["type_effects"]
    existing_levels = {level["level"]: level for level in row["levels"]}
    existing_pairs = {(pair["level_a"], pair["level_b"]): pair for pair in row["pairwise"]}
    row["reference_level"] = next((name for name in types if name not in fixed), None)
    reason = "该比较涉及触及下边界后强制固定 p=0 的 TSK，无法给出有限 log odds 差或普通 Wald 区间；零与零的 odds 比也未定义。"
    pair_count = len(types) * (len(types) - 1) // 2
    limited = pair_count > MAX_TYPE_PAIRS
    limit_reason = f"TSK 共 {pair_count} 个两两对比，超过 {MAX_TYPE_PAIRS} 个的计算上限；未选取部分对比计算显著性。"
    direction_available = (report.get("conditional_refit", {}).get("status") == "ok"
                           and row["status"] in {"ok", "partial", "no_variation", "computation_limited"})
    identifiable_positive = set()
    if direction_available:
        # Recover the already-fitted conditional context; this is a local
        # identifiability check, not another optimization or simulation.
        try:
            keep_types = [index for index, name in enumerate(types) if name not in fixed]
            design = np.asarray(original["design"], dtype=float)
            active = np.any(design[:, keep_types] > 0, axis=1)
            keep_columns = keep_types + list(range(len(types), design.shape[1]))
            conditional = report["conditional_refit"]
            active_types = [types[index] for index in keep_types]
            fit = _FrozenFit(dict(original, boundary_fit=None, converged=True, clipped=False,
                coefficients=conditional["coefficients"], negative_log_likelihood=conditional["negative_log_likelihood"],
                design=design[active][:, keep_columns], chain_index=np.asarray(original["chain_index"])[active],
                type_ids=active_types, all_type_ids=active_types))
            identifiable_positive = {name for index, name in enumerate(active_types) if _type_risk_identifiable(fit, index)}
        except (RuntimeError, ValueError, KeyError, TypeError, FloatingPointError, np.linalg.LinAlgError):
            pass
    levels, pairs = [], []
    for name in types:
        if name in fixed:
            level = {"level": name, "reference": False, "coefficient": None, "point_rank": None,
                     **_empty_contrast("fixed_zero_assumption", reason)}
            if direction_available:
                _add_boundary_direction(level, _boundary_level_direction("lower", "fixed_zero_assumption"))
        else:
            level = existing_levels[name]
            level["reference"] = name == row["reference_level"]
            if limited:
                level.update(_empty_contrast("computation_limited", limit_reason), coefficient=None, point_rank=None)
        levels.append(level)
    for name_a, name_b in ([] if limited else combinations(types, 2)):
        if name_a in fixed or name_b in fixed:
            pair = {"level_a": name_a, "level_b": name_b, "contrast": "b_minus_a",
                    **_empty_contrast("fixed_zero_assumption", reason)}
            if direction_available and all(name in fixed or name in identifiable_positive for name in (name_a, name_b)):
                _add_boundary_direction(pair, _boundary_pair_direction(
                    "lower" if name_a in fixed else "interior",
                    "lower" if name_b in fixed else "interior", "fixed_zero_assumption"))
        else:
            pair = existing_pairs[(name_a, name_b)]
        pairs.append(pair)
    row.update(levels=levels, pairwise=pairs, pairwise_count=pair_count,
               pairwise_limit=MAX_TYPE_PAIRS, pairwise_omitted_count=pair_count if limited else 0,
               computed_pairwise_count=sum(pair["p_value"] is not None for pair in pairs))
    _holm(pairs, report["alpha"])
    if limited:
        row.update(_status("computation_limited", limit_reason))
    elif row["status"] in ("ok", "partial", "no_variation") and fixed:
        row.update(_status("partial", "仅对未固定为零的 TSK 给出条件类型对比；涉及固定零类型的比较不可用。"))


def _build_fixed_zero_effects(context: Mapping[str, Any], confidence: float, progress,
                              analysis_workers: int = 0) -> dict[str, Any]:
    """Condition on verified exact zero type odds, then genuinely reduce and refit.

    Original Chain counts, including mixed and pure-zero chains, stay intact.
    Only fixed-zero instance contributions and their type parameters disappear.
    No capped Logistic placeholder is interpreted as a finite zero estimate.
    """
    state = context["boundary_fit"]
    original_types = list(context["type_ids"])
    zero_indices = list(state["zero_type_indices"])
    valid_zero_indices = all(isinstance(index, (int, np.integer)) and not isinstance(index, bool)
                             and 0 <= index < len(original_types) for index in zero_indices)
    fixed_ids = [original_types[index] for index in zero_indices] if valid_zero_indices else []
    metadata = {"inference_mode": "fixed_zero_conditional", "zero_risk_policy": "fixed_zero",
                "fixed_zero_tsk_ids": fixed_ids, "assumption_warning": _FIXED_ZERO_WARNING,
                "conditional_refit": {"status": "not_completed", "chain_count": len(context["chain_ids"]),
                                      "original_instance_count": len(context["design"])}}
    confirmed_zero_indices = False

    def finish(result):
        result.update(metadata)
        result["warnings"].insert(0, _FIXED_ZERO_WARNING)
        result["model_scope"] = ("固定零约束下的共享主效应 Logistic：仅由其余 TSK 支持因素效应、OR、条件区间和检验。")
        result["methods"].update(
            zero_risk_policy="exact_zero_type_odds_fixed_zero_all_original_chain_observations_retained",
            coefficient_interval="fixed_zero_conditional_joint_expected_fisher_information_wald_pointwise",
            pairwise_test="fixed_zero_conditional_two_sided_wald_within_feature_holm",
            overall_test="fixed_zero_conditional_drop_feature_refit_chain_binomial_likelihood_ratio_holm",
        )
        prefix = "条件于列出的 TSK 模型风险固定为 0；"
        if confirmed_zero_indices:
            _restore_fixed_zero_type_effects(result, context, fixed_ids)
            if not result["features"] and result["status"] in ("ok", "partial", "no_features", "computation_limited"):
                result.update(_status(result["type_effects"]["status"], result["type_effects"]["reason"]))
        for row in [result["type_effects"], *result["type_effects"]["levels"], *result["type_effects"]["pairwise"]]:
            if row["status"] == "ok":
                row["reason"] = prefix + row["reason"]
        for feature in result["features"]:
            for row in [feature, *feature["levels"], *feature["pairwise"], feature["lrt"], feature["deletion_impact"]]:
                if row["status"] == "ok":
                    row["reason"] = prefix + row["reason"]
            _fixed_zero_layout_impact(feature["deletion_impact"], context, zero_indices if valid_zero_indices else [])
        if result["status"] == "ok":
            result["reason"] = "已在固定零约束下完成重新拟合、条件区间和特征检验。"
        return _plain(result)

    def unavailable(status, reason):
        # Reuse the common row/contrast schema without invoking an optimizer or
        # attempting to interpret the unavailable boundary snapshot.
        failed_context = dict(context, boundary_fit=None, converged=False)
        report = build_tsk_feature_effects(failed_context, confidence_level=confidence,
                                          progress_callback=lambda *_: None, zero_risk_policy="boundary")
        report.update(_status(status, reason))
        for feature in report["features"]:
            _unavailable_feature(feature, status, reason)
        report["type_effects"] = _type_effects(_FrozenFit(failed_context), 0., 1 - confidence, (status, reason))
        metadata["conditional_refit"].update(_status(status, reason))
        progress(100, "固定零风险条件分析未满足推断条件。")
        return finish(report)

    progress(0, "将触及下边界的 TSK 风险固定为 0，重新拟合其余 TSK…")
    try:
        engine = LogisticBoundaryFit(context["design"], context["chain_index"], context["n_tested"],
                                     context["n_failed"], len(original_types),
                                     coefficient_bound=float(context.get("logistic_coefficient_bound", 35.)))
        engine.load_state(state)
        params = np.asarray(state["params"], dtype=float)
        exact_zeros = np.flatnonzero(params[:engine.type_count] == 0).tolist()
        if not valid_zero_indices or sorted(zero_indices) != exact_zeros:
            return unavailable("boundary", "零风险类型列表与保存的精确零 odds 不一致，未采用数值截断阈值推定零风险；请重新拟合。")
        confirmed_zero_indices = True
        keep_types = np.flatnonzero(params[:engine.type_count] > 0)
        active = params[engine.type_index] > 0
        has_active_risk = np.bincount(engine.chain_index[active], minlength=len(engine.n)) > 0
        impossible = ~has_active_risk & (engine.k > 0)
        if impossible.any():
            ids = [context["chain_ids"][index] for index in np.flatnonzero(impossible)]
            metadata["conditional_refit"]["incompatible_chain_ids"] = ids
            return unavailable("fixed_zero_incompatible", "固定零风险与原始 Fail 观测不相容：以下 Chain 没有剩余风险贡献却存在 Fail：" + "、".join(ids))
        if not len(keep_types) or not active.any():
            return unavailable("no_active_tsk", "全部 TSK 都被固定为零风险，没有可用于估计其他因素效应的 TSK。")
        if not context.get("converged") or not state.get("converged") or state.get("feature_clipped"):
            return unavailable("fit_not_converged", "原始边界拟合未建立可靠收敛，不能据此选择固定零风险类型。")
        invalid = _boundary_validation(_FrozenFit(context), lambda: progress(1, "复核用于固定零风险的原始边界拟合…"))
        if invalid is not None:
            return unavailable(*invalid)
        keep_columns = np.r_[keep_types, np.arange(engine.type_count, engine.width)]
        design = engine.design[active][:, keep_columns]
        chain_index = engine.chain_index[active]
        start = params[keep_columns].copy()
        start[:len(keep_types)] = np.log(params[keep_types]) + np.log(engine.odds_scale[keep_types])
        separation = _monotone_separation_certificate(design, chain_index, engine.n, engine.k)
        if separation["status"] != "no_certificate":
            status = "nonfinite_mle" if separation["status"] == "separation" else "finite_mle_check_failed"
            return unavailable(status, "固定零风险后，其余 TSK 的有限系数检查未通过：" + separation["reason"])
        value = _feature_loss_and_derivative(design, chain_index, engine.n, engine.k, start)[0]
        reduced_context = dict(context)
        reduced_context.update(
            boundary_fit=None, design=design, chain_index=chain_index, coefficients=start,
            type_ids=[original_types[index] for index in keep_types],
            all_type_ids=[original_types[index] for index in keep_types],
            negative_log_likelihood=value, converged=True, clipped=False,
        )
        if "topology" in context:
            reduced_context["topology"] = [row for row in context["topology"] if row["tsk_id"] not in fixed_ids]
        initial = _FrozenFit(reduced_context)
        last_update = monotonic()

        def heartbeat():
            nonlocal last_update
            if monotonic() - last_update >= .25:
                progress(2, "固定零风险，正在重新拟合其余 TSK 与共享特征…")
                last_update = monotonic()

        minimum, theta, converged = _refit_reduced(
            initial, np.ones(initial.width, dtype=bool), heartbeat)
        if not converged or not math.isfinite(minimum):
            return unavailable("conditional_fit_not_converged", "固定零风险后的条件模型未可靠收敛，暂不提供误差区间和检验。")
        reduced_context.update(coefficients=theta, negative_log_likelihood=minimum)
        metadata["conditional_refit"].update(
            status="ok", active_tsk_ids=reduced_context["type_ids"], active_instance_count=int(active.sum()),
            fixed_zero_instance_count=int((~active).sum()), parameter_count=len(theta),
            chain_ids=list(context["chain_ids"]), n_tested=engine.n.tolist(), n_failed=engine.k.tolist(),
            original_nll=context["negative_log_likelihood"], negative_log_likelihood=minimum,
            coefficients=theta.tolist(), coefficient_columns=context["coefficient_columns"],
        )
        result = build_tsk_feature_effects(
            reduced_context, confidence_level=confidence,
            progress_callback=lambda percent, message: progress(5 + .95 * percent, message), zero_risk_policy="boundary",
            analysis_workers=analysis_workers)
        return finish(result)
    except (RuntimeError, ValueError, KeyError, TypeError, FloatingPointError, np.linalg.LinAlgError) as error:
        metadata["conditional_refit"]["diagnostic_error"] = str(error)
        return unavailable("boundary", "固定零风险模型的保存参数、降维重拟合或信息矩阵无效，暂不提供条件区间；请重新拟合。")


def build_tsk_feature_effects(
    context: Mapping[str, Any], *, confidence_level: float | None = None,
    progress_callback: Callable[[float, str], None] | None = None,
    zero_risk_policy: str = "fixed_zero",
    simulation_replicates: int = 999,
    simulation_seed: int = 1729,
    simulation_workers: int = 0,
    analysis_workers: int = 0,
    _defer_feature_refits: bool = False,
) -> dict[str, Any]:
    """Return JSON-safe inference and descriptive deletion sensitivity, without mutation.

    Holm families are declared before testing: all selected features for LRTs,
    and every unordered pair of declared levels within each category.  A test
    that cannot be computed stays in its family with a placeholder p of one.
    Reference zeros are encoding conventions, never independently estimated
    effects.  Pointwise confidence intervals are not Holm-adjusted intervals.
    By default exact-zero types are held at zero under an explicit assumption
    and remaining effects are refitted with conditional intervals. Select
    ``zero_risk_policy="boundary"`` to retain free boundary risks and report
    only uncalibrated descriptive boundary effects.
    """
    if not isinstance(context, Mapping):
        raise ValueError("A frozen TSK Logistic context is required.")
    if context.get("model") == "type_only":
        context = _type_only_logistic_context(context)
    if zero_risk_policy not in ("fixed_zero", "boundary", "boundary_simulation"):
        raise ValueError("Zero-risk policy must be 'fixed_zero', 'boundary', or 'boundary_simulation'.")
    from .tsk_simulation_inference import validate_simulation_settings
    validate_simulation_settings(simulation_replicates, simulation_seed, simulation_workers)
    validate_analysis_workers(analysis_workers)
    confidence = float(context.get("confidence_level", .95) if confidence_level is None else confidence_level)
    if not math.isfinite(confidence) or not 0 < confidence < 1:
        raise ValueError("Confidence level must be strictly between zero and one.")
    categorical = context.get("categorical_features", {})
    columns = list(context.get("coefficient_columns", []))
    type_count = len(context.get("type_ids", []))
    if any(not isinstance(column, (tuple, list)) or len(column) != 2 for column in columns):
        raise ValueError("Invalid fitted feature coefficient columns.")
    if len(columns) + type_count != len(context.get("coefficients", [])):
        raise ValueError("Feature coefficient columns do not match the fitted parameters.")
    definitions = _feature_definitions(context)
    names = [definition["name"] for definition in definitions]
    progress = progress_callback or (lambda *_: None)
    if zero_risk_policy == "boundary_simulation":
        from .tsk_simulation_inference import build_boundary_simulation
        return build_boundary_simulation(context, confidence_level=confidence,
                                         simulation_replicates=simulation_replicates, simulation_seed=simulation_seed,
                                         simulation_workers=simulation_workers,
                                         progress_callback=progress)
    if zero_risk_policy == "fixed_zero" and (context.get("boundary_fit") or {}).get("zero_type_indices"):
        return _build_fixed_zero_effects(context, confidence, progress, analysis_workers)
    progress(0, "计算特征效应与整体删组检验…")
    # Positive-odds snapshots retain the ordinary finite-logit path. Active
    # zeros instead use the saved scaled-odds parameters, never capped logits.
    ordinary_context = dict(context)
    ordinary_context["boundary_fit"] = None
    fit = _FrozenFit(ordinary_context)
    alpha = 1 - confidence
    result = {"version": 1, **_status("ok", "已完成特征效应分析。"),
              "confidence_level": confidence, "alpha": alpha,
              "model_scope": "共享主效应 Logistic：控制其他条件后比较单实例风险；不同 TSK 共用档位系数与 OR。",
              "methods": dict(_METHODS), "features": [],
              "warnings": [
                  "系数和 OR 是条件关联；OR 不是失效率倍数，也不是因果影响。",
                  "区间是未作多重比较校正的逐项区间；显著与否依据 Holm 校正后的 p 值。",
                  "未检出显著差异不代表相同或等效，点估计顺序也不代表顺序已经证实。",
                  "检验采用大样本近似并假设 Chain 观测独立，尚未修正同一 die/wafer 内的相关性。",
                  "可辨识检查基于设计及局部信息；多起点检查不保证全局唯一最优。",
                  "删除影响仅描述原有效布局上的模型预测变化，不自动给出可安全删除或等效结论。",
              ]}
    boundary = context.get("boundary_fit") or {}
    boundary_mode = bool(boundary.get("zero_type_indices"))
    invalid = context.get("_type_only_invalid")
    if boundary_mode:
        try:
            fit = _FrozenFit(context)
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError):
            invalid = ("boundary", "零风险边界快照不完整或无效，请重新拟合后计算特征影响。")
    if invalid is None and (not fit.valid_fit or (boundary and (not boundary.get("converged") or boundary.get("feature_clipped")))):
        invalid = ("fit_not_converged", "完整模型未建立稳定收敛的有限解，不能给出常规效应推断。")
    elif invalid is None and boundary_mode:
        try:
            invalid = _boundary_validation(fit, lambda: progress(2, "复核零风险边界完整模型…"))
        except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError):
            invalid = ("fit_not_converged", "零风险边界完整模型复核遇到数值异常，暂不报告效应。")
    elif invalid is None and np.any(np.abs(fit.theta) >= float(context.get("logistic_coefficient_bound", 35.)) - .1):
        invalid = ("boundary", "完整模型参数触及数值边界，不能把截断系数当作有限效应估计。")
    if invalid:
        result["finite_mle_check"] = _status("not_checked", "完整模型已有不可用状态，不继续分离检查。")
    else:
        result["finite_mle_check"] = (_boundary_separation(fit.boundary_engine, fit.theta) if boundary_mode else
                                      _monotone_separation_certificate(fit.design, fit.chain_index, fit.n, fit.k))
        if result["finite_mle_check"]["status"] == "separation":
            invalid = ("nonfinite_mle", "数据存在分离方向，系数可趋向无穷而继续改善似然；即使优化器称已收敛，也不能报告普通 Wald 或 LRT。")
        elif result["finite_mle_check"]["status"] != "no_certificate":
            invalid = ("finite_mle_check_failed", result["finite_mle_check"]["reason"])
    if invalid is None and not names and not boundary_mode:
        # With no feature deletion there is no later optimization audit. Verify
        # the saved ordinary likelihood and its finite stationary conditions.
        value, gradient, _, _ = fit.evaluate(fit.theta)
        informative_n = max(float(fit.n[np.unique(fit.chain_index)].sum()), 1.)
        if (not math.isfinite(value) or abs(value - fit.minimum) > _likelihood_tolerance(fit.minimum)
                or not np.all(np.isfinite(gradient)) or np.max(np.abs(gradient), initial=0.) / informative_n >= 1e-8):
            invalid = ("fit_not_converged", "无其他特征的 TSK 快照未通过似然与有限参数驻点复核，类型区间和检验不可用。")
    if boundary_mode:
        result["methods"].update(
            coefficient_interval="unavailable_at_zero_odds_boundary",
            pairwise_test="unavailable_at_zero_odds_boundary",
            overall_test="boundary_odds_drop_feature_raw_likelihood_ratio_uncalibrated",
            contrast_identifiability="scaled_odds_local_feasible_flat_direction_check",
            type_effects="positive_type_log_odds_locally_identifiable_point_contrast",
            type_pairwise_test="unavailable_at_zero_odds_boundary",
        )
        result["warnings"][1] = "完整模型含零风险边界：仅保留可辨识的有限效应点估计及可靠的删除预测变化；不提供未经校准的标准误、区间或显著性。"
        result["warnings"][3] = "边界 LR 仅是原始似然比较统计量，不使用普通卡方分布或固定混合卡方分布计算 p 值。"
        result["warnings"].append("模型仍假设 Chain 观测独立，尚未修正同一 die/wafer 内的相关性。")
        result["warnings"].append("共享 OR 由有信息的 TSK 支持；零风险 TSK 的两档 odds 同为 0，不能将共享 OR 解释为该类型已被数据独立证实的 0/0 比值。")
    cutoff = float(norm.ppf((1 + confidence) / 2))
    parallel_refits = None
    # Process startup dominates tiny fits. Explicit worker selections permit
    # benchmarking those cases; larger independent deletions share one pool.
    # In particular, starting one process for every cheap feature can cost much
    # more than all of their fits. Ramp up the automatic budget conservatively.
    work_units = fit.design.size * len(definitions)
    refit_workers = analysis_workers
    if not refit_workers:
        refit_workers = (1 if work_units < 2_000_000 else
                         min(worker_count(0, len(definitions)), max(2, min(4, work_units // 2_000_000))))
    if (invalid is None and not _defer_feature_refits
            and worker_count(refit_workers, len(definitions)) > 1):
        execution = {}
        parallel_refits = ordered_parallel_map(
            _feature_refit_task, definitions, common=(fit.context, alpha, boundary_mode),
            prepare_common=_prepare_feature_refits, workers=refit_workers, execution=execution,
            progress_callback=lambda done, total: progress(5 + 85 * done / max(total, 1),
                f"并行特征删组拟合与最优解复核：{done}/{total}…"))
        result["warnings"].extend(execution.get("execution_warnings", []))
    for feature_index, grouped in enumerate(definitions):
        name = grouped["name"]
        spatial = grouped["kind"] == "spatial"
        base_progress = ((90 + 5 * feature_index / max(len(names), 1)) if parallel_refits is not None else
                         5 + 90 * feature_index / max(len(names), 1))
        progress(base_progress, f"特征 {name}：计算档位对比并重拟合删组模型…")
        last_update = monotonic()

        def heartbeat():
            nonlocal last_update
            if monotonic() - last_update >= .25:
                progress(base_progress, f"特征 {name}：正在重拟合与核查最优解…")
                last_update = monotonic()

        indices = grouped["indices"]
        definition = categorical.get(name)
        reference = str(definition["reference"]) if definition else None
        feature = {"feature": name, "kind": grouped["kind"], "label": grouped["label"],
                   "column_names": grouped["column_names"],
                   "reference_level": reference, **_status("ok", "效应可计算；是否显著请查看对应检验。"),
                   "levels": [], "pairwise": [],
                   "lrt": _empty_lrt("unavailable", "尚未计算整体检验。", fit.minimum),
                   "deletion_impact": _empty_impact("unavailable", "尚未计算删除影响。", len(fit.design))}
        if spatial:
            feature["reason"] = "XY 位置的全部空间基底作为一个因素整体删组；位置效应随坐标变化，没有统一的增加一个 scale 的 OR。"
        vectors = {}
        levels = [] if spatial else [str(level) for level in definition["levels"]] if definition else ["增加一个 scale"]
        column_map = {str(column[1]): type_count + index for index, column in enumerate(columns) if column[0] == name}
        for level in levels:
            vector = np.zeros(fit.width)
            is_reference = bool(definition and level == reference)
            if not is_reference:
                index = column_map.get(level) if definition else (indices[0] if len(indices) == 1 else None)
                if index is None:
                    raise ValueError(f"Missing fitted coefficient for {name!r}, {level!r}.")
                vector[index] = 1.
            vectors[level] = vector
            if is_reference:
                data = _empty_contrast("reference_coding", "参考档固定编码为 0、OR 为 1；没有独立标准误，不代表失效率为 0。")
                data.update(difference=0., odds_ratio=1.)
            elif invalid:
                data = _empty_contrast(*invalid)
            elif boundary_mode:
                data = _boundary_contrast(fit, vector)
            else:
                data = _wald(fit, vector, cutoff)
            row = {"level": level, "reference": is_reference, **data,
                   "coefficient": data["difference"], "point_rank": None}
            if not definition:
                row.update(context.get("numeric_scaling", {}).get(name, {}))
            feature["levels"].append(row)
        if definition:
            for level_a, level_b in combinations(levels, 2):
                vector = vectors[level_b] - vectors[level_a]
                data = (_empty_contrast(*invalid) if invalid else
                        _boundary_contrast(fit, vector) if boundary_mode else _wald(fit, vector, cutoff))
                feature["pairwise"].append({"level_a": level_a, "level_b": level_b,
                                            "contrast": "b_minus_a", **data})
            _holm(feature["pairwise"], alpha)
            if all(row["coefficient"] is not None for row in feature["levels"]):
                rank, previous = 0, None
                for row in sorted(feature["levels"], key=lambda item: item["coefficient"]):
                    if previous is None or row["coefficient"] != previous:
                        rank += 1
                    row["point_rank"] = rank
                    previous = row["coefficient"]
        if invalid:
            feature["lrt"] = _empty_lrt(*invalid, fit.minimum)
            feature["deletion_impact"] = _empty_impact(*invalid, len(fit.design))
            _unavailable_feature(feature, *invalid)
        elif not _defer_feature_refits:
            feature["lrt"], feature["deletion_impact"] = (
                parallel_refits[feature_index] if parallel_refits is not None else
                _feature_refit_task((fit, alpha, boundary_mode), grouped, heartbeat))
            if boundary_mode and feature["lrt"]["status"] == "boundary_uncalibrated":
                feature.update(_status("point_estimate_only", "零风险边界下逐项保留可辨识点估计及删除预测变化；显著性尚未校准。"))
            elif feature["lrt"]["status"] != "ok":
                feature.update(_status(feature["lrt"]["status"], feature["lrt"]["reason"]))
        result["features"].append(feature)
        if feature["lrt"]["status"] == "full_fit_not_optimal":
            invalid = ("full_fit_not_optimal", feature["lrt"]["reason"])
    if invalid:
        result.update(_status(*invalid))
        for feature in result["features"]:
            _unavailable_feature(feature, *invalid)
    result["type_effects"] = _type_effects(fit, cutoff, alpha, invalid, boundary_mode=boundary_mode)
    if not invalid:
        _holm([feature["lrt"] for feature in result["features"]], alpha)
        if not names:
            if len(result["type_effects"]["levels"]) >= 2:
                result.update(_status(result["type_effects"]["status"], result["type_effects"]["reason"]))
            else:
                result.update(_status("no_features", "当前模型没有其他特征，且不足两个 TSK，无法进行因素或类型间比较。"))
        elif boundary_mode and all(feature["status"] == "point_estimate_only" for feature in result["features"]):
            result.update(_status("point_estimate_only", "零风险边界下已完成可辨识效应点估计与删除预测变化；标准误、区间和显著性尚未校准。"))
        elif any(feature["status"] != "ok" for feature in result["features"]):
            result.update(_status("partial", "部分特征无法进行常规检验，请查看各项原因。"))
    progress(100, "特征效应分析完成。")
    return _plain(result)
