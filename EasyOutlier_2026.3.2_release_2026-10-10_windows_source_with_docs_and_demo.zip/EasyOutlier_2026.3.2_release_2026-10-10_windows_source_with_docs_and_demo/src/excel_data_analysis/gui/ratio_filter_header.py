"""Native sortable table headers with a separate column-filter target."""
from __future__ import annotations

from PySide6.QtCore import QEvent, QPoint, QRect, QSize, Qt, Signal
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QHeaderView, QStyle, QStyleOption, QStyleOptionHeader, QToolTip


class RatioFilterHeader(QHeaderView):
    filterRequested = Signal(int, QPoint)

    def __init__(self, parent=None):
        super().__init__(Qt.Horizontal, parent)
        self._hovered_filter = -1
        self._pressed_filter = -1
        self._pressed_button = Qt.NoButton

    def _filter_dimensions(self):
        width = max(0, int(self.property("filterButtonWidth") or 0))
        margin = max(0, int(self.property("filterButtonMargin") or 0))
        return width, margin

    def filter_button_rect(self, logical_index):
        width, margin = self._filter_dimensions()
        if not width or not 0 <= logical_index < self.count() or self.isSectionHidden(logical_index):
            return QRect()
        section_left = self.sectionViewportPosition(logical_index)
        section_width = self.sectionSize(logical_index)
        button_width = min(width, max(0, section_width - 2 * margin))
        return QRect(section_left + section_width - margin - button_width, margin,
                     button_width, max(0, self.viewport().height() - 2 * margin))

    def _has_filter(self, logical_index):
        getter = getattr(self.model(), "column_filter", None)
        return callable(getter) and getter(logical_index) is not None

    def sectionSizeFromContents(self, logical_index):
        size = super().sectionSizeFromContents(logical_index)
        width, margin = self._filter_dimensions()
        return QSize(size.width() + (width + 2 * margin if width else 0), size.height())

    def paintSection(self, painter, rect, logical_index):
        width, margin = self._filter_dimensions()
        if not width or not rect.isValid():
            super().paintSection(painter, rect, logical_index)
            return
        option = QStyleOptionHeader()
        self.initStyleOption(option)
        self.initStyleOptionForIndex(option, logical_index)
        option.rect = rect
        style = self.style()
        painter.save()
        style.drawControl(QStyle.CE_HeaderSection, option, painter, self)
        # Keep Qt's own title and sort-indicator layout inside the remaining area.
        option.rect = rect.adjusted(0, 0, -(width + 2 * margin), 0)
        if option.rect.isValid():
            style.drawControl(QStyle.CE_Header, option, painter, self)

        button_rect = self.filter_button_rect(logical_index)
        button_option = QStyleOption()
        button_option.initFrom(self)
        button_option.rect = button_rect
        button_option.state &= ~(QStyle.State_MouseOver | QStyle.State_Sunken)
        if logical_index == self._hovered_filter:
            button_option.state |= QStyle.State_MouseOver
        if logical_index == self._pressed_filter:
            button_option.state |= QStyle.State_Sunken
        if self._has_filter(logical_index):
            painter.fillRect(button_rect, self.palette().brush(QPalette.Highlight))
            for role in (QPalette.Text, QPalette.WindowText, QPalette.ButtonText):
                button_option.palette.setBrush(role, self.palette().brush(QPalette.HighlightedText))
        elif logical_index in (self._hovered_filter, self._pressed_filter):
            style.drawPrimitive(QStyle.PE_PanelButtonTool, button_option, painter, self)
        indicator_size = min(style.pixelMetric(QStyle.PM_MenuButtonIndicator, None, self),
                             button_rect.width(), button_rect.height())
        if indicator_size > 0:
            button_option.rect = QStyle.alignedRect(
                self.layoutDirection(), Qt.AlignCenter, QSize(indicator_size, indicator_size), button_rect)
            style.drawPrimitive(QStyle.PE_IndicatorArrowDown, button_option, painter, self)
        painter.restore()

    def _filter_at(self, position):
        logical_index = self.logicalIndexAt(position)
        return logical_index if self.filter_button_rect(logical_index).contains(position) else -1

    def _request_filter(self, logical_index):
        anchor = QPoint(self.sectionViewportPosition(logical_index) + self.sectionSize(logical_index),
                        self.viewport().height())
        self.filterRequested.emit(logical_index, self.viewport().mapToGlobal(anchor))

    def mousePressEvent(self, event):
        position = event.position().toPoint()
        logical_index = self.logicalIndexAt(position)
        if logical_index >= 0 and (event.button() == Qt.RightButton or
                                  event.button() == Qt.LeftButton and self._filter_at(position) >= 0):
            self._pressed_filter = logical_index
            self._pressed_button = event.button()
            self.viewport().update(self.filter_button_rect(logical_index))
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if self._pressed_filter >= 0:
            logical_index = self._pressed_filter
            pressed_button = self._pressed_button
            self._pressed_filter = -1
            self._pressed_button = Qt.NoButton
            self.viewport().update(self.filter_button_rect(logical_index))
            position = event.position().toPoint()
            same_target = (self.logicalIndexAt(position) == logical_index if pressed_button == Qt.RightButton
                           else self._filter_at(position) == logical_index)
            if event.button() == pressed_button and same_target:
                self._request_filter(logical_index)
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        if self._filter_at(event.position().toPoint()) >= 0:
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def mouseMoveEvent(self, event):
        hovered = self._filter_at(event.position().toPoint())
        if hovered != self._hovered_filter:
            previous = self._hovered_filter
            self._hovered_filter = hovered
            self.viewport().update(self.filter_button_rect(previous))
            self.viewport().update(self.filter_button_rect(hovered))
        super().mouseMoveEvent(event)

    def leaveEvent(self, event):
        previous = self._hovered_filter
        self._hovered_filter = -1
        self.viewport().update(self.filter_button_rect(previous))
        super().leaveEvent(event)

    def viewportEvent(self, event):
        if event.type() == QEvent.ToolTip:
            logical_index = self._filter_at(event.pos())
            if logical_index >= 0:
                property_name = "activeFilterToolTip" if self._has_filter(logical_index) else "filterToolTip"
                template = self.property(property_name) or ""
                column = self.model().headerData(logical_index, Qt.Horizontal, Qt.DisplayRole)
                QToolTip.showText(event.globalPos(), template.format(column=column), self.viewport(),
                                  self.filter_button_rect(logical_index))
                return True
        return super().viewportEvent(event)
