from collections.abc import Iterable

from PySide6.QtCore import QSignalBlocker, Qt
from PySide6.QtWidgets import QDialog, QListWidgetItem, QWidget

from .ui_ratio_column_filter_dialog import Ui_RatioColumnFilterDialog


class RatioColumnFilterDialog(QDialog):
    def __init__(
        self,
        column_name: str,
        values: Iterable[str],
        selected_values: set[str] | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_RatioColumnFilterDialog()
        self.ui.setupUi(self)
        self.action = "filter"
        self.ui.columnNameLabel.setText(column_name)
        self.ui.clearColumnButton.setEnabled(selected_values is not None)
        blank_text = str(self.property("blankText"))
        for value in dict.fromkeys(values):
            item = QListWidgetItem(value if value else blank_text)
            item.setData(Qt.ItemDataRole.UserRole, value)
            item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            checked = selected_values is None or value in selected_values
            item.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
            self.ui.valuesListWidget.addItem(item)
        self.ui.searchLineEdit.textChanged.connect(self._filter_values)
        self.ui.valuesListWidget.itemChanged.connect(self._sync_select_all)
        self.ui.selectAllCheckBox.clicked.connect(self._toggle_visible_values)
        self.ui.sortAscendingButton.clicked.connect(lambda: self._choose_action("sort_ascending"))
        self.ui.sortDescendingButton.clicked.connect(lambda: self._choose_action("sort_descending"))
        self.ui.clearColumnButton.clicked.connect(lambda: self._choose_action("clear"))
        self._filter_values("")
        self.ui.searchLineEdit.setFocus()

    def selected_values(self) -> set[str]:
        return {
            item.data(Qt.ItemDataRole.UserRole)
            for item in self._visible_items()
            if item.checkState() == Qt.CheckState.Checked
        }

    def _visible_items(self) -> list[QListWidgetItem]:
        return [
            self.ui.valuesListWidget.item(row)
            for row in range(self.ui.valuesListWidget.count())
            if not self.ui.valuesListWidget.item(row).isHidden()
        ]

    def _filter_values(self, text: str) -> None:
        query = text.casefold()
        for row in range(self.ui.valuesListWidget.count()):
            item = self.ui.valuesListWidget.item(row)
            item.setHidden(query not in item.text().casefold())
        visible_items = self._visible_items()
        self.ui.noResultsLabel.setVisible(not visible_items)
        self.ui.selectAllCheckBox.setEnabled(bool(visible_items))
        self._sync_select_all()

    def _sync_select_all(self, _item: QListWidgetItem | None = None) -> None:
        items = self._visible_items()
        checked_count = sum(item.checkState() == Qt.CheckState.Checked for item in items)
        state = Qt.CheckState.Unchecked
        if checked_count:
            state = Qt.CheckState.Checked if checked_count == len(items) else Qt.CheckState.PartiallyChecked
        with QSignalBlocker(self.ui.selectAllCheckBox):
            self.ui.selectAllCheckBox.setCheckState(state)

    def _toggle_visible_values(self, _checked: bool) -> None:
        state = self.ui.selectAllCheckBox.checkState()
        target = Qt.CheckState.Unchecked if state == Qt.CheckState.Unchecked else Qt.CheckState.Checked
        with QSignalBlocker(self.ui.valuesListWidget):
            for item in self._visible_items():
                item.setCheckState(target)
        self._sync_select_all()

    def _choose_action(self, action: str) -> None:
        self.action = action
        self.accept()
