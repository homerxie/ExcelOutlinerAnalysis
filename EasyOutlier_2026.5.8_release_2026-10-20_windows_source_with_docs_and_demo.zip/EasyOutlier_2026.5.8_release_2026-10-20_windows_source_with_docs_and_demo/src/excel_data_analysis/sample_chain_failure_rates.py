"""Per-sample chain failure rates derived from completed Analyze decisions.

These views consume saved final chain states, including passing states. They do
not read current measurements, rerun classification, or require a TSK topology.
"""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any

from .reporting import (
    _build_sample_node_ancestor_chains,
    _configured_node_orders,
    _resolve_sample_node_order,
    _sample_key_from_dimensions,
)
from .tsk_sorting import natural_sort_key


def build_sample_chain_failure_rows(
    final_status_rows: Iterable[Mapping[str, Any]],
    *,
    node_orders: Sequence[Sequence[str]] = (),
    sample_nodes: Iterable[tuple[Sequence[str], str]] = (),
) -> list[dict[str, Any]]:
    """Count unique merged chain keys within every sample and observed node.

    Both rates use the current node's valid chain count as their denominator.
    New follows Analyze's saved ``New`` status. Cumulative retains any failure
    in the current node or its configured ancestors, even after recovery, but
    only for chains valid at the current node. Separate node-order branches do
    not contribute to one another. No order is inferred from node spelling.

    ``sample_nodes`` also retains samples with no valid final chain states;
    those rows have a zero denominator and unavailable (None) rates. Duplicate
    records count once; conflicting duplicate decisions are rejected. Complete
    tuple identities prevent display-label or same-name-chain collisions.
    Inputs are never mutated.
    """
    states: dict[tuple[str, ...], dict[str, dict[tuple[str, ...], tuple[bool, str]]]] = defaultdict(dict)
    for sample, node in sample_nodes:
        sample_key = tuple(str(value) for value in sample)
        if sample_key and all(sample_key) and node:
            states[sample_key].setdefault(str(node), {})
    for record in final_status_rows:
        sample_key = tuple(str(value) for value in record.get("sample_key", ()))
        chain_key = tuple(str(value) for value in record.get("test_group_key", ()))
        node = str(record.get("node", ""))
        if not sample_key or not all(sample_key) or not chain_key or not node:
            raise ValueError("已保存的 Analyze 链路结果缺少完整样品、节点或链路标识。")
        status = str(record.get("status", ""))
        failed = record.get("is_fail")
        if not isinstance(failed, bool):
            raise ValueError("已保存的 Analyze 链路结果缺少有效的异常判定。")
        if failed and status not in {"New", "Existed"}:
            raise ValueError("已保存的 Analyze 链路结果缺少新增 / 已有异常标记，无法计算新增失效率。")
        if not failed and status not in {"", "Recovered"}:
            raise ValueError("已保存的 Analyze 链路状态与异常判定不一致。")
        chains = states[sample_key].setdefault(node, {})
        current = (failed, status)
        if chain_key in chains and chains[chain_key] != current:
            raise ValueError("已保存的 Analyze 结果中同一样品、节点、链路存在冲突状态，请检查唯一 Sample ID。")
        chains[chain_key] = current

    configured = [list(order) for order in node_orders if order]
    global_node_order = list(dict.fromkeys(node for order in configured for node in order))
    observed_nodes = {node for nodes in states.values() for node in nodes}
    global_node_order.extend(sorted(observed_nodes - set(global_node_order), key=natural_sort_key))
    global_node_positions = {node: index for index, node in enumerate(global_node_order)}
    result = []
    for sample_key in sorted(states, key=lambda key: tuple(map(natural_sort_key, key))):
        nodes = states[sample_key]
        # Recovered also records an earlier failure when legacy inputs omit
        # the earlier node itself. It must never reset cumulative failure.
        failures = {
            node: {chain for chain, (failed, status) in chains.items() if failed or status == "Recovered"}
            for node, chains in nodes.items()
        }
        ancestors = _build_sample_node_ancestor_chains(set(nodes), configured)
        order = _resolve_sample_node_order(set(nodes), configured) if configured else []
        node_positions = {node: index for index, node in enumerate(order)}
        for node in sorted(nodes, key=lambda value: (
            (0, node_positions[value]) if value in node_positions else (1, natural_sort_key(value))
        )):
            chains = nodes[node]
            historical_failures = {
                chain for previous_node in ancestors.get(node, ())
                for chain in failures[previous_node]
            }
            total_count = len(chains)
            chain_sort_key = lambda key: tuple(map(natural_sort_key, key))
            new_chains = sorted(
                (chain for chain, (failed, status) in chains.items() if failed and status == "New"),
                key=chain_sort_key,
            )
            cumulative_chains = sorted(
                (chain for chain in chains if chain in failures[node] or chain in historical_failures),
                key=chain_sort_key,
            )
            new_count = len(new_chains)
            cumulative_count = len(cumulative_chains)
            result.append({
                "sample_key": list(sample_key),
                "sample_id": " | ".join(sample_key),
                "node": node,
                "node_order_index": global_node_positions[node],
                "total_chain_count": total_count,
                "new_failed_chain_count": new_count,
                "new_failed_chain_keys": [list(chain) for chain in new_chains],
                "new_failure_rate": new_count / total_count if total_count else None,
                "cumulative_failed_chain_count": cumulative_count,
                "cumulative_failed_chain_keys": [list(chain) for chain in cumulative_chains],
                "cumulative_failure_rate": cumulative_count / total_count if total_count else None,
            })
    return result


def load_sample_chain_failure_rows(path: str | Path) -> dict[str, Any]:
    """Load a lightweight TSK input or full Analyze archive in a worker.

    The caller chooses the already-validated snapshot belonging to the active
    result, preferring its lightweight TSK input when available. All settings
    and identities are taken from that saved analysis, never the current UI.
    """
    from .tsk_observations import read_analysis_snapshot
    from .sample_chain_navigation import build_sample_chain_navigation_context

    if not path or not Path(path).is_file():
        raise ValueError("已保存的 Analyze 明细不可用，无法计算每颗样品的链路电测失效率。")
    snapshot = read_analysis_snapshot(path)
    template = snapshot["template"]
    final_status_rows = snapshot.get("summary_artifacts", {}).get("final_status_rows")
    if not isinstance(final_status_rows, list):
        raise ValueError("已保存的 Analyze 结果不含完整链路状态，无法计算链路电测失效率。")
    sample_dimension_names = list(template.report.sample_dimension_names)
    node_dimension = template.report.reliability_node_dimension
    sample_nodes = (
        (_sample_key_from_dimensions(row.dimensions, sample_dimension_names),
         str(row.dimensions.get(node_dimension, "") or ""))
        for row in snapshot["rows"]
    )
    return {
        "rows": build_sample_chain_failure_rows(
            final_status_rows,
            node_orders=_configured_node_orders(template),
            sample_nodes=sample_nodes,
        ),
        "sample_dimension_names": sample_dimension_names,
        "navigation_context": build_sample_chain_navigation_context(snapshot),
    }
