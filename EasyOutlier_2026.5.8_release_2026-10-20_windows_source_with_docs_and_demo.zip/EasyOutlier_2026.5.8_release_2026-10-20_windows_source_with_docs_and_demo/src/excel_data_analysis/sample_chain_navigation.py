"""Plot navigation for saved sample/chain results without changing their scope."""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from typing import Any

from .field_names import preferred_batch_field
from .merge_config import chain_level, column_levels
from .tsk_sorting import natural_sort_key


def build_sample_chain_navigation_context(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    """Retain only frozen identities and chain-to-column mappings after loading.

    Measurements, result rows and file paths are deliberately unnecessary for
    subsequent clicks. Full chain prefixes preserve same-named chains under
    different column ancestors, including pooled metrics shared by chains.
    """
    template = snapshot["template"]
    levels = column_levels(template)
    chain = chain_level(template)
    depth = levels.index(chain) + 1 if chain in levels else 0
    chains = defaultdict(lambda: {"raw_columns": set(), "logical_metrics": set()})
    for column in snapshot["columns"]:
        if not depth or len(column.header_values) < depth:
            continue
        key = tuple(str(value) for value in column.header_values[:depth])
        if not column.raw_column or not column.logical_metric:
            continue
        chains[key]["raw_columns"].add(str(column.raw_column))
        chains[key]["logical_metrics"].add(str(column.logical_metric))
    return {
        "sample_dimensions": list(template.report.sample_dimension_names),
        "node_dimension": str(template.report.reliability_node_dimension),
        "column_levels": levels,
        "chain_column_level": chain,
        "chains": [
            {"chain_key": list(key),
             "raw_columns": sorted(chains[key]["raw_columns"], key=natural_sort_key),
             "logical_metrics": sorted(chains[key]["logical_metrics"], key=natural_sort_key)}
            for key in sorted(chains, key=lambda value: tuple(map(natural_sort_key, value)))
        ],
    }


def build_sample_chain_plot_navigation(
    context: Mapping[str, Any],
    row: Mapping[str, Any],
    selected_chain_keys: Sequence[Sequence[str]],
    *,
    rate_mode: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build the existing Summary navigation/target schema for selected chains.

    Every sample and chain shares an empty report filter. Exact raw columns and
    logical metrics belong to the target projection, while sample conditions
    identify the overlay; none narrows the underlying analysis population.
    ``rate_mode`` labels the request only. The panel supplies its current chain
    selection explicitly, so newly failed and recovered chains use one path.
    """
    raw_dimensions = context.get("sample_dimensions", ())
    raw_sample_key = row.get("sample_key", ())
    if not isinstance(raw_dimensions, (list, tuple)) or not isinstance(raw_sample_key, (list, tuple)):
        raise ValueError("样品的完整唯一标识不可用，无法定位对应图表。")
    sample_dimensions, sample_key = list(raw_dimensions), list(raw_sample_key)
    if (not sample_dimensions or len(set(sample_dimensions)) != len(sample_dimensions)
            or any(not isinstance(name, str) or not name for name in sample_dimensions)
            or len(sample_key) != len(sample_dimensions)
            or any(not isinstance(value, str) or not value for value in sample_key)):
        raise ValueError("样品的完整唯一标识不可用，无法定位对应图表。")
    node_dimension, node = context.get("node_dimension"), row.get("node")
    if not isinstance(node_dimension, str) or not node_dimension or not isinstance(node, str) or not node:
        raise ValueError("样品的节点标识不可用，无法定位对应图表。")
    if (not isinstance(selected_chain_keys, (list, tuple)) or not selected_chain_keys
            or any(not isinstance(key, (list, tuple)) or not key
                   or any(not isinstance(value, str) for value in key)
                   for key in selected_chain_keys)):
        raise ValueError("请先选择至少一条完整的失效链路。")
    selected = sorted({tuple(key) for key in selected_chain_keys},
                      key=lambda value: tuple(map(natural_sort_key, value)))
    available = {tuple(item["chain_key"]): item for item in context.get("chains", ())}
    if any(key not in available for key in selected):
        raise ValueError("所选链路不在已保存的 Analyze 列范围中，无法定位对应图表。")
    columns = sorted({column for key in selected for column in available[key]["raw_columns"]},
                     key=natural_sort_key)
    metrics = sorted({metric for key in selected for metric in available[key]["logical_metrics"]},
                     key=natural_sort_key)
    if not columns or not metrics:
        raise ValueError("所选链路没有可定位的测量列。")
    conditions = dict(zip(sample_dimensions, sample_key))
    batch_field = preferred_batch_field(sample_dimensions)
    label_values = [value for field, value in conditions.items() if field != batch_field]
    target = {
        "sample_key": sample_key,
        "sample_label": " | ".join(label_values or sample_key),
        "lot": conditions.get(batch_field, ""),
        "pair_index": 0,
        "conditions": conditions,
        "logical_metrics": metrics,
        "raw_columns": columns,
        "focus_nodes": [node],
    }
    labels = {None: "样品链路失效率", "new": "样品链路新增失效率", "cumulative": "样品链路累积失效率"}
    if rate_mode not in labels:
        raise ValueError("不支持的链路失效率类型。")
    navigation = {
        "id": "sample-chain-failure-rates",
        "label": labels[rate_mode],
        "sample_dimensions": sample_dimensions,
        "node_dimension": node_dimension,
        "group_dimensions": [node_dimension],
        "group_values": [node],
        "filter_config": {},
        "targets": [target],
    }
    return navigation, target
