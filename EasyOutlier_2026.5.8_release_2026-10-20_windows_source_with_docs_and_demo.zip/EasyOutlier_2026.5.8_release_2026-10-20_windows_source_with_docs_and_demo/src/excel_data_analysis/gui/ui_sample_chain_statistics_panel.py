# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'sample_chain_statistics_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QPushButton,
    QRadioButton, QSizePolicy, QSpacerItem, QSplitter,
    QTableView, QVBoxLayout, QWidget)

from excel_data_analysis.gui.sample_chain_statistics_panel import SampleChainStatisticsHeader

class Ui_SampleChainStatisticsPanelForm(object):
    def setupUi(self, SampleChainStatisticsPanelForm):
        if not SampleChainStatisticsPanelForm.objectName():
            SampleChainStatisticsPanelForm.setObjectName(u"SampleChainStatisticsPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(SampleChainStatisticsPanelForm.sizePolicy().hasHeightForWidth())
        SampleChainStatisticsPanelForm.setSizePolicy(sizePolicy)
        self.copyAction = QAction(SampleChainStatisticsPanelForm)
        self.copyAction.setObjectName(u"copyAction")
        self.copyAction.setEnabled(False)
        self.copyHeadersAction = QAction(SampleChainStatisticsPanelForm)
        self.copyHeadersAction.setObjectName(u"copyHeadersAction")
        self.copyHeadersAction.setEnabled(False)
        self.chainsCopyAction = QAction(SampleChainStatisticsPanelForm)
        self.chainsCopyAction.setObjectName(u"chainsCopyAction")
        self.chainsCopyAction.setEnabled(False)
        self.chainsCopyHeadersAction = QAction(SampleChainStatisticsPanelForm)
        self.chainsCopyHeadersAction.setObjectName(u"chainsCopyHeadersAction")
        self.chainsCopyHeadersAction.setEnabled(False)
        self.panelLayout = QVBoxLayout(SampleChainStatisticsPanelForm)
        self.panelLayout.setSpacing(8)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.explanationLabel = QLabel(SampleChainStatisticsPanelForm)
        self.explanationLabel.setObjectName(u"explanationLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.explanationLabel.sizePolicy().hasHeightForWidth())
        self.explanationLabel.setSizePolicy(sizePolicy1)
        self.explanationLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.explanationLabel.setWordWrap(True)

        self.panelLayout.addWidget(self.explanationLabel)

        self.modeLayout = QHBoxLayout()
        self.modeLayout.setSpacing(8)
        self.modeLayout.setObjectName(u"modeLayout")
        self.modeLabel = QLabel(SampleChainStatisticsPanelForm)
        self.modeLabel.setObjectName(u"modeLabel")

        self.modeLayout.addWidget(self.modeLabel)

        self.newRadioButton = QRadioButton(SampleChainStatisticsPanelForm)
        self.newRadioButton.setObjectName(u"newRadioButton")
        self.newRadioButton.setEnabled(False)
        self.newRadioButton.setChecked(True)

        self.modeLayout.addWidget(self.newRadioButton)

        self.cumulativeRadioButton = QRadioButton(SampleChainStatisticsPanelForm)
        self.cumulativeRadioButton.setObjectName(u"cumulativeRadioButton")
        self.cumulativeRadioButton.setEnabled(False)

        self.modeLayout.addWidget(self.cumulativeRadioButton)

        self.modeSpacer = QSpacerItem(40, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.modeLayout.addItem(self.modeSpacer)


        self.panelLayout.addLayout(self.modeLayout)

        self.identitySearchLayout = QHBoxLayout()
        self.identitySearchLayout.setSpacing(8)
        self.identitySearchLayout.setObjectName(u"identitySearchLayout")
        self.batchFieldLabel = QLabel(SampleChainStatisticsPanelForm)
        self.batchFieldLabel.setObjectName(u"batchFieldLabel")

        self.identitySearchLayout.addWidget(self.batchFieldLabel)

        self.batchFieldComboBox = QComboBox(SampleChainStatisticsPanelForm)
        self.batchFieldComboBox.setObjectName(u"batchFieldComboBox")
        self.batchFieldComboBox.setEnabled(False)
        self.batchFieldComboBox.setMinimumContentsLength(8)
        self.batchFieldComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

        self.identitySearchLayout.addWidget(self.batchFieldComboBox)

        self.sampleFieldLabel = QLabel(SampleChainStatisticsPanelForm)
        self.sampleFieldLabel.setObjectName(u"sampleFieldLabel")

        self.identitySearchLayout.addWidget(self.sampleFieldLabel)

        self.sampleFieldComboBox = QComboBox(SampleChainStatisticsPanelForm)
        self.sampleFieldComboBox.setObjectName(u"sampleFieldComboBox")
        self.sampleFieldComboBox.setEnabled(False)
        self.sampleFieldComboBox.setMinimumContentsLength(8)
        self.sampleFieldComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

        self.identitySearchLayout.addWidget(self.sampleFieldComboBox)

        self.searchLabel = QLabel(SampleChainStatisticsPanelForm)
        self.searchLabel.setObjectName(u"searchLabel")

        self.identitySearchLayout.addWidget(self.searchLabel)

        self.searchEdit = QLineEdit(SampleChainStatisticsPanelForm)
        self.searchEdit.setObjectName(u"searchEdit")
        self.searchEdit.setEnabled(False)
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(1)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.searchEdit.sizePolicy().hasHeightForWidth())
        self.searchEdit.setSizePolicy(sizePolicy2)
        self.searchEdit.setClearButtonEnabled(True)

        self.identitySearchLayout.addWidget(self.searchEdit)


        self.panelLayout.addLayout(self.identitySearchLayout)

        self.statusLabel = QLabel(SampleChainStatisticsPanelForm)
        self.statusLabel.setObjectName(u"statusLabel")
        sizePolicy1.setHeightForWidth(self.statusLabel.sizePolicy().hasHeightForWidth())
        self.statusLabel.setSizePolicy(sizePolicy1)
        self.statusLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.statusLabel.setWordWrap(True)

        self.panelLayout.addWidget(self.statusLabel)

        self.detailsSplitter = QSplitter(SampleChainStatisticsPanelForm)
        self.detailsSplitter.setObjectName(u"detailsSplitter")
        self.detailsSplitter.setOrientation(Qt.Orientation.Horizontal)
        self.detailsSplitter.setChildrenCollapsible(False)
        self.tableView = QTableView(self.detailsSplitter)
        self.tableView.setObjectName(u"tableView")
        self.tableView.setEnabled(False)
        self.tableView.setMinimumSize(QSize(0, 160))
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy3.setHorizontalStretch(3)
        sizePolicy3.setVerticalStretch(1)
        sizePolicy3.setHeightForWidth(self.tableView.sizePolicy().hasHeightForWidth())
        self.tableView.setSizePolicy(sizePolicy3)
        self.tableView.setContextMenuPolicy(Qt.ContextMenuPolicy.ActionsContextMenu)
        self.tableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tableView.setAlternatingRowColors(True)
        self.tableView.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectItems)
        self.tableView.setSortingEnabled(True)
        self.tableView.setWordWrap(False)
        self.tableView.setProperty(u"textColumnMaximumWidth", 300)
        self.tableView.setProperty(u"textColumnMinimumWidth", 100)
        self.matrixHeader = SampleChainStatisticsHeader(self.tableView)
        self.matrixHeader.setObjectName(u"matrixHeader")
        self.matrixHeader.setProperty(u"headerRowHeight", 28)
        self.matrixHeader.setSectionsClickable(True)
        self.matrixHeader.setSortIndicatorShown(True)
        self.detailsSplitter.addWidget(self.tableView)
        self.tableView.verticalHeader().setVisible(False)
        self.detailsPanel = QWidget(self.detailsSplitter)
        self.detailsPanel.setObjectName(u"detailsPanel")
        self.detailsPanel.setMinimumSize(QSize(260, 0))
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(1)
        sizePolicy4.setHeightForWidth(self.detailsPanel.sizePolicy().hasHeightForWidth())
        self.detailsPanel.setSizePolicy(sizePolicy4)
        self.detailsLayout = QVBoxLayout(self.detailsPanel)
        self.detailsLayout.setSpacing(8)
        self.detailsLayout.setObjectName(u"detailsLayout")
        self.detailsLayout.setContentsMargins(8, 0, 0, 0)
        self.detailsTitleLabel = QLabel(self.detailsPanel)
        self.detailsTitleLabel.setObjectName(u"detailsTitleLabel")

        self.detailsLayout.addWidget(self.detailsTitleLabel)

        self.detailsSummaryLabel = QLabel(self.detailsPanel)
        self.detailsSummaryLabel.setObjectName(u"detailsSummaryLabel")
        sizePolicy1.setHeightForWidth(self.detailsSummaryLabel.sizePolicy().hasHeightForWidth())
        self.detailsSummaryLabel.setSizePolicy(sizePolicy1)
        self.detailsSummaryLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.detailsSummaryLabel.setWordWrap(True)
        self.detailsSummaryLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.detailsLayout.addWidget(self.detailsSummaryLabel)

        self.plotAllChainsButton = QPushButton(self.detailsPanel)
        self.plotAllChainsButton.setObjectName(u"plotAllChainsButton")
        self.plotAllChainsButton.setEnabled(False)

        self.detailsLayout.addWidget(self.plotAllChainsButton)

        self.chainsTableView = QTableView(self.detailsPanel)
        self.chainsTableView.setObjectName(u"chainsTableView")
        self.chainsTableView.setProperty(u"chainLinkUnderline", True)
        self.chainsTableView.setEnabled(False)
        sizePolicy4.setHeightForWidth(self.chainsTableView.sizePolicy().hasHeightForWidth())
        self.chainsTableView.setSizePolicy(sizePolicy4)
        self.chainsTableView.setContextMenuPolicy(Qt.ContextMenuPolicy.ActionsContextMenu)
        self.chainsTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.chainsTableView.setAlternatingRowColors(True)
        self.chainsTableView.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.chainsTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.chainsTableView.setWordWrap(False)
        self.chainsTableView.horizontalHeader().setStretchLastSection(True)

        self.detailsLayout.addWidget(self.chainsTableView)

        self.detailsLayout.setStretch(3, 1)
        self.detailsSplitter.addWidget(self.detailsPanel)

        self.panelLayout.addWidget(self.detailsSplitter)

        self.panelLayout.setStretch(4, 1)
#if QT_CONFIG(shortcut)
        self.batchFieldLabel.setBuddy(self.batchFieldComboBox)
        self.sampleFieldLabel.setBuddy(self.sampleFieldComboBox)
        self.searchLabel.setBuddy(self.searchEdit)
#endif // QT_CONFIG(shortcut)

        self.tableView.addAction(self.copyAction)
        self.tableView.addAction(self.copyHeadersAction)
        self.chainsTableView.addAction(self.chainsCopyAction)
        self.chainsTableView.addAction(self.chainsCopyHeadersAction)

        self.retranslateUi(SampleChainStatisticsPanelForm)

        QMetaObject.connectSlotsByName(SampleChainStatisticsPanelForm)
    # setupUi

    def retranslateUi(self, SampleChainStatisticsPanelForm):
        SampleChainStatisticsPanelForm.setProperty(u"missingSnapshotText", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u73b0\u6709\u7ed3\u679c\u672a\u4fdd\u5b58\u94fe\u8def\u5224\u5b9a\u660e\u7ec6\uff0c\u65e0\u6cd5\u8ba1\u7b97\u6b64\u8868\u3002", None))
        SampleChainStatisticsPanelForm.setProperty(u"loadingTitle", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u8bfb\u53d6\u6837\u54c1\u94fe\u8def\u7edf\u8ba1", None))
        SampleChainStatisticsPanelForm.setProperty(u"plotErrorTitle", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u5b9a\u4f4d\u5931\u6548\u94fe\u8def\u5931\u8d25", None))
        SampleChainStatisticsPanelForm.setProperty(u"plotLabelText", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6837\u54c1\u94fe\u8def\u5931\u6548\u7387", None))
        self.copyAction.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u590d\u5236", None))
        self.copyHeadersAction.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u590d\u5236\uff08\u542b\u8868\u5934\uff09", None))
        self.chainsCopyAction.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u590d\u5236", None))
        self.chainsCopyHeadersAction.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u590d\u5236\uff08\u542b\u8868\u5934\uff09", None))
        self.explanationLabel.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6bcf\u683c\u4e3a\u8be5\u6279\u6b21\u3001\u8be5\u6837\u54c1\u5728\u5bf9\u5e94\u8282\u70b9\u7684\u94fe\u8def\u7535\u6d4b\u5931\u6548\u7387\uff0c\u5206\u6bcd\u4e3a\u5f53\u524d\u6709\u6548\u94fe\u8def\u6570\uff1b\u7f3a\u6d4b\u4e0d\u8ba1\u5206\u6bcd\uff0c\u4e0d\u5b58\u5728\u7684\u6837\u54c1\u7ec4\u5408\u7559\u7a7a\u3002\n"
"\u65b0\u589e\u6cbf\u7528\u5df2\u4fdd\u5b58\u7684 New \u5224\u5b9a\uff1b\u7d2f\u79ef\u6309 Analyze \u8282\u70b9\u987a\u5e8f\u5305\u542b\u5df2\u6062\u590d\u7684\u5386\u53f2\u5931\u6548\u94fe\u8def\u3002\u70b9\u51fb\u5931\u6548\u7387\u53ef\u67e5\u770b\u5168\u90e8\u5931\u6548\u94fe\u8def\u3002", None))
        self.modeLabel.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u5931\u6548\u7c7b\u578b", None))
        self.newRadioButton.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u65b0\u589e", None))
        self.cumulativeRadioButton.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u7d2f\u79ef", None))
        self.batchFieldLabel.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6279\u6b21\u5b57\u6bb5", None))
        self.batchFieldComboBox.setProperty(u"allSamplesText", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u5168\u90e8\u6837\u54c1", None))
        self.sampleFieldLabel.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6837\u54c1\u5b57\u6bb5", None))
        self.searchLabel.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u641c\u7d22", None))
        self.searchEdit.setPlaceholderText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u641c\u7d22\u6837\u54c1\u2026", None))
#if QT_CONFIG(tooltip)
        self.searchEdit.setToolTip(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u641c\u7d22\u6837\u54c1\u8eab\u4efd\uff0c\u7a7a\u683c\u5206\u9694\u7684\u7247\u6bb5\u987b\u5168\u90e8\u5339\u914d\u3002\u5ffd\u7565\u5927\u5c0f\u5199\uff0c\u6807\u70b9\u6309\u539f\u6587\u5339\u914d\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.statusLabel.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6682\u65e0\u6837\u54c1\u94fe\u8def\u7edf\u8ba1\u3002", None))
        self.statusLabel.setProperty(u"emptyText", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6682\u65e0\u6837\u54c1\u94fe\u8def\u7edf\u8ba1\u3002", None))
        self.statusLabel.setProperty(u"loadingText", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6b63\u5728\u8bfb\u53d6\u5df2\u4fdd\u5b58\u7684\u94fe\u8def\u5224\u5b9a\uff0c\u65e0\u9700\u91cd\u65b0\u8fd0\u884c Analyze\u2026", None))
        self.statusLabel.setProperty(u"errorFormat", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u65e0\u6cd5\u8bfb\u53d6\u6837\u54c1\u94fe\u8def\u7edf\u8ba1\uff1a{message}", None))
        self.statusLabel.setProperty(u"summaryFormat", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u663e\u793a {visible} / {total} \u884c\u6837\u54c1\uff0c{batches} \u4e2a\u6279\u6b21\u3001{nodes} \u4e2a\u8282\u70b9\u3002", None))
        self.tableView.setProperty(u"sampleHeader", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6837\u54c1\u7f16\u53f7", None))
        self.tableView.setProperty(u"unavailableText", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u2014", None))
        self.tableView.setProperty(u"percentageFormat", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"{value:.4%}", None))
        self.tableView.setProperty(u"identityPartFormat", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"{field}={value}", None))
        self.tableView.setProperty(u"identitySeparator", QCoreApplication.translate("SampleChainStatisticsPanelForm", u" \u00b7 ", None))
        self.tableView.setProperty(u"emptyBatchText", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\uff08\u6279\u6b21\u4e3a\u7a7a\uff09", None))
        self.detailsTitleLabel.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u5931\u6548\u94fe\u8def\u660e\u7ec6", None))
        self.detailsSummaryLabel.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u70b9\u51fb\u5de6\u4fa7\u5931\u6548\u7387\uff0c\u67e5\u770b\u8be5\u6837\u54c1\u7684\u6240\u6709\u5931\u6548\u94fe\u8def\u3002", None))
        self.detailsSummaryLabel.setProperty(u"emptyText", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u70b9\u51fb\u5de6\u4fa7\u5931\u6548\u7387\uff0c\u67e5\u770b\u8be5\u6837\u54c1\u7684\u6240\u6709\u5931\u6548\u94fe\u8def\u3002", None))
        self.detailsSummaryLabel.setProperty(u"detailFormat", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u6279\u6b21\uff1a{batch}\n"
"\u6837\u54c1\uff1a{sample}\n"
"\u8282\u70b9\uff1a{node} \u00b7 {mode}\u5931\u6548\n"
"\u5931\u6548\u94fe\u8def\uff1a{failed} / {total} \u00b7 {rate}", None))
        self.plotAllChainsButton.setText(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u67e5\u770b\u672c\u6837\u54c1\u5168\u90e8\u5931\u6548\u94fe\u8def", None))
#if QT_CONFIG(tooltip)
        self.plotAllChainsButton.setToolTip(QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u5728 Plot Inspector \u4e2d\u5b9a\u4f4d\u5f53\u524d\u6837\u54c1\u3001\u5f53\u524d\u5931\u6548\u7c7b\u578b\u7684\u5168\u90e8\u5931\u6548\u94fe\u8def\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.chainsTableView.setProperty(u"navigationTooltip", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u5355\u51fb\u94fe\u8def\u53ef\u5728 Plot Inspector \u4e2d\u5b9a\u4f4d\u3002", None))
        self.chainsTableView.setProperty(u"navigationUnavailableTooltip", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u5f53\u524d\u7ed3\u679c\u6ca1\u6709\u53ef\u7528\u4e8e\u5b9a\u4f4d\u7684 Plot Inspector \u6570\u636e\u3002", None))
        self.chainsTableView.setProperty(u"chainHeader", QCoreApplication.translate("SampleChainStatisticsPanelForm", u"\u5931\u6548\u94fe\u8def\uff08\u5b8c\u6574\u8eab\u4efd\uff09", None))
        self.chainsTableView.setProperty(u"chainSeparator", QCoreApplication.translate("SampleChainStatisticsPanelForm", u" | ", None))
    # retranslateUi

