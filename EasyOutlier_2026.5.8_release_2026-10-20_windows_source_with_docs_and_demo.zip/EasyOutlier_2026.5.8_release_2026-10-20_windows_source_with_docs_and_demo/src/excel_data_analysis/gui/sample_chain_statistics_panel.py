"""Batch/node matrices of saved per-sample chain failures and their full evidence."""
from __future__ import annotations

import math
import re

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QRect, QSignalBlocker, QSize, QSortFilterProxyModel, Qt, Signal
from PySide6.QtGui import QFont, QPainter, QPalette
from PySide6.QtWidgets import QHeaderView, QStyle, QStyleOptionHeader, QWidget

from ..field_names import preferred_batch_field
from ..text_search import matches_search
from .table_copy import TableCopyController


def _natural_key(value):
    return tuple((0, int(part)) if part.isdigit() else (1, part.casefold())
                 for part in re.split(r"(\d+)", str(value)) if part)


class SampleChainStatisticsHeader(QHeaderView):
    """Two-level header with each batch spanning its reliability-node columns."""

    def __init__(self, parent=None):
        super().__init__(Qt.Horizontal, parent)
        self._batch_header_pressed = False

    def mousePressEvent(self, event):
        self._batch_header_pressed = (event.button() == Qt.LeftButton
                                      and self.logicalIndexAt(event.position().toPoint()) > 0
                                      and event.position().y() < self.height() // 2)
        if self._batch_header_pressed:
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if self._batch_header_pressed:
            self._batch_header_pressed = False
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def sizeHint(self):
        size = super().sizeHint()
        return QSize(size.width(), 2 * int(self.property("headerRowHeight") or size.height()))

    def _paint_header(self, painter, rectangle, text, section):
        option = QStyleOptionHeader()
        self.initStyleOption(option)
        option.rect = rectangle
        option.section = section
        option.text = text
        option.textAlignment = Qt.AlignCenter
        option.position = QStyleOptionHeader.Middle
        option.sortIndicator = QStyleOptionHeader.None_
        if section >= 0 and self.isSortIndicatorShown() and section == self.sortIndicatorSection():
            option.sortIndicator = (QStyleOptionHeader.SortDown if self.sortIndicatorOrder() == Qt.AscendingOrder
                                    else QStyleOptionHeader.SortUp)
        self.style().drawControl(QStyle.CE_Header, option, painter, self)

    def paintSection(self, painter, rectangle, logical_index):
        model = self.model()
        if model is None:
            return
        headings = model.header_rows([logical_index])
        if logical_index == 0:
            self._paint_header(painter, rectangle, headings[0][0], logical_index)
        else:
            lower = QRect(rectangle)
            lower.setTop(rectangle.top() + rectangle.height() // 2)
            self._paint_header(painter, lower, headings[1][0], logical_index)

    def paintEvent(self, event):
        super().paintEvent(event)
        model = self.model()
        if model is None or model.columnCount() <= 1:
            return
        painter = QPainter(self.viewport())
        try:
            # Group positions come from model identity, never from displayed text.
            for first, last, label in model.batch_sections():
                visible = [column for column in range(first, last + 1) if not self.isSectionHidden(column)]
                if not visible:
                    continue
                left = min(self.sectionViewportPosition(column) for column in visible)
                right = max(self.sectionViewportPosition(column) + self.sectionSize(column) for column in visible)
                self._paint_header(painter, QRect(left, 0, right - left, self.height() // 2), label, -1)
        finally:
            painter.end()


class _SampleChainStatisticsModel(QAbstractTableModel):
    def __init__(self, table, parent=None):
        super().__init__(parent)
        self._sample_header = table.property("sampleHeader")
        self._unavailable = table.property("unavailableText")
        self._percentage_format = table.property("percentageFormat")
        self._identity_part = table.property("identityPartFormat")
        self._identity_separator = table.property("identitySeparator")
        self._empty_batch = table.property("emptyBatchText")
        self.rows = []
        self.columns = []
        self.batches = []
        self.nodes = []
        self._cells = {}
        self._labels = {}
        self._mode = "new"
        self._all_samples_text = ""

    def set_rows(self, rows, dimension_names, batch_dimension, sample_dimension, mode, all_samples_text):
        self.beginResetModel()
        self.rows, self.batches, self.nodes = [], [], []
        self._cells, self._labels = {}, {}
        self._mode, self._all_samples_text = mode, all_samples_text
        row_keys, batches, nodes = set(), set(), set()
        node_order = {}
        dimensions = tuple(dimension_names) or (self._sample_header,)
        remaining = [index for index in range(len(dimensions)) if index != batch_dimension]
        if sample_dimension not in remaining:
            sample_dimension = remaining[-1]
        for row in rows:
            key = row.get("sample_key") if dimension_names else (row.get("sample_id", ""),)
            key = tuple(str(value) if value is not None else "" for value in (key or ()))
            key = tuple(key[index] if index < len(key) else "" for index in range(len(dimensions)))
            batch = key[batch_dimension] if batch_dimension >= 0 else None
            row_key = tuple(key[index] for index in remaining)
            node = str(row.get("node") or "")
            if batch not in batches:
                batches.add(batch)
                self.batches.append(batch)
            if node not in nodes:
                nodes.add(node)
                self.nodes.append(node)
            rank = row.get("node_order_index")
            if isinstance(rank, (int, float)) and not isinstance(rank, bool) and math.isfinite(rank):
                node_order[node] = min(rank, node_order.get(node, rank))
            if row_key not in row_keys:
                row_keys.add(row_key)
                self.rows.append(row_key)
                parts = [key[sample_dimension]]
                parts.extend(self._identity_part.format(field=dimensions[index], value=key[index])
                             for index in remaining if index != sample_dimension)
                self._labels[row_key] = self._identity_separator.join(parts)
            self._cells[row_key, batch, node] = row
        self.nodes.sort(key=lambda node: (0, node_order[node]) if node in node_order else (1, _natural_key(node)))
        self.columns = [(batch, node) for batch in self.batches for node in self.nodes]
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.columns) + 1

    def row_label(self, row):
        return self._labels[self.rows[row]]

    def source_row(self, index):
        if not index.isValid() or not 0 <= index.row() < len(self.rows) or not 1 <= index.column() <= len(self.columns):
            return None
        batch, node = self.columns[index.column() - 1]
        return self._cells.get((self.rows[index.row()], batch, node))

    @staticmethod
    def valid_rate(value):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and 0 <= value <= 1

    def rate_value(self, row):
        value = row.get(f"{self._mode}_failure_rate")
        return value if self.valid_rate(value) else None

    def rate_text(self, row):
        value = self.rate_value(row)
        return self._percentage_format.format(value=value) if value is not None else self._unavailable

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self.rows):
            return None
        if index.column() == 0:
            return self.row_label(index.row()) if role in (Qt.DisplayRole, Qt.ToolTipRole, Qt.UserRole) else None
        if role == Qt.TextAlignmentRole:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        row = self.source_row(index)
        if role == Qt.UserRole:
            return self.rate_value(row) if row is not None else None
        if role in (Qt.DisplayRole, Qt.ToolTipRole):
            return self.rate_text(row) if row is not None else ""
        return None

    def batch_text(self, batch):
        return self._all_samples_text if batch is None else batch or self._empty_batch

    def header_rows(self, columns):
        return [[self._sample_header if column == 0 else self.batch_text(self.columns[column - 1][0])
                 for column in columns],
                ["" if column == 0 else self.columns[column - 1][1] for column in columns]]

    def batch_sections(self):
        node_count = len(self.nodes)
        return [(1 + index * node_count, (index + 1) * node_count, self.batch_text(batch))
                for index, batch in enumerate(self.batches)]

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role not in (Qt.DisplayRole, Qt.ToolTipRole):
            return None
        if orientation == Qt.Vertical:
            return str(section + 1)
        if not 0 <= section < self.columnCount():
            return None
        if section == 0:
            return self._sample_header
        batch, node = self.columns[section - 1]
        return node if role == Qt.DisplayRole else self._identity_separator.join((self.batch_text(batch), node))


class _SampleStatisticsProxy(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._search_text = ""
        self.setSortRole(Qt.UserRole)

    def set_search_text(self, text):
        if text != self._search_text:
            self._search_text = text
            self.invalidateFilter()

    def filterAcceptsRow(self, source_row, source_parent):
        return matches_search(self.sourceModel().row_label(source_row), self._search_text)

    def lessThan(self, left, right):
        left_value, right_value = left.data(Qt.UserRole), right.data(Qt.UserRole)
        if left_value is None or right_value is None:
            return left_value is None and right_value is not None
        if isinstance(left_value, (int, float)) and isinstance(right_value, (int, float)):
            return left_value < right_value

        return _natural_key(left_value) < _natural_key(right_value)

    def header_rows(self, columns):
        return self.sourceModel().header_rows(columns)

    def batch_sections(self):
        return self.sourceModel().batch_sections()


class _ChainDetailsModel(QAbstractTableModel):
    def __init__(self, table, parent=None):
        super().__init__(parent)
        self._table = table
        self._header = table.property("chainHeader")
        self._separator = table.property("chainSeparator")
        self._navigation_available = False
        self.rows = []

    def set_rows(self, rows):
        self.beginResetModel()
        self.rows = list(rows)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else 1

    def set_navigation_available(self, available):
        if self._navigation_available != available:
            self._navigation_available = available
            if self.rows:
                self.dataChanged.emit(self.index(0, 0), self.index(len(self.rows) - 1, 0),
                                      [Qt.FontRole, Qt.ForegroundRole])

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self.rows):
            return None
        if self._navigation_available:
            if role == Qt.FontRole:
                font = QFont(self._table.font())
                font.setUnderline(bool(self._table.property("chainLinkUnderline")))
                return font
            if role == Qt.ForegroundRole:
                return self._table.palette().brush(QPalette.Link)
        if role in (Qt.DisplayRole, Qt.ToolTipRole):
            value = self.rows[index.row()]
            return self._separator.join(str(part) for part in value) if isinstance(value, (tuple, list)) else str(value)
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole:
            return self._header if orientation == Qt.Horizontal else str(section + 1)
        return None


class SampleChainStatisticsPanel(QWidget):
    """Bind derived rows; the application owns loading saved analysis data."""

    plotRequested = Signal(object, object)

    def __init__(self, parent=None):
        super().__init__(parent)
        # The generated form imports our custom header, which is already defined.
        from .ui_sample_chain_statistics_panel import Ui_SampleChainStatisticsPanelForm

        self.ui = Ui_SampleChainStatisticsPanelForm()
        self.ui.setupUi(self)
        table = self.ui.tableView
        table.setHorizontalHeader(self.ui.matrixHeader)
        self.table_model = _SampleChainStatisticsModel(table, self)
        self.proxy_model = _SampleStatisticsProxy(self)
        self.proxy_model.setSourceModel(self.table_model)
        table.setModel(self.proxy_model)
        table.sortByColumn(0, Qt.AscendingOrder)
        table.horizontalHeader().setResizeContentsPrecision(100)
        self.details_model = _ChainDetailsModel(self.ui.chainsTableView, self)
        self.ui.chainsTableView.setModel(self.details_model)
        self._copy_controllers = (
            TableCopyController(table, self.ui.copyAction, self.ui.copyHeadersAction),
            TableCopyController(self.ui.chainsTableView, self.ui.chainsCopyAction, self.ui.chainsCopyHeadersAction),
        )
        self._rows = []
        self._dimension_names = ()
        self._batch_dimension, self._sample_dimension = -1, 0
        self._navigation_available = False
        self._detail_row = None
        self._detail_chain_keys = []
        self.ui.searchEdit.textChanged.connect(self._search)
        self.ui.newRadioButton.toggled.connect(self._rebuild)
        self.ui.batchFieldComboBox.currentIndexChanged.connect(self._batch_changed)
        self.ui.sampleFieldComboBox.currentIndexChanged.connect(self._sample_changed)
        table.selectionModel().currentChanged.connect(self._show_detail)
        table.clicked.connect(self._show_detail)
        self.ui.chainsTableView.clicked.connect(self._request_chain_plot)
        self.ui.plotAllChainsButton.clicked.connect(self._request_all_chain_plots)
        self._update_navigation()

    def _mode(self):
        return "new" if self.ui.newRadioButton.isChecked() else "cumulative"

    def _search(self, text):
        self.proxy_model.set_search_text(text)
        self._clear_detail()
        if self._rows:
            self._update_summary()

    def _update_summary(self):
        self.ui.statusLabel.setText(self.ui.statusLabel.property("summaryFormat").format(
            visible=self.proxy_model.rowCount(), total=self.table_model.rowCount(),
            batches=len(self.table_model.batches), nodes=len(self.table_model.nodes)))

    def _configure_fields(self):
        dimensions = self._dimension_names or (self.ui.tableView.property("sampleHeader"),)
        batch = preferred_batch_field(dimensions) if len(dimensions) > 1 else None
        self._batch_dimension = dimensions.index(batch) if batch is not None else -1
        self._sample_dimension = next(index for index in reversed(range(len(dimensions))) if index != self._batch_dimension)
        with QSignalBlocker(self.ui.batchFieldComboBox), QSignalBlocker(self.ui.sampleFieldComboBox):
            self.ui.batchFieldComboBox.clear()
            self.ui.batchFieldComboBox.addItem(self.ui.batchFieldComboBox.property("allSamplesText"), -1)
            if len(dimensions) > 1:
                for index, name in enumerate(dimensions):
                    self.ui.batchFieldComboBox.addItem(name, index)
            self.ui.sampleFieldComboBox.clear()
            for index, name in enumerate(dimensions):
                self.ui.sampleFieldComboBox.addItem(name, index)
            self.ui.batchFieldComboBox.setCurrentIndex(self.ui.batchFieldComboBox.findData(self._batch_dimension))
            self.ui.sampleFieldComboBox.setCurrentIndex(self._sample_dimension)

    def _batch_changed(self):
        self._batch_dimension = self.ui.batchFieldComboBox.currentData()
        if self._batch_dimension is None:
            return
        if self._batch_dimension == self._sample_dimension:
            self._sample_dimension = next(index for index in reversed(range(self.ui.sampleFieldComboBox.count()))
                                          if index != self._batch_dimension)
            with QSignalBlocker(self.ui.sampleFieldComboBox):
                self.ui.sampleFieldComboBox.setCurrentIndex(self._sample_dimension)
        self._rebuild()

    def _sample_changed(self):
        self._sample_dimension = self.ui.sampleFieldComboBox.currentData()
        if self._sample_dimension is None:
            return
        if self._sample_dimension == self._batch_dimension:
            self._batch_dimension = -1
            with QSignalBlocker(self.ui.batchFieldComboBox):
                self.ui.batchFieldComboBox.setCurrentIndex(0)
        self._rebuild()

    def _rebuild(self, *_args):
        self.table_model.set_rows(self._rows, self._dimension_names, self._batch_dimension,
                                  self._sample_dimension, self._mode(),
                                  self.ui.batchFieldComboBox.property("allSamplesText"))
        self._clear_detail()
        if self._rows:
            self._update_summary()
        table = self.ui.tableView
        table.resizeColumnsToContents()
        table.setColumnWidth(0, min(table.property("textColumnMaximumWidth"),
                                    max(table.property("textColumnMinimumWidth"), table.columnWidth(0))))
        table.horizontalHeader().updateGeometry()
        table.horizontalHeader().viewport().update()

    def set_rows(self, rows, sample_dimension_names=()):
        self._rows = list(rows)
        self._dimension_names = tuple(sample_dimension_names)
        self._configure_fields()
        enabled = bool(self._rows)
        for widget in (self.ui.searchEdit, self.ui.tableView, self.ui.newRadioButton,
                       self.ui.cumulativeRadioButton, self.ui.batchFieldComboBox, self.ui.sampleFieldComboBox):
            widget.setEnabled(enabled)
        self._rebuild()
        if not enabled:
            self.ui.statusLabel.setText(self.ui.statusLabel.property("emptyText"))

    def _clear_detail(self):
        self._detail_row = None
        self._detail_chain_keys = []
        self.details_model.set_rows(())
        self.ui.chainsTableView.setEnabled(False)
        self.ui.detailsSummaryLabel.setText(self.ui.detailsSummaryLabel.property("emptyText"))
        self._update_navigation()

    def _show_detail(self, index, *_args):
        source_index = self.proxy_model.mapToSource(index)
        row = self.table_model.source_row(source_index)
        if row is None:
            self._clear_detail()
            return
        batch, node = self.table_model.columns[source_index.column() - 1]
        mode = self._mode()
        self._detail_row = row
        self._detail_chain_keys = [list(key) for key in row.get(f"{mode}_failed_chain_keys") or ()]
        self.details_model.set_rows(self._detail_chain_keys)
        self.ui.chainsTableView.setEnabled(bool(self.details_model.rowCount()))
        self.ui.detailsSummaryLabel.setText(self.ui.detailsSummaryLabel.property("detailFormat").format(
            batch=self.table_model.batch_text(batch), sample=self.table_model.row_label(source_index.row()),
            node=node, mode=self.ui.newRadioButton.text() if mode == "new" else self.ui.cumulativeRadioButton.text(),
            failed=row.get(f"{mode}_failed_chain_count", 0), total=row.get("total_chain_count", 0),
            rate=self.table_model.rate_text(row)))
        self.ui.chainsTableView.resizeColumnsToContents()
        self._update_navigation()

    def set_navigation_available(self, available):
        self._navigation_available = bool(available)
        self._update_navigation()

    def _can_navigate(self):
        return self._navigation_available and self._detail_row is not None and bool(self._detail_chain_keys)

    def _update_navigation(self):
        enabled = self._can_navigate()
        self.details_model.set_navigation_available(enabled)
        self.ui.plotAllChainsButton.setEnabled(enabled)
        self.ui.chainsTableView.viewport().setCursor(Qt.PointingHandCursor if enabled else Qt.ArrowCursor)
        self.ui.chainsTableView.setToolTip(self.ui.chainsTableView.property(
            "navigationTooltip" if self._navigation_available else "navigationUnavailableTooltip"))

    def _request_chain_plot(self, index):
        if not self._can_navigate() or not index.isValid() or not 0 <= index.row() < len(self._detail_chain_keys):
            return
        self.plotRequested.emit(self._detail_row, [list(self._detail_chain_keys[index.row()])])

    def _request_all_chain_plots(self):
        if self._can_navigate():
            self.plotRequested.emit(self._detail_row, [list(key) for key in self._detail_chain_keys])

    def set_empty(self, message=None):
        self.set_rows(())
        self.ui.statusLabel.setText(message if message is not None else self.ui.statusLabel.property("emptyText"))

    def set_loading(self):
        self.set_empty(self.ui.statusLabel.property("loadingText"))

    def set_error(self, message):
        self.set_empty(self.ui.statusLabel.property("errorFormat").format(message=message))

    def clear(self):
        self.ui.searchEdit.clear()
        self.set_empty()
