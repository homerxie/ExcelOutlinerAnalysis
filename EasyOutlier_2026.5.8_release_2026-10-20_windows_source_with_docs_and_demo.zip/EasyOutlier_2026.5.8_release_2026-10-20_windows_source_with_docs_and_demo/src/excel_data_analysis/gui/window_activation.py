"""Activate an existing plot in response to an explicit user action."""
from __future__ import annotations

import sys

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget


def allow_process_foreground(pid: int | None) -> None:
    """Let the Inspector process activate itself after a click in the main app."""
    if sys.platform != "win32" or not pid:
        return
    import ctypes
    from ctypes import wintypes

    try:
        allow = ctypes.WinDLL("user32", use_last_error=True).AllowSetForegroundWindow
        allow.argtypes = [wintypes.DWORD]
        allow.restype = wintypes.BOOL
        allow(pid)
    except OSError:
        # Windows may deny activation after focus has moved to another app.
        # The normal Qt show/raise request must still reach the Inspector.
        pass


def show_and_activate_window(window: QWidget) -> None:
    """Restore and foreground a window without changing its stacking flags."""
    if window.isMinimized():
        window.setWindowState(window.windowState() & ~Qt.WindowMinimized)
    window.show()
    window.raise_()
    window.activateWindow()


def set_window_on_top(window: QWidget, enabled: bool) -> None:
    """Change only the stacking hint, preserving the window's placement/state."""
    if bool(window.windowFlags() & Qt.WindowStaysOnTopHint) == enabled:
        return
    visible = window.isVisible()
    geometry = window.geometry()
    state = window.windowState()
    # Changing flags can hide/recreate the native window. Restore it without
    # losing maximization or changing its independent taskbar ownership.
    window.setWindowFlag(Qt.WindowStaysOnTopHint, enabled)
    window.setGeometry(geometry)
    window.setWindowState(state)
    if visible:
        window.show()
        if not window.isMinimized():
            window.raise_()
            window.activateWindow()
