"""Shared column-filter interaction for result table models and proxies."""
from weakref import ref

from PySide6.QtCore import QObject, QSignalBlocker, Qt
from PySide6.QtWidgets import QApplication, QDialog

from .ratio_column_filter_dialog import ColumnFilterDialog


class TableFilterController(QObject):
    """Install the form-declared header before assigning the table's model."""

    def __init__(self, table, header):
        super().__init__(table)
        self.table = table
        self._search_scope = None
        self._column_search_text = {}
        previous_state = table.horizontalHeader().saveState()
        minimum_size = header.minimumSectionSize()
        # Restoring header metadata must not initiate a new model sort.
        with QSignalBlocker(header):
            table.setHorizontalHeader(header)
            header.restoreState(previous_state)
            header.setMinimumSectionSize(minimum_size)
        header.filterRequested.connect(self.show_filter)
        table._column_filter_controller = self

    def show_filter(self, column, position):
        model = self.table.model()
        if model is None or not 0 <= column < model.columnCount():
            return
        source_model = model.sourceModel() if callable(getattr(model, "sourceModel", None)) else None
        scope = (ref(model), ref(source_model) if source_model is not None else None, tuple(
            model.headerData(index, Qt.Horizontal) for index in range(model.columnCount())
        ))
        if scope != self._search_scope:
            self._search_scope = scope
            self._column_search_text.clear()
        selected = model.column_filter(column)
        values = model.column_values(column)
        if selected is not None:
            values.extend(sorted(selected.difference(values)))
        clear_token = model.column_filter_clear_token(column)
        search_text, saved_token = self._column_search_text.get(column, ("", None))
        dialog = ColumnFilterDialog(
            model.headerData(column, Qt.Horizontal), values, selected, self.table,
            search_text=search_text if saved_token == clear_token else "",
        )
        dialog.ui.clearAllFiltersButton.setEnabled(model.has_column_filters())
        dialog.ensurePolished()
        dialog.adjustSize()
        available = (QApplication.screenAt(position) or self.table.screen()).availableGeometry()
        dialog.move(
            max(available.left(), min(position.x() - dialog.width(), available.right() - dialog.width() + 1)),
            max(available.top(), min(position.y(), available.bottom() - dialog.height() + 1)),
        )
        try:
            if dialog.exec() != QDialog.Accepted:
                return
            if dialog.action == "clear":
                model.set_column_filter(column, None)
            elif dialog.action == "clear_all":
                model.clear_column_filters()
            elif dialog.action in {"sort_ascending", "sort_descending"}:
                order = Qt.AscendingOrder if dialog.action == "sort_ascending" else Qt.DescendingOrder
                self.table.sortByColumn(column, order)
            elif dialog.filter_was_edited():
                values = dialog.selected_values()
                model.set_column_filter(column, None if values == model.all_column_values(column) else values)
        finally:
            if model.column_filter_clear_token(column) == clear_token:
                self._column_search_text[column] = dialog.ui.searchLineEdit.text(), clear_token
            else:
                # A clear from either the popup or its table also clears search
                # memory; do not save the closing popup's obsolete text again.
                self._column_search_text.pop(column, None)
            dialog.deleteLater()
