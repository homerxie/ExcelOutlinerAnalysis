# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_coordinate_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QDialog, QDoubleSpinBox, QGridLayout, QHBoxLayout,
    QLabel, QLayout, QListWidget, QListWidgetItem,
    QPushButton, QSizePolicy, QSpacerItem, QSplitter,
    QTabWidget, QToolButton, QVBoxLayout, QWidget)

from excel_data_analysis.gui.coordinate_size_spinbox import CoordinateSizeSpinBox
from excel_data_analysis.gui.tsk_coordinate_plot import TskCoordinatePlot
from excel_data_analysis.gui.tsk_coordinate_search_panel import TskCoordinateSearchPanel
from excel_data_analysis.gui.tsk_heatmap_scale import TskHeatmapScale

class Ui_TskCoordinateWindowForm(object):
    def setupUi(self, TskCoordinateWindowForm):
        if not TskCoordinateWindowForm.objectName():
            TskCoordinateWindowForm.setObjectName(u"TskCoordinateWindowForm")
        TskCoordinateWindowForm.resize(1120, 800)
        TskCoordinateWindowForm.setMinimumSize(QSize(760, 600))
        TskCoordinateWindowForm.setModal(False)
        TskCoordinateWindowForm.setWindowModality(Qt.WindowModality.NonModal)
        TskCoordinateWindowForm.setWindowFlags(Qt.WindowType.Window|Qt.WindowType.WindowTitleHint|Qt.WindowType.WindowSystemMenuHint|Qt.WindowType.WindowMinMaxButtonsHint|Qt.WindowType.WindowCloseButtonHint)
        TskCoordinateWindowForm.setProperty(u"favoriteChainPalette", u"#bd7600,#00966b,#8b62bd,#0072b2,#b85c93,#817800,#c4512b,#008f9e,#6c8c36,#b75757,#526fd1,#8f6d48")
        self.windowLayout = QVBoxLayout(TskCoordinateWindowForm)
        self.windowLayout.setSpacing(4)
        self.windowLayout.setObjectName(u"windowLayout")
        self.windowLayout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        self.windowLayout.setContentsMargins(10, 10, 10, 10)
        self.contextLayout = QHBoxLayout()
        self.contextLayout.setSpacing(12)
        self.contextLayout.setObjectName(u"contextLayout")
        self.groupLabel = QLabel(TskCoordinateWindowForm)
        self.groupLabel.setObjectName(u"groupLabel")

        self.contextLayout.addWidget(self.groupLabel)

        self.groupComboBox = QComboBox(TskCoordinateWindowForm)
        self.groupComboBox.setObjectName(u"groupComboBox")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.groupComboBox.sizePolicy().hasHeightForWidth())
        self.groupComboBox.setSizePolicy(sizePolicy)
        self.groupComboBox.setMinimumContentsLength(10)
        self.groupComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

        self.contextLayout.addWidget(self.groupComboBox)

        self.contextLabel = QLabel(TskCoordinateWindowForm)
        self.contextLabel.setObjectName(u"contextLabel")
        self.contextLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.contextLabel.setWordWrap(False)

        self.contextLayout.addWidget(self.contextLabel)

        self.pinWindowButton = QToolButton(TskCoordinateWindowForm)
        self.pinWindowButton.setObjectName(u"pinWindowButton")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.pinWindowButton.sizePolicy().hasHeightForWidth())
        self.pinWindowButton.setSizePolicy(sizePolicy1)
        self.pinWindowButton.setCheckable(True)
        self.pinWindowButton.setChecked(False)
        self.pinWindowButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.contextLayout.addWidget(self.pinWindowButton)


        self.windowLayout.addLayout(self.contextLayout)

        self.selectionLayout = QHBoxLayout()
        self.selectionLayout.setSpacing(12)
        self.selectionLayout.setObjectName(u"selectionLayout")
        self.chainLabel = QLabel(TskCoordinateWindowForm)
        self.chainLabel.setObjectName(u"chainLabel")

        self.selectionLayout.addWidget(self.chainLabel)

        self.chainComboBox = QComboBox(TskCoordinateWindowForm)
        self.chainComboBox.setObjectName(u"chainComboBox")
        sizePolicy.setHeightForWidth(self.chainComboBox.sizePolicy().hasHeightForWidth())
        self.chainComboBox.setSizePolicy(sizePolicy)
        self.chainComboBox.setMinimumContentsLength(10)
        self.chainComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.chainComboBox.setEditable(True)
        self.chainComboBox.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)

        self.selectionLayout.addWidget(self.chainComboBox)

        self.followCheckBox = QCheckBox(TskCoordinateWindowForm)
        self.followCheckBox.setObjectName(u"followCheckBox")
        self.followCheckBox.setChecked(True)

        self.selectionLayout.addWidget(self.followCheckBox)

        self.focusButton = QPushButton(TskCoordinateWindowForm)
        self.focusButton.setObjectName(u"focusButton")
        self.focusButton.setEnabled(False)

        self.selectionLayout.addWidget(self.focusButton)


        self.windowLayout.addLayout(self.selectionLayout)

        self.viewLayout = QHBoxLayout()
        self.viewLayout.setSpacing(12)
        self.viewLayout.setObjectName(u"viewLayout")
        self.outlineLabel = QLabel(TskCoordinateWindowForm)
        self.outlineLabel.setObjectName(u"outlineLabel")

        self.viewLayout.addWidget(self.outlineLabel)

        self.outlineComboBox = QComboBox(TskCoordinateWindowForm)
        self.outlineComboBox.addItem("")
        self.outlineComboBox.addItem("")
        self.outlineComboBox.addItem("")
        self.outlineComboBox.setObjectName(u"outlineComboBox")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.outlineComboBox.sizePolicy().hasHeightForWidth())
        self.outlineComboBox.setSizePolicy(sizePolicy2)
        self.outlineComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)

        self.viewLayout.addWidget(self.outlineComboBox)

        self.labelsCheckBox = QCheckBox(TskCoordinateWindowForm)
        self.labelsCheckBox.setObjectName(u"labelsCheckBox")
        self.labelsCheckBox.setChecked(True)

        self.viewLayout.addWidget(self.labelsCheckBox)

        self.settingsToggleButton = QToolButton(TskCoordinateWindowForm)
        self.settingsToggleButton.setObjectName(u"settingsToggleButton")
        self.settingsToggleButton.setCheckable(True)
        self.settingsToggleButton.setChecked(False)
        self.settingsToggleButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.viewLayout.addWidget(self.settingsToggleButton)

        self.sidebarToggleButton = QToolButton(TskCoordinateWindowForm)
        self.sidebarToggleButton.setObjectName(u"sidebarToggleButton")
        self.sidebarToggleButton.setCheckable(True)
        self.sidebarToggleButton.setChecked(True)
        self.sidebarToggleButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.viewLayout.addWidget(self.sidebarToggleButton)

        self.toolbarSpacer = QSpacerItem(16, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.viewLayout.addItem(self.toolbarSpacer)

        self.zoomOutButton = QPushButton(TskCoordinateWindowForm)
        self.zoomOutButton.setObjectName(u"zoomOutButton")
        sizePolicy1.setHeightForWidth(self.zoomOutButton.sizePolicy().hasHeightForWidth())
        self.zoomOutButton.setSizePolicy(sizePolicy1)
        self.zoomOutButton.setEnabled(False)

        self.viewLayout.addWidget(self.zoomOutButton)

        self.zoomInButton = QPushButton(TskCoordinateWindowForm)
        self.zoomInButton.setObjectName(u"zoomInButton")
        sizePolicy1.setHeightForWidth(self.zoomInButton.sizePolicy().hasHeightForWidth())
        self.zoomInButton.setSizePolicy(sizePolicy1)
        self.zoomInButton.setEnabled(False)

        self.viewLayout.addWidget(self.zoomInButton)

        self.resetButton = QPushButton(TskCoordinateWindowForm)
        self.resetButton.setObjectName(u"resetButton")

        self.viewLayout.addWidget(self.resetButton)


        self.windowLayout.addLayout(self.viewLayout)

        self.advancedOptionsWidget = QWidget(TskCoordinateWindowForm)
        self.advancedOptionsWidget.setObjectName(u"advancedOptionsWidget")
        self.advancedOptionsWidget.setVisible(False)
        self.advancedOptionsLayout = QVBoxLayout(self.advancedOptionsWidget)
        self.advancedOptionsLayout.setSpacing(6)
        self.advancedOptionsLayout.setObjectName(u"advancedOptionsLayout")
        self.advancedOptionsLayout.setContentsMargins(0, 0, 0, 0)
        self.labelOptionsLayout = QHBoxLayout()
        self.labelOptionsLayout.setSpacing(12)
        self.labelOptionsLayout.setObjectName(u"labelOptionsLayout")
        self.labelModeLabel = QLabel(self.advancedOptionsWidget)
        self.labelModeLabel.setObjectName(u"labelModeLabel")

        self.labelOptionsLayout.addWidget(self.labelModeLabel)

        self.labelModeComboBox = QComboBox(self.advancedOptionsWidget)
        self.labelModeComboBox.addItem("")
        self.labelModeComboBox.addItem("")
        self.labelModeComboBox.setObjectName(u"labelModeComboBox")
        sizePolicy2.setHeightForWidth(self.labelModeComboBox.sizePolicy().hasHeightForWidth())
        self.labelModeComboBox.setSizePolicy(sizePolicy2)
        self.labelModeComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)

        self.labelOptionsLayout.addWidget(self.labelModeComboBox)

        self.labelPositionLabel = QLabel(self.advancedOptionsWidget)
        self.labelPositionLabel.setObjectName(u"labelPositionLabel")
        self.labelPositionLabel.setEnabled(True)

        self.labelOptionsLayout.addWidget(self.labelPositionLabel)

        self.labelPositionComboBox = QComboBox(self.advancedOptionsWidget)
        self.labelPositionComboBox.addItem("")
        self.labelPositionComboBox.addItem("")
        self.labelPositionComboBox.setObjectName(u"labelPositionComboBox")
        sizePolicy2.setHeightForWidth(self.labelPositionComboBox.sizePolicy().hasHeightForWidth())
        self.labelPositionComboBox.setSizePolicy(sizePolicy2)
        self.labelPositionComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        self.labelPositionComboBox.setEnabled(True)

        self.labelOptionsLayout.addWidget(self.labelPositionComboBox)

        self.labelLayoutButton = QPushButton(self.advancedOptionsWidget)
        self.labelLayoutButton.setObjectName(u"labelLayoutButton")

        self.labelOptionsLayout.addWidget(self.labelLayoutButton)

        self.labelOptionsSpacer = QSpacerItem(0, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.labelOptionsLayout.addItem(self.labelOptionsSpacer)


        self.advancedOptionsLayout.addLayout(self.labelOptionsLayout)

        self.labelSizeLayout = QGridLayout()
        self.labelSizeLayout.setObjectName(u"labelSizeLayout")
        self.labelSizeLayout.setHorizontalSpacing(12)
        self.labelSizeLayout.setVerticalSpacing(10)
        self.initialLabelSizeLabel = QLabel(self.advancedOptionsWidget)
        self.initialLabelSizeLabel.setObjectName(u"initialLabelSizeLabel")
        self.initialLabelSizeLabel.setEnabled(True)

        self.labelSizeLayout.addWidget(self.initialLabelSizeLabel, 0, 0, 1, 1)

        self.initialLabelSizeSpinBox = CoordinateSizeSpinBox(self.advancedOptionsWidget)
        self.initialLabelSizeSpinBox.setObjectName(u"initialLabelSizeSpinBox")
        self.initialLabelSizeSpinBox.setEnabled(True)
        self.initialLabelSizeSpinBox.setMinimumSize(QSize(120, 0))
        self.initialLabelSizeSpinBox.setMaximumSize(QSize(120, 16777215))
        self.initialLabelSizeSpinBox.setKeyboardTracking(False)
        self.initialLabelSizeSpinBox.setDecimals(20)
        self.initialLabelSizeSpinBox.setProperty(u"minimumText", u"1e-20")
        self.initialLabelSizeSpinBox.setMaximum(1000000000000.000000000000000)
        self.initialLabelSizeSpinBox.setSingleStep(0.001000000000000)
        self.initialLabelSizeSpinBox.setValue(0.010416666666667)

        self.labelSizeLayout.addWidget(self.initialLabelSizeSpinBox, 0, 1, 1, 1)

        self.maximumLabelSizeLabel = QLabel(self.advancedOptionsWidget)
        self.maximumLabelSizeLabel.setObjectName(u"maximumLabelSizeLabel")
        self.maximumLabelSizeLabel.setEnabled(True)

        self.labelSizeLayout.addWidget(self.maximumLabelSizeLabel, 0, 2, 1, 1)

        self.maximumLabelSizeSpinBox = QDoubleSpinBox(self.advancedOptionsWidget)
        self.maximumLabelSizeSpinBox.setObjectName(u"maximumLabelSizeSpinBox")
        self.maximumLabelSizeSpinBox.setEnabled(True)
        self.maximumLabelSizeSpinBox.setKeyboardTracking(False)
        self.maximumLabelSizeSpinBox.setDecimals(1)
        self.maximumLabelSizeSpinBox.setMinimum(0.100000000000000)
        self.maximumLabelSizeSpinBox.setMaximum(48.000000000000000)
        self.maximumLabelSizeSpinBox.setSingleStep(0.100000000000000)
        self.maximumLabelSizeSpinBox.setValue(18.000000000000000)

        self.labelSizeLayout.addWidget(self.maximumLabelSizeSpinBox, 0, 3, 1, 1)

        self.zoomRangeLabel = QLabel(self.advancedOptionsWidget)
        self.zoomRangeLabel.setObjectName(u"zoomRangeLabel")

        self.labelSizeLayout.addWidget(self.zoomRangeLabel, 0, 4, 1, 1)

        self.pointWorldDiameterLabel = QLabel(self.advancedOptionsWidget)
        self.pointWorldDiameterLabel.setObjectName(u"pointWorldDiameterLabel")

        self.labelSizeLayout.addWidget(self.pointWorldDiameterLabel, 1, 0, 1, 1)

        self.pointWorldDiameterSpinBox = CoordinateSizeSpinBox(self.advancedOptionsWidget)
        self.pointWorldDiameterSpinBox.setObjectName(u"pointWorldDiameterSpinBox")
        self.pointWorldDiameterSpinBox.setMinimumSize(QSize(120, 0))
        self.pointWorldDiameterSpinBox.setMaximumSize(QSize(120, 16777215))
        self.pointWorldDiameterSpinBox.setKeyboardTracking(False)
        self.pointWorldDiameterSpinBox.setDecimals(20)
        self.pointWorldDiameterSpinBox.setProperty(u"minimumText", u"1e-20")
        self.pointWorldDiameterSpinBox.setMaximum(1000000000000.000000000000000)
        self.pointWorldDiameterSpinBox.setSingleStep(0.001000000000000)
        self.pointWorldDiameterSpinBox.setValue(0.020833333333333)

        self.labelSizeLayout.addWidget(self.pointWorldDiameterSpinBox, 1, 1, 1, 1)

        self.maximumPointDiameterLabel = QLabel(self.advancedOptionsWidget)
        self.maximumPointDiameterLabel.setObjectName(u"maximumPointDiameterLabel")

        self.labelSizeLayout.addWidget(self.maximumPointDiameterLabel, 1, 2, 1, 1)

        self.maximumPointDiameterSpinBox = QDoubleSpinBox(self.advancedOptionsWidget)
        self.maximumPointDiameterSpinBox.setObjectName(u"maximumPointDiameterSpinBox")
        self.maximumPointDiameterSpinBox.setKeyboardTracking(False)
        self.maximumPointDiameterSpinBox.setDecimals(1)
        self.maximumPointDiameterSpinBox.setMinimum(0.100000000000000)
        self.maximumPointDiameterSpinBox.setMaximum(64.000000000000000)
        self.maximumPointDiameterSpinBox.setSingleStep(0.100000000000000)
        self.maximumPointDiameterSpinBox.setValue(8.000000000000000)

        self.labelSizeLayout.addWidget(self.maximumPointDiameterSpinBox, 1, 3, 1, 1)

        self.labelSizeSpacer = QSpacerItem(0, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.labelSizeLayout.addItem(self.labelSizeSpacer, 0, 5, 1, 1)

        self.labelSizeLayout.setColumnStretch(5, 1)

        self.advancedOptionsLayout.addLayout(self.labelSizeLayout)

        self.interactionHint = QLabel(self.advancedOptionsWidget)
        self.interactionHint.setObjectName(u"interactionHint")
        self.interactionHint.setWordWrap(True)

        self.advancedOptionsLayout.addWidget(self.interactionHint)


        self.windowLayout.addWidget(self.advancedOptionsWidget)

        self.selectionLabel = QLabel(TskCoordinateWindowForm)
        self.selectionLabel.setObjectName(u"selectionLabel")
        self.selectionLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.selectionLabel.setWordWrap(True)

        self.windowLayout.addWidget(self.selectionLabel)

        self.legendWidget = QWidget(TskCoordinateWindowForm)
        self.legendWidget.setObjectName(u"legendWidget")
        self.legendLayout = QGridLayout(self.legendWidget)
        self.legendLayout.setObjectName(u"legendLayout")
        self.legendLayout.setHorizontalSpacing(8)
        self.legendLayout.setContentsMargins(0, 0, 0, 0)
        self.pointLegendTitle = QLabel(self.legendWidget)
        self.pointLegendTitle.setObjectName(u"pointLegendTitle")

        self.legendLayout.addWidget(self.pointLegendTitle, 0, 0, 1, 1)

        self.pointGradient = QLabel(self.legendWidget)
        self.pointGradient.setObjectName(u"pointGradient")
        self.pointGradient.setMinimumSize(QSize(90, 10))
        self.pointGradient.setMaximumSize(QSize(90, 10))

        self.legendLayout.addWidget(self.pointGradient, 0, 1, 1, 1)

        self.pointLegendLabel = QLabel(self.legendWidget)
        self.pointLegendLabel.setObjectName(u"pointLegendLabel")

        self.legendLayout.addWidget(self.pointLegendLabel, 0, 2, 1, 1)

        self.selectionLegend = QLabel(self.legendWidget)
        self.selectionLegend.setObjectName(u"selectionLegend")

        self.legendLayout.addWidget(self.selectionLegend, 0, 3, 1, 1)

        self.ringLegendTitle = QLabel(self.legendWidget)
        self.ringLegendTitle.setObjectName(u"ringLegendTitle")

        self.legendLayout.addWidget(self.ringLegendTitle, 1, 0, 1, 1)

        self.ringGradient = QLabel(self.legendWidget)
        self.ringGradient.setObjectName(u"ringGradient")
        self.ringGradient.setMinimumSize(QSize(90, 10))
        self.ringGradient.setMaximumSize(QSize(90, 10))

        self.legendLayout.addWidget(self.ringGradient, 1, 1, 1, 1)

        self.ringLegendLabel = QLabel(self.legendWidget)
        self.ringLegendLabel.setObjectName(u"ringLegendLabel")

        self.legendLayout.addWidget(self.ringLegendLabel, 1, 2, 1, 1)

        self.missingLegend = QLabel(self.legendWidget)
        self.missingLegend.setObjectName(u"missingLegend")

        self.legendLayout.addWidget(self.missingLegend, 1, 3, 1, 1)


        self.windowLayout.addWidget(self.legendWidget)

        self.xyHeatmapWidget = QWidget(TskCoordinateWindowForm)
        self.xyHeatmapWidget.setObjectName(u"xyHeatmapWidget")
        self.xyHeatmapLayout = QHBoxLayout(self.xyHeatmapWidget)
        self.xyHeatmapLayout.setSpacing(12)
        self.xyHeatmapLayout.setObjectName(u"xyHeatmapLayout")
        self.xyHeatmapLayout.setContentsMargins(0, 0, 0, 0)
        self.xyHeatmapCheckBox = QCheckBox(self.xyHeatmapWidget)
        self.xyHeatmapCheckBox.setObjectName(u"xyHeatmapCheckBox")
        self.xyHeatmapCheckBox.setEnabled(False)
        self.xyHeatmapCheckBox.setChecked(False)

        self.xyHeatmapLayout.addWidget(self.xyHeatmapCheckBox)

        self.xyHeatmapGradient = TskHeatmapScale(self.xyHeatmapWidget)
        self.xyHeatmapGradient.setObjectName(u"xyHeatmapGradient")
        self.xyHeatmapGradient.setEnabled(False)
        self.xyHeatmapGradient.setVisible(False)
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        sizePolicy3.setHorizontalStretch(1)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.xyHeatmapGradient.sizePolicy().hasHeightForWidth())
        self.xyHeatmapGradient.setSizePolicy(sizePolicy3)
        self.xyHeatmapGradient.setProperty(u"minimumScaleWidth", 240)
        self.xyHeatmapGradient.setProperty(u"preferredWidth", 300)
        self.xyHeatmapGradient.setProperty(u"barHeight", 12)
        self.xyHeatmapGradient.setProperty(u"sideMargin", 4)
        self.xyHeatmapGradient.setProperty(u"tickLength", 3)
        self.xyHeatmapGradient.setProperty(u"tickWidth", 0.800000000000000)
        self.xyHeatmapGradient.setProperty(u"tickLabelSpacing", 2)
        self.xyHeatmapGradient.setProperty(u"tickLabelGap", 8)
        self.xyHeatmapGradient.setProperty(u"significantDigits", 3)
        self.xyHeatmapGradient.setProperty(u"negativeColor", u"#64849a")
        self.xyHeatmapGradient.setProperty(u"positiveColor", u"#aa8a70")
        self.xyHeatmapGradient.setProperty(u"heatmapOpacity", 0.220000000000000)
        self.xyHeatmapGradient.setContentsMargins(-1, 2, -1, 2)

        self.xyHeatmapLayout.addWidget(self.xyHeatmapGradient)

        self.xyHeatmapLegendLabel = QLabel(self.xyHeatmapWidget)
        self.xyHeatmapLegendLabel.setObjectName(u"xyHeatmapLegendLabel")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.xyHeatmapLegendLabel.sizePolicy().hasHeightForWidth())
        self.xyHeatmapLegendLabel.setSizePolicy(sizePolicy4)
        self.xyHeatmapLegendLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.xyHeatmapLegendLabel.setWordWrap(True)

        self.xyHeatmapLayout.addWidget(self.xyHeatmapLegendLabel)

        self.xyHeatmapLayout.setStretch(1, 1)
        self.xyHeatmapLayout.setStretch(2, 1)

        self.windowLayout.addWidget(self.xyHeatmapWidget)

        self.coordinateSplitter = QSplitter(TskCoordinateWindowForm)
        self.coordinateSplitter.setObjectName(u"coordinateSplitter")
        self.coordinateSplitter.setOrientation(Qt.Orientation.Horizontal)
        self.coordinateSplitter.setChildrenCollapsible(False)
        self.coordinateSplitter.setProperty(u"preferredSidebarWidth", 320)
        self.coordinatePlot = TskCoordinatePlot(self.coordinateSplitter)
        self.coordinatePlot.setObjectName(u"coordinatePlot")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy5.setHorizontalStretch(1)
        sizePolicy5.setVerticalStretch(1)
        sizePolicy5.setHeightForWidth(self.coordinatePlot.sizePolicy().hasHeightForWidth())
        self.coordinatePlot.setSizePolicy(sizePolicy5)
        self.coordinatePlot.setMinimumSize(QSize(320, 220))
        font = QFont()
        font.setPointSize(10)
        self.coordinatePlot.setFont(font)
        self.coordinatePlot.setMouseTracking(True)
        self.coordinatePlot.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.coordinatePlot.setProperty(u"plotBackgroundRole", u"Base")
        self.coordinatePlot.setProperty(u"heatmapNegativeColor", u"#64849a")
        self.coordinatePlot.setProperty(u"heatmapPositiveColor", u"#aa8a70")
        self.coordinatePlot.setProperty(u"heatmapOpacity", 0.220000000000000)
        self.coordinatePlot.setProperty(u"heatmapResolution", 256)
        self.coordinatePlot.setProperty(u"heatmapTextureResolution", 512)
        self.coordinatePlot.setProperty(u"originAxisOpacity", 0.380000000000000)
        self.coordinatePlot.setProperty(u"originAxisWidth", 1.200000000000000)
        self.coordinatePlot.setProperty(u"labelZoomThreshold", 1.500000000000000)
        self.coordinatePlot.setProperty(u"maximumCanvasZoom", 64.000000000000000)
        self.coordinatePlot.setProperty(u"canvasPaddingFraction", 0.060000000000000)
        self.coordinatePlot.setProperty(u"canvasBorderWidth", 1.000000000000000)
        self.coordinatePlot.setProperty(u"referenceLabelPointSize", 10.000000000000000)
        self.coordinatePlot.setProperty(u"overlayLabelBackgroundOpacity", 0.400000000000000)
        self.coordinatePlot.setProperty(u"labelWorldHeight", 0.010416666666667)
        self.coordinatePlot.setProperty(u"pointWorldDiameter", 0.020833333333333)
        self.coordinatePlot.setProperty(u"defaultLabelHeightFraction", 0.010416666666667)
        self.coordinatePlot.setProperty(u"defaultPointDiameterFraction", 0.020833333333333)
        self.coordinatePlot.setProperty(u"referenceCoordinateSpan", 512.000000000000000)
        self.coordinatePlot.setProperty(u"maximumLabelPixelHeight", 18.000000000000000)
        self.coordinatePlot.setProperty(u"maximumPointPixelDiameter", 8.000000000000000)
        self.coordinatePlot.setProperty(u"leaderLineWidth", 1.000000000000000)
        self.coordinatePlot.setProperty(u"maximumLabelWidth", 260)
        self.coordinateSplitter.addWidget(self.coordinatePlot)
        self.sidebarWidget = QWidget(self.coordinateSplitter)
        self.sidebarWidget.setObjectName(u"sidebarWidget")
        self.sidebarWidget.setMinimumSize(QSize(260, 0))
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(1)
        sizePolicy6.setHeightForWidth(self.sidebarWidget.sizePolicy().hasHeightForWidth())
        self.sidebarWidget.setSizePolicy(sizePolicy6)
        self.sidebarLayout = QVBoxLayout(self.sidebarWidget)
        self.sidebarLayout.setSpacing(0)
        self.sidebarLayout.setObjectName(u"sidebarLayout")
        self.sidebarLayout.setContentsMargins(0, 0, 0, 0)
        self.sidebarTabs = QTabWidget(self.sidebarWidget)
        self.sidebarTabs.setObjectName(u"sidebarTabs")
        self.favoritesTab = QWidget()
        self.favoritesTab.setObjectName(u"favoritesTab")
        self.favoritesLayout = QVBoxLayout(self.favoritesTab)
        self.favoritesLayout.setSpacing(6)
        self.favoritesLayout.setObjectName(u"favoritesLayout")
        self.favoritesLayout.setContentsMargins(8, 8, 8, 8)
        self.favoritesHint = QLabel(self.favoritesTab)
        self.favoritesHint.setObjectName(u"favoritesHint")
        self.favoritesHint.setWordWrap(True)

        self.favoritesLayout.addWidget(self.favoritesHint)

        self.favoriteActionsLayout = QHBoxLayout()
        self.favoriteActionsLayout.setSpacing(6)
        self.favoriteActionsLayout.setObjectName(u"favoriteActionsLayout")
        self.addFavoriteButton = QPushButton(self.favoritesTab)
        self.addFavoriteButton.setObjectName(u"addFavoriteButton")
        self.addFavoriteButton.setEnabled(False)
        self.addFavoriteButton.setAutoDefault(False)

        self.favoriteActionsLayout.addWidget(self.addFavoriteButton)

        self.removeFavoriteButton = QPushButton(self.favoritesTab)
        self.removeFavoriteButton.setObjectName(u"removeFavoriteButton")
        self.removeFavoriteButton.setEnabled(False)
        self.removeFavoriteButton.setAutoDefault(False)

        self.favoriteActionsLayout.addWidget(self.removeFavoriteButton)


        self.favoritesLayout.addLayout(self.favoriteActionsLayout)

        self.favoriteChainsList = QListWidget(self.favoritesTab)
        self.favoriteChainsList.setObjectName(u"favoriteChainsList")
        self.favoriteChainsList.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.favoriteChainsList.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.favoriteChainsList.setUniformItemSizes(True)
        self.favoriteChainsList.setAlternatingRowColors(True)

        self.favoritesLayout.addWidget(self.favoriteChainsList)

        self.favoriteStatusLabel = QLabel(self.favoritesTab)
        self.favoriteStatusLabel.setObjectName(u"favoriteStatusLabel")
        self.favoriteStatusLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.favoriteStatusLabel.setWordWrap(True)

        self.favoritesLayout.addWidget(self.favoriteStatusLabel)

        self.obtainFailedSamplesButton = QPushButton(self.favoritesTab)
        self.obtainFailedSamplesButton.setObjectName(u"obtainFailedSamplesButton")
        self.obtainFailedSamplesButton.setEnabled(False)
        self.obtainFailedSamplesButton.setAutoDefault(False)

        self.favoritesLayout.addWidget(self.obtainFailedSamplesButton)

        self.sidebarTabs.addTab(self.favoritesTab, "")
        self.searchTab = QWidget()
        self.searchTab.setObjectName(u"searchTab")
        self.searchTabLayout = QVBoxLayout(self.searchTab)
        self.searchTabLayout.setSpacing(0)
        self.searchTabLayout.setObjectName(u"searchTabLayout")
        self.searchTabLayout.setContentsMargins(4, 4, 4, 4)
        self.searchPanel = TskCoordinateSearchPanel(self.searchTab)
        self.searchPanel.setObjectName(u"searchPanel")
        sizePolicy5.setHeightForWidth(self.searchPanel.sizePolicy().hasHeightForWidth())
        self.searchPanel.setSizePolicy(sizePolicy5)

        self.searchTabLayout.addWidget(self.searchPanel)

        self.sidebarTabs.addTab(self.searchTab, "")

        self.sidebarLayout.addWidget(self.sidebarTabs)

        self.coordinateSplitter.addWidget(self.sidebarWidget)

        self.windowLayout.addWidget(self.coordinateSplitter)

        self.statusLabel = QLabel(TskCoordinateWindowForm)
        self.statusLabel.setObjectName(u"statusLabel")
        self.statusLabel.setWordWrap(True)

        self.windowLayout.addWidget(self.statusLabel)

        self.windowLayout.setStretch(7, 1)
#if QT_CONFIG(shortcut)
        self.groupLabel.setBuddy(self.groupComboBox)
        self.chainLabel.setBuddy(self.chainComboBox)
        self.outlineLabel.setBuddy(self.outlineComboBox)
        self.labelModeLabel.setBuddy(self.labelModeComboBox)
        self.labelPositionLabel.setBuddy(self.labelPositionComboBox)
        self.initialLabelSizeLabel.setBuddy(self.initialLabelSizeSpinBox)
        self.maximumLabelSizeLabel.setBuddy(self.maximumLabelSizeSpinBox)
        self.pointWorldDiameterLabel.setBuddy(self.pointWorldDiameterSpinBox)
        self.maximumPointDiameterLabel.setBuddy(self.maximumPointDiameterSpinBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskCoordinateWindowForm)
        self.settingsToggleButton.toggled.connect(self.advancedOptionsWidget.setVisible)
        self.sidebarToggleButton.toggled.connect(self.sidebarWidget.setVisible)

        self.labelModeComboBox.setCurrentIndex(0)
        self.labelPositionComboBox.setCurrentIndex(0)
        self.sidebarTabs.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(TskCoordinateWindowForm)
    # setupUi

    def retranslateUi(self, TskCoordinateWindowForm):
        TskCoordinateWindowForm.setWindowTitle(QCoreApplication.translate("TskCoordinateWindowForm", u"TSK \u5750\u6807\u56fe", None))
        TskCoordinateWindowForm.setProperty(u"contextFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{mode} \u00b7 \u5750\u6807\u5355\u4f4d\uff1a{unit}", None))
        TskCoordinateWindowForm.setProperty(u"layoutModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6a21\u677f\u5e03\u5c40\uff08\u6682\u65e0 Analyze \u89c2\u6d4b\uff09", None))
        TskCoordinateWindowForm.setProperty(u"observedModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"Analyze \u89c2\u6d4b\uff08\u5c1a\u672a\u62df\u5408 TSK\uff09", None))
        TskCoordinateWindowForm.setProperty(u"fittedModeText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5df2\u4fdd\u5b58 TSK \u5206\u6790", None))
        TskCoordinateWindowForm.setProperty(u"emptyGroupText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5206\u6790\u7ed3\u679c", None))
        TskCoordinateWindowForm.setProperty(u"unknownUnitText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u672a\u6307\u5b9a", None))
        TskCoordinateWindowForm.setProperty(u"allChainsText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5168\u90e8\u94fe\u8def\uff08\u6e05\u9664\u9ad8\u4eae\uff09", None))
        TskCoordinateWindowForm.setProperty(u"chainSearchNoMatchText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6ca1\u6709\u5339\u914d\u7684\u94fe\u8def", None))
        TskCoordinateWindowForm.setProperty(u"chainSearchAmbiguousText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u8bf7\u9009\u62e9\u5339\u914d\u7684\u94fe\u8def", None))
        TskCoordinateWindowForm.setProperty(u"selectionFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain} \u00b7 \u5df2\u5b9a\u4f4d {shown}/{total} \u4e2a\u5b9e\u4f8b \u00b7 \u89c2\u6d4b {observed} \u00b7 \u9884\u6d4b {predicted}", None))
        TskCoordinateWindowForm.setProperty(u"multiSelectionFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5df2\u9ad8\u4eae {chains} \u6761\u94fe\u8def \u00b7 {shown} \u4e2a\u5b9e\u4f8b", None))
        TskCoordinateWindowForm.setProperty(u"instanceSelectionFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"TSK {tsk} \u00b7 {instance} \u00b7 Chain {chain}", None))
        TskCoordinateWindowForm.setProperty(u"combinationSelectionFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{combination} \u00b7 \u5df2\u9ad8\u4eae {count} \u4e2a\u5b9e\u4f8b \u00b7 {chains} \u6761\u94fe\u8def", None))
        TskCoordinateWindowForm.setProperty(u"favoriteItemFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain}", None))
        TskCoordinateWindowForm.setProperty(u"favoriteStatusFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5df2\u6536\u85cf {total} \u6761 \u00b7 \u9ad8\u4eae {selected} \u6761", None))
        TskCoordinateWindowForm.setProperty(u"favoritesEmptyText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u672a\u6536\u85cf\u94fe\u8def\u3002\u9009\u4e2d\u94fe\u8def\u540e\u53ef\u52a0\u5165\u6536\u85cf\u5939\u3002", None))
        TskCoordinateWindowForm.setProperty(u"favoriteToolTipFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain} \u00b7 \u5e95\u8272\u5bf9\u5e94\u753b\u5e03\u6807\u7b7e\u5916\u6846\u548c\u5149\u5708\u3002\u52fe\u9009\u4ee5\u9ad8\u4eae\uff0c\u53d6\u6d88\u52fe\u9009\u4ee5\u53d6\u6d88\u9ad8\u4eae\u3002", None))
        TskCoordinateWindowForm.setProperty(u"favoriteUnavailableFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain}\uff08\u5f53\u524d\u7ec4\u65e0\u5b9e\u4f8b\uff09", None))
        TskCoordinateWindowForm.setProperty(u"favoriteUnavailableToolTip", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u7ec4\u6ca1\u6709\u8fd9\u6761\u94fe\u8def\u7684\u5b9e\u4f8b\uff1b\u5207\u6362\u5230\u5305\u542b\u5b83\u7684\u7ec4\u5373\u53ef\u9ad8\u4eae\u3002", None))
        TskCoordinateWindowForm.setProperty(u"noSelectionText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u51fb Chain \u540d\u79f0\u6216\u5706\u70b9\u53ef\u9ad8\u4eae\u6574\u6761\u94fe\u3002", None))
        TskCoordinateWindowForm.setProperty(u"legendFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{low} \u2192 {high}", None))
        TskCoordinateWindowForm.setProperty(u"unavailableText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapLegendFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u0394log-odds \u00b7 \u76f8\u5bf9\u62df\u5408\u53c2\u8003\u70b9\n"
"\u84dd\u8272\u964d\u4f4e \u00b7 \u68d5\u8272\u5347\u9ad8", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapNoFitText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u7ec4\u5c1a\u65e0 XY \u7cfb\u6570\u62df\u5408\u7ed3\u679c", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapUnsupportedText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u62df\u5408\u6a21\u578b\u4e0d\u652f\u6301 XY \u5f71\u54cd\u70ed\u529b\u56fe", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapNotConvergedText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u7ec4\u62df\u5408\u672a\u6536\u655b\uff0c\u65e0\u6cd5\u663e\u793a XY \u5f71\u54cd", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapNotIdentifiableText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u7ec4 XY \u7cfb\u6570\u4e0d\u53ef\u8fa8\u8bc6\uff0c\u65e0\u6cd5\u663e\u793a XY \u5f71\u54cd", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapBoundaryInvalidText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u7ec4 XY \u62df\u5408\u8fb9\u754c\u65e0\u6548\uff0c\u65e0\u6cd5\u663e\u793a XY \u5f71\u54cd", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapInvalidText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u7ec4 XY \u62df\u5408\u6570\u636e\u65e0\u6548\uff0c\u65e0\u6cd5\u663e\u793a\u70ed\u529b\u56fe", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapNoCoordinatesText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u7ec4\u6ca1\u6709\u53ef\u7ed8\u5236\u7684\u6709\u6548 XY \u5750\u6807", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapToolTip", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5728\u5706\u70b9\u548c\u6807\u7b7e\u4e0b\u65b9\uff0c\u6309 XY \u62df\u5408\u66f2\u9762\u94fa\u6ee1\u6574\u4e2a\u753b\u5e03\uff1b\u6570\u636e\u8303\u56f4\u5916\u4e3a\u6a21\u578b\u5ef6\u4f38\u3002\u663e\u793a\u76f8\u5bf9\u62df\u5408\u53c2\u8003\u70b9\u7684\u5f71\u54cd\uff0c\u5355\u4f4d\u4e3a \u0394log-odds\uff0c\u5e76\u975e\u5931\u6548\u6982\u7387\u3002\u84dd\u8272\u8868\u793a\u964d\u4f4e\u3001\u68d5\u8272\u8868\u793a\u5347\u9ad8\uff0c\u96f6\u503c\u900f\u660e\uff1b\u4e0d\u5305\u542b\u622a\u8ddd\u3001\u7c7b\u578b\u6216\u5176\u4ed6\u7279\u5f81\u9879\u3002\u8272\u9636\u4ee5\u96f6\u4e3a\u4e2d\u5fc3\u5bf9\u79f0\uff0c\u6309\u5f53\u524d\u753b\u5e03\u8303\u56f4\u56fa\u5b9a\uff0c\u7f29\u653e\u548c\u5e73\u79fb\u65f6\u4e0d\u53d8\u3002", None))
        TskCoordinateWindowForm.setProperty(u"xyHeatmapUnavailableToolTipFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{reason}\u3002\u5df2\u52fe\u9009\u7684\u504f\u597d\u4f1a\u4fdd\u7559\uff0c\u5207\u6362\u5230\u6709\u6548\u62df\u5408\u7ec4\u540e\u6062\u590d\u663e\u793a\u3002", None))
        TskCoordinateWindowForm.setProperty(u"zoomRangeFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5168\u56fe 1\u00d7 \u2014 \u6700\u5927 {maximum}\u00d7", None))
        TskCoordinateWindowForm.setProperty(u"statusFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5df2\u7ed8\u5236 {shown}/{total} \u4e2a\u5b9e\u4f8b \u00b7 \u7f3a\u5c11\u6709\u6548 XY\uff1a{missing} \u00b7 \u540c\u5750\u6807\u989d\u5916\u5b9e\u4f8b\uff1a{coincident} \u00b7 \u7f29\u653e {zoom}\u00d7 \u00b7 \u89c6\u91ce\u5185\u6587\u5b57 {labels} \u00b7 \u70b9 {visible}", None))
        self.groupLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u8282\u70b9 / \u6279\u6b21", None))
        self.contextLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5206\u6790\u7ed3\u679c", None))
        self.pinWindowButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7f6e\u9876", None))
#if QT_CONFIG(tooltip)
        self.pinWindowButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u8ba9\u6b64\u7a97\u53e3\u4fdd\u6301\u5728\u5176\u4ed6\u7a97\u53e3\u4e0a\u65b9\uff1b\u518d\u6b21\u70b9\u51fb\u53d6\u6d88\u7f6e\u9876\u3002", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(accessibility)
        self.pinWindowButton.setAccessibleName(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7a97\u53e3\u7f6e\u9876", None))
#endif // QT_CONFIG(accessibility)
        self.chainLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"Chain", None))
        self.chainComboBox.setPlaceholderText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u8f93\u5165\u94fe\u8def\u540d\u79f0\uff0c\u7a7a\u683c\u5206\u9694\u7247\u6bb5", None))
        self.chainComboBox.setProperty(u"searchPlaceholderText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u8f93\u5165\u94fe\u8def\u540d\u79f0\uff0c\u7a7a\u683c\u5206\u9694\u7247\u6bb5", None))
#if QT_CONFIG(tooltip)
        self.chainComboBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7a7a\u683c\u5206\u9694\u591a\u4e2a\u7247\u6bb5\uff0c\u5168\u90e8\u5339\u914d\u4e14\u987a\u5e8f\u4e0d\u9650\uff1b\u4e0d\u533a\u5206\u5927\u5c0f\u5199\u3002\u9009\u62e9\u540e\u9ad8\u4eae\u94fe\u8def\u5728\u5e03\u5c40\u4e2d\u7684\u6240\u6709\u5b9e\u4f8b\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.followCheckBox.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u81ea\u52a8\u805a\u7126", None))
#if QT_CONFIG(tooltip)
        self.followCheckBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u9009\u4e2d\u94fe\u8def\u3001\u6536\u85cf\u6216\u641c\u7d22\u7ed3\u679c\u65f6\u81ea\u52a8\u7f29\u653e\u5e76\u5b9a\u4f4d\u3002\u5173\u95ed\u540e\u4fdd\u7559\u5f53\u524d\u89c6\u91ce\uff1b\u624b\u52a8\u7f29\u653e\u3001\u62d6\u52a8\u3001\u5b9a\u4f4d\u9009\u4e2d\u94fe\u548c\u663e\u793a\u5168\u90e8\u59cb\u7ec8\u53ef\u7528\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.focusButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b9a\u4f4d\u9009\u4e2d\u94fe", None))
        self.outlineLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708", None))
        self.outlineComboBox.setItemText(0, QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u89c2\u6d4b\u5931\u6548\u7387", None))
        self.outlineComboBox.setItemText(1, QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u9884\u6d4b\u5931\u6548\u7387", None))
        self.outlineComboBox.setItemText(2, QCoreApplication.translate("TskCoordinateWindowForm", u"\u4e0d\u663e\u793a", None))

        self.labelsCheckBox.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u663e\u793a\u6587\u5b57", None))
        self.settingsToggleButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7ed8\u56fe\u8bbe\u7f6e", None))
#if QT_CONFIG(tooltip)
        self.settingsToggleButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c55\u5f00\u6216\u6536\u8d77\u6587\u5b57\u6392\u7248\u3001\u5b57\u9ad8\u548c\u5706\u70b9\u5c3a\u5bf8\u8bbe\u7f6e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.sidebarToggleButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u4fa7\u680f", None))
#if QT_CONFIG(tooltip)
        self.sidebarToggleButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c55\u5f00\u6216\u6536\u8d77\u6536\u85cf\u5939\u4e0e\u641c\u7d22\u4fa7\u680f\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.zoomOutButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u2212", None))
#if QT_CONFIG(tooltip)
        self.zoomOutButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7f29\u5c0f\uff0c\u6700\u5c0f\u4e3a\u5b8c\u6574\u753b\u5e03\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.zoomInButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\uff0b", None))
#if QT_CONFIG(tooltip)
        self.zoomInButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u653e\u5927\uff0c\u4e0a\u9650\u4ee5\u5f53\u524d\u663e\u793a\u7684\u7f29\u653e\u8303\u56f4\u4e3a\u51c6\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.resetButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u663e\u793a\u5168\u90e8", None))
#if QT_CONFIG(tooltip)
        self.resetButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u663e\u793a\u5b8c\u6574\u753b\u5e03\uff0c\u5305\u542b\u539f\u70b9\u4e0e X=0\u3001Y=0 \u5750\u6807\u8f74\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.labelModeLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6587\u5b57\u6a21\u5f0f", None))
        self.labelModeComboBox.setItemText(0, QCoreApplication.translate("TskCoordinateWindowForm", u"\u81ea\u52a8\u907f\u8ba9", None))
        self.labelModeComboBox.setItemText(1, QCoreApplication.translate("TskCoordinateWindowForm", u"\u59cb\u7ec8\u663e\u793a\u5168\u90e8", None))

#if QT_CONFIG(tooltip)
        self.labelModeComboBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u81ea\u52a8\u907f\u8ba9\uff1a\u653e\u5927\u540e\u663e\u793a\u6587\u5b57\uff0c\u7f29\u5c0f\u65f6\u9690\u85cf\u3002\u59cb\u7ec8\u663e\u793a\u5168\u90e8\uff1a\u6240\u6709\u500d\u7387\u90fd\u663e\u793a\u6587\u5b57\u3002\u4e24\u79cd\u6a21\u5f0f\u4f7f\u7528\u76f8\u540c\u7684\u5750\u6807\u6392\u7248\uff0c\u7f29\u653e\u4e0d\u4f1a\u91cd\u65b0\u907f\u8ba9\u6216\u5207\u6362\u4f4d\u7f6e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.labelPositionLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u4f4d\u7f6e", None))
        self.labelPositionComboBox.setItemText(0, QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u65c1", None))
        self.labelPositionComboBox.setItemText(1, QCoreApplication.translate("TskCoordinateWindowForm", u"\u534a\u900f\u660e\u60ac\u6d6e", None))

#if QT_CONFIG(tooltip)
        self.labelPositionComboBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u65c1\uff1a\u6309\u5750\u6807\u7a7a\u95f4\u9009\u62e9 TSK \u4e0a\u3001\u4e0b\u3001\u5de6\u3001\u53f3\u7684\u7a7a\u9699\u3002\u534a\u900f\u660e\u60ac\u6d6e\uff1a\u6587\u5b57\u6d6e\u5728\u81ea\u8eab\u70b9\u4e0a\u65b9\uff0c\u4fdd\u7559\u4e0b\u65b9\u7684\u70b9\u3002\u6392\u7248\u9884\u7559\u533a\u57df\u56fa\u5b9a\uff0c\u7f29\u653e\u65f6\u4e0d\u6362\u8fb9\u3001\u4e0d\u91cd\u65b0\u6392\u5217\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.labelLayoutButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6807\u7b7e\u6392\u7248", None))
#if QT_CONFIG(tooltip)
        self.labelLayoutButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u62d6\u52a8\u5b57\u6bb5\u6807\u7b7e\uff0c\u5b89\u6392\u663e\u793a\u884c\u3001\u540c\u884c\u987a\u5e8f\u6216\u9690\u85cf\u5b57\u6bb5\u3002\u4fee\u6539\u4f1a\u7acb\u5373\u66f4\u65b0\u5750\u6807\u56fe\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.initialLabelSizeLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b57\u9ad8\uff08\u5750\u6807\uff09", None))
#if QT_CONFIG(tooltip)
        self.initialLabelSizeSpinBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5355\u884c\u6587\u5b57\u9ad8\u5ea6\uff0c\u4ee5\u5750\u6807\u8f74\u5355\u4f4d\u8868\u793a\uff1b\u4e24\u79cd\u6587\u5b57\u6a21\u5f0f\u5747\u9002\u7528\u3002\u6587\u5b57\u53ca\u907f\u8ba9\u7a7a\u95f4\u6309\u5750\u6807\u6392\u7248\uff0c\u968f\u5730\u56fe\u7f29\u653e\u3002\u652f\u6301\u5c0f\u6570\u6216\u79d1\u5b66\u8ba1\u6570\u6cd5\uff0c\u4f8b\u5982 1e-8\uff1b\u9996\u6b21\u6309\u6570\u636e\u8303\u56f4\u8bbe\u7f6e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.maximumLabelSizeLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6700\u5927\u5b57\u9ad8", None))
#if QT_CONFIG(tooltip)
        self.maximumLabelSizeSpinBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6587\u5b57\u5355\u884c\u9ad8\u5ea6\u7684\u5c4f\u5e55\u4e0a\u9650\uff0c\u5355\u4f4d\u4e3a\u903b\u8f91\u50cf\u7d20 px\u3002\u8fbe\u5230\u4e0a\u9650\u540e\uff0c\u6587\u5b57\u5728\u539f\u6709\u9884\u7559\u533a\u57df\u5185\u505c\u6b62\u53d8\u5927\uff0c\u4e0d\u6362\u8fb9\u6216\u91cd\u65b0\u6392\u5217\uff1b\u7f29\u5c0f\u65f6\u8fde\u7eed\u6062\u590d\u3002\u8303\u56f4 0.1 \u81f3 48.0 px\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.maximumLabelSizeSpinBox.setSuffix(QCoreApplication.translate("TskCoordinateWindowForm", u" px", None))
        self.zoomRangeLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5168\u56fe 1\u00d7 \u2014 \u6700\u5927 64\u00d7", None))
#if QT_CONFIG(tooltip)
        self.zoomRangeLabel.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u8fb9\u6846\u5305\u542b\u5b9e\u4f8b\u70b9\u53ca\u6587\u5b57\uff0c\u62d6\u52a8\u5728\u753b\u5e03\u8fb9\u754c\u5185\u505c\u6b62\u3002\u8c03\u6574\u5927\u5c0f\u65f6\u4fdd\u6301\u5f53\u524d\u89c6\u56fe\uff0c\u5e76\u6309\u9700\u6269\u5c55\u753b\u5e03\uff1b\u7f29\u653e\u4e0a\u9650\u4ee5\u6b64\u5904\u663e\u793a\u4e3a\u51c6\u3002\u70b9\u51fb\u663e\u793a\u5168\u90e8\u53ef\u91cd\u65b0\u8d34\u5408\u5185\u5bb9\u5e76\u6062\u590d\u5168\u56fe 1 \u81f3 64 \u500d\u7684\u8303\u56f4\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.pointWorldDiameterLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5706\u70b9\u76f4\u5f84\uff08\u5750\u6807\uff09", None))
#if QT_CONFIG(tooltip)
        self.pointWorldDiameterSpinBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b9e\u5fc3\u5706\u70b9\u76f4\u5f84\uff0c\u4ee5\u5750\u6807\u8f74\u5355\u4f4d\u8868\u793a\u3002\u4e0e\u6587\u5b57\u4e00\u6837\uff0c\u6309\u5750\u6807\u5c3a\u5bf8\u968f\u5730\u56fe\u7b49\u6bd4\u4f8b\u7f29\u653e\uff0c\u53ea\u53d7\u6700\u5927\u5c4f\u5e55\u76f4\u5f84\u9650\u5236\uff1b\u4e0d\u8bbe\u7f6e\u6700\u5c0f\u5c4f\u5e55\u5c3a\u5bf8\uff0c\u7f29\u5c0f\u65f6\u53ef\u5c0f\u4e8e 1 px\u3002\u652f\u6301\u5c0f\u6570\u6216\u79d1\u5b66\u8ba1\u6570\u6cd5\uff0c\u4f8b\u5982 1e-8\uff1b\u9996\u6b21\u6309\u6570\u636e\u8303\u56f4\u8bbe\u7f6e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.maximumPointDiameterLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6700\u5927\u76f4\u5f84", None))
#if QT_CONFIG(tooltip)
        self.maximumPointDiameterSpinBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5b9e\u5fc3\u5706\u70b9\u76f4\u5f84\u7684\u5c4f\u5e55\u4e0a\u9650\uff0c\u5355\u4f4d\u4e3a\u903b\u8f91\u50cf\u7d20 px\u3002\u4ec5\u9650\u5236\u6700\u5927\u663e\u793a\u76f4\u5f84\uff0c\u4e0d\u8bbe\u7f6e\u6700\u5c0f\u663e\u793a\u76f4\u5f84\u3002\u4e0a\u9650\u53ef\u8bbe\u4e3a 0.1 \u81f3 64.0 px\uff0c\u5706\u70b9\u4ecd\u53ef\u968f\u56fe\u7f29\u5c0f\u5230\u4f4e\u4e8e\u6b64\u8303\u56f4\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.maximumPointDiameterSpinBox.setSuffix(QCoreApplication.translate("TskCoordinateWindowForm", u" px", None))
        self.interactionHint.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6eda\u8f6e\u7f29\u653e \u00b7 \u62d6\u52a8\u5e73\u79fb \u00b7 \u53cc\u51fb\u663e\u793a\u5168\u90e8 \u00b7 \u60ac\u505c\u67e5\u770b\u5b8c\u6574\u5c5e\u6027", None))
#if QT_CONFIG(tooltip)
        self.interactionHint.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6eda\u8f6e\u7f29\u653e \u00b7 \u62d6\u52a8\u5e73\u79fb \u00b7 \u53cc\u51fb\u663e\u793a\u5168\u90e8 \u00b7 \u60ac\u505c\u67e5\u770b\u5b8c\u6574\u5c5e\u6027\u3002\u663e\u793a\u5168\u90e8\u5305\u542b\u539f\u70b9\u4e0e X=0\u3001Y=0 \u5750\u6807\u8f74\u3002\u6587\u5b57\u4e0e\u5706\u70b9\u6309\u5750\u6807\u7f29\u653e\uff0c\u5e76\u53d7\u5c4f\u5e55\u5927\u5c0f\u4e0a\u9650\u9650\u5236\uff1b\u6807\u7b7e\u4f4d\u7f6e\u56fa\u5b9a\uff0c\u4e0d\u968f\u7f29\u653e\u91cd\u65b0\u907f\u8ba9\u3002\u81ea\u52a8\u907f\u8ba9\u4ec5\u5728\u653e\u5927\u540e\u663e\u793a\u6587\u5b57\u3002\u540c\u5750\u6807\u70b9\u53ef\u91cd\u590d\u70b9\u51fb\u5207\u6362\u94fe\u8def\u3002\u4e24\u79cd\u8272\u9636\u5206\u522b\u6309\u5f53\u524d\u7ec4\u6709\u6548\u503c\u7ebf\u6027\u7f29\u653e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.selectionLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u51fb Chain \u540d\u79f0\u6216\u5706\u70b9\u53ef\u9ad8\u4eae\u6574\u6761\u94fe\u3002", None))
        self.pointLegendTitle.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u70b9\u8272 \u00b7 \u5b9e\u4f8b\u9884\u4f30\u5931\u6548\u7387", None))
        self.pointGradient.setStyleSheet(QCoreApplication.translate("TskCoordinateWindowForm", u"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #23a5a0, stop:0.5 #edc65a, stop:1 #d1495b); border-radius: 3px;", None))
        self.pointLegendLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        self.selectionLegend.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u9ad8\u4eae\u8272\u5bf9\u5e94\u6536\u85cf\u5939", None))
#if QT_CONFIG(tooltip)
        self.selectionLegend.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6536\u85cf\u94fe\u8def\u4f7f\u7528\u5404\u81ea\u5e95\u8272\u9ad8\u4eae\u6807\u7b7e\u5916\u6846\u3001\u5f15\u51fa\u7ebf\u548c\u5149\u5708\uff1b\u5176\u4ed6\u9009\u62e9\u4f7f\u7528\u84dd\u8272\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.ringLegendTitle.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708 \u00b7 \u94fe\u8def\u89c2\u6d4b\u5931\u6548\u7387", None))
        self.ringLegendTitle.setProperty(u"formatText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u5916\u5708 \u00b7 {metric}", None))
        self.ringGradient.setStyleSheet(QCoreApplication.translate("TskCoordinateWindowForm", u"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #23a5a0, stop:0.5 #edc65a, stop:1 #d1495b); border-radius: 3px;", None))
        self.ringLegendLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6682\u65e0\u6709\u6548\u98ce\u9669", None))
        self.missingLegend.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u7070\u8272\uff1a\u65e0\u6709\u6548\u4f30\u8ba1 / \u6d4b\u8bd5", None))
        self.xyHeatmapCheckBox.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"XY \u5f71\u54cd\u70ed\u529b\u56fe", None))
#if QT_CONFIG(tooltip)
        self.xyHeatmapCheckBox.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6309 XY \u62df\u5408\u66f2\u9762\u94fa\u6ee1\u6574\u4e2a\u753b\u5e03\uff0c\u6570\u636e\u8303\u56f4\u5916\u4e3a\u6a21\u578b\u5ef6\u4f38\uff1b\u84dd\u8272\u964d\u4f4e\uff0c\u68d5\u8272\u5347\u9ad8\uff0c\u96f6\u503c\u900f\u660e\u3002\u5f53\u524d\u7ec4\u5c1a\u65e0 XY \u7cfb\u6570\u62df\u5408\u7ed3\u679c\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.xyHeatmapGradient.setProperty(u"zeroText", QCoreApplication.translate("TskCoordinateWindowForm", u"0", None))
#if QT_CONFIG(accessibility)
        self.xyHeatmapGradient.setAccessibleName(QCoreApplication.translate("TskCoordinateWindowForm", u"XY \u5f71\u54cd\u8272\u9636\uff08\u0394log-odds\uff09", None))
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(accessibility)
        self.xyHeatmapGradient.setAccessibleDescription(QCoreApplication.translate("TskCoordinateWindowForm", u"\u4e94\u4e2a\u523b\u5ea6\u4ece\u5f53\u524d\u753b\u5e03\u7684\u6700\u5927\u8d1f\u5f71\u54cd\uff0c\u7ecf\u8fc7\u96f6\uff0c\u5230\u6700\u5927\u6b63\u5f71\u54cd\uff1b\u84dd\u8272\u964d\u4f4e\uff0c\u68d5\u8272\u5347\u9ad8\u3002", None))
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(tooltip)
        self.xyHeatmapGradient.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u8fde\u7eed\u8272\u9636\u53ca\u4e94\u4e2a\u6570\u503c\u523b\u5ea6\uff0c\u5355\u4f4d\u4e3a \u0394log-odds\uff0c\u4e0e\u6574\u5f20\u753b\u5e03\u4f7f\u7528\u76f8\u540c\u7684\u989c\u8272\u548c\u8303\u56f4\u3002\u84dd\u8272\uff1a\u76f8\u5bf9\u53c2\u8003\u70b9\u964d\u4f4e\uff1b\u900f\u660e\uff1a\u96f6\u5f71\u54cd\uff1b\u68d5\u8272\uff1a\u76f8\u5bf9\u53c2\u8003\u70b9\u5347\u9ad8\u3002\u975e\u5931\u6548\u6982\u7387\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.xyHeatmapLegendLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5f53\u524d\u7ec4\u5c1a\u65e0 XY \u7cfb\u6570\u62df\u5408\u7ed3\u679c", None))
        self.coordinatePlot.setProperty(u"originTickText", QCoreApplication.translate("TskCoordinateWindowForm", u"0", None))
        self.coordinatePlot.setProperty(u"emptyText", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6ca1\u6709\u53ef\u7ed8\u5236\u7684\u6709\u6548 XY \u5750\u6807\u3002\u8bf7\u5728\u6a21\u677f\u4e2d\u63d0\u4f9b\u5b9e\u4f8b\u5750\u6807\u540e\u91cd\u65b0\u5206\u6790\u3002", None))
        self.coordinatePlot.setProperty(u"labelMode", QCoreApplication.translate("TskCoordinateWindowForm", u"auto", None))
        self.coordinatePlot.setProperty(u"labelPosition", QCoreApplication.translate("TskCoordinateWindowForm", u"side", None))
        self.coordinatePlot.setProperty(u"leaderLineDarkColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#a4abb6", None))
        self.coordinatePlot.setProperty(u"leaderLineLightColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#858d98", None))
        self.coordinatePlot.setProperty(u"labelValueSeparator", QCoreApplication.translate("TskCoordinateWindowForm", u" \u00b7 ", None))
        self.coordinatePlot.setProperty(u"lowColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#23a5a0", None))
        self.coordinatePlot.setProperty(u"middleColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#edc65a", None))
        self.coordinatePlot.setProperty(u"highColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#d1495b", None))
        self.coordinatePlot.setProperty(u"missingColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#8c939e", None))
        self.coordinatePlot.setProperty(u"selectionColor", QCoreApplication.translate("TskCoordinateWindowForm", u"#4285ff", None))
        self.coordinatePlot.setProperty(u"identityFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"TSK {tsk} \u00b7 {instance}", None))
        self.coordinatePlot.setProperty(u"chainFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"Chain {chain}", None))
        self.coordinatePlot.setProperty(u"attributeFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"{name}\uff1a{value}", None))
        self.coordinatePlot.setProperty(u"riskFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u9884\u4f30\u5931\u6548\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"observedFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u89c2\u6d4b\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"predictedFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u94fe\u8def\u9884\u6d4b\uff1a{risk}", None))
        self.coordinatePlot.setProperty(u"overlapFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u6b64\u5904\u5171 {count} \u4e2a\u5b9e\u4f8b\uff1b\u91cd\u590d\u70b9\u51fb\u53ef\u5207\u6362\u94fe\u8def\u3002", None))
        self.coordinatePlot.setProperty(u"moreFormat", QCoreApplication.translate("TskCoordinateWindowForm", u"\u53e6\u6709 {count} \u4e2a\u5b9e\u4f8b\uff1b\u9009\u62e9 Chain \u53ef\u5b9a\u4f4d\u3002", None))
        self.favoritesHint.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5e95\u8272\u5bf9\u5e94\u753b\u5e03\u6807\u7b7e\u5916\u6846\uff0c\u52fe\u9009\u53ef\u540c\u65f6\u9ad8\u4eae\u591a\u6761\u94fe\u8def\u3002", None))
        self.addFavoriteButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u6536\u85cf\u5f53\u524d\u94fe\u8def", None))
#if QT_CONFIG(tooltip)
        self.addFavoriteButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c06\u5f53\u524d\u9009\u4e2d\u7684\u94fe\u8def\u52a0\u5165\u6536\u85cf\u5939\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.removeFavoriteButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u79fb\u9664", None))
#if QT_CONFIG(tooltip)
        self.removeFavoriteButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u4ece\u6536\u85cf\u5939\u79fb\u9664\u5f53\u524d\u9009\u4e2d\u7684\u6761\u76ee\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.favoriteChainsList.setStyleSheet(QCoreApplication.translate("TskCoordinateWindowForm", u"QListWidget::item { min-height: 24px; padding: 3px 6px; }", None))
#if QT_CONFIG(tooltip)
        self.favoriteChainsList.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u52fe\u9009\u6761\u76ee\u53ef\u540c\u65f6\u9ad8\u4eae\u591a\u6761\u94fe\u8def\uff1b\u9009\u62e9\u6761\u76ee\u540e\u53ef\u5c06\u5176\u79fb\u9664\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.favoriteStatusLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u672a\u6536\u85cf\u94fe\u8def\u3002\u9009\u4e2d\u94fe\u8def\u540e\u53ef\u52a0\u5165\u6536\u85cf\u5939\u3002", None))
        self.obtainFailedSamplesButton.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u83b7\u5f97\u5931\u6548\u6837\u54c1 ID", None))
#if QT_CONFIG(tooltip)
        self.obtainFailedSamplesButton.setToolTip(QCoreApplication.translate("TskCoordinateWindowForm", u"\u67e5\u770b\u5f53\u524d\u7ec4\u6536\u85cf\u94fe\u8def\u7684\u5931\u6548\u6837\u54c1\uff0c\u6309 Sample ID \u9009\u53d6\u5e76\u6bd4\u8f83\u5176\u5931\u6548\u94fe\u8def\u3002\u65e7\u7ed3\u679c\u53ef\u76f4\u63a5\u8bfb\u53d6 Analyze \u5df2\u4fdd\u5b58\u660e\u7ec6\uff0c\u65e0\u9700\u91cd\u65b0\u8fd0\u884c TSK \u5206\u6790\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.sidebarTabs.setTabText(self.sidebarTabs.indexOf(self.favoritesTab), QCoreApplication.translate("TskCoordinateWindowForm", u"\u6536\u85cf\u5939", None))
        self.sidebarTabs.setTabText(self.sidebarTabs.indexOf(self.searchTab), QCoreApplication.translate("TskCoordinateWindowForm", u"\u641c\u7d22", None))
        self.statusLabel.setText(QCoreApplication.translate("TskCoordinateWindowForm", u"\u5c1a\u65e0\u5750\u6807\u6570\u636e", None))
    # retranslateUi

