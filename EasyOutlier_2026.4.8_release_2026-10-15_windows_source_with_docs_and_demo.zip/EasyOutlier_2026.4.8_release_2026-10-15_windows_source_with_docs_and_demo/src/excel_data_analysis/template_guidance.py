"""User-facing, per-column instructions for editable template worksheets."""
from __future__ import annotations

import re


# Increment for workbook guidance changes that existing templates should receive.
# Keep separate from the schema version: text refreshes do not change settings.
TEMPLATE_WORKBOOK_GUIDANCE_VERSION = 3


ANALYSIS_FILTERS_GUIDANCE = "命中组合排除后按无数据处理，不算 Pass/Fail，不计有效分母，也不受“空值判 Fail”影响。其他链路、节点正常分析；原始数据保留，无需重新导入。"
ANALYSIS_FILTERS_LOGIC_GUIDANCE = (
    "同一 Rule ID 内：同 Scope、同 Field 的多个 Value 用 OR（任一匹配）；"
    "不同字段用 AND（全部匹配，含 row 与 column）。不同 Rule ID 用 OR（任一规则命中即排除）。"
)
ANALYSIS_FILTERS_ORDINARY_GUIDANCE = (
    "Rule ID 留空时：include 的不同字段用 AND；"
    "exclude + row 的不同字段用 OR（任一命中即排除整行）；"
    "exclude + column 的不同字段用 AND（全部匹配才排除整列）。行排除和列排除独立生效。"
)


SHEET_COLUMN_GUIDANCE = {
    "tsk_analysis": {
        "field": "TSK 模块设置字段。enabled 仅控制此模块，普通 Analyze 不自动执行。",
        "value": "设置的值。多个字段名称用英文分号分隔；布尔值填 TRUE 或 FALSE。",
        "notes": "本行设置的说明。内置 TSK 映射是假设示例，使用真实数据前请替换。",
    },
    "tsk_instances": {
        "chain_id": "链路编号。同一条链使用同一 ID，须与完整 CHAIN_KEY 一一对应。Chain 名全局唯一时可直接填该名称。",
        "tsk_instance_id": "该链内的物理实例编号，必须唯一。同类 TSK 出现多次时分行记录，不能合并去重。不同链的实例视为不同电路。",
        "tsk_id": "TSK 设计类型。同名表示相同设计，可出现在多条链或同链多个物理实例。",
        "x": "物理实例 X 坐标，填写有限数值，单位见 coordinate_unit。考虑 XY 时每个实例必填。",
        "y": "物理实例 Y 坐标，填写有限数值，原点和单位须与 X 一致。不考虑 XY 时允许留空。",
        "chain_key": '完整列表头路径，保留 Chain 层及以上，使用 JSON 数组，如 ["Group A", "Chain 1"]。名称重复时必填；唯一名称可留空自动匹配。',
    },
    "row_dimensions": {
        "name": "维度内部名，如 lot_id、sample_id。同一维度占多行时填写相同名字。其他页引用此名字，忽略大小写、空格、下划线和连字符。",
        "display_name": "报表上显示的名称，可以填中文。留空时使用 Name。",
        "priority": "行表头层级：1 为最高层，数字越大越低。每个维度的数字应不同。",
        "optional": "此维度能否缺失：TRUE 可以，FALSE 不可以。留空按 FALSE。",
        "default_value": "未提取到内容时使用的默认值。不需要则留空。",
        "source_order": "同一维度有多个来源时，按 1、2、3 排列提取顺序。",
        "source_column": "从原始数据哪一列取值，填写原始表中的列名。一个来源写一行；列名允许大小写、空格、下划线和连字符互换。",
        "default_split_position": "拆分后取第几段：0 是第一段，1 是第二段。填写时须同时填分隔符；不拆分则留空。",
        "split_position_by_column": "需要按条件选不同片段时，填条件所在的原始列名。不需要则连同后两列留空。",
        "match_value": "条件列等于什么值时使用右边的位置。每个条件单独写一行。",
        "mapped_split_position": "命中左边条件时取第几段，0 是第一段。未命中时使用默认位置。",
        "skip_empty_parts": "拆分时是否跳过空片段：TRUE 跳过，FALSE 保留。留空按 FALSE。",
    },
    "column_header_levels": {
        "name": "列表头层级名，如 Chain Name、Test Type。每层一行；analysis_groups 中须有对应列。引用名称时忽略大小写、空格、下划线和连字符。",
        "priority": "列层级顺序：1 为最高层，数字越大越低。每层的数字应不同。",
    },
    "analysis_groups": {
        "id": "分析组编号。同一组的测试列填相同 ID；每个原始测试列占一行。同组判据应一致。",
        "display_name": "分析组的显示名称，可以填中文。留空时使用 ID。",
        "analysis_mode": "per_column：每列单独算；pooled_columns：同 ID 的列一起算 Golden 和 Z-score。Z-score 默认使用 Golden 相同的参考数据范围，中位数和 MAD 保存在 Golden 文件；可在 template_info 关闭 report_zscore_use_golden_reference，改用全部分析数据。",
        "unit": "测试单位，如 V、A、Ohm。不需要显示单位时留空。",
        "outlier_golden_method": "Golden 判据，如 relative、sigma、mad、absolute，也可用 and / or 和括号组合。mad 使用 modified Z-score。留空用全局设置。",
        "golden_relative_limit": "相对偏差比例，如 0.2 表示 20%。留空用全局设置。",
        "golden_sigma_multiplier": "允许偏差为多少倍标准差，如 3。留空用全局设置。",
        "golden_mad_multiplier": "Modified Z-score 绝对值上限，如 3.5。允许区间为中位数 ± 此倍数 × MAD / 0.6745。留空用全局设置；参考值少于 3 个或 MAD 为 0 时，mad 不判失效。",
        "golden_lower_bound": "absolute 判据的允许下限，单位同测试值。留空用全局设置。",
        "golden_upper_bound": "absolute 判据的允许上限，单位同测试值。留空用全局设置。",
        "golden_overwrite_lower_bound": "覆盖计算结果的最终下限。启用 overwrite_lowerbound 时使用；留空用全局设置。",
        "golden_overwrite_upper_bound": "覆盖计算结果的最终上限。启用 overwrite_upperbound 时使用；留空用全局设置。",
        "golden_continuous_interval": "TRUE：把多个允许区间连成一个区间；FALSE：保留分开的区间。留空用全局设置。",
        "golden_empty_range_fallback_to_absolute": "允许区间为空时，TRUE 改用 absolute 上下限，FALSE 不回退。留空用全局设置。",
        "column_order": "该测试列在组内的顺序，填 1、2、3。",
        "column_name": "原始数据的测试列名，必须能匹配原表；忽略大小写、空格、下划线和连字符。每列写一行。",
        "golden_reference_node": "该测试列使用的 Golden 参考节点，如 T0。留空用全局节点筛选；填写时仅覆盖可靠性节点筛选，其他筛选保留。同组各列可不同；pooled_columns 按各列节点取值后合并计算。",
    },
    "node_orders": {
        "sequence_name": "节点顺序的名称，可自行命名。一行写一条完整的先后顺序。",
    },
    "analysis_filters": {
        "mode": "include 只保留，exclude 排除。Rule ID 留空为普通筛选；填写 Rule ID 为组合排除，只能填 exclude。不筛选时整行留空。",
        "rule_id": "普通筛选留空，组合排除填写规则编号。" + ANALYSIS_FILTERS_LOGIC_GUIDANCE + " 当前同一 ID 必须同时含 row 和 column 条件。",
        "scope": "row 表示行维度，column 表示列字段。" + ANALYSIS_FILTERS_ORDINARY_GUIDANCE,
        "field": "普通 row 填 node/reliability_node 或 sample_key（完整样品 ID）；组合 row 填任意行维度 Name。column 填列表头名、id、raw_column 等。链名重复时增加上级字段限定完整链路。",
        "value_order": "在相同 Mode、Rule ID、Scope 下，每个 Field 分别从 1 编号；单值填 1，多值填 1、2、3。仅控制排列顺序，不是优先级，不影响 AND/OR 匹配。",
        "value": ANALYSIS_FILTERS_GUIDANCE + " 同组同字段多值用 OR，每格一个，区分大小写；sample_key 用分号连接一个样品的各唯一 ID 字段值。例：同一 Rule ID 的节点 T2/T4、链路 Link1～Link4，表示 (T2 OR T4) AND (Link1 OR Link2 OR Link3 OR Link4)，排除 8 个组合。",
    },
    "outlier_ratio_stats": {
        "id": "统计项编号。一个统计项有多个筛选条件时，分行填写相同 ID。不统计则整行留空。",
        "display_name": "统计结果的显示名称，可以填中文。留空时使用 ID。",
        "group_by_dimension": "按哪些层级统计：填节点、节点上方的行维度或列层级名。多个名字用英文分号分隔。名称忽略大小写、空格、下划线和连字符，如 chain_name 可匹配 Chain Name。",
        "numerator": "分子统计什么：new_outlier_samples 新增异常；outlier_samples 全部异常；recovered_samples 恢复正常。",
        "filter_type": "筛选字段可填 row_dimensions 的 Name/唯一 Display Name、column_header_levels 的 Name，或 chain_name、test_type、id、unit 等内置字段。行维度包括节点以下的 site_id、repeat_id 等。字段名忽略大小写、空格、下划线和连字符；Filter Value 仍区分大小写。同名有歧义时用 row_dimension:Name 或 column_header:Name 明确范围。不筛选时与 Filter Value 一起留空。",
        "filter_order": "同一统计项有多个条件时，填 1、2、3。",
        "filter_value": "筛选的具体值，每个值单独一行。同类条件满足任一即可，不同类条件须同时满足。",
    },
}


def column_guidance(sheet_name: str, headers: list[str]) -> list[str]:
    result = []
    for index, header in enumerate(headers):
        key = re.sub(r"\s+", "_", str(header).strip().lower())
        text = SHEET_COLUMN_GUIDANCE[sheet_name].get(key)
        if text is None and sheet_name == "row_dimensions" and key.startswith("delimiter_"):
            text = "用于拆分原始文本的分隔符，如 _、-。每格写一个；不拆分则留空。"
        if text is None and sheet_name == "node_orders" and key.startswith("node_"):
            text = "填写此阶段的节点值，须与数据一致。从左到右按先后排列；未用列留空。"
            if index == len(headers) - 1:
                next_node = int(key.removeprefix("node_")) + 1
                text += f"\n节点更多时，继续向右加列，表头依次填 Node {next_node}、Node {next_node + 1}…，每格一个节点。"
        if text is None and sheet_name == "analysis_groups":
            text = f"此测试列在“{header}”层的具体值，必填。同值归为一组。"
            if index == len(headers) - 1:
                text += "\n层级不限于现有列。新增层级时，在 column_header_levels 增加 Name 和 Priority，再向右添加同名列，并为每个测试列填值。"
        if text is None and sheet_name == "tsk_instances":
            text = f"实例特征“{header}”，先在 tsk_analysis.feature_columns 声明。数值特征填有限数值、统一单位；类别特征另在 categorical_feature_columns 声明，可填规格、材料等非空标签或数字类别。"
        if text is None:
            raise ValueError(f"Missing template column guidance: {sheet_name}.{header}")
        result.append(text)
    return result
