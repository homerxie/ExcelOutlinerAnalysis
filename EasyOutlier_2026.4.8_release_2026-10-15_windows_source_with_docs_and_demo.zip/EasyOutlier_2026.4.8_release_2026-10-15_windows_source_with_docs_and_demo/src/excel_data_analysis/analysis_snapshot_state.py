"""Lossless Analyze snapshots: bounded gzip JSON records with shared tables.

The v2 stream retains exact templates, values, metric fields and summaries, while
keeping Golden rules and numeric arrays compact. The data-only type allowlist and
the original v1 JSON reader are retained for existing database snapshots.
"""
from __future__ import annotations

from array import array
import base64
import binascii
from dataclasses import fields
from decimal import Decimal, InvalidOperation
import gzip
import io
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import zlib

from .compact_analysis import DenseZScoreMap
from .compact_golden import PackedGoldenMap
from .models import (
    AnalysisColumn, AnalysisColumnFilterConfig, AnalysisDimensionFilterConfig, AnalysisExclusionRule,
    AnalysisGroup, ColumnHeaderLevel, GoldenAllowedRange, GoldenReferenceDefaults,
    NumericCleanupConfig, OutlierRatioStatConfig, ReportConfig, RowDimension,
    RowDimensionSource, TemplateConfig, ThresholdConfig, TSKAnalysisConfig, TSKInstance,
)
from .reporting import ColumnMeta, MetricValue, RowData


FORMAT = "analyze-snapshot-v2"
LEGACY_FORMAT = "analyze-snapshot-v1"
SUPPORTED_FORMATS = (FORMAT, LEGACY_FORMAT)
_TAG = "$type"
_CLASSES = (
    AnalysisColumn, AnalysisColumnFilterConfig, AnalysisDimensionFilterConfig, AnalysisExclusionRule,
    AnalysisGroup, ColumnHeaderLevel, GoldenAllowedRange, GoldenReferenceDefaults,
    NumericCleanupConfig, OutlierRatioStatConfig, ReportConfig, RowDimension,
    RowDimensionSource, TemplateConfig, ThresholdConfig, TSKAnalysisConfig, TSKInstance,
    ColumnMeta, MetricValue, RowData,
)
_TYPES = {cls.__name__: cls for cls in _CLASSES}
_FIELDS = {cls: tuple(field.name for field in fields(cls)) for cls in _CLASSES}
_REQUIRED = {
    "template", "columns", "rows", "zscore_values", "golden_values",
    "golden_header_values", "golden_bound_values", "golden_threshold_values",
    "zscore_threshold_values", "golden_fallback_warnings", "include_point_golden_sheet",
    "sample_node_orders", "summary_artifacts", "available_nodes", "fail_mode", "result",
}
_ARTIFACTS = {
    "summary_rows", "summary_stats_rows", "ratio_rows", "all_outlier_rows",
    "merged_outlier_rows", "final_status_rows",
}


def _packed_array(values: array) -> str:
    # Both numeric types are explicitly eight-byte little-endian on the wire.
    if values.itemsize != 8:
        raise ValueError("Unsupported numeric array width")
    if sys.byteorder != "little":
        values = array(values.typecode, values)
        values.byteswap()
    return base64.b64encode(values.tobytes()).decode("ascii")


def _unpacked_array(data: str, typecode: str) -> array:
    raw = base64.b64decode(data, validate=True)
    if len(raw) % 8:
        raise ValueError("Invalid saved Analyze numeric array")
    values = array(typecode)
    if values.itemsize != 8:
        raise ValueError("Unsupported numeric array width")
    values.frombytes(raw)
    if sys.byteorder != "little":
        values.byteswap()
    return values


def _encode(value):
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else {_TAG: "float", "value": repr(value)}
    if isinstance(value, Decimal):
        return {_TAG: "decimal", "value": str(value)}
    if isinstance(value, DenseZScoreMap):
        return {
            _TAG: "dense_zscores", "rows": _encode(value._rows), "columns": value._columns,
            "scores": _packed_array(value._scores), "thresholds": _packed_array(value._thresholds),
            "flags": base64.b64encode(value._flags).decode("ascii"),
            "order": _packed_array(value._order),
        }
    if type(value) in _FIELDS:
        return {_TAG: type(value).__name__, "fields": {
            name: _encode(getattr(value, name)) for name in _FIELDS[type(value)]
        }}
    if isinstance(value, list):
        return [_encode(item) for item in value]
    if isinstance(value, tuple):
        return {_TAG: "tuple", "items": [_encode(item) for item in value]}
    if isinstance(value, dict):
        if _TAG not in value and all(isinstance(key, str) for key in value):
            return {key: _encode(item) for key, item in value.items()}
        return {_TAG: "mapping", "items": [[_encode(key), _encode(item)] for key, item in value.items()]}
    raise ValueError(f"Unsupported saved Analyze value type: {type(value).__name__}")


def _decode_dense(value: dict) -> DenseZScoreMap:
    rows = _decode(value["rows"])
    columns = value["columns"]
    if (not isinstance(rows, list) or not isinstance(columns, list)
            or any(not isinstance(row, tuple) or len(row) != 2 for row in rows)
            or any(not isinstance(column, str) for column in columns)
            or len(set(rows)) != len(rows) or len(set(columns)) != len(columns)):
        raise ValueError("Invalid saved Analyze score axes")
    scores = _unpacked_array(value["scores"], "d")
    thresholds = _unpacked_array(value["thresholds"], "d")
    flags = bytearray(base64.b64decode(value["flags"], validate=True))
    order = _unpacked_array(value["order"], "Q")
    length = len(rows) * len(columns)
    if (len(scores) != length or len(thresholds) != length or len(flags) != length
            or any(flag not in (0, 1, 3, 5, 7) for flag in flags)
            or sum(bool(flag) for flag in flags) != len(order)):
        raise ValueError("Invalid saved Analyze packed scores")
    # A set(order) would expand every packed uint64 into a Python integer and
    # hash-table entry. Validate offsets with one temporary byte per dense cell.
    seen = bytearray(length)
    for offset in order:
        if offset >= length or not flags[offset] or seen[offset]:
            raise ValueError("Invalid saved Analyze packed scores")
        seen[offset] = 1
    del seen
    # Avoid allocating a second full set of dense arrays during restoration.
    result = DenseZScoreMap([], [], MetricValue)
    result._rows = rows
    result._columns = columns
    result._row_index = {key: index for index, key in enumerate(rows)}
    result._column_index = {key: index for index, key in enumerate(columns)}
    result._scores, result._thresholds = scores, thresholds
    result._flags, result._order = flags, order
    return result


def _decode(value):
    if isinstance(value, list):
        return [_decode(item) for item in value]
    if not isinstance(value, dict):
        return value
    if _TAG not in value:
        return {key: _decode(item) for key, item in value.items()}
    kind = value[_TAG]
    if kind in _TYPES:
        cls = _TYPES[kind]
        members = value["fields"]
        if cls is RowData and isinstance(members, dict) and "missing_columns" not in members:
            # Older Analyze snapshots predate source-header availability.
            members = {**members, "missing_columns": {_TAG: "tuple", "items": []}}
        if cls is ReportConfig and isinstance(members, dict) and "analysis_exclusions" not in members:
            members = {**members, "analysis_exclusions": []}
        if cls is OutlierRatioStatConfig and isinstance(members, dict):
            # Historical statistics predate arbitrary header and row filters.
            members = {"column_header_filters": {}, "row_dimension_filters": {}, **members}
        if not isinstance(members, dict) or set(members) != set(_FIELDS[cls]):
            raise ValueError("Invalid saved Analyze object fields")
        return cls(**{key: _decode(item) for key, item in members.items()})
    if kind == "dense_zscores":
        return _decode_dense(value)
    if kind == "tuple":
        return tuple(_decode(item) for item in value["items"])
    if kind == "mapping":
        result = {}
        for key, item in value["items"]:
            key = _decode(key)
            if key in result:
                raise ValueError("Duplicate saved Analyze mapping key")
            result[key] = _decode(item)
        return result
    if kind == "decimal":
        return Decimal(value["value"])
    if kind == "float" and value["value"] in ("nan", "inf", "-inf"):
        return float(value["value"])
    raise ValueError("Unsupported saved Analyze value type")


def _validate_snapshot(snapshot: dict) -> None:
    if not isinstance(snapshot, dict) or not _REQUIRED <= snapshot.keys():
        raise ValueError("Incomplete saved Analyze snapshot")
    if (not isinstance(snapshot["template"], TemplateConfig)
            or not isinstance(snapshot["rows"], list)
            or any(not isinstance(row, RowData) or not isinstance(row.values, dict)
                   or not isinstance(row.dimensions, dict) for row in snapshot["rows"])
            or not isinstance(snapshot["columns"], list)
            or any(not isinstance(column, ColumnMeta) for column in snapshot["columns"])
            or not isinstance(snapshot["sample_node_orders"], dict)
            or not isinstance(snapshot["available_nodes"], list)
            or not isinstance(snapshot["include_point_golden_sheet"], bool)
            or not isinstance(snapshot["result"], dict)
            or not isinstance(snapshot["fail_mode"], str)):
        raise ValueError("Invalid saved Analyze snapshot fields")
    for name in ("zscore_values", "golden_values"):
        metrics = snapshot[name]
        if isinstance(metrics, (DenseZScoreMap, PackedGoldenMap)):
            continue
        if not isinstance(metrics, dict) or any(
            not isinstance(key, tuple) or len(key) != 3 or not isinstance(metric, MetricValue)
            for key, metric in metrics.items()
        ):
            raise ValueError("Invalid saved Analyze metrics")
    artifacts = snapshot["summary_artifacts"]
    if (not isinstance(artifacts, dict) or not _ARTIFACTS <= artifacts.keys()
            or any(not isinstance(artifacts[key], list) for key in _ARTIFACTS)):
        raise ValueError("Incomplete saved Analyze summaries")
    if any(not isinstance(row, dict)
           or not {"sample_key", "node", "test_group_key", "is_fail"} <= row.keys()
           or not isinstance(row["is_fail"], bool) for row in artifacts["final_status_rows"]):
        raise ValueError("Invalid saved Analyze chain states")


def encode_analysis_snapshot(snapshot: dict, *, database_root: str | Path | None = None) -> dict:
    """Encode a full completed snapshot; reject TSK-only legacy snapshots."""
    output = io.BytesIO()
    _write_snapshot(snapshot, output, database_root=database_root)
    return {"format": FORMAT,
            "data": base64.b64encode(output.getvalue()).decode("ascii")}


def _write_snapshot(snapshot: dict, output, *, database_root: str | Path | None = None) -> None:
    from .analysis_snapshot_stream import write_snapshot

    _validate_snapshot(snapshot)
    with gzip.GzipFile(filename="", fileobj=output, mode="wb", compresslevel=6, mtime=0) as packed:
        with io.TextIOWrapper(packed, encoding="utf-8") as text:
            write_snapshot(snapshot, text, FORMAT, database_root=database_root)


def save_analysis_snapshot(snapshot: dict, path: str | Path, *, database_root: str | Path | None = None) -> None:
    """Atomically write bounded records, keeping shared rules and arrays packed."""
    path = Path(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=path.parent, prefix=".analysis-",
                                         suffix=".tmp", delete=False) as output:
            temporary = Path(output.name)
            _write_snapshot(snapshot, output, database_root=database_root)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def snapshot_bytes(payload: dict) -> bytes:
    """Unwrap the JSON-storable envelope into the compressed snapshot file."""
    if not isinstance(payload, dict) or payload.get("format") not in SUPPORTED_FORMATS:
        raise ValueError("Unsupported saved Analyze snapshot format")
    try:
        return base64.b64decode(payload["data"], validate=True)
    except (KeyError, TypeError, ValueError, binascii.Error) as exc:
        raise ValueError("Invalid saved Analyze snapshot data") from exc


def decode_analysis_snapshot(data: bytes) -> dict:
    """Restore only allowlisted data types; never load executable pickle data."""
    return _read_snapshot(io.BytesIO(data))


def load_analysis_snapshot(path: str | Path) -> dict:
    """Read a snapshot without loading its compressed file into another buffer."""
    with Path(path).open("rb") as input:
        return _read_snapshot(input)


def _read_snapshot(input) -> dict:
    from .analysis_snapshot_stream import read_snapshot

    try:
        with gzip.GzipFile(fileobj=input, mode="rb") as packed:
            with io.TextIOWrapper(packed, encoding="utf-8") as text:
                first = text.readline()
                try:
                    payload = json.loads(first, parse_constant=_reject_constant)
                except json.JSONDecodeError:
                    # v1 was one JSON document; accept older pretty-printed
                    # documents as well as the application's compact writer.
                    payload = json.loads(first + text.read(), parse_constant=_reject_constant)
                del first
                if not isinstance(payload, dict):
                    raise ValueError("Unsupported saved Analyze snapshot format")
                if payload.get("format") == FORMAT and set(payload) == {"format"}:
                    snapshot = read_snapshot(text)
                elif payload.get("format") == LEGACY_FORMAT:
                    if text.read().strip():
                        raise ValueError("Invalid saved Analyze trailing content")
                    snapshot = _decode(payload["snapshot"])
                else:
                    raise ValueError("Unsupported saved Analyze snapshot format")
        _validate_snapshot(snapshot)
        return snapshot
    except (OSError, EOFError, zlib.error, UnicodeError, KeyError, TypeError,
            ValueError, OverflowError, InvalidOperation, IndexError, AttributeError) as exc:
        raise ValueError(f"Invalid saved Analyze snapshot: {exc}") from exc


def _reject_constant(value):
    raise ValueError(f"Invalid JSON numeric constant: {value}")


def write_analysis_snapshot(payload: dict, path: str | Path) -> None:
    Path(path).write_bytes(snapshot_bytes(payload))
