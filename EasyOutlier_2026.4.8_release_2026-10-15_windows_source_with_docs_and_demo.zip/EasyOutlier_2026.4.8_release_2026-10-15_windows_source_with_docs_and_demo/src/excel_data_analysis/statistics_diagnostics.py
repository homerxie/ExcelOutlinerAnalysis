"""Bounded diagnostics for statistics that produce no output.

Column classifications come from the columns resolved against the current
template; row dimension values come from the stored rows supplied to analysis.
Diagnostics explain those inputs without changing selection or stored data.
"""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from dataclasses import dataclass
import json
import sys
from typing import TYPE_CHECKING, Any

from .merge_config import column_levels, row_levels
from .models import OutlierRatioStatConfig, TemplateConfig

if TYPE_CHECKING:
    from .reporting import ColumnMeta, RowData


_BUILTIN_FIELDS = (
    ("id", "group_ids", "group_id"),
    ("display_name", "group_display_names", "group_display_name"),
    ("test_type", "test_types", "test_type"),
    ("chain_name", "chain_names", "chain_name"),
    ("column_name", "column_names", "raw_column"),
    ("unit", "units", "unit"),
    ("logical_metric", "logical_metrics", "logical_metric"),
)
_COLUMN_ATTRIBUTES = {name: attribute for name, _, attribute in _BUILTIN_FIELDS}
_EXAMPLE_LIMIT = 8


def emit_statistics_log(event: str, **details: Any) -> None:
    """Write structured diagnostics where both the CLI and GUI capture them."""
    stream = sys.stderr
    if stream is None:
        return
    message = "[Statistics] " + json.dumps(
        {"event": event, **details}, ensure_ascii=False, sort_keys=True,
    )
    try:
        print(message, file=stream, flush=True)
    except (OSError, ValueError):
        # A closed or broken log stream must not prevent producing the report.
        pass


def _filter_specs(config: OutlierRatioStatConfig) -> Iterator[tuple[str, str, list[str]]]:
    for name, attribute, _ in _BUILTIN_FIELDS:
        values = getattr(config, attribute)
        if name == "chain_name":
            values = values or config.chains
        elif name == "column_name":
            values = values or config.raw_columns
        if values:
            yield "builtin", name, values
    for kind, filters in (
        ("column_header", config.column_header_filters),
        ("row_dimension", config.row_dimension_filters),
    ):
        for name, values in filters.items():
            if values:
                yield kind, name, values


@dataclass(slots=True)
class _FieldSummary:
    counts: dict[str, int]
    source_count: int
    missing_count: int
    observed_values: tuple[str, ...]


class StatisticsDiagnostics:
    """Lazily describe filters, scanning each configured field at most once.

Only values requested by statistics are counted. Distinct observed values are
bounded so a row dimension with millions of identities does not create a large
diagnostic index. Keep this object local to one analysis run.
"""

    def __init__(
        self,
        template: TemplateConfig,
        columns: Sequence[ColumnMeta],
        rows: Sequence[RowData],
    ) -> None:
        self._template = template
        self._columns = columns
        self._rows = rows
        self._header_indices = {
            name: index for index, name in enumerate(column_levels(template))
        }
        self._requested: dict[tuple[str, str], set[str]] = {}
        self._cache: dict[tuple[str, str], _FieldSummary] = {}
        for config in template.report.outlier_ratio_stats:
            for kind, name, values in _filter_specs(config):
                self._requested.setdefault((kind, name), set()).update(values)

    def context_summary(self) -> dict[str, Any]:
        return {
            "template_name": self._template.name,
            "row_dimensions": row_levels(self._template),
            "column_header_levels": column_levels(self._template),
            "resolved_column_count": len(self._columns),
            "template_column_count": sum(
                len(group.columns) for group in self._template.analysis_groups
            ),
            "observed_row_count": len(self._rows),
            "metadata_sources": {
                "column_headers": "current_template",
                "row_dimensions": "stored_rows",
            },
        }

    def describe_filters(self, config: OutlierRatioStatConfig) -> list[dict[str, Any]]:
        descriptions = []
        for kind, name, values in _filter_specs(config):
            summary = self._describe_field(kind, name, values)
            is_row = kind == "row_dimension"
            descriptions.append({
                "field": f"{kind}:{name}",
                "scope": "row" if is_row else "column",
                "name": name,
                "requested_values": list(values),
                "source": "stored_row_dimensions" if is_row else "current_template_columns",
                "source_count": summary.source_count,
                "matched_count": sum(summary.counts[value] for value in set(values)),
                "missing_count": summary.missing_count,
                "observed_values": list(summary.observed_values),
            })
        return descriptions

    def _describe_field(self, kind: str, name: str, values: list[str]) -> _FieldSummary:
        key = (kind, name)
        requested = self._requested.setdefault(key, set())
        requested.update(values)
        cached = self._cache.get(key)
        if cached is not None and requested.issubset(cached.counts):
            return cached

        # Configurations normally belong to template.report.outlier_ratio_stats,
        # whose requested values were collected before any scan. An ad hoc new
        # configuration may request extra values and requires one fresh scan.
        counts = dict.fromkeys(requested, 0)
        examples: dict[str, None] = {}
        source_count = missing_count = 0
        for value in self._field_values(kind, name):
            source_count += 1
            if value is None or value == "":
                missing_count += 1
            elif len(examples) < _EXAMPLE_LIMIT:
                examples.setdefault(value, None)
            if value in counts:
                counts[value] += 1
        summary = _FieldSummary(counts, source_count, missing_count, tuple(examples))
        self._cache[key] = summary
        return summary

    def _field_values(self, kind: str, name: str) -> Iterator[str | None]:
        if kind == "row_dimension":
            for row in self._rows:
                yield str(row.dimensions.get(name, "") or "")
        elif kind == "column_header":
            index = self._header_indices.get(name)
            for column in self._columns:
                yield (
                    column.header_values[index]
                    if index is not None and index < len(column.header_values) else None
                )
        else:
            attribute = _COLUMN_ATTRIBUTES[name]
            for column in self._columns:
                value = getattr(column, attribute)
                yield str(value or "") if name == "unit" else value
