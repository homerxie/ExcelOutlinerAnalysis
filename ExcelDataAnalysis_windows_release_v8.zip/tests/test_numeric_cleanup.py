from __future__ import annotations

import unittest

from excel_data_analysis.io import to_float
from excel_data_analysis.models import NumericCleanupConfig


class NumericCleanupTests(unittest.TestCase):
    def test_to_float_without_cleanup_returns_none_for_text_number(self) -> None:
        self.assertIsNone(to_float("1,234mV"))

    def test_to_float_with_all_non_numeric_cleanup(self) -> None:
        config = NumericCleanupConfig(enabled=True, mode="all_non_numeric")
        self.assertEqual(to_float("1,234mV", config), 1234.0)
        self.assertEqual(to_float("-1.25e-3A", config), -1.25e-3)
        self.assertEqual(to_float("10E-3mA", config), 10e-3)
        self.assertEqual(to_float("abc10E-3deg", config), 10e-3)

    def test_to_float_with_specified_character_cleanup(self) -> None:
        config = NumericCleanupConfig(
            enabled=True,
            mode="specified_chars",
            characters=[",", "mV"],
        )
        self.assertEqual(to_float("1,234mV", config), 1234.0)

    def test_to_float_with_specified_character_cleanup_keeps_scientific_notation(self) -> None:
        config = NumericCleanupConfig(
            enabled=True,
            mode="specified_chars",
            characters=["mA"],
        )
        self.assertEqual(to_float("10E-3mA", config), 10e-3)


if __name__ == "__main__":
    unittest.main()
