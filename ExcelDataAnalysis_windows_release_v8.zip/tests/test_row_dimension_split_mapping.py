from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from excel_data_analysis.io import extract_dimensions
from excel_data_analysis.models import RowDimension, RowDimensionSource, TemplateConfig
from excel_data_analysis.template import load_template, save_template


class RowDimensionSplitMappingTests(unittest.TestCase):
    def test_extract_dimensions_uses_mapped_split_position_with_fallback(self) -> None:
        template = TemplateConfig(
            name="demo",
            row_dimensions=[
                RowDimension(
                    name="sample_piece",
                    sources=[
                        RowDimensionSource(
                            column="recordName",
                            split_delimiters=["_"],
                            split_position=0,
                            split_position_by_column="Site",
                            split_position_map={"A": 1, "B": 2},
                        )
                    ],
                )
            ],
        )

        self.assertEqual(
            extract_dimensions(template, {"recordName": "S001_T0_3", "Site": "A"}),
            {"sample_piece": "T0"},
        )
        self.assertEqual(
            extract_dimensions(template, {"recordName": "S001_T0_3", "Site": "B"}),
            {"sample_piece": "3"},
        )
        self.assertEqual(
            extract_dimensions(template, {"recordName": "S001_T0_3", "Site": "C"}),
            {"sample_piece": "S001"},
        )

    def test_json_roundtrip_preserves_split_position_map(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            template_path = Path(temp_dir) / "template.json"
            template_path.write_text(
                json.dumps(
                    {
                        "name": "demo",
                        "row_dimensions": [
                            {
                                "name": "sample_id",
                                "display_name": "Sample ID",
                                "sources": [
                                    {
                                        "column": "recordName",
                                        "split_delimiters": ["_", "｜"],
                                        "split_position": 0,
                                        "split_position_by_column": "Site",
                                        "split_position_map": {
                                            "1": 1,
                                            "2": 2,
                                            "A": 0,
                                        },
                                    }
                                ],
                            }
                        ],
                        "analysis_groups": [],
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )

            template = load_template(template_path)
            source = template.row_dimensions[0].sources[0]
            self.assertEqual(source.split_position_by_column, "Site")
            self.assertEqual(source.split_position_map, {"1": 1, "2": 2, "A": 0})

            output_path = Path(temp_dir) / "roundtrip.json"
            save_template(template, output_path, if_exists="overwrite")
            payload = json.loads(output_path.read_text(encoding="utf-8"))
            roundtrip_source = payload["row_dimensions"][0]["sources"][0]
            self.assertEqual(roundtrip_source["split_position_by_column"], "Site")
            self.assertEqual(
                roundtrip_source["split_position_map"],
                {"1": 1, "2": 2, "A": 0},
            )

    def test_xlsx_roundtrip_preserves_split_position_map(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            template = TemplateConfig(
                name="demo",
                row_dimensions=[
                    RowDimension(
                        name="sample_id",
                        display_name="Sample ID",
                        sources=[
                            RowDimensionSource(
                                column="recordName",
                                split_delimiters=["_", "｜"],
                                split_position=0,
                                split_position_by_column="Site",
                                split_position_map={"1": 1, "A": 2},
                                skip_empty_parts=True,
                            )
                        ],
                    )
                ],
            )
            workbook_path = Path(temp_dir) / "template.xlsx"
            save_template(template, workbook_path, if_exists="overwrite")

            loaded = load_template(workbook_path)
            source = loaded.row_dimensions[0].sources[0]
            self.assertEqual(source.split_position_by_column, "Site")
            self.assertEqual(source.split_position_map, {"1": 1, "A": 2})
            self.assertEqual(source.split_position, 0)
            self.assertTrue(source.skip_empty_parts)


if __name__ == "__main__":
    unittest.main()
