# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_risk_filter_popup.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_TskRiskFilterPopupForm(object):
    def setupUi(self, TskRiskFilterPopupForm):
        if not TskRiskFilterPopupForm.objectName():
            TskRiskFilterPopupForm.setObjectName(u"TskRiskFilterPopupForm")
        TskRiskFilterPopupForm.resize(280, 350)
        TskRiskFilterPopupForm.setMinimumSize(QSize(240, 260))
        TskRiskFilterPopupForm.setFrameShape(QFrame.Shape.StyledPanel)
        self.popupLayout = QVBoxLayout(TskRiskFilterPopupForm)
        self.popupLayout.setSpacing(6)
        self.popupLayout.setObjectName(u"popupLayout")
        self.popupLayout.setContentsMargins(8, 8, 8, 8)
        self.fieldLabel = QLabel(TskRiskFilterPopupForm)
        self.fieldLabel.setObjectName(u"fieldLabel")
        self.fieldLabel.setWordWrap(True)
        self.fieldLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.popupLayout.addWidget(self.fieldLabel)

        self.sortLayout = QHBoxLayout()
        self.sortLayout.setObjectName(u"sortLayout")
        self.sortAscendingButton = QPushButton(TskRiskFilterPopupForm)
        self.sortAscendingButton.setObjectName(u"sortAscendingButton")

        self.sortLayout.addWidget(self.sortAscendingButton)

        self.sortDescendingButton = QPushButton(TskRiskFilterPopupForm)
        self.sortDescendingButton.setObjectName(u"sortDescendingButton")

        self.sortLayout.addWidget(self.sortDescendingButton)


        self.popupLayout.addLayout(self.sortLayout)

        self.searchLineEdit = QLineEdit(TskRiskFilterPopupForm)
        self.searchLineEdit.setObjectName(u"searchLineEdit")
        self.searchLineEdit.setClearButtonEnabled(True)

        self.popupLayout.addWidget(self.searchLineEdit)

        self.selectAllCheckBox = QCheckBox(TskRiskFilterPopupForm)
        self.selectAllCheckBox.setObjectName(u"selectAllCheckBox")
        self.selectAllCheckBox.setChecked(True)
        self.selectAllCheckBox.setTristate(True)

        self.popupLayout.addWidget(self.selectAllCheckBox)

        self.valuesListWidget = QListWidget(TskRiskFilterPopupForm)
        self.valuesListWidget.setObjectName(u"valuesListWidget")
        self.valuesListWidget.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.valuesListWidget.setAlternatingRowColors(True)
        self.valuesListWidget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        self.popupLayout.addWidget(self.valuesListWidget)

        self.liveHintLabel = QLabel(TskRiskFilterPopupForm)
        self.liveHintLabel.setObjectName(u"liveHintLabel")
        self.liveHintLabel.setWordWrap(True)

        self.popupLayout.addWidget(self.liveHintLabel)


        self.retranslateUi(TskRiskFilterPopupForm)

        QMetaObject.connectSlotsByName(TskRiskFilterPopupForm)
    # setupUi

    def retranslateUi(self, TskRiskFilterPopupForm):
        TskRiskFilterPopupForm.setProperty(u"blankText", QCoreApplication.translate("TskRiskFilterPopupForm", u"\uff08\u7a7a\u767d\uff09", None))
        self.fieldLabel.setText(QCoreApplication.translate("TskRiskFilterPopupForm", u"TSK ID", None))
        self.sortAscendingButton.setText(QCoreApplication.translate("TskRiskFilterPopupForm", u"\u5347\u5e8f\u6392\u5217 \u2191", None))
        self.sortDescendingButton.setText(QCoreApplication.translate("TskRiskFilterPopupForm", u"\u964d\u5e8f\u6392\u5217 \u2193", None))
        self.searchLineEdit.setPlaceholderText(QCoreApplication.translate("TskRiskFilterPopupForm", u"\u641c\u7d22\u7b5b\u9009\u503c", None))
        self.selectAllCheckBox.setText(QCoreApplication.translate("TskRiskFilterPopupForm", u"\u5168\u9009\u641c\u7d22\u7ed3\u679c", None))
        self.liveHintLabel.setText(QCoreApplication.translate("TskRiskFilterPopupForm", u"\u52fe\u9009\u540e\u7acb\u5373\u66f4\u65b0\u98ce\u9669\u56fe\u548c\u98ce\u9669\u660e\u7ec6\u3002", None))
    # retranslateUi

