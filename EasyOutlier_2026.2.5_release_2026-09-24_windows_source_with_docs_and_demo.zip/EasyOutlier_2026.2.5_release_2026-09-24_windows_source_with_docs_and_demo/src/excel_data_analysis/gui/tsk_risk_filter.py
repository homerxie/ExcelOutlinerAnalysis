"""Checkbox dropdowns for risk dimensions; form geometry is defined in .ui files."""
from __future__ import annotations

from PySide6.QtCore import QPoint, Qt, Signal
from PySide6.QtWidgets import QFrame, QListWidgetItem, QWidget

from ..tsk_sorting import natural_sort_key
from .ui_tsk_risk_filter import Ui_TskRiskFilterForm
from .ui_tsk_risk_filter_popup import Ui_TskRiskFilterPopupForm


class TskRiskFilterPopup(QFrame):
    selection_changed = Signal()
    sort_requested = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup)
        self.ui = Ui_TskRiskFilterPopupForm()
        self.ui.setupUi(self)
        self.ui.valuesListWidget.itemChanged.connect(self._item_changed)
        self.ui.searchLineEdit.textChanged.connect(self._search_changed)
        self.ui.selectAllCheckBox.clicked.connect(self._select_visible)
        self.ui.sortAscendingButton.clicked.connect(lambda: self._sort(False))
        self.ui.sortDescendingButton.clicked.connect(lambda: self._sort(True))

    def _sort(self, descending):
        self.sort_requested.emit(descending)
        self.hide()

    @property
    def selected_values(self):
        return {self.ui.valuesListWidget.item(index).data(Qt.UserRole)
                for index in range(self.ui.valuesListWidget.count())
                if self.ui.valuesListWidget.item(index).checkState() == Qt.Checked}

    def set_values(self, label, values, selected=None):
        self.ui.fieldLabel.setText(label)
        selected = set(values) if selected is None else set(selected)
        items = self.ui.valuesListWidget
        items.blockSignals(True)
        items.clear()
        for value in values:
            item = QListWidgetItem(value or self.property("blankText"), items)
            item.setData(Qt.UserRole, value)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if value in selected else Qt.Unchecked)
        items.blockSignals(False)
        self._search_changed(self.ui.searchLineEdit.text())

    def set_selected_values(self, selected):
        selected = set(selected)
        items = self.ui.valuesListWidget
        items.blockSignals(True)
        for index in range(items.count()):
            item = items.item(index)
            item.setCheckState(Qt.Checked if item.data(Qt.UserRole) in selected else Qt.Unchecked)
        items.blockSignals(False)
        self._item_changed()

    def _search_changed(self, text):
        text = text.casefold()
        items = self.ui.valuesListWidget
        for index in range(items.count()):
            item = items.item(index)
            item.setHidden(text not in item.text().casefold())
        self._sync_select_all()

    def _select_visible(self, checked):
        items = self.ui.valuesListWidget
        items.blockSignals(True)
        for index in range(items.count()):
            item = items.item(index)
            if not item.isHidden():
                item.setCheckState(Qt.Checked if checked else Qt.Unchecked)
        items.blockSignals(False)
        self._item_changed()

    def _sync_select_all(self):
        items = self.ui.valuesListWidget
        visible = [items.item(index) for index in range(items.count()) if not items.item(index).isHidden()]
        count = sum(item.checkState() == Qt.Checked for item in visible)
        state = Qt.Checked if visible and count == len(visible) else (Qt.PartiallyChecked if count else Qt.Unchecked)
        check = self.ui.selectAllCheckBox
        check.blockSignals(True)
        check.setCheckState(state)
        check.setEnabled(bool(visible))
        check.blockSignals(False)

    def _item_changed(self, *_args):
        self._sync_select_all()
        self.selection_changed.emit()


class TskRiskFilter(QWidget):
    selection_changed = Signal()
    sort_requested = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskRiskFilterForm()
        self.ui.setupUi(self)
        self.popup = TskRiskFilterPopup(self)
        self.values = []
        self.ui.filterButton.clicked.connect(self._show_popup)
        self.popup.selection_changed.connect(self._selection_changed)
        self.popup.sort_requested.connect(self.sort_requested)

    @property
    def selected_values(self):
        return self.popup.selected_values

    def set_values(self, label, values, *, reset=False):
        values = sorted({"" if value is None else str(value) for value in values}, key=natural_sort_key)
        previous = self.selected_values
        selected = None if reset or previous == set(self.values) else previous.intersection(values)
        self.values = values
        self.ui.fieldLabel.setText(label)
        self.ui.fieldLabel.setToolTip(label)
        self.popup.set_values(label, values, selected)
        self._update_text()

    def select_all(self):
        self.popup.set_selected_values(self.values)

    def _selection_changed(self):
        self._update_text()
        self.selection_changed.emit()

    def _update_text(self):
        selected = self.selected_values
        button = self.ui.filterButton
        if len(selected) == len(self.values):
            text = button.property("allText")
        elif not selected:
            text = button.property("noneText")
        else:
            text = button.property("selectionFormat").format(selected=len(selected), total=len(self.values))
        button.setText(text)

    def _show_popup(self):
        popup = self.popup
        popup.ui.searchLineEdit.clear()
        origin = self.ui.filterButton.mapToGlobal(QPoint(0, self.ui.filterButton.height()))
        screen = self.screen().availableGeometry()
        x = max(screen.left(), min(origin.x(), screen.right() - popup.width() + 1))
        y = origin.y()
        if y + popup.height() > screen.bottom() + 1:
            y = self.ui.filterButton.mapToGlobal(QPoint()).y() - popup.height()
        popup.move(x, max(screen.top(), y))
        popup.show()
        popup.ui.searchLineEdit.setFocus()
