# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_results_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QFormLayout, QFrame, QHBoxLayout, QHeaderView,
    QLabel, QPlainTextEdit, QPushButton, QScrollArea,
    QSizePolicy, QSpacerItem, QSpinBox, QTabWidget,
    QTableView, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget)

from excel_data_analysis.gui.tsk_combination_plot import (TskCombinationHeatmap, TskDifferencePlot)
from excel_data_analysis.gui.tsk_feature_panel import TskFeaturePanel
from excel_data_analysis.gui.tsk_joint_risk_panel import TskJointRiskPanel
from excel_data_analysis.gui.tsk_plot import (TskChainFitPlot, TskRiskPlot)

class Ui_TskResultsPanelForm(object):
    def setupUi(self, TskResultsPanelForm):
        if not TskResultsPanelForm.objectName():
            TskResultsPanelForm.setObjectName(u"TskResultsPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskResultsPanelForm.sizePolicy().hasHeightForWidth())
        TskResultsPanelForm.setSizePolicy(sizePolicy)
        self.panelLayout = QVBoxLayout(TskResultsPanelForm)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.selectionLayout = QHBoxLayout()
        self.selectionLayout.setObjectName(u"selectionLayout")
        self.groupLabel = QLabel(TskResultsPanelForm)
        self.groupLabel.setObjectName(u"groupLabel")

        self.selectionLayout.addWidget(self.groupLabel)

        self.groupComboBox = QComboBox(TskResultsPanelForm)
        self.groupComboBox.setObjectName(u"groupComboBox")
        self.groupComboBox.setEnabled(False)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.groupComboBox.sizePolicy().hasHeightForWidth())
        self.groupComboBox.setSizePolicy(sizePolicy1)
        self.groupComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.groupComboBox.setMinimumContentsLength(8)

        self.selectionLayout.addWidget(self.groupComboBox)

        self.exportButton = QPushButton(TskResultsPanelForm)
        self.exportButton.setObjectName(u"exportButton")
        self.exportButton.setEnabled(False)

        self.selectionLayout.addWidget(self.exportButton)


        self.panelLayout.addLayout(self.selectionLayout)

        self.summaryLabel = QLabel(TskResultsPanelForm)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)

        self.panelLayout.addWidget(self.summaryLabel)

        self.warningsLabel = QLabel(TskResultsPanelForm)
        self.warningsLabel.setObjectName(u"warningsLabel")
        self.warningsLabel.setVisible(False)
        self.warningsLabel.setWordWrap(True)
        self.warningsLabel.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.panelLayout.addWidget(self.warningsLabel)

        self.detailsTabWidget = QTabWidget(TskResultsPanelForm)
        self.detailsTabWidget.setObjectName(u"detailsTabWidget")
        self.riskTab = QWidget()
        self.riskTab.setObjectName(u"riskTab")
        self.riskLayout = QVBoxLayout(self.riskTab)
        self.riskLayout.setObjectName(u"riskLayout")
        self.riskLegendLabel = QLabel(self.riskTab)
        self.riskLegendLabel.setObjectName(u"riskLegendLabel")
        self.riskLegendLabel.setWordWrap(True)

        self.riskLayout.addWidget(self.riskLegendLabel)

        self.referenceLabel = QLabel(self.riskTab)
        self.referenceLabel.setObjectName(u"referenceLabel")
        self.referenceLabel.setWordWrap(True)
        self.referenceLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.riskLayout.addWidget(self.referenceLabel)

        self.riskNoExtrapolationCheckBox = QCheckBox(self.riskTab)
        self.riskNoExtrapolationCheckBox.setObjectName(u"riskNoExtrapolationCheckBox")
        self.riskNoExtrapolationCheckBox.setChecked(True)
        self.riskNoExtrapolationCheckBox.setEnabled(False)

        self.riskLayout.addWidget(self.riskNoExtrapolationCheckBox)

        self.riskCompletionHintLabel = QLabel(self.riskTab)
        self.riskCompletionHintLabel.setObjectName(u"riskCompletionHintLabel")
        self.riskCompletionHintLabel.setWordWrap(True)
        self.riskCompletionHintLabel.setVisible(False)

        self.riskLayout.addWidget(self.riskCompletionHintLabel)

        self.calculateFullCombinationButton = QPushButton(self.riskTab)
        self.calculateFullCombinationButton.setObjectName(u"calculateFullCombinationButton")
        self.calculateFullCombinationButton.setVisible(False)
        self.calculateFullCombinationButton.setEnabled(False)

        self.riskLayout.addWidget(self.calculateFullCombinationButton)

        self.riskSortLayout = QHBoxLayout()
        self.riskSortLayout.setObjectName(u"riskSortLayout")
        self.riskSortLabel = QLabel(self.riskTab)
        self.riskSortLabel.setObjectName(u"riskSortLabel")

        self.riskSortLayout.addWidget(self.riskSortLabel)

        self.riskSortFieldComboBox = QComboBox(self.riskTab)
        self.riskSortFieldComboBox.addItem("")
        self.riskSortFieldComboBox.addItem("")
        self.riskSortFieldComboBox.setObjectName(u"riskSortFieldComboBox")
        self.riskSortFieldComboBox.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.riskSortFieldComboBox.sizePolicy().hasHeightForWidth())
        self.riskSortFieldComboBox.setSizePolicy(sizePolicy1)
        self.riskSortFieldComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.riskSortFieldComboBox.setMinimumContentsLength(5)

        self.riskSortLayout.addWidget(self.riskSortFieldComboBox)

        self.riskSortDirectionComboBox = QComboBox(self.riskTab)
        self.riskSortDirectionComboBox.addItem("")
        self.riskSortDirectionComboBox.addItem("")
        self.riskSortDirectionComboBox.setObjectName(u"riskSortDirectionComboBox")
        self.riskSortDirectionComboBox.setEnabled(False)

        self.riskSortLayout.addWidget(self.riskSortDirectionComboBox)

        self.clearRiskFiltersButton = QPushButton(self.riskTab)
        self.clearRiskFiltersButton.setObjectName(u"clearRiskFiltersButton")
        self.clearRiskFiltersButton.setEnabled(False)

        self.riskSortLayout.addWidget(self.clearRiskFiltersButton)


        self.riskLayout.addLayout(self.riskSortLayout)

        self.riskFiltersScrollArea = QScrollArea(self.riskTab)
        self.riskFiltersScrollArea.setObjectName(u"riskFiltersScrollArea")
        self.riskFiltersScrollArea.setMinimumSize(QSize(0, 78))
        self.riskFiltersScrollArea.setMaximumSize(QSize(16777215, 78))
        self.riskFiltersScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.riskFiltersScrollArea.setWidgetResizable(True)
        self.riskFiltersScrollArea.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.riskFiltersScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.riskFiltersContents = QWidget()
        self.riskFiltersContents.setObjectName(u"riskFiltersContents")
        self.riskFiltersLayout = QHBoxLayout(self.riskFiltersContents)
        self.riskFiltersLayout.setObjectName(u"riskFiltersLayout")
        self.riskFiltersLayout.setContentsMargins(0, 0, 0, 0)
        self.riskFiltersSpacer = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.riskFiltersLayout.addItem(self.riskFiltersSpacer)

        self.riskFiltersScrollArea.setWidget(self.riskFiltersContents)

        self.riskLayout.addWidget(self.riskFiltersScrollArea)

        self.riskVisibleCountLabel = QLabel(self.riskTab)
        self.riskVisibleCountLabel.setObjectName(u"riskVisibleCountLabel")
        self.riskVisibleCountLabel.setWordWrap(True)

        self.riskLayout.addWidget(self.riskVisibleCountLabel)

        self.riskScrollArea = QScrollArea(self.riskTab)
        self.riskScrollArea.setObjectName(u"riskScrollArea")
        self.riskScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.riskScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.riskScrollArea.setWidgetResizable(True)
        self.riskPlot = TskRiskPlot()
        self.riskPlot.setObjectName(u"riskPlot")
        self.riskPlot.setProperty(u"virtualRows", True)
        self.riskPlot.setProperty(u"virtualCanvasMaximumHeight", 16777215)
        self.riskPlot.setProperty(u"confidenceLevel", 0.950000000000000)
        self.riskPlot.setProperty(u"multilineLabelWidthPadding", 12)
        self.riskPlot.setProperty(u"multilineLabelMaxWidth", 260)
        self.riskPlot.setProperty(u"multilineLabelWidthRatio", 0.380000000000000)
        self.riskPlot.setProperty(u"multilineLabelPadding", 14)
        self.riskPlot.setProperty(u"minimumRowHeight", 50)
        self.riskPlot.setMinimumSize(QSize(0, 190))
        sizePolicy.setHeightForWidth(self.riskPlot.sizePolicy().hasHeightForWidth())
        self.riskPlot.setSizePolicy(sizePolicy)
        self.riskScrollArea.setWidget(self.riskPlot)

        self.riskLayout.addWidget(self.riskScrollArea)

        self.detailsTabWidget.addTab(self.riskTab, "")
        self.chainFitTab = QWidget()
        self.chainFitTab.setObjectName(u"chainFitTab")
        self.chainFitLayout = QVBoxLayout(self.chainFitTab)
        self.chainFitLayout.setObjectName(u"chainFitLayout")
        self.chainLegendLabel = QLabel(self.chainFitTab)
        self.chainLegendLabel.setObjectName(u"chainLegendLabel")
        self.chainLegendLabel.setWordWrap(True)

        self.chainFitLayout.addWidget(self.chainLegendLabel)

        self.chainPlot = TskChainFitPlot(self.chainFitTab)
        self.chainPlot.setObjectName(u"chainPlot")
        self.chainPlot.setMinimumSize(QSize(0, 210))
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.chainPlot.sizePolicy().hasHeightForWidth())
        self.chainPlot.setSizePolicy(sizePolicy2)

        self.chainFitLayout.addWidget(self.chainPlot)

        self.chainsTableView = QTableView(self.chainFitTab)
        self.chainsTableView.setObjectName(u"chainsTableView")
        self.chainsTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.chainsTableView.setAlternatingRowColors(True)
        self.chainsTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.chainsTableView.setSortingEnabled(True)

        self.chainFitLayout.addWidget(self.chainsTableView)

        self.chainFitLayout.setStretch(1, 3)
        self.chainFitLayout.setStretch(2, 2)
        self.detailsTabWidget.addTab(self.chainFitTab, "")
        self.riskDetailsTab = QWidget()
        self.riskDetailsTab.setObjectName(u"riskDetailsTab")
        self.riskDetailsLayout = QVBoxLayout(self.riskDetailsTab)
        self.riskDetailsLayout.setObjectName(u"riskDetailsLayout")
        self.riskDetailsConditionsLabel = QLabel(self.riskDetailsTab)
        self.riskDetailsConditionsLabel.setObjectName(u"riskDetailsConditionsLabel")
        self.riskDetailsConditionsLabel.setWordWrap(True)

        self.riskDetailsLayout.addWidget(self.riskDetailsConditionsLabel)

        self.typesTableView = QTableView(self.riskDetailsTab)
        self.typesTableView.setObjectName(u"typesTableView")
        self.typesTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.typesTableView.setAlternatingRowColors(True)
        self.typesTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.typesTableView.setSortingEnabled(True)

        self.riskDetailsLayout.addWidget(self.typesTableView)

        self.detailsTabWidget.addTab(self.riskDetailsTab, "")
        self.featureTab = QWidget()
        self.featureTab.setObjectName(u"featureTab")
        self.featureLayout = QVBoxLayout(self.featureTab)
        self.featureLayout.setObjectName(u"featureLayout")
        self.featurePanel = TskFeaturePanel(self.featureTab)
        self.featurePanel.setObjectName(u"featurePanel")

        self.featureLayout.addWidget(self.featurePanel)

        self.detailsTabWidget.addTab(self.featureTab, "")
        self.jointRiskTab = QWidget()
        self.jointRiskTab.setObjectName(u"jointRiskTab")
        self.jointRiskLayout = QVBoxLayout(self.jointRiskTab)
        self.jointRiskLayout.setObjectName(u"jointRiskLayout")
        self.jointRiskPanel = TskJointRiskPanel(self.jointRiskTab)
        self.jointRiskPanel.setObjectName(u"jointRiskPanel")

        self.jointRiskLayout.addWidget(self.jointRiskPanel)

        self.detailsTabWidget.addTab(self.jointRiskTab, "")
        self.combinationTab = QWidget()
        self.combinationTab.setObjectName(u"combinationTab")
        self.combinationLayout = QVBoxLayout(self.combinationTab)
        self.combinationLayout.setObjectName(u"combinationLayout")
        self.combinationConditionsLabel = QLabel(self.combinationTab)
        self.combinationConditionsLabel.setObjectName(u"combinationConditionsLabel")
        self.combinationConditionsLabel.setMaximumSize(QSize(16777215, 48))
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.combinationConditionsLabel.sizePolicy().hasHeightForWidth())
        self.combinationConditionsLabel.setSizePolicy(sizePolicy3)
        self.combinationConditionsLabel.setWordWrap(True)
        self.combinationConditionsLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.combinationLayout.addWidget(self.combinationConditionsLabel)

        self.combinationWarningsLabel = QLabel(self.combinationTab)
        self.combinationWarningsLabel.setObjectName(u"combinationWarningsLabel")
        self.combinationWarningsLabel.setVisible(False)
        self.combinationWarningsLabel.setWordWrap(True)
        self.combinationWarningsLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.combinationLayout.addWidget(self.combinationWarningsLabel)

        self.combinationViewsTabWidget = QTabWidget(self.combinationTab)
        self.combinationViewsTabWidget.setObjectName(u"combinationViewsTabWidget")
        self.combinationViewsTabWidget.setMinimumSize(QSize(0, 360))
        self.combinationHeatmapTab = QWidget()
        self.combinationHeatmapTab.setObjectName(u"combinationHeatmapTab")
        self.combinationHeatmapLayout = QVBoxLayout(self.combinationHeatmapTab)
        self.combinationHeatmapLayout.setObjectName(u"combinationHeatmapLayout")
        self.combinationHeatmapMetricComboBox = QComboBox(self.combinationHeatmapTab)
        self.combinationHeatmapMetricComboBox.addItem("")
        self.combinationHeatmapMetricComboBox.addItem("")
        self.combinationHeatmapMetricComboBox.setObjectName(u"combinationHeatmapMetricComboBox")

        self.combinationHeatmapLayout.addWidget(self.combinationHeatmapMetricComboBox)

        self.combinationHeatmapLegendLabel = QLabel(self.combinationHeatmapTab)
        self.combinationHeatmapLegendLabel.setObjectName(u"combinationHeatmapLegendLabel")
        self.combinationHeatmapLegendLabel.setWordWrap(True)

        self.combinationHeatmapLayout.addWidget(self.combinationHeatmapLegendLabel)

        self.heatmapPageControls = QWidget(self.combinationHeatmapTab)
        self.heatmapPageControls.setObjectName(u"heatmapPageControls")
        self.heatmapPageControls.setVisible(False)
        self.heatmapPageLayout = QHBoxLayout(self.heatmapPageControls)
        self.heatmapPageLayout.setObjectName(u"heatmapPageLayout")
        self.heatmapPageLayout.setContentsMargins(0, 0, 0, 0)
        self.heatmapPageLabel = QLabel(self.heatmapPageControls)
        self.heatmapPageLabel.setObjectName(u"heatmapPageLabel")
        self.heatmapPageLabel.setProperty(u"pageSize", 25)
        self.heatmapPageLabel.setWordWrap(True)

        self.heatmapPageLayout.addWidget(self.heatmapPageLabel)

        self.heatmapPageSpinBox = QSpinBox(self.heatmapPageControls)
        self.heatmapPageSpinBox.setObjectName(u"heatmapPageSpinBox")
        self.heatmapPageSpinBox.setMinimum(1)
        self.heatmapPageSpinBox.setMaximum(1)

        self.heatmapPageLayout.addWidget(self.heatmapPageSpinBox)


        self.combinationHeatmapLayout.addWidget(self.heatmapPageControls)

        self.combinationHeatmapScrollArea = QScrollArea(self.combinationHeatmapTab)
        self.combinationHeatmapScrollArea.setObjectName(u"combinationHeatmapScrollArea")
        self.combinationHeatmapScrollArea.setMinimumSize(QSize(0, 300))
        self.combinationHeatmapScrollArea.setWidgetResizable(True)
        self.combinationHeatmapScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.combinationHeatmap = TskCombinationHeatmap()
        self.combinationHeatmap.setObjectName(u"combinationHeatmap")
        self.combinationHeatmap.setProperty(u"headerHorizontalPadding", 6)
        self.combinationHeatmap.setProperty(u"headerVerticalPadding", 8)
        self.combinationHeatmap.setProperty(u"minimumHeaderHeight", 37)
        self.combinationHeatmap.setProperty(u"typeLabelWidth", 110)
        self.combinationHeatmap.setProperty(u"minimumCellWidth", 86)
        self.combinationHeatmap.setProperty(u"cellRowHeight", 42)
        self.combinationHeatmap.setProperty(u"rightPadding", 8)
        self.combinationHeatmap.setProperty(u"bottomPadding", 25)
        self.combinationHeatmap.setProperty(u"minimumCanvasHeight", 160)
        self.combinationHeatmap.setMinimumSize(QSize(0, 160))
        self.combinationHeatmapScrollArea.setWidget(self.combinationHeatmap)

        self.combinationHeatmapLayout.addWidget(self.combinationHeatmapScrollArea)

        self.combinationViewsTabWidget.addTab(self.combinationHeatmapTab, "")
        self.combinationCompareTab = QWidget()
        self.combinationCompareTab.setObjectName(u"combinationCompareTab")
        self.combinationCompareLayout = QVBoxLayout(self.combinationCompareTab)
        self.combinationCompareLayout.setObjectName(u"combinationCompareLayout")
        self.combinationCompareTypeComboBox = QComboBox(self.combinationCompareTab)
        self.combinationCompareTypeComboBox.setObjectName(u"combinationCompareTypeComboBox")
        self.combinationCompareTypeComboBox.setEnabled(False)

        self.combinationCompareLayout.addWidget(self.combinationCompareTypeComboBox)

        self.combinationCompareLegendLabel = QLabel(self.combinationCompareTab)
        self.combinationCompareLegendLabel.setObjectName(u"combinationCompareLegendLabel")
        self.combinationCompareLegendLabel.setWordWrap(True)

        self.combinationCompareLayout.addWidget(self.combinationCompareLegendLabel)

        self.comparePageControls = QWidget(self.combinationCompareTab)
        self.comparePageControls.setObjectName(u"comparePageControls")
        self.comparePageControls.setVisible(False)
        self.comparePageLayout = QHBoxLayout(self.comparePageControls)
        self.comparePageLayout.setObjectName(u"comparePageLayout")
        self.comparePageLayout.setContentsMargins(0, 0, 0, 0)
        self.comparePageLabel = QLabel(self.comparePageControls)
        self.comparePageLabel.setObjectName(u"comparePageLabel")
        self.comparePageLabel.setProperty(u"pageSize", 100)
        self.comparePageLabel.setWordWrap(True)

        self.comparePageLayout.addWidget(self.comparePageLabel)

        self.comparePageSpinBox = QSpinBox(self.comparePageControls)
        self.comparePageSpinBox.setObjectName(u"comparePageSpinBox")
        self.comparePageSpinBox.setMinimum(1)
        self.comparePageSpinBox.setMaximum(1)

        self.comparePageLayout.addWidget(self.comparePageSpinBox)


        self.combinationCompareLayout.addWidget(self.comparePageControls)

        self.combinationCompareScrollArea = QScrollArea(self.combinationCompareTab)
        self.combinationCompareScrollArea.setObjectName(u"combinationCompareScrollArea")
        self.combinationCompareScrollArea.setMinimumSize(QSize(0, 300))
        self.combinationCompareScrollArea.setWidgetResizable(True)
        self.combinationCompareScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.combinationCompareScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.combinationCompareContents = QWidget()
        self.combinationCompareContents.setObjectName(u"combinationCompareContents")
        self.combinationCompareContentsLayout = QVBoxLayout(self.combinationCompareContents)
        self.combinationCompareContentsLayout.setObjectName(u"combinationCompareContentsLayout")
        self.combinationProbabilityPlot = TskRiskPlot(self.combinationCompareContents)
        self.combinationProbabilityPlot.setObjectName(u"combinationProbabilityPlot")
        self.combinationProbabilityPlot.setProperty(u"multilineLabelWidthPadding", 12)
        self.combinationProbabilityPlot.setProperty(u"multilineLabelMaxWidth", 260)
        self.combinationProbabilityPlot.setProperty(u"multilineLabelWidthRatio", 0.380000000000000)
        self.combinationProbabilityPlot.setProperty(u"multilineLabelPadding", 14)
        self.combinationProbabilityPlot.setProperty(u"minimumRowHeight", 50)
        self.combinationProbabilityPlot.setMinimumSize(QSize(0, 190))

        self.combinationCompareContentsLayout.addWidget(self.combinationProbabilityPlot)

        self.combinationDifferencePlot = TskDifferencePlot(self.combinationCompareContents)
        self.combinationDifferencePlot.setObjectName(u"combinationDifferencePlot")
        self.combinationDifferencePlot.setProperty(u"multilineLabelWidthPadding", 12)
        self.combinationDifferencePlot.setProperty(u"multilineLabelMaxWidth", 260)
        self.combinationDifferencePlot.setProperty(u"multilineLabelWidthRatio", 0.380000000000000)
        self.combinationDifferencePlot.setProperty(u"multilineLabelPadding", 14)
        self.combinationDifferencePlot.setProperty(u"minimumRowHeight", 50)
        self.combinationDifferencePlot.setMinimumSize(QSize(0, 190))

        self.combinationCompareContentsLayout.addWidget(self.combinationDifferencePlot)

        self.combinationCompareScrollArea.setWidget(self.combinationCompareContents)

        self.combinationCompareLayout.addWidget(self.combinationCompareScrollArea)

        self.combinationViewsTabWidget.addTab(self.combinationCompareTab, "")
        self.combinationDetailsTab = QWidget()
        self.combinationDetailsTab.setObjectName(u"combinationDetailsTab")
        self.combinationDetailsLayout = QVBoxLayout(self.combinationDetailsTab)
        self.combinationDetailsLayout.setObjectName(u"combinationDetailsLayout")
        self.combinationTableView = QTableView(self.combinationDetailsTab)
        self.combinationTableView.setObjectName(u"combinationTableView")
        self.combinationTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.combinationTableView.setAlternatingRowColors(True)
        self.combinationTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.combinationTableView.setSortingEnabled(True)

        self.combinationDetailsLayout.addWidget(self.combinationTableView)

        self.combinationViewsTabWidget.addTab(self.combinationDetailsTab, "")
        self.combinationSettingsTab = QWidget()
        self.combinationSettingsTab.setObjectName(u"combinationSettingsTab")
        self.combinationSettingsLayout = QVBoxLayout(self.combinationSettingsTab)
        self.combinationSettingsLayout.setObjectName(u"combinationSettingsLayout")
        self.combinationSettingsScrollArea = QScrollArea(self.combinationSettingsTab)
        self.combinationSettingsScrollArea.setObjectName(u"combinationSettingsScrollArea")
        self.combinationSettingsScrollArea.setWidgetResizable(True)
        self.combinationSettingsScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.combinationSettingsScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.combinationSettingsContents = QWidget()
        self.combinationSettingsContents.setObjectName(u"combinationSettingsContents")
        self.combinationSettingsContentsLayout = QVBoxLayout(self.combinationSettingsContents)
        self.combinationSettingsContentsLayout.setObjectName(u"combinationSettingsContentsLayout")
        self.combinationHintLabel = QLabel(self.combinationSettingsContents)
        self.combinationHintLabel.setObjectName(u"combinationHintLabel")
        self.combinationHintLabel.setWordWrap(True)

        self.combinationSettingsContentsLayout.addWidget(self.combinationHintLabel)

        self.combinationControlsLayout = QFormLayout()
        self.combinationControlsLayout.setObjectName(u"combinationControlsLayout")
        self.combinationControlsLayout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.combinationDimensionLabel = QLabel(self.combinationSettingsContents)
        self.combinationDimensionLabel.setObjectName(u"combinationDimensionLabel")

        self.combinationControlsLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.combinationDimensionLabel)

        self.combinationDimensionComboBox = QComboBox(self.combinationSettingsContents)
        self.combinationDimensionComboBox.setObjectName(u"combinationDimensionComboBox")
        self.combinationDimensionComboBox.setEnabled(False)
        self.combinationDimensionComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combinationDimensionComboBox.setMinimumContentsLength(8)

        self.combinationControlsLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.combinationDimensionComboBox)

        self.combinationTypeLabel = QLabel(self.combinationSettingsContents)
        self.combinationTypeLabel.setObjectName(u"combinationTypeLabel")

        self.combinationControlsLayout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.combinationTypeLabel)

        self.combinationTypeComboBox = QComboBox(self.combinationSettingsContents)
        self.combinationTypeComboBox.setObjectName(u"combinationTypeComboBox")
        self.combinationTypeComboBox.setEnabled(False)
        self.combinationTypeComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combinationTypeComboBox.setMinimumContentsLength(8)

        self.combinationControlsLayout.setWidget(1, QFormLayout.ItemRole.FieldRole, self.combinationTypeComboBox)

        self.combinationReferenceLabel = QLabel(self.combinationSettingsContents)
        self.combinationReferenceLabel.setObjectName(u"combinationReferenceLabel")

        self.combinationControlsLayout.setWidget(2, QFormLayout.ItemRole.LabelRole, self.combinationReferenceLabel)

        self.combinationReferenceComboBox = QComboBox(self.combinationSettingsContents)
        self.combinationReferenceComboBox.setObjectName(u"combinationReferenceComboBox")
        self.combinationReferenceComboBox.setMaxVisibleItems(20)
        self.combinationReferenceComboBox.setEnabled(False)
        self.combinationReferenceComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combinationReferenceComboBox.setMinimumContentsLength(8)

        self.combinationControlsLayout.setWidget(2, QFormLayout.ItemRole.FieldRole, self.combinationReferenceComboBox)


        self.combinationSettingsContentsLayout.addLayout(self.combinationControlsLayout)

        self.combinationNoExtrapolationCheckBox = QCheckBox(self.combinationSettingsContents)
        self.combinationNoExtrapolationCheckBox.setObjectName(u"combinationNoExtrapolationCheckBox")
        self.combinationNoExtrapolationCheckBox.setChecked(True)
        self.combinationNoExtrapolationCheckBox.setEnabled(False)

        self.combinationSettingsContentsLayout.addWidget(self.combinationNoExtrapolationCheckBox)

        self.combinationFixedTableWidget = QTableWidget(self.combinationSettingsContents)
        if (self.combinationFixedTableWidget.columnCount() < 2):
            self.combinationFixedTableWidget.setColumnCount(2)
        __qtablewidgetitem = QTableWidgetItem()
        self.combinationFixedTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.combinationFixedTableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        self.combinationFixedTableWidget.setObjectName(u"combinationFixedTableWidget")
        self.combinationFixedTableWidget.setEnabled(False)
        self.combinationFixedTableWidget.setMaximumSize(QSize(16777215, 112))
        self.combinationFixedTableWidget.setMinimumSize(QSize(0, 65))
        self.combinationFixedTableWidget.setAlternatingRowColors(True)
        self.combinationFixedTableWidget.setColumnCount(2)
        self.combinationFixedTableWidget.horizontalHeader().setStretchLastSection(True)
        self.combinationFixedTableWidget.verticalHeader().setVisible(False)

        self.combinationSettingsContentsLayout.addWidget(self.combinationFixedTableWidget)

        self.combinationActionLayout = QHBoxLayout()
        self.combinationActionLayout.setObjectName(u"combinationActionLayout")
        self.combinationStatusLabel = QLabel(self.combinationSettingsContents)
        self.combinationStatusLabel.setObjectName(u"combinationStatusLabel")
        self.combinationStatusLabel.setWordWrap(True)
        self.combinationStatusLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.combinationActionLayout.addWidget(self.combinationStatusLabel)

        self.calculateCombinationButton = QPushButton(self.combinationSettingsContents)
        self.calculateCombinationButton.setObjectName(u"calculateCombinationButton")
        self.calculateCombinationButton.setEnabled(False)

        self.combinationActionLayout.addWidget(self.calculateCombinationButton)


        self.combinationSettingsContentsLayout.addLayout(self.combinationActionLayout)

        self.combinationSettingsBottomSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.combinationSettingsContentsLayout.addItem(self.combinationSettingsBottomSpacer)

        self.combinationSettingsScrollArea.setWidget(self.combinationSettingsContents)

        self.combinationSettingsLayout.addWidget(self.combinationSettingsScrollArea)

        self.combinationViewsTabWidget.addTab(self.combinationSettingsTab, "")
        self.combinationWarningsTab = QWidget()
        self.combinationWarningsTab.setObjectName(u"combinationWarningsTab")
        self.combinationWarningsLayout = QVBoxLayout(self.combinationWarningsTab)
        self.combinationWarningsLayout.setObjectName(u"combinationWarningsLayout")
        self.diagnosticsActionsLayout = QHBoxLayout()
        self.diagnosticsActionsLayout.setObjectName(u"diagnosticsActionsLayout")
        self.copyDiagnosticsButton = QPushButton(self.combinationWarningsTab)
        self.copyDiagnosticsButton.setObjectName(u"copyDiagnosticsButton")
        self.copyDiagnosticsButton.setEnabled(False)

        self.diagnosticsActionsLayout.addWidget(self.copyDiagnosticsButton)

        self.saveDiagnosticsButton = QPushButton(self.combinationWarningsTab)
        self.saveDiagnosticsButton.setObjectName(u"saveDiagnosticsButton")
        self.saveDiagnosticsButton.setEnabled(False)

        self.diagnosticsActionsLayout.addWidget(self.saveDiagnosticsButton)

        self.diagnosticsActionsSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.diagnosticsActionsLayout.addItem(self.diagnosticsActionsSpacer)


        self.combinationWarningsLayout.addLayout(self.diagnosticsActionsLayout)

        self.diagnosticsActionStatusLabel = QLabel(self.combinationWarningsTab)
        self.diagnosticsActionStatusLabel.setObjectName(u"diagnosticsActionStatusLabel")
        self.diagnosticsActionStatusLabel.setVisible(False)
        self.diagnosticsActionStatusLabel.setWordWrap(True)
        self.diagnosticsActionStatusLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.combinationWarningsLayout.addWidget(self.diagnosticsActionStatusLabel)

        self.combinationWarningsTextEdit = QPlainTextEdit(self.combinationWarningsTab)
        self.combinationWarningsTextEdit.setObjectName(u"combinationWarningsTextEdit")
        self.combinationWarningsTextEdit.setReadOnly(True)

        self.combinationWarningsLayout.addWidget(self.combinationWarningsTextEdit)

        self.combinationViewsTabWidget.addTab(self.combinationWarningsTab, "")

        self.combinationLayout.addWidget(self.combinationViewsTabWidget)

        self.detailsTabWidget.addTab(self.combinationTab, "")
        self.topologyTab = QWidget()
        self.topologyTab.setObjectName(u"topologyTab")
        self.topologyLayout = QVBoxLayout(self.topologyTab)
        self.topologyLayout.setObjectName(u"topologyLayout")
        self.topologyHintLabel = QLabel(self.topologyTab)
        self.topologyHintLabel.setObjectName(u"topologyHintLabel")
        self.topologyHintLabel.setWordWrap(True)

        self.topologyLayout.addWidget(self.topologyHintLabel)

        self.topologyTableView = QTableView(self.topologyTab)
        self.topologyTableView.setObjectName(u"topologyTableView")
        self.topologyTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.topologyTableView.setAlternatingRowColors(True)
        self.topologyTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.topologyTableView.setSortingEnabled(True)

        self.topologyLayout.addWidget(self.topologyTableView)

        self.detailsTabWidget.addTab(self.topologyTab, "")

        self.panelLayout.addWidget(self.detailsTabWidget)

#if QT_CONFIG(shortcut)
        self.groupLabel.setBuddy(self.groupComboBox)
        self.riskSortLabel.setBuddy(self.riskSortFieldComboBox)
        self.combinationDimensionLabel.setBuddy(self.combinationDimensionComboBox)
        self.combinationTypeLabel.setBuddy(self.combinationTypeComboBox)
        self.combinationReferenceLabel.setBuddy(self.combinationReferenceComboBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskResultsPanelForm)

        self.detailsTabWidget.setCurrentIndex(0)
        self.combinationViewsTabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(TskResultsPanelForm)
    # setupUi

    def retranslateUi(self, TskResultsPanelForm):
        self.groupLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8282\u70b9 / \u6279\u6b21", None))
        self.exportButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5bfc\u51fa XLSX", None))
        self.summaryLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.summaryLabel.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.summaryLabel.setProperty(u"modelSummaryFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u6a21\u578b\uff1a{model}{details}", None))
        self.summaryLabel.setProperty(u"logisticModelText", QCoreApplication.translate("TskResultsPanelForm", u"Logistic\uff08\u539f\u6709\uff09", None))
        self.summaryLabel.setProperty(u"linearHazardModelText", QCoreApplication.translate("TskResultsPanelForm", u"\u7ebf\u6027\u98ce\u9669\uff08\u51f8\uff09", None))
        self.summaryLabel.setProperty(u"typeOnlyModelSuffix", QCoreApplication.translate("TskResultsPanelForm", u" \u00b7 \u672a\u4f7f\u7528\u7279\u5f81\uff0c\u91c7\u7528\u57fa\u7840\u7c7b\u578b\u6a21\u578b", None))
        self.warningsLabel.setText("")
        self.warningsLabel.setProperty(u"summaryText", QCoreApplication.translate("TskResultsPanelForm", u"{count} \u6761\u5206\u6790\u63d0\u793a\uff1b\u60ac\u505c\u67e5\u770b\uff0c\u6216\u6253\u5f00\u201c\u7ec4\u5408\u5206\u6790 \u2192 \u5168\u90e8\u63d0\u793a\u201d\u3002", None))
        self.riskLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6761\u5f62\uff1a\u5355\u5b9e\u4f8b P_fail \u00b7 \u8bef\u5dee\u7ebf\uff1a95% \u7f6e\u4fe1\u533a\u95f4\u3002\n"
"\u96f6\u8fb9\u754c\u7ebf\u4ece 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u4e0d\u662f \u00b1 \u6807\u51c6\u5dee\uff1b\u201c\u8fd1\u4f3c\u201d\u8868\u793a\u8fd1\u4f3c\u533a\u95f4\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002\u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002", None))
        self.riskLegendLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u6761\u5f62\uff1a\u5355\u5b9e\u4f8b P_fail \u00b7 \u8bef\u5dee\u7ebf\uff1a{confidence} \u7f6e\u4fe1\u533a\u95f4\u3002\n"
"\u96f6\u8fb9\u754c\u7ebf\u4ece 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u4e0d\u662f \u00b1 \u6807\u51c6\u5dee\uff1b\u201c\u8fd1\u4f3c\u201d\u8868\u793a\u8fd1\u4f3c\u533a\u95f4\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002\u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002", None))
        self.referenceLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u53ef\u663e\u793a\u7684\u62df\u5408\u7ed3\u679c\u3002", None))
        self.referenceLabel.setProperty(u"typeOnlyText", QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u578b\u6a21\u578b\uff1a\u540c\u4e00 TSK_ID \u7684\u5404\u5b9e\u4f8b\u5171\u4eab\u5f02\u5e38\u6982\u7387\u3002", None))
        self.referenceLabel.setProperty(u"featureText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u56fa\u5b9a\u6240\u6709\u6570\u503c\u7279\u5f81\u5728\u8be5\u7ec4\u8bad\u7ec3\u5747\u503c\uff0c\u6bd4\u8f83 TSK \u6761\u4ef6\u6982\u7387\u3002", None))
        self.referenceLabel.setProperty(u"categoricalText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u6570\u503c\u7279\u5f81\u53d6\u8bad\u7ec3\u5747\u503c\uff0c\u7c7b\u522b\u53d6 {categories}\uff0c\u6bd4\u8f83 TSK \u6761\u4ef6\u6982\u7387\uff1b\u4e0d\u662f\u6240\u6709\u5b9e\u4f8b\u7684\u5e73\u5747\u98ce\u9669\u3002", None))
        self.referenceLabel.setProperty(u"allCombinationsText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c55\u793a\u5168\u90e8\u7c7b\u522b\u7ec4\u5408\uff08{dimensions}\uff09\uff0c\u6bcf\u6839\u67f1\u5bf9\u5e94 TSK_ID \u4e0e\u7c7b\u522b\u7ec4\u5408\u3002XY \u548c\u5176\u4ed6\u6570\u503c\u7279\u5f81\u4ec5\u56fa\u5b9a\u5728\u8bad\u7ec3\u5747\u503c\uff0c\u4e0d\u53c2\u4e0e\u7ec4\u5408\u5c55\u5f00\u3002{missing}", None))
        self.referenceLabel.setProperty(u"noExtrapolationText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\u7684\u7ec4\u5408\u7559\u7a7a\uff0c\u4e0d\u5916\u63a8\u3002", None))
        self.referenceLabel.setProperty(u"extrapolationText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\u7684\u7ec4\u5408\u5141\u8bb8\u6a21\u578b\u5916\u63a8\u3002", None))
        self.referenceLabel.setProperty(u"allCombinationsPendingText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8\u7c7b\u522b\u7ec4\u5408\u5c1a\u672a\u8ba1\u7b97\uff1b\u9996\u9875\u4e0e\u98ce\u9669\u660e\u7ec6\u7b49\u5f85\u5b8c\u6574\u7ec4\u5408\u7ed3\u679c\uff0c\u4e0d\u663e\u793a\u5355\u4e00\u57fa\u51c6\u6216\u5c40\u90e8\u5207\u7247\u3002", None))
        self.referenceLabel.setProperty(u"categoricalNoFitText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u6570\u503c\u7279\u5f81\u53d6\u8bad\u7ec3\u5747\u503c\u3001\u7c7b\u522b\u7279\u5f81\u53d6\u57fa\u51c6\u7c7b\u522b\uff1b\u672c\u7ec4\u5c1a\u65e0\u53ef\u7528\u62df\u5408\u7ed3\u679c\u3002", None))
        self.riskNoExtrapolationCheckBox.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6570\u636e\u7ec4\u5408\u7559\u7a7a\uff08\u4e0d\u5916\u63a8\uff09", None))
#if QT_CONFIG(tooltip)
        self.riskNoExtrapolationCheckBox.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u5207\u6362\u540e\u91cd\u65b0\u8ba1\u7b97\u9996\u9875\u548c\u98ce\u9669\u660e\u7ec6\u7684\u5168\u90e8\u7c7b\u522b\u7ec4\u5408\uff1b\u4ec5\u6709\u5b9e\u9645\u6709\u6548\u6570\u636e\u652f\u6301\u7684\u7ec4\u5408\u4fdd\u7559\u4f30\u8ba1\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.riskCompletionHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5f53\u524d\u7ec4\u5c1a\u672a\u8ba1\u7b97\u5b8c\u6574\u7c7b\u522b\u7ec4\u5408\u3002\u53ef\u5728\u6b64\u70b9\u51fb\u201c\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\u201d\uff0c\u6216\u8fdb\u5165\u201c\u7ec4\u5408\u5206\u6790 \u2192 \u8ba1\u7b97\u6761\u4ef6\u201d\u9009\u62e9\u8303\u56f4\u540e\u70b9\u51fb\u201c\u8ba1\u7b97\u7ec4\u5408\u6982\u7387\u201d\u3002", None))
        self.calculateFullCombinationButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408", None))
        self.riskSortLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6392\u5e8f", None))
        self.riskSortFieldComboBox.setItemText(0, QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None))
        self.riskSortFieldComboBox.setItemText(1, QCoreApplication.translate("TskResultsPanelForm", u"\u5931\u6548\u6982\u7387", None))

        self.riskSortFieldComboBox.setProperty(u"tskText", QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None))
        self.riskSortFieldComboBox.setProperty(u"probabilityText", QCoreApplication.translate("TskResultsPanelForm", u"\u5931\u6548\u6982\u7387", None))
        self.riskSortDirectionComboBox.setItemText(0, QCoreApplication.translate("TskResultsPanelForm", u"\u5347\u5e8f \u2191", None))
        self.riskSortDirectionComboBox.setItemText(1, QCoreApplication.translate("TskResultsPanelForm", u"\u964d\u5e8f \u2193", None))

#if QT_CONFIG(tooltip)
        self.riskSortDirectionComboBox.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u98ce\u9669\u56fe\u6309\u6240\u9009\u5b57\u6bb5\u6392\u5e8f\uff1b\u98ce\u9669\u660e\u7ec6\u53ef\u70b9\u51fb\u8868\u5934\u5355\u72ec\u6392\u5e8f\u3002TSK \u7f16\u53f7\u53ca\u7c7b\u522b\u6309\u81ea\u7136\u987a\u5e8f\u6392\u5217\uff1b\u6982\u7387\u964d\u5e8f\u4ece\u9ad8\u5230\u4f4e\uff0c\u65e0\u4f30\u8ba1\u503c\u59cb\u7ec8\u6392\u5728\u672b\u5c3e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.clearRiskFiltersButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6e05\u9664\u7b5b\u9009", None))
        self.riskVisibleCountLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u663e\u793a 0 / 0 \u9879", None))
        self.riskVisibleCountLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u663e\u793a {visible} / {total} \u9879 \u00b7 \u7b5b\u9009\u540c\u6b65\u5230\u98ce\u9669\u660e\u7ec6", None))
        self.riskVisibleCountLabel.setProperty(u"noMatchesText", QCoreApplication.translate("TskResultsPanelForm", u"\u5f53\u524d\u7b5b\u9009\u6ca1\u6709\u5339\u914d\u9879\uff1b\u53ef\u70b9\u51fb\u201c\u6e05\u9664\u7b5b\u9009\u201d\u3002", None))
        self.riskPlot.setProperty(u"supportFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u652f\u6301\u94fe\u6570\uff1a{chains}\uff1b\u94fe\u6d4b\u8bd5\u66b4\u9732\uff1a{exposure}\uff08\u4e0d\u662f\u72ec\u7acb\u6837\u672c\u91cf\uff09", None))
        self.riskPlot.setProperty(u"intervalMethodFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u65b9\u6cd5\uff1a{method}", None))
        self.riskPlot.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.riskPlot.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bef\u5dee\u6761\u4e3a 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u5e76\u975e \u00b1 \u6807\u51c6\u5dee\uff1b\u4e0a\u9650\u5bbd\u8868\u793a\u6570\u636e\u5c1a\u4e0d\u80fd\u6392\u9664\u8f83\u5927\u98ce\u9669\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002", None))
        self.riskPlot.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.riskPlot.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.riskPlot.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.riskPlot.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.riskPlot.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.riskPlot.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.riskPlot.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.riskPlot.setProperty(u"combinationLabelFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id}\n"
"{categories}", None))
        self.riskPlot.setProperty(u"categoryLineFormat", QCoreApplication.translate("TskResultsPanelForm", u"{name}={value}", None))
        self.riskPlot.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"P_fail(TSK_ID)\uff08%\uff09", None))
        self.riskPlot.setProperty(u"typeAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"P_fail(TSK_ID)\uff08%\uff09", None))
        self.riskPlot.setProperty(u"combinationAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"TSK \u4e0e\u7c7b\u522b\u7ec4\u5408\u6761\u4ef6 P_fail\uff08%\uff09", None))
        self.riskPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a TSK \u6982\u7387\u4e0e\u533a\u95f4\u3002", None))
        self.riskPlot.setProperty(u"outsideDomainText", QCoreApplication.translate("TskResultsPanelForm", u"\u53c2\u8003\u6761\u4ef6\u4e0d\u9002\u7528", None))
        self.riskPlot.setProperty(u"noDataText", "")
        self.riskPlot.setProperty(u"noDataTooltip", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff1b\u5df2\u7559\u7a7a\uff0c\u4e0d\u8fdb\u884c\u5916\u63a8\u3002", None))
        self.riskPlot.setProperty(u"intervalErrorFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{error}", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.riskTab), QCoreApplication.translate("TskResultsPanelForm", u"\u98ce\u9669\u56fe", None))
        self.chainLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bcf\u70b9\u4ee3\u8868\u4e00\u6761 Chain\uff1b\u5bf9\u89d2\u7ebf\u8868\u793a\u89c2\u5bdf\u4e0e\u9884\u6d4b\u4e00\u81f4\u3002\u6b8b\u5dee = \u89c2\u5bdf \u2212 \u9884\u6d4b\u3002\u60ac\u505c\u67e5\u770b\u94fe\u4e0a TSK \u53ca\u5b9e\u4f8b\u5b9e\u9645\u6761\u4ef6\u6982\u7387\u3002", None))
        self.chainPlot.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{chain_id} \u00b7 \u89c2\u5bdf {observed} / \u9884\u6d4b {predicted}\n"
"Fail / Tested\uff1a{failed}/{tested} \u00b7 Missing\uff1a{missing}", None))
        self.chainPlot.setProperty(u"membersHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u94fe\u4e0a TSK\uff1a\u5355\u5b9e\u4f8b\u98ce\u9669\uff0c\u6309\u5b9e\u9645\u6761\u4ef6\u8ba1\u7b97\uff1b\u540c\u6761\u4ef6\u5b9e\u4f8b\u5408\u5e76", None))
        self.chainPlot.setProperty(u"memberFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id} \u00d7 {count} \u00b7 P_fail={probability}{reason} \u00b7 {conditions}", None))
        self.chainPlot.setProperty(u"noMembersText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ed3\u679c\u6ca1\u6709\u94fe\u6210\u5458\u98ce\u9669\u5feb\u7167\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c\u5206\u6790\u3002", None))
        self.chainPlot.setProperty(u"noFeaturesText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u989d\u5916\u7279\u5f81", None))
        self.chainPlot.setProperty(u"memberUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0d\u53ef\u4f30\u8ba1", None))
        self.chainPlot.setProperty(u"memberNoDataText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6570\u636e", None))
        self.chainPlot.setProperty(u"memberNotIdentifiableText", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0d\u53ef\u8bc6\u522b", None))
        self.chainPlot.setProperty(u"memberNotConvergedText", QCoreApplication.translate("TskResultsPanelForm", u"\u672a\u6536\u655b", None))
        self.chainPlot.setProperty(u"memberOutsideDomainText", QCoreApplication.translate("TskResultsPanelForm", u"\u5b9a\u4e49\u57df\u5916", None))
        self.chainPlot.setProperty(u"memberNoteFormat", QCoreApplication.translate("TskResultsPanelForm", u"[{index}] {text}", None))
        self.chainPlot.setProperty(u"memberNoteReferenceFormat", QCoreApplication.translate("TskResultsPanelForm", u"[{index}]", None))
        self.chainPlot.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.chainPlot.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002", None))
        self.chainPlot.setProperty(u"xAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u9884\u6d4b Chain \u5f02\u5e38\u7387\uff08%\uff09", None))
        self.chainPlot.setProperty(u"yAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u5f02\u5e38\u7387\uff08%\uff09", None))
        self.chainPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a Chain \u62df\u5408\u504f\u5dee\u3002", None))
        self.chainsTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"Chain ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u6837\u54c1\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Fail", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Pass", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Missing", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u9884\u6d4b\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6b8b\u5dee (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Deviance residual", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.chainFitTab), QCoreApplication.translate("TskResultsPanelForm", u"Chain \u62df\u5408", None))
        self.riskDetailsConditionsLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u4e0e\u9996\u9875\u98ce\u9669\u56fe\u4f7f\u7528\u540c\u4e00\u6279\u5b8c\u6574\u6761\u4ef6\u7ec4\u5408\u3002XY \u548c\u5176\u4ed6\u6570\u503c\u7279\u5f81\u56fa\u5b9a\u5728\u672c\u7ec4\u8bad\u7ec3\u5747\u503c\uff1b\u8fd9\u662f\u6761\u4ef6\u98ce\u9669\uff0c\u4e0d\u662f\u6240\u6709\u5b9e\u4f8b\u7684\u5e73\u5747\u98ce\u9669\u3002", None))
        self.typesTableView.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.typesTableView.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bef\u5dee\u6761\u4e3a 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u5e76\u975e \u00b1 \u6807\u51c6\u5dee\uff1b\u4e0a\u9650\u5bbd\u8868\u793a\u6570\u636e\u5c1a\u4e0d\u80fd\u6392\u9664\u8f83\u5927\u98ce\u9669\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002", None))
        self.typesTableView.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.typesTableView.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.typesTableView.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.typesTableView.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.typesTableView.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.typesTableView.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.typesTableView.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.typesTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u522b\u7ec4\u5408", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u5b9e\u4f8b\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0b\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0a\u754c / \u5355\u4fa7\u4e0a\u9650", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u53ef\u5355\u72ec\u8bc6\u522b", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u65b9\u6cd5", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u5f62\u5f0f", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.riskDetailsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u98ce\u9669\u660e\u7ec6", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.featureTab), QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u4e0e\u7cfb\u6570", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.jointRiskTab), QCoreApplication.translate("TskResultsPanelForm", u"\u8054\u5408\u98ce\u9669", None))
        self.combinationConditionsLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8ba1\u7b97\u7ec4\u5408\u7ed3\u679c\u3002", None))
        self.combinationConditionsLabel.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8ba1\u7b97\u7ec4\u5408\u7ed3\u679c\u3002", None))
        self.combinationConditionsLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u5df2\u8ba1\u7b97\uff1a{dimension} \u00b7 \u5dee\u503c\u57fa\u51c6 {reference} \u00b7 \u56fa\u5b9a\u7c7b\u522b\uff1a{fixed} \u00b7 \u6570\u503c\u5747\u503c\uff1a{numeric} \u00b7 {missing}", None))
        self.combinationConditionsLabel.setProperty(u"noneText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0", None))
        self.combinationWarningsLabel.setText("")
        self.combinationWarningsLabel.setProperty(u"summaryText", QCoreApplication.translate("TskResultsPanelForm", u"{count} \u6761\u7ec4\u5408\u63d0\u793a\uff08\u60ac\u505c\u6216\u6253\u5f00\u201c\u5168\u90e8\u63d0\u793a\u201d\uff09\u3002", None))
        self.combinationHeatmapMetricComboBox.setItemText(0, QCoreApplication.translate("TskResultsPanelForm", u"\u6982\u7387\u70ed\u529b\u56fe", None))
        self.combinationHeatmapMetricComboBox.setItemText(1, QCoreApplication.translate("TskResultsPanelForm", u"\u652f\u6301\u5ea6\u70ed\u529b\u56fe\uff08\u6709\u6548\u5e03\u5c40\u5b9e\u4f8b\u6570\uff09", None))

        self.combinationHeatmapLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u7a7a\u683c = \u65e0\u6570\u636e\u4e14\u4e0d\u5916\u63a8\uff1b\u7070\u683c = \u4e0d\u53ef\u4f30\u8ba1\uff1b\u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u96f6\u98ce\u9669\uff0c\u5355\u4fa7\u4e0a\u9650\u89c1\u60ac\u505c\u6216\u660e\u7ec6\uff1b\u659c\u7eb9 = \u5916\u63a8\u6216\u65e0\u6709\u6548\u652f\u6301\u3002\u652f\u6301\u5ea6\u662f\u5e03\u5c40\u5b9e\u4f8b\u6570\uff0c\u4e0d\u662f\u72ec\u7acb\u6837\u672c\u91cf\u3002\u70b9\u51fb\u683c\u5b50\u67e5\u770b\u8be5 TSK \u7684\u7c7b\u522b\u5bf9\u6bd4\u3002", None))
        self.heatmapPageLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8 {count} \u683c\uff1b\u672c\u9875 TSK {type_start}\u2013{type_end}\u3001\u7c7b\u522b {level_start}\u2013{level_end}\uff0c\u5171 {pages} \u9875\u3002", None))
        self.heatmapPageLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8 {count} \u683c\uff1b\u672c\u9875 TSK {type_start}\u2013{type_end}\u3001\u7c7b\u522b {level_start}\u2013{level_end}\uff0c\u5171 {pages} \u9875\u3002", None))
        self.heatmapPageSpinBox.setPrefix(QCoreApplication.translate("TskResultsPanelForm", u"\u7b2c ", None))
        self.heatmapPageSpinBox.setSuffix(QCoreApplication.translate("TskResultsPanelForm", u" \u9875", None))
        self.combinationHeatmap.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.combinationHeatmap.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bef\u5dee\u6761\u4e3a 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u5e76\u975e \u00b1 \u6807\u51c6\u5dee\uff1b\u4e0a\u9650\u5bbd\u8868\u793a\u6570\u636e\u5c1a\u4e0d\u80fd\u6392\u9664\u8f83\u5927\u98ce\u9669\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002", None))
        self.combinationHeatmap.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.combinationHeatmap.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.combinationHeatmap.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.combinationHeatmap.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.combinationHeatmap.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.combinationHeatmap.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.combinationHeatmap.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.combinationHeatmap.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u70b9\u51fb\u201c\u8ba1\u7b97\u7ec4\u5408\u6982\u7387\u201d\u751f\u6210\u70ed\u529b\u56fe\u3002", None))
        self.combinationHeatmap.setProperty(u"noDataSupportText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff08\u4e0d\u5916\u63a8\uff09", None))
        self.combinationHeatmap.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id} \u00b7 {level}\n"
"P_fail\uff1a{probability}\n"
"\u533a\u95f4\uff1a{interval}\n"
"\u533a\u95f4\u65b9\u6cd5\uff1a{interval_method}\n"
"\u652f\u6301\u72b6\u6001\uff1a{support}\n"
"\u5e03\u5c40\u5b9e\u4f8b\uff1a{layout} \u00b7 \u6709\u6548\u5b9e\u4f8b\uff1a{active}\n"
"\u6709\u6548\u94fe\uff1a{chains} \u00b7 \u94fe\u6d4b\u8bd5\u66b4\u9732\uff1a{exposure}\n"
"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{interval_error}\n"
"{boundary_note}", None))
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationHeatmapTab), QCoreApplication.translate("TskResultsPanelForm", u"\u70ed\u529b\u56fe", None))
        self.combinationCompareLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u56fe\uff1a\u6761\u4ef6 P_fail \u4e0e\u53ef\u7528\u533a\u95f4\uff0c\u96f6\u8fb9\u754c\u4f30\u8ba1\u663e\u793a\u5355\u4fa7\u4e0a\u9650\u3002\u4e0b\u56fe\uff1a\u76f8\u5bf9\u57fa\u51c6\u7684 \u0394p\uff08\u767e\u5206\u70b9\uff09\u53ca\u5355\u72ec\u8ba1\u7b97\u7684\u5dee\u503c\u533a\u95f4\uff1b\u8fb9\u754c\u60c5\u5f62\u65e0\u6cd5\u8ba1\u7b97\u65f6\u7559\u7a7a\u3002", None))
        self.combinationCompareLegendLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u56fe\uff1a\u6761\u4ef6 P_fail \u4e0e {confidence} \u533a\u95f4\uff0c\u96f6\u8fb9\u754c\u7ebf\u4ece 0 \u5230\u5355\u4fa7\u4e0a\u9650\uff0c\u4e0d\u662f \u00b1 \u6807\u51c6\u5dee\uff1b\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002\u4e0b\u56fe\uff1a\u76f8\u5bf9\u57fa\u51c6\u7684 \u0394p\uff08\u767e\u5206\u70b9\uff09\u53ca\u5355\u72ec\u8ba1\u7b97\u7684\u5dee\u503c\u533a\u95f4\uff1b\u8fb9\u754c\u60c5\u5f62\u65e0\u6cd5\u8ba1\u7b97\u65f6\u7559\u7a7a\u3002", None))
        self.comparePageLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8be5 TSK \u5171 {count} \u4e2a\u7c7b\u522b\u6761\u4ef6\uff1b\u663e\u793a {start}\u2013{end}\uff0c\u5171 {pages} \u9875\u3002", None))
        self.comparePageLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u8be5 TSK \u5171 {count} \u4e2a\u7c7b\u522b\u6761\u4ef6\uff1b\u663e\u793a {start}\u2013{end}\uff0c\u5171 {pages} \u9875\u3002", None))
        self.comparePageSpinBox.setPrefix(QCoreApplication.translate("TskResultsPanelForm", u"\u7b2c ", None))
        self.comparePageSpinBox.setSuffix(QCoreApplication.translate("TskResultsPanelForm", u" \u9875", None))
        self.combinationProbabilityPlot.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.combinationProbabilityPlot.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bef\u5dee\u6761\u4e3a 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u5e76\u975e \u00b1 \u6807\u51c6\u5dee\uff1b\u4e0a\u9650\u5bbd\u8868\u793a\u6570\u636e\u5c1a\u4e0d\u80fd\u6392\u9664\u8f83\u5927\u98ce\u9669\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002", None))
        self.combinationProbabilityPlot.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.combinationProbabilityPlot.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.combinationProbabilityPlot.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.combinationProbabilityPlot.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.combinationProbabilityPlot.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.combinationProbabilityPlot.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.combinationProbabilityPlot.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.combinationProbabilityPlot.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u522b\u6761\u4ef6 P_fail\uff08%\uff09", None))
        self.combinationProbabilityPlot.setProperty(u"noDataSupportText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff08\u4e0d\u5916\u63a8\uff09", None))
        self.combinationProbabilityPlot.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id} \u00b7 {level}\n"
"P_fail\uff1a{probability}\n"
"{interval}\n"
"\u652f\u6301\u72b6\u6001\uff1a{support}\n"
"\u62df\u5408\u72b6\u6001\uff1a{status}\n"
"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{interval_error}\n"
"{boundary_note}", None))
        self.combinationProbabilityPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u540e\u9009\u62e9 TSK \u67e5\u770b\u7c7b\u522b\u6982\u7387\u3002", None))
        self.combinationProbabilityPlot.setProperty(u"outsideDomainText", QCoreApplication.translate("TskResultsPanelForm", u"\u53c2\u8003\u6761\u4ef6\u4e0d\u9002\u7528", None))
        self.combinationProbabilityPlot.setProperty(u"noDataText", "")
        self.combinationProbabilityPlot.setProperty(u"noDataTooltip", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff1b\u5df2\u7559\u7a7a\uff0c\u4e0d\u8fdb\u884c\u5916\u63a8\u3002", None))
        self.combinationProbabilityPlot.setProperty(u"intervalErrorFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{error}", None))
        self.combinationDifferencePlot.setProperty(u"boundaryIntervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fb9\u754c\u60c5\u5f62\uff1a\u672a\u63d0\u4f9b\u5dee\u503c\u533a\u95f4", None))
        self.combinationDifferencePlot.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u76f8\u5bf9\u57fa\u51c6\u7c7b\u522b \u0394p\uff08\u767e\u5206\u70b9\uff09", None))
        self.combinationDifferencePlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u540e\u663e\u793a\u5dee\u503c\u53ca\u5176\u7f6e\u4fe1\u533a\u95f4\u3002", None))
        self.combinationDifferencePlot.setProperty(u"unavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u5dee\u503c\u4e0d\u53ef\u4f30\u8ba1", None))
        self.combinationDifferencePlot.setProperty(u"noDataText", "")
        self.combinationDifferencePlot.setProperty(u"referenceUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u57fa\u51c6\u65e0\u6570\u636e\uff0c\u5dee\u503c\u7559\u7a7a", None))
        self.combinationDifferencePlot.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{level}\n"
"\u0394p\uff1a{delta}\n"
"\u5dee\u503c\u533a\u95f4\uff1a{interval}\n"
"\u72b6\u6001\uff1a{status}\n"
"\u5dee\u503c\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{interval_error}", None))
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationCompareTab), QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u522b\u5bf9\u6bd4", None))
        self.combinationTableView.setProperty(u"boundaryIntervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fb9\u754c\u60c5\u5f62\uff1a\u672a\u63d0\u4f9b\u5dee\u503c\u533a\u95f4", None))
        self.combinationTableView.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.combinationTableView.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bef\u5dee\u6761\u4e3a 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u5e76\u975e \u00b1 \u6807\u51c6\u5dee\uff1b\u4e0a\u9650\u5bbd\u8868\u793a\u6570\u636e\u5c1a\u4e0d\u80fd\u6392\u9664\u8f83\u5927\u98ce\u9669\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002", None))
        self.combinationTableView.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.combinationTableView.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.combinationTableView.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.combinationTableView.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.combinationTableView.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.combinationTableView.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.combinationTableView.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.combinationTableView.setProperty(u"noDataSupportText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff08\u4e0d\u5916\u63a8\uff09", None))
        self.combinationTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u522b", None),
            QCoreApplication.translate("TskResultsPanelForm", u"P_fail", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0b\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0a\u754c / \u5355\u4fa7\u4e0a\u9650", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u0394p (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u0394p \u4e0b\u754c (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u0394p \u4e0a\u754c (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u652f\u6301\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5e03\u5c40\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u94fe\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u94fe\u6d4b\u8bd5\u66b4\u9732", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5dee\u503c\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5dee\u503c\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u5f62\u5f0f", None)])
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationDetailsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u660e\u7ec6", None))
        self.combinationHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u9ed8\u8ba4\u5c55\u5f00\u5168\u90e8\u7c7b\u522b\u7ec4\u5408\uff1b\u4e5f\u53ef\u9009\u62e9\u5355\u4e00\u7c7b\u522b\u7ef4\u5ea6\uff0c\u5176\u4f59\u7c7b\u522b\u56fa\u5b9a\u4e3a\u6307\u5b9a\u503c\u3002XY \u548c\u5176\u4ed6\u6570\u503c\u7279\u5f81\u4fdd\u6301\u8bad\u7ec3\u5747\u503c\uff0c\u4e0d\u53c2\u4e0e\u7ec4\u5408\u5c55\u5f00\u3002\u4fee\u6539\u6761\u4ef6\u540e\u70b9\u51fb\u8ba1\u7b97\u3002", None))
        self.combinationDimensionLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bd4\u8f83\u7ef4\u5ea6", None))
        self.combinationDimensionComboBox.setProperty(u"allCategoriesText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8\u7c7b\u522b\u7ec4\u5408", None))
        self.combinationTypeLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"TSK \u8303\u56f4", None))
        self.combinationTypeComboBox.setProperty(u"allText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8 TSK", None))
        self.combinationReferenceLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5dee\u503c\u6bd4\u8f83\u57fa\u51c6", None))
        self.combinationNoExtrapolationCheckBox.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6570\u636e\u7ec4\u5408\u7559\u7a7a\uff08\u4e0d\u5916\u63a8\uff09", None))
#if QT_CONFIG(tooltip)
        self.combinationNoExtrapolationCheckBox.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u6ca1\u6709\u6709\u6548\u94fe\u6d4b\u8bd5\u6570\u636e\u652f\u6301\u7684\u7c7b\u522b\u7ec4\u5408\u4fdd\u7559\u4f4d\u7f6e\uff0c\u6982\u7387\u548c\u533a\u95f4\u7559\u7a7a\uff1b\u53d6\u6d88\u52fe\u9009\u540e\u5141\u8bb8\u6a21\u578b\u5916\u63a8\u3002", None))
#endif // QT_CONFIG(tooltip)
        ___qtablewidgetitem = self.combinationFixedTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5176\u4f59\u7c7b\u522b\u7ef4\u5ea6", None))
        ___qtablewidgetitem1 = self.combinationFixedTableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u56fa\u5b9a\u7c7b\u522b", None))
        self.combinationStatusLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8bf7\u5148\u8fd0\u884c\u5305\u542b\u7c7b\u522b\u7279\u5f81\u7684 TSK \u5206\u6790\u3002", None))
        self.combinationStatusLabel.setProperty(u"noContextText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u65e0\u7ec4\u5408\u9884\u6d4b\u6240\u9700\u7684\u62df\u5408\u4fe1\u606f\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c TSK \u5206\u6790\u3002", None))
        self.combinationStatusLabel.setProperty(u"noCategoriesText", QCoreApplication.translate("TskResultsPanelForm", u"\u8bf7\u5728 TSK \u5206\u6790\u4e2d\u9009\u62e9\u81f3\u5c11\u4e00\u4e2a\u7c7b\u522b\u7279\u5f81\u540e\u91cd\u65b0\u8fd0\u884c\u3002", None))
        self.combinationStatusLabel.setProperty(u"readyText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u6b21 {count} \u4e2a\u7ec4\u5408\uff0c\u5168\u90e8\u8ba1\u7b97\uff1b\u5927\u7ed3\u679c\u5206\u9875\u663e\u793a\uff0c\u660e\u7ec6\u4fdd\u7559\u5168\u90e8\u884c\u3002", None))
        self.combinationStatusLabel.setProperty(u"busyText", QCoreApplication.translate("TskResultsPanelForm", u"\u6b63\u5728\u8ba1\u7b97\u7ec4\u5408\u6982\u7387\u4e0e\u5dee\u503c\u533a\u95f4\u2026", None))
        self.calculateCombinationButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u7ec4\u5408\u6982\u7387", None))
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationSettingsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u6761\u4ef6", None))
        self.copyDiagnosticsButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u590d\u5236\u8bca\u65ad\u6587\u672c", None))
#if QT_CONFIG(tooltip)
        self.copyDiagnosticsButton.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u590d\u5236\u5f53\u524d\u7ec4\u6807\u8bc6\u3001\u62df\u5408 debug \u62a5\u544a\u53ca\u5168\u90e8\u63d0\u793a\uff0c\u4e0d\u5305\u542b\u539f\u59cb\u62d3\u6251\u6216\u6837\u54c1\u884c\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.saveDiagnosticsButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u4fdd\u5b58\u8bca\u65ad TXT", None))
#if QT_CONFIG(tooltip)
        self.saveDiagnosticsButton.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u5c06\u5f53\u524d\u7ec4\u7684\u5b8c\u6574\u8bca\u65ad\u6587\u672c\u4fdd\u5b58\u4e3a UTF-8 \u6587\u672c\u6587\u4ef6\uff0c\u4fbf\u4e8e\u6392\u67e5\u8ba1\u7b97\u95ee\u9898\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.saveDiagnosticsButton.setProperty(u"dialogTitle", QCoreApplication.translate("TskResultsPanelForm", u"\u4fdd\u5b58 TSK \u8bca\u65ad\u6587\u672c", None))
        self.saveDiagnosticsButton.setProperty(u"fileFilter", QCoreApplication.translate("TskResultsPanelForm", u"\u6587\u672c\u6587\u4ef6 (*.txt)", None))
        self.saveDiagnosticsButton.setProperty(u"defaultFilename", QCoreApplication.translate("TskResultsPanelForm", u"tsk_diagnostics.txt", None))
        self.saveDiagnosticsButton.setProperty(u"errorTitle", QCoreApplication.translate("TskResultsPanelForm", u"\u8bca\u65ad\u6587\u672c\u4fdd\u5b58\u5931\u8d25", None))
        self.saveDiagnosticsButton.setProperty(u"errorFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6cd5\u4fdd\u5b58\u8bca\u65ad\u6587\u672c\uff1a{error}", None))
        self.diagnosticsActionStatusLabel.setText("")
        self.diagnosticsActionStatusLabel.setProperty(u"copiedText", QCoreApplication.translate("TskResultsPanelForm", u"\u5df2\u590d\u5236\u5f53\u524d\u7ec4\u7684\u8bca\u65ad\u6587\u672c\u3002", None))
        self.diagnosticsActionStatusLabel.setProperty(u"savedFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5df2\u4fdd\u5b58\uff1a{path}", None))
        self.combinationWarningsTextEdit.setPlaceholderText(QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c TSK \u5206\u6790\u540e\uff0c\u6b64\u5904\u663e\u793a\u5f53\u524d\u7ec4\u7684\u62df\u5408 debug \u62a5\u544a\u548c\u5168\u90e8\u63d0\u793a\u3002\u53ef\u590d\u5236\u8bca\u65ad\u6587\u672c\u6216\u4fdd\u5b58\u4e3a TXT\uff0c\u4fbf\u4e8e\u6392\u67e5\u5361\u987f\u3001\u672a\u6536\u655b\u6216\u533a\u95f4\u4e0d\u53ef\u7528\u7684\u539f\u56e0\u3002", None))
        self.combinationWarningsTextEdit.setProperty(u"contextFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u7ed3\u679c\u7ec4\uff1a{label}\n"
"\u8282\u70b9\uff1a{node}\n"
"\u6279\u6b21\u6a21\u5f0f\uff1a{batch_mode}\n"
"\u6279\u6b21\u5b57\u6bb5\uff1a{batch_dimension}\n"
"\u6bcd\u6279\uff1a{parent_batch}\n"
"\u539f\u6279\u6b21\uff1a{source_batches}", None))
        self.combinationWarningsTextEdit.setProperty(u"noneText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0", None))
        self.combinationWarningsTextEdit.setProperty(u"mixedBatchText", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0d\u5206\u5c42", None))
        self.combinationWarningsTextEdit.setProperty(u"separateBatchText", QCoreApplication.translate("TskResultsPanelForm", u"\u6309\u539f\u6279", None))
        self.combinationWarningsTextEdit.setProperty(u"parentBatchText", QCoreApplication.translate("TskResultsPanelForm", u"\u6309\u6bcd\u6279", None))
        self.combinationWarningsTextEdit.setProperty(u"debugHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408 debug \u62a5\u544a", None))
        self.combinationWarningsTextEdit.setProperty(u"debugScopeText", QCoreApplication.translate("TskResultsPanelForm", u"\u4ee5\u4e0b debug \u53c2\u6570\u7528\u4e8e\u6392\u67e5\u4f18\u5316\u8fc7\u7a0b\uff0c\u4e0d\u7b49\u4e8e\u53ef\u4fe1\u98ce\u9669\u4f30\u8ba1\uff1b\u8bf7\u7ed3\u5408\u6536\u655b\u3001\u53ef\u8bc6\u522b\u6027\u548c\u533a\u95f4\u72b6\u6001\u5224\u65ad\u7ed3\u679c\u3002", None))
        self.combinationWarningsTextEdit.setProperty(u"noDebugReportText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u7ed3\u679c\u672a\u8bb0\u5f55\u62df\u5408 debug \u62a5\u544a\u3002\u53ea\u6709\u542b\u7279\u5f81\u7684 Logistic \u4e3b\u62df\u5408\u4f1a\u8bb0\u5f55\u6b64\u8bca\u65ad\uff1b\u82e5\u662f\u65e7\u7684 Logistic \u7279\u5f81\u7ed3\u679c\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c\u5206\u6790\u3002", None))
        self.combinationWarningsTextEdit.setProperty(u"groupHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u5206\u6790\u63d0\u793a", None))
        self.combinationWarningsTextEdit.setProperty(u"viewHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u5f53\u524d\u7ec4\u5408\u63d0\u793a", None))
        self.combinationWarningsTextEdit.setProperty(u"modelScopeText", QCoreApplication.translate("TskResultsPanelForm", u"\u7ec4\u5408\u9884\u6d4b\u6cbf\u7528\u5171\u4eab\u7c7b\u522b\u4e3b\u6548\u5e94\u6a21\u578b\uff0c\u672a\u62df\u5408\u7c7b\u522b\u95f4\u6216\u7c7b\u522b\u4e0e TSK \u7684\u4ea4\u4e92\u3002\u4e0d\u540c TSK \u7684\u6982\u7387\u5dee\u4e0d\u540c\uff0c\u4e0d\u8868\u793a\u5df2\u8bc6\u522b\u4ea4\u4e92\u4f5c\u7528\u3002", None))
        self.combinationViewsTabWidget.setTabText(self.combinationViewsTabWidget.indexOf(self.combinationWarningsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8\u63d0\u793a", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.combinationTab), QCoreApplication.translate("TskResultsPanelForm", u"\u7ec4\u5408\u5206\u6790", None))
        self.topologyHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bcf\u884c\u8868\u793a\u4e00\u4e2a\u7269\u7406\u5b9e\u4f8b\uff1b\u9644\u52a0\u7279\u5f81\u5217\u6765\u81ea\u6a21\u677f\u3002Chain \u5b8c\u6574\u8def\u5f84\u7528\u4e8e\u533a\u5206\u540c\u540d\u94fe\u8def\u3002", None))
        self.topologyTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"CHAIN_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"TSK_instance_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"TSK_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"X", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Y", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Chain \u5b8c\u6574\u8def\u5f84", None)])
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.topologyTab), QCoreApplication.translate("TskResultsPanelForm", u"\u5b9e\u4f8b\u7ec4\u6210", None))
        pass
    # retranslateUi

