# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_risk_filter.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QSizePolicy, QToolButton,
    QVBoxLayout, QWidget)

class Ui_TskRiskFilterForm(object):
    def setupUi(self, TskRiskFilterForm):
        if not TskRiskFilterForm.objectName():
            TskRiskFilterForm.setObjectName(u"TskRiskFilterForm")
        TskRiskFilterForm.setMinimumSize(QSize(136, 0))
        TskRiskFilterForm.setMaximumSize(QSize(240, 16777215))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskRiskFilterForm.sizePolicy().hasHeightForWidth())
        TskRiskFilterForm.setSizePolicy(sizePolicy)
        self.filterLayout = QVBoxLayout(TskRiskFilterForm)
        self.filterLayout.setSpacing(2)
        self.filterLayout.setObjectName(u"filterLayout")
        self.filterLayout.setContentsMargins(0, 0, 0, 0)
        self.fieldLabel = QLabel(TskRiskFilterForm)
        self.fieldLabel.setObjectName(u"fieldLabel")
        self.fieldLabel.setTextFormat(Qt.TextFormat.PlainText)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.fieldLabel.sizePolicy().hasHeightForWidth())
        self.fieldLabel.setSizePolicy(sizePolicy1)

        self.filterLayout.addWidget(self.fieldLabel)

        self.filterButton = QToolButton(TskRiskFilterForm)
        self.filterButton.setObjectName(u"filterButton")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(1)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.filterButton.sizePolicy().hasHeightForWidth())
        self.filterButton.setSizePolicy(sizePolicy2)
        self.filterButton.setArrowType(Qt.ArrowType.DownArrow)
        self.filterButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)

        self.filterLayout.addWidget(self.filterButton)


        self.retranslateUi(TskRiskFilterForm)

        QMetaObject.connectSlotsByName(TskRiskFilterForm)
    # setupUi

    def retranslateUi(self, TskRiskFilterForm):
        self.fieldLabel.setText(QCoreApplication.translate("TskRiskFilterForm", u"TSK ID", None))
        self.filterButton.setText(QCoreApplication.translate("TskRiskFilterForm", u"\u5168\u90e8", None))
        self.filterButton.setProperty(u"allText", QCoreApplication.translate("TskRiskFilterForm", u"\u5168\u90e8", None))
        self.filterButton.setProperty(u"noneText", QCoreApplication.translate("TskRiskFilterForm", u"\u672a\u9009\u62e9", None))
        self.filterButton.setProperty(u"selectionFormat", QCoreApplication.translate("TskRiskFilterForm", u"\u5df2\u9009 {selected}/{total}", None))
#if QT_CONFIG(tooltip)
        self.filterButton.setToolTip(QCoreApplication.translate("TskRiskFilterForm", u"\u52fe\u9009\u8981\u663e\u793a\u7684\u503c\uff1b\u4e0d\u540c\u5b57\u6bb5\u7684\u7b5b\u9009\u540c\u65f6\u751f\u6548\u3002", None))
#endif // QT_CONFIG(tooltip)
        pass
    # retranslateUi

