# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_completion_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_TskCompletionDialog(object):
    def setupUi(self, TskCompletionDialog):
        if not TskCompletionDialog.objectName():
            TskCompletionDialog.setObjectName(u"TskCompletionDialog")
        TskCompletionDialog.setMinimumSize(QSize(500, 0))
        self.dialogLayout = QVBoxLayout(TskCompletionDialog)
        self.dialogLayout.setSpacing(16)
        self.dialogLayout.setObjectName(u"dialogLayout")
        self.titleLabel = QLabel(TskCompletionDialog)
        self.titleLabel.setObjectName(u"titleLabel")
        font = QFont()
        font.setBold(True)
        self.titleLabel.setFont(font)

        self.dialogLayout.addWidget(self.titleLabel)

        self.contextLabel = QLabel(TskCompletionDialog)
        self.contextLabel.setObjectName(u"contextLabel")
        self.contextLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.contextLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.contextLabel)

        self.messageLabel = QLabel(TskCompletionDialog)
        self.messageLabel.setObjectName(u"messageLabel")
        self.messageLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.messageLabel)

        self.laterHintLabel = QLabel(TskCompletionDialog)
        self.laterHintLabel.setObjectName(u"laterHintLabel")
        self.laterHintLabel.setWordWrap(True)

        self.dialogLayout.addWidget(self.laterHintLabel)

        self.buttonsLayout = QHBoxLayout()
        self.buttonsLayout.setObjectName(u"buttonsLayout")
        self.buttonsSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonsLayout.addItem(self.buttonsSpacer)

        self.laterButton = QPushButton(TskCompletionDialog)
        self.laterButton.setObjectName(u"laterButton")

        self.buttonsLayout.addWidget(self.laterButton)

        self.calculateButton = QPushButton(TskCompletionDialog)
        self.calculateButton.setObjectName(u"calculateButton")

        self.buttonsLayout.addWidget(self.calculateButton)


        self.dialogLayout.addLayout(self.buttonsLayout)


        self.retranslateUi(TskCompletionDialog)
        self.laterButton.clicked.connect(TskCompletionDialog.reject)
        self.calculateButton.clicked.connect(TskCompletionDialog.accept)

        self.laterButton.setDefault(True)


        QMetaObject.connectSlotsByName(TskCompletionDialog)
    # setupUi

    def retranslateUi(self, TskCompletionDialog):
        TskCompletionDialog.setWindowTitle(QCoreApplication.translate("TskCompletionDialog", u"\u8ba1\u7b97\u5b8c\u6574 TSK \u7c7b\u522b\u7ec4\u5408", None))
        self.titleLabel.setText(QCoreApplication.translate("TskCompletionDialog", u"\u662f\u5426\u73b0\u5728\u8865\u7b97\u5b8c\u6574\u7c7b\u522b\u7ec4\u5408\uff1f", None))
        self.contextLabel.setText("")
        self.contextLabel.setProperty(u"formatText", QCoreApplication.translate("TskCompletionDialog", u"\u8282\u70b9 / \u6279\u6b21\uff1a{group}\n"
"\u672c\u6b21\u8ba1\u7b97\uff1a{count} \u4e2a TSK \u4e0e\u7c7b\u522b\u7ec4\u5408", None))
        self.messageLabel.setText(QCoreApplication.translate("TskCompletionDialog", u"\u5f53\u524d\u7ec4\u5df2\u6709 TSK \u62df\u5408\u7ed3\u679c\uff0c\u4f46\u5c1a\u672a\u4fdd\u5b58\u5b8c\u6574\u7684\u7c7b\u522b\u7ec4\u5408\u7ed3\u679c\u3002\u8865\u7b97\u5c06\u4f7f\u7528\u5df2\u6709\u62df\u5408\u7ed3\u679c\uff0c\u8ba1\u7b97\u7ec4\u5408\u6982\u7387\u548c\u7f6e\u4fe1\u533a\u95f4\uff1b\u7ec4\u5408\u8f83\u591a\u65f6\u53ef\u80fd\u9700\u8981\u8f83\u957f\u65f6\u95f4\u3002\n"
"\n"
"\u9009\u62e9\u201c\u7a0d\u540e\u8ba1\u7b97\u201d\u53ef\u4ee5\u7ee7\u7eed\u67e5\u770b\u5df2\u6709\u7ed3\u679c\u3002", None))
        self.laterHintLabel.setText(QCoreApplication.translate("TskCompletionDialog", u"\u7a0d\u540e\u53ef\u8fdb\u5165\u201cTSK Results \u2192 \u98ce\u9669\u56fe\u201d\uff0c\u70b9\u51fb\u201c\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\u201d\u3002\u4e5f\u53ef\u8fdb\u5165\u201c\u7ec4\u5408\u5206\u6790 \u2192 \u8ba1\u7b97\u6761\u4ef6\u201d\uff0c\u9009\u62e9\u8303\u56f4\u540e\u70b9\u51fb\u201c\u8ba1\u7b97\u7ec4\u5408\u6982\u7387\u201d\u3002", None))
        self.laterButton.setText(QCoreApplication.translate("TskCompletionDialog", u"\u7a0d\u540e\u8ba1\u7b97", None))
        self.calculateButton.setText(QCoreApplication.translate("TskCompletionDialog", u"\u5f00\u59cb\u8ba1\u7b97", None))
    # retranslateUi

