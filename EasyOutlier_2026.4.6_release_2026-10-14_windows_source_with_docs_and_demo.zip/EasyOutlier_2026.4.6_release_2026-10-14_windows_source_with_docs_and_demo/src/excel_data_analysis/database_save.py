"""Database save orchestration for background workers, without Qt access."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from .gui_state import save_gui_state
from .service import (
    clear_storage_root,
    delete_storage_workspace,
    describe_storage,
    list_import_history,
    save_storage_workspace,
    save_storage_workspace_as,
)
from .summary_snapshot import prepare_summary_snapshot_for_copy, rebase_summary_snapshot_after_copy


def save_database_job(
    request: dict[str, Any],
    progress_callback: Callable[[int, str], None] | None = None,
) -> dict[str, Any]:
    """Save a frozen GUI request and prepare everything needed for UI completion.

    The caller captures widget values before dispatch. Nonnegative progress
    values mark completed stages; -1 requests an indeterminate indicator while
    performing disk operations whose work cannot be counted in advance.
    """
    progress = progress_callback or (lambda _value, _message: None)
    source_root = Path(request["source_root"]).resolve()
    target_root = Path(request["target_root"]).resolve()
    save_as = source_root != target_root
    if save_as and (target_root.is_relative_to(source_root) or source_root.is_relative_to(target_root)):
        raise ValueError("The saved database folder must not contain, or be inside, the source database folder.")
    # The request is already detached from the UI. Copy only the dictionaries
    # this job changes, avoiding another copy of potentially large TSK results.
    gui_state = dict(request["gui_state"])
    results = gui_state.get("current_results")
    results = dict(results) if isinstance(results, dict) else {}
    gui_state["current_results"] = results

    progress(0, "Preparing database save")
    progress(-1, "Checking saved analysis navigation")
    prepared = prepare_summary_snapshot_for_copy(request.get("summary_snapshot"), request["storage_path"])
    progress(15, "Analysis navigation checked")

    progress(-1, "Compacting and copying database" if save_as else "Compacting and merging database")
    if save_as:
        workspace_merge = save_storage_workspace_as(
            storage_root_path=str(source_root), target_storage_root_path=str(target_root),
        )
    else:
        workspace_merge = save_storage_workspace(str(source_root))
    progress(55, "Database files saved")

    progress(-1, "Updating saved analysis paths")
    snapshot = rebase_summary_snapshot_after_copy(prepared, source_root, target_root, target_root)
    results["plot_inspector_snapshot"] = snapshot
    progress(65, "Analysis paths updated")

    progress(-1, "Saving analysis results and settings")
    settings_file = save_gui_state(target_root, gui_state)
    progress(80, "Analysis results and settings saved")

    workspace_cleanup = None
    cleanup_error = None
    progress(-1, "Refreshing database overview")
    overview = describe_storage(str(target_root), template_path=request.get("template_path") or None, limit=500)
    entries = list_import_history(str(target_root))
    progress(95, "Database overview refreshed")

    # Keep the working source until all required save and refresh work has
    # succeeded. Cleanup failure cannot invalidate a committed database save.
    cleanup = None
    if not save_as:
        progress(-1, "Removing saved temporary workspace")
        cleanup = delete_storage_workspace
    elif request.get("clear_default_source"):
        progress(-1, "Clearing saved default temporary database")
        cleanup = clear_storage_root
    if cleanup is not None:
        try:
            workspace_cleanup = cleanup(str(source_root))
        except Exception as exc:
            cleanup_error = str(exc)
    progress(100, "Database saved")
    return {
        "root": str(target_root),
        "settings_file": str(settings_file),
        "gui_state": gui_state,
        "snapshot": snapshot,
        "workspace_merge": workspace_merge,
        "workspace_cleanup": workspace_cleanup,
        "overview": overview,
        "entries": entries,
        "cleanup_error": cleanup_error,
    }
