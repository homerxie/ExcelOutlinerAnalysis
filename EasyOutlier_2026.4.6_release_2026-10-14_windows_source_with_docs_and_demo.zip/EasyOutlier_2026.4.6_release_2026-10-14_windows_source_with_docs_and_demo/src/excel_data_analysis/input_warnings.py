"""Non-fatal input coverage notices for template columns absent from a file."""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any, Iterable

from .field_names import FieldNames
from .models import TemplateConfig


def collect_available_columns(template: TemplateConfig, headers: Iterable[str]) -> list[str]:
    """Return declared column names whose headers exist, including blank columns."""
    fields = FieldNames(header for header in headers if header)
    return list(dict.fromkeys(
        column.name
        for group in template.analysis_groups
        for column in group.columns
        if fields.resolve(column.name) in fields.names
    ))


def collect_missing_column_warnings(
    template: TemplateConfig,
    headers: Iterable[str],
) -> list[dict[str, Any]]:
    """Distinguish omitted test columns from present columns with empty cells."""
    available = set(collect_available_columns(template, headers))
    return [
        {
            "code": "missing_analysis_column",
            "group_id": group.id,
            "group_display_name": group.display_name,
            "raw_column": column.name,
            "header_values": list(column.header_values),
            "status": "no_data",
            "message": "Excel 未提供该测试列，按无数据跳过，不参与异常判定及统计。",
        }
        for group in template.analysis_groups
        for column in group.columns
        if column.name not in available
    ]


def write_import_warnings(
    repository_root: str | Path,
    dataset_id: str,
    source_file: str,
    template_name: str,
    warnings: list[dict[str, Any]],
) -> str | None:
    """Save notices beside the import data so database saves preserve them."""
    if not warnings:
        return None
    path = Path(repository_root).resolve() / "imports" / f"{dataset_id}.warnings.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "dataset_id": dataset_id,
        "source_file": str(Path(source_file).resolve()),
        "template_name": template_name,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "warning_count": len(warnings),
        "warnings": warnings,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return str(path)
