# -*- mode: python ; coding: utf-8 -*-

from pathlib import Path
import sys

from PyInstaller.utils.hooks import collect_data_files, collect_submodules


spec_file = globals().get("__file__")
if spec_file:
    project_root = Path(spec_file).resolve().parent
else:
    project_root = Path.cwd().resolve()
src_root = project_root / "src"

datas = collect_data_files(
    "excel_data_analysis",
    includes=["assets/templates/*.json", "assets/templates/*.xlsx"],
)
icon_dir = project_root / "icon"
if icon_dir.exists():
    for icon_name in ("icon.png", "icon.ico", "icon.icns"):
        icon_path = icon_dir / icon_name
        if icon_path.exists():
            datas.append((str(icon_path), "icon"))
hiddenimports = collect_submodules("openpyxl")
exe_icon = None
if sys.platform == "darwin":
    mac_icon = icon_dir / "icon.icns"
    if mac_icon.exists():
        exe_icon = str(mac_icon)
else:
    windows_icon = icon_dir / "icon.ico"
    if windows_icon.exists():
        exe_icon = str(windows_icon)


a = Analysis(
    [str(src_root / "excel_data_analysis" / "gui_main.py")],
    pathex=[str(src_root)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="EasyOutlier",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=exe_icon,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="EasyOutlier",
)

if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="EasyOutlier.app",
        icon=str(icon_dir / "icon.icns") if (icon_dir / "icon.icns").exists() else None,
        bundle_identifier=None,
    )
