from __future__ import annotations

import json
import multiprocessing as mp
import re
import traceback
from collections import defaultdict
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any
from copy import copy

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.styles.cell_style import StyleArray
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.merge import MergedCellRange

from .analyzer import evaluate_against_golden, evaluate_modified_zscore
from .golden_rules import outlier_golden_method_modifiers, outlier_golden_method_terms
from .io import extract_dimension_rows, load_table, to_float
from .models import (
    AnomalyResult,
    GoldenAllowedRange,
    GoldenReference,
    MeasurementRecord,
    OutlierRatioStatConfig,
    TemplateConfig,
    ThresholdConfig,
)
from .output_paths import resolve_split_output_base_path, resolve_split_output_paths
from .template import load_template


HEADER_FILL = PatternFill("solid", fgColor="D9E2F3")
SUBHEADER_FILL = PatternFill("solid", fgColor="EAF2F8")
FAIL_FONT = Font(color="9C0006", bold=True)
OUTLIER_WARN_FONT = Font(color="9C0006", bold=True)
OUTLIER_FAIL_FONT = Font(color="FF0000", bold=True)
HEADER_FONT = Font(bold=True)
THIN_SIDE = Side(style="thin", color="000000")
THIN_BORDER = Border(
    left=THIN_SIDE,
    right=THIN_SIDE,
    top=THIN_SIDE,
    bottom=THIN_SIDE,
)
CENTER = Alignment(horizontal="center", vertical="center")
PERCENT_FORMAT_2 = "0.00%"
DECIMAL_FORMAT_3 = "0.000"
MERGED_FAIL_FILL = PatternFill("solid", fgColor="FFF2CC")
NEW_FAIL_FILL = PatternFill("solid", fgColor="FFD966")
RECOVERED_FILL = PatternFill("solid", fgColor="E2F0D9")
OUTLIER_SUMMARY_NOTES = {
    "All Outlier Blocks": "出现任何单个数据点fail的样品+Node组合数量",
    "Merged Outlier Blocks": "按照当前merge规则判为fail的所有样品+Node组合数量",
    "New Merged Outliers": "按照当前merge规则判为fail的新增样品+Node组合数量",
    "Recovered Blocks": "按照当前merge规则判为pass的且上个节点为fail的样品+Node组合数量",
    "Affected Samples": "被判为fail的样品数量",
    "Raw Failing Test Cells": "被判为fail的单个数据点数量",
}
RATIO_GROUP_BY_SKIP_LEVEL_WARNING = (
    "Group By Dimension 存在 column header 跳层：{used_levels}。"
    "统计结果不会重新按这些维度判定 fail，而是将当前 filter 下已经 merged 的 outlier 结果映射到这些维度上统计。"
    "如果需要重新判断，请使用 filter 改变统计数据池。"
    "如果需要完整层级分桶，可写成：{suggested_levels}。"
)

OUTLIER_MERGE_ORDER_STEPS = {
    "column merge -> column group -> row merge -> row node": (
        "column_merge",
        "column_group",
        "row_merge",
        "row_node",
    ),
    "row merge -> row node -> column merge -> column group": (
        "row_merge",
        "row_node",
        "column_merge",
        "column_group",
    ),
    "column merge -> row merge -> column group -> row node": (
        "column_merge",
        "row_merge",
        "column_group",
        "row_node",
    ),
    "row merge -> column merge -> row node -> column group": (
        "row_merge",
        "column_merge",
        "row_node",
        "column_group",
    ),
    "column merge -> row merge -> row node -> column group": (
        "column_merge",
        "row_merge",
        "row_node",
        "column_group",
    ),
    "row merge -> column merge -> column group -> row node": (
        "row_merge",
        "column_merge",
        "column_group",
        "row_node",
    ),
}

NATURAL_SORT_SPLIT_RE = re.compile(r"(\d+)")


@dataclass(slots=True)
class ColumnMeta:
    raw_column: str
    logical_metric: str
    group_id: str
    group_display_name: str
    header_values: list[str]
    unit: str | None
    display_order: int
    column_order: int | None = None

    @property
    def chain_name(self) -> str:
        return self.header_values[0] if self.header_values else ""

    @property
    def test_type(self) -> str:
        return self.header_values[1] if len(self.header_values) > 1 else ""


@dataclass(slots=True)
class RowData:
    dataset_id: str
    source_file: str
    row_number: int
    dimensions: dict[str, str]
    values: dict[str, float]


@dataclass(slots=True)
class MetricValue:
    value: Any | None
    threshold: Any | None
    golden_value: Any | None
    is_fail: bool
    lower_bound: float | None = None
    upper_bound: float | None = None
    allowed_ranges: list[GoldenAllowedRange] | None = None
    outlier_display_value: Any | None = None
    outlier_number_format: str | None = None
    absolute_rule_failed: bool = False

    def __post_init__(self) -> None:
        if self.allowed_ranges is None:
            self.allowed_ranges = []


@dataclass(slots=True)
class MergeRecord:
    row_key: tuple[str, ...]
    column_key: tuple[str, ...]
    is_fail: bool
    sample_key: tuple[str, ...]
    node_value: str
    dimensions: dict[str, str]
    raw_row_keys: set[tuple[str, int]]
    raw_columns: set[str]
    logical_metrics: set[str]
    group_ids: set[str]
    group_display_names: set[str]
    test_types: set[str]
    chain_names: set[str]
    column_names: set[str]
    units: set[str]


@dataclass(slots=True)
class LeafRecord:
    row_path: tuple[str, ...]
    column_path: tuple[str, ...]
    sample_key: tuple[str, ...]
    node_value: str
    dimensions: dict[str, str]
    raw_row_key: tuple[str, int]
    raw_column: str
    logical_metric: str
    group_id: str
    group_display_name: str
    test_type: str
    chain_name: str
    unit: str | None
    is_fail: bool


MetricKey = tuple[str, int, str]


def _emit_progress(callback: Any | None, value: int, message: str) -> None:
    if callback is None:
        return
    callback(value, message)


def _measurement_key(measurement: MeasurementRecord) -> MetricKey:
    return (measurement.dataset_id, measurement.row_number, measurement.raw_column)


def _anomaly_key(anomaly: AnomalyResult) -> MetricKey:
    return (anomaly.dataset_id, anomaly.row_number, anomaly.raw_column)


def _row_metric_key(row: RowData, raw_column: str) -> MetricKey:
    return (row.dataset_id, row.row_number, raw_column)


def _sample_dimension_names(template: TemplateConfig) -> list[str]:
    values = [
        str(value).strip()
        for value in template.report.sample_dimension_names
        if str(value).strip()
    ]
    if not values:
        raise ValueError(
            "report.sample_dimension_names must be configured in the template."
        )
    return values


def _sample_dimension_label(template: TemplateConfig) -> str:
    names = _sample_dimension_names(template)
    labels: list[str] = []
    for target_name in names:
        for dimension in _ordered_row_dimensions(template):
            if dimension.name == target_name:
                labels.append(dimension.display_name or dimension.name)
                break
        else:
            labels.append(target_name)
    return " + ".join(labels)


def _sample_key_from_dimensions(
    dimensions: dict[str, str],
    sample_dimension_names: list[str],
) -> tuple[str, ...]:
    return tuple(str(dimensions.get(name, "") or "") for name in sample_dimension_names)


def _sample_key_display(sample_key: tuple[str, ...]) -> str:
    return " | ".join(sample_key)


def _sample_key_sort_key(sample_key: tuple[str, ...]) -> tuple[Any, ...]:
    return tuple(_natural_sort_key(value) for value in sample_key)


def _fail_mode_requires_golden(fail_mode: str) -> bool:
    return fail_mode in {"golden_deviation", "zscore_and_golden", "zscore_or_golden"}


def generate_chip_report(
    template_path: str | Path,
    input_path: str | Path,
    output_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    if_exists: str = "overwrite",
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    resolved_output_base_path = resolve_split_output_base_path(output_path, if_exists=if_exists)
    resolved_output_base_path.parent.mkdir(parents=True, exist_ok=True)
    _emit_progress(progress_callback, 5, "Loading template...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 15, "Reading input workbook...")
    table = load_table(input_path, template=template)
    _emit_progress(progress_callback, 25, "Building measurement records...")
    measurements = _build_measurements(template, table.rows, input_path)
    _emit_progress(progress_callback, 35, "Building row view...")
    row_data = _build_rows(template, table.rows, input_path)
    _emit_progress(progress_callback, 45, "Resolving test columns...")
    columns = _build_columns(template, table.units, table.headers)
    return _generate_chip_report_from_prebuilt(
        template=template,
        source_label=str(Path(input_path).resolve()),
        output_base_path=resolved_output_base_path,
        measurements=measurements,
        row_data=row_data,
        columns=columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        outlier_merge_order_override=outlier_merge_order_override,
        outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def generate_chip_report_from_measurements(
    template_path: str | Path,
    measurements: list[MeasurementRecord],
    output_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    source_label: str | None = None,
    if_exists: str = "overwrite",
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    resolved_output_base_path = resolve_split_output_base_path(output_path, if_exists=if_exists)
    resolved_output_base_path.parent.mkdir(parents=True, exist_ok=True)
    _emit_progress(progress_callback, 10, "Loading template...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 25, "Building row view from database measurements...")
    row_data = _build_rows_from_measurements(measurements)
    _emit_progress(progress_callback, 40, "Resolving test columns...")
    columns = _build_columns(
        template,
        {},
        sorted({item.raw_column for item in measurements}),
    )
    resolved_source_label = source_label or "database-scope"
    return _generate_chip_report_from_prebuilt(
        template=template,
        source_label=resolved_source_label,
        output_base_path=resolved_output_base_path,
        measurements=measurements,
        row_data=row_data,
        columns=columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        outlier_merge_order_override=outlier_merge_order_override,
        outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def _generate_chip_report_from_prebuilt(
    template: TemplateConfig,
    source_label: str,
    output_base_path: str | Path,
    measurements: list[MeasurementRecord],
    row_data: list[RowData],
    columns: list[ColumnMeta],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    progress_callback: Any | None = None,
) -> dict[str, Any]:
    resolved_output_paths = resolve_split_output_paths(output_base_path, if_exists="overwrite")
    _emit_progress(progress_callback, 55, "Calculating Z Score deviations...")
    sample_node_orders = _build_sample_node_orders(row_data, template)
    row_data.sort(key=lambda item: _row_sort_key(item, template, sample_node_orders))
    fail_mode = outlier_fail_method_override or template.report.outlier_fail_method
    if outlier_merge_order_override:
        template.report.outlier_merge_order = outlier_merge_order_override
    if outlier_treat_empty_cells_as_fail_override is not None:
        template.report.outlier_treat_empty_cells_as_fail = bool(
            outlier_treat_empty_cells_as_fail_override
        )
    if _fail_mode_requires_golden(fail_mode) and not built_golden_path:
        raise ValueError(
            "Golden File is required when Outlier Criteria uses Golden Deviation."
        )

    zscore_values = _build_zscore_map(
        measurements,
        template.report.zscore_thresholds,
        columns,
        zscore_threshold_override=zscore_threshold_override,
    )
    _emit_progress(progress_callback, 65, "Calculating golden deviations...")
    golden_reference = _load_built_golden_reference(built_golden_path)
    golden_values = _build_report_golden_values(
        measurements,
        template,
        columns,
        golden_reference=golden_reference,
    )
    golden_fallback_warnings = _build_golden_fallback_warning_rows(golden_reference)
    golden_header_values = _build_column_display_values(golden_values, "golden_value")
    golden_bound_values = _build_column_bound_display_values(golden_values)
    golden_threshold_values = _build_column_display_values(golden_values, "threshold")
    zscore_threshold_values = _build_column_display_values(zscore_values, "threshold")
    _emit_progress(progress_callback, 72, "Starting data workbook process...")
    data_process, data_queue = _start_report_process(
        _write_data_report_process,
        resolved_output_paths["data"],
        template,
        columns,
        row_data,
        golden_values,
        golden_header_values,
        golden_bound_values,
        zscore_values,
        zscore_threshold_values,
        golden_threshold_values,
        bool(built_golden_path and _has_variable_metric_attribute(golden_values, "golden_value")),
    )
    _emit_progress(progress_callback, 78, "Building outlier summary...")
    summary_artifacts = _collect_outlier_summary_artifacts(
        template,
        columns,
        row_data,
        zscore_values,
        golden_values,
        sample_node_orders,
        outlier_fail_method_override=fail_mode,
    )
    summary_rows = summary_artifacts["summary_rows"]
    summary_stats_rows = summary_artifacts["summary_stats_rows"]
    ratio_rows = summary_artifacts["ratio_rows"]
    all_outlier_rows = summary_artifacts["all_outlier_rows"]
    merged_outlier_rows = summary_artifacts["merged_outlier_rows"]
    _emit_progress(progress_callback, 90, "Starting outlier workbook process...")
    outlier_process, outlier_queue = _start_report_process(
        _write_outlier_report_process,
        resolved_output_paths["outlier"],
        template,
        columns,
        row_data,
        zscore_values,
        golden_values,
        golden_header_values,
        golden_bound_values,
        sample_node_orders,
        all_outlier_rows,
        merged_outlier_rows,
        summary_artifacts["final_status_rows"],
        summary_stats_rows,
        ratio_rows,
        golden_fallback_warnings,
        fail_mode,
    )
    _emit_progress(progress_callback, 96, "Waiting for split workbooks...")
    _wait_for_report_process(data_process, data_queue, "Data report")
    _wait_for_report_process(outlier_process, outlier_queue, "Outlier report")

    failing_samples = sorted(
        {item["sample_id"] for item in summary_rows},
        key=_natural_sort_key,
    )
    return {
        "input": source_label,
        "output": str(Path(output_base_path).resolve()),
        "outputs": {
            name: str(path.resolve()) for name, path in resolved_output_paths.items()
        },
        "row_count": len(row_data),
        "measurement_count": len(measurements),
        "outlier_sample_count": len(failing_samples),
        "outlier_event_count": len(summary_rows),
    }


def _start_report_process(target: Any, *args: Any) -> tuple[mp.Process, Any]:
    start_methods = mp.get_all_start_methods()
    context_name = "fork" if "fork" in start_methods else "spawn"
    ctx = mp.get_context(context_name)
    queue = ctx.Queue()
    process = ctx.Process(target=target, args=(*args, queue))
    process.start()
    return process, queue


def _wait_for_report_process(process: mp.Process, queue: Any, label: str) -> None:
    process.join()
    payload: dict[str, Any] | None = None
    while True:
        try:
            payload = queue.get_nowait()
        except Exception:
            break
    if process.exitcode == 0 and payload and payload.get("ok"):
        return
    if payload and not payload.get("ok"):
        details = str(payload.get("traceback", "")).strip()
        error = str(payload.get("error", f"{label} failed"))
        if details:
            raise RuntimeError(f"{label} failed: {error}\n{details}")
        raise RuntimeError(f"{label} failed: {error}")
    raise RuntimeError(f"{label} failed: process exited with code {process.exitcode}.")


def _write_data_report_process(
    output_path: str | Path,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    row_data: list[RowData],
    golden_values: dict[MetricKey, MetricValue],
    golden_header_values: dict[str, Any],
    golden_bound_values: dict[str, Any],
    zscore_values: dict[MetricKey, MetricValue],
    zscore_threshold_values: dict[str, Any],
    golden_threshold_values: dict[str, Any],
    include_point_golden_sheet: bool,
    result_queue: Any,
) -> None:
    try:
        workbook = Workbook()
        workbook.remove(workbook.active)
        _write_sorted_sheet(
            workbook.create_sheet("Sorted"),
            template,
            columns,
            row_data,
            golden_header_values,
            golden_bound_values,
        )
        if include_point_golden_sheet:
            _write_point_golden_sheet(
                workbook.create_sheet("golden-by-point"),
                template,
                columns,
                row_data,
                golden_values,
                golden_header_values,
            )
        _write_metric_sheet(
            workbook.create_sheet("deviation-zscore"),
            template,
            columns,
            row_data,
            zscore_values,
            zscore_threshold_values,
            golden_header_values,
            golden_bound_values,
            "Z Threshold",
            value_number_format=DECIMAL_FORMAT_3,
            threshold_number_format=DECIMAL_FORMAT_3,
        )
        _write_metric_sheet(
            workbook.create_sheet("deviation-golden"),
            template,
            columns,
            row_data,
            golden_values,
            golden_threshold_values,
            golden_header_values,
            golden_bound_values,
            "Deviation Threshold",
            value_number_format=PERCENT_FORMAT_2,
            threshold_number_format=PERCENT_FORMAT_2,
        )
        workbook.save(output_path)
        result_queue.put({"ok": True})
    except Exception as exc:
        result_queue.put(
            {
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
        )
        raise


def _write_outlier_report_process(
    output_path: str | Path,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    row_data: list[RowData],
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
    golden_header_values: dict[str, Any],
    golden_bound_values: dict[str, Any],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    all_outlier_rows: list[dict[str, str]],
    merged_outlier_rows: list[dict[str, str]],
    final_status_rows: list[dict[str, str]],
    summary_stats_rows: list[dict[str, Any]],
    ratio_rows: list[dict[str, Any]],
    golden_fallback_warnings: list[dict[str, str]],
    fail_mode: str,
    result_queue: Any,
) -> None:
    try:
        workbook = Workbook()
        workbook.remove(workbook.active)
        _write_summary_sheet(
            workbook.create_sheet("Outlier Summary"),
            template,
            summary_stats_rows,
            ratio_rows,
            sample_node_orders,
            golden_fallback_warnings,
        )
        _write_outlier_sheet(
            workbook.create_sheet("all outliers"),
            template,
            columns,
            row_data,
            zscore_values,
            golden_values,
            golden_header_values,
            golden_bound_values,
            sample_node_orders,
            all_outlier_rows,
            highlight_rows=final_status_rows,
            outlier_fail_method_override=fail_mode,
        )
        _write_outlier_sheet(
            workbook.create_sheet("merged outlier"),
            template,
            columns,
            row_data,
            zscore_values,
            golden_values,
            golden_header_values,
            golden_bound_values,
            sample_node_orders,
            merged_outlier_rows,
            highlight_rows=merged_outlier_rows,
            outlier_fail_method_override=fail_mode,
        )
        workbook.save(output_path)
        result_queue.put({"ok": True})
    except Exception as exc:
        result_queue.put(
            {
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
        )
        raise


def collect_report_failures(
    template_path: str | Path,
    input_path: str | Path,
    built_golden_path: str | Path | None = None,
    zscore_threshold_override: float | None = None,
) -> list[AnomalyResult]:
    template = load_template(template_path)
    table = load_table(input_path, template=template)
    measurements = _build_measurements(template, table.rows, input_path)
    columns = _build_columns(template, table.units, table.headers)
    zscore_values = _build_zscore_map(
        measurements,
        template.report.zscore_thresholds,
        columns,
        zscore_threshold_override=zscore_threshold_override,
    )
    golden_reference = _load_built_golden_reference(built_golden_path)
    golden_values = _build_report_golden_values(
        measurements,
        template,
        columns,
        golden_reference=golden_reference,
    )

    failures: list[AnomalyResult] = []
    for measurement in measurements:
        key = _measurement_key(measurement)
        z_entry = zscore_values.get(key)
        if z_entry and z_entry.is_fail:
            failures.append(
                AnomalyResult(
                    method="modified_z_score",
                    dataset_id=measurement.dataset_id,
                    source_file=measurement.source_file,
                    row_number=measurement.row_number,
                    logical_metric=measurement.logical_metric,
                    raw_column=measurement.raw_column,
                    value=measurement.value,
                    dimensions=measurement.dimensions,
                    center=None,
                    score=z_entry.value,
                    reason=(
                        "Absolute modified z-score exceeded configured threshold "
                        f"{z_entry.threshold}."
                    ),
                )
            )
        golden_entry = golden_values.get(key)
        if golden_entry and golden_entry.is_fail:
            failures.append(
                AnomalyResult(
                    method="golden_deviation",
                    dataset_id=measurement.dataset_id,
                    source_file=measurement.source_file,
                    row_number=measurement.row_number,
                    logical_metric=measurement.logical_metric,
                    raw_column=measurement.raw_column,
                    value=measurement.value,
                    dimensions=measurement.dimensions,
                    center=golden_entry.golden_value,
                    score=golden_entry.value,
                    reason=(
                        "Golden deviation exceeded configured threshold "
                        f"{golden_entry.threshold}."
                    ),
                )
            )
    return failures


def collect_outlier_summary_rows(
    template_path: str | Path,
    input_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, str]]:
    return collect_outlier_summary_artifacts(
        template_path,
        input_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["summary_rows"]


def collect_outlier_ratio_rows(
    template_path: str | Path,
    input_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, Any]]:
    return collect_outlier_summary_artifacts(
        template_path,
        input_path,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["ratio_rows"]


def collect_outlier_summary_artifacts(
    template_path: str | Path,
    input_path: str | Path,
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    progress_callback: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    _emit_progress(progress_callback, 5, "Loading template for outlier summary...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 20, "Reading input workbook for outlier summary...")
    table = load_table(input_path, template=template)
    _emit_progress(progress_callback, 35, "Building measurement records for outlier summary...")
    measurements = _build_measurements(template, table.rows, input_path)
    _emit_progress(progress_callback, 50, "Building row view for outlier summary...")
    row_data = _build_rows(template, table.rows, input_path)
    _emit_progress(progress_callback, 65, "Resolving test columns for outlier summary...")
    columns = _build_columns(template, table.units, table.headers)
    return _collect_outlier_summary_artifacts_from_prebuilt(
        template,
        measurements,
        row_data,
        columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        outlier_merge_order_override=outlier_merge_order_override,
        outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def collect_outlier_summary_rows_from_measurements(
    template_path: str | Path,
    measurements: list[MeasurementRecord],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, str]]:
    return collect_outlier_summary_artifacts_from_measurements(
        template_path,
        measurements,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["summary_rows"]


def collect_outlier_ratio_rows_from_measurements(
    template_path: str | Path,
    measurements: list[MeasurementRecord],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, Any]]:
    return collect_outlier_summary_artifacts_from_measurements(
        template_path,
        measurements,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["ratio_rows"]


def collect_outlier_summary_artifacts_from_measurements(
    template_path: str | Path,
    measurements: list[MeasurementRecord],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    progress_callback: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    _emit_progress(progress_callback, 10, "Loading template for outlier summary...")
    template = load_template(template_path)
    _emit_progress(progress_callback, 35, "Building row view from database measurements...")
    row_data = _build_rows_from_measurements(measurements)
    _emit_progress(progress_callback, 55, "Resolving test columns for outlier summary...")
    columns = _build_columns(
        template,
        {},
        sorted({item.raw_column for item in measurements}),
    )
    return _collect_outlier_summary_artifacts_from_prebuilt(
        template,
        measurements,
        row_data,
        columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        outlier_merge_order_override=outlier_merge_order_override,
        outlier_treat_empty_cells_as_fail_override=outlier_treat_empty_cells_as_fail_override,
        zscore_threshold_override=zscore_threshold_override,
        progress_callback=progress_callback,
    )


def _collect_outlier_summary_rows_from_prebuilt(
    template: TemplateConfig,
    measurements: list[MeasurementRecord],
    row_data: list[RowData],
    columns: list[ColumnMeta],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    zscore_threshold_override: float | None = None,
) -> list[dict[str, str]]:
    return _collect_outlier_summary_artifacts_from_prebuilt(
        template,
        measurements,
        row_data,
        columns,
        built_golden_path=built_golden_path,
        outlier_fail_method_override=outlier_fail_method_override,
        zscore_threshold_override=zscore_threshold_override,
    )["summary_rows"]


def _collect_outlier_summary_artifacts_from_prebuilt(
    template: TemplateConfig,
    measurements: list[MeasurementRecord],
    row_data: list[RowData],
    columns: list[ColumnMeta],
    built_golden_path: str | Path | None = None,
    outlier_fail_method_override: str | None = None,
    outlier_merge_order_override: str | None = None,
    outlier_treat_empty_cells_as_fail_override: bool | None = None,
    zscore_threshold_override: float | None = None,
    progress_callback: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    _emit_progress(progress_callback, 70, "Calculating Z Score for outlier summary...")
    sample_node_orders = _build_sample_node_orders(row_data, template)
    row_data.sort(key=lambda item: _row_sort_key(item, template, sample_node_orders))
    fail_mode = outlier_fail_method_override or template.report.outlier_fail_method
    if outlier_merge_order_override:
        template.report.outlier_merge_order = outlier_merge_order_override
    if outlier_treat_empty_cells_as_fail_override is not None:
        template.report.outlier_treat_empty_cells_as_fail = bool(
            outlier_treat_empty_cells_as_fail_override
        )
    if _fail_mode_requires_golden(fail_mode) and not built_golden_path:
        raise ValueError(
            "Golden File is required when Outlier Criteria uses Golden Deviation."
        )
    zscore_values = _build_zscore_map(
        measurements,
        template.report.zscore_thresholds,
        columns,
        zscore_threshold_override=zscore_threshold_override,
    )
    _emit_progress(progress_callback, 82, "Calculating golden deviation for outlier summary...")
    golden_reference = _load_built_golden_reference(built_golden_path)
    golden_values = _build_report_golden_values(
        measurements,
        template,
        columns,
        golden_reference=golden_reference,
    )
    _emit_progress(progress_callback, 94, "Collecting outlier summary rows...")
    return _collect_outlier_summary_artifacts(
        template,
        columns,
        row_data,
        zscore_values,
        golden_values,
        sample_node_orders,
        outlier_fail_method_override=fail_mode,
    )


def _build_measurements(
    template: TemplateConfig,
    rows: list[dict[str, Any]],
    input_path: str | Path,
) -> list[MeasurementRecord]:
    source_file = str(Path(input_path).resolve())
    measurements: list[MeasurementRecord] = []
    for row_number, row, dimensions in extract_dimension_rows(template, rows):
        for group in template.analysis_groups:
            for column in group.columns:
                if column.name not in row:
                    continue
                value = to_float(row.get(column.name), template.numeric_cleanup)
                if value is None:
                    continue
                logical_metric = (
                    group.id
                    if group.analysis_mode == "pooled_columns"
                    else f"{group.id}::{column.name}"
                )
                measurements.append(
                    MeasurementRecord(
                        dataset_id="ad-hoc-report",
                        source_file=source_file,
                        row_number=row_number,
                        logical_metric=logical_metric,
                        group_id=group.id,
                        group_display_name=group.display_name,
                        presentation_group=column.header_values[0] if column.header_values else None,
                        raw_column=column.name,
                        value=value,
                        dimensions=dimensions,
                    )
                )
    return measurements


def _build_rows(
    template: TemplateConfig,
    rows: list[dict[str, Any]],
    input_path: str | Path,
) -> list[RowData]:
    report_rows: list[RowData] = []
    source_file = str(Path(input_path).resolve())
    measurement_columns = {
        column.name
        for group in template.analysis_groups
        for column in group.columns
    }
    for row_number, row, dimensions in extract_dimension_rows(template, rows):
        values: dict[str, float] = {}
        for column in measurement_columns:
            if column not in row:
                continue
            value = to_float(row.get(column), template.numeric_cleanup)
            if value is not None:
                values[column] = value
        report_rows.append(
            RowData(
                dataset_id="ad-hoc-report",
                source_file=source_file,
                row_number=row_number,
                dimensions=dimensions,
                values=values,
            )
        )
    return report_rows


def _build_rows_from_measurements(measurements: list[MeasurementRecord]) -> list[RowData]:
    grouped: dict[tuple[str, str, int, tuple[tuple[str, str], ...]], RowData] = {}
    for item in measurements:
        dimension_key = tuple(sorted(item.dimensions.items()))
        row_key = (item.dataset_id, item.source_file, item.row_number, dimension_key)
        row = grouped.get(row_key)
        if row is None:
            row = RowData(
                dataset_id=item.dataset_id,
                source_file=item.source_file,
                row_number=item.row_number,
                dimensions=dict(item.dimensions),
                values={},
            )
            grouped[row_key] = row
        row.values[item.raw_column] = item.value
    return list(grouped.values())


def _build_columns(
    template: TemplateConfig,
    units: dict[str, str],
    headers: list[str],
) -> list[ColumnMeta]:
    header_set = set(headers)
    columns: list[ColumnMeta] = []
    display_order = 0
    for group in template.analysis_groups:
        for column in group.columns:
            if header_set and column.name not in header_set:
                continue
            logical_metric = (
                group.id
                if group.analysis_mode == "pooled_columns"
                else f"{group.id}::{column.name}"
            )
            columns.append(
                ColumnMeta(
                    raw_column=column.name,
                    logical_metric=logical_metric,
                    group_id=group.id,
                    group_display_name=group.display_name,
                    header_values=list(column.header_values),
                    unit=group.unit,
                    column_order=column.column_order,
                    display_order=display_order,
                )
            )
            display_order += 1
    return sorted(
        columns,
        key=lambda item: (
            item.column_order if item.column_order is not None else 10**9,
            tuple(_natural_sort_key(value) for value in item.header_values),
            item.display_order,
        ),
    )


def _build_zscore_map(
    measurements: list[MeasurementRecord],
    thresholds: ThresholdConfig,
    columns: list[ColumnMeta],
    zscore_threshold_override: float | None = None,
) -> dict[MetricKey, MetricValue]:
    column_index = {item.raw_column: item for item in columns}
    evaluations = evaluate_modified_zscore(measurements)
    values: dict[MetricKey, MetricValue] = {}
    for entry in evaluations:
        meta = column_index.get(entry.raw_column)
        if meta is None:
            continue
        threshold = zscore_threshold_override
        if threshold is None:
            threshold = _resolve_threshold(
                thresholds,
                [entry.logical_metric, entry.raw_column, meta.group_id, meta.chain_name],
            )
        score = abs(entry.score) if entry.score is not None else 0.0
        values[_anomaly_key(entry)] = MetricValue(
            value=score,
            threshold=threshold,
            golden_value=None,
            is_fail=threshold is not None and abs(score) > threshold,
        )
    return values


def _build_golden_deviation_map(
    measurements: list[MeasurementRecord],
    columns: list[ColumnMeta],
) -> dict[MetricKey, MetricValue]:
    del measurements
    del columns
    return {}


def _load_built_golden_reference(
    built_golden_path: str | Path | None,
) -> GoldenReference | None:
    if not built_golden_path:
        return None
    return GoldenReference.from_dict(
        json.loads(Path(built_golden_path).read_text(encoding="utf-8"))
    )


def _build_built_golden_deviation_map(
    measurements: list[MeasurementRecord],
    golden_reference: GoldenReference,
) -> dict[MetricKey, MetricValue]:
    values: dict[MetricKey, MetricValue] = {}
    evaluations = evaluate_against_golden(measurements, golden_reference)
    for entry in evaluations:
        golden_value = entry.center
        deviation, threshold = _resolve_built_metric_display(entry)
        values[_anomaly_key(entry)] = MetricValue(
            value=deviation,
            threshold=threshold,
            golden_value=golden_value,
            is_fail=entry.reason is not None,
            lower_bound=entry.lower_bound,
            upper_bound=entry.upper_bound,
            allowed_ranges=list(entry.allowed_ranges),
            outlier_display_value=_resolve_built_metric_outlier_display_value(entry),
            outlier_number_format=_resolve_built_metric_outlier_display_format(entry),
            absolute_rule_failed=_built_metric_absolute_rule_failed(entry),
        )
    return values


def _build_report_golden_values(
    measurements: list[MeasurementRecord],
    template: TemplateConfig,
    columns: list[ColumnMeta],
    golden_reference: GoldenReference | None,
) -> dict[MetricKey, MetricValue]:
    del template
    if golden_reference is not None:
        return _build_built_golden_deviation_map(measurements, golden_reference)
    return _build_golden_deviation_map(measurements, columns)


def _build_golden_fallback_warning_rows(
    golden_reference: GoldenReference | None,
) -> list[dict[str, str]]:
    if golden_reference is None:
        return []
    rows: list[dict[str, str]] = []
    for metric in golden_reference.metrics:
        if not metric.empty_range_fallback_used:
            continue
        reference_text = (
            ", ".join(f"{key}={value}" for key, value in metric.reference_key.items())
            if metric.reference_key
            else "<global>"
        )
        ranges_text = _format_allowed_ranges_display(metric.allowed_ranges)
        rows.append(
            {
                "id": "Golden fallback",
                "warning": (
                    "Golden allowed range 为空："
                    f"logical_metric={metric.logical_metric}, reference_key={reference_text}。"
                    "按照 AND/交集标准没有交集，已经 fallback 到 absolute 数值范围 "
                    f"{ranges_text}。请注意判断是否所有样品均失效。"
                ),
            }
        )
    return rows


def _column_header_labels(template: TemplateConfig) -> list[str]:
    return [item.name for item in sorted(template.column_header_levels, key=lambda item: item.priority)]


def _ordered_row_dimensions(template: TemplateConfig):
    return sorted(template.row_dimensions, key=lambda item: item.priority)


def _outlier_row_merge_dimension_names(template: TemplateConfig) -> list[str]:
    ordered_dimensions = _ordered_row_dimensions(template)
    names = [item.name for item in ordered_dimensions]
    max_dimension = template.report.outlier_row_merge_max_dimension
    if not max_dimension or max_dimension not in names:
        return names
    return names[names.index(max_dimension) :]


def _outlier_row_group_dimension_names(template: TemplateConfig) -> list[str]:
    ordered_dimensions = _ordered_row_dimensions(template)
    names = [item.name for item in ordered_dimensions]
    max_dimension = template.report.outlier_row_merge_max_dimension
    if not max_dimension or max_dimension not in names:
        return []
    return names[: names.index(max_dimension)]


def _outlier_node_group_dimension_names(template: TemplateConfig) -> list[str]:
    ordered_dimensions = _ordered_row_dimensions(template)
    names = [item.name for item in ordered_dimensions]
    if "reliability_node" not in names:
        return names
    return names[: names.index("reliability_node") + 1]


def _node_dimension_label(template: TemplateConfig) -> str:
    for item in _ordered_row_dimensions(template):
        if item.name == "reliability_node":
            return item.display_name or item.name
    return "Node"


def _outlier_row_group_key(
    row: RowData,
    template: TemplateConfig,
) -> tuple[str, ...]:
    return tuple(
        str(row.dimensions.get(name, "") or "")
        for name in _outlier_row_group_dimension_names(template)
    )


def _outlier_row_group_extra_dimension_names(template: TemplateConfig) -> list[str]:
    sample_dimensions = set(_sample_dimension_names(template))
    return [
        name
        for name in _outlier_row_group_dimension_names(template)
        if name not in sample_dimensions
    ]


def _outlier_row_group_header_label(template: TemplateConfig) -> str:
    extra_names = _outlier_row_group_extra_dimension_names(template)
    if len(extra_names) == 1:
        match = next(
            (item for item in _ordered_row_dimensions(template) if item.name == extra_names[0]),
            None,
        )
        return (match.display_name or match.name) if match else extra_names[0]
    return "Row Group"


def _outlier_row_group_display(
    dimensions: dict[str, str],
    template: TemplateConfig,
) -> str:
    extra_names = _outlier_row_group_extra_dimension_names(template)
    if not extra_names:
        return "All Rows"
    values = [str(dimensions.get(name, "") or "").strip() for name in extra_names]
    return " | ".join(value for value in values if value)


def _outlier_test_merge_level_index(template: TemplateConfig) -> int:
    labels = _column_header_labels(template)
    max_level = template.report.outlier_test_merge_max_level
    if not max_level or max_level not in labels:
        return max(0, len(labels) - 1)
    return labels.index(max_level)


def _outlier_test_group_key(column: ColumnMeta, template: TemplateConfig) -> tuple[str, ...]:
    index = _outlier_test_merge_level_index(template)
    return tuple(column.header_values[:index])


def _outlier_test_group_display(test_group_key: tuple[str, ...]) -> str:
    if not test_group_key:
        return "All Tests"
    return " | ".join(str(value).strip() for value in test_group_key if str(value).strip())


def _outlier_test_group_header_label(template: TemplateConfig) -> str:
    labels = _column_header_labels(template)
    max_level = template.report.outlier_test_merge_max_level
    if not max_level or max_level not in labels:
        return "Test Group"
    index = labels.index(max_level)
    if index == 0:
        return "Test Group"
    return labels[index - 1]


def _group_columns_by_outlier_test_group(
    template: TemplateConfig,
    columns: list[ColumnMeta],
) -> dict[tuple[str, ...], list[ColumnMeta]]:
    grouped: dict[tuple[str, ...], list[ColumnMeta]] = defaultdict(list)
    for column in columns:
        grouped[_outlier_test_group_key(column, template)].append(column)
    return grouped


def _top_level_test_group_key(column: ColumnMeta) -> tuple[str, ...]:
    return tuple(column.header_values[:1])


def _top_level_test_group_display(column_key: tuple[str, ...]) -> str:
    if not column_key:
        return "All Tests"
    return str(column_key[0] or "")


def _ordered_column_levels(template: TemplateConfig) -> list[str]:
    return _column_header_labels(template)


def _row_dimension_names(template: TemplateConfig) -> list[str]:
    return [item.name for item in _ordered_row_dimensions(template)]


def _reliability_node_index(template: TemplateConfig) -> int:
    names = _row_dimension_names(template)
    if "reliability_node" not in names:
        return max(0, len(names) - 1)
    return names.index("reliability_node")


def _row_merge_prefix_length(template: TemplateConfig) -> int:
    names = _row_dimension_names(template)
    max_dimension = template.report.outlier_row_merge_max_dimension
    if not max_dimension or max_dimension not in names:
        return len(names)
    return names.index(max_dimension)


def _column_merge_prefix_length(template: TemplateConfig) -> int:
    return _outlier_test_merge_level_index(template)


def _merge_rule_for_step(template: TemplateConfig, step: str) -> str:
    if step == "column_merge":
        return template.report.outlier_merged_test_fail_rule
    if step == "column_group":
        return template.report.outlier_test_group_fail_rule
    if step == "row_merge":
        return template.report.outlier_merged_sample_fail_rule
    if step == "row_node":
        return template.report.outlier_node_fail_rule
    raise ValueError(f"Unsupported merge step: {step}")


def _target_prefix_lengths(template: TemplateConfig, step: str) -> tuple[int, int]:
    row_names = _row_dimension_names(template)
    column_levels = _ordered_column_levels(template)
    if step == "column_merge":
        return (len(row_names), _column_merge_prefix_length(template))
    if step == "column_group":
        return (len(row_names), 1 if column_levels else 0)
    if step == "row_merge":
        return (_row_merge_prefix_length(template), len(column_levels))
    if step == "row_node":
        return (_reliability_node_index(template) + 1, len(column_levels))
    raise ValueError(f"Unsupported merge step: {step}")


def _outlier_merge_steps(template: TemplateConfig) -> tuple[str, ...]:
    return OUTLIER_MERGE_ORDER_STEPS[template.report.outlier_merge_order]


def _build_leaf_records(
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
    fail_mode: str,
) -> list[LeafRecord]:
    row_dimension_names = _row_dimension_names(template)
    sample_dimension_names = _sample_dimension_names(template)
    leaf_records: list[LeafRecord] = []
    for row in rows:
        row_path = tuple(str(row.dimensions.get(name, "") or "") for name in row_dimension_names)
        sample_key = _sample_key_from_dimensions(row.dimensions, sample_dimension_names)
        node_value = str(row.dimensions.get("reliability_node", "") or "")
        raw_row_key = (row.dataset_id, row.row_number)
        for column in columns:
            if column.raw_column not in row.values:
                if not template.report.outlier_treat_empty_cells_as_fail:
                    continue
                z_entry = None
                golden_entry = None
                is_fail = True
            else:
                z_entry = zscore_values.get(_row_metric_key(row, column.raw_column))
                golden_entry = golden_values.get(_row_metric_key(row, column.raw_column))
                is_fail = _is_metric_fail(fail_mode, z_entry, golden_entry)
            leaf_records.append(
                LeafRecord(
                    row_path=row_path,
                    column_path=tuple(column.header_values),
                    sample_key=sample_key,
                    node_value=node_value,
                    dimensions=dict(row.dimensions),
                    raw_row_key=raw_row_key,
                    raw_column=column.raw_column,
                    logical_metric=column.logical_metric,
                    group_id=column.group_id,
                    group_display_name=column.group_display_name,
                    test_type=column.test_type,
                    chain_name=column.chain_name,
                    unit=column.unit,
                    is_fail=is_fail,
                )
            )
    return leaf_records


def _leaf_matches_ratio_config(
    record: LeafRecord,
    config: OutlierRatioStatConfig,
) -> bool:
    if config.group_ids and record.group_id not in config.group_ids:
        return False
    if config.group_display_names and record.group_display_name not in config.group_display_names:
        return False
    if config.test_types and record.test_type not in config.test_types:
        return False
    effective_chain_names = config.chain_names or config.chains
    if effective_chain_names and record.chain_name not in effective_chain_names:
        return False
    effective_column_names = config.column_names or config.raw_columns
    if effective_column_names and record.raw_column not in effective_column_names:
        return False
    if config.units and str(record.unit or "") not in config.units:
        return False
    if config.logical_metrics and record.logical_metric not in config.logical_metrics:
        return False
    return True


def _merge_records_from_leaves(
    leaf_records: list[LeafRecord],
) -> list[MergeRecord]:
    return [
        MergeRecord(
            row_key=record.row_path,
            column_key=record.column_path,
            is_fail=record.is_fail,
            sample_key=record.sample_key,
            node_value=record.node_value,
            dimensions=dict(record.dimensions),
            raw_row_keys={record.raw_row_key},
            raw_columns={record.raw_column},
            logical_metrics={record.logical_metric},
            group_ids={record.group_id},
            group_display_names={record.group_display_name},
            test_types={record.test_type} if record.test_type else set(),
            chain_names={record.chain_name} if record.chain_name else set(),
            column_names={record.raw_column},
            units={str(record.unit)} if record.unit not in {None, ""} else set(),
        )
        for record in leaf_records
    ]


def _merge_record_matches_ratio_config(
    record: MergeRecord,
    config: OutlierRatioStatConfig,
) -> bool:
    if config.group_ids and record.group_ids.isdisjoint(config.group_ids):
        return False
    if config.group_display_names and record.group_display_names.isdisjoint(config.group_display_names):
        return False
    if config.test_types and record.test_types.isdisjoint(config.test_types):
        return False
    effective_chain_names = config.chain_names or config.chains
    if effective_chain_names and record.chain_names.isdisjoint(effective_chain_names):
        return False
    effective_column_names = config.column_names or config.raw_columns
    if effective_column_names and record.column_names.isdisjoint(effective_column_names):
        return False
    if config.units and record.units.isdisjoint(config.units):
        return False
    if config.logical_metrics and record.logical_metrics.isdisjoint(config.logical_metrics):
        return False
    return True


def _merge_records_step(
    records: list[MergeRecord],
    template: TemplateConfig,
    step: str,
) -> list[MergeRecord]:
    if not records:
        return []
    row_target_length, column_target_length = _target_prefix_lengths(template, step)
    rule = _merge_rule_for_step(template, step)
    grouped: dict[tuple[tuple[str, ...], tuple[str, ...]], list[MergeRecord]] = defaultdict(list)
    for record in records:
        target_row_key = record.row_key[: min(len(record.row_key), row_target_length)]
        target_column_key = record.column_key[: min(len(record.column_key), column_target_length)]
        grouped[(target_row_key, target_column_key)].append(record)

    merged_records: list[MergeRecord] = []
    for (target_row_key, target_column_key), items in grouped.items():
        statuses = [item.is_fail for item in items]
        is_fail = all(statuses) if rule == "all_fail" else any(statuses)
        merged_records.append(
            MergeRecord(
                row_key=target_row_key,
                column_key=target_column_key,
                is_fail=is_fail,
                sample_key=items[0].sample_key,
                node_value=str(items[0].dimensions.get("reliability_node", "") or ""),
                dimensions=dict(items[0].dimensions),
                raw_row_keys=set().union(*(item.raw_row_keys for item in items)),
                raw_columns=set().union(*(item.raw_columns for item in items)),
                logical_metrics=set().union(*(item.logical_metrics for item in items)),
                group_ids=set().union(*(item.group_ids for item in items)),
                group_display_names=set().union(*(item.group_display_names for item in items)),
                test_types=set().union(*(item.test_types for item in items)),
                chain_names=set().union(*(item.chain_names for item in items)),
                column_names=set().union(*(item.column_names for item in items)),
                units=set().union(*(item.units for item in items)),
            )
        )
    return merged_records


def _execute_outlier_merge_pipeline(
    template: TemplateConfig,
    leaf_records: list[LeafRecord],
) -> list[MergeRecord]:
    current_records = _merge_records_from_leaves(leaf_records)
    return _execute_outlier_merge_pipeline_from_records(template, current_records)


def _execute_outlier_merge_pipeline_from_records(
    template: TemplateConfig,
    current_records: list[MergeRecord],
) -> list[MergeRecord]:
    for step in _outlier_merge_steps(template):
        current_records = _merge_records_step(current_records, template, step)
    return current_records


def _top_level_any_fail_records(
    template: TemplateConfig,
    leaf_records: list[LeafRecord],
) -> list[MergeRecord]:
    records = _merge_records_from_leaves(leaf_records)
    return _top_level_any_fail_records_from_records(template, records)


def _top_level_any_fail_records_from_records(
    template: TemplateConfig,
    records: list[MergeRecord],
) -> list[MergeRecord]:
    row_target_length = _reliability_node_index(template) + 1
    column_target_length = 1 if _ordered_column_levels(template) else 0
    grouped: dict[tuple[tuple[str, ...], tuple[str, ...]], list[MergeRecord]] = defaultdict(list)
    for record in records:
        grouped[(record.row_key[:row_target_length], record.column_key[:column_target_length])].append(record)
    merged: list[MergeRecord] = []
    for (row_key, column_key), items in grouped.items():
        merged.append(
            MergeRecord(
                row_key=row_key,
                column_key=column_key,
                is_fail=any(item.is_fail for item in items),
                sample_key=items[0].sample_key,
                node_value=str(items[0].dimensions.get("reliability_node", "") or ""),
                dimensions=dict(items[0].dimensions),
                raw_row_keys=set().union(*(item.raw_row_keys for item in items)),
                raw_columns=set().union(*(item.raw_columns for item in items)),
                logical_metrics=set().union(*(item.logical_metrics for item in items)),
                group_ids=set().union(*(item.group_ids for item in items)),
                group_display_names=set().union(*(item.group_display_names for item in items)),
                test_types=set().union(*(item.test_types for item in items)),
                chain_names=set().union(*(item.chain_names for item in items)),
                column_names=set().union(*(item.column_names for item in items)),
                units=set().union(*(item.units for item in items)),
            )
        )
    return merged


def _row_group_sort_key(
    row_group_key: tuple[str, ...],
    row_group_dimension_names: list[str],
    node_order: list[str],
) -> tuple[Any, ...]:
    values: list[Any] = []
    for dimension_name, value in zip(row_group_dimension_names, row_group_key):
        if dimension_name == "reliability_node":
            values.append(_node_sort_key(value, node_order))
        else:
            values.append(_natural_sort_key(value))
    return tuple(values)


def _write_column_header_rows(
    worksheet,
    start_row: int,
    label_column: int,
    data_start_column: int,
    header_labels: list[str],
    columns: list[ColumnMeta],
) -> None:
    for level_index, label in enumerate(header_labels):
        worksheet.cell(start_row + level_index, label_column, label)
        for offset, column in enumerate(columns):
            worksheet.cell(
                start_row + level_index,
                data_start_column + offset,
                column.header_values[level_index],
            )


def _write_sorted_sheet(
    worksheet,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    golden_header_values: dict[str, Any],
    golden_bound_values: dict[str, Any],
) -> None:
    columns = _sort_columns_for_tree_display(columns)
    ordered_dimensions = _ordered_row_dimensions(template)
    dimension_labels = [item.display_name or item.name for item in ordered_dimensions]
    header_labels = _column_header_labels(template)
    label_column = len(dimension_labels)
    data_start_column = label_column + 1
    first_row = 1

    _write_column_header_rows(
        worksheet,
        first_row,
        label_column,
        data_start_column,
        header_labels,
        columns,
    )
    golden_row = first_row + len(header_labels)
    golden_bound_row = golden_row + 1
    unit_row = golden_bound_row + 1
    dimension_header_row = unit_row + 1
    worksheet.cell(golden_row, label_column, "Golden")
    worksheet.cell(golden_bound_row, label_column, "Golden Bounds")
    for offset, column in enumerate(columns):
        cell_column = data_start_column + offset
        worksheet.cell(golden_row, cell_column, golden_header_values.get(column.raw_column))
        worksheet.cell(golden_bound_row, cell_column, golden_bound_values.get(column.raw_column))
        worksheet.cell(unit_row, cell_column, column.unit)

    for index, label in enumerate(dimension_labels, start=1):
        worksheet.cell(dimension_header_row, index, label)

    data_start_row = dimension_header_row + 1
    for row_offset, row in enumerate(rows):
        target_row = data_start_row + row_offset
        for index, dimension in enumerate(ordered_dimensions, start=1):
            worksheet.cell(
                target_row,
                index,
                _display_dimension_value(row.dimensions.get(dimension.name)),
            )
        for column_offset, column in enumerate(columns):
            worksheet.cell(target_row, data_start_column + column_offset, row.values.get(column.raw_column))

    _style_sheet(
        worksheet,
        header_rows=list(range(first_row, unit_row + 1)),
        dimension_header_row=dimension_header_row,
        start_column=label_column,
        end_column=data_start_column + len(columns) - 1,
        dimension_count=len(dimension_labels),
        table_start_row=first_row,
        table_end_row=data_start_row + len(rows) - 1,
    )
    _merge_column_header_rows(worksheet, first_row, data_start_column, columns, len(header_labels))
    _merge_dimension_values(
        worksheet,
        data_start_row,
        len(rows),
        template,
        row_dimension_values=[
            tuple(_display_dimension_value(row.dimensions.get(dimension.name)) for dimension in ordered_dimensions)
            for row in rows
        ],
    )
    _autosize_columns(worksheet)


def _write_metric_sheet(
    worksheet,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    values: dict[MetricKey, MetricValue],
    threshold_header_values: dict[str, Any],
    golden_header_values: dict[str, Any],
    golden_bound_values: dict[str, Any],
    threshold_label: str,
    value_number_format: str | None = None,
    threshold_number_format: str | None = None,
) -> None:
    columns = _sort_columns_for_tree_display(columns)
    ordered_dimensions = _ordered_row_dimensions(template)
    dimension_labels = [item.display_name or item.name for item in ordered_dimensions]
    header_labels = _column_header_labels(template)
    label_column = len(dimension_labels)
    data_start_column = label_column + 1

    _write_column_header_rows(
        worksheet,
        1,
        label_column,
        data_start_column,
        header_labels,
        columns,
    )
    threshold_row = 1 + len(header_labels)
    golden_row = threshold_row + 1
    golden_bound_row = golden_row + 1
    unit_row = golden_bound_row + 1
    dimension_header_row = unit_row + 1
    worksheet.cell(threshold_row, label_column, threshold_label)
    worksheet.cell(golden_row, label_column, "Golden")
    worksheet.cell(golden_bound_row, label_column, "Golden Bounds")

    for offset, column in enumerate(columns):
        cell_column = data_start_column + offset
        threshold_cell = worksheet.cell(
            threshold_row,
            cell_column,
            threshold_header_values.get(column.raw_column),
        )
        if threshold_number_format and isinstance(threshold_cell.value, (int, float)):
            threshold_cell.number_format = threshold_number_format
        worksheet.cell(golden_row, cell_column, golden_header_values.get(column.raw_column))
        worksheet.cell(golden_bound_row, cell_column, golden_bound_values.get(column.raw_column))
        worksheet.cell(unit_row, cell_column, column.unit)

    for index, label in enumerate(dimension_labels, start=1):
        worksheet.cell(dimension_header_row, index, label)

    data_start_row = dimension_header_row + 1
    for row_offset, row in enumerate(rows):
        target_row = data_start_row + row_offset
        for index, dimension in enumerate(ordered_dimensions, start=1):
            worksheet.cell(
                target_row,
                index,
                _display_dimension_value(row.dimensions.get(dimension.name)),
            )
        for column_offset, column in enumerate(columns):
            entry = values.get(_row_metric_key(row, column.raw_column))
            cell = worksheet.cell(
                target_row,
                data_start_column + column_offset,
                entry.value if entry else None,
            )
            if entry and value_number_format and isinstance(cell.value, (int, float)):
                cell.number_format = value_number_format
            if entry and entry.is_fail:
                _apply_style_parts(cell, font=FAIL_FONT)

    _style_sheet(
        worksheet,
        header_rows=list(range(1, unit_row + 1)),
        dimension_header_row=dimension_header_row,
        start_column=label_column,
        end_column=data_start_column + len(columns) - 1,
        dimension_count=len(dimension_labels),
        table_start_row=1,
        table_end_row=data_start_row + len(rows) - 1,
    )
    _merge_column_header_rows(worksheet, 1, data_start_column, columns, len(header_labels))
    _merge_dimension_values(
        worksheet,
        data_start_row,
        len(rows),
        template,
        row_dimension_values=[
            tuple(_display_dimension_value(row.dimensions.get(dimension.name)) for dimension in ordered_dimensions)
            for row in rows
        ],
    )
    _autosize_columns(worksheet)


def _write_point_golden_sheet(
    worksheet,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    golden_values: dict[MetricKey, MetricValue],
    golden_header_values: dict[str, Any],
) -> None:
    columns = _sort_columns_for_tree_display(columns)
    ordered_dimensions = _ordered_row_dimensions(template)
    dimension_labels = [item.display_name or item.name for item in ordered_dimensions]
    header_labels = _column_header_labels(template)
    label_column = len(dimension_labels)
    data_start_column = label_column + 1
    first_row = 1

    worksheet.cell(first_row, 1, "Matched Built Golden For Each Data Point")
    header_start_row = first_row + 1
    _write_column_header_rows(
        worksheet,
        header_start_row,
        label_column,
        data_start_column,
        header_labels,
        columns,
    )
    golden_row = header_start_row + len(header_labels)
    unit_row = golden_row + 1
    dimension_header_row = unit_row + 1
    worksheet.cell(golden_row, label_column, "Golden")

    for offset, column in enumerate(columns):
        cell_column = data_start_column + offset
        worksheet.cell(golden_row, cell_column, golden_header_values.get(column.raw_column))
        worksheet.cell(unit_row, cell_column, column.unit)

    for index, label in enumerate(dimension_labels, start=1):
        worksheet.cell(dimension_header_row, index, label)

    data_start_row = dimension_header_row + 1
    for row_offset, row in enumerate(rows):
        target_row = data_start_row + row_offset
        for index, dimension in enumerate(ordered_dimensions, start=1):
            worksheet.cell(
                target_row,
                index,
                _display_dimension_value(row.dimensions.get(dimension.name)),
            )
        for column_offset, column in enumerate(columns):
            entry = golden_values.get(_row_metric_key(row, column.raw_column))
            worksheet.cell(
                target_row,
                data_start_column + column_offset,
                entry.golden_value if entry else None,
            )

    _style_sheet(
        worksheet,
        header_rows=[first_row] + list(range(header_start_row, unit_row + 1)),
        dimension_header_row=dimension_header_row,
        start_column=label_column,
        end_column=data_start_column + len(columns) - 1,
        dimension_count=len(dimension_labels),
        table_start_row=first_row,
        table_end_row=data_start_row + len(rows) - 1,
    )
    if data_start_column + len(columns) - 1 >= 1:
        worksheet.merge_cells(
            start_row=first_row,
            start_column=1,
            end_row=first_row,
            end_column=data_start_column + len(columns) - 1,
        )
    _merge_column_header_rows(
        worksheet,
        header_start_row,
        data_start_column,
        columns,
        len(header_labels),
    )
    _merge_dimension_values(
        worksheet,
        data_start_row,
        len(rows),
        template,
        row_dimension_values=[
            tuple(_display_dimension_value(row.dimensions.get(dimension.name)) for dimension in ordered_dimensions)
            for row in rows
        ],
    )
    _autosize_columns(worksheet)


def _write_outlier_sheet(
    worksheet,
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
    golden_header_values: dict[str, Any],
    golden_bound_values: dict[str, Any],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    outlier_rows: list[dict[str, Any]],
    highlight_rows: list[dict[str, Any]] | None = None,
    outlier_fail_method_override: str | None = None,
) -> None:
    columns = _sort_columns_for_tree_display(columns)
    ordered_dimensions = _ordered_row_dimensions(template)
    dimension_labels = [item.display_name or item.name for item in ordered_dimensions]
    header_labels = _column_header_labels(template)
    sample_dimension_names = _sample_dimension_names(template)
    fail_mode = outlier_fail_method_override or template.report.outlier_fail_method
    test_group_columns: dict[tuple[str, ...], list[ColumnMeta]] = defaultdict(list)
    raw_column_to_top_group_key: dict[str, tuple[str, ...]] = {}
    for column in columns:
        top_group_key = _top_level_test_group_key(column)
        test_group_columns[top_group_key].append(column)
        raw_column_to_top_group_key[column.raw_column] = top_group_key

    current_row = 1
    worksheet.cell(1, 1, f"Current Outlier Criteria: {_format_fail_mode(fail_mode)}")

    rows_by_sample: dict[tuple[str, ...], list[RowData]] = defaultdict(list)
    for row in rows:
        rows_by_sample[_sample_key_from_dimensions(row.dimensions, sample_dimension_names)].append(row)

    highlight_map: dict[tuple[tuple[str, ...], str, str], str] = {}
    highlight_priority = {"merged_fail": 1, "recovered": 2, "new_fail": 3}
    selected_row_keys_by_sample: dict[tuple[str, ...], set[tuple[str, int]]] = defaultdict(set)
    selected_top_groups_by_sample: dict[tuple[str, ...], set[tuple[str, ...]]] = defaultdict(set)
    selected_nodes_by_sample: dict[tuple[str, ...], set[str]] = defaultdict(set)
    for item in outlier_rows:
        sample_key = tuple(str(value) for value in item.get("sample_key", []))
        node_value = str(item.get("node", "") or "")
        test_group_key = tuple(str(value) for value in item.get("test_group_key", []))
        status = str(item.get("status", "") or "")
        raw_columns = [str(value) for value in item.get("raw_columns", [])]
        resolved_top_group_keys: set[tuple[str, ...]] = set()
        if test_group_key:
            resolved_top_group_keys.add(test_group_key)
        for raw_column in raw_columns:
            top_group_key = raw_column_to_top_group_key.get(raw_column)
            if top_group_key:
                resolved_top_group_keys.add(top_group_key)
        if not sample_key or not node_value or not resolved_top_group_keys:
            continue
        selected_top_groups_by_sample[sample_key].update(resolved_top_group_keys)
        selected_nodes_by_sample[sample_key].add(node_value)
        for raw_row_key in item.get("raw_row_keys", []):
            if isinstance(raw_row_key, (list, tuple)) and len(raw_row_key) >= 2:
                try:
                    selected_row_keys_by_sample[sample_key].add((str(raw_row_key[0]), int(raw_row_key[1])))
                except Exception:
                    continue
    for item in highlight_rows or outlier_rows:
        sample_key = tuple(str(value) for value in item.get("sample_key", []))
        node_value = str(item.get("node", "") or "")
        status = str(item.get("status", "") or "")
        raw_columns = [str(value) for value in item.get("raw_columns", [])]
        if not sample_key or not node_value or not status:
            continue
        if status == "New":
            highlight_status = "new_fail"
        elif status == "Recovered":
            highlight_status = "recovered"
        elif status == "Existed":
            highlight_status = "merged_fail"
        else:
            continue
        for raw_column in raw_columns:
            key = (sample_key, node_value, raw_column)
            existing = highlight_map.get(key)
            if existing and highlight_priority[existing] >= highlight_priority[highlight_status]:
                continue
            highlight_map[key] = highlight_status

    first_block = True
    for sample_key in sorted(rows_by_sample, key=_sample_key_sort_key):
        sample_rows = [
            row
            for row in rows_by_sample[sample_key]
            if (
                not selected_row_keys_by_sample.get(sample_key)
                or (row.dataset_id, row.row_number) in selected_row_keys_by_sample[sample_key]
            )
            and (
                not selected_nodes_by_sample.get(sample_key)
                or str(row.dimensions.get("reliability_node", "") or "") in selected_nodes_by_sample[sample_key]
            )
        ]
        selected_test_groups = sorted(
            selected_top_groups_by_sample.get(sample_key, set()),
            key=lambda item: tuple(_natural_sort_key(value) for value in item),
        )
        if not selected_test_groups:
            continue
        if not first_block:
            current_row += 3
        first_block = False

        label_column = len(dimension_labels) + 1
        data_start_column = label_column + 1
        block_columns = [
            column
            for test_group_key in selected_test_groups
            for column in test_group_columns[test_group_key]
        ]
        top_group_column_ranges: list[tuple[int, int]] = []
        current_group_start = data_start_column
        for test_group_key in selected_test_groups:
            width = len(test_group_columns[test_group_key])
            if width <= 0:
                continue
            top_group_column_ranges.append((current_group_start, current_group_start + width - 1))
            current_group_start += width

        _write_column_header_rows(
            worksheet,
            current_row,
            label_column,
            data_start_column,
            header_labels,
            block_columns,
        )
        golden_row = current_row + len(header_labels)
        golden_bound_row = golden_row + 1
        unit_row = golden_bound_row + 1
        dimension_header_row = unit_row + 1
        worksheet.cell(golden_row, label_column, "Golden")
        worksheet.cell(golden_bound_row, label_column, "Golden Bounds")

        for offset, column in enumerate(block_columns):
            cell_column = data_start_column + offset
            worksheet.cell(golden_row, cell_column, golden_header_values.get(column.raw_column))
            worksheet.cell(golden_bound_row, cell_column, golden_bound_values.get(column.raw_column))
            worksheet.cell(unit_row, cell_column, column.unit)

        for index, label in enumerate(dimension_labels, start=1):
            worksheet.cell(dimension_header_row, index, label)

        block_data_start = dimension_header_row + 1
        sample_rows = sorted(
            sample_rows,
            key=lambda item: _row_sort_key(item, template, sample_node_orders),
        )
        sample_row_dimension_values = [
            tuple(_display_dimension_value(row.dimensions.get(dimension.name)) for dimension in ordered_dimensions)
            for row in sample_rows
        ]
        for sample_row_index, row in enumerate(sample_rows):
            row_base = block_data_start + sample_row_index * 4
            for index, dimension in enumerate(ordered_dimensions, start=1):
                worksheet.cell(
                    row_base,
                    index,
                    _display_dimension_value(row.dimensions.get(dimension.name)),
                )

            labels = ["Value", "Z Score", "Golden Deviation", "Pass / Fail"]
            for label_offset, label in enumerate(labels):
                worksheet.cell(row_base + label_offset, label_column, label)

            for column_offset, column in enumerate(block_columns):
                col_idx = data_start_column + column_offset
                z_entry = zscore_values.get(_row_metric_key(row, column.raw_column))
                golden_entry = golden_values.get(_row_metric_key(row, column.raw_column))
                value_cell = worksheet.cell(row_base, col_idx, row.values.get(column.raw_column))
                z_cell = worksheet.cell(row_base + 1, col_idx, z_entry.value if z_entry else None)
                g_cell = worksheet.cell(
                    row_base + 2,
                    col_idx,
                    (
                        golden_entry.outlier_display_value
                        if golden_entry and golden_entry.outlier_display_value is not None
                        else (golden_entry.value if golden_entry else None)
                    ),
                )
                if z_entry and isinstance(z_cell.value, (int, float)):
                    z_cell.number_format = DECIMAL_FORMAT_3
                if (
                    golden_entry
                    and golden_entry.outlier_number_format
                    and isinstance(g_cell.value, (int, float))
                ):
                    g_cell.number_format = golden_entry.outlier_number_format
                elif golden_entry and isinstance(g_cell.value, (int, float)):
                    g_cell.number_format = PERCENT_FORMAT_2
                missing_value_failed = (
                    template.report.outlier_treat_empty_cells_as_fail
                    and column.raw_column not in row.values
                )
                pass_fail = (
                    "Fail"
                    if missing_value_failed
                    else _resolve_pass_fail(
                        fail_mode,
                        z_entry,
                        golden_entry,
                    )
                )
                pf_cell = worksheet.cell(row_base + 3, col_idx, pass_fail)
                metric_failed = pass_fail == "Fail"
                emphasis_font = OUTLIER_FAIL_FONT if metric_failed else OUTLIER_WARN_FONT
                if golden_entry and golden_entry.absolute_rule_failed:
                    _apply_style_parts(value_cell, font=emphasis_font)
                if z_entry and z_entry.is_fail:
                    _apply_style_parts(z_cell, font=emphasis_font)
                if golden_entry and golden_entry.is_fail:
                    _apply_style_parts(g_cell, font=emphasis_font)
                if pass_fail == "Fail":
                    _apply_style_parts(pf_cell, font=OUTLIER_FAIL_FONT)
                highlight_status = highlight_map.get(
                    (
                        sample_key,
                        str(row.dimensions.get("reliability_node", "") or ""),
                        column.raw_column,
                    )
                )
                if highlight_status:
                    fill = {
                        "new_fail": NEW_FAIL_FILL,
                        "recovered": RECOVERED_FILL,
                        "merged_fail": MERGED_FAIL_FILL,
                    }[highlight_status]
                    for target_row in range(row_base, row_base + 4):
                        _apply_style_parts(worksheet.cell(target_row, col_idx), fill=fill)

        _style_sheet(
            worksheet,
            header_rows=list(range(current_row, unit_row + 1)),
            dimension_header_row=dimension_header_row,
            start_column=label_column,
            end_column=data_start_column + len(block_columns) - 1,
            dimension_count=len(dimension_labels),
            table_start_row=current_row,
            table_end_row=block_data_start + len(sample_rows) * 4 - 1,
            apply_table_borders=False,
        )
        _merge_column_header_rows(
            worksheet,
            current_row,
            data_start_column,
            block_columns,
            len(header_labels),
        )
        _merge_outlier_dimension_values(
            worksheet,
            block_data_start,
            len(sample_rows),
            len(dimension_labels),
            row_dimension_values=sample_row_dimension_values,
        )
        _apply_outlier_data_borders(
            worksheet,
            block_data_start,
            len(sample_rows),
            label_column,
            data_start_column,
            data_start_column + len(block_columns) - 1,
            top_group_column_ranges,
        )
        current_row = block_data_start + len(sample_rows) * 4 - 1

    _autosize_columns(worksheet)
    return None


def _write_summary_sheet(
    worksheet,
    template: TemplateConfig,
    summary_stats_rows: list[dict[str, Any]],
    ratio_rows: list[dict[str, Any]],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    golden_fallback_warnings: list[dict[str, str]] | None = None,
) -> None:
    configured_node_orders = _configured_node_orders(template)
    if configured_node_orders:
        worksheet.cell(1, 1, "Configured Node Sequences")
        for row_offset, node_order in enumerate(configured_node_orders, start=1):
            worksheet.cell(1 + row_offset, 1, f"Sequence {row_offset}")
            for column_offset, node in enumerate(node_order, start=2):
                worksheet.cell(1 + row_offset, column_offset, node)
        start_row = len(configured_node_orders) + 3
    else:
        start_row = 4

    worksheet.cell(start_row, 1, "Metric")
    worksheet.cell(start_row, 2, "Value")
    worksheet.cell(start_row, 3, "Note")
    for row_offset, item in enumerate(summary_stats_rows, start=1):
        worksheet.cell(start_row + row_offset, 1, str(item.get("metric", "")))
        worksheet.cell(start_row + row_offset, 2, item.get("value"))
        worksheet.cell(start_row + row_offset, 3, str(item.get("note", "")))

    warnings = [
        *list(golden_fallback_warnings or []),
        *_ratio_group_by_skip_level_warnings(template),
    ]
    warning_start_row = start_row + len(summary_stats_rows) + 3
    if warnings:
        worksheet.cell(warning_start_row, 1, "Summary Warning")
        worksheet.cell(warning_start_row, 2, "Stat ID")
        worksheet.cell(warning_start_row, 3, "Warning")
        for row_offset, item in enumerate(warnings, start=1):
            worksheet.cell(warning_start_row + row_offset, 1, "WARNING")
            worksheet.cell(warning_start_row + row_offset, 2, item["id"])
            warning_cell = worksheet.cell(warning_start_row + row_offset, 3, item["warning"])
            warning_cell.alignment = Alignment(wrap_text=True, vertical="top")
        ratio_start_row = warning_start_row + len(warnings) + 3
    else:
        ratio_start_row = warning_start_row
    if ratio_rows:
        max_lot_pair_count = max(
            (len(item.get("lot_sample_pairs", [])) for item in ratio_rows),
            default=0,
        )
        ratio_headers = [
            "Stat ID",
            "Display Name",
            "Group By Dimension",
            "Group Value",
            "Numerator",
            "Matched Sample Count",
            "Total Sample Count",
            "Outlier Ratio",
            "Filter Summary",
        ]
        for pair_index in range(1, max_lot_pair_count + 1):
            ratio_headers.extend([f"Lot {pair_index}", f"Sample IDs {pair_index}"])
        for index, title in enumerate(ratio_headers, start=1):
            worksheet.cell(ratio_start_row, index, title)
        for row_offset, item in enumerate(ratio_rows, start=1):
            worksheet.cell(ratio_start_row + row_offset, 1, item["id"])
            worksheet.cell(ratio_start_row + row_offset, 2, item["display_name"])
            worksheet.cell(ratio_start_row + row_offset, 3, item["group_by_dimension"])
            worksheet.cell(ratio_start_row + row_offset, 4, item["group_value"])
            worksheet.cell(ratio_start_row + row_offset, 5, item["numerator"])
            worksheet.cell(ratio_start_row + row_offset, 6, item["outlier_sample_count"])
            worksheet.cell(ratio_start_row + row_offset, 7, item["total_sample_count"])
            ratio_cell = worksheet.cell(ratio_start_row + row_offset, 8, item["outlier_ratio"])
            if isinstance(ratio_cell.value, (int, float)):
                ratio_cell.number_format = PERCENT_FORMAT_2
            worksheet.cell(ratio_start_row + row_offset, 9, item["filter_summary"])
            for pair_index, (lot_value, sample_ids) in enumerate(
                item.get("lot_sample_pairs", []),
                start=1,
            ):
                base_column = 10 + (pair_index - 1) * 2
                worksheet.cell(ratio_start_row + row_offset, base_column, lot_value)
                worksheet.cell(ratio_start_row + row_offset, base_column + 1, sample_ids)

    _style_sheet(
        worksheet,
        header_rows=(
            ([1] if configured_node_orders else [])
            + [start_row]
            + ([warning_start_row] if warnings else [])
            + ([ratio_start_row] if ratio_rows else [])
        ),
        dimension_header_row=None,
        start_column=1,
        end_column=(9 + max(0, max((len(item.get("lot_sample_pairs", [])) for item in ratio_rows), default=0) * 2)) if ratio_rows else 3,
        dimension_count=0,
        table_start_row=1 if configured_node_orders else start_row,
        table_end_row=(
            (ratio_start_row + len(ratio_rows))
            if ratio_rows
            else (warning_start_row + len(warnings) if warnings else start_row + len(summary_stats_rows))
        ),
    )
    _autosize_columns(worksheet)


def _ratio_group_by_skip_level_warnings(template: TemplateConfig) -> list[dict[str, str]]:
    column_level_names = _ordered_column_levels(template)
    if not column_level_names:
        return []

    warnings: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for config in template.report.outlier_ratio_stats:
        group_dimensions = _effective_ratio_group_dimensions(config)
        used_column_levels = [
            dimension_name
            for dimension_name in group_dimensions
            if dimension_name in column_level_names
        ]
        if not used_column_levels:
            continue
        deepest_index = max(column_level_names.index(dimension_name) for dimension_name in used_column_levels)
        expected_prefix = column_level_names[: deepest_index + 1]
        missing_prefix_levels = [
            dimension_name
            for dimension_name in expected_prefix
            if dimension_name not in used_column_levels
        ]
        if not missing_prefix_levels:
            continue
        key = (config.id, ";".join(group_dimensions))
        if key in seen:
            continue
        seen.add(key)
        warnings.append(
            {
                "id": config.id,
                "warning": RATIO_GROUP_BY_SKIP_LEVEL_WARNING.format(
                    used_levels=";".join(used_column_levels),
                    suggested_levels=";".join(expected_prefix),
                ),
            }
        )
    return warnings


def _collect_outlier_summary_artifacts(
    template: TemplateConfig,
    columns: list[ColumnMeta],
    rows: list[RowData],
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    outlier_fail_method_override: str | None = None,
) -> dict[str, list[dict[str, Any]]]:
    sample_dimension_names = _sample_dimension_names(template)
    fail_mode = outlier_fail_method_override or template.report.outlier_fail_method
    leaf_records = _build_leaf_records(
        template,
        columns,
        rows,
        zscore_values,
        golden_values,
        fail_mode,
    )
    base_merge_records = _merge_records_from_leaves(leaf_records)
    all_outlier_records = [
        record for record in _top_level_any_fail_records_from_records(template, base_merge_records) if record.is_fail
    ]
    final_records = _execute_outlier_merge_pipeline_from_records(template, base_merge_records)
    final_status_rows = _build_final_status_rows(
        template,
        final_records,
        sample_node_orders,
    )
    summary_rows = _build_final_summary_rows(final_status_rows)
    status_map = {
        (
            tuple(str(value) for value in item.get("sample_key", [])),
            str(item.get("node", "")),
            tuple(str(value) for value in item.get("test_group_key", [])),
        ): str(item.get("status", ""))
        for item in final_status_rows
        if str(item.get("status", ""))
    }
    merged_outlier_rows = _build_merged_outlier_rows(
        template,
        final_status_rows,
        sample_node_orders,
    )
    all_outlier_rows = _build_all_outlier_rows(
        template,
        all_outlier_records,
        final_status_rows,
        status_map,
        sample_node_orders,
    )
    ratio_rows = _build_outlier_ratio_rows_from_leaf_records(
        template.report.outlier_ratio_stats,
        template,
        leaf_records,
        sample_node_orders,
        sample_dimension_names,
        base_merge_records=base_merge_records,
    )
    summary_stats_rows = _build_outlier_summary_stats_rows(
        leaf_records,
        final_status_rows,
        len(all_outlier_records),
    )
    return {
        "summary_rows": summary_rows,
        "summary_stats_rows": summary_stats_rows,
        "ratio_rows": ratio_rows,
        "all_outlier_rows": all_outlier_rows,
        "merged_outlier_rows": merged_outlier_rows,
        "final_status_rows": final_status_rows,
    }


def _build_final_status_rows(
    template: TemplateConfig,
    final_records: list[MergeRecord],
    sample_node_orders: dict[tuple[str, ...], list[str]],
) -> list[dict[str, Any]]:
    rows_by_sample: dict[tuple[str, ...], list[MergeRecord]] = defaultdict(list)
    for record in final_records:
        rows_by_sample[record.sample_key].append(record)

    status_rows: list[dict[str, Any]] = []
    for sample_key in sorted(rows_by_sample, key=_sample_key_sort_key):
        sample_id = _sample_key_display(sample_key)
        sample_records = rows_by_sample[sample_key]
        observed_nodes = {record.node_value for record in sample_records if record.node_value}
        node_ancestor_chains = _build_sample_node_ancestor_chains(
            observed_nodes,
            _configured_node_orders(template),
        )
        records_by_node_and_group = {
            (record.node_value, record.column_key): record
            for record in sample_records
        }
        for record in sorted(
            sample_records,
            key=lambda item: (
                _node_sort_key(
                    item.node_value,
                    sample_node_orders.get(sample_key, []),
                ),
                tuple(_natural_sort_key(value) for value in item.column_key),
            ),
        ):
            predecessors = node_ancestor_chains.get(record.node_value, [])
            previous_records = [
                records_by_node_and_group[(predecessor, record.column_key)]
                for predecessor in predecessors
                if (predecessor, record.column_key) in records_by_node_and_group
            ]
            any_previous_fail = any(item.is_fail for item in previous_records)
            nearest_previous = previous_records[0] if previous_records else None
            if record.is_fail:
                status = "Existed" if any_previous_fail else "New"
            elif nearest_previous is not None and nearest_previous.is_fail:
                status = "Recovered"
            else:
                status = ""
            status_rows.append(
                {
                    "sample_id": sample_id,
                    "sample_key": list(sample_key),
                    "node": record.node_value,
                    "chain": _top_level_test_group_display(record.column_key),
                    "status": status,
                    "is_fail": record.is_fail,
                    "row_group_key": [record.node_value],
                    "row_group_dimensions": ["reliability_node"],
                    "test_group_key": list(record.column_key),
                    "dimensions": dict(record.dimensions),
                    "raw_row_keys": sorted(record.raw_row_keys),
                    "raw_columns": sorted(record.raw_columns),
                    "group_ids": sorted(record.group_ids),
                    "group_display_names": sorted(record.group_display_names),
                    "test_types": sorted(record.test_types),
                    "chain_names": sorted(record.chain_names),
                    "column_names": sorted(record.column_names),
                    "units": sorted(record.units),
                    "logical_metrics": sorted(record.logical_metrics),
                }
            )
    return sorted(
        status_rows,
        key=lambda item: (
            tuple(_natural_sort_key(value) for value in item.get("sample_key", [])),
            _row_group_sort_key(
                tuple(str(value) for value in item.get("row_group_key", [])),
                [str(value) for value in item.get("row_group_dimensions", [])],
                sample_node_orders.get(
                    tuple(str(value) for value in item.get("sample_key", [])),
                    [],
                ),
            ),
            tuple(_natural_sort_key(value) for value in item.get("test_group_key", [])),
        ),
    )


def _build_final_summary_rows(
    final_status_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    return [
        {
            "sample_id": str(item.get("sample_id", "")),
            "sample_key": list(item.get("sample_key", [])),
            "node": str(item.get("node", "")),
            "chain": str(item.get("chain", "")),
            "status": str(item.get("status", "")),
            "test_group_key": list(item.get("test_group_key", [])),
            "row_group_key": list(item.get("row_group_key", [])),
            "row_group_dimensions": list(item.get("row_group_dimensions", [])),
        }
        for item in final_status_rows
        if str(item.get("status", ""))
    ]


def _build_all_outlier_rows(
    template: TemplateConfig,
    records: list[MergeRecord],
    final_status_rows: list[dict[str, Any]],
    status_map: dict[tuple[tuple[str, ...], str, tuple[str, ...]], str],
    sample_node_orders: dict[tuple[str, ...], list[str]],
) -> list[dict[str, Any]]:
    rows_by_key = {
        (
            tuple(str(value) for value in item.get("sample_key", [])),
            str(item.get("node", "")),
            tuple(str(value) for value in item.get("test_group_key", [])),
        ): item
        for item in final_status_rows
    }
    include_keys: set[tuple[tuple[str, ...], str, tuple[str, ...]]] = set()
    for record in records:
        sample_key = tuple(str(value) for value in record.sample_key)
        include_keys.update(
            key
            for key in rows_by_key
            if key[0] == sample_key and key[2] == record.column_key
        )

    raw_metadata_by_sample_group: dict[
        tuple[tuple[str, ...], tuple[str, ...]],
        dict[str, set[Any]],
    ] = defaultdict(
        lambda: {
            "raw_row_keys": set(),
            "raw_columns": set(),
        }
    )
    for record in records:
        sample_key = tuple(str(value) for value in record.sample_key)
        group_key = tuple(str(value) for value in record.column_key)
        metadata = raw_metadata_by_sample_group[(sample_key, group_key)]
        metadata["raw_row_keys"].update(record.raw_row_keys)
        metadata["raw_columns"].update(record.raw_columns)

    payload: list[dict[str, Any]] = []
    for key in include_keys:
        sample_key, node_value, test_group_key = key
        item = rows_by_key[key]
        metadata = raw_metadata_by_sample_group.get(
            (sample_key, test_group_key),
            {"raw_row_keys": set(), "raw_columns": set()},
        )
        payload.append(
            {
                "sample_id": str(item.get("sample_id", _sample_key_display(sample_key))),
                "sample_key": list(sample_key),
                "node": node_value,
                "chain": _top_level_test_group_display(test_group_key),
                "status": status_map.get((sample_key, node_value, test_group_key), ""),
                "test_group_key": list(test_group_key),
                "row_group_key": [node_value],
                "row_group_dimensions": ["reliability_node"],
                "raw_row_keys": sorted(item.get("raw_row_keys", [])),
                "raw_columns": sorted(
                    {
                        *(str(value) for value in metadata["raw_columns"]),
                        *(str(value) for value in item.get("raw_columns", [])),
                    }
                ),
            }
        )
    return _sort_summary_rows(payload, sample_node_orders)


def _build_merged_outlier_rows(
    template: TemplateConfig,
    final_status_rows: list[dict[str, Any]],
    sample_node_orders: dict[tuple[str, ...], list[str]],
) -> list[dict[str, Any]]:
    rows_by_key = {
        (
            tuple(str(value) for value in item.get("sample_key", [])),
            str(item.get("node", "")),
            tuple(str(value) for value in item.get("test_group_key", [])),
        ): item
        for item in final_status_rows
    }
    include_keys: set[tuple[tuple[str, ...], str, tuple[str, ...]]] = set()
    for item in final_status_rows:
        if not bool(item.get("is_fail")):
            continue
        sample_key = tuple(str(value) for value in item.get("sample_key", []))
        test_group_key = tuple(str(value) for value in item.get("test_group_key", []))
        include_keys.update(
            key
            for key in rows_by_key
            if key[0] == sample_key and key[2] == test_group_key
        )

    payload = [rows_by_key[key] for key in include_keys]
    return _sort_summary_rows(payload, sample_node_orders)


def _build_outlier_summary_stats_rows(
    leaf_records: list[LeafRecord],
    final_status_rows: list[dict[str, Any]],
    all_outlier_block_count: int,
) -> list[dict[str, Any]]:
    affected_samples = {
        tuple(str(value) for value in item.get("sample_key", []))
        for item in final_status_rows
        if str(item.get("status", ""))
    }
    new_count = sum(
        1 for item in final_status_rows if bool(item.get("is_fail")) and str(item.get("status", "")) == "New"
    )
    recovered_count = sum(1 for item in final_status_rows if str(item.get("status", "")) == "Recovered")
    merged_fail_count = sum(1 for item in final_status_rows if bool(item.get("is_fail")))
    raw_fail_count = sum(1 for item in leaf_records if item.is_fail)
    metrics = [
        ("All Outlier Blocks", all_outlier_block_count),
        ("Merged Outlier Blocks", merged_fail_count),
        ("New Merged Outliers", new_count),
        ("Recovered Blocks", recovered_count),
        ("Affected Samples", len(affected_samples)),
        ("Raw Failing Test Cells", raw_fail_count),
    ]
    return [
        {
            "metric": metric,
            "value": value,
            "note": OUTLIER_SUMMARY_NOTES.get(metric, ""),
        }
        for metric, value in metrics
    ]


def _ratio_filter_signature(config: OutlierRatioStatConfig) -> tuple[Any, ...]:
    return (
        tuple(config.group_ids),
        tuple(config.group_display_names),
        tuple(config.test_types),
        tuple(config.chain_names or config.chains),
        tuple(config.column_names or config.raw_columns),
        tuple(config.units),
        tuple(config.logical_metrics),
    )


def _record_matches_ratio_group(
    record: MergeRecord,
    group_dimensions: list[str],
    column_level_names: list[str],
) -> tuple[str, ...]:
    return tuple(
        _ratio_group_value_from_record(record, dimension_name, column_level_names)
        for dimension_name in group_dimensions
    )


def _ratio_group_value_from_record(
    record: MergeRecord,
    dimension_name: str,
    column_level_names: list[str],
) -> str:
    if dimension_name in record.dimensions:
        return str(record.dimensions.get(dimension_name, "") or "")
    if dimension_name in column_level_names:
        level_index = column_level_names.index(dimension_name)
        if level_index < len(record.column_key):
            return str(record.column_key[level_index] or "")
    return ""


def _final_record_by_leaf_key(
    final_records: list[MergeRecord],
) -> tuple[
    dict[tuple[tuple[str, ...], tuple[str, ...]], MergeRecord],
    int,
    int,
]:
    if not final_records:
        return {}, 0, 0
    row_target_length = len(final_records[0].row_key)
    column_target_length = len(final_records[0].column_key)
    records_by_key = {
        (record.row_key, record.column_key): record
        for record in final_records
    }
    return records_by_key, row_target_length, column_target_length


def _build_outlier_ratio_rows_from_leaf_records(
    configs: list[OutlierRatioStatConfig],
    template: TemplateConfig,
    leaf_records: list[LeafRecord],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    sample_dimension_names: list[str],
    base_merge_records: list[MergeRecord] | None = None,
) -> list[dict[str, Any]]:
    if not configs:
        return []

    configs_by_signature: dict[tuple[Any, ...], list[OutlierRatioStatConfig]] = defaultdict(list)
    for config in configs:
        configs_by_signature[_ratio_filter_signature(config)].append(config)

    merged_node_order = _merge_node_orders(sample_node_orders.values())
    column_level_names = _ordered_column_levels(template)
    ratio_rows: list[dict[str, Any]] = []
    reusable_base_records = base_merge_records or _merge_records_from_leaves(leaf_records)
    for signature, signature_configs in configs_by_signature.items():
        del signature
        sample_config = signature_configs[0]
        filtered_base_records = [
            record
            for record in reusable_base_records
            if _merge_record_matches_ratio_config(record, sample_config)
        ]
        if not filtered_base_records:
            continue
        final_records = _execute_outlier_merge_pipeline_from_records(
            template,
            filtered_base_records,
        )
        final_record_map, row_target_length, column_target_length = _final_record_by_leaf_key(
            final_records
        )
        final_status_rows = _build_final_status_rows(
            template,
            final_records,
            sample_node_orders,
        )
        status_map = {
            (
                tuple(str(value) for value in item.get("sample_key", [])),
                str(item.get("node", "")),
                tuple(str(value) for value in item.get("test_group_key", [])),
            ): str(item.get("status", ""))
            for item in final_status_rows
            if str(item.get("status", ""))
        }
        for config in signature_configs:
            group_dimensions = _effective_ratio_group_dimensions(config)
            total_samples_by_group: dict[tuple[str, ...], set[tuple[str, ...]]] = defaultdict(set)
            matched_samples_by_group: dict[tuple[str, ...], set[tuple[str, ...]]] = defaultdict(set)
            matched_records_by_group: dict[tuple[str, ...], list[MergeRecord]] = defaultdict(list)
            for record in filtered_base_records:
                group_key = _record_matches_ratio_group(
                    record,
                    group_dimensions,
                    column_level_names,
                )
                if not all(group_key):
                    continue
                if not all(record.sample_key):
                    continue
                total_samples_by_group[group_key].add(record.sample_key)
                final_record = final_record_map.get(
                    (
                        record.row_key[:row_target_length],
                        record.column_key[:column_target_length],
                    )
                )
                if final_record is None:
                    continue
                status = status_map.get(
                    (final_record.sample_key, final_record.node_value, final_record.column_key),
                    "",
                )
                if config.numerator == "recovered_samples":
                    if status != "Recovered":
                        continue
                else:
                    if not final_record.is_fail:
                        continue
                if config.numerator == "new_outlier_samples" and status != "New":
                    continue
                matched_samples_by_group[group_key].add(record.sample_key)
                matched_records_by_group[group_key].append(record)

            for group_key in sorted(
                total_samples_by_group,
                key=lambda item: _ratio_group_sort_key(item, group_dimensions, merged_node_order),
            ):
                total_sample_count = len(total_samples_by_group[group_key])
                matched_sample_count = len(matched_samples_by_group.get(group_key, set()))
                row_payload = {
                    "id": config.id,
                    "display_name": config.display_name or config.id,
                    "group_by_dimension": " + ".join(group_dimensions),
                    "group_value": " | ".join(group_key),
                    "numerator": config.numerator,
                    "outlier_sample_count": matched_sample_count,
                    "total_sample_count": total_sample_count,
                    "outlier_ratio": (
                        matched_sample_count / total_sample_count if total_sample_count else 0.0
                    ),
                    "filter_summary": _format_ratio_filter_summary(config),
                }
                lot_sample_pairs = _build_ratio_lot_sample_pairs_from_records(
                    matched_records_by_group.get(group_key, []),
                )
                if lot_sample_pairs:
                    row_payload["lot_sample_pairs"] = lot_sample_pairs
                ratio_rows.append(row_payload)

    return sorted(
        ratio_rows,
        key=lambda item: (
            _natural_sort_key(str(item["display_name"])),
            _ratio_group_value_display_sort_key(
                str(item["group_by_dimension"]),
                str(item["group_value"]),
                merged_node_order,
            ),
        ),
    )


def _build_ratio_lot_sample_pairs_from_records(
    matching_records: list[MergeRecord],
) -> list[tuple[str, str]]:
    sample_ids_by_lot: dict[str, set[str]] = defaultdict(set)
    for record in matching_records:
        lot_value = str(
            record.dimensions.get("lot", "")
            or record.dimensions.get("lot_id", "")
            or ""
        ).strip()
        sample_id_value = str(
            record.dimensions.get("sample_id", "")
            or _sample_key_display(record.sample_key)
            or ""
        ).strip()
        if not sample_id_value:
            continue
        sample_ids_by_lot[lot_value].add(sample_id_value)
    pairs: list[tuple[str, str]] = []
    for lot_value in sorted(sample_ids_by_lot, key=_natural_sort_key):
        sample_ids = sorted(sample_ids_by_lot[lot_value], key=_natural_sort_key)
        pairs.append((lot_value, ";".join(sample_ids)))
    return pairs


def _row_sort_key(
    row: RowData,
    template: TemplateConfig,
    sample_node_orders: dict[tuple[str, ...], list[str]] | None = None,
) -> tuple[Any, ...]:
    node_value = row.dimensions.get("reliability_node", "")
    node_order = []
    sample_dimension_names = _sample_dimension_names(template)
    sample_key = _sample_key_from_dimensions(row.dimensions, sample_dimension_names)
    if sample_node_orders is not None:
        node_order = sample_node_orders.get(sample_key, [])
    if not node_order:
        configured = _configured_node_orders(template)
        node_order = configured[0] if configured else []
    ordered_values: list[Any] = []
    for item in _ordered_row_dimensions(template):
        value = str(row.dimensions.get(item.name, "") or "")
        if item.name == "reliability_node":
            ordered_values.append(_node_sort_key(value, node_order))
        else:
            ordered_values.append(_natural_sort_key(value))
    return tuple(ordered_values)


def _sort_columns_for_tree_display(columns: list[ColumnMeta]) -> list[ColumnMeta]:
    return sorted(
        columns,
        key=lambda item: (
            tuple(_natural_sort_key(value) for value in item.header_values),
            item.column_order if item.column_order is not None else 10**9,
            item.display_order,
        ),
    )

def _resolve_threshold(config: ThresholdConfig, candidates: list[str]) -> float:
    for candidate in candidates:
        if candidate in config.overrides:
            return config.overrides[candidate]
    return config.default


def _resolve_built_relative_threshold(entry: AnomalyResult) -> float | None:
    if entry.center is None or entry.lower_bound is None or entry.upper_bound is None:
        return None
    if entry.center == 0:
        return None
    return max(
        abs(entry.upper_bound - entry.center),
        abs(entry.center - entry.lower_bound),
    ) / abs(entry.center)


def _resolve_built_absolute_threshold(entry: AnomalyResult) -> float | None:
    if entry.center is None or entry.lower_bound is None or entry.upper_bound is None:
        return None
    return max(
        abs(entry.upper_bound - entry.center),
        abs(entry.center - entry.lower_bound),
    )


def _resolve_built_metric_display(
    entry: AnomalyResult,
) -> tuple[Any | None, Any | None]:
    method = str(entry.outlier_golden_method or "").strip()
    modifiers = outlier_golden_method_modifiers(method) if method else set()
    if not method:
        if entry.center is None:
            return None, None
        if entry.center == 0:
            return entry.value - entry.center, _resolve_built_absolute_threshold(entry)
        return (
            (entry.value - entry.center) / abs(entry.center),
            _resolve_built_relative_threshold(entry),
        )

    terms = outlier_golden_method_terms(method)
    if terms == {"relative"} and not modifiers:
        if entry.center is None:
            return None, entry.relative_limit
        if entry.center == 0:
            return entry.value - entry.center, entry.relative_limit
        return (
            (entry.value - entry.center) / abs(entry.center),
            entry.relative_limit,
        )
    if terms == {"sigma"} and not modifiers:
        if entry.center is None or entry.stdev in {None, 0}:
            return None, entry.sigma_multiplier
        return (
            abs(entry.value - entry.center) / entry.stdev,
            entry.sigma_multiplier,
        )
    if terms == {"absolute"} and not modifiers:
        threshold = _format_absolute_bound_display(
            entry.absolute_lower_bound,
            entry.absolute_upper_bound,
        )
        return entry.value, threshold
    return (
        _format_built_metric_value_display(entry, terms),
        _format_built_metric_threshold_display(entry, terms),
    )


def _resolve_built_metric_outlier_display_value(
    entry: AnomalyResult,
) -> Any | None:
    method = str(entry.outlier_golden_method or "").strip()
    terms = outlier_golden_method_terms(method) if method else set()
    if "relative" in terms:
        if entry.center is None:
            return None
        if entry.center == 0:
            return entry.value - entry.center
        return (entry.value - entry.center) / abs(entry.center)
    if "sigma" in terms:
        if entry.center is None or entry.stdev in {None, 0}:
            return None
        return abs(entry.value - entry.center) / entry.stdev
    if "absolute" in terms:
        return entry.value
    return entry.value


def _resolve_built_metric_outlier_display_format(
    entry: AnomalyResult,
) -> str | None:
    method = str(entry.outlier_golden_method or "").strip()
    terms = outlier_golden_method_terms(method) if method else set()
    if "relative" in terms:
        return PERCENT_FORMAT_2
    if "sigma" in terms:
        return DECIMAL_FORMAT_3
    return None


def _built_metric_absolute_rule_failed(entry: AnomalyResult) -> bool:
    method = str(entry.outlier_golden_method or "").strip()
    terms = outlier_golden_method_terms(method) if method else set()
    if "absolute" not in terms:
        return False
    if entry.absolute_lower_bound is None or entry.absolute_upper_bound is None:
        return False
    return not (entry.absolute_lower_bound <= entry.value <= entry.absolute_upper_bound)


def _format_built_metric_value_display(
    entry: AnomalyResult,
    terms: set[str],
) -> str:
    parts: list[str] = []
    if "relative" in terms and entry.center is not None:
        if entry.center == 0:
            parts.append(f"relative={entry.value - entry.center:g}")
        else:
            relative_value = (entry.value - entry.center) / abs(entry.center)
            parts.append(f"relative={relative_value:.2%}")
    if "sigma" in terms:
        if entry.center is None or entry.stdev in {None, 0}:
            parts.append("sigma=n/a")
        else:
            sigma_value = abs(entry.value - entry.center) / entry.stdev
            parts.append(f"sigma={sigma_value:.3f}")
    if "absolute" in terms:
        parts.append(f"value={entry.value:g}")
    return " | ".join(parts) if parts else ""


def _format_built_metric_threshold_display(
    entry: AnomalyResult,
    terms: set[str],
) -> str:
    parts: list[str] = []
    if "relative" in terms and entry.relative_limit is not None:
        parts.append(f"relative={entry.relative_limit:.2%}")
    if "sigma" in terms and entry.sigma_multiplier is not None:
        parts.append(f"sigma={entry.sigma_multiplier:g}")
    if "absolute" in terms:
        absolute_text = _format_absolute_bound_display(
            entry.absolute_lower_bound,
            entry.absolute_upper_bound,
        )
        if absolute_text:
            parts.append(f"absolute={absolute_text}")
    modifiers = outlier_golden_method_modifiers(entry.outlier_golden_method) if entry.outlier_golden_method else set()
    if modifiers:
        allowed_text = _format_allowed_ranges_display(
            entry.allowed_ranges,
            fallback_lower_bound=entry.lower_bound,
            fallback_upper_bound=entry.upper_bound,
        )
        if allowed_text:
            parts.append(f"final={allowed_text}")
    return " | ".join(parts) if parts else ""


def _format_absolute_bound_display(
    lower_bound: float | None,
    upper_bound: float | None,
) -> str:
    if lower_bound is None or upper_bound is None:
        return ""
    return f"[{lower_bound:g}, {upper_bound:g}]"


def _format_allowed_ranges_display(
    allowed_ranges: list[GoldenAllowedRange],
    *,
    fallback_lower_bound: float | None = None,
    fallback_upper_bound: float | None = None,
) -> str:
    if allowed_ranges:
        return " or ".join(
            _format_absolute_bound_display(item.lower_bound, item.upper_bound)
            for item in allowed_ranges
        )
    return _format_absolute_bound_display(
        fallback_lower_bound,
        fallback_upper_bound,
    )


def _sample_chain_is_outlier(
    sample_rows: list[RowData],
    columns: list[ColumnMeta],
    fail_mode: str,
    fail_rule: str,
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
) -> bool:
    statuses = [
        _is_metric_fail(
            fail_mode,
            zscore_values.get(_row_metric_key(row, column.raw_column)),
            golden_values.get(_row_metric_key(row, column.raw_column)),
        )
        for row in sample_rows
        for column in columns
    ]
    if not statuses:
        return False
    if fail_rule == "all_fail":
        return all(statuses)
    return any(statuses)


def _row_chain_is_outlier(
    row: RowData,
    columns: list[ColumnMeta],
    fail_mode: str,
    fail_rule: str,
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
) -> bool:
    return _sample_chain_is_outlier(
        [row],
        columns,
        fail_mode,
        fail_rule,
        zscore_values,
        golden_values,
    )


def _resolve_pass_fail(
    fail_mode: str,
    z_entry: MetricValue | None,
    golden_entry: MetricValue | None,
) -> str:
    return "Fail" if _is_metric_fail(fail_mode, z_entry, golden_entry) else "Pass"


def _is_metric_fail(
    fail_mode: str,
    z_entry: MetricValue | None,
    golden_entry: MetricValue | None,
) -> bool:
    z_fail = bool(z_entry and z_entry.is_fail)
    golden_fail = bool(golden_entry and golden_entry.is_fail)
    if fail_mode == "modified_z_score":
        return z_fail
    if fail_mode == "golden_deviation":
        return golden_fail
    if fail_mode == "zscore_and_golden":
        return z_fail and golden_fail
    if fail_mode == "zscore_or_golden":
        return z_fail or golden_fail
    raise ValueError(f"Unsupported fail mode: {fail_mode}")


def _style_sheet(
    worksheet,
    header_rows: list[int],
    dimension_header_row: int | None,
    start_column: int,
    end_column: int,
    dimension_count: int,
    table_start_row: int | None = None,
    table_end_row: int | None = None,
    apply_table_borders: bool = True,
    apply_table_alignment: bool = False,
) -> None:
    full_width = max(end_column, dimension_count)
    workbook = worksheet.parent
    border_id = _style_component_id(workbook, "border", THIN_BORDER) if apply_table_borders else None
    alignment_id = _style_component_id(workbook, "alignment", CENTER) if apply_table_alignment else None
    if table_start_row is not None and table_end_row is not None and table_end_row >= table_start_row:
        for row_index in range(table_start_row, table_end_row + 1):
            if dimension_header_row is not None and row_index < dimension_header_row:
                column_start = start_column
            else:
                column_start = 1
            for col_index in range(column_start, full_width + 1):
                cell = worksheet.cell(row_index, col_index)
                if border_id is not None or alignment_id is not None:
                    _apply_style_ids(
                        cell,
                        border_id=border_id,
                        alignment_id=alignment_id,
                    )

    for row_index in header_rows:
        for col_index in range(start_column, end_column + 1):
            cell = worksheet.cell(row_index, col_index)
            cell._style = _prebuilt_style_array(workbook, "header")

    if dimension_header_row is not None:
        for col_index in range(1, full_width + 1):
            cell = worksheet.cell(dimension_header_row, col_index)
            cell._style = _prebuilt_style_array(workbook, "subheader")


def _merge_column_header_rows(
    worksheet,
    header_row: int,
    data_start_column: int,
    columns: list[ColumnMeta],
    header_level_count: int,
) -> None:
    if not columns or header_level_count <= 0:
        return
    for level_index in range(header_level_count):
        start = data_start_column
        current = columns[0].header_values[level_index]
        current_prefix = tuple(columns[0].header_values[:level_index])
        for offset, column in enumerate(columns[1:], start=1):
            absolute_column = data_start_column + offset
            prefix = tuple(column.header_values[:level_index])
            value = column.header_values[level_index]
            if value != current or prefix != current_prefix:
                if absolute_column - 1 > start:
                    worksheet.merge_cells(
                        start_row=header_row + level_index,
                        start_column=start,
                        end_row=header_row + level_index,
                        end_column=absolute_column - 1,
                    )
                start = absolute_column
                current = value
                current_prefix = prefix
        end_column = data_start_column + len(columns) - 1
        if end_column > start:
            worksheet.merge_cells(
                start_row=header_row + level_index,
                start_column=start,
                end_row=header_row + level_index,
                end_column=end_column,
            )


def _merge_dimension_values(
    worksheet,
    start_row: int,
    row_count: int,
    template: TemplateConfig,
    row_dimension_values: list[tuple[Any, ...]] | None = None,
) -> None:
    if row_count <= 1:
        return
    dimension_names = [item.name for item in _ordered_row_dimensions(template)]
    for col_index, _dimension in enumerate(dimension_names, start=1):
        group_start = start_row
        previous = (
            row_dimension_values[0][col_index - 1]
            if row_dimension_values is not None
            else worksheet.cell(start_row, col_index).value
        )
        for row_index in range(start_row + 1, start_row + row_count + 1):
            current = (
                row_dimension_values[row_index - start_row][col_index - 1]
                if row_dimension_values is not None and row_index < start_row + row_count
                else (
                    worksheet.cell(row_index, col_index).value
                    if row_index < start_row + row_count
                    else None
                )
            )
            should_merge = (
                row_index < start_row + row_count
                and current == previous
                and (
                    _same_prefix_row_values(
                        row_dimension_values,
                        group_start - start_row,
                        row_index - start_row,
                        col_index,
                    )
                    if row_dimension_values is not None
                    else _same_prefix_values(worksheet, group_start, row_index, col_index)
                )
            )
            if should_merge:
                continue
            if row_index - group_start > 1 and previous not in (None, ""):
                _merge_cells_fast(
                    worksheet,
                    start_row=group_start,
                    start_column=col_index,
                    end_row=row_index - 1,
                    end_column=col_index,
                )
            group_start = row_index
            previous = current


def _same_prefix_row_values(
    row_dimension_values: list[tuple[Any, ...]],
    start_index: int,
    current_index: int,
    current_column: int,
) -> bool:
    for col_index in range(current_column - 1):
        if row_dimension_values[start_index][col_index] != row_dimension_values[current_index][col_index]:
            return False
    return True


def _merge_cells_fast(
    worksheet,
    *,
    start_row: int,
    start_column: int,
    end_row: int,
    end_column: int,
) -> None:
    if start_row == end_row and start_column == end_column:
        return
    range_ref = (
        f"{get_column_letter(start_column)}{start_row}:"
        f"{get_column_letter(end_column)}{end_row}"
    )
    worksheet.merged_cells.ranges.add(MergedCellRange(worksheet, range_ref))


def _merge_outlier_dimension_values(
    worksheet,
    start_row: int,
    row_count: int,
    dimension_count: int,
    row_dimension_values: list[tuple[Any, ...]] | None = None,
) -> None:
    if row_count <= 0:
        return

    block_height = 4
    end_row_exclusive = start_row + row_count * block_height

    for col_index in range(1, dimension_count + 1):
        group_start = start_row
        previous = (
            row_dimension_values[0][col_index - 1]
            if row_dimension_values is not None
            else worksheet.cell(start_row, col_index).value
        )

        for row_index in range(start_row + block_height, end_row_exclusive + block_height, block_height):
            current = (
                row_dimension_values[(row_index - start_row) // block_height][col_index - 1]
                if row_dimension_values is not None and row_index < end_row_exclusive
                else (
                    worksheet.cell(row_index, col_index).value
                    if row_index < end_row_exclusive
                    else None
                )
            )
            should_merge = (
                row_index < end_row_exclusive
                and current == previous
                and (
                    _same_prefix_row_values(
                        row_dimension_values,
                        (group_start - start_row) // block_height,
                        (row_index - start_row) // block_height,
                        col_index,
                    )
                    if row_dimension_values is not None
                    else _same_prefix_values(worksheet, group_start, row_index, col_index)
                )
            )
            if should_merge:
                continue

            if previous not in (None, ""):
                worksheet.merge_cells(
                    start_row=group_start,
                    start_column=col_index,
                    end_row=row_index - 1,
                    end_column=col_index,
                )

            group_start = row_index
            previous = current


def _apply_outlier_data_borders(
    worksheet,
    start_row: int,
    row_count: int,
    label_column: int,
    data_start_column: int,
    end_column: int,
    top_group_column_ranges: list[tuple[int, int]],
) -> None:
    if row_count <= 0 or end_column <= 0:
        return

    block_height = 4
    total_end_row = start_row + row_count * block_height - 1
    column_edge_flags = {
        col_index: (
            any(col_index == left_column for left_column, _ in top_group_column_ranges),
            any(col_index == right_column for _, right_column in top_group_column_ranges),
        )
        for col_index in range(data_start_column, end_column + 1)
    }

    for block_index in range(row_count):
        top_row = start_row + block_index * block_height
        bottom_row = top_row + block_height - 1
        for col_index in range(label_column, end_column + 1):
            has_left, has_right = column_edge_flags.get(col_index, (False, False))
            top_cell = worksheet.cell(top_row, col_index)
            bottom_cell = worksheet.cell(bottom_row, col_index)
            _apply_style_parts(top_cell, border=_cached_border(has_left, has_right, True, False))
            _apply_style_parts(bottom_cell, border=_cached_border(has_left, has_right, False, True))

        for middle_row in range(top_row + 1, bottom_row):
            for col_index in range(label_column, end_column + 1):
                has_left, has_right = column_edge_flags.get(col_index, (False, False))
                _apply_style_parts(
                    worksheet.cell(middle_row, col_index),
                    border=_cached_border(
                        has_left,
                        has_right,
                        False,
                        False,
                    ),
                )
    last_row = total_end_row
    for left_column, right_column in top_group_column_ranges:
        left_cell = worksheet.cell(last_row, left_column)
        right_cell = worksheet.cell(last_row, right_column)
        _apply_style_parts(
            left_cell,
            border=_cached_border(
                True,
                bool(left_cell.border.right and left_cell.border.right.style),
                bool(left_cell.border.top and left_cell.border.top.style),
                bool(left_cell.border.bottom and left_cell.border.bottom.style),
            ),
        )
        _apply_style_parts(
            right_cell,
            border=_cached_border(
                bool(right_cell.border.left and right_cell.border.left.style),
                True,
                bool(right_cell.border.top and right_cell.border.top.style),
                bool(right_cell.border.bottom and right_cell.border.bottom.style),
            ),
        )


@lru_cache(maxsize=32)
def _cached_border(left: bool, right: bool, top: bool, bottom: bool) -> Border:
    return Border(
        left=THIN_SIDE if left else None,
        right=THIN_SIDE if right else None,
        top=THIN_SIDE if top else None,
        bottom=THIN_SIDE if bottom else None,
    )


def _workbook_style_ids(workbook) -> dict[tuple[str, Any], int]:
    cache = getattr(workbook, "_eda_style_ids", None)
    if cache is None:
        cache = {}
        setattr(workbook, "_eda_style_ids", cache)
    return cache


def _workbook_style_arrays(workbook) -> dict[str, StyleArray]:
    cache = getattr(workbook, "_eda_style_arrays", None)
    if cache is None:
        cache = {}
        setattr(workbook, "_eda_style_arrays", cache)
    return cache


def _workbook_style_transforms(workbook) -> dict[tuple[Any, ...], StyleArray]:
    cache = getattr(workbook, "_eda_style_transforms", None)
    if cache is None:
        cache = {}
        setattr(workbook, "_eda_style_transforms", cache)
    return cache


def _style_component_id(workbook, component_type: str, component: Any) -> int:
    cache = _workbook_style_ids(workbook)
    key = (component_type, component)
    cached = cache.get(key)
    if cached is not None:
        return cached
    if component_type == "font":
        value = workbook._fonts.add(component)
    elif component_type == "fill":
        value = workbook._fills.add(component)
    elif component_type == "border":
        value = workbook._borders.add(component)
    elif component_type == "alignment":
        value = workbook._alignments.add(component)
    else:
        raise ValueError(f"Unsupported style component type: {component_type}")
    cache[key] = value
    return value


def _prebuilt_style_array(workbook, name: str) -> StyleArray:
    cache = _workbook_style_arrays(workbook)
    cached = cache.get(name)
    if cached is not None:
        return cached
    style = StyleArray()
    style.fontId = _style_component_id(workbook, "font", HEADER_FONT)
    style.borderId = _style_component_id(workbook, "border", THIN_BORDER)
    style.alignmentId = _style_component_id(workbook, "alignment", CENTER)
    if name == "header":
        style.fillId = _style_component_id(workbook, "fill", HEADER_FILL)
    elif name == "subheader":
        style.fillId = _style_component_id(workbook, "fill", SUBHEADER_FILL)
    else:
        raise ValueError(f"Unsupported prebuilt style name: {name}")
    cache[name] = style
    return style


def _apply_style_parts(
    cell,
    *,
    border: Border | None = None,
    alignment: Alignment | None = None,
    font: Font | None = None,
    fill: PatternFill | None = None,
) -> None:
    workbook = cell.parent.parent
    _apply_style_ids(
        cell,
        border_id=_style_component_id(workbook, "border", border) if border is not None else None,
        alignment_id=_style_component_id(workbook, "alignment", alignment)
        if alignment is not None
        else None,
        font_id=_style_component_id(workbook, "font", font) if font is not None else None,
        fill_id=_style_component_id(workbook, "fill", fill) if fill is not None else None,
    )


def _apply_style_ids(
    cell,
    *,
    border_id: int | None = None,
    alignment_id: int | None = None,
    font_id: int | None = None,
    fill_id: int | None = None,
) -> None:
    base_style = cell._style if cell._style is not None else StyleArray()
    transform_key = (
        tuple(base_style),
        border_id,
        alignment_id,
        font_id,
        fill_id,
    )
    workbook = cell.parent.parent
    transform_cache = _workbook_style_transforms(workbook)
    cached = transform_cache.get(transform_key)
    if cached is None:
        cached = copy(base_style)
        if border_id is not None:
            cached.borderId = border_id
        if alignment_id is not None:
            cached.alignmentId = alignment_id
        if font_id is not None:
            cached.fontId = font_id
        if fill_id is not None:
            cached.fillId = fill_id
        transform_cache[transform_key] = cached
    cell._style = cached


def _worksheet_effective_value(worksheet, row_index: int, column_index: int) -> Any:
    cell = worksheet.cell(row_index, column_index)
    if cell.value is not None:
        return cell.value
    for merged_range in worksheet.merged_cells.ranges:
        if (
            merged_range.min_row <= row_index <= merged_range.max_row
            and merged_range.min_col <= column_index <= merged_range.max_col
        ):
            return worksheet.cell(merged_range.min_row, merged_range.min_col).value
    return None


def _same_prefix_values(worksheet, start_row: int, current_row: int, current_column: int) -> bool:
    for col_index in range(1, current_column):
        if _worksheet_effective_value(worksheet, start_row, col_index) != _worksheet_effective_value(
            worksheet,
            current_row,
            col_index,
        ):
            return False
    return True


def _find_any_metric_value(raw_column: str, values: dict[MetricKey, MetricValue]) -> MetricValue | None:
    for (_dataset_id, _row_number, column), value in values.items():
        if column == raw_column:
            return value
    return None


def _find_any_golden_value(raw_column: str, values: dict[MetricKey, MetricValue]) -> float | None:
    entry = _find_any_metric_value(raw_column, values)
    return entry.golden_value if entry else None


def _build_column_display_values(
    values: dict[MetricKey, MetricValue],
    attribute: str,
) -> dict[str, Any]:
    grouped: dict[str, list[Any]] = defaultdict(list)
    for (_dataset_id, _row_number, raw_column), metric_value in values.items():
        value = getattr(metric_value, attribute)
        if value is None:
            continue
        grouped[raw_column].append(value)

    display_values: dict[str, Any] = {}
    for raw_column, items in grouped.items():
        normalized = _collapse_display_values(items)
        display_values[raw_column] = normalized
    return display_values


def _build_column_bound_display_values(
    values: dict[MetricKey, MetricValue],
) -> dict[str, Any]:
    grouped: dict[str, list[str]] = defaultdict(list)
    for (_dataset_id, _row_number, raw_column), metric_value in values.items():
        bound_text = _format_allowed_ranges_display(
            metric_value.allowed_ranges or [],
            fallback_lower_bound=metric_value.lower_bound,
            fallback_upper_bound=metric_value.upper_bound,
        )
        if not bound_text:
            continue
        grouped[raw_column].append(bound_text)

    display_values: dict[str, Any] = {}
    for raw_column, items in grouped.items():
        display_values[raw_column] = _collapse_display_values(items)
    return display_values


def _collapse_display_values(items: list[Any]) -> Any:
    if not items:
        return None
    if all(isinstance(item, (int, float)) for item in items):
        rounded = {round(float(item), 12) for item in items}
        if len(rounded) == 1:
            return items[0]
        return "Varies"
    unique = {str(item) for item in items}
    if len(unique) == 1:
        return items[0]
    return "Varies"


def _has_variable_metric_attribute(
    values: dict[MetricKey, MetricValue],
    attribute: str,
) -> bool:
    grouped: dict[str, set[Any]] = defaultdict(set)
    for (_dataset_id, _row_number, raw_column), metric_value in values.items():
        value = getattr(metric_value, attribute)
        if value is None:
            continue
        if isinstance(value, float):
            grouped[raw_column].add(round(value, 12))
        else:
            grouped[raw_column].add(value)
    return any(len(items) > 1 for items in grouped.values())


def _autosize_columns(worksheet) -> None:
    max_lengths: dict[int, int] = {}
    for (row_index, column_index), cell in worksheet._cells.items():
        value = cell.value
        if value is None:
            continue
        value_length = len(str(value))
        previous = max_lengths.get(column_index, 0)
        if value_length > previous:
            max_lengths[column_index] = value_length
    for index in range(1, worksheet.max_column + 1):
        max_length = max_lengths.get(index, 0)
        worksheet.column_dimensions[get_column_letter(index)].width = min(max(max_length + 2, 10), 24)


def _dedupe_summary_rows(
    rows: list[dict[str, str]],
    template: TemplateConfig,
    sample_node_orders: dict[tuple[str, ...], list[str]],
) -> list[dict[str, str]]:
    seen: set[tuple[str, str, str]] = set()
    deduped: list[dict[str, str]] = []
    for item in _sort_summary_rows(rows, sample_node_orders):
        key = (item["sample_id"], item["node"], item["chain"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(
            {
                "sample_id": item["sample_id"],
                "sample_key": item["sample_key"],
                "node": item["node"],
                "chain": item["chain"],
                "status": item["status"],
                "test_group_key": item.get("test_group_key", [item["chain"]]),
                "row_group_key": item.get("row_group_key", [item["node"]]),
                "row_group_dimensions": item.get("row_group_dimensions", ["reliability_node"]),
            }
        )
    return deduped


def _build_sample_row_group_test_details(
    template: TemplateConfig,
    sample_rows: list[RowData],
    test_group_columns: dict[tuple[str, ...], list[ColumnMeta]],
    fail_mode: str,
    test_fail_rule: str,
    merged_sample_fail_rule: str,
    zscore_values: dict[MetricKey, MetricValue],
    golden_values: dict[MetricKey, MetricValue],
) -> dict[tuple[str, ...], dict[tuple[str, ...], dict[str, Any]]]:
    details: dict[tuple[str, ...], dict[tuple[str, ...], dict[str, Any]]] = defaultdict(dict)
    rows_by_group: dict[tuple[str, ...], list[RowData]] = defaultdict(list)
    for row in sample_rows:
        rows_by_group[_outlier_row_group_key(row, template)].append(row)

    for row_group_key, group_rows in rows_by_group.items():
        representative_dimensions = dict(group_rows[0].dimensions) if group_rows else {}
        for test_group_key, columns in test_group_columns.items():
            row_statuses: list[bool] = []
            failing_columns: list[ColumnMeta] = []
            for row in group_rows:
                metric_statuses: list[bool] = []
                row_failing_columns: list[ColumnMeta] = []
                for column in columns:
                    z_entry = zscore_values.get(_row_metric_key(row, column.raw_column))
                    golden_entry = golden_values.get(_row_metric_key(row, column.raw_column))
                    is_fail = _is_metric_fail(fail_mode, z_entry, golden_entry)
                    metric_statuses.append(is_fail)
                    if is_fail:
                        row_failing_columns.append(column)
                if not metric_statuses:
                    continue
                row_test_fail = (
                    all(metric_statuses)
                    if test_fail_rule == "all_fail"
                    else any(metric_statuses)
                )
                row_statuses.append(row_test_fail)
                if row_test_fail:
                    failing_columns.extend(row_failing_columns)
            if not row_statuses:
                continue
            row_group_fail = (
                all(row_statuses)
                if merged_sample_fail_rule == "all_fail"
                else any(row_statuses)
            )
            details[row_group_key][test_group_key] = {
                "is_fail": row_group_fail,
                "dimensions": representative_dimensions,
                "group_ids": {column.group_id for column in failing_columns},
                "group_display_names": {
                    column.group_display_name for column in failing_columns
                },
                "test_types": {column.test_type for column in failing_columns},
                "chain_names": {column.chain_name for column in failing_columns},
                "column_names": {column.raw_column for column in failing_columns},
                "units": {
                    str(column.unit)
                    for column in failing_columns
                    if column.unit not in {None, ""}
                },
                "raw_columns": {column.raw_column for column in failing_columns},
                "logical_metrics": {column.logical_metric for column in failing_columns},
            }
    return details


def _build_sample_node_test_details(
    template: TemplateConfig,
    row_group_test_details: dict[tuple[str, ...], dict[tuple[str, ...], dict[str, Any]]],
    row_group_dimension_names: list[str],
    node_group_dimension_names: list[str],
) -> dict[tuple[str, ...], dict[tuple[str, ...], dict[str, Any]]]:
    node_fail_rule = template.report.outlier_node_fail_rule
    details_by_node: dict[tuple[str, ...], dict[tuple[str, ...], list[dict[str, Any]]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for row_group_key, test_groups in row_group_test_details.items():
        row_group_dimensions = dict(zip(row_group_dimension_names, row_group_key))
        node_key = tuple(
            str(row_group_dimensions.get(name, "") or "")
            for name in node_group_dimension_names
        )
        for test_group_key, detail in test_groups.items():
            details_by_node[node_key][test_group_key].append(detail)

    node_details: dict[tuple[str, ...], dict[tuple[str, ...], dict[str, Any]]] = defaultdict(dict)
    for node_key, test_groups in details_by_node.items():
        for test_group_key, detail_items in test_groups.items():
            statuses = [bool(item.get("is_fail")) for item in detail_items]
            if not statuses:
                continue
            is_fail = all(statuses) if node_fail_rule == "all_fail" else any(statuses)
            failing_items = [item for item in detail_items if item.get("is_fail")]
            representative_dimensions = (
                dict(failing_items[0].get("dimensions", {}))
                if failing_items
                else dict(detail_items[0].get("dimensions", {}))
            )
            node_details[node_key][test_group_key] = {
                "is_fail": is_fail,
                "dimensions": representative_dimensions,
                "group_ids": {
                    value
                    for item in failing_items
                    for value in item.get("group_ids", set())
                },
                "group_display_names": {
                    value
                    for item in failing_items
                    for value in item.get("group_display_names", set())
                },
                "test_types": {
                    value
                    for item in failing_items
                    for value in item.get("test_types", set())
                },
                "chain_names": {
                    value
                    for item in failing_items
                    for value in item.get("chain_names", set())
                },
                "column_names": {
                    value
                    for item in failing_items
                    for value in item.get("column_names", set())
                },
                "units": {
                    value
                    for item in failing_items
                    for value in item.get("units", set())
                },
                "raw_columns": {
                    value
                    for item in failing_items
                    for value in item.get("raw_columns", set())
                },
                "logical_metrics": {
                    value
                    for item in failing_items
                    for value in item.get("logical_metrics", set())
                },
            }
    return node_details


def _build_sample_node_ancestor_chains(
    observed_nodes: set[str],
    configured_node_orders: list[list[str]],
) -> dict[str, list[str]]:
    ancestor_chains: dict[str, list[str]] = defaultdict(list)
    for node_order in configured_node_orders:
        for current_index, current_node in enumerate(node_order):
            if current_node not in observed_nodes:
                continue
            for previous_index in range(current_index - 1, -1, -1):
                previous_node = node_order[previous_index]
                if previous_node not in observed_nodes:
                    continue
                if previous_node not in ancestor_chains[current_node]:
                    ancestor_chains[current_node].append(previous_node)
    return ancestor_chains


def _build_outlier_ratio_rows(
    configs: list[OutlierRatioStatConfig],
    summary_events: list[dict[str, Any]],
    rows: list[RowData],
    sample_node_orders: dict[tuple[str, ...], list[str]],
    sample_dimension_names: list[str],
) -> list[dict[str, Any]]:
    if not configs:
        return []
    merged_node_order = _merge_node_orders(sample_node_orders.values())
    rows_by_dimension: dict[str, dict[tuple[str, ...], set[str]]] = defaultdict(
        lambda: defaultdict(set)
    )
    for row in rows:
        sample_key = _sample_key_from_dimensions(row.dimensions, sample_dimension_names)
        if not all(sample_key):
            continue
        for config in configs:
            group_dimensions = _effective_ratio_group_dimensions(config)
            group_key = tuple(
                str(row.dimensions.get(dimension_name, "") or "")
                for dimension_name in group_dimensions
            )
            if all(group_key):
                rows_by_dimension[config.id][group_key].add(sample_key)

    ratio_rows: list[dict[str, Any]] = []
    for config in configs:
        group_dimensions = _effective_ratio_group_dimensions(config)
        sample_ids_by_group = rows_by_dimension.get(config.id, {})
        for group_key in sorted(
            sample_ids_by_group,
            key=lambda item: _ratio_group_sort_key(
                item,
                group_dimensions,
                merged_node_order,
            ),
        ):
            total_sample_count = len(sample_ids_by_group[group_key])
            matching_events = [
                event
                for event in summary_events
                if _event_group_key(event, group_dimensions) == group_key
                and _summary_event_matches_ratio_config(event, config)
                and (
                    config.numerator != "new_outlier_samples"
                    or str(event.get("status", "")) == "New"
                )
            ]
            matched_sample_ids = {
                tuple(str(value) for value in event.get("sample_key", []))
                for event in matching_events
            }
            row_payload = {
                "id": config.id,
                "display_name": config.display_name or config.id,
                "group_by_dimension": " + ".join(group_dimensions),
                "group_value": " | ".join(group_key),
                "numerator": config.numerator,
                "outlier_sample_count": len(matched_sample_ids),
                "total_sample_count": total_sample_count,
                "outlier_ratio": (
                    len(matched_sample_ids) / total_sample_count
                    if total_sample_count
                    else 0.0
                ),
                "filter_summary": _format_ratio_filter_summary(config),
            }
            lot_sample_pairs = _build_ratio_lot_sample_pairs(matching_events)
            if lot_sample_pairs:
                row_payload["lot_sample_pairs"] = lot_sample_pairs
            ratio_rows.append(row_payload)
    return sorted(
        ratio_rows,
        key=lambda item: (
            _natural_sort_key(str(item["display_name"])),
            _ratio_group_value_display_sort_key(
                str(item["group_by_dimension"]),
                str(item["group_value"]),
                merged_node_order,
            ),
        ),
    )


def _build_ratio_lot_sample_pairs(
    matching_events: list[dict[str, Any]],
) -> list[tuple[str, str]]:
    sample_ids_by_lot: dict[str, set[str]] = defaultdict(set)
    for event in matching_events:
        dimensions = event.get("dimensions", {})
        if not isinstance(dimensions, dict):
            dimensions = {}
        lot_value = str(
            dimensions.get("lot", "")
            or dimensions.get("lot_id", "")
            or ""
        ).strip()
        sample_id_value = str(
            dimensions.get("sample_id", "")
            or event.get("sample_id", "")
            or ""
        ).strip()
        if not sample_id_value:
            continue
        sample_ids_by_lot[lot_value].add(sample_id_value)
    pairs: list[tuple[str, str]] = []
    for lot_value in sorted(sample_ids_by_lot, key=_natural_sort_key):
        sample_ids = sorted(sample_ids_by_lot[lot_value], key=_natural_sort_key)
        pairs.append((lot_value, ";".join(sample_ids)))
    return pairs


def _effective_ratio_group_dimensions(config: OutlierRatioStatConfig) -> list[str]:
    return [
        str(value).strip()
        for value in (config.group_by_dimensions or [config.group_by_dimension])
        if str(value).strip()
    ]


def _event_group_key(
    event: dict[str, Any],
    group_dimensions: list[str],
) -> tuple[str, ...]:
    dimensions = event.get("dimensions", {}) or {}
    return tuple(str(dimensions.get(dimension_name, "") or "") for dimension_name in group_dimensions)


def _ratio_group_sort_key(
    group_key: tuple[str, ...],
    group_dimensions: list[str],
    merged_node_order: list[str],
) -> tuple[Any, ...]:
    sort_values: list[Any] = []
    for dimension_name, value in zip(group_dimensions, group_key):
        if dimension_name == "reliability_node":
            sort_values.append(_node_sort_key(value, merged_node_order))
        else:
            sort_values.append(_natural_sort_key(value))
    return tuple(sort_values)


def _ratio_group_value_display_sort_key(
    group_by_dimension_label: str,
    group_value_label: str,
    merged_node_order: list[str],
) -> tuple[Any, ...]:
    dimensions = [item.strip() for item in group_by_dimension_label.split("+") if item.strip()]
    values = [item.strip() for item in group_value_label.split("|")]
    return _ratio_group_sort_key(tuple(values), dimensions, merged_node_order)


def _summary_event_matches_ratio_config(
    event: dict[str, Any],
    config: OutlierRatioStatConfig,
) -> bool:
    if config.group_ids:
        event_group_ids = set(event.get("group_ids", []))
        if not event_group_ids.intersection(config.group_ids):
            return False
    if config.group_display_names:
        event_group_display_names = set(event.get("group_display_names", []))
        if not event_group_display_names.intersection(config.group_display_names):
            return False
    if config.test_types:
        event_test_types = set(event.get("test_types", []))
        if not event_test_types.intersection(config.test_types):
            return False
    effective_chain_names = config.chain_names or config.chains
    if effective_chain_names:
        event_chain_names = set(event.get("chain_names", []))
        if not event_chain_names.intersection(effective_chain_names):
            return False
    effective_column_names = config.column_names or config.raw_columns
    if effective_column_names:
        event_column_names = set(event.get("column_names", [])) or set(event.get("raw_columns", []))
        if not event_column_names.intersection(effective_column_names):
            return False
    if config.units:
        event_units = set(event.get("units", []))
        if not event_units.intersection(config.units):
            return False
    if config.logical_metrics:
        event_logical_metrics = set(event.get("logical_metrics", []))
        if not event_logical_metrics.intersection(config.logical_metrics):
            return False
    return True


def _format_ratio_filter_summary(config: OutlierRatioStatConfig) -> str:
    items: list[str] = []
    if config.group_ids:
        items.append("id=" + ",".join(config.group_ids))
    if config.group_display_names:
        items.append("display_name=" + ",".join(config.group_display_names))
    if config.test_types:
        items.append("test_type=" + ",".join(config.test_types))
    effective_chain_names = config.chain_names or config.chains
    if effective_chain_names:
        items.append("chain_name=" + ",".join(effective_chain_names))
    effective_column_names = config.column_names or config.raw_columns
    if effective_column_names:
        items.append("column_name=" + ",".join(effective_column_names))
    if config.units:
        items.append("unit=" + ",".join(config.units))
    if config.logical_metrics:
        items.append("logical_metric=" + ",".join(config.logical_metrics))
    return " | ".join(items) if items else "No filters"


def _merge_node_orders(node_orders: Any) -> list[str]:
    merged: list[str] = []
    for node_order in node_orders:
        for node in node_order:
            if node not in merged:
                merged.append(node)
    return merged


def _format_fail_mode(value: str) -> str:
    if value == "modified_z_score":
        return "Modified Z Score"
    if value == "golden_deviation":
        return "Golden Deviation"
    if value == "zscore_and_golden":
        return "Modified Z Score And Golden Deviation"
    if value == "zscore_or_golden":
        return "Modified Z Score Or Golden Deviation"
    return value


def _build_sample_node_orders(
    rows: list[RowData],
    template: TemplateConfig,
) -> dict[tuple[str, ...], list[str]]:
    configured = _configured_node_orders(template)
    if not configured:
        return {}
    sample_dimension_names = _sample_dimension_names(template)
    nodes_by_sample: dict[tuple[str, ...], set[str]] = defaultdict(set)
    for row in rows:
        sample_id = _sample_key_from_dimensions(row.dimensions, sample_dimension_names)
        node_value = row.dimensions.get("reliability_node", "")
        if all(sample_id) and node_value:
            nodes_by_sample[sample_id].add(node_value)
    return {
        sample_id: _resolve_sample_node_order(observed_nodes, configured)
        for sample_id, observed_nodes in nodes_by_sample.items()
    }


def _configured_node_orders(template: TemplateConfig) -> list[list[str]]:
    if template.report.node_orders:
        return [list(item) for item in template.report.node_orders if item]
    if template.report.node_order:
        return [list(template.report.node_order)]
    return []


def _resolve_sample_node_order(
    observed_nodes: set[str],
    configured_node_orders: list[list[str]],
) -> list[str]:
    best_order = configured_node_orders[0]
    best_score = _node_order_match_score(observed_nodes, best_order)
    for candidate in configured_node_orders[1:]:
        score = _node_order_match_score(observed_nodes, candidate)
        if score < best_score:
            best_order = candidate
            best_score = score
    return list(best_order)


def _node_order_match_score(
    observed_nodes: set[str],
    node_order: list[str],
) -> tuple[int, int, tuple[Any, ...]]:
    configured_nodes = set(node_order)
    unknown_count = len([node for node in observed_nodes if node not in configured_nodes])
    unused_configured_count = len([node for node in node_order if node not in observed_nodes])
    return (
        unknown_count,
        unused_configured_count,
        tuple(_natural_sort_key(node) for node in node_order),
    )


def _node_sort_key(value: str, node_order: list[str]) -> tuple[int, Any]:
    if value in node_order:
        return (0, node_order.index(value))
    return (1, _natural_sort_key(value))


def _sort_summary_rows(
    rows: list[dict[str, str]],
    sample_node_orders: dict[tuple[str, ...], list[str]],
) -> list[dict[str, str]]:
    return sorted(
        rows,
        key=lambda payload: (
            tuple(
                _natural_sort_key(value)
                for value in payload.get("sample_key", [payload["sample_id"]])
            ),
            _row_group_sort_key(
                tuple(str(value) for value in payload.get("row_group_key", [])),
                [str(value) for value in payload.get("row_group_dimensions", [])],
                sample_node_orders.get(
                    tuple(str(value) for value in payload.get("sample_key", [payload["sample_id"]])),
                    [],
                ),
            ),
            tuple(
                _natural_sort_key(value)
                for value in payload.get("test_group_key", [payload["chain"]])
            ),
        ),
    )


@lru_cache(maxsize=8192)
def _natural_sort_key_cached(value: str) -> tuple[Any, ...]:
    parts = NATURAL_SORT_SPLIT_RE.split(value)
    key: list[Any] = []
    for part in parts:
        if not part:
            continue
        if part.isdigit():
            key.append((0, int(part)))
        else:
            key.append((1, part.lower()))
    return tuple(key)


def _natural_sort_key(value: str) -> tuple[Any, ...]:
    return _natural_sort_key_cached(value or "")


def _safe_int(value: str | None) -> int:
    if value is None:
        return 0
    match = re.search(r"\d+", str(value))
    if match:
        return int(match.group())
    return 0


def _display_dimension_value(value: str | None) -> Any:
    if value is None:
        return None
    text = str(value)
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    if re.fullmatch(r"-?\d+\.\d+", text):
        return float(text)
    return text
