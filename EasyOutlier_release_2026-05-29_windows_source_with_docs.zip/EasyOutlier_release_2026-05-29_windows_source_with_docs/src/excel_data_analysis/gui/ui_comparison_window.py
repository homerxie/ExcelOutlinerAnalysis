# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'comparison_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QFrame, QGridLayout, QGroupBox, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMainWindow, QPushButton, QScrollArea,
    QSizePolicy, QSplitter, QStatusBar, QTableWidget,
    QTableWidgetItem, QToolButton, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout, QWidget)

class Ui_PlotInspectorWindow(object):
    def setupUi(self, PlotInspectorWindow):
        if not PlotInspectorWindow.objectName():
            PlotInspectorWindow.setObjectName(u"PlotInspectorWindow")
        PlotInspectorWindow.resize(1280, 780)
        self.centralwidget = QWidget(PlotInspectorWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.mainLayout = QVBoxLayout(self.centralwidget)
        self.mainLayout.setObjectName(u"mainLayout")
        self.mainSplitter = QSplitter(self.centralwidget)
        self.mainSplitter.setObjectName(u"mainSplitter")
        self.mainSplitter.setOrientation(Qt.Horizontal)
        self.controlPanelScrollArea = QScrollArea(self.mainSplitter)
        self.controlPanelScrollArea.setObjectName(u"controlPanelScrollArea")
        self.controlPanelScrollArea.setMinimumSize(QSize(340, 0))
        self.controlPanelScrollArea.setMaximumSize(QSize(460, 16777215))
        self.controlPanelScrollArea.setWidgetResizable(True)
        self.controlPanelScrollArea.setFrameShape(QFrame.NoFrame)
        self.controlPanel = QWidget()
        self.controlPanel.setObjectName(u"controlPanel")
        self.controlPanel.setGeometry(QRect(0, 0, 340, 720))
        self.controlPanelLayout = QVBoxLayout(self.controlPanel)
        self.controlPanelLayout.setSpacing(10)
        self.controlPanelLayout.setObjectName(u"controlPanelLayout")
        self.metricFilterGroupBox = QGroupBox(self.controlPanel)
        self.metricFilterGroupBox.setObjectName(u"metricFilterGroupBox")
        self.metricFilterLayout = QVBoxLayout(self.metricFilterGroupBox)
        self.metricFilterLayout.setSpacing(8)
        self.metricFilterLayout.setObjectName(u"metricFilterLayout")
        self.advancedMetricFilterButton = QToolButton(self.metricFilterGroupBox)
        self.advancedMetricFilterButton.setObjectName(u"advancedMetricFilterButton")
        self.advancedMetricFilterButton.setCheckable(True)
        self.advancedMetricFilterButton.setChecked(False)

        self.metricFilterLayout.addWidget(self.advancedMetricFilterButton)

        self.advancedMetricFilterWidget = QWidget(self.metricFilterGroupBox)
        self.advancedMetricFilterWidget.setObjectName(u"advancedMetricFilterWidget")
        self.advancedMetricFilterWidget.setVisible(False)
        self.advancedMetricFilterLayout = QVBoxLayout(self.advancedMetricFilterWidget)
        self.advancedMetricFilterLayout.setSpacing(8)
        self.advancedMetricFilterLayout.setObjectName(u"advancedMetricFilterLayout")
        self.advancedMetricFilterLayout.setContentsMargins(0, 0, 0, 0)
        self.metricRuleInputLayout = QGridLayout()
        self.metricRuleInputLayout.setObjectName(u"metricRuleInputLayout")
        self.metricRuleInputLayout.setHorizontalSpacing(8)
        self.metricRuleInputLayout.setVerticalSpacing(6)
        self.metricConnectorComboBox = QComboBox(self.advancedMetricFilterWidget)
        self.metricConnectorComboBox.addItem("")
        self.metricConnectorComboBox.addItem("")
        self.metricConnectorComboBox.addItem("")
        self.metricConnectorComboBox.setObjectName(u"metricConnectorComboBox")

        self.metricRuleInputLayout.addWidget(self.metricConnectorComboBox, 0, 0, 1, 1)

        self.metricFieldComboBox = QComboBox(self.advancedMetricFilterWidget)
        self.metricFieldComboBox.setObjectName(u"metricFieldComboBox")

        self.metricRuleInputLayout.addWidget(self.metricFieldComboBox, 0, 1, 1, 1)

        self.metricOperatorComboBox = QComboBox(self.advancedMetricFilterWidget)
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.addItem("")
        self.metricOperatorComboBox.setObjectName(u"metricOperatorComboBox")

        self.metricRuleInputLayout.addWidget(self.metricOperatorComboBox, 1, 0, 1, 1)

        self.metricValueComboBox = QComboBox(self.advancedMetricFilterWidget)
        self.metricValueComboBox.setObjectName(u"metricValueComboBox")
        self.metricValueComboBox.setEditable(True)
        self.metricValueComboBox.setInsertPolicy(QComboBox.NoInsert)

        self.metricRuleInputLayout.addWidget(self.metricValueComboBox, 1, 1, 1, 1)

        self.addMetricRuleButton = QPushButton(self.advancedMetricFilterWidget)
        self.addMetricRuleButton.setObjectName(u"addMetricRuleButton")

        self.metricRuleInputLayout.addWidget(self.addMetricRuleButton, 2, 0, 1, 1)

        self.clearMetricRulesButton = QPushButton(self.advancedMetricFilterWidget)
        self.clearMetricRulesButton.setObjectName(u"clearMetricRulesButton")

        self.metricRuleInputLayout.addWidget(self.clearMetricRulesButton, 2, 1, 1, 1)


        self.advancedMetricFilterLayout.addLayout(self.metricRuleInputLayout)

        self.metricRuleActionLayout = QHBoxLayout()
        self.metricRuleActionLayout.setObjectName(u"metricRuleActionLayout")
        self.deleteMetricRuleButton = QPushButton(self.advancedMetricFilterWidget)
        self.deleteMetricRuleButton.setObjectName(u"deleteMetricRuleButton")

        self.metricRuleActionLayout.addWidget(self.deleteMetricRuleButton)

        self.modifyMetricRuleButton = QPushButton(self.advancedMetricFilterWidget)
        self.modifyMetricRuleButton.setObjectName(u"modifyMetricRuleButton")

        self.metricRuleActionLayout.addWidget(self.modifyMetricRuleButton)


        self.advancedMetricFilterLayout.addLayout(self.metricRuleActionLayout)

        self.metricRulesTableWidget = QTableWidget(self.advancedMetricFilterWidget)
        if (self.metricRulesTableWidget.columnCount() < 4):
            self.metricRulesTableWidget.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.metricRulesTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.metricRulesTableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.metricRulesTableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.metricRulesTableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        self.metricRulesTableWidget.setObjectName(u"metricRulesTableWidget")
        self.metricRulesTableWidget.setMinimumSize(QSize(0, 90))
        self.metricRulesTableWidget.setMaximumSize(QSize(16777215, 130))
        self.metricRulesTableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.metricRulesTableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)

        self.advancedMetricFilterLayout.addWidget(self.metricRulesTableWidget)


        self.metricFilterLayout.addWidget(self.advancedMetricFilterWidget)


        self.controlPanelLayout.addWidget(self.metricFilterGroupBox)

        self.plotOptionsGroupBox = QGroupBox(self.controlPanel)
        self.plotOptionsGroupBox.setObjectName(u"plotOptionsGroupBox")
        self.plotOptionsLayout = QGridLayout(self.plotOptionsGroupBox)
        self.plotOptionsLayout.setObjectName(u"plotOptionsLayout")
        self.plotTypeLabel = QLabel(self.plotOptionsGroupBox)
        self.plotTypeLabel.setObjectName(u"plotTypeLabel")

        self.plotOptionsLayout.addWidget(self.plotTypeLabel, 0, 0, 1, 1)

        self.plotTypeComboBox = QComboBox(self.plotOptionsGroupBox)
        self.plotTypeComboBox.addItem("")
        self.plotTypeComboBox.addItem("")
        self.plotTypeComboBox.setObjectName(u"plotTypeComboBox")

        self.plotOptionsLayout.addWidget(self.plotTypeComboBox, 0, 1, 1, 1)

        self.laneGroupingLabel = QLabel(self.plotOptionsGroupBox)
        self.laneGroupingLabel.setObjectName(u"laneGroupingLabel")

        self.plotOptionsLayout.addWidget(self.laneGroupingLabel, 1, 0, 1, 1)

        self.laneDimensionsListWidget = QListWidget(self.plotOptionsGroupBox)
        self.laneDimensionsListWidget.setObjectName(u"laneDimensionsListWidget")
        self.laneDimensionsListWidget.setMinimumSize(QSize(0, 72))
        self.laneDimensionsListWidget.setMaximumSize(QSize(16777215, 96))
        self.laneDimensionsListWidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.laneDimensionsListWidget.setDragEnabled(True)
        self.laneDimensionsListWidget.setDragDropMode(QAbstractItemView.InternalMove)
        self.laneDimensionsListWidget.setDefaultDropAction(Qt.MoveAction)

        self.plotOptionsLayout.addWidget(self.laneDimensionsListWidget, 1, 1, 1, 1)


        self.controlPanelLayout.addWidget(self.plotOptionsGroupBox)

        self.matchedMetricsGroupBox = QGroupBox(self.controlPanel)
        self.matchedMetricsGroupBox.setObjectName(u"matchedMetricsGroupBox")
        self.matchedMetricsLayout = QVBoxLayout(self.matchedMetricsGroupBox)
        self.matchedMetricsLayout.setObjectName(u"matchedMetricsLayout")
        self.metricSearchLayout = QGridLayout()
        self.metricSearchLayout.setObjectName(u"metricSearchLayout")
        self.metricSearchLayout.setHorizontalSpacing(8)
        self.metricSearchLayout.setVerticalSpacing(10)
        self.metricSearchEdit = QLineEdit(self.matchedMetricsGroupBox)
        self.metricSearchEdit.setObjectName(u"metricSearchEdit")

        self.metricSearchLayout.addWidget(self.metricSearchEdit, 0, 0, 1, 4)

        self.metricSearchViewComboBox = QComboBox(self.matchedMetricsGroupBox)
        self.metricSearchViewComboBox.addItem("")
        self.metricSearchViewComboBox.addItem("")
        self.metricSearchViewComboBox.setObjectName(u"metricSearchViewComboBox")

        self.metricSearchLayout.addWidget(self.metricSearchViewComboBox, 1, 0, 1, 4)

        self.metricRealtimeCheckBox = QCheckBox(self.matchedMetricsGroupBox)
        self.metricRealtimeCheckBox.setObjectName(u"metricRealtimeCheckBox")
        self.metricRealtimeCheckBox.setChecked(False)

        self.metricSearchLayout.addWidget(self.metricRealtimeCheckBox, 2, 0, 1, 2)

        self.metricSearchButton = QPushButton(self.matchedMetricsGroupBox)
        self.metricSearchButton.setObjectName(u"metricSearchButton")

        self.metricSearchLayout.addWidget(self.metricSearchButton, 2, 2, 1, 2)

        self.metricSearchPrevButton = QPushButton(self.matchedMetricsGroupBox)
        self.metricSearchPrevButton.setObjectName(u"metricSearchPrevButton")

        self.metricSearchLayout.addWidget(self.metricSearchPrevButton, 3, 0, 1, 1)

        self.metricSearchNextButton = QPushButton(self.matchedMetricsGroupBox)
        self.metricSearchNextButton.setObjectName(u"metricSearchNextButton")

        self.metricSearchLayout.addWidget(self.metricSearchNextButton, 3, 1, 1, 1)

        self.metricSearchStatusLabel = QLabel(self.matchedMetricsGroupBox)
        self.metricSearchStatusLabel.setObjectName(u"metricSearchStatusLabel")
        self.metricSearchStatusLabel.setMinimumSize(QSize(64, 0))
        self.metricSearchStatusLabel.setAlignment(Qt.AlignCenter)

        self.metricSearchLayout.addWidget(self.metricSearchStatusLabel, 3, 2, 1, 2)

        self.selectAllMetricsButton = QPushButton(self.matchedMetricsGroupBox)
        self.selectAllMetricsButton.setObjectName(u"selectAllMetricsButton")

        self.metricSearchLayout.addWidget(self.selectAllMetricsButton, 4, 0, 1, 2)

        self.deselectAllMetricsButton = QPushButton(self.matchedMetricsGroupBox)
        self.deselectAllMetricsButton.setObjectName(u"deselectAllMetricsButton")

        self.metricSearchLayout.addWidget(self.deselectAllMetricsButton, 4, 2, 1, 2)


        self.matchedMetricsLayout.addLayout(self.metricSearchLayout)

        self.metricTreeWidget = QTreeWidget(self.matchedMetricsGroupBox)
        self.metricTreeWidget.setObjectName(u"metricTreeWidget")
        self.metricTreeWidget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.metricTreeWidget.setRootIsDecorated(True)
        self.metricTreeWidget.setItemsExpandable(True)
        self.metricTreeWidget.setAllColumnsShowFocus(True)

        self.matchedMetricsLayout.addWidget(self.metricTreeWidget)


        self.controlPanelLayout.addWidget(self.matchedMetricsGroupBox)

        self.refreshButton = QPushButton(self.controlPanel)
        self.refreshButton.setObjectName(u"refreshButton")

        self.controlPanelLayout.addWidget(self.refreshButton)

        self.controlPanelScrollArea.setWidget(self.controlPanel)
        self.mainSplitter.addWidget(self.controlPanelScrollArea)
        self.plotPanel = QWidget(self.mainSplitter)
        self.plotPanel.setObjectName(u"plotPanel")
        self.plotPanelLayout = QVBoxLayout(self.plotPanel)
        self.plotPanelLayout.setObjectName(u"plotPanelLayout")
        self.plotPanelLayout.setContentsMargins(0, 0, 0, 0)
        self.summaryLabel = QLabel(self.plotPanel)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)

        self.plotPanelLayout.addWidget(self.summaryLabel)

        self.plotScrollArea = QScrollArea(self.plotPanel)
        self.plotScrollArea.setObjectName(u"plotScrollArea")
        self.plotScrollArea.setWidgetResizable(True)
        self.plotScrollArea.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.plotScrollAreaWidgetContents = QWidget()
        self.plotScrollAreaWidgetContents.setObjectName(u"plotScrollAreaWidgetContents")
        self.plotScrollAreaWidgetContents.setGeometry(QRect(0, 0, 870, 650))
        self.plotScrollArea.setWidget(self.plotScrollAreaWidgetContents)

        self.plotPanelLayout.addWidget(self.plotScrollArea)

        self.mainSplitter.addWidget(self.plotPanel)

        self.mainLayout.addWidget(self.mainSplitter)

        PlotInspectorWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(PlotInspectorWindow)
        self.statusbar.setObjectName(u"statusbar")
        PlotInspectorWindow.setStatusBar(self.statusbar)

        self.retranslateUi(PlotInspectorWindow)

        QMetaObject.connectSlotsByName(PlotInspectorWindow)
    # setupUi

    def retranslateUi(self, PlotInspectorWindow):
        PlotInspectorWindow.setWindowTitle(QCoreApplication.translate("PlotInspectorWindow", u"Plot Inspector", None))
        self.metricFilterGroupBox.setTitle(QCoreApplication.translate("PlotInspectorWindow", u"Data Filter", None))
        self.advancedMetricFilterButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Advanced Filter", None))
        self.metricConnectorComboBox.setItemText(0, QCoreApplication.translate("PlotInspectorWindow", u"and", None))
        self.metricConnectorComboBox.setItemText(1, QCoreApplication.translate("PlotInspectorWindow", u"or", None))
        self.metricConnectorComboBox.setItemText(2, QCoreApplication.translate("PlotInspectorWindow", u"and not", None))

        self.metricOperatorComboBox.setItemText(0, QCoreApplication.translate("PlotInspectorWindow", u"contains", None))
        self.metricOperatorComboBox.setItemText(1, QCoreApplication.translate("PlotInspectorWindow", u"is", None))
        self.metricOperatorComboBox.setItemText(2, QCoreApplication.translate("PlotInspectorWindow", u"is not", None))
        self.metricOperatorComboBox.setItemText(3, QCoreApplication.translate("PlotInspectorWindow", u"does not contain", None))
        self.metricOperatorComboBox.setItemText(4, QCoreApplication.translate("PlotInspectorWindow", u"starts with", None))
        self.metricOperatorComboBox.setItemText(5, QCoreApplication.translate("PlotInspectorWindow", u"ends with", None))
        self.metricOperatorComboBox.setItemText(6, QCoreApplication.translate("PlotInspectorWindow", u"is in", None))
        self.metricOperatorComboBox.setItemText(7, QCoreApplication.translate("PlotInspectorWindow", u"has outlier", None))

        self.metricValueComboBox.setPlaceholderText(QCoreApplication.translate("PlotInspectorWindow", u"leakage, ChainA, TestType1...", None))
        self.addMetricRuleButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Add Rule", None))
        self.clearMetricRulesButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Clear Rules", None))
        self.deleteMetricRuleButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Delete Selected Rule", None))
        self.modifyMetricRuleButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Modify Selected Rule", None))
        ___qtablewidgetitem = self.metricRulesTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("PlotInspectorWindow", u"Connector", None))
        ___qtablewidgetitem1 = self.metricRulesTableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("PlotInspectorWindow", u"Field", None))
        ___qtablewidgetitem2 = self.metricRulesTableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("PlotInspectorWindow", u"Operator", None))
        ___qtablewidgetitem3 = self.metricRulesTableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("PlotInspectorWindow", u"Value", None))
        self.plotOptionsGroupBox.setTitle(QCoreApplication.translate("PlotInspectorWindow", u"Plot Options", None))
        self.plotTypeLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Plot Type", None))
        self.plotTypeComboBox.setItemText(0, QCoreApplication.translate("PlotInspectorWindow", u"Ridge Plot", None))
        self.plotTypeComboBox.setItemText(1, QCoreApplication.translate("PlotInspectorWindow", u"Box Plot", None))

#if QT_CONFIG(tooltip)
        self.laneGroupingLabel.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"Leave all unchecked to combine all rows into one lane. Drag checked dimensions to change label order and lane sorting.", None))
#endif // QT_CONFIG(tooltip)
        self.laneGroupingLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"Lane Dimensions", None))
#if QT_CONFIG(tooltip)
        self.laneDimensionsListWidget.setToolTip(QCoreApplication.translate("PlotInspectorWindow", u"Leave all unchecked to combine all rows into one lane. Drag checked dimensions to change label order and lane sorting.", None))
#endif // QT_CONFIG(tooltip)
        self.matchedMetricsGroupBox.setTitle(QCoreApplication.translate("PlotInspectorWindow", u"Matched Metrics", None))
        self.metricSearchEdit.setPlaceholderText(QCoreApplication.translate("PlotInspectorWindow", u"Search metric, axis title, lane header, or lane label...", None))
        self.metricSearchViewComboBox.setItemText(0, QCoreApplication.translate("PlotInspectorWindow", u"Compact Results", None))
        self.metricSearchViewComboBox.setItemText(1, QCoreApplication.translate("PlotInspectorWindow", u"In Place", None))

        self.metricRealtimeCheckBox.setText(QCoreApplication.translate("PlotInspectorWindow", u"Realtime refresh", None))
        self.metricSearchButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Search", None))
        self.metricSearchPrevButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Prev", None))
        self.metricSearchNextButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Next", None))
        self.metricSearchStatusLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"0 / 0", None))
        self.selectAllMetricsButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Select All", None))
        self.deselectAllMetricsButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Deselect All", None))
        ___qtreewidgetitem = self.metricTreeWidget.headerItem()
        ___qtreewidgetitem.setText(1, QCoreApplication.translate("PlotInspectorWindow", u"Points", None))
        ___qtreewidgetitem.setText(0, QCoreApplication.translate("PlotInspectorWindow", u"Metric / Lane", None))
        self.refreshButton.setText(QCoreApplication.translate("PlotInspectorWindow", u"Refresh Plot", None))
        self.summaryLabel.setText(QCoreApplication.translate("PlotInspectorWindow", u"No plot data loaded.", None))
    # retranslateUi

