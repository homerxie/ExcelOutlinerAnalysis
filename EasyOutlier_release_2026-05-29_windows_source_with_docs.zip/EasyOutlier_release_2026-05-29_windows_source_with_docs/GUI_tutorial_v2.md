# Easy Outlier GUI Tutorial V2

[toc]

文本目标：

- 这个软件到底在处理什么对象
- 为什么使用流程通常是 `Setup -> Import -> Golden -> Analyze -> Save`
- 每个模块背后程序实际做了什么
- GUI 上每个常见输入框代表什么
- 如果某个输入需要去 template 里配置，应该去 `template_help_v2` 的哪一节看

## 1. 三个核心概念

| 对象 | 解释 | 主要作用 |
| --- | --- | --- |
| `Template File` | 规则模版 | 定义怎么识别行维度、怎么识别测试列、怎么做 group、怎么做 merge、怎么做 ratio 统计。 |
| `Database Folder` | 当前项目工作区 | 保存已导入的数据、built golden、分析结果、当前 GUI 工作状态。 |
| `Input Excel/CSV` | 这次要读入的原始数据 | 被 template 解析后，变成软件内部可分析的基础数据。 |

如果只记一句话，可以记成：

- `template` 决定“怎么理解数据”
- `database` 决定“现在这个项目已经积累了哪些数据和结果”
- `input file` 决定“这次新增要处理哪份原始文件”

## 2. 总流程图

下面这张图是全局总流程图。后面每个模块的小流程图，都会继续沿用这张图里的输入和输出关系。

```mermaid
flowchart TD
    subgraph S["1. Setup"]
        S1["选择 Database Folder"]
        S2["选择 Template File"]
        S3["选择 Input Excel/CSV"]
        S4["剔除 Input 无效字符"]
    end

    subgraph I["2. Import"]
        I1["按 template 解析输入文件"]
        I2["生成测试结果快照"]
        I3["写入当前 Database Folder"]
    end

    subgraph G["3. Golden"]
        G1["从数据库读取测试数据"]
        G2["读取 template golden 规则，检查是否有冲突"]
        G3["按 reference dims + filters 分组"]
        G4["计算 golden center 与允许范围"]
        G5["保存 built golden JSON"]
    end

    subgraph A["4. Analyze"]
        A1["选 analysis scope"]
    		A2["读取 template fail 判定规则，检查是否有冲突"]
        A3["应用 sample / node / test 过滤"]
        A4["对最基础数据点做 zscore / golden fail 判定"]
        A5["按顺序聚合最基础数据点做 node + test group 组合 fail 判定"]
        A6["检查failed node + test group 组合是 new / existed / recovered"]
        A7["导出结果含有所有数据的_data.xlsx和异常筛选统计数据的_outlier.xlsx"]
    end

    subgraph R["5. Result"]
        R1["刷新GUI Golden Coverage"]
        R2["刷新GUI Outlier Summary"]
    end

    subgraph D["6. Save"]
        D1["Save Database"]
        D2["Save Database As"]
    end

    S1 --> S2 --> S3 --> S4 --> I1
    I1 --> I2 --> I3
    I3 --> G1
    I3 --> A1
    G1 --> G2 --> G3 --> G4 --> G5
    G4 --> A4
    A1 --> A2 --> A3 --> A4 --> A5 --> A6 --> A7
    A6 --> R1
    A6 --> R2
    R1 --> D1
    R2 --> D1
    D1 --> D2
```

## 3. 最常用流程

对于大多数日常项目，推荐直接按下面的顺序使用：

1. 在 `Setup` 里确定 `Database Folder`、`Template File`、`Input Excel/CSV`
2. 如果原始数值里混有单位或符号，先确认 `Numeric Parsing`
3. 去 `Import` 导入数据，让原始文件先进入数据库
4. 如果这次分析依赖 built golden，去 `Golden` 生成或更新 golden 文件
5. 去 `Analyze` 选择分析范围、过滤条件、判定方式，导出xlsx结果
6. 看右侧 `Golden Coverage / Outlier Summary / Log`
7. 确认结果没问题后，用 `Save Database` 或 `Save Database As` 保存

## 4. 界面地图

### 4.1 左侧四个工作模块

| Tab | 用户工作 | 程序工作 |
| --- | --- | --- |
| `Setup` | 选路径、验模板、做模板转换、剔除无效字段 | 记录当前项目上下文，并把 GUI 参数缓存到当前工作区。 |
| `Import` | 导入原始 Excel/CSV，查看当前数据库快照检查是否有误，删误导入数据 | 把原始文件按 template 解析成 measurement，并写进当前数据库的 `temp` 工作区。 |
| `Golden` | 生成 built golden | 从数据库里筛出 reference 数据，按 reference dimension 分组，计算 golden center 与阈值范围。 |
| `Analyze` | 选择范围、过滤条件、判定方式，导出报表 | 对 measurement 做 zscore / golden 判定、基础fail pass数据聚合、node 状态判定，new / existed / recovered判定，导出结果 Excel。 |

### 4.2 右侧三个结果窗口

| Tab | 主要用途 | 什么时候最该看 |
| --- | --- | --- |
| `Golden Coverage` | 看 built golden 覆盖率、哪些点没匹配到 golden | 分析用了 golden，但结果明显偏少、或者怀疑 golden 没覆盖住新数据时。 |
| `Outlier Summary` | 看 fail 汇总、`New / Existed / Recovered`、ratio 统计 | 分析完成后，第一时间判断结果是否符合预期。 |
| `Log` | 看执行日志和报错 | 导入失败、分析失败、模板校验失败、文件被占用时。 |

## 5. Setup：配置环境

### 5.1 模块目的

`Setup` 不是“开始分析”，而是先告诉软件：

- 你当前在哪个数据库项目里工作
- 这次要按哪份 template 解释数据
- 当前准备导入哪份原始文件
- 数值文本是否有该剔除的非数字字符

### 5.2 子流程图

```mermaid
flowchart TD
    A["选择 Database Folder"] --> B["加载当前数据库状态"]
    B --> C["检查是否存在 temp 工作区"]
    C --> D["继续 temp 或回到已保存版本"]
    D --> E["选择 Template File"]
    E --> F["读取 template 结构"]
    F --> G["选择 Input Excel/CSV"]
    G --> H["设置 Numeric Parsing 删除无效字段方案"]
    H --> I["环境配置完成"]
```

### 5.3 Setup GUI 解释

| GUI 字段 | 作用 | Note | 如果要去 template 里改，参考哪里 |
| --- | --- | --- | --- |
| `Database Folder` | 指向当前数据库目录 | 这就是你当前项目的工作目录。 | 不需要去 template 填。 |
| `Template File` | 选择当前 template | 决定软件怎么识别行维度、测试列、group、merge。 | [template_info Sheet](template_help_v2.md#template-info-sheet)、[row_dimensions Sheet](template_help_v2.md#row-dimensions-sheet)、[analysis_groups Sheet](template_help_v2.md#analysis-groups-sheet) |
| `Input Excel/CSV` | 选择这次准备导入的原始文件 | 只是“候选输入文件”；真正写入数据库，要到 `Import` tab 点导入。 | 不需要去 template 填。 |
| `Validate Template` | 校验 template 是否可用 | 先检查结构和字段是否自洽。 | 整份 [template_help_v2.md](template_help_v2.md) |
| `Convert Template: JSON -> XLSX` | 把 JSON 模版转换成 Excel 模版 | 适合把程序结构转回更适合人工维护的表格。 | 不需要去 template 填。 |
| `Convert Template: XLSX -> JSON` | 把 Excel 模版转换成 JSON 模版 | 适合做版本对比、debug。 | 不需要去 template 填。 |
| `Enable Numeric Text Cleanup` | 开启数字文本清洗 | 原始数据有 `1,234mV`、`5.1%` 这种情况时很有用。 | [template_info Sheet / numeric_cleanup](template_help_v2.md#template-info-sheet) |
| `Cleanup Mode` | 决定清洗策略 | 是“尽量全清掉非数字”，还是“只删指定字符”。 | [template_info Sheet / numeric_cleanup](template_help_v2.md#template-info-sheet) |
| `Characters To Remove` | 指定要删的字符列表 | 只有在 `Remove Specified Characters` 模式下才重点使用。 | [template_info Sheet / numeric_cleanup](template_help_v2.md#template-info-sheet) |
| `Save Debug Bundle` | 导出当前问题现场 | 出现异常时，把设置、日志、模板、结果一次性打包出来。 | 不需要去 template 填。 |

### 5.4 `Database Folder` 的工作方式

一个数据库目录通常至少可以理解成三层：

| 目录层级 | 含义 |
| --- | --- |
| 数据库根目录 | 已保存状态 |
| `temp/` | 当前临时工作区 |
| `result/`、`golden/` | 导出结果与 golden 文件 |

如果你打开数据库时看见“继续 temp / 丢弃 temp”的选择，可以把它理解成：

- `Continue Temp Workspace`
  - 继续使用上次还没正式保存的工作现场
- `Discard Temp And Reload Saved Database`
  - 放弃上次未保存改动，回到上次正式保存版本

## 6. Import：导入原始文件到数据库

### 6.1 模块目的

`Import` 的本质不是“把 Excel 放进软件里看看”，而是：

- 读取原始文件
- 按 template 规则拆出 row 维度和测试列
- 把结果写成数据库里的最基础数据点（后续称为 measurement） 记录

### 6.2 子流程图

```mermaid
flowchart TD
    A["读取 Input Excel/CSV"] --> B["读取 template_info 定位行列"]
    B --> C["按 row_dimensions 提取 sample / node / site 等维度"]
    C --> D["按 analysis_groups 识别测试列并按column_header_levels进行整理"]
    D --> E["按 Numeric Parsing 解析数值"]
    E --> F["生成最基础数据 measurement"]
    F --> G{"是否与现有数据冲突"}
    G -- Replace --> H["替换已有记录"]
    G -- Append --> I["追加并顺延 repeat idx"]
    G -- Cancel --> J["终止导入"]
    H --> K["写入 temp 工作区"]
    I --> K
    K --> L["刷新 Current Database Snapshot"]
```

### 6.3 Import GUI 解释

| GUI 区域 / 按钮 | 作用 | Note | template 参考 |
| --- | --- | --- | --- |
| `Import Dataset Into Current Database` | 真的开始导入 | 只有点了这里，`Input Excel/CSV` 才会被解析并写入数据库。 | [template_info Sheet](template_help_v2.md#template-info-sheet)、[row_dimensions Sheet](template_help_v2.md#row-dimensions-sheet)、[analysis_groups Sheet](template_help_v2.md#analysis-groups-sheet) |
| `Current Database Snapshot` | 查看当前数据库里的数据快照 | 这里看到的是整个database，不只是本次导入文件。 | 不需要去 template 填。 |
| `Delete Selected Database Rows` | 删除选中的数据库记录 | 这是实际删除当前工作区数据，不是仅隐藏显示。 | 不需要去 template 填。 |
| 冲突处理 `Replace Existing / Append And Shift Repeat` | 决定遇到同键数据时怎么办 | `Append And Shift Repeat` 会把新增记录顺着已有 repeat 往后排。 | `repeat` 相关逻辑见 [row_dimensions Sheet](template_help_v2.md#row-dimensions-sheet) |

### 6.4 导入成功后，软件内部得到了什么

导入完成后，软件内部最核心的是得到很多条 measurement，他们被存在database目录下的measurements.jsonl文件中。每条 measurement 至少包含：

| 数据内容 | 来自哪里 |
| --- | --- |
| `sample_key` 相关维度 | `row_dimensions` + `sample_dimension_names` |
| `reliability_node` | `row_dimensions` |
| `raw_column` | 原始输入表测试列 |
| `logical group / display info` | `analysis_groups` |
| `numeric value` | 原始单元格经过 numeric parsing 后的数据 |

## 7. Golden：定义单个数据的pass/fail标准

### 7.1 模块目的

- 使用GUI中位数/均值+偏差 或 绝对范围等形式（不包含Modified Zscore Method，该异常分析算法在Analyze tab才引入）
- 或者使用更高优先级的template对每一个test_id对应的测试项目做精细的 pass / fail 标准定义
- 汇总成单个golden.json文件计算单个测试数据（measurement）什么范围算正常？
- 该golden.json文件可以在未来分析复用。

### 7.2 子流程图

```mermaid
flowchart TD
    A["从数据库读取 measurement"] --> B["按 Filters 先筛 reference 数据"]
    B --> C["按 Reference Dims 形成 reference key"]
    C --> D["按 logical group 分组"]
    D --> E{"读取template的analysis_groups规则,单个test_id是否有独立golden定义？"}
    E -- Yes --> F1["使用template的analysis_groups规则"]
    E -- No --> F2["使用GUI全局规则"]
    F1 --> F["计算 Golden Center"]
    F2 --> F
    F --> G["按 Outlier Golden Method 生成允许范围"]
    G --> H["保存 built golden JSON"]
    H --> I["检查 built golden coverage"]
    I --> J["更新 Golden Coverage 与 Log"]
```

### 7.3 Golden GUI 解释

| GUI 字段 | 作用 | Note | template 参考 |
| --- | --- | --- | --- |
| `Golden Name` | 给这份 built golden 起名字 | 方便区分不同版本或不同 reference 方案。 | [template_info Sheet / golden 默认字段](template_help_v2.md#template-info-sheet) |
| `Reference Dims` | 决定 golden key 按哪些维度分组 | 写得越多，golden 越细；写得越少，golden 越粗。 | [template_info Sheet / golden 默认字段](template_help_v2.md#template-info-sheet) |
| `Filters` | 先筛 reference 数据再建 golden | 常用于只拿 `T0`、某个 site、某个温度做 golden。 | [template_info Sheet / golden 默认字段](template_help_v2.md#template-info-sheet) |
| `Outlier Golden Method` | 定义允许范围怎么组合 | 可以只看 `relative`，也可以组合 `sigma`、`absolute`、`overwrite_*`。 | [template_info Sheet / golden 默认字段](template_help_v2.md#template-info-sheet) |
| `Golden Center` | 决定中心值用 `mean` 还是 `median` | `median` 更稳健，`mean` 更接近普通平均。 | [template_info Sheet / golden 默认字段](template_help_v2.md#template-info-sheet) |
| `Relative Limit` | `relative` 规则使用的相对偏差 | 只有方法里真的用到 `relative` 时才生效。 | 同上 |
| `Sigma Multiplier` | `sigma` 规则使用的倍数 | 只有方法里用到 `sigma` 时才生效。 | 同上 |
| `Absolute Lower Bound / Upper Bound` | `absolute` 规则使用的上下界 | 常用于业务上已有固定规格范围，两个参数要同时都填写。 | 同上 |
| `Overwrite Min / Overwrite Max` | 直接改写最终上下界 | 适合在组合规则外再强制封顶或封底，只可以`Overwrite Min / Overwrite Max`中的一个，如果两个都overwirte，就应该选择使用`Absolute Lower Bound / Upper Bound`。 | 同上 |
| `Golden File` | 当前 built golden 输出路径 | `Analyze` 如果用 golden deviation，就会读取这里的 `.json`。如果未来要直接服用，在此处指向之前生成好的json就可以，不用再build。 | 不需要去 template 填。 |

关于 `Golden File`，还有一个容易误解、但非常重要的行为：

- `Analyze` 时不会直接复用上一次 `Build Golden` 留在内存里的对象
- 程序会按当前 `Golden File` 路径，重新从磁盘读取这份 `.json`
- 如果你手动替换了这个文件内容，只要路径还是它，下一次 `Analyze` 就会按新文件重新分析

### 7.4 `Filters` 的输入格式

GUI 的 `Filters` 是多行文本框。推荐写法是：

```text
reliability_node=T0,T1
site_id=A
temp=25C
```

核心规则：

- 一行一个 `key=value`
- 同一个 key 支持逗号多值
- 同一个 key 也可以重复写多行，程序会自动合并
- 同一个 key 内部是“任一值命中”
- 不同 key 之间同时生效

如果你想从 template 里给这些项设默认值，可以看：

- [template_info Sheet / golden 默认字段](template_help_v2.md#template-info-sheet)

## 8. Analyze：真正做判定、聚合和导出

### 8.1 模块目的

`Analyze` 不只是“跑一下结果”，它同时回答三类问题：

- 分析范围是什么
- 判 fail 的规则是什么，并额外增加离群Outlier点检测算法Modified Z score作为golden之外的额外评判标准
- fail 之后怎么往 `sample / node / group / ratio` 层面汇总，从而形成一个`node`+`test group`层面的fail pass结果
- 评判是new / existed / recovered中的那一个

### 8.2 子流程图

```mermaid
flowchart TD
    A["读取分析 scope 内的 measurement"] -->A1["读取 template" ]
    A1 --> B["应用 Include/Exclude Sample Keys"]
    B --> C["应用 Include/Exclude Nodes"]
    C --> D["应用 Include/Exclude Tests"]
    D --> E["按当前 Golden File 路径重新读取 built golden JSON"]
    E --> F["计算 zscore / golden deviation"]
    F --> G["按 Outlier Criteria 做单点fail pass判定"]
    G --> H["按 Merge Order 做 column / row 聚合，判定node+test group层面的fail pass"]
    H --> I["按 template 中的 node_orders 判断 New / Existed / Recovered"]
    I --> J["按照 template 中的 outlier_ratio_stats 统计失效率"]
    J --> K["导出结果含有所有数据的_data.xlsx和异常筛选统计数据的_outlier.xlsx"]
    K --> L["更新 Golden Coverage / Outlier Summary / Log"]
```

### 8.3 Analyze GUI 解释

| GUI 字段 | 作用 | Note | template 参考 |
| --- | --- | --- | --- |
| `Outlier Criteria` | 决定单点 fail 怎么判 | 是只看 zscore、只看 golden，还是两者组合。 | [template_info Sheet / outlier_fail_method](template_help_v2.md#template-info-sheet) |
| `Z Threshold` | zscore 判定阈值 | 只在 criteria 使用 zscore 时生效。 | `template_info` 相关说明仍见 [template_help_v2.md](template_help_v2.md#template-info-sheet) |
| `Merge Order` | 决定 column merge / row merge / node 聚合顺序,形成一个`node`+`test group`层面的fail pass结果 | 当模板比较复杂时，会直接影响最终 fail 如何向上传播。 | [template_info Sheet / outlier_merge_order](template_help_v2.md#template-info-sheet) |
| `Treat Empty/Non-Numeric Test Cells As Fail` | 决定空白或清洗后非数字的测试 cell 是否直接算 fail | 勾选时这类 raw cell 不参与 golden，但会作为 outlier fail 进入后续 merge；默认勾选。 | [template_info Sheet / outlier_treat_empty_cells_as_fail](template_help_v2.md#371-空值--非数字测试-cell-的-fail-设置) |
| `Analysis Scope` | 决定这次分析读取哪些数据 | 是只看当前输入文件、整个数据库，还是勾选的 `Import History`。 | 不需要去 template 填。 |
| `Include Sample Keys` | 只分析指定样品主键 | 样品主键格式受 `sample_dimension_names` 控制。 | [template_info Sheet](template_help_v2.md#template-info-sheet)、[analysis_dimension_filters Sheet](template_help_v2.md#analysis-dimension-filters-sheet) |
| `Exclude Sample Keys` | 排除指定样品主键 | 与上面相同，只是反向过滤。 | 同上 |
| `Include Nodes` | 只分析指定 node | 常用于只看 `T0,T1,T2`。 | [analysis_dimension_filters Sheet](template_help_v2.md#analysis-dimension-filters-sheet)、[node_orders Sheet](template_help_v2.md#node-orders-sheet) |
| `Exclude Nodes` | 排除指定 node | 常用于去掉某些特殊阶段。 | 同上 |
| `Include Tests` | 只分析指定测试列 / 测试属性 | 可以按 `Chain Name`、`Test Type`、`id` 等筛。 | [analysis_column_filters Sheet](template_help_v2.md#analysis-column-filters-sheet)、[column_header_levels Sheet](template_help_v2.md#column-header-levels-sheet)、[analysis_groups Sheet](template_help_v2.md#analysis-groups-sheet) |
| `Exclude Tests` | 排除指定测试列 / 测试属性 | 与上面相同，只是反向过滤。 | 同上 |
| `Import History` | 当 scope 选 `Checked Imports` 时，决定读取哪些历史导入批次 | 这个列表只有在 `Checked Imports` 场景下才真正生效。 | 不需要去 template 填。 |
| `Report Output File` | 结果 Excel 输出路径 | 分析完成后导出的 `.xlsx` 会写到这里。 | 不需要去 template 填。 |

补充理解：

- `Analyze` 使用的 golden 来源不是隐藏缓存
- 它读取的是当前界面 `Golden File` 指向的磁盘文件
- 一次 `Analyze` 过程中，golden coverage、report、summary 这些阶段都会基于这个路径去读取 golden

### 8.4 `Analysis Scope` 三种模式怎么选

| 选项 | 适合什么时候用 | 背后读取范围 |
| --- | --- | --- |
| `Current Input File` | 你只想分析当前这一次导入对应的文件 | 当前输入文件对应的数据 |
| `Entire Database` | 你想看整个项目数据库累积结果 | 当前数据库里的全部 measurement |
| `Checked Imports` | 你只想比较部分导入批次 | 你在 `Import History` 勾选的那些 dataset |

### 8.5 6个过滤输入框

| 字段 | 过滤对象 | 过滤发生在什么阶段 |
| --- | --- | --- |
| `Include / Exclude Sample Keys` | 样品主键 | 分析一开始 |
| `Include / Exclude Nodes` | node 维度 | 分析一开始 |
| `Include / Exclude Tests` | 测试列与测试元信息 | 分析一开始 |

也就是说，这些过滤不是只影响显示，是在计算一开始就做的数据过滤，被过滤的数据不再参与计算，会直接影响后续：

- 哪些点参与 zscore
- 哪些点参与 golden deviation
- 哪些点参与 merge
- 哪些点进入 ratio 统计

### 8.6 `Include Sample Keys` 和 `Include Tests` 的输入格式

#### `Include Sample Keys / Exclude Sample Keys`

推荐写法：

```text
LotA:S001,S002;LotB:S003,S004
```

这类写法依赖 template 里定义的 `sample_dimension_names`。如果你不清楚当前样品主键到底由哪几个维度组成，先看：

- [template_info Sheet / sample_dimension_names](template_help_v2.md#template-info-sheet)

#### `Include Tests / Exclude Tests`

推荐写法：

```text
Chain Name=Chain1,Chain2;Test Type=Voltage;id=link1_voltage
```

可用字段主要来自两部分：

- `column_header_levels`
- `analysis_groups`

如果你不知道 `Chain Name`、`Test Type`、`id`、`column_name` 到底应该填什么值，先看：

- [column_header_levels Sheet](template_help_v2.md#column-header-levels-sheet)
- [analysis_groups Sheet](template_help_v2.md#analysis-groups-sheet)
- [analysis_column_filters Sheet](template_help_v2.md#analysis-column-filters-sheet)

## 9. 右侧结果区

### 9.1 Golden Coverage 模块目的

- 当前分析范围内一共有多少 measurement
- 其中多少条匹配到了 built golden
- 还有多少条没有匹配到
- 没匹配到的典型例子是什么

#### 9.1.1 Golden Coverage 子流程图

```mermaid
flowchart TD
    A["拿当前分析范围里的 measurement"] --> B["按 built golden key 去匹配"]
    B --> C{"是否命中 golden"}
    C -- Yes --> D["记为 matched"]
    C -- No --> E["记为 unmatched"]
    D --> F["统计 matched / total"]
    E --> G["统计 unmatched / unmatched rows / examples"]
    F --> H["更新 Golden Coverage Summary"]
    G --> H
```

### 9.3 Outlier Summary 模块目的

`Outlier Summary` 主要有两层信息：

| 区域 | 看什么 |
| --- | --- |
| 上半部分 summary table | 哪些 sample / node / group 最终 fail，状态是 `New / Existed / Recovered`。 |
| 下半部分 ratio table | `outlier_ratio_stats` 定义的统计项，例如按 node 的新增比例、总失效率等。 |

#### 9.3.1 `New / Existed / Recovered` 的理解方式

| 状态 | 使用者可以怎么理解 |
| --- | --- |
| `New` | 这个 fail 是在当前 node 第一次出现。 |
| `Existed` | 更早任意一个的 node 已经 fail 过，这次只是延续。 |
| `Recovered` | 更早最近一个有数据的 node 是 fail，但当前 node 已经恢复成 pass。 |

这个判定不是凭 GUI 自己猜，而是依赖：

- `node_orders`
- `sample_dimension_names`
- merge 后的最终 node 级结果

相关 template 配置见：

- [node_orders Sheet](template_help_v2.md#node-orders-sheet)
- [template_info Sheet](template_help_v2.md#template-info-sheet)

#### 9.3.2 ratio table 模块目的

`Outlier Summary` 下半部分 ratio table 不是自动固定的一套统计，而是 template 决定的。

- 用于统计每一种lot+node组合下的all、new失效率
- 可以应用多种filter，对某些测试项目单独统计

如果发现的统计项标题、分组方式、筛选条件和预期不一致，应该先去看：

- [outlier_ratio_stats Sheet](template_help_v2.md#outlier-ratio-stats-sheet)

#### 9.3.3 ratio table 子流程图

```mermaid
flowchart TD
    A["拿到当前 Analyze 使用的 measurement 范围"] --> B["获得最基础 measurement zscore / golden fail 判定"]
    B --> D["读取 template outlier_ratio_stats 每一个统计项"]
    D --> E["先按 template outlier_ratio_stats 该统计项的 Filter Type / Filter Value 过滤记录"]
    E --> F["重新按 Merge Order 做 column / row 聚合，判定node+test group层面的fail pass"]
    F --> H["按 Group By Dimension 分组，计算分母样本量"]
    H --> I["按照 new / existed 要求统计分子失效数量"]
    I --> L["计算 ratio 并写入 ratio table"]
```

这条流程里最容易混淆的有三件事：

| 容易混淆的点 | 实际逻辑 |
| --- | --- |
| ratio table 是不是只看原始 fail 点数量 | 不是。它不是简单数原始单点，而是基于重新 merge 之后的最终结果来统计。 |
| `Filter Type / Filter Value` 是什么时候生效 | 它会先过滤记录范围，然后再基于这批过滤后的记录重新跑 merge pipeline。 |
| ratio table 会不会重新做 fail/pass 聚合 | 会。它会对过滤后的记录重新计算最高层级的 `node + test group` fail/pass 结果。 |
| `Group By Dimension` 和 `Numerator` 分别控制什么 | 前者决定“最终按谁出统计行”，后者决定“每组到底数新增失效、全部失效，还是恢复样品”。 |

如果只记一句话，可以记成：

- 先按 ratio 的 filter 缩小记录范围
- 再对这批记录重新跑 merge 和 node 判定
- 最后才按 `Group By Dimension` 和 `Numerator` 统计失效率

这里再补一个实现层面的细节：

- 这里说的“重新跑 merge pipeline”，不是固定死某一个四步顺序
- 实际执行顺序会跟随当前 template 里的 `Merge Order`
- 所以如果 `Merge Order` 改了，ratio table 背后的最终 fail/pass 聚合结果也可能一起变化

## 10. Save：什么时候该存数据库

### 10.1 Save Database 和 Save Database As 的区别

| 操作 | 适合什么时候用 | 背后在做什么 |
| --- | --- | --- |
| `Save Database` | 你想把当前 temp 工作区正式写回当前数据库 | 把 `temp/` 的当前状态合并回数据库根目录，并保存 GUI 设置。 |
| `Save Database As` | 你想把当前工作区另存成一个新项目目录 | 把当前工作区复制到新目录，并一起带上 GUI 设置。 |

### 10.2 子流程图

```mermaid
flowchart TD
    A["当前操作都先写在 temp 工作区"] --> B{"用户是否执行 Save"}
    B -- Save Database --> C["把 temp 合并回数据库根目录"]
    B -- Save Database As --> D["把当前工作区复制到新目录"]
    C --> E["保存 GUI 设置"]
    D --> E
```

## 11. 常见误区

| 误区 | 实际情况 |
| --- | --- |
| 只要在 `Setup` 里选了 `Input Excel/CSV` 就算导入了 | 不是。真正写入数据库，要到 `Import` tab 点击导入GUI。 |
| `Current Database Snapshot` 只是显示表，不影响真实数据 | 不是。删行会实际删除当前工作区里的数据库记录。 |
| `Include / Exclude` 只是影响最终报表显示 | 不是。它们会在分析一开始就改变参与计算的数据范围。但是原始数据还是保留在数据库中。 |
| `Golden Coverage` 只是个参考信息 | 不是。很多“为什么结果太少”的问题，本质上都是 golden 没覆盖住。 |
| `Outlier Summary` 里的状态只看前一个 node | 不是。程序会按 `node_orders` 往前回溯。 |
