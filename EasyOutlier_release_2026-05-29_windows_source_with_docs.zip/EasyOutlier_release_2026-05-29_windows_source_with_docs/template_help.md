# Template Help

[toc]



这份文档说明当前程序支持的 template 格式、每个字段的含义、可选值、Excel 模板各个 sheet 的写法，以及常见校验规则。

当前 template 支持两种文件格式：

- `json`
- `xlsx`

程序内部都会先把它们解析成同一套 `TemplateConfig`。  
对应实现主要在：

- [template.py](src/excel_data_analysis/template.py)
- [models.py](src/excel_data_analysis/models.py)
- [io.py](src/excel_data_analysis/io.py)

示例文件：

- [chip_reliability_template.json](examples/chip_reliability_template.json)
- [chip_reliability_template.xlsx](examples/chip_reliability_template.xlsx)

补充说明：

- GUI 里 `Analyze` 页的 `Sample Keys / Exclude Sample Keys / Nodes / Exclude Nodes / Tests / Exclude Tests` 都属于“运行时分析过滤”
- 它们不是 `outlier_ratio_stats` 那种统计阶段过滤，而是在分析开始前就直接过滤输入 measurement
- 这些默认值现在也可以写进 template：
  - `report.analysis_dimension_filters`
  - `report.analysis_column_filters`
- `analysis_dimension_filters` 目前支持的字段：
  - `sample_key`
  - `reliability_node`
- `analysis_column_filters` 可用字段来自：
  - `column_header_levels`
  - `analysis_groups` 里的 `id / display_name / raw_column(column_name) / unit`
- `analysis_column_filters` 的输入格式是：
  - `字段=值1,值2;字段2=值3`
  - 例如：`Chain Name=Chain1,Chain2;Test Type=TestType1,TestType2`
- 当前示例模板里的默认分析过滤示例：
  - 标准模板：`reliability_node = T0,T1,T2`，`Chain Name = Link1,Link2,Link4`，`Test Type = Resistance,Current,Voltage,Capacitance`
  - `chip_reliability_template_test_v2`：`sample_key = LOT1:S1,S2,S3,S4,3; LOT2:3; LOT3:DUM1...DUM10`，`reliability_node = Node1,Node2`，`Chain Name = Chain1,Chain2`，`Test Type = TestType1,TestType2`

## 1. 顶层结构

JSON template 的顶层字段如下：

```json
{
  "name": "chip_reliability_template",
  "test_data_header_row": 0,
  "row_header_row": 4,
  "unit_row": 3,
  "test_data_start_row": 5,
  "numeric_cleanup": {
    "enabled": false,
    "mode": "all_non_numeric",
    "characters": []
  },
  "row_dimensions": [],
  "analysis_groups": [],
  "report": {}
}
```

各字段说明：

- `name`
  - 类型：`string`
  - 必填
  - 模板名称，仅作为标识使用

- `test_data_header_row`
  - 类型：`int`
  - 必填，默认示例一般写 `0`
  - 测试列列名所在行，零基准
  - 例如 `R_Link1_1V_1`、`V_Link1_1p8V` 这类测试项目列名

- `row_header_row`
  - 类型：`int`
  - 必填，零基准
  - 行维度列名所在行
  - 例如 `recordName`、`Lot`、`Site`

- `test_data_start_column`
  - 类型：`int`
  - 可选
  - 测试数据区域从哪一列开始，零基准
  - 从这列开始，程序会优先使用 `test_data_header_row` 的表头，不再让 `row_header_row` 覆盖测试区列名

- `unit_row`
  - 类型：`int`
  - 可选
  - 单位行所在位置，零基准

- `test_data_start_row`
  - 类型：`int`
  - 必填
  - 测试数据区域第一行数据所在行，零基准
  - 必须显式填写，程序不会自动推断

- `numeric_cleanup`
  - 类型：`object`
  - 可选
  - 控制数字文本在转成 `float` 之前是否先做清洗
  - 适合原始单元格里带单位、逗号、百分号等情况
  - 支持两种模式：
    - `all_non_numeric`
    - `specified_chars`
  - 合法科学记数法里的 `E/e` 会被保留
  - 例如 `10E-3`、`10E-3mA`、`-1.25e-3A` 都可以正确解析成数字

- `row_dimensions`
  - 类型：`list`
  - 必填
  - 描述一行数据的业务维度怎么提取

- `analysis_groups`
  - 类型：`list`
  - 必填
  - 描述横向测试列如何分组与分析

- `report`
  - 类型：`object`
  - 可选，但真实芯片报表一般都会配置
  - 控制 golden、threshold、node 顺序、outlier 判定规则

## 2. `row_dimensions`

`row_dimensions` 用来定义每一行的维度信息，例如：

- `sample_id`
- `reliability_node`
- `repeat_id`
- `site_id`
- `temp`

当前结构不是旧版的 `columns + split_position`，而是：

```json
{
  "name": "sample_id",
  "display_name": "SampleID",
  "optional": false,
  "default_value": null,
  "sources": [
    {
      "column": "recordName",
      "split_delimiters": ["_", "｜"],
      "default_split_position": 0,
      "split_position_by_column": "Site",
      "split_position_map": {
        "1": 0,
        "2": 1,
        "3": 2
      },
      "skip_empty_parts": false
    }
  ]
}
```

### 2.1 `row_dimension` 字段说明

- `name`
  - 类型：`string`
  - 必填
  - 维度内部名称
  - 后续会作为 `dimensions[name]` 的 key 使用
  - 不能重复

- `display_name`
  - 类型：`string`
  - 可选
  - 报表里展示的标题名称
  - 如果省略，界面/报表会退回使用 `name`

- `optional`
  - 类型：`bool`
  - 可选，默认 `false`
  - 如果该维度提取不到值：
    - `true`：允许缺失
    - `false`：整行数据会被视为无效并跳过

- `default_value`
  - 类型：`string`
  - 可选
  - 当所有 source 都提取不到值时的回填值
  - 常见用法：`repeat_id` 默认写 `"1"`
  - 对 `repeat_id` 来说，如果最终提取结果出现缺失、非数字、重复或不连续，程序会在同一组样品属性内部按行顺序统一重编号为连续的 `1..N`

- `sources`
  - 类型：`list`
  - 必填
  - 一个维度可以有多个 source
  - 程序会按 source 顺序提取内容
  - 多个 source 的结果会用 `|` 拼接成最终维度值

### 2.2 `row_dimension.sources[]` 字段说明

每个 source 都有自己的提取规则：

- `column`
  - 类型：`string`
  - 必填
  - 从输入表的哪一列取原始文本

- `split_delimiters`
  - 类型：`list[string]`
  - 可选
  - 一个 source 可以配置多个 delimiter
  - 例如：`["_", "｜"]`
  - 程序会按“任一 delimiter 都可切分”的规则拆开文本
  - 这是普通文本切分，不是正则表达式

- `default_split_position`
  - 类型：`int`
  - 可选
  - 表示 split 之后取第几个片段，零基准
  - 例如：
    - `recordName = "S001_T1_2"`
    - `split_delimiters = ["_"]`
    - `default_split_position = 1`
    - 结果就是 `"T1"`
  - 如果配置了 `default_split_position`，必须同时配置 `split_delimiters`
  - 旧字段名 `split_position` 仍兼容读取，但新模板建议统一写 `default_split_position`

- `split_position_by_column`
  - 类型：`string`
  - 可选
  - 表示要看输入表里的哪一列，再决定当前 source 该取哪个 split position
  - 常见例子：`Site`
  - 如果配置了它，通常也要同时配置 `split_position_map`

- `split_position_map`
  - 类型：`dict[string, int]`
  - 可选
  - 表示“另一列的值 -> 当前 source 应取的 split position”
  - 不局限于 2 组，可以有 3 组、4 组或更多
  - 例如：
    - `{"1": 0, "2": 1, "3": 2}`
  - 程序会先读取 `split_position_by_column` 指向的那一列
  - 如果这个值能在 `split_position_map` 里匹配到，就优先使用映射得到的 split position
  - 如果匹配不到，就回退到普通的 `default_split_position`
  - 如果连普通 `default_split_position` 也没配，就直接取整格文本

- `skip_empty_parts`
  - 类型：`bool`
  - 可选，默认 `false`
  - 对连续分隔符导致的空字符串片段是否忽略
  - 例如 `A__B` 按 `_` 切分时：
    - `false`：结果是 `["A", "", "B"]`
    - `true`：结果是 `["A", "B"]`

### 2.3 `row_dimensions` 的实际行为

程序提取维度时的规则：

1. 按 `row_dimensions` 顺序处理每个维度
2. 对当前维度，按 `sources` 顺序依次提取
3. 每个 source：
   - 如果配了 `split_position_by_column + split_position_map`：
     - 先读取另一列的值
     - 如果命中映射，优先用映射得到的 split position
     - 如果没命中，再回退到普通 `default_split_position`
   - 如果最终没有可用的 split position：直接取整格文本
   - 如果最终有 split position：先按 `split_delimiters` 切分，再取指定位置
4. 把所有成功提取的 source 结果用 `|` 拼起来
5. 如果一个维度所有 source 都没拿到值：
   - 有 `default_value` 就用默认值
   - 没默认值但 `optional=true` 就跳过该维度
   - 否则整行数据无效

### 2.4 `row_dimensions` 的典型例子

#### 例 1：从一个列里拆出 sample/node/repeat

```json
{
  "name": "sample_id",
  "display_name": "SampleID",
  "sources": [
    {
      "column": "recordName",
      "split_delimiters": ["_", "｜"],
      "default_split_position": 0
    }
  ]
}
```

#### 例 2：一个维度从多个原始列重组

```json
{
  "name": "location",
  "display_name": "Location",
  "sources": [
    {
      "column": "Line"
    },
    {
      "column": "Site"
    }
  ]
}
```

#### 例 3：按另一列的值动态决定 split position

```json
{
  "name": "sample_id",
  "display_name": "SampleID",
  "sources": [
    {
      "column": "recordName",
      "split_delimiters": ["_"],
      "default_split_position": 0,
      "split_position_by_column": "Site",
      "split_position_map": {
        "1": 0,
        "2": 1,
        "3": 2
      }
    }
  ]
}
```

例如：

- `recordName = "S001_T0_3"`
- `Site = "2"`

那么程序会优先命中：

- `split_position_map["2"] = 1`

最终取到的是第 `1` 段，也就是 `"T0"`。  
如果 `Site = "9"`，但映射表里没有 `9`，就会回退到普通的 `default_split_position = 0`，结果是 `"S001"`。

如果 `Line=A`，`Site=03`，最终维度值会是：

```text
A|03
```

#### 例 3：多个 source 各自 split 后重组

```json
{
  "name": "device_key",
  "display_name": "DeviceKey",
  "sources": [
    {
      "column": "recordA",
      "split_delimiters": ["_", "｜"],
      "split_position": 0
    },
    {
      "column": "recordB",
      "split_delimiters": ["-", ":"],
      "split_position": 1
    }
  ]
}
```

## 3. `analysis_groups`

`analysis_groups` 用来定义横向测试列如何归类。

结构示例：

```json
{
  "id": "link1_resistance",
  "display_name": "Link1 Resistance",
  "columns": [
    {
      "name": "R_Link1_1V_1",
      "header_values": ["Link1", "Resistance", "1"]
    },
    {
      "name": "R_Link1__1V_2",
      "header_values": ["Link1", "Resistance", "2"]
    },
    {
      "name": "R_Link1_1V_3",
      "header_values": ["Link1", "Resistance", "3"]
    }
  ],
  "analysis_mode": "pooled_columns",
  "unit": "Ohm"
}
```

### 3.1 字段说明

- `id`
  - 类型：`string`
  - 必填
  - 这是该组列的分组标识
  - 如果这些列应该一起参与 golden / z-score 相关计算，就使用同一个 `id`
  - 如果这些列不应该一起参与 golden / z-score 相关计算，就不要重复使用同一个 `id`
  - 当 `analysis_mode = pooled_columns` 时，同一个 `id` 下的列会一起参与 golden 和 z-score 计算
  - 当 `analysis_mode = per_column` 时，同一个 `id` 下的列不会一起计算 golden 和 z-score，但仍然共享这一组的 golden 手动规则配置

- `display_name`
  - 类型：`string`
  - 可选
  - 展示名称
  - 如果省略，默认使用 `id`

- `columns`
  - 类型：`list[object]`
  - 必填
  - 每一项都要显式定义：
    - `name`
    - `header_values`
  - `header_values` 的个数必须和 `column_header_levels` 完全一致
  - 同一个 raw column 不能出现在多个 group 里

- `analysis_mode`
  - 类型：`string`
  - 必填
  - 允许值：
    - `pooled_columns`
    - `per_column`

- `column_header_levels`
  - 类型：`list[string]`
  - 必填
  - 定义结果横向表头的层级名称和优先级
  - 例如：
    - `["Chain Name", "Test Type", "Repeat Index"]`
  - 程序不会再从原始 `column_name` 猜任何层级值

- `unit`
  - 类型：`string`
  - 可选
  - 该组默认单位
  - 结果报表只使用 template 里定义的单位
  - 可以留空；留空就按空值保留，不再从输入表猜单位

- `outlier_golden_method`
  - 类型：`string`
  - 可选
  - 该 analysis group 自己的 built golden 判定方法
  - 支持任意合法表达式，只要由：
    - `relative`
    - `sigma`
    - `absolute`
    - `and`
    - `or`
    - 括号
    组成
  - 例如：
    - `relative and sigma`
    - `relative or absolute`
    - `relative or (sigma and absolute)`
    - `relative or ((sigma and absolute) or (absolute and relative))`
  - 如果这里显式定义，就不会再读取 GUI / `golden_reference_defaults` 的全局默认

- `golden_relative_limit`
  - 类型：`number`
  - 可选
  - 当 `outlier_golden_method` 用到 `relative` 时必须显式定义

- `golden_sigma_multiplier`
  - 类型：`number`
  - 可选
  - 当 `outlier_golden_method` 用到 `sigma` 时必须显式定义

- `golden_absolute_lower_bound` / `golden_absolute_upper_bound`
  - 类型：`number`
  - 可选
  - 当 `outlier_golden_method` 用到 `absolute` 时必须显式定义

- `golden_empty_range_fallback_to_absolute`
  - 类型：`bool`
  - 可选，默认 `false`
  - 当 golden rule 通过 `and` 或覆盖边界计算后得到空 allowed range 时，是否 fallback 到 absolute 上下界
  - 如果设为 `true`，必须配置 absolute lower / upper bound
  - 触发 fallback 时，GUI 会警告用户，结果 Excel 的 `Outlier Summary` 第一页也会提示哪些 metric 按 AND/交集标准没有交集，已经 fallback 到 absolute，并提醒检查是否所有样品均失效

### 3.2 `analysis_mode` 说明

- `pooled_columns`
  - 多列被视为同一组一起计算
  - 同一个 `id` 下的列会合并参与 golden 和 z-score
  - 常见于同条件重复测量

- `per_column`
  - 每个 raw column 各自单独计算
  - 即使同一个 `id` 下有多列，它们也不会在 golden 和 z-score 里合并
  - 常见于同链路下不同电压/电流/模式的独立项目

### 3.3 `analysis_groups` 的 Excel 写法

Excel 模板中，`analysis_groups` 使用长表模式：

- 一行代表一个 `column_name`
- 所有 raw column 都集中在同一列，方便查漏

表头如下：

- `id`
- `Display Name`
- `Analysis Mode`
- `Unit`
- `Outlier Golden Method`
- `Golden Relative Limit`
- `Golden Sigma Multiplier`
- `Golden Lower Bound`
- `Golden Upper Bound`
- `Column Order`
- `Column Name`
- 再加上 `column_header_levels` 里定义的每一层列名

例子：

```text
link1_resistance | Link1 Resistance | pooled_columns | Ohm | relative or (sigma and absolute) | 0.20 | 3 | 80 | 120 | 1 | R_Link1_1V_1 | Link1 | Resistance | 1
link1_resistance | Link1 Resistance | pooled_columns | Ohm | relative or (sigma and absolute) | 0.20 | 3 | 80 | 120 | 2 | R_Link1__1V_2 | Link1 | Resistance | 2
link1_resistance | Link1 Resistance | pooled_columns | Ohm | relative or (sigma and absolute) | 0.20 | 3 | 80 | 120 | 3 | R_Link1_1V_3 | Link1 | Resistance | 3
```

`column_order` 用来保留原来的列顺序。

同一个 `id` 的多行里，下面这些字段属于“共享字段”：

- `Display Name`
- `Analysis Mode`
- `Unit`
- `Outlier Golden Method`
- `Golden Relative Limit`
- `Golden Sigma Multiplier`
- `Golden Lower Bound`
- `Golden Upper Bound`

这些字段的设计意图是：同一个 `id` 内应该保持一致。

如果 Excel 模板里同一个 `id` 的多行给了不同的共享字段值：

- 默认严格模式下，`validate-template` 和 `build-golden` 会报错，要求先修正模板
- 如果你明确选择 `first_non_empty` 模式，程序会保留当前兼容行为：
  - 每个共享字段都取该 `id` 下“首个非空值”
  - 后面行里冲突的值会被忽略

例如：

```text
group_voltage | Voltage Group | per_column | V | relative | 0.10 |   |   |   | 1 | V_A | ChainA | Voltage
group_voltage | Voltage Group | per_column | V | relative | 0.20 |   |   |   | 2 | V_B | ChainB | Voltage
```

如果强制使用 `first_non_empty`，最终整个 `group_voltage` 会使用 `Golden Relative Limit = 0.10`。

## 4. `report`

`report` 主要控制真实芯片多 sheet 报表的行为。

结构示例：

```json
"report": {
  "zscore_thresholds": {
    "default": 3.5
  },
  "outlier_ratio_stats": [],
  "node_order": ["T0", "T1", "T2"],
  "outlier_fail_method": "golden_deviation",
  "outlier_merged_test_fail_rule": "any_fail",
  "outlier_test_group_fail_rule": "any_fail",
  "outlier_merged_sample_fail_rule": "any_fail",
  "outlier_node_fail_rule": "any_fail",
  "outlier_row_merge_max_dimension": "repeat_id",
  "outlier_test_merge_max_level": "Chain Name",
  "outlier_merge_order": "column merge -> column group -> row merge -> row node"
}
```

### 4.1 `zscore_thresholds`

- 类型：`object` 或 `number`
- 可选

如果直接写数字：

```json
"zscore_thresholds": 3.5
```

等价于：

```json
"zscore_thresholds": {
  "default": 3.5
}
```

完整写法：

```json
"zscore_thresholds": {
  "default": 3.5,
  "overrides": {
    "link1_resistance": 4.0,
    "I_Link1_1p8V": 2.5
  }
}
```

override key 的匹配优先顺序是：

1. `group.id::raw_column`
2. `raw_column`
3. `group_id`
4. `chain_name`

### 4.2 `node_order` 与 `node_orders`

这两个字段用来描述 node 的先后顺序。

- `node_order`
  - 类型：`list[string]`
  - 旧的单条顺序写法

- `node_orders`
  - 类型：`list[list[string]]`
  - 新的多条顺序写法
  - 更推荐使用

单条例子：

```json
"node_order": ["T0", "T1", "T2"]
```

多条例子：

```json
"node_orders": [
  ["T0", "T1", "T2"],
  ["T0", "T1", "T3", "T4"]
]
```

程序会按每个 sample 实际出现的 node 集合，自动匹配最合适的顺序，用于：

- 报表行排序
- outlier 发生先后判断
- summary 里“从哪个 node 开始失效”的展示

`Outlier Summary` 中 `New / Existed / Recovered` 的判断规则：

- 判定粒度是：
  - 同一个 `sample + 当前最终列组`
  - 当前最终列组通常就是 `chain`
- 程序会先按当前 node 所属 sequence 往前找前驱节点
- 如果紧邻上一项 node 不存在于当前 sample，就继续往前找更早、实际存在数据的 node

- `New`
  - 当前节点最终判定为 `fail`
  - 且所有更早的已存在前驱节点里，这一条 `chain` 都没有 fail 过

- `Existed`
  - 当前节点最终判定为 `fail`
  - 且只要任意一个更早的已存在前驱节点里，这一条 `chain` 已经 fail 过，就判 `Existed`
  - 也就是说，`Existed` 不是只看最近一个前驱，而是看所有更早、实际有数据的前驱节点

- `Recovered`
  - 当前节点最终判定为 `pass`
  - 且最近一个有数据的前驱节点，这一条 `chain` 是 `fail`
  - 也就是说，`Recovered` 只看最近一个有数据的前驱节点，不会因为更早节点 fail 但最近前驱 pass 而继续判 `Recovered`

#### node 顺序一致性校验

多条 `node_orders` 允许存在，但公共节点之间的相对顺序不能冲突。

允许：

```json
[
  ["T0", "T1", "T2"],
  ["T0", "T1", "T3", "T4"]
]
```

不允许：

```json
[
  ["T0", "T1", "T2"],
  ["T2", "T1", "T0"]
]
```

因为第二条把公共节点顺序反过来了。

### 4.5 `outlier_ratio_stats`

- 类型：`list[object]`
- 可选
- 用于在 `Outlier Summary` 里增加“outlier 占比”统计表

每一项都表示一类统计规则。程序会在当前分析范围内：

- 先按当前 ratio 的 filter 条件筛底层数据
- 再执行一次完整的 4 次 merge，得到固定的最终判定单元
- 最后按 `group_by_dimension` 或 `group_by_dimensions` 对这批最终判定单元分组统计

当前结构如下：

```json
{
  "id": "new_ratio_by_node_all",
  "display_name": "New Outlier Ratio By Node",
  "group_by_dimension": "reliability_node",
  "numerator": "new_outlier_samples",
  "group_ids": [],
  "group_display_names": [],
  "test_types": [],
  "chain_names": [],
  "column_names": [],
  "units": [],
  "chains": [],
  "raw_columns": []
}
```

字段说明：

- `id`
  - 类型：`string`
  - 必填
  - 该统计项的唯一标识

- `display_name`
  - 类型：`string`
  - 可选
  - 在 Excel / GUI 里显示的名称

- `group_by_dimension`
  - 类型：`string`
  - 与 `group_by_dimensions` 二选一
  - 用于单维分组
  - 必须是一个已定义的 `row_dimensions.name` 或 `column_header_levels.name`
  - 最常用的是 `reliability_node`
  - 也可以是 `lot_id`、`product_id` 等 `reliability_node` 及更高优先级的行维度
  - 也可以是 `Chain Name` 这类 column header level，用于每个 chain 单独统计
  - 不能使用 `site_id`、`repeat_id` 这类会在 merge 中被消化掉的更低层级维度；这类限制应该放到 filter

- `group_by_dimensions`
  - 类型：`list[string]`
  - 与 `group_by_dimension` 二选一
  - 用于多维联合分组
  - 每个值都必须是已定义的 `row_dimensions.name` 或 `column_header_levels.name`
  - row 维度只能使用 `reliability_node` 及更高优先级的 row 维度；column header level 可以直接使用，例如 `Chain Name`
  - 例如：`["reliability_node", "lot_id"]` 或 `["Chain Name"]`
  - 结果里会显示成：
    - `Group By Dimension = reliability_node + lot_id`
    - `Group Value = T1 | LotA`

- `numerator`
  - 类型：`string`
  - 必填
  - 允许值：
    - `new_outlier_samples`
    - `recovered_samples`
    - `outlier_samples`

含义：

- `new_outlier_samples`
  - 只统计该组里状态为 `New` 的 outlier sample 数
  - 适合看“相对于前驱节点新增失效”的比例

- `recovered_samples`
  - 只统计该组里状态为 `Recovered` 的 sample 数
  - 适合看“相对于最近一个有数据前驱节点，已经从 fail 恢复为 pass”的比例

- `outlier_samples`
  - 统计该组里所有 outlier sample 数，不区分 `New / Existed`
  - 适合看该组当前总 outlier 覆盖率

- `group_ids`
  - 类型：`list[string]`
  - 可选
  - 按 `analysis_groups[*].id` 过滤
  - 例如：`["link4_voltage"]`

- `group_display_names`
  - 类型：`list[string]`
  - 可选
  - 按 `analysis_groups[*].display_name` 过滤
  - 例如：`["Link4 Voltage"]`

- `test_types`
  - 类型：`list[string]`
  - 可选
  - 按 `analysis_groups[*].test_type` 过滤
  - 例如：`["Voltage"]` 或 `["V"]`

- `chain_names`
  - 类型：`list[string]`
  - 可选
  - 按结果表头里的 `Chain Name` 过滤
  - 例如：`["Link4"]`

- `column_names`
  - 类型：`list[string]`
  - 可选
  - 按原始测试列名过滤
  - 例如：`["V_Link1_1p8V"]`

- `units`
  - 类型：`list[string]`
  - 可选
  - 按测试项单位过滤
  - 例如：`["V"]`

- `chains`
  - 类型：`list[string]`
  - 可选
  - 旧写法，等价于 `chain_names`
  - 仍然兼容，但新模板更推荐写 `chain_names`

- `raw_columns`
  - 类型：`list[string]`
  - 可选
  - 旧写法，等价于 `column_names`
  - 仍然兼容，但新模板更推荐写 `column_names`

执行顺序：

- 先按当前 ratio 配置的 filters 筛选底层 leaf 数据
- 再对这批筛选后的数据执行一次完整的 4 次 merge
- 最后才按 `group_by_dimension(s)` 对最终判定单元做分桶统计

这意味着：

- 同一个 filter 方案只需要 merge 一次
- `group_by_dimension(s)` 只负责“怎么统计”，不会反过来改变“最终判定单元”的定义
- 如果 `group_by_dimension(s)` 使用 column header level 且跳过了上层 level，Excel Summary 会用中文提示：统计结果是把当前 filter 下已经 merged 的 outlier 映射到当前维度上统计；如果需要重新判断，请使用 filter 改变统计数据池
- 如果想分别看不同 `test_type`，推荐写多条 ratio 规则并分别配置不同 filter，例如一条 `test_type=Voltage`，一条 `test_type=Current`

过滤规则：

- `group_ids`、`group_display_names`、`test_types`、`chain_names`、`column_names`、`units` 可以同时配置
- 如果同时配置多个过滤器，程序要求该 outlier 事件至少命中每一类过滤器中的一项
- 如果都不配置，表示“所有 outlier 都参与统计”

典型例子：

#### 例 1：统计每个 node 的新增 outlier 比例

```json
"outlier_ratio_stats": [
  {
    "id": "new_ratio_by_node_all",
    "display_name": "New Outlier Ratio By Node",
    "group_by_dimension": "reliability_node",
    "numerator": "new_outlier_samples"
  }
]
```

含义：

- 以 `reliability_node` 分组
- 分母：该 node 下 sample 总数
- 分子：该 node 下 `status = New` 的 outlier sample 数

#### 例 2：只统计 Link4 的总 outlier 比例

```json
"outlier_ratio_stats": [
  {
    "id": "total_ratio_by_node_link4",
    "display_name": "Total Outlier Ratio By Node (Link4)",
    "group_by_dimension": "reliability_node",
    "numerator": "outlier_samples",
    "chain_names": ["Link4"]
  }
]
```

#### 例 3：只统计某个测试列的总 outlier 比例

```json
"outlier_ratio_stats": [
  {
    "id": "total_ratio_by_node_v_link1_1p8v",
    "display_name": "Total Outlier Ratio By Node (V_Link1_1p8V)",
    "group_by_dimension": "reliability_node",
    "numerator": "outlier_samples",
    "column_names": ["V_Link1_1p8V"]
  }
]
```

#### 例 4：按 ID、Display Name、Test Type、Chain Name、Column Name、Unit 组合过滤

```json
"outlier_ratio_stats": [
  {
    "id": "link4_voltage_v_ratio",
    "display_name": "Link4 Voltage Ratio",
    "group_by_dimension": "reliability_node",
    "numerator": "outlier_samples",
    "group_ids": ["link4_voltage"],
    "group_display_names": ["Link4 Voltage"],
    "test_types": ["V"],
    "chain_names": ["Link4"],
    "column_names": ["V_Link4_1A"],
    "units": ["V"]
  }
]
```

#### 例 5：按 `reliability_node + lot_id` 联合分组

```json
"outlier_ratio_stats": [
  {
    "id": "new_ratio_by_node_and_lot",
    "display_name": "New Outlier Ratio By Node And Lot",
    "group_by_dimensions": ["reliability_node", "lot_id"],
    "numerator": "new_outlier_samples"
  }
]
```

含义：

- 先按 `reliability_node` 和 `lot_id` 的组合分组
- 例如 `T1 + LotA` 和 `T1 + LotB` 会被视为两个不同统计组
- 这是一种联合分组，等价于你说的 `reliability_node and lot_id`

### 4.6 `sample_dimension_names`

- 类型：`list[string]`
- 当定义了 `row_dimensions` 时必填

含义：

- 明确指定哪些 `row_dimensions.name` 要一起组成“样品主键”
- `Outlier Summary`
- outlier ratio 的样品去重
- sample 级 node order 匹配
  这些地方都会使用它

规则：

- 每个值都必须精确匹配某个 `row_dimensions[*].name`
- 程序不会再隐式取第一个 row dimension
- 如果没写清楚，模板校验会直接报错

示例：

```json
"report": {
  "sample_dimension_names": ["lot_id", "sample_id"]
}
```

### 4.7 `outlier_fail_method`

- 类型：`string`
- 可选
- 允许值：
  - `modified_z_score`
  - `golden_deviation`
  - `zscore_and_golden`
  - `zscore_or_golden`

含义：

- `modified_z_score`
  - `outliers` / `summary` 里以 zscore 判 fail

- `golden_deviation`
  - `outliers` / `summary` 里以 golden 偏差判 fail

- `zscore_and_golden`
  - zscore 和 golden 偏差都超 threshold 才判 fail

- `zscore_or_golden`
  - zscore 和 golden 偏差任意一个超 threshold 就判 fail

注意：

- GUI 中如果 Analysis Mode 和这个值不一致，程序会提示是否同步刷新 template

### 4.8 `outlier_merged_test_fail_rule`

- 类型：`string`
- 可选
- 允许值：
  - `any_fail`
  - `all_fail`

含义：

- `any_fail`
  - 对 `column merge` 阶段同一个 merged test pool 里的叶子测试列，只要任意一个 fail，就认为这个 merged test pool fail

- `all_fail`
  - 对 `column merge` 阶段同一个 merged test pool 里的叶子测试列，只有全部 fail，才认为这个 merged test pool fail

### 4.9 `outlier_test_group_fail_rule`

- 类型：`string`
- 可选
- 允许值：
  - `any_fail`
  - `all_fail`

含义：

- `column merge` 完成后，程序还会继续往列方向更高层级聚合，直到顶层 test group
- `outlier_test_group_fail_rule` 就是定义这个 `column group` 阶段如何把多个子组再汇总成更高层级结果

- `any_fail`
  - 只要任意一个子组 fail，就认为更高层 test group fail

- `all_fail`
  - 必须所有子组都 fail，才认为更高层 test group fail

### 4.10 `outlier_merged_sample_fail_rule`

- 类型：`string`
- 可选
- 允许值：
  - `any_fail`
  - `all_fail`

含义：

- 当同一个“合并后的 row pool”下存在多条原始数据行时，如何判断这个 row pool 是否算 fail

更直白地说：

- 先固定高优先级 row 维度
- 再看被 merge 进同一个 row pool 的那些 raw rows
- 这个规则就是在问：
  - “这个 row pool 里只要有一条 fail 就算 fail，还是必须全部都 fail 才算 fail？”

- `any_fail`
  - 只要该 row pool 下任意一条原始数据行 fail，就认为该 row pool fail

- `all_fail`
  - 必须该 row pool 下所有原始数据行都 fail，才认为该 row pool fail

### 4.11 `outlier_node_fail_rule`

- 类型：`string`
- 可选
- 允许值：
  - `any_fail`
  - `all_fail`

含义：

- 当同一个 `sample + reliability_node` 下存在多个 merged row pool 时，如何把这些 merged row pool 再聚合成 node-level fail

更直白地说：

- 先按 `outlier_merged_sample_fail_rule` 算出每个 row pool 的结果
- 再看同一个 `sample + reliability_node` 下这些 row pool
- 这个规则就是在问：
  - “这个 node 下只要有一个 pool fail 就算 node fail，还是必须所有 pool 都 fail 才算 node fail？”

- `any_fail`
  - 只要该 node 下任意一个 merged row pool fail，就认为该 node fail

- `all_fail`
  - 必须该 node 下所有 merged row pool 都 fail，才认为该 node fail

### 4.12 `outlier_row_merge_max_dimension`

- 类型：`string`
- 必填

含义：

- row 维度会按 `priority` 排序
- 这个字段定义“从哪一个 `row_dimensions.name` 开始往下 merge 成 row pool”
- 例如：
  - `sample_id`
  - `reliability_node`

例如 row 优先级是：

1. `lot`
2. `sample_id`
3. `reliability_node`
4. `site_id`
5. `repeat_id`

那么如果写：

- `outlier_row_merge_max_dimension = site_id`

就表示：

- `lot`、`sample_id`、`reliability_node` 保留在 pool 外
- `site_id`、`repeat_id` 一起进入 row pool
- 程序会先在同一个 `lot + sample_id + reliability_node` 下，把不同 `site_id + repeat_id` 的 raw rows 聚合成一个或多个 merged row pool
- 再按 `outlier_node_fail_rule` 把同一个 node 下多个 merged row pool 聚合成 node-level fail

可以把它理解成：

- 这个字段决定“从哪一层开始，下面的 row 维度一起参加 any/all 判断”
- 写得越靠后，池子越小
- 写得越靠前，池子越大

注意：

- `outlier_row_merge_max_dimension` 必须低于 `reliability_node`
- 不能和 `reliability_node` 是同一层，也不能比它更高

### 4.12 `outlier_test_merge_max_level`

- 类型：`string`
- 必填

含义：

- column 层级会按 `priority` 排序
- 这个字段定义“从哪一个 `column_header_levels.name` 开始往下合并”
- 例如：
  - `Chain Name`
  - `Test Type`
  - `Repeat Index`

例如 column 层级是：

1. `Chain Name`
2. `Test Type`
3. `Repeat Index`

那么如果写：

- `outlier_test_merge_max_level = Test Type`

就表示：

- 更高优先级的 `Chain Name` 保留在 pool 外
- `Test Type` 和 `Repeat Index` 一起进入 test pool

### 4.13 `outlier_treat_empty_cells_as_fail`

- 类型：`boolean`
- 可选
- 默认值：`true`

含义：

- 控制模板中期望存在的测试 cell 如果是空白，或经过 `numeric_cleanup` 后仍然不是数字，是否直接算作 raw outlier fail。
- 空白 / 非数字测试 cell 不会参与 built golden 计算。
- 该设置只影响 outlier analysis/report 阶段的 raw cell pass/fail，以及后续 merge 传播。

可选值：

- `true`
  - 空白 / 非数字测试 cell 直接算 fail。
- `false`
  - 空白 / 非数字测试 cell 被忽略，不参与 raw fail，也不参与 merge。

兼容性：

- 老模板没有这个字段时，程序默认按 `true` 运行。
- GUI 运行分析时会提示是否把该字段写回当前 template。

## 5. Excel Template 结构

Excel 模板包含这些 sheet：

- `template_info`
- `row_dimensions`
- `column_header_levels`
- `analysis_groups`
- `node_orders`
- `analysis_dimension_filters`
- `analysis_column_filters`
- `outlier_ratio_stats`
- `README`

### 5.1 `template_info`

这一节优先使用 `xlsx` 模板里 `Field` 列的实际写法；每个字段在程序内部再映射到对应的 JSON 路径。

一行一个字段，表头固定为：

- `Field`
- `Value`
- `Notes`

常见 field：

- `name`
- `test_data_header_row`
- `row_header_row`
- `test_data_start_column`
- `unit_row`
- `test_data_start_row`
- `numeric_cleanup_enabled`
- `numeric_cleanup_mode`
- `numeric_cleanup_characters`
- `node_order`
  - 在 Excel 里已经废弃，仅保留提示
- `sample_dimension_names`
- `outlier_fail_method`
- `outlier_merged_test_fail_rule`
- `outlier_test_group_fail_rule`
- `outlier_merged_sample_fail_rule`
- `outlier_node_fail_rule`
- `outlier_row_merge_max_dimension`
- `outlier_test_merge_max_level`
- `outlier_merge_order`
- `outlier_treat_empty_cells_as_fail`

常见字段与 JSON 对应如下：

| xlsx 中 `Field` | JSON 写法 |
| --- | --- |
| `name` | `name` |
| `test_data_header_row` | `test_data_header_row` |
| `row_header_row` | `row_header_row` |
| `test_data_start_column` | `test_data_start_column` |
| `unit_row` | `unit_row` |
| `test_data_start_row` | `test_data_start_row` |
| `numeric_cleanup_enabled` | `numeric_cleanup.enabled` |
| `numeric_cleanup_mode` | `numeric_cleanup.mode` |
| `numeric_cleanup_characters` | `numeric_cleanup.characters` |
| `node_order` | `report.node_order` |
| `sample_dimension_names` | `report.sample_dimension_names` |
| `outlier_fail_method` | `report.outlier_fail_method` |
| `outlier_merged_test_fail_rule` | `report.outlier_merged_test_fail_rule` |
| `outlier_test_group_fail_rule` | `report.outlier_test_group_fail_rule` |
| `outlier_merged_sample_fail_rule` | `report.outlier_merged_sample_fail_rule` |
| `outlier_node_fail_rule` | `report.outlier_node_fail_rule` |
| `outlier_row_merge_max_dimension` | `report.outlier_row_merge_max_dimension` |
| `outlier_test_merge_max_level` | `report.outlier_test_merge_max_level` |
| `outlier_merge_order` | `report.outlier_merge_order` |
| `outlier_treat_empty_cells_as_fail` | `report.outlier_treat_empty_cells_as_fail` |
| `golden_reference_dimensions` | `golden_reference_defaults.reference_dimensions` |
| `golden_reference_filters` | `golden_reference_defaults.filters` |
| `golden_reference_center_method` | `golden_reference_defaults.center_method` |
| `golden_reference_outlier_golden_method` | `golden_reference_defaults.outlier_golden_method` |
| `golden_reference_relative_limit` | `golden_reference_defaults.relative_limit` |
| `golden_reference_sigma_multiplier` | `golden_reference_defaults.sigma_multiplier` |
| `golden_reference_absolute_lower_bound` | `golden_reference_defaults.absolute_lower_bound` |
| `golden_reference_absolute_upper_bound` | `golden_reference_defaults.absolute_upper_bound` |
| `golden_reference_overwrite_lowerbound` | `golden_reference_defaults.overwrite_lowerbound` |
| `golden_reference_overwrite_upperbound` | `golden_reference_defaults.overwrite_upperbound` |
| `golden_reference_continuous_interval` | `golden_reference_defaults.continuous_interval` |
| `golden_empty_range_fallback_to_absolute` | `golden_reference_defaults.empty_range_fallback_to_absolute` |

Excel 里如果一个单元格要写多个值，统一使用：

- `;`

优先按复杂写法理解，例如：

- `sample_dimension_names`: `lot_id;sample_id`
- `golden_reference_dimensions`: `lot_id;sample_id;reliability_node`
- `group_by_dimensions`: `reliability_node;lot_id`
- `numeric_cleanup_characters`: `,;%;mV;ohm`
- `golden_reference_filters`: `reliability_node=T0;site_id=A;temp=25C`
- `golden_reference_filters`: `reliability_node=T0,T1;site_id=A;temp=25C`

`golden_reference_filters` 有一个额外约定：

- 整体仍然用 `;` 分隔不同的 `key=value` 项
- 同一个 key 如果要匹配多个值，可以在 value 里用 `,`
- 例如：`reliability_node=T0,T1;site_id=A`
- 也可以重复写同一个 key，程序会自动合并
- 例如：`reliability_node=T0;reliability_node=T1;site_id=A`
- 对同一个 key 来说，多值按“任一值匹配”；不同 key 之间仍然同时生效

### 5.1.1 Excel Header -> JSON Key 对照表

Excel 模板里为了方便人工编辑，表头会尽量使用正常大小写和空格；JSON 里仍然使用稳定的 snake_case key。

常见映射如下：

| Excel Header | JSON Key |
| --- | --- |
| `Field` | `field` |
| `Value` | `value` |
| `Notes` | `notes` |
| `Name` | `name` |
| `Display Name` | `display_name` |
| `Optional` | `optional` |
| `Default Value` | `default_value` |
| `Source Order` | `source_order` |
| `Source Column` | `source_column` |
| `Default Split Position` | `default_split_position` |
| `Split Position By Column` | `split_position_by_column` |
| `Match Value` | `match_value` |
| `Mapped Split Position` | `mapped_split_position` |
| `Skip Empty Parts` | `skip_empty_parts` |
| `Delimiter 1` | `delimiter_1` |
| `Delimiter 2` | `delimiter_2` |
| `ID` | `id` |
| `Test Type` | `test_type` |
| `Analysis Mode` | `analysis_mode` |
| `Chain Name` | `chain_name` |
| `Unit` | `unit` |
| `Column Order` | `column_order` |
| `Column Name` | `column_name` |
| `Sequence Name` | `sequence_name` |
| `Node 1` | `node_1` |
| `Node 2` | `node_2` |
| `Key` | `key` |
| `Group By Dimension` | `group_by_dimension` / `group_by_dimensions` |
| `Numerator` | `numerator` |
| `Filter Type` | `filter_type` |
| `Filter Order` | `filter_order` |
| `Filter Value` | `filter_value` |

程序读取 Excel 时，会先把表头标准化：

- 转小写
- 空格和其他分隔符转成下划线
- 连续分隔符合并

所以例如：

- `Display Name` -> `display_name`
- `Chain Name` -> `chain_name`
- `Group By Dimension` -> `group_by_dimension` 或 `group_by_dimensions`

### 5.1.2 分析过滤默认值

`Analyze` 页里这几类运行时过滤，现在都可以在 template 里写默认值：

- `Sample Keys / Exclude Sample Keys`
- `Nodes / Exclude Nodes`
- `Tests / Exclude Tests`

JSON 结构示例：

```json
{
  "report": {
    "analysis_dimension_filters": {
      "include": {
        "sample_key": ["LOT1:S1,S2,S3,S4,3", "LOT2:3"],
        "reliability_node": ["Node1", "Node2"]
      },
      "exclude": {
        "sample_key": ["LOTX:S999"]
      }
    },
    "analysis_column_filters": {
      "include": {
        "Chain Name": ["Chain1", "Chain2"],
        "Test Type": ["TestType1", "TestType2"]
      },
      "exclude": {
        "id": ["TestType2_Chain2_1"]
      }
    }
  }
}
```

说明：

- `analysis_dimension_filters`
  - 只支持：
    - `sample_key`
    - `reliability_node`
- `sample_key`
  - 写法和 GUI 完全一致
  - 两段主键示例：`LOT1:S1,S2,S3`
- `reliability_node`
  - 直接写 node 名称列表
- `analysis_column_filters`
  - 写法和 GUI 的 `Tests / Exclude Tests` 完全一致
  - 字段和值都必须来自 template 已定义内容

### 5.1.3 `analysis_dimension_filters`

Excel 模板里，`analysis_dimension_filters` 使用长表模式：

- 一行表示一个过滤值
- 表头固定为：
  - `Mode`
  - `Dimension`
  - `Value Order`
  - `Value`

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Mode` | `report.analysis_dimension_filters.include` / `report.analysis_dimension_filters.exclude` |
| `Dimension` | `report.analysis_dimension_filters.<mode>.<dimension>` |
| `Value Order` | `report.analysis_dimension_filters.<mode>.<dimension>[*]` 的数组顺序 |
| `Value` | `report.analysis_dimension_filters.<mode>.<dimension>[*]` |

例子：

```text
include | sample_key       | 1 | LOT1:S1,S2,S3,S4,3
include | sample_key       | 2 | LOT2:3
include | reliability_node | 1 | Node1
include | reliability_node | 2 | Node2
exclude | sample_key       | 1 | LOTX:S999
```

### 5.1.4 `analysis_column_filters`

Excel 模板里，`analysis_column_filters` 也使用长表模式：

- 一行表示一个过滤值
- 表头固定为：
  - `Mode`
  - `Field`
  - `Value Order`
  - `Value`

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Mode` | `report.analysis_column_filters.include` / `report.analysis_column_filters.exclude` |
| `Field` | `report.analysis_column_filters.<mode>.<field>` |
| `Value Order` | `report.analysis_column_filters.<mode>.<field>[*]` 的数组顺序 |
| `Value` | `report.analysis_column_filters.<mode>.<field>[*]` |

例子：

```text
include | Chain Name | 1 | Chain1
include | Chain Name | 2 | Chain2
include | Test Type  | 1 | TestType1
include | Test Type  | 2 | TestType2
exclude | id         | 1 | TestType2_Chain2_1
```

### 5.1.5 结果 Excel 表头 -> Template 字段 对照表

下面这张表主要对应导出的结果文件，例如 `Sorted`、`deviation-zscore`、`deviation-golden`、`outliers`、`Outlier Summary` 里用户最常看到的表头。

| 结果 Excel Header | 对应 Template 字段 | 说明 |
| --- | --- | --- |
| `Chain Name` | `column_header_levels[0]` 对应的 `analysis_groups[*].columns[*].header_values[0]` | 第一层横向表头值，必须显式定义 |
| `Test Type` | `column_header_levels[1]` 对应的 `analysis_groups[*].columns[*].header_values[1]` | 第二层横向表头值，必须显式定义 |
| `Repeat Index` | `column_header_levels[2]` 对应的 `analysis_groups[*].columns[*].header_values[2]` | 第三层横向表头值，必须显式定义；不再从列名尾部解析 |
| `Golden` | built golden | 只来自 built golden 文件 |
| `Z Threshold` | `report.zscore_thresholds.default` 或 override | `deviation-zscore` 页显示的阈值 |
| `Deviation Threshold` | built golden 的 `outlier_golden_method` 对应参数 | 可能显示相对百分比、sigma 倍数，或 absolute 上下界 |
| `Sample ID` | `report.sample_dimension_names` 指向的那些 `row_dimensions[*].display_name` 组合值 | 不再隐式取第一个 row dimension |
| `Node` | `row_dimensions[*].display_name` 对应的节点维度 | 一般对应 `row_dimensions.name = reliability_node` |
| `Site` / 其他维度列 | `row_dimensions[*].display_name` | 结果左侧行维度列直接来自 `row_dimensions` 定义顺序 |
| `Status` | `report.outlier_fail_method` 和当前运行设置 | `Outlier Summary` 里显示 `New / Existed / Recovered` 这类状态 |
| `Group By Dimension` | `report.outlier_ratio_stats[*].group_by_dimension` / `report.outlier_ratio_stats[*].group_by_dimensions` | `Outlier Summary` 比例统计区使用 |
| `Numerator` | `report.outlier_ratio_stats[*].numerator` | 比例统计分子规则 |
| `Filter Summary` | `report.outlier_ratio_stats[*]` 的 filter 配置 | 来自 `group_ids / group_display_names / test_types / chain_names / column_names / units` |

补充说明：

- `Sorted / deviation-zscore / deviation-golden / outliers` 这几页最上面的横向列头，都是按 `column_header_levels + header_values` 定义生成的
- 结果左侧的行维度列标题，来自 `row_dimensions[*].display_name`
- 如果你希望结果里的名字完全可控，优先在 template 里填写：
  - `row_dimensions[*].display_name`
  - `column_header_levels`
  - `analysis_groups[*].columns[*].header_values`

### 5.2 `row_dimensions`

一行表示一个 source。表头：

- `Name`
- `Display Name`
- `Optional`
- `Default Value`
- `Source Order`
  - 类型：`int`
  - Excel 模板专用
  - 用来表示同一个 `row_dimension` 下多个 source 的顺序
  - 程序读取 Excel 模板时，会先按 `source_order` 排序，再按这个顺序拼接 source 结果
  - 如果一个维度只有一个 source，这个值通常就是 `1`
  - 如果一个维度有多个 source，例如 `Line` 再 `Site`，那就可以写成：
    - `Line` 的 `source_order = 1`
    - `Site` 的 `source_order = 2`
  - 这个字段不会出现在 JSON 里，因为 JSON 里的 `sources` 本身就是有序数组，顺序已经天然表达了 source 的先后关系
- `Source Column`
- `Default Split Position`
- `Split Position By Column`
- `Match Value`
- `Mapped Split Position`
- `Skip Empty Parts`
- `Delimiter 1`
- `Delimiter 2`
- ...

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Name` | `row_dimensions[*].name` |
| `Display Name` | `row_dimensions[*].display_name` |
| `Optional` | `row_dimensions[*].optional` |
| `Default Value` | `row_dimensions[*].default_value` |
| `Source Order` | `row_dimensions[*].sources[*]` 的数组顺序，Excel 专用列 |
| `Source Column` | `row_dimensions[*].sources[*].column` |
| `Default Split Position` | `row_dimensions[*].sources[*].default_split_position` |
| `Split Position By Column` | `row_dimensions[*].sources[*].split_position_by_column` |
| `Match Value` | `row_dimensions[*].sources[*].split_position_map` 的 key |
| `Mapped Split Position` | `row_dimensions[*].sources[*].split_position_map` 的 value |
| `Skip Empty Parts` | `row_dimensions[*].sources[*].skip_empty_parts` |
| `Delimiter 1..N` | `row_dimensions[*].sources[*].split_delimiters[*]` |

说明：

- 同一个 `name` 可以出现多行，表示同一个维度有多个 source
- `source_order` 控制 source 的拼接顺序
- `delimiter_1 / delimiter_2 / ...` 表示一个 source 可以有多个 delimiter
- 如果同一个 source 需要多条“匹配值 -> split position”映射，也可以占多行
  - 这几行通常具有相同的：
    - `Name`
    - `Source Order`
    - `Source Column`
  - 不同的是：
    - `Match Value`
    - `Mapped Split Position`

动态 split position 的 Excel 写法：

- `Default Split Position`
  - 普通默认值，作为 fallback
- `Split Position By Column`
  - 要查看哪一列来决定取哪个位置，例如 `Site`
- `Match Value`
  - 另一列的匹配值，例如 `1`、`2`、`A`
- `Mapped Split Position`
  - 命中该匹配值时要用的 split position

例如同一个 source 可以写成 3 行：

| Name | Source Order | Source Column | Default Split Position | Split Position By Column | Match Value | Mapped Split Position |
| --- | --- | --- | --- | --- | --- | --- |
| `sample_id` | `1` | `recordName` | `0` | `Site` | `1` | `0` |
| `sample_id` | `1` | `recordName` | `0` | `Site` | `2` | `1` |
| `sample_id` | `1` | `recordName` | `0` | `Site` | `3` | `2` |

含义是：

- 如果 `Site=1`，取第 0 段
- 如果 `Site=2`，取第 1 段
- 如果 `Site=3`，取第 2 段
- 其他没命中的值，回退到默认的 `Default Split Position = 0`

为什么 JSON 里没有 `source_order`：

- 因为 JSON 的 `sources` 是数组，天然就有顺序
- 例如：

```json
"sources": [
  { "column": "Line" },
  { "column": "Site" }
]
```

这里就已经表示先取 `Line`，再取 `Site`，不需要再额外写一个 `source_order`

为什么 Excel 里需要 `source_order`：

- 因为 Excel 是按“多行表示一个维度的多个 source”
- 如果不单独写 `source_order`，只靠行位置就不够稳定
- 加上这个字段后，你可以排序、插行、筛选之后仍然保持 source 的明确顺序

### 5.3 `analysis_groups`

一行表示一个 raw column。表头：

- `ID`
- `Display Name`
- `Test Type`
- `Analysis Mode`
- `Chain Name`
- `Unit`
- `Column Order`
- `Column Name`

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `ID` | `analysis_groups[*].id` |
| `Display Name` | `analysis_groups[*].display_name` |
| `Test Type` | `analysis_groups[*].columns[*].header_values[*]` 中对应 `Test Type` 那一层 |
| `Analysis Mode` | `analysis_groups[*].analysis_mode` |
| `Chain Name` | `analysis_groups[*].columns[*].header_values[*]` 中对应 `Chain Name` 那一层 |
| `Unit` | `analysis_groups[*].unit` |
| `Column Order` | `analysis_groups[*].columns[*].column_order` |
| `Column Name` | `analysis_groups[*].columns[*].name` |

### 5.4 `node_orders`

一行表示一条 node sequence。表头：

- `Sequence Name`
- `Node 1`
- `Node 2`
- `Node 3`
- ...

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `Sequence Name` | `node_orders[*].name` |
| `Node 1..N` | `node_orders[*].sequence[*]` |

### 5.5 `outlier_ratio_stats`

一行表示一个 ratio filter 项。表头：

- `ID`
- `Display Name`
- `Group By Dimension`
- `Numerator`
- `Filter Type`
- `Filter Order`
- `Filter Value`

| xlsx 列名 | JSON 写法 |
| --- | --- |
| `ID` | `report.outlier_ratio_stats[*].id` |
| `Display Name` | `report.outlier_ratio_stats[*].display_name` |
| `Group By Dimension` | `report.outlier_ratio_stats[*].group_by_dimension` / `report.outlier_ratio_stats[*].group_by_dimensions` |
| `Numerator` | `report.outlier_ratio_stats[*].numerator` |
| `Filter Type` | `report.outlier_ratio_stats[*]` 中的 `group_ids / group_display_names / test_types / chain_names / column_names / units` 之一 |
| `Filter Order` | 对应 filter 数组里的顺序 |
| `Filter Value` | 对应 filter 数组里的元素值 |

其中：

- `filter_type` 允许值：
  - `id`
  - `display_name`
  - `test_type`
  - `chain_name`
  - `column_name`
  - `unit`
  - `chain`
  - `raw_column`

- 同一个 `ID` 下：
  - 如果是同一个 `filter_type` 对应多个 `filter_value`，含义是 `OR`
  - 例如两行 `test_type=A` 和 `test_type=B`，表示 `test_type=A or B`
  - 如果是不同 `filter_type`，它们之间的关系是 `AND`
  - 例如 `test_type=Voltage` 且 `chain_name=Link4`
- Excel 长表里如果要表达“同一个 key 多个值”，请写成多行
  - 当前不是在一个 `Filter Value` 单元格里写 `A,B`

- 如果一个统计项没有任何 filter，也可以只留一行基础配置，把 `filter_type / filter_value` 留空
- 如果要做多维联合分组，可以在 `Group By Dimension` 同一个单元格里用分号分隔多个维度
  - 例如：`reliability_node;lot_id`

例子：

```text
new_ratio_by_node_all | New Outlier Ratio By Node | reliability_node | new_outlier_samples |            | 1 | 
total_ratio_by_node_link4 | Total Outlier Ratio By Node (Link4) | reliability_node | outlier_samples | chain_name | 1 | Link4
total_ratio_by_node_v_link1_1p8v | Total Outlier Ratio By Node (V_Link1_1p8V) | reliability_node | outlier_samples | column_name | 1 | V_Link1_1p8V
link4_voltage_v_ratio | Link4 Voltage Ratio | reliability_node | outlier_samples | id | 1 | link4_voltage
link4_voltage_v_ratio | Link4 Voltage Ratio | reliability_node | outlier_samples | display_name | 2 | Link4 Voltage
link4_voltage_v_ratio | Link4 Voltage Ratio | reliability_node | outlier_samples | test_type | 3 | V
link4_voltage_v_ratio | Link4 Voltage Ratio | reliability_node | outlier_samples | unit | 4 | V
ab_ratio | A Or B Ratio | reliability_node | outlier_samples | test_type | 1 | A
ab_ratio | A Or B Ratio | reliability_node | outlier_samples | test_type | 2 | B
new_ratio_by_node_and_lot | New Outlier Ratio By Node And Lot | reliability_node;lot_id | new_outlier_samples |  | 1 | 
```

这里的 `ab_ratio` 表示：

- `test_type=A or B`
- 不是 `A and B`

## 6. 布尔值和常见输入格式

Excel / JSON 中布尔字段支持这些写法：

- 真值：
  - `1`
  - `true`
  - `yes`
  - `y`
- 假值：
  - `0`
  - `false`
  - `no`
  - `n`

如果布尔内容不是这些，会报错。

## 7. 主要校验规则

程序会自动校验这些内容：

- `row_dimension.name` 不能重复
- `test_data_start_row` 必须显式定义，不能依赖程序自动推断
- 每个 `row_dimension` 必须至少有一个 source
- 每个 source 必须有 `column`
- 如果 source 使用了任意 split 逻辑（`default_split_position` 或动态映射），必须同时有 `split_delimiters`
- 如果 source 配了 `split_position_by_column`，必须同时有 `split_position_map`
- 如果 source 配了 `split_position_map`，必须同时有 `split_position_by_column`
- `split_position_map` 里的位置值不能是负数
- `analysis_group.id` 不能重复
  - 但更准确地说：如果两行不应该共享同一组 golden / z-score 计算或同一组 golden 手动规则，就不要写成同一个 `id`
- `analysis_group.analysis_mode` 只能是：
  - `pooled_columns`
  - `per_column`
- 同一个 raw column 不能出现在多个 `analysis_groups`
- `report.outlier_fail_method` 只能是：
  - `modified_z_score`
  - `golden_deviation`
  - `zscore_and_golden`
  - `zscore_or_golden`
- `report.outlier_merged_test_fail_rule` 只能是：
  - `any_fail`
  - `all_fail`
- `report.outlier_test_group_fail_rule` 只能是：
  - `any_fail`
  - `all_fail`
- `report.outlier_merged_sample_fail_rule` 只能是：
  - `any_fail`
  - `all_fail`
- `report.outlier_node_fail_rule` 只能是：
  - `any_fail`
  - `all_fail`
- `report.outlier_row_merge_max_dimension` 必须显式定义，且必须是已存在的 `row_dimensions.name`
- `report.outlier_test_merge_max_level` 必须显式定义，且必须是已存在的 `column_header_levels.name`
- `report.outlier_merge_order` 必须是 6 种合法执行顺序之一
- `report.outlier_ratio_stats[*].numerator` 只能是：
  - `new_outlier_samples`
  - `outlier_samples`
- `report.outlier_ratio_stats[*].group_by_dimensions` 必须显式定义，不能留空
- `report.outlier_ratio_stats[*].group_by_dimension` 必须是已存在的 `row_dimensions.name` 或 `column_header_levels.name`
- `report.outlier_ratio_stats[*].group_by_dimensions[*]` 也必须全部是已存在的 `row_dimensions.name` 或 `column_header_levels.name`
- 如果存在 `reliability_node`，那么 `report.outlier_ratio_stats[*].group_by_dimensions` 的 row 维度只能使用 `reliability_node` 及更高优先级的 row 维度；也可以使用 `Chain Name` 这类 column header level
- 如果存在 `reliability_node`，那么 `report.outlier_row_merge_max_dimension` 必须低于 `reliability_node`
- `node_orders` 中每条 sequence 不能为空
- 每条 node sequence 内部不能有重复 node
- 多条 node sequence 之间不能出现公共节点的反向顺序冲突

## 8. 常见问题

### 8.1 一个维度能不能从多个原始列来？

可以。给同一个 `row_dimension` 配多个 `sources` 即可。

### 8.2 一个 source 能不能用多个 delimiter？

可以。`split_delimiters` 是列表，例如：

```json
"split_delimiters": ["_", "｜"]
```

### 8.3 能不能一个维度里有的 source split，有的 source 不 split？

可以。

- 有 `default_split_position` 的 source 会先 split
- 没有 `default_split_position` 的 source 会直接取整格内容

### 8.4 能不能按另一列的值动态决定 split position？

可以。给 source 增加：

- `split_position_by_column`
- `split_position_map`

例如：

```json
{
  "column": "recordName",
  "split_delimiters": ["_"],
  "default_split_position": 0,
  "split_position_by_column": "Site",
  "split_position_map": {
    "1": 0,
    "2": 1,
    "3": 2
  }
}
```

程序会先看 `Site` 列：

- `Site=1` 时取第 0 段
- `Site=2` 时取第 1 段
- `Site=3` 时取第 2 段
- 其他值回退到 `default_split_position=0`

### 8.5 为什么有的 template 字段在 Excel 里和 JSON 结构不完全一样？

因为 Excel 模板更偏向“方便人工编辑和校验”，所以做了表格化展开：

- `row_dimensions` 按 source 拆行
- `analysis_groups` 按 raw column 拆行
- `node_orders` 按 node 拆列
- `analysis_dimension_filters` 按一个过滤值一行展开
- `analysis_column_filters` 按一个过滤值一行展开

程序会把这些 sheet 再翻译回内部 JSON 结构。

## 9. 推荐做法

- `row_dimensions`
  - 尽量把一个维度的提取规则写清楚，不要混用太多 source，除非业务上真的需要重组

- `analysis_groups`
  - `id` 取稳定、短一点的业务名
  - `columns` 顺序尽量和实际展示顺序一致

- `node_orders`
  - 如果业务里确实有多种 node 路径，优先写 `node_orders`
  - 公共节点顺序必须保持一致

- `outlier_ratio_stats`
  - 如果只是想看每个 node 新增失效比例，先从 `group_by_dimension=reliability_node + numerator=new_outlier_samples` 开始
  - 如果想只看某条链路或某个测试项，再加 `chain_names`、`column_names`
  - 如果想按模板定义本身过滤，也可以加 `group_ids`、`group_display_names`、`test_types`、`units`

- `analysis_dimension_filters` / `analysis_column_filters`
  - 推荐只放“最常复用的默认分析范围”
  - 真正临时性的筛选，优先在 GUI 的 `Analyze` 页里改
  - 如果 GUI 当前值和 template 默认值不同，运行前会提示是否回写 template

## 10. 相关命令

校验 template：

```bash
excel-data-analysis validate-template --input examples/chip_reliability_template.json
excel-data-analysis validate-template --input examples/chip_reliability_template.xlsx
```

JSON 转 Excel：

```bash
excel-data-analysis template-to-xlsx \
  --input examples/chip_reliability_template.json \
  --output examples/chip_reliability_template.xlsx
```

Excel 转 JSON：

```bash
excel-data-analysis template-to-json \
  --input examples/chip_reliability_template.xlsx \
  --output /tmp/chip_reliability_template.json
```
