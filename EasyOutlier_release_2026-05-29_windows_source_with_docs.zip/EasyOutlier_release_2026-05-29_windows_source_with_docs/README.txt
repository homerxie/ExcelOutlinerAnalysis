Easy Outlier Windows package

This package is prepared for Windows users who want to build and run Easy Outlier locally.

Included:
- application source code
- Windows setup/build scripts
- PyInstaller spec files
- icon files
- GUI and template help manuals

Intentionally excluded:
- examples and template_example folders
- local databases, release archives, virtual environments, caches, and test output

Build on Windows:
1. Double-click setup_windows.bat
2. After setup completes, double-click build_windows.bat
3. GUI output will be created under dist\EasyOutlier
4. CLI output will be created under dist\easy-outlier

Notes:
- Build this package on Windows. PyInstaller does not generate a Windows executable from macOS.
- The application includes built-in JSON and Excel templates under src\excel_data_analysis\assets\templates.
- This package is source-only and prepared for a clean Windows PyInstaller build.
