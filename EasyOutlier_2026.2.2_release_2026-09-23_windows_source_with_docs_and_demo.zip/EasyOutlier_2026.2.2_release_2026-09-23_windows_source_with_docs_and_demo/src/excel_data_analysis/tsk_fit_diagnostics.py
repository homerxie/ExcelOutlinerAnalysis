"""Numerical evidence for a Logistic fit, separate from publishable estimates.

This module observes the returned fit.  It never changes coefficients, solver
limits, identifiability decisions or reported risk probabilities.
"""

from __future__ import annotations

import json
import math
import platform
import sys

import numpy as np
import scipy
from scipy.special import expit

from . import __version__


def _number(value):
    if value is None:
        return "不可用"
    try:
        return f"{float(value):.12g}" if math.isfinite(float(value)) else str(value)
    except (TypeError, ValueError):
        return str(value)


def _quoted(value):
    return json.dumps(str(value), ensure_ascii=False)


def _matrix_diagnostics(matrix):
    rows, columns = matrix.shape
    if not np.all(np.isfinite(matrix)):
        return {"shape": [rows, columns], "rank": None, "status": "nonfinite_matrix"}, None
    _, singular, right = np.linalg.svd(matrix, full_matrices=rows < columns)
    tolerance = max(matrix.shape) * np.finfo(float).eps * singular[0] * 100 if len(singular) else 0.
    rank = int(np.sum(singular > tolerance))
    null = right[rank:]
    identifiable = (np.linalg.norm(null, axis=0) < 1e-7 if len(null)
                    else np.ones(columns, dtype=bool))
    return {
        "shape": [rows, columns], "rank": rank, "status": "ok",
        "tolerance": float(tolerance), "singular_values": singular.tolist(),
        "smallest_retained": float(singular[rank - 1]) if rank else None,
        "largest_discarded": float(singular[rank]) if rank < len(singular) else None,
        "nullity": columns - rank, "identifiable": identifiable.tolist(),
        "null_directions": null.tolist(),
    }, right[:rank]


def _parameter_names(model, type_ids):
    parameters = [{"index": index, "name": f"α[TSK={_quoted(tsk)}]", "kind": "tsk_intercept",
                   "tsk_id": tsk} for index, tsk in enumerate(type_ids)]
    for index, (name, level) in enumerate(model.coefficient_columns, start=len(type_ids)):
        parameters.append({
            "index": index,
            "name": f"β[{_quoted(name)}]" if level is None else f"γ[{_quoted(name)}={_quoted(level)}]",
            "kind": "numeric_feature" if level is None else "categorical_feature",
            "feature": name, "level": level,
        })
    return parameters


def build_logistic_fit_debug(model, coefficients, type_ids, converged, derivative):
    """Collect parameter, rank and boundary diagnostics without refitting."""
    theta = np.asarray(coefficients, dtype=float)
    value, gradient, predicted, _ = model.evaluate(theta)
    sample_count = max(float(model.n.sum()), 1.)
    projected = np.asarray(gradient).copy()
    projected[(theta <= -35. + 1e-10) & (gradient > 0)] = 0.
    projected[(theta >= 35. - 1e-10) & (gradient < 0)] = 0.
    scaled_gradient = projected / sample_count
    parameters = _parameter_names(model, type_ids)
    design, row_basis = _matrix_diagnostics(model.design)
    chain, _ = _matrix_diagnostics(derivative)
    chain_types, _ = _matrix_diagnostics(derivative[:, :len(type_ids)])
    for index, row in enumerate(parameters):
        row.update({
            "coefficient": float(theta[index]), "raw_gradient": float(gradient[index]),
            "projected_gradient_per_observation": float(scaled_gradient[index]),
            "gradient_threshold_ratio": float(abs(scaled_gradient[index]) / 1e-8),
            "near_boundary": bool(abs(theta[index]) >= 34.9),
            "distance_to_bound": float(35. - abs(theta[index])),
            "design_identifiable": design.get("identifiable", [None] * len(theta))[index],
            "chain_identifiable": chain.get("identifiable", [None] * len(theta))[index],
        })
    worst = int(np.argmax(np.abs(scaled_gradient))) if len(theta) else None
    eta = model.design @ theta
    instance_probability = expit(eta)
    failures = []
    if not math.isfinite(value) or not np.all(np.isfinite(gradient)):
        failures.append("nonfinite_objective_or_gradient")
    if not converged:
        failures.append("stationarity_not_established")
    if any(row["near_boundary"] for row in parameters):
        failures.append("coefficient_boundary")
    if design["rank"] is not None and design["rank"] < len(theta):
        failures.append("design_rank_deficient")
    if chain["rank"] is not None and chain["rank"] < len(theta):
        failures.append("local_chain_rank_deficient")
    result = {
        "version": 1, "scope": "main_logistic_fit", "parameters": parameters,
        "runtime": {"application": __version__, "python": platform.python_version(),
                    "platform": sys.platform, "numpy": np.__version__, "scipy": scipy.__version__},
        "coefficient_bounds": [-35., 35.], "boundary_warning_threshold": 34.9,
        "gradient_threshold": 1e-8, "optimizer_converged": bool(converged),
        "failure_codes": failures, "negative_log_likelihood": float(value),
        "projected_gradient_norm": float(np.max(np.abs(scaled_gradient), initial=0.)),
        "worst_coefficient_index": worst,
        "matrices": {"instance_design": design, "chain_jacobian": chain, "chain_tsk_block": chain_types},
        "observations": {"chain_count": len(model.n), "instance_count": len(model.design),
                         "total_tested": int(model.n.sum()), "total_failed": int(model.k.sum()),
                         "all_pass_chains": int(np.count_nonzero(model.k == 0)),
                         "all_fail_chains": int(np.count_nonzero(model.k == model.n)),
                         "mixed_chains": int(np.count_nonzero((model.k > 0) & (model.k < model.n)))},
        "ranges": {"instance_logit": [float(eta.min()), float(eta.max())],
                   "instance_probability": [float(instance_probability.min()), float(instance_probability.max())],
                   "chain_probability": [float(predicted.min()), float(predicted.max())]},
        "categorical_features": model.categorical_features,
        "numeric_scaling": {name: {"mean": float(mean), "scale": float(scale),
                                   "constant": name in model.constant_features}
                            for name, mean, scale in zip(model.numeric_names, model.means, model.scales)},
        "optimizer": getattr(model, "optimizer_diagnostics", {}),
    }
    # A numerical row-space projection is diagnostic only.  It is not a new
    # fit, and equivalence must be checked explicitly before interpreting it.
    if row_basis is not None and design["rank"] < len(theta):
        reduced_theta = row_basis.T @ (row_basis @ theta)
        reduced_value, _, reduced_prediction, _ = model.evaluate(reduced_theta)
        result["redundant_representation_check"] = {
            "method": "numerical_design_row_space_projection_diagnostic_only",
            "coefficients": reduced_theta.tolist(),
            "max_abs_coefficient_before": float(np.max(np.abs(theta))),
            "max_abs_coefficient_after": float(np.max(np.abs(reduced_theta))),
            "max_abs_logit_change": float(np.max(np.abs(model.design @ reduced_theta - eta))),
            "negative_log_likelihood_change": float(reduced_value - value),
            "max_abs_chain_probability_change": float(np.max(np.abs(reduced_prediction - predicted))),
        }
    return result


_FAILURE_TEXT = {
    "nonfinite_objective_or_gradient": "目标函数或梯度出现非有限数值（NaN/Infinity）",
    "stationarity_not_established": "未通过有限目标函数与投影梯度收敛检查",
    "coefficient_boundary": "至少一个系数达到触界警戒值 |θ|≥34.9；风险输出被暂停",
    "design_rank_deficient": "实例设计矩阵存在数值不可区分方向",
    "local_chain_rank_deficient": "当前系数处的 Chain Jacobian 存在数值不可区分方向",
}


_REASON_TEXT = {
    "projected_gradient_converged": "投影梯度已达到收敛标准",
    "gradient_tolerance_not_met": "投影梯度尚未达到收敛标准",
    "solver_success_without_stationarity": "优化器报告成功，但程序的梯度复核未通过",
    "iteration_limit": "达到迭代次数上限",
    "evaluation_limit": "达到目标函数评估次数上限",
    "line_search_failure": "线搜索未找到可接受步长",
    "numerical_failure": "优化器报告数值问题",
    "objective_tolerance_stop": "目标函数变化触发停止条件",
    "objective_stagnation": "目标函数变化很小，可能存在数值停滞",
    "nonfinite_objective": "目标函数出现非有限数值",
    "nonfinite_gradient": "梯度出现非有限数值",
    "boundary_reached": "至少一个候选系数达到触界警戒值",
}


def _trend_text(initial, final):
    before, after = initial.get("threshold_ratio"), final.get("threshold_ratio")
    if before is None or after is None:
        return "与阶段起点相比：缺少有限梯度，不能判断距离标准的变化。"
    if after < 1.:
        direction = "已达到梯度标准"
    elif after < before:
        direction = "更接近梯度标准，但尚未达到"
    elif after > before:
        direction = "离梯度标准更远（不等于已证明发散）"
    else:
        direction = "与梯度标准的距离未改善"
    return f"与阶段起点相比：{direction}；标准倍数 {_number(before)} → {_number(after)}。"


def _coefficient_line(coefficients, names):
    return "; ".join(f"{names[index] if index < len(names) else index}={_number(value)}"
                     for index, value in enumerate(coefficients or []))


def format_logistic_fit_debug(debug):
    """Produce a self-contained, copyable diagnostic transcript."""
    parameters = debug.get("parameters", [])
    names = [row["name"] for row in parameters]
    gradient_norm = debug.get("projected_gradient_norm")
    gradient_ratio = gradient_norm / 1e-8 if gradient_norm is not None else None
    lines = [
        "TSK Logistic 主拟合数值诊断 v1",
        "以下系数是优化器的候选数值，不代表可发布的特征效应或风险估计。",
        "主拟合记录各起点和阶段；迭代轨迹保留首尾并抽样，未逐条记录线搜索试探或置信区间的重拟合。",
        "触界只是保护条件，不能单凭触界断定不存在有限最优解。秩是在当前返回系数处计算的局部数值诊断。",
        "模型：η=α_TSK+Σβ_j·z_j+Σγ_(类别)·I(类别)；z_j=(x_j−mean_j)/scale_j；p=1/(1+exp(−η))。",
        "Chain 概率：q=1−∏(1−p_i)。类别基准系数固定为 0，不属于待优化参数。",
        "运行环境：" + json.dumps(debug.get("runtime", {}), ensure_ascii=False),
        "",
        "【最终状态与判定标准】",
        f"优化收敛检查：{'通过' if debug.get('optimizer_converged') else '未通过'}；"
        f"NLL={_number(debug.get('negative_log_likelihood'))}",
        "系数限制：[-35, 35]；触界警戒：|θ|≥34.9（包括 TSK 截距）。",
        f"收敛标准：max|投影梯度|/总Tested < {_number(debug.get('gradient_threshold'))}；"
        f"当前={_number(debug.get('projected_gradient_norm'))}；"
        f"标准倍数={_number(gradient_ratio)}。",
        "目标 NLL 越小越好；梯度标准倍数越小越接近一阶收敛标准，两者不必同步或逐步单调改善。",
    ]
    worst = debug.get("worst_coefficient_index")
    if worst is not None and worst < len(names):
        lines.append(f"最大投影梯度项：{names[worst]}")
    failures = debug.get("failure_codes", [])
    lines.extend(f"判定：{_FAILURE_TEXT.get(code, code)}" for code in failures)
    if not failures:
        lines.append("判定：主拟合通过当前收敛、触界与数值秩检查。")
    touched = [row for row in parameters if row.get("near_boundary")]
    lines.append("触界参数：" + ("; ".join(f"{row['name']}={_number(row['coefficient'])}"
                                                for row in touched) or "无"))
    lines.extend(["", "【有效观测概况】", json.dumps(debug.get("observations", {}), ensure_ascii=False)])
    lines.append("全 Pass/全 Fail 链也属于有效数据；这些计数本身不能证明发生分离或不存在有限估计。")
    for name, values in debug.get("ranges", {}).items():
        lines.append(f"{name} 范围：" + " ~ ".join(_number(value) for value in values))
    for name, definition in debug.get("categorical_features", {}).items():
        lines.append(f"类别 {_quoted(name)}：基准={_quoted(definition.get('reference'))}；"
                     f"有效类别={json.dumps(definition.get('active_levels', []), ensure_ascii=False)}；"
                     f"无有效观测类别={json.dumps(definition.get('missing_levels', []), ensure_ascii=False)}")
    for name, definition in debug.get("numeric_scaling", {}).items():
        lines.append(f"数值特征 {_quoted(name)}：mean={_number(definition.get('mean'))}；"
                     f"scale={_number(definition.get('scale'))}；常量列={definition.get('constant')}。"
                     "β 是标准化单位的系数；常量列采用 scale=1。")
    lines.extend(["", "【最终全部候选系数】"])
    for row in parameters:
        lines.append(f"[{row['index']}] {row['name']} = {_number(row['coefficient'])}；"
                     f"原梯度={_number(row['raw_gradient'])}；"
                     f"投影梯度/总Tested={_number(row['projected_gradient_per_observation'])}；"
                     f"标准倍数={_number(row['gradient_threshold_ratio'])}；"
                     f"距±35边界={_number(row['distance_to_bound'])}；"
                     f"触界={'是' if row['near_boundary'] else '否'}；"
                     f"实例/链局部可识别={row['design_identifiable']}/{row['chain_identifiable']}")
    lines.extend(["", "【实例与 Chain 的秩】"])
    for name, matrix in debug.get("matrices", {}).items():
        lines.append(f"{name}：形状={matrix.get('shape')}；rank={matrix.get('rank')}；"
                     f"奇异值截断阈值={_number(matrix.get('tolerance'))}")
        lines.append("奇异值：" + ", ".join(_number(value) for value in matrix.get("singular_values", [])))
        null = matrix.get("null_directions", [])
        # Full vectors remain in the structured XLSX diagnostics.  Keep the
        # readable report bounded even for a very wide, badly deficient model.
        for index, vector in enumerate(null[:8]):
            terms = [f"{names[i]}:{_number(weight)}" for i, weight in enumerate(vector) if abs(weight) > 1e-7]
            lines.append(f"数值不可区分方向 {index + 1}：" + "; ".join(terms))
        if len(null) > 8:
            lines.append(f"仅展开前 8/{len(null)} 个方向；完整向量保存在 XLSX 的 fit_debug 中。")
    check = debug.get("redundant_representation_check")
    if check:
        lines.extend(["", "【冗余系数表示检查（不改变拟合结果）】"])
        for key in ("max_abs_coefficient_before", "max_abs_coefficient_after", "max_abs_logit_change",
                    "negative_log_likelihood_change", "max_abs_chain_probability_change"):
            lines.append(f"{key}={_number(check.get(key))}")
        lines.append("数值行空间投影后的系数：" + _coefficient_line(check.get("coefficients"), names))
        lines.append("必须结合预测/目标变化与奇异值阈值判断是否等价；这不是重新拟合，也不恢复单个系数的可识别性。")
    optimizer = debug.get("optimizer", {})
    lines.extend(["", "【各起点与优化阶段】",
                  f"选中起点={optimizer.get('selected_start_index', '未记录')}；规则=最低负对数似然（NLL）。"])
    for start in optimizer.get("starts", []):
        lines.append(f"\n起点 {start.get('start_index')}：收敛={start.get('converged')}"
                     + ("（最终选中）" if start.get("start_index") == optimizer.get("selected_start_index") else ""))
        lines.append("初始全系数：" + _coefficient_line(start.get("initial_coefficients"), names))
        for stage in start.get("stages", []):
            lines.append(f"阶段 {stage.get('phase')} / {stage.get('method')}"
                         + ("（此起点最终采用）" if stage.get("selected") else ""))
            solver = stage.get("solver", {})
            lines.append("优化器停止信息：" + json.dumps(solver, ensure_ascii=False))
            lines.append("本阶段配置：" + json.dumps(stage.get("options", stage.get("limits", {})), ensure_ascii=False))
            lines.append("具体判定：" + "; ".join(f"{_REASON_TEXT.get(code, code)} [{code}]"
                                                  for code in stage.get("reason_codes", [])))
            lines.append("起始指标：" + json.dumps(stage.get("initial_metrics", {}), ensure_ascii=False))
            lines.append("结束指标：" + json.dumps(stage.get("final_metrics", {}), ensure_ascii=False))
            lines.append(_trend_text(stage.get("initial_metrics") or {}, stage.get("final_metrics") or {}))
            lines.append("目标试探统计：" + json.dumps(stage.get("objective_evaluations", {}), ensure_ascii=False))
            lines.append("迭代趋势：" + json.dumps(stage.get("iteration_summary", {}), ensure_ascii=False))
            lines.append("阶段初始全系数：" + _coefficient_line(stage.get("initial_coefficients"), names))
            lines.append("阶段最终全系数：" + _coefficient_line(stage.get("final_coefficients"), names))
            history = stage.get("history", {})
            lines.append(f"抽样轨迹：总迭代={history.get('total_iterations')}；采样步长={history.get('stride')}；"
                         f"记录数={len(history.get('samples', []))}；上限={history.get('limit')}")
            for sample in history.get("samples", []):
                metrics = sample.get("metrics") or {}
                lines.append(f"  iter={sample.get('iteration')} NLL={_number(metrics.get('nll'))} "
                             f"梯度/总Tested={_number(metrics.get('projected_gradient_norm'))} "
                             f"标准倍数={_number(metrics.get('threshold_ratio'))} "
                             f"最差项index={metrics.get('worst_coefficient_index')} "
                             f"触界项index={metrics.get('boundary_indices')}")
                lines.append("    " + _coefficient_line(sample.get("coefficients"), names))
        lines.append("此起点最终全系数：" + _coefficient_line(start.get("final_coefficients"), names))
    return "\n".join(lines)
