"""Read-only feature interpretation; all static presentation lives in the form."""
from __future__ import annotations

import math

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt
from PySide6.QtWidgets import QWidget

from ..tsk_feature_summary import summarize_tsk_features
from .ui_tsk_feature_panel import Ui_TskFeaturePanelForm


def _number(value, *, percent=False):
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value):
        return ""
    return f"{value * 100:.5g}%" if percent else f"{value:.8g}"


class _FeatureTableModel(QAbstractTableModel):
    def __init__(self, headers, parent=None):
        super().__init__(parent)
        self.headers = list(headers)
        self.rows = []

    def set_rows(self, rows):
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.headers)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        display, raw, tooltip = self.rows[index.row()][index.column()]
        if role == Qt.DisplayRole:
            return display
        if role == Qt.UserRole:
            return raw
        if role == Qt.ToolTipRole:
            return tooltip or display
        if role == Qt.TextAlignmentRole and isinstance(raw, (int, float)):
            return int(Qt.AlignRight | Qt.AlignVCenter)
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and orientation == Qt.Horizontal and 0 <= section < len(self.headers):
            return self.headers[section]
        return super().headerData(section, orientation, role)


class TskFeaturePanel(QWidget):
    """Display a fitted model and existing predictions without running a fit."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_TskFeaturePanelForm()
        self.ui.setupUi(self)
        self.summary = {}
        self._risks = []
        self.risk_model = self._attach_table(self.ui.risksTableView)
        self.coefficient_model = self._attach_table(self.ui.coefficientsTableView)
        self.ui.featureComboBox.setItemData(0, None)
        self.ui.featureComboBox.currentIndexChanged.connect(self._show_risks)

    def _attach_table(self, table):
        model = _FeatureTableModel(table.property("columnHeaders"), self)
        proxy = QSortFilterProxyModel(table)
        proxy.setSourceModel(model)
        proxy.setSortRole(Qt.UserRole)
        table.setModel(proxy)
        table.sortByColumn(-1, Qt.AscendingOrder)
        return model

    @staticmethod
    def _cell(value, *, numeric=False, percent=False, tooltip=""):
        display = _number(value, percent=percent) if numeric else str(value or "")
        return display, value, tooltip

    @staticmethod
    def _status(widget, value):
        property_name = {
            "ok": "okText", "no_data": "noDataText", "not_identifiable": "notIdentifiableText",
            "fit_not_converged": "fitNotConvergedText", "interval_unavailable": "intervalUnavailableText",
            "outside_model_domain": "outsideDomainText", "observed": "observedText",
            "no_active_support": "noActiveSupportText", "extrapolated": "extrapolatedText",
            "reference_coding": "referenceCodingText", "unavailable": "unavailableText",
        }.get(value)
        return str(widget.property(property_name) or value or "") if property_name else str(value or "")

    def set_group(self, group, view=None):
        self.summary = summarize_tsk_features(group or {}, view=view)
        self.ui.formulaLabel.setText((self.summary.get("formula") if group else "")
                                    or self.ui.formulaLabel.property("emptyText"))
        self._risks = self.summary.get("risks", [])
        selected = self.ui.featureComboBox.currentData()
        self.ui.featureComboBox.blockSignals(True)
        self.ui.featureComboBox.clear()
        self.ui.featureComboBox.addItem(self.ui.featureComboBox.property("allFeaturesText"), None)
        for feature in dict.fromkeys(row["feature"] for row in self._risks):
            self.ui.featureComboBox.addItem(feature, feature)
        selected_index = self.ui.featureComboBox.findData(selected)
        self.ui.featureComboBox.setCurrentIndex(max(0, selected_index))
        self.ui.featureComboBox.setEnabled(bool(self._risks))
        self.ui.featureComboBox.blockSignals(False)
        risk_reason = self.summary.get("risk_reason")
        self.ui.riskStatusLabel.setText(risk_reason or self.ui.riskStatusLabel.property("emptyText"))
        self.ui.riskStatusLabel.setVisible(bool(risk_reason) or not self._risks)
        self._show_risks()
        coefficient_table = self.ui.coefficientsTableView
        coefficient_rows = []
        for row in self.summary.get("coefficients", []):
            tooltip = row.get("note", "")
            coefficient_rows.append([
                self._cell(row.get("term"), tooltip=tooltip),
                self._cell(row.get("coefficient"), numeric=True, tooltip=tooltip),
                self._cell(self._status(coefficient_table, row.get("status")), tooltip=tooltip),
                self._cell(row.get("coefficient_scale"), tooltip=tooltip),
                self._cell(row.get("mean"), numeric=True), self._cell(row.get("scale"), numeric=True),
                self._cell(tooltip),
            ])
        self.coefficient_model.set_rows(coefficient_rows)
        coefficient_table.resizeColumnToContents(0)
        coefficient_table.setColumnWidth(0, min(
            int(coefficient_table.property("termColumnMaximumWidth")),
            max(int(coefficient_table.property("termColumnMinimumWidth")), coefficient_table.columnWidth(0))))
        notes = list(self.summary.get("notes", []))
        references = self.summary.get("category_references", {})
        if references:
            notes.append(self.ui.notesTextEdit.property("categoryReferencesText").format(
                values=" · ".join(f"{name}={value}" for name, value in references.items())))
        for feature, scaling in self.summary.get("numeric_scaling", {}).items():
            notes.append(self.ui.notesTextEdit.property("numericScalingText").format(
                feature=feature, mean=_number(scaling.get("mean")), scale=_number(scaling.get("scale"))))
        self.ui.notesTextEdit.setPlainText("\n\n".join(notes))

    def _show_risks(self, *_):
        feature = self.ui.featureComboBox.currentData()
        table = self.ui.risksTableView
        rows = []
        for row in self._risks:
            if feature is not None and row.get("feature") != feature:
                continue
            conditions = []
            if row.get("conditions"):
                conditions.append(table.property("categoryConditionText").format(
                    values=" · ".join(f"{name}={value}" for name, value in row["conditions"].items())))
            if row.get("numeric_reference"):
                conditions.append(table.property("numericConditionText").format(
                    values=" · ".join(f"{name}={_number(value)}" for name, value in row["numeric_reference"].items())))
            condition_text = "; ".join(conditions) or table.property("noneText")
            error = row.get("interval_error")
            tooltip = table.property("intervalErrorText").format(error=error) if error else ""
            status = self._status(table, row.get("status"))
            support = self._status(table, "no_data" if row.get("status") == "no_data" else row.get("support_status"))
            rows.append([
                self._cell(row.get("feature")), self._cell(row.get("level")), self._cell(row.get("tsk_id")),
                self._cell(row.get("probability"), numeric=True, percent=True, tooltip=tooltip),
                self._cell(row.get("ci_lower"), numeric=True, percent=True, tooltip=tooltip),
                self._cell(row.get("ci_upper"), numeric=True, percent=True, tooltip=tooltip),
                self._cell(status, tooltip=tooltip), self._cell(support), self._cell(condition_text),
            ])
        self.risk_model.set_rows(rows)
