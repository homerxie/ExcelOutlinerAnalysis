"""Qt heatmaps and probability contrasts for an explicitly calculated slice."""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QPainter, QPen

from .tsk_plot import TskRiskPlot, _TskPlot, _percentage, _probability


def _finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def _points(value):
    return f"{100 * value:+.4f} pp" if _finite(value) else "—"


class TskCombinationHeatmap(_TskPlot):
    cell_selected = Signal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.levels = []
        self.type_ids = []
        self.display_metric = "probability"
        self._cells = []

    def set_view(self, view):
        self.rows = list((view or {}).get("rows", []))
        self.levels = list((view or {}).get("levels", []))
        self.type_ids = list(dict.fromkeys(str(row["tsk_id"]) for row in self.rows))
        self._cells = []
        self.setMinimumSize(max(0, 115 + 86 * len(self.levels)), max(160, 62 + 42 * len(self.type_ids)))
        self.update()

    def set_metric(self, metric):
        self.display_metric = metric
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            for region, row in self._cells:
                if region.contains(event.position()):
                    self.cell_selected.emit(str(row["tsk_id"]), str(row["level"]))
                    break
        super().mousePressEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions = []
        self._cells = []
        if not self.rows or not self.levels:
            self._empty(painter, colors)
            return
        left, top, row_height = 110., 37., 42.
        cell_width = max(86., (self.width() - left - 8) / len(self.levels))
        metrics = painter.fontMetrics()
        records = {(str(row["tsk_id"]), str(row["level"])): row for row in self.rows}
        values = [row.get(self.display_metric) if self.display_metric != "support" else row.get("active_instance_count")
                  for row in self.rows]
        maximum = max((float(value) for value in values if _finite(value)), default=0.) or 1.
        for column, level in enumerate(self.levels):
            painter.setPen(colors["ink"])
            painter.drawText(QRectF(left + column * cell_width + 3, 4, cell_width - 6, 28),
                             Qt.AlignCenter, metrics.elidedText(str(level), Qt.ElideRight, int(cell_width - 6)))
        for row_index, tsk_id in enumerate(self.type_ids):
            painter.setPen(colors["ink"])
            painter.drawText(QRectF(4, top + row_index * row_height, left - 12, row_height),
                             Qt.AlignRight | Qt.AlignVCenter, metrics.elidedText(tsk_id, Qt.ElideRight, int(left - 12)))
            for column, level in enumerate(self.levels):
                row = records.get((tsk_id, str(level)))
                region = QRectF(left + column * cell_width, top + row_index * row_height, cell_width - 3, row_height - 3)
                no_data = row is not None and row.get("status") == "no_data"
                value = None if row is None else row.get("active_instance_count") if self.display_metric == "support" else row.get("probability")
                valid = not no_data and (_finite(value) if self.display_metric == "support" else row is not None and row.get("identifiable", True) and _probability(value))
                fill = QColor(colors["grid"])
                fill.setAlpha(65)
                if no_data:
                    fill = QColor(colors["background"])
                elif valid:
                    fill = QColor(colors["series"])
                    fill.setAlpha(int(30 + 170 * max(0., min(1., float(value) / maximum))))
                painter.fillRect(region, fill)
                if no_data:
                    painter.setPen(QPen(colors["grid"], 1))
                    painter.drawRect(region)
                elif row and row.get("support_status") != "observed":
                    hatch = QColor(colors["muted"])
                    hatch.setAlpha(70)
                    painter.fillRect(region, QBrush(hatch, Qt.BDiagPattern))
                painter.setPen(colors["ink"])
                text = "" if no_data else f"{int(value)}" if valid and self.display_metric == "support" else f"{100 * value:.2f}%" if valid else "—"
                painter.drawText(region, Qt.AlignCenter, text)
                if row:
                    detail = str(self.property("tooltipFormat") or "{tsk_id} · {level}").format(
                        tsk_id=tsk_id, level=level,
                        probability=_percentage(row.get("probability")) if row.get("identifiable", True) else "—",
                        interval=f"{_percentage(row.get('ci_lower'))} – {_percentage(row.get('ci_upper'))}",
                        support=self.property("noDataSupportText") if no_data else row.get("support_status", "—"),
                        layout=row.get("layout_instance_count", 0),
                        active=row.get("active_instance_count", 0), chains=row.get("chain_count", 0),
                        exposure=row.get("chain_test_exposure", 0), interval_error=row.get("interval_error") or "—")
                    self._hit_regions.append((region, detail))
                    self._cells.append((region, row))


class TskDifferencePlot(TskRiskPlot):
    def set_rows(self, rows):
        super().set_rows([{**row, "label": row.get("label", row.get("level", ""))} for row in rows],
                         preserve_order=True)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        colors = self._colors()
        painter.fillRect(self.rect(), colors["background"])
        self._hit_regions = []
        self._label_regions = []
        if not self.rows:
            self._empty(painter, colors)
            return
        metrics = painter.fontMetrics()
        label_width = self._label_width
        value_width = max(70., metrics.horizontalAdvance("+100.00 pp") + 10)
        left, right, top = label_width + 6, self.width() - value_width - 8, 14.
        bottom = top + sum(self._row_heights)
        width = max(16., right - left)
        maximum = max(.01, max((abs(float(row[key])) for row in self.rows
                                for key in ("delta_probability", "delta_ci_lower", "delta_ci_upper")
                                if _finite(row.get(key))), default=0.) * 1.12)
        scale = lambda value: left + (value + maximum) / (2 * maximum) * width
        ticks = 2 if width < 230 else 4
        for index in range(ticks + 1):
            value = maximum * (2 * index / ticks - 1)
            x = scale(value)
            painter.setPen(QPen(colors["grid"], 1, Qt.DashLine if index == ticks // 2 else Qt.SolidLine))
            painter.drawLine(QPointF(x, top), QPointF(x, bottom))
            painter.setPen(colors["muted"])
            alignment = Qt.AlignLeft if index == 0 else Qt.AlignRight if index == ticks else Qt.AlignHCenter
            tick = QRectF(x if index == 0 else x - 55 if index == ticks else x - 27.5, bottom + 3, 55, 18)
            painter.drawText(tick, alignment | Qt.AlignVCenter, f"{100 * value:+.2f}")
        painter.setPen(colors["ink"])
        painter.drawText(QRectF(left - 8, bottom + 24, width + 16, 20), Qt.AlignCenter, str(self.property("axisLabel") or ""))
        row_top = top
        for index, row in enumerate(self.rows):
            row_height = self._row_heights[index]
            center = row_top + row_height / 2
            level = str(row.get("level", ""))
            painter.setPen(colors["ink"])
            self._draw_row_label(painter, index, str(row.get("label", level)), center)
            value, low, high = row.get("delta_probability"), row.get("delta_ci_lower"), row.get("delta_ci_upper")
            if _finite(value):
                painter.setPen(QPen(colors["ink"], 1.5))
                if _finite(low) and _finite(high):
                    painter.drawLine(QPointF(scale(low), center), QPointF(scale(high), center))
                    for bound in (low, high):
                        painter.drawLine(QPointF(scale(bound), center - 5), QPointF(scale(bound), center + 5))
                painter.setBrush(colors["series"])
                painter.setPen(QPen(colors["series"], 1))
                painter.drawEllipse(QPointF(scale(value), center), 4., 4.)
                painter.setPen(colors["ink"])
                painter.drawText(QRectF(right + 6, center - 10, value_width, 20), Qt.AlignLeft | Qt.AlignVCenter, f"{100 * value:+.3f}")
            else:
                painter.setPen(colors["muted"])
                text_property = ("noDataText" if row.get("status") == "no_data" else
                                 "referenceUnavailableText" if row.get("delta_status") == "no_data" else "unavailableText")
                painter.drawText(QRectF(left + 4, center - 11, self.width() - left - 8, 22), Qt.AlignLeft | Qt.AlignVCenter,
                                 str(self.property(text_property) or "") if text_property == "noDataText" else str(self.property(text_property) or "—"))
            detail = str(self.property("tooltipFormat") or "{level}: {delta}").format(
                level=level, delta=_points(value), interval=f"{_points(low)} – {_points(high)}", status=row.get("delta_status", ""),
                interval_error=row.get("delta_interval_error") or "—")
            self._hit_regions.append((QRectF(0, row_top, self.width(), row_height), detail))
            row_top += row_height
