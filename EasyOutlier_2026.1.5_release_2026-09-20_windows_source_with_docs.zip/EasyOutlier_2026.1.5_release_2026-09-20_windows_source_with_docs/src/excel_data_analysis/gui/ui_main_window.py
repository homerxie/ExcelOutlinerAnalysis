# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QDoubleSpinBox, QFrame, QGridLayout, QGroupBox,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMainWindow, QMenu,
    QMenuBar, QPlainTextEdit, QProgressBar, QPushButton,
    QScrollArea, QSizePolicy, QSpacerItem, QSplitter,
    QStatusBar, QTabWidget, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget)

from excel_data_analysis.gui.merge_controls import MergeControls

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1005, 612)
        self.actionSaveDatabase = QAction(MainWindow)
        self.actionSaveDatabase.setObjectName(u"actionSaveDatabase")
        self.actionSaveDatabaseAs = QAction(MainWindow)
        self.actionSaveDatabaseAs.setObjectName(u"actionSaveDatabaseAs")
        self.actionVerboseLogging = QAction(MainWindow)
        self.actionVerboseLogging.setObjectName(u"actionVerboseLogging")
        self.actionVerboseLogging.setCheckable(True)
        self.actionAboutEasyOutlier = QAction(MainWindow)
        self.actionAboutEasyOutlier.setObjectName(u"actionAboutEasyOutlier")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.templateEditBar = QFrame(self.centralwidget)
        self.templateEditBar.setObjectName(u"templateEditBar")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.templateEditBar.sizePolicy().hasHeightForWidth())
        self.templateEditBar.setSizePolicy(sizePolicy)
        self.templateEditBar.setFrameShape(QFrame.Shape.StyledPanel)
        self.templateEditBarLayout = QHBoxLayout(self.templateEditBar)
        self.templateEditBarLayout.setSpacing(12)
        self.templateEditBarLayout.setObjectName(u"templateEditBarLayout")
        self.templateEditStateLabel = QLabel(self.templateEditBar)
        self.templateEditStateLabel.setObjectName(u"templateEditStateLabel")
        font = QFont()
        font.setBold(True)
        self.templateEditStateLabel.setFont(font)

        self.templateEditBarLayout.addWidget(self.templateEditStateLabel)

        self.templateEditHintLabel = QLabel(self.templateEditBar)
        self.templateEditHintLabel.setObjectName(u"templateEditHintLabel")
        self.templateEditHintLabel.setWordWrap(True)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.templateEditHintLabel.sizePolicy().hasHeightForWidth())
        self.templateEditHintLabel.setSizePolicy(sizePolicy1)

        self.templateEditBarLayout.addWidget(self.templateEditHintLabel)

        self.templateEditToggleButton = QPushButton(self.templateEditBar)
        self.templateEditToggleButton.setObjectName(u"templateEditToggleButton")
        self.templateEditToggleButton.setCheckable(True)
        self.templateEditToggleButton.setChecked(False)
        self.templateEditToggleButton.setMinimumSize(QSize(110, 32))

        self.templateEditBarLayout.addWidget(self.templateEditToggleButton)


        self.verticalLayout.addWidget(self.templateEditBar)

        self.subHeaderLabel = QLabel(self.centralwidget)
        self.subHeaderLabel.setObjectName(u"subHeaderLabel")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.subHeaderLabel.sizePolicy().hasHeightForWidth())
        self.subHeaderLabel.setSizePolicy(sizePolicy2)
        font1 = QFont()
        font1.setBold(True)
        font1.setItalic(True)
        font1.setUnderline(True)
        self.subHeaderLabel.setFont(font1)
        self.subHeaderLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.subHeaderLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.subHeaderLabel)

        self.mainSplitter = QSplitter(self.centralwidget)
        self.mainSplitter.setObjectName(u"mainSplitter")
        self.mainSplitter.setOrientation(Qt.Orientation.Horizontal)
        self.leftPanel = QWidget(self.mainSplitter)
        self.leftPanel.setObjectName(u"leftPanel")
        self.leftPanelLayout = QVBoxLayout(self.leftPanel)
        self.leftPanelLayout.setObjectName(u"leftPanelLayout")
        self.leftPanelLayout.setContentsMargins(0, 0, 0, 0)
        self.workbenchTabWidget = QTabWidget(self.leftPanel)
        self.workbenchTabWidget.setObjectName(u"workbenchTabWidget")
        self.setupTab = QWidget()
        self.setupTab.setObjectName(u"setupTab")
        self.setupTabLayout = QVBoxLayout(self.setupTab)
        self.setupTabLayout.setObjectName(u"setupTabLayout")
        self.setupScrollArea = QScrollArea(self.setupTab)
        self.setupScrollArea.setObjectName(u"setupScrollArea")
        self.setupScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.setupScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setupScrollArea.setWidgetResizable(True)
        self.setupScrollAreaWidgetContents = QWidget()
        self.setupScrollAreaWidgetContents.setObjectName(u"setupScrollAreaWidgetContents")
        self.setupScrollAreaWidgetContents.setGeometry(QRect(0, 0, 604, 450))
        self.setupScrollContentLayout = QVBoxLayout(self.setupScrollAreaWidgetContents)
        self.setupScrollContentLayout.setObjectName(u"setupScrollContentLayout")
        self.pathsGroupBox = QGroupBox(self.setupScrollAreaWidgetContents)
        self.pathsGroupBox.setObjectName(u"pathsGroupBox")
        self.gridLayoutPaths = QGridLayout(self.pathsGroupBox)
        self.gridLayoutPaths.setSpacing(10)
        self.gridLayoutPaths.setObjectName(u"gridLayoutPaths")
        self.storagePathEdit = QLineEdit(self.pathsGroupBox)
        self.storagePathEdit.setObjectName(u"storagePathEdit")
        self.storagePathEdit.setReadOnly(True)

        self.gridLayoutPaths.addWidget(self.storagePathEdit, 0, 1, 1, 1)

        self.templatePathEdit = QLineEdit(self.pathsGroupBox)
        self.templatePathEdit.setObjectName(u"templatePathEdit")
        self.templatePathEdit.setReadOnly(True)

        self.gridLayoutPaths.addWidget(self.templatePathEdit, 1, 1, 1, 1)

        self.storageLabel = QLabel(self.pathsGroupBox)
        self.storageLabel.setObjectName(u"storageLabel")

        self.gridLayoutPaths.addWidget(self.storageLabel, 0, 0, 1, 1)

        self.templateLabel = QLabel(self.pathsGroupBox)
        self.templateLabel.setObjectName(u"templateLabel")

        self.gridLayoutPaths.addWidget(self.templateLabel, 1, 0, 1, 1)

        self.inputLabel = QLabel(self.pathsGroupBox)
        self.inputLabel.setObjectName(u"inputLabel")

        self.gridLayoutPaths.addWidget(self.inputLabel, 2, 0, 1, 1)

        self.inputPathEdit = QLineEdit(self.pathsGroupBox)
        self.inputPathEdit.setObjectName(u"inputPathEdit")
        self.inputPathEdit.setReadOnly(True)

        self.gridLayoutPaths.addWidget(self.inputPathEdit, 2, 1, 1, 1)

        self.storagePathButtonLayout = QHBoxLayout()
        self.storagePathButtonLayout.setSpacing(10)
        self.storagePathButtonLayout.setObjectName(u"storagePathButtonLayout")
        self.browseStorageButton = QPushButton(self.pathsGroupBox)
        self.browseStorageButton.setObjectName(u"browseStorageButton")

        self.storagePathButtonLayout.addWidget(self.browseStorageButton)

        self.openDatabaseButton = QPushButton(self.pathsGroupBox)
        self.openDatabaseButton.setObjectName(u"openDatabaseButton")

        self.storagePathButtonLayout.addWidget(self.openDatabaseButton)


        self.gridLayoutPaths.addLayout(self.storagePathButtonLayout, 0, 2, 1, 1)

        self.templatePathButtonLayout = QHBoxLayout()
        self.templatePathButtonLayout.setSpacing(10)
        self.templatePathButtonLayout.setObjectName(u"templatePathButtonLayout")
        self.browseTemplateButton = QPushButton(self.pathsGroupBox)
        self.browseTemplateButton.setObjectName(u"browseTemplateButton")

        self.templatePathButtonLayout.addWidget(self.browseTemplateButton)

        self.openTemplateButton = QPushButton(self.pathsGroupBox)
        self.openTemplateButton.setObjectName(u"openTemplateButton")

        self.templatePathButtonLayout.addWidget(self.openTemplateButton)


        self.gridLayoutPaths.addLayout(self.templatePathButtonLayout, 1, 2, 1, 1)

        self.inputPathButtonLayout = QHBoxLayout()
        self.inputPathButtonLayout.setSpacing(10)
        self.inputPathButtonLayout.setObjectName(u"inputPathButtonLayout")
        self.browseInputButton = QPushButton(self.pathsGroupBox)
        self.browseInputButton.setObjectName(u"browseInputButton")

        self.inputPathButtonLayout.addWidget(self.browseInputButton)

        self.openInputButton = QPushButton(self.pathsGroupBox)
        self.openInputButton.setObjectName(u"openInputButton")

        self.inputPathButtonLayout.addWidget(self.openInputButton)


        self.gridLayoutPaths.addLayout(self.inputPathButtonLayout, 2, 2, 1, 1)


        self.setupScrollContentLayout.addWidget(self.pathsGroupBox)

        self.templateToolsGroupBox = QGroupBox(self.setupScrollAreaWidgetContents)
        self.templateToolsGroupBox.setObjectName(u"templateToolsGroupBox")
        self.gridLayout_2 = QGridLayout(self.templateToolsGroupBox)
        self.gridLayout_2.setSpacing(10)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.exportTemplateJsonButton = QPushButton(self.templateToolsGroupBox)
        self.exportTemplateJsonButton.setObjectName(u"exportTemplateJsonButton")
        self.exportTemplateJsonButton.setEnabled(False)

        self.gridLayout_2.addWidget(self.exportTemplateJsonButton, 1, 0, 1, 1)

        self.exportTemplateExcelButton = QPushButton(self.templateToolsGroupBox)
        self.exportTemplateExcelButton.setObjectName(u"exportTemplateExcelButton")
        self.exportTemplateExcelButton.setEnabled(False)

        self.gridLayout_2.addWidget(self.exportTemplateExcelButton, 1, 1, 1, 1)

        self.validateTemplateButton = QPushButton(self.templateToolsGroupBox)
        self.validateTemplateButton.setObjectName(u"validateTemplateButton")

        self.gridLayout_2.addWidget(self.validateTemplateButton, 0, 0, 1, 2)

        self.saveDebugBundleButton = QPushButton(self.templateToolsGroupBox)
        self.saveDebugBundleButton.setObjectName(u"saveDebugBundleButton")

        self.gridLayout_2.addWidget(self.saveDebugBundleButton, 3, 0, 1, 2)


        self.setupScrollContentLayout.addWidget(self.templateToolsGroupBox)

        self.numericCleanupGroupBox = QGroupBox(self.setupScrollAreaWidgetContents)
        self.numericCleanupGroupBox.setObjectName(u"numericCleanupGroupBox")
        self.gridLayoutNumericCleanup = QGridLayout(self.numericCleanupGroupBox)
        self.gridLayoutNumericCleanup.setSpacing(10)
        self.gridLayoutNumericCleanup.setObjectName(u"gridLayoutNumericCleanup")
        self.numericCleanupCheckBox = QCheckBox(self.numericCleanupGroupBox)
        self.numericCleanupCheckBox.setObjectName(u"numericCleanupCheckBox")

        self.gridLayoutNumericCleanup.addWidget(self.numericCleanupCheckBox, 0, 0, 1, 3)

        self.numericCleanupModeLabel = QLabel(self.numericCleanupGroupBox)
        self.numericCleanupModeLabel.setObjectName(u"numericCleanupModeLabel")

        self.gridLayoutNumericCleanup.addWidget(self.numericCleanupModeLabel, 1, 0, 1, 1)

        self.numericCleanupModeComboBox = QComboBox(self.numericCleanupGroupBox)
        self.numericCleanupModeComboBox.addItem("")
        self.numericCleanupModeComboBox.addItem("")
        self.numericCleanupModeComboBox.setObjectName(u"numericCleanupModeComboBox")

        self.gridLayoutNumericCleanup.addWidget(self.numericCleanupModeComboBox, 1, 1, 1, 2)

        self.numericCleanupCharsLabel = QLabel(self.numericCleanupGroupBox)
        self.numericCleanupCharsLabel.setObjectName(u"numericCleanupCharsLabel")

        self.gridLayoutNumericCleanup.addWidget(self.numericCleanupCharsLabel, 2, 0, 1, 1)

        self.numericCleanupCharsEdit = QLineEdit(self.numericCleanupGroupBox)
        self.numericCleanupCharsEdit.setObjectName(u"numericCleanupCharsEdit")

        self.gridLayoutNumericCleanup.addWidget(self.numericCleanupCharsEdit, 2, 1, 1, 2)


        self.setupScrollContentLayout.addWidget(self.numericCleanupGroupBox)

        self.setupSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.setupScrollContentLayout.addItem(self.setupSpacer)

        self.setupScrollArea.setWidget(self.setupScrollAreaWidgetContents)

        self.setupTabLayout.addWidget(self.setupScrollArea)

        self.workbenchTabWidget.addTab(self.setupTab, "")
        self.importTab = QWidget()
        self.importTab.setObjectName(u"importTab")
        self.importTabLayout = QVBoxLayout(self.importTab)
        self.importTabLayout.setObjectName(u"importTabLayout")
        self.importScrollArea = QScrollArea(self.importTab)
        self.importScrollArea.setObjectName(u"importScrollArea")
        self.importScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.importScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.importScrollArea.setWidgetResizable(True)
        self.importScrollAreaWidgetContents = QWidget()
        self.importScrollAreaWidgetContents.setObjectName(u"importScrollAreaWidgetContents")
        self.importScrollAreaWidgetContents.setGeometry(QRect(0, 0, 604, 440))
        self.importScrollContentLayout = QVBoxLayout(self.importScrollAreaWidgetContents)
        self.importScrollContentLayout.setObjectName(u"importScrollContentLayout")
        self.importGroupBox = QGroupBox(self.importScrollAreaWidgetContents)
        self.importGroupBox.setObjectName(u"importGroupBox")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.importGroupBox.sizePolicy().hasHeightForWidth())
        self.importGroupBox.setSizePolicy(sizePolicy3)
        self.verticalLayoutImport = QVBoxLayout(self.importGroupBox)
        self.verticalLayoutImport.setSpacing(10)
        self.verticalLayoutImport.setObjectName(u"verticalLayoutImport")
        self.importButton = QPushButton(self.importGroupBox)
        self.importButton.setObjectName(u"importButton")

        self.verticalLayoutImport.addWidget(self.importButton)

        self.importHintLabel = QLabel(self.importGroupBox)
        self.importHintLabel.setObjectName(u"importHintLabel")
        self.importHintLabel.setWordWrap(True)

        self.verticalLayoutImport.addWidget(self.importHintLabel)


        self.importScrollContentLayout.addWidget(self.importGroupBox)

        self.storageOverviewGroupBox = QGroupBox(self.importScrollAreaWidgetContents)
        self.storageOverviewGroupBox.setObjectName(u"storageOverviewGroupBox")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(1)
        sizePolicy4.setHeightForWidth(self.storageOverviewGroupBox.sizePolicy().hasHeightForWidth())
        self.storageOverviewGroupBox.setSizePolicy(sizePolicy4)
        self.gridLayout = QGridLayout(self.storageOverviewGroupBox)
        self.gridLayout.setSpacing(10)
        self.gridLayout.setObjectName(u"gridLayout")
        self.refreshStorageViewButton = QPushButton(self.storageOverviewGroupBox)
        self.refreshStorageViewButton.setObjectName(u"refreshStorageViewButton")

        self.gridLayout.addWidget(self.refreshStorageViewButton, 0, 0, 1, 1)

        self.deleteSelectedRowsButton = QPushButton(self.storageOverviewGroupBox)
        self.deleteSelectedRowsButton.setObjectName(u"deleteSelectedRowsButton")

        self.gridLayout.addWidget(self.deleteSelectedRowsButton, 0, 1, 1, 1)

        self.storageSummaryLabel = QLabel(self.storageOverviewGroupBox)
        self.storageSummaryLabel.setObjectName(u"storageSummaryLabel")
        self.storageSummaryLabel.setWordWrap(True)

        self.gridLayout.addWidget(self.storageSummaryLabel, 2, 0, 1, 2)

        self.storageTableWidget = QTableWidget(self.storageOverviewGroupBox)
        if (self.storageTableWidget.columnCount() < 1):
            self.storageTableWidget.setColumnCount(1)
        __qtablewidgetitem = QTableWidgetItem()
        self.storageTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        self.storageTableWidget.setObjectName(u"storageTableWidget")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(1)
        sizePolicy5.setHeightForWidth(self.storageTableWidget.sizePolicy().hasHeightForWidth())
        self.storageTableWidget.setSizePolicy(sizePolicy5)
        self.storageTableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.storageTableWidget.setAlternatingRowColors(True)
        self.storageTableWidget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.storageTableWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.storageTableWidget.setSortingEnabled(True)

        self.gridLayout.addWidget(self.storageTableWidget, 3, 0, 1, 2)


        self.importScrollContentLayout.addWidget(self.storageOverviewGroupBox)

        self.importScrollArea.setWidget(self.importScrollAreaWidgetContents)

        self.importTabLayout.addWidget(self.importScrollArea)

        self.workbenchTabWidget.addTab(self.importTab, "")
        self.goldenTab = QWidget()
        self.goldenTab.setObjectName(u"goldenTab")
        self.goldenTabLayout = QVBoxLayout(self.goldenTab)
        self.goldenTabLayout.setObjectName(u"goldenTabLayout")
        self.goldenScrollArea = QScrollArea(self.goldenTab)
        self.goldenScrollArea.setObjectName(u"goldenScrollArea")
        self.goldenScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.goldenScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.goldenScrollArea.setWidgetResizable(True)
        self.goldenScrollAreaWidgetContents = QWidget()
        self.goldenScrollAreaWidgetContents.setObjectName(u"goldenScrollAreaWidgetContents")
        self.goldenScrollAreaWidgetContents.setGeometry(QRect(0, -126, 604, 566))
        self.goldenScrollContentLayout = QVBoxLayout(self.goldenScrollAreaWidgetContents)
        self.goldenScrollContentLayout.setObjectName(u"goldenScrollContentLayout")
        self.goldenGroupBox = QGroupBox(self.goldenScrollAreaWidgetContents)
        self.goldenGroupBox.setObjectName(u"goldenGroupBox")
        self.gridLayout_4 = QGridLayout(self.goldenGroupBox)
        self.gridLayout_4.setSpacing(10)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.goldenNameLabel = QLabel(self.goldenGroupBox)
        self.goldenNameLabel.setObjectName(u"goldenNameLabel")

        self.gridLayout_4.addWidget(self.goldenNameLabel, 0, 0, 1, 1)

        self.goldenNameEdit = QLineEdit(self.goldenGroupBox)
        self.goldenNameEdit.setObjectName(u"goldenNameEdit")

        self.gridLayout_4.addWidget(self.goldenNameEdit, 0, 1, 1, 1)

        self.referenceDimsLabel = QLabel(self.goldenGroupBox)
        self.referenceDimsLabel.setObjectName(u"referenceDimsLabel")

        self.gridLayout_4.addWidget(self.referenceDimsLabel, 1, 0, 1, 1)

        self.referenceDimsEdit = QLineEdit(self.goldenGroupBox)
        self.referenceDimsEdit.setObjectName(u"referenceDimsEdit")

        self.gridLayout_4.addWidget(self.referenceDimsEdit, 1, 1, 1, 1)

        self.filtersLabel = QLabel(self.goldenGroupBox)
        self.filtersLabel.setObjectName(u"filtersLabel")

        self.gridLayout_4.addWidget(self.filtersLabel, 2, 0, 1, 1)

        self.thresholdModeLabel = QLabel(self.goldenGroupBox)
        self.thresholdModeLabel.setObjectName(u"thresholdModeLabel")

        self.gridLayout_4.addWidget(self.thresholdModeLabel, 3, 0, 1, 1)

        self.centerMethodLabel = QLabel(self.goldenGroupBox)
        self.centerMethodLabel.setObjectName(u"centerMethodLabel")

        self.gridLayout_4.addWidget(self.centerMethodLabel, 4, 0, 1, 1)

        self.centerMethodComboBox = QComboBox(self.goldenGroupBox)
        self.centerMethodComboBox.addItem("")
        self.centerMethodComboBox.addItem("")
        self.centerMethodComboBox.setObjectName(u"centerMethodComboBox")

        self.gridLayout_4.addWidget(self.centerMethodComboBox, 4, 1, 1, 1)

        self.relativeLimitLabel = QLabel(self.goldenGroupBox)
        self.relativeLimitLabel.setObjectName(u"relativeLimitLabel")

        self.gridLayout_4.addWidget(self.relativeLimitLabel, 5, 0, 1, 1)

        self.relativeLimitSpinBox = QDoubleSpinBox(self.goldenGroupBox)
        self.relativeLimitSpinBox.setObjectName(u"relativeLimitSpinBox")
        self.relativeLimitSpinBox.setMinimum(-1.000000000000000)
        self.relativeLimitSpinBox.setDecimals(4)
        self.relativeLimitSpinBox.setMaximum(999999999.000000000000000)
        self.relativeLimitSpinBox.setSingleStep(0.050000000000000)
        self.relativeLimitSpinBox.setValue(0.200000000000000)

        self.gridLayout_4.addWidget(self.relativeLimitSpinBox, 5, 1, 1, 1)

        self.sigmaMultiplierLabel = QLabel(self.goldenGroupBox)
        self.sigmaMultiplierLabel.setObjectName(u"sigmaMultiplierLabel")

        self.gridLayout_4.addWidget(self.sigmaMultiplierLabel, 6, 0, 1, 1)

        self.sigmaMultiplierSpinBox = QDoubleSpinBox(self.goldenGroupBox)
        self.sigmaMultiplierSpinBox.setObjectName(u"sigmaMultiplierSpinBox")
        self.sigmaMultiplierSpinBox.setMinimum(-1.000000000000000)
        self.sigmaMultiplierSpinBox.setDecimals(4)
        self.sigmaMultiplierSpinBox.setMaximum(999999999.000000000000000)
        self.sigmaMultiplierSpinBox.setSingleStep(0.500000000000000)
        self.sigmaMultiplierSpinBox.setValue(3.000000000000000)

        self.gridLayout_4.addWidget(self.sigmaMultiplierSpinBox, 6, 1, 1, 1)

        self.absoluteLowerBoundLabel = QLabel(self.goldenGroupBox)
        self.absoluteLowerBoundLabel.setObjectName(u"absoluteLowerBoundLabel")

        self.gridLayout_4.addWidget(self.absoluteLowerBoundLabel, 7, 0, 1, 1)

        self.absoluteLowerBoundEdit = QLineEdit(self.goldenGroupBox)
        self.absoluteLowerBoundEdit.setObjectName(u"absoluteLowerBoundEdit")

        self.gridLayout_4.addWidget(self.absoluteLowerBoundEdit, 7, 1, 1, 1)

        self.absoluteUpperBoundLabel = QLabel(self.goldenGroupBox)
        self.absoluteUpperBoundLabel.setObjectName(u"absoluteUpperBoundLabel")

        self.gridLayout_4.addWidget(self.absoluteUpperBoundLabel, 8, 0, 1, 1)

        self.absoluteUpperBoundEdit = QLineEdit(self.goldenGroupBox)
        self.absoluteUpperBoundEdit.setObjectName(u"absoluteUpperBoundEdit")

        self.gridLayout_4.addWidget(self.absoluteUpperBoundEdit, 8, 1, 1, 1)

        self.overwriteMinLabel = QLabel(self.goldenGroupBox)
        self.overwriteMinLabel.setObjectName(u"overwriteMinLabel")

        self.gridLayout_4.addWidget(self.overwriteMinLabel, 9, 0, 1, 1)

        self.overwriteMinEdit = QLineEdit(self.goldenGroupBox)
        self.overwriteMinEdit.setObjectName(u"overwriteMinEdit")

        self.gridLayout_4.addWidget(self.overwriteMinEdit, 9, 1, 1, 1)

        self.overwriteMaxLabel = QLabel(self.goldenGroupBox)
        self.overwriteMaxLabel.setObjectName(u"overwriteMaxLabel")

        self.gridLayout_4.addWidget(self.overwriteMaxLabel, 10, 0, 1, 1)

        self.overwriteMaxEdit = QLineEdit(self.goldenGroupBox)
        self.overwriteMaxEdit.setObjectName(u"overwriteMaxEdit")

        self.gridLayout_4.addWidget(self.overwriteMaxEdit, 10, 1, 1, 1)

        self.filtersEdit = QPlainTextEdit(self.goldenGroupBox)
        self.filtersEdit.setObjectName(u"filtersEdit")

        self.gridLayout_4.addWidget(self.filtersEdit, 2, 1, 1, 1)

        self.thresholdModeComboBox = QComboBox(self.goldenGroupBox)
        self.thresholdModeComboBox.addItem("")
        self.thresholdModeComboBox.addItem("")
        self.thresholdModeComboBox.addItem("")
        self.thresholdModeComboBox.addItem("")
        self.thresholdModeComboBox.addItem("")
        self.thresholdModeComboBox.addItem("")
        self.thresholdModeComboBox.setObjectName(u"thresholdModeComboBox")
        self.thresholdModeComboBox.setEditable(True)

        self.gridLayout_4.addWidget(self.thresholdModeComboBox, 3, 1, 1, 1)

        self.buildGoldenButton = QPushButton(self.goldenGroupBox)
        self.buildGoldenButton.setObjectName(u"buildGoldenButton")

        self.gridLayout_4.addWidget(self.buildGoldenButton, 13, 0, 1, 2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setSpacing(10)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.goldenPathLabel = QLabel(self.goldenGroupBox)
        self.goldenPathLabel.setObjectName(u"goldenPathLabel")

        self.horizontalLayout_3.addWidget(self.goldenPathLabel)

        self.goldenPathEdit = QLineEdit(self.goldenGroupBox)
        self.goldenPathEdit.setObjectName(u"goldenPathEdit")
        self.goldenPathEdit.setReadOnly(True)

        self.horizontalLayout_3.addWidget(self.goldenPathEdit)

        self.browseGoldenButton = QPushButton(self.goldenGroupBox)
        self.browseGoldenButton.setObjectName(u"browseGoldenButton")

        self.horizontalLayout_3.addWidget(self.browseGoldenButton)

        self.openGoldenButton = QPushButton(self.goldenGroupBox)
        self.openGoldenButton.setObjectName(u"openGoldenButton")

        self.horizontalLayout_3.addWidget(self.openGoldenButton)


        self.gridLayout_4.addLayout(self.horizontalLayout_3, 14, 0, 1, 2)

        self.continuousIntervalCheckBox = QCheckBox(self.goldenGroupBox)
        self.continuousIntervalCheckBox.setObjectName(u"continuousIntervalCheckBox")

        self.gridLayout_4.addWidget(self.continuousIntervalCheckBox, 11, 0, 1, 2)

        self.emptyRangeFallbackCheckBox = QCheckBox(self.goldenGroupBox)
        self.emptyRangeFallbackCheckBox.setObjectName(u"emptyRangeFallbackCheckBox")

        self.gridLayout_4.addWidget(self.emptyRangeFallbackCheckBox, 12, 0, 1, 2)


        self.goldenScrollContentLayout.addWidget(self.goldenGroupBox)

        self.goldenSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.goldenScrollContentLayout.addItem(self.goldenSpacer)

        self.goldenScrollArea.setWidget(self.goldenScrollAreaWidgetContents)

        self.goldenTabLayout.addWidget(self.goldenScrollArea)

        self.workbenchTabWidget.addTab(self.goldenTab, "")
        self.analysisTab = QWidget()
        self.analysisTab.setObjectName(u"analysisTab")
        self.analysisTabLayout = QVBoxLayout(self.analysisTab)
        self.analysisTabLayout.setObjectName(u"analysisTabLayout")
        self.analysisScrollArea = QScrollArea(self.analysisTab)
        self.analysisScrollArea.setObjectName(u"analysisScrollArea")
        self.analysisScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.analysisScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.analysisScrollArea.setWidgetResizable(True)
        self.analysisScrollAreaWidgetContents = QWidget()
        self.analysisScrollAreaWidgetContents.setObjectName(u"analysisScrollAreaWidgetContents")
        self.analysisScrollAreaWidgetContents.setGeometry(QRect(0, 0, 604, 578))
        self.analysisScrollContentLayout = QVBoxLayout(self.analysisScrollAreaWidgetContents)
        self.analysisScrollContentLayout.setObjectName(u"analysisScrollContentLayout")
        self.analysisGroupBox = QGroupBox(self.analysisScrollAreaWidgetContents)
        self.analysisGroupBox.setObjectName(u"analysisGroupBox")
        self.gridLayout_3 = QGridLayout(self.analysisGroupBox)
        self.gridLayout_3.setSpacing(10)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.uniqueSampleIdFieldsEditLabel = QLabel(self.analysisGroupBox)
        self.uniqueSampleIdFieldsEditLabel.setObjectName(u"uniqueSampleIdFieldsEditLabel")

        self.gridLayout_3.addWidget(self.uniqueSampleIdFieldsEditLabel, 0, 0, 1, 1)

        self.uniqueSampleIdFieldsEdit = QLineEdit(self.analysisGroupBox)
        self.uniqueSampleIdFieldsEdit.setObjectName(u"uniqueSampleIdFieldsEdit")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.uniqueSampleIdFieldsEdit.sizePolicy().hasHeightForWidth())
        self.uniqueSampleIdFieldsEdit.setSizePolicy(sizePolicy6)

        self.gridLayout_3.addWidget(self.uniqueSampleIdFieldsEdit, 0, 1, 1, 1)

        self.reliabilityNodeRowLevelComboBoxLabel = QLabel(self.analysisGroupBox)
        self.reliabilityNodeRowLevelComboBoxLabel.setObjectName(u"reliabilityNodeRowLevelComboBoxLabel")

        self.gridLayout_3.addWidget(self.reliabilityNodeRowLevelComboBoxLabel, 1, 0, 1, 1)

        self.reliabilityNodeRowLevelComboBox = QComboBox(self.analysisGroupBox)
        self.reliabilityNodeRowLevelComboBox.setObjectName(u"reliabilityNodeRowLevelComboBox")
        sizePolicy6.setHeightForWidth(self.reliabilityNodeRowLevelComboBox.sizePolicy().hasHeightForWidth())
        self.reliabilityNodeRowLevelComboBox.setSizePolicy(sizePolicy6)

        self.gridLayout_3.addWidget(self.reliabilityNodeRowLevelComboBox, 1, 1, 1, 1)

        self.chainColumnLevelComboBoxLabel = QLabel(self.analysisGroupBox)
        self.chainColumnLevelComboBoxLabel.setObjectName(u"chainColumnLevelComboBoxLabel")

        self.gridLayout_3.addWidget(self.chainColumnLevelComboBoxLabel, 2, 0, 1, 1)

        self.chainColumnLevelComboBox = QComboBox(self.analysisGroupBox)
        self.chainColumnLevelComboBox.setObjectName(u"chainColumnLevelComboBox")
        sizePolicy6.setHeightForWidth(self.chainColumnLevelComboBox.sizePolicy().hasHeightForWidth())
        self.chainColumnLevelComboBox.setSizePolicy(sizePolicy6)

        self.gridLayout_3.addWidget(self.chainColumnLevelComboBox, 2, 1, 1, 1)

        self.outlierMergeControls = MergeControls(self.analysisGroupBox)
        self.outlierMergeControls.setObjectName(u"outlierMergeControls")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.outlierMergeControls.sizePolicy().hasHeightForWidth())
        self.outlierMergeControls.setSizePolicy(sizePolicy7)

        self.gridLayout_3.addWidget(self.outlierMergeControls, 6, 0, 1, 2)

        self.outlierMergeOrderComboBox = QComboBox(self.analysisGroupBox)
        self.outlierMergeOrderComboBox.addItem("")
        self.outlierMergeOrderComboBox.addItem("")
        self.outlierMergeOrderComboBox.addItem("")
        self.outlierMergeOrderComboBox.addItem("")
        self.outlierMergeOrderComboBox.addItem("")
        self.outlierMergeOrderComboBox.addItem("")
        self.outlierMergeOrderComboBox.setObjectName(u"outlierMergeOrderComboBox")

        self.gridLayout_3.addWidget(self.outlierMergeOrderComboBox, 5, 1, 1, 1)

        self.analysisNodesLabel = QLabel(self.analysisGroupBox)
        self.analysisNodesLabel.setObjectName(u"analysisNodesLabel")

        self.gridLayout_3.addWidget(self.analysisNodesLabel, 11, 0, 1, 1)

        self.zThresholdSpinBox = QDoubleSpinBox(self.analysisGroupBox)
        self.zThresholdSpinBox.setObjectName(u"zThresholdSpinBox")
        self.zThresholdSpinBox.setDecimals(3)
        self.zThresholdSpinBox.setMinimum(0.001000000000000)
        self.zThresholdSpinBox.setMaximum(999.000000000000000)
        self.zThresholdSpinBox.setSingleStep(0.100000000000000)
        self.zThresholdSpinBox.setValue(3.500000000000000)

        self.gridLayout_3.addWidget(self.zThresholdSpinBox, 4, 1, 1, 1)

        self.analysisImportsLabel = QLabel(self.analysisGroupBox)
        self.analysisImportsLabel.setObjectName(u"analysisImportsLabel")

        self.gridLayout_3.addWidget(self.analysisImportsLabel, 15, 0, 1, 1)

        self.analysisScopeComboBox = QComboBox(self.analysisGroupBox)
        self.analysisScopeComboBox.addItem("")
        self.analysisScopeComboBox.addItem("")
        self.analysisScopeComboBox.setObjectName(u"analysisScopeComboBox")

        self.gridLayout_3.addWidget(self.analysisScopeComboBox, 8, 1, 1, 1)

        self.zThresholdLabel = QLabel(self.analysisGroupBox)
        self.zThresholdLabel.setObjectName(u"zThresholdLabel")

        self.gridLayout_3.addWidget(self.zThresholdLabel, 4, 0, 1, 1)

        self.analysisExcludeNodesLabel = QLabel(self.analysisGroupBox)
        self.analysisExcludeNodesLabel.setObjectName(u"analysisExcludeNodesLabel")

        self.gridLayout_3.addWidget(self.analysisExcludeNodesLabel, 12, 0, 1, 1)

        self.runAnalysisButton = QPushButton(self.analysisGroupBox)
        self.runAnalysisButton.setObjectName(u"runAnalysisButton")

        self.gridLayout_3.addWidget(self.runAnalysisButton, 18, 0, 1, 2)

        self.openPlotInspectorButton = QPushButton(self.analysisGroupBox)
        self.openPlotInspectorButton.setObjectName(u"openPlotInspectorButton")

        self.gridLayout_3.addWidget(self.openPlotInspectorButton, 19, 0, 1, 2)

        self.analysisTestsLabel = QLabel(self.analysisGroupBox)
        self.analysisTestsLabel.setObjectName(u"analysisTestsLabel")

        self.gridLayout_3.addWidget(self.analysisTestsLabel, 13, 0, 1, 1)

        self.analysisTestsEdit = QLineEdit(self.analysisGroupBox)
        self.analysisTestsEdit.setObjectName(u"analysisTestsEdit")

        self.gridLayout_3.addWidget(self.analysisTestsEdit, 13, 1, 1, 1)

        self.outlierFailModeLabel = QLabel(self.analysisGroupBox)
        self.outlierFailModeLabel.setObjectName(u"outlierFailModeLabel")

        self.gridLayout_3.addWidget(self.outlierFailModeLabel, 3, 0, 1, 1)

        self.analysisExcludeNodesEdit = QLineEdit(self.analysisGroupBox)
        self.analysisExcludeNodesEdit.setObjectName(u"analysisExcludeNodesEdit")

        self.gridLayout_3.addWidget(self.analysisExcludeNodesEdit, 12, 1, 1, 1)

        self.analysisExcludeTestsEdit = QLineEdit(self.analysisGroupBox)
        self.analysisExcludeTestsEdit.setObjectName(u"analysisExcludeTestsEdit")

        self.gridLayout_3.addWidget(self.analysisExcludeTestsEdit, 14, 1, 1, 1)

        self.analysisNodesEdit = QLineEdit(self.analysisGroupBox)
        self.analysisNodesEdit.setObjectName(u"analysisNodesEdit")

        self.gridLayout_3.addWidget(self.analysisNodesEdit, 11, 1, 1, 1)

        self.analysisSampleIdsEdit = QLineEdit(self.analysisGroupBox)
        self.analysisSampleIdsEdit.setObjectName(u"analysisSampleIdsEdit")

        self.gridLayout_3.addWidget(self.analysisSampleIdsEdit, 9, 1, 1, 1)

        self.analysisExcludeSampleIdsEdit = QLineEdit(self.analysisGroupBox)
        self.analysisExcludeSampleIdsEdit.setObjectName(u"analysisExcludeSampleIdsEdit")

        self.gridLayout_3.addWidget(self.analysisExcludeSampleIdsEdit, 10, 1, 1, 1)

        self.analysisScopeLabel = QLabel(self.analysisGroupBox)
        self.analysisScopeLabel.setObjectName(u"analysisScopeLabel")

        self.gridLayout_3.addWidget(self.analysisScopeLabel, 8, 0, 1, 1)

        self.analysisExcludeTestsLabel = QLabel(self.analysisGroupBox)
        self.analysisExcludeTestsLabel.setObjectName(u"analysisExcludeTestsLabel")

        self.gridLayout_3.addWidget(self.analysisExcludeTestsLabel, 14, 0, 1, 1)

        self.outlierMergeOrderLabel = QLabel(self.analysisGroupBox)
        self.outlierMergeOrderLabel.setObjectName(u"outlierMergeOrderLabel")

        self.gridLayout_3.addWidget(self.outlierMergeOrderLabel, 5, 0, 1, 1)

        self.emptyCellsFailCheckBox = QCheckBox(self.analysisGroupBox)
        self.emptyCellsFailCheckBox.setObjectName(u"emptyCellsFailCheckBox")
        self.emptyCellsFailCheckBox.setChecked(True)

        self.gridLayout_3.addWidget(self.emptyCellsFailCheckBox, 7, 0, 1, 2)

        self.refreshAnalysisImportsButton = QPushButton(self.analysisGroupBox)
        self.refreshAnalysisImportsButton.setObjectName(u"refreshAnalysisImportsButton")

        self.gridLayout_3.addWidget(self.refreshAnalysisImportsButton, 15, 1, 1, 1)

        self.analysisImportsListWidget = QListWidget(self.analysisGroupBox)
        self.analysisImportsListWidget.setObjectName(u"analysisImportsListWidget")

        self.gridLayout_3.addWidget(self.analysisImportsListWidget, 16, 0, 1, 2)

        self.analysisSampleIdsLabel = QLabel(self.analysisGroupBox)
        self.analysisSampleIdsLabel.setObjectName(u"analysisSampleIdsLabel")

        self.gridLayout_3.addWidget(self.analysisSampleIdsLabel, 9, 0, 1, 1)

        self.outlierFailModeComboBox = QComboBox(self.analysisGroupBox)
        self.outlierFailModeComboBox.addItem("")
        self.outlierFailModeComboBox.addItem("")
        self.outlierFailModeComboBox.addItem("")
        self.outlierFailModeComboBox.addItem("")
        self.outlierFailModeComboBox.setObjectName(u"outlierFailModeComboBox")

        self.gridLayout_3.addWidget(self.outlierFailModeComboBox, 3, 1, 1, 1)

        self.analysisExcludeSampleIdsLabel = QLabel(self.analysisGroupBox)
        self.analysisExcludeSampleIdsLabel.setObjectName(u"analysisExcludeSampleIdsLabel")

        self.gridLayout_3.addWidget(self.analysisExcludeSampleIdsLabel, 10, 0, 1, 1)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setSpacing(10)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.outputLabel = QLabel(self.analysisGroupBox)
        self.outputLabel.setObjectName(u"outputLabel")

        self.horizontalLayout_2.addWidget(self.outputLabel)

        self.outputPathEdit = QLineEdit(self.analysisGroupBox)
        self.outputPathEdit.setObjectName(u"outputPathEdit")

        self.horizontalLayout_2.addWidget(self.outputPathEdit)

        self.browseOutputButton = QPushButton(self.analysisGroupBox)
        self.browseOutputButton.setObjectName(u"browseOutputButton")

        self.horizontalLayout_2.addWidget(self.browseOutputButton)

        self.openResultButton = QPushButton(self.analysisGroupBox)
        self.openResultButton.setObjectName(u"openResultButton")

        self.horizontalLayout_2.addWidget(self.openResultButton)


        self.gridLayout_3.addLayout(self.horizontalLayout_2, 17, 0, 1, 2)

        self.gridLayout_3.setColumnStretch(1, 1)

        self.analysisScrollContentLayout.addWidget(self.analysisGroupBox)

        self.analysisSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.analysisScrollContentLayout.addItem(self.analysisSpacer)

        self.analysisScrollArea.setWidget(self.analysisScrollAreaWidgetContents)

        self.analysisTabLayout.addWidget(self.analysisScrollArea)

        self.workbenchTabWidget.addTab(self.analysisTab, "")

        self.leftPanelLayout.addWidget(self.workbenchTabWidget)

        self.mainSplitter.addWidget(self.leftPanel)
        self.rightPanel = QWidget(self.mainSplitter)
        self.rightPanel.setObjectName(u"rightPanel")
        self.rightPanelLayout = QVBoxLayout(self.rightPanel)
        self.rightPanelLayout.setObjectName(u"rightPanelLayout")
        self.rightPanelLayout.setContentsMargins(0, 0, 0, 0)
        self.resultTabWidget = QTabWidget(self.rightPanel)
        self.resultTabWidget.setObjectName(u"resultTabWidget")
        self.goldenCoverageTab = QWidget()
        self.goldenCoverageTab.setObjectName(u"goldenCoverageTab")
        self.goldenCoverageTabLayout = QVBoxLayout(self.goldenCoverageTab)
        self.goldenCoverageTabLayout.setObjectName(u"goldenCoverageTabLayout")
        self.goldenCoverageSummaryLabel = QLabel(self.goldenCoverageTab)
        self.goldenCoverageSummaryLabel.setObjectName(u"goldenCoverageSummaryLabel")
        self.goldenCoverageSummaryLabel.setWordWrap(True)

        self.goldenCoverageTabLayout.addWidget(self.goldenCoverageSummaryLabel)

        self.goldenCoverageSummaryTableWidget = QTableWidget(self.goldenCoverageTab)
        if (self.goldenCoverageSummaryTableWidget.columnCount() < 1):
            self.goldenCoverageSummaryTableWidget.setColumnCount(1)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.goldenCoverageSummaryTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem1)
        self.goldenCoverageSummaryTableWidget.setObjectName(u"goldenCoverageSummaryTableWidget")
        self.goldenCoverageSummaryTableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.goldenCoverageSummaryTableWidget.setAlternatingRowColors(True)
        self.goldenCoverageSummaryTableWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.goldenCoverageSummaryTableWidget.setSortingEnabled(True)

        self.goldenCoverageTabLayout.addWidget(self.goldenCoverageSummaryTableWidget)

        self.goldenCoverageExamplesLabel = QLabel(self.goldenCoverageTab)
        self.goldenCoverageExamplesLabel.setObjectName(u"goldenCoverageExamplesLabel")

        self.goldenCoverageTabLayout.addWidget(self.goldenCoverageExamplesLabel)

        self.goldenCoverageExamplesTableWidget = QTableWidget(self.goldenCoverageTab)
        if (self.goldenCoverageExamplesTableWidget.columnCount() < 1):
            self.goldenCoverageExamplesTableWidget.setColumnCount(1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.goldenCoverageExamplesTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem2)
        self.goldenCoverageExamplesTableWidget.setObjectName(u"goldenCoverageExamplesTableWidget")
        self.goldenCoverageExamplesTableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.goldenCoverageExamplesTableWidget.setAlternatingRowColors(True)
        self.goldenCoverageExamplesTableWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.goldenCoverageExamplesTableWidget.setSortingEnabled(True)

        self.goldenCoverageTabLayout.addWidget(self.goldenCoverageExamplesTableWidget)

        self.resultTabWidget.addTab(self.goldenCoverageTab, "")
        self.outlierSummaryTab = QWidget()
        self.outlierSummaryTab.setObjectName(u"outlierSummaryTab")
        self.outlierSummaryTabLayout = QVBoxLayout(self.outlierSummaryTab)
        self.outlierSummaryTabLayout.setObjectName(u"outlierSummaryTabLayout")
        self.outlierSummaryLabel = QLabel(self.outlierSummaryTab)
        self.outlierSummaryLabel.setObjectName(u"outlierSummaryLabel")
        self.outlierSummaryLabel.setWordWrap(True)

        self.outlierSummaryTabLayout.addWidget(self.outlierSummaryLabel)

        self.outlierSummaryTableWidget = QTableWidget(self.outlierSummaryTab)
        if (self.outlierSummaryTableWidget.columnCount() < 1):
            self.outlierSummaryTableWidget.setColumnCount(1)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.outlierSummaryTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem3)
        self.outlierSummaryTableWidget.setObjectName(u"outlierSummaryTableWidget")
        self.outlierSummaryTableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.outlierSummaryTableWidget.setAlternatingRowColors(True)
        self.outlierSummaryTableWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.outlierSummaryTableWidget.setSortingEnabled(True)

        self.outlierSummaryTabLayout.addWidget(self.outlierSummaryTableWidget)

        self.outlierRatioSummaryLabel = QLabel(self.outlierSummaryTab)
        self.outlierRatioSummaryLabel.setObjectName(u"outlierRatioSummaryLabel")
        self.outlierRatioSummaryLabel.setWordWrap(True)

        self.outlierSummaryTabLayout.addWidget(self.outlierRatioSummaryLabel)

        self.outlierRatioTableWidget = QTableWidget(self.outlierSummaryTab)
        if (self.outlierRatioTableWidget.columnCount() < 1):
            self.outlierRatioTableWidget.setColumnCount(1)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.outlierRatioTableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem4)
        self.outlierRatioTableWidget.setObjectName(u"outlierRatioTableWidget")
        self.outlierRatioTableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.outlierRatioTableWidget.setAlternatingRowColors(True)
        self.outlierRatioTableWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.outlierRatioTableWidget.setSortingEnabled(True)

        self.outlierSummaryTabLayout.addWidget(self.outlierRatioTableWidget)

        self.resultTabWidget.addTab(self.outlierSummaryTab, "")
        self.logTab = QWidget()
        self.logTab.setObjectName(u"logTab")
        self.logTabLayout = QVBoxLayout(self.logTab)
        self.logTabLayout.setObjectName(u"logTabLayout")
        self.logPlainTextEdit = QPlainTextEdit(self.logTab)
        self.logPlainTextEdit.setObjectName(u"logPlainTextEdit")
        self.logPlainTextEdit.setReadOnly(True)

        self.logTabLayout.addWidget(self.logPlainTextEdit)

        self.resultTabWidget.addTab(self.logTab, "")

        self.rightPanelLayout.addWidget(self.resultTabWidget)

        self.mainSplitter.addWidget(self.rightPanel)

        self.verticalLayout.addWidget(self.mainSplitter)

        self.verticalLayout.setStretch(2, 1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1005, 33))
        self.menuDatabase = QMenu(self.menubar)
        self.menuDatabase.setObjectName(u"menuDatabase")
        self.menuDebug = QMenu(self.menubar)
        self.menuDebug.setObjectName(u"menuDebug")
        self.menuHelp = QMenu(self.menubar)
        self.menuHelp.setObjectName(u"menuHelp")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        self.taskProgressBar = QProgressBar(self.statusbar)
        self.taskProgressBar.setObjectName(u"taskProgressBar")
        self.taskProgressBar.setMinimumSize(QSize(220, 0))
        self.taskProgressBar.setValue(0)
        self.taskProgressBar.setVisible(False)
        self.cancelTaskButton = QPushButton(self.statusbar)
        self.cancelTaskButton.setObjectName(u"cancelTaskButton")
        self.cancelTaskButton.setVisible(False)
        MainWindow.setStatusBar(self.statusbar)

        self.menubar.addAction(self.menuDatabase.menuAction())
        self.menubar.addAction(self.menuDebug.menuAction())
        self.menubar.addAction(self.menuHelp.menuAction())
        self.menuDatabase.addAction(self.actionSaveDatabase)
        self.menuDatabase.addAction(self.actionSaveDatabaseAs)
        self.menuDebug.addAction(self.actionVerboseLogging)
        self.menuHelp.addAction(self.actionAboutEasyOutlier)

        self.retranslateUi(MainWindow)

        self.workbenchTabWidget.setCurrentIndex(0)
        self.resultTabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Easy Outlier", None))
        self.actionSaveDatabase.setText(QCoreApplication.translate("MainWindow", u"Save Database", None))
        self.actionSaveDatabaseAs.setText(QCoreApplication.translate("MainWindow", u"Save Database As", None))
        self.actionVerboseLogging.setText(QCoreApplication.translate("MainWindow", u"Verbose Logging", None))
        self.actionAboutEasyOutlier.setText(QCoreApplication.translate("MainWindow", u"About Easy Outlier", None))
        self.templateEditStateLabel.setText(QCoreApplication.translate("MainWindow", u"\U0001f512 \U00006a21\U0000677f\U00008bbe\U00007f6e\U00005df2\U00009501\U00005b9a", None))
        self.templateEditStateLabel.setProperty(u"lockedText", QCoreApplication.translate("MainWindow", u"\U0001f512 \U00006a21\U0000677f\U00008bbe\U00007f6e\U00005df2\U00009501\U00005b9a", None))
        self.templateEditStateLabel.setProperty(u"unlockedText", QCoreApplication.translate("MainWindow", u"\U0001f513 \U00006b63\U00005728\U00007f16\U00008f91\U00006a21\U0000677f\U00008bbe\U00007f6e", None))
        self.templateEditHintLabel.setText(QCoreApplication.translate("MainWindow", u"\u9700\u8981\u4fee\u6539\u53c2\u6570\u65f6\u89e3\u9501\uff1bImport / Build Golden / Analyze \u4f1a\u81ea\u52a8\u9501\u56de\u3002", None))
        self.templateEditToggleButton.setText(QCoreApplication.translate("MainWindow", u"\u89e3\u9501\u7f16\u8f91", None))
        self.templateEditToggleButton.setProperty(u"lockedText", QCoreApplication.translate("MainWindow", u"\u89e3\u9501\u7f16\u8f91", None))
        self.templateEditToggleButton.setProperty(u"unlockedText", QCoreApplication.translate("MainWindow", u"\u9501\u5b9a\u8bbe\u7f6e", None))
#if QT_CONFIG(tooltip)
        self.templateEditToggleButton.setToolTip(QCoreApplication.translate("MainWindow", u"\u5f00\u542f\u540e\u53ef\u7f16\u8f91\u6a21\u677f\u76f8\u5173\u53c2\u6570\uff1b\u9501\u56de\u4f1a\u4fdd\u7559\u5f53\u524d\u4fee\u6539\uff0c\u662f\u5426\u4fdd\u5b58\u5230\u6a21\u677f\u4ecd\u5728\u8fd0\u884c\u65f6\u9009\u62e9\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.templateEditToggleButton.setStyleSheet(QCoreApplication.translate("MainWindow", u"QPushButton:checked { background-color: #f4c46b; color: #342400; border: 1px solid #bb8425; border-radius: 5px; padding: 5px 12px; }", None))
        self.subHeaderLabel.setText(QCoreApplication.translate("MainWindow", u"\u6a21\u677f\u9a71\u52a8\u7684\u6d4b\u8bd5\u6570\u636e\u5f02\u5e38\u5206\u6790\u3001\u6bd4\u4f8b\u7edf\u8ba1\u4e0e\u62a5\u8868\u8f93\u51fa\u5de5\u5177\u3002", None))
        self.pathsGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"1. Paths", None))
        self.storageLabel.setText(QCoreApplication.translate("MainWindow", u"Database Folder", None))
        self.templateLabel.setText(QCoreApplication.translate("MainWindow", u"Template File", None))
        self.inputLabel.setText(QCoreApplication.translate("MainWindow", u"Input Excel/CSV", None))
        self.browseStorageButton.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.openDatabaseButton.setText(QCoreApplication.translate("MainWindow", u"Open Folder", None))
        self.browseTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.openTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Open File", None))
        self.browseInputButton.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.openInputButton.setText(QCoreApplication.translate("MainWindow", u"Open File", None))
        self.templateToolsGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"1.1 Template Tools", None))
        self.exportTemplateJsonButton.setText(QCoreApplication.translate("MainWindow", u"Convert Template: JSON -> XLSX", None))
        self.exportTemplateExcelButton.setText(QCoreApplication.translate("MainWindow", u"Convert Template: XLSX -> JSON", None))
        self.validateTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Validate Template", None))
        self.saveDebugBundleButton.setText(QCoreApplication.translate("MainWindow", u"Save Debug Bundle", None))
        self.numericCleanupGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"1.2 Numeric Parsing", None))
        self.numericCleanupCheckBox.setText(QCoreApplication.translate("MainWindow", u"Enable Numeric Text Cleanup", None))
        self.numericCleanupModeLabel.setText(QCoreApplication.translate("MainWindow", u"Cleanup Mode", None))
        self.numericCleanupModeComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"Remove All Non-Numeric Characters", None))
        self.numericCleanupModeComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Remove Specified Characters", None))

        self.numericCleanupCharsLabel.setText(QCoreApplication.translate("MainWindow", u"Characters To Remove", None))
        self.numericCleanupCharsEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u",;%;Ohm;V", None))
        self.workbenchTabWidget.setTabText(self.workbenchTabWidget.indexOf(self.setupTab), QCoreApplication.translate("MainWindow", u"Setup", None))
        self.importGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"2. Import", None))
        self.importButton.setText(QCoreApplication.translate("MainWindow", u"Import Dataset Into Current Database", None))
        self.importHintLabel.setText(QCoreApplication.translate("MainWindow", u"\u628a\u5f53\u524d\u6587\u4ef6\u6309\u6a21\u677f\u62c6\u6210 measurement\uff0c\u5e76\u5199\u5165\u5f53\u524d\u6570\u636e\u5e93\u3002\u82e5\u548c\u5df2\u6709 sample/node/site \u7b49\u5c5e\u6027\u51b2\u7a81\uff0c\u5bfc\u5165\u524d\u4f1a\u5148\u8be2\u95ee Replace \u8fd8\u662f Append\u3002", None))
        self.storageOverviewGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"2.1 Current Database Snapshot", None))
        self.refreshStorageViewButton.setText(QCoreApplication.translate("MainWindow", u"Refresh Current Database View", None))
        self.deleteSelectedRowsButton.setText(QCoreApplication.translate("MainWindow", u"Delete Selected Database Rows", None))
        self.storageSummaryLabel.setText(QCoreApplication.translate("MainWindow", u"No database loaded yet.", None))
        ___qtablewidgetitem = self.storageTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"Current Database Rows", None))
        self.workbenchTabWidget.setTabText(self.workbenchTabWidget.indexOf(self.importTab), QCoreApplication.translate("MainWindow", u"Import", None))
        self.goldenGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"3. Build Golden Reference", None))
        self.goldenNameLabel.setText(QCoreApplication.translate("MainWindow", u"Golden Name", None))
        self.referenceDimsLabel.setText(QCoreApplication.translate("MainWindow", u"Reference Dims", None))
        self.referenceDimsEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"sample_id,reliability_node", None))
        self.filtersLabel.setText(QCoreApplication.translate("MainWindow", u"Filters", None))
        self.thresholdModeLabel.setText(QCoreApplication.translate("MainWindow", u"Outlier Golden Method", None))
        self.centerMethodLabel.setText(QCoreApplication.translate("MainWindow", u"Golden Center", None))
        self.centerMethodComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"mean", None))
        self.centerMethodComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"median", None))

        self.relativeLimitLabel.setText(QCoreApplication.translate("MainWindow", u"Relative Limit", None))
        self.relativeLimitSpinBox.setSpecialValueText(QCoreApplication.translate("MainWindow", u"\u672a\u8bbe\u7f6e", None))
        self.sigmaMultiplierLabel.setText(QCoreApplication.translate("MainWindow", u"Sigma Multiplier", None))
        self.sigmaMultiplierSpinBox.setSpecialValueText(QCoreApplication.translate("MainWindow", u"\u672a\u8bbe\u7f6e", None))
        self.absoluteLowerBoundLabel.setText(QCoreApplication.translate("MainWindow", u"Absolute Lower Bound", None))
        self.absoluteLowerBoundEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Optional when method uses absolute", None))
        self.absoluteUpperBoundLabel.setText(QCoreApplication.translate("MainWindow", u"Absolute Upper Bound", None))
        self.absoluteUpperBoundEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Optional when method uses absolute", None))
        self.overwriteMinLabel.setText(QCoreApplication.translate("MainWindow", u"Overwrite Lower Bound", None))
        self.overwriteMinEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Optional when method uses overwrite_lowerbound", None))
        self.overwriteMaxLabel.setText(QCoreApplication.translate("MainWindow", u"Overwrite Upper Bound", None))
        self.overwriteMaxEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Optional when method uses overwrite_upperbound", None))
        self.filtersEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"\u4e00\u884c\u4e00\u4e2a key=value\n"
"\u540c\u4e00\u4e2a key \u53ef\u7528\u9017\u53f7\u5199\u591a\u4e2a\u503c\n"
"\u4f8b\u5982:\n"
"reliability_node=T0,T1", None))
        self.thresholdModeComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"relative", None))
        self.thresholdModeComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"sigma", None))
        self.thresholdModeComboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"absolute", None))
        self.thresholdModeComboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"relative and sigma", None))
        self.thresholdModeComboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"relative or (sigma and absolute)", None))
        self.thresholdModeComboBox.setItemText(5, QCoreApplication.translate("MainWindow", u"absolute or relative + overwrite_upperbound", None))

#if QT_CONFIG(tooltip)
        self.thresholdModeComboBox.setToolTip(QCoreApplication.translate("MainWindow", u"Enter any expression using relative, sigma, absolute, and, or, parentheses, plus optional suffix modifiers + overwrite_lowerbound / + overwrite_upperbound. The dropdown entries are only examples.", None))
#endif // QT_CONFIG(tooltip)
        self.buildGoldenButton.setText(QCoreApplication.translate("MainWindow", u"Build Golden", None))
        self.goldenPathLabel.setText(QCoreApplication.translate("MainWindow", u"Golden File", None))
        self.browseGoldenButton.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.openGoldenButton.setText(QCoreApplication.translate("MainWindow", u"Open File", None))
        self.continuousIntervalCheckBox.setText(QCoreApplication.translate("MainWindow", u"Use continuous Interval from min lower bound to max upper bound", None))
        self.emptyRangeFallbackCheckBox.setText(QCoreApplication.translate("MainWindow", u"Fallback empty allowed range to absolute bounds", None))
#if QT_CONFIG(tooltip)
        self.emptyRangeFallbackCheckBox.setToolTip(QCoreApplication.translate("MainWindow", u"When the configured golden rule produces no allowed interval, use Absolute Lower/Upper Bound if both are set and record a warning.", None))
#endif // QT_CONFIG(tooltip)
        self.workbenchTabWidget.setTabText(self.workbenchTabWidget.indexOf(self.goldenTab), QCoreApplication.translate("MainWindow", u"Golden", None))
        self.analysisGroupBox.setTitle(QCoreApplication.translate("MainWindow", u"4. Analyze And Export", None))
        self.uniqueSampleIdFieldsEditLabel.setText(QCoreApplication.translate("MainWindow", u"Unique Sample ID Fields", None))
        self.uniqueSampleIdFieldsEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"lot_id;sample_id", None))
#if QT_CONFIG(tooltip)
        self.uniqueSampleIdFieldsEdit.setToolTip(QCoreApplication.translate("MainWindow", u"\u7ec4\u6210\u6837\u54c1\u552f\u4e00 ID \u7684\u884c\u7ef4\u5ea6 Name\uff0c\u6309\u987a\u5e8f\u7528\u82f1\u6587\u5206\u53f7\u5206\u9694\u3002\u5305\u542b\u8282\u70b9\u4e0a\u65b9\u7684\u5168\u90e8\u7ef4\u5ea6\uff0c\u4e0d\u542b\u8282\u70b9\u53ca\u4e0b\u65b9\u5c42\u7ea7\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.reliabilityNodeRowLevelComboBoxLabel.setText(QCoreApplication.translate("MainWindow", u"Reliability Node Row Level", None))
#if QT_CONFIG(tooltip)
        self.reliabilityNodeRowLevelComboBox.setToolTip(QCoreApplication.translate("MainWindow", u"\u53ef\u9760\u6027\u8282\u70b9\u5bf9\u5e94\u7684\u884c\u8868\u5934\u5c42\u7ea7\uff0c\u4e5f\u662f Final row merge \u4fdd\u7559\u7684\u5c42\u7ea7\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.chainColumnLevelComboBoxLabel.setText(QCoreApplication.translate("MainWindow", u"Chain Column Level", None))
#if QT_CONFIG(tooltip)
        self.chainColumnLevelComboBox.setToolTip(QCoreApplication.translate("MainWindow", u"Chain \u5bf9\u5e94\u7684\u5217\u8868\u5934\u5c42\u7ea7\uff0c\u4e5f\u662f Final column merge \u4fdd\u7559\u7684\u5c42\u7ea7\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.outlierMergeOrderComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"column merge -> column group -> row merge -> row node", None))
        self.outlierMergeOrderComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"row merge -> row node -> column merge -> column group", None))
        self.outlierMergeOrderComboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"column merge -> row merge -> column group -> row node", None))
        self.outlierMergeOrderComboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"row merge -> column merge -> row node -> column group", None))
        self.outlierMergeOrderComboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"column merge -> row merge -> row node -> column group", None))
        self.outlierMergeOrderComboBox.setItemText(5, QCoreApplication.translate("MainWindow", u"row merge -> column merge -> column group -> row node", None))

        self.analysisNodesLabel.setText(QCoreApplication.translate("MainWindow", u"Include Nodes", None))
        self.analysisImportsLabel.setText(QCoreApplication.translate("MainWindow", u"Import History", None))
        self.analysisScopeComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"Entire Database", None))
        self.analysisScopeComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Selected Database", None))

        self.zThresholdLabel.setText(QCoreApplication.translate("MainWindow", u"Z Threshold", None))
        self.analysisExcludeNodesLabel.setText(QCoreApplication.translate("MainWindow", u"Exclude Nodes", None))
        self.runAnalysisButton.setText(QCoreApplication.translate("MainWindow", u"Run Analysis And Export Report", None))
        self.openPlotInspectorButton.setText(QCoreApplication.translate("MainWindow", u"Open Plot Inspector", None))
        self.analysisTestsLabel.setText(QCoreApplication.translate("MainWindow", u"Include Tests", None))
        self.analysisTestsEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Chain Name=Chain1,Chain2;Test Type=TestType1;id=TestType2_Chain2_1,TestType2_Chain2_2", None))
        self.outlierFailModeLabel.setText(QCoreApplication.translate("MainWindow", u"Outlier Criteria", None))
        self.analysisExcludeNodesEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"T3,T4", None))
        self.analysisExcludeTestsEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Chain Name=Chain1,Chain2;Test Type=TestType1;id=TestType2_Chain2_1,TestType2_Chain2_2", None))
        self.analysisNodesEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"T0,T1,T2", None))
        self.analysisSampleIdsEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"LotA:S001,S002;LotB:S003,S004", None))
        self.analysisExcludeSampleIdsEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"LotC:S003,S004;LotD:S005", None))
        self.analysisScopeLabel.setText(QCoreApplication.translate("MainWindow", u"Analysis Scope", None))
        self.analysisExcludeTestsLabel.setText(QCoreApplication.translate("MainWindow", u"Exclude Tests", None))
        self.outlierMergeOrderLabel.setText(QCoreApplication.translate("MainWindow", u"Merge Order", None))
#if QT_CONFIG(tooltip)
        self.emptyCellsFailCheckBox.setToolTip(QCoreApplication.translate("MainWindow", u"When enabled, expected test cells that are blank or non-numeric after numeric cleanup are treated as raw outlier failures. Empty cells never participate in golden calculation.", None))
#endif // QT_CONFIG(tooltip)
        self.emptyCellsFailCheckBox.setText(QCoreApplication.translate("MainWindow", u"Treat Empty/Non-Numeric Test Cells As Fail", None))
        self.refreshAnalysisImportsButton.setText(QCoreApplication.translate("MainWindow", u"Refresh Import List", None))
        self.analysisSampleIdsLabel.setText(QCoreApplication.translate("MainWindow", u"Include Sample Keys", None))
        self.outlierFailModeComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"Modified Z Score", None))
        self.outlierFailModeComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Golden Deviation", None))
        self.outlierFailModeComboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"Modified Z Score And Golden Deviation", None))
        self.outlierFailModeComboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"Modified Z Score Or Golden Deviation", None))

        self.analysisExcludeSampleIdsLabel.setText(QCoreApplication.translate("MainWindow", u"Exclude Sample Keys", None))
        self.outputLabel.setText(QCoreApplication.translate("MainWindow", u"Report Output File", None))
        self.browseOutputButton.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.openResultButton.setText(QCoreApplication.translate("MainWindow", u"Open Folder", None))
        self.workbenchTabWidget.setTabText(self.workbenchTabWidget.indexOf(self.analysisTab), QCoreApplication.translate("MainWindow", u"Analyze", None))
        self.goldenCoverageSummaryLabel.setText(QCoreApplication.translate("MainWindow", u"No built golden coverage checked yet.", None))
        ___qtablewidgetitem1 = self.goldenCoverageSummaryTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Scope", None))
        self.goldenCoverageExamplesLabel.setText(QCoreApplication.translate("MainWindow", u"Unmatched Examples", None))
        ___qtablewidgetitem2 = self.goldenCoverageExamplesTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Row", None))
        self.resultTabWidget.setTabText(self.resultTabWidget.indexOf(self.goldenCoverageTab), QCoreApplication.translate("MainWindow", u"Golden Coverage", None))
        self.outlierSummaryLabel.setText(QCoreApplication.translate("MainWindow", u"No outlier summary available yet.", None))
        ___qtablewidgetitem3 = self.outlierSummaryTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"SampleID", None))
        self.outlierRatioSummaryLabel.setText(QCoreApplication.translate("MainWindow", u"No outlier ratio statistics configured yet.", None))
        ___qtablewidgetitem4 = self.outlierRatioTableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"Stat ID", None))
        self.resultTabWidget.setTabText(self.resultTabWidget.indexOf(self.outlierSummaryTab), QCoreApplication.translate("MainWindow", u"Outlier Summary", None))
        self.resultTabWidget.setTabText(self.resultTabWidget.indexOf(self.logTab), QCoreApplication.translate("MainWindow", u"Log", None))
        self.menuDatabase.setTitle(QCoreApplication.translate("MainWindow", u"Database", None))
        self.menuDebug.setTitle(QCoreApplication.translate("MainWindow", u"Debug", None))
        self.menuHelp.setTitle(QCoreApplication.translate("MainWindow", u"Help", None))
        self.cancelTaskButton.setText(QCoreApplication.translate("MainWindow", u"Cancel Analysis", None))
    # retranslateUi

