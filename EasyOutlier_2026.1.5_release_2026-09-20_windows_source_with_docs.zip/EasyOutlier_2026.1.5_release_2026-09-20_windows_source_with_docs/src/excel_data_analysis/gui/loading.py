"""Background file loading. Worker closures never access Qt widgets."""
from copy import deepcopy
from math import isfinite
from pathlib import Path

from PySide6.QtWidgets import QDialog

from ..gui_paths import absolute_path, restore_paths
from ..gui_state import load_gui_state
from ..merge_config import MERGE_RULE_FIELDS, chain_level, same_level_rule_conflicts, validate_same_level_rules
from ..runtime import app_root, package_root
from ..service import (describe_storage, list_import_history, ensure_storage_workspace,
                       storage_workspace_differs, discard_storage_workspace_changes)
from ..template import load_template, validate_report_identity
from ..template_upgrade import upgrade_template_file, save_template_atomically
from .ui_merge_conflict_dialog import Ui_MergeConflictDialog
from .ui_workspace_recovery_dialog import Ui_WorkspaceRecoveryDialog


class LoadingMixin:
    @staticmethod
    def _saved_report_template(template, report_controls):
        selected = deepcopy(template)
        for name in ("sample_dimension_names", "reliability_node_dimension", "chain_column_level",
                     "initial_row_merge_level", "initial_column_merge_level", *MERGE_RULE_FIELDS.values()):
            if name in report_controls:
                setattr(selected.report, name, deepcopy(report_controls[name]))
        validate_report_identity(selected)
        return selected

    @classmethod
    def _validate_saved_settings(cls, payload, template):
        """Check saved values before committing the new database context to widgets."""
        golden = payload.get("golden", {})
        if isinstance(golden, dict):
            rule = golden.get("default_rule", golden)
            if not isinstance(rule, dict):
                raise ValueError("数据库 GUI 设置中的 Golden default_rule 格式无效。")
            for name in ("relative_limit", "sigma_multiplier"):
                if rule.get(name) is not None and not isfinite(float(rule[name])):
                    raise ValueError(f"数据库 GUI 设置中的 {name} 必须为有限数值。")
        analysis = payload.get("analysis", {})
        if isinstance(analysis, dict):
            if "z_threshold" in analysis and not isfinite(float(analysis["z_threshold"])):
                raise ValueError("数据库 GUI 设置中的 Z threshold 必须为有限数值。")
            if isinstance(analysis.get("report_controls"), dict):
                cls._saved_report_template(template, analysis["report_controls"])
            if "selected_dataset_ids" in analysis and not isinstance(analysis["selected_dataset_ids"], list):
                raise ValueError("数据库 GUI 设置中的 selected_dataset_ids 必须为列表。")
        state = payload.get("ui_state", {})
        if isinstance(state, dict) and isinstance(state.get("splitter_sizes"), list):
            for item in state["splitter_sizes"]:
                int(item)

    def _choose_same_level_rules(self, template, path):
        conflicts = same_level_rule_conflicts(template)
        if not conflicts:
            return template
        dialog = QDialog(self)
        ui = Ui_MergeConflictDialog()
        ui.setupUi(dialog)
        ui.pathLabel.setText(str(path))
        controls = {}
        for axis in ("row", "column"):
            conflict = next((c for c in conflicts if c["axis"] == axis), None)
            getattr(ui, axis + "Panel").setVisible(conflict is not None)
            if conflict is None:
                continue
            getattr(ui, axis + "DetailsLabel").setText(
                f"{axis}: {conflict['level']}  |  Initial: {conflict['initial_rule']}  |  Final: {conflict['final_rule']}"
            )
            combo = getattr(ui, axis + "RuleComboBox")
            combo.setItemData(1, "any_fail")
            combo.setItemData(2, "all_fail")
            controls[axis] = combo
            combo.currentIndexChanged.connect(
                lambda: ui.saveButton.setEnabled(all(c.currentData() for c in controls.values()))
            )
        if dialog.exec() != QDialog.Accepted:
            return None
        selected = deepcopy(template)
        for conflict in conflicts:
            rule = controls[conflict["axis"]].currentData()
            if rule not in {"any_fail", "all_fail"}:
                return None
            setattr(selected.report, conflict["initial_field"], rule)
            setattr(selected.report, conflict["final_field"], rule)
        validate_same_level_rules(selected)
        return selected

    def _decide_loaded_template(self, template, path):
        """Prompts on the GUI thread; persistence is a separate worker step."""
        selected = deepcopy(template)
        repair = False
        if selected.migration_required:
            accepted, repair = self._confirm_template_upgrade(selected)
            if not accepted:
                return None
            if repair:
                selected.report.initial_column_merge_level = chain_level(selected)
                selected.report.outlier_test_merge_max_level = None
        conflicts = same_level_rule_conflicts(selected)
        selected = self._choose_same_level_rules(selected, path)
        if selected is None:
            return None
        return selected, bool(template.migration_required or conflicts), repair

    @staticmethod
    def _persist_loaded_template(template, path, repair=False):
        if template.migration_required:
            path, _ = upgrade_template_file(path, template, repair_chain_boundary=repair)
        else:
            save_template_atomically(template, path)
        # Confirm the saved file, not an in-memory assumption, before applying it.
        return load_template(path), str(path)

    def _accept_loaded_template(self, template, path, ready):
        decision = self._decide_loaded_template(template, path)
        if decision is None:
            self.statusBar().showMessage("已取消加载，保留原配置。", 5000)
            return
        selected, write, repair = decision
        if write:
            def task(progress):
                progress(-1, "正在保存模板修正并重新读取…")
                return self._persist_loaded_template(selected, path, repair)
            self._start_background_task("保存模板修正", task, lambda result: ready(*result))
        else:
            ready(selected, path)

    def _load_template_async(self, path):
        storage = self._storage_path_for_read()
        def task(progress):
            progress(-1, "正在读取模板…")
            return load_template(path)
        def loaded(template):
            def accepted(selected, selected_path):
                def read_overview(progress):
                    progress(-1, "正在读取数据库概览…")
                    return (describe_storage(storage, template_path=selected_path, limit=500), list_import_history(storage)) if storage else (None, [])
                def finish(result):
                    overview, entries = result
                    self._apply_template_settings(selected, selected_path)
                    self.ui.templatePathEdit.setText(self._display_path(selected_path))
                    if overview is not None:
                        self._refresh_storage_overview(payload=overview, entries=entries)
                    self._set_template_edit_unlocked(False)
                    self.statusBar().showMessage("模板已加载，所有模板选项已刷新。", 5000)
                self._start_background_task("加载模板概览", read_overview, finish)
            self._accept_loaded_template(template, path, accepted)
        self._start_background_task("加载模板", task, loaded)

    def _choose_workspace_recovery(self, root, payload):
        dialog = QDialog(self)
        ui = Ui_WorkspaceRecoveryDialog()
        ui.setupUi(dialog)
        ui.pathsLabel.setText(f"Database: {root}\nWorkspace: {payload.get('workspace', '')}")
        ui.continueButton.clicked.connect(lambda: dialog.done(1))
        ui.discardButton.clicked.connect(lambda: dialog.done(2))
        ui.cancelButton.clicked.connect(dialog.reject)
        return {1: "continue", 2: "discard"}.get(dialog.exec(), "cancel")

    def _load_database_async(self, root):
        fallback_template = self._path_value(self.ui.templatePathEdit)
        application_root, package = app_root(), package_root()
        def prepare(progress):
            progress(-1, "正在准备数据库工作区…")
            existed = (Path(root) / "temp").exists()
            workspace = ensure_storage_workspace(root)
            progress(-1, "正在检查未保存的工作区…")
            recovery = storage_workspace_differs(root) if existed else {"differs": False}
            return workspace, recovery
        def prepared(result):
            workspace, recovery = result
            choice = self._choose_workspace_recovery(root, recovery) if recovery.get("differs") else "continue"
            if choice == "cancel":
                self.statusBar().showMessage("已取消打开数据库，保留原工作区。", 5000)
                return
            def read(progress):
                active = workspace
                if choice == "discard":
                    progress(-1, "正在按已保存数据库重建工作区…")
                    active = discard_storage_workspace_changes(root)
                storage = str(active["workspace"])
                progress(-1, "正在读取数据库设置…")
                settings = load_gui_state(root) or {}
                paths = restore_paths(settings, app=application_root, database=Path(root), package=package)
                template_path = str(absolute_path(paths.get("template_path") or fallback_template, application_root))
                progress(-1, "正在读取数据库关联模板…")
                template = load_template(template_path)
                progress(-1, "正在统计数据库并读取导入历史…")
                overview = describe_storage(storage, template_path=template_path, limit=500)
                entries = list_import_history(storage)
                return dict(storage=storage, settings=settings, paths=paths, template_path=template_path,
                            template=template, overview=overview, entries=entries)
            def loaded(data):
                def finish(template, selected_path):
                    self._validate_saved_settings(data["settings"], template)
                    self.ui.storagePathEdit.setText(self._display_path(root))
                    self.current_workspace_path = data["storage"]
                    paths = dict(data["paths"])
                    paths["template_path"] = selected_path
                    self._apply_persistent_gui_settings(
                        data["settings"], resolved_paths=paths, template=template, entries=data["entries"]
                    )
                    if not paths.get("output_path"):
                        self._refresh_default_output_path()
                    self._refresh_database_scoped_paths(root, root)
                    self._refresh_storage_overview(payload=data["overview"], entries=data["entries"])
                    self._set_template_edit_unlocked(False)
                    self.statusBar().showMessage("数据库与模板已加载。", 5000)
                self._accept_loaded_template(data["template"], data["template_path"], finish)
            self._start_background_task("读取数据库", read, loaded)
        self._start_background_task("打开数据库", prepare, prepared)
