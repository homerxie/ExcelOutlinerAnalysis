"""Template-driven Excel/CSV anomaly analysis toolkit."""

__all__ = ["__version__"]

__version__ = "2026.1.5"
