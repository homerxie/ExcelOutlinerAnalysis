# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tsk_results_panel.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QFrame, QHBoxLayout, QHeaderView, QLabel,
    QPlainTextEdit, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QSpinBox, QSplitter, QTableView,
    QToolButton, QVBoxLayout, QWidget)

from excel_data_analysis.gui.current_page_tabs import CurrentPageTabWidget
from excel_data_analysis.gui.tsk_combination_plot import TskCombinationHeatmap
from excel_data_analysis.gui.tsk_detail_panel import TskDetailPanel
from excel_data_analysis.gui.tsk_feature_effects_panel import TskFeatureEffectsPanel
from excel_data_analysis.gui.tsk_feature_panel import TskFeaturePanel
from excel_data_analysis.gui.tsk_heatmap_axis_selector import TskHeatmapAxisSelector
from excel_data_analysis.gui.tsk_joint_risk_panel import TskJointRiskPanel
from excel_data_analysis.gui.tsk_plot import (TskChainFitPlot, TskRiskPlot)

class Ui_TskResultsPanelForm(object):
    def setupUi(self, TskResultsPanelForm):
        if not TskResultsPanelForm.objectName():
            TskResultsPanelForm.setObjectName(u"TskResultsPanelForm")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(TskResultsPanelForm.sizePolicy().hasHeightForWidth())
        TskResultsPanelForm.setSizePolicy(sizePolicy)
        self.detailLayout = QVBoxLayout(TskResultsPanelForm)
        self.detailLayout.setObjectName(u"detailLayout")
        self.detailLayout.setContentsMargins(0, 0, 0, 0)
        self.resultsDetailSplitter = QSplitter(TskResultsPanelForm)
        self.resultsDetailSplitter.setObjectName(u"resultsDetailSplitter")
        self.resultsDetailSplitter.setOrientation(Qt.Orientation.Horizontal)
        self.resultsDetailSplitter.setChildrenCollapsible(False)
        self.resultsDetailSplitter.setHandleWidth(6)
        self.resultsDetailSplitter.setProperty(u"preferredDetailWidth", 340)
        self.resultsMain = QWidget(self.resultsDetailSplitter)
        self.resultsMain.setObjectName(u"resultsMain")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(1)
        sizePolicy1.setHeightForWidth(self.resultsMain.sizePolicy().hasHeightForWidth())
        self.resultsMain.setSizePolicy(sizePolicy1)
        self.panelLayout = QVBoxLayout(self.resultsMain)
        self.panelLayout.setSpacing(6)
        self.panelLayout.setObjectName(u"panelLayout")
        self.panelLayout.setContentsMargins(0, 0, 0, 0)
        self.selectionLayout = QHBoxLayout()
        self.selectionLayout.setSpacing(6)
        self.selectionLayout.setObjectName(u"selectionLayout")
        self.groupLabel = QLabel(self.resultsMain)
        self.groupLabel.setObjectName(u"groupLabel")

        self.selectionLayout.addWidget(self.groupLabel)

        self.groupComboBox = QComboBox(self.resultsMain)
        self.groupComboBox.setObjectName(u"groupComboBox")
        self.groupComboBox.setEnabled(False)
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(1)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.groupComboBox.sizePolicy().hasHeightForWidth())
        self.groupComboBox.setSizePolicy(sizePolicy2)
        self.groupComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.groupComboBox.setMinimumContentsLength(8)

        self.selectionLayout.addWidget(self.groupComboBox)

        self.detailToggleButton = QToolButton(self.resultsMain)
        self.detailToggleButton.setObjectName(u"detailToggleButton")
        self.detailToggleButton.setCheckable(True)
        self.detailToggleButton.setChecked(False)
        self.detailToggleButton.setEnabled(False)

        self.selectionLayout.addWidget(self.detailToggleButton)

        self.diagnosticsButton = QPushButton(self.resultsMain)
        self.diagnosticsButton.setObjectName(u"diagnosticsButton")
        self.diagnosticsButton.setEnabled(False)

        self.selectionLayout.addWidget(self.diagnosticsButton)

        self.exportButton = QPushButton(self.resultsMain)
        self.exportButton.setObjectName(u"exportButton")
        self.exportButton.setEnabled(False)

        self.selectionLayout.addWidget(self.exportButton)


        self.panelLayout.addLayout(self.selectionLayout)

        self.summaryStatusLayout = QHBoxLayout()
        self.summaryStatusLayout.setObjectName(u"summaryStatusLayout")
        self.compactSummaryLabel = QLabel(self.resultsMain)
        self.compactSummaryLabel.setObjectName(u"compactSummaryLabel")
        self.compactSummaryLabel.setWordWrap(True)
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.compactSummaryLabel.sizePolicy().hasHeightForWidth())
        self.compactSummaryLabel.setSizePolicy(sizePolicy3)

        self.summaryStatusLayout.addWidget(self.compactSummaryLabel)

        self.warningsLabel = QLabel(self.resultsMain)
        self.warningsLabel.setObjectName(u"warningsLabel")
        self.warningsLabel.setVisible(False)
        self.warningsLabel.setWordWrap(False)
        self.warningsLabel.setTextInteractionFlags(Qt.TextInteractionFlag.LinksAccessibleByMouse|Qt.TextInteractionFlag.LinksAccessibleByKeyboard)

        self.summaryStatusLayout.addWidget(self.warningsLabel)

        self.summaryDetailsButton = QToolButton(self.resultsMain)
        self.summaryDetailsButton.setObjectName(u"summaryDetailsButton")
        self.summaryDetailsButton.setCheckable(True)
        self.summaryDetailsButton.setEnabled(False)

        self.summaryStatusLayout.addWidget(self.summaryDetailsButton)


        self.panelLayout.addLayout(self.summaryStatusLayout)

        self.summaryDetailsWidget = QWidget(self.resultsMain)
        self.summaryDetailsWidget.setObjectName(u"summaryDetailsWidget")
        self.summaryDetailsWidget.setVisible(False)
        self.summaryDetailsLayout = QVBoxLayout(self.summaryDetailsWidget)
        self.summaryDetailsLayout.setObjectName(u"summaryDetailsLayout")
        self.summaryDetailsLayout.setContentsMargins(0, 0, 0, 0)
        self.summaryLabel = QLabel(self.summaryDetailsWidget)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)

        self.summaryDetailsLayout.addWidget(self.summaryLabel)


        self.panelLayout.addWidget(self.summaryDetailsWidget)

        self.detailsTabWidget = CurrentPageTabWidget(self.resultsMain)
        self.detailsTabWidget.setObjectName(u"detailsTabWidget")
        self.riskTab = QWidget()
        self.riskTab.setObjectName(u"riskTab")
        self.riskLayout = QVBoxLayout(self.riskTab)
        self.riskLayout.setSpacing(6)
        self.riskLayout.setObjectName(u"riskLayout")
        self.riskLayout.setContentsMargins(6, 6, 6, 6)
        self.riskReferenceLayout = QHBoxLayout()
        self.riskReferenceLayout.setObjectName(u"riskReferenceLayout")
        self.riskReferenceSummaryLabel = QLabel(self.riskTab)
        self.riskReferenceSummaryLabel.setObjectName(u"riskReferenceSummaryLabel")
        self.riskReferenceSummaryLabel.setWordWrap(True)
        sizePolicy3.setHeightForWidth(self.riskReferenceSummaryLabel.sizePolicy().hasHeightForWidth())
        self.riskReferenceSummaryLabel.setSizePolicy(sizePolicy3)

        self.riskReferenceLayout.addWidget(self.riskReferenceSummaryLabel)

        self.riskNoExtrapolationCheckBox = QCheckBox(self.riskTab)
        self.riskNoExtrapolationCheckBox.setObjectName(u"riskNoExtrapolationCheckBox")
        self.riskNoExtrapolationCheckBox.setChecked(True)
        self.riskNoExtrapolationCheckBox.setEnabled(False)
        self.riskNoExtrapolationCheckBox.setVisible(True)

        self.riskReferenceLayout.addWidget(self.riskNoExtrapolationCheckBox)

        self.riskHelpButton = QToolButton(self.riskTab)
        self.riskHelpButton.setObjectName(u"riskHelpButton")

        self.riskReferenceLayout.addWidget(self.riskHelpButton)


        self.riskLayout.addLayout(self.riskReferenceLayout)

        self.referenceLabel = QLabel(self.riskTab)
        self.referenceLabel.setObjectName(u"referenceLabel")
        self.referenceLabel.setWordWrap(True)
        self.referenceLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.referenceLabel.setVisible(False)

        self.riskLayout.addWidget(self.referenceLabel)

        self.riskCompletionHintLabel = QLabel(self.riskTab)
        self.riskCompletionHintLabel.setObjectName(u"riskCompletionHintLabel")
        self.riskCompletionHintLabel.setWordWrap(True)
        self.riskCompletionHintLabel.setVisible(False)

        self.riskLayout.addWidget(self.riskCompletionHintLabel)

        self.calculateFullCombinationButton = QPushButton(self.riskTab)
        self.calculateFullCombinationButton.setObjectName(u"calculateFullCombinationButton")
        self.calculateFullCombinationButton.setVisible(False)
        self.calculateFullCombinationButton.setEnabled(False)

        self.riskLayout.addWidget(self.calculateFullCombinationButton)

        self.riskCalculationStatusLabel = QLabel(self.riskTab)
        self.riskCalculationStatusLabel.setObjectName(u"riskCalculationStatusLabel")
        self.riskCalculationStatusLabel.setVisible(False)
        self.riskCalculationStatusLabel.setWordWrap(True)
        self.riskCalculationStatusLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.riskLayout.addWidget(self.riskCalculationStatusLabel)

        self.riskSortLayout = QHBoxLayout()
        self.riskSortLayout.setSpacing(6)
        self.riskSortLayout.setObjectName(u"riskSortLayout")
        self.riskSortLabel = QLabel(self.riskTab)
        self.riskSortLabel.setObjectName(u"riskSortLabel")

        self.riskSortLayout.addWidget(self.riskSortLabel)

        self.riskSortFieldComboBox = QComboBox(self.riskTab)
        self.riskSortFieldComboBox.addItem("")
        self.riskSortFieldComboBox.addItem("")
        self.riskSortFieldComboBox.setObjectName(u"riskSortFieldComboBox")
        self.riskSortFieldComboBox.setEnabled(False)
        sizePolicy2.setHeightForWidth(self.riskSortFieldComboBox.sizePolicy().hasHeightForWidth())
        self.riskSortFieldComboBox.setSizePolicy(sizePolicy2)
        self.riskSortFieldComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.riskSortFieldComboBox.setMinimumContentsLength(5)

        self.riskSortLayout.addWidget(self.riskSortFieldComboBox)

        self.riskSortDirectionComboBox = QComboBox(self.riskTab)
        self.riskSortDirectionComboBox.addItem("")
        self.riskSortDirectionComboBox.addItem("")
        self.riskSortDirectionComboBox.setObjectName(u"riskSortDirectionComboBox")
        self.riskSortDirectionComboBox.setEnabled(False)

        self.riskSortLayout.addWidget(self.riskSortDirectionComboBox)

        self.clearRiskFiltersButton = QPushButton(self.riskTab)
        self.clearRiskFiltersButton.setObjectName(u"clearRiskFiltersButton")
        self.clearRiskFiltersButton.setEnabled(False)

        self.riskSortLayout.addWidget(self.clearRiskFiltersButton)

        self.riskVisibleCountLabel = QLabel(self.riskTab)
        self.riskVisibleCountLabel.setObjectName(u"riskVisibleCountLabel")
        self.riskVisibleCountLabel.setWordWrap(True)

        self.riskSortLayout.addWidget(self.riskVisibleCountLabel)


        self.riskLayout.addLayout(self.riskSortLayout)

        self.riskFiltersScrollArea = QScrollArea(self.riskTab)
        self.riskFiltersScrollArea.setObjectName(u"riskFiltersScrollArea")
        self.riskFiltersScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.riskFiltersScrollArea.setWidgetResizable(True)
        self.riskFiltersScrollArea.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.riskFiltersScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.riskFiltersScrollArea.setMinimumSize(QSize(0, 44))
        self.riskFiltersScrollArea.setMaximumSize(QSize(16777215, 44))
        self.riskFiltersContents = QWidget()
        self.riskFiltersContents.setObjectName(u"riskFiltersContents")
        self.riskFiltersLayout = QHBoxLayout(self.riskFiltersContents)
        self.riskFiltersLayout.setSpacing(6)
        self.riskFiltersLayout.setObjectName(u"riskFiltersLayout")
        self.riskFiltersLayout.setContentsMargins(0, 0, 0, 0)
        self.riskFiltersSpacer = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.riskFiltersLayout.addItem(self.riskFiltersSpacer)

        self.riskFiltersScrollArea.setWidget(self.riskFiltersContents)

        self.riskLayout.addWidget(self.riskFiltersScrollArea)

        self.riskViewsTabWidget = CurrentPageTabWidget(self.riskTab)
        self.riskViewsTabWidget.setObjectName(u"riskViewsTabWidget")
        self.riskChartTab = QWidget()
        self.riskChartTab.setObjectName(u"riskChartTab")
        self.riskChartLayout = QVBoxLayout(self.riskChartTab)
        self.riskChartLayout.setSpacing(6)
        self.riskChartLayout.setObjectName(u"riskChartLayout")
        self.riskChartLayout.setContentsMargins(6, 6, 6, 6)
        self.riskLegendLabel = QLabel(self.riskChartTab)
        self.riskLegendLabel.setObjectName(u"riskLegendLabel")
        self.riskLegendLabel.setWordWrap(True)

        self.riskChartLayout.addWidget(self.riskLegendLabel)

        self.riskScrollArea = QScrollArea(self.riskChartTab)
        self.riskScrollArea.setObjectName(u"riskScrollArea")
        self.riskScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.riskScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.riskScrollArea.setWidgetResizable(True)
        self.riskScrollArea.setMinimumSize(QSize(0, 120))
        sizePolicy.setHeightForWidth(self.riskScrollArea.sizePolicy().hasHeightForWidth())
        self.riskScrollArea.setSizePolicy(sizePolicy)
        self.riskPlot = TskRiskPlot()
        self.riskPlot.setObjectName(u"riskPlot")
        self.riskPlot.setProperty(u"selectionFillAlpha", 28)
        self.riskPlot.setProperty(u"selectionOutlineWidth", 1.500000000000000)
        self.riskPlot.setProperty(u"virtualRows", True)
        self.riskPlot.setProperty(u"virtualCanvasMaximumHeight", 16777215)
        self.riskPlot.setProperty(u"confidenceLevel", 0.950000000000000)
        self.riskPlot.setProperty(u"multilineLabelWidthPadding", 12)
        self.riskPlot.setProperty(u"multilineLabelMaxWidth", 260)
        self.riskPlot.setProperty(u"multilineLabelWidthRatio", 0.380000000000000)
        self.riskPlot.setProperty(u"multilineLabelPadding", 14)
        self.riskPlot.setProperty(u"minimumRowHeight", 50)
        self.riskPlot.setMinimumSize(QSize(0, 190))
        sizePolicy.setHeightForWidth(self.riskPlot.sizePolicy().hasHeightForWidth())
        self.riskPlot.setSizePolicy(sizePolicy)
        self.riskScrollArea.setWidget(self.riskPlot)

        self.riskChartLayout.addWidget(self.riskScrollArea)

        self.riskChartLayout.setStretch(1, 1)
        self.riskViewsTabWidget.addTab(self.riskChartTab, "")
        self.combinationHeatmapTab = QWidget()
        self.combinationHeatmapTab.setObjectName(u"combinationHeatmapTab")
        self.combinationHeatmapLayout = QVBoxLayout(self.combinationHeatmapTab)
        self.combinationHeatmapLayout.setSpacing(6)
        self.combinationHeatmapLayout.setObjectName(u"combinationHeatmapLayout")
        self.combinationHeatmapLayout.setContentsMargins(6, 6, 6, 6)
        self.heatmapAxesLayout = QHBoxLayout()
        self.heatmapAxesLayout.setSpacing(6)
        self.heatmapAxesLayout.setObjectName(u"heatmapAxesLayout")
        self.heatmapXAxisSelector = TskHeatmapAxisSelector(self.combinationHeatmapTab)
        self.heatmapXAxisSelector.setObjectName(u"heatmapXAxisSelector")

        self.heatmapAxesLayout.addWidget(self.heatmapXAxisSelector)

        self.heatmapYAxisSelector = TskHeatmapAxisSelector(self.combinationHeatmapTab)
        self.heatmapYAxisSelector.setObjectName(u"heatmapYAxisSelector")

        self.heatmapAxesLayout.addWidget(self.heatmapYAxisSelector)

        self.combinationHeatmapMetricComboBox = QComboBox(self.combinationHeatmapTab)
        self.combinationHeatmapMetricComboBox.addItem("")
        self.combinationHeatmapMetricComboBox.addItem("")
        self.combinationHeatmapMetricComboBox.setObjectName(u"combinationHeatmapMetricComboBox")
        self.combinationHeatmapMetricComboBox.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combinationHeatmapMetricComboBox.setMinimumContentsLength(4)

        self.heatmapAxesLayout.addWidget(self.combinationHeatmapMetricComboBox)

        self.heatmapAxesLayout.setStretch(0, 1)
        self.heatmapAxesLayout.setStretch(1, 1)

        self.combinationHeatmapLayout.addLayout(self.heatmapAxesLayout)

        self.heatmapAxesHintLabel = QLabel(self.combinationHeatmapTab)
        self.heatmapAxesHintLabel.setObjectName(u"heatmapAxesHintLabel")
        self.heatmapAxesHintLabel.setWordWrap(True)
        self.heatmapAxesHintLabel.setVisible(False)

        self.combinationHeatmapLayout.addWidget(self.heatmapAxesHintLabel)

        self.combinationHeatmapLegendLabel = QLabel(self.combinationHeatmapTab)
        self.combinationHeatmapLegendLabel.setObjectName(u"combinationHeatmapLegendLabel")
        self.combinationHeatmapLegendLabel.setWordWrap(True)

        self.combinationHeatmapLayout.addWidget(self.combinationHeatmapLegendLabel)

        self.heatmapPageControls = QWidget(self.combinationHeatmapTab)
        self.heatmapPageControls.setObjectName(u"heatmapPageControls")
        self.heatmapPageControls.setVisible(False)
        self.heatmapPageLayout = QHBoxLayout(self.heatmapPageControls)
        self.heatmapPageLayout.setSpacing(6)
        self.heatmapPageLayout.setObjectName(u"heatmapPageLayout")
        self.heatmapPageLayout.setContentsMargins(0, 0, 0, 0)
        self.heatmapPageLabel = QLabel(self.heatmapPageControls)
        self.heatmapPageLabel.setObjectName(u"heatmapPageLabel")
        self.heatmapPageLabel.setProperty(u"pageSize", 25)
        self.heatmapPageLabel.setWordWrap(True)

        self.heatmapPageLayout.addWidget(self.heatmapPageLabel)

        self.heatmapPageSpinBox = QSpinBox(self.heatmapPageControls)
        self.heatmapPageSpinBox.setObjectName(u"heatmapPageSpinBox")
        self.heatmapPageSpinBox.setMinimum(1)
        self.heatmapPageSpinBox.setMaximum(1)

        self.heatmapPageLayout.addWidget(self.heatmapPageSpinBox)


        self.combinationHeatmapLayout.addWidget(self.heatmapPageControls)

        self.combinationHeatmapScrollArea = QScrollArea(self.combinationHeatmapTab)
        self.combinationHeatmapScrollArea.setObjectName(u"combinationHeatmapScrollArea")
        self.combinationHeatmapScrollArea.setWidgetResizable(True)
        self.combinationHeatmapScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.combinationHeatmapScrollArea.setMinimumSize(QSize(0, 120))
        sizePolicy.setHeightForWidth(self.combinationHeatmapScrollArea.sizePolicy().hasHeightForWidth())
        self.combinationHeatmapScrollArea.setSizePolicy(sizePolicy)
        self.combinationHeatmap = TskCombinationHeatmap()
        self.combinationHeatmap.setObjectName(u"combinationHeatmap")
        self.combinationHeatmap.setProperty(u"selectionOutlineWidth", 2.000000000000000)
        self.combinationHeatmap.setProperty(u"minimumAxisTitleHeight", 30)
        self.combinationHeatmap.setProperty(u"maximumAxisTitleWidth", 620)
        self.combinationHeatmap.setProperty(u"axisTitleVerticalPadding", 8)
        self.combinationHeatmap.setProperty(u"maximumRowLabelWidth", 300)
        self.combinationHeatmap.setProperty(u"rowLabelHorizontalPadding", 12)
        self.combinationHeatmap.setProperty(u"rowLabelVerticalPadding", 12)
        self.combinationHeatmap.setProperty(u"headerHorizontalPadding", 6)
        self.combinationHeatmap.setProperty(u"headerVerticalPadding", 8)
        self.combinationHeatmap.setProperty(u"minimumHeaderHeight", 37)
        self.combinationHeatmap.setProperty(u"typeLabelWidth", 110)
        self.combinationHeatmap.setProperty(u"minimumCellWidth", 86)
        self.combinationHeatmap.setProperty(u"cellRowHeight", 42)
        self.combinationHeatmap.setProperty(u"rightPadding", 8)
        self.combinationHeatmap.setProperty(u"bottomPadding", 25)
        self.combinationHeatmap.setProperty(u"minimumCanvasHeight", 160)
        self.combinationHeatmap.setMinimumSize(QSize(0, 160))
        self.combinationHeatmap.setProperty(u"lightCellTextColor", QColor(0, 0, 0))
        self.combinationHeatmap.setProperty(u"darkCellTextColor", QColor(255, 255, 255))
        self.combinationHeatmapScrollArea.setWidget(self.combinationHeatmap)

        self.combinationHeatmapLayout.addWidget(self.combinationHeatmapScrollArea)

        self.combinationHeatmapLayout.setStretch(4, 1)
        self.riskViewsTabWidget.addTab(self.combinationHeatmapTab, "")
        self.riskDetailsTab = QWidget()
        self.riskDetailsTab.setObjectName(u"riskDetailsTab")
        self.riskDetailsLayout = QVBoxLayout(self.riskDetailsTab)
        self.riskDetailsLayout.setSpacing(6)
        self.riskDetailsLayout.setObjectName(u"riskDetailsLayout")
        self.riskDetailsLayout.setContentsMargins(6, 6, 6, 6)
        self.riskDetailsConditionsLabel = QLabel(self.riskDetailsTab)
        self.riskDetailsConditionsLabel.setObjectName(u"riskDetailsConditionsLabel")
        self.riskDetailsConditionsLabel.setWordWrap(True)

        self.riskDetailsLayout.addWidget(self.riskDetailsConditionsLabel)

        self.typesTableView = QTableView(self.riskDetailsTab)
        self.typesTableView.setObjectName(u"typesTableView")
        self.typesTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.typesTableView.setAlternatingRowColors(True)
        self.typesTableView.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.typesTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.typesTableView.setSortingEnabled(True)

        self.riskDetailsLayout.addWidget(self.typesTableView)

        self.riskViewsTabWidget.addTab(self.riskDetailsTab, "")

        self.riskLayout.addWidget(self.riskViewsTabWidget)

        self.riskLayout.setStretch(7, 1)
        self.detailsTabWidget.addTab(self.riskTab, "")
        self.chainFitTab = QWidget()
        self.chainFitTab.setObjectName(u"chainFitTab")
        self.fitLayout = QVBoxLayout(self.chainFitTab)
        self.fitLayout.setSpacing(6)
        self.fitLayout.setObjectName(u"fitLayout")
        self.fitLayout.setContentsMargins(6, 6, 6, 6)
        self.fitViewsTabWidget = CurrentPageTabWidget(self.chainFitTab)
        self.fitViewsTabWidget.setObjectName(u"fitViewsTabWidget")
        self.chainOverviewTab = QWidget()
        self.chainOverviewTab.setObjectName(u"chainOverviewTab")
        self.chainFitLayout = QVBoxLayout(self.chainOverviewTab)
        self.chainFitLayout.setSpacing(6)
        self.chainFitLayout.setObjectName(u"chainFitLayout")
        self.chainFitLayout.setContentsMargins(6, 6, 6, 6)
        self.chainLegendLabel = QLabel(self.chainOverviewTab)
        self.chainLegendLabel.setObjectName(u"chainLegendLabel")
        self.chainLegendLabel.setWordWrap(True)

        self.chainFitLayout.addWidget(self.chainLegendLabel)

        self.chainPlot = TskChainFitPlot(self.chainOverviewTab)
        self.chainPlot.setObjectName(u"chainPlot")
        self.chainPlot.setProperty(u"axisLeftMargin", 82)
        self.chainPlot.setProperty(u"axisTickLeft", 34)
        self.chainPlot.setProperty(u"axisTitleX", 12)
        self.chainPlot.setProperty(u"selectionOutlineWidth", 2.000000000000000)
        self.chainPlot.setProperty(u"selectionMarkerSize", 16)
        self.chainPlot.setProperty(u"selectionLabelPadding", 4)
        self.chainPlot.setProperty(u"selectionLabelGap", 6)
        self.chainPlot.setProperty(u"selectionLabelElideMode", Qt.TextElideMode.ElideRight)
        self.chainPlot.setMinimumSize(QSize(0, 210))
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(1)
        sizePolicy4.setHeightForWidth(self.chainPlot.sizePolicy().hasHeightForWidth())
        self.chainPlot.setSizePolicy(sizePolicy4)

        self.chainFitLayout.addWidget(self.chainPlot)

        self.chainsTableView = QTableView(self.chainOverviewTab)
        self.chainsTableView.setObjectName(u"chainsTableView")
        self.chainsTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.chainsTableView.setAlternatingRowColors(True)
        self.chainsTableView.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.chainsTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.chainsTableView.setSortingEnabled(True)

        self.chainFitLayout.addWidget(self.chainsTableView)

        self.chainFitLayout.setStretch(1, 3)
        self.chainFitLayout.setStretch(2, 2)
        self.fitViewsTabWidget.addTab(self.chainOverviewTab, "")
        self.topologyTab = QWidget()
        self.topologyTab.setObjectName(u"topologyTab")
        self.topologyLayout = QVBoxLayout(self.topologyTab)
        self.topologyLayout.setSpacing(6)
        self.topologyLayout.setObjectName(u"topologyLayout")
        self.topologyLayout.setContentsMargins(6, 6, 6, 6)
        self.topologyHintLabel = QLabel(self.topologyTab)
        self.topologyHintLabel.setObjectName(u"topologyHintLabel")
        self.topologyHintLabel.setWordWrap(True)

        self.topologyLayout.addWidget(self.topologyHintLabel)

        self.topologyTableView = QTableView(self.topologyTab)
        self.topologyTableView.setObjectName(u"topologyTableView")
        self.topologyTableView.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.topologyTableView.setAlternatingRowColors(True)
        self.topologyTableView.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.topologyTableView.setSortingEnabled(True)

        self.topologyLayout.addWidget(self.topologyTableView)

        self.fitViewsTabWidget.addTab(self.topologyTab, "")

        self.fitLayout.addWidget(self.fitViewsTabWidget)

        self.detailsTabWidget.addTab(self.chainFitTab, "")
        self.jointRiskTab = QWidget()
        self.jointRiskTab.setObjectName(u"jointRiskTab")
        self.jointRiskLayout = QVBoxLayout(self.jointRiskTab)
        self.jointRiskLayout.setSpacing(6)
        self.jointRiskLayout.setObjectName(u"jointRiskLayout")
        self.jointRiskLayout.setContentsMargins(6, 6, 6, 6)
        self.jointRiskPanel = TskJointRiskPanel(self.jointRiskTab)
        self.jointRiskPanel.setObjectName(u"jointRiskPanel")

        self.jointRiskLayout.addWidget(self.jointRiskPanel)

        self.detailsTabWidget.addTab(self.jointRiskTab, "")
        self.featureEffectsTab = QWidget()
        self.featureEffectsTab.setObjectName(u"featureEffectsTab")
        self.featureEffectsLayout = QVBoxLayout(self.featureEffectsTab)
        self.featureEffectsLayout.setSpacing(6)
        self.featureEffectsLayout.setObjectName(u"featureEffectsLayout")
        self.featureEffectsLayout.setContentsMargins(6, 6, 6, 6)
        self.featureEffectsPanel = TskFeatureEffectsPanel(self.featureEffectsTab)
        self.featureEffectsPanel.setObjectName(u"featureEffectsPanel")

        self.featureEffectsLayout.addWidget(self.featureEffectsPanel)

        self.detailsTabWidget.addTab(self.featureEffectsTab, "")
        self.modelDiagnosticsTab = QWidget()
        self.modelDiagnosticsTab.setObjectName(u"modelDiagnosticsTab")
        self.modelDiagnosticsLayout = QVBoxLayout(self.modelDiagnosticsTab)
        self.modelDiagnosticsLayout.setSpacing(6)
        self.modelDiagnosticsLayout.setObjectName(u"modelDiagnosticsLayout")
        self.modelDiagnosticsLayout.setContentsMargins(6, 6, 6, 6)
        self.modelViewsTabWidget = CurrentPageTabWidget(self.modelDiagnosticsTab)
        self.modelViewsTabWidget.setObjectName(u"modelViewsTabWidget")
        self.featureTab = QWidget()
        self.featureTab.setObjectName(u"featureTab")
        self.featureLayout = QVBoxLayout(self.featureTab)
        self.featureLayout.setSpacing(6)
        self.featureLayout.setObjectName(u"featureLayout")
        self.featureLayout.setContentsMargins(6, 6, 6, 6)
        self.featurePanel = TskFeaturePanel(self.featureTab)
        self.featurePanel.setObjectName(u"featurePanel")

        self.featureLayout.addWidget(self.featurePanel)

        self.modelViewsTabWidget.addTab(self.featureTab, "")
        self.combinationWarningsTab = QWidget()
        self.combinationWarningsTab.setObjectName(u"combinationWarningsTab")
        self.combinationWarningsLayout = QVBoxLayout(self.combinationWarningsTab)
        self.combinationWarningsLayout.setSpacing(6)
        self.combinationWarningsLayout.setObjectName(u"combinationWarningsLayout")
        self.combinationWarningsLayout.setContentsMargins(6, 6, 6, 6)
        self.diagnosticsActionsLayout = QHBoxLayout()
        self.diagnosticsActionsLayout.setSpacing(6)
        self.diagnosticsActionsLayout.setObjectName(u"diagnosticsActionsLayout")
        self.copyDiagnosticsButton = QPushButton(self.combinationWarningsTab)
        self.copyDiagnosticsButton.setObjectName(u"copyDiagnosticsButton")
        self.copyDiagnosticsButton.setEnabled(False)

        self.diagnosticsActionsLayout.addWidget(self.copyDiagnosticsButton)

        self.saveDiagnosticsButton = QPushButton(self.combinationWarningsTab)
        self.saveDiagnosticsButton.setObjectName(u"saveDiagnosticsButton")
        self.saveDiagnosticsButton.setEnabled(False)

        self.diagnosticsActionsLayout.addWidget(self.saveDiagnosticsButton)

        self.diagnosticsActionsSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.diagnosticsActionsLayout.addItem(self.diagnosticsActionsSpacer)


        self.combinationWarningsLayout.addLayout(self.diagnosticsActionsLayout)

        self.diagnosticsActionStatusLabel = QLabel(self.combinationWarningsTab)
        self.diagnosticsActionStatusLabel.setObjectName(u"diagnosticsActionStatusLabel")
        self.diagnosticsActionStatusLabel.setVisible(False)
        self.diagnosticsActionStatusLabel.setWordWrap(True)
        self.diagnosticsActionStatusLabel.setTextFormat(Qt.TextFormat.PlainText)

        self.combinationWarningsLayout.addWidget(self.diagnosticsActionStatusLabel)

        self.combinationWarningsTextEdit = QPlainTextEdit(self.combinationWarningsTab)
        self.combinationWarningsTextEdit.setObjectName(u"combinationWarningsTextEdit")
        self.combinationWarningsTextEdit.setReadOnly(True)

        self.combinationWarningsLayout.addWidget(self.combinationWarningsTextEdit)

        self.modelViewsTabWidget.addTab(self.combinationWarningsTab, "")

        self.modelDiagnosticsLayout.addWidget(self.modelViewsTabWidget)

        self.detailsTabWidget.addTab(self.modelDiagnosticsTab, "")

        self.panelLayout.addWidget(self.detailsTabWidget)

        self.panelLayout.setStretch(3, 1)
        self.resultsDetailSplitter.addWidget(self.resultsMain)
        self.detailPanel = TskDetailPanel(self.resultsDetailSplitter)
        self.detailPanel.setObjectName(u"detailPanel")
        self.detailPanel.setVisible(False)
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(1)
        sizePolicy5.setHeightForWidth(self.detailPanel.sizePolicy().hasHeightForWidth())
        self.detailPanel.setSizePolicy(sizePolicy5)
        self.resultsDetailSplitter.addWidget(self.detailPanel)

        self.detailLayout.addWidget(self.resultsDetailSplitter)

#if QT_CONFIG(shortcut)
        self.groupLabel.setBuddy(self.groupComboBox)
        self.riskSortLabel.setBuddy(self.riskSortFieldComboBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(TskResultsPanelForm)

        self.detailsTabWidget.setCurrentIndex(0)
        self.riskViewsTabWidget.setCurrentIndex(0)
        self.fitViewsTabWidget.setCurrentIndex(0)
        self.modelViewsTabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(TskResultsPanelForm)
    # setupUi

    def retranslateUi(self, TskResultsPanelForm):
        TskResultsPanelForm.setProperty(u"combinationChainsHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u76f8\u5173\u94fe\u8def\uff08\u5f53\u524d\u8282\u70b9 / \u6279\u6b21\u7ec4\uff09\uff1a", None))
        TskResultsPanelForm.setProperty(u"combinationChainFormat", QCoreApplication.translate("TskResultsPanelForm", u"{chain_id}\n"
"  \u89c2\u6d4b\u5931\u6548\u7387\uff1a{observed} \u00b7 \u9884\u6d4b\u5931\u6548\u7387\uff1a{predicted}", None))
        TskResultsPanelForm.setProperty(u"combinationChainNoDataText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6d4b\u8bd5", None))
        TskResultsPanelForm.setProperty(u"combinationChainsEmptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u6a21\u677f\u4e2d\u6ca1\u6709\u4f7f\u7528\u8be5\u7ec4\u5408\u5b9e\u4f8b\u7684\u94fe\u8def\u3002", None))
        TskResultsPanelForm.setProperty(u"combinationChainsUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u7f3a\u5c11\u5e03\u5c40\u4fe1\u606f\uff0c\u65e0\u6cd5\u786e\u5b9a\u76f8\u5173\u94fe\u8def\u3002", None))
        TskResultsPanelForm.setProperty(u"combinationChainScopeText", QCoreApplication.translate("TskResultsPanelForm", u"\u4ee5\u4e0a\u4e3a\u6574\u6761\u94fe\u7684\u5931\u6548\u7387\u3002", None))
        self.groupLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8282\u70b9 / \u6279\u6b21", None))
        self.detailToggleButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u4fa7\u680f", None))
#if QT_CONFIG(tooltip)
        self.detailToggleButton.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u5c55\u5f00\u6216\u6536\u8d77\u5f53\u524d TSK / Chain \u8be6\u60c5\u4fa7\u680f\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.diagnosticsButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u67e5\u770b\u8bca\u65ad", None))
#if QT_CONFIG(tooltip)
        self.diagnosticsButton.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u6253\u5f00\u5f53\u524d\u7ec4\u7684\u6a21\u578b\u8bca\u65ad\u4e0e\u5206\u6790\u63d0\u793a\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.exportButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5bfc\u51fa XLSX", None))
        self.compactSummaryLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.compactSummaryLabel.setProperty(u"summaryFormat", QCoreApplication.translate("TskResultsPanelForm", u"{types} \u4e2a TSK \u00b7 {chains} \u6761\u94fe \u00b7 {convergence}", None))
        self.warningsLabel.setText("")
        self.warningsLabel.setProperty(u"summaryText", QCoreApplication.translate("TskResultsPanelForm", u"<a href=\"diagnostics\">{count} \u6761\u5206\u6790\u63d0\u793a</a>", None))
        self.summaryDetailsButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8be6\u60c5", None))
#if QT_CONFIG(tooltip)
        self.summaryDetailsButton.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u5c55\u5f00\u6a21\u578b\u3001\u6279\u6b21\u4e0e\u4fdd\u5b58\u72b6\u6001\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.summaryLabel.setProperty(u"savedText", QCoreApplication.translate("TskResultsPanelForm", u"\u5df2\u6062\u590d\u4fdd\u5b58\u7684\u5206\u6790\u7ed3\u679c\u3002", None))
        self.summaryLabel.setProperty(u"restoreErrorText", QCoreApplication.translate("TskResultsPanelForm", u"\u5df2\u4fdd\u5b58\u7684 TSK \u7ed3\u679c\u65e0\u6cd5\u8bfb\u53d6\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c\u5206\u6790\u3002", None))
        self.summaryLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.summaryLabel.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u672a\u8fd0\u884c TSK \u98ce\u9669\u5206\u6790\u3002", None))
        self.summaryLabel.setProperty(u"modelSummaryFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u6a21\u578b\uff1a{model}{details}", None))
        self.summaryLabel.setProperty(u"logisticModelText", QCoreApplication.translate("TskResultsPanelForm", u"Logistic", None))
        self.summaryLabel.setProperty(u"retiredModelText", QCoreApplication.translate("TskResultsPanelForm", u"Linear hazard\uff08\u5df2\u505c\u7528\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c Logistic\uff09", None))
        self.summaryLabel.setProperty(u"typeOnlyModelSuffix", QCoreApplication.translate("TskResultsPanelForm", u" \u00b7 \u672a\u4f7f\u7528\u7279\u5f81\uff0c\u91c7\u7528\u57fa\u7840\u7c7b\u578b\u6a21\u578b", None))
        self.riskReferenceSummaryLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u65e0\u98ce\u9669\u7ed3\u679c", None))
        self.riskReferenceSummaryLabel.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c1a\u65e0\u98ce\u9669\u7ed3\u679c", None))
        self.riskReferenceSummaryLabel.setProperty(u"typeText", QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u578b\u6a21\u578b \u00b7 \u5355\u5b9e\u4f8b\u6982\u7387", None))
        self.riskReferenceSummaryLabel.setProperty(u"featureText", QCoreApplication.translate("TskResultsPanelForm", u"\u6761\u4ef6\u6982\u7387 \u00b7 \u6570\u503c\u7279\u5f81\u56fa\u5b9a\u8bad\u7ec3\u5747\u503c", None))
        self.riskReferenceSummaryLabel.setProperty(u"completeText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8\u7c7b\u522b\u7ec4\u5408 \u00b7 \u6570\u503c\u7279\u5f81\u56fa\u5b9a\u8bad\u7ec3\u5747\u503c", None))
        self.riskReferenceSummaryLabel.setProperty(u"pendingText", QCoreApplication.translate("TskResultsPanelForm", u"\u7b49\u5f85\u5b8c\u6574\u7ec4\u5408\u7ed3\u679c", None))
        self.riskNoExtrapolationCheckBox.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5173\u95ed\u5916\u63d2\uff08\u65e0\u6570\u636e\u7ec4\u5408\u7559\u7a7a\uff09", None))
#if QT_CONFIG(tooltip)
        self.riskNoExtrapolationCheckBox.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u6216\u6253\u5f00\u5df2\u6709\u7ed3\u679c\u540e\uff0c\u53ef\u5207\u6362\u7c7b\u522b\u7ec4\u5408\u7684\u5916\u63d2\u7b56\u7565\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.riskNoExtrapolationCheckBox.setProperty(u"readyToolTip", QCoreApplication.translate("TskResultsPanelForm", u"\u52fe\u9009\u540e\uff0c\u65e0\u6709\u6548\u6570\u636e\u652f\u6301\u7684\u7c7b\u522b\u7ec4\u5408\u7559\u7a7a\uff1b\u53d6\u6d88\u52fe\u9009\u5219\u5141\u8bb8\u6a21\u578b\u5916\u63d2\u3002\u4f18\u5148\u663e\u793a\u5df2\u4fdd\u5b58\u7684\u5b8c\u6574\u7ec4\u5408\uff0c\u7f3a\u5c11\u76f8\u5e94\u7ed3\u679c\u65f6\u53ef\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\u3002", None))
        self.riskNoExtrapolationCheckBox.setProperty(u"savedToolTip", QCoreApplication.translate("TskResultsPanelForm", u"\u52fe\u9009\u540e\uff0c\u65e0\u6709\u6548\u6570\u636e\u652f\u6301\u7684\u7c7b\u522b\u7ec4\u5408\u7559\u7a7a\uff1b\u53d6\u6d88\u52fe\u9009\u5219\u663e\u793a\u5df2\u4fdd\u5b58\u7684\u5916\u63d2\u7ed3\u679c\u3002\u4ec5\u5207\u6362\u5df2\u6709\u5b8c\u6574\u7ed3\u679c\uff1b\u7f3a\u5c11\u76f8\u5e94\u7b56\u7565\u65f6\u4f1a\u63d0\u793a\u91cd\u65b0\u5206\u6790\u3002", None))
        self.riskNoExtrapolationCheckBox.setProperty(u"emptyToolTip", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u6216\u6253\u5f00\u5df2\u6709\u7ed3\u679c\u540e\uff0c\u53ef\u5207\u6362\u7c7b\u522b\u7ec4\u5408\u7684\u5916\u63d2\u7b56\u7565\u3002", None))
        self.riskNoExtrapolationCheckBox.setProperty(u"noCategoriesToolTip", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u672a\u4f7f\u7528\u7c7b\u522b\u7279\u5f81\uff0c\u7c7b\u522b\u7ec4\u5408\u5916\u63d2\u5f00\u5173\u4e0d\u9002\u7528\uff1b\u5f53\u524d\u663e\u793a\u5404 TSK \u7684\u5355\u5b9e\u4f8b\u6982\u7387\u3002", None))
        self.riskNoExtrapolationCheckBox.setProperty(u"unavailableToolTip", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u672a\u4fdd\u5b58\u5b8c\u6574\u7c7b\u522b\u7ec4\u5408\uff0c\u4e14\u7f3a\u5c11\u53ef\u8ba1\u7b97\u7684\u62df\u5408\u4fe1\u606f\uff1b\u8bf7\u91cd\u65b0\u8fd0\u884c TSK \u5206\u6790\u3002", None))
        self.riskNoExtrapolationCheckBox.setProperty(u"busyToolTip", QCoreApplication.translate("TskResultsPanelForm", u"\u6b63\u5728\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\uff0c\u5b8c\u6210\u540e\u53ef\u5207\u6362\u5916\u63d2\u7b56\u7565\u3002", None))
        self.riskHelpButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8bf4\u660e", None))
#if QT_CONFIG(tooltip)
        self.riskHelpButton.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u67e5\u770b\u6982\u7387\u53e3\u5f84\u3001\u7f6e\u4fe1\u533a\u95f4\u3001\u70ed\u529b\u56fe\u53ca\u8f74\u9009\u62e9\u8bf4\u660e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.referenceLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u53ef\u663e\u793a\u7684\u62df\u5408\u7ed3\u679c\u3002", None))
        self.referenceLabel.setProperty(u"typeOnlyText", QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u578b\u6a21\u578b\uff1a\u540c\u4e00 TSK_ID \u7684\u5404\u5b9e\u4f8b\u5171\u4eab\u5f02\u5e38\u6982\u7387\u3002", None))
        self.referenceLabel.setProperty(u"featureText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u56fa\u5b9a\u6240\u6709\u6570\u503c\u7279\u5f81\u5728\u8be5\u7ec4\u8bad\u7ec3\u5747\u503c\uff0c\u6bd4\u8f83 TSK \u6761\u4ef6\u6982\u7387\u3002", None))
        self.referenceLabel.setProperty(u"categoricalText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u6570\u503c\u7279\u5f81\u53d6\u8bad\u7ec3\u5747\u503c\uff0c\u7c7b\u522b\u53d6 {categories}\uff0c\u6bd4\u8f83 TSK \u6761\u4ef6\u6982\u7387\uff1b\u4e0d\u662f\u6240\u6709\u5b9e\u4f8b\u7684\u5e73\u5747\u98ce\u9669\u3002", None))
        self.referenceLabel.setProperty(u"allCombinationsText", QCoreApplication.translate("TskResultsPanelForm", u"\u5c55\u793a\u5168\u90e8\u7c7b\u522b\u7ec4\u5408\uff08{dimensions}\uff09\uff0c\u6bcf\u9879\u5bf9\u5e94 TSK_ID \u4e0e\u7c7b\u522b\u7ec4\u5408\u3002XY \u548c\u5176\u4ed6\u6570\u503c\u7279\u5f81\u4ec5\u56fa\u5b9a\u5728\u8bad\u7ec3\u5747\u503c\uff0c\u4e0d\u53c2\u4e0e\u7ec4\u5408\u5c55\u5f00\u3002{missing}", None))
        self.referenceLabel.setProperty(u"noExtrapolationText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\u7684\u7ec4\u5408\u7559\u7a7a\uff0c\u4e0d\u5916\u63a8\u3002", None))
        self.referenceLabel.setProperty(u"extrapolationText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\u7684\u7ec4\u5408\u5141\u8bb8\u6a21\u578b\u5916\u63a8\u3002", None))
        self.referenceLabel.setProperty(u"allCombinationsPendingText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8\u7c7b\u522b\u7ec4\u5408\u5c1a\u672a\u8ba1\u7b97\uff1b\u6761\u5f62\u56fe\u3001\u70ed\u529b\u56fe\u4e0e\u660e\u7ec6\u8868\u7b49\u5f85\u5b8c\u6574\u7ec4\u5408\u7ed3\u679c\u3002", None))
        self.referenceLabel.setProperty(u"categoricalNoFitText", QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u6a21\u578b\uff1a\u6570\u503c\u7279\u5f81\u53d6\u8bad\u7ec3\u5747\u503c\u3001\u7c7b\u522b\u7279\u5f81\u53d6\u57fa\u51c6\u7c7b\u522b\uff1b\u672c\u7ec4\u5c1a\u65e0\u53ef\u7528\u62df\u5408\u7ed3\u679c\u3002", None))
        self.riskCompletionHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5f53\u524d\u7ec4\u5c1a\u672a\u8ba1\u7b97\u5b8c\u6574\u7c7b\u522b\u7ec4\u5408\u3002\u70b9\u51fb\u201c\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\u201d\u540e\uff0c\u5728\u6761\u5f62\u56fe\u3001\u70ed\u529b\u56fe\u4e0e\u660e\u7ec6\u8868\u4e2d\u67e5\u770b\u540c\u4e00\u6279\u7ed3\u679c\u3002", None))
        self.calculateFullCombinationButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408", None))
        self.riskCalculationStatusLabel.setText("")
        self.riskCalculationStatusLabel.setProperty(u"savedResultText", QCoreApplication.translate("TskResultsPanelForm", u"\u4fdd\u5b58\u7ed3\u679c\u672a\u5305\u542b\u5f53\u524d\u7b56\u7565\u4e0b\u7684\u5b8c\u6574\u7ec4\u5408\uff1b\u8bf7\u91cd\u65b0\u8fd0\u884c TSK \u5206\u6790\u540e\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\u3002", None))
        self.riskCalculationStatusLabel.setProperty(u"retiredModelText", QCoreApplication.translate("TskResultsPanelForm", u"\u6b64\u5386\u53f2\u7ed3\u679c\u4f7f\u7528\u5df2\u505c\u7528\u7684 Linear hazard\uff1b\u8bf7\u91cd\u65b0\u8fd0\u884c Logistic \u5206\u6790\u540e\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\u3002", None))
        self.riskCalculationStatusLabel.setProperty(u"noContextText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u65e0\u5b8c\u6574\u7ec4\u5408\u9884\u6d4b\u6240\u9700\u7684\u62df\u5408\u4fe1\u606f\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c TSK \u5206\u6790\u3002", None))
        self.riskCalculationStatusLabel.setProperty(u"noCategoriesText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u672a\u4f7f\u7528\u7c7b\u522b\u7279\u5f81\uff0c\u6309 TSK \u663e\u793a\u5355\u5b9e\u4f8b\u6982\u7387\uff0c\u65e0\u9700\u8ba1\u7b97\u7c7b\u522b\u7ec4\u5408\u3002", None))
        self.riskCalculationStatusLabel.setProperty(u"readyText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u5171 {count} \u4e2a\u7ec4\u5408\uff1b\u8ba1\u7b97\u540e\u5728\u6761\u5f62\u56fe\u3001\u70ed\u529b\u56fe\u548c\u660e\u7ec6\u8868\u4e2d\u67e5\u770b\u3002", None))
        self.riskCalculationStatusLabel.setProperty(u"busyText", QCoreApplication.translate("TskResultsPanelForm", u"\u6b63\u5728\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\u6982\u7387\u4e0e\u7f6e\u4fe1\u533a\u95f4\u2026", None))
        self.riskSortLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6392\u5e8f", None))
        self.riskSortFieldComboBox.setItemText(0, QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None))
        self.riskSortFieldComboBox.setItemText(1, QCoreApplication.translate("TskResultsPanelForm", u"\u5931\u6548\u6982\u7387", None))

        self.riskSortFieldComboBox.setProperty(u"tskText", QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None))
        self.riskSortFieldComboBox.setProperty(u"probabilityText", QCoreApplication.translate("TskResultsPanelForm", u"\u5931\u6548\u6982\u7387", None))
        self.riskSortDirectionComboBox.setItemText(0, QCoreApplication.translate("TskResultsPanelForm", u"\u5347\u5e8f \u2191", None))
        self.riskSortDirectionComboBox.setItemText(1, QCoreApplication.translate("TskResultsPanelForm", u"\u964d\u5e8f \u2193", None))

#if QT_CONFIG(tooltip)
        self.riskSortDirectionComboBox.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u6761\u5f62\u56fe\u4e0e\u660e\u7ec6\u8868\u6309\u6240\u9009\u5b57\u6bb5\u6392\u5e8f\uff1b\u660e\u7ec6\u8868\u53ef\u70b9\u51fb\u8868\u5934\u5355\u72ec\u6392\u5e8f\u3002\u70ed\u529b\u56fe\u6309\u6240\u9009\u8f74\u7ef4\u5ea6\u4e0e\u7ec4\u5408\u987a\u5e8f\u6392\u5217\u3002TSK \u7f16\u53f7\u53ca\u7c7b\u522b\u6309\u81ea\u7136\u987a\u5e8f\u6392\u5217\uff1b\u6982\u7387\u964d\u5e8f\u4ece\u9ad8\u5230\u4f4e\uff0c\u65e0\u4f30\u8ba1\u503c\u59cb\u7ec8\u6392\u5728\u672b\u5c3e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.clearRiskFiltersButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6e05\u9664\u7b5b\u9009", None))
        self.riskVisibleCountLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u663e\u793a 0 / 0 \u9879", None))
        self.riskVisibleCountLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u663e\u793a {visible} / {total} \u9879", None))
        self.riskVisibleCountLabel.setProperty(u"noMatchesText", QCoreApplication.translate("TskResultsPanelForm", u"\u5f53\u524d\u7b5b\u9009\u6ca1\u6709\u5339\u914d\u9879\uff1b\u53ef\u70b9\u51fb\u201c\u6e05\u9664\u7b5b\u9009\u201d\u3002", None))
#if QT_CONFIG(tooltip)
        self.riskVisibleCountLabel.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u7b5b\u9009\u540c\u6b65\u5230\u6761\u5f62\u56fe\u3001\u70ed\u529b\u56fe\u4e0e\u660e\u7ec6\u8868\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.riskLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u5b9e\u4f8b\u6982\u7387 \u00b7 95% \u7f6e\u4fe1\u533a\u95f4 \u00b7 \u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u96f6\u98ce\u9669", None))
        self.riskLegendLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u5b9e\u4f8b\u6982\u7387 \u00b7 {confidence} \u7f6e\u4fe1\u533a\u95f4 \u00b7 \u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u96f6\u98ce\u9669", None))
        self.riskLegendLabel.setProperty(u"detailsFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u6761\u5f62\uff1a\u5355\u5b9e\u4f8b P_fail \u00b7 \u8bef\u5dee\u7ebf\uff1a{confidence} \u7f6e\u4fe1\u533a\u95f4\u3002\n"
"\u96f6\u8fb9\u754c\u7ebf\u4ece 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u4e0d\u662f \u00b1 \u6807\u51c6\u5dee\uff1b\u201c\u8fd1\u4f3c\u201d\u8868\u793a\u8fd1\u4f3c\u533a\u95f4\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002\u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002", None))
        self.riskPlot.setProperty(u"supportFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u652f\u6301\u94fe\u6570\uff1a{chains}\uff1b\u94fe\u6d4b\u8bd5\u66b4\u9732\uff1a{exposure}\uff08\u4e0d\u662f\u72ec\u7acb\u6837\u672c\u91cf\uff09", None))
        self.riskPlot.setProperty(u"intervalMethodFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u65b9\u6cd5\uff1a{method}", None))
        self.riskPlot.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.riskPlot.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bef\u5dee\u6761\u4e3a 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u5e76\u975e \u00b1 \u6807\u51c6\u5dee\uff1b\u4e0a\u9650\u5bbd\u8868\u793a\u6570\u636e\u5c1a\u4e0d\u80fd\u6392\u9664\u8f83\u5927\u98ce\u9669\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002", None))
        self.riskPlot.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.riskPlot.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.riskPlot.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.riskPlot.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.riskPlot.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.riskPlot.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.riskPlot.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.riskPlot.setProperty(u"combinationLabelFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id}\n"
"{categories}", None))
        self.riskPlot.setProperty(u"categoryLineFormat", QCoreApplication.translate("TskResultsPanelForm", u"{name}={value}", None))
        self.riskPlot.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"P_fail(TSK_ID)\uff08%\uff09", None))
        self.riskPlot.setProperty(u"typeAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"P_fail(TSK_ID)\uff08%\uff09", None))
        self.riskPlot.setProperty(u"combinationAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"TSK \u4e0e\u7c7b\u522b\u7ec4\u5408\u6761\u4ef6 P_fail\uff08%\uff09", None))
        self.riskPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a TSK \u6982\u7387\u4e0e\u533a\u95f4\u3002", None))
        self.riskPlot.setProperty(u"outsideDomainText", QCoreApplication.translate("TskResultsPanelForm", u"\u53c2\u8003\u6761\u4ef6\u4e0d\u9002\u7528", None))
        self.riskPlot.setProperty(u"noDataText", "")
        self.riskPlot.setProperty(u"noDataTooltip", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff1b\u5df2\u7559\u7a7a\uff0c\u4e0d\u8fdb\u884c\u5916\u63a8\u3002", None))
        self.riskPlot.setProperty(u"intervalErrorFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{error}", None))
        self.riskViewsTabWidget.setTabText(self.riskViewsTabWidget.indexOf(self.riskChartTab), QCoreApplication.translate("TskResultsPanelForm", u"\u6761\u5f62\u56fe", None))
        self.heatmapXAxisSelector.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"X \u8f74", None))
        self.heatmapYAxisSelector.setProperty(u"axisLabel", QCoreApplication.translate("TskResultsPanelForm", u"Y \u8f74", None))
        self.combinationHeatmapMetricComboBox.setItemText(0, QCoreApplication.translate("TskResultsPanelForm", u"\u6982\u7387", None))
        self.combinationHeatmapMetricComboBox.setItemText(1, QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u5b9e\u4f8b", None))

#if QT_CONFIG(tooltip)
        self.combinationHeatmapMetricComboBox.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u6982\u7387\uff1a\u5355\u5b9e\u4f8b\u5931\u6548\u6982\u7387\uff1b\u6709\u6548\u5b9e\u4f8b\uff1a\u6240\u5728\u94fe\u6709\u6709\u6548\u6d4b\u8bd5\u6570\u636e\u7684\u5339\u914d\u5e03\u5c40\u5b9e\u4f8b\u6570\uff0c\u4e0d\u662f\u72ec\u7acb\u6837\u672c\u91cf\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.heatmapAxesHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u52fe\u9009\u4f1a\u5c06\u7ef4\u5ea6\u79fb\u5230\u672c\u8f74\uff0c\u53d6\u6d88\u52fe\u9009\u4f1a\u79fb\u5230\u53e6\u4e00\u8f74\uff1b\u4e0a\u4e0b\u79fb\u52a8\u8c03\u6574\u7ec4\u5408\u987a\u5e8f\u3002\u7a7a\u8f74\u663e\u793a\u5355\u884c\u6216\u5355\u5217\uff0c\u4e0d\u6c47\u603b\u6982\u7387\u3002", None))
        self.combinationHeatmapLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u4f4e \u84dd\u2192\u7d2b\u2192\u9ec4 \u9ad8 \u00b7 \u7a7a\u767d \u65e0\u6570\u636e \u00b7 \u7070 \u4e0d\u53ef\u4f30\u8ba1 \u00b7 \u659c\u7eb9 \u5916\u63a8/\u65e0\u652f\u6301", None))
        self.combinationHeatmapLegendLabel.setProperty(u"detailsText", QCoreApplication.translate("TskResultsPanelForm", u"\u8272\u9636\u7531\u4f4e\u5230\u9ad8\u4e3a\u6df1\u84dd\u8272\u3001\u7d2b\u8272\u3001\u6a59\u8272\u3001\u9ec4\u8272\uff0c\u6309\u5f53\u524d\u9875\u7684 0 \u5230\u6700\u5927\u503c\u6620\u5c04\uff1b\u6982\u7387\u4e0e\u6709\u6548\u5b9e\u4f8b\u5206\u522b\u7f29\u653e\u3002\u6d45\u8272\u683c\u4f7f\u7528\u9ed1\u5b57\uff0c\u6df1\u8272\u683c\u4f7f\u7528\u767d\u5b57\u3002\u7a7a\u683c = \u65e0\u6570\u636e\u4e14\u4e0d\u5916\u63a8\uff1b\u7070\u683c = \u4e0d\u53ef\u4f30\u8ba1\uff1b\u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u96f6\u98ce\u9669\uff0c\u5355\u4fa7\u4e0a\u9650\u89c1\u60ac\u505c\u6216\u660e\u7ec6\uff1b\u659c\u7eb9 = \u5916\u63a8\u6216\u65e0\u6709\u6548\u652f\u6301\u3002\u6709\u6548\u5b9e\u4f8b\u662f\u6240\u5728\u94fe\u6709\u6709\u6548\u6d4b\u8bd5\u6570\u636e\u7684\u5339\u914d\u5e03\u5c40\u5b9e\u4f8b\u6570\uff0c\u4e0d\u662f\u72ec\u7acb\u6837\u672c\u91cf\u3002\u70b9\u51fb\u683c\u5b50\u5728\u53f3\u4fa7\u67e5\u770b TSK \u4e0e\u76f8\u5173\u94fe\u8def\u8be6\u60c5\u3002\u8f74\u5185\u7ef4\u5ea6\u6309\u6240\u9009\u987a\u5e8f\u7ec4"
                        "\u5408\uff1b\u6761\u5f62\u56fe\u4e0e\u660e\u7ec6\u53ef\u5206\u522b\u6392\u5e8f\u3002", None))
#if QT_CONFIG(tooltip)
        self.combinationHeatmapLegendLabel.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u8272\u9636\u7531\u4f4e\u5230\u9ad8\u4e3a\u6df1\u84dd\u8272\u3001\u7d2b\u8272\u3001\u6a59\u8272\u3001\u9ec4\u8272\uff0c\u6309\u5f53\u524d\u9875\u7684 0 \u5230\u6700\u5927\u503c\u6620\u5c04\uff1b\u6982\u7387\u4e0e\u6709\u6548\u5b9e\u4f8b\u5206\u522b\u7f29\u653e\u3002\u6d45\u8272\u683c\u4f7f\u7528\u9ed1\u5b57\uff0c\u6df1\u8272\u683c\u4f7f\u7528\u767d\u5b57\u3002\u7a7a\u683c = \u65e0\u6570\u636e\u4e14\u4e0d\u5916\u63a8\uff1b\u7070\u683c = \u4e0d\u53ef\u4f30\u8ba1\uff1b\u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u96f6\u98ce\u9669\uff0c\u5355\u4fa7\u4e0a\u9650\u89c1\u60ac\u505c\u6216\u660e\u7ec6\uff1b\u659c\u7eb9 = \u5916\u63a8\u6216\u65e0\u6709\u6548\u652f\u6301\u3002\u6709\u6548\u5b9e\u4f8b\u662f\u6240\u5728\u94fe\u6709\u6709\u6548\u6d4b\u8bd5\u6570\u636e\u7684\u5339\u914d\u5e03\u5c40\u5b9e\u4f8b\u6570\uff0c\u4e0d\u662f\u72ec\u7acb\u6837\u672c\u91cf\u3002\u70b9\u51fb\u683c\u5b50\u5728\u53f3\u4fa7\u67e5\u770b TSK \u4e0e\u76f8\u5173\u94fe\u8def\u8be6\u60c5\u3002\u8f74\u5185\u7ef4\u5ea6\u6309\u6240\u9009\u987a\u5e8f\u7ec4"
                        "\u5408\uff1b\u6761\u5f62\u56fe\u4e0e\u660e\u7ec6\u53ef\u5206\u522b\u6392\u5e8f\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.heatmapPageLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8 {count} \u683c\uff1b\u672c\u9875\u884c {row_start}\u2013{row_end}\u3001\u5217 {column_start}\u2013{column_end}\uff0c\u5171 {pages} \u9875\u3002", None))
        self.heatmapPageLabel.setProperty(u"formatText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8 {count} \u683c\uff1b\u672c\u9875\u884c {row_start}\u2013{row_end}\u3001\u5217 {column_start}\u2013{column_end}\uff0c\u5171 {pages} \u9875\u3002", None))
        self.heatmapPageSpinBox.setPrefix(QCoreApplication.translate("TskResultsPanelForm", u"\u7b2c ", None))
        self.heatmapPageSpinBox.setSuffix(QCoreApplication.translate("TskResultsPanelForm", u" \u9875", None))
        self.combinationHeatmap.setProperty(u"allAxisText", QCoreApplication.translate("TskResultsPanelForm", u"\u5168\u90e8", None))
        self.combinationHeatmap.setProperty(u"axisValueFormat", QCoreApplication.translate("TskResultsPanelForm", u"{name}={value}", None))
        self.combinationHeatmap.setProperty(u"axisLabelSeparator", QCoreApplication.translate("TskResultsPanelForm", u" \u00b7 ", None))
        self.combinationHeatmap.setProperty(u"typeOnlyLevelText", QCoreApplication.translate("TskResultsPanelForm", u"TSK \u6761\u4ef6\u6982\u7387", None))
        self.combinationHeatmap.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.combinationHeatmap.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bef\u5dee\u6761\u4e3a 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u5e76\u975e \u00b1 \u6807\u51c6\u5dee\uff1b\u4e0a\u9650\u5bbd\u8868\u793a\u6570\u636e\u5c1a\u4e0d\u80fd\u6392\u9664\u8f83\u5927\u98ce\u9669\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002", None))
        self.combinationHeatmap.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.combinationHeatmap.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.combinationHeatmap.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.combinationHeatmap.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.combinationHeatmap.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.combinationHeatmap.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.combinationHeatmap.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.combinationHeatmap.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u6682\u65e0\u53ef\u663e\u793a\u7684\u98ce\u9669\u7ed3\u679c\u3002\u8bf7\u5148\u8fd0\u884c\u5206\u6790\u3001\u8ba1\u7b97\u5b8c\u6574\u7ec4\u5408\uff0c\u6216\u6e05\u9664\u5f53\u524d\u7b5b\u9009\u3002", None))
        self.combinationHeatmap.setProperty(u"noDataSupportText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff08\u4e0d\u5916\u63a8\uff09", None))
        self.combinationHeatmap.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id} \u00b7 {level}\n"
"P_fail\uff1a{probability}\n"
"\u533a\u95f4\uff1a{interval}\n"
"\u533a\u95f4\u65b9\u6cd5\uff1a{interval_method}\n"
"\u652f\u6301\u72b6\u6001\uff1a{support}\n"
"\u5e03\u5c40\u5b9e\u4f8b\uff1a{layout} \u00b7 \u6709\u6548\u5b9e\u4f8b\uff1a{active}\n"
"\u6709\u6548\u94fe\uff1a{chains} \u00b7 \u94fe\u6d4b\u8bd5\u66b4\u9732\uff1a{exposure}\n"
"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0\uff1a{interval_error}\n"
"{boundary_note}\n"
"\n"
"{chain_details}", None))
        self.combinationHeatmap.setProperty(u"colorStops", [
            QCoreApplication.translate("TskResultsPanelForm", u"#0d0887", None),
            QCoreApplication.translate("TskResultsPanelForm", u"#5302a3", None),
            QCoreApplication.translate("TskResultsPanelForm", u"#7e03a8", None),
            QCoreApplication.translate("TskResultsPanelForm", u"#a82296", None),
            QCoreApplication.translate("TskResultsPanelForm", u"#cb4679", None),
            QCoreApplication.translate("TskResultsPanelForm", u"#e56b5d", None),
            QCoreApplication.translate("TskResultsPanelForm", u"#f89441", None),
            QCoreApplication.translate("TskResultsPanelForm", u"#fdca26", None),
            QCoreApplication.translate("TskResultsPanelForm", u"#f0f921", None)])
        self.riskViewsTabWidget.setTabText(self.riskViewsTabWidget.indexOf(self.combinationHeatmapTab), QCoreApplication.translate("TskResultsPanelForm", u"\u70ed\u529b\u56fe", None))
        self.riskDetailsConditionsLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u4e0e\u6761\u5f62\u56fe\u3001\u70ed\u529b\u56fe\u4f7f\u7528\u540c\u4e00\u6279\u98ce\u9669\u7ed3\u679c\u3002XY \u548c\u5176\u4ed6\u6570\u503c\u7279\u5f81\u56fa\u5b9a\u5728\u672c\u7ec4\u8bad\u7ec3\u5747\u503c\uff1b\u8fd9\u662f\u6761\u4ef6\u98ce\u9669\uff0c\u4e0d\u662f\u6240\u6709\u5b9e\u4f8b\u7684\u5e73\u5747\u98ce\u9669\u3002", None))
        self.typesTableView.setProperty(u"noDataSupportText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6709\u6548\u6570\u636e\uff08\u4e0d\u5916\u63a8\uff09", None))
        self.typesTableView.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.typesTableView.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u662f\u6a21\u578b\u8fb9\u754c\u5904\u7684\u4f30\u8ba1\uff0c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002\u8bef\u5dee\u6761\u4e3a 0 \u5230\u5355\u4fa7\u7f6e\u4fe1\u4e0a\u9650\uff0c\u5e76\u975e \u00b1 \u6807\u51c6\u5dee\uff1b\u4e0a\u9650\u5bbd\u8868\u793a\u6570\u636e\u5c1a\u4e0d\u80fd\u6392\u9664\u8f83\u5927\u98ce\u9669\u3002\u6a2a\u8f74\u81ea\u52a8\u7f29\u653e\u3002", None))
        self.typesTableView.setProperty(u"upperIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0a\u9650\uff08\u5355\u4fa7 {confidence}\uff09\uff1a{upper}", None))
        self.typesTableView.setProperty(u"upperApproxIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09\uff1a{upper}", None))
        self.typesTableView.setProperty(u"twoSidedIntervalFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4\uff1a{lower} \u2013 {upper}", None))
        self.typesTableView.setProperty(u"upperIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u4fa7 {confidence} \u4e0a\u9650", None))
        self.typesTableView.setProperty(u"upperApproxIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd1\u4f3c\u4e0a\u9650\uff08{confidence} \u8f6e\u5ed3\u4f3c\u7136\u9608\u503c\uff09", None))
        self.typesTableView.setProperty(u"twoSidedIntervalKindFormat", QCoreApplication.translate("TskResultsPanelForm", u"{confidence} \u53cc\u4fa7\u533a\u95f4", None))
        self.typesTableView.setProperty(u"intervalUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528", None))
        self.typesTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"TSK ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u7c7b\u522b\u7ec4\u5408", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5355\u5b9e\u4f8b\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0b\u754c", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0a\u754c / \u5355\u4fa7\u4e0a\u9650", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u53ef\u5355\u72ec\u8bc6\u522b", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u65b9\u6cd5", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u4e0d\u53ef\u7528\u539f\u56e0", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u533a\u95f4\u5f62\u5f0f", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u652f\u6301\u72b6\u6001", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u5b9e\u4f8b\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u94fe\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u94fe\u6d4b\u8bd5\u66b4\u9732", None)])
        self.riskViewsTabWidget.setTabText(self.riskViewsTabWidget.indexOf(self.riskDetailsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u660e\u7ec6\u8868", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.riskTab), QCoreApplication.translate("TskResultsPanelForm", u"\u98ce\u9669\u7ed3\u679c", None))
        self.chainLegendLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u6bcf\u70b9\u4ee3\u8868\u4e00\u6761 Chain\uff1b\u5bf9\u89d2\u7ebf\u8868\u793a\u89c2\u5bdf\u4e0e\u9884\u6d4b\u4e00\u81f4\u3002\u6b8b\u5dee = \u89c2\u5bdf \u2212 \u9884\u6d4b\u3002\u60ac\u505c\u67e5\u770b\u94fe\u4e0a TSK \u53ca\u5b9e\u4f8b\u5b9e\u9645\u6761\u4ef6\u6982\u7387\u3002", None))
        self.chainPlot.setProperty(u"selectionLabelFormat", QCoreApplication.translate("TskResultsPanelForm", u"{chain_id}", None))
        self.chainPlot.setProperty(u"tooltipFormat", QCoreApplication.translate("TskResultsPanelForm", u"{chain_id} \u00b7 \u89c2\u5bdf {observed} / \u9884\u6d4b {predicted}\n"
"Fail / Tested\uff1a{failed}/{tested} \u00b7 Missing\uff1a{missing}", None))
        self.chainPlot.setProperty(u"membersHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u94fe\u4e0a TSK\uff1a\u5355\u5b9e\u4f8b\u98ce\u9669\uff0c\u6309\u5b9e\u9645\u6761\u4ef6\u8ba1\u7b97\uff1b\u540c\u6761\u4ef6\u5b9e\u4f8b\u5408\u5e76", None))
        self.chainPlot.setProperty(u"memberFormat", QCoreApplication.translate("TskResultsPanelForm", u"{tsk_id} \u00d7 {count} \u00b7 P_fail={probability}{reason} \u00b7 {conditions}", None))
        self.chainPlot.setProperty(u"noMembersText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ed3\u679c\u6ca1\u6709\u94fe\u6210\u5458\u98ce\u9669\u5feb\u7167\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c\u5206\u6790\u3002", None))
        self.chainPlot.setProperty(u"noFeaturesText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u989d\u5916\u7279\u5f81", None))
        self.chainPlot.setProperty(u"memberUnavailableText", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0d\u53ef\u4f30\u8ba1", None))
        self.chainPlot.setProperty(u"memberNoDataText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6570\u636e", None))
        self.chainPlot.setProperty(u"memberNotIdentifiableText", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0d\u53ef\u8bc6\u522b", None))
        self.chainPlot.setProperty(u"memberNotConvergedText", QCoreApplication.translate("TskResultsPanelForm", u"\u672a\u6536\u655b", None))
        self.chainPlot.setProperty(u"memberOutsideDomainText", QCoreApplication.translate("TskResultsPanelForm", u"\u5b9a\u4e49\u57df\u5916", None))
        self.chainPlot.setProperty(u"memberNoteFormat", QCoreApplication.translate("TskResultsPanelForm", u"[{index}] {text}", None))
        self.chainPlot.setProperty(u"memberNoteReferenceFormat", QCoreApplication.translate("TskResultsPanelForm", u"[{index}]", None))
        self.chainPlot.setProperty(u"boundaryLowText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4f30\u8ba1", None))
        self.chainPlot.setProperty(u"boundaryHintText", QCoreApplication.translate("TskResultsPanelForm", u"\u96f6\u8fb9\u754c\u4e0d\u8868\u793a\u4fdd\u8bc1\u96f6\u5931\u6548\u3002", None))
        self.chainPlot.setProperty(u"xAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u9884\u6d4b Chain \u5f02\u5e38\u7387\uff08%\uff09", None))
        self.chainPlot.setProperty(u"yAxisLabel", QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u5f02\u5e38\u7387\uff08%\uff09", None))
        self.chainPlot.setProperty(u"emptyText", QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c\u5206\u6790\u540e\u663e\u793a Chain \u62df\u5408\u504f\u5dee\u3002", None))
        self.chainsTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"Chain ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6709\u6548\u6837\u54c1\u6570", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Fail", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Pass", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Missing", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u9884\u6d4b\u6982\u7387", None),
            QCoreApplication.translate("TskResultsPanelForm", u"\u6b8b\u5dee (pp)", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Deviance residual", None)])
        self.fitViewsTabWidget.setTabText(self.fitViewsTabWidget.indexOf(self.chainOverviewTab), QCoreApplication.translate("TskResultsPanelForm", u"\u89c2\u5bdf\u4e0e\u9884\u6d4b", None))
        self.topologyHintLabel.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u663e\u793a\u672c\u6b21\u5206\u6790\u4fdd\u5b58\u7684\u5168\u5c40\u6a21\u677f\u5b9e\u4f8b\uff0c\u4e0d\u968f\u8282\u70b9 / \u6279\u6b21\u5207\u6362\u3002\u6bcf\u884c\u8868\u793a\u4e00\u4e2a\u7269\u7406\u5b9e\u4f8b\uff1b\u9644\u52a0\u7279\u5f81\u5217\u6765\u81ea\u6a21\u677f\u3002Chain \u5b8c\u6574\u8def\u5f84\u7528\u4e8e\u533a\u5206\u540c\u540d\u94fe\u8def\u3002", None))
        self.topologyTableView.setProperty(u"columnHeaders", [
            QCoreApplication.translate("TskResultsPanelForm", u"CHAIN_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"TSK_instance_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"TSK_ID", None),
            QCoreApplication.translate("TskResultsPanelForm", u"X", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Y", None),
            QCoreApplication.translate("TskResultsPanelForm", u"Chain \u5b8c\u6574\u8def\u5f84", None)])
        self.fitViewsTabWidget.setTabText(self.fitViewsTabWidget.indexOf(self.topologyTab), QCoreApplication.translate("TskResultsPanelForm", u"\u6a21\u677f\u5b9e\u4f8b\u7ec4\u6210", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.chainFitTab), QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408\u68c0\u67e5", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.jointRiskTab), QCoreApplication.translate("TskResultsPanelForm", u"\u8054\u5408\u98ce\u9669", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.featureEffectsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u7279\u5f81\u5f71\u54cd", None))
        self.modelViewsTabWidget.setTabText(self.modelViewsTabWidget.indexOf(self.featureTab), QCoreApplication.translate("TskResultsPanelForm", u"\u6a21\u578b\u8bf4\u660e", None))
        self.copyDiagnosticsButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u590d\u5236\u8bca\u65ad\u6587\u672c", None))
#if QT_CONFIG(tooltip)
        self.copyDiagnosticsButton.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u590d\u5236\u5f53\u524d\u7ec4\u6807\u8bc6\u3001\u62df\u5408 debug \u62a5\u544a\u53ca\u5168\u90e8\u63d0\u793a\uff0c\u4e0d\u5305\u542b\u539f\u59cb\u62d3\u6251\u6216\u6837\u54c1\u884c\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.saveDiagnosticsButton.setText(QCoreApplication.translate("TskResultsPanelForm", u"\u4fdd\u5b58\u8bca\u65ad TXT", None))
#if QT_CONFIG(tooltip)
        self.saveDiagnosticsButton.setToolTip(QCoreApplication.translate("TskResultsPanelForm", u"\u5c06\u5f53\u524d\u7ec4\u7684\u5b8c\u6574\u8bca\u65ad\u6587\u672c\u4fdd\u5b58\u4e3a UTF-8 \u6587\u672c\u6587\u4ef6\uff0c\u4fbf\u4e8e\u6392\u67e5\u8ba1\u7b97\u95ee\u9898\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.saveDiagnosticsButton.setProperty(u"dialogTitle", QCoreApplication.translate("TskResultsPanelForm", u"\u4fdd\u5b58 TSK \u8bca\u65ad\u6587\u672c", None))
        self.saveDiagnosticsButton.setProperty(u"fileFilter", QCoreApplication.translate("TskResultsPanelForm", u"\u6587\u672c\u6587\u4ef6 (*.txt)", None))
        self.saveDiagnosticsButton.setProperty(u"defaultFilename", QCoreApplication.translate("TskResultsPanelForm", u"tsk_diagnostics.txt", None))
        self.saveDiagnosticsButton.setProperty(u"errorTitle", QCoreApplication.translate("TskResultsPanelForm", u"\u8bca\u65ad\u6587\u672c\u4fdd\u5b58\u5931\u8d25", None))
        self.saveDiagnosticsButton.setProperty(u"errorFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0\u6cd5\u4fdd\u5b58\u8bca\u65ad\u6587\u672c\uff1a{error}", None))
        self.diagnosticsActionStatusLabel.setText("")
        self.diagnosticsActionStatusLabel.setProperty(u"copiedText", QCoreApplication.translate("TskResultsPanelForm", u"\u5df2\u590d\u5236\u5f53\u524d\u7ec4\u7684\u8bca\u65ad\u6587\u672c\u3002", None))
        self.diagnosticsActionStatusLabel.setProperty(u"savedFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u5df2\u4fdd\u5b58\uff1a{path}", None))
        self.combinationWarningsTextEdit.setPlaceholderText(QCoreApplication.translate("TskResultsPanelForm", u"\u8fd0\u884c TSK \u5206\u6790\u540e\uff0c\u6b64\u5904\u663e\u793a\u5f53\u524d\u7ec4\u7684\u62df\u5408 debug \u62a5\u544a\u548c\u5168\u90e8\u63d0\u793a\u3002\u53ef\u590d\u5236\u8bca\u65ad\u6587\u672c\u6216\u4fdd\u5b58\u4e3a TXT\uff0c\u4fbf\u4e8e\u6392\u67e5\u5361\u987f\u3001\u672a\u6536\u655b\u6216\u533a\u95f4\u4e0d\u53ef\u7528\u7684\u539f\u56e0\u3002", None))
        self.combinationWarningsTextEdit.setProperty(u"contextFormat", QCoreApplication.translate("TskResultsPanelForm", u"\u7ed3\u679c\u7ec4\uff1a{label}\n"
"\u8282\u70b9\uff1a{node}\n"
"\u6279\u6b21\u6a21\u5f0f\uff1a{batch_mode}\n"
"\u6279\u6b21\u5b57\u6bb5\uff1a{batch_dimension}\n"
"\u6bcd\u6279\uff1a{parent_batch}\n"
"\u539f\u6279\u6b21\uff1a{source_batches}", None))
        self.combinationWarningsTextEdit.setProperty(u"noneText", QCoreApplication.translate("TskResultsPanelForm", u"\u65e0", None))
        self.combinationWarningsTextEdit.setProperty(u"mixedBatchText", QCoreApplication.translate("TskResultsPanelForm", u"\u4e0d\u5206\u5c42", None))
        self.combinationWarningsTextEdit.setProperty(u"separateBatchText", QCoreApplication.translate("TskResultsPanelForm", u"\u6309\u539f\u6279", None))
        self.combinationWarningsTextEdit.setProperty(u"parentBatchText", QCoreApplication.translate("TskResultsPanelForm", u"\u6309\u6bcd\u6279", None))
        self.combinationWarningsTextEdit.setProperty(u"debugHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u62df\u5408 debug \u62a5\u544a", None))
        self.combinationWarningsTextEdit.setProperty(u"debugScopeText", QCoreApplication.translate("TskResultsPanelForm", u"\u4ee5\u4e0b debug \u53c2\u6570\u7528\u4e8e\u6392\u67e5\u4f18\u5316\u8fc7\u7a0b\uff0c\u4e0d\u7b49\u4e8e\u53ef\u4fe1\u98ce\u9669\u4f30\u8ba1\uff1b\u8bf7\u7ed3\u5408\u6536\u655b\u3001\u53ef\u8bc6\u522b\u6027\u548c\u533a\u95f4\u72b6\u6001\u5224\u65ad\u7ed3\u679c\u3002", None))
        self.combinationWarningsTextEdit.setProperty(u"noDebugReportText", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u7ed3\u679c\u672a\u8bb0\u5f55\u62df\u5408 debug \u62a5\u544a\u3002\u53ea\u6709\u542b\u7279\u5f81\u7684 Logistic \u4e3b\u62df\u5408\u4f1a\u8bb0\u5f55\u6b64\u8bca\u65ad\uff1b\u82e5\u662f\u65e7\u7684 Logistic \u7279\u5f81\u7ed3\u679c\uff0c\u8bf7\u91cd\u65b0\u8fd0\u884c\u5206\u6790\u3002", None))
        self.combinationWarningsTextEdit.setProperty(u"groupHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u672c\u7ec4\u5206\u6790\u63d0\u793a", None))
        self.combinationWarningsTextEdit.setProperty(u"viewHeading", QCoreApplication.translate("TskResultsPanelForm", u"\u5b8c\u6574\u7ec4\u5408\u63d0\u793a", None))
        self.combinationWarningsTextEdit.setProperty(u"modelScopeText", QCoreApplication.translate("TskResultsPanelForm", u"\u7ec4\u5408\u9884\u6d4b\u6cbf\u7528\u5171\u4eab\u7c7b\u522b\u4e3b\u6548\u5e94\u6a21\u578b\uff0c\u672a\u62df\u5408\u7c7b\u522b\u95f4\u6216\u7c7b\u522b\u4e0e TSK \u7684\u4ea4\u4e92\u3002\u4e0d\u540c TSK \u7684\u6982\u7387\u5dee\u4e0d\u540c\uff0c\u4e0d\u8868\u793a\u5df2\u8bc6\u522b\u4ea4\u4e92\u4f5c\u7528\u3002", None))
        self.modelViewsTabWidget.setTabText(self.modelViewsTabWidget.indexOf(self.combinationWarningsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u8bca\u65ad\u4e0e\u63d0\u793a", None))
        self.detailsTabWidget.setTabText(self.detailsTabWidget.indexOf(self.modelDiagnosticsTab), QCoreApplication.translate("TskResultsPanelForm", u"\u6a21\u578b\u4e0e\u8bca\u65ad", None))
    # retranslateUi

