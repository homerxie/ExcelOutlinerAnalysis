"""Durable undo records for interrupted database saves, separate from scratch."""
from __future__ import annotations

from contextlib import contextmanager
import json
import logging
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import shutil
import stat
import tempfile

from .runtime_lease import RUNTIME_LEASE_FILENAME, RuntimeLease, is_redirected

RECOVERY_DIRNAME = ".save-recovery"
_MANIFEST = "manifest.json"
_LOGGER = logging.getLogger(__name__)


def _plain_tree(path: Path) -> None:
    """Reject redirection before copying/removing a recovery-owned tree."""
    pending = [path]
    while pending:
        current = pending.pop()
        info = current.lstat()
        if is_redirected(current):
            raise ValueError(f"Save recovery must not follow a link: {current}")
        if stat.S_ISDIR(info.st_mode):
            pending.extend(current.iterdir())
        elif not stat.S_ISREG(info.st_mode):
            raise ValueError(f"Save recovery requires ordinary files: {current}")


def _relative_path(value: str) -> Path:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError("Invalid relative save recovery path")
    path = PurePosixPath(value)
    if (path.is_absolute() or PureWindowsPath(value).drive or ":" in value
            or any(part in {"", ".", ".."} for part in value.split("/"))
            or path.parts[0] in {RECOVERY_DIRNAME, ".runtime"}):
        raise ValueError("Save recovery path must stay within its database")
    return Path(*path.parts)


def _checked_target(root: Path, relative: Path) -> Path:
    current = root
    for part in relative.parts:
        current /= part
        try:
            if is_redirected(current):
                raise ValueError(f"Save recovery target must not be a link: {current}")
        except FileNotFoundError:
            break
    return root / relative


def _copy_file(source, destination):
    with Path(source).open("rb") as original, Path(destination).open("wb") as output:
        shutil.copyfileobj(original, output, length=1024 * 1024)
        output.flush()
        os.fsync(output.fileno())
    shutil.copystat(source, destination)
    return str(destination)


def _copy(source: Path, target: Path) -> None:
    _plain_tree(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        shutil.copytree(source, target, copy_function=_copy_file)
    else:
        _copy_file(source, target)


def _retry_readonly_removal(function, path, error_info) -> None:
    error = error_info[1]
    if not isinstance(error, PermissionError):
        raise error
    candidate = Path(path)
    info = candidate.lstat()
    if is_redirected(candidate) or (stat.S_ISREG(info.st_mode) and info.st_nlink != 1):
        raise error
    # copy2-style metadata retains the Windows read-only flag. Undo/backup
    # deletion owns these entries, but must not change an external hard link.
    candidate.chmod(info.st_mode | stat.S_IWUSR)
    function(path)


def _remove(path: Path) -> None:
    try:
        _plain_tree(path)
    except FileNotFoundError:
        return
    if path.is_dir():
        shutil.rmtree(path, onerror=_retry_readonly_removal)
    else:
        try:
            path.unlink()
        except PermissionError as error:
            _retry_readonly_removal(os.unlink, path, (type(error), error, error.__traceback__))


def _check_recovery(directory: Path) -> None:
    if is_redirected(directory) or not directory.is_dir():
        raise ValueError("Database save recovery directory must be an ordinary directory")
    for child in directory.iterdir():
        if child.name == RUNTIME_LEASE_FILENAME:
            continue  # RuntimeLease validates the lock itself.
        if child.name not in {_MANIFEST, "backup", "restore"} and not (
                child.name.startswith(".manifest-") and child.name.endswith(".tmp")):
            raise ValueError(f"Unknown database save recovery entry: {child}")
        _plain_tree(child)
        if child.name in {"backup", "restore"} and not child.is_dir():
            raise ValueError(f"Invalid database save recovery directory: {child}")


def _write_manifest(directory: Path, manifest: dict) -> None:
    temporary = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=directory,
                                         prefix=".manifest-", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(manifest, handle, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, directory / _MANIFEST)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _read_manifest(directory: Path) -> dict | None:
    path = directory / _MANIFEST
    if not path.exists():
        return None
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
        if (not isinstance(manifest, dict) or set(manifest) != {"version", "phase", "entries"}
                or manifest["version"] != 1 or manifest["phase"] not in {"active", "committed"}
                or not isinstance(manifest["entries"], list)):
            raise ValueError("Invalid database save recovery manifest")
        seen = []
        for index, entry in enumerate(manifest["entries"]):
            if (not isinstance(entry, dict) or set(entry) != {"path", "present", "backup"}
                    or type(entry["present"]) is not bool or entry["backup"] != str(index)):
                raise ValueError("Invalid database save recovery entry")
            relative = _relative_path(entry["path"])
            if any(relative.is_relative_to(other) or other.is_relative_to(relative) for other in seen):
                raise ValueError("Overlapping database save recovery paths")
            seen.append(relative)
        return manifest
    except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
        raise ValueError(f"Cannot read database save recovery manifest: {path}") from error


def _clear_artifacts(directory: Path) -> None:
    # Keep the stable lease inode, including while another process waits on it.
    for name in ("restore", "backup"):
        _remove(directory / name)
    (directory / _MANIFEST).unlink(missing_ok=True)
    for path in directory.glob(".manifest-*.tmp"):
        _remove(path)


def _recover_locked(root: Path, directory: Path) -> bool:
    _check_recovery(directory)
    manifest = _read_manifest(directory)
    if manifest is None or manifest["phase"] == "committed":
        # No active manifest means backup preparation never touched the target.
        _clear_artifacts(directory)
        return False
    entries = manifest["entries"]
    # Validate every required backup before restoring any target entry.
    for entry in entries:
        _checked_target(root, _relative_path(entry["path"]))
        if entry["present"]:
            _plain_tree(directory / "backup" / entry["backup"])
    for entry in entries:
        target = _checked_target(root, _relative_path(entry["path"]))
        staged = directory / "restore" / entry["backup"]
        if entry["present"]:
            _remove(staged)
            _copy(directory / "backup" / entry["backup"], staged)
        _remove(target)
        if entry["present"]:
            target.parent.mkdir(parents=True, exist_ok=True)
            os.replace(staged, target)
    # Backups remain intact throughout rollback, so a second interruption can
    # safely restart every entry. Mark rollback complete before discarding them.
    _write_manifest(directory, {**manifest, "phase": "committed"})
    _clear_artifacts(directory)
    return True


def recover_database_save(database_root: str | Path) -> bool:
    """Undo an interrupted save; raise rather than fight a live saver or guess."""
    root = Path(database_root).resolve()
    directory = root / RECOVERY_DIRNAME
    try:
        directory.lstat()
    except FileNotFoundError:
        return False
    if is_redirected(directory) or not directory.is_dir():
        raise ValueError("Database save recovery directory must not be redirected")
    with RuntimeLease(directory, exclusive=True, blocking=False):
        return _recover_locked(root, directory)


class DatabaseSaveTransaction:
    def __init__(self, directory: Path, manifest: dict):
        self.directory = directory
        self.manifest = manifest
        self.committed = False

    def commit(self) -> None:
        _write_manifest(self.directory, {**self.manifest, "phase": "committed"})
        self.committed = True


@contextmanager
def database_save_transaction(database_root: str | Path, relative_paths):
    """Protect every target path until all data/state/runtime transfer succeeds."""
    root = Path(database_root).resolve()
    paths = sorted({_relative_path(str(path).replace(os.sep, "/")) for path in relative_paths},
                   key=lambda path: (len(path.parts), path.as_posix()))
    paths = [path for index, path in enumerate(paths)
             if not any(path.is_relative_to(parent) for parent in paths[:index])]
    directory = root / RECOVERY_DIRNAME
    root.mkdir(parents=True, exist_ok=True)
    try:
        if is_redirected(directory):
            raise ValueError("Database save recovery directory must not be redirected")
    except FileNotFoundError:
        pass
    directory.mkdir(exist_ok=True)
    with RuntimeLease(directory, exclusive=True, blocking=False):
        _recover_locked(root, directory)
        entries = []
        try:
            for index, relative in enumerate(paths):
                source = _checked_target(root, relative)
                present = source.exists()
                entry = {"path": relative.as_posix(), "present": present, "backup": str(index)}
                if present:
                    _copy(source, directory / "backup" / str(index))
                entries.append(entry)
            manifest = {"version": 1, "phase": "active", "entries": entries}
            _write_manifest(directory, manifest)
            transaction = DatabaseSaveTransaction(directory, manifest)
            yield transaction
            if not transaction.committed:
                _recover_locked(root, directory)
        except BaseException:
            _recover_locked(root, directory)
            raise
        else:
            try:
                _clear_artifacts(directory)
            except OSError as error:
                # A committed database is already durable. Retry housekeeping
                # on next open without misreporting the successful save.
                _LOGGER.warning("Could not remove committed save recovery files %s: %s", directory, error)
