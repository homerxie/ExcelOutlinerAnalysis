"""Short-lived application files owned by the currently opened database.

Every managed directory holds a shared OS lease throughout its lifetime. A
collector may reclaim abandoned directories only while exclusively owning that
same database lease. Durable snapshots and TSK history never live here.
"""
from __future__ import annotations

import errno
import json
import logging
import os
from pathlib import Path
import re
import shutil
import stat
from tempfile import TemporaryDirectory
import weakref

from .database_paths import WORKSPACE_MARKER_FILENAME, database_root_for_storage
from .runtime_lease import RUNTIME_LEASE_FILENAME, RuntimeLease, is_redirected


RUNTIME_DIRNAME = ".runtime"
RUNTIME_OWNER_FILENAME = ".runtime-owner.json"
_OWNER_RECORD = {"application": "excel-data-analysis", "runtime_version": 1}
_MANAGED_PREFIXES = (
    "analysis-template-", "analysis-result-", "import-template-", "restored-result-",
    "tsk-input-", "workbook-", "saved-", "save-files-", "tsk-sample-identities-",
)
_LOGGER = logging.getLogger(__name__)


def runtime_directory(storage_root: str | Path) -> Path:
    """Return the database-owned scratch parent, creating it when necessary."""
    root = database_root_for_storage(storage_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    directory = root / RUNTIME_DIRNAME
    try:
        if is_redirected(directory):
            raise ValueError("Database runtime directory must not be a symbolic link or junction")
    except FileNotFoundError:
        pass
    directory.mkdir(exist_ok=True)
    return directory


def _remove_owned_directory(name: str, lease: RuntimeLease, owner_pid: int,
                            *, ignore_errors: bool = False) -> None:
    try:
        # A fork inherits both the object and its descriptor, but it does not
        # inherit permission to retire files still owned by the parent.
        if os.getpid() == owner_pid:
            TemporaryDirectory._rmtree(name, ignore_errors=ignore_errors)
    finally:
        lease.close()


class _DatabaseTemporaryDirectory(TemporaryDirectory):
    def __init__(self, directory: Path, prefix: str):
        # Acquire before allocation: an exclusive collector cannot observe a
        # newly allocated directory before its owner has become protected.
        lease = RuntimeLease(directory)
        try:
            super().__init__(prefix=prefix, dir=directory)
            self._lease = lease
            self._owner_pid = os.getpid()
            self._finalizer.detach()
            self._finalizer = weakref.finalize(self, _remove_owned_directory, self.name, lease,
                                             self._owner_pid,
                                             ignore_errors=True)
            (Path(self.name) / RUNTIME_OWNER_FILENAME).write_text(
                json.dumps(_OWNER_RECORD), encoding="utf-8")
        except BaseException:
            if hasattr(self, "_lease"):
                self.cleanup()
            else:
                lease.close()
            raise

    def cleanup(self) -> None:
        if self._finalizer.detach() or Path(self.name).exists():
            _remove_owned_directory(self.name, self._lease, self._owner_pid)
        else:
            self._lease.close()


def temporary_database_directory(storage_root: str | Path, *, prefix: str) -> TemporaryDirectory:
    """Create leased scratch inside its database; refuse unprotected allocation."""
    return _DatabaseTemporaryDirectory(runtime_directory(storage_root), prefix)


def _managed_prefix(name: str) -> str | None:
    for prefix in _MANAGED_PREFIXES:
        if name.startswith(prefix) and re.fullmatch(r"[a-z0-9_]{8}", name[len(prefix):]):
            return prefix
    return None


def _remove_runtime_entry(path: Path) -> None:
    """Remove scratch without following links to files outside its owner."""
    info = path.lstat()
    if is_redirected(path):
        # Windows directory junctions/reparse points require rmdir; ordinary
        # symbolic links (including directory links on POSIX) require unlink.
        if stat.S_ISDIR(info.st_mode):
            path.rmdir()
        else:
            path.unlink()
    elif stat.S_ISDIR(info.st_mode):
        # rmtree does not traverse symbolic links or Windows junctions inside
        # the tree. Hard links are unlinked without changing their targets.
        shutil.rmtree(path)
    else:
        path.unlink()


def cleanup_database_runtime(storage_root: str | Path) -> list[Path]:
    """Remove all unused scratch, skipping the whole DB while any owner lives.

    Recover interrupted saves and preserve legacy originals first, then remove
    scratch irrespective of its name, age, or metadata. The permanent lease
    file alone survives so another process cannot acquire a different lock
    inode for the same database. Unproven ownership or failed recovery means
    no cleanup.
    """
    removed = []
    try:
        # An interrupted database save may have durable undo records. Restore
        # those before discarding any scratch from the interrupted session.
        from .database_save_recovery import recover_database_save
        root = database_root_for_storage(storage_root).resolve()
        directory = root / RUNTIME_DIRNAME
        if not directory.exists():
            recover_database_save(root)
            return removed
        if is_redirected(directory) or not directory.is_dir():
            _LOGGER.warning("Runtime cleanup refused redirected or invalid directory: %s", directory)
            return removed
        with RuntimeLease(directory, exclusive=True, blocking=False):
            recover_database_save(root)
            from .legacy_save_recovery import preserve_legacy_save_files
            # Older saves lacked a durable undo journal. Their staged input
            # files may be unique originals; preserve uncertain copies outside
            # scratch before sweeping all abandoned runtime entries.
            preserve_legacy_save_files(root, directory)
            for candidate in directory.iterdir():
                if candidate.name == RUNTIME_LEASE_FILENAME:
                    continue
                try:
                    _remove_runtime_entry(candidate)
                    removed.append(candidate)
                except FileNotFoundError:
                    # A previously removed entry needs no recovery.
                    continue
                except OSError as error:
                    # One inaccessible orphan must not block opening/closing
                    # or recovery of independent files and directories.
                    _LOGGER.warning("Could not remove runtime cache %s: %s", candidate, error)
    except OSError as error:
        # An active database owner is normal, and is the only occupancy proof
        # required. Unrelated processes and operating-system uptime play no role.
        if (error.errno not in {errno.EAGAIN, errno.EWOULDBLOCK}
                and getattr(error, "winerror", None) != 33):
            _LOGGER.warning("Could not clean database runtime for %s: %s", storage_root, error)
    except ValueError as error:
        _LOGGER.warning("Could not clean database runtime for %s: %s", storage_root, error)
    return removed


def database_root_for_snapshot(snapshot_path: str | Path) -> Path:
    """Locate a snapshot's owner without relying on the process directory.

    GUI snapshots have an explicit runtime or saved-analysis location. Older
    direct API callers may supply an arbitrary archive; its own directory is
    then the explicit local owner of temporary recovery files.
    """
    parent = Path(snapshot_path).absolute().parent
    markers = (WORKSPACE_MARKER_FILENAME, ".excel_data_analysis_gui_state.json",
               "datasets.jsonl", "measurements.jsonl", "measurements.jsonl.gz")
    for candidate in (parent, *parent.parents):
        if candidate.name == RUNTIME_DIRNAME:
            return candidate.parent
        if any((candidate / name).is_file() for name in markers):
            return database_root_for_storage(candidate)
        if candidate.name == "analysis" and candidate.parent.name == "result":
            return candidate.parent.parent
    return parent


def temporary_snapshot_directory(snapshot_path: str | Path, *, prefix: str) -> TemporaryDirectory:
    """Keep recovery scratch alongside the database that owns its archive."""
    return temporary_database_directory(database_root_for_snapshot(snapshot_path), prefix=prefix)
