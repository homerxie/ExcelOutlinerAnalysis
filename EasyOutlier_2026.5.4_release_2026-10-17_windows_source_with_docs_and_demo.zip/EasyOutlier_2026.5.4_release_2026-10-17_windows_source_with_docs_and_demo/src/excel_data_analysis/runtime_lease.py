"""Cross-process shared ownership for one database's private runtime files.

The lock file is permanent: unlinking it would let two processes lock different
inodes for the same database. No paths or process identifiers are persisted.
"""
from __future__ import annotations

import ctypes
import errno
import os
from pathlib import Path
import stat

RUNTIME_LEASE_FILENAME = ".runtime-lease.lock"


def is_redirected(path: Path) -> bool:
    """Include Windows junctions and other reparse points, not just symlinks."""
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def _lock_descriptor(descriptor: int, *, exclusive: bool, blocking: bool) -> None:
    if os.name == "posix":
        import fcntl
        operation = fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH
        fcntl.flock(descriptor, operation | (0 if blocking else fcntl.LOCK_NB))
        return
    if os.name == "nt":
        import msvcrt
        from ctypes import wintypes

        class OVERLAPPED(ctypes.Structure):
            _fields_ = [("Internal", ctypes.c_size_t), ("InternalHigh", ctypes.c_size_t),
                        ("Offset", wintypes.DWORD), ("OffsetHigh", wintypes.DWORD),
                        ("hEvent", wintypes.HANDLE)]

        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.LockFileEx.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD,
                                     wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(OVERLAPPED)]
        kernel.LockFileEx.restype = wintypes.BOOL
        # Synchronous file handles block for shared ownership, while the
        # collector's exclusive acquisition always fails immediately if busy.
        flags = (2 if exclusive else 0) | (0 if blocking else 1)
        if not kernel.LockFileEx(msvcrt.get_osfhandle(descriptor), flags, 0, 1, 0,
                                 ctypes.byref(OVERLAPPED())):
            raise ctypes.WinError(ctypes.get_last_error())
        return
    raise OSError(errno.ENOTSUP, "Runtime file locking is unavailable on this platform")


class RuntimeLease:
    """Hold an OS lease until closed; process death also releases ownership."""

    def __init__(self, directory: Path, *, exclusive: bool = False, blocking: bool = True):
        self._descriptor: int | None = None
        path = directory / RUNTIME_LEASE_FILENAME
        try:
            if is_redirected(path):
                raise OSError(errno.ELOOP, "Runtime lease must not be a link", str(path))
        except FileNotFoundError:
            pass
        descriptor = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        try:
            os.set_inheritable(descriptor, False)
            info = os.fstat(descriptor)
            current = path.lstat()
            if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or is_redirected(path)
                    or (info.st_dev, info.st_ino) != (current.st_dev, current.st_ino)):
                raise OSError(errno.EINVAL, "Runtime lease must be a private regular file", str(path))
            _lock_descriptor(descriptor, exclusive=exclusive, blocking=blocking)
        except BaseException:
            os.close(descriptor)
            raise
        self._descriptor = descriptor

    def close(self) -> None:
        if self._descriptor is not None:
            descriptor, self._descriptor = self._descriptor, None
            # Closing rather than explicitly unlocking also preserves a forked
            # child's inherited shared lease until its own descriptor closes.
            os.close(descriptor)

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        self.close()
