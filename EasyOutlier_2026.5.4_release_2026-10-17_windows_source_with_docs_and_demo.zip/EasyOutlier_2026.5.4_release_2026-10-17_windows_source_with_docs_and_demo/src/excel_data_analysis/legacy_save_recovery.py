"""Retain original files left by old, interrupted saves before runtime cleanup.

Old save-files directories contain copies named by GUI field, not a durable
destination journal. They must never be guessed back into a live database.
Call only while holding that database's exclusive runtime lease.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import shutil
import stat
from uuid import uuid4

from .runtime_lease import is_redirected


RECOVERED_SAVE_FILES_DIRNAME = "recovered-save-files"
DURABLE_SAVE_STAGING_MARKER = ".durable-save-staging"
_STAGED_NAME = re.compile(r"(?:[a-z][a-z0-9_]*_path|import_source_[0-9]+)\Z")
_LOGGER = logging.getLogger(__name__)
_NOTE = (
    "这些文件来自旧版本中断的数据库保存，可能是原文件的最后一份副本。"
    "原来的保存位置不能完全确认，因此保留在此供核对，没有覆盖当前数据库文件。"
    "所有文件路径均相对于本数据库目录。"
)


def _relative_path(value) -> Path | None:
    if not isinstance(value, str) or not value:
        return None
    normalized = value.replace("\\", "/")
    path = PurePosixPath(normalized)
    if (path.is_absolute() or PureWindowsPath(value).drive or not path.parts
            or ".." in path.parts or path.parts[0] in {".runtime", RECOVERED_SAVE_FILES_DIRNAME}
            or any(":" in part for part in path.parts)):
        return None
    return Path(*path.parts)


def _plain_path(root: Path, path: Path) -> bool:
    """Validate every ancestor so comparison/copying cannot follow a junction."""
    relative = path.relative_to(root)
    current = root
    for part in relative.parts:
        current /= part
        try:
            if is_redirected(current):
                return False
        except FileNotFoundError:
            return True
    return True


def _stored_paths(root: Path) -> dict[str, Path]:
    state = root / ".excel_data_analysis_gui_state.json"
    try:
        if not _plain_path(root, state):
            return {}
        payload = json.loads(state.read_text(encoding="utf-8"))
        values, bases = payload.get("paths", {}), payload.get("path_bases", {})
        output = {}
        if isinstance(values, dict) and isinstance(bases, dict):
            for name, value in values.items():
                relative = _relative_path(value)
                if bases.get(name) == "database" and relative is not None:
                    output[name] = relative
        summary = payload.get("current_results", {}).get("plot_inspector_snapshot", {})
        if isinstance(summary, dict):
            references = summary.get("portable_paths", {})
            if (isinstance(references, dict) and references.get("version") == 2
                    and references.get("base") == "database"
                    and "golden_path" in references.get("context", [])):
                relative = _relative_path(summary.get("context", {}).get("golden_path"))
                if relative is not None:
                    output["summary_golden_path"] = relative
        return output
    except (OSError, ValueError, TypeError, AttributeError, RecursionError):
        # Missing/damaged old settings are not evidence that a copy is redundant.
        return {}


def _same_content(first: Path, second: Path) -> bool:
    if not second.is_file() or first.stat().st_size != second.stat().st_size:
        return False
    with first.open("rb") as left, second.open("rb") as right:
        while data := left.read(1024 * 1024):
            if data != right.read(len(data)):
                return False
        return right.read(1) == b""


def _atomic_write(path: Path, write) -> None:
    temporary = path.with_name(f".{path.name}-{uuid4().hex}.tmp")
    try:
        with temporary.open("xb") as handle:
            write(handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        _sync_directory(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def _sync_directory(path: Path) -> None:
    if os.name != "nt":
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def _has_durable_save_marker(directory: Path) -> bool:
    # New saves publish their durable rollback journal before creating this
    # exact zero-byte regular marker. Normal owner metadata alone proves no
    # durability, and malformed markers must not suppress legacy recovery.
    marker = directory / DURABLE_SAVE_STAGING_MARKER
    try:
        info = marker.lstat()
        return not is_redirected(marker) and stat.S_ISREG(info.st_mode) and info.st_size == 0
    except FileNotFoundError:
        return False


def preserve_legacy_save_files(database_root: str | Path, runtime_dir: str | Path) -> list[Path]:
    """Copy uncertain staged originals into durable recovery, returning copies.

    Failure propagates so the caller cannot discard a possible sole surviving
    source. Ordinary analysis/pickle/workbook caches are never retained here.
    """
    root = Path(database_root).resolve()
    runtime = Path(runtime_dir).absolute()
    if runtime != root / ".runtime" or not _plain_path(root, runtime):
        raise ValueError("Legacy save recovery requires the database's own runtime directory")
    paths = None
    recovered = []
    for directory in runtime.iterdir():
        if (not directory.name.startswith("save-files-") or is_redirected(directory)
                or not directory.is_dir()):
            continue
        if _has_durable_save_marker(directory):
            continue
        entries = []
        for source in directory.iterdir():
            if (not _STAGED_NAME.fullmatch(source.name) or is_redirected(source)
                    or not stat.S_ISREG(source.lstat().st_mode)):
                continue
            if paths is None:
                paths = _stored_paths(root)
            intended = paths.get(source.name)
            if intended is not None:
                target = root / intended
                if _plain_path(root, target) and _same_content(source, target):
                    continue
            recovery = root / RECOVERED_SAVE_FILES_DIRNAME / directory.name
            if not _plain_path(root, recovery):
                raise ValueError("Recovered save files directory must not be a symbolic link or junction")
            recovery.mkdir(parents=True, exist_ok=True)
            target = recovery / source.name
            if not _plain_path(root, target):
                raise ValueError("Recovered save file must not be a symbolic link or junction")
            if target.exists() and not _same_content(source, target):
                digest = hashlib.sha256()
                with source.open("rb") as handle:
                    for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                        digest.update(chunk)
                target = target.with_name(f"{source.name}-{digest.hexdigest()}")
                if not _plain_path(root, target):
                    raise ValueError("Recovered save file must not be a symbolic link or junction")
            if not target.exists():
                def copy(handle):
                    with source.open("rb") as original:
                        shutil.copyfileobj(original, handle, length=1024 * 1024)
                _atomic_write(target, copy)
            elif not _same_content(source, target):
                raise ValueError("Conflicting recovered save copy must not be overwritten")
            entries.append({"staged_name": source.name,
                            "recovered_path": target.relative_to(root).as_posix(),
                            "intended_path": intended.as_posix() if intended is not None else None})
            recovered.append(target)
        if entries:
            manifest = root / RECOVERED_SAVE_FILES_DIRNAME / directory.name / "recovery.json"
            if not _plain_path(root, manifest):
                raise ValueError("Recovered save manifest must not be a symbolic link or junction")
            if manifest.exists():
                previous = json.loads(manifest.read_text(encoding="utf-8"))
                if (not isinstance(previous, dict) or previous.get("version") != 1
                        or previous.get("base") != "database" or not isinstance(previous.get("files"), list)):
                    raise ValueError("Existing recovered save manifest must not be overwritten")
                current_paths = {entry["recovered_path"] for entry in entries}
                entries = [entry for entry in previous["files"]
                           if isinstance(entry, dict) and entry.get("recovered_path") not in current_paths] + entries
            document = {"version": 1, "base": "database", "source_directory_name": directory.name,
                        "note": _NOTE, "files": entries}
            encoded = json.dumps(document, ensure_ascii=False, indent=2).encode("utf-8")
            _atomic_write(manifest, lambda handle: handle.write(encoded))
            _sync_directory(manifest.parent.parent)
            _sync_directory(root)
            _LOGGER.warning("Recovered original files from interrupted legacy save: %s", manifest.parent)
    return recovered
