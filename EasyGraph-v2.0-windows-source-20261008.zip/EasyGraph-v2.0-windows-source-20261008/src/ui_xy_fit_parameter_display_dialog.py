# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'xy_fit_parameter_display_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QDialog,
    QDialogButtonBox, QHBoxLayout, QHeaderView, QLabel,
    QPushButton, QSizePolicy, QSpacerItem, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget)

class Ui_XYFitParameterDisplayDialog(object):
    def setupUi(self, XYFitParameterDisplayDialog):
        if not XYFitParameterDisplayDialog.objectName():
            XYFitParameterDisplayDialog.setObjectName(u"XYFitParameterDisplayDialog")
        XYFitParameterDisplayDialog.setModal(True)
        XYFitParameterDisplayDialog.setMinimumSize(QSize(620, 420))
        self.verticalLayout = QVBoxLayout(XYFitParameterDisplayDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.hintLabel = QLabel(XYFitParameterDisplayDialog)
        self.hintLabel.setObjectName(u"hintLabel")
        self.hintLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.hintLabel)

        self.parameterTable = QTableWidget(XYFitParameterDisplayDialog)
        if (self.parameterTable.columnCount() < 4):
            self.parameterTable.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        self.parameterTable.setObjectName(u"parameterTable")
        self.parameterTable.setAlternatingRowColors(True)
        self.parameterTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.parameterTable.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.parameterTable.setColumnCount(4)

        self.verticalLayout.addWidget(self.parameterTable)

        self.selectionButtonsLayout = QHBoxLayout()
        self.selectionButtonsLayout.setObjectName(u"selectionButtonsLayout")
        self.clearAllButton = QPushButton(XYFitParameterDisplayDialog)
        self.clearAllButton.setObjectName(u"clearAllButton")

        self.selectionButtonsLayout.addWidget(self.clearAllButton)

        self.restoreDefaultsButton = QPushButton(XYFitParameterDisplayDialog)
        self.restoreDefaultsButton.setObjectName(u"restoreDefaultsButton")

        self.selectionButtonsLayout.addWidget(self.restoreDefaultsButton)

        self.selectionButtonsSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.selectionButtonsLayout.addItem(self.selectionButtonsSpacer)


        self.verticalLayout.addLayout(self.selectionButtonsLayout)

        self.validationLabel = QLabel(XYFitParameterDisplayDialog)
        self.validationLabel.setObjectName(u"validationLabel")
        self.validationLabel.setStyleSheet(u"color: #B42318;")
        self.validationLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.validationLabel)

        self.buttonBox = QDialogButtonBox(XYFitParameterDisplayDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(XYFitParameterDisplayDialog)
        self.buttonBox.rejected.connect(XYFitParameterDisplayDialog.reject)

        QMetaObject.connectSlotsByName(XYFitParameterDisplayDialog)
    # setupUi

    def retranslateUi(self, XYFitParameterDisplayDialog):
        XYFitParameterDisplayDialog.setWindowTitle(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Parameter Display Settings", None))
        self.hintLabel.setText(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Choose the fitted parameters to show on the chart for each result. The fit-results table always keeps every parameter available for comparison.", None))
        ___qtablewidgetitem = self.parameterTable.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Show", None))
        ___qtablewidgetitem1 = self.parameterTable.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Fit result", None))
        ___qtablewidgetitem2 = self.parameterTable.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Parameter", None))
        ___qtablewidgetitem3 = self.parameterTable.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Current value", None))
        self.clearAllButton.setText(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Clear All", None))
#if QT_CONFIG(tooltip)
        self.restoreDefaultsButton.setToolTip(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Restore all fitted parameters for every result.", None))
#endif // QT_CONFIG(tooltip)
        self.restoreDefaultsButton.setText(QCoreApplication.translate("XYFitParameterDisplayDialog", u"Restore Defaults", None))
        self.validationLabel.setText("")
    # retranslateUi
