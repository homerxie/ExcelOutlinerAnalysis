# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'grouped_order_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QDialog,
    QDialogButtonBox, QGroupBox, QHBoxLayout, QLabel,
    QListWidget, QListWidgetItem, QPushButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_GroupedOrderDialog(object):
    def setupUi(self, GroupedOrderDialog):
        if not GroupedOrderDialog.objectName():
            GroupedOrderDialog.setObjectName(u"GroupedOrderDialog")
        GroupedOrderDialog.resize(720, 480)
        GroupedOrderDialog.setMinimumSize(QSize(640, 440))
        GroupedOrderDialog.setModal(True)
        self.verticalLayout = QVBoxLayout(GroupedOrderDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.hintLabel = QLabel(GroupedOrderDialog)
        self.hintLabel.setObjectName(u"hintLabel")
        self.hintLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.hintLabel)

        self.listsLayout = QHBoxLayout()
        self.listsLayout.setObjectName(u"listsLayout")
        self.outerGroupBox = QGroupBox(GroupedOrderDialog)
        self.outerGroupBox.setObjectName(u"outerGroupBox")
        self.outerLayout = QVBoxLayout(self.outerGroupBox)
        self.outerLayout.setObjectName(u"outerLayout")
        self.outerHintLabel = QLabel(self.outerGroupBox)
        self.outerHintLabel.setObjectName(u"outerHintLabel")
        self.outerHintLabel.setWordWrap(True)

        self.outerLayout.addWidget(self.outerHintLabel)

        self.outerList = QListWidget(self.outerGroupBox)
        self.outerList.setObjectName(u"outerList")
        self.outerList.setDragDropMode(QAbstractItemView.InternalMove)
        self.outerList.setDefaultDropAction(Qt.MoveAction)
        self.outerList.setDragDropOverwriteMode(False)
        self.outerList.setSelectionMode(QAbstractItemView.ExtendedSelection)

        self.outerLayout.addWidget(self.outerList)

        self.outerButtonsLayout = QHBoxLayout()
        self.outerButtonsLayout.setObjectName(u"outerButtonsLayout")
        self.outerUpButton = QPushButton(self.outerGroupBox)
        self.outerUpButton.setObjectName(u"outerUpButton")

        self.outerButtonsLayout.addWidget(self.outerUpButton)

        self.outerDownButton = QPushButton(self.outerGroupBox)
        self.outerDownButton.setObjectName(u"outerDownButton")

        self.outerButtonsLayout.addWidget(self.outerDownButton)


        self.outerLayout.addLayout(self.outerButtonsLayout)


        self.listsLayout.addWidget(self.outerGroupBox)

        self.innerGroupBox = QGroupBox(GroupedOrderDialog)
        self.innerGroupBox.setObjectName(u"innerGroupBox")
        self.innerLayout = QVBoxLayout(self.innerGroupBox)
        self.innerLayout.setObjectName(u"innerLayout")
        self.innerHintLabel = QLabel(self.innerGroupBox)
        self.innerHintLabel.setObjectName(u"innerHintLabel")
        self.innerHintLabel.setWordWrap(True)

        self.innerLayout.addWidget(self.innerHintLabel)

        self.innerList = QListWidget(self.innerGroupBox)
        self.innerList.setObjectName(u"innerList")
        self.innerList.setDragDropMode(QAbstractItemView.InternalMove)
        self.innerList.setDefaultDropAction(Qt.MoveAction)
        self.innerList.setDragDropOverwriteMode(False)
        self.innerList.setSelectionMode(QAbstractItemView.ExtendedSelection)

        self.innerLayout.addWidget(self.innerList)

        self.innerButtonsLayout = QHBoxLayout()
        self.innerButtonsLayout.setObjectName(u"innerButtonsLayout")
        self.innerUpButton = QPushButton(self.innerGroupBox)
        self.innerUpButton.setObjectName(u"innerUpButton")

        self.innerButtonsLayout.addWidget(self.innerUpButton)

        self.innerDownButton = QPushButton(self.innerGroupBox)
        self.innerDownButton.setObjectName(u"innerDownButton")

        self.innerButtonsLayout.addWidget(self.innerDownButton)


        self.innerLayout.addLayout(self.innerButtonsLayout)


        self.listsLayout.addWidget(self.innerGroupBox)

        self.listsLayout.setStretch(0, 1)
        self.listsLayout.setStretch(1, 1)

        self.verticalLayout.addLayout(self.listsLayout)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.tableOrderButton = QPushButton(GroupedOrderDialog)
        self.tableOrderButton.setObjectName(u"tableOrderButton")

        self.buttonLayout.addWidget(self.tableOrderButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.buttonLayout.addItem(self.horizontalSpacer)

        self.buttonBox = QDialogButtonBox(GroupedOrderDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.buttonLayout.addWidget(self.buttonBox)


        self.verticalLayout.addLayout(self.buttonLayout)


        self.retranslateUi(GroupedOrderDialog)
        self.buttonBox.accepted.connect(GroupedOrderDialog.accept)
        self.buttonBox.rejected.connect(GroupedOrderDialog.reject)

        QMetaObject.connectSlotsByName(GroupedOrderDialog)
    # setupUi

    def retranslateUi(self, GroupedOrderDialog):
        GroupedOrderDialog.setWindowTitle(QCoreApplication.translate("GroupedOrderDialog", u"Edit Group Order", None))
        self.hintLabel.setText(QCoreApplication.translate("GroupedOrderDialog", u"Reorder whole groups on the left, or columns within a group on the right. The table and group membership stay unchanged.", None))
        self.outerGroupBox.setTitle(QCoreApplication.translate("GroupedOrderDialog", u"Groups and ungrouped columns", None))
        self.outerHintLabel.setText(QCoreApplication.translate("GroupedOrderDialog", u"Drag to reorder, or select items and use the buttons.", None))
#if QT_CONFIG(accessibility)
        self.outerList.setAccessibleName(QCoreApplication.translate("GroupedOrderDialog", u"Groups and ungrouped columns", None))
#endif // QT_CONFIG(accessibility)
        self.outerUpButton.setText(QCoreApplication.translate("GroupedOrderDialog", u"Move up", None))
        self.outerDownButton.setText(QCoreApplication.translate("GroupedOrderDialog", u"Move down", None))
        self.innerGroupBox.setTitle(QCoreApplication.translate("GroupedOrderDialog", u"Within selected group", None))
        self.innerHintLabel.setText(QCoreApplication.translate("GroupedOrderDialog", u"Select one parent group to reorder its columns.", None))
#if QT_CONFIG(accessibility)
        self.innerList.setAccessibleName(QCoreApplication.translate("GroupedOrderDialog", u"Columns within the selected group", None))
#endif // QT_CONFIG(accessibility)
        self.innerUpButton.setText(QCoreApplication.translate("GroupedOrderDialog", u"Move up", None))
        self.innerDownButton.setText(QCoreApplication.translate("GroupedOrderDialog", u"Move down", None))
        self.tableOrderButton.setText(QCoreApplication.translate("GroupedOrderDialog", u"Table Order", None))
    # retranslateUi

