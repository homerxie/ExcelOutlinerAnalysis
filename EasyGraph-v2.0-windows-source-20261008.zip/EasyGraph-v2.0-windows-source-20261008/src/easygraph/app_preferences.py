from __future__ import annotations

import os
import sys
from pathlib import Path

from PySide6.QtCore import QLocale, QSettings, QTranslator
from PySide6.QtWidgets import QApplication


APP_DIR = Path(__file__).resolve().parents[2]
TRANSLATION_DIR = APP_DIR / "translations"
LANGUAGE_ENV_VAR = "EASYGRAPH_LANGUAGE"
LANGUAGE_SETTING_KEY = "language"
THEME_SETTING_KEY = "theme"
AUTO_RECOVERY_INTERVAL_SETTING_KEY = "autoRecoveryIntervalSeconds"
DEFAULT_AUTO_RECOVERY_INTERVAL_SECONDS = 2
MIN_AUTO_RECOVERY_INTERVAL_SECONDS = 1
MAX_AUTO_RECOVERY_INTERVAL_SECONDS = 60
RECENT_PROJECTS_SETTING_KEY = "recentProjects"
MAX_RECENT_PROJECTS = 10
RECENT_PROJECT_EMPTY_LABEL = "No Recent Projects"
RECENT_PROJECT_CLEAR_LABEL = "Clear Recent Projects"


def normalize_language_code(language: str | None) -> str:
    if not language:
        return "system"
    code = language.strip().replace("-", "_")
    if code in {"system", "en", "zh_CN"}:
        return code
    if code.lower().startswith("zh"):
        return "zh_CN"
    if code.lower().startswith("en"):
        return "en"
    return "system"


def easygraph_settings() -> QSettings:
    return QSettings("EasyGraph", "EasyGraph")


def stored_language_preference() -> str:
    settings = easygraph_settings()
    return normalize_language_code(str(settings.value(LANGUAGE_SETTING_KEY, "system")))


def save_language_preference(language: str) -> None:
    settings = easygraph_settings()
    settings.setValue(LANGUAGE_SETTING_KEY, normalize_language_code(language))


def normalize_theme_name(theme: str | None) -> str:
    return "light" if str(theme or "").strip().lower() == "light" else "dark"


def stored_theme_preference() -> str:
    settings = easygraph_settings()
    return normalize_theme_name(str(settings.value(THEME_SETTING_KEY, "dark")))


def save_theme_preference(theme: str) -> None:
    settings = easygraph_settings()
    settings.setValue(THEME_SETTING_KEY, normalize_theme_name(theme))


def normalize_auto_recovery_interval(value) -> int:
    try:
        seconds = int(value)
    except (TypeError, ValueError):
        seconds = DEFAULT_AUTO_RECOVERY_INTERVAL_SECONDS
    return min(
        MAX_AUTO_RECOVERY_INTERVAL_SECONDS,
        max(MIN_AUTO_RECOVERY_INTERVAL_SECONDS, seconds),
    )


def stored_auto_recovery_interval() -> int:
    settings = easygraph_settings()
    return normalize_auto_recovery_interval(
        settings.value(
            AUTO_RECOVERY_INTERVAL_SETTING_KEY,
            DEFAULT_AUTO_RECOVERY_INTERVAL_SECONDS,
        )
    )


def save_auto_recovery_interval(seconds: int) -> None:
    settings = easygraph_settings()
    settings.setValue(
        AUTO_RECOVERY_INTERVAL_SETTING_KEY,
        normalize_auto_recovery_interval(seconds),
    )


def _settings_string_list(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [str(item) for item in value if str(item)]
    text = str(value)
    return [text] if text else []


def _project_path_key(path: Path) -> str:
    return os.path.normcase(str(Path(path).expanduser()))


def normalized_recent_project_paths(paths) -> list[Path]:
    recent: list[Path] = []
    seen: set[str] = set()
    for raw_path in paths:
        if not raw_path:
            continue
        path = Path(str(raw_path)).expanduser()
        key = _project_path_key(path)
        if key in seen:
            continue
        recent.append(path)
        seen.add(key)
        if len(recent) >= MAX_RECENT_PROJECTS:
            break
    return recent


def stored_recent_project_paths() -> list[Path]:
    settings = easygraph_settings()
    return normalized_recent_project_paths(_settings_string_list(settings.value(RECENT_PROJECTS_SETTING_KEY, [])))


def save_recent_project_paths(paths) -> None:
    settings = easygraph_settings()
    settings.setValue(RECENT_PROJECTS_SETTING_KEY, [str(path) for path in normalized_recent_project_paths(paths)])


def remember_recent_project(path: Path) -> None:
    project_path = Path(path).expanduser()
    save_recent_project_paths([project_path, *stored_recent_project_paths()])


def forget_recent_project(path: Path) -> None:
    key = _project_path_key(Path(path))
    save_recent_project_paths([recent_path for recent_path in stored_recent_project_paths() if _project_path_key(recent_path) != key])


def recent_project_empty_label() -> str:
    return RECENT_PROJECT_EMPTY_LABEL


def recent_project_clear_label() -> str:
    return RECENT_PROJECT_CLEAR_LABEL


def recent_project_menu_item(index: int, path: Path) -> tuple[str, str]:
    path_text = str(path)
    shortcut_prefix = f"&{index} " if index < 10 else ""
    return f"{shortcut_prefix}{path_text}", path_text


def effective_language_code(language: str | None = None) -> str:
    preference = normalize_language_code(os.environ.get(LANGUAGE_ENV_VAR) or language or stored_language_preference())
    if preference == "system":
        return normalize_language_code(QLocale.system().name())
    return preference


def translation_directory() -> Path:
    """Return the translations directory in source and PyInstaller builds."""

    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / "translations"
    return TRANSLATION_DIR


def install_app_translator(app: QApplication, language: str | None = None) -> str:
    code = effective_language_code(language)
    if code == "en":
        return code

    translator = QTranslator(app)
    translation_file = translation_directory() / f"easygraph_{code}.qm"
    if translator.load(str(translation_file)):
        app.installTranslator(translator)
        app._easygraph_translator = translator
    return code
