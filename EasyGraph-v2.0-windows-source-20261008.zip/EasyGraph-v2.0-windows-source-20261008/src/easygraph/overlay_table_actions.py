from __future__ import annotations

from dataclasses import dataclass

from easygraph.table_data import (
    append_custom_overlay_series,
    custom_overlay_state_from_series,
    reindex_hidden_overlay_indexes,
    remove_custom_overlay_series,
)


@dataclass(frozen=True)
class OverlayRemovalState:
    series: list[dict]
    hidden_indexes: list[int]
    count: int
    enabled: bool


def overlay_table_state_after_add(series: list[dict]) -> tuple[list[dict], int, bool]:
    updated = append_custom_overlay_series(series)
    count, enabled = custom_overlay_state_from_series(updated)
    return updated, count, enabled


def overlay_table_state_after_remove(series: list[dict], hidden_indexes: list[int], index: int) -> OverlayRemovalState:
    updated = remove_custom_overlay_series(series, index)
    hidden = reindex_hidden_overlay_indexes(hidden_indexes, index)
    count, enabled = custom_overlay_state_from_series(updated)
    return OverlayRemovalState(
        series=updated,
        hidden_indexes=hidden,
        count=count,
        enabled=enabled,
    )


def overlay_table_state_after_rename(series: list[dict], row: int, name: str) -> list[dict]:
    index = row - 1
    updated = list(series)
    while len(updated) <= index:
        updated.append({"name": f"Overlay {len(updated) + 1}", "values": {}})
    normalized = name.strip() or f"Overlay {row}"
    updated[index] = {**updated[index], "name": normalized}
    return updated
