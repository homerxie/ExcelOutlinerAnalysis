from __future__ import annotations

import pandas as pd
from PySide6.QtCore import QEvent, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QStyledItemDelegate,
    QTableView,
    QWidget,
)

from easygraph.table_model import EasyGraphTableModel
from easygraph.ui.group_header import GroupHeaderView


class DataTableItemDelegate(QStyledItemDelegate):
    """Coordinate inline-editor navigation before Qt's default handling."""

    navigation_requested = Signal(QWidget, object)

    def eventFilter(self, editor, event) -> bool:
        if event.type() == QEvent.Type.KeyPress:
            # Give the table controller first chance to commit and navigate.
            # Returning True here prevents QStyledItemDelegate from attempting
            # a second commit for the same editor.
            event.ignore()
            self.navigation_requested.emit(editor, event)
            if event.isAccepted():
                return True
        return super().eventFilter(editor, event)


class DataTable(QTableView):
    """QTableView configured around EasyGraph's dataframe-backed table model."""

    headerCellDoubleClicked = Signal(int)

    def __init__(self, rows=0, columns=0, parent=None) -> None:
        if not isinstance(rows, int):
            parent = rows
            rows = 0
            columns = 0
        super().__init__(parent)
        self.setHorizontalHeader(GroupHeaderView(self))
        self.table_model = EasyGraphTableModel(self)
        self.setModel(self.table_model)
        self.table_item_delegate = DataTableItemDelegate(self)
        self.setItemDelegate(self.table_item_delegate)
        self.setAlternatingRowColors(True)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.horizontalHeader().setObjectName("dataTableHorizontalHeader")
        self.verticalHeader().setObjectName("dataTableVerticalHeader")
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        if rows or columns:
            self.table_model.resize(rows, columns)

    def set_dataframe(self, df: pd.DataFrame, overlay_series: list[dict] | None = None) -> None:
        self.table_model.replace_from_dataframe(df, list(overlay_series or []))

    def dataframe(self) -> pd.DataFrame:
        return self.table_model.sample_dataframe()

    def mouseDoubleClickEvent(self, event) -> None:
        index = self.indexAt(event.position().toPoint())
        if index.isValid() and index.row() == 0:
            self.setCurrentIndex(index)
            self.headerCellDoubleClicked.emit(index.column())
            event.accept()
            return
        super().mouseDoubleClickEvent(event)
