"""Parse table numbers while preserving percentage text in the source data."""

from __future__ import annotations

import math
import re
from collections.abc import Iterable

import pandas as pd


_PERCENTAGE = re.compile(
    r"\s*([+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?)\s*[%％]\s*"
)


def _percentage_value(value: object) -> float | None:
    if isinstance(value, str) and (match := _PERCENTAGE.fullmatch(value)):
        number = float(match.group(1)) / 100.0
        if math.isfinite(number):
            return number
    return None


def _numeric_input(value: object) -> object:
    percentage = _percentage_value(value)
    return value if percentage is None else percentage


def coerce_numeric_value(value: object):
    """Read a scalar number, with ``25%`` interpreted as ``0.25``."""
    return pd.to_numeric(_numeric_input(value), errors="coerce")


def coerce_numeric_series(values: pd.Series) -> pd.Series:
    """Read numbers without modifying source text, index, or missing values."""
    source = values if pd.api.types.is_numeric_dtype(values.dtype) else values.map(_numeric_input)
    return pd.to_numeric(source, errors="coerce")


def has_percentage_values(values: Iterable[object]) -> bool:
    """Whether data contains a valid explicit percentage for axis formatting."""
    return any(_percentage_value(value) is not None for value in values)
