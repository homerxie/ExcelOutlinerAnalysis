from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication

from easygraph.app_icon import configure_application_icon
from easygraph.app_preferences import normalize_theme_name, stored_theme_preference

os.environ.setdefault(
    "MPLCONFIGDIR",
    str(Path(tempfile.gettempdir()) / "easygraph_matplotlib"),
)
Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)

try:
    import qdarktheme
except ImportError:
    qdarktheme = None


MATPLOTLIB_FONT_FAMILY_CANDIDATES = [
    # Microsoft YaHei is installed with Windows 10/11 and has Chinese glyphs.
    # Keep it first so Matplotlib never selects Latin-only Segoe UI for charts.
    "Microsoft YaHei",
    "Microsoft YaHei UI",
    "Segoe UI",
    "SimHei",
    "Noto Sans CJK SC",
    "Source Han Sans SC",
    "PingFang SC",
    "Heiti SC",
    "Hiragino Sans GB",
    "Songti SC",
    "Arial Unicode MS",
    "WenQuanYi Micro Hei",
    "DejaVu Sans",
]


def configure_matplotlib_fonts() -> str:
    global DEFAULT_FONT_FAMILY

    if DEFAULT_FONT_FAMILY is not None:
        return DEFAULT_FONT_FAMILY

    from matplotlib import font_manager, rcParams

    candidates = MATPLOTLIB_FONT_FAMILY_CANDIDATES
    available = {font.name for font in font_manager.fontManager.ttflist}
    selected = next((name for name in candidates if name in available), "DejaVu Sans")
    rcParams["font.family"] = "sans-serif"
    rcParams["font.sans-serif"] = [selected] + [name for name in candidates if name != selected]
    rcParams["axes.unicode_minus"] = False
    DEFAULT_FONT_FAMILY = selected
    return selected


DEFAULT_FONT_FAMILY: str | None = None
QT_FONT_FAMILY_CANDIDATES = [
    # Segoe UI matches the native Windows interface metrics. Keep Microsoft
    # YaHei UI immediately after it as the preferred Chinese fallback.
    "Segoe UI",
    "Microsoft YaHei UI",
    "Microsoft YaHei",
    "Arial",
    "Helvetica Neue",
    "Helvetica",
    "PingFang SC",
    "Noto Sans CJK SC",
    "Lucida Grande",
]
WINDOWS_BASE_FONT_PROPERTY = "easygraphWindowsBaseFont"
GENERIC_QT_FONT_FAMILIES = frozenset({"sans serif", "serif", "monospace"})
COMPACT_SPIN_TEXT_PADDING = 12
MENU_HIGHLIGHT_RADIUS = 4
OFFICE_FONT_SIZE_STEPS = [
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    14,
    16,
    18,
    20,
    22,
    24,
    26,
    28,
    30,
    32,
    34,
    36,
    40,
    44,
    48,
    52,
    56,
    60,
    66,
    72,
]
MENU_HIGHLIGHT_STYLE = f"""
QMenuBar::item:selected,
QMenuBar::item:pressed {{
    border-radius: {MENU_HIGHLIGHT_RADIUS}px;
}}

QComboBox QAbstractItemView::item:selected,
QComboBox QAbstractItemView::item:selected:!active,
QComboBox QAbstractItemView::item:selected:!focus,
QComboBox QAbstractItemView::item:!selected:hover,
QComboBox::item:selected {{
    border-radius: {MENU_HIGHLIGHT_RADIUS}px;
}}
"""
APP_THEME_OVERRIDES = """
QComboBox,
QSpinBox,
QDoubleSpinBox,
QPushButton {
    border-radius: 6px;
    min-height: 20px;
    max-height: 20px;
}

QComboBox {
    padding: 2px 20px 2px 10px;
}

QSpinBox,
QDoubleSpinBox {
    padding: 2px 18px 2px 8px;
}

QPushButton {
    padding: 2px 10px;
}

QPushButton#chartElementsButton::menu-indicator {
    image: none;
    width: 0px;
    height: 0px;
}

QToolButton#analysisResultsFilterButton {
    padding: 0;
}

QToolButton {
    border-radius: 6px;
}

QComboBox::drop-down {
    width: 16px;
    border-top-right-radius: 6px;
    border-bottom-right-radius: 6px;
}

QComboBox QAbstractItemView {
    border: 0;
    border-radius: 6px;
    padding: 4px;
    outline: 0;
}

QMenu {
    border-radius: 6px;
    padding: 4px;
}

QMenu::item {
    border-radius: __MENU_HIGHLIGHT_RADIUS__px;
    padding: 4px 20px;
}
""".replace(
    "__MENU_HIGHLIGHT_RADIUS__", str(MENU_HIGHLIGHT_RADIUS)
) + MENU_HIGHLIGHT_STYLE
THEME_COLOR_OVERRIDES = {
    "light": """
QWidget {
    color: #000000;
}

QToolButton {
    border: 1px solid #DADCE0;
}

QPushButton:enabled,
QTabBar::tab:selected:enabled {
    color: #0081DB;
}

QScrollArea#plotPreviewScroll,
QScrollArea#plotPreviewScroll QWidget#qt_scrollarea_viewport,
QLabel#plotPreviewPlaceholder {
    background-color: #E9EDF2;
    color: #000000;
    border: 0;
}

QTableView#dataTable,
QTableView#analysisResultsTable {
    border: 1px solid #C8D0D9;
    gridline-color: #C8D0D9;
    selection-background-color: #B5CAF4;
    selection-color: #000000;
}

QComboBox QAbstractItemView {
    selection-background-color: #B5CAF4;
    selection-color: #000000;
}

QTableView#dataTable::item:selected,
QTableView#dataTable::item:selected:!active,
QTableView#dataTable::item:selected:!focus,
QTableView#analysisResultsTable::item:selected,
QTableView#analysisResultsTable::item:selected:!active,
QTableView#analysisResultsTable::item:selected:!focus,
QComboBox QAbstractItemView::item:selected,
QComboBox QAbstractItemView::item:selected:!active,
QComboBox QAbstractItemView::item:selected:!focus,
QComboBox::item:selected {
    background: #B5CAF4;
    color: #000000;
}

QComboBox QAbstractItemView::item:!selected:hover {
    background: #D3D3D3;
    color: #000000;
}

QHeaderView#dataTableHorizontalHeader,
QHeaderView#dataTableVerticalHeader,
QHeaderView#analysisResultsHorizontalHeader,
QHeaderView#analysisResultsVerticalHeader {
    background: #E7EBF0;
    border: 0;
    border-radius: 0;
}

QToolButton#analysisResultsFilterButton {
    background: #E7EBF0;
    color: #000000;
}

QHeaderView#dataTableHorizontalHeader::section,
QHeaderView#dataTableVerticalHeader::section,
QHeaderView#analysisResultsHorizontalHeader::section,
QHeaderView#analysisResultsVerticalHeader::section {
    background: #E7EBF0;
    color: #000000;
    border: 0;
    border-radius: 0;
}

QHeaderView#dataTableHorizontalHeader::section,
QHeaderView#analysisResultsHorizontalHeader::section {
    margin-right: 0;
    border-right: 1px solid #C8D0D9;
    border-bottom: 1px solid #C8D0D9;
}

QHeaderView#dataTableVerticalHeader::section,
QHeaderView#analysisResultsVerticalHeader::section {
    margin-bottom: 0;
    border-right: 1px solid #C8D0D9;
    border-bottom: 1px solid #C8D0D9;
}

QTableView#dataTable QTableCornerButton::section,
QTableView#analysisResultsTable QTableCornerButton::section {
    background: #E7EBF0;
    border: 0;
    border-radius: 0;
    border-right: 1px solid #C8D0D9;
    border-bottom: 1px solid #C8D0D9;
}
""",
    "dark": """
QToolButton {
    border: 1px solid #3F4042;
}

QScrollArea#plotPreviewScroll,
QScrollArea#plotPreviewScroll QWidget#qt_scrollarea_viewport,
QLabel#plotPreviewPlaceholder {
    background-color: #2F2F2F;
    color: #9CA3AF;
    border: 0;
}

QComboBox QAbstractItemView {
    selection-background-color: #004875;
    selection-color: #E4E7EB;
}

QComboBox QAbstractItemView::item:selected,
QComboBox QAbstractItemView::item:selected:!active,
QComboBox QAbstractItemView::item:selected:!focus,
QComboBox::item:selected {
    background: #004875;
    color: #E4E7EB;
}

QComboBox QAbstractItemView::item:!selected:hover {
    background: #292D2E;
    color: #E4E7EB;
}
""",
}
COMPACT_SPIN_STYLE = """
QSpinBox {
    padding: 2px 0 2px 6px;
}

QSpinBox::up-button {
    subcontrol-origin: border;
    subcontrol-position: top right;
    width: 18px;
}

QSpinBox::down-button {
    subcontrol-origin: border;
    subcontrol-position: bottom right;
    width: 18px;
}

QDoubleSpinBox {
    padding: 2px 0 2px 6px;
}

QDoubleSpinBox::up-button {
    subcontrol-origin: border;
    subcontrol-position: top right;
    width: 18px;
}

QDoubleSpinBox::down-button {
    subcontrol-origin: border;
    subcontrol-position: bottom right;
    width: 18px;
}
"""


def configure_qt_application_font(
    app: QApplication,
    *,
    platform_name: str | None = None,
) -> str:
    available = set(QFontDatabase.families())
    platform_name = platform_name or sys.platform
    if platform_name.startswith("win"):
        base_font = app.property(WINDOWS_BASE_FONT_PROPERTY)
        if not isinstance(base_font, QFont):
            base_font = QFont(app.font())
            app.setProperty(WINDOWS_BASE_FONT_PROPERTY, QFont(base_font))
        base_family = base_font.family()
        selected = (
            base_family
            if base_family in available
            and base_family.casefold() not in GENERIC_QT_FONT_FAMILIES
            else next(
                (family for family in QT_FONT_FAMILY_CANDIDATES if family in available),
                next(iter(available), base_family),
            )
        )
        configured_font = QFont(base_font)
        configured_font.setFamilies(
            [
                selected,
                *[
                    family
                    for family in ("Microsoft YaHei UI", "Microsoft YaHei")
                    if family in available and family != selected
                ],
            ]
        )
        app.setFont(configured_font)
        return selected

    selected = next(
        (family for family in QT_FONT_FAMILY_CANDIDATES if family in available),
        next(iter(available), app.font().family()),
    )
    app.setFont(QFont(selected))
    return selected


def apply_app_theme(app: QApplication, theme: str | None = None) -> bool:
    selected_theme = normalize_theme_name(theme or stored_theme_preference())
    configure_application_icon(app, selected_theme)
    base_stylesheet = qdarktheme.load_stylesheet(selected_theme) if qdarktheme is not None else ""
    app.setStyleSheet(
        f"{base_stylesheet}\n{APP_THEME_OVERRIDES}\n{THEME_COLOR_OVERRIDES[selected_theme]}"
    )
    configure_qt_application_font(app)
    return qdarktheme is not None


def office_adjacent_font_size(current: int, direction: int, minimum: int, maximum: int) -> int:
    if direction > 0:
        candidates = [size for size in OFFICE_FONT_SIZE_STEPS if size > current]
        target = candidates[0] if candidates else maximum
    else:
        candidates = [size for size in OFFICE_FONT_SIZE_STEPS if size < current]
        target = candidates[-1] if candidates else minimum
    return min(max(target, minimum), maximum)
