from __future__ import annotations

from dataclasses import dataclass, field

from easygraph.table_history import TableHistoryState


@dataclass
class SheetSessionState:
    history: TableHistoryState = field(default_factory=TableHistoryState)
    xy_shared_histories: dict[str, TableHistoryState] = field(default_factory=dict)
    xy_paired_history: TableHistoryState = field(default_factory=TableHistoryState)
    current_row: int = 0
    current_column: int = 0
    horizontal_scroll: int = 0
    vertical_scroll: int = 0


__all__ = ["SheetSessionState"]
