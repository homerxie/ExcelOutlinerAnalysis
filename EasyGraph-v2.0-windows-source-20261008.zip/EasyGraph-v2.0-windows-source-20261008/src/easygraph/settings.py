from __future__ import annotations

import math
from dataclasses import dataclass, field

from easygraph.additional_guides import normalize_additional_guides
from easygraph.statistic_formats import normalize_statistic_formats

LEGEND_POSITION_RIGHT = "right"
LEGEND_POSITION_INSIDE = "inside"
LEGEND_INSIDE_AUTO_POSITION = -1.0

PRESETS = {
    "Paper Clean": {
        "palette": ["#4E79A7", "#E15759", "#59A14F", "#F28E2B", "#B07AA1"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.72,
    },
    "Nature Style": {
        "palette": ["#3B6EA8", "#C44E52", "#55A868", "#8172B3", "#CCB974"],
        "background": "#FFFFFF",
        "grid": False,
        "font_size": 9,
        "line_width": 0.9,
        "point_alpha": 0.68,
    },
    "Presentation": {
        "palette": ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#F0E442"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 14,
        "line_width": 1.8,
        "point_alpha": 0.8,
    },
    "Colorblind Safe": {
        "palette": ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.75,
    },
    "Okabe-Ito": {
        "palette": ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9", "#F0E442", "#000000"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.76,
    },
    "Tableau 10": {
        "palette": ["#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F", "#EDC948", "#B07AA1", "#FF9DA7", "#9C755F", "#BAB0AC"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.74,
    },
    "Brewer Set2": {
        "palette": ["#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.05,
        "point_alpha": 0.72,
    },
    "Brewer Dark2": {
        "palette": ["#1B9E77", "#D95F02", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D", "#666666"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.15,
        "point_alpha": 0.74,
    },
    "Brewer Paired": {
        "palette": ["#A6CEE3", "#1F78B4", "#B2DF8A", "#33A02C", "#FB9A99", "#E31A1C", "#FDBF6F", "#FF7F00", "#CAB2D6", "#6A3D9A"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.05,
        "point_alpha": 0.72,
    },
    "Viridis": {
        "palette": ["#440154", "#482878", "#3E4989", "#31688E", "#26828E", "#1F9E89", "#35B779", "#6DCD59", "#B4DE2C", "#FDE725"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.75,
    },
    "Cividis": {
        "palette": ["#00204D", "#123570", "#3B496C", "#575D6D", "#707173", "#8A8678", "#A59C74", "#C3B369", "#E1CC55", "#FFE945"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.75,
    },
    "Tol Bright": {
        "palette": ["#4477AA", "#EE6677", "#228833", "#CCBB44", "#66CCEE", "#AA3377", "#BBBBBB"],
        "background": "#FFFFFF",
        "grid": True,
        "font_size": 10,
        "line_width": 1.1,
        "point_alpha": 0.74,
    },
    "Mono Print": {
        "palette": ["#111111", "#666666", "#999999", "#CCCCCC", "#444444"],
        "background": "#FFFFFF",
        "grid": False,
        "font_size": 10,
        "line_width": 1.2,
        "point_alpha": 0.7,
    },
    "Dark Slide": {
        "palette": ["#7FDBFF", "#FF851B", "#2ECC40", "#F012BE", "#FFDC00"],
        "background": "#111827",
        "grid": True,
        "font_size": 13,
        "line_width": 1.6,
        "point_alpha": 0.86,
    },
}


STAT_TABLE_OPTIONS = [
    ("show_stat_mean", "Mean"),
    ("show_stat_median", "Median"),
    ("show_stat_q1", "Q1"),
    ("show_stat_q3", "Q3"),
    ("show_stat_max", "Max"),
    ("show_stat_min", "Min"),
    ("show_stat_sd", "SD"),
    ("show_stat_sem", "SEM"),
    ("show_stat_sum", "Sum"),
    ("show_stat_sample_size", "Sample"),
]

SEQUENTIAL_PALETTE_PRESETS = {"Viridis", "Cividis"}
DEFAULT_OVERLAY_PALETTE = "Mono Print"

LINE_OVERLAY_RENDER_STYLES = (
    "Solid",
    "Dashed",
    "Dotted",
    "Dash-dot",
    "Long dash",
    "Dense dash",
    "Loose dot",
    "Dash-dot-dot",
)
LINE_OVERLAY_STYLES = ("Auto", *LINE_OVERLAY_RENDER_STYLES)
BAR_SUMMARIES = (
    "Mean",
    "Mean with SD",
    "Mean with SEM",
    "Mean with 95% CI",
    "Mean with range",
    "Median",
    "Median with 95% CI",
    "Median with range",
    "No line or error bar",
)


@dataclass
class ChartSettings:
    chart_type: str = "Box"
    preset: str = "Paper Clean"
    group_order: str = "Table order"
    manual_group_order: list[str] = field(default_factory=list)
    group_hidden: list[str] = field(default_factory=list)
    group_inner_spacing: float = 1.0
    group_outer_spacing: float = 2.7
    group_label_mode: str = "Both levels"
    group_color_mode: str = "Subgroup"
    group_col: str = "group"
    value_col: str = "value"
    title: str = "Distribution plot"
    x_label: str = "Group"
    y_label: str = "Value"
    secondary_y_axis: bool = False
    secondary_y_label: str = "Secondary value"
    show_points: bool = True
    point_size: float = 4.0
    point_alpha: float = 0.75
    jitter_mode: str = "Quasirandom"
    jitter: float = 0.18
    show_line_overlay: bool = False
    line_overlay_stat: str = "None"
    extra_custom_overlay: bool = False
    custom_overlay_count: int = 1
    custom_overlay_series: list[dict] = field(default_factory=list)
    custom_overlay_hidden: list[int] = field(default_factory=list)
    line_overlay_width: float = 1.6
    line_overlay_style: str = "Solid"
    line_overlay_break_between_parents: bool = False
    line_overlay_point_size: float = 5.0
    show_line_values: bool = False
    line_value_position: str = "Auto"
    custom_line_value_position: str = "Auto"
    custom_overlay_secondary_axis: bool = False
    split_secondary_axis: bool = False
    secondary_axis_split_ratio: float = 0.35
    line_value_scientific: bool = False
    line_value_decimals: int = 2
    statistic_formats: dict[str, dict] = field(default_factory=dict)
    line_value_font_size: int = 9
    show_stat_table: bool = True
    show_stat_mean: bool = True
    show_stat_median: bool = True
    show_stat_q1: bool = False
    show_stat_q3: bool = False
    show_stat_max: bool = True
    show_stat_min: bool = True
    show_stat_sd: bool = False
    show_stat_sem: bool = False
    show_stat_sum: bool = False
    show_stat_sample_size: bool = False
    show_stat_header: bool = False
    stat_table_font_size: int = 9
    show_outliers: bool = True
    outlier_method: str = "IQR"
    outlier_threshold: float = 1.5
    outlier_effect: str = "Mark only"
    width: float = 15.0
    height: float = 10.0
    dpi: int = 300
    title_font_size: int = 16
    axis_label_font_size: int = 12
    tick_font_size: int = 10
    additional_guide_font_size: int = 10
    additional_guide_line_width: float = 1.2
    show_legend: bool = True
    legend_font_size: int = 10
    legend_width: float = 3.6
    legend_height: float = 0.0
    legend_auto_wrap: bool = True
    legend_auto_width: bool = True
    legend_columns: int = 1
    legend_position: str = LEGEND_POSITION_RIGHT
    legend_inside_x: float = LEGEND_INSIDE_AUTO_POSITION
    legend_inside_y: float = LEGEND_INSIDE_AUTO_POSITION
    axis_line_width: float = 1.1
    show_grid: bool = True
    x_tick_rotation: int = 0
    auto_x_range: bool = True
    x_min: float = 0.0
    x_max: float = 10.0
    x_auto_tick_interval: bool = True
    x_tick_interval: float = 1.0
    auto_y_range: bool = True
    y_min: float = 0.0
    y_max: float = 10.0
    primary_auto_tick_interval: bool = True
    primary_tick_interval: float = 1.0
    secondary_auto_y_range: bool = True
    secondary_y_min: float = 0.0
    secondary_y_max: float = 10.0
    secondary_auto_tick_interval: bool = True
    secondary_tick_interval: float = 1.0
    transparent_background: bool = True
    fill_alpha: float = 0.75
    box_width: float = 0.55
    box_whisker_mode: str = "Tukey 1.5 IQR"
    bar_width: float = 0.55
    bar_summary: str = "Mean with SD"
    violin_width: float = 0.8
    kde_bandwidth: float = 1.0
    ridge_overlap: float = 0.75
    custom_colors: dict[str, str] = field(default_factory=dict)
    custom_overlay_palette: str = DEFAULT_OVERLAY_PALETTE
    additional_guide_palette: str = DEFAULT_OVERLAY_PALETTE
    custom_overlay_colors: dict[str, str] = field(default_factory=dict)
    custom_overlay_styles: dict[str, str] = field(default_factory=dict)
    additional_x_axis_guides: list[dict] = field(default_factory=list)
    additional_primary_axis_guides: list[dict] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.bar_summary not in BAR_SUMMARIES:
            self.bar_summary = "Mean with SD"
        try:
            bar_width = float(self.bar_width)
        except (TypeError, ValueError, OverflowError):
            bar_width = 0.55
        self.bar_width = min(1.0, max(0.2, bar_width)) if math.isfinite(bar_width) else 0.55
        for field_name, default in (("group_inner_spacing", 1.0), ("group_outer_spacing", 2.7)):
            try:
                value = float(getattr(self, field_name))
            except (TypeError, ValueError, OverflowError):
                value = default
            setattr(self, field_name, min(10.0, max(0.2, value)) if math.isfinite(value) else default)
        if self.group_label_mode not in {"Both levels", "Legend only"}:
            self.group_label_mode = "Both levels"
        if self.group_color_mode not in {"Subgroup", "Parent"}:
            self.group_color_mode = "Subgroup"
        self.statistic_formats = normalize_statistic_formats(self.statistic_formats)
        if self.show_line_overlay and self.line_overlay_stat == "None":
            self.line_overlay_stat = "Median"
        self.show_line_overlay = self.line_overlay_stat != "None"
        self.group_hidden = sorted({str(group) for group in self.group_hidden})
        self.custom_overlay_count = max(1, int(self.custom_overlay_count))
        self.custom_overlay_hidden = sorted(
            {
                int(index)
                for index in self.custom_overlay_hidden
                if isinstance(index, int) or str(index).lstrip("-").isdigit()
            }
        )
        self.custom_overlay_styles = {
            str(key): str(style)
            for key, style in self.custom_overlay_styles.items()
            if str(style) in LINE_OVERLAY_STYLES
        }
        if (
            not isinstance(self.additional_guide_palette, str)
            or self.additional_guide_palette not in PRESETS
        ):
            self.additional_guide_palette = DEFAULT_OVERLAY_PALETTE
        self.legend_columns = max(0, int(self.legend_columns))
        self.legend_auto_width = bool(self.legend_auto_width)
        if self.legend_columns <= 0:
            self.legend_auto_width = False
        if self.legend_position not in {LEGEND_POSITION_RIGHT, LEGEND_POSITION_INSIDE}:
            self.legend_position = LEGEND_POSITION_RIGHT
        self.legend_inside_x = float(self.legend_inside_x)
        self.legend_inside_y = float(self.legend_inside_y)
        if self.legend_inside_x != LEGEND_INSIDE_AUTO_POSITION:
            self.legend_inside_x = min(max(self.legend_inside_x, 0.0), 1.0)
        if self.legend_inside_y != LEGEND_INSIDE_AUTO_POSITION:
            self.legend_inside_y = min(max(self.legend_inside_y, 0.0), 1.0)
        self.additional_x_axis_guides = normalize_additional_guides(
            self.additional_x_axis_guides
        )
        self.additional_primary_axis_guides = normalize_additional_guides(
            self.additional_primary_axis_guides
        )
        try:
            additional_guide_font_size = int(self.additional_guide_font_size)
        except (TypeError, ValueError, OverflowError):
            additional_guide_font_size = 10
        self.additional_guide_font_size = min(
            36,
            max(5, additional_guide_font_size),
        )
        try:
            additional_guide_line_width = float(
                self.additional_guide_line_width
            )
        except (TypeError, ValueError, OverflowError):
            additional_guide_line_width = 1.2
        if not math.isfinite(additional_guide_line_width):
            additional_guide_line_width = 1.2
        self.additional_guide_line_width = min(
            5.0,
            max(0.5, additional_guide_line_width),
        )


STYLE_TEMPLATE_CONTENT_FIELDS = {
    "title",
    "x_label",
    "y_label",
    "secondary_y_label",
    "manual_group_order",
    "group_hidden",
    "custom_overlay_count",
    "custom_overlay_series",
    "custom_overlay_hidden",
    "additional_x_axis_guides",
    "additional_primary_axis_guides",
}
GROUP_COLOR_TEMPLATE_KEY_PREFIX = "group:"


__all__ = [
    "ChartSettings",
    "DEFAULT_OVERLAY_PALETTE",
    "GROUP_COLOR_TEMPLATE_KEY_PREFIX",
    "LEGEND_INSIDE_AUTO_POSITION",
    "LEGEND_POSITION_INSIDE",
    "LEGEND_POSITION_RIGHT",
    "LINE_OVERLAY_RENDER_STYLES",
    "LINE_OVERLAY_STYLES",
    "PRESETS",
    "SEQUENTIAL_PALETTE_PRESETS",
    "STAT_TABLE_OPTIONS",
    "STYLE_TEMPLATE_CONTENT_FIELDS",
]
