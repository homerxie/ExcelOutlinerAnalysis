from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Protocol, TypeAlias


Snapshot = dict[str, Any]
MutationResult = tuple[Snapshot, Any, bool]
CellValue = tuple[int, int, str]


class HistoryTarget(Protocol):
    def apply_history_cells(
        self,
        values: tuple[CellValue, ...],
        settings: Snapshot | None = None,
    ) -> None: ...

    def apply_history_settings(self, settings: Snapshot) -> None: ...

    def restore_history_snapshot(self, snapshot: Snapshot) -> None: ...


@dataclass(frozen=True)
class CellEdit:
    row: int
    column: int
    before: str
    after: str

    @property
    def changed(self) -> bool:
        return self.before != self.after

    def apply(self, target: HistoryTarget) -> None:
        target.apply_history_cells(((self.row, self.column, self.after),))

    def revert(self, target: HistoryTarget) -> None:
        target.apply_history_cells(((self.row, self.column, self.before),))


@dataclass(frozen=True)
class BlockEdit:
    cells: tuple[CellEdit, ...]
    settings_before: Snapshot | None = None
    settings_after: Snapshot | None = None

    @property
    def changed(self) -> bool:
        return any(cell.changed for cell in self.cells) or self.settings_before != self.settings_after

    def apply(self, target: HistoryTarget) -> None:
        target.apply_history_cells(
            tuple((cell.row, cell.column, cell.after) for cell in self.cells),
            self.settings_after,
        )

    def revert(self, target: HistoryTarget) -> None:
        target.apply_history_cells(
            tuple((cell.row, cell.column, cell.before) for cell in self.cells),
            self.settings_before,
        )


@dataclass(frozen=True)
class SettingsEdit:
    before: Snapshot
    after: Snapshot

    @property
    def changed(self) -> bool:
        return self.before != self.after

    def apply(self, target: HistoryTarget) -> None:
        target.apply_history_settings(self.after)

    def revert(self, target: HistoryTarget) -> None:
        target.apply_history_settings(self.before)


@dataclass(frozen=True)
class StructureSnapshotEdit:
    before: Snapshot
    after: Snapshot

    @property
    def changed(self) -> bool:
        return self.before != self.after

    def apply(self, target: HistoryTarget) -> None:
        target.restore_history_snapshot(self.after)

    def revert(self, target: HistoryTarget) -> None:
        target.restore_history_snapshot(self.before)


@dataclass(frozen=True)
class CallbackEdit:
    """A reversible edit for structures owned outside one table model."""

    apply_callback: Callable[[], None]
    revert_callback: Callable[[], None]
    changed: bool = True

    def apply(self, _target: HistoryTarget) -> None:
        self.apply_callback()

    def revert(self, _target: HistoryTarget) -> None:
        self.revert_callback()


HistoryCommand: TypeAlias = (
    CellEdit | BlockEdit | SettingsEdit | StructureSnapshotEdit | CallbackEdit
)


def run_table_history_mutation(
    snapshot: Callable[[], Snapshot],
    set_suspended: Callable[[bool], None],
    mutate: Callable[[], Any],
) -> MutationResult:
    before = snapshot()
    set_suspended(True)
    try:
        result = mutate()
    finally:
        set_suspended(False)
    changed = result if isinstance(result, bool) else True
    return before, result, changed


@dataclass
class TableHistoryState:
    undo_stack: list[HistoryCommand] = field(default_factory=list)
    redo_stack: list[HistoryCommand] = field(default_factory=list)
    limit: int = 100

    @property
    def can_undo(self) -> bool:
        return bool(self.undo_stack)

    @property
    def can_redo(self) -> bool:
        return bool(self.redo_stack)

    def reset(self) -> None:
        self.undo_stack = []
        self.redo_stack = []

    def record(self, command: HistoryCommand) -> None:
        if not command.changed:
            return
        self.undo_stack.append(command)
        self.undo_stack = self.undo_stack[-self.limit :]
        self.redo_stack = []

    def undo(self, target: HistoryTarget) -> HistoryCommand | None:
        if not self.undo_stack:
            return None
        command = self.undo_stack.pop()
        command.revert(target)
        self.redo_stack.append(command)
        return command

    def redo(self, target: HistoryTarget) -> HistoryCommand | None:
        if not self.redo_stack:
            return None
        command = self.redo_stack.pop()
        command.apply(target)
        self.undo_stack.append(command)
        return command
