"""Palette names with compact swatch previews in the field and popup."""
from __future__ import annotations

from PySide6.QtCore import QRect, QSize, Qt
from PySide6.QtGui import QColor, QPainter, QPalette
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionComboBox,
    QStyleOptionViewItem,
    QStylePainter,
)

from easygraph.settings import PRESETS, SEQUENTIAL_PALETTE_PRESETS


SWATCH_COUNT = 5
SWATCH_SIZE = 12
SWATCH_SPACING = 3
PREVIEW_WIDTH = SWATCH_COUNT * SWATCH_SIZE + (SWATCH_COUNT - 1) * SWATCH_SPACING
PREVIEW_PADDING = PREVIEW_WIDTH + 12


def _preview_colors(name: str) -> list[str]:
    colors = PRESETS.get(name, {}).get("palette", [])
    if name in SEQUENTIAL_PALETTE_PRESETS and len(colors) > SWATCH_COUNT:
        return [colors[round(i * (len(colors) - 1) / (SWATCH_COUNT - 1))] for i in range(SWATCH_COUNT)]
    return colors[:SWATCH_COUNT]


def _draw_preview(painter: QPainter, rect: QRect, name: str, enabled: bool) -> None:
    painter.save()
    try:
        painter.setClipRect(rect, Qt.ClipOperation.IntersectClip)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        if not enabled:
            painter.setOpacity(0.45)
        left = rect.right() - PREVIEW_WIDTH + 1
        top = rect.y() + (rect.height() - SWATCH_SIZE) // 2
        painter.setPen(QColor(0, 0, 0, 60))
        for i, color in enumerate(_preview_colors(name)):
            painter.setBrush(QColor(color))
            painter.drawRoundedRect(
                QRect(left + i * (SWATCH_SIZE + SWATCH_SPACING), top, SWATCH_SIZE - 1, SWATCH_SIZE - 1),
                2,
                2,
            )
    finally:
        painter.restore()


class PaletteItemDelegate(QStyledItemDelegate):
    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index) -> None:
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        name = opt.text
        opt.text = ""
        style = opt.widget.style() if opt.widget is not None else QApplication.style()
        style.drawControl(QStyle.ControlElement.CE_ItemViewItem, opt, painter, opt.widget)

        content = opt.rect.adjusted(10, 0, -10, 0)
        text_rect = content.adjusted(0, 0, -PREVIEW_PADDING, 0)
        selected = bool(opt.state & QStyle.StateFlag.State_Selected)
        enabled = bool(opt.state & QStyle.StateFlag.State_Enabled)
        group = QPalette.ColorGroup.Active if enabled else QPalette.ColorGroup.Disabled
        role = QPalette.ColorRole.HighlightedText if selected else QPalette.ColorRole.Text
        painter.save()
        try:
            painter.setFont(opt.font)
            painter.setPen(opt.palette.color(group, role))
            painter.drawText(
                text_rect,
                Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                opt.fontMetrics.elidedText(name, Qt.TextElideMode.ElideRight, max(0, text_rect.width())),
            )
            _draw_preview(painter, content, name, enabled)
        finally:
            painter.restore()

    def sizeHint(self, option: QStyleOptionViewItem, index) -> QSize:
        hint = super().sizeHint(option, index)
        return QSize(hint.width() + PREVIEW_PADDING + 20, max(hint.height(), 26))


class PaletteComboBox(QComboBox):
    """Keep the preset key as ordinary combo text for settings and accessibility."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setItemDelegate(PaletteItemDelegate(self))

    def sizeHint(self) -> QSize:
        hint = super().sizeHint()
        return QSize(hint.width() + PREVIEW_PADDING, hint.height())

    def minimumSizeHint(self) -> QSize:
        hint = super().minimumSizeHint()
        return QSize(hint.width() + PREVIEW_PADDING, hint.height())

    def showPopup(self) -> None:
        self.view().setMinimumWidth(max(self.width(), self.sizeHint().width()))
        super().showPopup()

    def paintEvent(self, event) -> None:
        painter = QStylePainter(self)
        opt = QStyleOptionComboBox()
        self.initStyleOption(opt)
        painter.drawComplexControl(QStyle.ComplexControl.CC_ComboBox, opt)
        content = self.style().subControlRect(
            QStyle.ComplexControl.CC_ComboBox, opt, QStyle.SubControl.SC_ComboBoxEditField, self
        )
        name = opt.currentText
        opt.currentText = self.fontMetrics().elidedText(
            name, Qt.TextElideMode.ElideRight, max(0, content.width() - PREVIEW_PADDING)
        )
        painter.drawControl(QStyle.ControlElement.CE_ComboBoxLabel, opt)
        _draw_preview(painter, content, name, self.isEnabled())
