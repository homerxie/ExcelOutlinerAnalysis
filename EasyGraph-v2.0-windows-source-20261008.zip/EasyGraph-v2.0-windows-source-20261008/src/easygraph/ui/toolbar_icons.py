"""Theme-aware toolbar icons rendered from bundled SVG subsets."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
import sys

from PySide6.QtCore import QByteArray, QRectF, QSize, Qt
from PySide6.QtGui import QColor, QIcon, QIconEngine, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer


def _icon_directory(library: str) -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        root = Path(sys._MEIPASS)
    else:
        root = Path(__file__).resolve().parents[3]
    return root / "icon" / library


@lru_cache(maxsize=128)
def _svg_data(name: str, color: str) -> bytes:
    library, separator, icon_name = name.partition(":")
    if not separator:
        library, icon_name = "tabler", name
    if library not in {"tabler", "lucide"} or Path(icon_name).name != icon_name:
        raise ValueError(f"Invalid toolbar icon name: {name!r}")
    source = (_icon_directory(library) / f"{icon_name}.svg").read_bytes()
    return source.replace(b"currentColor", QColor(color).name().encode("ascii"))


class _ToolbarIconEngine(QIconEngine):
    """Render vectors at the target device scale, including disabled states."""

    def __init__(self, name: str, color: str, disabled_color: str) -> None:
        super().__init__()
        self._name = name
        self._color = color
        self._disabled_color = disabled_color

    def clone(self) -> QIconEngine:
        return _ToolbarIconEngine(self._name, self._color, self._disabled_color)

    def paint(self, painter: QPainter, rect, mode, state) -> None:
        color = self._disabled_color if mode == QIcon.Mode.Disabled else self._color
        renderer = QSvgRenderer(QByteArray(_svg_data(self._name, color)))
        renderer.render(painter, QRectF(rect))

    def pixmap(self, size: QSize, mode, state) -> QPixmap:
        return self.scaledPixmap(size, mode, state, 1.0)

    def scaledPixmap(self, size: QSize, mode, state, scale: float) -> QPixmap:
        pixmap = QPixmap(
            max(1, round(size.width() * scale)),
            max(1, round(size.height() * scale)),
        )
        pixmap.setDevicePixelRatio(scale)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        try:
            self.paint(painter, QRectF(0, 0, size.width(), size.height()), mode, state)
        finally:
            painter.end()
        return pixmap


@lru_cache(maxsize=256)
def toolbar_icon(name: str, color: str, disabled_color: str) -> QIcon:
    """Create a vector icon with explicit normal and disabled theme colors."""
    # Check assets eagerly so packaging mistakes cannot silently hide controls.
    _svg_data(name, color)
    return QIcon(_ToolbarIconEngine(name, color, disabled_color))


__all__ = ["toolbar_icon"]
