"""Startup choice for the first Sheet in a new EasyGraph project."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import QEvent, Qt
from PySide6.QtWidgets import QDialog, QHeaderView, QMessageBox, QTableWidgetItem, QWidget

from easygraph.app_preferences import forget_recent_project, stored_recent_project_paths
from easygraph.workbook import SHEET_MODE_GROUPS, SHEET_MODE_XY
from ui_startup_dialog import Ui_StartupDialog


@dataclass(frozen=True)
class StartupChoice:
    mode: str
    demo: bool
    grouped_demo: bool = False
    project_path: Path | None = None


class StartupDialog(QDialog):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.ui = Ui_StartupDialog()
        self.ui.setupUi(self)
        self.choice: StartupChoice | None = None
        self._group_demo_index = 0
        self.ui.groupRadioButton.toggled.connect(self._update_demo_presets)
        self.ui.demoButton.clicked.connect(lambda: self._choose(demo=True))
        self.ui.blankButton.clicked.connect(lambda: self._choose(demo=False))
        self.ui.openRecentButton.clicked.connect(self._open_selected_recent)
        table = self.ui.recentProjectsTable
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        table.setColumnWidth(0, 200)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        table.itemSelectionChanged.connect(self._update_recent_selection)
        table.cellDoubleClicked.connect(lambda _row, _column: self._open_selected_recent())
        table.installEventFilter(self)
        self._update_demo_presets()
        self._refresh_recent_projects()

    def _update_demo_presets(self) -> None:
        combo = self.ui.demoPresetCombo
        is_groups = self.ui.groupRadioButton.isChecked()
        if not is_groups:
            self._group_demo_index = max(0, combo.currentIndex())
        combo.clear()
        if is_groups:
            combo.addItems([self.tr("Single-level headers"), self.tr("Two-level headers")])
            combo.setCurrentIndex(self._group_demo_index)
        else:
            combo.addItem(self.tr("XY demo"))
        combo.setEnabled(is_groups)

    def _refresh_recent_projects(self) -> None:
        table = self.ui.recentProjectsTable
        paths = stored_recent_project_paths()
        table.setRowCount(0)
        for row, path in enumerate(paths):
            table.insertRow(row)
            for column, text in enumerate((path.name, str(path.parent))):
                item = QTableWidgetItem(text)
                item.setToolTip(str(path))
                item.setData(Qt.ItemDataRole.UserRole, path)
                table.setItem(row, column, item)
        table.setVisible(bool(paths))
        self.ui.recentEmptyLabel.setVisible(not paths)
        self._update_recent_selection()

    def _selected_recent_path(self) -> Path | None:
        rows = self.ui.recentProjectsTable.selectionModel().selectedRows()
        if not rows:
            return None
        return self.ui.recentProjectsTable.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole)

    def _update_recent_selection(self) -> None:
        self.ui.openRecentButton.setEnabled(self._selected_recent_path() is not None)

    def _open_selected_recent(self) -> None:
        path = self._selected_recent_path()
        if path is None:
            return
        if not path.is_file():
            forget_recent_project(path)
            self._refresh_recent_projects()
            QMessageBox.warning(
                self,
                self.tr("Recent project unavailable"),
                self.tr("The selected recent project could not be found:\n{path}").format(path=path),
            )
            return
        self.choice = StartupChoice(mode=SHEET_MODE_GROUPS, demo=False, project_path=path)
        self.accept()

    def eventFilter(self, watched, event) -> bool:
        if (
            watched is self.ui.recentProjectsTable
            and event.type() == QEvent.Type.KeyPress
            and event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter)
        ):
            self._open_selected_recent()
            return True
        return super().eventFilter(watched, event)

    def _choose(self, *, demo: bool) -> None:
        mode = SHEET_MODE_XY if self.ui.xyRadioButton.isChecked() else SHEET_MODE_GROUPS
        self.choice = StartupChoice(
            mode=mode,
            demo=demo,
            grouped_demo=demo and mode == SHEET_MODE_GROUPS and self.ui.demoPresetCombo.currentIndex() == 1,
        )
        self.accept()


def choose_startup(parent: QWidget | None = None) -> StartupChoice | None:
    dialog = StartupDialog(parent)
    if dialog.exec() != QDialog.DialogCode.Accepted:
        return None
    return dialog.choice


__all__ = ["StartupChoice", "StartupDialog", "choose_startup"]
