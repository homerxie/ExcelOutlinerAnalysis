"""Numbered columns above selectable, mergeable parent-title cells."""
from __future__ import annotations

from PySide6.QtCore import QPoint, QRect, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QHeaderView, QStyle, QStyleOption, QStyleOptionHeader


class GroupHeaderView(QHeaderView):
    # Keep the original signals for consumers that identify existing groups by ID.
    parentDoubleClicked = Signal(str)
    parentContextMenuRequested = Signal(str, QPoint)
    parentSelectionChanged = Signal()
    parentCellDoubleClicked = Signal(int)
    parentCellContextMenuRequested = Signal(int, QPoint)

    def __init__(self, parent=None, *, parent_band_at_top: bool = False):
        super().__init__(Qt.Horizontal, parent)
        self._groups: list[tuple[str, str, list[int]]] = []
        self._column_ids: list[str] = []
        self._selected_ids: set[str] = set()
        self._anchor_id: str | None = None
        self._parent_band_enabled = True
        self._parent_band_at_top = parent_band_at_top
        self._dragging_parent = False
        self._hint_active = False
        self._hint_timer = QTimer(self)
        self._hint_timer.setSingleShot(True)
        self._hint_timer.timeout.connect(self._clear_parent_band_hint)
        self.setSectionsMovable(False)
        self.setSectionsClickable(True)
        self.setHighlightSections(True)

    def set_grouping(self, parents: list[dict], column_ids: list[str]) -> None:
        old_columns = self.selected_parent_columns()
        old_ids = set(self._selected_ids)
        column_ids = list(column_ids)
        indexes = {key: index for index, key in enumerate(column_ids)}
        groups = []
        for group in parents:
            columns = sorted(indexes[key] for key in group['column_ids'] if key in indexes)
            if columns:
                groups.append((str(group['id']), str(group['name']), columns))
        changed = groups != self._groups or column_ids != self._column_ids
        self._groups = groups
        self._column_ids = column_ids
        self._selected_ids.intersection_update(column_ids)
        if self._anchor_id not in indexes:
            self._anchor_id = None
        # An inserted member of a selected group belongs to the same atomic block.
        selected = self._expanded_columns(self.selected_parent_columns())
        self._selected_ids = {column_ids[column] for column in selected}
        if changed:
            self._refresh_geometry()
        if old_columns != selected or old_ids != self._selected_ids:
            self.parentSelectionChanged.emit()

    def set_parent_band_enabled(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self._parent_band_enabled:
            return
        self._parent_band_enabled = enabled
        if not enabled:
            self.clear_parent_selection()
            self._dragging_parent = False
        self._refresh_geometry()

    def _refresh_geometry(self) -> None:
        self.updateGeometry()
        self.geometriesChanged.emit()
        self.viewport().update()

    def band_height(self) -> int:
        return max(24, self.fontMetrics().height() + 10) if self._parent_band_enabled else 0

    def sizeHint(self) -> QSize:
        size = super().sizeHint()
        return QSize(size.width(), size.height() + self.band_height())

    def paintSection(self, painter, rect, logical_index):
        band = self.band_height()
        if band:
            rect = QRect(
                rect.x(),
                rect.y() + (band if self._parent_band_at_top else 0),
                rect.width(),
                max(0, rect.height() - band),
            )
        super().paintSection(painter, rect, logical_index)

    def parent_band_rect(self) -> QRect:
        height = self.band_height()
        top = 0 if self._parent_band_at_top else max(0, self.viewport().height() - height)
        return QRect(0, top, self.viewport().width(), height)

    def _block_columns(self, column: int) -> list[int]:
        if not 0 <= column < len(self._column_ids):
            return []
        return next((columns for _key, _label, columns in self._groups if column in columns), [column])

    def _blocks(self):
        groups = {column: (key, label, columns) for key, label, columns in self._groups for column in columns}
        seen = set()
        for column in range(len(self._column_ids)):
            if column in seen:
                continue
            key, label, columns = groups.get(column, (None, '', [column]))
            seen.update(columns)
            yield key, label, columns

    def _columns_rect(self, columns: list[int]) -> QRect:
        visible = [column for column in columns if column < self.count() and not self.isSectionHidden(column)]
        if not visible:
            return QRect()
        band = self.parent_band_rect()
        left = self.sectionViewportPosition(visible[0])
        right = self.sectionViewportPosition(visible[-1]) + self.sectionSize(visible[-1])
        return QRect(left, band.top(), right - left, band.height())

    def group_rects(self):
        if not self._parent_band_enabled:
            return
        for key, label, columns in self._groups:
            yield key, label, self._columns_rect(columns)

    def _parent_border_color(self) -> QColor:
        # Stylesheet themes can paint section backgrounds without updating the
        # header's Button palette. Ask the table for its actual gridline color.
        table = self.parentWidget()
        if table is not None:
            option = QStyleOption()
            option.initFrom(table)
            value = table.style().styleHint(QStyle.SH_Table_GridLineColor, option, table)
            if value != -1:
                return QColor.fromRgba(value & 0xFFFFFFFF)
        return self.palette().mid().color()

    def paintEvent(self, event):
        super().paintEvent(event)
        if not self._parent_band_enabled:
            return
        painter = QPainter(self.viewport())
        painter.fillRect(self.parent_band_rect(), self.palette().button())
        highlight = self.palette().highlight().color()
        border = self._parent_border_color()
        for _key, label, columns in self._blocks():
            rect = self._columns_rect(columns)
            if not rect.intersects(event.rect()):
                continue
            option = QStyleOptionHeader()
            self.initStyleOption(option)
            option.rect = rect
            option.text = label
            option.textAlignment = Qt.AlignCenter
            option.position = QStyleOptionHeader.OnlyOneSection
            self.style().drawControl(QStyle.CE_Header, option, painter, self)
            # Some dark styles omit CE_Header section borders entirely. Draw
            # one shared edge per block; merged columns have no inner dividers.
            painter.setPen(QPen(border, 1))
            painter.drawRect(rect.adjusted(-1, 0, -1, -1))
            if any(self._column_ids[column] in self._selected_ids for column in columns):
                tint = QColor(highlight)
                tint.setAlpha(42)
                painter.fillRect(rect.adjusted(1, 1, -1, -1), tint)
                painter.setPen(QPen(highlight, 2))
                painter.drawRect(rect.adjusted(1, 1, -1, -1))
        if self._hint_active:
            painter.setPen(QPen(highlight, 2, Qt.DashLine))
            painter.drawRect(self.parent_band_rect().adjusted(1, 1, -2, -2))
        painter.end()

    def parent_at(self, position: QPoint) -> str | None:
        return next((key for key, _label, rect in self.group_rects() if rect.contains(position)), None)

    def parent_columns_at(self, position: QPoint) -> list[int]:
        if not self._parent_band_enabled or not self.parent_band_rect().contains(position):
            return []
        return list(self._block_columns(self.logicalIndexAt(position)))

    def selected_parent_columns(self) -> list[int]:
        return [column for column, key in enumerate(self._column_ids) if key in self._selected_ids]

    def _expanded_columns(self, columns) -> list[int]:
        valid = [column for column in columns if 0 <= column < len(self._column_ids)]
        if not valid:
            return []
        left = min(self._block_columns(min(valid)))
        right = max(self._block_columns(max(valid)))
        return list(range(left, right + 1))

    def _set_selected_columns(self, columns: list[int]) -> None:
        selected_ids = {self._column_ids[column] for column in columns}
        if selected_ids == self._selected_ids:
            return
        self._selected_ids = selected_ids
        self.viewport().update()
        self.parentSelectionChanged.emit()

    def select_parent_columns(self, columns) -> None:
        selected = self._expanded_columns(columns) if self._parent_band_enabled else []
        self._anchor_id = self._column_ids[selected[0]] if selected else None
        self._set_selected_columns(selected)

    def clear_parent_selection(self) -> None:
        self._anchor_id = None
        self._set_selected_columns([])

    def select_parent_column(self, column: int, extend: bool = False, preserve: bool = False) -> None:
        columns = self._block_columns(column) if self._parent_band_enabled else []
        if not columns:
            return
        if preserve and self._column_ids[column] in self._selected_ids:
            return
        if extend and self._anchor_id in self._column_ids:
            anchor = self._column_ids.index(self._anchor_id)
            columns = self._expanded_columns([anchor, column])
        else:
            self._anchor_id = self._column_ids[column]
        self._set_selected_columns(columns)

    def highlight_parent_band(self) -> None:
        if self._parent_band_enabled:
            self._hint_active = True
            self._hint_timer.start(1500)
            self.viewport().update()

    def _clear_parent_band_hint(self) -> None:
        self._hint_active = False
        self.viewport().update()

    def mousePressEvent(self, event):
        position = event.position().toPoint()
        if self._parent_band_enabled and self.parent_band_rect().contains(position):
            columns = self.parent_columns_at(position)
            if columns:
                self.select_parent_column(
                    columns[0],
                    extend=bool(event.modifiers() & Qt.ShiftModifier),
                    preserve=event.button() == Qt.RightButton,
                )
                self._dragging_parent = event.button() == Qt.LeftButton
            else:
                self.clear_parent_selection()
            event.accept()
            return
        self.clear_parent_selection()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._dragging_parent:
            column = self.logicalIndexAt(event.position().toPoint().x())
            if 0 <= column < len(self._column_ids):
                self.select_parent_column(column, extend=True)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._dragging_parent:
            self._dragging_parent = False
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        columns = self.parent_columns_at(event.position().toPoint())
        if columns:
            self.select_parent_column(columns[0])
            self.parentCellDoubleClicked.emit(columns[0])
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)

    def contextMenuEvent(self, event):
        columns = self.parent_columns_at(event.pos())
        if columns:
            self.select_parent_column(columns[0], preserve=True)
            self.parentCellContextMenuRequested.emit(columns[0], event.globalPos())
            event.accept()
        else:
            super().contextMenuEvent(event)
