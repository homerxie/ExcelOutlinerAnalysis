"""Qt workflow for selecting and previewing a Prism PZFX data table."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from PySide6.QtCore import QCoreApplication, QT_TRANSLATE_NOOP, Qt
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHeaderView,
    QListWidgetItem,
    QTableWidgetItem,
    QWidget,
)

from easygraph.prism_io import (
    PrismImportError,
    PrismImportResult,
    PrismProjectSummary,
    PrismTableSummary,
    import_pzfx_table,
    import_pzfx_tables,
    inspect_pzfx,
)
from ui_prism_import_dialog import Ui_PrismImportDialog


PREVIEW_MAX_ROWS = 20
PREVIEW_MAX_COLUMNS = 12

SOURCE_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "Source: {file} — Prism {version}, PZFX XML {xml_version}",
)
UNKNOWN_TEXT = QT_TRANSLATE_NOOP("PrismImportDialog", "unknown")
NO_TABLES_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "This PZFX file contains no data tables.",
)
UNKNOWN_KIND_TEXT = QT_TRANSLATE_NOOP("PrismImportDialog", "Unknown")
TABLE_LABEL_TEXT = QT_TRANSLATE_NOOP("PrismImportDialog", "{title} — {kind}")
UNSUPPORTED_LABEL_TEXT = QT_TRANSLATE_NOOP("PrismImportDialog", "Unsupported: {label}")
CANNOT_IMPORT_TEXT = QT_TRANSLATE_NOOP("PrismImportDialog", "This table cannot be imported.")
NO_SELECTION_TEXT = QT_TRANSLATE_NOOP("PrismImportDialog", "No Prism table is selected.")
SELECTED_COUNT_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "{count} tables selected",
)
SELECTED_COUNT_SINGULAR_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "1 table selected",
)
SUMMARY_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "Type: {kind} | Groups: {groups} | Rows: {rows} | Missing: {missing} | Excluded: {excluded}",
)
EXCLUDED_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "Excluded Prism values will be imported as empty cells and will not be plotted.",
)
GROUPED_MAPPING_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "Grouped row and column factors are combined into EasyGraph group names.",
)
UNVALIDATED_VERSION_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "Prism version {version} has not been validated for PZFX import.",
)
UNSUPPORTED_EXTENSION_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "Extended table type {table_type} is not supported.",
)
UNSUPPORTED_Y_FORMAT_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "Y format {y_format} is not raw replicate data and cannot be imported.",
)
UNSUPPORTED_TABLE_TYPE_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "Prism table type {table_type} is not supported.",
)
UNSUPPORTED_STRUCTURE_TEXT = QT_TRANSLATE_NOOP(
    "PrismImportDialog",
    "This table does not match the supported raw Column or Grouped structure.",
)

WARNING_TEXTS = {
    "unvalidated_prism_version": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "This Prism application version has not been validated."
    ),
    "missing_table_id": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "One or more tables had no ID; fallback IDs were assigned."
    ),
    "duplicate_table_id": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "Duplicate table IDs were safely disambiguated."
    ),
    "column_row_titles_not_preserved": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "Column row titles are not represented in EasyGraph."
    ),
    "unequal_column_lengths": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "Shorter Column groups were padded with empty cells."
    ),
    "missing_grouped_row_titles": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "Some Grouped rows used fallback names because row titles were missing."
    ),
    "replicate_count_mismatch": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "The declared replicate count differs from the XML data structure."
    ),
    "subcolumn_count_mismatch": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "A declared Subcolumn count differs from the XML data structure."
    ),
    "short_grouped_subcolumn": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "A short Grouped Subcolumn was padded with an empty cell."
    ),
}

ERROR_TEXTS = {
    "file_read_failed": QT_TRANSLATE_NOOP("PrismImportDialog", "The Prism file could not be read."),
    "file_too_large": QT_TRANSLATE_NOOP("PrismImportDialog", "The PZFX file exceeds the safety size limit."),
    "unsafe_xml_declaration": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "PZFX files containing DOCTYPE or ENTITY declarations are not supported."
    ),
    "malformed_xml": QT_TRANSLATE_NOOP("PrismImportDialog", "The PZFX XML is malformed."),
    "unsupported_encoding": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "PZFX import currently requires UTF-8 XML encoding."
    ),
    "legacy_pzf": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "Legacy .pzf files are binary. Save the file as .pzfx in Prism first."
    ),
    "unsupported_file": QT_TRANSLATE_NOOP("PrismImportDialog", "Select a GraphPad Prism .pzfx file."),
    "invalid_root": QT_TRANSLATE_NOOP("PrismImportDialog", "The XML root is not a GraphPad Prism file."),
    "unsupported_xml_version": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "This Prism XML format version is not supported."
    ),
    "no_tables": QT_TRANSLATE_NOOP("PrismImportDialog", "The PZFX file contains no data tables."),
    "too_many_tables": QT_TRANSLATE_NOOP("PrismImportDialog", "The PZFX file contains too many tables."),
    "too_many_values": QT_TRANSLATE_NOOP("PrismImportDialog", "The PZFX file contains too many data values."),
    "too_many_columns": QT_TRANSLATE_NOOP("PrismImportDialog", "The PZFX file contains too many columns."),
    "too_many_subcolumns": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "The PZFX file contains too many Subcolumns."
    ),
    "table_not_found": QT_TRANSLATE_NOOP("PrismImportDialog", "The selected Prism table was not found."),
    "unsupported_table": QT_TRANSLATE_NOOP("PrismImportDialog", "The selected Prism table is not supported."),
    "non_numeric_value": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "The selected table contains a non-numeric raw value."
    ),
    "non_finite_value": QT_TRANSLATE_NOOP(
        "PrismImportDialog", "The selected table contains a non-finite raw value."
    ),
}


def _tr(text: str) -> str:
    return QCoreApplication.translate("PrismImportDialog", text)


def prism_error_text(error: PrismImportError) -> str:
    return _tr(ERROR_TEXTS.get(error.code, str(error)))


def prism_warning_text(code: str, fallback: str) -> str:
    return _tr(WARNING_TEXTS.get(code, fallback))


def _unsupported_table_text(
    table: PrismTableSummary,
    project: PrismProjectSummary,
) -> str:
    if any(warning.code == "unvalidated_prism_version" for warning in project.warnings):
        return _tr(UNVALIDATED_VERSION_TEXT).format(
            version=project.created_by_version or _tr(UNKNOWN_TEXT)
        )
    if table.ext_table_type:
        return _tr(UNSUPPORTED_EXTENSION_TEXT).format(table_type=table.ext_table_type)
    if table.y_format and table.y_format != "replicates":
        return _tr(UNSUPPORTED_Y_FORMAT_TEXT).format(y_format=table.y_format)
    if table.table_type not in {"OneWay", "TwoWay"}:
        return _tr(UNSUPPORTED_TABLE_TYPE_TEXT).format(
            table_type=table.table_type or _tr(UNKNOWN_KIND_TEXT)
        )
    return _tr(UNSUPPORTED_STRUCTURE_TEXT)


class PrismImportDialog(QDialog):
    """Select supported tables and preview their EasyGraph mappings."""

    def __init__(self, path: Path, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.path = Path(path)
        self.project: PrismProjectSummary = inspect_pzfx(self.path)
        self.ui = Ui_PrismImportDialog()
        self.ui.setupUi(self)
        self._results: dict[str, PrismImportResult] = {}
        self._selected_result: PrismImportResult | None = None
        self._accepted_results: tuple[PrismImportResult, ...] | None = None

        self.ui.sourceLabel.setText(
            _tr(SOURCE_TEXT).format(
                file=self.path.name,
                version=self.project.created_by_version or _tr(UNKNOWN_TEXT),
                xml_version=self.project.xml_version,
            )
        )
        self.ui.warningLabel.setTextFormat(Qt.TextFormat.PlainText)
        self.ui.previewTable.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.ui.previewTable.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

        self._populate_tables()
        self.ui.tableListWidget.currentRowChanged.connect(self._refresh_selected_table)
        self.ui.tableListWidget.itemChanged.connect(self._selection_changed)
        self.ui.selectAllSupportedButton.clicked.connect(self._select_all_supported)
        self.ui.clearSelectionButton.clicked.connect(self._clear_selection)
        first_supported = next(
            (index for index, table in enumerate(self.project.tables) if table.supported),
            0,
        )
        if self.project.tables:
            self.ui.tableListWidget.setCurrentRow(first_supported)
        else:
            self._show_unavailable(_tr(NO_TABLES_TEXT))
        self._update_selection_state()

    @property
    def selected_result(self) -> PrismImportResult | None:
        return self._selected_result

    @property
    def selected_table_ids(self) -> tuple[str, ...]:
        selected: list[str] = []
        for index in range(self.ui.tableListWidget.count()):
            item = self.ui.tableListWidget.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                selected.append(str(item.data(Qt.ItemDataRole.UserRole)))
        return tuple(selected)

    @property
    def selected_results(self) -> tuple[PrismImportResult, ...]:
        if self._accepted_results is None:
            self._accepted_results = import_pzfx_tables(
                self.path,
                self.selected_table_ids,
            )
        return self._accepted_results

    def _ok_button(self):
        return self.ui.buttonBox.button(QDialogButtonBox.StandardButton.Ok)

    def _populate_tables(self) -> None:
        self.ui.tableListWidget.blockSignals(True)
        try:
            for table in self.project.tables:
                kind = table.kind.value if table.supported else table.ext_table_type or table.table_type or _tr(UNKNOWN_KIND_TEXT)
                label = _tr(TABLE_LABEL_TEXT).format(title=table.display_title, kind=kind)
                if not table.supported:
                    label = _tr(UNSUPPORTED_LABEL_TEXT).format(label=label)
                item = QListWidgetItem(label)
                item.setData(Qt.ItemDataRole.UserRole, table.id)
                if table.supported:
                    item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    item.setCheckState(Qt.CheckState.Checked)
                else:
                    item.setToolTip(_unsupported_table_text(table, self.project))
                self.ui.tableListWidget.addItem(item)
        finally:
            self.ui.tableListWidget.blockSignals(False)

    def _selection_changed(self, _item: QListWidgetItem) -> None:
        self._accepted_results = None
        self._update_selection_state()

    def _set_supported_check_state(self, state: Qt.CheckState) -> None:
        self.ui.tableListWidget.blockSignals(True)
        try:
            for index, table in enumerate(self.project.tables):
                if table.supported:
                    self.ui.tableListWidget.item(index).setCheckState(state)
        finally:
            self.ui.tableListWidget.blockSignals(False)
        self._accepted_results = None
        self._update_selection_state()

    def _select_all_supported(self) -> None:
        self._set_supported_check_state(Qt.CheckState.Checked)

    def _clear_selection(self) -> None:
        self._set_supported_check_state(Qt.CheckState.Unchecked)

    def _update_selection_state(self) -> None:
        selected_count = len(self.selected_table_ids)
        selected_text = (
            _tr(SELECTED_COUNT_SINGULAR_TEXT)
            if selected_count == 1
            else _tr(SELECTED_COUNT_TEXT).format(count=selected_count)
        )
        self.ui.selectedCountLabel.setText(selected_text)
        self._ok_button().setEnabled(selected_count > 0)
        self.ui.clearSelectionButton.setEnabled(selected_count > 0)
        self.ui.selectAllSupportedButton.setEnabled(
            selected_count
            < sum(table.supported for table in self.project.tables)
        )

    def _summary_for_index(self, index: int) -> PrismTableSummary | None:
        if 0 <= index < len(self.project.tables):
            return self.project.tables[index]
        return None

    def _clear_preview(self) -> None:
        self.ui.previewTable.clear()
        self.ui.previewTable.setRowCount(0)
        self.ui.previewTable.setColumnCount(0)

    def _show_unavailable(self, reason: str) -> None:
        self._selected_result = None
        self.ui.summaryLabel.setText(_tr(CANNOT_IMPORT_TEXT))
        self.ui.warningLabel.setText(reason)
        self._clear_preview()
        self._update_selection_state()

    def _refresh_selected_table(self, index: int) -> None:
        table = self._summary_for_index(index)
        if table is None:
            self._show_unavailable(_tr(NO_SELECTION_TEXT))
            return
        if not table.supported:
            self._show_unavailable(_unsupported_table_text(table, self.project))
            return

        try:
            result = self._results.get(table.id)
            if result is None:
                result = import_pzfx_table(self.path, table.id)
                self._results[table.id] = result
        except PrismImportError as exc:
            self._show_unavailable(prism_error_text(exc))
            return

        self._selected_result = result
        self._update_selection_state()
        rows, columns = result.dataframe.shape
        self.ui.summaryLabel.setText(
            _tr(SUMMARY_TEXT).format(
                kind=result.table.kind.value,
                groups=columns,
                rows=rows,
                missing=result.missing_count,
                excluded=result.excluded_count,
            )
        )
        warning_messages = [
            prism_warning_text(warning.code, warning.message) for warning in result.warnings
        ]
        if result.excluded_count:
            warning_messages.insert(
                0,
                _tr(EXCLUDED_TEXT),
            )
        if result.table.kind.value == "Grouped":
            warning_messages.append(
                _tr(GROUPED_MAPPING_TEXT),
            )
        self.ui.warningLabel.setText("\n".join(warning_messages))
        self._show_preview(result.dataframe)

    def _show_preview(self, dataframe: pd.DataFrame) -> None:
        preview_rows = min(PREVIEW_MAX_ROWS, len(dataframe.index))
        preview_columns = min(PREVIEW_MAX_COLUMNS, len(dataframe.columns))
        self.ui.previewTable.clear()
        self.ui.previewTable.setRowCount(preview_rows)
        self.ui.previewTable.setColumnCount(preview_columns)
        self.ui.previewTable.setHorizontalHeaderLabels(
            [str(column) for column in list(dataframe.columns)[:preview_columns]]
        )
        for row_index in range(preview_rows):
            for column_index in range(preview_columns):
                value = dataframe.iloc[row_index, column_index]
                if pd.isna(value):
                    text = ""
                elif isinstance(value, float):
                    text = f"{value:g}"
                else:
                    text = str(value)
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                self.ui.previewTable.setItem(row_index, column_index, item)

    def accept(self) -> None:
        table_ids = self.selected_table_ids
        if not table_ids:
            self._show_unavailable(_tr(NO_SELECTION_TEXT))
            return
        try:
            self._accepted_results = import_pzfx_tables(self.path, table_ids)
        except PrismImportError as exc:
            if exc.table_id:
                for index in range(self.ui.tableListWidget.count()):
                    item = self.ui.tableListWidget.item(index)
                    if item.data(Qt.ItemDataRole.UserRole) == exc.table_id:
                        self.ui.tableListWidget.setCurrentRow(index)
                        break
            self._show_unavailable(prism_error_text(exc))
            return
        self._results.update(
            {result.table.id: result for result in self._accepted_results}
        )
        super().accept()


def choose_prism_tables(
    parent: QWidget | None,
    path: Path,
) -> tuple[PrismImportResult, ...] | None:
    dialog = PrismImportDialog(Path(path), parent)
    return dialog.selected_results if dialog.exec() == QDialog.DialogCode.Accepted else None


def choose_prism_table(parent: QWidget | None, path: Path) -> PrismImportResult | None:
    """Choose one table for backwards-compatible callers."""

    results = choose_prism_tables(parent, path)
    return results[0] if results else None


__all__ = [
    "PREVIEW_MAX_COLUMNS",
    "PREVIEW_MAX_ROWS",
    "PrismImportDialog",
    "choose_prism_table",
    "choose_prism_tables",
    "prism_error_text",
]
