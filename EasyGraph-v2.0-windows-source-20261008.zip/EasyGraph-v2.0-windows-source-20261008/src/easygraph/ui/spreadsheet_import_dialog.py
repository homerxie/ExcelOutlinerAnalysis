from __future__ import annotations

from PySide6.QtCore import QCoreApplication, Qt
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QComboBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from easygraph.spreadsheet_io import SpreadsheetSheet
from easygraph.workbook import (
    SHEET_MODE_GROUPS,
    SHEET_MODE_XY,
    normalized_sheet_mode,
)


PREVIEW_ROWS = 12
PREVIEW_COLUMNS = 8


def _set_preview(table: QTableWidget, sheet: SpreadsheetSheet) -> None:
    dataframe = sheet.dataframe
    row_count = min(len(dataframe), PREVIEW_ROWS)
    column_count = min(len(dataframe.columns), PREVIEW_COLUMNS)
    table.clear()
    table.setRowCount(row_count)
    table.setColumnCount(column_count)
    table.setHorizontalHeaderLabels([str(column) for column in dataframe.columns[:column_count]])
    for row in range(row_count):
        for column in range(column_count):
            value = dataframe.iat[row, column]
            table.setItem(row, column, QTableWidgetItem("" if value is None else str(value)))
    table.resizeColumnsToContents()


def choose_spreadsheet_sheets(
    parent: QWidget,
    sheets: list[SpreadsheetSheet],
) -> list[SpreadsheetSheet] | None:
    if not sheets:
        return []

    dialog = QDialog(parent)
    dialog.setWindowTitle(QCoreApplication.translate("SpreadsheetImportDialog", "Import Excel Sheets"))
    dialog.resize(820, 480)
    root = QVBoxLayout(dialog)
    root.addWidget(QLabel(
        QCoreApplication.translate(
            "SpreadsheetImportDialog",
            "Select the worksheets to import. Each worksheet becomes an EasyGraph sheet.",
        ),
        dialog,
    ))

    mode_row = QHBoxLayout()
    mode_row.addWidget(QLabel(
        QCoreApplication.translate("SpreadsheetImportDialog", "Selected sheet type"),
        dialog,
    ))
    mode_combo = QComboBox(dialog)
    mode_combo.setObjectName("sheetModeCombo")
    mode_combo.addItem(
        QCoreApplication.translate("SpreadsheetImportDialog", "Groups"),
        SHEET_MODE_GROUPS,
    )
    mode_combo.addItem(
        QCoreApplication.translate("SpreadsheetImportDialog", "XY"),
        SHEET_MODE_XY,
    )
    mode_row.addWidget(mode_combo)
    mode_row.addStretch()
    root.addLayout(mode_row)

    content = QHBoxLayout()
    sheet_list = QListWidget(dialog)
    sheet_list.setMinimumWidth(260)
    preview = QTableWidget(dialog)
    preview.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    content.addWidget(sheet_list, 0)
    content.addWidget(preview, 1)
    root.addLayout(content, 1)

    buttons = QDialogButtonBox(
        QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
        parent=dialog,
    )
    root.addWidget(buttons)

    for index, sheet in enumerate(sheets):
        item = QListWidgetItem(
            QCoreApplication.translate(
                "SpreadsheetImportDialog",
                "{name}  —  {rows} rows × {columns} columns",
            ).format(
                name=sheet.name,
                rows=len(sheet.dataframe),
                columns=len(sheet.dataframe.columns),
            )
        )
        item.setData(Qt.ItemDataRole.UserRole, index)
        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
        has_data = bool(len(sheet.dataframe) and len(sheet.dataframe.columns))
        item.setCheckState(Qt.CheckState.Checked if has_data else Qt.CheckState.Unchecked)
        sheet_list.addItem(item)

    ok_button = buttons.button(QDialogButtonBox.StandardButton.Ok)
    modes = {
        index: normalized_sheet_mode(sheet.mode)
        for index, sheet in enumerate(sheets)
    }

    def selected_indexes() -> list[int]:
        return [
            int(sheet_list.item(row).data(Qt.ItemDataRole.UserRole))
            for row in range(sheet_list.count())
            if sheet_list.item(row).checkState() == Qt.CheckState.Checked
        ]

    def update_ok_button(*_args) -> None:
        ok_button.setEnabled(bool(selected_indexes()))

    def update_preview(row: int) -> None:
        if 0 <= row < sheet_list.count():
            index = int(sheet_list.item(row).data(Qt.ItemDataRole.UserRole))
            _set_preview(preview, sheets[index])
            mode_combo.blockSignals(True)
            try:
                mode_index = mode_combo.findData(modes[index])
                mode_combo.setCurrentIndex(max(mode_index, 0))
            finally:
                mode_combo.blockSignals(False)

    def update_mode(_combo_index: int) -> None:
        row = sheet_list.currentRow()
        if 0 <= row < sheet_list.count():
            index = int(sheet_list.item(row).data(Qt.ItemDataRole.UserRole))
            modes[index] = normalized_sheet_mode(mode_combo.currentData())

    sheet_list.itemChanged.connect(update_ok_button)
    sheet_list.currentRowChanged.connect(update_preview)
    mode_combo.currentIndexChanged.connect(update_mode)
    buttons.accepted.connect(dialog.accept)
    buttons.rejected.connect(dialog.reject)
    sheet_list.setCurrentRow(0)
    update_ok_button()

    if dialog.exec() != QDialog.DialogCode.Accepted:
        return None
    selected = [sheets[index] for index in selected_indexes()]
    for index in selected_indexes():
        sheets[index].mode = modes[index]
    return selected


__all__ = ["choose_spreadsheet_sheets"]
