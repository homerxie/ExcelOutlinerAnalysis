"""Contextual table tools that keep their target when the toolbar takes focus."""
from __future__ import annotations

from PySide6.QtCore import QObject
from PySide6.QtWidgets import QToolButton

from easygraph.table_structure import table_selection


class TableToolsController(QObject):
    """Bind the Designer-defined Table page to the active data table."""

    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.ui = window.ui
        self.active_table = None
        self._observed_tables = set()
        self._updating = False
        self._parent_actions_bound = False
        self.tabs = self.ui.topToolsTabs
        self.chart_index = self.tabs.indexOf(self.ui.chartToolsPage)
        self.table_index = self.tabs.indexOf(self.ui.tableToolsPage)
        self.tabs.setTabVisible(self.table_index, False)
        self.tabs.setCurrentIndex(self.chart_index)
        for button, method in (
            (self.ui.tableCopyButton, "copy_table_selection"),
            (self.ui.tableCutButton, "cut_table_selection"),
            (self.ui.tablePasteButton, "paste_table_selection"),
            (self.ui.tableClearButton, "clear_table_selection"),
        ):
            button.clicked.connect(lambda _checked=False, name=method: self._run(name))
        self.ui.tableUndoButton.clicked.connect(lambda: self._history("undo"))
        self.ui.tableRedoButton.clicked.connect(lambda: self._history("redo"))
        for button, mode, after in (
            (self.ui.tableInsertRowAboveButton, "entire_row", False),
            (self.ui.tableInsertRowBelowButton, "entire_row", True),
        ):
            button.clicked.connect(
                lambda _checked=False, m=mode, right=after: self._insert(m, right)
            )
        self.ui.tableInsertColumnLeftButton.clicked.connect(lambda: self._insert_column(False))
        self.ui.tableInsertColumnRightButton.clicked.connect(lambda: self._insert_column(True))
        self.ui.tableDeleteRowsButton.clicked.connect(lambda: self._delete("entire_row"))
        self.ui.tableDeleteColumnsButton.clicked.connect(lambda: self._delete("entire_column"))
        self._bind_parent_actions()
        self.update_state()

    def _bind_parent_actions(self):
        if self._parent_actions_bound:
            return
        groups = self.window.grouping_controls
        for button, key in (
            (self.ui.tableMergeParentButton, "merge"),
            (self.ui.tableUnmergeParentButton, "unmerge"),
            (self.ui.tableRenameParentButton, "rename"),
            (self.ui.tableInsertParentLeftButton, "insert_parent_left"),
            (self.ui.tableInsertParentRightButton, "insert_parent_right"),
            (self.ui.tableBatchParentsButton, "batch"),
        ):
            button.setDefaultAction(groups.action(key))
        self._parent_actions_bound = True

    def activate(self, table):
        """Enter Table once; later clicks in the same table respect a manual Chart choice."""
        changed = self.active_table is not table
        self.active_table = table
        self.tabs.setTabVisible(self.table_index, True)
        if changed:
            self.tabs.setCurrentIndex(self.table_index)
        if table not in self._observed_tables:
            self._observed_tables.add(table)
            table.selectionModel().selectionChanged.connect(self.update_state)
            table.selectionModel().currentChanged.connect(self.update_state)
            table.table_model.modelReset.connect(self.update_state)
            table.table_model.dataChanged.connect(self.update_state)
            header = table.horizontalHeader()
            if hasattr(header, "parentSelectionChanged"):
                header.parentSelectionChanged.connect(self.update_state)
        self.update_state()

    def deactivate(self):
        self.active_table = None
        self.tabs.setCurrentIndex(self.chart_index)
        self.tabs.setTabVisible(self.table_index, False)
        self.update_state()

    def _run(self, method):
        if self.active_table is not None:
            getattr(self.window, method)(self.active_table)
            self.update_state()

    def _history(self, method):
        if self.active_table is None:
            return
        controller = self.window._controller_for_table(self.active_table)
        getattr(controller, method)()
        if self.window._is_xy_sheet():
            self.window._sync_xy_views_to_sheet()
        self.window._refresh_table_capacity()
        self.update_state()

    def _insert(self, mode, after):
        if self.active_table is not None:
            self.window.insert_table_structure_relative(mode, after=after, table=self.active_table)
            self.update_state()

    def _insert_column(self, after):
        if self.active_table is None:
            return
        if self.window._is_xy_sheet():
            self._insert("entire_column", after)
        else:
            action = self.window.grouping_controls.action(
                "insert_subgroup_right" if after else "insert_subgroup_left"
            )
            if action.isEnabled():
                action.trigger()
            self.update_state()

    def _delete(self, mode):
        if self.active_table is not None:
            self.window.delete_table_structure(mode, self.active_table)
            self.update_state()

    def update_state(self, *_args):
        if self._updating:
            return
        self._updating = True
        try:
            self._update_state()
            self._update_hints()
        finally:
            self._updating = False

    def _update_hints(self):
        # Shared actions and XY/Groups transitions change their labels and
        # descriptions. Keep that information available on icon-only buttons.
        for button in self.ui.tableParentSection.findChildren(QToolButton):
            action = button.defaultAction()
            if action is not None:
                label, detail = action.text(), action.toolTip()
                button.setAccessibleName(label)
                button.setToolTip(label if detail == label else f"{label}\n{detail}")
        for button in (self.ui.tableInsertColumnLeftButton, self.ui.tableInsertColumnRightButton):
            label = button.text()
            detail = self.tr("In paired XY tables, insert a complete X/Y pair.") if self.window._is_xy_sheet() else ""
            button.setAccessibleName(label)
            button.setToolTip(f"{label}\n{detail}" if detail else label)

    def _update_state(self):
        table = self.active_table
        enabled = table is not None
        is_xy = self.window._is_xy_sheet()
        self.ui.tableParentSection.setVisible(not is_xy)
        self.ui.tableParentSeparator.setVisible(not is_xy)
        self.window.grouping_controls.update_actions()
        for button in (
            self.ui.tableCopyButton, self.ui.tableCutButton, self.ui.tablePasteButton,
            self.ui.tableClearButton, self.ui.tableUndoButton, self.ui.tableRedoButton,
            self.ui.tableInsertRowAboveButton, self.ui.tableInsertRowBelowButton,
            self.ui.tableInsertColumnLeftButton, self.ui.tableInsertColumnRightButton,
            self.ui.tableDeleteRowsButton, self.ui.tableDeleteColumnsButton,
        ):
            button.setEnabled(enabled)
        if table is None:
            return
        controller = self.window._controller_for_table(table)
        selection = table_selection(table)
        header = table.horizontalHeader()
        parent_columns = (
            header.selected_parent_columns()
            if not is_xy and hasattr(header, "selected_parent_columns") else []
        )
        has_cells = not selection.is_empty
        for button in (self.ui.tableCopyButton, self.ui.tableCutButton, self.ui.tableClearButton):
            button.setEnabled(has_cells)
        self.ui.tableCopyButton.setEnabled(has_cells or bool(parent_columns))
        self.ui.tableUndoButton.setEnabled(controller.history.can_undo)
        self.ui.tableRedoButton.setEnabled(controller.history.can_redo)
        self.ui.tablePasteButton.setEnabled(True)
        sample_rows = (
            has_cells and selection.is_rectangular
            and self.window._selection_uses_sample_rows(table, selection)
        )
        for button in (
            self.ui.tableInsertRowAboveButton, self.ui.tableInsertRowBelowButton,
            self.ui.tableDeleteRowsButton,
        ):
            button.setEnabled(sample_rows)
        self.ui.tableDeleteColumnsButton.setEnabled(
            not parent_columns and bool(self.window._structure_columns(table, selection))
            and self.window._can_delete_selected_columns(table)
        )
        if is_xy:
            columns = self.window._structure_columns(table, selection)
            for button in (self.ui.tableInsertColumnLeftButton, self.ui.tableInsertColumnRightButton):
                button.setEnabled(bool(columns))
                button.setText(self.tr("Insert column right") if button is self.ui.tableInsertColumnRightButton else self.tr("Insert column left"))
                button.setToolTip(self.tr("In paired XY tables, insert a complete X/Y pair."))
        else:
            for button, key in (
                (self.ui.tableInsertColumnLeftButton, "insert_subgroup_left"),
                (self.ui.tableInsertColumnRightButton, "insert_subgroup_right"),
            ):
                action = self.window.grouping_controls.action(key)
                button.setEnabled(action.isEnabled())
                button.setText(action.text())
                button.setToolTip(action.toolTip())
            self.ui.tableSelectionSummary.setText(self.window.grouping_controls.selection_summary())
