from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, TypeVar

import pandas as pd
from PySide6.QtCore import QCoreApplication, QTimer, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QAbstractItemDelegate, QLineEdit, QWidget

from easygraph.data_table import DataTable
from easygraph.clipboard_table import CellMerge, ClipboardTable, clipboard_table_to_tsv
from easygraph.palette import blend_qcolors
from easygraph.settings import ChartSettings
from easygraph.table_actions import (
    append_group_column,
    current_or_last_column,
    insert_sample_row,
    remove_current_or_last_group_column,
)
from easygraph.table_clipboard import (
    clear_selected_table_items,
    cut_selection_to_tsv,
    paste_rows_into_table,
    paste_start_cell,
    paste_tsv_into_table,
    selected_range_to_tsv,
    tsv_to_rows,
)
from easygraph.data import attach_group_metadata, group_keys, migrate_group_settings
from easygraph.grouping import create_parent, normalize_grouping, parent_for_column, ungroup_columns
from easygraph.table_data import (
    custom_overlay_series_from_table,
    normalized_hidden_overlay_indexes,
    populate_table_from_dataframe,
    sample_start_row_for_overlay_count,
    sync_group_order_state,
    table_group_names,
    table_sample_dataframe,
)
from easygraph.table_history import (
    BlockEdit,
    CellEdit,
    SettingsEdit,
    StructureSnapshotEdit,
    TableHistoryState,
    run_table_history_mutation,
)
from easygraph.table_editor import navigation_delta, next_table_cell
from easygraph.table_refresh import refresh_table_structure
from easygraph.table_snapshot import (
    apply_sheet_state_snapshot,
    apply_snapshot_settings,
    build_settings_snapshot,
    build_table_snapshot,
    snapshot_cell_text,
    snapshot_current_cell,
    snapshot_shape,
)
from easygraph.workbook import SHEET_MODE_XY, SheetDocument, new_column_id
from easygraph.xy_series import remove_xy_column_references, xy_column_headers


T = TypeVar("T")


@dataclass(frozen=True)
class TableControllerHooks:
    render: Callable[[], None]
    update_history_actions: Callable[[bool, bool], None]
    update_dependent_controls: Callable[[], None]
    sync_overlay_controls: Callable[[], None]
    sheet_state_changed: Callable[[], None] | None = None


class TableController:
    def __init__(
        self,
        table: DataTable,
        settings: Callable[[], ChartSettings],
        hooks: TableControllerHooks,
        sheet: Callable[[], SheetDocument] | None = None,
        column_ids: Callable[[], list[str]] | None = None,
    ) -> None:
        self.table = table
        self._settings = settings
        self._sheet = sheet
        self._column_ids = column_ids
        self.hooks = hooks
        self.history = TableHistoryState()
        self._custom_overlay_rows = 0
        self.history_restoring = False
        self.history_suspended = False
        self._data_revision = 0
        self._cached_dataframe_revision = -1
        self._cached_dataframe: pd.DataFrame | None = None
        self._pending_cell_edit: tuple[CellEdit, dict] | None = None
        self.table.table_model.cellEdited.connect(self._observe_model_edit)

    @property
    def settings(self) -> ChartSettings:
        return self._settings()

    @property
    def sheet(self) -> SheetDocument | None:
        return self._sheet() if self._sheet is not None else None

    @property
    def is_xy(self) -> bool:
        return self.sheet is not None and self.sheet.mode == SHEET_MODE_XY

    @property
    def column_ids(self) -> list[str]:
        if self._column_ids is not None:
            return list(self._column_ids())
        return list(self.sheet.column_ids) if self.sheet is not None else []

    @property
    def column_name_prefix(self) -> str:
        return "Column" if self.is_xy else "Group"

    def _notify_sheet_state_changed(self) -> None:
        if self.hooks.sheet_state_changed is not None:
            self.hooks.sheet_state_changed()

    @property
    def data_revision(self) -> int:
        return self._data_revision

    def invalidate_dataframe(self, *_args) -> None:
        self._data_revision += 1
        self._cached_dataframe_revision = -1
        self._cached_dataframe = None

    def _cell_text(self, row: int, column: int) -> str:
        return self.table.table_model.cell_text(row, column)

    def _observe_model_edit(self, row: int, column: int, before: str, after: str) -> None:
        self.invalidate_dataframe()
        if self.history_restoring or self.history_suspended or before == after:
            return
        self._pending_cell_edit = (
            CellEdit(row, column, before, after),
            build_settings_snapshot(self.settings),
        )

    def set_dataframe(self, df: pd.DataFrame, overlay_series: list[dict] | None = None) -> None:
        if not self.is_xy and len(self.column_ids) == len(df.columns):
            df = attach_group_metadata(df, self.column_ids)
            migrate_group_settings(self.settings, df)
        series = list(self.settings.custom_overlay_series if overlay_series is None else overlay_series)
        if self.is_xy:
            series = []
        self._custom_overlay_rows = len(series)
        populate_table_from_dataframe(self.table, df, series)
        self._pending_cell_edit = None
        self.invalidate_dataframe()
        self.refresh_structure()

    def dataframe(self) -> pd.DataFrame:
        if (
            self._cached_dataframe is None
            or self._cached_dataframe_revision != self._data_revision
        ):
            self._cached_dataframe = table_sample_dataframe(
                self.table,
                self.sample_start_row(),
                self.column_name_prefix,
            )
            self._cached_dataframe_revision = self._data_revision
        result = self._cached_dataframe.copy()
        if not self.is_xy and len(self.column_ids) == len(result.columns):
            result = attach_group_metadata(result, self.column_ids)
        return result

    def overlay_row_count(self) -> int:
        return self._custom_overlay_rows

    def sample_start_row(self) -> int:
        return sample_start_row_for_overlay_count(self._custom_overlay_rows)

    def group_names(self) -> list[str]:
        return table_group_names(self.table, self.column_name_prefix)

    def overlay_series_from_table(self) -> list[dict]:
        if self.is_xy:
            return []
        return custom_overlay_series_from_table(
            self.table,
            self.sample_start_row(),
            self.column_ids if len(self.column_ids) == self.table.table_model.columnCount() else group_keys(pd.DataFrame(columns=self.group_names())),
            self.settings.custom_overlay_series,
        )

    def refresh_structure(self) -> None:
        sheet = self.sheet
        xy_headers = (
            xy_column_headers(sheet.xy_settings, self.column_ids)
            if sheet is not None and sheet.mode == SHEET_MODE_XY
            else None
        )
        labels = [header.label for header in xy_headers] if xy_headers is not None else None
        tooltips = None
        if xy_headers is not None:
            tooltip_template = QCoreApplication.translate(
                "TableHeaders",
                "Matches: %1",
            )
            tooltips = [
                tooltip_template.replace("%1", ", ".join(header.matched_y_labels))
                if header.matched_y_labels
                else ""
                for header in xy_headers
            ]
        refresh_table_structure(
            self.table,
            self.sample_start_row(),
            self.settings.custom_overlay_series,
            self.overlay_row_count(),
            blend_qcolors,
            column_labels=labels,
            column_tooltips=tooltips,
        )
        header = self.table.horizontalHeader()
        if hasattr(header, "set_grouping"):
            header.set_parent_band_enabled(not self.is_xy)
            if sheet is not None and not self.is_xy:
                normalize_grouping(sheet.grouping, self.column_ids)
                header.set_grouping(sheet.grouping.parents, self.column_ids)
            else:
                header.set_grouping([], [])

    def sync_manual_group_order(self) -> None:
        if self.is_xy:
            return
        settings = self.settings
        dataframe = self.dataframe()
        migrate_group_settings(settings, dataframe)
        settings.manual_group_order, settings.group_hidden = sync_group_order_state(
            group_keys(dataframe),
            settings.manual_group_order,
            settings.group_hidden,
        )

    def snapshot(self) -> dict:
        return build_table_snapshot(
            self.table,
            self.settings,
            self._custom_overlay_rows,
            self.sheet if self._column_ids is None or not self.is_xy else None,
        )

    def restore_snapshot(self, snapshot: dict) -> None:
        row_count, col_count = snapshot_shape(snapshot)
        self.history_restoring = True
        was_blocked = self.table.signalsBlocked()
        self.table.blockSignals(True)
        try:
            self._custom_overlay_rows = int(snapshot.get("custom_overlay_rows", 0))
            apply_snapshot_settings(snapshot, self.settings)
            cells = [
                [snapshot_cell_text(snapshot, row, col) for col in range(col_count)]
                for row in range(row_count)
            ]
            self.table.table_model.replace_cells(cells, column_count=col_count)
            self.invalidate_dataframe()
            sheet = self.sheet
            if sheet is not None and "sheet_mode" in snapshot:
                sheet.dataframe = table_sample_dataframe(
                    self.table,
                    self.sample_start_row(),
                    "Column" if snapshot.get("sheet_mode") == SHEET_MODE_XY else "Group",
                )
                apply_sheet_state_snapshot(snapshot, sheet)
            row, col = snapshot_current_cell(snapshot, row_count, col_count)
            if row_count and col_count:
                self.table.setCurrentIndex(self.table.table_model.index(row, col))
            self.refresh_structure()
            # The snapshot already carries the exact order/visibility state.
            # Re-deriving it here can promote a runtime-only trailing capacity
            # column into a real group before the window restores its spare
            # provenance after undo/redo.
        finally:
            self.table.blockSignals(was_blocked)
            self.history_restoring = False
        self.invalidate_dataframe()
        self._pending_cell_edit = None
        settings = self.settings
        settings.custom_overlay_hidden = normalized_hidden_overlay_indexes(
            settings.custom_overlay_hidden,
            len(settings.custom_overlay_series),
        )
        self.hooks.sync_overlay_controls()
        self.hooks.update_dependent_controls()
        self._notify_sheet_state_changed()
        self.hooks.render()

    def reset_history(self) -> None:
        self.history.reset()
        self._pending_cell_edit = None
        self.update_history_actions()

    def record_history_change(self, before: dict | None = None) -> None:
        if self.history_restoring or self.history_suspended:
            return
        if before is not None:
            self.history.record(StructureSnapshotEdit(before, self.snapshot()))
        elif self._pending_cell_edit is not None:
            edit, settings_before = self._pending_cell_edit
            self._pending_cell_edit = None
            self._record_cell_edits(
                (edit,),
                settings_before,
                build_settings_snapshot(self.settings),
            )
        self.update_history_actions()

    def _set_history_suspended(self, value: bool) -> None:
        self.history_suspended = value

    def run_history_mutation(
        self,
        mutate: Callable[[], T],
        after: Callable[[T], None] | None = None,
    ) -> T:
        before, result, changed = run_table_history_mutation(
            self.snapshot,
            self._set_history_suspended,
            mutate,
        )
        if not changed:
            return result
        self.invalidate_dataframe()
        if after is not None:
            after(result)
        self.history.record(StructureSnapshotEdit(before, self.snapshot()))
        self._pending_cell_edit = None
        self.update_history_actions()
        return result

    def update_history_actions(self) -> None:
        self.hooks.update_history_actions(self.history.can_undo, self.history.can_redo)

    def _record_cell_edits(
        self,
        edits: tuple[CellEdit, ...],
        settings_before: dict,
        settings_after: dict,
        *,
        force_block: bool = False,
    ) -> None:
        changed = tuple(edit for edit in edits if edit.changed)
        shared_edits = self._sync_shared_headers({edit.column: edit.after for edit in changed if edit.row == 0})
        changed = tuple(CellEdit(edit.row, edit.column, edit.before, self._cell_text(edit.row, edit.column)) for edit in changed)
        changed += tuple(edit for edit in shared_edits if (edit.row, edit.column) not in {(item.row, item.column) for item in changed})
        if not changed:
            if settings_before != settings_after:
                self.history.record(SettingsEdit(settings_before, settings_after))
            return
        if len(changed) == 1 and settings_before == settings_after and not force_block:
            self.history.record(changed[0])
            return
        self.history.record(
            BlockEdit(
                changed,
                settings_before=settings_before,
                settings_after=settings_after,
            )
        )

    def _sync_shared_headers(self, headers: dict[int, str]) -> tuple[CellEdit, ...]:
        sheet = self.sheet
        if not headers or self.is_xy or sheet is None or not sheet.grouping.shared_subgroups:
            return ()
        categories = {
            sheet.grouping.subgroup_ids[sheet.column_ids[column]]: value
            for column, value in headers.items()
            if column < len(sheet.column_ids) and sheet.column_ids[column] in sheet.grouping.subgroup_ids
        }
        edits = []
        was_suspended = self.history_suspended
        self.history_suspended = True
        try:
            for column, key in enumerate(sheet.column_ids):
                category = sheet.grouping.subgroup_ids.get(key)
                if category in categories and column < self.table.table_model.columnCount():
                    before = self._cell_text(0, column)
                    after = categories[category]
                    if before != after:
                        self.table.table_model.set_cell_text(0, column, after)
                        edits.append(CellEdit(0, column, before, after))
        finally:
            self.history_suspended = was_suspended
        return tuple(edits)

    def _edits_for_cells(
        self,
        positions: list[tuple[int, int]],
        before_values: dict[tuple[int, int], str],
    ) -> tuple[CellEdit, ...]:
        return tuple(
            CellEdit(row, column, before_values[(row, column)], self._cell_text(row, column))
            for row, column in positions
        )

    def apply_history_cells(
        self,
        values: tuple[tuple[int, int, str], ...],
        settings: dict | None = None,
    ) -> None:
        self.history_restoring = True
        was_blocked = self.table.signalsBlocked()
        self.table.blockSignals(True)
        try:
            for row, column, text in values:
                self.table.table_model.set_cell_text(row, column, text)
            if settings is not None:
                apply_snapshot_settings(settings, self.settings)
        finally:
            self.table.blockSignals(was_blocked)
            self.history_restoring = False

        self.invalidate_dataframe()
        if any(row < self.sample_start_row() for row, _column, _text in values):
            self.refresh_structure()
        if settings is not None:
            self.settings.custom_overlay_hidden = normalized_hidden_overlay_indexes(
                self.settings.custom_overlay_hidden,
                len(self.settings.custom_overlay_series),
            )
            self.hooks.sync_overlay_controls()
            self.hooks.update_dependent_controls()
        self.hooks.render()

    def apply_history_settings(self, settings: dict) -> None:
        apply_snapshot_settings(settings, self.settings)
        self.refresh_structure()
        self.hooks.sync_overlay_controls()
        self.hooks.update_dependent_controls()
        self.hooks.render()

    def restore_history_snapshot(self, snapshot: dict) -> None:
        self.restore_snapshot(snapshot)

    def undo(self) -> None:
        if self.history.undo(self) is None:
            return
        self.update_history_actions()

    def redo(self) -> None:
        if self.history.redo(self) is None:
            return
        self.update_history_actions()

    def handle_editor_navigation(self, event: QKeyEvent, editor: QWidget | None = None) -> bool:
        if not isinstance(editor, QLineEdit) or not self.table.isAncestorOf(editor):
            return False
        modifiers = event.modifiers() & ~Qt.KeypadModifier
        if modifiers != Qt.NoModifier:
            return False
        move = navigation_delta(event.key())
        if move is None:
            return False
        current = self.table.currentIndex()
        row = current.row()
        col = current.column()
        row_count = self.table.table_model.rowCount()
        column_count = self.table.table_model.columnCount()
        target = next_table_cell(
            row,
            col,
            row_count,
            column_count,
            move,
        )
        enter_moves_to_new_trailing_row = (
            event.key() in (Qt.Key_Return, Qt.Key_Enter)
            and move == (1, 0)
            and row == row_count - 1
            and 0 <= col < column_count
        )
        if target is None and enter_moves_to_new_trailing_row:
            target = (row + 1, col)
        if target is None:
            return False
        if not current.isValid():
            return False
        delegate = self.table.itemDelegate()
        if delegate is None:
            return False
        # Let the view perform its normal editor commit before changing the
        # current index. Manually writing the model and moving first leaves Qt
        # with an orphaned editor, which later produces a commitData warning
        # and bypasses the normal cell-edited render/history path.
        delegate.commitData.emit(editor)
        delegate.closeEditor.emit(
            editor,
            QAbstractItemDelegate.EndEditHint.NoHint,
        )
        next_row, next_col = target
        if next_row < self.table.table_model.rowCount():
            next_index = self.table.table_model.index(next_row, next_col)
            self.table.setCurrentIndex(next_index)
            QTimer.singleShot(0, lambda index=next_index: self.table.edit(index))
        else:
            # Committing a used trailing row schedules capacity expansion.
            # Navigate only after that zero-delay update has appended the new
            # blank row, so the next editor is attached to a valid index.
            QTimer.singleShot(
                0,
                lambda target_row=next_row, target_col=next_col: self._edit_cell_if_valid(
                    target_row,
                    target_col,
                ),
            )
        return True

    def _edit_cell_if_valid(self, row: int, column: int) -> None:
        model = self.table.table_model
        if not (0 <= row < model.rowCount() and 0 <= column < model.columnCount()):
            return
        index = model.index(row, column)
        self.table.setCurrentIndex(index)
        self.table.edit(index)

    def copy_selection(self) -> str:
        return selected_range_to_tsv(self.table)

    def copy_selection_data(self, *, column_limit: int | None = None) -> ClipboardTable | None:
        """Include the separate parent band when copying group headers."""
        header = self.table.horizontalHeader()
        parent_columns = (
            header.selected_parent_columns()
            if not self.is_xy and hasattr(header, "selected_parent_columns")
            else []
        )
        ranges = self.table.selectionModel().selection()
        if parent_columns:
            left, right = min(parent_columns), max(parent_columns)
            if column_limit is not None:
                right = min(right, column_limit - 1)
            if right < left:
                return None
            rows = []
            include_parents = True
        elif ranges:
            selected = ranges[0]
            left, right = selected.left(), selected.right()
            if column_limit is not None:
                right = min(right, column_limit - 1)
            if right < left:
                return None
            rows = [
                [self._cell_text(row, column) for column in range(left, right + 1)]
                for row in range(selected.top(), selected.bottom() + 1)
            ]
            include_parents = (
                not self.is_xy
                and selected.top() == 0
                and self.sheet is not None
                and any(
                    parent_for_column(self.sheet.grouping, key) is not None
                    for key in self.column_ids[left:right + 1]
                )
            )
        else:
            return None
        if not include_parents:
            return ClipboardTable(rows, header_rows=0)

        titles = [""] * (right - left + 1)
        merges = []
        column = left
        while column <= right:
            parent = (
                parent_for_column(self.sheet.grouping, self.column_ids[column])
                if self.sheet is not None and column < len(self.column_ids)
                else None
            )
            if parent is None:
                column += 1
                continue
            end = column + 1
            members = set(parent["column_ids"])
            while end <= right and end < len(self.column_ids) and self.column_ids[end] in members:
                end += 1
            titles[column - left] = parent["name"]
            if end - column > 1:
                merges.append(CellMerge(0, column - left, colspan=end - column))
            column = end
        return ClipboardTable(
            [titles, *rows],
            merges=merges,
            header_rows=1 if parent_columns else 2,
        )

    def paste_clipboard(
        self,
        data: ClipboardTable,
        after_paste: Callable[[], None] | None = None,
    ) -> bool:
        """Restore merged parent headers and their values as one undo step.

        A regular HTML table retains ordinary paste behavior. The first row is
        a parent band only when our metadata, its horizontal merges, or the
        explicit parent-header selection identifies it as such.
        """
        if not data.rows:
            return False
        header = self.table.horizontalHeader()
        parent_columns = (
            header.selected_parent_columns()
            if not self.is_xy and hasattr(header, "selected_parent_columns")
            else []
        )
        has_parent_row = bool(
            parent_columns
            or data.header_rows in (1, 2)
            or (
                data.header_rows is None
                and any(merge.row == 0 and merge.colspan > 1 for merge in data.merges)
            )
        )
        if data.merges and (
            not has_parent_row
            or any(merge.row != 0 or merge.rowspan != 1 for merge in data.merges)
        ):
            raise ValueError("Only horizontal parent-header merges are supported.")
        if not has_parent_row:
            return self.paste_text(clipboard_table_to_tsv(data), after_paste=after_paste)
        if self.is_xy or self.sheet is None:
            raise ValueError("Parent headers can only be pasted into a Groups table.")

        start_column = (
            min(parent_columns)
            if parent_columns
            else max(self.table.currentIndex().column(), 0)
        )
        width = max((len(row) for row in data.rows), default=0)
        if not width:
            return False
        parent_row = list(data.rows[0]) + [""] * (width - len(data.rows[0]))
        merges_by_column = {merge.column: merge for merge in data.merges}
        blocks = []
        column = 0
        while column < width:
            merge = merges_by_column.get(column)
            count = merge.colspan if merge is not None else 1
            if count < 1 or column + count > width:
                raise ValueError("The merged parent header extends beyond the copied table.")
            if parent_row[column].strip() or (merge is not None and count > 1):
                blocks.append((column, count, parent_row[column]))
            column += count

        rename_parent = (
            parent_for_column(self.sheet.grouping, self.column_ids[start_column])
            if parent_columns
            and len(data.rows) == 1
            and width == 1
            and not data.merges
            and data.header_rows != 2
            and start_column < len(self.column_ids)
            else None
        )

        def mutate() -> bool:
            if rename_parent is not None:
                rename_parent["name"] = parent_row[0]
                return True
            model = self.table.table_model
            model.resize(max(model.rowCount(), 1), max(model.columnCount(), start_column + width))
            self._reconcile_sheet_column_ids()
            if len(data.rows) > 1:
                paste_rows_into_table(self.table, data.rows[1:], 0, start_column)
            else:
                for target in range(start_column, start_column + width):
                    if not self._cell_text(0, target).strip():
                        model.set_cell_text(0, target, f"Group {target + 1}")
            column_ids = self.sheet.column_ids
            ungroup_columns(self.sheet.grouping, column_ids[start_column:start_column + width])
            # Overwriting the middle of a parent leaves independent pieces.
            # Keep those pieces merged without drawing across the new group.
            positions = {key: index for index, key in enumerate(column_ids)}
            parents = []
            for parent in self.sheet.grouping.parents:
                runs: list[list[str]] = []
                for key in sorted(parent["column_ids"], key=positions.__getitem__):
                    if not runs or positions[key] != positions[runs[-1][-1]] + 1:
                        runs.append([])
                    runs[-1].append(key)
                parents.extend(
                    {**parent, "id": parent["id"] if index == 0 else new_column_id(), "column_ids": members}
                    for index, members in enumerate(runs)
                )
            self.sheet.grouping.parents = parents
            for offset, count, name in blocks:
                first = start_column + offset
                create_parent(self.sheet.grouping, column_ids[first:first + count], name)
            normalize_grouping(self.sheet.grouping, column_ids)
            return True

        def after(result: bool) -> None:
            self._after_structure_mutation(result, sync_order=True)
            if after_paste is not None:
                after_paste()

        return self.run_history_mutation(mutate, after=after)

    def cut_selection(self) -> str:
        text = selected_range_to_tsv(self.table)
        if not text:
            return ""
        positions = sorted({
            (index.row(), index.column())
            for index in self.table.selectionModel().selectedIndexes()
        })
        before_values = {position: self._cell_text(*position) for position in positions}
        settings_before = build_settings_snapshot(self.settings)
        self.history_suspended = True
        try:
            result = cut_selection_to_tsv(self.table)
        finally:
            self.history_suspended = False
        self.invalidate_dataframe()
        self._record_cell_edits(
            self._edits_for_cells(positions, before_values),
            settings_before,
            build_settings_snapshot(self.settings),
            force_block=True,
        )
        self.update_history_actions()
        self.hooks.render()
        return result

    def _after_structure_mutation(self, _result: object, *, sync_order: bool) -> None:
        self._reconcile_sheet_column_ids()
        self.refresh_structure()
        if sync_order:
            self.sync_manual_group_order()
        self._notify_sheet_state_changed()
        self.hooks.render()

    def _reconcile_sheet_column_ids(self) -> None:
        sheet = self.sheet
        if sheet is None or (self._column_ids is not None and self.is_xy):
            return
        column_count = self.table.table_model.columnCount()
        if len(sheet.column_ids) < column_count:
            sheet.column_ids.extend(
                new_column_id() for _ in range(column_count - len(sheet.column_ids))
            )
        elif len(sheet.column_ids) > column_count:
            removed = set(sheet.column_ids[column_count:])
            del sheet.column_ids[column_count:]
            remove_xy_column_references(sheet.xy_settings, removed)

    def paste_text(
        self,
        text: str,
        after_paste: Callable[[], None] | None = None,
    ) -> bool:
        if not text:
            return False
        rows = tsv_to_rows(text)
        if not rows:
            return False
        start_row, start_column = paste_start_cell(
            self.table.currentIndex().row(),
            self.table.currentIndex().column(),
        )
        needed_rows = start_row + len(rows)
        needed_columns = start_column + max(len(row) for row in rows)
        if start_row == 0 and self.sheet is not None and not self.is_xy and self.sheet.grouping.shared_subgroups:
            def paste_shared_headers():
                paste_tsv_into_table(self.table, text)
                self._reconcile_sheet_column_ids()
                self._sync_shared_headers({start_column + offset: value for offset, value in enumerate(rows[0])})
                return True
            def after_shared_paste(result):
                self._after_structure_mutation(result, sync_order=True)
                if after_paste is not None:
                    after_paste()
            return self.run_history_mutation(paste_shared_headers, after=after_shared_paste)
        if (
            needed_rows > self.table.table_model.rowCount()
            or needed_columns > self.table.table_model.columnCount()
        ):
            def after_expanding_paste(result: object) -> None:
                self._after_structure_mutation(result, sync_order=True)
                if after_paste is not None:
                    after_paste()

            return self.run_history_mutation(
                lambda: paste_tsv_into_table(self.table, text),
                after=after_expanding_paste,
            )

        if after_paste is not None:
            def paste_and_configure() -> bool:
                paste_rows_into_table(
                    self.table,
                    rows,
                    start_row,
                    start_column,
                )
                return True

            def after_same_shape_paste(result: object) -> None:
                self._after_structure_mutation(result, sync_order=True)
                after_paste()

            return self.run_history_mutation(
                paste_and_configure,
                after=after_same_shape_paste,
            )

        positions = [
            (start_row + row_offset, start_column + column_offset)
            for row_offset, row_values in enumerate(rows)
            for column_offset, _value in enumerate(row_values)
        ]
        before_values = {position: self._cell_text(*position) for position in positions}
        settings_before = build_settings_snapshot(self.settings)
        self.history_suspended = True
        try:
            paste_rows_into_table(self.table, rows, start_row, start_column)
        finally:
            self.history_suspended = False
        self.invalidate_dataframe()
        self._after_structure_mutation(True, sync_order=True)
        self._record_cell_edits(
            self._edits_for_cells(positions, before_values),
            settings_before,
            build_settings_snapshot(self.settings),
            force_block=True,
        )
        self.update_history_actions()
        return True

    def clear_selection(self) -> bool:
        if not self.table.selectionModel().selectedIndexes():
            return False
        positions = sorted({
            (index.row(), index.column())
            for index in self.table.selectionModel().selectedIndexes()
        })
        before_values = {position: self._cell_text(*position) for position in positions}
        settings_before = build_settings_snapshot(self.settings)
        self.history_suspended = True
        try:
            changed = clear_selected_table_items(self.table)
        finally:
            self.history_suspended = False
        if not changed:
            return False
        self.invalidate_dataframe()
        self._record_cell_edits(
            self._edits_for_cells(positions, before_values),
            settings_before,
            build_settings_snapshot(self.settings),
            force_block=True,
        )
        self.update_history_actions()
        self.hooks.render()
        return True

    def run_block_mutation(
        self,
        positions: list[tuple[int, int]],
        mutate: Callable[[], T],
        after: Callable[[T], None] | None = None,
    ) -> T:
        before_values = {position: self._cell_text(*position) for position in positions}
        settings_before = build_settings_snapshot(self.settings)
        self.history_suspended = True
        try:
            result = mutate()
        finally:
            self.history_suspended = False
        changed = result if isinstance(result, bool) else True
        if not changed:
            return result
        self.invalidate_dataframe()
        if after is not None:
            after(result)
        self._record_cell_edits(
            self._edits_for_cells(positions, before_values),
            settings_before,
            build_settings_snapshot(self.settings),
            force_block=True,
        )
        self.update_history_actions()
        return result

    def run_settings_mutation(
        self,
        mutate: Callable[[], T],
        after: Callable[[T], None] | None = None,
    ) -> T:
        settings_before = build_settings_snapshot(self.settings)
        self.history_suspended = True
        try:
            result = mutate()
        finally:
            self.history_suspended = False
        changed = result if isinstance(result, bool) else True
        if not changed:
            return result
        if after is not None:
            after(result)
        self.history.record(
            SettingsEdit(settings_before, build_settings_snapshot(self.settings))
        )
        self.update_history_actions()
        return result

    def add_sample_row(self) -> int:
        return self.run_history_mutation(
            lambda: insert_sample_row(self.table),
            after=lambda result: self._after_structure_mutation(result, sync_order=False),
        )

    def add_group_column(self) -> int:
        return self.run_history_mutation(
            lambda: append_group_column(self.table, self.column_name_prefix),
            after=lambda result: self._after_structure_mutation(result, sync_order=True),
        )

    def delete_group_column(self) -> bool:
        column = current_or_last_column(self.table)

        def remove_column() -> bool:
            removed_column_id = None
            sheet = self.sheet
            if sheet is not None and 0 <= column < len(sheet.column_ids):
                removed_column_id = sheet.column_ids[column]
            result = remove_current_or_last_group_column(self.table)
            if result and sheet is not None and removed_column_id is not None:
                sheet.column_ids.pop(column)
                remove_xy_column_references(
                    sheet.xy_settings,
                    {removed_column_id},
                )
            return result

        return self.run_history_mutation(
            remove_column,
            after=lambda result: self._after_structure_mutation(result, sync_order=True),
        )
