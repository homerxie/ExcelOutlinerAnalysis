"""Plot-order editing without changing the table or parent membership."""
from __future__ import annotations

from collections import Counter
from copy import deepcopy

from PySide6.QtCore import QItemSelectionModel, QObject, Qt
from PySide6.QtWidgets import QDialog, QListWidget, QListWidgetItem, QWidget

from easygraph.grouping import ordered_group_blocks
from ui_grouped_order_dialog import Ui_GroupedOrderDialog


class GroupedOrderDialogController(QObject):
    """Keep an outer block order and a separate member order per parent."""

    def __init__(
        self,
        dialog: QDialog,
        ui: Ui_GroupedOrderDialog,
        current_order: list[str],
        table_order: list[str],
        *,
        parents: list[dict],
        item_labels: dict[str, str],
    ) -> None:
        super().__init__(dialog)
        self.ui = ui
        self.table_order = list(dict.fromkeys(table_order))
        self.parents = deepcopy(parents)
        self.item_labels = dict(item_labels)
        self._parent_names = {parent["id"]: parent["name"] for parent in self.parents}
        counts = Counter(self._parent_names.values())
        seen: Counter[str] = Counter()
        self._parent_labels = {}
        for parent_id, name in self._parent_names.items():
            seen[name] += 1
            self._parent_labels[parent_id] = (
                self.tr("{name} ({number})").format(name=name, number=seen[name])
                if counts[name] > 1 else name
            )
        self._members: dict[str, list[str]] = {}
        self._parent_ids: dict[str, str | None] = {}
        self._shown_key: str | None = None
        self._updating = False
        ui.outerList.itemSelectionChanged.connect(self._outer_selection_changed)
        ui.innerList.itemSelectionChanged.connect(self._update_buttons)
        # QListWidget's InternalMove mode accepts drops only from the same list.
        # A parent or child therefore cannot be moved into the other hierarchy.
        ui.outerList.model().rowsMoved.connect(self._outer_rows_moved)
        ui.innerList.model().rowsMoved.connect(self._inner_rows_moved)
        ui.outerUpButton.clicked.connect(lambda: self.move_selected(ui.outerList, -1))
        ui.outerDownButton.clicked.connect(lambda: self.move_selected(ui.outerList, 1))
        ui.innerUpButton.clicked.connect(lambda: self.move_selected(ui.innerList, -1))
        ui.innerDownButton.clicked.connect(lambda: self.move_selected(ui.innerList, 1))
        ui.tableOrderButton.clicked.connect(self.reset_to_table_order)
        valid = set(self.table_order)
        order = list(dict.fromkeys([item for item in current_order if item in valid] + self.table_order))
        self._populate(order)

    @staticmethod
    def _list_keys(widget: QListWidget) -> list[str]:
        return [widget.item(row).data(Qt.UserRole) for row in range(widget.count())]

    def _populate(self, order: list[str]) -> None:
        self._updating = True
        self._shown_key = None
        self._members.clear()
        self._parent_ids.clear()
        self.ui.outerList.clear()
        self.ui.innerList.clear()
        for parent_id, members in ordered_group_blocks(order, self.parents):
            key = f"parent:{parent_id}" if parent_id is not None else f"column:{members[0]}"
            self._members[key] = list(members)
            self._parent_ids[key] = parent_id
            if parent_id is not None:
                label = self.tr("Group: {name}").format(name=self._parent_labels[parent_id])
                tooltip = self.tr("{count} columns: {names}").format(
                    count=len(members),
                    names=", ".join(self.item_labels.get(member, member) for member in members),
                )
            else:
                label = self.tr("Ungrouped: {name}").format(name=self.item_labels.get(members[0], members[0]))
                tooltip = self.tr("This column has no parent group. Move it in the left list.")
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, key)
            item.setToolTip(tooltip)
            self.ui.outerList.addItem(item)
        if self.ui.outerList.count():
            self.ui.outerList.setCurrentRow(0)
        self._updating = False
        self._outer_selection_changed()

    def _save_members(self) -> None:
        if self._shown_key is None:
            return
        members = self._list_keys(self.ui.innerList)
        # Never accept a transient or foreign list as a membership change.
        previous = self._members[self._shown_key]
        if len(members) == len(previous) and set(members) == set(previous):
            self._members[self._shown_key] = members

    def _outer_selection_changed(self) -> None:
        if self._updating:
            return
        self._save_members()
        selected = self.ui.outerList.selectedItems()
        key = selected[0].data(Qt.UserRole) if len(selected) == 1 else None
        if key == self._shown_key and key is not None:
            self._update_buttons()
            return
        self._updating = True
        self._shown_key = None
        self.ui.innerList.clear()
        is_parent = key is not None and self._parent_ids[key] is not None
        self.ui.innerList.setEnabled(is_parent)
        if key is None:
            self.ui.innerHintLabel.setText(self.tr("Select one parent group to reorder its columns."))
        elif not is_parent:
            self.ui.innerHintLabel.setText(self.tr("This column has no parent group. Move it in the left list."))
        else:
            self._shown_key = key
            self.ui.innerHintLabel.setText(
                self.tr("Columns in {name}").format(name=self._parent_labels[self._parent_ids[key]])
            )
        if key is not None:
            for member in self._members[key]:
                item = QListWidgetItem(self.item_labels.get(member, member))
                item.setData(Qt.UserRole, member)
                self.ui.innerList.addItem(item)
            if is_parent and self.ui.innerList.count():
                self.ui.innerList.setCurrentRow(0)
        self._updating = False
        self._update_buttons()

    def _outer_rows_moved(self, *_args) -> None:
        if not self._updating:
            self._update_buttons()

    def _inner_rows_moved(self, *_args) -> None:
        if not self._updating:
            self._save_members()
            self._update_buttons()

    def _update_buttons(self, *_args) -> None:
        if self._updating:
            return
        for widget, up, down in (
            (self.ui.outerList, self.ui.outerUpButton, self.ui.outerDownButton),
            (self.ui.innerList, self.ui.innerUpButton, self.ui.innerDownButton),
        ):
            rows = {widget.row(item) for item in widget.selectedItems()}
            up.setEnabled(widget.isEnabled() and any(row > 0 and row - 1 not in rows for row in rows))
            down.setEnabled(widget.isEnabled() and any(row + 1 < widget.count() and row + 1 not in rows for row in rows))

    def move_selected(self, widget: QListWidget, direction: int) -> None:
        """Move each selected run one step, keeping its internal order."""
        if not widget.isEnabled() or direction not in (-1, 1):
            return
        selected = {item.data(Qt.UserRole) for item in widget.selectedItems()}
        if not selected:
            return
        current = widget.currentItem()
        self._updating = True
        rows = range(widget.count()) if direction < 0 else range(widget.count() - 1, -1, -1)
        for row in rows:
            neighbor = row + direction
            item = widget.item(row)
            if (
                item.data(Qt.UserRole) in selected
                and 0 <= neighbor < widget.count()
                and widget.item(neighbor).data(Qt.UserRole) not in selected
            ):
                widget.insertItem(neighbor, widget.takeItem(row))
        for row in range(widget.count()):
            item = widget.item(row)
            item.setSelected(item.data(Qt.UserRole) in selected)
        if current is not None:
            widget.setCurrentItem(current, QItemSelectionModel.NoUpdate)
            widget.scrollToItem(current)
        self._updating = False
        if widget is self.ui.innerList:
            self._save_members()
        self._outer_selection_changed()

    def reset_to_table_order(self) -> None:
        self._populate(self.table_order)

    def order(self) -> list[str]:
        self._save_members()
        return [member for key in self._list_keys(self.ui.outerList) for member in self._members[key]]


def create_grouped_order_dialog(
    parent: QWidget | None,
    current_order: list[str],
    table_order: list[str],
    *,
    parents: list[dict],
    item_labels: dict[str, str],
) -> tuple[QDialog, Ui_GroupedOrderDialog, GroupedOrderDialogController]:
    dialog = QDialog(parent)
    ui = Ui_GroupedOrderDialog()
    ui.setupUi(dialog)
    controller = GroupedOrderDialogController(
        dialog, ui, current_order, table_order, parents=parents, item_labels=item_labels,
    )
    dialog.grouped_order_controller = controller
    return dialog, ui, controller


def run_grouped_order_dialog(
    parent: QWidget,
    current_order: list[str],
    table_order: list[str],
    *,
    parents: list[dict],
    item_labels: dict[str, str],
) -> list[str] | None:
    dialog, _ui, controller = create_grouped_order_dialog(
        parent, current_order, table_order, parents=parents, item_labels=item_labels,
    )
    if dialog.exec() != QDialog.Accepted:
        return None
    return controller.order()
