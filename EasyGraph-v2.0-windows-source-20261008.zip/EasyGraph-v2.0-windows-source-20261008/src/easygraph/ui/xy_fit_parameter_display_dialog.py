from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHeaderView,
    QTableWidgetItem,
    QWidget,
)

from ui_xy_fit_parameter_display_dialog import Ui_XYFitParameterDisplayDialog


@dataclass(frozen=True)
class XYFitParameterDisplaySeries:
    series_id: str
    series_name: str
    parameters: tuple[tuple[str, float | None], ...]
    selected_parameter_names: tuple[str, ...] = ()


def _value_text(value: float | None) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return "—"
    return f"{number:.17g}" if math.isfinite(number) else "—"


class XYFitParameterDisplayDialog(QDialog):
    """Choose the fitted values shown in each chart annotation."""

    def __init__(
        self,
        parent: QWidget | None,
        series: Iterable[XYFitParameterDisplaySeries],
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_XYFitParameterDisplayDialog()
        self.ui.setupUi(self)
        self._series = tuple(series)
        self._rows: dict[int, tuple[str, str]] = {}

        header = self.ui.parameterTable.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.Stretch)
        self._populate()

        self.ui.clearAllButton.clicked.connect(
            lambda: self._set_all_checked(False)
        )
        self.ui.restoreDefaultsButton.clicked.connect(
            lambda: self._set_all_checked(True)
        )
        self.ui.parameterTable.itemChanged.connect(
            lambda _item: self.ui.validationLabel.clear()
        )
        self.ui.buttonBox.button(QDialogButtonBox.Ok).clicked.connect(
            self._accept
        )

    def _populate(self) -> None:
        table = self.ui.parameterTable
        table.setRowCount(0)
        for entry in self._series:
            available_names = {name for name, _value in entry.parameters}
            selected_names = (
                set(entry.selected_parameter_names)
                if entry.selected_parameter_names
                else available_names
            )
            for parameter_name, value in entry.parameters:
                row = table.rowCount()
                table.insertRow(row)
                show_item = QTableWidgetItem()
                show_item.setFlags(
                    Qt.ItemIsEnabled
                    | Qt.ItemIsSelectable
                    | Qt.ItemIsUserCheckable
                )
                show_item.setCheckState(
                    Qt.Checked
                    if parameter_name in selected_names
                    else Qt.Unchecked
                )
                show_item.setTextAlignment(Qt.AlignCenter)
                table.setItem(row, 0, show_item)
                table.setItem(row, 1, QTableWidgetItem(entry.series_name))
                table.setItem(row, 2, QTableWidgetItem(parameter_name))
                table.setItem(row, 3, QTableWidgetItem(_value_text(value)))
                self._rows[row] = (entry.series_id, parameter_name)

    def _set_all_checked(self, checked: bool) -> None:
        state = Qt.Checked if checked else Qt.Unchecked
        table = self.ui.parameterTable
        was_blocked = table.blockSignals(True)
        try:
            for row in self._rows:
                table.item(row, 0).setCheckState(state)
        finally:
            table.blockSignals(was_blocked)
        self.ui.validationLabel.clear()

    def selections(self) -> dict[str, list[str]]:
        selected = {entry.series_id: [] for entry in self._series}
        for row, (series_id, parameter_name) in self._rows.items():
            if self.ui.parameterTable.item(row, 0).checkState() == Qt.Checked:
                selected[series_id].append(parameter_name)
        return selected

    def _accept(self) -> None:
        selections = self.selections()
        missing = [
            entry.series_name
            for entry in self._series
            if entry.parameters and not selections.get(entry.series_id)
        ]
        if missing:
            self.ui.validationLabel.setText(
                self.tr(
                    "Select at least one parameter for every fit result. Missing: {series}"
                ).format(series=", ".join(missing))
            )
            return
        self.accept()


__all__ = [
    "XYFitParameterDisplayDialog",
    "XYFitParameterDisplaySeries",
]
