from __future__ import annotations

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QIcon, QPainter, QPalette
from PySide6.QtWidgets import (
    QApplication,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionViewItem,
)

from easygraph.plotting.overlay_renderer import (
    LINE_STYLE_POPUP_PREVIEW_WIDTH,
    LINE_STYLE_POPUP_ROW_HEIGHT,
    draw_line_style_preview,
)


class LineStyleItemDelegate(QStyledItemDelegate):
    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index) -> None:
        style_name = str(index.data(Qt.ItemDataRole.DisplayRole) or "")
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        opt.text = ""
        opt.icon = QIcon()
        widget_style = opt.widget.style() if opt.widget is not None else QApplication.style()
        widget_style.drawControl(QStyle.ControlElement.CE_ItemViewItem, opt, painter, opt.widget)

        selected = bool(opt.state & QStyle.StateFlag.State_Selected)
        color_role = QPalette.ColorRole.HighlightedText if selected else QPalette.ColorRole.Text
        line_color = opt.palette.color(color_role)
        painter.save()
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            preview_left = opt.rect.left() + 12
            preview_right = preview_left + LINE_STYLE_POPUP_PREVIEW_WIDTH
            preview_y = opt.rect.center().y()
            draw_line_style_preview(painter, style_name, line_color, preview_left, preview_right, preview_y)

            text_rect = opt.rect.adjusted(LINE_STYLE_POPUP_PREVIEW_WIDTH + 28, 0, -8, 0)
            painter.setPen(line_color)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, style_name)
        finally:
            painter.restore()

    def sizeHint(self, option: QStyleOptionViewItem, index) -> QSize:
        hint = super().sizeHint(option, index)
        return QSize(max(hint.width(), LINE_STYLE_POPUP_PREVIEW_WIDTH + 150), max(hint.height(), LINE_STYLE_POPUP_ROW_HEIGHT))
