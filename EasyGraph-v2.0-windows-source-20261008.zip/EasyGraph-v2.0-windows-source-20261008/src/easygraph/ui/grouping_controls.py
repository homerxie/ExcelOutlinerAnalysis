"""Groups-table editing operations. Numeric cells keep their existing row offsets."""
from __future__ import annotations

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QFormLayout, QInputDialog, QLabel, QMenu, QMessageBox, QPlainTextEdit, QVBoxLayout,
)

from easygraph.grouping import create_parent, insert_subgroup, normalize_grouping, parent_for_column
from easygraph.table_structure import table_selection
from easygraph.workbook import new_column_id


class SharedGroupsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr('Create parent groups in bulk'))
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.parents = QPlainTextEdit('WT\nKO')
        self.subgroups = QPlainTextEdit('Control\nTreatment')
        form.addRow(self.tr('Parent names (one per line)'), self.parents)
        form.addRow(self.tr('Shared subgroup names (one per line)'), self.subgroups)
        layout.addLayout(form)
        self.error = QLabel()
        layout.addWidget(self.error)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def names(self):
        return ([name.strip() for name in self.parents.toPlainText().splitlines() if name.strip()],
                [name.strip() for name in self.subgroups.toPlainText().splitlines() if name.strip()])

    def accept(self):
        parents, children = self.names()
        if not parents or not children:
            self.error.setText(self.tr('Enter at least one parent and one subgroup.'))
            return
        super().accept()


class GroupDisplayDialog(QDialog):
    def __init__(self, settings, grouping, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr('Grouping settings'))
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.shared = QCheckBox(self.tr('Share matching subgroup names and colors'))
        self.shared.setChecked(grouping.shared_subgroups)
        form.addRow(self.shared)
        self.inner = QDoubleSpinBox()
        self.outer = QDoubleSpinBox()
        for control, value in ((self.inner, settings.group_inner_spacing), (self.outer, settings.group_outer_spacing)):
            control.setRange(0.2, 10)
            control.setSingleStep(0.1)
            control.setDecimals(1)
            control.setValue(value)
        self.outer.setMinimum(self.inner.value())
        self.inner.valueChanged.connect(self.outer.setMinimum)
        form.addRow(self.tr('Within-group spacing'), self.inner)
        form.addRow(self.tr('Between-group spacing'), self.outer)
        self.labels = QComboBox()
        self.labels.addItem(self.tr('Both levels'), 'Both levels')
        self.labels.addItem(self.tr('Subgroup names in legend only'), 'Legend only')
        self.labels.setCurrentIndex(max(0, self.labels.findData(settings.group_label_mode)))
        self.labels.setEnabled(self.shared.isChecked())
        self.shared.toggled.connect(self.labels.setEnabled)
        form.addRow(self.tr('Labels'), self.labels)
        self.colors = QComboBox()
        self.colors.addItem(self.tr('By subgroup'), 'Subgroup')
        self.colors.addItem(self.tr('By parent group'), 'Parent')
        self.colors.setCurrentIndex(max(0, self.colors.findData(settings.group_color_mode)))
        form.addRow(self.tr('Colors'), self.colors)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class GroupingControls(QObject):
    def __init__(self, window):
        super().__init__(window)
        self.window = window
        commands = (
            ('merge', 'Merge parent headers...', self.merge_selected_headers),
            ('unmerge', 'Unmerge parent headers', self.unmerge_selected_headers),
            ('rename', 'Rename parent header...', self.rename_selected_parent),
            ('insert_parent_left', 'Insert parent group left...', lambda: self.insert_selected_parent(False)),
            ('insert_parent_right', 'Insert parent group right...', lambda: self.insert_selected_parent(True)),
            ('insert_subgroup_left', 'Insert subgroup left', lambda: self.insert_selected_subgroup(False)),
            ('insert_subgroup_right', 'Insert subgroup right', lambda: self.insert_selected_subgroup(True)),
            ('batch', 'Create parent groups in bulk...', self.add_shared_groups_dialog),
        )
        self.actions = {}
        for key, title, callback in commands:
            action = QAction(self.tr(title), self)
            action.setObjectName('group_' + key)
            action.triggered.connect(lambda _checked=False, run=callback: run())
            self.actions[key] = action

    @property
    def sheet(self):
        return self.window.workbook.active_sheet

    def selected_columns(self):
        selection = table_selection(self.window.table)
        columns = self.window._current_or_selected_columns(self.window.table, selection)
        user_count = len(self.window.table_group_names())
        return [column for column in columns if 0 <= column < user_count]

    def action(self, key):
        """Shared command instances for the Table tab and every context menu."""
        return self.actions[key]

    def _raw_header_columns(self):
        header = self.window.table.horizontalHeader()
        getter = getattr(header, 'selected_parent_columns', None)
        return list(getter()) if getter is not None else []

    def _header_columns(self):
        return sorted({column for column in self._raw_header_columns()
                       if 0 <= column < len(self.window.table_group_names())})

    def _command_columns(self):
        # A selected capacity header is an explicit target, even though it is
        # not a real group yet. Never fall back to a stale current data cell.
        return self._header_columns() if self._raw_header_columns() else self.selected_columns()

    def _subgroup_columns(self):
        header_columns = self._raw_header_columns()
        if header_columns:
            return sorted(header_columns)
        columns = self._command_columns()
        if columns:
            return columns
        # The final capacity column is not a plotted group yet, but must still
        # offer insertion, including after deleting the last real column.
        table = self.window.table
        physical = self.window._current_or_selected_columns(table)
        valid = [column for column in physical if 0 <= column < table.table_model.columnCount()]
        return valid or ([table.table_model.columnCount() - 1] if table.table_model.columnCount() else [])

    def _selected_parents(self):
        ids = {self.sheet.column_ids[column] for column in self._command_columns()}
        return [parent for parent in self.sheet.grouping.parents if ids.intersection(parent['column_ids'])]

    def selection_summary(self):
        columns = self._command_columns()
        parents = self._selected_parents()
        if len(parents) == 1 and all(
            self.sheet.column_ids[column] in parents[0]['column_ids'] for column in columns
        ):
            return self.tr('Parent: {name} ({count} columns)').format(
                name=parents[0]['name'], count=len(parents[0]['column_ids']))
        if columns:
            return self.tr('Selected {count} columns').format(count=len(columns))
        return self.tr('Select parent headers or columns')

    def update_actions(self):
        groups = not self.window._is_xy_sheet()
        columns = self._command_columns() if groups else []
        parents = self._selected_parents() if groups else []
        for key, action in self.actions.items():
            action.setEnabled(groups)
            action.setVisible(groups)
        for key in ('insert_parent_left', 'insert_parent_right'):
            self.actions[key].setEnabled(groups and bool(columns))
        child_columns = self._subgroup_columns() if groups else []
        can_insert_children = bool(child_columns) and child_columns == list(range(min(child_columns), max(child_columns) + 1))
        if self._raw_header_columns():
            can_insert_children = len(child_columns) == 1
        for key in ('insert_subgroup_left', 'insert_subgroup_right'):
            self.actions[key].setEnabled(groups and can_insert_children)
        self.actions['unmerge'].setEnabled(groups and bool(parents))
        self.actions['rename'].setEnabled(groups and len(parents) == 1)
        self.actions['merge'].setToolTip(self.tr('Select adjacent parent header cells to merge.'))
        self.actions['unmerge'].setToolTip(self.tr('Keep subgroup names and all data.'))
        return self.selection_summary() if groups else ''

    def add_menu(self, menu, context_scope):
        if context_scope == 'rows' or self.window._is_xy_sheet():
            return
        self.update_actions()
        menu.addSeparator()
        if context_scope == 'columns':
            target = menu
        else:
            target = menu.addMenu(self.tr('Parent headers'))
            # Retain the wrapper as well as Qt ownership until menu.exec ends.
            menu._easygraph_submenus = getattr(menu, '_easygraph_submenus', []) + [target]
            menu._easygraph_submenu_actions = getattr(menu, '_easygraph_submenu_actions', []) + [target.menuAction()]
        self._add_parent_actions(target)

    def _add_parent_actions(self, menu):
        for key in ('merge', 'unmerge', 'rename'):
            menu.addAction(self.action(key))
        menu.addSeparator()
        for key in ('insert_parent_left', 'insert_parent_right'):
            menu.addAction(self.action(key))
        menu.addSeparator()
        menu.addAction(self.action('batch'))

    def _merge_columns(self):
        if self._raw_header_columns():
            return self._header_columns()
        # A data-cell rectangle is never an implicit request to alter headers.
        selection = self.window.table.selectionModel()
        return sorted({index.column() for index in selection.selectedColumns()
                       if 0 <= index.column() < len(self.window.table_group_names())})

    def _complete_adjacent_blocks(self, columns):
        if not columns or columns != list(range(min(columns), max(columns) + 1)):
            return False
        ids = {self.sheet.column_ids[column] for column in columns}
        return all(not ids.intersection(parent['column_ids']) or set(parent['column_ids']) <= ids
                   for parent in self.sheet.grouping.parents)

    def _prompt_parent_name(self, title, value=''):
        name, accepted = QInputDialog.getText(self.window, self.tr(title), self.tr('Parent name'), text=value)
        return str(name).strip() if accepted else ''

    def merge_selected_headers(self, name=None):
        if self.window._is_xy_sheet():
            return False
        columns = self._merge_columns()
        if not self._complete_adjacent_blocks(columns):
            QMessageBox.information(self.window, self.tr('Merge parent headers'),
                                    self.tr('Select adjacent parent header cells to merge.'))
            header = self.window.table.horizontalHeader()
            if hasattr(header, 'highlight_parent_band'):
                header.highlight_parent_band()
            return False
        name = self._prompt_parent_name('Merge parent headers') if name is None else str(name).strip()
        if not name:
            return False
        ids = [self.sheet.column_ids[column] for column in columns]
        def mutate():
            create_parent(self.sheet.grouping, ids, name)
            normalize_grouping(self.sheet.grouping, self.sheet.column_ids)
            return True
        return self._mutate(mutate)

    def unmerge_selected_headers(self):
        parent_ids = {parent['id'] for parent in self._selected_parents()}
        if not parent_ids or self.window._is_xy_sheet():
            return False
        return self._remove_parents(parent_ids)

    def _remove_parents(self, parent_ids):
        def mutate():
            grouping = self.sheet.grouping
            grouping.parents = [parent for parent in grouping.parents if parent['id'] not in parent_ids]
            normalize_grouping(grouping, self.sheet.column_ids)
            return True
        return self._mutate(mutate)

    def rename_selected_parent(self, name=None):
        parents = self._selected_parents()
        return self.rename_parent(parents[0]['id'], name) if len(parents) == 1 else False

    def edit_parent_at_column(self, column):
        if self.window._is_xy_sheet() or not 0 <= column < len(self.window.table_group_names()):
            return False
        parent = parent_for_column(self.sheet.grouping, self.sheet.column_ids[column])
        if parent is not None:
            return self.rename_parent(parent['id'])
        self.window.table.horizontalHeader().select_parent_columns([column])
        return self.merge_selected_headers()

    def create_selected_parent(self, name=None):
        columns = self.selected_columns()
        if not columns or max(columns) - min(columns) + 1 != len(columns):
            return False
        ids = [self.sheet.column_ids[index] for index in columns]
        if any(parent_for_column(self.sheet.grouping, key) is not None for key in ids):
            return False
        if name is None:
            name, accepted = QInputDialog.getText(self.window, self.tr('Create parent group'), self.tr('Parent name'))
            if not accepted:
                return False
        if not str(name).strip():
            return False
        def mutate():
            create_parent(self.sheet.grouping, ids, str(name).strip())
            self._link_shared_names()
            return True
        return self._mutate(mutate)

    def _mutate(self, operation):
        changed = self.window._run_model_structure_mutation(self.window.table, operation)
        self.update_actions()
        return changed

    def rename_parent(self, parent_id, name=None):
        parent = next((item for item in self.sheet.grouping.parents if item['id'] == parent_id), None)
        if parent is None:
            return False
        if name is None:
            name, accepted = QInputDialog.getText(self.window, self.tr('Rename parent group'), self.tr('Parent name'), text=parent['name'])
            if not accepted:
                return False
        name = str(name).strip()
        if not name or name == parent['name']:
            return False
        def mutate():
            parent['name'] = name
            return True
        return self._mutate(mutate)

    def remove_parent(self, parent_id):
        if not any(parent['id'] == parent_id for parent in self.sheet.grouping.parents):
            return False
        return self._remove_parents({parent_id})

    def header_menu(self, column, position):
        if not 0 <= column < self.window.table.table_model.columnCount():
            return
        header = self.window.table.horizontalHeader()
        if column not in self._header_columns():
            header.select_parent_columns([column])
        self.update_actions()
        menu = QMenu(self.window)
        menu.addAction(self.window.tr('Copy'), lambda: self.window.copy_table_selection(self.window.table))
        menu.addAction(self.window.tr('Paste'), lambda: self.window.paste_table_selection(self.window.table))
        menu.addSeparator()
        self._add_parent_actions(menu)
        menu.exec(position)

    def parent_menu(self, parent_id, position):
        parent = next((item for item in self.sheet.grouping.parents if item['id'] == parent_id), None)
        if parent is not None:
            self.header_menu(self.sheet.column_ids.index(parent['column_ids'][0]), position)

    def insert_selected_parent(self, after, name=None):
        if self.window._is_xy_sheet():
            return False
        columns = self._command_columns()
        if not columns:
            return False
        anchor = max(columns) if after else min(columns)
        parent = parent_for_column(self.sheet.grouping, self.sheet.column_ids[anchor])
        if parent is not None:
            members = [self.sheet.column_ids.index(key) for key in parent['column_ids']]
            anchor = max(members) if after else min(members)
        insertion = anchor + int(after)
        name = self._prompt_parent_name('Insert parent group') if name is None else str(name).strip()
        if not name:
            return False
        sheet = self.sheet
        model = self.window.table.table_model
        column_id = new_column_id()
        subgroup_name = self.window._next_group_column_names(1)[0]
        def mutate():
            if not model.insertColumns(insertion, 1):
                return False
            sheet.column_ids.insert(insertion, column_id)
            model.set_cell_text(0, insertion, subgroup_name)
            create_parent(sheet.grouping, [column_id], name)
            normalize_grouping(sheet.grouping, sheet.column_ids)
            return True
        changed = self._mutate(mutate)
        if changed:
            self.window.table.setCurrentIndex(model.index(0, insertion))
            self.window.table.horizontalHeader().select_parent_columns([insertion])
            self.update_actions()
        return changed

    def insert_selected_subgroup(self, after):
        if self.window._is_xy_sheet():
            return False
        columns = self._subgroup_columns()
        if not columns or columns != list(range(min(columns), max(columns) + 1)):
            return False
        if self._raw_header_columns() and len(columns) != 1:
            return False
        anchor = max(columns) if after else min(columns)
        insertion = min(anchor + int(after), len(self.window.table_group_names()))
        sheet = self.sheet
        anchor_id = sheet.column_ids[anchor]
        count = len(columns)
        ids = [new_column_id() for _ in columns]
        model = self.window.table.table_model
        names = self.window._next_group_column_names(count)
        def mutate():
            if not model.insertColumns(insertion, count):
                return False
            sheet.column_ids[insertion:insertion] = ids
            previous_id = anchor_id
            for offset, (column_id, name) in enumerate(zip(ids, names)):
                model.set_cell_text(0, insertion + offset, name)
                insert_subgroup(sheet.grouping, previous_id, column_id, after=after)
                if after:
                    previous_id = column_id
            return True
        changed = self._mutate(mutate)
        if changed:
            self.window.table.setCurrentIndex(model.index(0, insertion))
            header = self.window.table.horizontalHeader()
            if hasattr(header, 'clear_parent_selection'):
                header.clear_parent_selection()
            self.update_actions()
        return changed

    def add_shared_groups_dialog(self):
        dialog = SharedGroupsDialog(self.window)
        if dialog.exec() == QDialog.Accepted:
            self.add_shared_groups(*dialog.names())

    def add_shared_groups(self, parent_names, subgroup_names):
        if not parent_names or not subgroup_names:
            return False
        sheet = self.sheet
        model = self.window.table.table_model
        insertion = len(self.window.table_group_names())
        count = len(parent_names) * len(subgroup_names)
        ids = [new_column_id() for _ in range(count)]
        category_ids = [new_column_id() for _ in subgroup_names]
        replace_defaults = not sheet.grouping.parents and all(
            model.cell_text(0, column).startswith('Group ')
            and model.cell_text(0, column).removeprefix('Group ').isdigit()
            and all(not model.cell_text(row, column).strip() for row in range(1, model.rowCount()))
            for column in range(insertion)
        )
        def mutate():
            nonlocal insertion
            if replace_defaults and insertion:
                model.removeColumns(0, insertion)
                del sheet.column_ids[:insertion]
                insertion = 0
            if not model.insertColumns(insertion, count):
                return False
            sheet.column_ids[insertion:insertion] = ids
            sheet.grouping.shared_subgroups = True
            for parent_index, parent_name in enumerate(parent_names):
                child_ids = ids[parent_index * len(subgroup_names):(parent_index + 1) * len(subgroup_names)]
                create_parent(sheet.grouping, child_ids, parent_name)
                for index, (key, name) in enumerate(zip(child_ids, subgroup_names)):
                    model.set_cell_text(0, insertion + parent_index * len(subgroup_names) + index, name)
                    sheet.grouping.subgroup_ids[key] = category_ids[index]
            return True
        return self._mutate(mutate)

    def _link_shared_names(self):
        if not self.sheet.grouping.shared_subgroups:
            return
        names = self.window._table_controller.group_names()
        category_by_name = {}
        for index, key in enumerate(self.sheet.column_ids):
            if index >= len(names) or parent_for_column(self.sheet.grouping, key) is None:
                continue
            category = category_by_name.setdefault(names[index], self.sheet.grouping.subgroup_ids.get(key, new_column_id()))
            self.sheet.grouping.subgroup_ids[key] = category

    def edit_display(self):
        settings = self.window.settings
        dialog = GroupDisplayDialog(settings, self.sheet.grouping, self.window)
        if dialog.exec() != QDialog.Accepted:
            return
        def mutate():
            was_shared = self.sheet.grouping.shared_subgroups
            self.sheet.grouping.shared_subgroups = dialog.shared.isChecked()
            if dialog.shared.isChecked() and not was_shared:
                self._link_shared_names()
            settings.group_inner_spacing = dialog.inner.value()
            settings.group_outer_spacing = dialog.outer.value()
            settings.group_label_mode = dialog.labels.currentData() if dialog.shared.isChecked() else 'Both levels'
            settings.group_color_mode = dialog.colors.currentData()
            if settings.group_label_mode == 'Legend only':
                settings.group_color_mode = 'Subgroup'
                settings.show_legend = True
                was_blocked = self.window.show_legend.blockSignals(True)
                try:
                    self.window.show_legend.setChecked(True)
                finally:
                    self.window.show_legend.blockSignals(was_blocked)
            return True
        self._mutate(mutate)

    def linked_columns(self, column):
        grouping = self.sheet.grouping
        if not grouping.shared_subgroups or column >= len(self.sheet.column_ids):
            return [column]
        category = grouping.subgroup_ids.get(self.sheet.column_ids[column])
        if not category:
            return [column]
        return [index for index, key in enumerate(self.sheet.column_ids) if grouping.subgroup_ids.get(key) == category]
