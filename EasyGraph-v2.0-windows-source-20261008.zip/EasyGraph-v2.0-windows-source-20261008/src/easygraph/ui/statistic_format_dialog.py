from __future__ import annotations

from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QHeaderView,
    QLabel,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from easygraph.statistic_formats import (
    MAX_STATISTIC_DECIMALS,
    STATISTIC_NAMES,
    format_statistic_value,
    normalize_statistic_formats,
)


class StatisticFormatDialog(QDialog):
    """Edit per-statistic display overrides without touching source values."""

    def __init__(
        self,
        formats: dict[str, dict],
        parent=None,
        *,
        analysis: bool = False,
        default_decimals: int = 2,
        default_scientific: bool = False,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(self.tr("Statistic Number Formats"))
        self.setMinimumSize(680, 520)
        self.resize(760, 520)
        self.default_decimals = default_decimals
        self.default_scientific = default_scientific
        layout = QVBoxLayout(self)
        self.description = QLabel(
            self.tr("Applies to this sheet's analysis results and copied statistics.")
            if analysis else
            self.tr("Applies to this sheet's statistic labels and in-chart statistics table."),
            self,
        )
        self.description.setWordWrap(True)
        layout.addWidget(self.description)
        self.defaults_label = QLabel(
            self.tr("Unchecked rows use the default: {decimals} decimal places, {notation}.").format(
                decimals=default_decimals,
                notation=self.tr("scientific notation") if default_scientific else self.tr("decimal notation"),
            ),
            self,
        )
        self.defaults_label.setWordWrap(True)
        layout.addWidget(self.defaults_label)

        self.table = QTableWidget(len(STATISTIC_NAMES), 6, self)
        self.table.setHorizontalHeaderLabels([
            self.tr("Statistic"), self.tr("Override"), self.tr("Decimals"),
            self.tr("Notation"), self.tr("Trim zeros"), self.tr("Preview"),
        ])
        self.table.verticalHeader().hide()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setDefaultSectionSize(34)
        layout.addWidget(self.table, 1)
        self.controls: dict[str, tuple] = {}
        normalized = normalize_statistic_formats(formats)
        for row, name in enumerate(STATISTIC_NAMES):
            self.table.setItem(row, 0, QTableWidgetItem(name))
            override = QCheckBox(self.table)
            override.setAccessibleName(self.tr("Override {statistic} format").format(statistic=name))
            override.setChecked(name in normalized)
            options = normalized.get(name, {})
            decimals = QSpinBox(self.table)
            decimals.setRange(0, MAX_STATISTIC_DECIMALS)
            decimals.setValue(options.get("decimals", default_decimals))
            notation = QComboBox(self.table)
            notation.addItem(self.tr("Decimal"), False)
            notation.addItem(self.tr("Scientific"), True)
            notation.setCurrentIndex(int(options.get("scientific", default_scientific)))
            trim = QCheckBox(self.table)
            trim.setAccessibleName(self.tr("Trim trailing zeros for {statistic}").format(statistic=name))
            trim.setChecked(options.get("trim_zeros", False))
            for column, control in enumerate((override, decimals, notation, trim), start=1):
                self.table.setCellWidget(row, column, control)
            preview = QTableWidgetItem()
            self.table.setItem(row, 5, preview)
            self.controls[name] = (override, decimals, notation, trim, preview)
            override.toggled.connect(self._update_previews)
            decimals.valueChanged.connect(self._update_previews)
            notation.currentIndexChanged.connect(self._update_previews)
            trim.toggled.connect(self._update_previews)

        note = QLabel(self.tr("Preview value: 1234.5. Sample size is always displayed as an integer."), self)
        note.setWordWrap(True)
        layout.addWidget(note)
        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
            | QDialogButtonBox.StandardButton.RestoreDefaults,
            self,
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self.button_box.button(QDialogButtonBox.StandardButton.Ok).setText(self.tr("OK"))
        self.button_box.button(QDialogButtonBox.StandardButton.Cancel).setText(self.tr("Cancel"))
        self.button_box.button(QDialogButtonBox.StandardButton.RestoreDefaults).setText(self.tr("Restore Defaults"))
        self.button_box.button(QDialogButtonBox.StandardButton.RestoreDefaults).clicked.connect(self.restore_defaults)
        layout.addWidget(self.button_box)
        self._update_previews()

    def formats(self) -> dict[str, dict]:
        return {
            name: {
                "decimals": decimals.value(),
                "scientific": notation.currentData(),
                "trim_zeros": trim.isChecked(),
            }
            for name, (override, decimals, notation, trim, _preview) in self.controls.items()
            if override.isChecked()
        }

    def _update_previews(self, *_args) -> None:
        formats = self.formats()
        for name, (override, decimals, notation, trim, preview) in self.controls.items():
            enabled = override.isChecked()
            for control in (decimals, notation, trim):
                control.setEnabled(enabled)
            preview.setText(format_statistic_value(
                1234.5, name, formats,
                default_decimals=self.default_decimals,
                default_scientific=self.default_scientific,
            ))

    def restore_defaults(self) -> None:
        for override, decimals, notation, trim, _preview in self.controls.values():
            override.setChecked(False)
            decimals.setValue(self.default_decimals)
            notation.setCurrentIndex(int(self.default_scientific))
            trim.setChecked(False)
