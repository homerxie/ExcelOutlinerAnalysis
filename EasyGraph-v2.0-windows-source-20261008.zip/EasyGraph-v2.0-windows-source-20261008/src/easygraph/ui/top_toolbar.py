"""Compact, themed icons for the Chart and Table tool pages."""
from __future__ import annotations

from PySide6.QtCore import QCoreApplication, QSize, Qt, QT_TRANSLATE_NOOP
from PySide6.QtGui import QIcon, QKeySequence

from easygraph.app_preferences import stored_theme_preference
from easygraph.ui.toolbar_icons import toolbar_icon


BUTTON_ICONS = {
    "copyImageButton": "lucide:images",
    "copyStatisticsButton": "table",
    "groupFilterButton": "filter",
    "increaseAllFontsButton": "lucide:a-arrow-up",
    "decreaseAllFontsButton": "lucide:a-arrow-down",
    "loadTemplateButton": "folder-open",
    "saveTemplateButton": "device-floppy",
    "tableCopyButton": "copy",
    "tableCutButton": "cut",
    "tablePasteButton": "clipboard",
    "tableClearButton": "eraser",
    "tableUndoButton": "arrow-back-up",
    "tableRedoButton": "arrow-forward-up",
    "tableInsertRowAboveButton": "row-insert-top",
    "tableInsertRowBelowButton": "row-insert-bottom",
    "tableInsertColumnLeftButton": "column-insert-left",
    "tableInsertColumnRightButton": "column-insert-right",
    "tableDeleteRowsButton": "row-remove",
    "tableDeleteColumnsButton": "column-remove",
}
LABELED_BUTTONS = {"copyImageButton", "copyStatisticsButton", "groupFilterButton"}

# QAction.iconText supplies the short toolbar label while menus retain the
# full action text. Directional group operations also retain a label to
# distinguish them from the adjacent ordinary column operations.
PARENT_BUTTONS = (
    ("tableMergeParentButton", "merge", "lucide:table-cells-merge", QT_TRANSLATE_NOOP("TopToolbar", "Merge")),
    ("tableUnmergeParentButton", "unmerge", "lucide:table", QT_TRANSLATE_NOOP("TopToolbar", "Unmerge")),
    ("tableRenameParentButton", "rename", "pencil", QT_TRANSLATE_NOOP("TopToolbar", "Rename")),
    ("tableInsertParentLeftButton", "insert_parent_left", "column-insert-left", QT_TRANSLATE_NOOP("TopToolbar", "Insert left")),
    ("tableInsertParentRightButton", "insert_parent_right", "column-insert-right", QT_TRANSLATE_NOOP("TopToolbar", "Insert right")),
    ("tableBatchParentsButton", "batch", "table-plus", QT_TRANSLATE_NOOP("TopToolbar", "Create groups…")),
)


def _set_label_icon(label, control, name: str, hint: str, color: str, disabled: str) -> None:
    scale = label.devicePixelRatioF()
    enabled = control.isEnabled()
    key = f"{name}:{color}:{disabled}:{scale}:{enabled}"
    if label.property("toolbarIconKey") != key:
        mode = QIcon.Normal if enabled else QIcon.Disabled
        label.setPixmap(toolbar_icon(name, color, disabled).pixmap(QSize(20, 20), scale, mode))
        label.setProperty("toolbarIconKey", key)
    label.setAlignment(Qt.AlignCenter)
    label.setFixedHeight(26)
    label.setBuddy(control)
    label.setAccessibleName(hint)
    label.setToolTip(hint)


def refresh_chart_toolbar_icons(window, theme: str | None = None) -> None:
    """Follow chart changes, including settings loaded with signals blocked."""
    dark = (theme or stored_theme_preference()) == "dark"
    color, disabled = ("#DCE5EF", "#67717E") if dark else ("#334155", "#9CA5B0")
    order_icon = "layout-arrow-down" if window.chart_type.currentText() == "Ridge" else "layout-arrow-right"
    for label, control, name, hint in (
        (window.ui.toolbarChartTypeLabel, window.chart_type, "lucide:chart-candlestick", window.tr("Type")),
        (window.ui.toolbarPaletteLabel, window.preset, "palette", window.tr("Palette")),
        (window.ui.toolbarOrderLabel, window.group_order, f"lucide:{order_icon}", window.tr("Order")),
        (window.ui.toolbarTemplateIconLabel, window.template_combo, "lucide:broom-sparkles", window.ui.templateToolbarLabel.text()),
    ):
        _set_label_icon(label, control, name, hint, color, disabled)


def configure_top_toolbar(window, theme: str | None = None) -> None:
    """Apply presentation only; existing actions keep their command targets."""
    dark = (theme or stored_theme_preference()) == "dark"
    color, disabled, border, hover, pressed, focus = (
        ("#DCE5EF", "#67717E", "#3F4042", "#1E2B3C", "#2E465E", "#78B7F0") if dark else
        ("#334155", "#9CA5B0", "#DADCE0", "#E2EAFB", "#B5CAF4", "#3185CA")
    )
    window.ui.topToolsTabs.setStyleSheet(f"""
        QToolButton {{
            color: {color};
            background: transparent;
            border: 1px solid {border};
            border-radius: 6px;
            padding: 2px 5px;
        }}
        QToolButton:disabled {{ color: {disabled}; }}
        QToolButton:hover:enabled {{ background: {hover}; }}
        QToolButton:pressed:enabled {{ background: {pressed}; }}
        QToolButton:focus {{ border-color: {focus}; }}
    """)
    for name, icon_name, spin, hint in (
        ("toolbarWidthLabel", "arrows-horizontal", window.width, window.tr("Width (cm)")),
        ("toolbarHeightLabel", "arrows-vertical", window.height, window.tr("Height (cm)")),
    ):
        _set_label_icon(getattr(window.ui, name), spin, icon_name, hint, color, disabled)
        spin.setAccessibleName(hint)
        spin.setToolTip(hint)
    refresh_chart_toolbar_icons(window, theme)
    window.ui.editGroupColorsButton.setToolTip(window.tr("Edit Group Colors"))
    window.ui.editGroupColorsButton.setAccessibleName(window.tr("Edit Group Colors"))
    shortcuts = {
        "tableCopyButton": QKeySequence.Copy,
        "tableCutButton": QKeySequence.Cut,
        "tablePasteButton": QKeySequence.Paste,
        "tableUndoButton": QKeySequence.Undo,
        "tableRedoButton": QKeySequence.Redo,
    }
    for name, icon_name in BUTTON_ICONS.items():
        button = getattr(window.ui, name)
        button.setIcon(toolbar_icon(icon_name, color, disabled))
        button.setIconSize(QSize(20, 20))
        if name in LABELED_BUTTONS:
            button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            button.setFixedHeight(26)
            window.ui.topToolbarLayout.setAlignment(button, Qt.AlignLeft)
        else:
            button.setToolButtonStyle(Qt.ToolButtonIconOnly)
            button.setFixedSize(36, 26)
        label = button.text()
        if name == "loadTemplateButton":
            label = window.tr("Load Style Template")
        elif name == "saveTemplateButton":
            label = window.tr("Save Style Template")
        button.setAccessibleName(label)
        if name in shortcuts:
            key = QKeySequence(shortcuts[name]).toString(QKeySequence.NativeText)
            button.setToolTip(f"{label} ({key})")
        else:
            button.setToolTip(label)
    for name, key, icon_name, label in PARENT_BUTTONS:
        action = window.grouping_controls.action(key)
        action.setIcon(toolbar_icon(icon_name, color, disabled))
        action.setIconText(QCoreApplication.translate("TopToolbar", label))
        button = getattr(window.ui, name)
        button.setIconSize(QSize(20, 20))
        button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        button.setFixedHeight(26)
    window.table_tools.update_state()
