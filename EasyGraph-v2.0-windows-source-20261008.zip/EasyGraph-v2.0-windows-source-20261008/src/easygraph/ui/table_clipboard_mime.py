"""Publish table clipboard data with MIME ownership safe for Qt shutdown."""
from __future__ import annotations

from PySide6.QtWidgets import QApplication, QTextEdit


def set_table_clipboard_mime(text: str, html: str) -> None:
    """Keep exact Office HTML and TSV in a C++-allocated MIME object.

    A Python-created QMimeData left in the clipboard can invoke its Shiboken
    wrapper during Qt teardown, after Python has already finalized. An empty
    QTextEdit provides a native MIME object without copying through the system
    clipboard or reserializing our merged-table HTML. The editor must stay
    empty: selected text introduces lazy document formats that replace the
    explicit HTML and TSV on first retrieval.
    """
    editor = QTextEdit()
    mime = editor.createMimeDataFromSelection()
    mime.setText(text)
    mime.setHtml(html)
    QApplication.clipboard().setMimeData(mime)
