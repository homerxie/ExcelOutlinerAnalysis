from __future__ import annotations

from copy import deepcopy

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QHeaderView,
    QInputDialog,
    QLineEdit,
    QMessageBox,
    QTableWidgetItem,
    QWidget,
)

from easygraph.xy_data import prepare_xy_data
from easygraph.xy_series import (
    XYSeriesSpec,
    XYSettings,
    adjacent_xy_series,
    new_series_id,
    remove_xy_series,
    resolved_x_column_id,
    shared_x_series,
    xy_mapping_mode,
)
from ui_xy_series_dialog import Ui_XYSeriesDialog


VISIBLE_COLUMN = 0
NAME_COLUMN = 1
X_COLUMN = 2
Y_COLUMN = 3
COUNT_COLUMN = 4
POINTS_COLUMN = 5
LINE_COLUMN = 6

XY_MAPPING_SHARED = "shared"
XY_MAPPING_ADJACENT = "adjacent"
XY_MAPPING_CUSTOM = "custom"


def choose_xy_mapping_mode(parent: QWidget) -> str | None:
    choices = [
        parent.tr("Shared X — first column is X, remaining columns are Y"),
        parent.tr("Adjacent XY — pair columns as XY, XY, …"),
        parent.tr("Custom — open Series Setup"),
    ]
    selected, accepted = QInputDialog.getItem(
        parent,
        parent.tr("XY Mapping"),
        parent.tr("How should these columns be mapped?"),
        choices,
        0,
        False,
    )
    if not accepted:
        return None
    return {
        choices[0]: XY_MAPPING_SHARED,
        choices[1]: XY_MAPPING_ADJACENT,
        choices[2]: XY_MAPPING_CUSTOM,
    }.get(selected)


def _column_labels(column_ids: list[str], column_names: list[object]) -> dict[str, str]:
    names = [str(name) for name in column_names]
    counts = {name: names.count(name) for name in set(names)}
    return {
        column_id: (
            f"{name} · Column {index + 1}"
            if counts[name] > 1
            else name
        )
        for index, (column_id, name) in enumerate(zip(column_ids, names))
    }


class XYSeriesDialogController:
    def __init__(
        self,
        parent: QWidget,
        dataframe: pd.DataFrame,
        column_ids: list[str],
        settings: XYSettings,
    ) -> None:
        self.dialog = QDialog(parent)
        self.ui = Ui_XYSeriesDialog()
        self.ui.setupUi(self.dialog)
        self.dataframe = dataframe.copy(deep=True)
        self.column_ids = list(column_ids)
        self.labels = _column_labels(self.column_ids, list(dataframe.columns))
        self.settings = deepcopy(settings)
        self._building = False
        self._layout_note = ""

        self.ui.defaultXCombo.addItem(parent.tr("None"), None)
        for column_id in self.column_ids:
            self.ui.defaultXCombo.addItem(self.labels[column_id], column_id)
        self._set_combo_data(
            self.ui.defaultXCombo,
            self.settings.default_x_column_id,
        )
        header = self.ui.seriesTable.horizontalHeader()
        header.setSectionResizeMode(VISIBLE_COLUMN, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(NAME_COLUMN, QHeaderView.Stretch)
        header.setSectionResizeMode(X_COLUMN, QHeaderView.Stretch)
        header.setSectionResizeMode(Y_COLUMN, QHeaderView.Stretch)
        header.setSectionResizeMode(COUNT_COLUMN, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(POINTS_COLUMN, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(LINE_COLUMN, QHeaderView.ResizeToContents)

        self.ui.defaultXCombo.currentIndexChanged.connect(self._default_x_changed)
        self.ui.seriesTable.itemChanged.connect(self._row_value_changed)
        self.ui.sharedXButton.clicked.connect(self.use_shared_x)
        self.ui.adjacentXYButton.clicked.connect(self.use_adjacent_xy)
        self.ui.addSeriesButton.clicked.connect(self.add_series)
        self.ui.removeSeriesButton.clicked.connect(self.remove_selected_series)
        self.ui.moveUpButton.clicked.connect(lambda: self.move_selected_series(-1))
        self.ui.moveDownButton.clicked.connect(lambda: self.move_selected_series(1))
        self._rebuild_rows(self.settings.series)

    @staticmethod
    def _set_combo_data(combo: QComboBox, value) -> None:
        for index in range(combo.count()):
            if combo.itemData(index) == value:
                combo.setCurrentIndex(index)
                return

    def _display_combo(self, value: bool | None) -> QComboBox:
        combo = QComboBox(self.ui.seriesTable)
        combo.addItem(self.dialog.tr("Default"), None)
        combo.addItem(self.dialog.tr("Show"), True)
        combo.addItem(self.dialog.tr("Hide"), False)
        self._set_combo_data(combo, value)
        combo.currentIndexChanged.connect(self._row_value_changed)
        return combo

    def _x_combo(self, value: str | None) -> QComboBox:
        combo = QComboBox(self.ui.seriesTable)
        default_id = self.ui.defaultXCombo.currentData()
        default_label = self.labels.get(default_id, self.dialog.tr("None"))
        combo.addItem(
            self.dialog.tr("Use default ({name})").format(name=default_label),
            None,
        )
        for column_id in self.column_ids:
            combo.addItem(self.labels[column_id], column_id)
        self._set_combo_data(combo, value)
        combo.currentIndexChanged.connect(self._row_value_changed)
        return combo

    def _y_combo(self, value: str) -> QComboBox:
        combo = QComboBox(self.ui.seriesTable)
        for column_id in self.column_ids:
            combo.addItem(self.labels[column_id], column_id)
        self._set_combo_data(combo, value)
        combo.currentIndexChanged.connect(self._row_value_changed)
        return combo

    def _append_row(self, series: XYSeriesSpec) -> None:
        table = self.ui.seriesTable
        row = table.rowCount()
        table.insertRow(row)
        visible = QTableWidgetItem()
        visible.setData(Qt.UserRole, series.id)
        visible.setFlags(
            Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsUserCheckable
        )
        visible.setCheckState(Qt.Checked if series.visible else Qt.Unchecked)
        table.setItem(row, VISIBLE_COLUMN, visible)

        name = QLineEdit(series.name, table)
        name.textChanged.connect(self._row_value_changed)
        table.setCellWidget(row, NAME_COLUMN, name)
        table.setCellWidget(row, X_COLUMN, self._x_combo(series.x_column_id))
        table.setCellWidget(row, Y_COLUMN, self._y_combo(series.y_column_id))
        count = QTableWidgetItem("")
        count.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        table.setItem(row, COUNT_COLUMN, count)
        table.setCellWidget(row, POINTS_COLUMN, self._display_combo(series.show_points))
        table.setCellWidget(row, LINE_COLUMN, self._display_combo(series.show_line))

    def _rebuild_rows(self, series: list[XYSeriesSpec]) -> None:
        self._building = True
        try:
            self.ui.seriesTable.setRowCount(0)
            for item in series:
                self._append_row(item)
        finally:
            self._building = False
        self._refresh_status_and_counts()

    def _default_x_changed(self, _index: int) -> None:
        default_id = self.ui.defaultXCombo.currentData()
        default_label = self.labels.get(default_id, self.dialog.tr("None"))
        for row in range(self.ui.seriesTable.rowCount()):
            combo = self.ui.seriesTable.cellWidget(row, X_COLUMN)
            combo.setItemText(
                0,
                self.dialog.tr("Use default ({name})").format(name=default_label),
            )
        self._row_value_changed()

    def _row_value_changed(self, *_args) -> None:
        if self._building:
            return
        self._layout_note = ""
        self._refresh_status_and_counts()

    def _series_from_table(self) -> list[XYSeriesSpec]:
        table = self.ui.seriesTable
        series = []
        for row in range(table.rowCount()):
            visible_item = table.item(row, VISIBLE_COLUMN)
            name_editor = table.cellWidget(row, NAME_COLUMN)
            x_combo = table.cellWidget(row, X_COLUMN)
            y_combo = table.cellWidget(row, Y_COLUMN)
            points_combo = table.cellWidget(row, POINTS_COLUMN)
            line_combo = table.cellWidget(row, LINE_COLUMN)
            name = name_editor.text().strip() or self.labels.get(
                y_combo.currentData(),
                self.dialog.tr("Series {number}").format(number=row + 1),
            )
            series.append(
                XYSeriesSpec(
                    id=str(visible_item.data(Qt.UserRole)),
                    name=name,
                    x_column_id=x_combo.currentData(),
                    y_column_id=str(y_combo.currentData()),
                    visible=visible_item.checkState() == Qt.Checked,
                    show_points=points_combo.currentData(),
                    show_line=line_combo.currentData(),
                    color=self._existing_series_value(
                        visible_item.data(Qt.UserRole), "color"
                    ),
                    marker=self._existing_series_value(
                        visible_item.data(Qt.UserRole), "marker"
                    ),
                    line_style=self._existing_series_value(
                        visible_item.data(Qt.UserRole), "line_style"
                    ),
                    point_size=self._existing_series_value(
                        visible_item.data(Qt.UserRole), "point_size"
                    ),
                    point_alpha=self._existing_series_value(
                        visible_item.data(Qt.UserRole), "point_alpha"
                    ),
                    line_width=self._existing_series_value(
                        visible_item.data(Qt.UserRole), "line_width"
                    ),
                )
            )
        return series

    def _existing_series_value(self, series_id: object, field_name: str):
        for series in self.settings.series:
            if series.id == str(series_id):
                return getattr(series, field_name)
        return None

    def result(self) -> XYSettings:
        result = deepcopy(self.settings)
        result.default_x_column_id = self.ui.defaultXCombo.currentData()
        updated_series = self._series_from_table()
        updated_series_ids = {series.id for series in updated_series}
        removed_series_ids = {
            series.id
            for series in result.series
            if series.id not in updated_series_ids
        }
        remove_xy_series(result, removed_series_ids)
        result.series = updated_series
        result.__post_init__()
        for series in result.series:
            if resolved_x_column_id(result, series) is None:
                raise ValueError(
                    self.dialog.tr("Every series must have an X column.")
                )
        return result

    def _refresh_status_and_counts(self) -> None:
        try:
            result = self.result()
            prepared = prepare_xy_data(self.dataframe, self.column_ids, result)
            counts = {
                series.id: f"{series.valid_count} · {series.skipped_count} skipped"
                for series in prepared.series
            }
            for row in range(self.ui.seriesTable.rowCount()):
                series_id = str(
                    self.ui.seriesTable.item(row, VISIBLE_COLUMN).data(Qt.UserRole)
                )
                self.ui.seriesTable.item(row, COUNT_COLUMN).setText(
                    counts.get(series_id, self.dialog.tr("Invalid mapping"))
                )
            status = xy_mapping_mode(result).capitalize()
            text = self.dialog.tr("{count} series · {mode}").format(
                count=len(result.series),
                mode=status,
            )
            if self._layout_note:
                text += f" · {self._layout_note}"
            self.ui.mappingStatusLabel.setText(text)
        except ValueError as error:
            self.ui.mappingStatusLabel.setText(str(error))

    def use_shared_x(self) -> None:
        x_column_id = self.ui.defaultXCombo.currentData()
        if x_column_id is None and self.column_ids:
            x_column_id = self.column_ids[0]
        generated = shared_x_series(
            self.column_ids,
            list(self.dataframe.columns),
            x_column_id=x_column_id,
        )
        remove_xy_series(
            self.settings,
            {series.id for series in self.settings.series},
        )
        self.settings.default_x_column_id = generated.default_x_column_id
        self.settings.series = generated.series
        self.settings.shared_tables = generated.shared_tables
        self.settings.paired_series_ids = generated.paired_series_ids
        self.settings.active_shared_table_id = generated.active_shared_table_id
        self._set_combo_data(
            self.ui.defaultXCombo,
            generated.default_x_column_id,
        )
        self._layout_note = ""
        self._rebuild_rows(generated.series)

    def use_adjacent_xy(self) -> None:
        generated = adjacent_xy_series(
            self.column_ids,
            list(self.dataframe.columns),
        )
        remove_xy_series(
            self.settings,
            {series.id for series in self.settings.series},
        )
        self.settings.default_x_column_id = None
        self.settings.series = generated.settings.series
        self.settings.shared_tables = generated.settings.shared_tables
        self.settings.paired_series_ids = generated.settings.paired_series_ids
        self.settings.active_shared_table_id = (
            generated.settings.active_shared_table_id
        )
        self._set_combo_data(self.ui.defaultXCombo, None)
        self._layout_note = (
            self.dialog.tr("{count} unused column").format(
                count=len(generated.unused_column_ids)
            )
            if generated.unused_column_ids
            else ""
        )
        self._rebuild_rows(generated.settings.series)

    def add_series(self) -> None:
        if not self.column_ids:
            return
        default_x = self.ui.defaultXCombo.currentData()
        y_candidates = [
            column_id for column_id in self.column_ids if column_id != default_x
        ] or self.column_ids
        y_column_id = y_candidates[0]
        series = self._series_from_table()
        series.append(
            XYSeriesSpec(
                id=new_series_id(),
                name=self.labels[y_column_id],
                x_column_id=None if default_x is not None else self.column_ids[0],
                y_column_id=y_column_id,
            )
        )
        self._rebuild_rows(series)
        self.ui.seriesTable.selectRow(len(series) - 1)

    def remove_selected_series(self) -> None:
        row = self.ui.seriesTable.currentRow()
        if row < 0:
            return
        series = self._series_from_table()
        series.pop(row)
        self._rebuild_rows(series)
        if series:
            self.ui.seriesTable.selectRow(min(row, len(series) - 1))

    def move_selected_series(self, offset: int) -> None:
        row = self.ui.seriesTable.currentRow()
        destination = row + int(offset)
        series = self._series_from_table()
        if not 0 <= row < len(series) or not 0 <= destination < len(series):
            return
        series[row], series[destination] = series[destination], series[row]
        self._rebuild_rows(series)
        self.ui.seriesTable.selectRow(destination)


def create_xy_series_dialog(
    parent: QWidget,
    dataframe: pd.DataFrame,
    column_ids: list[str],
    settings: XYSettings,
) -> XYSeriesDialogController:
    return XYSeriesDialogController(
        parent,
        dataframe,
        column_ids,
        settings,
    )


def run_xy_series_dialog(
    parent: QWidget,
    dataframe: pd.DataFrame,
    column_ids: list[str],
    settings: XYSettings,
) -> XYSettings | None:
    controller = create_xy_series_dialog(
        parent,
        dataframe,
        column_ids,
        settings,
    )
    while controller.dialog.exec() == QDialog.Accepted:
        try:
            return controller.result()
        except ValueError as error:
            QMessageBox.warning(
                controller.dialog,
                controller.dialog.tr("Invalid series setup"),
                str(error),
            )
    return None


__all__ = [
    "XY_MAPPING_ADJACENT",
    "XY_MAPPING_CUSTOM",
    "XY_MAPPING_SHARED",
    "XYSeriesDialogController",
    "choose_xy_mapping_mode",
    "create_xy_series_dialog",
    "run_xy_series_dialog",
]
