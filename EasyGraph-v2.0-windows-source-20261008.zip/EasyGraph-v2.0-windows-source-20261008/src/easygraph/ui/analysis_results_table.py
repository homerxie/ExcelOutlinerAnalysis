from __future__ import annotations

from PySide6.QtCore import (
    QAbstractTableModel, QEvent, QItemSelection, QItemSelectionModel, QModelIndex,
    Qt, Signal,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDialogButtonBox,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QMenu,
    QPushButton,
    QTableView,
    QToolButton,
    QVBoxLayout,
    QWidget,
    QWidgetAction,
)

from easygraph.analysis_results import AnalysisTableResult
from easygraph.clipboard_table import CellMerge, ClipboardTable, clipboard_table_to_tsv
from easygraph.ui.group_header import GroupHeaderView

__all__ = [
    "AnalysisResultsTable",
    "AnalysisResultsTableModel",
]


class AnalysisResultsTableModel(QAbstractTableModel):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._result = AnalysisTableResult(
            key="empty",
            title="",
            columns=(),
            row_labels=(),
            values=(),
        )

    @property
    def result(self) -> AnalysisTableResult:
        return self._result

    def set_result(self, result: AnalysisTableResult) -> None:
        self.beginResetModel()
        self._result = result
        self.endResetModel()

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._result.values)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._result.columns)

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):
        if not index.isValid():
            return None
        if role in (Qt.DisplayRole, Qt.EditRole):
            return self._result.values[index.row()][index.column()]
        if role == Qt.TextAlignmentRole:
            return Qt.AlignCenter
        return None

    def headerData(
        self,
        section: int,
        orientation: Qt.Orientation,
        role: int = Qt.DisplayRole,
    ):
        headers = (
            self._result.columns
            if orientation == Qt.Horizontal
            else self._result.row_labels
        )
        if not 0 <= section < len(headers):
            return None
        if role in (Qt.DisplayRole, Qt.ToolTipRole):
            return headers[section]
        if role == Qt.TextAlignmentRole:
            return Qt.AlignCenter
        return None

    def flags(self, index: QModelIndex):
        if not index.isValid():
            return Qt.NoItemFlags
        return Qt.ItemIsEnabled | Qt.ItemIsSelectable


class _StatisticsFilterMenu(QMenu):
    selectionApplied = Signal(tuple)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("analysisResultsFilterMenu")
        self._labels: tuple[str, ...] = ()
        self._committed: tuple[str, ...] = ()
        self.checkboxes: dict[str, QCheckBox] = {}

        panel = QWidget(self)
        panel.setObjectName("analysisResultsFilterPanel")
        panel.setMinimumWidth(230)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 0)
        self.title_label = QLabel(self.tr("Visible statistics"), panel)
        self.count_label = QLabel(panel)
        self.count_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        header_layout.addWidget(self.title_label)
        header_layout.addStretch(1)
        header_layout.addWidget(self.count_label)
        layout.addLayout(header_layout)

        command_layout = QHBoxLayout()
        command_layout.setContentsMargins(0, 0, 0, 0)
        command_layout.setSpacing(4)
        self.select_all_button = QPushButton(self.tr("Select All"), panel)
        self.clear_button = QPushButton(self.tr("Clear"), panel)
        self.invert_button = QPushButton(self.tr("Invert"), panel)
        command_layout.addWidget(self.select_all_button)
        command_layout.addWidget(self.clear_button)
        command_layout.addWidget(self.invert_button)
        layout.addLayout(command_layout)

        self.options_layout = QVBoxLayout()
        self.options_layout.setContentsMargins(2, 0, 2, 0)
        self.options_layout.setSpacing(2)
        layout.addLayout(self.options_layout)

        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel,
            parent=panel,
        )
        self.apply_button = self.button_box.button(
            QDialogButtonBox.StandardButton.Ok
        )
        self.cancel_button = self.button_box.button(
            QDialogButtonBox.StandardButton.Cancel
        )
        layout.addWidget(self.button_box)

        widget_action = QWidgetAction(self)
        widget_action.setDefaultWidget(panel)
        self.addAction(widget_action)

        self.select_all_button.clicked.connect(
            lambda: self._set_all_pending(True)
        )
        self.clear_button.clicked.connect(
            lambda: self._set_all_pending(False)
        )
        self.invert_button.clicked.connect(self._invert_pending)
        self.button_box.accepted.connect(self.apply_selection)
        self.button_box.rejected.connect(self.cancel_selection)
        self.aboutToShow.connect(self.begin_editing)

    def set_options(self, labels: tuple[str, ...]) -> None:
        while self.options_layout.count():
            item = self.options_layout.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        self.checkboxes.clear()
        self._labels = tuple(str(label) for label in labels)
        self._committed = self._labels
        for label in self._labels:
            checkbox = QCheckBox(label, self)
            checkbox.toggled.connect(self._update_pending_state)
            self.options_layout.addWidget(checkbox)
            self.checkboxes[label] = checkbox
        self.begin_editing()

    def selected(self) -> frozenset[str]:
        return frozenset(self._committed)

    def set_selected(self, labels: tuple[str, ...] | list[str]) -> None:
        selected = {str(label) for label in labels}
        ordered = tuple(label for label in self._labels if label in selected)
        self._committed = ordered or self._labels
        self.begin_editing()

    def begin_editing(self) -> None:
        committed = set(self._committed)
        for label, checkbox in self.checkboxes.items():
            blocked = checkbox.blockSignals(True)
            try:
                checkbox.setChecked(label in committed)
            finally:
                checkbox.blockSignals(blocked)
        self._update_pending_state()

    def _pending_selection(self) -> tuple[str, ...]:
        return tuple(
            label
            for label in self._labels
            if self.checkboxes[label].isChecked()
        )

    def _set_all_pending(self, checked: bool) -> None:
        for checkbox in self.checkboxes.values():
            blocked = checkbox.blockSignals(True)
            try:
                checkbox.setChecked(checked)
            finally:
                checkbox.blockSignals(blocked)
        self._update_pending_state()

    def _invert_pending(self) -> None:
        for checkbox in self.checkboxes.values():
            blocked = checkbox.blockSignals(True)
            try:
                checkbox.setChecked(not checkbox.isChecked())
            finally:
                checkbox.blockSignals(blocked)
        self._update_pending_state()

    def _update_pending_state(self, _checked: bool | None = None) -> None:
        selected_count = len(self._pending_selection())
        total_count = len(self._labels)
        self.count_label.setText(f"{selected_count}/{total_count}")
        self.apply_button.setEnabled(selected_count > 0)
        self.select_all_button.setEnabled(selected_count < total_count)
        self.clear_button.setEnabled(selected_count > 0)

    def apply_selection(self) -> None:
        pending = self._pending_selection()
        if not pending:
            return
        changed = pending != self._committed
        self._committed = pending
        self.close()
        if changed:
            self.selectionApplied.emit(pending)

    def cancel_selection(self) -> None:
        self.begin_editing()
        self.close()


class AnalysisResultsTable(QTableView):
    """Read-only table for present and future analysis providers."""

    statisticsVisibilityChanged = Signal(tuple)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._parent_groups: list[tuple[str, list[int]]] = []
        self._selecting_parent_columns = False
        self.results_model = AnalysisResultsTableModel(self)
        self.setModel(self.results_model)
        header = GroupHeaderView(self, parent_band_at_top=True)
        header.set_parent_band_enabled(False)
        self.setHorizontalHeader(header)
        header.parentSelectionChanged.connect(self._select_parent_columns)
        header.parentCellContextMenuRequested.connect(
            lambda _column, position: self.customContextMenuRequested.emit(
                self.viewport().mapFromGlobal(position)
            )
        )
        self.selectionModel().selectionChanged.connect(self._clear_parent_selection)
        self.setAlternatingRowColors(True)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectItems)
        self.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.horizontalHeader().setObjectName("analysisResultsHorizontalHeader")
        self.verticalHeader().setObjectName("analysisResultsVerticalHeader")
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.horizontalHeader().setSectionsClickable(True)
        self.verticalHeader().setSectionsClickable(True)
        self.setCornerButtonEnabled(False)
        self.statistics_filter_menu = _StatisticsFilterMenu(self)
        self.statistics_filter_menu.selectionApplied.connect(
            self._apply_statistics_visibility
        )
        self.statistics_filter_button = QToolButton(self)
        self.statistics_filter_button.setObjectName("analysisResultsFilterButton")
        self.statistics_filter_button.setToolTip(self.tr("Choose visible statistics"))
        self.statistics_filter_button.setText(self.tr("Stats"))
        self.statistics_filter_button.setAutoRaise(True)
        self.statistics_filter_button.setPopupMode(
            QToolButton.ToolButtonPopupMode.MenuButtonPopup
        )
        self.statistics_filter_button.setMenu(self.statistics_filter_menu)
        self.statistics_filter_button.clicked.connect(self.selectAll)
        self._sync_statistics_filter_button_font()
        self.horizontalHeader().geometriesChanged.connect(
            self.update_statistics_filter_geometry
        )
        self.verticalHeader().geometriesChanged.connect(
            self.update_statistics_filter_geometry
        )

    def set_statistics_filter_options(self, labels: tuple[str, ...]) -> None:
        self.statistics_filter_menu.set_options(labels)
        self._update_statistics_filter_button_text()

    @property
    def statistics_filter_checkboxes(self) -> dict[str, QCheckBox]:
        return self.statistics_filter_menu.checkboxes

    def visible_statistics(self) -> frozenset[str]:
        return self.statistics_filter_menu.selected()

    def set_visible_statistics(self, labels: tuple[str, ...] | list[str]) -> None:
        self.statistics_filter_menu.set_selected(labels)
        self._update_statistics_filter_button_text()

    def _apply_statistics_visibility(self, ordered: tuple[str, ...]) -> None:
        self._update_statistics_filter_button_text()
        self.statisticsVisibilityChanged.emit(ordered)

    def _update_statistics_filter_button_text(self) -> None:
        self.statistics_filter_button.setText(self.tr("Stats"))

    def _sync_statistics_filter_button_font(self) -> None:
        self.statistics_filter_button.setFont(self.font())

    def update_statistics_filter_geometry(self) -> None:
        vertical_geometry = self.verticalHeader().geometry()
        horizontal_geometry = self.horizontalHeader().geometry()
        self.statistics_filter_button.setGeometry(
            vertical_geometry.x(),
            horizontal_geometry.y(),
            vertical_geometry.width(),
            horizontal_geometry.height(),
        )
        self.statistics_filter_button.raise_()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.update_statistics_filter_geometry()

    def changeEvent(self, event) -> None:
        super().changeEvent(event)
        if event.type() in {
            QEvent.Type.FontChange,
            QEvent.Type.ApplicationFontChange,
        }:
            self._sync_statistics_filter_button_font()

    def set_result(self, result: AnalysisTableResult) -> None:
        self.set_grouping([], [])
        self.results_model.set_result(result)

    def set_grouping(self, parents: list[dict], column_ids: list[str]) -> None:
        """Mirror the source's parent headers without exposing editing actions."""
        column_ids = list(column_ids[:self.model().columnCount()])
        indexes = {key: index for index, key in enumerate(column_ids)}
        self._parent_groups = [
            (
                str(parent["name"]),
                sorted(indexes[key] for key in parent["column_ids"] if key in indexes),
            )
            for parent in parents
        ]
        self._parent_groups = [
            (name, columns) for name, columns in self._parent_groups if columns
        ]
        header = self.horizontalHeader()
        header.set_grouping(parents, column_ids)
        header.set_parent_band_enabled(bool(self._parent_groups))

    def _select_parent_columns(self) -> None:
        columns = self.horizontalHeader().selected_parent_columns()
        row_count = self.model().rowCount()
        if not columns or not row_count:
            return
        selection = QItemSelection(
            self.model().index(0, min(columns)),
            self.model().index(row_count - 1, max(columns)),
        )
        self._selecting_parent_columns = True
        try:
            self.selectionModel().select(
                selection, QItemSelectionModel.SelectionFlag.ClearAndSelect
            )
        finally:
            self._selecting_parent_columns = False

    def _clear_parent_selection(self, _selected, _deselected) -> None:
        if not self._selecting_parent_columns:
            self.horizontalHeader().clear_parent_selection()

    def _clipboard_headers(self, left: int, right: int) -> ClipboardTable:
        columns = self.results_model.result.columns[left:right + 1]
        rows = [["", *columns]]
        merges = []
        if self._parent_groups:
            parent_row = [""] * (len(columns) + 1)
            for name, members in self._parent_groups:
                visible = [column for column in members if left <= column <= right]
                if not visible:
                    continue
                column = visible[0] - left + 1
                parent_row[column] = name
                if len(visible) > 1:
                    merges.append(CellMerge(0, column, colspan=len(visible)))
            rows.insert(0, parent_row)
        return ClipboardTable(
            rows, merges, header_rows=2 if self._parent_groups else None
        )

    def table_clipboard_data(self) -> ClipboardTable | None:
        result = self.results_model.result
        if not result.columns and not result.row_labels:
            return None
        table = self._clipboard_headers(0, len(result.columns) - 1)
        table.rows.extend(
            [label, *values]
            for label, values in zip(result.row_labels, result.values)
        )
        return table

    def selection_clipboard_data(
        self, include_headers: bool = False
    ) -> ClipboardTable | None:
        indexes = self.selectionModel().selectedIndexes()
        if not indexes:
            return None
        top = min(index.row() for index in indexes)
        bottom = max(index.row() for index in indexes)
        left = min(index.column() for index in indexes)
        right = max(index.column() for index in indexes)
        selected = {(index.row(), index.column()) for index in indexes}
        rows = [
            [
                str(self.model().data(self.model().index(row, column), Qt.DisplayRole))
                if (row, column) in selected
                else ""
                for column in range(left, right + 1)
            ]
            for row in range(top, bottom + 1)
        ]
        if not include_headers:
            return ClipboardTable(rows, header_rows=0)
        table = self._clipboard_headers(left, right)
        table.rows.extend(
            [self.results_model.result.row_labels[row], *values]
            for row, values in zip(range(top, bottom + 1), rows)
        )
        return table

    def table_tsv(self) -> str:
        table = self.table_clipboard_data()
        return clipboard_table_to_tsv(table) if table is not None else ""

    def selection_tsv(self) -> str:
        table = self.selection_clipboard_data()
        return clipboard_table_to_tsv(table) if table is not None else ""

    def selection_with_headers_tsv(self) -> str:
        table = self.selection_clipboard_data(include_headers=True)
        return clipboard_table_to_tsv(table) if table is not None else ""
