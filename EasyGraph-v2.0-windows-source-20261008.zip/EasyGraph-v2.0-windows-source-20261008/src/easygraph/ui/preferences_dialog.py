from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSpinBox,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from easygraph.app_preferences import (
    MAX_AUTO_RECOVERY_INTERVAL_SECONDS,
    MIN_AUTO_RECOVERY_INTERVAL_SECONDS,
)
from easygraph.file_association import (
    FileAssociationRefreshStatus,
    refresh_project_file_association,
)


@dataclass(frozen=True)
class PreferencesState:
    language: str
    theme: str
    auto_recovery_interval_seconds: int


class PreferencesDialog(QDialog):
    """Category-based settings window that can grow with future preferences."""

    def __init__(
        self,
        state: PreferencesState,
        parent=None,
        *,
        association_refresher: Callable[[], FileAssociationRefreshStatus] | None = None,
    ) -> None:
        super().__init__(parent)
        self._association_refresher = (
            refresh_project_file_association
            if association_refresher is None
            else association_refresher
        )
        self.setWindowTitle(self.tr("Settings"))
        self.setModal(True)
        self.resize(620, 390)

        root_layout = QVBoxLayout(self)
        content_layout = QHBoxLayout()
        self.category_list = QListWidget(self)
        self.category_list.setFixedWidth(150)
        self.pages = QStackedWidget(self)
        content_layout.addWidget(self.category_list)
        content_layout.addWidget(self.pages, 1)
        root_layout.addLayout(content_layout, 1)

        self.language_combo = QComboBox(self)
        self.language_combo.addItem(self.tr("System"), "system")
        self.language_combo.addItem("English", "en")
        self.language_combo.addItem(self.tr("Simplified Chinese"), "zh_CN")
        self.theme_combo = QComboBox(self)
        self.theme_combo.addItem(self.tr("Light"), "light")
        self.theme_combo.addItem(self.tr("Dark"), "dark")
        general_page = QWidget(self)
        general_layout = QFormLayout(general_page)
        general_layout.setFieldGrowthPolicy(
            QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow
        )
        general_layout.addRow(self.tr("Language"), self.language_combo)
        general_layout.addRow(self.tr("Theme"), self.theme_combo)
        language_note = QLabel(
            self.tr("Language changes take effect after restarting EasyGraph."),
            general_page,
        )
        language_note.setWordWrap(True)
        general_layout.addRow("", language_note)
        self.add_page(self.tr("General"), general_page)

        self.auto_recovery_interval_spin = QSpinBox(self)
        self.auto_recovery_interval_spin.setRange(
            MIN_AUTO_RECOVERY_INTERVAL_SECONDS,
            MAX_AUTO_RECOVERY_INTERVAL_SECONDS,
        )
        self.auto_recovery_interval_spin.setSuffix(self.tr(" seconds"))
        recovery_page = QWidget(self)
        recovery_layout = QFormLayout(recovery_page)
        recovery_layout.setFieldGrowthPolicy(
            QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow
        )
        recovery_layout.addRow(
            self.tr("Write recovery changes every"),
            self.auto_recovery_interval_spin,
        )
        recovery_note = QLabel(
            self.tr(
                "This interval writes only incremental JSONL recovery changes. "
                "Large imports are stored as a complete background checkpoint."
            ),
            recovery_page,
        )
        recovery_note.setWordWrap(True)
        recovery_note.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        recovery_layout.addRow("", recovery_note)
        self.add_page(self.tr("Recovery"), recovery_page)

        association_page = QWidget(self)
        association_layout = QVBoxLayout(association_page)
        association_note = QLabel(
            self.tr(
                "Re-register .eg project files with this copy of EasyGraph and "
                "refresh the system project icon cache."
            ),
            association_page,
        )
        association_note.setWordWrap(True)
        association_layout.addWidget(association_note)
        self.refresh_file_association_button = QPushButton(
            self.tr("Refresh .eg File Association"),
            association_page,
        )
        self.refresh_file_association_button.clicked.connect(
            self.refresh_file_association
        )
        association_layout.addWidget(self.refresh_file_association_button)
        self.file_association_status_label = QLabel("", association_page)
        self.file_association_status_label.setWordWrap(True)
        association_layout.addWidget(self.file_association_status_label)
        association_layout.addStretch(1)
        self.add_page(self.tr("File Association"), association_page)

        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        root_layout.addWidget(self.button_box)
        self.category_list.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.category_list.setCurrentRow(0)
        self._set_combo_data(self.language_combo, state.language)
        self._set_combo_data(self.theme_combo, state.theme)
        self.auto_recovery_interval_spin.setValue(
            state.auto_recovery_interval_seconds
        )

    def add_page(self, label: str, page: QWidget) -> None:
        item = QListWidgetItem(label)
        item.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.category_list.addItem(item)
        self.pages.addWidget(page)

    @staticmethod
    def _set_combo_data(combo: QComboBox, value: str) -> None:
        combo.setCurrentIndex(max(0, combo.findData(value)))

    def preferences(self) -> PreferencesState:
        return PreferencesState(
            language=str(self.language_combo.currentData()),
            theme=str(self.theme_combo.currentData()),
            auto_recovery_interval_seconds=self.auto_recovery_interval_spin.value(),
        )

    def refresh_file_association(self) -> None:
        status = self._association_refresher()
        messages = {
            FileAssociationRefreshStatus.REFRESHED: self.tr(
                "The .eg file association and project icon were refreshed."
            ),
            FileAssociationRefreshStatus.PACKAGED_APP_REQUIRED: self.tr(
                "Run the packaged EasyGraph application to refresh file associations."
            ),
            FileAssociationRefreshStatus.FAILED: self.tr(
                "EasyGraph could not refresh the .eg file association."
            ),
            FileAssociationRefreshStatus.UNSUPPORTED: self.tr(
                "File-association refresh is not supported on this operating system."
            ),
        }
        self.file_association_status_label.setText(messages[status])


__all__ = ["PreferencesDialog", "PreferencesState"]
