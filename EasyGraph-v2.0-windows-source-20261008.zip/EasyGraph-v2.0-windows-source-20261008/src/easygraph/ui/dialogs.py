from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from PySide6.QtCore import QCoreApplication, Qt
from PySide6.QtGui import QColor, QFontMetrics
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLayout,
    QListWidgetItem,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from easygraph.overlay_series import (
    all_overlay_color_keys,
    overlay_color_map_for_keys,
    overlay_palette_slot_for_color_key,
)
from easygraph.additional_guides import MAX_ADDITIONAL_GUIDES
from easygraph.palette import expanded_preset_palette, palette_choices_for_group_count
from easygraph.settings import (
    DEFAULT_OVERLAY_PALETTE,
    LINE_OVERLAY_STYLES,
    PRESETS,
    ChartSettings,
)
from ui_checklist_filter_dialog import Ui_ChecklistFilterDialog
from ui_group_colors_dialog import Ui_GroupColorsDialog
from ui_group_order_dialog import Ui_GroupOrderDialog
from ui_overlay_styles_dialog import Ui_OverlayStylesDialog


@dataclass(frozen=True)
class ChecklistItem:
    key: str
    label: str


@dataclass(frozen=True)
class GroupColorSelection:
    preset: str
    custom_colors: dict[str, str]
    overlay_palette: str
    overlay_colors: dict[str, str]
    guide_palette: str = DEFAULT_OVERLAY_PALETTE
    guide_color_indices: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class OverlayStyleSelection:
    styles: dict[str, str]


def create_checklist_filter_dialog(
    parent: QWidget,
    title: str,
) -> tuple[QDialog, Ui_ChecklistFilterDialog]:
    dialog = QDialog(parent)
    ui = Ui_ChecklistFilterDialog()
    ui.setupUi(dialog)
    dialog.setWindowTitle(parent.tr(title))
    return dialog, ui


def create_group_order_dialog(
    parent: QWidget,
) -> tuple[QDialog, Ui_GroupOrderDialog]:
    dialog = QDialog(parent)
    ui = Ui_GroupOrderDialog()
    ui.setupUi(dialog)
    return dialog, ui


def create_group_colors_dialog(
    parent: QWidget,
) -> tuple[QDialog, Ui_GroupColorsDialog]:
    dialog = QDialog(parent)
    ui = Ui_GroupColorsDialog()
    ui.setupUi(dialog)
    return dialog, ui


def create_overlay_styles_dialog(
    parent: QWidget,
) -> tuple[QDialog, Ui_OverlayStylesDialog]:
    dialog = QDialog(parent)
    ui = Ui_OverlayStylesDialog()
    ui.setupUi(dialog)
    return dialog, ui


def _populate_group_order(ui: Ui_GroupOrderDialog, groups: list[str], item_labels: dict[str, str] | None = None) -> None:
    ui.groupList.clear()
    for group in groups:
        item = QListWidgetItem((item_labels or {}).get(group, str(group)))
        item.setData(Qt.UserRole, group)
        ui.groupList.addItem(item)


def run_group_order_dialog(
    parent: QWidget,
    current_order: list[str],
    table_order: list[str],
    *,
    title: str | None = None,
    hint: str | None = None,
    item_labels: dict[str, str] | None = None,
) -> list[str] | None:
    dialog, ui = create_group_order_dialog(parent)
    if title is not None:
        dialog.setWindowTitle(parent.tr(title))
    if hint is not None:
        ui.hintLabel.setText(parent.tr(hint))
    _populate_group_order(ui, current_order, item_labels)
    ui.tableOrderButton.clicked.connect(lambda: _populate_group_order(ui, table_order, item_labels))
    if dialog.exec() != QDialog.Accepted:
        return None
    return [ui.groupList.item(row).data(Qt.UserRole) or ui.groupList.item(row).text() for row in range(ui.groupList.count())]


def run_checklist_filter_dialog(
    parent: QWidget,
    title: str,
    items: list[ChecklistItem],
    hidden_keys: set[str],
) -> list[str] | None:
    dialog, ui = create_checklist_filter_dialog(parent, title)
    list_widget = ui.itemList
    for item_data in items:
        item = QListWidgetItem(item_data.label)
        item.setData(Qt.UserRole, item_data.key)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
        item.setCheckState(Qt.Unchecked if item_data.key in hidden_keys else Qt.Checked)
        list_widget.addItem(item)
    if dialog.exec() != QDialog.Accepted:
        return None
    return [
        str(list_widget.item(index).data(Qt.UserRole))
        for index in range(list_widget.count())
        if list_widget.item(index).checkState() != Qt.Checked
    ]


def _color_selection(
    preset: str,
    group_colors: dict[str, str],
    overlay_palette: str,
    overlay_colors: dict[str, str],
    valid_group_keys: set[str],
    guide_palette: str = DEFAULT_OVERLAY_PALETTE,
    guide_color_indices: dict[str, int] | None = None,
    valid_guide_keys: set[str] | None = None,
) -> GroupColorSelection:
    valid_guides = set(valid_guide_keys or ())
    return GroupColorSelection(
        preset=preset,
        custom_colors={key: value for key, value in group_colors.items() if key in valid_group_keys},
        overlay_palette=overlay_palette,
        overlay_colors=dict(overlay_colors),
        guide_palette=guide_palette,
        guide_color_indices={
            key: int(value)
            for key, value in (guide_color_indices or {}).items()
            if key in valid_guides
        },
    )


def run_group_colors_dialog(
    parent: QWidget,
    settings: ChartSettings,
    groups: list[str],
    overlay_items: list[tuple[str, str]],
    preview: Callable[[GroupColorSelection], None],
    polish_combo: Callable[[QComboBox], None],
    *,
    title: str | None = None,
    item_labels: dict[str, str] | None = None,
    guide_items: list[tuple[str, str, int, int]] | None = None,
) -> GroupColorSelection | None:
    labels = dict(item_labels or {})
    guides = list(guide_items or ())
    color_items = [
        {
            "key": str(group),
            "label": labels.get(str(group), str(group)),
            "palette_index": index,
            "kind": "group",
        }
        for index, group in enumerate(groups)
    ]
    color_items.extend(
        {
            "key": key,
            "label": parent.tr("Overlay: {name}").format(name=name),
            "palette_index": len(groups) + overlay_palette_slot_for_color_key(settings, key, index),
            "kind": "overlay",
        }
        for index, (key, name) in enumerate(overlay_items)
    )
    color_items.extend(
        {
            "key": str(key),
            "label": str(label),
            "palette_index": int(default_index),
            "kind": "guide",
        }
        for key, label, _color_index, default_index in guides
    )
    selected_preset = settings.preset
    selected_overlay_preset = (
        settings.custom_overlay_palette
        if settings.custom_overlay_palette in PRESETS
        else DEFAULT_OVERLAY_PALETTE
    )
    selected_colors = dict(settings.custom_colors)
    selected_overlay_colors = dict(settings.custom_overlay_colors)
    selected_guide_preset = (
        settings.additional_guide_palette
        if settings.additional_guide_palette in PRESETS
        else DEFAULT_OVERLAY_PALETTE
    )
    selected_guide_indices = {
        str(key): min(
            MAX_ADDITIONAL_GUIDES * 2 - 1,
            max(0, int(color_index)),
        )
        for key, _label, color_index, _default_index in guides
    }
    valid_group_keys = {str(group) for group in groups}
    valid_guide_keys = {str(key) for key, *_rest in guides}
    dialog, ui = create_group_colors_dialog(parent)
    if title is not None:
        dialog.setWindowTitle(parent.tr(title))

    palette_combo = ui.paletteCombo
    palette_combo.addItems(list(PRESETS))
    palette_combo.setCurrentText(selected_preset)
    polish_combo(palette_combo)
    ui.paletteRow.setVisible(bool(groups))
    overlay_palette_combo = None
    ui.overlayPaletteRow.setVisible(bool(overlay_items))
    if overlay_items:
        overlay_palette_combo = ui.overlayPaletteCombo
        overlay_palette_combo.addItems(list(PRESETS))
        overlay_palette_combo.setCurrentText(selected_overlay_preset)
        polish_combo(overlay_palette_combo)
    guide_palette_combo = None
    ui.guidePaletteRow.setVisible(bool(guides))
    if guides:
        guide_palette_combo = ui.guidePaletteCombo
        guide_palette_combo.addItems(list(PRESETS))
        guide_palette_combo.setCurrentText(selected_guide_preset)
        polish_combo(guide_palette_combo)

    palette_cache: dict[str, list[str]] = {}
    overlay_palette_cache: dict[tuple[str, int], list[str]] = {}
    guide_palette_cache: dict[tuple[str, int], list[str]] = {}

    def current_palette() -> list[str]:
        if selected_preset not in palette_cache:
            palette_cache[selected_preset] = palette_choices_for_group_count(selected_preset, len(groups))
        return palette_cache[selected_preset]

    def current_overlay_palette() -> list[str]:
        overlay_slots = [
            int(item["palette_index"]) - len(groups)
            for item in color_items
            if item["kind"] == "overlay"
        ]
        overlay_count = max(overlay_slots, default=0) + 1
        cache_key = (selected_overlay_preset, overlay_count)
        if cache_key not in overlay_palette_cache:
            overlay_palette_cache[cache_key] = palette_choices_for_group_count(
                selected_overlay_preset,
                overlay_count,
            )
        return overlay_palette_cache[cache_key]

    def current_guide_palette() -> list[str]:
        guide_slots = [
            int(item["palette_index"])
            for item in color_items
            if item["kind"] == "guide"
        ]
        guide_slots.extend(selected_guide_indices.values())
        required_count = max(1, max(guide_slots, default=0) + 1)
        cache_key = (selected_guide_preset, max(len(guides), required_count))
        if cache_key not in guide_palette_cache:
            palette = palette_choices_for_group_count(
                selected_guide_preset,
                len(guides),
            )
            if len(palette) < required_count:
                palette = expanded_preset_palette(
                    selected_guide_preset,
                    required_count,
                )
            guide_palette_cache[cache_key] = palette[: MAX_ADDITIONAL_GUIDES * 2]
        return guide_palette_cache[cache_key]

    def palette_for_item(item: dict) -> list[str]:
        if item["kind"] == "overlay":
            return current_overlay_palette()
        if item["kind"] == "guide":
            return current_guide_palette()
        return current_palette()

    def color_for_item(item: dict) -> str:
        key = str(item["key"])
        selected = (
            selected_overlay_colors
            if item["kind"] == "overlay"
            else selected_colors
        )
        if item["kind"] == "guide":
            palette = current_guide_palette()
            palette_index = selected_guide_indices.get(
                key,
                int(item["palette_index"]),
            )
            return palette[palette_index % len(palette)]
        if item["kind"] == "overlay":
            color_map = overlay_color_map_for_keys(
                all_overlay_color_keys(settings),
                settings,
                custom_overlay_colors=selected_overlay_colors,
                overlay_preset=selected_overlay_preset,
            )
            if key in color_map:
                return color_map[key]
            palette = palette_for_item(item)
            palette_index = int(item["palette_index"]) - len(groups)
            return selected.get(key, palette[palette_index % len(palette)])
        palette = palette_for_item(item)
        palette_index = int(item["palette_index"])
        custom_color = selected.get(key)
        if custom_color is not None and QColor(custom_color).isValid():
            return QColor(custom_color).name()
        return palette[palette_index % len(palette)]

    def emit_preview() -> None:
        preview(
            _color_selection(
                selected_preset,
                selected_colors,
                selected_overlay_preset,
                selected_overlay_colors,
                valid_group_keys,
                selected_guide_preset,
                selected_guide_indices,
                valid_guide_keys,
            )
        )

    def style_swatch(button: QPushButton, color: str, selected: bool = False) -> None:
        border = "3px solid #60A5FA" if selected else "1px solid #6B7280"
        foreground = "#000000" if QColor(color).lightnessF() > 0.55 else "#FFFFFF"
        button.setChecked(selected)
        button.setText("✓" if selected else "")
        button.setStyleSheet(
            f"QPushButton {{ background: {color}; color: {foreground}; border: {border}; "
            "border-radius: 4px; padding: 0; min-height: 0; max-height: 24px; font-weight: bold; }"
            "QPushButton:hover { border: 2px solid palette(highlight); }"
            "QPushButton:focus { border: 2px dashed palette(text); }"
        )
        button.ensurePolished()
        button.setFixedSize(24, 24)

    swatches: dict[tuple[str, str], list[tuple[int, QPushButton]]] = {}
    current_swatches: dict[tuple[str, str], QLabel] = {}
    current_values: dict[tuple[str, str], QLabel] = {}

    def refresh_item(item: dict, palette: list[str] | None = None) -> None:
        palette = palette_for_item(item) if palette is None else palette
        key = str(item["key"])
        item_id = (str(item["kind"]), key)
        active_color = color_for_item(item)
        for color_index, button in swatches[item_id]:
            color = palette[color_index % len(palette)]
            style_swatch(button, color, selected=active_color == color)
            description = QCoreApplication.translate(
                "GroupColorsDialog", "{name}: {color}"
            ).format(name=item["label"], color=color.upper())
            button.setToolTip(description)
            button.setAccessibleName(description)
        current_swatches[item_id].setStyleSheet(
            f"background: {active_color}; border: 1px solid #6B7280; border-radius: 4px;"
        )
        description = QCoreApplication.translate(
            "GroupColorsDialog", "{name}: current color {color}"
        ).format(name=item["label"], color=active_color.upper())
        current_swatches[item_id].setToolTip(description)
        current_swatches[item_id].setAccessibleName(description)
        current_values[item_id].setText(active_color.upper())

    def refresh_all_items() -> None:
        for item in color_items:
            refresh_item(item)

    label_width = min(180, max(120, max(
        (dialog.fontMetrics().horizontalAdvance(str(item["label"])) for item in color_items),
        default=120,
    )))
    header_font = dialog.font()
    header_font.setBold(True)
    current_width = max(88, QFontMetrics(header_font).horizontalAdvance(
        QCoreApplication.translate("GroupColorsDialog", "Current color")
    ) + 4)
    palette_width = 8 * 24 + 7 * 5

    def add_separator() -> None:
        separator = QFrame(ui.rowsContainer)
        separator.setProperty("dialogRole", "color-separator")
        separator.setFrameShape(QFrame.HLine)
        separator.setFixedHeight(1)
        separator.setStyleSheet("background: rgba(128, 128, 128, 96); border: none;")
        ui.rowsLayout.addWidget(separator)

    header = QHBoxLayout()
    header.setContentsMargins(12, 8, 12, 8)
    header.setSpacing(16)
    for text, width in (
        (QCoreApplication.translate("GroupColorsDialog", "Item"), label_width),
        (QCoreApplication.translate("GroupColorsDialog", "Current color"), current_width),
        (QCoreApplication.translate("GroupColorsDialog", "Palette colors"), palette_width),
    ):
        caption = QLabel(text)
        caption.setFixedWidth(width)
        caption.setFont(header_font)
        caption.setStyleSheet("padding: 0;")
        header.addWidget(caption)
    header.addStretch()
    ui.rowsLayout.addLayout(header)

    for item in color_items:
        add_separator()
        row_widget = QWidget(ui.rowsContainer)
        row_widget.setProperty("dialogRole", "color-row")
        row_widget.setProperty("colorKey", str(item["key"]))
        row_widget.setProperty("colorKind", str(item["kind"]))
        row = QHBoxLayout(row_widget)
        row.setContentsMargins(12, 12, 12, 12)
        row.setSpacing(16)
        label = QLabel(str(item["label"]))
        label.setTextFormat(Qt.PlainText)
        label.setWordWrap(True)
        label.setFixedWidth(label_width)
        label.setMinimumHeight(24)
        label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        label.setStyleSheet("padding: 0;")
        label.setToolTip(str(item["label"]))
        label.setProperty("dialogRole", "color-label")
        row.addWidget(label, 0, Qt.AlignTop)
        current = QWidget()
        current.setFixedWidth(current_width)
        current_layout = QVBoxLayout(current)
        current_layout.setContentsMargins(0, 0, 0, 0)
        current_layout.setSpacing(5)
        current_swatch = QLabel()
        current_swatch.setProperty("dialogRole", "color-current")
        current_swatch.setFixedSize(34, 24)
        current_layout.addWidget(current_swatch)
        current_value = QLabel()
        current_value.setStyleSheet("padding: 0;")
        current_value.setTextInteractionFlags(Qt.TextSelectableByMouse)
        current_layout.addWidget(current_value)
        key = str(item["key"])
        kind = str(item["kind"])
        item_id = (kind, key)
        current_swatches[item_id] = current_swatch
        current_values[item_id] = current_value
        row.addWidget(current, 0, Qt.AlignTop)
        swatches[item_id] = []
        palette_widget = QWidget()
        palette_widget.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        grid = QGridLayout(palette_widget)
        grid.setSizeConstraint(QLayout.SetFixedSize)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(5)
        grid.setVerticalSpacing(5)
        for column in range(8):
            grid.setColumnMinimumWidth(column, 24)
        for color_index, _color in enumerate(palette_for_item(item)):
            button = QPushButton()
            button.setAutoDefault(False)
            button.setCheckable(True)
            button.setCursor(Qt.PointingHandCursor)
            button.setProperty("dialogRole", "color-swatch")
            button.setProperty("colorKey", key)
            button.setProperty("colorKind", kind)
            button.setProperty("colorIndex", color_index)
            swatches[item_id].append((color_index, button))

            def choose_color(
                _checked=False,
                *,
                item_key=key,
                item_kind=kind,
                selected_index=color_index,
                item_data=item,
            ) -> None:
                if item_kind == "guide":
                    palette = current_guide_palette()
                    selected_guide_indices[item_key] = selected_index
                    refresh_item(item_data, palette)
                    emit_preview()
                    return
                palette = current_overlay_palette() if item_kind == "overlay" else current_palette()
                chosen = palette[selected_index % len(palette)]
                if item_kind == "overlay":
                    selected_overlay_colors[item_key] = chosen
                else:
                    selected_colors[item_key] = chosen
                refresh_item(item_data, palette)
                emit_preview()

            button.clicked.connect(choose_color)
            grid.addWidget(button, color_index // 8, color_index % 8)
        row.addWidget(palette_widget, 0, Qt.AlignTop)
        row.addStretch()
        reset = QPushButton(parent.tr("Reset"))
        reset.setAutoDefault(False)
        reset_description = QCoreApplication.translate(
            "GroupColorsDialog", "Reset {name} to its palette color."
        ).format(name=item["label"])
        reset.setToolTip(reset_description)
        reset.setAccessibleName(reset_description)
        reset.setProperty("dialogRole", "color-reset")
        reset.setProperty("colorKey", key)
        reset.setProperty("colorKind", kind)

        def reset_color(_checked=False, *, item_key=key, item_kind=kind, item_data=item) -> None:
            if item_kind == "guide":
                selected_guide_indices[item_key] = int(item_data["palette_index"])
            elif item_kind == "overlay":
                selected_overlay_colors.pop(item_key, None)
            else:
                selected_colors.pop(item_key, None)
            refresh_item(item_data)
            emit_preview()

        reset.clicked.connect(reset_color)
        row.addWidget(reset, 0, Qt.AlignTop)
        ui.rowsLayout.addWidget(row_widget)
        refresh_item(item)
    if color_items:
        add_separator()
    ui.rowsLayout.addStretch()
    dialog.ensurePolished()
    ui.rowsScroll.setMinimumWidth(max(
        ui.rowsScroll.minimumWidth(),
        ui.rowsContainer.minimumSizeHint().width()
        + ui.rowsScroll.verticalScrollBar().sizeHint().width()
        + 2 * ui.rowsScroll.frameWidth(),
    ))

    def choose_palette(preset: str) -> None:
        nonlocal selected_preset
        if preset not in PRESETS:
            return
        selected_preset = preset
        selected_colors.clear()
        refresh_all_items()
        emit_preview()

    def choose_overlay_palette(preset: str) -> None:
        nonlocal selected_overlay_preset
        if preset not in PRESETS:
            return
        selected_overlay_preset = preset
        selected_overlay_colors.clear()
        refresh_all_items()
        emit_preview()

    def choose_guide_palette(preset: str) -> None:
        nonlocal selected_guide_preset
        if preset not in PRESETS:
            return
        selected_guide_preset = preset
        refresh_all_items()
        emit_preview()

    palette_combo.currentTextChanged.connect(choose_palette)
    if overlay_palette_combo is not None:
        overlay_palette_combo.currentTextChanged.connect(choose_overlay_palette)
    if guide_palette_combo is not None:
        guide_palette_combo.currentTextChanged.connect(choose_guide_palette)
    if dialog.exec() != QDialog.Accepted:
        return None
    return _color_selection(
        selected_preset,
        selected_colors,
        selected_overlay_preset,
        selected_overlay_colors,
        valid_group_keys,
        selected_guide_preset,
        selected_guide_indices,
        valid_guide_keys,
    )


def _overlay_style_selection(
    selected_styles: dict[str, str],
    valid_keys: set[str],
) -> OverlayStyleSelection:
    return OverlayStyleSelection(
        styles={
            key: style
            for key, style in selected_styles.items()
            if key in valid_keys and style in LINE_OVERLAY_STYLES
        }
    )


def run_overlay_styles_dialog(
    parent: QWidget,
    style_items: list[tuple[str, str]],
    base_style: str,
    custom_styles: dict[str, str],
    preview: Callable[[OverlayStyleSelection], None],
    populate_combo: Callable[[QComboBox], None],
    polish_combo: Callable[[QComboBox], None],
) -> OverlayStyleSelection | None:
    selected_styles = dict(custom_styles)
    valid_keys = {key for key, _label in style_items}
    dialog, ui = create_overlay_styles_dialog(parent)

    def emit_preview() -> None:
        preview(_overlay_style_selection(selected_styles, valid_keys))

    for key, name in style_items:
        row = QHBoxLayout()
        label = QLabel(parent.tr("Overlay: {name}").format(name=name))
        label.setMinimumWidth(140)
        row.addWidget(label)

        combo = QComboBox()
        combo.setProperty("dialogRole", "overlay-style-combo")
        combo.setProperty("styleKey", key)
        populate_combo(combo)
        current_style = selected_styles.get(key, base_style)
        combo.setCurrentText(current_style if current_style in LINE_OVERLAY_STYLES else base_style)
        polish_combo(combo)

        def choose_style(style: str, *, item_key=key) -> None:
            if style not in LINE_OVERLAY_STYLES:
                return
            if style == base_style:
                selected_styles.pop(item_key, None)
            else:
                selected_styles[item_key] = style
            emit_preview()

        combo.currentTextChanged.connect(choose_style)
        row.addWidget(combo)

        reset = QPushButton(parent.tr("Reset"))
        reset.setProperty("dialogRole", "overlay-style-reset")
        reset.setProperty("styleKey", key)

        def reset_style(_checked=False, *, item_key=key, item_combo=combo) -> None:
            selected_styles.pop(item_key, None)
            item_combo.blockSignals(True)
            try:
                item_combo.setCurrentText(base_style)
            finally:
                item_combo.blockSignals(False)
            emit_preview()

        reset.clicked.connect(reset_style)
        row.addWidget(reset)
        row.addStretch()
        ui.rowsLayout.addLayout(row)

    ui.rowsLayout.addStretch()
    if dialog.exec() != QDialog.Accepted:
        return None
    return _overlay_style_selection(selected_styles, valid_keys)
