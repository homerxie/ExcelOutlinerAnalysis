"""Top-level EasyGraph window orchestration."""

from __future__ import annotations

from copy import deepcopy
import hashlib
import math
from dataclasses import asdict, replace
from enum import Enum
from pathlib import Path

import numpy as np
import pandas as pd
from PySide6.QtCore import QEvent, QItemSelectionModel, QSize, Qt, QThreadPool, QTimer
from PySide6.QtGui import (
    QAction,
    QActionGroup,
    QBrush,
    QCloseEvent,
    QColor,
    QIcon,
    QKeyEvent,
    QKeySequence,
    QPainter,
    QPalette,
    QPixmap,
    QShortcut,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QAbstractItemDelegate,
    QAbstractSpinBox,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QStyle,
    QStyleOptionSpinBox,
    QTableWidgetItem,
    QToolButton,
    QWidget,
)

from easygraph.additional_guides import (
    ADDITIONAL_GUIDE_TEXT_COLOR_MODES,
    MAX_ADDITIONAL_GUIDES,
    default_additional_guide,
    format_additional_guide_value,
    limit_additional_guide_text,
    normalize_additional_guide,
)
from easygraph.analysis_results import (
    AnalysisTableResult,
    DESCRIPTIVE_STATISTICS,
    descriptive_statistics_result,
)
from easygraph.clipboard_table import (
    ClipboardTable,
    clipboard_table_from_html,
    clipboard_table_to_html,
    clipboard_table_to_tsv,
)
from easygraph.ui.table_clipboard_mime import set_table_clipboard_mime
from easygraph.app_preferences import (
    forget_recent_project,
    normalize_language_code,
    recent_project_clear_label,
    recent_project_empty_label,
    recent_project_menu_item,
    remember_recent_project,
    save_auto_recovery_interval,
    save_language_preference,
    save_recent_project_paths,
    save_theme_preference,
    stored_auto_recovery_interval,
    stored_language_preference,
    stored_recent_project_paths,
    stored_theme_preference,
)
from easygraph.app_theme import (
    COMPACT_SPIN_STYLE,
    COMPACT_SPIN_TEXT_PADDING,
    apply_app_theme,
    office_adjacent_font_size,
)
from easygraph.data import (
    axis_labels_for_chart,
    blank_project_data,
    blank_xy_data,
    hidden_group_names,
    sample_data,
    attach_group_metadata,
    group_keys,
    group_labels,
    migrate_group_settings,
    ordered_group_columns,
)
from easygraph.grouping import GroupingSettings, grouping_from_dict, insert_subgroup, ordered_group_blocks, parent_for_column
from easygraph.ui.grouping_controls import GroupingControls
from easygraph.ui.group_order_dialog import run_grouped_order_dialog
from easygraph.ui.table_tools import TableToolsController
from easygraph.ui.top_toolbar import configure_top_toolbar, refresh_chart_toolbar_icons
from easygraph.overlay_series import overlay_color_items, overlay_style_items
from easygraph.palette import (
    additional_guide_color,
    additional_guide_palette_colors,
)
from easygraph.overlay_table_actions import (
    overlay_table_state_after_add,
    overlay_table_state_after_remove,
    overlay_table_state_after_rename,
)
from easygraph.plotting.layout import custom_overlay_secondary_axis_active
from easygraph.plotting.overlay_renderer import (
    LINE_STYLE_ICON_SIZE,
    LINE_STYLE_POPUP_PREVIEW_WIDTH,
    line_style_icon,
    normalize_overlay_label_position,
)
from easygraph.project_io import project_path_with_suffix, read_workbook_project, write_project
from easygraph.recovery import (
    RecoveryCandidate,
    RecoveryManager,
    discard_recovery,
    find_recovery_candidates,
    read_recovery_workbook,
)
from easygraph.prism_io import PrismImportError
from easygraph.settings import (
    ChartSettings,
    LEGEND_INSIDE_AUTO_POSITION,
    LEGEND_POSITION_INSIDE,
    LEGEND_POSITION_RIGHT,
    LINE_OVERLAY_STYLES,
    PRESETS,
    STAT_TABLE_OPTIONS,
)
from easygraph.spreadsheet_io import (
    SpreadsheetSheet,
    read_spreadsheet,
    read_spreadsheet_book,
    write_spreadsheet,
    write_spreadsheet_book,
)
from easygraph.table_actions import set_group_header
from easygraph.table_clipboard import paste_rows_into_table, tsv_to_rows
from easygraph.table_data import (
    custom_overlay_state_from_series,
    normalized_hidden_overlay_indexes,
    overlay_row_for_removal,
    overlay_row_name,
    sync_group_order_state,
    table_group_name,
)
from easygraph.table_style import row_header_min_width
from easygraph.table_history import CallbackEdit
from easygraph.table_structure import (
    TableSelection,
    delete_table_rows,
    ensure_trailing_blank_row,
    expanded_pair_columns,
    insert_table_rows,
    shift_cells_down,
    shift_cells_up,
    table_selection,
)
from easygraph.template_io import (
    TEMPLATE_FAMILY_GROUPS,
    TEMPLATE_FAMILY_XY,
    TEMPLATE_NONE_NAME,
    XYStyleTemplate,
    apply_xy_style_template,
    apply_style_template_settings,
    import_style_template,
    list_style_templates,
    read_style_template,
    read_xy_style_template,
    style_template_families_file,
    write_style_template,
)
from easygraph.ui.dialogs import (
    ChecklistItem,
    GroupColorSelection,
    OverlayStyleSelection,
    Ui_ChecklistFilterDialog,
    Ui_GroupColorsDialog,
    Ui_GroupOrderDialog,
    Ui_OverlayStylesDialog,
    create_checklist_filter_dialog,
    create_group_colors_dialog,
    create_group_order_dialog,
    create_overlay_styles_dialog,
    run_checklist_filter_dialog,
    run_group_colors_dialog,
    run_group_order_dialog,
    run_overlay_styles_dialog,
)
from easygraph.ui.line_style_delegate import LineStyleItemDelegate
from easygraph.ui.palette_combo import PREVIEW_PADDING, PaletteComboBox
from easygraph.ui.prism_import_dialog import choose_prism_tables, prism_error_text
from easygraph.ui.preferences_dialog import PreferencesDialog, PreferencesState
from easygraph.ui.statistic_format_dialog import StatisticFormatDialog
from easygraph.ui.spreadsheet_import_dialog import choose_spreadsheet_sheets
from easygraph.ui.table_controller import TableController, TableControllerHooks
from easygraph.workbook import (
    SHEET_MODE_GROUPS,
    SHEET_MODE_XY,
    SheetDocument,
    WorkbookDocument,
    new_column_id,
    next_default_sheet_name,
    normalized_sheet_mode,
    normalized_sheet_name,
    sheet_name_error,
    unique_sheet_name,
)
from easygraph.workbook_session import SheetSessionState
from easygraph.xy_data import PreparedXYData, prepare_xy_data
from easygraph.xy_fit_worker import XYFitBatchWorker, XYFitJob
from easygraph.xy_fitting import (
    XYFitResult,
    XYFitSpec,
    fit_xy_values,
    initial_fit_parameters,
)
from easygraph.xy_series import (
    XYSeriesSpec,
    XYSharedTableSpec,
    XYSettings,
    ensure_xy_table_layout,
    new_series_id,
    paired_xy_column_ids,
    remove_xy_column_references,
    reorder_series_for_table_layout,
    shared_table_column_ids,
    shared_x_series,
)
from easygraph.xy_table_data import (
    DEFAULT_XY_TABLE_ROWS,
    dataframe_column_subset,
    dataframe_with_trailing_blank_row,
    replace_dataframe_columns,
)
from ui_main_window import Ui_MainWindow


APP_CONTROL_HEIGHT = 26
COMBO_TEXT_WIDTH_PADDING = 55
COMBO_MIN_WIDTH = 96
APP_RENDER_DEBOUNCE_MS = 150
XY_FIT_DEBOUNCE_MS = 350
_DIRECT_LINEAR_XY_FIT_MODEL_IDS = frozenset(
    {"linear", "polynomial2", "polynomial3", "polynomial4", "polynomial5"}
)
COLOR_PREVIEW_RENDER_DEBOUNCE_MS = 75
RECOVERY_IDLE_CHECKPOINT_MS = 30_000
DEFAULT_GROUP_TABLE_ROWS = 12
DEFAULT_XY_SHARED_Y_COLUMNS = 2
DEFAULT_XY_INDEPENDENT_PAIRS = 2
XY_MIXED_COMBO_DATA = "__easygraph_xy_mixed__"


class RenderMode(Enum):
    FULL = "full"
    TEXT_ONLY = "text_only"


class MainWindow(QMainWindow):
    def __init__(
        self,
        initial_render: bool = True,
        defer_preview: bool = False,
        *,
        recovery_enabled: bool = False,
        recovery_root: Path | None = None,
    ) -> None:
        super().__init__()
        self.settings = ChartSettings()
        initial_dataframe = sample_data()
        self.workbook = WorkbookDocument.single(initial_dataframe, self.settings)
        self._sheet_sessions: dict[str, SheetSessionState] = {}
        self._switching_sheet = False
        self.current_project: Path | None = None
        self._saved_project_content: tuple | None = None
        self._saved_sheet_content: dict[str, tuple] = {}
        self._recovered_on_startup = False
        self._recovery_manager: RecoveryManager | None = None
        self._recovery_root = recovery_root
        self._recovery_events_suspended = False
        self._recovery_checkpoint_scheduled = False
        self._recovery_idle_timer = QTimer(self)
        self._recovery_idle_timer.setSingleShot(True)
        self._recovery_idle_timer.setInterval(RECOVERY_IDLE_CHECKPOINT_MS)
        self._recovery_idle_timer.timeout.connect(self._checkpoint_recovery)
        self._applying_settings = False
        self._committing_control_edits = False
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.setInterval(APP_RENDER_DEBOUNCE_MS)
        self._render_timer.timeout.connect(self.flush_pending_render)
        self._xy_fit_timer = QTimer(self)
        self._xy_fit_timer.setSingleShot(True)
        self._xy_fit_timer.setInterval(XY_FIT_DEBOUNCE_MS)
        self._xy_fit_timer.timeout.connect(self._start_xy_auto_fit)
        self._xy_fit_results_by_sheet: dict[str, dict[str, XYFitResult]] = {}
        self._xy_fit_signatures_by_sheet: dict[str, dict[str, str]] = {}
        self._xy_fit_inflight_signatures: dict[str, dict[str, str]] = {}
        self._xy_fit_pending_token: tuple[str, tuple[tuple[str, str], ...]] | None = None
        self._active_xy_fit_dialog_sheet_id: str | None = None
        self._xy_fit_workers: set[XYFitBatchWorker] = set()
        self._xy_fit_worker_context: dict[object, tuple[XYFitBatchWorker, str, dict[str, str]]] = {}
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.table = self.ui.dataTable
        self.results_table = self.ui.analysisResultsTable
        self.xy_independent_table = self.ui.xyIndependentTable
        self._table_selection_origins: dict[object, str] = {}
        self._table_header_context_targets: dict[object, tuple[object, Qt.Orientation]] = {}
        self._active_xy_shared_column_ids: list[str] = []
        self._active_xy_paired_column_ids: list[str] = []
        self._loading_xy_workspace = False
        self._table_capacity_update_pending = False
        self._group_auto_spare_names: dict[str, dict[str, str]] = {}
        self._syncing_analysis_columns = False
        self._syncing_table_selections = False
        self._table_controller = TableController(
            table=self.table,
            settings=lambda: self.settings,
            sheet=lambda: self.workbook.active_sheet,
            hooks=TableControllerHooks(
                render=self.schedule_render,
                update_history_actions=self._apply_table_history_action_state,
                update_dependent_controls=self._update_dependent_control_states,
                sync_overlay_controls=self._apply_table_history_controls,
                sheet_state_changed=self._handle_table_sheet_state_changed,
            ),
            column_ids=self._main_table_column_ids,
        )
        self._xy_paired_controller = TableController(
            table=self.xy_independent_table,
            settings=lambda: self.settings,
            sheet=lambda: self.workbook.active_sheet,
            column_ids=lambda: self._active_xy_paired_column_ids,
            hooks=TableControllerHooks(
                render=self.schedule_render,
                update_history_actions=self._apply_custom_table_history_action_state,
                update_dependent_controls=self._update_dependent_control_states,
                sync_overlay_controls=self._apply_table_history_controls,
                sheet_state_changed=self._record_recovery_sheet_state,
            ),
        )
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.xy_independent_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Interactive
        )
        self.xy_independent_table.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
        self._configure_analysis_results_workspace()
        self._selected_plot_object_kind: str | None = None
        self._last_additional_guides_axis_key = "primary"
        self._loading_additional_guides = False
        self._syncing_xy_series_selection_list = False
        self._xy_series_selection_anchor_id: str | None = None
        self._xy_mixed_style_fields: set[str] = set()
        self._xy_mixed_spin_edits: set[str] = set()
        self.chart_elements_menu: QMenu | None = None
        self.chart_element_actions: dict[str, QAction] = {}
        self.canvas = None
        self._plot_placeholder = None
        if defer_preview:
            self._show_plot_placeholder()
        else:
            self._ensure_plot_canvas()
        self._bind_ui_widgets()
        self._populate_ui_options()
        self.refresh_template_combo()
        self._polish_input_controls()
        self.set_table_dataframe(initial_dataframe)
        self.reset_table_history()
        self._sheet_sessions[self.workbook.active_sheet_id] = SheetSessionState(
            history=self._table_controller.history,
        )
        self.apply_settings_to_controls()
        self._rebuild_sheet_tabs()
        self._connect_generated_ui()
        self.table_tools = TableToolsController(self)
        configure_top_toolbar(self)
        self._build_chart_elements_menu()
        if defer_preview and initial_render:
            QTimer.singleShot(
                0,
                self,
                lambda: self.initialize_preview(initial_render=initial_render),
            )
        elif initial_render:
            self.initialize_preview(initial_render=True)
        self.sync_manual_group_order()
        self._set_saved_project_baseline()
        if recovery_enabled:
            self._initialize_recovery()

    def _configure_analysis_results_workspace(self) -> None:
        main_splitter = self.ui.mainSplitter
        main_splitter.setChildrenCollapsible(True)
        main_splitter.setStretchFactor(0, 0)
        main_splitter.setStretchFactor(1, 1)
        main_splitter.setStretchFactor(2, 0)

        splitter = self.ui.dataResultsSplitter
        splitter.setChildrenCollapsible(True)
        splitter.setCollapsible(0, True)
        splitter.setCollapsible(1, True)
        splitter.setHandleWidth(6)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([620, 300])

        self.table.setHorizontalScrollMode(
            QAbstractItemView.ScrollMode.ScrollPerPixel
        )
        self.xy_independent_table.setHorizontalScrollMode(
            QAbstractItemView.ScrollMode.ScrollPerPixel
        )
        # Equal scrollbar gutters keep the source/result column origins aligned
        # even when only the source table has enough rows to scroll.
        self.table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.results_table.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOn
        )
        self.table.horizontalScrollBar().valueChanged.connect(
            self.results_table.horizontalScrollBar().setValue
        )
        self.results_table.horizontalScrollBar().valueChanged.connect(
            self.table.horizontalScrollBar().setValue
        )
        self.table.horizontalHeader().sectionResized.connect(
            self._sync_result_column_from_data
        )
        self.results_table.horizontalHeader().sectionResized.connect(
            self._sync_data_column_from_result
        )
        self.results_table.set_statistics_filter_options(
            DESCRIPTIVE_STATISTICS
        )
        self.results_table.statisticsVisibilityChanged.connect(
            self._handle_analysis_statistics_visibility_changed
        )
        self.ui.xySharedTitleLabel.setVisible(False)
        self.ui.xySharedTabBar.setVisible(False)
        self.ui.addXYSharedTableButton.setVisible(False)
        self.ui.removeXYSharedTableButton.setVisible(False)
        self.ui.xyIndependentTitleLabel.setVisible(False)
        self.xy_independent_table.setVisible(False)

    def _handle_analysis_statistics_visibility_changed(
        self,
        ordered: tuple[str, ...],
    ) -> None:
        self.workbook.active_sheet.analysis_settings.visible_statistics = list(
            ordered
        )
        self.refresh_analysis_results()
        self._record_recovery_analysis()
        self._update_sheet_tab_texts()

    def _sync_result_column_from_data(
        self,
        logical_index: int,
        _old_size: int,
        new_size: int,
    ) -> None:
        if self._syncing_analysis_columns:
            return
        if logical_index >= self.results_table.model().columnCount():
            return
        self._syncing_analysis_columns = True
        try:
            self.results_table.setColumnWidth(logical_index, new_size)
        finally:
            self._syncing_analysis_columns = False

    def _sync_data_column_from_result(
        self,
        logical_index: int,
        _old_size: int,
        new_size: int,
    ) -> None:
        if self._syncing_analysis_columns:
            return
        if logical_index >= self.table.model().columnCount():
            return
        self._syncing_analysis_columns = True
        try:
            self.table.setColumnWidth(logical_index, new_size)
        finally:
            self._syncing_analysis_columns = False

    def _align_analysis_results_table(self) -> None:
        result = self.results_table.results_model.result
        if not result.source_aligned:
            return
        self._syncing_analysis_columns = True
        try:
            column_count = min(
                self.table.model().columnCount(),
                self.results_table.model().columnCount(),
            )
            for column in range(column_count):
                self.results_table.setColumnWidth(
                    column,
                    self.table.columnWidth(column),
                )
        finally:
            self._syncing_analysis_columns = False

        label_width = max(
            (
                self.results_table.fontMetrics().horizontalAdvance(label)
                for label in result.row_labels
            ),
            default=0,
        ) + 20
        shared_header_width = max(
            row_header_min_width(self.custom_overlay_row_count()),
            label_width,
            34,
        )
        self.table.verticalHeader().setFixedWidth(shared_header_width)
        self.results_table.verticalHeader().setFixedWidth(shared_header_width)
        self.table.updateGeometries()
        self.results_table.updateGeometries()
        self.results_table.update_statistics_filter_geometry()

    def refresh_analysis_results(
        self,
        dataframe: pd.DataFrame | None = None,
    ) -> None:
        if self._is_xy_sheet():
            return
        if dataframe is None:
            dataframe = self._user_group_dataframe()
        result = descriptive_statistics_result(
            dataframe,
            visible_statistics=self.results_table.visible_statistics(),
            statistic_formats=self.workbook.active_sheet.analysis_settings.statistic_formats,
            title=(
                "Column descriptive statistics"
                if self._is_xy_sheet()
                else "Descriptive statistics"
            ),
        )
        result = self._project_group_spare_into_analysis_result(result)
        self.results_table.set_result(result)
        sheet = self.workbook.active_sheet
        self.results_table.set_grouping(
            sheet.grouping.parents,
            sheet.column_ids[:len(result.columns)],
        )
        localized_title = (
            self.tr("Column descriptive statistics")
            if self._is_xy_sheet()
            else self.tr("Descriptive statistics")
        )
        self.ui.resultsTitleLabel.setText(
            self.tr("Analysis Results · {title}").format(
                title=localized_title
            )
        )
        self._align_analysis_results_table()

    def _handle_table_sheet_state_changed(self) -> None:
        # Parent edits and history changes must reach the statistics table even
        # when automatic chart rendering is disabled or waiting on its timer.
        if not self._is_xy_sheet():
            self.refresh_analysis_results()
        self._record_recovery_sheet_state()

    def _project_group_spare_into_analysis_result(
        self,
        result: AnalysisTableResult,
    ) -> AnalysisTableResult:
        model = self.table.table_model
        spare_column = model.columnCount() - 1
        if (
            spare_column < 0
            or not result.source_aligned
            or not self._group_last_column_is_auto_spare()
            or len(result.columns) != spare_column
        ):
            return result
        spare_name = model.cell_text(0, spare_column)
        return AnalysisTableResult(
            key=result.key,
            title=result.title,
            columns=(*result.columns, spare_name),
            row_labels=result.row_labels,
            values=tuple((*row, "") for row in result.values),
            source_aligned=result.source_aligned,
        )

    def copy_analysis_results_selection(self) -> None:
        data = self.results_table.selection_clipboard_data()
        if data is not None:
            self._write_table_clipboard(data)

    def copy_analysis_results_selection_with_headers(self) -> None:
        data = self.results_table.selection_clipboard_data(include_headers=True)
        if data is not None:
            self._write_table_clipboard(data)

    def copy_analysis_results_table(self) -> None:
        data = self.results_table.table_clipboard_data()
        if data is not None:
            self._write_table_clipboard(data)
            self.statusBar().showMessage(
                self.tr("Statistics table copied to clipboard"),
                2500,
            )

    def _handle_data_table_selection_changed(
        self,
        selected,
        _deselected,
    ) -> None:
        if not selected.isEmpty():
            self.table.horizontalHeader().clear_parent_selection()
        if hasattr(self, "table_tools"):
            self.table_tools.update_state()
        if self._syncing_table_selections or selected.isEmpty():
            return
        self._syncing_table_selections = True
        try:
            self.results_table.clearSelection()
        finally:
            self._syncing_table_selections = False

    def _handle_analysis_table_selection_changed(
        self,
        selected,
        _deselected,
    ) -> None:
        if self._syncing_table_selections or selected.isEmpty():
            return
        if hasattr(self, "table_tools"):
            self.table_tools.deactivate()
        self._syncing_table_selections = True
        try:
            self.table.clearSelection()
            self.table.horizontalHeader().clear_parent_selection()
        finally:
            self._syncing_table_selections = False

    def _show_plot_placeholder(self) -> None:
        if self._plot_placeholder is not None:
            return
        placeholder = QLabel(self.tr("Preparing preview…"), self.ui.plotHost)
        placeholder.setObjectName("plotPreviewPlaceholder")
        placeholder.setAlignment(Qt.AlignCenter)
        self.ui.plotHostLayout.addWidget(placeholder)
        self._plot_placeholder = placeholder

    def _ensure_plot_canvas(self):
        if self.canvas is not None:
            return self.canvas
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        canvas.selection_callback = self.handle_plot_object_selection
        canvas.legend_position_callback = self.handle_legend_drag_position
        canvas.fit_equation_position_callback = (
            self.handle_fit_equation_drag_position
        )
        if self._plot_placeholder is not None:
            self.ui.plotHostLayout.removeWidget(self._plot_placeholder)
            self._plot_placeholder.deleteLater()
            self._plot_placeholder = None
        self.ui.plotHostLayout.addWidget(canvas)
        self.canvas = canvas
        self._attach_chart_elements_menu()
        return canvas

    def initialize_preview(self, *, initial_render: bool = True) -> None:
        canvas = self._ensure_plot_canvas()
        if initial_render and not hasattr(canvas, "_last_settings"):
            was_clean = not self.has_unsaved_changes()
            self.render()
            self._fit_initial_plot_to_viewport()
            if was_clean:
                self._set_saved_project_baseline()

    def _fit_initial_plot_to_viewport(self) -> None:
        canvas = self._ensure_plot_canvas()
        canvas.zoom_to_fit()
        QTimer.singleShot(0, canvas, canvas.zoom_to_fit)

    def handle_plot_object_selection(self, object_kind: str | None) -> None:
        if hasattr(self, "table_tools"):
            self.table_tools.deactivate()
        selected_guide = (
            self.canvas.selected_additional_guide()
            if object_kind == "additional_grid_line"
            and self.canvas is not None
            else None
        )
        if object_kind == "plot_area" and self._is_xy_sheet():
            if (
                self.canvas is not None
                and getattr(self.canvas, "_selected_object_kind", None) == "plot_area"
            ):
                self.canvas.clear_plot_selection()
                return
            object_kind = None
        if object_kind == "primary_axis":
            self._last_additional_guides_axis_key = "primary"
        elif object_kind == "category_axis" and self._is_xy_sheet():
            self._last_additional_guides_axis_key = "x"
        elif selected_guide is not None:
            self._last_additional_guides_axis_key = selected_guide[0]
        self._selected_plot_object_kind = object_kind
        self._apply_xy_series_style_scope_to_controls()
        self._update_inspector_context(object_kind)
        self._apply_inspector_focus(object_kind)
        self._update_contextual_font_slots()
        if selected_guide is not None:
            self._refresh_additional_guides_table(selected_guide[1])
            current = self.additional_guides_table.currentItem()
            if current is not None:
                self.additional_guides_table.scrollToItem(current)
        self._update_dependent_control_states()
        section = self._section_for_plot_object(object_kind)
        if section is None:
            return
        self.ui.controlsScroll.ensureWidgetVisible(section, 0, 8)
        if object_kind == "points" and self._is_xy_sheet():
            QTimer.singleShot(
                0,
                self.ui.controlsScroll,
                lambda: self.ui.controlsScroll.ensureWidgetVisible(
                    self.ui.pointsGroup,
                    0,
                    8,
                ),
            )

    def _plot_object_label(self, object_kind: str) -> str:
        labels = {
            "legend": self.tr("Legend"),
            "stats_table": self.tr("In-chart Statistics"),
            "axis": self.tr("Axes"),
            "category_axis": self.ui.categoryAxisGroup.title(),
            "primary_axis": self.ui.primaryAxisGroup.title(),
            "secondary_axis": self.ui.secondaryAxisGroup.title(),
            "chart_title": self.tr("Chart Title"),
            "title_axis": self.ui.titleAxisGroup.title(),
            "plot_area": self.tr("Chart Style"),
            "points": self.ui.pointsGroup.title(),
            "outliers": self.tr("Outliers"),
            "line_overlay": self.tr("Line Overlay"),
            "additional_grid_line": self.tr("Additional grid line"),
        }
        return labels.get(object_kind, object_kind.replace("_", " ").title())

    def _build_chart_elements_menu(self) -> None:
        if self.chart_elements_menu is not None:
            self._attach_chart_elements_menu()
            return

        menu = QMenu(self)
        menu.setObjectName("chartElementsMenu")
        menu.setToolTipsVisible(True)
        self.chart_elements_menu = menu

        def add_action(
            key: str,
            text: str,
            *,
            checkable: bool = True,
            parent_menu: QMenu = menu,
        ) -> QAction:
            action = QAction(text, self)
            action.setObjectName(
                "chartElements"
                + "".join(part.title() for part in key.split("_"))
                + "Action"
            )
            action.setCheckable(checkable)
            parent_menu.addAction(action)
            self.chart_element_actions[key] = action
            return action

        def connect_checkbox_action(action: QAction, checkbox: QCheckBox) -> None:
            action.triggered.connect(
                lambda _checked=False, source=action, target=checkbox: target.setChecked(
                    source.isChecked()
                )
            )

        connect_checkbox_action(
            add_action("legend", self.tr("Legend")),
            self.show_legend,
        )
        connect_checkbox_action(
            add_action("stats_table", self.tr("Statistics Table")),
            self.show_stat_table,
        )
        points_action = add_action("points", self.tr("Data Points"))
        points_action.triggered.connect(
            lambda checked=False: self._set_chart_element_xy_style_visibility(
                "show_points",
                bool(checked),
                self.show_points,
            )
        )
        lines_action = add_action("lines", self.tr("Lines"))
        lines_action.triggered.connect(
            lambda checked=False: self._set_chart_element_xy_style_visibility(
                "show_line",
                bool(checked),
                self.xy_show_line,
            )
        )
        lines_action.setVisible(self._is_xy_sheet())
        connect_checkbox_action(
            add_action("outliers", self.tr("Outliers")),
            self.show_outliers,
        )
        connect_checkbox_action(
            add_action("grid", self.tr("Grid Lines")),
            self.show_grid,
        )

        menu.addSeparator()
        summary_menu = menu.addMenu(self.tr("Summary Line"))
        summary_menu.setObjectName("summaryLineMenu")
        summary_group = QActionGroup(self)
        summary_group.setExclusive(True)
        for key, label, value in (
            ("summary_none", self.tr("None"), "None"),
            ("summary_median", self.tr("Median"), "Median"),
            ("summary_mean", self.tr("Mean"), "Mean"),
        ):
            action = add_action(key, label, parent_menu=summary_menu)
            summary_group.addAction(action)
            action.triggered.connect(
                lambda _checked=False, overlay=value: self.line_overlay_stat.setCurrentText(
                    overlay
                )
            )
        self.chart_elements_summary_group = summary_group

        menu.addSeparator()
        add_action(
            "add_custom_overlay",
            self.tr("Add Custom Overlay…"),
            checkable=False,
        ).triggered.connect(self.add_custom_overlay_row)
        custom_overlay_action = add_action(
            "custom_overlay",
            self.tr("Custom Overlay Lines"),
        )
        custom_overlay_action.triggered.connect(
            lambda _checked=False: self._set_custom_overlay_from_chart_elements(
                custom_overlay_action.isChecked()
            )
        )
        secondary_axis_action = add_action(
            "secondary_axis",
            self.tr("Secondary Axis for Custom Overlays"),
        )
        secondary_axis_action.triggered.connect(
            lambda _checked=False: self._set_secondary_axis_from_chart_elements(
                secondary_axis_action.isChecked()
            )
        )
        connect_checkbox_action(
            add_action(
                "split_secondary_axis",
                self.tr("Separate Secondary Axis"),
            ),
            self.split_secondary_axis,
        )
        connect_checkbox_action(
            add_action(
                "line_values",
                self.tr("Overlay Value Labels"),
            ),
            self.show_line_values,
        )

        menu.aboutToShow.connect(self._refresh_chart_elements_menu)
        self._attach_chart_elements_menu()

    def _attach_chart_elements_menu(self) -> None:
        if self.canvas is None or self.chart_elements_menu is None:
            return
        button = self.canvas.chart_elements_button
        button.setText(self.tr("Chart Elements"))
        button.setToolTip(self.tr("Show or hide chart elements"))
        button.setAccessibleName(self.tr("Chart Elements"))
        button.setMenu(self.chart_elements_menu)

    def _refresh_chart_elements_menu(self) -> None:
        actions = self.chart_element_actions
        if not actions:
            return

        actions["legend"].setChecked(self.show_legend.isChecked())
        actions["stats_table"].setChecked(self.show_stat_table.isChecked())
        if self._is_xy_sheet():
            xy_settings = self.workbook.active_sheet.xy_settings
            actions["points"].setChecked(xy_settings.show_points)
            actions["lines"].setChecked(xy_settings.show_line)
        else:
            actions["points"].setChecked(self.show_points.isChecked())
            actions["lines"].setChecked(self.xy_show_line.isChecked())
        actions["outliers"].setChecked(self.show_outliers.isChecked())
        actions["grid"].setChecked(self.show_grid.isChecked())

        summary_value = self.line_overlay_stat.currentText()
        actions["summary_none"].setChecked(summary_value == "None")
        actions["summary_median"].setChecked(summary_value == "Median")
        actions["summary_mean"].setChecked(summary_value == "Mean")

        custom_overlay_count = self.custom_overlay_row_count()
        has_custom_overlays = custom_overlay_count > 0
        visible_custom_overlays = custom_overlay_count > len(
            normalized_hidden_overlay_indexes(
                self.settings.custom_overlay_hidden,
                custom_overlay_count,
            )
        )
        custom_overlays_visible = (
            visible_custom_overlays and self.extra_custom_overlay.isChecked()
        )
        secondary_axis_visible = (
            custom_overlays_visible
            and self.custom_overlay_secondary_axis.isChecked()
        )
        actions["custom_overlay"].setEnabled(has_custom_overlays)
        actions["custom_overlay"].setChecked(custom_overlays_visible)
        actions["secondary_axis"].setEnabled(has_custom_overlays)
        actions["secondary_axis"].setChecked(secondary_axis_visible)
        actions["secondary_axis"].setToolTip(
            self.tr("Show custom overlay values on a secondary axis")
            if has_custom_overlays
            else self.tr("Add a custom overlay before enabling the secondary axis")
        )
        actions["split_secondary_axis"].setEnabled(secondary_axis_visible)
        actions["split_secondary_axis"].setChecked(
            self.split_secondary_axis.isChecked()
        )

        overlays_visible = summary_value != "None" or custom_overlays_visible
        actions["line_values"].setEnabled(overlays_visible)
        actions["line_values"].setChecked(
            self.show_line_values.isChecked()
        )

    def _set_chart_element_xy_style_visibility(
        self,
        field: str,
        checked: bool,
        fallback_checkbox: QCheckBox,
    ) -> None:
        if not self._is_xy_sheet():
            fallback_checkbox.setChecked(checked)
            return
        self._set_xy_all_series_style_value(field, checked)
        self._apply_xy_series_style_scope_to_controls()
        self._update_dependent_control_states()
        self._record_recovery_sheet_state()
        self.schedule_render(RenderMode.FULL)

    def _set_custom_overlay_from_chart_elements(self, checked: bool) -> None:
        custom_overlay_count = self.custom_overlay_row_count()
        if custom_overlay_count <= 0:
            return
        if checked and len(
            normalized_hidden_overlay_indexes(
                self.settings.custom_overlay_hidden,
                custom_overlay_count,
            )
        ) >= custom_overlay_count:
            self.settings.custom_overlay_hidden = []
            if self.extra_custom_overlay.isChecked():
                self.update_settings()
                return
        self.extra_custom_overlay.setChecked(checked)

    def _set_secondary_axis_from_chart_elements(self, checked: bool) -> None:
        if checked and self.custom_overlay_row_count() <= 0:
            return
        if checked:
            self._set_custom_overlay_from_chart_elements(True)
        self.custom_overlay_secondary_axis.setChecked(checked)

    def _update_inspector_context(self, object_kind: str | None) -> None:
        if object_kind is None:
            self.ui.inspectorContextLabel.setText(self.tr("Editing: All settings"))
            self.ui.inspectorShowAllButton.setEnabled(False)
            return
        if object_kind == "points" and self._is_xy_sheet():
            scope, selected_series = self._xy_style_selection()
            if scope == "all":
                self.ui.inspectorContextLabel.setText(
                    self.tr("Editing: All series")
                )
            elif not selected_series:
                self.ui.inspectorContextLabel.setText(
                    self.tr("Editing: No series selected")
                )
            elif len(selected_series) == 1:
                self.ui.inspectorContextLabel.setText(
                    self.tr("Editing: {series}").format(
                        series=selected_series[0].name
                    )
                )
            else:
                self.ui.inspectorContextLabel.setText(
                    self.tr("Editing: {count} series").format(
                        count=len(selected_series)
                    )
                )
            self.ui.inspectorShowAllButton.setEnabled(True)
            return
        self.ui.inspectorContextLabel.setText(
            self.tr("Editing: {object}").format(
                object=self._plot_object_label(object_kind)
            )
        )
        self.ui.inspectorShowAllButton.setEnabled(True)

    @staticmethod
    def _additional_guides_setting_name(axis_key: str) -> str:
        if axis_key == "x":
            return "additional_x_axis_guides"
        if axis_key == "primary":
            return "additional_primary_axis_guides"
        raise ValueError(f"Unsupported additional-guide axis: {axis_key}")

    def _additional_guides_for_axis(self, axis_key: str) -> list[dict]:
        return getattr(
            self.settings,
            self._additional_guides_setting_name(axis_key),
        )

    def _additional_guide_dimension(self, axis_key: str) -> str:
        if axis_key == "x":
            return "x"
        if axis_key == "primary":
            return (
                "x"
                if not self._is_xy_sheet()
                and self.settings.chart_type == "Ridge"
                else "y"
            )
        raise ValueError(f"Unsupported additional-guide axis: {axis_key}")

    @staticmethod
    def _additional_guide_display_position(
        value: object,
        dimension: str,
        field: str,
    ) -> str:
        """Map a saved position to the closest option shown for this axis."""

        normalized = str(value)
        if field == "text_side" and dimension == "x":
            return {
                "plot_left": "left",
                "plot_right": "right",
            }.get(normalized, normalized)
        if field == "text_side":
            return {
                "center": "plot_left",
                "right": "plot_left",
            }.get(normalized, normalized)
        if dimension == "x":
            return {
                "aligned": "plot_bottom",
                "above": "plot_bottom",
            }.get(normalized, normalized)
        return {
            "plot_bottom": "below",
            "plot_top": "above",
        }.get(normalized, normalized)

    def _refresh_additional_guide_position_options(
        self,
        axis_key: str | None = None,
    ) -> None:
        if axis_key is None:
            axis_key = self._selected_additional_guides_axis_key()
        if axis_key is None:
            return
        dimension = self._additional_guide_dimension(axis_key)
        if dimension == "x":
            side_values = ["left", "center", "right"]
            vertical_values = ["plot_bottom", "plot_top", "below"]
        else:
            side_values = ["plot_left", "plot_right", "left"]
            vertical_values = ["aligned", "above", "below"]
        labels = {
            "left": self.tr("Left"),
            "center": self.tr("Center"),
            "right": self.tr("Right"),
            "aligned": self.tr("Center"),
            "above": self.tr("Above"),
            "below": self.tr("Below"),
            "plot_left": self.tr("Align to plot left"),
            "plot_right": self.tr("Align to plot right"),
            "plot_bottom": self.tr("Align to plot bottom"),
            "plot_top": self.tr("Align to plot top"),
        }
        if dimension == "x":
            labels["below"] = self.tr("Below X axis")
        else:
            labels["left"] = self.tr("Left of Y axis")

        def replace_options(
            combo: QComboBox,
            values: list[str],
            fallback: str,
            field: str,
        ) -> None:
            current = self._additional_guide_display_position(
                combo.currentData(),
                dimension,
                field,
            )
            signals_blocked = combo.blockSignals(True)
            try:
                combo.clear()
                for value in values:
                    combo.addItem(labels[value], value)
                selected_index = combo.findData(current)
                if selected_index < 0:
                    selected_index = combo.findData(fallback)
                combo.setCurrentIndex(max(selected_index, 0))
            finally:
                combo.blockSignals(signals_blocked)

        replace_options(
            self.additional_guide_text_side,
            side_values,
            "right" if dimension == "x" else "plot_left",
            "text_side",
        )
        replace_options(
            self.additional_guide_text_vertical,
            vertical_values,
            "plot_bottom" if dimension == "x" else "above",
            "vertical_position",
        )

    def _set_additional_guide_editor_enabled(self, enabled: bool) -> None:
        for widget in (
            self.additional_guide_value,
            self.additional_guide_tick,
            self.additional_guide_show_value,
            self.additional_guide_line,
            self.additional_guide_color,
            self.additional_guide_text_color,
            self.additional_guide_text,
            self.additional_guide_text_side,
            self.additional_guide_text_vertical,
            self.additional_guide_label_background,
        ):
            widget.setEnabled(enabled)
        self.additional_guide_delete_button.setEnabled(enabled)

    @staticmethod
    def _additional_guide_color_icon(color: str) -> QIcon:
        pixmap = QPixmap(24, 14)
        qcolor = QColor(color)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.fillRect(
            1,
            1,
            22,
            12,
            qcolor if qcolor.isValid() else QColor("#000000"),
        )
        painter.setPen(QColor("#6B7280"))
        painter.drawRect(0, 0, 23, 13)
        painter.end()
        return QIcon(pixmap)

    def _refresh_additional_guide_color_options(
        self,
        selected_slot: int | None = None,
    ) -> None:
        if selected_slot is None:
            current = self.additional_guide_color.currentData()
            selected_slot = int(current) if current is not None else 0
        colors = additional_guide_palette_colors(
            self.settings,
            int(selected_slot) + 1,
        )
        blocked = self.additional_guide_color.blockSignals(True)
        try:
            self.additional_guide_color.clear()
            for index, color in enumerate(colors):
                self.additional_guide_color.addItem(
                    self._additional_guide_color_icon(color),
                    self.tr("Color {number}").format(number=index + 1),
                    index,
                )
                self.additional_guide_color.setItemData(
                    index,
                    color,
                    Qt.ItemDataRole.ToolTipRole,
                )
            selected_index = self.additional_guide_color.findData(
                int(selected_slot)
            )
            self.additional_guide_color.setCurrentIndex(
                max(0, selected_index)
            )
        finally:
            self.additional_guide_color.blockSignals(blocked)

    def _set_additional_guide_table_row(
        self,
        row: int,
        guide: dict,
    ) -> None:
        values = (
            format_additional_guide_value(guide["value"]),
            "✓" if guide["show_tick"] else "—",
            "✓" if guide["show_line"] else "—",
            self.tr("Color {number}").format(
                number=int(guide.get("color_index", 0)) + 1
            ),
            guide["text"].replace("\n", " / "),
        )
        for column, value in enumerate(values):
            item = self.additional_guides_table.item(row, column)
            if item is None:
                item = QTableWidgetItem()
                item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled
                    | Qt.ItemFlag.ItemIsSelectable
                )
                self.additional_guides_table.setItem(row, column, item)
            item.setText(value)
            if column in (1, 2, 3):
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if column == 3:
                color = additional_guide_color(self.settings, guide)
                item.setIcon(self._additional_guide_color_icon(color))
                item.setToolTip(color)
            if column == 4:
                item.setToolTip(guide["text"])

    def _refresh_additional_guides_table(
        self,
        selected_row: int | None = None,
    ) -> None:
        axis_key = self._selected_additional_guides_axis_key()
        previous_row = self.additional_guides_table.currentRow()
        guides = (
            self._additional_guides_for_axis(axis_key)
            if axis_key is not None
            else []
        )
        if selected_row is None:
            selected_row = previous_row
        self._loading_additional_guides = True
        self.additional_guides_table.blockSignals(True)
        try:
            self.additional_guides_table.setRowCount(len(guides))
            for row, guide in enumerate(guides):
                self._set_additional_guide_table_row(row, guide)
            if guides:
                selected_row = min(max(int(selected_row), 0), len(guides) - 1)
                self.additional_guides_table.setCurrentCell(selected_row, 0)
                self.additional_guides_table.selectRow(selected_row)
            else:
                self.additional_guides_table.clearSelection()
                self.additional_guides_table.setCurrentCell(-1, -1)
        finally:
            self.additional_guides_table.blockSignals(False)
            self._loading_additional_guides = False
        self.additional_guide_add_button.setEnabled(
            axis_key is not None and len(guides) < MAX_ADDITIONAL_GUIDES
        )
        self._load_selected_additional_guide()

    def _load_selected_additional_guide(self) -> None:
        if self._loading_additional_guides:
            return
        axis_key = self._selected_additional_guides_axis_key()
        row = self.additional_guides_table.currentRow()
        guides = (
            self._additional_guides_for_axis(axis_key)
            if axis_key is not None
            else []
        )
        if not 0 <= row < len(guides):
            self._set_additional_guide_editor_enabled(False)
            return

        guide = guides[row]
        dimension = self._additional_guide_dimension(axis_key)
        self._loading_additional_guides = True
        try:
            self._set_additional_guide_editor_enabled(True)
            self.additional_guide_value.setValue(float(guide["value"]))
            self.additional_guide_tick.setChecked(bool(guide["show_tick"]))
            self.additional_guide_show_value.setChecked(
                bool(guide.get("show_value_with_text", False))
            )
            self.additional_guide_line.setChecked(bool(guide["show_line"]))
            self._refresh_additional_guide_color_options(
                int(guide.get("color_index", 0))
            )
            text_color_index = self.additional_guide_text_color.findData(
                guide.get("text_color_mode", "auto")
            )
            self.additional_guide_text_color.setCurrentIndex(
                max(text_color_index, 0)
            )
            self.additional_guide_text.setPlainText(str(guide["text"]))
            self.additional_guide_label_background.setChecked(
                bool(guide.get("show_label_background", False))
            )
            side_index = self.additional_guide_text_side.findData(
                self._additional_guide_display_position(
                    guide["text_side"],
                    dimension,
                    "text_side",
                )
            )
            self.additional_guide_text_side.setCurrentIndex(
                max(side_index, 0)
            )
            vertical_index = self.additional_guide_text_vertical.findData(
                self._additional_guide_display_position(
                    guide["vertical_position"],
                    dimension,
                    "vertical_position",
                )
            )
            self.additional_guide_text_vertical.setCurrentIndex(
                max(vertical_index, 0)
            )
        finally:
            self._loading_additional_guides = False

    def _handle_additional_guide_table_selection_changed(self) -> None:
        """Load the row and mirror a visible line selection on the canvas."""

        self._load_selected_additional_guide()
        if self._loading_additional_guides or self.canvas is None:
            return
        axis_key = self._selected_additional_guides_axis_key()
        row = self.additional_guides_table.currentRow()
        guides = (
            self._additional_guides_for_axis(axis_key)
            if axis_key is not None
            else []
        )
        if axis_key is not None and 0 <= row < len(guides):
            self.canvas.focus_additional_guide(axis_key, row)

    def _update_contextual_font_slots(self) -> None:
        axis_key = self._selected_additional_guides_axis_key()
        guide_visible = self._selected_plot_object_kind in {
            "category_axis",
            "primary_axis",
            "additional_grid_line",
        } and axis_key is not None
        line_value_visible = (
            self._selected_plot_object_kind == "line_overlay"
            and not self._is_xy_sheet()
        )
        stat_table_visible = (
            self._selected_plot_object_kind == "stats_table"
            and not self._is_xy_sheet()
        )
        self.ui.lineValueSizeLabel.setVisible(line_value_visible)
        self.line_value_font_size.setVisible(line_value_visible)
        self.ui.statTableSizeLabel.setVisible(stat_table_visible)
        self.stat_table_font_size.setVisible(stat_table_visible)
        self.additional_guide_font_size_label.setVisible(guide_visible)
        self.additional_guide_font_size.setVisible(guide_visible)
        show_axis_selector = (
            self._selected_plot_object_kind is None
            and self._is_xy_sheet()
            and axis_key is not None
        )
        self.additional_guides_axis_selector.setVisible(show_axis_selector)
        for radio, checked in (
            (self.additional_guides_x_axis_radio, axis_key == "x"),
            (self.additional_guides_y_axis_radio, axis_key == "primary"),
        ):
            blocked = radio.blockSignals(True)
            radio.setChecked(checked)
            radio.blockSignals(blocked)
        if axis_key is None:
            self._refresh_additional_guides_table()
            return

        self._refresh_additional_guide_position_options(axis_key)

        if axis_key == "x":
            axis_label = self.tr("X axis")
            position_label = self.tr("At X")
        elif self._is_xy_sheet():
            axis_label = self.tr("Y axis")
            position_label = self.tr("At Y")
        else:
            axis_label = self.tr("Value axis")
            position_label = self.tr("At value")
        self.ui.additionalGuidesAxisLabel.setText(
            self.tr("Editing additional marks on the {axis}").format(
                axis=axis_label
            )
        )
        header = self.additional_guides_table.horizontalHeaderItem(0)
        if header is not None:
            header.setText(position_label)
        self.additional_guide_font_size_label.setToolTip(
            self.tr("Font size for additional labels on the {axis}").format(
                axis=axis_label
            )
        )
        self._refresh_additional_guides_table()

    def _select_show_all_additional_guides_axis(
        self,
        axis_key: str,
        checked: bool,
    ) -> None:
        if (
            not checked
            or self._selected_plot_object_kind is not None
            or not self._is_xy_sheet()
            or axis_key not in {"x", "primary"}
        ):
            return
        self._last_additional_guides_axis_key = axis_key
        if self.canvas is not None:
            self.canvas.clear_additional_guide_focus()
        self._update_contextual_font_slots()

    def _default_additional_guide_value(self, axis_key: str) -> float:
        canvas = self.canvas
        if (
            canvas is None
            or canvas.figure is None
            or not canvas.figure.axes
        ):
            return 0.0
        axis = canvas.figure.axes[0]
        dimension = self._additional_guide_dimension(axis_key)
        low, high = axis.get_xlim() if dimension == "x" else axis.get_ylim()
        midpoint = (float(low) + float(high)) / 2.0
        return midpoint if math.isfinite(midpoint) else 0.0

    def _store_additional_guides(
        self,
        axis_key: str,
        guides: list[dict],
    ) -> None:
        setattr(
            self.settings,
            self._additional_guides_setting_name(axis_key),
            guides[:MAX_ADDITIONAL_GUIDES],
        )
        self._record_recovery_settings()
        self.schedule_render(RenderMode.FULL)

    def add_additional_guide(self) -> None:
        axis_key = self._selected_additional_guides_axis_key()
        if axis_key is None:
            return
        guides = deepcopy(self._additional_guides_for_axis(axis_key))
        if len(guides) >= MAX_ADDITIONAL_GUIDES:
            return
        new_guide = default_additional_guide(
            self._default_additional_guide_value(axis_key)
        )
        # New marks start as a complete, visible callout, aligned just inside
        # the plot frame for their physical axis.  Text follows the guide line
        # color by default; legacy records without this field remain automatic.
        dimension = self._additional_guide_dimension(axis_key)
        new_guide.update(
            {
                "show_tick": True,
                "show_value_with_text": True,
                "show_line": True,
                "text_side": "right" if dimension == "x" else "plot_left",
                "vertical_position": (
                    "plot_bottom" if dimension == "x" else "above"
                ),
                "text_color_mode": "match_line",
            }
        )
        guides.append(new_guide)
        used_slots = {
            int(guide.get("color_index", 0))
            for guide in (
                *self.settings.additional_x_axis_guides,
                *self.settings.additional_primary_axis_guides,
            )
        }
        guides[-1]["color_index"] = next(
            (
                index
                for index in range(MAX_ADDITIONAL_GUIDES * 2)
                if index not in used_slots
            ),
            len(guides) - 1,
        )
        self._store_additional_guides(axis_key, guides)
        self._refresh_additional_guides_table(len(guides) - 1)
        if self.canvas is not None:
            self.canvas.clear_additional_guide_focus()
        self.additional_guide_value.setFocus()
        self.additional_guide_value.selectAll()

    def delete_selected_additional_guide(self) -> None:
        axis_key = self._selected_additional_guides_axis_key()
        row = self.additional_guides_table.currentRow()
        if axis_key is None:
            return
        guides = deepcopy(self._additional_guides_for_axis(axis_key))
        if not 0 <= row < len(guides):
            return
        guides.pop(row)
        self._store_additional_guides(axis_key, guides)
        self._refresh_additional_guides_table(
            min(row, len(guides) - 1)
        )
        if self.canvas is not None:
            self.canvas.clear_additional_guide_focus()

    def _handle_additional_guide_text_changed(self) -> None:
        if self._loading_additional_guides:
            return
        text = self.additional_guide_text.toPlainText()
        limited = limit_additional_guide_text(text)
        if limited != text:
            cursor = self.additional_guide_text.textCursor()
            cursor_position = min(cursor.position(), len(limited))
            self.additional_guide_text.blockSignals(True)
            try:
                self.additional_guide_text.setPlainText(limited)
                cursor = self.additional_guide_text.textCursor()
                cursor.setPosition(cursor_position)
                self.additional_guide_text.setTextCursor(cursor)
            finally:
                self.additional_guide_text.blockSignals(False)
        self._commit_selected_additional_guide()

    def _commit_selected_additional_guide(
        self,
        *_args,
        changed_position: str | None = None,
    ) -> None:
        if self._loading_additional_guides or self._applying_settings:
            return
        axis_key = self._selected_additional_guides_axis_key()
        row = self.additional_guides_table.currentRow()
        if axis_key is None:
            return
        guides = deepcopy(self._additional_guides_for_axis(axis_key))
        if not 0 <= row < len(guides):
            return
        previous_guide = guides[row]

        def committed_position(
            field: str,
            combo: QComboBox,
            fallback: str,
        ) -> str:
            previous = str(previous_guide.get(field, fallback))
            available = {
                str(combo.itemData(index))
                for index in range(combo.count())
            }
            if previous not in available and changed_position != field:
                # Groups keeps one value-axis guide list when switching
                # Box/Violin (Y) and Ridge (X). Preserve an edge position that
                # is temporarily unavailable unless the user explicitly edits
                # this position control.
                return previous
            return str(combo.currentData() or fallback)

        guide = normalize_additional_guide(
            {
                "value": self.additional_guide_value.value(),
                "show_tick": self.additional_guide_tick.isChecked(),
                "show_value_with_text": (
                    self.additional_guide_show_value.isChecked()
                ),
                "show_line": self.additional_guide_line.isChecked(),
                "color_index": self.additional_guide_color.currentData() or 0,
                "text_color_mode": (
                    self.additional_guide_text_color.currentData() or "auto"
                ),
                "text": self.additional_guide_text.toPlainText(),
                "text_side": committed_position(
                    "text_side",
                    self.additional_guide_text_side,
                    "left",
                ),
                "vertical_position": committed_position(
                    "vertical_position",
                    self.additional_guide_text_vertical,
                    "aligned",
                ),
                "show_label_background": (
                    self.additional_guide_label_background.isChecked()
                ),
            }
        )
        guides[row] = guide
        self._store_additional_guides(axis_key, guides)
        self._loading_additional_guides = True
        try:
            self._set_additional_guide_table_row(row, guide)
        finally:
            self._loading_additional_guides = False

    @staticmethod
    def _xy_series_style_fields() -> tuple[str, ...]:
        return (
            "show_points",
            "show_line",
            "marker",
            "line_style",
            "point_size",
            "point_alpha",
            "line_width",
        )

    def _xy_style_selection(self) -> tuple[str, list[XYSeriesSpec]]:
        if (
            not self._is_xy_sheet()
            or self._selected_plot_object_kind != "points"
            or self.canvas is None
        ):
            return ("all", self._xy_user_series() if self._is_xy_sheet() else [])

        series = self._xy_user_series()
        series_by_id = {item.id: item for item in series}
        legacy_series_id = getattr(self.canvas, "_selected_series_id", None)
        scope = getattr(self.canvas, "_xy_selection_scope", None)
        raw_ids = getattr(self.canvas, "_selected_series_ids", ())
        selected_ids = {
            str(series_id)
            for series_id in (raw_ids or ())
            if str(series_id) in series_by_id
        }
        # Compatibility with projects/tests that still set the previous
        # single-series attribute directly while the canvas API is rolling out.
        if legacy_series_id is not None and str(legacy_series_id) in series_by_id:
            if scope != "subset" or not selected_ids:
                scope = "subset"
                selected_ids = {str(legacy_series_id)}
        if scope != "subset":
            return ("all", series)
        return (
            "subset",
            [item for item in series if item.id in selected_ids],
        )

    def _selected_xy_style_series(self) -> XYSeriesSpec | None:
        scope, series = self._xy_style_selection()
        return series[0] if scope == "subset" and len(series) == 1 else None

    @staticmethod
    def _resolved_xy_style_value(
        xy_settings: XYSettings,
        series: XYSeriesSpec,
        field: str,
    ) -> object:
        override = getattr(series, field, None)
        return getattr(xy_settings, field) if override is None else override

    def _xy_series_selection_ids(self) -> tuple[str, ...]:
        scope, selected_series = self._xy_style_selection()
        if scope == "all":
            return tuple(item.id for item in self._xy_user_series())
        return tuple(item.id for item in selected_series)

    @staticmethod
    def _qcolor_from_plot_value(value) -> QColor:
        if isinstance(value, str):
            return QColor(value)
        try:
            channels = np.asarray(value, dtype=float).reshape(-1)
        except (TypeError, ValueError):
            return QColor()
        if channels.size < 3:
            return QColor()
        alpha = float(channels[3]) if channels.size >= 4 else 1.0
        return QColor.fromRgbF(
            float(channels[0]),
            float(channels[1]),
            float(channels[2]),
            alpha,
        )

    def _canvas_xy_series_color(self, series_id: str) -> QColor:
        if self.canvas is None:
            return QColor()
        for target in getattr(self.canvas, "_interaction_targets", ()):
            if (
                target.get("kind") != "points"
                or target.get("source") != "plot"
                or str(target.get("series_id")) != series_id
            ):
                continue
            artist = target.get("artist")
            if artist is None:
                continue
            if hasattr(artist, "get_color"):
                color = self._qcolor_from_plot_value(artist.get_color())
                if color.isValid():
                    return color
            for getter_name in ("get_facecolors", "get_edgecolors"):
                getter = getattr(artist, getter_name, None)
                if not callable(getter):
                    continue
                colors = getter()
                if len(colors):
                    color = self._qcolor_from_plot_value(colors[0])
                    if color.isValid():
                        return color
        return QColor()

    def _xy_series_color_icon(self, series: XYSeriesSpec, index: int) -> QIcon:
        preset = PRESETS.get(self.settings.preset, PRESETS["Paper Clean"])
        palette = list(preset.get("palette", ())) or ["#4E79A7"]
        color = self._canvas_xy_series_color(series.id)
        if not color.isValid():
            color = QColor(series.color or palette[index % len(palette)])
        if not color.isValid():
            color = QColor("#4E79A7")
        pixmap = QPixmap(12, 12)
        pixmap.fill(color)
        return QIcon(pixmap)

    def _refresh_xy_series_selection_list(self) -> None:
        if not hasattr(self, "xy_series_selection_list"):
            return
        if not self._is_xy_sheet():
            self.xy_series_selection_panel.hide()
            return
        self.xy_series_selection_panel.show()
        series = self._xy_user_series()
        labels = self._xy_series_labels()
        scope, selected_series = self._xy_style_selection()
        selected_ids = (
            {item.id for item in series}
            if scope == "all"
            else {item.id for item in selected_series}
        )
        if self._xy_series_selection_anchor_id not in {
            item.id for item in series
        }:
            self._xy_series_selection_anchor_id = None
        scroll_bar = self.xy_series_selection_list.verticalScrollBar()
        previous_scroll_value = scroll_bar.value()
        self._syncing_xy_series_selection_list = True
        blocked = self.xy_series_selection_list.blockSignals(True)
        try:
            self.xy_series_selection_list.clear()
            muted = self.palette().color(
                QPalette.ColorGroup.Disabled,
                QPalette.ColorRole.Text,
            )
            for index, series_item in enumerate(series):
                item = QListWidgetItem(
                    self._xy_series_color_icon(series_item, index),
                    labels.get(series_item.id, series_item.name),
                )
                item.setData(Qt.ItemDataRole.UserRole, series_item.id)
                item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled
                    | Qt.ItemFlag.ItemIsUserCheckable
                )
                item.setCheckState(
                    Qt.CheckState.Checked
                    if series_item.id in selected_ids
                    else Qt.CheckState.Unchecked
                )
                if not series_item.visible:
                    item.setForeground(QBrush(muted))
                    font = item.font()
                    font.setItalic(True)
                    item.setFont(font)
                    item.setToolTip(self.tr("Hidden series"))
                self.xy_series_selection_list.addItem(item)
        finally:
            self.xy_series_selection_list.blockSignals(blocked)
            self._syncing_xy_series_selection_list = False
        scroll_bar.setValue(
            max(
                scroll_bar.minimum(),
                min(previous_scroll_value, scroll_bar.maximum()),
            )
        )

        selected_count = len(selected_ids)
        total = len(series)
        self.xy_series_selection_count_label.setText(
            self.tr("Selected {selected}/{total}").format(
                selected=selected_count,
                total=total,
            )
        )
        self.ui.xySeriesSelectAllButton.setEnabled(total > 0)
        self.ui.xySeriesClearSelectionButton.setEnabled(selected_count > 0)
        self.ui.xySeriesInvertSelectionButton.setEnabled(total > 0)
        self.xy_no_series_selected_label.setVisible(
            scope == "subset" and selected_count == 0
        )

    def _set_xy_series_selection(self, scope: str, series_ids) -> None:
        if not self._is_xy_sheet() or self.canvas is None:
            return
        requested_ids = {str(series_id) for series_id in series_ids}
        ordered_ids = tuple(
            item.id
            for item in self._xy_user_series()
            if item.id in requested_ids
        )
        setter = getattr(self.canvas, "set_xy_series_selection", None)
        if callable(setter):
            setter(scope, ordered_ids)
            return
        self.canvas._selected_object_kind = "points"
        self.canvas._xy_selection_scope = scope
        self.canvas._selected_series_ids = ordered_ids
        self.canvas._selected_series_id = (
            ordered_ids[0]
            if scope == "subset" and len(ordered_ids) == 1
            else None
        )
        feedback = getattr(
            self.canvas,
            "_set_xy_series_selection_feedback",
            None,
        )
        if callable(feedback):
            feedback()
        # Keep compatibility with a lightweight/test canvas that predates the
        # public setter and therefore cannot invoke selection_callback itself.
        self._selected_plot_object_kind = "points"
        self._apply_xy_series_style_scope_to_controls()
        self._update_inspector_context("points")
        self._apply_inspector_focus("points")
        self._update_dependent_control_states()

    def _handle_xy_series_selection_item_changed(
        self,
        _changed_item: QListWidgetItem,
    ) -> None:
        if self._syncing_xy_series_selection_list:
            return
        selected_ids = [
            str(item.data(Qt.ItemDataRole.UserRole))
            for index in range(self.xy_series_selection_list.count())
            if (item := self.xy_series_selection_list.item(index)).checkState()
            == Qt.CheckState.Checked
        ]
        self._set_xy_series_selection("subset", selected_ids)

    def _handle_xy_series_selection_mouse_press(self, event) -> bool:
        if event.button() != Qt.MouseButton.LeftButton:
            return False
        position = (
            event.position().toPoint()
            if hasattr(event, "position")
            else event.pos()
        )
        clicked_item = self.xy_series_selection_list.itemAt(position)
        if clicked_item is None:
            return False
        clicked_id = str(
            clicked_item.data(Qt.ItemDataRole.UserRole)
        )
        items = [
            self.xy_series_selection_list.item(index)
            for index in range(self.xy_series_selection_list.count())
        ]
        selected_ids = {
            str(item.data(Qt.ItemDataRole.UserRole))
            for item in items
            if item.checkState() == Qt.CheckState.Checked
        }
        make_checked = clicked_item.checkState() != Qt.CheckState.Checked
        shift_pressed = bool(
            event.modifiers() & Qt.KeyboardModifier.ShiftModifier
        )
        if shift_pressed:
            ids = [
                str(item.data(Qt.ItemDataRole.UserRole))
                for item in items
            ]
            anchor_id = self._xy_series_selection_anchor_id
            if anchor_id not in ids:
                anchor_id = clicked_id
                self._xy_series_selection_anchor_id = clicked_id
            anchor_index = ids.index(anchor_id)
            clicked_index = ids.index(clicked_id)
            start, end = sorted((anchor_index, clicked_index))
            range_ids = set(ids[start : end + 1])
            if make_checked:
                selected_ids.update(range_ids)
            else:
                selected_ids.difference_update(range_ids)
        else:
            self._xy_series_selection_anchor_id = clicked_id
            if make_checked:
                selected_ids.add(clicked_id)
            else:
                selected_ids.discard(clicked_id)
        self._set_xy_series_selection("subset", selected_ids)
        return True

    def _select_all_xy_series_globally(self) -> None:
        self._xy_series_selection_anchor_id = None
        self._set_xy_series_selection("all", ())

    def _clear_xy_series_selection(self) -> None:
        self._xy_series_selection_anchor_id = None
        self._set_xy_series_selection("subset", ())

    def _invert_xy_series_selection(self) -> None:
        self._xy_series_selection_anchor_id = None
        selected_ids = set(self._xy_series_selection_ids())
        self._set_xy_series_selection(
            "subset",
            [
                item.id
                for item in self._xy_user_series()
                if item.id not in selected_ids
            ],
        )

    def _xy_style_control_values(self) -> dict[str, object]:
        return {
            "show_points": self.show_points.isChecked(),
            "show_line": self.xy_show_line.isChecked(),
            "marker": self.xy_marker.currentText(),
            "line_style": self.xy_line_style.currentText(),
            "point_size": self.point_size.value(),
            "point_alpha": self.point_alpha.value(),
            "line_width": self.xy_line_width.value(),
        }

    def _xy_style_control_for_field(self, field: str) -> QWidget:
        return {
            "show_points": self.show_points,
            "show_line": self.xy_show_line,
            "marker": self.xy_marker,
            "line_style": self.xy_line_style,
            "point_size": self.point_size,
            "point_alpha": self.point_alpha,
            "line_width": self.xy_line_width,
        }[field]

    def _xy_style_field_for_sender(self, sender: object | None) -> str | None:
        for field in self._xy_series_style_fields():
            if sender is self._xy_style_control_for_field(field):
                return field
        return None

    def _set_xy_style_controls(
        self,
        values: dict[str, object],
        mixed_fields: set[str] | None = None,
    ) -> None:
        mixed_fields = set(mixed_fields or ())
        self._xy_mixed_style_fields = mixed_fields
        self._xy_mixed_spin_edits.clear()
        controls = {
            field: self._xy_style_control_for_field(field)
            for field in self._xy_series_style_fields()
        }
        for field, value in values.items():
            control = controls[field]
            blocked = control.blockSignals(True)
            try:
                mixed = field in mixed_fields
                if isinstance(control, QCheckBox):
                    control.setTristate(mixed)
                    control.setCheckState(
                        Qt.CheckState.PartiallyChecked
                        if mixed
                        else (
                            Qt.CheckState.Checked
                            if bool(value)
                            else Qt.CheckState.Unchecked
                        )
                    )
                elif isinstance(control, QComboBox):
                    mixed_index = control.findData(XY_MIXED_COMBO_DATA)
                    if mixed:
                        if mixed_index < 0:
                            control.insertItem(
                                0,
                                self.tr("Mixed"),
                                XY_MIXED_COMBO_DATA,
                            )
                            mixed_index = 0
                        control.setCurrentIndex(mixed_index)
                    else:
                        if mixed_index >= 0:
                            control.removeItem(mixed_index)
                        control.setCurrentText(str(value))
                elif isinstance(control, QDoubleSpinBox):
                    minimum_attribute = "_easygraph_xy_style_minimum"
                    special_text_attribute = "_easygraph_xy_style_special_text"
                    if not hasattr(control, minimum_attribute):
                        setattr(control, minimum_attribute, control.minimum())
                        setattr(
                            control,
                            special_text_attribute,
                            control.specialValueText(),
                        )
                    normal_minimum = float(
                        getattr(control, minimum_attribute)
                    )
                    if mixed:
                        sentinel = normal_minimum - max(
                            abs(float(control.singleStep())),
                            10.0 ** (-control.decimals()),
                        )
                        control.setMinimum(sentinel)
                        control.setSpecialValueText(self.tr("Mixed"))
                        control.setValue(sentinel)
                    else:
                        control.setSpecialValueText(
                            str(getattr(control, special_text_attribute))
                        )
                        control.setMinimum(normal_minimum)
                        control.setValue(float(value))
            finally:
                control.blockSignals(blocked)

    def _set_xy_style_controls_enabled(self, enabled: bool) -> None:
        for label, control in (
            (self.ui.showPointsLabel, self.show_points),
            (self.ui.xyShowLineLabel, self.xy_show_line),
            (self.ui.xyMarkerLabel, self.xy_marker),
            (self.ui.pointSizeLabel, self.point_size),
            (self.ui.pointAlphaLabel, self.point_alpha),
            (self.ui.xyLineWidthLabel, self.xy_line_width),
            (self.ui.xyLineStyleLabel, self.xy_line_style),
        ):
            label.setEnabled(enabled)
            control.setEnabled(enabled)

    def _xy_mixed_spin_input_is_explicit(self, field: str) -> bool:
        """Return whether a mixed spin box contains a user-provided value."""
        if field not in self._xy_mixed_style_fields:
            return True
        control = self._xy_style_control_for_field(field)
        if not isinstance(control, QDoubleSpinBox):
            return True
        text = control.lineEdit().text().strip()
        special_text = control.specialValueText().strip()
        normal_minimum = float(
            getattr(
                control,
                "_easygraph_xy_style_minimum",
                control.minimum(),
            )
        )
        value = float(control.value())
        return (
            bool(text)
            and (not special_text or text != special_text)
            and math.isfinite(value)
            and value >= normal_minimum
        )

    def _restore_unedited_xy_mixed_spin(self, field: str) -> None:
        self._xy_mixed_spin_edits.discard(field)
        self._apply_xy_series_style_scope_to_controls()
        self._update_dependent_control_states()

    def _commit_mixed_xy_spin_field(self, field: str) -> None:
        if (
            field not in self._xy_mixed_style_fields
            or field not in self._xy_mixed_spin_edits
        ):
            return
        if not self._xy_mixed_spin_input_is_explicit(field):
            self._restore_unedited_xy_mixed_spin(field)
            return
        self._xy_mixed_spin_edits.discard(field)
        scope, selected_series = self._xy_style_selection()
        if scope != "subset" or not selected_series:
            return
        value = self._xy_style_control_for_field(field).value()
        self._set_selected_xy_series_style_values(selected_series, field, value)
        self._apply_xy_series_style_scope_to_controls()
        self._update_dependent_control_states()
        self._record_recovery_sheet_state()
        self.schedule_render(RenderMode.FULL)

    def _apply_xy_series_style_scope_to_controls(self) -> None:
        if not hasattr(self, "use_all_series_style_button"):
            return
        if not self._is_xy_sheet():
            self.xy_series_selection_panel.hide()
            self.use_all_series_style_button.hide()
            return
        xy_settings = self.workbook.active_sheet.xy_settings
        scope, selected_series = self._xy_style_selection()
        mixed_fields: set[str] = set()
        if scope == "all" or not selected_series:
            values = {
                field: getattr(xy_settings, field)
                for field in self._xy_series_style_fields()
            }
        else:
            values = {}
            for field in self._xy_series_style_fields():
                resolved = [
                    self._resolved_xy_style_value(xy_settings, series, field)
                    for series in selected_series
                ]
                values[field] = resolved[0]
                if any(value != resolved[0] for value in resolved[1:]):
                    mixed_fields.add(field)
        self._set_xy_style_controls(values, mixed_fields)
        has_targets = scope == "all" or bool(selected_series)
        self._set_xy_style_controls_enabled(has_targets)
        subset_scope = scope == "subset"
        self.use_all_series_style_button.setVisible(subset_scope)
        self.use_all_series_style_button.setEnabled(bool(selected_series))
        self._refresh_xy_series_selection_list()

    def reset_selected_xy_series_style(self) -> None:
        scope, selected_series = self._xy_style_selection()
        if scope != "subset" or not selected_series:
            return
        xy_settings = self.workbook.active_sheet.xy_settings
        selected_ids = {series.id for series in selected_series}
        candidate = deepcopy(xy_settings)
        for series in candidate.series:
            if series.id not in selected_ids:
                continue
            for field in self._xy_series_style_fields():
                setattr(series, field, None)
            series.color = None
        candidate.__post_init__()
        for series in selected_series:
            for field in self._xy_series_style_fields():
                setattr(series, field, None)
            series.color = None
        xy_settings.__post_init__()
        self._apply_xy_series_style_scope_to_controls()
        self._update_dependent_control_states()
        self._record_recovery_sheet_state()
        self.schedule_render(RenderMode.FULL)

    def _normalize_xy_series_display_after_style_change(
        self,
        changed_field: str | None,
        series: XYSeriesSpec | None,
    ) -> None:
        xy_settings = self.workbook.active_sheet.xy_settings
        if not xy_settings.show_points and not xy_settings.show_line:
            fallback_field = (
                "show_line"
                if changed_field in (None, "show_points")
                else "show_points"
            )
            setattr(xy_settings, fallback_field, True)
            self._set_xy_style_controls(
                {fallback_field: getattr(xy_settings, fallback_field)}
            )

        if series is not None:
            resolved_points = (
                xy_settings.show_points
                if series.show_points is None
                else series.show_points
            )
            resolved_line = (
                xy_settings.show_line
                if series.show_line is None
                else series.show_line
            )
            if series.visible and not resolved_points and not resolved_line:
                fallback_field = (
                    "show_line" if changed_field == "show_points" else "show_points"
                )
                setattr(series, fallback_field, True)
                self._set_xy_style_controls({fallback_field: True})
        else:
            for candidate in xy_settings.series:
                resolved_points = (
                    xy_settings.show_points
                    if candidate.show_points is None
                    else candidate.show_points
                )
                resolved_line = (
                    xy_settings.show_line
                    if candidate.show_line is None
                    else candidate.show_line
                )
                if resolved_points or resolved_line:
                    continue
                if xy_settings.show_points:
                    candidate.show_points = None
                else:
                    candidate.show_line = None
        xy_settings.__post_init__()

    def _set_xy_all_series_style_value(self, field: str, value: object) -> None:
        xy_settings = self.workbook.active_sheet.xy_settings
        setattr(xy_settings, field, value)
        for series in xy_settings.series:
            setattr(series, field, None)
        self._normalize_xy_series_display_after_style_change(field, None)

    def _set_selected_xy_series_style_value(
        self,
        series: XYSeriesSpec,
        field: str,
        value: object,
    ) -> None:
        self._set_selected_xy_series_style_values([series], field, value)

    def _set_selected_xy_series_style_values(
        self,
        selected_series: list[XYSeriesSpec],
        field: str,
        value: object,
    ) -> None:
        if not selected_series:
            return
        xy_settings = self.workbook.active_sheet.xy_settings
        selected_ids = {series.id for series in selected_series}
        candidate = deepcopy(xy_settings)
        candidate_by_id = {series.id: series for series in candidate.series}
        for series_id in selected_ids:
            series = candidate_by_id.get(series_id)
            if series is None:
                continue
            setattr(series, field, value)
            if field not in {"show_points", "show_line"}:
                continue
            resolved_points = self._resolved_xy_style_value(
                candidate,
                series,
                "show_points",
            )
            resolved_line = self._resolved_xy_style_value(
                candidate,
                series,
                "show_line",
            )
            if resolved_points or resolved_line:
                continue
            fallback_field = (
                "show_line" if field == "show_points" else "show_points"
            )
            setattr(series, fallback_field, True)
        candidate.__post_init__()

        validated_by_id = {series.id: series for series in candidate.series}
        copied_fields = {field}
        if field in {"show_points", "show_line"}:
            copied_fields.update({"show_points", "show_line"})
        for series in selected_series:
            validated = validated_by_id[series.id]
            for copied_field in copied_fields:
                setattr(series, copied_field, getattr(validated, copied_field))
        xy_settings.__post_init__()

    def clear_plot_object_selection(self) -> None:
        if self.canvas is not None and (
            self.canvas._selected_object_kind is not None
            or bool(getattr(self.canvas, "_xy_box_select_enabled", False))
            or getattr(self.canvas, "_xy_box_select_state", None) is not None
        ):
            self.canvas.clear_plot_selection()
            return
        self.handle_plot_object_selection(None)

    def handle_legend_drag_position(self, x: float, y: float) -> None:
        self.settings.legend_position = LEGEND_POSITION_INSIDE
        self.settings.legend_inside_x = min(max(float(x), 0.0), 1.0)
        self.settings.legend_inside_y = min(max(float(y), 0.0), 1.0)
        self._record_recovery_settings()
        self.render()

    def handle_fit_equation_drag_position(
        self,
        fit_id: str,
        x: float | None,
        y: float | None,
    ) -> None:
        """Persist a dragged fit-equation label, or reset it to auto layout."""

        if not self._is_xy_sheet():
            return
        fit_spec = next(
            (
                candidate
                for candidate in self.workbook.active_sheet.xy_settings.fit_specs
                if candidate.id == str(fit_id)
            ),
            None,
        )
        if fit_spec is None:
            return
        if x is None or y is None:
            position = (None, None)
        else:
            try:
                normalized = (float(x), float(y))
            except (TypeError, ValueError, OverflowError):
                return
            if not all(math.isfinite(value) for value in normalized):
                return
            position = tuple(
                min(max(value, 0.0), 1.0) for value in normalized
            )
        if (
            fit_spec.equation_position_x,
            fit_spec.equation_position_y,
        ) == position:
            return
        (
            fit_spec.equation_position_x,
            fit_spec.equation_position_y,
        ) = position
        self.workbook.active_sheet.xy_settings.__post_init__()
        self._record_recovery_sheet_state()
        self.render()

    def _section_for_plot_object(self, object_kind: str | None) -> QWidget | None:
        if object_kind == "legend":
            return self.legend_group
        if object_kind == "stats_table":
            return self.ui.statsTableGroup
        if object_kind in {"axis", "category_axis"}:
            return self.ui.categoryAxisGroup
        if object_kind == "primary_axis":
            return self.ui.primaryAxisGroup
        if object_kind == "secondary_axis":
            return self.ui.secondaryAxisGroup
        if object_kind in {"chart_title", "title_axis"}:
            return self.ui.titleAxisGroup
        if object_kind == "plot_area":
            if self._is_xy_sheet():
                return None
            return self.ui.specificGroup
        if object_kind == "points":
            return self.ui.pointsGroup
        if object_kind == "outliers":
            return self.ui.outliersGroup
        if object_kind == "line_overlay":
            return self.ui.lineOverlayGroup
        if object_kind == "additional_grid_line":
            return self.ui.additionalGuidesGroup
        return None

    @property
    def _table_history(self):
        return self._active_table_controller().history

    def _main_table_column_ids(self) -> list[str]:
        sheet = self.workbook.active_sheet
        if sheet.mode == SHEET_MODE_XY:
            return list(self._active_xy_shared_column_ids)
        return list(sheet.column_ids)

    def _active_table_controller(self) -> TableController:
        focus = QApplication.focusWidget()
        if (
            focus is self.xy_independent_table
            or self.xy_independent_table.isAncestorOf(focus)
        ):
            return self._xy_paired_controller
        if focus is not self.table and not self.table.isAncestorOf(focus):
            table_tools = getattr(self, "table_tools", None)
            if table_tools is not None and table_tools.active_table is self.xy_independent_table:
                return self._xy_paired_controller
        return self._table_controller

    def _controller_for_table(self, table) -> TableController:
        return (
            self._xy_paired_controller
            if table is self.xy_independent_table
            else self._table_controller
        )

    def _apply_custom_table_history_action_state(
        self,
        _can_undo: bool,
        _can_redo: bool,
    ) -> None:
        controller = self._active_table_controller()
        self._apply_table_history_action_state(
            controller.history.can_undo,
            controller.history.can_redo,
        )

    @property
    def _table_history_restoring(self) -> bool:
        return self._active_table_controller().history_restoring

    @_table_history_restoring.setter
    def _table_history_restoring(self, value: bool) -> None:
        self._active_table_controller().history_restoring = value

    @property
    def _table_history_suspended(self) -> bool:
        return self._active_table_controller().history_suspended

    @_table_history_suspended.setter
    def _table_history_suspended(self, value: bool) -> None:
        self._active_table_controller().history_suspended = value

    @property
    def _table_undo_stack(self) -> list[dict]:
        return self._table_history.undo_stack

    @_table_undo_stack.setter
    def _table_undo_stack(self, value: list[dict]) -> None:
        self._table_history.undo_stack = value

    @property
    def _table_redo_stack(self) -> list[dict]:
        return self._table_history.redo_stack

    @_table_redo_stack.setter
    def _table_redo_stack(self, value: list[dict]) -> None:
        self._table_history.redo_stack = value

    def _create_checklist_filter_dialog(self, title: str) -> tuple[QDialog, Ui_ChecklistFilterDialog]:
        return create_checklist_filter_dialog(self, title)

    def _create_group_order_dialog(self) -> tuple[QDialog, Ui_GroupOrderDialog]:
        return create_group_order_dialog(self)

    def _create_overlay_styles_dialog(self) -> tuple[QDialog, Ui_OverlayStylesDialog]:
        return create_overlay_styles_dialog(self)

    def _create_group_colors_dialog(self) -> tuple[QDialog, Ui_GroupColorsDialog]:
        return create_group_colors_dialog(self)

    def _inspector_groups(self) -> list[QGroupBox]:
        return [
            self.ui.titleAxisGroup,
            self.ui.categoryAxisGroup,
            self.ui.primaryAxisGroup,
            self.ui.additionalGuidesGroup,
            self.ui.axesAppearanceGroup,
            self.ui.secondaryAxisGroup,
            self.ui.pointsGroup,
            self.ui.outliersGroup,
            self.ui.lineOverlayGroup,
            self.ui.statsTableGroup,
            self.ui.specificGroup,
            self.legend_group,
        ]

    def _inspector_groups_for_plot_object(self, object_kind: str | None) -> set[QGroupBox] | None:
        if object_kind is None:
            return None
        if object_kind == "plot_area":
            if self._is_xy_sheet():
                return None
            return {self.ui.specificGroup}
        if object_kind == "points":
            return {self.ui.pointsGroup}
        if object_kind == "outliers":
            return {self.ui.outliersGroup}
        if object_kind == "line_overlay":
            return {self.ui.lineOverlayGroup}
        if object_kind == "additional_grid_line":
            return {self.ui.additionalGuidesGroup}
        if object_kind == "axis":
            return {
                self.ui.categoryAxisGroup,
                self.ui.primaryAxisGroup,
                self.ui.secondaryAxisGroup,
                self.ui.axesAppearanceGroup,
            }
        if object_kind == "category_axis":
            return {self.ui.categoryAxisGroup, self.ui.axesAppearanceGroup}
        if object_kind == "primary_axis":
            return {self.ui.primaryAxisGroup, self.ui.axesAppearanceGroup}
        if object_kind == "secondary_axis":
            return {self.ui.secondaryAxisGroup, self.ui.axesAppearanceGroup}
        if object_kind in {"chart_title", "title_axis"}:
            return {self.ui.titleAxisGroup}
        if object_kind == "stats_table":
            return {self.ui.statsTableGroup}
        if object_kind == "legend":
            return {self.legend_group}
        return None

    def _is_xy_sheet(self) -> bool:
        return self.workbook.active_sheet.mode == SHEET_MODE_XY

    def _selected_additional_guides_axis_key(self) -> str | None:
        if self._selected_plot_object_kind == "additional_grid_line":
            return self._last_additional_guides_axis_key
        if self._selected_plot_object_kind == "primary_axis":
            return "primary"
        if (
            self._selected_plot_object_kind == "category_axis"
            and self._is_xy_sheet()
        ):
            return "x"
        if self._selected_plot_object_kind is None:
            if self._is_xy_sheet() and self._last_additional_guides_axis_key == "x":
                return "x"
            return "primary"
        return None

    def _mode_inspector_groups(self) -> set[QGroupBox]:
        if not self._is_xy_sheet():
            return set(self._inspector_groups())
        return {
            self.ui.titleAxisGroup,
            self.ui.categoryAxisGroup,
            self.ui.primaryAxisGroup,
            self.ui.additionalGuidesGroup,
            self.ui.axesAppearanceGroup,
            self.ui.pointsGroup,
            self.legend_group,
        }

    def _apply_inspector_focus(self, object_kind: str | None) -> None:
        visible_groups = self._inspector_groups_for_plot_object(object_kind)
        mode_groups = self._mode_inspector_groups()
        if visible_groups is not None and not (visible_groups & mode_groups):
            visible_groups = None
        for group in self._inspector_groups():
            if group is self.ui.additionalGuidesGroup:
                group.setVisible(
                    self._selected_additional_guides_axis_key() is not None
                )
                continue
            group.setVisible(
                group in mode_groups
                and (visible_groups is None or group in visible_groups)
            )

    @staticmethod
    def _set_form_row_visible(form: QFormLayout, label: QWidget, control: QWidget, visible: bool) -> None:
        if hasattr(form, "setRowVisible"):
            form.setRowVisible(label, visible)
        else:
            label.setVisible(visible)
            control.setVisible(visible)

    @staticmethod
    def _set_combo_items(combo: QComboBox, items: list[str], current: str) -> None:
        existing = [combo.itemText(index) for index in range(combo.count())]
        signals_blocked = combo.blockSignals(True)
        try:
            if existing != items:
                combo.clear()
                combo.addItems(items)
            combo.setCurrentText(current if current in items else items[0])
        finally:
            combo.blockSignals(signals_blocked)

    def _apply_sheet_mode_ui(self) -> None:
        is_xy = self._is_xy_sheet()
        chart_types = [self.tr("XY")] if is_xy else ["Box", "Bar", "Violin", "Ridge"]
        chart_type = chart_types[0] if is_xy else self.settings.chart_type
        if is_xy:
            self.settings.chart_type = "Scatter"
        if chart_type not in chart_types:
            chart_type = chart_types[0]
            self.settings.chart_type = chart_type
        self._set_combo_items(self.chart_type, chart_types, chart_type)
        self.chart_type.setEnabled(not is_xy)
        order_modes = [
            "Table order",
            "Manual",
            "Name A-Z",
            "Name Z-A",
        ]
        if not is_xy:
            order_modes.extend(
                [
                    "Mean ascending",
                    "Mean descending",
                    "Median ascending",
                    "Median descending",
                ]
            )
        if self.settings.group_order not in order_modes:
            self.settings.group_order = "Table order"
        self._set_combo_items(
            self.group_order,
            order_modes,
            self.settings.group_order,
        )

        self.group_filter_button.setText(
            self.tr("Series Filter") if is_xy else self.tr("Group Filter")
        )
        self.group_filter_button.setToolTip(self.group_filter_button.text())
        self.group_filter_button.setAccessibleName(self.group_filter_button.text())
        self.ui.editGroupOrderButton.setText(
            self.tr("Edit")
        )
        order_hint = self.tr("Edit Series Order") if is_xy else self.tr("Edit Group Order")
        self.ui.editGroupOrderButton.setToolTip(order_hint)
        self.ui.editGroupOrderButton.setAccessibleName(order_hint)
        self.ui.pointsGroup.setTitle(
            self.tr("Series Style") if is_xy else self.tr("Data Points")
        )
        self.ui.templateToolbarLabel.setText(
            self.tr("XY Style Templates")
            if is_xy
            else self.tr("Groups Style Templates")
        )
        self.ui.templateToolbarLabel.setToolTip(
            self.tr("Templates available for XY sheets")
            if is_xy
            else self.tr("Templates available for Groups sheets")
        )
        self.ui.xLabelLabel.setText(
            self.tr("X axis title") if is_xy else self.tr("Category axis title")
        )
        self.ui.yLabelLabel.setText(
            self.tr("Y axis title")
            if is_xy
            else self.tr("Primary value axis title")
        )
        self.ui.showPointsLabel.setText(
            self.tr("Show points") if is_xy else self.tr("Show all points")
        )
        self.ui.xySharedTitleLabel.setText(self.tr("Shared X"))
        self.ui.xyIndependentTitleLabel.setText(self.tr("Independent XY"))
        for widget in (
            self.ui.xySharedTitleLabel,
            self.ui.xySharedTabBar,
            self.ui.addXYSharedTableButton,
            self.ui.removeXYSharedTableButton,
            self.ui.xyIndependentTitleLabel,
        ):
            widget.setVisible(is_xy)
        section_frame_shape = (
            QFrame.Shape.StyledPanel if is_xy else QFrame.Shape.NoFrame
        )
        self.ui.xySharedFrame.setFrameShape(section_frame_shape)
        self.ui.xyIndependentFrame.setFrameShape(section_frame_shape)
        top_frame = self.ui.xyIndependentFrame if is_xy else self.ui.xySharedFrame
        order_changed = self.ui.dataResultsSplitter.indexOf(top_frame) != 0
        if order_changed:
            self.ui.dataResultsSplitter.insertWidget(0, top_frame)
        if is_xy:
            self.ui.dataResultsSplitter.setStretchFactor(0, 1)
            self.ui.dataResultsSplitter.setStretchFactor(1, 1)
            if order_changed:
                self.ui.dataResultsSplitter.setSizes([1, 1])
        else:
            self.ui.dataResultsSplitter.setStretchFactor(0, 3)
            self.ui.dataResultsSplitter.setStretchFactor(1, 1)
            if order_changed:
                self.ui.dataResultsSplitter.setSizes([620, 300])
        self.ui.resultsTitleLabel.setVisible(not is_xy)
        self.ui.analysisNumberFormatsButton.setVisible(not is_xy)
        self.results_table.setVisible(not is_xy)
        self.xy_independent_table.setVisible(is_xy)

        for widget in (
            self.add_overlay_button,
            self.remove_overlay_button,
            self.custom_overlay_filter_button,
            self.ui.copyStatisticsButton,
        ):
            widget.setVisible(not is_xy)
        self.curve_fit_button.setVisible(is_xy)

        self._set_form_row_visible(
            self.ui.pointsForm,
            self.ui.jitterModeLabel,
            self.jitter_mode,
            not is_xy,
        )
        self._set_form_row_visible(
            self.ui.pointsForm,
            self.ui.jitterLabel,
            self.jitter,
            not is_xy,
        )
        for label, control in (
            (self.ui.xyMarkerLabel, self.xy_marker),
            (self.ui.xyShowLineLabel, self.xy_show_line),
            (self.ui.xyLineWidthLabel, self.xy_line_width),
            (self.ui.xyLineStyleLabel, self.xy_line_style),
        ):
            self._set_form_row_visible(
                self.ui.pointsForm,
                label,
                control,
                is_xy,
            )

        for label, control in (
            (self.ui.autoXRangeLabel, self.auto_x_range),
            (self.ui.xMinLabel, self.x_min),
            (self.ui.xMaxLabel, self.x_max),
            (self.ui.xAutoTickIntervalLabel, self.x_auto_tick_interval),
            (self.ui.xTickIntervalLabel, self.x_tick_interval),
        ):
            self._set_form_row_visible(
                self.ui.categoryAxisForm,
                label,
                control,
                is_xy,
            )
        self._set_form_row_visible(
            self.ui.categoryAxisForm,
            self.ui.xRotationLabel,
            self.x_tick_rotation,
            not is_xy,
        )

        distribution_chart_actions = {
            "stats_table",
            "outliers",
            "summary_none",
            "summary_median",
            "summary_mean",
            "add_custom_overlay",
            "custom_overlay",
            "secondary_axis",
            "split_secondary_axis",
            "line_values",
        }
        for key in distribution_chart_actions:
            action = self.chart_element_actions.get(key)
            if action is not None:
                action.setVisible(not is_xy)
        lines_action = self.chart_element_actions.get("lines")
        if lines_action is not None:
            lines_action.setVisible(is_xy)
        points_action = self.chart_element_actions.get("points")
        if points_action is not None:
            points_action.setText(
                self.tr("Series Points") if is_xy else self.tr("Data Points")
            )
        self.xy_series_selection_panel.setVisible(is_xy)
        if not is_xy:
            self.use_all_series_style_button.hide()
        self._apply_inspector_focus(self._selected_plot_object_kind)
        self._update_contextual_font_slots()

    def _polish_inspector_groups(self) -> None:
        self.ui.controlsLayout.setAlignment(Qt.AlignTop)
        self.ui.inspectorShowAllButton.setFixedHeight(APP_CONTROL_HEIGHT)
        for group in self._inspector_groups():
            group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)

    def _bind_ui_widgets(self) -> None:
        self.sheet_tab_bar = self.ui.sheetTabBar
        self.sheet_menu_button = self.ui.sheetMenuButton
        self.template_combo = self.ui.templateCombo
        self.chart_type = self.ui.chartTypeCombo
        self.preset = self.ui.presetCombo
        self.group_order = self.ui.groupOrderCombo
        self.group_filter_button = self.ui.groupFilterButton
        self.edit_group_colors_button = self.ui.editGroupColorsButton
        self.curve_fit_button = self.ui.curveFitButton
        self.title = self.ui.titleEdit
        self.x_label = self.ui.xLabelEdit
        self.y_label = self.ui.yLabelEdit
        self.secondary_y_label_label = self.ui.secondaryYLabelLabel
        self.secondary_y_label = self.ui.secondaryYLabelEdit
        self.secondary_y_label.setPlainText(self.settings.secondary_y_label)
        self.width = self.ui.widthSpin
        self.height = self.ui.heightSpin
        self.dpi = self.ui.dpiSpin
        self.transparent_background = self.ui.transparentBackgroundCheck
        self.title_font_size = self.ui.titleFontSizeSpin
        self.axis_label_font_size = self.ui.axisLabelFontSizeSpin
        self.tick_font_size = self.ui.tickFontSizeSpin
        self.additional_guide_font_size_label = (
            self.ui.additionalGuideFontSizeLabel
        )
        self.additional_guide_font_size = self.ui.additionalGuideFontSizeSpin
        self.decrease_all_fonts_button = self.ui.decreaseAllFontsButton
        self.increase_all_fonts_button = self.ui.increaseAllFontsButton
        self.legend_font_size = self.ui.legendFontSizeSpin
        self.legend_group = self.ui.legendGroup
        self.legend_form = self.ui.legendForm
        self.show_legend = self.ui.showLegendCheck
        self.show_legend.setChecked(self.settings.show_legend)
        self.legend_position = self.ui.legendPositionCombo
        self.legend_position.addItems([self.tr("Right side"), self.tr("Inside plot")])
        self._set_legend_position_value(self.settings.legend_position)
        self.legend_auto_width = self.ui.legendAutoWidthCheck
        self.legend_auto_width.setChecked(self.settings.legend_auto_width)
        self.legend_width = self.ui.legendWidthSpin
        self.legend_width.setValue(self.settings.legend_width)
        self.legend_columns = self.ui.legendColumnsCombo
        self.legend_columns.addItems([self.tr("Auto"), "1", "2", "3", "4", "5", "6"])
        self.legend_columns.setCurrentText(self.tr("Auto") if self.settings.legend_columns <= 0 else str(self.settings.legend_columns))
        self.line_value_font_size = self.ui.lineValueFontSizeSpin
        self.stat_table_font_size = self.ui.statTableFontSizeSpin
        self.show_grid = self.ui.showGridCheck
        self.auto_x_range_label = self.ui.autoXRangeLabel
        self.auto_x_range = self.ui.autoXRangeCheck
        self.auto_x_range.setChecked(self.settings.auto_x_range)
        self.x_min_label = self.ui.xMinLabel
        self.x_min = self.ui.xMinSpin
        self.x_max_label = self.ui.xMaxLabel
        self.x_max = self.ui.xMaxSpin
        self._set_range_spin_box_values_preserving_range(
            self.x_min,
            self.x_max,
            self.settings.x_min,
            self.settings.x_max,
        )
        self.x_auto_tick_interval_label = self.ui.xAutoTickIntervalLabel
        self.x_auto_tick_interval = self.ui.xAutoTickIntervalCheck
        self.x_auto_tick_interval.setChecked(self.settings.x_auto_tick_interval)
        self.x_tick_interval_label = self.ui.xTickIntervalLabel
        self.x_tick_interval = self.ui.xTickIntervalSpin
        self._set_spin_box_value_preserving_range(
            self.x_tick_interval,
            self.settings.x_tick_interval,
        )
        self.auto_y_range = self.ui.autoYRangeCheck
        self.axis_line_width = self.ui.axisLineWidthSpin
        self.x_tick_rotation = self.ui.xTickRotationSpin
        self.y_min = self.ui.yMinSpin
        self.y_max = self.ui.yMaxSpin
        self.primary_auto_tick_interval_label = self.ui.primaryAutoTickIntervalLabel
        self.primary_auto_tick_interval = self.ui.primaryAutoTickIntervalCheck
        self.primary_auto_tick_interval.setChecked(self.settings.primary_auto_tick_interval)
        self.primary_tick_interval_label = self.ui.primaryTickIntervalLabel
        self.primary_tick_interval = self.ui.primaryTickIntervalSpin
        self.primary_tick_interval.setValue(self.settings.primary_tick_interval)
        self.additional_guide_line_width = self.ui.additionalGuideLineWidthSpin
        self.additional_guides_table = self.ui.additionalGuidesTable
        self.additional_guide_add_button = self.ui.additionalGuideAddButton
        self.additional_guide_delete_button = self.ui.additionalGuideDeleteButton
        self.additional_guide_value = self.ui.additionalGuideValueSpin
        self.additional_guide_tick = self.ui.additionalGuideTickCheck
        self.additional_guide_show_value = (
            self.ui.additionalGuideShowValueCheck
        )
        self.additional_guide_line = self.ui.additionalGuideLineCheck
        self.additional_guide_color = self.ui.additionalGuideColorCombo
        self.additional_guide_text_color = (
            self.ui.additionalGuideTextColorCombo
        )
        self.additional_guide_text = self.ui.additionalGuideTextEdit
        self.additional_guide_text_side = self.ui.additionalGuideTextSideCombo
        self.additional_guide_text_vertical = (
            self.ui.additionalGuideTextVerticalCombo
        )
        self.additional_guide_label_background = (
            self.ui.additionalGuideLabelBackgroundCheck
        )
        self.additional_guides_axis_selector = (
            self.ui.additionalGuidesAxisSelector
        )
        self.additional_guides_x_axis_radio = (
            self.ui.additionalGuidesXAxisRadio
        )
        self.additional_guides_y_axis_radio = (
            self.ui.additionalGuidesYAxisRadio
        )
        self.custom_overlay_secondary_axis_label = self.ui.customOverlaySecondaryAxisLabel
        self.custom_overlay_secondary_axis = self.ui.customOverlaySecondaryAxisCheck
        self.custom_overlay_secondary_axis.setChecked(self.settings.custom_overlay_secondary_axis)
        self.secondary_auto_y_range_label = self.ui.secondaryAutoYLabel
        self.secondary_auto_y_range = self.ui.secondaryAutoYRangeCheck
        self.secondary_auto_y_range.setChecked(self.settings.secondary_auto_y_range)
        self.secondary_y_min_label = self.ui.secondaryYMinLabel
        self.secondary_y_min = self.ui.secondaryYMinSpin
        self.secondary_y_min.setValue(self.settings.secondary_y_min)
        self.secondary_y_max_label = self.ui.secondaryYMaxLabel
        self.secondary_y_max = self.ui.secondaryYMaxSpin
        self.secondary_y_max.setValue(self.settings.secondary_y_max)
        self.secondary_auto_tick_interval_label = self.ui.secondaryAutoTickIntervalLabel
        self.secondary_auto_tick_interval = self.ui.secondaryAutoTickIntervalCheck
        self.secondary_auto_tick_interval.setChecked(self.settings.secondary_auto_tick_interval)
        self.secondary_tick_interval_label = self.ui.secondaryTickIntervalLabel
        self.secondary_tick_interval = self.ui.secondaryTickIntervalSpin
        self.secondary_tick_interval.setValue(self.settings.secondary_tick_interval)
        self.split_secondary_axis_label = self.ui.splitSecondaryAxisLabel
        self.split_secondary_axis = self.ui.splitSecondaryAxisCheck
        self.split_secondary_axis.setChecked(self.settings.split_secondary_axis)
        self.secondary_axis_split_ratio_label = self.ui.secondaryAxisSplitRatioLabel
        self.secondary_axis_split_ratio = self.ui.secondaryAxisSplitRatioSpin
        self.secondary_axis_split_ratio.setValue(self.settings.secondary_axis_split_ratio)
        self.show_points = self.ui.showPointsCheck
        self.point_size = self.ui.pointSizeSpin
        self.point_alpha = self.ui.pointAlphaSpin
        self.jitter_mode = self.ui.jitterModeCombo
        self.jitter = self.ui.jitterSpin
        self.xy_marker = self.ui.xyMarkerCombo
        self.xy_show_line = self.ui.xyShowLineCheck
        self.xy_line_width = self.ui.xyLineWidthSpin
        self.xy_line_style = self.ui.xyLineStyleCombo
        self.use_all_series_style_button = self.ui.useAllSeriesStyleButton
        self.xy_series_selection_panel = self.ui.xySeriesSelectionPanel
        self.xy_series_selection_count_label = self.ui.xySeriesSelectionCountLabel
        self.xy_series_selection_list = self.ui.xySeriesSelectionList
        self.xy_no_series_selected_label = self.ui.xyNoSeriesSelectedLabel
        self.show_line_overlay = self.ui.showLineOverlayCheck
        self.line_overlay_stat = self.ui.lineOverlayStatCombo
        self.extra_custom_overlay = self.ui.extraCustomOverlayCheck
        self.custom_overlay_count = self.ui.customOverlayCountSpin
        self.add_overlay_button = self.ui.addOverlayButton
        self.remove_overlay_button = self.ui.removeOverlayButton
        self.custom_overlay_filter_button = self.ui.customOverlayFilterButton
        self.line_overlay_width = self.ui.lineOverlayWidthSpin
        self.line_overlay_style = self.ui.lineOverlayStyleCombo
        self.line_overlay_break_between_parents = self.ui.lineOverlayBreakBetweenParentsCheck
        self.edit_overlay_styles_button = self.ui.editOverlayStylesButton
        self.line_overlay_point_size = self.ui.lineOverlayPointSizeSpin
        self.show_line_values = self.ui.showLineValuesCheck
        self.line_value_position = self.ui.lineValuePositionCombo
        self.custom_line_value_position = self.ui.customLineValuePositionCombo
        self.line_value_scientific = self.ui.lineValueScientificCheck
        self.line_value_decimals = self.ui.lineValueDecimalsSpin
        self.show_stat_table = self.ui.showStatTableCheck
        self.show_stat_header = self.ui.showStatHeaderCheck
        self.stat_table_options = self.ui.statTableOptionsList
        self.show_outliers = self.ui.showOutliersCheck
        self.outlier_method = self.ui.outlierMethodCombo
        self.outlier_threshold = self.ui.outlierThresholdSpin
        self.outlier_effect = self.ui.outlierEffectCombo
        self.box_width = self.ui.boxWidthSpin
        self.box_whisker_mode = self.ui.boxWhiskerModeCombo
        self.bar_width = self.ui.barWidthSpin
        self.bar_summary = self.ui.barSummaryCombo
        self.violin_width = self.ui.violinWidthSpin
        self.kde_bandwidth = self.ui.kdeBandwidthSpin
        self.ridge_overlap = self.ui.ridgeOverlapSpin
        self.fill_alpha = self.ui.fillAlphaSpin
        self.group_outer_spacing = self.ui.groupOuterSpacingSpin

    def _populate_ui_options(self) -> None:
        self.chart_type.addItems(["Box", "Bar", "Violin", "Ridge"])
        self.preset.addItems(list(PRESETS))
        self.group_order.addItems([
            "Table order",
            "Manual",
            "Name A-Z",
            "Name Z-A",
            "Mean ascending",
            "Mean descending",
            "Median ascending",
            "Median descending",
        ])
        self.jitter_mode.addItems(["Beeswarm", "Quasirandom", "Random"])
        self.xy_marker.addItems(
            ["Circle", "Square", "Triangle", "Diamond", "Plus", "Cross"]
        )
        self._populate_line_style_combo(self.xy_line_style)
        self.line_overlay_stat.addItems(["None", "Median", "Mean"])
        self._populate_line_style_combo(self.line_overlay_style)
        self._refresh_line_value_position_options()
        self.custom_line_value_position.addItems(["Auto", "Above", "Below", "Left", "Right"])
        self._refresh_additional_guide_position_options()
        self.additional_guide_text_color.clear()
        text_color_labels = {
            "auto": self.tr("Automatic (theme)"),
            "match_line": self.tr("Match line"),
        }
        for value in ADDITIONAL_GUIDE_TEXT_COLOR_MODES:
            self.additional_guide_text_color.addItem(
                text_color_labels[value],
                value,
            )
        self._refresh_additional_guide_color_options()
        self.additional_guides_table.verticalHeader().hide()
        self.additional_guides_table.horizontalHeader().setSectionResizeMode(
            0,
            QHeaderView.ResizeMode.ResizeToContents,
        )
        for column in (1, 2, 3):
            self.additional_guides_table.horizontalHeader().setSectionResizeMode(
                column,
                QHeaderView.ResizeMode.ResizeToContents,
            )
        self.additional_guides_table.horizontalHeader().setSectionResizeMode(
            4,
            QHeaderView.ResizeMode.Stretch,
        )
        self.outlier_method.addItems(["IQR", "Z-score", "MAD", "Percentile"])
        self.outlier_effect.addItems(["Mark only", "Exclude from distribution"])
        self.box_whisker_mode.addItems(["Tukey 1.5 IQR", "Min-Max", "Percentile 5-95", "Percentile 10-90"])
        self.bar_summary.addItem(self.tr("Mean"), "Mean")
        self.bar_summary.addItem(self.tr("Mean with SD"), "Mean with SD")
        self.bar_summary.addItem(self.tr("Mean with SEM"), "Mean with SEM")
        self.bar_summary.addItem(self.tr("Mean with 95% CI"), "Mean with 95% CI")
        self.bar_summary.addItem(self.tr("Mean with range"), "Mean with range")
        self.bar_summary.addItem(self.tr("Median"), "Median")
        self.bar_summary.addItem(self.tr("Median with 95% CI"), "Median with 95% CI")
        self.bar_summary.addItem(self.tr("Median with range"), "Median with range")
        self.bar_summary.addItem(self.tr("No line or error bar"), "No line or error bar")
        self._populate_stat_table_options()

    def _populate_line_style_combo(self, combo: QComboBox) -> None:
        combo.clear()
        combo.setIconSize(LINE_STYLE_ICON_SIZE)
        combo.view().setIconSize(LINE_STYLE_ICON_SIZE)
        combo.view().setItemDelegate(LineStyleItemDelegate(combo.view()))
        icon_color = combo.palette().color(QPalette.ColorRole.ButtonText)
        if not icon_color.isValid():
            icon_color = combo.palette().color(QPalette.ColorRole.Text)
        for style in LINE_OVERLAY_STYLES:
            combo.addItem(line_style_icon(style, icon_color), style)

    def _populate_stat_table_options(self) -> None:
        self.stat_table_options.clear()
        for setting_name, label in STAT_TABLE_OPTIONS:
            item = QListWidgetItem(label)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if getattr(self.settings, setting_name) else Qt.Unchecked)
            item.setSizeHint(QSize(0, 22))
            self.stat_table_options.addItem(item)

    def edit_statistic_formats(self, *, analysis: bool = False) -> None:
        target = self.workbook.active_sheet.analysis_settings if analysis else self.settings
        dialog = StatisticFormatDialog(
            target.statistic_formats,
            self,
            analysis=analysis,
            default_decimals=2 if analysis else self.settings.line_value_decimals,
            default_scientific=False if analysis else self.settings.line_value_scientific,
        )
        try:
            if dialog.exec() != QDialog.DialogCode.Accepted:
                return
            formats = dialog.formats()
            if formats == target.statistic_formats:
                return
            target.statistic_formats = formats
            if analysis:
                self.refresh_analysis_results()
                self._record_recovery_analysis()
            else:
                self._record_recovery_settings()
                self.schedule_render(RenderMode.FULL)
            self._update_sheet_tab_texts()
        finally:
            dialog.deleteLater()

    def _stat_table_option_checked(self, setting_name: str) -> bool:
        for index, (option_name, _label) in enumerate(STAT_TABLE_OPTIONS):
            if option_name == setting_name:
                item = self.stat_table_options.item(index)
                return item is not None and item.checkState() == Qt.Checked
        return False

    def _apply_stat_table_options_to_controls(self) -> None:
        self.stat_table_options.blockSignals(True)
        try:
            for index, (setting_name, _label) in enumerate(STAT_TABLE_OPTIONS):
                item = self.stat_table_options.item(index)
                if item is not None:
                    item.setCheckState(Qt.Checked if getattr(self.settings, setting_name) else Qt.Unchecked)
        finally:
            self.stat_table_options.blockSignals(False)

    def _stat_table_header_forced(self) -> bool:
        return self.chart_type.currentText() == "Ridge" and self.show_stat_table.isChecked()

    def _set_stat_table_header_checked(self, checked: bool) -> None:
        signals_blocked = self.show_stat_header.blockSignals(True)
        try:
            self.show_stat_header.setChecked(checked)
        finally:
            self.show_stat_header.blockSignals(signals_blocked)

    def _sync_stat_table_header_control(self, restore_stored: bool = False) -> bool:
        forced = self._stat_table_header_forced()
        if forced:
            self._set_stat_table_header_checked(True)
        elif restore_stored:
            self._set_stat_table_header_checked(self.settings.show_stat_header)
        self.show_stat_header.setEnabled(not forced)
        return forced

    def _line_value_position_options(self) -> list[str]:
        axis_options = ["Axis left", "Axis right"] if self.chart_type.currentText() == "Ridge" else ["Top axis", "Bottom axis"]
        return ["Auto", "Above", "Below", "Left", "Right", *axis_options]

    def _refresh_line_value_position_options(self, preferred: str | None = None) -> None:
        options = self._line_value_position_options()
        current_options = [self.line_value_position.itemText(index) for index in range(self.line_value_position.count())]
        current = preferred if preferred is not None else self.line_value_position.currentText()
        selected = normalize_overlay_label_position(current, self.chart_type.currentText())
        if current_options == options:
            self.line_value_position.setCurrentText(selected)
            return

        self.line_value_position.blockSignals(True)
        try:
            self.line_value_position.clear()
            self.line_value_position.addItems(options)
            self.line_value_position.setCurrentText(selected)
        finally:
            self.line_value_position.blockSignals(False)

    def _legend_columns_control_value(self) -> int:
        text = self.legend_columns.currentText()
        return int(text) if text.isdigit() else 0

    def _legend_position_control_value(self) -> str:
        return LEGEND_POSITION_INSIDE if self.legend_position.currentText() == self.tr("Inside plot") else LEGEND_POSITION_RIGHT

    def _set_legend_position_value(self, position: str) -> None:
        was_blocked = self.legend_position.blockSignals(True)
        try:
            self.legend_position.setItemText(
                0,
                self.tr("Below plot") if self.settings.chart_type == "Ridge" else self.tr("Right side"),
            )
            self.legend_position.setCurrentIndex(1 if position == LEGEND_POSITION_INSIDE else 0)
        finally:
            self.legend_position.blockSignals(was_blocked)

    def _set_legend_auto_width_checked(self, checked: bool) -> None:
        self.legend_auto_width.blockSignals(True)
        try:
            self.legend_auto_width.setChecked(checked)
        finally:
            self.legend_auto_width.blockSignals(False)

    def _set_legend_columns_value(self, columns: int) -> None:
        self.legend_columns.blockSignals(True)
        try:
            self.legend_columns.setCurrentText(self.tr("Auto") if columns <= 0 else str(columns))
        finally:
            self.legend_columns.blockSignals(False)

    def handle_legend_columns_changed(self, _text: str | None = None) -> None:
        if self._legend_columns_control_value() <= 0:
            self._set_legend_auto_width_checked(False)
        self.update_settings()

    def handle_legend_auto_width_changed(self, _state: int | None = None) -> None:
        if self.legend_auto_width.isChecked() and self._legend_columns_control_value() <= 0:
            self._set_legend_columns_value(1)
        self.update_settings()

    def _custom_overlay_axis_available(self, existing_overlay_series: list[dict] | None = None) -> bool:
        if existing_overlay_series is None:
            existing_overlay_series = self.custom_overlay_series_from_table()
        return self.extra_custom_overlay.isChecked() and bool(existing_overlay_series)

    def _combo_boxes(self) -> list[QComboBox]:
        return [
            self.chart_type,
            self.preset,
            self.group_order,
            self.legend_position,
            self.legend_columns,
            self.jitter_mode,
            self.xy_marker,
            self.xy_line_style,
            self.line_overlay_stat,
            self.line_overlay_style,
            self.line_value_position,
            self.custom_line_value_position,
            self.additional_guide_text_side,
            self.additional_guide_text_vertical,
            self.additional_guide_color,
            self.additional_guide_text_color,
            self.outlier_method,
            self.outlier_effect,
            self.box_whisker_mode,
            self.bar_summary,
        ]

    def _spin_boxes(self) -> list[QSpinBox | QDoubleSpinBox]:
        return [
            self.width,
            self.height,
            self.dpi,
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.additional_guide_font_size,
            self.legend_font_size,
            self.legend_width,
            self.line_value_font_size,
            self.stat_table_font_size,
            self.custom_overlay_count,
            self.line_overlay_width,
            self.line_overlay_point_size,
            self.axis_line_width,
            self.additional_guide_line_width,
            self.x_min,
            self.x_max,
            self.x_tick_interval,
            self.x_tick_rotation,
            self.y_min,
            self.y_max,
            self.primary_tick_interval,
            self.additional_guide_value,
            self.secondary_y_min,
            self.secondary_y_max,
            self.secondary_tick_interval,
            self.secondary_axis_split_ratio,
            self.point_size,
            self.point_alpha,
            self.jitter,
            self.xy_line_width,
            self.line_value_decimals,
            self.outlier_threshold,
            self.box_width,
            self.bar_width,
            self.violin_width,
            self.kde_bandwidth,
            self.ridge_overlap,
            self.fill_alpha,
            self.group_outer_spacing,
        ]

    def _buttons(self) -> list[QPushButton | QToolButton]:
        return [
            self.ui.addXYSharedTableButton,
            self.ui.removeXYSharedTableButton,
            self.additional_guide_add_button,
            self.additional_guide_delete_button,
            self.add_overlay_button,
            self.remove_overlay_button,
            self.custom_overlay_filter_button,
            self.edit_overlay_styles_button,
            self.ui.copyImageButton,
            self.ui.copyStatisticsButton,
            self.ui.editGroupOrderButton,
            self.group_filter_button,
            self.edit_group_colors_button,
            self.decrease_all_fonts_button,
            self.increase_all_fonts_button,
            self.ui.loadTemplateButton,
            self.ui.saveTemplateButton,
            self.ui.inspectorShowAllButton,
            self.use_all_series_style_button,
        ]

    def _font_size_controls(self) -> list[QSpinBox]:
        return [
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.additional_guide_font_size,
            self.legend_font_size,
            self.line_value_font_size,
            self.stat_table_font_size,
        ]

    def _top_toolbar_compact_spin_boxes(self) -> list[QSpinBox | QDoubleSpinBox]:
        return [
            *self._font_size_controls(),
            self.width,
            self.height,
            self.dpi,
        ]

    def adjust_all_font_sizes(self, direction: int) -> None:
        controls = self._font_size_controls()
        changed = False
        for control in controls:
            target = office_adjacent_font_size(control.value(), direction, control.minimum(), control.maximum())
            if target != control.value():
                changed = True
            control.blockSignals(True)
            control.setValue(target)
            control.blockSignals(False)
        if changed:
            self.update_settings()

    def _polish_combo_box(self, combo: QComboBox) -> None:
        combo.setFixedHeight(APP_CONTROL_HEIGHT)
        combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        if combo.count() == 0:
            return
        max_text_width = max(combo.fontMetrics().horizontalAdvance(combo.itemText(index)) for index in range(combo.count()))
        has_icons = any(not combo.itemIcon(index).isNull() for index in range(combo.count()))
        if has_icons:
            max_text_width += combo.iconSize().width() + 8
        max_text_length = max(len(combo.itemText(index)) for index in range(combo.count()))
        minimum_width = min(max(max_text_width + COMBO_TEXT_WIDTH_PADDING, COMBO_MIN_WIDTH), 280)
        if isinstance(combo, PaletteComboBox):
            minimum_width += PREVIEW_PADDING
        popup_minimum_width = minimum_width
        if isinstance(combo.view().itemDelegate(), LineStyleItemDelegate):
            popup_width = LINE_STYLE_POPUP_PREVIEW_WIDTH + max_text_width + COMBO_TEXT_WIDTH_PADDING + 24
            popup_minimum_width = min(max(popup_minimum_width, popup_width), 320)
        combo.setMinimumContentsLength(min(max(max_text_length + 2, 10), 36))
        combo.setFixedWidth(minimum_width)
        combo.view().setMinimumWidth(popup_minimum_width)

    def _polish_template_combo_box(self) -> None:
        self.template_combo.setFixedHeight(APP_CONTROL_HEIGHT)
        self.template_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.template_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        if self.template_combo.count() == 0:
            return
        max_text_width = max(self.template_combo.fontMetrics().horizontalAdvance(self.template_combo.itemText(index)) for index in range(self.template_combo.count()))
        max_text_length = max(len(self.template_combo.itemText(index)) for index in range(self.template_combo.count()))
        minimum_width = min(max(max_text_width + COMBO_TEXT_WIDTH_PADDING, COMBO_MIN_WIDTH), 280)
        self.template_combo.setMinimumContentsLength(min(max(max_text_length + 2, 10), 36))
        self.template_combo.setMinimumWidth(COMBO_MIN_WIDTH)
        self.template_combo.view().setMinimumWidth(minimum_width)

    def _combo_full_text_width(self, combo: QComboBox) -> int:
        if combo.count() == 0:
            return COMBO_MIN_WIDTH
        max_text_width = max(combo.fontMetrics().horizontalAdvance(combo.itemText(index)) for index in range(combo.count()))
        has_icons = any(not combo.itemIcon(index).isNull() for index in range(combo.count()))
        if has_icons:
            max_text_width += combo.iconSize().width() + 8
        if isinstance(combo, PaletteComboBox):
            max_text_width += PREVIEW_PADDING
        return max(max_text_width + COMBO_TEXT_WIDTH_PADDING, COMBO_MIN_WIDTH)

    def _spin_box_widest_text(self, spin_box: QSpinBox | QDoubleSpinBox) -> str:
        candidates = [
            spin_box.textFromValue(spin_box.minimum()),
            spin_box.textFromValue(spin_box.maximum()),
            spin_box.textFromValue(spin_box.value()),
        ]
        return max(candidates, key=spin_box.fontMetrics().horizontalAdvance)

    def _compact_spin_box_width(self, spin_box: QSpinBox | QDoubleSpinBox) -> int:
        sample_text = self._spin_box_widest_text(spin_box)
        font_metrics = spin_box.fontMetrics()
        minimum_edit_width = (
            font_metrics.horizontalAdvance(sample_text)
            + COMPACT_SPIN_TEXT_PADDING
            + font_metrics.horizontalAdvance("0")
        )
        start_width = max(minimum_edit_width, APP_CONTROL_HEIGHT)
        for width in range(start_width, COMBO_MIN_WIDTH + 1):
            spin_box.setFixedWidth(width)
            option = QStyleOptionSpinBox()
            spin_box.initStyleOption(option)
            edit_rect = spin_box.style().subControlRect(
                QStyle.ComplexControl.CC_SpinBox,
                option,
                QStyle.SubControl.SC_SpinBoxEditField,
                spin_box,
            )
            button_rect = spin_box.style().subControlRect(
                QStyle.ComplexControl.CC_SpinBox,
                option,
                QStyle.SubControl.SC_SpinBoxUp,
                spin_box,
            )
            if edit_rect.width() >= minimum_edit_width and button_rect.width() > 0:
                return width
        return COMBO_MIN_WIDTH

    def _polish_chart_basics_combo_boxes(self) -> None:
        order_width = max(
            self._combo_full_text_width(self.group_order),
            self._combo_full_text_width(self.preset),
        )
        self.ui.topToolbarLayout.setColumnStretch(9, 0)
        self.ui.topToolbarLayout.setColumnMinimumWidth(9, order_width)
        self.ui.topToolbarLayout.setColumnStretch(19, 1)
        for combo in (self.chart_type, self.preset, self.group_order):
            combo.setFixedWidth(order_width)
            combo.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

    def _polish_contextual_font_slots(self) -> None:
        layout = self.ui.topToolbarLayout
        first_slot_labels = (
            self.ui.lineValueSizeLabel,
            self.additional_guide_font_size_label,
        )
        layout.setColumnMinimumWidth(
            3,
            max(label.sizeHint().width() for label in first_slot_labels),
        )
        layout.setColumnMinimumWidth(
            4,
            max(
                self.line_value_font_size.width(),
                self.additional_guide_font_size.width(),
            ),
        )
        layout.setColumnMinimumWidth(5, self.ui.statTableSizeLabel.sizeHint().width())
        layout.setColumnMinimumWidth(6, self.stat_table_font_size.width())

    def _polish_input_controls(self) -> None:
        self._polish_inspector_groups()
        self._polish_template_combo_box()
        for combo in self._combo_boxes():
            self._polish_combo_box(combo)
        self._polish_chart_basics_combo_boxes()
        compact_spin_boxes = set(self._top_toolbar_compact_spin_boxes())
        for spin_box in self._spin_boxes():
            spin_box.setKeyboardTracking(False)
            spin_box.setFixedHeight(APP_CONTROL_HEIGHT)
            if spin_box in compact_spin_boxes:
                spin_box.setStyleSheet(COMPACT_SPIN_STYLE)
                spin_box.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.UpDownArrows)
                spin_width = self._compact_spin_box_width(spin_box)
            else:
                spin_width = COMBO_MIN_WIDTH
            spin_box.setFixedWidth(spin_width)
        for button in self._buttons():
            button.setFixedHeight(APP_CONTROL_HEIGHT)
        self._polish_contextual_font_slots()
        self.sheet_menu_button.setFixedSize(APP_CONTROL_HEIGHT, APP_CONTROL_HEIGHT)
        self.sheet_tab_bar.setFixedHeight(APP_CONTROL_HEIGHT + 2)
        self.transparent_background.setFixedHeight(APP_CONTROL_HEIGHT)
        self.custom_overlay_count.hide()
        self.ui.customOverlayCountLabel.setText(self.tr("Overlay filter"))
        if hasattr(self.ui.lineOverlayForm, "setRowVisible"):
            self.ui.lineOverlayForm.setRowVisible(self.ui.showLineOverlayLabel, False)
        else:
            self.ui.showLineOverlayLabel.hide()
            self.show_line_overlay.hide()
        self.ui.extraCustomOverlayLabel.setText(self.tr("Show custom overlays"))

    def _populate_sheet_type_actions(self, menu: QMenu, callback) -> None:
        for label, mode in (
            (self.tr("Groups"), SHEET_MODE_GROUPS),
            (self.tr("XY"), SHEET_MODE_XY),
        ):
            action = menu.addAction(label)
            action.triggered.connect(
                lambda _checked=False, sheet_mode=mode: callback(sheet_mode)
            )

    def _configure_new_menus(self) -> None:
        self._new_project_menu = QMenu(self)
        self._populate_sheet_type_actions(
            self._new_project_menu,
            self.new_project,
        )
        self.ui.actionNew.setMenu(self._new_project_menu)

    def _connect_generated_ui(self) -> None:
        self._build_recent_projects_menu()
        self._build_edit_menu()
        self._build_settings_menu()
        self._build_theme_menu()
        self._build_language_menu()
        self._configure_file_action_shortcuts()
        self._configure_new_menus()
        self.ui.actionOpenProject.triggered.connect(self.open_project)
        self.ui.actionSaveProject.triggered.connect(self.save_project)
        self.ui.actionSaveProjectAs.triggered.connect(self.save_project_as)
        self.ui.actionImportExcel.triggered.connect(self.import_excel)
        self.ui.actionImportPrism.triggered.connect(self.import_prism_data)
        self.ui.actionExportExcel.triggered.connect(self.export_excel)
        self.ui.actionCopyFigure.triggered.connect(self.copy_figure_image)
        self.ui.actionExportFigure.triggered.connect(self.export_figure)
        self.sheet_menu_button.clicked.connect(self.show_sheet_menu)
        self.sheet_tab_bar.currentChanged.connect(self.switch_sheet)
        self.sheet_tab_bar.tabBarDoubleClicked.connect(self.rename_sheet)
        self.sheet_tab_bar.tabMoved.connect(self.move_sheet)
        self.sheet_tab_bar.customContextMenuRequested.connect(self.show_sheet_context_menu)
        self.add_overlay_button.clicked.connect(self.add_custom_overlay_row)
        self.remove_overlay_button.clicked.connect(self.remove_custom_overlay_row)
        self.additional_guide_add_button.clicked.connect(
            self.add_additional_guide
        )
        self.additional_guide_delete_button.clicked.connect(
            self.delete_selected_additional_guide
        )
        self.additional_guides_table.itemSelectionChanged.connect(
            self._handle_additional_guide_table_selection_changed
        )
        self.additional_guide_value.valueChanged.connect(
            self._commit_selected_additional_guide
        )
        self.additional_guide_tick.stateChanged.connect(
            self._commit_selected_additional_guide
        )
        self.additional_guide_show_value.stateChanged.connect(
            self._commit_selected_additional_guide
        )
        self.additional_guide_line.stateChanged.connect(
            self._commit_selected_additional_guide
        )
        self.additional_guide_color.currentIndexChanged.connect(
            self._commit_selected_additional_guide
        )
        self.additional_guide_text_color.currentIndexChanged.connect(
            self._commit_selected_additional_guide
        )
        self.additional_guide_text.textChanged.connect(
            self._handle_additional_guide_text_changed
        )
        self.additional_guide_text_side.currentIndexChanged.connect(
            lambda _index: self._commit_selected_additional_guide(
                changed_position="text_side"
            )
        )
        self.additional_guide_text_vertical.currentIndexChanged.connect(
            lambda _index: self._commit_selected_additional_guide(
                changed_position="vertical_position"
            )
        )
        self.additional_guide_label_background.stateChanged.connect(
            self._commit_selected_additional_guide
        )
        self.additional_guides_x_axis_radio.toggled.connect(
            lambda checked: self._select_show_all_additional_guides_axis(
                "x",
                checked,
            )
        )
        self.additional_guides_y_axis_radio.toggled.connect(
            lambda checked: self._select_show_all_additional_guides_axis(
                "primary",
                checked,
            )
        )
        self.ui.addXYSharedTableButton.clicked.connect(lambda: self.add_xy_shared_table())
        self.ui.removeXYSharedTableButton.clicked.connect(lambda: self.remove_xy_shared_table())
        self.ui.xySharedTabBar.currentChanged.connect(self.switch_xy_shared_table)
        self.ui.xySharedTabBar.tabMoved.connect(self.move_xy_shared_table)
        self.ui.xySharedTabBar.tabBarDoubleClicked.connect(self.rename_xy_shared_table)
        self.curve_fit_button.clicked.connect(self.open_xy_curve_fit_dialog)
        self.ui.copyImageButton.clicked.connect(self.copy_figure_image)
        self.ui.copyStatisticsButton.clicked.connect(self.copy_analysis_results_table)
        self.ui.analysisNumberFormatsButton.clicked.connect(
            lambda: self.edit_statistic_formats(analysis=True)
        )
        self.ui.statisticNumberFormatsButton.clicked.connect(self.edit_statistic_formats)
        self.ui.labelNumberFormatsButton.clicked.connect(self.edit_statistic_formats)
        self.ui.editGroupOrderButton.clicked.connect(self.edit_group_order)
        self.group_filter_button.clicked.connect(self.edit_group_filter)
        self.custom_overlay_filter_button.clicked.connect(self.edit_custom_overlay_filter)
        self.edit_overlay_styles_button.clicked.connect(self.edit_custom_overlay_styles)
        self.edit_group_colors_button.clicked.connect(self.edit_group_colors)
        self.template_combo.currentTextChanged.connect(self.apply_selected_template)
        self.ui.loadTemplateButton.clicked.connect(self.load_external_template)
        self.ui.saveTemplateButton.clicked.connect(self.save_current_template)
        self.ui.inspectorShowAllButton.clicked.connect(
            self.clear_plot_object_selection
        )
        self.use_all_series_style_button.clicked.connect(
            self.reset_selected_xy_series_style
        )
        self.xy_series_selection_list.itemChanged.connect(
            self._handle_xy_series_selection_item_changed
        )
        self.ui.xySeriesSelectAllButton.clicked.connect(
            self._select_all_xy_series_globally
        )
        self.ui.xySeriesClearSelectionButton.clicked.connect(
            self._clear_xy_series_selection
        )
        self.ui.xySeriesInvertSelectionButton.clicked.connect(
            self._invert_xy_series_selection
        )
        for field, spin_box in (
            ("point_size", self.point_size),
            ("point_alpha", self.point_alpha),
            ("line_width", self.xy_line_width),
        ):
            spin_box.editingFinished.connect(
                lambda style_field=field: self._commit_mixed_xy_spin_field(
                    style_field
                )
            )
            spin_box.lineEdit().textEdited.connect(
                lambda _text, style_field=field: self._xy_mixed_spin_edits.add(
                    style_field
                )
            )
        self.table_copy_shortcut = QShortcut(
            QKeySequence.Copy,
            self.table,
            activated=self.copy_table_selection,
        )
        self.table_copy_shortcut.setContext(
            Qt.ShortcutContext.WidgetWithChildrenShortcut
        )
        for sequence, callback in [
            (QKeySequence.Paste, self.paste_table_selection),
            (QKeySequence.Cut, self.cut_table_selection),
            (QKeySequence.Delete, self.clear_table_selection),
            (QKeySequence.Undo, self.undo_table_change),
            (QKeySequence.Redo, self.redo_table_change),
        ]:
            shortcut = QShortcut(sequence, self.table, activated=callback)
            shortcut.setContext(
                Qt.ShortcutContext.WidgetWithChildrenShortcut
            )
        for sequence, callback in [
            (QKeySequence.Copy, self.copy_table_selection),
            (QKeySequence.Paste, self.paste_table_selection),
            (QKeySequence.Cut, self.cut_table_selection),
            (QKeySequence.Delete, self.clear_table_selection),
            (QKeySequence.Undo, self.undo_table_change),
            (QKeySequence.Redo, self.redo_table_change),
        ]:
            shortcut = QShortcut(
                sequence,
                self.xy_independent_table,
                activated=callback,
            )
            shortcut.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        self.results_copy_shortcut = QShortcut(
            QKeySequence.Copy,
            self.results_table,
            activated=self.copy_analysis_results_selection,
        )
        self.results_copy_shortcut.setContext(
            Qt.ShortcutContext.WidgetWithChildrenShortcut
        )
        QShortcut(QKeySequence("Ctrl+PgUp"), self, activated=lambda: self.activate_adjacent_sheet(-1))
        QShortcut(QKeySequence("Ctrl+PgDown"), self, activated=lambda: self.activate_adjacent_sheet(1))
        QShortcut(QKeySequence("Shift+F11"), self, activated=self.add_sheet)
        QShortcut(
            QKeySequence("Escape"),
            self,
            activated=self.clear_plot_object_selection,
        )
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_table_context_menu)
        self.xy_independent_table.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        self.xy_independent_table.customContextMenuRequested.connect(
            self.show_xy_independent_context_menu
        )
        for table in (self.table, self.xy_independent_table):
            horizontal_header = table.horizontalHeader()
            horizontal_header.setContextMenuPolicy(
                Qt.ContextMenuPolicy.CustomContextMenu
            )
            horizontal_header.viewport().installEventFilter(self)
            self._table_header_context_targets[horizontal_header.viewport()] = (
                table,
                Qt.Orientation.Horizontal,
            )
            horizontal_header.sectionPressed.connect(
                lambda _section, target=table: self._remember_table_selection_origin(
                    target,
                    "columns",
                )
            )
            vertical_header = table.verticalHeader()
            vertical_header.setContextMenuPolicy(
                Qt.ContextMenuPolicy.CustomContextMenu
            )
            vertical_header.viewport().installEventFilter(self)
            self._table_header_context_targets[vertical_header.viewport()] = (
                table,
                Qt.Orientation.Vertical,
            )
            vertical_header.sectionPressed.connect(
                lambda _section, target=table: self._remember_table_selection_origin(
                    target,
                    "rows",
                )
            )
        self.results_table.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        self.results_table.customContextMenuRequested.connect(
            self.show_analysis_results_context_menu
        )
        self.table.selectionModel().selectionChanged.connect(
            self._handle_data_table_selection_changed
        )
        self.results_table.selectionModel().selectionChanged.connect(
            self._handle_analysis_table_selection_changed
        )
        self.table.installEventFilter(self)
        self.table.viewport().installEventFilter(self)
        self.xy_independent_table.installEventFilter(self)
        self.xy_independent_table.viewport().installEventFilter(self)
        self.xy_series_selection_list.viewport().installEventFilter(self)
        self.table.table_item_delegate.navigation_requested.connect(
            self._handle_table_delegate_navigation
        )
        self.xy_independent_table.table_item_delegate.navigation_requested.connect(
            self._handle_table_delegate_navigation
        )
        self._connect_table()

        for widget in [
            self.chart_type,
            self.group_order,
            self.legend_position,
            self.jitter_mode,
            self.xy_marker,
            self.xy_line_style,
            self.line_overlay_stat,
            self.line_overlay_style,
            self.line_value_position,
            self.custom_line_value_position,
            self.outlier_method,
            self.outlier_effect,
            self.box_whisker_mode,
            self.bar_summary,
        ]:
            widget.currentTextChanged.connect(self.update_settings)
        self.legend_columns.currentTextChanged.connect(self.handle_legend_columns_changed)
        self.preset.currentTextChanged.connect(self.handle_preset_changed)
        for widget in [self.title, self.x_label, self.y_label]:
            widget.textChanged.connect(self.update_settings)
        self.secondary_y_label.textChanged.connect(self.update_settings)
        self.decrease_all_fonts_button.clicked.connect(lambda: self.adjust_all_font_sizes(-1))
        self.increase_all_fonts_button.clicked.connect(lambda: self.adjust_all_font_sizes(1))
        for widget in [
            self.width,
            self.height,
            self.dpi,
            self.title_font_size,
            self.axis_label_font_size,
            self.tick_font_size,
            self.additional_guide_font_size,
            self.legend_font_size,
            self.legend_width,
            self.line_value_font_size,
            self.stat_table_font_size,
            self.custom_overlay_count,
            self.line_overlay_width,
            self.line_overlay_point_size,
            self.axis_line_width,
            self.additional_guide_line_width,
            self.x_min,
            self.x_max,
            self.x_tick_interval,
            self.x_tick_rotation,
            self.y_min,
            self.y_max,
            self.primary_tick_interval,
            self.secondary_y_min,
            self.secondary_y_max,
            self.secondary_tick_interval,
            self.secondary_axis_split_ratio,
            self.point_size,
            self.point_alpha,
            self.jitter,
            self.xy_line_width,
            self.line_value_decimals,
            self.outlier_threshold,
            self.box_width,
            self.bar_width,
            self.violin_width,
            self.kde_bandwidth,
            self.ridge_overlap,
            self.fill_alpha,
            self.group_outer_spacing,
        ]:
            widget.valueChanged.connect(self.update_settings)
        for widget in [
            self.transparent_background,
            self.show_grid,
            self.auto_x_range,
            self.x_auto_tick_interval,
            self.auto_y_range,
            self.primary_auto_tick_interval,
            self.secondary_auto_y_range,
            self.secondary_auto_tick_interval,
            self.split_secondary_axis,
            self.show_legend,
            self.show_points,
            self.xy_show_line,
            self.show_line_overlay,
            self.extra_custom_overlay,
            self.custom_overlay_secondary_axis,
            self.line_overlay_break_between_parents,
            self.show_line_values,
            self.line_value_scientific,
            self.show_stat_table,
            self.show_stat_header,
            self.show_outliers,
        ]:
            widget.stateChanged.connect(self.update_settings)
        self.legend_auto_width.stateChanged.connect(self.handle_legend_auto_width_changed)
        self.stat_table_options.itemChanged.connect(self.update_settings)

    def _configure_file_action_shortcuts(self) -> None:
        self.ui.actionOpenProject.setShortcuts(QKeySequence.Open)
        self.ui.actionSaveProject.setShortcuts(QKeySequence.Save)
        self.ui.actionSaveProjectAs.setShortcuts(QKeySequence.SaveAs)
        self.ui.actionCopyFigure.setShortcut(QKeySequence("Ctrl+Shift+C"))

    def _build_recent_projects_menu(self) -> None:
        self.recent_projects_menu = self.ui.menuOpenRecent
        self.recent_projects_menu.aboutToShow.connect(self.update_recent_projects_menu)
        self.update_recent_projects_menu()

    def update_recent_projects_menu(self) -> None:
        self.recent_projects_menu.clear()
        recent_paths = stored_recent_project_paths()
        if not recent_paths:
            empty_action = self.recent_projects_menu.addAction(self.tr(recent_project_empty_label()))
            empty_action.setEnabled(False)
            return

        for index, path in enumerate(recent_paths, start=1):
            text, path_text = recent_project_menu_item(index, path)
            action = self.recent_projects_menu.addAction(text)
            action.setData(path_text)
            action.setStatusTip(path_text)
            action.triggered.connect(lambda _checked=False, *, project_path=path: self.open_recent_project(project_path))

        self.recent_projects_menu.addSeparator()
        clear_action = self.recent_projects_menu.addAction(self.tr(recent_project_clear_label()))
        clear_action.triggered.connect(self.clear_recent_projects)

    def clear_recent_projects(self) -> None:
        save_recent_project_paths([])
        self.update_recent_projects_menu()

    def _build_language_menu(self) -> None:
        self.language_menu = self.ui.menubar.addMenu(self.tr("Language"))
        self.language_actions: dict[str, QAction] = {}
        current_language = stored_language_preference()
        for language, label in [
            ("system", self.tr("System")),
            ("en", "English"),
            ("zh_CN", self.tr("Simplified Chinese")),
        ]:
            action = QAction(label, self)
            action.setCheckable(True)
            action.setChecked(current_language == language)
            action.triggered.connect(lambda _checked=False, *, code=language: self.change_language_preference(code))
            self.language_menu.addAction(action)
            self.language_actions[language] = action

    def _build_theme_menu(self) -> None:
        self.theme_menu = self.ui.menubar.addMenu(self.tr("Theme"))
        self.theme_action_group = QActionGroup(self)
        self.theme_action_group.setExclusive(True)
        self.theme_actions: dict[str, QAction] = {}
        current_theme = stored_theme_preference()
        for theme, label in [
            ("light", self.tr("Light")),
            ("dark", self.tr("Dark")),
        ]:
            action = QAction(label, self)
            action.setCheckable(True)
            action.setChecked(current_theme == theme)
            action.triggered.connect(lambda _checked=False, *, name=theme: self.change_theme_preference(name))
            self.theme_action_group.addAction(action)
            self.theme_menu.addAction(action)
            self.theme_actions[theme] = action

    def _build_settings_menu(self) -> None:
        self.settings_menu = self.ui.menubar.addMenu(self.tr("Settings"))
        self.preferences_action = QAction(self.tr("Preferences…"), self)
        self.preferences_action.triggered.connect(self.show_preferences)
        self.settings_menu.addAction(self.preferences_action)

    def preferences_state(self) -> PreferencesState:
        return PreferencesState(
            language=stored_language_preference(),
            theme=stored_theme_preference(),
            auto_recovery_interval_seconds=stored_auto_recovery_interval(),
        )

    def create_preferences_dialog(self) -> PreferencesDialog:
        return PreferencesDialog(self.preferences_state(), self)

    def show_preferences(self) -> None:
        dialog = self.create_preferences_dialog()
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.apply_preferences(dialog.preferences())

    def apply_preferences(self, preferences: PreferencesState) -> None:
        self.change_theme_preference(preferences.theme)
        self.change_language_preference(preferences.language)
        save_auto_recovery_interval(
            preferences.auto_recovery_interval_seconds
        )
        if self._recovery_manager is not None:
            self._recovery_manager.set_interval(stored_auto_recovery_interval())

    def change_theme_preference(self, theme: str) -> None:
        save_theme_preference(theme)
        selected_theme = stored_theme_preference()
        for name, action in self.theme_actions.items():
            action.setChecked(name == selected_theme)
        app = QApplication.instance()
        if app is not None:
            apply_app_theme(app, selected_theme)
            configure_top_toolbar(self, selected_theme)
            self._table_controller.refresh_structure()
            self._align_analysis_results_table()

    def _build_edit_menu(self) -> None:
        self.edit_menu = self.ui.menubar.addMenu(self.tr("Edit"))
        self.undo_table_action = QAction(self.tr("Undo Table Change"), self)
        self.undo_table_action.setShortcuts(QKeySequence.Undo)
        self.undo_table_action.triggered.connect(self.undo_table_change)
        self.edit_menu.addAction(self.undo_table_action)
        self.redo_table_action = QAction(self.tr("Redo Table Change"), self)
        self.redo_table_action.setShortcuts(QKeySequence.Redo)
        self.redo_table_action.triggered.connect(self.redo_table_change)
        self.edit_menu.addAction(self.redo_table_action)
        self.update_table_history_actions()

    def change_language_preference(self, language: str) -> None:
        language = normalize_language_code(language)
        if stored_language_preference() == language:
            self.language_actions[language].setChecked(True)
            return
        save_language_preference(language)
        for code, action in self.language_actions.items():
            action.setChecked(code == language)
        QMessageBox.information(
            self,
            self.tr("Language changed"),
            self.tr("Restart EasyGraph to apply the language change."),
        )

    def _prompt_recovery(self, candidate: RecoveryCandidate) -> str:
        dialog = QMessageBox(self)
        dialog.setIcon(QMessageBox.Icon.Warning)
        dialog.setWindowTitle(self.tr("Recover Unsaved Work"))
        project_name = (
            candidate.source_project.name
            if candidate.source_project is not None
            else self.tr("Untitled project")
        )
        dialog.setText(
            self.tr(
                "EasyGraph found unsaved work from an earlier session for {project}."
            ).format(project=project_name)
        )
        dialog.setInformativeText(
            self.tr(
                "Recover it now, discard it, or keep it for the next launch."
            )
        )
        recover_button = dialog.addButton(
            self.tr("Recover"), QMessageBox.ButtonRole.AcceptRole
        )
        discard_button = dialog.addButton(
            self.tr("Discard"), QMessageBox.ButtonRole.DestructiveRole
        )
        later_button = dialog.addButton(
            self.tr("Later"), QMessageBox.ButtonRole.RejectRole
        )
        dialog.setDefaultButton(recover_button)
        dialog.setEscapeButton(later_button)
        dialog.exec()
        clicked = dialog.clickedButton()
        if clicked is recover_button:
            return "recover"
        if clicked is discard_button:
            return "discard"
        return "later"

    def _initialize_recovery(self) -> None:
        adopt_session: Path | None = None
        candidates = find_recovery_candidates(self._recovery_root)
        if candidates:
            candidate = candidates[0]
            choice = self._prompt_recovery(candidate)
            if choice == "recover":
                try:
                    workbook, source_project = read_recovery_workbook(candidate)
                except Exception as exc:
                    QMessageBox.critical(
                        self,
                        self.tr("Recovery failed"),
                        str(exc),
                    )
                else:
                    self._apply_recovered_workbook(workbook, source_project)
                    self._recovered_on_startup = True
                    adopt_session = candidate.session_dir
            elif choice == "discard":
                discard_recovery(candidate)

        self._recovery_manager = RecoveryManager(
            interval_seconds=stored_auto_recovery_interval(),
            root=self._recovery_root,
            adopt_session=adopt_session,
        )
        self._connect_recovery_events()
        if adopt_session is None:
            self._replace_recovery_document(dirty=False)

    def _apply_recovered_workbook(
        self,
        workbook: WorkbookDocument,
        source_project: Path | None,
    ) -> None:
        self.current_project = source_project
        self.workbook = workbook
        self._reset_xy_fit_runtime()
        self.settings = workbook.active_sheet.settings
        self._sheet_sessions = {
            sheet.id: SheetSessionState() for sheet in workbook.sheets
        }
        self._table_controller.history = self._sheet_session(
            workbook.active_sheet.id
        ).history
        self._load_active_sheet(render=False)
        self._rebuild_sheet_tabs()
        self.refresh_template_combo(TEMPLATE_NONE_NAME)
        if self.canvas is not None:
            self.render()
            self.canvas.zoom_to_fit()
        self._saved_project_content = ()
        self._saved_sheet_content = {}
        self._update_sheet_tab_texts()

    def _connect_recovery_events(self) -> None:
        model = self.table.table_model
        model.cellEdited.connect(self._record_recovery_cell)
        model.modelReset.connect(self._require_recovery_checkpoint)
        model.rowsInserted.connect(
            lambda _parent, first, last: self._record_recovery_rows(
                first, last, inserted=True
            )
        )
        model.rowsRemoved.connect(
            lambda _parent, first, last: self._record_recovery_rows(
                first, last, inserted=False
            )
        )
        model.columnsInserted.connect(
            lambda _parent, first, last: self._record_recovery_columns(
                first, last, inserted=True
            )
        )
        model.columnsRemoved.connect(
            lambda _parent, first, last: self._record_recovery_columns(
                first, last, inserted=False
            )
        )

    def _note_recovery_change(self) -> None:
        if self._recovery_manager is None:
            return
        if self._recovery_manager.checkpoint_required:
            self._schedule_recovery_checkpoint(immediate=True)
        else:
            self._schedule_recovery_checkpoint(immediate=False)

    def _record_recovery_cell(
        self,
        row: int,
        column: int,
        _before: str,
        after: str,
    ) -> None:
        if self._recovery_events_suspended or self._recovery_manager is None:
            return
        self._recovery_manager.record_cell(
            self.workbook.active_sheet_id,
            row,
            column,
            after,
        )
        self._note_recovery_change()

    def _record_recovery_rows(
        self,
        first: int,
        last: int,
        *,
        inserted: bool,
    ) -> None:
        if self._recovery_events_suspended or self._recovery_manager is None:
            return
        self._recovery_manager.record_rows(
            self.workbook.active_sheet_id,
            first,
            last - first + 1,
            inserted=inserted,
        )
        self._note_recovery_change()

    def _record_recovery_columns(
        self,
        first: int,
        last: int,
        *,
        inserted: bool,
    ) -> None:
        if self._recovery_events_suspended or self._recovery_manager is None:
            return
        self._recovery_manager.record_columns(
            self.workbook.active_sheet_id,
            first,
            last - first + 1,
            inserted=inserted,
        )
        self._note_recovery_change()

    def _record_recovery_settings(self, *, dirty: bool = True) -> None:
        if self._recovery_events_suspended or self._recovery_manager is None:
            return
        self._recovery_manager.record_settings(
            self.workbook.active_sheet_id,
            self.settings,
            dirty=dirty,
        )
        if dirty:
            self._note_recovery_change()

    def _record_recovery_sheet_state(self, *, dirty: bool = True) -> None:
        if self._recovery_events_suspended or self._recovery_manager is None:
            return
        self._recovery_manager.record_sheet_state(
            self.workbook.active_sheet,
            dirty=dirty,
        )
        if dirty:
            self._note_recovery_change()

    def _record_recovery_analysis(self) -> None:
        if self._recovery_events_suspended or self._recovery_manager is None:
            return
        sheet = self.workbook.active_sheet
        self._recovery_manager.record_analysis(
            sheet.id,
            sheet.analysis_settings,
        )
        self._note_recovery_change()

    def _require_recovery_checkpoint(self, *_args) -> None:
        if self._recovery_events_suspended or self._recovery_manager is None:
            return
        self._recovery_manager.require_checkpoint()
        self._schedule_recovery_checkpoint(immediate=True)

    def _schedule_recovery_checkpoint(self, *, immediate: bool) -> None:
        if self._recovery_manager is None:
            return
        delay = 0 if immediate else RECOVERY_IDLE_CHECKPOINT_MS
        self._recovery_idle_timer.start(delay)

    def _checkpoint_recovery(self) -> None:
        if self._recovery_manager is None:
            return
        self._store_active_sheet(commit=False)
        self._recovery_manager.checkpoint_document(
            self.workbook,
            self.current_project,
        )

    def _replace_recovery_document(self, *, dirty: bool) -> None:
        if self._recovery_manager is None:
            return
        self._recovery_idle_timer.stop()
        self._store_active_sheet(commit=False)
        self._recovery_manager.replace_document(
            self.workbook,
            self.current_project,
            dirty=dirty,
        )

    def _mark_recovery_clean(self) -> None:
        if self._recovery_manager is None:
            return
        self._recovery_idle_timer.stop()
        self._store_active_sheet(commit=False)
        self._recovery_manager.mark_clean_and_checkpoint(
            self.workbook,
            self.current_project,
        )

    def _sheet_session(self, sheet_id: str) -> SheetSessionState:
        return self._sheet_sessions.setdefault(sheet_id, SheetSessionState())

    def _store_active_sheet(
        self,
        *,
        commit: bool = True,
        dataframe: pd.DataFrame | None = None,
    ) -> None:
        if commit:
            self._commit_pending_project_edits()
            if self._table_capacity_update_pending:
                self._refresh_table_capacity()
            self.flush_pending_render()
        sheet = self.workbook.active_sheet
        if sheet.mode != SHEET_MODE_XY:
            self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        sheet.dataframe = (
            self.table_dataframe()
            if dataframe is None
            else dataframe.copy(deep=True)
        )
        sheet.settings = self.settings
        sheet.analysis_settings.visible_statistics = [
            label
            for label in DESCRIPTIVE_STATISTICS
            if label in self.results_table.visible_statistics()
        ]
        session = self._sheet_session(sheet.id)
        if sheet.mode == SHEET_MODE_XY:
            active_table = self._active_xy_shared_table()
            if active_table is not None:
                session.xy_shared_histories[active_table.id] = self._table_controller.history
            session.xy_paired_history = self._xy_paired_controller.history
        else:
            session.history = self._table_controller.history
        current = self.table.currentIndex()
        if current.isValid():
            session.current_row = current.row()
            session.current_column = current.column()
        session.horizontal_scroll = self.table.horizontalScrollBar().value()
        session.vertical_scroll = self.table.verticalScrollBar().value()

    def _restore_sheet_view_state(self, session: SheetSessionState) -> None:
        row_count = self.table.table_model.rowCount()
        column_count = self.table.table_model.columnCount()
        if row_count and column_count:
            row = min(max(session.current_row, 0), row_count - 1)
            column = min(max(session.current_column, 0), column_count - 1)
            self.table.setCurrentIndex(self.table.table_model.index(row, column))
        self.table.horizontalScrollBar().setValue(session.horizontal_scroll)
        self.table.verticalScrollBar().setValue(session.vertical_scroll)

    def _load_active_sheet(self, *, render: bool = True) -> None:
        self.table.horizontalHeader().clear_parent_selection()
        sheet = self.workbook.active_sheet
        session = self._sheet_session(sheet.id)
        self._render_timer.stop()
        self._render_pending = False
        self.settings = sheet.settings
        self.clear_plot_object_selection()
        if sheet.mode == SHEET_MODE_XY:
            self._ensure_active_xy_table_layout()
            active_table = self._active_xy_shared_table()
            self._table_controller.history = session.xy_shared_histories.setdefault(
                active_table.id if active_table is not None else "",
                type(session.history)(),
            )
            self._xy_paired_controller.history = session.xy_paired_history
        else:
            self._table_controller.history = session.history
        recovery_was_suspended = self._recovery_events_suspended
        self._recovery_events_suspended = True
        try:
            self.results_table.set_visible_statistics(
                sheet.analysis_settings.visible_statistics
            )
            self.set_table_dataframe(
                sheet.dataframe,
                self.settings.custom_overlay_series,
                restore_group_capacity=True,
            )
            self.sync_manual_group_order()
            self.apply_settings_to_controls()
            self.refresh_template_combo(TEMPLATE_NONE_NAME)
            self._restore_sheet_view_state(session)
            self.update_table_history_actions()
            self._switching_sheet = True
            try:
                self.sheet_tab_bar.setCurrentIndex(self.workbook.active_index)
            finally:
                self._switching_sheet = False
        finally:
            self._recovery_events_suspended = recovery_was_suspended
        if render:
            self.render()

    def switch_sheet(self, index: int) -> None:
        if self._switching_sheet or not 0 <= index < len(self.workbook.sheets):
            return
        target = self.workbook.sheets[index]
        if target.id == self.workbook.active_sheet_id:
            return
        self._store_active_sheet()
        self.workbook.active_sheet_id = target.id
        self._load_active_sheet()
        if self._recovery_manager is not None:
            self._recovery_manager.record_active_sheet(target.id)
        self._update_sheet_tab_texts()

    def activate_adjacent_sheet(self, offset: int) -> None:
        if len(self.workbook.sheets) < 2:
            return
        target = (self.workbook.active_index + int(offset)) % len(self.workbook.sheets)
        self.sheet_tab_bar.setCurrentIndex(target)

    def _rebuild_sheet_tabs(self) -> None:
        self._switching_sheet = True
        try:
            while self.sheet_tab_bar.count():
                self.sheet_tab_bar.removeTab(self.sheet_tab_bar.count() - 1)
            for sheet in self.workbook.sheets:
                index = self.sheet_tab_bar.addTab(sheet.name)
                self.sheet_tab_bar.setTabData(index, sheet.id)
                self.sheet_tab_bar.setTabToolTip(index, sheet.name)
            self.sheet_tab_bar.setCurrentIndex(self.workbook.active_index)
        finally:
            self._switching_sheet = False
        self._update_sheet_tab_texts()

    @staticmethod
    def _dataframe_content_snapshot(dataframe: pd.DataFrame) -> tuple:
        columns = tuple(str(column) for column in dataframe.columns)
        rows = tuple(
            tuple("" if pd.isna(value) else str(value) for value in row)
            for row in dataframe.itertuples(index=False, name=None)
        )
        return columns, rows

    def _sheet_content_snapshot(self, sheet: SheetDocument) -> tuple:
        return (
            sheet.id,
            sheet.name,
            self._dataframe_content_snapshot(sheet.dataframe),
            asdict(sheet.settings),
            asdict(sheet.analysis_settings),
            sheet.mode,
            tuple(sheet.column_ids),
            asdict(sheet.xy_settings),
            asdict(sheet.grouping),
        )

    def _update_sheet_tab_texts(self, active_dataframe: pd.DataFrame | None = None) -> None:
        if not hasattr(self, "sheet_tab_bar"):
            return
        self._store_active_sheet(commit=False, dataframe=active_dataframe)
        project_is_dirty = False
        for index, sheet in enumerate(self.workbook.sheets):
            saved = self._saved_sheet_content.get(sheet.id)
            dirty = saved is None or self._sheet_content_snapshot(sheet) != saved
            project_is_dirty = project_is_dirty or dirty
            label = f"{sheet.name} •" if dirty else sheet.name
            self.sheet_tab_bar.setTabText(index, label)
            self.sheet_tab_bar.setTabToolTip(index, sheet.name)
        if (
            not project_is_dirty
            and self._recovery_manager is not None
            and self._recovery_manager.dirty
        ):
            self._mark_recovery_clean()

    def _new_sheet_settings(
        self,
        dataframe: pd.DataFrame,
        mode: str = SHEET_MODE_GROUPS,
        template_settings: ChartSettings | None = None,
    ) -> ChartSettings:
        if template_settings is None:
            settings = ChartSettings()
        else:
            settings = apply_style_template_settings(
                ChartSettings(),
                template_settings,
                [str(column) for column in dataframe.columns],
            )
        if normalized_sheet_mode(mode) == SHEET_MODE_XY:
            settings.chart_type = "Scatter"
            settings.title = self.tr("XY plot")
            settings.x_label = "X"
            settings.y_label = "Y"
            settings.show_stat_table = False
            settings.custom_overlay_series = []
            settings.extra_custom_overlay = False
        return settings

    def _style_template_for_new_sheet(
        self,
        mode: str,
    ) -> tuple[ChartSettings | None, XYStyleTemplate | None]:
        template_name = self._template_name_for_new_sheet(mode)
        if template_name is None:
            return (None, None)
        family = self._style_template_family_for_mode(mode)
        try:
            settings = read_style_template(template_name, family=family)
            xy_style = (
                read_xy_style_template(template_name, family=family)
                if family == TEMPLATE_FAMILY_XY
                else None
            )
        except Exception as exc:
            QMessageBox.warning(
                self,
                self.tr("Template load failed"),
                str(exc),
            )
            return (None, None)
        return (settings, xy_style)

    def _blank_sheet_document(self, mode: str, name: str) -> SheetDocument:
        normalized_mode = normalized_sheet_mode(mode)
        template_settings, xy_style = self._style_template_for_new_sheet(
            normalized_mode
        )
        dataframe = (
            pd.concat(
                [
                    blank_xy_data(y_columns=DEFAULT_XY_SHARED_Y_COLUMNS),
                    pd.DataFrame(
                        [
                            [""] * (DEFAULT_XY_INDEPENDENT_PAIRS * 2)
                            for _ in range(DEFAULT_XY_TABLE_ROWS)
                        ],
                        columns=[
                            f"{pair_number}{axis}"
                            for pair_number in range(
                                1, DEFAULT_XY_INDEPENDENT_PAIRS + 1
                            )
                            for axis in ("X", "Y")
                        ],
                    ),
                ],
                axis=1,
            )
            if normalized_mode == SHEET_MODE_XY
            else blank_project_data()
        )
        sheet = SheetDocument(
            name=name,
            dataframe=dataframe,
            settings=self._new_sheet_settings(
                dataframe,
                normalized_mode,
                template_settings,
            ),
            mode=normalized_mode,
        )
        if normalized_mode == SHEET_MODE_XY:
            sheet.xy_settings = shared_x_series(
                sheet.column_ids,
                list(sheet.dataframe.columns),
                y_column_ids=list(
                    sheet.column_ids[1 : DEFAULT_XY_SHARED_Y_COLUMNS + 1]
                ),
            )
            sheet.xy_settings.shared_tables[0].name = "Sheet1"
            independent_start = DEFAULT_XY_SHARED_Y_COLUMNS + 1
            for pair_number, x_column_index in enumerate(
                range(
                    independent_start,
                    independent_start + DEFAULT_XY_INDEPENDENT_PAIRS * 2,
                    2,
                ),
                start=1,
            ):
                pair = XYSeriesSpec(
                    id=new_series_id(),
                    name=f"{pair_number}Y",
                    x_column_id=sheet.column_ids[x_column_index],
                    y_column_id=sheet.column_ids[x_column_index + 1],
                )
                sheet.xy_settings.series.append(pair)
                sheet.xy_settings.paired_series_ids.append(pair.id)
            if xy_style is not None:
                sheet.xy_settings = apply_xy_style_template(
                    sheet.xy_settings,
                    xy_style,
                )
        return sheet

    def _demo_sheet_document(
        self, mode: str, name: str, *, grouped_demo: bool = False,
    ) -> SheetDocument:
        normalized_mode = normalized_sheet_mode(mode)
        if normalized_mode == SHEET_MODE_GROUPS:
            dataframe = sample_data()
            column_ids: list[str] = []
            grouping = GroupingSettings()
            if grouped_demo:
                subgroup_names = ["Control", "Low dose", "High dose"]
                subgroup_ids = ["demo_control", "demo_low_dose", "demo_high_dose"]
                parent_names = ["WT", "KO"]
                column_ids = [
                    f"demo_{parent.lower()}_{index}"
                    for parent in parent_names
                    for index in range(3)
                ]
                rng = np.random.default_rng(17)
                dataframe = pd.DataFrame(
                    np.column_stack([
                        np.round(rng.normal(center, 0.55, 14), 3)
                        for center in (5.0, 5.6, 6.4, 6.6, 7.2, 7.8)
                    ]),
                    columns=subgroup_names * len(parent_names),
                )
                grouping = GroupingSettings(
                    parents=[
                        {
                            "id": f"demo_{parent.lower()}",
                            "name": parent,
                            "column_ids": column_ids[index * 3 : (index + 1) * 3],
                        }
                        for index, parent in enumerate(parent_names)
                    ],
                    shared_subgroups=True,
                    subgroup_ids={
                        column_id: subgroup_ids[index % 3]
                        for index, column_id in enumerate(column_ids)
                    },
                )
            template_settings, _xy_style = self._style_template_for_new_sheet(
                normalized_mode
            )
            return SheetDocument(
                name=name,
                dataframe=dataframe,
                settings=self._new_sheet_settings(
                    dataframe,
                    normalized_mode,
                    template_settings,
                ),
                mode=normalized_mode,
                column_ids=column_ids,
                grouping=grouping,
            )

        sheet = self._blank_sheet_document(normalized_mode, name)
        sheet.dataframe.columns = [
            "Time",
            "Control",
            "Treatment",
            "Sensor A X",
            "Sensor A",
            "Sensor B X",
            "Sensor B",
        ]
        demo_values = (
            (0.0, 1.0, 2.0, 3.0, 4.0, 5.0),
            (1.0, 1.7, 2.5, 3.4, 4.0, 4.5),
            (0.8, 1.4, 2.1, 3.0, 4.2, 5.1),
            (0.0, 0.8, 1.7, 3.2, 4.6, 6.0),
            (0.5, 1.2, 2.0, 3.1, 4.0, 4.7),
            (0.0, 1.2, 2.2, 3.8, 5.5, 7.0),
            (1.2, 1.8, 2.7, 3.6, 4.3, 5.0),
        )
        for column, values in enumerate(demo_values):
            sheet.dataframe.iloc[: len(values), column] = values
        names_by_column_id = dict(zip(sheet.column_ids, sheet.dataframe.columns))
        for series in sheet.xy_settings.series:
            series.name = str(names_by_column_id[series.y_column_id])
        sheet.settings.title = self.tr("XY demo")
        return sheet

    def _append_and_activate_sheet(self, sheet: SheetDocument) -> int:
        self._store_active_sheet()
        index = self.workbook.append_sheet(sheet, activate=False)
        self._sheet_sessions[sheet.id] = SheetSessionState()
        self._rebuild_sheet_tabs()
        self.sheet_tab_bar.setCurrentIndex(index)
        return index

    def add_sheet(self, mode: str = SHEET_MODE_GROUPS) -> None:
        name = next_default_sheet_name([sheet.name for sheet in self.workbook.sheets])
        self._append_and_activate_sheet(self._blank_sheet_document(mode, name))
        self._require_recovery_checkpoint()

    def duplicate_sheet(self, index: int = -1) -> None:
        if index < 0:
            index = self.workbook.active_index
        if not 0 <= index < len(self.workbook.sheets):
            return
        self._store_active_sheet()
        source = self.workbook.sheets[index]
        name = unique_sheet_name(
            [sheet.name for sheet in self.workbook.sheets],
            self.tr("{name} Copy").format(name=source.name),
        )
        self._append_and_activate_sheet(source.clone(name=name))
        self._require_recovery_checkpoint()

    def _sheet_name_error_text(self, error: str) -> str:
        if error == "Sheet name cannot be empty.":
            return self.tr("Sheet name cannot be empty.")
        if error.startswith("Sheet name cannot be longer than "):
            return self.tr("Sheet name cannot be longer than 31 characters.")
        if error.startswith("Sheet name cannot contain: "):
            characters = error.removeprefix("Sheet name cannot contain: ")
            return self.tr("Sheet name cannot contain: {characters}").format(characters=characters)
        if error == "Sheet name cannot begin or end with an apostrophe.":
            return self.tr("Sheet name cannot begin or end with an apostrophe.")
        if error == "Sheet names must be unique.":
            return self.tr("Sheet names must be unique.")
        return error

    def rename_sheet(self, index: int = -1) -> None:
        if index < 0:
            index = self.workbook.active_index
        if not 0 <= index < len(self.workbook.sheets):
            return
        sheet = self.workbook.sheets[index]
        name, accepted = QInputDialog.getText(
            self,
            self.tr("Rename Sheet"),
            self.tr("Sheet name"),
            text=sheet.name,
        )
        if not accepted:
            return
        normalized = normalized_sheet_name(name)
        other_names = [item.name for position, item in enumerate(self.workbook.sheets) if position != index]
        error = sheet_name_error(normalized, other_names)
        if error:
            QMessageBox.warning(self, self.tr("Invalid sheet name"), self._sheet_name_error_text(error))
            return
        if normalized == sheet.name:
            return
        sheet.name = normalized
        self._rebuild_sheet_tabs()
        self._require_recovery_checkpoint()

    def delete_sheet(self, index: int = -1, *, confirm: bool = True) -> None:
        if len(self.workbook.sheets) <= 1:
            self.statusBar().showMessage(self.tr("A project must contain at least one sheet."), 3000)
            return
        if index < 0:
            index = self.workbook.active_index
        if not 0 <= index < len(self.workbook.sheets):
            return
        sheet = self.workbook.sheets[index]
        if confirm:
            answer = QMessageBox.question(
                self,
                self.tr("Delete Sheet"),
                self.tr('Delete sheet "{name}"? This cannot be undone.').format(name=sheet.name),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                return
        deleting_active = sheet.id == self.workbook.active_sheet_id
        if deleting_active:
            self._store_active_sheet()
        self.workbook.remove_sheet(index)
        self._sheet_sessions.pop(sheet.id, None)
        self._xy_fit_results_by_sheet.pop(sheet.id, None)
        self._xy_fit_signatures_by_sheet.pop(sheet.id, None)
        self._xy_fit_inflight_signatures.pop(sheet.id, None)
        if deleting_active:
            self._load_active_sheet()
        self._rebuild_sheet_tabs()
        self._require_recovery_checkpoint()

    def move_sheet(self, source: int, destination: int) -> None:
        if self._switching_sheet or source == destination:
            return
        self._store_active_sheet()
        self.workbook.move_sheet(source, destination)
        self._update_sheet_tab_texts()
        self._require_recovery_checkpoint()

    def _move_sheet_from_menu(self, index: int, destination: int) -> None:
        if 0 <= index < len(self.workbook.sheets) and 0 <= destination < len(self.workbook.sheets):
            self.sheet_tab_bar.moveTab(index, destination)

    def _populate_sheet_menu(self, menu: QMenu, index: int) -> None:
        new_menu = QMenu(self.tr("New"), menu)
        menu.addMenu(new_menu)
        menu._easygraph_submenus = [
            *getattr(menu, "_easygraph_submenus", []),
            new_menu,
        ]
        self._populate_sheet_type_actions(new_menu, self.add_sheet)
        duplicate_action = menu.addAction(self.tr("Duplicate Sheet"))
        duplicate_action.triggered.connect(lambda _checked=False, target=index: self.duplicate_sheet(target))
        rename_action = menu.addAction(self.tr("Rename Sheet"))
        rename_action.triggered.connect(lambda _checked=False, target=index: self.rename_sheet(target))
        delete_action = menu.addAction(self.tr("Delete Sheet"))
        delete_action.setEnabled(len(self.workbook.sheets) > 1)
        delete_action.triggered.connect(lambda _checked=False, target=index: self.delete_sheet(target))
        menu.addSeparator()
        move_left = menu.addAction(self.tr("Move Left"))
        move_left.setEnabled(index > 0)
        move_left.triggered.connect(lambda _checked=False, target=index: self._move_sheet_from_menu(target, target - 1))
        move_right = menu.addAction(self.tr("Move Right"))
        move_right.setEnabled(index < len(self.workbook.sheets) - 1)
        move_right.triggered.connect(lambda _checked=False, target=index: self._move_sheet_from_menu(target, target + 1))

    def show_sheet_context_menu(self, position) -> None:
        index = self.sheet_tab_bar.tabAt(position)
        if index < 0:
            return
        menu = QMenu(self)
        self._populate_sheet_menu(menu, index)
        menu.exec(self.sheet_tab_bar.mapToGlobal(position))

    def show_sheet_menu(self) -> None:
        menu = QMenu(self)
        self._populate_sheet_menu(menu, self.workbook.active_index)
        menu.addSeparator()
        for index, sheet in enumerate(self.workbook.sheets):
            action = menu.addAction(sheet.name)
            action.setCheckable(True)
            action.setChecked(sheet.id == self.workbook.active_sheet_id)
            action.triggered.connect(lambda _checked=False, target=index: self.sheet_tab_bar.setCurrentIndex(target))
        menu.exec(self.sheet_menu_button.mapToGlobal(self.sheet_menu_button.rect().bottomLeft()))

    def eventFilter(self, watched, event) -> bool:
        header_context = self._table_header_context_targets.get(watched)
        table_tools = getattr(self, "table_tools", None)
        if table_tools is not None:
            table = header_context[0] if header_context is not None else next(
                (candidate for candidate in (self.table, self.xy_independent_table)
                 if watched is candidate or watched is candidate.viewport()), None
            )
            if table is not None and event.type() in {QEvent.Type.MouseButtonPress, QEvent.Type.FocusIn}:
                table_tools.activate(table)
        if (
            header_context is not None
            and event.type() == QEvent.Type.MouseButtonPress
            and event.button() == Qt.MouseButton.RightButton
        ):
            table, orientation = header_context
            self.show_table_header_context_menu(
                table,
                orientation,
                event.position().toPoint(),
            )
            return True
        if (
            watched is self.xy_series_selection_list.viewport()
            and event.type() == QEvent.Type.MouseButtonPress
            and self._handle_xy_series_selection_mouse_press(event)
        ):
            return True
        if (
            watched in (self.table.viewport(), self.xy_independent_table.viewport())
            and event.type() == QEvent.Type.MouseButtonPress
            and event.button() == Qt.MouseButton.LeftButton
        ):
            table = (
                self.xy_independent_table
                if watched is self.xy_independent_table.viewport()
                else self.table
            )
            self._remember_table_selection_origin(table, "cells")
        table_editor_event = isinstance(watched, QLineEdit) and (
            self.table.isAncestorOf(watched)
            or self.xy_independent_table.isAncestorOf(watched)
        )
        if event.type() == QEvent.KeyPress and (self._table_or_child_has_focus() or table_editor_event):
            if self.handle_table_editor_navigation(event, watched):
                return True
            if event.matches(QKeySequence.Undo):
                self.undo_table_change()
                return True
            if event.matches(QKeySequence.Redo):
                self.redo_table_change()
                return True
            if event.matches(QKeySequence.Copy):
                self.copy_table_selection()
                return True
            if event.matches(QKeySequence.Paste):
                self.paste_table_selection()
                return True
            if event.matches(QKeySequence.Cut):
                self.cut_table_selection()
                return True
            if event.matches(QKeySequence.Delete):
                self.clear_table_selection()
                return True
        return super().eventFilter(watched, event)

    def _handle_table_delegate_navigation(self, editor: QWidget, event) -> None:
        if self.handle_table_editor_navigation(event, editor):
            event.accept()

    def _table_or_child_has_focus(self) -> bool:
        focus = QApplication.focusWidget()
        return (
            focus is self.table
            or self.table.isAncestorOf(focus)
            or focus is self.xy_independent_table
            or self.xy_independent_table.isAncestorOf(focus)
        )

    def handle_table_editor_navigation(self, event: QKeyEvent, editor: QWidget | None = None) -> bool:
        if isinstance(editor, QLineEdit) and self.xy_independent_table.isAncestorOf(editor):
            controller = self._xy_paired_controller
        elif isinstance(editor, QLineEdit) and self.table.isAncestorOf(editor):
            controller = self._table_controller
        else:
            controller = self._active_table_controller()
            editor = QApplication.focusWidget()
        return controller.handle_editor_navigation(event, editor)

    def table_snapshot(self) -> dict:
        return self._table_controller.snapshot()

    def restore_table_snapshot(self, snapshot: dict) -> None:
        self._table_controller.restore_snapshot(snapshot)

    def reset_table_history(self) -> None:
        self._table_controller.reset_history()
        if self._is_xy_sheet():
            self._xy_paired_controller.reset_history()

    def record_table_history_change(self, before: dict | None = None) -> None:
        self._table_controller.record_history_change(before)

    def _run_table_history_mutation(self, mutate, after=None):
        return self._table_controller.run_history_mutation(mutate, after)

    def _run_table_block_mutation(self, positions, mutate, after=None):
        return self._table_controller.run_block_mutation(positions, mutate, after)

    def _run_table_settings_mutation(self, mutate, after=None):
        return self._table_controller.run_settings_mutation(mutate, after)

    def update_table_history_actions(self) -> None:
        self._active_table_controller().update_history_actions()

    def _apply_table_history_action_state(self, can_undo: bool, can_redo: bool) -> None:
        if hasattr(self, "undo_table_action"):
            self.undo_table_action.setEnabled(can_undo)
        if hasattr(self, "redo_table_action"):
            self.redo_table_action.setEnabled(can_redo)
        if hasattr(self, "table_tools"):
            self.table_tools.update_state()

    def undo_table_change(self) -> None:
        self._active_table_controller().undo()
        if self._is_xy_sheet():
            self._sync_xy_views_to_sheet()
        self._refresh_table_capacity()

    def redo_table_change(self) -> None:
        self._active_table_controller().redo()
        if self._is_xy_sheet():
            self._sync_xy_views_to_sheet()
        self._refresh_table_capacity()

    def _apply_table_history_controls(self) -> None:
        if hasattr(self, "show_legend"):
            was_blocked = self.show_legend.blockSignals(True)
            try:
                self.show_legend.setChecked(self.settings.show_legend)
            finally:
                self.show_legend.blockSignals(was_blocked)
        self._apply_custom_overlay_visibility_to_controls()

    def _apply_custom_overlay_visibility_to_controls(self) -> None:
        if not hasattr(self, "extra_custom_overlay"):
            return
        self.extra_custom_overlay.blockSignals(True)
        self.custom_overlay_count.blockSignals(True)
        try:
            self.extra_custom_overlay.setChecked(self.settings.extra_custom_overlay)
            self.custom_overlay_count.setValue(max(1, len(self.settings.custom_overlay_series), self.settings.custom_overlay_count))
        finally:
            self.custom_overlay_count.blockSignals(False)
            self.extra_custom_overlay.blockSignals(False)
        self._sync_custom_overlay_visibility()

    def _sync_custom_overlay_visibility_to_controls(self) -> None:
        self._apply_custom_overlay_visibility_to_controls()
        self._update_dependent_control_states()

    def _ensure_active_xy_table_layout(self) -> None:
        sheet = self.workbook.active_sheet
        if sheet.mode != SHEET_MODE_XY:
            return
        ensure_xy_table_layout(sheet.xy_settings, sheet.column_ids)

    def _active_xy_shared_table(self) -> XYSharedTableSpec | None:
        sheet = self.workbook.active_sheet
        if sheet.mode != SHEET_MODE_XY:
            return None
        active_id = sheet.xy_settings.active_shared_table_id
        return next(
            (
                table
                for table in sheet.xy_settings.shared_tables
                if table.id == active_id
            ),
            None,
        )

    def _set_xy_workspace_headers(self) -> None:
        shared_count = len(self._active_xy_shared_column_ids)
        shared_labels = [
            "X" if column == 0 else f"{column}Y"
            for column in range(shared_count)
        ]
        matched = ", ".join(shared_labels[1:])
        shared_tooltips = [
            self.tr("Matches: {series}").format(series=matched)
            if column == 0 and matched
            else ""
            for column in range(shared_count)
        ]
        self.table.table_model.set_horizontal_headers(
            shared_labels,
            shared_tooltips,
        )

        paired_labels = []
        for column in range(len(self._active_xy_paired_column_ids)):
            pair_number = column // 2 + 1
            paired_labels.append(
                f"{pair_number}X" if column % 2 == 0 else f"{pair_number}Y"
            )
        paired_tooltips = [
            self.tr("Matches: {series}").format(series=f"{column // 2 + 1}Y")
            if column % 2 == 0
            else ""
            for column in range(len(paired_labels))
        ]
        self.xy_independent_table.table_model.set_horizontal_headers(
            paired_labels,
            paired_tooltips,
        )

    def _rebuild_xy_shared_tabs(self) -> None:
        sheet = self.workbook.active_sheet
        tab_bar = self.ui.xySharedTabBar
        blocked = tab_bar.blockSignals(True)
        try:
            while tab_bar.count():
                tab_bar.removeTab(tab_bar.count() - 1)
            active_index = -1
            for index, table in enumerate(sheet.xy_settings.shared_tables):
                tab_bar.addTab(table.name)
                tab_bar.setTabData(index, table.id)
                if table.id == sheet.xy_settings.active_shared_table_id:
                    active_index = index
            if active_index >= 0:
                tab_bar.setCurrentIndex(active_index)
        finally:
            tab_bar.blockSignals(blocked)
        self.ui.removeXYSharedTableButton.setEnabled(tab_bar.count() > 0)

    def _load_xy_workspace_views(self) -> None:
        sheet = self.workbook.active_sheet
        if sheet.mode != SHEET_MODE_XY:
            return
        self._ensure_active_xy_table_layout()
        self._ensure_xy_spare_columns()
        active_table = self._active_xy_shared_table()
        self._active_xy_shared_column_ids = list(
            shared_table_column_ids(sheet.xy_settings, active_table)
            if active_table is not None
            else ()
        )
        self._active_xy_paired_column_ids = list(
            paired_xy_column_ids(sheet.xy_settings)
        )
        self._loading_xy_workspace = True
        try:
            shared_frame = dataframe_with_trailing_blank_row(
                dataframe_column_subset(
                    sheet.dataframe,
                    sheet.column_ids,
                    self._active_xy_shared_column_ids,
                ),
                preserve_existing=True,
            )
            paired_frame = dataframe_with_trailing_blank_row(
                dataframe_column_subset(
                    sheet.dataframe,
                    sheet.column_ids,
                    self._active_xy_paired_column_ids,
                ),
                preserve_existing=True,
            )
            self._table_controller.set_dataframe(shared_frame, [])
            self._xy_paired_controller.set_dataframe(paired_frame, [])
            self._rebuild_xy_shared_tabs()
            self._set_xy_workspace_headers()
        finally:
            self._loading_xy_workspace = False

    def _sync_xy_controller_to_sheet(
        self,
        controller: TableController,
        column_ids: list[str],
    ) -> None:
        if self._loading_xy_workspace or not column_ids:
            return
        sheet = self.workbook.active_sheet
        if sheet.mode != SHEET_MODE_XY:
            return
        sheet.dataframe = replace_dataframe_columns(
            sheet.dataframe,
            sheet.column_ids,
            controller.dataframe(),
            column_ids,
        )

    def _sync_xy_views_to_sheet(self) -> None:
        sheet = self.workbook.active_sheet
        if sheet.mode != SHEET_MODE_XY or self._loading_xy_workspace:
            return
        self._sync_xy_controller_to_sheet(
            self._table_controller,
            self._active_xy_shared_column_ids,
        )
        self._sync_xy_controller_to_sheet(
            self._xy_paired_controller,
            self._active_xy_paired_column_ids,
        )
        sheet.dataframe = dataframe_with_trailing_blank_row(
            sheet.dataframe,
            preserve_existing=True,
        )
        names_by_column_id = {
            column_id: str(sheet.dataframe.columns[index])
            for index, column_id in enumerate(sheet.column_ids)
        }
        for series in sheet.xy_settings.series:
            if series.y_column_id in names_by_column_id:
                series.name = names_by_column_id[series.y_column_id]

    def set_table_dataframe(
        self,
        df: pd.DataFrame,
        overlay_series: list[dict] | None = None,
        *,
        restore_group_capacity: bool = False,
    ) -> None:
        if self._is_xy_sheet():
            self.workbook.active_sheet.dataframe = df.copy(deep=True)
            self._load_xy_workspace_views()
            return
        sheet = self.workbook.active_sheet
        sheet.dataframe = df.copy(deep=True)
        if not restore_group_capacity:
            source_ids = df.attrs.get("group_column_ids")
            sheet.column_ids = list(source_ids) if isinstance(source_ids, (list, tuple)) and len(source_ids) == len(df.columns) else [new_column_id() for _column in df.columns]
            sheet.grouping = grouping_from_dict(df.attrs.get("grouping"), sheet.column_ids)
            self._group_auto_spare_names.pop(sheet.id, None)
            (
                self.settings.manual_group_order,
                self.settings.group_hidden,
            ) = sync_group_order_state(
                [str(column) for column in df.columns],
                self.settings.manual_group_order,
                self.settings.group_hidden,
            )
        self._table_controller.set_dataframe(df, overlay_series)
        self._table_controller._reconcile_sheet_column_ids()
        if restore_group_capacity:
            self._restore_group_spare_provenance()
        self._ensure_group_table_capacity(
            minimum_columns=3,
            minimum_sample_rows=DEFAULT_GROUP_TABLE_ROWS,
        )
        sheet.dataframe = self._table_controller.dataframe()
        self.refresh_analysis_results(self._user_group_dataframe())

    def table_dataframe(self) -> pd.DataFrame:
        if self._is_xy_sheet():
            self._sync_xy_views_to_sheet()
            return self.workbook.active_sheet.dataframe.copy(deep=True)
        return self._table_controller.dataframe()

    @staticmethod
    def _without_trailing_blank_rows(dataframe: pd.DataFrame) -> pd.DataFrame:
        row_count = len(dataframe)
        while row_count > 0 and all(
            pd.isna(value) or not str(value).strip()
            for value in dataframe.iloc[row_count - 1]
        ):
            row_count -= 1
        return dataframe.iloc[:row_count].reset_index(drop=True)

    def _user_group_dataframe(
        self,
        dataframe: pd.DataFrame | None = None,
    ) -> pd.DataFrame:
        if dataframe is None:
            dataframe = self._table_controller.dataframe()
        else:
            dataframe = dataframe.copy(deep=True)
        if (
            len(dataframe.columns)
            and self._group_last_column_is_auto_spare()
        ):
            dataframe = dataframe.iloc[:, :-1]
        dataframe = self._without_trailing_blank_rows(dataframe)
        dataframe = attach_group_metadata(dataframe, self.workbook.active_sheet.column_ids[:len(dataframe.columns)])
        dataframe.attrs["grouping"] = asdict(self.workbook.active_sheet.grouping)
        return dataframe

    def _user_table_dataframe(self) -> pd.DataFrame:
        if self._is_xy_sheet():
            return self.table_dataframe()
        return self._user_group_dataframe()

    @classmethod
    def _user_group_sheet_dataframe(
        cls,
        sheet: SheetDocument,
    ) -> pd.DataFrame:
        dataframe = sheet.dataframe.copy(deep=True)
        if len(dataframe.columns):
            name = str(dataframe.columns[-1]).strip()
            default_named = (
                name.startswith("Group ")
                and name.removeprefix("Group ").isdigit()
            )
            values = dataframe.iloc[:, -1]
            is_spare = (
                default_named
                and not any(key in sheet.settings.manual_group_order or key in sheet.settings.group_hidden or key in sheet.settings.custom_colors for key in (name, sheet.column_ids[-1]))
                and parent_for_column(sheet.grouping, sheet.column_ids[-1]) is None
                and all(
                    pd.isna(value) or not str(value).strip()
                    for value in values
                )
            )
            if is_spare:
                dataframe = dataframe.iloc[:, :-1]
        dataframe = cls._without_trailing_blank_rows(dataframe)
        dataframe = attach_group_metadata(dataframe, sheet.column_ids[:len(dataframe.columns)])
        dataframe.attrs["grouping"] = asdict(sheet.grouping)
        return dataframe

    def custom_overlay_row_count(self) -> int:
        return self._table_controller.overlay_row_count()

    def sample_start_row(self) -> int:
        return self._table_controller.sample_start_row()

    def custom_overlay_series_from_table(self) -> list[dict]:
        series = self._table_controller.overlay_series_from_table()
        if self._is_xy_sheet():
            return series
        user_names = set(self._group_user_keys())
        return [
            {
                **item,
                "values": {
                    name: value
                    for name, value in item.get("values", {}).items()
                    if name in user_names
                },
            }
            for item in series
        ]

    def sync_custom_overlay_rows(self, existing_series: list[dict] | None = None) -> None:
        target_series = list(
            self.settings.custom_overlay_series
            if existing_series is None
            else existing_series
        )
        if self.custom_overlay_row_count() == len(target_series):
            self.settings.custom_overlay_series = target_series
            self.settings.custom_overlay_count = max(1, len(self.settings.custom_overlay_series))
            self._sync_custom_overlay_visibility()
            return
        df = self.table_dataframe()
        self.settings.custom_overlay_series = target_series
        self.settings.custom_overlay_count = max(1, len(self.settings.custom_overlay_series))
        self._sync_custom_overlay_visibility()
        self.set_table_dataframe(
            df,
            self.settings.custom_overlay_series,
            restore_group_capacity=True,
        )

    def _sync_custom_overlay_visibility(self) -> None:
        count = len(self.settings.custom_overlay_series)
        self.settings.custom_overlay_hidden = normalized_hidden_overlay_indexes(self.settings.custom_overlay_hidden, count)

    def update_row_headers(self) -> None:
        self.refresh_table_structure()

    def table_selection_tsv(self) -> str:
        data = self._table_clipboard_selection(self._active_table_controller())
        return clipboard_table_to_tsv(data) if data is not None else ""

    def _table_clipboard_selection(self, controller):
        column_limit = None
        if not self._is_xy_sheet():
            column_limit = controller.table.table_model.columnCount() - int(
                self._group_last_column_is_auto_spare()
            )
        return controller.copy_selection_data(column_limit=column_limit)

    @staticmethod
    def _write_table_clipboard(data: ClipboardTable) -> None:
        set_table_clipboard_mime(
            clipboard_table_to_tsv(data), clipboard_table_to_html(data),
        )

    def copy_table_selection(self, table=None) -> None:
        controller = (
            self._active_table_controller()
            if table is None
            else self._controller_for_table(table)
        )
        data = self._table_clipboard_selection(controller)
        if data is not None:
            self._write_table_clipboard(data)

    def cut_table_selection(self, table=None) -> None:
        controller = (
            self._active_table_controller()
            if table is None
            else self._controller_for_table(table)
        )
        data = self._table_clipboard_selection(controller)
        text = controller.cut_selection()
        self._apply_table_history_action_state(
            controller.history.can_undo,
            controller.history.can_redo,
        )
        if self._is_xy_sheet():
            self._sync_xy_views_to_sheet()
        self._refresh_table_capacity()
        if text and data is not None:
            self._write_table_clipboard(data)

    def _remember_table_selection_origin(self, table, scope: str) -> None:
        self._table_selection_origins[table] = scope
        if scope in {"cells", "rows", "columns"}:
            table.horizontalHeader().clear_parent_selection()

    def _table_selection_scope(self, table) -> str:
        selection_model = table.selectionModel()
        if selection_model is None:
            return "cells"
        selected_rows = bool(selection_model.selectedRows())
        selected_columns = bool(selection_model.selectedColumns())
        remembered = self._table_selection_origins.get(table)
        if remembered == "cells":
            return "cells"
        if remembered == "rows" and selected_rows:
            return "rows"
        if remembered == "columns" and selected_columns:
            return "columns"
        if selected_rows and not selected_columns:
            return "rows"
        if selected_columns and not selected_rows:
            return "columns"
        return "cells"

    def _selection_uses_sample_rows(
        self,
        table,
        selection: TableSelection | None = None,
    ) -> bool:
        selection = table_selection(table) if selection is None else selection
        if selection.is_empty:
            return False
        return selection.top >= self._controller_for_table(table).sample_start_row()

    def table_context_menu(
        self,
        table=None,
        context_scope: str | None = None,
    ) -> QMenu:
        table = self.table if table is None else table
        if context_scope is None:
            context_scope = self._table_selection_scope(table)
        if context_scope not in {"cells", "rows", "columns"}:
            raise ValueError(f"Unknown table context scope: {context_scope}")
        selection = table_selection(table)
        has_selection = not selection.is_empty
        sample_rows_selected = self._selection_uses_sample_rows(table, selection)
        menu = QMenu(table)
        copy_action = menu.addAction(self.tr("Copy"))
        copy_action.setShortcut(QKeySequence.Copy)
        copy_action.setEnabled(has_selection)
        copy_action.triggered.connect(
            lambda _checked=False, target=table: self.copy_table_selection(target)
        )
        paste_action = menu.addAction(self.tr("Paste"))
        paste_action.setShortcut(QKeySequence.Paste)
        paste_action.triggered.connect(
            lambda _checked=False, target=table: self.paste_table_selection(target)
        )
        cut_action = menu.addAction(self.tr("Cut"))
        cut_action.setShortcut(QKeySequence.Cut)
        cut_action.setEnabled(has_selection)
        cut_action.triggered.connect(
            lambda _checked=False, target=table: self.cut_table_selection(target)
        )
        clear_action = menu.addAction(self.tr("Clear Contents"))
        clear_action.setShortcut(QKeySequence.Delete)
        clear_action.setEnabled(has_selection)
        clear_action.triggered.connect(
            lambda _checked=False, target=table: self.clear_table_selection(target)
        )

        menu.addSeparator()
        if context_scope == "rows":
            insert_action = menu.addAction(self.tr("Insert"))
            insert_action.setEnabled(
                sample_rows_selected and selection.is_rectangular
            )
            insert_action.triggered.connect(
                lambda _checked=False, target=table: self.insert_table_structure(
                    "entire_row",
                    target,
                )
            )
            delete_action = menu.addAction(self.tr("Delete"))
            delete_action.setEnabled(
                sample_rows_selected and selection.is_rectangular
            )
            delete_action.triggered.connect(
                lambda _checked=False, target=table: self.delete_table_structure(
                    "entire_row",
                    target,
                )
            )
            return menu

        if context_scope == "columns":
            if self._is_xy_sheet():
                insert_action = menu.addAction(self.tr("Insert"))
                insert_action.setEnabled(selection.is_rectangular)
                insert_action.triggered.connect(
                    lambda _checked=False, target=table: self.insert_table_structure(
                        "entire_column",
                        target,
                    )
                )
            else:
                self.grouping_controls.update_actions()
                menu.addAction(self.grouping_controls.action("insert_subgroup_left"))
                menu.addAction(self.grouping_controls.action("insert_subgroup_right"))
            delete_action = menu.addAction(self.tr("Delete"))
            delete_action.setEnabled(self._can_delete_selected_columns(table))
            delete_action.triggered.connect(
                lambda _checked=False, target=table: self.delete_table_structure(
                    "entire_column",
                    target,
                )
            )
            if self._is_xy_sheet() and table is self.xy_independent_table:
                pair_hint = self.tr("Applies to the entire X/Y pair")
                menu.setToolTipsVisible(True)
                for action in (insert_action, delete_action):
                    action.setToolTip(pair_hint)
                    action.setStatusTip(pair_hint)
            if not self._is_xy_sheet():
                self.grouping_controls.add_menu(menu, context_scope)
            return menu

        insert_menu = QMenu(self.tr("Insert"), menu)
        menu.addMenu(insert_menu)
        shift_down_action = insert_menu.addAction(self.tr("Shift Cells Down"))
        shift_down_action.setEnabled(
            sample_rows_selected and selection.is_rectangular
        )
        shift_down_action.triggered.connect(
            lambda _checked=False, target=table: self.insert_table_structure(
                "cells_down",
                target,
            )
        )
        insert_row_action = insert_menu.addAction(self.tr("Entire Row"))
        insert_row_action.setEnabled(
            sample_rows_selected and selection.is_rectangular
        )
        insert_row_action.triggered.connect(
            lambda _checked=False, target=table: self.insert_table_structure(
                "entire_row",
                target,
            )
        )
        if self._is_xy_sheet():
            insert_column_action = insert_menu.addAction(self.tr("Entire Column"))
            insert_column_action.setEnabled(
                selection.is_empty or selection.is_rectangular
            )
            insert_column_action.triggered.connect(
                lambda _checked=False, target=table: self.insert_table_structure(
                    "entire_column",
                    target,
                )
            )
        else:
            self.grouping_controls.update_actions()
            insert_menu.addAction(self.grouping_controls.action("insert_subgroup_left"))
            insert_menu.addAction(self.grouping_controls.action("insert_subgroup_right"))

        delete_menu = QMenu(self.tr("Delete"), menu)
        menu.addMenu(delete_menu)
        menu._easygraph_submenus = [insert_menu, delete_menu]
        shift_up_action = delete_menu.addAction(self.tr("Shift Cells Up"))
        shift_up_action.setEnabled(sample_rows_selected and selection.is_rectangular)
        shift_up_action.triggered.connect(
            lambda _checked=False, target=table: self.delete_table_structure(
                "cells_up",
                target,
            )
        )
        delete_row_action = delete_menu.addAction(self.tr("Entire Row"))
        delete_row_action.setEnabled(
            sample_rows_selected and selection.is_rectangular
        )
        delete_row_action.triggered.connect(
            lambda _checked=False, target=table: self.delete_table_structure(
                "entire_row",
                target,
            )
        )
        delete_column_action = delete_menu.addAction(self.tr("Entire Column"))
        delete_column_action.setEnabled(self._can_delete_selected_columns(table))
        delete_column_action.triggered.connect(
            lambda _checked=False, target=table: self.delete_table_structure(
                "entire_column",
                target,
            )
        )
        if self._is_xy_sheet() and table is self.xy_independent_table:
            pair_hint = self.tr("Applies to the entire X/Y pair")
            menu.setToolTipsVisible(True)
            insert_menu.setToolTipsVisible(True)
            delete_menu.setToolTipsVisible(True)
            for action in (
                shift_down_action,
                insert_column_action,
                shift_up_action,
                delete_column_action,
            ):
                action.setToolTip(pair_hint)
                action.setStatusTip(pair_hint)
        if not self._is_xy_sheet():
            self.grouping_controls.add_menu(menu, context_scope)
        return menu

    def show_table_context_menu(self, position) -> None:
        self._show_table_viewport_context_menu(self.table, position)

    def show_xy_independent_context_menu(self, position) -> None:
        self._show_table_viewport_context_menu(self.xy_independent_table, position)

    def _show_table_viewport_context_menu(self, table, position) -> None:
        index = table.indexAt(position)
        selection_model = table.selectionModel()
        if index.isValid():
            if not selection_model.isSelected(index):
                self._remember_table_selection_origin(table, "cells")
                selection_model.setCurrentIndex(
                    index,
                    QItemSelectionModel.SelectionFlag.ClearAndSelect,
                )
            else:
                selection_model.setCurrentIndex(
                    index,
                    QItemSelectionModel.SelectionFlag.NoUpdate,
                )
        table.setFocus()
        if hasattr(self, "table_tools"):
            self.table_tools.activate(table)
        scope = self._table_selection_scope(table)
        menu = self.table_context_menu(table, scope)
        menu.exec(table.viewport().mapToGlobal(position))

    def show_table_header_context_menu(
        self,
        table,
        orientation: Qt.Orientation,
        position,
    ) -> None:
        header = (
            table.horizontalHeader()
            if orientation == Qt.Orientation.Horizontal
            else table.verticalHeader()
        )
        if hasattr(self, "table_tools"):
            self.table_tools.activate(table)
        if orientation == Qt.Horizontal and not self._is_xy_sheet():
            columns = header.parent_columns_at(position)
            if columns:
                self.grouping_controls.header_menu(columns[0], header.mapToGlobal(position))
                return
        section = header.logicalIndexAt(position)
        if section < 0:
            return
        selection_model = table.selectionModel()
        if orientation == Qt.Orientation.Horizontal:
            self._remember_table_selection_origin(table, "columns")
            selected = {index.column() for index in selection_model.selectedColumns()}
            if section not in selected:
                table.selectColumn(section)
            current_row = table.currentIndex().row()
            if current_row < 0 and table.table_model.rowCount():
                current_row = min(
                    self._controller_for_table(table).sample_start_row(),
                    table.table_model.rowCount() - 1,
                )
            if current_row >= 0:
                selection_model.setCurrentIndex(
                    table.table_model.index(current_row, section),
                    QItemSelectionModel.SelectionFlag.NoUpdate,
                )
            scope = "columns"
        else:
            self._remember_table_selection_origin(table, "rows")
            selected = {index.row() for index in selection_model.selectedRows()}
            if section not in selected:
                table.selectRow(section)
            current_column = table.currentIndex().column()
            if current_column < 0 and table.table_model.columnCount():
                current_column = 0
            if current_column >= 0:
                selection_model.setCurrentIndex(
                    table.table_model.index(section, current_column),
                    QItemSelectionModel.SelectionFlag.NoUpdate,
                )
            scope = "rows"
        table.setFocus()
        menu = self.table_context_menu(table, scope)
        menu.exec(header.viewport().mapToGlobal(position))

    @staticmethod
    def _current_or_selected_columns(
        table,
        selection: TableSelection | None = None,
    ) -> tuple[int, ...]:
        selection = table_selection(table) if selection is None else selection
        if selection.columns:
            return selection.columns
        current_column = table.currentIndex().column()
        if 0 <= current_column < table.table_model.columnCount():
            return (current_column,)
        return ()

    def _structure_columns(
        self,
        table,
        selection: TableSelection | None = None,
    ) -> tuple[int, ...]:
        columns = self._current_or_selected_columns(table, selection)
        if self._is_xy_sheet() and table is self.xy_independent_table:
            return expanded_pair_columns(
                columns,
                table.table_model.columnCount(),
            )
        return columns

    def _can_delete_selected_columns(self, table) -> bool:
        selection = table_selection(table)
        if not selection.is_empty and not selection.is_rectangular:
            return False
        columns = self._structure_columns(table, selection)
        if not self._is_xy_sheet():
            return bool(columns or table.table_model.columnCount())
        if table is self.xy_independent_table:
            return bool(columns)
        return bool(columns) and 0 not in columns

    def _finish_table_model_structure_mutation(
        self,
        controller: TableController,
        result: object,
    ) -> None:
        if self._is_xy_sheet():
            controller.history_suspended = True
            try:
                ensure_trailing_blank_row(
                    controller.table.table_model,
                    controller.sample_start_row(),
                )
            finally:
                controller.history_suspended = False
            controller.invalidate_dataframe()
        else:
            self._ensure_group_table_capacity(refresh_structure=False)
        controller._after_structure_mutation(
            result,
            sync_order=not self._is_xy_sheet(),
        )
        if self._is_xy_sheet():
            column_ids = (
                self._active_xy_paired_column_ids
                if controller is self._xy_paired_controller
                else self._active_xy_shared_column_ids
            )
            self._sync_xy_controller_to_sheet(controller, column_ids)
            self.workbook.active_sheet.dataframe = dataframe_with_trailing_blank_row(
                self.workbook.active_sheet.dataframe,
                preserve_existing=True,
            )
            self._record_recovery_sheet_state()
            self.schedule_render()
        else:
            self.sync_manual_group_order()

    def _run_model_structure_mutation(self, table, mutate) -> bool:
        controller = self._controller_for_table(table)
        changed = controller.run_history_mutation(
            mutate,
            after=lambda result: self._finish_table_model_structure_mutation(
                controller,
                result,
            ),
        )
        self._apply_table_history_action_state(
            controller.history.can_undo,
            controller.history.can_redo,
        )
        if changed and not self._is_xy_sheet():
            self._update_chart_specific_controls()
        return bool(changed)

    def insert_table_structure(self, mode: str, table=None) -> bool:
        table = self.table if table is None else table
        if mode not in {"cells_down", "entire_row", "entire_column"}:
            raise ValueError(f"Unknown table insertion mode: {mode}")
        selection = table_selection(table)
        if mode == "entire_column":
            return self._insert_entire_columns(table, selection)
        if (
            selection.is_empty
            or not selection.is_rectangular
            or not self._selection_uses_sample_rows(table, selection)
        ):
            return False
        if mode == "entire_row":
            changed = self._run_model_structure_mutation(
                table,
                lambda: insert_table_rows(
                    table.table_model,
                    selection.top,
                    selection.row_span,
                ),
            )
        else:
            columns = self._structure_columns(table, selection)
            changed = self._run_model_structure_mutation(
                table,
                lambda: shift_cells_down(
                    table.table_model,
                    selection.top,
                    columns,
                    selection.row_span,
                ),
            )
        if changed:
            table.setCurrentIndex(
                table.table_model.index(selection.top, max(selection.left, 0))
            )
            if self._is_xy_sheet() and mode == "cells_down":
                self._schedule_table_capacity_update()
        return changed

    def insert_table_structure_relative(self, mode: str, after: bool = False, table=None) -> bool:
        """Insert beside the explicit table selection, even when a tool owns focus."""
        table = self.table if table is None else table
        if not after:
            return self.insert_table_structure(mode, table)
        selection = table_selection(table)
        if mode == "entire_column":
            if self._is_xy_sheet():
                return self._insert_xy_columns(table, selection, after=True)
            return self.grouping_controls.insert_selected_subgroup(True)
        if mode != "entire_row":
            raise ValueError(f"Unknown relative insertion mode: {mode}")
        if (selection.is_empty or not selection.is_rectangular
                or not self._selection_uses_sample_rows(table, selection)):
            return False
        insertion = selection.bottom + 1
        changed = self._run_model_structure_mutation(
            table,
            lambda: insert_table_rows(table.table_model, insertion, selection.row_span),
        )
        if changed:
            table.setCurrentIndex(table.table_model.index(insertion, max(selection.left, 0)))
        return changed

    def delete_table_structure(self, mode: str, table=None) -> bool:
        table = self.table if table is None else table
        if mode not in {"cells_up", "entire_row", "entire_column"}:
            raise ValueError(f"Unknown table deletion mode: {mode}")
        selection = table_selection(table)
        if mode == "entire_column":
            return self._delete_entire_columns(table, selection)
        if (
            selection.is_empty
            or not selection.is_rectangular
            or not self._selection_uses_sample_rows(table, selection)
        ):
            return False
        if mode == "entire_row":
            changed = self._run_model_structure_mutation(
                table,
                lambda: self._delete_rows_keep_sample_capacity(
                    table,
                    selection.top,
                    selection.row_span,
                ),
            )
        else:
            columns = self._structure_columns(table, selection)
            changed = self._run_model_structure_mutation(
                table,
                lambda: shift_cells_up(
                    table.table_model,
                    selection.top,
                    columns,
                    selection.row_span,
                ),
            )
        if changed and table.table_model.rowCount() and table.table_model.columnCount():
            table.setCurrentIndex(
                table.table_model.index(
                    min(selection.top, table.table_model.rowCount() - 1),
                    min(max(selection.left, 0), table.table_model.columnCount() - 1),
                )
            )
            if self._is_xy_sheet() and mode == "cells_up":
                self._schedule_table_capacity_update()
        return changed

    def _delete_rows_keep_sample_capacity(
        self,
        table,
        row: int,
        count: int,
    ) -> bool:
        changed = delete_table_rows(table.table_model, row, count)
        sample_start = self._controller_for_table(table).sample_start_row()
        if changed and table.table_model.rowCount() <= sample_start:
            insert_table_rows(table.table_model, table.table_model.rowCount(), 1)
        return changed

    def _next_group_column_names(self, count: int) -> list[str]:
        existing = set(self._table_controller.group_names())
        names: list[str] = []
        number = self.table.table_model.columnCount() + 1
        while len(names) < count:
            candidate = f"Group {number}"
            number += 1
            if candidate in existing:
                continue
            existing.add(candidate)
            names.append(candidate)
        return names

    def _insert_group_columns(
        self,
        selection: TableSelection,
    ) -> bool:
        model = self.table.table_model
        columns = self._current_or_selected_columns(self.table, selection)
        insertion = min(columns) if columns else model.columnCount()
        count = len(columns) if columns else 1
        names = self._next_group_column_names(count)
        sheet = self.workbook.active_sheet
        anchor_id = sheet.column_ids[insertion] if insertion < len(sheet.column_ids) else None

        def mutate() -> bool:
            if not model.insertColumns(insertion, count):
                return False
            new_ids = [
                new_column_id() for _index in range(count)
            ]
            sheet.column_ids[insertion:insertion] = new_ids
            if anchor_id is not None:
                for new_id in new_ids:
                    insert_subgroup(sheet.grouping, anchor_id, new_id, after=False)
            for offset, name in enumerate(names):
                model.set_cell_text(0, insertion + offset, name)
            return True

        changed = self._run_model_structure_mutation(self.table, mutate)
        if changed and model.rowCount():
            self.table.setCurrentIndex(model.index(0, insertion))
        return changed

    def _delete_group_columns(
        self,
        selection: TableSelection,
    ) -> bool:
        model = self.table.table_model
        columns = self._current_or_selected_columns(self.table, selection)
        if not columns and model.columnCount():
            columns = (model.columnCount() - 1,)
        columns = tuple(
            column for column in columns if 0 <= column < model.columnCount()
        )
        if not columns:
            return False
        sheet = self.workbook.active_sheet

        def mutate() -> bool:
            changed = False
            for column in sorted(columns, reverse=True):
                changed = model.removeColumns(column, 1) or changed
                if 0 <= column < len(sheet.column_ids):
                    removed_column_id = sheet.column_ids.pop(column)
                    remove_xy_column_references(
                        sheet.xy_settings,
                        {removed_column_id},
                    )
            return changed

        changed = self._run_model_structure_mutation(self.table, mutate)
        if changed and model.rowCount() and model.columnCount():
            self.table.setCurrentIndex(
                model.index(0, min(min(columns), model.columnCount() - 1))
            )
        return changed

    def _xy_column_structure_snapshot(self) -> dict:
        self._sync_xy_views_to_sheet()
        sheet = self.workbook.active_sheet
        return {
            "sheet_id": sheet.id,
            "dataframe": sheet.dataframe.copy(deep=True),
            "column_ids": list(sheet.column_ids),
            "xy_settings": deepcopy(sheet.xy_settings),
            "main_current": (
                self.table.currentIndex().row(),
                self.table.currentIndex().column(),
            ),
            "paired_current": (
                self.xy_independent_table.currentIndex().row(),
                self.xy_independent_table.currentIndex().column(),
            ),
        }

    @staticmethod
    def _xy_snapshot_column_matches(
        current_values: pd.Series,
        source_values: pd.Series,
    ) -> bool:
        row_count = max(len(current_values), len(source_values))
        current = (
            current_values.reset_index(drop=True)
            .reindex(range(row_count), fill_value="")
            .fillna("")
        )
        source = (
            source_values.reset_index(drop=True)
            .reindex(range(row_count), fill_value="")
            .fillna("")
        )
        return current.equals(source)

    @staticmethod
    def _apply_xy_sequence_delta(
        current: list[str] | tuple[str, ...],
        source: list[str] | tuple[str, ...],
        target: list[str] | tuple[str, ...],
    ) -> list[str]:
        """Apply source→target membership changes while retaining later items."""
        source_set = set(source)
        target_set = set(target)
        removed = source_set - target_set
        added = target_set - source_set
        result = [item for item in current if item not in removed]
        for target_index, item in enumerate(target):
            if item not in added or item in result:
                continue
            next_anchor = next(
                (
                    candidate
                    for candidate in target[target_index + 1 :]
                    if candidate in result
                ),
                None,
            )
            if next_anchor is not None:
                result.insert(result.index(next_anchor), item)
                continue
            previous_anchor = next(
                (
                    candidate
                    for candidate in reversed(target[:target_index])
                    if candidate in result
                ),
                None,
            )
            if previous_anchor is None:
                result.append(item)
            else:
                result.insert(result.index(previous_anchor) + 1, item)
        return result

    def _restore_xy_column_structure_snapshot(
        self,
        snapshot: dict,
        source_snapshot: dict,
    ) -> None:
        sheet = next(
            (
                candidate
                for candidate in self.workbook.sheets
                if candidate.id == snapshot["sheet_id"]
            ),
            None,
        )
        if sheet is None:
            return
        target_dataframe = snapshot["dataframe"]
        target_column_ids = list(snapshot["column_ids"])
        source_column_ids = list(source_snapshot["column_ids"])
        restored_column_ids = self._apply_xy_sequence_delta(
            sheet.column_ids,
            source_column_ids,
            target_column_ids,
        )
        current_positions = {
            column_id: index for index, column_id in enumerate(sheet.column_ids)
        }
        target_positions = {
            column_id: index for index, column_id in enumerate(target_column_ids)
        }
        source_dataframe = source_snapshot["dataframe"]
        source_positions = {
            column_id: index
            for index, column_id in enumerate(source_column_ids)
        }
        row_count = max(len(sheet.dataframe), len(target_dataframe))
        restored_columns: list[pd.Series] = []
        restored_names: list[object] = []
        for column_id in restored_column_ids:
            target_index = target_positions.get(column_id)
            if target_index is None:
                current_index = current_positions[column_id]
                restored_columns.append(
                    sheet.dataframe.iloc[:, current_index]
                    .reset_index(drop=True)
                    .reindex(range(row_count), fill_value="")
                )
                restored_names.append(sheet.dataframe.columns[current_index])
                continue
            use_current_values = False
            use_current_name = False
            if column_id in current_positions and column_id in source_positions:
                current_index = current_positions[column_id]
                source_index = source_positions[column_id]
                use_current_values = not self._xy_snapshot_column_matches(
                    sheet.dataframe.iloc[:, current_index],
                    source_dataframe.iloc[:, source_index],
                )
                use_current_name = (
                    sheet.dataframe.columns[current_index]
                    != source_dataframe.columns[source_index]
                )
            if use_current_values:
                values_source = sheet.dataframe
                values_index = current_positions[column_id]
            else:
                values_source = target_dataframe
                values_index = target_index
            restored_columns.append(
                values_source.iloc[:, values_index]
                .reset_index(drop=True)
                .reindex(range(row_count), fill_value="")
            )
            restored_names.append(
                sheet.dataframe.columns[current_positions[column_id]]
                if use_current_name
                else target_dataframe.columns[target_index]
            )
        if restored_columns:
            restored_dataframe = pd.concat(restored_columns, axis=1)
            restored_dataframe.columns = restored_names
        else:
            restored_dataframe = pd.DataFrame(index=range(row_count))

        target_settings = deepcopy(snapshot["xy_settings"])
        source_settings = source_snapshot["xy_settings"]
        current_settings = sheet.xy_settings
        current_series = {series.id: series for series in current_settings.series}
        source_series = {series.id: series for series in source_settings.series}
        target_series_by_id = {
            series.id: series for series in target_settings.series
        }
        restored_series_ids = self._apply_xy_sequence_delta(
            [series.id for series in current_settings.series],
            [series.id for series in source_settings.series],
            [series.id for series in target_settings.series],
        )
        restored_series = []
        for series_id in restored_series_ids:
            if series_id not in target_series_by_id:
                restored_series.append(deepcopy(current_series[series_id]))
                continue
            target_series = target_series_by_id[series_id]
            restored_series_item = deepcopy(target_series)
            current_series_item = current_series.get(target_series.id)
            source_series_item = source_series.get(target_series.id)
            if current_series_item is not None and source_series_item is not None:
                for field_name in target_series.__dataclass_fields__:
                    if getattr(current_series_item, field_name) != getattr(
                        source_series_item,
                        field_name,
                    ):
                        setattr(
                            restored_series_item,
                            field_name,
                            deepcopy(getattr(current_series_item, field_name)),
                        )
            restored_series.append(restored_series_item)
        target_settings.series = restored_series
        current_tables = {
            table.id: table for table in current_settings.shared_tables
        }
        source_tables = {
            table.id: table for table in source_settings.shared_tables
        }
        target_tables = {
            table.id: table for table in target_settings.shared_tables
        }
        restored_table_ids = self._apply_xy_sequence_delta(
            [table.id for table in current_settings.shared_tables],
            [table.id for table in source_settings.shared_tables],
            [table.id for table in target_settings.shared_tables],
        )
        restored_tables = []
        for table_id in restored_table_ids:
            if table_id not in target_tables:
                restored_tables.append(deepcopy(current_tables[table_id]))
                continue
            table = deepcopy(target_tables[table_id])
            if (
                table.id in current_tables
                and table.id in source_tables
                and current_tables[table.id].name != source_tables[table.id].name
            ):
                table.name = current_tables[table.id].name
            if table.id in current_tables and table.id in source_tables:
                table.series_ids = self._apply_xy_sequence_delta(
                    current_tables[table.id].series_ids,
                    source_tables[table.id].series_ids,
                    table.series_ids,
                )
            restored_tables.append(table)
        target_settings.shared_tables = restored_tables
        current_fits = {
            fit_spec.id: fit_spec for fit_spec in current_settings.fit_specs
        }
        source_fits = {
            fit_spec.id: fit_spec for fit_spec in source_settings.fit_specs
        }
        target_fits = {
            fit_spec.id: fit_spec for fit_spec in target_settings.fit_specs
        }
        restored_fit_ids = self._apply_xy_sequence_delta(
            [fit_spec.id for fit_spec in current_settings.fit_specs],
            [fit_spec.id for fit_spec in source_settings.fit_specs],
            [fit_spec.id for fit_spec in target_settings.fit_specs],
        )
        valid_series_ids = {series.id for series in restored_series}
        restored_fits = []
        for fit_id in restored_fit_ids:
            if fit_id not in target_fits:
                restored_fit = deepcopy(current_fits[fit_id])
            else:
                restored_fit = deepcopy(target_fits[fit_id])
                current_fit = current_fits.get(fit_id)
                source_fit = source_fits.get(fit_id)
                if current_fit is not None and source_fit is not None:
                    for field_name in restored_fit.__dataclass_fields__:
                        if getattr(current_fit, field_name) != getattr(
                            source_fit,
                            field_name,
                        ):
                            setattr(
                                restored_fit,
                                field_name,
                                deepcopy(getattr(current_fit, field_name)),
                            )
            if restored_fit.series_id in valid_series_ids:
                restored_fits.append(restored_fit)
        target_settings.fit_specs = restored_fits
        restored_settings = deepcopy(target_settings)
        structural_fields = {
            "series",
            "shared_tables",
            "paired_series_ids",
            "default_x_column_id",
            "active_shared_table_id",
            "fit_specs",
        }
        for field_name in target_settings.__dataclass_fields__:
            if field_name in structural_fields:
                continue
            if getattr(current_settings, field_name) != getattr(
                source_settings,
                field_name,
            ):
                setattr(
                    restored_settings,
                    field_name,
                    deepcopy(getattr(current_settings, field_name)),
                )
        restored_settings.series = target_settings.series
        restored_settings.shared_tables = target_settings.shared_tables
        restored_settings.fit_specs = target_settings.fit_specs
        restored_settings.paired_series_ids = self._apply_xy_sequence_delta(
            current_settings.paired_series_ids,
            source_settings.paired_series_ids,
            target_settings.paired_series_ids,
        )
        default_x_column_id = (
            current_settings.default_x_column_id
            if target_settings.default_x_column_id
            == source_settings.default_x_column_id
            else target_settings.default_x_column_id
        )
        restored_settings.default_x_column_id = (
            default_x_column_id
            if default_x_column_id in restored_column_ids
            else None
        )
        valid_table_ids = {table.id for table in restored_settings.shared_tables}
        restored_settings.active_shared_table_id = (
            current_settings.active_shared_table_id
            if current_settings.active_shared_table_id in valid_table_ids
            else target_settings.active_shared_table_id
        )
        restored_settings.__post_init__()

        sheet.dataframe = restored_dataframe
        sheet.column_ids = restored_column_ids
        sheet.xy_settings = restored_settings
        if sheet.id != self.workbook.active_sheet_id:
            return
        self._load_xy_workspace_views()
        for table, key in (
            (self.table, "main_current"),
            (self.xy_independent_table, "paired_current"),
        ):
            row, column = snapshot[key]
            if table.table_model.rowCount() and table.table_model.columnCount():
                table.setCurrentIndex(
                    table.table_model.index(
                        min(max(row, 0), table.table_model.rowCount() - 1),
                        min(max(column, 0), table.table_model.columnCount() - 1),
                    )
                )
        self._record_recovery_sheet_state()
        self.schedule_render()

    def _run_xy_column_structure_mutation(self, table, mutate) -> bool:
        controller = self._controller_for_table(table)
        before = self._xy_column_structure_snapshot()
        controller.history_suspended = True
        try:
            changed = bool(mutate())
        finally:
            controller.history_suspended = False
        if not changed:
            return False
        after = self._xy_column_structure_snapshot()
        controller.history.record(
            CallbackEdit(
                apply_callback=lambda state=after, source=before: self._restore_xy_column_structure_snapshot(
                    state,
                    source,
                ),
                revert_callback=lambda state=before, source=after: self._restore_xy_column_structure_snapshot(
                    state,
                    source,
                ),
            )
        )
        self._apply_table_history_action_state(
            controller.history.can_undo,
            controller.history.can_redo,
        )
        return True

    def _insert_xy_columns(self, table, selection: TableSelection, *, after: bool = False) -> bool:
        columns = self._current_or_selected_columns(table, selection)
        if table is self.xy_independent_table:
            pair_columns = expanded_pair_columns(
                columns,
                table.table_model.columnCount(),
            )
            pair_indexes = sorted({column // 2 for column in pair_columns})
            pair_index = pair_indexes[0] if pair_indexes else len(
                self.workbook.active_sheet.xy_settings.paired_series_ids
            )
            if after and pair_indexes:
                pair_index = pair_indexes[-1] + 1
            count = len(pair_indexes) or 1

            def mutate() -> bool:
                for offset in range(count):
                    self._insert_xy_pair_at(
                        pair_index + offset,
                        sync_views=False,
                    )
                self._reorder_xy_series_if_table_order()
                self._load_xy_workspace_views()
                self.xy_independent_table.setCurrentIndex(
                    self.xy_independent_table.table_model.index(1, pair_index * 2)
                )
                self._record_recovery_sheet_state()
                self.schedule_render()
                return True

        else:
            shared_table = self._active_xy_shared_table()
            if shared_table is None:
                return False
            series_index = max(0, (min(columns) - 1) if columns else len(shared_table.series_ids))
            if after and columns:
                series_index = max(columns)
            count = len(columns) or 1

            def mutate() -> bool:
                for offset in range(count):
                    self._insert_xy_y_for_table(
                        shared_table,
                        series_index + offset,
                        sync_views=False,
                    )
                self._reorder_xy_series_if_table_order()
                self._load_xy_workspace_views()
                self.table.setCurrentIndex(
                    self.table.table_model.index(1, series_index + 1)
                )
                self._record_recovery_sheet_state()
                self.schedule_render()
                return True

        return self._run_xy_column_structure_mutation(table, mutate)

    def _delete_xy_columns(self, table, selection: TableSelection) -> bool:
        sheet = self.workbook.active_sheet
        columns = self._current_or_selected_columns(table, selection)
        if table is self.table and 0 in columns:
            return False
        if table is self.xy_independent_table:
            pair_columns = expanded_pair_columns(
                columns,
                table.table_model.columnCount(),
            )
            pair_indexes = sorted({column // 2 for column in pair_columns})
            series_by_id = {series.id: series for series in sheet.xy_settings.series}
            selected_series = [
                series_by_id[series_id]
                for index, series_id in enumerate(sheet.xy_settings.paired_series_ids)
                if index in pair_indexes and series_id in series_by_id
            ]
        else:
            shared_table = self._active_xy_shared_table()
            if shared_table is None:
                return False
            series_by_id = {series.id: series for series in sheet.xy_settings.series}
            selected_series = [
                series_by_id[series_id]
                for column in columns
                if column > 0
                and column - 1 < len(shared_table.series_ids)
                and (series_id := shared_table.series_ids[column - 1]) in series_by_id
            ]
        if not selected_series:
            return False
        source_column_ids: list[str] = []
        for series in selected_series:
            if table is self.xy_independent_table and series.x_column_id is not None:
                source_column_ids.append(series.x_column_id)
            source_column_ids.append(series.y_column_id)

        def mutate() -> bool:
            self._remove_xy_source_columns(source_column_ids)
            self._renumber_default_xy_column_names()
            self._reorder_xy_series_if_table_order()
            self._load_xy_workspace_views()
            self._record_recovery_sheet_state()
            self.schedule_render()
            return True

        return self._run_xy_column_structure_mutation(table, mutate)

    def _insert_entire_columns(
        self,
        table,
        selection: TableSelection,
    ) -> bool:
        if not selection.is_empty and not selection.is_rectangular:
            return False
        if self._is_xy_sheet():
            return self._insert_xy_columns(table, selection)
        return self._insert_group_columns(selection)

    def _delete_entire_columns(
        self,
        table,
        selection: TableSelection,
    ) -> bool:
        if not selection.is_empty and not selection.is_rectangular:
            return False
        if not self._can_delete_selected_columns(table):
            return False
        if self._is_xy_sheet():
            return self._delete_xy_columns(table, selection)
        return self._delete_group_columns(selection)

    def analysis_results_context_menu(self) -> QMenu:
        has_selection = bool(
            self.results_table.selectionModel().selectedIndexes()
        )
        menu = QMenu(self.results_table)
        copy_action = menu.addAction(self.tr("Copy Selected Data"))
        copy_action.setShortcut(QKeySequence.Copy)
        copy_action.setEnabled(has_selection)
        copy_action.triggered.connect(self.copy_analysis_results_selection)
        copy_with_headers_action = menu.addAction(
            self.tr("Copy Selected Data with Headers")
        )
        copy_with_headers_action.setEnabled(has_selection)
        copy_with_headers_action.triggered.connect(
            self.copy_analysis_results_selection_with_headers
        )
        menu.addSeparator()
        copy_table_action = menu.addAction(
            self.tr("Copy Current Statistics Table")
        )
        copy_table_action.setEnabled(bool(self.results_table.table_tsv()))
        copy_table_action.triggered.connect(self.copy_analysis_results_table)
        menu.addSeparator()
        formats_action = menu.addAction(self.tr("Statistic Number Formats..."))
        formats_action.triggered.connect(lambda: self.edit_statistic_formats(analysis=True))
        return menu

    def show_analysis_results_context_menu(self, position) -> None:
        index = self.results_table.indexAt(position)
        if (
            index.isValid()
            and not self.results_table.selectionModel().isSelected(index)
        ):
            self.results_table.setCurrentIndex(index)

        menu = self.analysis_results_context_menu()
        menu.exec(self.results_table.viewport().mapToGlobal(position))

    def paste_table_selection(self, table=None) -> None:
        mime = QApplication.clipboard().mimeData()
        data = clipboard_table_from_html(mime.html()) if mime is not None and mime.hasHtml() else None
        text = None
        if data is None:
            text = QApplication.clipboard().text()
            data = ClipboardTable(tsv_to_rows(text) if text else [])
        rows = data.rows
        if not rows:
            return
        controller = (
            self._active_table_controller()
            if table is None
            else self._controller_for_table(table)
        )
        if self._is_xy_sheet():
            if data.merges:
                QMessageBox.information(
                    self, self.tr("Paste table"),
                    self.tr("Merged parent headers can be pasted into a Groups sheet."),
                )
                return
            start_row = max(controller.table.currentIndex().row(), 0)
            start_column = max(controller.table.currentIndex().column(), 0)
            target_table = controller.table
            states = {
                self.table: self._table_view_state(self.table),
                self.xy_independent_table: self._table_view_state(
                    self.xy_independent_table
                ),
            }

            def paste_xy() -> bool:
                pasted_column_count = max(
                    (len(row) for row in rows),
                    default=0,
                )
                self._ensure_xy_columns_for_paste(
                    controller,
                    start_column + pasted_column_count,
                    reset_history=False,
                )
                model = controller.table.table_model
                if model.rowCount() and model.columnCount():
                    controller.table.setCurrentIndex(
                        model.index(
                            min(start_row, model.rowCount() - 1),
                            min(start_column, model.columnCount() - 1),
                        )
                    )
                paste_rows_into_table(
                    controller.table,
                    rows,
                    start_row,
                    start_column,
                )
                controller.invalidate_dataframe()
                self._sync_xy_views_to_sheet()
                self._ensure_xy_spare_columns()
                self._load_xy_workspace_views()
                for target, state in states.items():
                    self._restore_table_view_state(target, state)
                self._record_recovery_sheet_state()
                self.schedule_render()
                return True

            self._run_xy_column_structure_mutation(target_table, paste_xy)
            return
        try:
            if text is not None and not controller.table.horizontalHeader().selected_parent_columns():
                controller.paste_text(text, after_paste=lambda: self._ensure_group_table_capacity())
            else:
                controller.paste_clipboard(
                    data,
                    after_paste=lambda: self._ensure_group_table_capacity(),
                )
        except ValueError as error:
            QMessageBox.information(self, self.tr("Paste table"), self.tr(str(error)))
            return
        self.refresh_analysis_results()
        self._update_chart_specific_controls()
        self._apply_table_history_action_state(
            controller.history.can_undo,
            controller.history.can_redo,
        )

    def _configure_xy_table_layout(self, sheet: SheetDocument) -> bool:
        if sheet.mode != SHEET_MODE_XY or len(sheet.dataframe.columns) < 2:
            return False
        sheet.xy_settings = shared_x_series(
            sheet.column_ids,
            list(sheet.dataframe.columns),
        )
        sheet.xy_settings.shared_tables[0].name = "Sheet1"
        sheet.xy_settings.__post_init__()
        return True

    def clear_table_selection(self, table=None) -> None:
        controller = (
            self._active_table_controller()
            if table is None
            else self._controller_for_table(table)
        )
        controller.clear_selection()
        self._apply_table_history_action_state(
            controller.history.can_undo,
            controller.history.can_redo,
        )
        if self._is_xy_sheet():
            self._sync_xy_views_to_sheet()
        self._refresh_table_capacity()

    def update_table_header_height(self) -> None:
        self.refresh_table_structure()

    def update_column_headers(self) -> None:
        self.refresh_table_structure()

    def group_name_at(self, col: int) -> str:
        prefix = "Column" if self.workbook.active_sheet.mode == SHEET_MODE_XY else "Group"
        return table_group_name(self.table, col, prefix)

    def style_group_name_row(self) -> None:
        self.refresh_table_structure()

    def style_table_rows(self) -> None:
        self.refresh_table_structure()

    def refresh_table_structure(self) -> None:
        self._table_controller.refresh_structure()
        if self._is_xy_sheet():
            self._xy_paired_controller.refresh_structure()
            self._set_xy_workspace_headers()
            return
        self._align_analysis_results_table()

    def _group_user_names(self) -> list[str]:
        names = self._table_controller.group_names()
        if names and self._group_last_column_is_auto_spare():
            return names[:-1]
        return names

    def table_group_names(self) -> list[str]:
        return self._group_user_names()

    def _group_user_keys(self) -> list[str]:
        return list(self.workbook.active_sheet.column_ids[:len(self._group_user_names())])

    def _group_item_labels(self) -> dict[str, str]:
        names = self._group_user_names()
        keys = self._group_user_keys()
        labels = {}
        for key, name in zip(keys, names):
            parent = parent_for_column(self.workbook.active_sheet.grouping, key)
            labels[key] = f"{parent['name']} / {name}" if parent else name
        values = list(labels.values())
        return {key: f"{label} · {index + 1}" if values.count(label) > 1 else label
                for index, (key, label) in enumerate(labels.items())}

    def sync_manual_group_order(self) -> None:
        if self._is_xy_sheet():
            return
        header_frame = attach_group_metadata(pd.DataFrame(columns=self._group_user_names()), self._group_user_keys())
        migrate_group_settings(self.settings, header_frame)
        (
            self.settings.manual_group_order,
            self.settings.group_hidden,
        ) = sync_group_order_state(
            self._group_user_keys(),
            self.settings.manual_group_order,
            self.settings.group_hidden,
        )

    def edit_group_order(self) -> None:
        if self.workbook.active_sheet.mode == SHEET_MODE_XY:
            sheet = self.workbook.active_sheet
            labels = self._xy_series_labels()
            series = self._xy_user_series()
            current_labels = [labels[item.id] for item in series]
            visible_ids = {item.id for item in series}
            table_order_ids = [
                series_id
                for table in sheet.xy_settings.shared_tables
                for series_id in table.series_ids
                if series_id in visible_ids
            ]
            table_order_ids.extend(
                series_id
                for series_id in sheet.xy_settings.paired_series_ids
                if series_id in visible_ids
            )
            table_order_labels = [
                labels[series_id]
                for series_id in table_order_ids
                if series_id in labels
            ]
            order = run_group_order_dialog(
                self,
                current_labels,
                table_order_labels,
                title=self.tr("Edit Series Order"),
                hint=self.tr("Drag series to change plot order."),
            )
            if order is None:
                return
            id_by_label = {label: series_id for series_id, label in labels.items()}
            series_by_id = {series.id: series for series in sheet.xy_settings.series}
            ordered_ids = [id_by_label[label] for label in order]
            ordered_ids.extend(
                item.id
                for item in sheet.xy_settings.series
                if item.id not in ordered_ids
            )
            sheet.xy_settings.series = [series_by_id[series_id] for series_id in ordered_ids]
            self.settings.group_order = "Manual"
            self.group_order.setCurrentText("Manual")
            self._record_recovery_sheet_state()
            self.render()
            return
        self.sync_manual_group_order()
        table_order = self._group_user_keys()
        parents = self.workbook.active_sheet.grouping.parents
        if parents:
            current_order = ordered_group_columns(self._user_group_dataframe(), self.settings)
            blocks = ordered_group_blocks(
                current_order,
                parents,
                outer_order=None if self.settings.group_order == "Manual" else table_order,
            )
            order = run_grouped_order_dialog(
                self,
                [key for _parent_id, members in blocks for key in members],
                table_order,
                parents=parents,
                item_labels=self._group_item_labels(),
            )
        else:
            order = run_group_order_dialog(
                self,
                self.settings.manual_group_order,
                table_order,
                item_labels=self._group_item_labels(),
            )
        if order is None:
            return
        self.settings.manual_group_order = order
        self.settings.group_order = "Manual"
        self.group_order.setCurrentText("Manual")
        self._record_recovery_settings()
        self.render()

    def _xy_series_labels(self) -> dict[str, str]:
        sheet = self.workbook.active_sheet
        names = [series.name for series in sheet.xy_settings.series]
        duplicate_names = {name for name in names if names.count(name) > 1}
        source_labels = {
            series_id: f"{table.name} / {index}Y"
            for table in sheet.xy_settings.shared_tables
            for index, series_id in enumerate(table.series_ids, start=1)
        }
        source_labels.update(
            {
                series_id: self.tr("Independent XY · Pair {number}").format(
                    number=index + 1
                )
                for index, series_id in enumerate(
                    sheet.xy_settings.paired_series_ids
                )
            }
        )
        labels = {}
        for series in sheet.xy_settings.series:
            label = series.name
            if series.name in duplicate_names:
                suffix = source_labels.get(series.id, self.tr("Unassigned"))
                label = f"{label} · {suffix}"
            labels[series.id] = label
        return labels

    def _xy_spare_series_ids(self) -> set[str]:
        sheet = self.workbook.active_sheet
        settings = sheet.xy_settings
        series_by_id = {series.id: series for series in settings.series}
        fitted_series_ids = {fit.series_id for fit in settings.fit_specs}
        spare_ids: set[str] = set()
        for table in settings.shared_tables:
            if not table.series_ids:
                continue
            series = series_by_id.get(table.series_ids[-1])
            number = len(table.series_ids)
            if (
                series is not None
                and series.id not in fitted_series_ids
                and self._xy_series_is_auto_spare(series, number, paired=False)
            ):
                spare_ids.add(series.id)
        if settings.paired_series_ids:
            series = series_by_id.get(settings.paired_series_ids[-1])
            number = len(settings.paired_series_ids)
            if (
                series is not None
                and series.id not in fitted_series_ids
                and self._xy_series_is_auto_spare(series, number, paired=True)
            ):
                spare_ids.add(series.id)
        return spare_ids

    def _xy_series_is_auto_spare(
        self,
        series: XYSeriesSpec | None,
        number: int,
        *,
        paired: bool,
    ) -> bool:
        if series is None or not series.visible:
            return False
        if any(
            getattr(series, field_name) is not None
            for field_name in (
                "show_points",
                "show_line",
                "color",
                "marker",
                "line_style",
                "point_size",
                "point_alpha",
                "line_width",
            )
        ):
            return False
        expected_y = f"{number}Y"
        if (
            self._xy_column_has_data(series.y_column_id)
            or self._xy_column_name(series.y_column_id) != expected_y
            or series.name != expected_y
        ):
            return False
        if not paired:
            return True
        expected_x = f"{number}X"
        return (
            series.x_column_id is not None
            and not self._xy_column_has_data(series.x_column_id)
            and self._xy_column_name(series.x_column_id) == expected_x
        )

    def _xy_user_series(self) -> list[XYSeriesSpec]:
        spare_ids = self._xy_spare_series_ids()
        series = [
            series
            for series in self.workbook.active_sheet.xy_settings.series
            if series.id not in spare_ids
        ]
        if self.settings.group_order == "Name A-Z":
            series.sort(key=lambda item: (item.name.casefold(), item.id))
        elif self.settings.group_order == "Name Z-A":
            series.sort(
                key=lambda item: (item.name.casefold(), item.id),
                reverse=True,
            )
        return series

    def _render_xy_fit_preview(
        self,
        preview_specs: object,
        preview_results: dict[str, XYFitResult],
        *,
        show_equations: bool = True,
        annotation_mode: str | None = None,
    ) -> None:
        if not self._is_xy_sheet():
            return
        specs = list(preview_specs)
        if not specs:
            return
        sheet = self.workbook.active_sheet
        selected_series_ids = {spec.series_id for spec in specs}
        preview_settings = deepcopy(sheet.xy_settings)
        if annotation_mode in {"equation", "parameters"}:
            preview_settings.fit_annotation_mode = str(annotation_mode)
        preview_settings.fit_specs = [
            deepcopy(spec)
            for spec in preview_settings.fit_specs
            if spec.series_id not in selected_series_ids
        ] + [
            replace(
                deepcopy(spec),
                show_equation=bool(spec.show_equation and show_equations),
            )
            for spec in specs
        ]
        preview_settings.__post_init__()

        combined_results = dict(self._xy_fit_results_by_sheet.get(sheet.id, {}))
        for spec in specs:
            combined_results.pop(spec.id, None)
        combined_results.update(preview_results)
        dataframe = self.table_dataframe()
        self._ensure_plot_canvas().render(
            dataframe,
            self.settings,
            xy_settings=preview_settings,
            column_ids=sheet.column_ids,
            xy_fit_results=combined_results,
        )

    def _preview_xy_fit_curves(self, request: object) -> str | None:
        request_specs = dict(getattr(request, "specs", {}))
        request_series = dict(getattr(request, "series", {}))
        starting_results: dict[str, XYFitResult] = {}
        problems: list[str] = []
        for spec in request_specs.values():
            series = request_series.get(spec.series_id)
            if series is None:
                problems.append(
                    self.tr("{series}: data are unavailable.").format(
                        series=spec.series_id
                    )
                )
                continue
            series_name = str(getattr(series, "name", spec.series_id))
            if (
                spec.model_id in _DIRECT_LINEAR_XY_FIT_MODEL_IDS
                and not spec.parameters
            ):
                # For these models the automatically suggested values are the
                # direct least-squares solution itself. Keep its stable internal
                # basis for preview instead of expanding the same values to raw
                # coefficients and feeding them back as fragile fixed constraints.
                result = fit_xy_values(series.x, series.y, spec)
                if result.success:
                    starting_results[spec.id] = result
                else:
                    failure_message = result.message or self.tr("preview failed")
                    problems.append(f"{series_name}: {failure_message}")
                continue
            try:
                parameters = initial_fit_parameters(series.x, series.y, spec)
            except ValueError as error:
                problems.append(f"{series_name}: {error}")
                continue
            fixed_spec = replace(
                spec,
                parameters=[replace(parameter, fixed=True) for parameter in parameters],
            )
            result = fit_xy_values(series.x, series.y, fixed_spec)
            if result.success:
                starting_results[spec.id] = result
            else:
                failure_message = result.message or self.tr("preview failed")
                problems.append(f"{series_name}: {failure_message}")
        self._render_xy_fit_preview(
            request_specs.values(),
            starting_results,
            show_equations=False,
        )
        return "\n".join(problems) or None

    def open_xy_curve_fit_dialog(self) -> None:
        if not self._is_xy_sheet():
            return
        from easygraph.ui.xy_curve_fit_dialog import XYCurveFitDialog

        self._commit_pending_project_edits()
        dataframe = self.table_dataframe()
        sheet = self.workbook.active_sheet
        prepared = prepare_xy_data(
            dataframe,
            sheet.column_ids,
            sheet.xy_settings,
            order_mode=self.settings.group_order,
        )
        user_series_ids = {series.id for series in self._xy_user_series()}
        series_inputs = [
            series
            for series in prepared.series
            if series.id in user_series_ids and series.valid_count > 0
        ]
        if not series_inputs:
            QMessageBox.information(
                self,
                self.tr("Curve Fit"),
                self.tr("Enter at least one valid XY data series before fitting."),
            )
            return

        self._xy_fit_timer.stop()
        self._xy_fit_pending_token = None
        self._active_xy_fit_dialog_sheet_id = sheet.id
        if self._render_timer.isActive():
            self._render_timer.stop()
        self._render_pending = False
        selection_scope, selected_fit_series = self._xy_style_selection()
        selected_fit_series_ids = (
            tuple(series.id for series in selected_fit_series)
            if selection_scope == "subset"
            else ()
        )
        try:
            dialog = XYCurveFitDialog(
                self,
                series_inputs,
                existing_specs=sheet.xy_settings.fit_specs,
                existing_results=self._xy_fit_results_by_sheet.get(sheet.id, {}),
                selected_series_ids=selected_fit_series_ids,
                annotation_mode=sheet.xy_settings.fit_annotation_mode,
                preview_callback=self._preview_xy_fit_curves,
            )
            dialog.previewCleared.connect(self.render)
            dialog.fitResultsReady.connect(
                lambda _results: self._render_xy_fit_preview(
                    dialog.specs(),
                    dialog.results(),
                    annotation_mode=dialog.annotation_mode(),
                )
            )
            accepted = dialog.exec() == QDialog.Accepted
        finally:
            if self._active_xy_fit_dialog_sheet_id == sheet.id:
                self._active_xy_fit_dialog_sheet_id = None
        if not accepted:
            self.render()
            return

        dialog_result = dialog.result()
        input_series_ids = {series.id for series in series_inputs}
        preserved_specs = [
            deepcopy(spec)
            for spec in sheet.xy_settings.fit_specs
            if spec.series_id not in input_series_ids
        ]
        updated_settings = deepcopy(sheet.xy_settings)
        updated_settings.fit_annotation_mode = getattr(
            dialog_result,
            "annotation_mode",
            sheet.xy_settings.fit_annotation_mode,
        )
        updated_settings.fit_specs = preserved_specs + [
            deepcopy(spec) for spec in dialog_result.specs
        ]
        updated_settings.__post_init__()
        sheet.xy_settings = updated_settings

        live_fit_ids = {spec.id for spec in updated_settings.fit_specs}
        cached_results = self._xy_fit_results_by_sheet.setdefault(sheet.id, {})
        cached_signatures = self._xy_fit_signatures_by_sheet.setdefault(sheet.id, {})
        for fit_id in set(cached_results) - live_fit_ids:
            cached_results.pop(fit_id, None)
        for fit_id in set(cached_signatures) - live_fit_ids:
            cached_signatures.pop(fit_id, None)
        cached_results.update(
            {
                fit_id: result
                for fit_id, result in dialog_result.results.items()
                if fit_id in live_fit_ids
            }
        )
        _jobs, current_signatures = self._xy_fit_jobs_and_signatures(
            sheet,
            dataframe,
            auto_only=False,
            build_jobs=False,
        )
        for fit_id in dialog_result.results:
            if fit_id in current_signatures and fit_id in live_fit_ids:
                cached_signatures[fit_id] = current_signatures[fit_id]

        self._record_recovery_sheet_state()
        self._update_sheet_tab_texts(dataframe)
        self.render()

    def edit_group_filter(self) -> None:
        if self._is_xy_sheet():
            sheet = self.workbook.active_sheet
            series = self._xy_user_series()
            if not series:
                QMessageBox.information(
                    self,
                    self.tr("Series Filter"),
                    self.tr("Add a series first."),
                )
                return
            labels = self._xy_series_labels()
            hidden = run_checklist_filter_dialog(
                self,
                "Series Filter",
                [
                    ChecklistItem(item.id, labels[item.id])
                    for item in series
                ],
                {item.id for item in series if not item.visible},
            )
            if hidden is None:
                return
            hidden_ids = set(hidden)
            if hidden_ids == {item.id for item in series if not item.visible}:
                return
            updated_settings = deepcopy(sheet.xy_settings)
            user_series_ids = {item.id for item in series}
            for item in updated_settings.series:
                if item.id not in user_series_ids:
                    continue
                item.visible = item.id not in hidden_ids
                if not item.visible:
                    continue
                resolved_points = (
                    updated_settings.show_points
                    if item.show_points is None
                    else item.show_points
                )
                resolved_line = (
                    updated_settings.show_line
                    if item.show_line is None
                    else item.show_line
                )
                if resolved_points or resolved_line:
                    continue
                if updated_settings.show_points:
                    item.show_points = None
                else:
                    item.show_line = None
            updated_settings.__post_init__()
            sheet.xy_settings = updated_settings
            self._record_recovery_sheet_state()
            self.render()
            return
        self.sync_manual_group_order()
        groups = self._group_user_keys()
        if not groups:
            QMessageBox.information(
                self,
                self.tr("Group Filter"),
                self.tr("Add a group first."),
            )
            return
        hidden = run_checklist_filter_dialog(
            self,
            "Group Filter",
            [ChecklistItem(group, self._group_item_labels()[group]) for group in groups],
            set(hidden_group_names(self.settings)),
        )
        if hidden is None:
            return
        self.settings.group_hidden = hidden
        self._record_recovery_settings()
        self.render()

    @staticmethod
    def _additional_guide_color_key(axis_key: str, row: int) -> str:
        return f"additional-guide:{axis_key}:{row}"

    def _additional_guide_color_items(
        self,
    ) -> list[tuple[str, str, int, int]]:
        axis_keys = ("x", "primary") if self._is_xy_sheet() else ("primary",)
        items: list[tuple[str, str, int, int]] = []
        for axis_key in axis_keys:
            if axis_key == "x":
                axis_label = self.tr("X axis")
            elif self._is_xy_sheet():
                axis_label = self.tr("Y axis")
            else:
                axis_label = self.tr("Value axis")
            for row, guide in enumerate(
                self._additional_guides_for_axis(axis_key)
            ):
                key = self._additional_guide_color_key(axis_key, row)
                label = (
                    f"{self.tr('Additional grid line')} · {axis_label}: "
                    f"{format_additional_guide_value(guide.get('value', 0.0))}"
                )
                try:
                    color_index = int(guide.get("color_index", 0))
                except (AttributeError, TypeError, ValueError, OverflowError):
                    color_index = 0
                items.append((key, label, color_index, len(items)))
        return items

    def _additional_guide_color_indices(self) -> dict[str, int]:
        return {
            key: color_index
            for key, _label, color_index, _default_index
            in self._additional_guide_color_items()
        }

    def _apply_additional_guide_color_selection(
        self,
        selection: GroupColorSelection,
    ) -> bool:
        # A dialog without guide rows returns no guide keys. In that case its
        # compatibility defaults must not overwrite the sheet's guide palette.
        if not selection.guide_color_indices:
            return False
        changed = False
        if (
            selection.guide_palette in PRESETS
            and selection.guide_palette
            != self.settings.additional_guide_palette
        ):
            self.settings.additional_guide_palette = selection.guide_palette
            changed = True
        axis_keys = ("x", "primary") if self._is_xy_sheet() else ("primary",)
        for axis_key in axis_keys:
            guides = self._additional_guides_for_axis(axis_key)
            for row, guide in enumerate(guides):
                key = self._additional_guide_color_key(axis_key, row)
                if key not in selection.guide_color_indices:
                    continue
                color_index = min(
                    MAX_ADDITIONAL_GUIDES * 2 - 1,
                    max(0, int(selection.guide_color_indices[key])),
                )
                if int(guide.get("color_index", 0)) == color_index:
                    continue
                guide["color_index"] = color_index
                changed = True
        return changed

    def _group_color_selection(self) -> GroupColorSelection:
        return GroupColorSelection(
            preset=self.settings.preset,
            custom_colors=dict(self.settings.custom_colors),
            overlay_palette=self.settings.custom_overlay_palette,
            overlay_colors=dict(self.settings.custom_overlay_colors),
            guide_palette=self.settings.additional_guide_palette,
            guide_color_indices=self._additional_guide_color_indices(),
        )

    def _apply_group_color_selection(self, selection: GroupColorSelection) -> bool:
        grouping = self.workbook.active_sheet.grouping
        if grouping.parents:
            expanded = dict(selection.custom_colors)
            for key, color in selection.custom_colors.items():
                if self.settings.group_color_mode == "Parent":
                    parent = parent_for_column(grouping, key)
                    linked = parent["column_ids"] if parent else [key]
                elif grouping.shared_subgroups and key in grouping.subgroup_ids:
                    category = grouping.subgroup_ids[key]
                    linked = [column_id for column_id, category_id in grouping.subgroup_ids.items() if category_id == category]
                else:
                    linked = [key]
                expanded.update({column_id: color for column_id in linked})
            selection = replace(selection, custom_colors=expanded)
        if selection == self._group_color_selection():
            return False
        self.settings.preset = selection.preset
        self.settings.custom_colors = dict(selection.custom_colors)
        self.settings.custom_overlay_palette = selection.overlay_palette
        self.settings.custom_overlay_colors = dict(selection.overlay_colors)
        self._apply_additional_guide_color_selection(selection)
        self.preset.blockSignals(True)
        try:
            self.preset.setCurrentText(selection.preset)
        finally:
            self.preset.blockSignals(False)
        return True

    def _preview_group_color_selection(self, selection: GroupColorSelection) -> None:
        if self._apply_group_color_selection(selection):
            self.schedule_render(delay_ms=COLOR_PREVIEW_RENDER_DEBOUNCE_MS)

    def _finish_group_color_selection(self, selection: GroupColorSelection) -> None:
        if self._apply_group_color_selection(selection):
            self._record_recovery_settings()
            self.render()
        else:
            self.flush_pending_render()
        self._refresh_additional_guides_table(
            self.additional_guides_table.currentRow()
        )

    def _xy_color_selection(self) -> GroupColorSelection:
        return GroupColorSelection(
            preset=self.settings.preset,
            custom_colors={
                series.id: series.color
                for series in self.workbook.active_sheet.xy_settings.series
                if series.color is not None
            },
            overlay_palette=self.settings.custom_overlay_palette,
            overlay_colors={},
            guide_palette=self.settings.additional_guide_palette,
            guide_color_indices=self._additional_guide_color_indices(),
        )

    def _apply_xy_color_selection(self, selection: GroupColorSelection) -> bool:
        current = self._xy_color_selection()
        if selection == current:
            return False
        self.settings.preset = selection.preset
        for series in self.workbook.active_sheet.xy_settings.series:
            series.color = selection.custom_colors.get(series.id)
        self._apply_additional_guide_color_selection(selection)
        signals_blocked = self.preset.blockSignals(True)
        try:
            self.preset.setCurrentText(selection.preset)
        finally:
            self.preset.blockSignals(signals_blocked)
        return True

    def _preview_xy_color_selection(self, selection: GroupColorSelection) -> None:
        if self._apply_xy_color_selection(selection):
            self.schedule_render(delay_ms=COLOR_PREVIEW_RENDER_DEBOUNCE_MS)

    def edit_xy_colors(self) -> None:
        sheet = self.workbook.active_sheet
        series = self._xy_user_series() if sheet.mode == SHEET_MODE_XY else []
        guide_items = (
            self._additional_guide_color_items()
            if sheet.mode == SHEET_MODE_XY
            else []
        )
        if sheet.mode != SHEET_MODE_XY or (not series and not guide_items):
            return
        original = self._xy_color_selection()
        dialog_settings = deepcopy(self.settings)
        dialog_settings.custom_colors = dict(original.custom_colors)
        dialog_settings.custom_overlay_colors = {}
        dialog_settings.custom_overlay_series = []
        labels = self._xy_series_labels()
        result = run_group_colors_dialog(
            self,
            dialog_settings,
            [item.id for item in series],
            [],
            self._preview_xy_color_selection,
            self._polish_combo_box,
            title="Series Colors",
            item_labels={item.id: labels[item.id] for item in series},
            guide_items=guide_items,
        )
        final = original if result is None else result
        changed = final != original
        self._apply_xy_color_selection(final)
        if self._render_pending:
            self.flush_pending_render()
        elif changed:
            self.render()
        if result is not None and changed:
            self._record_recovery_settings()
            self._record_recovery_sheet_state()
        self._refresh_additional_guides_table(
            self.additional_guides_table.currentRow()
        )

    def edit_group_colors(self) -> None:
        if self._is_xy_sheet():
            self.edit_xy_colors()
            return
        self.sync_manual_group_order()
        groups = self._group_user_keys()
        item_labels = self._group_item_labels()
        grouping = self.workbook.active_sheet.grouping
        if grouping.parents and (grouping.shared_subgroups or self.settings.group_color_mode == "Parent"):
            representatives = {}
            names = group_labels(self._user_group_dataframe())
            for key in groups:
                parent = parent_for_column(grouping, key)
                if parent and self.settings.group_color_mode == "Parent":
                    category = parent['id']
                    item_labels[key] = parent['name']
                elif grouping.shared_subgroups and key in grouping.subgroup_ids:
                    category = grouping.subgroup_ids[key]
                    item_labels[key] = names[key]
                else:
                    category = key
                representatives.setdefault(category, key)
            groups = list(representatives.values())
        guide_items = self._additional_guide_color_items()
        if not groups and not guide_items:
            return
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        overlay_items = overlay_color_items(
            self._user_group_dataframe(),
            self.settings,
        )
        original = self._group_color_selection()
        dialog_kwargs = {"guide_items": guide_items} if guide_items else {}
        dialog_kwargs["item_labels"] = item_labels
        result = run_group_colors_dialog(
            self,
            self.settings,
            groups,
            overlay_items,
            self._preview_group_color_selection,
            self._polish_combo_box,
            **dialog_kwargs,
        )
        self._finish_group_color_selection(original if result is None else result)

    def _connect_table(self) -> None:
        self.grouping_controls = GroupingControls(self)
        self.ui.groupLayoutButton.clicked.connect(self.grouping_controls.edit_display)
        header = self.table.horizontalHeader()
        header.parentCellDoubleClicked.connect(self.grouping_controls.edit_parent_at_column)
        header.parentCellContextMenuRequested.connect(self.grouping_controls.header_menu)
        header.parentSelectionChanged.connect(self._handle_parent_header_selection_changed)
        self.table.table_model.cellEdited.connect(self.handle_table_item_changed)
        self.xy_independent_table.table_model.cellEdited.connect(
            self.handle_xy_independent_item_changed
        )
        self.table.headerCellDoubleClicked.connect(
            lambda column: self.rename_column(self.table, column)
        )
        self.xy_independent_table.headerCellDoubleClicked.connect(
            lambda column: self.rename_column(self.xy_independent_table, column)
        )
        self.table.verticalHeader().sectionDoubleClicked.connect(self.rename_overlay_row)

    def _handle_parent_header_selection_changed(self) -> None:
        header = self.table.horizontalHeader()
        if header.selected_parent_columns():
            self.table.clearSelection()
            self.table.selectionModel().clearCurrentIndex()
            self.results_table.clearSelection()
            self._table_selection_origins[self.table] = "parent_headers"
            if hasattr(self, "table_tools"):
                self.table_tools.activate(self.table)
        self.grouping_controls.update_actions()
        if hasattr(self, "table_tools"):
            self.table_tools.update_state()

    @staticmethod
    def _style_template_family_for_mode(mode: str) -> str:
        return (
            TEMPLATE_FAMILY_XY
            if normalized_sheet_mode(mode) == SHEET_MODE_XY
            else TEMPLATE_FAMILY_GROUPS
        )

    def _active_style_template_family(self) -> str:
        return self._style_template_family_for_mode(
            self.workbook.active_sheet.mode
        )

    def _template_name_for_new_sheet(self, mode: str) -> str | None:
        target_family = self._style_template_family_for_mode(mode)
        name = self.template_combo.currentText().strip()
        if not name or name == TEMPLATE_NONE_NAME:
            return None
        if (
            target_family != self._active_style_template_family()
            and name not in list_style_templates(family=target_family)
        ):
            return None
        return name

    def refresh_template_combo(self, selected: str | None = None) -> None:
        current = self.template_combo.currentText() if selected is None else selected
        self.template_combo.blockSignals(True)
        self.template_combo.clear()
        self.template_combo.addItem(TEMPLATE_NONE_NAME)
        templates = list_style_templates(
            family=self._active_style_template_family()
        )
        self.template_combo.addItems(templates)
        if current in [TEMPLATE_NONE_NAME, *templates]:
            self.template_combo.setCurrentText(current)
        else:
            self.template_combo.setCurrentText(TEMPLATE_NONE_NAME)
        self.template_combo.blockSignals(False)
        self._polish_template_combo_box()

    def apply_style_template(
        self,
        name: str,
        settings: ChartSettings,
        xy_style: XYStyleTemplate | None = None,
    ) -> None:
        self.update_settings()
        self.settings = apply_style_template_settings(self.settings, settings, self._group_user_keys() if not self._is_xy_sheet() else self.table_group_names())
        sheet = self.workbook.active_sheet
        sheet.settings = self.settings
        if sheet.mode == SHEET_MODE_XY:
            self.settings.chart_type = "Scatter"
            if xy_style is not None:
                sheet.xy_settings = apply_xy_style_template(
                    sheet.xy_settings,
                    xy_style,
                )
        self.sync_manual_group_order()
        self.apply_settings_to_controls()
        self._record_recovery_settings()
        if sheet.mode == SHEET_MODE_XY and xy_style is not None:
            self._record_recovery_sheet_state()
        self.render()
        self.statusBar().showMessage(self.tr("Style template applied: {name}").format(name=name), 2500)

    def apply_selected_template(self, name: str) -> None:
        if not name or name == TEMPLATE_NONE_NAME:
            return
        family = self._active_style_template_family()
        try:
            settings = read_style_template(name, family=family)
            xy_style = (
                read_xy_style_template(name, family=family)
                if family == TEMPLATE_FAMILY_XY
                else None
            )
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template load failed"), str(exc))
            self.refresh_template_combo()
            return
        self.apply_style_template(name, settings, xy_style)

    def handle_table_item_changed(self, row: int, column: int, _before: str, _after: str) -> None:
        if (
            self._table_controller.history_restoring
            or self._table_controller.history_suspended
        ):
            return
        if self._is_xy_sheet():
            self._sync_xy_controller_to_sheet(
                self._table_controller,
                self._active_xy_shared_column_ids,
            )
            self._sync_xy_views_to_sheet()
            self._table_controller.record_history_change()
            if (
                row == self.table.table_model.rowCount() - 1
                or column == self.table.table_model.columnCount() - 1
            ):
                self._schedule_table_capacity_update()
            else:
                self.schedule_render()
            return
        if row == 0:
            self.refresh_table_structure()
            self.sync_manual_group_order()
        if 0 < row < self.sample_start_row():
            self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        self.record_table_history_change()
        if (
            row == 0
            or
            row == self.table.table_model.rowCount() - 1
            or column == self.table.table_model.columnCount() - 1
        ):
            self._schedule_table_capacity_update()
        else:
            self.schedule_render()

    def handle_xy_independent_item_changed(
        self,
        row: int,
        column: int,
        _before: str,
        _after: str,
    ) -> None:
        if (
            self._xy_paired_controller.history_restoring
            or self._xy_paired_controller.history_suspended
            or self._loading_xy_workspace
        ):
            return
        self._sync_xy_controller_to_sheet(
            self._xy_paired_controller,
            self._active_xy_paired_column_ids,
        )
        self._sync_xy_views_to_sheet()
        self._xy_paired_controller.record_history_change()
        if (
            row == self.xy_independent_table.table_model.rowCount() - 1
            or column >= self.xy_independent_table.table_model.columnCount() - 2
        ):
            self._schedule_table_capacity_update()
        else:
            self.schedule_render()

    def _group_capacity_name(self, column: int) -> str:
        model = self.table.table_model
        existing = {
            model.cell_text(0, index).strip()
            for index in range(max(0, int(column)))
        }
        number = max(0, int(column)) + 1
        while f"Group {number}" in existing:
            number += 1
        return f"Group {number}"

    def _restore_group_spare_provenance(self) -> None:
        model = self.table.table_model
        column = model.columnCount() - 1
        sheet = self.workbook.active_sheet
        if column < 0 or column >= len(sheet.column_ids):
            return
        name = model.cell_text(0, column).strip()
        default_named = (
            name.startswith("Group ")
            and name.removeprefix("Group ").isdigit()
        )
        if (
            not default_named
            or any(key in self.settings.manual_group_order or key in self.settings.group_hidden or key in self.settings.custom_colors for key in (name, sheet.column_ids[column]))
            or parent_for_column(sheet.grouping, sheet.column_ids[column]) is not None
            or any(
                model.cell_text(row, column).strip()
                for row in range(1, model.rowCount())
            )
        ):
            return
        self._group_auto_spare_names.setdefault(sheet.id, {})[
            sheet.column_ids[column]
        ] = name

    def _group_last_column_is_auto_spare(self) -> bool:
        model = self.table.table_model
        column = model.columnCount() - 1
        if column < 0:
            return False
        sheet = self.workbook.active_sheet
        tracked_names = self._group_auto_spare_names.setdefault(sheet.id, {})
        valid_column_ids = set(sheet.column_ids)
        for column_id in tuple(tracked_names):
            if column_id not in valid_column_ids:
                tracked_names.pop(column_id, None)
        column_id = (
            sheet.column_ids[column]
            if column < len(sheet.column_ids)
            else ""
        )
        name = model.cell_text(0, column).strip()
        tracked_name = tracked_names.get(column_id)
        if tracked_name is None:
            return False
        if name not in {"", tracked_name}:
            tracked_names.pop(column_id, None)
            return False
        if any(key in self.settings.group_hidden or key in self.settings.custom_colors for key in (name, column_id)) or parent_for_column(sheet.grouping, column_id) is not None:
            return False
        return not any(
            model.cell_text(row, column).strip()
            for row in range(1, model.rowCount())
        )

    def _ensure_group_table_capacity(
        self,
        *,
        minimum_columns: int = 1,
        minimum_sample_rows: int = 1,
        refresh_structure: bool = True,
    ) -> bool:
        controller = self._table_controller
        model = self.table.table_model
        changed = False
        controller.history_suspended = True
        try:
            changed = ensure_trailing_blank_row(
                model,
                controller.sample_start_row(),
                minimum_sample_rows,
            )
            while (
                model.columnCount() < max(1, int(minimum_columns))
                or not self._group_last_column_is_auto_spare()
            ):
                column = model.columnCount()
                if not model.insertColumns(column, 1):
                    break
                controller._reconcile_sheet_column_ids()
                name = self._group_capacity_name(column)
                model.set_cell_text(0, column, name)
                sheet = self.workbook.active_sheet
                if column < len(sheet.column_ids):
                    self._group_auto_spare_names.setdefault(sheet.id, {})[
                        sheet.column_ids[column]
                    ] = name
                changed = True
            last_column = model.columnCount() - 1
            if last_column >= 0 and self._group_last_column_is_auto_spare():
                spare_name = model.cell_text(0, last_column).strip()
                preceding_names = {
                    model.cell_text(0, column).strip()
                    for column in range(last_column)
                }
                if spare_name in preceding_names:
                    spare_name = self._group_capacity_name(last_column)
                    model.set_cell_text(0, last_column, spare_name)
                    sheet = self.workbook.active_sheet
                    if last_column < len(sheet.column_ids):
                        self._group_auto_spare_names.setdefault(sheet.id, {})[
                            sheet.column_ids[last_column]
                        ] = spare_name
                    changed = True
        finally:
            controller.history_suspended = False
        if changed:
            controller.invalidate_dataframe()
            if refresh_structure:
                controller.refresh_structure()
        if refresh_structure:
            self.sync_manual_group_order()
        return changed

    def _table_view_state(self, table) -> dict:
        selection_model = table.selectionModel()
        indexes = (
            selection_model.selectedIndexes()
            if selection_model is not None
            else ()
        )
        current = table.currentIndex()
        return {
            "current": (current.row(), current.column()),
            "positions": tuple(
                sorted({(index.row(), index.column()) for index in indexes})
            ),
            "scope": self._table_selection_origins.get(table, "cells"),
            "horizontal_scroll": table.horizontalScrollBar().value(),
            "vertical_scroll": table.verticalScrollBar().value(),
        }

    def _restore_table_view_state(self, table, state: dict) -> None:
        model = table.table_model
        selection_model = table.selectionModel()
        if selection_model is None:
            return
        selection_model.clearSelection()
        positions = tuple(state.get("positions", ()))
        scope = str(state.get("scope", "cells"))
        if scope == "rows":
            rows = sorted({row for row, _column in positions})
            positions = tuple(
                (row, column)
                for row in rows
                if 0 <= row < model.rowCount()
                for column in range(model.columnCount())
            )
        elif scope == "columns":
            columns = sorted({column for _row, column in positions})
            positions = tuple(
                (row, column)
                for column in columns
                if 0 <= column < model.columnCount()
                for row in range(model.rowCount())
            )
        for row, column in positions:
            if 0 <= row < model.rowCount() and 0 <= column < model.columnCount():
                selection_model.select(
                    model.index(row, column),
                    QItemSelectionModel.Select,
                )
        row, column = state.get("current", (-1, -1))
        if model.rowCount() and model.columnCount() and row >= 0 and column >= 0:
            selection_model.setCurrentIndex(
                model.index(
                    min(row, model.rowCount() - 1),
                    min(column, model.columnCount() - 1),
                ),
                QItemSelectionModel.NoUpdate,
            )
        self._table_selection_origins[table] = scope
        table.horizontalScrollBar().setValue(
            int(state.get("horizontal_scroll", 0))
        )
        table.verticalScrollBar().setValue(
            int(state.get("vertical_scroll", 0))
        )

    def _schedule_table_capacity_update(self) -> None:
        if self._table_capacity_update_pending:
            return
        self._table_capacity_update_pending = True
        QTimer.singleShot(0, self._flush_pending_table_capacity_update)

    def _flush_pending_table_capacity_update(self) -> None:
        if not self._table_capacity_update_pending:
            return
        self._refresh_table_capacity()

    def _refresh_table_capacity(self) -> None:
        self._table_capacity_update_pending = False
        if self._is_xy_sheet():
            self._sync_xy_views_to_sheet()
            columns_changed = self._ensure_xy_spare_columns()
            if columns_changed:
                states = {
                    self.table: self._table_view_state(self.table),
                    self.xy_independent_table: self._table_view_state(
                        self.xy_independent_table
                    ),
                }
                self._load_xy_workspace_views()
                for table, state in states.items():
                    self._restore_table_view_state(table, state)
            else:
                for controller in (
                    self._table_controller,
                    self._xy_paired_controller,
                ):
                    controller.history_suspended = True
                    try:
                        changed = ensure_trailing_blank_row(
                            controller.table.table_model,
                            controller.sample_start_row(),
                        )
                    finally:
                        controller.history_suspended = False
                    if changed:
                        controller.invalidate_dataframe()
                        controller.refresh_structure()
        else:
            self._restore_group_spare_provenance()
            self._ensure_group_table_capacity()
        self._record_recovery_sheet_state()
        self.schedule_render()

    # Compatibility for callers outside the unified table-capacity path.
    def _schedule_xy_capacity_update(self) -> None:
        self._schedule_table_capacity_update()

    def _refresh_xy_capacity(self) -> None:
        self._refresh_table_capacity()

    def _xy_column_position(self, column_id: str) -> int | None:
        try:
            return self.workbook.active_sheet.column_ids.index(column_id)
        except ValueError:
            return None

    def _xy_column_name(self, column_id: str) -> str:
        position = self._xy_column_position(column_id)
        if position is None:
            return ""
        return str(self.workbook.active_sheet.dataframe.columns[position])

    def _xy_column_has_data(self, column_id: str) -> bool:
        position = self._xy_column_position(column_id)
        if position is None:
            return False
        values = self.workbook.active_sheet.dataframe.iloc[:, position]
        return any(
            not pd.isna(value) and bool(str(value).strip())
            for value in values
        )

    @staticmethod
    def _is_numbered_xy_name(name: object, axis: str) -> bool:
        text = str(name)
        return text.endswith(axis) and text[:-1].isdigit()

    def _renumber_default_xy_column_names(self) -> None:
        sheet = self.workbook.active_sheet
        names = list(sheet.dataframe.columns)
        series_by_id = {series.id: series for series in sheet.xy_settings.series}
        for table in sheet.xy_settings.shared_tables:
            for index, series_id in enumerate(table.series_ids, start=1):
                series = series_by_id.get(series_id)
                if series is None:
                    continue
                position = self._xy_column_position(series.y_column_id)
                if position is not None and self._is_numbered_xy_name(names[position], "Y"):
                    names[position] = f"{index}Y"
                if self._is_numbered_xy_name(series.name, "Y"):
                    series.name = f"{index}Y"
        for index, series_id in enumerate(sheet.xy_settings.paired_series_ids, start=1):
            series = series_by_id.get(series_id)
            if series is None:
                continue
            x_column_id = series.x_column_id
            x_position = (
                self._xy_column_position(x_column_id)
                if x_column_id is not None
                else None
            )
            y_position = self._xy_column_position(series.y_column_id)
            if x_position is not None and self._is_numbered_xy_name(names[x_position], "X"):
                names[x_position] = f"{index}X"
            if y_position is not None and self._is_numbered_xy_name(names[y_position], "Y"):
                names[y_position] = f"{index}Y"
            if self._is_numbered_xy_name(series.name, "Y"):
                series.name = f"{index}Y"
        sheet.dataframe.columns = names

    def _insert_xy_source_columns(
        self,
        names: list[str],
        *,
        before_column_id: str | None = None,
        sync_views: bool = True,
    ) -> list[str]:
        sheet = self.workbook.active_sheet
        if sync_views:
            self._sync_xy_views_to_sheet()
        addition = pd.DataFrame(
            [["" for _ in names] for _ in range(len(sheet.dataframe))],
            columns=names,
        )
        column_ids = [new_column_id() for _ in names]
        insertion = (
            self._xy_column_position(before_column_id)
            if before_column_id is not None
            else None
        )
        if insertion is None:
            sheet.dataframe = pd.concat(
                [sheet.dataframe.reset_index(drop=True), addition],
                axis=1,
            )
            sheet.column_ids.extend(column_ids)
        else:
            sheet.dataframe = pd.concat(
                [
                    sheet.dataframe.iloc[:, :insertion].reset_index(drop=True),
                    addition,
                    sheet.dataframe.iloc[:, insertion:].reset_index(drop=True),
                ],
                axis=1,
            )
            sheet.column_ids[insertion:insertion] = column_ids
        return column_ids

    def _append_xy_source_columns(self, names: list[str]) -> list[str]:
        return self._insert_xy_source_columns(names)

    def _insert_xy_y_for_table(
        self,
        table: XYSharedTableSpec,
        series_index: int,
        *,
        sync_views: bool,
    ) -> XYSeriesSpec:
        sheet = self.workbook.active_sheet
        series_index = max(0, min(series_index, len(table.series_ids)))
        series_by_id = {series.id: series for series in sheet.xy_settings.series}
        before_column_id = None
        if series_index < len(table.series_ids):
            target = series_by_id.get(table.series_ids[series_index])
            before_column_id = target.y_column_id if target is not None else None
        y_column_id = self._insert_xy_source_columns(
            [f"{series_index + 1}Y"],
            before_column_id=before_column_id,
            sync_views=sync_views,
        )[0]
        series = XYSeriesSpec(
            id=new_series_id(),
            name=f"{series_index + 1}Y",
            x_column_id=(
                None
                if table.x_column_id == sheet.xy_settings.default_x_column_id
                else table.x_column_id
            ),
            y_column_id=y_column_id,
        )
        sheet.xy_settings.series.append(series)
        table.series_ids.insert(series_index, series.id)
        self._renumber_default_xy_column_names()
        return series

    def _insert_xy_pair_at(
        self,
        pair_index: int,
        *,
        sync_views: bool,
    ) -> XYSeriesSpec:
        sheet = self.workbook.active_sheet
        pair_ids = sheet.xy_settings.paired_series_ids
        pair_index = max(0, min(pair_index, len(pair_ids)))
        series_by_id = {series.id: series for series in sheet.xy_settings.series}
        before_column_id = None
        if pair_index < len(pair_ids):
            target = series_by_id.get(pair_ids[pair_index])
            before_column_id = target.x_column_id if target is not None else None
        x_column_id, y_column_id = self._insert_xy_source_columns(
            [f"{pair_index + 1}X", f"{pair_index + 1}Y"],
            before_column_id=before_column_id,
            sync_views=sync_views,
        )
        series = XYSeriesSpec(
            id=new_series_id(),
            name=f"{pair_index + 1}Y",
            x_column_id=x_column_id,
            y_column_id=y_column_id,
        )
        sheet.xy_settings.series.append(series)
        pair_ids.insert(pair_index, series.id)
        self._renumber_default_xy_column_names()
        return series

    def _ensure_xy_spare_columns(self) -> bool:
        sheet = self.workbook.active_sheet
        settings = sheet.xy_settings
        series_by_id = {series.id: series for series in settings.series}
        changed = False
        for table in settings.shared_tables:
            last_series = (
                series_by_id.get(table.series_ids[-1])
                if table.series_ids
                else None
            )
            last_number = len(table.series_ids)
            needs_spare = not self._xy_series_is_auto_spare(
                last_series,
                last_number,
                paired=False,
            )
            if needs_spare:
                created = self._insert_xy_y_for_table(
                    table,
                    len(table.series_ids),
                    sync_views=False,
                )
                series_by_id[created.id] = created
                changed = True

        last_pair = (
            series_by_id.get(settings.paired_series_ids[-1])
            if settings.paired_series_ids
            else None
        )
        pair_number = len(settings.paired_series_ids)
        needs_pair = not self._xy_series_is_auto_spare(
            last_pair,
            pair_number,
            paired=True,
        )
        if needs_pair:
            self._insert_xy_pair_at(
                len(settings.paired_series_ids),
                sync_views=False,
            )
            changed = True
        if changed:
            self._reorder_xy_series_if_table_order()
        return changed

    def _reorder_xy_series_if_table_order(self) -> None:
        if self.settings.group_order == "Table order":
            reorder_series_for_table_layout(
                self.workbook.active_sheet.xy_settings
            )

    def _remove_xy_source_columns(self, column_ids: list[str]) -> None:
        sheet = self.workbook.active_sheet
        removed = set(column_ids)
        keep_positions = [
            index
            for index, column_id in enumerate(sheet.column_ids)
            if column_id not in removed
        ]
        sheet.dataframe = sheet.dataframe.iloc[:, keep_positions].copy(deep=True)
        sheet.column_ids = [sheet.column_ids[index] for index in keep_positions]
        remove_xy_column_references(sheet.xy_settings, removed)

    def add_xy_shared_table(self) -> None:
        if not self._is_xy_sheet():
            return
        sheet = self.workbook.active_sheet
        table_number = len(sheet.xy_settings.shared_tables) + 1
        x_column_id, *y_column_ids = self._append_xy_source_columns(
            [
                "X",
                *(
                    f"{index}Y"
                    for index in range(1, DEFAULT_XY_SHARED_Y_COLUMNS + 1)
                ),
            ]
        )
        series = [
            XYSeriesSpec(
                id=new_series_id(),
                name=f"{index}Y",
                x_column_id=x_column_id,
                y_column_id=y_column_id,
            )
            for index, y_column_id in enumerate(y_column_ids, start=1)
        ]
        table = XYSharedTableSpec(
            id=new_series_id(),
            name=f"Sheet{table_number}",
            x_column_id=x_column_id,
            series_ids=[item.id for item in series],
        )
        sheet.xy_settings.series.extend(series)
        sheet.xy_settings.shared_tables.append(table)
        sheet.xy_settings.active_shared_table_id = table.id
        self._reorder_xy_series_if_table_order()
        session = self._sheet_session(sheet.id)
        session.xy_shared_histories[table.id] = type(session.history)()
        self._table_controller.history = session.xy_shared_histories[table.id]
        self._load_xy_workspace_views()
        self._record_recovery_sheet_state()
        self.render()

    def remove_xy_shared_table(self) -> None:
        if not self._is_xy_sheet():
            return
        sheet = self.workbook.active_sheet
        table = self._active_xy_shared_table()
        if table is None:
            return
        answer = QMessageBox.question(
            self,
            self.tr("Delete Shared X Table"),
            self.tr('Delete "{name}" and all of its data?').format(name=table.name),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        tables = sheet.xy_settings.shared_tables
        removed_index = next(
            (index for index, item in enumerate(tables) if item.id == table.id),
            -1,
        )
        next_active_table_id = None
        if 0 <= removed_index < len(tables) - 1:
            next_active_table_id = tables[removed_index + 1].id
        elif removed_index > 0:
            next_active_table_id = tables[removed_index - 1].id
        self._sync_xy_views_to_sheet()
        columns = list(shared_table_column_ids(sheet.xy_settings, table))
        self._remove_xy_source_columns(columns)
        sheet.xy_settings.active_shared_table_id = next_active_table_id
        session = self._sheet_session(sheet.id)
        session.xy_shared_histories.pop(table.id, None)
        active_table = self._active_xy_shared_table()
        self._table_controller.history = session.xy_shared_histories.setdefault(
            active_table.id if active_table is not None else "",
            type(session.history)(),
        )
        self._reorder_xy_series_if_table_order()
        self._load_xy_workspace_views()
        self._record_recovery_sheet_state()
        self.render()

    def switch_xy_shared_table(self, index: int) -> None:
        if self._loading_xy_workspace or not self._is_xy_sheet() or index < 0:
            return
        sheet = self.workbook.active_sheet
        table_id = self.ui.xySharedTabBar.tabData(index)
        if not isinstance(table_id, str) or table_id == sheet.xy_settings.active_shared_table_id:
            return
        self._sync_xy_views_to_sheet()
        previous = self._active_xy_shared_table()
        session = self._sheet_session(sheet.id)
        if previous is not None:
            session.xy_shared_histories[previous.id] = self._table_controller.history
        sheet.xy_settings.active_shared_table_id = table_id
        self._table_controller.history = session.xy_shared_histories.setdefault(
            table_id,
            type(session.history)(),
        )
        self._load_xy_workspace_views()
        self.update_table_history_actions()

    def move_xy_shared_table(self, source: int, destination: int) -> None:
        if self._loading_xy_workspace or not self._is_xy_sheet():
            return
        tables = self.workbook.active_sheet.xy_settings.shared_tables
        if not (0 <= source < len(tables) and 0 <= destination < len(tables)):
            return
        table = tables.pop(source)
        tables.insert(destination, table)
        self._reorder_xy_series_if_table_order()
        self._rebuild_xy_shared_tabs()
        self._record_recovery_sheet_state()
        self.render()

    def rename_xy_shared_table(self, index: int) -> None:
        if not self._is_xy_sheet() or not 0 <= index < self.ui.xySharedTabBar.count():
            return
        sheet = self.workbook.active_sheet
        table_id = self.ui.xySharedTabBar.tabData(index)
        table = next(
            (item for item in sheet.xy_settings.shared_tables if item.id == table_id),
            None,
        )
        if table is None:
            return
        name, accepted = QInputDialog.getText(
            self,
            self.tr("Rename Shared X Table"),
            self.tr("Table name"),
            text=table.name,
        )
        if not accepted or not name.strip() or name.strip() == table.name:
            return
        table.name = name.strip()
        self._rebuild_xy_shared_tabs()
        self._record_recovery_sheet_state()

    def _add_xy_y_column(self, *, reload_views: bool = True) -> None:
        table = self._active_xy_shared_table()
        if table is None:
            self.add_xy_shared_table()
            return
        self._insert_xy_y_for_table(
            table,
            len(table.series_ids),
            sync_views=True,
        )
        self._reorder_xy_series_if_table_order()
        if reload_views:
            self._load_xy_workspace_views()
            self._table_controller.reset_history()

    def insert_xy_y_before_selection(self) -> None:
        if not self._is_xy_sheet():
            return
        column = self.table.currentIndex().column()
        if column < 0:
            column = self.table.table_model.columnCount() - 1
        if column >= 0:
            self.table.selectColumn(column)
        self.insert_table_structure("entire_column", self.table)

    def add_xy_pair(self, *, reload_views: bool = True) -> None:
        if not self._is_xy_sheet():
            return
        settings = self.workbook.active_sheet.xy_settings
        self._insert_xy_pair_at(
            len(settings.paired_series_ids),
            sync_views=True,
        )
        self._reorder_xy_series_if_table_order()
        if reload_views:
            self._load_xy_workspace_views()
            self._xy_paired_controller.reset_history()
            self._record_recovery_sheet_state()
            self.render()

    def insert_xy_pair_before_selection(self) -> None:
        if not self._is_xy_sheet():
            return
        column = self.xy_independent_table.currentIndex().column()
        if column < 0:
            column = self.xy_independent_table.table_model.columnCount() - 1
        if column >= 0:
            self.xy_independent_table.selectColumn(column)
        self.insert_table_structure("entire_column", self.xy_independent_table)

    def remove_xy_pair(self) -> None:
        if not self._is_xy_sheet():
            return
        column = self.xy_independent_table.currentIndex().column()
        if column < 0:
            column = self.xy_independent_table.table_model.columnCount() - 1
        if column >= 0:
            self.xy_independent_table.selectColumn(column)
        self.delete_table_structure("entire_column", self.xy_independent_table)

    def _ensure_xy_columns_for_paste(
        self,
        controller: TableController,
        needed_columns: int,
        *,
        reset_history: bool = True,
    ) -> None:
        original_column_count = controller.table.table_model.columnCount()
        current_row = controller.table.currentIndex().row()
        current_column = controller.table.currentIndex().column()
        columns_added = False
        if controller is self._xy_paired_controller:
            while (
                len(self.workbook.active_sheet.xy_settings.paired_series_ids) * 2
                < needed_columns
            ):
                self.add_xy_pair(reload_views=False)
                columns_added = True
        else:
            table = self._active_xy_shared_table()
            while table is None or len(table.series_ids) + 1 < needed_columns:
                self._add_xy_y_column(reload_views=False)
                columns_added = True
                table = self._active_xy_shared_table()
        if not columns_added:
            return
        self._load_xy_workspace_views()
        row_count = controller.table.table_model.rowCount()
        column_count = controller.table.table_model.columnCount()
        if row_count and column_count:
            controller.table.setCurrentIndex(
                controller.table.table_model.index(
                    min(max(current_row, 0), row_count - 1),
                    min(max(current_column, 0), column_count - 1),
                )
            )
        if (
            reset_history
            and controller.table.table_model.columnCount()
            != original_column_count
        ):
            controller.reset_history()

    def add_row(self) -> None:
        if not self._is_xy_sheet():
            self._table_controller.add_sample_row()
            return
        sheet = self.workbook.active_sheet
        self._sync_xy_views_to_sheet()
        sheet.dataframe.loc[len(sheet.dataframe)] = [
            "" for _ in sheet.dataframe.columns
        ]
        self._load_xy_workspace_views()
        self._record_recovery_sheet_state()

    def add_custom_overlay_row(self) -> None:
        if self.workbook.active_sheet.mode == SHEET_MODE_XY:
            return

        def add_overlay_row() -> bool:
            self.settings.extra_custom_overlay = True
            self.extra_custom_overlay.setChecked(True)
            series, count, enabled = overlay_table_state_after_add(self.custom_overlay_series_from_table())
            self.settings.custom_overlay_series = series
            self.settings.custom_overlay_count = count
            self.settings.extra_custom_overlay = enabled
            self._sync_custom_overlay_visibility()
            self.set_table_dataframe(
                self.table_dataframe(),
                series,
                restore_group_capacity=True,
            )
            row = self.sample_start_row() - 1
            if row > 0:
                self.table.setCurrentIndex(self.table.table_model.index(row, 0))
            return True

        self._run_table_history_mutation(
            add_overlay_row,
            after=lambda _changed: (
                self._update_dependent_control_states(),
                self.schedule_render(),
            ),
        )

    def remove_custom_overlay_row(self) -> None:
        if self.workbook.active_sheet.mode == SHEET_MODE_XY:
            return
        if self.custom_overlay_row_count() == 0:
            return
        row = overlay_row_for_removal(self.table.currentIndex().row(), self.sample_start_row())
        header = self.table.table_model.headerData(row, Qt.Vertical, Qt.DisplayRole)
        name = overlay_row_name(str(header) if header is not None else None, row)
        answer = QMessageBox.warning(
            self,
            self.tr("Delete Overlay"),
            self.tr("Delete overlay '{name}'? Its values will be permanently lost.").format(name=name),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        def remove_overlay_row() -> bool:
            sample_df = self.table_dataframe()
            result = overlay_table_state_after_remove(
                self.custom_overlay_series_from_table(),
                self.settings.custom_overlay_hidden,
                index=row - 1,
            )
            self.settings.custom_overlay_hidden = result.hidden_indexes
            self.settings.custom_overlay_series = result.series
            self.settings.custom_overlay_count = result.count
            self.settings.extra_custom_overlay = result.enabled
            if not result.series:
                self.extra_custom_overlay.blockSignals(True)
                self.extra_custom_overlay.setChecked(False)
                self.extra_custom_overlay.blockSignals(False)
            self._sync_custom_overlay_visibility()
            self.set_table_dataframe(
                sample_df,
                result.series,
                restore_group_capacity=True,
            )
            return True

        self._run_table_history_mutation(
            remove_overlay_row,
            after=lambda _changed: (
                self._update_dependent_control_states(),
                self.schedule_render(),
            ),
        )

    def edit_custom_overlay_filter(self) -> None:
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        if not self.settings.custom_overlay_series:
            QMessageBox.information(
                self,
                self.tr("Overlay Filter"),
                self.tr("Add an overlay row first."),
            )
            return
        hidden = run_checklist_filter_dialog(
            self,
            "Overlay Filter",
            [
                ChecklistItem(
                    str(index),
                    (
                        str(series.get("name", "")).strip()
                        if isinstance(series, dict)
                        else ""
                    ) or f"Overlay {index + 1}",
                )
                for index, series in enumerate(self.settings.custom_overlay_series)
            ],
            {str(index) for index in self.settings.custom_overlay_hidden},
        )
        if hidden is None:
            return
        self.settings.custom_overlay_hidden = [int(index) for index in hidden]
        overlay_count = len(self.settings.custom_overlay_series)
        self.extra_custom_overlay.setChecked(
            any(index not in self.settings.custom_overlay_hidden for index in range(overlay_count))
        )
        self.settings.extra_custom_overlay = self.extra_custom_overlay.isChecked()
        self._sync_custom_overlay_visibility()
        self._update_dependent_control_states()
        self._record_recovery_settings()
        self.render()

    def _overlay_style_selection(self) -> OverlayStyleSelection:
        return OverlayStyleSelection(styles=dict(self.settings.custom_overlay_styles))

    def _apply_overlay_style_selection(self, selection: OverlayStyleSelection) -> None:
        self.settings.custom_overlay_styles = dict(selection.styles)
        self._record_recovery_settings()
        self.render()

    def edit_custom_overlay_styles(self) -> None:
        self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        style_items = overlay_style_items(
            self._user_group_dataframe(),
            self.settings,
        )
        if not style_items:
            QMessageBox.information(
                self,
                self.tr("Custom Overlay Line Styles"),
                self.tr("Add an overlay row first."),
            )
            return

        original = self._overlay_style_selection()
        result = run_overlay_styles_dialog(
            self,
            style_items,
            self.settings.line_overlay_style,
            self.settings.custom_overlay_styles,
            self._apply_overlay_style_selection,
            self._populate_line_style_combo,
            self._polish_combo_box,
        )
        self._apply_overlay_style_selection(original if result is None else result)

    def rename_overlay_row(self, row: int) -> None:
        if not (0 < row < self.sample_start_row()):
            return
        header = self.table.table_model.headerData(row, Qt.Vertical, Qt.DisplayRole)
        current = str(header) if header is not None else f"Overlay {row}"
        name, ok = QInputDialog.getMultiLineText(self, self.tr("Rename Overlay"), self.tr("Legend name"), text=current)
        if not ok:
            return
        self._run_table_settings_mutation(
            lambda: self._rename_overlay_row_state(row, name),
            after=lambda _changed: (
                self.refresh_table_structure(),
                self.schedule_render(),
            ),
        )

    def _rename_overlay_row_state(self, row: int, name: str) -> bool:
        self.settings.custom_overlay_series = overlay_table_state_after_rename(
            self.custom_overlay_series_from_table(),
            row,
            name,
        )
        return True

    def add_column(self) -> None:
        table = self.table
        table.clearSelection()
        table.selectionModel().clearCurrentIndex()
        self.insert_table_structure("entire_column", table)

    def delete_column(self) -> None:
        column = self.table.currentIndex().column()
        if self._is_xy_sheet() and column == 0:
            self.statusBar().showMessage(
                self.tr("The shared X column cannot be deleted; delete the tab instead."),
                3000,
            )
            return
        if column < 0:
            column = self.table.table_model.columnCount() - 1
        if column >= 0:
            self.table.selectColumn(column)
        self.delete_table_structure("entire_column", self.table)

    def rename_column(self, table_widget=None, col: int | None = None) -> None:
        table_widget = self.table if table_widget is None else table_widget
        controller = (
            self._xy_paired_controller
            if table_widget is self.xy_independent_table
            else self._table_controller
        )
        if col is None:
            col = table_widget.currentIndex().column()
        if col < 0:
            col = max(0, table_widget.table_model.columnCount() - 1)
        if col < 0:
            return
        current = controller.group_names()[col]
        is_xy = self.workbook.active_sheet.mode == SHEET_MODE_XY
        name, ok = QInputDialog.getMultiLineText(
            self,
            self.tr("Rename Column") if is_xy else self.tr("Rename Group"),
            self.tr("Column name") if is_xy else self.tr("Group name"),
            text=current,
        )
        if ok and name.strip():
            new_name = name.strip()
            linked_columns = [col] if is_xy else self.grouping_controls.linked_columns(col)

            def rename_group_header() -> bool:
                for index in linked_columns:
                    set_group_header(table_widget, index, new_name)
                return True

            controller.run_block_mutation(
                [(0, index) for index in linked_columns],
                rename_group_header,
                after=lambda _changed: (
                    self.refresh_table_structure(),
                    self.sync_manual_group_order(),
                    self._sync_xy_views_to_sheet() if is_xy else None,
                    self._schedule_table_capacity_update(),
                ),
            )

    def update_settings(self, *_args) -> None:
        if self._applying_settings:
            return
        self._commit_pending_control_edits()
        if self._is_xy_sheet():
            mixed_spin_field = self._xy_style_field_for_sender(self.sender())
            if (
                mixed_spin_field in self._xy_mixed_style_fields
                and isinstance(
                    self._xy_style_control_for_field(mixed_spin_field),
                    QDoubleSpinBox,
                )
                and not self._xy_mixed_spin_input_is_explicit(
                    mixed_spin_field
                )
            ):
                self._restore_unedited_xy_mixed_spin(mixed_spin_field)
                return
        existing_overlay_series = self.custom_overlay_series_from_table()
        self.settings.chart_type = (
            "Scatter" if self._is_xy_sheet() else self.chart_type.currentText()
        )
        self.settings.preset = self.preset.currentText()
        self.settings.group_order = self.group_order.currentText()
        self.sync_manual_group_order()
        self.settings.title = self.title.toPlainText()
        self.settings.x_label = self.x_label.toPlainText()
        self.settings.y_label = self.y_label.toPlainText()
        self.settings.secondary_y_label = self.secondary_y_label.toPlainText()
        if not self._is_xy_sheet():
            self.settings.show_points = self.show_points.isChecked()
            self.settings.point_size = self.point_size.value()
            self.settings.point_alpha = self.point_alpha.value()
        self.settings.jitter_mode = self.jitter_mode.currentText()
        self.settings.jitter = self.jitter.value()
        self.settings.line_overlay_stat = self.line_overlay_stat.currentText()
        self.settings.show_line_overlay = self.settings.line_overlay_stat != "None"
        overlay_count, has_overlay_series = custom_overlay_state_from_series(existing_overlay_series)
        self.settings.extra_custom_overlay = self.extra_custom_overlay.isChecked() and has_overlay_series
        self.settings.custom_overlay_count = overlay_count
        if self.settings.extra_custom_overlay and len(self.settings.custom_overlay_hidden) >= len(existing_overlay_series):
            self.settings.custom_overlay_hidden = []
        self.settings.custom_overlay_secondary_axis = self.custom_overlay_secondary_axis.isChecked()
        self.sync_custom_overlay_rows(existing_overlay_series)
        self.settings.line_overlay_width = self.line_overlay_width.value()
        self.settings.line_overlay_style = self.line_overlay_style.currentText()
        self.settings.line_overlay_break_between_parents = self.line_overlay_break_between_parents.isChecked()
        self.settings.line_overlay_point_size = self.line_overlay_point_size.value()
        self.settings.show_line_values = self.show_line_values.isChecked()
        self._refresh_line_value_position_options()
        self.settings.line_value_position = self.line_value_position.currentText()
        self.settings.custom_line_value_position = self.custom_line_value_position.currentText()
        self.settings.line_value_scientific = self.line_value_scientific.isChecked()
        self.settings.line_value_decimals = self.line_value_decimals.value()
        self.settings.line_value_font_size = self.line_value_font_size.value()
        self.settings.show_stat_table = self.show_stat_table.isChecked()
        for setting_name, _label in STAT_TABLE_OPTIONS:
            setattr(self.settings, setting_name, self._stat_table_option_checked(setting_name))
        restore_stored_stat_header = self.sender() in (self.chart_type, self.show_stat_table)
        stat_header_forced = self._sync_stat_table_header_control(restore_stored=restore_stored_stat_header)
        if not stat_header_forced:
            self.settings.show_stat_header = self.show_stat_header.isChecked()
        self.settings.stat_table_font_size = self.stat_table_font_size.value()
        self.settings.show_outliers = self.show_outliers.isChecked()
        self.settings.outlier_method = self.outlier_method.currentText()
        self.settings.outlier_threshold = self.outlier_threshold.value()
        self.settings.outlier_effect = self.outlier_effect.currentText()
        self.settings.width = self.width.value()
        self.settings.height = self.height.value()
        self.settings.dpi = self.dpi.value()
        self.settings.title_font_size = self.title_font_size.value()
        self.settings.axis_label_font_size = self.axis_label_font_size.value()
        self.settings.tick_font_size = self.tick_font_size.value()
        self.settings.additional_guide_font_size = (
            self.additional_guide_font_size.value()
        )
        self.settings.show_legend = self.show_legend.isChecked()
        self.settings.legend_font_size = self.legend_font_size.value()
        self.settings.legend_width = self.legend_width.value()
        self.settings.legend_columns = self._legend_columns_control_value()
        self.settings.legend_auto_width = self.legend_auto_width.isChecked() and self.settings.legend_columns > 0
        previous_legend_position = self.settings.legend_position
        self.settings.legend_position = self._legend_position_control_value()
        if previous_legend_position != self.settings.legend_position and self.settings.legend_position == LEGEND_POSITION_INSIDE:
            self.settings.legend_inside_x = LEGEND_INSIDE_AUTO_POSITION
            self.settings.legend_inside_y = LEGEND_INSIDE_AUTO_POSITION
        self.settings.axis_line_width = self.axis_line_width.value()
        self.settings.additional_guide_line_width = (
            self.additional_guide_line_width.value()
        )
        self.settings.show_grid = self.show_grid.isChecked()
        self.settings.auto_x_range = self.auto_x_range.isChecked()
        self.settings.x_min = self.x_min.value()
        self.settings.x_max = self.x_max.value()
        self.settings.x_auto_tick_interval = self.x_auto_tick_interval.isChecked()
        self.settings.x_tick_interval = self.x_tick_interval.value()
        self.settings.x_tick_rotation = self.x_tick_rotation.value()
        self.settings.auto_y_range = self.auto_y_range.isChecked()
        self.settings.y_min = self.y_min.value()
        self.settings.y_max = self.y_max.value()
        self.settings.primary_auto_tick_interval = self.primary_auto_tick_interval.isChecked()
        self.settings.primary_tick_interval = self.primary_tick_interval.value()
        self.settings.secondary_auto_y_range = self.secondary_auto_y_range.isChecked()
        self.settings.secondary_y_min = self.secondary_y_min.value()
        self.settings.secondary_y_max = self.secondary_y_max.value()
        self.settings.secondary_auto_tick_interval = self.secondary_auto_tick_interval.isChecked()
        self.settings.secondary_tick_interval = self.secondary_tick_interval.value()
        self.settings.split_secondary_axis = self.split_secondary_axis.isChecked()
        self.settings.secondary_axis_split_ratio = self.secondary_axis_split_ratio.value()
        self.settings.transparent_background = self.transparent_background.isChecked()
        self.settings.fill_alpha = self.fill_alpha.value()
        self.settings.box_width = self.box_width.value()
        self.settings.box_whisker_mode = self.box_whisker_mode.currentText()
        self.settings.bar_width = self.bar_width.value()
        self.settings.bar_summary = self.bar_summary.currentData()
        self.settings.violin_width = self.violin_width.value()
        self.settings.kde_bandwidth = self.kde_bandwidth.value()
        self.settings.ridge_overlap = self.ridge_overlap.value()
        if not self._is_xy_sheet():
            self.settings.group_outer_spacing = self.group_outer_spacing.value()
        if self._is_xy_sheet():
            xy_settings = self.workbook.active_sheet.xy_settings
            style_field = self._xy_style_field_for_sender(self.sender())
            scope, selected_series = self._xy_style_selection()
            style_values = self._xy_style_control_values()
            if style_field is not None:
                style_control = self._xy_style_control_for_field(style_field)
                if (
                    isinstance(style_control, QCheckBox)
                    and style_control.checkState()
                    == Qt.CheckState.PartiallyChecked
                ) or (
                    isinstance(style_control, QComboBox)
                    and style_control.currentData() == XY_MIXED_COMBO_DATA
                ):
                    return
                if scope == "all":
                    self._set_xy_all_series_style_value(
                        style_field,
                        style_values[style_field],
                    )
                elif selected_series:
                    self._set_selected_xy_series_style_values(
                        selected_series,
                        style_field,
                        style_values[style_field],
                    )
                self._apply_xy_series_style_scope_to_controls()
            elif self.sender() is None and scope == "all":
                # Programmatic callers historically use update_settings() to
                # commit all controls. Preserve that path without erasing
                # per-series overrides, which were not edited here.
                for field, value in style_values.items():
                    setattr(xy_settings, field, value)
                self._normalize_xy_series_display_after_style_change(None, None)
            self._record_recovery_sheet_state()
        self._update_dependent_control_states()
        self._record_recovery_settings()
        if self.sender() in (self.title, self.x_label, self.y_label, self.secondary_y_label):
            self.schedule_render(RenderMode.TEXT_ONLY)
        else:
            self.schedule_render(RenderMode.FULL)

    def _commit_pending_control_edits(self) -> None:
        if self._committing_control_edits:
            return
        self._committing_control_edits = True
        try:
            sender = self.sender()
            mixed_spin_controls = {
                self._xy_style_control_for_field(field)
                for field in self._xy_mixed_style_fields
                if field in {"point_size", "point_alpha", "line_width"}
            }
            for spin_box in self._spin_boxes():
                if spin_box in mixed_spin_controls and spin_box is not sender:
                    continue
                spin_box.interpretText()
        finally:
            self._committing_control_edits = False

    def handle_preset_changed(self, *_args) -> None:
        if not self._applying_settings:
            self.settings.custom_colors = {}
            self.settings.custom_overlay_colors = {}
        self.update_settings()

    @staticmethod
    def _xy_fit_numeric_signature(
        spec: XYFitSpec,
        x_values: object,
        y_values: object,
    ) -> str:
        numeric_settings = (
            spec.model_id,
            spec.expression,
            spec.syntax_version,
            tuple(
                (
                    parameter.name,
                    parameter.initial,
                    parameter.lower,
                    parameter.upper,
                    parameter.fixed,
                )
                for parameter in spec.parameters
            ),
        )
        digest = hashlib.blake2b(digest_size=20)
        digest.update(repr(numeric_settings).encode("utf-8"))
        digest.update(np.asarray(x_values, dtype="<f8").tobytes())
        digest.update(b"\0")
        digest.update(np.asarray(y_values, dtype="<f8").tobytes())
        return digest.hexdigest()

    def _xy_fit_jobs_and_signatures(
        self,
        sheet: SheetDocument,
        dataframe: pd.DataFrame,
        *,
        auto_only: bool,
        build_jobs: bool = True,
        prepared: PreparedXYData | None = None,
    ) -> tuple[list[XYFitJob], dict[str, str]]:
        if prepared is None:
            prepared = prepare_xy_data(
                dataframe,
                sheet.column_ids,
                sheet.xy_settings,
                order_mode=self.settings.group_order,
            )
        series_by_id = {series.id: series for series in prepared.series}
        jobs: list[XYFitJob] = []
        signatures: dict[str, str] = {}
        for spec in sheet.xy_settings.fit_specs:
            if not spec.enabled or (auto_only and not spec.auto_refit):
                continue
            series = series_by_id.get(spec.series_id)
            if series is None:
                x_values = np.asarray((), dtype=float)
                y_values = np.asarray((), dtype=float)
            else:
                x_values = np.asarray(series.x, dtype=float)
                y_values = np.asarray(series.y, dtype=float)
            signatures[spec.id] = self._xy_fit_numeric_signature(
                spec,
                x_values,
                y_values,
            )
            if build_jobs:
                jobs.append(
                    XYFitJob(
                        spec=deepcopy(spec),
                        x=tuple(float(value) for value in x_values),
                        y=tuple(float(value) for value in y_values),
                    )
                )
        return jobs, signatures

    def _xy_fit_results_for_render(
        self,
        sheet: SheetDocument,
        dataframe: pd.DataFrame,
        *,
        prepared: PreparedXYData | None = None,
    ) -> dict[str, XYFitResult]:
        sheet_results = self._xy_fit_results_by_sheet.setdefault(sheet.id, {})
        sheet_signatures = self._xy_fit_signatures_by_sheet.setdefault(sheet.id, {})
        live_fit_ids = {spec.id for spec in sheet.xy_settings.fit_specs}
        for fit_id in set(sheet_results) - live_fit_ids:
            sheet_results.pop(fit_id, None)
        for fit_id in set(sheet_signatures) - live_fit_ids:
            sheet_signatures.pop(fit_id, None)

        _jobs, current_signatures = self._xy_fit_jobs_and_signatures(
            sheet,
            dataframe,
            auto_only=False,
            build_jobs=False,
            prepared=prepared,
        )
        specs_by_id = {spec.id: spec for spec in sheet.xy_settings.fit_specs}
        inflight = self._xy_fit_inflight_signatures.get(sheet.id, {})
        stale_fit_ids = []
        for fit_id, signature in current_signatures.items():
            spec = specs_by_id[fit_id]
            if spec.auto_refit:
                if sheet_signatures.get(fit_id) == signature:
                    continue
                sheet_results.pop(fit_id, None)
                sheet_signatures.pop(fit_id, None)
            elif fit_id in sheet_results or fit_id in sheet_signatures:
                continue
            if inflight.get(fit_id) != signature:
                stale_fit_ids.append(fit_id)

        if stale_fit_ids:
            pending_token = (
                sheet.id,
                tuple(
                    sorted(
                        (fit_id, current_signatures[fit_id])
                        for fit_id in stale_fit_ids
                    )
                ),
            )
            if pending_token != self._xy_fit_pending_token:
                self._xy_fit_pending_token = pending_token
                self._xy_fit_timer.start(XY_FIT_DEBOUNCE_MS)
        elif self._xy_fit_pending_token is not None:
            pending_sheet_id, _pending_signatures = self._xy_fit_pending_token
            if pending_sheet_id == sheet.id:
                self._xy_fit_pending_token = None
                self._xy_fit_timer.stop()
        return dict(sheet_results)

    def _start_xy_auto_fit(self) -> None:
        self._xy_fit_pending_token = None
        sheet = self.workbook.active_sheet
        if sheet.mode != SHEET_MODE_XY or not sheet.xy_settings.fit_specs:
            return
        dataframe = self.table_dataframe()
        jobs, current_signatures = self._xy_fit_jobs_and_signatures(
            sheet,
            dataframe,
            auto_only=False,
        )
        cached_signatures = self._xy_fit_signatures_by_sheet.setdefault(
            sheet.id,
            {},
        )
        cached_results = self._xy_fit_results_by_sheet.setdefault(sheet.id, {})
        inflight = self._xy_fit_inflight_signatures.setdefault(sheet.id, {})
        self._cancel_superseded_xy_fit_workers(
            sheet.id,
            current_signatures,
        )
        jobs = [
            job
            for job in jobs
            if (
                (
                    job.spec.auto_refit
                    and cached_signatures.get(job.spec.id)
                    != current_signatures[job.spec.id]
                )
                or (
                    not job.spec.auto_refit
                    and job.spec.id not in cached_results
                    and job.spec.id not in cached_signatures
                )
            )
            and inflight.get(job.spec.id) != current_signatures[job.spec.id]
        ]
        if not jobs:
            return
        submitted_signatures = {
            job.spec.id: current_signatures[job.spec.id]
            for job in jobs
        }
        inflight.update(submitted_signatures)
        worker = XYFitBatchWorker(jobs)
        self._xy_fit_workers.add(worker)
        self._xy_fit_worker_context[worker.signals] = (
            worker,
            sheet.id,
            submitted_signatures,
        )
        worker.signals.finished.connect(self._handle_xy_fit_batch_finished)
        worker.signals.failed.connect(self._handle_xy_fit_batch_failed)
        QThreadPool.globalInstance().start(worker)

    def _cancel_superseded_xy_fit_workers(
        self,
        sheet_id: str,
        current_signatures: dict[str, str],
    ) -> None:
        """Cancel stale batches and make their still-current jobs eligible again."""

        for signals, context in tuple(self._xy_fit_worker_context.items()):
            worker, worker_sheet_id, submitted_signatures = context
            if worker_sheet_id != sheet_id or not any(
                current_signatures.get(fit_id) != signature
                for fit_id, signature in submitted_signatures.items()
            ):
                continue
            self._xy_fit_worker_context.pop(signals, None)
            self._xy_fit_workers.discard(worker)
            self._clear_matching_xy_fit_inflight(
                sheet_id,
                submitted_signatures,
            )
            try:
                cancel = getattr(worker, "cancel", None)
                if callable(cancel):
                    cancel()
            except RuntimeError:
                # The runnable can be auto-deleted while its queued signal is
                # waiting for delivery; removing the context still makes that
                # stale completion harmless.
                continue

    def _take_xy_fit_worker_context(
        self,
    ) -> tuple[XYFitBatchWorker, str, dict[str, str]] | None:
        signals = self.sender()
        context = self._xy_fit_worker_context.pop(signals, None)
        if context is not None:
            self._xy_fit_workers.discard(context[0])
        return context

    def _current_xy_fit_signatures(self, sheet_id: str) -> dict[str, str]:
        sheet = next(
            (candidate for candidate in self.workbook.sheets if candidate.id == sheet_id),
            None,
        )
        if sheet is None or sheet.mode != SHEET_MODE_XY:
            return {}
        dataframe = (
            self.table_dataframe()
            if self.workbook.active_sheet_id == sheet_id
            else sheet.dataframe
        )
        _jobs, signatures = self._xy_fit_jobs_and_signatures(
            sheet,
            dataframe,
            auto_only=False,
            build_jobs=False,
        )
        return signatures

    def _clear_matching_xy_fit_inflight(
        self,
        sheet_id: str,
        submitted_signatures: dict[str, str],
    ) -> None:
        inflight = self._xy_fit_inflight_signatures.get(sheet_id, {})
        for fit_id, signature in submitted_signatures.items():
            if inflight.get(fit_id) == signature:
                inflight.pop(fit_id, None)

    def _handle_xy_fit_batch_finished(
        self,
        results: dict[str, XYFitResult],
    ) -> None:
        context = self._take_xy_fit_worker_context()
        if context is None:
            return
        _worker, sheet_id, submitted_signatures = context
        self._clear_matching_xy_fit_inflight(sheet_id, submitted_signatures)
        current_signatures = self._current_xy_fit_signatures(sheet_id)
        cached_results = self._xy_fit_results_by_sheet.setdefault(sheet_id, {})
        cached_signatures = self._xy_fit_signatures_by_sheet.setdefault(sheet_id, {})
        accepted = False
        for fit_id, signature in submitted_signatures.items():
            if current_signatures.get(fit_id) != signature or fit_id not in results:
                continue
            result = results[fit_id]
            cached_results[fit_id] = result
            cached_signatures[fit_id] = signature
            accepted = True
        if (
            accepted
            and self.workbook.active_sheet_id == sheet_id
            and self._active_xy_fit_dialog_sheet_id != sheet_id
        ):
            self.schedule_render(delay_ms=0)

    def _handle_xy_fit_batch_failed(self, _message: str) -> None:
        context = self._take_xy_fit_worker_context()
        if context is None:
            return
        _worker, sheet_id, submitted_signatures = context
        self._clear_matching_xy_fit_inflight(sheet_id, submitted_signatures)
        current_signatures = self._current_xy_fit_signatures(sheet_id)
        cached_signatures = self._xy_fit_signatures_by_sheet.setdefault(sheet_id, {})
        for fit_id, signature in submitted_signatures.items():
            if current_signatures.get(fit_id) == signature:
                # Prevent an unexpected worker-level error from creating a
                # retry loop on every redraw. Editing data/settings retries it.
                cached_signatures[fit_id] = signature

    def _reset_xy_fit_runtime(self) -> None:
        self._xy_fit_timer.stop()
        self._xy_fit_pending_token = None
        self._cancel_xy_fit_workers()
        self._xy_fit_results_by_sheet.clear()
        self._xy_fit_signatures_by_sheet.clear()
        self._xy_fit_inflight_signatures.clear()

    def _cancel_xy_fit_workers(self) -> None:
        workers = tuple(self._xy_fit_workers)
        self._xy_fit_workers.clear()
        self._xy_fit_worker_context.clear()
        for worker in workers:
            try:
                cancel = getattr(worker, "cancel", None)
                if callable(cancel):
                    cancel()
            except RuntimeError:
                # A QRunnable can be auto-deleted just before its queued
                # completion signal is delivered to the GUI thread.
                continue

    def schedule_render(
        self,
        mode: RenderMode = RenderMode.FULL,
        *,
        delay_ms: int | None = None,
    ) -> None:
        if mode == RenderMode.FULL or not self._render_pending:
            self._scheduled_render_mode = mode
        self._render_pending = True
        delay = APP_RENDER_DEBOUNCE_MS if delay_ms is None else max(0, int(delay_ms))
        self._render_timer.start(delay)

    def flush_pending_render(self) -> None:
        if not self._render_pending:
            return
        if self._render_timer.isActive():
            self._render_timer.stop()
        mode = self._scheduled_render_mode
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        if mode == RenderMode.TEXT_ONLY and self._render_text_only():
            return
        self.render()

    def _render_text_only(self) -> bool:
        if self.canvas is None or self.canvas.figure is None or self.canvas.canvas is None or not self.canvas.figure.axes:
            return False
        last_settings = getattr(self.canvas, "_last_settings", None)
        if last_settings is None or self._text_layout_signature(last_settings) != self._text_layout_signature(self.settings):
            return False
        ax = self.canvas.figure.axes[0]
        preset = PRESETS.get(self.settings.preset)
        if preset is None:
            return False
        text_color = "#F9FAFB" if preset["background"] != "#FFFFFF" else "#222222"
        x_axis_label, y_axis_label = axis_labels_for_chart(self.settings)
        custom_overlay_secondary_axis_active = self.canvas._custom_overlay_secondary_axis_active(self.settings)
        split_secondary_frame = self.canvas._split_secondary_frame_enabled(self.settings)
        ax.set_title("" if split_secondary_frame else self.settings.title, fontsize=self.settings.title_font_size, color=text_color)
        ax.set_xlabel(x_axis_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        ax.set_ylabel(y_axis_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        secondary_ax = self._secondary_axis_for_sync() if custom_overlay_secondary_axis_active else None
        if secondary_ax is not None:
            if self.settings.chart_type == "Ridge":
                if split_secondary_frame:
                    self.canvas._set_split_secondary_title(secondary_ax, ax, self.settings, text_color)
                secondary_ax.set_xlabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
            elif split_secondary_frame:
                self.canvas._set_split_secondary_title(secondary_ax, ax, self.settings, text_color)
                secondary_ax.set_xlabel("", fontsize=self.settings.axis_label_font_size, color=text_color)
                secondary_ax.set_ylabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
            else:
                secondary_ax.set_ylabel(self.settings.secondary_y_label, fontsize=self.settings.axis_label_font_size, color=text_color)
        self.canvas.canvas.draw()
        table_ax = next(
            (
                axis
                for axis in self.canvas.figure.axes
                if axis is not ax
                and axis is not secondary_ax
                and not axis.axison
            ),
            None,
        )
        self.canvas._last_settings = ChartSettings(**asdict(self.settings))
        self.canvas._refresh_interaction_targets(
            self.settings,
            ax,
            table_ax,
            secondary_ax,
        )
        self._record_recovery_settings(dirty=False)
        self._update_sheet_tab_texts()
        return True

    def _text_layout_signature(
        self,
        settings: ChartSettings,
    ) -> tuple[tuple[int, bool], tuple[int, bool], tuple[int, bool], tuple[int, bool], tuple[int, int]]:
        x_axis_label, y_axis_label = axis_labels_for_chart(settings)

        def footprint(text: str) -> tuple[int, bool]:
            return (self.canvas._line_count(text), bool(text))

        y_overflow = 0
        x_overflow = 0
        if settings.chart_type in {"Box", "Bar", "Violin"} and y_axis_label:
            label_height_in = self.canvas._max_text_width_inches([y_axis_label], settings.axis_label_font_size)
            y_overflow = max(0, int(math.ceil((label_height_in - settings.height / 2.54) * 100)))
            if self.canvas._custom_overlay_secondary_axis_active(settings) and settings.secondary_y_label:
                secondary_label_height_in = self.canvas._max_text_width_inches([settings.secondary_y_label], settings.axis_label_font_size)
                y_overflow = max(y_overflow, max(0, int(math.ceil((secondary_label_height_in - settings.height / 2.54) * 100))))
        if settings.chart_type == "Ridge" and x_axis_label:
            label_width_in = self.canvas._max_text_width_inches([x_axis_label], settings.axis_label_font_size)
            x_overflow = max(0, int(math.ceil((label_width_in - settings.width / 2.54) * 100)))
            if self.canvas._custom_overlay_secondary_axis_active(settings) and settings.secondary_y_label:
                secondary_label_width_in = self.canvas._max_text_width_inches([settings.secondary_y_label], settings.axis_label_font_size)
                x_overflow = max(x_overflow, max(0, int(math.ceil((secondary_label_width_in - settings.width / 2.54) * 100))))

        secondary_label = settings.secondary_y_label if self.canvas._custom_overlay_secondary_axis_active(settings) else ""
        return (
            footprint(settings.title),
            footprint(x_axis_label),
            footprint(y_axis_label),
            footprint(secondary_label),
            (y_overflow, x_overflow),
        )

    def render(self) -> None:
        if self._render_timer.isActive():
            self._render_timer.stop()
        self._render_pending = False
        self._scheduled_render_mode = RenderMode.FULL
        sheet = self.workbook.active_sheet
        if sheet.mode != SHEET_MODE_XY:
            self.settings.custom_overlay_series = self.custom_overlay_series_from_table()
        physical_dataframe = self.table_dataframe()
        dataframe = (
            physical_dataframe
            if sheet.mode == SHEET_MODE_XY
            else self._user_group_dataframe(physical_dataframe)
        )
        self.refresh_analysis_results(dataframe)
        canvas = self._ensure_plot_canvas()
        if sheet.mode == SHEET_MODE_XY:
            prepared_xy_data = prepare_xy_data(
                dataframe,
                sheet.column_ids,
                sheet.xy_settings,
                order_mode=self.settings.group_order,
            )
            xy_fit_results = self._xy_fit_results_for_render(
                sheet,
                dataframe,
                prepared=prepared_xy_data,
            )
            canvas.render(
                dataframe,
                self.settings,
                xy_settings=sheet.xy_settings,
                column_ids=sheet.column_ids,
                xy_fit_results=xy_fit_results,
                prepared_xy_data=prepared_xy_data,
            )
            if self._selected_plot_object_kind == "points":
                self._apply_xy_series_style_scope_to_controls()
                self._update_inspector_context("points")
            else:
                self._refresh_xy_series_selection_list()
        else:
            migrate_group_settings(self.settings, dataframe)
            canvas.render(dataframe, self.settings, grouping=sheet.grouping, column_ids=group_keys(dataframe))
        self._sync_auto_y_axis_controls()
        self._sync_auto_tick_interval_controls()
        self._record_recovery_settings(dirty=False)
        # The plot consumes the semantic Groups view, while the workbook keeps
        # the physical editing capacity (including its trailing spare cells).
        self._update_sheet_tab_texts(physical_dataframe)

    def _update_group_axis_controls(self) -> None:
        was_blocked = self.group_outer_spacing.blockSignals(True)
        try:
            self.group_outer_spacing.setMinimum(self.settings.group_inner_spacing)
            self.group_outer_spacing.setValue(self.settings.group_outer_spacing)
        finally:
            self.group_outer_spacing.blockSignals(was_blocked)
        has_parent_groups = not self._is_xy_sheet() and bool(self.workbook.active_sheet.grouping.parents)
        self.ui.categoryAxisForm.setRowVisible(self.ui.parentGroupSpacingLabel, has_parent_groups)
        self.ui.categoryAxisForm.setRowVisible(self.ui.groupLayoutButton, has_parent_groups)
        self.ui.lineOverlayBreakBetweenParentsLabel.setEnabled(has_parent_groups)
        self.line_overlay_break_between_parents.setEnabled(has_parent_groups)

    def _update_chart_specific_controls(self) -> None:
        self._update_group_axis_controls()
        chart_type = self.chart_type.currentText()
        self._set_legend_position_value(self.settings.legend_position)
        refresh_chart_toolbar_icons(self)
        titles = {
            "Box": self.tr("Box Style"),
            "Bar": self.tr("Bar Style"),
            "Violin": self.tr("Violin Style"),
            "Ridge": self.tr("Ridge Style"),
        }
        rows = {
            "Bar": {
                self.ui.barWidthLabel,
                self.ui.barSummaryLabel,
                self.ui.fillAlphaLabel,
            },
            "Box": {
                self.ui.boxWidthLabel,
                self.ui.boxWhiskerLabel,
                self.ui.fillAlphaLabel,
            },
            "Violin": {
                self.ui.violinWidthLabel,
                self.ui.kdeBandwidthLabel,
                self.ui.fillAlphaLabel,
            },
            "Ridge": {
                self.ui.kdeBandwidthLabel,
                self.ui.ridgeOverlapLabel,
                self.ui.fillAlphaLabel,
            },
        }
        controls_by_label = {
            self.ui.boxWidthLabel: self.box_width,
            self.ui.boxWhiskerLabel: self.box_whisker_mode,
            self.ui.barWidthLabel: self.bar_width,
            self.ui.barSummaryLabel: self.bar_summary,
            self.ui.violinWidthLabel: self.violin_width,
            self.ui.kdeBandwidthLabel: self.kde_bandwidth,
            self.ui.ridgeOverlapLabel: self.ridge_overlap,
            self.ui.fillAlphaLabel: self.fill_alpha,
        }
        visible_labels = rows.get(chart_type, set(controls_by_label))
        if chart_type == "Bar" and self.settings.bar_summary == "No line or error bar":
            visible_labels.difference_update({self.ui.barWidthLabel, self.ui.fillAlphaLabel})
        summary_help = {
            "Mean": self.tr("Bar height is the arithmetic mean, without error bars."),
            "Mean with SD": self.tr("Mean plus/minus sample SD. Error bars require at least 2 valid values per column."),
            "Mean with SEM": self.tr("Mean plus/minus SEM (sample SD divided by the square root of n). Error bars require at least 2 valid values per column."),
            "Mean with 95% CI": self.tr("95% confidence interval of the mean using Student's t distribution. Requires at least 2 valid values per column."),
            "Mean with range": self.tr("Bar height is the mean; error bars span the minimum to maximum."),
            "Median": self.tr("Bar height is the median, without error bars."),
            "Median with 95% CI": self.tr("Nonparametric 95% CI from ordered values (binomial method; coverage is at least 95%). Requires at least 6 valid values per column; otherwise only the median is drawn."),
            "Median with range": self.tr("Bar height is the median; error bars span the minimum to maximum."),
            "No line or error bar": self.tr("Hide summary bars and error bars. Scatter points follow the point visibility and style settings."),
        }
        self.bar_summary.setToolTip(summary_help.get(self.settings.bar_summary, ""))
        self.ui.specificGroup.setTitle(
            titles.get(chart_type, self.tr("Chart Style"))
        )
        for label, control in controls_by_label.items():
            visible = label in visible_labels
            if hasattr(self.ui.specificForm, "setRowVisible"):
                self.ui.specificForm.setRowVisible(label, visible)
            else:
                label.setVisible(visible)
                control.setVisible(visible)

    def _update_dependent_control_states(self) -> None:
        self._apply_sheet_mode_ui()
        self._update_chart_specific_controls()
        is_xy = self._is_xy_sheet()
        ridge_numeric_axis = self.chart_type.currentText() == "Ridge"
        if is_xy:
            self.ui.categoryAxisGroup.setTitle(self.tr("X Axis"))
            self.ui.primaryAxisGroup.setTitle(self.tr("Y Axis"))
            self.ui.secondaryAxisGroup.setTitle(self.tr("Secondary Y Axis"))
        elif ridge_numeric_axis:
            self.ui.categoryAxisGroup.setTitle(self.tr("Y Axis"))
            self.ui.primaryAxisGroup.setTitle(self.tr("Primary X Axis"))
            self.ui.secondaryAxisGroup.setTitle(self.tr("Secondary X Axis"))
        else:
            self.ui.categoryAxisGroup.setTitle(self.tr("X Axis"))
            self.ui.primaryAxisGroup.setTitle(self.tr("Primary Y Axis"))
            self.ui.secondaryAxisGroup.setTitle(self.tr("Secondary Y Axis"))
        auto_x_enabled = self.auto_x_range.isChecked()
        for widget in (
            self.x_min_label,
            self.x_min,
            self.x_max_label,
            self.x_max,
        ):
            widget.setEnabled(is_xy and not auto_x_enabled)
        x_auto_tick_enabled = self.x_auto_tick_interval.isChecked()
        self.x_tick_interval_label.setEnabled(is_xy and not x_auto_tick_enabled)
        self.x_tick_interval.setEnabled(is_xy and not x_auto_tick_enabled)
        auto_y_enabled = self.auto_y_range.isChecked()
        for widget in [self.ui.yMinLabel, self.y_min, self.ui.yMaxLabel, self.y_max]:
            widget.setEnabled(not auto_y_enabled)
        primary_auto_tick_enabled = self.primary_auto_tick_interval.isChecked()
        self.primary_tick_interval_label.setEnabled(not primary_auto_tick_enabled)
        self.primary_tick_interval.setEnabled(not primary_auto_tick_enabled)
        custom_overlay_axis_available = self._custom_overlay_axis_available()

        secondary_axis_enabled = self.custom_overlay_secondary_axis.isChecked() and custom_overlay_axis_available
        if hasattr(self.ui.titleAxisForm, "setRowVisible"):
            self.ui.titleAxisForm.setRowVisible(
                self.secondary_y_label_label,
                secondary_axis_enabled,
            )
        else:
            self.secondary_y_label_label.setVisible(secondary_axis_enabled)
            self.secondary_y_label.setVisible(secondary_axis_enabled)
        secondary_auto_y_enabled = self.secondary_auto_y_range.isChecked()
        split_secondary_enabled = secondary_axis_enabled
        for widget in [
            self.secondary_auto_y_range_label,
            self.secondary_auto_y_range,
            self.secondary_y_min_label,
            self.secondary_y_min,
            self.secondary_y_max_label,
            self.secondary_y_max,
            self.secondary_auto_tick_interval_label,
            self.secondary_auto_tick_interval,
            self.secondary_tick_interval_label,
            self.secondary_tick_interval,
            self.split_secondary_axis_label,
            self.split_secondary_axis,
            self.secondary_axis_split_ratio_label,
            self.secondary_axis_split_ratio,
        ]:
            widget.setEnabled(secondary_axis_enabled)
        for widget in [self.secondary_y_min_label, self.secondary_y_min, self.secondary_y_max_label, self.secondary_y_max]:
            widget.setEnabled(secondary_axis_enabled and not secondary_auto_y_enabled)
        secondary_auto_tick_enabled = self.secondary_auto_tick_interval.isChecked()
        self.secondary_tick_interval_label.setEnabled(secondary_axis_enabled and not secondary_auto_tick_enabled)
        self.secondary_tick_interval.setEnabled(secondary_axis_enabled and not secondary_auto_tick_enabled)
        self.split_secondary_axis_label.setEnabled(split_secondary_enabled)
        self.split_secondary_axis.setEnabled(split_secondary_enabled)
        self.secondary_axis_split_ratio_label.setEnabled(split_secondary_enabled and self.split_secondary_axis.isChecked())
        self.secondary_axis_split_ratio.setEnabled(split_secondary_enabled and self.split_secondary_axis.isChecked())

        stat_overlay_enabled = self.line_overlay_stat.currentText() != "None"
        custom_overlay_enabled = self.extra_custom_overlay.isChecked()
        line_overlay_enabled = stat_overlay_enabled or custom_overlay_enabled
        line_value_font_enabled = line_overlay_enabled and self.show_line_values.isChecked()
        has_custom_overlay_rows = self.custom_overlay_row_count() > 0
        self.add_overlay_button.setEnabled(True)
        self.remove_overlay_button.setEnabled(has_custom_overlay_rows)
        self.custom_overlay_filter_button.setEnabled(has_custom_overlay_rows)
        self.edit_overlay_styles_button.setEnabled(has_custom_overlay_rows)
        self.ui.customOverlayCountLabel.setEnabled(has_custom_overlay_rows)
        self.custom_overlay_secondary_axis_label.setEnabled(custom_overlay_axis_available)
        self.custom_overlay_secondary_axis.setEnabled(custom_overlay_axis_available)
        for widget in [
            self.ui.lineOverlayWidthLabel,
            self.line_overlay_width,
            self.ui.lineOverlayStyleLabel,
            self.line_overlay_style,
            self.ui.lineOverlayPointSizeLabel,
            self.line_overlay_point_size,
            self.ui.showLineValuesLabel,
            self.show_line_values,
            self.ui.customLineValuePositionLabel,
            self.custom_line_value_position,
        ]:
            widget.setEnabled(line_overlay_enabled)
        for widget in (
            self.ui.lineValueScientificLabel, self.line_value_scientific,
            self.ui.lineValueDecimalsLabel, self.line_value_decimals,
        ):
            widget.setEnabled(line_overlay_enabled or self.show_stat_table.isChecked())
        self.ui.lineValueSizeLabel.setEnabled(line_value_font_enabled)
        self.line_value_font_size.setEnabled(line_value_font_enabled)
        self.ui.lineValuePositionLabel.setEnabled(stat_overlay_enabled)
        self.line_value_position.setEnabled(stat_overlay_enabled)
        self.ui.customLineValuePositionLabel.setEnabled(custom_overlay_enabled)
        self.custom_line_value_position.setEnabled(custom_overlay_enabled)
        legend_enabled = self.show_legend.isChecked()
        self.ui.toolbarLegendSizeLabel.setEnabled(legend_enabled)
        self.legend_font_size.setEnabled(legend_enabled)
        self.ui.legendPositionLabel.setEnabled(legend_enabled)
        self.legend_position.setEnabled(legend_enabled)
        self.ui.legendAutoWidthLabel.setEnabled(legend_enabled)
        self.legend_auto_width.setEnabled(legend_enabled)
        self.ui.legendWidthLabel.setEnabled(
            legend_enabled and not self.legend_auto_width.isChecked()
        )
        self.legend_width.setEnabled(legend_enabled and not self.legend_auto_width.isChecked())
        self.ui.legendColumnsLabel.setEnabled(legend_enabled)
        self.legend_columns.setEnabled(legend_enabled)
        stat_table_enabled = self.show_stat_table.isChecked()
        self._sync_stat_table_header_control()
        self.ui.statTableSizeLabel.setEnabled(stat_table_enabled)
        self.stat_table_font_size.setEnabled(stat_table_enabled)
        if self._is_xy_sheet():
            xy_settings = self.workbook.active_sheet.xy_settings
            scope, selected_series = self._xy_style_selection()
            has_targets = scope == "all" or bool(selected_series)
            self.ui.showPointsLabel.setEnabled(has_targets)
            self.show_points.setEnabled(has_targets)
            self.ui.xyShowLineLabel.setEnabled(has_targets)
            self.xy_show_line.setEnabled(has_targets)
            if not has_targets:
                points_enabled = False
                lines_enabled = False
            elif scope == "subset":
                points_enabled = any(
                    bool(
                        self._resolved_xy_style_value(
                            xy_settings,
                            series,
                            "show_points",
                        )
                    )
                    for series in selected_series
                )
                lines_enabled = any(
                    bool(
                        self._resolved_xy_style_value(
                            xy_settings,
                            series,
                            "show_line",
                        )
                    )
                    for series in selected_series
                )
            else:
                points_enabled = self.show_points.isChecked() or any(
                    series.visible and series.show_points is True
                    for series in xy_settings.series
                )
            for widget in (
                self.ui.xyMarkerLabel,
                self.xy_marker,
                self.ui.pointSizeLabel,
                self.point_size,
                self.ui.pointAlphaLabel,
                self.point_alpha,
            ):
                widget.setEnabled(points_enabled)
            if scope == "all":
                lines_enabled = self.xy_show_line.isChecked() or any(
                    series.visible and series.show_line is True
                    for series in xy_settings.series
                )
            for widget in (
                self.ui.xyLineWidthLabel,
                self.xy_line_width,
                self.ui.xyLineStyleLabel,
                self.xy_line_style,
            ):
                widget.setEnabled(lines_enabled)

    def _sync_auto_y_axis_controls(self) -> None:
        if not self.canvas.figure.axes:
            return
        ax = self.canvas.figure.axes[0]
        if self._is_xy_sheet() and self.settings.auto_x_range:
            x_min, x_max = ax.get_xlim()
            if math.isfinite(x_min) and math.isfinite(x_max):
                self._sync_range_spin_boxes(
                    self.x_min,
                    self.x_max,
                    x_min,
                    x_max,
                )
                self.settings.x_min = float(x_min)
                self.settings.x_max = float(x_max)
        if self.settings.auto_y_range:
            y_min, y_max = ax.get_xlim() if self.settings.chart_type == "Ridge" else ax.get_ylim()
            if math.isfinite(y_min) and math.isfinite(y_max):
                self._sync_range_spin_boxes(self.y_min, self.y_max, y_min, y_max)
                self.settings.y_min = float(self.y_min.value())
                self.settings.y_max = float(self.y_max.value())
                if self.settings.chart_type == "Ridge":
                    ax.set_xlim(self.settings.y_min, self.settings.y_max)
                else:
                    ax.set_ylim(self.settings.y_min, self.settings.y_max)
        secondary_ax = self._secondary_axis_for_sync()
        if self.settings.custom_overlay_secondary_axis and self.settings.secondary_auto_y_range and secondary_ax is not None:
            y_min, y_max = secondary_ax.get_xlim() if self.settings.chart_type == "Ridge" else secondary_ax.get_ylim()
            if math.isfinite(y_min) and math.isfinite(y_max):
                self._sync_range_spin_boxes(self.secondary_y_min, self.secondary_y_max, y_min, y_max)
                self.settings.secondary_y_min = float(self.secondary_y_min.value())
                self.settings.secondary_y_max = float(self.secondary_y_max.value())
                if self.settings.chart_type == "Ridge":
                    secondary_ax.set_xlim(self.settings.secondary_y_min, self.settings.secondary_y_max)
                else:
                    secondary_ax.set_ylim(self.settings.secondary_y_min, self.settings.secondary_y_max)
        self.canvas.canvas.draw()

    def _sync_range_spin_boxes(self, min_spin: QDoubleSpinBox, max_spin: QDoubleSpinBox, min_value: float, max_value: float) -> None:
        min_was_blocked = min_spin.blockSignals(True)
        max_was_blocked = max_spin.blockSignals(True)
        try:
            self._set_range_spin_box_values_preserving_range(
                min_spin,
                max_spin,
                min_value,
                max_value,
            )
        finally:
            min_spin.blockSignals(min_was_blocked)
            max_spin.blockSignals(max_was_blocked)

    @staticmethod
    def _set_range_spin_box_values_preserving_range(
        min_spin: QDoubleSpinBox,
        max_spin: QDoubleSpinBox,
        min_value: float,
        max_value: float,
    ) -> None:
        base_decimals = max(
            int(
                getattr(
                    min_spin,
                    "_easygraph_base_decimals",
                    min_spin.decimals(),
                )
            ),
            int(
                getattr(
                    max_spin,
                    "_easygraph_base_decimals",
                    max_spin.decimals(),
                )
            ),
        )
        span = abs(float(max_value) - float(min_value))
        required_decimals = base_decimals
        if math.isfinite(span) and span > 0.0:
            required_decimals = max(
                required_decimals,
                -math.floor(math.log10(span)) + 2,
            )
        for spin_box, value in (
            (min_spin, min_value),
            (max_spin, max_value),
        ):
            MainWindow._set_spin_box_value_preserving_range(
                spin_box,
                value,
                minimum_decimals=required_decimals,
            )

    @staticmethod
    def _set_spin_box_value_preserving_range(
        spin_box: QDoubleSpinBox,
        value: float,
        *,
        minimum_decimals: int = 0,
    ) -> None:
        numeric_value = float(value)
        base_decimals = getattr(
            spin_box,
            "_easygraph_base_decimals",
            spin_box.decimals(),
        )
        spin_box._easygraph_base_decimals = base_decimals
        required_decimals = max(base_decimals, int(minimum_decimals))
        if math.isfinite(numeric_value) and numeric_value != 0.0:
            required_decimals = max(
                required_decimals,
                0,
                -math.floor(math.log10(abs(numeric_value))) + 3,
            )
        spin_box.setDecimals(min(15, required_decimals))
        if numeric_value < spin_box.minimum():
            spin_box.setMinimum(numeric_value)
        if numeric_value > spin_box.maximum():
            spin_box.setMaximum(numeric_value)
        spin_box.setValue(numeric_value)

    def _sync_auto_tick_interval_controls(self) -> None:
        if not self.canvas.figure.axes:
            return
        fallback_axes = getattr(self.canvas, "_auto_tick_interval_fallbacks", set())
        ax = self.canvas.figure.axes[0]
        if self._is_xy_sheet():
            if "x" in fallback_axes:
                self._set_check_box_without_signal(
                    self.x_auto_tick_interval,
                    True,
                )
                self.settings.x_auto_tick_interval = True
            if self.settings.x_auto_tick_interval:
                self._sync_tick_interval_spin_box(
                    self.x_tick_interval,
                    ax,
                    dimension="x",
                )
                self.settings.x_tick_interval = float(
                    self.x_tick_interval.value()
                )
        if "primary" in fallback_axes:
            self._set_check_box_without_signal(self.primary_auto_tick_interval, True)
            self.settings.primary_auto_tick_interval = True
        if self.settings.primary_auto_tick_interval:
            self._sync_tick_interval_spin_box(self.primary_tick_interval, ax)
            self.settings.primary_tick_interval = float(self.primary_tick_interval.value())

        secondary_ax = self._secondary_axis_for_sync()
        if secondary_ax is not None:
            if "secondary" in fallback_axes:
                self._set_check_box_without_signal(self.secondary_auto_tick_interval, True)
                self.settings.secondary_auto_tick_interval = True
            if self.settings.custom_overlay_secondary_axis and self.settings.secondary_auto_tick_interval:
                self._sync_tick_interval_spin_box(self.secondary_tick_interval, secondary_ax)
                self.settings.secondary_tick_interval = float(self.secondary_tick_interval.value())
        if fallback_axes:
            self._update_dependent_control_states()

    def _sync_tick_interval_spin_box(
        self,
        spin_box: QDoubleSpinBox,
        ax,
        *,
        dimension: str | None = None,
    ) -> None:
        interval = self._auto_tick_interval_for_axis(ax, dimension=dimension)
        if interval is None:
            return
        spin_box.blockSignals(True)
        try:
            self._set_spin_box_value_preserving_range(spin_box, interval)
        finally:
            spin_box.blockSignals(False)

    def _auto_tick_interval_for_axis(
        self,
        ax,
        *,
        dimension: str | None = None,
    ) -> float | None:
        use_x_axis = (
            dimension == "x"
            or (dimension is None and self.settings.chart_type == "Ridge")
        )
        ticks = ax.get_xticks() if use_x_axis else ax.get_yticks()
        finite_ticks = sorted(float(tick) for tick in ticks if math.isfinite(float(tick)))
        diffs = [
            finite_ticks[index + 1] - finite_ticks[index]
            for index in range(len(finite_ticks) - 1)
            if finite_ticks[index + 1] > finite_ticks[index]
        ]
        if not diffs:
            return None
        interval = float(np.median(diffs))
        return interval if math.isfinite(interval) and interval > 0 else None

    def _set_check_box_without_signal(self, check_box: QCheckBox, checked: bool) -> None:
        check_box.blockSignals(True)
        try:
            check_box.setChecked(checked)
        finally:
            check_box.blockSignals(False)

    def _secondary_axis_for_sync(self):
        for axis in self.canvas.figure.axes[1:]:
            if axis.get_gid() == "secondary-axis":
                return axis
            if self.settings.chart_type == "Ridge" and axis.xaxis.label.get_text() == self.settings.secondary_y_label:
                return axis
            if self.settings.chart_type != "Ridge" and axis.yaxis.label.get_text() == self.settings.secondary_y_label:
                return axis
        return None

    def _commit_pending_project_edits(self) -> None:
        editor = QApplication.focusWidget()
        if isinstance(editor, QLineEdit) and self.table.isAncestorOf(editor):
            self.table.commitData(editor)
            self.table.closeEditor(editor, QAbstractItemDelegate.EndEditHint.NoHint)
        self._commit_pending_control_edits()

    def _project_content_snapshot(self) -> tuple:
        self._commit_pending_project_edits()
        self._store_active_sheet(commit=False)
        return tuple(self._sheet_content_snapshot(sheet) for sheet in self.workbook.sheets)

    def _set_saved_project_baseline(
        self,
        *,
        replace_recovery: bool = False,
    ) -> None:
        self._saved_project_content = self._project_content_snapshot()
        self._saved_sheet_content = {
            sheet.id: self._sheet_content_snapshot(sheet)
            for sheet in self.workbook.sheets
        }
        if replace_recovery:
            self._replace_recovery_document(dirty=False)
        else:
            self._mark_recovery_clean()
        self._update_sheet_tab_texts()

    def has_unsaved_changes(self) -> bool:
        if self._saved_project_content is None:
            return False
        return self._project_content_snapshot() != self._saved_project_content

    def _prompt_unsaved_changes(self) -> str:
        dialog = QMessageBox(self)
        dialog.setIcon(QMessageBox.Icon.Warning)
        dialog.setWindowTitle(self.tr("Unsaved Changes"))
        dialog.setText(
            self.tr(
                "The current project has unsaved changes. "
                "Do you want to save them before continuing?"
            )
        )
        save_button = dialog.addButton(self.tr("Save"), QMessageBox.ButtonRole.AcceptRole)
        discard_button = dialog.addButton(self.tr("Discard"), QMessageBox.ButtonRole.DestructiveRole)
        cancel_button = dialog.addButton(self.tr("Cancel"), QMessageBox.ButtonRole.RejectRole)
        dialog.setDefaultButton(save_button)
        dialog.setEscapeButton(cancel_button)
        dialog.exec()
        clicked = dialog.clickedButton()
        if clicked is save_button:
            return "save"
        if clicked is discard_button:
            return "discard"
        return "cancel"

    def _confirm_unsaved_changes(self) -> bool:
        if not self.has_unsaved_changes():
            return True
        choice = self._prompt_unsaved_changes()
        if choice == "save":
            return self.save_project()
        return choice == "discard"

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._confirm_unsaved_changes():
            self._cancel_xy_fit_workers()
            if self._recovery_manager is not None:
                self._recovery_manager.close(discard=True)
                self._recovery_manager = None
            super().closeEvent(event)
        else:
            event.ignore()

    def new_project(self, mode: str = SHEET_MODE_GROUPS) -> None:
        if not self._confirm_unsaved_changes():
            return
        self._replace_project_with_sheet(
            self._blank_sheet_document(mode, "Sheet 1"),
            render=True,
        )

    @property
    def recovered_on_startup(self) -> bool:
        return self._recovered_on_startup

    def initialize_startup_project(
        self, mode: str, *, demo: bool, grouped_demo: bool = False,
    ) -> None:
        sheet = (
            self._demo_sheet_document(mode, "Sheet 1", grouped_demo=grouped_demo)
            if demo
            else self._blank_sheet_document(mode, "Sheet 1")
        )
        self._replace_project_with_sheet(sheet, render=False)

    def _replace_project_with_sheet(
        self,
        sheet: SheetDocument,
        *,
        render: bool,
    ) -> None:
        self.clear_plot_object_selection()
        self.current_project = None
        dataframe = sheet.dataframe
        self.settings = sheet.settings
        self.workbook = WorkbookDocument([sheet], sheet.id)
        self._reset_xy_fit_runtime()
        session = SheetSessionState()
        self._sheet_sessions = {self.workbook.active_sheet_id: session}
        self._table_controller.history = session.history
        self.results_table.set_visible_statistics(
            self.workbook.active_sheet.analysis_settings.visible_statistics
        )
        self.set_table_dataframe(dataframe, restore_group_capacity=True)
        self.sync_manual_group_order()
        self.apply_settings_to_controls()
        self.refresh_template_combo(TEMPLATE_NONE_NAME)
        self.update_table_history_actions()
        self._rebuild_sheet_tabs()
        if render:
            self.render()
        self._set_saved_project_baseline(replace_recovery=True)

    def _settings_for_new_project(self) -> ChartSettings:
        template_settings, _xy_style = self._style_template_for_new_sheet(
            SHEET_MODE_GROUPS
        )
        return self._new_sheet_settings(
            blank_project_data(),
            SHEET_MODE_GROUPS,
            template_settings,
        )

    def save_current_template(self) -> None:
        self.update_settings()
        self.flush_pending_render()
        family = self._active_style_template_family()
        name, ok = QInputDialog.getText(self, self.tr("Save Style Template"), self.tr("Template name"))
        if not ok:
            return
        try:
            path = write_style_template(
                name,
                self.settings,
                xy_settings=(
                    self.workbook.active_sheet.xy_settings
                    if self._is_xy_sheet()
                    else None
                ),
                family=family,
            )
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template save failed"), str(exc))
            return
        self.refresh_template_combo(path.stem)
        self.statusBar().showMessage(self.tr("Style template saved: {name}").format(name=path.stem), 2500)

    def load_external_template(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Load Style Template"), "", self.tr("Style Template (*.json);;All Files (*)"))
        if not path:
            return
        source_path = Path(path)
        family = self._active_style_template_family()
        try:
            imported_families = style_template_families_file(source_path)
            imported = import_style_template(source_path)
            name = imported[0]
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Template load failed"), str(exc))
            self.refresh_template_combo()
            return
        if family not in imported_families:
            self.refresh_template_combo(TEMPLATE_NONE_NAME)
            self.statusBar().showMessage(
                self.tr(
                    "Style template imported, but it has no {family} variant "
                    "to apply on this sheet."
                ).format(
                    family=(
                        self.tr("XY")
                        if family == TEMPLATE_FAMILY_XY
                        else self.tr("Groups")
                    )
                ),
                3500,
            )
            return
        try:
            settings = read_style_template(name, family=family)
            xy_style = (
                read_xy_style_template(name, family=family)
                if family == TEMPLATE_FAMILY_XY
                else None
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                self.tr("Template load failed"),
                str(exc),
            )
            self.refresh_template_combo(TEMPLATE_NONE_NAME)
            return
        self.refresh_template_combo(name)
        self.apply_style_template(name, settings, xy_style)
        self.statusBar().showMessage(self.tr("Style template loaded: {name}").format(name=name), 2500)

    def save_project(self) -> bool:
        if not self.current_project:
            return self.save_project_as()
        return self._save_project_path(self.current_project)

    def _save_project_path(self, path: Path) -> bool:
        self.update_settings()
        self.flush_pending_render()
        self._store_active_sheet()
        project_path = project_path_with_suffix(Path(path))
        try:
            write_project(project_path, self.workbook)
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Project save failed"), str(exc))
            return False
        self.current_project = project_path
        remember_recent_project(project_path)
        self.update_recent_projects_menu()
        self._set_saved_project_baseline()
        return True

    def save_project_as(self) -> bool:
        path, _ = QFileDialog.getSaveFileName(self, self.tr("Save Project"), "", self.tr("EasyGraph Project (*.eg);;All Files (*)"))
        if not path:
            return False
        return self._save_project_path(Path(path))

    def open_project(self) -> None:
        if not self._confirm_unsaved_changes():
            return
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Open Project"), "", self.tr("EasyGraph Project (*.eg);;All Files (*)"))
        if not path:
            return
        self._load_project_path(Path(path))

    def open_recent_project(self, path: Path) -> None:
        project_path = Path(path)
        if not project_path.is_file():
            self._handle_missing_recent_project(project_path)
            return
        if not self._confirm_unsaved_changes():
            return
        try:
            self._load_project_path(project_path)
        except FileNotFoundError:
            self._handle_missing_recent_project(project_path)
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Project open failed"), str(exc))

    def _handle_missing_recent_project(self, project_path: Path) -> None:
        forget_recent_project(project_path)
        self.update_recent_projects_menu()
        QMessageBox.warning(
            self,
            self.tr("Recent project unavailable"),
            self.tr("The selected recent project could not be found:\n{path}").format(path=project_path),
        )

    def open_project_path(self, path: Path) -> bool:
        project_path = Path(path)
        if not project_path.is_file():
            QMessageBox.critical(
                self,
                self.tr("Project open failed"),
                self.tr("The selected project could not be found:\n{path}").format(
                    path=project_path
                ),
            )
            return False
        if not self._confirm_unsaved_changes():
            return False
        try:
            self._load_project_path(project_path)
        except Exception as exc:
            QMessageBox.critical(
                self,
                self.tr("Project open failed"),
                str(exc),
            )
            return False
        return True

    def _load_project_path(self, path: Path) -> None:
        workbook = read_workbook_project(path)
        self.current_project = path
        self.workbook = workbook
        self._reset_xy_fit_runtime()
        self.settings = workbook.active_sheet.settings
        self._sheet_sessions = {
            sheet.id: SheetSessionState()
            for sheet in workbook.sheets
        }
        self._table_controller.history = self._sheet_session(workbook.active_sheet.id).history
        self._load_active_sheet(render=False)
        self._rebuild_sheet_tabs()
        self.refresh_template_combo(TEMPLATE_NONE_NAME)
        # Startup keeps the placeholder until the window has been shown and
        # initialize_preview creates the canvas, just as it does for demos.
        if self.canvas is not None:
            self.render()
            self._fit_initial_plot_to_viewport()
        remember_recent_project(path)
        self.update_recent_projects_menu()
        self._set_saved_project_baseline(replace_recovery=True)

    def apply_settings_to_controls(self) -> None:
        self._applying_settings = True
        try:
            self._apply_sheet_mode_ui()
            if not self._is_xy_sheet():
                self.chart_type.setCurrentText(self.settings.chart_type)
            self.preset.setCurrentText(self.settings.preset)
            self.group_order.setCurrentText(self.settings.group_order)
            self.title.setPlainText(self.settings.title)
            self.x_label.setPlainText(self.settings.x_label)
            self.y_label.setPlainText(self.settings.y_label)
            self.secondary_y_label.setPlainText(self.settings.secondary_y_label)
            if self._is_xy_sheet():
                self._apply_xy_series_style_scope_to_controls()
            else:
                self._set_xy_style_controls(
                    {
                        "show_points": self.settings.show_points,
                        "show_line": True,
                        "marker": "Circle",
                        "line_style": "Solid",
                        "point_size": self.settings.point_size,
                        "point_alpha": self.settings.point_alpha,
                        "line_width": 1.6,
                    }
                )
            self.jitter_mode.setCurrentText(self.settings.jitter_mode)
            self.jitter.setValue(self.settings.jitter)
            self.show_line_overlay.setChecked(self.settings.line_overlay_stat != "None")
            self.line_overlay_stat.setCurrentText(self.settings.line_overlay_stat)
            self.extra_custom_overlay.setChecked(self.settings.extra_custom_overlay)
            self.custom_overlay_count.setValue(max(1, len(self.settings.custom_overlay_series), self.settings.custom_overlay_count))
            self.custom_overlay_secondary_axis.setChecked(self.settings.custom_overlay_secondary_axis)
            self.sync_custom_overlay_rows()
            self.line_overlay_width.setValue(self.settings.line_overlay_width)
            self.line_overlay_style.setCurrentText(self.settings.line_overlay_style)
            self.line_overlay_break_between_parents.setChecked(self.settings.line_overlay_break_between_parents)
            self.line_overlay_point_size.setValue(self.settings.line_overlay_point_size)
            self.show_line_values.setChecked(self.settings.show_line_values)
            self._refresh_line_value_position_options(self.settings.line_value_position)
            self.line_value_position.setCurrentText(self.settings.line_value_position)
            self.custom_line_value_position.setCurrentText(
                normalize_overlay_label_position(self.settings.custom_line_value_position, self.settings.chart_type, is_custom_overlay=True)
            )
            self.line_value_scientific.setChecked(self.settings.line_value_scientific)
            self.line_value_decimals.setValue(self.settings.line_value_decimals)
            self.line_value_font_size.setValue(self.settings.line_value_font_size)
            self.show_stat_table.setChecked(self.settings.show_stat_table)
            self._apply_stat_table_options_to_controls()
            self.show_stat_header.setChecked(self.settings.show_stat_header)
            self._sync_stat_table_header_control()
            self.stat_table_font_size.setValue(self.settings.stat_table_font_size)
            self.show_outliers.setChecked(self.settings.show_outliers)
            self.outlier_method.setCurrentText(self.settings.outlier_method)
            self.outlier_threshold.setValue(self.settings.outlier_threshold)
            self.outlier_effect.setCurrentText(self.settings.outlier_effect)
            self.width.setValue(self.settings.width)
            self.height.setValue(self.settings.height)
            self.dpi.setValue(self.settings.dpi)
            self.title_font_size.setValue(self.settings.title_font_size)
            self.axis_label_font_size.setValue(self.settings.axis_label_font_size)
            self.tick_font_size.setValue(self.settings.tick_font_size)
            self.additional_guide_font_size.setValue(
                self.settings.additional_guide_font_size
            )
            self.show_legend.setChecked(self.settings.show_legend)
            self.legend_font_size.setValue(self.settings.legend_font_size)
            self.legend_width.setValue(self.settings.legend_width)
            self._set_legend_position_value(self.settings.legend_position)
            self._set_legend_auto_width_checked(self.settings.legend_auto_width)
            self._set_legend_columns_value(self.settings.legend_columns)
            self.axis_line_width.setValue(self.settings.axis_line_width)
            self.additional_guide_line_width.setValue(
                self.settings.additional_guide_line_width
            )
            self._refresh_additional_guide_color_options()
            self.show_grid.setChecked(self.settings.show_grid)
            self.auto_x_range.setChecked(self.settings.auto_x_range)
            self._set_range_spin_box_values_preserving_range(
                self.x_min,
                self.x_max,
                self.settings.x_min,
                self.settings.x_max,
            )
            self.x_auto_tick_interval.setChecked(
                self.settings.x_auto_tick_interval
            )
            self._set_spin_box_value_preserving_range(
                self.x_tick_interval,
                self.settings.x_tick_interval,
            )
            self.x_tick_rotation.setValue(self.settings.x_tick_rotation)
            self.auto_y_range.setChecked(self.settings.auto_y_range)
            self.y_min.setValue(self.settings.y_min)
            self.y_max.setValue(self.settings.y_max)
            self.primary_auto_tick_interval.setChecked(self.settings.primary_auto_tick_interval)
            self.primary_tick_interval.setValue(self.settings.primary_tick_interval)
            self.secondary_auto_y_range.setChecked(self.settings.secondary_auto_y_range)
            self.secondary_y_min.setValue(self.settings.secondary_y_min)
            self.secondary_y_max.setValue(self.settings.secondary_y_max)
            self.secondary_auto_tick_interval.setChecked(self.settings.secondary_auto_tick_interval)
            self.secondary_tick_interval.setValue(self.settings.secondary_tick_interval)
            self.split_secondary_axis.setChecked(self.settings.split_secondary_axis)
            self.secondary_axis_split_ratio.setValue(self.settings.secondary_axis_split_ratio)
            self.transparent_background.setChecked(self.settings.transparent_background)
            self.fill_alpha.setValue(self.settings.fill_alpha)
            self.box_width.setValue(self.settings.box_width)
            self.box_whisker_mode.setCurrentText(self.settings.box_whisker_mode)
            self.bar_width.setValue(self.settings.bar_width)
            self.bar_summary.setCurrentIndex(self.bar_summary.findData(self.settings.bar_summary))
            self.violin_width.setValue(self.settings.violin_width)
            self.kde_bandwidth.setValue(self.settings.kde_bandwidth)
            self.ridge_overlap.setValue(self.settings.ridge_overlap)
            self._update_contextual_font_slots()
            self._update_dependent_control_states()
        finally:
            self._applying_settings = False

    def _apply_imported_dataframe(
        self,
        df: pd.DataFrame,
        overlay_series: list[dict] | None = None,
    ) -> None:
        imported_overlay = list(overlay_series or [])
        self.settings.custom_overlay_series = imported_overlay
        self.settings.custom_overlay_count, self.settings.extra_custom_overlay = custom_overlay_state_from_series(imported_overlay)
        self.settings.custom_overlay_hidden = []
        self.set_table_dataframe(df, imported_overlay)
        self._sync_custom_overlay_visibility_to_controls()
        self.sync_manual_group_order()
        self.reset_table_history()
        self.render()

    def _apply_imported_workbook(self, imported_sheets: list[SpreadsheetSheet]) -> None:
        if not imported_sheets:
            return
        self.update_settings()
        base_settings = deepcopy(self.settings)
        names: list[str] = []
        sheets = []
        for imported in imported_sheets:
            name = unique_sheet_name(names, imported.name)
            names.append(name)
            mode = normalized_sheet_mode(imported.mode)
            settings = deepcopy(base_settings)
            settings.custom_overlay_series = (
                deepcopy(imported.overlay_series)
                if mode == SHEET_MODE_GROUPS
                else []
            )
            settings.custom_overlay_count, settings.extra_custom_overlay = custom_overlay_state_from_series(
                settings.custom_overlay_series
            )
            settings.custom_overlay_hidden = []
            if mode == SHEET_MODE_GROUPS:
                (
                    settings.manual_group_order,
                    settings.group_hidden,
                ) = sync_group_order_state(
                    [str(column) for column in imported.dataframe.columns],
                    [],
                    settings.group_hidden,
                )
            if mode == SHEET_MODE_XY:
                settings.chart_type = "Scatter"
                settings.title = self.tr("XY plot")
                settings.x_label = "X"
                settings.y_label = "Y"
                settings.show_stat_table = False
            sheet = SheetDocument(
                name=name,
                dataframe=imported.dataframe.copy(deep=True),
                settings=settings,
                mode=mode,
                column_ids=list(imported.dataframe.attrs.get("group_column_ids", [])) if mode == SHEET_MODE_GROUPS else [],
            )
            if mode == SHEET_MODE_GROUPS:
                sheet.grouping = grouping_from_dict(imported.dataframe.attrs.get("grouping"), sheet.column_ids)
            if mode == SHEET_MODE_XY:
                sheet.xy_settings = XYSettings()
                self._configure_xy_table_layout(sheet)
            sheets.append(sheet)
        self.workbook = WorkbookDocument(sheets, sheets[0].id)
        self._reset_xy_fit_runtime()
        self.settings = self.workbook.active_sheet.settings
        self._sheet_sessions = {sheet.id: SheetSessionState() for sheet in sheets}
        self._table_controller.history = self._sheet_session(self.workbook.active_sheet.id).history
        self._load_active_sheet(render=False)
        self._rebuild_sheet_tabs()
        self.render()
        self._replace_recovery_document(dirty=True)

    def import_excel(self) -> None:
        if not self._confirm_unsaved_changes():
            return
        path, _ = QFileDialog.getOpenFileName(self, self.tr("Import Excel"), "", self.tr("Excel Files (*.xlsx *.xls);;CSV Files (*.csv)"))
        if not path:
            return
        try:
            input_path = Path(path)
            if input_path.suffix.casefold() == ".csv":
                df, overlay_series = read_spreadsheet(input_path)
                imported = [SpreadsheetSheet(input_path.stem or "Sheet 1", df, overlay_series)]
            else:
                imported = read_spreadsheet_book(input_path)
            selected = choose_spreadsheet_sheets(self, imported)
            if selected is None:
                return
            self._apply_imported_workbook(selected)
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Import failed"), str(exc))

    def import_prism_data(self) -> None:
        if not self._confirm_unsaved_changes():
            return
        path, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("Import Prism PZFX"),
            "",
            self.tr("Prism PZFX (*.pzfx);;Legacy Prism PZF (*.pzf);;All Files (*)"),
        )
        if not path:
            return
        try:
            results = choose_prism_tables(self, Path(path))
            if not results:
                return
            imported_sheets = [
                SpreadsheetSheet(result.table.display_title, result.dataframe)
                for result in results
            ]
            self._apply_imported_workbook(imported_sheets)
            group_count = sum(len(result.dataframe.columns) for result in results)
            message = self.tr(
                "Imported {groups} Prism groups from {tables} tables into sheets"
            ).format(
                groups=group_count,
                tables=len(results),
            )
            excluded_count = sum(result.excluded_count for result in results)
            if excluded_count:
                message += self.tr("; {count} excluded values became empty cells").format(
                    count=excluded_count
                )
            self.statusBar().showMessage(message, 8000)
        except PrismImportError as exc:
            QMessageBox.critical(self, self.tr("Import failed"), prism_error_text(exc))
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Import failed"), str(exc))

    def export_excel(self) -> None:
        path, selected_filter = QFileDialog.getSaveFileName(
            self,
            self.tr("Export Excel"),
            "",
            self.tr(
                "Excel Workbook — All Sheets (*.xlsx);;"
                "Current Sheet Excel (*.xlsx);;"
                "Current Sheet CSV (*.csv)"
            ),
        )
        if not path:
            return
        try:
            self._store_active_sheet()
            output_path = Path(path)
            if "*.csv" in selected_filter and not output_path.suffix:
                output_path = Path(f"{output_path}.csv")
            export_current_sheet = "Current Sheet" in selected_filter
            sheet = self.workbook.active_sheet
            active_overlay_series = (
                []
                if sheet.mode == SHEET_MODE_XY
                else sheet.settings.custom_overlay_series
            )
            active_dataframe = (
                sheet.dataframe
                if sheet.mode == SHEET_MODE_XY
                else self._user_group_sheet_dataframe(sheet)
            )
            if output_path.suffix.casefold() == ".csv":
                write_spreadsheet(
                    output_path,
                    active_dataframe,
                    active_overlay_series,
                )
            elif export_current_sheet or len(self.workbook.sheets) == 1:
                write_spreadsheet_book(
                    output_path,
                    [
                        SpreadsheetSheet(
                            sheet.name,
                            active_dataframe,
                            active_overlay_series,
                        )
                    ],
                )
            else:
                write_spreadsheet_book(
                    output_path,
                    [
                        SpreadsheetSheet(
                            sheet.name,
                            (
                                sheet.dataframe
                                if sheet.mode == SHEET_MODE_XY
                                else self._user_group_sheet_dataframe(sheet)
                            ),
                            (
                                []
                                if sheet.mode == SHEET_MODE_XY
                                else sheet.settings.custom_overlay_series
                            ),
                        )
                        for sheet in self.workbook.sheets
                    ],
                )
        except Exception as exc:
            QMessageBox.critical(self, self.tr("Export failed"), str(exc))

    def export_figure(self) -> None:
        filters = (
            "SVG Vector (*.svg);;"
            "PNG Image (*.png);;"
            "PDF Document (*.pdf);;"
            "TIFF Image (*.tif *.tiff);;"
            "JPEG Image (*.jpg *.jpeg)"
        )
        path, selected_filter = QFileDialog.getSaveFileName(
            self,
            self.tr("Export Figure"),
            "",
            filters,
            "SVG Vector (*.svg)",
        )
        if path:
            suffix = export_suffix_for_filter(selected_filter)
            if suffix and not Path(path).suffix:
                path = f"{path}{suffix}"
            self.flush_pending_render()
            self.canvas.export(path, self.settings)

    def copy_figure(self) -> None:
        self.copy_figure_image()

    def copy_figure_image(self) -> None:
        self.flush_pending_render()
        if self.canvas.copy_to_clipboard(self.settings):
            self.statusBar().showMessage(self.tr("Figure image copied to clipboard"), 2500)
        else:
            QMessageBox.warning(self, self.tr("Copy failed"), self.tr("Could not copy the figure to the clipboard."))


def export_suffix_for_filter(selected_filter: str) -> str:
    if "*.svg" in selected_filter:
        return ".svg"
    if "*.png" in selected_filter:
        return ".png"
    if "*.pdf" in selected_filter:
        return ".pdf"
    if "*.tif" in selected_filter or "*.tiff" in selected_filter:
        return ".tif"
    if "*.jpg" in selected_filter or "*.jpeg" in selected_filter:
        return ".jpg"
    return ""
