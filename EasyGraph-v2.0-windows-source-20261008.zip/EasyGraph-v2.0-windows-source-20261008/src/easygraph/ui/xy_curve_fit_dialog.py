from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, replace
from functools import partial
import math
from typing import Callable, Iterable, Mapping, Sequence

from PySide6.QtCore import QLocale, QThreadPool, QTimer, Qt, Signal
from PySide6.QtGui import QDoubleValidator
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHeaderView,
    QLineEdit,
    QListWidgetItem,
    QTableWidgetItem,
    QWidget,
)

from easygraph.xy_fit_worker import XYFitBatchWorker, XYFitJob
from easygraph.ui.xy_fit_parameter_display_dialog import (
    XYFitParameterDisplayDialog,
    XYFitParameterDisplaySeries,
)
from easygraph.xy_fitting import (
    FIT_MODEL_REGISTRY,
    FitModel,
    FitParameterSpec,
    XYFitResult,
    XYFitSpec,
    default_fit_spec,
    initial_fit_parameters,
    parse_custom_expression,
)
from ui_xy_curve_fit_dialog import Ui_XYCurveFitDialog


_CENTERED_POLYNOMIAL_MODEL_IDS = frozenset(
    {"linear", "polynomial2", "polynomial3", "polynomial4", "polynomial5"}
)

_CUSTOM_FUNCTION_TEMPLATES = (
    ("exp", "exp(u)", "exp(expression)"),
    ("ln", "ln(u)", "ln(expression)"),
    ("log", "log(u, base)", "log(expression, 2)"),
    ("log10", "log10(u)", "log10(expression)"),
    ("sqrt", "sqrt(u)", "sqrt(expression)"),
    ("abs", "abs(u)", "abs(expression)"),
    ("sin", "sin(u)", "sin(expression)"),
    ("cos", "cos(u)", "cos(expression)"),
    ("tan", "tan(u)", "tan(expression)"),
    ("asin", "asin(u)", "asin(expression)"),
    ("acos", "acos(u)", "acos(expression)"),
    ("atan", "atan(u)", "atan(expression)"),
    ("atan2", "atan2(u, v)", "atan2(expression, x)"),
    ("sec", "sec(u)", "sec(expression)"),
    ("csc", "csc(u)", "csc(expression)"),
    ("cot", "cot(u)", "cot(expression)"),
    ("sinh", "sinh(u)", "sinh(expression)"),
    ("cosh", "cosh(u)", "cosh(expression)"),
    ("tanh", "tanh(u)", "tanh(expression)"),
)


def _valid_log_base_initial(parameter: FitParameterSpec) -> float | None:
    """Suggest a valid base only when the current parameter cannot be used."""

    lower = -math.inf if parameter.lower is None else float(parameter.lower)
    upper = math.inf if parameter.upper is None else float(parameter.upper)
    current = float(parameter.initial)
    if (
        math.isfinite(current)
        and current > 0.0
        and current != 1.0
        and lower <= current <= upper
    ):
        return None
    for candidate in (2.0, 0.5):
        if lower <= candidate <= upper:
            return candidate
    above_lower = max(lower, math.nextafter(1.0, math.inf))
    if above_lower <= upper:
        if math.isinf(upper):
            return above_lower
        return above_lower / 2.0 + upper / 2.0
    below_lower = max(lower, math.nextafter(0.0, math.inf))
    below_upper = min(upper, math.nextafter(1.0, 0.0))
    if below_lower <= below_upper:
        return below_lower / 2.0 + below_upper / 2.0
    return None


@dataclass(frozen=True)
class XYFitSeriesInput:
    """The small, renderer-independent series payload consumed by the dialog."""

    id: str
    name: str
    x: tuple[float, ...]
    y: tuple[float, ...]


@dataclass(frozen=True)
class XYFitPreviewRequest:
    """Payload emitted when the user asks to preview starting curves."""

    series: Mapping[str, XYFitSeriesInput]
    specs: Mapping[str, XYFitSpec]


@dataclass(frozen=True)
class XYCurveFitDialogResult:
    specs: tuple[XYFitSpec, ...]
    results: Mapping[str, XYFitResult]
    removed_fit_ids: frozenset[str]
    removed_series_ids: frozenset[str]
    annotation_mode: str


def _object_value(value: object, name: str, default: object = None) -> object:
    if isinstance(value, Mapping):
        return value.get(name, default)
    return getattr(value, name, default)


def _series_input(value: object, number: int) -> XYFitSeriesInput:
    series_id = str(_object_value(value, "id", f"series-{number}"))
    name = str(_object_value(value, "name", series_id))
    raw_x = _object_value(value, "x", ())
    raw_y = _object_value(value, "y", ())
    return XYFitSeriesInput(
        id=series_id,
        name=name,
        x=tuple(raw_x if raw_x is not None else ()),
        y=tuple(raw_y if raw_y is not None else ()),
    )


def _fit_succeeded(result: object) -> bool:
    return bool(getattr(result, "success", True))


def _finite_text(value: object, *, significant_digits: int = 6) -> str:
    if value is None:
        return "—"
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return str(value)
    if not math.isfinite(numeric):
        return "—"
    return f"{numeric:.{significant_digits}g}"


def _parameter_text(value: object) -> str:
    """Format a coefficient without losing enough digits to change its curve."""

    return _finite_text(value, significant_digits=17)


class XYCurveFitDialog(QDialog):
    """User-facing editor for one independent fit per selected XY series.

    No caller-owned object is mutated. Call :meth:`specs` and :meth:`results`
    only after ``exec()`` returns ``QDialog.Accepted`` and commit those copies.
    """

    previewRequested = Signal(object)
    previewCleared = Signal()
    fitBatchStarted = Signal(int)
    fitBatchFinished = Signal(int, object)
    fitResultsReady = Signal(object)

    def __init__(
        self,
        parent: QWidget | None,
        series_inputs: Iterable[object],
        existing_specs: Iterable[XYFitSpec] | Mapping[str, XYFitSpec] = (),
        existing_results: Mapping[str, XYFitResult] | None = None,
        selected_series_ids: Iterable[str] = (),
        *,
        annotation_mode: str = "equation",
        preview_callback: Callable[[XYFitPreviewRequest], str | None] | None = None,
        results_callback: Callable[[Mapping[str, XYFitResult]], None] | None = None,
        thread_pool: QThreadPool | None = None,
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_XYCurveFitDialog()
        self.ui.setupUi(self)

        normalized = [
            _series_input(series, index + 1)
            for index, series in enumerate(series_inputs)
        ]
        self._series_order = [series.id for series in normalized]
        self._series_by_id = {series.id: series for series in normalized}
        supplied_specs = (
            list(existing_specs.values())
            if isinstance(existing_specs, Mapping)
            else list(existing_specs)
        )
        self._specs_by_series = {
            str(spec.series_id): deepcopy(spec)
            for spec in supplied_specs
            if str(spec.series_id) in self._series_by_id
        }
        self._show_annotation_by_series = {
            series_id: bool(
                getattr(self._specs_by_series.get(series_id), "show_equation", False)
            )
            for series_id in self._series_order
        }
        self._annotation_parameters_by_series = {
            series_id: tuple(
                getattr(
                    self._specs_by_series.get(series_id),
                    "annotation_parameter_names",
                    (),
                )
            )
            for series_id in self._series_order
        }
        self._annotation_mode = (
            str(annotation_mode)
            if str(annotation_mode) in {"equation", "parameters"}
            else "equation"
        )
        self._results_by_fit = dict(existing_results or {})
        self._removed_fit_ids: set[str] = set()
        self._removed_series_ids: set[str] = set()
        self._last_attempt_results: dict[str, XYFitResult] = {}
        self._last_attempt_errors: dict[str, str] = {}
        self._last_attempt_specs: dict[str, XYFitSpec] = {}
        self._preview_callback = preview_callback
        self._results_callback = results_callback
        self._thread_pool = thread_pool or QThreadPool.globalInstance()
        self._workers: dict[int, XYFitBatchWorker] = {}
        self._fit_generation = 0
        self._pending_specs: dict[int, dict[str, XYFitSpec]] = {}
        self._busy = False
        self._building_parameters = False
        self._parameters_edited = False
        self._current_model_id = ""
        self._model_drafts: dict[
            str,
            tuple[str, list[FitParameterSpec], bool],
        ] = {}
        self._series_editor_drafts: dict[
            str,
            tuple[
                str,
                dict[str, tuple[str, list[FitParameterSpec], bool]],
            ],
        ] = {}
        self._active_single_series_id: str | None = None
        self._result_rows: dict[int, tuple[str, XYFitSpec, object | None, str | None]] = {}

        self._equation_timer = QTimer(self)
        self._equation_timer.setSingleShot(True)
        self._equation_timer.setInterval(250)
        self._equation_timer.timeout.connect(self.regenerate_custom_parameters)

        self._configure_tables()
        self._populate_series(set(str(value) for value in selected_series_ids))
        self._populate_models()
        self._populate_custom_functions()
        self._connect_controls()
        self.ui.progressBar.hide()
        self.ui.setupSplitter.setSizes([250, 730])
        self.ui.mainSplitter.setSizes([360, 250])
        self.ui.mainSplitter.setStretchFactor(0, 3)
        self.ui.mainSplitter.setStretchFactor(1, 2)
        self._select_initial_model()
        selected = self.selected_series_ids()
        self._active_single_series_id = selected[0] if len(selected) == 1 else None
        self._sync_annotation_controls()
        self._render_results()
        self._update_series_summary()

    def _configure_tables(self) -> None:
        parameter_header = self.ui.parameterTable.horizontalHeader()
        parameter_header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        for column in (1, 2, 3):
            parameter_header.setSectionResizeMode(column, QHeaderView.Stretch)
        parameter_header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        results_header = self.ui.resultsTable.horizontalHeader()
        results_header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        results_header.setSectionResizeMode(1, QHeaderView.Stretch)
        results_header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        results_header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        results_header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        results_header.setSectionResizeMode(5, QHeaderView.Stretch)
        self.ui.resultsTable.currentCellChanged.connect(
            self._result_selection_changed
        )
        self.ui.resultsTable.itemChanged.connect(
            self._result_display_changed
        )

    def _populate_series(self, requested: set[str]) -> None:
        requested &= set(self._series_order)
        if not requested and self._series_order:
            requested = {self._series_order[0]}
        for series_id in self._series_order:
            series = self._series_by_id[series_id]
            item = QListWidgetItem(series.name)
            item.setData(Qt.UserRole, series.id)
            item.setFlags(
                item.flags()
                | Qt.ItemIsUserCheckable
                | Qt.ItemIsSelectable
                | Qt.ItemIsEnabled
            )
            item.setCheckState(
                Qt.Checked if series.id in requested else Qt.Unchecked
            )
            count = min(len(series.x), len(series.y))
            item.setToolTip(
                self.tr("{count} valid X/Y pairs").format(count=count)
            )
            self.ui.seriesList.addItem(item)

    def _populate_models(self) -> None:
        translated_names = {
            "linear": self.tr("Linear"),
            "polynomial2": self.tr("Quadratic polynomial"),
            "polynomial3": self.tr("Cubic polynomial"),
            "polynomial4": self.tr("Quartic polynomial"),
            "polynomial5": self.tr("Quintic polynomial"),
            "exponential": self.tr("Exponential"),
            "logarithmic": self.tr("Logarithmic"),
            "power": self.tr("Power"),
            "gaussian": self.tr("Gaussian peak"),
            "custom": self.tr("Custom equation"),
        }
        preferred_order = (
            "linear",
            "polynomial2",
            "polynomial3",
            "polynomial4",
            "polynomial5",
            "exponential",
            "logarithmic",
            "power",
            "gaussian",
            "custom",
        )
        combo = self.ui.modelCombo
        combo.clear()
        combo.setCurrentIndex(-1)
        ordered_models = [
            FIT_MODEL_REGISTRY[model_id]
            for model_id in preferred_order
            if model_id in FIT_MODEL_REGISTRY
        ]
        preferred_ids = set(preferred_order)
        ordered_models.extend(
            model
            for model in FIT_MODEL_REGISTRY.values()
            if model.id not in preferred_ids
        )
        for model in ordered_models:
            combo.addItem(
                translated_names.get(model.id, model.display_name),
                model.id,
            )
        combo.setCurrentIndex(-1)

    def _populate_custom_functions(self) -> None:
        descriptions = {
            "exp": self.tr("Exponential, e raised to u."),
            "ln": self.tr("Natural logarithm; u must be positive."),
            "log": self.tr(
                "Logarithm with a custom base; u must be positive, and base must be positive and not equal to 1. The inserted template starts with base 2; replace 2 with another valid value or a parameter."
            ),
            "log10": self.tr("Base-10 logarithm; u must be positive."),
            "sqrt": self.tr("Square root; u must not be negative."),
            "abs": self.tr("Absolute value."),
            "sin": self.tr("Sine; input is in radians."),
            "cos": self.tr("Cosine; input is in radians."),
            "tan": self.tr(
                "Tangent; input is in radians and the function is undefined where cos(u) is zero."
            ),
            "asin": self.tr(
                "Inverse sine; input must be between -1 and 1, and the result is in radians."
            ),
            "acos": self.tr(
                "Inverse cosine; input must be between -1 and 1, and the result is in radians."
            ),
            "atan": self.tr("Inverse tangent; result is in radians."),
            "atan2": self.tr(
                "Four-quadrant inverse tangent atan2(u, v): u is the vertical value and v is the horizontal value; the result is in radians."
            ),
            "sec": self.tr(
                "Secant, 1 / cos(u); input is in radians and the function is undefined where cos(u) is zero."
            ),
            "csc": self.tr(
                "Cosecant, 1 / sin(u); input is in radians and the function is undefined where sin(u) is zero."
            ),
            "cot": self.tr(
                "Cotangent, cos(u) / sin(u); input is in radians and the function is undefined where sin(u) is zero."
            ),
            "sinh": self.tr("Hyperbolic sine."),
            "cosh": self.tr("Hyperbolic cosine."),
            "tanh": self.tr("Hyperbolic tangent."),
        }
        combo = self.ui.functionCombo
        combo.clear()
        for name, signature, _template in _CUSTOM_FUNCTION_TEMPLATES:
            combo.addItem(signature, name)
            combo.setItemData(
                combo.count() - 1,
                descriptions[name],
                Qt.ToolTipRole,
            )
        combo.setCurrentIndex(0)

    def _connect_controls(self) -> None:
        self.ui.selectAllButton.clicked.connect(lambda: self._set_all_series_checked(True))
        self.ui.clearSelectionButton.clicked.connect(
            lambda: self._set_all_series_checked(False)
        )
        self.ui.seriesList.itemChanged.connect(self._series_selection_changed)
        self.ui.modelCombo.currentIndexChanged.connect(self._model_changed)
        self.ui.customEquationEdit.textChanged.connect(self._custom_equation_changed)
        self.ui.insertSigmaButton.clicked.connect(self.insert_sigma_template)
        self.ui.insertIntegralButton.clicked.connect(self.insert_integral_template)
        self.ui.insertFunctionButton.clicked.connect(self.insert_function_template)
        self.ui.parameterTable.itemChanged.connect(self._parameter_item_changed)
        self.ui.equationAnnotationRadioButton.toggled.connect(
            self._annotation_mode_changed
        )
        self.ui.parameterAnnotationRadioButton.toggled.connect(
            self._annotation_mode_changed
        )
        self.ui.parameterAnnotationSettingsButton.clicked.connect(
            self.edit_parameter_annotations
        )
        self.ui.previewButton.clicked.connect(self.preview_starting_curves)
        self.ui.fitButton.clicked.connect(self.run_fit)
        self.ui.removeFitButton.clicked.connect(self.remove_selected_fits)
        apply_button = self.ui.buttonBox.button(QDialogButtonBox.Apply)
        apply_button.clicked.connect(self._apply)
        self.rejected.connect(self._cancel_preview)

    def _select_initial_model(self) -> None:
        selected = self.selected_series_ids()
        initial_id = "linear"
        for series_id in selected or self._series_order:
            spec = self._specs_by_series.get(series_id)
            if spec is not None:
                initial_id = spec.model_id
                break
        if initial_id not in FIT_MODEL_REGISTRY:
            initial_id = "linear"
        selected_index = -1
        for index in range(self.ui.modelCombo.count()):
            if self.ui.modelCombo.itemData(index) == initial_id:
                selected_index = index
                break
        if selected_index < 0:
            selected_index = next(
                (
                    index
                    for index in range(self.ui.modelCombo.count())
                    if self.ui.modelCombo.itemData(index) in FIT_MODEL_REGISTRY
                ),
                -1,
            )
        self.ui.modelCombo.setCurrentIndex(selected_index)
        self._model_changed(self.ui.modelCombo.currentIndex())

    def selected_series_ids(self) -> tuple[str, ...]:
        return tuple(
            str(item.data(Qt.UserRole))
            for row in range(self.ui.seriesList.count())
            if (item := self.ui.seriesList.item(row)).checkState() == Qt.Checked
        )

    def _set_all_series_checked(self, checked: bool) -> None:
        state = Qt.Checked if checked else Qt.Unchecked
        for row in range(self.ui.seriesList.count()):
            self.ui.seriesList.item(row).setCheckState(state)

    def _series_selection_changed(self, *_args) -> None:
        selected = self.selected_series_ids()
        single_series_id = selected[0] if len(selected) == 1 else None
        if single_series_id != self._active_single_series_id:
            if self._active_single_series_id is not None:
                self._save_series_editor_draft(self._active_single_series_id)
            self._active_single_series_id = single_series_id
            if single_series_id is not None:
                self._load_series_editor(single_series_id)
        self._update_series_summary()

    def annotation_mode(self) -> str:
        return self._annotation_mode

    def _sync_annotation_controls(self) -> None:
        equation_blocked = self.ui.equationAnnotationRadioButton.blockSignals(True)
        parameters_blocked = self.ui.parameterAnnotationRadioButton.blockSignals(
            True
        )
        try:
            self.ui.equationAnnotationRadioButton.setChecked(
                self._annotation_mode == "equation"
            )
            self.ui.parameterAnnotationRadioButton.setChecked(
                self._annotation_mode == "parameters"
            )
        finally:
            self.ui.equationAnnotationRadioButton.blockSignals(
                equation_blocked
            )
            self.ui.parameterAnnotationRadioButton.blockSignals(
                parameters_blocked
            )
        has_parameter_options = any(
            self._parameter_options_for_series(series_id)
            for series_id in self._specs_by_series
        )
        self.ui.parameterAnnotationSettingsButton.setEnabled(
            self._annotation_mode == "parameters"
            and has_parameter_options
            and not self._busy
        )

    def _annotation_mode_changed(self, checked: bool) -> None:
        if not checked:
            return
        self._annotation_mode = (
            "parameters"
            if self.ui.parameterAnnotationRadioButton.isChecked()
            else "equation"
        )
        self._sync_annotation_controls()
        self._request_annotation_preview()

    def _request_annotation_preview(self) -> None:
        self.fitResultsReady.emit(dict(self._results_by_fit))

    def _parameter_options_for_series(
        self,
        series_id: str,
    ) -> tuple[tuple[str, float | None], ...]:
        spec = self._specs_by_series.get(series_id)
        if spec is None:
            return ()
        result = self._results_by_fit.get(spec.id)
        parameters = getattr(result, "parameters", {}) if result is not None else {}
        if isinstance(parameters, Mapping) and parameters:
            return tuple(
                (str(name), float(value))
                for name, value in parameters.items()
            )
        if spec.parameters:
            return tuple(
                (parameter.name, float(parameter.initial))
                for parameter in spec.parameters
            )
        model = FIT_MODEL_REGISTRY.get(spec.model_id)
        return (
            tuple((name, None) for name in model.parameter_names)
            if model is not None
            else ()
        )

    def edit_parameter_annotations(self) -> None:
        entries = [
            XYFitParameterDisplaySeries(
                series_id=series_id,
                series_name=self._series_by_id[series_id].name,
                parameters=self._parameter_options_for_series(series_id),
                selected_parameter_names=self._annotation_parameters_by_series.get(
                    series_id,
                    (),
                ),
            )
            for series_id in self._series_order
            if self._parameter_options_for_series(series_id)
        ]
        if not entries:
            self.ui.statusLabel.setText(
                self.tr("Fit at least one series before choosing displayed parameters.")
            )
            return
        dialog = XYFitParameterDisplayDialog(self, entries)
        if dialog.exec() != QDialog.Accepted:
            return
        for series_id, names in dialog.selections().items():
            self._annotation_parameters_by_series[series_id] = tuple(names)
            existing = self._specs_by_series.get(series_id)
            if existing is not None:
                self._specs_by_series[series_id] = replace(
                    existing,
                    annotation_parameter_names=list(names),
                )
        self.ui.statusLabel.setText(
            self.tr("Updated the parameter values shown on the chart.")
        )
        self._request_annotation_preview()

    def _save_series_editor_draft(self, series_id: str) -> None:
        model_id = str(self.ui.modelCombo.currentData() or "")
        if model_id not in FIT_MODEL_REGISTRY:
            return
        drafts = deepcopy(self._model_drafts)
        drafts[model_id] = (
            self.ui.customEquationEdit.text().strip()
            if model_id == "custom"
            else "",
            self._parameter_specs_from_table(validate=False),
            self._parameters_edited,
        )
        self._series_editor_drafts[series_id] = (model_id, drafts)

    def _load_series_editor(self, series_id: str) -> None:
        self._equation_timer.stop()
        saved = self._series_editor_drafts.get(series_id)
        if saved is not None:
            model_id, drafts = deepcopy(saved)
            self._model_drafts = drafts
        else:
            existing = self._specs_by_series.get(series_id)
            model_id = existing.model_id if existing is not None else "linear"
            self._model_drafts = {}
        if model_id not in FIT_MODEL_REGISTRY:
            model_id = "linear"
        self._current_model_id = ""
        for index in range(self.ui.modelCombo.count()):
            if self.ui.modelCombo.itemData(index) != model_id:
                continue
            changed = self.ui.modelCombo.currentIndex() != index
            self.ui.modelCombo.setCurrentIndex(index)
            if not changed:
                self._model_changed(index)
            break

    def _update_series_summary(self, *_args) -> None:
        selected = self.selected_series_ids()
        points = sum(
            min(len(self._series_by_id[series_id].x), len(self._series_by_id[series_id].y))
            for series_id in selected
        )
        if selected:
            self.ui.seriesSummaryLabel.setText(
                self.tr("{series_count} selected · {point_count} total points").format(
                    series_count=len(selected),
                    point_count=points,
                )
            )
        else:
            self.ui.seriesSummaryLabel.setText(self.tr("No series selected"))
        self.ui.fitButton.setEnabled(bool(selected) and not self._busy)
        self.ui.previewButton.setEnabled(bool(selected) and not self._busy)
        self.ui.removeFitButton.setEnabled(bool(selected) and not self._busy)
        self._sync_annotation_controls()

    def _model(self, model_id: str | None = None) -> FitModel:
        resolved = model_id or str(self.ui.modelCombo.currentData())
        return FIT_MODEL_REGISTRY[resolved]

    def _model_display_name(self, model_id: str) -> str:
        for index in range(self.ui.modelCombo.count()):
            if self.ui.modelCombo.itemData(index) == model_id:
                return self.ui.modelCombo.itemText(index)
        return self._model(model_id).display_name

    def _model_form(self, model_id: str) -> str:
        centered_forms = {
            "linear": "y = slope * x + intercept",
            "polynomial2": "y = a * x^2 + b * x + c",
            "polynomial3": "y = a * x^3 + b * x^2 + c * x + d",
            "polynomial4": "y = a * x^4 + b * x^3 + c * x^2 + d * x + e",
            "polynomial5": (
                "y = a * x^5 + b * x^4 + c * x^3 + d * x^2 + e * x + f"
            ),
        }
        return centered_forms.get(model_id, self._model(model_id).equation)

    def _model_description(self, model_id: str) -> str:
        descriptions = {
            "linear": self.tr("Use for data that follows a straight-line trend."),
            "polynomial2": self.tr(
                "Use for a smooth curve with one bend or turning point."
            ),
            "polynomial3": self.tr(
                "Use for a smooth curve that may have up to two turning points."
            ),
            "polynomial4": self.tr(
                "Use for a flexible smooth trend with up to three turning points. Prefer a simpler polynomial when it fits well."
            ),
            "polynomial5": self.tr(
                "Use for a highly flexible smooth trend with up to four turning points. Prefer a simpler polynomial when it fits well."
            ),
            "exponential": self.tr(
                "Use for growth or decay whose rate changes with the current value."
            ),
            "logarithmic": self.tr(
                "Use for a rapid early change that gradually levels off. X must be positive."
            ),
            "power": self.tr(
                "Use for scale relationships such as y changing by a power of x. X must be positive."
            ),
            "gaussian": self.tr("Use for a single symmetric peak with a baseline."),
            "custom": self.tr(
                "Enter your own equation, including finite sums and numerical integrals. EasyGraph safely identifies parameter names for you."
            ),
        }
        return descriptions.get(
            model_id,
            self.tr(
                "Choose this model when its equation matches the expected curve shape."
            ),
        )

    def _model_changed(self, _index: int) -> None:
        model_id = str(self.ui.modelCombo.currentData() or "")
        if not model_id or model_id not in FIT_MODEL_REGISTRY:
            if self._current_model_id in FIT_MODEL_REGISTRY:
                for index in range(self.ui.modelCombo.count()):
                    if self.ui.modelCombo.itemData(index) != self._current_model_id:
                        continue
                    was_blocked = self.ui.modelCombo.blockSignals(True)
                    try:
                        self.ui.modelCombo.setCurrentIndex(index)
                    finally:
                        self.ui.modelCombo.blockSignals(was_blocked)
                    break
            return
        previous_model_id = self._current_model_id
        if previous_model_id and previous_model_id != model_id:
            self._model_drafts[previous_model_id] = (
                self.ui.customEquationEdit.text().strip()
                if previous_model_id == "custom"
                else "",
                self._parameter_specs_from_table(validate=False),
                self._parameters_edited,
            )
        self._current_model_id = model_id
        model = self._model(model_id)
        is_custom = model_id == "custom"
        self.ui.customEquationWidget.setVisible(is_custom)
        self.ui.equationDisplayLabel.setText(self._model_form(model_id))
        self.ui.modelDescriptionLabel.setText(self._model_description(model_id))
        existing = self._common_existing_spec(model_id)
        draft = self._model_drafts.get(model_id)
        if is_custom:
            expression = (
                draft[0]
                if draft is not None
                else existing.expression
                if existing is not None
                else ""
            )
            seed_parameters = (
                deepcopy(draft[1])
                if draft is not None
                else deepcopy(existing.parameters)
                if existing is not None
                else []
            )
            self._set_parameter_rows(seed_parameters)
            was_blocked = self.ui.customEquationEdit.blockSignals(True)
            try:
                self.ui.customEquationEdit.setText(expression)
            finally:
                self.ui.customEquationEdit.blockSignals(was_blocked)
            self.regenerate_custom_parameters()
            self._parameters_edited = (
                draft[2] if draft is not None else bool(seed_parameters)
            )
            return
        parameters = (
            deepcopy(draft[1])
            if draft is not None
            else self._suggested_parameters(model_id, existing)
        )
        self._parameters_edited = (
            draft[2]
            if draft is not None
            else bool(existing and existing.parameters)
        )
        self._set_parameter_rows(parameters)
        self.ui.parameterHintLabel.setText(
            self.tr(
                "These starting values were estimated from the first selected series. "
                "Leave them unchanged to estimate each series independently."
            )
        )

    def _common_existing_spec(self, model_id: str) -> XYFitSpec | None:
        for series_id in self.selected_series_ids() or tuple(self._series_order):
            spec = self._specs_by_series.get(series_id)
            if spec is not None and spec.model_id == model_id:
                return spec
        return None

    def _suggested_parameters(
        self,
        model_id: str,
        existing: XYFitSpec | None,
    ) -> Sequence[FitParameterSpec]:
        if existing is not None and existing.parameters:
            return deepcopy(existing.parameters)
        selected = self.selected_series_ids() or tuple(self._series_order)
        if selected:
            series = self._series_by_id[selected[0]]
            spec = default_fit_spec(series.id, model_id)
            try:
                return initial_fit_parameters(series.x, series.y, spec)
            except ValueError:
                pass
        return deepcopy(self._model(model_id).default_parameters)

    def _number_editor(self, value: float | None, *, bound: bool = False) -> QLineEdit:
        editor = QLineEdit(self.ui.parameterTable)
        validator = QDoubleValidator(-1e300, 1e300, 17, editor)
        validator.setNotation(QDoubleValidator.ScientificNotation)
        validator.setLocale(QLocale.c())
        editor.setValidator(validator)
        if value is not None:
            editor.setText(f"{float(value):.17g}")
        elif bound:
            editor.setPlaceholderText(self.tr("No limit"))
        editor.textEdited.connect(self._parameter_edited)
        return editor

    def _set_parameter_rows(self, parameters: Sequence[FitParameterSpec]) -> None:
        self._building_parameters = True
        try:
            table = self.ui.parameterTable
            table.setRowCount(0)
            for parameter in parameters:
                row = table.rowCount()
                table.insertRow(row)
                name_item = QTableWidgetItem(parameter.name)
                name_item.setData(Qt.UserRole, parameter.name)
                name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                table.setItem(row, 0, name_item)
                table.setCellWidget(row, 1, self._number_editor(parameter.initial))
                table.setCellWidget(row, 2, self._number_editor(parameter.lower, bound=True))
                table.setCellWidget(row, 3, self._number_editor(parameter.upper, bound=True))
                fixed_item = QTableWidgetItem()
                fixed_item.setFlags(
                    Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsUserCheckable
                )
                fixed_item.setCheckState(Qt.Checked if parameter.fixed else Qt.Unchecked)
                table.setItem(row, 4, fixed_item)
        finally:
            self._building_parameters = False
    def _parameter_edited(self, *_args) -> None:
        if not self._building_parameters:
            self._parameters_edited = True

    def _parameter_item_changed(self, *_args) -> None:
        self._parameter_edited()

    def _custom_equation_changed(self, text: str) -> None:
        if self._current_model_id != "custom":
            return
        self.ui.equationDisplayLabel.setText(
            self.tr("y = {expression}").format(expression=text.strip() or "—")
        )
        self._equation_timer.start()

    def _insert_custom_template(
        self,
        template: str,
        *,
        select_after_wrapping: str | None = None,
    ) -> None:
        editor = self.ui.customEquationEdit
        placeholder = "expression"
        selected_text = editor.selectedText()
        selection_start = editor.selectionStart()
        if selection_start < 0:
            selection_start = editor.cursorPosition()
        selection_end = selection_start + len(selected_text)
        inserted_expression = selected_text or placeholder
        replacement = template.replace(placeholder, inserted_expression, 1)
        original = editor.text()
        editor.setText(
            original[:selection_start] + replacement + original[selection_end:]
        )
        if selected_text and select_after_wrapping:
            selected_start = selection_start + replacement.rindex(
                select_after_wrapping
            )
            editor.setSelection(selected_start, len(select_after_wrapping))
        else:
            expression_start = selection_start + template.index(placeholder)
            editor.setSelection(expression_start, len(inserted_expression))
        editor.setFocus()

    def insert_sigma_template(self, _checked: bool = False) -> None:
        self._insert_custom_template("Σ(k, 1, 5, expression)")

    def insert_integral_template(self, _checked: bool = False) -> None:
        self._insert_custom_template("∫(t, 0, x, expression)")

    def insert_function_template(self, _checked: bool = False) -> None:
        selected_name = str(self.ui.functionCombo.currentData() or "")
        template = next(
            (
                template
                for name, _signature, template in _CUSTOM_FUNCTION_TEMPLATES
                if name == selected_name
            ),
            "",
        )
        if template:
            self._insert_custom_template(
                template,
                select_after_wrapping="2" if selected_name == "log" else None,
            )

    def regenerate_custom_parameters(self) -> bool:
        if self._current_model_id != "custom":
            return True
        expression = self.ui.customEquationEdit.text().strip()
        old = {parameter.name: parameter for parameter in self._parameter_specs_from_table(False)}
        if not expression:
            self._set_parameter_rows(())
            self.ui.parameterHintLabel.setText(
                self.tr("Enter an equation to identify its parameters automatically.")
            )
            return False
        try:
            parsed = parse_custom_expression(expression)
        except ValueError as error:
            self._set_parameter_rows(())
            self.ui.parameterHintLabel.setText(
                self.tr("The equation needs attention: {message}").format(message=error)
            )
            return False
        log_base_names = frozenset(parsed.log_base_parameter_names)
        parameters: list[FitParameterSpec] = []
        for name in parsed.parameter_names:
            parameter = deepcopy(
                old.get(
                    name,
                    FitParameterSpec(
                        name=name,
                        initial=2.0 if name in log_base_names else 1.0,
                    ),
                )
            )
            if name in log_base_names:
                valid_initial = _valid_log_base_initial(parameter)
                if valid_initial is not None:
                    parameter.initial = valid_initial
            parameters.append(parameter)
        self._set_parameter_rows(parameters)
        self._parameters_edited = True
        if parameters:
            self.ui.parameterHintLabel.setText(
                self.tr("Detected parameters: {names}").format(
                    names=", ".join(parameter.name for parameter in parameters)
                )
            )
        else:
            self.ui.parameterHintLabel.setText(
                self.tr("This equation has no adjustable parameters.")
            )
        return True

    def _editor_number(
        self,
        editor: QLineEdit,
        label: str,
        *,
        optional: bool,
    ) -> float | None:
        text = editor.text().strip()
        if optional and not text:
            return None
        try:
            value = float(text)
        except ValueError as error:
            raise ValueError(
                self.tr("Enter a valid number for {label}.").format(label=label)
            ) from error
        if not math.isfinite(value):
            raise ValueError(
                self.tr("{label} must be a finite number.").format(label=label)
            )
        return value

    def _parameter_specs_from_table(
        self,
        validate: bool = True,
    ) -> list[FitParameterSpec]:
        parameters = []
        table = self.ui.parameterTable
        for row in range(table.rowCount()):
            name_item = table.item(row, 0)
            stored_name = name_item.data(Qt.UserRole)
            name = str(stored_name if stored_name is not None else name_item.text())
            try:
                initial = self._editor_number(
                    table.cellWidget(row, 1),
                    self.tr("starting value for {name}").format(name=name),
                    optional=False,
                )
                lower = self._editor_number(
                    table.cellWidget(row, 2),
                    self.tr("lower bound for {name}").format(name=name),
                    optional=True,
                )
                upper = self._editor_number(
                    table.cellWidget(row, 3),
                    self.tr("upper bound for {name}").format(name=name),
                    optional=True,
                )
            except ValueError:
                if validate:
                    raise
                continue
            fixed = table.item(row, 4).checkState() == Qt.Checked
            if validate and lower is not None and upper is not None and lower > upper:
                raise ValueError(
                    self.tr("The lower bound for {name} cannot exceed its upper bound.").format(name=name)
                )
            if validate and lower is not None and initial < lower:
                raise ValueError(
                    self.tr("The starting value for {name} is below its lower bound.").format(name=name)
                )
            if validate and upper is not None and initial > upper:
                raise ValueError(
                    self.tr("The starting value for {name} is above its upper bound.").format(name=name)
                )
            parameters.append(FitParameterSpec(name, initial, lower, upper, fixed))
        return parameters

    def _specs_for_selection(self) -> dict[str, XYFitSpec]:
        selected = self.selected_series_ids()
        if not selected:
            raise ValueError(self.tr("Select at least one data series to continue."))
        model_id = str(self.ui.modelCombo.currentData())
        expression = ""
        if model_id == "custom":
            if not self.regenerate_custom_parameters():
                raise ValueError(
                    self.tr("Correct the custom equation before previewing or fitting.")
                )
            expression = self.ui.customEquationEdit.text().strip()
        table_parameters = self._parameter_specs_from_table()
        use_table_parameters = model_id == "custom" or self._parameters_edited
        specs: dict[str, XYFitSpec] = {}
        for series_id in selected:
            existing = self._specs_by_series.get(series_id)
            base = deepcopy(existing) if existing is not None else default_fit_spec(series_id, model_id)
            spec = replace(
                base,
                series_id=series_id,
                model_id=model_id,
                expression=expression,
                parameters=deepcopy(table_parameters) if use_table_parameters else [],
                enabled=True,
                show_equation=self._show_annotation_by_series.get(
                    series_id,
                    False,
                ),
                annotation_parameter_names=list(
                    self._annotation_parameters_by_series.get(series_id, ())
                ),
                x_origin=None,
            )
            specs[spec.id] = spec
        return specs

    def _show_problem(self, message: str) -> None:
        self.ui.statusLabel.setText(
            self.tr("Cannot continue: {message}").format(message=message)
        )

    def preview_starting_curves(self) -> None:
        try:
            specs = self._specs_for_selection()
        except ValueError as error:
            self._show_problem(str(error))
            return
        request = XYFitPreviewRequest(
            series={
                spec.series_id: self._series_by_id[spec.series_id]
                for spec in specs.values()
            },
            specs=deepcopy(specs),
        )
        self.previewRequested.emit(request)
        preview_problem = None
        if self._preview_callback is not None:
            preview_problem = self._preview_callback(request)
        if preview_problem:
            self.ui.statusLabel.setText(
                self.tr("Preview unavailable: {message}").format(
                    message=preview_problem
                )
            )
            return
        self.ui.statusLabel.setText(
            self.tr("Starting-curve preview requested for {count} series.").format(
                count=len(specs)
            )
        )

    def run_fit(self) -> None:
        if self._busy:
            return
        try:
            specs = self._specs_for_selection()
        except ValueError as error:
            self._show_problem(str(error))
            return
        jobs = [
            XYFitJob(
                spec=deepcopy(spec),
                x=self._series_by_id[spec.series_id].x,
                y=self._series_by_id[spec.series_id].y,
            )
            for spec in specs.values()
        ]
        self._fit_generation += 1
        generation = self._fit_generation
        worker = XYFitBatchWorker(jobs)
        worker.signals.finished.connect(partial(self._fit_finished, generation))
        worker.signals.failed.connect(partial(self._fit_failed, generation))
        self._workers[generation] = worker
        self._pending_specs[generation] = specs
        self._last_attempt_specs = {
            spec.series_id: deepcopy(spec) for spec in specs.values()
        }
        self._set_busy(True)
        self.ui.statusLabel.setText(
            self.tr("Fitting {count} series in the background…").format(count=len(jobs))
        )
        self.fitBatchStarted.emit(generation)
        self._thread_pool.start(worker)

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        self.ui.progressBar.setVisible(busy)
        self.ui.modelGroup.setEnabled(not busy)
        self.ui.equationAnnotationRadioButton.setEnabled(not busy)
        self.ui.parameterAnnotationRadioButton.setEnabled(not busy)
        self.ui.resultsTable.setEnabled(not busy)
        self.ui.selectAllButton.setEnabled(not busy)
        self.ui.clearSelectionButton.setEnabled(not busy)
        self.ui.seriesList.setEnabled(not busy)
        self.ui.buttonBox.button(QDialogButtonBox.Apply).setEnabled(not busy)
        self._update_series_summary()

    def _fit_finished(
        self,
        generation: int,
        results: Mapping[str, XYFitResult],
    ) -> None:
        specs = self._pending_specs.pop(generation, {})
        self._workers.pop(generation, None)
        if generation != self._fit_generation:
            return
        self._last_attempt_results = dict(results)
        self._last_attempt_errors = {}
        successes = 0
        for fit_id, result in results.items():
            spec = specs.get(fit_id)
            if spec is None:
                continue
            if _fit_succeeded(result):
                successes += 1
                available_parameters = set(getattr(result, "parameters", {}))
                requested_parameters = list(
                    getattr(spec, "annotation_parameter_names", ())
                )
                valid_parameters = [
                    name
                    for name in requested_parameters
                    if name in available_parameters
                ]
                saved_spec = replace(
                    deepcopy(spec),
                    annotation_parameter_names=valid_parameters,
                    x_origin=None,
                )
                self._specs_by_series[spec.series_id] = saved_spec
                self._annotation_parameters_by_series[spec.series_id] = tuple(
                    valid_parameters
                )
                self._last_attempt_specs[spec.series_id] = deepcopy(saved_spec)
                self._results_by_fit[fit_id] = result
                self._removed_fit_ids.discard(fit_id)
                self._removed_series_ids.discard(spec.series_id)
        failed = len(results) - successes
        self._set_busy(False)
        self._render_results()
        if failed:
            self.ui.statusLabel.setText(
                self.tr(
                    "{successes} fit(s) succeeded; {failed} failed. "
                    "Review the status below, then adjust starting values or bounds."
                ).format(successes=successes, failed=failed)
            )
        else:
            self.ui.statusLabel.setText(
                self.tr("Fit complete for {count} series. Review the results, then apply.").format(count=successes)
            )
        copied = dict(results)
        self.fitBatchFinished.emit(generation, copied)
        self.fitResultsReady.emit(copied)
        if self._results_callback is not None:
            self._results_callback(copied)

    def _fit_failed(self, generation: int, message: str) -> None:
        specs = self._pending_specs.pop(generation, {})
        self._workers.pop(generation, None)
        if generation != self._fit_generation:
            return
        self._last_attempt_results = {}
        self._last_attempt_errors = {fit_id: message for fit_id in specs}
        self._set_busy(False)
        self._render_results()
        self.ui.statusLabel.setText(
            self.tr(
                "The fit could not run: {message} Check the data, equation, starting values, and bounds."
            ).format(message=message or self.tr("Unknown fitting error."))
        )
        self.fitBatchFinished.emit(generation, {})

    def remove_selected_fits(self) -> None:
        removed = 0
        for series_id in self.selected_series_ids():
            spec = self._specs_by_series.pop(series_id, None)
            if spec is None:
                continue
            removed += 1
            self._results_by_fit.pop(spec.id, None)
            self._removed_fit_ids.add(spec.id)
            self._removed_series_ids.add(series_id)
        self._last_attempt_results = {}
        self._last_attempt_errors = {}
        self._last_attempt_specs = {}
        self._render_results()
        if removed:
            self.ui.statusLabel.setText(
                self.tr("Marked {count} fit(s) for removal. Choose Apply to confirm.").format(count=removed)
            )
            self.previewCleared.emit()
        else:
            self.ui.statusLabel.setText(
                self.tr("The selected series do not have saved fits to remove.")
            )

    def _render_results(self) -> None:
        table = self.ui.resultsTable
        previous_series_id = None
        if table.currentRow() in self._result_rows:
            previous_series_id = self._result_rows[table.currentRow()][0]
        was_blocked = table.blockSignals(True)
        try:
            table.setRowCount(0)
            self._result_rows = {}
            for series_id in self._series_order:
                spec = self._specs_by_series.get(series_id)
                attempted_spec = self._last_attempt_specs.get(series_id)
                display_spec = attempted_spec or spec
                if display_spec is None:
                    continue
                result = self._last_attempt_results.get(display_spec.id)
                if result is None:
                    result = self._results_by_fit.get(display_spec.id)
                error = self._last_attempt_errors.get(display_spec.id)
                row = table.rowCount()
                table.insertRow(row)
                display_item = QTableWidgetItem()
                display_item.setData(Qt.UserRole, series_id)
                display_item.setTextAlignment(Qt.AlignCenter)
                if spec is not None:
                    display_item.setFlags(
                        Qt.ItemIsEnabled
                        | Qt.ItemIsSelectable
                        | Qt.ItemIsUserCheckable
                    )
                    display_item.setCheckState(
                        Qt.Checked
                        if self._show_annotation_by_series.get(series_id, False)
                        else Qt.Unchecked
                    )
                    display_item.setToolTip(
                        self.tr(
                            "Show or hide this fit's chart annotation. This does not run the fit again."
                        )
                    )
                else:
                    display_item.setFlags(Qt.ItemIsSelectable)
                    display_item.setCheckState(Qt.Unchecked)
                    display_item.setToolTip(
                        self.tr("Run a successful fit before displaying its annotation.")
                    )
                table.setItem(row, 0, display_item)
                series_item = QTableWidgetItem(self._series_by_id[series_id].name)
                series_item.setData(Qt.UserRole, series_id)
                table.setItem(row, 1, series_item)
                if error:
                    status_text = self.tr("Failed")
                    status_detail = error
                elif result is None:
                    status_text = self.tr("Saved")
                    status_detail = self.tr("No result is available in this session.")
                elif _fit_succeeded(result):
                    status_text = self.tr("Fitted")
                    status_detail = str(getattr(result, "message", ""))
                else:
                    status_text = self.tr("Needs attention")
                    status_detail = str(getattr(result, "message", ""))
                status_item = QTableWidgetItem(status_text)
                warnings = (
                    tuple(getattr(result, "warnings", ()))
                    if result is not None
                    else ()
                )
                tooltip_parts = [part for part in (status_detail, *warnings) if part]
                status_item.setToolTip("\n".join(tooltip_parts))
                table.setItem(row, 2, status_item)
                table.setItem(
                    row,
                    3,
                    QTableWidgetItem(
                        _finite_text(getattr(result, "r_squared", None))
                    ),
                )
                table.setItem(
                    row,
                    4,
                    QTableWidgetItem(_finite_text(getattr(result, "rmse", None))),
                )
                parameters = (
                    getattr(result, "parameters", {}) if result is not None else {}
                )
                parameter_text = ", ".join(
                    f"{name} = {_parameter_text(value)}"
                    for name, value in parameters.items()
                )
                table.setItem(row, 5, QTableWidgetItem(parameter_text or "—"))
                self._result_rows[row] = (
                    series_id,
                    display_spec,
                    result,
                    error,
                )
        finally:
            table.blockSignals(was_blocked)

        selected_row = 0 if table.rowCount() else -1
        if previous_series_id is not None:
            for row, entry in self._result_rows.items():
                if entry[0] == previous_series_id:
                    selected_row = row
                    break
        if selected_row >= 0:
            table.setCurrentCell(selected_row, 0)
        else:
            table.clearSelection()
        self._render_selected_fit_details(selected_row)

    def _result_display_changed(self, item: QTableWidgetItem) -> None:
        if item.column() != 0:
            return
        entry = self._result_rows.get(item.row())
        if entry is None:
            return
        series_id = entry[0]
        existing = self._specs_by_series.get(series_id)
        if existing is None:
            return
        visible = item.checkState() == Qt.Checked
        self._show_annotation_by_series[series_id] = visible
        self._specs_by_series[series_id] = replace(
            existing,
            show_equation=visible,
        )
        self._request_annotation_preview()

    def _result_selection_changed(
        self,
        current_row: int,
        _current_column: int,
        _previous_row: int,
        _previous_column: int,
    ) -> None:
        self._render_selected_fit_details(current_row)

    def _render_selected_fit_details(self, row: int | None = None) -> None:
        if row is None:
            row = self.ui.resultsTable.currentRow()
        entry = self._result_rows.get(row)
        if entry is None:
            self.ui.fitDetailsText.clear()
            return
        series_id, spec, result, error = entry
        series_name = self._series_by_id[series_id].name
        model_name = self._model_display_name(spec.model_id)
        lines = [
            self.tr("Series: {series} · Model: {model}").format(
                series=series_name,
                model=model_name,
            )
        ]
        if error:
            lines.append(self.tr("Fit failed: {message}").format(message=error))
            self.ui.fitDetailsText.setPlainText("\n".join(lines))
            return
        if result is None:
            lines.append(
                self.tr(
                    "No numerical result is available in this session. Run the fit to review full statistics."
                )
            )
            self.ui.fitDetailsText.setPlainText("\n".join(lines))
            return

        equation = (
            self._model_form(spec.model_id)
            if spec.model_id in _CENTERED_POLYNOMIAL_MODEL_IDS
            else str(getattr(result, "equation", "") or "").strip()
        )
        if equation:
            lines.append(self.tr("Equation: {equation}").format(equation=equation))
        lines.append(
            self.tr(
                "Fit quality: R² = {r_squared} · Adjusted R² = {adjusted_r_squared} · "
                "RMSE = {rmse} · SSE = {sse}"
            ).format(
                r_squared=_finite_text(getattr(result, "r_squared", None)),
                adjusted_r_squared=_finite_text(
                    getattr(result, "adjusted_r_squared", None)
                ),
                rmse=_finite_text(getattr(result, "rmse", None)),
                sse=_finite_text(getattr(result, "sse", None)),
            )
        )
        lines.append(
            self.tr(
                "Data used: {observations} points · {parameters} fitted parameter(s) · "
                "{degrees_of_freedom} degrees of freedom"
            ).format(
                observations=getattr(result, "observation_count", 0),
                parameters=getattr(result, "free_parameter_count", 0),
                degrees_of_freedom=getattr(result, "degrees_of_freedom", 0),
            )
        )

        estimates = tuple(getattr(result, "parameter_estimates", ()))
        if estimates:
            lines.append(self.tr("Parameter uncertainty:"))
            for estimate in estimates:
                confidence_interval = getattr(estimate, "confidence_interval", None)
                if confidence_interval is None:
                    interval_text = self.tr("not available")
                else:
                    interval_text = "[{lower}, {upper}]".format(
                        lower=_parameter_text(confidence_interval[0]),
                        upper=_parameter_text(confidence_interval[1]),
                    )
                notes = []
                if getattr(estimate, "fixed", False):
                    notes.append(self.tr("fixed"))
                if getattr(estimate, "at_bound", False):
                    notes.append(self.tr("at a bound"))
                notes_text = f" ({', '.join(notes)})" if notes else ""
                lines.append(
                    self.tr(
                        "  {name} = {value} · standard error = {standard_error} · "
                        "95% CI = {confidence_interval}{notes}"
                    ).format(
                        name=str(getattr(estimate, "name", "")),
                        value=_parameter_text(getattr(estimate, "value", None)),
                        standard_error=_parameter_text(
                            getattr(estimate, "standard_error", None)
                        ),
                        confidence_interval=interval_text,
                        notes=notes_text,
                    )
                )

        warnings = tuple(getattr(result, "warnings", ()))
        if warnings:
            lines.append(self.tr("Warnings:"))
            lines.extend(f"  • {warning}" for warning in warnings)
        else:
            lines.append(self.tr("Warnings: none."))
        message = str(getattr(result, "message", "") or "").strip()
        if message:
            lines.append(self.tr("Fit status: {message}").format(message=message))
        self.ui.fitDetailsText.setPlainText("\n".join(lines))

    def _apply(self) -> None:
        if self._busy:
            self._show_problem(self.tr("Wait for the current fit to finish."))
            return
        self.accept()

    def _cancel_preview(self) -> None:
        self._fit_generation += 1
        for worker in tuple(self._workers.values()):
            worker.cancel()
        self._workers.clear()
        self._pending_specs.clear()
        self._set_busy(False)
        self.previewCleared.emit()

    def specs(self) -> list[XYFitSpec]:
        return [
            deepcopy(self._specs_by_series[series_id])
            for series_id in self._series_order
            if series_id in self._specs_by_series
        ]

    def results(self) -> dict[str, XYFitResult]:
        return dict(self._results_by_fit)

    def removed_fit_ids(self) -> set[str]:
        return set(self._removed_fit_ids)

    def removed_series_ids(self) -> set[str]:
        return set(self._removed_series_ids)

    def result(self) -> XYCurveFitDialogResult:
        return XYCurveFitDialogResult(
            specs=tuple(self.specs()),
            results=self.results(),
            removed_fit_ids=frozenset(self._removed_fit_ids),
            removed_series_ids=frozenset(self._removed_series_ids),
            annotation_mode=self._annotation_mode,
        )


XYCurveFitDialogController = XYCurveFitDialog


def create_xy_curve_fit_dialog(
    parent: QWidget | None,
    series_inputs: Iterable[object],
    existing_specs: Iterable[XYFitSpec] | Mapping[str, XYFitSpec] = (),
    existing_results: Mapping[str, XYFitResult] | None = None,
    selected_series_ids: Iterable[str] = (),
    **kwargs,
) -> XYCurveFitDialog:
    return XYCurveFitDialog(
        parent,
        series_inputs,
        existing_specs,
        existing_results,
        selected_series_ids,
        **kwargs,
    )


__all__ = [
    "XYCurveFitDialog",
    "XYCurveFitDialogController",
    "XYCurveFitDialogResult",
    "XYFitPreviewRequest",
    "XYFitSeriesInput",
    "create_xy_curve_fit_dialog",
]
