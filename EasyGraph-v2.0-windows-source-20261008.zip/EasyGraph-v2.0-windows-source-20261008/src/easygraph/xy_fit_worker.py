from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from threading import Event

from PySide6.QtCore import QObject, QRunnable, Signal, Slot

from easygraph.xy_fitting import XYFitResult, XYFitSpec, fit_xy_values


@dataclass(frozen=True)
class XYFitJob:
    spec: XYFitSpec
    x: tuple[float, ...]
    y: tuple[float, ...]


def fit_xy_batch(
    jobs: tuple[XYFitJob, ...] | list[XYFitJob],
    *,
    curve_points: int = 400,
    cancel_event: Event | None = None,
) -> dict[str, XYFitResult]:
    """Fit independent series sequentially inside one background task."""

    results: dict[str, XYFitResult] = {}
    for job in jobs:
        if cancel_event is not None and cancel_event.is_set():
            break
        spec = deepcopy(job.spec)
        result = fit_xy_values(
            job.x,
            job.y,
            spec,
            curve_points=curve_points,
            cancel_check=(cancel_event.is_set if cancel_event is not None else None),
        )
        if result.status == "cancelled":
            break
        results[spec.id] = result
    return results


class XYFitBatchSignals(QObject):
    finished = Signal(object)
    failed = Signal(str)


class XYFitBatchWorker(QRunnable):
    def __init__(
        self,
        jobs: tuple[XYFitJob, ...] | list[XYFitJob],
        *,
        curve_points: int = 400,
    ) -> None:
        super().__init__()
        self.jobs = tuple(jobs)
        self.curve_points = int(curve_points)
        self.signals = XYFitBatchSignals()
        self._cancel_event = Event()

    def cancel(self) -> None:
        """Request cooperative cancellation of a queued or running fit batch."""

        self._cancel_event.set()

    @Slot()
    def run(self) -> None:
        if self._cancel_event.is_set():
            return
        try:
            results = fit_xy_batch(
                self.jobs,
                curve_points=self.curve_points,
                cancel_event=self._cancel_event,
            )
        except Exception as error:  # pragma: no cover - defensive thread boundary
            if self._cancel_event.is_set():
                return
            self.signals.failed.emit(str(error))
            return
        if self._cancel_event.is_set():
            return
        self.signals.finished.emit(results)


__all__ = [
    "XYFitBatchSignals",
    "XYFitBatchWorker",
    "XYFitJob",
    "fit_xy_batch",
]
