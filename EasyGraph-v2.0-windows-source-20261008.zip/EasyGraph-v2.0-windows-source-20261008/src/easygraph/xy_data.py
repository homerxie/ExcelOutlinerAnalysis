from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass

import pandas as pd

from easygraph.numeric import has_percentage_values
from easygraph.xy_series import (
    XYSeriesSpec,
    XYSettings,
    pairwise_numeric_values,
    resolved_series_display,
    resolved_x_column_id,
)


@dataclass(frozen=True)
class PreparedXYSeries:
    spec: XYSeriesSpec
    x: pd.Series
    y: pd.Series
    row_indexes: tuple[object, ...]
    skipped_row_indexes: tuple[object, ...]
    show_points: bool
    show_line: bool
    x_is_percentage: bool = False
    y_is_percentage: bool = False

    @property
    def id(self) -> str:
        return self.spec.id

    @property
    def name(self) -> str:
        return self.spec.name

    @property
    def visible(self) -> bool:
        return self.spec.visible

    @property
    def valid_count(self) -> int:
        return len(self.row_indexes)

    @property
    def skipped_count(self) -> int:
        return len(self.skipped_row_indexes)


@dataclass(frozen=True)
class XYDataIssue:
    series_id: str
    message: str


@dataclass(frozen=True)
class PreparedXYData:
    series: tuple[PreparedXYSeries, ...]
    issues: tuple[XYDataIssue, ...]

    @property
    def visible_series(self) -> tuple[PreparedXYSeries, ...]:
        return tuple(series for series in self.series if series.visible)

    @property
    def visible_numeric_series(self) -> tuple[PreparedXYSeries, ...]:
        return tuple(
            series
            for series in self.series
            if series.visible and series.valid_count > 0
        )


def prepare_xy_data(
    dataframe: pd.DataFrame,
    column_ids: list[str] | tuple[str, ...],
    settings: XYSettings,
    *,
    order_mode: str = "Table order",
) -> PreparedXYData:
    if len(column_ids) != len(dataframe.columns):
        raise ValueError("Column IDs must match the DataFrame column count.")
    if len(set(column_ids)) != len(column_ids):
        raise ValueError("Column IDs must be unique.")

    positions = {column_id: index for index, column_id in enumerate(column_ids)}
    prepared_series = []
    issues = []
    source_series = list(settings.series)
    if order_mode == "Name A-Z":
        source_series.sort(key=lambda series: (series.name.casefold(), series.id))
    elif order_mode == "Name Z-A":
        source_series.sort(
            key=lambda series: (series.name.casefold(), series.id),
            reverse=True,
        )
    for series in source_series:
        x_column_id = resolved_x_column_id(settings, series)
        if x_column_id is None:
            issues.append(XYDataIssue(series.id, "Series has no X column."))
            continue
        if x_column_id not in positions:
            issues.append(
                XYDataIssue(series.id, f"Series references missing X column: {x_column_id}")
            )
            continue
        if series.y_column_id not in positions:
            issues.append(
                XYDataIssue(
                    series.id,
                    f"Series references missing Y column: {series.y_column_id}",
                )
            )
            continue

        raw_x = dataframe.iloc[:, positions[x_column_id]].reset_index(drop=True)
        raw_y = dataframe.iloc[:, positions[series.y_column_id]].reset_index(drop=True)
        # Pair by position so duplicate source row labels cannot make a skipped
        # percentage cell affect the axis format of another, valid pair.
        paired = pairwise_numeric_values(raw_x, raw_y)
        valid_positions = list(paired.row_indexes)
        show_points, show_line = resolved_series_display(settings, series)
        prepared = PreparedXYSeries(
            spec=deepcopy(series),
            x=paired.x,
            y=paired.y,
            row_indexes=tuple(dataframe.index[index] for index in paired.row_indexes),
            skipped_row_indexes=tuple(
                dataframe.index[index] for index in paired.skipped_row_indexes
            ),
            show_points=show_points,
            show_line=show_line,
            x_is_percentage=has_percentage_values(raw_x.iloc[valid_positions]),
            y_is_percentage=has_percentage_values(raw_y.iloc[valid_positions]),
        )
        prepared_series.append(prepared)
        if prepared.valid_count == 0:
            issues.append(XYDataIssue(series.id, "No valid X/Y pairs."))

    return PreparedXYData(tuple(prepared_series), tuple(issues))


__all__ = [
    "PreparedXYData",
    "PreparedXYSeries",
    "XYDataIssue",
    "prepare_xy_data",
]
