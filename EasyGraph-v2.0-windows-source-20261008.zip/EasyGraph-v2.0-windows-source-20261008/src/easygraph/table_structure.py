from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from easygraph.data_table import DataTable
from easygraph.table_model import EasyGraphTableModel


@dataclass(frozen=True)
class TableSelection:
    """A compact, UI-independent description of a table selection."""

    positions: frozenset[tuple[int, int]]
    rows: tuple[int, ...]
    columns: tuple[int, ...]

    @classmethod
    def from_positions(
        cls,
        positions: Iterable[tuple[int, int]],
    ) -> TableSelection:
        normalized = frozenset(
            (int(row), int(column))
            for row, column in positions
            if int(row) >= 0 and int(column) >= 0
        )
        return cls(
            positions=normalized,
            rows=tuple(sorted({row for row, _column in normalized})),
            columns=tuple(sorted({column for _row, column in normalized})),
        )

    @property
    def is_empty(self) -> bool:
        return not self.positions

    @property
    def top(self) -> int:
        return self.rows[0] if self.rows else -1

    @property
    def bottom(self) -> int:
        return self.rows[-1] if self.rows else -1

    @property
    def left(self) -> int:
        return self.columns[0] if self.columns else -1

    @property
    def right(self) -> int:
        return self.columns[-1] if self.columns else -1

    @property
    def row_span(self) -> int:
        return self.bottom - self.top + 1 if self.rows else 0

    @property
    def column_span(self) -> int:
        return self.right - self.left + 1 if self.columns else 0

    @property
    def is_rectangular(self) -> bool:
        if self.is_empty:
            return False
        expected_rows = tuple(range(self.top, self.bottom + 1))
        expected_columns = tuple(range(self.left, self.right + 1))
        return (
            self.rows == expected_rows
            and self.columns == expected_columns
            and len(self.positions) == len(self.rows) * len(self.columns)
        )


def table_selection(table: DataTable) -> TableSelection:
    selection_model = table.selectionModel()
    indexes = selection_model.selectedIndexes() if selection_model is not None else ()
    return TableSelection.from_positions(
        (index.row(), index.column()) for index in indexes
    )


def expanded_pair_columns(
    columns: Iterable[int],
    column_count: int,
) -> tuple[int, ...]:
    """Expand every selected XY column to its complete adjacent X/Y pair."""

    column_count = max(0, int(column_count))
    expanded: set[int] = set()
    for column in columns:
        column = int(column)
        if not 0 <= column < column_count:
            continue
        pair_start = (column // 2) * 2
        expanded.update(
            candidate
            for candidate in (pair_start, pair_start + 1)
            if candidate < column_count
        )
    return tuple(sorted(expanded))


def _valid_columns(
    model: EasyGraphTableModel,
    columns: Iterable[int],
) -> tuple[int, ...]:
    column_count = model.columnCount()
    return tuple(sorted({
        int(column)
        for column in columns
        if 0 <= int(column) < column_count
    }))


def shift_cells_down(
    model: EasyGraphTableModel,
    top: int,
    columns: Iterable[int],
    count: int,
) -> bool:
    """Insert blank cells and shift values down without discarding used data."""

    top = int(top)
    count = int(count)
    columns = _valid_columns(model, columns)
    if count <= 0 or not columns or not 0 <= top <= model.rowCount():
        return False

    old_cells = model.cells_copy()
    old_row_count = len(old_cells)
    last_used = max(
        (
            row
            for row in range(top, old_row_count)
            if any(old_cells[row][column].strip() for column in columns)
        ),
        default=top - 1,
    )
    needed_rows = max(old_row_count, top + count, last_used + count + 1)
    if needed_rows > old_row_count:
        model.insertRows(old_row_count, needed_rows - old_row_count)

    changed = needed_rows != old_row_count
    for column in columns:
        for destination in range(needed_rows - 1, top + count - 1, -1):
            source = destination - count
            value = (
                old_cells[source][column]
                if 0 <= source < old_row_count
                else ""
            )
            changed = model.set_cell_text(destination, column, value) or changed
        for row in range(top, min(top + count, needed_rows)):
            changed = model.set_cell_text(row, column, "") or changed
    return changed


def shift_cells_up(
    model: EasyGraphTableModel,
    top: int,
    columns: Iterable[int],
    count: int,
) -> bool:
    """Delete cells by shifting later values up and blanking the tail."""

    top = int(top)
    count = int(count)
    columns = _valid_columns(model, columns)
    row_count = model.rowCount()
    if count <= 0 or not columns or not 0 <= top < row_count:
        return False

    old_cells = model.cells_copy()
    changed = False
    for column in columns:
        for destination in range(top, row_count):
            source = destination + count
            value = old_cells[source][column] if source < row_count else ""
            changed = model.set_cell_text(destination, column, value) or changed
    return changed


def insert_table_rows(
    model: EasyGraphTableModel,
    row: int,
    count: int,
) -> bool:
    row = int(row)
    count = int(count)
    if count <= 0 or not 0 <= row <= model.rowCount():
        return False
    return model.insertRows(row, count)


def delete_table_rows(
    model: EasyGraphTableModel,
    row: int,
    count: int,
) -> bool:
    row = int(row)
    count = min(int(count), model.rowCount() - row)
    if count <= 0 or not 0 <= row < model.rowCount():
        return False
    return model.removeRows(row, count)


def ensure_trailing_blank_row(
    model: EasyGraphTableModel,
    sample_start_row: int,
    minimum_sample_rows: int = 1,
) -> bool:
    """Append one editable row when the current final sample row is in use."""

    sample_start_row = max(0, int(sample_start_row))
    minimum_sample_rows = max(1, int(minimum_sample_rows))
    row_count = model.rowCount()
    minimum_row_count = sample_start_row + minimum_sample_rows
    changed = False
    if row_count < minimum_row_count:
        changed = model.insertRows(
            row_count,
            minimum_row_count - row_count,
        )
        row_count = model.rowCount()
    final_row = row_count - 1
    if not any(
        model.cell_text(final_row, column).strip()
        for column in range(model.columnCount())
    ):
        return changed
    return model.insertRows(row_count, 1) or changed


__all__ = [
    "TableSelection",
    "delete_table_rows",
    "ensure_trailing_blank_row",
    "expanded_pair_columns",
    "insert_table_rows",
    "shift_cells_down",
    "shift_cells_up",
    "table_selection",
]
