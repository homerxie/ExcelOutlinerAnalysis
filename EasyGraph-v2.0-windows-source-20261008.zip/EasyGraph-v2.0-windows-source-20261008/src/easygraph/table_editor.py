"""Pure decisions used by inline table-editor keyboard navigation."""

from __future__ import annotations


# Qt::Key values are stable integer protocol values. Keeping these constants
# here avoids importing Qt Widgets (or the application facade) into this
# deterministic table-editing module.
_NAVIGATION_DELTAS = {
    16777234: (0, -1),  # Qt.Key_Left
    16777236: (0, 1),   # Qt.Key_Right
    16777235: (-1, 0),  # Qt.Key_Up
    16777237: (1, 0),   # Qt.Key_Down
    16777220: (1, 0),   # Qt.Key_Return
    16777221: (1, 0),   # Qt.Key_Enter
}


def navigation_delta(key: int) -> tuple[int, int] | None:
    """Return the row/column delta for a supported navigation key."""

    return _NAVIGATION_DELTAS.get(int(key))


def next_table_cell(
    row: int,
    column: int,
    row_count: int,
    column_count: int,
    delta: tuple[int, int],
) -> tuple[int, int] | None:
    """Return a moved-to cell, or ``None`` when it falls outside the table."""

    next_row = row + delta[0]
    next_column = column + delta[1]
    if not (0 <= row < row_count and 0 <= column < column_count):
        return None
    if not (0 <= next_row < row_count and 0 <= next_column < column_count):
        return None
    return next_row, next_column
