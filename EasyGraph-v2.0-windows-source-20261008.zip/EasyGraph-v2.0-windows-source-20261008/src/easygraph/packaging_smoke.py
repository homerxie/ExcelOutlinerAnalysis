from __future__ import annotations

from importlib import metadata
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from PySide6.QtCore import QTranslator
from PySide6.QtWidgets import QApplication

from easygraph.app_preferences import translation_directory
from easygraph.settings import ChartSettings
from easygraph.xy_fitting import default_fit_spec, fit_xy_values
from easygraph.xy_series import XYSeriesSpec, XYSettings


REQUIRED_LAZY_MODULES = (
    "easygraph.plotting.canvas",
    "seaborn",
    "scipy.stats",
    "scipy.ndimage",
    "scipy.optimize",
    "matplotlib.backends.backend_svg",
    "matplotlib.backends.backend_pdf",
)


def _installed_version(distribution: str) -> str:
    try:
        return metadata.version(distribution)
    except metadata.PackageNotFoundError:
        return "not-installed"


def _module_loaded(module: str) -> bool:
    return any(name == module or name.startswith(f"{module}.") for name in sys.modules)


def run_packaging_smoke(output_dir: str | Path, app: QApplication | None = None) -> dict:
    """Exercise frozen lazy imports, chart renderers, and export backends."""

    from easygraph.ui.main_window import MainWindow

    app = app or QApplication.instance() or QApplication([])
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(701)
    small_frame = pd.DataFrame(
        rng.normal(size=(24, 3)),
        columns=["Control", "Low dose", "High dose"],
    )
    large_frame = pd.DataFrame(
        rng.normal(size=(2050, 2)),
        columns=["Control", "Treatment"],
    )
    cases = (
        ("box", small_frame, ChartSettings(chart_type="Box", show_stat_table=False)),
        ("violin", small_frame, ChartSettings(chart_type="Violin", show_stat_table=False)),
        ("ridge", small_frame, ChartSettings(chart_type="Ridge", show_stat_table=False)),
        (
            "quasirandom-large",
            large_frame,
            ChartSettings(
                chart_type="Box",
                jitter_mode="Quasirandom",
                show_points=True,
                show_stat_table=False,
            ),
        ),
    )

    window = MainWindow(initial_render=False, defer_preview=True)
    artifacts = []
    case_results = []
    try:
        window.show()
        app.processEvents()
        placeholder_visible = window._plot_placeholder is not None and window.canvas is None
        window.initialize_preview(initial_render=False)
        app.processEvents()
        ui_state = {
            "window_visible": window.isVisible(),
            "placeholder_before_canvas": placeholder_visible,
            "canvas_ready": window.canvas is not None,
            "table_rows": window.table.table_model.rowCount(),
            "table_columns": window.table.table_model.columnCount(),
            "menu_actions": len(window.menuBar().actions()),
        }
        for name, frame, settings in cases:
            window.canvas.render(frame, settings)
            app.processEvents()
            png_path = output_path / f"{name}.png"
            window.canvas.export(str(png_path), settings)
            artifacts.append(png_path)
            case_results.append({
                "name": name,
                "axes": len(window.canvas.figure.axes),
                "png": png_path.name,
                "png_bytes": png_path.stat().st_size,
            })

        xy_frame = pd.DataFrame(
            {
                "Shared X": [3, 1, 2, 4],
                "Shared Y": [
                    0.5 + 2.0 * np.exp(-0.4 * value)
                    for value in (3, 1, 2, 4)
                ],
                "Independent X": [100, 300, 200, np.nan],
                "Independent Y": [1, 3, 2, np.nan],
            }
        )
        xy_chart = ChartSettings(
            chart_type="Scatter",
            title="Mixed XY",
            x_label="X",
            y_label="Y",
            show_stat_table=False,
        )
        xy_fit_spec = default_fit_spec("shared-series", "exponential")
        xy_settings = XYSettings(
            default_x_column_id="shared-x",
            series=[
                XYSeriesSpec(
                    id="shared-series",
                    name="Shared",
                    y_column_id="shared-y",
                ),
                XYSeriesSpec(
                    id="independent-series",
                    name="Independent",
                    x_column_id="independent-x",
                    y_column_id="independent-y",
                ),
            ],
            fit_specs=[xy_fit_spec],
        )
        xy_fit_result = fit_xy_values(
            xy_frame["Shared X"],
            xy_frame["Shared Y"],
            xy_fit_spec,
        )
        if not xy_fit_result.success:
            raise RuntimeError(f"packaging XY fit failed: {xy_fit_result.message}")
        window.canvas.render(
            xy_frame,
            xy_chart,
            xy_settings=xy_settings,
            column_ids=[
                "shared-x",
                "shared-y",
                "independent-x",
                "independent-y",
            ],
            xy_fit_results={xy_fit_spec.id: xy_fit_result},
        )
        app.processEvents()
        xy_path = output_path / "xy-mixed.png"
        window.canvas.export(str(xy_path), xy_chart)
        artifacts.append(xy_path)
        case_results.append({
            "name": "xy-mixed",
            "axes": len(window.canvas.figure.axes),
            "png": xy_path.name,
            "png_bytes": xy_path.stat().st_size,
        })

        export_settings = cases[0][2]
        for suffix in (".svg", ".pdf"):
            export_path = output_path / f"vector-export{suffix}"
            window.canvas.export(str(export_path), export_settings)
            artifacts.append(export_path)
    finally:
        window.close()
        window.deleteLater()
        app.processEvents()

    missing_modules = [module for module in REQUIRED_LAZY_MODULES if not _module_loaded(module)]
    missing_artifacts = [path.name for path in artifacts if not path.is_file() or path.stat().st_size == 0]
    translation_file = translation_directory() / "easygraph_zh_CN.qm"
    translation_available = translation_file.is_file()
    translation_loadable = QTranslator(app).load(str(translation_file))
    report = {
        "status": (
            "ok"
            if (
                not missing_modules
                and not missing_artifacts
                and translation_available
                and translation_loadable
            )
            else "failed"
        ),
        "frozen": bool(getattr(sys, "frozen", False)),
        "python": sys.version.split()[0],
        "versions": {
            "matplotlib": _installed_version("matplotlib"),
            "numpy": _installed_version("numpy"),
            "pandas": _installed_version("pandas"),
            "PySide6": _installed_version("PySide6"),
            "scipy": _installed_version("scipy"),
            "seaborn": _installed_version("seaborn"),
        },
        "cases": case_results,
        "ui": ui_state,
        "artifacts": [path.name for path in artifacts],
        "missing_modules": missing_modules,
        "missing_artifacts": missing_artifacts,
        "translation": {
            "zh_CN_available": translation_available,
            "zh_CN_loadable": translation_loadable,
            "directory": str(translation_file.parent),
        },
    }
    (output_path / "packaging-smoke.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if not all((
        ui_state["window_visible"],
        ui_state["placeholder_before_canvas"],
        ui_state["canvas_ready"],
        ui_state["table_rows"] > 0,
        ui_state["table_columns"] > 0,
        ui_state["menu_actions"] > 0,
    )):
        report["status"] = "failed"
        (output_path / "packaging-smoke.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    if report["status"] != "ok":
        raise RuntimeError(f"packaging smoke failed: {report}")
    return report
