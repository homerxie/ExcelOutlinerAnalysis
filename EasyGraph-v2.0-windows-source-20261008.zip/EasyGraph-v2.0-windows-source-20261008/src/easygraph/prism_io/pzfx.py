"""Safe, structure-driven reader for GraphPad Prism PZFX 5.00 files."""

from __future__ import annotations

import math
import re
import xml.etree.ElementTree as ET
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from .mapping import groups_to_dataframe
from .models import (
    PrismImportError,
    PrismImportResult,
    PrismProjectSummary,
    PrismRawGroup,
    PrismRawTable,
    PrismTableKind,
    PrismTableSummary,
    PrismWarning,
)


PZFX_XML_VERSION = "5.00"
SUPPORTED_PRISM_MAJORS = frozenset({8, 9, 10, 11})
MAX_PZFX_BYTES = 64 * 1024 * 1024
MAX_TABLES = 256
MAX_Y_COLUMNS = 4096
MAX_SUBCOLUMNS = 4096
MAX_DATA_NODES = 2_000_000


@dataclass(frozen=True)
class _ParsedDocument:
    path: Path
    root: ET.Element
    xml_version: str
    created_by_version: str
    major_version: int | None
    tables: tuple[tuple[str, ET.Element, PrismTableSummary], ...]
    warnings: tuple[PrismWarning, ...]


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def _direct_children(element: ET.Element, name: str) -> list[ET.Element]:
    return [child for child in element if _local_name(child.tag) == name]


def _first_direct_child(element: ET.Element, name: str) -> ET.Element | None:
    return next((child for child in element if _local_name(child.tag) == name), None)


def _descendants(element: ET.Element, name: str) -> list[ET.Element]:
    return [node for node in element.iter() if _local_name(node.tag) == name]


def _element_text(element: ET.Element | None) -> str:
    if element is None:
        return ""

    parts: list[str] = []

    def append_node(node: ET.Element) -> None:
        if node.text:
            parts.append(node.text)
        for child in node:
            if _local_name(child.tag).casefold() == "br":
                parts.append("\n")
            append_node(child)
            if child.tail:
                parts.append(child.tail)

    append_node(element)
    return "".join(parts).strip()


def _major_version(version: str) -> int | None:
    match = re.match(r"\s*(\d+)", version)
    return int(match.group(1)) if match else None


def _read_xml(path: Path) -> ET.Element:
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise PrismImportError("file_read_failed", f"Unable to read Prism file: {exc}") from exc
    if size > MAX_PZFX_BYTES:
        raise PrismImportError(
            "file_too_large",
            f"PZFX file is larger than the {MAX_PZFX_BYTES // (1024 * 1024)} MB safety limit.",
        )
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise PrismImportError("file_read_failed", f"Unable to read Prism file: {exc}") from exc

    if data.startswith((b"\xff\xfe", b"\xfe\xff", b"\x00\x00\xfe\xff", b"\xff\xfe\x00\x00")) or b"\x00" in data[:256]:
        raise PrismImportError(
            "unsupported_encoding",
            "PZFX import currently requires UTF-8 XML encoding.",
        )
    upper_data = data.upper()
    if b"<!DOCTYPE" in upper_data or b"<!ENTITY" in upper_data:
        raise PrismImportError(
            "unsafe_xml_declaration",
            "PZFX files containing DOCTYPE or ENTITY declarations are not supported.",
        )
    try:
        return ET.fromstring(data)
    except ET.ParseError as exc:
        raise PrismImportError("malformed_xml", f"Invalid PZFX XML: {exc}") from exc


def _created_by_version(root: ET.Element) -> str:
    # Prism can preserve an empty OriginalVersion after an older document is
    # opened and saved by a newer release. MostRecentVersion describes the
    # application that produced the current PZFX structure and is therefore
    # authoritative for compatibility checks. OriginalVersion is retained only
    # as a fallback for files that do not contain a usable recent-version node.
    for element_name in ("MostRecentVersion", "OriginalVersion"):
        for node in root.iter():
            if _local_name(node.tag) != element_name:
                continue
            version = node.attrib.get("CreatedByVersion", "").strip()
            if version:
                return version
    return ""


def _table_title(table: ET.Element) -> str:
    return _element_text(_first_direct_child(table, "Title"))


def _unsupported_summary(
    table_id: str,
    title: str,
    table_type: str,
    ext_table_type: str,
    y_format: str,
    reason: str,
) -> PrismTableSummary:
    return PrismTableSummary(
        id=table_id,
        title=title,
        table_type=table_type,
        ext_table_type=ext_table_type,
        y_format=y_format,
        kind=PrismTableKind.UNSUPPORTED,
        supported=False,
        unsupported_reason=reason,
    )


def _classify_table(
    table_id: str,
    table: ET.Element,
    *,
    version_supported: bool,
) -> PrismTableSummary:
    title = _table_title(table)
    table_type = table.attrib.get("TableType", "").strip()
    ext_table_type = table.attrib.get("ExtTableType", "").strip()
    y_format = table.attrib.get("YFormat", "").strip()

    if _local_name(table.tag) == "HugeTable":
        return _unsupported_summary(
            table_id,
            title,
            table_type,
            ext_table_type,
            y_format,
            "HugeTable data is not supported in the first Prism import milestone.",
        )
    if not version_supported:
        return _unsupported_summary(
            table_id,
            title,
            table_type,
            ext_table_type,
            y_format,
            "This Prism application version has not been validated for PZFX import.",
        )
    if ext_table_type:
        return _unsupported_summary(
            table_id,
            title,
            table_type,
            ext_table_type,
            y_format,
            f"Extended Prism table type '{ext_table_type}' is not supported.",
        )
    if table_type == "OneWay":
        if y_format not in {"", "replicates"}:
            return _unsupported_summary(
                table_id,
                title,
                table_type,
                ext_table_type,
                y_format,
                f"Pre-averaged Y format '{y_format}' cannot be imported as raw values.",
            )
        if _direct_children(table, "XColumn") or _direct_children(table, "XAdvancedColumn"):
            return _unsupported_summary(
                table_id,
                title,
                table_type,
                ext_table_type,
                y_format,
                "OneWay tables containing X data are not supported as Column tables.",
            )
        y_columns = _direct_children(table, "YColumn")
        if not y_columns:
            return _unsupported_summary(
                table_id,
                title,
                table_type,
                ext_table_type,
                y_format,
                "Column table does not contain any YColumn data.",
            )
        if any(len(_direct_children(column, "Subcolumn")) != 1 for column in y_columns):
            return _unsupported_summary(
                table_id,
                title,
                table_type,
                ext_table_type,
                y_format,
                "Raw Column import requires exactly one Subcolumn per YColumn.",
            )
        return PrismTableSummary(
            id=table_id,
            title=title,
            table_type=table_type,
            ext_table_type=ext_table_type,
            y_format=y_format,
            kind=PrismTableKind.COLUMN,
            supported=True,
        )
    if table_type == "TwoWay":
        if y_format != "replicates":
            reason = (
                f"Grouped Y format '{y_format}' is not raw replicate data."
                if y_format
                else "Grouped table does not declare raw replicate data."
            )
            return _unsupported_summary(
                table_id,
                title,
                table_type,
                ext_table_type,
                y_format,
                reason,
            )
        row_title_columns = _direct_children(table, "RowTitlesColumn")
        y_columns = _direct_children(table, "YColumn")
        if len(row_title_columns) != 1 or not y_columns:
            return _unsupported_summary(
                table_id,
                title,
                table_type,
                ext_table_type,
                y_format,
                "Grouped import requires one RowTitlesColumn and at least one YColumn.",
            )
        if any(not _direct_children(column, "Subcolumn") for column in y_columns):
            return _unsupported_summary(
                table_id,
                title,
                table_type,
                ext_table_type,
                y_format,
                "Grouped YColumn does not contain replicate Subcolumns.",
            )
        return PrismTableSummary(
            id=table_id,
            title=title,
            table_type=table_type,
            ext_table_type=ext_table_type,
            y_format=y_format,
            kind=PrismTableKind.GROUPED,
            supported=True,
        )
    return _unsupported_summary(
        table_id,
        title,
        table_type,
        ext_table_type,
        y_format,
        f"Prism table type '{table_type or 'unknown'}' is not supported.",
    )


def _ordered_table_elements(root: ET.Element) -> tuple[tuple[str, ET.Element], ...]:
    raw_tables = [
        child for child in root if _local_name(child.tag) in {"Table", "HugeTable"}
    ]
    if len(raw_tables) > MAX_TABLES:
        raise PrismImportError(
            "too_many_tables",
            f"PZFX file contains more than {MAX_TABLES} tables.",
        )

    assigned: list[tuple[str, ET.Element]] = []
    seen: dict[str, int] = {}
    for index, table in enumerate(raw_tables, start=1):
        declared_id = table.attrib.get("ID", "").strip() or f"Table{index}"
        occurrence = seen.get(declared_id, 0) + 1
        seen[declared_id] = occurrence
        stable_id = declared_id if occurrence == 1 else f"{declared_id}#{occurrence}"
        assigned.append((stable_id, table))

    sequence = _first_direct_child(root, "TableSequence")
    if sequence is None:
        return tuple(assigned)
    ref_ids = [ref.attrib.get("ID", "").strip() for ref in _direct_children(sequence, "Ref")]
    first_by_declared_id = {
        table.attrib.get("ID", "").strip(): (stable_id, table)
        for stable_id, table in reversed(assigned)
        if table.attrib.get("ID", "").strip()
    }
    ordered: list[tuple[str, ET.Element]] = []
    used_elements: set[int] = set()
    for ref_id in ref_ids:
        item = first_by_declared_id.get(ref_id)
        if item is not None and id(item[1]) not in used_elements:
            ordered.append(item)
            used_elements.add(id(item[1]))
    ordered.extend(item for item in assigned if id(item[1]) not in used_elements)
    return tuple(ordered)


def _parse_document(path: Path) -> _ParsedDocument:
    input_path = Path(path)
    if input_path.suffix.casefold() == ".pzf":
        raise PrismImportError(
            "legacy_pzf",
            "Legacy .pzf files are binary. Open the file in Prism and save it as .pzfx first.",
        )
    if input_path.suffix.casefold() != ".pzfx":
        raise PrismImportError("unsupported_file", "Select a GraphPad Prism .pzfx file.")

    root = _read_xml(input_path)
    if _local_name(root.tag) != "GraphPadPrismFile":
        raise PrismImportError(
            "invalid_root",
            "The XML root element is not GraphPadPrismFile.",
        )
    xml_version = root.attrib.get("PrismXMLVersion", "").strip()
    if xml_version != PZFX_XML_VERSION:
        raise PrismImportError(
            "unsupported_xml_version",
            f"Unsupported Prism XML version '{xml_version or 'missing'}'; expected {PZFX_XML_VERSION}.",
        )

    created_by_version = _created_by_version(root)
    major_version = _major_version(created_by_version)
    version_supported = major_version in SUPPORTED_PRISM_MAJORS
    warnings: list[PrismWarning] = []
    if not version_supported:
        warnings.append(
            PrismWarning(
                "unvalidated_prism_version",
                f"Prism application version '{created_by_version or 'missing'}' is outside the validated 8–11 range.",
            )
        )

    table_elements = _ordered_table_elements(root)
    if not table_elements:
        raise PrismImportError("no_tables", "The PZFX file does not contain any data tables.")
    declared_ids = [
        table.attrib.get("ID", "").strip()
        for table in root
        if _local_name(table.tag) in {"Table", "HugeTable"}
    ]
    if any(not table_id for table_id in declared_ids):
        warnings.append(
            PrismWarning(
                "missing_table_id",
                "One or more Prism tables have no ID; stable fallback IDs were assigned.",
            )
        )
    duplicate_ids = sorted({table_id for table_id in declared_ids if table_id and declared_ids.count(table_id) > 1})
    if duplicate_ids:
        warnings.append(
            PrismWarning(
                "duplicate_table_id",
                f"Duplicate Prism table IDs were disambiguated: {', '.join(duplicate_ids)}.",
            )
        )

    data_node_count = sum(len(_descendants(table, "d")) for _, table in table_elements)
    y_column_count = sum(len(_direct_children(table, "YColumn")) for _, table in table_elements)
    subcolumn_count = sum(len(_descendants(table, "Subcolumn")) for _, table in table_elements)
    if data_node_count > MAX_DATA_NODES:
        raise PrismImportError("too_many_values", f"PZFX file contains more than {MAX_DATA_NODES} data values.")
    if y_column_count > MAX_Y_COLUMNS:
        raise PrismImportError("too_many_columns", f"PZFX file contains more than {MAX_Y_COLUMNS} Y columns.")
    if subcolumn_count > MAX_SUBCOLUMNS:
        raise PrismImportError("too_many_subcolumns", f"PZFX file contains more than {MAX_SUBCOLUMNS} subcolumns.")

    tables = tuple(
        (
            table_id,
            table,
            _classify_table(table_id, table, version_supported=version_supported),
        )
        for table_id, table in table_elements
    )
    return _ParsedDocument(
        path=input_path,
        root=root,
        xml_version=xml_version,
        created_by_version=created_by_version,
        major_version=major_version,
        tables=tables,
        warnings=tuple(warnings),
    )


def inspect_pzfx(path: Path) -> PrismProjectSummary:
    document = _parse_document(Path(path))
    return PrismProjectSummary(
        path=document.path,
        xml_version=document.xml_version,
        created_by_version=document.created_by_version,
        tables=tuple(summary for _, _, summary in document.tables),
        warnings=document.warnings,
    )


def _value_from_node(
    node: ET.Element | None,
    *,
    table_id: str,
    group_name: str,
    position: str,
) -> tuple[float | None, bool, bool]:
    if node is None:
        return None, True, False
    excluded = node.attrib.get("Excluded", "").strip().casefold() in {"true", "1"}
    if excluded:
        return None, False, True
    text = _element_text(node).strip()
    if not text:
        return None, True, False
    try:
        value = float(text)
    except ValueError as exc:
        raise PrismImportError(
            "non_numeric_value",
            f"Table '{table_id}', group '{group_name}', value {position} is not numeric: {text!r}.",
            table_id=table_id,
        ) from exc
    if not math.isfinite(value):
        raise PrismImportError(
            "non_finite_value",
            f"Table '{table_id}', group '{group_name}', value {position} is not finite.",
            table_id=table_id,
        )
    return value, False, False


def _parse_column_table(table_id: str, table: ET.Element) -> PrismRawTable:
    groups: list[PrismRawGroup] = []
    warnings: list[PrismWarning] = []
    missing_count = 0
    excluded_count = 0
    if _direct_children(table, "RowTitlesColumn"):
        warnings.append(
            PrismWarning(
                "column_row_titles_not_preserved",
                "Column row titles are not represented in EasyGraph and were not imported.",
            )
        )

    for column_index, y_column in enumerate(_direct_children(table, "YColumn"), start=1):
        title = _element_text(_first_direct_child(y_column, "Title")) or f"Group {column_index}"
        subcolumn = _direct_children(y_column, "Subcolumn")[0]
        values: list[float | None] = []
        for value_index, node in enumerate(_direct_children(subcolumn, "d"), start=1):
            value, missing, excluded = _value_from_node(
                node,
                table_id=table_id,
                group_name=title,
                position=str(value_index),
            )
            values.append(value)
            missing_count += int(missing)
            excluded_count += int(excluded)
        groups.append(PrismRawGroup(title, tuple(values)))
    maximum_length = max((len(group.values) for group in groups), default=0)
    if any(len(group.values) != maximum_length for group in groups):
        warnings.append(
            PrismWarning(
                "unequal_column_lengths",
                "Column groups have different lengths; shorter groups were padded with empty values.",
            )
        )
        padded_groups: list[PrismRawGroup] = []
        for group in groups:
            padding = maximum_length - len(group.values)
            missing_count += padding
            padded_groups.append(
                PrismRawGroup(group.name, tuple((*group.values, *((None,) * padding))))
            )
        groups = padded_groups
    return PrismRawTable(
        groups=tuple(groups),
        missing_count=missing_count,
        excluded_count=excluded_count,
        warnings=tuple(warnings),
    )


def _parse_grouped_table(table_id: str, table: ET.Element) -> PrismRawTable:
    warnings: list[PrismWarning] = []
    short_subcolumn_warning_added = False
    missing_count = 0
    excluded_count = 0
    row_title_column = _direct_children(table, "RowTitlesColumn")[0]
    row_title_subcolumns = _direct_children(row_title_column, "Subcolumn")
    row_title_nodes = (
        _direct_children(row_title_subcolumns[0], "d") if row_title_subcolumns else []
    )
    y_columns = _direct_children(table, "YColumn")
    declared_replicates = table.attrib.get("Replicates", "").strip()
    actual_replicate_counts = {
        len(_direct_children(y_column, "Subcolumn")) for y_column in y_columns
    }
    if (
        declared_replicates
        and declared_replicates.isdigit()
        and any(int(declared_replicates) != count for count in actual_replicate_counts)
    ):
        warnings.append(
            PrismWarning(
                "replicate_count_mismatch",
                f"Table declares {declared_replicates} replicates but its YColumn structure differs.",
            )
        )
    maximum_data_rows = max(
        (
            len(_direct_children(subcolumn, "d"))
            for y_column in y_columns
            for subcolumn in _direct_children(y_column, "Subcolumn")
        ),
        default=0,
    )
    row_count = max(len(row_title_nodes), maximum_data_rows)
    if row_count > len(row_title_nodes):
        warnings.append(
            PrismWarning(
                "missing_grouped_row_titles",
                "Some Grouped data rows have no row title; stable fallback names were used.",
            )
        )
    row_titles = [
        _element_text(row_title_nodes[index]) if index < len(row_title_nodes) else ""
        for index in range(row_count)
    ]

    groups: list[PrismRawGroup] = []
    for column_index, y_column in enumerate(y_columns, start=1):
        column_title = _element_text(_first_direct_child(y_column, "Title")) or f"Column {column_index}"
        subcolumns = _direct_children(y_column, "Subcolumn")
        subcolumn_values = [_direct_children(subcolumn, "d") for subcolumn in subcolumns]
        declared = y_column.attrib.get("Subcolumns", "").strip()
        if declared and declared.isdigit() and int(declared) != len(subcolumns):
            warnings.append(
                PrismWarning(
                    "subcolumn_count_mismatch",
                    f"YColumn '{column_title}' declares {declared} subcolumns but contains {len(subcolumns)}.",
                )
            )
        for row_index in range(row_count):
            row_title = row_titles[row_index] or f"Row {row_index + 1}"
            group_name = f"{column_title} · {row_title}"
            values: list[float | None] = []
            for replicate_index, nodes in enumerate(subcolumn_values, start=1):
                node = nodes[row_index] if row_index < len(nodes) else None
                value, missing, excluded = _value_from_node(
                    node,
                    table_id=table_id,
                    group_name=group_name,
                    position=f"row {row_index + 1}, replicate {replicate_index}",
                )
                values.append(value)
                missing_count += int(missing)
                excluded_count += int(excluded)
                if node is None:
                    if not short_subcolumn_warning_added:
                        warnings.append(
                            PrismWarning(
                                "short_grouped_subcolumn",
                                "One or more short Grouped Subcolumns were padded with empty values.",
                            )
                        )
                        short_subcolumn_warning_added = True
            groups.append(PrismRawGroup(
                group_name, tuple(values),
                parent_id=f"prism-parent-{column_index}",
                parent_name=column_title,
                subgroup_id=f"prism-subgroup-{row_index + 1}",
                subgroup_name=row_title,
            ))
    return PrismRawTable(
        groups=tuple(groups),
        missing_count=missing_count,
        excluded_count=excluded_count,
        warnings=tuple(warnings),
    )


def _import_document_table(
    document: _ParsedDocument,
    table_id: str,
) -> PrismImportResult:
    selected = next((item for item in document.tables if item[0] == table_id), None)
    if selected is None:
        raise PrismImportError(
            "table_not_found",
            f"Prism table '{table_id}' was not found.",
            table_id=table_id,
        )
    _, table, summary = selected
    if not summary.supported:
        raise PrismImportError(
            "unsupported_table",
            summary.unsupported_reason,
            table_id=table_id,
        )
    if summary.kind == PrismTableKind.COLUMN:
        raw_table = _parse_column_table(table_id, table)
    elif summary.kind == PrismTableKind.GROUPED:
        raw_table = _parse_grouped_table(table_id, table)
    else:  # defensive guard for future table kinds
        raise PrismImportError(
            "unsupported_table",
            summary.unsupported_reason or "Unsupported Prism table.",
            table_id=table_id,
        )
    return PrismImportResult(
        dataframe=groups_to_dataframe(raw_table.groups),
        table=summary,
        xml_version=document.xml_version,
        created_by_version=document.created_by_version,
        missing_count=raw_table.missing_count,
        excluded_count=raw_table.excluded_count,
        warnings=tuple((*document.warnings, *raw_table.warnings)),
    )


def import_pzfx_tables(
    path: Path,
    table_ids: Iterable[str] | None = None,
) -> tuple[PrismImportResult, ...]:
    """Import selected supported tables after parsing the PZFX document once.

    When ``table_ids`` is omitted, every supported table is imported in Prism's
    TableSequence order. Explicit IDs are imported in the order supplied.
    """

    document = _parse_document(Path(path))
    selected_ids = (
        [summary.id for _, _, summary in document.tables if summary.supported]
        if table_ids is None
        else [str(table_id) for table_id in table_ids]
    )
    return tuple(
        _import_document_table(document, table_id) for table_id in selected_ids
    )


def import_pzfx_table(path: Path, table_id: str) -> PrismImportResult:
    """Import one Prism table while preserving the original public API."""

    return import_pzfx_tables(path, (table_id,))[0]


__all__ = ["import_pzfx_table", "import_pzfx_tables", "inspect_pzfx"]
