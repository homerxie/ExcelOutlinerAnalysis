"""Map parsed Prism groups to EasyGraph's wide DataFrame model."""

from __future__ import annotations

from dataclasses import asdict

import pandas as pd

from easygraph.data import attach_group_metadata
from easygraph.grouping import GroupingSettings

from .models import PrismRawGroup


def groups_to_dataframe(groups: tuple[PrismRawGroup, ...]) -> pd.DataFrame:
    """Return a wide frame while preserving group order and duplicate names."""
    names = [group.subgroup_name if group.parent_id is not None else group.name for group in groups]
    if not groups:
        return pd.DataFrame()

    row_count = max((len(group.values) for group in groups), default=0)
    rows = [
        [
            group.values[row_index] if row_index < len(group.values) else None
            for group in groups
        ]
        for row_index in range(row_count)
    ]
    dataframe = pd.DataFrame(rows, columns=names, dtype=float)
    if any(group.parent_id is not None for group in groups):
        column_ids = [f"prism-column-{index + 1}" for index in range(len(groups))]
        parents = {}
        categories = {}
        for column_id, group in zip(column_ids, groups):
            if group.parent_id is None:
                continue
            parent = parents.setdefault(group.parent_id, {"id": group.parent_id, "name": group.parent_name or "Group", "column_ids": []})
            parent["column_ids"].append(column_id)
            if group.subgroup_id is not None:
                categories[column_id] = group.subgroup_id
        dataframe = attach_group_metadata(dataframe, column_ids)
        dataframe.attrs["grouping"] = asdict(GroupingSettings(list(parents.values()), True, categories))
    return dataframe


__all__ = ["groups_to_dataframe"]
