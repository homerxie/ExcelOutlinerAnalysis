"""Stable data contracts for GraphPad Prism imports."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path

import pandas as pd


class PrismTableKind(str, Enum):
    COLUMN = "Column"
    GROUPED = "Grouped"
    UNSUPPORTED = "Unsupported"


@dataclass(frozen=True)
class PrismWarning:
    code: str
    message: str


@dataclass(frozen=True)
class PrismTableSummary:
    id: str
    title: str
    table_type: str
    ext_table_type: str
    y_format: str
    kind: PrismTableKind
    supported: bool
    unsupported_reason: str = ""

    @property
    def display_title(self) -> str:
        return self.title or self.id


@dataclass(frozen=True)
class PrismProjectSummary:
    path: Path
    xml_version: str
    created_by_version: str
    tables: tuple[PrismTableSummary, ...]
    warnings: tuple[PrismWarning, ...] = ()


@dataclass(frozen=True)
class PrismImportResult:
    dataframe: pd.DataFrame
    table: PrismTableSummary
    xml_version: str
    created_by_version: str
    missing_count: int
    excluded_count: int
    warnings: tuple[PrismWarning, ...] = ()


class PrismImportError(ValueError):
    """A stable, user-presentable Prism import failure."""

    def __init__(self, code: str, message: str, *, table_id: str = "") -> None:
        super().__init__(message)
        self.code = code
        self.table_id = table_id


@dataclass(frozen=True)
class PrismRawGroup:
    name: str
    values: tuple[float | None, ...]
    parent_id: str | None = None
    parent_name: str | None = None
    subgroup_id: str | None = None
    subgroup_name: str | None = None


@dataclass(frozen=True)
class PrismRawTable:
    groups: tuple[PrismRawGroup, ...]
    missing_count: int
    excluded_count: int
    warnings: tuple[PrismWarning, ...] = ()
