"""EasyGraph application modules."""
