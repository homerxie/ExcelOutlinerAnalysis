from __future__ import annotations

import ctypes
from pathlib import Path
import sys

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from easygraph.app_info import APP_DISPLAY_NAME, APP_NAME, APP_VERSION

APPLICATION_NAME = APP_NAME
WINDOWS_APP_USER_MODEL_ID = "EasyGraph.EasyGraph.Desktop"
ICON_PNG_SIZES = (16, 32, 64, 128, 256, 512, 1024)
ICON_THEMES = ("dark", "light")


def normalize_icon_theme(theme: str | None) -> str:
    return "light" if str(theme or "").strip().lower() == "light" else "dark"


def icon_directory(
    theme: str | None = None,
    *,
    platform_name: str | None = None,
) -> Path:
    """Return the icon directory in a source tree or PyInstaller bundle."""

    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        root = Path(sys._MEIPASS)
    else:
        root = Path(__file__).resolve().parents[2]
    selected_theme = normalize_icon_theme(theme)
    if (platform_name or sys.platform).startswith("win"):
        return root / "icon" / "windows" / selected_theme / "png"
    return root / "icon" / selected_theme / "png"


def icon_png_paths(theme: str | None = None) -> dict[int, Path]:
    selected_theme = normalize_icon_theme(theme)
    directory = icon_directory(selected_theme)
    return {
        size: directory / f"EasyGraph_{selected_theme}_{size}x{size}.png"
        for size in ICON_PNG_SIZES
    }


def create_application_icon(theme: str | None = None) -> QIcon:
    """Build a Qt icon containing explicit pixmaps for every supported DPI."""

    icon = QIcon()
    for path in icon_png_paths(theme).values():
        if path.is_file():
            icon.addFile(str(path))
    return icon


def configure_platform_identity() -> None:
    """Give Windows a stable taskbar identity instead of python.exe's identity."""

    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            WINDOWS_APP_USER_MODEL_ID
        )
    except (AttributeError, OSError):
        # Restricted Windows environments can omit this API. The explicit Qt
        # and executable icons still provide the correct fallback.
        pass


def configure_application_icon(app: QApplication, theme: str | None = None) -> QIcon:
    app.setApplicationName(APPLICATION_NAME)
    app.setOrganizationName(APPLICATION_NAME)
    app.setApplicationDisplayName(APP_DISPLAY_NAME)
    app.setApplicationVersion(APP_VERSION)
    icon = create_application_icon(theme)
    app.setWindowIcon(icon)
    return icon


__all__ = [
    "APPLICATION_NAME",
    "ICON_PNG_SIZES",
    "ICON_THEMES",
    "WINDOWS_APP_USER_MODEL_ID",
    "configure_application_icon",
    "configure_platform_identity",
    "create_application_icon",
    "icon_directory",
    "icon_png_paths",
    "normalize_icon_theme",
]
