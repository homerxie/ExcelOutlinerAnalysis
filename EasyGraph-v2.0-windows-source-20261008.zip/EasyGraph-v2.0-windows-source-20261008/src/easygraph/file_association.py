from __future__ import annotations

import ctypes
from enum import Enum
import os
from pathlib import Path, PureWindowsPath
import sys
from typing import Callable, Iterable

from PySide6.QtCore import QEvent
from PySide6.QtWidgets import QApplication


PROJECT_EXTENSION = ".eg"
PROJECT_MIME_TYPE = "application/x-easygraph-project"
WINDOWS_PROJECT_PROG_ID = "EasyGraph.Project"
WINDOWS_PROJECT_ICON_FILENAME = "EasyGraph_Project_Icon_Windows.ico"
WINDOWS_PROJECT_ICON_BUNDLE_PARTS = (
    "icon",
    "windows",
    "project",
    WINDOWS_PROJECT_ICON_FILENAME,
)
WINDOWS_SHELL_ASSOCIATION_CHANGED = 0x08000000
WINDOWS_SHELL_NOTIFY_FLUSH = 0x1000
MACOS_BUNDLE_IDENTIFIER = "com.easygraph.desktop"
MACOS_PROJECT_UTI = "com.easygraph.project"

ProjectFileHandler = Callable[[Path], object]


class FileAssociationRefreshStatus(Enum):
    REFRESHED = "refreshed"
    PACKAGED_APP_REQUIRED = "packaged_app_required"
    FAILED = "failed"
    UNSUPPORTED = "unsupported"


def normalized_project_path(value: str | Path) -> Path | None:
    try:
        path = Path(value).expanduser()
    except (TypeError, ValueError):
        return None
    if path.suffix.casefold() != PROJECT_EXTENSION:
        return None
    return path


def project_path_from_arguments(arguments: Iterable[str]) -> Path | None:
    for argument in arguments:
        path = normalized_project_path(argument)
        if path is not None:
            return path
    return None


class ProjectFileOpenRouter:
    def __init__(self) -> None:
        self._handler: ProjectFileHandler | None = None
        self._pending: list[Path] = []

    def set_handler(self, handler: ProjectFileHandler) -> None:
        self._handler = handler
        pending = tuple(self._pending)
        self._pending.clear()
        for path in pending:
            handler(path)

    def request(self, value: str | Path) -> bool:
        path = normalized_project_path(value)
        if path is None:
            return False
        if self._handler is None:
            if path not in self._pending:
                self._pending.append(path)
        else:
            self._handler(path)
        return True


class EasyGraphApplication(QApplication):
    """QApplication that preserves macOS Finder open-document events."""

    def __init__(self, arguments: list[str]) -> None:
        self._project_file_router = ProjectFileOpenRouter()
        super().__init__(arguments)

    def set_project_file_handler(self, handler: ProjectFileHandler) -> None:
        self._project_file_router.set_handler(handler)

    def request_project_file(self, value: str | Path) -> bool:
        return self._project_file_router.request(value)

    def event(self, event) -> bool:
        if event.type() == QEvent.Type.FileOpen:
            file_path = event.file()
            if file_path and self.request_project_file(file_path):
                event.accept()
                return True
        return super().event(event)


def windows_file_association_registry_values(
    executable: Path,
    project_icon: Path | None = None,
) -> tuple[tuple[str, str, str | bytes, str], ...]:
    executable_text = str(Path(executable))
    project_icon_text = str(project_icon) if project_icon is not None else str(
        PureWindowsPath(executable_text).with_name(
            WINDOWS_PROJECT_ICON_FILENAME
        )
    )
    application_key = (
        fr"Software\Classes\Applications\{PureWindowsPath(executable_text).name}"
    )
    command = f'"{executable_text}" "%1"'
    classes = r"Software\Classes"
    capabilities = r"Software\EasyGraph\Capabilities"
    return (
        (fr"{classes}\{PROJECT_EXTENSION}", "", WINDOWS_PROJECT_PROG_ID, "string"),
        (fr"{classes}\{PROJECT_EXTENSION}", "Content Type", PROJECT_MIME_TYPE, "string"),
        (
            fr"{classes}\{PROJECT_EXTENSION}\DefaultIcon",
            "",
            f'"{project_icon_text}",0',
            "string",
        ),
        (
            fr"{classes}\{PROJECT_EXTENSION}\OpenWithProgids",
            WINDOWS_PROJECT_PROG_ID,
            b"",
            "none",
        ),
        (fr"{classes}\{WINDOWS_PROJECT_PROG_ID}", "", "EasyGraph Project", "string"),
        (
            fr"{classes}\{WINDOWS_PROJECT_PROG_ID}",
            "FriendlyTypeName",
            "EasyGraph Project",
            "string",
        ),
        (
            fr"{classes}\{WINDOWS_PROJECT_PROG_ID}\DefaultIcon",
            "",
            f'"{project_icon_text}",0',
            "string",
        ),
        (
            fr"{classes}\{WINDOWS_PROJECT_PROG_ID}\shell\open\command",
            "",
            command,
            "string",
        ),
        (
            fr"{application_key}\DefaultIcon",
            "",
            f'"{project_icon_text}",0',
            "string",
        ),
        (
            fr"{application_key}\shell\open\command",
            "",
            command,
            "string",
        ),
        (
            fr"{application_key}\SupportedTypes",
            PROJECT_EXTENSION,
            b"",
            "none",
        ),
        (capabilities, "ApplicationName", "EasyGraph", "string"),
        (
            capabilities,
            "ApplicationDescription",
            "Create and edit EasyGraph project files.",
            "string",
        ),
        (
            fr"{capabilities}\FileAssociations",
            PROJECT_EXTENSION,
            WINDOWS_PROJECT_PROG_ID,
            "string",
        ),
        (
            r"Software\RegisteredApplications",
            "EasyGraph",
            capabilities,
            "string",
        ),
    )


def windows_project_icon_path(
    executable: Path,
    *,
    bundle_root: Path | None = None,
) -> Path:
    executable_path = Path(executable)
    selected_bundle_root = (
        Path(sys._MEIPASS)
        if bundle_root is None and hasattr(sys, "_MEIPASS")
        else bundle_root
    )
    if selected_bundle_root is not None:
        bundled_icon = Path(selected_bundle_root).joinpath(
            *WINDOWS_PROJECT_ICON_BUNDLE_PARTS
        )
        if bundled_icon.is_file():
            return bundled_icon
    return executable_path.with_name(WINDOWS_PROJECT_ICON_FILENAME)


def register_windows_project_file_association(
    executable: Path | None = None,
    *,
    platform_name: str | None = None,
    frozen: bool | None = None,
    registry_module=None,
    notify_shell: bool = True,
) -> bool:
    selected_platform = sys.platform if platform_name is None else platform_name
    selected_frozen = bool(getattr(sys, "frozen", False)) if frozen is None else frozen
    if selected_platform != "win32" or not selected_frozen:
        return False

    if registry_module is None:
        import winreg as registry_module

    executable_path = Path(sys.executable if executable is None else executable)
    project_icon_path = windows_project_icon_path(executable_path)
    try:
        for key_path, value_name, value, value_kind in windows_file_association_registry_values(
            executable_path,
            project_icon_path,
        ):
            key = registry_module.CreateKey(registry_module.HKEY_CURRENT_USER, key_path)
            try:
                registry_type = (
                    registry_module.REG_NONE
                    if value_kind == "none"
                    else registry_module.REG_SZ
                )
                registry_module.SetValueEx(
                    key,
                    value_name,
                    0,
                    registry_type,
                    value,
                )
            finally:
                registry_module.CloseKey(key)
    except OSError:
        return False

    if notify_shell:
        try:
            ctypes.windll.shell32.SHChangeNotify(
                WINDOWS_SHELL_ASSOCIATION_CHANGED,
                WINDOWS_SHELL_NOTIFY_FLUSH,
                None,
                None,
            )
        except (AttributeError, OSError):
            pass
    return True


def macos_application_bundle_path(executable: Path | None = None) -> Path | None:
    executable_path = Path(sys.executable if executable is None else executable)
    for candidate in (executable_path, *executable_path.parents):
        if candidate.suffix.casefold() == ".app":
            return candidate
    return None


def register_macos_project_file_association(
    bundle: Path | None = None,
    *,
    platform_name: str | None = None,
    frozen: bool | None = None,
    core_foundation=None,
    launch_services=None,
) -> bool:
    selected_platform = sys.platform if platform_name is None else platform_name
    selected_frozen = bool(getattr(sys, "frozen", False)) if frozen is None else frozen
    if selected_platform != "darwin" or not selected_frozen:
        return False

    bundle_path = (
        macos_application_bundle_path()
        if bundle is None
        else Path(bundle)
    )
    if bundle_path is None or not bundle_path.is_dir():
        return False

    try:
        if core_foundation is None:
            core_foundation = ctypes.CDLL(
                "/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation"
            )
        if launch_services is None:
            launch_services = ctypes.CDLL(
                "/System/Library/Frameworks/CoreServices.framework/CoreServices"
            )

        create_url = core_foundation.CFURLCreateFromFileSystemRepresentation
        create_url.argtypes = [
            ctypes.c_void_p,
            ctypes.c_char_p,
            ctypes.c_long,
            ctypes.c_ubyte,
        ]
        create_url.restype = ctypes.c_void_p
        release = core_foundation.CFRelease
        release.argtypes = [ctypes.c_void_p]
        release.restype = None
        register_url = launch_services.LSRegisterURL
        register_url.argtypes = [ctypes.c_void_p, ctypes.c_ubyte]
        register_url.restype = ctypes.c_int32

        bundle_bytes = os.fsencode(str(bundle_path))
        url_ref = create_url(None, bundle_bytes, len(bundle_bytes), True)
        if not url_ref:
            return False
        try:
            return register_url(url_ref, True) == 0
        finally:
            release(url_ref)
    except (AttributeError, OSError):
        return False


def refresh_project_file_association(
    *,
    platform_name: str | None = None,
    frozen: bool | None = None,
) -> FileAssociationRefreshStatus:
    selected_platform = sys.platform if platform_name is None else platform_name
    selected_frozen = bool(getattr(sys, "frozen", False)) if frozen is None else frozen
    if selected_platform not in {"win32", "darwin"}:
        return FileAssociationRefreshStatus.UNSUPPORTED
    if not selected_frozen:
        return FileAssociationRefreshStatus.PACKAGED_APP_REQUIRED
    if selected_platform == "win32":
        refreshed = register_windows_project_file_association(
            platform_name=selected_platform,
            frozen=selected_frozen,
        )
    else:
        refreshed = register_macos_project_file_association(
            platform_name=selected_platform,
            frozen=selected_frozen,
        )
    return (
        FileAssociationRefreshStatus.REFRESHED
        if refreshed
        else FileAssociationRefreshStatus.FAILED
    )


__all__ = [
    "EasyGraphApplication",
    "FileAssociationRefreshStatus",
    "MACOS_BUNDLE_IDENTIFIER",
    "MACOS_PROJECT_UTI",
    "PROJECT_EXTENSION",
    "PROJECT_MIME_TYPE",
    "ProjectFileOpenRouter",
    "WINDOWS_PROJECT_ICON_FILENAME",
    "WINDOWS_PROJECT_ICON_BUNDLE_PARTS",
    "WINDOWS_PROJECT_PROG_ID",
    "WINDOWS_SHELL_ASSOCIATION_CHANGED",
    "WINDOWS_SHELL_NOTIFY_FLUSH",
    "macos_application_bundle_path",
    "normalized_project_path",
    "project_path_from_arguments",
    "refresh_project_file_association",
    "register_macos_project_file_association",
    "register_windows_project_file_association",
    "windows_file_association_registry_values",
    "windows_project_icon_path",
]
