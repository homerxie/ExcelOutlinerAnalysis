from __future__ import annotations

import json
import re
from copy import deepcopy
from dataclasses import asdict, dataclass, fields
from pathlib import Path

from PySide6.QtGui import QColor

from easygraph.project_io import chart_settings_from_dict
from easygraph.settings import (
    ChartSettings,
    GROUP_COLOR_TEMPLATE_KEY_PREFIX,
    STYLE_TEMPLATE_CONTENT_FIELDS,
)
from easygraph.xy_series import XYSettings

TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "template"
TEMPLATE_NONE_NAME = "None"
STYLE_TEMPLATE_VERSION = 2
STYLE_TEMPLATE_VERSION_KEY = "version"
STYLE_TEMPLATE_COMMON_KEY = "common"
STYLE_TEMPLATE_VARIANTS_KEY = "variants"
TEMPLATE_FAMILY_GROUPS = "groups"
TEMPLATE_FAMILY_XY = "xy"
XY_STYLE_TEMPLATE_KEY = "xy_style"

# Compatibility for v2 files written during the short-lived development
# period before the public family name was finalized as ``groups``.  This is
# deliberately not a public/API family value: readers normalize it to groups
# and every subsequent save/import writes only ``variants.groups``.
_LEGACY_V2_FAMILY_DISTRIBUTION = "distribution"

_TEMPLATE_FAMILIES = {
    TEMPLATE_FAMILY_GROUPS,
    TEMPLATE_FAMILY_XY,
}
_TEMPLATE_COMMON_FIELDS = {
    "preset",
    "width",
    "height",
    "dpi",
    "title_font_size",
    "axis_label_font_size",
    "tick_font_size",
    "additional_guide_font_size",
    "additional_guide_line_width",
    "additional_guide_palette",
    "show_legend",
    "legend_font_size",
    "legend_width",
    "legend_height",
    "legend_auto_wrap",
    "legend_auto_width",
    "legend_columns",
    "legend_position",
    "legend_inside_x",
    "legend_inside_y",
    "axis_line_width",
    "show_grid",
    "transparent_background",
}
_TEMPLATE_XY_CHART_FIELDS = {
    "group_order",
    "x_tick_rotation",
    "auto_x_range",
    "x_min",
    "x_max",
    "x_auto_tick_interval",
    "x_tick_interval",
    "auto_y_range",
    "y_min",
    "y_max",
    "primary_auto_tick_interval",
    "primary_tick_interval",
}
_TEMPLATE_XY_ONLY_CHART_FIELDS = {
    "auto_x_range",
    "x_min",
    "x_max",
    "x_auto_tick_interval",
    "x_tick_interval",
}
_TEMPLATE_CONTENT_FIELDS = set(STYLE_TEMPLATE_CONTENT_FIELDS) | {
    "group_col",
    "value_col",
}
_CHART_SETTING_FIELDS = {field.name for field in fields(ChartSettings)}
_TEMPLATE_GROUPS_FIELDS = (
    _CHART_SETTING_FIELDS
    - _TEMPLATE_COMMON_FIELDS
    - _TEMPLATE_CONTENT_FIELDS
    - _TEMPLATE_XY_ONLY_CHART_FIELDS
)


@dataclass(frozen=True)
class XYStyleTemplate:
    show_points: bool = True
    show_line: bool = True
    point_size: float = 4.0
    point_alpha: float = 0.75
    marker: str = "Circle"
    line_width: float = 1.6
    line_style: str = "Solid"

    def __post_init__(self) -> None:
        if not self.show_points and not self.show_line:
            raise ValueError("XY style must show points or lines.")


__all__ = [
    "STYLE_TEMPLATE_VERSION",
    "TEMPLATE_DIR",
    "TEMPLATE_FAMILY_GROUPS",
    "TEMPLATE_FAMILY_XY",
    "TEMPLATE_NONE_NAME",
    "XY_STYLE_TEMPLATE_KEY",
    "XYStyleTemplate",
    "apply_xy_style_template",
    "apply_style_template_settings",
    "group_colors_for_target_groups",
    "import_style_template",
    "indexed_group_colors_from_settings",
    "list_style_templates",
    "read_style_template",
    "read_style_template_file",
    "read_xy_style_template",
    "read_xy_style_template_file",
    "style_template_settings_data",
    "style_template_families",
    "style_template_families_file",
    "template_file_name",
    "template_indexed_group_colors",
    "write_style_template",
    "xy_style_template_data",
]


def xy_style_template_data(
    settings: XYSettings | XYStyleTemplate,
) -> dict:
    return asdict(
        settings
        if isinstance(settings, XYStyleTemplate)
        else XYStyleTemplate(
            show_points=settings.show_points,
            show_line=settings.show_line,
            point_size=settings.point_size,
            point_alpha=settings.point_alpha,
            marker=settings.marker,
            line_width=settings.line_width,
            line_style=settings.line_style,
        )
    )


def apply_xy_style_template(
    current: XYSettings,
    template: XYStyleTemplate,
) -> XYSettings:
    result = deepcopy(current)
    style_fields = fields(XYStyleTemplate)
    for field in style_fields:
        setattr(result, field.name, deepcopy(getattr(template, field.name)))
    # A style template describes the appearance of every series. Keeping an
    # older per-series override here would make the applied template partial
    # and can even leave a visible series with both points and lines disabled.
    for series in result.series:
        for field in style_fields:
            setattr(series, field.name, None)
    result.__post_init__()
    return result


def style_template_settings_data(settings: ChartSettings) -> dict:
    data = asdict(settings)
    defaults = asdict(ChartSettings())
    for key in STYLE_TEMPLATE_CONTENT_FIELDS:
        data[key] = deepcopy(defaults[key])
    data["custom_colors"] = indexed_group_colors_from_settings(settings)
    return data


def indexed_group_colors_from_settings(settings: ChartSettings) -> dict[str, str]:
    groups = [str(group) for group in settings.manual_group_order]
    indexed: dict[str, str] = {}
    for index, group in enumerate(groups):
        color = settings.custom_colors.get(group)
        if color is not None and QColor(color).isValid():
            indexed[f"{GROUP_COLOR_TEMPLATE_KEY_PREFIX}{index}"] = QColor(color).name()
    for key, color in settings.custom_colors.items():
        key_text = str(key)
        if key_text.startswith(GROUP_COLOR_TEMPLATE_KEY_PREFIX) and key_text.split(":", 1)[1].isdigit() and QColor(color).isValid():
            indexed[key_text] = QColor(color).name()
    return indexed


def template_indexed_group_colors(custom_colors: dict) -> dict[str, str]:
    return {
        str(key): QColor(color).name()
        for key, color in custom_colors.items()
        if str(key).startswith(GROUP_COLOR_TEMPLATE_KEY_PREFIX)
        and str(key).split(":", 1)[1].isdigit()
        and QColor(color).isValid()
    }


def group_colors_for_target_groups(custom_colors: dict, groups: list[str]) -> dict[str, str]:
    colors = template_indexed_group_colors(custom_colors)
    mapped: dict[str, str] = {}
    for key, color in colors.items():
        index = int(str(key).split(":", 1)[1])
        if 0 <= index < len(groups):
            mapped[str(groups[index])] = color
    return mapped


def apply_style_template_settings(current: ChartSettings, template: ChartSettings, groups: list[str] | None = None) -> ChartSettings:
    data = asdict(template)
    for key in _TEMPLATE_CONTENT_FIELDS:
        data[key] = deepcopy(getattr(current, key))
    target_groups = [str(group) for group in (groups if groups is not None else current.manual_group_order)]
    data["custom_colors"] = group_colors_for_target_groups(template.custom_colors, target_groups)
    data["custom_overlay_count"] = max(1, len(data["custom_overlay_series"]))
    return ChartSettings(**data)


def template_file_name(name: str) -> str:
    if name.strip().casefold() == TEMPLATE_NONE_NAME.casefold():
        raise ValueError("Template name is reserved.")
    stem = re.sub(r"[^\w .()-]+", "_", name.strip(), flags=re.UNICODE)
    stem = re.sub(r"\s+", " ", stem).strip(" .")
    if not stem:
        raise ValueError("Template name cannot be empty.")
    return f"{stem}.json"


def _read_template_json(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Style template must be a JSON object.")
    return data


def _is_v2_template(data: dict) -> bool:
    return any(
        key in data
        for key in (
            STYLE_TEMPLATE_VERSION_KEY,
            STYLE_TEMPLATE_COMMON_KEY,
            STYLE_TEMPLATE_VARIANTS_KEY,
        )
    )


def _validated_family(family: str) -> str:
    if family not in _TEMPLATE_FAMILIES:
        raise ValueError(
            "Unknown style template family: " + str(family)
        )
    return family


def _write_family(
    family: str | None,
    xy_settings: XYSettings | XYStyleTemplate | None,
) -> str:
    selected = (
        TEMPLATE_FAMILY_XY
        if family is None and xy_settings is not None
        else TEMPLATE_FAMILY_GROUPS
        if family is None
        else _validated_family(family)
    )
    if selected == TEMPLATE_FAMILY_GROUPS and xy_settings is not None:
        raise ValueError(
            "xy_settings can only be saved in an XY style template."
        )
    return selected


def _read_family(family: str | None, available: set[str]) -> str:
    if not available:
        raise ValueError("Style template does not contain any variants.")
    if family is None:
        if TEMPLATE_FAMILY_GROUPS in available:
            return TEMPLATE_FAMILY_GROUPS
        return TEMPLATE_FAMILY_XY
    selected = _validated_family(family)
    if selected not in available:
        raise ValueError(
            f"Style template has no {selected} variant."
        )
    return selected


def _require_available_family(
    family: str | None,
    available: set[str],
) -> None:
    if family is not None:
        _read_family(family, available)


def _empty_template_document() -> dict:
    return {
        STYLE_TEMPLATE_VERSION_KEY: STYLE_TEMPLATE_VERSION,
        STYLE_TEMPLATE_COMMON_KEY: {},
        STYLE_TEMPLATE_VARIANTS_KEY: {},
    }


def _validated_settings_payload(
    payload: object,
    allowed_fields: set[str],
    label: str,
) -> dict:
    if not isinstance(payload, dict):
        raise ValueError(f"{label} must be a JSON object.")
    unknown = sorted(str(key) for key in payload if key not in allowed_fields)
    if unknown:
        raise ValueError(f"Unknown {label} fields: " + ", ".join(unknown))
    return deepcopy(payload)


def _settings_from_template_document(
    document: dict,
    family: str,
) -> ChartSettings:
    data = asdict(ChartSettings())
    data.update(deepcopy(document[STYLE_TEMPLATE_COMMON_KEY]))
    variant = deepcopy(document[STYLE_TEMPLATE_VARIANTS_KEY][family])
    variant.pop(XY_STYLE_TEMPLATE_KEY, None)
    data.update(variant)
    for key in _TEMPLATE_CONTENT_FIELDS:
        data[key] = deepcopy(getattr(ChartSettings(), key))
    data["custom_colors"] = template_indexed_group_colors(
        data.get("custom_colors", {})
    )
    return chart_settings_from_dict(data)


def _template_document_from_v2(data: dict) -> dict:
    version = data.get(STYLE_TEMPLATE_VERSION_KEY)
    if type(version) is not int or version != STYLE_TEMPLATE_VERSION:
        raise ValueError(
            f"Unsupported style template version: {version!r}."
        )
    allowed_root = {
        STYLE_TEMPLATE_VERSION_KEY,
        STYLE_TEMPLATE_COMMON_KEY,
        STYLE_TEMPLATE_VARIANTS_KEY,
    }
    unknown_root = sorted(str(key) for key in data if key not in allowed_root)
    if unknown_root:
        raise ValueError(
            "Unknown style template fields: " + ", ".join(unknown_root)
        )
    common = _validated_settings_payload(
        data.get(STYLE_TEMPLATE_COMMON_KEY),
        _TEMPLATE_COMMON_FIELDS,
        "common style",
    )
    raw_variants = data.get(STYLE_TEMPLATE_VARIANTS_KEY)
    if not isinstance(raw_variants, dict):
        raise ValueError("Style template variants must be a JSON object.")
    accepted_families = _TEMPLATE_FAMILIES | {
        _LEGACY_V2_FAMILY_DISTRIBUTION,
    }
    unknown_families = sorted(
        str(key) for key in raw_variants if key not in accepted_families
    )
    if unknown_families:
        raise ValueError(
            "Unknown style template families: " + ", ".join(unknown_families)
        )
    if not raw_variants:
        raise ValueError("Style template does not contain any variants.")

    variants: dict[str, dict] = {}
    has_groups = TEMPLATE_FAMILY_GROUPS in raw_variants
    has_legacy_groups = _LEGACY_V2_FAMILY_DISTRIBUTION in raw_variants
    if has_groups and has_legacy_groups:
        raise ValueError(
            "Style template contains ambiguous groups variants."
        )
    if has_groups or has_legacy_groups:
        groups_payload = raw_variants[
            TEMPLATE_FAMILY_GROUPS
            if has_groups
            else _LEGACY_V2_FAMILY_DISTRIBUTION
        ]
        variants[TEMPLATE_FAMILY_GROUPS] = _validated_settings_payload(
            groups_payload,
            _TEMPLATE_GROUPS_FIELDS,
            "groups style",
        )
    if TEMPLATE_FAMILY_XY in raw_variants:
        variants[TEMPLATE_FAMILY_XY] = _validated_settings_payload(
            raw_variants[TEMPLATE_FAMILY_XY],
            _TEMPLATE_XY_CHART_FIELDS | {XY_STYLE_TEMPLATE_KEY},
            "XY style",
        )

    document = {
        STYLE_TEMPLATE_VERSION_KEY: STYLE_TEMPLATE_VERSION,
        STYLE_TEMPLATE_COMMON_KEY: common,
        STYLE_TEMPLATE_VARIANTS_KEY: variants,
    }
    for variant_family in variants:
        _settings_from_template_document(document, variant_family)
    xy_payload = variants.get(TEMPLATE_FAMILY_XY)
    if xy_payload is not None:
        _xy_style_from_payload(xy_payload.get(XY_STYLE_TEMPLATE_KEY))
    return document


def _legacy_template_family(data: dict) -> str:
    _legacy_chart_settings(data)
    if XY_STYLE_TEMPLATE_KEY in data:
        _xy_style_from_payload(data[XY_STYLE_TEMPLATE_KEY])
        return TEMPLATE_FAMILY_XY
    return TEMPLATE_FAMILY_GROUPS


def _template_document_from_legacy(data: dict) -> dict:
    family = _legacy_template_family(data)
    settings_data = style_template_settings_data(_legacy_chart_settings(data))
    document = _empty_template_document()
    document[STYLE_TEMPLATE_COMMON_KEY] = {
        key: deepcopy(settings_data[key])
        for key in sorted(_TEMPLATE_COMMON_FIELDS)
    }
    if family == TEMPLATE_FAMILY_XY:
        payload = {
            key: deepcopy(settings_data[key])
            for key in sorted(_TEMPLATE_XY_CHART_FIELDS)
        }
        xy_style = _xy_style_from_payload(data[XY_STYLE_TEMPLATE_KEY])
        if xy_style is not None:
            payload[XY_STYLE_TEMPLATE_KEY] = xy_style_template_data(xy_style)
    else:
        payload = {
            key: deepcopy(settings_data[key])
            for key in sorted(_TEMPLATE_GROUPS_FIELDS)
        }
    document[STYLE_TEMPLATE_VARIANTS_KEY][family] = payload
    return document


def _template_document_from_file(path: Path) -> dict:
    data = _read_template_json(path)
    if _is_v2_template(data):
        return _template_document_from_v2(data)
    return _template_document_from_legacy(data)


def _write_template_document(path: Path, document: dict) -> None:
    validated = _template_document_from_v2(document)
    path.write_text(
        json.dumps(validated, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def write_style_template(
    name: str,
    settings: ChartSettings,
    template_dir: Path = TEMPLATE_DIR,
    *,
    xy_settings: XYSettings | XYStyleTemplate | None = None,
    family: str | None = None,
) -> Path:
    template_dir.mkdir(parents=True, exist_ok=True)
    path = template_dir / template_file_name(name)
    selected_family = _write_family(family, xy_settings)
    if path.exists():
        document = _template_document_from_file(path)
    else:
        document = _empty_template_document()

    settings_data = style_template_settings_data(settings)
    document[STYLE_TEMPLATE_COMMON_KEY] = {
        key: deepcopy(settings_data[key])
        for key in sorted(_TEMPLATE_COMMON_FIELDS)
    }
    if selected_family == TEMPLATE_FAMILY_XY:
        if xy_settings is None:
            raise ValueError("xy_settings is required for an XY style template.")
        payload = {
            key: deepcopy(settings_data[key])
            for key in sorted(_TEMPLATE_XY_CHART_FIELDS)
        }
        payload[XY_STYLE_TEMPLATE_KEY] = xy_style_template_data(xy_settings)
    else:
        payload = {
            key: deepcopy(settings_data[key])
            for key in sorted(_TEMPLATE_GROUPS_FIELDS)
        }
    document[STYLE_TEMPLATE_VARIANTS_KEY][selected_family] = payload
    _write_template_document(path, document)
    return path


def read_style_template(
    name: str,
    template_dir: Path = TEMPLATE_DIR,
    *,
    family: str | None = None,
) -> ChartSettings:
    path = template_dir / template_file_name(name)
    return read_style_template_file(path, family=family)


def read_style_template_file(
    path: Path,
    *,
    family: str | None = None,
) -> ChartSettings:
    raw = _read_template_json(path)
    if not _is_v2_template(raw):
        legacy_family = _legacy_template_family(raw)
        _require_available_family(family, {legacy_family})
        return _legacy_chart_settings(raw)
    document = _template_document_from_v2(raw)
    selected_family = _read_family(
        family,
        set(document[STYLE_TEMPLATE_VARIANTS_KEY]),
    )
    return _settings_from_template_document(document, selected_family)


def style_template_families(
    name: str,
    template_dir: Path = TEMPLATE_DIR,
) -> set[str]:
    return style_template_families_file(template_dir / template_file_name(name))


def style_template_families_file(path: Path) -> set[str]:
    raw = _read_template_json(path)
    if not _is_v2_template(raw):
        return {_legacy_template_family(raw)}
    document = _template_document_from_v2(raw)
    return set(document[STYLE_TEMPLATE_VARIANTS_KEY])


def _legacy_chart_settings(data: dict) -> ChartSettings:
    settings_data = dict(data)
    settings_data.pop(XY_STYLE_TEMPLATE_KEY, None)
    defaults = asdict(ChartSettings())
    for key in STYLE_TEMPLATE_CONTENT_FIELDS:
        settings_data[key] = deepcopy(defaults[key])
    settings_data["custom_colors"] = template_indexed_group_colors(
        settings_data.get("custom_colors", {})
    )
    return chart_settings_from_dict(settings_data)


def read_xy_style_template(
    name: str,
    template_dir: Path = TEMPLATE_DIR,
    *,
    family: str | None = None,
) -> XYStyleTemplate | None:
    return read_xy_style_template_file(
        template_dir / template_file_name(name),
        family=family,
    )


def read_xy_style_template_file(
    path: Path,
    *,
    family: str | None = None,
) -> XYStyleTemplate | None:
    raw = _read_template_json(path)
    if _is_v2_template(raw):
        document = _template_document_from_v2(raw)
        variants = document[STYLE_TEMPLATE_VARIANTS_KEY]
        if family is not None:
            selected_family = _read_family(family, set(variants))
            if selected_family != TEMPLATE_FAMILY_XY:
                return None
        xy_payload = variants.get(TEMPLATE_FAMILY_XY)
        payload = None if xy_payload is None else xy_payload.get(XY_STYLE_TEMPLATE_KEY)
    else:
        legacy_family = _legacy_template_family(raw)
        if family is not None:
            selected_family = _read_family(family, {legacy_family})
            if selected_family != TEMPLATE_FAMILY_XY:
                return None
        payload = raw.get(XY_STYLE_TEMPLATE_KEY)
    return _xy_style_from_payload(payload)


def _xy_style_from_payload(payload: object) -> XYStyleTemplate | None:
    if payload is None:
        return None
    if not isinstance(payload, dict):
        raise ValueError("XY style template must be a JSON object.")
    valid_fields = {field.name for field in fields(XYStyleTemplate)}
    unknown = sorted(str(key) for key in payload if key not in valid_fields)
    if unknown:
        raise ValueError("Unknown XY style fields: " + ", ".join(unknown))
    return XYStyleTemplate(**payload)


def import_style_template(
    path: Path,
    template_dir: Path = TEMPLATE_DIR,
    *,
    family: str | None = None,
) -> tuple[str, ChartSettings]:
    raw = _read_template_json(path)
    source = (
        _template_document_from_v2(raw)
        if _is_v2_template(raw)
        else _template_document_from_legacy(raw)
    )
    source_families = set(source[STYLE_TEMPLATE_VARIANTS_KEY])
    requested_family = None
    if family is not None:
        requested_family = _validated_family(family)
    selected_family = (
        requested_family
        if requested_family in source_families
        else _read_family(None, source_families)
    )
    settings = (
        _settings_from_template_document(source, selected_family)
        if _is_v2_template(raw)
        else _legacy_chart_settings(raw)
    )

    template_dir.mkdir(parents=True, exist_ok=True)
    imported_path = template_dir / template_file_name(path.stem)
    if imported_path.exists() and imported_path.resolve() != path.resolve():
        destination = _template_document_from_file(imported_path)
        destination[STYLE_TEMPLATE_COMMON_KEY] = deepcopy(
            source[STYLE_TEMPLATE_COMMON_KEY]
        )
        destination[STYLE_TEMPLATE_VARIANTS_KEY].update(
            deepcopy(source[STYLE_TEMPLATE_VARIANTS_KEY])
        )
        source = destination
    _write_template_document(imported_path, source)
    return imported_path.stem, settings


def list_style_templates(
    template_dir: Path = TEMPLATE_DIR,
    *,
    family: str | None = None,
) -> list[str]:
    if not template_dir.exists():
        return []
    selected_family = None if family is None else _validated_family(family)
    names: list[str] = []
    for path in template_dir.glob("*.json"):
        if (
            not path.is_file()
            or path.stem.casefold() == TEMPLATE_NONE_NAME.casefold()
        ):
            continue
        if selected_family is not None:
            try:
                families = style_template_families_file(path)
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            if selected_family not in families:
                continue
        names.append(path.stem)
    return sorted(names)
