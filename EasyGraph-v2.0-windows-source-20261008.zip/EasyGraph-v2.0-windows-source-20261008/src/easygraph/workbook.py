from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
import re
from uuid import uuid4

import pandas as pd

from easygraph.analysis_results import AnalysisSettings
from easygraph.grouping import GroupingSettings, normalize_grouping
from easygraph.settings import ChartSettings
from easygraph.xy_series import XYSettings


DEFAULT_SHEET_NAME_PREFIX = "Sheet"
INVALID_SHEET_NAME_CHARACTERS = frozenset("[]:*?/\\")
MAX_SHEET_NAME_LENGTH = 31
SHEET_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")
SHEET_MODE_GROUPS = "groups"
SHEET_MODE_XY = "xy"
SHEET_MODES = frozenset({SHEET_MODE_GROUPS, SHEET_MODE_XY})


def new_sheet_id() -> str:
    return uuid4().hex


def new_column_id() -> str:
    return uuid4().hex


def normalized_sheet_mode(mode: object) -> str:
    normalized = str(mode).strip().lower()
    if normalized not in SHEET_MODES:
        raise ValueError(f"Unsupported sheet mode: {mode}")
    return normalized


def normalized_sheet_name(name: object) -> str:
    return str(name).strip()


def sheet_name_error(name: object, existing_names: list[str] | tuple[str, ...] = ()) -> str | None:
    normalized = normalized_sheet_name(name)
    if not normalized:
        return "Sheet name cannot be empty."
    if len(normalized) > MAX_SHEET_NAME_LENGTH:
        return f"Sheet name cannot be longer than {MAX_SHEET_NAME_LENGTH} characters."
    invalid = sorted(character for character in set(normalized) if character in INVALID_SHEET_NAME_CHARACTERS)
    if invalid:
        return "Sheet name cannot contain: " + " ".join(invalid)
    if normalized.startswith("'") or normalized.endswith("'"):
        return "Sheet name cannot begin or end with an apostrophe."
    existing = {str(value).casefold() for value in existing_names}
    if normalized.casefold() in existing:
        return "Sheet names must be unique."
    return None


def unique_sheet_name(
    existing_names: list[str] | tuple[str, ...],
    preferred: str | None = None,
) -> str:
    existing = {str(name).casefold() for name in existing_names}
    base = normalized_sheet_name(preferred or DEFAULT_SHEET_NAME_PREFIX)
    if not base:
        base = DEFAULT_SHEET_NAME_PREFIX
    base = "".join("_" if character in INVALID_SHEET_NAME_CHARACTERS else character for character in base)
    base = base.strip("'")[:MAX_SHEET_NAME_LENGTH] or DEFAULT_SHEET_NAME_PREFIX
    if base.casefold() not in existing:
        return base

    suffix_index = 2
    while True:
        suffix = f" ({suffix_index})"
        candidate = f"{base[: MAX_SHEET_NAME_LENGTH - len(suffix)]}{suffix}"
        if candidate.casefold() not in existing:
            return candidate
        suffix_index += 1


def next_default_sheet_name(existing_names: list[str] | tuple[str, ...]) -> str:
    existing = {str(name).casefold() for name in existing_names}
    index = 1
    while f"{DEFAULT_SHEET_NAME_PREFIX} {index}".casefold() in existing:
        index += 1
    return f"{DEFAULT_SHEET_NAME_PREFIX} {index}"


@dataclass
class SheetDocument:
    name: str
    dataframe: pd.DataFrame
    settings: ChartSettings = field(default_factory=ChartSettings)
    id: str = field(default_factory=new_sheet_id)
    analysis_settings: AnalysisSettings = field(default_factory=AnalysisSettings)
    mode: str = SHEET_MODE_GROUPS
    column_ids: list[str] = field(default_factory=list)
    xy_settings: XYSettings = field(default_factory=XYSettings)
    grouping: GroupingSettings = field(default_factory=GroupingSettings)

    def __post_init__(self) -> None:
        self.mode = normalized_sheet_mode(self.mode)
        if not self.column_ids:
            self.column_ids = [new_column_id() for _ in self.dataframe.columns]
        if len(self.column_ids) != len(self.dataframe.columns):
            raise ValueError("Column IDs must match the DataFrame column count.")
        if len(set(self.column_ids)) != len(self.column_ids):
            raise ValueError("Column IDs must be unique.")
        if any(
            not isinstance(column_id, str) or not SHEET_ID_PATTERN.fullmatch(column_id)
            for column_id in self.column_ids
        ):
            raise ValueError("Column IDs may contain only letters, numbers, underscores, and hyphens.")

        normalize_grouping(self.grouping, self.column_ids)

    def clone(self, *, name: str | None = None) -> SheetDocument:
        return SheetDocument(
            id=new_sheet_id(),
            name=self.name if name is None else name,
            dataframe=self.dataframe.copy(deep=True),
            settings=deepcopy(self.settings),
            analysis_settings=deepcopy(self.analysis_settings),
            mode=self.mode,
            column_ids=list(self.column_ids),
            xy_settings=deepcopy(self.xy_settings),
            grouping=deepcopy(self.grouping),
        )


@dataclass
class WorkbookDocument:
    sheets: list[SheetDocument]
    active_sheet_id: str | None = None

    def __post_init__(self) -> None:
        if not self.sheets:
            raise ValueError("A workbook must contain at least one sheet.")
        ids = [sheet.id for sheet in self.sheets]
        if any(not isinstance(sheet_id, str) or not SHEET_ID_PATTERN.fullmatch(sheet_id) for sheet_id in ids):
            raise ValueError("Sheet IDs may contain only letters, numbers, underscores, and hyphens.")
        if len(set(ids)) != len(ids):
            raise ValueError("Sheet IDs must be unique.")
        names = [sheet.name.casefold() for sheet in self.sheets]
        if len(set(names)) != len(names):
            raise ValueError("Sheet names must be unique.")
        if self.active_sheet_id not in ids:
            self.active_sheet_id = ids[0]

    @classmethod
    def single(
        cls,
        dataframe: pd.DataFrame,
        settings: ChartSettings | None = None,
        *,
        name: str = "Sheet 1",
        mode: str = SHEET_MODE_GROUPS,
        column_ids: list[str] | None = None,
        xy_settings: XYSettings | None = None,
        grouping: GroupingSettings | None = None,
    ) -> WorkbookDocument:
        sheet = SheetDocument(
            name=name,
            dataframe=dataframe.copy(deep=True),
            settings=settings or ChartSettings(),
            mode=mode,
            column_ids=list(column_ids) if column_ids is not None else [],
            xy_settings=xy_settings or XYSettings(),
            grouping=grouping or GroupingSettings(),
        )
        return cls([sheet], sheet.id)

    @property
    def active_sheet(self) -> SheetDocument:
        return self.sheet_by_id(self.active_sheet_id)

    @property
    def active_index(self) -> int:
        return self.index_of(self.active_sheet_id)

    def sheet_by_id(self, sheet_id: str | None) -> SheetDocument:
        for sheet in self.sheets:
            if sheet.id == sheet_id:
                return sheet
        raise KeyError(f"Unknown sheet ID: {sheet_id}")

    def index_of(self, sheet_id: str | None) -> int:
        for index, sheet in enumerate(self.sheets):
            if sheet.id == sheet_id:
                return index
        raise KeyError(f"Unknown sheet ID: {sheet_id}")

    def set_active_index(self, index: int) -> SheetDocument:
        if not 0 <= index < len(self.sheets):
            raise IndexError(index)
        self.active_sheet_id = self.sheets[index].id
        return self.sheets[index]

    def append_sheet(self, sheet: SheetDocument, *, activate: bool = True) -> int:
        if any(existing.id == sheet.id for existing in self.sheets):
            raise ValueError("Sheet IDs must be unique.")
        if any(existing.name.casefold() == sheet.name.casefold() for existing in self.sheets):
            raise ValueError("Sheet names must be unique.")
        self.sheets.append(sheet)
        if activate:
            self.active_sheet_id = sheet.id
        return len(self.sheets) - 1

    def move_sheet(self, source: int, destination: int) -> None:
        if source == destination:
            return
        if not 0 <= source < len(self.sheets) or not 0 <= destination < len(self.sheets):
            raise IndexError((source, destination))
        sheet = self.sheets.pop(source)
        self.sheets.insert(destination, sheet)

    def remove_sheet(self, index: int) -> SheetDocument:
        if len(self.sheets) <= 1:
            raise ValueError("A workbook must contain at least one sheet.")
        removed = self.sheets.pop(index)
        if removed.id == self.active_sheet_id:
            replacement_index = min(index, len(self.sheets) - 1)
            self.active_sheet_id = self.sheets[replacement_index].id
        return removed


__all__ = [
    "DEFAULT_SHEET_NAME_PREFIX",
    "INVALID_SHEET_NAME_CHARACTERS",
    "MAX_SHEET_NAME_LENGTH",
    "SHEET_MODE_GROUPS",
    "SHEET_MODE_XY",
    "SHEET_MODES",
    "SheetDocument",
    "WorkbookDocument",
    "new_column_id",
    "new_sheet_id",
    "next_default_sheet_name",
    "normalized_sheet_mode",
    "normalized_sheet_name",
    "sheet_name_error",
    "unique_sheet_name",
]
