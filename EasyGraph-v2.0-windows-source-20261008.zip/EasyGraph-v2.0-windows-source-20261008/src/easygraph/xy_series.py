from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4

import numpy as np
import pandas as pd

from easygraph.numeric import coerce_numeric_series
from easygraph.xy_fitting import FitParameterSpec, XYFitSpec


MAPPING_MODE_EMPTY = "empty"
MAPPING_MODE_SHARED = "shared"
MAPPING_MODE_PAIRED = "paired"
MAPPING_MODE_MIXED = "mixed"
XY_FIT_ANNOTATION_MODES = frozenset({"equation", "parameters"})


def new_series_id() -> str:
    return uuid4().hex


@dataclass
class XYSeriesSpec:
    id: str
    name: str
    y_column_id: str
    x_column_id: str | None = None
    visible: bool = True
    show_points: bool | None = None
    show_line: bool | None = None
    color: str | None = None
    marker: str | None = None
    line_style: str | None = None
    point_size: float | None = None
    point_alpha: float | None = None
    line_width: float | None = None


@dataclass
class XYSharedTableSpec:
    id: str
    name: str
    x_column_id: str
    series_ids: list[str] = field(default_factory=list)


@dataclass
class XYSettings:
    chart_type: str = "Scatter"
    default_x_column_id: str | None = None
    series: list[XYSeriesSpec] = field(default_factory=list)
    show_points: bool = True
    show_line: bool = True
    point_size: float = 4.0
    point_alpha: float = 0.75
    marker: str = "Circle"
    line_width: float = 1.6
    line_style: str = "Solid"
    shared_tables: list[XYSharedTableSpec] = field(default_factory=list)
    paired_series_ids: list[str] = field(default_factory=list)
    active_shared_table_id: str | None = None
    fit_specs: list[XYFitSpec] = field(default_factory=list)
    fit_annotation_mode: str = "equation"

    def __post_init__(self) -> None:
        if self.fit_annotation_mode not in XY_FIT_ANNOTATION_MODES:
            raise ValueError(
                "XY fit annotation mode must be 'equation' or 'parameters'."
            )
        if not self.show_points and not self.show_line:
            raise ValueError("Points and lines cannot both be hidden.")
        for series in self.series:
            resolved_series_display(self, series)
        series_ids = {series.id for series in self.series}
        if not isinstance(self.fit_specs, list):
            raise ValueError("XY fit specifications must be a list.")
        fit_ids: set[str] = set()
        fitted_series_ids: set[str] = set()
        for fit_spec in self.fit_specs:
            if not isinstance(fit_spec, XYFitSpec):
                raise ValueError("XY fit specifications must be XYFitSpec objects.")
            if not isinstance(fit_spec.id, str) or not fit_spec.id:
                raise ValueError("XY fit IDs must be non-empty strings.")
            if fit_spec.id in fit_ids:
                raise ValueError("XY fit IDs must be unique.")
            fit_ids.add(fit_spec.id)
            if not isinstance(fit_spec.series_id, str) or not fit_spec.series_id:
                raise ValueError("XY fit series IDs must be non-empty strings.")
            if fit_spec.series_id in fitted_series_ids:
                raise ValueError(
                    f"Only one XY fit is allowed per series: {fit_spec.series_id}"
                )
            if not isinstance(fit_spec.annotation_parameter_names, list) or any(
                not isinstance(name, str) or not name
                for name in fit_spec.annotation_parameter_names
            ):
                raise ValueError(
                    "XY fit annotation parameter names must be non-empty strings."
                )
            if len(set(fit_spec.annotation_parameter_names)) != len(
                fit_spec.annotation_parameter_names
            ):
                raise ValueError(
                    "XY fit annotation parameter names must be unique."
                )
            fitted_series_ids.add(fit_spec.series_id)
            if fit_spec.series_id not in series_ids:
                raise ValueError(
                    f"XY fit references missing series: {fit_spec.series_id}"
                )
            if not isinstance(fit_spec.parameters, list):
                raise ValueError("XY fit parameters must be a list.")
            if any(
                not isinstance(parameter, FitParameterSpec)
                for parameter in fit_spec.parameters
            ):
                raise ValueError(
                    "XY fit parameters must be FitParameterSpec objects."
                )
            parameter_names = [parameter.name for parameter in fit_spec.parameters]
            if any(
                not isinstance(parameter_name, str) or not parameter_name
                for parameter_name in parameter_names
            ):
                raise ValueError(
                    "XY fit parameter names must be non-empty strings."
                )
            if len(set(parameter_names)) != len(parameter_names):
                raise ValueError(
                    f"XY fit parameter names must be unique: {fit_spec.id}"
                )


@dataclass(frozen=True)
class XYColumnHeader:
    label: str
    matched_y_labels: tuple[str, ...] = ()


def resolved_x_column_id(settings: XYSettings, series: XYSeriesSpec) -> str | None:
    return series.x_column_id or settings.default_x_column_id


def resolved_series_display(
    settings: XYSettings,
    series: XYSeriesSpec,
) -> tuple[bool, bool]:
    show_points = settings.show_points if series.show_points is None else series.show_points
    show_line = settings.show_line if series.show_line is None else series.show_line
    if series.visible and not show_points and not show_line:
        raise ValueError("Points and lines cannot both be hidden for a visible series.")
    return bool(show_points), bool(show_line)


def resolved_series_point_size(
    settings: XYSettings,
    series: XYSeriesSpec,
) -> float:
    return float(
        settings.point_size if series.point_size is None else series.point_size
    )


def resolved_series_point_alpha(
    settings: XYSettings,
    series: XYSeriesSpec,
) -> float:
    return float(
        settings.point_alpha if series.point_alpha is None else series.point_alpha
    )


def resolved_series_line_width(
    settings: XYSettings,
    series: XYSeriesSpec,
) -> float:
    return float(
        settings.line_width if series.line_width is None else series.line_width
    )


def xy_mapping_mode(settings: XYSettings) -> str:
    if not settings.series:
        return MAPPING_MODE_EMPTY
    resolved_x = [resolved_x_column_id(settings, series) for series in settings.series]
    if any(column_id is None for column_id in resolved_x):
        return MAPPING_MODE_MIXED
    if len(set(resolved_x)) == 1:
        return MAPPING_MODE_SHARED
    if settings.default_x_column_id is not None:
        return MAPPING_MODE_MIXED
    if len(set(resolved_x)) == len(resolved_x):
        return MAPPING_MODE_PAIRED
    return MAPPING_MODE_MIXED


def xy_column_roles(
    settings: XYSettings,
    column_ids: list[str] | tuple[str, ...],
) -> tuple[str, ...]:
    roles = {column_id: set() for column_id in column_ids}
    if settings.default_x_column_id in roles:
        roles[settings.default_x_column_id].add("X")
    for series in settings.series:
        x_column_id = resolved_x_column_id(settings, series)
        if x_column_id in roles:
            roles[x_column_id].add("X")
        if series.y_column_id in roles:
            roles[series.y_column_id].add("Y")
    return tuple(
        "/".join(role for role in ("X", "Y") if role in roles[column_id])
        for column_id in column_ids
    )


def xy_column_headers(
    settings: XYSettings,
    column_ids: list[str] | tuple[str, ...],
) -> tuple[XYColumnHeader, ...]:
    """Describe each physical column using stable, one-based series numbers."""
    x_series_by_column = {column_id: [] for column_id in column_ids}
    y_series_by_column = {column_id: [] for column_id in column_ids}
    for series_number, series in enumerate(settings.series, start=1):
        x_column_id = resolved_x_column_id(settings, series)
        if x_column_id in x_series_by_column:
            x_series_by_column[x_column_id].append(series_number)
        if series.y_column_id in y_series_by_column:
            y_series_by_column[series.y_column_id].append(series_number)

    headers = []
    series_count = len(settings.series)
    for column_number, column_id in enumerate(column_ids, start=1):
        x_series = x_series_by_column[column_id]
        y_series = y_series_by_column[column_id]
        is_default_x = column_id == settings.default_x_column_id
        is_only_shared_x = (
            settings.default_x_column_id is None
            and series_count > 1
            and len(x_series) == series_count
        )
        if is_default_x or is_only_shared_x:
            x_label = "X"
        else:
            x_label = "/".join(f"{number}X" for number in x_series)
        y_label = "/".join(f"{number}Y" for number in y_series)
        label = "/".join(part for part in (x_label, y_label) if part)
        headers.append(
            XYColumnHeader(
                label=label or str(column_number),
                matched_y_labels=tuple(f"{number}Y" for number in x_series),
            )
        )
    return tuple(headers)


def _series_by_id(settings: XYSettings) -> dict[str, XYSeriesSpec]:
    return {series.id: series for series in settings.series}


def shared_table_column_ids(
    settings: XYSettings,
    table: XYSharedTableSpec,
) -> tuple[str, ...]:
    series_by_id = _series_by_id(settings)
    return (
        table.x_column_id,
        *(
            series_by_id[series_id].y_column_id
            for series_id in table.series_ids
            if series_id in series_by_id
        ),
    )


def paired_xy_column_ids(settings: XYSettings) -> tuple[str, ...]:
    series_by_id = _series_by_id(settings)
    columns = []
    for series_id in settings.paired_series_ids:
        series = series_by_id.get(series_id)
        if series is None:
            continue
        x_column_id = resolved_x_column_id(settings, series)
        if x_column_id is not None:
            columns.extend((x_column_id, series.y_column_id))
    return tuple(columns)


def ensure_xy_table_layout(
    settings: XYSettings,
    column_ids: list[str] | tuple[str, ...],
) -> None:
    """Validate a table layout or derive one from a legacy free-form mapping."""
    valid_columns = set(column_ids)
    series_by_id = _series_by_id(settings)
    if len(series_by_id) != len(settings.series):
        raise ValueError("XY series IDs must be unique.")

    assigned: set[str] = set()
    table_ids: set[str] = set()
    for table in settings.shared_tables:
        if table.id in table_ids:
            raise ValueError("XY shared table IDs must be unique.")
        table_ids.add(table.id)
        if table.x_column_id not in valid_columns:
            raise ValueError(f"XY shared table references missing X column: {table.x_column_id}")
        for series_id in table.series_ids:
            if series_id not in series_by_id:
                raise ValueError(f"XY shared table references missing series: {series_id}")
            if series_id in assigned:
                raise ValueError("A series cannot belong to more than one XY table section.")
            assigned.add(series_id)

    for series_id in settings.paired_series_ids:
        if series_id not in series_by_id:
            raise ValueError(f"Independent XY table references missing series: {series_id}")
        if series_id in assigned:
            raise ValueError("A series cannot belong to more than one XY table section.")
        assigned.add(series_id)

    unassigned = [series for series in settings.series if series.id not in assigned]
    grouped: dict[str, list[XYSeriesSpec]] = {}
    unresolved: list[XYSeriesSpec] = []
    for series in unassigned:
        x_column_id = resolved_x_column_id(settings, series)
        if x_column_id is None or x_column_id not in valid_columns:
            unresolved.append(series)
            continue
        grouped.setdefault(x_column_id, []).append(series)

    for x_column_id, series_group in grouped.items():
        use_shared_table = (
            x_column_id == settings.default_x_column_id
            or len(series_group) > 1
        )
        if use_shared_table:
            table = XYSharedTableSpec(
                id=new_series_id(),
                name=f"Sheet{len(settings.shared_tables) + 1}",
                x_column_id=x_column_id,
                series_ids=[series.id for series in series_group],
            )
            settings.shared_tables.append(table)
        else:
            settings.paired_series_ids.append(series_group[0].id)

    settings.paired_series_ids.extend(series.id for series in unresolved)
    if settings.active_shared_table_id not in {
        table.id for table in settings.shared_tables
    }:
        settings.active_shared_table_id = (
            settings.shared_tables[0].id if settings.shared_tables else None
        )


def reorder_series_for_table_layout(settings: XYSettings) -> None:
    series_by_id = _series_by_id(settings)
    ordered_ids = [
        series_id
        for table in settings.shared_tables
        for series_id in table.series_ids
    ]
    ordered_ids.extend(settings.paired_series_ids)
    ordered_ids.extend(
        series.id for series in settings.series if series.id not in ordered_ids
    )
    settings.series = [
        series_by_id[series_id]
        for series_id in ordered_ids
        if series_id in series_by_id
    ]


def remove_xy_column_references(
    settings: XYSettings,
    removed_column_ids: set[str] | frozenset[str],
) -> tuple[str, ...]:
    removed = set(removed_column_ids)
    default_x_removed = settings.default_x_column_id in removed
    removed_series_ids = []
    for series in settings.series:
        affected = (
            series.y_column_id in removed
            or series.x_column_id in removed
            or (series.x_column_id is None and default_x_removed)
        )
        if affected:
            removed_series_ids.append(series.id)
    remove_xy_series(settings, set(removed_series_ids))
    if default_x_removed:
        settings.default_x_column_id = None
    settings.shared_tables = [
        table
        for table in settings.shared_tables
        if table.x_column_id not in removed
    ]
    if settings.active_shared_table_id not in {
        table.id for table in settings.shared_tables
    }:
        settings.active_shared_table_id = (
            settings.shared_tables[0].id if settings.shared_tables else None
        )
    return tuple(removed_series_ids)


def remove_xy_series(
    settings: XYSettings,
    removed_series_ids: set[str] | frozenset[str],
) -> tuple[str, ...]:
    """Remove XY series and every table or fit reference that belongs to them."""
    removed = set(removed_series_ids)
    removed_in_order = tuple(
        series.id for series in settings.series if series.id in removed
    )
    settings.series = [
        series for series in settings.series if series.id not in removed
    ]
    settings.shared_tables = [
        XYSharedTableSpec(
            id=table.id,
            name=table.name,
            x_column_id=table.x_column_id,
            series_ids=[
                series_id for series_id in table.series_ids
                if series_id not in removed
            ],
        )
        for table in settings.shared_tables
    ]
    settings.paired_series_ids = [
        series_id for series_id in settings.paired_series_ids
        if series_id not in removed
    ]
    settings.fit_specs = [
        fit_spec
        for fit_spec in settings.fit_specs
        if fit_spec.series_id not in removed
    ]
    return removed_in_order


def _column_name_by_id(
    column_ids: list[str] | tuple[str, ...],
    column_names: list[object] | tuple[object, ...],
) -> dict[str, str]:
    if len(column_ids) != len(column_names):
        raise ValueError("Column IDs and names must have the same length.")
    if len(set(column_ids)) != len(column_ids):
        raise ValueError("Column IDs must be unique.")
    return {column_id: str(name) for column_id, name in zip(column_ids, column_names)}


def shared_x_series(
    column_ids: list[str] | tuple[str, ...],
    column_names: list[object] | tuple[object, ...],
    *,
    x_column_id: str | None = None,
    y_column_ids: list[str] | tuple[str, ...] | None = None,
) -> XYSettings:
    names = _column_name_by_id(column_ids, column_names)
    if not column_ids:
        return XYSettings()
    resolved_x = x_column_id or column_ids[0]
    if resolved_x not in names:
        raise ValueError(f"Unknown X column ID: {resolved_x}")
    resolved_y = (
        list(y_column_ids)
        if y_column_ids is not None
        else [column_id for column_id in column_ids if column_id != resolved_x]
    )
    unknown = [column_id for column_id in resolved_y if column_id not in names]
    if unknown:
        raise ValueError(f"Unknown Y column ID: {unknown[0]}")
    series = [
        XYSeriesSpec(
            id=new_series_id(),
            name=names[column_id],
            y_column_id=column_id,
        )
        for column_id in resolved_y
    ]
    table_id = new_series_id()
    return XYSettings(
        default_x_column_id=resolved_x,
        series=series,
        shared_tables=[
            XYSharedTableSpec(
                id=table_id,
                name="Sheet1",
                x_column_id=resolved_x,
                series_ids=[item.id for item in series],
            )
        ],
        active_shared_table_id=table_id,
    )


@dataclass(frozen=True)
class AdjacentXYResult:
    settings: XYSettings
    unused_column_ids: tuple[str, ...] = ()


def adjacent_xy_series(
    column_ids: list[str] | tuple[str, ...],
    column_names: list[object] | tuple[object, ...],
) -> AdjacentXYResult:
    names = _column_name_by_id(column_ids, column_names)
    pair_end = len(column_ids) - (len(column_ids) % 2)
    series = [
        XYSeriesSpec(
            id=new_series_id(),
            name=names[column_ids[index + 1]],
            x_column_id=column_ids[index],
            y_column_id=column_ids[index + 1],
        )
        for index in range(0, pair_end, 2)
    ]
    return AdjacentXYResult(
        settings=XYSettings(
            series=series,
            paired_series_ids=[item.id for item in series],
        ),
        unused_column_ids=tuple(column_ids[pair_end:]),
    )


@dataclass(frozen=True)
class PairedNumericValues:
    x: pd.Series
    y: pd.Series
    row_indexes: tuple[object, ...]
    skipped_row_indexes: tuple[object, ...]

    @property
    def valid_count(self) -> int:
        return len(self.row_indexes)

    @property
    def skipped_count(self) -> int:
        return len(self.skipped_row_indexes)


def pairwise_numeric_values(x_values: pd.Series, y_values: pd.Series) -> PairedNumericValues:
    x_source = pd.Series(x_values, copy=False)
    y_source = pd.Series(y_values, copy=False)
    if len(x_source) != len(y_source):
        raise ValueError("X and Y columns must have the same number of rows.")

    row_indexes = tuple(x_source.index)
    numeric_x = coerce_numeric_series(x_source.reset_index(drop=True))
    numeric_y = coerce_numeric_series(y_source.reset_index(drop=True))
    valid = numeric_x.notna() & numeric_y.notna()
    if len(numeric_x):
        valid &= np.isfinite(numeric_x.to_numpy(dtype=float))
        valid &= np.isfinite(numeric_y.to_numpy(dtype=float))

    valid_positions = np.flatnonzero(valid.to_numpy())
    skipped_positions = np.flatnonzero((~valid).to_numpy())
    return PairedNumericValues(
        x=numeric_x.iloc[valid_positions].astype(float).reset_index(drop=True),
        y=numeric_y.iloc[valid_positions].astype(float).reset_index(drop=True),
        row_indexes=tuple(row_indexes[position] for position in valid_positions),
        skipped_row_indexes=tuple(row_indexes[position] for position in skipped_positions),
    )


__all__ = [
    "AdjacentXYResult",
    "MAPPING_MODE_EMPTY",
    "MAPPING_MODE_MIXED",
    "MAPPING_MODE_PAIRED",
    "MAPPING_MODE_SHARED",
    "PairedNumericValues",
    "XYSeriesSpec",
    "XYSharedTableSpec",
    "XYSettings",
    "XYColumnHeader",
    "adjacent_xy_series",
    "ensure_xy_table_layout",
    "new_series_id",
    "pairwise_numeric_values",
    "paired_xy_column_ids",
    "remove_xy_column_references",
    "remove_xy_series",
    "reorder_series_for_table_layout",
    "resolved_series_display",
    "resolved_series_line_width",
    "resolved_series_point_alpha",
    "resolved_series_point_size",
    "resolved_x_column_id",
    "shared_x_series",
    "shared_table_column_ids",
    "xy_column_headers",
    "xy_column_roles",
    "xy_mapping_mode",
]
