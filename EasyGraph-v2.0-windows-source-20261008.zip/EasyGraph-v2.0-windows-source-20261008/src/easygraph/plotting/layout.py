from __future__ import annotations

import math
import re
import unicodedata

from easygraph.settings import ChartSettings, LEGEND_POSITION_INSIDE


__all__ = [
    "AUTO_AXIS_RANGE_PADDING_FRACTION",
    "LEGEND_COLUMN_SPACING",
    "LEGEND_HANDLE_LENGTH",
    "LEGEND_HANDLE_SPACE_UNITS",
    "LEGEND_MAX_COLUMNS",
    "LEGEND_SECONDARY_AXIS_GAP_PX",
    "MAX_MANUAL_TICK_COUNT",
    "OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS",
    "OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO",
    "OVERLAY_CONTENT_MARGIN_RATIO",
    "custom_overlay_secondary_axis_active",
    "horizontal_axis_label_width_overflow_inches",
    "legend_auto_width_enabled",
    "legend_column_count",
    "legend_column_gap_inches",
    "legend_column_width_inches",
    "legend_force_wrap",
    "legend_handle_space_inches",
    "legend_label_text",
    "legend_labels_for_settings",
    "legend_outside_needed",
    "legend_render_width_inches",
    "legend_right_margin_inches",
    "legend_text_width_inches",
    "legend_total_width_inches",
    "legend_unwrapped_item_width_inches",
    "legend_wrap_units",
    "line_count",
    "max_line_count",
    "max_text_width_inches",
    "overlay_axis_label_margin_points",
    "overlay_axis_marker_margin_points",
    "plot_bottom_margin_inches",
    "plot_left_margin_inches",
    "plot_right_margin_inches",
    "plot_top_margin_inches",
    "ridge_category_tick_vertical_overflow_inches",
    "rotated_axis_label_width_inches",
    "rotated_category_tick_side_overflow_inches",
    "rotated_value_axis_label_height_overflow_inches",
    "secondary_axis_split_ratio",
    "split_secondary_frame_enabled",
    "stat_table_gap_inches",
    "stat_table_height_inches",
    "stat_table_row_height_inches",
    "stat_table_row_height_units",
    "text_visual_units",
    "wrap_visual_units",
]


OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS = 3
OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO = 0.5
OVERLAY_CONTENT_MARGIN_RATIO = 0.10
AUTO_AXIS_RANGE_PADDING_FRACTION = 0.10
LEGEND_MAX_COLUMNS = 6
LEGEND_COLUMN_SPACING = 1.0
LEGEND_HANDLE_LENGTH = 3.0
LEGEND_HANDLE_SPACE_UNITS = 3.8
LEGEND_SECONDARY_AXIS_GAP_PX = 8.0
MAX_MANUAL_TICK_COUNT = 1000


def _visible_custom_overlay_indexes(settings: ChartSettings) -> list[int]:
    if not settings.extra_custom_overlay:
        return []
    hidden = {
        int(index)
        for index in settings.custom_overlay_hidden
        if isinstance(index, int) or str(index).lstrip("-").isdigit()
    }
    return [
        index
        for index, series in enumerate(settings.custom_overlay_series or [])
        if index not in hidden and isinstance(series, dict)
    ]


def _stat_table_header_enabled(settings: ChartSettings) -> bool:
    return settings.show_stat_header or (settings.chart_type == "Ridge" and settings.show_stat_table)


def _normalize_overlay_label_position(position: str, chart_type: str, is_custom_overlay: bool = False) -> str:
    point_positions = {"Auto", "Above", "Below", "Left", "Right"}
    if is_custom_overlay:
        return position if position in point_positions else "Auto"
    axis_positions = {"Axis left", "Axis right"} if chart_type == "Ridge" else {"Top axis", "Bottom axis"}
    valid_positions = point_positions | axis_positions
    if position in valid_positions:
        return position
    if chart_type == "Ridge" and position == "Top axis":
        return "Axis right"
    if chart_type == "Ridge" and position == "Bottom axis":
        return "Axis left"
    if chart_type != "Ridge" and position == "Axis right":
        return "Top axis"
    if chart_type != "Ridge" and position == "Axis left":
        return "Bottom axis"
    return "Auto"


def custom_overlay_secondary_axis_active(settings: ChartSettings) -> bool:
    return bool(
        settings.custom_overlay_secondary_axis
        and settings.extra_custom_overlay
        and _visible_custom_overlay_indexes(settings)
    )


def split_secondary_frame_enabled(settings: ChartSettings) -> bool:
    return bool(custom_overlay_secondary_axis_active(settings) and settings.split_secondary_axis)


def secondary_axis_split_ratio(settings: ChartSettings) -> float:
    return max(0.15, min(float(settings.secondary_axis_split_ratio), 0.85))


def legend_wrap_units(settings: ChartSettings, columns: int = 1) -> float:
    width_in = legend_text_width_inches(settings, columns)
    return max(4.0, width_in * 72.0 / (max(settings.legend_font_size, 1) * 0.52))


def legend_text_width_inches(settings: ChartSettings, columns: int = 1) -> float:
    column_width_in = legend_column_width_inches(settings, columns)
    return max(0.20, column_width_in - legend_handle_space_inches(settings))


def legend_total_width_inches(settings: ChartSettings) -> float:
    return max(settings.legend_width, 0.5) / 2.54


def legend_auto_width_enabled(settings: ChartSettings) -> bool:
    return bool(settings.legend_columns > 0 and settings.legend_auto_width)


def legend_handle_space_inches(settings: ChartSettings) -> float:
    return max(settings.legend_font_size, 1) * LEGEND_HANDLE_SPACE_UNITS / 72.0


def legend_column_gap_inches(settings: ChartSettings) -> float:
    return max(settings.legend_font_size, 1) * LEGEND_COLUMN_SPACING / 72.0


def legend_column_width_inches(settings: ChartSettings, columns: int) -> float:
    columns = max(1, columns)
    available_width = legend_total_width_inches(settings) - legend_column_gap_inches(settings) * (columns - 1)
    return max(0.25, available_width / columns)


def legend_label_text(
    label: object,
    settings: ChartSettings,
    columns: int = 1,
    force_wrap: bool = False,
) -> str:
    text = str(label).replace("\\n", "\n")
    if legend_auto_width_enabled(settings):
        return text
    if settings.legend_columns <= 0 and not force_wrap:
        return text
    max_units = legend_wrap_units(settings, columns)
    wrapped_lines = []
    for line in text.splitlines() or [""]:
        wrapped_lines.extend(wrap_visual_units(line, max_units) or [""])
    return "\n".join(wrapped_lines)


def legend_column_count(labels: list[str], settings: ChartSettings) -> int:
    item_count = max(1, len(labels))
    if settings.legend_columns > 0:
        return min(max(1, settings.legend_columns), item_count)

    max_item_width = max(
        (legend_unwrapped_item_width_inches(label, settings) for label in labels),
        default=legend_handle_space_inches(settings),
    )
    column_gap = legend_column_gap_inches(settings)
    total_width = legend_total_width_inches(settings)
    columns_that_fit = math.floor((total_width + column_gap) / max(max_item_width + column_gap, 0.01))
    return min(max(1, columns_that_fit), item_count, LEGEND_MAX_COLUMNS)


def legend_force_wrap(labels: list[str], settings: ChartSettings) -> bool:
    if legend_auto_width_enabled(settings):
        return False
    if settings.legend_columns > 0:
        return True
    max_item_width = max(
        (legend_unwrapped_item_width_inches(label, settings) for label in labels),
        default=legend_handle_space_inches(settings),
    )
    return legend_total_width_inches(settings) < max_item_width


def legend_unwrapped_item_width_inches(label: object, settings: ChartSettings) -> float:
    text = str(label).replace("\\n", "\n")
    lines = text.splitlines() or [""]
    text_width = max_text_width_inches(lines, settings.legend_font_size)
    return text_width + legend_handle_space_inches(settings)


def legend_render_width_inches(labels: list[str], settings: ChartSettings) -> float:
    if not labels:
        return legend_total_width_inches(settings)
    columns = legend_column_count(labels, settings)
    if legend_auto_width_enabled(settings):
        widest_item_width = max(
            (legend_unwrapped_item_width_inches(label, settings) for label in labels),
            default=legend_handle_space_inches(settings),
        )
        return widest_item_width * columns + legend_column_gap_inches(settings) * (columns - 1)
    force_wrap = legend_force_wrap(labels, settings)
    wrapped_labels = [
        legend_label_text(label, settings, columns, force_wrap=force_wrap)
        for label in labels
    ]
    item_widths = [
        legend_unwrapped_item_width_inches(label, settings)
        for label in wrapped_labels
    ]
    if columns <= 1:
        content_width = max(item_widths, default=legend_handle_space_inches(settings))
    else:
        widest_columns = sorted(item_widths, reverse=True)[:columns]
        content_width = sum(widest_columns) + legend_column_gap_inches(settings) * (len(widest_columns) - 1)
    return max(legend_total_width_inches(settings), content_width)


def legend_labels_for_settings(settings: ChartSettings) -> list[str]:
    if not settings.show_legend:
        return []
    labels = []
    if settings.show_outliers and (settings.chart_type != "Ridge" or settings.show_points):
        labels.append("Outlier")
    if settings.line_overlay_stat != "None":
        labels.append(settings.line_overlay_stat)
    if settings.extra_custom_overlay:
        for index in _visible_custom_overlay_indexes(settings):
            name = ""
            if index < len(settings.custom_overlay_series):
                name = str(settings.custom_overlay_series[index].get("name", "")).strip()
            labels.append(name or f"Overlay {index + 1}")
    return labels


def legend_outside_needed(settings: ChartSettings) -> bool:
    if settings.legend_position == LEGEND_POSITION_INSIDE:
        return False
    outlier_legend_needed = settings.show_outliers and (settings.chart_type != "Ridge" or settings.show_points)
    return bool(
        settings.show_legend
        and (
            outlier_legend_needed
            or settings.line_overlay_stat != "None"
            or settings.extra_custom_overlay
        )
    )


def legend_right_margin_inches(settings: ChartSettings) -> float:
    labels = legend_labels_for_settings(settings)
    legend_width_in = legend_render_width_inches(labels, settings) if labels else legend_total_width_inches(settings)
    return max(0.45, legend_width_in) + 0.50


def overlay_axis_marker_margin_points(settings: ChartSettings) -> float:
    marker_areas = []
    if settings.show_points:
        marker_areas.append(settings.point_size * 12)
    if settings.show_outliers:
        marker_areas.append(max(settings.point_size * 18, 45))
    if not marker_areas:
        return 0.0
    return math.sqrt(max(marker_areas)) / 2.0 + 1.0


def overlay_axis_label_margin_points(settings: ChartSettings) -> float:
    label_height_points = max(settings.line_value_font_size, 1) * 1.35
    label_data_pad_points = label_height_points * OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO
    return label_height_points + OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS + label_data_pad_points


def stat_table_row_height_inches(settings: ChartSettings) -> float:
    font_height = max(settings.stat_table_font_size, 1) / 72.0
    return font_height + 0.10


def stat_table_height_inches(groups: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings) -> float:
    return stat_table_row_height_inches(settings) * sum(stat_table_row_height_units(groups, rows, settings))


def stat_table_row_height_units(groups: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings) -> list[float]:
    heights = []
    if _stat_table_header_enabled(settings):
        heights.append(max(1.0, max_line_count(groups) * 0.96))
    heights.extend(1.0 for _ in rows)
    return heights


def stat_table_gap_inches(settings: ChartSettings, groups: list[str], x_axis_label: str) -> float:
    tick_height = max(settings.tick_font_size, 1) / 72.0 * max_line_count(groups) * 1.15
    tick_width = max_text_width_inches(groups, settings.tick_font_size)
    x_tick_rotation = 0 if settings.chart_type == "Ridge" else settings.x_tick_rotation
    rotation = math.radians(abs(x_tick_rotation))
    rotated_tick_height = tick_width * math.sin(rotation) + tick_height * math.cos(rotation)
    label_height = (
        max(settings.axis_label_font_size, 1) / 72.0 * line_count(x_axis_label) * 1.25
        if x_axis_label
        else 0.0
    )
    overlay_height = 0.0
    line_value_position = _normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
    if settings.show_line_overlay and settings.show_line_values and line_value_position == "Bottom axis":
        overlay_height = overlay_axis_label_margin_points(settings) / 72.0
    tick_pad = 0.10 if groups else 0.0
    label_pad = 0.08 if x_axis_label else 0.0
    table_pad = 0.08
    return tick_pad + rotated_tick_height + label_pad + label_height + overlay_height + table_pad


def plot_left_margin_inches(
    settings: ChartSettings,
    groups: list[object],
    y_axis_label: str,
    stat_rows: list[tuple[str, list[str]]],
) -> float:
    left_margin_in = 0.62
    if y_axis_label:
        left_margin_in = max(left_margin_in, rotated_axis_label_width_inches(y_axis_label, settings.axis_label_font_size))
    if settings.chart_type == "Ridge":
        tick_width_in = max_text_width_inches(groups, settings.tick_font_size)
        tick_height_in = (
            max(settings.tick_font_size, 1)
            / 72.0
            * max_line_count([str(group) for group in groups])
            * 1.15
        )
        rotation = math.radians(abs(settings.x_tick_rotation))
        rotated_tick_width_in = (
            tick_width_in * abs(math.cos(rotation))
            + tick_height_in * abs(math.sin(rotation))
        )
        axis_label_in = (
            rotated_axis_label_width_inches(y_axis_label, settings.axis_label_font_size, pad=0.0)
            if y_axis_label
            else 0.0
        )
        left_margin_in = max(
            left_margin_in,
            rotated_tick_width_in + axis_label_in + 0.38,
        )
    if stat_rows and settings.chart_type != "Ridge":
        row_labels = [label for label, _values in stat_rows if label]
        left_margin_in = max(left_margin_in, max_text_width_inches(row_labels, settings.stat_table_font_size) + 0.62)
    if (
        settings.chart_type == "Ridge"
        and settings.show_line_overlay
        and settings.show_line_values
        and _normalize_overlay_label_position(settings.line_value_position, settings.chart_type) == "Axis left"
    ):
        left_margin_in += max(settings.line_value_font_size, 1) * 3.0 / 72.0
    return left_margin_in


def rotated_axis_label_width_inches(text: str, font_size: int, pad: float = 0.30) -> float:
    return max(font_size, 1) / 72.0 * (line_count(text) + 0.9) + pad


def plot_right_margin_inches(settings: ChartSettings) -> float:
    right_margin_in = (
        legend_right_margin_inches(settings)
        if legend_outside_needed(settings) and settings.chart_type != "Ridge"
        else 0.20
    )
    if custom_overlay_secondary_axis_active(settings) and settings.chart_type != "Ridge":
        right_margin_in += max(
            0.62,
            rotated_axis_label_width_inches(settings.secondary_y_label, settings.axis_label_font_size),
        )
    if (
        settings.chart_type == "Ridge"
        and settings.show_line_overlay
        and settings.show_line_values
        and _normalize_overlay_label_position(settings.line_value_position, settings.chart_type) == "Axis right"
    ):
        right_margin_in += max(settings.line_value_font_size, 1) * 3.0 / 72.0
    return right_margin_in


def plot_top_margin_inches(settings: ChartSettings) -> float:
    title_height = max(settings.title_font_size, 1) / 72.0 * line_count(settings.title)
    line_value_position = _normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
    overlay_extra = 0.06 if settings.show_line_overlay and settings.show_line_values and line_value_position == "Top axis" else 0.0
    secondary_label_height = 0.0
    secondary_active = custom_overlay_secondary_axis_active(settings)
    if secondary_active and settings.chart_type == "Ridge":
        secondary_label_height = (
            max(settings.axis_label_font_size, 1) / 72.0 * line_count(settings.secondary_y_label) * 1.25
            if settings.secondary_y_label
            else 0.0
        )
    secondary_tick_height = max(settings.tick_font_size, 1) / 72.0 * 1.15 if secondary_active and settings.chart_type == "Ridge" else 0.0
    return 0.16 + title_height * 1.15 + overlay_extra + secondary_tick_height + secondary_label_height


def plot_bottom_margin_inches(settings: ChartSettings, groups: list[str], x_axis_label: str) -> float:
    tick_height = max(settings.tick_font_size, 1) / 72.0 * max_line_count(groups) * 1.15
    tick_width = max_text_width_inches(groups, settings.tick_font_size)
    x_tick_rotation = 0 if settings.chart_type == "Ridge" else settings.x_tick_rotation
    rotation = math.radians(abs(x_tick_rotation))
    rotated_tick_height = tick_width * math.sin(rotation) + tick_height * math.cos(rotation)
    label_height = (
        max(settings.axis_label_font_size, 1) / 72.0 * line_count(x_axis_label) * 1.25
        if x_axis_label
        else 0.0
    )
    overlay_height = 0.0
    line_value_position = _normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
    if settings.show_line_overlay and settings.show_line_values and line_value_position == "Bottom axis":
        overlay_height = overlay_axis_label_margin_points(settings) / 72.0
    tick_pad = 0.10 if groups else 0.0
    label_pad = 0.08 if x_axis_label else 0.0
    return 0.12 + tick_pad + rotated_tick_height + label_pad + label_height + overlay_height


def rotated_category_tick_side_overflow_inches(
    settings: ChartSettings,
    groups: list[str],
    plot_width_in: float,
    left_margin_in: float,
    right_margin_in: float,
) -> tuple[float, float]:
    if settings.chart_type == "Ridge" or not groups or not settings.x_tick_rotation:
        return (0.0, 0.0)

    rotation = math.radians(abs(settings.x_tick_rotation))
    tick_width_in = max_text_width_inches(groups, settings.tick_font_size)
    tick_height_in = (
        max(settings.tick_font_size, 1) / 72.0
        * max_line_count(groups)
        * 1.15
    )
    horizontal_text_in = tick_width_in * abs(math.cos(rotation))
    horizontal_line_height_in = tick_height_in * abs(math.sin(rotation))
    first_or_last_tick_offset_in = plot_width_in / (2.0 * max(len(groups), 1))
    edge_pad_in = 0.08
    required_left_in = horizontal_text_in + horizontal_line_height_in + edge_pad_in
    required_right_in = horizontal_line_height_in + edge_pad_in
    return (
        max(0.0, required_left_in - left_margin_in - first_or_last_tick_offset_in),
        max(0.0, required_right_in - right_margin_in - first_or_last_tick_offset_in),
    )


def ridge_category_tick_vertical_overflow_inches(
    settings: ChartSettings,
    groups: list[str],
    plot_height_in: float,
) -> tuple[float, float]:
    if (
        settings.chart_type != "Ridge"
        or not groups
        or not settings.x_tick_rotation
    ):
        return (0.0, 0.0)

    rotation = math.radians(abs(settings.x_tick_rotation))
    tick_width_in = max_text_width_inches(groups, settings.tick_font_size)
    tick_height_in = (
        max(settings.tick_font_size, 1)
        / 72.0
        * max_line_count(groups)
        * 1.15
    )
    below_anchor_in = (
        tick_width_in * abs(math.sin(rotation))
        + tick_height_in * abs(math.cos(rotation)) / 2.0
    )
    above_anchor_in = tick_height_in * abs(math.cos(rotation)) / 2.0

    data_span = max(
        len(groups) - 0.35 + max(float(settings.ridge_overlap), 0.0),
        1.0,
    )
    bottom_inside_plot_in = max(float(plot_height_in), 0.0) * 0.4 / data_span
    top_inside_plot_in = (
        max(float(plot_height_in), 0.0)
        * (max(float(settings.ridge_overlap), 0.0) + 0.25)
        / data_span
    )
    edge_pad_in = 0.12
    return (
        max(0.0, below_anchor_in + edge_pad_in - bottom_inside_plot_in),
        max(0.0, above_anchor_in + edge_pad_in - top_inside_plot_in),
    )


def rotated_value_axis_label_height_overflow_inches(
    y_axis_label: str,
    settings: ChartSettings,
    total_height_in: float,
    label_center_in: float,
) -> tuple[float, float]:
    if not y_axis_label:
        return (0.0, 0.0)
    label_height_in = max_text_width_inches([y_axis_label], settings.axis_label_font_size)
    if label_height_in <= 0.0:
        return (0.0, 0.0)
    pad_in = 0.12
    half_label_in = label_height_in / 2.0 + pad_in
    extra_bottom_in = max(0.0, half_label_in - label_center_in)
    extra_top_in = max(0.0, half_label_in - (total_height_in - label_center_in))
    return (extra_bottom_in, extra_top_in)


def horizontal_axis_label_width_overflow_inches(
    x_axis_label: str,
    settings: ChartSettings,
    total_width_in: float,
    label_center_in: float,
) -> tuple[float, float]:
    if not x_axis_label:
        return (0.0, 0.0)
    label_width_in = max_text_width_inches([x_axis_label], settings.axis_label_font_size)
    if label_width_in <= 0.0:
        return (0.0, 0.0)
    pad_in = 0.12
    half_label_in = label_width_in / 2.0 + pad_in
    extra_left_in = max(0.0, half_label_in - label_center_in)
    extra_right_in = max(0.0, half_label_in - (total_width_in - label_center_in))
    return (extra_left_in, extra_right_in)


def line_count(text: object) -> int:
    return max(1, str(text).count("\n") + 1)


def max_line_count(values: list[object]) -> int:
    return max([line_count(value) for value in values] or [1])


def max_text_width_inches(values: list[object], font_size: int) -> float:
    max_units = 0.0
    for value in values:
        for line in str(value).splitlines() or [""]:
            max_units = max(max_units, text_visual_units(line))
    return max_units * max(font_size, 1) * 0.52 / 72.0


def text_visual_units(text: str) -> float:
    return sum(2.0 if unicodedata.east_asian_width(char) in {"F", "W"} else 1.0 for char in text)


def wrap_visual_units(text: str, max_units: float) -> list[str]:
    if text_visual_units(text) <= max_units:
        return [text]
    lines = []
    current = ""
    current_units = 0.0
    for char in text:
        char_units = 2.0 if unicodedata.east_asian_width(char) in {"F", "W"} else 1.0
        if current and current_units + char_units > max_units:
            lines.append(current.rstrip())
            current = char
            current_units = char_units
        else:
            current += char
            current_units += char_units
    if current or not lines:
        lines.append(current.rstrip())
    return lines
