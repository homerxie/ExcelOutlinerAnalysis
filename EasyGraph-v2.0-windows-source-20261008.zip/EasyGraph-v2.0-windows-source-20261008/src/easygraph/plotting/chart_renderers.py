from __future__ import annotations

import math
from collections.abc import Callable
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

from easygraph.data import box_whis, mark_outliers
from easygraph.settings import ChartSettings, PRESETS
if TYPE_CHECKING:
    from easygraph.plotting.group_layout import GroupLayout


__all__ = [
    "beeswarm_offsets",
    "draw_bar",
    "draw_box",
    "draw_points",
    "draw_ridge",
    "draw_violin",
    "jitter_offsets",
    "point_positions",
    "quasirandom_offsets",
    "random_offsets",
    "van_der_corput",
]


ArtistMarker = Callable[[object], None]


def point_positions(df: pd.DataFrame, settings: ChartSettings, layout: GroupLayout | None = None) -> pd.Series:
    order = list(df[settings.group_col].dropna().unique())
    xpos = layout.positions if layout is not None else {group: idx for idx, group in enumerate(order)}
    positions = pd.Series(index=df.index, dtype=float)
    for group in order:
        mask = df[settings.group_col] == group
        values = df.loc[mask, settings.value_col].to_numpy(dtype=float)
        spacing = layout.inner_spacing if layout is not None else 1.0
        offsets = jitter_offsets(values, settings.jitter * spacing, settings.jitter_mode, str(group))
        positions.loc[mask] = xpos[group] + offsets
    return positions


def draw_points(
    ax,
    df: pd.DataFrame,
    settings: ChartSettings,
    palette: list[str],
    preset: dict,
    positions: pd.Series,
    mark_point_artist: ArtistMarker | None = None,
) -> None:
    from easygraph.palette import derived_group_color

    order = list(df[settings.group_col].dropna().unique())
    colors = {group: palette[idx % len(palette)] for idx, group in enumerate(order)}
    for group in order:
        group_df = df[df[settings.group_col] == group]
        color = colors[group]
        points = ax.scatter(
            positions.loc[group_df.index],
            group_df[settings.value_col],
            s=settings.point_size * 12,
            c=derived_group_color(color, "point", preset["background"]),
            alpha=settings.point_alpha,
            edgecolors=derived_group_color(color, "edge", preset["background"]),
            linewidths=0.35,
            zorder=5,
        )
        if mark_point_artist is not None:
            mark_point_artist(points)


def _bar_summary_interval(values: np.ndarray, mode: str) -> tuple[float, float | None, float | None]:
    """Summarize a nonempty, finite column without pooling other columns."""
    center = float(np.median(values) if mode.startswith("Median") else np.mean(values))
    count = len(values)
    if mode.endswith("with range"):
        return center, float(np.min(values)), float(np.max(values))
    if mode == "Median with 95% CI" and count >= 6:
        from scipy.stats import binom

        # Choose observed order statistics whose two omitted binomial tails
        # total at most 5%. Discreteness makes coverage conservative; fewer
        # than six values cannot provide a finite interval with 95% coverage.
        rank = int(binom.ppf(0.025, count, 0.5))
        ordered = np.sort(values)
        return center, float(ordered[rank - 1]), float(ordered[count - rank])
    if mode in {"Mean with SD", "Mean with SEM", "Mean with 95% CI"} and count > 1:
        error = float(np.std(values, ddof=1))
        if mode != "Mean with SD":
            error /= math.sqrt(count)
        if mode == "Mean with 95% CI":
            from scipy.stats import t

            error *= float(t.ppf(0.975, count - 1))
        return center, center - error, center + error
    return center, None, None


def draw_bar(
    ax,
    df: pd.DataFrame,
    settings: ChartSettings,
    palette: list[str],
    mark_plot_content_artist: ArtistMarker | None = None,
    layout: GroupLayout | None = None,
) -> None:
    from easygraph.palette import derived_group_color

    if settings.bar_summary == "No line or error bar":
        return
    preset = PRESETS[settings.preset]
    spacing = layout.inner_spacing if layout is not None else 1.0
    for index, (group, frame) in enumerate(df.groupby(settings.group_col, sort=False)):
        values = frame[settings.value_col].to_numpy(dtype=float)
        values = values[np.isfinite(values)]
        if not len(values):
            continue
        position = layout.positions[str(group)] if layout is not None else index
        color = layout.colors[str(group)] if layout is not None else palette[index % len(palette)]
        edge = derived_group_color(color, "edge", preset["background"])
        center, low, high = _bar_summary_interval(values, settings.bar_summary)
        bars = ax.bar(
            [position], [center], width=settings.bar_width * spacing,
            color=color, edgecolor=edge, linewidth=preset["line_width"],
            alpha=settings.fill_alpha, zorder=2,
        )
        artists = list(bars.patches)
        if low is not None and high is not None:
            errors = ax.errorbar(
                [position], [center], yerr=[[max(0.0, center - low)], [max(0.0, high - center)]],
                fmt="none", ecolor=edge, elinewidth=preset["line_width"],
                capsize=4, capthick=preset["line_width"], zorder=3,
            )
            artists.extend((*errors.lines[1], *errors.lines[2]))
        if mark_plot_content_artist is not None:
            for artist in artists:
                mark_plot_content_artist(artist)


def draw_box(
    ax,
    df: pd.DataFrame,
    settings: ChartSettings,
    palette: list[str],
    mark_plot_content_artist: ArtistMarker | None = None,
    layout: GroupLayout | None = None,
) -> None:
    import seaborn as sns

    existing_lines = set(ax.lines)
    existing_patches = set(ax.patches)
    existing_collections = set(ax.collections)
    sns.boxplot(
        data=df,
        x=settings.group_col,
        y=settings.value_col,
        ax=ax,
        hue=settings.group_col,
        palette=palette,
        legend=False,
        width=settings.box_width * (layout.inner_spacing if layout is not None else 1.0),
        showfliers=False,
        whis=box_whis(settings.box_whisker_mode),
        linewidth=PRESETS[settings.preset]["line_width"],
    )
    for patch in ax.patches:
        patch.set_alpha(settings.fill_alpha)
    if layout is not None:
        _position_categorical_artists(ax, df, settings, layout, existing_lines, existing_patches, existing_collections)
    for artist in [
        *(line for line in ax.lines if line not in existing_lines),
        *(patch for patch in ax.patches if patch not in existing_patches),
        *(collection for collection in ax.collections if collection not in existing_collections),
    ]:
        if mark_plot_content_artist is not None:
            mark_plot_content_artist(artist)


def draw_violin(
    ax,
    df: pd.DataFrame,
    settings: ChartSettings,
    palette: list[str],
    mark_plot_content_artist: ArtistMarker | None = None,
    layout: GroupLayout | None = None,
) -> None:
    import seaborn as sns

    existing_lines = set(ax.lines)
    existing_patches = set(ax.patches)
    existing_collections = set(ax.collections)
    sns.violinplot(
        data=df,
        x=settings.group_col,
        y=settings.value_col,
        ax=ax,
        hue=settings.group_col,
        palette=palette,
        legend=False,
        width=settings.violin_width * (layout.inner_spacing if layout is not None else 1.0),
        inner="quartile",
        cut=0,
        bw_adjust=settings.kde_bandwidth,
        linewidth=PRESETS[settings.preset]["line_width"],
    )
    for collection in ax.collections:
        collection.set_alpha(settings.fill_alpha)
    if layout is not None:
        _position_categorical_artists(ax, df, settings, layout, existing_lines, existing_patches, existing_collections)
    for artist in [
        *(line for line in ax.lines if line not in existing_lines),
        *(patch for patch in ax.patches if patch not in existing_patches),
        *(collection for collection in ax.collections if collection not in existing_collections),
    ]:
        if mark_plot_content_artist is not None:
            mark_plot_content_artist(artist)


def _position_categorical_artists(ax, df, settings, layout, existing_lines, existing_patches, existing_collections):
    """Translate Seaborn's category artists without changing their widths/KDEs."""
    order = list(df[settings.group_col].dropna().unique())

    def shift(xs):
        xs = np.asarray(xs, dtype=float)
        if not len(xs):
            return xs
        center = (float(np.nanmin(xs)) + float(np.nanmax(xs))) / 2
        index = min(len(order) - 1, max(0, round(center)))
        return xs + layout.positions[str(order[index])] - index

    for line in ax.lines:
        if line not in existing_lines:
            line.set_xdata(shift(line.get_xdata()))
    for patch in ax.patches:
        if patch not in existing_patches:
            vertices = patch.get_path().vertices
            vertices[:, 0] = shift(vertices[:, 0])
    for collection in ax.collections:
        if collection not in existing_collections:
            for path in collection.get_paths():
                path.vertices[:, 0] = shift(path.vertices[:, 0])


def draw_ridge(
    ax,
    df: pd.DataFrame,
    point_df: pd.DataFrame,
    settings: ChartSettings,
    palette: list[str],
    text_color: str,
    mark_plot_content_artist: ArtistMarker | None = None,
    mark_point_artist: ArtistMarker | None = None,
    outlier_df: pd.DataFrame | None = None,
    layout: GroupLayout | None = None,
) -> None:
    from scipy.stats import gaussian_kde

    groups = list(df[settings.group_col].dropna().unique())
    values = pd.to_numeric(point_df[settings.value_col], errors="coerce").dropna()
    xmin, xmax = float(values.min()), float(values.max())
    pad = max((xmax - xmin) * 0.08, 1e-3)
    xs = np.linspace(xmin - pad, xmax + pad, 300)
    y_positions = np.array([layout.coordinate(str(group), ridge=True) for group in groups]) if layout is not None else np.arange(len(groups))[::-1]
    max_density = 0.0
    densities = []
    density_groups = {
        group: group_df
        for group, group_df in df.groupby(settings.group_col, sort=False)
    }
    point_groups = {
        group: group_df
        for group, group_df in point_df.groupby(settings.group_col, sort=False)
    }
    if settings.show_points and settings.show_outliers:
        prepared_outliers = outlier_df if outlier_df is not None else mark_outliers(point_df, settings)
        outlier_groups = {
            group: group_df
            for group, group_df in prepared_outliers.groupby(settings.group_col, sort=False)
        }
    else:
        outlier_groups = {}

    for group in groups:
        vals = pd.to_numeric(density_groups[group][settings.value_col], errors="coerce").dropna()
        if len(vals) < 2 or math.isclose(float(vals.std()), 0.0):
            density = np.zeros_like(xs)
        else:
            kde = gaussian_kde(vals, bw_method=settings.kde_bandwidth)
            density = kde(xs)
        max_density = max(max_density, float(density.max()))
        densities.append(density)

    spacing = layout.inner_spacing if layout is not None else 1.0
    ridge_height = settings.ridge_overlap * spacing
    scale = ridge_height / max_density if max_density > 0 else 1.0
    outlier_label_added = False
    for idx, (group, density) in enumerate(zip(groups, densities)):
        y0 = y_positions[idx]
        color = palette[idx % len(palette)]
        y = y0 + density * scale
        ridge_fill = ax.fill_between(xs, y0, y, color=color, alpha=settings.fill_alpha, linewidth=0)
        ridge_line, = ax.plot(xs, y, color=color, linewidth=PRESETS[settings.preset]["line_width"])
        if mark_plot_content_artist is not None:
            mark_plot_content_artist(ridge_fill)
        if mark_plot_content_artist is not None:
            mark_plot_content_artist(ridge_line)
        if settings.show_points:
            group_points = point_groups.get(group, point_df.iloc[0:0])
            vals = pd.to_numeric(group_points[settings.value_col], errors="coerce").dropna()
            offsets = jitter_offsets(vals.to_numpy(dtype=float), settings.jitter * spacing, settings.jitter_mode, str(group))
            points = ax.scatter(
                vals,
                np.full(len(vals), y0) + offsets,
                s=settings.point_size * 8,
                color=color,
                alpha=settings.point_alpha,
                edgecolors="#222222",
                linewidths=0.25,
            )
            if mark_point_artist is not None:
                mark_point_artist(points)
            if settings.show_outliers:
                group_out = outlier_groups.get(group, point_df.iloc[0:0])
                if not group_out.empty:
                    offset_by_index = pd.Series(offsets, index=vals.index)
                    outlier_points = ax.scatter(
                        group_out[settings.value_col],
                        np.full(len(group_out), y0) + offset_by_index.loc[group_out.index],
                        s=max(settings.point_size * 18, 45),
                        facecolors="none",
                        edgecolors="#D62728",
                        linewidths=1.3,
                        zorder=6,
                        label="Outlier" if not outlier_label_added else "_nolegend_",
                    )
                    if mark_point_artist is not None:
                        mark_point_artist(outlier_points)
                    outlier_label_added = True

    ax.set_yticks(y_positions)
    ax.set_yticklabels([layout.labels[str(group)] if layout is not None else str(group) for group in groups], color=text_color, fontsize=settings.tick_font_size)
    ax.tick_params(axis="y", length=0, pad=10)
    category_max = max(layout.positions.values(), default=0) if layout is not None else len(groups) - 1
    ax.set_ylim(-0.4 * spacing, category_max + ridge_height + 0.25 * spacing)
    ax.set_xlim(xmin - pad, xmax + pad)


def jitter_offsets(values: np.ndarray, width: float, mode: str, key: str) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    count = len(values)
    if count == 0 or width <= 0:
        return np.zeros(count)
    if mode == "Random":
        return random_offsets(key, count, width)
    if mode == "Quasirandom":
        return quasirandom_offsets(values, width)
    return beeswarm_offsets(values, width)


def random_offsets(key: str, count: int, width: float) -> np.ndarray:
    seed = 20240527 + sum(ord(ch) for ch in key)
    rng = np.random.default_rng(seed)
    return rng.uniform(-width, width, count)


def beeswarm_offsets(values: np.ndarray, width: float) -> np.ndarray:
    count = len(values)
    offsets = np.zeros(count)
    if count <= 1:
        return offsets

    finite = values[np.isfinite(values)]
    if len(finite) == 0:
        return offsets
    value_span = float(np.max(finite) - np.min(finite))
    bin_width = max(value_span / 24, 1e-9)
    bins = np.floor((values - float(np.min(finite))) / bin_width).astype(int)

    for bin_id in np.unique(bins):
        idx = np.where(bins == bin_id)[0]
        idx = idx[np.argsort(values[idx], kind="mergesort")]
        n = len(idx)
        if n == 1:
            offsets[idx[0]] = 0.0
            continue
        max_level = max(1, math.ceil((n - 1) / 2))
        step = width / max_level
        sequence = [0.0]
        for level in range(1, max_level + 1):
            sequence.extend([-level * step, level * step])
        offsets[idx] = np.array(sequence[:n])
    return np.clip(offsets, -width, width)


def quasirandom_offsets(values: np.ndarray, width: float) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    count = len(values)
    if count <= 1 or width <= 0:
        return np.zeros(count)

    order = np.argsort(values, kind="mergesort")
    base_offsets = np.array([van_der_corput(i + 1) for i in range(count)]) - 0.5
    base_offsets *= 2 * width

    density_scale = np.ones(count, dtype=float)
    finite_mask = np.isfinite(values)
    finite = values[finite_mask]
    if len(finite) > 2 and not math.isclose(float(np.std(finite)), 0.0):
        try:
            if len(finite) <= 2048:
                from scipy.stats import gaussian_kde

                density = gaussian_kde(finite)(finite)
            else:
                density = _binned_quasirandom_density(finite)
            max_density = float(np.max(density)) if len(density) else 0.0
            if max_density > 0:
                density_scale[finite_mask] = 0.25 + 0.75 * density / max_density
        except Exception:
            density_scale = np.ones(count)

    offsets = np.zeros(count)
    offsets[order] = base_offsets * density_scale[order]
    return np.clip(offsets, -width, width)


def _binned_quasirandom_density(values: np.ndarray) -> np.ndarray:
    from scipy.ndimage import gaussian_filter1d

    value_min = float(np.min(values))
    value_max = float(np.max(values))
    if math.isclose(value_min, value_max, rel_tol=0.0, abs_tol=1e-12):
        return np.ones(len(values), dtype=float)

    bin_count = 512
    histogram, edges = np.histogram(values, bins=bin_count, range=(value_min, value_max))
    bin_width = float(edges[1] - edges[0])
    standard_deviation = float(np.std(values, ddof=1))
    bandwidth = standard_deviation * len(values) ** (-0.2)
    sigma = max(bandwidth / max(bin_width, np.finfo(float).eps), 0.5)
    smoothed = gaussian_filter1d(histogram.astype(float), sigma=sigma, mode="constant")
    centers = (edges[:-1] + edges[1:]) * 0.5
    return np.interp(values, centers, smoothed, left=smoothed[0], right=smoothed[-1])


def van_der_corput(index: int, base: int = 2) -> float:
    result = 0.0
    denominator = 1.0
    while index:
        index, remainder = divmod(index, base)
        denominator *= base
        result += remainder / denominator
    return result
