"""One categorical coordinate system for every Groups chart artist."""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from easygraph.grouping import GroupingSettings, ordered_group_blocks
from easygraph.palette import group_color_map_for_groups
from easygraph.settings import ChartSettings


@dataclass(frozen=True)
class ParentSpan:
    key: str
    label: str
    start: float
    end: float

    @property
    def center(self) -> float:
        return (self.start + self.end) / 2


@dataclass(frozen=True)
class GroupLayout:
    order: tuple[str, ...]
    labels: dict[str, str]
    positions: dict[str, float]
    colors: dict[str, str]
    parents: tuple[ParentSpan, ...]
    legend: tuple[tuple[str, str], ...]
    inner_spacing: float = 1.0
    hide_leaf_labels: bool = False

    @property
    def limits(self) -> tuple[float, float]:
        return (-self.inner_spacing / 2, max(self.positions.values(), default=0) + self.inner_spacing / 2)

    def coordinate(self, group: str, *, ridge: bool = False) -> float:
        position = self.positions[str(group)]
        return max(self.positions.values(), default=0) - position if ridge else position

    def reorder(self, frame: pd.DataFrame, group_col: str) -> pd.DataFrame:
        """Keep original sample indices, which are shared with outlier markers."""
        rank = {key: index for index, key in enumerate(self.order)}
        return frame.loc[frame[group_col].map(rank).sort_values(kind="stable").index]


def build_group_layout(
    frame: pd.DataFrame,
    settings: ChartSettings,
    grouping: GroupingSettings | None = None,
    column_ids: list[str] | tuple[str, ...] | None = None,
) -> GroupLayout:
    present = list(dict.fromkeys(str(key) for key in frame[settings.group_col]))
    all_labels = {str(key): str(value) for key, value in frame.attrs.get("group_labels", {}).items()}
    ordered = list(dict.fromkeys(str(key) for key in frame.attrs.get("group_keys", present)))
    grouping_parents = grouping.parents if grouping is not None else []
    if not grouping_parents:
        ordered = [key for key in ordered if key in present]
    labels = {key: all_labels.get(key, key) for key in ordered}
    physical = list(dict.fromkeys(str(key) for key in (column_ids or ordered)))
    physical.extend(key for key in ordered if key not in physical)
    parent_for = {}
    for parent in grouping_parents:
        for column in parent["column_ids"]:
            parent_for.setdefault(str(column), parent)
    manual = settings.group_order == "Manual"
    outer_order = None
    if grouping_parents:
        outer_order = [*settings.manual_group_order, *ordered] if manual else physical
    blocks = ordered_group_blocks(ordered, grouping_parents, outer_order)
    inner = max(0.1, float(getattr(settings, "group_inner_spacing", 1.0))) if grouping_parents else 1.0
    outer = max(inner, float(getattr(settings, "group_outer_spacing", 2.7))) if grouping_parents else inner
    positions: dict[str, float] = {}
    parents: list[ParentSpan] = []
    cursor = 0.0
    for _block_key, members in blocks:
        start = cursor
        for key in members:
            positions[key] = cursor
            cursor += inner
        parent = parent_for.get(members[0])
        if parent is not None:
            parents.append(ParentSpan(str(parent["id"]), str(parent["name"]), start, cursor - inner))
        cursor += outer - inner
    order = tuple(positions)
    base_colors = group_color_map_for_groups(physical, settings)
    color_keys = {key: key for key in physical}
    color_labels = {key: all_labels.get(key, key) for key in physical}
    use_parent = bool(grouping_parents) and getattr(settings, "group_color_mode", "Subgroup") == "Parent"
    shared = bool(grouping_parents) and grouping is not None and grouping.shared_subgroups
    if use_parent:
        for key in physical:
            parent = parent_for.get(key)
            if parent is not None:
                color_keys[key] = str(parent["id"])
                color_labels[color_keys[key]] = str(parent["name"])
    elif shared:
        for key in physical:
            color_keys[key] = grouping.subgroup_ids.get(key, key)
            color_labels[color_keys[key]] = all_labels.get(key, key)
    category_order = list(dict.fromkeys(color_keys.get(key, key) for key in physical if key in color_keys))
    category_colors = group_color_map_for_groups(category_order, settings)
    # A per-column override applies to the complete shared category.
    for key in physical:
        if key in color_keys and key in settings.custom_colors:
            category_colors[color_keys[key]] = base_colors[key]
    colors = {
        key: category_colors[color_keys[key]] if use_parent or shared else base_colors[key]
        for key in order
    }
    visible_categories = {color_keys[key] for key in order}
    legend_order = list(dict.fromkeys(color_keys[key] for key in order)) if manual else category_order
    legend = tuple((color_labels[key], category_colors[key]) for key in legend_order if key in visible_categories) if use_parent or shared else ()
    return GroupLayout(
        order, labels, positions, colors, tuple(parents), legend, inner,
        shared and not use_parent and getattr(settings, "group_label_mode", "Both levels") == "Legend only" and settings.show_legend,
    )
