from __future__ import annotations

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap

from easygraph.settings import ChartSettings, PRESETS


STAT_OVERLAY_ALPHA = 0.78


LINE_OVERLAY_STYLE_TO_MPL = {
    "Solid": "-",
    "Dashed": "--",
    "Dotted": ":",
    "Dash-dot": "-.",
    "Long dash": (0, (10, 3)),
    "Dense dash": (0, (4, 1.5)),
    "Loose dot": (0, (1, 5)),
    "Dash-dot-dot": (0, (7, 2, 1, 2, 1, 2)),
}


LINE_OVERLAY_STYLE_TO_QT = {
    "Solid": Qt.PenStyle.SolidLine,
    "Dashed": Qt.PenStyle.DashLine,
    "Dotted": Qt.PenStyle.DotLine,
    "Dash-dot": Qt.PenStyle.DashDotLine,
    "Long dash": Qt.PenStyle.DashLine,
    "Dense dash": Qt.PenStyle.DashLine,
    "Loose dot": Qt.PenStyle.DotLine,
    "Dash-dot-dot": Qt.PenStyle.DashDotDotLine,
}


LINE_STYLE_ICON_SIZE = QSize(96, 22)


LINE_STYLE_ICON_DEVICE_RATIOS = (1, 2, 3)


LINE_STYLE_POPUP_PREVIEW_WIDTH = 120


LINE_STYLE_POPUP_ROW_HEIGHT = 34


LINE_STYLE_PREVIEW_STROKE_WIDTH = 3.4


LINE_STYLE_PREVIEW_DOT_RADIUS = 2.0


def overlay_label_bbox(settings: ChartSettings) -> dict:
    preset = PRESETS[settings.preset]
    facecolor = "#FFFFFF" if preset["background"] == "#FFFFFF" else "#111827"
    edgecolor = "#D1D5DB" if preset["background"] == "#FFFFFF" else "#4B5563"
    return {
        "boxstyle": "round,pad=0.22",
        "facecolor": facecolor,
        "edgecolor": edgecolor,
        "alpha": 0.86,
        "linewidth": 0.55,
    }


def overlay_label_arrow(color: str) -> dict:
    return {
        "arrowstyle": "-",
        "color": color,
        "alpha": 0.65,
        "linewidth": 0.7,
        "shrinkA": 2,
        "shrinkB": 4,
    }


def overlay_line_style(style: str) -> str | tuple:
    return LINE_OVERLAY_STYLE_TO_MPL.get(style, "-")


def _overlay_coordinates_with_parent_breaks(
    groups: list[str], positions, values: list[float], parents: list[dict],
) -> tuple[list[float], list[float]]:
    """Break the path between outer blocks without adding separate artists.

    Stable column and parent IDs determine membership. Each ungrouped column
    is its own block, even when two columns have the same display name.
    Existing missing values stay in place, so they still break their own line.
    """
    if not parents:
        return list(positions), list(values)
    parent_by_column = {}
    for parent in parents:
        for column_id in parent.get("column_ids", []):
            parent_by_column.setdefault(str(column_id), ("parent", parent["id"]))
    line_positions, line_values = [], []
    previous_block = None
    for group, position, value in zip(groups, positions, values):
        column_id = str(group)
        block = parent_by_column.get(column_id, ("column", column_id))
        if previous_block is not None and block != previous_block:
            line_positions.append(float("nan"))
            line_values.append(float("nan"))
        line_positions.append(position)
        line_values.append(value)
        previous_block = block
    return line_positions, line_values


def overlay_line_qt_pen_style(style: str) -> Qt.PenStyle:
    return LINE_OVERLAY_STYLE_TO_QT.get(style, Qt.PenStyle.SolidLine)


def draw_line_style_preview(painter: QPainter, style: str, color: QColor | str, left: float, right: float, y: float) -> None:
    line_color = QColor(color)
    if not line_color.isValid():
        line_color = QColor("#F9FAFB")
    pen = QPen(line_color)
    pen.setWidthF(LINE_STYLE_PREVIEW_STROKE_WIDTH)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)

    def draw_segment(start: float, end: float) -> None:
        painter.setPen(pen)
        painter.drawLine(start, y, min(end, right), y)

    def draw_dot(center: float) -> None:
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(line_color)
        painter.drawEllipse(
            center - LINE_STYLE_PREVIEW_DOT_RADIUS,
            y - LINE_STYLE_PREVIEW_DOT_RADIUS,
            LINE_STYLE_PREVIEW_DOT_RADIUS * 2,
            LINE_STYLE_PREVIEW_DOT_RADIUS * 2,
        )

    def draw_manual_pattern(pattern: tuple[str, ...]) -> None:
        x = left
        dash_lengths = {
            "dash": 22.0,
            "long_dash": 34.0,
            "dense_dash": 12.0,
        }
        gaps = {
            "dash": 8.0,
            "long_dash": 8.0,
            "dense_dash": 5.0,
            "dot": 8.0,
            "loose_dot": 14.0,
        }
        while x < right:
            for token in pattern:
                if token in dash_lengths:
                    draw_segment(x, x + dash_lengths[token])
                    x += dash_lengths[token] + gaps[token]
                elif token in {"dot", "loose_dot"}:
                    center = x + LINE_STYLE_PREVIEW_DOT_RADIUS
                    if center <= right - LINE_STYLE_PREVIEW_DOT_RADIUS:
                        draw_dot(center)
                    x = center + LINE_STYLE_PREVIEW_DOT_RADIUS + gaps[token]
                if x >= right:
                    break

    if style == "Auto":
        section_width = (right - left) / 3.0
        draw_line_style_preview(painter, "Solid", line_color, left, left + section_width - 6, y)
        draw_line_style_preview(painter, "Dashed", line_color, left + section_width, left + section_width * 2 - 6, y)
        draw_line_style_preview(painter, "Dotted", line_color, left + section_width * 2, right, y)
        return
    if style == "Dotted":
        draw_manual_pattern(("dot",))
        return
    if style == "Dash-dot":
        draw_manual_pattern(("dash", "dot"))
        return
    if style == "Long dash":
        draw_manual_pattern(("long_dash",))
        return
    if style == "Dense dash":
        draw_manual_pattern(("dense_dash",))
        return
    if style == "Loose dot":
        draw_manual_pattern(("loose_dot",))
        return
    if style == "Dash-dot-dot":
        draw_manual_pattern(("dash", "dot", "dot"))
        return

    pen.setStyle(overlay_line_qt_pen_style(style))
    painter.setPen(pen)
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.drawLine(left, y, right, y)


def line_style_icon(style: str, color: QColor | str) -> QIcon:
    icon = QIcon()
    line_color = QColor(color)
    if not line_color.isValid():
        line_color = QColor("#F9FAFB")
    for ratio in LINE_STYLE_ICON_DEVICE_RATIOS:
        pixmap = QPixmap(LINE_STYLE_ICON_SIZE.width() * ratio, LINE_STYLE_ICON_SIZE.height() * ratio)
        pixmap.setDevicePixelRatio(ratio)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            y = LINE_STYLE_ICON_SIZE.height() / 2
            draw_line_style_preview(painter, style, line_color, 10, LINE_STYLE_ICON_SIZE.width() - 10, y)
        finally:
            painter.end()
        icon.addPixmap(pixmap)
    return icon


def overlay_label_position_for_series(settings: ChartSettings, is_custom_overlay: bool) -> str:
    position = settings.custom_line_value_position if is_custom_overlay else settings.line_value_position
    return normalize_overlay_label_position(position, settings.chart_type, is_custom_overlay)


def overlay_auto_avoidance_position(settings: ChartSettings, is_custom_overlay: bool) -> str | None:
    if not is_custom_overlay or settings.line_overlay_stat == "None":
        return None
    stat_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
    if settings.chart_type == "Ridge":
        if stat_position == "Axis left":
            return "Right"
        if stat_position == "Axis right":
            return "Left"
    else:
        if stat_position == "Bottom axis":
            return "Above"
        if stat_position == "Top axis":
            return "Below"
    return None


def normalize_overlay_label_position(position: str, chart_type: str, is_custom_overlay: bool = False) -> str:
    point_positions = {"Auto", "Above", "Below", "Left", "Right"}
    if is_custom_overlay:
        return position if position in point_positions else "Auto"
    axis_positions = {"Axis left", "Axis right"} if chart_type == "Ridge" else {"Top axis", "Bottom axis"}
    valid_positions = point_positions | axis_positions
    if position in valid_positions:
        return position
    if chart_type == "Ridge" and position == "Top axis":
        return "Axis right"
    if chart_type == "Ridge" and position == "Bottom axis":
        return "Axis left"
    if chart_type != "Ridge" and position == "Axis right":
        return "Top axis"
    if chart_type != "Ridge" and position == "Axis left":
        return "Bottom axis"
    return "Auto"


def resolve_overlay_label_position(
    index: int,
    values: list[float],
    position: str,
    is_ridge: bool,
    series_index: int = 0,
    preferred_auto_position: str | None = None,
) -> str:
    point_positions = {"Above", "Below", "Left", "Right"}
    if position != "Auto":
        return position
    if preferred_auto_position in point_positions:
        return preferred_auto_position

    crowded = overlay_values_are_close(index, values)
    if is_ridge:
        prefer_right = (series_index + (1 if crowded and index % 2 else 0)) % 2 == 0
        return "Right" if prefer_right else "Left"
    prefer_above = (series_index + (1 if crowded and index % 2 else 0)) % 2 == 0
    return "Above" if prefer_above else "Below"


def overlay_label_offset(
    index: int,
    values: list[float],
    position: str,
    is_ridge: bool,
    series_index: int = 0,
    marker_size_points: float = 0.0,
) -> tuple[int, int, str, str]:
    position = resolve_overlay_label_position(index, values, position, is_ridge, series_index)

    stagger = max(series_index, 0) * 8
    side_gap = int(max(12, marker_size_points / 2.0 + 6))
    vertical_gap = int(max(13, marker_size_points / 2.0 + 6))

    if position == "Below":
        return (stagger, -vertical_gap, "center", "top")
    if position == "Left":
        return (-side_gap, -stagger, "right", "center")
    if position == "Right":
        return (side_gap, stagger, "left", "center")
    return (stagger, vertical_gap, "center", "bottom")


def overlay_values_are_close(index: int, values: list[float]) -> bool:
    if len(values) < 2:
        return False
    value_range = max(values) - min(values)
    threshold = max(value_range * 0.08, 1e-9)
    value = values[index]
    neighbors = []
    if index > 0:
        neighbors.append(values[index - 1])
    if index + 1 < len(values):
        neighbors.append(values[index + 1])
    return any(abs(value - neighbor) <= threshold for neighbor in neighbors)


__all__ = [
    "LINE_OVERLAY_STYLE_TO_MPL",
    "LINE_OVERLAY_STYLE_TO_QT",
    "LINE_STYLE_ICON_DEVICE_RATIOS",
    "LINE_STYLE_ICON_SIZE",
    "LINE_STYLE_POPUP_PREVIEW_WIDTH",
    "LINE_STYLE_POPUP_ROW_HEIGHT",
    "LINE_STYLE_PREVIEW_DOT_RADIUS",
    "LINE_STYLE_PREVIEW_STROKE_WIDTH",
    "STAT_OVERLAY_ALPHA",
    "draw_line_style_preview",
    "line_style_icon",
    "normalize_overlay_label_position",
    "overlay_auto_avoidance_position",
    "overlay_label_arrow",
    "overlay_label_bbox",
    "overlay_label_offset",
    "overlay_label_position_for_series",
    "overlay_line_qt_pen_style",
    "overlay_line_style",
    "overlay_values_are_close",
    "resolve_overlay_label_position",
]
