from __future__ import annotations

import math
from collections.abc import Iterable
from copy import copy
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from matplotlib.artist import Artist
from matplotlib.lines import Line2D
from matplotlib.markers import TICKDOWN, TICKLEFT, TICKRIGHT, TICKUP
from matplotlib.patches import ConnectionPatch
from matplotlib.ticker import ScalarFormatter
from matplotlib.transforms import Bbox, ScaledTranslation

from easygraph.additional_guides import (
    format_additional_guide_value,
    normalize_additional_guides,
)


__all__ = ["draw_additional_guides"]


def _matching_major_tick_index(value: float, major_values: list[float]) -> int | None:
    finite_values = [item for item in major_values if math.isfinite(item)]
    if not finite_values:
        return None
    span = max(finite_values) - min(finite_values)
    absolute_tolerance = (
        abs(span) * 1e-9 if math.isfinite(span) and span != 0.0 else 0.0
    )
    for index, major_value in enumerate(major_values):
        if math.isfinite(major_value) and math.isclose(
            value,
            major_value,
            rel_tol=0.0,
            abs_tol=absolute_tolerance,
        ):
            return index
    return None


def _finite_tick_values(values: Iterable[object]) -> list[float]:
    result: list[float] = []
    for value in values:
        try:
            numeric = float(value)
        except (TypeError, ValueError, OverflowError):
            continue
        if math.isfinite(numeric):
            result.append(numeric)
    return result


def _value_is_visible(ax, value: float, dimension: str) -> bool:
    limits = ax.get_xlim() if dimension == "x" else ax.get_ylim()
    lower, upper = sorted((float(limits[0]), float(limits[1])))
    span = upper - lower
    tolerance = (
        abs(span) * 1e-12 if math.isfinite(span) and span != 0.0 else 0.0
    )
    return lower - tolerance <= value <= upper + tolerance


def _major_tick_label(axis, index: int, side: str):
    ticks = axis.get_major_ticks(index + 1)
    if index >= len(ticks):
        return None
    label = (
        ticks[index].label1
        if side in {"bottom", "left"}
        else ticks[index].label2
    )
    if not label.get_visible() or not label.get_text():
        return None
    return label


def _major_grid_is_visible(axis, index: int) -> bool:
    ticks = axis.get_major_ticks(index + 1)
    return index < len(ticks) and ticks[index].gridline.get_visible()


def _restyle_major_grid_line(
    axis,
    index: int,
    color: str,
    line_width: float,
) -> Line2D:
    gridline = axis.get_major_ticks(index + 1)[index].gridline
    gridline.set_color(color)
    gridline.set_alpha(0.55)
    gridline.set_linestyle("--")
    gridline.set_linewidth(line_width)
    gridline.set_zorder(1.6)
    gridline.set_gid("additional-grid-line")
    return gridline


def _guide_line(
    ax,
    value: float,
    dimension: str,
    color: str,
    line_width: float,
) -> Line2D:
    if dimension == "x":
        line = Line2D(
            [value, value],
            [0.0, 1.0],
            transform=ax.get_xaxis_transform(),
        )
    else:
        line = Line2D(
            [0.0, 1.0],
            [value, value],
            transform=ax.get_yaxis_transform(),
        )
    line.set_color(color)
    line.set_alpha(0.55)
    line.set_linestyle("--")
    line.set_linewidth(line_width)
    # Axis/grid artists are drawn at about 1.5 while data lines and EasyGraph
    # point artists are 2 or higher. Keep guides above the ordinary grid but
    # below the plotted data.
    line.set_zorder(1.6)
    line.set_clip_on(True)
    line.set_gid("additional-grid-line")
    ax.add_artist(line)
    return line


def _guide_tick(
    ax,
    value: float,
    dimension: str,
    side: str,
    color: str,
    line_width: float,
) -> Line2D:
    if dimension == "x":
        marker = TICKUP if side == "top" else TICKDOWN
        tick = Line2D(
            [value],
            [1.0 if side == "top" else 0.0],
            transform=ax.get_xaxis_transform(),
        )
    else:
        marker = TICKRIGHT if side == "right" else TICKLEFT
        tick = Line2D(
            [1.0 if side == "right" else 0.0],
            [value],
            transform=ax.get_yaxis_transform(),
        )
    tick.set_linestyle("None")
    tick.set_marker(marker)
    tick.set_markersize(4.0)
    tick.set_markeredgewidth(max(0.1, float(line_width)))
    tick.set_color(color)
    tick.set_zorder(3.0)
    tick.set_clip_on(False)
    tick.set_gid("additional-tick")
    ax.add_artist(tick)
    return tick


def _guide_numeric_label(
    ax,
    value: float,
    dimension: str,
    side: str,
    color: str,
    label_text: str | None = None,
) -> Artist:
    axis = ax.xaxis if dimension == "x" else ax.yaxis
    ticks = axis.get_major_ticks(1)
    template = (
        ticks[0].label1
        if side in {"bottom", "left"}
        else ticks[0].label2
    )
    if label_text is None:
        label_text = format_additional_guide_value(value)
    position = (
        (value, 1.0 if side == "top" else 0.0)
        if dimension == "x"
        else (1.0 if side == "right" else 0.0, value)
    )
    label = ax.text(
        *position,
        str(label_text),
        transform=template.get_transform(),
        ha=template.get_horizontalalignment(),
        va=template.get_verticalalignment(),
        fontproperties=template.get_fontproperties().copy(),
        color=color,
        rotation=template.get_rotation(),
        rotation_mode=template.get_rotation_mode(),
        clip_on=False,
        zorder=4.0,
    )
    label.set_gid("additional-tick-value")
    return label


def _axis_formatted_guide_values(axis, values: list[float]) -> list[str]:
    """Format guide numbers like native ticks without mutating the axis."""

    fallback = [format_additional_guide_value(value) for value in values]
    if not values:
        return fallback
    try:
        formatter = copy(axis.get_major_formatter())
        formatter.set_axis(axis)
        major_locations = _finite_tick_values(axis.get_majorticklocs())
        if isinstance(formatter, ScalarFormatter):
            # Keep the live axis' already-selected offset and magnitude. Letting
            # guides participate in set_locs() can choose a different baseline
            # from the offset text that is actually shown on the canvas.
            offset = float(formatter.offset)
            order = int(formatter.orderOfMagnitude)
            if offset == 0.0 and order == 0:
                return fallback
            decimal_offset = Decimal(str(offset))
            decimal_scale = Decimal(10) ** order
            formatted = []
            for value in values:
                scaled = (Decimal(str(value)) - decimal_offset) / decimal_scale
                text = format(scaled, ".12g")
                formatted.append("0" if Decimal(text) == 0 else text)
        else:
            formatter.set_locs(major_locations + values)
            formatted = [
                str(formatter(value, len(major_locations) + index))
                for index, value in enumerate(values)
            ]
    except (
        AttributeError,
        InvalidOperation,
        TypeError,
        ValueError,
        OverflowError,
    ):
        return fallback
    result = [
        text if text.strip() else fallback_text
        for text, fallback_text in zip(formatted, fallback)
    ]
    for index, (value, text) in enumerate(zip(values, result)):
        if any(
            other_value != value and other_text == text
            for other_value, other_text in zip(values, result)
        ):
            result[index] = fallback[index]
    return result


def _padded_bounds(bounds: Bbox, padding: float) -> Bbox:
    return Bbox.from_extents(
        bounds.x0 - padding,
        bounds.y0 - padding,
        bounds.x1 + padding,
        bounds.y1 + padding,
    )


def _overlaps_any(bounds: Bbox, occupied: list[Bbox], padding: float) -> bool:
    padded = _padded_bounds(bounds, padding)
    return any(padded.overlaps(other) for other in occupied)


def _axis_label_obstacle_bounds(
    ax,
    dimension: str,
    side: str,
    renderer,
) -> list[Bbox]:
    axis = ax.xaxis if dimension == "x" else ax.yaxis
    bounds: list[Bbox] = []
    for index, value in enumerate(_finite_tick_values(axis.get_majorticklocs())):
        if not _value_is_visible(ax, value, dimension):
            continue
        label = _major_tick_label(axis, index, side)
        if label is None:
            continue
        label_bounds = label.get_window_extent(renderer)
        if all(math.isfinite(number) for number in label_bounds.extents):
            bounds.append(label_bounds)
    offset_label = axis.get_offset_text()
    try:
        offset_text = str(axis.get_major_formatter().get_offset())
    except (AttributeError, TypeError, ValueError):
        offset_text = offset_label.get_text()
    if offset_text:
        offset_label.set_text(offset_text)
    if offset_label.get_visible() and offset_label.get_text():
        offset_bounds = offset_label.get_window_extent(renderer)
        if all(math.isfinite(number) for number in offset_bounds.extents):
            bounds.append(offset_bounds)
    return bounds


def _existing_additional_label_bounds(
    ax,
    renderer,
    excluded: set[int],
) -> list[Bbox]:
    bounds: list[Bbox] = []
    for artist in ax.get_children():
        if (
            id(artist) in excluded
            or artist.get_gid()
            not in {"additional-tick-label", "additional-tick-value"}
            or not artist.get_visible()
        ):
            continue
        patch = getattr(artist, "get_bbox_patch", lambda: None)()
        if patch is not None:
            # Annotation positions can change after the patch was first
            # measured.  Refresh its transform before treating it as a fixed
            # obstacle; otherwise a stale, still-centered patch can push an
            # unrelated numeric tick into a distant collision lane.
            update_bbox = getattr(artist, "update_bbox_position_size", None)
            if callable(update_bbox):
                update_bbox(renderer)
            label_bounds = patch.get_window_extent(renderer)
        else:
            label_bounds = artist.get_window_extent(renderer)
        if all(math.isfinite(number) for number in label_bounds.extents):
            bounds.append(label_bounds)
    return bounds


def _numeric_label_leader(
    ax,
    label: Artist,
    value: float,
    dimension: str,
    side: str,
    color: str,
    line_width: float,
) -> ConnectionPatch:
    anchor = (
        (value, 1.0 if side == "top" else 0.0)
        if dimension == "x"
        else (1.0 if side == "right" else 0.0, value)
    )
    axis_transform = (
        ax.get_xaxis_transform()
        if dimension == "x"
        else ax.get_yaxis_transform()
    )
    leader = ConnectionPatch(
        xyA=anchor,
        coordsA=axis_transform,
        xyB=label.get_position(),
        coordsB=label.get_transform(),
        arrowstyle="-",
        color=color,
        linewidth=max(0.55, min(0.8, float(line_width) * 0.55)),
        alpha=0.58,
        shrinkA=1.5,
        shrinkB=1.0,
        # Keep the connector behind the Axis composite (major tick labels)
        # and every additional label. Crowded fans then remain readable even
        # where a deeper connector crosses a shallower label's bounding box.
        zorder=1.45,
        clip_on=False,
    )
    leader.set_capstyle("round")
    leader.set_gid("additional-tick-leader")
    ax.add_artist(leader)
    return leader


@dataclass
class _NumericLabelLayoutEntry:
    label: Artist
    value: float
    color: str
    base_transform: object
    base_bounds: Bbox
    anchor: float
    lower: float
    upper: float


def _projected_interval(bounds: Bbox, dimension: str) -> tuple[float, float]:
    if dimension == "x":
        return float(bounds.x0), float(bounds.x1)
    return float(bounds.y0), float(bounds.y1)


def _collision_components(
    entries: list[_NumericLabelLayoutEntry],
    padding: float,
) -> list[list[_NumericLabelLayoutEntry]]:
    """Group labels whose allowed screen-space envelopes can touch."""

    components: list[list[_NumericLabelLayoutEntry]] = []
    current: list[_NumericLabelLayoutEntry] = []
    current_upper = -math.inf
    envelopes = [
        (
            entry.anchor - max(entry.upper - entry.lower, 1.0),
            entry.anchor + max(entry.upper - entry.lower, 1.0),
            entry,
        )
        for entry in entries
    ]
    for envelope_lower, envelope_upper, entry in sorted(
        envelopes,
        key=lambda item: (item[0], item[1]),
    ):
        if current and envelope_lower > current_upper + padding:
            components.append(current)
            current = []
            current_upper = -math.inf
        current.append(entry)
        current_upper = max(current_upper, envelope_upper)
    if current:
        components.append(current)
    return components


def _closest_free_interval(
    *,
    preferred_lower: float,
    minimum_lower: float,
    maximum_lower: float,
    length: float,
    occupied: list[tuple[float, float]],
    padding: float,
    visible_lower: float,
    visible_upper: float,
) -> float | None:
    """Place an interval near its preferred position inside anchor limits."""

    def clamp(value: float) -> float:
        return min(max(value, minimum_lower), maximum_lower)

    candidates = {clamp(preferred_lower), minimum_lower, maximum_lower}
    for lower, upper in occupied:
        candidates.add(clamp(lower - padding - length))
        candidates.add(clamp(upper + padding))

    def candidate_cost(value: float) -> tuple[float, float, float]:
        overflow = max(0.0, visible_lower - value) + max(
            0.0,
            value + length - visible_upper,
        )
        return overflow, abs(value - preferred_lower), value

    for candidate in sorted(candidates, key=candidate_cost):
        candidate_upper = candidate + length
        if all(
            candidate_upper + padding <= lower
            or candidate >= upper + padding
            for lower, upper in occupied
        ):
            return candidate
    return None


def _apply_numeric_label_offset(
    entry: _NumericLabelLayoutEntry,
    *,
    dimension: str,
    side: str,
    along_pixels: float,
    outward_pixels: float,
    pixels_per_point: float,
    dpi_scale_transform,
) -> None:
    if dimension == "x":
        dx_pixels = along_pixels
        dy_pixels = outward_pixels if side == "top" else -outward_pixels
    else:
        dx_pixels = outward_pixels if side == "right" else -outward_pixels
        dy_pixels = along_pixels
    entry.label.set_transform(
        entry.base_transform
        + ScaledTranslation(
            dx_pixels / pixels_per_point / 72.0,
            dy_pixels / pixels_per_point / 72.0,
            dpi_scale_transform,
        )
    )


def _required_outward_clearance(
    label_bounds: Bbox,
    obstacle_bounds: Bbox,
    *,
    dimension: str,
    side: str,
    padding: float,
) -> float:
    if dimension == "x":
        if side == "top":
            return max(0.0, obstacle_bounds.y1 + padding - label_bounds.y0)
        return max(0.0, label_bounds.y1 - obstacle_bounds.y0 + padding)
    if side == "right":
        return max(0.0, obstacle_bounds.x1 + padding - label_bounds.x0)
    return max(0.0, label_bounds.x1 - obstacle_bounds.x0 + padding)


def _separate_numeric_tick_labels(
    ax,
    entries: list[tuple[Artist, float, str]],
    *,
    dimension: str,
    side: str,
    line_width: float,
) -> list[Artist]:
    if not entries:
        return []
    renderer = ax.figure.canvas.get_renderer()
    pixels_per_point = max(float(renderer.points_to_pixels(1.0)), 1e-9)
    padding = float(renderer.points_to_pixels(1.25))
    major_bounds = _axis_label_obstacle_bounds(ax, dimension, side, renderer)
    major_bounds.extend(
        _existing_additional_label_bounds(
            ax,
            renderer,
            {id(label) for label, _value, _color in entries},
        )
    )
    leaders: list[Artist] = []
    axis_transform = (
        ax.get_xaxis_transform()
        if dimension == "x"
        else ax.get_yaxis_transform()
    )
    layout_entries: list[_NumericLabelLayoutEntry] = []
    visible_lower = 0.0
    visible_upper = float(
        ax.figure.bbox.width if dimension == "x" else ax.figure.bbox.height
    )
    for label, value, color in entries:
        bounds = label.get_window_extent(renderer)
        anchor_point = axis_transform.transform(
            (value, 1.0 if side == "top" else 0.0)
            if dimension == "x"
            else (1.0 if side == "right" else 0.0, value)
        )
        lower, upper = _projected_interval(bounds, dimension)
        layout_entries.append(
            _NumericLabelLayoutEntry(
                label=label,
                value=value,
                color=color,
                base_transform=label.get_transform(),
                base_bounds=bounds,
                anchor=float(anchor_point[0] if dimension == "x" else anchor_point[1]),
                lower=lower,
                upper=upper,
            )
        )

    for component in _collision_components(layout_entries, padding):
        has_additional_collision = any(
            _overlaps_any(left.base_bounds, [right.base_bounds], padding)
            for index, left in enumerate(component)
            for right in component[index + 1 :]
        )
        base_major_bounds = [
            bounds
            for bounds in major_bounds
            if any(
                _overlaps_any(entry.base_bounds, [bounds], padding)
                for entry in component
            )
        ]
        if not has_additional_collision and not base_major_bounds:
            continue

        component_lower = min(
            entry.anchor - max(entry.upper - entry.lower, 1.0)
            for entry in component
        )
        component_upper = max(
            entry.anchor + max(entry.upper - entry.lower, 1.0)
            for entry in component
        )
        colliding_major_bounds = []
        for bounds in major_bounds:
            major_lower, major_upper = _projected_interval(bounds, dimension)
            if (
                component_lower < major_upper + padding
                and component_upper > major_lower - padding
            ):
                colliding_major_bounds.append(bounds)
        collides_with_major = bool(colliding_major_bounds)

        cluster_center = (
            min(entry.anchor for entry in component)
            + max(entry.anchor for entry in component)
        ) / 2.0
        first_lane = 0
        lanes: dict[int, list[tuple[float, float]]] = {
            0: sorted(
                _projected_interval(bounds, dimension)
                for bounds in colliding_major_bounds
            )
        }
        placements: list[tuple[_NumericLabelLayoutEntry, int, float]] = []

        # Lay out the two wings first. This lets the outer labels share the
        # closest lane while central values use a second compact lane, instead
        # of producing the long one-label-per-lane staircase of a greedy pass.
        placement_order = sorted(
            component,
            key=lambda entry: (-abs(entry.anchor - cluster_center), entry.anchor),
        )
        for entry in placement_order:
            length = max(entry.upper - entry.lower, 1.0)
            projection_inset = min(0.75, padding * 0.25, length * 0.1)
            anchored_minimum = entry.anchor - length + projection_inset
            anchored_maximum = entry.anchor - projection_inset
            if entry.anchor < cluster_center - 1e-6:
                preferred_lower = anchored_minimum
            elif entry.anchor > cluster_center + 1e-6:
                preferred_lower = anchored_maximum
            else:
                # Keep the central callout nearly centered, with a restrained
                # along-axis nudge so its connector still reads as a leader
                # rather than as an accidental extension of the tick mark.
                preferred_lower = entry.lower + min(length * 0.18, padding * 1.5)

            chosen_lane = first_lane
            chosen_lower = entry.lower
            max_lanes = len(component) + first_lane + 1
            for lane in range(first_lane, max_lanes + 1):
                lane_intervals = lanes.setdefault(lane, [])
                minimum_lower = anchored_minimum
                maximum_lower = anchored_maximum
                if lane == 0 and collides_with_major:
                    # Reuse the free space immediately above/below (Y) or
                    # left/right (X) of a native tick before creating another
                    # outward lane. Keep this detour short so only the nearest
                    # wing labels occupy the native label column.
                    maximum_detour = length * 0.55
                    minimum_lower -= maximum_detour
                    maximum_lower += maximum_detour
                candidate_lower = _closest_free_interval(
                    preferred_lower=preferred_lower,
                    minimum_lower=minimum_lower,
                    maximum_lower=maximum_lower,
                    length=length,
                    occupied=lane_intervals,
                    padding=padding,
                    visible_lower=visible_lower,
                    visible_upper=visible_upper,
                )
                if candidate_lower is None:
                    continue
                chosen_lane = lane
                chosen_lower = candidate_lower
                lane_intervals.append((candidate_lower, candidate_lower + length))
                lane_intervals.sort()
                break

            placements.append((entry, chosen_lane, chosen_lower))

        lane_cross_extents: dict[int, float] = {}
        for entry, lane, _chosen_lower in placements:
            cross_extent = float(
                entry.base_bounds.height
                if dimension == "x"
                else entry.base_bounds.width
            )
            lane_cross_extents[lane] = max(
                lane_cross_extents.get(lane, 0.0),
                cross_extent,
            )

        first_lane_offset = max(
            (
                _required_outward_clearance(
                    entry.base_bounds,
                    bounds,
                    dimension=dimension,
                    side=side,
                    padding=padding,
                )
                for entry in component
                for bounds in colliding_major_bounds
            ),
            default=0.0,
        )
        lane_offsets: dict[int, float] = {}
        previous_lane: int | None = None
        for lane in sorted(lane_cross_extents):
            if lane == 0:
                lane_offsets[lane] = 0.0
            elif previous_lane is None:
                lane_offsets[lane] = first_lane_offset
            elif previous_lane == 0:
                lane_offsets[lane] = max(
                    first_lane_offset,
                    lane_cross_extents[previous_lane] + padding,
                )
            else:
                lane_offsets[lane] = (
                    lane_offsets[previous_lane]
                    + lane_cross_extents[previous_lane]
                    + padding
                )
            previous_lane = lane

        for entry, chosen_lane, chosen_lower in placements:
            along_shift = chosen_lower - entry.lower
            outward_shift = lane_offsets[chosen_lane]
            _apply_numeric_label_offset(
                entry,
                dimension=dimension,
                side=side,
                along_pixels=along_shift,
                outward_pixels=outward_shift,
                pixels_per_point=pixels_per_point,
                dpi_scale_transform=ax.figure.dpi_scale_trans,
            )
            if abs(along_shift) > 0.5 or outward_shift > 0.5:
                leaders.append(
                    _numeric_label_leader(
                        ax,
                        entry.label,
                        entry.value,
                        dimension,
                        side,
                        entry.color,
                        line_width,
                    )
                )
    return leaders


def _guide_text(
    ax,
    value: float,
    text: str,
    dimension: str,
    side: str,
    text_side: str,
    vertical_position: str,
    font_size: int,
    color: str,
    show_label_background: bool,
    label_facecolor: str,
    rotate_vertical: bool = False,
    major_tick_label=None,
) -> Artist:
    align_plot_top = dimension == "x" and vertical_position == "plot_top"
    align_plot_bottom = (
        dimension == "x" and vertical_position == "plot_bottom"
    )
    align_plot_left = dimension == "y" and text_side == "plot_left"
    align_plot_right = dimension == "y" and text_side == "plot_right"
    relative_text_side = {
        "plot_left": "left",
        "plot_right": "right",
    }.get(text_side, text_side)
    relative_vertical_position = {
        "plot_bottom": "below",
        "plot_top": "above",
    }.get(vertical_position, vertical_position)
    if dimension == "x":
        if align_plot_top:
            axis_fraction = 1.0
        elif align_plot_bottom:
            axis_fraction = 0.0
        else:
            axis_fraction = 1.0 if side == "top" else 0.0
        xy = (value, axis_fraction)
        transform = ax.get_xaxis_transform()
    else:
        if align_plot_left:
            axis_fraction = 0.0
        elif align_plot_right:
            axis_fraction = 1.0
        else:
            axis_fraction = 1.0 if side == "right" else 0.0
        xy = (axis_fraction, value)
        transform = ax.get_yaxis_transform()
    multiline_alignment = (
        {
            "above": "left",
            "below": "right",
            "plot_bottom": "left",
            "plot_top": "right",
        }.get(vertical_position, "center")
        if rotate_vertical
        else {
            "left": "right",
            "right": "left",
            "plot_left": "left",
            "plot_right": "right",
        }.get(text_side, "center")
    )
    label = ax.annotate(
        text,
        xy=xy,
        xycoords=transform,
        xytext=(0.0, 0.0),
        textcoords="offset points",
        ha="center",
        va="center",
        multialignment=multiline_alignment,
        fontsize=font_size,
        color=color,
        rotation=90 if rotate_vertical else 0,
        rotation_mode="anchor" if rotate_vertical else "default",
        annotation_clip=False,
        clip_on=False,
        zorder=4.0,
    )
    label.set_gid("additional-tick-label")
    # Keep one identical layout envelope in both states.  Turning the
    # background on must only reveal the patch; it must not move the custom
    # text, its numeric tick, a leader, or the surrounding canvas.  An alpha-0
    # patch reserves the same padding while remaining completely invisible.
    label.set_bbox(
        {
            "boxstyle": "round,pad=0.2",
            "facecolor": label_facecolor,
            "edgecolor": "none",
            "linewidth": 0.0,
            "alpha": 0.75 if show_label_background else 0.0,
        }
    )

    renderer = ax.figure.canvas.get_renderer()
    pixels_per_point = max(float(renderer.points_to_pixels(1.0)), 1e-9)
    anchor_x, anchor_y = (float(number) for number in transform.transform(xy))

    def visual_bounds() -> Bbox:
        # Updating the text extent also refreshes the optional bbox patch's
        # transform, so all placement is based on the final visible rectangle.
        text_bounds = label.get_window_extent(renderer)
        patch = label.get_bbox_patch()
        if patch is None:
            return text_bounds
        label.update_bbox_position_size(renderer)
        return patch.get_window_extent(renderer)

    def move_by_pixels(dx: float = 0.0, dy: float = 0.0) -> None:
        current_x, current_y = label.get_position()
        label.set_position(
            (
                float(current_x) + float(dx) / pixels_per_point,
                float(current_y) + float(dy) / pixels_per_point,
            )
        )

    bounds = visual_bounds()
    gap = float(renderer.points_to_pixels(4.0))
    if align_plot_left:
        horizontal_shift = anchor_x + gap - bounds.x0
    elif align_plot_right:
        horizontal_shift = anchor_x - gap - bounds.x1
    elif relative_text_side == "left":
        horizontal_shift = anchor_x - gap - bounds.x1
    elif relative_text_side == "right":
        horizontal_shift = anchor_x + gap - bounds.x0
    else:
        horizontal_shift = anchor_x - (bounds.x0 + bounds.x1) / 2.0
    if align_plot_top:
        vertical_shift = anchor_y - gap - bounds.y1
    elif align_plot_bottom:
        vertical_shift = anchor_y + gap - bounds.y0
    elif relative_vertical_position == "above":
        vertical_shift = anchor_y + gap - bounds.y0
    elif relative_vertical_position == "below":
        vertical_shift = anchor_y - gap - bounds.y1
    else:
        vertical_shift = anchor_y - (bounds.y0 + bounds.y1) / 2.0
    move_by_pixels(horizontal_shift, vertical_shift)

    # A custom label on the plot side of the axis normally has no contact
    # with its numeric tick label.  Only move it when their final 2-D bounds
    # really overlap; the old x-only test produced large, asymmetric gaps.
    if major_tick_label is not None:
        bounds = visual_bounds()
        major_bounds = major_tick_label.get_window_extent(renderer)
        collision_padding = float(renderer.points_to_pixels(3.0))
        if bounds.overlaps(_padded_bounds(major_bounds, collision_padding)):
            if align_plot_left:
                move_by_pixels(
                    major_bounds.x1 + collision_padding - bounds.x0,
                )
            elif align_plot_right:
                move_by_pixels(
                    major_bounds.x0 - collision_padding - bounds.x1,
                )
            elif align_plot_bottom:
                move_by_pixels(
                    dy=major_bounds.y1 + collision_padding - bounds.y0,
                )
            elif align_plot_top:
                move_by_pixels(
                    dy=major_bounds.y0 - collision_padding - bounds.y1,
                )
            elif relative_text_side == "left":
                move_by_pixels(
                    major_bounds.x0 - collision_padding - bounds.x1,
                )
            elif relative_text_side == "right":
                move_by_pixels(
                    major_bounds.x1 + collision_padding - bounds.x0,
                )
            elif relative_vertical_position == "above":
                move_by_pixels(
                    dy=major_bounds.y1 + collision_padding - bounds.y0,
                )
            elif relative_vertical_position == "below":
                move_by_pixels(
                    dy=major_bounds.y0 - collision_padding - bounds.y1,
                )
            elif dimension == "x":
                if side == "bottom":
                    move_by_pixels(
                        dy=major_bounds.y1 + collision_padding - bounds.y0,
                    )
                else:
                    move_by_pixels(
                        dy=major_bounds.y0 - collision_padding - bounds.y1,
                    )
            elif side == "left":
                move_by_pixels(
                    major_bounds.x1 + collision_padding - bounds.x0,
                )
            else:
                move_by_pixels(
                    major_bounds.x0 - collision_padding - bounds.x1,
                )

    if align_plot_top or align_plot_bottom or align_plot_left or align_plot_right:
        # Plot-edge modes mean the complete visible label stays inside the
        # axes frame.  Clamp the perpendicular direction as well, so a guide
        # near a data limit cannot push its label back outside the plot.  If a
        # label is larger than the available span, center it deterministically
        # rather than shrinking or clipping the user's text.
        bounds = visual_bounds()
        axes_bounds = ax.get_window_extent(renderer)

        def interval_shift(
            lower: float,
            upper: float,
            target_lower: float,
            target_upper: float,
        ) -> float:
            extent = upper - lower
            available = target_upper - target_lower
            if extent > available:
                return (
                    (target_lower + target_upper) / 2.0
                    - (lower + upper) / 2.0
                )
            if lower < target_lower:
                return target_lower - lower
            if upper > target_upper:
                return target_upper - upper
            return 0.0

        move_by_pixels(
            interval_shift(
                bounds.x0,
                bounds.x1,
                axes_bounds.x0 + gap,
                axes_bounds.x1 - gap,
            ),
            interval_shift(
                bounds.y0,
                bounds.y1,
                axes_bounds.y0 + gap,
                axes_bounds.y1 - gap,
            ),
        )
    # Leave the optional patch synchronized with the final annotation offset.
    # Callers may measure it immediately, before the next canvas draw.
    visual_bounds()
    return label


def draw_additional_guides(
    ax,
    guides: object,
    *,
    dimension: str,
    side: str,
    font_size: int,
    text_color: str,
    grid_color: str,
    grid_colors: Iterable[object] | None = None,
    axis_line_width: float = 1.0,
    guide_line_width: float = 1.2,
    label_facecolor: str = "#FFFFFF",
    major_tick_values: Iterable[object] | None = None,
) -> list[Artist]:
    """Draw extra guide artists without modifying the axis locator or limits."""

    if dimension not in {"x", "y"}:
        raise ValueError("Additional-guide dimension must be 'x' or 'y'.")
    valid_sides = {"bottom", "top"} if dimension == "x" else {"left", "right"}
    if side not in valid_sides:
        raise ValueError(f"Additional-guide side {side!r} is invalid for {dimension!r}.")

    normalized_guides = normalize_additional_guides(guides)
    if not normalized_guides:
        return []

    resolved_grid_colors = list(grid_colors or ())
    axis = ax.xaxis if dimension == "x" else ax.yaxis
    # A newly assigned locator (for example a manual interval) has locations
    # before it has formatted Tick labels. Refresh just this axis so collision
    # measurement never requires an expensive full-figure draw.
    axis.get_majorticklabels()
    major_values = _finite_tick_values(
        axis.get_majorticklocs() if major_tick_values is None else major_tick_values
    )
    numeric_values = [
        float(guide["value"])
        for guide in normalized_guides
        if _value_is_visible(ax, float(guide["value"]), dimension)
        and bool(guide["show_tick"])
        and _matching_major_tick_index(float(guide["value"]), major_values) is None
        and (
            not str(guide["text"]).strip()
            or bool(guide["show_value_with_text"])
        )
    ]
    numeric_text_by_value = dict(
        zip(numeric_values, _axis_formatted_guide_values(axis, numeric_values))
    )
    artists: list[Artist] = []
    numeric_entries: list[tuple[Artist, float, str]] = []
    pending_custom_labels: list[
        tuple[float, str, dict, Artist | None, str]
    ] = []
    for guide_index, guide in enumerate(normalized_guides):
        value = float(guide["value"])
        if not _value_is_visible(ax, value, dimension):
            continue
        matching_index = _matching_major_tick_index(value, major_values)
        custom_text = str(guide["text"])
        has_custom_text = bool(custom_text.strip())
        line_color = (
            str(resolved_grid_colors[guide_index])
            if guide_index < len(resolved_grid_colors)
            else grid_color
        )
        guide_text_color = (
            line_color
            if guide.get("text_color_mode") == "match_line"
            else text_color
        )

        if bool(guide["show_line"]):
            if (
                matching_index is not None
                and _major_grid_is_visible(axis, matching_index)
            ):
                line = _restyle_major_grid_line(
                    axis,
                    matching_index,
                    line_color,
                    guide_line_width,
                )
            else:
                line = _guide_line(
                    ax,
                    value,
                    dimension,
                    line_color,
                    guide_line_width,
                )
            guide_indices = list(
                getattr(line, "_easygraph_additional_guide_indices", ())
            )
            if guide_index not in guide_indices:
                guide_indices.append(guide_index)
            line._easygraph_additional_guide_indices = tuple(guide_indices)
            line._easygraph_additional_guide_index = guide_index
            if line not in artists:
                artists.append(line)

        if bool(guide["show_tick"]) and matching_index is None:
            artists.append(
                _guide_tick(
                    ax,
                    value,
                    dimension,
                    side,
                    text_color,
                    axis_line_width,
                )
            )

        numeric_label = (
            _major_tick_label(axis, matching_index, side)
            if matching_index is not None
            else None
        )
        if (
            numeric_label is not None
            and bool(guide["show_tick"])
        ):
            numeric_label.set_color(guide_text_color)
        if (
            bool(guide["show_tick"])
            and matching_index is None
            and (
                not has_custom_text
                or bool(guide["show_value_with_text"])
            )
        ):
            numeric_label = _guide_numeric_label(
                ax,
                value,
                dimension,
                side,
                guide_text_color,
                numeric_text_by_value.get(value),
            )
            artists.append(numeric_label)
            numeric_entries.append((numeric_label, value, guide_text_color))

        if has_custom_text:
            pending_custom_labels.append(
                (
                    value,
                    custom_text,
                    guide,
                    numeric_label if matching_index is not None else None,
                    guide_text_color,
                )
            )
    custom_labels: list[Artist] = []
    for (
        value,
        custom_text,
        guide,
        numeric_label,
        guide_text_color,
    ) in pending_custom_labels:
        custom_labels.append(
            _guide_text(
                ax,
                value,
                custom_text,
                dimension,
                side,
                str(guide["text_side"]),
                str(guide["vertical_position"]),
                int(font_size),
                guide_text_color,
                bool(guide["show_label_background"]),
                label_facecolor,
                dimension == "x",
                numeric_label,
            )
        )
    artists.extend(
        _separate_numeric_tick_labels(
            ax,
            numeric_entries,
            dimension=dimension,
            side=side,
            line_width=axis_line_width,
        )
    )
    artists.extend(custom_labels)
    return artists
