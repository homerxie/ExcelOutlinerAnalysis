from __future__ import annotations

from collections.abc import Mapping, Sequence
import math

import numpy as np
from matplotlib.backends.backend_agg import RendererAgg
from matplotlib.colors import is_color_like, to_rgb, to_rgba
from matplotlib.transforms import Bbox

from easygraph.plotting.xy_renderer import line_style_for
from easygraph.xy_data import PreparedXYData
from easygraph.xy_fit_equation import (
    format_fitted_equation_for_curve,
    format_fitted_parameters,
)
from easygraph.xy_series import XYSettings


_EQUATION_LABEL_GID = "xy-fit-equation"
_LABEL_MINIMUM_FONT_SIZE = 7.0
_LABEL_FALLBACK_FONT_SIZE = 6.0
_LABEL_AXES_PADDING_POINTS = 3.0
_LABEL_COLLISION_PADDING_POINTS = 2.25
_LABEL_OFFSET_POINTS = 7.0
_MAX_LABEL_ANCHORS = 3
_MAX_FALLBACK_SLOTS = 40
_MAX_RAIL_ATTEMPTS_PER_LABEL = 8
_MAX_OVERLAP_ATTEMPTS = 4


def _fit_color(fit_spec, series, color_index: int, colors: Sequence[str]) -> str:
    requested_color = fit_spec.color or series.spec.color
    return (
        requested_color
        if requested_color and is_color_like(requested_color)
        else colors[color_index % len(colors)]
    )


def _relative_luminance(color: object) -> float:
    red, green, blue = to_rgb(color)

    def linear(channel: float) -> float:
        return channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4

    return 0.2126 * linear(red) + 0.7152 * linear(green) + 0.0722 * linear(blue)


def _contrast_ratio(first: object, second: object) -> float:
    first_luminance = _relative_luminance(first)
    second_luminance = _relative_luminance(second)
    lighter = max(first_luminance, second_luminance)
    darker = min(first_luminance, second_luminance)
    return (lighter + 0.05) / (darker + 0.05)


def _equation_text_color(
    fit_color: str,
    text_color: object,
    background_color: object,
) -> object:
    try:
        if _contrast_ratio(fit_color, background_color) >= 4.5:
            return fit_color
    except (TypeError, ValueError):
        pass
    try:
        if is_color_like(text_color) and _contrast_ratio(
            text_color,
            background_color,
        ) >= 4.5:
            return text_color
        fallback_colors = ("#222222", "#F9FAFB", "#000000", "#FFFFFF")
        for candidate in fallback_colors:
            if _contrast_ratio(candidate, background_color) >= 4.5:
                return candidate
        return max(
            fallback_colors,
            key=lambda candidate: _contrast_ratio(candidate, background_color),
        )
    except (TypeError, ValueError):
        return "#222222"


def _resolved_renderer(ax, renderer):
    if renderer is not None:
        return renderer
    canvas = getattr(ax.figure, "canvas", None)
    get_renderer = getattr(canvas, "get_renderer", None)
    if callable(get_renderer):
        try:
            return get_renderer()
        except (AttributeError, RuntimeError):
            pass
    width = max(1, int(math.ceil(float(ax.figure.bbox.width))))
    height = max(1, int(math.ceil(float(ax.figure.bbox.height))))
    return RendererAgg(width, height, float(ax.figure.dpi))


def _inset_bbox(bounds: Bbox, padding: float) -> Bbox | None:
    if bounds.width <= padding * 2.0 or bounds.height <= padding * 2.0:
        return None
    return Bbox.from_extents(
        bounds.x0 + padding,
        bounds.y0 + padding,
        bounds.x1 - padding,
        bounds.y1 - padding,
    )


def _padded_bbox(bounds: Bbox, padding: float) -> Bbox:
    return Bbox.from_extents(
        bounds.x0 - padding,
        bounds.y0 - padding,
        bounds.x1 + padding,
        bounds.y1 + padding,
    )


def _point_padding(renderer, points: float) -> float:
    return float(renderer.points_to_pixels(points))


def _bbox_is_inside(inner: Bbox, outer: Bbox) -> bool:
    return bool(
        np.isfinite(inner.extents).all()
        and inner.x0 >= outer.x0
        and inner.y0 >= outer.y0
        and inner.x1 <= outer.x1
        and inner.y1 <= outer.y1
    )


def _clip_display_segment(
    first: np.ndarray,
    second: np.ndarray,
    bounds: Bbox,
) -> tuple[np.ndarray, np.ndarray] | None:
    """Clip one display-space segment to a rectangular viewport."""

    delta = second - first
    lower = 0.0
    upper = 1.0
    for direction, distance in (
        (-delta[0], first[0] - bounds.x0),
        (delta[0], bounds.x1 - first[0]),
        (-delta[1], first[1] - bounds.y0),
        (delta[1], bounds.y1 - first[1]),
    ):
        if math.isclose(float(direction), 0.0, abs_tol=1e-12):
            if distance < 0.0:
                return None
            continue
        ratio = float(distance / direction)
        if direction < 0.0:
            if ratio > upper:
                return None
            lower = max(lower, ratio)
        else:
            if ratio < lower:
                return None
            upper = min(upper, ratio)
    if lower > upper:
        return None
    return first + lower * delta, first + upper * delta


def _append_display_point(points: list[np.ndarray], point: np.ndarray) -> None:
    if not points or float(np.linalg.norm(points[-1] - point)) > 1e-7:
        points.append(point)


def _visible_display_polylines(
    ax,
    curve_x: np.ndarray,
    curve_y: np.ndarray,
    axes_bounds: Bbox,
) -> list[np.ndarray]:
    """Return viewport-clipped polylines without ever bridging non-finite gaps."""

    finite = np.isfinite(curve_x) & np.isfinite(curve_y)
    if not np.any(finite):
        return []
    with np.errstate(all="ignore"):
        display = np.asarray(
            ax.transData.transform(np.column_stack((curve_x, curve_y))),
            dtype=float,
        )
    finite &= np.isfinite(display).all(axis=1)
    runs: list[np.ndarray] = []
    start = 0
    while start < finite.size:
        while start < finite.size and not finite[start]:
            start += 1
        end = start
        while end < finite.size and finite[end]:
            end += 1
        if end <= start:
            continue
        run = display[start:end]
        if len(run) == 1:
            point = run[0]
            if axes_bounds.contains(float(point[0]), float(point[1])):
                runs.append(run.copy())
            start = end
            continue
        current: list[np.ndarray] = []
        for index in range(len(run) - 1):
            clipped = _clip_display_segment(run[index], run[index + 1], axes_bounds)
            if clipped is None:
                if current:
                    runs.append(np.asarray(current, dtype=float))
                    current = []
                continue
            clipped_first, clipped_second = clipped
            if current and float(np.linalg.norm(current[-1] - clipped_first)) > 1e-6:
                runs.append(np.asarray(current, dtype=float))
                current = []
            _append_display_point(current, clipped_first)
            _append_display_point(current, clipped_second)
        if current:
            runs.append(np.asarray(current, dtype=float))
        start = end
    return runs


def _polyline_length(polyline: np.ndarray) -> float:
    if len(polyline) < 2:
        return 0.0
    return float(np.linalg.norm(np.diff(polyline, axis=0), axis=1).sum())


def _point_along_polyline(polyline: np.ndarray, fraction: float) -> np.ndarray:
    if len(polyline) == 1:
        return polyline[0]
    segment_lengths = np.linalg.norm(np.diff(polyline, axis=0), axis=1)
    total = float(segment_lengths.sum())
    if not math.isfinite(total) or total <= 1e-9:
        return polyline[len(polyline) // 2]
    target = min(max(float(fraction), 0.0), 1.0) * total
    cumulative = np.cumsum(segment_lengths)
    segment_index = min(int(np.searchsorted(cumulative, target, side="right")), len(segment_lengths) - 1)
    preceding = 0.0 if segment_index == 0 else float(cumulative[segment_index - 1])
    segment_length = float(segment_lengths[segment_index])
    local = 0.0 if segment_length <= 1e-12 else (target - preceding) / segment_length
    return polyline[segment_index] + local * (
        polyline[segment_index + 1] - polyline[segment_index]
    )


def _candidate_display_anchors(polylines: Sequence[np.ndarray]) -> list[np.ndarray]:
    preferred_fractions = (0.68, 0.36, 0.82)
    ordered = sorted(polylines, key=_polyline_length, reverse=True)
    anchors = [
        _point_along_polyline(polyline, fraction)
        for polyline in ordered
        for fraction in preferred_fractions
    ]
    return anchors[:_MAX_LABEL_ANCHORS]


def _manual_equation_position(fit_spec) -> np.ndarray | None:
    values = (
        getattr(fit_spec, "equation_position_x", None),
        getattr(fit_spec, "equation_position_y", None),
    )
    if any(value is None for value in values):
        return None
    try:
        position = np.asarray([float(value) for value in values], dtype=float)
    except (TypeError, ValueError, OverflowError):
        return None
    if not np.isfinite(position).all():
        return None
    return np.clip(position, 0.0, 1.0)


def _nearest_display_anchor(
    polylines: Sequence[np.ndarray],
    target: np.ndarray,
) -> np.ndarray:
    """Return the visible curve point nearest a label in display space."""

    best_point = np.asarray(polylines[0][0], dtype=float)
    best_distance = math.inf
    for polyline in polylines:
        if len(polyline) == 1:
            candidates = (np.asarray(polyline[0], dtype=float),)
        else:
            starts = np.asarray(polyline[:-1], dtype=float)
            deltas = np.asarray(polyline[1:] - polyline[:-1], dtype=float)
            squared_lengths = np.einsum("ij,ij->i", deltas, deltas)
            offsets = np.asarray(target, dtype=float) - starts
            fractions = np.divide(
                np.einsum("ij,ij->i", offsets, deltas),
                squared_lengths,
                out=np.zeros_like(squared_lengths),
                where=squared_lengths > 1e-18,
            )
            fractions = np.clip(fractions, 0.0, 1.0)
            candidates = starts + fractions[:, None] * deltas
        for candidate in candidates:
            distance = float(np.dot(candidate - target, candidate - target))
            if distance < best_distance:
                best_distance = distance
                best_point = np.asarray(candidate, dtype=float)
    return best_point


def _label_bounds(annotation, renderer) -> Bbox:
    annotation.update_positions(renderer)
    annotation.update_bbox_position_size(renderer)
    background = annotation.get_bbox_patch()
    if background is not None:
        background_bounds = background.get_window_extent(renderer)
        if np.isfinite(background_bounds.extents).all():
            return background_bounds
    return annotation.get_window_extent(renderer)


def _clamp_manual_annotation(
    annotation,
    ax,
    renderer,
    axes_bounds: Bbox,
) -> tuple[np.ndarray, Bbox] | None:
    """Keep a centered manual label fully inside the plotting viewport."""

    try:
        label_bounds = _label_bounds(annotation, renderer)
    except (ArithmeticError, RuntimeError, TypeError, ValueError):
        return None
    if (
        not np.isfinite(label_bounds.extents).all()
        or label_bounds.width > axes_bounds.width
        or label_bounds.height > axes_bounds.height
    ):
        return None
    shift_x = 0.0
    shift_y = 0.0
    if label_bounds.x0 < axes_bounds.x0:
        shift_x = axes_bounds.x0 - label_bounds.x0
    elif label_bounds.x1 > axes_bounds.x1:
        shift_x = axes_bounds.x1 - label_bounds.x1
    if label_bounds.y0 < axes_bounds.y0:
        shift_y = axes_bounds.y0 - label_bounds.y0
    elif label_bounds.y1 > axes_bounds.y1:
        shift_y = axes_bounds.y1 - label_bounds.y1
    current_display = np.asarray(
        ax.transAxes.transform(annotation.xyann),
        dtype=float,
    )
    adjusted_fraction = np.asarray(
        ax.transAxes.inverted().transform(
            current_display + np.asarray((shift_x, shift_y), dtype=float)
        ),
        dtype=float,
    )
    adjusted_fraction = np.clip(adjusted_fraction, 0.0, 1.0)
    annotation.xyann = (
        float(adjusted_fraction[0]),
        float(adjusted_fraction[1]),
    )
    annotation._easygraph_text_axes_fraction = tuple(
        float(value) for value in adjusted_fraction
    )
    try:
        label_bounds = _label_bounds(annotation, renderer)
    except (ArithmeticError, RuntimeError, TypeError, ValueError):
        return None
    if not _bbox_is_inside(label_bounds, axes_bounds):
        return None
    return adjusted_fraction, label_bounds


def _legend_regions(ax, renderer) -> list[Bbox]:
    legend = ax.get_legend()
    if legend is None or not legend.get_visible():
        return []
    frame = legend.get_frame()
    bounds = (
        frame.get_window_extent(renderer)
        if frame is not None and frame.get_visible()
        else legend.get_window_extent(renderer)
    )
    if not np.isfinite(bounds.extents).all():
        return []
    return [
        _padded_bbox(
            bounds,
            _point_padding(renderer, _LABEL_COLLISION_PADDING_POINTS),
        )
    ]


def _occupied_equation_regions(ax, renderer) -> list[Bbox]:
    occupied = _legend_regions(ax, renderer)
    for text in ax.texts:
        if text.get_gid() != _EQUATION_LABEL_GID or not text.get_visible():
            continue
        bounds = _label_bounds(text, renderer)
        if np.isfinite(bounds.extents).all():
            occupied.append(
                _padded_bbox(
                    bounds,
                    _point_padding(renderer, _LABEL_COLLISION_PADDING_POINTS),
                )
            )
    return occupied


def _font_sizes(font_size: object) -> tuple[float, ...]:
    try:
        preferred = float(font_size)
    except (TypeError, ValueError, OverflowError):
        preferred = 9.0
    if not math.isfinite(preferred) or preferred <= 0.0:
        preferred = 9.0
    minimum = min(preferred, _LABEL_MINIMUM_FONT_SIZE)
    candidates = (
        preferred,
        max(minimum, preferred * 0.78),
        minimum,
    )
    result: list[float] = []
    for candidate in candidates:
        if not any(math.isclose(candidate, existing, abs_tol=0.01) for existing in result):
            result.append(candidate)
    return tuple(result)


def _top_level_equation_parts(body: str) -> list[str]:
    """Split at display-safe arithmetic boundaries while preserving every byte."""

    parts: list[str] = []
    start = 0
    brace_depth = 0
    parenthesis_depth = 0
    bracket_depth = 0
    index = 0
    operators = (" + ", " - ", r" \cdot ", r",\quad ")
    while index < len(body):
        character = body[index]
        if character == "{":
            brace_depth += 1
        elif character == "}":
            brace_depth = max(0, brace_depth - 1)
        elif character == "(":
            parenthesis_depth += 1
        elif character == ")":
            parenthesis_depth = max(0, parenthesis_depth - 1)
        elif character == "[":
            bracket_depth += 1
        elif character == "]":
            bracket_depth = max(0, bracket_depth - 1)
        if brace_depth == parenthesis_depth == bracket_depth == 0:
            operator = next(
                (candidate for candidate in operators if body.startswith(candidate, index)),
                None,
            )
            if operator is not None and index > start:
                parts.append(body[start:index])
                start = index
                index += len(operator)
                continue
        index += 1
    parts.append(body[start:])
    return [part for part in parts if part]


def _wrap_mathtext_equation(equation: str, maximum_line_characters: int) -> str:
    """Add MathText-safe line boundaries without omitting formula content."""

    if not equation.startswith("$") or not equation.endswith("$"):
        return equation
    body = equation[1:-1]
    parts = _top_level_equation_parts(body)
    if len(parts) <= 1:
        return equation
    lines: list[str] = []
    current = ""
    for part in parts:
        if current and len(current) + len(part) > maximum_line_characters:
            lines.append(current)
            current = part
        else:
            current += part
    if current:
        lines.append(current)
    if len(lines) <= 1:
        return equation
    return "$\n$".join(f"${line}" if index == 0 else line for index, line in enumerate(lines)) + "$"


def _fallback_equation(equation: str, axes_bounds: Bbox, renderer) -> str:
    # TeX commands make character count a conservative width proxy. The
    # fallback is measured before acceptance, so an indivisible wide term is
    # still rejected rather than clipped.
    pixels_per_point = max(float(renderer.points_to_pixels(1.0)), 1e-6)
    axes_width_points = axes_bounds.width / pixels_per_point
    width_budget = max(22, min(46, int(axes_width_points / 5.75)))
    return _wrap_mathtext_equation(equation, width_budget)


def _fallback_font_size(
    equation: str,
    preferred_font_size: object,
    axes_bounds: Bbox,
    renderer,
) -> float:
    base_size = min(
        _LABEL_FALLBACK_FONT_SIZE,
        _font_sizes(preferred_font_size)[-1],
    )
    line_count = max(1, equation.count("\n") + 1)
    pixels_per_point = max(float(renderer.points_to_pixels(1.0)), 1e-6)
    axes_height_points = axes_bounds.height / pixels_per_point
    height_limited = max(4.5, (axes_height_points - 8.0) / (line_count * 2.0))
    return min(base_size, height_limited)


def _fallback_slots(ax, renderer) -> list[tuple[np.ndarray, str, str]]:
    """Return DPI-independent positions for the compact equation rail."""

    axes_bounds = ax.get_window_extent(renderer)
    pixels_per_point = max(float(renderer.points_to_pixels(1.0)), 1e-6)
    axes_width_points = max(axes_bounds.width / pixels_per_point, 1e-6)
    axes_height_points = max(axes_bounds.height / pixels_per_point, 1e-6)
    row_step_points = max(8.5, _LABEL_FALLBACK_FONT_SIZE * 1.65)
    rows = max(
        1,
        min(
            _MAX_FALLBACK_SLOTS // 2,
            int((axes_height_points - 8.0) // row_step_points),
        ),
    )
    # Leave room for the rounded box and collision padding as well as the
    # glyphs themselves. Expressing this in points keeps preview and export
    # placement physically stable at different raster DPIs and in vectors.
    rail_inset_points = 9.0
    x_inset = min(0.08, rail_inset_points / axes_width_points)
    y_inset = min(0.08, rail_inset_points / axes_height_points)
    row_step = row_step_points / axes_height_points
    slots: list[tuple[np.ndarray, str, str]] = []
    for row in range(rows):
        y_value = 1.0 - y_inset - row * row_step
        slots.extend(
            (
                (
                    np.asarray((x_inset, y_value), dtype=float),
                    "left",
                    "top",
                ),
                (
                    np.asarray((1.0 - x_inset, y_value), dtype=float),
                    "right",
                    "top",
                ),
            )
        )
    return slots[:_MAX_FALLBACK_SLOTS]


def _create_equation_annotation(
    ax,
    equation: str,
    anchor_display: np.ndarray,
    *,
    offset: tuple[float, float],
    horizontal_alignment: str,
    vertical_alignment: str,
    font_size: float,
    fit_color: str,
    text_color: object,
    background_color: object,
    text_axes_fraction: np.ndarray | None = None,
):
    anchor_data = ax.transData.inverted().transform(anchor_display)
    try:
        label_background = to_rgba(background_color, 0.88)
    except (TypeError, ValueError):
        label_background = to_rgba("#FFFFFF", 0.88)
    if text_axes_fraction is None:
        text_position = offset
        text_coordinates = "offset points"
    else:
        text_position = (
            float(text_axes_fraction[0]),
            float(text_axes_fraction[1]),
        )
        text_coordinates = "axes fraction"
    annotation = ax.annotate(
        equation,
        xy=(float(anchor_data[0]), float(anchor_data[1])),
        xycoords="data",
        xytext=text_position,
        textcoords=text_coordinates,
        ha=horizontal_alignment,
        va=vertical_alignment,
        fontsize=font_size,
        color=text_color,
        rotation=0,
        rotation_mode="anchor",
        bbox={
            "boxstyle": "round,pad=0.24",
            "facecolor": label_background,
            "edgecolor": to_rgba(fit_color, 0.72),
            "linewidth": 0.8,
        },
        arrowprops={
            "arrowstyle": "-",
            "color": to_rgba(fit_color, 0.78),
            "linewidth": 0.8,
            "shrinkA": 2.0,
            "shrinkB": 1.5,
        },
        annotation_clip=True,
        clip_on=True,
        zorder=6,
    )
    annotation.set_gid(_EQUATION_LABEL_GID)
    annotation.set_label("_nolegend_")
    annotation.set_picker(False)
    annotation.set_clip_path(ax.patch)
    if annotation.arrow_patch is not None:
        annotation.arrow_patch.set_clip_path(ax.patch)
    annotation._easygraph_anchor_display = tuple(float(value) for value in anchor_display)
    annotation._easygraph_anchor_data = tuple(float(value) for value in anchor_data)
    if text_axes_fraction is not None:
        annotation._easygraph_text_axes_fraction = tuple(
            float(value) for value in text_axes_fraction
        )
    return annotation


def draw_xy_fit_curves(
    ax,
    prepared: PreparedXYData,
    settings: XYSettings,
    fit_results: Mapping[str, object] | None,
    palette: Sequence[str],
    *,
    mark_plot_content_artist=None,
) -> list:
    """Draw successful cached fits without performing numerical work.

    Fitting is deliberately kept out of the renderer so redraws caused by
    titles, colors, zoom, or export remain inexpensive and deterministic.
    """

    if not fit_results:
        return []

    colors = list(palette) or ["#4E79A7"]
    visible_series = {
        series.id: (series, index)
        for index, series in enumerate(prepared.visible_numeric_series)
    }
    artists = []
    for fit_spec in settings.fit_specs:
        if not fit_spec.enabled or fit_spec.series_id not in visible_series:
            continue
        result = fit_results.get(fit_spec.id)
        if result is None or not bool(getattr(result, "success", False)):
            continue
        curve_x = np.asarray(getattr(result, "curve_x", ()), dtype=float)
        curve_y = np.asarray(getattr(result, "curve_y", ()), dtype=float)
        if curve_x.ndim != 1 or curve_y.ndim != 1 or curve_x.size != curve_y.size:
            continue
        finite = np.isfinite(curve_x) & np.isfinite(curve_y)
        if not np.any(finite):
            continue
        plot_x = curve_x.copy()
        plot_y = curve_y.copy()
        plot_x[~finite] = np.nan
        plot_y[~finite] = np.nan

        series, color_index = visible_series[fit_spec.series_id]
        color = _fit_color(fit_spec, series, color_index, colors)
        label = (
            f"{series.name} (fit)"
            if fit_spec.show_in_legend
            else "_nolegend_"
        )
        try:
            line_width = float(fit_spec.line_width)
        except (TypeError, ValueError, OverflowError):
            line_width = 2.0
        if not math.isfinite(line_width):
            line_width = 2.0
        artist, = ax.plot(
            plot_x,
            plot_y,
            color=color,
            linewidth=max(0.1, line_width),
            linestyle=line_style_for(fit_spec.line_style),
            label=label,
            zorder=4,
        )
        artist._easygraph_series_id = series.id
        artist._easygraph_fit_id = fit_spec.id
        if mark_plot_content_artist is not None:
            mark_plot_content_artist(artist)
        artists.append(artist)
    return artists


def draw_xy_fit_equation_labels(
    ax,
    prepared: PreparedXYData,
    settings: XYSettings,
    fit_results: Mapping[str, object] | None,
    palette: Sequence[str],
    *,
    text_color: object,
    background_color: object,
    font_size: object,
    renderer=None,
) -> list:
    """Draw enabled fit annotations beside finite portions of their curves.

    This is intentionally a post-layout pass. Callers should establish the
    final axis limits before invoking it so viewport clipping and label
    placement reflect the chart the user will actually see.
    """

    if not fit_results:
        return []
    annotation_mode = str(
        getattr(settings, "fit_annotation_mode", "equation")
    )
    if annotation_mode not in {"equation", "parameters"}:
        annotation_mode = "equation"
    renderer = _resolved_renderer(ax, renderer)
    axes_bounds = _inset_bbox(
        ax.get_window_extent(renderer),
        _point_padding(renderer, _LABEL_AXES_PADDING_POINTS),
    )
    if axes_bounds is None:
        return []

    colors = list(palette) or ["#4E79A7"]
    visible_series = {
        series.id: (series, index)
        for index, series in enumerate(prepared.visible_numeric_series)
    }
    legend_regions = _legend_regions(ax, renderer)
    occupied = _occupied_equation_regions(ax, renderer)
    fallback_slots = _fallback_slots(ax, renderer)
    fallback_slot_cursor = 0
    fallback_count = 0
    artists = []
    offsets = (
        ((0.0, _LABEL_OFFSET_POINTS), "center", "bottom"),
        ((0.0, -_LABEL_OFFSET_POINTS), "center", "top"),
    )

    ordered_fit_specs = sorted(
        settings.fit_specs,
        key=lambda fit_spec: _manual_equation_position(fit_spec) is None,
    )
    for fit_spec in ordered_fit_specs:
        if (
            not fit_spec.enabled
            or not bool(getattr(fit_spec, "show_equation", False))
            or fit_spec.series_id not in visible_series
        ):
            continue
        result = fit_results.get(fit_spec.id)
        if result is None or not bool(getattr(result, "success", False)):
            continue
        if (
            annotation_mode == "equation"
            and not bool(getattr(result, "equation_display_reliable", True))
        ):
            continue
        try:
            curve_x = np.asarray(getattr(result, "curve_x", ()), dtype=float)
            curve_y = np.asarray(getattr(result, "curve_y", ()), dtype=float)
        except (TypeError, ValueError, OverflowError):
            continue
        if (
            curve_x.ndim != 1
            or curve_y.ndim != 1
            or curve_x.size != curve_y.size
            or curve_x.size == 0
        ):
            continue
        visible_polylines = _visible_display_polylines(
            ax,
            curve_x,
            curve_y,
            axes_bounds,
        )
        if not visible_polylines:
            continue
        try:
            if annotation_mode == "parameters":
                equation = format_fitted_parameters(
                    result,
                    getattr(fit_spec, "annotation_parameter_names", ()),
                )
            else:
                equation = format_fitted_equation_for_curve(fit_spec, result)
        except (ArithmeticError, TypeError, ValueError):
            continue
        if not isinstance(equation, str) or not equation.strip():
            continue

        series, color_index = visible_series[fit_spec.series_id]
        fit_color = _fit_color(fit_spec, series, color_index, colors)
        resolved_text_color = _equation_text_color(
            fit_color,
            text_color,
            background_color,
        )
        anchors = _candidate_display_anchors(visible_polylines)
        manual_position = _manual_equation_position(fit_spec)
        selected_annotation = None
        if manual_position is not None:
            manual_bounds = _inset_bbox(
                axes_bounds,
                _point_padding(
                    renderer,
                    _LABEL_COLLISION_PADDING_POINTS,
                ),
            ) or axes_bounds
            manual_display = np.asarray(
                ax.transAxes.transform(manual_position),
                dtype=float,
            )
            manual_anchor = _nearest_display_anchor(
                visible_polylines,
                manual_display,
            )
            manual_candidates = [
                (equation, candidate_font_size)
                for candidate_font_size in _font_sizes(font_size)
            ]
            fallback_equation = _fallback_equation(
                equation,
                axes_bounds,
                renderer,
            )
            manual_candidates.append(
                (
                    fallback_equation,
                    _fallback_font_size(
                        fallback_equation,
                        font_size,
                        axes_bounds,
                        renderer,
                    ),
                )
            )
            for manual_equation, resolved_font_size in manual_candidates:
                annotation = _create_equation_annotation(
                    ax,
                    manual_equation,
                    manual_anchor,
                    offset=(0.0, 0.0),
                    horizontal_alignment="center",
                    vertical_alignment="center",
                    font_size=resolved_font_size,
                    fit_color=fit_color,
                    text_color=resolved_text_color,
                    background_color=background_color,
                    text_axes_fraction=manual_position,
                )
                clamped = _clamp_manual_annotation(
                    annotation,
                    ax,
                    renderer,
                    manual_bounds,
                )
                if clamped is None:
                    annotation.remove()
                    continue
                _actual_position, label_bounds = clamped
                selected_annotation = annotation
                annotation._easygraph_equation_layout = "manual"
                occupied.append(
                    _padded_bbox(
                        label_bounds,
                        _point_padding(
                            renderer,
                            _LABEL_COLLISION_PADDING_POINTS,
                        ),
                    )
                )
                break
        else:
            for resolved_font_size in _font_sizes(font_size):
                for anchor_display in anchors:
                    for offset, horizontal_alignment, vertical_alignment in offsets:
                        annotation = _create_equation_annotation(
                            ax,
                            equation,
                            anchor_display,
                            offset=offset,
                            horizontal_alignment=horizontal_alignment,
                            vertical_alignment=vertical_alignment,
                            font_size=resolved_font_size,
                            fit_color=fit_color,
                            text_color=resolved_text_color,
                            background_color=background_color,
                        )
                        try:
                            label_bounds = _label_bounds(annotation, renderer)
                        except (ArithmeticError, RuntimeError, TypeError, ValueError):
                            annotation.remove()
                            continue
                        padded_label_bounds = _padded_bbox(
                            label_bounds,
                            _point_padding(
                                renderer,
                                _LABEL_COLLISION_PADDING_POINTS,
                            ),
                        )
                        if not _bbox_is_inside(
                            padded_label_bounds,
                            axes_bounds,
                        ) or any(
                            padded_label_bounds.overlaps(region)
                            for region in occupied
                        ):
                            annotation.remove()
                            continue
                        selected_annotation = annotation
                        annotation._easygraph_equation_layout = "curve"
                        occupied.append(padded_label_bounds)
                        break
                    if selected_annotation is not None:
                        break
                if selected_annotation is not None:
                    break

        if (
            manual_position is None
            and selected_annotation is None
            and anchors
            and fallback_slots
        ):
            fallback_equation = _fallback_equation(equation, axes_bounds, renderer)
            fallback_font_size = _fallback_font_size(
                fallback_equation,
                font_size,
                axes_bounds,
                renderer,
            )
            fallback_anchor = anchors[0]
            rail_attempts = 0
            while (
                fallback_slot_cursor < len(fallback_slots)
                and rail_attempts < _MAX_RAIL_ATTEMPTS_PER_LABEL
            ):
                text_axes_fraction, horizontal_alignment, vertical_alignment = fallback_slots[
                    fallback_slot_cursor
                ]
                fallback_slot_cursor += 1
                rail_attempts += 1
                annotation = _create_equation_annotation(
                    ax,
                    fallback_equation,
                    fallback_anchor,
                    offset=(0.0, 0.0),
                    horizontal_alignment=horizontal_alignment,
                    vertical_alignment=vertical_alignment,
                    font_size=fallback_font_size,
                    fit_color=fit_color,
                    text_color=resolved_text_color,
                    background_color=background_color,
                    text_axes_fraction=text_axes_fraction,
                )
                try:
                    label_bounds = _label_bounds(annotation, renderer)
                except (ArithmeticError, RuntimeError, TypeError, ValueError):
                    annotation.remove()
                    continue
                padded_label_bounds = _padded_bbox(
                    label_bounds,
                    _point_padding(
                        renderer,
                        _LABEL_COLLISION_PADDING_POINTS,
                    ),
                )
                if not _bbox_is_inside(padded_label_bounds, axes_bounds) or any(
                    padded_label_bounds.overlaps(region) for region in occupied
                ):
                    annotation.remove()
                    continue
                selected_annotation = annotation
                annotation._easygraph_equation_layout = "rail"
                occupied.append(padded_label_bounds)
                break

            if selected_annotation is None:
                # A dense chart can exhaust collision-free rail slots. Keep the
                # request visible with a deterministic, bounded amount of
                # overlap, but never cover an inside legend or leave the axes.
                for offset_index in range(
                    min(_MAX_OVERLAP_ATTEMPTS, len(fallback_slots))
                ):
                    slot_index = (
                        fallback_count * 3 + offset_index
                    ) % len(fallback_slots)
                    text_axes_fraction, horizontal_alignment, vertical_alignment = (
                        fallback_slots[slot_index]
                    )
                    annotation = _create_equation_annotation(
                        ax,
                        fallback_equation,
                        fallback_anchor,
                        offset=(0.0, 0.0),
                        horizontal_alignment=horizontal_alignment,
                        vertical_alignment=vertical_alignment,
                        font_size=fallback_font_size,
                        fit_color=fit_color,
                        text_color=resolved_text_color,
                        background_color=background_color,
                        text_axes_fraction=text_axes_fraction,
                    )
                    try:
                        label_bounds = _label_bounds(annotation, renderer)
                    except (ArithmeticError, RuntimeError, TypeError, ValueError):
                        annotation.remove()
                        continue
                    padded_label_bounds = _padded_bbox(
                        label_bounds,
                        _point_padding(
                            renderer,
                            _LABEL_COLLISION_PADDING_POINTS,
                        ),
                    )
                    if not _bbox_is_inside(
                        padded_label_bounds,
                        axes_bounds,
                    ) or any(
                        padded_label_bounds.overlaps(region)
                        for region in legend_regions
                    ):
                        annotation.remove()
                        continue
                    selected_annotation = annotation
                    annotation._easygraph_equation_layout = "controlled-overlap"
                    occupied.append(padded_label_bounds)
                    break
            fallback_count += 1

        if selected_annotation is not None:
            selected_annotation._easygraph_fit_id = fit_spec.id
            selected_annotation._easygraph_series_id = series.id
            selected_annotation._easygraph_label_bounds = tuple(
                float(value) for value in label_bounds.extents
            )
            artists.append(selected_annotation)
    return artists


__all__ = ["draw_xy_fit_curves", "draw_xy_fit_equation_labels"]
