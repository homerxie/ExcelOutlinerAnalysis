from __future__ import annotations

import atexit
from copy import copy, deepcopy
import math
import os
import re
import tempfile
from collections.abc import Mapping
from dataclasses import asdict, replace
from io import BytesIO
from pathlib import Path

os.environ.setdefault(
    "MPLCONFIGDIR",
    str(Path(tempfile.gettempdir()) / "easygraph_matplotlib"),
)
Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)

import numpy as np
import pandas as pd
from matplotlib import patheffects
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.collections import PathCollection
from matplotlib.colors import to_rgba
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.markers import MarkerStyle
from matplotlib.path import Path as MplPath
from matplotlib.patches import Rectangle
from matplotlib.ticker import AutoLocator, MultipleLocator, PercentFormatter
from matplotlib.transforms import Affine2D, Bbox

from PySide6.QtCore import QByteArray, QEvent, QMimeData, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QImage, QKeySequence, QShortcut
from PySide6.QtWidgets import QApplication, QHBoxLayout, QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget

from easygraph.settings import ChartSettings, LEGEND_INSIDE_AUTO_POSITION, LEGEND_POSITION_INSIDE, PRESETS
from easygraph.app_preferences import stored_theme_preference
from easygraph.ui.toolbar_icons import toolbar_icon
from easygraph.data import attach_group_metadata, axis_labels_for_chart, group_keys, mark_outliers, migrate_group_settings, prepare_plot_frames
from easygraph.grouping import GroupingSettings, grouping_from_dict
from easygraph.numeric import has_percentage_values
from easygraph.plotting.group_layout import build_group_layout
from easygraph.palette import (
    _relative_luminance,
    additional_guide_color,
    expanded_preset_palette,
    palette_for,
)
from easygraph.overlay_series import (
    format_overlay_value,
    line_overlay_series,
    overlay_palette_for,
    overlay_style_for_series,
    stat_table_data,
    stat_table_header_enabled,
    visible_custom_overlay_indexes,
)
from easygraph.plotting.layout import (
    AUTO_AXIS_RANGE_PADDING_FRACTION,
    LEGEND_COLUMN_SPACING,
    LEGEND_HANDLE_LENGTH,
    LEGEND_HANDLE_SPACE_UNITS,
    LEGEND_MAX_COLUMNS,
    LEGEND_SECONDARY_AXIS_GAP_PX,
    MAX_MANUAL_TICK_COUNT,
    OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS,
    OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO,
    OVERLAY_CONTENT_MARGIN_RATIO,
    custom_overlay_secondary_axis_active,
    horizontal_axis_label_width_overflow_inches,
    legend_auto_width_enabled,
    legend_column_count,
    legend_column_gap_inches,
    legend_column_width_inches,
    legend_force_wrap,
    legend_handle_space_inches,
    legend_label_text,
    legend_labels_for_settings,
    legend_outside_needed,
    legend_render_width_inches,
    legend_right_margin_inches,
    legend_text_width_inches,
    legend_total_width_inches,
    legend_unwrapped_item_width_inches,
    legend_wrap_units,
    line_count,
    max_line_count,
    max_text_width_inches,
    overlay_axis_label_margin_points,
    overlay_axis_marker_margin_points,
    plot_bottom_margin_inches,
    plot_left_margin_inches,
    plot_right_margin_inches,
    plot_top_margin_inches,
    ridge_category_tick_vertical_overflow_inches,
    rotated_axis_label_width_inches,
    rotated_category_tick_side_overflow_inches,
    rotated_value_axis_label_height_overflow_inches,
    secondary_axis_split_ratio,
    split_secondary_frame_enabled,
    stat_table_gap_inches,
    stat_table_height_inches,
    stat_table_row_height_inches,
    stat_table_row_height_units,
    text_visual_units,
    wrap_visual_units,
)
from easygraph.plotting.chart_renderers import (
    beeswarm_offsets,
    draw_bar,
    draw_box,
    draw_points,
    draw_ridge,
    draw_violin,
    jitter_offsets,
    point_positions,
    quasirandom_offsets,
    random_offsets,
    van_der_corput,
)
from easygraph.plotting.overlay_renderer import (
    LINE_OVERLAY_STYLE_TO_MPL,
    LINE_OVERLAY_STYLE_TO_QT,
    LINE_STYLE_ICON_DEVICE_RATIOS,
    LINE_STYLE_ICON_SIZE,
    LINE_STYLE_POPUP_PREVIEW_WIDTH,
    LINE_STYLE_POPUP_ROW_HEIGHT,
    LINE_STYLE_PREVIEW_DOT_RADIUS,
    LINE_STYLE_PREVIEW_STROKE_WIDTH,
    STAT_OVERLAY_ALPHA,
    _overlay_coordinates_with_parent_breaks,
    draw_line_style_preview,
    line_style_icon,
    normalize_overlay_label_position,
    overlay_auto_avoidance_position,
    overlay_label_arrow,
    overlay_label_bbox,
    overlay_label_offset,
    overlay_label_position_for_series,
    overlay_line_qt_pen_style,
    overlay_line_style,
    overlay_values_are_close,
    resolve_overlay_label_position,
)
from easygraph.plotting.xy_renderer import draw_xy_series
from easygraph.plotting.xy_fit_renderer import (
    draw_xy_fit_curves,
    draw_xy_fit_equation_labels,
)
from easygraph.plotting.additional_guides import draw_additional_guides
from easygraph.xy_data import PreparedXYData, prepare_xy_data
from easygraph.xy_series import XYSettings


_COORDINATES_WIDTH_SAMPLE = "x=−12345.678 y=−98765.432"
_FIT_EQUATION_EDGE_PADDING_POINTS = 5.25
_CHART_CLIPBOARD_MIME_PROPERTY = "easygraphChartClipboardMime"
_CHART_CLIPBOARD_QUIT_HOOK_PROPERTY = "easygraphChartClipboardQuitHook"
_chart_clipboard_atexit_registered = False


def _release_chart_clipboard_mime_data() -> None:
    """Replace our Python-owned MIME wrapper before the Qt runtime shuts down."""
    app = QApplication.instance()
    if app is None:
        return
    clipboard = QApplication.clipboard()
    if clipboard is None:
        return
    mime_data = clipboard.mimeData()
    if mime_data is None or not bool(mime_data.property(_CHART_CLIPBOARD_MIME_PROPERTY)):
        return
    image = clipboard.image()
    if image.isNull():
        image.loadFromData(mime_data.data("image/png"), "PNG")
    if image.isNull():
        return
    current_mime_data = clipboard.mimeData()
    if current_mime_data is None or not bool(
        current_mime_data.property(_CHART_CLIPBOARD_MIME_PROPERTY)
    ):
        return
    # setImage() creates the replacement QMimeData in C++, so its teardown
    # cannot call back into Shiboken after Python has begun finalizing.
    clipboard.setImage(image)


def _ensure_chart_clipboard_shutdown_cleanup() -> None:
    global _chart_clipboard_atexit_registered

    app = QApplication.instance()
    if app is not None and not bool(app.property(_CHART_CLIPBOARD_QUIT_HOOK_PROPERTY)):
        app.aboutToQuit.connect(_release_chart_clipboard_mime_data)
        app.setProperty(_CHART_CLIPBOARD_QUIT_HOOK_PROPERTY, True)
    if not _chart_clipboard_atexit_registered:
        atexit.register(_release_chart_clipboard_mime_data)
        _chart_clipboard_atexit_registered = True


__all__ = [
    'AUTO_AXIS_RANGE_PADDING_FRACTION',
    'CoordinatesToolbar',
    'LEGEND_COLUMN_SPACING',
    'LEGEND_HANDLE_LENGTH',
    'LEGEND_HANDLE_SPACE_UNITS',
    'LEGEND_MAX_COLUMNS',
    'LEGEND_SECONDARY_AXIS_GAP_PX',
    'LINE_OVERLAY_STYLE_TO_MPL',
    'LINE_OVERLAY_STYLE_TO_QT',
    'LINE_STYLE_ICON_DEVICE_RATIOS',
    'LINE_STYLE_ICON_SIZE',
    'LINE_STYLE_POPUP_PREVIEW_WIDTH',
    'LINE_STYLE_POPUP_ROW_HEIGHT',
    'LINE_STYLE_PREVIEW_DOT_RADIUS',
    'LINE_STYLE_PREVIEW_STROKE_WIDTH',
    'MAX_MANUAL_TICK_COUNT',
    'OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS',
    'OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO',
    'OVERLAY_CONTENT_MARGIN_RATIO',
    'PlotCanvas',
    'STAT_OVERLAY_ALPHA',
    'ScrollFriendlyFigureCanvas',
    'draw_line_style_preview',
    'line_style_icon',
    'normalize_overlay_label_position',
    'overlay_auto_avoidance_position',
    'overlay_label_arrow',
    'overlay_label_bbox',
    'overlay_label_offset',
    'overlay_label_position_for_series',
    'overlay_line_qt_pen_style',
    'overlay_line_style',
    'overlay_values_are_close',
    'resolve_overlay_label_position',
]


class ScrollFriendlyFigureCanvas(FigureCanvasQTAgg):
    def __init__(self, figure, owner=None) -> None:
        self.owner = owner
        super().__init__(figure)

    def wheelEvent(self, event) -> None:
        if event.modifiers() & Qt.ControlModifier and self.owner is not None:
            delta = event.angleDelta().y()
            if delta:
                self.owner.zoom_by(1.12 if delta > 0 else 1 / 1.12)
                event.accept()
                return
        event.ignore()


class CoordinatesToolbar(NavigationToolbar2QT):
    toolitems: tuple = ()

    def __init__(self, canvas, parent=None) -> None:
        super().__init__(canvas, parent, coordinates=True)
        self.setObjectName("plotCoordinatesToolbar")
        self.setFloatable(False)
        self.setMovable(False)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setStyleSheet("QToolBar#plotCoordinatesToolbar { border: 0; background: transparent; padding: 0; }")
        self.locLabel.setObjectName("plotCoordinatesLabel")
        self.locLabel.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        # Matplotlib creates this label empty, so its minimum width otherwise
        # grows only when the pointer first enters the plot and moves the
        # surrounding splitter panes. Reserve coordinate space up front.
        self.locLabel.setMinimumWidth(
            self.locLabel.fontMetrics().horizontalAdvance(_COORDINATES_WIDTH_SAMPLE) + 8
        )

    def set_message(self, message: str) -> None:
        if not self.coordinates or self.locLabel.text() == message:
            return
        self.locLabel.setText(message)
        # The fixed width intentionally prevents a layout pass on every mouse
        # move. Repaint the embedded toolbar label directly so coordinate text
        # still follows the pointer immediately without requiring a click.
        self.locLabel.repaint()


class PlotCanvas(QWidget):
    def __init__(self) -> None:
        super().__init__()
        from easygraph.app_theme import configure_matplotlib_fonts

        configure_matplotlib_fonts()
        self.preview_ppi = 140
        self.preview_zoom = 1.0
        self.figure = None
        self.canvas = None
        self.toolbar = None
        self.selection_callback = None
        self.legend_position_callback = None
        self.fit_equation_position_callback = None
        self._interaction_targets: list[dict] = []
        self._hover_feedback_patch = None
        self._selected_feedback_patch = None
        self._hover_object_kind: str | None = None
        self._hover_series_id: str | None = None
        self._hover_artist_id: int | None = None
        self._selected_object_kind: str | None = None
        self._xy_selection_scope: str = "none"
        self._selected_series_ids: set[str] = set()
        self._selected_series_id: str | None = None
        self._selected_additional_guide_axis_key: str | None = None
        self._selected_additional_guide_index: int | None = None
        self._additional_guide_line_artists: list[dict] = []
        self._xy_box_select_enabled = False
        self._xy_box_select_state: dict | None = None
        self._xy_box_selection_patch = None
        self._legend_drag_state: dict | None = None
        self._fit_equation_drag_state: dict | None = None
        self._legend_plot_union_bbox = None
        self._legend_layout_token = 0
        self._blit_background = None
        self._blit_redrawing = False
        self._blit_refresh_pending = False
        self.zoom_bar = QWidget()
        self.zoom_layout = QHBoxLayout(self.zoom_bar)
        self.zoom_layout.setContentsMargins(6, 4, 6, 4)
        self.zoom_layout.addStretch()
        self.xy_box_select_button = QPushButton(self.tr("Box Select (B)"))
        self.xy_box_select_button.setObjectName("xyBoxSelectButton")
        self.xy_box_select_button.setCheckable(True)
        self.xy_box_select_button.setEnabled(False)
        self.xy_box_select_button.setVisible(False)
        self.xy_box_select_button.setToolTip(
            self.tr(
                "Drag across visible lines or markers. "
                "Ctrl/Cmd adds; Alt removes."
            )
        )
        self.xy_box_select_button.toggled.connect(
            self._set_xy_box_select_enabled
        )
        self._xy_box_select_shortcut = QShortcut(QKeySequence("B"), self)
        self._xy_box_select_shortcut.setContext(
            Qt.ShortcutContext.WidgetWithChildrenShortcut
        )
        self._xy_box_select_shortcut.activated.connect(
            self._toggle_xy_box_select
        )
        zoom_out = QPushButton()
        zoom_reset = QPushButton("100%")
        zoom_fit = QPushButton("Fit")
        zoom_in = QPushButton()
        zoom_out.setObjectName("zoomOutButton")
        zoom_reset.setObjectName("zoomResetButton")
        zoom_fit.setObjectName("zoomToFitButton")
        zoom_in.setObjectName("zoomInButton")
        self._toolbar_icon_buttons = (
            (zoom_out, "zoom-out", self.tr("Zoom Out")),
            (zoom_reset, "scaling", self.tr("Reset Zoom to 100%")),
            (zoom_fit, "square-dimensions", self.tr("Fit to View")),
            (zoom_in, "zoom-in", self.tr("Zoom In")),
        )
        for button, _icon_name, hint in self._toolbar_icon_buttons:
            button.setIconSize(QSize(20, 20))
            button.setToolTip(hint)
            button.setAccessibleName(hint)
        for button in (zoom_out, zoom_in):
            button.setStyleSheet("QPushButton { padding: 2px 5px; }")
            button.setFixedWidth(36)
        zoom_out.clicked.connect(lambda: self.zoom_by(1 / 1.12))
        zoom_reset.clicked.connect(self.reset_zoom)
        zoom_fit.clicked.connect(self.zoom_to_fit)
        zoom_in.clicked.connect(lambda: self.zoom_by(1.12))
        self.zoom_layout.addWidget(self.xy_box_select_button)
        self.zoom_layout.addWidget(zoom_out)
        self.zoom_layout.addWidget(zoom_reset)
        self.zoom_layout.addWidget(zoom_fit)
        self.zoom_layout.addWidget(zoom_in)
        self._canvas_size: tuple[int, int] | None = None
        self.scroll = QScrollArea()
        self.scroll.setObjectName("plotPreviewScroll")
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignCenter)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.chart_elements_bar = QWidget(self)
        self.chart_elements_bar.setObjectName("chartElementsBar")
        self.chart_elements_layout = QHBoxLayout(self.chart_elements_bar)
        self.chart_elements_layout.setContentsMargins(6, 2, 6, 2)
        self.chart_elements_layout.addStretch()
        self.chart_elements_button = QPushButton(
            "Chart Elements",
            self.chart_elements_bar,
        )
        self.chart_elements_button.setObjectName("chartElementsButton")
        self.chart_elements_button.setFixedHeight(26)
        self.chart_elements_button.setIconSize(QSize(20, 20))
        self._toolbar_icon_buttons += (
            (self.chart_elements_button, "chart-no-axes-combined", "Chart Elements"),
        )
        self._refresh_toolbar_icons()
        self.chart_elements_layout.addWidget(self.chart_elements_button)
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.layout.addWidget(self.zoom_bar)
        self.layout.addWidget(self.scroll, 1)
        self.layout.addWidget(self.chart_elements_bar)
        self._replace_canvas(15 / 2.54, 10 / 2.54)

    def _refresh_toolbar_icons(self) -> None:
        dark = stored_theme_preference() == "dark"
        color, disabled = ("#DCE5EF", "#67717E") if dark else ("#334155", "#9CA5B0")
        for button, icon_name, _hint in self._toolbar_icon_buttons:
            button.setIcon(toolbar_icon(f"lucide:{icon_name}", color, disabled))

    def changeEvent(self, event) -> None:
        super().changeEvent(event)
        if event.type() in (QEvent.PaletteChange, QEvent.StyleChange) and hasattr(self, "_toolbar_icon_buttons"):
            self._refresh_toolbar_icons()

    def _replace_canvas(self, width_in: float, height_in: float) -> None:
        width_px = max(1, int(width_in * self.preview_ppi * self.preview_zoom))
        height_px = max(1, int(height_in * self.preview_ppi * self.preview_zoom))
        size = (width_px, height_px)
        if size == self._canvas_size and self.figure is not None and self.canvas is not None:
            return

        self._invalidate_blit_background()

        if self.toolbar is not None:
            self.zoom_layout.removeWidget(self.toolbar)
            self.toolbar.deleteLater()
            self.toolbar = None

        old_canvas = self.scroll.takeWidget()
        if old_canvas is not None:
            old_canvas.deleteLater()

        self.figure = Figure(figsize=(width_in, height_in), dpi=self.preview_ppi * self.preview_zoom)
        self.canvas = ScrollFriendlyFigureCanvas(self.figure, owner=self)
        self.canvas.setFixedSize(width_px, height_px)
        self.canvas.setAutoFillBackground(True)
        self.canvas.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        if self._xy_box_select_enabled:
            self.canvas.setCursor(Qt.CursorShape.CrossCursor)
        self.canvas.mpl_connect("motion_notify_event", self._handle_plot_motion)
        self.canvas.mpl_connect("figure_leave_event", self._handle_plot_leave)
        self.canvas.mpl_connect("button_press_event", self._handle_plot_click)
        self.canvas.mpl_connect("button_release_event", self._handle_plot_release)
        self.canvas.mpl_connect("draw_event", self._handle_canvas_draw)
        self.canvas.mpl_connect("resize_event", self._handle_canvas_resize)
        self.toolbar = CoordinatesToolbar(self.canvas, self.zoom_bar)
        self.zoom_layout.insertWidget(0, self.toolbar, 1)
        self.scroll.setWidget(self.canvas)
        self._canvas_size = size

    def zoom_by(self, factor: float) -> None:
        self.preview_zoom = min(4.0, max(0.25, self.preview_zoom * factor))
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self._rerender_last()

    def reset_zoom(self) -> None:
        self.preview_zoom = 1.0
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self._rerender_last()

    def zoom_to_fit(self) -> None:
        if self.canvas is None:
            return
        base_width_px = self.canvas.width() / max(self.preview_zoom, 0.001)
        base_height_px = self.canvas.height() / max(self.preview_zoom, 0.001)
        if base_width_px <= 0 or base_height_px <= 0:
            return
        viewport_size = self.scroll.viewport().size()
        available_width = max(1, viewport_size.width() - 12)
        available_height = max(1, viewport_size.height() - 12)
        target_zoom = min(available_width / base_width_px, available_height / base_height_px)
        target_zoom = min(4.0, max(0.25, target_zoom))
        if math.isclose(target_zoom, self.preview_zoom, rel_tol=0.001, abs_tol=0.001):
            return
        self.preview_zoom = target_zoom
        self._canvas_size = None
        if hasattr(self, "_last_df") and hasattr(self, "_last_settings"):
            self._rerender_last()

    def _rerender_last(self) -> None:
        xy_settings = getattr(self, "_last_xy_settings", None)
        column_ids = getattr(self, "_last_column_ids", None)
        xy_fit_results = getattr(self, "_last_xy_fit_results", None)
        prepared_xy_data = getattr(self, "_last_prepared_xy_data", None)
        self.render(
            self._last_df,
            self._last_settings,
            xy_settings=xy_settings,
            column_ids=column_ids,
            xy_fit_results=xy_fit_results,
            prepared_xy_data=prepared_xy_data,
            grouping=getattr(self, "_last_grouping", None),
        )

    def render(
        self,
        df: pd.DataFrame,
        settings: ChartSettings,
        *,
        xy_settings: XYSettings | None = None,
        column_ids: list[str] | tuple[str, ...] | None = None,
        xy_fit_results: Mapping[str, object] | None = None,
        prepared_xy_data: PreparedXYData | None = None,
        grouping: GroupingSettings | None = None,
    ) -> None:
        self._discard_fit_equation_drag()
        if xy_settings is not None:
            if column_ids is None:
                raise ValueError("XY rendering requires column IDs.")
            self._render_xy(
                df,
                settings,
                xy_settings,
                column_ids,
                xy_fit_results=xy_fit_results,
                prepared_xy_data=prepared_xy_data,
            )
            return
        if column_ids is not None or df.attrs.get("group_column_ids"):
            if column_ids is not None:
                df = attach_group_metadata(df, column_ids)
            settings = ChartSettings(**asdict(settings))
            migrate_group_settings(settings, df)
        if grouping is None and "grouping" in df.attrs:
            grouping = grouping_from_dict(df.attrs["grouping"], group_keys(df))
        self.xy_box_select_button.setVisible(False)
        self.xy_box_select_button.setEnabled(False)
        self._set_xy_box_select_enabled(False)
        if self._xy_selection_scope != "none":
            self._selected_object_kind = None
            self._xy_selection_scope = "none"
            self._selected_series_ids.clear()
            self._selected_series_id = None
        self._invalidate_blit_background()
        self._last_df = df.copy()
        self._last_settings = ChartSettings(**asdict(settings))
        self._last_xy_settings = None
        self._last_column_ids = tuple(column_ids) if column_ids is not None else None
        self._last_grouping = deepcopy(grouping)
        self._last_xy_fit_results = None
        self._last_prepared_xy_data = None
        self._auto_tick_interval_fallbacks: set[str] = set()
        self._clear_plot_feedback(clear_selection=False)
        self._interaction_targets = []
        self._additional_guide_line_artists = []
        plot_width_in = settings.width / 2.54
        plot_height_in = settings.height / 2.54

        prepared = prepare_plot_frames(df, settings)
        layout_column_ids = column_ids or (group_keys(df) if grouping is not None else prepared.groups)
        self._group_layout = build_group_layout(prepared.visible, settings, grouping, layout_column_ids)
        self._group_legend_entries = self._group_layout.legend
        clean = self._group_layout.reorder(prepared.visible, settings.group_col)
        preset = PRESETS[settings.preset]
        palette = [self._group_layout.colors[str(key)] for key in clean[settings.group_col].drop_duplicates()]
        text_color = "#F9FAFB" if preset["background"] != "#FFFFFF" else "#222222"

        if clean.empty:
            self._replace_canvas(plot_width_in, plot_height_in)
            self.figure.clf()
            self.figure.patch.set_facecolor(preset["background"])
            ax = self.figure.add_axes([0.0, 0.0, 1.0, 1.0])
            ax.set_facecolor(preset["background"])
            ax.text(0.5, 0.5, "No numeric data", ha="center", va="center", fontsize=settings.axis_label_font_size)
            self.canvas.draw()
            if self._selected_object_kind is not None:
                self.clear_plot_selection()
            self.canvas.repaint()
            self.scroll.viewport().repaint()
            return

        out = mark_outliers(clean, settings)
        distribution = clean.drop(index=out.index) if settings.outlier_effect == "Exclude from distribution" else clean
        if distribution.empty:
            distribution = clean
        primary_percentage, secondary_percentage = self._group_percentage_formats(df, clean, settings)
        stat_groups, stat_rows = stat_table_data(distribution, settings, percentage=primary_percentage)
        if stat_rows:
            stat_indexes = {key: index for index, key in enumerate(stat_groups)}
            stat_rows = [
                (label, [values[stat_indexes[key]] if key in stat_indexes else ("0" if label == "Sample" else "") for key in self._group_layout.order])
                for label, values in stat_rows
            ]
            stat_groups = list(self._group_layout.order)
        x_axis_label, y_axis_label = axis_labels_for_chart(settings)

        plot_groups = [self._group_layout.labels[key] for key in self._group_layout.order]
        stat_labels = [self._group_layout.labels[key] for key in stat_groups]
        custom_overlay_secondary_axis_active = self._custom_overlay_secondary_axis_active(settings)
        split_secondary_frame = self._split_secondary_frame_enabled(settings)
        ridge_table = settings.chart_type == "Ridge" and bool(stat_rows)
        table_below = bool(stat_rows) and not ridge_table
        left_margin_in = self._plot_left_margin_inches(settings, plot_groups, y_axis_label, stat_rows)
        right_margin_in = self._plot_right_margin_inches(settings)
        if (
            self._group_legend_entries
            and settings.show_legend
            and settings.legend_position != LEGEND_POSITION_INSIDE
            and settings.chart_type != "Ridge"
        ):
            legend_labels = [label for label, _color in self._group_legend_entries] + legend_labels_for_settings(settings)
            right_margin_in = max(right_margin_in, legend_render_width_inches(legend_labels, settings) + 0.5)
        table_height_in = self._stat_table_height_inches(stat_labels, stat_rows, settings) if table_below else 0.0
        gap_in = self._stat_table_gap_inches(settings, stat_labels, x_axis_label) if table_below else 0.0
        bottom_in = 0.14 if table_below else self._plot_bottom_margin_inches(settings, plot_groups, x_axis_label)
        top_in = self._plot_top_margin_inches(settings)
        if ridge_table:
            table_column_widths = self._ridge_stat_table_column_widths(stat_labels, stat_rows, settings)
            table_width_in = sum(table_column_widths)
            table_gap_in = right_margin_in
            right_margin_in += table_width_in + 0.12
            spacing = self._group_layout.inner_spacing
            category_max = max(self._group_layout.positions.values(), default=0)
            category_range = category_max + (settings.ridge_overlap + 0.65) * spacing
            header_height_in = self._stat_table_row_height_inches(settings)
            table_row_heights = [
                header_height_in
                + (line_count(label) - 1) * settings.stat_table_font_size / 72 * 1.15
                for label in stat_labels
            ]
            half_row_in = max(table_row_heights) / 2
            category_scale = spacing * plot_height_in / category_range
            top_in = max(
                top_in,
                header_height_in + half_row_in
                - (settings.ridge_overlap + 0.25) * category_scale + 0.12,
            )
            bottom_in = max(bottom_in, half_row_in - 0.4 * category_scale + 0.12)
        if self._group_layout.parents:
            parent_labels = [parent.label for parent in self._group_layout.parents]
            if settings.chart_type == "Ridge":
                left_margin_in += max_text_width_inches(parent_labels, settings.tick_font_size) + 0.28
            elif stat_rows:
                gap_in += (settings.tick_font_size * 1.3 * max_line_count(parent_labels) + 14) / 72
            else:
                bottom_in += (settings.tick_font_size * 1.3 * max_line_count(parent_labels) + 14) / 72
        ridge_bottom_overflow, ridge_top_overflow = (
            ridge_category_tick_vertical_overflow_inches(
                settings,
                plot_groups,
                plot_height_in,
            )
        )
        if table_below:
            gap_in = max(gap_in, ridge_bottom_overflow)
        else:
            bottom_in = max(bottom_in, ridge_bottom_overflow)
        top_in = max(top_in, ridge_top_overflow)
        if settings.chart_type in {"Box", "Bar", "Violin"}:
            primary_height_in = plot_height_in
            primary_center_in = bottom_in + table_height_in + gap_in + plot_height_in / 2.0
            if split_secondary_frame:
                secondary_height_in = plot_height_in * self._secondary_axis_split_ratio(settings)
                primary_height_in = plot_height_in - secondary_height_in
                primary_center_in = bottom_in + table_height_in + gap_in + primary_height_in / 2.0
            extra_bottom, extra_top = self._rotated_value_axis_label_height_overflow_inches(
                y_axis_label,
                settings,
                bottom_in + table_height_in + gap_in + plot_height_in + top_in,
                primary_center_in,
            )
            bottom_in += extra_bottom
            top_in += extra_top
            if custom_overlay_secondary_axis_active:
                secondary_center_in = bottom_in + table_height_in + gap_in + plot_height_in / 2.0
                if split_secondary_frame:
                    secondary_center_in = bottom_in + table_height_in + gap_in + primary_height_in + secondary_height_in / 2.0
                extra_bottom, extra_top = self._rotated_value_axis_label_height_overflow_inches(
                    settings.secondary_y_label,
                    settings,
                    bottom_in + table_height_in + gap_in + plot_height_in + top_in,
                    secondary_center_in,
                )
                bottom_in += extra_bottom
                top_in += extra_top
            extra_left, extra_right = self._horizontal_axis_label_width_overflow_inches(
                x_axis_label,
                settings,
                left_margin_in + plot_width_in + right_margin_in,
                left_margin_in + plot_width_in / 2.0,
            )
            left_margin_in += extra_left
            right_margin_in += extra_right
            extra_left, extra_right = rotated_category_tick_side_overflow_inches(
                settings,
                plot_groups,
                plot_width_in,
                left_margin_in,
                right_margin_in,
            )
            left_margin_in += extra_left
            right_margin_in += extra_right
        if settings.chart_type == "Ridge":
            primary_width_in = plot_width_in
            primary_center_in = left_margin_in + plot_width_in / 2.0
            if split_secondary_frame:
                secondary_width_in = plot_width_in * self._secondary_axis_split_ratio(settings)
                primary_width_in = plot_width_in - secondary_width_in
                primary_center_in = left_margin_in + primary_width_in / 2.0
            extra_left, extra_right = self._horizontal_axis_label_width_overflow_inches(
                x_axis_label,
                settings,
                left_margin_in + plot_width_in + right_margin_in,
                primary_center_in,
            )
            left_margin_in += extra_left
            right_margin_in += extra_right
            if custom_overlay_secondary_axis_active:
                secondary_center_in = left_margin_in + plot_width_in / 2.0
                if split_secondary_frame:
                    secondary_center_in = left_margin_in + primary_width_in + secondary_width_in / 2.0
                extra_left, extra_right = self._horizontal_axis_label_width_overflow_inches(
                    settings.secondary_y_label,
                    settings,
                    left_margin_in + plot_width_in + right_margin_in,
                    secondary_center_in,
                )
                left_margin_in += extra_left
                right_margin_in += extra_right
        total_width_in = left_margin_in + plot_width_in + right_margin_in
        total_height_in = plot_height_in + table_height_in + gap_in + bottom_in + top_in

        self._replace_canvas(total_width_in, total_height_in)
        self.figure.clf()
        self.figure.patch.set_facecolor(preset["background"])

        table_ax = None
        secondary_ax = None
        plot_left = left_margin_in / total_width_in
        plot_width = plot_width_in / total_width_in
        plot_bottom = (bottom_in + table_height_in + gap_in) / total_height_in
        plot_height = plot_height_in / total_height_in
        if stat_rows:
            table_bottom = bottom_in / total_height_in
            table_height = table_height_in / total_height_in
            if split_secondary_frame:
                if settings.chart_type == "Ridge":
                    secondary_width = plot_width * self._secondary_axis_split_ratio(settings)
                    primary_width = plot_width - secondary_width
                    ax = self.figure.add_axes([plot_left, plot_bottom, primary_width, plot_height])
                    secondary_ax = self.figure.add_axes([plot_left + primary_width, plot_bottom, secondary_width, plot_height])
                else:
                    secondary_height = plot_height * self._secondary_axis_split_ratio(settings)
                    primary_height = plot_height - secondary_height
                    ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, primary_height])
                    secondary_ax = self.figure.add_axes([plot_left, plot_bottom + primary_height, plot_width, secondary_height])
            else:
                ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, plot_height])
            if ridge_table:
                table_left = (left_margin_in + plot_width_in + table_gap_in) / total_width_in
                table_ax = self.figure.add_axes(
                    [table_left, plot_bottom, table_width_in / total_width_in, plot_height],
                    sharey=ax,
                )
                table_ax.set_gid("ridge-stat-table")
                table_ax.axis("off")
            else:
                table_ax = self.figure.add_axes([plot_left, table_bottom, plot_width, table_height])
            table_ax.set_facecolor("none")
        else:
            if split_secondary_frame:
                if settings.chart_type == "Ridge":
                    secondary_width = plot_width * self._secondary_axis_split_ratio(settings)
                    primary_width = plot_width - secondary_width
                    ax = self.figure.add_axes([plot_left, plot_bottom, primary_width, plot_height])
                    secondary_ax = self.figure.add_axes([plot_left + primary_width, plot_bottom, secondary_width, plot_height])
                else:
                    secondary_height = plot_height * self._secondary_axis_split_ratio(settings)
                    primary_height = plot_height - secondary_height
                    ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, primary_height])
                    secondary_ax = self.figure.add_axes([plot_left, plot_bottom + primary_height, plot_width, secondary_height])
            else:
                ax = self.figure.add_axes([plot_left, plot_bottom, plot_width, plot_height])
        ax.set_facecolor(preset["background"])
        if secondary_ax is not None:
            secondary_ax.set_gid("secondary-axis")
            secondary_ax.set_facecolor(preset["background"])
            if split_secondary_frame:
                # The legend belongs to the primary axis and may span both split
                # frames. Draw that axis last so the secondary frame cannot cover it.
                ax.set_zorder(secondary_ax.get_zorder() + 1)
        elif custom_overlay_secondary_axis_active:
            secondary_ax = ax.twiny() if settings.chart_type == "Ridge" else ax.twinx()
            secondary_ax.set_gid("secondary-axis")
            secondary_ax.set_facecolor("none")
        if primary_percentage:
            value_axis = ax.xaxis if settings.chart_type == "Ridge" else ax.yaxis
            value_axis.set_major_formatter(PercentFormatter(xmax=1))
        if secondary_percentage and secondary_ax is not None:
            value_axis = secondary_ax.xaxis if settings.chart_type == "Ridge" else secondary_ax.yaxis
            value_axis.set_major_formatter(PercentFormatter(xmax=1))

        if settings.chart_type == "Box":
            self._draw_box(ax, distribution, settings, palette)
        elif settings.chart_type == "Bar":
            draw_bar(
                ax, distribution, settings, palette,
                mark_plot_content_artist=self._mark_plot_content_artist,
                layout=self._group_layout,
            )
        elif settings.chart_type == "Violin":
            self._draw_violin(ax, distribution, settings, palette)
        else:
            self._draw_ridge(ax, distribution, clean, settings, palette, text_color, out)
        if settings.chart_type != "Ridge":
            ax.set_xlim(*self._group_layout.limits)
            if split_secondary_frame and secondary_ax is not None:
                secondary_ax.set_xlim(ax.get_xlim())

        point_positions = None
        if settings.chart_type != "Ridge":
            point_positions = self._point_positions(clean, settings)
            if settings.show_points:
                self._draw_points(ax, clean, settings, palette, preset, point_positions)

        if settings.chart_type != "Ridge" and settings.show_outliers:
            if not out.empty and point_positions is not None:
                outlier_points = ax.scatter(
                    point_positions.loc[out.index],
                    out[settings.value_col],
                    s=max(settings.point_size * 18, 45),
                    facecolors="none",
                    edgecolors="#D62728",
                    linewidths=1.3,
                    zorder=6,
                    label="Outlier",
                )
                self._mark_outlier_artist(outlier_points)

        if settings.show_line_overlay or settings.extra_custom_overlay:
            self._draw_line_overlay(ax, distribution, settings, text_color, secondary_ax=secondary_ax)

        if settings.chart_type == "Ridge":
            self._apply_ridge_x_range(ax, settings)
        elif not settings.auto_y_range:
            ax.set_ylim(settings.y_min, settings.y_max)
        else:
            self._apply_auto_value_axis_padding(ax, settings)
        if secondary_ax is not None and not settings.secondary_auto_y_range:
            if settings.chart_type == "Ridge":
                secondary_ax.set_xlim(settings.secondary_y_min, settings.secondary_y_max)
            else:
                secondary_ax.set_ylim(settings.secondary_y_min, settings.secondary_y_max)
        elif secondary_ax is not None:
            self._apply_auto_value_axis_padding(secondary_ax, settings)

        ax.set_title("" if split_secondary_frame else settings.title, fontsize=settings.title_font_size, color=text_color)
        ax.set_xlabel(x_axis_label, fontsize=settings.axis_label_font_size, color=text_color)
        ax.set_ylabel(y_axis_label, fontsize=settings.axis_label_font_size, color=text_color)
        ax.tick_params(colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        category_tick_rotation = settings.x_tick_rotation
        category_axis = ax.yaxis if settings.chart_type == "Ridge" else ax.xaxis
        category_axis.set_ticks(
            [self._group_layout.coordinate(key, ridge=settings.chart_type == "Ridge") for key in self._group_layout.order],
            labels=["" if self._group_layout.hide_leaf_labels else self._group_layout.labels[key] for key in self._group_layout.order],
        )
        category_axis.set_tick_params(labelrotation=category_tick_rotation)
        for tick_label in category_axis.get_ticklabels():
            if settings.chart_type == "Ridge":
                tick_label.set_horizontalalignment("right")
                tick_label.set_verticalalignment("center")
            else:
                tick_label.set_horizontalalignment(
                    "right" if category_tick_rotation else "center"
                )
            tick_label.set_rotation_mode(
                "anchor" if category_tick_rotation else "default"
            )
        self._draw_group_axis(ax, settings, text_color)
        self._style_plot_frame(ax, settings, text_color)
        ax.grid(bool(settings.show_grid))
        if settings.show_grid:
            ax.grid(color="#D1D5DB" if preset["background"] == "#FFFFFF" else "#374151", alpha=0.55)
        if secondary_ax is not None:
            if split_secondary_frame:
                self._style_split_secondary_axis(secondary_ax, ax, stat_groups, settings, text_color)
            else:
                self._style_secondary_axis(secondary_ax, settings, text_color)
        if table_below:
            self._draw_stat_table(table_ax, stat_groups, stat_rows, settings, text_color)
        self._apply_overlay_axis_label_y_padding(ax, settings)
        # One measurement draw supplies the renderer for all display-space
        # range, label, legend, and interaction calculations below.
        self.canvas.draw()
        self._place_legend(ax, text_color, settings, extra_axes=[secondary_ax] if secondary_ax is not None else None)
        if settings.auto_y_range:
            self._expand_axes_for_plot_content(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._expand_axes_for_plot_content(secondary_ax, settings)
        if settings.auto_y_range:
            self._expand_axes_for_overlay_label_conflicts(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._expand_axes_for_overlay_label_conflicts(secondary_ax, settings)
        if settings.auto_y_range:
            self._separate_overlay_value_labels(ax)
            self._expand_axes_for_plot_content(ax, settings)
        if secondary_ax is not None and settings.secondary_auto_y_range:
            self._separate_overlay_value_labels(secondary_ax)
            self._expand_axes_for_plot_content(secondary_ax, settings)
        # Content and label fitting can add space below the bar baseline.
        if settings.chart_type == "Bar" and settings.auto_y_range and 0 <= ax.dataLim.ymin < math.inf:
            ax.set_ylim(bottom=0.0)
        self._apply_value_axis_tick_interval(ax, settings)
        if secondary_ax is not None:
            self._apply_value_axis_tick_interval(secondary_ax, settings, secondary=True)
        if ridge_table:
            # Convert physical row heights only after overlays have finished
            # expanding the shared category range.
            self._draw_ridge_stat_table(
                table_ax, stat_groups, stat_rows, settings, text_color,
                table_column_widths, table_row_heights,
            )
        if settings.legend_position == LEGEND_POSITION_INSIDE and ax.get_legend() is not None:
            # Inside legends need one bounded layout draw so their real frame
            # size can be clamped before the final preview draw.
            self.canvas.draw()
        self._finalize_inside_legend(ax, secondary_ax, settings)
        primary_guide_colors = [
            additional_guide_color(settings, guide)
            for guide in settings.additional_primary_axis_guides
        ]
        additional_guide_artists = draw_additional_guides(
            ax,
            settings.additional_primary_axis_guides,
            dimension="x" if settings.chart_type == "Ridge" else "y",
            side="bottom" if settings.chart_type == "Ridge" else "left",
            font_size=settings.additional_guide_font_size,
            text_color=text_color,
            grid_color="#D1D5DB" if preset["background"] == "#FFFFFF" else "#374151",
            grid_colors=primary_guide_colors,
            axis_line_width=settings.axis_line_width,
            guide_line_width=settings.additional_guide_line_width,
            label_facecolor=preset["background"],
        )
        self._register_additional_guide_lines(
            ax,
            additional_guide_artists,
            axis_key="primary",
        )
        # This draw supplies exact label/background bounds after every range
        # and locator adjustment, so only visible guides affect the canvas.
        self.canvas.draw()
        guide_dimension = "x" if settings.chart_type == "Ridge" else "y"
        if self._space_axis_labels_for_additional_guides(
            ax,
            x_artists=(
                additional_guide_artists if guide_dimension == "x" else ()
            ),
            y_artists=(
                additional_guide_artists if guide_dimension == "y" else ()
            ),
        ):
            self.canvas.draw()
        if self._fit_additional_guide_overflow(
            ax,
            additional_guide_artists,
            table_ax=table_ax if table_below and guide_dimension == "x" else None,
            secondary_ax=secondary_ax,
        ):
            self._finalize_inside_legend(ax, secondary_ax, settings)
            self.canvas.draw()
        if ridge_table and self._fit_ridge_stat_table_overflow(table_ax):
            self._finalize_inside_legend(ax, secondary_ax, settings)
            self.canvas.draw()
        if settings.chart_type == "Ridge" and settings.legend_position != LEGEND_POSITION_INSIDE:
            self._fit_ridge_bottom_legend(ax, secondary_ax, table_ax)
        self._refresh_interaction_targets(settings, ax, table_ax, secondary_ax)
        self._last_settings = ChartSettings(**asdict(settings))
        self.canvas.repaint()
        self.scroll.viewport().repaint()
        self._schedule_legend_layout_finalize(settings, ax, table_ax, secondary_ax)

    def _group_percentage_formats(self, dataframe, clean, settings) -> tuple[bool, bool]:
        visible_groups = set(clean[settings.group_col].dropna().astype(str))
        primary_percentage = any(
            key in visible_groups and has_percentage_values(dataframe.iloc[:, index])
            for index, key in enumerate(group_keys(dataframe))
        )
        overlay_percentage = False
        for index in visible_custom_overlay_indexes(settings):
            raw_values = settings.custom_overlay_series[index].get("values", {})
            if isinstance(raw_values, dict) and has_percentage_values(
                raw_values.get(key) for key in visible_groups
            ):
                overlay_percentage = True
                break
        if self._custom_overlay_secondary_axis_active(settings):
            return primary_percentage, overlay_percentage
        return primary_percentage or overlay_percentage, False

    def _render_xy(
        self,
        dataframe: pd.DataFrame,
        chart_settings: ChartSettings,
        xy_settings: XYSettings,
        column_ids: list[str] | tuple[str, ...],
        *,
        xy_fit_results: Mapping[str, object] | None = None,
        prepared_xy_data: PreparedXYData | None = None,
    ) -> None:
        self.xy_box_select_button.setVisible(True)
        self.xy_box_select_button.setEnabled(True)
        self._invalidate_blit_background()
        self._last_df = dataframe.copy()
        self._last_settings = ChartSettings(**asdict(chart_settings))
        self._last_xy_settings = deepcopy(xy_settings)
        self._last_grouping = None
        self._group_layout = None
        self._group_legend_entries = ()
        self._last_column_ids = tuple(column_ids)
        self._last_xy_fit_results = dict(xy_fit_results or {})
        self._auto_tick_interval_fallbacks = set()
        self._clear_plot_feedback(clear_selection=False)
        self._interaction_targets = []
        self._additional_guide_line_artists = []

        prepared = prepared_xy_data
        if prepared is None:
            prepared = prepare_xy_data(
                dataframe,
                column_ids,
                xy_settings,
                order_mode=chart_settings.group_order,
            )
        self._last_prepared_xy_data = prepared
        preset = PRESETS[chart_settings.preset]
        text_color = "#F9FAFB" if preset["background"] != "#FFFFFF" else "#222222"
        plot_width_in = chart_settings.width / 2.54
        plot_height_in = chart_settings.height / 2.54

        visible_series_names = {
            series.id: series.name
            for series in prepared.visible_numeric_series
        }
        labels = list(visible_series_names.values())
        successful_fit_labels = [
            f"{visible_series_names[fit_spec.series_id]} (fit)"
            for fit_spec in xy_settings.fit_specs
            if fit_spec.enabled
            and fit_spec.show_in_legend
            and fit_spec.series_id in visible_series_names
            and bool(
                getattr(
                    (xy_fit_results or {}).get(fit_spec.id),
                    "success",
                    False,
                )
            )
        ]
        legend_labels = [*labels, *successful_fit_labels]
        left_margin_in = max(
            0.62,
            self._plot_left_margin_inches(
                chart_settings,
                [],
                chart_settings.y_label,
                [],
            ),
        )
        bottom_in = max(
            0.52,
            self._plot_bottom_margin_inches(
                replace(chart_settings, x_tick_rotation=0),
                [],
                chart_settings.x_label,
            ),
        )
        top_in = self._plot_top_margin_inches(chart_settings)
        right_margin_in = 0.28
        if (
            legend_labels
            and chart_settings.show_legend
            and chart_settings.legend_position != LEGEND_POSITION_INSIDE
        ):
            right_margin_in += self._legend_render_width_inches(
                legend_labels,
                chart_settings,
            )

        total_width_in = left_margin_in + plot_width_in + right_margin_in
        total_height_in = bottom_in + plot_height_in + top_in
        self._replace_canvas(total_width_in, total_height_in)
        self.figure.clf()
        self.figure.patch.set_facecolor(preset["background"])
        ax = self.figure.add_axes(
            [
                left_margin_in / total_width_in,
                bottom_in / total_height_in,
                plot_width_in / total_width_in,
                plot_height_in / total_height_in,
            ]
        )
        ax.set_facecolor(preset["background"])
        palette = expanded_preset_palette(chart_settings.preset, len(labels))

        if not prepared.visible_numeric_series:
            ax.text(
                0.5,
                0.5,
                "No numeric data",
                transform=ax.transAxes,
                ha="center",
                va="center",
                fontsize=chart_settings.axis_label_font_size,
                color=text_color,
            )
        else:
            draw_xy_series(
                ax,
                prepared,
                xy_settings,
                palette,
                mark_point_artist=self._mark_point_artist,
                mark_plot_content_artist=self._mark_plot_content_artist,
            )
            draw_xy_fit_curves(
                ax,
                prepared,
                xy_settings,
                xy_fit_results,
                palette,
                mark_plot_content_artist=self._mark_plot_content_artist,
            )
            ax.margins(x=0.05)
            if chart_settings.auto_y_range:
                self._apply_auto_value_axis_padding(ax, chart_settings)
            else:
                ax.set_ylim(chart_settings.y_min, chart_settings.y_max)
        if not chart_settings.auto_x_range:
            ax.set_xlim(chart_settings.x_min, chart_settings.x_max)

        ax.set_title(
            chart_settings.title,
            fontsize=chart_settings.title_font_size,
            color=text_color,
        )
        ax.set_xlabel(
            chart_settings.x_label,
            fontsize=chart_settings.axis_label_font_size,
            color=text_color,
        )
        ax.set_ylabel(
            chart_settings.y_label,
            fontsize=chart_settings.axis_label_font_size,
            color=text_color,
        )
        ax.tick_params(
            colors=text_color,
            labelsize=chart_settings.tick_font_size,
            width=chart_settings.axis_line_width,
        )
        # XY uses a numeric X axis, so category-label rotation does not apply.
        ax.xaxis.set_tick_params(labelrotation=0)
        if any(series.x_is_percentage for series in prepared.visible_numeric_series):
            ax.xaxis.set_major_formatter(PercentFormatter(xmax=1))
        if any(series.y_is_percentage for series in prepared.visible_numeric_series):
            ax.yaxis.set_major_formatter(PercentFormatter(xmax=1))
        self._style_plot_frame(ax, chart_settings, text_color)
        ax.grid(bool(chart_settings.show_grid))
        if chart_settings.show_grid:
            ax.grid(
                color="#D1D5DB" if preset["background"] == "#FFFFFF" else "#374151",
                alpha=0.55,
            )

        self.canvas.draw()
        self._place_legend(ax, text_color, chart_settings)
        self._apply_value_axis_tick_interval(ax, chart_settings)
        self._apply_xy_x_axis_tick_interval(ax, chart_settings)
        if (
            chart_settings.legend_position == LEGEND_POSITION_INSIDE
            and ax.get_legend() is not None
        ):
            self.canvas.draw()
        self._finalize_inside_legend(ax, None, chart_settings)
        guide_grid_color = (
            "#D1D5DB"
            if preset["background"] == "#FFFFFF"
            else "#374151"
        )
        x_guide_colors = [
            additional_guide_color(chart_settings, guide)
            for guide in chart_settings.additional_x_axis_guides
        ]
        primary_guide_colors = [
            additional_guide_color(chart_settings, guide)
            for guide in chart_settings.additional_primary_axis_guides
        ]
        additional_x_guide_artists = draw_additional_guides(
            ax,
            chart_settings.additional_x_axis_guides,
            dimension="x",
            side="bottom",
            font_size=chart_settings.additional_guide_font_size,
            text_color=text_color,
            grid_color=guide_grid_color,
            grid_colors=x_guide_colors,
            axis_line_width=chart_settings.axis_line_width,
            guide_line_width=chart_settings.additional_guide_line_width,
            label_facecolor=preset["background"],
        )
        additional_y_guide_artists = draw_additional_guides(
            ax,
            chart_settings.additional_primary_axis_guides,
            dimension="y",
            side="left",
            font_size=chart_settings.additional_guide_font_size,
            text_color=text_color,
            grid_color=guide_grid_color,
            grid_colors=primary_guide_colors,
            axis_line_width=chart_settings.axis_line_width,
            guide_line_width=chart_settings.additional_guide_line_width,
            label_facecolor=preset["background"],
        )
        self._register_additional_guide_lines(
            ax,
            additional_x_guide_artists,
            axis_key="x",
        )
        self._register_additional_guide_lines(
            ax,
            additional_y_guide_artists,
            axis_key="primary",
        )
        additional_guide_artists = [
            *additional_x_guide_artists,
            *additional_y_guide_artists,
        ]
        self.canvas.draw()
        if self._space_axis_labels_for_additional_guides(
            ax,
            x_artists=additional_x_guide_artists,
            y_artists=additional_y_guide_artists,
        ):
            self.canvas.draw()
        if self._fit_additional_guide_overflow(ax, additional_guide_artists):
            self._finalize_inside_legend(ax, None, chart_settings)
            self.canvas.draw()
        if prepared.visible_numeric_series:
            equation_labels = draw_xy_fit_equation_labels(
                ax,
                prepared,
                xy_settings,
                xy_fit_results,
                palette,
                text_color=text_color,
                background_color=preset["background"],
                font_size=chart_settings.tick_font_size,
                renderer=self.canvas.get_renderer(),
            )
            if equation_labels:
                self.canvas.draw()
        self._refresh_interaction_targets(chart_settings, ax, None, None)
        self.canvas.repaint()
        self.scroll.viewport().repaint()
        self._schedule_legend_layout_finalize(
            chart_settings,
            ax,
            None,
            None,
        )

    def _toggle_xy_box_select(self) -> None:
        if self.xy_box_select_button.isEnabled():
            self.xy_box_select_button.setChecked(
                not self.xy_box_select_button.isChecked()
            )

    def _set_xy_box_select_enabled(self, enabled: bool) -> None:
        active = bool(
            enabled
            and self.xy_box_select_button.isEnabled()
            and getattr(self, "_last_xy_settings", None) is not None
        )
        if self._xy_box_select_enabled == active:
            if self.xy_box_select_button.isChecked() != active:
                self.xy_box_select_button.blockSignals(True)
                self.xy_box_select_button.setChecked(active)
                self.xy_box_select_button.blockSignals(False)
            return
        self._xy_box_select_enabled = active
        if self.xy_box_select_button.isChecked() != active:
            self.xy_box_select_button.blockSignals(True)
            self.xy_box_select_button.setChecked(active)
            self.xy_box_select_button.blockSignals(False)
        if self.canvas is not None:
            self.canvas.setCursor(
                Qt.CursorShape.CrossCursor
                if active
                else Qt.CursorShape.ArrowCursor
            )
        if not active:
            self._cancel_xy_box_drag(redraw=True)

    def set_xy_box_select_enabled(self, enabled: bool) -> None:
        """Enable or disable direct rectangle selection on an XY plot."""
        if enabled and not self.xy_box_select_button.isEnabled():
            return
        self.xy_box_select_button.setChecked(bool(enabled))

    def cancel_xy_box_selection(self) -> None:
        """Cancel an in-progress marquee and leave rectangle-selection mode."""
        self.set_xy_box_select_enabled(False)

    def _handle_plot_motion(self, event) -> None:
        if self._fit_equation_drag_state is not None:
            self._drag_fit_equation_to_event(event)
            return
        if self._xy_box_select_state is not None:
            self._update_xy_box_drag(event)
            return
        if self._legend_drag_state is not None:
            self._drag_legend_to_event(event)
            return
        target = self._interaction_target_at_event(
            event,
            include_point_targets=getattr(self, "_last_xy_settings", None) is not None,
        )
        self._set_plot_cursor_for_target(target)
        kind = self._selection_kind_for_target(target)
        series_id = self._series_id_for_target(target)
        artist_id = (
            id(target.get("artist"))
            if self._is_xy_series_target(target)
            or (
                target is not None
                and target.get("kind")
                in {"additional_grid_line", "fit_equation"}
            )
            else None
        )
        if (
            kind == self._hover_object_kind
            and series_id == self._hover_series_id
            and artist_id == self._hover_artist_id
        ):
            return
        self._hover_object_kind = kind
        self._hover_series_id = series_id
        self._hover_artist_id = artist_id
        if self._is_xy_series_target(target) or (
            target is not None
            and target.get("kind") == "additional_grid_line"
        ):
            self._set_feedback_artists(
                "_hover_feedback_patch",
                [target["artist"]],
                selected=False,
                figure_level=target.get("source") == "legend",
            )
        else:
            self._set_feedback_patch(
                "_hover_feedback_patch",
                self._hover_feedback_bboxes_for_target(target),
                selected=False,
            )

    def _handle_plot_leave(self, _event) -> None:
        if (
            self._fit_equation_drag_state is not None
            or self._legend_drag_state is not None
            or self._xy_box_select_state is not None
        ):
            return
        self._set_plot_cursor_for_target(None)
        self._hover_object_kind = None
        self._hover_series_id = None
        self._hover_artist_id = None
        self._set_feedback_patch("_hover_feedback_patch", None, selected=False)

    def _handle_plot_click(self, event) -> None:
        if getattr(event, "button", None) != 1:
            return
        target = self._interaction_target_at_event(event)
        if target is not None and target.get("kind") == "fit_equation":
            fit_id = target.get("fit_id")
            if bool(getattr(event, "dblclick", False)):
                if fit_id is not None and callable(
                    self.fit_equation_position_callback
                ):
                    self.fit_equation_position_callback(str(fit_id), None, None)
                return
            self._start_fit_equation_drag(event, target)
            return
        if self._xy_box_select_enabled and self._start_xy_box_drag(event):
            return
        self._handle_plot_selection_click(event)

    def _handle_plot_selection_click(self, event) -> None:
        target = self._interaction_target_at_event(event)
        if target is None:
            self.clear_plot_selection()
            return
        if target.get("kind") == "legend" and self._legend_drag_enabled():
            self._start_legend_drag(event, target)
        if self._is_xy_series_target(target):
            series_id = self._series_id_for_target(target)
            if series_id is None:
                return
            if bool(getattr(event, "dblclick", False)):
                self.set_xy_series_selection("subset", {series_id})
                return
            if self._xy_event_has_toggle_modifier(event):
                if self._xy_selection_scope == "subset":
                    selected_ids = set(self._selected_series_ids)
                elif self._xy_selection_scope == "all":
                    selected_ids = self._all_xy_series_ids()
                else:
                    selected_ids = set()
                if series_id in selected_ids:
                    selected_ids.remove(series_id)
                else:
                    selected_ids.add(series_id)
                self.set_xy_series_selection("subset", selected_ids)
                return
            self.set_xy_series_selection("subset", {series_id})
            return

        self._xy_selection_scope = "none"
        self._selected_series_ids.clear()
        self._selected_object_kind = self._selection_kind_for_target(target)
        self._selected_series_id = self._series_id_for_target(target)
        if self._selected_object_kind == "additional_grid_line":
            self._selected_additional_guide_axis_key = str(
                target.get("guide_axis_key")
            )
            self._selected_additional_guide_index = int(
                target.get("guide_index", 0)
            )
        else:
            self._selected_additional_guide_axis_key = None
            self._selected_additional_guide_index = None
        if (
            self._selected_object_kind == "points"
            and getattr(self, "_last_xy_settings", None) is None
        ):
            self._set_feedback_artists(
                "_selected_feedback_patch",
                self._plot_point_artists(),
                selected=True,
            )
        elif self._selected_object_kind == "additional_grid_line":
            self._set_feedback_artists(
                "_selected_feedback_patch",
                [target.get("artist")],
                selected=True,
            )
        else:
            self._set_feedback_patch(
                "_selected_feedback_patch",
                self._feedback_bboxes_for_target(target),
                selected=True,
            )
        if callable(self.selection_callback):
            self.selection_callback(self._selected_object_kind)

    def _handle_plot_release(self, event) -> None:
        if getattr(event, "button", None) != 1:
            return
        if self._fit_equation_drag_state is not None:
            self._drag_fit_equation_to_event(event)
            self._finish_fit_equation_drag()
            return
        if self._xy_box_select_state is not None:
            self._finish_xy_box_drag(event)
            return
        if self._legend_drag_state is None:
            return
        self._drag_legend_to_event(event)
        self._finish_legend_drag()

    def _event_key_tokens(self, event) -> set[str]:
        key = str(getattr(event, "key", "") or "").lower()
        tokens = {
            token.strip()
            for token in re.split(r"[+\s]+", key)
            if token.strip()
        }
        gui_event = getattr(event, "guiEvent", None)
        if gui_event is not None and hasattr(gui_event, "modifiers"):
            try:
                modifiers = gui_event.modifiers()
                if modifiers & Qt.KeyboardModifier.ControlModifier:
                    tokens.add("control")
                if modifiers & Qt.KeyboardModifier.MetaModifier:
                    tokens.add("meta")
                if modifiers & Qt.KeyboardModifier.AltModifier:
                    tokens.add("alt")
            except (AttributeError, RuntimeError, TypeError):
                pass
        return tokens

    def _xy_event_has_toggle_modifier(self, event) -> bool:
        return bool(
            self._event_key_tokens(event)
            & {"control", "ctrl", "cmd", "command", "meta", "super"}
        )

    def _xy_box_operation_for_event(self, event) -> str:
        tokens = self._event_key_tokens(event)
        if tokens & {"alt", "option"}:
            return "subtract"
        if tokens & {"control", "ctrl", "cmd", "command", "meta", "super"}:
            return "append"
        return "replace"

    def _xy_plot_clip_bbox_at_event(self, event):
        x = getattr(event, "x", None)
        y = getattr(event, "y", None)
        if x is None or y is None:
            return None
        try:
            x = float(x)
            y = float(y)
        except (TypeError, ValueError):
            return None
        if not math.isfinite(x) or not math.isfinite(y):
            return None
        clip_bboxes = []
        seen = set()
        for target in self._interaction_targets:
            if target.get("kind") != "points" or target.get("source") != "plot":
                continue
            clip_bbox = target.get("clip_bbox")
            if clip_bbox is None or id(clip_bbox) in seen:
                continue
            seen.add(id(clip_bbox))
            clip_bboxes.append(clip_bbox)
        if not clip_bboxes and self.figure is not None and self.figure.axes:
            renderer = self.canvas.get_renderer() if self.canvas is not None else None
            clip_bboxes = [self.figure.axes[0].get_window_extent(renderer)]
        return next(
            (bbox for bbox in clip_bboxes if bbox.contains(x, y)),
            None,
        )

    def _start_xy_box_drag(self, event) -> bool:
        if getattr(self, "_last_xy_settings", None) is None:
            return False
        target = self._interaction_target_at_event(event)
        if target is not None and (
            target.get("source") != "plot" or target.get("kind") != "points"
        ):
            return False
        clip_bbox = self._xy_plot_clip_bbox_at_event(event)
        if clip_bbox is None:
            return False
        x = float(event.x)
        y = float(event.y)
        self._xy_box_select_state = {
            "start": (x, y),
            "current": (x, y),
            "clip_bbox": clip_bbox,
            "operation": self._xy_box_operation_for_event(event),
            "press_event": event,
            "moved": False,
            "preview_ids": set(),
        }
        if self.canvas is not None:
            self.canvas.setFocus()
        return True

    def _xy_box_bbox_for_state(self, state: dict):
        clip_bbox = state["clip_bbox"]
        start_x, start_y = state["start"]
        current_x, current_y = state["current"]
        start_x = min(max(float(start_x), clip_bbox.x0), clip_bbox.x1)
        start_y = min(max(float(start_y), clip_bbox.y0), clip_bbox.y1)
        current_x = min(max(float(current_x), clip_bbox.x0), clip_bbox.x1)
        current_y = min(max(float(current_y), clip_bbox.y0), clip_bbox.y1)
        return Bbox.from_extents(
            min(start_x, current_x),
            min(start_y, current_y),
            max(start_x, current_x),
            max(start_y, current_y),
        )

    def _update_xy_box_drag(self, event) -> None:
        state = self._xy_box_select_state
        if state is None:
            return
        x = getattr(event, "x", state["current"][0])
        y = getattr(event, "y", state["current"][1])
        try:
            x = float(x)
            y = float(y)
        except (TypeError, ValueError):
            return
        if not math.isfinite(x) or not math.isfinite(y):
            return
        state["current"] = (x, y)
        start_x, start_y = state["start"]
        if math.hypot(x - start_x, y - start_y) >= 3.0:
            state["moved"] = True
        if not state["moved"]:
            return
        selection_bbox = self._xy_box_bbox_for_state(state)
        self._set_xy_box_selection_patch(selection_bbox, redraw=False)
        preview_ids = self._xy_series_ids_intersecting_bbox(selection_bbox)
        if preview_ids != state["preview_ids"]:
            state["preview_ids"] = preview_ids
            self._set_feedback_artists(
                "_hover_feedback_patch",
                self._xy_plot_series_artists(preview_ids),
                selected=False,
            )
        else:
            self._redraw_interaction_artists()

    def _finish_xy_box_drag(self, event) -> None:
        state = self._xy_box_select_state
        if state is None:
            return
        self._update_xy_box_drag(event)
        moved = bool(state["moved"])
        press_event = state["press_event"]
        operation = state["operation"]
        hit_ids = set(state["preview_ids"])
        self._cancel_xy_box_drag(redraw=False)
        if not moved:
            self._handle_plot_selection_click(press_event)
            return
        if operation == "append":
            if self._xy_selection_scope == "subset":
                base_ids = set(self._selected_series_ids)
            elif self._xy_selection_scope == "all":
                base_ids = self._all_xy_series_ids()
            else:
                base_ids = set()
            selected_ids = base_ids | hit_ids
        elif operation == "subtract":
            if self._xy_selection_scope == "subset":
                base_ids = set(self._selected_series_ids)
            elif self._xy_selection_scope == "all":
                base_ids = self._all_xy_series_ids()
            else:
                base_ids = set()
            selected_ids = base_ids - hit_ids
        else:
            selected_ids = hit_ids
        self.set_xy_series_selection("subset", selected_ids)

    def _cancel_xy_box_drag(self, *, redraw: bool) -> None:
        had_feedback = bool(
            self._xy_box_select_state is not None
            or self._xy_box_selection_patch is not None
            or self._hover_feedback_patch is not None
        )
        self._xy_box_select_state = None
        self._remove_feedback_patch("_xy_box_selection_patch", redraw=False)
        self._remove_feedback_patch("_hover_feedback_patch", redraw=False)
        self._hover_object_kind = None
        self._hover_series_id = None
        self._hover_artist_id = None
        if redraw and had_feedback:
            self._redraw_interaction_artists()

    def _set_xy_box_selection_patch(self, bbox, *, redraw: bool) -> None:
        if self.figure is None or self.canvas is None:
            return
        (x0, y0), (x1, y1) = self.figure.transFigure.inverted().transform(
            [(bbox.x0, bbox.y0), (bbox.x1, bbox.y1)]
        )
        patch = self._xy_box_selection_patch
        if patch is None:
            patch = Rectangle(
                (x0, y0),
                x1 - x0,
                y1 - y0,
                transform=self.figure.transFigure,
                facecolor="#60A5FA",
                edgecolor="#2563EB",
                alpha=0.13,
                linewidth=1.0,
                linestyle="--",
                zorder=1003,
                clip_on=False,
            )
            patch.set_animated(self._can_blit())
            patch._easygraph_feedback_figure_level = True
            patch.set_gid("interaction-feedback")
            self.figure.add_artist(patch)
            self._xy_box_selection_patch = patch
        else:
            patch.set_bounds(x0, y0, x1 - x0, y1 - y0)
        if redraw:
            self._redraw_interaction_artists()

    def _set_plot_cursor_for_target(self, target) -> None:
        if self.canvas is None:
            return
        if target is not None and target.get("kind") == "fit_equation":
            cursor = Qt.CursorShape.SizeAllCursor
        elif self._xy_box_select_enabled:
            cursor = Qt.CursorShape.CrossCursor
        else:
            cursor = Qt.CursorShape.ArrowCursor
        self.canvas.setCursor(cursor)

    @staticmethod
    def _fit_equation_annotation_bbox(annotation, renderer):
        try:
            annotation.update_positions(renderer)
            annotation.update_bbox_position_size(renderer)
            background = annotation.get_bbox_patch()
            bounds = (
                background.get_window_extent(renderer)
                if background is not None
                else annotation.get_window_extent(renderer)
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return None
        if bounds is None or not np.isfinite(bounds.extents).all():
            return None
        return bounds

    def _start_fit_equation_drag(self, event, target: dict) -> None:
        annotation = target.get("artist")
        axes = getattr(annotation, "axes", None)
        fit_id = target.get("fit_id")
        if (
            annotation is None
            or axes is None
            or fit_id is None
            or self.canvas is None
        ):
            return
        renderer = self.canvas.get_renderer()
        bounds = self._fit_equation_annotation_bbox(annotation, renderer)
        if bounds is None:
            return
        center = np.asarray(
            (
                (bounds.x0 + bounds.x1) / 2.0,
                (bounds.y0 + bounds.y1) / 2.0,
            ),
            dtype=float,
        )
        try:
            event_position = np.asarray(
                (float(event.x), float(event.y)),
                dtype=float,
            )
        except (AttributeError, TypeError, ValueError, OverflowError):
            event_position = center.copy()
        if not np.isfinite(event_position).all():
            event_position = center.copy()

        original_anncoords = (
            annotation.get_anncoords()
            if hasattr(annotation, "get_anncoords")
            else getattr(annotation, "_textcoords", "offset points")
        )
        original_position = tuple(float(value) for value in annotation.xyann)
        original_ha = annotation.get_horizontalalignment()
        original_va = annotation.get_verticalalignment()
        had_axes_fraction = hasattr(
            annotation,
            "_easygraph_text_axes_fraction",
        )
        original_axes_fraction = getattr(
            annotation,
            "_easygraph_text_axes_fraction",
            None,
        )
        center_fraction = np.asarray(
            axes.transAxes.inverted().transform(center),
            dtype=float,
        )
        annotation.set_anncoords("axes fraction")
        annotation.xyann = (
            float(center_fraction[0]),
            float(center_fraction[1]),
        )
        annotation.set_horizontalalignment("center")
        annotation.set_verticalalignment("center")
        annotation._easygraph_text_axes_fraction = tuple(
            float(value) for value in center_fraction
        )
        self._fit_equation_drag_state = {
            "artist": annotation,
            "axes": axes,
            "fit_id": str(fit_id),
            "start": event_position,
            "offset": event_position - center,
            "position": center_fraction,
            "moved": False,
            "original_anncoords": original_anncoords,
            "original_position": original_position,
            "original_ha": original_ha,
            "original_va": original_va,
            "had_axes_fraction": had_axes_fraction,
            "original_axes_fraction": original_axes_fraction,
        }
        self._remove_feedback_patch("_hover_feedback_patch", redraw=False)
        self._hover_object_kind = None
        self._hover_series_id = None
        self._hover_artist_id = None
        self._set_plot_cursor_for_target(target)
        if self._can_blit():
            annotation.set_animated(True)
            self._invalidate_blit_background()
            self.canvas.draw()
            self._redraw_interaction_artists()

    def _drag_fit_equation_to_event(self, event) -> None:
        state = self._fit_equation_drag_state
        if state is None or self.canvas is None:
            return
        try:
            event_position = np.asarray(
                (float(event.x), float(event.y)),
                dtype=float,
            )
        except (AttributeError, TypeError, ValueError, OverflowError):
            return
        if not np.isfinite(event_position).all():
            return
        annotation = state["artist"]
        axes = state["axes"]
        renderer = self.canvas.get_renderer()
        label_bounds = self._fit_equation_annotation_bbox(
            annotation,
            renderer,
        )
        if label_bounds is None:
            return
        padding = max(
            1.0,
            float(
                renderer.points_to_pixels(
                    _FIT_EQUATION_EDGE_PADDING_POINTS
                )
            ),
        )
        axis_bounds = axes.get_window_extent(renderer)
        available = Bbox.from_extents(
            axis_bounds.x0 + padding,
            axis_bounds.y0 + padding,
            axis_bounds.x1 - padding,
            axis_bounds.y1 - padding,
        )
        desired_center = event_position - state["offset"]
        if label_bounds.width >= available.width:
            desired_center[0] = (available.x0 + available.x1) / 2.0
        else:
            desired_center[0] = min(
                max(
                    desired_center[0],
                    available.x0 + label_bounds.width / 2.0,
                ),
                available.x1 - label_bounds.width / 2.0,
            )
        if label_bounds.height >= available.height:
            desired_center[1] = (available.y0 + available.y1) / 2.0
        else:
            desired_center[1] = min(
                max(
                    desired_center[1],
                    available.y0 + label_bounds.height / 2.0,
                ),
                available.y1 - label_bounds.height / 2.0,
            )
        position = np.asarray(
            axes.transAxes.inverted().transform(desired_center),
            dtype=float,
        )
        if not np.isfinite(position).all():
            return
        position = np.clip(position, 0.0, 1.0)
        annotation.xyann = (float(position[0]), float(position[1]))
        annotation._easygraph_text_axes_fraction = tuple(
            float(value) for value in position
        )
        state["position"] = position
        if float(np.linalg.norm(event_position - state["start"])) >= 3.0:
            state["moved"] = True
        self._set_plot_cursor_for_target({"kind": "fit_equation"})
        self._redraw_interaction_artists()

    @staticmethod
    def _restore_fit_equation_annotation(state: dict) -> None:
        annotation = state["artist"]
        annotation.set_anncoords(state["original_anncoords"])
        annotation.xyann = state["original_position"]
        annotation.set_horizontalalignment(state["original_ha"])
        annotation.set_verticalalignment(state["original_va"])
        if state["had_axes_fraction"]:
            annotation._easygraph_text_axes_fraction = state[
                "original_axes_fraction"
            ]
        elif hasattr(annotation, "_easygraph_text_axes_fraction"):
            del annotation._easygraph_text_axes_fraction

    def _finish_fit_equation_drag(self) -> None:
        state = self._fit_equation_drag_state
        self._fit_equation_drag_state = None
        if state is None or self.canvas is None:
            return
        annotation = state["artist"]
        moved = bool(state["moved"])
        if not moved:
            self._restore_fit_equation_annotation(state)
        annotation.set_animated(False)
        self._invalidate_blit_background()
        self._set_plot_cursor_for_target(None)
        if moved and callable(self.fit_equation_position_callback):
            position = np.asarray(state["position"], dtype=float)
            self.fit_equation_position_callback(
                state["fit_id"],
                float(position[0]),
                float(position[1]),
            )
        else:
            self.canvas.draw_idle()

    def _discard_fit_equation_drag(self) -> None:
        state = self._fit_equation_drag_state
        self._fit_equation_drag_state = None
        if state is None:
            return
        annotation = state.get("artist")
        if annotation is not None:
            try:
                annotation.set_animated(False)
            except (AttributeError, RuntimeError):
                pass
        self._invalidate_blit_background()

    def _legend_drag_enabled(self) -> bool:
        settings = getattr(self, "_last_settings", None)
        return bool(settings is not None and settings.legend_position == LEGEND_POSITION_INSIDE)

    def _start_legend_drag(self, event, target: dict) -> None:
        legend = target.get("artist")
        bounds = self._legend_plot_union_bbox
        if legend is None or bounds is None:
            return
        bbox = target.get("bbox")
        if bbox is None:
            return
        self._legend_drag_state = {
            "legend": legend,
            "offset_x": float(getattr(event, "x", bbox.x0) - bbox.x0),
            "offset_y": float(bbox.y1 - getattr(event, "y", bbox.y1)),
            "bounds": bounds,
        }
        if self._can_blit():
            legend.set_animated(True)
            self._invalidate_blit_background()
            self.canvas.draw()

    def _drag_legend_to_event(self, event) -> None:
        state = self._legend_drag_state
        if state is None or self.figure is None or self.canvas is None:
            return
        legend = state["legend"]
        bounds = state["bounds"]
        renderer = self.canvas.get_renderer()
        legend_bbox = self._legend_outer_bbox(legend, renderer)
        left = float(getattr(event, "x", legend_bbox.x0) - state["offset_x"])
        top = float(getattr(event, "y", legend_bbox.y1) + state["offset_y"])
        left, top = self._clamped_legend_left_top(left, top, legend_bbox, bounds)
        self._set_legend_outer_left_top(legend, left, top, renderer)
        self._set_feedback_patch("_selected_feedback_patch", self._legend_outer_bbox(legend, renderer), selected=True)

    def _finish_legend_drag(self) -> None:
        state = self._legend_drag_state
        self._legend_drag_state = None
        if state is None or self.canvas is None:
            return
        legend = state["legend"]
        bounds = state["bounds"]
        renderer = self.canvas.get_renderer()
        bbox = self._legend_outer_bbox(legend, renderer)
        left, top = self._clamped_legend_left_top(bbox.x0, bbox.y1, bbox, bounds)
        anchor_left, anchor_top = self._set_legend_outer_left_top(legend, left, top, renderer)
        x, y = self._legend_inside_position_from_display(anchor_left, anchor_top, bounds)
        legend.set_animated(False)
        self._invalidate_blit_background()
        if callable(self.legend_position_callback):
            self.legend_position_callback(x, y)
        else:
            self.canvas.draw_idle()

    def _clamped_legend_left_top(self, left: float, top: float, legend_bbox, bounds) -> tuple[float, float]:
        max_left = bounds.x1 - legend_bbox.width
        min_top = bounds.y0 + legend_bbox.height
        if max_left < bounds.x0:
            left = bounds.x0
        else:
            left = min(max(left, bounds.x0), max_left)
        if min_top > bounds.y1:
            top = bounds.y1
        else:
            top = min(max(top, min_top), bounds.y1)
        return (float(left), float(top))

    def _legend_inside_position_from_display(self, left: float, top: float, bounds) -> tuple[float, float]:
        return (
            min(max((left - bounds.x0) / max(bounds.width, 1.0), 0.0), 1.0),
            min(max((bounds.y1 - top) / max(bounds.height, 1.0), 0.0), 1.0),
        )

    def clear_plot_selection(self) -> None:
        self._set_xy_box_select_enabled(False)
        self._selected_object_kind = None
        self._xy_selection_scope = "none"
        self._selected_series_ids.clear()
        self._selected_series_id = None
        self._selected_additional_guide_axis_key = None
        self._selected_additional_guide_index = None
        self._set_feedback_patch("_selected_feedback_patch", None, selected=True)
        if callable(self.selection_callback):
            self.selection_callback(None)

    def set_xy_series_selection(self, scope: str, ids=None) -> None:
        """Set the XY editing scope and refresh its plot feedback.

        ``all`` is deliberately distinct from a ``subset`` containing every
        series: the former edits global defaults, while the latter edits
        per-series overrides. A subset may be empty or contain hidden series.
        """
        normalized_scope = str(scope).strip().lower()
        if normalized_scope not in {"none", "all", "subset"}:
            raise ValueError(f"Unsupported XY selection scope: {scope!r}")
        if isinstance(ids, str):
            normalized_ids = {ids}
        else:
            normalized_ids = {
                str(series_id)
                for series_id in (() if ids is None else ids)
                if series_id is not None
            }
        if normalized_scope != "subset":
            normalized_ids.clear()

        self._cancel_xy_box_drag(redraw=False)
        self._xy_selection_scope = normalized_scope
        self._selected_series_ids = normalized_ids
        self._selected_series_id = (
            next(iter(normalized_ids))
            if normalized_scope == "subset" and len(normalized_ids) == 1
            else None
        )
        self._selected_object_kind = (
            "points" if normalized_scope in {"all", "subset"} else None
        )
        self._selected_additional_guide_axis_key = None
        self._selected_additional_guide_index = None
        self._set_xy_series_selection_feedback()
        if callable(self.selection_callback):
            self.selection_callback(self._selected_object_kind)

    def _all_xy_series_ids(self) -> set[str]:
        xy_settings = getattr(self, "_last_xy_settings", None)
        if xy_settings is None:
            return set()
        return {
            str(series.id)
            for series in getattr(xy_settings, "series", ())
        }

    def _clear_plot_feedback(self, clear_selection: bool = True) -> None:
        self._xy_box_select_state = None
        self._hover_object_kind = None
        self._hover_series_id = None
        self._hover_artist_id = None
        if clear_selection:
            self._selected_object_kind = None
            self._xy_selection_scope = "none"
            self._selected_series_ids.clear()
            self._selected_series_id = None
            self._selected_additional_guide_axis_key = None
            self._selected_additional_guide_index = None
        self._remove_feedback_patch("_xy_box_selection_patch", redraw=False)
        self._remove_feedback_patch("_hover_feedback_patch", redraw=False)
        self._remove_feedback_patch("_selected_feedback_patch", redraw=False)

    def _feedback_bboxes_for_target(self, target):
        if target is None:
            return None
        return target.get("feedback_bboxes") or target.get("bbox")

    def _hover_feedback_bboxes_for_target(self, target):
        if target is None:
            return None
        return target.get("hover_feedback_bboxes") or self._feedback_bboxes_for_target(
            target
        )

    def _selection_kind_for_target(self, target) -> str | None:
        if target is None:
            return None
        return str(target.get("selection_kind") or target["kind"])

    def selected_additional_guide(self) -> tuple[str, int] | None:
        if (
            self._selected_object_kind != "additional_grid_line"
            or self._selected_additional_guide_axis_key not in {"x", "primary"}
            or self._selected_additional_guide_index is None
        ):
            return None
        return (
            self._selected_additional_guide_axis_key,
            int(self._selected_additional_guide_index),
        )

    def focus_additional_guide(self, axis_key: str, guide_index: int) -> bool:
        """Synchronize table selection with a visible guide-line highlight."""

        normalized_axis_key = str(axis_key)
        normalized_index = int(guide_index)
        target = next(
            (
                item
                for item in self._interaction_targets
                if item.get("kind") == "additional_grid_line"
                and item.get("guide_axis_key") == normalized_axis_key
                and item.get("guide_index") == normalized_index
            ),
            None,
        )
        if target is None:
            self.clear_additional_guide_focus()
            return False

        self._selected_object_kind = "additional_grid_line"
        self._selected_series_id = None
        self._selected_additional_guide_axis_key = normalized_axis_key
        self._selected_additional_guide_index = normalized_index
        self._set_feedback_artists(
            "_selected_feedback_patch",
            [target.get("artist")],
            selected=True,
        )
        return True

    def clear_additional_guide_focus(self) -> None:
        """Clear table-driven guide feedback without changing UI context."""

        if self._selected_object_kind != "additional_grid_line":
            return
        self._selected_object_kind = None
        self._selected_additional_guide_axis_key = None
        self._selected_additional_guide_index = None
        self._set_feedback_patch(
            "_selected_feedback_patch",
            None,
            selected=True,
        )

    def _register_additional_guide_lines(
        self,
        ax,
        artists,
        *,
        axis_key: str,
    ) -> None:
        for artist in artists:
            if not isinstance(artist, Line2D):
                continue
            if artist.get_gid() != "additional-grid-line":
                continue
            try:
                guide_index = int(
                    getattr(artist, "_easygraph_additional_guide_index")
                )
            except (AttributeError, TypeError, ValueError, OverflowError):
                continue
            artist._easygraph_additional_guide_axis_key = axis_key
            self._additional_guide_line_artists = [
                record
                for record in self._additional_guide_line_artists
                if record.get("artist") is not artist
            ]
            self._additional_guide_line_artists.append(
                {
                    "artist": artist,
                    "axis": ax,
                    "axis_key": axis_key,
                    "guide_index": guide_index,
                }
            )

    def _series_id_for_target(self, target) -> str | None:
        if target is None or target.get("series_id") is None:
            return None
        return str(target["series_id"])

    def _is_xy_series_target(self, target) -> bool:
        return bool(
            target is not None
            and target.get("kind") == "points"
            and getattr(self, "_last_xy_settings", None) is not None
            and target.get("artist") is not None
        )

    def _plot_point_artists(self, series_ids=None) -> list:
        if isinstance(series_ids, str):
            selected_ids = {series_ids}
        elif series_ids is None:
            selected_ids = None
        else:
            selected_ids = {str(series_id) for series_id in series_ids}
        plot_targets = [
            target
            for target in self._interaction_targets
            if target.get("kind") == "points"
            and target.get("source") == "plot"
            and (
                selected_ids is None
                or self._series_id_for_target(target) in selected_ids
            )
        ]
        # Hit testing walks artists front-to-back. Feedback must be painted in
        # the original back-to-front order so selecting every series does not
        # visually invert which series is on top at crossings.
        plot_targets.sort(
            key=lambda target: (
                float(target.get("draw_zorder", 0.0)),
                int(target.get("draw_index", -1)),
            )
        )
        artists = []
        seen = set()
        for target in plot_targets:
            artist = target.get("artist")
            if artist is None or id(artist) in seen:
                continue
            seen.add(id(artist))
            artists.append(artist)
        return artists

    def _xy_plot_series_artists(self, series_ids=None) -> list:
        return self._plot_point_artists(series_ids)

    def _set_xy_series_selection_feedback(self) -> None:
        if self._xy_selection_scope == "all":
            series_ids = None
        elif self._xy_selection_scope == "subset":
            series_ids = self._selected_series_ids
        else:
            series_ids = set()
        self._set_feedback_artists(
            "_selected_feedback_patch",
            self._xy_plot_series_artists(series_ids),
            selected=True,
        )

    def _restore_plot_selection_after_target_refresh(self) -> None:
        selected_kind = self._selected_object_kind
        selected_series_id = self._selected_series_id
        if selected_kind is None:
            return
        if (
            selected_kind == "points"
            and getattr(self, "_last_xy_settings", None) is not None
        ):
            if self._xy_selection_scope == "none":
                # Preserve compatibility with callers that populated the
                # former single-ID field directly.
                if selected_series_id is None:
                    self._xy_selection_scope = "all"
                    self._selected_series_ids.clear()
                else:
                    self._xy_selection_scope = "subset"
                    self._selected_series_ids = {str(selected_series_id)}
            if self._xy_selection_scope == "subset":
                self._selected_series_ids.intersection_update(
                    self._all_xy_series_ids()
                )
                self._selected_series_id = (
                    next(iter(self._selected_series_ids))
                    if len(self._selected_series_ids) == 1
                    else None
                )
            self._set_xy_series_selection_feedback()
            return
        if selected_kind == "points":
            point_artists = self._plot_point_artists()
            if not point_artists:
                self.clear_plot_selection()
                return
            self._set_feedback_artists(
                "_selected_feedback_patch",
                point_artists,
                selected=True,
            )
            return
        selected_target = next(
            (
                target
                for target in self._interaction_targets
                if self._selection_kind_for_target(target) == selected_kind
                and self._series_id_for_target(target) == selected_series_id
                and (
                    selected_kind != "additional_grid_line"
                    or (
                        target.get("guide_axis_key")
                        == self._selected_additional_guide_axis_key
                        and target.get("guide_index")
                        == self._selected_additional_guide_index
                    )
                )
            ),
            None,
        )
        if selected_target is None:
            self.clear_plot_selection()
            return
        if selected_kind == "additional_grid_line":
            self._set_feedback_artists(
                "_selected_feedback_patch",
                [selected_target.get("artist")],
                selected=True,
            )
        else:
            self._set_feedback_patch(
                "_selected_feedback_patch",
                self._feedback_bboxes_for_target(selected_target),
                selected=True,
            )

    def _set_feedback_artists(
        self,
        attribute: str,
        source_artists,
        *,
        selected: bool,
        figure_level: bool = False,
    ) -> None:
        self._remove_feedback_patch(attribute, redraw=False)
        if not source_artists or self.figure is None or self.canvas is None:
            self._redraw_interaction_artists()
            return
        feedback_artists = []
        seen = set()
        for source in source_artists:
            if not isinstance(source, (Line2D, PathCollection)):
                continue
            if id(source) in seen:
                continue
            seen.add(id(source))
            highlight_color = "#2563EB" if selected else "#60A5FA"
            stroke_delta = 4.0 if selected else 2.5
            source_feedback = []
            if isinstance(source, PathCollection):
                feedback = copy(source)
                linewidths = np.asarray(source.get_linewidths(), dtype=float)
                finite_linewidths = linewidths[np.isfinite(linewidths)]
                base_linewidth = (
                    float(np.max(finite_linewidths))
                    if finite_linewidths.size
                    else 1.0
                )
                feedback.set_facecolor("none")
                feedback.set_edgecolor(highlight_color)
                feedback.set_linewidth(base_linewidth + stroke_delta / 2.0)
                feedback.set_alpha(1.0)
                feedback.set_path_effects([])
                source_feedback.append(feedback)
            else:
                marker = source.get_marker()
                line_style = source.get_linestyle()
                has_marker = (
                    marker is not None
                    and str(marker).strip().lower() not in {"", "none"}
                )
                has_line = (
                    line_style is not None
                    and str(line_style).strip().lower() not in {"", "none"}
                )
                if has_line:
                    line_feedback = copy(source)
                    line_feedback.set_marker("None")
                    line_feedback.set_alpha(1.0)
                    line_feedback.set_path_effects(
                        [
                            patheffects.Stroke(
                                linewidth=(
                                    float(source.get_linewidth()) + stroke_delta
                                ),
                                foreground=highlight_color,
                            ),
                            patheffects.Normal(),
                        ]
                    )
                    source_feedback.append(line_feedback)
                if has_marker:
                    marker_feedback = copy(source)
                    marker_feedback.set_linestyle("None")
                    marker_feedback.set_markerfacecolor("none")
                    marker_feedback.set_markeredgecolor(highlight_color)
                    marker_feedback.set_markeredgewidth(
                        max(float(source.get_markeredgewidth()), 1.0)
                        + stroke_delta / 2.0
                    )
                    marker_feedback.set_alpha(1.0)
                    marker_feedback.set_path_effects([])
                    source_feedback.append(marker_feedback)

            for feedback in source_feedback:
                feedback._remove_method = None
                feedback.set_gid("interaction-feedback")
                feedback.set_label("_nolegend_")
                feedback.set_picker(False)
                feedback.set_zorder(
                    (1001 if selected else 1002)
                    if figure_level
                    else (4.0 if selected else 4.1)
                )
                feedback.set_animated(self._can_blit())
                feedback._easygraph_feedback_source = source
                feedback._easygraph_feedback_selected = bool(selected)
                feedback._easygraph_feedback_figure_level = bool(
                    figure_level or source.axes is None
                )
                if feedback._easygraph_feedback_figure_level:
                    self.figure.add_artist(feedback)
                else:
                    # Plot halos belong to their source Axes. This retains
                    # plot clipping and keeps them below an inside legend.
                    # Legend handles remain figure-level because they may sit
                    # outside the Axes.
                    source.axes.add_artist(feedback)
                feedback_artists.append(feedback)
        setattr(self, attribute, feedback_artists or None)
        self._redraw_interaction_artists()

    def _set_feedback_patch(self, attribute: str, bboxes, selected: bool) -> None:
        self._remove_feedback_patch(attribute, redraw=False)
        if bboxes is None or self.figure is None or self.canvas is None:
            self._redraw_interaction_artists()
            return
        if not isinstance(bboxes, (list, tuple)):
            bboxes = [bboxes]
        patches = []
        for bbox in bboxes:
            x0, y0, x1, y1 = self._bbox_to_figure_rect(bbox)
            if x1 <= x0 or y1 <= y0:
                continue
            patch = Rectangle(
                (x0, y0),
                x1 - x0,
                y1 - y0,
                transform=self.figure.transFigure,
                facecolor="#2563EB",
                edgecolor="#2563EB",
                alpha=0.08 if selected else 0.045,
                linewidth=1.5 if selected else 1.0,
                linestyle="-" if selected else "--",
                zorder=1000,
                clip_on=False,
            )
            patch.set_animated(self._can_blit())
            patch._easygraph_feedback_figure_level = True
            self.figure.add_artist(patch)
            patches.append(patch)
        setattr(self, attribute, patches or None)
        self._redraw_interaction_artists()

    def _remove_feedback_patch(self, attribute: str, *, redraw: bool = True) -> None:
        patches = getattr(self, attribute, None)
        if patches is None:
            setattr(self, attribute, None)
            return
        if not isinstance(patches, (list, tuple)):
            patches = [patches]
        for patch in patches:
            try:
                patch.remove()
            except ValueError:
                pass
        setattr(self, attribute, None)
        if redraw:
            self._redraw_interaction_artists()

    def _can_blit(self) -> bool:
        return bool(
            self.figure is not None
            and self.canvas is not None
            and getattr(self.canvas, "supports_blit", False)
        )

    def _invalidate_blit_background(self) -> None:
        self._blit_background = None

    def _handle_canvas_resize(self, _event) -> None:
        self._invalidate_blit_background()

    def _handle_canvas_draw(self, event) -> None:
        if event.canvas is not self.canvas or not self._can_blit() or self._blit_redrawing:
            return
        try:
            self._blit_background = self.canvas.copy_from_bbox(self.figure.bbox)
            if self._interaction_artists() and not self._blit_refresh_pending:
                self._blit_refresh_pending = True
                canvas = self.canvas
                QTimer.singleShot(
                    0,
                    canvas,
                    lambda: self._finish_canvas_draw_blit(canvas),
                )
        except (AttributeError, RuntimeError, ValueError):
            self._invalidate_blit_background()

    def _finish_canvas_draw_blit(self, canvas) -> None:
        self._blit_refresh_pending = False
        if canvas is self.canvas:
            self._redraw_interaction_artists()

    def _interaction_artists(self) -> list:
        artists = []
        if self._fit_equation_drag_state is not None:
            annotation = self._fit_equation_drag_state.get("artist")
            if annotation is not None:
                artists.append(annotation)
        if self._legend_drag_state is not None:
            legend = self._legend_drag_state.get("legend")
            if legend is not None:
                artists.append(legend)
        for attribute in (
            "_selected_feedback_patch",
            "_hover_feedback_patch",
            "_xy_box_selection_patch",
        ):
            value = getattr(self, attribute, None)
            if value is None:
                continue
            artists.extend(value if isinstance(value, (list, tuple)) else [value])
        return artists

    def _draw_animated_interaction_artists(self) -> None:
        artists = self._interaction_artists()
        plot_feedback = [
            artist
            for artist in artists
            if getattr(artist, "_easygraph_feedback_figure_level", None) is False
        ]
        upper_artists = [
            artist
            for artist in artists
            if getattr(artist, "_easygraph_feedback_figure_level", None) is not False
        ]
        feedback_axes = []
        seen_axes = set()
        for artist in plot_feedback:
            axes = getattr(artist, "axes", None)
            if axes is not None and id(axes) not in seen_axes:
                seen_axes.add(id(axes))
                feedback_axes.append(axes)
        upper_ids = {id(artist) for artist in upper_artists}
        protected_legend_regions = []
        for axes in feedback_axes:
            legend = axes.get_legend()
            if (
                legend is not None
                and legend.get_visible()
                and id(legend) not in upper_ids
            ):
                legend_bbox = Bbox.intersection(
                    self._padded_bbox(
                        self._legend_outer_bbox(
                            legend,
                            self.canvas.get_renderer(),
                        ),
                        5.0,
                    ),
                    self.figure.bbox,
                )
                if legend_bbox is not None:
                    protected_legend_regions.append(
                        self.canvas.copy_from_bbox(legend_bbox)
                    )
        for artist in plot_feedback:
            axes = getattr(artist, "axes", None)
            if axes is not None:
                axes.draw_artist(artist)
            else:
                self.figure.draw_artist(artist)
        # The cached full background already contains non-animated legends.
        # Restoring their original pixels keeps plot halos below translucent
        # legend frames without compositing the legend a second time.
        for region in protected_legend_regions:
            self.canvas.restore_region(region)
        for artist in upper_artists:
            axes = getattr(artist, "axes", None)
            if axes is not None:
                axes.draw_artist(artist)
            else:
                self.figure.draw_artist(artist)

    def _redraw_interaction_artists(self) -> None:
        if self.canvas is None:
            return
        if not self._can_blit() or self._blit_background is None:
            self.canvas.draw_idle()
            return
        try:
            self._blit_redrawing = True
            self.canvas.restore_region(self._blit_background)
            self._draw_animated_interaction_artists()
            self.canvas.blit(self.figure.bbox)
        except (AttributeError, RuntimeError, ValueError):
            self._invalidate_blit_background()
            self.canvas.draw_idle()
        finally:
            self._blit_redrawing = False

    def _bbox_to_figure_rect(self, bbox) -> tuple[float, float, float, float]:
        padded = self._padded_bbox(bbox, 4.0)
        (x0, y0), (x1, y1) = self.figure.transFigure.inverted().transform(
            [(padded.x0, padded.y0), (padded.x1, padded.y1)]
        )
        return (
            min(max(float(x0), 0.0), 1.0),
            min(max(float(y0), 0.0), 1.0),
            min(max(float(x1), 0.0), 1.0),
            min(max(float(y1), 0.0), 1.0),
        )

    def _refresh_interaction_targets(self, settings: ChartSettings, ax, table_ax, secondary_ax) -> None:
        if self.canvas is None or self.figure is None:
            self._interaction_targets = []
            return
        renderer = self.canvas.get_renderer()
        targets: list[dict] = []
        for record in self._additional_guide_line_artists:
            line = record.get("artist")
            line_axis = record.get("axis")
            if not isinstance(line, Line2D) or line_axis is None:
                continue
            interaction_bbox = self._interaction_artist_bbox(
                line,
                line_axis,
                renderer,
            )
            if interaction_bbox is None:
                continue
            line.set_picker(6)
            draw_indices = {
                id(artist): index
                for index, artist in enumerate(line_axis.get_children())
            }
            targets.append(
                {
                    "kind": "additional_grid_line",
                    "artist": line,
                    "bbox": interaction_bbox,
                    "clip_bbox": line_axis.get_window_extent(renderer),
                    "priority": 25,
                    "draw_zorder": float(line.get_zorder()),
                    "draw_index": draw_indices.get(id(line), -1),
                    "guide_axis_key": record.get("axis_key"),
                    "guide_index": record.get("guide_index"),
                    "source": "additional-guide",
                }
            )
        for axis in self.figure.axes:
            axis_clip_bbox = axis.get_window_extent(renderer)
            draw_indices = {
                id(artist): index
                for index, artist in enumerate(axis.get_children())
            }
            for text in axis.texts:
                if (
                    text.get_gid() != "xy-fit-equation"
                    or not text.get_visible()
                ):
                    continue
                interaction_bbox = self._fit_equation_annotation_bbox(
                    text,
                    renderer,
                )
                fit_id = getattr(text, "_easygraph_fit_id", None)
                if interaction_bbox is None or fit_id is None:
                    continue
                text.set_picker(False)
                targets.append(
                    {
                        "kind": "fit_equation",
                        "artist": text,
                        "use_artist_contains": False,
                        "bbox": interaction_bbox,
                        "clip_bbox": axis_clip_bbox,
                        "priority": -5,
                        "draw_zorder": float(text.get_zorder()),
                        "draw_index": draw_indices.get(id(text), -1),
                        "fit_id": str(fit_id),
                        "series_id": getattr(
                            text,
                            "_easygraph_series_id",
                            None,
                        ),
                        "source": "plot",
                    }
                )
            for line in axis.lines:
                line_kind = {
                    "overlay-line": "line_overlay",
                    "data-points": "points",
                }.get(line.get_gid())
                if line_kind is not None:
                    interaction_bbox = self._interaction_artist_bbox(
                        line,
                        axis,
                        renderer,
                    )
                    if interaction_bbox is None:
                        continue
                    line.set_picker(6)
                    targets.append(
                        {
                            "kind": line_kind,
                            "artist": line,
                            "bbox": interaction_bbox,
                            "clip_bbox": axis_clip_bbox,
                            "priority": 10 if line_kind == "line_overlay" else 20,
                            "draw_zorder": float(line.get_zorder()),
                            "draw_index": draw_indices.get(id(line), -1),
                            "series_id": getattr(line, "_easygraph_series_id", None),
                            "source": "plot",
                        }
                    )
            for collection in axis.collections:
                collection_kind = {
                    "data-points": "points",
                    "outliers": "outliers",
                }.get(collection.get_gid())
                if collection_kind is not None:
                    interaction_bbox = self._interaction_artist_bbox(
                        collection,
                        axis,
                        renderer,
                    )
                    if interaction_bbox is None:
                        continue
                    collection.set_picker(6)
                    targets.append(
                        {
                            "kind": collection_kind,
                            "artist": collection,
                            "bbox": interaction_bbox,
                            "clip_bbox": axis_clip_bbox,
                            "priority": 15 if collection_kind == "outliers" else 20,
                            "draw_zorder": float(collection.get_zorder()),
                            "draw_index": draw_indices.get(id(collection), -1),
                            "series_id": getattr(collection, "_easygraph_series_id", None),
                            "source": "plot",
                        }
                    )

        legend = ax.get_legend()
        if legend is not None and legend.get_visible():
            if getattr(self, "_last_xy_settings", None) is not None:
                source_handles, _source_labels = ax.get_legend_handles_labels()
                legend_handles = list(getattr(legend, "legend_handles", []))
                legend_texts = list(legend.get_texts())
                for source_artist, legend_handle, legend_text in zip(
                    source_handles,
                    legend_handles,
                    legend_texts,
                ):
                    series_id = getattr(source_artist, "_easygraph_series_id", None)
                    if series_id is None:
                        continue
                    text_bbox = legend_text.get_window_extent(renderer)
                    handle_bbox = legend_handle.get_window_extent(renderer)
                    if np.isfinite(handle_bbox.extents).all():
                        legend_artist_bbox = handle_bbox
                    else:
                        handle_width = (
                            float(legend.handlelength + legend.handletextpad)
                            * float(legend_text.get_fontsize())
                            * float(self.figure.dpi)
                            / 72.0
                        )
                        legend_artist_bbox = Bbox.from_extents(
                            text_bbox.x0 - handle_width,
                            text_bbox.y0,
                            text_bbox.x0,
                            text_bbox.y1,
                        )
                    legend_handle.set_picker(6)
                    source_feedback_bbox = self._interaction_artist_bbox(
                        source_artist,
                        source_artist.axes,
                        renderer,
                    )
                    targets.append(
                        {
                            "kind": "points",
                            "artist": legend_handle,
                            "bbox": legend_artist_bbox,
                            "hover_feedback_bboxes": legend_artist_bbox,
                            "feedback_bboxes": (
                                source_feedback_bbox
                                if source_feedback_bbox is not None
                                else legend_artist_bbox
                            ),
                            "priority": -1,
                            "series_id": str(series_id),
                            "source": "legend",
                        }
                    )
            targets.append(
                {
                    "kind": "legend",
                    "artist": legend,
                    "use_artist_contains": False,
                    "bbox": self._legend_outer_bbox(legend, renderer),
                    "priority": 0,
                }
            )
        if table_ax is not None:
            targets.append(
                {
                    "kind": "stats_table",
                    "bbox": (
                        self._ridge_stat_table_bounds(table_ax, renderer)
                        if table_ax.get_gid() == "ridge-stat-table"
                        else table_ax.get_window_extent(renderer)
                    ),
                    "priority": 5,
                }
            )
        split_secondary_frame = self._split_secondary_frame_enabled(settings)
        plot_axes = [candidate for candidate in (ax, secondary_ax) if candidate is not None]
        self._legend_plot_union_bbox = self._inside_legend_bounds(plot_axes, renderer, settings)
        if getattr(self, "_last_xy_settings", None) is None:
            for plot_axis in plot_axes:
                target = {
                    "kind": "plot_area",
                    "bbox": plot_axis.get_window_extent(renderer),
                    "priority": 80,
                }
                if split_secondary_frame and plot_axis is secondary_ax:
                    target["selection_kind"] = "line_overlay"
                targets.append(
                    target
                )
        category_dimension = "y" if settings.chart_type == "Ridge" else "x"
        value_dimension = "x" if settings.chart_type == "Ridge" else "y"
        category_side = "left" if settings.chart_type == "Ridge" else "bottom"
        primary_side = "bottom" if settings.chart_type == "Ridge" else "left"
        secondary_side = "top" if settings.chart_type == "Ridge" else "right"
        for kind, axis, dimension, side in (
            ("category_axis", ax, category_dimension, category_side),
            ("primary_axis", ax, value_dimension, primary_side),
            ("secondary_axis", secondary_ax, value_dimension, secondary_side),
        ):
            if axis is None:
                continue
            axis_boxes = self._axis_dimension_interaction_boxes(
                axis,
                renderer,
                dimension=dimension,
                side=side,
            )
            if not axis_boxes:
                continue
            targets.append(
                {
                    "kind": kind,
                    "bbox": Bbox.union(axis_boxes),
                    "hit_bboxes": axis_boxes,
                    "feedback_bboxes": [
                        self._axis_side_feedback_box(axis, renderer, side=side)
                    ],
                    "priority": 30,
                }
            )
        title_boxes = self._title_interaction_boxes(plot_axes, renderer)
        if title_boxes:
            targets.append(
                {
                    "kind": "title_axis",
                    "bbox": Bbox.union(title_boxes),
                    "hit_bboxes": title_boxes,
                    "feedback_bboxes": title_boxes,
                    "priority": 25,
                }
            )
        self._interaction_targets = sorted(
            targets,
            key=lambda target: (
                int(target.get("priority", 100)),
                -float(target.get("draw_zorder", 0.0)),
                -int(target.get("draw_index", -1)),
            ),
        )
        self._restore_plot_selection_after_target_refresh()

    def _interaction_target_at_event(self, event, include_point_targets: bool = True):
        x = getattr(event, "x", None)
        y = getattr(event, "y", None)
        if x is None or y is None:
            return None
        for target in self._interaction_targets:
            if not include_point_targets and target.get("kind") in {"points", "outliers"}:
                continue
            artist = target.get("artist")
            if artist is not None and target.get("use_artist_contains", True):
                clip_bbox = target.get("clip_bbox")
                if clip_bbox is not None and not clip_bbox.contains(x, y):
                    continue
                try:
                    contains, _details = artist.contains(event)
                except Exception:
                    contains = False
                if contains:
                    return target
                continue
            bbox = target.get("bbox")
            hit_bboxes = target.get("hit_bboxes")
            if hit_bboxes is not None and any(hit_bbox.contains(x, y) for hit_bbox in hit_bboxes):
                return target
            if hit_bboxes is None and bbox is not None and bbox.contains(x, y):
                return target
        return None

    def _xy_series_ids_intersecting_bbox(self, selection_bbox) -> set[str]:
        """Return series whose visible Line2D/marker geometry meets a box."""
        if selection_bbox is None or not np.isfinite(selection_bbox.extents).all():
            return set()
        selection_fragments = self._xy_selection_fragments_outside_legend(
            selection_bbox
        )
        if not selection_fragments:
            return set()
        selected_ids: set[str] = set()
        for target in self._interaction_targets:
            if target.get("kind") != "points" or target.get("source") != "plot":
                continue
            series_id = self._series_id_for_target(target)
            artist = target.get("artist")
            if series_id is None or not isinstance(artist, (Line2D, PathCollection)):
                continue
            clip_bbox = target.get("clip_bbox")
            for selection_fragment in selection_fragments:
                visible_selection = (
                    Bbox.intersection(selection_fragment, clip_bbox)
                    if clip_bbox is not None
                    else selection_fragment
                )
                if visible_selection is None:
                    continue
                if self._xy_artist_intersects_display_bbox(
                    artist,
                    visible_selection,
                    clip_bbox,
                ):
                    selected_ids.add(series_id)
                    break
        return selected_ids

    def _xy_selection_fragments_outside_legend(self, selection_bbox) -> list:
        settings = getattr(self, "_last_settings", None)
        if (
            settings is None
            or settings.legend_position != LEGEND_POSITION_INSIDE
            or self.figure is None
            or self.canvas is None
        ):
            return [selection_bbox]
        renderer = self.canvas.get_renderer()
        legend_bbox = None
        for axis in self.figure.axes:
            legend = axis.get_legend()
            if legend is None or not legend.get_visible():
                continue
            candidate = self._legend_outer_bbox(legend, renderer)
            if candidate is not None and np.isfinite(candidate.extents).all():
                legend_bbox = candidate
                break
        if legend_bbox is None:
            return [selection_bbox]
        return self._xy_bbox_fragments_after_subtraction(
            selection_bbox,
            legend_bbox,
        )

    def _xy_bbox_fragments_after_subtraction(self, bbox, occluder) -> list:
        overlap = Bbox.intersection(bbox, occluder)
        if overlap is None:
            return [bbox]
        candidates = (
            # Full-width strips above and below the overlap.
            (bbox.x0, overlap.y1, bbox.x1, bbox.y1),
            (bbox.x0, bbox.y0, bbox.x1, overlap.y0),
            # Side strips cover only the overlap's vertical span, keeping all
            # four returned rectangles pairwise non-overlapping.
            (bbox.x0, overlap.y0, overlap.x0, overlap.y1),
            (overlap.x1, overlap.y0, bbox.x1, overlap.y1),
        )
        return [
            Bbox.from_extents(x0, y0, x1, y1)
            for x0, y0, x1, y1 in candidates
            if x1 > x0 and y1 > y0
        ]

    def _xy_artist_intersects_display_bbox(
        self,
        artist,
        selection_bbox,
        clip_bbox,
    ) -> bool:
        if not artist.get_visible():
            return False
        alpha = artist.get_alpha()
        if alpha is not None and float(alpha) <= 0.0:
            return False
        if isinstance(artist, PathCollection):
            return self._xy_path_collection_intersects_bbox(
                artist,
                selection_bbox,
                clip_bbox,
            )
        if not isinstance(artist, Line2D):
            return False
        return self._xy_line2d_intersects_bbox(
            artist,
            selection_bbox,
            clip_bbox,
        )

    def _xy_clipped_padded_bbox(self, bbox, padding: float, clip_bbox):
        padded = Bbox.from_extents(
            bbox.x0 - padding,
            bbox.y0 - padding,
            bbox.x1 + padding,
            bbox.y1 + padding,
        )
        if clip_bbox is None:
            return padded
        return Bbox.intersection(padded, clip_bbox)

    def _xy_color_is_visible(self, color) -> bool:
        if color is None or str(color).strip().lower() == "none":
            return False
        try:
            return float(to_rgba(color)[3]) > 0.0
        except (TypeError, ValueError):
            return True

    def _xy_line2d_intersects_bbox(
        self,
        artist: Line2D,
        selection_bbox,
        clip_bbox,
    ) -> bool:
        line_style = artist.get_linestyle()
        has_line = (
            line_style is not None
            and str(line_style).strip().lower() not in {"", "none"}
            and float(artist.get_linewidth()) > 0.0
            and self._xy_color_is_visible(artist.get_color())
        )
        if has_line:
            stroke_radius = (
                float(artist.get_linewidth())
                * float(self.figure.dpi)
                / 144.0
            )
            line_bbox = self._xy_clipped_padded_bbox(
                selection_bbox,
                stroke_radius,
                clip_bbox,
            )
            if line_bbox is not None:
                try:
                    display_path = artist.get_path().transformed(
                        artist.get_transform()
                    ).cleaned(remove_nans=True)
                    # intersects_bbox can bridge MOVETO boundaries. Check each
                    # continuous subpath separately so missing data and parent
                    # breaks cannot select a line through an empty gap.
                    starts = np.flatnonzero(display_path.codes == MplPath.MOVETO)
                    for start, end in zip(starts, [*starts[1:], len(display_path.vertices)]):
                        subpath = MplPath(display_path.vertices[start:end], display_path.codes[start:end])
                        if subpath.intersects_bbox(line_bbox, filled=False):
                            return True
                except (AttributeError, TypeError, ValueError):
                    pass

        marker = artist.get_marker()
        has_marker = (
            marker is not None
            and str(marker).strip().lower() not in {"", "none"}
            and float(artist.get_markersize()) > 0.0
        )
        if not has_marker:
            return False
        try:
            marker_style = MarkerStyle(marker)
            marker_path = marker_style.get_path().transformed(
                marker_style.get_transform()
            )
        except (TypeError, ValueError):
            return False
        marker_face_visible = (
            marker_style.is_filled()
            and self._xy_color_is_visible(artist.get_markerfacecolor())
        )
        marker_edge_width = max(float(artist.get_markeredgewidth()), 0.0)
        marker_edge_visible = (
            marker_edge_width > 0.0
            and self._xy_color_is_visible(artist.get_markeredgecolor())
        )
        if not marker_face_visible and not marker_edge_visible:
            return False

        marker_scale = (
            float(artist.get_markersize())
            * float(self.figure.dpi)
            / 72.0
        )
        try:
            display_vertices = artist.get_transform().transform(
                artist.get_path().vertices
            )
        except (AttributeError, TypeError, ValueError):
            return False
        marker_radius = (
            marker_scale / 2.0
            + marker_edge_width * self.figure.dpi / 144.0
        )
        nearby = display_vertices[
            np.isfinite(display_vertices).all(axis=1)
            & (display_vertices[:, 0] >= selection_bbox.x0 - marker_radius)
            & (display_vertices[:, 0] <= selection_bbox.x1 + marker_radius)
            & (display_vertices[:, 1] >= selection_bbox.y0 - marker_radius)
            & (display_vertices[:, 1] <= selection_bbox.y1 + marker_radius)
        ]
        if not nearby.size:
            return False
        marker_edge_bbox = self._xy_clipped_padded_bbox(
            selection_bbox,
            marker_edge_width * float(self.figure.dpi) / 144.0,
            clip_bbox,
        )
        for x, y in nearby:
            display_marker = marker_path.transformed(
                Affine2D().scale(marker_scale).translate(float(x), float(y))
            )
            if marker_face_visible and display_marker.intersects_bbox(
                selection_bbox,
                filled=True,
            ):
                return True
            if (
                marker_edge_visible
                and marker_edge_bbox is not None
                and display_marker.intersects_bbox(marker_edge_bbox, filled=False)
            ):
                return True
        return False

    def _xy_path_collection_intersects_bbox(
        self,
        artist: PathCollection,
        selection_bbox,
        clip_bbox,
    ) -> bool:
        paths = list(artist.get_paths())
        if not paths:
            return False
        offsets = np.ma.asarray(artist.get_offsets(), dtype=float)
        if np.ma.isMaskedArray(offsets):
            offsets = offsets.filled(np.nan)
        offsets = np.asarray(offsets, dtype=float)
        if offsets.ndim != 2 or offsets.shape[1] < 2 or not offsets.size:
            return False
        try:
            display_offsets = artist.get_offset_transform().transform(
                offsets[:, :2]
            )
        except (AttributeError, TypeError, ValueError):
            return False

        transforms = np.asarray(artist.get_transforms(), dtype=float)
        path_transform = artist.get_transform()
        linewidths = np.asarray(artist.get_linewidths(), dtype=float)
        finite_linewidths = linewidths[np.isfinite(linewidths)]
        max_linewidth = (
            max(float(np.max(finite_linewidths)), 0.0)
            if finite_linewidths.size
            else 0.0
        )
        edge_radius = max_linewidth * float(self.figure.dpi) / 144.0

        max_path_extent = max(
            (
                float(np.nanmax(np.abs(path.vertices)))
                for path in paths
                if path.vertices.size and np.isfinite(path.vertices).any()
            ),
            default=0.0,
        )
        if transforms.size:
            max_transform_scale = max(
                float(np.linalg.norm(matrix[:2, :2], ord=2))
                for matrix in transforms
            )
        else:
            max_transform_scale = 1.0
        max_radius = max_path_extent * max_transform_scale + edge_radius

        nearby_indices = np.flatnonzero(
            np.isfinite(display_offsets).all(axis=1)
            & (display_offsets[:, 0] >= selection_bbox.x0 - max_radius)
            & (display_offsets[:, 0] <= selection_bbox.x1 + max_radius)
            & (display_offsets[:, 1] >= selection_bbox.y0 - max_radius)
            & (display_offsets[:, 1] <= selection_bbox.y1 + max_radius)
        )
        if not nearby_indices.size:
            return False

        facecolors = np.asarray(artist.get_facecolors(), dtype=float)
        edgecolors = np.asarray(artist.get_edgecolors(), dtype=float)
        transformed_paths = {}
        for offset_index in nearby_indices:
            path_index = int(offset_index) % len(paths)
            transform_index = (
                int(offset_index) % len(transforms)
                if transforms.size
                else None
            )
            cache_key = (path_index, transform_index)
            base_path = transformed_paths.get(cache_key)
            if cache_key not in transformed_paths:
                try:
                    base_path = paths[path_index]
                    if transform_index is not None:
                        base_path = base_path.transformed(
                            Affine2D(transforms[transform_index])
                        )
                    base_path = base_path.transformed(path_transform)
                except (AttributeError, TypeError, ValueError):
                    base_path = None
                transformed_paths[cache_key] = base_path
            if base_path is None:
                continue
            x, y = display_offsets[offset_index]
            display_marker = base_path.transformed(
                Affine2D().translate(float(x), float(y))
            )
            path_codes = paths[path_index].codes
            path_is_closed = bool(
                path_codes is not None
                and np.any(path_codes == MplPath.CLOSEPOLY)
            )
            face_visible = bool(
                path_is_closed
                and facecolors.size
                and facecolors[int(offset_index) % len(facecolors), 3] > 0.0
            )
            edge_visible = bool(
                linewidths.size
                and linewidths[int(offset_index) % len(linewidths)] > 0.0
                and edgecolors.size
                and edgecolors[int(offset_index) % len(edgecolors), 3] > 0.0
            )
            if face_visible and display_marker.intersects_bbox(
                selection_bbox,
                filled=True,
            ):
                return True
            if (
                edge_visible
                and (
                    edge_bbox := self._xy_clipped_padded_bbox(
                        selection_bbox,
                        float(linewidths[int(offset_index) % len(linewidths)])
                        * float(self.figure.dpi)
                        / 144.0,
                        clip_bbox,
                    )
                ) is not None
                and display_marker.intersects_bbox(
                    edge_bbox,
                    filled=False,
                )
            ):
                return True
        return False

    def _axis_dimension_interaction_boxes(
        self,
        ax,
        renderer,
        *,
        dimension: str,
        side: str,
    ):
        boxes = [self._axis_side_feedback_box(ax, renderer, side=side, band=12.0)]
        axis = ax.xaxis if dimension == "x" else ax.yaxis
        artists = axis.get_ticklabels()
        for artist in artists:
            if artist.get_visible() and artist.get_text():
                boxes.append(artist.get_window_extent(renderer))
        return boxes

    def _axis_side_feedback_box(self, ax, renderer, *, side: str, band: float = 3.0):
        axis_bounds = ax.get_window_extent(renderer)
        if side == "bottom":
            return Bbox.from_extents(
                axis_bounds.x0 - band,
                axis_bounds.y0 - band,
                axis_bounds.x1 + band,
                axis_bounds.y0 + band,
            )
        if side == "top":
            return Bbox.from_extents(
                axis_bounds.x0 - band,
                axis_bounds.y1 - band,
                axis_bounds.x1 + band,
                axis_bounds.y1 + band,
            )
        if side == "left":
            return Bbox.from_extents(
                axis_bounds.x0 - band,
                axis_bounds.y0 - band,
                axis_bounds.x0 + band,
                axis_bounds.y1 + band,
            )
        if side == "right":
            return Bbox.from_extents(
                axis_bounds.x1 - band,
                axis_bounds.y0 - band,
                axis_bounds.x1 + band,
                axis_bounds.y1 + band,
            )
        raise ValueError(f"Unsupported axis side: {side}")

    def _title_interaction_boxes(self, axes, renderer):
        boxes = []
        for ax in axes:
            for artist in (ax.title, ax.xaxis.label, ax.yaxis.label):
                if artist is not None and artist.get_visible() and artist.get_text():
                    boxes.append(artist.get_window_extent(renderer))
        return boxes

    def _artist_bbox_or_axes_bbox(self, artist, ax, renderer):
        try:
            bbox = artist.get_window_extent(renderer)
            if bbox.width > 0 and bbox.height > 0:
                return self._padded_bbox(bbox, 6.0)
        except Exception:
            pass
        return ax.get_window_extent(renderer)

    def _interaction_artist_bbox(self, artist, ax, renderer):
        axes_bounds = ax.get_window_extent(renderer)
        if isinstance(artist, PathCollection):
            offsets = np.asarray(artist.get_offsets(), dtype=float)
            if offsets.size:
                display_offsets = artist.get_offset_transform().transform(offsets)
                finite_offsets = display_offsets[
                    np.isfinite(display_offsets).all(axis=1)
                ]
                sizes = np.asarray(artist.get_sizes(), dtype=float)
                marker_radius = (
                    math.sqrt(float(np.nanmax(sizes)))
                    * self.figure.dpi
                    / 144.0
                    if sizes.size
                    else 0.0
                )
                visible_offsets = finite_offsets[
                    (finite_offsets[:, 0] >= axes_bounds.x0 - marker_radius)
                    & (finite_offsets[:, 0] <= axes_bounds.x1 + marker_radius)
                    & (finite_offsets[:, 1] >= axes_bounds.y0 - marker_radius)
                    & (finite_offsets[:, 1] <= axes_bounds.y1 + marker_radius)
                ]
                if visible_offsets.size:
                    visible_bounds = Bbox.from_extents(
                        float(visible_offsets[:, 0].min()) - marker_radius,
                        float(visible_offsets[:, 1].min()) - marker_radius,
                        float(visible_offsets[:, 0].max()) + marker_radius,
                        float(visible_offsets[:, 1].max()) + marker_radius,
                    )
                    return Bbox.intersection(visible_bounds, axes_bounds)
            return None
        bounds = self._plot_content_artist_bounds(artist, ax, renderer)
        if bounds is not None and np.isfinite(bounds.extents).all():
            visible_bounds = Bbox.intersection(bounds, axes_bounds)
            if (
                visible_bounds is not None
                and np.isfinite(visible_bounds.extents).all()
            ):
                return visible_bounds
        return None

    def _padded_bbox(self, bbox, padding: float):
        return Bbox.from_extents(bbox.x0 - padding, bbox.y0 - padding, bbox.x1 + padding, bbox.y1 + padding)

    def _apply_value_axis_tick_interval(self, ax, settings: ChartSettings, secondary: bool = False) -> None:
        auto_tick_interval = settings.secondary_auto_tick_interval if secondary else settings.primary_auto_tick_interval
        axis = ax.xaxis if settings.chart_type == "Ridge" else ax.yaxis
        if auto_tick_interval:
            return
        tick_interval = settings.secondary_tick_interval if secondary else settings.primary_tick_interval
        if not self._manual_tick_interval_is_safe(ax, tick_interval, settings):
            axis.set_major_locator(AutoLocator())
            self._auto_tick_interval_fallbacks.add("secondary" if secondary else "primary")
            return
        axis.set_major_locator(MultipleLocator(tick_interval))

    def _apply_xy_x_axis_tick_interval(self, ax, settings: ChartSettings) -> None:
        if settings.x_auto_tick_interval:
            return
        if not self._manual_tick_interval_is_safe_for_dimension(
            ax,
            settings.x_tick_interval,
            "x",
        ):
            ax.xaxis.set_major_locator(AutoLocator())
            self._auto_tick_interval_fallbacks.add("x")
            return
        ax.xaxis.set_major_locator(MultipleLocator(settings.x_tick_interval))

    def _manual_tick_interval_is_safe(self, ax, tick_interval: float, settings: ChartSettings) -> bool:
        dimension = "x" if settings.chart_type == "Ridge" else "y"
        return self._manual_tick_interval_is_safe_for_dimension(
            ax,
            tick_interval,
            dimension,
        )

    def _manual_tick_interval_is_safe_for_dimension(
        self,
        ax,
        tick_interval: float,
        dimension: str,
    ) -> bool:
        if not math.isfinite(tick_interval) or tick_interval <= 0:
            return False
        axis_min, axis_max = ax.get_xlim() if dimension == "x" else ax.get_ylim()
        if not math.isfinite(axis_min) or not math.isfinite(axis_max):
            return False
        span = abs(axis_max - axis_min)
        if span <= 0:
            return True
        return math.ceil(span / tick_interval) + 1 <= MAX_MANUAL_TICK_COUNT

    def _apply_ridge_x_range(self, ax, settings: ChartSettings) -> None:
        if not settings.auto_y_range:
            ax.set_xlim(settings.y_min, settings.y_max)
            return

        self._apply_auto_value_axis_padding(ax, settings)

    def _apply_auto_value_axis_padding(self, ax, settings: ChartSettings) -> None:
        axis_min, axis_max = ax.dataLim.intervalx if settings.chart_type == "Ridge" else ax.dataLim.intervaly
        if not math.isfinite(axis_min) or not math.isfinite(axis_max):
            return
        if math.isclose(axis_min, axis_max, rel_tol=0.0, abs_tol=1e-12):
            pad = max(abs(axis_min) * AUTO_AXIS_RANGE_PADDING_FRACTION, 0.5)
        else:
            pad = (axis_max - axis_min) * AUTO_AXIS_RANGE_PADDING_FRACTION
        if settings.chart_type == "Ridge":
            ax.set_xlim(axis_min - pad, axis_max + pad)
        else:
            ax.set_ylim(axis_min - pad, axis_max + pad)

    def _point_positions(self, df: pd.DataFrame, settings: ChartSettings) -> pd.Series:
        return point_positions(df, settings, getattr(self, "_group_layout", None))

    def _draw_points(
        self,
        ax,
        df: pd.DataFrame,
        settings: ChartSettings,
        palette: list[str],
        preset: dict,
        positions: pd.Series,
    ) -> None:
        draw_points(ax, df, settings, palette, preset, positions, mark_point_artist=self._mark_point_artist)

    def _draw_box(self, ax, df: pd.DataFrame, settings: ChartSettings, palette: list[str]) -> None:
        layout = getattr(self, "_group_layout", None)
        if layout is not None:
            palette = [layout.colors[str(key)] for key in df[settings.group_col].drop_duplicates()]
        draw_box(ax, df, settings, palette, mark_plot_content_artist=self._mark_plot_content_artist, layout=getattr(self, "_group_layout", None))

    def _draw_violin(self, ax, df: pd.DataFrame, settings: ChartSettings, palette: list[str]) -> None:
        layout = getattr(self, "_group_layout", None)
        if layout is not None:
            palette = [layout.colors[str(key)] for key in df[settings.group_col].drop_duplicates()]
        draw_violin(ax, df, settings, palette, mark_plot_content_artist=self._mark_plot_content_artist, layout=getattr(self, "_group_layout", None))

    def _draw_ridge(
        self,
        ax,
        df: pd.DataFrame,
        point_df: pd.DataFrame,
        settings: ChartSettings,
        palette: list[str],
        text_color: str,
        outlier_df: pd.DataFrame,
    ) -> None:
        layout = getattr(self, "_group_layout", None)
        if layout is not None:
            palette = [layout.colors[str(key)] for key in df[settings.group_col].drop_duplicates()]
        draw_ridge(
            ax,
            df,
            point_df,
            settings,
            palette,
            text_color,
            mark_plot_content_artist=self._mark_plot_content_artist,
            mark_point_artist=self._mark_ridge_point_artist,
            outlier_df=outlier_df,
            layout=getattr(self, "_group_layout", None),
        )

    def _draw_group_axis(self, ax, settings: ChartSettings, text_color: str) -> None:
        layout = self._group_layout
        ridge = settings.chart_type == "Ridge"
        if not layout.parents:
            return
        font_size = settings.tick_font_size
        renderer = self.canvas.get_renderer()
        axis_bounds = ax.get_window_extent(renderer)
        tick_labels = ax.get_yticklabels() if ridge else ax.get_xticklabels()
        leaf_bounds = [label.get_window_extent(renderer) for label in tick_labels if label.get_visible() and label.get_text()]
        # The real tick bounds include multiline text, rotation, alignment and
        # tick padding. Measuring them needs no additional canvas draw.
        pixels_to_points = 72 / self.figure.dpi
        leaf_extent = max(
            [(axis_bounds.x0 - bounds.x0 if ridge else axis_bounds.y0 - bounds.y0) * pixels_to_points for bounds in leaf_bounds],
            default=0.0,
        )
        label_offset = max(0.0, leaf_extent)
        dpi_transform = self.figure.dpi_scale_trans
        from matplotlib.transforms import ScaledTranslation

        parent_texts = []
        for parent in layout.parents:
            if ridge:
                top = max(layout.positions.values()) - parent.start + layout.inner_spacing * 0.38
                bottom = max(layout.positions.values()) - parent.end - layout.inner_spacing * 0.38
                center = (top + bottom) / 2
                transform = ax.get_yaxis_transform() + ScaledTranslation(-(label_offset + 4) / 72, 0, dpi_transform)
                ax.plot([0, 0], [bottom, top], color=text_color, linewidth=0.65, transform=transform, clip_on=False, gid="group-parent-bracket")
                text_transform = ax.get_yaxis_transform() + ScaledTranslation(-(label_offset + 8) / 72, 0, dpi_transform)
                parent_texts.append(ax.text(0, center, parent.label, transform=text_transform, ha="right", va="center", fontsize=font_size, color=text_color, gid="group-parent-label"))
            else:
                transform = ax.get_xaxis_transform() + ScaledTranslation(0, -(label_offset + 4) / 72, dpi_transform)
                ax.plot([parent.start - layout.inner_spacing * 0.38, parent.end + layout.inner_spacing * 0.38], [0, 0], color=text_color, linewidth=0.65, transform=transform, clip_on=False, gid="group-parent-bracket")
                text_transform = ax.get_xaxis_transform() + ScaledTranslation(0, -(label_offset + 8) / 72, dpi_transform)
                parent_texts.append(ax.text(parent.center, 0, parent.label, transform=text_transform, ha="center", va="top", fontsize=font_size, color=text_color, gid="group-parent-label"))
        parent_bounds = [text.get_window_extent(renderer) for text in parent_texts]
        if ridge:
            ax.yaxis.labelpad += max(bounds.width for bounds in parent_bounds) * pixels_to_points + 12
        else:
            ax.xaxis.labelpad += max(bounds.height for bounds in parent_bounds) * pixels_to_points + 12

    def _style_plot_frame(self, ax, settings: ChartSettings, text_color: str) -> None:
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(text_color)
            spine.set_linewidth(settings.axis_line_width)

    def _custom_overlay_secondary_axis_active(self, settings: ChartSettings) -> bool:
        return custom_overlay_secondary_axis_active(settings)

    def _split_secondary_frame_enabled(self, settings: ChartSettings) -> bool:
        return split_secondary_frame_enabled(settings)

    def _secondary_axis_split_ratio(self, settings: ChartSettings) -> float:
        return secondary_axis_split_ratio(settings)

    def _set_split_secondary_title(self, secondary_ax, primary_ax, settings: ChartSettings, text_color: str) -> None:
        title_x = 0.5
        if settings.chart_type == "Ridge":
            primary_position = primary_ax.get_position()
            secondary_position = secondary_ax.get_position()
            combined_center = (primary_position.x0 + secondary_position.x1) / 2.0
            title_x = (combined_center - secondary_position.x0) / max(secondary_position.width, 1e-9)
        secondary_ax.set_title(settings.title, fontsize=settings.title_font_size, color=text_color, x=title_x)

    def _style_split_secondary_axis(self, secondary_ax, primary_ax, groups: list[str], settings: ChartSettings, text_color: str) -> None:
        self._set_split_secondary_title(secondary_ax, primary_ax, settings, text_color)
        if settings.chart_type == "Ridge":
            secondary_ax.set_xlabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            secondary_ax.set_ylabel("", fontsize=settings.axis_label_font_size, color=text_color)
            secondary_ax.set_ylim(primary_ax.get_ylim())
            secondary_ax.set_yticks(primary_ax.get_yticks())
            secondary_ax.set_yticklabels([])
            secondary_ax.xaxis.set_label_position("top")
            secondary_ax.xaxis.tick_top()
            secondary_ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            secondary_ax.tick_params(axis="x", top=True, labeltop=True, bottom=False, labelbottom=False)
            secondary_ax.tick_params(axis="y", left=False, labelleft=False, right=False, labelright=False)
            self._style_plot_frame(secondary_ax, settings, text_color)
            secondary_ax.grid(bool(settings.show_grid))
            if settings.show_grid:
                secondary_ax.grid(
                    color="#D1D5DB" if PRESETS[settings.preset]["background"] == "#FFFFFF" else "#374151",
                    alpha=0.55,
                )
            return

        secondary_ax.set_xlabel("", fontsize=settings.axis_label_font_size, color=text_color)
        secondary_ax.set_ylabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
        secondary_ax.yaxis.set_label_position("right")
        secondary_ax.yaxis.tick_right()
        secondary_ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        secondary_ax.tick_params(axis="y", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
        secondary_ax.tick_params(axis="y", left=False, labelleft=False, right=True, labelright=True)
        secondary_ax.set_xlim(primary_ax.get_xlim())
        secondary_ax.set_xticks(primary_ax.get_xticks())
        secondary_ax.set_xticklabels([])
        secondary_ax.tick_params(axis="x", top=False, labeltop=False, bottom=False, labelbottom=False)
        self._style_plot_frame(secondary_ax, settings, text_color)
        secondary_ax.grid(bool(settings.show_grid))
        if settings.show_grid:
            secondary_ax.grid(
                color="#D1D5DB" if PRESETS[settings.preset]["background"] == "#FFFFFF" else "#374151",
                alpha=0.55,
            )

    def _style_secondary_axis(self, ax, settings: ChartSettings, text_color: str) -> None:
        if settings.chart_type == "Ridge":
            ax.set_xlabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            ax.tick_params(axis="x", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            ax.tick_params(axis="y", left=False, labelleft=False)
            ax.spines["top"].set_visible(True)
            ax.spines["right"].set_visible(False)
        else:
            ax.set_ylabel(settings.secondary_y_label, fontsize=settings.axis_label_font_size, color=text_color)
            ax.tick_params(axis="y", colors=text_color, labelsize=settings.tick_font_size, width=settings.axis_line_width)
            ax.tick_params(axis="x", bottom=False, labelbottom=False)
            ax.spines["right"].set_visible(True)
            ax.spines["top"].set_visible(False)
        for spine in ax.spines.values():
            spine.set_color(text_color)
            spine.set_linewidth(settings.axis_line_width)
        ax.grid(False)

    def _draw_line_overlay(self, ax, df: pd.DataFrame, settings: ChartSettings, text_color: str, secondary_ax=None) -> None:
        series_list = line_overlay_series(df, settings)
        if not series_list:
            return
        line_width = max(settings.line_overlay_width, 0.1)
        point_size = max(settings.line_overlay_point_size, 0.0)
        overlay_colors = overlay_palette_for(df, settings, len(series_list))
        grouping = getattr(self, "_last_grouping", None)
        break_parents = grouping.parents if settings.line_overlay_break_between_parents and grouping is not None else []
        for series_index, series in enumerate(series_list):
            groups = series["groups"]
            values = series["values"]
            is_custom_overlay = series.get("kind") == "custom"
            statistic = None if is_custom_overlay else settings.line_overlay_stat
            target_ax = secondary_ax if series.get("secondary_axis") and secondary_ax is not None else ax
            value_axis = target_ax.xaxis if settings.chart_type == "Ridge" else target_ax.yaxis
            percentage = isinstance(value_axis.get_major_formatter(), PercentFormatter)
            label_position = overlay_label_position_for_series(settings, is_custom_overlay)
            preferred_auto_position = overlay_auto_avoidance_position(settings, is_custom_overlay)
            line_color = overlay_colors[series_index % len(overlay_colors)]
            line_style = overlay_line_style(overlay_style_for_series(settings, series, series_index))
            line_alpha = 1.0 if is_custom_overlay else STAT_OVERLAY_ALPHA
            finite_indices = [index for index, value in enumerate(values) if math.isfinite(value)]
            finite_values = [values[index] for index in finite_indices]
            finite_ranks = {index: rank for rank, index in enumerate(finite_indices)}
            if settings.chart_type == "Ridge":
                layout = getattr(self, "_group_layout", None)
                y_positions = [layout.coordinate(str(group), ridge=True) for group in groups] if layout is not None else np.arange(len(groups))[::-1]
                line_positions, line_values = _overlay_coordinates_with_parent_breaks(groups, y_positions, values, break_parents)
                line, = target_ax.plot(
                    line_values,
                    line_positions,
                    color=line_color,
                    marker="o",
                    markersize=point_size,
                    linewidth=line_width,
                    linestyle=line_style,
                    dash_capstyle="round",
                    solid_capstyle="round",
                    alpha=line_alpha,
                    label=series["name"],
                    zorder=8 + series_index,
                )
                self._mark_overlay_line(line)
                if settings.show_line_values:
                    for index, (x_value, y_value) in enumerate(zip(values, y_positions)):
                        if not math.isfinite(x_value):
                            continue
                        if not self._overlay_label_anchor_is_visible(x_value, y_value, settings, uses_secondary_axis=target_ax is secondary_ax):
                            continue
                        if not is_custom_overlay and label_position in {"Axis left", "Axis right"}:
                            is_right_axis = label_position == "Axis right"
                            x_fraction = 1.0 if is_right_axis else 0.0
                            offset_x = -OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS if is_right_axis else OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                            horizontal_align = "right" if is_right_axis else "left"
                            annotation = target_ax.annotate(
                                format_overlay_value(x_value, settings, statistic, percentage=percentage),
                                xy=(x_fraction, y_value),
                                xycoords=target_ax.get_yaxis_transform(),
                                xytext=(offset_x, 0),
                                textcoords="offset points",
                                ha=horizontal_align,
                                va="center",
                                color=line_color,
                                fontsize=settings.line_value_font_size,
                                bbox=overlay_label_bbox(settings),
                                clip_on=False,
                                zorder=10 + series_index,
                            )
                            self._mark_overlay_value_label(annotation, is_custom_overlay, label_position)
                            continue
                        actual_label_position = resolve_overlay_label_position(
                            finite_ranks[index],
                            finite_values,
                            label_position,
                            is_ridge=True,
                            series_index=series_index,
                            preferred_auto_position=preferred_auto_position,
                        )
                        offset_x, offset_y, horizontal_align, vertical_align = overlay_label_offset(
                            finite_ranks[index],
                            finite_values,
                            actual_label_position,
                            is_ridge=True,
                            series_index=series_index,
                            marker_size_points=point_size,
                        )
                        annotation = target_ax.annotate(
                            format_overlay_value(x_value, settings, statistic, percentage=percentage),
                            xy=(x_value, y_value),
                            xytext=(offset_x, offset_y),
                            textcoords="offset points",
                            ha=horizontal_align,
                            va=vertical_align,
                            color=line_color,
                            fontsize=settings.line_value_font_size,
                            bbox=overlay_label_bbox(settings),
                            arrowprops=overlay_label_arrow(line_color),
                            zorder=10 + series_index,
                        )
                        self._mark_overlay_value_label(annotation, is_custom_overlay, actual_label_position)
                continue

            layout = getattr(self, "_group_layout", None)
            x_positions = [layout.coordinate(str(group)) for group in groups] if layout is not None else np.arange(len(values))
            line_positions, line_values = _overlay_coordinates_with_parent_breaks(groups, x_positions, values, break_parents)
            line, = target_ax.plot(
                line_positions,
                line_values,
                color=line_color,
                marker="o",
                markersize=point_size,
                linewidth=line_width,
                linestyle=line_style,
                dash_capstyle="round",
                solid_capstyle="round",
                alpha=line_alpha,
                label=series["name"],
                zorder=8 + series_index,
            )
            self._mark_overlay_line(line)
            if settings.show_line_values:
                for index, (x_value, y_value) in enumerate(zip(x_positions, values)):
                    if not math.isfinite(y_value):
                        continue
                    if not self._overlay_label_anchor_is_visible(x_value, y_value, settings, uses_secondary_axis=target_ax is secondary_ax):
                        continue
                    if not is_custom_overlay and label_position in {"Top axis", "Bottom axis"}:
                        is_top_axis = label_position == "Top axis"
                        y_fraction = 1.0 if is_top_axis else 0.0
                        offset_y = -OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS if is_top_axis else OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                        vertical_align = "top" if is_top_axis else "bottom"
                        annotation = target_ax.annotate(
                            format_overlay_value(y_value, settings, statistic, percentage=percentage),
                            xy=(x_value, y_fraction),
                            xycoords=target_ax.get_xaxis_transform(),
                            xytext=(0, offset_y),
                            textcoords="offset points",
                            ha="center",
                            va=vertical_align,
                            color=line_color,
                            fontsize=settings.line_value_font_size,
                            bbox=overlay_label_bbox(settings),
                            clip_on=False,
                            zorder=10 + series_index,
                        )
                        self._mark_overlay_value_label(annotation, is_custom_overlay, label_position)
                        continue
                    actual_label_position = resolve_overlay_label_position(
                        finite_ranks[index],
                        finite_values,
                        label_position,
                        is_ridge=False,
                        series_index=series_index,
                        preferred_auto_position=preferred_auto_position,
                    )
                    offset_x, offset_y, horizontal_align, vertical_align = overlay_label_offset(
                        finite_ranks[index],
                        finite_values,
                        actual_label_position,
                        is_ridge=False,
                        series_index=series_index,
                        marker_size_points=point_size,
                    )
                    annotation = target_ax.annotate(
                        format_overlay_value(y_value, settings, statistic, percentage=percentage),
                        xy=(x_value, y_value),
                        xytext=(offset_x, offset_y),
                        textcoords="offset points",
                        ha=horizontal_align,
                        va=vertical_align,
                        color=line_color,
                        fontsize=settings.line_value_font_size,
                        bbox=overlay_label_bbox(settings),
                        arrowprops=overlay_label_arrow(line_color),
                        zorder=10 + series_index,
                    )
                    self._mark_overlay_value_label(annotation, is_custom_overlay, actual_label_position)
    def _apply_overlay_axis_label_y_padding(self, ax, settings: ChartSettings) -> None:
        if settings.chart_type == "Ridge":
            return
        if not settings.auto_y_range:
            return
        if not settings.show_line_overlay or not settings.show_line_values:
            return
        line_value_position = normalize_overlay_label_position(settings.line_value_position, settings.chart_type)
        if line_value_position not in {"Top axis", "Bottom axis"}:
            return

        current_y_min, current_y_max = ax.get_ylim()
        if settings.auto_y_range:
            y_min, y_max = ax.dataLim.intervaly
        else:
            y_min, y_max = current_y_min, current_y_max
        if not math.isfinite(y_min) or not math.isfinite(y_max) or y_max < y_min:
            return

        y_range = y_max - y_min
        if math.isclose(y_range, 0.0):
            y_range = max(abs(y_min), abs(y_max), 1.0)
        axes_height_points = max(ax.get_position().height * self.figure.get_figheight() * 72.0, 1.0)
        label_margin_points = self._overlay_axis_label_margin_points(settings)
        marker_margin_points = self._overlay_axis_marker_margin_points(settings) if settings.auto_y_range else 0.0
        bottom_margin_points = marker_margin_points
        top_margin_points = marker_margin_points
        if line_value_position == "Bottom axis":
            bottom_margin_points += label_margin_points
        else:
            top_margin_points += label_margin_points

        bottom_fraction = bottom_margin_points / axes_height_points
        top_fraction = top_margin_points / axes_height_points
        total_fraction = min(max(bottom_fraction + top_fraction, 0.0), 0.80)
        if total_fraction <= 0.0:
            return

        scale = y_range / (1.0 - total_fraction)
        bottom_pad = scale * bottom_fraction
        top_pad = scale * top_fraction
        padded_y_min = y_min - bottom_pad
        padded_y_max = y_max + top_pad
        if line_value_position == "Top axis":
            padded_y_min = min(padded_y_min, current_y_min)
        else:
            padded_y_max = max(padded_y_max, current_y_max)
        ax.set_ylim(padded_y_min, padded_y_max)

    def _overlay_axis_label_margin_points(self, settings: ChartSettings) -> float:
        return overlay_axis_label_margin_points(settings)

    def _fit_ridge_axis_overlay_margin(self, ax, table_ax, settings: ChartSettings) -> None:
        if settings.chart_type != "Ridge" or not settings.show_line_overlay or not settings.show_line_values:
            return
        if normalize_overlay_label_position(settings.line_value_position, settings.chart_type) not in {"Axis left", "Axis right"}:
            return

        renderer = self.canvas.get_renderer()
        figure_width = max(self.figure.bbox.width, 1.0)
        text_bounds = [text.get_window_extent(renderer) for text in ax.texts if text.get_visible() and text.get_text()]
        if not text_bounds:
            return

        left_overflow = max(0.0, 6.0 - min(bounds.x0 for bounds in text_bounds))
        right_overflow = max(0.0, max(bounds.x1 for bounds in text_bounds) - (self.figure.bbox.width - 6.0))
        if left_overflow <= 0.0 and right_overflow <= 0.0:
            return

        position = ax.get_position()
        new_left = position.x0 + left_overflow / figure_width
        new_right = position.x1 - right_overflow / figure_width
        if new_right - new_left < 0.20:
            return
        ax.set_position([new_left, position.y0, new_right - new_left, position.height])
        if table_ax is not None:
            table_position = table_ax.get_position()
            table_ax.set_position([new_left, table_position.y0, new_right - new_left, table_position.height])

    def _expand_axes_for_plot_content(self, ax, settings: ChartSettings) -> bool:
        return self._expand_axes_once_for_plot_content(ax, settings)

    def _expand_axes_for_overlay_label_conflicts(self, ax, settings: ChartSettings) -> bool:
        return self._expand_axes_once_for_overlay_label_conflicts(ax)

    @staticmethod
    def _expanded_axis_limits(
        first: float,
        second: float,
        first_overflow_px: float,
        second_overflow_px: float,
        axis_size_px: float,
    ) -> tuple[float, float]:
        span = abs(second - first)
        if not math.isfinite(span) or math.isclose(span, 0.0):
            span = max(abs(first), abs(second), 1.0)
        usable_px = max(
            axis_size_px - first_overflow_px - second_overflow_px,
            axis_size_px * 0.10,
            1.0,
        )
        # A small safety factor absorbs renderer rounding so one measured
        # expansion never lands a fraction of a pixel inside the requested pad.
        safety_factor = 1.001
        first_delta = span * first_overflow_px / usable_px * safety_factor
        second_delta = span * second_overflow_px / usable_px * safety_factor
        if second >= first:
            return first - first_delta, second + second_delta
        return first + first_delta, second - second_delta

    def _overlay_label_anchor_is_visible(
        self,
        x_value: float,
        y_value: float,
        settings: ChartSettings,
        uses_secondary_axis: bool = False,
    ) -> bool:
        if uses_secondary_axis:
            if settings.secondary_auto_y_range:
                return True
            low, high = sorted((settings.secondary_y_min, settings.secondary_y_max))
            return low <= (x_value if settings.chart_type == "Ridge" else y_value) <= high
        if settings.auto_y_range:
            return True
        if settings.chart_type == "Ridge":
            low, high = sorted((settings.y_min, settings.y_max))
            return low <= x_value <= high
        low, high = sorted((settings.y_min, settings.y_max))
        return low <= y_value <= high

    def _expand_axes_once_for_overlay_label_conflicts(self, ax) -> bool:
        labels = [
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and text.get_visible() and text.get_text()
        ]
        if len(labels) < 2:
            return False

        renderer = self.canvas.get_renderer()
        axes_bounds = ax.get_window_extent(renderer)
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        padding_px = 2.0
        expand_left = expand_right = expand_bottom = expand_top = 0.0
        bounds_by_label = {label: self._overlay_label_bounds(label, renderer) for label in labels}

        for left_index, left_label in enumerate(labels):
            left_bounds = bounds_by_label[left_label]
            for right_label in labels[left_index + 1:]:
                right_bounds = bounds_by_label[right_label]
                overlap_x = min(left_bounds.x1, right_bounds.x1) - max(left_bounds.x0, right_bounds.x0) + padding_px
                overlap_y = min(left_bounds.y1, right_bounds.y1) - max(left_bounds.y0, right_bounds.y0) + padding_px
                if overlap_x <= 0.0 or overlap_y <= 0.0:
                    continue
                moving_label = self._lower_priority_overlay_label(left_label, right_label)
                position = getattr(moving_label, "_easygraph_overlay_position", "Auto")
                if position == "Below":
                    expand_bottom = max(expand_bottom, overlap_y)
                elif position == "Above":
                    expand_top = max(expand_top, overlap_y)
                elif position == "Left":
                    expand_left = max(expand_left, overlap_x)
                elif position == "Right":
                    expand_right = max(expand_right, overlap_x)

        if max(expand_left, expand_right, expand_bottom, expand_top) <= 0.05:
            return False

        ax.set_xlim(*self._expanded_axis_limits(
            x_min,
            x_max,
            expand_left,
            expand_right,
            max(axes_bounds.width, 1.0),
        ))
        ax.set_ylim(*self._expanded_axis_limits(
            y_min,
            y_max,
            expand_bottom,
            expand_top,
            max(axes_bounds.height, 1.0),
        ))
        return True

    def _expand_axes_once_for_plot_content(self, ax, settings: ChartSettings) -> bool:
        renderer = self.canvas.get_renderer()
        axes_bounds = ax.get_window_extent(renderer)
        labels = [
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
            and text.get_visible()
            and text.get_text()
            and getattr(text, "_easygraph_overlay_position", "Auto")
            not in {"Top axis", "Bottom axis", "Axis left", "Axis right"}
        ]
        content_bounds = [self._overlay_label_bounds(text, renderer) for text in labels]
        for artist in [*ax.lines, *ax.patches, *ax.collections]:
            if artist.get_gid() not in {"plot-content", "data-points", "overlay-line"} or not artist.get_visible():
                continue
            bounds = self._plot_content_artist_bounds(artist, ax, renderer)
            if bounds is not None:
                content_bounds.append(bounds)
        if not content_bounds:
            return False

        plot_content_bounds = Bbox.union(content_bounds)
        category_padding_px = 2.0
        if settings.chart_type == "Ridge":
            value_padding_px = plot_content_bounds.width * OVERLAY_CONTENT_MARGIN_RATIO
        else:
            value_padding_px = plot_content_bounds.height * OVERLAY_CONTENT_MARGIN_RATIO

        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        if settings.chart_type == "Ridge":
            horizontal_padding_px = value_padding_px
            vertical_padding_px = category_padding_px
        else:
            horizontal_padding_px = category_padding_px
            vertical_padding_px = value_padding_px

        expand_left = max(0.0, axes_bounds.x0 + horizontal_padding_px - plot_content_bounds.x0)
        expand_right = max(0.0, plot_content_bounds.x1 - (axes_bounds.x1 - horizontal_padding_px))
        expand_bottom = max(0.0, axes_bounds.y0 + vertical_padding_px - plot_content_bounds.y0)
        expand_top = max(0.0, plot_content_bounds.y1 - (axes_bounds.y1 - vertical_padding_px))

        if max(expand_left, expand_right, expand_bottom, expand_top) <= 0.05:
            return False

        ax.set_xlim(*self._expanded_axis_limits(
            x_min,
            x_max,
            expand_left,
            expand_right,
            max(axes_bounds.width, 1.0),
        ))
        ax.set_ylim(*self._expanded_axis_limits(
            y_min,
            y_max,
            expand_bottom,
            expand_top,
            max(axes_bounds.height, 1.0),
        ))
        return True

    def _plot_content_artist_bounds(self, artist, ax, renderer):
        if isinstance(artist, PathCollection):
            offsets = np.asarray(artist.get_offsets(), dtype=float)
            if offsets.size:
                display_offsets = artist.get_offset_transform().transform(offsets)
                finite_offsets = display_offsets[np.isfinite(display_offsets).all(axis=1)]
                if finite_offsets.size:
                    sizes = np.asarray(artist.get_sizes(), dtype=float)
                    marker_radius = math.sqrt(float(np.nanmax(sizes))) * self.figure.dpi / 144.0 if sizes.size else 0.0
                    return Bbox.from_extents(
                        float(finite_offsets[:, 0].min()) - marker_radius,
                        float(finite_offsets[:, 1].min()) - marker_radius,
                        float(finite_offsets[:, 0].max()) + marker_radius,
                        float(finite_offsets[:, 1].max()) + marker_radius,
                    )

        bounds = artist.get_window_extent(renderer)
        if np.isfinite(bounds.extents).all():
            return bounds
        if hasattr(artist, "get_datalim"):
            data_bounds = artist.get_datalim(ax.transData)
            if np.isfinite(data_bounds.extents).all():
                return ax.transData.transform_bbox(data_bounds)
        return None

    def _separate_overlay_value_labels(self, ax) -> None:
        labels = [
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and text.get_visible() and text.get_text()
        ]
        labels.sort(key=lambda text: getattr(text, "_easygraph_overlay_priority", 1))
        if not labels:
            return

        padding_px = 2.0
        renderer = self.canvas.get_renderer()
        bounds_by_label = {label: self._overlay_label_bounds(label, renderer) for label in labels}
        for _ in range(4):
            moved = False
            for left_index, left_label in enumerate(labels):
                for right_label in labels[left_index + 1:]:
                    left_bounds = bounds_by_label[left_label]
                    right_bounds = bounds_by_label[right_label]
                    overlap_x = min(left_bounds.x1, right_bounds.x1) - max(left_bounds.x0, right_bounds.x0) + padding_px
                    overlap_y = min(left_bounds.y1, right_bounds.y1) - max(left_bounds.y0, right_bounds.y0) + padding_px
                    if overlap_x <= 0.0 or overlap_y <= 0.0:
                        continue

                    left_center_x = (left_bounds.x0 + left_bounds.x1) / 2.0
                    right_center_x = (right_bounds.x0 + right_bounds.x1) / 2.0
                    left_center_y = (left_bounds.y0 + left_bounds.y1) / 2.0
                    right_center_y = (right_bounds.y0 + right_bounds.y1) / 2.0

                    moving_label = self._lower_priority_overlay_label(left_label, right_label)
                    fixed_bounds = right_bounds if moving_label is left_label else left_bounds
                    moving_bounds = left_bounds if moving_label is left_label else right_bounds
                    fixed_center_x = (fixed_bounds.x0 + fixed_bounds.x1) / 2.0
                    moving_center_x = (moving_bounds.x0 + moving_bounds.x1) / 2.0
                    fixed_center_y = (fixed_bounds.y0 + fixed_bounds.y1) / 2.0
                    moving_center_y = (moving_bounds.y0 + moving_bounds.y1) / 2.0

                    if overlap_x < overlap_y:
                        direction = 1.0 if moving_center_x >= fixed_center_x else -1.0
                        dx_px = direction * overlap_x
                        dy_px = 0.0
                    else:
                        direction = 1.0 if moving_center_y >= fixed_center_y else -1.0
                        dx_px = 0.0
                        dy_px = direction * overlap_y
                    self._move_overlay_label(moving_label, dx_px, dy_px)
                    bounds_by_label[moving_label] = moving_bounds.translated(dx_px, dy_px)
                    moved = True

            if not moved:
                return

    def _move_overlay_label(self, text, dx_px: float, dy_px: float) -> None:
        pixel_to_points = 72.0 / max(self.figure.dpi, 1.0)
        x_offset, y_offset = text.get_position()
        text.set_position((x_offset + dx_px * pixel_to_points, y_offset + dy_px * pixel_to_points))

    def _mark_overlay_value_label(self, text, is_custom_overlay: bool, label_position: str) -> None:
        text.set_gid("overlay-value-label")
        text._easygraph_overlay_priority = 1 if is_custom_overlay else 0
        text._easygraph_overlay_position = label_position

    def _mark_overlay_line(self, line) -> None:
        line.set_gid("overlay-line")
        line.set_picker(6)

    def _mark_plot_content_artist(self, artist) -> None:
        artist.set_gid("plot-content")

    def _mark_point_artist(self, artist) -> None:
        artist.set_gid("data-points")
        artist.set_picker(6)

    def _mark_outlier_artist(self, artist) -> None:
        artist.set_gid("outliers")
        artist.set_picker(6)

    def _mark_ridge_point_artist(self, artist) -> None:
        facecolors = artist.get_facecolors()
        if getattr(facecolors, "size", 0) == 0:
            self._mark_outlier_artist(artist)
            return
        self._mark_point_artist(artist)

    def _lower_priority_overlay_label(self, first, second):
        first_priority = getattr(first, "_easygraph_overlay_priority", 1)
        second_priority = getattr(second, "_easygraph_overlay_priority", 1)
        if first_priority > second_priority:
            return first
        return second

    def _overlay_label_bounds(self, text, renderer):
        bbox_patch = text.get_bbox_patch()
        if bbox_patch is not None:
            return bbox_patch.get_window_extent(renderer)
        return text.get_window_extent(renderer)

    def _place_legend(self, ax, text_color: str, settings: ChartSettings, extra_axes: list | None = None) -> None:
        if not settings.show_legend:
            existing_legend = ax.get_legend()
            if existing_legend is not None:
                existing_legend.remove()
            return
        handles, labels = ax.get_legend_handles_labels()
        group_entries = getattr(self, "_group_legend_entries", ())
        if group_entries:
            handles = [Rectangle((0, 0), 1, 1, facecolor=color, alpha=settings.fill_alpha) for _label, color in group_entries] + handles
            labels = [label for label, _color in group_entries] + labels
        for extra_ax in extra_axes or []:
            if extra_ax is None:
                continue
            extra_handles, extra_labels = extra_ax.get_legend_handles_labels()
            handles.extend(extra_handles)
            labels.extend(extra_labels)
        if not labels:
            return

        existing_legend = ax.get_legend()
        if existing_legend is not None:
            existing_legend.remove()
        renderer = self.canvas.get_renderer()
        columns = self._legend_column_count(labels, settings, renderer)
        force_wrap = self._legend_force_wrap(labels, settings, renderer)
        labels = [self._legend_label_text(label, settings, columns, renderer, force_wrap=force_wrap) for label in labels]
        if settings.legend_position == LEGEND_POSITION_INSIDE:
            legend = self._place_legend_inside(ax, handles, labels, text_color, settings, columns, extra_axes)
            for text in legend.get_texts():
                text.set_color(text_color)
            self._style_legend_frame(legend, settings)
            return
        legend_anchor_x = self._legend_right_anchor_x(ax, settings)
        legend = ax.legend(
            handles,
            labels,
            loc="upper center" if settings.chart_type == "Ridge" else "upper left",
            bbox_to_anchor=(0.5, 0.0) if settings.chart_type == "Ridge" else (legend_anchor_x, 1.0),
            borderaxespad=0.0,
            frameon=False,
            fontsize=settings.legend_font_size,
            ncol=columns,
            columnspacing=1.0,
            handlelength=LEGEND_HANDLE_LENGTH,
        )
        for text in legend.get_texts():
            text.set_color(text_color)

    def _fit_ridge_bottom_legend(self, ax, secondary_ax, table_ax) -> None:
        legend = ax.get_legend()
        if legend is None or not legend.get_visible():
            return
        renderer = self.canvas.get_renderer()
        plot_axes = [axis for axis in (ax, secondary_ax) if axis is not None]
        plot_bounds = self._plot_axes_union_bbox(plot_axes, renderer)
        content_bounds = [plot_bounds]
        for axis in plot_axes:
            for coordinate_axis in (axis.xaxis, axis.yaxis):
                bounds = coordinate_axis.get_tightbbox(renderer)
                if bounds is not None:
                    content_bounds.append(bounds)
            content_bounds.extend(self._additional_guide_label_bounds(axis.get_children(), renderer))
        if table_ax is not None:
            content_bounds.append(self._ridge_stat_table_bounds(table_ax, renderer))
        padding = renderer.points_to_pixels(8)
        legend_bounds = legend.get_window_extent(renderer)
        left = (plot_bounds.x0 + plot_bounds.x1 - legend_bounds.width) / 2
        top = min(bounds.y0 for bounds in content_bounds if bounds is not None) - padding
        left_extra = max(0, math.ceil(padding - left))
        right_extra = max(0, math.ceil(left + legend_bounds.width + padding - self.figure.bbox.width))
        bottom_extra = max(0, math.ceil(legend_bounds.height + padding - top))
        self._expand_canvas_margins(left_extra, right_extra, bottom_extra, 0)
        self._set_legend_outer_left_top(
            legend, left + left_extra, top + bottom_extra, self.canvas.get_renderer(),
        )
        self.canvas.draw()

    def _place_legend_inside(
        self,
        ax,
        handles: list,
        labels: list[str],
        text_color: str,
        settings: ChartSettings,
        columns: int,
        extra_axes: list | None = None,
    ):
        has_saved_position = (
            settings.legend_inside_x != LEGEND_INSIDE_AUTO_POSITION
            and settings.legend_inside_y != LEGEND_INSIDE_AUTO_POSITION
        )
        if has_saved_position:
            renderer = self.canvas.get_renderer()
            bounds = self._inside_legend_bounds([ax, *(extra_axes or [])], renderer, settings)
            left = bounds.x0 + settings.legend_inside_x * bounds.width
            top = bounds.y1 - settings.legend_inside_y * bounds.height
            fig_x, fig_y = self.figure.transFigure.inverted().transform((left, top))
            legend = ax.legend(
                handles,
                labels,
                loc="upper left",
                bbox_to_anchor=(float(fig_x), float(fig_y)),
                bbox_transform=self.figure.transFigure,
                borderaxespad=0.0,
                frameon=True,
                fontsize=settings.legend_font_size,
                ncol=columns,
                columnspacing=1.0,
                handlelength=LEGEND_HANDLE_LENGTH,
            )
            return legend

        legend = ax.legend(
            handles,
            labels,
            loc="best",
            borderaxespad=0.0,
            frameon=True,
            fontsize=settings.legend_font_size,
            ncol=columns,
            columnspacing=1.0,
            handlelength=LEGEND_HANDLE_LENGTH,
        )
        return legend

    def _style_legend_frame(self, legend, settings: ChartSettings) -> None:
        legend.set_zorder(100)
        frame = legend.get_frame()
        if frame is None:
            return
        preset = PRESETS.get(settings.preset, PRESETS[ChartSettings().preset])
        background = QColor(str(preset["background"]))
        is_light_background = not background.isValid() or _relative_luminance(background) >= 0.52
        frame.set_facecolor("#FFFFFF" if is_light_background else "#111827")
        frame.set_edgecolor("#222222" if is_light_background else "#F9FAFB")
        frame.set_alpha(0.78 if is_light_background else 0.72)
        frame.set_linewidth(settings.axis_line_width)
        frame.set_boxstyle("square,pad=0.25")

    def _clamp_inside_legend_artist(self, legend, bounds, settings: ChartSettings) -> None:
        renderer = self.canvas.get_renderer()
        bbox = self._legend_outer_bbox(legend, renderer)
        left, top = self._clamped_legend_left_top(bbox.x0, bbox.y1, bbox, bounds)
        anchor_left, anchor_top = self._set_legend_outer_left_top(legend, left, top, renderer)
        x, y = self._legend_inside_position_from_display(anchor_left, anchor_top, bounds)
        settings.legend_inside_x = x
        settings.legend_inside_y = y

    def _legend_outer_bbox(self, legend, renderer):
        frame = legend.get_frame()
        if frame is not None and frame.get_visible():
            return frame.get_window_extent(renderer)
        return legend.get_window_extent(renderer)

    def _set_legend_outer_left_top(self, legend, left: float, top: float, renderer) -> tuple[float, float]:
        outer_bbox = self._legend_outer_bbox(legend, renderer)
        legend_bbox = legend.get_window_extent(renderer)
        anchor_left = legend_bbox.x0 + (left - outer_bbox.x0)
        anchor_top = legend_bbox.y1 + (top - outer_bbox.y1)
        fig_x, fig_y = self.figure.transFigure.inverted().transform((anchor_left, anchor_top))
        legend.set_loc("upper left")
        legend.set_bbox_to_anchor((float(fig_x), float(fig_y)), transform=self.figure.transFigure)
        return anchor_left, anchor_top

    def _finalize_inside_legend(self, ax, secondary_ax, settings: ChartSettings) -> None:
        if settings.legend_position != LEGEND_POSITION_INSIDE:
            return
        legend = ax.get_legend()
        if legend is None or not legend.get_visible():
            return
        renderer = self.canvas.get_renderer()
        bounds = self._inside_legend_bounds(
            [candidate for candidate in (ax, secondary_ax) if candidate is not None],
            renderer,
            settings,
        )
        self._clamp_inside_legend_artist(legend, bounds, settings)

    def _schedule_legend_layout_finalize(self, settings, ax, table_ax, secondary_ax) -> None:
        self._legend_layout_token += 1
        if settings.legend_position != LEGEND_POSITION_INSIDE or self.canvas is None:
            return
        token = self._legend_layout_token
        canvas = self.canvas
        rendered_size = (canvas.width(), canvas.height())
        QTimer.singleShot(
            0,
            canvas,
            lambda: self._finalize_legend_after_qt_layout(
                token, canvas, rendered_size, settings, ax, table_ax, secondary_ax
            ),
        )

    def _finalize_legend_after_qt_layout(
        self,
        token,
        canvas,
        rendered_size,
        settings,
        ax,
        table_ax,
        secondary_ax,
    ) -> None:
        if token != self._legend_layout_token or canvas is not self.canvas:
            return
        if (canvas.width(), canvas.height()) == rendered_size:
            return
        canvas.draw()
        self._finalize_inside_legend(ax, secondary_ax, settings)
        canvas.draw()
        self._refresh_interaction_targets(settings, ax, table_ax, secondary_ax)
        canvas.repaint()

    def _inside_legend_bounds(self, axes: list, renderer, settings: ChartSettings):
        bounds = self._plot_axes_union_bbox(axes, renderer)
        inset = max(1.0, renderer.points_to_pixels(max(settings.axis_line_width, 0.0)) / 2.0 + 0.5)
        width = max(1.0, bounds.width - inset * 2.0)
        height = max(1.0, bounds.height - inset * 2.0)
        return Bbox.from_bounds(bounds.x0 + inset, bounds.y0 + inset, width, height)

    def _plot_axes_union_bbox(self, axes: list, renderer):
        boxes = [axis.get_window_extent(renderer) for axis in axes if axis is not None]
        if not boxes:
            return Bbox.from_bounds(0.0, 0.0, max(self.figure.bbox.width, 1.0), max(self.figure.bbox.height, 1.0))
        return Bbox.union(boxes)

    def _legend_right_anchor_x(self, ax, settings: ChartSettings) -> float:
        base_anchor = 1.02
        if settings.chart_type == "Ridge":
            if not self._split_secondary_frame_enabled(settings):
                return base_anchor
            secondary_ax = next((axis for axis in self.figure.axes if axis.get_gid() == "secondary-axis"), None)
            if secondary_ax is None:
                return base_anchor
            renderer = self.canvas.get_renderer()
            axis_bounds = ax.get_window_extent(renderer)
            secondary_bounds = secondary_ax.get_window_extent(renderer)
            return base_anchor + max(0.0, secondary_bounds.x1 - axis_bounds.x1) / max(axis_bounds.width, 1.0)
        if not self._custom_overlay_secondary_axis_active(settings):
            return base_anchor

        secondary_ax = next((axis for axis in self.figure.axes if axis.get_gid() == "secondary-axis"), None)
        if secondary_ax is None or not secondary_ax.yaxis.label.get_text():
            return base_anchor

        renderer = self.canvas.get_renderer()
        axis_bounds = ax.get_window_extent(renderer)
        label_bounds = secondary_ax.yaxis.label.get_window_extent(renderer)
        if label_bounds.width <= 0.0:
            return base_anchor

        reserved_right_px = max(axis_bounds.x1, label_bounds.x1 + LEGEND_SECONDARY_AXIS_GAP_PX)
        anchor_x = 1.0 + (reserved_right_px - axis_bounds.x1) / max(axis_bounds.width, 1.0)
        return max(base_anchor, anchor_x)

    def _legend_label_text(
        self,
        label: object,
        settings: ChartSettings,
        columns: int = 1,
        renderer=None,
        force_wrap: bool = False,
    ) -> str:
        text = str(label).replace("\\n", "\n")
        if legend_auto_width_enabled(settings):
            return text
        if settings.legend_columns <= 0 and not force_wrap:
            return text
        if renderer is None:
            return legend_label_text(label, settings, columns, force_wrap=force_wrap)
        max_width_in = legend_text_width_inches(settings, columns)
        wrapped_lines = []
        for line in text.splitlines() or [""]:
            wrapped_lines.extend(self._wrap_text_to_width(line, max_width_in, settings.legend_font_size, renderer) or [""])
        return "\n".join(wrapped_lines)

    def _legend_wrap_units(self, settings: ChartSettings, columns: int = 1) -> float:
        return legend_wrap_units(settings, columns)

    def _legend_text_width_inches(self, settings: ChartSettings, columns: int = 1) -> float:
        return legend_text_width_inches(settings, columns)

    def _legend_total_width_inches(self, settings: ChartSettings) -> float:
        return legend_total_width_inches(settings)

    def _legend_auto_width_enabled(self, settings: ChartSettings) -> bool:
        return legend_auto_width_enabled(settings)

    def _legend_handle_space_inches(self, settings: ChartSettings) -> float:
        return legend_handle_space_inches(settings)

    def _legend_column_gap_inches(self, settings: ChartSettings) -> float:
        return legend_column_gap_inches(settings)

    def _legend_column_width_inches(self, settings: ChartSettings, columns: int) -> float:
        return legend_column_width_inches(settings, columns)

    def _wrap_text_to_width(self, text: str, max_width_in: float, font_size: int, renderer) -> list[str]:
        if self._measured_text_width_inches(text, font_size, renderer) <= max_width_in:
            return [text]

        pieces = [piece for piece in re.split(r"(\s+|[-/_:;,，。；：、]+)", text) if piece]
        if len(pieces) <= 1:
            return self._wrap_unbreakable_text(text, max_width_in, font_size, renderer)

        lines = []
        current = ""
        token_tolerance_in = max_width_in * 1.5
        for piece in pieces:
            candidate = f"{current}{piece}" if current else piece.lstrip()
            if not candidate:
                continue
            if self._measured_text_width_inches(candidate.rstrip(), font_size, renderer) <= max_width_in:
                current = candidate
                continue
            if current.strip():
                lines.append(current.rstrip())
                current = piece.lstrip()
                if current and self._measured_text_width_inches(current, font_size, renderer) > max_width_in:
                    if self._measured_text_width_inches(current, font_size, renderer) <= token_tolerance_in:
                        lines.append(current)
                    else:
                        lines.extend(self._wrap_unbreakable_text(current, max_width_in, font_size, renderer))
                    current = ""
            else:
                stripped = piece.strip()
                if self._measured_text_width_inches(stripped, font_size, renderer) <= token_tolerance_in:
                    lines.append(stripped)
                else:
                    lines.extend(self._wrap_unbreakable_text(stripped, max_width_in, font_size, renderer))
                current = ""
        if current.strip():
            lines.append(current.rstrip())
        return lines

    def _wrap_unbreakable_text(self, text: str, max_width_in: float, font_size: int, renderer) -> list[str]:
        lines = []
        current = ""
        for char in text:
            candidate = f"{current}{char}"
            if current and self._measured_text_width_inches(candidate, font_size, renderer) > max_width_in:
                lines.append(current)
                current = char
            else:
                current = candidate
        if current or not lines:
            lines.append(current)
        return lines

    def _measured_text_width_inches(self, text: str, font_size: int, renderer) -> float:
        artist = self.figure.text(0, 0, text, fontsize=font_size, alpha=0.0)
        try:
            return artist.get_window_extent(renderer).width / max(self.figure.dpi, 1.0)
        finally:
            artist.remove()

    def _wrap_visual_units(self, text: str, max_units: float) -> list[str]:
        return wrap_visual_units(text, max_units)

    def _legend_column_count(self, labels: list[str], settings: ChartSettings, renderer=None) -> int:
        if renderer is None:
            return legend_column_count(labels, settings)
        item_count = max(1, len(labels))
        if settings.legend_columns > 0:
            return min(max(1, settings.legend_columns), item_count)

        max_item_width = max(
            (self._legend_unwrapped_item_width_inches(label, settings, renderer) for label in labels),
            default=self._legend_handle_space_inches(settings),
        )
        column_gap = self._legend_column_gap_inches(settings)
        total_width = self._legend_total_width_inches(settings)
        columns_that_fit = math.floor((total_width + column_gap) / max(max_item_width + column_gap, 0.01))
        return min(max(1, columns_that_fit), item_count, LEGEND_MAX_COLUMNS)

    def _legend_force_wrap(self, labels: list[str], settings: ChartSettings, renderer=None) -> bool:
        if renderer is None:
            return legend_force_wrap(labels, settings)
        if legend_auto_width_enabled(settings):
            return False
        if settings.legend_columns > 0:
            return True
        max_item_width = max(
            (self._legend_unwrapped_item_width_inches(label, settings, renderer) for label in labels),
            default=self._legend_handle_space_inches(settings),
        )
        return self._legend_total_width_inches(settings) < max_item_width

    def _legend_unwrapped_item_width_inches(self, label: object, settings: ChartSettings, renderer=None) -> float:
        if renderer is None:
            return legend_unwrapped_item_width_inches(label, settings)
        text = str(label).replace("\\n", "\n")
        lines = text.splitlines() or [""]
        text_width = max((self._measured_text_width_inches(line, settings.legend_font_size, renderer) for line in lines), default=0.0)
        return text_width + legend_handle_space_inches(settings)

    def _overlay_axis_marker_margin_points(self, settings: ChartSettings) -> float:
        return overlay_axis_marker_margin_points(settings)

    def _ridge_stat_table_bounds(self, table_ax, renderer):
        return Bbox.union([
            table_ax.get_tightbbox(renderer),
            table_ax.transData.transform_bbox(table_ax.dataLim),
        ])

    def _fit_ridge_stat_table_overflow(self, table_ax) -> bool:
        renderer = self.canvas.get_renderer()
        bounds = self._ridge_stat_table_bounds(table_ax, renderer)
        padding = renderer.points_to_pixels(4)
        margins = (
            max(0, math.ceil(padding - bounds.x0)),
            max(0, math.ceil(bounds.x1 + padding - self.figure.bbox.width)),
            max(0, math.ceil(padding - bounds.y0)),
            max(0, math.ceil(bounds.y1 + padding - self.figure.bbox.height)),
        )
        if not any(margins):
            return False
        self._expand_canvas_margins(*margins)
        return True

    def _ridge_stat_table_column_widths(
        self, labels: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings,
    ) -> list[float]:
        renderer = self.canvas.get_renderer()
        columns = [["", *labels], *[[label, *values] for label, values in rows]]
        return [
            max(
                self._measured_text_width_inches(str(value), settings.stat_table_font_size, renderer)
                for value in column
            ) + 0.20
            for column in columns
        ]

    def _draw_ridge_stat_table(
        self, table_ax, groups: list[str], rows: list[tuple[str, list[str]]],
        settings: ChartSettings, text_color: str,
        column_widths: list[float], row_heights: list[float],
    ) -> None:
        layout = self._group_layout
        positions = [layout.coordinate(group, ridge=True) for group in groups]
        edges = np.concatenate(([0.0], np.cumsum(column_widths)))
        table_ax.set_xlim(0, edges[-1])
        table_ax.axis("off")
        # Sharing Y limits and the physical axis height keeps rows aligned even
        # after content fitting, group spacing changes, and canvas resizing.
        units_per_inch = np.ptp(table_ax.get_ylim()) / (
            table_ax.get_position().height * self.figure.get_figheight()
        )
        # Rows stay compact in physical units; the spaces between them absorb
        # the category spacing instead of stretching the cells.
        half_heights = np.asarray(row_heights) * units_per_inch / 2
        header_height = self._stat_table_row_height_inches(settings) * units_per_inch
        header_bottom = max(
            position + half_height for position, half_height in zip(positions, half_heights)
        )
        header_top = header_bottom + header_height
        edge_color = "#D1D5DB" if PRESETS[settings.preset]["background"] == "#FFFFFF" else "#4B5563"
        centers = (edges[:-1] + edges[1:]) / 2
        for center, label in zip(centers, ["", *[label for label, _ in rows]]):
            if label:
                table_ax.text(
                    center, (header_bottom + header_top) / 2, label,
                    ha="center", va="center", color=text_color,
                    fontsize=settings.stat_table_font_size, clip_on=False,
                )
        bands = [(header_bottom, header_top)]
        for index, (group, position) in enumerate(zip(groups, positions)):
            values = [layout.labels[group], *[values[index] for _, values in rows]]
            for center, value in zip(centers, values):
                table_ax.text(
                    center, position, value, ha="center", va="center", color=text_color,
                    fontsize=settings.stat_table_font_size, linespacing=1.15, clip_on=False,
                )
            bands.append((position - half_heights[index], position + half_heights[index]))
        for bottom, top in bands:
            table_ax.vlines(edges, bottom, top, colors=edge_color, linewidth=0.6, clip_on=False)
        horizontal_edges = sorted({edge for band in bands for edge in band})
        table_ax.hlines(horizontal_edges, edges[0], edges[-1], colors=edge_color, linewidth=0.6, clip_on=False)

    def _draw_stat_table(
        self,
        table_ax,
        groups: list[str],
        rows: list[tuple[str, list[str]]],
        settings: ChartSettings,
        text_color: str,
    ) -> None:
        if not groups or not rows:
            return
        layout = getattr(self, "_group_layout", None)
        positions = [layout.positions[group] for group in groups] if layout is not None else list(range(len(groups)))
        limits = layout.limits if layout is not None else (-0.5, len(groups) - 0.5)
        half_width = layout.inner_spacing / 2 if layout is not None else 0.5
        table_ax.set_xlim(*limits)
        font_size = settings.stat_table_font_size
        display_labels = [layout.labels[group] for group in groups] if layout is not None else [str(group) for group in groups]
        all_rows = [("", display_labels)] if stat_table_header_enabled(settings) else []
        all_rows.extend(rows)
        row_heights = self._stat_table_row_height_units(display_labels, rows, settings)
        total_height = sum(row_heights)
        table_ax.set_ylim(0, total_height)
        table_ax.axis("off")
        preset = PRESETS[settings.preset]
        edge_color = "#D1D5DB" if preset["background"] == "#FFFFFF" else "#4B5563"

        y_cursor = total_height
        row_edges = [total_height]
        for row_index, (label, values) in enumerate(all_rows):
            row_height = row_heights[row_index]
            y_cursor -= row_height
            row_edges.append(y_cursor)
            if label:
                table_ax.text(
                    limits[0] - 0.08,
                    y_cursor + row_height / 2,
                    label,
                    ha="right",
                    va="center",
                    color=text_color,
                    fontsize=font_size,
                    clip_on=False,
                    linespacing=1.15,
                )
            for column, value in enumerate(values):
                table_ax.text(
                    positions[column],
                    y_cursor + row_height / 2,
                    value,
                    ha="center",
                    va="center",
                    color=text_color,
                    fontsize=font_size,
                    linespacing=1.15,
                )
        line_width = 0.6
        edges = sorted({position + delta for position in positions for delta in (-half_width, half_width)})
        for x_value in edges:
            table_ax.vlines(x_value, 0, total_height, colors=edge_color, linewidth=line_width, clip_on=False)
        for y_value in row_edges:
            for position in positions:
                table_ax.hlines(y_value, position - half_width, position + half_width, colors=edge_color, linewidth=line_width, clip_on=False)

    def _fit_table_left_margin(self, ax, table_ax, settings: ChartSettings) -> None:
        renderer = self.canvas.get_renderer()
        text_artists = [text for text in table_ax.texts if text.get_visible()]
        text_artists.append(ax.yaxis.label)
        if settings.chart_type == "Ridge":
            text_artists.extend(label for label in ax.get_yticklabels() if label.get_visible())
        left_edges = [
            artist.get_window_extent(renderer).x0
            for artist in text_artists
            if artist.get_text()
        ]
        if not left_edges:
            return
        overflow_px = 6.0 - min(left_edges)
        if overflow_px <= 0:
            return
        delta = overflow_px / max(self.figure.bbox.width, 1.0)
        for target_ax in (ax, table_ax):
            position = target_ax.get_position()
            new_left = min(position.x0 + delta, position.x1 - 0.20)
            target_ax.set_position([new_left, position.y0, position.x1 - new_left, position.height])

    def _stat_table_row_height_inches(self, settings: ChartSettings) -> float:
        return stat_table_row_height_inches(settings)

    def _stat_table_height_inches(self, groups: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings) -> float:
        return stat_table_height_inches(groups, rows, settings)

    def _stat_table_row_height_units(self, groups: list[str], rows: list[tuple[str, list[str]]], settings: ChartSettings) -> list[float]:
        return stat_table_row_height_units(groups, rows, settings)

    def _stat_table_gap_inches(self, settings: ChartSettings, groups: list[str], x_axis_label: str) -> float:
        return stat_table_gap_inches(settings, groups, x_axis_label)

    @staticmethod
    def _additional_guide_label_bounds(artists: list, renderer) -> list[Bbox]:
        bounds: list[Bbox] = []
        for artist in artists:
            if (
                artist.get_gid()
                not in {"additional-tick-label", "additional-tick-value"}
                or not artist.get_visible()
            ):
                continue
            background = artist.get_bbox_patch()
            if background is not None:
                update_bbox = getattr(
                    artist,
                    "update_bbox_position_size",
                    None,
                )
                if callable(update_bbox):
                    update_bbox(renderer)
                bbox = background.get_window_extent(renderer)
            else:
                bbox = artist.get_window_extent(renderer)
            if np.isfinite(bbox.extents).all():
                bounds.append(bbox)
        return bounds

    def _space_axis_labels_for_additional_guides(
        self,
        ax,
        *,
        x_artists: list | tuple = (),
        y_artists: list | tuple = (),
    ) -> bool:
        """Move axis titles beyond visible guide labels using measured bounds."""

        renderer = self.canvas.get_renderer()
        axes_bounds = ax.get_window_extent(renderer)
        gap_px = renderer.points_to_pixels(3.0)
        points_per_pixel = 1.0 / max(renderer.points_to_pixels(1.0), 1e-9)
        changed = False

        x_label = ax.xaxis.label
        if x_label.get_visible() and x_label.get_text():
            outward = [
                bbox
                for bbox in self._additional_guide_label_bounds(
                    list(x_artists),
                    renderer,
                )
                if bbox.y0 < axes_bounds.y0 + gap_px
            ]
            if outward:
                label_bounds = x_label.get_window_extent(renderer)
                target_top = min(bbox.y0 for bbox in outward) - gap_px
                overlap_px = label_bounds.y1 - target_top
                if overlap_px > 0.5:
                    ax.xaxis.labelpad += overlap_px * points_per_pixel
                    changed = True

        y_label = ax.yaxis.label
        if y_label.get_visible() and y_label.get_text():
            outward = [
                bbox
                for bbox in self._additional_guide_label_bounds(
                    list(y_artists),
                    renderer,
                )
                if bbox.x0 < axes_bounds.x0 + gap_px
            ]
            if outward:
                label_bounds = y_label.get_window_extent(renderer)
                target_right = min(bbox.x0 for bbox in outward) - gap_px
                overlap_px = label_bounds.x1 - target_right
                if overlap_px > 0.5:
                    ax.yaxis.labelpad += overlap_px * points_per_pixel
                    changed = True
        return changed

    def _fit_additional_guide_overflow(
        self,
        ax,
        artists: list,
        *,
        table_ax=None,
        secondary_ax=None,
    ) -> bool:
        """Expand the existing canvas around measured, visible guide labels."""

        renderer = self.canvas.get_renderer()
        bounds = self._additional_guide_label_bounds(artists, renderer)
        if not bounds:
            return False
        for axis_label in (ax.xaxis.label, ax.yaxis.label):
            if axis_label.get_visible() and axis_label.get_text():
                bbox = axis_label.get_window_extent(renderer)
                if np.isfinite(bbox.extents).all():
                    bounds.append(bbox)

        figure_bounds = self.figure.bbox
        padding_px = renderer.points_to_pixels(4.0)
        internal_plot_shift_px = 0
        if table_ax is not None:
            lower_plot_bounds = self._additional_guide_label_bounds(
                artists,
                renderer,
            )
            x_axis_label = ax.xaxis.label
            if x_axis_label.get_visible() and x_axis_label.get_text():
                bbox = x_axis_label.get_window_extent(renderer)
                if np.isfinite(bbox.extents).all():
                    lower_plot_bounds.append(bbox)
            if lower_plot_bounds:
                table_top = table_ax.get_window_extent(renderer).y1
                lowest_plot_content = min(
                    bbox.y0 for bbox in lower_plot_bounds
                )
                internal_plot_shift_px = math.ceil(
                    max(
                        0.0,
                        table_top + padding_px - lowest_plot_content,
                    )
                )
        left_px = math.ceil(
            max(0.0, padding_px - min(bbox.x0 for bbox in bounds))
        )
        right_px = math.ceil(
            max(
                0.0,
                max(bbox.x1 for bbox in bounds)
                - (figure_bounds.width - padding_px),
            )
        )
        bottom_px = math.ceil(
            max(0.0, padding_px - min(bbox.y0 for bbox in bounds))
        )
        top_px = math.ceil(
            max(
                0.0,
                max(bbox.y1 for bbox in bounds)
                - (figure_bounds.height - padding_px),
            )
        )
        if not any(
            (
                left_px,
                right_px,
                bottom_px,
                top_px,
                internal_plot_shift_px,
            )
        ):
            return False

        self._expand_canvas_margins(
            left_px, right_px, bottom_px, top_px,
            plot_shift_px=internal_plot_shift_px,
            shifted_axes=(ax, secondary_ax),
        )
        return True

    def _expand_canvas_margins(
        self, left_px, right_px, bottom_px, top_px, *, plot_shift_px=0, shifted_axes=(),
    ) -> None:
        if not any((left_px, right_px, bottom_px, top_px, plot_shift_px)):
            return
        old_width = float(self.figure.bbox.width)
        old_height = float(self.figure.bbox.height)
        requested_width = old_width + left_px + right_px
        requested_height = (
            old_height
            + bottom_px
            + top_px
            + plot_shift_px
        )
        # Figure bounds and measured text use physical pixels, while QWidget
        # sizing uses logical pixels. Passing physical dimensions to Qt on a
        # Retina/HiDPI display doubles both canvas dimensions and leaves the
        # blit buffer out of sync with the widget.
        device_pixel_ratio = max(
            float(getattr(self.canvas, "device_pixel_ratio", 1.0)),
            1.0,
        )
        logical_width = int(math.ceil(requested_width / device_pixel_ratio))
        logical_height = int(math.ceil(requested_height / device_pixel_ratio))
        new_width = float(logical_width) * device_pixel_ratio
        new_height = float(logical_height) * device_pixel_ratio
        positions = {
            target_ax: target_ax.get_position().frozen()
            for target_ax in self.figure.axes
        }

        self._invalidate_blit_background()
        self.canvas.setFixedSize(logical_width, logical_height)
        self.figure.set_size_inches(
            new_width / max(float(self.figure.dpi), 1.0),
            new_height / max(float(self.figure.dpi), 1.0),
            forward=False,
        )
        for target_ax, position in positions.items():
            axis_shift_px = (
                plot_shift_px
                if target_ax in shifted_axes
                else 0
            )
            target_ax.set_position(
                [
                    (position.x0 * old_width + left_px) / new_width,
                    (
                        position.y0 * old_height
                        + bottom_px
                        + axis_shift_px
                    )
                    / new_height,
                    position.width * old_width / new_width,
                    position.height * old_height / new_height,
                ]
            )
        self._canvas_size = (logical_width, logical_height)

    def _plot_left_margin_inches(
        self,
        settings: ChartSettings,
        groups: list[object],
        y_axis_label: str,
        stat_rows: list[tuple[str, list[str]]],
    ) -> float:
        return plot_left_margin_inches(settings, groups, y_axis_label, stat_rows)

    def _rotated_axis_label_width_inches(self, text: str, font_size: int, pad: float = 0.30) -> float:
        return rotated_axis_label_width_inches(text, font_size, pad)

    def _plot_right_margin_inches(self, settings: ChartSettings) -> float:
        return plot_right_margin_inches(settings)

    def _legend_outside_needed(self, settings: ChartSettings) -> bool:
        return legend_outside_needed(settings)

    def _legend_right_margin_inches(self, settings: ChartSettings) -> float:
        return legend_right_margin_inches(settings)

    def _legend_render_width_inches(self, labels: list[str], settings: ChartSettings) -> float:
        return legend_render_width_inches(labels, settings)

    def _legend_labels_for_settings(self, settings: ChartSettings) -> list[str]:
        return legend_labels_for_settings(settings)

    def _plot_top_margin_inches(self, settings: ChartSettings) -> float:
        return plot_top_margin_inches(settings)

    def _plot_bottom_margin_inches(self, settings: ChartSettings, groups: list[str], x_axis_label: str) -> float:
        return plot_bottom_margin_inches(settings, groups, x_axis_label)

    def _rotated_value_axis_label_height_overflow_inches(
        self,
        y_axis_label: str,
        settings: ChartSettings,
        total_height_in: float,
        label_center_in: float,
    ) -> tuple[float, float]:
        return rotated_value_axis_label_height_overflow_inches(y_axis_label, settings, total_height_in, label_center_in)

    def _horizontal_axis_label_width_overflow_inches(
        self,
        x_axis_label: str,
        settings: ChartSettings,
        total_width_in: float,
        label_center_in: float,
    ) -> tuple[float, float]:
        return horizontal_axis_label_width_overflow_inches(x_axis_label, settings, total_width_in, label_center_in)

    def _line_count(self, text: object) -> int:
        return line_count(text)

    def _max_line_count(self, values: list[object]) -> int:
        return max_line_count(values)

    def _max_text_width_inches(self, values: list[object], font_size: int) -> float:
        return max_text_width_inches(values, font_size)

    def _text_visual_units(self, text: str) -> float:
        return text_visual_units(text)

    def _jitter_offsets(self, values: np.ndarray, width: float, mode: str, key: str) -> np.ndarray:
        return jitter_offsets(values, width, mode, key)

    def _random_offsets(self, key: str, count: int, width: float) -> np.ndarray:
        return random_offsets(key, count, width)

    def _beeswarm_offsets(self, values: np.ndarray, width: float) -> np.ndarray:
        return beeswarm_offsets(values, width)

    def _quasirandom_offsets(self, values: np.ndarray, width: float) -> np.ndarray:
        return quasirandom_offsets(values, width)

    def _van_der_corput(self, index: int, base: int = 2) -> float:
        return van_der_corput(index, base)

    def export(self, path: str, settings: ChartSettings) -> None:
        suffix = Path(path).suffix.lower()
        # JPEG cannot carry alpha; flatten it against the active chart preset
        # instead of Matplotlib's white fallback (which can erase light text).
        transparent = settings.transparent_background and suffix not in {".jpg", ".jpeg"}
        kwargs = {
            "dpi": settings.dpi,
            "bbox_inches": "tight",
            "transparent": transparent,
        }
        if not transparent:
            kwargs["facecolor"] = self.figure.get_facecolor()
        if suffix in {".png", ".tif", ".tiff", ".jpg", ".jpeg", ".pdf", ".svg"}:
            self._savefig_without_interaction_feedback(path, **kwargs)

    def copy_to_clipboard(self, settings: ChartSettings) -> bool:
        buffer = BytesIO()
        kwargs = {
            "format": "png",
            "dpi": settings.dpi,
            "bbox_inches": "tight",
            "transparent": settings.transparent_background,
        }
        if not settings.transparent_background:
            kwargs["facecolor"] = self.figure.get_facecolor()
        self._savefig_without_interaction_feedback(buffer, **kwargs)
        png_data = buffer.getvalue()
        image = QImage()
        image.loadFromData(png_data, "PNG")
        if image.isNull():
            return False
        mime_data = QMimeData()
        # Offer the exact Matplotlib PNG first so clipboard consumers can keep
        # its straight-alpha antialiasing instead of converting a platform bitmap.
        mime_data.setData("image/png", QByteArray(png_data))
        mime_data.setImageData(image)
        mime_data.setProperty(_CHART_CLIPBOARD_MIME_PROPERTY, True)
        _ensure_chart_clipboard_shutdown_cleanup()
        QApplication.clipboard().setMimeData(mime_data)
        return True

    def _savefig_without_interaction_feedback(self, *args, **kwargs) -> None:
        patches = []
        for attribute in (
            "_hover_feedback_patch",
            "_selected_feedback_patch",
            "_xy_box_selection_patch",
        ):
            feedback = getattr(self, attribute, None)
            if feedback is None:
                continue
            if isinstance(feedback, (list, tuple)):
                patches.extend(feedback)
            else:
                patches.append(feedback)
        visibility = [(patch, patch.get_visible()) for patch in patches]
        try:
            for patch, _visible in visibility:
                patch.set_visible(False)
            self.figure.savefig(*args, **kwargs)
        finally:
            for patch, visible in visibility:
                patch.set_visible(visible)
            if visibility and self.canvas is not None:
                self._redraw_interaction_artists()
