from __future__ import annotations

from matplotlib.colors import is_color_like, to_rgba

from easygraph.xy_data import PreparedXYData
from easygraph.xy_series import (
    XYSettings,
    resolved_series_line_width,
    resolved_series_point_alpha,
    resolved_series_point_size,
)


MARKERS = {
    "Circle": "o",
    "Square": "s",
    "Triangle": "^",
    "Diamond": "D",
    "Plus": "+",
    "Cross": "x",
}

LINE_STYLES = {
    "Auto": "-",
    "Solid": "-",
    "Dashed": "--",
    "Dotted": ":",
    "Dash-dot": "-.",
    "Long dash": (0, (10, 3)),
    "Dense dash": (0, (4, 1.5)),
    "Loose dot": (0, (1, 5)),
    "Dash-dot-dot": (0, (7, 2, 1, 2, 1, 2)),
}


def marker_for(name: str) -> str:
    return MARKERS.get(str(name), "o")


def line_style_for(name: str) -> str | tuple:
    return LINE_STYLES.get(str(name), "-")


def draw_xy_series(
    ax,
    prepared: PreparedXYData,
    settings: XYSettings,
    palette: list[str] | tuple[str, ...],
    *,
    mark_point_artist=None,
    mark_plot_content_artist=None,
) -> list:
    colors = list(palette) or ["#4E79A7"]
    artists = []
    for color_index, series in enumerate(prepared.visible_numeric_series):
        requested_color = series.spec.color
        color = (
            requested_color
            if requested_color and is_color_like(requested_color)
            else colors[color_index % len(colors)]
        )
        marker = marker_for(series.spec.marker or settings.marker)
        line_style = line_style_for(series.spec.line_style or settings.line_style)
        point_size = resolved_series_point_size(settings, series.spec)
        point_alpha = resolved_series_point_alpha(settings, series.spec)
        line_width = resolved_series_line_width(settings, series.spec)
        if series.show_points and series.show_line:
            marker_color = to_rgba(color, alpha=point_alpha)
            artist, = ax.plot(
                series.x,
                series.y,
                color=color,
                linewidth=line_width,
                linestyle=line_style,
                marker=marker,
                markersize=point_size,
                markerfacecolor=marker_color,
                markeredgecolor=marker_color,
                label=series.name,
                zorder=3,
            )
            if mark_point_artist is not None:
                mark_point_artist(artist)
        elif series.show_points:
            artist = ax.scatter(
                series.x,
                series.y,
                s=point_size ** 2,
                marker=marker,
                color=color,
                alpha=point_alpha,
                label=series.name,
                zorder=3,
            )
            if mark_point_artist is not None:
                mark_point_artist(artist)
        else:
            artist, = ax.plot(
                series.x,
                series.y,
                color=color,
                linewidth=line_width,
                linestyle=line_style,
                label=series.name,
                zorder=3,
            )
            if mark_point_artist is not None:
                mark_point_artist(artist)
            elif mark_plot_content_artist is not None:
                mark_plot_content_artist(artist)
        artist._easygraph_series_id = series.id
        artists.append(artist)
    return artists


__all__ = [
    "LINE_STYLES",
    "MARKERS",
    "draw_xy_series",
    "line_style_for",
    "marker_for",
]
