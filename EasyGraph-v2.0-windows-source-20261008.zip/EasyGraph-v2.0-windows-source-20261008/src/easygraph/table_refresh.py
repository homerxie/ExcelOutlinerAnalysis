from __future__ import annotations

from easygraph.data_table import DataTable
from easygraph.table_data import column_header_labels, row_header_labels
from easygraph.table_style import apply_table_row_styles, header_row_height, row_header_min_width


def refresh_table_structure(
    table: DataTable,
    sample_start_row: int,
    overlay_series: list[dict],
    overlay_row_count: int,
    blend_colors,
    column_roles: tuple[str, ...] | list[str] | None = None,
    column_labels: tuple[str, ...] | list[str] | None = None,
    column_tooltips: tuple[str, ...] | list[str] | None = None,
) -> None:
    table.table_model.set_horizontal_headers(
        column_labels
        if column_labels is not None
        else column_header_labels(table.table_model.columnCount(), column_roles),
        column_tooltips,
    )
    table.setRowHeight(0, header_row_height(table))
    table.table_model.set_vertical_headers(
        row_header_labels(
            table.table_model.rowCount(),
            sample_start_row,
            overlay_series,
        )
    )
    table.verticalHeader().setMinimumWidth(row_header_min_width(overlay_row_count))
    apply_table_row_styles(table, sample_start_row, blend_colors)
