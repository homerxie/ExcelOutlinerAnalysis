"""Shared display-only number formatting for descriptive statistics."""

from __future__ import annotations

STATISTIC_NAMES = ("Mean", "Median", "Q1", "Q3", "Max", "Min", "SD", "SEM", "Sum")
MAX_STATISTIC_DECIMALS = 12


def normalize_statistic_formats(formats: object) -> dict[str, dict]:
    if not isinstance(formats, dict):
        return {}
    normalized = {}
    for name in STATISTIC_NAMES:
        options = formats.get(name)
        if not isinstance(options, dict):
            continue
        try:
            decimals = int(options.get("decimals", 2))
        except (TypeError, ValueError, OverflowError):
            decimals = 2
        normalized[name] = {
            "decimals": max(0, min(decimals, MAX_STATISTIC_DECIMALS)),
            "scientific": options.get("scientific") is True,
            "trim_zeros": options.get("trim_zeros") is True,
        }
    return normalized


def format_statistic_value(
    value: float,
    statistic: str | None,
    formats: dict[str, dict],
    *,
    default_decimals: int = 2,
    default_scientific: bool = False,
) -> str:
    options = formats.get(statistic, {})
    decimals = max(0, min(int(options.get("decimals", default_decimals)), MAX_STATISTIC_DECIMALS))
    format_type = "e" if options.get("scientific", default_scientific) else "f"
    text = f"{value:.{decimals}{format_type}}"
    if options.get("trim_zeros", False):
        mantissa, separator, exponent = text.partition("e")
        if "." in mantissa:
            mantissa = mantissa.rstrip("0").rstrip(".")
        text = mantissa + separator + exponent
    return text
