"""Public identity and release metadata for EasyGraph."""

APP_NAME = "EasyGraph"
APP_VERSION = "2.0"
APP_DISPLAY_NAME = f"{APP_NAME} v{APP_VERSION}"


__all__ = [
    "APP_DISPLAY_NAME",
    "APP_NAME",
    "APP_VERSION",
]
