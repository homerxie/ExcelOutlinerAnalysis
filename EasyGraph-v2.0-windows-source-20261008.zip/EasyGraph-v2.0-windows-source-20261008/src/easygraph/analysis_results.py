from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from easygraph.numeric import coerce_numeric_series
from easygraph.settings import STAT_TABLE_OPTIONS
from easygraph.statistic_formats import format_statistic_value, normalize_statistic_formats

__all__ = [
    "AnalysisSettings",
    "AnalysisTableResult",
    "DESCRIPTIVE_STATISTICS",
    "descriptive_statistics_result",
]


DESCRIPTIVE_STATISTICS = tuple(label for _setting_name, label in STAT_TABLE_OPTIONS)


@dataclass
class AnalysisSettings:
    """Per-sheet analysis choices persisted independently from plot settings."""

    visible_statistics: list[str] = field(
        default_factory=lambda: list(DESCRIPTIVE_STATISTICS)
    )
    statistic_formats: dict[str, dict] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.statistic_formats = normalize_statistic_formats(self.statistic_formats)
        selected = {str(label) for label in self.visible_statistics}
        ordered = [
            label for label in DESCRIPTIVE_STATISTICS if label in selected
        ]
        self.visible_statistics = ordered or list(DESCRIPTIVE_STATISTICS)


@dataclass(frozen=True)
class AnalysisTableResult:
    """A renderer-independent table produced by one analysis provider."""

    key: str
    title: str
    columns: tuple[str, ...]
    row_labels: tuple[str, ...]
    values: tuple[tuple[str, ...], ...]
    source_aligned: bool = True

    def __post_init__(self) -> None:
        column_count = len(self.columns)
        if len(self.row_labels) != len(self.values):
            raise ValueError("Analysis row labels and values must have the same length.")
        if any(len(row) != column_count for row in self.values):
            raise ValueError("Every analysis row must match the result column count.")


def descriptive_statistics_result(
    dataframe: pd.DataFrame,
    visible_statistics: set[str] | frozenset[str] | None = None,
    *,
    title: str = "Descriptive statistics",
    statistic_formats: dict[str, dict] | None = None,
) -> AnalysisTableResult:
    """Return descriptive statistics aligned to the unfiltered source table.

    Results intentionally do not accept ``ChartSettings``: plot filtering,
    ordering, outlier handling, and chart number formatting must never alter
    this table. Analysis number formats are supplied independently.
    Every physical source column is calculated independently, including
    columns with identical labels.
    """

    columns = tuple(str(column) for column in dataframe.columns)
    if not columns:
        return AnalysisTableResult(
            key="descriptive_statistics",
            title=title,
            columns=(),
            row_labels=(),
            values=(),
        )

    selected = (
        set(DESCRIPTIVE_STATISTICS)
        if visible_statistics is None
        else {str(label) for label in visible_statistics}
    )
    populated_groups = {
        index: values
        for index in range(len(columns))
        if not (values := coerce_numeric_series(dataframe.iloc[:, index]).dropna()).empty
    }
    if not populated_groups:
        return AnalysisTableResult(
            key="descriptive_statistics",
            title=title,
            columns=columns,
            row_labels=(),
            values=(),
        )

    formats = normalize_statistic_formats(statistic_formats)

    def formatted(values: pd.Series, calculation, label: str) -> str:
        value = calculation(values)
        if pd.isna(value):
            return ""
        return format_statistic_value(float(value), label, formats)

    def sample_sd(values: pd.Series) -> float:
        return float(values.std(ddof=1)) if len(values) > 1 else np.nan

    def sample_sem(values: pd.Series) -> float:
        return sample_sd(values) / np.sqrt(len(values)) if len(values) > 1 else np.nan

    row_specs = {
        "Mean": lambda values: values.mean(),
        "Median": lambda values: values.median(),
        "Q1": lambda values: values.quantile(0.25),
        "Q3": lambda values: values.quantile(0.75),
        "Max": lambda values: values.max(),
        "Min": lambda values: values.min(),
        "SD": sample_sd,
        "SEM": sample_sem,
        "Sum": lambda values: values.sum(),
    }
    rows: list[tuple[str, tuple[str, ...]]] = []
    for _setting_name, label in STAT_TABLE_OPTIONS:
        if label not in selected:
            continue
        if label == "Sample":
            row = tuple(
                str(len(populated_groups[column]))
                if column in populated_groups
                else ""
                for column in range(len(columns))
            )
        else:
            calculation = row_specs[label]
            row = tuple(
                formatted(populated_groups[column], calculation, label)
                if column in populated_groups
                else ""
                for column in range(len(columns))
            )
        rows.append((label, row))

    return AnalysisTableResult(
        key="descriptive_statistics",
        title=title,
        columns=columns,
        row_labels=tuple(label for label, _row in rows),
        values=tuple(row for _label, row in rows),
    )
