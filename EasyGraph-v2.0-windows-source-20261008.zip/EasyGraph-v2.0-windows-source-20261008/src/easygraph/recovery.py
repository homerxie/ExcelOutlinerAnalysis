from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from queue import Empty, Queue
import shutil
from threading import Event, Lock, Thread
import time
from typing import Any
from uuid import uuid4

import pandas as pd
from PySide6.QtCore import QLockFile, QStandardPaths, QTimer

from easygraph.analysis_results import AnalysisSettings
from easygraph.grouping import grouping_from_dict, normalize_grouping
from easygraph.data import attach_group_metadata, migrate_group_settings
from easygraph.project_io import (
    chart_settings_from_dict,
    read_workbook_project,
    write_project,
    xy_settings_from_dict,
)
from easygraph.workbook import (
    SHEET_MODE_XY,
    SheetDocument,
    WorkbookDocument,
    new_column_id,
    normalized_sheet_mode,
)
from easygraph.xy_series import remove_xy_column_references


RECOVERY_FORMAT_VERSION = 1
RECOVERY_DIRECTORY_NAME = "recovery"
MANIFEST_FILE = "manifest.json"
LOCK_FILE = "session.lock"
DEFAULT_MAX_PENDING_OPERATIONS = 10_000


@dataclass(frozen=True)
class RecoveryCandidate:
    session_dir: Path
    source_project: Path | None
    updated_at: str


@dataclass(frozen=True)
class _CheckpointRequest:
    document_id: str
    checkpoint_file: str
    checkpoint_sequence: int
    workbook: WorkbookDocument
    source_project: str
    dirty: bool


@dataclass(frozen=True)
class _CheckpointResult:
    request: _CheckpointRequest
    error: Exception | None


def recovery_root_path(root: Path | None = None) -> Path:
    if root is not None:
        return Path(root)
    app_data = QStandardPaths.writableLocation(
        QStandardPaths.StandardLocation.AppLocalDataLocation
    )
    return Path(app_data) / RECOVERY_DIRECTORY_NAME


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_write_bytes(path: Path, payload: bytes) -> None:
    temporary = path.with_name(f".{path.name}.{uuid4().hex}.tmp")
    try:
        with temporary.open("wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    _atomic_write_bytes(
        path,
        json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"),
    )


def _read_manifest(session_dir: Path) -> dict[str, Any]:
    raw = json.loads((session_dir / MANIFEST_FILE).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("Recovery manifest is invalid.")
    return raw


def _discard_session(session_dir: Path) -> None:
    if session_dir.is_dir():
        shutil.rmtree(session_dir, ignore_errors=True)


def discard_recovery(candidate: RecoveryCandidate | Path) -> None:
    session_dir = (
        candidate.session_dir
        if isinstance(candidate, RecoveryCandidate)
        else Path(candidate)
    )
    _discard_session(session_dir)


def find_recovery_candidates(root: Path | None = None) -> list[RecoveryCandidate]:
    directory = recovery_root_path(root)
    if not directory.is_dir():
        return []
    candidates: list[RecoveryCandidate] = []
    for session_dir in directory.glob("session-*"):
        if not session_dir.is_dir():
            continue
        lock = QLockFile(str(session_dir / LOCK_FILE))
        if not lock.tryLock(0):
            continue
        should_discard = False
        try:
            manifest = _read_manifest(session_dir)
            checkpoint = session_dir / str(manifest.get("checkpoint_file", ""))
            valid = (
                manifest.get("format_version") == RECOVERY_FORMAT_VERSION
                and manifest.get("ready") is True
                and manifest.get("dirty") is True
                and checkpoint.is_file()
            )
            if not valid:
                should_discard = True
            else:
                source_text = str(manifest.get("source_project", "")).strip()
                candidates.append(
                    RecoveryCandidate(
                        session_dir=session_dir,
                        source_project=Path(source_text) if source_text else None,
                        updated_at=str(manifest.get("updated_at", "")),
                    )
                )
        except (OSError, ValueError, json.JSONDecodeError):
            should_discard = True
        finally:
            lock.unlock()
        if should_discard:
            _discard_session(session_dir)
    return sorted(candidates, key=lambda item: item.updated_at, reverse=True)


def _journal_path(session_dir: Path, manifest: dict[str, Any]) -> Path:
    return session_dir / str(manifest["journal_file"])


def _iter_journal_operations(
    path: Path,
    *,
    after_sequence: int,
):
    if not path.is_file():
        return
    lines = path.read_text(encoding="utf-8").splitlines()
    for index, line in enumerate(lines):
        if not line.strip():
            continue
        try:
            operation = json.loads(line)
        except json.JSONDecodeError:
            if index == len(lines) - 1:
                break
            raise ValueError("Recovery journal contains an invalid record.")
        if not isinstance(operation, dict):
            raise ValueError("Recovery journal record is invalid.")
        if int(operation.get("sequence", -1)) > after_sequence:
            yield operation


def _blank_rows(count: int, columns: list[str]) -> pd.DataFrame:
    return pd.DataFrame([[""] * len(columns) for _ in range(count)], columns=columns)


def _apply_cell_operation(sheet: SheetDocument, operation: dict[str, Any]) -> None:
    row = int(operation["row"])
    column = int(operation["column"])
    value = str(operation.get("value", ""))
    if not 0 <= column < len(sheet.dataframe.columns):
        return
    if sheet.mode != SHEET_MODE_XY:
        migrate_group_settings(sheet.settings, attach_group_metadata(sheet.dataframe, sheet.column_ids))
    headers = [str(header) for header in sheet.dataframe.columns]
    if row == 0:
        old_header = headers[column]
        new_header = value.strip() or f"Group {column + 1}"
        headers[column] = new_header
        sheet.dataframe.columns = headers
        for series in sheet.settings.custom_overlay_series:
            values = series.get("values", {}) if isinstance(series, dict) else {}
            if isinstance(values, dict) and old_header in values:
                values[new_header] = values.pop(old_header)
        return
    overlay_count = len(sheet.settings.custom_overlay_series)
    if row <= overlay_count:
        series = sheet.settings.custom_overlay_series[row - 1]
        values = series.setdefault("values", {})
        values[sheet.column_ids[column] if sheet.mode != SHEET_MODE_XY else headers[column]] = value
        return
    dataframe_row = row - 1 - overlay_count
    if 0 <= dataframe_row < len(sheet.dataframe.index):
        if sheet.dataframe.dtypes.iloc[column] != object:
            sheet.dataframe.isetitem(
                column,
                sheet.dataframe.iloc[:, column].astype(object),
            )
        sheet.dataframe.iat[dataframe_row, column] = value


def _insert_rows(sheet: SheetDocument, row: int, count: int) -> None:
    overlay_count = len(sheet.settings.custom_overlay_series)
    dataframe_row = max(0, row - 1 - overlay_count)
    dataframe_row = min(dataframe_row, len(sheet.dataframe.index))
    columns = [str(column) for column in sheet.dataframe.columns]
    sheet.dataframe = pd.concat(
        [
            sheet.dataframe.iloc[:dataframe_row],
            _blank_rows(count, columns),
            sheet.dataframe.iloc[dataframe_row:],
        ],
        ignore_index=True,
    )


def _remove_rows(sheet: SheetDocument, row: int, count: int) -> None:
    overlay_count = len(sheet.settings.custom_overlay_series)
    dataframe_row = max(0, row - 1 - overlay_count)
    before = sheet.dataframe.iloc[:dataframe_row]
    after = sheet.dataframe.iloc[dataframe_row + count :]
    sheet.dataframe = pd.concat([before, after], ignore_index=True)


def _insert_columns(sheet: SheetDocument, column: int, count: int) -> None:
    headers = [str(header) for header in sheet.dataframe.columns]
    rows = sheet.dataframe.astype(object).values.tolist()
    for offset in range(count):
        prefix = "Column" if sheet.mode == SHEET_MODE_XY else "Group"
        headers.insert(column + offset, f"{prefix} {column + offset + 1}")
        sheet.column_ids.insert(column + offset, new_column_id())
        for row in rows:
            row.insert(column + offset, "")
    sheet.dataframe = pd.DataFrame(rows, columns=headers)


def _remove_columns(sheet: SheetDocument, column: int, count: int) -> None:
    headers = [str(header) for header in sheet.dataframe.columns]
    removed = headers[column : column + count]
    removed_column_ids = set(sheet.column_ids[column : column + count])
    kept_indexes = [
        index for index in range(len(headers)) if not column <= index < column + count
    ]
    sheet.dataframe = sheet.dataframe.iloc[:, kept_indexes].copy()
    sheet.column_ids = [
        column_id
        for index, column_id in enumerate(sheet.column_ids)
        if index in kept_indexes
    ]
    remove_xy_column_references(sheet.xy_settings, removed_column_ids)
    normalize_grouping(sheet.grouping, sheet.column_ids)
    for series in sheet.settings.custom_overlay_series:
        values = series.get("values", {}) if isinstance(series, dict) else {}
        if isinstance(values, dict):
            for key in removed_column_ids:
                values.pop(key, None)
            for header in removed:
                if header not in sheet.dataframe.columns:
                    values.pop(header, None)


def _apply_operation(workbook: WorkbookDocument, operation: dict[str, Any]) -> None:
    kind = str(operation.get("type", ""))
    if kind == "active_sheet":
        sheet_id = str(operation["sheet_id"])
        workbook.sheet_by_id(sheet_id)
        workbook.active_sheet_id = sheet_id
        return
    sheet = workbook.sheet_by_id(str(operation["sheet_id"]))
    if kind == "set_cell":
        _apply_cell_operation(sheet, operation)
    elif kind == "settings":
        sheet.settings = chart_settings_from_dict(operation["settings"])
    elif kind == "sheet_state":
        column_ids = operation.get("column_ids")
        if not isinstance(column_ids, list) or any(
            not isinstance(column_id, str) for column_id in column_ids
        ):
            raise ValueError("Recovery column_ids must be a list of strings.")
        if len(column_ids) != len(sheet.dataframe.columns):
            raise ValueError("Recovery column IDs must match the DataFrame column count.")
        sheet.mode = normalized_sheet_mode(operation.get("mode"))
        sheet.column_ids = list(column_ids)
        sheet.xy_settings = xy_settings_from_dict(operation.get("xy"), column_ids)
        sheet.grouping = grouping_from_dict(operation.get("grouping"), column_ids)
    elif kind == "analysis":
        payload = operation.get("analysis", {})
        sheet.analysis_settings = AnalysisSettings(
            visible_statistics=[
                str(value) for value in payload.get("visible_statistics", [])
            ],
            statistic_formats=payload.get("statistic_formats", {}),
        )
    elif kind == "insert_rows":
        _insert_rows(sheet, int(operation["row"]), int(operation["count"]))
    elif kind == "remove_rows":
        _remove_rows(sheet, int(operation["row"]), int(operation["count"]))
    elif kind == "insert_columns":
        _insert_columns(sheet, int(operation["column"]), int(operation["count"]))
    elif kind == "remove_columns":
        _remove_columns(sheet, int(operation["column"]), int(operation["count"]))


def read_recovery_workbook(
    candidate: RecoveryCandidate | Path,
) -> tuple[WorkbookDocument, Path | None]:
    session_dir = (
        candidate.session_dir
        if isinstance(candidate, RecoveryCandidate)
        else Path(candidate)
    )
    manifest = _read_manifest(session_dir)
    if (
        manifest.get("format_version") != RECOVERY_FORMAT_VERSION
        or manifest.get("ready") is not True
    ):
        raise ValueError("Recovery data is incomplete.")
    workbook = read_workbook_project(
        session_dir / str(manifest["checkpoint_file"])
    )
    checkpoint_sequence = int(manifest.get("checkpoint_sequence", 0))
    for operation in _iter_journal_operations(
        _journal_path(session_dir, manifest),
        after_sequence=checkpoint_sequence,
    ):
        _apply_operation(workbook, operation)
    source_text = str(manifest.get("source_project", "")).strip()
    return workbook, Path(source_text) if source_text else None


def _freeze_workbook(workbook: WorkbookDocument) -> WorkbookDocument:
    return WorkbookDocument(
        [
            SheetDocument(
                id=sheet.id,
                name=sheet.name,
                dataframe=sheet.dataframe.copy(deep=True),
                settings=deepcopy(sheet.settings),
                analysis_settings=deepcopy(sheet.analysis_settings),
                mode=sheet.mode,
                column_ids=list(sheet.column_ids),
                xy_settings=deepcopy(sheet.xy_settings),
                grouping=deepcopy(sheet.grouping),
            )
            for sheet in workbook.sheets
        ],
        workbook.active_sheet_id,
    )


class _CheckpointWorker(Thread):
    def __init__(self, session_dir: Path) -> None:
        super().__init__(name="EasyGraphRecoveryCheckpoint", daemon=True)
        self.session_dir = session_dir
        self.requests: Queue[_CheckpointRequest | None] = Queue()
        self.results: Queue[_CheckpointResult] = Queue()

    def run(self) -> None:
        while True:
            request = self.requests.get()
            if request is None:
                return
            error: Exception | None = None
            try:
                write_project(
                    self.session_dir / request.checkpoint_file,
                    request.workbook,
                )
            except Exception as exc:
                error = exc
            self.results.put(_CheckpointResult(request, error))


class _JournalWorker(Thread):
    def __init__(self, manifest_lock: Lock) -> None:
        super().__init__(name="EasyGraphRecoveryJournal", daemon=True)
        self.manifest_lock = manifest_lock
        self.requests: Queue[tuple[str, Any]] = Queue()
        self.last_error: Exception | None = None

    def run(self) -> None:
        while True:
            command, payload = self.requests.get()
            if command == "stop":
                payload.set()
                return
            if command == "barrier":
                payload.set()
                continue
            try:
                if command == "append":
                    self._append(*payload)
                elif command == "compact":
                    self._compact(*payload)
                self.last_error = None
            except Exception as exc:
                self.last_error = exc

    def _append(
        self,
        session_dir: Path,
        document_id: str,
        journal_file: str,
        encoded_lines: bytes,
        makes_dirty: bool,
    ) -> None:
        path = session_dir / journal_file
        with path.open("ab") as stream:
            stream.write(encoded_lines)
            stream.flush()
            os.fsync(stream.fileno())
        with self.manifest_lock:
            manifest = _read_manifest(session_dir)
            if manifest.get("document_id") != document_id:
                return
            if makes_dirty:
                manifest["dirty"] = True
            manifest["updated_at"] = _utc_now()
            _atomic_write_json(session_dir / MANIFEST_FILE, manifest)

    @staticmethod
    def _compact(path: Path, after_sequence: int) -> None:
        encoded = b"".join(
            (
                json.dumps(operation, ensure_ascii=False, separators=(",", ":"))
                + "\n"
            ).encode("utf-8")
            for operation in _iter_journal_operations(
                path, after_sequence=after_sequence
            )
        )
        _atomic_write_bytes(path, encoded)


class RecoveryManager:
    def __init__(
        self,
        *,
        interval_seconds: int,
        root: Path | None = None,
        adopt_session: Path | None = None,
        max_pending_operations: int = DEFAULT_MAX_PENDING_OPERATIONS,
    ) -> None:
        directory = recovery_root_path(root)
        directory.mkdir(parents=True, exist_ok=True)
        self.session_dir = (
            Path(adopt_session)
            if adopt_session is not None
            else directory / f"session-{uuid4().hex}"
        )
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self._lock = QLockFile(str(self.session_dir / LOCK_FILE))
        if not self._lock.tryLock(0):
            raise RuntimeError("Recovery session is already in use.")
        self._manifest_lock = Lock()
        self._checkpoint_worker = _CheckpointWorker(self.session_dir)
        self._journal_worker = _JournalWorker(self._manifest_lock)
        self._checkpoint_worker.start()
        self._journal_worker.start()
        self._flush_timer = QTimer()
        self._flush_timer.setSingleShot(True)
        self._flush_timer.timeout.connect(self.flush_async)
        self._poll_timer = QTimer()
        self._poll_timer.setInterval(100)
        self._poll_timer.timeout.connect(self.poll)
        self._poll_timer.start()
        self._pending: list[tuple[bytes, bool]] = []
        self._sequence = 0
        self._document_id = ""
        self._journal_file = ""
        self._checkpoint_active = False
        self._active_checkpoint_document_id = ""
        self._deferred_checkpoint: tuple[
            WorkbookDocument, Path | None, bool
        ] | None = None
        self._closed = False
        self._dirty = False
        self._ready = False
        self._checkpoint_required = False
        self._deferred_checkpoint = None
        self._max_pending_operations = max(1, int(max_pending_operations))
        self.last_error: Exception | None = None
        self.set_interval(interval_seconds)
        if adopt_session is not None:
            manifest = _read_manifest(self.session_dir)
            self._document_id = str(manifest["document_id"])
            self._journal_file = str(manifest["journal_file"])
            self._dirty = bool(manifest.get("dirty"))
            self._ready = bool(manifest.get("ready"))
            self._sequence = max(
                [int(manifest.get("checkpoint_sequence", 0))]
                + [
                    int(operation.get("sequence", 0))
                    for operation in _iter_journal_operations(
                        self.session_dir / self._journal_file,
                        after_sequence=-1,
                    )
                ]
            )

    @property
    def interval_seconds(self) -> int:
        return max(1, self._flush_timer.interval() // 1000)

    @property
    def dirty(self) -> bool:
        return self._dirty

    @property
    def checkpoint_active(self) -> bool:
        return self._checkpoint_active

    @property
    def checkpoint_required(self) -> bool:
        return self._checkpoint_required

    def set_interval(self, seconds: int) -> None:
        self._flush_timer.setInterval(max(1, int(seconds)) * 1000)
        if self._pending:
            self._flush_timer.start()

    def _base_manifest(
        self,
        *,
        source_project: Path | None,
        dirty: bool,
    ) -> dict[str, Any]:
        return {
            "format_version": RECOVERY_FORMAT_VERSION,
            "document_id": self._document_id,
            "source_project": "" if source_project is None else str(source_project),
            "checkpoint_file": "",
            "checkpoint_sequence": 0,
            "journal_file": self._journal_file,
            "ready": False,
            "dirty": bool(dirty),
            "updated_at": _utc_now(),
        }

    def replace_document(
        self,
        workbook: WorkbookDocument,
        source_project: Path | None,
        *,
        dirty: bool,
    ) -> None:
        self._flush_timer.stop()
        self._pending.clear()
        self._document_id = uuid4().hex
        self._journal_file = f"changes-{self._document_id}.jsonl"
        self._sequence = 0
        self._dirty = bool(dirty)
        self._ready = False
        self._checkpoint_required = False
        _atomic_write_bytes(self.session_dir / self._journal_file, b"")
        with self._manifest_lock:
            _atomic_write_json(
                self.session_dir / MANIFEST_FILE,
                self._base_manifest(
                    source_project=source_project,
                    dirty=dirty,
                ),
            )
        self._start_checkpoint(
            workbook,
            source_project,
            dirty=dirty,
            force=True,
        )

    def _start_checkpoint(
        self,
        workbook: WorkbookDocument,
        source_project: Path | None,
        *,
        dirty: bool,
        force: bool = False,
    ) -> bool:
        frozen = _freeze_workbook(workbook)
        if self._checkpoint_active and not force:
            self._deferred_checkpoint = (frozen, source_project, bool(dirty))
            return False
        request = _CheckpointRequest(
            document_id=self._document_id,
            checkpoint_file=f"checkpoint-{self._document_id}-{uuid4().hex}.eg",
            checkpoint_sequence=self._sequence,
            workbook=frozen,
            source_project="" if source_project is None else str(source_project),
            dirty=bool(dirty),
        )
        self._checkpoint_active = True
        self._active_checkpoint_document_id = self._document_id
        self._checkpoint_worker.requests.put(request)
        return True

    def checkpoint_document(
        self,
        workbook: WorkbookDocument,
        source_project: Path | None,
    ) -> bool:
        self.flush_async()
        return self._start_checkpoint(
            workbook,
            source_project,
            dirty=self._dirty,
        )

    def mark_clean_and_checkpoint(
        self,
        workbook: WorkbookDocument,
        source_project: Path | None,
    ) -> None:
        self._dirty = False
        if (self.session_dir / MANIFEST_FILE).is_file():
            with self._manifest_lock:
                manifest = _read_manifest(self.session_dir)
                if manifest.get("document_id") == self._document_id:
                    manifest["dirty"] = False
                    manifest["source_project"] = (
                        "" if source_project is None else str(source_project)
                    )
                    manifest["updated_at"] = _utc_now()
                    _atomic_write_json(self.session_dir / MANIFEST_FILE, manifest)
        self.checkpoint_document(workbook, source_project)

    def _record(self, operation: dict[str, Any], *, makes_dirty: bool = True) -> None:
        if self._closed:
            return
        self._sequence += 1
        if makes_dirty:
            self._dirty = True
        operation = {
            "version": RECOVERY_FORMAT_VERSION,
            "sequence": self._sequence,
            **operation,
        }
        if self._checkpoint_required:
            return
        encoded = (
            json.dumps(operation, ensure_ascii=False, separators=(",", ":"))
            + "\n"
        ).encode("utf-8")
        self._pending.append((encoded, makes_dirty))
        if len(self._pending) > self._max_pending_operations:
            self._checkpoint_required = True
            self._ready = False
            with self._manifest_lock:
                manifest = _read_manifest(self.session_dir)
                manifest["ready"] = False
                manifest["dirty"] = self._dirty
                manifest["updated_at"] = _utc_now()
                _atomic_write_json(self.session_dir / MANIFEST_FILE, manifest)
            return
        if not self._flush_timer.isActive():
            self._flush_timer.start()

    def require_checkpoint(self) -> None:
        if self._closed or self._checkpoint_required:
            return
        self._checkpoint_required = True
        self._ready = False
        self._dirty = True
        with self._manifest_lock:
            manifest = _read_manifest(self.session_dir)
            if manifest.get("document_id") == self._document_id:
                manifest["ready"] = False
                manifest["dirty"] = True
                manifest["updated_at"] = _utc_now()
                _atomic_write_json(self.session_dir / MANIFEST_FILE, manifest)

    def record_cell(self, sheet_id: str, row: int, column: int, value: str) -> None:
        self._record(
            {
                "type": "set_cell",
                "sheet_id": sheet_id,
                "row": int(row),
                "column": int(column),
                "value": str(value),
            }
        )

    def record_settings(
        self,
        sheet_id: str,
        settings: object,
        *,
        dirty: bool = True,
    ) -> None:
        if not dirty and not self._dirty:
            return
        self._record(
            {
                "type": "settings",
                "sheet_id": sheet_id,
                "settings": asdict(settings),
            },
            makes_dirty=dirty,
        )

    def record_sheet_state(
        self,
        sheet: SheetDocument,
        *,
        dirty: bool = True,
    ) -> None:
        if not dirty and not self._dirty:
            return
        self._record(
            {
                "type": "sheet_state",
                "sheet_id": sheet.id,
                "mode": sheet.mode,
                "column_ids": list(sheet.column_ids),
                "xy": asdict(sheet.xy_settings),
                "grouping": asdict(sheet.grouping),
            },
            makes_dirty=dirty,
        )

    def record_analysis(self, sheet_id: str, settings: object) -> None:
        self._record(
            {
                "type": "analysis",
                "sheet_id": sheet_id,
                "analysis": asdict(settings),
            }
        )

    def record_active_sheet(self, sheet_id: str) -> None:
        if not self._dirty:
            return
        self._record(
            {"type": "active_sheet", "sheet_id": sheet_id},
            makes_dirty=False,
        )

    def record_rows(self, sheet_id: str, row: int, count: int, *, inserted: bool) -> None:
        self._record(
            {
                "type": "insert_rows" if inserted else "remove_rows",
                "sheet_id": sheet_id,
                "row": int(row),
                "count": int(count),
            }
        )

    def record_columns(
        self,
        sheet_id: str,
        column: int,
        count: int,
        *,
        inserted: bool,
    ) -> None:
        self._record(
            {
                "type": "insert_columns" if inserted else "remove_columns",
                "sheet_id": sheet_id,
                "column": int(column),
                "count": int(count),
            }
        )

    def flush_async(self) -> None:
        self._flush_timer.stop()
        if not self._pending or not self._journal_file:
            return
        pending, self._pending = self._pending, []
        self._journal_worker.requests.put(
            (
                "append",
                (
                    self.session_dir,
                    self._document_id,
                    self._journal_file,
                    b"".join(line for line, _dirty in pending),
                    any(dirty for _line, dirty in pending),
                ),
            )
        )

    def flush(self, timeout: float = 10.0) -> bool:
        self.flush_async()
        barrier = Event()
        self._journal_worker.requests.put(("barrier", barrier))
        return barrier.wait(timeout)

    def poll(self) -> None:
        while True:
            try:
                result = self._checkpoint_worker.results.get_nowait()
            except Empty:
                break
            request = result.request
            if request.document_id != self._document_id or self._closed:
                try:
                    (self.session_dir / request.checkpoint_file).unlink()
                except FileNotFoundError:
                    pass
                continue
            self._checkpoint_active = False
            self._active_checkpoint_document_id = ""
            if self._checkpoint_required and self._deferred_checkpoint is not None:
                try:
                    (self.session_dir / request.checkpoint_file).unlink()
                except FileNotFoundError:
                    pass
                self._start_deferred_checkpoint()
                continue
            if result.error is not None:
                self.last_error = result.error
                self._start_deferred_checkpoint()
                continue
            old_checkpoint = ""
            with self._manifest_lock:
                manifest = _read_manifest(self.session_dir)
                if manifest.get("document_id") != request.document_id:
                    continue
                old_checkpoint = str(manifest.get("checkpoint_file", ""))
                manifest.update(
                    {
                        "source_project": request.source_project,
                        "checkpoint_file": request.checkpoint_file,
                        "checkpoint_sequence": request.checkpoint_sequence,
                        "ready": True,
                        "dirty": self._dirty
                        or self._sequence > request.checkpoint_sequence,
                        "updated_at": _utc_now(),
                    }
                )
                _atomic_write_json(self.session_dir / MANIFEST_FILE, manifest)
                self._dirty = bool(manifest["dirty"])
                self._ready = True
                self._checkpoint_required = False
            if old_checkpoint and old_checkpoint != request.checkpoint_file:
                try:
                    (self.session_dir / old_checkpoint).unlink()
                except FileNotFoundError:
                    pass
            self._journal_worker.requests.put(
                (
                    "compact",
                    (
                        self.session_dir / self._journal_file,
                        request.checkpoint_sequence,
                    ),
                )
            )
            self.last_error = None
            self._start_deferred_checkpoint()
        if self._journal_worker.last_error is not None:
            self.last_error = self._journal_worker.last_error

    def _start_deferred_checkpoint(self) -> None:
        if self._deferred_checkpoint is None or self._closed:
            return
        workbook, source_project, dirty = self._deferred_checkpoint
        self._deferred_checkpoint = None
        self._start_checkpoint(
            workbook,
            source_project,
            dirty=dirty,
        )

    def wait_for_checkpoint(self, timeout: float = 30.0) -> bool:
        deadline = time.monotonic() + timeout
        while self._checkpoint_active and time.monotonic() < deadline:
            self.poll()
            time.sleep(0.01)
        self.poll()
        return not self._checkpoint_active and self.last_error is None

    def close(self, *, discard: bool) -> None:
        if self._closed:
            return
        self._closed = True
        self._flush_timer.stop()
        self._poll_timer.stop()
        if discard:
            self._pending.clear()
            if (self.session_dir / MANIFEST_FILE).is_file():
                with self._manifest_lock:
                    manifest = _read_manifest(self.session_dir)
                    manifest["dirty"] = False
                    manifest["ready"] = False
                    _atomic_write_json(self.session_dir / MANIFEST_FILE, manifest)
        else:
            self.flush_async()
        journal_stopped = Event()
        self._journal_worker.requests.put(("stop", journal_stopped))
        journal_stopped.wait(5.0)
        self._checkpoint_worker.requests.put(None)
        checkpoint_stopped = not self._checkpoint_worker.is_alive()
        if not checkpoint_stopped:
            self._checkpoint_worker.join(timeout=0.2)
            checkpoint_stopped = not self._checkpoint_worker.is_alive()
        self._lock.unlock()
        if discard and checkpoint_stopped:
            _discard_session(self.session_dir)


__all__ = [
    "RecoveryCandidate",
    "RecoveryManager",
    "discard_recovery",
    "find_recovery_candidates",
    "read_recovery_workbook",
    "recovery_root_path",
]
