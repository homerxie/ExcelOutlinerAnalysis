from __future__ import annotations

import math
from collections.abc import Mapping


MAX_ADDITIONAL_GUIDES = 30
ADDITIONAL_GUIDE_TEXT_SIDES = (
    "left",
    "center",
    "right",
    "plot_left",
    "plot_right",
)
ADDITIONAL_GUIDE_VERTICAL_POSITIONS = (
    "aligned",
    "above",
    "below",
    "plot_bottom",
    "plot_top",
)
ADDITIONAL_GUIDE_TEXT_COLOR_MODES = ("auto", "match_line")


__all__ = [
    "MAX_ADDITIONAL_GUIDES",
    "ADDITIONAL_GUIDE_TEXT_SIDES",
    "ADDITIONAL_GUIDE_VERTICAL_POSITIONS",
    "ADDITIONAL_GUIDE_TEXT_COLOR_MODES",
    "default_additional_guide",
    "normalize_additional_guide",
    "normalize_additional_guides",
    "limit_additional_guide_text",
    "format_additional_guide_value",
]


def _finite_float(value: object, default: float = 0.0) -> float:
    try:
        numeric = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return numeric if math.isfinite(numeric) else float(default)


def _boolean(value: object, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, str):
        normalized = value.strip().casefold()
        if normalized in {"true", "yes", "on", "1"}:
            return True
        if normalized in {"false", "no", "off", "0", ""}:
            return False
        return default
    if isinstance(value, (int, float)):
        return bool(value) if math.isfinite(float(value)) else default
    return default


def _color_index(value: object, default: int = 0) -> int:
    try:
        index = int(value)
    except (TypeError, ValueError, OverflowError):
        return int(default)
    return min(MAX_ADDITIONAL_GUIDES * 2 - 1, max(0, index))


def limit_additional_guide_text(text: object) -> str:
    """Return plain text containing at most its first two logical lines."""

    if text is None:
        return ""
    normalized = str(text).replace("\r\n", "\n").replace("\r", "\n")
    return "\n".join(normalized.split("\n")[:2])


def default_additional_guide(value: object = 0.0) -> dict[str, object]:
    return {
        "value": _finite_float(value),
        "color_index": 0,
        "text_color_mode": "auto",
        "show_tick": True,
        "show_value_with_text": False,
        "show_line": False,
        "text": "",
        "show_label_background": False,
        "text_side": "left",
        "vertical_position": "aligned",
    }


def normalize_additional_guide(raw: object) -> dict[str, object]:
    source = raw if isinstance(raw, Mapping) else {}
    guide = default_additional_guide(source.get("value", 0.0))
    guide["color_index"] = _color_index(source.get("color_index"), 0)
    text_color_mode = str(
        source.get("text_color_mode", "auto")
    ).strip().casefold()
    guide["text_color_mode"] = (
        text_color_mode
        if text_color_mode in ADDITIONAL_GUIDE_TEXT_COLOR_MODES
        else "auto"
    )
    guide["show_tick"] = _boolean(source.get("show_tick"), True)
    guide["show_value_with_text"] = _boolean(
        source.get("show_value_with_text"),
        False,
    )
    guide["show_line"] = _boolean(source.get("show_line"), False)
    guide["text"] = limit_additional_guide_text(source.get("text", ""))
    guide["show_label_background"] = _boolean(
        source.get("show_label_background"),
        False,
    )

    text_side = str(source.get("text_side", "left")).strip().casefold()
    guide["text_side"] = (
        text_side if text_side in ADDITIONAL_GUIDE_TEXT_SIDES else "left"
    )
    vertical_position = (
        str(source.get("vertical_position", "aligned")).strip().casefold()
    )
    guide["vertical_position"] = (
        vertical_position
        if vertical_position in ADDITIONAL_GUIDE_VERTICAL_POSITIONS
        else "aligned"
    )
    return guide


def normalize_additional_guides(values: object) -> list[dict[str, object]]:
    if not isinstance(values, (list, tuple)):
        return []
    return [
        normalize_additional_guide(value)
        for value in values[:MAX_ADDITIONAL_GUIDES]
    ]


def format_additional_guide_value(value: object) -> str:
    numeric = _finite_float(value)
    if numeric == 0.0:
        return "0"
    return format(numeric, ".12g")
