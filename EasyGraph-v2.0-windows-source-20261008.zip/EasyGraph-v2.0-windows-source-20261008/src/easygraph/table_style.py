from __future__ import annotations

from PySide6.QtGui import QBrush, QPalette

from easygraph.data_table import DataTable


def header_row_height(table: DataTable, padding: int = 14) -> int:
    max_lines = max(
        (
            table.table_model.cell_text(0, column).count("\n") + 1
            for column in range(table.table_model.columnCount())
        ),
        default=1,
    )
    return table.fontMetrics().lineSpacing() * max_lines + padding


def row_header_min_width(overlay_row_count: int) -> int:
    return 86 if overlay_row_count else 34


def apply_table_row_styles(table: DataTable, sample_start_row: int, blend_colors) -> None:
    if table.table_model.rowCount() == 0:
        table.table_model.resize(1, table.table_model.columnCount())
    was_blocked = table.signalsBlocked()
    table.blockSignals(True)
    try:
        for column in range(table.table_model.columnCount()):
            if not table.table_model.cell_text(0, column).strip():
                table.table_model.set_cell_text(0, column, f"Group {column + 1}")
    finally:
        table.blockSignals(was_blocked)
    # A stylesheet-backed palette is resolved lazily.  The table is styled
    # before the main window is shown, so polish it before caching theme colors.
    table.ensurePolished()
    palette = table.palette()
    base_color = palette.color(QPalette.ColorRole.Base)
    highlight_color = palette.color(QPalette.ColorRole.Highlight)
    text_color = palette.color(QPalette.ColorRole.Text)
    table.table_model.configure_style(
        sample_start_row,
        QBrush(blend_colors(base_color, highlight_color, 0.18)),
        QBrush(text_color),
        QBrush(blend_colors(base_color, highlight_color, 0.12)),
        QBrush(text_color),
    )
