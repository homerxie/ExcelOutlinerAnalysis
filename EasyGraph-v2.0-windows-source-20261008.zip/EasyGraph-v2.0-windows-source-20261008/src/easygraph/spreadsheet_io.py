from __future__ import annotations

import math
import csv
import json
from copy import deepcopy
from dataclasses import asdict, dataclass, field
from pathlib import Path

import pandas as pd

from easygraph.data import attach_group_metadata, group_keys
from easygraph.grouping import GroupingSettings, grouping_from_dict, normalize_grouping
from easygraph.workbook import SHEET_MODE_GROUPS, unique_sheet_name


OVERLAY_EXPORT_ROW_TYPE_COLUMN = "__easygraph_row_type"
OVERLAY_EXPORT_NAME_COLUMN = "__easygraph_overlay_name"
OVERLAY_EXPORT_SAMPLE_ROW = "sample"
OVERLAY_EXPORT_CUSTOM_ROW = "overlay"
_GROUPING_COMMENT_PREFIX = "EasyGraph column metadata v1\n"


@dataclass
class SpreadsheetSheet:
    name: str
    dataframe: pd.DataFrame
    overlay_series: list[dict] = field(default_factory=list)
    mode: str = SHEET_MODE_GROUPS
    grouping: GroupingSettings = field(default_factory=GroupingSettings)
    column_ids: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.column_ids:
            self.column_ids = list(self.dataframe.attrs.get("group_column_ids", []))
        if not self.grouping.parents and "grouping" in self.dataframe.attrs:
            self.grouping = grouping_from_dict(self.dataframe.attrs["grouping"], self.column_ids)
        if self.column_ids:
            self.dataframe = attach_group_metadata(self.dataframe, self.column_ids)
            self.grouping = normalize_grouping(deepcopy(self.grouping), self.column_ids)
            self.dataframe.attrs["grouping"] = asdict(self.grouping)
        elif self.grouping.parents:
            raise ValueError("Grouped spreadsheet sheets require column IDs.")


def excel_export_dataframe(df: pd.DataFrame, overlay_series: list[dict] | None = None) -> pd.DataFrame:
    overlay_series = list(overlay_series or [])
    if not overlay_series:
        return df.copy()

    group_columns = list(df.columns)
    keys = group_keys(df)
    overlay_rows = []
    for series in overlay_series:
        values = series.get("values", {}) if isinstance(series, dict) else {}
        overlay_rows.append(
            [
                "" if pd.isna(value := values.get(key, values.get(str(column), ""))) else value
                for key, column in zip(keys, group_columns)
            ]
        )
    overlay_metadata = pd.DataFrame(
        {
            OVERLAY_EXPORT_ROW_TYPE_COLUMN: [OVERLAY_EXPORT_CUSTOM_ROW] * len(overlay_series),
            OVERLAY_EXPORT_NAME_COLUMN: [
                str(series.get("name", "")) if isinstance(series, dict) else ""
                for series in overlay_series
            ],
        }
    )
    overlay_frame = pd.concat(
        [overlay_metadata, pd.DataFrame(overlay_rows, columns=group_columns)],
        axis=1,
    )

    sample_metadata = pd.DataFrame(
        {
            OVERLAY_EXPORT_ROW_TYPE_COLUMN: [OVERLAY_EXPORT_SAMPLE_ROW] * len(df),
            OVERLAY_EXPORT_NAME_COLUMN: [""] * len(df),
        }
    )
    sample_frame = pd.concat(
        [sample_metadata, df.reset_index(drop=True)],
        axis=1,
    )
    exported = pd.concat([overlay_frame, sample_frame], ignore_index=True)
    exported.attrs["group_value_keys"] = keys
    return exported


def excel_import_parts(df: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    columns = list(df.columns)
    if OVERLAY_EXPORT_ROW_TYPE_COLUMN not in columns or OVERLAY_EXPORT_NAME_COLUMN not in columns:
        return df, []

    row_type_index = columns.index(OVERLAY_EXPORT_ROW_TYPE_COLUMN)
    name_index = columns.index(OVERLAY_EXPORT_NAME_COLUMN)
    group_indexes = [
        index
        for index, column in enumerate(columns)
        if index not in {row_type_index, name_index}
    ]
    group_columns = [columns[index] for index in group_indexes]
    row_types = (
        df.iloc[:, row_type_index]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.casefold()
    )
    sample_mask = row_types.isin({"", OVERLAY_EXPORT_SAMPLE_ROW})
    if sample_mask.any():
        samples = (
            df.iloc[sample_mask.to_numpy(), group_indexes]
            .reset_index(drop=True)
            .infer_objects()
        )
        samples.columns = group_columns
    else:
        samples = pd.DataFrame(columns=group_columns)

    keys = df.attrs.get("group_value_keys", group_keys(samples))
    overlay_series = []
    overlay_mask = row_types.eq(OVERLAY_EXPORT_CUSTOM_ROW)
    overlay_rows = df.iloc[overlay_mask.to_numpy(), :]
    for row in overlay_rows.itertuples(index=False, name=None):
        name_value = row[name_index]
        name = "" if pd.isna(name_value) else str(name_value)
        values = {}
        for group, index in zip(keys, group_indexes):
            value = row[index]
            values[str(group)] = "" if pd.isna(value) else str(value)
        overlay_series.append({"name": name, "values": values})

    return samples, overlay_series


def _excel_cell_value(value):
    if not isinstance(value, str):
        return value
    if not value.strip():
        return ""
    try:
        numeric = pd.to_numeric(value.strip(), errors="raise")
    except (TypeError, ValueError):
        return value
    if not math.isfinite(float(numeric)):
        return value
    return numeric.item() if hasattr(numeric, "item") else numeric


def _excel_write_dataframe(
    df: pd.DataFrame,
    overlay_series: list[dict] | None = None,
) -> pd.DataFrame:
    overlay_series = list(overlay_series or [])
    exported = excel_export_dataframe(df, overlay_series)
    first_data_column = 2 if overlay_series else 0
    for column_index in range(first_data_column, exported.shape[1]):
        converted = exported.iloc[:, column_index].astype(object).map(_excel_cell_value)
        exported.isetitem(column_index, converted)
    return exported


def _read_xlsx_book(path: Path) -> list[SpreadsheetSheet]:
    from openpyxl import load_workbook

    sheets = []
    workbook = load_workbook(path, data_only=True)
    try:
        for worksheet in workbook.worksheets:
            metadata = None
            comment = worksheet.cell(1, 1).comment
            if comment and comment.text.startswith(_GROUPING_COMMENT_PREFIX):
                metadata = json.loads(comment.text[len(_GROUPING_COMMENT_PREFIX):])
                if not isinstance(metadata, dict):
                    raise ValueError("Excel grouping metadata must be a dictionary.")
            merged_headers = [area for area in worksheet.merged_cells.ranges if area.min_row == area.max_row == 1 and area.max_col > area.min_col]
            has_leaf_titles = all(
                isinstance(value := worksheet.cell(2, column).value, (str, int, float))
                and bool(str(value).strip())
                for column in range(1, worksheet.max_column + 1)
            )
            two_levels = bool(metadata and metadata.get("header_rows") == 2) or bool(merged_headers and has_leaf_titles)
            header_row = 2 if two_levels else 1
            raw = pd.read_excel(path, sheet_name=worksheet.title, header=header_row - 1)
            raw.columns = ["" if (value := worksheet.cell(header_row, column + 1).value) is None else str(value) for column in range(raw.shape[1])]
            has_overlay = OVERLAY_EXPORT_ROW_TYPE_COLUMN in raw.columns and OVERLAY_EXPORT_NAME_COLUMN in raw.columns
            offset = 2 if has_overlay else 0
            count = raw.shape[1] - offset
            ids = []
            if metadata:
                ids = metadata.get("column_ids", [])
            if not isinstance(ids, list) or len(ids) != count or not all(isinstance(key, str) and key for key in ids) or len(set(ids)) != len(ids):
                duplicate_labels = len(set(raw.columns[offset:])) != count
                ids = [f"excel-column-{index + 1}" for index in range(count)] if two_levels or metadata or duplicate_labels else []
            if ids:
                raw.attrs["group_value_keys"] = ids
            dataframe, overlays = excel_import_parts(raw)
            grouping = GroupingSettings()
            if two_levels:
                parents = []
                used_columns = set()
                for area in merged_headers:
                    start, end = max(area.min_col - 1 - offset, 0), min(area.max_col - offset, count)
                    if start >= end:
                        continue
                    used_columns.update(range(start, end))
                    parents.append({"id": f"excel-parent-{start + 1}", "name": str(worksheet.cell(1, area.min_col).value or "Group"), "column_ids": ids[start:end]})
                for index in range(count):
                    value = worksheet.cell(1, index + offset + 1).value
                    if index not in used_columns and value is not None:
                        parents.append({"id": f"excel-parent-{index + 1}", "name": str(value), "column_ids": [ids[index]]})
                grouping = normalize_grouping(GroupingSettings(parents), ids)
                if metadata and "grouping" in metadata:
                    saved = grouping_from_dict(metadata["grouping"], ids)
                    # Visible merges and titles remain authoritative after Excel edits.
                    by_members = {tuple(parent["column_ids"]): parent for parent in saved.parents}
                    for parent in grouping.parents:
                        original = by_members.get(tuple(parent["column_ids"]))
                        if original:
                            parent["id"] = original["id"]
                    grouping.shared_subgroups = saved.shared_subgroups
                    grouping.subgroup_ids = saved.subgroup_ids
                    normalize_grouping(grouping, ids)
            if ids:
                dataframe = attach_group_metadata(dataframe, ids)
                dataframe.attrs["grouping"] = asdict(grouping)
            sheets.append(SpreadsheetSheet(worksheet.title, dataframe, overlays, grouping=grouping, column_ids=ids))
    finally:
        workbook.close()
    return sheets


def read_spreadsheet(path: Path) -> tuple[pd.DataFrame, list[dict]]:
    input_path = Path(path)
    if input_path.suffix.casefold() in {".xlsx", ".xlsm"}:
        first = _read_xlsx_book(input_path)[0]
        return first.dataframe, first.overlay_series
    if input_path.suffix.casefold() == ".csv":
        raw_df = pd.read_csv(input_path)
        with input_path.open(encoding="utf-8-sig", newline="") as stream:
            raw_df.columns = next(csv.reader(stream))
    else:
        raw_df = pd.read_excel(input_path)
    dataframe, overlays = excel_import_parts(raw_df)
    if len(set(map(str, dataframe.columns))) != len(dataframe.columns):
        old_keys = group_keys(dataframe)
        ids = [f"import-column-{index + 1}" for index in range(len(old_keys))]
        for series in overlays:
            series["values"] = {column_id: series["values"].get(key, "") for column_id, key in zip(ids, old_keys)}
        dataframe = attach_group_metadata(dataframe, ids)
    return dataframe, overlays


def read_spreadsheet_book(path: Path) -> list[SpreadsheetSheet]:
    input_path = Path(path)
    if input_path.suffix.casefold() == ".csv":
        dataframe, overlay_series = read_spreadsheet(input_path)
        return [SpreadsheetSheet(input_path.stem or "Sheet 1", dataframe, overlay_series)]
    if input_path.suffix.casefold() in {".xlsx", ".xlsm"}:
        return _read_xlsx_book(input_path)
    sheets = []
    with pd.ExcelFile(input_path) as workbook:
        for name in workbook.sheet_names:
            dataframe, overlay_series = excel_import_parts(pd.read_excel(workbook, sheet_name=name))
            sheets.append(SpreadsheetSheet(str(name), dataframe, overlay_series))
    return sheets


def _write_excel_sheet(writer, sheet: SpreadsheetSheet, name: str) -> None:
    from openpyxl.comments import Comment
    from openpyxl.styles import Alignment, Font

    ids = list(sheet.column_ids or sheet.dataframe.attrs.get("group_column_ids", []))
    if sheet.grouping.parents and not ids:
        raise ValueError("Grouped Excel export requires column IDs.")
    grouping = normalize_grouping(deepcopy(sheet.grouping), ids)
    frame = attach_group_metadata(sheet.dataframe, ids) if ids else sheet.dataframe
    two_levels = bool(grouping.parents)
    _excel_write_dataframe(frame, sheet.overlay_series).to_excel(writer, sheet_name=name, index=False, startrow=int(two_levels))
    worksheet = writer.sheets[name]
    for row in worksheet:
        for cell in row:
            if cell.value == "":
                cell.value = None
                cell.data_type = "n"
    if two_levels:
        offset = 2 if sheet.overlay_series else 0
        for parent in grouping.parents:
            positions = [ids.index(column_id) + 1 + offset for column_id in parent["column_ids"]]
            if positions != list(range(min(positions), max(positions) + 1)):
                raise ValueError("Excel parent groups must contain consecutive columns.")
            start, end = min(positions), max(positions)
            worksheet.cell(1, start, parent["name"])
            if start != end:
                worksheet.merge_cells(start_row=1, start_column=start, end_row=1, end_column=end)
            worksheet.cell(1, start).alignment = Alignment(horizontal="center", vertical="center")
            worksheet.cell(1, start).font = Font(bold=True)
        worksheet.freeze_panes = "A3"
    if ids:
        payload = {"header_rows": 2 if two_levels else 1, "column_ids": ids, "grouping": asdict(grouping)}
        worksheet.cell(1, 1).comment = Comment(_GROUPING_COMMENT_PREFIX + json.dumps(payload, ensure_ascii=False), "EasyGraph")


def write_spreadsheet(
    path: Path,
    df: pd.DataFrame,
    overlay_series: list[dict] | None = None,
    *,
    grouping: GroupingSettings | None = None,
    column_ids: list[str] | None = None,
) -> Path:
    output_path = Path(path)
    if output_path.suffix.casefold() == ".csv":
        excel_export_dataframe(df, overlay_series).to_csv(output_path, index=False)
        return output_path
    return write_spreadsheet_book(output_path, [SpreadsheetSheet("Sheet1", df, list(overlay_series or []), grouping=grouping or GroupingSettings(), column_ids=list(column_ids or []))])


def write_spreadsheet_book(path: Path, sheets: list[SpreadsheetSheet]) -> Path:
    if not sheets:
        raise ValueError("At least one sheet is required for Excel export.")
    output_path = Path(path)
    if output_path.suffix.casefold() != ".xlsx":
        output_path = Path(f"{output_path}.xlsx")
    exported_names = []
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for sheet in sheets:
            export_name = unique_sheet_name(exported_names, sheet.name)
            exported_names.append(export_name)
            _write_excel_sheet(writer, sheet, export_name)
    return output_path


__all__ = [
    "OVERLAY_EXPORT_CUSTOM_ROW",
    "OVERLAY_EXPORT_NAME_COLUMN",
    "OVERLAY_EXPORT_ROW_TYPE_COLUMN",
    "OVERLAY_EXPORT_SAMPLE_ROW",
    "SpreadsheetSheet",
    "excel_export_dataframe",
    "excel_import_parts",
    "read_spreadsheet",
    "read_spreadsheet_book",
    "write_spreadsheet",
    "write_spreadsheet_book",
]
