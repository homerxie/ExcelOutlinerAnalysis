from __future__ import annotations

import pandas as pd


DEFAULT_XY_TABLE_ROWS = 10


def _value_is_blank(value: object) -> bool:
    return pd.isna(value) or not str(value).strip()


def dataframe_with_trailing_blank_row(
    dataframe: pd.DataFrame,
    *,
    minimum_rows: int = DEFAULT_XY_TABLE_ROWS,
    preserve_existing: bool = True,
) -> pd.DataFrame:
    """Keep existing rows and append one blank row after the last value."""
    minimum_rows = max(1, int(minimum_rows))
    last_used_row = -1
    for row_index, row in enumerate(dataframe.itertuples(index=False, name=None)):
        if any(not _value_is_blank(value) for value in row):
            last_used_row = row_index
    row_count = max(
        minimum_rows,
        len(dataframe) if preserve_existing else 0,
        last_used_row + 2,
    )
    return dataframe.reset_index(drop=True).reindex(range(row_count), fill_value="")


def _positions_by_id(
    dataframe: pd.DataFrame,
    column_ids: list[str] | tuple[str, ...],
) -> dict[str, int]:
    if len(column_ids) != len(dataframe.columns):
        raise ValueError("Column IDs must match the DataFrame column count.")
    if len(set(column_ids)) != len(column_ids):
        raise ValueError("Column IDs must be unique.")
    return {column_id: index for index, column_id in enumerate(column_ids)}


def dataframe_column_subset(
    dataframe: pd.DataFrame,
    column_ids: list[str] | tuple[str, ...],
    selected_column_ids: list[str] | tuple[str, ...],
) -> pd.DataFrame:
    positions = _positions_by_id(dataframe, column_ids)
    missing = [column_id for column_id in selected_column_ids if column_id not in positions]
    if missing:
        raise ValueError(f"Unknown column ID: {missing[0]}")
    return dataframe.iloc[
        :,
        [positions[column_id] for column_id in selected_column_ids],
    ].copy(deep=True)


def replace_dataframe_columns(
    dataframe: pd.DataFrame,
    column_ids: list[str] | tuple[str, ...],
    replacement: pd.DataFrame,
    replacement_column_ids: list[str] | tuple[str, ...],
) -> pd.DataFrame:
    positions = _positions_by_id(dataframe, column_ids)
    if len(replacement_column_ids) != len(replacement.columns):
        raise ValueError("Replacement column IDs must match the replacement column count.")
    missing = [column_id for column_id in replacement_column_ids if column_id not in positions]
    if missing:
        raise ValueError(f"Unknown replacement column ID: {missing[0]}")

    row_count = max(len(dataframe), len(replacement))
    result = dataframe.reset_index(drop=True).reindex(range(row_count), fill_value="")
    replacement = replacement.reset_index(drop=True).reindex(range(row_count), fill_value="")
    for replacement_index, column_id in enumerate(replacement_column_ids):
        target_index = positions[column_id]
        result.isetitem(target_index, replacement.iloc[:, replacement_index])
        columns = list(result.columns)
        columns[target_index] = replacement.columns[replacement_index]
        result.columns = columns
    return result


__all__ = [
    "DEFAULT_XY_TABLE_ROWS",
    "dataframe_column_subset",
    "dataframe_with_trailing_blank_row",
    "replace_dataframe_columns",
]
