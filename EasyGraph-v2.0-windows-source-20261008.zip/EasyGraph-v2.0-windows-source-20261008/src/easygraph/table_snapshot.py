from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from typing import Any

from easygraph.data_table import DataTable
from easygraph.grouping import grouping_from_dict
from easygraph.project_io import xy_settings_from_dict
from easygraph.settings import ChartSettings
from easygraph.workbook import SheetDocument, normalized_sheet_mode


Snapshot = dict[str, Any]


def build_settings_snapshot(settings: ChartSettings) -> Snapshot:
    return {
        "custom_overlay_series": deepcopy(settings.custom_overlay_series),
        "custom_overlay_count": settings.custom_overlay_count,
        "extra_custom_overlay": settings.extra_custom_overlay,
        "custom_overlay_hidden": list(settings.custom_overlay_hidden),
        "custom_overlay_styles": dict(settings.custom_overlay_styles),
        "manual_group_order": list(settings.manual_group_order),
        "group_hidden": list(settings.group_hidden),
        "custom_colors": dict(settings.custom_colors),
        "group_inner_spacing": getattr(settings, "group_inner_spacing", 1.0),
        "group_outer_spacing": getattr(settings, "group_outer_spacing", 2.7),
        "group_label_mode": getattr(settings, "group_label_mode", "Both levels"),
        "group_color_mode": getattr(settings, "group_color_mode", "Subgroup"),
        "show_legend": settings.show_legend,
    }


def build_sheet_state_snapshot(sheet: SheetDocument) -> Snapshot:
    return {
        "sheet_mode": sheet.mode,
        "column_ids": list(sheet.column_ids),
        "xy_settings": deepcopy(asdict(sheet.xy_settings)),
        "grouping": deepcopy(asdict(sheet.grouping)),
    }


def apply_sheet_state_snapshot(snapshot: Snapshot, sheet: SheetDocument) -> None:
    mode = normalized_sheet_mode(snapshot.get("sheet_mode", sheet.mode))
    column_ids = snapshot.get("column_ids", sheet.column_ids)
    if not isinstance(column_ids, list) or any(
        not isinstance(column_id, str) for column_id in column_ids
    ):
        raise ValueError("Snapshot column_ids must be a list of strings.")
    if len(column_ids) != len(sheet.dataframe.columns):
        raise ValueError("Snapshot column IDs must match the DataFrame column count.")
    sheet.mode = mode
    sheet.column_ids = list(column_ids)
    sheet.grouping = grouping_from_dict(
        deepcopy(snapshot.get("grouping", asdict(sheet.grouping))), sheet.column_ids,
    )
    sheet.xy_settings = xy_settings_from_dict(
        deepcopy(snapshot.get("xy_settings", asdict(sheet.xy_settings))),
        sheet.column_ids,
    )


def build_table_snapshot(
    table: DataTable,
    settings: ChartSettings,
    custom_overlay_rows: int,
    sheet: SheetDocument | None = None,
) -> Snapshot:
    snapshot = {
        "cells": table.table_model.cells_copy(),
        "current_row": table.currentIndex().row(),
        "current_col": table.currentIndex().column(),
        "custom_overlay_rows": custom_overlay_rows,
        **build_settings_snapshot(settings),
    }
    if sheet is not None:
        snapshot.update(build_sheet_state_snapshot(sheet))
    return snapshot


def snapshot_cells(snapshot: Snapshot) -> list[list[str]]:
    cells = snapshot.get("cells", [])
    return cells if isinstance(cells, list) else []


def snapshot_shape(snapshot: Snapshot) -> tuple[int, int]:
    cells = snapshot_cells(snapshot)
    row_count = len(cells)
    col_count = max((len(row) for row in cells if isinstance(row, list)), default=0)
    return row_count, col_count


def snapshot_cell_text(snapshot: Snapshot, row: int, col: int) -> str:
    cells = snapshot_cells(snapshot)
    if row < 0 or col < 0 or row >= len(cells):
        return ""
    row_values = cells[row]
    if not isinstance(row_values, list) or col >= len(row_values):
        return ""
    return str(row_values[col])


def snapshot_current_cell(snapshot: Snapshot, row_count: int, col_count: int) -> tuple[int, int]:
    row = min(max(int(snapshot.get("current_row", 0)), 0), max(row_count - 1, 0))
    col = min(max(int(snapshot.get("current_col", 0)), 0), max(col_count - 1, 0))
    return row, col


def apply_snapshot_settings(snapshot: Snapshot, settings: ChartSettings) -> None:
    settings.custom_overlay_series = deepcopy(snapshot.get("custom_overlay_series", []))
    settings.custom_overlay_count = int(snapshot.get("custom_overlay_count", max(1, len(settings.custom_overlay_series))))
    settings.extra_custom_overlay = bool(snapshot.get("extra_custom_overlay", bool(settings.custom_overlay_series)))
    settings.custom_overlay_hidden = list(snapshot.get("custom_overlay_hidden", []))
    settings.custom_overlay_styles = dict(snapshot.get("custom_overlay_styles", {}))
    settings.manual_group_order = list(snapshot.get("manual_group_order", []))
    settings.group_hidden = list(snapshot.get("group_hidden", []))

    settings.custom_colors = dict(snapshot.get("custom_colors", settings.custom_colors))
    for name in ("group_inner_spacing", "group_outer_spacing", "group_label_mode", "group_color_mode", "show_legend"):
        if name in snapshot:
            setattr(settings, name, snapshot[name])
