from __future__ import annotations

import csv
from io import StringIO

from easygraph.data_table import DataTable


def selected_range_to_tsv(table: DataTable) -> str:
    ranges = table.selectionModel().selection()
    if not ranges:
        return ""
    selected = ranges[0]
    rows = [
        [
            table.table_model.cell_text(row, col)
            for col in range(selected.left(), selected.right() + 1)
        ]
        for row in range(selected.top(), selected.bottom() + 1)
    ]
    buffer = StringIO()
    writer = csv.writer(buffer, delimiter="\t", lineterminator="\n")
    writer.writerows(rows)
    return buffer.getvalue().rstrip("\n")


def clear_selected_table_items(table: DataTable) -> bool:
    selected = table.selectionModel().selectedIndexes()
    if not selected:
        return False
    was_blocked = table.signalsBlocked()
    table.blockSignals(True)
    try:
        for index in selected:
            table.table_model.set_cell_text(index.row(), index.column(), "")
    finally:
        table.blockSignals(was_blocked)
    return True


def cut_selection_to_tsv(table: DataTable) -> str:
    text = selected_range_to_tsv(table)
    if text:
        clear_selected_table_items(table)
    return text


def tsv_to_rows(text: str) -> list[list[str]]:
    return list(csv.reader(StringIO(text), delimiter="\t"))


def paste_start_cell(current_row: int, current_col: int) -> tuple[int, int]:
    return max(current_row, 0), max(current_col, 0)


def paste_rows_into_table(table: DataTable, rows: list[list[str]], start_row: int, start_col: int) -> None:
    if not rows:
        return
    start_row = max(start_row, 0)
    start_col = max(start_col, 0)
    needed_rows = start_row + len(rows)
    needed_cols = start_col + max(len(row) for row in rows)
    table.table_model.resize(
        max(table.table_model.rowCount(), needed_rows),
        max(table.table_model.columnCount(), needed_cols),
    )
    for col in range(table.table_model.columnCount()):
        if not table.table_model.cell_text(0, col).strip():
            table.table_model.set_cell_text(0, col, f"Group {col + 1}")

    was_blocked = table.signalsBlocked()
    table.blockSignals(True)
    try:
        for row_offset, row_values in enumerate(rows):
            for col_offset, value in enumerate(row_values):
                table.table_model.set_cell_text(
                    start_row + row_offset,
                    start_col + col_offset,
                    value,
                )
    finally:
        table.blockSignals(was_blocked)


def paste_tsv_into_table(table: DataTable, text: str) -> bool:
    if not text:
        return False
    rows = tsv_to_rows(text)
    if not rows:
        return False
    current = table.currentIndex()
    start_row, start_col = paste_start_cell(current.row(), current.column())
    paste_rows_into_table(table, rows, start_row, start_col)
    return True
