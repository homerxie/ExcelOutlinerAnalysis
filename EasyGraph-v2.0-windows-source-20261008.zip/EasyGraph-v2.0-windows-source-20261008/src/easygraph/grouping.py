"""Two-level Groups metadata, independent of column labels and table values."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from uuid import uuid4


@dataclass
class GroupingSettings:
    parents: list[dict] = field(default_factory=list)
    shared_subgroups: bool = False
    subgroup_ids: dict[str, str] = field(default_factory=dict)


def ordered_group_blocks(
    order: list[str],
    parents: list[dict],
    outer_order: list[str] | None = None,
) -> list[tuple[str | None, list[str]]]:
    """Keep parent groups together while preserving each member's given order.

    ``order`` defines the available columns and their order within a parent.
    Ungrouped columns form individual blocks. By default, blocks follow their
    first appearance in ``order``; ``outer_order`` can supply a different block
    order, such as the physical table order. A hidden sibling in that reference
    order can still anchor its parent, without adding the hidden column back.

    Repeated columns, empty parents, and references to missing columns do not
    create duplicate or empty blocks. If parents overlap, the first claim wins.
    Neither the order lists nor the parent metadata are modified.
    """
    columns = list(dict.fromkeys(order))
    parent_ids: dict[str, str] = {}
    for parent in parents:
        parent_id = parent.get("id")
        if not isinstance(parent_id, str) or not parent_id:
            continue
        for column in parent.get("column_ids", []):
            parent_ids.setdefault(column, parent_id)

    def block_key(column: str) -> tuple[str | None, str | None]:
        parent_id = parent_ids.get(column)
        return (parent_id, None) if parent_id is not None else (None, column)

    members_by_block: dict[tuple[str | None, str | None], list[str]] = {}
    for column in columns:
        members_by_block.setdefault(block_key(column), []).append(column)

    ordered_blocks = []
    seen = set()
    for column in columns if outer_order is None else outer_order:
        key = block_key(column)
        if key in members_by_block and key not in seen:
            ordered_blocks.append((key[0], members_by_block[key]))
            seen.add(key)
    ordered_blocks.extend(
        (key[0], members) for key, members in members_by_block.items()
        if key not in seen
    )
    return ordered_blocks


def normalize_grouping(
    grouping: GroupingSettings, column_ids: list[str],
) -> GroupingSettings:
    """Normalize in place after structural edits, dropping deleted references.

    Each physical column belongs to at most one parent. Parent members and
    parents follow their first physical column, irrespective of label reuse.
    """
    positions = {column_id: index for index, column_id in enumerate(column_ids)}
    claimed: set[str] = set()
    parents = []
    parent_ids: set[str] = set()
    for parent in grouping.parents:
        members = sorted(
            {column_id for column_id in parent.get("column_ids", [])
             if column_id in positions and column_id not in claimed},
            key=positions.__getitem__,
        )
        if not members:
            continue
        parent_id = str(parent.get("id", ""))
        if not parent_id or parent_id in parent_ids:
            parent_id = uuid4().hex
        parent_ids.add(parent_id)
        parents.append({"id": parent_id, "name": str(parent.get("name", "Group")), "column_ids": members})
        claimed.update(members)
    grouping.parents = sorted(parents, key=lambda parent: positions[parent["column_ids"][0]])
    grouping.subgroup_ids = {
        column_id: category_id
        for column_id, category_id in grouping.subgroup_ids.items()
        if column_id in claimed and isinstance(category_id, str) and category_id
    }
    return grouping


def grouping_from_dict(data: object, column_ids: list[str]) -> GroupingSettings:
    """Read project/snapshot metadata and discard references to removed columns."""
    if data is None:
        return GroupingSettings()
    if not isinstance(data, dict):
        raise ValueError("Grouping settings must be a dictionary.")
    unknown = set(data) - {"parents", "shared_subgroups", "subgroup_ids"}
    if unknown:
        raise ValueError("Unknown grouping settings fields: " + ", ".join(sorted(map(str, unknown))))
    parents = data.get("parents", [])
    shared = data.get("shared_subgroups", False)
    categories = data.get("subgroup_ids", {})
    if not isinstance(parents, list):
        raise ValueError("Grouping parents must be a list.")
    if not isinstance(shared, bool):
        raise ValueError("Grouping shared_subgroups must be a boolean.")
    if not isinstance(categories, dict) or any(
        not isinstance(key, str) or not isinstance(value, str)
        for key, value in categories.items()
    ):
        raise ValueError("Grouping subgroup_ids must map column IDs to category IDs.")
    for parent in parents:
        if not isinstance(parent, dict) or set(parent) != {"id", "name", "column_ids"}:
            raise ValueError("Grouping parents must contain id, name, and column_ids.")
        if not isinstance(parent["id"], str) or not parent["id"] or not isinstance(parent["name"], str):
            raise ValueError("Grouping parent ID and name must be strings, with a nonempty ID.")
        if not isinstance(parent["column_ids"], list) or any(
            not isinstance(column_id, str) for column_id in parent["column_ids"]
        ):
            raise ValueError("Grouping parent column_ids must be a list of strings.")
    return normalize_grouping(
        GroupingSettings(deepcopy(parents), shared, dict(categories)), column_ids,
    )


def parent_for_column(grouping: GroupingSettings, column_id: str) -> dict | None:
    return next((parent for parent in grouping.parents if column_id in parent["column_ids"]), None)


def ungroup_columns(grouping: GroupingSettings, column_ids: list[str]) -> None:
    """Remove membership, leaving data and the physical columns untouched."""
    removed = set(column_ids)
    for parent in grouping.parents:
        parent["column_ids"] = [column_id for column_id in parent["column_ids"] if column_id not in removed]
    grouping.parents = [parent for parent in grouping.parents if parent["column_ids"]]
    grouping.subgroup_ids = {key: value for key, value in grouping.subgroup_ids.items() if key not in removed}


def create_parent(grouping: GroupingSettings, column_ids: list[str], name: str) -> dict:
    """Group selected consecutive columns (the UI validates contiguity)."""
    members = list(dict.fromkeys(column_ids))
    if not members:
        raise ValueError("A parent group needs at least one subgroup.")
    categories = {key: grouping.subgroup_ids[key] for key in members if key in grouping.subgroup_ids}
    ungroup_columns(grouping, members)
    parent = {"id": uuid4().hex, "name": str(name), "column_ids": members}
    grouping.parents.append(parent)
    if grouping.shared_subgroups:
        grouping.subgroup_ids.update({key: categories.get(key, uuid4().hex) for key in members})
    return parent


def insert_subgroup(
    grouping: GroupingSettings, anchor_id: str, new_id: str, *, after: bool = True,
) -> dict | None:
    """Attach an inserted column to its anchor's parent, including at a boundary."""
    parent = parent_for_column(grouping, anchor_id)
    if parent is None:
        return None
    if parent_for_column(grouping, new_id) is not None:
        raise ValueError("The inserted subgroup already belongs to a parent.")
    index = parent["column_ids"].index(anchor_id) + int(after)
    parent["column_ids"].insert(index, new_id)
    if grouping.shared_subgroups:
        grouping.subgroup_ids[new_id] = uuid4().hex
    return parent
