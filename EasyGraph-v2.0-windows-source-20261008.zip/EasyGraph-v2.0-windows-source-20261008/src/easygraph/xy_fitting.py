from __future__ import annotations

import ast
from itertools import product
import math
import re
import warnings as python_warnings
from dataclasses import dataclass, field
from functools import lru_cache
from types import MappingProxyType
from typing import Callable, Mapping, Sequence
from uuid import uuid4

import numpy as np


__all__ = [
    "CustomExpressionError",
    "FIT_MODEL_REGISTRY",
    "FitModel",
    "FitParameterEstimate",
    "FitParameterSpec",
    "ParsedCustomExpression",
    "XYFitResult",
    "XYFitSpec",
    "default_fit_spec",
    "fit_xy_values",
    "initial_fit_parameters",
    "parse_custom_expression",
]


_TRIG_SINGULARITY_TOLERANCE = 8.0 * np.finfo(float).eps


def _trig_ratio(numerator: object, denominator: object) -> np.ndarray:
    """Return a trig ratio while marking floating-point singularities undefined."""

    numerator_values = np.asarray(numerator, dtype=float)
    denominator_values = np.asarray(denominator, dtype=float)
    shape = np.broadcast_shapes(numerator_values.shape, denominator_values.shape)
    numerator_values = np.broadcast_to(numerator_values, shape)
    denominator_values = np.broadcast_to(denominator_values, shape)
    result = np.full(shape, np.nan, dtype=float)
    np.divide(
        numerator_values,
        denominator_values,
        out=result,
        where=np.abs(denominator_values) > _TRIG_SINGULARITY_TOLERANCE,
    )
    return result


def _safe_tan(value: object) -> np.ndarray:
    return _trig_ratio(np.sin(value), np.cos(value))


def _sec(value: object) -> np.ndarray:
    return _trig_ratio(1.0, np.cos(value))


def _csc(value: object) -> np.ndarray:
    return _trig_ratio(1.0, np.sin(value))


def _cot(value: object) -> np.ndarray:
    return _trig_ratio(np.cos(value), np.sin(value))


def _log_base(value: object, base: object) -> np.ndarray:
    """Return a real logarithm, marking invalid values and bases undefined."""

    value_values, base_values = np.broadcast_arrays(
        np.asarray(value, dtype=float),
        np.asarray(base, dtype=float),
    )
    result = np.full(value_values.shape, np.nan, dtype=float)
    valid = (
        np.isfinite(value_values)
        & np.isfinite(base_values)
        & (value_values > 0.0)
        & (base_values > 0.0)
        & (base_values != 1.0)
    )
    with np.errstate(all="ignore"):
        numerator = np.log(value_values)
        denominator = np.log(base_values)
        np.divide(numerator, denominator, out=result, where=valid)
    return result


def _opposite_log_base_seed(
    current: float,
    lower: float,
    upper: float,
) -> float | None:
    """Choose a representable starting point on the other side of base 1."""

    canonical = 0.5 if current > 1.0 else 2.0
    if lower <= canonical <= upper:
        return canonical
    if current > 1.0:
        branch_lower = max(lower, math.nextafter(0.0, math.inf))
        branch_upper = min(upper, math.nextafter(1.0, 0.0))
    else:
        branch_lower = max(lower, math.nextafter(1.0, math.inf))
        branch_upper = upper
    if not math.isfinite(branch_lower) or branch_lower > branch_upper:
        return None
    if math.isinf(branch_upper):
        return max(2.0, branch_lower)
    candidate = branch_lower / 2.0 + branch_upper / 2.0
    return min(max(candidate, branch_lower), branch_upper)


def _log_base_optimizer_bounds(
    current: float,
    lower: float,
    upper: float,
) -> tuple[float, float] | None:
    """Map one connected real-log-base branch to bounds for q = ln(base)."""

    minimum_positive = math.nextafter(0.0, math.inf)
    maximum_finite = float(np.finfo(float).max)
    if current < 1.0:
        branch_lower = max(lower, minimum_positive)
        branch_upper = min(upper, math.nextafter(1.0, 0.0))
    elif current > 1.0:
        branch_lower = max(lower, math.nextafter(1.0, math.inf))
        branch_upper = min(upper, maximum_finite)
    else:
        return None
    if branch_lower > branch_upper:
        return None
    optimizer_lower = math.log(branch_lower)
    optimizer_upper = math.log(branch_upper)
    if optimizer_lower >= optimizer_upper:
        return None
    return optimizer_lower, optimizer_upper


_ALLOWED_FUNCTIONS: dict[str, Callable[..., object]] = {
    "exp": np.exp,
    "log": _log_base,
    "ln": np.log,
    "log10": np.log10,
    "sqrt": np.sqrt,
    "abs": np.abs,
    "sin": np.sin,
    "cos": np.cos,
    "tan": _safe_tan,
    "asin": np.arcsin,
    "acos": np.arccos,
    "atan": np.arctan,
    "atan2": np.arctan2,
    "sec": _sec,
    "csc": _csc,
    "cot": _cot,
    "sinh": np.sinh,
    "cosh": np.cosh,
    "tanh": np.tanh,
}
_FUNCTION_ARITIES = {
    name: (2 if name in {"log", "atan2"} else 1)
    for name in _ALLOWED_FUNCTIONS
}
_ALLOWED_CONSTANTS = {"pi": math.pi, "e": math.e}
_REDUCER_NAMES = frozenset({"sum_over", "integral"})
_MAX_SUM_TERMS = 256
_DEFAULT_INTEGRATION_POINTS = 32
_MIN_INTEGRATION_POINTS = 8
_MAX_INTEGRATION_POINTS = 128
_MAX_REDUCER_WORK = 512
_MAX_REDUCER_ELEMENTS_PER_CHUNK = 262_144
_MAX_EXACT_SUM_INDEX = 2**53 - 1
_MAX_LOG_BASE_STARTS = 16
_BINARY_OPERATORS: dict[type[ast.operator], Callable[[object, object], object]] = {
    ast.Add: np.add,
    ast.Sub: np.subtract,
    ast.Mult: np.multiply,
    ast.Div: np.divide,
    ast.Pow: np.power,
}
_UNARY_OPERATORS: dict[type[ast.unaryop], Callable[[object], object]] = {
    ast.UAdd: np.positive,
    ast.USub: np.negative,
}
_LINEAR_MODEL_IDS = frozenset(
    {"linear", "polynomial2", "polynomial3", "polynomial4", "polynomial5"}
)
_POLYNOMIAL_POWERS: dict[str, tuple[int, ...]] = {
    "linear": (1, 0),
    "polynomial2": (2, 1, 0),
    "polynomial3": (3, 2, 1, 0),
    "polynomial4": (4, 3, 2, 1, 0),
    "polynomial5": (5, 4, 3, 2, 1, 0),
}


class CustomExpressionError(ValueError):
    """A safe, user-correctable error in a custom curve expression."""


class _FitInputError(ValueError):
    pass


class _FitCancelled(RuntimeError):
    pass


@dataclass
class FitParameterSpec:
    name: str
    initial: float
    lower: float | None = None
    upper: float | None = None
    fixed: bool = False


@dataclass
class XYFitSpec:
    id: str
    series_id: str
    model_id: str
    expression: str = ""
    parameters: list[FitParameterSpec] = field(default_factory=list)
    enabled: bool = True
    auto_refit: bool = True
    line_style: str = "Dashed"
    line_width: float = 2.0
    color: str | None = None
    show_in_legend: bool = False
    show_equation: bool = False
    annotation_parameter_names: list[str] = field(default_factory=list)
    equation_position_x: float | None = None
    equation_position_y: float | None = None
    syntax_version: int = 1
    x_origin: float | None = None


@dataclass(frozen=True)
class FitParameterEstimate:
    name: str
    value: float
    standard_error: float | None = None
    confidence_interval: tuple[float, float] | None = None
    fixed: bool = False
    at_bound: bool = False


@dataclass(frozen=True)
class XYFitResult:
    """Renderer-independent, immutable output from one XY curve fit."""

    fit_id: str
    series_id: str
    model_id: str
    success: bool
    status: str
    message: str
    warnings: tuple[str, ...] = ()
    equation: str = ""
    x_origin: float | None = None
    parameter_estimates: tuple[FitParameterEstimate, ...] = ()
    observation_count: int = 0
    free_parameter_count: int = 0
    degrees_of_freedom: int = 0
    sse: float | None = None
    rmse: float | None = None
    r_squared: float | None = None
    adjusted_r_squared: float | None = None
    curve_x: tuple[float, ...] = ()
    curve_y: tuple[float, ...] = ()
    function_evaluations: int = 0
    equation_display_reliable: bool = True

    @property
    def parameters(self) -> Mapping[str, float]:
        return MappingProxyType(
            {estimate.name: estimate.value for estimate in self.parameter_estimates}
        )

    @property
    def standard_errors(self) -> Mapping[str, float | None]:
        return MappingProxyType(
            {
                estimate.name: estimate.standard_error
                for estimate in self.parameter_estimates
            }
        )

    @property
    def confidence_intervals(
        self,
    ) -> Mapping[str, tuple[float, float] | None]:
        return MappingProxyType(
            {
                estimate.name: estimate.confidence_interval
                for estimate in self.parameter_estimates
            }
        )

    @property
    def r2(self) -> float | None:
        return self.r_squared

    @property
    def adjusted_r2(self) -> float | None:
        return self.adjusted_r_squared


ExpressionEvaluator = Callable[[np.ndarray, Mapping[str, float]], object]


@dataclass(frozen=True)
class ParsedCustomExpression:
    source: str
    normalized_expression: str
    parameter_names: tuple[str, ...]
    _evaluator: ExpressionEvaluator = field(repr=False, compare=False)
    log_base_parameter_names: tuple[str, ...] = ()

    def evaluate(
        self,
        x: Sequence[float] | np.ndarray,
        parameters: Mapping[str, float],
    ) -> np.ndarray:
        missing = [name for name in self.parameter_names if name not in parameters]
        if missing:
            raise CustomExpressionError(
                "Missing parameter value(s): " + ", ".join(missing) + "."
            )
        x_values = np.asarray(x, dtype=float)
        with np.errstate(all="ignore"):
            result = self._evaluator(x_values, parameters)
        result_array = np.asarray(result, dtype=float)
        if result_array.ndim == 0:
            result_array = np.full(x_values.shape, float(result_array), dtype=float)
        try:
            return np.asarray(np.broadcast_to(result_array, x_values.shape), dtype=float)
        except ValueError as exc:
            raise CustomExpressionError(
                "The equation result does not match the shape of the X values."
            ) from exc

    def __call__(
        self,
        x: Sequence[float] | np.ndarray,
        **parameters: float,
    ) -> np.ndarray:
        return self.evaluate(x, parameters)


def _custom_rhs(expression: str) -> str:
    if not isinstance(expression, str) or not expression.strip():
        raise CustomExpressionError("Enter a curve equation before fitting.")
    if len(expression) > 2_000:
        raise CustomExpressionError("The curve equation is too long.")
    stripped = expression.strip()
    assignment = re.match(r"^[yY]\s*=", stripped)
    if assignment is not None:
        stripped = stripped[assignment.end() :].strip()
    if not stripped:
        raise CustomExpressionError("Enter the right-hand side of the equation.")
    stripped = re.sub(r"(?<!\w)[\u03a3\u2211](?=\s*\()", "sum_over", stripped)
    stripped = re.sub(r"(?<!\w)\u222b(?=\s*\()", "integral", stripped)
    return stripped.replace("^", "**")


def _static_integer(node: ast.AST, label: str) -> int:
    sign = 1
    value_node = node
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        sign = -1 if isinstance(node.op, ast.USub) else 1
        value_node = node.operand
    if (
        not isinstance(value_node, ast.Constant)
        or isinstance(value_node.value, bool)
        or not isinstance(value_node.value, int)
    ):
        raise CustomExpressionError(f"{label} must be a whole-number constant.")
    return sign * int(value_node.value)


def _reducer_binding(node: ast.Call) -> str:
    if not node.args or not isinstance(node.args[0], ast.Name):
        raise CustomExpressionError(
            "The first value in a sum or integral must be a local variable name."
        )
    name = node.args[0].id
    if (
        name in {"x", "y", *_ALLOWED_FUNCTIONS, *_ALLOWED_CONSTANTS, *_REDUCER_NAMES}
        or name.startswith("_")
    ):
        raise CustomExpressionError(
            f"'{name}' cannot be used as a sum or integral variable."
        )
    return name


def _expression_parameters(tree: ast.Expression) -> tuple[str, ...]:
    names: list[str] = []
    reducer_bindings: set[str] = set()
    reducer_work = 0

    class ParameterVisitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.local_names: list[frozenset[str]] = [frozenset()]
            self.reducer_depth = 0

        def visit_Name(self, node: ast.Name) -> None:  # noqa: N802
            name = node.id
            if name in {
                "x",
                *_ALLOWED_FUNCTIONS,
                *_ALLOWED_CONSTANTS,
                *_REDUCER_NAMES,
                *self.local_names[-1],
            }:
                return
            if name in reducer_bindings:
                raise CustomExpressionError(
                    f"The local variable '{name}' can only be used inside its sum or integral."
                )
            if name == "expression":
                raise CustomExpressionError(
                    "Replace the template word 'expression' with the formula "
                    "to sum or integrate."
                )
            if name == "y":
                raise CustomExpressionError(
                    "The right-hand side cannot refer to y; use parameters instead."
                )
            if name.startswith("_"):
                raise CustomExpressionError(
                    "Parameter names cannot start with an underscore."
                )
            if name not in names:
                names.append(name)

        def visit_Call(self, node: ast.Call) -> None:  # noqa: N802
            nonlocal reducer_work
            if not isinstance(node.func, ast.Name):
                self.generic_visit(node)
                return
            function_name = node.func.id
            if function_name not in _REDUCER_NAMES:
                for argument in node.args:
                    self.visit(argument)
                for keyword in node.keywords:
                    self.visit(keyword.value)
                return
            if self.reducer_depth:
                raise CustomExpressionError("Sums and integrals cannot be nested.")
            if node.keywords:
                raise CustomExpressionError(
                    "Sums and integrals do not accept named values."
                )
            binding = _reducer_binding(node)
            if binding in names:
                raise CustomExpressionError(
                    f"The local variable '{binding}' cannot also be a fitted parameter."
                )
            reducer_bindings.add(binding)
            if function_name == "sum_over":
                if len(node.args) != 4:
                    raise CustomExpressionError(
                        "sum_over requires: variable, first, last, expression."
                    )
                first = _static_integer(node.args[1], "The sum's first index")
                last = _static_integer(node.args[2], "The sum's last index")
                if max(abs(first), abs(last)) > _MAX_EXACT_SUM_INDEX:
                    raise CustomExpressionError(
                        "The sum indexes are too large for exact calculation."
                    )
                if last < first:
                    raise CustomExpressionError(
                        "The sum's last index must be greater than or equal to its first index."
                    )
                work = last - first + 1
                if work > _MAX_SUM_TERMS:
                    raise CustomExpressionError(
                        f"A sum can contain at most {_MAX_SUM_TERMS} terms."
                    )
                body = node.args[3]
            else:
                if len(node.args) not in {4, 5}:
                    raise CustomExpressionError(
                        "integral requires: variable, lower, upper, expression, "
                        "and optionally the number of points."
                    )
                self.reducer_depth += 1
                try:
                    self.visit(node.args[1])
                    self.visit(node.args[2])
                finally:
                    self.reducer_depth -= 1
                work = (
                    _DEFAULT_INTEGRATION_POINTS
                    if len(node.args) == 4
                    else _static_integer(
                        node.args[4], "The integral's point count"
                    )
                )
                if not _MIN_INTEGRATION_POINTS <= work <= _MAX_INTEGRATION_POINTS:
                    raise CustomExpressionError(
                        "The integral's point count must be between "
                        f"{_MIN_INTEGRATION_POINTS} and {_MAX_INTEGRATION_POINTS}."
                    )
                body = node.args[3]
            reducer_work += work
            if reducer_work > _MAX_REDUCER_WORK:
                raise CustomExpressionError(
                    "The equation contains too many sum or integral calculations."
                )
            self.reducer_depth += 1
            self.local_names.append(self.local_names[-1] | {binding})
            try:
                self.visit(body)
            finally:
                self.local_names.pop()
                self.reducer_depth -= 1

    ParameterVisitor().visit(tree)
    return tuple(names)


_InternalExpressionEvaluator = Callable[
    [np.ndarray, Mapping[str, float], Mapping[str, object]], object
]


def _broadcast_reducer_result(
    value: object,
    shape: tuple[int, ...],
    label: str,
) -> np.ndarray:
    try:
        return np.asarray(np.broadcast_to(np.asarray(value, dtype=float), shape), dtype=float)
    except (TypeError, ValueError) as exc:
        raise CustomExpressionError(
            f"The expression inside the {label} has an incompatible shape."
        ) from exc


def _compile_expression_node(
    node: ast.AST,
    parameter_names: frozenset[str],
    local_names: frozenset[str] = frozenset(),
    reducer_depth: int = 0,
) -> _InternalExpressionEvaluator:
    if isinstance(node, ast.Constant):
        if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
            raise CustomExpressionError("Only real numeric constants are allowed.")
        try:
            value = float(node.value)
        except (OverflowError, ValueError) as exc:
            raise CustomExpressionError("A numeric constant is too large.") from exc
        if not math.isfinite(value):
            raise CustomExpressionError("Numeric constants must be finite.")
        return lambda _x, _parameters, _locals, value=value: value

    if isinstance(node, ast.Name):
        if node.id == "x":
            return lambda x, _parameters, _locals: x
        if node.id in local_names:
            name = node.id
            return lambda _x, _parameters, locals_, name=name: locals_[name]
        if node.id in _ALLOWED_CONSTANTS:
            value = _ALLOWED_CONSTANTS[node.id]
            return lambda _x, _parameters, _locals, value=value: value
        if node.id in parameter_names:
            name = node.id
            return lambda _x, parameters, _locals, name=name: parameters[name]
        if node.id in {*_ALLOWED_FUNCTIONS, *_REDUCER_NAMES}:
            raise CustomExpressionError(
                f"Function '{node.id}' must be followed by parentheses."
            )
        raise CustomExpressionError(f"Unsupported name: {node.id}.")

    if isinstance(node, ast.BinOp):
        operation = _BINARY_OPERATORS.get(type(node.op))
        if operation is None:
            raise CustomExpressionError(
                "Only +, -, *, /, and ^ arithmetic operators are allowed."
            )
        left = _compile_expression_node(
            node.left, parameter_names, local_names, reducer_depth
        )
        right = _compile_expression_node(
            node.right, parameter_names, local_names, reducer_depth
        )
        return (
            lambda x, parameters, locals_, operation=operation, left=left, right=right: operation(
                left(x, parameters, locals_), right(x, parameters, locals_)
            )
        )

    if isinstance(node, ast.UnaryOp):
        operation = _UNARY_OPERATORS.get(type(node.op))
        if operation is None:
            raise CustomExpressionError("Only unary + and - are allowed.")
        operand = _compile_expression_node(
            node.operand, parameter_names, local_names, reducer_depth
        )
        return (
            lambda x, parameters, locals_, operation=operation, operand=operand: operation(
                operand(x, parameters, locals_)
            )
        )

    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise CustomExpressionError(
                "Only the listed mathematical functions can be called."
            )
        if node.func.id in _REDUCER_NAMES:
            if reducer_depth:
                raise CustomExpressionError("Sums and integrals cannot be nested.")
            if node.keywords:
                raise CustomExpressionError(
                    "Sums and integrals do not accept named values."
                )
            binding = _reducer_binding(node)
            if node.func.id == "sum_over":
                if len(node.args) != 4:
                    raise CustomExpressionError(
                        "sum_over requires: variable, first, last, expression."
                    )
                first = _static_integer(node.args[1], "The sum's first index")
                last = _static_integer(node.args[2], "The sum's last index")
                term_indexes = np.arange(first, last + 1, dtype=float)
                body = _compile_expression_node(
                    node.args[3],
                    parameter_names,
                    local_names | {binding},
                    reducer_depth + 1,
                )

                def evaluate_sum(
                    x: np.ndarray,
                    parameters: Mapping[str, float],
                    locals_: Mapping[str, object],
                    *,
                    binding: str = binding,
                    term_indexes: np.ndarray = term_indexes,
                    body: _InternalExpressionEvaluator = body,
                ) -> object:
                    x_values = np.asarray(x, dtype=float)
                    flat_x = x_values.reshape(-1)
                    output = np.empty(flat_x.shape, dtype=float)
                    chunk_size = max(
                        1,
                        _MAX_REDUCER_ELEMENTS_PER_CHUNK // term_indexes.size,
                    )
                    for start in range(0, flat_x.size, chunk_size):
                        chunk_x = flat_x[start : start + chunk_size]
                        target_shape = (chunk_x.size, term_indexes.size)
                        body_locals = dict(locals_)
                        body_locals[binding] = term_indexes[np.newaxis, :]
                        terms = _broadcast_reducer_result(
                            body(chunk_x[:, np.newaxis], parameters, body_locals),
                            target_shape,
                            "sum",
                        )
                        output[start : start + chunk_x.size] = np.sum(
                            terms, axis=-1
                        )
                    return output.reshape(x_values.shape)

                return evaluate_sum

            if len(node.args) not in {4, 5}:
                raise CustomExpressionError(
                    "integral requires: variable, lower, upper, expression, "
                    "and optionally the number of points."
                )
            point_count = (
                _DEFAULT_INTEGRATION_POINTS
                if len(node.args) == 4
                else _static_integer(node.args[4], "The integral's point count")
            )
            lower = _compile_expression_node(
                node.args[1], parameter_names, local_names, reducer_depth + 1
            )
            upper = _compile_expression_node(
                node.args[2], parameter_names, local_names, reducer_depth + 1
            )
            body = _compile_expression_node(
                node.args[3],
                parameter_names,
                local_names | {binding},
                reducer_depth + 1,
            )
            quadrature_nodes, quadrature_weights = np.polynomial.legendre.leggauss(
                point_count
            )

            def evaluate_integral(
                x: np.ndarray,
                parameters: Mapping[str, float],
                locals_: Mapping[str, object],
                *,
                binding: str = binding,
                lower: _InternalExpressionEvaluator = lower,
                upper: _InternalExpressionEvaluator = upper,
                body: _InternalExpressionEvaluator = body,
                nodes: np.ndarray = quadrature_nodes,
                weights: np.ndarray = quadrature_weights,
            ) -> object:
                x_values = np.asarray(x, dtype=float)
                flat_x = x_values.reshape(-1)
                output = np.empty(flat_x.shape, dtype=float)
                chunk_size = max(
                    1,
                    _MAX_REDUCER_ELEMENTS_PER_CHUNK // nodes.size,
                )
                for start in range(0, flat_x.size, chunk_size):
                    chunk_x = flat_x[start : start + chunk_size]
                    lower_values = _broadcast_reducer_result(
                        lower(chunk_x, parameters, locals_),
                        chunk_x.shape,
                        "integral bound",
                    )
                    upper_values = _broadcast_reducer_result(
                        upper(chunk_x, parameters, locals_),
                        chunk_x.shape,
                        "integral bound",
                    )
                    with np.errstate(over="ignore", invalid="ignore"):
                        midpoint = lower_values / 2.0 + upper_values / 2.0
                        half_width = upper_values / 2.0 - lower_values / 2.0
                        samples = midpoint[:, np.newaxis] + (
                            half_width[:, np.newaxis] * nodes
                        )
                    target_shape = (chunk_x.size, nodes.size)
                    body_locals = dict(locals_)
                    body_locals[binding] = samples
                    values = _broadcast_reducer_result(
                        body(chunk_x[:, np.newaxis], parameters, body_locals),
                        target_shape,
                        "integral",
                    )
                    output[start : start + chunk_x.size] = half_width * np.sum(
                        values * weights, axis=-1
                    )
                return output.reshape(x_values.shape)

            return evaluate_integral

        if node.func.id not in _ALLOWED_FUNCTIONS:
            raise CustomExpressionError(
                "Only the listed mathematical functions can be called."
            )
        argument_count = _FUNCTION_ARITIES[node.func.id]
        if node.func.id == "log" and node.keywords:
            raise CustomExpressionError(
                "Use log(value, base), such as log(x, 2). Named values such "
                "as base=2 are not supported."
            )
        if len(node.args) != argument_count or node.keywords:
            if node.func.id == "log":
                raise CustomExpressionError(
                    "Function 'log' requires exactly 2 values: log(value, base). "
                    "Use ln(value) for the natural logarithm."
                )
            value_word = "value" if argument_count == 1 else "values"
            raise CustomExpressionError(
                f"Function '{node.func.id}' requires exactly "
                f"{argument_count} {value_word}."
            )
        function = _ALLOWED_FUNCTIONS[node.func.id]
        arguments = tuple(
            _compile_expression_node(
                argument, parameter_names, local_names, reducer_depth
            )
            for argument in node.args
        )
        return (
            lambda x, parameters, locals_, function=function, arguments=arguments: function(
                *(argument(x, parameters, locals_) for argument in arguments)
            )
        )

    raise CustomExpressionError(
        "The equation contains unsupported syntax. Use numbers, x, parameters, "
        "arithmetic, and the listed mathematical functions only."
    )


@lru_cache(maxsize=256)
def parse_custom_expression(expression: str) -> ParsedCustomExpression:
    """Parse a custom curve without evaluating arbitrary Python code."""

    rhs = _custom_rhs(expression)
    try:
        tree = ast.parse(rhs, mode="eval")
    except (SyntaxError, ValueError) as exc:
        raise CustomExpressionError(
            "The equation could not be read. Check operators and parentheses."
        ) from exc
    if sum(1 for _node in ast.walk(tree)) > 256:
        raise CustomExpressionError("The curve equation is too complex.")
    parameter_names = _expression_parameters(tree)
    parameter_name_set = frozenset(parameter_names)
    direct_log_base_names = {
        node.args[1].id
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "log"
        and len(node.args) == 2
        and isinstance(node.args[1], ast.Name)
        and node.args[1].id in parameter_name_set
    }
    internal_evaluator = _compile_expression_node(
        tree.body, parameter_name_set
    )
    evaluator: ExpressionEvaluator = (
        lambda x, parameters, internal_evaluator=internal_evaluator: internal_evaluator(
            x, parameters, {}
        )
    )
    return ParsedCustomExpression(
        source=expression,
        normalized_expression=rhs,
        parameter_names=parameter_names,
        log_base_parameter_names=tuple(
            name for name in parameter_names if name in direct_log_base_names
        ),
        _evaluator=evaluator,
    )


ModelEvaluator = Callable[[np.ndarray, Sequence[float]], np.ndarray]
InitialGuess = Callable[[np.ndarray, np.ndarray], Sequence[float]]
DomainValidator = Callable[[np.ndarray], str | None]


@dataclass(frozen=True)
class FitModel:
    id: str
    display_name: str
    equation: str
    parameter_names: tuple[str, ...]
    initial_values: tuple[float, ...]
    default_bounds: tuple[tuple[float | None, float | None], ...]
    evaluator: ModelEvaluator = field(repr=False, compare=False)
    automatic_initial: InitialGuess = field(repr=False, compare=False)
    domain_validator: DomainValidator | None = field(
        default=None,
        repr=False,
        compare=False,
    )

    @property
    def default_parameters(self) -> tuple[FitParameterSpec, ...]:
        return tuple(
            FitParameterSpec(name, initial, lower, upper)
            for name, initial, (lower, upper) in zip(
                self.parameter_names,
                self.initial_values,
                self.default_bounds,
            )
        )


def _design_matrix(model_id: str, x: np.ndarray) -> np.ndarray:
    powers = _POLYNOMIAL_POWERS.get(model_id)
    if powers is None:
        raise ValueError(f"No linear design matrix for model: {model_id}")
    return np.column_stack(
        tuple(np.ones_like(x) if power == 0 else x**power for power in powers)
    )


def _stable_midpoint(lower: float, upper: float) -> float:
    """Return a finite midpoint without overflowing ``lower + upper``."""

    midpoint = lower / 2.0 + upper / 2.0
    if not math.isfinite(midpoint):
        raise _FitInputError("The X range is too large to choose a stable fitting origin.")
    return 0.0 if midpoint == 0.0 else midpoint


@dataclass(frozen=True)
class _CenteredPolynomialBasis:
    """Stable normalized basis for ordinary-X polynomial coefficients.

    Public parameters always multiply powers of the original ``x``. Internally,
    the polynomial is evaluated in ``t = (x - x_origin) / x_scale`` and relative
    to ``y_reference``. Keeping both representations separate lets the UI expose
    familiar equations without sacrificing numeric stability while fitting or
    drawing the curve.
    """

    model_id: str
    x_origin: float
    x_scale: float
    y_reference: float
    powers: tuple[int, ...]

    @classmethod
    def for_values(
        cls,
        spec: XYFitSpec,
        x: np.ndarray,
        y: np.ndarray,
    ) -> _CenteredPolynomialBasis:
        # The origin is purely an internal numeric aid. Public coefficients use
        # the original X variable, so a persisted origin must never pin a later
        # refit to an obsolete data range.
        x_origin = _stable_midpoint(float(np.min(x)), float(np.max(x)))

        with np.errstate(over="ignore", invalid="ignore"):
            centered_x = x - x_origin
        if not np.all(np.isfinite(centered_x)):
            raise _FitInputError(
                "The current X range is too large to choose a stable polynomial origin."
            )
        x_scale = float(np.max(np.abs(centered_x)))
        if x_scale == 0.0:
            x_scale = 1.0
        powers = _POLYNOMIAL_POWERS[spec.model_id]
        with np.errstate(over="ignore", invalid="ignore"):
            coefficient_scales = np.power(x_scale, np.asarray(powers, dtype=float))
        if not np.all(np.isfinite(coefficient_scales)):
            raise _FitInputError(
                "The X range is too large for this polynomial degree at numeric precision."
            )
        return cls(
            model_id=spec.model_id,
            x_origin=x_origin,
            x_scale=x_scale,
            y_reference=float(y[0]),
            powers=powers,
        )

    def matrix(self, x: np.ndarray) -> np.ndarray:
        with np.errstate(over="ignore", invalid="ignore"):
            normalized_x = (x - self.x_origin) / self.x_scale
            matrix = _design_matrix(self.model_id, normalized_x)
        if not np.all(np.isfinite(matrix)):
            raise _FitInputError(
                "The polynomial is outside the numeric range supported by the current X values."
            )
        return matrix

    def _raw_to_internal_matrix(self, *, extended: bool = False) -> np.ndarray:
        """Return the linear part of ``raw coefficients -> internal``."""

        dtype = np.longdouble if extended else float
        powers = self.powers
        matrix = np.zeros((len(powers), len(powers)), dtype=dtype)
        origin = dtype(self.x_origin)
        scale = dtype(self.x_scale)
        for row, centered_power in enumerate(powers):
            for column, raw_power in enumerate(powers):
                if centered_power > raw_power:
                    continue
                matrix[row, column] = (
                    dtype(math.comb(raw_power, centered_power))
                    * origin ** (raw_power - centered_power)
                    * scale**centered_power
                )
        return matrix

    def internal_to_raw_matrix(self, *, extended: bool = False) -> np.ndarray:
        """Return the linear part of ``internal -> raw coefficients``."""

        powers = self.powers
        extended_matrix = np.zeros(
            (len(powers), len(powers)),
            dtype=np.longdouble,
        )
        origin = np.longdouble(self.x_origin)
        scale = np.longdouble(self.x_scale)
        for row, raw_power in enumerate(powers):
            for column, centered_power in enumerate(powers):
                if raw_power > centered_power:
                    continue
                extended_matrix[row, column] = (
                    np.longdouble(math.comb(centered_power, raw_power))
                    * (-origin) ** (centered_power - raw_power)
                    / scale**centered_power
                )
        if extended:
            return extended_matrix
        with np.errstate(over="ignore", invalid="ignore"):
            matrix = np.asarray(extended_matrix, dtype=float)
        if not np.all(np.isfinite(matrix)):
            raise _FitInputError(
                "The ordinary-X polynomial coefficients exceed the supported numeric range."
            )
        return matrix

    def raw_to_absolute_internal(self, parameters: Sequence[float]) -> np.ndarray:
        """Convert raw coefficients to the normalized basis without Y centering."""

        raw = np.asarray(parameters, dtype=float)
        with np.errstate(over="ignore", invalid="ignore"):
            absolute_internal_extended = self._raw_to_internal_matrix(
                extended=True
            ) @ np.asarray(raw, dtype=np.longdouble)
            absolute_internal = np.asarray(
                absolute_internal_extended,
                dtype=float,
            )
        if not np.all(np.isfinite(absolute_internal)):
            raise _FitInputError(
                "The ordinary-X polynomial parameters exceed the numeric range for these X values."
            )
        return absolute_internal

    def absolute_internal_to_raw(self, parameters: Sequence[float]) -> np.ndarray:
        """Convert normalized coefficients without a data-dependent Y offset."""

        absolute_internal = np.asarray(parameters, dtype=float)
        matrix = self.internal_to_raw_matrix(extended=True)
        with np.errstate(over="ignore", invalid="ignore"):
            raw_extended = matrix @ np.asarray(
                absolute_internal,
                dtype=np.longdouble,
            )
            raw = np.asarray(raw_extended, dtype=float)
        if not np.all(np.isfinite(raw)):
            raise _FitInputError(
                "The ordinary-X polynomial coefficients exceed the supported numeric range."
            )
        return raw

    def raw_to_internal(self, parameters: Sequence[float]) -> np.ndarray:
        internal = self.raw_to_absolute_internal(parameters)
        with np.errstate(over="ignore", invalid="ignore"):
            internal[-1] -= self.y_reference
        if not math.isfinite(float(internal[-1])):
            raise _FitInputError(
                "The ordinary-X polynomial parameters exceed the numeric range for these X values."
            )
        return internal

    def internal_to_raw(self, parameters: Sequence[float]) -> np.ndarray:
        internal = np.asarray(parameters, dtype=float)
        absolute_internal = internal.copy()
        with np.errstate(over="ignore", invalid="ignore"):
            absolute_internal[-1] += self.y_reference
        if not math.isfinite(float(absolute_internal[-1])):
            raise _FitInputError(
                "The ordinary-X polynomial coefficients exceed the supported numeric range."
            )
        return self.absolute_internal_to_raw(absolute_internal)

    def evaluate_internal(self, x: np.ndarray, parameters: np.ndarray) -> np.ndarray:
        matrix = self.matrix(x)
        with np.errstate(over="ignore", invalid="ignore"):
            return np.asarray(
                self.y_reference + matrix @ np.asarray(parameters, dtype=float),
                dtype=float,
            )

    def evaluate_absolute_internal(
        self,
        x: np.ndarray,
        parameters: np.ndarray,
    ) -> np.ndarray:
        matrix = self.matrix(x)
        with np.errstate(over="ignore", invalid="ignore"):
            return np.asarray(matrix @ np.asarray(parameters, dtype=float), dtype=float)

    def residual_absolute_internal(
        self,
        x: np.ndarray,
        y: np.ndarray,
        parameters: np.ndarray,
    ) -> np.ndarray:
        """Evaluate a gamma-basis residual without subtracting large Y baselines."""

        matrix = self.matrix(x)
        beta = np.asarray(parameters, dtype=float).copy()
        beta[-1] -= self.y_reference
        with np.errstate(over="ignore", invalid="ignore"):
            centered_y = y - self.y_reference
            return np.asarray(matrix @ beta - centered_y, dtype=float)

    def evaluate_raw(self, x: np.ndarray, parameters: Sequence[float]) -> np.ndarray:
        internal = self.raw_to_internal(parameters)
        return self.evaluate_internal(x, internal)

    def automatic_internal(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        matrix = self.matrix(x)
        with np.errstate(over="ignore", invalid="ignore"):
            target = y - self.y_reference
        if not np.all(np.isfinite(target)):
            raise _FitInputError(
                "The Y range is too large to initialize this polynomial fit."
            )
        internal, *_unused = np.linalg.lstsq(matrix, target, rcond=None)
        return np.asarray(internal, dtype=float)

    def automatic_initial(self, x: np.ndarray, y: np.ndarray) -> tuple[float, ...]:
        internal = self.automatic_internal(x, y)
        raw = self.internal_to_raw(internal)
        return tuple(float(value) for value in raw)


def _exponential_initial(x: np.ndarray, y: np.ndarray) -> tuple[float, ...]:
    order = np.argsort(x)
    sorted_y = y[order]
    span = max(float(np.ptp(x)), 1.0)
    y_span = float(np.ptp(y))
    if y_span <= np.finfo(float).eps:
        return 0.0, 0.0, float(np.mean(y))
    increasing = float(sorted_y[-1]) >= float(sorted_y[0])
    rate = (1.0 if increasing else -1.0) / span
    offset = float(np.min(y) - 0.05 * y_span)
    reference_x = float(x[order[0]])
    amplitude = float((sorted_y[0] - offset) / math.exp(rate * reference_x))
    if not math.isfinite(amplitude) or abs(amplitude) < np.finfo(float).eps:
        amplitude = y_span
    return amplitude, rate, offset


def _logarithmic_initial(x: np.ndarray, y: np.ndarray) -> tuple[float, ...]:
    logged_x = np.log(x)
    matrix = np.column_stack((logged_x, np.ones_like(logged_x)))
    coefficients, *_unused = np.linalg.lstsq(matrix, y, rcond=None)
    return tuple(float(value) for value in coefficients)


def _power_initial(x: np.ndarray, y: np.ndarray) -> tuple[float, ...]:
    nonzero = np.abs(y) > np.finfo(float).eps
    if np.count_nonzero(nonzero) >= 2 and np.all(np.sign(y[nonzero]) == np.sign(y[nonzero][0])):
        logged_x = np.log(x[nonzero])
        logged_y = np.log(np.abs(y[nonzero]))
        matrix = np.column_stack((logged_x, np.ones_like(logged_x)))
        exponent, logged_amplitude = np.linalg.lstsq(
            matrix,
            logged_y,
            rcond=None,
        )[0]
        amplitude = math.copysign(math.exp(float(logged_amplitude)), float(y[nonzero][0]))
        return float(amplitude), float(exponent)
    scale = float(np.max(np.abs(y))) if y.size else 1.0
    return (scale or 1.0), 1.0


def _gaussian_initial(x: np.ndarray, y: np.ndarray) -> tuple[float, ...]:
    order = np.argsort(x)
    edge_count = max(1, min(len(x) // 5, 5))
    edge_values = np.concatenate((y[order[:edge_count]], y[order[-edge_count:]]))
    baseline = float(np.median(edge_values))
    deviations = y - baseline
    peak_index = int(np.argmax(np.abs(deviations)))
    amplitude = float(deviations[peak_index])
    if abs(amplitude) <= np.finfo(float).eps:
        amplitude = float(np.ptp(y)) or 1.0
    center = float(x[peak_index])
    span = max(float(np.ptp(x)), np.finfo(float).eps)
    weights = np.abs(deviations)
    if float(np.sum(weights)) > np.finfo(float).eps:
        variance = float(np.sum(weights * (x - center) ** 2) / np.sum(weights))
        sigma = math.sqrt(max(variance, 0.0))
    else:
        sigma = span / 6.0
    sigma = max(sigma, span / 100.0, 1e-12)
    return baseline, amplitude, center, sigma


def _positive_x_domain(x: np.ndarray) -> str | None:
    if np.any(x <= 0.0):
        return "This model requires every X value to be greater than zero."
    return None


def _evaluate_linear(model_id: str) -> ModelEvaluator:
    return lambda x, parameters: np.asarray(
        _design_matrix(model_id, x) @ np.asarray(parameters, dtype=float),
        dtype=float,
    )


FIT_MODEL_REGISTRY: dict[str, FitModel] = {
    "linear": FitModel(
        id="linear",
        display_name="Linear",
        equation="y = slope * x + intercept",
        parameter_names=("slope", "intercept"),
        initial_values=(1.0, 0.0),
        default_bounds=((None, None), (None, None)),
        evaluator=_evaluate_linear("linear"),
        automatic_initial=lambda _x, _y: (1.0, 0.0),
    ),
    "polynomial2": FitModel(
        id="polynomial2",
        display_name="Quadratic polynomial",
        equation="y = a * x^2 + b * x + c",
        parameter_names=("a", "b", "c"),
        initial_values=(1.0, 1.0, 0.0),
        default_bounds=((None, None), (None, None), (None, None)),
        evaluator=_evaluate_linear("polynomial2"),
        automatic_initial=lambda _x, _y: (1.0, 1.0, 0.0),
    ),
    "polynomial3": FitModel(
        id="polynomial3",
        display_name="Cubic polynomial",
        equation="y = a * x^3 + b * x^2 + c * x + d",
        parameter_names=("a", "b", "c", "d"),
        initial_values=(1.0, 1.0, 1.0, 0.0),
        default_bounds=((None, None),) * 4,
        evaluator=_evaluate_linear("polynomial3"),
        automatic_initial=lambda _x, _y: (1.0, 1.0, 1.0, 0.0),
    ),
    "polynomial4": FitModel(
        id="polynomial4",
        display_name="Quartic polynomial",
        equation="y = a * x^4 + b * x^3 + c * x^2 + d * x + e",
        parameter_names=("a", "b", "c", "d", "e"),
        initial_values=(1.0, 1.0, 1.0, 1.0, 0.0),
        default_bounds=((None, None),) * 5,
        evaluator=_evaluate_linear("polynomial4"),
        automatic_initial=lambda _x, _y: (1.0, 1.0, 1.0, 1.0, 0.0),
    ),
    "polynomial5": FitModel(
        id="polynomial5",
        display_name="Quintic polynomial",
        equation=(
            "y = a * x^5 + b * x^4 + c * x^3 + d * x^2 + e * x + f"
        ),
        parameter_names=("a", "b", "c", "d", "e", "f"),
        initial_values=(1.0, 1.0, 1.0, 1.0, 1.0, 0.0),
        default_bounds=((None, None),) * 6,
        evaluator=_evaluate_linear("polynomial5"),
        automatic_initial=lambda _x, _y: (1.0, 1.0, 1.0, 1.0, 1.0, 0.0),
    ),
    "exponential": FitModel(
        id="exponential",
        display_name="Exponential",
        equation="y = amplitude * exp(rate * x) + offset",
        parameter_names=("amplitude", "rate", "offset"),
        initial_values=(1.0, 1.0, 0.0),
        default_bounds=((None, None), (None, None), (None, None)),
        evaluator=lambda x, p: p[0] * np.exp(p[1] * x) + p[2],
        automatic_initial=_exponential_initial,
    ),
    "logarithmic": FitModel(
        id="logarithmic",
        display_name="Logarithmic",
        equation="y = slope * ln(x) + intercept",
        parameter_names=("slope", "intercept"),
        initial_values=(1.0, 0.0),
        default_bounds=((None, None), (None, None)),
        evaluator=lambda x, p: p[0] * np.log(x) + p[1],
        automatic_initial=_logarithmic_initial,
        domain_validator=_positive_x_domain,
    ),
    "power": FitModel(
        id="power",
        display_name="Power",
        equation="y = amplitude * x^exponent",
        parameter_names=("amplitude", "exponent"),
        initial_values=(1.0, 1.0),
        default_bounds=((None, None), (None, None)),
        evaluator=lambda x, p: p[0] * np.power(x, p[1]),
        automatic_initial=_power_initial,
        domain_validator=_positive_x_domain,
    ),
    "gaussian": FitModel(
        id="gaussian",
        display_name="Gaussian peak",
        equation="y = baseline + amplitude * exp(-0.5 * ((x - center) / sigma)^2)",
        parameter_names=("baseline", "amplitude", "center", "sigma"),
        initial_values=(0.0, 1.0, 0.0, 1.0),
        default_bounds=((None, None), (None, None), (None, None), (1e-12, None)),
        evaluator=lambda x, p: p[0]
        + p[1] * np.exp(-0.5 * np.square((x - p[2]) / p[3])),
        automatic_initial=_gaussian_initial,
    ),
    "custom": FitModel(
        id="custom",
        display_name="Custom equation",
        equation="y = custom expression",
        parameter_names=(),
        initial_values=(),
        default_bounds=(),
        evaluator=lambda x, _p: np.zeros_like(x),
        automatic_initial=lambda _x, _y: (),
    ),
}


def default_fit_spec(series_id: str, model_id: str) -> XYFitSpec:
    if model_id not in FIT_MODEL_REGISTRY:
        raise ValueError(f"Unknown curve model: {model_id}")
    return XYFitSpec(
        id=uuid4().hex,
        series_id=str(series_id),
        model_id=model_id,
    )


def _numeric_vector(values: Sequence[float] | np.ndarray, label: str) -> np.ndarray:
    try:
        result = np.asarray(values, dtype=float)
    except (TypeError, ValueError) as exc:
        raise _FitInputError(f"{label} values must all be numeric.") from exc
    if result.ndim != 1:
        raise _FitInputError(f"{label} values must be a one-dimensional series.")
    if not np.all(np.isfinite(result)):
        raise _FitInputError(f"{label} values must not contain blanks, NaN, or infinity.")
    return result


def _custom_components(
    spec: XYFitSpec,
) -> tuple[
    tuple[str, ...],
    tuple[float, ...],
    tuple[tuple[float | None, float | None], ...],
    ModelEvaluator,
    str,
    _CenteredPolynomialBasis | None,
]:
    if spec.syntax_version != 1:
        raise _FitInputError(
            f"Custom equation syntax version {spec.syntax_version} is not supported."
        )
    try:
        parsed = parse_custom_expression(spec.expression)
    except CustomExpressionError as exc:
        raise _FitInputError(str(exc)) from exc
    names = parsed.parameter_names
    log_base_names = frozenset(parsed.log_base_parameter_names)
    return (
        names,
        tuple(2.0 if name in log_base_names else 1.0 for name in names),
        ((None, None),) * len(names),
        lambda x, values: parsed.evaluate(x, dict(zip(names, values))),
        f"y = {parsed.normalized_expression}",
        None,
    )


def _model_components(
    spec: XYFitSpec,
    x: np.ndarray,
    y: np.ndarray,
) -> tuple[
    tuple[str, ...],
    tuple[float, ...],
    tuple[tuple[float | None, float | None], ...],
    ModelEvaluator,
    str,
    _CenteredPolynomialBasis | None,
]:
    model = FIT_MODEL_REGISTRY.get(spec.model_id)
    if model is None:
        raise _FitInputError(f"Unknown curve model: {spec.model_id}.")
    if spec.model_id == "custom":
        return _custom_components(spec)
    if spec.model_id in _LINEAR_MODEL_IDS:
        basis = _CenteredPolynomialBasis.for_values(spec, x, y)
        try:
            automatic = basis.automatic_initial(x, y)
        except (ArithmeticError, ValueError, np.linalg.LinAlgError):
            automatic = model.initial_values
        if len(automatic) != len(model.parameter_names) or not np.all(
            np.isfinite(automatic)
        ):
            automatic = model.initial_values
        return (
            model.parameter_names,
            automatic,
            model.default_bounds,
            basis.evaluate_raw,
            model.equation,
            basis,
        )
    if model.domain_validator is not None:
        domain_error = model.domain_validator(x)
        if domain_error is not None:
            raise _FitInputError(domain_error)
    try:
        with np.errstate(all="ignore"):
            automatic = tuple(float(value) for value in model.automatic_initial(x, y))
    except (ArithmeticError, ValueError, np.linalg.LinAlgError):
        automatic = model.initial_values
    if len(automatic) != len(model.parameter_names) or not np.all(np.isfinite(automatic)):
        automatic = model.initial_values
    return (
        model.parameter_names,
        automatic,
        model.default_bounds,
        model.evaluator,
        model.equation,
        None,
    )


def _resolved_parameter_specs(
    names: tuple[str, ...],
    automatic: tuple[float, ...],
    default_bounds: tuple[tuple[float | None, float | None], ...],
    supplied: Sequence[FitParameterSpec],
) -> tuple[FitParameterSpec, ...]:
    supplied_by_name: dict[str, FitParameterSpec] = {}
    for parameter in supplied:
        name = str(parameter.name)
        if name in supplied_by_name:
            raise _FitInputError(f"Parameter '{name}' is listed more than once.")
        if name not in names:
            raise _FitInputError(f"Parameter '{name}' is not used by this equation.")
        supplied_by_name[name] = parameter

    resolved: list[FitParameterSpec] = []
    for name, initial, (lower, upper) in zip(names, automatic, default_bounds):
        supplied_parameter = supplied_by_name.get(name)
        if supplied_parameter is None:
            resolved.append(FitParameterSpec(name, initial, lower, upper))
        else:
            resolved.append(
                FitParameterSpec(
                    name=name,
                    initial=supplied_parameter.initial,
                    lower=supplied_parameter.lower,
                    upper=supplied_parameter.upper,
                    fixed=bool(supplied_parameter.fixed),
                )
            )
    return tuple(resolved)


def _validated_parameter_arrays(
    parameters: tuple[FitParameterSpec, ...],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    initial: list[float] = []
    lower: list[float] = []
    upper: list[float] = []
    fixed: list[bool] = []
    for parameter in parameters:
        try:
            initial_value = float(parameter.initial)
            lower_value = -math.inf if parameter.lower is None else float(parameter.lower)
            upper_value = math.inf if parameter.upper is None else float(parameter.upper)
        except (TypeError, ValueError, OverflowError) as exc:
            raise _FitInputError(
                f"Parameter '{parameter.name}' has a non-numeric initial value or bound."
            ) from exc
        if not math.isfinite(initial_value):
            raise _FitInputError(
                f"Parameter '{parameter.name}' needs a finite initial value."
            )
        if math.isnan(lower_value) or math.isnan(upper_value):
            raise _FitInputError(f"Parameter '{parameter.name}' has an invalid bound.")
        if lower_value > upper_value:
            raise _FitInputError(
                f"Parameter '{parameter.name}' has a lower bound above its upper bound."
            )
        is_fixed = bool(parameter.fixed)
        if not is_fixed and lower_value == upper_value:
            raise _FitInputError(
                f"Parameter '{parameter.name}' has identical bounds; mark it as fixed instead."
            )
        if initial_value < lower_value or initial_value > upper_value:
            raise _FitInputError(
                f"Initial value for '{parameter.name}' must lie within its bounds."
            )
        initial.append(initial_value)
        lower.append(lower_value)
        upper.append(upper_value)
        fixed.append(is_fixed)
    return (
        np.asarray(initial, dtype=float),
        np.asarray(lower, dtype=float),
        np.asarray(upper, dtype=float),
        np.asarray(fixed, dtype=bool),
    )


def initial_fit_parameters(
    x: Sequence[float] | np.ndarray,
    y: Sequence[float] | np.ndarray,
    spec: XYFitSpec,
) -> tuple[FitParameterSpec, ...]:
    """Return data-aware parameter suggestions without importing SciPy."""

    x_values = _numeric_vector(x, "X")
    y_values = _numeric_vector(y, "Y")
    if x_values.size != y_values.size:
        raise ValueError("X and Y must contain the same number of values.")
    try:
        names, automatic, bounds, _evaluator, _equation, _basis = _model_components(
            spec,
            x_values,
            y_values,
        )
        return _resolved_parameter_specs(names, automatic, bounds, spec.parameters)
    except _FitInputError as exc:
        raise ValueError(str(exc)) from exc


def _evaluated_values(
    evaluator: ModelEvaluator,
    x: np.ndarray,
    parameters: np.ndarray,
) -> np.ndarray:
    with np.errstate(all="ignore"):
        values = np.asarray(evaluator(x, parameters), dtype=float)
    if values.ndim == 0:
        values = np.full(x.shape, float(values), dtype=float)
    try:
        return np.asarray(np.broadcast_to(values, x.shape), dtype=float)
    except ValueError as exc:
        raise _FitInputError(
            "The model output does not match the number of X values."
        ) from exc


def _failure_result(
    spec: XYFitSpec,
    message: str,
    *,
    status: str = "error",
    warnings: tuple[str, ...] = (),
    observation_count: int = 0,
) -> XYFitResult:
    return XYFitResult(
        fit_id=spec.id,
        series_id=spec.series_id,
        model_id=spec.model_id,
        success=False,
        status=status,
        message=message,
        warnings=warnings,
        x_origin=spec.x_origin,
        observation_count=observation_count,
    )


def _stable_norm(values: np.ndarray, label: str) -> tuple[float, float]:
    """Return (Euclidean norm, sum of squares) with explicit range errors."""

    if not np.all(np.isfinite(values)):
        raise _FitInputError(f"{label} contains values outside the numeric range.")
    magnitude = float(np.max(np.abs(values))) if values.size else 0.0
    if magnitude == 0.0:
        return 0.0, 0.0
    with np.errstate(over="ignore", under="ignore", invalid="ignore"):
        normalized = values / magnitude
        unit_sum_squares = float(np.dot(normalized, normalized))
        norm = float(magnitude * math.sqrt(unit_sum_squares))
    if not math.isfinite(unit_sum_squares) or not math.isfinite(norm):
        raise _FitInputError(f"{label} exceeds the supported numeric range.")
    maximum_square_root = math.sqrt(np.finfo(float).max)
    if norm > maximum_square_root:
        raise _FitInputError(f"{label} sum of squares exceeds the supported numeric range.")
    squared = float(norm * norm)
    if not math.isfinite(squared) or (squared == 0.0 and norm != 0.0):
        raise _FitInputError(f"{label} sum of squares is outside the supported numeric range.")
    return norm, squared


def _stable_centered_y(y: np.ndarray) -> np.ndarray:
    """Center Y after removing its first value, preserving small large-offset changes."""

    with np.errstate(over="ignore", invalid="ignore"):
        delta = y - float(y[0])
    if not np.all(np.isfinite(delta)):
        raise _FitInputError(
            "Y variation exceeds the supported numeric range for fit statistics."
        )
    magnitude = float(np.max(np.abs(delta)))
    if magnitude == 0.0:
        return np.zeros_like(delta)
    with np.errstate(over="ignore", invalid="ignore"):
        mean_delta = magnitude * float(np.mean(delta / magnitude))
        centered = delta - mean_delta
    if not math.isfinite(mean_delta) or not np.all(np.isfinite(centered)):
        raise _FitInputError(
            "Y variation exceeds the supported numeric range for fit statistics."
        )
    return centered


def _parameter_uncertainty(
    estimates: np.ndarray,
    fixed: np.ndarray,
    jacobian: np.ndarray,
    sse: float,
    degrees_of_freedom: int,
    warnings: list[str],
    internal_to_public_transform: np.ndarray | None = None,
) -> tuple[list[float | None], list[tuple[float, float] | None]]:
    standard_errors: list[float | None] = [None] * len(estimates)
    intervals: list[tuple[float, float] | None] = [None] * len(estimates)
    free_indexes = np.flatnonzero(~fixed)
    free_count = len(free_indexes)
    if free_count == 0:
        return standard_errors, intervals
    if degrees_of_freedom <= 0:
        warnings.append(
            "Standard errors and confidence intervals need more data points than free parameters."
        )
        return standard_errors, intervals
    if jacobian.ndim != 2 or jacobian.shape[1] != free_count:
        warnings.append("Parameter uncertainty could not be calculated.")
        return standard_errors, intervals
    try:
        _left, singular_values, right_transpose = np.linalg.svd(
            jacobian,
            full_matrices=False,
        )
        if singular_values.size != free_count:
            raise np.linalg.LinAlgError
        tolerance = (
            np.finfo(float).eps
            * max(jacobian.shape)
            * float(singular_values[0])
        )
        if np.any(singular_values <= tolerance):
            warnings.append(
                "Some parameters are not independently identifiable; their uncertainty is unavailable."
            )
            return standard_errors, intervals
        residual_standard_deviation = (
            math.sqrt(sse) / math.sqrt(degrees_of_freedom)
        )
        # Work with a covariance square-root factor. Squaring a raw slope scale
        # such as 1e-300 would underflow even though its standard error remains
        # representable; row-wise hypot keeps that information intact.
        covariance_factor = (
            right_transpose.T * (1.0 / singular_values)
        ) * residual_standard_deviation
        if internal_to_public_transform is not None:
            transform = np.asarray(internal_to_public_transform, dtype=float)
            if transform.shape != (free_count, free_count) or not np.all(
                np.isfinite(transform)
            ):
                raise np.linalg.LinAlgError
            with np.errstate(over="ignore", invalid="ignore"):
                covariance_factor = transform @ covariance_factor
        if not np.all(np.isfinite(covariance_factor)):
            raise np.linalg.LinAlgError
        free_errors = np.asarray(
            [
                math.hypot(*(float(value) for value in row))
                for row in covariance_factor
            ],
            dtype=float,
        )
        if (
            residual_standard_deviation > 0.0
            and np.any(free_errors == 0.0)
        ):
            raise np.linalg.LinAlgError
        # Kept local so importing persisted fit settings does not load SciPy.
        from scipy.stats import t as student_t

        critical = float(student_t.ppf(0.975, degrees_of_freedom))
        if not math.isfinite(critical) or not np.all(np.isfinite(free_errors)):
            raise np.linalg.LinAlgError
    except (ArithmeticError, ValueError, np.linalg.LinAlgError):
        warnings.append("Parameter uncertainty could not be calculated.")
        return standard_errors, intervals
    for free_position, parameter_index in enumerate(free_indexes):
        error = float(free_errors[free_position])
        value = float(estimates[parameter_index])
        standard_errors[parameter_index] = error
        intervals[parameter_index] = (
            value - critical * error,
            value + critical * error,
        )
        if not all(math.isfinite(bound) for bound in intervals[parameter_index]):
            warnings.append("Parameter uncertainty could not be calculated.")
            return [None] * len(estimates), [None] * len(estimates)
    return standard_errors, intervals


def _coefficient_tolerance(
    value: float,
    reference: float,
    lower: float = -math.inf,
    upper: float = math.inf,
) -> float:
    """Return a scale-aware floating tolerance without an absolute floor."""

    tolerance = 1024.0 * max(math.ulp(value), math.ulp(reference))
    if math.isfinite(lower) and math.isfinite(upper):
        with np.errstate(over="ignore", invalid="ignore"):
            span = float(upper - lower)
        if math.isfinite(span) and span > 0.0:
            tolerance = max(
                tolerance,
                1024.0 * np.finfo(float).eps * span,
            )
    return tolerance


def _transformed_coefficient_tolerance(
    transform_row: np.ndarray,
    absolute_internal: np.ndarray,
    value: float,
    reference: float,
    lower: float = -math.inf,
    upper: float = math.inf,
) -> float:
    """Include the backward error of one raw-coefficient matrix product."""

    tolerance = _coefficient_tolerance(value, reference, lower, upper)
    backward_error = _raw_transform_backward_error(
        transform_row,
        absolute_internal,
    )
    if backward_error is not None:
        tolerance = max(tolerance, backward_error)
    return tolerance


def _raw_transform_backward_error(
    transform_row: np.ndarray,
    absolute_internal: np.ndarray,
) -> float | None:
    """Estimate the absolute roundoff in one internal-to-raw row product."""

    with np.errstate(over="ignore", invalid="ignore"):
        magnitude = np.dot(
            np.abs(np.asarray(transform_row, dtype=np.longdouble)),
            np.abs(np.asarray(absolute_internal, dtype=np.longdouble)),
        )
        backward_error = (
            np.longdouble(256.0)
            * np.longdouble(np.finfo(float).eps)
            * magnitude
        )
    if np.isfinite(backward_error) and backward_error <= np.finfo(float).max:
        return float(backward_error)
    return None


def _raw_constraint_row_is_reliable(
    transform_row: np.ndarray,
    parameter_index: int,
) -> bool:
    """Check raw-constraint conditioning using only the current X basis."""

    magnitudes = np.abs(np.asarray(transform_row, dtype=float))
    pivot = float(magnitudes[parameter_index])
    if (
        pivot == 0.0
        or not math.isfinite(pivot)
        or not np.all(np.isfinite(magnitudes))
    ):
        return False
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        dynamic_range = float(np.max(magnitudes) / pivot)
    return math.isfinite(dynamic_range) and dynamic_range <= (
        1.0 / math.sqrt(np.finfo(float).eps)
    )


def _constrained_polynomial_fit(
    basis: _CenteredPolynomialBasis,
    matrix: np.ndarray,
    y: np.ndarray,
    initial: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    fixed: np.ndarray,
    *,
    cancel_check: Callable[[], bool] | None = None,
) -> tuple[np.ndarray, int, np.ndarray]:
    """Fit absolute normalized coefficients under ordinary-X constraints.

    There are at most six coefficients, so a deterministic active-set search is
    both fast and substantially more reliable than optimizing in the extremely
    ill-conditioned raw coefficient coordinates. Each bounded coefficient is
    considered free, fixed at its lower bound, or fixed at its upper bound.

    The optimization variable is ``gamma = beta + y_reference * e_constant``.
    Thus ``raw = transform @ gamma`` has no observation-dependent offset. This
    is essential when all raw parameters are fixed: the resulting polynomial
    must depend only on X and those parameters, never on the observed Y values.
    """

    if cancel_check is not None and cancel_check():
        raise _FitCancelled
    transform = basis.internal_to_raw_matrix()
    reference = np.zeros(len(initial), dtype=float)
    reference[-1] = basis.y_reference
    with np.errstate(over="ignore", invalid="ignore"):
        centered_y = y - basis.y_reference
    if not np.all(np.isfinite(centered_y)):
        raise _FitInputError(
            "The polynomial residual exceeds the supported numeric range."
        )
    fixed_rows = tuple(int(index) for index in np.flatnonzero(fixed))
    bounded_rows = tuple(
        int(index)
        for index in np.flatnonzero(
            ~fixed & (np.isfinite(lower) | np.isfinite(upper))
        )
    )
    choices: list[tuple[tuple[int, float] | None, ...]] = []
    for index in bounded_rows:
        options: list[tuple[int, float] | None] = [None]
        if math.isfinite(float(lower[index])):
            options.append((index, float(lower[index])))
        if math.isfinite(float(upper[index])):
            options.append((index, float(upper[index])))
        choices.append(tuple(options))

    best_internal: np.ndarray | None = None
    best_residual_norm = math.inf
    best_active_bound_values = np.full(len(initial), np.nan, dtype=float)
    best_active_bound_count = -1
    evaluations = 0
    for selected_bounds in product(*choices) if choices else ((),):
        if cancel_check is not None and cancel_check():
            raise _FitCancelled
        active = [(index, float(initial[index])) for index in fixed_rows]
        active.extend(
            selected for selected in selected_bounds if selected is not None
        )
        if any(
            not _raw_constraint_row_is_reliable(transform[index], index)
            for index, _required in active
        ):
            continue
        if active:
            active_rows = np.asarray([item[0] for item in active], dtype=int)
            active_values = np.asarray([item[1] for item in active], dtype=float)
            active_transform = transform[active_rows]
            active_rhs = active_values
            row_scales = np.max(np.abs(active_transform), axis=1)
            if np.any(row_scales == 0.0) or not np.all(np.isfinite(row_scales)):
                continue
            scaled_transform = active_transform / row_scales[:, None]
            scaled_rhs = active_rhs / row_scales
            try:
                _u, singular_values, right_transpose = np.linalg.svd(
                    scaled_transform,
                    full_matrices=True,
                )
            except np.linalg.LinAlgError:
                continue
            tolerance = (
                np.finfo(float).eps
                * max(scaled_transform.shape)
                * float(singular_values[0])
            )
            rank = int(np.count_nonzero(singular_values > tolerance))
            if rank != len(active):
                continue
            particular = np.asarray(
                np.linalg.lstsq(scaled_transform, scaled_rhs, rcond=None)[0],
                dtype=float,
            )
            null_basis = np.asarray(right_transpose[rank:].T, dtype=float)
        else:
            particular = np.zeros(len(initial), dtype=float)
            null_basis = np.eye(len(initial), dtype=float)

        if null_basis.shape[1]:
            # Reparameterize around the observed Y reference when that direction
            # is available. This keeps the least-squares right-hand side small,
            # while ``particular`` and the raw constraints remain independent of Y.
            anchor = particular + null_basis @ (
                null_basis.T @ (reference - particular)
            )
            reduced_matrix = matrix @ null_basis
            if np.linalg.matrix_rank(reduced_matrix) < null_basis.shape[1]:
                continue
            reduced_target = centered_y - matrix @ (anchor - reference)
            reduced = np.linalg.lstsq(
                reduced_matrix,
                reduced_target,
                rcond=None,
            )[0]
            absolute_internal = anchor + null_basis @ reduced
        else:
            absolute_internal = particular
        if not np.all(np.isfinite(absolute_internal)):
            continue
        if active:
            # SVD null-space vectors satisfy the active equalities only to
            # floating precision. Project the final candidate back onto those
            # equalities before the strict raw-coefficient verification below.
            for _iteration in range(2):
                correction = np.linalg.lstsq(
                    scaled_transform,
                    scaled_rhs - scaled_transform @ absolute_internal,
                    rcond=None,
                )[0]
                absolute_internal = absolute_internal + correction
            if not np.all(np.isfinite(absolute_internal)):
                continue
            scaled_equality_residual = (
                scaled_transform @ absolute_internal - scaled_rhs
            )
            equality_scale = max(
                float(np.max(np.abs(absolute_internal))),
                float(np.max(np.abs(scaled_rhs))),
            )
            scaled_equality_tolerance = (
                1024.0
                * np.finfo(float).eps
                * max(scaled_transform.shape)
                * equality_scale
            )
            if np.any(
                np.abs(scaled_equality_residual) > scaled_equality_tolerance
            ):
                continue
        try:
            raw = basis.absolute_internal_to_raw(absolute_internal)
        except _FitInputError:
            continue

        selected_bound_indexes = {
            selected[0] for selected in selected_bounds if selected is not None
        }
        feasible = True
        for index, value in enumerate(raw):
            if fixed[index] or index in selected_bound_indexes:
                continue
            lower_value = float(lower[index])
            upper_value = float(upper[index])
            if not math.isfinite(lower_value) and not math.isfinite(upper_value):
                continue
            backward_error = _raw_transform_backward_error(
                transform[index],
                absolute_internal,
            )
            if backward_error is None:
                feasible = False
                break
            if math.isfinite(lower_value) and value - backward_error < lower_value:
                feasible = False
                break
            if math.isfinite(upper_value) and value + backward_error > upper_value:
                feasible = False
                break
        if not feasible:
            continue
        for active_position, (index, required) in enumerate(active):
            actual = float(raw[index])
            if fixed[index]:
                validation_lower = required
                validation_upper = required
            else:
                validation_lower = float(lower[index])
                validation_upper = float(upper[index])
            equality_tolerance = max(
                _transformed_coefficient_tolerance(
                    transform[index],
                    absolute_internal,
                    actual,
                    required,
                    validation_lower,
                    validation_upper,
                ),
                scaled_equality_tolerance * float(row_scales[active_position]),
            )
            if abs(actual - required) > equality_tolerance:
                feasible = False
                break
        if not feasible:
            continue

        evaluations += 1
        try:
            beta = absolute_internal - reference
            residual = matrix @ beta - centered_y
            residual_norm, _sse = _stable_norm(
                residual,
                "Constrained polynomial residual",
            )
        except _FitInputError:
            continue
        active_bound_values = np.full(len(initial), np.nan, dtype=float)
        for selected in selected_bounds:
            if selected is not None:
                active_bound_values[selected[0]] = selected[1]
        active_bound_count = int(np.count_nonzero(np.isfinite(active_bound_values)))
        numeric_objective_tolerance = 1024.0 * max(
            math.ulp(residual_norm),
            math.ulp(best_residual_norm)
            if math.isfinite(best_residual_norm)
            else 0.0,
        )
        centered_fitted = matrix @ beta
        numeric_objective_tolerance = max(
            numeric_objective_tolerance,
            4.0
            * np.finfo(float).eps
            * math.sqrt(len(centered_y))
            * max(
                float(np.max(np.abs(centered_y))) if centered_y.size else 0.0,
                float(np.max(np.abs(centered_fitted)))
                if centered_fitted.size
                else 0.0,
            ),
        )
        is_better = residual_norm < best_residual_norm - numeric_objective_tolerance
        is_numeric_tie = (
            math.isfinite(best_residual_norm)
            and abs(residual_norm - best_residual_norm)
            <= numeric_objective_tolerance
        )
        if is_better or (
            is_numeric_tie and active_bound_count > best_active_bound_count
        ):
            best_internal = np.asarray(absolute_internal, dtype=float)
            best_residual_norm = residual_norm
            best_active_bound_values = active_bound_values
            best_active_bound_count = active_bound_count

    if best_internal is None:
        raise _FitInputError(
            "The ordinary-X parameter constraints are too ill-conditioned "
            "at this X scale. Shift the X values closer to zero or relax the constraints."
        )
    return best_internal, max(1, evaluations), best_active_bound_values


def _raw_polynomial_condition_warning(
    basis: _CenteredPolynomialBasis,
    x: np.ndarray,
    internal: np.ndarray,
    *,
    absolute: bool = False,
) -> str | None:
    """Warn when rounded raw coefficients cannot reproduce the stable curve."""

    try:
        matrix = basis.matrix(x)
        if absolute:
            raw = basis.absolute_internal_to_raw(internal)
            reconstructed = basis.raw_to_absolute_internal(raw)
            fitted = matrix @ internal
        else:
            raw = basis.internal_to_raw(internal)
            reconstructed = basis.raw_to_internal(raw)
            fitted = basis.y_reference + matrix @ internal
        with np.errstate(over="ignore", invalid="ignore"):
            round_trip_difference = matrix @ (reconstructed - internal)
            raw_equation_difference = np.polyval(raw, x) - fitted
    except _FitInputError:
        return (
            "The ordinary-X polynomial coefficients are numerically ill-conditioned "
            "at this X scale; the fitted curve still uses a stable internal basis."
        )
    tolerance = 1e-8 * max(
        1.0,
        float(np.max(np.abs(fitted))) if fitted.size else 0.0,
    )
    if (
        not np.all(np.isfinite(round_trip_difference))
        or not np.all(np.isfinite(raw_equation_difference))
        or (
            round_trip_difference.size
            and float(np.max(np.abs(round_trip_difference))) > tolerance
        )
        or (
            raw_equation_difference.size
            and float(np.max(np.abs(raw_equation_difference))) > tolerance
        )
    ):
        return (
            "The ordinary-X polynomial coefficients are numerically ill-conditioned "
            "at this X scale. The displayed curve remains stable, but substituting "
            "rounded coefficients into the equation may lose accuracy."
        )
    return None


def fit_xy_values(
    x: Sequence[float] | np.ndarray,
    y: Sequence[float] | np.ndarray,
    spec: XYFitSpec,
    *,
    curve_points: int = 400,
    cancel_check: Callable[[], bool] | None = None,
) -> XYFitResult:
    """Fit one XY series, returning a result for both success and failure."""

    if not spec.enabled:
        return _failure_result(
            spec,
            "This fit is disabled.",
            status="disabled",
        )

    direct_log_base_names: frozenset[str] = frozenset()
    try:
        if cancel_check is not None and cancel_check():
            raise _FitCancelled
        if (
            isinstance(curve_points, bool)
            or not isinstance(curve_points, (int, np.integer))
            or not 2 <= int(curve_points) <= 10_000
        ):
            raise _FitInputError(
                "Curve point count must be a whole number between 2 and 10,000."
            )
        x_values = _numeric_vector(x, "X")
        y_values = _numeric_vector(y, "Y")
        if x_values.size != y_values.size:
            raise _FitInputError("X and Y must contain the same number of values.")
        if x_values.size == 0:
            raise _FitInputError("There are no data points to fit.")

        (
            names,
            automatic,
            default_bounds,
            evaluator,
            equation,
            centered_basis,
        ) = _model_components(spec, x_values, y_values)
        if spec.model_id == "custom":
            direct_log_base_names = frozenset(
                parse_custom_expression(spec.expression).log_base_parameter_names
            )
        parameter_specs = _resolved_parameter_specs(
            names,
            automatic,
            default_bounds,
            spec.parameters,
        )
        initial, lower, upper, fixed = _validated_parameter_arrays(parameter_specs)
        free_indexes = np.flatnonzero(~fixed)
        free_count = len(free_indexes)
        if x_values.size < free_count:
            raise _FitInputError(
                f"Not enough data points: this model has {free_count} free parameters "
                f"but only {x_values.size} points."
            )
        # Linear/polynomial models are solved directly in their stable internal
        # basis, so an automatic raw coefficient suggestion never needs to be
        # expanded back into that basis before the solve. User-supplied fixed
        # values and bounds are validated by the constrained branch below.
        if centered_basis is None:
            initial_prediction = _evaluated_values(evaluator, x_values, initial)
            if not np.all(np.isfinite(initial_prediction)):
                raise _FitInputError(
                    "The equation is undefined at the current initial values. "
                    "Check function domains or numeric overflow, trigonometric "
                    "singularities, divisions, and parameter bounds. "
                    "Trigonometric angles use radians."
                )
        if cancel_check is not None and cancel_check():
            raise _FitCancelled
    except _FitCancelled:
        return _failure_result(
            spec,
            "The fit was cancelled.",
            status="cancelled",
        )
    except _FitInputError as exc:
        observation_count = len(x) if hasattr(x, "__len__") else 0
        return _failure_result(
            spec,
            str(exc),
            observation_count=observation_count,
        )
    except Exception as exc:
        return _failure_result(spec, f"The fit input could not be prepared: {exc}")

    warnings: list[str] = []
    equation_display_reliable = True
    estimates = initial.copy()
    function_evaluations = 0
    jacobian = np.empty((len(x_values), free_count), dtype=float)
    uncertainty_transform: np.ndarray | None = None
    optimizer_at_bound = np.zeros(len(estimates), dtype=bool)
    fitted_internal: np.ndarray | None = None
    fitted_absolute_internal: np.ndarray | None = None
    stable_polynomial_residual: np.ndarray | None = None
    active_bound_values = np.full(len(estimates), np.nan, dtype=float)
    centered_constraints_used = False

    def values_with_free(free_values: np.ndarray) -> np.ndarray:
        values = initial.copy()
        values[free_indexes] = free_values
        return values

    def coefficient_tolerance(
        index: int,
        value: float,
        reference: float,
        lower_value: float,
        upper_value: float,
    ) -> float:
        if (
            centered_constraints_used
            and centered_basis is not None
            and fitted_absolute_internal is not None
        ):
            return _transformed_coefficient_tolerance(
                centered_basis.internal_to_raw_matrix()[index],
                fitted_absolute_internal,
                value,
                reference,
                lower_value,
                upper_value,
            )
        return _coefficient_tolerance(
            value,
            reference,
            lower_value,
            upper_value,
        )

    try:
        if cancel_check is not None and cancel_check():
            raise _FitCancelled
        if free_count == 0:
            if centered_basis is None:
                prediction = _evaluated_values(evaluator, x_values, estimates)
            else:
                fixed_matrix = centered_basis.matrix(x_values)
                (
                    fitted_absolute_internal,
                    function_evaluations,
                    active_bound_values,
                ) = _constrained_polynomial_fit(
                    centered_basis,
                    fixed_matrix,
                    y_values,
                    estimates,
                    lower,
                    upper,
                    fixed,
                    cancel_check=cancel_check,
                )
                prediction = centered_basis.evaluate_absolute_internal(
                    x_values,
                    fitted_absolute_internal,
                )
                stable_polynomial_residual = (
                    centered_basis.residual_absolute_internal(
                        x_values,
                        y_values,
                        fitted_absolute_internal,
                    )
                )
            jacobian = np.empty((len(x_values), 0), dtype=float)
        elif centered_basis is not None:
            matrix = centered_basis.matrix(x_values)
            with np.errstate(over="ignore", invalid="ignore"):
                target = y_values - centered_basis.y_reference
            if not np.all(np.isfinite(target)):
                raise _FitInputError(
                    "The polynomial residual exceeds the supported numeric range."
                )
            has_raw_constraints = bool(
                np.any(fixed)
                or np.any(np.isfinite(lower))
                or np.any(np.isfinite(upper))
            )
            if not has_raw_constraints:
                if np.linalg.matrix_rank(matrix) < len(names):
                    raise _FitInputError(
                        "The polynomial parameters cannot be determined uniquely from these X values."
                    )
                fitted_internal = np.asarray(
                    np.linalg.lstsq(matrix, target, rcond=None)[0],
                    dtype=float,
                )
                function_evaluations = 1
                jacobian = matrix
                uncertainty_transform = centered_basis.internal_to_raw_matrix()
            else:
                (
                    fitted_absolute_internal,
                    function_evaluations,
                    active_bound_values,
                ) = _constrained_polynomial_fit(
                    centered_basis,
                    matrix,
                    y_values,
                    initial,
                    lower,
                    upper,
                    fixed,
                    cancel_check=cancel_check,
                )
                centered_constraints_used = True
                jacobian = np.empty((len(x_values), free_count), dtype=float)
            if fitted_absolute_internal is not None:
                estimates = centered_basis.absolute_internal_to_raw(
                    fitted_absolute_internal
                )
            else:
                estimates = centered_basis.internal_to_raw(fitted_internal)
            if centered_constraints_used:
                for index in free_indexes:
                    if math.isfinite(float(active_bound_values[index])):
                        estimates[index] = active_bound_values[index]
                        optimizer_at_bound[index] = True
            estimates[fixed] = initial[fixed]
            if fitted_absolute_internal is not None:
                prediction = centered_basis.evaluate_absolute_internal(
                    x_values,
                    fitted_absolute_internal,
                )
                stable_polynomial_residual = (
                    centered_basis.residual_absolute_internal(
                        x_values,
                        y_values,
                        fitted_absolute_internal,
                    )
                )
            else:
                prediction = centered_basis.evaluate_internal(x_values, fitted_internal)
        else:
            # Deliberately lazy: project loading and app startup do not need SciPy.
            from scipy.optimize import least_squares

            lower_free = lower[free_indexes]
            upper_free = upper[free_indexes]
            raw_starting_points = [
                np.asarray(initial[free_indexes], dtype=float)
            ]
            log_base_free_positions = tuple(
                free_position
                for free_position, parameter_index in enumerate(free_indexes)
                if names[parameter_index] in direct_log_base_names
            )
            for free_position, parameter_index in enumerate(free_indexes):
                if names[parameter_index] not in direct_log_base_names:
                    continue
                current_base = float(initial[parameter_index])
                alternate_base = _opposite_log_base_seed(
                    current_base,
                    float(lower_free[free_position]),
                    float(upper_free[free_position]),
                )
                if alternate_base is None:
                    continue
                if len(raw_starting_points) * 2 > _MAX_LOG_BASE_STARTS:
                    warnings.append(
                        "Only the first logarithm-base branches were searched; "
                        "set initial values for additional base parameters if needed."
                    )
                    break
                alternate_points: list[np.ndarray] = []
                for starting_point in raw_starting_points:
                    alternate = starting_point.copy()
                    alternate[free_position] = alternate_base
                    alternate_points.append(alternate)
                raw_starting_points.extend(alternate_points)

            def optimizer_to_raw_free(
                optimizer_values: np.ndarray,
            ) -> np.ndarray:
                raw_values = np.asarray(optimizer_values, dtype=float).copy()
                for free_position in log_base_free_positions:
                    raw_values[free_position] = math.exp(
                        float(raw_values[free_position])
                    )
                return raw_values

            optimizer_starts: list[
                tuple[np.ndarray, np.ndarray, np.ndarray]
            ] = []
            for raw_starting_point in raw_starting_points:
                optimizer_start = raw_starting_point.copy()
                optimizer_lower = np.asarray(lower_free, dtype=float).copy()
                optimizer_upper = np.asarray(upper_free, dtype=float).copy()
                valid_branch = True
                for free_position in log_base_free_positions:
                    branch_bounds = _log_base_optimizer_bounds(
                        float(raw_starting_point[free_position]),
                        float(lower_free[free_position]),
                        float(upper_free[free_position]),
                    )
                    if branch_bounds is None:
                        valid_branch = False
                        break
                    optimizer_lower[free_position], optimizer_upper[free_position] = (
                        branch_bounds
                    )
                    optimizer_start[free_position] = math.log(
                        float(raw_starting_point[free_position])
                    )
                    optimizer_start[free_position] = min(
                        max(
                            optimizer_start[free_position],
                            optimizer_lower[free_position],
                        ),
                        optimizer_upper[free_position],
                    )
                if valid_branch:
                    optimizer_starts.append(
                        (optimizer_start, optimizer_lower, optimizer_upper)
                    )

            def residuals(optimizer_values: np.ndarray) -> np.ndarray:
                if cancel_check is not None and cancel_check():
                    raise _FitCancelled
                predicted = _evaluated_values(
                    evaluator,
                    x_values,
                    values_with_free(
                        optimizer_to_raw_free(optimizer_values)
                    ),
                )
                residual = predicted - y_values
                if not np.all(np.isfinite(residual)):
                    return np.nan_to_num(
                        residual,
                        nan=1e20,
                        posinf=1e20,
                        neginf=-1e20,
                    )
                return residual

            best_optimized = None
            best_prediction = None
            best_raw_free = None
            best_residual_norm = math.inf
            for starting_point, optimizer_lower, optimizer_upper in optimizer_starts:
                if cancel_check is not None and cancel_check():
                    raise _FitCancelled
                try:
                    with python_warnings.catch_warnings():
                        python_warnings.simplefilter("ignore", RuntimeWarning)
                        optimized = least_squares(
                            residuals,
                            starting_point,
                            bounds=(optimizer_lower, optimizer_upper),
                            method="trf",
                            x_scale="jac",
                            max_nfev=5_000,
                        )
                except _FitCancelled:
                    raise
                except (
                    ArithmeticError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                    np.linalg.LinAlgError,
                ):
                    continue
                function_evaluations += int(optimized.nfev)
                if not optimized.success or not np.all(np.isfinite(optimized.x)):
                    continue
                try:
                    candidate_raw_free = optimizer_to_raw_free(
                        np.asarray(optimized.x, dtype=float)
                    )
                    candidate_estimates = values_with_free(candidate_raw_free)
                    candidate_prediction = _evaluated_values(
                        evaluator,
                        x_values,
                        candidate_estimates,
                    )
                    if not np.all(np.isfinite(candidate_prediction)):
                        continue
                    candidate_residual_norm, _candidate_sse = _stable_norm(
                        candidate_prediction - y_values,
                        "Residual",
                    )
                except (
                    ArithmeticError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                    np.linalg.LinAlgError,
                ):
                    continue
                if candidate_residual_norm < best_residual_norm:
                    best_optimized = optimized
                    best_prediction = candidate_prediction
                    best_raw_free = candidate_raw_free
                    best_residual_norm = candidate_residual_norm
                    if np.array_equal(candidate_prediction, y_values):
                        break
            if (
                best_optimized is None
                or best_prediction is None
                or best_raw_free is None
            ):
                return _failure_result(
                    spec,
                    "The optimizer stopped before finding a solution. "
                    "Try different initial values or wider bounds.",
                    observation_count=len(x_values),
                )
            estimates = values_with_free(best_raw_free)
            prediction = best_prediction
            jacobian = np.asarray(best_optimized.jac, dtype=float)
            if log_base_free_positions:
                uncertainty_transform = np.eye(free_count, dtype=float)
                for free_position in log_base_free_positions:
                    parameter_index = int(free_indexes[free_position])
                    uncertainty_transform[free_position, free_position] = estimates[
                        parameter_index
                    ]
            optimizer_at_bound[free_indexes] = (
                np.asarray(best_optimized.active_mask, dtype=int) != 0
            )
        if cancel_check is not None and cancel_check():
            raise _FitCancelled
    except _FitCancelled:
        return _failure_result(
            spec,
            "The fit was cancelled.",
            status="cancelled",
            observation_count=len(x_values),
        )
    except _FitInputError as exc:
        return _failure_result(
            spec,
            str(exc),
            observation_count=len(x_values),
        )
    except Exception:
        return _failure_result(
            spec,
            "The optimizer could not complete this fit. Try different initial values or bounds.",
            observation_count=len(x_values),
        )

    if not np.all(np.isfinite(estimates)) or not np.all(np.isfinite(prediction)):
        return _failure_result(
            spec,
            "The fitted equation produced non-finite values. Try different bounds.",
            observation_count=len(x_values),
        )

    try:
        if stable_polynomial_residual is not None:
            residual = stable_polynomial_residual
        else:
            with np.errstate(over="ignore", invalid="ignore"):
                residual = prediction - y_values
        residual_norm, sse = _stable_norm(residual, "Residual")
        rmse = float(residual_norm / math.sqrt(len(x_values)))
        if not math.isfinite(rmse) or (rmse == 0.0 and residual_norm != 0.0):
            raise _FitInputError("RMSE is outside the supported numeric range.")
        degrees_of_freedom = len(x_values) - free_count
        if np.all(y_values == y_values[0]):
            r_squared = None
            adjusted_r_squared = None
            warnings.append("R-squared is undefined because all Y values are equal.")
        else:
            centered_y = _stable_centered_y(y_values)
            total_norm, _total_sum_squares = _stable_norm(
                centered_y,
                "Total Y variation",
            )
            if total_norm == 0.0:
                raise _FitInputError(
                    "Total Y variation is outside the supported numeric range."
                )
            residual_ratio = float(residual_norm / total_norm)
            with np.errstate(over="ignore", invalid="ignore"):
                unexplained_ratio = float(residual_ratio * residual_ratio)
                r_squared = float(1.0 - unexplained_ratio)
            if not math.isfinite(residual_ratio) or not math.isfinite(r_squared):
                raise _FitInputError("R-squared exceeds the supported numeric range.")
            adjusted_r_squared = (
                float(
                    1.0
                    - unexplained_ratio
                    * (len(x_values) - 1)
                    / (len(x_values) - free_count)
                )
                if len(x_values) > free_count
                else None
            )
            if adjusted_r_squared is not None and not math.isfinite(
                adjusted_r_squared
            ):
                raise _FitInputError(
                    "Adjusted R-squared exceeds the supported numeric range."
                )
            if adjusted_r_squared is None:
                warnings.append(
                    "Adjusted R-squared needs at least one more point than the model currently has."
                )
    except _FitInputError as exc:
        return _failure_result(
            spec,
            str(exc),
            observation_count=len(x_values),
        )

    if cancel_check is not None and cancel_check():
        return _failure_result(
            spec,
            "The fit was cancelled.",
            status="cancelled",
            observation_count=len(x_values),
        )
    if centered_constraints_used and free_count:
        standard_errors = [None] * len(estimates)
        intervals = [None] * len(estimates)
        warnings.append(
            "Parameter uncertainty is unavailable for a polynomial fit with "
            "ordinary-X bounds or fixed coefficients."
        )
    else:
        standard_errors, intervals = _parameter_uncertainty(
            estimates,
            fixed,
            jacobian,
            sse,
            degrees_of_freedom,
            warnings,
            uncertainty_transform,
        )
    if cancel_check is not None and cancel_check():
        return _failure_result(
            spec,
            "The fit was cancelled.",
            status="cancelled",
            observation_count=len(x_values),
        )

    at_bound = [bool(value) for value in optimizer_at_bound]
    for index in free_indexes:
        if centered_constraints_used:
            if at_bound[index]:
                continue
            estimate = float(estimates[index])
            lower_value = float(lower[index])
            upper_value = float(upper[index])
            if math.isfinite(lower_value):
                lower_tolerance = coefficient_tolerance(
                    int(index),
                    estimate,
                    lower_value,
                    lower_value,
                    upper_value,
                )
                if math.isfinite(upper_value) and upper_value > lower_value:
                    lower_tolerance = min(
                        lower_tolerance,
                        1e-6 * (upper_value - lower_value),
                    )
                if abs(estimate - lower_value) <= lower_tolerance:
                    estimates[index] = lower_value
                    at_bound[index] = True
                    continue
            if math.isfinite(upper_value):
                upper_tolerance = coefficient_tolerance(
                    int(index),
                    estimate,
                    upper_value,
                    lower_value,
                    upper_value,
                )
                if math.isfinite(lower_value) and upper_value > lower_value:
                    upper_tolerance = min(
                        upper_tolerance,
                        1e-6 * (upper_value - lower_value),
                    )
                if abs(estimate - upper_value) <= upper_tolerance:
                    estimates[index] = upper_value
                    at_bound[index] = True
            continue
        estimate = float(estimates[index])
        lower_value = float(lower[index])
        upper_value = float(upper[index])
        at_lower = math.isfinite(lower_value) and abs(estimate - lower_value) <= (
            coefficient_tolerance(
                int(index),
                estimate,
                lower_value,
                lower_value,
                upper_value,
            )
        )
        at_upper = math.isfinite(upper_value) and abs(estimate - upper_value) <= (
            coefficient_tolerance(
                int(index),
                estimate,
                upper_value,
                lower_value,
                upper_value,
            )
        )
        at_bound[index] = at_bound[index] or at_lower or at_upper
    if any(at_bound):
        bounded_names = ", ".join(
            names[index] for index, bounded in enumerate(at_bound) if bounded
        )
        for index, bounded in enumerate(at_bound):
            if bounded:
                standard_errors[index] = None
                intervals[index] = None
        warnings.append(
            f"The fitted value for {bounded_names} reached a parameter bound; "
            "its symmetric confidence interval is unavailable."
        )

    parameter_estimates = tuple(
        FitParameterEstimate(
            name=name,
            value=float(estimates[index]),
            standard_error=standard_errors[index],
            confidence_interval=intervals[index],
            fixed=bool(fixed[index]),
            at_bound=at_bound[index],
        )
        for index, name in enumerate(names)
    )

    try:
        minimum_x = float(np.min(x_values))
        maximum_x = float(np.max(x_values))
        if minimum_x == maximum_x:
            curve_x_values = np.asarray([minimum_x], dtype=float)
        else:
            fractions = np.linspace(0.0, 1.0, int(curve_points))
            with np.errstate(over="ignore", invalid="ignore"):
                curve_x_values = (
                    minimum_x * (1.0 - fractions) + maximum_x * fractions
                )
            curve_x_values[0] = minimum_x
            curve_x_values[-1] = maximum_x
            if not np.all(np.isfinite(curve_x_values)):
                raise _FitInputError(
                    "The X range is too large to generate a finite fitted curve."
                )
        if centered_basis is not None and (
            fitted_internal is not None or fitted_absolute_internal is not None
        ):
            if fitted_absolute_internal is not None:
                curve_y_values = centered_basis.evaluate_absolute_internal(
                    curve_x_values,
                    fitted_absolute_internal,
                )
                condition_parameters = fitted_absolute_internal
                condition_parameters_are_absolute = True
            else:
                curve_y_values = centered_basis.evaluate_internal(
                    curve_x_values,
                    fitted_internal,
                )
                condition_parameters = fitted_internal
                condition_parameters_are_absolute = False
            condition_warning = _raw_polynomial_condition_warning(
                centered_basis,
                curve_x_values,
                condition_parameters,
                absolute=condition_parameters_are_absolute,
            )
            if condition_warning is not None:
                warnings.append(condition_warning)
                equation_display_reliable = False
        else:
            curve_y_values = _evaluated_values(evaluator, curve_x_values, estimates)
    except _FitInputError as exc:
        return _failure_result(
            spec,
            str(exc),
            observation_count=len(x_values),
        )
    except Exception:
        return _failure_result(
            spec,
            "The fitted curve could not be generated across the current X range.",
            observation_count=len(x_values),
        )
    if not np.all(np.isfinite(curve_y_values)):
        curve_y_values = np.where(np.isfinite(curve_y_values), curve_y_values, np.nan)
        warnings.append(
            "The fitted curve is undefined across part of the displayed X range."
        )

    status = "warning" if warnings else "success"
    message = (
        "Fit completed with warnings."
        if warnings
        else "Fit completed successfully."
    )
    if free_count == 0:
        message = "The model was evaluated with all parameters fixed."
    return XYFitResult(
        fit_id=spec.id,
        series_id=spec.series_id,
        model_id=spec.model_id,
        success=True,
        status=status,
        message=message,
        warnings=tuple(warnings),
        equation_display_reliable=equation_display_reliable,
        equation=equation,
        x_origin=(centered_basis.x_origin if centered_basis is not None else None),
        parameter_estimates=parameter_estimates,
        observation_count=len(x_values),
        free_parameter_count=free_count,
        degrees_of_freedom=degrees_of_freedom,
        sse=sse,
        rmse=rmse,
        r_squared=r_squared,
        adjusted_r_squared=adjusted_r_squared,
        curve_x=tuple(float(value) for value in curve_x_values),
        curve_y=tuple(float(value) for value in curve_y_values),
        function_evaluations=function_evaluations,
    )
