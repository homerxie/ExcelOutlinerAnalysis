from __future__ import annotations

import pandas as pd

from easygraph.data_table import DataTable


def table_cell_text(table: DataTable, row: int, col: int) -> str:
    return table.table_model.cell_text(row, col)


def table_group_name(table: DataTable, col: int, fallback_prefix: str = "Group") -> str:
    name = table_cell_text(table, 0, col).strip()
    return name or f"{fallback_prefix} {col + 1}"


def table_group_names(table: DataTable, fallback_prefix: str = "Group") -> list[str]:
    return [
        table_group_name(table, col, fallback_prefix)
        for col in range(table.table_model.columnCount())
    ]


def table_sample_dataframe(
    table: DataTable,
    sample_start_row: int,
    fallback_prefix: str = "Group",
) -> pd.DataFrame:
    return table.table_model.sample_dataframe(sample_start_row, fallback_prefix)


def sample_start_row_for_overlay_count(overlay_count: int) -> int:
    return 1 + overlay_count


def _table_text(value) -> str:
    return "" if pd.isna(value) else str(value)


def populate_table_from_dataframe(table: DataTable, df: pd.DataFrame, overlay_series: list[dict]) -> int:
    return table.table_model.replace_from_dataframe(df, overlay_series)


def append_custom_overlay_series(series: list[dict]) -> list[dict]:
    updated = list(series)
    updated.append({"name": f"Overlay {len(updated) + 1}", "values": {}})
    return updated


def remove_custom_overlay_series(series: list[dict], index: int) -> list[dict]:
    updated = list(series)
    if 0 <= index < len(updated):
        updated.pop(index)
    return updated


def overlay_row_for_removal(current_row: int, sample_start_row: int) -> int:
    if 0 < current_row < sample_start_row:
        return current_row
    return sample_start_row - 1


def overlay_row_name(header_text: str | None, row: int) -> str:
    name = header_text.strip() if header_text else ""
    return name or f"Overlay {row}"


def custom_overlay_state_from_series(series: list[dict]) -> tuple[int, bool]:
    return max(1, len(series)), bool(series)


def reindex_hidden_overlay_indexes(hidden_indexes: list[int], removed_index: int) -> list[int]:
    reindexed = []
    for hidden_index in hidden_indexes:
        if hidden_index == removed_index:
            continue
        reindexed.append(hidden_index - 1 if hidden_index > removed_index else hidden_index)
    return reindexed


def normalized_hidden_overlay_indexes(hidden_indexes: list[int], overlay_count: int) -> list[int]:
    hidden = {
        int(index)
        for index in hidden_indexes
        if isinstance(index, int) or str(index).lstrip("-").isdigit()
    }
    return sorted(index for index in hidden if 0 <= index < overlay_count)


def sync_group_order_state(
    columns: list[str],
    manual_group_order: list[str],
    group_hidden: list[str],
) -> tuple[list[str], list[str]]:
    existing = [group for group in manual_group_order if group in columns]
    existing.extend(group for group in columns if group not in existing)
    valid_columns = {str(column) for column in columns}
    hidden = [group for group in group_hidden if group in valid_columns]
    return existing, hidden


def rename_group_in_order(manual_group_order: list[str], old_name: str, new_name: str) -> list[str]:
    return [new_name if group == old_name else group for group in manual_group_order]


def row_header_labels(row_count: int, sample_start_row: int, overlay_series: list[dict]) -> list[str]:
    labels = [""]
    for row in range(1, sample_start_row):
        series_index = row - 1
        name = "Overlay"
        if series_index < len(overlay_series):
            name = str(overlay_series[series_index].get("name", "")).strip()
        labels.append(name or f"Overlay {series_index + 1}")
    sample_count = max(0, row_count - sample_start_row)
    labels.extend(str(index + 1) for index in range(sample_count))
    return labels


def column_header_labels(
    column_count: int,
    roles: tuple[str, ...] | list[str] | None = None,
) -> list[str]:
    labels = []
    for column in range(column_count):
        role = roles[column] if roles is not None and column < len(roles) else ""
        labels.append(f"{column + 1} · {role}" if role else str(column + 1))
    return labels


def custom_overlay_series_from_table(
    table: DataTable,
    sample_start_row: int,
    groups: list[str],
    fallback_series: list[dict],
) -> list[dict]:
    return table.table_model.overlay_series(sample_start_row, fallback_series, groups)
