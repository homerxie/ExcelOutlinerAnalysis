from __future__ import annotations

import json
import csv
from io import StringIO
import os
import tempfile
import zipfile
from dataclasses import asdict, fields
from pathlib import Path

import pandas as pd

from easygraph.analysis_results import AnalysisSettings
from easygraph.data import attach_group_metadata, migrate_group_settings
from easygraph.grouping import GroupingSettings, grouping_from_dict
from easygraph.settings import ChartSettings
from easygraph.workbook import (
    SHEET_ID_PATTERN,
    SHEET_MODE_GROUPS,
    SheetDocument,
    WorkbookDocument,
)
from easygraph.xy_fitting import FitParameterSpec, XYFitSpec
from easygraph.xy_series import (
    XYSeriesSpec,
    XYSharedTableSpec,
    XYSettings,
    ensure_xy_table_layout,
)

PROJECT_APP_NAME = "EasyGraph"
PROJECT_VERSION = 5
PROJECT_DATA_FILE = "data.csv"
PROJECT_SETTINGS_FILE = "settings.json"
PROJECT_MANIFEST_FILE = "project.json"
PROJECT_SHEETS_FILE = "sheets.json"
PROJECT_SHEETS_DIRECTORY = "sheets"
LEGACY_PROJECT_REQUIRED_FILES = (PROJECT_DATA_FILE, PROJECT_SETTINGS_FILE)
PROJECT_REQUIRED_FILES = (PROJECT_MANIFEST_FILE, PROJECT_SHEETS_FILE)

__all__ = [
    "PROJECT_APP_NAME",
    "PROJECT_DATA_FILE",
    "PROJECT_SHEETS_DIRECTORY",
    "PROJECT_SHEETS_FILE",
    "PROJECT_MANIFEST_FILE",
    "PROJECT_SETTINGS_FILE",
    "PROJECT_VERSION",
    "chart_settings_from_dict",
    "project_manifest",
    "project_path_with_suffix",
    "read_project",
    "read_workbook_project",
    "write_project",
    "xy_settings_from_dict",
]


def chart_settings_from_dict(data):
    if not isinstance(data, dict):
        raise ValueError("Chart settings must be a dictionary.")
    current_fields = {field.name for field in fields(ChartSettings)}
    unknown_fields = sorted(str(key) for key in data if key not in current_fields)
    if unknown_fields:
        raise ValueError("Unknown ChartSettings fields: " + ", ".join(unknown_fields))
    return ChartSettings(**data)


def _strict_dataclass_fields(data: object, dataclass_type: type, label: str) -> dict:
    if not isinstance(data, dict):
        raise ValueError(f"{label} must be a dictionary.")
    current_fields = {field.name for field in fields(dataclass_type)}
    unknown_fields = sorted(str(key) for key in data if key not in current_fields)
    if unknown_fields:
        raise ValueError(f"Unknown {label} fields: " + ", ".join(unknown_fields))
    return data


def xy_settings_from_dict(data: object, column_ids: list[str]) -> XYSettings:
    payload = _strict_dataclass_fields(data, XYSettings, "XYSettings")
    raw_series = payload.get("series", [])
    if not isinstance(raw_series, list):
        raise ValueError("XYSettings series must be a list.")
    series = []
    series_ids = set()
    for raw_spec in raw_series:
        spec_payload = _strict_dataclass_fields(raw_spec, XYSeriesSpec, "XYSeriesSpec")
        try:
            spec = XYSeriesSpec(**spec_payload)
        except TypeError as error:
            raise ValueError(f"Invalid XYSeriesSpec: {error}") from error
        if not isinstance(spec.id, str) or not SHEET_ID_PATTERN.fullmatch(spec.id):
            raise ValueError("XY series IDs may contain only letters, numbers, underscores, and hyphens.")
        if spec.id in series_ids:
            raise ValueError("XY series IDs must be unique.")
        series_ids.add(spec.id)
        series.append(spec)

    settings_payload = dict(payload)
    settings_payload["series"] = series
    raw_fit_specs = settings_payload.get("fit_specs", [])
    if not isinstance(raw_fit_specs, list):
        raise ValueError("XYSettings fit_specs must be a list.")
    fit_specs = []
    for raw_fit_spec in raw_fit_specs:
        fit_payload = dict(
            _strict_dataclass_fields(raw_fit_spec, XYFitSpec, "XYFitSpec")
        )
        raw_parameters = fit_payload.get("parameters", [])
        if not isinstance(raw_parameters, list):
            raise ValueError("XYFitSpec parameters must be a list.")
        parameters = []
        for raw_parameter in raw_parameters:
            parameter_payload = _strict_dataclass_fields(
                raw_parameter,
                FitParameterSpec,
                "FitParameterSpec",
            )
            try:
                parameters.append(FitParameterSpec(**parameter_payload))
            except TypeError as error:
                raise ValueError(f"Invalid FitParameterSpec: {error}") from error
        fit_payload["parameters"] = parameters
        annotation_parameter_names = fit_payload.get(
            "annotation_parameter_names",
            [],
        )
        if not isinstance(annotation_parameter_names, list) or any(
            not isinstance(name, str) or not name
            for name in annotation_parameter_names
        ):
            raise ValueError(
                "XYFitSpec annotation_parameter_names must be a list of non-empty strings."
            )
        fit_payload["annotation_parameter_names"] = list(
            annotation_parameter_names
        )
        try:
            fit_specs.append(XYFitSpec(**fit_payload))
        except TypeError as error:
            raise ValueError(f"Invalid XYFitSpec: {error}") from error
    settings_payload["fit_specs"] = fit_specs
    raw_shared_tables = settings_payload.get("shared_tables", [])
    if not isinstance(raw_shared_tables, list):
        raise ValueError("XYSettings shared_tables must be a list.")
    shared_tables = []
    for raw_table in raw_shared_tables:
        table_payload = _strict_dataclass_fields(
            raw_table,
            XYSharedTableSpec,
            "XYSharedTableSpec",
        )
        try:
            shared_tables.append(XYSharedTableSpec(**table_payload))
        except TypeError as error:
            raise ValueError(f"Invalid XYSharedTableSpec: {error}") from error
    settings_payload["shared_tables"] = shared_tables
    try:
        settings = XYSettings(**settings_payload)
    except TypeError as error:
        raise ValueError(f"Invalid XYSettings: {error}") from error
    if settings.chart_type != "Scatter":
        raise ValueError(f"Unsupported XY chart type: {settings.chart_type}")

    valid_column_ids = set(column_ids)
    referenced = []
    if settings.default_x_column_id is not None:
        referenced.append(settings.default_x_column_id)
    for spec in settings.series:
        if spec.x_column_id is not None:
            referenced.append(spec.x_column_id)
        referenced.append(spec.y_column_id)
    unknown_references = [column_id for column_id in referenced if column_id not in valid_column_ids]
    if unknown_references:
        raise ValueError(f"XY settings reference unknown column ID: {unknown_references[0]}")
    if settings.shared_tables or settings.paired_series_ids:
        ensure_xy_table_layout(settings, column_ids)
    return settings


def project_manifest(version: int = PROJECT_VERSION) -> dict[str, object]:
    return {"version": int(version), "app": PROJECT_APP_NAME}


def project_path_with_suffix(path: Path) -> Path:
    path = Path(path)
    return path if str(path).lower().endswith(".eg") else Path(f"{path}.eg")


def _validate_archive_members(archive: zipfile.ZipFile, required_files: tuple[str, ...]) -> None:
    members = set(archive.namelist())
    for required_file in required_files:
        if required_file not in members:
            raise ValueError(f"Project archive missing required file: {required_file}")


def _sheet_data_file(sheet_id: str) -> str:
    return f"{PROJECT_SHEETS_DIRECTORY}/{sheet_id}/{PROJECT_DATA_FILE}"


def _sheet_settings_file(sheet_id: str) -> str:
    return f"{PROJECT_SHEETS_DIRECTORY}/{sheet_id}/{PROJECT_SETTINGS_FILE}"


def _workbook_index(workbook: WorkbookDocument) -> dict[str, object]:
    return {
        "active_sheet_id": workbook.active_sheet_id,
        "sheets": [
            {
                "id": sheet.id,
                "name": sheet.name,
                "mode": sheet.mode,
                "analysis": asdict(sheet.analysis_settings),
            }
            for sheet in workbook.sheets
        ],
    }


def _analysis_settings_from_dict(data: object) -> AnalysisSettings:
    if data is None:
        return AnalysisSettings()
    if not isinstance(data, dict):
        raise ValueError("Analysis settings must be a dictionary.")
    unknown_fields = sorted(
        str(key) for key in data if key not in {"visible_statistics", "statistic_formats"}
    )
    if unknown_fields:
        raise ValueError(
            "Unknown AnalysisSettings fields: " + ", ".join(unknown_fields)
        )
    visible_statistics = data.get("visible_statistics")
    if visible_statistics is None:
        visible_statistics = AnalysisSettings().visible_statistics
    if not isinstance(visible_statistics, list):
        raise ValueError("visible_statistics must be a list.")
    return AnalysisSettings(
        visible_statistics=visible_statistics,
        statistic_formats=data.get("statistic_formats", {}),
    )


def _coerce_workbook(
    data: pd.DataFrame | WorkbookDocument,
    settings: ChartSettings | None,
) -> WorkbookDocument:
    if isinstance(data, WorkbookDocument):
        if settings is not None:
            raise TypeError("settings must be omitted when saving a WorkbookDocument.")
        return WorkbookDocument(list(data.sheets), data.active_sheet_id)
    if not isinstance(data, pd.DataFrame) or settings is None:
        raise TypeError("write_project expects a WorkbookDocument or a DataFrame with ChartSettings.")
    column_ids = data.attrs.get("group_column_ids", [])
    if not isinstance(column_ids, (list, tuple)):
        raise ValueError("Group column IDs must be a list of strings.")
    return WorkbookDocument.single(
        data, settings,
        column_ids=list(column_ids),
        grouping=grouping_from_dict(data.attrs.get("grouping"), list(column_ids)),
    )


def write_project(
    path: Path,
    data: pd.DataFrame | WorkbookDocument,
    settings: ChartSettings | None = None,
) -> None:
    path = project_path_with_suffix(path)
    workbook = _coerce_workbook(data, settings)
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        (tmp_path / PROJECT_MANIFEST_FILE).write_text(
            json.dumps(project_manifest(), indent=2),
            encoding="utf-8",
        )
        (tmp_path / PROJECT_SHEETS_FILE).write_text(
            json.dumps(_workbook_index(workbook), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        for sheet in workbook.sheets:
            sheet_path = tmp_path / PROJECT_SHEETS_DIRECTORY / sheet.id
            sheet_path.mkdir(parents=True)
            sheet.dataframe.to_csv(sheet_path / PROJECT_DATA_FILE, index=False)
            (sheet_path / PROJECT_SETTINGS_FILE).write_text(
                json.dumps(
                    {
                        "chart": asdict(sheet.settings),
                        "xy": asdict(sheet.xy_settings),
                        "column_ids": sheet.column_ids,
                        "grouping": asdict(sheet.grouping),
                    },
                    indent=2,
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
        temporary_file = tempfile.NamedTemporaryFile(
            prefix=f".{path.name}.",
            suffix=".tmp",
            dir=path.parent,
            delete=False,
        )
        temporary_path = Path(temporary_file.name)
        temporary_file.close()
        try:
            with zipfile.ZipFile(
                temporary_path,
                "w",
                compression=zipfile.ZIP_DEFLATED,
            ) as archive:
                for file in tmp_path.rglob("*"):
                    if file.is_file():
                        archive.write(
                            file,
                            arcname=file.relative_to(tmp_path).as_posix(),
                        )
            with temporary_path.open("r+b") as stream:
                os.fsync(stream.fileno())
            os.replace(temporary_path, path)
        except Exception:
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass
            raise


def _read_legacy_workbook(archive: zipfile.ZipFile) -> WorkbookDocument:
    _validate_archive_members(archive, LEGACY_PROJECT_REQUIRED_FILES)
    dataframe = _read_dataframe(archive, PROJECT_DATA_FILE)
    settings_data = json.loads(archive.read(PROJECT_SETTINGS_FILE).decode("utf-8"))
    return WorkbookDocument.single(dataframe, chart_settings_from_dict(settings_data))


def _read_dataframe(archive: zipfile.ZipFile, file_name: str) -> pd.DataFrame:
    text = archive.read(file_name).decode("utf-8-sig")
    try:
        header = next(csv.reader(StringIO(text)))
    except StopIteration:
        raise ValueError(f"Project data file is empty: {file_name}") from None
    dataframe = pd.read_csv(StringIO(text))
    if len(header) != len(dataframe.columns):
        raise ValueError(f"Project data header is invalid: {file_name}")
    dataframe.columns = header
    return dataframe


def _read_workbook_index(
    archive: zipfile.ZipFile,
    version: int,
) -> tuple[list[dict[str, object]], str | None]:
    raw_index = json.loads(archive.read(PROJECT_SHEETS_FILE).decode("utf-8"))
    if not isinstance(raw_index, dict) or not isinstance(raw_index.get("sheets"), list):
        raise ValueError("Project sheet index is invalid.")
    sheet_entries = []
    for entry in raw_index["sheets"]:
        if not isinstance(entry, dict):
            raise ValueError("Project sheet entry is invalid.")
        sheet_id = str(entry.get("id", "")).strip()
        name = str(entry.get("name", "")).strip()
        if not sheet_id or not name:
            raise ValueError("Project sheet entry must contain an ID and name.")
        if version >= 3 and "mode" not in entry:
            raise ValueError("Project sheet entry must contain a mode.")
        sheet_entries.append(
            {
                "id": sheet_id,
                "name": name,
                "mode": entry.get("mode", SHEET_MODE_GROUPS),
                "analysis_settings": _analysis_settings_from_dict(
                    entry.get("analysis")
                ),
            }
        )
    if not sheet_entries:
        raise ValueError("Project must contain at least one sheet.")
    active_sheet_id = raw_index.get("active_sheet_id")
    return sheet_entries, None if active_sheet_id is None else str(active_sheet_id)


def _read_current_workbook(archive: zipfile.ZipFile) -> WorkbookDocument:
    _validate_archive_members(archive, PROJECT_REQUIRED_FILES)
    manifest = json.loads(archive.read(PROJECT_MANIFEST_FILE).decode("utf-8"))
    if not isinstance(manifest, dict) or manifest.get("app") != PROJECT_APP_NAME:
        raise ValueError("Project manifest is invalid.")
    version = manifest.get("version")
    if version not in (2, 3, 4, PROJECT_VERSION):
        raise ValueError(f"Unsupported project version: {version}")
    entries, active_sheet_id = _read_workbook_index(archive, version)
    members = set(archive.namelist())
    sheets = []
    for entry in entries:
        data_file = _sheet_data_file(entry["id"])
        settings_file = _sheet_settings_file(entry["id"])
        for required_file in (data_file, settings_file):
            if required_file not in members:
                raise ValueError(f"Project archive missing required file: {required_file}")
        dataframe = _read_dataframe(archive, data_file)
        settings_data = json.loads(archive.read(settings_file).decode("utf-8"))
        if version == 2:
            chart_settings = chart_settings_from_dict(settings_data)
            column_ids = []
            xy_settings = XYSettings()
            grouping = GroupingSettings()
        else:
            if not isinstance(settings_data, dict):
                raise ValueError("Sheet settings must be a dictionary.")
            expected_keys = {"chart", "xy", "column_ids"}
            if version >= 5:
                expected_keys.add("grouping")
            actual_keys = set(settings_data)
            if actual_keys != expected_keys:
                missing = sorted(expected_keys - actual_keys)
                unknown = sorted(str(key) for key in actual_keys - expected_keys)
                details = []
                if missing:
                    details.append("missing: " + ", ".join(missing))
                if unknown:
                    details.append("unknown: " + ", ".join(unknown))
                raise ValueError("Sheet settings envelope is invalid (" + "; ".join(details) + ").")
            column_ids = settings_data["column_ids"]
            if not isinstance(column_ids, list) or any(
                not isinstance(column_id, str) for column_id in column_ids
            ):
                raise ValueError("column_ids must be a list of strings.")
            chart_settings = chart_settings_from_dict(settings_data["chart"])
            xy_settings = xy_settings_from_dict(settings_data["xy"], column_ids)
            grouping = grouping_from_dict(settings_data.get("grouping"), column_ids)
        sheets.append(
            SheetDocument(
                id=entry["id"],
                name=entry["name"],
                dataframe=dataframe,
                settings=chart_settings,
                analysis_settings=entry["analysis_settings"],
                mode=entry["mode"],
                column_ids=column_ids,
                xy_settings=xy_settings,
                grouping=grouping,
            )
        )
    return WorkbookDocument(sheets, active_sheet_id)


def read_workbook_project(path: Path) -> WorkbookDocument:
    with zipfile.ZipFile(path, "r") as archive:
        members = set(archive.namelist())
        if PROJECT_SHEETS_FILE in members:
            return _read_current_workbook(archive)
        if PROJECT_MANIFEST_FILE in members:
            manifest = json.loads(archive.read(PROJECT_MANIFEST_FILE).decode("utf-8"))
            if not isinstance(manifest, dict) or manifest.get("version") != 1:
                raise ValueError(f"Unsupported project version: {manifest.get('version') if isinstance(manifest, dict) else None}")
        return _read_legacy_workbook(archive)


def read_project(path: Path) -> tuple[pd.DataFrame, ChartSettings]:
    workbook = read_workbook_project(path)
    sheet = workbook.active_sheet
    dataframe = sheet.dataframe
    if sheet.mode == SHEET_MODE_GROUPS:
        dataframe = attach_group_metadata(dataframe, sheet.column_ids)
        dataframe.attrs["grouping"] = asdict(sheet.grouping)
        migrate_group_settings(sheet.settings, dataframe)
    return dataframe, sheet.settings
