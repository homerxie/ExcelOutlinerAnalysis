from __future__ import annotations

from easygraph.data_table import DataTable


def insert_sample_row(table: DataTable) -> int:
    row = table.table_model.rowCount()
    table.table_model.insertRows(row, 1)
    return row


def append_group_column(table: DataTable, fallback_prefix: str = "Group") -> int:
    col = table.table_model.columnCount()
    table.table_model.insertColumns(col, 1)
    table.table_model.set_cell_text(0, col, f"{fallback_prefix} {col + 1}")
    return col


def current_or_last_column(table: DataTable) -> int:
    col = table.currentIndex().column()
    if col < 0:
        col = table.table_model.columnCount() - 1
    return col


def remove_table_column(table: DataTable, col: int) -> bool:
    if col < 0 or col >= table.table_model.columnCount():
        return False
    return table.table_model.removeColumns(col, 1)


def remove_current_or_last_group_column(table: DataTable) -> bool:
    return remove_table_column(table, current_or_last_column(table))


def set_group_header(table: DataTable, col: int, name: str) -> None:
    table.table_model.set_cell_text(0, col, name.strip())
