from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from easygraph.numeric import coerce_numeric_series
from easygraph.settings import ChartSettings

__all__ = [
    "attach_group_metadata",
    "group_keys",
    "group_labels",
    "migrate_group_settings",
    "axis_labels_for_chart",
    "blank_project_data",
    "blank_xy_data",
    "box_whis",
    "hidden_group_names",
    "mark_outliers",
    "ordered_group_columns",
    "prepare_plot_data",
    "sample_data",
    "unique_groups",
    "values_for_group",
]


def sample_data() -> pd.DataFrame:
    rng = np.random.default_rng(7)
    columns = {}
    for group, center, spread in [
        ("Control", 4.8, 0.55),
        ("Low dose", 5.6, 0.65),
        ("High dose", 6.4, 0.7),
    ]:
        values = [round(float(v), 3) for v in rng.normal(center, spread, 34)]
        if group == "High dose":
            values.append(8.7)
        columns[group] = values
    return pd.DataFrame({name: pd.Series(values) for name, values in columns.items()})


def blank_project_data(rows: int = 12, columns: int = 3) -> pd.DataFrame:
    return pd.DataFrame(
        [["" for _ in range(columns)] for _ in range(rows)],
        columns=[f"Group {col + 1}" for col in range(columns)],
    )


def blank_xy_data(rows: int = 10, y_columns: int = 2) -> pd.DataFrame:
    columns = ["X", *(f"{index + 1}Y" for index in range(y_columns))]
    return pd.DataFrame(
        [["" for _ in columns] for _ in range(rows)],
        columns=columns,
    )


def attach_group_metadata(df: pd.DataFrame, column_ids: list[str]) -> pd.DataFrame:
    """Return a frame with stable per-column identities, without changing labels."""
    if (len(column_ids) != len(df.columns) or len(set(column_ids)) != len(column_ids)
            or any(not isinstance(key, str) or not key for key in column_ids)):
        raise ValueError("Group column IDs must be unique nonempty strings matching the columns.")
    result = df.copy(deep=False)
    result.attrs["group_column_ids"] = list(column_ids)
    return result


def group_keys(df: pd.DataFrame) -> list[str]:
    """One identity per physical column; repeated labels never pool values."""
    identities = df.attrs.get("group_column_ids")
    if (isinstance(identities, (list, tuple)) and len(identities) == len(df.columns)
            and all(isinstance(key, str) and key for key in identities)
            and len(set(identities)) == len(identities)):
        return list(identities)
    labels = [str(column) for column in df.columns]
    frequencies = Counter(labels)
    reserved = set(labels)
    counts: dict[str, int] = {}
    keys = []
    for label in labels:
        counts[label] = counts.get(label, 0) + 1
        if frequencies[label] == 1:
            key = label
        else:
            base = f"{label} [{counts[label]}]"
            key = base
            suffix = 2
            while key in reserved:
                key = f"{base} ({suffix})"
                suffix += 1
        reserved.add(key)
        keys.append(key)
    return keys


def group_labels(df: pd.DataFrame) -> dict[str, str]:
    return dict(zip(group_keys(df), map(str, df.columns)))


def _resolved_group_references(references, keys: list[str], labels: dict[str, str]) -> list[str]:
    resolved = []
    for reference in references:
        reference = str(reference)
        matches = [reference] if reference in keys else [key for key in keys if labels[key] == reference]
        resolved.extend(key for key in matches if key not in resolved)
    return resolved


def migrate_group_settings(settings: ChartSettings, df: pd.DataFrame) -> None:
    """Resolve legacy label-based settings into independent column identities."""
    keys, labels = group_keys(df), group_labels(df)
    settings.group_hidden = _resolved_group_references(settings.group_hidden, keys, labels)
    settings.manual_group_order = _resolved_group_references(settings.manual_group_order, keys, labels)
    settings.custom_colors = {
        key: settings.custom_colors[key] if key in settings.custom_colors else settings.custom_colors[labels[key]]
        for key in keys if key in settings.custom_colors or labels[key] in settings.custom_colors
    }
    for series in settings.custom_overlay_series:
        values = series.get("values", {})
        if isinstance(values, dict):
            series["values"] = {
                key: values[key] if key in values else values[labels[key]]
                for key in keys if key in values or labels[key] in values
            }


@dataclass(frozen=True)
class PreparedPlotFrames:
    full: pd.DataFrame
    visible: pd.DataFrame
    groups: tuple[str, ...]
    labels: dict[str, str] = field(default_factory=dict)


def prepare_plot_frames(df: pd.DataFrame, settings: ChartSettings) -> PreparedPlotFrames:
    columns, labels = group_keys(df), group_labels(df)
    values_by_group = {
        key: coerce_numeric_series(df.iloc[:, index]).dropna().to_numpy(dtype=float)
        for index, key in enumerate(columns)
    }
    ordered = _ordered_columns_from_values(columns, values_by_group, settings, labels)
    group_arrays, value_arrays = [], []
    for column in ordered:
        values = values_by_group[column]
        if len(values):
            group_arrays.append(np.full(len(values), column, dtype=object))
            value_arrays.append(values)
    if value_arrays:
        full = pd.DataFrame({settings.group_col: np.concatenate(group_arrays), settings.value_col: np.concatenate(value_arrays)})
    else:
        full = pd.DataFrame(columns=[settings.group_col, settings.value_col])
    full.attrs["group_keys"] = list(ordered)
    full.attrs["group_labels"] = dict(labels)
    hidden = set(_resolved_group_references(settings.group_hidden, columns, labels))
    visible = full.loc[~full[settings.group_col].isin(hidden)].reset_index(drop=True) if hidden else full.copy()
    visible.attrs["group_keys"] = [key for key in ordered if key not in hidden]
    visible.attrs["group_labels"] = dict(labels)
    return PreparedPlotFrames(full=full, visible=visible, groups=tuple(ordered), labels=labels)


def prepare_plot_data(df: pd.DataFrame, settings: ChartSettings, include_hidden: bool = False) -> pd.DataFrame:
    prepared = prepare_plot_frames(df, settings)
    return prepared.full if include_hidden else prepared.visible


def hidden_group_names(settings: ChartSettings) -> set[str]:
    return {str(group) for group in settings.group_hidden}


def unique_groups(columns) -> list:
    groups = []
    for column in columns:
        if column not in groups:
            groups.append(column)
    return groups


def values_for_group(df: pd.DataFrame, group) -> pd.Series:
    keys = group_keys(df)
    try:
        index = keys.index(str(group))
    except ValueError:
        # An ambiguous display label must never accidentally pool columns.
        matches = [index for index, label in enumerate(df.columns) if str(label) == str(group)]
        if len(matches) != 1:
            return pd.Series(dtype=float)
        index = matches[0]
    return coerce_numeric_series(df.iloc[:, index]).dropna().reset_index(drop=True)


def ordered_group_columns(df: pd.DataFrame, settings: ChartSettings) -> list[str]:
    columns = group_keys(df)
    values_by_group = {key: values_for_group(df, key).to_numpy(dtype=float) for key in columns}
    return _ordered_columns_from_values(columns, values_by_group, settings, group_labels(df))


def _ordered_columns_from_values(
    columns: list,
    values_by_group: dict[object, np.ndarray],
    settings: ChartSettings,
    labels: dict[str, str] | None = None,
) -> list:
    labels = labels or {str(column): str(column) for column in columns}
    if settings.group_order == "Manual":
        ordered = _resolved_group_references(settings.manual_group_order, columns, labels)
        ordered.extend(group for group in columns if group not in ordered)
        return ordered
    if settings.group_order == "Name A-Z":
        return sorted(columns, key=lambda column: labels[column].lower())
    if settings.group_order == "Name Z-A":
        return sorted(columns, key=lambda column: labels[column].lower(), reverse=True)
    if settings.group_order in {
        "Mean ascending",
        "Mean descending",
        "Median ascending",
        "Median descending",
    }:
        use_median = settings.group_order.startswith("Median")
        descending = settings.group_order.endswith("descending")

        def sort_key(column):
            values = values_by_group[column]
            if len(values) == 0:
                stat = math.inf if not descending else -math.inf
            else:
                stat = float(np.median(values) if use_median else np.mean(values))
            return (stat, labels[column].lower())

        return sorted(columns, key=sort_key, reverse=descending)
    return columns


def box_whis(mode: str):
    if mode == "Min-Max":
        return (0, 100)
    if mode == "Percentile 5-95":
        return (5, 95)
    if mode == "Percentile 10-90":
        return (10, 90)
    return 1.5


def axis_labels_for_chart(settings: ChartSettings) -> tuple[str, str]:
    group_label = settings.x_label
    value_label = settings.y_label
    if settings.chart_type == "Ridge":
        return value_label, group_label
    return group_label, value_label


def mark_outliers(df: pd.DataFrame, settings: ChartSettings) -> pd.DataFrame:
    outlier_parts = []
    for _, group_df in df.groupby(settings.group_col):
        values = group_df[settings.value_col]
        if len(values) < 3:
            continue
        if settings.outlier_method == "IQR":
            q1, q3 = values.quantile([0.25, 0.75])
            iqr = q3 - q1
            low = q1 - settings.outlier_threshold * iqr
            high = q3 + settings.outlier_threshold * iqr
            mask = (values < low) | (values > high)
        elif settings.outlier_method == "Z-score":
            std = values.std(ddof=0)
            mask = pd.Series(False, index=values.index) if std == 0 else ((values - values.mean()).abs() / std > settings.outlier_threshold)
        elif settings.outlier_method == "MAD":
            median = values.median()
            mad = (values - median).abs().median()
            mask = pd.Series(False, index=values.index) if mad == 0 else (0.6745 * (values - median).abs() / mad > settings.outlier_threshold)
        else:
            pct = settings.outlier_threshold
            low = values.quantile(max(0.0, pct / 100.0))
            high = values.quantile(min(1.0, 1.0 - pct / 100.0))
            mask = (values < low) | (values > high)
        outlier_parts.append(group_df[mask])
    return pd.concat(outlier_parts) if outlier_parts else pd.DataFrame(columns=df.columns)
