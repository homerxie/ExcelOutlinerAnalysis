from __future__ import annotations

import ast
from dataclasses import dataclass
import math
import re
import unicodedata
from typing import Mapping, Sequence

import numpy as np

from .xy_fitting import (
    FIT_MODEL_REGISTRY,
    XYFitResult,
    XYFitSpec,
    parse_custom_expression,
)


__all__ = [
    "format_fitted_equation",
    "format_fitted_equation_for_curve",
    "format_fitted_parameters",
]


_POLYNOMIAL_POWERS: dict[str, tuple[int, ...]] = {
    "linear": (1, 0),
    "polynomial2": (2, 1, 0),
    "polynomial3": (3, 2, 1, 0),
    "polynomial4": (4, 3, 2, 1, 0),
    "polynomial5": (5, 4, 3, 2, 1, 0),
}
_POLYNOMIAL_NAMES: dict[str, tuple[str, ...]] = {
    "linear": ("slope", "intercept"),
    "polynomial2": ("a", "b", "c"),
    "polynomial3": ("a", "b", "c", "d"),
    "polynomial4": ("a", "b", "c", "d", "e"),
    "polynomial5": ("a", "b", "c", "d", "e", "f"),
}
_FUNCTION_NAMES = frozenset(
    {
        "exp",
        "ln",
        "log",
        "log10",
        "sqrt",
        "abs",
        "sin",
        "cos",
        "tan",
        "asin",
        "acos",
        "atan",
        "atan2",
        "sec",
        "csc",
        "cot",
        "sinh",
        "cosh",
        "tanh",
    }
)
_SIMPLE_FUNCTION_COMMANDS: dict[str, str] = {
    "exp": r"\exp",
    "ln": r"\ln",
    "sin": r"\sin",
    "cos": r"\cos",
    "tan": r"\tan",
    "asin": r"\arcsin",
    "acos": r"\arccos",
    "atan": r"\arctan",
    "sinh": r"\sinh",
    "cosh": r"\cosh",
    "tanh": r"\tanh",
}
_MAX_ADAPTIVE_SIGNIFICANT_DIGITS = 17
_MAX_DISPLAY_CURVE_ERROR_FRACTION = np.longdouble("0.005")
_MAX_CURVE_VALIDATION_SAMPLES = 64


def _format_number(value: float, significant_digits: int) -> str:
    value = float(value)
    if math.isnan(value):
        return r"\mathrm{NaN}"
    if math.isinf(value):
        return r"-\infty" if value < 0.0 else r"\infty"
    if value == 0.0:
        value = 0.0
    rendered = format(value, f".{significant_digits}g").lower()
    if "e" not in rendered:
        return rendered
    mantissa, exponent = rendered.split("e", 1)
    return rf"{mantissa} \times 10^{{{int(exponent)}}}"


def _parameter_values(result: XYFitResult) -> dict[str, float]:
    return {
        str(estimate.name): float(estimate.value)
        for estimate in result.parameter_estimates
    }


def _sampled_finite_curve(
    result: XYFitResult,
) -> tuple[np.ndarray, np.ndarray] | None:
    curve_x = np.asarray(result.curve_x, dtype=float)
    curve_y = np.asarray(result.curve_y, dtype=float)
    if (
        curve_x.ndim != 1
        or curve_y.ndim != 1
        or curve_x.size < 2
        or curve_x.size != curve_y.size
    ):
        return None
    finite_indexes = np.flatnonzero(np.isfinite(curve_x) & np.isfinite(curve_y))
    if finite_indexes.size < 2:
        return None
    if finite_indexes.size > _MAX_CURVE_VALIDATION_SAMPLES:
        evenly_spaced = np.linspace(
            0,
            finite_indexes.size - 1,
            _MAX_CURVE_VALIDATION_SAMPLES - 2,
            dtype=int,
        )
        finite_y = curve_y[finite_indexes]
        positions = np.unique(
            np.concatenate(
                (
                    evenly_spaced,
                    np.asarray(
                        [np.argmin(finite_y), np.argmax(finite_y)],
                        dtype=int,
                    ),
                )
            )
        )
        finite_indexes = finite_indexes[positions]
    return curve_x[finite_indexes], curve_y[finite_indexes]


def _rounded_parameter_mapping(
    parameters: Mapping[str, float],
    names: tuple[str, ...],
    digits: int,
) -> dict[str, float]:
    rounded: dict[str, float] = {}
    for name in names:
        value = _finite_parameter(parameters, name)
        rounded[name] = float(format(value, f".{digits}g"))
    return rounded


def _adaptive_curve_digits(
    spec: XYFitSpec,
    result: XYFitResult,
    parameters: Mapping[str, float],
    minimum_digits: int,
) -> tuple[int, bool]:
    """Return display digits and whether they reproduce the visible curve.

    Validation uses at most 64 evenly distributed finite curve points. Each
    candidate decimal precision is evaluated once as a vector, keeping even
    custom sums and numerical integrals bounded and responsive.
    """

    try:
        sampled = _sampled_finite_curve(result)
        if sampled is None:
            return minimum_digits, True
        x_values, expected_float = sampled
        expected = np.asarray(expected_float, dtype=np.longdouble)
        curve_variation = np.max(expected) - np.min(expected)
        curve_scale = np.max(np.abs(expected))
        if curve_variation > 0.0:
            allowed_error = (
                _MAX_DISPLAY_CURVE_ERROR_FRACTION * curve_variation
            )
        else:
            allowed_error = (
                np.longdouble(64.0)
                * np.longdouble(np.finfo(float).eps)
                * curve_scale
            )

        model_id = str(result.model_id)
        if model_id == "custom":
            expression = str(spec.expression or result.equation)
            parsed = parse_custom_expression(expression)
            parameter_names = parsed.parameter_names

            def evaluate(rounded: Mapping[str, float]) -> np.ndarray:
                return parsed.evaluate(x_values, rounded)

        else:
            model = FIT_MODEL_REGISTRY[model_id]
            parameter_names = model.parameter_names

            def evaluate(rounded: Mapping[str, float]) -> np.ndarray:
                values = [rounded[name] for name in parameter_names]
                return np.asarray(model.evaluator(x_values, values), dtype=float)

        for digits in range(
            minimum_digits,
            _MAX_ADAPTIVE_SIGNIFICANT_DIGITS + 1,
        ):
            rounded = _rounded_parameter_mapping(
                parameters,
                parameter_names,
                digits,
            )
            try:
                reconstructed_float = np.asarray(
                    evaluate(rounded), dtype=float
                )
            except Exception:
                continue
            if reconstructed_float.ndim == 0:
                reconstructed_float = np.full(
                    x_values.shape,
                    float(reconstructed_float),
                    dtype=float,
                )
            try:
                reconstructed_float = np.asarray(
                    np.broadcast_to(reconstructed_float, x_values.shape),
                    dtype=float,
                )
            except ValueError:
                continue
            reconstructed = np.asarray(
                reconstructed_float, dtype=np.longdouble
            )
            if not np.all(np.isfinite(reconstructed)):
                continue
            maximum_error = np.max(np.abs(reconstructed - expected))
            if maximum_error <= allowed_error:
                return digits, True
    except Exception:
        return minimum_digits, False
    return _MAX_ADAPTIVE_SIGNIFICANT_DIGITS, False


def _finite_parameter(parameters: Mapping[str, float], name: str) -> float:
    value = float(parameters[name])
    if not math.isfinite(value):
        raise ValueError(f"The fitted parameter {name!r} is not finite.")
    return value


def _coefficient_body(
    magnitude: float,
    body: str,
    significant_digits: int,
) -> str:
    coefficient = _format_number(magnitude, significant_digits)
    if coefficient == "1":
        return body
    separator = r"\," if body.startswith("\\") else ""
    return f"{coefficient}{separator}{body}"


def _join_signed_terms(
    terms: list[tuple[float, str | None]],
    significant_digits: int,
) -> str:
    rendered: list[str] = []
    for coefficient, body in terms:
        if coefficient == 0.0:
            continue
        negative = math.copysign(1.0, coefficient) < 0.0
        magnitude = abs(coefficient)
        term = (
            _format_number(magnitude, significant_digits)
            if body is None
            else _coefficient_body(magnitude, body, significant_digits)
        )
        if not rendered:
            rendered.append(f"-{term}" if negative else term)
        else:
            rendered.append((" - " if negative else " + ") + term)
    return "".join(rendered) or "0"


def _power_of_x(power: int) -> str:
    if power == 0:
        return ""
    if power == 1:
        return "x"
    return rf"x^{{{power}}}"


def _format_polynomial(
    model_id: str,
    parameters: Mapping[str, float],
    significant_digits: int,
) -> str:
    names = _POLYNOMIAL_NAMES[model_id]
    powers = _POLYNOMIAL_POWERS[model_id]
    terms: list[tuple[float, str | None]] = []
    for name, power in zip(names, powers):
        terms.append(
            (
                _finite_parameter(parameters, name),
                _power_of_x(power) if power else None,
            )
        )
    return _join_signed_terms(terms, significant_digits)


def _scaled_x(value: float, significant_digits: int) -> str:
    if value == 0.0:
        return "0"
    negative = value < 0.0
    magnitude = abs(value)
    coefficient = _format_number(magnitude, significant_digits)
    body = "x" if coefficient == "1" else f"{coefficient}x"
    return f"-{body}" if negative else body


def _format_builtin(
    model_id: str,
    parameters: Mapping[str, float],
    significant_digits: int,
) -> str:
    if model_id in _POLYNOMIAL_POWERS:
        return _format_polynomial(model_id, parameters, significant_digits)

    if model_id == "exponential":
        amplitude = _finite_parameter(parameters, "amplitude")
        rate = _finite_parameter(parameters, "rate")
        offset = _finite_parameter(parameters, "offset")
        exponential = rf"\exp\!\left({_scaled_x(rate, significant_digits)}\right)"
        return _join_signed_terms(
            [(amplitude, exponential), (offset, None)], significant_digits
        )

    if model_id == "logarithmic":
        slope = _finite_parameter(parameters, "slope")
        intercept = _finite_parameter(parameters, "intercept")
        return _join_signed_terms(
            [(slope, r"\ln\!\left(x\right)"), (intercept, None)],
            significant_digits,
        )

    if model_id == "power":
        amplitude = _finite_parameter(parameters, "amplitude")
        exponent = _finite_parameter(parameters, "exponent")
        power = rf"x^{{{_format_number(exponent, significant_digits)}}}"
        return _join_signed_terms([(amplitude, power)], significant_digits)

    if model_id == "gaussian":
        baseline = _finite_parameter(parameters, "baseline")
        amplitude = _finite_parameter(parameters, "amplitude")
        center = _finite_parameter(parameters, "center")
        sigma = _finite_parameter(parameters, "sigma")
        if sigma == 0.0:
            raise ValueError("A Gaussian width cannot be zero.")
        if center == 0.0:
            centered_x = "x"
        elif center < 0.0:
            centered_x = (
                f"x + {_format_number(abs(center), significant_digits)}"
            )
        else:
            centered_x = f"x - {_format_number(center, significant_digits)}"
        sigma_text = _format_number(abs(sigma), significant_digits)
        normalized = (
            rf"\left({centered_x}\right)"
            if sigma_text == "1"
            else rf"\frac{{{centered_x}}}{{{sigma_text}}}"
        )
        gaussian = (
            rf"\exp\!\left[-\frac{{1}}{{2}}"
            rf"\left({normalized}\right)^{{2}}\right]"
        )
        if sigma < 0.0:
            # Squaring makes the sign immaterial; keep the displayed width positive.
            sigma = abs(sigma)
        return _join_signed_terms(
            [(baseline, None), (amplitude, gaussian)], significant_digits
        )

    raise ValueError(f"Unsupported fitted model: {model_id}")


@dataclass(frozen=True)
class _RenderedExpression:
    text: str
    precedence: int
    kind: str = "compound"
    numeric_value: float | None = None


_PREC_ADD = 10
_PREC_MULTIPLY = 20
_PREC_UNARY = 30
_PREC_POWER = 40
_PREC_ATOM = 100


_GREEK_MATHTEXT: dict[str, str] = {
    "α": r"\alpha",
    "β": r"\beta",
    "γ": r"\gamma",
    "δ": r"\delta",
    "ε": r"\epsilon",
    "ϵ": r"\varepsilon",
    "ζ": r"\zeta",
    "η": r"\eta",
    "θ": r"\theta",
    "ϑ": r"\vartheta",
    "ι": r"\iota",
    "κ": r"\kappa",
    "λ": r"\lambda",
    "μ": r"\mu",
    "ν": r"\nu",
    "ξ": r"\xi",
    "ο": r"\mathrm{o}",
    "π": r"\pi",
    "ϖ": r"\varpi",
    "ρ": r"\rho",
    "ϱ": r"\varrho",
    "σ": r"\sigma",
    "ς": r"\varsigma",
    "τ": r"\tau",
    "υ": r"\upsilon",
    "φ": r"\phi",
    "ϕ": r"\varphi",
    "χ": r"\chi",
    "ψ": r"\psi",
    "ω": r"\omega",
    "Α": r"\mathrm{A}",
    "Β": r"\mathrm{B}",
    "Γ": r"\Gamma",
    "Δ": r"\Delta",
    "Ε": r"\mathrm{E}",
    "Ζ": r"\mathrm{Z}",
    "Η": r"\mathrm{H}",
    "Θ": r"\Theta",
    "Ι": r"\mathrm{I}",
    "Κ": r"\mathrm{K}",
    "Λ": r"\Lambda",
    "Μ": r"\mathrm{M}",
    "Ν": r"\mathrm{N}",
    "Ξ": r"\Xi",
    "Ο": r"\mathrm{O}",
    "Π": r"\Pi",
    "Ρ": r"\mathrm{P}",
    "Σ": r"\Sigma",
    "Τ": r"\mathrm{T}",
    "Υ": r"\Upsilon",
    "Φ": r"\Phi",
    "Χ": r"\mathrm{X}",
    "Ψ": r"\Psi",
    "Ω": r"\Omega",
}


def _unicode_ascii_name(character: str) -> str:
    transliterated = (
        unicodedata.normalize("NFKD", character)
        .encode("ascii", "ignore")
        .decode("ascii")
    )
    transliterated = re.sub(r"[^A-Za-z0-9]", "", transliterated)
    return transliterated or f"u{ord(character):04X}"


def _identifier(name: str) -> str:
    if len(name) == 1 and name.isascii() and name.isalpha():
        return name
    pieces: list[str] = []
    roman: list[str] = []

    def flush_roman() -> None:
        if roman:
            safe = "".join(roman).replace("_", r"\_")
            pieces.append(rf"\mathrm{{{safe}}}")
            roman.clear()

    for character in name:
        greek = _GREEK_MATHTEXT.get(character)
        if greek is not None:
            flush_roman()
            pieces.append(greek)
        elif character.isascii() and (character.isalnum() or character == "_"):
            roman.append(character)
        else:
            roman.append(_unicode_ascii_name(character))
    flush_roman()
    return "".join(pieces) or r"\mathrm{variable}"


def _rendered_number(
    value: float,
    significant_digits: int,
) -> _RenderedExpression:
    numeric_value = float(value)
    precedence = _PREC_UNARY if numeric_value < 0.0 else _PREC_ATOM
    return _RenderedExpression(
        _format_number(numeric_value, significant_digits),
        precedence,
        "number",
        numeric_value,
    )


def _parenthesized(rendered: _RenderedExpression) -> str:
    return rf"\left({rendered.text}\right)"


def _with_minimum_precedence(rendered: _RenderedExpression, minimum: int) -> str:
    if rendered.precedence < minimum:
        return _parenthesized(rendered)
    return rendered.text


def _render_function_call(
    name: str,
    arguments: list[_RenderedExpression],
) -> _RenderedExpression:
    if name == "sqrt" and len(arguments) == 1:
        return _RenderedExpression(
            rf"\sqrt{{{arguments[0].text}}}", _PREC_ATOM, "function"
        )
    if name == "abs" and len(arguments) == 1:
        return _RenderedExpression(
            rf"\left|{arguments[0].text}\right|", _PREC_ATOM, "function"
        )
    if name == "log10" and len(arguments) == 1:
        return _RenderedExpression(
            rf"\log_{{10}}\!\left({arguments[0].text}\right)",
            _PREC_ATOM,
            "function",
        )
    if name == "log" and len(arguments) == 2:
        return _RenderedExpression(
            rf"\log_{{{arguments[1].text}}}\!\left({arguments[0].text}\right)",
            _PREC_ATOM,
            "function",
        )
    if name in _SIMPLE_FUNCTION_COMMANDS and len(arguments) == 1:
        command = _SIMPLE_FUNCTION_COMMANDS[name]
        return _RenderedExpression(
            rf"{command}\!\left({arguments[0].text}\right)",
            _PREC_ATOM,
            "function",
        )
    if name in {"sec", "csc", "cot"} and len(arguments) == 1:
        return _RenderedExpression(
            rf"\mathrm{{{name}}}\!\left({arguments[0].text}\right)",
            _PREC_ATOM,
            "function",
        )
    if name == "atan2" and len(arguments) == 2:
        return _RenderedExpression(
            rf"\mathrm{{atan2}}\!\left({arguments[0].text},\,"
            rf"{arguments[1].text}\right)",
            _PREC_ATOM,
            "function",
        )
    raise ValueError(f"Unsupported function call: {name}")


def _render_expression_node(
    node: ast.AST,
    parameters: Mapping[str, float],
    significant_digits: int,
    local_names: frozenset[str] = frozenset(),
) -> _RenderedExpression:
    if isinstance(node, ast.Constant):
        if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
            raise ValueError("Only numeric constants can be formatted.")
        return _rendered_number(float(node.value), significant_digits)

    if isinstance(node, ast.Name):
        if node.id in local_names:
            return _RenderedExpression(_identifier(node.id), _PREC_ATOM, "symbol")
        if node.id == "x":
            return _RenderedExpression("x", _PREC_ATOM, "symbol")
        if node.id == "pi":
            return _RenderedExpression(r"\pi", _PREC_ATOM, "symbol")
        if node.id == "e":
            return _RenderedExpression("e", _PREC_ATOM, "symbol")
        if node.id in parameters:
            return _rendered_number(
                parameters[node.id], significant_digits
            )
        return _RenderedExpression(_identifier(node.id), _PREC_ATOM, "symbol")

    if isinstance(node, ast.UnaryOp):
        operand = _render_expression_node(
            node.operand, parameters, significant_digits, local_names
        )
        if isinstance(node.op, ast.UAdd):
            return operand
        if isinstance(node.op, ast.USub):
            if operand.numeric_value is not None:
                return _rendered_number(
                    -operand.numeric_value,
                    significant_digits,
                )
            if operand.precedence == _PREC_UNARY and operand.text.startswith("-"):
                return _RenderedExpression(
                    operand.text[1:], _PREC_ATOM, operand.kind
                )
            text = _with_minimum_precedence(operand, _PREC_UNARY)
            return _RenderedExpression(f"-{text}", _PREC_UNARY)
        raise ValueError("Unsupported unary operator.")

    if isinstance(node, ast.BinOp):
        left = _render_expression_node(
            node.left, parameters, significant_digits, local_names
        )
        right = _render_expression_node(
            node.right, parameters, significant_digits, local_names
        )
        if isinstance(node.op, (ast.Add, ast.Sub)):
            left_text = _with_minimum_precedence(left, _PREC_ADD)
            right_minimum = _PREC_ADD + (1 if isinstance(node.op, ast.Sub) else 0)
            right_text = _with_minimum_precedence(right, right_minimum)
            is_simple_negative = (
                right.precedence > _PREC_ADD
                and right.text.startswith("-")
                and not right_text.startswith(r"\left(")
            )
            if is_simple_negative:
                right_text = right_text[1:]
                operator = " - " if isinstance(node.op, ast.Add) else " + "
            else:
                operator = " + " if isinstance(node.op, ast.Add) else " - "
            return _RenderedExpression(
                f"{left_text}{operator}{right_text}", _PREC_ADD
            )
        if isinstance(node.op, ast.Mult):
            left_text = _with_minimum_precedence(left, _PREC_MULTIPLY)
            right_text = _with_minimum_precedence(right, _PREC_MULTIPLY)
            if right.text.startswith("-"):
                right_text = _parenthesized(right)
            if left.kind == "number" and right.kind != "number":
                separator = r"\,"
            else:
                separator = r" \cdot "
            return _RenderedExpression(
                f"{left_text}{separator}{right_text}", _PREC_MULTIPLY
            )
        if isinstance(node.op, ast.Div):
            negative = False
            if left.numeric_value is not None and left.numeric_value < 0.0:
                negative = not negative
                left_text = _format_number(
                    abs(left.numeric_value), significant_digits
                )
            else:
                left_text = left.text
            if right.numeric_value is not None and right.numeric_value < 0.0:
                negative = not negative
                right_text = _format_number(
                    abs(right.numeric_value), significant_digits
                )
            else:
                right_text = right.text
            fraction = rf"\frac{{{left_text}}}{{{right_text}}}"
            return _RenderedExpression(
                f"-{fraction}" if negative else fraction,
                _PREC_UNARY if negative else _PREC_ATOM,
                "group",
            )
        if isinstance(node.op, ast.Pow):
            # Python powers associate to the right. A power explicitly used as
            # the left/base operand therefore needs parentheses; otherwise
            # MathText sees two superscripts on one atom (``x^2^3``).
            base = _with_minimum_precedence(left, _PREC_POWER + 1)
            return _RenderedExpression(
                rf"{base}^{{{right.text}}}", _PREC_POWER
            )
        raise ValueError("Unsupported binary operator.")

    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name) or node.keywords:
            raise ValueError("Unsupported function syntax.")
        name = node.func.id
        if name == "sum_over":
            if len(node.args) != 4 or not isinstance(node.args[0], ast.Name):
                raise ValueError("Unsupported sum syntax.")
            binding = node.args[0].id
            lower = _render_expression_node(
                node.args[1], parameters, significant_digits, local_names
            )
            upper = _render_expression_node(
                node.args[2], parameters, significant_digits, local_names
            )
            body = _render_expression_node(
                node.args[3],
                parameters,
                significant_digits,
                local_names | {binding},
            )
            return _RenderedExpression(
                rf"\sum_{{{_identifier(binding)}={lower.text}}}^{{{upper.text}}}"
                rf"\!\left({body.text}\right)",
                _PREC_ATOM,
                "function",
            )
        if name == "integral":
            if len(node.args) not in {4, 5} or not isinstance(node.args[0], ast.Name):
                raise ValueError("Unsupported integral syntax.")
            binding = node.args[0].id
            lower = _render_expression_node(
                node.args[1], parameters, significant_digits, local_names
            )
            upper = _render_expression_node(
                node.args[2], parameters, significant_digits, local_names
            )
            body = _render_expression_node(
                node.args[3],
                parameters,
                significant_digits,
                local_names | {binding},
            )
            return _RenderedExpression(
                rf"\int_{{{lower.text}}}^{{{upper.text}}}"
                rf"\!\left({body.text}\right)\,\mathrm{{d}}{_identifier(binding)}",
                _PREC_ATOM,
                "function",
            )
        if name not in _FUNCTION_NAMES:
            raise ValueError(f"Unsupported function: {name}")
        arguments = [
            _render_expression_node(
                argument, parameters, significant_digits, local_names
            )
            for argument in node.args
        ]
        return _render_function_call(name, arguments)

    raise ValueError("Unsupported expression syntax.")


def _render_custom_expression(
    expression: str,
    parameters: Mapping[str, float],
    significant_digits: int,
) -> str:
    parsed = parse_custom_expression(expression)
    tree = ast.parse(parsed.normalized_expression, mode="eval")
    return _render_expression_node(
        tree.body, parameters, significant_digits
    ).text


def _literal_math_text(source: str) -> str:
    source = str(source).strip()
    assignment = re.match(r"^[yY]\s*=", source)
    if assignment is not None:
        source = source[assignment.end() :].strip()
    source = re.sub(r"\s+", " ", source)
    if len(source) > 96:
        source = source[:93].rstrip() + "..."
    if not source:
        return r"\mathrm{fit}"

    pieces: list[str] = []
    word: list[str] = []

    def flush_word() -> None:
        if word:
            pieces.append(rf"\mathrm{{{''.join(word)}}}")
            word.clear()

    punctuation = set("+-*/=(),.[]")
    for character in source:
        if character.isascii() and character.isalnum():
            word.append(character)
            continue
        flush_word()
        if character.isspace():
            pieces.append(r"\ ")
        elif character in punctuation:
            pieces.append(character)
        elif character == "^":
            # A bare caret can make MathText itself fail; ``**`` remains visible
            # and conveys the same exponent operation used by the parser.
            pieces.append("**")
        elif character == "_":
            pieces.append("-")
        elif character in {"Σ", "∑"}:
            pieces.append(r"\Sigma")
        elif character == "∫":
            pieces.append(r"\int")
        else:
            pieces.append("?")
    flush_word()
    return "".join(pieces) or r"\mathrm{fit}"


def _safe_fallback(spec: XYFitSpec, result: XYFitResult) -> str:
    try:
        if getattr(spec, "model_id", "") == "custom":
            source = getattr(spec, "expression", "")
        else:
            source = getattr(result, "equation", "")
        return rf"$y \approx {_literal_math_text(source)}$"
    except Exception:
        return r"$y \approx \mathrm{fit}$"


def _validated_significant_digits(significant_digits: int) -> int:
    digits = int(significant_digits)
    if not 1 <= digits <= _MAX_ADAPTIVE_SIGNIFICANT_DIGITS:
        raise ValueError("significant_digits must be between 1 and 17")
    return digits


def _format_successful_equation(
    spec: XYFitSpec,
    result: XYFitResult,
    significant_digits: int,
    *,
    require_curve_reliability: bool,
) -> str | None:
    parameters = _parameter_values(result)
    display_digits, reliable = _adaptive_curve_digits(
        spec,
        result,
        parameters,
        significant_digits,
    )
    if require_curve_reliability and not reliable:
        return None
    model_id = str(result.model_id)
    if model_id == "custom":
        expression = str(spec.expression or result.equation)
        right_hand_side = _render_custom_expression(
            expression, parameters, display_digits
        )
    else:
        right_hand_side = _format_builtin(
            model_id, parameters, display_digits
        )
    return rf"$y \approx {right_hand_side}$"


def format_fitted_equation_for_curve(
    spec: XYFitSpec,
    result: XYFitResult,
    significant_digits: int = 4,
) -> str | None:
    """Return a curve-faithful MathText equation, or ``None`` when unsafe.

    This renderer-facing variant suppresses an annotation if even 17-digit
    displayed parameters cannot reproduce the already fitted curve. It also
    returns ``None`` for failed results or formatting errors, so drawing a plot
    never depends on an annotation succeeding.
    """

    try:
        digits = _validated_significant_digits(significant_digits)
        if not bool(result.success):
            return None
        return _format_successful_equation(
            spec,
            result,
            digits,
            require_curve_reliability=True,
        )
    except Exception:
        return None


def format_fitted_equation(
    spec: XYFitSpec,
    result: XYFitResult,
    significant_digits: int = 4,
) -> str:
    """Return a fitted equation ready for Matplotlib's built-in MathText parser.

    Fitted parameters are substituted into the public, ordinary-X equation.
    Custom expressions are parsed again with EasyGraph's safe expression parser;
    substitution therefore happens only at AST ``Name`` nodes and never through
    substring replacement.  Formatting is deliberately best-effort so a plot
    annotation cannot make an otherwise successful plot fail.
    """

    try:
        digits = _validated_significant_digits(significant_digits)
        if not bool(result.success):
            return _safe_fallback(spec, result)
        formatted = _format_successful_equation(
            spec,
            result,
            digits,
            require_curve_reliability=False,
        )
        return formatted or _safe_fallback(spec, result)
    except Exception:
        return _safe_fallback(spec, result)


def format_fitted_parameters(
    result: XYFitResult,
    parameter_names: Sequence[str] = (),
    significant_digits: int = 4,
) -> str | None:
    """Return selected fitted values as compact, safe Matplotlib MathText."""

    try:
        digits = _validated_significant_digits(significant_digits)
        if not bool(result.success):
            return None
        parameters = _parameter_values(result)
        requested = tuple(str(name) for name in parameter_names)
        names = requested or tuple(parameters)
        rendered = [
            rf"{_identifier(name)} = {_format_number(parameters[name], digits)}"
            for name in names
            if name in parameters
        ]
        if not rendered:
            return None
        return "$" + r",\quad ".join(rendered) + "$"
    except Exception:
        return None
