from __future__ import annotations

from collections.abc import Iterable

import pandas as pd
from easygraph.data import group_keys
from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont


def _cell_text(value) -> str:
    return "" if pd.isna(value) else str(value)


class EasyGraphTableModel(QAbstractTableModel):
    cellEdited = Signal(int, int, str, str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._cells: list[list[str]] = []
        self._horizontal_headers: list[str] = []
        self._horizontal_header_tooltips: list[str] = []
        self._vertical_headers: list[str] = []
        self._sample_start_row = 1
        self._header_background = QBrush(QColor("#3E4A56"))
        self._header_foreground = QBrush(QColor("#F3F4F6"))
        self._overlay_background = QBrush()
        self._overlay_foreground = QBrush()
        self._revision = 0

    @property
    def revision(self) -> int:
        return self._revision

    @property
    def sample_start_row(self) -> int:
        return self._sample_start_row

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._cells)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        if self._cells:
            return len(self._cells[0])
        return len(self._horizontal_headers)

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):
        if not index.isValid():
            return None
        row, column = index.row(), index.column()
        if row >= self.rowCount() or column >= self.columnCount():
            return None
        if role in (Qt.DisplayRole, Qt.EditRole):
            return self._cells[row][column]
        if role == Qt.FontRole:
            font = QFont(self.parent().font()) if self.parent() is not None else QFont()
            font.setBold(row < self._sample_start_row)
            return font
        if role == Qt.BackgroundRole:
            if row == 0:
                return self._header_background
            if row < self._sample_start_row:
                return self._overlay_background
            return None
        if role == Qt.ForegroundRole:
            if row == 0:
                return self._header_foreground
            if row < self._sample_start_row:
                return self._overlay_foreground
            return None
        if role == Qt.TextAlignmentRole:
            return Qt.AlignCenter if row == 0 else Qt.AlignLeft | Qt.AlignVCenter
        return None

    def setData(self, index: QModelIndex, value, role: int = Qt.EditRole) -> bool:
        if role not in (Qt.EditRole, Qt.DisplayRole) or not index.isValid():
            return False
        text = str(value)
        row, column = index.row(), index.column()
        before = self._cells[row][column]
        if before == text:
            return False
        self._cells[row][column] = text
        self._revision += 1
        self.dataChanged.emit(index, index, [Qt.DisplayRole, Qt.EditRole])
        self.cellEdited.emit(row, column, before, text)
        return True

    def flags(self, index: QModelIndex):
        if not index.isValid():
            return Qt.NoItemFlags
        return Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.ToolTipRole:
            if 0 <= section < len(self._horizontal_header_tooltips):
                return self._horizontal_header_tooltips[section] or None
            return None
        if role != Qt.DisplayRole:
            return None
        headers = self._horizontal_headers if orientation == Qt.Horizontal else self._vertical_headers
        if 0 <= section < len(headers):
            return headers[section]
        return str(section + 1) if orientation == Qt.Vertical else ""

    def set_horizontal_headers(
        self,
        labels: Iterable[str],
        tooltips: Iterable[str] | None = None,
    ) -> None:
        self._horizontal_headers = [str(label) for label in labels]
        tooltip_values = [] if tooltips is None else [str(value) for value in tooltips]
        self._horizontal_header_tooltips = [
            tooltip_values[index] if index < len(tooltip_values) else ""
            for index in range(len(self._horizontal_headers))
        ]
        if self._horizontal_headers:
            self.headerDataChanged.emit(Qt.Horizontal, 0, len(self._horizontal_headers) - 1)

    def set_vertical_headers(self, labels: Iterable[str]) -> None:
        self._vertical_headers = [str(label) for label in labels]
        if self._vertical_headers:
            self.headerDataChanged.emit(Qt.Vertical, 0, len(self._vertical_headers) - 1)

    def set_vertical_header(self, row: int, text: str) -> None:
        while len(self._vertical_headers) < self.rowCount():
            self._vertical_headers.append(str(len(self._vertical_headers) + 1))
        if 0 <= row < len(self._vertical_headers) and self._vertical_headers[row] != str(text):
            self._vertical_headers[row] = str(text)
            self.headerDataChanged.emit(Qt.Vertical, row, row)

    def configure_style(
        self,
        sample_start_row: int,
        overlay_background: QBrush,
        overlay_foreground: QBrush,
        header_background: QBrush | None = None,
        header_foreground: QBrush | None = None,
    ) -> None:
        self._sample_start_row = max(1, int(sample_start_row))
        if header_background is not None:
            self._header_background = header_background
        if header_foreground is not None:
            self._header_foreground = header_foreground
        self._overlay_background = overlay_background
        self._overlay_foreground = overlay_foreground
        if self.rowCount() and self.columnCount():
            self.dataChanged.emit(
                self.index(0, 0),
                self.index(self.rowCount() - 1, self.columnCount() - 1),
                [Qt.FontRole, Qt.BackgroundRole, Qt.ForegroundRole, Qt.TextAlignmentRole],
            )

    def replace_from_dataframe(self, df: pd.DataFrame, overlay_series: list[dict]) -> int:
        overlay_series = list(overlay_series)
        columns = [str(column) for column in df.columns]
        keys = group_keys(df)
        sample_start_row = 1 + len(overlay_series)
        rows = [columns]
        for series in overlay_series:
            values = series.get("values", {}) if isinstance(series, dict) else {}
            rows.append([
                _cell_text(values.get(key, values.get(column, ""))) if isinstance(values, dict) else ""
                for key, column in zip(keys, columns)
            ])
        rows.extend([
            [_cell_text(value) for value in row]
            for row in df.itertuples(index=False, name=None)
        ])
        self.replace_cells(rows, column_count=len(columns))
        self._sample_start_row = sample_start_row
        return sample_start_row

    def replace_cells(self, rows: list[list[str]], column_count: int | None = None) -> None:
        if column_count is None:
            column_count = max((len(row) for row in rows), default=0)
        normalized = [
            [str(row[column]) if column < len(row) else "" for column in range(column_count)]
            for row in rows
        ]
        self.beginResetModel()
        self._cells = normalized
        self._horizontal_headers = [str(index + 1) for index in range(column_count)]
        self._horizontal_header_tooltips = ["" for _ in range(column_count)]
        self._vertical_headers = [str(index + 1) for index in range(len(normalized))]
        self._revision += 1
        self.endResetModel()

    def resize(self, rows: int, columns: int) -> None:
        rows = max(0, int(rows))
        columns = max(0, int(columns))
        current_rows = self.rowCount()
        current_columns = self.columnCount()
        if rows > current_rows:
            self.insertRows(current_rows, rows - current_rows)
        elif rows < current_rows:
            self.removeRows(rows, current_rows - rows)
        if columns > current_columns:
            self.insertColumns(current_columns, columns - current_columns)
        elif columns < current_columns:
            self.removeColumns(columns, current_columns - columns)

    def insertRows(self, row: int, count: int, parent: QModelIndex = QModelIndex()) -> bool:
        if count <= 0 or row < 0 or row > self.rowCount():
            return False
        columns = self.columnCount()
        self.beginInsertRows(parent, row, row + count - 1)
        for offset in range(count):
            self._cells.insert(row + offset, [""] * columns)
            self._vertical_headers.insert(row + offset, str(row + offset + 1))
        self._revision += 1
        self.endInsertRows()
        return True

    def removeRows(self, row: int, count: int, parent: QModelIndex = QModelIndex()) -> bool:
        if count <= 0 or row < 0 or row + count > self.rowCount():
            return False
        self.beginRemoveRows(parent, row, row + count - 1)
        del self._cells[row : row + count]
        del self._vertical_headers[row : row + count]
        self._revision += 1
        self.endRemoveRows()
        return True

    def insertColumns(self, column: int, count: int, parent: QModelIndex = QModelIndex()) -> bool:
        if count <= 0 or column < 0 or column > self.columnCount():
            return False
        self.beginInsertColumns(parent, column, column + count - 1)
        for row in self._cells:
            row[column:column] = [""] * count
        self._horizontal_headers[column:column] = [
            str(index + 1) for index in range(column, column + count)
        ]
        self._horizontal_header_tooltips[column:column] = ["" for _ in range(count)]
        self._revision += 1
        self.endInsertColumns()
        return True

    def removeColumns(self, column: int, count: int, parent: QModelIndex = QModelIndex()) -> bool:
        if count <= 0 or column < 0 or column + count > self.columnCount():
            return False
        self.beginRemoveColumns(parent, column, column + count - 1)
        for row in self._cells:
            del row[column : column + count]
        del self._horizontal_headers[column : column + count]
        del self._horizontal_header_tooltips[column : column + count]
        self._revision += 1
        self.endRemoveColumns()
        return True

    def cell_text(self, row: int, column: int) -> str:
        if 0 <= row < self.rowCount() and 0 <= column < self.columnCount():
            return self._cells[row][column]
        return ""

    def cells_copy(self) -> list[list[str]]:
        return [row.copy() for row in self._cells]

    def set_cell_text(self, row: int, column: int, text: str) -> bool:
        if not (0 <= row < self.rowCount() and 0 <= column < self.columnCount()):
            return False
        return self.setData(self.index(row, column), str(text), Qt.EditRole)

    def sample_dataframe(
        self,
        sample_start_row: int | None = None,
        fallback_prefix: str = "Group",
    ) -> pd.DataFrame:
        start = self._sample_start_row if sample_start_row is None else int(sample_start_row)
        headers = [
            self._cells[0][column].strip() or f"{fallback_prefix} {column + 1}"
            for column in range(self.columnCount())
        ] if self.rowCount() else [f"{fallback_prefix} {column + 1}" for column in range(self.columnCount())]
        return pd.DataFrame(
            [row.copy() for row in self._cells[max(start, 0) :]],
            columns=headers,
        )

    def overlay_series(
        self,
        sample_start_row: int,
        fallback_series: list[dict],
        groups: list[str] | None = None,
    ) -> list[dict]:
        if sample_start_row <= 1:
            return list(fallback_series)
        if groups is None:
            groups = [
                self._cells[0][column].strip() or f"Group {column + 1}"
                for column in range(self.columnCount())
            ]
        series = []
        for row in range(1, min(sample_start_row, self.rowCount())):
            name = self.headerData(row, Qt.Vertical, Qt.DisplayRole)
            name = str(name).strip() if name is not None else ""
            series.append({
                "name": name or f"Overlay {row}",
                "values": {
                    str(group): self._cells[row][column]
                    for column, group in enumerate(groups)
                },
            })
        return series
