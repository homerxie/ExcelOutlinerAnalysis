"""Office-compatible clipboard tables, independent of Qt and the data model."""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from html import escape
from html.parser import HTMLParser
from io import StringIO


# Clipboard HTML is external input. Bound both individual spans and the final
# rectangular allocation before constructing a potentially very sparse table.
_MAX_ROWS = 100_000
_MAX_COLUMNS = 10_000
_MAX_CELLS = 1_000_000
_MAX_HTML_LENGTH = 16_000_000


@dataclass(frozen=True)
class CellMerge:
    row: int
    column: int
    rowspan: int = 1
    colspan: int = 1


@dataclass
class ClipboardTable:
    rows: list[list[str]]
    merges: list[CellMerge] = field(default_factory=list)
    # None means foreign HTML; 0 is data, 1 parent headers, 2 parent + leaf.
    header_rows: int | None = None


def _table_cells(
    table: ClipboardTable,
) -> tuple[list[list[str]], dict[tuple[int, int], CellMerge], set[tuple[int, int]]]:
    width = max((len(row) for row in table.rows), default=0)
    height = len(table.rows)
    if height > _MAX_ROWS or width > _MAX_COLUMNS or height * width > _MAX_CELLS:
        raise ValueError("Clipboard table is too large")
    rows = [list(row) + [""] * (width - len(row)) for row in table.rows]
    anchors: dict[tuple[int, int], CellMerge] = {}
    occupied: set[tuple[int, int]] = set()
    covered: set[tuple[int, int]] = set()
    for merge in table.merges:
        if (
            merge.row < 0
            or merge.column < 0
            or merge.rowspan < 1
            or merge.colspan < 1
            or merge.row + merge.rowspan > height
            or merge.column + merge.colspan > width
        ):
            raise ValueError("Clipboard merge is outside the table")
        anchor = (merge.row, merge.column)
        anchors[anchor] = merge
        for row in range(merge.row, merge.row + merge.rowspan):
            for column in range(merge.column, merge.column + merge.colspan):
                position = (row, column)
                if position in occupied:
                    raise ValueError("Clipboard merges overlap")
                occupied.add(position)
                if position != anchor:
                    covered.add(position)
                    rows[row][column] = ""
    return rows, anchors, covered


def clipboard_table_to_tsv(table: ClipboardTable) -> str:
    """Plain-text fallback with empty placeholders for merged cells."""
    rows, _, _ = _table_cells(table)
    buffer = StringIO()
    csv.writer(buffer, delimiter="\t", lineterminator="\n").writerows(rows)
    text = buffer.getvalue()
    return text[:-1] if text.endswith("\n") else text


def clipboard_table_to_html(table: ClipboardTable) -> str:
    """Create an HTML table Excel and Word can paste with merged headers."""
    rows, anchors, covered = _table_cells(table)
    metadata = (
        f' data-easygraph-header-rows="{table.header_rows}"'
        if table.header_rows is not None
        else ""
    )
    parts = [
        '<html><head><meta charset="utf-8"></head><body><!--StartFragment-->',
        f'<table{metadata} border="1" style="border-collapse:collapse">',
    ]
    for row_number, row in enumerate(rows):
        parts.append("<tr>")
        tag = "th" if row_number < (table.header_rows or 0) else "td"
        for column, value in enumerate(row):
            if (row_number, column) in covered:
                continue
            merge = anchors.get((row_number, column))
            spans = ""
            if merge is not None:
                if merge.rowspan > 1:
                    spans += f' rowspan="{merge.rowspan}"'
                if merge.colspan > 1:
                    spans += f' colspan="{merge.colspan}"'
            # Keep header labels literal while allowing Office to infer numeric
            # and percentage types in data cells, as with plain-text paste.
            number_format = ";mso-number-format:\\@" if tag == "th" else ""
            style = f' style="white-space:pre-wrap{number_format}"'
            text = escape(str(value)).replace("\r\n", "\n").replace("\r", "\n")
            text = text.replace("\n", '<br style="mso-data-placement:same-cell">')
            parts.append(f"<{tag}{spans}{style}>{text}</{tag}>")
        parts.append("</tr>")
    parts.append("</table><!--EndFragment--></body></html>")
    return "".join(parts)


class _InvalidTable(ValueError):
    pass


class _TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.started = False
        self.finished = False
        self.depth = 0
        self.suppressed = 0
        self.rows: list[dict[int, str]] = []
        self.merges: list[CellMerge] = []
        self.header_rows: int | None = None
        self.row = -1
        self.column = 0
        self.width = 0
        self.in_row = False
        self.cell: tuple[int, int] | None = None
        self.parts: list[str | None] = []
        self.preserve_space = False

    def _check_dimensions(self, height: int, width: int) -> None:
        if height > _MAX_ROWS or width > _MAX_COLUMNS or height * width > _MAX_CELLS:
            raise _InvalidTable("Clipboard table is too large")

    def _start_row(self) -> None:
        self._finish_cell()
        self.row += 1
        self.column = 0
        self.in_row = True
        self._check_dimensions(self.row + 1, self.width)
        if self.row >= len(self.rows):
            self.rows.append({})

    @staticmethod
    def _span(value: str | None) -> int:
        try:
            return max(1, int(value or "1"))
        except ValueError:
            return 1

    def _start_cell(self, attrs: dict[str, str | None]) -> None:
        self._finish_cell()
        if not self.in_row:
            self._start_row()
        while self.column in self.rows[self.row]:
            self.column += 1
        rowspan = self._span(attrs.get("rowspan"))
        colspan = self._span(attrs.get("colspan"))
        height = max(len(self.rows), self.row + rowspan)
        width = max(self.width, self.column + colspan)
        self._check_dimensions(height, width)
        self.width = width
        while len(self.rows) < height:
            self.rows.append({})
        for row in range(self.row, self.row + rowspan):
            for column in range(self.column, self.column + colspan):
                if column in self.rows[row]:
                    raise _InvalidTable("Clipboard merges overlap")
                self.rows[row][column] = ""
        self.cell = (self.row, self.column)
        if rowspan > 1 or colspan > 1:
            self.merges.append(CellMerge(self.row, self.column, rowspan, colspan))
        self.column += colspan
        style = attrs.get("style") or ""
        self.preserve_space = bool(re.search(r"white-space\s*:\s*pre", style, re.I))

    def _finish_cell(self) -> None:
        if self.cell is None:
            return
        # Explicit breaks are separate tokens so source-code indentation can
        # be folded without losing a multiline Excel cell's line breaks.
        lines = [""]
        for part in self.parts:
            if part is None:
                lines.append("")
            else:
                lines[-1] += part
        if not self.preserve_space:
            lines = [re.sub(r"[ \t\r\n\f]+", " ", line).strip(" ") for line in lines]
        row, column = self.cell
        self.rows[row][column] = "\n".join(lines)
        self.cell = None
        self.parts = []
        self.preserve_space = False

    def handle_starttag(self, tag: str, attributes: list[tuple[str, str | None]]) -> None:
        if self.finished:
            return
        attrs = dict(attributes)
        if tag == "table":
            self.depth += 1
            if not self.started:
                self.started = True
                value = attrs.get("data-easygraph-header-rows")
                if value in ("0", "1", "2"):
                    self.header_rows = int(value)
            return
        if not self.started:
            return
        if tag in ("script", "style"):
            self.suppressed += 1
        if self.suppressed:
            return
        if self.depth == 1:
            if tag == "tr":
                self._start_row()
            elif tag in ("td", "th"):
                self._start_cell(attrs)
        if self.cell is not None:
            if tag == "br":
                self.parts.append(None)
            elif tag in ("p", "div") and self.parts and self.parts[-1] is not None:
                self.parts.append(None)
            elif tag == "pre" or re.search(
                r"(?:white-space\s*:\s*pre|mso-spacerun\s*:\s*yes)",
                attrs.get("style") or "",
                re.I,
            ):
                self.preserve_space = True

    def handle_endtag(self, tag: str) -> None:
        if not self.started or self.finished:
            return
        if tag in ("script", "style") and self.suppressed:
            self.suppressed -= 1
            return
        if self.suppressed:
            return
        if tag == "table":
            self.depth -= 1
            if self.depth == 0:
                self._finish_cell()
                self.finished = True
        elif self.depth == 1 and tag in ("td", "th", "tr"):
            self._finish_cell()
            if tag == "tr":
                self.in_row = False

    def handle_data(self, data: str) -> None:
        if self.cell is not None and not self.suppressed:
            self.parts.append(data)

    def result(self) -> ClipboardTable | None:
        self._finish_cell()
        if not self.rows or not self.width:
            return None
        if self.header_rows is not None and self.header_rows > len(self.rows):
            self.header_rows = None
        rows = [[row.get(column, "") for column in range(self.width)] for row in self.rows]
        return ClipboardTable(rows, self.merges, self.header_rows)


def clipboard_table_from_html(html: str) -> ClipboardTable | None:
    """Read the first HTML table, including Office's optional CF_HTML prefix.

    None asks the caller to fall back to the clipboard's plain-text flavor.
    Foreign HTML has no EasyGraph header metadata, even when it uses ``th``.
    """
    if not html or len(html) > _MAX_HTML_LENGTH:
        return None
    parser = _TableParser()
    try:
        parser.feed(html)
        parser.close()
        return parser.result()
    except (ValueError, OverflowError):
        return None
