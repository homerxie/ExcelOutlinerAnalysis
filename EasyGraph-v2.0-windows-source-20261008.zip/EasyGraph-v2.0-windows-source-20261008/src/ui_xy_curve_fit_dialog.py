# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'xy_curve_fit_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QComboBox,
    QDialog, QDialogButtonBox, QFormLayout, QFrame,
    QGroupBox, QHBoxLayout, QHeaderView, QLabel,
    QLayout, QLineEdit, QListWidget, QListWidgetItem,
    QPlainTextEdit, QProgressBar, QPushButton, QRadioButton,
    QScrollArea, QSizePolicy, QSpacerItem, QSplitter,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

class Ui_XYCurveFitDialog(object):
    def setupUi(self, XYCurveFitDialog):
        if not XYCurveFitDialog.objectName():
            XYCurveFitDialog.setObjectName(u"XYCurveFitDialog")
        XYCurveFitDialog.setModal(True)
        XYCurveFitDialog.setMinimumSize(QSize(980, 680))
        self.verticalLayout = QVBoxLayout(XYCurveFitDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.hintLabel = QLabel(XYCurveFitDialog)
        self.hintLabel.setObjectName(u"hintLabel")
        self.hintLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.hintLabel)

        self.mainSplitter = QSplitter(XYCurveFitDialog)
        self.mainSplitter.setObjectName(u"mainSplitter")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.mainSplitter.sizePolicy().hasHeightForWidth())
        self.mainSplitter.setSizePolicy(sizePolicy)
        self.mainSplitter.setOrientation(Qt.Vertical)
        self.mainSplitter.setChildrenCollapsible(False)
        self.fitSetupGroup = QGroupBox(self.mainSplitter)
        self.fitSetupGroup.setObjectName(u"fitSetupGroup")
        self.fitSetupLayout = QHBoxLayout(self.fitSetupGroup)
        self.fitSetupLayout.setObjectName(u"fitSetupLayout")
        self.setupSplitter = QSplitter(self.fitSetupGroup)
        self.setupSplitter.setObjectName(u"setupSplitter")
        self.setupSplitter.setOrientation(Qt.Horizontal)
        self.setupSplitter.setChildrenCollapsible(False)
        self.seriesPane = QWidget(self.setupSplitter)
        self.seriesPane.setObjectName(u"seriesPane")
        self.seriesPaneLayout = QVBoxLayout(self.seriesPane)
        self.seriesPaneLayout.setObjectName(u"seriesPaneLayout")
        self.seriesPaneLayout.setContentsMargins(0, 0, 6, 0)
        self.seriesHeadingLabel = QLabel(self.seriesPane)
        self.seriesHeadingLabel.setObjectName(u"seriesHeadingLabel")

        self.seriesPaneLayout.addWidget(self.seriesHeadingLabel)

        self.seriesSelectionLayout = QHBoxLayout()
        self.seriesSelectionLayout.setObjectName(u"seriesSelectionLayout")
        self.selectAllButton = QPushButton(self.seriesPane)
        self.selectAllButton.setObjectName(u"selectAllButton")

        self.seriesSelectionLayout.addWidget(self.selectAllButton)

        self.clearSelectionButton = QPushButton(self.seriesPane)
        self.clearSelectionButton.setObjectName(u"clearSelectionButton")

        self.seriesSelectionLayout.addWidget(self.clearSelectionButton)


        self.seriesPaneLayout.addLayout(self.seriesSelectionLayout)

        self.seriesList = QListWidget(self.seriesPane)
        self.seriesList.setObjectName(u"seriesList")
        self.seriesList.setAlternatingRowColors(True)
        self.seriesList.setSelectionMode(QAbstractItemView.ExtendedSelection)

        self.seriesPaneLayout.addWidget(self.seriesList)

        self.seriesSummaryLabel = QLabel(self.seriesPane)
        self.seriesSummaryLabel.setObjectName(u"seriesSummaryLabel")
        self.seriesSummaryLabel.setWordWrap(True)

        self.seriesPaneLayout.addWidget(self.seriesSummaryLabel)

        self.setupSplitter.addWidget(self.seriesPane)
        self.fitScrollArea = QScrollArea(self.setupSplitter)
        self.fitScrollArea.setObjectName(u"fitScrollArea")
        self.fitScrollArea.setMinimumSize(QSize(400, 0))
        self.fitScrollArea.setFrameShape(QFrame.Shape.NoFrame)
        self.fitScrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.fitScrollArea.setWidgetResizable(True)
        self.fitPane = QWidget()
        self.fitPane.setObjectName(u"fitPane")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.fitPane.sizePolicy().hasHeightForWidth())
        self.fitPane.setSizePolicy(sizePolicy1)
        self.fitPane.setGeometry(QRect(0, 0, 711, 606))
        self.fitPaneLayout = QVBoxLayout(self.fitPane)
        self.fitPaneLayout.setObjectName(u"fitPaneLayout")
        self.fitPaneLayout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        self.fitPaneLayout.setContentsMargins(6, 0, 0, 0)
        self.modelGroup = QGroupBox(self.fitPane)
        self.modelGroup.setObjectName(u"modelGroup")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(4)
        sizePolicy2.setHeightForWidth(self.modelGroup.sizePolicy().hasHeightForWidth())
        self.modelGroup.setSizePolicy(sizePolicy2)
        self.modelGroupLayout = QVBoxLayout(self.modelGroup)
        self.modelGroupLayout.setObjectName(u"modelGroupLayout")
        self.modelFormLayout = QFormLayout()
        self.modelFormLayout.setObjectName(u"modelFormLayout")
        self.modelLabel = QLabel(self.modelGroup)
        self.modelLabel.setObjectName(u"modelLabel")

        self.modelFormLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.modelLabel)

        self.modelCombo = QComboBox(self.modelGroup)
        self.modelCombo.setObjectName(u"modelCombo")

        self.modelFormLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.modelCombo)

        self.equationLabel = QLabel(self.modelGroup)
        self.equationLabel.setObjectName(u"equationLabel")

        self.modelFormLayout.setWidget(1, QFormLayout.ItemRole.SpanningRole, self.equationLabel)

        self.equationDisplayLabel = QLabel(self.modelGroup)
        self.equationDisplayLabel.setObjectName(u"equationDisplayLabel")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(1)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.equationDisplayLabel.sizePolicy().hasHeightForWidth())
        self.equationDisplayLabel.setSizePolicy(sizePolicy3)
        self.equationDisplayLabel.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.equationDisplayLabel.setWordWrap(True)

        self.modelFormLayout.setWidget(2, QFormLayout.ItemRole.SpanningRole, self.equationDisplayLabel)


        self.modelGroupLayout.addLayout(self.modelFormLayout)

        self.modelDescriptionLabel = QLabel(self.modelGroup)
        self.modelDescriptionLabel.setObjectName(u"modelDescriptionLabel")
        self.modelDescriptionLabel.setWordWrap(True)

        self.modelGroupLayout.addWidget(self.modelDescriptionLabel)

        self.customEquationWidget = QWidget(self.modelGroup)
        self.customEquationWidget.setObjectName(u"customEquationWidget")
        self.customEquationLayout = QVBoxLayout(self.customEquationWidget)
        self.customEquationLayout.setObjectName(u"customEquationLayout")
        self.customEquationLayout.setContentsMargins(0, 0, 0, 0)
        self.customEquationEditLayout = QHBoxLayout()
        self.customEquationEditLayout.setObjectName(u"customEquationEditLayout")
        self.customEquationLabel = QLabel(self.customEquationWidget)
        self.customEquationLabel.setObjectName(u"customEquationLabel")

        self.customEquationEditLayout.addWidget(self.customEquationLabel)

        self.customEquationEdit = QLineEdit(self.customEquationWidget)
        self.customEquationEdit.setObjectName(u"customEquationEdit")
        self.customEquationEdit.setClearButtonEnabled(True)

        self.customEquationEditLayout.addWidget(self.customEquationEdit)


        self.customEquationLayout.addLayout(self.customEquationEditLayout)

        self.customEquationInsertLayout = QHBoxLayout()
        self.customEquationInsertLayout.setObjectName(u"customEquationInsertLayout")
        self.insertTemplateLabel = QLabel(self.customEquationWidget)
        self.insertTemplateLabel.setObjectName(u"insertTemplateLabel")

        self.customEquationInsertLayout.addWidget(self.insertTemplateLabel)

        self.insertSigmaButton = QPushButton(self.customEquationWidget)
        self.insertSigmaButton.setObjectName(u"insertSigmaButton")

        self.customEquationInsertLayout.addWidget(self.insertSigmaButton)

        self.insertIntegralButton = QPushButton(self.customEquationWidget)
        self.insertIntegralButton.setObjectName(u"insertIntegralButton")

        self.customEquationInsertLayout.addWidget(self.insertIntegralButton)

        self.customEquationInsertSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.customEquationInsertLayout.addItem(self.customEquationInsertSpacer)


        self.customEquationLayout.addLayout(self.customEquationInsertLayout)

        self.customFunctionInsertLayout = QHBoxLayout()
        self.customFunctionInsertLayout.setObjectName(u"customFunctionInsertLayout")
        self.functionTemplateLabel = QLabel(self.customEquationWidget)
        self.functionTemplateLabel.setObjectName(u"functionTemplateLabel")

        self.customFunctionInsertLayout.addWidget(self.functionTemplateLabel)

        self.functionCombo = QComboBox(self.customEquationWidget)
        self.functionCombo.setObjectName(u"functionCombo")
        self.functionCombo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.functionCombo.setMinimumContentsLength(12)

        self.customFunctionInsertLayout.addWidget(self.functionCombo)

        self.insertFunctionButton = QPushButton(self.customEquationWidget)
        self.insertFunctionButton.setObjectName(u"insertFunctionButton")

        self.customFunctionInsertLayout.addWidget(self.insertFunctionButton)

        self.customFunctionInsertSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.customFunctionInsertLayout.addItem(self.customFunctionInsertSpacer)


        self.customEquationLayout.addLayout(self.customFunctionInsertLayout)

        self.customEquationHelpLabel = QLabel(self.customEquationWidget)
        self.customEquationHelpLabel.setObjectName(u"customEquationHelpLabel")
        self.customEquationHelpLabel.setWordWrap(True)

        self.customEquationLayout.addWidget(self.customEquationHelpLabel)


        self.modelGroupLayout.addWidget(self.customEquationWidget)

        self.parameterTable = QTableWidget(self.modelGroup)
        if (self.parameterTable.columnCount() < 5):
            self.parameterTable.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.parameterTable.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.parameterTable.setObjectName(u"parameterTable")
        self.parameterTable.setMinimumSize(QSize(0, 70))
        self.parameterTable.setMaximumSize(QSize(16777215, 110))
        self.parameterTable.setAlternatingRowColors(True)
        self.parameterTable.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.parameterTable.setColumnCount(5)

        self.modelGroupLayout.addWidget(self.parameterTable)

        self.parameterHintLabel = QLabel(self.modelGroup)
        self.parameterHintLabel.setObjectName(u"parameterHintLabel")
        self.parameterHintLabel.setWordWrap(True)

        self.modelGroupLayout.addWidget(self.parameterHintLabel)

        self.fitActionLayout = QHBoxLayout()
        self.fitActionLayout.setObjectName(u"fitActionLayout")
        self.fitActionSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.fitActionLayout.addItem(self.fitActionSpacer)

        self.previewButton = QPushButton(self.modelGroup)
        self.previewButton.setObjectName(u"previewButton")

        self.fitActionLayout.addWidget(self.previewButton)

        self.fitButton = QPushButton(self.modelGroup)
        self.fitButton.setObjectName(u"fitButton")

        self.fitActionLayout.addWidget(self.fitButton)


        self.modelGroupLayout.addLayout(self.fitActionLayout)


        self.fitPaneLayout.addWidget(self.modelGroup)

        self.fitScrollArea.setWidget(self.fitPane)
        self.setupSplitter.addWidget(self.fitScrollArea)

        self.fitSetupLayout.addWidget(self.setupSplitter)

        self.mainSplitter.addWidget(self.fitSetupGroup)
        self.resultsGroup = QGroupBox(self.mainSplitter)
        self.resultsGroup.setObjectName(u"resultsGroup")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(3)
        sizePolicy4.setHeightForWidth(self.resultsGroup.sizePolicy().hasHeightForWidth())
        self.resultsGroup.setSizePolicy(sizePolicy4)
        self.resultsGroupLayout = QVBoxLayout(self.resultsGroup)
        self.resultsGroupLayout.setObjectName(u"resultsGroupLayout")
        self.annotationModeLayout = QHBoxLayout()
        self.annotationModeLayout.setObjectName(u"annotationModeLayout")
        self.annotationModeLabel = QLabel(self.resultsGroup)
        self.annotationModeLabel.setObjectName(u"annotationModeLabel")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.annotationModeLabel.sizePolicy().hasHeightForWidth())
        self.annotationModeLabel.setSizePolicy(sizePolicy5)

        self.annotationModeLayout.addWidget(self.annotationModeLabel)

        self.equationAnnotationRadioButton = QRadioButton(self.resultsGroup)
        self.equationAnnotationRadioButton.setObjectName(u"equationAnnotationRadioButton")
        self.equationAnnotationRadioButton.setChecked(True)

        self.annotationModeLayout.addWidget(self.equationAnnotationRadioButton)

        self.parameterAnnotationRadioButton = QRadioButton(self.resultsGroup)
        self.parameterAnnotationRadioButton.setObjectName(u"parameterAnnotationRadioButton")

        self.annotationModeLayout.addWidget(self.parameterAnnotationRadioButton)

        self.parameterAnnotationSettingsButton = QPushButton(self.resultsGroup)
        self.parameterAnnotationSettingsButton.setObjectName(u"parameterAnnotationSettingsButton")

        self.annotationModeLayout.addWidget(self.parameterAnnotationSettingsButton)

        self.annotationModeSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.annotationModeLayout.addItem(self.annotationModeSpacer)


        self.resultsGroupLayout.addLayout(self.annotationModeLayout)

        self.statusLayout = QHBoxLayout()
        self.statusLayout.setObjectName(u"statusLayout")
        self.statusLabel = QLabel(self.resultsGroup)
        self.statusLabel.setObjectName(u"statusLabel")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum)
        sizePolicy6.setHorizontalStretch(1)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.statusLabel.sizePolicy().hasHeightForWidth())
        self.statusLabel.setSizePolicy(sizePolicy6)
        self.statusLabel.setWordWrap(True)

        self.statusLayout.addWidget(self.statusLabel)

        self.progressBar = QProgressBar(self.resultsGroup)
        self.progressBar.setObjectName(u"progressBar")
        self.progressBar.setMaximumSize(QSize(180, 16777215))
        self.progressBar.setMaximum(0)
        self.progressBar.setValue(-1)
        self.progressBar.setTextVisible(False)

        self.statusLayout.addWidget(self.progressBar)


        self.resultsGroupLayout.addLayout(self.statusLayout)

        self.resultsTable = QTableWidget(self.resultsGroup)
        if (self.resultsTable.columnCount() < 6):
            self.resultsTable.setColumnCount(6)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.resultsTable.setHorizontalHeaderItem(0, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.resultsTable.setHorizontalHeaderItem(1, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.resultsTable.setHorizontalHeaderItem(2, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.resultsTable.setHorizontalHeaderItem(3, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.resultsTable.setHorizontalHeaderItem(4, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.resultsTable.setHorizontalHeaderItem(5, __qtablewidgetitem10)
        self.resultsTable.setObjectName(u"resultsTable")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy7.setHorizontalStretch(1)
        sizePolicy7.setVerticalStretch(1)
        sizePolicy7.setHeightForWidth(self.resultsTable.sizePolicy().hasHeightForWidth())
        self.resultsTable.setSizePolicy(sizePolicy7)
        self.resultsTable.setMinimumSize(QSize(0, 70))
        self.resultsTable.setMaximumSize(QSize(16777215, 16777215))
        self.resultsTable.setAlternatingRowColors(True)
        self.resultsTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.resultsTable.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.resultsTable.setColumnCount(6)

        self.resultsGroupLayout.addWidget(self.resultsTable)

        self.selectedFitDetailsLabel = QLabel(self.resultsGroup)
        self.selectedFitDetailsLabel.setObjectName(u"selectedFitDetailsLabel")
        sizePolicy5.setHeightForWidth(self.selectedFitDetailsLabel.sizePolicy().hasHeightForWidth())
        self.selectedFitDetailsLabel.setSizePolicy(sizePolicy5)

        self.resultsGroupLayout.addWidget(self.selectedFitDetailsLabel)

        self.fitDetailsText = QPlainTextEdit(self.resultsGroup)
        self.fitDetailsText.setObjectName(u"fitDetailsText")
        sizePolicy6.setHeightForWidth(self.fitDetailsText.sizePolicy().hasHeightForWidth())
        self.fitDetailsText.setSizePolicy(sizePolicy6)
        self.fitDetailsText.setMinimumSize(QSize(0, 45))
        self.fitDetailsText.setMaximumSize(QSize(16777215, 90))
        self.fitDetailsText.setReadOnly(True)
        self.fitDetailsText.setTabChangesFocus(True)

        self.resultsGroupLayout.addWidget(self.fitDetailsText)

        self.mainSplitter.addWidget(self.resultsGroup)

        self.verticalLayout.addWidget(self.mainSplitter)

        self.bottomLayout = QHBoxLayout()
        self.bottomLayout.setObjectName(u"bottomLayout")
        self.removeFitButton = QPushButton(XYCurveFitDialog)
        self.removeFitButton.setObjectName(u"removeFitButton")

        self.bottomLayout.addWidget(self.removeFitButton)

        self.bottomSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.bottomLayout.addItem(self.bottomSpacer)

        self.buttonBox = QDialogButtonBox(XYCurveFitDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Apply|QDialogButtonBox.Cancel)

        self.bottomLayout.addWidget(self.buttonBox)


        self.verticalLayout.addLayout(self.bottomLayout)


        self.retranslateUi(XYCurveFitDialog)
        self.buttonBox.rejected.connect(XYCurveFitDialog.reject)

        self.fitButton.setDefault(True)


        QMetaObject.connectSlotsByName(XYCurveFitDialog)
    # setupUi

    def retranslateUi(self, XYCurveFitDialog):
        XYCurveFitDialog.setWindowTitle(QCoreApplication.translate("XYCurveFitDialog", u"Curve Fit", None))
        self.hintLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Choose the fit targets, model, and starting values in Fit setup. Chart annotations are controlled independently in Fit results.", None))
        self.fitSetupGroup.setTitle(QCoreApplication.translate("XYCurveFitDialog", u"1. Fit setup", None))
        self.seriesHeadingLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Series to fit", None))
        self.selectAllButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Select All", None))
        self.clearSelectionButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Clear", None))
#if QT_CONFIG(tooltip)
        self.seriesList.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Checked series will be fitted independently.", None))
#endif // QT_CONFIG(tooltip)
        self.seriesSummaryLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"No series selected", None))
        self.modelGroup.setTitle(QCoreApplication.translate("XYCurveFitDialog", u"Model and starting values", None))
        self.modelLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Curve model", None))
#if QT_CONFIG(tooltip)
        self.modelCombo.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Choose the shape that best describes your data.", None))
#endif // QT_CONFIG(tooltip)
        self.equationLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Equation", None))
        self.equationDisplayLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"\u2014", None))
        self.modelDescriptionLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Select a model to see when to use it.", None))
        self.customEquationLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"y =", None))
        self.customEquationEdit.setPlaceholderText(QCoreApplication.translate("XYCurveFitDialog", u"a * exp(-k * x) + c", None))
        self.insertTemplateLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Insert template", None))
#if QT_CONFIG(tooltip)
        self.insertSigmaButton.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Insert an inclusive finite-sum template.", None))
#endif // QT_CONFIG(tooltip)
        self.insertSigmaButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"\u03a3 Sum", None))
#if QT_CONFIG(tooltip)
        self.insertIntegralButton.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Insert a numerical-integral template.", None))
#endif // QT_CONFIG(tooltip)
        self.insertIntegralButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"\u222b Integral", None))
        self.functionTemplateLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Function", None))
#if QT_CONFIG(tooltip)
        self.functionCombo.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Choose a function to insert. ln(u) is the natural logarithm, log(u, base) uses a custom base, and log10(u) uses base 10. The log template starts with base 2; replace 2 with any positive value other than 1, or with a parameter. Trigonometric inputs and inverse-trigonometric results use radians.", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.insertFunctionButton.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Wrap the selected expression with this function, or insert a placeholder.", None))
#endif // QT_CONFIG(tooltip)
        self.insertFunctionButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Insert", None))
        self.customEquationHelpLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Use x for the horizontal axis; other names become parameters automatically. Functions include exp, ln, log(u, base), log10, sqrt, and abs; sin, cos, tan, asin, acos, atan, atan2, sec, csc, and cot; and sinh, cosh, and tanh. ln(u) is the natural logarithm, log(u, base) uses a custom base, and log10(u) uses base 10. For logarithms, u must be positive; a custom base must also be positive and not equal to 1. The log template starts with base 2; replace 2 with another valid value or a parameter name. Trigonometric angles and inverse-trigonometric results use radians. \u03a3(k, 1, 5, expression) is an inclusive finite sum. \u222b(t, 0, x, expression), or integral(t, 0, x, expression), is evaluated numerically.", None))
        ___qtablewidgetitem = self.parameterTable.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("XYCurveFitDialog", u"Parameter", None))
        ___qtablewidgetitem1 = self.parameterTable.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("XYCurveFitDialog", u"Starting value", None))
        ___qtablewidgetitem2 = self.parameterTable.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("XYCurveFitDialog", u"Lower bound", None))
        ___qtablewidgetitem3 = self.parameterTable.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("XYCurveFitDialog", u"Upper bound", None))
        ___qtablewidgetitem4 = self.parameterTable.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("XYCurveFitDialog", u"Fixed", None))
#if QT_CONFIG(tooltip)
        self.parameterTable.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Starting values help nonlinear fitting converge. Leave a bound empty for no limit.", None))
#endif // QT_CONFIG(tooltip)
        self.parameterHintLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"EasyGraph supplies starting values automatically. Edit them only when the initial curve is far from your data.", None))
#if QT_CONFIG(tooltip)
        self.previewButton.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Show the curve produced by the current starting values without fitting.", None))
#endif // QT_CONFIG(tooltip)
        self.previewButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Preview Starting Curve", None))
        self.fitButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Fit Selected Series", None))
        self.resultsGroup.setTitle(QCoreApplication.translate("XYCurveFitDialog", u"2. Fit results", None))
        self.annotationModeLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Chart annotation", None))
#if QT_CONFIG(tooltip)
        self.equationAnnotationRadioButton.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Show the fitted equation for every result whose Display switch is on.", None))
#endif // QT_CONFIG(tooltip)
        self.equationAnnotationRadioButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Fitted equation", None))
#if QT_CONFIG(tooltip)
        self.parameterAnnotationRadioButton.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Show selected fitted parameter values for every result whose Display switch is on.", None))
#endif // QT_CONFIG(tooltip)
        self.parameterAnnotationRadioButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Parameter values", None))
#if QT_CONFIG(tooltip)
        self.parameterAnnotationSettingsButton.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Choose which fitted parameters are shown for each result.", None))
#endif // QT_CONFIG(tooltip)
        self.parameterAnnotationSettingsButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Parameter Display Settings\u2026", None))
        self.statusLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Ready to fit.", None))
        ___qtablewidgetitem5 = self.resultsTable.horizontalHeaderItem(0)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("XYCurveFitDialog", u"Display", None))
        ___qtablewidgetitem6 = self.resultsTable.horizontalHeaderItem(1)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("XYCurveFitDialog", u"Series", None))
        ___qtablewidgetitem7 = self.resultsTable.horizontalHeaderItem(2)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("XYCurveFitDialog", u"Status", None))
        ___qtablewidgetitem8 = self.resultsTable.horizontalHeaderItem(3)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("XYCurveFitDialog", u"R\u00b2", None))
        ___qtablewidgetitem9 = self.resultsTable.horizontalHeaderItem(4)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("XYCurveFitDialog", u"RMSE", None))
        ___qtablewidgetitem10 = self.resultsTable.horizontalHeaderItem(5)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("XYCurveFitDialog", u"Parameters", None))
        self.selectedFitDetailsLabel.setText(QCoreApplication.translate("XYCurveFitDialog", u"Selected fit details", None))
#if QT_CONFIG(tooltip)
        self.selectedFitDetailsLabel.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"R\u00b2 closer to 1 and smaller error values generally indicate a closer fit. Confidence intervals summarize parameter uncertainty.", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.fitDetailsText.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Select a result row to review fit quality and parameter uncertainty.", None))
#endif // QT_CONFIG(tooltip)
        self.fitDetailsText.setPlaceholderText(QCoreApplication.translate("XYCurveFitDialog", u"Select a fitted row to see full statistics.", None))
#if QT_CONFIG(tooltip)
        self.removeFitButton.setToolTip(QCoreApplication.translate("XYCurveFitDialog", u"Remove saved fits from the checked series when you apply.", None))
#endif // QT_CONFIG(tooltip)
        self.removeFitButton.setText(QCoreApplication.translate("XYCurveFitDialog", u"Remove Fit", None))
    # retranslateUi
