# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'prism_import_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QDialog,
    QDialogButtonBox, QHBoxLayout, QHeaderView, QLabel,
    QListWidget, QListWidgetItem, QPushButton, QSizePolicy,
    QSpacerItem, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget)

class Ui_PrismImportDialog(object):
    def setupUi(self, PrismImportDialog):
        if not PrismImportDialog.objectName():
            PrismImportDialog.setObjectName(u"PrismImportDialog")
        PrismImportDialog.resize(760, 620)
        PrismImportDialog.setMinimumSize(QSize(640, 520))
        self.verticalLayout = QVBoxLayout(PrismImportDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.sourceLabel = QLabel(PrismImportDialog)
        self.sourceLabel.setObjectName(u"sourceLabel")
        self.sourceLabel.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self.verticalLayout.addWidget(self.sourceLabel)

        self.tableSelectionLayout = QHBoxLayout()
        self.tableSelectionLayout.setObjectName(u"tableSelectionLayout")
        self.tableLabel = QLabel(PrismImportDialog)
        self.tableLabel.setObjectName(u"tableLabel")

        self.tableSelectionLayout.addWidget(self.tableLabel)

        self.tableSelectionSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.tableSelectionLayout.addItem(self.tableSelectionSpacer)

        self.selectedCountLabel = QLabel(PrismImportDialog)
        self.selectedCountLabel.setObjectName(u"selectedCountLabel")

        self.tableSelectionLayout.addWidget(self.selectedCountLabel)

        self.selectAllSupportedButton = QPushButton(PrismImportDialog)
        self.selectAllSupportedButton.setObjectName(u"selectAllSupportedButton")

        self.tableSelectionLayout.addWidget(self.selectAllSupportedButton)

        self.clearSelectionButton = QPushButton(PrismImportDialog)
        self.clearSelectionButton.setObjectName(u"clearSelectionButton")

        self.tableSelectionLayout.addWidget(self.clearSelectionButton)


        self.verticalLayout.addLayout(self.tableSelectionLayout)

        self.tableListWidget = QListWidget(PrismImportDialog)
        self.tableListWidget.setObjectName(u"tableListWidget")
        self.tableListWidget.setMinimumSize(QSize(0, 120))
        self.tableListWidget.setMaximumSize(QSize(16777215, 180))
        self.tableListWidget.setAlternatingRowColors(True)
        self.tableListWidget.setSelectionMode(QAbstractItemView.SingleSelection)

        self.verticalLayout.addWidget(self.tableListWidget)

        self.summaryLabel = QLabel(PrismImportDialog)
        self.summaryLabel.setObjectName(u"summaryLabel")
        self.summaryLabel.setWordWrap(True)
        self.summaryLabel.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self.verticalLayout.addWidget(self.summaryLabel)

        self.warningLabel = QLabel(PrismImportDialog)
        self.warningLabel.setObjectName(u"warningLabel")
        self.warningLabel.setWordWrap(True)
        self.warningLabel.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self.verticalLayout.addWidget(self.warningLabel)

        self.previewTable = QTableWidget(PrismImportDialog)
        self.previewTable.setObjectName(u"previewTable")
        self.previewTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.previewTable.setAlternatingRowColors(True)
        self.previewTable.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.previewTable.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.previewTable.setShowGrid(True)

        self.verticalLayout.addWidget(self.previewTable)

        self.previewLimitLabel = QLabel(PrismImportDialog)
        self.previewLimitLabel.setObjectName(u"previewLimitLabel")

        self.verticalLayout.addWidget(self.previewLimitLabel)

        self.buttonBox = QDialogButtonBox(PrismImportDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.verticalLayout.addWidget(self.buttonBox)

#if QT_CONFIG(shortcut)
        self.tableLabel.setBuddy(self.tableListWidget)
#endif // QT_CONFIG(shortcut)
        QWidget.setTabOrder(self.tableListWidget, self.selectAllSupportedButton)
        QWidget.setTabOrder(self.selectAllSupportedButton, self.clearSelectionButton)
        QWidget.setTabOrder(self.clearSelectionButton, self.previewTable)

        self.retranslateUi(PrismImportDialog)
        self.buttonBox.accepted.connect(PrismImportDialog.accept)
        self.buttonBox.rejected.connect(PrismImportDialog.reject)

        QMetaObject.connectSlotsByName(PrismImportDialog)
    # setupUi

    def retranslateUi(self, PrismImportDialog):
        PrismImportDialog.setWindowTitle(QCoreApplication.translate("PrismImportDialog", u"Import Prism PZFX", None))
        self.sourceLabel.setText(QCoreApplication.translate("PrismImportDialog", u"Prism source", None))
        self.tableLabel.setText(QCoreApplication.translate("PrismImportDialog", u"Data tables:", None))
        self.selectedCountLabel.setText(QCoreApplication.translate("PrismImportDialog", u"0 tables selected", None))
        self.selectAllSupportedButton.setText(QCoreApplication.translate("PrismImportDialog", u"Select All Supported", None))
        self.clearSelectionButton.setText(QCoreApplication.translate("PrismImportDialog", u"Clear", None))
        self.summaryLabel.setText(QCoreApplication.translate("PrismImportDialog", u"Table summary", None))
        self.warningLabel.setText("")
        self.previewLimitLabel.setText(QCoreApplication.translate("PrismImportDialog", u"Preview shows at most 20 rows and 12 groups.", None))
    # retranslateUi
