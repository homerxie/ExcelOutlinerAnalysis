# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'group_colors_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QHBoxLayout, QLabel, QScrollArea, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

from easygraph.ui.palette_combo import PaletteComboBox

class Ui_GroupColorsDialog(object):
    def setupUi(self, GroupColorsDialog):
        if not GroupColorsDialog.objectName():
            GroupColorsDialog.setObjectName(u"GroupColorsDialog")
        GroupColorsDialog.resize(700, 520)
        GroupColorsDialog.setModal(True)
        self.verticalLayout = QVBoxLayout(GroupColorsDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.paletteRow = QWidget(GroupColorsDialog)
        self.paletteRow.setObjectName(u"paletteRow")
        self.paletteRowLayout = QHBoxLayout(self.paletteRow)
        self.paletteRowLayout.setObjectName(u"paletteRowLayout")
        self.paletteRowLayout.setContentsMargins(0, 0, 0, 0)
        self.paletteLabel = QLabel(self.paletteRow)
        self.paletteLabel.setObjectName(u"paletteLabel")

        self.paletteRowLayout.addWidget(self.paletteLabel)

        self.paletteCombo = PaletteComboBox(self.paletteRow)
        self.paletteCombo.setObjectName(u"paletteCombo")

        self.paletteRowLayout.addWidget(self.paletteCombo)

        self.paletteSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.paletteRowLayout.addItem(self.paletteSpacer)


        self.verticalLayout.addWidget(self.paletteRow)

        self.overlayPaletteRow = QWidget(GroupColorsDialog)
        self.overlayPaletteRow.setObjectName(u"overlayPaletteRow")
        self.overlayPaletteRowLayout = QHBoxLayout(self.overlayPaletteRow)
        self.overlayPaletteRowLayout.setObjectName(u"overlayPaletteRowLayout")
        self.overlayPaletteRowLayout.setContentsMargins(0, 0, 0, 0)
        self.overlayPaletteLabel = QLabel(self.overlayPaletteRow)
        self.overlayPaletteLabel.setObjectName(u"overlayPaletteLabel")

        self.overlayPaletteRowLayout.addWidget(self.overlayPaletteLabel)

        self.overlayPaletteCombo = PaletteComboBox(self.overlayPaletteRow)
        self.overlayPaletteCombo.setObjectName(u"overlayPaletteCombo")

        self.overlayPaletteRowLayout.addWidget(self.overlayPaletteCombo)

        self.overlayPaletteSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.overlayPaletteRowLayout.addItem(self.overlayPaletteSpacer)


        self.verticalLayout.addWidget(self.overlayPaletteRow)

        self.guidePaletteRow = QWidget(GroupColorsDialog)
        self.guidePaletteRow.setObjectName(u"guidePaletteRow")
        self.guidePaletteRowLayout = QHBoxLayout(self.guidePaletteRow)
        self.guidePaletteRowLayout.setObjectName(u"guidePaletteRowLayout")
        self.guidePaletteRowLayout.setContentsMargins(0, 0, 0, 0)
        self.guidePaletteLabel = QLabel(self.guidePaletteRow)
        self.guidePaletteLabel.setObjectName(u"guidePaletteLabel")

        self.guidePaletteRowLayout.addWidget(self.guidePaletteLabel)

        self.guidePaletteCombo = PaletteComboBox(self.guidePaletteRow)
        self.guidePaletteCombo.setObjectName(u"guidePaletteCombo")

        self.guidePaletteRowLayout.addWidget(self.guidePaletteCombo)

        self.guidePaletteSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.guidePaletteRowLayout.addItem(self.guidePaletteSpacer)


        self.verticalLayout.addWidget(self.guidePaletteRow)

        self.hintLabel = QLabel(GroupColorsDialog)
        self.hintLabel.setObjectName(u"hintLabel")
        self.hintLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.hintLabel)

        self.rowsScroll = QScrollArea(GroupColorsDialog)
        self.rowsScroll.setObjectName(u"rowsScroll")
        self.rowsScroll.setMinimumSize(QSize(620, 260))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.rowsScroll.sizePolicy().hasHeightForWidth())
        self.rowsScroll.setSizePolicy(sizePolicy)
        self.rowsScroll.setWidgetResizable(True)
        self.rowsContainer = QWidget()
        self.rowsContainer.setObjectName(u"rowsContainer")
        self.rowsContainer.setGeometry(QRect(0, 0, 458, 218))
        self.rowsLayout = QVBoxLayout(self.rowsContainer)
        self.rowsLayout.setSpacing(6)
        self.rowsLayout.setObjectName(u"rowsLayout")
        self.rowsLayout.setContentsMargins(0, 0, 0, 0)
        self.rowsScroll.setWidget(self.rowsContainer)

        self.verticalLayout.addWidget(self.rowsScroll)

        self.buttonBox = QDialogButtonBox(GroupColorsDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(GroupColorsDialog)
        self.buttonBox.accepted.connect(GroupColorsDialog.accept)
        self.buttonBox.rejected.connect(GroupColorsDialog.reject)

        QMetaObject.connectSlotsByName(GroupColorsDialog)
    # setupUi

    def retranslateUi(self, GroupColorsDialog):
        GroupColorsDialog.setWindowTitle(QCoreApplication.translate("GroupColorsDialog", u"Edit Group Colors", None))
        self.paletteLabel.setText(QCoreApplication.translate("GroupColorsDialog", u"Palette", None))
        self.overlayPaletteLabel.setText(QCoreApplication.translate("GroupColorsDialog", u"Overlay palette", None))
        self.guidePaletteLabel.setText(QCoreApplication.translate("GroupColorsDialog", u"Guide palette", None))
        self.hintLabel.setText(QCoreApplication.translate("GroupColorsDialog", u"Choose a color for each item. Changes preview immediately.", None))
    # retranslateUi

