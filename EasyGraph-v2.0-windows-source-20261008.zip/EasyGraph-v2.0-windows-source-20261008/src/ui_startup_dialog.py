# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'startup_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QDialog,
    QFormLayout, QFrame, QHBoxLayout, QHeaderView,
    QLabel, QPushButton, QRadioButton, QSizePolicy,
    QSpacerItem, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget)

class Ui_StartupDialog(object):
    def setupUi(self, StartupDialog):
        if not StartupDialog.objectName():
            StartupDialog.setObjectName(u"StartupDialog")
        StartupDialog.resize(640, 620)
        StartupDialog.setMinimumSize(QSize(540, 560))
        StartupDialog.setModal(True)
        self.verticalLayout = QVBoxLayout(StartupDialog)
        self.verticalLayout.setSpacing(12)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(24, 22, 24, 20)
        self.titleLabel = QLabel(StartupDialog)
        self.titleLabel.setObjectName(u"titleLabel")
        font = QFont()
        font.setPointSize(18)
        font.setBold(True)
        self.titleLabel.setFont(font)

        self.verticalLayout.addWidget(self.titleLabel)

        self.subtitleLabel = QLabel(StartupDialog)
        self.subtitleLabel.setObjectName(u"subtitleLabel")
        self.subtitleLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.subtitleLabel)

        self.sheetTypeLabel = QLabel(StartupDialog)
        self.sheetTypeLabel.setObjectName(u"sheetTypeLabel")
        font1 = QFont()
        font1.setBold(True)
        self.sheetTypeLabel.setFont(font1)

        self.verticalLayout.addWidget(self.sheetTypeLabel)

        self.sheetTypeLayout = QHBoxLayout()
        self.sheetTypeLayout.setSpacing(20)
        self.sheetTypeLayout.setObjectName(u"sheetTypeLayout")
        self.groupRadioButton = QRadioButton(StartupDialog)
        self.groupRadioButton.setObjectName(u"groupRadioButton")
        self.groupRadioButton.setText(u"Group")
        self.groupRadioButton.setChecked(True)

        self.sheetTypeLayout.addWidget(self.groupRadioButton)

        self.xyRadioButton = QRadioButton(StartupDialog)
        self.xyRadioButton.setObjectName(u"xyRadioButton")
        self.xyRadioButton.setText(u"XY")

        self.sheetTypeLayout.addWidget(self.xyRadioButton)

        self.sheetTypeSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.sheetTypeLayout.addItem(self.sheetTypeSpacer)


        self.verticalLayout.addLayout(self.sheetTypeLayout)

        self.typeHelpLabel = QLabel(StartupDialog)
        self.typeHelpLabel.setObjectName(u"typeHelpLabel")
        self.typeHelpLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.typeHelpLabel)

        self.demoPresetLayout = QFormLayout()
        self.demoPresetLayout.setObjectName(u"demoPresetLayout")
        self.demoPresetLabel = QLabel(StartupDialog)
        self.demoPresetLabel.setObjectName(u"demoPresetLabel")

        self.demoPresetLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.demoPresetLabel)

        self.demoPresetCombo = QComboBox(StartupDialog)
        self.demoPresetCombo.setObjectName(u"demoPresetCombo")

        self.demoPresetLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.demoPresetCombo)


        self.verticalLayout.addLayout(self.demoPresetLayout)

        self.actionLayout = QHBoxLayout()
        self.actionLayout.setSpacing(10)
        self.actionLayout.setObjectName(u"actionLayout")
        self.demoButton = QPushButton(StartupDialog)
        self.demoButton.setObjectName(u"demoButton")
        self.demoButton.setMinimumSize(QSize(0, 32))
        self.demoButton.setAutoDefault(True)

        self.actionLayout.addWidget(self.demoButton)

        self.blankButton = QPushButton(StartupDialog)
        self.blankButton.setObjectName(u"blankButton")
        self.blankButton.setMinimumSize(QSize(0, 32))
        self.blankButton.setAutoDefault(True)

        self.actionLayout.addWidget(self.blankButton)


        self.verticalLayout.addLayout(self.actionLayout)

        self.projectNoteLabel = QLabel(StartupDialog)
        self.projectNoteLabel.setObjectName(u"projectNoteLabel")
        self.projectNoteLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.projectNoteLabel)

        self.recentSeparator = QFrame(StartupDialog)
        self.recentSeparator.setObjectName(u"recentSeparator")
        self.recentSeparator.setFrameShape(QFrame.Shape.HLine)
        self.recentSeparator.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout.addWidget(self.recentSeparator)

        self.recentProjectsLabel = QLabel(StartupDialog)
        self.recentProjectsLabel.setObjectName(u"recentProjectsLabel")
        self.recentProjectsLabel.setFont(font1)

        self.verticalLayout.addWidget(self.recentProjectsLabel)

        self.recentProjectsTable = QTableWidget(StartupDialog)
        if (self.recentProjectsTable.columnCount() < 2):
            self.recentProjectsTable.setColumnCount(2)
        __qtablewidgetitem = QTableWidgetItem()
        self.recentProjectsTable.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.recentProjectsTable.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        self.recentProjectsTable.setObjectName(u"recentProjectsTable")
        self.recentProjectsTable.setMinimumSize(QSize(0, 150))
        self.recentProjectsTable.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.recentProjectsTable.setAlternatingRowColors(True)
        self.recentProjectsTable.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.recentProjectsTable.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.recentProjectsTable.setShowGrid(False)
        self.recentProjectsTable.verticalHeader().setVisible(False)

        self.verticalLayout.addWidget(self.recentProjectsTable)

        self.recentEmptyLabel = QLabel(StartupDialog)
        self.recentEmptyLabel.setObjectName(u"recentEmptyLabel")
        self.recentEmptyLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.recentEmptyLabel)

        self.cancelLayout = QHBoxLayout()
        self.cancelLayout.setObjectName(u"cancelLayout")
        self.openRecentButton = QPushButton(StartupDialog)
        self.openRecentButton.setObjectName(u"openRecentButton")
        self.openRecentButton.setEnabled(False)
        self.openRecentButton.setMinimumSize(QSize(0, 32))
        self.openRecentButton.setAutoDefault(True)

        self.cancelLayout.addWidget(self.openRecentButton)

        self.cancelSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.cancelLayout.addItem(self.cancelSpacer)

        self.cancelButton = QPushButton(StartupDialog)
        self.cancelButton.setObjectName(u"cancelButton")
        self.cancelButton.setMinimumSize(QSize(0, 32))
        self.cancelButton.setAutoDefault(True)

        self.cancelLayout.addWidget(self.cancelButton)


        self.verticalLayout.addLayout(self.cancelLayout)

#if QT_CONFIG(shortcut)
        self.demoPresetLabel.setBuddy(self.demoPresetCombo)
        self.recentProjectsLabel.setBuddy(self.recentProjectsTable)
#endif // QT_CONFIG(shortcut)
        QWidget.setTabOrder(self.groupRadioButton, self.xyRadioButton)
        QWidget.setTabOrder(self.xyRadioButton, self.demoPresetCombo)
        QWidget.setTabOrder(self.demoPresetCombo, self.demoButton)
        QWidget.setTabOrder(self.demoButton, self.blankButton)
        QWidget.setTabOrder(self.blankButton, self.recentProjectsTable)
        QWidget.setTabOrder(self.recentProjectsTable, self.openRecentButton)
        QWidget.setTabOrder(self.openRecentButton, self.cancelButton)

        self.retranslateUi(StartupDialog)
        self.cancelButton.clicked.connect(StartupDialog.reject)

        self.demoButton.setDefault(True)


        QMetaObject.connectSlotsByName(StartupDialog)
    # setupUi

    def retranslateUi(self, StartupDialog):
        StartupDialog.setWindowTitle(QCoreApplication.translate("StartupDialog", u"Welcome to EasyGraph", None))
        self.titleLabel.setText(QCoreApplication.translate("StartupDialog", u"Choose your first Sheet", None))
        self.subtitleLabel.setText(QCoreApplication.translate("StartupDialog", u"Select its chart type, then start with example data or a blank table.", None))
        self.sheetTypeLabel.setText(QCoreApplication.translate("StartupDialog", u"First Sheet type", None))
        self.typeHelpLabel.setText(QCoreApplication.translate("StartupDialog", u"Group supports Box, Bar, Violin, and Ridge charts. XY supports points, lines, and combined plots.", None))
        self.demoPresetLabel.setText(QCoreApplication.translate("StartupDialog", u"Demo example", None))
        self.demoButton.setText(QCoreApplication.translate("StartupDialog", u"Open Demo", None))
        self.blankButton.setText(QCoreApplication.translate("StartupDialog", u"Create Blank", None))
        self.projectNoteLabel.setText(QCoreApplication.translate("StartupDialog", u"A project file can contain both Group and XY Sheets. This choice only determines the first Sheet.", None))
        self.recentProjectsLabel.setText(QCoreApplication.translate("StartupDialog", u"Recent projects", None))
        ___qtablewidgetitem = self.recentProjectsTable.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("StartupDialog", u"Project", None))
        ___qtablewidgetitem1 = self.recentProjectsTable.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("StartupDialog", u"Location", None))
#if QT_CONFIG(accessibility)
        self.recentProjectsTable.setAccessibleName(QCoreApplication.translate("StartupDialog", u"Recent projects", None))
#endif // QT_CONFIG(accessibility)
        self.recentEmptyLabel.setText(QCoreApplication.translate("StartupDialog", u"No recent projects yet. Projects you open or save will appear here.", None))
        self.openRecentButton.setText(QCoreApplication.translate("StartupDialog", u"Open selected project", None))
        self.cancelButton.setText(QCoreApplication.translate("StartupDialog", u"Cancel", None))
    # retranslateUi

