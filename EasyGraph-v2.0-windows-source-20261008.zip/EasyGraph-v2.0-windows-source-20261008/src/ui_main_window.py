# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QDoubleSpinBox, QFormLayout, QFrame, QGridLayout,
    QGroupBox, QHBoxLayout, QHeaderView, QLabel,
    QListWidget, QListWidgetItem, QMainWindow, QMenu,
    QMenuBar, QPlainTextEdit, QPushButton, QRadioButton,
    QScrollArea, QSizePolicy, QSpacerItem, QSpinBox,
    QSplitter, QStatusBar, QTabBar, QTabWidget,
    QTableWidget, QTableWidgetItem, QToolButton, QVBoxLayout,
    QWidget)

from easygraph.data_table import DataTable
from easygraph.ui.analysis_results_table import AnalysisResultsTable
from easygraph.ui.palette_combo import PaletteComboBox

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1103, 759)
        self.actionNew = QAction(MainWindow)
        self.actionNew.setObjectName(u"actionNew")
        self.actionOpenProject = QAction(MainWindow)
        self.actionOpenProject.setObjectName(u"actionOpenProject")
        self.actionSaveProject = QAction(MainWindow)
        self.actionSaveProject.setObjectName(u"actionSaveProject")
        self.actionSaveProjectAs = QAction(MainWindow)
        self.actionSaveProjectAs.setObjectName(u"actionSaveProjectAs")
        self.actionImportExcel = QAction(MainWindow)
        self.actionImportExcel.setObjectName(u"actionImportExcel")
        self.actionImportPrism = QAction(MainWindow)
        self.actionImportPrism.setObjectName(u"actionImportPrism")
        self.actionExportExcel = QAction(MainWindow)
        self.actionExportExcel.setObjectName(u"actionExportExcel")
        self.actionCopyFigure = QAction(MainWindow)
        self.actionCopyFigure.setObjectName(u"actionCopyFigure")
        self.actionExportFigure = QAction(MainWindow)
        self.actionExportFigure.setObjectName(u"actionExportFigure")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralLayout = QVBoxLayout(self.centralwidget)
        self.centralLayout.setObjectName(u"centralLayout")
        self.centralLayout.setContentsMargins(10, 5, 10, 5)
        self.topToolsTabs = QTabWidget(self.centralwidget)
        self.topToolsTabs.setObjectName(u"topToolsTabs")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.topToolsTabs.sizePolicy().hasHeightForWidth())
        self.topToolsTabs.setSizePolicy(sizePolicy)
        self.topToolsTabs.setDocumentMode(True)
        self.chartToolsPage = QWidget()
        self.chartToolsPage.setObjectName(u"chartToolsPage")
        self.chartToolsPageLayout = QVBoxLayout(self.chartToolsPage)
        self.chartToolsPageLayout.setObjectName(u"chartToolsPageLayout")
        self.chartToolsPageLayout.setContentsMargins(0, 0, 0, 0)
        self.topToolbarWidget = QFrame(self.chartToolsPage)
        self.topToolbarWidget.setObjectName(u"topToolbarWidget")
        sizePolicy.setHeightForWidth(self.topToolbarWidget.sizePolicy().hasHeightForWidth())
        self.topToolbarWidget.setSizePolicy(sizePolicy)
        self.topToolbarWidget.setFrameShape(QFrame.Shape.Box)
        self.topToolbarWidget.setFrameShadow(QFrame.Shadow.Plain)
        self.topToolbarLayout = QGridLayout(self.topToolbarWidget)
        self.topToolbarLayout.setObjectName(u"topToolbarLayout")
        self.topToolbarLayout.setHorizontalSpacing(8)
        self.topToolbarLayout.setVerticalSpacing(4)
        self.topToolbarLayout.setContentsMargins(8, 4, 8, 4)
        self.copyToolbarLabel = QLabel(self.topToolbarWidget)
        self.copyToolbarLabel.setObjectName(u"copyToolbarLabel")
        sizePolicy.setHeightForWidth(self.copyToolbarLabel.sizePolicy().hasHeightForWidth())
        self.copyToolbarLabel.setSizePolicy(sizePolicy)

        self.topToolbarLayout.addWidget(self.copyToolbarLabel, 0, 0, 1, 1)

        self.copyImageButton = QToolButton(self.topToolbarWidget)
        self.copyImageButton.setObjectName(u"copyImageButton")

        self.topToolbarLayout.addWidget(self.copyImageButton, 1, 0, 1, 1)

        self.copyStatisticsButton = QToolButton(self.topToolbarWidget)
        self.copyStatisticsButton.setObjectName(u"copyStatisticsButton")

        self.topToolbarLayout.addWidget(self.copyStatisticsButton, 2, 0, 1, 1)

        self.groupFilterButton = QToolButton(self.topToolbarWidget)
        self.groupFilterButton.setObjectName(u"groupFilterButton")

        self.topToolbarLayout.addWidget(self.groupFilterButton, 3, 0, 1, 1)

        self.copyToolbarSeparator = QFrame(self.topToolbarWidget)
        self.copyToolbarSeparator.setObjectName(u"copyToolbarSeparator")
        self.copyToolbarSeparator.setFrameShape(QFrame.Shape.VLine)
        self.copyToolbarSeparator.setFrameShadow(QFrame.Shadow.Sunken)

        self.topToolbarLayout.addWidget(self.copyToolbarSeparator, 0, 1, 4, 1)

        self.fontToolbarLabel = QLabel(self.topToolbarWidget)
        self.fontToolbarLabel.setObjectName(u"fontToolbarLabel")
        sizePolicy.setHeightForWidth(self.fontToolbarLabel.sizePolicy().hasHeightForWidth())
        self.fontToolbarLabel.setSizePolicy(sizePolicy)

        self.topToolbarLayout.addWidget(self.fontToolbarLabel, 0, 2, 1, 5)

        self.increaseAllFontsButton = QToolButton(self.topToolbarWidget)
        self.increaseAllFontsButton.setObjectName(u"increaseAllFontsButton")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.increaseAllFontsButton.sizePolicy().hasHeightForWidth())
        self.increaseAllFontsButton.setSizePolicy(sizePolicy1)

        self.topToolbarLayout.addWidget(self.increaseAllFontsButton, 1, 2, 1, 1)

        self.decreaseAllFontsButton = QToolButton(self.topToolbarWidget)
        self.decreaseAllFontsButton.setObjectName(u"decreaseAllFontsButton")
        sizePolicy1.setHeightForWidth(self.decreaseAllFontsButton.sizePolicy().hasHeightForWidth())
        self.decreaseAllFontsButton.setSizePolicy(sizePolicy1)

        self.topToolbarLayout.addWidget(self.decreaseAllFontsButton, 2, 2, 1, 1)

        self.toolbarTitleSizeLabel = QLabel(self.topToolbarWidget)
        self.toolbarTitleSizeLabel.setObjectName(u"toolbarTitleSizeLabel")

        self.topToolbarLayout.addWidget(self.toolbarTitleSizeLabel, 1, 3, 1, 1)

        self.titleFontSizeSpin = QSpinBox(self.topToolbarWidget)
        self.titleFontSizeSpin.setObjectName(u"titleFontSizeSpin")
        self.titleFontSizeSpin.setMinimum(6)
        self.titleFontSizeSpin.setMaximum(60)

        self.topToolbarLayout.addWidget(self.titleFontSizeSpin, 1, 4, 1, 1)

        self.toolbarAxisSizeLabel = QLabel(self.topToolbarWidget)
        self.toolbarAxisSizeLabel.setObjectName(u"toolbarAxisSizeLabel")

        self.topToolbarLayout.addWidget(self.toolbarAxisSizeLabel, 1, 5, 1, 1)

        self.axisLabelFontSizeSpin = QSpinBox(self.topToolbarWidget)
        self.axisLabelFontSizeSpin.setObjectName(u"axisLabelFontSizeSpin")
        self.axisLabelFontSizeSpin.setMinimum(6)
        self.axisLabelFontSizeSpin.setMaximum(48)

        self.topToolbarLayout.addWidget(self.axisLabelFontSizeSpin, 1, 6, 1, 1)

        self.toolbarTickSizeLabel = QLabel(self.topToolbarWidget)
        self.toolbarTickSizeLabel.setObjectName(u"toolbarTickSizeLabel")

        self.topToolbarLayout.addWidget(self.toolbarTickSizeLabel, 2, 3, 1, 1)

        self.tickFontSizeSpin = QSpinBox(self.topToolbarWidget)
        self.tickFontSizeSpin.setObjectName(u"tickFontSizeSpin")
        self.tickFontSizeSpin.setMinimum(5)
        self.tickFontSizeSpin.setMaximum(36)

        self.topToolbarLayout.addWidget(self.tickFontSizeSpin, 2, 4, 1, 1)

        self.toolbarLegendSizeLabel = QLabel(self.topToolbarWidget)
        self.toolbarLegendSizeLabel.setObjectName(u"toolbarLegendSizeLabel")

        self.topToolbarLayout.addWidget(self.toolbarLegendSizeLabel, 2, 5, 1, 1)

        self.legendFontSizeSpin = QSpinBox(self.topToolbarWidget)
        self.legendFontSizeSpin.setObjectName(u"legendFontSizeSpin")
        self.legendFontSizeSpin.setMinimum(5)
        self.legendFontSizeSpin.setMaximum(36)
        self.legendFontSizeSpin.setValue(10)

        self.topToolbarLayout.addWidget(self.legendFontSizeSpin, 2, 6, 1, 1)

        self.lineValueSizeLabel = QLabel(self.topToolbarWidget)
        self.lineValueSizeLabel.setObjectName(u"lineValueSizeLabel")

        self.topToolbarLayout.addWidget(self.lineValueSizeLabel, 3, 3, 1, 1)

        self.lineValueFontSizeSpin = QSpinBox(self.topToolbarWidget)
        self.lineValueFontSizeSpin.setObjectName(u"lineValueFontSizeSpin")
        self.lineValueFontSizeSpin.setMinimum(5)
        self.lineValueFontSizeSpin.setMaximum(36)
        self.lineValueFontSizeSpin.setValue(9)

        self.topToolbarLayout.addWidget(self.lineValueFontSizeSpin, 3, 4, 1, 1)

        self.additionalGuideFontSizeLabel = QLabel(self.topToolbarWidget)
        self.additionalGuideFontSizeLabel.setObjectName(u"additionalGuideFontSizeLabel")
        self.additionalGuideFontSizeLabel.setVisible(False)

        self.topToolbarLayout.addWidget(self.additionalGuideFontSizeLabel, 3, 3, 1, 1)

        self.additionalGuideFontSizeSpin = QSpinBox(self.topToolbarWidget)
        self.additionalGuideFontSizeSpin.setObjectName(u"additionalGuideFontSizeSpin")
        self.additionalGuideFontSizeSpin.setVisible(False)
        self.additionalGuideFontSizeSpin.setMinimum(5)
        self.additionalGuideFontSizeSpin.setMaximum(36)
        self.additionalGuideFontSizeSpin.setValue(10)

        self.topToolbarLayout.addWidget(self.additionalGuideFontSizeSpin, 3, 4, 1, 1)

        self.statTableSizeLabel = QLabel(self.topToolbarWidget)
        self.statTableSizeLabel.setObjectName(u"statTableSizeLabel")

        self.topToolbarLayout.addWidget(self.statTableSizeLabel, 3, 5, 1, 1)

        self.statTableFontSizeSpin = QSpinBox(self.topToolbarWidget)
        self.statTableFontSizeSpin.setObjectName(u"statTableFontSizeSpin")
        self.statTableFontSizeSpin.setMinimum(5)
        self.statTableFontSizeSpin.setMaximum(36)
        self.statTableFontSizeSpin.setValue(9)

        self.topToolbarLayout.addWidget(self.statTableFontSizeSpin, 3, 6, 1, 1)

        self.fontToolbarSeparator = QFrame(self.topToolbarWidget)
        self.fontToolbarSeparator.setObjectName(u"fontToolbarSeparator")
        self.fontToolbarSeparator.setFrameShape(QFrame.Shape.VLine)
        self.fontToolbarSeparator.setFrameShadow(QFrame.Shadow.Sunken)

        self.topToolbarLayout.addWidget(self.fontToolbarSeparator, 0, 7, 4, 1)

        self.chartToolbarLabel = QLabel(self.topToolbarWidget)
        self.chartToolbarLabel.setObjectName(u"chartToolbarLabel")
        sizePolicy.setHeightForWidth(self.chartToolbarLabel.sizePolicy().hasHeightForWidth())
        self.chartToolbarLabel.setSizePolicy(sizePolicy)

        self.topToolbarLayout.addWidget(self.chartToolbarLabel, 0, 8, 1, 3)

        self.toolbarChartTypeLabel = QLabel(self.topToolbarWidget)
        self.toolbarChartTypeLabel.setObjectName(u"toolbarChartTypeLabel")

        self.topToolbarLayout.addWidget(self.toolbarChartTypeLabel, 1, 8, 1, 1)

        self.chartTypeCombo = QComboBox(self.topToolbarWidget)
        self.chartTypeCombo.setObjectName(u"chartTypeCombo")

        self.topToolbarLayout.addWidget(self.chartTypeCombo, 1, 9, 1, 2)

        self.toolbarPaletteLabel = QLabel(self.topToolbarWidget)
        self.toolbarPaletteLabel.setObjectName(u"toolbarPaletteLabel")

        self.topToolbarLayout.addWidget(self.toolbarPaletteLabel, 2, 8, 1, 1)

        self.presetCombo = PaletteComboBox(self.topToolbarWidget)
        self.presetCombo.setObjectName(u"presetCombo")

        self.topToolbarLayout.addWidget(self.presetCombo, 2, 9, 1, 1)

        self.editGroupColorsButton = QPushButton(self.topToolbarWidget)
        self.editGroupColorsButton.setObjectName(u"editGroupColorsButton")

        self.topToolbarLayout.addWidget(self.editGroupColorsButton, 2, 10, 1, 1)

        self.toolbarOrderLabel = QLabel(self.topToolbarWidget)
        self.toolbarOrderLabel.setObjectName(u"toolbarOrderLabel")

        self.topToolbarLayout.addWidget(self.toolbarOrderLabel, 3, 8, 1, 1)

        self.groupOrderCombo = QComboBox(self.topToolbarWidget)
        self.groupOrderCombo.setObjectName(u"groupOrderCombo")

        self.topToolbarLayout.addWidget(self.groupOrderCombo, 3, 9, 1, 1)

        self.editGroupOrderButton = QPushButton(self.topToolbarWidget)
        self.editGroupOrderButton.setObjectName(u"editGroupOrderButton")

        self.topToolbarLayout.addWidget(self.editGroupOrderButton, 3, 10, 1, 1)

        self.chartToolbarSeparator = QFrame(self.topToolbarWidget)
        self.chartToolbarSeparator.setObjectName(u"chartToolbarSeparator")
        self.chartToolbarSeparator.setFrameShape(QFrame.Shape.VLine)
        self.chartToolbarSeparator.setFrameShadow(QFrame.Shadow.Sunken)

        self.topToolbarLayout.addWidget(self.chartToolbarSeparator, 0, 11, 4, 1)

        self.templateToolbarLabel = QLabel(self.topToolbarWidget)
        self.templateToolbarLabel.setObjectName(u"templateToolbarLabel")
        sizePolicy.setHeightForWidth(self.templateToolbarLabel.sizePolicy().hasHeightForWidth())
        self.templateToolbarLabel.setSizePolicy(sizePolicy)

        self.topToolbarLayout.addWidget(self.templateToolbarLabel, 0, 12, 1, 2)

        self.toolbarTemplateIconLabel = QLabel(self.topToolbarWidget)
        self.toolbarTemplateIconLabel.setObjectName(u"toolbarTemplateIconLabel")

        self.topToolbarLayout.addWidget(self.toolbarTemplateIconLabel, 1, 12, 1, 1)

        self.templateCombo = QComboBox(self.topToolbarWidget)
        self.templateCombo.setObjectName(u"templateCombo")

        self.topToolbarLayout.addWidget(self.templateCombo, 1, 13, 1, 1)

        self.loadTemplateButton = QToolButton(self.topToolbarWidget)
        self.loadTemplateButton.setObjectName(u"loadTemplateButton")

        self.topToolbarLayout.addWidget(self.loadTemplateButton, 2, 12, 1, 1)

        self.saveTemplateButton = QToolButton(self.topToolbarWidget)
        self.saveTemplateButton.setObjectName(u"saveTemplateButton")

        self.topToolbarLayout.addWidget(self.saveTemplateButton, 2, 13, 1, 1)

        self.templateToolbarSeparator = QFrame(self.topToolbarWidget)
        self.templateToolbarSeparator.setObjectName(u"templateToolbarSeparator")
        self.templateToolbarSeparator.setFrameShape(QFrame.Shape.VLine)
        self.templateToolbarSeparator.setFrameShadow(QFrame.Shadow.Sunken)

        self.topToolbarLayout.addWidget(self.templateToolbarSeparator, 0, 14, 4, 1)

        self.canvasToolbarLabel = QLabel(self.topToolbarWidget)
        self.canvasToolbarLabel.setObjectName(u"canvasToolbarLabel")
        sizePolicy.setHeightForWidth(self.canvasToolbarLabel.sizePolicy().hasHeightForWidth())
        self.canvasToolbarLabel.setSizePolicy(sizePolicy)

        self.topToolbarLayout.addWidget(self.canvasToolbarLabel, 0, 15, 1, 4)

        self.toolbarWidthLabel = QLabel(self.topToolbarWidget)
        self.toolbarWidthLabel.setObjectName(u"toolbarWidthLabel")

        self.topToolbarLayout.addWidget(self.toolbarWidthLabel, 1, 15, 1, 1)

        self.widthSpin = QDoubleSpinBox(self.topToolbarWidget)
        self.widthSpin.setObjectName(u"widthSpin")
        self.widthSpin.setMinimum(4.000000000000000)
        self.widthSpin.setMaximum(40.000000000000000)
        self.widthSpin.setSingleStep(0.500000000000000)

        self.topToolbarLayout.addWidget(self.widthSpin, 1, 16, 1, 1)

        self.toolbarHeightLabel = QLabel(self.topToolbarWidget)
        self.toolbarHeightLabel.setObjectName(u"toolbarHeightLabel")

        self.topToolbarLayout.addWidget(self.toolbarHeightLabel, 1, 17, 1, 1)

        self.heightSpin = QDoubleSpinBox(self.topToolbarWidget)
        self.heightSpin.setObjectName(u"heightSpin")
        self.heightSpin.setMinimum(4.000000000000000)
        self.heightSpin.setMaximum(30.000000000000000)
        self.heightSpin.setSingleStep(0.500000000000000)

        self.topToolbarLayout.addWidget(self.heightSpin, 1, 18, 1, 1)

        self.toolbarDpiLabel = QLabel(self.topToolbarWidget)
        self.toolbarDpiLabel.setObjectName(u"toolbarDpiLabel")

        self.topToolbarLayout.addWidget(self.toolbarDpiLabel, 2, 15, 1, 1)

        self.dpiSpin = QSpinBox(self.topToolbarWidget)
        self.dpiSpin.setObjectName(u"dpiSpin")
        self.dpiSpin.setMinimum(72)
        self.dpiSpin.setMaximum(1200)
        self.dpiSpin.setSingleStep(25)

        self.topToolbarLayout.addWidget(self.dpiSpin, 2, 16, 1, 1)

        self.topToolbarSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.topToolbarLayout.addItem(self.topToolbarSpacer, 0, 19, 4, 1)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.toolbarTransparentLabel = QLabel(self.topToolbarWidget)
        self.toolbarTransparentLabel.setObjectName(u"toolbarTransparentLabel")

        self.horizontalLayout_2.addWidget(self.toolbarTransparentLabel)

        self.transparentBackgroundCheck = QCheckBox(self.topToolbarWidget)
        self.transparentBackgroundCheck.setObjectName(u"transparentBackgroundCheck")

        self.horizontalLayout_2.addWidget(self.transparentBackgroundCheck)


        self.topToolbarLayout.addLayout(self.horizontalLayout_2, 3, 15, 1, 3)


        self.chartToolsPageLayout.addWidget(self.topToolbarWidget)

        self.topToolsTabs.addTab(self.chartToolsPage, "")
        self.tableToolsPage = QWidget()
        self.tableToolsPage.setObjectName(u"tableToolsPage")
        self.tableToolsPageLayout = QHBoxLayout(self.tableToolsPage)
        self.tableToolsPageLayout.setObjectName(u"tableToolsPageLayout")
        self.tableToolsPageLayout.setContentsMargins(0, 0, 0, 0)
        self.tableToolsWidget = QFrame(self.tableToolsPage)
        self.tableToolsWidget.setObjectName(u"tableToolsWidget")
        self.tableToolsWidget.setFrameShape(QFrame.Shape.Box)
        self.tableToolsWidget.setFrameShadow(QFrame.Shadow.Plain)
        self.tableToolsLayout = QHBoxLayout(self.tableToolsWidget)
        self.tableToolsLayout.setSpacing(8)
        self.tableToolsLayout.setObjectName(u"tableToolsLayout")
        self.tableToolsLayout.setContentsMargins(8, 4, 8, 4)
        self.tableEditSection = QWidget(self.tableToolsWidget)
        self.tableEditSection.setObjectName(u"tableEditSection")
        self.tableEditSectionLayout = QGridLayout(self.tableEditSection)
        self.tableEditSectionLayout.setObjectName(u"tableEditSectionLayout")
        self.tableEditSectionLayout.setHorizontalSpacing(8)
        self.tableEditSectionLayout.setVerticalSpacing(4)
        self.tableEditSectionLayout.setContentsMargins(0, 0, 0, 0)
        self.tableEditLabel = QLabel(self.tableEditSection)
        self.tableEditLabel.setObjectName(u"tableEditLabel")

        self.tableEditSectionLayout.addWidget(self.tableEditLabel, 0, 0, 1, 3)

        self.tableCopyButton = QToolButton(self.tableEditSection)
        self.tableCopyButton.setObjectName(u"tableCopyButton")
        self.tableCopyButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableEditSectionLayout.addWidget(self.tableCopyButton, 1, 0, 1, 1)

        self.tableCutButton = QToolButton(self.tableEditSection)
        self.tableCutButton.setObjectName(u"tableCutButton")
        self.tableCutButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableEditSectionLayout.addWidget(self.tableCutButton, 1, 1, 1, 1)

        self.tablePasteButton = QToolButton(self.tableEditSection)
        self.tablePasteButton.setObjectName(u"tablePasteButton")
        self.tablePasteButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableEditSectionLayout.addWidget(self.tablePasteButton, 1, 2, 1, 1)

        self.tableClearButton = QToolButton(self.tableEditSection)
        self.tableClearButton.setObjectName(u"tableClearButton")
        self.tableClearButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableEditSectionLayout.addWidget(self.tableClearButton, 2, 0, 1, 1)

        self.tableUndoButton = QToolButton(self.tableEditSection)
        self.tableUndoButton.setObjectName(u"tableUndoButton")
        self.tableUndoButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableEditSectionLayout.addWidget(self.tableUndoButton, 2, 1, 1, 1)

        self.tableRedoButton = QToolButton(self.tableEditSection)
        self.tableRedoButton.setObjectName(u"tableRedoButton")
        self.tableRedoButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableEditSectionLayout.addWidget(self.tableRedoButton, 2, 2, 1, 1)

        self.tableEditHintLabel = QLabel(self.tableEditSection)
        self.tableEditHintLabel.setObjectName(u"tableEditHintLabel")

        self.tableEditSectionLayout.addWidget(self.tableEditHintLabel, 3, 0, 1, 3)


        self.tableToolsLayout.addWidget(self.tableEditSection)

        self.tableEditSeparator = QFrame(self.tableToolsWidget)
        self.tableEditSeparator.setObjectName(u"tableEditSeparator")
        self.tableEditSeparator.setFrameShape(QFrame.Shape.VLine)
        self.tableEditSeparator.setFrameShadow(QFrame.Shadow.Sunken)

        self.tableToolsLayout.addWidget(self.tableEditSeparator)

        self.tableRowsColumnsSection = QWidget(self.tableToolsWidget)
        self.tableRowsColumnsSection.setObjectName(u"tableRowsColumnsSection")
        self.tableRowsColumnsSectionLayout = QGridLayout(self.tableRowsColumnsSection)
        self.tableRowsColumnsSectionLayout.setObjectName(u"tableRowsColumnsSectionLayout")
        self.tableRowsColumnsSectionLayout.setHorizontalSpacing(8)
        self.tableRowsColumnsSectionLayout.setVerticalSpacing(4)
        self.tableRowsColumnsSectionLayout.setContentsMargins(0, 0, 0, 0)
        self.tableRowsColumnsLabel = QLabel(self.tableRowsColumnsSection)
        self.tableRowsColumnsLabel.setObjectName(u"tableRowsColumnsLabel")

        self.tableRowsColumnsSectionLayout.addWidget(self.tableRowsColumnsLabel, 0, 0, 1, 2)

        self.tableInsertRowAboveButton = QToolButton(self.tableRowsColumnsSection)
        self.tableInsertRowAboveButton.setObjectName(u"tableInsertRowAboveButton")
        self.tableInsertRowAboveButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableRowsColumnsSectionLayout.addWidget(self.tableInsertRowAboveButton, 1, 0, 1, 1)

        self.tableInsertRowBelowButton = QToolButton(self.tableRowsColumnsSection)
        self.tableInsertRowBelowButton.setObjectName(u"tableInsertRowBelowButton")
        self.tableInsertRowBelowButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableRowsColumnsSectionLayout.addWidget(self.tableInsertRowBelowButton, 1, 1, 1, 1)

        self.tableInsertColumnLeftButton = QToolButton(self.tableRowsColumnsSection)
        self.tableInsertColumnLeftButton.setObjectName(u"tableInsertColumnLeftButton")
        self.tableInsertColumnLeftButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableRowsColumnsSectionLayout.addWidget(self.tableInsertColumnLeftButton, 2, 0, 1, 1)

        self.tableInsertColumnRightButton = QToolButton(self.tableRowsColumnsSection)
        self.tableInsertColumnRightButton.setObjectName(u"tableInsertColumnRightButton")
        self.tableInsertColumnRightButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableRowsColumnsSectionLayout.addWidget(self.tableInsertColumnRightButton, 2, 1, 1, 1)

        self.tableDeleteRowsButton = QToolButton(self.tableRowsColumnsSection)
        self.tableDeleteRowsButton.setObjectName(u"tableDeleteRowsButton")
        self.tableDeleteRowsButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableRowsColumnsSectionLayout.addWidget(self.tableDeleteRowsButton, 3, 0, 1, 1)

        self.tableDeleteColumnsButton = QToolButton(self.tableRowsColumnsSection)
        self.tableDeleteColumnsButton.setObjectName(u"tableDeleteColumnsButton")
        self.tableDeleteColumnsButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableRowsColumnsSectionLayout.addWidget(self.tableDeleteColumnsButton, 3, 1, 1, 1)


        self.tableToolsLayout.addWidget(self.tableRowsColumnsSection)

        self.tableParentSeparator = QFrame(self.tableToolsWidget)
        self.tableParentSeparator.setObjectName(u"tableParentSeparator")
        self.tableParentSeparator.setFrameShape(QFrame.Shape.VLine)
        self.tableParentSeparator.setFrameShadow(QFrame.Shadow.Sunken)

        self.tableToolsLayout.addWidget(self.tableParentSeparator)

        self.tableParentSection = QWidget(self.tableToolsWidget)
        self.tableParentSection.setObjectName(u"tableParentSection")
        self.tableParentSectionLayout = QGridLayout(self.tableParentSection)
        self.tableParentSectionLayout.setObjectName(u"tableParentSectionLayout")
        self.tableParentSectionLayout.setHorizontalSpacing(8)
        self.tableParentSectionLayout.setVerticalSpacing(4)
        self.tableParentSectionLayout.setContentsMargins(0, 0, 0, 0)
        self.tableParentHeadersLabel = QLabel(self.tableParentSection)
        self.tableParentHeadersLabel.setObjectName(u"tableParentHeadersLabel")

        self.tableParentSectionLayout.addWidget(self.tableParentHeadersLabel, 0, 0, 1, 3)

        self.tableMergeParentButton = QToolButton(self.tableParentSection)
        self.tableMergeParentButton.setObjectName(u"tableMergeParentButton")
        self.tableMergeParentButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableParentSectionLayout.addWidget(self.tableMergeParentButton, 1, 0, 1, 1)

        self.tableUnmergeParentButton = QToolButton(self.tableParentSection)
        self.tableUnmergeParentButton.setObjectName(u"tableUnmergeParentButton")
        self.tableUnmergeParentButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableParentSectionLayout.addWidget(self.tableUnmergeParentButton, 1, 1, 1, 1)

        self.tableRenameParentButton = QToolButton(self.tableParentSection)
        self.tableRenameParentButton.setObjectName(u"tableRenameParentButton")
        self.tableRenameParentButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableParentSectionLayout.addWidget(self.tableRenameParentButton, 1, 2, 1, 1)

        self.tableInsertParentLeftButton = QToolButton(self.tableParentSection)
        self.tableInsertParentLeftButton.setObjectName(u"tableInsertParentLeftButton")
        self.tableInsertParentLeftButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableParentSectionLayout.addWidget(self.tableInsertParentLeftButton, 2, 0, 1, 1)

        self.tableInsertParentRightButton = QToolButton(self.tableParentSection)
        self.tableInsertParentRightButton.setObjectName(u"tableInsertParentRightButton")
        self.tableInsertParentRightButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableParentSectionLayout.addWidget(self.tableInsertParentRightButton, 2, 1, 1, 1)

        self.tableBatchParentsButton = QToolButton(self.tableParentSection)
        self.tableBatchParentsButton.setObjectName(u"tableBatchParentsButton")
        self.tableBatchParentsButton.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)

        self.tableParentSectionLayout.addWidget(self.tableBatchParentsButton, 2, 2, 1, 1)

        self.tableSelectionSummary = QLabel(self.tableParentSection)
        self.tableSelectionSummary.setObjectName(u"tableSelectionSummary")

        self.tableParentSectionLayout.addWidget(self.tableSelectionSummary, 3, 0, 1, 3)


        self.tableToolsLayout.addWidget(self.tableParentSection)

        self.tableToolsSpacer = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.tableToolsLayout.addItem(self.tableToolsSpacer)


        self.tableToolsPageLayout.addWidget(self.tableToolsWidget)

        self.topToolsTabs.addTab(self.tableToolsPage, "")

        self.centralLayout.addWidget(self.topToolsTabs)

        self.mainSplitter = QSplitter(self.centralwidget)
        self.mainSplitter.setObjectName(u"mainSplitter")
        self.mainSplitter.setOrientation(Qt.Orientation.Horizontal)
        self.dataPanel = QWidget(self.mainSplitter)
        self.dataPanel.setObjectName(u"dataPanel")
        self.dataLayout = QVBoxLayout(self.dataPanel)
        self.dataLayout.setSpacing(8)
        self.dataLayout.setObjectName(u"dataLayout")
        self.dataLayout.setContentsMargins(0, 0, 0, 0)
        self.dataButtonLayout = QHBoxLayout()
        self.dataButtonLayout.setSpacing(6)
        self.dataButtonLayout.setObjectName(u"dataButtonLayout")
        self.addOverlayButton = QPushButton(self.dataPanel)
        self.addOverlayButton.setObjectName(u"addOverlayButton")

        self.dataButtonLayout.addWidget(self.addOverlayButton)

        self.removeOverlayButton = QPushButton(self.dataPanel)
        self.removeOverlayButton.setObjectName(u"removeOverlayButton")

        self.dataButtonLayout.addWidget(self.removeOverlayButton)

        self.curveFitButton = QPushButton(self.dataPanel)
        self.curveFitButton.setObjectName(u"curveFitButton")

        self.dataButtonLayout.addWidget(self.curveFitButton)


        self.dataLayout.addLayout(self.dataButtonLayout)

        self.dataResultsSplitter = QSplitter(self.dataPanel)
        self.dataResultsSplitter.setObjectName(u"dataResultsSplitter")
        self.dataResultsSplitter.setOrientation(Qt.Orientation.Vertical)
        self.dataResultsSplitter.setChildrenCollapsible(True)
        self.xySharedFrame = QFrame(self.dataResultsSplitter)
        self.xySharedFrame.setObjectName(u"xySharedFrame")
        self.xySharedFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.xySharedFrame.setFrameShadow(QFrame.Shadow.Plain)
        self.xySharedFrameLayout = QVBoxLayout(self.xySharedFrame)
        self.xySharedFrameLayout.setSpacing(4)
        self.xySharedFrameLayout.setObjectName(u"xySharedFrameLayout")
        self.xySharedFrameLayout.setContentsMargins(4, 4, 4, 4)
        self.xySharedHeaderLayout = QHBoxLayout()
        self.xySharedHeaderLayout.setSpacing(4)
        self.xySharedHeaderLayout.setObjectName(u"xySharedHeaderLayout")
        self.xySharedTitleLabel = QLabel(self.xySharedFrame)
        self.xySharedTitleLabel.setObjectName(u"xySharedTitleLabel")

        self.xySharedHeaderLayout.addWidget(self.xySharedTitleLabel)

        self.xySharedTabBar = QTabBar(self.xySharedFrame)
        self.xySharedTabBar.setObjectName(u"xySharedTabBar")
        self.xySharedTabBar.setMinimumSize(QSize(120, 26))
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(1)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.xySharedTabBar.sizePolicy().hasHeightForWidth())
        self.xySharedTabBar.setSizePolicy(sizePolicy2)
        self.xySharedTabBar.setMovable(True)
        self.xySharedTabBar.setExpanding(False)
        self.xySharedTabBar.setDocumentMode(True)
        self.xySharedTabBar.setDrawBase(False)

        self.xySharedHeaderLayout.addWidget(self.xySharedTabBar)

        self.addXYSharedTableButton = QPushButton(self.xySharedFrame)
        self.addXYSharedTableButton.setObjectName(u"addXYSharedTableButton")
        self.addXYSharedTableButton.setMaximumSize(QSize(32, 26))

        self.xySharedHeaderLayout.addWidget(self.addXYSharedTableButton)

        self.removeXYSharedTableButton = QPushButton(self.xySharedFrame)
        self.removeXYSharedTableButton.setObjectName(u"removeXYSharedTableButton")
        self.removeXYSharedTableButton.setMaximumSize(QSize(32, 26))

        self.xySharedHeaderLayout.addWidget(self.removeXYSharedTableButton)


        self.xySharedFrameLayout.addLayout(self.xySharedHeaderLayout)

        self.dataTable = DataTable(self.xySharedFrame)
        self.dataTable.setObjectName(u"dataTable")
        self.dataTable.setAlternatingRowColors(True)

        self.xySharedFrameLayout.addWidget(self.dataTable)

        self.dataResultsSplitter.addWidget(self.xySharedFrame)
        self.xyIndependentFrame = QFrame(self.dataResultsSplitter)
        self.xyIndependentFrame.setObjectName(u"xyIndependentFrame")
        self.xyIndependentFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.xyIndependentFrame.setFrameShadow(QFrame.Shadow.Plain)
        self.xyIndependentFrameLayout = QVBoxLayout(self.xyIndependentFrame)
        self.xyIndependentFrameLayout.setSpacing(4)
        self.xyIndependentFrameLayout.setObjectName(u"xyIndependentFrameLayout")
        self.xyIndependentFrameLayout.setContentsMargins(4, 4, 4, 4)
        self.xyIndependentTitleLabel = QLabel(self.xyIndependentFrame)
        self.xyIndependentTitleLabel.setObjectName(u"xyIndependentTitleLabel")

        self.xyIndependentFrameLayout.addWidget(self.xyIndependentTitleLabel)

        self.analysisResultsTitleLayout = QHBoxLayout()
        self.analysisResultsTitleLayout.setObjectName(u"analysisResultsTitleLayout")
        self.resultsTitleLabel = QLabel(self.xyIndependentFrame)
        self.resultsTitleLabel.setObjectName(u"resultsTitleLabel")

        self.analysisResultsTitleLayout.addWidget(self.resultsTitleLabel)

        self.analysisNumberFormatsButton = QPushButton(self.xyIndependentFrame)
        self.analysisNumberFormatsButton.setObjectName(u"analysisNumberFormatsButton")

        self.analysisResultsTitleLayout.addWidget(self.analysisNumberFormatsButton)


        self.xyIndependentFrameLayout.addLayout(self.analysisResultsTitleLayout)

        self.analysisResultsTable = AnalysisResultsTable(self.xyIndependentFrame)
        self.analysisResultsTable.setObjectName(u"analysisResultsTable")

        self.xyIndependentFrameLayout.addWidget(self.analysisResultsTable)

        self.xyIndependentTable = DataTable(self.xyIndependentFrame)
        self.xyIndependentTable.setObjectName(u"xyIndependentTable")
        self.xyIndependentTable.setAlternatingRowColors(True)

        self.xyIndependentFrameLayout.addWidget(self.xyIndependentTable)

        self.dataResultsSplitter.addWidget(self.xyIndependentFrame)

        self.dataLayout.addWidget(self.dataResultsSplitter)

        self.mainSplitter.addWidget(self.dataPanel)
        self.plotHost = QFrame(self.mainSplitter)
        self.plotHost.setObjectName(u"plotHost")
        self.plotHost.setFrameShape(QFrame.Shape.StyledPanel)
        self.plotHostLayout = QVBoxLayout(self.plotHost)
        self.plotHostLayout.setSpacing(8)
        self.plotHostLayout.setObjectName(u"plotHostLayout")
        self.plotHostLayout.setContentsMargins(8, 10, 8, 10)
        self.mainSplitter.addWidget(self.plotHost)
        self.controlsPane = QFrame(self.mainSplitter)
        self.controlsPane.setObjectName(u"controlsPane")
        self.controlsPane.setMinimumSize(QSize(420, 0))
        self.controlsPane.setFrameShape(QFrame.Shape.NoFrame)
        self.controlsPane.setStyleSheet(u"QFrame#controlsPane,\n"
"QScrollArea#controlsScroll {\n"
"    border: none;\n"
"    margin: 0;\n"
"    padding: 0;\n"
"}")
        self.controlsPane.setFrameShadow(QFrame.Shadow.Plain)
        self.controlsPaneLayout = QVBoxLayout(self.controlsPane)
        self.controlsPaneLayout.setSpacing(10)
        self.controlsPaneLayout.setObjectName(u"controlsPaneLayout")
        self.controlsPaneLayout.setContentsMargins(0, 0, 0, 0)
        self.inspectorContextFrame = QFrame(self.controlsPane)
        self.inspectorContextFrame.setObjectName(u"inspectorContextFrame")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.inspectorContextFrame.sizePolicy().hasHeightForWidth())
        self.inspectorContextFrame.setSizePolicy(sizePolicy3)
        self.inspectorContextFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.inspectorContextFrame.setFrameShadow(QFrame.Shadow.Plain)
        self.inspectorContextLayout = QHBoxLayout(self.inspectorContextFrame)
        self.inspectorContextLayout.setSpacing(8)
        self.inspectorContextLayout.setObjectName(u"inspectorContextLayout")
        self.inspectorContextLayout.setContentsMargins(8, 4, 8, 4)
        self.inspectorContextLabel = QLabel(self.inspectorContextFrame)
        self.inspectorContextLabel.setObjectName(u"inspectorContextLabel")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.inspectorContextLabel.sizePolicy().hasHeightForWidth())
        self.inspectorContextLabel.setSizePolicy(sizePolicy4)

        self.inspectorContextLayout.addWidget(self.inspectorContextLabel)

        self.inspectorShowAllButton = QPushButton(self.inspectorContextFrame)
        self.inspectorShowAllButton.setObjectName(u"inspectorShowAllButton")
        self.inspectorShowAllButton.setEnabled(False)
        self.inspectorShowAllButton.setVisible(True)
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.inspectorShowAllButton.sizePolicy().hasHeightForWidth())
        self.inspectorShowAllButton.setSizePolicy(sizePolicy5)

        self.inspectorContextLayout.addWidget(self.inspectorShowAllButton)


        self.controlsPaneLayout.addWidget(self.inspectorContextFrame)

        self.controlsScroll = QScrollArea(self.controlsPane)
        self.controlsScroll.setObjectName(u"controlsScroll")
        self.controlsScroll.setMinimumSize(QSize(0, 0))
        self.controlsScroll.setFrameShape(QFrame.Shape.NoFrame)
        self.controlsScroll.setWidgetResizable(True)
        self.controlsContent = QWidget()
        self.controlsContent.setObjectName(u"controlsContent")
        self.controlsContent.setGeometry(QRect(0, 0, 420, 1758))
        self.controlsContent.setMinimumSize(QSize(0, 0))
        self.controlsLayout = QVBoxLayout(self.controlsContent)
        self.controlsLayout.setSpacing(10)
        self.controlsLayout.setObjectName(u"controlsLayout")
        self.controlsLayout.setContentsMargins(0, 0, 0, 0)
        self.titleAxisGroup = QGroupBox(self.controlsContent)
        self.titleAxisGroup.setObjectName(u"titleAxisGroup")
        self.titleAxisForm = QFormLayout(self.titleAxisGroup)
        self.titleAxisForm.setObjectName(u"titleAxisForm")
        self.titleAxisForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.titleAxisForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.titleAxisForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.titleAxisForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.titleAxisForm.setHorizontalSpacing(12)
        self.titleAxisForm.setVerticalSpacing(6)
        self.titleAxisForm.setContentsMargins(8, 10, 8, 8)
        self.titleLabel = QLabel(self.titleAxisGroup)
        self.titleLabel.setObjectName(u"titleLabel")

        self.titleAxisForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.titleLabel)

        self.titleEdit = QPlainTextEdit(self.titleAxisGroup)
        self.titleEdit.setObjectName(u"titleEdit")
        self.titleEdit.setMinimumSize(QSize(0, 44))
        self.titleEdit.setMaximumSize(QSize(16777215, 48))
        self.titleEdit.setTabChangesFocus(True)

        self.titleAxisForm.setWidget(0, QFormLayout.ItemRole.FieldRole, self.titleEdit)

        self.xLabelLabel = QLabel(self.titleAxisGroup)
        self.xLabelLabel.setObjectName(u"xLabelLabel")

        self.titleAxisForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.xLabelLabel)

        self.xLabelEdit = QPlainTextEdit(self.titleAxisGroup)
        self.xLabelEdit.setObjectName(u"xLabelEdit")
        self.xLabelEdit.setMinimumSize(QSize(0, 44))
        self.xLabelEdit.setMaximumSize(QSize(16777215, 48))
        self.xLabelEdit.setTabChangesFocus(True)

        self.titleAxisForm.setWidget(1, QFormLayout.ItemRole.FieldRole, self.xLabelEdit)

        self.yLabelLabel = QLabel(self.titleAxisGroup)
        self.yLabelLabel.setObjectName(u"yLabelLabel")

        self.titleAxisForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.yLabelLabel)

        self.yLabelEdit = QPlainTextEdit(self.titleAxisGroup)
        self.yLabelEdit.setObjectName(u"yLabelEdit")
        self.yLabelEdit.setMinimumSize(QSize(0, 44))
        self.yLabelEdit.setMaximumSize(QSize(16777215, 48))
        self.yLabelEdit.setTabChangesFocus(True)

        self.titleAxisForm.setWidget(2, QFormLayout.ItemRole.FieldRole, self.yLabelEdit)

        self.secondaryYLabelLabel = QLabel(self.titleAxisGroup)
        self.secondaryYLabelLabel.setObjectName(u"secondaryYLabelLabel")

        self.titleAxisForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.secondaryYLabelLabel)

        self.secondaryYLabelEdit = QPlainTextEdit(self.titleAxisGroup)
        self.secondaryYLabelEdit.setObjectName(u"secondaryYLabelEdit")
        self.secondaryYLabelEdit.setMinimumSize(QSize(0, 44))
        self.secondaryYLabelEdit.setMaximumSize(QSize(16777215, 48))
        self.secondaryYLabelEdit.setTabChangesFocus(True)

        self.titleAxisForm.setWidget(3, QFormLayout.ItemRole.FieldRole, self.secondaryYLabelEdit)


        self.controlsLayout.addWidget(self.titleAxisGroup)

        self.categoryAxisGroup = QGroupBox(self.controlsContent)
        self.categoryAxisGroup.setObjectName(u"categoryAxisGroup")
        self.categoryAxisForm = QFormLayout(self.categoryAxisGroup)
        self.categoryAxisForm.setObjectName(u"categoryAxisForm")
        self.categoryAxisForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.categoryAxisForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.categoryAxisForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.categoryAxisForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.categoryAxisForm.setHorizontalSpacing(12)
        self.categoryAxisForm.setVerticalSpacing(6)
        self.categoryAxisForm.setContentsMargins(8, 10, 8, 8)
        self.autoXRangeLabel = QLabel(self.categoryAxisGroup)
        self.autoXRangeLabel.setObjectName(u"autoXRangeLabel")

        self.categoryAxisForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.autoXRangeLabel)

        self.autoXRangeCheckFieldLayout = QHBoxLayout()
        self.autoXRangeCheckFieldLayout.setSpacing(0)
        self.autoXRangeCheckFieldLayout.setObjectName(u"autoXRangeCheckFieldLayout")
        self.autoXRangeCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.autoXRangeCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.autoXRangeCheckFieldLayout.addItem(self.autoXRangeCheckLeftSpacer)

        self.autoXRangeCheck = QCheckBox(self.categoryAxisGroup)
        self.autoXRangeCheck.setObjectName(u"autoXRangeCheck")

        self.autoXRangeCheckFieldLayout.addWidget(self.autoXRangeCheck)


        self.categoryAxisForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.autoXRangeCheckFieldLayout)

        self.xMinLabel = QLabel(self.categoryAxisGroup)
        self.xMinLabel.setObjectName(u"xMinLabel")

        self.categoryAxisForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.xMinLabel)

        self.xMinSpinFieldLayout = QHBoxLayout()
        self.xMinSpinFieldLayout.setSpacing(0)
        self.xMinSpinFieldLayout.setObjectName(u"xMinSpinFieldLayout")
        self.xMinSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.xMinSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xMinSpinFieldLayout.addItem(self.xMinSpinLeftSpacer)

        self.xMinSpin = QDoubleSpinBox(self.categoryAxisGroup)
        self.xMinSpin.setObjectName(u"xMinSpin")
        self.xMinSpin.setDecimals(6)
        self.xMinSpin.setMinimum(-1000000.000000000000000)
        self.xMinSpin.setMaximum(1000000.000000000000000)
        self.xMinSpin.setSingleStep(0.500000000000000)

        self.xMinSpinFieldLayout.addWidget(self.xMinSpin)


        self.categoryAxisForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.xMinSpinFieldLayout)

        self.xMaxLabel = QLabel(self.categoryAxisGroup)
        self.xMaxLabel.setObjectName(u"xMaxLabel")

        self.categoryAxisForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.xMaxLabel)

        self.xMaxSpinFieldLayout = QHBoxLayout()
        self.xMaxSpinFieldLayout.setSpacing(0)
        self.xMaxSpinFieldLayout.setObjectName(u"xMaxSpinFieldLayout")
        self.xMaxSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.xMaxSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xMaxSpinFieldLayout.addItem(self.xMaxSpinLeftSpacer)

        self.xMaxSpin = QDoubleSpinBox(self.categoryAxisGroup)
        self.xMaxSpin.setObjectName(u"xMaxSpin")
        self.xMaxSpin.setDecimals(6)
        self.xMaxSpin.setMinimum(-1000000.000000000000000)
        self.xMaxSpin.setMaximum(1000000.000000000000000)
        self.xMaxSpin.setSingleStep(0.500000000000000)

        self.xMaxSpinFieldLayout.addWidget(self.xMaxSpin)


        self.categoryAxisForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.xMaxSpinFieldLayout)

        self.xAutoTickIntervalLabel = QLabel(self.categoryAxisGroup)
        self.xAutoTickIntervalLabel.setObjectName(u"xAutoTickIntervalLabel")

        self.categoryAxisForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.xAutoTickIntervalLabel)

        self.xAutoTickIntervalCheckFieldLayout = QHBoxLayout()
        self.xAutoTickIntervalCheckFieldLayout.setSpacing(0)
        self.xAutoTickIntervalCheckFieldLayout.setObjectName(u"xAutoTickIntervalCheckFieldLayout")
        self.xAutoTickIntervalCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.xAutoTickIntervalCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xAutoTickIntervalCheckFieldLayout.addItem(self.xAutoTickIntervalCheckLeftSpacer)

        self.xAutoTickIntervalCheck = QCheckBox(self.categoryAxisGroup)
        self.xAutoTickIntervalCheck.setObjectName(u"xAutoTickIntervalCheck")

        self.xAutoTickIntervalCheckFieldLayout.addWidget(self.xAutoTickIntervalCheck)


        self.categoryAxisForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.xAutoTickIntervalCheckFieldLayout)

        self.xTickIntervalLabel = QLabel(self.categoryAxisGroup)
        self.xTickIntervalLabel.setObjectName(u"xTickIntervalLabel")

        self.categoryAxisForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.xTickIntervalLabel)

        self.xTickIntervalSpinFieldLayout = QHBoxLayout()
        self.xTickIntervalSpinFieldLayout.setSpacing(0)
        self.xTickIntervalSpinFieldLayout.setObjectName(u"xTickIntervalSpinFieldLayout")
        self.xTickIntervalSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.xTickIntervalSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xTickIntervalSpinFieldLayout.addItem(self.xTickIntervalSpinLeftSpacer)

        self.xTickIntervalSpin = QDoubleSpinBox(self.categoryAxisGroup)
        self.xTickIntervalSpin.setObjectName(u"xTickIntervalSpin")
        self.xTickIntervalSpin.setDecimals(6)
        self.xTickIntervalSpin.setMinimum(0.000001000000000)
        self.xTickIntervalSpin.setMaximum(1000000.000000000000000)
        self.xTickIntervalSpin.setSingleStep(0.500000000000000)

        self.xTickIntervalSpinFieldLayout.addWidget(self.xTickIntervalSpin)


        self.categoryAxisForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.xTickIntervalSpinFieldLayout)

        self.xRotationLabel = QLabel(self.categoryAxisGroup)
        self.xRotationLabel.setObjectName(u"xRotationLabel")

        self.categoryAxisForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.xRotationLabel)

        self.xTickRotationSpinFieldLayout = QHBoxLayout()
        self.xTickRotationSpinFieldLayout.setSpacing(0)
        self.xTickRotationSpinFieldLayout.setObjectName(u"xTickRotationSpinFieldLayout")
        self.xTickRotationSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.xTickRotationSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xTickRotationSpinFieldLayout.addItem(self.xTickRotationSpinLeftSpacer)

        self.xTickRotationSpin = QSpinBox(self.categoryAxisGroup)
        self.xTickRotationSpin.setObjectName(u"xTickRotationSpin")
        self.xTickRotationSpin.setMinimum(0)
        self.xTickRotationSpin.setMaximum(90)
        self.xTickRotationSpin.setSingleStep(5)

        self.xTickRotationSpinFieldLayout.addWidget(self.xTickRotationSpin)


        self.categoryAxisForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.xTickRotationSpinFieldLayout)

        self.parentGroupSpacingLabel = QLabel(self.categoryAxisGroup)
        self.parentGroupSpacingLabel.setObjectName(u"parentGroupSpacingLabel")

        self.categoryAxisForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.parentGroupSpacingLabel)

        self.groupOuterSpacingSpinFieldLayout = QHBoxLayout()
        self.groupOuterSpacingSpinFieldLayout.setSpacing(0)
        self.groupOuterSpacingSpinFieldLayout.setObjectName(u"groupOuterSpacingSpinFieldLayout")
        self.groupOuterSpacingSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.groupOuterSpacingSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.groupOuterSpacingSpinFieldLayout.addItem(self.groupOuterSpacingSpinLeftSpacer)

        self.groupOuterSpacingSpin = QDoubleSpinBox(self.categoryAxisGroup)
        self.groupOuterSpacingSpin.setObjectName(u"groupOuterSpacingSpin")
        self.groupOuterSpacingSpin.setDecimals(1)
        self.groupOuterSpacingSpin.setMinimum(0.200000000000000)
        self.groupOuterSpacingSpin.setMaximum(10.000000000000000)
        self.groupOuterSpacingSpin.setSingleStep(0.100000000000000)
        self.groupOuterSpacingSpin.setValue(2.700000000000000)

        self.groupOuterSpacingSpinFieldLayout.addWidget(self.groupOuterSpacingSpin)


        self.categoryAxisForm.setLayout(6, QFormLayout.ItemRole.FieldRole, self.groupOuterSpacingSpinFieldLayout)

        self.groupLayoutButton = QPushButton(self.categoryAxisGroup)
        self.groupLayoutButton.setObjectName(u"groupLayoutButton")

        self.categoryAxisForm.setWidget(7, QFormLayout.ItemRole.SpanningRole, self.groupLayoutButton)


        self.controlsLayout.addWidget(self.categoryAxisGroup)

        self.primaryAxisGroup = QGroupBox(self.controlsContent)
        self.primaryAxisGroup.setObjectName(u"primaryAxisGroup")
        self.primaryAxisForm = QFormLayout(self.primaryAxisGroup)
        self.primaryAxisForm.setObjectName(u"primaryAxisForm")
        self.primaryAxisForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.primaryAxisForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.primaryAxisForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.primaryAxisForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.primaryAxisForm.setHorizontalSpacing(12)
        self.primaryAxisForm.setVerticalSpacing(6)
        self.primaryAxisForm.setContentsMargins(8, 10, 8, 8)
        self.autoYLabel = QLabel(self.primaryAxisGroup)
        self.autoYLabel.setObjectName(u"autoYLabel")

        self.primaryAxisForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.autoYLabel)

        self.autoYRangeCheckFieldLayout = QHBoxLayout()
        self.autoYRangeCheckFieldLayout.setSpacing(0)
        self.autoYRangeCheckFieldLayout.setObjectName(u"autoYRangeCheckFieldLayout")
        self.autoYRangeCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.autoYRangeCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.autoYRangeCheckFieldLayout.addItem(self.autoYRangeCheckLeftSpacer)

        self.autoYRangeCheck = QCheckBox(self.primaryAxisGroup)
        self.autoYRangeCheck.setObjectName(u"autoYRangeCheck")

        self.autoYRangeCheckFieldLayout.addWidget(self.autoYRangeCheck)


        self.primaryAxisForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.autoYRangeCheckFieldLayout)

        self.yMinLabel = QLabel(self.primaryAxisGroup)
        self.yMinLabel.setObjectName(u"yMinLabel")

        self.primaryAxisForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.yMinLabel)

        self.yMinSpinFieldLayout = QHBoxLayout()
        self.yMinSpinFieldLayout.setSpacing(0)
        self.yMinSpinFieldLayout.setObjectName(u"yMinSpinFieldLayout")
        self.yMinSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.yMinSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.yMinSpinFieldLayout.addItem(self.yMinSpinLeftSpacer)

        self.yMinSpin = QDoubleSpinBox(self.primaryAxisGroup)
        self.yMinSpin.setObjectName(u"yMinSpin")
        self.yMinSpin.setMinimum(-1000000.000000000000000)
        self.yMinSpin.setMaximum(1000000.000000000000000)
        self.yMinSpin.setSingleStep(0.500000000000000)

        self.yMinSpinFieldLayout.addWidget(self.yMinSpin)


        self.primaryAxisForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.yMinSpinFieldLayout)

        self.yMaxLabel = QLabel(self.primaryAxisGroup)
        self.yMaxLabel.setObjectName(u"yMaxLabel")

        self.primaryAxisForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.yMaxLabel)

        self.yMaxSpinFieldLayout = QHBoxLayout()
        self.yMaxSpinFieldLayout.setSpacing(0)
        self.yMaxSpinFieldLayout.setObjectName(u"yMaxSpinFieldLayout")
        self.yMaxSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.yMaxSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.yMaxSpinFieldLayout.addItem(self.yMaxSpinLeftSpacer)

        self.yMaxSpin = QDoubleSpinBox(self.primaryAxisGroup)
        self.yMaxSpin.setObjectName(u"yMaxSpin")
        self.yMaxSpin.setMinimum(-1000000.000000000000000)
        self.yMaxSpin.setMaximum(1000000.000000000000000)
        self.yMaxSpin.setSingleStep(0.500000000000000)

        self.yMaxSpinFieldLayout.addWidget(self.yMaxSpin)


        self.primaryAxisForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.yMaxSpinFieldLayout)

        self.primaryAutoTickIntervalLabel = QLabel(self.primaryAxisGroup)
        self.primaryAutoTickIntervalLabel.setObjectName(u"primaryAutoTickIntervalLabel")

        self.primaryAxisForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.primaryAutoTickIntervalLabel)

        self.primaryAutoTickIntervalCheckFieldLayout = QHBoxLayout()
        self.primaryAutoTickIntervalCheckFieldLayout.setSpacing(0)
        self.primaryAutoTickIntervalCheckFieldLayout.setObjectName(u"primaryAutoTickIntervalCheckFieldLayout")
        self.primaryAutoTickIntervalCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.primaryAutoTickIntervalCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.primaryAutoTickIntervalCheckFieldLayout.addItem(self.primaryAutoTickIntervalCheckLeftSpacer)

        self.primaryAutoTickIntervalCheck = QCheckBox(self.primaryAxisGroup)
        self.primaryAutoTickIntervalCheck.setObjectName(u"primaryAutoTickIntervalCheck")

        self.primaryAutoTickIntervalCheckFieldLayout.addWidget(self.primaryAutoTickIntervalCheck)


        self.primaryAxisForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.primaryAutoTickIntervalCheckFieldLayout)

        self.primaryTickIntervalLabel = QLabel(self.primaryAxisGroup)
        self.primaryTickIntervalLabel.setObjectName(u"primaryTickIntervalLabel")

        self.primaryAxisForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.primaryTickIntervalLabel)

        self.primaryTickIntervalSpinFieldLayout = QHBoxLayout()
        self.primaryTickIntervalSpinFieldLayout.setSpacing(0)
        self.primaryTickIntervalSpinFieldLayout.setObjectName(u"primaryTickIntervalSpinFieldLayout")
        self.primaryTickIntervalSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.primaryTickIntervalSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.primaryTickIntervalSpinFieldLayout.addItem(self.primaryTickIntervalSpinLeftSpacer)

        self.primaryTickIntervalSpin = QDoubleSpinBox(self.primaryAxisGroup)
        self.primaryTickIntervalSpin.setObjectName(u"primaryTickIntervalSpin")
        self.primaryTickIntervalSpin.setDecimals(6)
        self.primaryTickIntervalSpin.setMinimum(0.000001000000000)
        self.primaryTickIntervalSpin.setMaximum(1000000.000000000000000)
        self.primaryTickIntervalSpin.setSingleStep(0.500000000000000)

        self.primaryTickIntervalSpinFieldLayout.addWidget(self.primaryTickIntervalSpin)


        self.primaryAxisForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.primaryTickIntervalSpinFieldLayout)


        self.controlsLayout.addWidget(self.primaryAxisGroup)

        self.additionalGuidesGroup = QGroupBox(self.controlsContent)
        self.additionalGuidesGroup.setObjectName(u"additionalGuidesGroup")
        self.additionalGuidesGroup.setVisible(False)
        self.additionalGuidesLayout = QVBoxLayout(self.additionalGuidesGroup)
        self.additionalGuidesLayout.setSpacing(6)
        self.additionalGuidesLayout.setObjectName(u"additionalGuidesLayout")
        self.additionalGuidesLayout.setContentsMargins(8, 10, 8, 8)
        self.additionalGuidesAxisLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuidesAxisLabel.setObjectName(u"additionalGuidesAxisLabel")

        self.additionalGuidesLayout.addWidget(self.additionalGuidesAxisLabel)

        self.additionalGuidesAxisSelector = QWidget(self.additionalGuidesGroup)
        self.additionalGuidesAxisSelector.setObjectName(u"additionalGuidesAxisSelector")
        self.additionalGuidesAxisSelector.setVisible(False)
        self.additionalGuidesAxisSelectorLayout = QHBoxLayout(self.additionalGuidesAxisSelector)
        self.additionalGuidesAxisSelectorLayout.setSpacing(12)
        self.additionalGuidesAxisSelectorLayout.setObjectName(u"additionalGuidesAxisSelectorLayout")
        self.additionalGuidesAxisSelectorLayout.setContentsMargins(0, 0, 0, 0)
        self.additionalGuidesXAxisRadio = QRadioButton(self.additionalGuidesAxisSelector)
        self.additionalGuidesXAxisRadio.setObjectName(u"additionalGuidesXAxisRadio")

        self.additionalGuidesAxisSelectorLayout.addWidget(self.additionalGuidesXAxisRadio)

        self.additionalGuidesYAxisRadio = QRadioButton(self.additionalGuidesAxisSelector)
        self.additionalGuidesYAxisRadio.setObjectName(u"additionalGuidesYAxisRadio")

        self.additionalGuidesAxisSelectorLayout.addWidget(self.additionalGuidesYAxisRadio)

        self.additionalGuidesAxisSelectorSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.additionalGuidesAxisSelectorLayout.addItem(self.additionalGuidesAxisSelectorSpacer)


        self.additionalGuidesLayout.addWidget(self.additionalGuidesAxisSelector)

        self.additionalGuideStyleForm = QFormLayout()
        self.additionalGuideStyleForm.setObjectName(u"additionalGuideStyleForm")
        self.additionalGuideStyleForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.additionalGuideStyleForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.additionalGuideStyleForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.additionalGuideStyleForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.additionalGuideStyleForm.setHorizontalSpacing(12)
        self.additionalGuideStyleForm.setVerticalSpacing(6)
        self.additionalGuideLineWidthLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideLineWidthLabel.setObjectName(u"additionalGuideLineWidthLabel")

        self.additionalGuideStyleForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.additionalGuideLineWidthLabel)

        self.additionalGuideLineWidthSpin = QDoubleSpinBox(self.additionalGuidesGroup)
        self.additionalGuideLineWidthSpin.setObjectName(u"additionalGuideLineWidthSpin")
        self.additionalGuideLineWidthSpin.setDecimals(1)
        self.additionalGuideLineWidthSpin.setMinimum(0.500000000000000)
        self.additionalGuideLineWidthSpin.setMaximum(5.000000000000000)
        self.additionalGuideLineWidthSpin.setSingleStep(0.100000000000000)
        self.additionalGuideLineWidthSpin.setValue(1.200000000000000)

        self.additionalGuideStyleForm.setWidget(0, QFormLayout.ItemRole.FieldRole, self.additionalGuideLineWidthSpin)


        self.additionalGuidesLayout.addLayout(self.additionalGuideStyleForm)

        self.additionalGuidesTable = QTableWidget(self.additionalGuidesGroup)
        if (self.additionalGuidesTable.columnCount() < 5):
            self.additionalGuidesTable.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.additionalGuidesTable.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.additionalGuidesTable.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.additionalGuidesTable.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.additionalGuidesTable.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.additionalGuidesTable.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.additionalGuidesTable.setObjectName(u"additionalGuidesTable")
        self.additionalGuidesTable.setMinimumSize(QSize(0, 130))
        self.additionalGuidesTable.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.additionalGuidesTable.setAlternatingRowColors(True)
        self.additionalGuidesTable.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.additionalGuidesTable.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.additionalGuidesTable.setColumnCount(5)
        self.additionalGuidesTable.horizontalHeader().setStretchLastSection(True)

        self.additionalGuidesLayout.addWidget(self.additionalGuidesTable)

        self.additionalGuideButtonsLayout = QHBoxLayout()
        self.additionalGuideButtonsLayout.setSpacing(6)
        self.additionalGuideButtonsLayout.setObjectName(u"additionalGuideButtonsLayout")
        self.additionalGuideAddButton = QPushButton(self.additionalGuidesGroup)
        self.additionalGuideAddButton.setObjectName(u"additionalGuideAddButton")

        self.additionalGuideButtonsLayout.addWidget(self.additionalGuideAddButton)

        self.additionalGuideDeleteButton = QPushButton(self.additionalGuidesGroup)
        self.additionalGuideDeleteButton.setObjectName(u"additionalGuideDeleteButton")

        self.additionalGuideButtonsLayout.addWidget(self.additionalGuideDeleteButton)

        self.additionalGuideButtonsSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.additionalGuideButtonsLayout.addItem(self.additionalGuideButtonsSpacer)


        self.additionalGuidesLayout.addLayout(self.additionalGuideButtonsLayout)

        self.additionalGuideForm = QFormLayout()
        self.additionalGuideForm.setObjectName(u"additionalGuideForm")
        self.additionalGuideForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.additionalGuideForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.additionalGuideForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.additionalGuideForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.additionalGuideForm.setHorizontalSpacing(12)
        self.additionalGuideForm.setVerticalSpacing(6)
        self.additionalGuideValueLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideValueLabel.setObjectName(u"additionalGuideValueLabel")

        self.additionalGuideForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.additionalGuideValueLabel)

        self.additionalGuideValueSpin = QDoubleSpinBox(self.additionalGuidesGroup)
        self.additionalGuideValueSpin.setObjectName(u"additionalGuideValueSpin")
        self.additionalGuideValueSpin.setDecimals(8)
        self.additionalGuideValueSpin.setMinimum(-10000000000000000159028911097599180468360808563945281389781327557747838772170381060813469985856815104.000000000000000)
        self.additionalGuideValueSpin.setMaximum(10000000000000000159028911097599180468360808563945281389781327557747838772170381060813469985856815104.000000000000000)

        self.additionalGuideForm.setWidget(0, QFormLayout.ItemRole.FieldRole, self.additionalGuideValueSpin)

        self.additionalGuideTickLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideTickLabel.setObjectName(u"additionalGuideTickLabel")

        self.additionalGuideForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.additionalGuideTickLabel)

        self.additionalGuideTickCheck = QCheckBox(self.additionalGuidesGroup)
        self.additionalGuideTickCheck.setObjectName(u"additionalGuideTickCheck")

        self.additionalGuideForm.setWidget(1, QFormLayout.ItemRole.FieldRole, self.additionalGuideTickCheck)

        self.additionalGuideShowValueLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideShowValueLabel.setObjectName(u"additionalGuideShowValueLabel")

        self.additionalGuideForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.additionalGuideShowValueLabel)

        self.additionalGuideShowValueCheck = QCheckBox(self.additionalGuidesGroup)
        self.additionalGuideShowValueCheck.setObjectName(u"additionalGuideShowValueCheck")

        self.additionalGuideForm.setWidget(2, QFormLayout.ItemRole.FieldRole, self.additionalGuideShowValueCheck)

        self.additionalGuideLineLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideLineLabel.setObjectName(u"additionalGuideLineLabel")

        self.additionalGuideForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.additionalGuideLineLabel)

        self.additionalGuideLineCheck = QCheckBox(self.additionalGuidesGroup)
        self.additionalGuideLineCheck.setObjectName(u"additionalGuideLineCheck")

        self.additionalGuideForm.setWidget(3, QFormLayout.ItemRole.FieldRole, self.additionalGuideLineCheck)

        self.additionalGuideColorLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideColorLabel.setObjectName(u"additionalGuideColorLabel")

        self.additionalGuideForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.additionalGuideColorLabel)

        self.additionalGuideColorCombo = QComboBox(self.additionalGuidesGroup)
        self.additionalGuideColorCombo.setObjectName(u"additionalGuideColorCombo")

        self.additionalGuideForm.setWidget(4, QFormLayout.ItemRole.FieldRole, self.additionalGuideColorCombo)

        self.additionalGuideTextColorLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideTextColorLabel.setObjectName(u"additionalGuideTextColorLabel")

        self.additionalGuideForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.additionalGuideTextColorLabel)

        self.additionalGuideTextColorCombo = QComboBox(self.additionalGuidesGroup)
        self.additionalGuideTextColorCombo.setObjectName(u"additionalGuideTextColorCombo")

        self.additionalGuideForm.setWidget(5, QFormLayout.ItemRole.FieldRole, self.additionalGuideTextColorCombo)

        self.additionalGuideTextLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideTextLabel.setObjectName(u"additionalGuideTextLabel")

        self.additionalGuideForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.additionalGuideTextLabel)

        self.additionalGuideTextEdit = QPlainTextEdit(self.additionalGuidesGroup)
        self.additionalGuideTextEdit.setObjectName(u"additionalGuideTextEdit")
        self.additionalGuideTextEdit.setMinimumSize(QSize(0, 44))
        self.additionalGuideTextEdit.setMaximumSize(QSize(16777215, 48))
        self.additionalGuideTextEdit.setTabChangesFocus(True)

        self.additionalGuideForm.setWidget(6, QFormLayout.ItemRole.FieldRole, self.additionalGuideTextEdit)

        self.additionalGuideTextSideLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideTextSideLabel.setObjectName(u"additionalGuideTextSideLabel")

        self.additionalGuideForm.setWidget(7, QFormLayout.ItemRole.LabelRole, self.additionalGuideTextSideLabel)

        self.additionalGuideTextSideCombo = QComboBox(self.additionalGuidesGroup)
        self.additionalGuideTextSideCombo.addItem("")
        self.additionalGuideTextSideCombo.addItem("")
        self.additionalGuideTextSideCombo.addItem("")
        self.additionalGuideTextSideCombo.setObjectName(u"additionalGuideTextSideCombo")

        self.additionalGuideForm.setWidget(7, QFormLayout.ItemRole.FieldRole, self.additionalGuideTextSideCombo)

        self.additionalGuideTextVerticalLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideTextVerticalLabel.setObjectName(u"additionalGuideTextVerticalLabel")

        self.additionalGuideForm.setWidget(8, QFormLayout.ItemRole.LabelRole, self.additionalGuideTextVerticalLabel)

        self.additionalGuideTextVerticalCombo = QComboBox(self.additionalGuidesGroup)
        self.additionalGuideTextVerticalCombo.addItem("")
        self.additionalGuideTextVerticalCombo.addItem("")
        self.additionalGuideTextVerticalCombo.addItem("")
        self.additionalGuideTextVerticalCombo.setObjectName(u"additionalGuideTextVerticalCombo")

        self.additionalGuideForm.setWidget(8, QFormLayout.ItemRole.FieldRole, self.additionalGuideTextVerticalCombo)

        self.additionalGuideLabelBackgroundLabel = QLabel(self.additionalGuidesGroup)
        self.additionalGuideLabelBackgroundLabel.setObjectName(u"additionalGuideLabelBackgroundLabel")

        self.additionalGuideForm.setWidget(9, QFormLayout.ItemRole.LabelRole, self.additionalGuideLabelBackgroundLabel)

        self.additionalGuideLabelBackgroundCheck = QCheckBox(self.additionalGuidesGroup)
        self.additionalGuideLabelBackgroundCheck.setObjectName(u"additionalGuideLabelBackgroundCheck")

        self.additionalGuideForm.setWidget(9, QFormLayout.ItemRole.FieldRole, self.additionalGuideLabelBackgroundCheck)


        self.additionalGuidesLayout.addLayout(self.additionalGuideForm)


        self.controlsLayout.addWidget(self.additionalGuidesGroup)

        self.axesAppearanceGroup = QGroupBox(self.controlsContent)
        self.axesAppearanceGroup.setObjectName(u"axesAppearanceGroup")
        self.axesAppearanceForm = QFormLayout(self.axesAppearanceGroup)
        self.axesAppearanceForm.setObjectName(u"axesAppearanceForm")
        self.axesAppearanceForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.axesAppearanceForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.axesAppearanceForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.axesAppearanceForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.axesAppearanceForm.setHorizontalSpacing(12)
        self.axesAppearanceForm.setVerticalSpacing(6)
        self.axesAppearanceForm.setContentsMargins(8, 10, 8, 8)
        self.showGridLabel = QLabel(self.axesAppearanceGroup)
        self.showGridLabel.setObjectName(u"showGridLabel")

        self.axesAppearanceForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.showGridLabel)

        self.showGridCheckFieldLayout = QHBoxLayout()
        self.showGridCheckFieldLayout.setSpacing(0)
        self.showGridCheckFieldLayout.setObjectName(u"showGridCheckFieldLayout")
        self.showGridCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showGridCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showGridCheckFieldLayout.addItem(self.showGridCheckLeftSpacer)

        self.showGridCheck = QCheckBox(self.axesAppearanceGroup)
        self.showGridCheck.setObjectName(u"showGridCheck")

        self.showGridCheckFieldLayout.addWidget(self.showGridCheck)


        self.axesAppearanceForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showGridCheckFieldLayout)

        self.axisLineWidthLabel = QLabel(self.axesAppearanceGroup)
        self.axisLineWidthLabel.setObjectName(u"axisLineWidthLabel")

        self.axesAppearanceForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.axisLineWidthLabel)

        self.axisLineWidthSpinFieldLayout = QHBoxLayout()
        self.axisLineWidthSpinFieldLayout.setSpacing(0)
        self.axisLineWidthSpinFieldLayout.setObjectName(u"axisLineWidthSpinFieldLayout")
        self.axisLineWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.axisLineWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.axisLineWidthSpinFieldLayout.addItem(self.axisLineWidthSpinLeftSpacer)

        self.axisLineWidthSpin = QDoubleSpinBox(self.axesAppearanceGroup)
        self.axisLineWidthSpin.setObjectName(u"axisLineWidthSpin")
        self.axisLineWidthSpin.setMinimum(0.200000000000000)
        self.axisLineWidthSpin.setMaximum(5.000000000000000)
        self.axisLineWidthSpin.setSingleStep(0.100000000000000)

        self.axisLineWidthSpinFieldLayout.addWidget(self.axisLineWidthSpin)


        self.axesAppearanceForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.axisLineWidthSpinFieldLayout)


        self.controlsLayout.addWidget(self.axesAppearanceGroup)

        self.secondaryAxisGroup = QGroupBox(self.controlsContent)
        self.secondaryAxisGroup.setObjectName(u"secondaryAxisGroup")
        self.secondaryAxisForm = QFormLayout(self.secondaryAxisGroup)
        self.secondaryAxisForm.setObjectName(u"secondaryAxisForm")
        self.secondaryAxisForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.secondaryAxisForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.secondaryAxisForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.secondaryAxisForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.secondaryAxisForm.setHorizontalSpacing(12)
        self.secondaryAxisForm.setVerticalSpacing(6)
        self.secondaryAxisForm.setContentsMargins(8, 10, 8, 8)
        self.secondaryAutoYLabel = QLabel(self.secondaryAxisGroup)
        self.secondaryAutoYLabel.setObjectName(u"secondaryAutoYLabel")

        self.secondaryAxisForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.secondaryAutoYLabel)

        self.secondaryAutoYRangeCheckFieldLayout = QHBoxLayout()
        self.secondaryAutoYRangeCheckFieldLayout.setSpacing(0)
        self.secondaryAutoYRangeCheckFieldLayout.setObjectName(u"secondaryAutoYRangeCheckFieldLayout")
        self.secondaryAutoYRangeCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.secondaryAutoYRangeCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.secondaryAutoYRangeCheckFieldLayout.addItem(self.secondaryAutoYRangeCheckLeftSpacer)

        self.secondaryAutoYRangeCheck = QCheckBox(self.secondaryAxisGroup)
        self.secondaryAutoYRangeCheck.setObjectName(u"secondaryAutoYRangeCheck")

        self.secondaryAutoYRangeCheckFieldLayout.addWidget(self.secondaryAutoYRangeCheck)


        self.secondaryAxisForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.secondaryAutoYRangeCheckFieldLayout)

        self.secondaryYMinLabel = QLabel(self.secondaryAxisGroup)
        self.secondaryYMinLabel.setObjectName(u"secondaryYMinLabel")

        self.secondaryAxisForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.secondaryYMinLabel)

        self.secondaryYMinSpinFieldLayout = QHBoxLayout()
        self.secondaryYMinSpinFieldLayout.setSpacing(0)
        self.secondaryYMinSpinFieldLayout.setObjectName(u"secondaryYMinSpinFieldLayout")
        self.secondaryYMinSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.secondaryYMinSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.secondaryYMinSpinFieldLayout.addItem(self.secondaryYMinSpinLeftSpacer)

        self.secondaryYMinSpin = QDoubleSpinBox(self.secondaryAxisGroup)
        self.secondaryYMinSpin.setObjectName(u"secondaryYMinSpin")
        self.secondaryYMinSpin.setMinimum(-1000000.000000000000000)
        self.secondaryYMinSpin.setMaximum(1000000.000000000000000)
        self.secondaryYMinSpin.setSingleStep(0.500000000000000)

        self.secondaryYMinSpinFieldLayout.addWidget(self.secondaryYMinSpin)


        self.secondaryAxisForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.secondaryYMinSpinFieldLayout)

        self.secondaryYMaxLabel = QLabel(self.secondaryAxisGroup)
        self.secondaryYMaxLabel.setObjectName(u"secondaryYMaxLabel")

        self.secondaryAxisForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.secondaryYMaxLabel)

        self.secondaryYMaxSpinFieldLayout = QHBoxLayout()
        self.secondaryYMaxSpinFieldLayout.setSpacing(0)
        self.secondaryYMaxSpinFieldLayout.setObjectName(u"secondaryYMaxSpinFieldLayout")
        self.secondaryYMaxSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.secondaryYMaxSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.secondaryYMaxSpinFieldLayout.addItem(self.secondaryYMaxSpinLeftSpacer)

        self.secondaryYMaxSpin = QDoubleSpinBox(self.secondaryAxisGroup)
        self.secondaryYMaxSpin.setObjectName(u"secondaryYMaxSpin")
        self.secondaryYMaxSpin.setMinimum(-1000000.000000000000000)
        self.secondaryYMaxSpin.setMaximum(1000000.000000000000000)
        self.secondaryYMaxSpin.setSingleStep(0.500000000000000)

        self.secondaryYMaxSpinFieldLayout.addWidget(self.secondaryYMaxSpin)


        self.secondaryAxisForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.secondaryYMaxSpinFieldLayout)

        self.secondaryAutoTickIntervalLabel = QLabel(self.secondaryAxisGroup)
        self.secondaryAutoTickIntervalLabel.setObjectName(u"secondaryAutoTickIntervalLabel")

        self.secondaryAxisForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.secondaryAutoTickIntervalLabel)

        self.secondaryAutoTickIntervalCheckFieldLayout = QHBoxLayout()
        self.secondaryAutoTickIntervalCheckFieldLayout.setSpacing(0)
        self.secondaryAutoTickIntervalCheckFieldLayout.setObjectName(u"secondaryAutoTickIntervalCheckFieldLayout")
        self.secondaryAutoTickIntervalCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.secondaryAutoTickIntervalCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.secondaryAutoTickIntervalCheckFieldLayout.addItem(self.secondaryAutoTickIntervalCheckLeftSpacer)

        self.secondaryAutoTickIntervalCheck = QCheckBox(self.secondaryAxisGroup)
        self.secondaryAutoTickIntervalCheck.setObjectName(u"secondaryAutoTickIntervalCheck")

        self.secondaryAutoTickIntervalCheckFieldLayout.addWidget(self.secondaryAutoTickIntervalCheck)


        self.secondaryAxisForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.secondaryAutoTickIntervalCheckFieldLayout)

        self.secondaryTickIntervalLabel = QLabel(self.secondaryAxisGroup)
        self.secondaryTickIntervalLabel.setObjectName(u"secondaryTickIntervalLabel")

        self.secondaryAxisForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.secondaryTickIntervalLabel)

        self.secondaryTickIntervalSpinFieldLayout = QHBoxLayout()
        self.secondaryTickIntervalSpinFieldLayout.setSpacing(0)
        self.secondaryTickIntervalSpinFieldLayout.setObjectName(u"secondaryTickIntervalSpinFieldLayout")
        self.secondaryTickIntervalSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.secondaryTickIntervalSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.secondaryTickIntervalSpinFieldLayout.addItem(self.secondaryTickIntervalSpinLeftSpacer)

        self.secondaryTickIntervalSpin = QDoubleSpinBox(self.secondaryAxisGroup)
        self.secondaryTickIntervalSpin.setObjectName(u"secondaryTickIntervalSpin")
        self.secondaryTickIntervalSpin.setDecimals(6)
        self.secondaryTickIntervalSpin.setMinimum(0.000001000000000)
        self.secondaryTickIntervalSpin.setMaximum(1000000.000000000000000)
        self.secondaryTickIntervalSpin.setSingleStep(0.500000000000000)

        self.secondaryTickIntervalSpinFieldLayout.addWidget(self.secondaryTickIntervalSpin)


        self.secondaryAxisForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.secondaryTickIntervalSpinFieldLayout)

        self.splitSecondaryAxisLabel = QLabel(self.secondaryAxisGroup)
        self.splitSecondaryAxisLabel.setObjectName(u"splitSecondaryAxisLabel")

        self.secondaryAxisForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.splitSecondaryAxisLabel)

        self.splitSecondaryAxisCheckFieldLayout = QHBoxLayout()
        self.splitSecondaryAxisCheckFieldLayout.setSpacing(0)
        self.splitSecondaryAxisCheckFieldLayout.setObjectName(u"splitSecondaryAxisCheckFieldLayout")
        self.splitSecondaryAxisCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.splitSecondaryAxisCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.splitSecondaryAxisCheckFieldLayout.addItem(self.splitSecondaryAxisCheckLeftSpacer)

        self.splitSecondaryAxisCheck = QCheckBox(self.secondaryAxisGroup)
        self.splitSecondaryAxisCheck.setObjectName(u"splitSecondaryAxisCheck")

        self.splitSecondaryAxisCheckFieldLayout.addWidget(self.splitSecondaryAxisCheck)


        self.secondaryAxisForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.splitSecondaryAxisCheckFieldLayout)

        self.secondaryAxisSplitRatioLabel = QLabel(self.secondaryAxisGroup)
        self.secondaryAxisSplitRatioLabel.setObjectName(u"secondaryAxisSplitRatioLabel")

        self.secondaryAxisForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.secondaryAxisSplitRatioLabel)

        self.secondaryAxisSplitRatioSpinFieldLayout = QHBoxLayout()
        self.secondaryAxisSplitRatioSpinFieldLayout.setSpacing(0)
        self.secondaryAxisSplitRatioSpinFieldLayout.setObjectName(u"secondaryAxisSplitRatioSpinFieldLayout")
        self.secondaryAxisSplitRatioSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.secondaryAxisSplitRatioSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.secondaryAxisSplitRatioSpinFieldLayout.addItem(self.secondaryAxisSplitRatioSpinLeftSpacer)

        self.secondaryAxisSplitRatioSpin = QDoubleSpinBox(self.secondaryAxisGroup)
        self.secondaryAxisSplitRatioSpin.setObjectName(u"secondaryAxisSplitRatioSpin")
        self.secondaryAxisSplitRatioSpin.setDecimals(2)
        self.secondaryAxisSplitRatioSpin.setMinimum(0.150000000000000)
        self.secondaryAxisSplitRatioSpin.setMaximum(0.850000000000000)
        self.secondaryAxisSplitRatioSpin.setSingleStep(0.050000000000000)

        self.secondaryAxisSplitRatioSpinFieldLayout.addWidget(self.secondaryAxisSplitRatioSpin)


        self.secondaryAxisForm.setLayout(6, QFormLayout.ItemRole.FieldRole, self.secondaryAxisSplitRatioSpinFieldLayout)


        self.controlsLayout.addWidget(self.secondaryAxisGroup)

        self.pointsGroup = QGroupBox(self.controlsContent)
        self.pointsGroup.setObjectName(u"pointsGroup")
        self.pointsGroupLayout = QVBoxLayout(self.pointsGroup)
        self.pointsGroupLayout.setSpacing(0)
        self.pointsGroupLayout.setObjectName(u"pointsGroupLayout")
        self.pointsGroupLayout.setContentsMargins(0, 0, 0, 0)
        self.xySeriesSelectionPanel = QWidget(self.pointsGroup)
        self.xySeriesSelectionPanel.setObjectName(u"xySeriesSelectionPanel")
        self.xySeriesSelectionPanel.setVisible(False)
        self.xySeriesSelectionPanelLayout = QVBoxLayout(self.xySeriesSelectionPanel)
        self.xySeriesSelectionPanelLayout.setSpacing(6)
        self.xySeriesSelectionPanelLayout.setObjectName(u"xySeriesSelectionPanelLayout")
        self.xySeriesSelectionPanelLayout.setContentsMargins(8, 8, 8, 4)
        self.xySeriesSelectionHeaderLayout = QHBoxLayout()
        self.xySeriesSelectionHeaderLayout.setSpacing(4)
        self.xySeriesSelectionHeaderLayout.setObjectName(u"xySeriesSelectionHeaderLayout")
        self.xySeriesSelectionCountLabel = QLabel(self.xySeriesSelectionPanel)
        self.xySeriesSelectionCountLabel.setObjectName(u"xySeriesSelectionCountLabel")

        self.xySeriesSelectionHeaderLayout.addWidget(self.xySeriesSelectionCountLabel)

        self.xySeriesSelectionHeaderSpacer = QSpacerItem(20, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xySeriesSelectionHeaderLayout.addItem(self.xySeriesSelectionHeaderSpacer)

        self.xySeriesSelectAllButton = QPushButton(self.xySeriesSelectionPanel)
        self.xySeriesSelectAllButton.setObjectName(u"xySeriesSelectAllButton")
        self.xySeriesSelectAllButton.setMinimumSize(QSize(76, 0))
        font = QFont()
        font.setBold(True)
        self.xySeriesSelectAllButton.setFont(font)

        self.xySeriesSelectionHeaderLayout.addWidget(self.xySeriesSelectAllButton)

        self.xySeriesClearSelectionButton = QToolButton(self.xySeriesSelectionPanel)
        self.xySeriesClearSelectionButton.setObjectName(u"xySeriesClearSelectionButton")

        self.xySeriesSelectionHeaderLayout.addWidget(self.xySeriesClearSelectionButton)

        self.xySeriesInvertSelectionButton = QToolButton(self.xySeriesSelectionPanel)
        self.xySeriesInvertSelectionButton.setObjectName(u"xySeriesInvertSelectionButton")

        self.xySeriesSelectionHeaderLayout.addWidget(self.xySeriesInvertSelectionButton)


        self.xySeriesSelectionPanelLayout.addLayout(self.xySeriesSelectionHeaderLayout)

        self.xySeriesSelectionList = QListWidget(self.xySeriesSelectionPanel)
        self.xySeriesSelectionList.setObjectName(u"xySeriesSelectionList")
        self.xySeriesSelectionList.setMinimumSize(QSize(0, 72))
        self.xySeriesSelectionList.setMaximumSize(QSize(16777215, 150))
        self.xySeriesSelectionList.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.xySeriesSelectionList.setUniformItemSizes(True)

        self.xySeriesSelectionPanelLayout.addWidget(self.xySeriesSelectionList)

        self.xyNoSeriesSelectedLabel = QLabel(self.xySeriesSelectionPanel)
        self.xyNoSeriesSelectedLabel.setObjectName(u"xyNoSeriesSelectedLabel")
        self.xyNoSeriesSelectedLabel.setVisible(False)
        self.xyNoSeriesSelectedLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.xySeriesSelectionPanelLayout.addWidget(self.xyNoSeriesSelectedLabel)


        self.pointsGroupLayout.addWidget(self.xySeriesSelectionPanel)

        self.pointsForm = QFormLayout()
        self.pointsForm.setObjectName(u"pointsForm")
        self.pointsForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.pointsForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.pointsForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.pointsForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.pointsForm.setHorizontalSpacing(12)
        self.pointsForm.setVerticalSpacing(6)
        self.pointsForm.setContentsMargins(8, 10, 8, 8)
        self.showPointsLabel = QLabel(self.pointsGroup)
        self.showPointsLabel.setObjectName(u"showPointsLabel")

        self.pointsForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.showPointsLabel)

        self.showPointsCheckFieldLayout = QHBoxLayout()
        self.showPointsCheckFieldLayout.setSpacing(0)
        self.showPointsCheckFieldLayout.setObjectName(u"showPointsCheckFieldLayout")
        self.showPointsCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showPointsCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showPointsCheckFieldLayout.addItem(self.showPointsCheckLeftSpacer)

        self.showPointsCheck = QCheckBox(self.pointsGroup)
        self.showPointsCheck.setObjectName(u"showPointsCheck")

        self.showPointsCheckFieldLayout.addWidget(self.showPointsCheck)


        self.pointsForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showPointsCheckFieldLayout)

        self.pointSizeLabel = QLabel(self.pointsGroup)
        self.pointSizeLabel.setObjectName(u"pointSizeLabel")

        self.pointsForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.pointSizeLabel)

        self.pointSizeSpinFieldLayout = QHBoxLayout()
        self.pointSizeSpinFieldLayout.setSpacing(0)
        self.pointSizeSpinFieldLayout.setObjectName(u"pointSizeSpinFieldLayout")
        self.pointSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.pointSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.pointSizeSpinFieldLayout.addItem(self.pointSizeSpinLeftSpacer)

        self.pointSizeSpin = QDoubleSpinBox(self.pointsGroup)
        self.pointSizeSpin.setObjectName(u"pointSizeSpin")
        self.pointSizeSpin.setMinimum(1.000000000000000)
        self.pointSizeSpin.setMaximum(14.000000000000000)
        self.pointSizeSpin.setSingleStep(0.500000000000000)

        self.pointSizeSpinFieldLayout.addWidget(self.pointSizeSpin)


        self.pointsForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.pointSizeSpinFieldLayout)

        self.pointAlphaLabel = QLabel(self.pointsGroup)
        self.pointAlphaLabel.setObjectName(u"pointAlphaLabel")

        self.pointsForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.pointAlphaLabel)

        self.pointAlphaSpinFieldLayout = QHBoxLayout()
        self.pointAlphaSpinFieldLayout.setSpacing(0)
        self.pointAlphaSpinFieldLayout.setObjectName(u"pointAlphaSpinFieldLayout")
        self.pointAlphaSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.pointAlphaSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.pointAlphaSpinFieldLayout.addItem(self.pointAlphaSpinLeftSpacer)

        self.pointAlphaSpin = QDoubleSpinBox(self.pointsGroup)
        self.pointAlphaSpin.setObjectName(u"pointAlphaSpin")
        self.pointAlphaSpin.setMinimum(0.100000000000000)
        self.pointAlphaSpin.setMaximum(1.000000000000000)
        self.pointAlphaSpin.setSingleStep(0.050000000000000)

        self.pointAlphaSpinFieldLayout.addWidget(self.pointAlphaSpin)


        self.pointsForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.pointAlphaSpinFieldLayout)

        self.xyMarkerLabel = QLabel(self.pointsGroup)
        self.xyMarkerLabel.setObjectName(u"xyMarkerLabel")

        self.pointsForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.xyMarkerLabel)

        self.xyMarkerFieldLayout = QHBoxLayout()
        self.xyMarkerFieldLayout.setObjectName(u"xyMarkerFieldLayout")
        self.xyMarkerLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xyMarkerFieldLayout.addItem(self.xyMarkerLeftSpacer)

        self.xyMarkerCombo = QComboBox(self.pointsGroup)
        self.xyMarkerCombo.setObjectName(u"xyMarkerCombo")

        self.xyMarkerFieldLayout.addWidget(self.xyMarkerCombo)


        self.pointsForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.xyMarkerFieldLayout)

        self.jitterModeLabel = QLabel(self.pointsGroup)
        self.jitterModeLabel.setObjectName(u"jitterModeLabel")

        self.pointsForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.jitterModeLabel)

        self.jitterModeComboFieldLayout = QHBoxLayout()
        self.jitterModeComboFieldLayout.setSpacing(0)
        self.jitterModeComboFieldLayout.setObjectName(u"jitterModeComboFieldLayout")
        self.jitterModeComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.jitterModeComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.jitterModeComboFieldLayout.addItem(self.jitterModeComboLeftSpacer)

        self.jitterModeCombo = QComboBox(self.pointsGroup)
        self.jitterModeCombo.setObjectName(u"jitterModeCombo")

        self.jitterModeComboFieldLayout.addWidget(self.jitterModeCombo)


        self.pointsForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.jitterModeComboFieldLayout)

        self.jitterLabel = QLabel(self.pointsGroup)
        self.jitterLabel.setObjectName(u"jitterLabel")

        self.pointsForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.jitterLabel)

        self.jitterSpinFieldLayout = QHBoxLayout()
        self.jitterSpinFieldLayout.setSpacing(0)
        self.jitterSpinFieldLayout.setObjectName(u"jitterSpinFieldLayout")
        self.jitterSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.jitterSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.jitterSpinFieldLayout.addItem(self.jitterSpinLeftSpacer)

        self.jitterSpin = QDoubleSpinBox(self.pointsGroup)
        self.jitterSpin.setObjectName(u"jitterSpin")
        self.jitterSpin.setMinimum(0.000000000000000)
        self.jitterSpin.setMaximum(0.600000000000000)
        self.jitterSpin.setSingleStep(0.020000000000000)

        self.jitterSpinFieldLayout.addWidget(self.jitterSpin)


        self.pointsForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.jitterSpinFieldLayout)

        self.xyShowLineLabel = QLabel(self.pointsGroup)
        self.xyShowLineLabel.setObjectName(u"xyShowLineLabel")

        self.pointsForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.xyShowLineLabel)

        self.xyShowLineFieldLayout = QHBoxLayout()
        self.xyShowLineFieldLayout.setObjectName(u"xyShowLineFieldLayout")
        self.xyShowLineLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xyShowLineFieldLayout.addItem(self.xyShowLineLeftSpacer)

        self.xyShowLineCheck = QCheckBox(self.pointsGroup)
        self.xyShowLineCheck.setObjectName(u"xyShowLineCheck")

        self.xyShowLineFieldLayout.addWidget(self.xyShowLineCheck)


        self.pointsForm.setLayout(6, QFormLayout.ItemRole.FieldRole, self.xyShowLineFieldLayout)

        self.xyLineWidthLabel = QLabel(self.pointsGroup)
        self.xyLineWidthLabel.setObjectName(u"xyLineWidthLabel")

        self.pointsForm.setWidget(7, QFormLayout.ItemRole.LabelRole, self.xyLineWidthLabel)

        self.xyLineWidthFieldLayout = QHBoxLayout()
        self.xyLineWidthFieldLayout.setObjectName(u"xyLineWidthFieldLayout")
        self.xyLineWidthLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xyLineWidthFieldLayout.addItem(self.xyLineWidthLeftSpacer)

        self.xyLineWidthSpin = QDoubleSpinBox(self.pointsGroup)
        self.xyLineWidthSpin.setObjectName(u"xyLineWidthSpin")
        self.xyLineWidthSpin.setMinimum(0.200000000000000)
        self.xyLineWidthSpin.setMaximum(8.000000000000000)
        self.xyLineWidthSpin.setSingleStep(0.200000000000000)

        self.xyLineWidthFieldLayout.addWidget(self.xyLineWidthSpin)


        self.pointsForm.setLayout(7, QFormLayout.ItemRole.FieldRole, self.xyLineWidthFieldLayout)

        self.xyLineStyleLabel = QLabel(self.pointsGroup)
        self.xyLineStyleLabel.setObjectName(u"xyLineStyleLabel")

        self.pointsForm.setWidget(8, QFormLayout.ItemRole.LabelRole, self.xyLineStyleLabel)

        self.xyLineStyleFieldLayout = QHBoxLayout()
        self.xyLineStyleFieldLayout.setObjectName(u"xyLineStyleFieldLayout")
        self.xyLineStyleLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.xyLineStyleFieldLayout.addItem(self.xyLineStyleLeftSpacer)

        self.xyLineStyleCombo = QComboBox(self.pointsGroup)
        self.xyLineStyleCombo.setObjectName(u"xyLineStyleCombo")

        self.xyLineStyleFieldLayout.addWidget(self.xyLineStyleCombo)


        self.pointsForm.setLayout(8, QFormLayout.ItemRole.FieldRole, self.xyLineStyleFieldLayout)


        self.pointsGroupLayout.addLayout(self.pointsForm)

        self.useAllSeriesStyleButtonLayout = QHBoxLayout()
        self.useAllSeriesStyleButtonLayout.setObjectName(u"useAllSeriesStyleButtonLayout")
        self.useAllSeriesStyleButtonLayout.setContentsMargins(8, 0, 8, 8)
        self.useAllSeriesStyleButton = QPushButton(self.pointsGroup)
        self.useAllSeriesStyleButton.setObjectName(u"useAllSeriesStyleButton")
        self.useAllSeriesStyleButton.setVisible(False)

        self.useAllSeriesStyleButtonLayout.addWidget(self.useAllSeriesStyleButton)


        self.pointsGroupLayout.addLayout(self.useAllSeriesStyleButtonLayout)


        self.controlsLayout.addWidget(self.pointsGroup)

        self.outliersGroup = QGroupBox(self.controlsContent)
        self.outliersGroup.setObjectName(u"outliersGroup")
        self.outliersForm = QFormLayout(self.outliersGroup)
        self.outliersForm.setObjectName(u"outliersForm")
        self.outliersForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.outliersForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.outliersForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.outliersForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.outliersForm.setHorizontalSpacing(12)
        self.outliersForm.setVerticalSpacing(6)
        self.outliersForm.setContentsMargins(8, 10, 8, 8)
        self.highlightLabel = QLabel(self.outliersGroup)
        self.highlightLabel.setObjectName(u"highlightLabel")

        self.outliersForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.highlightLabel)

        self.showOutliersCheckFieldLayout = QHBoxLayout()
        self.showOutliersCheckFieldLayout.setSpacing(0)
        self.showOutliersCheckFieldLayout.setObjectName(u"showOutliersCheckFieldLayout")
        self.showOutliersCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showOutliersCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showOutliersCheckFieldLayout.addItem(self.showOutliersCheckLeftSpacer)

        self.showOutliersCheck = QCheckBox(self.outliersGroup)
        self.showOutliersCheck.setObjectName(u"showOutliersCheck")

        self.showOutliersCheckFieldLayout.addWidget(self.showOutliersCheck)


        self.outliersForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showOutliersCheckFieldLayout)

        self.outlierMethodLabel = QLabel(self.outliersGroup)
        self.outlierMethodLabel.setObjectName(u"outlierMethodLabel")

        self.outliersForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.outlierMethodLabel)

        self.outlierMethodComboFieldLayout = QHBoxLayout()
        self.outlierMethodComboFieldLayout.setSpacing(0)
        self.outlierMethodComboFieldLayout.setObjectName(u"outlierMethodComboFieldLayout")
        self.outlierMethodComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.outlierMethodComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.outlierMethodComboFieldLayout.addItem(self.outlierMethodComboLeftSpacer)

        self.outlierMethodCombo = QComboBox(self.outliersGroup)
        self.outlierMethodCombo.setObjectName(u"outlierMethodCombo")

        self.outlierMethodComboFieldLayout.addWidget(self.outlierMethodCombo)


        self.outliersForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.outlierMethodComboFieldLayout)

        self.thresholdLabel = QLabel(self.outliersGroup)
        self.thresholdLabel.setObjectName(u"thresholdLabel")

        self.outliersForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.thresholdLabel)

        self.outlierThresholdSpinFieldLayout = QHBoxLayout()
        self.outlierThresholdSpinFieldLayout.setSpacing(0)
        self.outlierThresholdSpinFieldLayout.setObjectName(u"outlierThresholdSpinFieldLayout")
        self.outlierThresholdSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.outlierThresholdSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.outlierThresholdSpinFieldLayout.addItem(self.outlierThresholdSpinLeftSpacer)

        self.outlierThresholdSpin = QDoubleSpinBox(self.outliersGroup)
        self.outlierThresholdSpin.setObjectName(u"outlierThresholdSpin")
        self.outlierThresholdSpin.setMinimum(0.100000000000000)
        self.outlierThresholdSpin.setMaximum(10.000000000000000)
        self.outlierThresholdSpin.setSingleStep(0.100000000000000)

        self.outlierThresholdSpinFieldLayout.addWidget(self.outlierThresholdSpin)


        self.outliersForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.outlierThresholdSpinFieldLayout)

        self.effectLabel = QLabel(self.outliersGroup)
        self.effectLabel.setObjectName(u"effectLabel")

        self.outliersForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.effectLabel)

        self.outlierEffectComboFieldLayout = QHBoxLayout()
        self.outlierEffectComboFieldLayout.setSpacing(0)
        self.outlierEffectComboFieldLayout.setObjectName(u"outlierEffectComboFieldLayout")
        self.outlierEffectComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.outlierEffectComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.outlierEffectComboFieldLayout.addItem(self.outlierEffectComboLeftSpacer)

        self.outlierEffectCombo = QComboBox(self.outliersGroup)
        self.outlierEffectCombo.setObjectName(u"outlierEffectCombo")

        self.outlierEffectComboFieldLayout.addWidget(self.outlierEffectCombo)


        self.outliersForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.outlierEffectComboFieldLayout)


        self.controlsLayout.addWidget(self.outliersGroup)

        self.lineOverlayGroup = QGroupBox(self.controlsContent)
        self.lineOverlayGroup.setObjectName(u"lineOverlayGroup")
        self.lineOverlayForm = QFormLayout(self.lineOverlayGroup)
        self.lineOverlayForm.setObjectName(u"lineOverlayForm")
        self.lineOverlayForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.lineOverlayForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.lineOverlayForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.lineOverlayForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.lineOverlayForm.setHorizontalSpacing(12)
        self.lineOverlayForm.setVerticalSpacing(6)
        self.lineOverlayForm.setContentsMargins(8, 10, 8, 8)
        self.showLineOverlayLabel = QLabel(self.lineOverlayGroup)
        self.showLineOverlayLabel.setObjectName(u"showLineOverlayLabel")

        self.lineOverlayForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.showLineOverlayLabel)

        self.showLineOverlayCheckFieldLayout = QHBoxLayout()
        self.showLineOverlayCheckFieldLayout.setSpacing(0)
        self.showLineOverlayCheckFieldLayout.setObjectName(u"showLineOverlayCheckFieldLayout")
        self.showLineOverlayCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showLineOverlayCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showLineOverlayCheckFieldLayout.addItem(self.showLineOverlayCheckLeftSpacer)

        self.showLineOverlayCheck = QCheckBox(self.lineOverlayGroup)
        self.showLineOverlayCheck.setObjectName(u"showLineOverlayCheck")

        self.showLineOverlayCheckFieldLayout.addWidget(self.showLineOverlayCheck)


        self.lineOverlayForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showLineOverlayCheckFieldLayout)

        self.lineOverlayStatLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayStatLabel.setObjectName(u"lineOverlayStatLabel")

        self.lineOverlayForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.lineOverlayStatLabel)

        self.lineOverlayStatComboFieldLayout = QHBoxLayout()
        self.lineOverlayStatComboFieldLayout.setSpacing(0)
        self.lineOverlayStatComboFieldLayout.setObjectName(u"lineOverlayStatComboFieldLayout")
        self.lineOverlayStatComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayStatComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayStatComboFieldLayout.addItem(self.lineOverlayStatComboLeftSpacer)

        self.lineOverlayStatCombo = QComboBox(self.lineOverlayGroup)
        self.lineOverlayStatCombo.setObjectName(u"lineOverlayStatCombo")

        self.lineOverlayStatComboFieldLayout.addWidget(self.lineOverlayStatCombo)


        self.lineOverlayForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.lineOverlayStatComboFieldLayout)

        self.extraCustomOverlayLabel = QLabel(self.lineOverlayGroup)
        self.extraCustomOverlayLabel.setObjectName(u"extraCustomOverlayLabel")

        self.lineOverlayForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.extraCustomOverlayLabel)

        self.extraCustomOverlayCheckFieldLayout = QHBoxLayout()
        self.extraCustomOverlayCheckFieldLayout.setSpacing(0)
        self.extraCustomOverlayCheckFieldLayout.setObjectName(u"extraCustomOverlayCheckFieldLayout")
        self.extraCustomOverlayCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.extraCustomOverlayCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.extraCustomOverlayCheckFieldLayout.addItem(self.extraCustomOverlayCheckLeftSpacer)

        self.extraCustomOverlayCheck = QCheckBox(self.lineOverlayGroup)
        self.extraCustomOverlayCheck.setObjectName(u"extraCustomOverlayCheck")

        self.extraCustomOverlayCheckFieldLayout.addWidget(self.extraCustomOverlayCheck)


        self.lineOverlayForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.extraCustomOverlayCheckFieldLayout)

        self.customOverlayCountLabel = QLabel(self.lineOverlayGroup)
        self.customOverlayCountLabel.setObjectName(u"customOverlayCountLabel")

        self.lineOverlayForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.customOverlayCountLabel)

        self.customOverlayCountSpinFieldLayout = QHBoxLayout()
        self.customOverlayCountSpinFieldLayout.setSpacing(0)
        self.customOverlayCountSpinFieldLayout.setObjectName(u"customOverlayCountSpinFieldLayout")
        self.customOverlayCountSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.customOverlayCountSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.customOverlayCountSpinFieldLayout.addItem(self.customOverlayCountSpinLeftSpacer)

        self.customOverlayCountSpin = QSpinBox(self.lineOverlayGroup)
        self.customOverlayCountSpin.setObjectName(u"customOverlayCountSpin")
        self.customOverlayCountSpin.setMinimum(1)
        self.customOverlayCountSpin.setMaximum(12)
        self.customOverlayCountSpin.setValue(1)

        self.customOverlayCountSpinFieldLayout.addWidget(self.customOverlayCountSpin)

        self.customOverlayFilterButton = QPushButton(self.lineOverlayGroup)
        self.customOverlayFilterButton.setObjectName(u"customOverlayFilterButton")

        self.customOverlayCountSpinFieldLayout.addWidget(self.customOverlayFilterButton)


        self.lineOverlayForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.customOverlayCountSpinFieldLayout)

        self.customOverlaySecondaryAxisLabel = QLabel(self.lineOverlayGroup)
        self.customOverlaySecondaryAxisLabel.setObjectName(u"customOverlaySecondaryAxisLabel")

        self.lineOverlayForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.customOverlaySecondaryAxisLabel)

        self.customOverlaySecondaryAxisCheckFieldLayout = QHBoxLayout()
        self.customOverlaySecondaryAxisCheckFieldLayout.setSpacing(0)
        self.customOverlaySecondaryAxisCheckFieldLayout.setObjectName(u"customOverlaySecondaryAxisCheckFieldLayout")
        self.customOverlaySecondaryAxisCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.customOverlaySecondaryAxisCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.customOverlaySecondaryAxisCheckFieldLayout.addItem(self.customOverlaySecondaryAxisCheckLeftSpacer)

        self.customOverlaySecondaryAxisCheck = QCheckBox(self.lineOverlayGroup)
        self.customOverlaySecondaryAxisCheck.setObjectName(u"customOverlaySecondaryAxisCheck")

        self.customOverlaySecondaryAxisCheckFieldLayout.addWidget(self.customOverlaySecondaryAxisCheck)


        self.lineOverlayForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.customOverlaySecondaryAxisCheckFieldLayout)

        self.lineOverlayWidthLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayWidthLabel.setObjectName(u"lineOverlayWidthLabel")

        self.lineOverlayForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.lineOverlayWidthLabel)

        self.lineOverlayWidthSpinFieldLayout = QHBoxLayout()
        self.lineOverlayWidthSpinFieldLayout.setSpacing(0)
        self.lineOverlayWidthSpinFieldLayout.setObjectName(u"lineOverlayWidthSpinFieldLayout")
        self.lineOverlayWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayWidthSpinFieldLayout.addItem(self.lineOverlayWidthSpinLeftSpacer)

        self.lineOverlayWidthSpin = QDoubleSpinBox(self.lineOverlayGroup)
        self.lineOverlayWidthSpin.setObjectName(u"lineOverlayWidthSpin")
        self.lineOverlayWidthSpin.setMinimum(0.200000000000000)
        self.lineOverlayWidthSpin.setMaximum(10.000000000000000)
        self.lineOverlayWidthSpin.setSingleStep(0.100000000000000)

        self.lineOverlayWidthSpinFieldLayout.addWidget(self.lineOverlayWidthSpin)


        self.lineOverlayForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.lineOverlayWidthSpinFieldLayout)

        self.lineOverlayStyleLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayStyleLabel.setObjectName(u"lineOverlayStyleLabel")

        self.lineOverlayForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.lineOverlayStyleLabel)

        self.lineOverlayStyleComboFieldLayout = QHBoxLayout()
        self.lineOverlayStyleComboFieldLayout.setSpacing(0)
        self.lineOverlayStyleComboFieldLayout.setObjectName(u"lineOverlayStyleComboFieldLayout")
        self.lineOverlayStyleComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayStyleComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayStyleComboFieldLayout.addItem(self.lineOverlayStyleComboLeftSpacer)

        self.lineOverlayStyleCombo = QComboBox(self.lineOverlayGroup)
        self.lineOverlayStyleCombo.setObjectName(u"lineOverlayStyleCombo")

        self.lineOverlayStyleComboFieldLayout.addWidget(self.lineOverlayStyleCombo)


        self.lineOverlayForm.setLayout(6, QFormLayout.ItemRole.FieldRole, self.lineOverlayStyleComboFieldLayout)

        self.lineOverlayBreakBetweenParentsLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayBreakBetweenParentsLabel.setObjectName(u"lineOverlayBreakBetweenParentsLabel")
        self.lineOverlayBreakBetweenParentsLabel.setEnabled(False)

        self.lineOverlayForm.setWidget(7, QFormLayout.ItemRole.LabelRole, self.lineOverlayBreakBetweenParentsLabel)

        self.lineOverlayBreakBetweenParentsFieldLayout = QHBoxLayout()
        self.lineOverlayBreakBetweenParentsFieldLayout.setSpacing(0)
        self.lineOverlayBreakBetweenParentsFieldLayout.setObjectName(u"lineOverlayBreakBetweenParentsFieldLayout")
        self.lineOverlayBreakBetweenParentsFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayBreakBetweenParentsSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayBreakBetweenParentsFieldLayout.addItem(self.lineOverlayBreakBetweenParentsSpacer)

        self.lineOverlayBreakBetweenParentsCheck = QCheckBox(self.lineOverlayGroup)
        self.lineOverlayBreakBetweenParentsCheck.setObjectName(u"lineOverlayBreakBetweenParentsCheck")
        self.lineOverlayBreakBetweenParentsCheck.setEnabled(False)

        self.lineOverlayBreakBetweenParentsFieldLayout.addWidget(self.lineOverlayBreakBetweenParentsCheck)


        self.lineOverlayForm.setLayout(7, QFormLayout.ItemRole.FieldRole, self.lineOverlayBreakBetweenParentsFieldLayout)

        self.editOverlayStylesLabel = QLabel(self.lineOverlayGroup)
        self.editOverlayStylesLabel.setObjectName(u"editOverlayStylesLabel")

        self.lineOverlayForm.setWidget(8, QFormLayout.ItemRole.LabelRole, self.editOverlayStylesLabel)

        self.editOverlayStylesButtonFieldLayout = QHBoxLayout()
        self.editOverlayStylesButtonFieldLayout.setSpacing(0)
        self.editOverlayStylesButtonFieldLayout.setObjectName(u"editOverlayStylesButtonFieldLayout")
        self.editOverlayStylesButtonFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.editOverlayStylesButtonLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.editOverlayStylesButtonFieldLayout.addItem(self.editOverlayStylesButtonLeftSpacer)

        self.editOverlayStylesButton = QPushButton(self.lineOverlayGroup)
        self.editOverlayStylesButton.setObjectName(u"editOverlayStylesButton")

        self.editOverlayStylesButtonFieldLayout.addWidget(self.editOverlayStylesButton)


        self.lineOverlayForm.setLayout(8, QFormLayout.ItemRole.FieldRole, self.editOverlayStylesButtonFieldLayout)

        self.lineOverlayPointSizeLabel = QLabel(self.lineOverlayGroup)
        self.lineOverlayPointSizeLabel.setObjectName(u"lineOverlayPointSizeLabel")

        self.lineOverlayForm.setWidget(9, QFormLayout.ItemRole.LabelRole, self.lineOverlayPointSizeLabel)

        self.lineOverlayPointSizeSpinFieldLayout = QHBoxLayout()
        self.lineOverlayPointSizeSpinFieldLayout.setSpacing(0)
        self.lineOverlayPointSizeSpinFieldLayout.setObjectName(u"lineOverlayPointSizeSpinFieldLayout")
        self.lineOverlayPointSizeSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineOverlayPointSizeSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineOverlayPointSizeSpinFieldLayout.addItem(self.lineOverlayPointSizeSpinLeftSpacer)

        self.lineOverlayPointSizeSpin = QDoubleSpinBox(self.lineOverlayGroup)
        self.lineOverlayPointSizeSpin.setObjectName(u"lineOverlayPointSizeSpin")
        self.lineOverlayPointSizeSpin.setMinimum(0.000000000000000)
        self.lineOverlayPointSizeSpin.setMaximum(20.000000000000000)
        self.lineOverlayPointSizeSpin.setSingleStep(0.500000000000000)

        self.lineOverlayPointSizeSpinFieldLayout.addWidget(self.lineOverlayPointSizeSpin)


        self.lineOverlayForm.setLayout(9, QFormLayout.ItemRole.FieldRole, self.lineOverlayPointSizeSpinFieldLayout)

        self.showLineValuesLabel = QLabel(self.lineOverlayGroup)
        self.showLineValuesLabel.setObjectName(u"showLineValuesLabel")

        self.lineOverlayForm.setWidget(10, QFormLayout.ItemRole.LabelRole, self.showLineValuesLabel)

        self.showLineValuesCheckFieldLayout = QHBoxLayout()
        self.showLineValuesCheckFieldLayout.setSpacing(0)
        self.showLineValuesCheckFieldLayout.setObjectName(u"showLineValuesCheckFieldLayout")
        self.showLineValuesCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showLineValuesCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showLineValuesCheckFieldLayout.addItem(self.showLineValuesCheckLeftSpacer)

        self.showLineValuesCheck = QCheckBox(self.lineOverlayGroup)
        self.showLineValuesCheck.setObjectName(u"showLineValuesCheck")

        self.showLineValuesCheckFieldLayout.addWidget(self.showLineValuesCheck)


        self.lineOverlayForm.setLayout(10, QFormLayout.ItemRole.FieldRole, self.showLineValuesCheckFieldLayout)

        self.lineValuePositionLabel = QLabel(self.lineOverlayGroup)
        self.lineValuePositionLabel.setObjectName(u"lineValuePositionLabel")

        self.lineOverlayForm.setWidget(11, QFormLayout.ItemRole.LabelRole, self.lineValuePositionLabel)

        self.lineValuePositionComboFieldLayout = QHBoxLayout()
        self.lineValuePositionComboFieldLayout.setSpacing(0)
        self.lineValuePositionComboFieldLayout.setObjectName(u"lineValuePositionComboFieldLayout")
        self.lineValuePositionComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineValuePositionComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineValuePositionComboFieldLayout.addItem(self.lineValuePositionComboLeftSpacer)

        self.lineValuePositionCombo = QComboBox(self.lineOverlayGroup)
        self.lineValuePositionCombo.setObjectName(u"lineValuePositionCombo")

        self.lineValuePositionComboFieldLayout.addWidget(self.lineValuePositionCombo)


        self.lineOverlayForm.setLayout(11, QFormLayout.ItemRole.FieldRole, self.lineValuePositionComboFieldLayout)

        self.customLineValuePositionLabel = QLabel(self.lineOverlayGroup)
        self.customLineValuePositionLabel.setObjectName(u"customLineValuePositionLabel")

        self.lineOverlayForm.setWidget(12, QFormLayout.ItemRole.LabelRole, self.customLineValuePositionLabel)

        self.customLineValuePositionComboFieldLayout = QHBoxLayout()
        self.customLineValuePositionComboFieldLayout.setSpacing(0)
        self.customLineValuePositionComboFieldLayout.setObjectName(u"customLineValuePositionComboFieldLayout")
        self.customLineValuePositionComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.customLineValuePositionComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.customLineValuePositionComboFieldLayout.addItem(self.customLineValuePositionComboLeftSpacer)

        self.customLineValuePositionCombo = QComboBox(self.lineOverlayGroup)
        self.customLineValuePositionCombo.setObjectName(u"customLineValuePositionCombo")

        self.customLineValuePositionComboFieldLayout.addWidget(self.customLineValuePositionCombo)


        self.lineOverlayForm.setLayout(12, QFormLayout.ItemRole.FieldRole, self.customLineValuePositionComboFieldLayout)

        self.lineValueScientificLabel = QLabel(self.lineOverlayGroup)
        self.lineValueScientificLabel.setObjectName(u"lineValueScientificLabel")

        self.lineOverlayForm.setWidget(13, QFormLayout.ItemRole.LabelRole, self.lineValueScientificLabel)

        self.lineValueScientificCheckFieldLayout = QHBoxLayout()
        self.lineValueScientificCheckFieldLayout.setSpacing(0)
        self.lineValueScientificCheckFieldLayout.setObjectName(u"lineValueScientificCheckFieldLayout")
        self.lineValueScientificCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineValueScientificCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineValueScientificCheckFieldLayout.addItem(self.lineValueScientificCheckLeftSpacer)

        self.lineValueScientificCheck = QCheckBox(self.lineOverlayGroup)
        self.lineValueScientificCheck.setObjectName(u"lineValueScientificCheck")

        self.lineValueScientificCheckFieldLayout.addWidget(self.lineValueScientificCheck)


        self.lineOverlayForm.setLayout(13, QFormLayout.ItemRole.FieldRole, self.lineValueScientificCheckFieldLayout)

        self.lineValueDecimalsLabel = QLabel(self.lineOverlayGroup)
        self.lineValueDecimalsLabel.setObjectName(u"lineValueDecimalsLabel")

        self.lineOverlayForm.setWidget(14, QFormLayout.ItemRole.LabelRole, self.lineValueDecimalsLabel)

        self.lineValueDecimalsSpinFieldLayout = QHBoxLayout()
        self.lineValueDecimalsSpinFieldLayout.setSpacing(0)
        self.lineValueDecimalsSpinFieldLayout.setObjectName(u"lineValueDecimalsSpinFieldLayout")
        self.lineValueDecimalsSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.lineValueDecimalsSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.lineValueDecimalsSpinFieldLayout.addItem(self.lineValueDecimalsSpinLeftSpacer)

        self.lineValueDecimalsSpin = QSpinBox(self.lineOverlayGroup)
        self.lineValueDecimalsSpin.setObjectName(u"lineValueDecimalsSpin")
        self.lineValueDecimalsSpin.setMinimum(0)
        self.lineValueDecimalsSpin.setMaximum(12)
        self.lineValueDecimalsSpin.setValue(2)

        self.lineValueDecimalsSpinFieldLayout.addWidget(self.lineValueDecimalsSpin)


        self.lineOverlayForm.setLayout(14, QFormLayout.ItemRole.FieldRole, self.lineValueDecimalsSpinFieldLayout)

        self.labelNumberFormatsButton = QPushButton(self.lineOverlayGroup)
        self.labelNumberFormatsButton.setObjectName(u"labelNumberFormatsButton")

        self.lineOverlayForm.setWidget(15, QFormLayout.ItemRole.SpanningRole, self.labelNumberFormatsButton)


        self.controlsLayout.addWidget(self.lineOverlayGroup)

        self.statsTableGroup = QGroupBox(self.controlsContent)
        self.statsTableGroup.setObjectName(u"statsTableGroup")
        self.statsTableLayout = QVBoxLayout(self.statsTableGroup)
        self.statsTableLayout.setSpacing(6)
        self.statsTableLayout.setObjectName(u"statsTableLayout")
        self.statsTableLayout.setContentsMargins(8, 10, 8, 8)
        self.showStatTableCheck = QCheckBox(self.statsTableGroup)
        self.showStatTableCheck.setObjectName(u"showStatTableCheck")
        self.showStatTableCheck.setChecked(True)

        self.statsTableLayout.addWidget(self.showStatTableCheck)

        self.showStatHeaderCheck = QCheckBox(self.statsTableGroup)
        self.showStatHeaderCheck.setObjectName(u"showStatHeaderCheck")

        self.statsTableLayout.addWidget(self.showStatHeaderCheck)

        self.statTableOptionsList = QListWidget(self.statsTableGroup)
        self.statTableOptionsList.setObjectName(u"statTableOptionsList")
        self.statTableOptionsList.setMinimumSize(QSize(0, 150))
        self.statTableOptionsList.setMaximumSize(QSize(16777215, 190))
        self.statTableOptionsList.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.statTableOptionsList.setAlternatingRowColors(False)
        self.statTableOptionsList.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)

        self.statsTableLayout.addWidget(self.statTableOptionsList)

        self.statisticNumberFormatsButton = QPushButton(self.statsTableGroup)
        self.statisticNumberFormatsButton.setObjectName(u"statisticNumberFormatsButton")

        self.statsTableLayout.addWidget(self.statisticNumberFormatsButton)


        self.controlsLayout.addWidget(self.statsTableGroup)

        self.legendGroup = QGroupBox(self.controlsContent)
        self.legendGroup.setObjectName(u"legendGroup")
        self.legendForm = QFormLayout(self.legendGroup)
        self.legendForm.setObjectName(u"legendForm")
        self.legendForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.legendForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.legendForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.legendForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.legendForm.setHorizontalSpacing(12)
        self.legendForm.setVerticalSpacing(6)
        self.legendForm.setContentsMargins(8, 10, 8, 8)
        self.showLegendLabel = QLabel(self.legendGroup)
        self.showLegendLabel.setObjectName(u"showLegendLabel")

        self.legendForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.showLegendLabel)

        self.showLegendCheckFieldLayout = QHBoxLayout()
        self.showLegendCheckFieldLayout.setSpacing(0)
        self.showLegendCheckFieldLayout.setObjectName(u"showLegendCheckFieldLayout")
        self.showLegendCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.showLegendCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.showLegendCheckFieldLayout.addItem(self.showLegendCheckLeftSpacer)

        self.showLegendCheck = QCheckBox(self.legendGroup)
        self.showLegendCheck.setObjectName(u"showLegendCheck")

        self.showLegendCheckFieldLayout.addWidget(self.showLegendCheck)


        self.legendForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.showLegendCheckFieldLayout)

        self.legendPositionLabel = QLabel(self.legendGroup)
        self.legendPositionLabel.setObjectName(u"legendPositionLabel")

        self.legendForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.legendPositionLabel)

        self.legendPositionComboFieldLayout = QHBoxLayout()
        self.legendPositionComboFieldLayout.setSpacing(0)
        self.legendPositionComboFieldLayout.setObjectName(u"legendPositionComboFieldLayout")
        self.legendPositionComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.legendPositionComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.legendPositionComboFieldLayout.addItem(self.legendPositionComboLeftSpacer)

        self.legendPositionCombo = QComboBox(self.legendGroup)
        self.legendPositionCombo.setObjectName(u"legendPositionCombo")

        self.legendPositionComboFieldLayout.addWidget(self.legendPositionCombo)


        self.legendForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.legendPositionComboFieldLayout)

        self.legendAutoWidthLabel = QLabel(self.legendGroup)
        self.legendAutoWidthLabel.setObjectName(u"legendAutoWidthLabel")

        self.legendForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.legendAutoWidthLabel)

        self.legendAutoWidthCheckFieldLayout = QHBoxLayout()
        self.legendAutoWidthCheckFieldLayout.setSpacing(0)
        self.legendAutoWidthCheckFieldLayout.setObjectName(u"legendAutoWidthCheckFieldLayout")
        self.legendAutoWidthCheckFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.legendAutoWidthCheckLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.legendAutoWidthCheckFieldLayout.addItem(self.legendAutoWidthCheckLeftSpacer)

        self.legendAutoWidthCheck = QCheckBox(self.legendGroup)
        self.legendAutoWidthCheck.setObjectName(u"legendAutoWidthCheck")

        self.legendAutoWidthCheckFieldLayout.addWidget(self.legendAutoWidthCheck)


        self.legendForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.legendAutoWidthCheckFieldLayout)

        self.legendWidthLabel = QLabel(self.legendGroup)
        self.legendWidthLabel.setObjectName(u"legendWidthLabel")

        self.legendForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.legendWidthLabel)

        self.legendWidthSpinFieldLayout = QHBoxLayout()
        self.legendWidthSpinFieldLayout.setSpacing(0)
        self.legendWidthSpinFieldLayout.setObjectName(u"legendWidthSpinFieldLayout")
        self.legendWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.legendWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.legendWidthSpinFieldLayout.addItem(self.legendWidthSpinLeftSpacer)

        self.legendWidthSpin = QDoubleSpinBox(self.legendGroup)
        self.legendWidthSpin.setObjectName(u"legendWidthSpin")
        self.legendWidthSpin.setDecimals(2)
        self.legendWidthSpin.setMinimum(0.500000000000000)
        self.legendWidthSpin.setMaximum(20.000000000000000)
        self.legendWidthSpin.setSingleStep(0.100000000000000)

        self.legendWidthSpinFieldLayout.addWidget(self.legendWidthSpin)


        self.legendForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.legendWidthSpinFieldLayout)

        self.legendColumnsLabel = QLabel(self.legendGroup)
        self.legendColumnsLabel.setObjectName(u"legendColumnsLabel")

        self.legendForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.legendColumnsLabel)

        self.legendColumnsComboFieldLayout = QHBoxLayout()
        self.legendColumnsComboFieldLayout.setSpacing(0)
        self.legendColumnsComboFieldLayout.setObjectName(u"legendColumnsComboFieldLayout")
        self.legendColumnsComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.legendColumnsComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.legendColumnsComboFieldLayout.addItem(self.legendColumnsComboLeftSpacer)

        self.legendColumnsCombo = QComboBox(self.legendGroup)
        self.legendColumnsCombo.setObjectName(u"legendColumnsCombo")

        self.legendColumnsComboFieldLayout.addWidget(self.legendColumnsCombo)


        self.legendForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.legendColumnsComboFieldLayout)


        self.controlsLayout.addWidget(self.legendGroup)

        self.specificGroup = QGroupBox(self.controlsContent)
        self.specificGroup.setObjectName(u"specificGroup")
        self.specificForm = QFormLayout(self.specificGroup)
        self.specificForm.setObjectName(u"specificForm")
        self.specificForm.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.specificForm.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.specificForm.setLabelAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.specificForm.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.specificForm.setHorizontalSpacing(12)
        self.specificForm.setVerticalSpacing(6)
        self.specificForm.setContentsMargins(8, 10, 8, 8)
        self.barWidthLabel = QLabel(self.specificGroup)
        self.barWidthLabel.setObjectName(u"barWidthLabel")

        self.specificForm.setWidget(0, QFormLayout.ItemRole.LabelRole, self.barWidthLabel)

        self.barWidthSpinFieldLayout = QHBoxLayout()
        self.barWidthSpinFieldLayout.setSpacing(0)
        self.barWidthSpinFieldLayout.setObjectName(u"barWidthSpinFieldLayout")
        self.barWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.barWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.barWidthSpinFieldLayout.addItem(self.barWidthSpinLeftSpacer)

        self.barWidthSpin = QDoubleSpinBox(self.specificGroup)
        self.barWidthSpin.setObjectName(u"barWidthSpin")
        self.barWidthSpin.setMinimum(0.200000000000000)
        self.barWidthSpin.setMaximum(1.000000000000000)
        self.barWidthSpin.setSingleStep(0.050000000000000)

        self.barWidthSpinFieldLayout.addWidget(self.barWidthSpin)


        self.specificForm.setLayout(0, QFormLayout.ItemRole.FieldRole, self.barWidthSpinFieldLayout)

        self.barSummaryLabel = QLabel(self.specificGroup)
        self.barSummaryLabel.setObjectName(u"barSummaryLabel")

        self.specificForm.setWidget(1, QFormLayout.ItemRole.LabelRole, self.barSummaryLabel)

        self.barSummaryComboFieldLayout = QHBoxLayout()
        self.barSummaryComboFieldLayout.setSpacing(0)
        self.barSummaryComboFieldLayout.setObjectName(u"barSummaryComboFieldLayout")
        self.barSummaryComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.barSummaryComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.barSummaryComboFieldLayout.addItem(self.barSummaryComboLeftSpacer)

        self.barSummaryCombo = QComboBox(self.specificGroup)
        self.barSummaryCombo.setObjectName(u"barSummaryCombo")

        self.barSummaryComboFieldLayout.addWidget(self.barSummaryCombo)


        self.specificForm.setLayout(1, QFormLayout.ItemRole.FieldRole, self.barSummaryComboFieldLayout)

        self.boxWidthLabel = QLabel(self.specificGroup)
        self.boxWidthLabel.setObjectName(u"boxWidthLabel")

        self.specificForm.setWidget(2, QFormLayout.ItemRole.LabelRole, self.boxWidthLabel)

        self.boxWidthSpinFieldLayout = QHBoxLayout()
        self.boxWidthSpinFieldLayout.setSpacing(0)
        self.boxWidthSpinFieldLayout.setObjectName(u"boxWidthSpinFieldLayout")
        self.boxWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.boxWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.boxWidthSpinFieldLayout.addItem(self.boxWidthSpinLeftSpacer)

        self.boxWidthSpin = QDoubleSpinBox(self.specificGroup)
        self.boxWidthSpin.setObjectName(u"boxWidthSpin")
        self.boxWidthSpin.setMinimum(0.200000000000000)
        self.boxWidthSpin.setMaximum(1.000000000000000)
        self.boxWidthSpin.setSingleStep(0.050000000000000)

        self.boxWidthSpinFieldLayout.addWidget(self.boxWidthSpin)


        self.specificForm.setLayout(2, QFormLayout.ItemRole.FieldRole, self.boxWidthSpinFieldLayout)

        self.boxWhiskerLabel = QLabel(self.specificGroup)
        self.boxWhiskerLabel.setObjectName(u"boxWhiskerLabel")

        self.specificForm.setWidget(3, QFormLayout.ItemRole.LabelRole, self.boxWhiskerLabel)

        self.boxWhiskerModeComboFieldLayout = QHBoxLayout()
        self.boxWhiskerModeComboFieldLayout.setSpacing(0)
        self.boxWhiskerModeComboFieldLayout.setObjectName(u"boxWhiskerModeComboFieldLayout")
        self.boxWhiskerModeComboFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.boxWhiskerModeComboLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.boxWhiskerModeComboFieldLayout.addItem(self.boxWhiskerModeComboLeftSpacer)

        self.boxWhiskerModeCombo = QComboBox(self.specificGroup)
        self.boxWhiskerModeCombo.setObjectName(u"boxWhiskerModeCombo")

        self.boxWhiskerModeComboFieldLayout.addWidget(self.boxWhiskerModeCombo)


        self.specificForm.setLayout(3, QFormLayout.ItemRole.FieldRole, self.boxWhiskerModeComboFieldLayout)

        self.violinWidthLabel = QLabel(self.specificGroup)
        self.violinWidthLabel.setObjectName(u"violinWidthLabel")

        self.specificForm.setWidget(4, QFormLayout.ItemRole.LabelRole, self.violinWidthLabel)

        self.violinWidthSpinFieldLayout = QHBoxLayout()
        self.violinWidthSpinFieldLayout.setSpacing(0)
        self.violinWidthSpinFieldLayout.setObjectName(u"violinWidthSpinFieldLayout")
        self.violinWidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.violinWidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.violinWidthSpinFieldLayout.addItem(self.violinWidthSpinLeftSpacer)

        self.violinWidthSpin = QDoubleSpinBox(self.specificGroup)
        self.violinWidthSpin.setObjectName(u"violinWidthSpin")
        self.violinWidthSpin.setMinimum(0.200000000000000)
        self.violinWidthSpin.setMaximum(1.000000000000000)
        self.violinWidthSpin.setSingleStep(0.050000000000000)

        self.violinWidthSpinFieldLayout.addWidget(self.violinWidthSpin)


        self.specificForm.setLayout(4, QFormLayout.ItemRole.FieldRole, self.violinWidthSpinFieldLayout)

        self.kdeBandwidthLabel = QLabel(self.specificGroup)
        self.kdeBandwidthLabel.setObjectName(u"kdeBandwidthLabel")

        self.specificForm.setWidget(5, QFormLayout.ItemRole.LabelRole, self.kdeBandwidthLabel)

        self.kdeBandwidthSpinFieldLayout = QHBoxLayout()
        self.kdeBandwidthSpinFieldLayout.setSpacing(0)
        self.kdeBandwidthSpinFieldLayout.setObjectName(u"kdeBandwidthSpinFieldLayout")
        self.kdeBandwidthSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.kdeBandwidthSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.kdeBandwidthSpinFieldLayout.addItem(self.kdeBandwidthSpinLeftSpacer)

        self.kdeBandwidthSpin = QDoubleSpinBox(self.specificGroup)
        self.kdeBandwidthSpin.setObjectName(u"kdeBandwidthSpin")
        self.kdeBandwidthSpin.setMinimum(0.200000000000000)
        self.kdeBandwidthSpin.setMaximum(3.000000000000000)
        self.kdeBandwidthSpin.setSingleStep(0.100000000000000)

        self.kdeBandwidthSpinFieldLayout.addWidget(self.kdeBandwidthSpin)


        self.specificForm.setLayout(5, QFormLayout.ItemRole.FieldRole, self.kdeBandwidthSpinFieldLayout)

        self.ridgeOverlapLabel = QLabel(self.specificGroup)
        self.ridgeOverlapLabel.setObjectName(u"ridgeOverlapLabel")

        self.specificForm.setWidget(6, QFormLayout.ItemRole.LabelRole, self.ridgeOverlapLabel)

        self.ridgeOverlapSpinFieldLayout = QHBoxLayout()
        self.ridgeOverlapSpinFieldLayout.setSpacing(0)
        self.ridgeOverlapSpinFieldLayout.setObjectName(u"ridgeOverlapSpinFieldLayout")
        self.ridgeOverlapSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.ridgeOverlapSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.ridgeOverlapSpinFieldLayout.addItem(self.ridgeOverlapSpinLeftSpacer)

        self.ridgeOverlapSpin = QDoubleSpinBox(self.specificGroup)
        self.ridgeOverlapSpin.setObjectName(u"ridgeOverlapSpin")
        self.ridgeOverlapSpin.setMinimum(0.200000000000000)
        self.ridgeOverlapSpin.setMaximum(2.000000000000000)
        self.ridgeOverlapSpin.setSingleStep(0.050000000000000)

        self.ridgeOverlapSpinFieldLayout.addWidget(self.ridgeOverlapSpin)


        self.specificForm.setLayout(6, QFormLayout.ItemRole.FieldRole, self.ridgeOverlapSpinFieldLayout)

        self.fillAlphaLabel = QLabel(self.specificGroup)
        self.fillAlphaLabel.setObjectName(u"fillAlphaLabel")

        self.specificForm.setWidget(7, QFormLayout.ItemRole.LabelRole, self.fillAlphaLabel)

        self.fillAlphaSpinFieldLayout = QHBoxLayout()
        self.fillAlphaSpinFieldLayout.setSpacing(0)
        self.fillAlphaSpinFieldLayout.setObjectName(u"fillAlphaSpinFieldLayout")
        self.fillAlphaSpinFieldLayout.setContentsMargins(0, 0, 0, 0)
        self.fillAlphaSpinLeftSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.fillAlphaSpinFieldLayout.addItem(self.fillAlphaSpinLeftSpacer)

        self.fillAlphaSpin = QDoubleSpinBox(self.specificGroup)
        self.fillAlphaSpin.setObjectName(u"fillAlphaSpin")
        self.fillAlphaSpin.setMinimum(0.100000000000000)
        self.fillAlphaSpin.setMaximum(1.000000000000000)
        self.fillAlphaSpin.setSingleStep(0.050000000000000)

        self.fillAlphaSpinFieldLayout.addWidget(self.fillAlphaSpin)


        self.specificForm.setLayout(7, QFormLayout.ItemRole.FieldRole, self.fillAlphaSpinFieldLayout)


        self.controlsLayout.addWidget(self.specificGroup)

        self.controlsSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.controlsLayout.addItem(self.controlsSpacer)

        self.controlsScroll.setWidget(self.controlsContent)

        self.controlsPaneLayout.addWidget(self.controlsScroll)

        self.mainSplitter.addWidget(self.controlsPane)

        self.centralLayout.addWidget(self.mainSplitter)

        self.sheetBar = QFrame(self.centralwidget)
        self.sheetBar.setObjectName(u"sheetBar")
        sizePolicy.setHeightForWidth(self.sheetBar.sizePolicy().hasHeightForWidth())
        self.sheetBar.setSizePolicy(sizePolicy)
        self.sheetBar.setFrameShape(QFrame.Shape.StyledPanel)
        self.sheetBarLayout = QHBoxLayout(self.sheetBar)
        self.sheetBarLayout.setSpacing(4)
        self.sheetBarLayout.setObjectName(u"sheetBarLayout")
        self.sheetBarLayout.setContentsMargins(4, 2, 4, 2)
        self.sheetMenuButton = QToolButton(self.sheetBar)
        self.sheetMenuButton.setObjectName(u"sheetMenuButton")

        self.sheetBarLayout.addWidget(self.sheetMenuButton)

        self.sheetTabBar = QTabBar(self.sheetBar)
        self.sheetTabBar.setObjectName(u"sheetTabBar")
        sizePolicy4.setHeightForWidth(self.sheetTabBar.sizePolicy().hasHeightForWidth())
        self.sheetTabBar.setSizePolicy(sizePolicy4)
        self.sheetTabBar.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.sheetTabBar.setDrawBase(False)
        self.sheetTabBar.setElideMode(Qt.TextElideMode.ElideRight)
        self.sheetTabBar.setExpanding(False)
        self.sheetTabBar.setMovable(True)
        self.sheetTabBar.setUsesScrollButtons(True)

        self.sheetBarLayout.addWidget(self.sheetTabBar)


        self.centralLayout.addWidget(self.sheetBar)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1103, 39))
        self.menuFile = QMenu(self.menubar)
        self.menuFile.setObjectName(u"menuFile")
        self.menuOpenRecent = QMenu(self.menuFile)
        self.menuOpenRecent.setObjectName(u"menuOpenRecent")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
#if QT_CONFIG(shortcut)
        self.customOverlaySecondaryAxisLabel.setBuddy(self.customOverlaySecondaryAxisCheck)
        self.lineOverlayBreakBetweenParentsLabel.setBuddy(self.lineOverlayBreakBetweenParentsCheck)
#endif // QT_CONFIG(shortcut)

        self.menubar.addAction(self.menuFile.menuAction())
        self.menuFile.addAction(self.actionNew)
        self.menuFile.addAction(self.actionOpenProject)
        self.menuFile.addAction(self.menuOpenRecent.menuAction())
        self.menuFile.addAction(self.actionSaveProject)
        self.menuFile.addAction(self.actionSaveProjectAs)
        self.menuFile.addSeparator()
        self.menuFile.addAction(self.actionImportExcel)
        self.menuFile.addAction(self.actionImportPrism)
        self.menuFile.addAction(self.actionExportExcel)
        self.menuFile.addSeparator()
        self.menuFile.addAction(self.actionCopyFigure)
        self.menuFile.addAction(self.actionExportFigure)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"EasyGraph v2.0", None))
        self.actionNew.setText(QCoreApplication.translate("MainWindow", u"New", None))
        self.actionOpenProject.setText(QCoreApplication.translate("MainWindow", u"Open Project", None))
        self.actionSaveProject.setText(QCoreApplication.translate("MainWindow", u"Save Project", None))
        self.actionSaveProjectAs.setText(QCoreApplication.translate("MainWindow", u"Save Project As", None))
        self.actionImportExcel.setText(QCoreApplication.translate("MainWindow", u"Import Excel", None))
        self.actionImportPrism.setText(QCoreApplication.translate("MainWindow", u"Import Prism PZFX...", None))
        self.actionExportExcel.setText(QCoreApplication.translate("MainWindow", u"Export Excel", None))
        self.actionCopyFigure.setText(QCoreApplication.translate("MainWindow", u"Copy as Image", None))
        self.actionExportFigure.setText(QCoreApplication.translate("MainWindow", u"Export Figure", None))
        self.copyToolbarLabel.setText(QCoreApplication.translate("MainWindow", u"Common", None))
        self.copyImageButton.setText(QCoreApplication.translate("MainWindow", u"Copy as Image", None))
        self.copyStatisticsButton.setText(QCoreApplication.translate("MainWindow", u"Copy Statistics Table", None))
        self.groupFilterButton.setText(QCoreApplication.translate("MainWindow", u"Group Filter", None))
        self.fontToolbarLabel.setText(QCoreApplication.translate("MainWindow", u"Font", None))
        self.increaseAllFontsButton.setText(QCoreApplication.translate("MainWindow", u"Increase All Font Sizes", None))
        self.decreaseAllFontsButton.setText(QCoreApplication.translate("MainWindow", u"Decrease All Font Sizes", None))
        self.toolbarTitleSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Title", None))
        self.toolbarAxisSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Axis", None))
        self.toolbarTickSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Tick", None))
        self.toolbarLegendSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Legend", None))
        self.lineValueSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Data label", None))
        self.additionalGuideFontSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Additional labels", None))
        self.statTableSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Stats table", None))
        self.chartToolbarLabel.setText(QCoreApplication.translate("MainWindow", u"Chart Basics", None))
        self.toolbarChartTypeLabel.setText(QCoreApplication.translate("MainWindow", u"Type", None))
        self.toolbarPaletteLabel.setText(QCoreApplication.translate("MainWindow", u"Palette", None))
        self.editGroupColorsButton.setText(QCoreApplication.translate("MainWindow", u"Colors", None))
        self.toolbarOrderLabel.setText(QCoreApplication.translate("MainWindow", u"Order", None))
        self.editGroupOrderButton.setText(QCoreApplication.translate("MainWindow", u"Edit", None))
        self.templateToolbarLabel.setText(QCoreApplication.translate("MainWindow", u"Style Templates", None))
        self.toolbarTemplateIconLabel.setText(QCoreApplication.translate("MainWindow", u"Style Templates", None))
        self.loadTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Load...", None))
        self.saveTemplateButton.setText(QCoreApplication.translate("MainWindow", u"Save Current", None))
        self.canvasToolbarLabel.setText(QCoreApplication.translate("MainWindow", u"Export & Canvas", None))
        self.toolbarWidthLabel.setText(QCoreApplication.translate("MainWindow", u"W", None))
        self.toolbarHeightLabel.setText(QCoreApplication.translate("MainWindow", u"H", None))
        self.toolbarDpiLabel.setText(QCoreApplication.translate("MainWindow", u"DPI", None))
        self.toolbarTransparentLabel.setText(QCoreApplication.translate("MainWindow", u"Transparent", None))
        self.topToolsTabs.setTabText(self.topToolsTabs.indexOf(self.chartToolsPage), QCoreApplication.translate("MainWindow", u"Chart", None))
        self.tableEditLabel.setText(QCoreApplication.translate("MainWindow", u"Edit", None))
        self.tableCopyButton.setText(QCoreApplication.translate("MainWindow", u"Copy", None))
        self.tableCutButton.setText(QCoreApplication.translate("MainWindow", u"Cut", None))
        self.tablePasteButton.setText(QCoreApplication.translate("MainWindow", u"Paste", None))
        self.tableClearButton.setText(QCoreApplication.translate("MainWindow", u"Clear Contents", None))
        self.tableUndoButton.setText(QCoreApplication.translate("MainWindow", u"Undo", None))
        self.tableRedoButton.setText(QCoreApplication.translate("MainWindow", u"Redo", None))
        self.tableEditHintLabel.setText(QCoreApplication.translate("MainWindow", u"Changes can be undone.", None))
        self.tableRowsColumnsLabel.setText(QCoreApplication.translate("MainWindow", u"Rows and columns", None))
        self.tableInsertRowAboveButton.setText(QCoreApplication.translate("MainWindow", u"Insert row above", None))
        self.tableInsertRowBelowButton.setText(QCoreApplication.translate("MainWindow", u"Insert row below", None))
        self.tableInsertColumnLeftButton.setText(QCoreApplication.translate("MainWindow", u"Insert column left", None))
        self.tableInsertColumnRightButton.setText(QCoreApplication.translate("MainWindow", u"Insert column right", None))
        self.tableDeleteRowsButton.setText(QCoreApplication.translate("MainWindow", u"Delete rows", None))
        self.tableDeleteColumnsButton.setText(QCoreApplication.translate("MainWindow", u"Delete columns", None))
        self.tableParentHeadersLabel.setText(QCoreApplication.translate("MainWindow", u"Parent headers", None))
        self.tableMergeParentButton.setText(QCoreApplication.translate("MainWindow", u"Merge parent headers\u2026", None))
        self.tableUnmergeParentButton.setText(QCoreApplication.translate("MainWindow", u"Unmerge parent headers", None))
        self.tableRenameParentButton.setText(QCoreApplication.translate("MainWindow", u"Rename parent header\u2026", None))
        self.tableInsertParentLeftButton.setText(QCoreApplication.translate("MainWindow", u"Insert parent group left", None))
        self.tableInsertParentRightButton.setText(QCoreApplication.translate("MainWindow", u"Insert parent group right", None))
        self.tableBatchParentsButton.setText(QCoreApplication.translate("MainWindow", u"Create parent groups\u2026", None))
        self.tableSelectionSummary.setText(QCoreApplication.translate("MainWindow", u"Select parent headers or columns", None))
        self.topToolsTabs.setTabText(self.topToolsTabs.indexOf(self.tableToolsPage), QCoreApplication.translate("MainWindow", u"Table", None))
        self.addOverlayButton.setText(QCoreApplication.translate("MainWindow", u"+ Overlay", None))
        self.removeOverlayButton.setText(QCoreApplication.translate("MainWindow", u"- Overlay", None))
#if QT_CONFIG(tooltip)
        self.curveFitButton.setToolTip(QCoreApplication.translate("MainWindow", u"Fit built-in or custom equations to the selected XY series", None))
#endif // QT_CONFIG(tooltip)
        self.curveFitButton.setText(QCoreApplication.translate("MainWindow", u"Curve Fit...", None))
        self.xySharedTitleLabel.setText(QCoreApplication.translate("MainWindow", u"Shared X", None))
#if QT_CONFIG(tooltip)
        self.addXYSharedTableButton.setToolTip(QCoreApplication.translate("MainWindow", u"Add shared X tab", None))
#endif // QT_CONFIG(tooltip)
        self.addXYSharedTableButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
#if QT_CONFIG(tooltip)
        self.removeXYSharedTableButton.setToolTip(QCoreApplication.translate("MainWindow", u"Delete current shared X tab", None))
#endif // QT_CONFIG(tooltip)
        self.removeXYSharedTableButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.xyIndependentTitleLabel.setText(QCoreApplication.translate("MainWindow", u"Independent XY", None))
        self.resultsTitleLabel.setText(QCoreApplication.translate("MainWindow", u"Analysis Results \u00b7 Descriptive statistics", None))
        self.analysisNumberFormatsButton.setText(QCoreApplication.translate("MainWindow", u"Number Formats...", None))
        self.inspectorContextLabel.setText(QCoreApplication.translate("MainWindow", u"Editing: All settings", None))
        self.inspectorShowAllButton.setText(QCoreApplication.translate("MainWindow", u"Show All", None))
        self.titleAxisGroup.setTitle(QCoreApplication.translate("MainWindow", u"Title", None))
        self.titleLabel.setText(QCoreApplication.translate("MainWindow", u"Chart title", None))
        self.titleEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter to line break", None))
        self.xLabelLabel.setText(QCoreApplication.translate("MainWindow", u"Category axis title", None))
        self.xLabelEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter to line break", None))
        self.yLabelLabel.setText(QCoreApplication.translate("MainWindow", u"Primary value axis title", None))
        self.yLabelEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter to line break", None))
        self.secondaryYLabelLabel.setText(QCoreApplication.translate("MainWindow", u"Secondary value axis title", None))
        self.secondaryYLabelEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter to line break", None))
        self.categoryAxisGroup.setTitle(QCoreApplication.translate("MainWindow", u"X Axis", None))
        self.autoXRangeLabel.setText(QCoreApplication.translate("MainWindow", u"Auto range", None))
        self.xMinLabel.setText(QCoreApplication.translate("MainWindow", u"Minimum", None))
        self.xMaxLabel.setText(QCoreApplication.translate("MainWindow", u"Maximum", None))
        self.xAutoTickIntervalLabel.setText(QCoreApplication.translate("MainWindow", u"Auto tick interval", None))
        self.xTickIntervalLabel.setText(QCoreApplication.translate("MainWindow", u"Tick interval", None))
        self.xRotationLabel.setText(QCoreApplication.translate("MainWindow", u"Label rotation", None))
        self.parentGroupSpacingLabel.setText(QCoreApplication.translate("MainWindow", u"Parent group spacing", None))
        self.groupLayoutButton.setText(QCoreApplication.translate("MainWindow", u"Group layout...", None))
        self.primaryAxisGroup.setTitle(QCoreApplication.translate("MainWindow", u"Primary Y Axis", None))
        self.autoYLabel.setText(QCoreApplication.translate("MainWindow", u"Auto range", None))
        self.yMinLabel.setText(QCoreApplication.translate("MainWindow", u"Minimum", None))
        self.yMaxLabel.setText(QCoreApplication.translate("MainWindow", u"Maximum", None))
        self.primaryAutoTickIntervalLabel.setText(QCoreApplication.translate("MainWindow", u"Auto tick interval", None))
        self.primaryTickIntervalLabel.setText(QCoreApplication.translate("MainWindow", u"Tick interval", None))
        self.additionalGuidesGroup.setTitle(QCoreApplication.translate("MainWindow", u"Additional ticks and grid lines", None))
        self.additionalGuidesAxisLabel.setText(QCoreApplication.translate("MainWindow", u"Selected axis", None))
        self.additionalGuidesXAxisRadio.setText(QCoreApplication.translate("MainWindow", u"X axis", None))
        self.additionalGuidesYAxisRadio.setText(QCoreApplication.translate("MainWindow", u"Y axis", None))
        self.additionalGuideLineWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Line width", None))
        ___qtablewidgetitem = self.additionalGuidesTable.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"Position", None))
        ___qtablewidgetitem1 = self.additionalGuidesTable.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Tick", None))
        ___qtablewidgetitem2 = self.additionalGuidesTable.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Line", None))
        ___qtablewidgetitem3 = self.additionalGuidesTable.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"Color", None))
        ___qtablewidgetitem4 = self.additionalGuidesTable.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"Text", None))
        self.additionalGuideAddButton.setText(QCoreApplication.translate("MainWindow", u"Add", None))
        self.additionalGuideDeleteButton.setText(QCoreApplication.translate("MainWindow", u"Delete", None))
        self.additionalGuideValueLabel.setText(QCoreApplication.translate("MainWindow", u"Position", None))
        self.additionalGuideTickLabel.setText(QCoreApplication.translate("MainWindow", u"Tick", None))
        self.additionalGuideShowValueLabel.setText(QCoreApplication.translate("MainWindow", u"Value with text", None))
        self.additionalGuideLineLabel.setText(QCoreApplication.translate("MainWindow", u"Grid line", None))
        self.additionalGuideColorLabel.setText(QCoreApplication.translate("MainWindow", u"Line color", None))
        self.additionalGuideTextColorLabel.setText(QCoreApplication.translate("MainWindow", u"Text color", None))
        self.additionalGuideTextLabel.setText(QCoreApplication.translate("MainWindow", u"Text", None))
        self.additionalGuideTextEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Up to two lines", None))
        self.additionalGuideTextSideLabel.setText(QCoreApplication.translate("MainWindow", u"Text side", None))
        self.additionalGuideTextSideCombo.setItemText(0, QCoreApplication.translate("MainWindow", u"Left", None))
        self.additionalGuideTextSideCombo.setItemText(1, QCoreApplication.translate("MainWindow", u"Center", None))
        self.additionalGuideTextSideCombo.setItemText(2, QCoreApplication.translate("MainWindow", u"Right", None))

        self.additionalGuideTextVerticalLabel.setText(QCoreApplication.translate("MainWindow", u"Text height", None))
        self.additionalGuideTextVerticalCombo.setItemText(0, QCoreApplication.translate("MainWindow", u"Center", None))
        self.additionalGuideTextVerticalCombo.setItemText(1, QCoreApplication.translate("MainWindow", u"Below", None))
        self.additionalGuideTextVerticalCombo.setItemText(2, QCoreApplication.translate("MainWindow", u"Above", None))

        self.additionalGuideLabelBackgroundLabel.setText(QCoreApplication.translate("MainWindow", u"Label background", None))
        self.axesAppearanceGroup.setTitle(QCoreApplication.translate("MainWindow", u"Axes Appearance", None))
        self.showGridLabel.setText(QCoreApplication.translate("MainWindow", u"Show grid", None))
        self.axisLineWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Line width", None))
        self.secondaryAxisGroup.setTitle(QCoreApplication.translate("MainWindow", u"Secondary Y Axis", None))
        self.secondaryAutoYLabel.setText(QCoreApplication.translate("MainWindow", u"Auto range", None))
        self.secondaryYMinLabel.setText(QCoreApplication.translate("MainWindow", u"Minimum", None))
        self.secondaryYMaxLabel.setText(QCoreApplication.translate("MainWindow", u"Maximum", None))
        self.secondaryAutoTickIntervalLabel.setText(QCoreApplication.translate("MainWindow", u"Auto tick interval", None))
        self.secondaryTickIntervalLabel.setText(QCoreApplication.translate("MainWindow", u"Tick interval", None))
        self.splitSecondaryAxisLabel.setText(QCoreApplication.translate("MainWindow", u"Split secondary frame", None))
        self.secondaryAxisSplitRatioLabel.setText(QCoreApplication.translate("MainWindow", u"Secondary frame ratio", None))
        self.pointsGroup.setTitle(QCoreApplication.translate("MainWindow", u"Data Points", None))
        self.xySeriesSelectionCountLabel.setText(QCoreApplication.translate("MainWindow", u"Selected 0/0", None))
#if QT_CONFIG(tooltip)
        self.xySeriesSelectAllButton.setToolTip(QCoreApplication.translate("MainWindow", u"Edit every series through the all-series style", None))
#endif // QT_CONFIG(tooltip)
        self.xySeriesSelectAllButton.setText(QCoreApplication.translate("MainWindow", u"All series", None))
#if QT_CONFIG(tooltip)
        self.xySeriesClearSelectionButton.setToolTip(QCoreApplication.translate("MainWindow", u"Clear the editable series selection", None))
#endif // QT_CONFIG(tooltip)
        self.xySeriesClearSelectionButton.setText(QCoreApplication.translate("MainWindow", u"Clear", None))
#if QT_CONFIG(tooltip)
        self.xySeriesInvertSelectionButton.setToolTip(QCoreApplication.translate("MainWindow", u"Invert the editable series selection", None))
#endif // QT_CONFIG(tooltip)
        self.xySeriesInvertSelectionButton.setText(QCoreApplication.translate("MainWindow", u"Invert", None))
        self.xyNoSeriesSelectedLabel.setText(QCoreApplication.translate("MainWindow", u"No series selected", None))
        self.showPointsLabel.setText(QCoreApplication.translate("MainWindow", u"Show all points", None))
        self.pointSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Size", None))
        self.pointAlphaLabel.setText(QCoreApplication.translate("MainWindow", u"Opacity", None))
        self.xyMarkerLabel.setText(QCoreApplication.translate("MainWindow", u"Marker", None))
        self.jitterModeLabel.setText(QCoreApplication.translate("MainWindow", u"Jitter mode", None))
        self.jitterLabel.setText(QCoreApplication.translate("MainWindow", u"Jitter amount", None))
        self.xyShowLineLabel.setText(QCoreApplication.translate("MainWindow", u"Connect data points", None))
        self.xyLineWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Line width", None))
        self.xyLineStyleLabel.setText(QCoreApplication.translate("MainWindow", u"Line style", None))
        self.useAllSeriesStyleButton.setText(QCoreApplication.translate("MainWindow", u"Use all-series style", None))
#if QT_CONFIG(tooltip)
        self.useAllSeriesStyleButton.setToolTip(QCoreApplication.translate("MainWindow", u"Clear the selected series' overrides and follow the all-series style", None))
#endif // QT_CONFIG(tooltip)
        self.outliersGroup.setTitle(QCoreApplication.translate("MainWindow", u"Outliers", None))
        self.highlightLabel.setText(QCoreApplication.translate("MainWindow", u"Highlight outliers", None))
        self.outlierMethodLabel.setText(QCoreApplication.translate("MainWindow", u"Method", None))
        self.thresholdLabel.setText(QCoreApplication.translate("MainWindow", u"Threshold", None))
        self.effectLabel.setText(QCoreApplication.translate("MainWindow", u"Effect", None))
        self.lineOverlayGroup.setTitle(QCoreApplication.translate("MainWindow", u"Line Overlay", None))
        self.showLineOverlayLabel.setText(QCoreApplication.translate("MainWindow", u"Show line", None))
        self.lineOverlayStatLabel.setText(QCoreApplication.translate("MainWindow", u"Trend overlay", None))
        self.extraCustomOverlayLabel.setText(QCoreApplication.translate("MainWindow", u"Extra custom overlay", None))
        self.customOverlayCountLabel.setText(QCoreApplication.translate("MainWindow", u"Custom line count", None))
        self.customOverlayFilterButton.setText(QCoreApplication.translate("MainWindow", u"Filter", None))
        self.customOverlaySecondaryAxisLabel.setText(QCoreApplication.translate("MainWindow", u"Use secondary axis", None))
#if QT_CONFIG(tooltip)
        self.customOverlaySecondaryAxisLabel.setToolTip(QCoreApplication.translate("MainWindow", u"Show custom overlay values on a secondary axis", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.customOverlaySecondaryAxisCheck.setToolTip(QCoreApplication.translate("MainWindow", u"Show custom overlay values on a secondary axis", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(accessibility)
        self.customOverlaySecondaryAxisCheck.setAccessibleName(QCoreApplication.translate("MainWindow", u"Use secondary axis", None))
#endif // QT_CONFIG(accessibility)
        self.lineOverlayWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Line width", None))
        self.lineOverlayStyleLabel.setText(QCoreApplication.translate("MainWindow", u"Line style", None))
        self.lineOverlayBreakBetweenParentsLabel.setText(QCoreApplication.translate("MainWindow", u"Break between parent groups", None))
#if QT_CONFIG(tooltip)
        self.lineOverlayBreakBetweenParentsLabel.setToolTip(QCoreApplication.translate("MainWindow", u"Draw separate overlay segments within each parent group. Ungrouped columns keep points only. Available when the table has parent groups.", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.lineOverlayBreakBetweenParentsCheck.setToolTip(QCoreApplication.translate("MainWindow", u"Draw separate overlay segments within each parent group. Ungrouped columns keep points only. Available when the table has parent groups.", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(accessibility)
        self.lineOverlayBreakBetweenParentsCheck.setAccessibleName(QCoreApplication.translate("MainWindow", u"Break between parent groups", None))
#endif // QT_CONFIG(accessibility)
        self.editOverlayStylesLabel.setText(QCoreApplication.translate("MainWindow", u"Custom line styles", None))
        self.editOverlayStylesButton.setText(QCoreApplication.translate("MainWindow", u"Custom styles", None))
        self.lineOverlayPointSizeLabel.setText(QCoreApplication.translate("MainWindow", u"Point size", None))
        self.showLineValuesLabel.setText(QCoreApplication.translate("MainWindow", u"Show values", None))
        self.lineValuePositionLabel.setText(QCoreApplication.translate("MainWindow", u"Label position", None))
        self.customLineValuePositionLabel.setText(QCoreApplication.translate("MainWindow", u"Extra label position", None))
        self.lineValueScientificLabel.setText(QCoreApplication.translate("MainWindow", u"Scientific", None))
        self.lineValueDecimalsLabel.setText(QCoreApplication.translate("MainWindow", u"Decimals", None))
        self.labelNumberFormatsButton.setText(QCoreApplication.translate("MainWindow", u"Statistic Number Formats...", None))
        self.statsTableGroup.setTitle(QCoreApplication.translate("MainWindow", u"Stats Table", None))
        self.showStatTableCheck.setText(QCoreApplication.translate("MainWindow", u"Show statistics table", None))
        self.showStatHeaderCheck.setText(QCoreApplication.translate("MainWindow", u"Show header", None))
        self.statisticNumberFormatsButton.setText(QCoreApplication.translate("MainWindow", u"Statistic Number Formats...", None))
        self.legendGroup.setTitle(QCoreApplication.translate("MainWindow", u"Legend", None))
        self.showLegendLabel.setText(QCoreApplication.translate("MainWindow", u"Show legend", None))
        self.legendPositionLabel.setText(QCoreApplication.translate("MainWindow", u"Position", None))
        self.legendAutoWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Auto width", None))
        self.legendWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Width (cm)", None))
        self.legendColumnsLabel.setText(QCoreApplication.translate("MainWindow", u"Columns", None))
        self.specificGroup.setTitle(QCoreApplication.translate("MainWindow", u"Type-specific", None))
        self.barWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Bar width", None))
        self.barSummaryLabel.setText(QCoreApplication.translate("MainWindow", u"Bar height / error", None))
        self.boxWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Box width", None))
        self.boxWhiskerLabel.setText(QCoreApplication.translate("MainWindow", u"Box whisker mode", None))
        self.violinWidthLabel.setText(QCoreApplication.translate("MainWindow", u"Violin width", None))
        self.kdeBandwidthLabel.setText(QCoreApplication.translate("MainWindow", u"KDE bandwidth", None))
        self.ridgeOverlapLabel.setText(QCoreApplication.translate("MainWindow", u"Ridge overlap", None))
        self.fillAlphaLabel.setText(QCoreApplication.translate("MainWindow", u"Fill alpha", None))
#if QT_CONFIG(tooltip)
        self.sheetMenuButton.setToolTip(QCoreApplication.translate("MainWindow", u"Sheet menu", None))
#endif // QT_CONFIG(tooltip)
        self.sheetMenuButton.setText(QCoreApplication.translate("MainWindow", u"\u2630", None))
        self.menuFile.setTitle(QCoreApplication.translate("MainWindow", u"File", None))
        self.menuOpenRecent.setTitle(QCoreApplication.translate("MainWindow", u"Open Recent", None))
    # retranslateUi
