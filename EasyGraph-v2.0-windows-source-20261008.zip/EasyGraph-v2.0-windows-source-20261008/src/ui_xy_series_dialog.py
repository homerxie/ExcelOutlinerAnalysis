# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'xy_series_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QComboBox,
    QDialog, QDialogButtonBox, QHBoxLayout, QHeaderView,
    QLabel, QPushButton, QSizePolicy, QSpacerItem,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

class Ui_XYSeriesDialog(object):
    def setupUi(self, XYSeriesDialog):
        if not XYSeriesDialog.objectName():
            XYSeriesDialog.setObjectName(u"XYSeriesDialog")
        XYSeriesDialog.setModal(True)
        XYSeriesDialog.setMinimumSize(QSize(900, 480))
        self.verticalLayout = QVBoxLayout(XYSeriesDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.hintLabel = QLabel(XYSeriesDialog)
        self.hintLabel.setObjectName(u"hintLabel")
        self.hintLabel.setWordWrap(True)

        self.verticalLayout.addWidget(self.hintLabel)

        self.mappingLayout = QHBoxLayout()
        self.mappingLayout.setObjectName(u"mappingLayout")
        self.defaultXLabel = QLabel(XYSeriesDialog)
        self.defaultXLabel.setObjectName(u"defaultXLabel")

        self.mappingLayout.addWidget(self.defaultXLabel)

        self.defaultXCombo = QComboBox(XYSeriesDialog)
        self.defaultXCombo.setObjectName(u"defaultXCombo")

        self.mappingLayout.addWidget(self.defaultXCombo)

        self.sharedXButton = QPushButton(XYSeriesDialog)
        self.sharedXButton.setObjectName(u"sharedXButton")

        self.mappingLayout.addWidget(self.sharedXButton)

        self.adjacentXYButton = QPushButton(XYSeriesDialog)
        self.adjacentXYButton.setObjectName(u"adjacentXYButton")

        self.mappingLayout.addWidget(self.adjacentXYButton)

        self.mappingSpacer = QSpacerItem(24, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.mappingLayout.addItem(self.mappingSpacer)

        self.mappingStatusLabel = QLabel(XYSeriesDialog)
        self.mappingStatusLabel.setObjectName(u"mappingStatusLabel")

        self.mappingLayout.addWidget(self.mappingStatusLabel)


        self.verticalLayout.addLayout(self.mappingLayout)

        self.seriesTable = QTableWidget(XYSeriesDialog)
        if (self.seriesTable.columnCount() < 7):
            self.seriesTable.setColumnCount(7)
        __qtablewidgetitem = QTableWidgetItem()
        self.seriesTable.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.seriesTable.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.seriesTable.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.seriesTable.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.seriesTable.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.seriesTable.setHorizontalHeaderItem(5, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.seriesTable.setHorizontalHeaderItem(6, __qtablewidgetitem6)
        self.seriesTable.setObjectName(u"seriesTable")
        self.seriesTable.setAlternatingRowColors(True)
        self.seriesTable.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.seriesTable.setSelectionMode(QAbstractItemView.SingleSelection)
        self.seriesTable.setColumnCount(7)

        self.verticalLayout.addWidget(self.seriesTable)

        self.seriesButtonsLayout = QHBoxLayout()
        self.seriesButtonsLayout.setObjectName(u"seriesButtonsLayout")
        self.addSeriesButton = QPushButton(XYSeriesDialog)
        self.addSeriesButton.setObjectName(u"addSeriesButton")

        self.seriesButtonsLayout.addWidget(self.addSeriesButton)

        self.removeSeriesButton = QPushButton(XYSeriesDialog)
        self.removeSeriesButton.setObjectName(u"removeSeriesButton")

        self.seriesButtonsLayout.addWidget(self.removeSeriesButton)

        self.moveUpButton = QPushButton(XYSeriesDialog)
        self.moveUpButton.setObjectName(u"moveUpButton")

        self.seriesButtonsLayout.addWidget(self.moveUpButton)

        self.moveDownButton = QPushButton(XYSeriesDialog)
        self.moveDownButton.setObjectName(u"moveDownButton")

        self.seriesButtonsLayout.addWidget(self.moveDownButton)

        self.buttonSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.seriesButtonsLayout.addItem(self.buttonSpacer)

        self.buttonBox = QDialogButtonBox(XYSeriesDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.seriesButtonsLayout.addWidget(self.buttonBox)


        self.verticalLayout.addLayout(self.seriesButtonsLayout)


        self.retranslateUi(XYSeriesDialog)
        self.buttonBox.accepted.connect(XYSeriesDialog.accept)
        self.buttonBox.rejected.connect(XYSeriesDialog.reject)

        QMetaObject.connectSlotsByName(XYSeriesDialog)
    # setupUi

    def retranslateUi(self, XYSeriesDialog):
        XYSeriesDialog.setWindowTitle(QCoreApplication.translate("XYSeriesDialog", u"Series Setup", None))
        self.hintLabel.setText(QCoreApplication.translate("XYSeriesDialog", u"Set a default X, then override X or display options only for series that need it.", None))
        self.defaultXLabel.setText(QCoreApplication.translate("XYSeriesDialog", u"Default X", None))
        self.sharedXButton.setText(QCoreApplication.translate("XYSeriesDialog", u"Use Shared X", None))
        self.adjacentXYButton.setText(QCoreApplication.translate("XYSeriesDialog", u"Use Adjacent XY Pairs", None))
        self.mappingStatusLabel.setText(QCoreApplication.translate("XYSeriesDialog", u"No series", None))
        ___qtablewidgetitem = self.seriesTable.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("XYSeriesDialog", u"Visible", None))
        ___qtablewidgetitem1 = self.seriesTable.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("XYSeriesDialog", u"Name", None))
        ___qtablewidgetitem2 = self.seriesTable.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("XYSeriesDialog", u"X", None))
        ___qtablewidgetitem3 = self.seriesTable.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("XYSeriesDialog", u"Y", None))
        ___qtablewidgetitem4 = self.seriesTable.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("XYSeriesDialog", u"Valid rows", None))
        ___qtablewidgetitem5 = self.seriesTable.horizontalHeaderItem(5)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("XYSeriesDialog", u"Points", None))
        ___qtablewidgetitem6 = self.seriesTable.horizontalHeaderItem(6)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("XYSeriesDialog", u"Line", None))
        self.addSeriesButton.setText(QCoreApplication.translate("XYSeriesDialog", u"+ Series", None))
        self.removeSeriesButton.setText(QCoreApplication.translate("XYSeriesDialog", u"Remove", None))
        self.moveUpButton.setText(QCoreApplication.translate("XYSeriesDialog", u"Move Up", None))
        self.moveDownButton.setText(QCoreApplication.translate("XYSeriesDialog", u"Move Down", None))
    # retranslateUi

