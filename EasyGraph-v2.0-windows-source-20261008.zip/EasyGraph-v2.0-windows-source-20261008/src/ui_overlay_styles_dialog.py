# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'overlay_styles_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QScrollArea, QSizePolicy, QVBoxLayout, QWidget)

class Ui_OverlayStylesDialog(object):
    def setupUi(self, OverlayStylesDialog):
        if not OverlayStylesDialog.objectName():
            OverlayStylesDialog.setObjectName(u"OverlayStylesDialog")
        OverlayStylesDialog.setModal(True)
        self.verticalLayout = QVBoxLayout(OverlayStylesDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.rowsScroll = QScrollArea(OverlayStylesDialog)
        self.rowsScroll.setObjectName(u"rowsScroll")
        self.rowsScroll.setMinimumSize(QSize(360, 160))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.rowsScroll.sizePolicy().hasHeightForWidth())
        self.rowsScroll.setSizePolicy(sizePolicy)
        self.rowsScroll.setWidgetResizable(True)
        self.rowsContainer = QWidget()
        self.rowsContainer.setObjectName(u"rowsContainer")
        self.rowsContainer.setGeometry(QRect(0, 0, 358, 158))
        self.rowsLayout = QVBoxLayout(self.rowsContainer)
        self.rowsLayout.setSpacing(6)
        self.rowsLayout.setObjectName(u"rowsLayout")
        self.rowsLayout.setContentsMargins(0, 0, 0, 0)
        self.rowsScroll.setWidget(self.rowsContainer)

        self.verticalLayout.addWidget(self.rowsScroll)

        self.buttonBox = QDialogButtonBox(OverlayStylesDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(OverlayStylesDialog)
        self.buttonBox.accepted.connect(OverlayStylesDialog.accept)
        self.buttonBox.rejected.connect(OverlayStylesDialog.reject)

        QMetaObject.connectSlotsByName(OverlayStylesDialog)
    # setupUi

    def retranslateUi(self, OverlayStylesDialog):
        OverlayStylesDialog.setWindowTitle(QCoreApplication.translate("OverlayStylesDialog", u"Custom Overlay Line Styles", None))
    # retranslateUi

