from __future__ import annotations

from PySide6.QtCore import QTimer

from easygraph.app_icon import configure_application_icon, configure_platform_identity
from easygraph.app_preferences import install_app_translator
from easygraph.app_theme import apply_app_theme
from easygraph.file_association import (
    EasyGraphApplication,
    project_path_from_arguments,
    register_windows_project_file_association,
)
from easygraph.ui.main_window import MainWindow


def main() -> None:
    import os
    import sys

    configure_platform_identity()
    app = EasyGraphApplication(sys.argv)
    configure_application_icon(app)
    install_app_translator(app)
    apply_app_theme(app)
    smoke_output = os.environ.get("EASYGRAPH_PACKAGING_SMOKE_DIR")
    if smoke_output:
        from easygraph.packaging_smoke import run_packaging_smoke

        run_packaging_smoke(smoke_output, app)
        return
    register_windows_project_file_association()
    startup_project = project_path_from_arguments(sys.argv[1:])
    window = MainWindow(
        initial_render=False,
        defer_preview=True,
        recovery_enabled=True,
    )
    startup_file_requested = False

    def open_associated_project(path) -> None:
        if window.isMinimized():
            window.showNormal()
        window.raise_()
        window.activateWindow()
        window.open_project_path(path)

    def queue_associated_project(path) -> None:
        nonlocal startup_file_requested
        startup_file_requested = True
        QTimer.singleShot(
            0,
            lambda project_path=path: open_associated_project(project_path),
        )

    app.set_project_file_handler(queue_associated_project)
    if startup_project is not None:
        app.request_project_file(startup_project)
    if (
        startup_project is None
        and not startup_file_requested
        and not window.recovered_on_startup
    ):
        from easygraph.ui.startup_dialog import choose_startup

        while True:
            choice = choose_startup(window)
            if choice is None:
                window.close()
                return
            if choice.project_path is not None:
                if window.open_project_path(choice.project_path):
                    break
                continue
            window.initialize_startup_project(
                choice.mode,
                demo=choice.demo,
                grouped_demo=choice.grouped_demo,
            )
            break

    window.show()

    def activate_then_initialize_preview() -> None:
        window.raise_()
        window.activateWindow()
        QTimer.singleShot(
            100,
            lambda: window.initialize_preview(initial_render=True),
        )

    QTimer.singleShot(0, activate_then_initialize_preview)
    app.exec()


if __name__ == "__main__":
    main()
