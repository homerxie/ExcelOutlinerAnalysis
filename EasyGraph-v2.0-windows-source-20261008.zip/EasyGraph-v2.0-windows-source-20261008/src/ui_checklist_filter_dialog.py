# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'checklist_filter_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QListWidget, QListWidgetItem, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_ChecklistFilterDialog(object):
    def setupUi(self, ChecklistFilterDialog):
        if not ChecklistFilterDialog.objectName():
            ChecklistFilterDialog.setObjectName(u"ChecklistFilterDialog")
        ChecklistFilterDialog.setModal(True)
        self.verticalLayout = QVBoxLayout(ChecklistFilterDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.itemList = QListWidget(ChecklistFilterDialog)
        self.itemList.setObjectName(u"itemList")

        self.verticalLayout.addWidget(self.itemList)

        self.buttonBox = QDialogButtonBox(ChecklistFilterDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(ChecklistFilterDialog)
        self.buttonBox.accepted.connect(ChecklistFilterDialog.accept)
        self.buttonBox.rejected.connect(ChecklistFilterDialog.reject)

        QMetaObject.connectSlotsByName(ChecklistFilterDialog)
    # setupUi

    def retranslateUi(self, ChecklistFilterDialog):
        ChecklistFilterDialog.setWindowTitle(QCoreApplication.translate("ChecklistFilterDialog", u"Filter", None))
    # retranslateUi

