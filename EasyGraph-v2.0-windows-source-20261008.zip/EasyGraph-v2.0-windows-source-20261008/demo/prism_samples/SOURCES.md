# Prism 本地兼容性样例

这些文件从本机安装的 GraphPad Prism 11.0.2 应用包复制，仅用于 EasyGraph 的本地解析验证。二进制/数据文件由本目录的 `.gitignore` 排除，不随 EasyGraph 提交或再分发。

## Prism 8 PZFX

- 本地文件：`prism8-logistic-regression-studying.pzfx`
- 原始位置：`/Applications/Prism 11.app/Contents/SharedSupport/SampleData/XY/Logistic Regression (Studying).pzfx`
- XML 根元素：`GraphPadPrismFile`
- `PrismXMLVersion`：`5.00`
- `OriginalVersion`：GraphPad Prism `8.3.0.510`
- `MostRecentVersion`：GraphPad Prism `8.2.1.279`
- 表型：`TableType="XY"`
- 大小：49,733 bytes
- SHA-256：`55df2729e35c08292cac54b5bfde420cb8b604529333741136d1dbec9927dd22`
- `xmllint --noout`：通过

用途：验证 Prism 8 PZFX 文件识别、版本读取、XML 命名空间兼容、XY 表枚举，以及第一版对 XY 显示明确“不支持映射”的行为。

## Prism 10 PZFX

- 本地文件：`prism10-logistic-titanic.pzfx`
- 原始位置：`/Applications/Prism 11.app/Contents/SharedSupport/SampleData/MultipleVariables/Logistic (Titanic).pzfx`
- XML 根元素：`GraphPadPrismFile`
- `PrismXMLVersion`：`5.00`
- `OriginalVersion`：GraphPad Prism `10.3.0.495`
- 表型：`TableType="OneWay"`、`ExtTableType="MultipleVariables"`
- 大小：329,235 bytes
- SHA-256：`6dd7c3657e987498d0557100c0d0ea2e256021ee431a47e2ea3597423691e041`
- `xmllint --noout`：通过

用途：验证 Prism 10 兼容模式保存的真实 PZFX、带默认 XML 命名空间的解析、Multiple Variables 表枚举，以及第一版对该表型显示明确“不支持映射”的行为。

## 用户生成的 Column/Grouped PZFX

以下文件由用户在本机对应 Prism 版本中保存，用于验证 EasyGraph 的目标表型。它们仅保留在本地并受 `.gitignore` 排除；没有明确再分发许可前不得提交。

| 文件 | `CreatedByVersion` | 表型 | 大小 | SHA-256 |
| --- | --- | --- | ---: | --- |
| `prism8Columns.pzfx` | 8.2.1.441 | `OneWay` | 5,327 | `d95d36d39fbb7463b5f24d136a6ce70c173c817ec5ffa03cc1738532640f487f` |
| `prism8Groups.pzfx` | 8.2.1.441 | `TwoWay`、`YFormat="replicates"` | 5,698 | `1d325adfde497cdef647143765cc209e9a42022c225d323f33f39a808938b5c1` |
| `prism8ColumnsTo9.pzfx` | `MostRecentVersion` 9.5.1.528（`OriginalVersion` 为空） | `OneWay` | 6,859 | `24b6d5d876900c2bf996b005116192ceeefc4b7ff0a550de508345a247c93267` |
| `prism9Group.pzfx` | 9.5.1.528 | `TwoWay`、`YFormat="replicates"` | 8,646 | `ee8cc295ffcb72a33f50736aa1034e885330d0a9b8bbe0e29ed7e22d42a0cf34` |
| `prism9columns.pzfx` | 9.5.1.528 | `OneWay` | 7,913 | `89abe6872d8a2edced8c31691431b1e6af4ebb62bf513a09a02426a6ae77c0f1` |
| `prism10Group.pzfx` | 10.3.1.464 | `TwoWay`、`YFormat="replicates"` | 9,193 | `4808e39c40f1890699529640e8c1ba165466ced68086d9f501fcb0962f260be6` |
| `prism10columns.pzfx` | 10.3.1.464 | `OneWay` | 8,479 | `8ef7e2dc6ba5118e98695531403a711b7168ff834b8fc08a94dea7010ffbd7f7` |
| `prism11Group.pzfx` | 11.0.2.100 | `TwoWay`、`YFormat="replicates"` | 9,205 | `c5e3ad407a74a7b011945e1a46ea67cb48f4fefae1fd4b073624fc5402079a57` |
| `prism11Columns.pzfx` | 11.0.2.100 | `OneWay` | 8,509 | `df2e287072206676bc124c12ec1564de575ed5f8df805e6a4c3a190a2d5e4766` |

九份文件均为 `PrismXMLVersion="5.00"` 且不带默认命名空间。Prism 8–11 的 Column/Grouped 使用同一套结构规则。`prism8ColumnsTo9.pzfx` 证明另存后的文件可能保留空 `OriginalVersion`，因此解析器必须优先读取非空的 `MostRecentVersion`。

用途：作为本地端到端回归基准，逐项核对表型、标题、数值、空值位置和数据顺序。CI 必须使用匿名最小 fixture，不能依赖这些被忽略文件。

从仓库根目录运行以下只读审计命令，可重新输出所有本地 PZFX 的大小、SHA-256、创建版本和表型分类：

```bash
./.venv/bin/python scripts/inspect_prism_samples.py
```

## 本地 `.prism` 归档

用户还保存了 Prism 10/11 的 Column/Grouped `.prism` 文件。它们已确认是 ZIP 类归档，匹配版本间的数据 CSV 内容一致；当前 PZFX 首个里程碑不读取这些文件。后续实现 `easygraph/prism_io/archive.py` 时再补充归档内 JSON schema、表 ID 和 CSV 路径的稳定性记录。

| 文件 | 大小 | SHA-256 |
| --- | ---: | --- |
| `prism10Group.prism` | 10,540 | `8cd9e48c6874a58070a006886dca911cd055a016ba8ed73681a7ed584280d211` |
| `prism10columns.prism` | 10,389 | `086b20c138b88dc4e64569c03c74f7ec04bf6012ace056b5a0fc96821668cf7a` |
| `prism11Group.prism` | 10,589 | `8d82087418dc046f99835dfe8d510038949e7db93c7fae11d85b6226d29b6fdd` |
| `prism11Columns.prism` | 10,433 | `d4b2f630a90b8110eda5710ff6090cd9f95262006c7d04af5f9c9949727b2f47` |

## 版本元数据兼容结论

Prism 8 Column/Grouped 实样已经补齐，早期的“Prism 8 结构假设”现已由本地实样验证。版本识别以 `MostRecentVersion` 为准，`OriginalVersion` 仅作为旧文件没有最近版本节点时的回退。未来新增实样仍须记录创建版本、表型、文件大小、SHA-256 和许可/来源；不能通过修改 XML 版本字符串伪造版本样例。
