<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>GroupColorsDialog</name>
    <message>
        <source>Edit Group Colors</source>
        <translation>编辑分组颜色</translation>
    </message>
    <message>
        <source>Palette</source>
        <translation>调色板</translation>
    </message>
    <message>
        <source>Overlay palette</source>
        <translation>叠加线调色板</translation>
    </message>
    <message>
        <source>Guide palette</source>
        <translation>附加线调色板</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>项目</translation>
    </message>
    <message>
        <source>Current color</source>
        <translation>当前颜色</translation>
    </message>
    <message>
        <source>Palette colors</source>
        <translation>调色板颜色</translation>
    </message>
    <message>
        <source>Choose a color for each item. Changes preview immediately.</source>
        <translation>为每个项目选择颜色。更改将即时预览。</translation>
    </message>
    <message>
        <source>{name}: {color}</source>
        <translation>{name}：{color}</translation>
    </message>
    <message>
        <source>{name}: current color {color}</source>
        <translation>{name}：当前颜色 {color}</translation>
    </message>
    <message>
        <source>Reset {name} to its palette color.</source>
        <translation>将 {name} 恢复为调色板颜色。</translation>
    </message>
</context>
<context>
    <name>GroupOrderDialog</name>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="6"/>
        <source>Edit Group Order</source>
        <translation>编辑分组顺序</translation>
    </message>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="15"/>
        <source>Drag groups to change plot order.</source>
        <translation>拖动分组以调整绘图顺序。</translation>
    </message>
    <message>
        <location filename="../ui/group_order_dialog.ui" line="37"/>
        <source>Table Order</source>
        <translation>表格顺序</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit Group Order</source>
        <translation>编辑分组顺序</translation>
    </message>
    <message>
        <source>Bar Style</source>
        <translation>柱状图样式</translation>
    </message>
    <message>
        <source>Bar width</source>
        <translation>柱宽</translation>
    </message>
    <message>
        <source>Bar height / error</source>
        <translation>柱高与误差线</translation>
    </message>
    <message>
        <source>Mean with SD</source>
        <translation>均值 ± SD</translation>
    </message>
    <message>
        <source>Mean with SEM</source>
        <translation>均值 ± SEM</translation>
    </message>
    <message>
        <source>Mean with 95% CI</source>
        <translation>均值及 95% CI</translation>
    </message>
    <message>
        <source>Mean with range</source>
        <translation>均值及全距</translation>
    </message>
    <message>
        <source>Median with 95% CI</source>
        <translation>中位数及 95% CI</translation>
    </message>
    <message>
        <source>Median with range</source>
        <translation>中位数及全距</translation>
    </message>
    <message>
        <source>No line or error bar</source>
        <translation>不显示汇总柱或误差线</translation>
    </message>
    <message>
        <source>Bar height is the arithmetic mean, without error bars.</source>
        <translation>柱高为算术平均数，不显示误差线。</translation>
    </message>
    <message>
        <source>Mean plus/minus sample SD. Error bars require at least 2 valid values per column.</source>
        <translation>均值 ± 样本标准差（SD）。每列至少需要 2 个有效值才能绘制误差线。</translation>
    </message>
    <message>
        <source>Mean plus/minus SEM (sample SD divided by the square root of n). Error bars require at least 2 valid values per column.</source>
        <translation>均值 ± 均值标准误（SEM，即样本标准差除以样本量的平方根）。每列至少需要 2 个有效值才能绘制误差线。</translation>
    </message>
    <message>
        <source>95% confidence interval of the mean using Student's t distribution. Requires at least 2 valid values per column.</source>
        <translation>使用 Student t 分布计算均值的 95% 置信区间。每列至少需要 2 个有效值。</translation>
    </message>
    <message>
        <source>Bar height is the mean; error bars span the minimum to maximum.</source>
        <translation>柱高为均值，误差线从最小值延伸到最大值。</translation>
    </message>
    <message>
        <source>Bar height is the median, without error bars.</source>
        <translation>柱高为中位数，不显示误差线。</translation>
    </message>
    <message>
        <source>Nonparametric 95% CI from ordered values (binomial method; coverage is at least 95%). Requires at least 6 valid values per column; otherwise only the median is drawn.</source>
        <translation>使用排序后的观测值和二项分布计算非参数 95% 置信区间，覆盖率至少为 95%。每列至少需要 6 个有效值，否则仅绘制中位数柱。</translation>
    </message>
    <message>
        <source>Bar height is the median; error bars span the minimum to maximum.</source>
        <translation>柱高为中位数，误差线从最小值延伸到最大值。</translation>
    </message>
    <message>
        <source>Hide summary bars and error bars. Scatter points follow the point visibility and style settings.</source>
        <translation>隐藏汇总柱和误差线，散点继续使用原有的显示和样式设置。</translation>
    </message>
    <message>
        <source>Parent group spacing</source>
        <translation>一级组间距</translation>
    </message>
    <message>
        <source>Number Formats...</source>
        <translation>数值格式…</translation>
    </message>
    <message>
        <source>Statistic Number Formats...</source>
        <translation>统计类型数值格式…</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="329"/>
        <source>Colors</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Legend size</source>
        <translation type="vanished">图例字号</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="724"/>
        <location filename="../src/easygraph/ui/main_window.py" line="776"/>
        <location filename="../ui/main_window.ui" line="200"/>
        <location filename="../ui/main_window.ui" line="4121"/>
        <source>Legend</source>
        <translation>图例</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="730"/>
        <source>Chart Title</source>
        <translation>图表标题</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2783"/>
        <location filename="../src/easygraph/ui/main_window.py" line="2784"/>
        <location filename="../src/easygraph/ui/main_window.py" line="3077"/>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Auto wrap</source>
        <translation type="vanished">自动换行</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4338"/>
        <source>Columns</source>
        <translation>列数</translation>
    </message>
    <message>
        <source>Auto Primary Y Tick Interval</source>
        <translation type="vanished">自动主Y轴刻度间距</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="72"/>
        <source>Common</source>
        <translation>常用</translation>
    </message>
    <message>
        <source>Primary Y tick interval</source>
        <translation type="vanished">主Y轴刻度间距</translation>
    </message>
    <message>
        <source>Auto Secondary Y Tick Interval</source>
        <translation type="vanished">自动次Y轴刻度间距</translation>
    </message>
    <message>
        <source>Secondary Y tick interval</source>
        <translation type="vanished">次Y轴刻度间距</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3771"/>
        <source>Custom styles</source>
        <translation>自定义样式</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3734"/>
        <source>Custom line styles</source>
        <translation>自定义线形状</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3350"/>
        <source>Overlay filter</source>
        <translation>叠加线过滤器</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3356"/>
        <source>Show custom overlays</source>
        <translation>显示自定义叠加线</translation>
    </message>
    <message>
        <source>No Recent Projects</source>
        <translation type="vanished">没有最近项目</translation>
    </message>
    <message>
        <source>Clear Recent Projects</source>
        <translation type="vanished">清除最近项目</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3748"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3752"/>
        <source>System</source>
        <translation>跟随系统</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3754"/>
        <source>Simplified Chinese</source>
        <translation>简体中文</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3764"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3770"/>
        <source>Light</source>
        <translation>浅色</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3771"/>
        <source>Dark</source>
        <translation>暗色</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3782"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3783"/>
        <source>Preferences…</source>
        <translation>偏好设置…</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3824"/>
        <source>Undo Table Change</source>
        <translation>撤回表格修改</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3828"/>
        <source>Redo Table Change</source>
        <translation>重做表格修改</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3844"/>
        <source>Language changed</source>
        <translation>语言已更改</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3845"/>
        <source>Restart EasyGraph to apply the language change.</source>
        <translation>重启 EasyGraph 后语言更改会生效。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3851"/>
        <source>Recover Unsaved Work</source>
        <translation>恢复未保存的工作</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3855"/>
        <source>Untitled project</source>
        <translation>未命名项目</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3859"/>
        <source>EasyGraph found unsaved work from an earlier session for {project}.</source>
        <translation>EasyGraph 发现了先前会话中“{project}”的未保存内容。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3864"/>
        <source>Recover it now, discard it, or keep it for the next launch.</source>
        <translation>可以立即恢复、丢弃，或保留到下次启动时处理。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3868"/>
        <source>Recover</source>
        <translation>恢复</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3874"/>
        <source>Later</source>
        <translation>稍后</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3898"/>
        <source>Recovery failed</source>
        <translation>恢复失败</translation>
    </message>
    <message>
        <source>XY scatter plot</source>
        <translation type="vanished">XY 散点图</translation>
    </message>
    <message>
        <source>Shared X 1</source>
        <translation type="vanished">共享 X 1</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4454"/>
        <source>{name} Copy</source>
        <translation>{name} 副本</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4461"/>
        <source>Sheet name cannot be empty.</source>
        <translation>工作表名称不能为空。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4463"/>
        <source>Sheet name cannot be longer than 31 characters.</source>
        <translation>工作表名称不能超过 31 个字符。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4466"/>
        <source>Sheet name cannot contain: {characters}</source>
        <translation>工作表名称不能包含：{characters}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4468"/>
        <source>Sheet name cannot begin or end with an apostrophe.</source>
        <translation>工作表名称不能以撇号开头或结尾。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4470"/>
        <source>Sheet names must be unique.</source>
        <translation>工作表名称不能重复。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4481"/>
        <location filename="../src/easygraph/ui/main_window.py" line="4553"/>
        <source>Rename Sheet</source>
        <translation>重命名工作表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4482"/>
        <source>Sheet name</source>
        <translation>工作表名称</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4491"/>
        <source>Invalid sheet name</source>
        <translation>工作表名称无效</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4501"/>
        <source>A project must contain at least one sheet.</source>
        <translation>项目必须至少包含一个工作表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4511"/>
        <location filename="../src/easygraph/ui/main_window.py" line="4555"/>
        <source>Delete Sheet</source>
        <translation>删除工作表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4512"/>
        <source>Delete sheet &quot;{name}&quot;? This cannot be undone.</source>
        <translation>确定删除工作表“{name}”吗？此操作无法撤销。</translation>
    </message>
    <message>
        <source>New Sheet</source>
        <translation type="vanished">新建工作表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4551"/>
        <source>Duplicate Sheet</source>
        <translation>复制工作表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4559"/>
        <source>Move Left</source>
        <translation>左移</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4562"/>
        <source>Move Right</source>
        <translation>右移</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5107"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5113"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5118"/>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <source>Insert Data Pair</source>
        <translation type="vanished">插入数据对</translation>
    </message>
    <message>
        <source>Delete Data Pair</source>
        <translation type="vanished">删除数据对</translation>
    </message>
    <message>
        <source>Insert Y</source>
        <translation type="vanished">插入 Y</translation>
    </message>
    <message>
        <source>Delete Y</source>
        <translation type="vanished">删除 Y</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6085"/>
        <source>Copy Selected Data</source>
        <translation>复制选中数据</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6090"/>
        <source>Copy Selected Data with Headers</source>
        <translation>复制选中数据（含表头）</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6098"/>
        <source>Copy Current Statistics Table</source>
        <translation>复制当前显示统计表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2586"/>
        <location filename="../src/easygraph/ui/main_window.py" line="6691"/>
        <location filename="../ui/main_window.ui" line="93"/>
        <source>Group Filter</source>
        <translation>分组筛选</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="553"/>
        <source>Column descriptive statistics</source>
        <translation>列描述统计</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="555"/>
        <source>Descriptive statistics</source>
        <translation>描述统计</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2586"/>
        <location filename="../src/easygraph/ui/main_window.py" line="6638"/>
        <source>Series Filter</source>
        <translation>系列筛选</translation>
    </message>
    <message>
        <source>Series Setup…</source>
        <translation type="vanished">系列设置…</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8017"/>
        <source>Rename Column</source>
        <translation>重命名列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2592"/>
        <source>Series Style</source>
        <translation>系列样式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2613"/>
        <source>Show points</source>
        <translation>显示点</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3360"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9325"/>
        <source>Groups</source>
        <translation>分组</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2553"/>
        <location filename="../src/easygraph/ui/main_window.py" line="3361"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9323"/>
        <source>XY</source>
        <translation>XY</translation>
    </message>
    <message>
        <source>Column {number}</source>
        <translation type="vanished">第 {number} 列</translation>
    </message>
    <message>
        <source>Missing column</source>
        <translation type="vanished">缺失列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6639"/>
        <source>Add a series first.</source>
        <translation>请先添加系列。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6692"/>
        <source>Add a group first.</source>
        <translation>请先一个添加分组。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8018"/>
        <source>Column name</source>
        <translation>列名</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8705"/>
        <source>Box Style</source>
        <translation>箱线图样式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8706"/>
        <source>Violin Style</source>
        <translation>小提琴图样式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8707"/>
        <source>Ridge Style</source>
        <translation>山脊图样式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8753"/>
        <location filename="../src/easygraph/ui/main_window.py" line="8756"/>
        <source>Y Axis</source>
        <translation>Y 轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8757"/>
        <source>Primary X Axis</source>
        <translation>主 X 轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8758"/>
        <source>Secondary X Axis</source>
        <translation>次 X 轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8752"/>
        <location filename="../src/easygraph/ui/main_window.py" line="8760"/>
        <location filename="../ui/main_window.ui" line="1050"/>
        <source>X Axis</source>
        <translation>X 轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8761"/>
        <location filename="../ui/main_window.ui" line="1390"/>
        <source>Primary Y Axis</source>
        <translation>主 Y 轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8754"/>
        <location filename="../src/easygraph/ui/main_window.py" line="8762"/>
        <location filename="../ui/main_window.ui" line="2208"/>
        <source>Secondary Y Axis</source>
        <translation>次 Y 轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="736"/>
        <source>Additional grid line</source>
        <translation>附加网格线</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="983"/>
        <source>Editing: All series</source>
        <translation>正在编辑：所有系列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="987"/>
        <source>Editing: No series selected</source>
        <translation>正在编辑：未选择系列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="991"/>
        <source>Editing: {series}</source>
        <translation>正在编辑：{series}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="997"/>
        <source>Editing: {count} series</source>
        <translation>正在编辑：{count} 个系列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1087"/>
        <source>Align to plot left</source>
        <translation>画布内左对齐</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1088"/>
        <source>Align to plot right</source>
        <translation>画布内右对齐</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1089"/>
        <source>Align to plot bottom</source>
        <translation>画布内下对齐</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1090"/>
        <source>Align to plot top</source>
        <translation>画布内上对齐</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1093"/>
        <source>Below X axis</source>
        <translation>X轴下方</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1095"/>
        <source>Left of Y axis</source>
        <translation>Y轴左方</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1184"/>
        <location filename="../src/easygraph/ui/main_window.py" line="1210"/>
        <source>Color {number}</source>
        <translation>颜色 {number}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1386"/>
        <location filename="../src/easygraph/ui/main_window.py" line="6718"/>
        <location filename="../ui/main_window.ui" line="1724"/>
        <source>X axis</source>
        <translation>X 轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1387"/>
        <source>At X</source>
        <translation>X 位置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1389"/>
        <location filename="../src/easygraph/ui/main_window.py" line="6720"/>
        <location filename="../ui/main_window.ui" line="1731"/>
        <source>Y axis</source>
        <translation>Y 轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1390"/>
        <source>At Y</source>
        <translation>Y 位置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1392"/>
        <location filename="../src/easygraph/ui/main_window.py" line="6722"/>
        <source>Value axis</source>
        <translation>数值轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1393"/>
        <source>At value</source>
        <translation>数值位置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1395"/>
        <source>Editing additional marks on the {axis}</source>
        <translation>正在编辑{axis}上的附加标记</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1403"/>
        <source>Font size for additional labels on the {axis}</source>
        <translation>{axis}附加标注的字号</translation>
    </message>
    <message>
        <source>Line palette</source>
        <translation type="vanished">线条调色板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1775"/>
        <source>Hidden series</source>
        <translation>已隐藏系列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1790"/>
        <source>Selected {selected}/{total}</source>
        <translation>已选择 {selected}/{total}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1987"/>
        <location filename="../src/easygraph/ui/main_window.py" line="2015"/>
        <source>Mixed</source>
        <translation>混合</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2595"/>
        <source>XY Style Templates</source>
        <translation>XY 样式模板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2600"/>
        <source>Templates available for XY sheets</source>
        <translation>可用于 XY 工作表的模板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2605"/>
        <source>X axis title</source>
        <translation>X 轴标题</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2608"/>
        <source>Y axis title</source>
        <translation>Y 轴标题</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2724"/>
        <source>Series Points</source>
        <translation>系列点</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2948"/>
        <source>Automatic (theme)</source>
        <translation>自动（随明暗）</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2949"/>
        <source>Match line</source>
        <translation>与线条一致</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4284"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9615"/>
        <source>XY plot</source>
        <translation>XY 图</translation>
    </message>
    <message>
        <source>Add Column</source>
        <translation type="vanished">添加列</translation>
    </message>
    <message>
        <source>Delete Column</source>
        <translation type="vanished">删除列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9319"/>
        <source>Style template imported, but it has no {family} variant to apply on this sheet.</source>
        <translation>样式模板已导入，但不包含可应用于当前工作表的“{family}”变体。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9414"/>
        <source>The selected project could not be found:
{path}</source>
        <translation>找不到所选项目：
{path}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9681"/>
        <source>Imported {groups} Prism groups from {tables} tables into sheets</source>
        <translation>已从 {tables} 个 Prism 数据表导入 {groups} 个组，并创建为工作表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9703"/>
        <source>Excel Workbook — All Sheets (*.xlsx);;Current Sheet Excel (*.xlsx);;Current Sheet CSV (*.csv)</source>
        <translation>Excel 工作簿 — 全部工作表 (*.xlsx);;当前工作表 Excel (*.xlsx);;当前工作表 CSV (*.csv)</translation>
    </message>
    <message>
        <source>Overlay: {name}</source>
        <translation type="vanished">叠加线：{name}</translation>
    </message>
    <message>
        <source>Edit Group Colors</source>
        <translation type="vanished">编辑分组颜色</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="319"/>
        <source>Palette</source>
        <translation>调色板</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">重置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7939"/>
        <source>Custom Overlay Line Styles</source>
        <translation>自定义叠加线线型</translation>
    </message>
    <message>
        <source>Auto Primary {value_axis_name} Range</source>
        <translation type="vanished">自动主坐标轴 {value_axis_name} 范围</translation>
    </message>
    <message>
        <source>Primary {value_axis_name} min</source>
        <translation type="vanished">主坐标轴 {value_axis_name} 最小值</translation>
    </message>
    <message>
        <source>Primary {value_axis_name} max</source>
        <translation type="vanished">主坐标轴 {value_axis_name} 最大值</translation>
    </message>
    <message>
        <source>Auto Primary {value_axis_name} Tick Interval</source>
        <translation type="vanished">自动主坐标轴 {value_axis_name} 刻度间距</translation>
    </message>
    <message>
        <source>Primary {value_axis_name} tick interval</source>
        <translation type="vanished">主坐标轴 {value_axis_name} 刻度间距</translation>
    </message>
    <message>
        <source>Auto Secondary {value_axis_name} Range</source>
        <translation type="vanished">自动次坐标轴 {value_axis_name} 范围</translation>
    </message>
    <message>
        <source>Secondary {value_axis_name} min</source>
        <translation type="vanished">次坐标轴 {value_axis_name} 最小值</translation>
    </message>
    <message>
        <source>Secondary {value_axis_name} max</source>
        <translation type="vanished">次坐标轴 {value_axis_name} 最大值</translation>
    </message>
    <message>
        <source>Auto Secondary {value_axis_name} Tick Interval</source>
        <translation type="vanished">自动次坐标轴 {value_axis_name} 刻度间距</translation>
    </message>
    <message>
        <source>Secondary {value_axis_name} tick interval</source>
        <translation type="vanished">次坐标轴 {value_axis_name} 刻度间距</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9181"/>
        <source>Unsaved Changes</source>
        <translation>未保存的更改</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9184"/>
        <source>The current project has unsaved changes. Do you want to save them before continuing?</source>
        <translation>当前项目有未保存的更改。是否要在继续前保存？</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9188"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="3871"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9189"/>
        <source>Discard</source>
        <translation>丢弃</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9190"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Secondary value 
axis title</source>
        <translation type="vanished">次数值
坐标轴标题</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2774"/>
        <location filename="../src/easygraph/ui/main_window.py" line="2776"/>
        <location filename="../src/easygraph/ui/main_window.py" line="3063"/>
        <source>Right side</source>
        <translation>右侧</translation>
    </message>
    <message>
        <source>Below plot</source>
        <translation>绘图区下方</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2774"/>
        <location filename="../src/easygraph/ui/main_window.py" line="2776"/>
        <location filename="../src/easygraph/ui/main_window.py" line="3058"/>
        <location filename="../src/easygraph/ui/main_window.py" line="3063"/>
        <source>Inside plot</source>
        <translation>绘图区内</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4157"/>
        <source>Show legend</source>
        <translation>显示图例</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1827"/>
        <location filename="../ui/main_window.ui" line="1909"/>
        <location filename="../ui/main_window.ui" line="4199"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4241"/>
        <source>Auto width</source>
        <translation>自动宽度</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">确定</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6994"/>
        <source>Style template applied: {name}</source>
        <translation>已应用样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4310"/>
        <location filename="../src/easygraph/ui/main_window.py" line="7008"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9312"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9341"/>
        <source>Template load failed</source>
        <translation>模板加载失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="558"/>
        <source>Analysis Results · {title}</source>
        <translation>分析结果 · {title}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="602"/>
        <source>Statistics table copied to clipboard</source>
        <translation>统计表已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="725"/>
        <source>In-chart Statistics</source>
        <translation>图内统计表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="726"/>
        <source>Axes</source>
        <translation>坐标轴</translation>
    </message>
    <message>
        <source>Title &amp; Axis Titles</source>
        <translation type="vanished">标题与坐标轴标题</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="732"/>
        <location filename="../src/easygraph/ui/main_window.py" line="8736"/>
        <source>Chart Style</source>
        <translation>图表样式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="780"/>
        <source>Statistics Table</source>
        <translation>统计表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="791"/>
        <source>Lines</source>
        <translation>连线</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="805"/>
        <source>Grid Lines</source>
        <translation>网格线</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="810"/>
        <source>Summary Line</source>
        <translation>统计叠加线</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="815"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="816"/>
        <source>Median</source>
        <translation>中位数</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="817"/>
        <source>Mean</source>
        <translation>均值</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="836"/>
        <source>Custom Overlay Lines</source>
        <translation>自定义叠加线</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="845"/>
        <source>Secondary Axis for Custom Overlays</source>
        <translation>自定义叠加线使用次坐标轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="855"/>
        <source>Separate Secondary Axis</source>
        <translation>分离次坐标轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="862"/>
        <source>Overlay Value Labels</source>
        <translation>叠加线数值标签</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="831"/>
        <source>Add Custom Overlay…</source>
        <translation>添加自定义叠加线…</translation>
    </message>
    <message>
        <source>Edit Titles…</source>
        <translation type="vanished">编辑标题…</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="874"/>
        <source>＋ Chart Elements</source>
        <translation>＋ 图表元素</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="875"/>
        <source>Show or hide chart elements</source>
        <translation>显示或隐藏图表元素</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="876"/>
        <source>Chart Elements</source>
        <translation>图表元素</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="921"/>
        <source>Show custom overlay values on a secondary axis</source>
        <translation>在次坐标轴上显示自定义叠加线数值</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="923"/>
        <source>Add a custom overlay before enabling the secondary axis</source>
        <translation>请先添加自定义叠加线，再启用次坐标轴</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="976"/>
        <location filename="../ui/main_window.ui" line="821"/>
        <source>Editing: All settings</source>
        <translation>正在编辑：全部设置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1004"/>
        <source>Editing: {object}</source>
        <translation>正在编辑：{object}</translation>
    </message>
    <message>
        <source>+ Y</source>
        <translation type="vanished">+ Y</translation>
    </message>
    <message>
        <source>- Y</source>
        <translation type="vanished">- Y</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4755"/>
        <location filename="../src/easygraph/ui/main_window.py" line="4772"/>
        <source>Matches: {series}</source>
        <translation>匹配：{series}</translation>
    </message>
    <message>
        <source>Independent XY · {count} pairs</source>
        <translation type="vanished">独立 XY · {count} 对</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6279"/>
        <source>Edit Series Order</source>
        <translation>编辑系列顺序</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6280"/>
        <source>Drag series to change plot order.</source>
        <translation>拖动系列以调整绘图顺序。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6322"/>
        <source>Independent XY · Pair {number}</source>
        <translation>独立 XY · 第 {number} 对</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6334"/>
        <source>Unassigned</source>
        <translation>未分配</translation>
    </message>
    <message>
        <source>Shared X {number}</source>
        <translation type="vanished">共享 X {number}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7602"/>
        <source>Delete Shared X Table</source>
        <translation>删除共享 X 表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7603"/>
        <source>Delete &quot;{name}&quot; and all of its data?</source>
        <translation>删除“{name}”及其中的全部数据？</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7681"/>
        <source>Rename Shared X Table</source>
        <translation>重命名共享 X 表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7682"/>
        <source>Table name</source>
        <translation>表名称</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7846"/>
        <source>Delete Overlay</source>
        <translation>删除叠加线</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7847"/>
        <source>Delete overlay &apos;{name}&apos;? Its values will be permanently lost.</source>
        <translation>确认删除叠加线{name}? 叠加线对应数值将被永久删除。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7889"/>
        <source>Overlay Filter</source>
        <translation>叠加线过滤器</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7890"/>
        <location filename="../src/easygraph/ui/main_window.py" line="7940"/>
        <source>Add an overlay row first.</source>
        <translation>请先添加一行叠加线。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7961"/>
        <source>Rename Overlay</source>
        <translation>重命名叠加线</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7961"/>
        <source>Legend name</source>
        <translation>图例名称</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="7990"/>
        <source>The shared X column cannot be deleted; delete the tab instead.</source>
        <translation>不能单独删除共享 X 列；请删除整个标签页。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8018"/>
        <source>Group name</source>
        <translation>分组名称</translation>
    </message>
    <message>
        <source>Auto X range</source>
        <translation type="vanished">自动 X 范围</translation>
    </message>
    <message>
        <source>X min</source>
        <translation type="vanished">X 最小值</translation>
    </message>
    <message>
        <source>X max</source>
        <translation type="vanished">X 最大值</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9281"/>
        <source>Save Style Template</source>
        <translation>保存样式模板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9281"/>
        <source>Template name</source>
        <translation>模板名称</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9296"/>
        <source>Template save failed</source>
        <translation>模板保存失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9299"/>
        <source>Style template saved: {name}</source>
        <translation>已保存样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9302"/>
        <source>Load Style Template</source>
        <translation>加载样式模板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9302"/>
        <source>Style Template (*.json);;All Files (*)</source>
        <translation>样式模板 (*.json);;所有文件 (*)</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9348"/>
        <source>Style template loaded: {name}</source>
        <translation>已加载样式模板：{name}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9363"/>
        <source>Project save failed</source>
        <translation>项目保存失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9372"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9380"/>
        <source>EasyGraph Project (*.eg);;All Files (*)</source>
        <translation>EasyGraph 项目 (*.eg);;所有文件 (*)</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9404"/>
        <source>Recent project unavailable</source>
        <translation>最近项目不可用</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9405"/>
        <source>The selected recent project could not be found:
{path}</source>
        <translation>找不到所选的最近项目：
{path}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9397"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9413"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9426"/>
        <source>Project open failed</source>
        <translation>项目打开失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="635"/>
        <source>Preparing preview…</source>
        <translation>正在准备预览…</translation>
    </message>
    <message>
        <source>Excel Workbook (*.xlsx);;Current Sheet CSV (*.csv)</source>
        <translation type="vanished">Excel 工作簿 (*.xlsx);;当前工作表 CSV (*.csv)</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9795"/>
        <source>Figure image copied to clipboard</source>
        <translation>图形图片已复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9797"/>
        <source>Copy failed</source>
        <translation>复制失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9797"/>
        <source>Could not copy the figure to the clipboard.</source>
        <translation>无法将图形复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="14"/>
        <source>EasyGraph v2.0</source>
        <translation>EasyGraph v2.0</translation>
    </message>
    <message>
        <source>Data</source>
        <translation type="vanished">数据</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2597"/>
        <source>Groups Style Templates</source>
        <translation>分组样式模板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2602"/>
        <source>Templates available for Groups sheets</source>
        <translation>可用于分组工作表的模板</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4429"/>
        <source>XY demo</source>
        <translation>XY Demo</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5124"/>
        <source>Clear Contents</source>
        <translation>清除内容</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5133"/>
        <location filename="../src/easygraph/ui/main_window.py" line="5156"/>
        <location filename="../src/easygraph/ui/main_window.py" line="5180"/>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5143"/>
        <location filename="../src/easygraph/ui/main_window.py" line="5164"/>
        <location filename="../src/easygraph/ui/main_window.py" line="5213"/>
        <location filename="../ui/main_window.ui" line="1867"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5173"/>
        <location filename="../src/easygraph/ui/main_window.py" line="5243"/>
        <source>Applies to the entire X/Y pair</source>
        <translation>应用于整个 X/Y 数据对</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5182"/>
        <source>Shift Cells Down</source>
        <translation>下移单元格</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5192"/>
        <location filename="../src/easygraph/ui/main_window.py" line="5224"/>
        <source>Entire Row</source>
        <translation>整行</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5202"/>
        <location filename="../src/easygraph/ui/main_window.py" line="5234"/>
        <source>Entire Column</source>
        <translation>整列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="5216"/>
        <source>Shift Cells Up</source>
        <translation>上移单元格</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6475"/>
        <source>{series}: data are unavailable.</source>
        <translation>{series}：数据不可用。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6493"/>
        <location filename="../src/easygraph/ui/main_window.py" line="6509"/>
        <source>preview failed</source>
        <translation>预览失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6541"/>
        <source>Curve Fit</source>
        <translation>曲线拟合</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="6542"/>
        <source>Enter at least one valid XY data series before fitting.</source>
        <translation>请先输入至少一个有效的 XY 数据系列，再进行拟合。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="8017"/>
        <source>Rename Group</source>
        <translation>重命名分组</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="369"/>
        <source>Style Templates</source>
        <translation>样式模板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="379"/>
        <source>Load...</source>
        <translation>加载...</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="386"/>
        <source>Save Current</source>
        <translation>保存当前</translation>
    </message>
    <message>
        <source>Chart</source>
        <translation>图表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="309"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Preset</source>
        <translation type="vanished">预设</translation>
    </message>
    <message>
        <source>Group order</source>
        <translation type="vanished">分组顺序</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2589"/>
        <location filename="../src/easygraph/ui/main_window.py" line="3823"/>
        <location filename="../ui/main_window.ui" line="346"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="149"/>
        <location filename="../ui/main_window.ui" line="895"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="636"/>
        <source>Add shared X tab</source>
        <translation>添加共享 X 标签页</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="652"/>
        <source>Delete current shared X tab</source>
        <translation>删除当前共享 X 标签页</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="655"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="931"/>
        <source>Chart title</source>
        <translation>图表标题</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="953"/>
        <location filename="../ui/main_window.ui" line="982"/>
        <location filename="../ui/main_window.ui" line="1011"/>
        <location filename="../ui/main_window.ui" line="1040"/>
        <source>Enter to line break</source>
        <translation>按 Enter 换行</translation>
    </message>
    <message>
        <source>Group axis title</source>
        <translation type="vanished">分组坐标轴标题</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2610"/>
        <location filename="../ui/main_window.ui" line="989"/>
        <source>Primary value axis title</source>
        <translation>主数值坐标轴标题</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1018"/>
        <source>Secondary value axis title</source>
        <translation>次数值坐标轴标题</translation>
    </message>
    <message>
        <source>Use secondary axis</source>
        <translation>使用次坐标轴</translation>
    </message>
    <message>
        <source>Auto Secondary Y Range</source>
        <translation type="vanished">自动次 Y 范围</translation>
    </message>
    <message>
        <source>Secondary Y min</source>
        <translation type="vanished">次 Y 轴 min</translation>
    </message>
    <message>
        <source>Secondary Y max</source>
        <translation type="vanished">次 Y 轴 max</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2529"/>
        <source>Split secondary frame</source>
        <translation>拆分次坐标轴绘图区</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2571"/>
        <source>Secondary frame ratio</source>
        <translation>次坐标轴绘图区占比</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2676"/>
        <source>Selected 0/0</source>
        <translation>已选择 0/0</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2708"/>
        <source>Edit every series through the all-series style</source>
        <translation>通过所有系列样式编辑全部系列</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">全部</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2718"/>
        <source>Clear the editable series selection</source>
        <translation>清空待编辑的系列选择</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2721"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2728"/>
        <source>Invert the editable series selection</source>
        <translation>反选待编辑的系列</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2731"/>
        <source>Invert</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2765"/>
        <source>No series selected</source>
        <translation>未选择系列</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2852"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2904"/>
        <source>Opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2956"/>
        <source>Marker</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3025"/>
        <source>Jitter amount</source>
        <translation>抖动幅度</translation>
    </message>
    <message>
        <source>Show lines</source>
        <translation type="vanished">显示线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3190"/>
        <source>Clear the selected series&apos; overrides and follow the all-series style</source>
        <translation>清除所选系列的覆盖设置并沿用所有系列样式</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3238"/>
        <source>Highlight outliers</source>
        <translation>突出显示异常值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4283"/>
        <source>Width (cm)</source>
        <translation>宽度 (cm)</translation>
    </message>
    <message>
        <source>Height (cm)</source>
        <translation type="vanished">高度 (cm)</translation>
    </message>
    <message>
        <source>Export DPI</source>
        <translation type="vanished">导出 DPI</translation>
    </message>
    <message>
        <source>Transparent bg</source>
        <translation type="vanished">透明背景</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="90"/>
        <location filename="../ui/main_window.ui" line="5498"/>
        <source>Copy as Image</source>
        <translation>复制为图片</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="116"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Title size</source>
        <translation type="vanished">标题字号</translation>
    </message>
    <message>
        <source>Axis label size</source>
        <translation type="vanished">坐标轴标签字号</translation>
    </message>
    <message>
        <source>Tick size</source>
        <translation type="vanished">刻度字号</translation>
    </message>
    <message>
        <source>Overlay value size</source>
        <translation type="vanished">叠加数值字号</translation>
    </message>
    <message>
        <source>Stats table size</source>
        <translation type="vanished">统计表字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="166"/>
        <source>Axis</source>
        <translation>坐标轴</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="547"/>
        <source>Fit built-in or custom equations to the selected XY series</source>
        <translation>使用内置或自定义方程拟合所选 XY 数据系列</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="550"/>
        <source>Curve Fit...</source>
        <translation>曲线拟合...</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1335"/>
        <source>Label rotation</source>
        <translation>标签旋转</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1675"/>
        <source>Additional ticks and grid lines</source>
        <translation>附加刻度与网格线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1696"/>
        <source>Selected axis</source>
        <translation>所选坐标轴</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1837"/>
        <source>Line</source>
        <translation>线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1842"/>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1847"/>
        <location filename="../ui/main_window.ui" line="1979"/>
        <source>Text</source>
        <translation>文字</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1860"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1939"/>
        <source>Value with text</source>
        <translation>有文字时显示数值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1949"/>
        <source>Grid line</source>
        <translation>网格线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1959"/>
        <source>Line color</source>
        <translation>线条颜色</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1969"/>
        <source>Text color</source>
        <translation>文字颜色</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2001"/>
        <source>Up to two lines</source>
        <translation>最多两行</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2008"/>
        <source>Text side</source>
        <translation>文字左右位置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1081"/>
        <location filename="../ui/main_window.ui" line="2016"/>
        <source>Left</source>
        <translation>左侧</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1082"/>
        <location filename="../src/easygraph/ui/main_window.py" line="1084"/>
        <location filename="../ui/main_window.ui" line="2021"/>
        <location filename="../ui/main_window.ui" line="2042"/>
        <source>Center</source>
        <translation>居中</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1083"/>
        <location filename="../ui/main_window.ui" line="2026"/>
        <source>Right</source>
        <translation>右侧</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2034"/>
        <source>Text height</source>
        <translation>文字高度位置</translation>
    </message>
    <message>
        <source>Same height</source>
        <translation type="vanished">等高</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1086"/>
        <location filename="../ui/main_window.ui" line="2047"/>
        <source>Below</source>
        <translation>下方</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="1085"/>
        <location filename="../ui/main_window.ui" line="2052"/>
        <source>Above</source>
        <translation>上方</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2060"/>
        <source>Label background</source>
        <translation>标签背景</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2075"/>
        <source>Axes Appearance</source>
        <translation>坐标轴外观</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2111"/>
        <source>Show grid</source>
        <translation>显示网格</translation>
    </message>
    <message>
        <source>Auto Primary Y Range</source>
        <translation type="vanished">自动主 Y 范围</translation>
    </message>
    <message>
        <source>Primary Y min</source>
        <translation type="vanished">主 Y 轴 min</translation>
    </message>
    <message>
        <source>Primary Y max</source>
        <translation type="vanished">主 Y 轴 max</translation>
    </message>
    <message>
        <source>Axis line width</source>
        <translation type="vanished">坐标轴线宽</translation>
    </message>
    <message>
        <source>X label rotation</source>
        <translation type="vanished">X 标签旋转</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="783"/>
        <location filename="../src/easygraph/ui/main_window.py" line="2592"/>
        <location filename="../src/easygraph/ui/main_window.py" line="2724"/>
        <location filename="../ui/main_window.ui" line="2629"/>
        <source>Data Points</source>
        <translation>数据点</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2613"/>
        <location filename="../ui/main_window.ui" line="2810"/>
        <source>Show all points</source>
        <translation>显示所有点</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3780"/>
        <source>Point size</source>
        <translation>点大小</translation>
    </message>
    <message>
        <source>Point alpha</source>
        <translation type="vanished">点透明度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2983"/>
        <source>Jitter mode</source>
        <translation>抖动模式</translation>
    </message>
    <message>
        <source>Jitter</source>
        <translation type="vanished">抖动</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="735"/>
        <location filename="../ui/main_window.ui" line="3419"/>
        <source>Line Overlay</source>
        <translation>折线叠加</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3455"/>
        <source>Show line</source>
        <translation>显示折线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3497"/>
        <source>Trend overlay</source>
        <translation>趋势叠加</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3539"/>
        <source>Extra custom overlay</source>
        <translation>额外自定义叠加线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3581"/>
        <source>Custom line count</source>
        <translation>自定义线数量</translation>
    </message>
    <message>
        <source>Statistic</source>
        <translation type="vanished">统计量</translation>
    </message>
    <message>
        <source>Overlay +</source>
        <translation type="vanished">叠加线 +</translation>
    </message>
    <message>
        <source>Overlay -</source>
        <translation type="vanished">叠加线 -</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="533"/>
        <source>+ Overlay</source>
        <translation>+ 叠加线</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="540"/>
        <source>- Overlay</source>
        <translation>- 叠加线</translation>
    </message>
    <message>
        <source>Primary value 
axis title</source>
        <translation type="vanished">主数值
坐标轴标题</translation>
    </message>
    <message>
        <source>Plot area width (cm)</source>
        <translation type="vanished">绘图区宽度 (cm)</translation>
    </message>
    <message>
        <source>Plot area height (cm)</source>
        <translation type="vanished">绘图区高度 (cm)</translation>
    </message>
    <message>
        <source>Group filter</source>
        <translation type="vanished">分组过滤器</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3631"/>
        <source>Filter</source>
        <translation>过滤</translation>
    </message>
    <message>
        <source>All sizes</source>
        <translation type="vanished">全部字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="153"/>
        <source>Decrease All Font Sizes</source>
        <translation>减小所有字号</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="140"/>
        <source>Increase All Font Sizes</source>
        <translation>增大所有字号</translation>
    </message>
    <message>
        <source>Clipboard</source>
        <translation type="vanished">剪贴板</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="86"/>
        <source>Copy Statistics Table</source>
        <translation>复制统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="183"/>
        <location filename="../ui/main_window.ui" line="1832"/>
        <location filename="../ui/main_window.ui" line="1929"/>
        <source>Tick</source>
        <translation>刻度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="220"/>
        <source>Data label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="243"/>
        <source>Additional labels</source>
        <translation>附加标注</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="266"/>
        <source>Stats table</source>
        <translation>统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="302"/>
        <source>Chart Basics</source>
        <translation>图表基础</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="336"/>
        <source>Order</source>
        <translation>顺序</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="409"/>
        <source>Export &amp; Canvas</source>
        <translation>输出&amp;画布</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="416"/>
        <source>W</source>
        <translation>宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="436"/>
        <source>H</source>
        <translation>高</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="456"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="491"/>
        <source>Transparent</source>
        <translation>透明背景</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2615"/>
        <location filename="../ui/main_window.ui" line="595"/>
        <source>Shared X</source>
        <translation>共享 X</translation>
    </message>
    <message>
        <source>+ Tab</source>
        <translation type="vanished">+ 标签页</translation>
    </message>
    <message>
        <source>- Tab</source>
        <translation type="vanished">- 标签页</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="703"/>
        <source>Analysis Results · Descriptive statistics</source>
        <translation>分析结果 · 描述性统计</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2616"/>
        <location filename="../ui/main_window.ui" line="696"/>
        <source>Independent XY</source>
        <translation>独立 XY</translation>
    </message>
    <message>
        <source>+ Pair</source>
        <translation type="vanished">+ 数据对</translation>
    </message>
    <message>
        <source>- Pair</source>
        <translation type="vanished">- 数据对</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="840"/>
        <source>Show All</source>
        <translation>显示全部</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2605"/>
        <location filename="../ui/main_window.ui" line="960"/>
        <source>Category axis title</source>
        <translation>分类轴标题</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1086"/>
        <location filename="../ui/main_window.ui" line="1426"/>
        <location filename="../ui/main_window.ui" line="2286"/>
        <source>Auto range</source>
        <translation>自动范围</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1128"/>
        <location filename="../ui/main_window.ui" line="1468"/>
        <location filename="../ui/main_window.ui" line="2328"/>
        <source>Minimum</source>
        <translation>最小值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1183"/>
        <location filename="../ui/main_window.ui" line="1520"/>
        <location filename="../ui/main_window.ui" line="2380"/>
        <source>Maximum</source>
        <translation>最大值</translation>
    </message>
    <message>
        <source>All axes line width</source>
        <translation type="vanished">全部坐标轴线宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1238"/>
        <location filename="../ui/main_window.ui" line="1572"/>
        <location filename="../ui/main_window.ui" line="2432"/>
        <source>Auto tick interval</source>
        <translation>自动刻度间隔</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1280"/>
        <location filename="../ui/main_window.ui" line="1614"/>
        <location filename="../ui/main_window.ui" line="2474"/>
        <source>Tick interval</source>
        <translation>刻度间隔</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2244"/>
        <source>Use for overlay lines</source>
        <translation>用于叠加线</translation>
    </message>
    <message>
        <source>Secondary value
axis title</source>
        <translation type="vanished">次坐标轴数值
标题</translation>
    </message>
    <message>
        <source>Selection / Filter</source>
        <translation type="vanished">选择 / 过滤</translation>
    </message>
    <message>
        <source>Axis &amp; Range</source>
        <translation type="vanished">坐标轴 &amp; 范围</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="2855"/>
        <source>Use secondary axis for lines</source>
        <translation>叠加线使用次坐标轴</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4772"/>
        <source>Sheet menu</source>
        <translation>工作表菜单</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4775"/>
        <source>☰</source>
        <translation>☰</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4810"/>
        <source>Add sheet</source>
        <translation>添加工作表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="639"/>
        <location filename="../ui/main_window.ui" line="4813"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4883"/>
        <source>Import Prism PZFX...</source>
        <translation>导入 Prism PZFX...</translation>
    </message>
    <message>
        <source>Primary Axis</source>
        <translation type="vanished">主坐标轴</translation>
    </message>
    <message>
        <source>Secondary Axis</source>
        <translation type="vanished">次坐标轴</translation>
    </message>
    <message>
        <source>叠加线使用次坐标轴</source>
        <translation type="vanished">叠加线使用次坐标轴</translation>
    </message>
    <message>
        <source>Data Points &amp; Outliers</source>
        <translation type="vanished">数据点 &amp; 异常值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="1774"/>
        <location filename="../ui/main_window.ui" line="2153"/>
        <location filename="../ui/main_window.ui" line="3104"/>
        <location filename="../ui/main_window.ui" line="3640"/>
        <source>Line width</source>
        <translation>线宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="2711"/>
        <source>All series</source>
        <translation>所有系列</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3077"/>
        <source>Connect data points</source>
        <translation>连接数据点</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3141"/>
        <location filename="../ui/main_window.ui" line="3692"/>
        <source>Line style</source>
        <translation>线型</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4197"/>
        <location filename="../ui/main_window.ui" line="4220"/>
        <source>Break between parent groups</source>
        <translation>叠加线不跨一级组</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4199"/>
        <location filename="../ui/main_window.ui" line="4219"/>
        <source>Draw separate overlay segments within each parent group. Ungrouped columns keep points only. Available when the table has parent groups.</source>
        <translation>按一级组绘制独立叠加线段；未分组列仅保留叠加点。仅在表格存在一级组时可用。</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3187"/>
        <source>Use all-series style</source>
        <translation>使用所有系列样式</translation>
    </message>
    <message>
        <source>Clear this series&apos; overrides and follow the all-series style</source>
        <translation type="vanished">清除该系列的覆盖设置并沿用所有系列样式</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3832"/>
        <source>Show values</source>
        <translation>显示数值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3874"/>
        <source>Label position</source>
        <translation>标签位置</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3916"/>
        <source>Extra label position</source>
        <translation>额外标签位置</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3958"/>
        <source>Scientific</source>
        <translation>科学计数法</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4000"/>
        <source>Decimals</source>
        <translation>小数位数</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4055"/>
        <source>Stats Table</source>
        <translation>统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4076"/>
        <source>Show statistics table</source>
        <translation>显示统计表</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4086"/>
        <source>Show header</source>
        <translation>显示表头</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="734"/>
        <location filename="../src/easygraph/ui/main_window.py" line="801"/>
        <location filename="../ui/main_window.ui" line="3202"/>
        <source>Outliers</source>
        <translation>离群值</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation type="vanished">高亮</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3280"/>
        <source>Method</source>
        <translation>方法</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3322"/>
        <source>Threshold</source>
        <translation>阈值</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="3374"/>
        <source>Effect</source>
        <translation>效果</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4383"/>
        <source>Type-specific</source>
        <translation>类型专属</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4419"/>
        <source>Box width</source>
        <translation>箱体宽度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4471"/>
        <source>Box whisker mode</source>
        <translation>箱线须模式</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4513"/>
        <source>Violin width</source>
        <translation>小提琴宽度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4565"/>
        <source>KDE bandwidth</source>
        <translation>KDE 带宽</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4617"/>
        <source>Ridge overlap</source>
        <translation>山脊重叠</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4669"/>
        <source>Fill alpha</source>
        <translation>填充透明度</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4833"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4837"/>
        <source>Open Recent</source>
        <translation>打开最近项目</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="4544"/>
        <location filename="../ui/main_window.ui" line="4858"/>
        <source>New</source>
        <translation>新建</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9380"/>
        <location filename="../ui/main_window.ui" line="4863"/>
        <source>Open Project</source>
        <translation>打开项目</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9372"/>
        <location filename="../ui/main_window.ui" line="4868"/>
        <source>Save Project</source>
        <translation>保存项目</translation>
    </message>
    <message>
        <location filename="../ui/main_window.ui" line="4873"/>
        <source>Save Project As</source>
        <translation>项目另存为</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9642"/>
        <location filename="../ui/main_window.ui" line="4878"/>
        <source>Import Excel</source>
        <translation>导入 Excel</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9642"/>
        <source>Excel Files (*.xlsx *.xls);;CSV Files (*.csv)</source>
        <translation>Excel 文件 (*.xlsx *.xls);;CSV 文件 (*.csv)</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9657"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9693"/>
        <location filename="../src/easygraph/ui/main_window.py" line="9695"/>
        <source>Import failed</source>
        <translation>导入失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9664"/>
        <source>Import Prism PZFX</source>
        <translation>导入 Prism PZFX</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9666"/>
        <source>Prism PZFX (*.pzfx);;Legacy Prism PZF (*.pzf);;All Files (*)</source>
        <translation>Prism PZFX (*.pzfx);;旧版 Prism PZF (*.pzf);;所有文件 (*)</translation>
    </message>
    <message>
        <source>Imported {groups} Prism groups</source>
        <translation type="vanished">已导入 {groups} 个 Prism 分组</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9688"/>
        <source>; {count} excluded values became empty cells</source>
        <translation>；{count} 个排除值已转换为空单元格</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9700"/>
        <location filename="../ui/main_window.ui" line="4888"/>
        <source>Export Excel</source>
        <translation>导出 Excel</translation>
    </message>
    <message>
        <source>Excel File (*.xlsx);;CSV File (*.csv)</source>
        <translation type="vanished">Excel 文件 (*.xlsx);;CSV 文件 (*.csv)</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9765"/>
        <source>Export failed</source>
        <translation>导出失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/main_window.py" line="9777"/>
        <location filename="../ui/main_window.ui" line="4898"/>
        <source>Export Figure</source>
        <translation>导出图形</translation>
    </message>
    <message>
        <source>Table</source>
        <translation>表格</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>撤销</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <source>Changes can be undone.</source>
        <translation>操作支持撤销。</translation>
    </message>
    <message>
        <source>Rows and columns</source>
        <translation>行与列</translation>
    </message>
    <message>
        <source>Insert row above</source>
        <translation>向上插入行</translation>
    </message>
    <message>
        <source>Insert row below</source>
        <translation>向下插入行</translation>
    </message>
    <message>
        <source>Insert column left</source>
        <translation>向左插入列</translation>
    </message>
    <message>
        <source>Insert column right</source>
        <translation>向右插入列</translation>
    </message>
    <message>
        <source>Delete rows</source>
        <translation>删除行</translation>
    </message>
    <message>
        <source>Delete columns</source>
        <translation>删除列</translation>
    </message>
    <message>
        <source>Parent headers</source>
        <translation>一级表头</translation>
    </message>
    <message>
        <source>Merge parent headers…</source>
        <translation>合并一级表头…</translation>
    </message>
    <message>
        <source>Unmerge parent headers</source>
        <translation>取消合并一级表头</translation>
    </message>
    <message>
        <source>Rename parent header…</source>
        <translation>重命名一级表头…</translation>
    </message>
    <message>
        <source>Insert parent group left</source>
        <translation>向左插入一级分组</translation>
    </message>
    <message>
        <source>Insert parent group right</source>
        <translation>向右插入一级分组</translation>
    </message>
    <message>
        <source>Create parent groups…</source>
        <translation>批量创建一级分组…</translation>
    </message>
    <message>
        <source>Select parent headers or columns</source>
        <translation>请选择一级表头或列</translation>
    </message>
    <message>
        <source>Group layout...</source>
        <translation>分组显示设置…</translation>
    </message>
</context>
<context>
    <name>PlotCanvas</name>
    <message>
        <source>Reset Zoom to 100%</source>
        <translation>重置缩放为 100%</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>缩小</translation>
    </message>
    <message>
        <source>Fit to View</source>
        <translation>适应窗口</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>放大</translation>
    </message>
    <message>
        <location filename="../src/easygraph/plotting/canvas.py" line="317"/>
        <source>Box Select (B)</source>
        <translation>框选 (B)</translation>
    </message>
    <message>
        <location filename="../src/easygraph/plotting/canvas.py" line="324"/>
        <source>Drag across visible lines or markers. Ctrl/Cmd adds; Alt removes.</source>
        <translation>拖过可见线条或数据点；Ctrl/Cmd 添加，Alt 移除。</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="56"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="70"/>
        <source>System</source>
        <translation>跟随系统</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="72"/>
        <source>Simplified Chinese</source>
        <translation>简体中文</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="74"/>
        <source>Light</source>
        <translation>浅色</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="75"/>
        <source>Dark</source>
        <translation>暗色</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="81"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="82"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="84"/>
        <source>Language changes take effect after restarting EasyGraph.</source>
        <translation>语言更改将在重启 EasyGraph 后生效。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="89"/>
        <source>General</source>
        <translation>常规</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="96"/>
        <source> seconds</source>
        <translation> 秒</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="103"/>
        <source>Write recovery changes every</source>
        <translation>恢复记录写入间隔</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="108"/>
        <source>This interval writes only incremental JSONL recovery changes. Large imports are stored as a complete background checkpoint.</source>
        <translation>此间隔只用于写入增量 JSONL 恢复记录。大型导入会在后台保存为一个完整检查点。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="116"/>
        <source>Recovery</source>
        <translation>恢复</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="122"/>
        <source>Re-register .eg project files with this copy of EasyGraph and refresh the system project icon cache.</source>
        <translation>使用当前 EasyGraph 重新注册 .eg 项目文件，并刷新系统项目图标缓存。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="130"/>
        <source>Refresh .eg File Association</source>
        <translation>刷新 .eg 文件关联</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="141"/>
        <source>File Association</source>
        <translation>文件关联</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="180"/>
        <source>The .eg file association and project icon were refreshed.</source>
        <translation>已刷新 .eg 文件关联和项目图标。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="183"/>
        <source>Run the packaged EasyGraph application to refresh file associations.</source>
        <translation>请运行打包后的 EasyGraph 应用以刷新文件关联。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="186"/>
        <source>EasyGraph could not refresh the .eg file association.</source>
        <translation>EasyGraph 无法刷新 .eg 文件关联。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/preferences_dialog.py" line="189"/>
        <source>File-association refresh is not supported on this operating system.</source>
        <translation>当前操作系统不支持刷新文件关联。</translation>
    </message>
</context>
<context>
    <name>PrismImportDialog</name>
    <message>
        <location filename="../ui/prism_import_dialog.ui" line="20"/>
        <source>Import Prism PZFX</source>
        <translation>导入 Prism PZFX</translation>
    </message>
    <message>
        <location filename="../ui/prism_import_dialog.ui" line="26"/>
        <source>Prism source</source>
        <translation>Prism 来源</translation>
    </message>
    <message>
        <location filename="../ui/prism_import_dialog.ui" line="38"/>
        <source>Data tables:</source>
        <translation>数据表：</translation>
    </message>
    <message>
        <location filename="../ui/prism_import_dialog.ui" line="61"/>
        <source>0 tables selected</source>
        <translation>已选择 0 个数据表</translation>
    </message>
    <message>
        <location filename="../ui/prism_import_dialog.ui" line="68"/>
        <source>Select All Supported</source>
        <translation>选择全部受支持的数据表</translation>
    </message>
    <message>
        <location filename="../ui/prism_import_dialog.ui" line="75"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <source>Data table:</source>
        <translation type="vanished">数据表：</translation>
    </message>
    <message>
        <location filename="../ui/prism_import_dialog.ui" line="106"/>
        <source>Table summary</source>
        <translation>表格摘要</translation>
    </message>
    <message>
        <location filename="../ui/prism_import_dialog.ui" line="151"/>
        <source>Preview shows at most 20 rows and 12 groups.</source>
        <translation>预览最多显示 20 行和 12 个分组。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="33"/>
        <source>Source: {file} — Prism {version}, PZFX XML {xml_version}</source>
        <translation>来源：{file} — Prism {version}，PZFX XML {xml_version}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="37"/>
        <source>unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="38"/>
        <source>This PZFX file contains no data tables.</source>
        <translation>此 PZFX 文件不包含数据表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="42"/>
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="43"/>
        <source>{title} — {kind}</source>
        <translation>{title} — {kind}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="44"/>
        <source>Unsupported: {label}</source>
        <translation>不支持：{label}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="45"/>
        <source>This table cannot be imported.</source>
        <translation>无法导入此数据表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="46"/>
        <source>No Prism table is selected.</source>
        <translation>未选择 Prism 数据表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="47"/>
        <source>{count} tables selected</source>
        <translation>已选择 {count} 个数据表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="51"/>
        <source>1 table selected</source>
        <translation>已选择 1 个数据表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="55"/>
        <source>Type: {kind} | Groups: {groups} | Rows: {rows} | Missing: {missing} | Excluded: {excluded}</source>
        <translation>类型：{kind} | 分组：{groups} | 行数：{rows} | 缺失：{missing} | 排除：{excluded}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="59"/>
        <source>Excluded Prism values will be imported as empty cells and will not be plotted.</source>
        <translation>Prism 中的排除值将作为空单元格导入且不参与绘图。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="63"/>
        <source>Grouped row and column factors are combined into EasyGraph group names.</source>
        <translation>Grouped 的行因素和列因素将合并为 EasyGraph 分组名称。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="67"/>
        <source>Prism version {version} has not been validated for PZFX import.</source>
        <translation>Prism {version} 尚未经过 PZFX 导入验证。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="71"/>
        <source>Extended table type {table_type} is not supported.</source>
        <translation>不支持扩展表类型 {table_type}。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="75"/>
        <source>Y format {y_format} is not raw replicate data and cannot be imported.</source>
        <translation>Y 格式 {y_format} 不是原始重复值，无法导入。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="79"/>
        <source>Prism table type {table_type} is not supported.</source>
        <translation>不支持 Prism 表类型 {table_type}。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="83"/>
        <source>This table does not match the supported raw Column or Grouped structure.</source>
        <translation>此数据表不符合受支持的原始 Column 或 Grouped 结构。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="89"/>
        <source>This Prism application version has not been validated.</source>
        <translation>此 Prism 应用版本尚未经过验证。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="92"/>
        <source>One or more tables had no ID; fallback IDs were assigned.</source>
        <translation>一个或多个数据表没有 ID，已分配备用 ID。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="95"/>
        <source>Duplicate table IDs were safely disambiguated.</source>
        <translation>重复的数据表 ID 已安全区分。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="98"/>
        <source>Column row titles are not represented in EasyGraph.</source>
        <translation>EasyGraph 不表示 Column 的行标题。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="101"/>
        <source>Shorter Column groups were padded with empty cells.</source>
        <translation>较短的 Column 分组已用空单元格补齐。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="104"/>
        <source>Some Grouped rows used fallback names because row titles were missing.</source>
        <translation>部分 Grouped 行缺少标题，已使用备用名称。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="107"/>
        <source>The declared replicate count differs from the XML data structure.</source>
        <translation>声明的重复值数量与 XML 数据结构不一致。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="110"/>
        <source>A declared Subcolumn count differs from the XML data structure.</source>
        <translation>声明的 Subcolumn 数量与 XML 数据结构不一致。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="113"/>
        <source>A short Grouped Subcolumn was padded with an empty cell.</source>
        <translation>较短的 Grouped Subcolumn 已用空单元格补齐。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="119"/>
        <source>The Prism file could not be read.</source>
        <translation>无法读取 Prism 文件。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="120"/>
        <source>The PZFX file exceeds the safety size limit.</source>
        <translation>PZFX 文件超过安全大小限制。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="121"/>
        <source>PZFX files containing DOCTYPE or ENTITY declarations are not supported.</source>
        <translation>不支持包含 DOCTYPE 或 ENTITY 声明的 PZFX 文件。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="124"/>
        <source>The PZFX XML is malformed.</source>
        <translation>PZFX XML 格式错误。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="125"/>
        <source>PZFX import currently requires UTF-8 XML encoding.</source>
        <translation>PZFX 导入当前要求使用 UTF-8 XML 编码。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="128"/>
        <source>Legacy .pzf files are binary. Save the file as .pzfx in Prism first.</source>
        <translation>旧版 .pzf 是二进制文件，请先在 Prism 中另存为 .pzfx。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="131"/>
        <source>Select a GraphPad Prism .pzfx file.</source>
        <translation>请选择 GraphPad Prism .pzfx 文件。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="132"/>
        <source>The XML root is not a GraphPad Prism file.</source>
        <translation>XML 根节点不是 GraphPad Prism 文件。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="133"/>
        <source>This Prism XML format version is not supported.</source>
        <translation>不支持此 Prism XML 格式版本。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="136"/>
        <source>The PZFX file contains no data tables.</source>
        <translation>PZFX 文件不包含数据表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="137"/>
        <source>The PZFX file contains too many tables.</source>
        <translation>PZFX 文件包含过多数据表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="138"/>
        <source>The PZFX file contains too many data values.</source>
        <translation>PZFX 文件包含过多数据值。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="139"/>
        <source>The PZFX file contains too many columns.</source>
        <translation>PZFX 文件包含过多数据列。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="140"/>
        <source>The PZFX file contains too many Subcolumns.</source>
        <translation>PZFX 文件包含过多 Subcolumn。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="143"/>
        <source>The selected Prism table was not found.</source>
        <translation>未找到所选 Prism 数据表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="144"/>
        <source>The selected Prism table is not supported.</source>
        <translation>不支持所选 Prism 数据表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="145"/>
        <source>The selected table contains a non-numeric raw value.</source>
        <translation>所选数据表包含非数值的原始数据。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/prism_import_dialog.py" line="148"/>
        <source>The selected table contains a non-finite raw value.</source>
        <translation>所选数据表包含非有限数值。</translation>
    </message>
</context>
<context>
    <name>SpreadsheetImportDialog</name>
    <message>
        <location filename="../src/easygraph/ui/spreadsheet_import_dialog.py" line="53"/>
        <source>Import Excel Sheets</source>
        <translation>导入 Excel 工作表</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/spreadsheet_import_dialog.py" line="57"/>
        <source>Select the worksheets to import. Each worksheet becomes an EasyGraph sheet.</source>
        <translation>请选择要导入的工作表。每个工作表都会成为一个 EasyGraph 工作表。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/spreadsheet_import_dialog.py" line="66"/>
        <source>Selected sheet type</source>
        <translation>所选工作表类型</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/spreadsheet_import_dialog.py" line="72"/>
        <source>Groups</source>
        <translation>分组</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/spreadsheet_import_dialog.py" line="76"/>
        <source>XY</source>
        <translation>XY</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/spreadsheet_import_dialog.py" line="100"/>
        <source>{name}  —  {rows} rows × {columns} columns</source>
        <translation>{name}  —  {rows} 行 × {columns} 列</translation>
    </message>
</context>
<context>
    <name>StartupDialog</name>
    <message>
        <source>Welcome to EasyGraph</source>
        <translation>欢迎使用 EasyGraph</translation>
    </message>
    <message>
        <source>Demo example</source>
        <translation>Demo 示例</translation>
    </message>
    <message>
        <source>Single-level headers</source>
        <translation>单层表头</translation>
    </message>
    <message>
        <source>Two-level headers</source>
        <translation>双层表头</translation>
    </message>
    <message>
        <source>XY demo</source>
        <translation>XY 示例</translation>
    </message>
    <message>
        <source>Recent projects</source>
        <translation>最近项目</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>项目</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>No recent projects yet. Projects you open or save will appear here.</source>
        <translation>暂无最近项目。打开或保存的项目会显示在这里。</translation>
    </message>
    <message>
        <source>Open selected project</source>
        <translation>打开选中项目</translation>
    </message>
    <message>
        <source>Recent project unavailable</source>
        <translation>最近项目不可用</translation>
    </message>
    <message>
        <source>The selected recent project could not be found:
{path}</source>
        <translation>找不到选中的最近项目：
{path}</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="20"/>
        <source>New EasyGraph Project</source>
        <translation>新建 EasyGraph 项目</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="50"/>
        <source>Choose your first Sheet</source>
        <translation>选择第一个 Sheet</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="57"/>
        <source>Select its chart type, then start with example data or a blank table.</source>
        <translation>选择图表类型，然后使用 Demo 数据或新建空白表。</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="85"/>
        <source>First Sheet type</source>
        <translation>第一个 Sheet 类型</translation>
    </message>
    <message>
        <source>Group supports Box, Violin, and Ridge charts. XY supports scatter and line charts.</source>
        <translation type="vanished">Group 支持 Box、Violin 和 Ridge 图；XY 支持散点图和连线图。</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="129"/>
        <source>Group supports Box, Bar, Violin, and Ridge charts. XY supports points, lines, and combined plots.</source>
        <translation>Group 支持箱线图、柱状图、小提琴图和山脊图；XY 支持点图、折线图及点线组合图。</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="157"/>
        <source>How would you like to begin?</source>
        <translation>如何开始？</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="175"/>
        <source>Open Demo</source>
        <translation>打开 Demo</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="191"/>
        <source>Create Blank</source>
        <translation>新建空白</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="213"/>
        <source>A project file can contain both Group and XY Sheets. This choice only determines the first Sheet.</source>
        <translation>同一个项目文件可以同时包含 Group 和 XY 类型的 Sheet；当前选择只决定第一个 Sheet。</translation>
    </message>
    <message>
        <location filename="../ui/startup_dialog.ui" line="238"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>TableHeaders</name>
    <message>
        <location filename="../src/easygraph/ui/table_controller.py" line="196"/>
        <source>Matches: %1</source>
        <translation>匹配：%1</translation>
    </message>
</context>
<context>
    <name>XYCurveFitDialog</name>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="320"/>
        <source>{count} valid X/Y pairs</source>
        <translation>{count} 组有效的 X/Y 数据</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="326"/>
        <source>Linear</source>
        <translation>线性</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="327"/>
        <source>Quadratic polynomial</source>
        <translation>二次多项式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="328"/>
        <source>Cubic polynomial</source>
        <translation>三次多项式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="329"/>
        <source>Quartic polynomial</source>
        <translation>四次多项式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="330"/>
        <source>Quintic polynomial</source>
        <translation>五次多项式</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="331"/>
        <source>Exponential</source>
        <translation>指数</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="332"/>
        <source>Logarithmic</source>
        <translation>对数</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="333"/>
        <source>Power</source>
        <translation>幂函数</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="334"/>
        <source>Gaussian peak</source>
        <translation>高斯峰</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="335"/>
        <source>Custom equation</source>
        <translation>自定义方程</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="372"/>
        <source>Exponential, e raised to u.</source>
        <translation>指数函数，即 e 的 u 次幂。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="373"/>
        <source>Natural logarithm; u must be positive.</source>
        <translation>自然对数；u 必须为正数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="375"/>
        <source>Logarithm with a custom base; u must be positive, and base must be positive and not equal to 1. The inserted template starts with base 2; replace 2 with another valid value or a parameter.</source>
        <translation>自定义底数的对数；u 必须为正数，base 必须为正数且不能等于 1。插入的模板默认以 2 为底；可将 2 替换为其他有效值或参数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="377"/>
        <source>Base-10 logarithm; u must be positive.</source>
        <translation>以 10 为底的对数；u 必须为正数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="378"/>
        <source>Square root; u must not be negative.</source>
        <translation>平方根；u 不能为负数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="379"/>
        <source>Absolute value.</source>
        <translation>绝对值。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="380"/>
        <source>Sine; input is in radians.</source>
        <translation>正弦函数；输入值以弧度为单位。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="381"/>
        <source>Cosine; input is in radians.</source>
        <translation>余弦函数；输入值以弧度为单位。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="383"/>
        <source>Tangent; input is in radians and the function is undefined where cos(u) is zero.</source>
        <translation>正切函数；输入值以弧度为单位，在 cos(u) 为零处无定义。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="386"/>
        <source>Inverse sine; input must be between -1 and 1, and the result is in radians.</source>
        <translation>反正弦函数；输入值必须介于 -1 和 1 之间，结果以弧度为单位。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="389"/>
        <source>Inverse cosine; input must be between -1 and 1, and the result is in radians.</source>
        <translation>反余弦函数；输入值必须介于 -1 和 1 之间，结果以弧度为单位。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="391"/>
        <source>Inverse tangent; result is in radians.</source>
        <translation>反正切函数；结果以弧度为单位。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="393"/>
        <source>Four-quadrant inverse tangent atan2(u, v): u is the vertical value and v is the horizontal value; the result is in radians.</source>
        <translation>四象限反正切函数 atan2(u, v)：u 为纵向值，v 为横向值；结果以弧度为单位。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="396"/>
        <source>Secant, 1 / cos(u); input is in radians and the function is undefined where cos(u) is zero.</source>
        <translation>正割函数，即 1 / cos(u)；输入值以弧度为单位，在 cos(u) 为零处无定义。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="399"/>
        <source>Cosecant, 1 / sin(u); input is in radians and the function is undefined where sin(u) is zero.</source>
        <translation>余割函数，即 1 / sin(u)；输入值以弧度为单位，在 sin(u) 为零处无定义。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="404"/>
        <source>Hyperbolic sine.</source>
        <translation>双曲正弦函数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="405"/>
        <source>Hyperbolic cosine.</source>
        <translation>双曲余弦函数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="406"/>
        <source>Hyperbolic tangent.</source>
        <translation>双曲正切函数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="648"/>
        <source>{series_count} selected · {point_count} total points</source>
        <translation>已选择 {series_count} 个系列 · 共 {point_count} 个数据点</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="654"/>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="110"/>
        <source>No series selected</source>
        <translation>未选择系列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="684"/>
        <source>Use for data that follows a straight-line trend.</source>
        <translation>适用于呈直线趋势的数据。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="686"/>
        <source>Use for a smooth curve with one bend or turning point.</source>
        <translation>适用于只有一次弯曲或一个转折点的平滑曲线。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="689"/>
        <source>Use for a smooth curve that may have up to two turning points.</source>
        <translation>适用于最多可能有两个转折点的平滑曲线。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="692"/>
        <source>Use for a flexible smooth trend with up to three turning points. Prefer a simpler polynomial when it fits well.</source>
        <translation>适用于最多有三个转折点的灵活平滑趋势。如果较简单的多项式也能很好地拟合，请优先使用较简单的模型。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="695"/>
        <source>Use for a highly flexible smooth trend with up to four turning points. Prefer a simpler polynomial when it fits well.</source>
        <translation>适用于最多有四个转折点的高度灵活平滑趋势。如果较简单的多项式也能很好地拟合，请优先使用较简单的模型。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="698"/>
        <source>Use for growth or decay whose rate changes with the current value.</source>
        <translation>适用于增长或衰减速率随当前数值变化的数据。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="701"/>
        <source>Use for a rapid early change that gradually levels off. X must be positive.</source>
        <translation>适用于前期变化快、随后逐渐趋于平缓的数据。X 必须为正数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="704"/>
        <source>Use for scale relationships such as y changing by a power of x. X must be positive.</source>
        <translation>适用于 y 随 x 的幂次变化等比例关系。X 必须为正数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="706"/>
        <source>Use for a single symmetric peak with a baseline.</source>
        <translation>适用于带基线的单个对称峰。</translation>
    </message>
    <message>
        <source>Enter your own equation. EasyGraph safely identifies parameter names for you.</source>
        <translation type="vanished">输入您自己的方程，EasyGraph 会安全地识别其中的参数名称。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="402"/>
        <source>Cotangent, cos(u) / sin(u); input is in radians and the function is undefined where sin(u) is zero.</source>
        <translation>余切函数，即 cos(u) / sin(u)；输入值以弧度为单位，在 sin(u) 为零处无定义。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="585"/>
        <source>Fit at least one series before choosing displayed parameters.</source>
        <translation>请先完成至少一个数据系列的拟合，再选择要显示的参数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="600"/>
        <source>Updated the parameter values shown on the chart.</source>
        <translation>已更新图中显示的参数值。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="708"/>
        <source>Enter your own equation, including finite sums and numerical integrals. EasyGraph safely identifies parameter names for you.</source>
        <translation>输入自己的方程，包括有限求和与数值积分。EasyGraph 会安全地为你识别参数名称。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="714"/>
        <source>Choose this model when its equation matches the expected curve shape.</source>
        <translation>当此模型的方程符合预期的曲线形状时，请选择它。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="788"/>
        <source>These starting values were estimated from the first selected series. Leave them unchanged to estimate each series independently.</source>
        <translation>这些初始值根据第一个所选系列估算得出。保持不变即可分别为每个系列独立估算。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="826"/>
        <source>No limit</source>
        <translation>无限制</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="864"/>
        <source>y = {expression}</source>
        <translation>y = {expression}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="927"/>
        <source>Enter an equation to identify its parameters automatically.</source>
        <translation>输入方程后，将自动识别其中的参数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="935"/>
        <source>The equation needs attention: {message}</source>
        <translation>请检查方程：{message}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="959"/>
        <source>Detected parameters: {names}</source>
        <translation>识别到的参数：{names}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="965"/>
        <source>This equation has no adjustable parameters.</source>
        <translation>此方程没有可调整的参数。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="983"/>
        <source>Enter a valid number for {label}.</source>
        <translation>请为{label}输入有效数字。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="987"/>
        <source>{label} must be a finite number.</source>
        <translation>{label}必须是有限数值。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1004"/>
        <source>starting value for {name}</source>
        <translation>{name} 的初始值</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1009"/>
        <source>lower bound for {name}</source>
        <translation>{name} 的下限</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1014"/>
        <source>upper bound for {name}</source>
        <translation>{name} 的上限</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1024"/>
        <source>The lower bound for {name} cannot exceed its upper bound.</source>
        <translation>{name} 的下限不能大于上限。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1028"/>
        <source>The starting value for {name} is below its lower bound.</source>
        <translation>{name} 的初始值低于下限。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1032"/>
        <source>The starting value for {name} is above its upper bound.</source>
        <translation>{name} 的初始值高于上限。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1040"/>
        <source>Select at least one data series to continue.</source>
        <translation>请至少选择一个数据系列以继续。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1046"/>
        <source>Correct the custom equation before previewing or fitting.</source>
        <translation>请先修正自定义方程，再预览或拟合。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1076"/>
        <source>Cannot continue: {message}</source>
        <translation>无法继续：{message}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1098"/>
        <source>Preview unavailable: {message}</source>
        <translation>无法预览：{message}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1104"/>
        <source>Starting-curve preview requested for {count} series.</source>
        <translation>已请求预览 {count} 个系列的初始曲线。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1137"/>
        <source>Fitting {count} series in the background…</source>
        <translation>正在后台拟合 {count} 个系列…</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1201"/>
        <source>{successes} fit(s) succeeded; {failed} failed. Review the status below, then adjust starting values or bounds.</source>
        <translation>{successes} 个拟合成功，{failed} 个失败。请查看下方状态，然后调整初始值或边界。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1207"/>
        <source>Fit complete for {count} series. Review the results, then apply.</source>
        <translation>已完成 {count} 个系列的拟合。请检查结果，然后应用。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1226"/>
        <source>The fit could not run: {message} Check the data, equation, starting values, and bounds.</source>
        <translation>无法进行拟合：{message} 请检查数据、方程、初始值和边界。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1227"/>
        <source>Unknown fitting error.</source>
        <translation>未知的拟合错误。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1247"/>
        <source>Marked {count} fit(s) for removal. Choose Apply to confirm.</source>
        <translation>已将 {count} 个拟合标记为待移除。请选择“应用”进行确认。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1252"/>
        <source>The selected series do not have saved fits to remove.</source>
        <translation>所选系列没有可移除的已保存拟合。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1292"/>
        <source>Show or hide this fit&apos;s chart annotation. This does not run the fit again.</source>
        <translation>显示或隐藏此拟合的图中标注；该操作不会重新拟合。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1299"/>
        <source>Run a successful fit before displaying its annotation.</source>
        <translation>请先成功完成拟合，再显示其标注。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1306"/>
        <source>Failed</source>
        <translation>失败</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1309"/>
        <source>Saved</source>
        <translation>已保存</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1310"/>
        <source>No result is available in this session.</source>
        <translation>本次操作中没有可用结果。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1312"/>
        <source>Fitted</source>
        <translation>拟合完成</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1315"/>
        <source>Needs attention</source>
        <translation>需要检查</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1405"/>
        <source>Series: {series} · Model: {model}</source>
        <translation>系列：{series} · 模型：{model}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1411"/>
        <source>Fit failed: {message}</source>
        <translation>拟合失败：{message}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1417"/>
        <source>No numerical result is available in this session. Run the fit to review full statistics.</source>
        <translation>当前会话中没有可用的数值结果。请运行拟合以查看完整统计信息。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1429"/>
        <source>Equation: {equation}</source>
        <translation>方程：{equation}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1432"/>
        <source>Fit quality: R² = {r_squared} · Adjusted R² = {adjusted_r_squared} · RMSE = {rmse} · SSE = {sse}</source>
        <translation>拟合质量：R² = {r_squared} · 调整后 R² = {adjusted_r_squared} · RMSE = {rmse} · SSE = {sse}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1445"/>
        <source>Data used: {observations} points · {parameters} fitted parameter(s) · {degrees_of_freedom} degrees of freedom</source>
        <translation>使用的数据：{observations} 个数据点 · {parameters} 个拟合参数 · {degrees_of_freedom} 个自由度</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1456"/>
        <source>Parameter uncertainty:</source>
        <translation>参数不确定性：</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1460"/>
        <source>not available</source>
        <translation>暂不可用</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1468"/>
        <source>fixed</source>
        <translation>已固定</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1470"/>
        <source>at a bound</source>
        <translation>已达到边界</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1474"/>
        <source>  {name} = {value} · standard error = {standard_error} · 95% CI = {confidence_interval}{notes}</source>
        <translation>  {name} = {value} · 标准误 = {standard_error} · 95% 置信区间 = {confidence_interval}{notes}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1489"/>
        <source>Warnings:</source>
        <translation>警告：</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1492"/>
        <source>Warnings: none.</source>
        <translation>警告：无。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1495"/>
        <source>Fit status: {message}</source>
        <translation>拟合状态：{message}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_curve_fit_dialog.py" line="1500"/>
        <source>Wait for the current fit to finish.</source>
        <translation>请等待当前拟合完成。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="6"/>
        <source>Curve Fit</source>
        <translation>曲线拟合</translation>
    </message>
    <message>
        <source>Choose one or more series. EasyGraph fits each series independently with the same model and settings.</source>
        <translation type="vanished">请选择一个或多个系列。EasyGraph 将使用相同的模型和设置，分别拟合每个系列。</translation>
    </message>
    <message>
        <source>1. Data series</source>
        <translation type="vanished">1. 数据系列</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="81"/>
        <source>Select All</source>
        <translation>全选</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="88"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="97"/>
        <source>Checked series will be fitted independently.</source>
        <translation>将分别拟合勾选的各个系列。</translation>
    </message>
    <message>
        <source>2. Model and starting values</source>
        <translation type="vanished">2. 模型和初始值</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="183"/>
        <source>Curve model</source>
        <translation>曲线模型</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="190"/>
        <source>Choose the shape that best describes your data.</source>
        <translation>请选择最符合数据形状的模型。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="197"/>
        <source>Equation</source>
        <translation>方程</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="210"/>
        <source>—</source>
        <translation>—</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="225"/>
        <source>Select a model to see when to use it.</source>
        <translation>选择模型后可查看其适用情况。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="252"/>
        <source>y =</source>
        <translation>y =</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="259"/>
        <source>a * exp(-k * x) + c</source>
        <translation>a * exp(-k * x) + c</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="273"/>
        <source>Insert template</source>
        <translation>插入模板</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="280"/>
        <source>Insert an inclusive finite-sum template.</source>
        <translation>插入包含上下限的有限求和模板。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="283"/>
        <source>Σ Sum</source>
        <translation>Σ 求和</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="290"/>
        <source>Insert a numerical-integral template.</source>
        <translation>插入数值积分模板。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="293"/>
        <source>∫ Integral</source>
        <translation>∫ 积分</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="317"/>
        <source>Function</source>
        <translation>函数</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="337"/>
        <source>Wrap the selected expression with this function, or insert a placeholder.</source>
        <translation>使用此函数包裹选中的表达式，或插入占位表达式。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="340"/>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="324"/>
        <source>Choose a function to insert. ln(u) is the natural logarithm, log(u, base) uses a custom base, and log10(u) uses base 10. The log template starts with base 2; replace 2 with any positive value other than 1, or with a parameter. Trigonometric inputs and inverse-trigonometric results use radians.</source>
        <translation>选择要插入的函数。ln(u) 为自然对数，log(u, base) 使用自定义底数，log10(u) 以 10 为底。log 模板默认以 2 为底；可将 2 替换为除 1 以外的任意正数或参数。三角函数的输入值和反三角函数的结果均以弧度为单位。</translation>
    </message>
    <message>
        <source>Choose the series to fit on the left. Chart annotations are controlled independently in the fit results.</source>
        <translation type="vanished">在左侧选择本次要拟合的数据系列；图中标注由拟合结果独立控制。</translation>
    </message>
    <message>
        <source>1. Series to fit</source>
        <translation type="vanished">1. 本次拟合对象</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="362"/>
        <source>Use x for the horizontal axis; other names become parameters automatically. Functions include exp, ln, log(u, base), log10, sqrt, and abs; sin, cos, tan, asin, acos, atan, atan2, sec, csc, and cot; and sinh, cosh, and tanh. ln(u) is the natural logarithm, log(u, base) uses a custom base, and log10(u) uses base 10. For logarithms, u must be positive; a custom base must also be positive and not equal to 1. The log template starts with base 2; replace 2 with another valid value or a parameter name. Trigonometric angles and inverse-trigonometric results use radians. Σ(k, 1, 5, expression) is an inclusive finite sum. ∫(t, 0, x, expression), or integral(t, 0, x, expression), is evaluated numerically.</source>
        <translation>使用 x 表示横轴；其他名称会自动成为参数。函数包括 exp、ln、log(u, base)、log10、sqrt 和 abs；sin、cos、tan、asin、acos、atan、atan2、sec、csc 和 cot；以及 sinh、cosh 和 tanh。ln(u) 为自然对数，log(u, base) 使用自定义底数，log10(u) 以 10 为底。对数函数的 u 必须为正数；自定义底数也必须为正数且不能等于 1。log 模板默认以 2 为底；可将 2 替换为其他有效值或参数名。三角函数的角度和反三角函数的结果均以弧度为单位。Σ(k, 1, 5, expression) 表示包含上下限的有限求和。∫(t, 0, x, expression) 或 integral(t, 0, x, expression) 通过数值方法计算。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="387"/>
        <source>Starting values help nonlinear fitting converge. Leave a bound empty for no limit.</source>
        <translation>初始值有助于非线性拟合收敛。边界留空表示不限制。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="400"/>
        <source>Parameter</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="405"/>
        <source>Starting value</source>
        <translation>初始值</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="410"/>
        <source>Lower bound</source>
        <translation>下限</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="415"/>
        <source>Upper bound</source>
        <translation>上限</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="420"/>
        <source>Fixed</source>
        <translation>固定</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="428"/>
        <source>EasyGraph supplies starting values automatically. Edit them only when the initial curve is far from your data.</source>
        <translation>EasyGraph 会自动提供初始值。仅当初始曲线与数据相差较大时才需要修改。</translation>
    </message>
    <message>
        <source>Draw the fitted equation on the chart using rounded parameter values. Full-precision values remain available in the fit results. The equation is omitted when its ordinary-X coefficients cannot be displayed reliably.</source>
        <translation type="vanished">使用适当舍入的参数值在图中绘制拟合方程。完整精度仍可在拟合结果中查看。如果系数在当前 X 数值范围下无法可靠显示，图中将省略该方程，以免误导。</translation>
    </message>
    <message>
        <source>Show fitted equation on chart</source>
        <translation type="vanished">在图中显示拟合方程</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="453"/>
        <source>Show the curve produced by the current starting values without fitting.</source>
        <translation>无需拟合，直接显示当前初始值生成的曲线。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="456"/>
        <source>Preview Starting Curve</source>
        <translation>预览初始曲线</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="463"/>
        <source>Fit Selected Series</source>
        <translation>拟合所选系列</translation>
    </message>
    <message>
        <source>3. Fit results</source>
        <translation type="vanished">3. 拟合结果</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="21"/>
        <source>Choose the fit targets, model, and starting values in Fit setup. Chart annotations are controlled independently in Fit results.</source>
        <translation>请在“拟合设置”中选择拟合对象、模型和初始值；图表标注在“拟合结果”中独立控制。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="44"/>
        <source>1. Fit setup</source>
        <translation>1. 拟合设置</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="72"/>
        <source>Series to fit</source>
        <translation>本次拟合对象</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="175"/>
        <source>Model and starting values</source>
        <translation>模型和初始值</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="490"/>
        <source>2. Fit results</source>
        <translation>2. 拟合结果</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="498"/>
        <source>Chart annotation</source>
        <translation>图中标注</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="505"/>
        <source>Show the fitted equation for every result whose Display switch is on.</source>
        <translation>为已开启“显示”开关的每条结果显示拟合公式。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="508"/>
        <source>Fitted equation</source>
        <translation>拟合公式</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="518"/>
        <source>Show selected fitted parameter values for every result whose Display switch is on.</source>
        <translation>为已开启“显示”开关的每条结果显示所选拟合参数值。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="521"/>
        <source>Parameter values</source>
        <translation>参数值</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="528"/>
        <source>Choose which fitted parameters are shown for each result.</source>
        <translation>选择每条拟合结果要显示的参数。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="531"/>
        <source>Parameter Display Settings…</source>
        <translation>参数显示设置…</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="555"/>
        <source>Ready to fit.</source>
        <translation>已准备好进行拟合。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="611"/>
        <source>Display</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="616"/>
        <source>Series</source>
        <translation>系列</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="621"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="626"/>
        <source>R²</source>
        <translation>R²</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="631"/>
        <source>RMSE</source>
        <translation>RMSE</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="636"/>
        <source>Parameters</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="644"/>
        <source>Selected fit details</source>
        <translation>选中拟合的详情</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="647"/>
        <source>R² closer to 1 and smaller error values generally indicate a closer fit. Confidence intervals summarize parameter uncertainty.</source>
        <translation>R² 越接近 1 且误差越小，通常表示拟合越接近数据。置信区间用于概括参数的不确定性。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="666"/>
        <source>Select a result row to review fit quality and parameter uncertainty.</source>
        <translation>选择结果行以查看拟合质量和参数不确定性。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="669"/>
        <source>Select a fitted row to see full statistics.</source>
        <translation>选择已拟合的结果行以查看完整统计信息。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="688"/>
        <source>Remove saved fits from the checked series when you apply.</source>
        <translation>应用时移除勾选系列中已保存的拟合。</translation>
    </message>
    <message>
        <location filename="../ui/xy_curve_fit_dialog.ui" line="691"/>
        <source>Remove Fit</source>
        <translation>移除拟合</translation>
    </message>
</context>
<context>
    <name>XYFitParameterDisplayDialog</name>
    <message>
        <location filename="../src/easygraph/ui/xy_fit_parameter_display_dialog.py" line="128"/>
        <source>Select at least one parameter for every fit result. Missing: {series}</source>
        <translation>请为每条拟合结果至少选择一个参数。尚未选择：{series}</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="6"/>
        <source>Parameter Display Settings</source>
        <translation>参数显示设置</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="21"/>
        <source>Choose the fitted parameters to show on the chart for each result. The fit-results table always keeps every parameter available for comparison.</source>
        <translation>选择每条拟合结果要在图中显示的参数。拟合结果表始终保留全部参数，方便比较。</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="44"/>
        <source>Show</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="49"/>
        <source>Fit result</source>
        <translation>拟合结果</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="54"/>
        <source>Parameter</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="59"/>
        <source>Current value</source>
        <translation>当前值</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="69"/>
        <source>Clear All</source>
        <translation>全部清除</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="76"/>
        <source>Restore all fitted parameters for every result.</source>
        <translation>恢复为显示每条结果的全部拟合参数。</translation>
    </message>
    <message>
        <location filename="../ui/xy_fit_parameter_display_dialog.ui" line="79"/>
        <source>Restore Defaults</source>
        <translation>恢复默认</translation>
    </message>
</context>
<context>
    <name>XYSeriesDialog</name>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="6"/>
        <source>Series Setup</source>
        <translation>系列设置</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="21"/>
        <source>Set a default X, then override X or display options only for series that need it.</source>
        <translation>先设置默认 X，再仅为需要的系列覆盖 X 或显示选项。</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="33"/>
        <source>Default X</source>
        <translation>默认 X</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="43"/>
        <source>Use Shared X</source>
        <translation>使用共享 X</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="50"/>
        <source>Use Adjacent XY Pairs</source>
        <translation>使用相邻 XY 对</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="70"/>
        <source>No series</source>
        <translation>无系列</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="92"/>
        <source>Visible</source>
        <translation>可见</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="97"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="102"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="107"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="112"/>
        <source>Valid rows</source>
        <translation>有效行</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="117"/>
        <source>Points</source>
        <translation>点</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="122"/>
        <source>Line</source>
        <translation>线</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="132"/>
        <source>+ Series</source>
        <translation>+ 系列</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="139"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="146"/>
        <source>Move Up</source>
        <translation>上移</translation>
    </message>
    <message>
        <location filename="../ui/xy_series_dialog.ui" line="153"/>
        <source>Move Down</source>
        <translation>下移</translation>
    </message>
</context>
<context>
    <name>controller.dialog</name>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="434"/>
        <source>Invalid series setup</source>
        <translation>系列设置无效</translation>
    </message>
</context>
<context>
    <name>parent</name>
    <message>
        <source>Import Excel Sheets</source>
        <translation type="vanished">导入 Excel 工作表</translation>
    </message>
    <message>
        <source>Select the worksheets to import. Each worksheet becomes an EasyGraph sheet.</source>
        <translation type="vanished">请选择要导入的工作表。每个工作表都会成为一个 EasyGraph 工作表。</translation>
    </message>
    <message>
        <source>{name}  —  {rows} rows × {columns} columns</source>
        <translation type="vanished">{name}  —  {rows} 行 × {columns} 列</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="47"/>
        <source>Shared X — first column is X, remaining columns are Y</source>
        <translation>共享 X — 第一列为 X，其余列为 Y</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="48"/>
        <source>Adjacent XY — pair columns as XY, XY, …</source>
        <translation>相邻 XY — 按 XY、XY… 将相邻列配对</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="49"/>
        <source>Custom — open Series Setup</source>
        <translation>自定义 — 打开系列设置</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="53"/>
        <source>XY Mapping</source>
        <translation>XY 映射</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="54"/>
        <source>How should these columns be mapped?</source>
        <translation>这些列应如何映射？</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="99"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Overlay: {name}</source>
        <translation type="vanished">叠加线：{name}</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">重置</translation>
    </message>
</context>
<context>
    <name>self.dialog</name>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="134"/>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="135"/>
        <source>Show</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="136"/>
        <source>Hide</source>
        <translation>隐藏</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="144"/>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="198"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="146"/>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="203"/>
        <source>Use default ({name})</source>
        <translation>使用默认值（{name}）</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="225"/>
        <source>Series {number}</source>
        <translation>系列 {number}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="280"/>
        <source>Every series must have an X column.</source>
        <translation>每个系列都必须指定 X 列。</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="297"/>
        <source>Invalid mapping</source>
        <translation>映射无效</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="300"/>
        <source>{count} series · {mode}</source>
        <translation>{count} 个系列 · {mode}</translation>
    </message>
    <message>
        <location filename="../src/easygraph/ui/xy_series_dialog.py" line="353"/>
        <source>{count} unused column</source>
        <translation>{count} 个未使用列</translation>
    </message>
</context>
<context>
    <name>StatisticFormatDialog</name>
    <message>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>恢复默认</translation>
    </message>
    <message>
        <source>Statistic Number Formats</source>
        <translation>统计类型数值格式</translation>
    </message>
    <message>
        <source>Applies to this sheet's analysis results and copied statistics.</source>
        <translation>应用于当前工作表的分析结果及复制的统计数据。</translation>
    </message>
    <message>
        <source>Applies to this sheet's statistic labels and in-chart statistics table.</source>
        <translation>应用于当前工作表的统计数据标签和图内统计表。</translation>
    </message>
    <message>
        <source>Unchecked rows use the default: {decimals} decimal places, {notation}.</source>
        <translation>未勾选的统计类型沿用默认格式：{decimals} 位小数，{notation}。</translation>
    </message>
    <message>
        <source>scientific notation</source>
        <translation>科学计数法</translation>
    </message>
    <message>
        <source>decimal notation</source>
        <translation>普通小数</translation>
    </message>
    <message>
        <source>Statistic</source>
        <translation>统计类型</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>单独设置</translation>
    </message>
    <message>
        <source>Decimals</source>
        <translation>小数位数</translation>
    </message>
    <message>
        <source>Notation</source>
        <translation>显示方式</translation>
    </message>
    <message>
        <source>Trim zeros</source>
        <translation>去掉末尾零</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Override {statistic} format</source>
        <translation>单独设置 {statistic} 格式</translation>
    </message>
    <message>
        <source>Decimal</source>
        <translation>普通小数</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>科学计数法</translation>
    </message>
    <message>
        <source>Trim trailing zeros for {statistic}</source>
        <translation>去掉 {statistic} 小数末尾的零</translation>
    </message>
    <message>
        <source>Preview value: 1234.5. Sample size is always displayed as an integer.</source>
        <translation>预览数值：1234.5。样本量（Sample）始终显示为整数。</translation>
    </message>
</context>
<context>
    <name>SharedGroupsDialog</name>
    <message>
        <source>Add shared groups</source>
        <translation>添加共享子组</translation>
    </message>
    <message>
        <source>Parent names (one per line)</source>
        <translation>一级分组名称（每行一个）</translation>
    </message>
    <message>
        <source>Shared subgroup names (one per line)</source>
        <translation>共享子组名称（每行一个）</translation>
    </message>
    <message>
        <source>Enter at least one parent and one subgroup.</source>
        <translation>请至少输入一个一级分组和一个子组。</translation>
    </message>
    <message>
        <source>Create parent groups in bulk</source>
        <translation>批量创建一级分组</translation>
    </message>
</context>
<context>
    <name>GroupDisplayDialog</name>
    <message>
        <source>Grouping settings</source>
        <translation>分组设置</translation>
    </message>
    <message>
        <source>Share matching subgroup names and colors</source>
        <translation>共享同名子组的名称和颜色</translation>
    </message>
    <message>
        <source>Within-group spacing</source>
        <translation>组内间距</translation>
    </message>
    <message>
        <source>Between-group spacing</source>
        <translation>一级组间距</translation>
    </message>
    <message>
        <source>Both levels</source>
        <translation>显示两级标签</translation>
    </message>
    <message>
        <source>Subgroup names in legend only</source>
        <translation>子组名称仅显示在图例</translation>
    </message>
    <message>
        <source>Labels</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>By subgroup</source>
        <translation>按子组</translation>
    </message>
    <message>
        <source>By parent group</source>
        <translation>按一级分组</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>颜色</translation>
    </message>
</context>
<context>
    <name>GroupingControls</name>
    <message>
        <source>Create parent group...</source>
        <translation>建立一级分组…</translation>
    </message>
    <message>
        <source>Create parent group</source>
        <translation>建立一级分组</translation>
    </message>
    <message>
        <source>Parent name</source>
        <translation>一级分组名称</translation>
    </message>
    <message>
        <source>Insert subgroup left</source>
        <translation>向左插入子组</translation>
    </message>
    <message>
        <source>Insert subgroup right</source>
        <translation>向右插入子组</translation>
    </message>
    <message>
        <source>Add shared groups...</source>
        <translation>添加共享子组…</translation>
    </message>
    <message>
        <source>Grouping settings...</source>
        <translation>分组设置…</translation>
    </message>
    <message>
        <source>Rename parent group</source>
        <translation>重命名一级分组</translation>
    </message>
    <message>
        <source>Rename parent group...</source>
        <translation>重命名一级分组…</translation>
    </message>
    <message>
        <source>Remove parent group</source>
        <translation>解除一级分组</translation>
    </message>
    <message>
        <source>Merge parent headers...</source>
        <translation>合并一级表头…</translation>
    </message>
    <message>
        <source>Merge parent headers</source>
        <translation>合并一级表头</translation>
    </message>
    <message>
        <source>Unmerge parent headers</source>
        <translation>取消合并一级表头</translation>
    </message>
    <message>
        <source>Rename parent header...</source>
        <translation>重命名一级表头…</translation>
    </message>
    <message>
        <source>Insert parent group left...</source>
        <translation>向左插入一级分组…</translation>
    </message>
    <message>
        <source>Insert parent group right...</source>
        <translation>向右插入一级分组…</translation>
    </message>
    <message>
        <source>Insert parent group</source>
        <translation>插入一级分组</translation>
    </message>
    <message>
        <source>Create parent groups in bulk...</source>
        <translation>批量创建一级分组…</translation>
    </message>
    <message>
        <source>Parent: {name} ({count} columns)</source>
        <translation>一级组：{name}（{count} 列）</translation>
    </message>
    <message>
        <source>Selected {count} columns</source>
        <translation>已选 {count} 列</translation>
    </message>
    <message>
        <source>Select parent headers or columns</source>
        <translation>请选择一级表头或列</translation>
    </message>
    <message>
        <source>Select adjacent parent header cells to merge.</source>
        <translation>请选择相邻的一级表头以合并。</translation>
    </message>
    <message>
        <source>Keep subgroup names and all data.</source>
        <translation>保留子组名称和全部数据。</translation>
    </message>
    <message>
        <source>Parent headers</source>
        <translation>一级表头</translation>
    </message>
</context>
<context>
    <name>TableToolsController</name>
    <message>
        <source>Insert column left</source>
        <translation>向左插入列</translation>
    </message>
    <message>
        <source>Insert column right</source>
        <translation>向右插入列</translation>
    </message>
    <message>
        <source>In paired XY tables, insert a complete X/Y pair.</source>
        <translation>在成对 XY 表中插入完整的一对 X/Y 列。</translation>
    </message>
</context>
<context>
    <name>TopToolbar</name>
    <message>
        <source>Merge</source>
        <translation>合并</translation>
    </message>
    <message>
        <source>Unmerge</source>
        <translation>取消合并</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <source>Insert left</source>
        <translation>向左插入</translation>
    </message>
    <message>
        <source>Insert right</source>
        <translation>向右插入</translation>
    </message>
    <message>
        <source>Create groups…</source>
        <translation>批量创建…</translation>
    </message>
</context>
<context>
    <name>GroupedOrderDialog</name>
    <message>
        <source>Edit Group Order</source>
        <translation>编辑分组顺序</translation>
    </message>
    <message>
        <source>Reorder whole groups on the left, or columns within a group on the right. The table and group membership stay unchanged.</source>
        <translation>左侧调整一级组和未分组列的顺序，右侧调整组内子组顺序。仅影响绘图，不改变表格和分组归属。</translation>
    </message>
    <message>
        <source>Groups and ungrouped columns</source>
        <translation>一级组与未分组列</translation>
    </message>
    <message>
        <source>Drag to reorder, or select items and use the buttons.</source>
        <translation>拖动项目，或选中后使用下方按钮调整。支持多选。</translation>
    </message>
    <message>
        <source>Move up</source>
        <translation>上移</translation>
    </message>
    <message>
        <source>Move down</source>
        <translation>下移</translation>
    </message>
    <message>
        <source>Within selected group</source>
        <translation>所选一级组内的顺序</translation>
    </message>
    <message>
        <source>Select one parent group to reorder its columns.</source>
        <translation>请选择一个一级组，以调整组内子组顺序。</translation>
    </message>
    <message>
        <source>Columns within the selected group</source>
        <translation>所选一级组内的子组</translation>
    </message>
    <message>
        <source>Table Order</source>
        <translation>恢复表格顺序</translation>
    </message>
</context>
<context>
    <name>GroupedOrderDialogController</name>
    <message>
        <source>{name} ({number})</source>
        <translation>{name}（{number}）</translation>
    </message>
    <message>
        <source>Group: {name}</source>
        <translation>一级组：{name}</translation>
    </message>
    <message>
        <source>{count} columns: {names}</source>
        <translation>{count} 个子组：{names}</translation>
    </message>
    <message>
        <source>Ungrouped: {name}</source>
        <translation>未分组：{name}</translation>
    </message>
    <message>
        <source>This column has no parent group. Move it in the left list.</source>
        <translation>此列没有一级分组，请在左侧调整顺序。</translation>
    </message>
    <message>
        <source>Select one parent group to reorder its columns.</source>
        <translation>请选择一个一级组，以调整组内子组顺序。</translation>
    </message>
    <message>
        <source>Columns in {name}</source>
        <translation>{name} 的子组</translation>
    </message>
</context>
</TS>
