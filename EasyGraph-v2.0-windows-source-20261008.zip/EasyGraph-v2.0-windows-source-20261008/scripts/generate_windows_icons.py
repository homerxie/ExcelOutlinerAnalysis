from __future__ import annotations

from pathlib import Path

from PIL import Image


PROJECT_ROOT = Path(__file__).resolve().parents[1]
ICON_SIZES = (16, 32, 64, 128, 256, 512, 1024)
ICO_SIZES = tuple((size, size) for size in (16, 20, 24, 32, 40, 48, 64, 128, 256))


def cropped_master(theme: str) -> Image.Image:
    source = (
        PROJECT_ROOT
        / "icon"
        / theme
        / "png"
        / f"EasyGraph_{theme}_1024x1024.png"
    )
    with Image.open(source) as image:
        rgba = image.convert("RGBA")
    alpha_bounds = rgba.getchannel("A").getbbox()
    if alpha_bounds is None:
        raise ValueError(f"Icon has no visible pixels: {source}")
    width = alpha_bounds[2] - alpha_bounds[0]
    height = alpha_bounds[3] - alpha_bounds[1]
    if width != height:
        raise ValueError(f"Icon alpha bounds must be square: {source} {alpha_bounds}")
    return rgba.crop(alpha_bounds)


def generate_windows_icons() -> None:
    masters: dict[str, Image.Image] = {}
    for theme in ("dark", "light"):
        master = cropped_master(theme)
        masters[theme] = master
        output_dir = PROJECT_ROOT / "icon" / "windows" / theme / "png"
        output_dir.mkdir(parents=True, exist_ok=True)
        for size in ICON_SIZES:
            output = output_dir / f"EasyGraph_{theme}_{size}x{size}.png"
            master.resize((size, size), Image.Resampling.LANCZOS).save(output)

    ico_path = PROJECT_ROOT / "icon" / "windows" / "EasyGraph.ico"
    ico_path.parent.mkdir(parents=True, exist_ok=True)
    masters["dark"].save(ico_path, format="ICO", sizes=ICO_SIZES)


if __name__ == "__main__":
    generate_windows_icons()
