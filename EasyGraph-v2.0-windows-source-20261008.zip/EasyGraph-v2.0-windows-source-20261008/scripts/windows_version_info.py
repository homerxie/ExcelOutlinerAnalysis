# UTF-8
# This file is consumed by PyInstaller's --version-file option on Windows.
VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=(2, 0, 0, 0),
    prodvers=(2, 0, 0, 0),
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
  ),
  kids=[
    StringFileInfo([
      StringTable(
        u'040904B0',
        [
          StringStruct(u'CompanyName', u'EasyGraph'),
          StringStruct(u'FileDescription', u'EasyGraph v2.0'),
          StringStruct(u'FileVersion', u'2.0.0.0'),
          StringStruct(u'InternalName', u'EasyGraph'),
          StringStruct(u'OriginalFilename', u'EasyGraph.exe'),
          StringStruct(u'ProductName', u'EasyGraph'),
          StringStruct(u'ProductVersion', u'2.0'),
        ]
      )
    ]),
    VarFileInfo([VarStruct(u'Translation', [1033, 1200])])
  ]
)
