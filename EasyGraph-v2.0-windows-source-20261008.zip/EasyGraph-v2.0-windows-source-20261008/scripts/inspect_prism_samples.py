"""Print a deterministic, read-only inventory of local PZFX regression samples."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from easygraph.prism_io import PrismImportError, inspect_pzfx  # noqa: E402


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def inspect_directory(directory: Path) -> dict:
    samples = []
    for path in sorted(directory.glob("*.pzfx"), key=lambda item: item.name.casefold()):
        record = {
            "file": path.name,
            "bytes": path.stat().st_size,
            "sha256": file_sha256(path),
        }
        try:
            project = inspect_pzfx(path)
            record.update(
                {
                    "status": "ok",
                    "xml_version": project.xml_version,
                    "created_by_version": project.created_by_version,
                    "warnings": [warning.code for warning in project.warnings],
                    "tables": [
                        {
                            "id": table.id,
                            "title": table.title,
                            "table_type": table.table_type,
                            "ext_table_type": table.ext_table_type,
                            "y_format": table.y_format,
                            "kind": table.kind.value,
                            "supported": table.supported,
                            "unsupported_reason": table.unsupported_reason,
                        }
                        for table in project.tables
                    ],
                }
            )
        except PrismImportError as exc:
            record.update(
                {
                    "status": "error",
                    "error_code": exc.code,
                    "error": str(exc),
                }
            )
        samples.append(record)
    return {
        "schema": 1,
        "directory": str(directory.resolve()),
        "samples": samples,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--directory",
        type=Path,
        default=ROOT / "demo" / "prism_samples",
        help="Directory containing local .pzfx files.",
    )
    args = parser.parse_args()
    print(json.dumps(inspect_directory(args.directory), ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
