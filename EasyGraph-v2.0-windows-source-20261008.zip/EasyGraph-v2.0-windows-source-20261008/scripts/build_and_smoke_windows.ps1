$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Python = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
$PyInstaller = Join-Path $ProjectRoot ".venv\Scripts\pyinstaller.exe"
$Executable = Join-Path $ProjectRoot "dist\EasyGraph\EasyGraph.exe"
$BundledProjectIcon = Join-Path $ProjectRoot "dist\EasyGraph\_internal\icon\windows\project\EasyGraph_Project_Icon_Windows.ico"
$SmokeDir = Join-Path $ProjectRoot "dist\packaging-smoke"

if (-not (Test-Path $Python)) {
    throw "Missing Windows virtual environment: $Python"
}
if (-not (Test-Path $PyInstaller)) {
    throw "PyInstaller is not installed. Install requirements-windows.txt first."
}

Push-Location $ProjectRoot
try {
    & $PyInstaller `
        --noconfirm `
        --clean `
        --name EasyGraph `
        --windowed `
        --onedir `
        --version-file "scripts\windows_version_info.py" `
        --icon "icon\windows\EasyGraph.ico" `
        --add-data "icon\windows\dark\png;icon\windows\dark\png" `
        --add-data "icon\windows\light\png;icon\windows\light\png" `
        --add-data "icon\EasyGraph_Project_Icon_Pack\EasyGraph_Project_Icon_Windows.ico;icon\windows\project" `
        --add-data "translations;translations" `
        --add-data "icon\tabler;icon\tabler" `
        --add-data "icon\lucide;icon\lucide" `
        --add-data "template;template" `
        --add-data "src\palette_cache.json;src" `
        --hidden-import easygraph.packaging_smoke `
        --hidden-import easygraph.plotting.canvas `
        --hidden-import seaborn `
        --hidden-import scipy.stats `
        --hidden-import scipy.ndimage `
        --hidden-import scipy.optimize `
        --hidden-import matplotlib.backends.backend_svg `
        --hidden-import matplotlib.backends.backend_pdf `
        src\app.py
    if ($LASTEXITCODE -ne 0) {
        throw "PyInstaller failed with exit code $LASTEXITCODE"
    }
    if (-not (Test-Path $BundledProjectIcon)) {
        throw "Packaged project icon is missing: $BundledProjectIcon"
    }

    if (Test-Path $SmokeDir) {
        Remove-Item $SmokeDir -Recurse -Force
    }
    New-Item -ItemType Directory -Path $SmokeDir -Force | Out-Null
    $env:QT_QPA_PLATFORM = "offscreen"
    $env:EASYGRAPH_PACKAGING_SMOKE_DIR = $SmokeDir
    $Process = Start-Process -FilePath $Executable -Wait -PassThru
    if ($Process.ExitCode -ne 0) {
        throw "Packaged EasyGraph smoke process failed with exit code $($Process.ExitCode)"
    }

    $ReportPath = Join-Path $SmokeDir "packaging-smoke.json"
    if (-not (Test-Path $ReportPath)) {
        throw "Packaged smoke report was not created: $ReportPath"
    }
    $Report = Get-Content $ReportPath -Raw | ConvertFrom-Json
    if ($Report.status -ne "ok" -or -not $Report.frozen) {
        throw "Packaged smoke report did not pass: $ReportPath"
    }

    Write-Host "Windows packaged smoke passed: $ReportPath"
}
finally {
    Remove-Item Env:EASYGRAPH_PACKAGING_SMOKE_DIR -ErrorAction SilentlyContinue
    Remove-Item Env:QT_QPA_PLATFORM -ErrorAction SilentlyContinue
    Pop-Location
}
