# GraphPad Prism PZFX 原始数据导入实施计划

状态：PZFX 首个里程碑已实施（2026-07-16）；Prism 8 实样和转换文件兼容性已补验（2026-07-21）；`.prism` 归档仍为后续里程碑

## 目标

为 EasyGraph 增加统一的 GraphPad Prism PZFX 导入入口，把 Prism 8–11 的普通 Column 和 Grouped 原始数据转换为当前宽表模型。

首个里程碑只读取 `.pzfx`。它不导入 Prism 分析结果、图形、布局、统计设置或样式，也不回写 PZFX。Prism 10/11 的 `.prism` ZIP 类归档作为后续独立里程碑，避免两种容器格式同时增加首版风险。

## 版本假设与保护策略

### 已验证事实

- Prism 9.5、10.3、11.0 生成的 Column/Grouped 样例都声明 `PrismXMLVersion="5.00"`。
- 三个版本的 Grouped 原始数据子树逐字节一致。
- 三个版本的 Column 标题、数值和节点层级一致；Prism 9 与 10/11 仅存在 `YColumn Width` 之类显示属性差异。
- Prism 8.2 Column/Grouped 实样同样声明 `PrismXMLVersion="5.00"`，并符合与 Prism 9/10/11 相同的数据节点结构。
- Prism 8 Column 经 Prism 9 另存后可以出现空 `OriginalVersion` 和非空 `MostRecentVersion`；当前文件结构的版本判断必须以后者为准。
- PZFX 是否带默认命名空间与 Prism 主版本不是一一对应关系，解析器必须同时兼容有命名空间和无命名空间文件。

### Prism 8 验证结论

早期实现按以下契约假设支持 Prism 8，现已由本地 Column/Grouped 实样验证：

- Column 使用 `TableType="OneWay"`，没有改变含义的 `ExtTableType`，数据为 `YColumn/Subcolumn/d`。
- Grouped 使用 `TableType="TwoWay"`、`YFormat="replicates"`，行因素来自 `RowTitlesColumn`，原始重复值来自每个 `YColumn` 的多个 `Subcolumn`。
- 根节点仍为 `GraphPadPrismFile`，`PrismXMLVersion="5.00"`。

实样验证不放宽结构校验。如果后续文件不满足上述契约，导入器仍必须停止并报告不匹配节点、表型和版本，不得猜测式展平数据。

### 版本判断原则

- 不为 Prism 8、9、10、11 分别编写解析器。
- 优先读取 `MostRecentVersion@CreatedByVersion`；仅在其缺失或为空时回退到 `OriginalVersion`。版本只用于来源诊断和受支持版本保护，不决定数据节点的读取方式。
- 先判断 `ExtTableType`，再判断 `TableType` 和 `YFormat`。
- `PrismXMLVersion` 不是 `5.00` 时首版拒绝导入并显示实际版本。
- Prism 主版本不在 8–11、缺少创建版本或结构未知时，首版列出表但标记为不支持，避免对未经验证版本作兼容承诺。

## 首版支持矩阵

| 输入 | 状态 | 映射规则 |
| --- | --- | --- |
| PZFX 8–11 Column | 支持 | 每个 `YColumn` 成为 EasyGraph 一列，保留值的行顺序。 |
| PZFX 8–11 Grouped raw replicates | 支持 | 每个“Y 列标题 · 行标题”成为一列，同一单元格的各 Subcolumn 成为纵向重复值。 |
| PZFX XY | 不支持 | EasyGraph 当前没有连续 X 轴数据模型。 |
| Multiple Variables | 不支持 | `OneWay + ExtTableType="MultipleVariables"` 不能当作普通 Column。 |
| Nested | 不支持 | 直接展平会丢失 subject/subcolumn 层级。 |
| 预汇总误差数据 | 不支持 | `SD`、`SE`、`SDN`、`SEN`、`CVN`、`low-high` 等不能当作原始重复值。 |
| Survival、Contingency、Parts of Whole | 不支持 | 当前数据模型不能表达删失、计数表或组成语义。 |
| `HugeTable` | 首版不支持 | 显示明确原因；后续根据真实大表样例单独设计流式读取。 |
| `.prism` | 后续里程碑 | ZIP/CSV/JSON 容器，与 PZFX 解析分开实现。 |
| `.pzf` | 不支持 | 专有二进制格式，提示在 Prism 中另存为 PZFX。 |

不支持的表必须显示原因，不能静默忽略 X 值、误差列、删失标记或层级信息。

## 数据映射规则

### Column

接受条件：

- `TableType="OneWay"`；
- `ExtTableType` 为空；
- `YFormat` 为空或 `replicates`；
- 每个 `YColumn` 恰好有一个原始数据 `Subcolumn`。如果出现多个 Subcolumn，首版拒绝该表，避免把汇总量或其他维度当作重复值。

转换规则：

- `YColumn/Title` 作为 EasyGraph 列名；空标题回退为 `Group N`。
- `Subcolumn/d` 按文档顺序写入该列。
- 各组长度不一致时用空值补齐 DataFrame，不重排、不删除整行。
- 可选 RowTitles 仅作为未保留元数据显示警告，不混入数值或列名。

### Grouped

接受条件：

- `TableType="TwoWay"`；
- `ExtTableType` 为空；
- `YFormat="replicates"`；
- 存在一个 `RowTitlesColumn`；
- 每个 YColumn 至少包含一个 Subcolumn。

转换规则：

- 遍历顺序固定为 YColumn 文档顺序，再遍历 RowTitles 文档顺序。
- EasyGraph 列名为 `YColumn 标题 · RowTitle`；空标题使用稳定序号回退名。
- 对每个组合单元格，读取所有 Subcolumn 在该行索引处的 `d`，保持 replicate 顺序。
- Subcolumn 比某行短时补空值并产生结构警告；不把下一行数值错配过来。
- `Replicates`、`Subcolumns` 属性用于一致性检查，但实际节点数量才是数据来源。

### 数值、缺失和 excluded

- 空 `<d/>`、空白文本和 XML 空节点转换为 EasyGraph 空值。
- `Excluded="true"` 或 `Excluded="1"` 的值转换为空值并保留所在位置，同时累计 excluded 数量；绘图不会使用该值。
- 普通数值支持整数、小数、科学计数法和负数。
- 非数值文本、无穷大或无法安全转换的内容使该表导入失败，并指出表、组和数据位置。
- 标题通过节点全部文本内容读取，保留 Unicode；格式标签和显示属性不进入列名。
- 重复标题保持原样，继续使用 EasyGraph 现有的重复组名处理规则。

## 文件架构与依赖边界

首版不要把 XML 解析、数据映射和对话框全部塞进单个 `prism_io.py`。PZFX 已包含版本识别、表分类、安全解析和两种数据映射，后续还要接入 `.prism` 归档，因此从一开始使用小型包结构：

```text
src/easygraph/
├── prism_io/
│   ├── __init__.py              # 稳定公开 API，只重导出公开类型和函数
│   ├── models.py                # dataclass、表型枚举、警告和错误代码
│   ├── pzfx.py                  # PZFX 5.00 安全解析、版本识别、表枚举和分类
│   └── mapping.py               # Column/Grouped 中间数据到宽表 DataFrame
└── ui/
    ├── main_window.py           # 文件选择和确认后应用结果，不包含 XML 规则
    └── prism_import_dialog.py   # 表选择、警告和有限预览工作流

ui/
└── prism_import_dialog.ui       # Prism 对话框的 UI 源文件

src/
└── ui_prism_import_dialog.py    # pyside6-uic 生成，禁止手工维护

tests/
├── prism_fixtures.py            # 匿名最小 PZFX 构造器，不放用户真实数据
├── test_prism_pzfx.py           # XML、安全、版本、表分类和公开 API
├── test_prism_mapping.py        # Column/Grouped 到 DataFrame 的纯转换测试
└── test_prism_import_dialog.py  # 选择、取消、警告和主窗口状态集成测试

scripts/
└── inspect_prism_samples.py     # 只读本地样例检查和结构/哈希报告

docs/plans/
└── 2026-07-16-prism-raw-data-import.md

demo/prism_samples/
└── SOURCES.md                   # 本地真实样例版本、来源、哈希和用途登记
```

未来增加 `.prism` 支持时，只新增 `src/easygraph/prism_io/archive.py`，并复用 `models.py` 与 `mapping.py`；不要把 ZIP/JSON 规则加入 `pzfx.py`。

### 模块所有权

- `easygraph.prism_io.models`：唯一拥有 Prism 导入的稳定数据结构、错误代码和警告代码，不读取文件、不依赖 Qt。
- `easygraph.prism_io.pzfx`：唯一拥有 PZFX/XML 规则；输出结构化表数据，不操作窗口、表控件或图形。
- `easygraph.prism_io.mapping`：唯一拥有 Prism Column/Grouped 到 EasyGraph 宽表的映射；不解析 XML、不依赖 Qt。
- `easygraph.prism_io.__init__`：公开门面，保持小而稳定；UI 和测试不得导入私有下划线 helper。
- `easygraph.ui.prism_import_dialog`：唯一拥有 Prism 表选择与预览工作流；消费公开 Prism API，不复制解析规则。
- `easygraph.ui.main_window`：只负责打开文件、调用对话框、在确认后应用 DataFrame。
- `easygraph.spreadsheet_io`：继续只负责 CSV/Excel，不加入 Prism 分支，避免两个独立格式共享一个模糊 I/O 模块。
- `ui_prism_import_dialog.py`：生成文件；结构变化必须先编辑 `.ui` 再重新生成。

### 依赖方向

```text
main_window
    └── ui.prism_import_dialog
            └── easygraph.prism_io (public API)
                    ├── pzfx
                    ├── mapping
                    └── models
```

依赖只能沿箭头向下。`prism_io` 不得导入 `main_window`、任何 Qt Widgets、绘图模块、生成 UI 或项目持久化模块。后续 `archive.py` 与 `pzfx.py` 是并列容器读取器，二者不得互相导入。

### 公开数据结构与 API

建议公开类型：

- `PrismProjectSummary`：XML 版本、Prism 创建版本、表清单和工程级警告。
- `PrismTableSummary`：ID、标题、TableType、ExtTableType、YFormat、是否支持及原因。
- `PrismImportResult`：转换后的 DataFrame、缺失值数、excluded 数、来源信息和警告。
- `PrismImportError`：包含稳定错误代码和可显示消息的异常。

建议公开函数：

- `inspect_pzfx(path: Path) -> PrismProjectSummary`
- `import_pzfx_table(path: Path, table_id: str) -> PrismImportResult`

`__init__.py` 的 `__all__` 只包含上述公开类型和函数；错误代码与警告代码使用稳定字符串，便于 UI 翻译和未来兼容测试。

`pzfx.py` 内部职责拆分：

- `_local_name()`：统一处理带命名空间和不带命名空间的标签。
- `_parse_pzfx()`：安全解析、根节点检查、版本和资源上限检查。
- `_classify_table()`：按 `ExtTableType -> TableType -> YFormat` 判断是否支持。
- `_parse_column_table()`：Column 到中间原始组结构。
- `_parse_grouped_table()`：Grouped 到中间原始组结构。

`mapping.py` 拥有 `_groups_to_dataframe()`，统一补齐不同长度列并生成结果统计。解析和 DataFrame 转换分层，未来 `.prism` 归档读取器可以复用同一个中间组结构和映射模块。

### XML 安全与兼容

- 使用标准库 `xml.etree.ElementTree`，在解析前执行字节级安全检查；首版不新增运行时依赖。
- 解析前限制文件大小，拒绝非 UTF-8、DOCTYPE、ENTITY 和包含空字节的输入，从入口阻断外部实体与实体扩展。
- 为表数、YColumn 数、Subcolumn 数和 `d` 节点总数设置具名常量和上限测试。
- 所有元素按 local name 匹配，不硬编码默认命名空间前缀。
- 忽略 `Created` 之外的用户信息、`Info`、`FloatingNote`、图形、分析、布局和 `<Template>` 二进制模板内容。
- 不依赖 XML 子节点的绝对位置；按标签名查找，并通过 Table ID 和 `TableSequence` 确定展示顺序。
- 同一文件中允许多张普通 `Table`；重复或缺失 Table ID 产生稳定回退 ID 和警告。

## UI 集成

1. 在 `ui/main_window.ui` 的 File 菜单增加 `Import Prism PZFX...` action，并重新生成 `src/ui_main_window.py`。
2. 在 `src/easygraph/ui/main_window.py` 增加 `import_prism_data()`，文件过滤器接受 `*.pzfx`，并给 `.pzf` 提供转换说明。
3. 新增 `ui/prism_import_dialog.ui` 和 `src/easygraph/ui/prism_import_dialog.py`：
   - 列出所有原始表；
   - 不支持表仍显示，但禁用确认并显示原因；
   - 展示来源版本、转换后列名、组数、最大重复数、缺失数和 excluded 数；
   - 仅展示有限行列的预览。
4. 只有用户确认后才调用 `set_table_dataframe()`。
5. 从现有 `import_excel()` 提取一个共享的“应用导入结果”私有方法，统一完成 overlay 清理、组顺序同步、历史重置和 render，避免两个导入入口状态行为不一致。
6. 取消文件选择、取消预览、解析失败或表型不支持时，当前 EasyGraph 数据、overlay、历史和设置保持不变。
7. 重新生成 `src/ui_prism_import_dialog.py`；所有可见文本加入 `translations/easygraph_zh_CN.ts` 并更新 `.qm`。

## 测试计划

### 解析器单元测试

由 `tests/prism_fixtures.py` 生成小型匿名 XML，并按所有权拆到 `test_prism_pzfx.py` 和 `test_prism_mapping.py` 覆盖：

- Prism 8、9、10、11 创建版本配合同一个 PZFX 5.00 结构；另覆盖空 `OriginalVersion`、非空 `MostRecentVersion` 的另存文件。
- 无命名空间和默认命名空间两种文件。
- Column：不等长列、空标题、Unicode、重复标题、空节点和科学计数法。
- Grouped：多个行因素、多个 YColumn、不同 replicate 数、短 Subcolumn 和缺失值。
- `Excluded="true"`、`Excluded="1"`、false 和 0。
- XML 属性中的 `Replicates`/`Subcolumns` 与实际节点不一致。
- 多 Table、TableSequence、重复 ID 和空表。
- `ExtTableType="MultipleVariables"`、Nested、XY、预汇总 YFormat 和 HugeTable 的明确拒绝结果。
- 带命名空间的 Prism 10 Multiple Variables 本地样例不会被误判为普通 Column。
- 非 5.00 XML 版本、畸形 XML、DOCTYPE/entity、超限文件和伪装扩展名。
- 失败消息包含可定位的表 ID 和结构原因，不泄露模板二进制内容。
- 普通模式和 `python -O` 下结果一致。

### 真实样例回归

- 本地 Prism 9/10/11 Column 样例必须生成相同 DataFrame。
- 本地 Prism 9/10/11 Grouped 样例必须生成相同 DataFrame。
- 本地 Prism 8 Column/Grouped 以及 Prism 8→9 另存 Column 样例必须可导入。
- 逐项核对标题、数值、空值位置和列顺序，而不只比较行列数量。
- 现有 Prism 8 XY 样例应被正确识别为 Prism 8 和 XY，并明确返回“不支持”，不能被错误压成分组数据。
- 用户样例当前由 `.gitignore` 排除；除非用户明确同意提交，否则 CI 测试使用匿名小 fixture，真实样例只做本地 smoke test。

### UI 和状态测试

- UI 用例放在 `tests/test_prism_import_dialog.py`，不要继续扩大 `tests/test_core.py`。
- action 和信号连接正确。
- 单表和多表选择流程正确。
- 不支持表不能确认导入。
- 取消文件选择、取消对话框和解析失败不改变当前表格。
- 成功导入清除旧 overlay，并正确同步组顺序、历史和 render。
- excluded/缺失警告只显示一次且数量准确。

### 验证命令

实施完成后依次运行：

1. `python -m unittest tests.test_prism_pzfx tests.test_prism_mapping -v`
2. `python -m unittest tests.test_prism_import_dialog -v`
3. `python -m unittest discover -s tests -v`，Qt 使用 offscreen 环境。
4. `python -m py_compile` 检查新增和修改模块。
5. Windows 依赖/打包测试和冻结程序 smoke test。
6. 用本地 Prism 9/10/11 六份样例进行一次端到端手工导入核对。

## 实施顺序与检查点

### 阶段 1：固定解析契约

- 把 9/10/11 实样比较结果编码为测试期望。
- 建立匿名 Column/Grouped fixture builder。
- 建立 `prism_io` 包壳、公开 `__all__` 和架构依赖测试。
- 先写 Prism 8 假设、命名空间、unsupported 和恶意 XML 失败测试。

检查点：测试准确描述支持范围，尚未实现时按预期失败。

### 阶段 2：实现项目检查和表分类

- 完成安全 XML 读取、版本识别、TableSequence 和表摘要。
- 完成支持/不支持判定及错误分类。

检查点：可列出多表工程，且不会把 Multiple Variables 当作 Column。

### 阶段 3：实现 Column/Grouped 转换

- 实现数据节点读取、中间组结构、DataFrame 映射。
- 实现缺失、excluded、短列、标题和结构一致性警告。

检查点：9/10/11 对应样例转换结果完全一致；Prism 8 假设 fixture 通过。

### 阶段 4：接入 UI

- 增加菜单 action、表选择/预览对话框和共享导入应用流程。
- 保证确认前不修改主窗口状态。

检查点：取消和失败路径零副作用，成功路径与 Excel 导入状态同步一致。

### 阶段 5：翻译、完整验证和打包

- 更新翻译和依赖清单。
- 运行聚焦、完整、优化模式和 Windows 打包测试。
- 用真实 9/10/11 样例执行端到端 smoke test。

检查点：所有自动测试通过，打包程序可导入六份本地样例。

### 后续里程碑：`.prism` 归档

- 新增 `src/easygraph/prism_io/archive.py`，保持 `pzfx.py` 不变。
- 使用 `zipfile` 流式读取 `document.json`、数据表 JSON 和 CSV。
- 复用 PZFX 已建立的表摘要、组中间结构和 DataFrame 转换。
- 单独增加 ZIP 路径穿越、加密条目和压缩炸弹保护。
- 在有稳定 `.prism` 多版本样例后再接入同一个 UI 入口。

## 验收标准

- Prism 9/10/11 的 Column 和 Grouped 本地样例均可导入，输出 DataFrame 在标题、数值、空值位置和顺序上逐项一致。
- 符合已验证结构契约的 Prism 8 PZFX 可以通过同一个接口导入。
- 若真实 Prism 8 结构不同，软件给出结构化“不支持”错误且不改变当前项目。
- 有/无默认命名空间的 PZFX 都能正确识别。
- Multiple Variables、XY、Nested 和预汇总数据不会被误导入为原始 Column/Grouped。
- excluded 值不参与绘图，位置和数量可追踪；缺失值不会导致后续数值错位。
- 多表工程由用户明确选择，不默认猜测第一张表。
- 导入失败或取消不会改变当前数据、overlay、历史或图形。
- 完整测试和 Windows 打包 smoke test 通过。

## 实施与验证记录

2026-07-16 已完成以下交付：

- 建立 `src/easygraph/prism_io/` 包，按 `models.py`、`pzfx.py`、`mapping.py` 分离契约、容器解析和宽表转换。
- 建立独立 `PrismImportDialog`、`.ui` 源文件和生成文件，并在 File 菜单增加 `Import Prism PZFX...`。
- 主窗口只在用户确认后应用导入结果；取消、解析失败和不支持表型不会修改当前表格。
- 支持 Prism 8–11 PZFX 5.00 结构下的原始 Column 与 Grouped replicates；Prism 8 已由本地实样验证。
- 正确拒绝 XY、Multiple Variables、Nested/扩展类型、预汇总 YFormat、HugeTable、非 5.00 XML、非 UTF-8、DOCTYPE 和 ENTITY。
- 实现缺失值、excluded、短列/短 Subcolumn、默认命名空间、多表选择和 TableSequence 顺序处理。
- 增加匿名 fixtures、解析/映射/UI 测试、架构边界测试及 `scripts/inspect_prism_samples.py`。
- README、样例来源登记、简体中文翻译和 Windows 源码打包清单已同步。

验证结果：

- Prism/架构/Excel 聚焦回归：41 项通过。
- Windows 源码包与冻结 smoke 聚焦验证：3 项通过。
- 完整测试：458 项通过，耗时 194.023 秒。
- `py_compile`：新增和修改的 Prism、UI、脚本及测试模块通过。
- 本地真实样例：Prism 9/10/11 的三份 Column 和三份 Grouped 均通过逐项 DataFrame 回归；Prism 8 XY 与 Prism 10 Multiple Variables 被正确识别为不支持。
- 2026-07-21 补充：Prism 8 Column/Grouped 与 Prism 8→9 另存 Column 实样通过；版本识别改为 `MostRecentVersion` 优先、`OriginalVersion` 回退。
- 对话框已使用 Prism 11 Grouped 实样进行 offscreen 视觉检查，760×520 布局、摘要、警告、横向预览和确认按钮正常。

## 明确不在首版范围内

- Prism 分析结果、P 值、拟合参数、统计方法和结果表。
- Prism 图形、布局、颜色、字体、坐标轴、注释和 Template 内容。
- XY 连续坐标绘图、Kaplan–Meier、生存删失、列联表、nested 层级和预汇总误差数据。
- 从 EasyGraph 导出或回写 `.pzfx`/`.prism`。
- 自动合并 Prism 工程中的多张数据表。
- 对 Prism 7 及更早版本或 Prism 12 及以后版本作兼容承诺。
