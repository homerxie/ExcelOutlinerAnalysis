import math

import pandas as pd

from tests.easygraph_case import EasyGraphTestCase
from easygraph.numeric import (
    coerce_numeric_series,
    coerce_numeric_value,
    has_percentage_values,
)


class NumericTests(EasyGraphTestCase):
    def test_percentage_numbers_use_fractional_values(self):
        for text, expected in [
            ("25%", 0.25),
            (" -12.5 % ", -0.125),
            ("\u00a0+50％\u00a0", 0.5),
            (".5%", 0.005),
            ("1.2e2%", 1.2),
            ("0%", 0.0),
        ]:
            with self.subTest(text=text):
                self.assertAlmostEqual(coerce_numeric_value(text), expected)
                self.assertTrue(has_percentage_values([text]))

    def test_invalid_percentage_text_stays_invalid(self):
        for text in ["%", "25%%", "%25", "2%5", "25% extra", "NaN%", "inf%", "1e999%"]:
            with self.subTest(text=text):
                self.assertTrue(math.isnan(coerce_numeric_value(text)))
                self.assertFalse(has_percentage_values([text]))

    def test_mixed_series_preserves_source_and_row_alignment(self):
        source = pd.Series(
            ["25%", 0.5, "75％", "", "bad", None, "1e-2", "-5%"],
            index=[2, 2, 4, 5, 6, 7, 8, 9],
            name="Response",
        )
        original = source.copy(deep=True)

        result = coerce_numeric_series(source)

        pd.testing.assert_series_equal(source, original)
        pd.testing.assert_series_equal(
            result,
            pd.Series(
                [0.25, 0.5, 0.75, math.nan, math.nan, math.nan, 0.01, -0.05],
                index=source.index,
                name=source.name,
            ),
        )

    def test_numeric_series_and_unmarked_text_keep_their_values(self):
        for source in [pd.Series([1, 2, 3]), pd.Series([0.25, math.nan]), pd.Series(["25", "0.5"])]:
            with self.subTest(dtype=source.dtype):
                pd.testing.assert_series_equal(
                    coerce_numeric_series(source), pd.to_numeric(source, errors="coerce")
                )
                self.assertFalse(has_percentage_values(source))
