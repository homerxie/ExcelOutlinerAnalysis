from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest import mock

import numpy as np
import pandas as pd
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QApplication, QPushButton
from scipy.stats import gaussian_kde

from tests.easygraph_case import ROOT, EasyGraphQtTestCase, EasyGraphTestCase
from easygraph.settings import ChartSettings


class PlottingModuleContractTests(EasyGraphTestCase):
    def test_main_window_import_defers_matplotlib_and_chart_specific_dependencies(self):
        source_path = str(ROOT / "src")
        environment = os.environ.copy()
        existing_pythonpath = environment.get("PYTHONPATH", "")
        environment["PYTHONPATH"] = source_path + (
            os.pathsep + existing_pythonpath if existing_pythonpath else ""
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.ui import main_window

for forbidden in (
    "easygraph.plotting.canvas",
    "matplotlib",
    "seaborn",
    "scipy",
):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit("eager startup dependency loaded: " + forbidden)
if main_window.MainWindow.__name__ != "MainWindow":
    raise SystemExit("main window import failed")
"""
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=ROOT,
            env=environment,
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )

        self.assertEqual(result.returncode, 0, msg=result.stderr or result.stdout)

    def test_plotting_canvas_api_is_exact(self):
        from easygraph.plotting import canvas

        expected = [
            "AUTO_AXIS_RANGE_PADDING_FRACTION",
            "CoordinatesToolbar",
            "LEGEND_COLUMN_SPACING",
            "LEGEND_HANDLE_LENGTH",
            "LEGEND_HANDLE_SPACE_UNITS",
            "LEGEND_MAX_COLUMNS",
            "LEGEND_SECONDARY_AXIS_GAP_PX",
            "LINE_OVERLAY_STYLE_TO_MPL",
            "LINE_OVERLAY_STYLE_TO_QT",
            "LINE_STYLE_ICON_DEVICE_RATIOS",
            "LINE_STYLE_ICON_SIZE",
            "LINE_STYLE_POPUP_PREVIEW_WIDTH",
            "LINE_STYLE_POPUP_ROW_HEIGHT",
            "LINE_STYLE_PREVIEW_DOT_RADIUS",
            "LINE_STYLE_PREVIEW_STROKE_WIDTH",
            "MAX_MANUAL_TICK_COUNT",
            "OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS",
            "OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO",
            "OVERLAY_CONTENT_MARGIN_RATIO",
            "PlotCanvas",
            "STAT_OVERLAY_ALPHA",
            "ScrollFriendlyFigureCanvas",
            "draw_line_style_preview",
            "line_style_icon",
            "normalize_overlay_label_position",
            "overlay_auto_avoidance_position",
            "overlay_label_arrow",
            "overlay_label_bbox",
            "overlay_label_offset",
            "overlay_label_position_for_series",
            "overlay_line_qt_pen_style",
            "overlay_line_style",
            "overlay_values_are_close",
            "resolve_overlay_label_position",
        ]
        self.assertEqual(canvas.__all__, expected)

    def test_overlay_renderer_api_is_exact_and_shared_with_canvas(self):
        from easygraph.plotting import canvas, overlay_renderer

        expected = [
            "LINE_OVERLAY_STYLE_TO_MPL",
            "LINE_OVERLAY_STYLE_TO_QT",
            "LINE_STYLE_ICON_DEVICE_RATIOS",
            "LINE_STYLE_ICON_SIZE",
            "LINE_STYLE_POPUP_PREVIEW_WIDTH",
            "LINE_STYLE_POPUP_ROW_HEIGHT",
            "LINE_STYLE_PREVIEW_DOT_RADIUS",
            "LINE_STYLE_PREVIEW_STROKE_WIDTH",
            "STAT_OVERLAY_ALPHA",
            "draw_line_style_preview",
            "line_style_icon",
            "normalize_overlay_label_position",
            "overlay_auto_avoidance_position",
            "overlay_label_arrow",
            "overlay_label_bbox",
            "overlay_label_offset",
            "overlay_label_position_for_series",
            "overlay_line_qt_pen_style",
            "overlay_line_style",
            "overlay_values_are_close",
            "resolve_overlay_label_position",
        ]
        self.assertEqual(overlay_renderer.__all__, expected)
        for name in expected:
            with self.subTest(name=name):
                self.assertIs(getattr(canvas, name), getattr(overlay_renderer, name))

    def test_direct_overlay_renderer_import_has_no_canvas_or_app_dependency(self):
        source_path = str(ROOT / "src")
        environment = os.environ.copy()
        existing_pythonpath = environment.get("PYTHONPATH", "")
        environment["PYTHONPATH"] = source_path + (
            os.pathsep + existing_pythonpath if existing_pythonpath else ""
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.plotting import overlay_renderer

for forbidden in (
    "app",
    "easygraph.plotting.canvas",
    "matplotlib",
    "numpy",
    "pandas",
    "seaborn",
    "scipy",
):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit("forbidden dependency loaded: " + forbidden)
if overlay_renderer.overlay_line_style("Dense dash") != (0, (4, 1.5)):
    raise SystemExit("line style mapping changed")
if overlay_renderer.overlay_label_offset(0, [1.0], "Above", False) != (0, 13, "center", "bottom"):
    raise SystemExit("overlay offset changed")
"""
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=20,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )

    def test_overlay_renderer_helpers_preserve_current_behavior(self):
        from easygraph.plotting import overlay_renderer

        settings = ChartSettings(preset="Presentation", chart_type="Ridge", line_value_position="Top axis")

        self.assertEqual(
            overlay_renderer.normalize_overlay_label_position("Top axis", "Ridge"),
            "Axis right",
        )
        self.assertEqual(
            overlay_renderer.normalize_overlay_label_position("Axis left", "Box"),
            "Bottom axis",
        )
        self.assertEqual(
            overlay_renderer.overlay_label_position_for_series(settings, False),
            "Axis right",
        )
        self.assertEqual(
            overlay_renderer.overlay_auto_avoidance_position(
                ChartSettings(
                    chart_type="Box",
                    line_overlay_stat="Median",
                    line_value_position="Bottom axis",
                ),
                True,
            ),
            "Above",
        )
        self.assertTrue(overlay_renderer.overlay_values_are_close(1, [1.0, 1.04, 2.0]))
        self.assertFalse(overlay_renderer.overlay_values_are_close(1, [1.0, 1.5, 2.0]))

        box = overlay_renderer.overlay_label_bbox(settings)
        self.assertEqual(box["facecolor"], "#FFFFFF")
        self.assertEqual(box["edgecolor"], "#D1D5DB")
        arrow = overlay_renderer.overlay_label_arrow("#123456")
        self.assertEqual(arrow["color"], "#123456")
        self.assertEqual(arrow["arrowstyle"], "-")

    def test_chart_renderers_api_is_exact_and_shared_with_canvas(self):
        from easygraph.plotting import canvas, chart_renderers

        expected = [
            "beeswarm_offsets",
            "draw_bar",
            "draw_box",
            "draw_points",
            "draw_ridge",
            "draw_violin",
            "jitter_offsets",
            "point_positions",
            "quasirandom_offsets",
            "random_offsets",
            "van_der_corput",
        ]
        self.assertEqual(chart_renderers.__all__, expected)
        for name in expected:
            with self.subTest(name=name):
                self.assertIs(getattr(canvas, name), getattr(chart_renderers, name))

    def test_direct_chart_renderers_import_has_no_canvas_app_qt_or_ui_dependency(self):
        source_path = str(ROOT / "src")
        environment = os.environ.copy()
        existing_pythonpath = environment.get("PYTHONPATH", "")
        environment["PYTHONPATH"] = source_path + (
            os.pathsep + existing_pythonpath if existing_pythonpath else ""
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.plotting import chart_renderers

for forbidden in (
    "app",
    "easygraph.plotting.canvas",
    "PySide6",
    "seaborn",
    "scipy",
    "ui_main_window",
    "ui_group_order_dialog",
):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit("forbidden dependency loaded: " + forbidden)
if chart_renderers.van_der_corput(1) != 0.5:
    raise SystemExit("van der Corput sequence changed")
"""
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=20,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )

    def test_chart_renderer_helpers_preserve_current_behavior(self):
        from easygraph.plotting import chart_renderers

        values = np.array([1.0, 1.0, 2.0, 3.0])
        self.assertEqual(chart_renderers.van_der_corput(1), 0.5)
        self.assertEqual(chart_renderers.van_der_corput(2), 0.25)
        self.assertEqual(chart_renderers.jitter_offsets(values, 0.0, "Random", "A").tolist(), [0.0, 0.0, 0.0, 0.0])
        first = chart_renderers.jitter_offsets(values, 0.2, "Random", "A")
        second = chart_renderers.jitter_offsets(values, 0.2, "Random", "A")
        self.assertTrue(np.allclose(first, second))
        self.assertTrue(np.all(np.abs(chart_renderers.beeswarm_offsets(values, 0.2)) <= 0.2))
        self.assertTrue(np.all(np.abs(chart_renderers.quasirandom_offsets(values, 0.2)) <= 0.2))

        frame = pd.DataFrame({"Group": ["A", "A", "B"], "Value": [1.0, 2.0, 3.0]})
        settings = ChartSettings(group_col="Group", value_col="Value", jitter=0.0)
        positions = chart_renderers.point_positions(frame, settings)
        self.assertEqual(positions.tolist(), [0.0, 0.0, 1.0])

    def test_plotting_layout_api_is_exact_and_shared_with_canvas(self):
        from easygraph.plotting import canvas, layout

        expected = [
            "AUTO_AXIS_RANGE_PADDING_FRACTION",
            "LEGEND_COLUMN_SPACING",
            "LEGEND_HANDLE_LENGTH",
            "LEGEND_HANDLE_SPACE_UNITS",
            "LEGEND_MAX_COLUMNS",
            "LEGEND_SECONDARY_AXIS_GAP_PX",
            "MAX_MANUAL_TICK_COUNT",
            "OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS",
            "OVERLAY_AXIS_LABEL_DATA_PAD_HEIGHT_RATIO",
            "OVERLAY_CONTENT_MARGIN_RATIO",
            "custom_overlay_secondary_axis_active",
            "horizontal_axis_label_width_overflow_inches",
            "legend_auto_width_enabled",
            "legend_column_count",
            "legend_column_gap_inches",
            "legend_column_width_inches",
            "legend_force_wrap",
            "legend_handle_space_inches",
            "legend_label_text",
            "legend_labels_for_settings",
            "legend_outside_needed",
            "legend_render_width_inches",
            "legend_right_margin_inches",
            "legend_text_width_inches",
            "legend_total_width_inches",
            "legend_unwrapped_item_width_inches",
            "legend_wrap_units",
            "line_count",
            "max_line_count",
            "max_text_width_inches",
            "overlay_axis_label_margin_points",
            "overlay_axis_marker_margin_points",
            "plot_bottom_margin_inches",
            "plot_left_margin_inches",
            "plot_right_margin_inches",
            "plot_top_margin_inches",
            "ridge_category_tick_vertical_overflow_inches",
            "rotated_axis_label_width_inches",
            "rotated_category_tick_side_overflow_inches",
            "rotated_value_axis_label_height_overflow_inches",
            "secondary_axis_split_ratio",
            "split_secondary_frame_enabled",
            "stat_table_gap_inches",
            "stat_table_height_inches",
            "stat_table_row_height_inches",
            "stat_table_row_height_units",
            "text_visual_units",
            "wrap_visual_units",
        ]
        self.assertEqual(layout.__all__, expected)
        for name in expected:
            with self.subTest(name=name):
                self.assertIs(getattr(canvas, name), getattr(layout, name))

    def test_direct_layout_import_has_no_canvas_app_or_plotting_stack_dependency(self):
        source_path = str(ROOT / "src")
        environment = os.environ.copy()
        existing_pythonpath = environment.get("PYTHONPATH", "")
        environment["PYTHONPATH"] = source_path + (
            os.pathsep + existing_pythonpath if existing_pythonpath else ""
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.plotting import layout

for forbidden in (
    "app",
    "easygraph.plotting.canvas",
    "matplotlib",
    "numpy",
    "pandas",
    "seaborn",
    "scipy",
    "PySide6",
):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit("forbidden dependency loaded: " + forbidden)
if layout.line_count("A\\nB") != 2:
    raise SystemExit("line_count changed")
if layout.text_visual_units("A中") != 3.0:
    raise SystemExit("text width heuristic changed")
"""
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=20,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )

    def test_layout_helpers_preserve_current_behavior(self):
        from easygraph.plotting import layout

        settings = ChartSettings(
            legend_width=5.08,
            legend_font_size=12,
            legend_columns=2,
            legend_auto_width=False,
            show_legend=True,
            show_outliers=True,
            show_points=True,
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[{"name": "Target"}, {"name": ""}],
            custom_overlay_hidden=[],
            show_line_overlay=True,
            show_line_values=True,
            line_value_position="Bottom axis",
            chart_type="Box",
            stat_table_font_size=10,
            tick_font_size=12,
            axis_label_font_size=14,
            x_tick_rotation=45,
        )

        self.assertEqual(layout.secondary_axis_split_ratio(ChartSettings(secondary_axis_split_ratio=0.9)), 0.85)
        self.assertEqual(layout.line_count("A\nB"), 2)
        self.assertEqual(layout.max_line_count(["A", "B\nC"]), 2)
        self.assertAlmostEqual(layout.text_visual_units("A中"), 3.0)
        self.assertEqual(layout.wrap_visual_units("abcd", 2.0), ["ab", "cd"])
        self.assertAlmostEqual(layout.legend_total_width_inches(settings), 2.0)
        self.assertAlmostEqual(layout.legend_handle_space_inches(settings), 12 * 3.8 / 72.0)
        self.assertEqual(layout.legend_column_count(["Alpha", "Beta", "Gamma"], settings), 2)
        self.assertTrue(layout.legend_force_wrap(["Alpha", "Beta"], settings))
        self.assertEqual(layout.legend_labels_for_settings(settings), ["Outlier", "Median", "Target", "Overlay 2"])
        self.assertGreater(layout.stat_table_gap_inches(settings, ["A", "B"], "Group"), 0.0)
        self.assertGreater(layout.plot_left_margin_inches(settings, ["A", "B"], "Value", [("Mean", ["1", "2"])]), 0.0)
        self.assertGreater(layout.plot_bottom_margin_inches(settings, ["A", "B"], "Group"), 0.0)
        left_overflow, right_overflow = layout.rotated_category_tick_side_overflow_inches(
            settings,
            ["A very long category", "B", "C"],
            2.0,
            0.2,
            0.2,
        )
        self.assertGreater(left_overflow, 0.0)
        self.assertGreaterEqual(right_overflow, 0.0)

    def test_direct_plotting_canvas_import_does_not_import_app(self):
        code = f"""
import sys
sys.path.insert(0, {str(ROOT / "src")!r})
from easygraph.plotting import canvas
if "app" in sys.modules:
    raise SystemExit("imported app")
for name in ("PlotCanvas", "ScrollFriendlyFigureCanvas", "CoordinatesToolbar"):
    getattr(canvas, name)
assert canvas.overlay_label_offset(0, [1.0], "Above", False) == (0, 13, "center", "bottom")
"""
        env = os.environ.copy()
        env["PYTHONPATH"] = str(ROOT / "src")
        for args in ([sys.executable, "-c", code], [sys.executable, "-O", "-c", code]):
            with self.subTest(args=args):
                result = subprocess.run(
                    args,
                    cwd=ROOT,
                    env=env,
                    text=True,
                    capture_output=True,
                    timeout=20,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )

    def test_chart_clipboard_mime_survives_qapplication_teardown(self):
        source_path = str(ROOT / "src")
        code = f"""
import sys
sys.path.insert(0, {source_path!r})

from PySide6.QtWidgets import QApplication
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings

app = QApplication([])
plot_canvas = PlotCanvas()
plot_canvas.figure.text(0.5, 0.5, "Clipboard teardown", color="#123456")
if not plot_canvas.copy_to_clipboard(
    ChartSettings(transparent_background=True, dpi=72)
):
    raise SystemExit("clipboard copy failed")
mime_data = QApplication.clipboard().mimeData()
if mime_data.formats()[0] != "image/png" or not mime_data.hasImage():
    raise SystemExit("clipboard MIME payload is incomplete")
print("clipboard-ready", flush=True)
"""
        environment = os.environ.copy()
        existing_pythonpath = environment.get("PYTHONPATH", "")
        environment["PYTHONPATH"] = source_path + (
            os.pathsep + existing_pythonpath if existing_pythonpath else ""
        )
        environment["QT_QPA_PLATFORM"] = "offscreen"
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=ROOT,
            env=environment,
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )

        diagnostics = f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        self.assertIn("clipboard-ready", result.stdout, msg=diagnostics)
        self.assertEqual(result.returncode, 0, msg=diagnostics)


class PlottingModuleQtTests(EasyGraphQtTestCase):
    TRANSPARENT_TEXT_RGB = (18, 52, 86)

    def transparent_text_canvas(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        plot_canvas.figure.clf()
        plot_canvas.figure.patch.set_facecolor("white")
        plot_canvas.figure.text(
            0.5,
            0.5,
            "Antialias",
            ha="center",
            va="center",
            fontsize=48,
            color="#123456",
        )
        settings = ChartSettings(transparent_background=True, dpi=120)
        return plot_canvas, settings

    def assert_native_transparent_text_pixels(self, image: QImage) -> None:
        self.assertFalse(image.isNull())
        self.assertTrue(image.hasAlphaChannel())
        alphas = set()
        edge_colors = set()
        for y in range(image.height()):
            for x in range(image.width()):
                color = image.pixelColor(x, y)
                alpha = color.alpha()
                alphas.add(alpha)
                if 0 < alpha < 255:
                    edge_colors.add((color.red(), color.green(), color.blue()))

        self.assertIn(0, alphas)
        self.assertIn(255, alphas)
        self.assertTrue(any(0 < alpha < 255 for alpha in alphas))
        self.assertEqual(edge_colors, {self.TRANSPARENT_TEXT_RGB})

    def render_draw_count(
        self,
        settings: ChartSettings,
        frame: pd.DataFrame | None = None,
    ) -> int:
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        frame = frame if frame is not None else pd.DataFrame({
            "A": [1.0, 2.0, 3.0, 4.0],
            "B": [2.0, 3.0, 4.0, 5.0],
            "C": [3.0, 4.0, 5.0, 6.0],
        })
        original_draw = canvas.ScrollFriendlyFigureCanvas.draw
        draw_count = 0

        def counted_draw(instance, *args, **kwargs):
            nonlocal draw_count
            draw_count += 1
            return original_draw(instance, *args, **kwargs)

        with mock.patch.object(canvas.ScrollFriendlyFigureCanvas, "draw", new=counted_draw):
            plot_canvas.render(frame, settings)
            QApplication.processEvents()
        return draw_count

    def test_default_chart_types_stay_within_full_render_draw_budget(self):
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            with self.subTest(chart_type=chart_type):
                draw_count = self.render_draw_count(ChartSettings(chart_type=chart_type))

                self.assertLessEqual(draw_count, 3)

    def test_overall_font_step_across_reported_sizes_scales_text_gradually(self):
        from easygraph import app_theme
        from easygraph.plotting import canvas

        large_steps = [size for size in app_theme.OFFICE_FONT_SIZE_STEPS if size >= 28]
        self.assertEqual(app_theme.office_adjacent_font_size(36, 1, 5, 72), 40)
        self.assertTrue(
            all(next_size / size <= 1.20 for size, next_size in zip(large_steps, large_steps[1:]))
        )

        frame = pd.DataFrame({
            "Control group with a long condition label": [1.0, 2.0, 3.0],
            "Low dose treatment with a long condition label": [2.0, 3.0, 4.0],
            "High dose treatment with a long condition label": [3.0, 4.0, 5.0],
        })
        font_sets = (
            (32, 28, 24, 24, 22, 22),
            (34, 30, 26, 26, 24, 24),
        )
        rendered_sizes = []
        for title_size, axis_size, tick_size, legend_size, label_size, table_size in font_sets:
            plot_canvas = canvas.PlotCanvas()
            self.addCleanup(plot_canvas.close)
            original_set_fixed_size = canvas.ScrollFriendlyFigureCanvas.setFixedSize
            resize_count = 0

            def counted_set_fixed_size(instance, *args, **kwargs):
                nonlocal resize_count
                resize_count += 1
                return original_set_fixed_size(instance, *args, **kwargs)

            with mock.patch.object(
                canvas.ScrollFriendlyFigureCanvas,
                "setFixedSize",
                new=counted_set_fixed_size,
            ):
                plot_canvas.render(
                    frame,
                    ChartSettings(
                        show_stat_table=False,
                        x_tick_rotation=65,
                        x_label="Treatment group",
                        title="Gradual title scaling",
                        title_font_size=title_size,
                        axis_label_font_size=axis_size,
                        tick_font_size=tick_size,
                        legend_font_size=legend_size,
                        line_value_font_size=label_size,
                        stat_table_font_size=table_size,
                    ),
                )
            self.assertEqual(resize_count, 1)
            renderer = plot_canvas.canvas.get_renderer()
            ax = plot_canvas.figure.axes[0]
            rendered_sizes.append((
                ax.title.get_window_extent(renderer).height,
                ax.xaxis.label.get_window_extent(renderer).height,
                ax.get_xticklabels()[0].get_window_extent(renderer).height,
                plot_canvas.figure.get_figwidth(),
                plot_canvas.figure.get_figheight(),
            ))

        for before, after in zip(rendered_sizes[0], rendered_sizes[1]):
            self.assertGreater(after, before)
            self.assertLess(after / before, 1.20)

    def test_complex_layouts_stay_within_full_render_draw_budget(self):
        overlay = {
            "name": "Target",
            "values": {"A": "3.0", "B": "4.0", "C": "5.0"},
        }
        scenarios = {
            "statistics table": ChartSettings(show_stat_table=True),
            "inside legend": ChartSettings(
                show_stat_table=False,
                line_overlay_stat="Median",
                legend_position="inside",
            ),
            "secondary axis": ChartSettings(
                show_stat_table=False,
                extra_custom_overlay=True,
                custom_overlay_secondary_axis=True,
                custom_overlay_series=[overlay],
            ),
        }

        for name, settings in scenarios.items():
            with self.subTest(name=name):
                self.assertLessEqual(self.render_draw_count(settings), 4)

    def test_many_overlay_labels_have_bounded_draw_count(self):
        overlays = [
            {
                "name": f"Target {index + 1}",
                "values": {"A": str(3.0 + index * 0.02), "B": "4.0", "C": "5.0"},
            }
            for index in range(8)
        ]
        settings = ChartSettings(
            show_stat_table=False,
            extra_custom_overlay=True,
            custom_overlay_series=overlays,
            show_line_values=True,
        )

        self.assertLessEqual(self.render_draw_count(settings), 6)

    def test_axis_expansion_preserves_direction_and_handles_zero_span(self):
        from easygraph.plotting import canvas

        normal = canvas.PlotCanvas._expanded_axis_limits(0.0, 10.0, 10.0, 20.0, 100.0)
        inverted = canvas.PlotCanvas._expanded_axis_limits(10.0, 0.0, 10.0, 20.0, 100.0)
        zero_span = canvas.PlotCanvas._expanded_axis_limits(5.0, 5.0, 10.0, 10.0, 100.0)

        self.assertLess(normal[0], 0.0)
        self.assertGreater(normal[1], 10.0)
        self.assertGreater(inverted[0], 10.0)
        self.assertLess(inverted[1], 0.0)
        self.assertGreater(inverted[0], inverted[1])
        self.assertLess(zero_span[0], 5.0)
        self.assertGreater(zero_span[1], 5.0)

    def test_optimized_render_exports_raster_and_vector_formats(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        frame = pd.DataFrame({
            "A": [1.0, 2.0, 3.0],
            "B": [2.0, 3.0, 4.0],
            "C": [3.0, 4.0, 5.0],
        })
        settings = ChartSettings(
            show_stat_table=True,
            line_overlay_stat="Median",
            show_line_values=True,
            legend_position="inside",
        )
        plot_canvas.render(frame, settings)

        with tempfile.TemporaryDirectory() as tmp:
            for suffix in (".png", ".svg", ".pdf"):
                with self.subTest(suffix=suffix):
                    path = Path(tmp) / f"optimized-render{suffix}"
                    plot_canvas.export(str(path), settings)

                    self.assertTrue(path.is_file())
                    self.assertGreater(path.stat().st_size, 100)

    def test_transparent_png_export_preserves_native_alpha_and_text_edge_rgb(self):
        plot_canvas, settings = self.transparent_text_canvas()

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "transparent-text.png"
            plot_canvas.export(str(path), settings)
            image = QImage(str(path))

        self.assert_native_transparent_text_pixels(image)

    def test_clipboard_copy_provides_png_mime_and_alpha_preserving_qimage(self):
        plot_canvas, settings = self.transparent_text_canvas()
        clipboard = QApplication.clipboard()
        clipboard.clear()
        self.addCleanup(clipboard.clear)

        copied = plot_canvas.copy_to_clipboard(settings)

        self.assertTrue(copied)
        mime_data = clipboard.mimeData()
        self.assertEqual(mime_data.formats()[0], "image/png")
        self.assertTrue(mime_data.hasFormat("image/png"))
        self.assertTrue(mime_data.hasImage())
        png_bytes = bytes(mime_data.data("image/png"))
        self.assertTrue(png_bytes.startswith(b"\x89PNG\r\n\x1a\n"))
        png_image = QImage()
        self.assertTrue(png_image.loadFromData(png_bytes, "PNG"))
        fallback_image = clipboard.image()

        self.assert_native_transparent_text_pixels(png_image)
        self.assert_native_transparent_text_pixels(fallback_image)
        self.assertEqual(fallback_image.size(), png_image.size())

    def test_chart_clipboard_release_preserves_native_alpha_image(self):
        from easygraph.plotting import canvas

        plot_canvas, settings = self.transparent_text_canvas()
        clipboard = QApplication.clipboard()
        clipboard.clear()
        self.addCleanup(clipboard.clear)
        self.assertTrue(plot_canvas.copy_to_clipboard(settings))

        wrapped_mime_data = clipboard.mimeData()
        self.assertTrue(
            bool(
                wrapped_mime_data.property(
                    canvas._CHART_CLIPBOARD_MIME_PROPERTY,
                )
            )
        )
        wrapped_image = clipboard.image()
        self.assert_native_transparent_text_pixels(wrapped_image)

        canvas._release_chart_clipboard_mime_data()

        native_mime_data = clipboard.mimeData()
        native_image = clipboard.image()
        self.assertIsNot(native_mime_data, wrapped_mime_data)
        self.assertFalse(
            bool(
                native_mime_data.property(
                    canvas._CHART_CLIPBOARD_MIME_PROPERTY,
                )
            )
        )
        self.assertTrue(native_mime_data.hasImage())
        self.assertEqual(native_image.size(), wrapped_image.size())
        self.assert_native_transparent_text_pixels(native_image)

    def test_chart_clipboard_release_leaves_external_content_unchanged(self):
        from easygraph.plotting import canvas

        clipboard = QApplication.clipboard()
        clipboard.clear()
        self.addCleanup(clipboard.clear)
        clipboard.setText("external-content")
        external_mime_data = clipboard.mimeData()
        external_formats = external_mime_data.formats()

        canvas._release_chart_clipboard_mime_data()

        self.assertIs(clipboard.mimeData(), external_mime_data)
        self.assertEqual(clipboard.mimeData().formats(), external_formats)
        self.assertEqual(clipboard.text(), "external-content")
        self.assertFalse(
            bool(
                clipboard.mimeData().property(
                    canvas._CHART_CLIPBOARD_MIME_PROPERTY,
                )
            )
        )

    def test_transparent_setting_exports_jpeg_on_opaque_figure_facecolor(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        plot_canvas.figure.clf()
        plot_canvas.figure.patch.set_facecolor("#112233")
        plot_canvas.figure.text(
            0.5,
            0.5,
            "White text",
            ha="center",
            va="center",
            fontsize=48,
            color="white",
        )
        settings = ChartSettings(transparent_background=True, dpi=120)

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "dark-theme.jpg"
            plot_canvas.export(str(path), settings)
            image = QImage(str(path))

        self.assertFalse(image.isNull())
        corner = image.pixelColor(0, 0)
        self.assertEqual(corner.alpha(), 255)
        for actual, expected in zip(
            (corner.red(), corner.green(), corner.blue()),
            (0x11, 0x22, 0x33),
        ):
            self.assertAlmostEqual(actual, expected, delta=8)
        self.assertTrue(
            any(
                image.pixelColor(x, y).lightness() >= 220
                for y in range(image.height())
                for x in range(image.width())
            )
        )

    def test_canvas_prepares_full_and_visible_plot_frames_once(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        frame = pd.DataFrame({
            "A": [1.0, 2.0, 3.0],
            "B": [2.0, 3.0, 4.0],
        })

        with mock.patch.object(
            canvas,
            "prepare_plot_frames",
            wraps=canvas.prepare_plot_frames,
        ) as prepare:
            plot_canvas.render(frame, ChartSettings(group_hidden=["B"]))

        prepare.assert_called_once_with(frame, mock.ANY)

    def test_ridge_render_reuses_precomputed_outliers_for_all_visibility_modes(self):
        from easygraph.plotting import canvas, chart_renderers

        frame = pd.DataFrame(
            [
                [1.0, 1.4, 2.0, 100.0],
                [1.1, 1.5, 2.1, 101.0],
                [1.2, 1.6, 2.2, 102.0],
                [8.0, 9.0, 9.0, 200.0],
            ],
            columns=["A", "A", "B", "Hidden"],
        )
        for show_points, show_outliers, outlier_effect in (
            (True, True, "Mark only"),
            (True, False, "Mark only"),
            (False, True, "Mark only"),
            (True, True, "Exclude from distribution"),
        ):
            with self.subTest(
                show_points=show_points,
                show_outliers=show_outliers,
                outlier_effect=outlier_effect,
            ):
                plot_canvas = canvas.PlotCanvas()
                self.addCleanup(plot_canvas.close)
                settings = ChartSettings(
                    chart_type="Ridge",
                    show_stat_table=False,
                    show_points=show_points,
                    show_outliers=show_outliers,
                    outlier_effect=outlier_effect,
                    group_hidden=["Hidden"],
                )
                with mock.patch.object(
                    canvas,
                    "mark_outliers",
                    wraps=canvas.mark_outliers,
                ) as prepare_outliers, mock.patch.object(
                    chart_renderers,
                    "mark_outliers",
                    side_effect=AssertionError("Ridge renderer rescanned outliers"),
                ):
                    plot_canvas.render(frame, settings)

                prepare_outliers.assert_called_once()
                prepared_frame = prepare_outliers.call_args.args[0]
                self.assertNotIn("Hidden", prepared_frame[settings.group_col].unique())
                labels = prepared_frame.attrs["group_labels"]
                a_keys = [key for key, label in labels.items() if label == "A"]
                self.assertEqual(len(a_keys), 2)
                self.assertEqual(
                    [int((prepared_frame[settings.group_col] == key).sum()) for key in a_keys],
                    [4, 4],
                )

    def test_large_quasirandom_offsets_are_deterministic_bounded_and_order_independent(self):
        from easygraph.plotting import chart_renderers

        rng = np.random.default_rng(303)
        values = rng.normal(size=5000)
        permutation = rng.permutation(len(values))

        first = chart_renderers.quasirandom_offsets(values, 0.25)
        second = chart_renderers.quasirandom_offsets(values, 0.25)
        shuffled = chart_renderers.quasirandom_offsets(values[permutation], 0.25)
        restored = np.empty_like(shuffled)
        restored[permutation] = shuffled

        np.testing.assert_array_equal(first, second)
        np.testing.assert_allclose(first, restored, rtol=0.0, atol=1e-12)
        self.assertTrue(np.isfinite(first).all())
        self.assertLessEqual(float(np.max(np.abs(first))), 0.25)

    def test_quasirandom_offsets_handle_constants_and_non_finite_values(self):
        from easygraph.plotting import chart_renderers

        for values in (
            np.full(5000, 3.0),
            np.array([np.nan, np.inf, -np.inf, 1.0, 2.0]),
            np.array([1.0]),
        ):
            with self.subTest(size=len(values)):
                offsets = chart_renderers.quasirandom_offsets(values, 0.25)

                self.assertEqual(len(offsets), len(values))
                self.assertTrue(np.isfinite(offsets).all())
                self.assertLessEqual(float(np.max(np.abs(offsets), initial=0.0)), 0.25)

        np.testing.assert_array_equal(
            chart_renderers.quasirandom_offsets(np.arange(8.0), 0.0),
            np.zeros(8),
        )

    def test_small_quasirandom_offsets_preserve_exact_kde_scaling(self):
        from easygraph.plotting import chart_renderers

        values = np.array([-1.2, -0.8, -0.1, 0.0, 0.2, 1.7, 2.0])
        width = 0.3
        order = np.argsort(values, kind="mergesort")
        base = np.array([
            chart_renderers.van_der_corput(index + 1)
            for index in range(len(values))
        ]) - 0.5
        base *= 2 * width
        density = gaussian_kde(values)(values)
        density_scale = 0.25 + 0.75 * density / density.max()
        expected = np.zeros(len(values))
        expected[order] = base * density_scale[order]

        np.testing.assert_allclose(
            chart_renderers.quasirandom_offsets(values, width),
            expected,
            rtol=1e-12,
            atol=1e-12,
        )

    def test_quasirandom_density_keeps_dense_regions_visually_wider(self):
        from easygraph.plotting import chart_renderers

        rng = np.random.default_rng(304)
        dense = rng.normal(0.0, 0.08, 4000)
        sparse = rng.uniform(3.0, 8.0, 1000)
        values = np.concatenate([dense, sparse])
        offsets = chart_renderers.quasirandom_offsets(values, 0.25)

        self.assertGreater(
            float(np.mean(np.abs(offsets[: len(dense)]))),
            float(np.mean(np.abs(offsets[len(dense):]))),
        )

    def test_plot_canvas_constructs_scroll_friendly_canvas_and_toolbar(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)

        self.assertIsInstance(plot_canvas.canvas, canvas.ScrollFriendlyFigureCanvas)
        self.assertIsInstance(plot_canvas.toolbar, canvas.CoordinatesToolbar)
        self.assertIs(plot_canvas.canvas.owner, plot_canvas)
        self.assertIsNotNone(plot_canvas.findChild(QPushButton, "zoomToFitButton"))

    def test_main_window_uses_extracted_plot_canvas(self):
        from easygraph.plotting import canvas

        window = self.make_window(initial_render=False)

        self.assertIsInstance(window.canvas, canvas.PlotCanvas)
        self.assertIs(window.canvas.selection_callback.__self__, window)
        self.assertIs(
            window.canvas.selection_callback.__func__,
            window.handle_plot_object_selection.__func__,
        )
        self.assertIs(window.canvas.legend_position_callback.__self__, window)
        self.assertIs(
            window.canvas.legend_position_callback.__func__,
            window.handle_legend_drag_position.__func__,
        )
        self.assertIs(
            window.canvas.fit_equation_position_callback.__self__,
            window,
        )
        self.assertIs(
            window.canvas.fit_equation_position_callback.__func__,
            window.handle_fit_equation_drag_position.__func__,
        )

    def test_show_grid_switch_hides_and_restores_plot_grid(self):
        window = self.make_window(initial_render=True)

        window.show_grid.setChecked(False)
        window.flush_pending_render()
        primary_ax = window.canvas.figure.axes[0]
        self.assertFalse(any(line.get_visible() for line in primary_ax.get_xgridlines()))
        self.assertFalse(any(line.get_visible() for line in primary_ax.get_ygridlines()))

        window.show_grid.setChecked(True)
        window.flush_pending_render()
        primary_ax = window.canvas.figure.axes[0]
        self.assertTrue(any(line.get_visible() for line in primary_ax.get_xgridlines()))
        self.assertTrue(any(line.get_visible() for line in primary_ax.get_ygridlines()))

    def test_unrotated_x_tick_labels_remain_centered(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        plot_canvas.render(self.df, ChartSettings(show_stat_table=False, x_tick_rotation=0))

        labels = plot_canvas.figure.axes[0].get_xticklabels()
        self.assertTrue(labels)
        self.assertTrue(all(label.get_rotation() == 0 for label in labels))
        self.assertTrue(all(label.get_horizontalalignment() == "center" for label in labels))

    def test_rotated_x_tick_labels_anchor_their_right_end_to_ticks(self):
        from easygraph.plotting import canvas

        for rotation in (45, 90):
            with self.subTest(rotation=rotation):
                plot_canvas = canvas.PlotCanvas()
                self.addCleanup(plot_canvas.close)
                plot_canvas.render(
                    self.df,
                    ChartSettings(show_stat_table=False, x_tick_rotation=rotation),
                )

                labels = plot_canvas.figure.axes[0].get_xticklabels()
                self.assertTrue(labels)
                self.assertTrue(all(label.get_rotation() == rotation for label in labels))
                self.assertTrue(all(label.get_horizontalalignment() == "right" for label in labels))
                self.assertTrue(all(label.get_rotation_mode() == "anchor" for label in labels))

    def test_rotated_ticks_and_x_axis_title_stay_inside_canvas_without_stat_table(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        frame = pd.DataFrame({
            "Control group with a long condition label": [1.0, 2.0, 3.0],
            "Low dose treatment with a long condition label": [2.0, 3.0, 4.0],
            "High dose treatment with a long condition label": [3.0, 4.0, 5.0],
        })
        plot_canvas.render(
            frame,
            ChartSettings(
                show_stat_table=False,
                x_tick_rotation=65,
                x_label=(
                    "Treatment group axis title spanning every scheduled "
                    "observation and experimental condition"
                ),
            ),
        )

        renderer = plot_canvas.canvas.get_renderer()
        figure_bounds = plot_canvas.figure.bbox
        ax = plot_canvas.figure.axes[0]
        artists = [*ax.get_xticklabels(), ax.xaxis.label]
        for artist in artists:
            if not artist.get_visible() or not artist.get_text():
                continue
            with self.subTest(text=artist.get_text()):
                bounds = artist.get_window_extent(renderer)
                self.assertGreaterEqual(bounds.x0, figure_bounds.x0)
                self.assertGreaterEqual(bounds.y0, figure_bounds.y0)
                self.assertLessEqual(bounds.x1, figure_bounds.x1)
                self.assertLessEqual(bounds.y1, figure_bounds.y1)

    def test_many_long_rotated_ticks_stay_inside_horizontal_canvas_edges(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        frame = pd.DataFrame({
            f"Group {index + 1} with an extremely long treatment condition label": [
                float(index + 1),
                float(index + 2),
                float(index + 3),
            ]
            for index in range(10)
        })
        plot_canvas.render(
            frame,
            ChartSettings(
                show_stat_table=False,
                x_tick_rotation=30,
                x_label="",
            ),
        )

        renderer = plot_canvas.canvas.get_renderer()
        figure_bounds = plot_canvas.figure.bbox
        for label in plot_canvas.figure.axes[0].get_xticklabels():
            if not label.get_visible() or not label.get_text():
                continue
            bounds = label.get_window_extent(renderer)
            self.assertGreaterEqual(bounds.x0, figure_bounds.x0)
            self.assertLessEqual(bounds.x1, figure_bounds.x1)

    def test_ridge_x_tick_labels_ignore_rotation_and_remain_centered(self):
        from easygraph.plotting import canvas

        plot_canvas = canvas.PlotCanvas()
        self.addCleanup(plot_canvas.close)
        plot_canvas.render(
            self.df,
            ChartSettings(chart_type="Ridge", show_stat_table=False, x_tick_rotation=65),
        )

        labels = plot_canvas.figure.axes[0].get_xticklabels()
        self.assertTrue(labels)
        self.assertTrue(all(label.get_rotation() == 0 for label in labels))
        self.assertTrue(all(label.get_horizontalalignment() == "center" for label in labels))
