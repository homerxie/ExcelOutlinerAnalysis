from __future__ import annotations

from types import SimpleNamespace
from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPalette

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.workbook import SHEET_MODE_XY
from easygraph.xy_series import XYSeriesSpec, XYSettings


class XYInspectorRegressionTests(EasyGraphQtTestCase):
    def make_xy_window(self):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        return window

    @staticmethod
    def set_xy_series_selection(window, scope: str, series_ids=()) -> None:
        setter = getattr(window.canvas, "set_xy_series_selection", None)
        if callable(setter):
            setter(scope, tuple(series_ids))
            return
        ordered_ids = tuple(series_ids)
        window.canvas._selected_object_kind = "points"
        window.canvas._xy_selection_scope = scope
        window.canvas._selected_series_ids = ordered_ids
        window.canvas._selected_series_id = (
            ordered_ids[0]
            if scope == "subset" and len(ordered_ids) == 1
            else None
        )
        window.handle_plot_object_selection("points")

    @staticmethod
    def xy_selection_item(window, series_id: str):
        for index in range(window.xy_series_selection_list.count()):
            item = window.xy_series_selection_list.item(index)
            if item.data(Qt.ItemDataRole.UserRole) == series_id:
                return item
        raise AssertionError(f"Missing XY series selection item: {series_id}")

    @staticmethod
    def set_xy_display_controls(window, *, show_points: bool, show_lines: bool) -> None:
        points_blocked = window.show_points.blockSignals(True)
        lines_blocked = window.xy_show_line.blockSignals(True)
        try:
            window.show_points.setChecked(show_points)
            window.xy_show_line.setChecked(show_lines)
        finally:
            window.show_points.blockSignals(points_blocked)
            window.xy_show_line.blockSignals(lines_blocked)
        window._update_dependent_control_states()

    def test_xy_point_and_line_controls_follow_the_three_valid_display_modes(self):
        window = self.make_xy_window()
        point_widgets = (
            window.ui.xyMarkerLabel,
            window.xy_marker,
            window.ui.pointSizeLabel,
            window.point_size,
            window.ui.pointAlphaLabel,
            window.point_alpha,
        )
        line_widgets = (
            window.ui.xyLineWidthLabel,
            window.xy_line_width,
            window.ui.xyLineStyleLabel,
            window.xy_line_style,
        )

        for name, show_points, show_lines in (
            ("scatter-only", True, False),
            ("line-only", False, True),
            ("points-and-line", True, True),
        ):
            with self.subTest(mode=name):
                self.set_xy_display_controls(
                    window,
                    show_points=show_points,
                    show_lines=show_lines,
                )

                self.assertTrue(window.show_points.isEnabled())
                self.assertTrue(window.xy_show_line.isEnabled())
                self.assertTrue(
                    all(widget.isEnabled() == show_points for widget in point_widgets)
                )
                self.assertTrue(
                    all(widget.isEnabled() == show_lines for widget in line_widgets)
                )

    def test_xy_style_controls_account_for_visible_per_series_overrides(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        xy_settings.series = [
            XYSeriesSpec(
                id="override",
                name="Override",
                y_column_id="y",
                show_points=True,
                show_line=True,
            )
        ]

        self.set_xy_display_controls(
            window,
            show_points=False,
            show_lines=False,
        )

        self.assertTrue(window.xy_marker.isEnabled())
        self.assertTrue(window.point_size.isEnabled())
        self.assertTrue(window.point_alpha.isEnabled())
        self.assertTrue(window.xy_line_width.isEnabled())
        self.assertTrue(window.xy_line_style.isEnabled())

    def test_xy_plot_area_falls_back_to_all_settings_without_chart_style_context(self):
        window = self.make_xy_window()

        window.handle_plot_object_selection("plot_area")

        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: All settings",
        )
        self.assertFalse(window.ui.inspectorShowAllButton.isEnabled())
        self.assertTrue(window.ui.specificGroup.isHidden())
        self.assertEqual(
            {
                group
                for group in window._inspector_groups()
                if not group.isHidden()
            },
            window._mode_inspector_groups(),
        )

    def test_xy_points_context_uses_all_series_wording_and_group(self):
        window = self.make_xy_window()

        window.handle_plot_object_selection("points")

        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: All series",
        )
        self.assertEqual(
            {
                group
                for group in window._inspector_groups()
                if not group.isHidden()
            },
            {window.ui.pointsGroup},
        )

    def test_xy_point_and_line_artists_select_the_series_style_context(self):
        window = self.make_xy_window()
        frame = pd.DataFrame(
            {
                "X": [0.0, 1.0, 2.0],
                "Y": [0.0, 1.0, 0.0],
            }
        )

        for name, show_points, show_lines in (
            ("scatter-only", True, False),
            ("line-only", False, True),
            ("points-and-line", True, True),
        ):
            with self.subTest(mode=name):
                xy_settings = XYSettings(
                    default_x_column_id="x",
                    show_points=show_points,
                    show_line=show_lines,
                    series=[
                        XYSeriesSpec(
                            id="series-one",
                            name="Series one",
                            y_column_id="y",
                        )
                    ],
                )
                window.workbook.active_sheet.xy_settings = xy_settings
                window.canvas.render(
                    frame,
                    window.settings,
                    xy_settings=xy_settings,
                    column_ids=["x", "y"],
                )
                axis = window.canvas.figure.axes[0]
                display_x, display_y = axis.transData.transform((1.0, 1.0))
                event = SimpleNamespace(
                    x=float(display_x),
                    y=float(display_y),
                    button=1,
                )

                window.canvas._handle_plot_click(event)

                self.assertEqual(window.canvas._selected_object_kind, "points")
                self.assertEqual(
                    window.canvas._selected_series_id,
                    "series-one",
                )
                self.assertEqual(
                    window.ui.inspectorContextLabel.text(),
                    "Editing: Series one",
                )
                self.assertIsNotNone(window.canvas._selected_feedback_patch)

    def test_xy_plot_single_and_double_click_focus_single_series_style(self):
        window = self.make_xy_window()
        frame = pd.DataFrame(
            {
                "X": [0.0, 1.0, 2.0],
                "A": [0.0, 0.0, 0.0],
                "B": [1.0, 2.0, 1.0],
            }
        )
        xy_settings = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=True,
            series=[
                XYSeriesSpec(id="a", name="Series A", y_column_id="a"),
                XYSeriesSpec(id="b", name="Series B", y_column_id="b"),
            ],
        )
        window.workbook.active_sheet.xy_settings = xy_settings
        window.canvas.render(
            frame,
            window.settings,
            xy_settings=xy_settings,
            column_ids=["x", "a", "b"],
        )
        display_x, display_y = window.canvas.figure.axes[0].transData.transform(
            (1.0, 2.0)
        )

        window.canvas._handle_plot_click(
            SimpleNamespace(
                x=float(display_x),
                y=float(display_y),
                button=1,
            )
        )

        self.assertEqual(window.canvas._selected_series_id, "b")
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: Series B",
        )
        self.assertEqual(len(window.canvas._selected_feedback_patch), 2)
        self.assertEqual(
            {
                feedback._easygraph_feedback_source._easygraph_series_id
                for feedback in window.canvas._selected_feedback_patch
            },
            {"b"},
        )
        self.assertFalse(window.use_all_series_style_button.isHidden())

        window.canvas._handle_plot_click(
            SimpleNamespace(
                x=float(display_x),
                y=float(display_y),
                button=1,
                dblclick=True,
            )
        )

        self.assertEqual(window.canvas._selected_series_id, "b")
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: Series B",
        )
        self.assertEqual(len(window.canvas._selected_feedback_patch), 2)
        self.assertEqual(
            {
                feedback._easygraph_feedback_source._easygraph_series_id
                for feedback in window.canvas._selected_feedback_patch
            },
            {"b"},
        )
        self.assertFalse(window.use_all_series_style_button.isHidden())

    def test_xy_double_clicked_series_scope_loads_and_writes_only_overrides(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        xy_settings.show_points = True
        xy_settings.show_line = True
        xy_settings.point_size = 4.0
        xy_settings.point_alpha = 0.75
        xy_settings.marker = "Circle"
        xy_settings.line_width = 1.6
        xy_settings.line_style = "Solid"
        selected = XYSeriesSpec(
            id="selected",
            name="Selected series",
            y_column_id="selected-y",
            marker="Diamond",
        )
        xy_settings.series = [selected]
        window.canvas._selected_object_kind = "points"
        window.canvas._selected_series_id = selected.id

        window.handle_plot_object_selection("points")

        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: Selected series",
        )
        self.assertEqual(window.xy_marker.currentText(), "Diamond")
        self.assertEqual(window.point_size.value(), 4.0)
        self.assertFalse(window.use_all_series_style_button.isHidden())

        with mock.patch.object(window, "schedule_render"):
            window.point_size.setValue(7.0)

        self.assertEqual(selected.point_size, 7.0)
        self.assertEqual(xy_settings.point_size, 4.0)
        self.assertEqual(selected.marker, "Diamond")
        self.assertIsNone(selected.point_alpha)
        self.assertIsNone(selected.line_width)

        with mock.patch.object(window, "schedule_render"):
            window.show_grid.setChecked(not window.show_grid.isChecked())

        self.assertIsNone(selected.point_alpha)
        self.assertIsNone(selected.line_width)
        self.assertIsNone(selected.line_style)

    def test_xy_rerender_refreshes_the_selected_series_name_in_context(self):
        window = self.make_xy_window()
        sheet = window.workbook.active_sheet
        selected = XYSeriesSpec(
            id="selected",
            name="Old name",
            y_column_id="selected-y",
        )
        sheet.xy_settings.series = [selected]
        window.canvas._selected_object_kind = "points"
        window.canvas._selected_series_id = selected.id
        window.handle_plot_object_selection("points")
        self.assertEqual(window.ui.inspectorContextLabel.text(), "Editing: Old name")
        self.assertEqual(
            self.xy_selection_item(window, selected.id).text(),
            "Old name",
        )

        selected.name = "New name"
        with mock.patch.object(
            window,
            "table_dataframe",
            return_value=sheet.dataframe.copy(deep=True),
        ), mock.patch.object(window, "refresh_analysis_results"), mock.patch.object(
            window.canvas,
            "render",
        ), mock.patch.object(window, "_sync_auto_y_axis_controls"), mock.patch.object(
            window,
            "_sync_auto_tick_interval_controls",
        ):
            window.render()

        self.assertEqual(window.ui.inspectorContextLabel.text(), "Editing: New name")
        self.assertEqual(
            self.xy_selection_item(window, selected.id).text(),
            "New name",
        )

    def test_xy_all_series_scope_changes_only_the_edited_global_field(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        first = XYSeriesSpec(
            id="first",
            name="First",
            y_column_id="first-y",
            point_size=8.0,
            line_width=2.0,
        )
        second = XYSeriesSpec(
            id="second",
            name="Second",
            y_column_id="second-y",
            point_size=9.0,
            line_width=3.0,
        )
        xy_settings.series = [first, second]
        window.canvas._selected_object_kind = "points"
        window.canvas._selected_series_id = None

        window.handle_plot_object_selection("points")
        with mock.patch.object(window, "schedule_render"):
            window.point_size.setValue(6.0)

        self.assertEqual(xy_settings.point_size, 6.0)
        self.assertIsNone(first.point_size)
        self.assertIsNone(second.point_size)
        self.assertEqual(first.line_width, 2.0)
        self.assertEqual(second.line_width, 3.0)
        self.assertTrue(window.use_all_series_style_button.isHidden())

    def test_xy_all_series_visibility_change_keeps_hidden_series_showable(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        xy_settings.show_points = True
        xy_settings.show_line = True
        hidden = XYSeriesSpec(
            id="hidden",
            name="Hidden",
            y_column_id="hidden-y",
            visible=False,
            show_line=False,
        )
        xy_settings.series = [hidden]
        window.canvas._selected_object_kind = "points"
        window.canvas._selected_series_id = None
        window.handle_plot_object_selection("points")

        with mock.patch.object(window, "schedule_render"):
            window.show_points.setChecked(False)

        self.assertFalse(xy_settings.show_points)
        self.assertTrue(xy_settings.show_line)
        self.assertIsNone(hidden.show_points)
        self.assertIsNone(hidden.show_line)
        hidden.visible = True
        xy_settings.__post_init__()

    def test_xy_single_series_reset_clears_all_style_overrides(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        selected = XYSeriesSpec(
            id="selected",
            name="Selected",
            y_column_id="selected-y",
            color="#E15759",
            show_points=False,
            show_line=True,
            marker="Square",
            line_style="Dashed",
            point_size=7.0,
            point_alpha=0.4,
            line_width=2.8,
        )
        xy_settings.series = [selected]
        window.canvas._selected_object_kind = "points"
        window.canvas._selected_series_id = selected.id
        window.handle_plot_object_selection("points")

        with mock.patch.object(window, "schedule_render"):
            window.use_all_series_style_button.click()

        for field in window._xy_series_style_fields():
            self.assertIsNone(getattr(selected, field), field)
        self.assertIsNone(selected.color)
        self.assertEqual(window.show_points.isChecked(), xy_settings.show_points)
        self.assertEqual(window.xy_show_line.isChecked(), xy_settings.show_line)
        self.assertEqual(window.point_size.value(), xy_settings.point_size)
        self.assertEqual(window.xy_marker.currentText(), xy_settings.marker)

    def test_xy_series_checklist_includes_hidden_series_and_keeps_selection_scope(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        xy_settings.series = [
            XYSeriesSpec(id="visible", name="Visible", y_column_id="visible-y"),
            XYSeriesSpec(
                id="hidden",
                name="Hidden",
                y_column_id="hidden-y",
                visible=False,
            ),
        ]
        self.set_xy_series_selection(window, "all")

        self.assertEqual(window.xy_series_selection_list.count(), 2)
        self.assertEqual(
            window.xy_series_selection_count_label.text(),
            "Selected 2/2",
        )
        hidden_item = self.xy_selection_item(window, "hidden")
        self.assertEqual(hidden_item.checkState(), Qt.CheckState.Checked)
        self.assertTrue(hidden_item.flags() & Qt.ItemFlag.ItemIsEnabled)
        self.assertEqual(
            hidden_item.foreground().color(),
            window.palette().color(
                QPalette.ColorGroup.Disabled,
                QPalette.ColorRole.Text,
            ),
        )

        window.ui.xySeriesClearSelectionButton.click()

        self.assertEqual(window.canvas._xy_selection_scope, "subset")
        self.assertEqual(tuple(window.canvas._selected_series_ids), ())
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: No series selected",
        )
        self.assertFalse(window.ui.pointsGroup.isHidden())
        self.assertFalse(window.xy_no_series_selected_label.isHidden())
        for field in window._xy_series_style_fields():
            self.assertFalse(
                window._xy_style_control_for_field(field).isEnabled(),
                field,
            )

        for series_id in ("visible", "hidden"):
            self.xy_selection_item(window, series_id).setCheckState(
                Qt.CheckState.Checked
            )

        self.assertEqual(window.canvas._xy_selection_scope, "subset")
        self.assertEqual(
            set(window.canvas._selected_series_ids),
            {"visible", "hidden"},
        )
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: 2 series",
        )
        window.ui.xySeriesSelectAllButton.click()
        self.assertEqual(window.canvas._xy_selection_scope, "all")
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: All series",
        )

    def test_xy_multi_series_mixed_controls_write_only_the_touched_fields(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        first = XYSeriesSpec(
            id="first",
            name="First",
            y_column_id="first-y",
            show_points=True,
            show_line=False,
            marker="Square",
            point_size=5.0,
            line_width=2.0,
        )
        second = XYSeriesSpec(
            id="second",
            name="Second",
            y_column_id="second-y",
            show_points=False,
            show_line=True,
            marker="Diamond",
            point_size=7.0,
            line_width=3.0,
        )
        xy_settings.series = [first, second]
        xy_settings.__post_init__()
        self.set_xy_series_selection(window, "subset", ("first", "second"))

        self.assertEqual(
            window.show_points.checkState(),
            Qt.CheckState.PartiallyChecked,
        )
        self.assertEqual(
            window.xy_show_line.checkState(),
            Qt.CheckState.PartiallyChecked,
        )
        self.assertEqual(window.xy_marker.currentData(), "__easygraph_xy_mixed__")
        window.show()
        self.qapp.processEvents()
        self.assertEqual(window.point_size.text(), "Mixed")
        self.assertEqual(window.point_size.lineEdit().text(), "Mixed")

        with mock.patch.object(window, "schedule_render"):
            window.xy_marker.setCurrentText("Triangle")

        self.assertEqual(first.marker, "Triangle")
        self.assertEqual(second.marker, "Triangle")
        self.assertEqual(first.point_size, 5.0)
        self.assertEqual(second.point_size, 7.0)
        self.assertEqual(first.line_width, 2.0)
        self.assertEqual(second.line_width, 3.0)
        self.assertTrue(first.show_points)
        self.assertFalse(second.show_points)

        with mock.patch.object(window, "schedule_render"):
            window.point_size.setValue(8.0)

        self.assertEqual(first.point_size, 8.0)
        self.assertEqual(second.point_size, 8.0)
        self.assertEqual(first.line_width, 2.0)
        self.assertEqual(second.line_width, 3.0)

    def test_xy_subset_all_writes_overrides_while_all_scope_writes_global(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        xy_settings.line_width = 1.6
        first = XYSeriesSpec(id="first", name="First", y_column_id="first-y")
        second = XYSeriesSpec(id="second", name="Second", y_column_id="second-y")
        xy_settings.series = [first, second]
        self.set_xy_series_selection(window, "subset", ("first", "second"))

        with mock.patch.object(window, "schedule_render"):
            window.xy_line_width.setValue(2.8)

        self.assertEqual(xy_settings.line_width, 1.6)
        self.assertEqual(first.line_width, 2.8)
        self.assertEqual(second.line_width, 2.8)
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: 2 series",
        )

        window.ui.xySeriesSelectAllButton.click()
        with mock.patch.object(window, "schedule_render"):
            window.xy_line_width.setValue(3.2)

        self.assertEqual(xy_settings.line_width, 3.2)
        self.assertIsNone(first.line_width)
        self.assertIsNone(second.line_width)
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: All series",
        )

    def test_xy_batch_visibility_change_normalizes_each_selected_series_atomically(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        visible = XYSeriesSpec(
            id="visible",
            name="Visible",
            y_column_id="visible-y",
            show_line=False,
        )
        hidden = XYSeriesSpec(
            id="hidden",
            name="Hidden",
            y_column_id="hidden-y",
            visible=False,
            show_line=False,
        )
        xy_settings.series = [visible, hidden]
        xy_settings.__post_init__()
        self.set_xy_series_selection(window, "subset", ("visible", "hidden"))

        with mock.patch.object(window, "schedule_render"):
            window.show_points.setChecked(False)

        for series in (visible, hidden):
            self.assertFalse(series.show_points)
            self.assertTrue(series.show_line)
        xy_settings.__post_init__()

    def test_xy_reset_clears_overrides_for_every_selected_series_only(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        selected = [
            XYSeriesSpec(
                id="first",
                name="First",
                y_column_id="first-y",
                color="#E15759",
                marker="Square",
                point_size=6.0,
            ),
            XYSeriesSpec(
                id="second",
                name="Second",
                y_column_id="second-y",
                color="#59A14F",
                line_style="Dotted",
                line_width=2.4,
            ),
        ]
        untouched = XYSeriesSpec(
            id="third",
            name="Third",
            y_column_id="third-y",
            color="#F28E2B",
            marker="Diamond",
        )
        xy_settings.series = [*selected, untouched]
        self.set_xy_series_selection(window, "subset", ("first", "second"))

        with mock.patch.object(window, "schedule_render"):
            window.use_all_series_style_button.click()

        for series in selected:
            self.assertIsNone(series.color)
            for field in window._xy_series_style_fields():
                self.assertIsNone(getattr(series, field), field)
        self.assertEqual(untouched.color, "#F28E2B")
        self.assertEqual(untouched.marker, "Diamond")

    def test_xy_checklist_uses_the_rendered_color_after_a_hidden_first_series(self):
        window = self.make_xy_window()
        frame = pd.DataFrame(
            {
                "X": [0.0, 1.0],
                "Hidden": [2.0, 3.0],
                "Visible": [4.0, 5.0],
            }
        )
        xy_settings = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(
                    id="hidden",
                    name="Hidden",
                    y_column_id="hidden-y",
                    visible=False,
                ),
                XYSeriesSpec(
                    id="visible",
                    name="Visible",
                    y_column_id="visible-y",
                ),
            ],
        )
        window.workbook.active_sheet.xy_settings = xy_settings
        window.canvas.render(
            frame,
            window.settings,
            xy_settings=xy_settings,
            column_ids=["x", "hidden-y", "visible-y"],
        )
        window._refresh_xy_series_selection_list()

        actual = window._canvas_xy_series_color("visible")
        icon_color = (
            self.xy_selection_item(window, "visible")
            .icon()
            .pixmap(12, 12)
            .toImage()
            .pixelColor(6, 6)
        )
        self.assertTrue(actual.isValid())
        self.assertEqual(icon_color.name(), actual.name())
        self.assertNotEqual(
            icon_color.name(),
            QColor("#E15759").name(),
        )

    def test_xy_chart_elements_visibility_remains_global_in_series_scope(self):
        window = self.make_xy_window()
        xy_settings = window.workbook.active_sheet.xy_settings
        selected = XYSeriesSpec(
            id="selected",
            name="Selected",
            y_column_id="selected-y",
            show_points=False,
            line_width=3.0,
        )
        xy_settings.series = [selected]
        window.canvas._selected_object_kind = "points"
        window.canvas._selected_series_id = selected.id
        window.handle_plot_object_selection("points")
        points_action = window.chart_element_actions["points"]

        window.chart_elements_menu.aboutToShow.emit()
        self.assertTrue(points_action.isChecked())
        self.assertFalse(window.show_points.isChecked())

        with mock.patch.object(window, "schedule_render"):
            points_action.trigger()

        self.assertFalse(xy_settings.show_points)
        self.assertIsNone(selected.show_points)
        self.assertEqual(selected.line_width, 3.0)

    def test_xy_numeric_x_axis_controls_round_trip_and_follow_auto_toggles(self):
        window = self.make_xy_window()
        settings = window.settings
        settings.auto_x_range = False
        settings.x_min = -2.5
        settings.x_max = 8.5
        settings.x_auto_tick_interval = False
        settings.x_tick_interval = 0.75

        window.apply_settings_to_controls()

        self.assertFalse(window.auto_x_range.isChecked())
        self.assertEqual(window.x_min.value(), -2.5)
        self.assertEqual(window.x_max.value(), 8.5)
        self.assertFalse(window.x_auto_tick_interval.isChecked())
        self.assertEqual(window.x_tick_interval.value(), 0.75)
        for widget in (
            window.ui.xMinLabel,
            window.x_min,
            window.ui.xMaxLabel,
            window.x_max,
            window.ui.xTickIntervalLabel,
            window.x_tick_interval,
        ):
            self.assertTrue(widget.isEnabled(), widget.objectName())

        window.auto_x_range.setChecked(True)
        window.x_auto_tick_interval.setChecked(True)
        window._update_dependent_control_states()

        for widget in (
            window.ui.xMinLabel,
            window.x_min,
            window.ui.xMaxLabel,
            window.x_max,
            window.ui.xTickIntervalLabel,
            window.x_tick_interval,
        ):
            self.assertFalse(widget.isEnabled(), widget.objectName())

        window._applying_settings = True
        try:
            window.auto_x_range.setChecked(False)
            window.x_min.setValue(-4.0)
            window.x_max.setValue(12.0)
            window.x_auto_tick_interval.setChecked(False)
            window.x_tick_interval.setValue(1.25)
        finally:
            window._applying_settings = False
        with mock.patch.object(window, "schedule_render"):
            window.update_settings()

        self.assertFalse(settings.auto_x_range)
        self.assertEqual(settings.x_min, -4.0)
        self.assertEqual(settings.x_max, 12.0)
        self.assertFalse(settings.x_auto_tick_interval)
        self.assertEqual(settings.x_tick_interval, 1.25)

    def test_xy_auto_x_controls_sync_to_rendered_axis_and_safe_tick_fallback(self):
        window = self.make_xy_window()
        frame = pd.DataFrame(
            {
                "X": [2.0, 4.0, 8.0],
                "Y": [1.0, 3.0, 2.0],
            }
        )
        xy_settings = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=False,
            series=[
                XYSeriesSpec(
                    id="series-one",
                    name="Series one",
                    y_column_id="y",
                )
            ],
        )
        settings = window.settings
        settings.auto_x_range = True
        settings.x_auto_tick_interval = True
        window.apply_settings_to_controls()

        window.canvas.render(
            frame,
            settings,
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )
        window._sync_auto_y_axis_controls()
        window._sync_auto_tick_interval_controls()

        axis = window.canvas.figure.axes[0]
        x_min, x_max = axis.get_xlim()
        expected_interval = window._auto_tick_interval_for_axis(
            axis,
            dimension="x",
        )
        self.assertAlmostEqual(window.x_min.value(), x_min)
        self.assertAlmostEqual(window.x_max.value(), x_max)
        self.assertAlmostEqual(settings.x_min, x_min)
        self.assertAlmostEqual(settings.x_max, x_max)
        self.assertIsNotNone(expected_interval)
        self.assertAlmostEqual(window.x_tick_interval.value(), expected_interval)
        self.assertAlmostEqual(settings.x_tick_interval, expected_interval)

        settings.auto_x_range = False
        settings.x_min = 0.0
        settings.x_max = 10_000.0
        settings.x_auto_tick_interval = False
        settings.x_tick_interval = 0.000001
        window.apply_settings_to_controls()
        window.canvas.render(
            frame,
            settings,
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )
        window._sync_auto_tick_interval_controls()

        self.assertTrue(window.x_auto_tick_interval.isChecked())
        self.assertTrue(settings.x_auto_tick_interval)
        self.assertFalse(window.x_tick_interval.isEnabled())
        self.assertGreater(window.x_tick_interval.value(), 0.000001)

    def test_xy_auto_x_sync_does_not_round_a_small_axis_back_onto_the_plot(self):
        window = self.make_xy_window()
        frame = pd.DataFrame(
            {
                "X": [0.00000001, 0.00000002],
                "Y": [1.0, 2.0],
            }
        )
        xy_settings = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=False,
            series=[
                XYSeriesSpec(
                    id="series-one",
                    name="Series one",
                    y_column_id="y",
                )
            ],
        )
        settings = window.settings
        settings.auto_x_range = True
        window.apply_settings_to_controls()
        window.canvas.render(
            frame,
            settings,
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )
        before = window.canvas.figure.axes[0].get_xlim()

        window._sync_auto_y_axis_controls()

        after = window.canvas.figure.axes[0].get_xlim()
        self.assertEqual(after, before)
        self.assertLess(after[0], 0.00000001)
        self.assertGreater(after[1], 0.00000002)
        self.assertEqual((settings.x_min, settings.x_max), before)
        self.assertGreaterEqual(window.x_min.decimals(), 9)
        self.assertGreaterEqual(window.x_max.decimals(), 9)

    def test_xy_auto_x_sync_preserves_a_narrow_range_with_a_large_offset(self):
        window = self.make_xy_window()
        frame = pd.DataFrame(
            {
                "X": [1_000_000.00000001, 1_000_000.00000002],
                "Y": [1.0, 2.0],
            }
        )
        xy_settings = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=False,
            series=[
                XYSeriesSpec(
                    id="series-one",
                    name="Series one",
                    y_column_id="y",
                )
            ],
        )
        settings = window.settings
        settings.auto_x_range = True
        window.apply_settings_to_controls()
        window.canvas.render(
            frame,
            settings,
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )
        rendered_limits = window.canvas.figure.axes[0].get_xlim()

        window._sync_auto_y_axis_controls()

        self.assertLess(window.x_min.value(), window.x_max.value())
        self.assertGreaterEqual(window.x_min.decimals(), 10)
        self.assertGreaterEqual(window.x_max.decimals(), 10)
        self.assertEqual((settings.x_min, settings.x_max), rendered_limits)

        window._applying_settings = True
        try:
            window.auto_x_range.setChecked(False)
        finally:
            window._applying_settings = False
        with mock.patch.object(window, "schedule_render"):
            window.update_settings()

        self.assertFalse(settings.auto_x_range)
        self.assertLess(settings.x_min, settings.x_max)
        self.assertAlmostEqual(settings.x_min, rendered_limits[0], places=9)
        self.assertAlmostEqual(settings.x_max, rendered_limits[1], places=9)

    def test_chart_elements_lines_action_tracks_xy_line_visibility(self):
        window = self.make_xy_window()
        action = window.chart_element_actions["lines"]

        window.chart_elements_menu.aboutToShow.emit()

        self.assertTrue(action.isVisible())
        self.assertTrue(action.isCheckable())
        self.assertEqual(action.isChecked(), window.xy_show_line.isChecked())

        action.trigger()

        self.assertFalse(window.xy_show_line.isChecked())
        self.assertFalse(window.workbook.active_sheet.xy_settings.show_line)
        window.chart_elements_menu.aboutToShow.emit()
        self.assertFalse(action.isChecked())

        with mock.patch.object(window, "render"):
            window.switch_sheet(0)

        self.assertFalse(action.isVisible())


if __name__ == "__main__":
    __import__("unittest").main()
