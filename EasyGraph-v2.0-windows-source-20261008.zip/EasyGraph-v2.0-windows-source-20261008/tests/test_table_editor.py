from PySide6.QtCore import Qt

from tests.easygraph_case import EasyGraphTestCase
from easygraph.table_editor import navigation_delta, next_table_cell


class TableEditorTests(EasyGraphTestCase):
    def test_navigation_delta_maps_direction_and_return_keys(self):
        self.assertEqual(navigation_delta(Qt.Key_Left), (0, -1))
        self.assertEqual(navigation_delta(Qt.Key_Right), (0, 1))
        self.assertEqual(navigation_delta(Qt.Key_Up), (-1, 0))
        self.assertEqual(navigation_delta(Qt.Key_Down), (1, 0))
        self.assertEqual(navigation_delta(Qt.Key_Return), (1, 0))
        self.assertEqual(navigation_delta(Qt.Key_Enter), (1, 0))

    def test_navigation_delta_returns_none_for_unhandled_key(self):
        self.assertIsNone(navigation_delta(Qt.Key_Tab))

    def test_next_table_cell_returns_target_when_inside_bounds(self):
        self.assertEqual(next_table_cell(1, 2, 4, 5, (1, 0)), (2, 2))
        self.assertEqual(next_table_cell(1, 2, 4, 5, (0, -1)), (1, 1))

    def test_next_table_cell_rejects_targets_outside_bounds(self):
        self.assertIsNone(next_table_cell(0, 0, 4, 5, (-1, 0)))
        self.assertIsNone(next_table_cell(3, 4, 4, 5, (0, 1)))
        self.assertIsNone(next_table_cell(-1, 0, 4, 5, (1, 0)))
        self.assertIsNone(next_table_cell(0, 0, 0, 5, (1, 0)))
