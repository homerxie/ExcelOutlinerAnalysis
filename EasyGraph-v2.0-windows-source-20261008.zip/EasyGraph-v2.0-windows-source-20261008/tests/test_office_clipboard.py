"""Clipboard MIME and grouping regressions for copying tables to/from Office."""
from __future__ import annotations

from dataclasses import asdict

import pandas as pd
from PySide6.QtCore import QMimeData, QPoint, Qt
from PySide6.QtGui import QKeySequence
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from easygraph.clipboard_table import CellMerge, clipboard_table_from_html
from tests.easygraph_case import EasyGraphQtTestCase


class OfficeClipboardTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.addCleanup(QApplication.clipboard().clear)

    def make_grouped_window(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame(
            [["25%", "50%", "3", "4"], ["80％", "12.5 %", "7", "8"]],
            columns=["Control", "Drug", "Control", "Drug"],
        ))
        for first, last, name in ((0, 1, "WT"), (2, 2, "KO"), (3, 3, "WT")):
            window.table.horizontalHeader().clear_parent_selection()
            self.select_table_range(window.table, 0, first, 0, last)
            self.assertTrue(window.grouping_controls.create_selected_parent(name))
        window.table.clearSelection()
        return window

    def copied_table(self):
        mime = QApplication.clipboard().mimeData()
        self.assertTrue(mime.hasText())
        self.assertTrue(mime.hasHtml())
        data = clipboard_table_from_html(mime.html())
        self.assertIsNotNone(data)
        return data

    @staticmethod
    def put_excel_table_on_clipboard():
        # Excel supplies both flavors. Plain text cannot describe merge ranges.
        mime = QMimeData()
        mime.setText("WT\t\tKO\tWT\nControl\tDrug\tControl\tDrug\n25%\t50%\t3\t4")
        mime.setHtml(
            '<html xmlns:x="urn:schemas-microsoft-com:office:excel"><body>'
            '<!--StartFragment--><table><tr><td colspan="2">WT</td>'
            '<td>KO</td><td>WT</td></tr><tr><td>Control</td><td>Drug</td>'
            '<td>Control</td><td>Drug</td></tr><tr><td x:num="0.25">25%</td>'
            '<td x:num="0.5">50%</td><td>3</td><td>4</td></tr></table>'
            '<!--EndFragment--></body></html>'
        )
        QApplication.clipboard().setMimeData(mime)

    def assert_expected_parents(self, window):
        sheet = window.workbook.active_sheet
        parents = sheet.grouping.parents
        self.assertEqual([parent["name"] for parent in parents], ["WT", "KO", "WT"])
        self.assertEqual(
            [parent["column_ids"] for parent in parents],
            [sheet.column_ids[:2], sheet.column_ids[2:3], sheet.column_ids[3:4]],
        )
        self.assertEqual(len({parent["id"] for parent in parents}), 3)

    def test_parent_band_copy_uses_header_selection_and_preserves_merged_cells(self):
        window = self.make_grouped_window()
        table = window.table
        table.setCurrentIndex(table.table_model.index(window.sample_start_row(), 3))
        table.horizontalHeader().select_parent_columns([0, 3])
        window.table_tools.activate(table)

        self.assertTrue(window.ui.tableCopyButton.isEnabled())
        window.ui.tableCopyButton.click()

        self.assertEqual(QApplication.clipboard().text(), "WT\t\tKO\tWT")
        copied = self.copied_table()
        self.assertEqual(copied.rows, [["WT", "", "KO", "WT"]])
        self.assertEqual(copied.merges, [CellMerge(0, 0, colspan=2)])
        self.assertEqual(copied.header_rows, 1)

    def test_parent_header_keyboard_copy_and_paste_keep_header_target(self):
        window = self.make_grouped_window()
        window.resize(1600, 900)
        window.show()
        self.qapp.processEvents()
        table = window.table
        before_cells = table.table_model.cells_copy()
        table.setCurrentIndex(table.table_model.index(window.sample_start_row(), 3))
        header = table.horizontalHeader()
        # Setting the old cell can scroll the first leaf out of view while its
        # merged parent remains visible. Click the visible part of that parent.
        parent_rect = next(header.group_rects())[2]
        point = parent_rect.intersected(header.viewport().rect()).center()
        QTest.mouseClick(header.viewport(), Qt.LeftButton, Qt.NoModifier, point)
        self.assertEqual(header.selected_parent_columns(), [0, 1])

        QTest.keySequence(table, QKeySequence(QKeySequence.Copy))

        self.assertEqual(QApplication.clipboard().text(), "WT\t")
        self.assertEqual(self.copied_table().merges, [CellMerge(0, 0, colspan=2)])
        QApplication.clipboard().setText("Keyboard name")
        QTest.keySequence(table, QKeySequence(QKeySequence.Paste))

        self.assertEqual(table.table_model.cells_copy(), before_cells)
        parent = window.workbook.active_sheet.grouping.parents[0]
        self.assertEqual(parent["name"], "Keyboard name")
        self.assertEqual(parent["column_ids"], window.workbook.active_sheet.column_ids[:2])

    def test_copy_with_leaf_headers_includes_parent_row_and_percentage_text(self):
        window = self.make_grouped_window()
        self.select_table_range(window.table, 0, 0, window.sample_start_row() + 1, 3)

        window.copy_table_selection(window.table)

        copied = self.copied_table()
        self.assertEqual(copied.rows, [
            ["WT", "", "KO", "WT"],
            ["Control", "Drug", "Control", "Drug"],
            ["25%", "50%", "3", "4"],
            ["80％", "12.5 %", "7", "8"],
        ])
        self.assertEqual(copied.merges, [CellMerge(0, 0, colspan=2)])
        self.assertEqual(copied.header_rows, 2)
        self.assertEqual(QApplication.clipboard().text().splitlines()[0], "WT\t\tKO\tWT")

    def test_copy_sample_cells_does_not_prepend_headers(self):
        window = self.make_grouped_window()
        row = window.sample_start_row()
        self.select_table_range(window.table, row, 0, row, 1)

        window.copy_table_selection(window.table)

        copied = self.copied_table()
        self.assertEqual(copied.rows, [["25%", "50%"]])
        self.assertEqual(copied.merges, [])
        self.assertEqual(QApplication.clipboard().text(), "25%\t50%")

    def test_copy_whole_table_omits_automatic_spare_column(self):
        window = self.make_grouped_window()
        self.assertTrue(window._group_last_column_is_auto_spare())
        window.table.selectAll()

        window.copy_table_selection(window.table)

        copied = self.copied_table()
        self.assertEqual(copied.rows[:2], [
            ["WT", "", "KO", "WT"],
            ["Control", "Drug", "Control", "Drug"],
        ])
        self.assertTrue(all(len(row) == 4 for row in copied.rows))
        self.assertEqual(copied.merges, [CellMerge(0, 0, colspan=2)])

    def test_select_all_after_parent_selection_copies_headers_and_data(self):
        window = self.make_grouped_window()
        table = window.table
        window.show()
        table.setFocus()
        table.horizontalHeader().select_parent_columns([0])

        QTest.keySequence(table, QKeySequence(QKeySequence.SelectAll))
        window.copy_table_selection(table)

        copied = self.copied_table()
        self.assertEqual(copied.header_rows, 2)
        self.assertEqual(copied.rows[2], ["25%", "50%", "3", "4"])
        self.assertEqual(copied.merges, [CellMerge(0, 0, colspan=2)])

    def test_paste_excel_preserves_parents_singletons_duplicate_names_and_one_step_undo(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Old": ["old value"]}))
        before_cells = window.table.table_model.cells_copy()
        before_grouping = asdict(window.workbook.active_sheet.grouping)
        window._table_controller.reset_history()
        window.table.setCurrentIndex(window.table.table_model.index(0, 0))
        self.put_excel_table_on_clipboard()

        window.paste_table_selection(window.table)

        self.assert_expected_parents(window)
        self.assertEqual(window.table_group_names(), ["Control", "Drug", "Control", "Drug"])
        self.assertEqual(
            [window.table.table_model.cell_text(window.sample_start_row(), col) for col in range(4)],
            ["25%", "50%", "3", "4"],
        )
        self.assertEqual(len(window._table_controller.history.undo_stack), 1)
        pasted_cells = window.table.table_model.cells_copy()
        pasted_grouping = asdict(window.workbook.active_sheet.grouping)

        window.undo_table_change()
        self.assertEqual(window.table.table_model.cells_copy(), before_cells)
        self.assertEqual(asdict(window.workbook.active_sheet.grouping), before_grouping)
        window.redo_table_change()
        self.assertEqual(window.table.table_model.cells_copy(), pasted_cells)
        self.assertEqual(asdict(window.workbook.active_sheet.grouping), pasted_grouping)

    def test_excel_paste_then_copy_retains_merge_in_office_html(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Old": [""]}))
        window.table.setCurrentIndex(window.table.table_model.index(0, 0))
        self.put_excel_table_on_clipboard()
        window.paste_table_selection(window.table)
        self.select_table_range(window.table, 0, 0, window.sample_start_row(), 3)

        window.copy_table_selection(window.table)

        copied = self.copied_table()
        self.assertEqual(copied.rows, [
            ["WT", "", "KO", "WT"],
            ["Control", "Drug", "Control", "Drug"],
            ["25%", "50%", "3", "4"],
        ])
        self.assertEqual(copied.merges, [CellMerge(0, 0, colspan=2)])

    def test_plain_text_paste_into_parent_selection_edits_header_without_stale_sample(self):
        window = self.make_grouped_window()
        table = window.table
        before_cells = table.table_model.cells_copy()
        window._table_controller.reset_history()
        table.setCurrentIndex(table.table_model.index(window.sample_start_row(), 3))
        table.horizontalHeader().select_parent_columns([0])
        window.table_tools.activate(table)
        QApplication.clipboard().setText("New name")

        self.assertTrue(window.ui.tablePasteButton.isEnabled())
        window.ui.tablePasteButton.click()

        self.assertEqual(table.table_model.cells_copy(), before_cells)
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]["name"], "New name")
        self.assertEqual(len(window._table_controller.history.undo_stack), 1)
        window.undo_table_change()
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]["name"], "WT")

    def test_non_table_html_falls_back_to_plain_text(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Rate": [""]}))
        window.table.setCurrentIndex(window.table.table_model.index(window.sample_start_row(), 0))
        mime = QMimeData()
        mime.setText("25%")
        mime.setHtml("<p>25%</p>")
        QApplication.clipboard().setMimeData(mime)

        window.paste_table_selection(window.table)

        self.assertEqual(window.table.table_model.cell_text(window.sample_start_row(), 0), "25%")

    def test_ragged_plain_text_paste_keeps_cells_outside_supplied_values(self):
        window = self.make_grouped_window()
        table = window.table
        row = window.sample_start_row()
        table.setCurrentIndex(table.table_model.index(row, 0))
        QApplication.clipboard().setText("1\t2\n3")

        window.paste_table_selection(table)

        self.assertEqual(table.table_model.cell_text(row + 1, 0), "3")
        self.assertEqual(table.table_model.cell_text(row + 1, 1), "12.5 %")

    def test_regular_html_paste_into_samples_keeps_values_out_of_headers(self):
        window = self.make_grouped_window()
        window.table.setCurrentIndex(window.table.table_model.index(window.sample_start_row(), 0))
        before_grouping = asdict(window.workbook.active_sheet.grouping)
        mime = QMimeData()
        mime.setHtml("<table><tr><td>75%</td><td>90%</td></tr></table>")
        QApplication.clipboard().setMimeData(mime)

        window.paste_table_selection(window.table)

        self.assertEqual(window.table_group_names(), ["Control", "Drug", "Control", "Drug"])
        self.assertEqual(asdict(window.workbook.active_sheet.grouping), before_grouping)
        self.assertEqual(window.table.table_model.cell_text(window.sample_start_row(), 0), "75%")
        self.assertEqual(window.table.table_model.cell_text(window.sample_start_row(), 1), "90%")
