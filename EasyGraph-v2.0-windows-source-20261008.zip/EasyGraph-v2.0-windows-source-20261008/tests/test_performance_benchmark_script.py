from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from tests.easygraph_case import ROOT, EasyGraphTestCase


SCRIPT = ROOT / "scripts" / "benchmark_performance.py"
SCENARIOS = [
    "settings_table_overhead",
    "settings_update_fast_path",
    "render_box",
    "render_xy",
    "interaction_feedback",
    "quasirandom",
    "ridge_outliers",
    "prepare_plot_data",
    "table_history",
    "table_model",
    "spreadsheet_transform",
    "startup",
    "module_import",
]


class PerformanceBenchmarkScriptTests(EasyGraphTestCase):
    def run_script(self, *args: str) -> subprocess.CompletedProcess[str]:
        environment = os.environ.copy()
        environment["QT_QPA_PLATFORM"] = "offscreen"
        environment["MPLCONFIGDIR"] = str(Path(tempfile.gettempdir()) / "easygraph_matplotlib")
        return subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            cwd=ROOT,
            env=environment,
            capture_output=True,
            text=True,
            check=False,
            timeout=60,
        )

    def test_list_prints_stable_scenario_names_without_running_benchmarks(self):
        result = self.run_script("--list")

        self.assertEqual(result.returncode, 0, msg=result.stderr)
        self.assertEqual(result.stdout.splitlines(), SCENARIOS)

    def test_unknown_scenario_is_rejected(self):
        result = self.run_script("--scenario", "missing")

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("invalid choice", result.stderr)

    def test_invalid_repeat_counts_are_rejected(self):
        for arguments, message in [
            (("--warmups", "-1"), "non-negative integer"),
            (("--repeats", "0"), "positive integer"),
        ]:
            with self.subTest(arguments=arguments):
                result = self.run_script(*arguments)

                self.assertNotEqual(result.returncode, 0)
                self.assertIn(message, result.stderr)

    def test_quick_selected_scenario_writes_versioned_json_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "benchmark.json"
            result = self.run_script(
                "--scenario",
                "quasirandom",
                "--quick",
                "--warmups",
                "0",
                "--repeats",
                "1",
                "--json",
                str(output_path),
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            payload = json.loads(output_path.read_text(encoding="utf-8"))

        self.assertEqual(payload["schema_version"], 1)
        self.assertEqual(payload["config"], {"quick": True, "repeats": 1, "warmups": 0})
        self.assertIn("python", payload["environment"])
        self.assertIn("platform", payload["environment"])
        self.assertEqual(list(payload["scenarios"]), ["quasirandom"])
        cases = payload["scenarios"]["quasirandom"]
        self.assertEqual(len(cases), 1)
        self.assertEqual(cases[0]["parameters"], {"points": 1000})
        elapsed = cases[0]["metrics"]["elapsed_seconds"]
        self.assertEqual(elapsed["unit"], "seconds")
        self.assertEqual(len(elapsed["values"]), 1)
        self.assertEqual(elapsed["median"], elapsed["values"][0])
        self.assertEqual(elapsed["minimum"], elapsed["values"][0])

    def test_quick_xy_render_scenario_covers_shared_and_independent_x(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "benchmark.json"
            result = self.run_script(
                "--scenario",
                "render_xy",
                "--quick",
                "--warmups",
                "0",
                "--repeats",
                "1",
                "--json",
                str(output_path),
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            payload = json.loads(output_path.read_text(encoding="utf-8"))

        case = payload["scenarios"]["render_xy"][0]
        self.assertEqual(
            case["parameters"],
            {"rows": 200, "series": 6, "mapping": "mixed"},
        )
        self.assertGreaterEqual(case["metrics"]["artists_count"]["median"], 6)

    def test_repeated_scenario_arguments_preserve_registry_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "benchmark.json"
            result = self.run_script(
                "--scenario",
                "quasirandom",
                "--scenario",
                "prepare_plot_data",
                "--quick",
                "--warmups",
                "0",
                "--repeats",
                "1",
                "--json",
                str(output_path),
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            payload = json.loads(output_path.read_text(encoding="utf-8"))

        self.assertEqual(
            list(payload["scenarios"]),
            ["quasirandom", "prepare_plot_data"],
        )

    def test_quick_settings_fast_path_reports_debounced_render_counts(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "benchmark.json"
            result = self.run_script(
                "--scenario",
                "settings_update_fast_path",
                "--quick",
                "--warmups",
                "0",
                "--repeats",
                "1",
                "--json",
                str(output_path),
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            payload = json.loads(output_path.read_text(encoding="utf-8"))

        case = payload["scenarios"]["settings_update_fast_path"][0]
        self.assertEqual(
            case["parameters"],
            {"rows": 200, "columns": 10, "setting_changes": 20},
        )
        self.assertEqual(case["metrics"]["render_before_flush_count"]["median"], 0)
        self.assertEqual(case["metrics"]["render_after_flush_count"]["median"], 1)

    def test_quick_table_model_compares_bulk_model_with_legacy_items(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "benchmark.json"
            result = self.run_script(
                "--scenario",
                "table_model",
                "--quick",
                "--warmups",
                "0",
                "--repeats",
                "1",
                "--json",
                str(output_path),
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            payload = json.loads(output_path.read_text(encoding="utf-8"))

        case = payload["scenarios"]["table_model"][0]
        self.assertEqual(case["parameters"], {"rows": 200, "columns": 10})
        self.assertEqual(case["metrics"]["legacy_item_count"]["median"], 2010)
        self.assertEqual(case["metrics"]["model_item_count"]["median"], 0)

    def test_quick_startup_and_interaction_scenarios_report_stage_metrics(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "benchmark.json"
            result = self.run_script(
                "--scenario",
                "interaction_feedback",
                "--scenario",
                "startup",
                "--quick",
                "--warmups",
                "0",
                "--repeats",
                "1",
                "--json",
                str(output_path),
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            payload = json.loads(output_path.read_text(encoding="utf-8"))

        interaction = payload["scenarios"]["interaction_feedback"][0]
        startup = payload["scenarios"]["startup"][0]
        self.assertEqual(interaction["metrics"]["updates_count"]["median"], 20)
        self.assertIn("blit_to_full_draw_ratio", interaction["metrics"])
        self.assertIn("process_to_visible_seconds", startup["metrics"])
        self.assertIn("canvas_to_first_render_seconds", startup["metrics"])
