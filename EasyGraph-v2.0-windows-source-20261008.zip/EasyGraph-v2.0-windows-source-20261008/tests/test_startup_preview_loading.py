from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import mock

import pandas as pd

from easygraph.app_preferences import stored_recent_project_paths
from easygraph.project_io import write_project
from easygraph.settings import ChartSettings
from easygraph.ui.main_window import MainWindow
from easygraph.workbook import SHEET_MODE_GROUPS, SHEET_MODE_XY, WorkbookDocument
from tests.easygraph_case import EasyGraphQtTestCase, patch_qsettings


class StartupPreviewLoadingTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        preferences, _ = patch_qsettings()
        preferences.start()
        self.addCleanup(preferences.stop)
        templates = mock.patch.object(
            MainWindow, "_style_template_for_new_sheet", return_value=(None, None),
        )
        templates.start()
        self.addCleanup(templates.stop)
        directory = TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.directory = Path(directory.name)

    def make_deferred_window(self):
        window = MainWindow(initial_render=False, defer_preview=True)
        self.addCleanup(self.close_window_without_unsaved_prompt, window)
        return window

    @staticmethod
    def numeric_data(dataframe):
        return (
            dataframe.apply(pd.to_numeric, errors="coerce")
            .dropna(how="all")
            .dropna(axis=1, how="all")
        )

    def assert_deferred_project_preview(self, mode):
        window = self.make_deferred_window()
        saved = window._demo_sheet_document(
            mode, "Saved sheet", grouped_demo=mode == SHEET_MODE_GROUPS,
        )
        saved.settings.title = "Loaded project preview"
        other = window._demo_sheet_document(SHEET_MODE_GROUPS, "Inactive sheet")
        workbook = WorkbookDocument([other, saved], saved.id)
        path = self.directory / f"{mode}.eg"
        write_project(path, workbook)

        placeholder = window._plot_placeholder
        with mock.patch.object(window, "render", wraps=window.render) as render:
            self.assertTrue(window.open_project_path(path))
            render.assert_not_called()

        self.assertIsNone(window.canvas)
        self.assertIs(window._plot_placeholder, placeholder)
        self.assertEqual(window.current_project, path)
        self.assertEqual(window.workbook.active_sheet_id, saved.id)
        self.assertEqual(window.sheet_tab_bar.currentIndex(), 1)
        self.assertEqual(window.settings.title, saved.settings.title)
        pd.testing.assert_frame_equal(
            self.numeric_data(window.table_dataframe()),
            self.numeric_data(saved.dataframe),
            check_dtype=False,
        )
        self.assertFalse(window.has_unsaved_changes())
        self.assertEqual(stored_recent_project_paths()[0], path)

        window.show()
        self.qapp.processEvents()
        self.assertTrue(placeholder.isVisible())
        self.assertIsNone(window.canvas)

        with mock.patch.object(
            window, "_fit_initial_plot_to_viewport",
            wraps=window._fit_initial_plot_to_viewport,
        ) as fit:
            window.initialize_preview(initial_render=True)
            fit.assert_called_once()

        self.assertIsNone(window._plot_placeholder)
        self.assertEqual(window.canvas._last_settings.title, saved.settings.title)
        pd.testing.assert_frame_equal(
            self.numeric_data(window.canvas._last_df),
            self.numeric_data(saved.dataframe),
            check_dtype=False,
        )
        if mode == SHEET_MODE_GROUPS:
            self.assertEqual(
                [parent.label for parent in window.canvas._group_layout.parents],
                ["WT", "KO"],
            )
        else:
            self.assertIsNotNone(window.canvas._last_xy_settings)
            self.assertEqual(
                [series.name for series in window._xy_user_series()],
                ["Control", "Treatment", "Sensor A", "Sensor B"],
            )
        self.assertFalse(window.has_unsaved_changes())

        with mock.patch.object(window, "render") as render:
            window.initialize_preview(initial_render=True)
            render.assert_not_called()

    def test_recent_grouped_project_keeps_placeholder_until_preview_initialization(self):
        self.assert_deferred_project_preview(SHEET_MODE_GROUPS)

    def test_recent_xy_project_keeps_placeholder_until_preview_initialization(self):
        self.assert_deferred_project_preview(SHEET_MODE_XY)

    def test_project_opened_in_initialized_window_renders_and_fits_immediately(self):
        window = self.make_window(initial_render=True)
        canvas = window.canvas
        path = self.directory / "regular.eg"
        data = pd.DataFrame({"Saved A": [11, 12, 13], "Saved B": [21, 22, 23]})
        write_project(path, data, ChartSettings(title="Regular open"))

        with mock.patch.object(window, "render", wraps=window.render) as render:
            with mock.patch.object(canvas, "zoom_to_fit", wraps=canvas.zoom_to_fit) as fit:
                self.assertTrue(window.open_project_path(path))
                render.assert_called_once()
                fit.assert_called_once()

        self.assertIs(window.canvas, canvas)
        self.assertEqual(canvas._last_settings.title, "Regular open")
        pd.testing.assert_frame_equal(
            self.numeric_data(canvas._last_df), data, check_dtype=False,
        )
        self.assertFalse(window.has_unsaved_changes())

    def test_invalid_recent_project_preserves_placeholder_and_can_continue_to_demo(self):
        window = self.make_deferred_window()
        workbook = window.workbook
        placeholder = window._plot_placeholder
        invalid = self.directory / "invalid.eg"
        invalid.write_text("not an EasyGraph archive", encoding="utf-8")

        with mock.patch("easygraph.ui.main_window.QMessageBox.critical") as error:
            self.assertFalse(window.open_project_path(invalid))
            error.assert_called_once()

        self.assertIs(window.workbook, workbook)
        self.assertIsNone(window.current_project)
        self.assertIsNone(window.canvas)
        self.assertIs(window._plot_placeholder, placeholder)
        self.assertEqual(stored_recent_project_paths(), [])
        window.initialize_startup_project(SHEET_MODE_GROUPS, demo=True)
        self.assertIsNone(window.canvas)
        window.initialize_preview(initial_render=True)
        self.assertIsNotNone(window.canvas)
        self.assertFalse(window.has_unsaved_changes())


if __name__ == "__main__":
    __import__("unittest").main()
