from dataclasses import asdict
from pathlib import Path
import tempfile

import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.grouping import create_parent
from easygraph.recovery import RecoveryManager, read_recovery_workbook
from easygraph.workbook import SheetDocument, WorkbookDocument


class GroupingRecoveryTests(EasyGraphQtTestCase):
    def test_checkpoint_and_journal_preserve_parents_and_duplicate_column_overlay_ids(self):
        sheet = SheetDocument('Grouped', pd.DataFrame([[1, 10]], columns=['A', 'A']), column_ids=['first', 'second'])
        create_parent(sheet.grouping, ['first'], 'WT')
        create_parent(sheet.grouping, ['second'], 'KO')
        sheet.settings.custom_overlay_series = [{'name': 'Limit', 'values': {'first': '7', 'second': '70'}}]
        workbook = WorkbookDocument([sheet], sheet.id)
        with tempfile.TemporaryDirectory() as directory:
            manager = RecoveryManager(interval_seconds=2, root=Path(directory))
            try:
                manager.replace_document(workbook, None, dirty=True)
                self.assertTrue(manager.wait_for_checkpoint(10))
                sheet.grouping.parents[0]['name'] = 'Renamed WT'
                manager.record_sheet_state(sheet)
                manager.record_cell(sheet.id, 1, 1, '99')
                self.assertTrue(manager.flush())
                restored, _ = read_recovery_workbook(manager.session_dir)
                self.assertEqual(asdict(restored.active_sheet.grouping), asdict(sheet.grouping))
                self.assertEqual(restored.active_sheet.settings.custom_overlay_series[0]['values'], {'first': '7', 'second': '99'})
                self.assertEqual(restored.active_sheet.dataframe.values.tolist(), [[1, 10]])
            finally:
                manager.close(discard=True)
