from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from scripts import audit_app_facade


ROOT = Path(__file__).resolve().parents[1]


class AppFacadeAuditTests(unittest.TestCase):
    def _fixture_root(self, directory: str) -> Path:
        root = Path(directory)
        (root / "src").mkdir()
        (root / "tests").mkdir()
        (root / "src" / "easygraph" / "ui").mkdir(parents=True)
        (root / "src" / "app.py").write_text(
            """from dependency import historical_export, startup_helper, unused_import
from easygraph.ui.main_window import MainWindow

def main():
    startup_helper()
    return MainWindow()
""",
            encoding="utf-8",
        )
        (root / "src" / "easygraph" / "ui" / "main_window.py").write_text(
            """from dependency import used_by_window

WINDOW_CONST = 3

def helper():
    return used_by_window

class MainWindow:
    def render(self):
        return used_by_window, WINDOW_CONST, helper()
""",
            encoding="utf-8",
        )
        (root / "tests" / "test_architecture.py").write_text(
            """class ArchitectureTests:
    def test_app_entrypoint_reexports_only_main_window(self):
        import app
        from easygraph.ui import main_window
        self.assertIs(app.MainWindow, main_window.MainWindow)
""",
            encoding="utf-8",
        )
        (root / "tests" / "test_alpha.py").write_text(
            """import app

helper = app.used_by_window
""",
            encoding="utf-8",
        )
        (root / "tests" / "test_zeta.py").write_text(
            """from tests.easygraph_case import app

export = app.historical_export
""",
            encoding="utf-8",
        )
        (root / "tests" / "easygraph_case.py").write_text(
            """import app
""",
            encoding="utf-8",
        )
        return root

    def test_build_report_classifies_final_entrypoint_boundary(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._fixture_root(tmp)

            report = audit_app_facade.build_report(root)

        self.assertEqual(
            report,
            {
                "allowed_entrypoint_assertions": {
                    "tests/test_architecture.py::ArchitectureTests::test_app_entrypoint_reexports_only_main_window": [
                        "MainWindow"
                    ]
                },
                "historical_test_app_attributes": {
                    "tests/test_alpha.py::<module>": ["used_by_window"],
                    "tests/test_zeta.py::<module>": ["historical_export"],
                },
                "main_window_loads": ["WINDOW_CONST", "helper", "used_by_window"],
                "startup_only_names": ["MainWindow", "startup_helper"],
                "unused_imported_names": ["unused_import"],
            },
        )

    def test_cli_output_is_deterministic_and_read_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._fixture_root(tmp)
            files = sorted(path for path in root.rglob("*") if path.is_file())
            before = {path.relative_to(root).as_posix(): path.read_bytes() for path in files}
            command = [
                sys.executable,
                str(ROOT / "scripts" / "audit_app_facade.py"),
                str(root),
            ]

            first = subprocess.run(command, capture_output=True, text=True, check=False)
            second = subprocess.run(command, capture_output=True, text=True, check=False)
            after = {path.relative_to(root).as_posix(): path.read_bytes() for path in files}

        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(first.stdout, second.stdout)
        self.assertEqual(json.loads(first.stdout), json.loads(second.stdout))
        self.assertLess(
            first.stdout.index('"tests/test_alpha.py::<module>"'),
            first.stdout.index('"tests/test_zeta.py::<module>"'),
        )
        self.assertEqual(
            first.stdout,
            json.dumps(json.loads(first.stdout), indent=2, sort_keys=True) + "\n",
        )
        self.assertEqual(after, before)

    def test_entrypoint_allowlist_rejects_alias_duplicate_and_nonidentity_access(self):
        cases = {
            "alias": """class ArchitectureTests:
    def test_app_entrypoint_reexports_only_main_window(self):
        import app as facade
        from easygraph.ui import main_window
        self.assertIs(facade.MainWindow, main_window.MainWindow)
""",
            "duplicate": """class ArchitectureTests:
    def test_app_entrypoint_reexports_only_main_window(self):
        import app
        from easygraph.ui import main_window
        self.assertIs(app.MainWindow, main_window.MainWindow)
        self.assertIs(app.MainWindow, main_window.MainWindow)
""",
            "nonidentity": """class ArchitectureTests:
    def test_app_entrypoint_reexports_only_main_window(self):
        import app
        value = app.MainWindow
""",
            "rebound_alias": """class ArchitectureTests:
    def test_app_entrypoint_reexports_only_main_window(self):
        import app
        facade = app
        value = facade.QFileDialog
""",
            "dynamic_getattr": """class ArchitectureTests:
    def test_app_entrypoint_reexports_only_main_window(self):
        import app
        value = getattr(app, "QFileDialog")
""",
        }

        for name, source in cases.items():
            with self.subTest(name=name), tempfile.TemporaryDirectory() as tmp:
                root = self._fixture_root(tmp)
                (root / "tests" / "test_architecture.py").write_text(
                    source,
                    encoding="utf-8",
                )

                report = audit_app_facade.build_report(root)

                self.assertEqual(report["allowed_entrypoint_assertions"], {})
                self.assertIn(
                    "tests/test_architecture.py::ArchitectureTests::test_app_entrypoint_reexports_only_main_window",
                    report["historical_test_app_attributes"],
                )
