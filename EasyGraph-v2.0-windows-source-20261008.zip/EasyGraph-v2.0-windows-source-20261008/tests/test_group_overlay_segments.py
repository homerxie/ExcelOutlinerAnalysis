from __future__ import annotations

import numpy as np
import pandas as pd
from matplotlib.backend_bases import MouseEvent
from matplotlib.path import Path
from matplotlib.transforms import Bbox

from easygraph.grouping import GroupingSettings
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings, LEGEND_POSITION_INSIDE
from tests.easygraph_case import EasyGraphQtTestCase


class GroupOverlaySegmentsTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.ids = ["a1", "a2", "single1", "single2", "b1", "b2"]
        # Repeated parent and child names must not establish line membership.
        self.frame = pd.DataFrame(
            [[1, 4, 7, 10, 13, 16], [2, 5, 8, 11, 14, 17], [3, 6, 12, 12, 15, 18]],
            columns=["Repeated"] * len(self.ids),
        )
        self.grouping = GroupingSettings(parents=[
            {"id": "a", "name": "Repeated parent", "column_ids": self.ids[:2]},
            {"id": "b", "name": "Repeated parent", "column_ids": self.ids[4:]},
        ])

    def render(self, settings, *, grouping=None, frame=None):
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            self.frame if frame is None else frame,
            settings,
            grouping=self.grouping if grouping is None else grouping,
            column_ids=self.ids,
        )
        return canvas

    @staticmethod
    def overlay_lines(canvas):
        return [line for ax in canvas.figure.axes for line in ax.lines if line.get_gid() == "overlay-line"]

    @staticmethod
    def paths(line):
        paths = []
        for vertex, code in line.get_path().iter_segments(remove_nans=True, simplify=False):
            if code == Path.MOVETO:
                paths.append([])
            paths[-1].append(vertex)
        return [np.asarray(path) for path in paths]

    def assert_segment_members(self, canvas, line, member_blocks, *, ridge=False):
        paths = self.paths(line)
        self.assertEqual(len(paths), len(member_blocks))
        for path, members in zip(paths, member_blocks):
            np.testing.assert_allclose(
                path[:, 1 if ridge else 0],
                [canvas._group_layout.coordinate(key, ridge=ridge) for key in members],
            )
        vertices = line.get_path().vertices
        self.assertEqual(np.isfinite(vertices).all(axis=1).sum(), sum(map(len, member_blocks)))
        self.assertEqual(line.get_marker(), "o")
        self.assertGreater(line.get_markersize(), 0)

    def test_mean_and_median_keep_every_marker_label_and_one_legend_in_all_charts(self):
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            for statistic in ("Mean", "Median"):
                with self.subTest(chart_type=chart_type, statistic=statistic):
                    settings = ChartSettings(
                        chart_type=chart_type, show_line_overlay=True, line_overlay_stat=statistic,
                        line_overlay_break_between_parents=True, show_line_values=True,
                        show_stat_table=False, show_points=False,
                    )
                    canvas = self.render(settings)
                    lines = self.overlay_lines(canvas)
                    self.assertEqual(len(lines), 1)
                    line = lines[0]
                    self.assert_segment_members(canvas, line, [self.ids[:2], ["single1"], ["single2"], self.ids[4:]], ridge=chart_type == "Ridge")
                    values = self.frame.mean() if statistic == "Mean" else self.frame.median()
                    finite = line.get_path().vertices[np.isfinite(line.get_path().vertices).all(axis=1)]
                    np.testing.assert_allclose(finite[:, 0 if chart_type == "Ridge" else 1], values)
                    labels = [text for text in line.axes.texts if text.get_gid() == "overlay-value-label"]
                    self.assertEqual(len(labels), len(self.ids))
                    np.testing.assert_allclose([text.xy for text in labels], finite)
                    self.assertEqual([text.get_text() for text in line.axes.get_legend().get_texts()].count(statistic), 1)

    def test_manual_order_hidden_members_and_equal_spacing_use_stable_ids(self):
        settings = ChartSettings(
            chart_type="Bar", show_line_overlay=True, line_overlay_stat="Mean",
            line_overlay_break_between_parents=True, show_stat_table=False,
            group_order="Manual", manual_group_order=["b2", "single2", "a2", "b1", "single1", "a1"],
            group_hidden=["a1", "single1"], group_inner_spacing=1.0, group_outer_spacing=1.0,
        )
        canvas = self.render(settings)
        self.assertEqual(canvas._group_layout.order, ("b2", "b1", "single2", "a2"))
        self.assert_segment_members(canvas, self.overlay_lines(canvas)[0], [["b2", "b1"], ["single2"], ["a2"]])

    def test_default_and_no_parent_metadata_keep_the_original_continuous_line(self):
        for enabled, grouping in ((False, self.grouping), (True, GroupingSettings())):
            with self.subTest(enabled=enabled, has_parents=bool(grouping.parents)):
                settings = ChartSettings(
                    line_overlay_stat="Mean", show_line_overlay=True, show_stat_table=False,
                    line_overlay_break_between_parents=enabled,
                )
                canvas = self.render(settings, grouping=grouping)
                self.assert_segment_members(canvas, self.overlay_lines(canvas)[0], [self.ids])

    def test_custom_lines_follow_the_same_blocks_on_primary_secondary_and_split_axes(self):
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            for secondary, split in ((False, False), (True, False), (True, True)):
                with self.subTest(chart_type=chart_type, secondary=secondary, split=split):
                    settings = ChartSettings(
                        chart_type=chart_type, show_stat_table=False, show_points=False,
                        extra_custom_overlay=True, custom_overlay_secondary_axis=secondary,
                        split_secondary_axis=split, line_overlay_break_between_parents=True,
                        custom_overlay_series=[{"name": "Response", "values": dict(zip(self.ids, [10, 20, 30, 40, 50, 60]))}],
                    )
                    canvas = self.render(settings)
                    lines = self.overlay_lines(canvas)
                    self.assertEqual(len(lines), 1)
                    self.assertEqual(lines[0].axes.get_gid() == "secondary-axis", secondary)
                    self.assert_segment_members(canvas, lines[0], [self.ids[:2], ["single1"], ["single2"], self.ids[4:]], ridge=chart_type == "Ridge")
                    legend_labels = [text.get_text() for ax in canvas.figure.axes if ax.get_legend() for text in ax.get_legend().get_texts()]
                    self.assertEqual(legend_labels.count("Response"), 1)

    def test_missing_custom_values_still_break_lines_and_keep_finite_labels(self):
        for chart_type in ("Box", "Ridge"):
            with self.subTest(chart_type=chart_type):
                settings = ChartSettings(
                    chart_type=chart_type, show_stat_table=False, show_points=False,
                    show_line_values=True, extra_custom_overlay=True,
                    line_overlay_break_between_parents=True,
                    custom_overlay_series=[{"name": "Response", "values": dict(zip(self.ids, [10, "", 30, "", 50, 60]))}],
                )
                canvas = self.render(settings)
                line = self.overlay_lines(canvas)[0]
                self.assert_segment_members(canvas, line, [["a1"], ["single1"], ["b1", "b2"]], ridge=chart_type == "Ridge")
                labels = [text for text in line.axes.texts if text.get_gid() == "overlay-value-label"]
                self.assertEqual(len(labels), 4)
                vertices = line.get_path().vertices
                np.testing.assert_allclose([text.xy for text in labels], vertices[np.isfinite(vertices).all(axis=1)])

    def test_missing_data_column_does_not_connect_across_parent_boundaries(self):
        frame = self.frame.astype(float)
        frame.iloc[:, 1] = np.nan
        settings = ChartSettings(
            line_overlay_stat="Mean", show_line_overlay=True, show_stat_table=False,
            line_overlay_break_between_parents=True,
        )
        canvas = self.render(settings, frame=frame)
        self.assert_segment_members(canvas, self.overlay_lines(canvas)[0], [["a1"], ["single1"], ["single2"], ["b1", "b2"]])

    def test_selection_and_geometry_ignore_the_gaps_and_bounds_remain_finite(self):
        settings = ChartSettings(
            show_stat_table=False, show_points=False, extra_custom_overlay=True,
            line_overlay_break_between_parents=True, legend_position=LEGEND_POSITION_INSIDE,
            custom_overlay_series=[{"name": "Response", "values": dict.fromkeys(self.ids, 50)}],
        )
        canvas = self.render(settings)
        line = self.overlay_lines(canvas)[0]
        ax = line.axes
        renderer = canvas.canvas.get_renderer()
        self.assertTrue(np.isfinite(canvas._interaction_artist_bbox(line, ax, renderer).extents).all())
        self.assertTrue(np.isfinite(canvas._plot_content_artist_bounds(line, ax, renderer).extents).all())
        targets = [target for target in canvas._interaction_targets if target.get("artist") is line]
        self.assertEqual(len(targets), 1)
        positions = canvas._group_layout.positions
        for x, expected_hit in (((positions["a1"] + positions["a2"]) / 2, True), ((positions["a2"] + positions["single1"]) / 2, False), (positions["single1"], True)):
            with self.subTest(x=x, expected_hit=expected_hit):
                pixel_x, pixel_y = ax.transData.transform((x, 50))
                event = MouseEvent("button_press_event", canvas.canvas, pixel_x, pixel_y)
                self.assertEqual(line.contains(event)[0], expected_hit)
                self.assertEqual(
                    canvas._xy_line2d_intersects_bbox(line, Bbox.from_bounds(pixel_x - 1, pixel_y - 1, 2, 2), ax.get_window_extent(renderer)),
                    expected_hit,
                )
