from dataclasses import asdict
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

import pandas as pd

from easygraph.data import attach_group_metadata, group_keys, group_labels, migrate_group_settings, prepare_plot_frames, values_for_group
from easygraph.grouping import GroupingSettings, create_parent, grouping_from_dict, insert_subgroup, normalize_grouping, parent_for_column, ungroup_columns
from easygraph.project_io import read_workbook_project, write_project
from easygraph.settings import ChartSettings
from easygraph.workbook import SheetDocument, WorkbookDocument


class GroupingTests(unittest.TestCase):
    def test_same_labels_have_independent_statistics_and_can_be_hidden_independently(self):
        frame = attach_group_metadata(pd.DataFrame([[1, 10, ""], [3, 20, ""]], columns=["Control"] * 3), ["a", "b", "empty"])
        prepared = prepare_plot_frames(frame, ChartSettings(group_hidden=["a"]))
        self.assertEqual(prepared.groups, ("a", "b", "empty"))
        self.assertEqual(prepared.labels, {"a": "Control", "b": "Control", "empty": "Control"})
        self.assertEqual(prepared.full.groupby("group")["value"].mean().to_dict(), {"a": 2.0, "b": 15.0})
        self.assertEqual(prepared.visible["value"].tolist(), [10, 20])
        self.assertEqual(prepared.visible.attrs["group_keys"], ["b", "empty"])
        self.assertEqual(values_for_group(frame, "a").tolist(), [1, 3])
        self.assertTrue(values_for_group(frame, "Control").empty)

    def test_standalone_keys_do_not_collide_with_user_labels(self):
        frame = pd.DataFrame([[1, 2, 3, 4]], columns=["A", "A", "A [1]", "B"])
        keys = group_keys(frame)
        self.assertEqual(len(set(keys)), 4)
        self.assertEqual(keys[2:], ["A [1]", "B"])
        self.assertEqual(list(group_labels(frame).values()), list(frame.columns))
        self.assertEqual(prepare_plot_frames(frame, ChartSettings()).full["value"].tolist(), [1, 2, 3, 4])

    def test_legacy_label_settings_expand_to_ids_and_new_settings_stay_independent(self):
        frame = attach_group_metadata(pd.DataFrame([[1, 2, 3]], columns=["A", "A", "B"]), ["a1", "a2", "b"])
        settings = ChartSettings(group_hidden=["A"], manual_group_order=["B", "A"], custom_colors={"A": "#123456"}, custom_overlay_series=[{"name": "Target", "values": {"A": "10", "B": "20"}}])
        migrate_group_settings(settings, frame)
        self.assertEqual(settings.group_hidden, ["a1", "a2"])
        self.assertEqual(settings.manual_group_order, ["b", "a1", "a2"])
        self.assertEqual(settings.custom_colors, {"a1": "#123456", "a2": "#123456"})
        self.assertEqual(settings.custom_overlay_series[0]["values"], {"a1": "10", "a2": "10", "b": "20"})
        settings.group_hidden = ["a2"]
        settings.custom_overlay_series[0]["values"]["a2"] = "50"
        migrate_group_settings(settings, frame)
        self.assertEqual(settings.group_hidden, ["a2"])
        self.assertEqual(settings.custom_overlay_series[0]["values"]["a1"], "10")

    def test_left_right_insertion_stays_in_the_anchor_parent_and_ungroup_keeps_other_parents(self):
        grouping = GroupingSettings(shared_subgroups=True)
        first = create_parent(grouping, ["a", "b"], "First")
        second = create_parent(grouping, ["c"], "Second")
        insert_subgroup(grouping, "b", "right")
        insert_subgroup(grouping, "a", "left", after=False)
        self.assertEqual(first["column_ids"], ["left", "a", "b", "right"])
        self.assertIs(parent_for_column(grouping, "right"), first)
        self.assertNotEqual(grouping.subgroup_ids["left"], grouping.subgroup_ids["right"])
        ungroup_columns(grouping, first["column_ids"])
        self.assertEqual(grouping.parents, [second])
        self.assertEqual(set(grouping.subgroup_ids), {"c"})

    def test_normalization_drops_deleted_ids_and_orders_members_by_table(self):
        grouping = GroupingSettings(parents=[{"id": "p", "name": "Parent", "column_ids": ["b", "missing", "a"]}, {"id": "q", "name": "Empty", "column_ids": ["missing"]}], shared_subgroups=True, subgroup_ids={"a": "control", "missing": "treatment"})
        normalize_grouping(grouping, ["a", "b"])
        self.assertEqual(grouping.parents, [{"id": "p", "name": "Parent", "column_ids": ["a", "b"]}])
        self.assertEqual(grouping.subgroup_ids, {"a": "control"})
        with self.assertRaises(ValueError):
            grouping_from_dict({"parents": "invalid"}, ["a"])

    def test_project_and_clone_preserve_shared_and_irregular_group_metadata(self):
        grouping = GroupingSettings(parents=[{"id": "p", "name": "First", "column_ids": ["a", "b"]}, {"id": "q", "name": "Second", "column_ids": ["c"]}], shared_subgroups=True, subgroup_ids={"a": "control", "b": "treated", "c": "control"})
        sheet = SheetDocument(name="Groups", dataframe=pd.DataFrame([[1, 2, 10]], columns=["Control", "Treatment", "Control"]), column_ids=["a", "b", "c"], grouping=grouping)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "grouped.eg"
            write_project(path, WorkbookDocument([sheet]))
            loaded = read_workbook_project(path).active_sheet
        self.assertEqual(asdict(loaded.grouping), asdict(grouping))
        self.assertEqual(loaded.column_ids, ["a", "b", "c"])
        self.assertEqual(list(loaded.dataframe.columns), ["Control", "Treatment", "Control"])
        clone = sheet.clone()
        clone.grouping.parents[0]["name"] = "Changed"
        clone.grouping.subgroup_ids["a"] = "independent"
        self.assertEqual(sheet.grouping.parents[0]["name"], "First")
        self.assertEqual(sheet.grouping.subgroup_ids["a"], "control")

    def test_old_projects_with_duplicate_titles_open_as_independent_columns(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "legacy.eg"
            for version in (1, 2, 3, 4):
                with self.subTest(version=version):
                    with zipfile.ZipFile(path, "w") as archive:
                        archive.writestr("project.json", json.dumps({"version": version, "app": "EasyGraph"}))
                        prefix = "" if version == 1 else "sheets/sheet/"
                        archive.writestr(prefix + "data.csv", "A,A\n1,10\n3,20\n")
                        settings = asdict(ChartSettings())
                        if version >= 3:
                            settings = {"chart": settings, "xy": {}, "column_ids": ["a", "b"]}
                        archive.writestr(prefix + "settings.json", json.dumps(settings))
                        if version > 1:
                            archive.writestr("sheets.json", json.dumps({"active_sheet_id": "sheet", "sheets": [{"id": "sheet", "name": "Groups", "mode": "groups"}]}))
                    loaded = read_workbook_project(path).active_sheet
                    prepared = prepare_plot_frames(attach_group_metadata(loaded.dataframe, loaded.column_ids), loaded.settings)
                    self.assertEqual(list(loaded.dataframe.columns), ["A", "A"])
                    self.assertEqual(len(prepared.groups), 2)
                    self.assertEqual(prepared.full.groupby("group", sort=False)["value"].mean().tolist(), [2.0, 15.0])
                    self.assertEqual(loaded.grouping.parents, [])
