import pathlib
import tempfile
from unittest import mock

from tests.easygraph_case import EasyGraphQtTestCase, patch_qsettings
from easygraph import app_preferences, project_io
from easygraph.file_association import FileAssociationRefreshStatus
from easygraph.settings import ChartSettings
from easygraph.ui import main_window
from easygraph.ui.preferences_dialog import PreferencesDialog, PreferencesState


class AppPreferenceTests(EasyGraphQtTestCase):

    def test_auto_recovery_interval_is_normalized_and_persisted(self):
        settings_patch, values = patch_qsettings()
        with settings_patch:
            self.assertEqual(app_preferences.stored_auto_recovery_interval(), 2)
            app_preferences.save_auto_recovery_interval(0)
            self.assertEqual(app_preferences.stored_auto_recovery_interval(), 1)
            app_preferences.save_auto_recovery_interval(500)
            self.assertEqual(app_preferences.stored_auto_recovery_interval(), 60)
        self.assertEqual(
            values[app_preferences.AUTO_RECOVERY_INTERVAL_SETTING_KEY],
            60,
        )

    def test_preferences_dialog_uses_expandable_categories(self):
        dialog = PreferencesDialog(
            PreferencesState("zh_CN", "light", 7)
        )
        self.addCleanup(dialog.deleteLater)
        self.assertEqual(dialog.category_list.count(), 3)
        self.assertEqual(dialog.pages.count(), 3)
        self.assertEqual(
            dialog.preferences(), PreferencesState("zh_CN", "light", 7)
        )

    def test_preferences_can_manually_refresh_file_association_and_icon(self):
        refresher = mock.Mock(
            return_value=FileAssociationRefreshStatus.REFRESHED
        )
        dialog = PreferencesDialog(
            PreferencesState("system", "dark", 2),
            association_refresher=refresher,
        )
        self.addCleanup(dialog.deleteLater)

        dialog.refresh_file_association_button.click()

        refresher.assert_called_once_with()
        self.assertEqual(
            dialog.file_association_status_label.text(),
            "The .eg file association and project icon were refreshed.",
        )

    def test_settings_window_updates_shared_preferences_and_keeps_old_menus(self):
        settings_patch, values = patch_qsettings()
        with settings_patch, mock.patch.object(
            main_window, "apply_app_theme"
        ) as apply_theme, mock.patch.object(
            main_window.QMessageBox, "information"
        ):
            window = self.make_window()
            window.apply_preferences(PreferencesState("zh_CN", "light", 5))

        self.assertEqual(values[app_preferences.LANGUAGE_SETTING_KEY], "zh_CN")
        self.assertEqual(values[app_preferences.THEME_SETTING_KEY], "light")
        self.assertEqual(
            values[app_preferences.AUTO_RECOVERY_INTERVAL_SETTING_KEY], 5
        )
        self.assertTrue(window.language_actions["zh_CN"].isChecked())
        self.assertTrue(window.theme_actions["light"].isChecked())
        self.assertIn(window.language_menu.menuAction(), window.ui.menubar.actions())
        self.assertIn(window.theme_menu.menuAction(), window.ui.menubar.actions())
        apply_theme.assert_called_once_with(self.qapp, "light")

    def test_language_code_normalization_uses_focused_module(self):
        self.assertEqual(app_preferences.normalize_language_code("zh-Hans"), "zh_CN")

    def test_translation_directory_uses_pyinstaller_bundle_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            with (
                mock.patch.object(app_preferences.sys, "frozen", True, create=True),
                mock.patch.object(app_preferences.sys, "_MEIPASS", tmp, create=True),
            ):
                directory = app_preferences.translation_directory()

        self.assertEqual(directory, pathlib.Path(tmp) / "translations")

    def test_translator_loads_qm_from_resolved_translation_directory(self):
        translation_dir = pathlib.Path("C:/EasyGraph/_internal/translations")
        fake_app = mock.Mock()
        translator = mock.Mock()
        translator.load.return_value = True

        with (
            mock.patch.object(
                app_preferences,
                "translation_directory",
                return_value=translation_dir,
            ),
            mock.patch.object(
                app_preferences,
                "QTranslator",
                return_value=translator,
            ),
        ):
            code = app_preferences.install_app_translator(fake_app, "zh_CN")

        self.assertEqual(code, "zh_CN")
        translator.load.assert_called_once_with(
            str(translation_dir / "easygraph_zh_CN.qm")
        )
        fake_app.installTranslator.assert_called_once_with(translator)
        self.assertIs(fake_app._easygraph_translator, translator)

    def test_theme_preference_normalizes_persists_and_defaults_to_dark(self):
        settings_patch, values = patch_qsettings()
        with settings_patch:
            self.assertEqual(app_preferences.stored_theme_preference(), "dark")
            app_preferences.save_theme_preference("LIGHT")
            self.assertEqual(app_preferences.stored_theme_preference(), "light")
            self.assertEqual(values[app_preferences.THEME_SETTING_KEY], "light")

    def test_theme_menu_switches_and_applies_theme_immediately(self):
        settings_patch, values = patch_qsettings()
        with settings_patch, mock.patch.object(main_window, "apply_app_theme") as apply_theme:
            window = self.make_window()
            window.theme_actions["light"].trigger()

        self.assertEqual(values[app_preferences.THEME_SETTING_KEY], "light")
        self.assertTrue(window.theme_actions["light"].isChecked())
        self.assertFalse(window.theme_actions["dark"].isChecked())
        apply_theme.assert_called_once_with(self.qapp, "light")

    def test_recent_project_paths_keep_newest_unique_and_limited(self):
        settings_patch, _values = patch_qsettings()
        paths = [pathlib.Path(f"/tmp/project_{index}.eg") for index in range(app_preferences.MAX_RECENT_PROJECTS + 2)]
        with settings_patch:
            app_preferences.save_recent_project_paths(paths)

            self.assertEqual(app_preferences.stored_recent_project_paths(), paths[: app_preferences.MAX_RECENT_PROJECTS])

            app_preferences.remember_recent_project(paths[3])

            recent_paths = app_preferences.stored_recent_project_paths()

        self.assertEqual(recent_paths[0], paths[3])
        self.assertEqual(len(recent_paths), app_preferences.MAX_RECENT_PROJECTS)
        self.assertEqual(recent_paths.count(paths[3]), 1)

    def test_recent_project_menu_helpers_format_empty_and_numbered_items(self):
        self.assertEqual(app_preferences.recent_project_empty_label(), "No Recent Projects")
        self.assertEqual(app_preferences.recent_project_clear_label(), "Clear Recent Projects")
        self.assertEqual(
            app_preferences.recent_project_menu_item(1, pathlib.Path("/tmp/one.eg")),
            ("&1 /tmp/one.eg", "/tmp/one.eg"),
        )
        self.assertEqual(
            app_preferences.recent_project_menu_item(10, pathlib.Path("/tmp/ten.eg")),
            ("/tmp/ten.eg", "/tmp/ten.eg"),
        )

    def test_file_menu_contains_open_recent_submenu(self):
        settings_patch, _values = patch_qsettings()
        with settings_patch:
            window = self.make_window()

        actions = window.ui.menuFile.actions()
        recent_index = actions.index(window.ui.actionOpenProject) + 1
        self.assertEqual(actions[recent_index], window.ui.menuOpenRecent.menuAction())
        self.assertEqual(window.ui.menuOpenRecent.title(), "Open Recent")
        self.assertEqual(window.ui.menuOpenRecent.actions()[0].text(), "No Recent Projects")
        self.assertFalse(window.ui.menuOpenRecent.actions()[0].isEnabled())

    def test_open_project_adds_path_to_recent_menu(self):
        settings_patch, _values = patch_qsettings()
        self.settings.title = "Recent project title"
        with settings_patch:
            window = self.make_window(initial_render=True)
            with tempfile.TemporaryDirectory() as tmp:
                path = pathlib.Path(tmp) / "recent_open.eg"
                project_io.write_project(path, self.df, self.settings)

                with mock.patch.object(main_window.QFileDialog, "getOpenFileName", return_value=(str(path), "")):
                    window.open_project()

                recent_action = window.ui.menuOpenRecent.actions()[0]

            self.assertEqual(app_preferences.stored_recent_project_paths(), [path])

        self.assertEqual(window.current_project, path)
        self.assertEqual(window.settings.title, "Recent project title")
        self.assertEqual(recent_action.data(), str(path))

    def test_open_recent_project_loads_file_and_moves_it_to_top(self):
        settings_patch, _values = patch_qsettings()
        first_settings = ChartSettings(title="First")
        second_settings = ChartSettings(title="Second")
        with settings_patch:
            window = self.make_window(initial_render=True)
            with tempfile.TemporaryDirectory() as tmp:
                first_path = pathlib.Path(tmp) / "first.eg"
                second_path = pathlib.Path(tmp) / "second.eg"
                project_io.write_project(first_path, self.df, first_settings)
                project_io.write_project(second_path, self.df, second_settings)
                app_preferences.save_recent_project_paths([second_path, first_path])

                window.open_recent_project(first_path)

                self.assertEqual(window.current_project, first_path)
                self.assertEqual(window.settings.title, "First")
                self.assertEqual(app_preferences.stored_recent_project_paths(), [first_path, second_path])

    def test_open_recent_project_removes_missing_file(self):
        settings_patch, _values = patch_qsettings()
        missing_path = pathlib.Path("/tmp/missing_recent_project.eg")
        with settings_patch:
            window = self.make_window(initial_render=True)
            app_preferences.save_recent_project_paths([missing_path])
            window.update_recent_projects_menu()

            with mock.patch.object(main_window.QMessageBox, "warning") as warning:
                window.open_recent_project(missing_path)

            self.assertEqual(app_preferences.stored_recent_project_paths(), [])
            self.assertEqual(window.ui.menuOpenRecent.actions()[0].text(), "No Recent Projects")
            warning.assert_called_once()

    def test_missing_recent_project_handler_forgets_path_and_refreshes_menu(self):
        settings_patch, _values = patch_qsettings()
        missing_path = pathlib.Path("/tmp/missing_recent_project_handler.eg")
        with settings_patch:
            window = self.make_window(initial_render=True)
            app_preferences.save_recent_project_paths([missing_path])
            window.update_recent_projects_menu()

            with mock.patch.object(main_window.QMessageBox, "warning") as warning:
                window._handle_missing_recent_project(missing_path)

            self.assertEqual(app_preferences.stored_recent_project_paths(), [])
            self.assertEqual(window.ui.menuOpenRecent.actions()[0].text(), "No Recent Projects")
            warning.assert_called_once()
