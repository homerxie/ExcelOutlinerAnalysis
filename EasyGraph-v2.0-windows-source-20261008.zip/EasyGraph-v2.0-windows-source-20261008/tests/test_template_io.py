import json
import os
import pathlib
import subprocess
import sys
import tempfile
from dataclasses import asdict

from tests.easygraph_case import ROOT, EasyGraphTestCase
from easygraph import template_io
from easygraph.settings import ChartSettings, STYLE_TEMPLATE_CONTENT_FIELDS
from easygraph.xy_series import XYSeriesSpec, XYSettings


class TemplateIOTests(EasyGraphTestCase):

    def test_style_template_rejects_unknown_settings_fields(self):
        data = asdict(self.settings)
        data["retired_template_setting"] = True

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "strict.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            with self.assertRaises(ValueError) as raised:
                template_io.read_style_template_file(path)

        self.assertEqual(
            str(raised.exception),
            "Unknown ChartSettings fields: retired_template_setting",
        )

    def test_template_io_api_is_exact(self):
        expected_exports = [
            "STYLE_TEMPLATE_VERSION",
            "TEMPLATE_DIR",
            "TEMPLATE_FAMILY_GROUPS",
            "TEMPLATE_FAMILY_XY",
            "TEMPLATE_NONE_NAME",
            "XY_STYLE_TEMPLATE_KEY",
            "XYStyleTemplate",
            "apply_xy_style_template",
            "apply_style_template_settings",
            "group_colors_for_target_groups",
            "import_style_template",
            "indexed_group_colors_from_settings",
            "list_style_templates",
            "read_style_template",
            "read_style_template_file",
            "read_xy_style_template",
            "read_xy_style_template_file",
            "style_template_settings_data",
            "style_template_families",
            "style_template_families_file",
            "template_file_name",
            "template_indexed_group_colors",
            "write_style_template",
            "xy_style_template_data",
        ]
        self.assertEqual(template_io.__all__, expected_exports)
        self.assertFalse(
            hasattr(template_io, "TEMPLATE_FAMILY_DISTRIBUTION")
        )
        self.assertEqual(template_io.TEMPLATE_DIR, ROOT / "src" / "template")

    def test_template_io_contract_runs_without_ui_or_plotting_dependencies(self):
        code = """
import inspect
import sys
from easygraph.settings import ChartSettings
from easygraph.template_io import (
    TEMPLATE_DIR,
    group_colors_for_target_groups,
    style_template_settings_data,
    write_style_template,
)

settings = ChartSettings(
    manual_group_order=["A", "B"],
    custom_colors={"B": "#446688"},
)
data = style_template_settings_data(settings)
if data["custom_colors"] != {"group:1": "#446688"}:
    raise SystemExit("group color was not indexed")
mapped = group_colors_for_target_groups(data["custom_colors"], ["X", "Y"])
if mapped != {"Y": "#446688"}:
    raise SystemExit("indexed group color was not mapped")
if inspect.signature(write_style_template).parameters["template_dir"].default != TEMPLATE_DIR:
    raise SystemExit("unexpected default template path")
if "PySide6.QtWidgets" in sys.modules:
    raise SystemExit("QtWidgets imported")
for forbidden in ("matplotlib", "seaborn", "scipy"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit(forbidden + " imported")
"""
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(ROOT / "src")
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_style_template_roundtrip_preserves_settings(self):
        self.settings.chart_type = "Ridge"
        self.settings.title = "Saved style"
        self.settings.x_label = "Saved group label"
        self.settings.y_label = "Saved value label"
        self.settings.secondary_y_label = "Saved secondary label"
        self.settings.width = 22.0
        self.settings.transparent_background = False
        self.settings.show_line_overlay = True
        self.settings.line_overlay_stat = "Mean"
        self.settings.line_overlay_width = 2.2
        self.settings.line_overlay_style = "Dotted"
        self.settings.line_overlay_point_size = 6.5
        self.settings.line_value_position = "Right"
        self.settings.custom_line_value_position = "Below"
        self.settings.line_value_font_size = 12
        self.settings.manual_group_order = ["Low dose", "Control", "High dose"]
        self.settings.group_hidden = ["High dose"]
        self.settings.custom_colors = {"Control": "#446688"}
        self.settings.custom_overlay_styles = {"custom:0": "Dashed"}
        self.settings.x_tick_rotation = 65
        self.settings.preset = "Viridis"
        self.settings.auto_y_range = False
        self.settings.y_min = -2.0
        self.settings.y_max = 9.0
        self.settings.line_value_decimals = 4
        self.settings.line_value_scientific = True
        self.settings.show_stat_q1 = False
        self.settings.stat_table_font_size = 8
        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)

            path = template_io.write_style_template(" My style/template ", self.settings, template_dir)
            loaded = template_io.read_style_template(path.stem, template_dir)

        self.assertEqual(path.name, "My style_template.json")
        expected = asdict(self.settings)
        defaults = asdict(ChartSettings())
        for key in STYLE_TEMPLATE_CONTENT_FIELDS:
            expected[key] = defaults[key]
        expected["custom_colors"] = {"group:1": "#446688"}
        self.assertEqual(asdict(loaded), expected)

    def test_style_template_does_not_save_custom_overlay_data(self):
        self.settings.extra_custom_overlay = True
        self.settings.custom_overlay_count = 1
        self.settings.custom_overlay_hidden = [0]
        self.settings.custom_overlay_secondary_axis = True
        self.settings.split_secondary_axis = True
        self.settings.custom_overlay_series = [
            {"name": "Overlay 1", "values": {"Control": "30", "Low dose": "20"}},
        ]

        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = template_io.write_style_template("Overlay style", self.settings, template_dir)
            saved = json.loads(path.read_text(encoding="utf-8"))
            loaded = template_io.read_style_template(path.stem, template_dir)

        groups = saved["variants"]["groups"]
        self.assertTrue(groups["extra_custom_overlay"])
        self.assertNotIn("custom_overlay_count", groups)
        self.assertNotIn("custom_overlay_series", groups)
        self.assertNotIn("custom_overlay_hidden", groups)
        self.assertTrue(groups["custom_overlay_secondary_axis"])
        self.assertTrue(groups["split_secondary_axis"])
        self.assertTrue(loaded.extra_custom_overlay)
        self.assertEqual(loaded.custom_overlay_series, [])
        self.assertEqual(loaded.custom_overlay_hidden, [])
        self.assertTrue(loaded.custom_overlay_secondary_axis)
        self.assertTrue(loaded.split_secondary_axis)

    def test_style_template_load_clears_content_overlay_data(self):
        data = asdict(self.settings)
        data["extra_custom_overlay"] = True
        data["custom_overlay_count"] = 1
        data["custom_overlay_hidden"] = [0]
        data["custom_overlay_secondary_axis"] = True
        data["split_secondary_axis"] = True
        data["custom_overlay_series"] = [
            {"name": "Legacy overlay", "values": {"Control": "30"}},
        ]

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "legacy.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            loaded = template_io.read_style_template_file(path)

        self.assertTrue(loaded.extra_custom_overlay)
        self.assertEqual(loaded.custom_overlay_count, 1)
        self.assertEqual(loaded.custom_overlay_series, [])
        self.assertEqual(loaded.custom_overlay_hidden, [])
        self.assertTrue(loaded.custom_overlay_secondary_axis)
        self.assertTrue(loaded.split_secondary_axis)

    def test_style_template_group_colors_are_indexed_not_name_bound(self):
        self.settings.manual_group_order = ["Control", "Low dose", "High dose"]
        self.settings.custom_colors = {"Low dose": "#446688"}

        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = template_io.write_style_template("Indexed colors", self.settings, template_dir)
            saved = json.loads(path.read_text(encoding="utf-8"))
            loaded = template_io.read_style_template(path.stem, template_dir)

        self.assertEqual(
            saved["variants"]["groups"]["custom_colors"],
            {"group:1": "#446688"},
        )
        self.assertEqual(loaded.custom_colors, {"group:1": "#446688"})

    def test_style_template_keeps_only_indexed_group_colors(self):
        data = asdict(self.settings)
        data["custom_colors"] = {"Control": "#446688", "group:1": "#884466"}

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "legacy_colors.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            loaded = template_io.read_style_template_file(path)

        self.assertEqual(loaded.custom_colors, {"group:1": "#884466"})

    def test_xy_style_template_roundtrip_excludes_mapping_and_series_state(self):
        xy = XYSettings(
            default_x_column_id="x",
            show_points=False,
            show_line=True,
            point_size=7.0,
            point_alpha=0.6,
            marker="Diamond",
            line_width=2.8,
            line_style="Dashed",
            series=[
                XYSeriesSpec(
                    id="series-1",
                    name="Dose",
                    x_column_id="other-x",
                    y_column_id="y",
                    visible=False,
                    color="#123456",
                )
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = template_io.write_style_template(
                "XY style",
                self.settings,
                template_dir,
                xy_settings=xy,
            )
            saved = json.loads(path.read_text(encoding="utf-8"))
            style = template_io.read_xy_style_template_file(path)

        self.assertEqual(
            saved["variants"]["xy"]["xy_style"],
            {
                "show_points": False,
                "show_line": True,
                "point_size": 7.0,
                "point_alpha": 0.6,
                "marker": "Diamond",
                "line_width": 2.8,
                "line_style": "Dashed",
            },
        )
        self.assertNotIn("series", saved["variants"]["xy"]["xy_style"])
        self.assertNotIn(
            "default_x_column_id",
            saved["variants"]["xy"]["xy_style"],
        )
        self.assertEqual(style.marker, "Diamond")

        target = XYSettings(
            default_x_column_id="target-x",
            series=[XYSeriesSpec(id="target", name="Target", y_column_id="target-y")],
        )
        applied = template_io.apply_xy_style_template(target, style)
        self.assertEqual(applied.default_x_column_id, "target-x")
        self.assertEqual([series.id for series in applied.series], ["target"])
        self.assertFalse(applied.show_points)
        self.assertTrue(applied.show_line)
        self.assertEqual(applied.line_width, 2.8)

    def test_xy_style_template_replaces_conflicting_per_series_overrides(self):
        current = XYSettings(
            show_points=True,
            show_line=True,
            series=[
                XYSeriesSpec(
                    id="target",
                    name="Target",
                    y_column_id="target-y",
                    show_line=False,
                    marker="Diamond",
                    point_size=8.0,
                    point_alpha=0.4,
                    line_width=3.0,
                    line_style="Dashed",
                    color="#123456",
                )
            ],
        )
        style = template_io.XYStyleTemplate(
            show_points=False,
            show_line=True,
            marker="Square",
            point_size=5.0,
            point_alpha=0.8,
            line_width=2.0,
            line_style="Dotted",
        )

        applied = template_io.apply_xy_style_template(current, style)

        series = applied.series[0]
        for field in (
            "show_points",
            "show_line",
            "marker",
            "point_size",
            "point_alpha",
            "line_width",
            "line_style",
        ):
            self.assertIsNone(getattr(series, field), field)
        self.assertEqual(series.color, "#123456")
        self.assertFalse(applied.show_points)
        self.assertTrue(applied.show_line)

    def test_v2_same_name_preserves_groups_and_xy_variants(self):
        groups = ChartSettings(
            chart_type="Violin",
            preset="Nature Style",
            width=18.0,
            group_order="Table order",
            point_size=8.0,
            auto_y_range=False,
            y_min=-3.0,
            y_max=12.0,
            group_col="legacy-group",
            value_col="legacy-value",
            manual_group_order=["A", "B"],
            custom_colors={"B": "#446688"},
        )
        xy_chart = ChartSettings(
            chart_type="Scatter",
            preset="Viridis",
            width=24.0,
            group_order="Y columns",
            x_tick_rotation=30,
            auto_x_range=False,
            x_min=-5.0,
            x_max=25.0,
            auto_y_range=False,
            y_min=-10.0,
            y_max=40.0,
        )
        xy_style = template_io.XYStyleTemplate(
            marker="Diamond",
            line_width=2.5,
        )

        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = template_io.write_style_template(
                "Shared",
                groups,
                template_dir,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            template_io.write_style_template(
                "Shared",
                xy_chart,
                template_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
                xy_settings=xy_style,
            )
            saved = json.loads(path.read_text(encoding="utf-8"))
            loaded_default = template_io.read_style_template(
                "Shared",
                template_dir,
            )
            loaded_groups = template_io.read_style_template(
                "Shared",
                template_dir,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            loaded_xy = template_io.read_style_template(
                "Shared",
                template_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
            )
            loaded_xy_style = template_io.read_xy_style_template(
                "Shared",
                template_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
            )
            families = template_io.style_template_families(
                "Shared",
                template_dir,
            )

        self.assertEqual(saved["version"], 2)
        self.assertEqual(
            set(saved),
            {"version", "common", "variants"},
        )
        self.assertEqual(
            set(saved["variants"]),
            {"groups", "xy"},
        )
        self.assertEqual(saved["common"]["preset"], "Viridis")
        self.assertEqual(saved["common"]["width"], 24.0)
        self.assertEqual(
            saved["variants"]["groups"]["chart_type"],
            "Violin",
        )
        self.assertEqual(
            saved["variants"]["groups"]["point_size"],
            8.0,
        )
        self.assertEqual(
            saved["variants"]["groups"]["custom_colors"],
            {"group:1": "#446688"},
        )
        self.assertNotIn("group_col", saved["variants"]["groups"])
        self.assertNotIn("value_col", saved["variants"]["groups"])
        self.assertNotIn("manual_group_order", saved["variants"]["groups"])
        self.assertNotIn("auto_x_range", saved["variants"]["groups"])
        self.assertEqual(saved["variants"]["xy"]["x_min"], -5.0)
        self.assertEqual(saved["variants"]["xy"]["y_min"], -10.0)
        self.assertNotIn("point_size", saved["variants"]["xy"])
        self.assertEqual(families, {"groups", "xy"})
        self.assertEqual(loaded_default.chart_type, "Violin")
        self.assertEqual(asdict(loaded_default), asdict(loaded_groups))
        self.assertEqual(loaded_groups.preset, "Viridis")
        self.assertEqual(loaded_groups.width, 24.0)
        self.assertEqual(loaded_groups.y_min, -3.0)
        self.assertEqual(loaded_groups.group_col, "group")
        self.assertEqual(loaded_groups.value_col, "value")
        self.assertEqual(loaded_xy.x_min, -5.0)
        self.assertEqual(loaded_xy.y_min, -10.0)
        self.assertEqual(loaded_xy_style.marker, "Diamond")

    def test_v2_save_updates_only_current_variant_and_shared_common(self):
        first_xy = ChartSettings(width=10.0, auto_x_range=False, x_min=-2.0)
        groups = ChartSettings(
            chart_type="Ridge",
            width=16.0,
            point_alpha=0.4,
        )
        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = template_io.write_style_template(
                "Two families",
                first_xy,
                template_dir,
                xy_settings=template_io.XYStyleTemplate(marker="Square"),
            )
            xy_before = json.loads(path.read_text(encoding="utf-8"))["variants"]["xy"]
            template_io.write_style_template(
                "Two families",
                groups,
                template_dir,
            )
            saved = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(saved["common"]["width"], 16.0)
        self.assertEqual(saved["variants"]["xy"], xy_before)
        self.assertEqual(
            saved["variants"]["groups"]["chart_type"],
            "Ridge",
        )

    def test_legacy_family_detection_and_migration(self):
        groups_data = asdict(ChartSettings(chart_type="Violin"))
        groups_data["group_col"] = "legacy-group"
        xy_data = asdict(
            ChartSettings(
                chart_type="Scatter",
                auto_x_range=False,
                x_min=-7.0,
            )
        )
        xy_data["xy_style"] = asdict(
            template_io.XYStyleTemplate(marker="Triangle")
        )

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = pathlib.Path(tmp)
            groups_path = tmp_path / "old groups.json"
            xy_path = tmp_path / "old xy.json"
            groups_path.write_text(
                json.dumps(groups_data),
                encoding="utf-8",
            )
            xy_path.write_text(json.dumps(xy_data), encoding="utf-8")

            self.assertEqual(
                template_io.style_template_families_file(groups_path),
                {template_io.TEMPLATE_FAMILY_GROUPS},
            )
            self.assertEqual(
                template_io.style_template_families_file(xy_path),
                {template_io.TEMPLATE_FAMILY_XY},
            )
            self.assertEqual(
                template_io.read_style_template_file(groups_path).group_col,
                "legacy-group",
            )
            with self.assertRaisesRegex(ValueError, "no xy variant"):
                template_io.read_style_template_file(
                    groups_path,
                    family=template_io.TEMPLATE_FAMILY_XY,
                )

            imported_dir = tmp_path / "templates"
            name, _settings = template_io.import_style_template(
                xy_path,
                imported_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
            )
            imported_path = imported_dir / f"{name}.json"
            migrated = json.loads(imported_path.read_text(encoding="utf-8"))

        self.assertEqual(migrated["version"], 2)
        self.assertEqual(set(migrated["variants"]), {"xy"})
        self.assertNotIn("group_col", migrated["variants"]["xy"])
        self.assertEqual(
            migrated["variants"]["xy"]["xy_style"]["marker"],
            "Triangle",
        )

    def test_interim_v2_distribution_key_reads_as_groups_and_migrates(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = pathlib.Path(tmp)
            path = template_io.write_style_template(
                "Interim",
                ChartSettings(chart_type="Violin", point_size=7.0),
                tmp_path,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            interim = json.loads(path.read_text(encoding="utf-8"))
            interim["variants"]["distribution"] = interim["variants"].pop(
                "groups"
            )
            path.write_text(json.dumps(interim), encoding="utf-8")

            self.assertEqual(
                template_io.style_template_families_file(path),
                {template_io.TEMPLATE_FAMILY_GROUPS},
            )
            loaded = template_io.read_style_template_file(
                path,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            with self.assertRaisesRegex(
                ValueError,
                "Unknown style template family: distribution",
            ):
                template_io.read_style_template_file(
                    path,
                    family="distribution",
                )

            imported_dir = tmp_path / "imported"
            imported_name, _settings = template_io.import_style_template(
                path,
                imported_dir,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            imported = json.loads(
                (imported_dir / f"{imported_name}.json").read_text(
                    encoding="utf-8"
                )
            )

            template_io.write_style_template(
                "Interim",
                ChartSettings(chart_type="Box", point_size=9.0),
                tmp_path,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            saved = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(loaded.chart_type, "Violin")
        self.assertEqual(set(imported["variants"]), {"groups"})
        self.assertEqual(set(saved["variants"]), {"groups"})
        self.assertEqual(saved["variants"]["groups"]["chart_type"], "Box")

    def test_v2_rejects_groups_and_interim_key_together(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = pathlib.Path(tmp)
            path = template_io.write_style_template(
                "Ambiguous",
                ChartSettings(),
                tmp_path,
            )
            document = json.loads(path.read_text(encoding="utf-8"))
            document["variants"]["distribution"] = dict(
                document["variants"]["groups"]
            )
            path.write_text(json.dumps(document), encoding="utf-8")

            with self.assertRaisesRegex(
                ValueError,
                "ambiguous groups variants",
            ):
                template_io.read_style_template_file(path)

    def test_apply_template_preserves_data_mapping_and_content(self):
        current = ChartSettings(
            group_col="current-group",
            value_col="current-value",
            title="Current title",
            manual_group_order=["B", "A"],
            group_hidden=["B"],
            custom_overlay_count=2,
            custom_overlay_series=[{"name": "Current overlay", "values": {}}],
            custom_overlay_hidden=[0],
        )
        template = ChartSettings(
            group_col="template-group",
            value_col="template-value",
            title="Template title",
            manual_group_order=["X"],
            group_hidden=["X"],
        )

        applied = template_io.apply_style_template_settings(current, template)

        self.assertEqual(applied.group_col, "current-group")
        self.assertEqual(applied.value_col, "current-value")
        self.assertEqual(applied.title, "Current title")
        self.assertEqual(applied.manual_group_order, ["B", "A"])
        self.assertEqual(applied.group_hidden, ["B"])
        self.assertEqual(applied.custom_overlay_count, 1)
        self.assertEqual(applied.custom_overlay_series, current.custom_overlay_series)
        self.assertEqual(applied.custom_overlay_hidden, [0])

    def test_template_listing_can_filter_by_family(self):
        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            template_io.write_style_template("Groups", ChartSettings(), template_dir)
            template_io.write_style_template(
                "XY",
                ChartSettings(),
                template_dir,
                xy_settings=template_io.XYStyleTemplate(),
            )
            (template_dir / "broken.json").write_text("{", encoding="utf-8")
            (template_dir / "future.json").write_text(
                json.dumps({"version": 99, "common": {}, "variants": {}}),
                encoding="utf-8",
            )

            self.assertEqual(
                template_io.list_style_templates(
                    template_dir,
                    family=template_io.TEMPLATE_FAMILY_GROUPS,
                ),
                ["Groups"],
            )
            self.assertEqual(
                template_io.list_style_templates(
                    template_dir,
                    family=template_io.TEMPLATE_FAMILY_XY,
                ),
                ["XY"],
            )
            self.assertEqual(
                template_io.list_style_templates(template_dir),
                ["Groups", "XY", "broken", "future"],
            )

    def test_import_style_template_copies_external_json(self):
        self.settings.chart_type = "Violin"
        self.settings.title = "External style"
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = pathlib.Path(tmp)
            external = tmp_path / "external style.json"
            external.write_text(json.dumps(asdict(self.settings)), encoding="utf-8")

            name, loaded = template_io.import_style_template(external, tmp_path / "templates")

            self.assertEqual(name, "external style")
            self.assertTrue((tmp_path / "templates" / "external style.json").exists())
            self.assertEqual(loaded.chart_type, "Violin")
            self.assertEqual(loaded.title, "Distribution plot")
