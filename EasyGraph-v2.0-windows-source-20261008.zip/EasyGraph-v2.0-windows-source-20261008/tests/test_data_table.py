import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable


class DataTableTests(EasyGraphQtTestCase):
    def test_data_table_is_owned_by_focused_module(self):
        self.assertEqual(DataTable.__module__, "easygraph.data_table")

    def test_data_table_round_trips_dataframe_text(self):
        table = DataTable()
        self.addCleanup(table.deleteLater)
        frame = pd.DataFrame({"A": [1, None], "": ["x", ""]})

        table.set_dataframe(frame)
        table.table_model.set_cell_text(0, 1, "")

        result = table.dataframe()

        self.assertEqual(list(result.columns), ["A", "Group 2"])
        self.assertEqual(result.iloc[0, 0], "1.0")
        self.assertEqual(result.iloc[1, 0], "")
        self.assertEqual(result.iloc[0, 1], "x")
