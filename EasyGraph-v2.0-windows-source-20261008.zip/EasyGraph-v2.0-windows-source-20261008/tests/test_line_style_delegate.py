from __future__ import annotations

import ast
from pathlib import Path
from unittest import mock

from PySide6.QtCore import QRect
from PySide6.QtGui import QImage, QPainter
from PySide6.QtWidgets import QComboBox, QStyleOptionViewItem

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.plotting.overlay_renderer import (
    LINE_STYLE_POPUP_PREVIEW_WIDTH,
    LINE_STYLE_POPUP_ROW_HEIGHT,
)
from easygraph.ui import line_style_delegate


class LineStyleDelegateTests(EasyGraphQtTestCase):
    def _combo(self) -> QComboBox:
        combo = QComboBox()
        combo.addItem("Dashed")
        self.addCleanup(combo.close)
        return combo

    def test_delegate_is_owned_by_ui_module_and_preserves_size_floor(self):
        combo = self._combo()
        delegate = line_style_delegate.LineStyleItemDelegate(combo.view())
        option = QStyleOptionViewItem()
        option.rect = QRect(0, 0, 220, 30)
        option.widget = combo.view()

        hint = delegate.sizeHint(option, combo.model().index(0, 0))

        self.assertGreaterEqual(hint.width(), LINE_STYLE_POPUP_PREVIEW_WIDTH + 150)
        self.assertGreaterEqual(hint.height(), LINE_STYLE_POPUP_ROW_HEIGHT)

    def test_delegate_paint_uses_line_preview_boundary(self):
        combo = self._combo()
        delegate = line_style_delegate.LineStyleItemDelegate(combo.view())
        option = QStyleOptionViewItem()
        option.rect = QRect(0, 0, 240, 36)
        option.widget = combo.view()
        option.palette = combo.palette()
        image = QImage(240, 36, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(0)
        painter = QPainter(image)

        try:
            with mock.patch.object(
                line_style_delegate, "draw_line_style_preview"
            ) as preview:
                delegate.paint(painter, option, combo.model().index(0, 0))
        finally:
            painter.end()

        preview.assert_called_once()
        self.assertEqual(preview.call_args.args[1], "Dashed")

    def test_delegate_module_has_narrow_import_boundary(self):
        source_path = Path(line_style_delegate.__file__)
        tree = ast.parse(source_path.read_text(encoding="utf-8"))
        forbidden_parts = {
            "app",
            "canvas",
            "matplotlib",
            "numpy",
            "pandas",
            "project_io",
            "scipy",
            "seaborn",
            "spreadsheet_io",
            "template_io",
        }

        def assert_allowed_imports(import_tree: ast.Module) -> None:
            imported_modules = {
                node.module
                for node in ast.walk(import_tree)
                if isinstance(node, ast.ImportFrom) and node.module is not None
            }
            imported_modules.update(
                f"{node.module}.{alias.name}"
                for node in ast.walk(import_tree)
                if isinstance(node, ast.ImportFrom) and node.module is not None
                for alias in node.names
                if alias.name != "*"
            )
            imported_modules.update(
                alias.name
                for node in ast.walk(import_tree)
                if isinstance(node, ast.Import)
                for alias in node.names
            )
            imported_aliases = [
                alias
                for node in ast.walk(import_tree)
                if isinstance(node, (ast.Import, ast.ImportFrom))
                for alias in node.names
            ]
            for module in imported_modules:
                parts = set(module.split("."))
                self.assertFalse(parts & forbidden_parts)
                self.assertFalse(any(part.startswith("ui_") for part in parts))
            self.assertFalse(
                any(
                    alias.name == "MainWindow" or alias.asname == "MainWindow"
                    for alias in imported_aliases
                )
            )

        assert_allowed_imports(tree)
        with self.assertRaises(AssertionError):
            assert_allowed_imports(
                ast.parse("from ui_group_colors_dialog import Ui_GroupColorsDialog")
            )
        with self.assertRaises(AssertionError):
            assert_allowed_imports(
                ast.parse("from easygraph.ui.main_window import MainWindow")
            )
        with self.assertRaises(AssertionError):
            assert_allowed_imports(
                ast.parse("from easygraph.ui import ui_group_colors_dialog")
            )
        with self.assertRaises(AssertionError):
            assert_allowed_imports(
                ast.parse("from easygraph.plotting import canvas")
            )
