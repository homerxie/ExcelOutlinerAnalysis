from __future__ import annotations

from unittest import mock

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph import palette
from easygraph.ui import dialogs
from easygraph.ui.dialogs import ChecklistItem


class DialogTests(EasyGraphQtTestCase):
    def test_factories_load_generated_shells(self):
        parent = QDialog()
        self.addCleanup(parent.close)
        checklist, checklist_ui = dialogs.create_checklist_filter_dialog(parent, "Group Filter")
        order, order_ui = dialogs.create_group_order_dialog(parent)
        colors, colors_ui = dialogs.create_group_colors_dialog(parent)
        styles, styles_ui = dialogs.create_overlay_styles_dialog(parent)
        for dialog in (checklist, order, colors, styles):
            self.addCleanup(dialog.close)
        self.assertEqual(checklist.windowTitle(), "Group Filter")
        self.assertIs(checklist_ui.itemList.parent(), checklist)
        self.assertIs(order_ui.groupList.parent(), order)
        self.assertEqual(order_ui.tableOrderButton.text(), "Table Order")
        self.assertIs(colors_ui.paletteCombo.parent(), colors_ui.paletteRow)
        self.assertIs(
            colors_ui.guidePaletteCombo.parent(),
            colors_ui.guidePaletteRow,
        )
        self.assertIs(colors_ui.rowsScroll.widget(), colors_ui.rowsContainer)
        self.assertEqual(styles.windowTitle(), "Custom Overlay Line Styles")
        self.assertIs(styles_ui.rowsScroll.widget(), styles_ui.rowsContainer)

    def test_group_order_accepts_table_order_button_result(self):
        parent = QDialog()
        dialog, ui = dialogs.create_group_order_dialog(parent)
        self.addCleanup(parent.close)
        self.addCleanup(dialog.close)

        def execute():
            ui.tableOrderButton.click()
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_group_order_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_group_order_dialog(parent, ["B", "A"], ["A", "B"])
        self.assertEqual(result, ["A", "B"])

    def test_group_order_cancel_returns_none(self):
        parent = QDialog()
        self.addCleanup(parent.close)
        with mock.patch.object(dialogs.QDialog, "exec", return_value=QDialog.Rejected):
            self.assertIsNone(dialogs.run_group_order_dialog(parent, ["B", "A"], ["A", "B"]))

    def test_checklist_accepts_hidden_item_keys(self):
        parent = QDialog()
        dialog, ui = dialogs.create_checklist_filter_dialog(parent, "Group Filter")
        self.addCleanup(parent.close)
        self.addCleanup(dialog.close)

        def execute():
            ui.itemList.item(0).setCheckState(Qt.Unchecked)
            ui.itemList.item(1).setCheckState(Qt.Checked)
            return QDialog.Accepted

        items = [ChecklistItem("a", "A"), ChecklistItem("b", "B")]
        with mock.patch.object(dialogs, "create_checklist_filter_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_checklist_filter_dialog(parent, "Group Filter", items, {"b"})
        self.assertEqual(result, ["a"])

    def test_checklist_cancel_returns_none(self):
        parent = QDialog()
        self.addCleanup(parent.close)
        items = [ChecklistItem("a", "A")]
        with mock.patch.object(dialogs.QDialog, "exec", return_value=QDialog.Rejected):
            self.assertIsNone(dialogs.run_checklist_filter_dialog(parent, "Group Filter", items, set()))

    def _captured_colors_dialog(self):
        parent = QDialog()
        dialog, ui = dialogs.create_group_colors_dialog(parent)
        self.addCleanup(parent.close)
        self.addCleanup(dialog.close)
        return parent, dialog, ui

    def test_color_palettes_emit_group_and_overlay_preview(self):
        parent, dialog, ui = self._captured_colors_dialog()
        settings = dialogs.ChartSettings(extra_custom_overlay=True)
        preview = mock.Mock()

        def execute():
            ui.paletteCombo.setCurrentText("Presentation")
            ui.overlayPaletteCombo.setCurrentText("Viridis")
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_group_colors_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_group_colors_dialog(
                parent, settings, ["A"], [("custom:0", "Limit")], preview, mock.Mock()
            )
        self.assertEqual(result.preset, "Presentation")
        self.assertEqual(result.overlay_palette, "Viridis")
        self.assertEqual(preview.call_args.args[0], result)

    def test_color_swatches_and_reset_update_matching_dictionary(self):
        parent, dialog, ui = self._captured_colors_dialog()
        settings = dialogs.ChartSettings(
            custom_colors={"A": "#112233"},
            custom_overlay_colors={"custom:0": "#445566"},
            extra_custom_overlay=True,
        )
        preview = mock.Mock()

        def execute():
            group_swatch = next(
                button for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-swatch" and button.property("colorKey") == "A"
            )
            overlay_reset = next(
                button for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-reset" and button.property("colorKey") == "custom:0"
            )
            group_swatch.click()
            overlay_reset.click()
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_group_colors_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_group_colors_dialog(
                parent, settings, ["A"], [("custom:0", "Limit")], preview, mock.Mock()
            )
        self.assertIn("A", result.custom_colors)
        self.assertNotIn("custom:0", result.overlay_colors)

    def test_color_swatch_updates_selection_before_emitting_preview(self):
        parent, dialog, ui = self._captured_colors_dialog()
        clicked_button = []
        preview_styles = []

        def preview(_selection):
            preview_styles.append(clicked_button[0].styleSheet())

        def execute():
            group_swatches = [
                button for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-swatch"
                and button.property("colorKey") == "A"
            ]
            target = next(
                button for button in group_swatches
                if "3px solid #60A5FA" not in button.styleSheet()
            )
            clicked_button.append(target)
            target.click()
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_group_colors_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            dialogs.run_group_colors_dialog(
                parent, dialogs.ChartSettings(), ["A"], [], preview, mock.Mock()
            )

        self.assertEqual(len(preview_styles), 1)
        self.assertIn("3px solid #60A5FA", preview_styles[0])

    def test_group_color_dialog_allows_custom_color_to_match_another_group(self):
        parent, dialog, ui = self._captured_colors_dialog()
        preview = mock.Mock()

        def execute():
            group_a_second_color = next(
                button for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-swatch"
                and button.property("colorKey") == "A"
                and button.property("colorIndex") == 1
            )
            group_a_second_color.click()
            group_b_second_color = next(
                button for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-swatch"
                and button.property("colorKey") == "B"
                and button.property("colorIndex") == 1
            )
            self.assertIn("3px solid #60A5FA", group_a_second_color.styleSheet())
            self.assertIn("3px solid #60A5FA", group_b_second_color.styleSheet())
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_group_colors_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_group_colors_dialog(
                parent, dialogs.ChartSettings(), ["A", "B"], [], preview, mock.Mock()
            )

        resolved = palette.group_color_map_for_groups(
            ["A", "B"],
            dialogs.ChartSettings(),
            custom_colors=result.custom_colors,
            preset_name=result.preset,
        )
        self.assertEqual(resolved["A"], resolved["B"])

    def test_color_swatch_borders_are_visible_on_dark_backgrounds(self):
        parent, dialog, ui = self._captured_colors_dialog()

        def execute():
            swatches = [
                button for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-swatch"
            ]
            self.assertTrue(any("3px solid #60A5FA" in button.styleSheet() for button in swatches))
            self.assertTrue(any("1px solid #6B7280" in button.styleSheet() for button in swatches))
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_group_colors_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            dialogs.run_group_colors_dialog(
                parent, dialogs.ChartSettings(), ["A"], [], mock.Mock(), mock.Mock()
            )

    def test_color_cancel_returns_none_after_live_preview(self):
        parent, dialog, ui = self._captured_colors_dialog()
        preview = mock.Mock()

        def execute():
            ui.paletteCombo.setCurrentText("Presentation")
            return QDialog.Rejected

        with mock.patch.object(dialogs, "create_group_colors_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_group_colors_dialog(
                parent, dialogs.ChartSettings(), ["A"], [], preview, mock.Mock()
            )
        self.assertIsNone(result)
        preview.assert_called()

    def test_guide_colors_share_one_palette_and_accept_axis_specific_slots(self):
        parent, dialog, ui = self._captured_colors_dialog()
        settings = dialogs.ChartSettings(
            additional_guide_palette="Viridis",
        )
        preview = mock.Mock()
        guide_items = [
            ("additional-guide:x:0", "X at 1", 2, 0),
            ("additional-guide:primary:0", "Y at 2", 4, 1),
        ]

        def guide_button(role, key, index=None):
            return next(
                button
                for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == role
                and button.property("colorKind") == "guide"
                and button.property("colorKey") == key
                and (
                    index is None
                    or button.property("colorIndex") == index
                )
            )

        def execute():
            self.assertTrue(ui.paletteRow.isHidden())
            self.assertTrue(ui.overlayPaletteRow.isHidden())
            self.assertFalse(ui.guidePaletteRow.isHidden())
            self.assertEqual(ui.guidePaletteCombo.currentText(), "Viridis")

            x_swatches = [
                button
                for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-swatch"
                and button.property("colorKind") == "guide"
                and button.property("colorKey") == "additional-guide:x:0"
            ]
            self.assertEqual(
                len(x_swatches),
                len(palette.palette_choices_for_group_count("Viridis", 2)),
            )
            self.assertIn(
                "3px solid #60A5FA",
                guide_button(
                    "color-swatch",
                    "additional-guide:x:0",
                    2,
                ).styleSheet(),
            )
            self.assertIn(
                "3px solid #60A5FA",
                guide_button(
                    "color-swatch",
                    "additional-guide:primary:0",
                    4,
                ).styleSheet(),
            )

            ui.guidePaletteCombo.setCurrentText("Presentation")
            self.assertEqual(
                preview.call_args.args[0].guide_color_indices,
                {
                    "additional-guide:x:0": 2,
                    "additional-guide:primary:0": 4,
                },
            )
            guide_button(
                "color-swatch",
                "additional-guide:x:0",
                3,
            ).click()
            guide_button(
                "color-reset",
                "additional-guide:primary:0",
            ).click()
            return QDialog.Accepted

        with mock.patch.object(
            dialogs,
            "create_group_colors_dialog",
            return_value=(dialog, ui),
        ), mock.patch.object(
            dialogs.QDialog,
            "exec",
            side_effect=execute,
        ):
            result = dialogs.run_group_colors_dialog(
                parent,
                settings,
                [],
                [],
                preview,
                mock.Mock(),
                guide_items=guide_items,
            )

        self.assertEqual(result.guide_palette, "Presentation")
        self.assertEqual(
            result.guide_color_indices,
            {
                "additional-guide:x:0": 3,
                "additional-guide:primary:0": 1,
            },
        )
        self.assertEqual(result.preset, settings.preset)
        self.assertEqual(result.overlay_palette, settings.custom_overlay_palette)
        self.assertGreaterEqual(preview.call_count, 3)

    def test_guide_color_cancel_returns_none_after_palette_and_swatch_preview(self):
        parent, dialog, ui = self._captured_colors_dialog()
        preview = mock.Mock()

        def execute():
            ui.guidePaletteCombo.setCurrentText("Presentation")
            swatch = next(
                button
                for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-swatch"
                and button.property("colorKind") == "guide"
                and button.property("colorKey")
                == "additional-guide:primary:0"
                and button.property("colorIndex") == 3
            )
            swatch.click()
            return QDialog.Rejected

        with mock.patch.object(
            dialogs,
            "create_group_colors_dialog",
            return_value=(dialog, ui),
        ), mock.patch.object(
            dialogs.QDialog,
            "exec",
            side_effect=execute,
        ):
            result = dialogs.run_group_colors_dialog(
                parent,
                dialogs.ChartSettings(),
                ["A"],
                [],
                preview,
                mock.Mock(),
                guide_items=[
                    (
                        "additional-guide:primary:0",
                        "Value at 5",
                        0,
                        0,
                    )
                ],
            )

        self.assertIsNone(result)
        self.assertGreaterEqual(preview.call_count, 2)
        self.assertEqual(preview.call_args.args[0].guide_palette, "Presentation")
        self.assertEqual(
            preview.call_args.args[0].guide_color_indices,
            {"additional-guide:primary:0": 3},
        )

    def test_color_dialog_hides_guide_palette_when_no_guides_are_supplied(self):
        parent, dialog, ui = self._captured_colors_dialog()

        def execute():
            self.assertTrue(ui.guidePaletteRow.isHidden())
            self.assertEqual(
                [
                    button
                    for button in dialog.findChildren(dialogs.QPushButton)
                    if button.property("colorKind") == "guide"
                ],
                [],
            )
            return QDialog.Accepted

        with mock.patch.object(
            dialogs,
            "create_group_colors_dialog",
            return_value=(dialog, ui),
        ), mock.patch.object(
            dialogs.QDialog,
            "exec",
            side_effect=execute,
        ):
            result = dialogs.run_group_colors_dialog(
                parent,
                dialogs.ChartSettings(),
                ["A"],
                [],
                mock.Mock(),
                mock.Mock(),
            )

        self.assertEqual(result.guide_color_indices, {})

    def test_color_dialog_can_show_series_labels_while_returning_stable_keys(self):
        parent, dialog, ui = self._captured_colors_dialog()

        def execute():
            labels = [
                label.text()
                for label in dialog.findChildren(dialogs.QLabel)
                if label.text() in {"Dose A", "Dose A · Column 4"}
            ]
            self.assertEqual(labels, ["Dose A", "Dose A · Column 4"])
            swatch = next(
                button
                for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "color-swatch"
                and button.property("colorKey") == "series-2"
            )
            swatch.click()
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_group_colors_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_group_colors_dialog(
                parent,
                dialogs.ChartSettings(),
                ["series-1", "series-2"],
                [],
                mock.Mock(),
                mock.Mock(),
                title="Series Colors",
                item_labels={
                    "series-1": "Dose A",
                    "series-2": "Dose A · Column 4",
                },
            )

        self.assertEqual(dialog.windowTitle(), "Series Colors")
        self.assertIn("series-2", result.custom_colors)

    def test_color_accept_filters_group_keys_preserves_overlay_keys_and_copies(self):
        parent, dialog, ui = self._captured_colors_dialog()
        settings = dialogs.ChartSettings(
            custom_colors={"A": "#112233", "removed": "#223344"},
            custom_overlay_colors={"custom:0": "#334455", "custom:9": "#445566"},
            extra_custom_overlay=True,
        )
        with mock.patch.object(dialogs, "create_group_colors_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", return_value=QDialog.Accepted):
            result = dialogs.run_group_colors_dialog(
                parent, settings, ["A"], [("custom:0", "Limit")], mock.Mock(), mock.Mock()
            )
        self.assertEqual(result.custom_colors, {"A": "#112233"})
        self.assertEqual(result.overlay_colors, settings.custom_overlay_colors)
        result.custom_colors["A"] = "#ffffff"
        self.assertEqual(settings.custom_colors["A"], "#112233")

    def _captured_overlay_styles_dialog(self):
        parent = QDialog()
        dialog, ui = dialogs.create_overlay_styles_dialog(parent)
        self.addCleanup(parent.close)
        self.addCleanup(dialog.close)
        return parent, dialog, ui

    @staticmethod
    def _populate_test_styles(combo):
        combo.addItems(list(dialogs.LINE_OVERLAY_STYLES))

    def test_overlay_style_combo_emits_typed_preview(self):
        parent, dialog, ui = self._captured_overlay_styles_dialog()
        preview = mock.Mock()

        def execute():
            combo = next(
                combo for combo in dialog.findChildren(dialogs.QComboBox)
                if combo.property("dialogRole") == "overlay-style-combo"
                and combo.property("styleKey") == "custom:0"
            )
            combo.setCurrentText("Dashed")
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_overlay_styles_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_overlay_styles_dialog(
                parent,
                [("custom:0", "Limit")],
                "Auto",
                {},
                preview,
                self._populate_test_styles,
                mock.Mock(),
            )
        self.assertEqual(result, dialogs.OverlayStyleSelection({"custom:0": "Dashed"}))
        self.assertEqual(preview.call_args.args[0], result)

    def test_overlay_style_base_choice_removes_override(self):
        parent, dialog, ui = self._captured_overlay_styles_dialog()

        def execute():
            combo = next(
                combo for combo in dialog.findChildren(dialogs.QComboBox)
                if combo.property("styleKey") == "custom:0"
            )
            combo.setCurrentText("Auto")
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_overlay_styles_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_overlay_styles_dialog(
                parent,
                [("custom:0", "Limit")],
                "Auto",
                {"custom:0": "Dotted"},
                mock.Mock(),
                self._populate_test_styles,
                mock.Mock(),
            )
        self.assertEqual(result.styles, {})

    def test_overlay_style_reset_removes_only_matching_override(self):
        parent, dialog, ui = self._captured_overlay_styles_dialog()

        def execute():
            reset = next(
                button for button in dialog.findChildren(dialogs.QPushButton)
                if button.property("dialogRole") == "overlay-style-reset"
                and button.property("styleKey") == "custom:0"
            )
            reset.click()
            return QDialog.Accepted

        with mock.patch.object(dialogs, "create_overlay_styles_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_overlay_styles_dialog(
                parent,
                [("custom:0", "Limit"), ("custom:1", "Target")],
                "Auto",
                {"custom:0": "Dotted", "custom:1": "Dashed"},
                mock.Mock(),
                self._populate_test_styles,
                mock.Mock(),
            )
        self.assertEqual(result.styles, {"custom:1": "Dashed"})

    def test_overlay_style_accept_filters_and_copies(self):
        parent, dialog, ui = self._captured_overlay_styles_dialog()
        supplied = {
            "custom:0": "Dotted",
            "custom:1": "Invalid",
            "stale": "Dashed",
        }
        with mock.patch.object(dialogs, "create_overlay_styles_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", return_value=QDialog.Accepted):
            result = dialogs.run_overlay_styles_dialog(
                parent,
                [("custom:0", "Limit"), ("custom:1", "Target")],
                "Auto",
                supplied,
                mock.Mock(),
                self._populate_test_styles,
                mock.Mock(),
            )
        self.assertEqual(result.styles, {"custom:0": "Dotted"})
        result.styles["custom:0"] = "Solid"
        self.assertEqual(supplied["custom:0"], "Dotted")

    def test_overlay_style_cancel_returns_none_after_preview(self):
        parent, dialog, ui = self._captured_overlay_styles_dialog()
        preview = mock.Mock()

        def execute():
            combo = next(
                combo for combo in dialog.findChildren(dialogs.QComboBox)
                if combo.property("dialogRole") == "overlay-style-combo"
            )
            combo.setCurrentText("Dashed")
            return QDialog.Rejected

        with mock.patch.object(dialogs, "create_overlay_styles_dialog", return_value=(dialog, ui)), \
             mock.patch.object(dialogs.QDialog, "exec", side_effect=execute):
            result = dialogs.run_overlay_styles_dialog(
                parent,
                [("custom:0", "Limit")],
                "Auto",
                {},
                preview,
                self._populate_test_styles,
                mock.Mock(),
            )
        self.assertIsNone(result)
        preview.assert_called_once_with(dialogs.OverlayStyleSelection({"custom:0": "Dashed"}))
