"""Two-level plot ordering preserves group membership and table values."""
from __future__ import annotations

from copy import deepcopy
import unittest
from unittest.mock import patch

from PySide6.QtCore import QModelIndex, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QAbstractItemView, QApplication, QDialog, QWidget

from easygraph.ui.group_order_dialog import create_grouped_order_dialog, run_grouped_order_dialog


class GroupedOrderDialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.table_order = ["a", "b", "x", "c", "d", "e", "y"]
        self.parents = [
            {"id": "first", "name": "Treatment", "column_ids": ["a", "b"]},
            {"id": "second", "name": "Treatment", "column_ids": ["c", "d", "e"]},
        ]
        self.labels = {key: f"Column {key}" for key in self.table_order}
        self.dialog, self.ui, self.controller = create_grouped_order_dialog(
            None, self.table_order, self.table_order, parents=self.parents, item_labels=self.labels,
        )
        self.dialog.show()
        self.app.processEvents()
        self.addCleanup(self.dialog.close)
        self.addCleanup(self.dialog.deleteLater)

    @staticmethod
    def keys(widget):
        return [widget.item(row).data(Qt.UserRole) for row in range(widget.count())]

    @staticmethod
    def select_rows(widget, rows):
        widget.clearSelection()
        for row in rows:
            widget.item(row).setSelected(True)

    @staticmethod
    def click_row(widget, row):
        QTest.mouseClick(widget.viewport(), Qt.LeftButton, Qt.NoModifier, widget.visualItemRect(widget.item(row)).center())

    def test_mixed_and_same_name_groups_keep_distinct_blocks(self):
        self.assertEqual(self.keys(self.ui.outerList), ["parent:first", "column:x", "parent:second", "column:y"])
        first_label = self.ui.outerList.item(0).text()
        second_label = self.ui.outerList.item(2).text()
        self.assertIn("Treatment", first_label)
        self.assertIn("Treatment", second_label)
        self.assertNotEqual(first_label, second_label)
        self.assertEqual(self.keys(self.ui.innerList), ["a", "b"])
        self.assertEqual(self.controller.order(), self.table_order)

    def test_buttons_move_whole_group_and_preserve_member_order(self):
        QTest.mouseClick(self.ui.outerDownButton, Qt.LeftButton)
        self.assertEqual(self.controller.order(), ["x", "a", "b", "c", "d", "e", "y"])
        self.assertEqual(self.keys(self.ui.innerList), ["a", "b"])
        QTest.mouseClick(self.ui.innerDownButton, Qt.LeftButton)
        self.assertEqual(self.controller.order(), ["x", "b", "a", "c", "d", "e", "y"])
        self.click_row(self.ui.outerList, 2)
        self.click_row(self.ui.innerList, 2)
        QTest.mouseClick(self.ui.innerUpButton, Qt.LeftButton)
        self.click_row(self.ui.outerList, 1)
        self.assertEqual(self.keys(self.ui.innerList), ["b", "a"])
        self.assertEqual(self.controller.order(), ["x", "b", "a", "c", "e", "d", "y"])

    def test_multi_selection_moves_each_selected_run_one_step(self):
        self.click_row(self.ui.outerList, 2)
        self.select_rows(self.ui.innerList, [1, 2])
        QTest.mouseClick(self.ui.innerUpButton, Qt.LeftButton)
        self.assertEqual(self.keys(self.ui.innerList), ["d", "e", "c"])
        self.assertEqual([item.data(Qt.UserRole) for item in self.ui.innerList.selectedItems()], ["d", "e"])
        self.assertFalse(self.ui.innerUpButton.isEnabled())
        self.select_rows(self.ui.outerList, [1, 2])
        self.assertFalse(self.ui.innerList.isEnabled())
        QTest.mouseClick(self.ui.outerUpButton, Qt.LeftButton)
        self.assertEqual(self.controller.order(), ["x", "d", "e", "c", "a", "b", "y"])
        self.assertFalse(self.ui.outerUpButton.isEnabled())
        QTest.mouseClick(self.ui.outerDownButton, Qt.LeftButton)
        self.assertEqual(self.controller.order(), ["a", "b", "x", "d", "e", "c", "y"])

    def test_noncontiguous_selection_keeps_relative_order(self):
        self.select_rows(self.ui.outerList, [1, 3])
        QTest.mouseClick(self.ui.outerUpButton, Qt.LeftButton)
        self.assertEqual(self.controller.order(), ["x", "a", "b", "y", "c", "d", "e"])
        QTest.mouseClick(self.ui.outerDownButton, Qt.LeftButton)
        self.assertEqual(self.controller.order(), self.table_order)

    def test_internal_move_model_changes_save_across_group_switches(self):
        # These are the row moves emitted by QListWidget's InternalMove drops.
        self.assertTrue(self.ui.innerList.model().moveRows(QModelIndex(), 0, 1, QModelIndex(), 2))
        self.assertEqual(self.keys(self.ui.innerList), ["b", "a"])
        self.assertTrue(self.ui.outerList.model().moveRows(QModelIndex(), 0, 1, QModelIndex(), 3))
        self.assertEqual(self.controller.order(), ["x", "c", "d", "e", "b", "a", "y"])
        self.click_row(self.ui.outerList, 1)
        self.assertEqual(self.keys(self.ui.innerList), ["c", "d", "e"])
        self.assertTrue(self.ui.innerList.model().moveRows(QModelIndex(), 1, 2, QModelIndex(), 0))
        self.click_row(self.ui.outerList, 2)
        self.assertEqual(self.keys(self.ui.innerList), ["b", "a"])
        self.assertEqual(self.controller.order(), ["x", "d", "e", "c", "b", "a", "y"])
        for widget in (self.ui.outerList, self.ui.innerList):
            self.assertEqual(widget.dragDropMode(), QAbstractItemView.InternalMove)
            self.assertEqual(widget.defaultDropAction(), Qt.MoveAction)
            self.assertEqual(widget.selectionMode(), QAbstractItemView.ExtendedSelection)

    def test_ungrouped_column_moves_only_in_outer_list(self):
        self.click_row(self.ui.outerList, 1)
        self.assertEqual(self.keys(self.ui.innerList), ["x"])
        self.assertFalse(self.ui.innerList.isEnabled())
        self.assertFalse(self.ui.innerUpButton.isEnabled())
        self.assertFalse(self.ui.innerDownButton.isEnabled())
        self.assertIn("no parent group", self.ui.innerHintLabel.text())
        QTest.mouseClick(self.ui.outerDownButton, Qt.LeftButton)
        self.assertEqual(self.controller.order(), ["a", "b", "c", "d", "e", "x", "y"])

    def test_reset_restores_outer_and_inner_table_order(self):
        QTest.mouseClick(self.ui.innerDownButton, Qt.LeftButton)
        QTest.mouseClick(self.ui.outerDownButton, Qt.LeftButton)
        QTest.mouseClick(self.ui.tableOrderButton, Qt.LeftButton)
        self.assertEqual(self.controller.order(), self.table_order)
        self.assertEqual(self.keys(self.ui.innerList), ["a", "b"])

    def test_cancel_leaves_supplied_order_and_parent_metadata_unchanged(self):
        before = deepcopy(self.parents)
        parent = QWidget()
        self.addCleanup(parent.deleteLater)

        def cancel(dialog):
            controller = dialog.grouped_order_controller
            controller.move_selected(controller.ui.innerList, 1)
            controller.move_selected(controller.ui.outerList, 1)
            return QDialog.Rejected

        with patch.object(QDialog, "exec", cancel):
            result = run_grouped_order_dialog(
                parent, self.table_order, self.table_order, parents=self.parents, item_labels=self.labels,
            )
        self.assertIsNone(result)
        self.assertEqual(self.table_order, ["a", "b", "x", "c", "d", "e", "y"])
        self.assertEqual(self.parents, before)

    def test_accept_returns_flattened_ids_with_existing_custom_order(self):
        parent = QWidget()
        self.addCleanup(parent.deleteLater)
        with patch.object(QDialog, "exec", return_value=QDialog.Accepted):
            result = run_grouped_order_dialog(
                parent, ["y", "d", "c", "e", "x", "b", "a"], self.table_order,
                parents=self.parents, item_labels=self.labels,
            )
        self.assertEqual(result, ["y", "d", "c", "e", "x", "b", "a"])

    def test_minimum_size_keeps_both_lists_and_buttons_visible(self):
        self.dialog.resize(640, 440)
        self.app.processEvents()
        for widget in (self.ui.outerList, self.ui.innerList):
            self.assertGreater(widget.width(), 200)
            self.assertGreater(widget.height(), 200)
        self.assertEqual(self.ui.outerUpButton.height(), self.ui.innerUpButton.height())
        self.assertEqual(self.ui.tableOrderButton.height(), self.ui.outerUpButton.height())
        self.assertTrue(self.dialog.rect().contains(self.ui.buttonBox.geometry().bottomRight()))


if __name__ == "__main__":
    unittest.main()
