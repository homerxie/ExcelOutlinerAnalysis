from __future__ import annotations

import pathlib
import tempfile
from unittest import mock

import pandas as pd
from PySide6.QtWidgets import QFileDialog

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.spreadsheet_io import SpreadsheetSheet, write_spreadsheet_book
from easygraph.ui import main_window
from easygraph.workbook import SHEET_MODE_GROUPS, SHEET_MODE_XY


class MultiSheetUITests(EasyGraphQtTestCase):
    def test_new_window_has_one_sheet_and_add_creates_an_active_blank_sheet(self):
        window = self.make_window()

        self.assertEqual([sheet.name for sheet in window.workbook.sheets], ["Sheet 1"])
        self.assertEqual(window.sheet_tab_bar.count(), 1)
        self.assertEqual(window.sheet_tab_bar.tabText(0), "Sheet 1")

        window.add_sheet()

        self.assertEqual([sheet.name for sheet in window.workbook.sheets], ["Sheet 1", "Sheet 2"])
        self.assertEqual(window.workbook.active_index, 1)
        self.assertEqual(window.sheet_tab_bar.currentIndex(), 1)
        self.assertEqual(window.sheet_tab_bar.tabText(0), "Sheet 1")
        self.assertEqual(window.sheet_tab_bar.tabText(1), "Sheet 2 •")
        self.assertEqual(list(window.table_dataframe().columns), ["Group 1", "Group 2", "Group 3"])
        self.assertTrue((window.table_dataframe() == "").all().all())
        self.assertTrue(window.has_unsaved_changes())

    def test_switching_sheets_preserves_independent_data_settings_view_and_history(self):
        window = self.make_window()
        first_original = window.table.table_model.cell_text(1, 0)
        window.table.table_model.set_cell_text(1, 0, "111")
        window.title.setPlainText("First chart")
        first_index = window.table.table_model.index(2, 1)
        window.table.setCurrentIndex(first_index)

        window.add_sheet()
        window.table.table_model.set_cell_text(1, 0, "222")
        window.title.setPlainText("Second chart")
        window.undo_table_change()
        self.assertEqual(window.table.table_model.cell_text(1, 0), "")

        window.sheet_tab_bar.setCurrentIndex(0)
        self.assertEqual(window.table.table_model.cell_text(1, 0), "111")
        self.assertEqual(window.title.toPlainText(), "First chart")
        self.assertEqual((window.table.currentIndex().row(), window.table.currentIndex().column()), (2, 1))

        window.undo_table_change()
        self.assertEqual(window.table.table_model.cell_text(1, 0), first_original)

        window.sheet_tab_bar.setCurrentIndex(1)
        self.assertEqual(window.table.table_model.cell_text(1, 0), "")
        self.assertEqual(window.title.toPlainText(), "Second chart")

    def test_switching_between_ridge_and_xy_preserves_chart_type_and_order_icon(self):
        window = self.make_window()
        groups_sheet = window.workbook.active_sheet
        order_label = window.ui.toolbarOrderLabel
        horizontal_icon = order_label.pixmap().toImage()

        with mock.patch.object(window, "render"), mock.patch.object(window, "schedule_render"):
            window.chart_type.setCurrentText("Ridge")
            ridge_icon = order_label.pixmap().toImage()
            self.assertNotEqual(ridge_icon, horizontal_icon)

            window.add_sheet(SHEET_MODE_XY)
            xy_sheet = window.workbook.active_sheet
            self.assertEqual(groups_sheet.settings.chart_type, "Ridge")
            self.assertEqual(xy_sheet.settings.chart_type, "Scatter")
            self.assertEqual(order_label.pixmap().toImage(), horizontal_icon)

            window.sheet_tab_bar.setCurrentIndex(0)
            self.assertIs(window.settings, groups_sheet.settings)
            self.assertEqual(window.settings.chart_type, "Ridge")
            self.assertEqual(window.chart_type.currentText(), "Ridge")
            self.assertEqual(order_label.pixmap().toImage(), ridge_icon)
            self.assertEqual(xy_sheet.settings.chart_type, "Scatter")

    def test_switching_sheets_preserves_independent_overlay_rows(self):
        window = self.make_window()
        window.add_custom_overlay_row()
        window.table.table_model.set_cell_text(1, 0, "10")

        window.add_sheet()
        self.assertEqual(window.custom_overlay_row_count(), 0)

        window.sheet_tab_bar.setCurrentIndex(0)
        self.assertEqual(window.custom_overlay_row_count(), 1)
        self.assertEqual(window.table.table_model.cell_text(1, 0), "10")

        window.sheet_tab_bar.setCurrentIndex(1)
        self.assertEqual(window.custom_overlay_row_count(), 0)

    def test_duplicate_rename_reorder_and_delete_sheet(self):
        window = self.make_window()
        window.table.table_model.set_cell_text(1, 0, "42")
        window.title.setPlainText("Original chart")

        window.duplicate_sheet()
        self.assertEqual(len(window.workbook.sheets), 2)
        self.assertEqual(window.workbook.sheets[1].name, "Sheet 1 Copy")
        self.assertEqual(window.table.table_model.cell_text(1, 0), "42")
        self.assertEqual(window.title.toPlainText(), "Original chart")

        with mock.patch.object(main_window.QInputDialog, "getText", return_value=("Results", True)):
            window.rename_sheet(1)
        self.assertEqual(window.workbook.sheets[1].name, "Results")

        window.sheet_tab_bar.moveTab(1, 0)
        self.assertEqual([sheet.name for sheet in window.workbook.sheets], ["Results", "Sheet 1"])

        window.delete_sheet(0, confirm=False)
        self.assertEqual([sheet.name for sheet in window.workbook.sheets], ["Sheet 1"])
        self.assertEqual(window.table.table_model.cell_text(1, 0), "42")

    def test_multisheet_project_roundtrip_restores_active_sheet(self):
        window = self.make_window()
        window.table.table_model.set_cell_text(1, 0, "101")
        window.title.setPlainText("First")
        window.add_sheet()
        window.table.table_model.set_cell_text(1, 0, "202")
        window.title.setPlainText("Second")

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "multi.eg"
            window.current_project = path
            self.assertTrue(window.save_project())
            self.assertFalse(window.has_unsaved_changes())
            self.assertEqual(
                [window.sheet_tab_bar.tabText(index) for index in range(2)],
                ["Sheet 1", "Sheet 2"],
            )

            window.sheet_tab_bar.setCurrentIndex(0)
            self.assertFalse(window.has_unsaved_changes())

            loaded = self.make_window()
            loaded._load_project_path(path)

        self.assertEqual([sheet.name for sheet in loaded.workbook.sheets], ["Sheet 1", "Sheet 2"])
        self.assertEqual(loaded.workbook.active_index, 1)
        self.assertEqual(float(loaded.table.table_model.cell_text(1, 0)), 202.0)
        self.assertEqual(loaded.title.toPlainText(), "Second")
        self.assertFalse(loaded.has_unsaved_changes())

        loaded.sheet_tab_bar.setCurrentIndex(0)
        self.assertEqual(float(loaded.table.table_model.cell_text(1, 0)), 101.0)
        self.assertEqual(loaded.title.toPlainText(), "First")

    def test_import_and_export_excel_workbook_use_all_selected_sheets(self):
        source = [
            SpreadsheetSheet("First", pd.DataFrame({"A": [1, 2]})),
            SpreadsheetSheet("Second", pd.DataFrame({"B": [3, 4]})),
        ]
        window = self.make_window()
        with tempfile.TemporaryDirectory() as tmp:
            directory = pathlib.Path(tmp)
            input_path = directory / "input.xlsx"
            output_path = directory / "output.xlsx"
            write_spreadsheet_book(input_path, source)

            with (
                mock.patch.object(QFileDialog, "getOpenFileName", return_value=(str(input_path), "")),
                mock.patch.object(main_window, "choose_spreadsheet_sheets", side_effect=lambda _parent, sheets: sheets),
            ):
                window.import_excel()

            self.assertEqual([sheet.name for sheet in window.workbook.sheets], ["First", "Second"])
            self.assertTrue(window.has_unsaved_changes())

            with mock.patch.object(QFileDialog, "getSaveFileName", return_value=(str(output_path), "")):
                window.export_excel()

            with pd.ExcelFile(output_path) as exported:
                exported_names = exported.sheet_names

        self.assertEqual(exported_names, ["First", "Second"])

    def test_imported_worksheets_can_mix_groups_and_xy_modes(self):
        imported = [
            SpreadsheetSheet(
                "Groups",
                pd.DataFrame({"A": [1], "B": [2]}),
                mode=SHEET_MODE_GROUPS,
            ),
            SpreadsheetSheet(
                "XY",
                pd.DataFrame({"Time": [1, 2], "A": [3, 4], "B": [5, 6]}),
                mode=SHEET_MODE_XY,
            ),
        ]
        window = self.make_window()

        window._apply_imported_workbook(imported)

        self.assertEqual(
            [sheet.mode for sheet in window.workbook.sheets],
            [SHEET_MODE_GROUPS, SHEET_MODE_XY],
        )
        xy_sheet = window.workbook.sheets[1]
        self.assertEqual(
            xy_sheet.xy_settings.default_x_column_id,
            xy_sheet.column_ids[0],
        )
        self.assertEqual(
            [series.y_column_id for series in xy_sheet.xy_settings.series],
            xy_sheet.column_ids[1:],
        )

    def test_csv_filter_without_suffix_exports_only_the_active_sheet(self):
        window = self.make_window()
        window.add_sheet()
        window.table.table_model.set_cell_text(1, 0, "77")

        with tempfile.TemporaryDirectory() as tmp:
            base_path = pathlib.Path(tmp) / "current-sheet"
            csv_path = pathlib.Path(f"{base_path}.csv")
            with mock.patch.object(
                QFileDialog,
                "getSaveFileName",
                return_value=(str(base_path), "Current Sheet CSV (*.csv)"),
            ):
                window.export_excel()

            exported = pd.read_csv(csv_path)

        self.assertEqual(list(exported.columns), ["Group 1", "Group 2"])
        self.assertEqual(exported.iloc[0, 0], 77)

    def test_current_sheet_excel_filter_does_not_export_other_sheets(self):
        window = self.make_window()
        window.add_sheet()
        window.table.table_model.set_cell_text(1, 0, "88")

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "current.xlsx"
            with mock.patch.object(
                QFileDialog,
                "getSaveFileName",
                return_value=(str(path), "Current Sheet Excel (*.xlsx)"),
            ):
                window.export_excel()

            with pd.ExcelFile(path) as workbook:
                names = workbook.sheet_names
                exported = pd.read_excel(workbook, sheet_name=0)

        self.assertEqual(names, ["Sheet 2"])
        self.assertEqual(exported.iloc[0, 0], 88)

    def test_xy_csv_export_contains_only_visible_source_columns(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        sheet = window.workbook.active_sheet
        sheet.settings.custom_overlay_series = [
            {"name": "Should not export", "values": {"X": "99"}}
        ]
        window.table.table_model.set_cell_text(1, 0, "1")
        window.table.table_model.set_cell_text(1, 1, "2")

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "xy.csv"
            with mock.patch.object(
                QFileDialog,
                "getSaveFileName",
                return_value=(str(path), "Current Sheet CSV (*.csv)"),
            ):
                window.export_excel()
            exported = pd.read_csv(path)

        self.assertEqual(list(exported.columns[:4]), ["X", "1Y", "2Y", "1X"])
        self.assertTrue(exported.columns[4].startswith("1Y"))
        self.assertEqual(exported.columns[5], "2X")
        self.assertTrue(exported.columns[6].startswith("2Y"))
        self.assertNotIn("__easygraph_row_type", exported.columns)

    def test_xy_workspace_tabs_and_pairs_roundtrip_in_project(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
            window.add_xy_shared_table()
            window.add_xy_pair()
        sheet = window.workbook.active_sheet
        sheet.xy_settings.shared_tables[1].name = "Second shared set"
        window.table.table_model.set_cell_text(1, 0, "2")
        window.table.table_model.set_cell_text(1, 1, "20")
        window.xy_independent_table.table_model.set_cell_text(1, 0, "3")
        window.xy_independent_table.table_model.set_cell_text(1, 1, "30")

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "xy-workspace.eg"
            window.current_project = path
            self.assertTrue(window.save_project())
            loaded = self.make_window()
            with mock.patch.object(loaded, "render"):
                loaded._load_project_path(path)

        loaded_sheet = loaded.workbook.active_sheet
        self.assertEqual(
            [table.name for table in loaded_sheet.xy_settings.shared_tables],
            ["Sheet1", "Second shared set"],
        )
        self.assertEqual(loaded.ui.xySharedTabBar.count(), 2)
        self.assertEqual(loaded.xy_independent_table.table_model.columnCount(), 6)
        self.assertEqual(loaded.table.table_model.cell_text(1, 0), "2.0")
        self.assertEqual(loaded.table.table_model.cell_text(1, 1), "20.0")
        self.assertEqual(
            loaded.xy_independent_table.table_model.cell_text(1, 0),
            "3.0",
        )
        self.assertEqual(
            loaded.xy_independent_table.table_model.cell_text(1, 1),
            "30.0",
        )


if __name__ == "__main__":
    __import__("unittest").main()
