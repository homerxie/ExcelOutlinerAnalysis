from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

import matplotlib
import numpy as np
import pandas as pd
from matplotlib.collections import PathCollection
from matplotlib.ticker import PercentFormatter

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings
from easygraph.xy_data import prepare_xy_data
from easygraph.xy_series import XYSeriesSpec, XYSettings


class PercentagePlottingTests(EasyGraphQtTestCase):
    def make_canvas(self):
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        return canvas

    def test_grouped_charts_use_decimal_values_and_percentage_value_ticks(self):
        frame = pd.DataFrame({"Response": ["25%", "50%", "75%", "100%"]})
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            with self.subTest(chart_type=chart_type):
                canvas = self.make_canvas()
                settings = ChartSettings(
                    chart_type=chart_type,
                    show_stat_table=False,
                    line_overlay_stat="Mean",
                )

                canvas.render(frame, settings)

                ax = canvas.figure.axes[0]
                value_axis = ax.xaxis if chart_type == "Ridge" else ax.yaxis
                category_axis = ax.yaxis if chart_type == "Ridge" else ax.xaxis
                self.assertIsInstance(value_axis.get_major_formatter(), PercentFormatter)
                self.assertTrue(all("%" in tick.get_text() for tick in value_axis.get_ticklabels()))
                self.assertEqual([tick.get_text() for tick in category_axis.get_ticklabels()], ["Response"])
                mean = next(line for line in ax.lines if line.get_label() == "Mean")
                np.testing.assert_allclose(mean.get_xdata() if chart_type == "Ridge" else mean.get_ydata(), [0.625])
                self.assertEqual(frame.iloc[0, 0], "25%")

    def test_group_visibility_and_redraw_reset_percentage_formatting(self):
        canvas = self.make_canvas()
        frame = pd.DataFrame({"Percent": ["25%", "50%"], "Amount %": [2, 3]})
        settings = ChartSettings(show_stat_table=False)
        canvas.render(frame, settings)
        self.assertIsInstance(canvas.figure.axes[0].yaxis.get_major_formatter(), PercentFormatter)

        settings.group_hidden = ["Percent"]
        canvas.render(frame, settings)

        self.assertNotIsInstance(canvas.figure.axes[0].yaxis.get_major_formatter(), PercentFormatter)
        self.assertEqual([tick.get_text() for tick in canvas.figure.axes[0].get_xticklabels()], ["Amount %"])
        canvas.render(pd.DataFrame({"Amount %": [0.25, 0.5]}), ChartSettings(show_stat_table=False))
        self.assertNotIsInstance(canvas.figure.axes[0].yaxis.get_major_formatter(), PercentFormatter)

    def test_xy_formats_x_and_y_independently_and_preserves_decimal_coordinates(self):
        xy = XYSettings(
            default_x_column_id="x",
            show_line=False,
            series=[XYSeriesSpec(id="series", name="Response", y_column_id="y")],
        )
        for percent_x, percent_y in ((True, False), (False, True), (True, True)):
            with self.subTest(percent_x=percent_x, percent_y=percent_y):
                frame = pd.DataFrame({
                    "X": ["25%", "50%"] if percent_x else [0.25, 0.5],
                    "Y": ["50%", "75%"] if percent_y else [0.5, 0.75],
                })
                canvas = self.make_canvas()

                canvas.render(frame, ChartSettings(), xy_settings=xy, column_ids=["x", "y"])

                ax = canvas.figure.axes[0]
                self.assertEqual(isinstance(ax.xaxis.get_major_formatter(), PercentFormatter), percent_x)
                self.assertEqual(isinstance(ax.yaxis.get_major_formatter(), PercentFormatter), percent_y)
                points = next(artist for artist in ax.collections if isinstance(artist, PathCollection))
                np.testing.assert_allclose(points.get_offsets(), [[0.25, 0.5], [0.5, 0.75]])

    def test_xy_hidden_series_and_invalid_pairs_do_not_change_axes(self):
        frame = pd.DataFrame(
            {"X": [1, "25%", 3], "Y": [2, "bad", 4], "Hidden": ["50%", "75%", "100%"]},
            index=["duplicate", "duplicate", "last"],
        )
        xy = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(id="shown", name="Shown", y_column_id="y"),
                XYSeriesSpec(id="hidden", name="Hidden", y_column_id="hidden", visible=False),
            ],
        )
        prepared = prepare_xy_data(frame, ["x", "y", "hidden"], xy)
        self.assertEqual(prepared.series[0].row_indexes, ("duplicate", "last"))
        self.assertEqual(prepared.series[0].skipped_row_indexes, ("duplicate",))
        canvas = self.make_canvas()

        canvas.render(frame, ChartSettings(), xy_settings=xy, column_ids=["x", "y", "hidden"], prepared_xy_data=prepared)

        ax = canvas.figure.axes[0]
        self.assertNotIsInstance(ax.xaxis.get_major_formatter(), PercentFormatter)
        self.assertNotIsInstance(ax.yaxis.get_major_formatter(), PercentFormatter)

    def test_custom_percentage_overlays_format_only_their_value_axis(self):
        frame = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})
        for chart_type in ("Box", "Ridge"):
            for secondary, split in ((False, False), (True, False), (True, True)):
                with self.subTest(chart_type=chart_type, secondary=secondary, split=split):
                    canvas = self.make_canvas()
                    settings = ChartSettings(
                        chart_type=chart_type,
                        show_stat_table=False,
                        show_line_values=True,
                        extra_custom_overlay=True,
                        custom_overlay_secondary_axis=secondary,
                        split_secondary_axis=split,
                        custom_overlay_series=[{"name": "Rate", "values": {"A": "25%", "B": "50%"}}],
                    )

                    canvas.render(frame, settings)

                    primary_ax = canvas.figure.axes[0]
                    primary_axis = primary_ax.xaxis if chart_type == "Ridge" else primary_ax.yaxis
                    self.assertEqual(isinstance(primary_axis.get_major_formatter(), PercentFormatter), not secondary)
                    target_ax = next(ax for ax in canvas.figure.axes if ax.get_gid() == "secondary-axis") if secondary else primary_ax
                    target_axis = target_ax.xaxis if chart_type == "Ridge" else target_ax.yaxis
                    self.assertIsInstance(target_axis.get_major_formatter(), PercentFormatter)
                    line = next(line for line in target_ax.lines if line.get_label() == "Rate")
                    np.testing.assert_allclose(line.get_xdata() if chart_type == "Ridge" else line.get_ydata(), [0.25, 0.5])
                    self.assertIn("25.00%", [text.get_text() for text in target_ax.texts])

    def test_percentage_stat_table_and_stat_overlay_labels_keep_sample_counts(self):
        frame = pd.DataFrame({"Response": ["25%", "50%", "75%", "100%"]})
        for chart_type in ("Box", "Ridge"):
            with self.subTest(chart_type=chart_type):
                canvas = self.make_canvas()
                settings = ChartSettings(
                    chart_type=chart_type,
                    show_stat_table=True,
                    show_stat_sample_size=True,
                    show_line_values=True,
                    line_overlay_stat="Mean",
                )

                canvas.render(frame, settings)

                ax, table_ax = canvas.figure.axes
                self.assertIn("62.50%", [text.get_text() for text in ax.texts])
                table_values = [text.get_text() for text in table_ax.texts]
                self.assertIn("62.50%", table_values)
                self.assertIn("4", table_values)
                self.assertNotIn("400.00%", table_values)

    def test_hidden_overlay_and_hidden_group_values_do_not_change_formatting(self):
        frame = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        settings = ChartSettings(
            show_stat_table=False,
            extra_custom_overlay=True,
            group_hidden=["B"],
            custom_overlay_hidden=[0],
            custom_overlay_series=[
                {"name": "Hidden", "values": {"A": "25%"}},
                {"name": "Shown", "values": {"A": 0.5, "B": "75%"}},
            ],
        )
        canvas = self.make_canvas()

        canvas.render(frame, settings)

        self.assertNotIsInstance(canvas.figure.axes[0].yaxis.get_major_formatter(), PercentFormatter)

    def test_percentage_ticks_survive_zoom_and_figure_export(self):
        frame = pd.DataFrame({"Response": ["25%", "50%", "75%"]})
        settings = ChartSettings(
            show_stat_table=False,
            auto_y_range=False,
            y_min=0,
            y_max=1,
            primary_auto_tick_interval=False,
            primary_tick_interval=0.25,
        )
        canvas = self.make_canvas()
        canvas.render(frame, settings)
        canvas.zoom_by(1.1)

        with TemporaryDirectory() as directory, matplotlib.rc_context({"svg.fonttype": "none"}):
            path = Path(directory) / "percentages.svg"
            canvas.export(str(path), settings)
            exported = path.read_text()

        self.assertIn(">25%</text>", exported)
        self.assertIn(">50%</text>", exported)
        self.assertIsInstance(canvas.figure.axes[0].yaxis.get_major_formatter(), PercentFormatter)
