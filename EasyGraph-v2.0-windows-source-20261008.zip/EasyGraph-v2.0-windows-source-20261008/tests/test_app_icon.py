from __future__ import annotations

import pathlib
import sys
import unittest
from unittest import mock

from PySide6.QtGui import QIcon, QImage
from PySide6.QtWidgets import QApplication


ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from easygraph import app_icon
from easygraph.app_info import APP_DISPLAY_NAME, APP_VERSION


class AppIconTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_theme_icon_png_sets_contain_every_supported_resolution(self):
        for theme in ("dark", "light"):
            icon_dir = app_icon.icon_directory(theme)

            for size, path in app_icon.icon_png_paths(theme).items():
                with self.subTest(theme=theme, size=size):
                    self.assertEqual(path.parent, icon_dir)
                    self.assertTrue(path.is_file(), path)
                    image = QImage(str(path))
                    self.assertFalse(image.isNull(), path)
                    self.assertEqual((image.width(), image.height()), (size, size))

            self.assertEqual(
                set(app_icon.icon_png_paths(theme)),
                {16, 32, 64, 128, 256, 512, 1024},
            )

    def test_application_icon_loads_all_png_resolutions(self):
        for theme in ("dark", "light"):
            icon = app_icon.create_application_icon(theme)

            with self.subTest(theme=theme):
                self.assertFalse(icon.isNull())
                self.assertEqual(
                    {(size.width(), size.height()) for size in icon.availableSizes()},
                    {(size, size) for size in (16, 32, 64, 128, 256, 512, 1024)},
                )

    def test_windows_uses_cropped_platform_icon_assets(self):
        for theme in ("dark", "light"):
            directory = app_icon.icon_directory(theme, platform_name="win32")
            self.assertEqual(directory, ROOT / "icon" / "windows" / theme / "png")

            with mock.patch.object(app_icon.sys, "platform", "win32"):
                paths = app_icon.icon_png_paths(theme)

            for size, path in paths.items():
                with self.subTest(theme=theme, size=size):
                    self.assertTrue(path.is_file(), path)
                    image = QImage(str(path))
                    self.assertEqual((image.width(), image.height()), (size, size))
                    edges = {
                        "top": [image.pixelColor(x, 0).alpha() for x in range(size)],
                        "bottom": [image.pixelColor(x, size - 1).alpha() for x in range(size)],
                        "left": [image.pixelColor(0, y).alpha() for y in range(size)],
                        "right": [image.pixelColor(size - 1, y).alpha() for y in range(size)],
                    }
                    for edge_name, edge_alpha in edges.items():
                        with self.subTest(edge=edge_name):
                            self.assertGreater(max(edge_alpha), 0)

    def test_windows_executable_icon_contains_common_resolutions(self):
        icon_path = ROOT / "icon" / "windows" / "EasyGraph.ico"
        icon = QIcon(str(icon_path))

        self.assertTrue(icon_path.is_file())
        self.assertFalse(icon.isNull())
        available = {(size.width(), size.height()) for size in icon.availableSizes()}
        self.assertTrue({(16, 16), (32, 32), (48, 48), (256, 256)} <= available)

    def test_configure_application_icon_sets_qt_application_metadata(self):
        icon = app_icon.configure_application_icon(self.app, "light")

        self.assertEqual(self.app.applicationName(), "EasyGraph")
        self.assertEqual(self.app.organizationName(), "EasyGraph")
        self.assertEqual(self.app.applicationDisplayName(), APP_DISPLAY_NAME)
        self.assertEqual(self.app.applicationVersion(), APP_VERSION)
        self.assertEqual(self.app.windowIcon().cacheKey(), icon.cacheKey())
        self.assertFalse(self.app.windowIcon().isNull())

    def test_windows_app_user_model_id_is_only_registered_on_windows(self):
        with mock.patch.object(app_icon.sys, "platform", "win32"), mock.patch.object(
            app_icon.ctypes, "windll", create=True
        ) as windll:
            app_icon.configure_platform_identity()

        windll.shell32.SetCurrentProcessExplicitAppUserModelID.assert_called_once_with(
            app_icon.WINDOWS_APP_USER_MODEL_ID
        )

    def test_packaging_uses_platform_specific_icons_and_bundles_runtime_icons(self):
        windows_script = (ROOT / "scripts" / "build_and_smoke_windows.ps1").read_text(encoding="utf-8")
        macos_script = (ROOT / "scripts" / "build_and_smoke_macos.sh").read_text(encoding="utf-8")

        self.assertIn(r"icon\windows\EasyGraph.ico", windows_script)
        self.assertIn(r"icon\windows\dark\png;icon\windows\dark\png", windows_script)
        self.assertIn(r"icon\windows\light\png;icon\windows\light\png", windows_script)
        self.assertIn("EasyGraph_dark.icns", macos_script)
        self.assertIn("icon/dark/png:icon/dark/png", macos_script)
        self.assertIn("icon/light/png:icon/light/png", macos_script)


if __name__ == "__main__":
    unittest.main()
