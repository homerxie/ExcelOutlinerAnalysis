from __future__ import annotations

from unittest.mock import patch

import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

from tests.easygraph_case import EasyGraphTestCase

from easygraph.xy_fit_equation import (
    format_fitted_equation,
    format_fitted_equation_for_curve,
    format_fitted_parameters,
)
from easygraph.xy_fitting import (
    FitParameterEstimate,
    FitParameterSpec,
    XYFitResult,
    default_fit_spec,
    fit_xy_values,
)


def _result(model_id: str, **parameters: float) -> XYFitResult:
    equations = {
        "linear": "y = slope * x + intercept",
        "polynomial3": "y = a * x^3 + b * x^2 + c * x + d",
        "exponential": "y = amplitude * exp(rate * x) + offset",
        "logarithmic": "y = slope * ln(x) + intercept",
        "power": "y = amplitude * x^exponent",
        "gaussian": (
            "y = baseline + amplitude * exp(-0.5 * ((x - center) / sigma)^2)"
        ),
        "custom": "y = custom expression",
    }
    return XYFitResult(
        fit_id="fit",
        series_id="series",
        model_id=model_id,
        success=True,
        status="success",
        message="",
        equation=equations.get(model_id, "y = fitted curve"),
        parameter_estimates=tuple(
            FitParameterEstimate(name, value)
            for name, value in parameters.items()
        ),
    )


class FittedEquationFormattingTests(EasyGraphTestCase):
    def test_selected_parameter_values_use_compact_mathtext(self):
        result = _result("linear", slope=2.34567, intercept=-0.125)

        rendered = format_fitted_parameters(result, ("intercept",), 4)

        self.assertEqual(rendered, r"$\mathrm{intercept} = -0.125$")
        self.assertIsNone(format_fitted_parameters(result, ("missing",), 4))

    def test_linear_uses_compact_signs_and_removes_negative_zero(self):
        spec = default_fit_spec("series", "linear")

        self.assertEqual(
            format_fitted_equation(
                spec, _result("linear", slope=2.0, intercept=-1.0)
            ),
            r"$y \approx 2x - 1$",
        )
        self.assertEqual(
            format_fitted_equation(
                spec, _result("linear", slope=1.0, intercept=-0.0)
            ),
            r"$y \approx x$",
        )

    def test_polynomial_omits_zero_terms_and_formats_scientific_notation(self):
        spec = default_fit_spec("series", "polynomial3")

        equation = format_fitted_equation(
            spec,
            _result(
                "polynomial3",
                a=1.23456,
                b=-2.0,
                c=0.0,
                d=1.23456e-8,
            ),
        )

        self.assertEqual(
            equation,
            r"$y \approx 1.235x^{3} - 2x^{2} + 1.235 \times 10^{-8}$",
        )

    def test_large_x_linear_fit_adds_only_the_display_precision_it_needs(self):
        base = 1e9
        x = base + np.linspace(0.0, 20.0, 41)
        y = 2.0 * (x - base) + 1.0
        spec = default_fit_spec("series", "linear")
        result = fit_xy_values(x, y, spec)

        equation = format_fitted_equation(spec, result)

        self.assertTrue(result.success, result.message)
        self.assertEqual(equation, r"$y \approx 2x - 1999999999$")
        rebuilt = 2.0 * np.asarray(result.curve_x) - 1_999_999_999.0
        maximum_error = float(
            np.max(np.abs(rebuilt - np.asarray(result.curve_y)))
        )
        self.assertLessEqual(
            maximum_error,
            0.005 * float(np.ptp(result.curve_y)),
        )

    def test_cancelling_exponential_fit_adapts_all_three_parameters(self):
        amplitude = 1.23456789e12
        rate = 1e-12
        offset = -1.23456788e12
        x = np.linspace(0.0, 1.0, 257)
        y = amplitude * np.exp(rate * x) + offset
        spec = default_fit_spec("series", "exponential")
        spec.parameters = [
            FitParameterSpec("amplitude", amplitude, fixed=True),
            FitParameterSpec("rate", rate, fixed=True),
            FitParameterSpec("offset", offset, fixed=True),
        ]
        result = fit_xy_values(x, y, spec)

        equation = format_fitted_equation_for_curve(spec, result)

        self.assertTrue(result.success, result.message)
        self.assertIsNotNone(equation)
        self.assertIn(r"1.23456789 \times 10^{12}", equation or "")
        self.assertIn(r"1.23456788 \times 10^{12}", equation or "")
        self.assertGreater(float(np.ptp(result.curve_y)), 1.0)

    def test_cancelling_gaussian_fit_uses_curve_faithful_precision(self):
        baseline = 1.23456789e12
        amplitude = -1.23456788e12
        center = 0.0
        sigma = 8e5
        x = np.linspace(-1.0, 1.0, 257)
        y = baseline + amplitude * np.exp(
            -0.5 * np.square((x - center) / sigma)
        )
        spec = default_fit_spec("series", "gaussian")
        spec.parameters = [
            FitParameterSpec("baseline", baseline, fixed=True),
            FitParameterSpec("amplitude", amplitude, fixed=True),
            FitParameterSpec("center", center, fixed=True),
            FitParameterSpec("sigma", sigma, fixed=True),
        ]
        result = fit_xy_values(x, y, spec)

        equation = format_fitted_equation_for_curve(spec, result)

        self.assertTrue(result.success, result.message)
        self.assertIsNotNone(equation)
        self.assertIn(r"1.23456789 \times 10^{12}", equation or "")
        self.assertIn(r"1.23456788 \times 10^{12}", equation or "")

    def test_cancelling_custom_fit_uses_its_safe_evaluator_for_validation(self):
        amplitude = 1.23456789e12
        rate = 1e-12
        offset = -1.23456788e12
        x = np.linspace(0.0, 1.0, 257)
        y = amplitude * np.exp(rate * x) + offset
        spec = default_fit_spec("series", "custom")
        spec.expression = "a * exp(rate * x) + offset"
        spec.parameters = [
            FitParameterSpec("a", amplitude, fixed=True),
            FitParameterSpec("rate", rate, fixed=True),
            FitParameterSpec("offset", offset, fixed=True),
        ]
        result = fit_xy_values(x, y, spec)

        equation = format_fitted_equation_for_curve(spec, result)

        self.assertTrue(result.success, result.message)
        self.assertIsNotNone(equation)
        self.assertIn(r"1.23456789 \times 10^{12}", equation or "")
        self.assertIn(r"1.23456788 \times 10^{12}", equation or "")

    def test_remaining_builtin_models_use_conventional_math_notation(self):
        cases = [
            (
                "exponential",
                {"amplitude": 2.0, "rate": -0.5, "offset": 3.0},
                r"$y \approx 2\,\exp\!\left(-0.5x\right) + 3$",
            ),
            (
                "logarithmic",
                {"slope": -1.0, "intercept": 2.0},
                r"$y \approx -\ln\!\left(x\right) + 2$",
            ),
            (
                "power",
                {"amplitude": 3.0, "exponent": -0.5},
                r"$y \approx 3x^{-0.5}$",
            ),
            (
                "gaussian",
                {
                    "baseline": 1.0,
                    "amplitude": 2.0,
                    "center": 3.0,
                    "sigma": 4.0,
                },
                (
                    r"$y \approx 1 + 2\,\exp\!\left[-\frac{1}{2}"
                    r"\left(\frac{x - 3}{4}\right)^{2}\right]$"
                ),
            ),
        ]
        for model_id, parameters, expected in cases:
            with self.subTest(model_id=model_id):
                spec = default_fit_spec("series", model_id)
                self.assertEqual(
                    format_fitted_equation(
                        spec, _result(model_id, **parameters)
                    ),
                    expected,
                )

    def test_custom_parameters_are_replaced_as_ast_names_not_substrings(self):
        spec = default_fit_spec("series", "custom")
        spec.expression = "a * x + amplitude + log(x, base)"

        equation = format_fitted_equation(
            spec,
            _result("custom", a=2.0, amplitude=30.0, base=10.0),
        )

        self.assertEqual(
            equation,
            (
                r"$y \approx 2\,x + 30 + "
                r"\log_{10}\!\left(x\right)$"
            ),
        )

    def test_custom_substitution_simplifies_a_negative_addend(self):
        spec = default_fit_spec("series", "custom")
        spec.expression = "a * x + offset"

        equation = format_fitted_equation(
            spec, _result("custom", a=2.0, offset=-3.0)
        )

        self.assertEqual(equation, r"$y \approx 2\,x - 3$")

    def test_negative_custom_parameter_keeps_math_precedence_on_a_real_curve(self):
        spec = default_fit_spec("series", "custom")
        spec.expression = (
            "a**2 + (-a) + a*x + x*a + x/a + exp(a)"
        )
        spec.parameters = [FitParameterSpec("a", -2.0, fixed=True)]
        x = np.linspace(0.5, 1.5, 41)
        y = (
            (-2.0) ** 2
            + 2.0
            - 2.0 * x
            + x * -2.0
            + x / -2.0
            + np.exp(-2.0)
        )
        result = fit_xy_values(x, y, spec)

        equation = format_fitted_equation_for_curve(spec, result)

        self.assertTrue(result.success, result.message)
        self.assertIsNotNone(equation)
        self.assertIn(r"\left(-2\right)^{2}", equation or "")
        self.assertIn(" + 2", equation or "")
        self.assertNotIn("--2", equation or "")
        self.assertIn(r" - 2\,x", equation or "")
        self.assertIn(r"x \cdot \left(-2\right)", equation or "")
        self.assertIn(r" - \frac{x}{2}", equation or "")
        self.assertIn(r"\exp\!\left(-2\right)", equation or "")

        figure = Figure()
        axes = figure.subplots()
        axes.text(0.5, 0.5, equation or "")
        figure.canvas.draw()

    def test_nested_powers_keep_associativity_and_render_with_agg(self):
        x = np.linspace(0.5, 1.5, 41)
        cases = [
            (
                "(x**2)**3",
                {},
                x**6,
                r"$y \approx \left(x^{2}\right)^{3}$",
            ),
            (
                "x**(2**3)",
                {},
                x**8,
                r"$y \approx x^{2^{3}}$",
            ),
            (
                "a**2",
                {"a": -2.0},
                np.full_like(x, 4.0),
                r"$y \approx \left(-2\right)^{2}$",
            ),
        ]
        for expression, parameters, curve_y, expected in cases:
            with self.subTest(expression=expression):
                spec = default_fit_spec("series", "custom")
                spec.expression = expression
                result = XYFitResult(
                    fit_id="fit",
                    series_id="series",
                    model_id="custom",
                    success=True,
                    status="success",
                    message="",
                    equation=f"y = {expression}",
                    parameter_estimates=tuple(
                        FitParameterEstimate(name, value)
                        for name, value in parameters.items()
                    ),
                    curve_x=tuple(x),
                    curve_y=tuple(curve_y),
                )

                equation = format_fitted_equation_for_curve(spec, result)

                self.assertEqual(equation, expected)
                figure = Figure()
                canvas = FigureCanvasAgg(figure)
                axes = figure.subplots()
                axes.text(0.5, 0.5, equation or "")
                canvas.draw()

    def test_custom_sum_and_integral_preserve_local_variables_and_hide_points(self):
        spec = default_fit_spec("series", "custom")
        spec.expression = (
            "sum_over(k, 1, 3, a * k * x) + "
            "integral(t, 0, x, b * t, 64)"
        )

        equation = format_fitted_equation(
            spec,
            _result("custom", a=2.0, b=0.5, k=999.0, t=888.0),
        )

        self.assertIn(r"\sum_{k=1}^{3}", equation)
        self.assertIn(r"2\,k", equation)
        self.assertIn(r"\int_{0}^{x}", equation)
        self.assertIn(r"0.5\,t", equation)
        self.assertIn(r"\mathrm{d}t", equation)
        self.assertNotIn("64", equation)
        self.assertNotIn("999", equation)
        self.assertNotIn("888", equation)

    def test_custom_functions_and_unicode_reducer_aliases_are_typeset(self):
        spec = default_fit_spec("series", "custom")
        spec.expression = (
            "Σ(k, 1, 2, sin(k*x) + sec(x)) + "
            "∫(t, 0, x, sinh(t) + atan2(t, x), 32)"
        )

        equation = format_fitted_equation(spec, _result("custom"))

        self.assertIn(r"\sum_{k=1}^{2}", equation)
        self.assertIn(r"\sin\!\left", equation)
        self.assertIn(r"\mathrm{sec}\!\left", equation)
        self.assertIn(r"\int_{0}^{x}", equation)
        self.assertIn(r"\sinh\!\left", equation)
        self.assertIn(r"\mathrm{atan2}\!\left", equation)
        self.assertNotIn("32", equation)

    def test_unicode_reducer_variables_are_visible_and_mathtext_safe(self):
        spec = default_fit_spec("series", "custom")
        spec.expression = (
            "Σ(α, 1, 2, α*x) + "
            "integral(变量, 0, x, 变量, 32)"
        )

        equation = format_fitted_equation(spec, _result("custom"))

        self.assertIn(r"\sum_{\alpha=1}^{2}", equation)
        self.assertIn(r"\mathrm{u53D8u91CF}", equation)
        self.assertIn(r"\mathrm{d}\mathrm{u53D8u91CF}", equation)
        self.assertNotIn("?", equation)
        self.assertNotIn("32", equation)

    def test_renderer_variant_suppresses_a_curve_no_precision_can_rebuild(self):
        spec = default_fit_spec("series", "custom")
        spec.expression = "x"
        x = np.linspace(0.0, 1.0, 101)
        result = XYFitResult(
            fit_id="fit",
            series_id="series",
            model_id="custom",
            success=True,
            status="success",
            message="",
            equation="y = x",
            curve_x=tuple(x),
            curve_y=tuple(x + 100.0),
        )

        self.assertIsNone(format_fitted_equation_for_curve(spec, result))
        self.assertEqual(format_fitted_equation(spec, result), r"$y \approx x$")

    def test_curve_validation_caps_samples_and_precision_candidates(self):
        sample_sizes: list[int] = []

        class RecordingExpression:
            normalized_expression = "a * x"
            parameter_names = ("a",)

            def evaluate(self, x, _parameters):
                sample_sizes.append(int(np.asarray(x).size))
                return np.zeros_like(x, dtype=float)

        spec = default_fit_spec("series", "custom")
        spec.expression = "a * x"
        x = np.linspace(0.0, 1000.0, 10_000)
        result = XYFitResult(
            fit_id="fit",
            series_id="series",
            model_id="custom",
            success=True,
            status="success",
            message="",
            equation="y = a * x",
            parameter_estimates=(FitParameterEstimate("a", 1.0),),
            curve_x=tuple(x),
            curve_y=tuple(x + 1.0),
        )

        with patch(
            "easygraph.xy_fit_equation.parse_custom_expression",
            return_value=RecordingExpression(),
        ):
            equation = format_fitted_equation_for_curve(spec, result)

        self.assertIsNone(equation)
        self.assertEqual(len(sample_sizes), 14)
        self.assertLessEqual(max(sample_sizes), 64)
        self.assertGreaterEqual(min(sample_sizes), 2)

    def test_formatting_errors_return_a_visible_safe_mathtext_fallback(self):
        spec = default_fit_spec("series", "custom")
        spec.expression = "not valid { expression"

        equation = format_fitted_equation(spec, _result("custom"))

        self.assertTrue(equation.startswith(r"$y \approx "))
        self.assertTrue(equation.endswith("$"))
        self.assertIn(r"\mathrm{not}", equation)
        self.assertIn(r"\mathrm{expression}", equation)

        spec.expression = "x ^"
        self.assertIn("**", format_fitted_equation(spec, _result("custom")))

    def test_failure_result_and_invalid_precision_never_raise(self):
        spec = default_fit_spec("series", "linear")
        failed = XYFitResult(
            fit_id="fit",
            series_id="series",
            model_id="linear",
            success=False,
            status="error",
            message="failed",
            equation="y = slope * x + intercept",
        )

        self.assertIn(r"\mathrm{slope}", format_fitted_equation(spec, failed))
        self.assertIn(
            r"\mathrm{slope}",
            format_fitted_equation(
                spec, _result("linear", slope=2.0, intercept=1.0), 0
            ),
        )
