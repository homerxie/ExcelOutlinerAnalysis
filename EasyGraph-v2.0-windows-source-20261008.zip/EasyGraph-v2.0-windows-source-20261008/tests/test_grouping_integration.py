from dataclasses import asdict
import pathlib
import tempfile
from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data import group_keys, prepare_plot_frames
from easygraph.grouping import parent_for_column
from easygraph.project_io import read_workbook_project, write_project
from easygraph.spreadsheet_io import read_spreadsheet_book, write_spreadsheet
from easygraph.ui.grouping_controls import GroupDisplayDialog


class GroupingIntegrationTests(EasyGraphQtTestCase):
    def test_duplicate_single_level_columns_keep_independent_statistics_and_overlay_values(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([[1, 10], [3, 30]], columns=['Control', 'Control']))
        dataframe = window._user_group_dataframe()
        keys = group_keys(dataframe)
        self.assertEqual(len(keys), 2)
        self.assertNotEqual(keys[0], keys[1])
        frames = prepare_plot_frames(dataframe, window.settings)
        self.assertEqual(frames.full.groupby('group')['value'].mean().to_dict(), {keys[0]: 2, keys[1]: 20})
        series = [{'name': 'Limits', 'values': {keys[0]: '7', keys[1]: '70'}}]
        window.sync_custom_overlay_rows(series)
        self.assertEqual(window.table.table_model.cell_text(1, 0), '7')
        self.assertEqual(window.table.table_model.cell_text(1, 1), '70')
        self.assertEqual(window.custom_overlay_series_from_table()[0]['values'], {keys[0]: '7', keys[1]: '70'})

    def test_insert_at_parent_boundary_stays_with_selected_parent_and_undo_restores_ids(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([[1, 2, 3]], columns=['A', 'B', 'C']))
        sheet = window.workbook.active_sheet
        original_ids = list(sheet.column_ids)
        self.select_table_range(window.table, 0, 0, 0, 1)
        start_row = window.sample_start_row()
        self.assertTrue(window.grouping_controls.create_selected_parent('First'))
        parent_id = sheet.grouping.parents[0]['id']
        self.select_table_range(window.table, 0, 2, 0, 2)
        self.assertTrue(window.grouping_controls.create_selected_parent('Second'))
        self.assertEqual(window.sample_start_row(), start_row)
        self.assertGreater(window.table.horizontalHeader().band_height(), 0)
        self.select_table_range(window.table, 0, 1, 0, 1)
        self.assertTrue(window.grouping_controls.insert_selected_subgroup(True))
        inserted_id = sheet.column_ids[2]
        self.assertEqual(parent_for_column(sheet.grouping, inserted_id)['id'], parent_id)
        self.assertEqual(sheet.column_ids[3], original_ids[2])
        self.assertEqual(window.table.table_model.cell_text(start_row, 2), '')
        self.assertEqual(window.table.table_model.cell_text(start_row, 3), '3')
        window.undo_table_change()
        self.assertEqual(sheet.column_ids, original_ids)
        self.assertEqual(sheet.grouping.parents[0]['column_ids'], original_ids[:2])
        window.redo_table_change()
        self.assertEqual(sheet.column_ids[2], inserted_id)
        self.assertEqual(parent_for_column(sheet.grouping, inserted_id)['id'], parent_id)
        self.select_table_range(window.table, 0, 0, 0, 0)
        self.assertTrue(window.grouping_controls.insert_selected_subgroup(False))
        self.assertEqual(parent_for_column(sheet.grouping, sheet.column_ids[0])['id'], parent_id)

    def test_shared_headers_rename_together_and_undo_as_one_edit(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([['', '']], columns=['Group 1', 'Group 2']))
        self.assertTrue(window.grouping_controls.add_shared_groups(['WT', 'KO'], ['Control', 'Drug']))
        self.assertEqual(window.table_group_names(), ['Control', 'Drug', 'Control', 'Drug'])
        sheet = window.workbook.active_sheet
        self.assertNotEqual(sheet.column_ids[0], sheet.column_ids[2])
        self.assertEqual(sheet.grouping.subgroup_ids[sheet.column_ids[0]], sheet.grouping.subgroup_ids[sheet.column_ids[2]])
        window.table.table_model.set_cell_text(0, 0, 'Vehicle')
        self.assertEqual(window.table_group_names(), ['Vehicle', 'Drug', 'Vehicle', 'Drug'])
        window.undo_table_change()
        self.assertEqual(window.table_group_names(), ['Control', 'Drug', 'Control', 'Drug'])
        window.redo_table_change()
        self.assertEqual(window.table_group_names(), ['Vehicle', 'Drug', 'Vehicle', 'Drug'])
        with mock.patch('easygraph.ui.main_window.QInputDialog.getMultiLineText', return_value=('Dose', True)):
            window.rename_column(window.table, 1)
        self.assertEqual(window.table_group_names(), ['Vehicle', 'Dose', 'Vehicle', 'Dose'])

    def test_group_identity_survives_project_reload_and_excel_roundtrip(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([[1, 10], [3, 30]], columns=['Control', 'Control']))
        for column, name in enumerate(['WT', 'KO']):
            self.select_table_range(window.table, 0, column, 0, column)
            window.grouping_controls.create_selected_parent(name)
        window._store_active_sheet()
        sheet = window.workbook.active_sheet
        with tempfile.TemporaryDirectory() as directory:
            project = pathlib.Path(directory) / 'groups.eg'
            write_project(project, window.workbook)
            loaded = read_workbook_project(project).active_sheet
            self.assertEqual(asdict(loaded.grouping), asdict(sheet.grouping))
            self.assertEqual(loaded.column_ids, sheet.column_ids)
            excel = pathlib.Path(directory) / 'groups.xlsx'
            write_spreadsheet(excel, window._user_group_sheet_dataframe(sheet), [])
            imported = read_spreadsheet_book(excel)
            restored = self.make_window()
            restored._apply_imported_workbook(imported)
            self.assertEqual(restored.table_group_names(), ['Control', 'Control'])
            self.assertEqual([parent['name'] for parent in restored.workbook.active_sheet.grouping.parents], ['WT', 'KO'])
            self.assertEqual(restored._user_group_dataframe().iloc[:2].astype(float).values.tolist(), [[1, 10], [3, 30]])

    def test_paste_shared_header_links_new_batch_without_changing_existing_free_group(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([[1, 2]], columns=['Control', 'Drug']))
        self.select_table_range(window.table, 0, 0, 0, 1)
        window.grouping_controls.create_selected_parent('Existing')
        window.grouping_controls.add_shared_groups(['WT', 'KO'], ['Control', 'Drug'])
        window.table.setCurrentIndex(window.table.table_model.index(0, 2))
        window._table_controller.paste_text('Vehicle', after_paste=window._ensure_group_table_capacity)
        self.assertEqual(window.table_group_names(), ['Control', 'Drug', 'Vehicle', 'Drug', 'Vehicle', 'Drug'])
        self.assertEqual(window.table.table_model.cell_text(window.sample_start_row(), 0), '1')
        self.assertEqual(window.table.table_model.cell_text(window.sample_start_row(), 2), '')
        window.undo_table_change()
        self.assertEqual(window.table_group_names(), ['Control', 'Drug', 'Control', 'Drug', 'Control', 'Drug'])
        window.redo_table_change()
        self.assertEqual(window.table_group_names(), ['Control', 'Drug', 'Vehicle', 'Drug', 'Vehicle', 'Drug'])

    def test_filter_and_color_dialogs_distinguish_duplicate_names(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([[1, 10]], columns=['A', 'A']))
        labels = window._group_item_labels()
        keys = window._group_user_keys()
        self.assertEqual(len(labels), 2)
        self.assertNotEqual(labels[keys[0]], labels[keys[1]])
        window.settings.group_hidden = [keys[0]]
        window.sync_manual_group_order()
        frames = prepare_plot_frames(window._user_group_dataframe(), window.settings)
        self.assertEqual(frames.visible['group'].unique().tolist(), [keys[1]])
        window.table.table_model.set_cell_text(0, 0, 'Renamed')
        self.assertEqual(window.settings.group_hidden, [keys[0]])

    def test_legend_only_group_display_undo_restores_legend_control(self):
        window = self.make_window()
        window.grouping_controls.add_shared_groups(['WT', 'KO'], ['Control', 'Drug'])
        window.show_legend.setChecked(False)
        window.settings.show_legend = False
        dialog = GroupDisplayDialog(window.settings, window.workbook.active_sheet.grouping, window)
        dialog.labels.setCurrentIndex(dialog.labels.findData('Legend only'))
        self.assertFalse(window.ui.groupLayoutButton.isHidden())
        with mock.patch('easygraph.ui.grouping_controls.GroupDisplayDialog', return_value=dialog), mock.patch.object(dialog, 'exec', return_value=QDialog.Accepted):
            window.ui.groupLayoutButton.click()
        self.assertEqual(window.settings.group_label_mode, 'Legend only')
        self.assertTrue(window.settings.show_legend)
        self.assertTrue(window.show_legend.isChecked())
        window.undo_table_change()
        self.assertEqual(window.settings.group_label_mode, 'Both levels')
        self.assertFalse(window.settings.show_legend)
        self.assertFalse(window.show_legend.isChecked())
        window.redo_table_change()
        self.assertEqual(window.settings.group_label_mode, 'Legend only')
        self.assertTrue(window.settings.show_legend)
        self.assertTrue(window.show_legend.isChecked())

    def test_parent_header_can_be_removed_without_changing_data_and_undone(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([[1, 2]], columns=['A', 'B']))
        original = window.table_dataframe()
        self.select_table_range(window.table, 0, 0, 0, 1)
        window.grouping_controls.create_selected_parent('Batch')
        key = window.workbook.active_sheet.grouping.parents[0]['id']
        window.grouping_controls.remove_parent(key)
        self.assertFalse(window.workbook.active_sheet.grouping.parents)
        pd.testing.assert_frame_equal(window.table_dataframe(), original)
        self.assertGreater(window.table.horizontalHeader().band_height(), 0)
        window.undo_table_change()
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]['id'], key)


if __name__ == '__main__':
    import unittest
    unittest.main()
