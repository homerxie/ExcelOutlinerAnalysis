from __future__ import annotations

from contextlib import ExitStack
from pathlib import Path
import runpy
import tempfile
from unittest import mock

import pandas as pd

from easygraph import app_preferences, project_io
from easygraph.settings import ChartSettings
from easygraph.ui.main_window import MainWindow
from easygraph.ui.startup_dialog import StartupChoice
from easygraph.workbook import SHEET_MODE_GROUPS, SHEET_MODE_XY
from tests.easygraph_case import ROOT, EasyGraphQtTestCase, patch_qsettings


class StartupEntrypointTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        preferences, _ = patch_qsettings()
        preferences.start()
        self.addCleanup(preferences.stop)

    def run_startup(self, window, choices):
        application = mock.Mock()
        with ExitStack() as stack:
            for target in (
                'easygraph.app_icon.configure_application_icon',
                'easygraph.app_icon.configure_platform_identity',
                'easygraph.app_preferences.install_app_translator',
                'easygraph.app_theme.apply_app_theme',
                'easygraph.file_association.register_windows_project_file_association',
                'PySide6.QtCore.QTimer.singleShot',
            ):
                stack.enter_context(mock.patch(target))
            stack.enter_context(mock.patch(
                'easygraph.file_association.EasyGraphApplication',
                return_value=application,
            ))
            stack.enter_context(mock.patch(
                'easygraph.ui.main_window.MainWindow', return_value=window,
            ))
            choose = stack.enter_context(mock.patch(
                'easygraph.ui.startup_dialog.choose_startup', side_effect=choices,
            ))
            stack.enter_context(mock.patch('sys.argv', ['easygraph']))
            stack.enter_context(mock.patch.dict(
                'os.environ', {'EASYGRAPH_PACKAGING_SMOKE_DIR': ''},
            ))
            runpy.run_path(str(ROOT / 'src' / 'app.py'), run_name='__main__')
        return application, choose

    def test_recent_project_loads_instead_of_initializing_a_demo(self):
        window = MainWindow(initial_render=False, defer_preview=True)
        self.addCleanup(self.close_window_without_unsaved_prompt, window)
        data = pd.DataFrame({'Saved A': [2.5, 3.5], 'Saved B': [5.5, 6.5]})
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'saved.eg'
            project_io.write_project(path, data, ChartSettings(title='Saved project'))
            choice = StartupChoice(SHEET_MODE_GROUPS, False, project_path=path)
            with mock.patch.object(window, 'initialize_startup_project') as initialize:
                application, choose = self.run_startup(window, [choice])
            self.assertEqual(window.current_project, path)
            self.assertEqual(window.settings.title, 'Saved project')
            self.assertTrue(window.isVisible())
            self.assertIsNone(window.canvas)
            self.assertTrue(window._plot_placeholder.isVisible())
            restored = window.table_dataframe().apply(pd.to_numeric, errors='coerce')
            restored = restored.dropna(how='all').dropna(axis=1, how='all')
            pd.testing.assert_frame_equal(restored, data, check_dtype=False)
            self.assertEqual(app_preferences.stored_recent_project_paths()[0], path)
            self.assertFalse(window.has_unsaved_changes())
        initialize.assert_not_called()
        self.assertEqual(choose.call_count, 1)
        application.exec.assert_called_once()

    def test_failed_recent_project_returns_to_chooser_before_creating_blank(self):
        window = self.make_window()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'broken.eg'
            path.write_text('invalid project', encoding='utf-8')
            choices = [
                StartupChoice(SHEET_MODE_GROUPS, False, project_path=path),
                StartupChoice(SHEET_MODE_XY, False),
            ]
            with mock.patch('easygraph.ui.main_window.QMessageBox.critical') as error:
                application, choose = self.run_startup(window, choices)
            error.assert_called_once()
        self.assertEqual(choose.call_count, 2)
        self.assertIsNone(window.current_project)
        self.assertEqual(window.workbook.active_sheet.mode, SHEET_MODE_XY)
        self.assertTrue((window.workbook.active_sheet.dataframe == '').all().all())
        self.assertFalse(window.has_unsaved_changes())
        application.exec.assert_called_once()

    def test_grouped_demo_choice_is_applied_and_cancel_does_not_start_event_loop(self):
        window = self.make_window()
        application, _ = self.run_startup(window, [
            StartupChoice(SHEET_MODE_GROUPS, True, grouped_demo=True),
        ])
        self.assertTrue(window.workbook.active_sheet.grouping.parents)
        self.assertIsNone(window.current_project)
        application.exec.assert_called_once()

        cancelled = self.make_window()
        application, _ = self.run_startup(cancelled, [None])
        application.exec.assert_not_called()
        self.assertFalse(cancelled.isVisible())
