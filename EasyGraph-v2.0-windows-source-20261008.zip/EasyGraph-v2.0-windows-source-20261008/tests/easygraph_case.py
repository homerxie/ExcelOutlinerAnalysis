from __future__ import annotations

import pathlib
import sys
from unittest import mock

from PySide6.QtCore import QEvent, QItemSelection, QItemSelectionModel
from PySide6.QtWidgets import QApplication

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tests.test_support import WarningConfiguredTestCase

from easygraph import app_preferences
from easygraph.app_theme import configure_qt_application_font
from easygraph.data import sample_data
from easygraph.settings import ChartSettings
from easygraph.ui.main_window import MainWindow


def patch_qsettings(values=None):
    values = {} if values is None else values

    class FakeSettings:
        def __init__(self, *args):
            pass

        def value(self, key, default=None):
            return values.get(key, default)

        def setValue(self, key, value):
            values[key] = value

    return mock.patch.object(app_preferences, "QSettings", FakeSettings), values


class EasyGraphTestCase(WarningConfiguredTestCase):
    def setUp(self):
        super().setUp()
        self.settings = ChartSettings()
        self.df = sample_data()


class EasyGraphQtTestCase(EasyGraphTestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.qapp = QApplication.instance() or QApplication([])
        configure_qt_application_font(cls.qapp)

    def setUp(self):
        super().setUp()
        self._main_windows_created_by_test = []
        original_init = MainWindow.__init__

        def record_main_window(window, *args, **kwargs):
            original_init(window, *args, **kwargs)
            self._main_windows_created_by_test.append(window)

        self._main_window_init_patcher = mock.patch.object(
            MainWindow,
            "__init__",
            record_main_window,
        )
        self._main_window_init_patcher.start()
        self.addCleanup(self._main_window_init_patcher.stop)
        self.addCleanup(self._delete_widgets_created_by_test)

    def _delete_widgets_created_by_test(self) -> None:
        # Flush callbacks (for example the deferred initial zoom) while their
        # widgets are still alive, then deliver only deferred deletions.
        self.qapp.processEvents()
        for widget in reversed(self._main_windows_created_by_test):
            try:
                widget.hide()
                widget.deleteLater()
            except RuntimeError:
                pass
        QApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)

    def make_window(self, *, initial_render: bool = False):
        window = MainWindow(initial_render=initial_render)
        self.addCleanup(self.close_window_without_unsaved_prompt, window)
        return window

    @staticmethod
    def close_window_without_unsaved_prompt(window) -> None:
        with mock.patch.object(window, "_confirm_unsaved_changes", return_value=True):
            window.close()

    def select_table_range(self, table, top: int, left: int, bottom: int, right: int) -> None:
        model = table.model()
        selection = QItemSelection(model.index(top, left), model.index(bottom, right))
        table.selectionModel().select(selection, QItemSelectionModel.ClearAndSelect)
