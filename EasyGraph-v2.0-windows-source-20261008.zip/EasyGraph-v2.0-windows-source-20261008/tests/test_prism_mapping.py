from __future__ import annotations

import pathlib
import tempfile
from unittest import mock

import pandas as pd

from tests.easygraph_case import ROOT, EasyGraphTestCase
from tests.prism_fixtures import column_table, grouped_table, pzfx_document, write_pzfx, xy_table

from easygraph.prism_io import PrismImportError, import_pzfx_table, import_pzfx_tables
from easygraph.prism_io import pzfx as pzfx_module


class PrismMappingTests(EasyGraphTestCase):
    def test_batch_import_parses_once_and_skips_unsupported_tables_by_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = write_pzfx(
                pathlib.Path(tmp) / "batch.pzfx",
                pzfx_document(
                    [
                        column_table(table_id="Column"),
                        grouped_table(table_id="Grouped"),
                        xy_table(table_id="XY"),
                    ],
                    sequence_ids=["Grouped", "XY", "Column"],
                ),
            )
            with mock.patch.object(
                pzfx_module,
                "_parse_document",
                wraps=pzfx_module._parse_document,
            ) as parse_document:
                results = import_pzfx_tables(path)

        parse_document.assert_called_once_with(path)
        self.assertEqual([result.table.id for result in results], ["Grouped", "Column"])

    def test_batch_import_uses_the_explicit_table_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = write_pzfx(
                pathlib.Path(tmp) / "selected.pzfx",
                pzfx_document(
                    [
                        column_table(table_id="Column"),
                        grouped_table(table_id="Grouped"),
                    ]
                ),
            )
            results = import_pzfx_tables(path, ["Grouped", "Column"])

        self.assertEqual([result.table.id for result in results], ["Grouped", "Column"])

    def test_column_values_missing_excluded_and_unequal_lengths(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = write_pzfx(pathlib.Path(tmp) / "column.pzfx", pzfx_document([column_table(include_row_titles=True)]))
            result = import_pzfx_table(path, "Table0")

        expected = pd.DataFrame({"A": [1.0, None, None], "B": [-3.5, 40.0, None]}, dtype=float)
        pd.testing.assert_frame_equal(result.dataframe, expected)
        self.assertEqual(result.excluded_count, 1)
        self.assertEqual(result.missing_count, 2)
        warning_codes = [warning.code for warning in result.warnings]
        self.assertIn("column_row_titles_not_preserved", warning_codes)
        self.assertIn("unequal_column_lengths", warning_codes)

    def test_grouped_values_are_mapped_by_y_column_then_row_title(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = write_pzfx(pathlib.Path(tmp) / "grouped.pzfx", pzfx_document([grouped_table()]))
            result = import_pzfx_table(path, "Table0")

        expected = pd.DataFrame(
            [
                [1.0, 2.0, 7.0, 8.0],
                [5.0, 6.0, None, 10.0],
            ],
            columns=[
                "Wild type",
                "Knock-out",
                "Wild type",
                "Knock-out",
            ],
            dtype=float,
        )
        pd.testing.assert_frame_equal(result.dataframe, expected)
        self.assertEqual(result.excluded_count, 1)
        self.assertEqual(result.missing_count, 0)

    def test_grouped_factor_metadata_preserves_parent_and_shared_subgroup_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            path = write_pzfx(pathlib.Path(directory) / "grouped.pzfx", pzfx_document([grouped_table()]))
            result = import_pzfx_table(path, "Table0")
        ids = result.dataframe.attrs["group_column_ids"]
        grouping = result.dataframe.attrs["grouping"]
        self.assertEqual([parent["name"] for parent in grouping["parents"]], ["Control", "Treated"])
        self.assertEqual([parent["column_ids"] for parent in grouping["parents"]], [ids[:2], ids[2:]])
        self.assertTrue(grouping["shared_subgroups"])
        self.assertEqual(grouping["subgroup_ids"][ids[0]], grouping["subgroup_ids"][ids[2]])
        self.assertNotEqual(ids[0], ids[2])

    def test_short_grouped_subcolumn_is_padded_without_shifting_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = write_pzfx(
                pathlib.Path(tmp) / "short.pzfx",
                pzfx_document([grouped_table(short_subcolumn=True)]),
            )
            result = import_pzfx_table(path, "Table0")
        self.assertTrue(pd.isna(result.dataframe.iloc[1, 1]))
        self.assertEqual(result.dataframe.iloc[0, 1], 2.0)
        self.assertEqual(result.missing_count, 1)
        self.assertIn("short_grouped_subcolumn", [warning.code for warning in result.warnings])

    def test_missing_table_and_non_numeric_value_fail_with_location(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = write_pzfx(pathlib.Path(tmp) / "column.pzfx", pzfx_document([column_table()]))
            with self.assertRaises(PrismImportError) as missing_context:
                import_pzfx_table(path, "Missing")
            self.assertEqual(missing_context.exception.code, "table_not_found")

            bad_xml = pzfx_document([column_table()]).replace("<d>1</d>", "<d>abc</d>", 1)
            bad_path = write_pzfx(pathlib.Path(tmp) / "bad.pzfx", bad_xml)
            with self.assertRaisesRegex(PrismImportError, "group 'A'.*not numeric") as bad_context:
                import_pzfx_table(bad_path, "Table0")
            self.assertEqual(bad_context.exception.code, "non_numeric_value")

    def test_real_prism_9_10_11_samples_match_when_available(self):
        sample_dir = ROOT / "demo" / "prism_samples"
        column_paths = [
            sample_dir / "prism9columns.pzfx",
            sample_dir / "prism10columns.pzfx",
            sample_dir / "prism11Columns.pzfx",
        ]
        grouped_paths = [
            sample_dir / "prism9Group.pzfx",
            sample_dir / "prism10Group.pzfx",
            sample_dir / "prism11Group.pzfx",
        ]
        if not all(path.exists() for path in (*column_paths, *grouped_paths)):
            self.skipTest("Local ignored Prism regression samples are unavailable")

        column_frames = [import_pzfx_table(path, "Table0").dataframe for path in column_paths]
        grouped_frames = [import_pzfx_table(path, "Table0").dataframe for path in grouped_paths]
        for frame in column_frames[1:]:
            pd.testing.assert_frame_equal(frame, column_frames[0])
        for frame in grouped_frames[1:]:
            pd.testing.assert_frame_equal(frame, grouped_frames[0])

        self.assertEqual(list(column_frames[0].columns), ["Untreated", "Placebo", "Treated"])
        self.assertEqual(
            list(grouped_frames[0].columns),
            [
                "Wild type",
                "Knock-out A",
                "Knock-out B",
                "Wild type",
                "Knock-out A",
                "Knock-out B",
            ],
        )


if __name__ == "__main__":
    raise SystemExit(__import__("unittest").main())
