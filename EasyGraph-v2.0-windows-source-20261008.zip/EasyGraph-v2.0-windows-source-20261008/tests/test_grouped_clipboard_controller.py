from __future__ import annotations

from copy import deepcopy
from unittest import mock

import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.clipboard_table import (
    CellMerge,
    ClipboardTable,
    clipboard_table_from_html,
    clipboard_table_to_html,
)
from easygraph.data_table import DataTable
from easygraph.grouping import create_parent
from easygraph.table_history import StructureSnapshotEdit
from easygraph.ui.table_controller import TableController, TableControllerHooks
from easygraph.workbook import SheetDocument


class GroupedClipboardControllerTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.sheet = SheetDocument(
            "Sheet 1",
            pd.DataFrame({"A": ["25%"], "B": ["3"], "C": ["4"], "D": ["5"]}),
        )
        self.table = DataTable()
        self.addCleanup(self.table.close)
        self.controller = TableController(
            self.table,
            settings=lambda: self.sheet.settings,
            sheet=lambda: self.sheet,
            hooks=TableControllerHooks(
                render=mock.Mock(),
                update_history_actions=mock.Mock(),
                update_dependent_controls=mock.Mock(),
                sync_overlay_controls=mock.Mock(),
            ),
        )
        self.controller.set_dataframe(self.sheet.dataframe)
        create_parent(self.sheet.grouping, self.sheet.column_ids[:2], "First")
        create_parent(self.sheet.grouping, self.sheet.column_ids[2:], "Second")
        self.controller.refresh_structure()
        self.controller.reset_history()

    def test_copy_preserves_both_header_levels_and_clips_merges_to_selection(self):
        self.select_table_range(self.table, 0, 1, 1, 3)
        data = self.controller.copy_selection_data()
        self.assertEqual(data.rows, [["First", "Second", ""], ["B", "C", "D"], ["3", "4", "5"]])
        self.assertEqual(data.header_rows, 2)
        self.assertEqual(data.merges, [CellMerge(0, 1, colspan=2)])
        self.assertEqual(clipboard_table_from_html(clipboard_table_to_html(data)), data)

    def test_numeric_selection_does_not_acquire_headers(self):
        self.select_table_range(self.table, 1, 0, 1, 1)
        data = self.controller.copy_selection_data()
        self.assertEqual(data, ClipboardTable([["25%", "3"]], header_rows=0))

    def test_parent_only_copy_and_spare_column_limit(self):
        self.table.horizontalHeader().select_parent_columns([0, 1, 2, 3])
        data = self.controller.copy_selection_data(column_limit=3)
        self.assertEqual(data, ClipboardTable([["First", "", "Second"]], [CellMerge(0, 0, colspan=2)], 1))
        self.table.horizontalHeader().clear_parent_selection()
        self.select_table_range(self.table, 0, 3, 1, 3)
        self.assertIsNone(self.controller.copy_selection_data(column_limit=3))

    def test_foreign_excel_headers_expand_and_undo_redo_atomically(self):
        self.table.setCurrentIndex(self.table.table_model.index(0, 2))
        before = self.controller.snapshot()
        data = ClipboardTable(
            [["New", "", "Solo"], ["A", "B", "C"], ["12.5%", "2", "3"]],
            [CellMerge(0, 0, colspan=2)],
        )
        self.assertTrue(self.controller.paste_clipboard(data))
        self.assertEqual(self.table.table_model.cells_copy()[0], ["A", "B", "A", "B", "C"])
        self.assertEqual(self.table.table_model.cell_text(1, 2), "12.5%")
        self.assertEqual([parent["name"] for parent in self.sheet.grouping.parents], ["First", "New", "Solo"])
        self.assertEqual(len(self.sheet.column_ids), 5)
        self.assertEqual(len(self.controller.history.undo_stack), 1)
        self.assertIsInstance(self.controller.history.undo_stack[0], StructureSnapshotEdit)
        after = self.controller.snapshot()
        self.controller.undo()
        self.assertEqual(self.controller.snapshot()["cells"], before["cells"])
        self.assertEqual(self.controller.snapshot()["grouping"], before["grouping"])
        self.assertEqual(self.sheet.column_ids, before["column_ids"])
        self.controller.redo()
        self.assertEqual(self.controller.snapshot()["grouping"], after["grouping"])
        self.assertEqual(self.controller.snapshot()["cells"], after["cells"])

    def test_parent_target_plain_text_does_not_touch_stale_current_cell(self):
        self.table.setCurrentIndex(self.table.table_model.index(1, 3))
        self.table.horizontalHeader().select_parent_columns([0, 3])
        before = self.table.table_model.cells_copy()
        parent_before = deepcopy(self.sheet.grouping.parents[0])
        self.assertTrue(self.controller.paste_clipboard(ClipboardTable([["Renamed"]])))
        self.assertEqual(self.table.table_model.cells_copy(), before)
        self.assertEqual(self.sheet.grouping.parents[0]["name"], "Renamed")
        self.assertEqual(self.sheet.grouping.parents[-1]["name"], "Second")
        self.assertEqual(len(self.sheet.grouping.parents), 2)
        self.assertEqual(self.sheet.grouping.parents[0]["column_ids"], parent_before["column_ids"])
        self.assertEqual(self.sheet.grouping.parents[0]["id"], parent_before["id"])
        self.controller.undo()
        self.assertEqual(self.sheet.grouping.parents[0], parent_before)

    def test_overwriting_middle_of_existing_merge_leaves_separate_merged_pieces(self):
        old = create_parent(self.sheet.grouping, self.sheet.column_ids, "Original")
        before = deepcopy(self.sheet.grouping)
        self.table.setCurrentIndex(self.table.table_model.index(0, 1))
        self.controller.paste_clipboard(ClipboardTable([["New", ""]], [CellMerge(0, 0, colspan=2)], 1))
        parents = self.sheet.grouping.parents
        self.assertEqual([parent["name"] for parent in parents], ["Original", "New", "Original"])
        self.assertEqual([parent["column_ids"] for parent in parents], [self.sheet.column_ids[:1], self.sheet.column_ids[1:3], self.sheet.column_ids[3:]])
        self.assertEqual(parents[0]["id"], old["id"])
        self.assertNotEqual(parents[2]["id"], old["id"])
        self.assertEqual(len(self.controller.history.undo_stack), 1)
        self.controller.undo()
        self.assertEqual(self.sheet.grouping, before)

    def test_blank_merged_parent_remains_merged(self):
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))
        self.controller.paste_clipboard(ClipboardTable([["", ""]], [CellMerge(0, 0, colspan=2)], 1))
        parent = self.sheet.grouping.parents[0]
        self.assertEqual(parent["name"], "")
        self.assertEqual(parent["column_ids"], self.sheet.column_ids[:2])
        self.table.horizontalHeader().select_parent_columns([0])
        self.assertEqual(self.controller.copy_selection_data().merges, [CellMerge(0, 0, colspan=2)])

    def test_replacing_subset_preserves_unaffected_shared_names(self):
        self.sheet.grouping.shared_subgroups = True
        self.sheet.grouping.subgroup_ids = dict(zip(self.sheet.column_ids, ["a", "b", "a", "b"]))
        before = deepcopy(self.sheet.grouping)
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))
        self.controller.paste_clipboard(ClipboardTable([["Other", ""], ["X", "Y"]], [CellMerge(0, 0, colspan=2)], 2))
        self.assertEqual(self.table.table_model.cells_copy()[0], ["X", "Y", "C", "D"])
        for key in self.sheet.column_ids[2:]:
            self.assertEqual(self.sheet.grouping.subgroup_ids[key], before.subgroup_ids[key])
        self.assertEqual(self.sheet.grouping.parents[-1], before.parents[-1])

    def test_unsupported_body_or_vertical_merge_is_rejected_before_changes(self):
        before = self.controller.snapshot()
        for merge in (CellMerge(0, 0, rowspan=2), CellMerge(1, 0, colspan=2)):
            with self.subTest(merge=merge), self.assertRaisesRegex(ValueError, "horizontal parent-header"):
                self.controller.paste_clipboard(ClipboardTable([["A", "B"], ["1", "2"]], [merge]))
            self.assertEqual(self.controller.snapshot(), before)
        self.assertFalse(self.controller.history.can_undo)
