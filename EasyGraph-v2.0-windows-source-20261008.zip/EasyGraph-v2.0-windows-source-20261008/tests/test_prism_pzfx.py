from __future__ import annotations

import os
import pathlib
import subprocess
import sys
import tempfile
import json

from tests.easygraph_case import ROOT, EasyGraphTestCase
from tests.prism_fixtures import column_table, grouped_table, pzfx_document, write_pzfx, xy_table

from easygraph import prism_io
from easygraph.prism_io import PrismImportError, PrismTableKind


class PrismPzfxTests(EasyGraphTestCase):
    def write_fixture(self, directory: str, content: str, name: str = "sample.pzfx") -> pathlib.Path:
        return write_pzfx(pathlib.Path(directory) / name, content)

    def test_public_api_is_explicit(self):
        self.assertEqual(
            prism_io.__all__,
            [
                "PrismImportError",
                "PrismImportResult",
                "PrismProjectSummary",
                "PrismTableKind",
                "PrismTableSummary",
                "PrismWarning",
                "import_pzfx_table",
                "import_pzfx_tables",
                "inspect_pzfx",
            ],
        )

    def test_versions_8_through_11_use_the_same_structure_driven_classifier(self):
        versions = ("8.4.3.686", "9.5.1.528", "10.3.1.464", "11.0.2.100")
        with tempfile.TemporaryDirectory() as tmp:
            for version in versions:
                with self.subTest(version=version):
                    path = self.write_fixture(
                        tmp,
                        pzfx_document(
                            [column_table()],
                            created_by_version=version,
                            namespace=version.startswith("10"),
                        ),
                        f"{version}.pzfx",
                    )
                    project = prism_io.inspect_pzfx(path)
                    self.assertEqual(project.xml_version, "5.00")
                    self.assertEqual(project.created_by_version, version)
                    self.assertEqual(len(project.tables), 1)
                    self.assertTrue(project.tables[0].supported)
                    self.assertEqual(project.tables[0].kind, PrismTableKind.COLUMN)

    def test_most_recent_version_is_authoritative_and_original_is_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            resaved_path = self.write_fixture(
                tmp,
                pzfx_document(
                    [column_table()],
                    created_by_version="",
                    most_recent_version="9.5.1.528",
                ),
                "resaved.pzfx",
            )
            resaved_project = prism_io.inspect_pzfx(resaved_path)
            self.assertEqual(resaved_project.created_by_version, "9.5.1.528")
            self.assertEqual(resaved_project.warnings, ())
            self.assertTrue(resaved_project.tables[0].supported)
            self.assertEqual(resaved_project.tables[0].kind, PrismTableKind.COLUMN)

            fallback_path = self.write_fixture(
                tmp,
                pzfx_document(
                    [column_table()],
                    created_by_version="8.2.1.441",
                ),
                "original-only.pzfx",
            )
            self.assertEqual(
                prism_io.inspect_pzfx(fallback_path).created_by_version,
                "8.2.1.441",
            )

    def test_prism_8_column_resaved_by_prism_9_sample_imports_when_available(self):
        sample_path = ROOT / "demo" / "prism_samples" / "prism8ColumnsTo9.pzfx"
        if not sample_path.exists():
            self.skipTest("Local ignored Prism 8-to-9 regression sample is unavailable")

        project = prism_io.inspect_pzfx(sample_path)
        self.assertEqual(project.created_by_version, "9.5.1.528")
        self.assertEqual(project.warnings, ())
        self.assertEqual(project.tables[0].kind, PrismTableKind.COLUMN)
        self.assertTrue(project.tables[0].supported)

        result = prism_io.import_pzfx_table(sample_path, "Table0")
        self.assertEqual(list(result.dataframe.columns), ["a", "b", "c", "d"])
        self.assertEqual(result.dataframe.shape, (11, 4))

    def test_table_sequence_controls_display_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write_fixture(
                tmp,
                pzfx_document(
                    [column_table(table_id="A", title="First"), grouped_table(table_id="B", title="Second")],
                    sequence_ids=["B", "A"],
                ),
            )
            project = prism_io.inspect_pzfx(path)
        self.assertEqual([table.id for table in project.tables], ["B", "A"])
        self.assertEqual([table.kind for table in project.tables], [PrismTableKind.GROUPED, PrismTableKind.COLUMN])

    def test_unsupported_structures_are_listed_with_reasons(self):
        tables = [
            column_table(table_id="M", ext_table_type="MultipleVariables"),
            grouped_table(table_id="S", y_format="SDN"),
            xy_table(table_id="X"),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write_fixture(tmp, pzfx_document(tables, sequence_ids=["M", "S", "X"]))
            project = prism_io.inspect_pzfx(path)
        self.assertEqual(len(project.tables), 3)
        self.assertTrue(all(not table.supported for table in project.tables))
        self.assertIn("MultipleVariables", project.tables[0].unsupported_reason)
        self.assertIn("SDN", project.tables[1].unsupported_reason)
        self.assertIn("XY", project.tables[2].unsupported_reason)

    def test_default_namespace_multiple_variables_is_not_misclassified_as_column(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write_fixture(
                tmp,
                pzfx_document(
                    [column_table(ext_table_type="MultipleVariables")],
                    namespace=True,
                ),
            )
            table = prism_io.inspect_pzfx(path).tables[0]
        self.assertFalse(table.supported)
        self.assertEqual(table.ext_table_type, "MultipleVariables")

    def test_unvalidated_application_version_does_not_guess(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write_fixture(
                tmp,
                pzfx_document([column_table()], created_by_version="12.0.0"),
            )
            project = prism_io.inspect_pzfx(path)
            self.assertFalse(project.tables[0].supported)
            self.assertEqual(project.warnings[0].code, "unvalidated_prism_version")
            with self.assertRaisesRegex(PrismImportError, "not been validated"):
                prism_io.import_pzfx_table(path, "Table0")

    def test_wrong_xml_version_and_unsafe_declarations_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            wrong_version = self.write_fixture(
                tmp,
                pzfx_document([column_table()], xml_version="4.00"),
                "wrong.pzfx",
            )
            with self.assertRaises(PrismImportError) as wrong_context:
                prism_io.inspect_pzfx(wrong_version)
            self.assertEqual(wrong_context.exception.code, "unsupported_xml_version")

            unsafe = self.write_fixture(
                tmp,
                '<!DOCTYPE foo [<!ENTITY x "1">]><GraphPadPrismFile PrismXMLVersion="5.00"/>',
                "unsafe.pzfx",
            )
            with self.assertRaises(PrismImportError) as unsafe_context:
                prism_io.inspect_pzfx(unsafe)
            self.assertEqual(unsafe_context.exception.code, "unsafe_xml_declaration")

            utf16 = pathlib.Path(tmp) / "utf16.pzfx"
            utf16.write_text(pzfx_document([column_table()]), encoding="utf-16")
            with self.assertRaises(PrismImportError) as encoding_context:
                prism_io.inspect_pzfx(utf16)
            self.assertEqual(encoding_context.exception.code, "unsupported_encoding")

    def test_legacy_pzf_explains_conversion(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "legacy.pzf"
            path.write_bytes(b"binary")
            with self.assertRaisesRegex(PrismImportError, "save it as .pzfx"):
                prism_io.inspect_pzfx(path)

    def test_importing_package_does_not_load_qt_or_plotting(self):
        code = """
import sys
import easygraph.prism_io
for forbidden in ("PySide6", "matplotlib", "seaborn", "scipy"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit(f"forbidden dependency loaded: {forbidden}")
"""
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(ROOT / "src")
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=15,
                )
                self.assertEqual(result.returncode, 0, msg=result.stderr or result.stdout)

    def test_sample_inspector_outputs_deterministic_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.write_fixture(tmp, pzfx_document([column_table()]), "fixture.pzfx")
            result = subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "scripts" / "inspect_prism_samples.py"),
                    "--directory",
                    tmp,
                ],
                cwd=ROOT,
                capture_output=True,
                text=True,
                check=False,
                timeout=15,
            )
        self.assertEqual(result.returncode, 0, msg=result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(report["schema"], 1)
        self.assertEqual(report["samples"][0]["file"], "fixture.pzfx")
        self.assertEqual(report["samples"][0]["tables"][0]["kind"], "Column")


if __name__ == "__main__":
    raise SystemExit(__import__("unittest").main())
