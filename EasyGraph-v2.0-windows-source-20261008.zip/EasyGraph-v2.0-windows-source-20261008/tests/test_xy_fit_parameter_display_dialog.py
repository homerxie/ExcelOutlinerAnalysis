from __future__ import annotations

from PySide6.QtCore import QPoint, QRect, Qt
from PySide6.QtWidgets import QDialog

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.ui.xy_fit_parameter_display_dialog import (
    XYFitParameterDisplayDialog,
    XYFitParameterDisplaySeries,
)


class XYFitParameterDisplayDialogTests(EasyGraphQtTestCase):
    def dialog(self) -> XYFitParameterDisplayDialog:
        dialog = XYFitParameterDisplayDialog(
            None,
            (
                XYFitParameterDisplaySeries(
                    "series-a",
                    "Response A",
                    (("slope", 2.0), ("intercept", 1.0)),
                    ("slope",),
                ),
                XYFitParameterDisplaySeries(
                    "series-b",
                    "Response B",
                    (("amplitude", 3.0), ("offset", 0.5)),
                ),
            ),
        )
        self.addCleanup(dialog.close)
        return dialog

    def test_populates_each_fit_and_preserves_existing_selection(self):
        dialog = self.dialog()

        self.assertEqual(dialog.ui.parameterTable.rowCount(), 4)
        self.assertEqual(dialog.ui.parameterTable.item(0, 1).text(), "Response A")
        self.assertEqual(dialog.ui.parameterTable.item(0, 2).text(), "slope")
        self.assertEqual(dialog.ui.parameterTable.item(0, 3).text(), "2")
        self.assertEqual(dialog.ui.parameterTable.item(0, 0).checkState(), Qt.Checked)
        self.assertEqual(dialog.ui.parameterTable.item(1, 0).checkState(), Qt.Unchecked)
        self.assertEqual(dialog.ui.parameterTable.item(2, 0).checkState(), Qt.Checked)
        self.assertEqual(dialog.ui.parameterTable.item(3, 0).checkState(), Qt.Checked)

    def test_requires_one_parameter_per_fit_and_returns_names_in_table_order(self):
        dialog = self.dialog()
        dialog.ui.clearAllButton.click()

        dialog._accept()
        self.assertEqual(dialog.result(), QDialog.Rejected)
        self.assertIn("Response A", dialog.ui.validationLabel.text())
        self.assertIn("Response B", dialog.ui.validationLabel.text())

        dialog.ui.parameterTable.item(1, 0).setCheckState(Qt.Checked)
        dialog.ui.parameterTable.item(2, 0).setCheckState(Qt.Checked)
        dialog._accept()

        self.assertEqual(dialog.result(), QDialog.Accepted)
        self.assertEqual(
            dialog.selections(),
            {
                "series-a": ["intercept"],
                "series-b": ["amplitude"],
            },
        )

    def test_restore_defaults_selects_every_parameter(self):
        dialog = self.dialog()
        dialog.ui.clearAllButton.click()
        dialog.ui.restoreDefaultsButton.click()

        self.assertEqual(
            dialog.selections(),
            {
                "series-a": ["slope", "intercept"],
                "series-b": ["amplitude", "offset"],
            },
        )

    def test_minimum_layout_keeps_table_buttons_and_validation_separate(self):
        dialog = self.dialog()
        dialog.resize(dialog.minimumSize())
        dialog.show()
        self.qapp.processEvents()

        def bounds(widget) -> QRect:
            return QRect(widget.mapTo(dialog, QPoint(0, 0)), widget.size())

        table = bounds(dialog.ui.parameterTable)
        clear_button = bounds(dialog.ui.clearAllButton)
        defaults_button = bounds(dialog.ui.restoreDefaultsButton)
        validation = bounds(dialog.ui.validationLabel)
        button_box = bounds(dialog.ui.buttonBox)
        self.assertFalse(table.intersects(clear_button))
        self.assertFalse(table.intersects(defaults_button))
        self.assertFalse(clear_button.intersects(defaults_button))
        self.assertFalse(defaults_button.intersects(validation))
        self.assertFalse(validation.intersects(button_box))
        for rectangle in (
            table,
            clear_button,
            defaults_button,
            validation,
            button_box,
        ):
            self.assertTrue(dialog.rect().contains(rectangle))


if __name__ == "__main__":
    __import__("unittest").main()
