from __future__ import annotations

from dataclasses import asdict
import json
import pathlib
import tempfile
from unittest import mock

from tests.easygraph_case import EasyGraphQtTestCase, EasyGraphTestCase

from easygraph import template_io
from easygraph.settings import ChartSettings
from easygraph.ui import main_window
from easygraph.workbook import SHEET_MODE_GROUPS, SHEET_MODE_XY
from easygraph.xy_series import XYSettings


class StyleTemplateFamilyIOTests(EasyGraphTestCase):
    def test_same_name_variants_share_latest_common_and_keep_mode_styles(self):
        groups = ChartSettings(
            preset="Viridis",
            width=18.0,
            chart_type="Violin",
            fill_alpha=0.31,
            auto_y_range=False,
            y_min=-4.0,
        )
        xy_chart = ChartSettings(
            preset="Cividis",
            width=24.0,
            group_order="Name A-Z",
            auto_x_range=False,
            x_min=-2.0,
            x_max=8.0,
            auto_y_range=False,
            y_min=-7.0,
        )
        xy_style = XYSettings(
            show_points=False,
            show_line=True,
            marker="Diamond",
            line_width=2.8,
            line_style="Dashed",
        )

        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = template_io.write_style_template(
                "Shared family",
                groups,
                template_dir,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            template_io.write_style_template(
                "Shared family",
                xy_chart,
                template_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
                xy_settings=xy_style,
            )
            payload = json.loads(path.read_text(encoding="utf-8"))
            families = template_io.style_template_families(
                "Shared family",
                template_dir,
            )
            loaded_groups = template_io.read_style_template(
                "Shared family",
                template_dir,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            loaded_xy_chart = template_io.read_style_template(
                "Shared family",
                template_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
            )
            loaded_xy_style = template_io.read_xy_style_template(
                "Shared family",
                template_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
            )

        self.assertEqual(
            set(payload),
            {"version", "common", "variants"},
        )
        self.assertEqual(payload["version"], template_io.STYLE_TEMPLATE_VERSION)
        self.assertEqual(
            set(payload["variants"]),
            {
                template_io.TEMPLATE_FAMILY_GROUPS,
                template_io.TEMPLATE_FAMILY_XY,
            },
        )
        self.assertEqual(
            families,
            {
                template_io.TEMPLATE_FAMILY_GROUPS,
                template_io.TEMPLATE_FAMILY_XY,
            },
        )

        # The second save updates family-level common settings for both modes,
        # while leaving the first mode's private style payload intact.
        self.assertEqual(payload["common"]["width"], 24.0)
        self.assertEqual(payload["common"]["preset"], "Cividis")
        self.assertEqual(loaded_groups.width, 24.0)
        self.assertEqual(loaded_groups.preset, "Cividis")
        self.assertEqual(loaded_groups.chart_type, "Violin")
        self.assertEqual(loaded_groups.fill_alpha, 0.31)
        self.assertFalse(loaded_groups.auto_y_range)
        self.assertEqual(loaded_groups.y_min, -4.0)

        self.assertEqual(loaded_xy_chart.width, 24.0)
        self.assertEqual(loaded_xy_chart.group_order, "Name A-Z")
        self.assertFalse(loaded_xy_chart.auto_x_range)
        self.assertEqual(loaded_xy_chart.x_min, -2.0)
        self.assertEqual(loaded_xy_chart.x_max, 8.0)
        self.assertEqual(loaded_xy_chart.y_min, -7.0)
        self.assertIsNotNone(loaded_xy_style)
        self.assertEqual(loaded_xy_style.marker, "Diamond")
        self.assertEqual(loaded_xy_style.line_width, 2.8)

    def test_legacy_xy_style_classifies_only_as_xy_and_lists_are_filtered(self):
        groups_data = asdict(
            ChartSettings(chart_type="Ridge", width=17.0)
        )
        xy_data = asdict(ChartSettings(width=21.0))
        xy_data[template_io.XY_STYLE_TEMPLATE_KEY] = asdict(
            template_io.XYStyleTemplate(
                show_points=False,
                show_line=True,
                marker="Square",
            )
        )

        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            groups_path = template_dir / "Legacy Groups.json"
            xy_path = template_dir / "Legacy XY.json"
            groups_path.write_text(
                json.dumps(groups_data),
                encoding="utf-8",
            )
            xy_path.write_text(json.dumps(xy_data), encoding="utf-8")
            template_io.write_style_template(
                "Both",
                ChartSettings(chart_type="Box"),
                template_dir,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            template_io.write_style_template(
                "Both",
                ChartSettings(),
                template_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
                xy_settings=XYSettings(),
            )

            self.assertEqual(
                template_io.style_template_families_file(groups_path),
                {template_io.TEMPLATE_FAMILY_GROUPS},
            )
            self.assertEqual(
                template_io.style_template_families_file(xy_path),
                {template_io.TEMPLATE_FAMILY_XY},
            )
            groups_names = template_io.list_style_templates(
                template_dir,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            xy_names = template_io.list_style_templates(
                template_dir,
                family=template_io.TEMPLATE_FAMILY_XY,
            )

            with self.assertRaises(ValueError):
                template_io.read_style_template_file(
                    xy_path,
                    family=template_io.TEMPLATE_FAMILY_GROUPS,
                )
            with self.assertRaises(ValueError):
                template_io.read_style_template_file(
                    groups_path,
                    family=template_io.TEMPLATE_FAMILY_XY,
                )

        self.assertEqual(
            set(groups_names),
            {"Both", "Legacy Groups"},
        )
        self.assertEqual(set(xy_names), {"Both", "Legacy XY"})

    def test_legacy_v2_distribution_key_normalizes_and_rewrites_as_groups(self):
        legacy_document = {
            "version": template_io.STYLE_TEMPLATE_VERSION,
            "common": {
                "preset": "Viridis",
                "width": 22.0,
            },
            "variants": {
                "distribution": {
                    "chart_type": "Violin",
                    "fill_alpha": 0.37,
                },
            },
        }

        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            template_dir = root / "templates"
            template_dir.mkdir()
            saved_path = template_dir / "Legacy v2 save.json"
            saved_path.write_text(
                json.dumps(legacy_document),
                encoding="utf-8",
            )

            self.assertEqual(
                template_io.style_template_families_file(saved_path),
                {template_io.TEMPLATE_FAMILY_GROUPS},
            )
            loaded = template_io.read_style_template_file(
                saved_path,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            self.assertEqual(loaded.width, 22.0)
            self.assertEqual(loaded.chart_type, "Violin")
            self.assertEqual(loaded.fill_alpha, 0.37)

            template_io.write_style_template(
                "Legacy v2 save",
                ChartSettings(chart_type="Ridge", fill_alpha=0.44),
                template_dir,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            rewritten_after_save = json.loads(
                saved_path.read_text(encoding="utf-8")
            )

            source_dir = root / "source"
            source_dir.mkdir()
            import_source = source_dir / "Legacy v2 import.json"
            import_source.write_text(
                json.dumps(legacy_document),
                encoding="utf-8",
            )
            imported_name, imported = template_io.import_style_template(
                import_source,
                template_dir,
            )
            imported_path = template_dir / "Legacy v2 import.json"
            rewritten_after_import = json.loads(
                imported_path.read_text(encoding="utf-8")
            )

        self.assertEqual(
            set(rewritten_after_save["variants"]),
            {template_io.TEMPLATE_FAMILY_GROUPS},
        )
        self.assertNotIn("distribution", rewritten_after_save["variants"])
        self.assertEqual(
            set(rewritten_after_import["variants"]),
            {template_io.TEMPLATE_FAMILY_GROUPS},
        )
        self.assertNotIn("distribution", rewritten_after_import["variants"])
        self.assertEqual(imported_name, "Legacy v2 import")
        self.assertEqual(imported.width, 22.0)
        self.assertEqual(imported.chart_type, "Violin")

    def test_importing_same_legacy_name_merges_variants_and_updates_common(self):
        groups_data = asdict(
            ChartSettings(
                chart_type="Ridge",
                width=18.0,
                fill_alpha=0.42,
            )
        )
        xy_data = asdict(
            ChartSettings(
                width=27.0,
                group_order="Name Z-A",
                auto_x_range=False,
                x_min=-3.0,
                x_max=9.0,
            )
        )
        xy_data[template_io.XY_STYLE_TEMPLATE_KEY] = asdict(
            template_io.XYStyleTemplate(
                show_points=True,
                show_line=False,
                marker="Triangle",
            )
        )

        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            first_source = root / "first" / "Merged.json"
            second_source = root / "second" / "Merged.json"
            destination = root / "templates"
            first_source.parent.mkdir()
            second_source.parent.mkdir()
            first_source.write_text(
                json.dumps(groups_data),
                encoding="utf-8",
            )
            second_source.write_text(json.dumps(xy_data), encoding="utf-8")

            template_io.import_style_template(first_source, destination)
            template_io.import_style_template(second_source, destination)

            families = template_io.style_template_families(
                "Merged",
                destination,
            )
            loaded_groups = template_io.read_style_template(
                "Merged",
                destination,
                family=template_io.TEMPLATE_FAMILY_GROUPS,
            )
            loaded_xy_chart = template_io.read_style_template(
                "Merged",
                destination,
                family=template_io.TEMPLATE_FAMILY_XY,
            )
            loaded_xy_style = template_io.read_xy_style_template(
                "Merged",
                destination,
                family=template_io.TEMPLATE_FAMILY_XY,
            )

        self.assertEqual(
            families,
            {
                template_io.TEMPLATE_FAMILY_GROUPS,
                template_io.TEMPLATE_FAMILY_XY,
            },
        )
        self.assertEqual(loaded_groups.width, 27.0)
        self.assertEqual(loaded_groups.chart_type, "Ridge")
        self.assertEqual(loaded_groups.fill_alpha, 0.42)
        self.assertEqual(loaded_xy_chart.width, 27.0)
        self.assertEqual(loaded_xy_chart.group_order, "Name Z-A")
        self.assertFalse(loaded_xy_chart.auto_x_range)
        self.assertEqual(loaded_xy_chart.x_min, -3.0)
        self.assertIsNotNone(loaded_xy_style)
        self.assertEqual(loaded_xy_style.marker, "Triangle")


class StyleTemplateFamilyUITests(EasyGraphQtTestCase):
    @staticmethod
    def _set_template_name(window, name: str) -> None:
        blocked = window.template_combo.blockSignals(True)
        try:
            window.template_combo.clear()
            window.template_combo.addItems([template_io.TEMPLATE_NONE_NAME, name])
            window.template_combo.setCurrentText(name)
        finally:
            window.template_combo.blockSignals(blocked)

    def test_switch_sheet_resets_template_action_without_applying_it(self):
        with mock.patch.object(main_window, "list_style_templates", return_value=[]):
            window = self.make_window(initial_render=False)
            with mock.patch.object(window, "render"):
                window.add_sheet(SHEET_MODE_XY)

        xy_sheet = window.workbook.active_sheet
        xy_sheet.settings.width = 26.0
        xy_sheet.settings.preset = "Cividis"
        xy_sheet.xy_settings.marker = "Diamond"
        groups_sheet = window.workbook.sheets[0]
        groups_sheet.settings.preset = "Viridis"
        with mock.patch.object(main_window, "list_style_templates", return_value=[]):
            with mock.patch.object(window, "render"):
                window.switch_sheet(0)
        self.assertEqual(window.workbook.active_sheet.mode, SHEET_MODE_GROUPS)
        self.assertEqual(window.preset.currentText(), "Viridis")
        self.assertEqual(
            window.ui.templateToolbarLabel.text(),
            "Groups Style Templates",
        )
        self._set_template_name(window, "Do not apply")

        def names_for_family(*_args, family=None, **_kwargs):
            return (
                ["Target XY family"]
                if family == template_io.TEMPLATE_FAMILY_XY
                else ["Target Groups family"]
            )

        with mock.patch.object(
            main_window,
            "list_style_templates",
            side_effect=names_for_family,
        ) as list_templates:
            with mock.patch.object(main_window, "read_style_template") as read_chart:
                with mock.patch.object(
                    main_window,
                    "read_xy_style_template",
                ) as read_xy:
                    with mock.patch.object(window, "apply_style_template") as apply:
                        with mock.patch.object(window, "render"):
                            window.switch_sheet(1)

        self.assertEqual(window.workbook.active_sheet.id, xy_sheet.id)
        self.assertEqual(window.workbook.active_sheet.settings.width, 26.0)
        self.assertEqual(window.workbook.active_sheet.settings.preset, "Cividis")
        self.assertEqual(window.preset.currentText(), "Cividis")
        self.assertEqual(window.ui.templateToolbarLabel.text(), "XY Style Templates")
        self.assertEqual(window.workbook.active_sheet.xy_settings.marker, "Diamond")
        self.assertEqual(
            window.template_combo.currentText(),
            template_io.TEMPLATE_NONE_NAME,
        )
        self.assertEqual(
            [
                window.template_combo.itemText(index)
                for index in range(window.template_combo.count())
            ],
            [template_io.TEMPLATE_NONE_NAME, "Target XY family"],
        )
        read_chart.assert_not_called()
        read_xy.assert_not_called()
        apply.assert_not_called()
        self.assertTrue(
            any(
                call.kwargs.get("family")
                == template_io.TEMPLATE_FAMILY_XY
                for call in list_templates.call_args_list
            )
        )

    def test_add_xy_sheet_uses_selected_family_xy_variant_then_resets_action(self):
        xy_chart = ChartSettings(
            width=23.0,
            group_order="Name A-Z",
            auto_x_range=False,
            x_min=-2.0,
            x_max=7.0,
        )
        xy_style = template_io.XYStyleTemplate(
            show_points=False,
            show_line=True,
            marker="Diamond",
            line_width=2.6,
        )

        with mock.patch.object(main_window, "list_style_templates", return_value=[]):
            window = self.make_window(initial_render=False)
        self._set_template_name(window, "Shared family")

        def names_for_family(*_args, family=None, **_kwargs):
            return (
                ["Shared family"]
                if family == template_io.TEMPLATE_FAMILY_XY
                else []
            )

        with mock.patch.object(
            main_window,
            "list_style_templates",
            side_effect=names_for_family,
        ):
            with mock.patch.object(
                main_window,
                "read_style_template",
                return_value=xy_chart,
            ) as read_chart:
                with mock.patch.object(
                    main_window,
                    "read_xy_style_template",
                    return_value=xy_style,
                ) as read_xy:
                    with mock.patch.object(window, "render"):
                        window.add_sheet(SHEET_MODE_XY)

        sheet = window.workbook.active_sheet
        self.assertEqual(sheet.mode, SHEET_MODE_XY)
        self.assertEqual(sheet.settings.width, 23.0)
        self.assertEqual(sheet.settings.group_order, "Name A-Z")
        self.assertFalse(sheet.settings.auto_x_range)
        self.assertEqual(sheet.settings.x_min, -2.0)
        self.assertFalse(sheet.xy_settings.show_points)
        self.assertTrue(sheet.xy_settings.show_line)
        self.assertEqual(sheet.xy_settings.marker, "Diamond")
        self.assertEqual(sheet.xy_settings.line_width, 2.6)
        self.assertTrue(sheet.xy_settings.series)
        self.assertEqual(
            window.template_combo.currentText(),
            template_io.TEMPLATE_NONE_NAME,
        )
        read_chart.assert_called_once_with(
            "Shared family",
            family=template_io.TEMPLATE_FAMILY_XY,
        )
        read_xy.assert_called_once()
        self.assertEqual(read_xy.call_args.args[0], "Shared family")

    def test_add_sheet_does_not_fall_back_to_the_other_family_variant(self):
        with mock.patch.object(main_window, "list_style_templates", return_value=[]):
            window = self.make_window(initial_render=False)
        self._set_template_name(window, "Groups only")

        with mock.patch.object(
            main_window,
            "list_style_templates",
            return_value=[],
        ):
            with mock.patch.object(main_window, "read_style_template") as read_chart:
                with mock.patch.object(
                    main_window,
                    "read_xy_style_template",
                ) as read_xy:
                    with mock.patch.object(window, "render"):
                        window.add_sheet(SHEET_MODE_XY)

        sheet = window.workbook.active_sheet
        self.assertEqual(sheet.mode, SHEET_MODE_XY)
        self.assertEqual(sheet.settings.width, ChartSettings().width)
        self.assertEqual(sheet.xy_settings.marker, XYSettings().marker)
        self.assertEqual(sheet.xy_settings.line_width, XYSettings().line_width)
        self.assertEqual(
            window.template_combo.currentText(),
            template_io.TEMPLATE_NONE_NAME,
        )
        read_chart.assert_not_called()
        read_xy.assert_not_called()

    def test_import_without_active_family_variant_does_not_apply(self):
        imported_path = pathlib.Path("/tmp/Only XY.json")
        with mock.patch.object(main_window, "list_style_templates", return_value=[]):
            window = self.make_window(initial_render=False)

        with mock.patch.object(
            main_window.QFileDialog,
            "getOpenFileName",
            return_value=(str(imported_path), ""),
        ):
            with mock.patch.object(
                main_window,
                "style_template_families_file",
                return_value={template_io.TEMPLATE_FAMILY_XY},
            ):
                with mock.patch.object(
                    main_window,
                    "import_style_template",
                    return_value=("Only XY", ChartSettings()),
                ) as import_template:
                    with mock.patch.object(
                        main_window,
                        "list_style_templates",
                        return_value=[],
                    ):
                        with mock.patch.object(
                            main_window,
                            "read_style_template",
                        ) as read_chart:
                            with mock.patch.object(
                                window,
                                "apply_style_template",
                            ) as apply:
                                window.load_external_template()

        import_template.assert_called_once_with(imported_path)
        read_chart.assert_not_called()
        apply.assert_not_called()
        self.assertEqual(
            window.template_combo.currentText(),
            template_io.TEMPLATE_NONE_NAME,
        )

    def test_save_routes_each_sheet_mode_to_its_matching_family(self):
        with mock.patch.object(main_window, "list_style_templates", return_value=[]):
            window = self.make_window(initial_render=False)

        def save_and_get_call(name: str):
            with mock.patch.object(window, "update_settings"):
                with mock.patch.object(window, "flush_pending_render"):
                    with mock.patch.object(
                        main_window.QInputDialog,
                        "getText",
                        return_value=(name, True),
                    ):
                        with mock.patch.object(
                            main_window,
                            "write_style_template",
                            return_value=pathlib.Path(f"/tmp/{name}.json"),
                        ) as write_template:
                            with mock.patch.object(window, "refresh_template_combo"):
                                window.save_current_template()
            write_template.assert_called_once()
            return write_template.call_args

        groups_call = save_and_get_call("Groups family")
        self.assertEqual(
            groups_call.kwargs["family"],
            template_io.TEMPLATE_FAMILY_GROUPS,
        )
        self.assertIsNone(groups_call.kwargs["xy_settings"])

        with mock.patch.object(main_window, "list_style_templates", return_value=[]):
            with mock.patch.object(window, "render"):
                window.add_sheet(SHEET_MODE_XY)
        xy_settings = window.workbook.active_sheet.xy_settings
        xy_call = save_and_get_call("XY family")
        self.assertEqual(
            xy_call.kwargs["family"],
            template_io.TEMPLATE_FAMILY_XY,
        )
        self.assertIs(xy_call.kwargs["xy_settings"], xy_settings)
