from __future__ import annotations

from unittest import mock

import pandas as pd
from PySide6.QtWidgets import QComboBox, QDialog, QWidget

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.spreadsheet_io import SpreadsheetSheet
from easygraph.ui.spreadsheet_import_dialog import choose_spreadsheet_sheets
from easygraph.workbook import SHEET_MODE_XY


class SpreadsheetImportDialogTests(EasyGraphQtTestCase):
    def test_multiple_sheet_dialog_selects_nonempty_sheets_by_default(self):
        parent = QWidget()
        self.addCleanup(parent.deleteLater)
        sheets = [
            SpreadsheetSheet("Data", pd.DataFrame({"A": [1]})),
            SpreadsheetSheet("Empty", pd.DataFrame()),
        ]

        with mock.patch.object(QDialog, "exec", return_value=QDialog.DialogCode.Accepted):
            selected = choose_spreadsheet_sheets(parent, sheets)

        self.assertEqual(selected, [sheets[0]])

    def test_multiple_sheet_dialog_cancel_returns_none(self):
        parent = QWidget()
        self.addCleanup(parent.deleteLater)
        sheets = [
            SpreadsheetSheet("First", pd.DataFrame({"A": [1]})),
            SpreadsheetSheet("Second", pd.DataFrame({"B": [2]})),
        ]

        with mock.patch.object(QDialog, "exec", return_value=QDialog.DialogCode.Rejected):
            selected = choose_spreadsheet_sheets(parent, sheets)

        self.assertIsNone(selected)

    def test_single_sheet_dialog_can_select_xy_mode(self):
        parent = QWidget()
        self.addCleanup(parent.deleteLater)
        sheet = SpreadsheetSheet("XY Data", pd.DataFrame({"X": [1], "Y": [2]}))

        def execute():
            dialog = parent.findChild(QDialog)
            mode_combo = dialog.findChild(QComboBox, "sheetModeCombo")
            mode_combo.setCurrentIndex(mode_combo.findData(SHEET_MODE_XY))
            return QDialog.DialogCode.Accepted

        with mock.patch.object(QDialog, "exec", side_effect=execute):
            selected = choose_spreadsheet_sheets(parent, [sheet])

        self.assertEqual(selected, [sheet])
        self.assertEqual(sheet.mode, SHEET_MODE_XY)


if __name__ == "__main__":
    __import__("unittest").main()
