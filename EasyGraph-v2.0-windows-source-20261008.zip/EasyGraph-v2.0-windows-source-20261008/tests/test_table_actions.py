from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.table_actions import (
    append_group_column,
    insert_sample_row,
    remove_current_or_last_group_column,
    remove_table_column,
    set_group_header,
)


class TableActionsTests(EasyGraphQtTestCase):
    def test_insert_sample_row_appends_row_and_returns_index(self):
        table = DataTable(2, 1)
        self.addCleanup(table.deleteLater)

        row = insert_sample_row(table)

        self.assertEqual(row, 2)
        self.assertEqual(table.table_model.rowCount(), 3)

    def test_append_group_column_adds_default_header_and_returns_index(self):
        table = DataTable(1, 1)
        self.addCleanup(table.deleteLater)

        col = append_group_column(table)

        self.assertEqual(col, 1)
        self.assertEqual(table.table_model.columnCount(), 2)
        self.assertEqual(table.table_model.cell_text(0, 1), "Group 2")

    def test_remove_current_or_last_group_column_uses_selection_or_last_column(self):
        table = DataTable(1, 3)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells([["A", "B", "C"]], column_count=3)
        table.setCurrentIndex(table.table_model.index(0, 1))

        self.assertTrue(remove_current_or_last_group_column(table))
        self.assertEqual(table.table_model.columnCount(), 2)
        self.assertEqual(table.table_model.cell_text(0, 1), "C")

        table.clearSelection()
        table.setCurrentIndex(table.table_model.index(-1, -1))

        self.assertTrue(remove_current_or_last_group_column(table))
        self.assertEqual(table.table_model.columnCount(), 1)
        self.assertEqual(table.table_model.cell_text(0, 0), "A")

    def test_remove_current_or_last_group_column_returns_false_without_columns(self):
        table = DataTable(1, 0)
        self.addCleanup(table.deleteLater)

        self.assertFalse(remove_current_or_last_group_column(table))

    def test_remove_table_column_removes_valid_column_and_rejects_invalid_column(self):
        table = DataTable(1, 2)
        self.addCleanup(table.deleteLater)

        self.assertFalse(remove_table_column(table, -1))
        self.assertFalse(remove_table_column(table, 2))
        self.assertTrue(remove_table_column(table, 1))
        self.assertEqual(table.table_model.columnCount(), 1)

    def test_set_group_header_writes_name_to_group_row(self):
        table = DataTable(1, 1)
        self.addCleanup(table.deleteLater)

        set_group_header(table, 0, " Renamed ")

        self.assertEqual(table.table_model.cell_text(0, 0), "Renamed")
