"""Anonymous, minimal PZFX fixtures for Prism import tests."""

from __future__ import annotations

from pathlib import Path


def pzfx_document(
    tables: list[str],
    *,
    created_by_version: str = "10.3.1.464",
    most_recent_version: str | None = None,
    xml_version: str = "5.00",
    namespace: bool = False,
    sequence_ids: list[str] | None = None,
) -> str:
    namespace_attribute = ' xmlns="http://graphpad.com/prism/Prism.htm"' if namespace else ""
    sequence_ids = sequence_ids or [f"Table{index}" for index in range(len(tables))]
    refs = "".join(f'<Ref ID="{table_id}"/>' for table_id in sequence_ids)
    recent_version = (
        ""
        if most_recent_version is None
        else (
            '<MostRecentVersion CreatedByProgram="GraphPad Prism" '
            f'CreatedByVersion="{most_recent_version}"/>'
        )
    )
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f'<GraphPadPrismFile{namespace_attribute} PrismXMLVersion="{xml_version}">'
        "<Created><OriginalVersion CreatedByProgram=\"GraphPad Prism\" "
        f'CreatedByVersion="{created_by_version}"/>{recent_version}</Created>'
        f"<TableSequence>{refs}</TableSequence>"
        f"{''.join(tables)}"
        "<Template>ignored-layout-data</Template>"
        "</GraphPadPrismFile>"
    )


def column_table(
    *,
    table_id: str = "Table0",
    title: str = "Column data",
    y_format: str = "",
    ext_table_type: str = "",
    include_row_titles: bool = False,
) -> str:
    y_format_attribute = f' YFormat="{y_format}"' if y_format else ""
    ext_attribute = f' ExtTableType="{ext_table_type}"' if ext_table_type else ""
    row_titles = (
        "<RowTitlesColumn><Subcolumn><d>Subject 1</d><d>Subject 2</d></Subcolumn></RowTitlesColumn>"
        if include_row_titles
        else ""
    )
    return (
        f'<Table ID="{table_id}" TableType="OneWay" XFormat="none"'
        f"{y_format_attribute}{ext_attribute}>"
        f"<Title>{title}</Title>"
        f"{row_titles}"
        "<YColumn Subcolumns=\"1\"><Title>A</Title><Subcolumn>"
        "<d>1</d><d Excluded=\"true\">2</d><d></d>"
        "</Subcolumn></YColumn>"
        "<YColumn Subcolumns=\"1\"><Title>B</Title><Subcolumn>"
        "<d>-3.5</d><d>4e1</d>"
        "</Subcolumn></YColumn>"
        "</Table>"
    )


def grouped_table(
    *,
    table_id: str = "Table0",
    title: str = "Grouped data",
    y_format: str = "replicates",
    ext_table_type: str = "",
    short_subcolumn: bool = False,
) -> str:
    ext_attribute = f' ExtTableType="{ext_table_type}"' if ext_table_type else ""
    last_value = "" if short_subcolumn else "<d>6</d>"
    return (
        f'<Table ID="{table_id}" TableType="TwoWay" YFormat="{y_format}" Replicates="2"'
        f"{ext_attribute}>"
        f"<Title>{title}</Title>"
        "<RowTitlesColumn><Subcolumn><d>Wild type</d><d>Knock-out</d></Subcolumn></RowTitlesColumn>"
        "<YColumn Subcolumns=\"2\"><Title>Control</Title>"
        "<Subcolumn><d>1</d><d>2</d></Subcolumn>"
        f"<Subcolumn><d>5</d>{last_value}</Subcolumn>"
        "</YColumn>"
        "<YColumn Subcolumns=\"2\"><Title>Treated</Title>"
        "<Subcolumn><d>7</d><d>8</d></Subcolumn>"
        "<Subcolumn><d Excluded=\"1\">9</d><d>10</d></Subcolumn>"
        "</YColumn>"
        "</Table>"
    )


def xy_table(*, table_id: str = "Table0") -> str:
    return (
        f'<Table ID="{table_id}" TableType="XY" YFormat="replicates">'
        "<Title>XY data</Title>"
        "<XColumn><Subcolumn><d>1</d></Subcolumn></XColumn>"
        "<YColumn><Subcolumn><d>2</d></Subcolumn></YColumn>"
        "</Table>"
    )


def write_pzfx(path: Path, content: str) -> Path:
    path.write_text(content, encoding="utf-8")
    return path
