import os
import subprocess
import sys

from tests.easygraph_case import ROOT, EasyGraphTestCase
from easygraph import data


class DataModuleTests(EasyGraphTestCase):
    def test_data_module_declares_exact_public_api(self):
        expected_exports = (
            "attach_group_metadata",
            "group_keys",
            "group_labels",
            "migrate_group_settings",
            "axis_labels_for_chart",
            "blank_project_data",
            "blank_xy_data",
            "box_whis",
            "hidden_group_names",
            "mark_outliers",
            "ordered_group_columns",
            "prepare_plot_data",
            "sample_data",
            "unique_groups",
            "values_for_group",
        )
        self.assertEqual(data.__all__, list(expected_exports))

    def test_data_module_imports_without_gui_or_plotting_stack(self):
        environment = os.environ.copy()
        source_path = str(ROOT / "src")
        existing_pythonpath = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = (
            source_path + os.pathsep + existing_pythonpath
            if existing_pythonpath
            else source_path
        )
        code = f"""
import sys
sys.path.insert(0, {source_path!r})
from easygraph.data import sample_data

assert len(sample_data().columns) == 3
assert not any(name == "PySide6" or name.startswith("PySide6.") for name in sys.modules)
assert not any(name == "matplotlib" or name.startswith("matplotlib.") for name in sys.modules)
"""

        result = subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True,
            text=True,
            env=environment,
            cwd=ROOT,
            check=False,
            timeout=10,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
