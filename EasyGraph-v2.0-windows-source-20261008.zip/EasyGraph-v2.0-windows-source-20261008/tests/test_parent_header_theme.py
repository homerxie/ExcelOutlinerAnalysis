"""Rendered regression checks for grouped header borders in both app themes."""
from __future__ import annotations

import unittest

from PySide6.QtGui import QStandardItemModel
from PySide6.QtWidgets import QApplication, QTableView

from easygraph.app_theme import apply_app_theme, qdarktheme
from easygraph.ui.group_header import GroupHeaderView


@unittest.skipIf(qdarktheme is None, "The app's optional qdarktheme is unavailable")
class ParentHeaderThemeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        stylesheet = self.app.styleSheet()
        font = self.app.font()
        icon = self.app.windowIcon()
        self.addCleanup(self.app.setWindowIcon, icon)
        self.addCleanup(self.app.setFont, font)
        self.addCleanup(self.app.setStyleSheet, stylesheet)
        self.table = QTableView()
        self.table.setObjectName("dataTable")
        self.table.setModel(QStandardItemModel(3, 6, self.table))
        self.header = GroupHeaderView(self.table)
        self.header.setObjectName("dataTableHorizontalHeader")
        self.table.setHorizontalHeader(self.header)
        self.header.setDefaultSectionSize(90)
        ids = [f"column-{column}" for column in range(6)]
        self.header.set_grouping(
            [
                {"id": "wt", "name": "WT", "column_ids": ids[:2]},
                {"id": "ko", "name": "KO", "column_ids": ids[3:5]},
            ],
            ids,
        )
        self.table.resize(590, 200)
        self.addCleanup(self.table.deleteLater)
        self.addCleanup(self.table.close)
        self.table.show()

    def image(self, theme):
        apply_app_theme(self.app, theme)
        self.app.processEvents()
        return self.header.viewport().grab().toImage()

    @staticmethod
    def difference(first, second):
        return max(abs(a - b) for a, b in zip(first.getRgb()[:3], second.getRgb()[:3]))

    def test_group_and_blank_boundaries_remain_visible_when_switching_themes(self):
        for theme in ("dark", "light", "dark"):
            with self.subTest(theme=theme):
                image = self.image(theme)
                band = self.header.parent_band_rect()
                y = band.top() + 5
                background = image.pixelColor(10, y)
                # Both merged blocks and the intervening blank parent cell
                # need visible outlines, including their top and bottom edges.
                for end_column in (1, 2, 4, 5):
                    x = self.header.sectionViewportPosition(end_column) + self.header.sectionSize(end_column) - 1
                    self.assertGreater(self.difference(image.pixelColor(x, y), background), 15)
                for y_edge in (band.top(), band.bottom()):
                    self.assertGreater(self.difference(image.pixelColor(10, y_edge), background), 15)
                # A merged parent stays visually continuous across its leaves.
                inner_boundary = self.header.sectionViewportPosition(1) - 1
                self.assertEqual(image.pixelColor(inner_boundary, y), background)

    def test_selected_block_retains_its_stronger_outline(self):
        for theme in ("dark", "light"):
            with self.subTest(theme=theme):
                self.header.select_parent_columns([0])
                image = self.image(theme)
                rect = self.header._columns_rect([0, 1])
                highlight = self.header.palette().highlight().color()
                self.assertEqual(image.pixelColor(rect.left() + 1, rect.top() + 5), highlight)
                self.assertEqual(image.pixelColor(rect.right() - 1, rect.top() + 5), highlight)
                self.header.clear_parent_selection()
