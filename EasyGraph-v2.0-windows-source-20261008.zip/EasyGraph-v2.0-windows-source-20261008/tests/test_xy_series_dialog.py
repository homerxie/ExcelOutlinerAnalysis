from __future__ import annotations

from copy import deepcopy
from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.ui import main_window
from easygraph.ui.xy_series_dialog import create_xy_series_dialog
from easygraph.workbook import SHEET_MODE_XY
from easygraph.xy_series import XYSeriesSpec, XYSettings, xy_mapping_mode


class XYSeriesDialogTests(EasyGraphQtTestCase):
    def controller(self):
        parent = QWidget()
        self.addCleanup(parent.close)
        frame = pd.DataFrame(
            [[0, 10, 0.5, 20], [1, 11, 1.5, 21]],
            columns=["Time", "Response", "Time", "Response"],
        )
        controller = create_xy_series_dialog(
            parent,
            frame,
            ["x1", "y1", "x2", "y2"],
            XYSettings(),
        )
        self.addCleanup(controller.dialog.close)
        return controller

    def test_shared_and_adjacent_batch_actions_build_clear_mappings(self):
        controller = self.controller()

        controller.use_shared_x()
        shared = controller.result()
        self.assertEqual(shared.default_x_column_id, "x1")
        self.assertEqual([series.y_column_id for series in shared.series], ["y1", "x2", "y2"])
        self.assertEqual(xy_mapping_mode(shared), "shared")

        controller.use_adjacent_xy()
        paired = controller.result()
        self.assertIsNone(paired.default_x_column_id)
        self.assertEqual(
            [(series.x_column_id, series.y_column_id) for series in paired.series],
            [("x1", "y1"), ("x2", "y2")],
        )
        self.assertEqual(xy_mapping_mode(paired), "paired")
        self.assertIn("2 series", controller.ui.mappingStatusLabel.text())
        self.assertEqual(controller.ui.seriesTable.item(0, 4).text(), "2 · 0 skipped")

    def test_duplicate_column_labels_are_disambiguated_and_row_settings_are_editable(self):
        controller = self.controller()
        controller.use_adjacent_xy()

        self.assertEqual(controller.ui.defaultXCombo.itemText(1), "Time · Column 1")
        self.assertEqual(controller.ui.defaultXCombo.itemText(3), "Time · Column 3")
        name_editor = controller.ui.seriesTable.cellWidget(0, 1)
        name_editor.setText("First response")
        points_combo = controller.ui.seriesTable.cellWidget(0, 5)
        line_combo = controller.ui.seriesTable.cellWidget(0, 6)
        points_combo.setCurrentIndex(2)
        line_combo.setCurrentIndex(1)
        controller.ui.seriesTable.item(1, 0).setCheckState(Qt.Unchecked)

        result = controller.result()

        self.assertEqual(result.series[0].name, "First response")
        self.assertFalse(result.series[0].show_points)
        self.assertTrue(result.series[0].show_line)
        self.assertFalse(result.series[1].visible)

    def test_main_window_edits_series_order_without_exposing_mapping(self):
        window = main_window.MainWindow(initial_render=False, defer_preview=True)
        def close_window():
            with mock.patch.object(
                window,
                "_prompt_unsaved_changes",
                return_value="discard",
            ):
                window.close()

        self.addCleanup(close_window)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        original = deepcopy(window.workbook.active_sheet.xy_settings)
        labels = window._xy_series_labels()
        reversed_labels = [labels[series.id] for series in reversed(original.series)]

        with mock.patch.object(
            main_window,
            "run_group_order_dialog",
            return_value=reversed_labels,
        ), mock.patch.object(window, "render") as render:
            window.edit_group_order()

        self.assertEqual(
            [series.id for series in window.workbook.active_sheet.xy_settings.series],
            [series.id for series in reversed(original.series)],
        )
        self.assertEqual(window.settings.group_order, "Manual")
        render.assert_called_once_with()


if __name__ == "__main__":
    __import__("unittest").main()
