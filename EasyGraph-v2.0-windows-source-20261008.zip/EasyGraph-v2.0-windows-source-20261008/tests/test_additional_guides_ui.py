from __future__ import annotations

from types import SimpleNamespace
from unittest import mock

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.ui import main_window
from easygraph.workbook import SHEET_MODE_XY


class AdditionalGuidesUiTests(EasyGraphQtTestCase):
    def assert_new_guide_defaults(self, window, guide, *, dimension="y"):
        expected_side = "right" if dimension == "x" else "plot_left"
        expected_vertical = (
            "plot_bottom" if dimension == "x" else "above"
        )
        self.assertTrue(guide["show_tick"])
        self.assertTrue(guide["show_value_with_text"])
        self.assertTrue(guide["show_line"])
        self.assertEqual(guide["text_side"], expected_side)
        self.assertEqual(guide["vertical_position"], expected_vertical)
        self.assertEqual(guide["text_color_mode"], "match_line")
        self.assertTrue(window.additional_guide_tick.isChecked())
        self.assertTrue(window.additional_guide_show_value.isChecked())
        self.assertTrue(window.additional_guide_line.isChecked())
        self.assertEqual(
            window.additional_guide_text_side.currentData(),
            expected_side,
        )
        self.assertEqual(
            window.additional_guide_text_vertical.currentData(),
            expected_vertical,
        )
        self.assertEqual(
            window.additional_guide_text_color.currentData(),
            "match_line",
        )

    def test_y_text_position_controls_use_plot_edges_and_axis_left(self):
        window = self.make_window(initial_render=False)

        self.assertEqual(
            [
                window.additional_guide_text_side.itemData(index)
                for index in range(window.additional_guide_text_side.count())
            ],
            ["plot_left", "plot_right", "left"],
        )
        self.assertEqual(
            [
                window.additional_guide_text_vertical.itemData(index)
                for index in range(
                    window.additional_guide_text_vertical.count()
                )
            ],
            ["aligned", "above", "below"],
        )
        self.assertEqual(
            window.additional_guide_text_side.itemText(
                window.additional_guide_text_side.findData("left")
            ),
            "Left of Y axis",
        )
        self.assertEqual(
            window.additional_guide_text_side.itemText(
                window.additional_guide_text_side.findData("plot_left")
            ),
            "Align to plot left",
        )
        self.assertEqual(
            window.additional_guide_text_side.itemText(
                window.additional_guide_text_side.findData("plot_right")
            ),
            "Align to plot right",
        )
        self.assertEqual(
            [
                window.additional_guide_text_color.itemData(index)
                for index in range(
                    window.additional_guide_text_color.count()
                )
            ],
            ["auto", "match_line"],
        )

    def test_ridge_value_axis_uses_x_dimension_position_options(self):
        window = self.make_window(initial_render=False)
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(5.0),
                "vertical_position": "plot_bottom",
            }
        ]

        with mock.patch.object(window, "schedule_render"):
            window.chart_type.setCurrentText("Ridge")
        window.handle_plot_object_selection("primary_axis")

        self.assertEqual(
            [
                window.additional_guide_text_side.itemData(index)
                for index in range(window.additional_guide_text_side.count())
            ],
            ["left", "center", "right"],
        )
        self.assertEqual(
            [
                window.additional_guide_text_vertical.itemData(index)
                for index in range(
                    window.additional_guide_text_vertical.count()
                )
            ],
            ["plot_bottom", "plot_top", "below"],
        )
        self.assertEqual(
            window.additional_guide_text_vertical.currentData(),
            "plot_bottom",
        )
        self.assertEqual(
            window.additional_guide_text_vertical.itemText(
                window.additional_guide_text_vertical.findData("plot_bottom")
            ),
            "Align to plot bottom",
        )
        self.assertEqual(
            window.additional_guide_text_vertical.itemText(
                window.additional_guide_text_vertical.findData("plot_top")
            ),
            "Align to plot top",
        )
        self.assertEqual(
            window.additional_guide_text_vertical.itemText(
                window.additional_guide_text_vertical.findData("below")
            ),
            "Below X axis",
        )

        with mock.patch.object(window, "schedule_render"):
            window.chart_type.setCurrentText("Violin")

        self.assertEqual(
            [
                window.additional_guide_text_side.itemData(index)
                for index in range(window.additional_guide_text_side.count())
            ],
            ["plot_left", "plot_right", "left"],
        )
        self.assertEqual(
            [
                window.additional_guide_text_vertical.itemData(index)
                for index in range(
                    window.additional_guide_text_vertical.count()
                )
            ],
            ["aligned", "above", "below"],
        )

    def test_groups_orientation_fallback_preserves_hidden_edge_positions(self):
        window = self.make_window(initial_render=False)
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(5.0),
                "text": "Persistent edge",
                "text_side": "plot_right",
                "vertical_position": "plot_top",
            }
        ]
        window.handle_plot_object_selection("primary_axis")

        # Box/Violin renders the X-only top token as its semantic "above"
        # fallback, while retaining the saved token through unrelated edits.
        self.assertEqual(
            window.additional_guide_text_side.currentData(),
            "plot_right",
        )
        self.assertEqual(
            window.additional_guide_text_vertical.currentData(),
            "above",
        )
        window.additional_guide_line.setChecked(True)
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0][
                "vertical_position"
            ],
            "plot_top",
        )

        with mock.patch.object(window, "schedule_render"):
            window.chart_type.setCurrentText("Ridge")
        window.handle_plot_object_selection("primary_axis")

        # Ridge renders the Y-only right-edge token as "right" and likewise
        # preserves it when a different field is edited.
        self.assertEqual(
            window.additional_guide_text_side.currentData(),
            "right",
        )
        self.assertEqual(
            window.additional_guide_text_vertical.currentData(),
            "plot_top",
        )
        window.additional_guide_label_background.setChecked(True)
        guide = window.settings.additional_primary_axis_guides[0]
        self.assertEqual(guide["text_side"], "plot_right")
        self.assertEqual(guide["vertical_position"], "plot_top")

        with mock.patch.object(window, "schedule_render"):
            window.chart_type.setCurrentText("Violin")
        self.assertEqual(
            window.additional_guide_text_side.currentData(),
            "plot_right",
        )
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0][
                "vertical_position"
            ],
            "plot_top",
        )

    def test_removed_position_choices_display_safely_without_overwriting(self):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        window.settings.additional_x_axis_guides = [
            {
                **main_window.default_additional_guide(2.5),
                "vertical_position": "above",
            }
        ]
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(7.5),
                "text_side": "right",
            }
        ]

        window.handle_plot_object_selection("category_axis")
        self.assertEqual(
            window.additional_guide_text_vertical.currentData(),
            "plot_bottom",
        )
        window.additional_guide_label_background.setChecked(True)
        self.assertEqual(
            window.settings.additional_x_axis_guides[0][
                "vertical_position"
            ],
            "above",
        )

        window.handle_plot_object_selection("primary_axis")
        self.assertEqual(
            window.additional_guide_text_side.currentData(),
            "plot_left",
        )
        window.additional_guide_label_background.setChecked(True)
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0]["text_side"],
            "right",
        )

    def test_xy_axis_context_switches_edge_options_without_mutating_guides(self):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        window.settings.additional_x_axis_guides = [
            {
                **main_window.default_additional_guide(2.5),
                "text": "X edge",
                "vertical_position": "plot_top",
            }
        ]
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(7.5),
                "text": "Y edge",
                "text_side": "plot_right",
            }
        ]
        original_x_guides = [
            dict(guide) for guide in window.settings.additional_x_axis_guides
        ]
        original_y_guides = [
            dict(guide)
            for guide in window.settings.additional_primary_axis_guides
        ]

        window.handle_plot_object_selection("category_axis")
        self.assertEqual(
            [
                window.additional_guide_text_side.itemData(index)
                for index in range(window.additional_guide_text_side.count())
            ],
            ["left", "center", "right"],
        )
        self.assertEqual(
            window.additional_guide_text_vertical.currentData(),
            "plot_top",
        )

        window.handle_plot_object_selection(None)
        self.assertTrue(window.additional_guides_x_axis_radio.isChecked())
        window.additional_guides_y_axis_radio.click()

        self.assertEqual(
            [
                window.additional_guide_text_side.itemData(index)
                for index in range(window.additional_guide_text_side.count())
            ],
            ["plot_left", "plot_right", "left"],
        )
        self.assertEqual(
            [
                window.additional_guide_text_vertical.itemData(index)
                for index in range(
                    window.additional_guide_text_vertical.count()
                )
            ],
            ["aligned", "above", "below"],
        )
        self.assertEqual(
            window.additional_guide_text_side.currentData(),
            "plot_right",
        )

        window.additional_guides_x_axis_radio.click()

        self.assertEqual(
            window.additional_guide_text_vertical.currentData(),
            "plot_top",
        )
        self.assertEqual(
            window.settings.additional_x_axis_guides,
            original_x_guides,
        )
        self.assertEqual(
            window.settings.additional_primary_axis_guides,
            original_y_guides,
        )

    def test_top_toolbar_context_slots_follow_the_selected_chart_element(self):
        window = self.make_window(initial_render=False)
        contextual_widgets = (
            window.ui.lineValueSizeLabel,
            window.line_value_font_size,
            window.ui.statTableSizeLabel,
            window.stat_table_font_size,
            window.additional_guide_font_size_label,
            window.additional_guide_font_size,
        )
        self.assertTrue(all(widget.isHidden() for widget in contextual_widgets))

        window.handle_plot_object_selection("line_overlay")

        self.assertFalse(window.ui.lineValueSizeLabel.isHidden())
        self.assertFalse(window.line_value_font_size.isHidden())
        self.assertTrue(window.ui.statTableSizeLabel.isHidden())
        self.assertTrue(window.additional_guide_font_size.isHidden())

        window.handle_plot_object_selection("stats_table")

        self.assertTrue(window.line_value_font_size.isHidden())
        self.assertFalse(window.ui.statTableSizeLabel.isHidden())
        self.assertFalse(window.stat_table_font_size.isHidden())
        self.assertTrue(window.additional_guide_font_size.isHidden())

        window.handle_plot_object_selection("primary_axis")

        self.assertTrue(window.line_value_font_size.isHidden())
        self.assertTrue(window.stat_table_font_size.isHidden())
        self.assertFalse(window.additional_guide_font_size_label.isHidden())
        self.assertFalse(window.additional_guide_font_size.isHidden())

        layout = window.ui.topToolbarLayout
        self.assertEqual(
            layout.getItemPosition(layout.indexOf(window.line_value_font_size)),
            (3, 4, 1, 1),
        )
        self.assertEqual(
            layout.getItemPosition(
                layout.indexOf(window.additional_guide_font_size)
            ),
            (3, 4, 1, 1),
        )
        self.assertEqual(
            layout.getItemPosition(layout.indexOf(window.stat_table_font_size)),
            (3, 6, 1, 1),
        )

        window.resize(1800, 900)
        window.show()
        self.qapp.processEvents()
        chart_module_positions = []
        for object_kind in (
            "line_overlay",
            "primary_axis",
            "stats_table",
            None,
        ):
            window.handle_plot_object_selection(object_kind)
            self.qapp.processEvents()
            chart_module_positions.append(window.ui.chartToolbarLabel.x())
        self.assertEqual(len(set(chart_module_positions)), 1)

        window.handle_plot_object_selection(None)
        self.assertTrue(all(widget.isHidden() for widget in contextual_widgets))

    def test_groups_only_exposes_the_editor_for_the_value_axis(self):
        window = self.make_window(initial_render=False)

        self.assertFalse(window.ui.additionalGuidesGroup.isHidden())
        self.assertTrue(window.additional_guide_font_size.isHidden())
        self.assertIn(
            "Value axis",
            window.ui.additionalGuidesAxisLabel.text(),
        )

        window.handle_plot_object_selection("category_axis")

        self.assertTrue(window.ui.additionalGuidesGroup.isHidden())
        self.assertTrue(window.additional_guide_font_size.isHidden())

        window.handle_plot_object_selection("primary_axis")

        self.assertFalse(window.ui.additionalGuidesGroup.isHidden())
        self.assertFalse(window.additional_guide_font_size.isHidden())
        self.assertEqual(
            {
                group
                for group in window._inspector_groups()
                if not group.isHidden()
            },
            {
                window.ui.primaryAxisGroup,
                window.ui.additionalGuidesGroup,
                window.ui.axesAppearanceGroup,
            },
        )

        window.handle_plot_object_selection("secondary_axis")

        self.assertTrue(window.ui.additionalGuidesGroup.isHidden())
        self.assertTrue(window.additional_guide_font_size.isHidden())

        window.handle_plot_object_selection(None)

        self.assertFalse(window.ui.additionalGuidesGroup.isHidden())
        self.assertTrue(window.additional_guide_font_size.isHidden())

    def test_xy_show_all_keeps_the_last_additional_axis_editor_visible(self):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        self.assertFalse(window.ui.additionalGuidesGroup.isHidden())
        self.assertIn("Y axis", window.ui.additionalGuidesAxisLabel.text())
        self.assertTrue(window.additional_guide_font_size.isHidden())
        self.assertFalse(window.additional_guides_axis_selector.isHidden())
        self.assertTrue(window.additional_guides_y_axis_radio.isChecked())

        window.handle_plot_object_selection("category_axis")
        self.assertIn("X axis", window.ui.additionalGuidesAxisLabel.text())
        self.assertFalse(window.additional_guide_font_size.isHidden())
        self.assertTrue(window.additional_guides_axis_selector.isHidden())

        window.handle_plot_object_selection(None)
        self.assertFalse(window.ui.additionalGuidesGroup.isHidden())
        self.assertFalse(window.additional_guides_axis_selector.isHidden())
        self.assertTrue(window.additional_guides_x_axis_radio.isChecked())
        self.assertIn("X axis", window.ui.additionalGuidesAxisLabel.text())
        self.assertEqual(
            window.additional_guides_table.horizontalHeaderItem(0).text(),
            "At X",
        )
        self.assertTrue(window.additional_guide_font_size.isHidden())

        window.canvas._selected_object_kind = "additional_grid_line"
        window.canvas._selected_additional_guide_axis_key = "x"
        window.canvas._selected_additional_guide_index = 0

        window.additional_guides_y_axis_radio.click()

        self.assertIsNone(window.canvas.selected_additional_guide())
        self.assertTrue(window.additional_guides_y_axis_radio.isChecked())
        self.assertIn("Y axis", window.ui.additionalGuidesAxisLabel.text())
        self.assertEqual(
            window.additional_guides_table.horizontalHeaderItem(0).text(),
            "At Y",
        )

        window.handle_plot_object_selection("primary_axis")
        self.assertTrue(window.additional_guides_axis_selector.isHidden())

    def test_add_edit_two_line_limit_and_delete_round_trip_through_controls(self):
        window = self.make_window(initial_render=False)
        window.handle_plot_object_selection("primary_axis")

        with mock.patch.object(window, "schedule_render") as schedule_render:
            window.additional_guide_add_button.click()

            self.assertEqual(len(window.settings.additional_primary_axis_guides), 1)
            self.assertEqual(window.additional_guides_table.rowCount(), 1)
            self.assert_new_guide_defaults(
                window,
                window.settings.additional_primary_axis_guides[0],
            )

            window.additional_guide_value.setValue(25.0)
            window.additional_guide_line.setChecked(True)
            window.additional_guide_show_value.setChecked(True)
            window.additional_guide_label_background.setChecked(True)
            window.additional_guide_text.setPlainText(
                "Baseline\nSecond line\nIgnored line"
            )
            window.additional_guide_text_side.setCurrentIndex(
                window.additional_guide_text_side.findData("left")
            )
            window.additional_guide_text_vertical.setCurrentIndex(
                window.additional_guide_text_vertical.findData("above")
            )

            guide = window.settings.additional_primary_axis_guides[0]
            self.assertEqual(guide["value"], 25.0)
            self.assertTrue(guide["show_line"])
            self.assertTrue(guide["show_value_with_text"])
            self.assertTrue(guide["show_label_background"])
            self.assertEqual(guide["text"], "Baseline\nSecond line")
            self.assertEqual(guide["text_side"], "left")
            self.assertEqual(guide["vertical_position"], "above")
            self.assertEqual(
                window.additional_guide_text.toPlainText(),
                "Baseline\nSecond line",
            )
            self.assertEqual(
                window.additional_guides_table.item(0, 4).text(),
                "Baseline / Second line",
            )
            self.assertTrue(schedule_render.called)

            window.additional_guide_line_width.setValue(1.8)
            self.assertEqual(window.settings.additional_guide_line_width, 1.8)

            window.additional_guide_delete_button.click()

        self.assertEqual(window.settings.additional_primary_axis_guides, [])
        self.assertEqual(window.additional_guides_table.rowCount(), 0)
        self.assertFalse(window.additional_guide_delete_button.isEnabled())

    def test_xy_x_and_y_axes_store_separate_guide_lists(self):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        window.handle_plot_object_selection("category_axis")
        window.additional_guide_add_button.click()
        window.additional_guide_value.setValue(2.5)

        self.assert_new_guide_defaults(
            window,
            window.settings.additional_x_axis_guides[0],
            dimension="x",
        )
        self.assertEqual(
            window.settings.additional_x_axis_guides[0]["value"],
            2.5,
        )
        self.assertEqual(
            window.settings.additional_x_axis_guides[0]["color_index"],
            0,
        )
        self.assertEqual(window.settings.additional_primary_axis_guides, [])
        self.assertEqual(
            window.additional_guides_table.horizontalHeaderItem(0).text(),
            "At X",
        )

        window.handle_plot_object_selection("primary_axis")
        window.additional_guide_add_button.click()
        window.additional_guide_value.setValue(7.5)

        self.assert_new_guide_defaults(
            window,
            window.settings.additional_primary_axis_guides[0],
        )
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0]["value"],
            7.5,
        )
        self.assertEqual(
            window.settings.additional_x_axis_guides[0]["value"],
            2.5,
        )
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0][
                "color_index"
            ],
            1,
        )
        self.assertEqual(
            window.additional_guides_table.horizontalHeaderItem(0).text(),
            "At Y",
        )

    def test_new_guide_with_custom_text_draws_every_default_component(self):
        window = self.make_window(initial_render=False)
        window.handle_plot_object_selection("primary_axis")

        with mock.patch.object(window, "schedule_render"):
            window.additional_guide_add_button.click()
            window.additional_guide_value.setValue(5.123)
            window.additional_guide_text.setPlainText("Target threshold")

        guide = window.settings.additional_primary_axis_guides[0]
        self.assert_new_guide_defaults(window, guide)
        self.assertEqual(guide["text"], "Target threshold")

        window.settings.show_stat_table = False
        window.canvas.render(window.table.dataframe(), window.settings)

        artist_gids = {
            artist.get_gid()
            for artist in window.canvas.figure.axes[0].get_children()
        }
        self.assertTrue(
            {
                "additional-grid-line",
                "additional-tick",
                "additional-tick-value",
                "additional-tick-label",
            }.issubset(artist_gids)
        )

    def test_context_font_size_participates_in_global_font_steps(self):
        window = self.make_window(initial_render=False)
        self.assertTrue(window.additional_guide_font_size.isHidden())
        self.assertEqual(window.additional_guide_font_size.value(), 10)

        window.increase_all_fonts_button.click()

        self.assertEqual(window.additional_guide_font_size.value(), 11)
        self.assertEqual(window.settings.additional_guide_font_size, 11)

        window.handle_plot_object_selection("primary_axis")
        self.assertFalse(window.additional_guide_font_size.isHidden())

        window.additional_guide_font_size.setValue(14)

        self.assertEqual(window.settings.additional_guide_font_size, 14)

    def test_sidebar_color_updates_only_the_selected_guide(self):
        window = self.make_window(initial_render=False)
        window.handle_plot_object_selection("primary_axis")

        with mock.patch.object(window, "schedule_render") as schedule_render:
            window.additional_guide_add_button.click()
            window.additional_guide_add_button.click()

            self.assertEqual(window.additional_guides_table.columnCount(), 5)
            self.assertEqual(
                [
                    guide["color_index"]
                    for guide in window.settings.additional_primary_axis_guides
                ],
                [0, 1],
            )
            self.assertFalse(window.preset.isHidden())
            self.assertFalse(window.edit_group_colors_button.isHidden())
            self.assertFalse(window.ui.toolbarPaletteLabel.pixmap().isNull())
            self.assertEqual(window.ui.toolbarPaletteLabel.accessibleName(), "Palette")
            self.assertEqual(window.additional_guide_color.count(), 10)

            color_slot = min(3, window.additional_guide_color.count() - 1)
            window.additional_guide_color.setCurrentIndex(color_slot)
            window.additional_guide_text_color.setCurrentIndex(
                window.additional_guide_text_color.findData("match_line")
            )

            self.assertEqual(
                window.settings.additional_primary_axis_guides[1]["color_index"],
                color_slot,
            )
            self.assertEqual(
                window.settings.additional_primary_axis_guides[1][
                    "text_color_mode"
                ],
                "match_line",
            )
            window.additional_guide_value.setValue(12.5)
            self.assertEqual(
                window.settings.additional_primary_axis_guides[1][
                    "text_color_mode"
                ],
                "match_line",
            )
            self.assertFalse(
                window.additional_guides_table.item(1, 3).icon().isNull()
            )
            original_chart_palette = window.settings.preset

        self.assertEqual(window.settings.preset, original_chart_palette)
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0]["color_index"],
            0,
        )
        self.assertEqual(
            window.settings.additional_primary_axis_guides[1]["color_index"],
            color_slot,
        )
        self.assertEqual(
            window.settings.additional_primary_axis_guides[1][
                "text_color_mode"
            ],
            "match_line",
        )
        self.assertTrue(schedule_render.called)

    def test_show_all_table_click_keeps_the_original_palette_toolbar(self):
        window = self.make_window(initial_render=False)
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(10.0),
                "show_line": True,
            }
        ]
        window.handle_plot_object_selection(None)
        window.resize(1500, 900)
        window.show()
        window.ui.controlsScroll.ensureWidgetVisible(
            window.ui.additionalGuidesGroup,
            0,
            8,
        )
        self.qapp.processEvents()

        self.assertFalse(window.ui.toolbarPaletteLabel.pixmap().isNull())
        self.assertEqual(window.ui.toolbarPaletteLabel.accessibleName(), "Palette")
        self.assertFalse(window.preset.isHidden())
        self.assertFalse(window.edit_group_colors_button.isHidden())
        item = window.additional_guides_table.item(0, 0)
        self.assertIsNotNone(item)
        QTest.mouseClick(
            window.additional_guides_table.viewport(),
            Qt.MouseButton.LeftButton,
            pos=window.additional_guides_table.visualItemRect(item).center(),
        )
        self.qapp.processEvents()

        self.assertFalse(window.ui.toolbarPaletteLabel.pixmap().isNull())
        self.assertEqual(window.ui.toolbarPaletteLabel.accessibleName(), "Palette")
        self.assertFalse(window.preset.isHidden())
        self.assertFalse(window.edit_group_colors_button.isHidden())
        self.assertFalse(hasattr(window.ui, "additionalGuidePaletteCombo"))
        self.assertFalse(hasattr(window.ui, "additionalGuideColorsButton"))

    def test_groups_colors_dialog_opens_with_only_guides_and_cancel_restores_preview(self):
        window = self.make_window(initial_render=False)
        window.settings.additional_guide_palette = "Viridis"
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(5.0),
                "show_line": True,
                "color_index": 2,
            }
        ]
        original = window._group_color_selection()
        preview_selection = main_window.GroupColorSelection(
            preset=original.preset,
            custom_colors=dict(original.custom_colors),
            overlay_palette=original.overlay_palette,
            overlay_colors=dict(original.overlay_colors),
            guide_palette="Presentation",
            guide_color_indices={"additional-guide:primary:0": 4},
        )

        def execute(
            _parent,
            _settings,
            groups,
            _overlays,
            apply_preview,
            _polish,
            **kwargs,
        ):
            self.assertEqual(groups, [])
            self.assertEqual(
                kwargs["guide_items"],
                [
                    (
                        "additional-guide:primary:0",
                        "Additional grid line · Value axis: 5",
                        2,
                        0,
                    )
                ],
            )
            apply_preview(preview_selection)
            self.assertEqual(
                window.settings.additional_guide_palette,
                "Presentation",
            )
            self.assertEqual(
                window.settings.additional_primary_axis_guides[0][
                    "color_index"
                ],
                4,
            )
            return None

        with mock.patch.object(
            window,
            "_group_user_keys",
            return_value=[],
        ), mock.patch.object(
            window,
            "_group_item_labels",
            return_value={},
        ), mock.patch.object(
            window,
            "_group_user_names",
            return_value=[],
        ), mock.patch.object(
            main_window,
            "run_group_colors_dialog",
            side_effect=execute,
        ) as dialog, mock.patch.object(window, "render") as render:
            window.edit_group_colors()

        dialog.assert_called_once()
        render.assert_called_once_with()
        self.assertEqual(window.settings.additional_guide_palette, "Viridis")
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0]["color_index"],
            2,
        )

    def test_xy_colors_dialog_opens_with_only_guides_and_applies_shared_palette(self):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        window.settings.additional_guide_palette = "Viridis"
        window.settings.additional_x_axis_guides = [
            {
                **main_window.default_additional_guide(1.5),
                "show_line": True,
                "color_index": 2,
            }
        ]
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(7.5),
                "show_line": True,
                "color_index": 5,
            }
        ]
        original = window._xy_color_selection()
        accepted = main_window.GroupColorSelection(
            preset=original.preset,
            custom_colors={},
            overlay_palette=original.overlay_palette,
            overlay_colors={},
            guide_palette="Presentation",
            guide_color_indices={
                "additional-guide:x:0": 3,
                "additional-guide:primary:0": 4,
            },
        )

        def execute(
            _parent,
            _settings,
            series,
            overlays,
            apply_preview,
            _polish,
            **kwargs,
        ):
            self.assertEqual(series, [])
            self.assertEqual(overlays, [])
            self.assertEqual(
                [item[0] for item in kwargs["guide_items"]],
                [
                    "additional-guide:x:0",
                    "additional-guide:primary:0",
                ],
            )
            self.assertEqual(
                [item[2] for item in kwargs["guide_items"]],
                [2, 5],
            )
            apply_preview(accepted)
            return accepted

        with mock.patch.object(
            window,
            "_xy_user_series",
            return_value=[],
        ), mock.patch.object(
            window,
            "_xy_series_labels",
            return_value={},
        ), mock.patch.object(
            main_window,
            "run_group_colors_dialog",
            side_effect=execute,
        ) as dialog, mock.patch.object(window, "render") as render:
            window.edit_group_colors()

        dialog.assert_called_once()
        render.assert_called_once_with()
        self.assertEqual(
            window.settings.additional_guide_palette,
            "Presentation",
        )
        self.assertEqual(
            window.settings.additional_x_axis_guides[0]["color_index"],
            3,
        )
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0]["color_index"],
            4,
        )

    def test_xy_colors_dialog_cancel_restores_both_guide_axes(self):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        window.settings.additional_guide_palette = "Viridis"
        window.settings.additional_x_axis_guides = [
            {
                **main_window.default_additional_guide(1.5),
                "color_index": 1,
            }
        ]
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(7.5),
                "color_index": 2,
            }
        ]
        original = window._xy_color_selection()
        preview_selection = main_window.GroupColorSelection(
            preset=original.preset,
            custom_colors=dict(original.custom_colors),
            overlay_palette=original.overlay_palette,
            overlay_colors={},
            guide_palette="Presentation",
            guide_color_indices={
                "additional-guide:x:0": 4,
                "additional-guide:primary:0": 5,
            },
        )

        def execute(
            _parent,
            _settings,
            _series,
            _overlays,
            apply_preview,
            _polish,
            **_kwargs,
        ):
            apply_preview(preview_selection)
            return None

        with mock.patch.object(
            window,
            "_xy_user_series",
            return_value=[],
        ), mock.patch.object(
            window,
            "_xy_series_labels",
            return_value={},
        ), mock.patch.object(
            main_window,
            "run_group_colors_dialog",
            side_effect=execute,
        ), mock.patch.object(window, "render") as render:
            window.edit_group_colors()

        render.assert_called_once_with()
        self.assertEqual(window.settings.additional_guide_palette, "Viridis")
        self.assertEqual(
            window.settings.additional_x_axis_guides[0]["color_index"],
            1,
        )
        self.assertEqual(
            window.settings.additional_primary_axis_guides[0]["color_index"],
            2,
        )

    def test_clicking_a_grid_line_selects_its_axis_and_table_row(self):
        window = self.make_window(initial_render=False)
        window.settings.show_stat_table = False
        window.settings.auto_y_range = False
        window.settings.y_min = 0.0
        window.settings.y_max = 30.0
        window.settings.additional_primary_axis_guides = [
            {
                **main_window.default_additional_guide(value),
                "show_line": True,
                "color_index": index,
            }
            for index, value in enumerate((10.0, 25.0))
        ]
        window.canvas.render(window.table.dataframe(), window.settings)
        target = next(
            target
            for target in window.canvas._interaction_targets
            if target.get("kind") == "additional_grid_line"
            and target.get("guide_axis_key") == "primary"
            and target.get("guide_index") == 1
        )
        display_path = target["artist"].get_path().transformed(
            target["artist"].get_transform()
        )
        vertices = display_path.vertices
        event = SimpleNamespace(
            x=float((vertices[0, 0] + vertices[-1, 0]) / 2.0),
            y=float((vertices[0, 1] + vertices[-1, 1]) / 2.0),
            button=1,
            dblclick=False,
        )

        window.canvas._handle_plot_click(event)

        self.assertEqual(window.canvas.selected_additional_guide(), ("primary", 1))
        self.assertEqual(window._selected_plot_object_kind, "additional_grid_line")
        self.assertEqual(window.additional_guides_table.currentRow(), 1)
        self.assertEqual(window.additional_guide_color.currentData(), 1)
        self.assertEqual(
            {
                group
                for group in window._inspector_groups()
                if not group.isHidden()
            },
            {window.ui.additionalGuidesGroup},
        )

        window.additional_guides_table.selectRow(0)
        self.qapp.processEvents()

        self.assertEqual(
            window.canvas.selected_additional_guide(),
            ("primary", 0),
        )


if __name__ == "__main__":
    import unittest

    unittest.main()
