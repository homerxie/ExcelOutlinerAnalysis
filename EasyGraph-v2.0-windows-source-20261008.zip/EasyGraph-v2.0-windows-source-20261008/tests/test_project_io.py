import json
import os
import pathlib
import subprocess
import sys
import tempfile
from unittest import mock
import zipfile
from dataclasses import asdict

import pandas as pd

from tests.easygraph_case import ROOT, EasyGraphTestCase
from easygraph import project_io
from easygraph.analysis_results import AnalysisSettings, DESCRIPTIVE_STATISTICS
from easygraph.data import prepare_plot_frames
from easygraph.grouping import GroupingSettings
from easygraph.overlay_series import line_overlay_series
from easygraph.settings import ChartSettings
from easygraph.workbook import (
    SHEET_MODE_GROUPS,
    SHEET_MODE_XY,
    SheetDocument,
    WorkbookDocument,
)
from easygraph.xy_series import XYSeriesSpec, XYSharedTableSpec, XYSettings


class ProjectIOTests(EasyGraphTestCase):

    def test_project_fsync_uses_writable_descriptor_for_windows(self):
        opened_temporary_modes = []
        real_path_open = pathlib.Path.open

        def record_path_open(path, mode="r", *args, **kwargs):
            if path.suffix == ".tmp":
                opened_temporary_modes.append(mode)
            return real_path_open(path, mode, *args, **kwargs)

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "windows-compatible.eg"
            with mock.patch.object(pathlib.Path, "open", new=record_path_open):
                project_io.write_project(path, self.df, self.settings)

        self.assertEqual(opened_temporary_modes, ["r+b"])

    def test_failed_project_write_preserves_existing_file_atomically(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "existing.eg"
            project_io.write_project(path, self.df, self.settings)
            original = path.read_bytes()
            with mock.patch.object(
                project_io.zipfile,
                "ZipFile",
                side_effect=OSError("interrupted write"),
            ):
                with self.assertRaisesRegex(OSError, "interrupted write"):
                    project_io.write_project(path, self.df, self.settings)
            self.assertEqual(path.read_bytes(), original)
            self.assertEqual(list(path.parent.glob(f".{path.name}.*.tmp")), [])

    def test_chart_settings_codec_rejects_invalid_and_unknown_fields(self):
        with self.assertRaisesRegex(ValueError, r"^Chart settings must be a dictionary\.$"):
            project_io.chart_settings_from_dict([])
        with self.assertRaisesRegex(
            ValueError,
            r"^Unknown ChartSettings fields: 1$",
        ):
            project_io.chart_settings_from_dict({1: "bad"})
        with self.assertRaisesRegex(
            ValueError,
            r"^Unknown ChartSettings fields: legacy_show_line_overlay, retired_legend_mode$",
        ):
            project_io.chart_settings_from_dict({
                "retired_legend_mode": True,
                "legacy_show_line_overlay": False,
            })

    def test_project_io_api_is_exact(self):
        self.assertEqual(
            project_io.__all__,
            [
                "PROJECT_APP_NAME",
                "PROJECT_DATA_FILE",
                "PROJECT_SHEETS_DIRECTORY",
                "PROJECT_SHEETS_FILE",
                "PROJECT_MANIFEST_FILE",
                "PROJECT_SETTINGS_FILE",
                "PROJECT_VERSION",
                "chart_settings_from_dict",
                "project_manifest",
                "project_path_with_suffix",
                "read_project",
                "read_workbook_project",
                "write_project",
                "xy_settings_from_dict",
            ],
        )

    def test_project_path_and_manifest_helpers_own_project_archive_policy(self):
        self.assertEqual(project_io.project_path_with_suffix(pathlib.Path("plot")), pathlib.Path("plot.eg"))
        self.assertEqual(project_io.project_path_with_suffix(pathlib.Path("plot.EG")), pathlib.Path("plot.EG"))
        self.assertEqual(project_io.project_manifest(), {"version": 5, "app": "EasyGraph"})

    def test_read_project_reports_missing_archive_members(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "missing-settings.eg"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("data.csv", "A\n1\n")

            with self.assertRaisesRegex(ValueError, r"^Project archive missing required file: settings\.json$"):
                project_io.read_project(path)

    def test_project_io_contract_is_strict_with_and_without_optimization(self):
        code = """
import sys
from easygraph import project_io

settings = project_io.chart_settings_from_dict({"legend_columns": 1})
if settings.legend_auto_width is not True:
    raise SystemExit("missing legend_auto_width did not use the current default")
try:
    project_io.chart_settings_from_dict({"removed_field": True})
except ValueError as error:
    if str(error) != "Unknown ChartSettings fields: removed_field":
        raise SystemExit(f"unexpected error: {error}")
else:
    raise SystemExit("unknown field was accepted")
for forbidden in ("PySide6", "matplotlib", "seaborn", "scipy"):
    if any(
        name == forbidden or name.startswith(forbidden + ".")
        for name in sys.modules
    ):
        raise SystemExit(f"forbidden dependency loaded: {forbidden}")
"""
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(ROOT / "src")
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )

    def test_project_roundtrip_preserves_new_settings(self):
        self.settings.jitter_mode = "Quasirandom"
        self.settings.outlier_effect = "Exclude from distribution"
        self.settings.box_whisker_mode = "Min-Max"
        self.settings.group_order = "Mean descending"
        self.settings.manual_group_order = ["High dose", "Control", "Low dose"]
        self.settings.group_hidden = ["Low dose"]
        self.settings.transparent_background = True
        self.settings.show_line_overlay = True
        self.settings.line_overlay_stat = "Mean"
        self.settings.line_overlay_width = 2.4
        self.settings.line_overlay_style = "Dashed"
        self.settings.line_overlay_point_size = 7.5
        self.settings.show_line_values = True
        self.settings.line_value_position = "Below"
        self.settings.custom_line_value_position = "Left"
        self.settings.secondary_y_label = "Rate"
        self.settings.custom_overlay_secondary_axis = True
        self.settings.custom_overlay_hidden = [1]
        self.settings.secondary_auto_y_range = False
        self.settings.secondary_y_min = 40.0
        self.settings.secondary_y_max = 80.0
        self.settings.split_secondary_axis = True
        self.settings.secondary_axis_split_ratio = 0.42
        self.settings.line_value_scientific = True
        self.settings.line_value_decimals = 4
        self.settings.line_value_font_size = 11
        self.settings.custom_colors = {"High dose": "#336699"}
        self.settings.custom_overlay_palette = "Dark Slide"
        self.settings.custom_overlay_colors = {"custom:0": "#884466"}
        self.settings.custom_overlay_styles = {"custom:0": "Dash-dot"}
        self.settings.x_tick_rotation = 65
        self.settings.preset = "Tableau 10"
        self.settings.point_size = 5.5
        self.settings.point_alpha = 0.42
        self.settings.axis_line_width = 1.8
        self.settings.show_grid = False
        self.settings.auto_y_range = False
        self.settings.y_min = -1.0
        self.settings.y_max = 12.0
        self.settings.box_width = 0.72
        self.settings.violin_width = 0.66
        self.settings.kde_bandwidth = 1.4
        self.settings.ridge_overlap = 0.82
        self.settings.fill_alpha = 0.51
        self.settings.show_stat_min = False
        self.settings.show_stat_sem = False
        self.settings.show_stat_header = True
        self.settings.stat_table_font_size = 10
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "roundtrip.eg"
            project_io.write_project(path, self.df, self.settings)
            roundtrip_df, roundtrip_settings = project_io.read_project(path)

        self.assertEqual(roundtrip_df.shape, self.df.shape)
        ids_by_name = dict(zip(roundtrip_df.columns, roundtrip_df.attrs["group_column_ids"]))
        expected = asdict(self.settings)
        expected["manual_group_order"] = [ids_by_name[name] for name in self.settings.manual_group_order]
        expected["group_hidden"] = [ids_by_name["Low dose"]]
        expected["custom_colors"] = {ids_by_name["High dose"]: "#336699"}
        self.assertEqual(asdict(roundtrip_settings), expected)

    def test_compatibility_read_write_preserves_group_ids_filter_and_independent_overlays(self):
        grouping = GroupingSettings(parents=[{"id": "wt", "name": "WT", "column_ids": ["a"]}, {"id": "ko", "name": "KO", "column_ids": ["b"]}], shared_subgroups=True, subgroup_ids={"a": "control", "b": "control"})
        settings = ChartSettings(group_hidden=["a"], custom_colors={"a": "#112233", "b": "#445566"}, line_overlay_stat="None", extra_custom_overlay=True, custom_overlay_series=[{"name": "Target", "values": {"a": "5", "b": "50"}}])
        sheet = SheetDocument(name="Groups", dataframe=pd.DataFrame([[1, 10], [3, 30]], columns=["Control", "Control"]), column_ids=["a", "b"], grouping=grouping, settings=settings)
        with tempfile.TemporaryDirectory() as directory:
            first = pathlib.Path(directory) / "first.eg"
            second = pathlib.Path(directory) / "second.eg"
            project_io.write_project(first, WorkbookDocument([sheet]))
            frame, loaded_settings = project_io.read_project(first)
            project_io.write_project(second, frame, loaded_settings)
            frame, loaded_settings = project_io.read_project(second)
            reread = project_io.read_workbook_project(second).active_sheet
        self.assertEqual(frame.attrs["group_column_ids"], ["a", "b"])
        self.assertEqual(frame.attrs["grouping"], asdict(grouping))
        self.assertEqual(reread.column_ids, ["a", "b"])
        self.assertEqual(reread.grouping, grouping)
        self.assertEqual(asdict(loaded_settings), asdict(settings))
        frames = prepare_plot_frames(frame, loaded_settings)
        self.assertEqual(frames.visible["group"].tolist(), ["b", "b"])
        self.assertEqual(frames.visible["value"].tolist(), [10, 30])
        self.assertEqual(frames.visible.attrs["group_keys"], ["b"])
        self.assertEqual(frames.visible.attrs["group_labels"], {"a": "Control", "b": "Control"})
        self.assertEqual(line_overlay_series(frames.visible, loaded_settings)[0]["values"], [50])

    def test_compatibility_reader_migrates_legacy_label_overlays_for_duplicate_columns(self):
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / "legacy.eg"
            settings = ChartSettings(line_overlay_stat="None", extra_custom_overlay=True, custom_overlay_series=[{"name": "Target", "values": {"A": "5"}}])
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("data.csv", "A,A\n1,10\n3,30\n")
                archive.writestr("settings.json", json.dumps(asdict(settings)))
            frame, loaded_settings = project_io.read_project(path)
        keys = frame.attrs["group_column_ids"]
        self.assertEqual(len(set(keys)), 2)
        self.assertEqual(loaded_settings.custom_overlay_series[0]["values"], {key: "5" for key in keys})
        frames = prepare_plot_frames(frame, loaded_settings)
        self.assertEqual(line_overlay_series(frames.visible, loaded_settings)[0]["values"], [5, 5])

    def test_compatibility_reader_keeps_xy_dataframe_free_of_groups_metadata(self):
        sheet = SheetDocument(name="XY", dataframe=pd.DataFrame({"X": [1], "Y": [2]}), mode=SHEET_MODE_XY, column_ids=["x", "y"], settings=ChartSettings(chart_type="Scatter"))
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / "xy.eg"
            project_io.write_project(path, WorkbookDocument([sheet]))
            frame, settings = project_io.read_project(path)
        pd.testing.assert_frame_equal(frame, sheet.dataframe)
        self.assertNotIn("group_column_ids", frame.attrs)
        self.assertNotIn("grouping", frame.attrs)
        self.assertEqual(asdict(settings), asdict(sheet.settings))

    def test_multisheet_project_roundtrip_preserves_order_names_active_sheet_and_settings(self):
        first = SheetDocument(
            id="first-sheet",
            name="Control",
            dataframe=pd.DataFrame({"A": [1, 2]}),
            settings=ChartSettings(title="Control chart"),
            analysis_settings=AnalysisSettings(
                visible_statistics=["Mean", "Sample"]
            ),
        )
        second = SheetDocument(
            id="second-sheet",
            name="剂量反应",
            dataframe=pd.DataFrame({"Dose": [3, 4], "Response": [5, 6]}),
            settings=ChartSettings(title="Dose response", show_grid=False),
            analysis_settings=AnalysisSettings(
                visible_statistics=["Median", "SD"]
            ),
        )
        workbook = WorkbookDocument([first, second], second.id)

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "workbook.eg"
            project_io.write_project(path, workbook)
            loaded = project_io.read_workbook_project(path)
            with zipfile.ZipFile(path) as archive:
                members = set(archive.namelist())
                workbook_index = json.loads(archive.read("sheets.json"))

        self.assertEqual([sheet.id for sheet in loaded.sheets], [first.id, second.id])
        self.assertEqual([sheet.name for sheet in loaded.sheets], ["Control", "剂量反应"])
        self.assertEqual(loaded.active_sheet_id, second.id)
        pd.testing.assert_frame_equal(loaded.sheets[0].dataframe, first.dataframe)
        pd.testing.assert_frame_equal(loaded.sheets[1].dataframe, second.dataframe)
        self.assertEqual(asdict(loaded.sheets[0].settings), asdict(first.settings))
        self.assertEqual(asdict(loaded.sheets[1].settings), asdict(second.settings))
        self.assertEqual(
            loaded.sheets[0].analysis_settings.visible_statistics,
            ["Mean", "Sample"],
        )
        self.assertEqual(
            loaded.sheets[1].analysis_settings.visible_statistics,
            ["Median", "SD"],
        )
        self.assertEqual(
            workbook_index["sheets"][0]["analysis"],
                {"visible_statistics": ["Mean", "Sample"], "statistic_formats": {}},
        )
        self.assertIn("sheets.json", members)
        self.assertIn("sheets/first-sheet/data.csv", members)
        self.assertIn("sheets/second-sheet/settings.json", members)

    def test_v3_roundtrip_preserves_xy_mapping_display_and_duplicate_column_names(self):
        column_ids = ["x-main", "y-a", "x-other", "y-b"]
        xy_settings = XYSettings(
            default_x_column_id="x-main",
            show_points=True,
            show_line=False,
            point_size=6.5,
            point_alpha=0.4,
            marker="Square",
            line_width=2.25,
            line_style="Dashed",
            series=[
                XYSeriesSpec(
                    id="series-a",
                    name="Response A",
                    y_column_id="y-a",
                    color="#123456",
                    show_line=True,
                ),
                XYSeriesSpec(
                    id="series-b",
                    name="Response B",
                    x_column_id="x-other",
                    y_column_id="y-b",
                    visible=False,
                    show_points=False,
                    show_line=False,
                    color="#abcdef",
                    marker="Triangle",
                    line_style="Dotted",
                ),
            ],
        )
        dataframe = pd.DataFrame(
            [[0, 10, 0.5, 20], [1, 11, 1.5, 22]],
            columns=["Time", "Response", "Time", "Response"],
        )
        groups = SheetDocument(
            id="groups-sheet",
            name="Groups",
            dataframe=pd.DataFrame({"Control": [1, 2]}),
        )
        xy = SheetDocument(
            id="xy-sheet",
            name="XY",
            dataframe=dataframe,
            mode=SHEET_MODE_XY,
            column_ids=column_ids,
            xy_settings=xy_settings,
        )

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "xy-v3.eg"
            project_io.write_project(path, WorkbookDocument([groups, xy], xy.id))
            loaded = project_io.read_workbook_project(path)
            with zipfile.ZipFile(path) as archive:
                index = json.loads(archive.read("sheets.json"))
                envelope = json.loads(archive.read("sheets/xy-sheet/settings.json"))

        self.assertEqual([entry["mode"] for entry in index["sheets"]], ["groups", "xy"])
        self.assertEqual(set(envelope), {"chart", "xy", "column_ids", "grouping"})
        self.assertEqual(loaded.sheets[0].mode, SHEET_MODE_GROUPS)
        loaded_xy = loaded.sheets[1]
        self.assertEqual(loaded_xy.mode, SHEET_MODE_XY)
        self.assertEqual(loaded_xy.column_ids, column_ids)
        self.assertEqual(list(loaded_xy.dataframe.columns), list(dataframe.columns))
        self.assertEqual(asdict(loaded_xy.xy_settings), asdict(xy_settings))

    def test_v3_roundtrip_preserves_structured_xy_table_layout(self):
        settings = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(id="shared-y", name="1Y", y_column_id="y"),
                XYSeriesSpec(
                    id="paired-y",
                    name="1Y",
                    x_column_id="pair-x",
                    y_column_id="pair-y",
                ),
            ],
            shared_tables=[
                XYSharedTableSpec(
                    id="shared-table",
                    name="Shared X 1",
                    x_column_id="x",
                    series_ids=["shared-y"],
                )
            ],
            paired_series_ids=["paired-y"],
            active_shared_table_id="shared-table",
        )
        sheet = SheetDocument(
            id="xy-layout",
            name="XY layout",
            dataframe=pd.DataFrame({"X": [1], "1Y": [2], "1X": [3], "Pair Y": [4]}),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y", "pair-x", "pair-y"],
            xy_settings=settings,
        )

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "xy-layout.eg"
            project_io.write_project(path, WorkbookDocument([sheet], sheet.id))
            loaded = project_io.read_workbook_project(path).active_sheet

        self.assertEqual(asdict(loaded.xy_settings), asdict(settings))

    def test_v3_reader_rejects_invalid_xy_column_references(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "invalid-reference.eg"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("project.json", json.dumps(project_io.project_manifest(3)))
                archive.writestr(
                    "sheets.json",
                    json.dumps(
                        {
                            "active_sheet_id": "xy-sheet",
                            "sheets": [{"id": "xy-sheet", "name": "XY", "mode": "xy"}],
                        }
                    ),
                )
                archive.writestr("sheets/xy-sheet/data.csv", "X,Y\n1,2\n")
                archive.writestr(
                    "sheets/xy-sheet/settings.json",
                    json.dumps(
                        {
                            "chart": asdict(ChartSettings()),
                            "column_ids": ["x", "y"],
                            "xy": {
                                **asdict(XYSettings()),
                                "default_x_column_id": "missing",
                            },
                        }
                    ),
                )

            with self.assertRaisesRegex(ValueError, "unknown column ID"):
                project_io.read_workbook_project(path)

    def test_current_project_without_analysis_settings_defaults_to_all_statistics(self):
        settings = ChartSettings(title="Existing version 2 project")
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "without-analysis.eg"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr(
                    "project.json",
                    json.dumps(project_io.project_manifest(2)),
                )
                archive.writestr(
                    "sheets.json",
                    json.dumps(
                        {
                            "active_sheet_id": "existing-sheet",
                            "sheets": [
                                {"id": "existing-sheet", "name": "Existing"}
                            ],
                        }
                    ),
                )
                archive.writestr(
                    "sheets/existing-sheet/data.csv",
                    "A\n1\n",
                )
                archive.writestr(
                    "sheets/existing-sheet/settings.json",
                    json.dumps(asdict(settings)),
                )

            workbook = project_io.read_workbook_project(path)

        self.assertEqual(
            workbook.active_sheet.analysis_settings.visible_statistics,
            list(DESCRIPTIVE_STATISTICS),
        )
        self.assertEqual(workbook.active_sheet.mode, SHEET_MODE_GROUPS)
        self.assertEqual(
            len(workbook.active_sheet.column_ids),
            workbook.active_sheet.dataframe.shape[1],
        )

    def test_legacy_single_sheet_project_opens_as_workbook(self):
        settings = ChartSettings(title="Legacy")
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "legacy.eg"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("data.csv", "A,B\n1,2\n")
                archive.writestr("settings.json", json.dumps(asdict(settings)))
                archive.writestr("project.json", json.dumps({"version": 1, "app": "EasyGraph"}))

            workbook = project_io.read_workbook_project(path)

        self.assertEqual(len(workbook.sheets), 1)
        self.assertEqual(workbook.active_sheet.name, "Sheet 1")
        self.assertEqual(workbook.active_sheet.settings.title, "Legacy")
        pd.testing.assert_frame_equal(
            workbook.active_sheet.dataframe,
            pd.DataFrame({"A": [1], "B": [2]}),
        )
