"""Structure edits act on atomic parent headers without pooling numeric columns."""
from copy import deepcopy
from dataclasses import asdict
from unittest import mock

import pandas as pd
from PySide6.QtWidgets import QDialog, QMenu

from easygraph.grouping import parent_for_column
from easygraph.ui.grouping_controls import GroupDisplayDialog
from tests.easygraph_case import EasyGraphQtTestCase


class ParentGroupCommandTests(EasyGraphQtTestCase):
    def make_group_window(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([[1, 10, 100, 1000], [2, 20, 200, 2000]],
                                               columns=['Control', 'Drug', 'Control', 'Drug']))
        return window

    def add_parent(self, window, first, last, name):
        window.table.horizontalHeader().clear_parent_selection()
        self.select_table_range(window.table, 0, first, 0, last)
        self.assertTrue(window.grouping_controls.create_selected_parent(name))

    def test_merge_complete_parent_blocks_and_blank_slots_keeps_data_and_ids_and_undo(self):
        window = self.make_group_window()
        self.add_parent(window, 0, 1, 'WT')
        self.add_parent(window, 2, 2, 'KO')
        sheet = window.workbook.active_sheet
        before = asdict(sheet.grouping)
        ids = list(sheet.column_ids)
        values = window.table_dataframe().copy()
        window.table.horizontalHeader().select_parent_columns([0, 2, 3])
        self.assertTrue(window.grouping_controls.merge_selected_headers('Experiment'))
        self.assertEqual(len(sheet.grouping.parents), 1)
        self.assertEqual(sheet.grouping.parents[0]['column_ids'], ids[:4])
        self.assertEqual(sheet.column_ids, ids)
        pd.testing.assert_frame_equal(window.table_dataframe(), values)
        window.undo_table_change()
        self.assertEqual(asdict(sheet.grouping), before)
        window.redo_table_change()
        self.assertEqual(sheet.grouping.parents[0]['name'], 'Experiment')

    def test_cell_selection_merge_command_remains_enabled_and_guides_to_header(self):
        window = self.make_group_window()
        self.select_table_range(window.table, window.sample_start_row(), 0,
                                window.sample_start_row(), 1)
        controls = window.grouping_controls
        controls.update_actions()
        self.assertTrue(controls.action('merge').isEnabled())
        with mock.patch('easygraph.ui.grouping_controls.QMessageBox.information') as notice, \
             mock.patch.object(window.table.horizontalHeader(), 'highlight_parent_band') as highlight:
            controls.action('merge').trigger()
        notice.assert_called_once()
        self.assertEqual(notice.call_args.args[2], 'Select adjacent parent header cells to merge.')
        highlight.assert_called_once()
        self.assertFalse(window.workbook.active_sheet.grouping.parents)

    def test_partial_existing_parent_from_whole_column_selection_cannot_split_it(self):
        window = self.make_group_window()
        self.add_parent(window, 0, 1, 'WT')
        before = asdict(window.workbook.active_sheet.grouping)
        window.table.selectColumn(1)
        with mock.patch('easygraph.ui.grouping_controls.QMessageBox.information') as notice:
            self.assertFalse(window.grouping_controls.merge_selected_headers('Partial'))
        notice.assert_called_once()
        self.assertEqual(asdict(window.workbook.active_sheet.grouping), before)

    def test_whole_free_column_selection_and_blank_header_double_click_create_parent(self):
        window = self.make_group_window()
        window.table.selectColumn(0)
        self.assertTrue(window.grouping_controls.merge_selected_headers('First'))
        with mock.patch('easygraph.ui.grouping_controls.QInputDialog.getText', return_value=('Second', True)):
            self.assertTrue(window.grouping_controls.edit_parent_at_column(1))
        with mock.patch('easygraph.ui.grouping_controls.QInputDialog.getText', return_value=('Renamed', True)):
            self.assertTrue(window.grouping_controls.edit_parent_at_column(1))
        self.assertEqual([p['name'] for p in window.workbook.active_sheet.grouping.parents], ['First', 'Renamed'])

    def test_insert_parent_from_child_uses_outer_boundary_and_one_step_undo(self):
        for after, insertion in ((False, 0), (True, 3)):
            with self.subTest(after=after):
                window = self.make_group_window()
                self.add_parent(window, 0, 2, 'WT')
                self.add_parent(window, 3, 3, 'KO')
                sheet = window.workbook.active_sheet
                ids = list(sheet.column_ids)
                parents = deepcopy(sheet.grouping.parents)
                original = window.table_dataframe().copy()
                self.select_table_range(window.table, 0, 1, 0, 1)
                self.assertTrue(window.grouping_controls.insert_selected_parent(after, 'New'))
                inserted = sheet.column_ids[insertion]
                self.assertNotIn(inserted, ids)
                self.assertEqual(parent_for_column(sheet.grouping, inserted)['name'], 'New')
                self.assertEqual(parent_for_column(sheet.grouping, inserted)['column_ids'], [inserted])
                self.assertEqual(window.table.table_model.cell_text(window.sample_start_row(), insertion), '')
                self.assertEqual([key for key in sheet.column_ids if key != inserted], ids)
                window.undo_table_change()
                self.assertEqual(sheet.column_ids, ids)
                self.assertEqual(sheet.grouping.parents, parents)
                pd.testing.assert_frame_equal(window.table_dataframe(), original)
                window.redo_table_change()
                self.assertEqual(sheet.column_ids[insertion], inserted)

    def test_unmerge_from_child_and_parent_header_preserves_values_and_column_identity(self):
        window = self.make_group_window()
        self.add_parent(window, 0, 1, 'WT')
        self.add_parent(window, 2, 3, 'KO')
        sheet = window.workbook.active_sheet
        ids = list(sheet.column_ids)
        values = window.table_dataframe().copy()
        self.select_table_range(window.table, 0, 1, 0, 1)
        self.assertTrue(window.grouping_controls.unmerge_selected_headers())
        self.assertEqual([p['name'] for p in sheet.grouping.parents], ['KO'])
        window.table.horizontalHeader().select_parent_columns([2])
        self.assertTrue(window.grouping_controls.unmerge_selected_headers())
        self.assertFalse(sheet.grouping.parents)
        self.assertEqual(sheet.column_ids, ids)
        pd.testing.assert_frame_equal(window.table_dataframe(), values)
        self.assertGreater(window.table.horizontalHeader().band_height(), 0)
        window.undo_table_change()
        self.assertEqual([p['name'] for p in sheet.grouping.parents], ['KO'])
        window.undo_table_change()
        self.assertEqual([p['name'] for p in sheet.grouping.parents], ['WT', 'KO'])
        self.assertEqual(sheet.column_ids, ids)
        pd.testing.assert_frame_equal(window.table_dataframe(), values)

    def test_cancelled_insert_and_blank_merge_name_do_not_record_structure_changes(self):
        window = self.make_group_window()
        header = window.table.horizontalHeader()
        header.select_parent_columns([0, 1])
        sheet = window.workbook.active_sheet
        ids = list(sheet.column_ids)
        self.assertFalse(window.grouping_controls.merge_selected_headers(' '))
        with mock.patch('easygraph.ui.grouping_controls.QInputDialog.getText', return_value=('', False)):
            self.assertFalse(window.grouping_controls.insert_selected_parent(True))
        self.assertFalse(sheet.grouping.parents)
        self.assertEqual(sheet.column_ids, ids)

    def test_right_click_and_table_consume_same_action_instances(self):
        window = self.make_group_window()
        menu = QMenu(window)
        controls = window.grouping_controls
        controls.add_menu(menu, 'cells')
        parent_menu = next(a.menu() for a in menu.actions() if a.menu() is not None)
        for key in ('merge', 'unmerge', 'rename', 'insert_parent_left', 'insert_parent_right', 'batch'):
            self.assertIn(controls.action(key), parent_menu.actions())
        self.assertTrue(controls.action('merge').isVisible())
        self.assertTrue(controls.action('merge').isEnabled())

    def test_multiple_selected_columns_insert_same_count_at_child_boundary(self):
        for after, insertion, parent_index in ((False, 0, 0), (True, 2, 0)):
            with self.subTest(after=after):
                window = self.make_group_window()
                self.add_parent(window, 0, 1, 'WT')
                self.add_parent(window, 2, 3, 'KO')
                sheet = window.workbook.active_sheet
                ids = list(sheet.column_ids)
                parent_id = sheet.grouping.parents[parent_index]['id']
                self.select_table_range(window.table, 0, 0, 0, 1)
                window.grouping_controls.update_actions()
                self.assertTrue(window.grouping_controls.action('insert_subgroup_right').isEnabled())
                self.assertTrue(window.grouping_controls.insert_selected_subgroup(after))
                inserted = sheet.column_ids[insertion:insertion + 2]
                self.assertEqual(len(sheet.column_ids), len(ids) + 2)
                self.assertTrue(all(key not in ids for key in inserted))
                self.assertTrue(all(parent_for_column(sheet.grouping, key)['id'] == parent_id for key in inserted))
                self.assertEqual([key for key in sheet.column_ids if key not in inserted], ids)
                window.undo_table_change()
                self.assertEqual(sheet.column_ids, ids)

    def test_batch_sharing_does_not_relink_preexisting_matching_headers(self):
        window = self.make_group_window()
        self.add_parent(window, 0, 1, 'Existing')
        window.grouping_controls.add_shared_groups(['WT', 'KO'], ['Control', 'Drug'])
        window.table.table_model.set_cell_text(0, 4, 'Vehicle')
        self.assertEqual(window.table_group_names(),
                         ['Control', 'Drug', 'Control', 'Drug', 'Vehicle', 'Drug', 'Vehicle', 'Drug'])
        window.undo_table_change()
        self.assertEqual(window.table_group_names()[4], 'Control')

    def test_minimum_empty_table_still_allows_subgroup_insertion_and_undo(self):
        for after in (False, True):
            with self.subTest(after=after):
                window = self.make_window()
                window.set_table_dataframe(pd.DataFrame({'Only': ['tail']}))
                table = window.table
                self.select_table_range(table, 0, 0, table.table_model.rowCount() - 1,
                                        table.table_model.columnCount() - 1)
                self.assertTrue(window.delete_table_structure('entire_column', table))
                table.clearSelection()
                self.assertEqual(window.table_group_names(), [])
                self.assertEqual(table.table_model.columnCount(), 1)
                controls = window.grouping_controls
                controls.update_actions()
                self.assertTrue(controls.action('insert_subgroup_right' if after else 'insert_subgroup_left').isEnabled())
                self.assertTrue(controls.insert_selected_subgroup(after))
                self.assertEqual(table.table_model.columnCount(), 2)
                self.assertEqual(len(window.table_group_names()), 1)
                self.assertTrue(window._group_last_column_is_auto_spare())
                ids = list(window.workbook.active_sheet.column_ids)
                window.undo_table_change()
                self.assertEqual(table.table_model.columnCount(), 1)
                self.assertEqual(window.table_group_names(), [])
                window.redo_table_change()
                self.assertEqual(window.workbook.active_sheet.column_ids, ids)

    def test_display_edits_preserve_mixed_name_linkage_unless_sharing_is_enabled(self):
        window = self.make_group_window()
        self.add_parent(window, 0, 1, 'Existing')
        window.grouping_controls.add_shared_groups(['WT', 'KO'], ['Control', 'Drug'])
        sheet = window.workbook.active_sheet
        categories = dict(sheet.grouping.subgroup_ids)
        dialog = GroupDisplayDialog(window.settings, sheet.grouping, window)
        dialog.outer.setValue(dialog.outer.value() + 1)
        with mock.patch('easygraph.ui.grouping_controls.GroupDisplayDialog', return_value=dialog), \
             mock.patch.object(dialog, 'exec', return_value=QDialog.Accepted):
            window.grouping_controls.edit_display()
        self.assertEqual(sheet.grouping.subgroup_ids, categories)
        window.table.table_model.set_cell_text(0, 4, 'Vehicle')
        self.assertEqual(window.table_group_names()[0], 'Control')
        self.assertEqual(window.table_group_names()[6], 'Vehicle')
        # Explicitly enabling sharing retains the existing global link command.
        sheet.grouping.shared_subgroups = False
        dialog = GroupDisplayDialog(window.settings, sheet.grouping, window)
        dialog.shared.setChecked(True)
        with mock.patch('easygraph.ui.grouping_controls.GroupDisplayDialog', return_value=dialog), \
             mock.patch.object(dialog, 'exec', return_value=QDialog.Accepted):
            window.grouping_controls.edit_display()
        self.assertEqual(sheet.grouping.subgroup_ids[sheet.column_ids[1]],
                         sheet.grouping.subgroup_ids[sheet.column_ids[5]])

    def test_spare_header_never_targets_stale_current_parent(self):
        window = self.make_group_window()
        self.add_parent(window, 0, 1, 'WT')
        table = window.table
        sheet = window.workbook.active_sheet
        before = asdict(sheet.grouping)
        values = window.table_dataframe().copy()
        ids = list(sheet.column_ids)
        table.setCurrentIndex(table.table_model.index(window.sample_start_row(), 0))
        spare = table.table_model.columnCount() - 1
        table.horizontalHeader().select_parent_columns([spare])
        controls = window.grouping_controls
        controls.update_actions()
        for key in ('rename', 'unmerge', 'insert_parent_left', 'insert_parent_right'):
            self.assertFalse(controls.action(key).isEnabled())
        self.assertFalse(controls.rename_selected_parent('Wrong target'))
        self.assertFalse(controls.unmerge_selected_headers())
        self.assertFalse(controls.insert_selected_parent(False, 'Wrong target'))
        self.assertEqual(asdict(sheet.grouping), before)
        self.assertEqual(sheet.column_ids, ids)
        pd.testing.assert_frame_equal(window.table_dataframe(), values)
        self.assertTrue(controls.action('insert_subgroup_right').isEnabled())
        self.assertTrue(controls.insert_selected_subgroup(True))
        self.assertEqual(sheet.column_ids[:spare], ids[:spare])
        self.assertEqual(sheet.column_ids[-1], ids[-1])
        self.assertEqual(asdict(sheet.grouping), before)
        self.assertEqual(len(window.table_group_names()), spare + 1)
        self.assertTrue(window._group_last_column_is_auto_spare())
