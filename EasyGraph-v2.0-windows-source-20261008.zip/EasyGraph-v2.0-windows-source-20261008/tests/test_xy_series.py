from __future__ import annotations

import pandas as pd

from tests.easygraph_case import EasyGraphTestCase

from easygraph.xy_series import (
    MAPPING_MODE_EMPTY,
    MAPPING_MODE_MIXED,
    MAPPING_MODE_PAIRED,
    MAPPING_MODE_SHARED,
    XYSeriesSpec,
    XYSharedTableSpec,
    XYSettings,
    adjacent_xy_series,
    ensure_xy_table_layout,
    pairwise_numeric_values,
    paired_xy_column_ids,
    remove_xy_column_references,
    resolved_series_display,
    resolved_x_column_id,
    shared_x_series,
    shared_table_column_ids,
    xy_column_headers,
    xy_column_roles,
    xy_mapping_mode,
)


class XYSeriesTests(EasyGraphTestCase):
    def test_xy_defaults_show_points_and_lines(self):
        settings = XYSettings()

        self.assertTrue(settings.show_points)
        self.assertTrue(settings.show_line)

    def test_visible_series_must_resolve_to_points_or_lines(self):
        with self.assertRaisesRegex(ValueError, "Points and lines cannot both be hidden"):
            XYSettings(show_points=False, show_line=False)

        hidden = XYSeriesSpec(
            id="hidden",
            name="Hidden",
            y_column_id="y",
            visible=False,
            show_points=False,
            show_line=False,
        )
        settings = XYSettings(series=[hidden])
        self.assertEqual(resolved_series_display(settings, hidden), (False, False))

        inherited = XYSeriesSpec(id="inherited", name="Inherited", y_column_id="y")
        settings = XYSettings(show_points=True, show_line=False, series=[inherited])
        self.assertEqual(resolved_series_display(settings, inherited), (True, False))

    def test_shared_x_series_use_the_default_x_without_storing_repeated_references(self):
        settings = shared_x_series(
            ["col-x", "col-a", "col-b", "col-c"],
            ["Time", "Control", "Drug A", "Drug B"],
        )

        self.assertEqual(settings.default_x_column_id, "col-x")
        self.assertEqual([series.name for series in settings.series], ["Control", "Drug A", "Drug B"])
        self.assertEqual([series.y_column_id for series in settings.series], ["col-a", "col-b", "col-c"])
        self.assertEqual([series.x_column_id for series in settings.series], [None, None, None])
        self.assertEqual(xy_mapping_mode(settings), MAPPING_MODE_SHARED)
        self.assertEqual(len(settings.shared_tables), 1)
        self.assertEqual(settings.shared_tables[0].name, "Sheet1")
        self.assertEqual(
            shared_table_column_ids(settings, settings.shared_tables[0]),
            ("col-x", "col-a", "col-b", "col-c"),
        )
        self.assertEqual(settings.paired_series_ids, [])

    def test_adjacent_xy_series_create_independent_pairs_and_report_an_odd_tail(self):
        result = adjacent_xy_series(
            ["x1", "y1", "x2", "y2", "unused"],
            ["Time A", "A", "Time B", "B", "Notes"],
        )

        self.assertEqual([series.name for series in result.settings.series], ["A", "B"])
        self.assertEqual(
            [(series.x_column_id, series.y_column_id) for series in result.settings.series],
            [("x1", "y1"), ("x2", "y2")],
        )
        self.assertEqual(result.unused_column_ids, ("unused",))
        self.assertEqual(xy_mapping_mode(result.settings), MAPPING_MODE_PAIRED)
        self.assertEqual(result.settings.shared_tables, [])
        self.assertEqual(
            paired_xy_column_ids(result.settings),
            ("x1", "y1", "x2", "y2"),
        )

    def test_legacy_mixed_mapping_is_partitioned_into_shared_tables_and_pairs(self):
        settings = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(id="a", name="A", y_column_id="a"),
                XYSeriesSpec(id="b", name="B", y_column_id="b"),
                XYSeriesSpec(id="c", name="C", x_column_id="cx", y_column_id="c"),
            ],
        )

        ensure_xy_table_layout(settings, ["x", "a", "b", "cx", "c"])

        self.assertEqual(len(settings.shared_tables), 1)
        self.assertEqual(settings.shared_tables[0].name, "Sheet1")
        self.assertEqual(settings.shared_tables[0].series_ids, ["a", "b"])
        self.assertEqual(settings.paired_series_ids, ["c"])
        self.assertEqual(settings.active_shared_table_id, settings.shared_tables[0].id)

    def test_layout_validation_rejects_series_assigned_to_two_sections(self):
        settings = XYSettings(
            series=[
                XYSeriesSpec(id="one", name="One", x_column_id="x", y_column_id="y")
            ],
            shared_tables=[
                XYSharedTableSpec(
                    id="shared",
                    name="Shared X 1",
                    x_column_id="x",
                    series_ids=["one"],
                )
            ],
            paired_series_ids=["one"],
        )

        with self.assertRaisesRegex(ValueError, "more than one XY table section"):
            ensure_xy_table_layout(settings, ["x", "y"])

    def test_overriding_one_shared_series_x_creates_a_mixed_mapping(self):
        settings = shared_x_series(
            ["x", "a", "b", "other-x"],
            ["Time", "A", "B", "Other time"],
            y_column_ids=["a", "b"],
        )
        settings.series[1].x_column_id = "other-x"

        self.assertEqual(resolved_x_column_id(settings, settings.series[0]), "x")
        self.assertEqual(resolved_x_column_id(settings, settings.series[1]), "other-x")
        self.assertEqual(xy_mapping_mode(settings), MAPPING_MODE_MIXED)
        self.assertEqual(xy_mapping_mode(XYSettings()), MAPPING_MODE_EMPTY)

    def test_pairwise_numeric_values_never_shift_x_and_y_independently(self):
        frame = pd.DataFrame(
            {
                "x": [1, 2, "bad", 4, 5],
                "y": [10, "", 30, 40, None],
            }
        )

        paired = pairwise_numeric_values(frame.iloc[:, 0], frame.iloc[:, 1])

        self.assertEqual(paired.x.tolist(), [1.0, 4.0])
        self.assertEqual(paired.y.tolist(), [10.0, 40.0])
        self.assertEqual(paired.row_indexes, (0, 3))
        self.assertEqual(paired.skipped_row_indexes, (1, 2, 4))
        self.assertEqual(paired.valid_count, 2)
        self.assertEqual(paired.skipped_count, 3)

    def test_percentage_pairs_keep_valid_rows_aligned(self):
        paired = pairwise_numeric_values(
            pd.Series(["25%", "bad", "50％", 0.75], index=[4, 5, 6, 7]),
            pd.Series(["-10%", "20%", "", "1.2e2%"], index=[4, 5, 6, 7]),
        )

        self.assertEqual(paired.x.tolist(), [0.25, 0.75])
        self.assertEqual(paired.y.tolist(), [-0.1, 1.2])
        self.assertEqual(paired.row_indexes, (4, 7))
        self.assertEqual(paired.skipped_row_indexes, (5, 6))

    def test_column_roles_and_reference_cleanup_use_stable_column_ids(self):
        settings = shared_x_series(
            ["x", "a", "other-x", "b"],
            ["Time", "A", "Other time", "B"],
            y_column_ids=["a", "b"],
        )
        settings.series[1].x_column_id = "other-x"

        self.assertEqual(
            xy_column_roles(settings, ["x", "a", "other-x", "b"]),
            ("X", "Y", "X", "Y"),
        )
        inherited_series_id = settings.series[0].id
        removed = remove_xy_column_references(settings, {"x"})

        self.assertEqual(removed, (inherited_series_id,))
        self.assertIsNone(settings.default_x_column_id)
        self.assertEqual([series.name for series in settings.series], ["B"])

    def test_shared_x_headers_number_series_and_describe_all_matches(self):
        settings = shared_x_series(
            ["x", "a", "b", "c"],
            ["X", "A", "B", "C"],
        )

        headers = xy_column_headers(settings, ["x", "a", "b", "c"])

        self.assertEqual([header.label for header in headers], ["X", "1Y", "2Y", "3Y"])
        self.assertEqual(headers[0].matched_y_labels, ("1Y", "2Y", "3Y"))
        self.assertEqual(headers[1].matched_y_labels, ())

    def test_paired_xy_headers_use_the_same_number_for_each_pair(self):
        settings = adjacent_xy_series(
            ["x1", "y1", "x2", "y2", "x3", "y3"],
            ["X1", "Y1", "X2", "Y2", "X3", "Y3"],
        ).settings

        headers = xy_column_headers(
            settings,
            ["x1", "y1", "x2", "y2", "x3", "y3"],
        )

        self.assertEqual(
            [header.label for header in headers],
            ["1X", "1Y", "2X", "2Y", "3X", "3Y"],
        )
        self.assertEqual(headers[2].matched_y_labels, ("2Y",))

    def test_mixed_headers_keep_series_numbers_when_columns_are_reordered(self):
        settings = shared_x_series(
            ["x", "y1", "y2", "x4", "y4", "x5", "y5", "y3"],
            ["X", "Y1", "Y2", "X4", "Y4", "X5", "Y5", "Y3"],
            y_column_ids=["y1", "y2", "y3", "y4", "y5"],
        )
        settings.series[3].x_column_id = "x4"
        settings.series[4].x_column_id = "x5"

        headers = xy_column_headers(
            settings,
            ["x", "y1", "y2", "x4", "y4", "x5", "y5", "y3"],
        )

        self.assertEqual(
            [header.label for header in headers],
            ["X", "1Y", "2Y", "4X", "4Y", "5X", "5Y", "3Y"],
        )
        self.assertEqual(headers[0].matched_y_labels, ("1Y", "2Y", "3Y"))


if __name__ == "__main__":
    __import__("unittest").main()
