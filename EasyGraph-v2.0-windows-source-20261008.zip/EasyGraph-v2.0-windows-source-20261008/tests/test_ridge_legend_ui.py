from __future__ import annotations

from unittest import mock

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.settings import LEGEND_POSITION_INSIDE, LEGEND_POSITION_RIGHT
from easygraph.workbook import SHEET_MODE_XY


class RidgeLegendUiTests(EasyGraphQtTestCase):
    def test_chart_changes_relabel_outside_legend_and_preserve_position(self):
        window = self.make_window()

        with mock.patch.object(window, "schedule_render"):
            window.chart_type.setCurrentText("Ridge")
            self.assertEqual(window.legend_position.currentText(), "Below plot")
            self.assertEqual(window.settings.legend_position, LEGEND_POSITION_RIGHT)

            window.legend_position.setCurrentText("Inside plot")
            window.chart_type.setCurrentText("Box")
            self.assertEqual(window.legend_position.itemText(0), "Right side")
            self.assertEqual(window.legend_position.currentText(), "Inside plot")
            self.assertEqual(window.settings.legend_position, LEGEND_POSITION_INSIDE)

            window.chart_type.setCurrentText("Ridge")
            self.assertEqual(window.legend_position.currentText(), "Inside plot")
            window.legend_position.setCurrentText("Below plot")
            self.assertEqual(window.settings.legend_position, LEGEND_POSITION_RIGHT)

    def test_switching_between_ridge_and_xy_restores_outside_legend_label(self):
        window = self.make_window()

        with mock.patch.object(window, "render"), mock.patch.object(window, "schedule_render"):
            window.chart_type.setCurrentText("Ridge")
            window.add_sheet(SHEET_MODE_XY)
            self.assertEqual(window.legend_position.currentText(), "Right side")

            window.sheet_tab_bar.setCurrentIndex(0)
            self.assertEqual(window.legend_position.currentText(), "Below plot")
            self.assertEqual(window.settings.legend_position, LEGEND_POSITION_RIGHT)
