"""Statistics must retain the source table's merged parent headings."""
from __future__ import annotations

from unittest import mock

import pandas as pd
from PySide6.QtCore import QMimeData, QPoint, Qt
from PySide6.QtTest import QTest

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.analysis_results import AnalysisTableResult
from easygraph.clipboard_table import CellMerge, clipboard_table_from_html
from easygraph.ui.analysis_results_table import AnalysisResultsTable


class AnalysisParentHeaderTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.addCleanup(self.qapp.clipboard().clear)

    def make_results_table(self):
        table = AnalysisResultsTable()
        self.addCleanup(table.deleteLater)
        self.addCleanup(table.close)
        table.set_result(AnalysisTableResult(
            key="example",
            title="Example",
            columns=("Control", "Drug", "Recovery", "Control"),
            row_labels=("Mean", "Sample"),
            values=(("1.00", "2.00", "3.00", "4.00"), ("2", "2", "2", "2")),
        ))
        ids = ["a", "b", "c", "d"]
        table.set_grouping([
            {"id": "wt", "name": "WT", "column_ids": ids[:3]},
            {"id": "ko", "name": "KO", "column_ids": ids[3:]},
        ], ids)
        table.resize(650, 240)
        table.show()
        self.qapp.processEvents()
        return table

    def make_grouped_window(self, columns=None):
        window = self.make_window()
        columns = ["Control", "Drug", "Other"] if columns is None else columns
        window.set_table_dataframe(pd.DataFrame(
            [[index + 1 for index in range(len(columns))],
             [index + 3 for index in range(len(columns))]],
            columns=columns,
        ))
        self.select_table_range(window.table, 0, 0, 0, 1)
        self.assertTrue(window.grouping_controls.create_selected_parent("WT"))
        return window

    def group_labels(self, table):
        return [label for _key, label, _rect in table.horizontalHeader().group_rects()]

    def clipboard_table(self):
        mime = self.qapp.clipboard().mimeData()
        self.assertTrue(mime.hasText())
        self.assertTrue(mime.hasHtml())
        data = clipboard_table_from_html(mime.html())
        self.assertIsNotNone(data)
        return data

    def test_parent_band_is_above_leaf_names_and_selects_complete_group(self):
        table = self.make_results_table()
        header = table.horizontalHeader()
        self.assertEqual(header.parent_band_rect().top(), 0)
        self.assertGreater(header.height(), header.band_height())
        self.assertEqual(self.group_labels(table), ["WT", "KO"])
        self.assertEqual(table.model().headerData(1, Qt.Horizontal), "Drug")
        self.assertFalse(table.model().flags(table.model().index(0, 0)) & Qt.ItemIsEditable)

        x = header.sectionViewportPosition(1) + header.sectionSize(1) // 2
        QTest.mouseClick(header.viewport(), Qt.LeftButton, pos=QPoint(
            x, header.parent_band_rect().center().y(),
        ))
        self.assertEqual(
            {(index.row(), index.column()) for index in table.selectedIndexes()},
            {(row, column) for row in range(2) for column in range(3)},
        )

        leaf_y = (header.parent_band_rect().bottom() + header.height()) // 2
        QTest.mouseClick(header.viewport(), Qt.LeftButton, pos=QPoint(x, leaf_y))
        self.assertEqual(
            {(index.row(), index.column()) for index in table.selectedIndexes()},
            {(0, 1), (1, 1)},
        )
        self.assertEqual(header.selected_parent_columns(), [])

    def test_full_statistics_clipboard_preserves_parent_merges_and_row_labels(self):
        table = self.make_results_table()
        copied = table.table_clipboard_data()
        self.assertEqual(copied.rows, [
            ["", "WT", "", "", "KO"],
            ["", "Control", "Drug", "Recovery", "Control"],
            ["Mean", "1.00", "2.00", "3.00", "4.00"],
            ["Sample", "2", "2", "2", "2"],
        ])
        self.assertEqual(copied.merges, [CellMerge(0, 1, colspan=3)])
        self.assertEqual(copied.header_rows, 2)
        self.assertEqual(table.table_tsv().splitlines()[0], "\tWT\t\t\tKO")

    def test_partial_selection_clips_parent_merge_and_raw_copy_remains_values(self):
        table = self.make_results_table()
        self.select_table_range(table, 0, 1, 1, 2)
        copied = table.selection_clipboard_data(include_headers=True)
        self.assertEqual(copied.rows, [
            ["", "WT", ""],
            ["", "Drug", "Recovery"],
            ["Mean", "2.00", "3.00"],
            ["Sample", "2", "2"],
        ])
        self.assertEqual(copied.merges, [CellMerge(0, 1, colspan=2)])
        self.assertEqual(table.selection_with_headers_tsv().splitlines()[0], "\tWT\t")
        raw = table.selection_clipboard_data()
        self.assertEqual(raw.rows, [["2.00", "3.00"], ["2", "2"]])
        self.assertEqual(raw.merges, [])
        self.assertEqual(table.selection_tsv(), "2.00\t3.00\n2\t2")

    def test_replacing_result_clears_obsolete_parent_headings(self):
        table = self.make_results_table()
        table.set_result(AnalysisTableResult(
            key="independent", title="Independent", columns=("New",),
            row_labels=("Mean",), values=(("9",),), source_aligned=False,
        ))
        self.assertEqual(self.group_labels(table), [])
        self.assertEqual(table.horizontalHeader().band_height(), 0)
        self.assertEqual(table.table_tsv(), "\tNew\nMean\t9")

    def test_source_merge_rename_unmerge_and_history_sync_before_render(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame([[1, 2, 3]], columns=["A", "B", "C"]))
        window._render_timer.stop()
        window.table.horizontalHeader().select_parent_columns([0, 1])
        with mock.patch.object(window, "render") as render:
            self.assertTrue(window.grouping_controls.merge_selected_headers("Batch"))
            self.assertEqual(self.group_labels(window.results_table), ["Batch"])
            parent_id = window.workbook.active_sheet.grouping.parents[0]["id"]
            self.assertTrue(window.grouping_controls.rename_parent(parent_id, "Renamed"))
            self.assertEqual(self.group_labels(window.results_table), ["Renamed"])
            window.undo_table_change()
            self.assertEqual(self.group_labels(window.results_table), ["Batch"])
            window.redo_table_change()
            self.assertEqual(self.group_labels(window.results_table), ["Renamed"])
            window.table.horizontalHeader().select_parent_columns([0])
            self.assertTrue(window.grouping_controls.unmerge_selected_headers())
            self.assertEqual(self.group_labels(window.results_table), [])
            window.undo_table_change()
            self.assertEqual(self.group_labels(window.results_table), ["Renamed"])
            window.redo_table_change()
            self.assertEqual(self.group_labels(window.results_table), [])
            render.assert_not_called()

    def test_switching_sheets_and_replacing_source_clears_stale_parent_headings(self):
        window = self.make_grouped_window()
        self.assertEqual(self.group_labels(window.results_table), ["WT"])
        with mock.patch.object(window, "render"):
            window.add_sheet()
            self.assertEqual(self.group_labels(window.results_table), [])
            window.sheet_tab_bar.setCurrentIndex(0)
            self.assertEqual(self.group_labels(window.results_table), ["WT"])
            window.set_table_dataframe(pd.DataFrame({"Replacement": [9]}))
            self.assertEqual(self.group_labels(window.results_table), [])
            self.assertEqual(window.results_table.table_tsv().splitlines()[0].split("\t")[1], "Replacement")

    def test_merged_statistics_header_tracks_column_widths_and_horizontal_scroll(self):
        window = self.make_grouped_window([f"Column {index}" for index in range(12)])
        window.resize(1100, 700)
        window.show()
        self.qapp.processEvents()
        source_header = window.table.horizontalHeader()
        result_header = window.results_table.horizontalHeader()
        window.table.setColumnWidth(0, 173)
        window.results_table.setColumnWidth(1, 149)
        self.assertEqual(window.results_table.columnWidth(0), 173)
        self.assertEqual(window.table.columnWidth(1), 149)
        self.assertGreater(window.table.horizontalScrollBar().maximum(), 0)

        for scroll in (window.table.horizontalScrollBar(), window.results_table.horizontalScrollBar()):
            scroll.setValue(min(60, scroll.maximum()))
            source_rect = next(source_header.group_rects())[2]
            result_rect = next(result_header.group_rects())[2]
            self.assertEqual(result_rect.width(), 173 + 149)
            self.assertEqual(result_rect.left(), source_rect.left())
            self.assertEqual(result_rect.right(), source_rect.right())
            self.assertEqual(result_rect.top(), 0)

    def test_copy_statistics_actions_publish_office_html_with_merged_parent(self):
        window = self.make_grouped_window()
        window.ui.copyStatisticsButton.click()
        copied = self.clipboard_table()
        self.assertEqual(copied.rows[0][:4], ["", "WT", "", ""])
        self.assertEqual(copied.rows[1][:4], ["", "Control", "Drug", "Other"])
        self.assertEqual(copied.merges, [CellMerge(0, 1, colspan=2)])

        self.select_table_range(window.results_table, 0, 0, 0, 1)
        window.copy_analysis_results_selection_with_headers()
        copied = self.clipboard_table()
        self.assertEqual(copied.rows[:2], [["", "WT", ""], ["", "Control", "Drug"]])
        self.assertEqual(copied.merges, [CellMerge(0, 1, colspan=2)])
        window.copy_analysis_results_selection()
        self.assertEqual(self.qapp.clipboard().text(), window.results_table.selection_tsv())
        self.assertNotIn("WT", self.qapp.clipboard().text())

    def test_excel_parent_header_paste_and_undo_sync_statistics_immediately(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Old": [1]}))
        window.table.setCurrentIndex(window.table.table_model.index(0, 0))
        mime = QMimeData()
        mime.setText("Excel batch\t\nA\tB\n2\t4")
        mime.setHtml(
            '<table><tr><td colspan="2">Excel batch</td></tr>'
            '<tr><td>A</td><td>B</td></tr><tr><td>2</td><td>4</td></tr></table>'
        )
        self.qapp.clipboard().setMimeData(mime)
        with mock.patch.object(window, "render") as render:
            window.paste_table_selection(window.table)
            self.assertEqual(self.group_labels(window.results_table), ["Excel batch"])
            self.assertEqual(window.results_table.table_clipboard_data().merges, [CellMerge(0, 1, colspan=2)])
            window.undo_table_change()
            self.assertEqual(self.group_labels(window.results_table), [])
            window.redo_table_change()
            self.assertEqual(self.group_labels(window.results_table), ["Excel batch"])
            render.assert_not_called()
