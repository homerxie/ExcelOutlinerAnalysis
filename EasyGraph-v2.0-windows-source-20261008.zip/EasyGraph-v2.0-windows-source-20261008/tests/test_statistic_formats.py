from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import tempfile
from unittest import mock

import pandas as pd
from PySide6.QtCore import QPoint, QRect, QTranslator
from PySide6.QtWidgets import QDialog, QDialogButtonBox

from tests.easygraph_case import ROOT, EasyGraphQtTestCase, EasyGraphTestCase
from easygraph.analysis_results import AnalysisSettings, descriptive_statistics_result
from easygraph.overlay_series import format_overlay_value, stat_table_data
from easygraph.project_io import read_workbook_project, write_project
from easygraph.settings import ChartSettings
from easygraph.statistic_formats import format_statistic_value, normalize_statistic_formats
from easygraph.template_io import apply_style_template_settings, style_template_settings_data
from easygraph.ui.statistic_format_dialog import StatisticFormatDialog
from easygraph.workbook import SheetDocument, WorkbookDocument


class StatisticFormatTests(EasyGraphTestCase):
    def test_each_statistic_uses_its_own_format_and_defaults_remain_compatible(self):
        settings = ChartSettings(
            line_value_decimals=2,
            statistic_formats={
                "Mean": {"decimals": 3},
                "Median": {"decimals": 0},
                "SD": {"decimals": 4, "scientific": True},
                "Max": {"decimals": 6, "trim_zeros": True},
            },
        )
        data = pd.DataFrame({"group": ["A"] * 3, "value": [1.1, 2.2, 4.4]})
        settings.show_stat_sd = settings.show_stat_sample_size = True
        _groups, rows = stat_table_data(data, settings)
        values = dict(rows)
        self.assertEqual(values["Mean"], ["2.567"])
        self.assertEqual(values["Median"], ["2"])
        self.assertEqual(values["SD"], ["1.6803e+00"])
        self.assertEqual(values["Max"], ["4.4"])
        self.assertEqual(values["Min"], ["1.10"])
        self.assertEqual(values["Sample"], ["3"])
        self.assertEqual(format_overlay_value(2.566666, settings, "Mean"), "2.567")
        self.assertEqual(format_overlay_value(2.566666, settings), "2.57")
        settings.line_value_decimals = 5
        self.assertEqual(format_overlay_value(2.566666, settings, "Mean"), "2.567")
        self.assertEqual(format_overlay_value(2.566666, settings, "Min"), "2.56667")

    def test_trim_zeros_preserves_integer_zeros_and_scientific_exponent(self):
        cases = (
            (1200, 0, False, "1200"),
            (1200, 4, False, "1200"),
            (1200, 4, True, "1.2e+03"),
            (0, 4, True, "0e+00"),
            (-0.012, 4, True, "-1.2e-02"),
            (1.234567890123, 12, False, "1.234567890123"),
        )
        for value, decimals, scientific, expected in cases:
            with self.subTest(value=value, decimals=decimals, scientific=scientific):
                self.assertEqual(format_statistic_value(value, "Mean", {
                    "Mean": {"decimals": decimals, "scientific": scientific, "trim_zeros": True},
                }), expected)

    def test_invalid_persisted_formats_are_normalized_and_counts_cannot_be_overridden(self):
        formats = {
            "Mean": {"decimals": 999, "scientific": "false"},
            "Median": {"decimals": -4},
            "SD": {"decimals": float("inf")},
            "SEM": "invalid", "Unknown": {"decimals": 3}, "Sample": {"decimals": 2},
        }
        result = normalize_statistic_formats(formats)
        self.assertEqual(set(result), {"Mean", "Median", "SD"})
        self.assertEqual(result["Mean"]["decimals"], 12)
        self.assertFalse(result["Mean"]["scientific"])
        self.assertEqual(result["Median"]["decimals"], 0)
        self.assertEqual(result["SD"]["decimals"], 2)
        self.assertEqual(AnalysisSettings(statistic_formats=formats).statistic_formats, result)
        self.assertEqual(ChartSettings(statistic_formats=[]).statistic_formats, {})

    def test_analysis_formats_keep_empty_results_and_do_not_round_source_data(self):
        frame = pd.DataFrame({"A": [1.111, 2.222, 4.444], "Empty": [None] * 3, "Single": [2, None, None]})
        before = frame.copy(deep=True)
        result = descriptive_statistics_result(frame, statistic_formats={
            "Mean": {"decimals": 4}, "Median": {"decimals": 0},
            "SD": {"decimals": 1, "scientific": True},
        })
        rows = dict(zip(result.row_labels, result.values))
        self.assertEqual(rows["Mean"], ("2.5923", "", "2.0000"))
        self.assertEqual(rows["Median"], ("2", "", "2"))
        self.assertEqual(rows["SD"], ("1.7e+00", "", ""))
        self.assertEqual(rows["Sample"], ("3", "", "1"))
        pd.testing.assert_frame_equal(before, frame)

    def test_project_and_style_template_roundtrip_chart_and_analysis_formats(self):
        settings = ChartSettings(statistic_formats={"Mean": {"decimals": 4, "trim_zeros": True}})
        analysis = AnalysisSettings(statistic_formats={"Mean": {"decimals": 1, "scientific": True}})
        sheet = SheetDocument(id="sheet", name="Data", dataframe=pd.DataFrame({"A": [1, 2]}), settings=settings, analysis_settings=analysis)
        workbook = WorkbookDocument([sheet], sheet.id)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "formats.eg"
            write_project(path, workbook)
            restored = read_workbook_project(path).active_sheet
        self.assertEqual(asdict(restored.settings), asdict(settings))
        self.assertEqual(asdict(restored.analysis_settings), asdict(analysis))
        template = ChartSettings(**style_template_settings_data(settings))
        applied = apply_style_template_settings(ChartSettings(), template)
        self.assertEqual(applied.statistic_formats, settings.statistic_formats)
        applied.statistic_formats["Mean"]["decimals"] = 0
        self.assertEqual(settings.statistic_formats["Mean"]["decimals"], 4)


class StatisticFormatUITests(EasyGraphQtTestCase):
    def test_dialog_previews_restore_defaults_and_cancel_does_not_mutate_input(self):
        source = {"Mean": {"decimals": 3, "scientific": False, "trim_zeros": False}}
        before = deepcopy(source)
        dialog = StatisticFormatDialog(source, default_decimals=4)
        self.addCleanup(dialog.close)
        override, decimals, notation, trim, preview = dialog.controls["Mean"]
        self.assertEqual(preview.text(), "1234.500")
        trim.setChecked(True)
        self.assertEqual(preview.text(), "1234.5")
        notation.setCurrentIndex(1)
        self.assertEqual(preview.text(), "1.234e+03")
        dialog.reject()
        self.assertEqual(source, before)
        dialog.button_box.button(QDialogButtonBox.StandardButton.RestoreDefaults).click()
        self.assertEqual(dialog.formats(), {})
        self.assertFalse(decimals.isEnabled())
        self.assertEqual(preview.text(), "1234.5000")

    def test_dialog_minimum_layout_fits_controls_and_preview(self):
        translator = QTranslator()
        self.assertTrue(translator.load(str(ROOT / "translations/easygraph_zh_CN.qm")))
        for chinese in (False, True):
            with self.subTest(chinese=chinese):
                if chinese:
                    self.qapp.installTranslator(translator)
                try:
                    dialog = StatisticFormatDialog({})
                    self.addCleanup(dialog.close)
                    dialog.resize(dialog.minimumSize())
                    dialog.show()
                    self.qapp.processEvents()
                    for widget in (dialog.description, dialog.defaults_label, dialog.table, dialog.button_box):
                        rect = QRect(widget.mapTo(dialog, QPoint(0, 0)), widget.size())
                        self.assertTrue(dialog.rect().contains(rect))
                    self.assertEqual(dialog.table.horizontalScrollBar().maximum(), 0)
                    self.assertEqual(dialog.table.verticalScrollBar().maximum(), 0)
                    if chinese:
                        self.assertEqual(dialog.windowTitle(), "统计类型数值格式")
                        self.assertEqual(dialog.button_box.button(QDialogButtonBox.StandardButton.Cancel).text(), "取消")
                    dialog.close()
                finally:
                    if chinese:
                        self.qapp.removeTranslator(translator)

    def test_buttons_commit_formats_and_cancel_preserves_settings(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": [1.1, 2.2, 4.4]}))
        formats = {"Mean": {"decimals": 4, "scientific": False, "trim_zeros": False}}
        with mock.patch.object(StatisticFormatDialog, "exec", return_value=QDialog.Accepted), mock.patch.object(StatisticFormatDialog, "formats", return_value=formats):
            window.ui.statisticNumberFormatsButton.click()
        window.flush_pending_render()
        self.assertEqual(window.settings.statistic_formats, formats)
        self.assertEqual(window.results_table.results_model.result.values[0][0], "2.57")
        with mock.patch.object(StatisticFormatDialog, "exec", return_value=QDialog.Rejected):
            window.ui.labelNumberFormatsButton.click()
        self.assertEqual(window.settings.statistic_formats, formats)
        with mock.patch.object(StatisticFormatDialog, "exec", return_value=QDialog.Accepted), mock.patch.object(StatisticFormatDialog, "formats", return_value=formats):
            window.ui.analysisNumberFormatsButton.click()
        self.assertEqual(window.results_table.results_model.result.values[0][0], "2.5667")
        window.copy_analysis_results_table()
        self.assertIn("2.5667", self.qapp.clipboard().text())
        self.assertTrue(window.has_unsaved_changes())

    def test_formats_switch_and_save_per_sheet(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": [1.1, 2.2, 4.4]}))
        formats = {"Mean": {"decimals": 4, "scientific": False, "trim_zeros": False}}
        window.settings.statistic_formats = deepcopy(formats)
        window.workbook.active_sheet.analysis_settings.statistic_formats = deepcopy(formats)
        window.add_sheet()
        self.assertEqual(window.settings.statistic_formats, {})
        self.assertEqual(window.workbook.active_sheet.analysis_settings.statistic_formats, {})
        window.sheet_tab_bar.setCurrentIndex(0)
        self.assertEqual(window.settings.statistic_formats, formats)
        self.assertEqual(window.results_table.results_model.result.values[0][0], "2.5667")
        with tempfile.TemporaryDirectory() as tmp:
            window.current_project = Path(tmp) / "formats.eg"
            self.assertTrue(window.save_project())
            restored = self.make_window()
            restored._load_project_path(window.current_project)
        self.assertEqual(restored.settings.statistic_formats, formats)
        self.assertEqual(restored.results_table.results_model.result.values[0][0], "2.5667")

    def test_all_chart_types_and_label_positions_apply_statistic_formats(self):
        window = self.make_window()
        frame = pd.DataFrame({"A": [1.1, 2.2, 4.4]})
        for chart_type, positions in (("Box", ("Auto", "Top axis")), ("Violin", ("Auto",)), ("Ridge", ("Auto", "Axis left"))):
            for statistic, expected in (("Mean", "2.5667"), ("Median", "2.2")):
                for position in positions:
                    with self.subTest(chart_type=chart_type, statistic=statistic, position=position):
                        settings = ChartSettings(
                            chart_type=chart_type, line_overlay_stat=statistic,
                            show_line_values=True, line_value_position=position,
                            extra_custom_overlay=True,
                            custom_overlay_series=[{"name": "Mean", "values": {"A": "5.5"}}],
                            statistic_formats={"Mean": {"decimals": 4}, "Median": {"decimals": 1}},
                        )
                        window.canvas.render(frame, settings)
                        plot, table = window.canvas.figure.axes[:2]
                        labels = [text.get_text() for text in plot.texts]
                        self.assertIn(expected, labels)
                        self.assertIn("5.50", labels)
                        table_values = [text.get_text() for text in table.texts]
                        self.assertIn("2.5667", table_values)
                        self.assertIn("2.2", table_values)

    def test_shared_defaults_remain_editable_with_only_statistics_table_visible(self):
        window = self.make_window()
        window.line_overlay_stat.setCurrentText("None")
        window.extra_custom_overlay.setChecked(False)
        window.show_stat_table.setChecked(True)
        window._update_dependent_control_states()
        self.assertTrue(window.line_value_decimals.isEnabled())
        self.assertTrue(window.line_value_scientific.isEnabled())
