from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import mock

import pandas as pd

from easygraph.app_preferences import RECENT_PROJECTS_SETTING_KEY
from easygraph.data import sample_data
from easygraph.project_io import read_workbook_project, write_project
from easygraph.settings import ChartSettings
from easygraph.ui.main_window import MainWindow
from easygraph.workbook import SHEET_MODE_GROUPS, SHEET_MODE_XY
from tests.easygraph_case import EasyGraphQtTestCase, patch_qsettings


class StartupGroupedDemoTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        template_patch = mock.patch.object(
            MainWindow, "_style_template_for_new_sheet", return_value=(None, None),
        )
        self.template = template_patch.start()
        self.addCleanup(template_patch.stop)
        preferences_patch, self.preferences = patch_qsettings()
        preferences_patch.start()
        self.addCleanup(preferences_patch.stop)

    def test_existing_single_header_demo_is_unchanged(self):
        window = self.make_window()
        sheet = window._demo_sheet_document(SHEET_MODE_GROUPS, "Demo")

        pd.testing.assert_frame_equal(sheet.dataframe, sample_data())
        self.assertFalse(sheet.grouping.parents)
        self.assertFalse(sheet.grouping.shared_subgroups)
        self.assertEqual(sheet.grouping.subgroup_ids, {})

    def test_grouped_demo_has_independent_repeatable_samples_and_shared_subheaders(self):
        window = self.make_window()
        first = window._demo_sheet_document(SHEET_MODE_GROUPS, "Demo", grouped_demo=True)
        second = window._demo_sheet_document(SHEET_MODE_GROUPS, "Demo", grouped_demo=True)

        pd.testing.assert_frame_equal(first.dataframe, second.dataframe)
        self.assertEqual(first.column_ids, second.column_ids)
        self.assertEqual(len(first.column_ids), len(set(first.column_ids)))
        self.assertEqual(first.dataframe.shape, (14, 6))
        self.assertTrue(first.dataframe.notna().all().all())
        self.assertEqual(
            list(first.dataframe.columns), ["Control", "Low dose", "High dose"] * 2,
        )
        self.assertEqual([parent["name"] for parent in first.grouping.parents], ["WT", "KO"])
        self.assertEqual(
            [parent["column_ids"] for parent in first.grouping.parents],
            [first.column_ids[:3], first.column_ids[3:]],
        )
        self.assertTrue(first.grouping.shared_subgroups)
        for index in range(3):
            self.assertFalse(first.dataframe.iloc[:, index].equals(first.dataframe.iloc[:, index + 3]))
            self.assertEqual(
                first.grouping.subgroup_ids[first.column_ids[index]],
                first.grouping.subgroup_ids[first.column_ids[index + 3]],
            )

    def test_grouped_startup_renders_both_levels_with_matching_colors_and_roundtrips(self):
        window = self.make_window()
        window.initialize_startup_project(SHEET_MODE_GROUPS, demo=True, grouped_demo=True)
        window.render()

        sheet = window.workbook.active_sheet
        layout = window.canvas._group_layout
        self.assertEqual([parent.label for parent in layout.parents], ["WT", "KO"])
        self.assertEqual(len(layout.order), 6)
        self.assertEqual(list(layout.labels.values()), ["Control", "Low dose", "High dose"] * 2)
        self.assertEqual(len(layout.legend), 3)
        self.assertGreater(
            layout.positions[sheet.column_ids[3]] - layout.positions[sheet.column_ids[2]],
            layout.positions[sheet.column_ids[1]] - layout.positions[sheet.column_ids[0]],
        )
        for index in range(3):
            self.assertEqual(layout.colors[sheet.column_ids[index]], layout.colors[sheet.column_ids[index + 3]])

        window._store_active_sheet()
        with TemporaryDirectory() as directory:
            path = Path(directory) / "two-level.eg"
            write_project(path, window.workbook)
            loaded = read_workbook_project(path).active_sheet
        pd.testing.assert_frame_equal(
            loaded.dataframe.apply(pd.to_numeric, errors="coerce"),
            sheet.dataframe.apply(pd.to_numeric, errors="coerce"),
        )
        self.assertEqual(loaded.column_ids, sheet.column_ids)
        self.assertEqual(asdict(loaded.grouping), asdict(sheet.grouping))

    def test_grouped_startup_keeps_template_style_and_clean_unsaved_document(self):
        window = self.make_window()
        self.preferences[RECENT_PROJECTS_SETTING_KEY] = ["/tmp/existing.eg"]
        window.current_project = Path("/tmp/existing.eg")
        self.template.return_value = (ChartSettings(chart_type="Bar", tick_font_size=15), None)

        with mock.patch.object(window, "render") as render:
            window.initialize_startup_project(SHEET_MODE_GROUPS, demo=True, grouped_demo=True)

        render.assert_not_called()
        self.assertEqual(window.settings.chart_type, "Bar")
        self.assertEqual(window.settings.tick_font_size, 15)
        self.assertIsNone(window.current_project)
        self.assertEqual(self.preferences[RECENT_PROJECTS_SETTING_KEY], ["/tmp/existing.eg"])
        self.assertFalse(window.has_unsaved_changes())
        self.assertEqual(window.sheet_tab_bar.tabText(0), "Sheet 1")

    def test_blank_startup_does_not_add_demo_data_or_parent_headers(self):
        window = self.make_window()
        window.initialize_startup_project(SHEET_MODE_GROUPS, demo=True, grouped_demo=True)
        window.initialize_startup_project(SHEET_MODE_GROUPS, demo=False, grouped_demo=True)

        self.assertTrue((window.table.dataframe() == "").all().all())
        self.assertFalse(window.workbook.active_sheet.grouping.parents)
        self.assertFalse(window.has_unsaved_changes())

    def test_xy_demo_ignores_grouped_header_choice(self):
        window = self.make_window()
        plain = window._demo_sheet_document(SHEET_MODE_XY, "Demo")
        grouped = window._demo_sheet_document(SHEET_MODE_XY, "Demo", grouped_demo=True)

        pd.testing.assert_frame_equal(plain.dataframe, grouped.dataframe)
        self.assertEqual(grouped.mode, SHEET_MODE_XY)
        self.assertFalse(grouped.grouping.parents)
        self.assertEqual(grouped.settings, plain.settings)
        self.assertEqual(
            [series.name for series in grouped.xy_settings.series],
            [series.name for series in plain.xy_settings.series],
        )
