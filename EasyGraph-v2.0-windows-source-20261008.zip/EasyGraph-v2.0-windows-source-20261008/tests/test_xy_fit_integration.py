from __future__ import annotations

from copy import deepcopy
from dataclasses import replace
import time
from types import SimpleNamespace
from unittest import mock

import numpy as np
import pandas as pd
from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import QDialog

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.plotting.canvas import PlotCanvas
from easygraph.plotting.xy_fit_renderer import (
    draw_xy_fit_curves,
    draw_xy_fit_equation_labels,
)
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.colors import to_rgba
from matplotlib.figure import Figure
from easygraph.settings import ChartSettings
from easygraph.workbook import SHEET_MODE_XY, SheetDocument
from easygraph.xy_data import prepare_xy_data
from easygraph.xy_fitting import FitParameterSpec, default_fit_spec, fit_xy_values
from easygraph.xy_series import XYSeriesSpec, XYSettings, XYSharedTableSpec


class XYFitIntegrationTests(EasyGraphQtTestCase):
    @staticmethod
    def fit_fixture(*, visible: bool = True):
        dataframe = pd.DataFrame({"X": [0.0, 1.0, 2.0, 3.0], "Y": [1.0, 3.0, 5.0, 7.0]})
        series = XYSeriesSpec(
            id="series-a",
            name="Response",
            y_column_id="y",
            visible=visible,
            color="#C2410C",
        )
        spec = default_fit_spec(series.id, "linear")
        settings = XYSettings(
            default_x_column_id="x",
            series=[series],
            fit_specs=[spec],
        )
        result = fit_xy_values(dataframe["X"], dataframe["Y"], spec)
        return dataframe, settings, spec, result

    def test_renderer_draws_successful_fit_with_inherited_color_and_no_duplicate_legend(self):
        dataframe, settings, spec, result = self.fit_fixture()
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        figure = Figure()
        ax = figure.add_subplot(111)

        artists = draw_xy_fit_curves(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
        )

        self.assertEqual(len(artists), 1)
        self.assertEqual(artists[0].get_color(), "#C2410C")
        self.assertEqual(artists[0].get_linestyle(), "--")
        self.assertEqual(artists[0].get_label(), "_nolegend_")
        self.assertEqual(artists[0]._easygraph_series_id, "series-a")
        self.assertEqual(artists[0]._easygraph_fit_id, spec.id)

    def test_renderer_omits_fit_when_source_series_is_hidden(self):
        dataframe, settings, spec, result = self.fit_fixture(visible=False)
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        ax = Figure().add_subplot(111)

        artists = draw_xy_fit_curves(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
        )

        self.assertEqual(artists, [])

    def test_renderer_keeps_nan_gaps_in_partially_undefined_custom_curves(self):
        dataframe, settings, spec, result = self.fit_fixture()
        result = replace(
            result,
            curve_x=(0.0, 1.0, 2.0),
            curve_y=(1.0, float("nan"), 3.0),
        )
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        ax = Figure().add_subplot(111)

        artist = draw_xy_fit_curves(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
        )[0]

        self.assertEqual(len(artist.get_ydata()), 3)
        self.assertTrue(np.isnan(artist.get_ydata()[1]))

    def test_equation_renderer_draws_opt_in_mathtext_without_changing_lines_limits_or_legend(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_equation = True
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        figure = Figure(figsize=(6.0, 4.0), dpi=100)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_subplot(111)
        draw_xy_fit_curves(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
        )
        ax.set_xlim(-0.5, 3.5)
        ax.set_ylim(-1.0, 9.0)
        canvas.draw()
        original_limits = (ax.get_xlim(), ax.get_ylim())
        original_line_count = len(ax.lines)
        original_legend = ax.get_legend_handles_labels()[1]

        labels = draw_xy_fit_equation_labels(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
            text_color="#222222",
            background_color="#FFFFFF",
            font_size=10,
            renderer=canvas.get_renderer(),
        )
        canvas.draw()

        self.assertEqual(len(labels), 1)
        label = labels[0]
        self.assertTrue(label.get_text().startswith("$"))
        self.assertIn(r"\approx", label.get_text())
        self.assertEqual(label.get_rotation(), 0.0)
        self.assertEqual(label.get_gid(), "xy-fit-equation")
        self.assertEqual(label.get_label(), "_nolegend_")
        self.assertEqual(label._easygraph_fit_id, spec.id)
        self.assertEqual(label._easygraph_series_id, "series-a")
        self.assertFalse(label.get_picker())
        self.assertEqual(to_rgba(label.get_color()), to_rgba("#C2410C"))
        self.assertEqual(
            label.get_bbox_patch().get_edgecolor()[:3],
            to_rgba("#C2410C")[:3],
        )
        self.assertAlmostEqual(
            label.get_bbox_patch().get_facecolor()[3],
            0.88,
        )
        self.assertEqual(len(ax.lines), original_line_count)
        self.assertEqual(ax.get_legend_handles_labels()[1], original_legend)
        self.assertEqual((ax.get_xlim(), ax.get_ylim()), original_limits)

        label.remove()
        # #808080 passes the old 3:1 threshold against white but not WCAG's
        # 4.5:1 threshold for small text. The fit color remains on the border.
        spec.color = "#808080"
        low_contrast_labels = draw_xy_fit_equation_labels(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
            text_color="#222222",
            background_color="#FFFFFF",
            font_size=10,
            renderer=canvas.get_renderer(),
        )
        self.assertEqual(len(low_contrast_labels), 1)
        self.assertEqual(
            to_rgba(low_contrast_labels[0].get_color()),
            to_rgba("#222222"),
        )
        self.assertEqual(
            low_contrast_labels[0].get_bbox_patch().get_edgecolor()[:3],
            to_rgba("#808080")[:3],
        )

    def test_equation_renderer_uses_saved_axes_fraction_position(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_equation = True
        spec.equation_position_x = 0.35
        spec.equation_position_y = 0.72
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        figure = Figure(figsize=(6.0, 4.0), dpi=100)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_subplot(111)
        ax.set_xlim(-0.5, 3.5)
        ax.set_ylim(-1.0, 9.0)
        canvas.draw()

        labels = draw_xy_fit_equation_labels(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
            text_color="#222222",
            background_color="#FFFFFF",
            font_size=10,
            renderer=canvas.get_renderer(),
        )
        canvas.draw()

        self.assertEqual(len(labels), 1)
        label = labels[0]
        self.assertEqual(label._easygraph_equation_layout, "manual")
        np.testing.assert_allclose(
            label._easygraph_text_axes_fraction,
            (0.35, 0.72),
            atol=0.01,
        )
        bounds = label.get_bbox_patch().get_window_extent(
            canvas.get_renderer()
        )
        axis_bounds = ax.get_window_extent(canvas.get_renderer())
        self.assertGreaterEqual(bounds.x0, axis_bounds.x0)
        self.assertLessEqual(bounds.x1, axis_bounds.x1)
        self.assertGreaterEqual(bounds.y0, axis_bounds.y0)
        self.assertLessEqual(bounds.y1, axis_bounds.y1)

    def test_annotation_renderer_can_show_selected_parameter_values(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_equation = True
        spec.annotation_parameter_names = ["slope"]
        settings.fit_annotation_mode = "parameters"
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        figure = Figure(figsize=(6.0, 4.0), dpi=100)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_subplot(111)
        ax.set_xlim(-0.5, 3.5)
        ax.set_ylim(-1.0, 9.0)
        canvas.draw()

        labels = draw_xy_fit_equation_labels(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
            text_color="#222222",
            background_color="#FFFFFF",
            font_size=10,
            renderer=canvas.get_renderer(),
        )
        canvas.draw()

        self.assertEqual(len(labels), 1)
        self.assertIn(r"\mathrm{slope} = 2", labels[0].get_text())
        self.assertNotIn("intercept", labels[0].get_text())
        self.assertNotIn(r"y \approx", labels[0].get_text())

    def test_canvas_drags_equation_before_box_selection_and_double_click_resets(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_equation = True
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        callback = mock.Mock()
        canvas.fit_equation_position_callback = callback
        canvas.render(
            dataframe,
            ChartSettings(chart_type="Scatter", show_stat_table=False),
            xy_settings=settings,
            column_ids=["x", "y"],
            xy_fit_results={spec.id: result},
        )
        target = next(
            item
            for item in canvas._interaction_targets
            if item["kind"] == "fit_equation"
        )
        bounds = target["bbox"]
        center_x = (bounds.x0 + bounds.x1) / 2.0
        center_y = (bounds.y0 + bounds.y1) / 2.0

        canvas.set_xy_box_select_enabled(True)
        canvas._handle_plot_click(
            SimpleNamespace(
                x=center_x,
                y=center_y,
                button=1,
                dblclick=True,
            )
        )
        callback.assert_called_once_with(spec.id, None, None)
        self.assertIsNone(canvas._xy_box_select_state)
        callback.reset_mock()

        press = SimpleNamespace(
            x=center_x,
            y=center_y,
            button=1,
            dblclick=False,
        )
        annotation = target["artist"]
        original_anncoords = annotation.get_anncoords()
        original_position = annotation.xyann
        canvas._handle_plot_click(press)
        canvas._handle_plot_release(press)
        callback.assert_not_called()
        self.assertEqual(annotation.get_anncoords(), original_anncoords)
        self.assertEqual(annotation.xyann, original_position)

        motion = SimpleNamespace(
            x=center_x + 52.0,
            y=center_y - 31.0,
            button=1,
        )
        canvas._handle_plot_click(press)
        self.assertIsNotNone(canvas._fit_equation_drag_state)
        self.assertIsNone(canvas._xy_box_select_state)
        canvas._handle_plot_motion(motion)
        canvas._handle_plot_release(motion)

        self.assertIsNone(canvas._fit_equation_drag_state)
        callback.assert_called_once()
        fit_id, position_x, position_y = callback.call_args.args
        self.assertEqual(fit_id, spec.id)
        self.assertGreaterEqual(position_x, 0.0)
        self.assertLessEqual(position_x, 1.0)
        self.assertGreaterEqual(position_y, 0.0)
        self.assertLessEqual(position_y, 1.0)
        self.assertGreater(position_x, 0.0)

    def test_equation_renderer_skips_disabled_failed_hidden_and_opted_out_fits(self):
        dataframe, settings, spec, result = self.fit_fixture()
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        figure = Figure(figsize=(6.0, 4.0), dpi=100)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_subplot(111)
        ax.set_xlim(-0.5, 3.5)
        ax.set_ylim(-1.0, 9.0)
        canvas.draw()

        def draw(candidate_settings, candidate_prepared, candidate_result):
            return draw_xy_fit_equation_labels(
                ax,
                candidate_prepared,
                candidate_settings,
                {spec.id: candidate_result},
                ["#0000FF"],
                text_color="#222222",
                background_color="#FFFFFF",
                font_size=10,
                renderer=canvas.get_renderer(),
            )

        self.assertEqual(draw(settings, prepared, result), [])
        spec.show_equation = True
        self.assertEqual(draw(settings, prepared, replace(result, success=False)), [])
        spec.enabled = False
        self.assertEqual(draw(settings, prepared, result), [])
        spec.enabled = True
        unreliable = replace(result, equation_display_reliable=False)
        self.assertEqual(draw(settings, prepared, unreliable), [])
        with mock.patch(
            "easygraph.plotting.xy_fit_renderer.format_fitted_equation_for_curve",
            return_value=None,
        ):
            self.assertEqual(draw(settings, prepared, result), [])
        self.assertEqual(
            len(
                draw_xy_fit_curves(
                    ax,
                    prepared,
                    settings,
                    {spec.id: unreliable},
                    ["#0000FF"],
                )
            ),
            1,
        )

        _hidden_dataframe, hidden_settings, hidden_spec, hidden_result = self.fit_fixture(
            visible=False
        )
        hidden_spec.show_equation = True
        hidden_prepared = prepare_xy_data(
            dataframe,
            ["x", "y"],
            hidden_settings,
        )
        self.assertEqual(
            draw_xy_fit_equation_labels(
                ax,
                hidden_prepared,
                hidden_settings,
                {hidden_spec.id: hidden_result},
                ["#0000FF"],
                text_color="#222222",
                background_color="#FFFFFF",
                font_size=10,
                renderer=canvas.get_renderer(),
            ),
            [],
        )

    def test_equation_renderer_anchors_only_to_visible_finite_run(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_equation = True
        result = replace(
            result,
            curve_x=(0.0, 1.0, 2.0, 3.0, 4.0),
            curve_y=(1.0, 3.0, float("nan"), 7.0, 9.0),
        )
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        figure = Figure(figsize=(6.0, 4.0), dpi=100)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_subplot(111)
        ax.set_xlim(2.5, 4.5)
        ax.set_ylim(5.5, 9.5)
        canvas.draw()

        labels = draw_xy_fit_equation_labels(
            ax,
            prepared,
            settings,
            {spec.id: result},
            ["#0000FF"],
            text_color="#222222",
            background_color="#FFFFFF",
            font_size=10,
            renderer=canvas.get_renderer(),
        )

        self.assertEqual(len(labels), 1)
        anchor_x, anchor_y = labels[0]._easygraph_anchor_data
        self.assertGreaterEqual(anchor_x, 3.0)
        self.assertLessEqual(anchor_x, 4.0)
        self.assertGreaterEqual(anchor_y, 7.0)
        self.assertLessEqual(anchor_y, 9.0)

        labels[0].remove()
        ax.set_xlim(10.0, 11.0)
        ax.set_ylim(10.0, 11.0)
        canvas.draw()
        self.assertEqual(
            draw_xy_fit_equation_labels(
                ax,
                prepared,
                settings,
                {spec.id: result},
                ["#0000FF"],
                text_color="#222222",
                background_color="#FFFFFF",
                font_size=10,
                renderer=canvas.get_renderer(),
            ),
            [],
        )

    def test_equation_renderer_separates_multiple_fit_labels(self):
        data = {"X": [0.0, 1.0, 2.0, 3.0]}
        series = []
        specs = []
        column_ids = ["x"]
        for index in range(5):
            column_id = f"y-{index}"
            data[f"Y {index}"] = [1.0, 3.0, 5.0, 7.0]
            column_ids.append(column_id)
            series_spec = XYSeriesSpec(
                id=f"series-{index}",
                name=f"Series {index}",
                y_column_id=column_id,
            )
            fit_spec = default_fit_spec(series_spec.id, "linear")
            fit_spec.show_equation = True
            series.append(series_spec)
            specs.append(fit_spec)
        dataframe = pd.DataFrame(data)
        settings = XYSettings(
            default_x_column_id="x",
            series=series,
            fit_specs=specs,
        )
        prepared = prepare_xy_data(dataframe, column_ids, settings)
        results = {
            spec.id: fit_xy_values(
                dataframe["X"],
                dataframe.iloc[:, index + 1],
                spec,
            )
            for index, spec in enumerate(specs)
        }
        figure = Figure(figsize=(7.0, 4.0), dpi=100)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_subplot(111)
        ax.set_xlim(-0.5, 3.5)
        ax.set_ylim(-1.0, 9.0)
        canvas.draw()

        labels = draw_xy_fit_equation_labels(
            ax,
            prepared,
            settings,
            results,
            ["#4E79A7", "#E15759", "#59A14F", "#F28E2B", "#B07AA1"],
            text_color="#222222",
            background_color="#FFFFFF",
            font_size=10,
            renderer=canvas.get_renderer(),
        )
        canvas.draw()

        self.assertEqual(len(labels), 5)
        renderer = canvas.get_renderer()
        bounds = [
            label.get_bbox_patch().get_window_extent(renderer)
            for label in labels
        ]
        for first_index, first_bounds in enumerate(bounds):
            for second_bounds in bounds[first_index + 1 :]:
                self.assertFalse(first_bounds.overlaps(second_bounds))
        self.assertIn(
            "rail",
            {label._easygraph_equation_layout for label in labels},
        )

    def test_equation_renderer_shrinks_long_mathtext_without_truncating_it(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_equation = True
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        figure = Figure(figsize=(4.0, 3.0), dpi=100)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_subplot(111)
        ax.set_xlim(-0.5, 3.5)
        ax.set_ylim(-1.0, 9.0)
        canvas.draw()
        long_equation = "$y \\approx " + " + ".join(
            f"{index + 1}.234x^{{{index + 1}}}"
            for index in range(30)
        ) + "$"
        original_limits = (ax.get_xlim(), ax.get_ylim())

        with mock.patch(
            "easygraph.plotting.xy_fit_renderer.format_fitted_equation_for_curve",
            return_value=long_equation,
        ):
            labels = draw_xy_fit_equation_labels(
                ax,
                prepared,
                settings,
                {spec.id: result},
                ["#0000FF"],
                text_color="#222222",
                background_color="#FFFFFF",
                font_size=18,
                renderer=canvas.get_renderer(),
            )

        self.assertEqual(len(labels), 1)
        self.assertEqual(
            labels[0].get_text().replace("$\n$", ""),
            long_equation,
        )
        self.assertNotIn("...", labels[0].get_text())
        self.assertNotIn("…", labels[0].get_text())
        self.assertLess(labels[0].get_fontsize(), 18.0)
        self.assertEqual(labels[0]._easygraph_equation_layout, "rail")
        self.assertEqual(labels[0]._textcoords, "axes fraction")
        self.assertTrue(
            all(
                0.0 <= value <= 1.0
                for value in labels[0]._easygraph_text_axes_fraction
            )
        )
        self.assertEqual((ax.get_xlim(), ax.get_ylim()), original_limits)

    def test_equation_renderer_dense_fallback_is_bounded_and_user_visible(self):
        fit_count = 30
        data = {"X": [0.0, 1.0, 2.0, 3.0]}
        series = []
        specs = []
        column_ids = ["x"]
        for index in range(fit_count):
            column_id = f"y-{index}"
            data[f"Y {index}"] = [1.0, 3.0, 5.0, 7.0]
            column_ids.append(column_id)
            series_spec = XYSeriesSpec(
                id=f"dense-series-{index}",
                name=f"Dense {index}",
                y_column_id=column_id,
            )
            fit_spec = default_fit_spec(series_spec.id, "linear")
            fit_spec.show_equation = True
            series.append(series_spec)
            specs.append(fit_spec)
        dataframe = pd.DataFrame(data)
        settings = XYSettings(
            default_x_column_id="x",
            series=series,
            fit_specs=specs,
        )
        prepared = prepare_xy_data(dataframe, column_ids, settings)
        results = {
            spec.id: fit_xy_values(
                dataframe["X"],
                dataframe.iloc[:, index + 1],
                spec,
            )
            for index, spec in enumerate(specs)
        }
        figure = Figure(figsize=(6.0, 4.0), dpi=100)
        canvas = FigureCanvasAgg(figure)
        ax = figure.add_subplot(111)
        ax.set_xlim(-0.5, 3.5)
        ax.set_ylim(-1.0, 9.0)
        canvas.draw()
        original_limits = (ax.get_xlim(), ax.get_ylim())
        original_line_count = len(ax.lines)

        started = time.perf_counter()
        labels = draw_xy_fit_equation_labels(
            ax,
            prepared,
            settings,
            results,
            ["#4E79A7"],
            text_color="#222222",
            background_color="#FFFFFF",
            font_size=10,
            renderer=canvas.get_renderer(),
        )
        elapsed = time.perf_counter() - started

        self.assertGreaterEqual(len(labels), 10)
        self.assertLess(elapsed, 2.0)
        self.assertEqual(len(ax.lines), original_line_count)
        self.assertEqual((ax.get_xlim(), ax.get_ylim()), original_limits)

    def test_equation_renderer_rail_position_is_dpi_independent(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_equation = True
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        long_equation = "$y \\approx " + " + ".join(
            f"{index + 1}.234x^{{{index + 1}}}"
            for index in range(30)
        ) + "$"
        placements = []

        with mock.patch(
            "easygraph.plotting.xy_fit_renderer.format_fitted_equation_for_curve",
            return_value=long_equation,
        ):
            for dpi in (100, 600):
                figure = Figure(figsize=(4.0, 3.0), dpi=dpi)
                canvas = FigureCanvasAgg(figure)
                ax = figure.add_subplot(111)
                ax.set_xlim(-0.5, 3.5)
                ax.set_ylim(-1.0, 9.0)
                canvas.draw()
                labels = draw_xy_fit_equation_labels(
                    ax,
                    prepared,
                    settings,
                    {spec.id: result},
                    ["#0000FF"],
                    text_color="#222222",
                    background_color="#FFFFFF",
                    font_size=18,
                    renderer=canvas.get_renderer(),
                )
                canvas.draw()

                self.assertEqual(len(labels), 1)
                self.assertEqual(labels[0]._easygraph_equation_layout, "rail")
                self.assertEqual(labels[0]._textcoords, "axes fraction")
                placements.append(
                    (
                        labels[0]._easygraph_text_axes_fraction,
                        labels[0].get_text(),
                        labels[0].get_fontsize(),
                    )
                )

        np.testing.assert_allclose(placements[0][0], placements[1][0])
        self.assertEqual(placements[0][1:], placements[1][1:])

    def test_canvas_includes_fit_curve_in_auto_range_and_cached_rerender_state(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_equation = True
        extended = replace(
            result,
            # Keep the synthetic extended curve faithful to y = 2x + 1 so the
            # renderer-facing equation formatter can safely annotate it.
            curve_x=(0.0, 1.0, 2.0, 12.0),
            curve_y=(1.0, 3.0, 5.0, 25.0),
        )
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)

        canvas.render(
            dataframe,
            ChartSettings(chart_type="Scatter", show_stat_table=False),
            xy_settings=settings,
            column_ids=["x", "y"],
            xy_fit_results={spec.id: extended},
        )

        fit_lines = [
            line
            for line in canvas.figure.axes[0].lines
            if getattr(line, "_easygraph_fit_id", None) == spec.id
        ]
        self.assertEqual(len(fit_lines), 1)
        equation_labels = [
            text
            for text in canvas.figure.axes[0].texts
            if text.get_gid() == "xy-fit-equation"
        ]
        self.assertEqual(len(equation_labels), 1)
        self.assertIn(r"y \approx", equation_labels[0].get_text())
        self.assertGreater(canvas.figure.axes[0].get_ylim()[1], 25.0)
        self.assertIs(canvas._last_xy_fit_results[spec.id], extended)

    def test_canvas_reuses_supplied_prepared_xy_data_and_clears_it_for_group_render(self):
        dataframe, settings, spec, result = self.fit_fixture()
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)

        with mock.patch(
            "easygraph.plotting.canvas.prepare_xy_data",
            wraps=prepare_xy_data,
        ) as prepare_spy:
            canvas.render(
                dataframe,
                ChartSettings(chart_type="Scatter", show_stat_table=False),
                xy_settings=settings,
                column_ids=["x", "y"],
                xy_fit_results={spec.id: result},
                prepared_xy_data=prepared,
            )
            canvas._rerender_last()

        prepare_spy.assert_not_called()
        self.assertIs(canvas._last_prepared_xy_data, prepared)

        canvas.render(
            pd.DataFrame({"group": ["A"], "value": [1.0]}),
            ChartSettings(show_stat_table=False),
        )
        self.assertIsNone(canvas._last_prepared_xy_data)

    def test_outside_legend_width_includes_successful_visible_fit_label(self):
        dataframe, settings, spec, result = self.fit_fixture()
        spec.show_in_legend = True
        prepared = prepare_xy_data(dataframe, ["x", "y"], settings)
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)

        with mock.patch.object(
            canvas,
            "_legend_render_width_inches",
            wraps=canvas._legend_render_width_inches,
        ) as width_spy:
            canvas.render(
                dataframe,
                ChartSettings(
                    chart_type="Scatter",
                    show_stat_table=False,
                    show_legend=True,
                ),
                xy_settings=settings,
                column_ids=["x", "y"],
                xy_fit_results={spec.id: result},
                prepared_xy_data=prepared,
            )

        self.assertEqual(
            width_spy.call_args.args[0],
            ["Response", "Response (fit)"],
        )
        self.assertEqual(
            [text.get_text() for text in canvas.figure.axes[0].get_legend().texts],
            ["Response", "Response (fit)"],
        )

    def test_numeric_cache_ignores_style_changes_but_invalidates_data_changes(self):
        dataframe, settings, spec, result = self.fit_fixture()
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        _jobs, signatures = window._xy_fit_jobs_and_signatures(
            sheet,
            dataframe,
            auto_only=True,
        )
        window._xy_fit_results_by_sheet[sheet.id] = {spec.id: result}
        window._xy_fit_signatures_by_sheet[sheet.id] = dict(signatures)

        style_only = deepcopy(sheet)
        style_only.xy_settings.fit_specs[0].color = "#00AA00"
        style_only.xy_settings.fit_specs[0].line_width = 4.0
        style_only.xy_settings.fit_specs[0].show_equation = True
        style_only.xy_settings.fit_specs[0].annotation_parameter_names = [
            "slope"
        ]
        style_only.xy_settings.fit_specs[0].equation_position_x = 0.2
        style_only.xy_settings.fit_specs[0].equation_position_y = 0.8
        style_only.xy_settings.fit_annotation_mode = "parameters"
        _jobs, style_signatures = window._xy_fit_jobs_and_signatures(
            style_only,
            dataframe,
            auto_only=True,
        )
        self.assertEqual(style_signatures, signatures)
        with mock.patch.object(window._xy_fit_timer, "start") as timer_start:
            rendered = window._xy_fit_results_for_render(style_only, dataframe)
        self.assertIn(spec.id, rendered)
        timer_start.assert_not_called()

        changed_data = dataframe.copy()
        changed_data.loc[3, "Y"] = 8.0
        with mock.patch.object(window._xy_fit_timer, "start") as timer_start:
            rendered = window._xy_fit_results_for_render(style_only, changed_data)
        self.assertNotIn(spec.id, rendered)
        timer_start.assert_called_once()

    def test_main_window_persists_and_resets_dragged_equation_position(self):
        dataframe, settings, spec, _result = self.fit_fixture()
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=False)
        active_spec = window.workbook.active_sheet.xy_settings.fit_specs[0]

        with (
            mock.patch.object(window, "_record_recovery_sheet_state") as record,
            mock.patch.object(window, "render") as render,
        ):
            window.handle_fit_equation_drag_position(spec.id, 1.5, -0.5)

        self.assertEqual(active_spec.equation_position_x, 1.0)
        self.assertEqual(active_spec.equation_position_y, 0.0)
        record.assert_called_once_with()
        render.assert_called_once_with()

        with (
            mock.patch.object(window, "_record_recovery_sheet_state") as record,
            mock.patch.object(window, "render") as render,
        ):
            window.handle_fit_equation_drag_position(spec.id, None, None)

        self.assertIsNone(active_spec.equation_position_x)
        self.assertIsNone(active_spec.equation_position_y)
        record.assert_called_once_with()
        render.assert_called_once_with()

    def test_main_window_render_prepares_xy_data_only_once(self):
        dataframe, settings, _spec, _result = self.fit_fixture()
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=False)

        with (
            mock.patch(
                "easygraph.ui.main_window.prepare_xy_data",
                wraps=prepare_xy_data,
            ) as window_prepare,
            mock.patch(
                "easygraph.plotting.canvas.prepare_xy_data",
                wraps=prepare_xy_data,
            ) as canvas_prepare,
        ):
            window.render()

        window._xy_fit_timer.stop()
        window_prepare.assert_called_once()
        canvas_prepare.assert_not_called()

    def test_curve_fit_entry_is_only_visible_for_xy_and_line_label_is_unambiguous(self):
        window = self.make_window()
        self.assertFalse(window.curve_fit_button.isVisible())
        self.assertEqual(window.ui.xyShowLineLabel.text(), "Connect data points")

        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        self.assertFalse(window.curve_fit_button.isHidden())

    def test_curve_fit_dialog_rejects_series_without_valid_numeric_pairs(self):
        dataframe, settings, _spec, _result = self.fit_fixture()
        dataframe["X"] = pd.Series(
            ["bad", None, "", "also bad"],
            dtype=object,
        )
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=False)

        with (
            mock.patch(
                "easygraph.ui.xy_curve_fit_dialog.XYCurveFitDialog"
            ) as dialog_class,
            mock.patch(
                "easygraph.ui.main_window.QMessageBox.information"
            ) as information,
        ):
            window.open_xy_curve_fit_dialog()

        dialog_class.assert_not_called()
        information.assert_called_once()

    def test_curve_fit_dialog_does_not_preselect_every_series_from_global_scope(self):
        dataframe, settings, _spec, _result = self.fit_fixture()
        dataframe["Z"] = [2.0, 4.0, 6.0, 8.0]
        settings.series.append(
            XYSeriesSpec(
                id="series-b",
                name="Second response",
                y_column_id="z",
            )
        )
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y", "z"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=False)

        with (
            mock.patch(
                "easygraph.ui.xy_curve_fit_dialog.XYCurveFitDialog"
            ) as dialog_class,
            mock.patch.object(window, "render"),
        ):
            dialog_class.return_value.exec.return_value = QDialog.Rejected
            window.open_xy_curve_fit_dialog()

        self.assertEqual(
            dialog_class.call_args.kwargs["selected_series_ids"],
            (),
        )

    def test_main_window_background_fit_populates_cache_and_redraws_curve(self):
        dataframe, settings, spec, _result = self.fit_fixture()
        settings.shared_tables = [
            XYSharedTableSpec(
                id="table-a",
                name="Data",
                x_column_id="x",
                series_ids=["series-a"],
            )
        ]
        settings.active_shared_table_id = "table-a"
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=True)
        window._xy_fit_timer.stop()

        window._start_xy_auto_fit()
        deadline = time.monotonic() + 5.0
        while window._xy_fit_workers and time.monotonic() < deadline:
            self.qapp.processEvents()
            time.sleep(0.01)
        self.qapp.processEvents()
        window.flush_pending_render()

        self.assertFalse(window._xy_fit_workers)
        result = window._xy_fit_results_by_sheet[sheet.id][spec.id]
        self.assertTrue(result.success, result.message)
        self.assertTrue(
            any(
                getattr(line, "_easygraph_fit_id", None) == spec.id
                for line in window.canvas.figure.axes[0].lines
            )
        )

    def test_background_fit_recomputes_internal_origin_after_data_change(self):
        dataframe, settings, spec, _result = self.fit_fixture()
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=False)
        current_dataframe = window.table_dataframe()
        jobs, submitted_signatures = window._xy_fit_jobs_and_signatures(
            sheet,
            current_dataframe,
            auto_only=False,
        )
        first_job = jobs[0]
        first_result = fit_xy_values(first_job.x, first_job.y, first_job.spec)
        self.assertTrue(first_result.success, first_result.message)
        self.assertIsNone(spec.x_origin)
        context = (mock.sentinel.worker, sheet.id, submitted_signatures)

        with (
            mock.patch.object(window, "_take_xy_fit_worker_context", return_value=context),
            mock.patch.object(window, "schedule_render") as schedule_render,
        ):
            window._handle_xy_fit_batch_finished({spec.id: first_result})

        self.assertIsNone(spec.x_origin)
        self.assertIsNotNone(first_result.x_origin)
        current_signatures = window._current_xy_fit_signatures(sheet.id)
        self.assertEqual(
            submitted_signatures[spec.id],
            current_signatures[spec.id],
        )
        self.assertEqual(
            window._xy_fit_signatures_by_sheet[sheet.id][spec.id],
            current_signatures[spec.id],
        )
        schedule_render.assert_called_once_with(delay_ms=0)

        with mock.patch.object(window._xy_fit_timer, "start") as timer_start:
            rendered = window._xy_fit_results_for_render(sheet, current_dataframe)
        self.assertIs(rendered[spec.id], first_result)
        timer_start.assert_not_called()

        changed_dataframe = current_dataframe.copy()
        changed_dataframe["X"] = (
            pd.to_numeric(changed_dataframe["X"], errors="raise") + 1_000.0
        )
        changed_jobs, _signatures = window._xy_fit_jobs_and_signatures(
            sheet,
            changed_dataframe,
            auto_only=False,
        )
        changed_job = changed_jobs[0]
        self.assertIsNone(changed_job.spec.x_origin)
        changed_result = fit_xy_values(
            changed_job.x,
            changed_job.y,
            changed_job.spec,
        )
        self.assertTrue(changed_result.success, changed_result.message)
        self.assertAlmostEqual(
            changed_result.x_origin,
            first_result.x_origin + 1_000.0,
        )

    def test_non_auto_fit_hydrates_once_after_runtime_reset_then_stays_cached(self):
        dataframe, settings, spec, _result = self.fit_fixture()
        spec.auto_refit = False
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        # Opening/replacing a project deliberately restores persisted fit specs
        # while clearing renderer-only result and signature caches.
        window._replace_project_with_sheet(sheet, render=True)
        window._xy_fit_timer.stop()
        self.assertNotIn(spec.id, window._xy_fit_results_by_sheet[sheet.id])

        window._start_xy_auto_fit()
        deadline = time.monotonic() + 5.0
        while window._xy_fit_workers and time.monotonic() < deadline:
            self.qapp.processEvents()
            time.sleep(0.01)
        self.qapp.processEvents()

        self.assertFalse(window._xy_fit_workers)
        hydrated = window._xy_fit_results_by_sheet[sheet.id][spec.id]
        self.assertTrue(hydrated.success, hydrated.message)
        original_signature = window._xy_fit_signatures_by_sheet[sheet.id][spec.id]

        changed_data = window.table_dataframe()
        source_series = next(
            series
            for series in sheet.xy_settings.series
            if series.id == spec.series_id
        )
        y_position = sheet.column_ids.index(source_series.y_column_id)
        changed_data.iloc[3, y_position] = 70.0
        window.set_table_dataframe(changed_data, restore_group_capacity=True)
        with mock.patch.object(window._xy_fit_timer, "start") as timer_start:
            window.render()
        timer_start.assert_not_called()
        self.assertIs(window._xy_fit_results_by_sheet[sheet.id][spec.id], hydrated)
        self.assertEqual(
            window._xy_fit_signatures_by_sheet[sheet.id][spec.id],
            original_signature,
        )

        window._start_xy_auto_fit()
        self.assertFalse(window._xy_fit_workers)
        self.assertIs(window._xy_fit_results_by_sheet[sheet.id][spec.id], hydrated)

    def test_worker_result_does_not_redraw_over_active_fit_dialog_preview(self):
        dataframe, settings, spec, result = self.fit_fixture()
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=False)
        current_dataframe = window.table_dataframe()
        _jobs, signatures = window._xy_fit_jobs_and_signatures(
            sheet,
            current_dataframe,
            auto_only=False,
        )
        context = (mock.sentinel.worker, sheet.id, signatures)
        window._active_xy_fit_dialog_sheet_id = sheet.id

        with (
            mock.patch.object(window, "_take_xy_fit_worker_context", return_value=context),
            mock.patch.object(window, "_current_xy_fit_signatures", return_value=signatures),
            mock.patch.object(window, "schedule_render") as schedule_render,
        ):
            window._handle_xy_fit_batch_finished({spec.id: result})

        self.assertIs(window._xy_fit_results_by_sheet[sheet.id][spec.id], result)
        schedule_render.assert_not_called()

        window._active_xy_fit_dialog_sheet_id = None
        with (
            mock.patch.object(window, "_take_xy_fit_worker_context", return_value=context),
            mock.patch.object(window, "_current_xy_fit_signatures", return_value=signatures),
            mock.patch.object(window, "schedule_render") as schedule_render,
        ):
            window._handle_xy_fit_batch_finished({spec.id: result})
        schedule_render.assert_called_once_with(delay_ms=0)

    def test_starting_preview_returns_actionable_fit_failure(self):
        dataframe, settings, spec, _result = self.fit_fixture()
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=False)
        series = SimpleNamespace(
            id=spec.series_id,
            name="Response",
            x=tuple(dataframe["X"]),
            y=tuple(dataframe["Y"]),
        )
        request = SimpleNamespace(
            specs={spec.id: spec},
            series={spec.series_id: series},
        )
        failed = SimpleNamespace(
            success=False,
            message="fixed coefficients cannot be represented reliably",
        )

        with (
            mock.patch(
                "easygraph.ui.main_window.fit_xy_values",
                return_value=failed,
            ),
            mock.patch.object(window, "_render_xy_fit_preview") as render_preview,
        ):
            problem = window._preview_xy_fit_curves(request)

        self.assertIn("Response", problem)
        self.assertIn("cannot be represented reliably", problem)
        render_preview.assert_called_once()
        self.assertEqual(render_preview.call_args.args[1], {})
        self.assertFalse(render_preview.call_args.kwargs["show_equations"])

    def test_automatic_large_offset_polynomial_preview_uses_stable_fit_basis(self):
        base = 1_000_000_000.0
        x = base + np.linspace(-20.0, 20.0, 61)
        z = x - base
        y = 3.0 * z**2 + 2.0 * z + 1.0
        spec = default_fit_spec("series-a", "polynomial2")
        series = SimpleNamespace(
            id=spec.series_id,
            name="Response",
            x=tuple(x),
            y=tuple(y),
        )
        request = SimpleNamespace(
            specs={spec.id: spec},
            series={spec.series_id: series},
        )
        window = self.make_window()

        with mock.patch.object(window, "_render_xy_fit_preview") as render_preview:
            problem = window._preview_xy_fit_curves(request)

        self.assertIsNone(problem)
        preview_results = render_preview.call_args.args[1]
        self.assertTrue(preview_results[spec.id].success)
        self.assertLess(preview_results[spec.id].rmse, 1e-10)
        self.assertFalse(render_preview.call_args.kwargs["show_equations"])

    def test_parameter_change_cancels_stale_batch_and_requeues_valid_jobs(self):
        dataframe = pd.DataFrame(
            {
                "X": [0.0, 1.0, 2.0, 3.0],
                "Y A": [1.0, 3.0, 5.0, 7.0],
                "Y B": [2.0, 4.0, 6.0, 8.0],
            }
        )
        series_a = XYSeriesSpec(
            id="series-a",
            name="Response A",
            y_column_id="y-a",
        )
        series_b = XYSeriesSpec(
            id="series-b",
            name="Response B",
            y_column_id="y-b",
        )
        spec_a = default_fit_spec(series_a.id, "linear")
        spec_b = default_fit_spec(series_b.id, "linear")
        settings = XYSettings(
            default_x_column_id="x",
            series=[series_a, series_b],
            fit_specs=[spec_a, spec_b],
        )
        sheet = SheetDocument(
            name="XY",
            dataframe=dataframe,
            settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y-a", "y-b"],
            xy_settings=settings,
        )
        window = self.make_window()
        window._replace_project_with_sheet(sheet, render=False)

        _jobs, old_signatures = window._xy_fit_jobs_and_signatures(
            sheet,
            window.table_dataframe(),
            auto_only=False,
        )
        old_worker = mock.Mock()
        old_signals = mock.sentinel.old_signals
        window._xy_fit_workers.add(old_worker)
        window._xy_fit_worker_context[old_signals] = (
            old_worker,
            sheet.id,
            dict(old_signatures),
        )
        window._xy_fit_inflight_signatures[sheet.id] = dict(old_signatures)

        spec_a.parameters = [
            FitParameterSpec(name="slope", initial=1.0),
        ]
        _jobs, new_signatures = window._xy_fit_jobs_and_signatures(
            sheet,
            window.table_dataframe(),
            auto_only=False,
        )
        self.assertNotEqual(new_signatures[spec_a.id], old_signatures[spec_a.id])
        self.assertEqual(new_signatures[spec_b.id], old_signatures[spec_b.id])

        replacement_worker = mock.Mock()
        replacement_pool = mock.Mock()
        with (
            mock.patch(
                "easygraph.ui.main_window.XYFitBatchWorker",
                return_value=replacement_worker,
            ) as worker_class,
            mock.patch(
                "easygraph.ui.main_window.QThreadPool.globalInstance",
                return_value=replacement_pool,
            ),
        ):
            window._start_xy_auto_fit()

        old_worker.cancel.assert_called_once_with()
        self.assertNotIn(old_worker, window._xy_fit_workers)
        self.assertNotIn(old_signals, window._xy_fit_worker_context)
        submitted_jobs = worker_class.call_args.args[0]
        self.assertEqual(
            {job.spec.id for job in submitted_jobs},
            {spec_a.id, spec_b.id},
        )
        replacement_context = window._xy_fit_worker_context[
            replacement_worker.signals
        ]
        self.assertEqual(replacement_context[2], new_signatures)
        self.assertEqual(
            window._xy_fit_inflight_signatures[sheet.id],
            new_signatures,
        )
        replacement_pool.start.assert_called_once_with(replacement_worker)

    def test_fit_workers_cancel_on_runtime_reset_and_only_confirmed_close(self):
        window = self.make_window()
        worker = mock.Mock()
        window._xy_fit_workers.add(worker)
        window._xy_fit_worker_context[mock.sentinel.signals] = (
            worker,
            window.workbook.active_sheet_id,
            {},
        )

        window._reset_xy_fit_runtime()

        worker.cancel.assert_called_once_with()
        self.assertFalse(window._xy_fit_workers)
        self.assertFalse(window._xy_fit_worker_context)

        with (
            mock.patch.object(
                window,
                "_confirm_unsaved_changes",
                return_value=False,
            ),
            mock.patch.object(window, "_cancel_xy_fit_workers") as cancel_workers,
        ):
            rejected_event = QCloseEvent()
            window.closeEvent(rejected_event)
        self.assertFalse(rejected_event.isAccepted())
        cancel_workers.assert_not_called()

        with (
            mock.patch.object(
                window,
                "_confirm_unsaved_changes",
                return_value=True,
            ),
            mock.patch.object(window, "_cancel_xy_fit_workers") as cancel_workers,
        ):
            accepted_event = QCloseEvent()
            window.closeEvent(accepted_event)
        self.assertTrue(accepted_event.isAccepted())
        cancel_workers.assert_called_once_with()

    def test_curve_fit_dialog_clears_modal_guard_on_accept_and_cancel(self):
        dataframe, settings, spec, result = self.fit_fixture()

        class SignalStub:
            def connect(self, _callback):
                return None

        for dialog_code in (QDialog.Rejected, QDialog.Accepted):
            with self.subTest(dialog_code=dialog_code):
                sheet = SheetDocument(
                    name="XY",
                    dataframe=dataframe,
                    settings=ChartSettings(chart_type="Scatter", show_stat_table=False),
                    mode=SHEET_MODE_XY,
                    column_ids=["x", "y"],
                    xy_settings=deepcopy(settings),
                )
                window = self.make_window()
                window._replace_project_with_sheet(sheet, render=False)
                active_guard_values = []

                class FakeDialog:
                    def __init__(self, parent, *_args, **_kwargs):
                        self.parent = parent
                        self.previewCleared = SignalStub()
                        self.fitResultsReady = SignalStub()

                    def exec(self):
                        active_guard_values.append(
                            self.parent._active_xy_fit_dialog_sheet_id
                        )
                        return dialog_code

                    def specs(self):
                        return [deepcopy(spec)]

                    def results(self):
                        return {spec.id: result}

                    def result(self):
                        return SimpleNamespace(
                            specs=(deepcopy(spec),),
                            results={spec.id: result},
                        )

                with (
                    mock.patch(
                        "easygraph.ui.xy_curve_fit_dialog.XYCurveFitDialog",
                        FakeDialog,
                    ),
                    mock.patch.object(window, "_commit_pending_project_edits"),
                    mock.patch.object(window, "render") as render,
                ):
                    window.open_xy_curve_fit_dialog()

                self.assertEqual(active_guard_values, [sheet.id])
                self.assertIsNone(window._active_xy_fit_dialog_sheet_id)
                render.assert_called_once_with()


if __name__ == "__main__":
    __import__("unittest").main()
