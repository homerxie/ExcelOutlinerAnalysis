import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.table_data import (
    append_custom_overlay_series,
    column_header_labels,
    custom_overlay_state_from_series,
    custom_overlay_series_from_table,
    normalized_hidden_overlay_indexes,
    populate_table_from_dataframe,
    overlay_row_for_removal,
    overlay_row_name,
    reindex_hidden_overlay_indexes,
    rename_group_in_order,
    remove_custom_overlay_series,
    row_header_labels,
    sample_start_row_for_overlay_count,
    sync_group_order_state,
    table_group_name,
    table_group_names,
    table_sample_dataframe,
)


class TableDataTests(EasyGraphQtTestCase):
    def test_table_group_name_falls_back_to_numbered_group(self):
        table = DataTable(1, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.set_cell_text(0, 0, "Control")

        self.assertEqual(table_group_name(table, 0), "Control")
        self.assertEqual(table_group_name(table, 1), "Group 2")

    def test_xy_column_names_use_column_fallback_without_changing_cells(self):
        table = DataTable(1, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.set_cell_text(0, 0, "X")

        self.assertEqual(
            table_group_names(table, fallback_prefix="Column"),
            ["X", "Column 2"],
        )
        self.assertEqual(table.table_model.cell_text(0, 1), "")

    def test_table_sample_dataframe_skips_overlay_rows(self):
        table = DataTable(4, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells(
            [["A", "B"], ["overlay", ""], ["1", "2"], ["3", "4"]],
            column_count=2,
        )

        frame = table_sample_dataframe(table, sample_start_row=2)

        self.assertEqual(list(frame.columns), ["A", "B"])
        self.assertEqual(frame.values.tolist(), [["1", "2"], ["3", "4"]])

    def test_custom_overlay_series_uses_vertical_header_fallback(self):
        table = DataTable(3, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.set_vertical_headers(["", "", "1"])
        table.table_model.set_cell_text(1, 0, "10")
        table.table_model.set_cell_text(1, 1, "20")

        series = custom_overlay_series_from_table(table, sample_start_row=2, groups=["A", "B"], fallback_series=[])

        self.assertEqual(series, [{"name": "Overlay 1", "values": {"A": "10", "B": "20"}}])

    def test_populate_table_from_dataframe_writes_overlay_and_sample_rows(self):
        table = DataTable()
        self.addCleanup(table.deleteLater)
        table.blockSignals(True)
        frame = pd.DataFrame({"A": [1, None], "B": ["x", "y"]})
        overlay = [{"name": "Overlay", "values": {"A": 10, "B": ""}}]

        sample_start = populate_table_from_dataframe(table, frame, overlay)

        self.assertTrue(table.signalsBlocked())
        self.assertEqual(sample_start, 2)
        self.assertEqual(table.table_model.rowCount(), 4)
        self.assertEqual(table.table_model.columnCount(), 2)
        self.assertEqual(table.table_model.cell_text(0, 0), "A")
        self.assertEqual(table.table_model.cell_text(0, 1), "B")
        self.assertEqual(table.table_model.cell_text(1, 0), "10")
        self.assertEqual(table.table_model.cell_text(1, 1), "")
        self.assertEqual(table.table_model.cell_text(2, 0), "1.0")
        self.assertEqual(table.table_model.cell_text(3, 0), "")
        self.assertEqual(table.table_model.cell_text(2, 1), "x")

    def test_row_header_labels_include_overlay_fallbacks_and_sample_numbers(self):
        labels = row_header_labels(
            row_count=5,
            sample_start_row=3,
            overlay_series=[{"name": "Overlay A"}, {"name": ""}],
        )

        self.assertEqual(labels, ["", "Overlay A", "Overlay 2", "1", "2"])

    def test_column_header_labels_are_one_based_numbers(self):
        self.assertEqual(column_header_labels(0), [])
        self.assertEqual(column_header_labels(3), ["1", "2", "3"])
        self.assertEqual(
            column_header_labels(3, ("X", "Y", "X/Y")),
            ["1 · X", "2 · Y", "3 · X/Y"],
        )

    def test_sample_start_row_for_overlay_count_is_after_group_and_overlay_rows(self):
        self.assertEqual(sample_start_row_for_overlay_count(0), 1)
        self.assertEqual(sample_start_row_for_overlay_count(2), 3)

    def test_reindex_hidden_overlay_indexes_drops_removed_and_shifts_later_indexes(self):
        self.assertEqual(reindex_hidden_overlay_indexes([0, 2, 3], removed_index=2), [0, 2])
        self.assertEqual(reindex_hidden_overlay_indexes([1, 3], removed_index=0), [0, 2])

    def test_normalized_hidden_overlay_indexes_keeps_valid_unique_sorted_indexes(self):
        self.assertEqual(
            normalized_hidden_overlay_indexes([2, "1", 2, "-1", "bad", 3], overlay_count=3),
            [1, 2],
        )
        self.assertEqual(normalized_hidden_overlay_indexes(["0"], overlay_count=0), [])

    def test_sync_group_order_state_keeps_existing_appends_new_and_drops_stale_hidden(self):
        manual_order, hidden = sync_group_order_state(
            columns=["Control", "Low dose", "High dose"],
            manual_group_order=["High dose", "Missing", "Control"],
            group_hidden=["Missing", "Low dose"],
        )

        self.assertEqual(manual_order, ["High dose", "Control", "Low dose"])
        self.assertEqual(hidden, ["Low dose"])

    def test_rename_group_in_order_replaces_matching_names_only(self):
        self.assertEqual(
            rename_group_in_order(["Control", "Low dose", "Control"], "Control", "Vehicle"),
            ["Vehicle", "Low dose", "Vehicle"],
        )

    def test_append_custom_overlay_series_adds_next_default_overlay_without_mutating_input(self):
        existing = [{"name": "Overlay 1", "values": {"A": "1"}}]

        result = append_custom_overlay_series(existing)

        self.assertEqual(existing, [{"name": "Overlay 1", "values": {"A": "1"}}])
        self.assertEqual(result, [
            {"name": "Overlay 1", "values": {"A": "1"}},
            {"name": "Overlay 2", "values": {}},
        ])

    def test_remove_custom_overlay_series_removes_valid_index_without_mutating_input(self):
        existing = [{"name": "Overlay 1"}, {"name": "Overlay 2"}]

        result = remove_custom_overlay_series(existing, 0)

        self.assertEqual(existing, [{"name": "Overlay 1"}, {"name": "Overlay 2"}])
        self.assertEqual(result, [{"name": "Overlay 2"}])

    def test_remove_custom_overlay_series_ignores_invalid_index(self):
        existing = [{"name": "Overlay 1"}]

        self.assertEqual(remove_custom_overlay_series(existing, -1), existing)
        self.assertEqual(remove_custom_overlay_series(existing, 2), existing)

    def test_overlay_row_for_removal_uses_selected_overlay_or_last_overlay(self):
        self.assertEqual(overlay_row_for_removal(current_row=1, sample_start_row=3), 1)
        self.assertEqual(overlay_row_for_removal(current_row=0, sample_start_row=3), 2)
        self.assertEqual(overlay_row_for_removal(current_row=5, sample_start_row=3), 2)

    def test_overlay_row_name_uses_header_text_or_numbered_fallback(self):
        self.assertEqual(overlay_row_name(" Target ", row=2), "Target")
        self.assertEqual(overlay_row_name("", row=2), "Overlay 2")
        self.assertEqual(overlay_row_name(None, row=2), "Overlay 2")

    def test_custom_overlay_state_from_series_reports_min_count_and_extra_flag(self):
        self.assertEqual(custom_overlay_state_from_series([]), (1, False))
        self.assertEqual(custom_overlay_state_from_series([{"name": "Overlay"}]), (1, True))
        self.assertEqual(custom_overlay_state_from_series([{}, {}]), (2, True))
