from __future__ import annotations

from types import SimpleNamespace
from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.settings import ChartSettings, LEGEND_POSITION_INSIDE
from easygraph.workbook import SHEET_MODE_XY
from easygraph.xy_data import prepare_xy_data
from easygraph.xy_series import XYSeriesSpec, XYSettings, resolved_series_display


class XYMultiSelectionTestCase(EasyGraphQtTestCase):
    SERIES_IDS = ("a", "b", "c")

    @staticmethod
    def _series_settings(*, show_points: bool = False) -> XYSettings:
        return XYSettings(
            default_x_column_id="x",
            show_points=show_points,
            show_line=True,
            series=[
                XYSeriesSpec(id="a", name="Series A", y_column_id="a"),
                XYSeriesSpec(id="b", name="Series B", y_column_id="b"),
                XYSeriesSpec(id="c", name="Series C", y_column_id="c"),
            ],
        )

    @staticmethod
    def _series_frame() -> pd.DataFrame:
        return pd.DataFrame(
            {
                "X": [0.0, 1.0, 2.0],
                "A": [0.0, 0.0, 0.0],
                "B": [5.0, 5.0, 5.0],
                "C": [10.0, 10.0, 10.0],
            }
        )

    def make_canvas(self, settings: XYSettings | None = None):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            self._series_frame(),
            ChartSettings(show_stat_table=False),
            xy_settings=settings or self._series_settings(),
            column_ids=["x", "a", "b", "c"],
        )
        return canvas

    def make_xy_window(self, settings: XYSettings | None = None):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        xy_settings = settings or self._series_settings()
        window.workbook.active_sheet.xy_settings = xy_settings
        window.canvas.render(
            self._series_frame(),
            window.settings,
            xy_settings=xy_settings,
            column_ids=["x", "a", "b", "c"],
        )
        return window

    @staticmethod
    def _event_at_data(
        canvas,
        x: float,
        y: float,
        *,
        key: str | None = None,
        dblclick: bool = False,
        button: int = 1,
    ) -> SimpleNamespace:
        display_x, display_y = canvas.figure.axes[0].transData.transform((x, y))
        return SimpleNamespace(
            x=float(display_x),
            y=float(display_y),
            button=button,
            key=key,
            dblclick=dblclick,
        )

    @staticmethod
    def _feedback_series_ids(canvas) -> set[str]:
        return {
            feedback._easygraph_feedback_source._easygraph_series_id
            for feedback in (canvas._selected_feedback_patch or [])
        }

    @staticmethod
    def _series_by_id(settings: XYSettings, series_id: str) -> XYSeriesSpec:
        return next(series for series in settings.series if series.id == series_id)

    @staticmethod
    def _selection_list_item(window, series_id: str):
        for index in range(window.ui.xySeriesSelectionList.count()):
            item = window.ui.xySeriesSelectionList.item(index)
            if str(item.data(Qt.ItemDataRole.UserRole)) == series_id:
                return item
        raise AssertionError(f"No series-selection item for {series_id!r}")

    def _click_selection_list_item(
        self,
        window,
        series_id: str,
        *,
        modifier: Qt.KeyboardModifier = Qt.KeyboardModifier.NoModifier,
    ) -> None:
        selection_list = window.xy_series_selection_list
        item = self._selection_list_item(window, series_id)
        selection_list.scrollToItem(item)
        self.qapp.processEvents()
        item_rect = selection_list.visualItemRect(item)
        self.assertTrue(item_rect.isValid())
        QTest.mouseClick(
            selection_list.viewport(),
            Qt.MouseButton.LeftButton,
            modifier,
            item_rect.center(),
        )
        self.qapp.processEvents()


class XYCanvasMultiSelectionTests(XYMultiSelectionTestCase):
    def make_geometry_canvas(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "U X": [0.0, 0.0, 10.0, 10.0],
                "U Y": [0.0, 10.0, 10.0, 0.0],
                "Cross X": [0.0, 3.0, 7.0, 10.0],
                "Cross Y": [5.0, 5.0, 5.0, 5.0],
                "Outside X": [0.0, 3.0, 7.0, 10.0],
                "Outside Y": [8.0, 8.0, 8.0, 8.0],
            }
        )
        settings = XYSettings(
            show_points=False,
            show_line=True,
            series=[
                XYSeriesSpec(
                    id="u",
                    name="U-shaped",
                    x_column_id="ux",
                    y_column_id="uy",
                ),
                XYSeriesSpec(
                    id="cross",
                    name="Crossing",
                    x_column_id="cross-x",
                    y_column_id="cross-y",
                ),
                XYSeriesSpec(
                    id="outside",
                    name="Outside",
                    x_column_id="outside-x",
                    y_column_id="outside-y",
                ),
            ],
        )
        canvas.render(
            frame,
            ChartSettings(show_stat_table=False),
            xy_settings=settings,
            column_ids=["ux", "uy", "cross-x", "cross-y", "outside-x", "outside-y"],
        )
        return canvas

    def _drag_box(
        self,
        canvas,
        start: tuple[float, float],
        end: tuple[float, float],
        *,
        key: str | None = None,
    ) -> None:
        press = self._event_at_data(canvas, *start, key=key)
        move = self._event_at_data(canvas, *end, key=key)
        canvas.set_xy_box_select_enabled(True)
        canvas._handle_plot_click(press)
        canvas._handle_plot_motion(move)
        canvas._handle_plot_release(move)

    def test_plain_double_and_modifier_click_use_single_or_explicit_subset(self):
        canvas = self.make_canvas()

        canvas._handle_plot_click(self._event_at_data(canvas, 1.0, 5.0))
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), {"b"})
        self.assertEqual(canvas._selected_series_id, "b")
        self.assertEqual(self._feedback_series_ids(canvas), {"b"})

        canvas._handle_plot_click(
            self._event_at_data(canvas, 1.0, 5.0, dblclick=True)
        )
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), {"b"})
        self.assertEqual(canvas._selected_series_id, "b")
        self.assertEqual(self._feedback_series_ids(canvas), {"b"})

        canvas._handle_plot_click(
            self._event_at_data(canvas, 1.0, 10.0, key="control")
        )
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), {"b", "c"})
        self.assertIsNone(canvas._selected_series_id)
        self.assertEqual(self._feedback_series_ids(canvas), {"b", "c"})

        canvas._handle_plot_click(self._event_at_data(canvas, 1.0, 5.0))
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), {"b"})
        self.assertEqual(self._feedback_series_ids(canvas), {"b"})

    def test_control_and_command_click_start_and_toggle_a_subset(self):
        for key in ("control", "cmd"):
            with self.subTest(key=key):
                canvas = self.make_canvas()

                canvas._handle_plot_click(
                    self._event_at_data(canvas, 1.0, 5.0, key=key)
                )
                self.assertEqual(canvas._xy_selection_scope, "subset")
                self.assertEqual(set(canvas._selected_series_ids), {"b"})

                canvas._handle_plot_click(
                    self._event_at_data(canvas, 1.0, 10.0, key=key)
                )
                self.assertEqual(
                    set(canvas._selected_series_ids),
                    {"b", "c"},
                )

                canvas._handle_plot_click(
                    self._event_at_data(canvas, 1.0, 5.0, key=key)
                )
                self.assertEqual(set(canvas._selected_series_ids), {"c"})

                canvas._handle_plot_click(
                    self._event_at_data(canvas, 1.0, 10.0, key=key)
                )
                self.assertEqual(canvas._xy_selection_scope, "subset")
                self.assertEqual(set(canvas._selected_series_ids), set())
                self.assertIsNone(canvas._selected_feedback_patch)

    def test_shift_click_on_canvas_is_a_single_selection_not_a_range(self):
        canvas = self.make_canvas()
        canvas.set_xy_series_selection("subset", {"a", "c"})

        canvas._handle_plot_click(
            self._event_at_data(canvas, 1.0, 5.0, key="shift")
        )

        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), {"b"})
        self.assertEqual(canvas._selected_series_id, "b")
        self.assertEqual(self._feedback_series_ids(canvas), {"b"})

    def test_explicit_subset_containing_every_id_does_not_become_global_all(self):
        canvas = self.make_canvas()

        canvas.set_xy_series_selection("subset", self.SERIES_IDS)

        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), set(self.SERIES_IDS))
        self.assertIsNone(canvas._selected_series_id)
        self.assertEqual(self._feedback_series_ids(canvas), set(self.SERIES_IDS))

    def test_subset_ids_survive_render_when_one_series_is_hidden(self):
        settings = self._series_settings()
        canvas = self.make_canvas(settings)
        canvas.set_xy_series_selection("subset", {"a", "b"})

        self._series_by_id(settings, "b").visible = False
        canvas.render(
            self._series_frame(),
            ChartSettings(show_stat_table=False),
            xy_settings=settings,
            column_ids=["x", "a", "b", "c"],
        )

        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), {"a", "b"})
        self.assertEqual(self._feedback_series_ids(canvas), {"a"})

        self._series_by_id(settings, "b").visible = True
        canvas.render(
            self._series_frame(),
            ChartSettings(show_stat_table=False),
            xy_settings=settings,
            column_ids=["x", "a", "b", "c"],
        )
        self.assertEqual(set(canvas._selected_series_ids), {"a", "b"})
        self.assertEqual(self._feedback_series_ids(canvas), {"a", "b"})

    def test_box_selection_replaces_adds_and_removes_by_actual_artist_geometry(self):
        canvas = self.make_geometry_canvas()

        # The U-shaped line's overall bbox contains this rectangle, but none
        # of its actual segments cross it. Only the horizontal center line is
        # a geometric hit.
        canvas.set_xy_series_selection("subset", {"outside"})
        self._drag_box(canvas, (4.0, 4.0), (6.0, 6.0))
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), {"cross"})

        canvas.set_xy_series_selection("subset", {"outside"})
        self._drag_box(
            canvas,
            (4.0, 4.0),
            (6.0, 6.0),
            key="control",
        )
        self.assertEqual(
            set(canvas._selected_series_ids),
            {"cross", "outside"},
        )

        canvas.set_xy_series_selection(
            "subset",
            {"u", "cross", "outside"},
        )
        self._drag_box(canvas, (4.0, 4.0), (6.0, 6.0), key="alt")
        self.assertEqual(set(canvas._selected_series_ids), {"u", "outside"})

    def test_box_selection_does_not_hit_line_geometry_hidden_by_inside_legend(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            pd.DataFrame({"X": [0.0, 10.0], "Y": [5.0, 5.0]}),
            ChartSettings(
                show_stat_table=False,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
                legend_position=LEGEND_POSITION_INSIDE,
                legend_inside_x=0.35,
                legend_inside_y=0.45,
            ),
            xy_settings=XYSettings(
                default_x_column_id="x",
                show_points=False,
                show_line=True,
                series=[
                    XYSeriesSpec(
                        id="line",
                        name="Covered line",
                        y_column_id="y",
                    )
                ],
            ),
            column_ids=["x", "y"],
        )
        axis = canvas.figure.axes[0]
        renderer = canvas.canvas.get_renderer()
        legend_bbox = canvas._legend_outer_bbox(axis.get_legend(), renderer)
        line_y = float(axis.transData.transform((5.0, 5.0))[1])
        self.assertTrue(legend_bbox.y0 < line_y < legend_bbox.y1)

        # Start just above the legend so rectangle mode is allowed, then drag
        # only through x positions where the horizontal line is occluded by
        # the legend. The marquee contains no visible part of the plot line.
        center_x = (legend_bbox.x0 + legend_bbox.x1) / 2.0
        press = SimpleNamespace(
            x=center_x,
            y=legend_bbox.y1 + 3.0,
            button=1,
            key=None,
            dblclick=False,
        )
        release = SimpleNamespace(
            x=legend_bbox.x1 - 5.0,
            y=line_y - 2.0,
            button=1,
            key=None,
            dblclick=False,
        )
        canvas.set_xy_box_select_enabled(True)
        canvas._handle_plot_click(press)
        self.assertIsNotNone(canvas._xy_box_select_state)
        canvas._handle_plot_motion(release)
        canvas._handle_plot_release(release)

        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(set(canvas._selected_series_ids), set())

        # A neighboring box that also contains a genuinely visible segment
        # must still select the line; excluding the legend must not discard
        # the rest of a partially occluded selection rectangle.
        visible_press = SimpleNamespace(
            x=legend_bbox.x0 - 15.0,
            y=line_y + 4.0,
            button=1,
            key=None,
            dblclick=False,
        )
        visible_release = SimpleNamespace(
            x=center_x,
            y=line_y - 4.0,
            button=1,
            key=None,
            dblclick=False,
        )
        canvas.set_xy_box_select_enabled(True)
        canvas._handle_plot_click(visible_press)
        self.assertIsNotNone(canvas._xy_box_select_state)
        canvas._handle_plot_motion(visible_release)
        canvas._handle_plot_release(visible_release)

        self.assertEqual(set(canvas._selected_series_ids), {"line"})


class XYSidebarMultiSelectionTests(XYMultiSelectionTestCase):
    def _select_subset(self, window, series_ids: set[str]) -> None:
        window.canvas.set_xy_series_selection("subset", series_ids)
        window.handle_plot_object_selection("points")

    def test_clear_shortcut_path_exits_box_mode_without_an_existing_selection(self):
        window = self.make_xy_window()
        self.assertIsNone(window.canvas._selected_object_kind)
        window.canvas.set_xy_box_select_enabled(True)
        self.assertTrue(window.canvas._xy_box_select_enabled)

        # This is the callback used by the main-window Escape shortcut.
        window.clear_plot_object_selection()

        self.assertFalse(window.canvas._xy_box_select_enabled)
        self.assertFalse(window.canvas.xy_box_select_button.isChecked())

    def test_sidebar_checklist_and_buttons_update_canvas_selection_both_ways(self):
        window = self.make_xy_window()
        window.canvas._handle_plot_click(
            self._event_at_data(window.canvas, 1.0, 5.0, key="control")
        )

        self.assertEqual(
            self._selection_list_item(window, "b").checkState(),
            Qt.CheckState.Checked,
        )
        self.assertEqual(
            self._selection_list_item(window, "a").checkState(),
            Qt.CheckState.Unchecked,
        )

        self._selection_list_item(window, "a").setCheckState(
            Qt.CheckState.Checked
        )
        self.assertEqual(
            set(window.canvas._selected_series_ids),
            {"a", "b"},
        )
        self._selection_list_item(window, "b").setCheckState(
            Qt.CheckState.Unchecked
        )
        self.assertEqual(set(window.canvas._selected_series_ids), {"a"})

        window.ui.xySeriesSelectAllButton.click()
        self.assertEqual(window.ui.xySeriesSelectAllButton.text(), "All series")
        self.assertEqual(
            window.ui.xySeriesSelectAllButton.metaObject().className(),
            "QPushButton",
        )
        self.assertTrue(window.ui.xySeriesSelectAllButton.font().bold())
        self.assertEqual(window.canvas._xy_selection_scope, "all")
        self.assertEqual(set(window.canvas._selected_series_ids), set())

        window.ui.xySeriesInvertSelectionButton.click()
        self.assertEqual(window.canvas._xy_selection_scope, "subset")
        self.assertEqual(set(window.canvas._selected_series_ids), set())
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: No series selected",
        )
        self.assertFalse(window.xy_line_width.isEnabled())

        self._selection_list_item(window, "a").setCheckState(
            Qt.CheckState.Checked
        )
        window.ui.xySeriesInvertSelectionButton.click()
        self.assertEqual(
            set(window.canvas._selected_series_ids),
            {"b", "c"},
        )

        window.ui.xySeriesClearSelectionButton.click()
        self.assertEqual(window.canvas._xy_selection_scope, "subset")
        self.assertEqual(set(window.canvas._selected_series_ids), set())
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: No series selected",
        )

        window.canvas.set_xy_series_selection("all", ())
        window.handle_plot_object_selection("points")
        self.assertEqual(
            {
                self._selection_list_item(window, series_id).checkState()
                for series_id in self.SERIES_IDS
            },
            {Qt.CheckState.Checked},
        )

    def test_checklist_shift_click_applies_a_checked_range_and_preserves_outside(self):
        window = self.make_xy_window()
        self._select_subset(window, set())
        window.show()
        self.qapp.processEvents()

        # C is an existing checked item outside the later A..B range. The
        # most recent ordinary click on A establishes A as the range anchor.
        self._click_selection_list_item(window, "c")
        self._click_selection_list_item(window, "a")
        self.assertEqual(set(window.canvas._selected_series_ids), {"a", "c"})

        self._click_selection_list_item(
            window,
            "b",
            modifier=Qt.KeyboardModifier.ShiftModifier,
        )
        self.assertEqual(
            set(window.canvas._selected_series_ids),
            {"a", "b", "c"},
        )

        # Shift-clicking an already checked endpoint applies the unchecked
        # state across the same continuous range; C remains untouched.
        self._click_selection_list_item(
            window,
            "b",
            modifier=Qt.KeyboardModifier.ShiftModifier,
        )
        self.assertEqual(set(window.canvas._selected_series_ids), {"c"})
        self.assertEqual(
            self._selection_list_item(window, "a").checkState(),
            Qt.CheckState.Unchecked,
        )
        self.assertEqual(
            self._selection_list_item(window, "b").checkState(),
            Qt.CheckState.Unchecked,
        )
        self.assertEqual(
            self._selection_list_item(window, "c").checkState(),
            Qt.CheckState.Checked,
        )

        # Bulk-selection buttons terminate the previous range gesture. After
        # All series, a Shift-click without a live anchor changes only C.
        window.ui.xySeriesSelectAllButton.click()
        self._click_selection_list_item(
            window,
            "c",
            modifier=Qt.KeyboardModifier.ShiftModifier,
        )
        self.assertEqual(set(window.canvas._selected_series_ids), {"a", "b"})

        # Clear likewise prevents a stale checklist anchor from unexpectedly
        # expanding the next Shift-click.
        window.ui.xySeriesClearSelectionButton.click()
        self._click_selection_list_item(
            window,
            "b",
            modifier=Qt.KeyboardModifier.ShiftModifier,
        )
        self.assertEqual(set(window.canvas._selected_series_ids), {"b"})

    def test_double_click_selects_one_series_and_locates_series_style(self):
        window = self.make_xy_window()

        with mock.patch.object(
            window.ui.controlsScroll,
            "ensureWidgetVisible",
        ) as ensure_visible:
            window.canvas._handle_plot_click(
                self._event_at_data(
                    window.canvas,
                    1.0,
                    5.0,
                    dblclick=True,
                )
            )

        self.assertEqual(window.canvas._xy_selection_scope, "subset")
        self.assertEqual(set(window.canvas._selected_series_ids), {"b"})
        self.assertEqual(window.canvas._selected_series_id, "b")
        self.assertEqual(
            window.ui.inspectorContextLabel.text(),
            "Editing: Series B",
        )
        ensure_visible.assert_called_with(window.ui.pointsGroup, 0, 8)

    def test_explicit_all_id_subset_writes_overrides_not_global_style(self):
        settings = self._series_settings()
        window = self.make_xy_window(settings)
        self._select_subset(window, set(self.SERIES_IDS))

        with mock.patch.object(window, "schedule_render"):
            window.xy_line_width.setValue(3.4)

        self.assertEqual(settings.line_width, 1.6)
        self.assertEqual(
            [series.line_width for series in settings.series],
            [3.4, 3.4, 3.4],
        )
        self.assertEqual(window.canvas._xy_selection_scope, "subset")

    def test_mixed_selection_does_not_materialize_untouched_overrides(self):
        settings = self._series_settings(show_points=True)
        first, second, hidden = settings.series
        first.marker = None
        first.point_size = None
        first.show_points = True
        second.marker = "Diamond"
        second.point_size = 8.0
        second.show_points = False
        hidden.visible = False
        hidden.marker = "Square"
        hidden.point_size = 9.0
        before = [vars(series).copy() for series in settings.series]
        window = self.make_xy_window(settings)

        self._select_subset(window, {"a", "b"})

        window.show()
        self.qapp.processEvents()
        self.assertEqual(window.show_points.checkState(), Qt.CheckState.PartiallyChecked)
        self.assertEqual(window.xy_marker.currentText(), "Mixed")
        self.assertEqual(window.point_size.text(), "Mixed")
        self.assertEqual(window.point_size.lineEdit().text(), "Mixed")
        self.assertEqual([vars(series) for series in settings.series], before)

        # A normal inspector update must not commit the checkbox's partial
        # state, the combo's sentinel item, or the spin box's hidden value.
        with mock.patch.object(window, "schedule_render"):
            window.show_grid.setChecked(not window.show_grid.isChecked())
        self.assertEqual([vars(series) for series in settings.series], before)

        with mock.patch.object(window, "schedule_render"):
            window.xy_line_width.setValue(2.8)

        self.assertEqual(first.line_width, 2.8)
        self.assertEqual(second.line_width, 2.8)
        self.assertIsNone(hidden.line_width)
        self.assertIsNone(first.marker)
        self.assertEqual(second.marker, "Diamond")
        self.assertEqual(hidden.marker, "Square")
        self.assertIsNone(first.point_size)
        self.assertEqual(second.point_size, 8.0)
        self.assertEqual(hidden.point_size, 9.0)

    def test_abandoning_an_empty_mixed_spin_edit_does_not_write_its_sentinel(self):
        settings = self._series_settings(show_points=True)
        first, second, _unselected = settings.series
        first.point_size = 4.0
        second.point_size = 8.0
        window = self.make_xy_window(settings)
        self._select_subset(window, {"a", "b"})
        self.assertEqual(window.point_size.text(), "Mixed")

        # Model the user focusing the mixed field, deleting its contents, and
        # tabbing away without entering a replacement value.
        with mock.patch.object(window, "schedule_render"):
            window.point_size.lineEdit().setText("")
            window.point_size.lineEdit().textEdited.emit("")
            window.point_size.editingFinished.emit()

        self.assertEqual(first.point_size, 4.0)
        self.assertEqual(second.point_size, 8.0)
        self.assertEqual(window.point_size.text(), "Mixed")

    def test_mixed_spin_rejects_values_from_its_temporary_sentinel_range(self):
        settings = self._series_settings(show_points=True)
        first, second, _unselected = settings.series
        first.point_size = 4.0
        second.point_size = 8.0
        window = self.make_xy_window(settings)
        self._select_subset(window, {"a", "b"})
        normal_minimum = float(window.point_size._easygraph_xy_style_minimum)
        sentinel = window.point_size.minimum()
        self.assertLess(sentinel, normal_minimum)

        with mock.patch.object(window, "schedule_render"):
            window.point_size.setValue((sentinel + normal_minimum) / 2.0)

        self.assertEqual(first.point_size, 4.0)
        self.assertEqual(second.point_size, 8.0)
        self.assertEqual(window.point_size.text(), "Mixed")

        # The first increment from the Mixed sentinel is a deliberate edit:
        # it must land exactly on the control's real minimum and apply to the
        # whole selected subset.
        with mock.patch.object(window, "schedule_render"):
            window.point_size.stepUp()

        self.assertEqual(window.point_size.value(), normal_minimum)
        self.assertNotEqual(window.point_size.text(), "Mixed")
        self.assertEqual(first.point_size, normal_minimum)
        self.assertEqual(second.point_size, normal_minimum)

    def test_series_checklist_order_matches_renderer_name_order(self):
        settings = XYSettings(
            default_x_column_id="x",
            show_points=False,
            show_line=True,
            series=[
                XYSeriesSpec(id="z", name="Zulu", y_column_id="z-y"),
                XYSeriesSpec(
                    id="a-upper",
                    name="Alpha",
                    y_column_id="a-upper-y",
                ),
                XYSeriesSpec(id="b", name="beta", y_column_id="b-y"),
                XYSeriesSpec(
                    id="a-lower",
                    name="alpha",
                    y_column_id="a-lower-y",
                ),
            ],
        )
        frame = pd.DataFrame(
            {
                "X": [0.0, 1.0],
                "Zulu": [1.0, 2.0],
                "Alpha upper": [2.0, 3.0],
                "Beta": [3.0, 4.0],
                "Alpha lower": [4.0, 5.0],
            }
        )
        column_ids = ["x", "z-y", "a-upper-y", "b-y", "a-lower-y"]
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        window.workbook.active_sheet.xy_settings = settings

        for order_mode in ("Name A-Z", "Name Z-A"):
            with self.subTest(order_mode=order_mode):
                window.settings.group_order = order_mode
                window._refresh_xy_series_selection_list()
                checklist_ids = [
                    str(
                        window.xy_series_selection_list.item(index).data(
                            Qt.ItemDataRole.UserRole
                        )
                    )
                    for index in range(window.xy_series_selection_list.count())
                ]
                renderer_ids = [
                    series.id
                    for series in prepare_xy_data(
                        frame,
                        column_ids,
                        settings,
                        order_mode=order_mode,
                    ).series
                ]
                self.assertEqual(checklist_ids, renderer_ids)

    def test_series_checklist_keeps_scroll_position_after_style_refresh(self):
        settings = XYSettings(
            default_x_column_id="x",
            show_points=False,
            show_line=True,
            series=[
                XYSeriesSpec(
                    id=f"series-{index:02d}",
                    name=f"Series {index:02d}",
                    y_column_id=f"y-{index:02d}",
                )
                for index in range(40)
            ],
        )
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        window.workbook.active_sheet.xy_settings = settings
        window.canvas.set_xy_series_selection("all", ())
        window.handle_plot_object_selection("points")
        window.show()
        self.qapp.processEvents()

        scroll_bar = window.xy_series_selection_list.verticalScrollBar()
        self.assertGreater(scroll_bar.maximum(), 0)
        scroll_bar.setValue(scroll_bar.maximum() // 2)
        previous_scroll_value = scroll_bar.value()
        self.assertGreater(previous_scroll_value, 0)

        with mock.patch.object(window, "schedule_render"):
            window.xy_line_width.setValue(window.xy_line_width.value() + 0.4)
        self.qapp.processEvents()

        self.assertEqual(scroll_bar.value(), previous_scroll_value)

    def test_bulk_visibility_change_keeps_every_visible_series_valid(self):
        settings = self._series_settings(show_points=True)
        first, second, unselected = settings.series
        first.show_points = True
        first.show_line = False
        second.show_points = False
        second.show_line = True
        unselected.show_points = False
        unselected.show_line = True
        window = self.make_xy_window(settings)
        self._select_subset(window, {"a", "b"})

        with mock.patch.object(window, "schedule_render"):
            window.xy_show_line.setChecked(False)

        for series in (first, second):
            self.assertNotEqual(resolved_series_display(settings, series), (False, False))
        self.assertEqual((unselected.show_points, unselected.show_line), (False, True))
        settings.__post_init__()

    def test_reset_selected_series_clears_all_style_fields_and_color_only_for_subset(self):
        settings = self._series_settings(show_points=True)
        values = {
            "show_points": False,
            "show_line": True,
            "marker": "Square",
            "line_style": "Dashed",
            "point_size": 7.0,
            "point_alpha": 0.4,
            "line_width": 2.8,
            "color": "#E15759",
        }
        for series in settings.series:
            for field, value in values.items():
                setattr(series, field, value)
        window = self.make_xy_window(settings)
        self._select_subset(window, {"a", "b"})

        with mock.patch.object(window, "schedule_render"):
            window.use_all_series_style_button.click()

        for series_id in ("a", "b"):
            series = self._series_by_id(settings, series_id)
            for field in (*window._xy_series_style_fields(), "color"):
                self.assertIsNone(getattr(series, field), (series_id, field))
        unchanged = self._series_by_id(settings, "c")
        for field, value in values.items():
            self.assertEqual(getattr(unchanged, field), value, field)
