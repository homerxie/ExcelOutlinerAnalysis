import os
import pathlib
import subprocess
import sys
import tempfile
from unittest import mock

import pandas as pd
from openpyxl import Workbook, load_workbook
from PySide6.QtCore import Qt

from tests.easygraph_case import ROOT, EasyGraphQtTestCase, EasyGraphTestCase
from easygraph import spreadsheet_io
from easygraph.grouping import GroupingSettings
from easygraph.ui import main_window


class SpreadsheetIOTests(EasyGraphTestCase):

    def test_export_without_overlay_returns_an_independent_dataframe(self):
        for frame in (
            pd.DataFrame({"A": [1, 2], "B": [3, 4]}),
            pd.DataFrame(columns=["A", "B"]),
        ):
            with self.subTest(empty=frame.empty):
                exported = spreadsheet_io.excel_export_dataframe(frame)

                self.assertIsNot(exported, frame)
                pd.testing.assert_frame_equal(exported, frame)
                if not exported.empty:
                    exported.iloc[0, 0] = 999
                    self.assertNotEqual(exported.iloc[0, 0], frame.iloc[0, 0])

    def test_overlay_roundtrip_preserves_duplicate_and_multiline_group_columns(self):
        frame = pd.DataFrame(
            [[1, 2, 3], [4, 5, 6]],
            columns=["A", "A", "B\nline"],
        )
        overlay = [{"name": "Target\nline", "values": {"A": 7.5}}]

        exported = spreadsheet_io.excel_export_dataframe(frame, overlay)
        imported, imported_overlay = spreadsheet_io.excel_import_parts(exported)

        self.assertEqual(
            list(exported.columns),
            [
                spreadsheet_io.OVERLAY_EXPORT_ROW_TYPE_COLUMN,
                spreadsheet_io.OVERLAY_EXPORT_NAME_COLUMN,
                "A",
                "A",
                "B\nline",
            ],
        )
        expected = pd.concat(
            [
                frame.iloc[:, 0].astype(float),
                frame.iloc[:, 1].astype(float),
                frame.iloc[:, 2],
            ],
            axis=1,
        )
        expected.columns = frame.columns
        pd.testing.assert_frame_equal(imported, expected)
        self.assertEqual(
            imported_overlay,
            [{"name": "Target\nline", "values": {"A [1]": "7.5", "A [2]": "7.5", "B\nline": ""}}],
        )

    def test_import_vectorizes_samples_with_metadata_in_nondefault_positions(self):
        raw = pd.DataFrame(
            [
                ["1", "", "2", ""],
                ["10", "Target", "20", "overlay"],
                ["3", "ignored", "4", "sample"],
                ["5", "ignored", "6", "unsupported"],
            ],
            columns=[
                "A",
                spreadsheet_io.OVERLAY_EXPORT_NAME_COLUMN,
                "B",
                spreadsheet_io.OVERLAY_EXPORT_ROW_TYPE_COLUMN,
            ],
        )

        with mock.patch.object(
            pd.DataFrame,
            "iterrows",
            side_effect=AssertionError("sample rows must use a vectorized mask"),
        ):
            samples, overlay = spreadsheet_io.excel_import_parts(raw)

        pd.testing.assert_frame_equal(
            samples,
            pd.DataFrame([["1", "2"], ["3", "4"]], columns=["A", "B"]),
        )
        self.assertEqual(
            overlay,
            [{"name": "Target", "values": {"A": "10", "B": "20"}}],
        )

    def test_import_handles_only_overlay_only_samples_and_empty_encoded_frames(self):
        metadata_columns = [
            spreadsheet_io.OVERLAY_EXPORT_ROW_TYPE_COLUMN,
            spreadsheet_io.OVERLAY_EXPORT_NAME_COLUMN,
            "A",
        ]
        cases = (
            (
                pd.DataFrame([["overlay", "Target", 10]], columns=metadata_columns),
                pd.DataFrame(columns=["A"]),
                [{"name": "Target", "values": {"A": "10"}}],
            ),
            (
                pd.DataFrame([["", "", 1], ["sample", "", 2]], columns=metadata_columns),
                pd.DataFrame({"A": [1, 2]}),
                [],
            ),
            (
                pd.DataFrame(columns=metadata_columns),
                pd.DataFrame(columns=["A"]),
                [],
            ),
        )

        for encoded, expected_samples, expected_overlay in cases:
            with self.subTest(rows=len(encoded), overlay=bool(expected_overlay)):
                samples, overlay = spreadsheet_io.excel_import_parts(encoded)

                pd.testing.assert_frame_equal(samples, expected_samples)
                self.assertEqual(overlay, expected_overlay)

    def test_overlay_export_normalizes_null_and_missing_values(self):
        frame = pd.DataFrame({"A": [1], "B": [2], "C": [3]})
        overlay = [{
            "name": "Mixed",
            "values": {"A": 7.5, "B": pd.NA},
        }]

        imported, imported_overlay = spreadsheet_io.excel_import_parts(
            spreadsheet_io.excel_export_dataframe(frame, overlay)
        )

        pd.testing.assert_frame_equal(imported, frame.astype({"A": float}))
        self.assertEqual(
            imported_overlay,
            [{"name": "Mixed", "values": {"A": "7.5", "B": "", "C": ""}}],
        )

    def test_excel_overlay_dataframe_roundtrip_preserves_custom_overlay_rows(self):
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        overlay = [
            {"name": "Target", "values": {"A": "10", "B": "20"}},
            {"name": "Limit", "values": {"A": "7.5", "B": ""}},
        ]

        exported = spreadsheet_io.excel_export_dataframe(df, overlay)
        imported_df, imported_overlay = spreadsheet_io.excel_import_parts(exported)

        self.assertEqual(list(exported.columns), [
            spreadsheet_io.OVERLAY_EXPORT_ROW_TYPE_COLUMN,
            spreadsheet_io.OVERLAY_EXPORT_NAME_COLUMN,
            "A",
            "B",
        ])
        pd.testing.assert_frame_equal(imported_df, df)
        self.assertEqual(imported_overlay, overlay)

    def test_spreadsheet_paths_and_roundtrips_follow_format_policy(self):
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]

        with tempfile.TemporaryDirectory() as tmp:
            directory = pathlib.Path(tmp)
            csv_path = directory / "data.csv"
            self.assertEqual(
                spreadsheet_io.write_spreadsheet(csv_path, df, overlay),
                csv_path,
            )
            csv_df, csv_overlay = spreadsheet_io.read_spreadsheet(csv_path)
            pd.testing.assert_frame_equal(csv_df, df)
            self.assertEqual(csv_overlay, overlay)

            book_path = directory / "book"
            xlsx_path = directory / "book.xlsx"
            self.assertEqual(
                spreadsheet_io.write_spreadsheet(book_path, df, overlay),
                xlsx_path,
            )
            xlsx_df, xlsx_overlay = spreadsheet_io.read_spreadsheet(xlsx_path)
            pd.testing.assert_frame_equal(xlsx_df, df)
            self.assertEqual(xlsx_overlay, overlay)

            for suffix in (".csv", ".xlsx"):
                with self.subTest(plain_suffix=suffix):
                    plain_path = directory / f"plain{suffix}"
                    spreadsheet_io.write_spreadsheet(plain_path, df)
                    plain_df, plain_overlay = spreadsheet_io.read_spreadsheet(plain_path)
                    pd.testing.assert_frame_equal(plain_df, df)
                    self.assertEqual(plain_overlay, [])

            old_path = directory / "old.xls"
            self.assertEqual(
                spreadsheet_io.write_spreadsheet(old_path, df, overlay),
                directory / "old.xls.xlsx",
            )

        encoded = spreadsheet_io.excel_export_dataframe(df, overlay)
        input_path = pathlib.Path("input.xls")
        with mock.patch.object(spreadsheet_io.pd, "read_excel", return_value=encoded) as read_excel:
            imported_df, imported_overlay = spreadsheet_io.read_spreadsheet(input_path)
        read_excel.assert_called_once_with(input_path)
        pd.testing.assert_frame_equal(imported_df, df)
        self.assertEqual(imported_overlay, overlay)

    def test_excel_export_writes_numeric_strings_as_numbers_and_preserves_text(self):
        frame = pd.DataFrame({
            "A": [
                "1",
                "-2.5",
                "1e3",
                "N/A",
                "Sample",
                "",
                " ",
                "\t",
                "NaN",
                "inf",
            ],
        })
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "typed.xlsx"
            spreadsheet_io.write_spreadsheet(path, frame)
            sheet = load_workbook(path).active

        cells = [sheet.cell(row=row, column=1) for row in range(2, 12)]
        self.assertEqual(
            [(cell.value, cell.data_type) for cell in cells],
            [
                (1, "n"),
                (-2.5, "n"),
                (1000, "n"),
                ("N/A", "s"),
                ("Sample", "s"),
                (None, "n"),
                (None, "n"),
                (None, "n"),
                ("NaN", "s"),
                ("inf", "s"),
            ],
        )

    def test_excel_workbook_export_types_overlay_and_sample_values_but_not_metadata(self):
        sheets = [
            spreadsheet_io.SpreadsheetSheet(
                "Typed",
                pd.DataFrame({"A": ["4"]}),
                [{"name": "Target", "values": {"A": "3.5"}}],
            )
        ]
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "typed-book.xlsx"
            spreadsheet_io.write_spreadsheet_book(path, sheets)
            sheet = load_workbook(path)["Typed"]

        self.assertEqual((sheet["A2"].value, sheet["A2"].data_type), ("overlay", "s"))
        self.assertEqual((sheet["B2"].value, sheet["B2"].data_type), ("Target", "s"))
        self.assertEqual((sheet["C2"].value, sheet["C2"].data_type), (3.5, "n"))
        self.assertEqual((sheet["C3"].value, sheet["C3"].data_type), (4, "n"))

    def test_single_level_duplicate_columns_and_overlay_values_survive_csv_and_excel(self):
        frame = pd.DataFrame([[1, 10], [3, 20]], columns=["A", "A"])
        overlays = [{"name": "Target", "values": {"A [1]": "5", "A [2]": "50"}}]
        with tempfile.TemporaryDirectory() as directory:
            for suffix in ("csv", "xlsx"):
                with self.subTest(suffix=suffix):
                    path = pathlib.Path(directory) / f"duplicate.{suffix}"
                    spreadsheet_io.write_spreadsheet(path, frame, overlays)
                    loaded, loaded_overlays = spreadsheet_io.read_spreadsheet(path)
                    pd.testing.assert_frame_equal(loaded, frame)
                    ids = loaded.attrs["group_column_ids"]
                    self.assertEqual(loaded_overlays, [{"name": "Target", "values": {ids[0]: "5", ids[1]: "50"}}])

    def test_grouped_excel_roundtrip_preserves_merged_headers_shared_categories_and_independent_overlays(self):
        grouping = GroupingSettings(parents=[{"id": "p", "name": "First", "column_ids": ["a", "b"]}, {"id": "q", "name": "Second", "column_ids": ["c"]}], shared_subgroups=True, subgroup_ids={"a": "control", "b": "treated", "c": "control"})
        frame = pd.DataFrame([[1, 2, 10], [3, 4, 20]], columns=["Control", "Treatment", "Control"])
        overlays = [{"name": "Target", "values": {"a": "5", "b": "6", "c": "50"}}]
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / "grouped.xlsx"
            spreadsheet_io.write_spreadsheet(path, frame, overlays, grouping=grouping, column_ids=["a", "b", "c"])
            workbook = load_workbook(path)
            sheet = workbook.active
            self.assertEqual(set(map(str, sheet.merged_cells.ranges)), {"C1:D1"})
            self.assertEqual([sheet.cell(2, column).value for column in (3, 4, 5)], ["Control", "Treatment", "Control"])
            self.assertEqual(sheet["C1"].value, "First")
            self.assertEqual(sheet["E1"].value, "Second")
            workbook.close()
            loaded = spreadsheet_io.read_spreadsheet_book(path)[0]
        self.assertEqual(loaded.grouping, grouping)
        self.assertEqual(loaded.column_ids, ["a", "b", "c"])
        self.assertEqual(loaded.dataframe.attrs["group_column_ids"], ["a", "b", "c"])
        self.assertEqual(loaded.overlay_series, overlays)
        pd.testing.assert_frame_equal(loaded.dataframe, frame)

    def test_import_native_excel_merged_headers_uses_irregular_parent_spans(self):
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / "native.xlsx"
            workbook = Workbook()
            sheet = workbook.active
            sheet.append(["Large", None, None, "Small"])
            sheet.merge_cells("A1:C1")
            sheet.append(["A", "B", "C", "A"])
            sheet.append([1, 2, 3, 10])
            workbook.save(path)
            workbook.close()
            loaded = spreadsheet_io.read_spreadsheet_book(path)[0]
        self.assertEqual(list(loaded.dataframe.columns), ["A", "B", "C", "A"])
        self.assertEqual([parent["name"] for parent in loaded.grouping.parents], ["Large", "Small"])
        self.assertEqual([len(parent["column_ids"]) for parent in loaded.grouping.parents], [3, 1])
        self.assertFalse(loaded.grouping.shared_subgroups)
        self.assertEqual(loaded.dataframe.iloc[0].tolist(), [1, 2, 3, 10])

    def test_import_native_excel_numeric_subgroup_titles_are_not_samples(self):
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / "numeric-headers.xlsx"
            workbook = Workbook()
            sheet = workbook.active
            sheet.append(["WT", None, "KO", None])
            sheet.merge_cells("A1:B1")
            sheet.merge_cells("C1:D1")
            sheet.append([0, 10, 0, 10])
            sheet.append([1, 2, 3, 4])
            sheet.append([5, 6, 7, 8])
            workbook.save(path)
            workbook.close()
            loaded = spreadsheet_io.read_spreadsheet_book(path)[0]
        self.assertEqual(list(loaded.dataframe.columns), ["0", "10", "0", "10"])
        self.assertEqual(loaded.dataframe.values.tolist(), [[1, 2, 3, 4], [5, 6, 7, 8]])
        self.assertEqual([parent["name"] for parent in loaded.grouping.parents], ["WT", "KO"])
        self.assertEqual([parent["column_ids"] for parent in loaded.grouping.parents], [loaded.column_ids[:2], loaded.column_ids[2:]])
        self.assertEqual(len(set(loaded.column_ids)), 4)

    def test_grouped_excel_visible_renames_override_saved_header_names(self):
        grouping = GroupingSettings(parents=[{"id": "p", "name": "Before", "column_ids": ["a", "b"]}])
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / "edited.xlsx"
            spreadsheet_io.write_spreadsheet(path, pd.DataFrame([[1, 2]], columns=["A", "B"]), grouping=grouping, column_ids=["a", "b"])
            workbook = load_workbook(path)
            workbook.active["A1"] = "After"
            workbook.active["A2"] = "Renamed"
            workbook.save(path)
            workbook.close()
            loaded = spreadsheet_io.read_spreadsheet_book(path)[0]
        self.assertEqual(loaded.grouping.parents[0]["name"], "After")
        self.assertEqual(loaded.grouping.parents[0]["id"], "p")
        self.assertEqual(list(loaded.dataframe.columns), ["Renamed", "B"])

    def test_spreadsheet_io_api_is_exact(self):
        expected = [
            "OVERLAY_EXPORT_CUSTOM_ROW",
            "OVERLAY_EXPORT_NAME_COLUMN",
            "OVERLAY_EXPORT_ROW_TYPE_COLUMN",
            "OVERLAY_EXPORT_SAMPLE_ROW",
            "SpreadsheetSheet",
            "excel_export_dataframe",
            "excel_import_parts",
            "read_spreadsheet",
            "read_spreadsheet_book",
            "write_spreadsheet",
            "write_spreadsheet_book",
        ]
        self.assertEqual(spreadsheet_io.__all__, expected)

    def test_excel_workbook_roundtrip_preserves_sheet_order_data_and_overlays(self):
        sheets = [
            spreadsheet_io.SpreadsheetSheet(
                "Control",
                pd.DataFrame({"A": [1, 2]}),
                [{"name": "Target", "values": {"A": "3"}}],
            ),
            spreadsheet_io.SpreadsheetSheet(
                "剂量反应",
                pd.DataFrame({"Dose": [4, 5], "Response": [6, 7]}),
            ),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "all-sheets.xlsx"
            self.assertEqual(spreadsheet_io.write_spreadsheet_book(path, sheets), path)
            loaded = spreadsheet_io.read_spreadsheet_book(path)

        self.assertEqual([sheet.name for sheet in loaded], ["Control", "剂量反应"])
        pd.testing.assert_frame_equal(loaded[0].dataframe, sheets[0].dataframe)
        pd.testing.assert_frame_equal(loaded[1].dataframe, sheets[1].dataframe)
        self.assertEqual(loaded[0].overlay_series, sheets[0].overlay_series)
        self.assertEqual(loaded[1].overlay_series, [])

    def test_excel_workbook_export_sanitizes_and_deduplicates_sheet_names(self):
        sheets = [
            spreadsheet_io.SpreadsheetSheet("A/B", pd.DataFrame({"A": [1]})),
            spreadsheet_io.SpreadsheetSheet("A:B", pd.DataFrame({"B": [2]})),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "sanitized.xlsx"
            spreadsheet_io.write_spreadsheet_book(path, sheets)
            with pd.ExcelFile(path) as workbook:
                names = workbook.sheet_names

        self.assertEqual(names, ["A_B", "A_B (2)"])

    def test_direct_spreadsheet_contract_works_with_and_without_optimization(self):
        code = """
import sys
import pandas as pd
from easygraph import spreadsheet_io

frame = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]
encoded = spreadsheet_io.excel_export_dataframe(frame, overlay)
decoded, decoded_overlay = spreadsheet_io.excel_import_parts(encoded)
if not decoded.equals(frame):
    raise SystemExit("spreadsheet frame roundtrip failed")
if decoded_overlay != overlay:
    raise SystemExit("spreadsheet overlay roundtrip failed")
for forbidden in ("PySide6", "matplotlib", "seaborn", "scipy"):
    if any(
        name == forbidden or name.startswith(forbidden + ".")
        for name in sys.modules
    ):
        raise SystemExit(f"forbidden dependency loaded: {forbidden}")
"""
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(ROOT / "src")
        for flags in ([], ["-O"]):
            with self.subTest(flags=flags):
                result = subprocess.run(
                    [sys.executable, *flags, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=15,
                )
                self.assertEqual(
                    result.returncode,
                    0,
                    msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
                )


class SpreadsheetUIIntegrationTests(EasyGraphQtTestCase):

    def test_export_excel_writes_overlay_rows(self):
        window = self.make_window(initial_render=True)
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]
        window.settings.custom_overlay_series = overlay
        window.settings.extra_custom_overlay = True
        window.set_table_dataframe(df, overlay)

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "overlay_export.xlsx"
            with mock.patch.object(main_window.QFileDialog, "getSaveFileName", return_value=(str(path), "")):
                window.export_excel()

            imported_df, imported_overlay = spreadsheet_io.excel_import_parts(pd.read_excel(path))

        pd.testing.assert_frame_equal(imported_df, df)
        self.assertEqual(imported_overlay, [{"name": "Target", "values": {"A": "10", "B": "20"}}])

    def test_import_excel_restores_overlay_rows(self):
        window = self.make_window(initial_render=True)
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        overlay = [{"name": "Target", "values": {"A": "10", "B": "20"}}]

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "overlay_import.xlsx"
            spreadsheet_io.excel_export_dataframe(df, overlay).to_excel(path, index=False)
            with (
                mock.patch.object(main_window.QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                mock.patch.object(main_window, "choose_spreadsheet_sheets", side_effect=lambda _parent, sheets: sheets),
            ):
                window.import_excel()

        self.assertEqual(window.custom_overlay_row_count(), 1)
        self.assertTrue(window.settings.extra_custom_overlay)
        column_ids = window.workbook.active_sheet.column_ids
        self.assertEqual(window.settings.custom_overlay_series, [{"name": "Target", "values": {column_ids[0]: "10", column_ids[1]: "20"}}])
        self.assertEqual(window.table.table_model.headerData(1, Qt.Vertical, Qt.DisplayRole), "Target")
        self.assertEqual(window.table.table_model.cell_text(1, 0), "10")
        pd.testing.assert_frame_equal(window._user_group_dataframe(), df.astype(str))

    def test_import_plain_excel_clears_existing_overlay_rows(self):
        window = self.make_window(initial_render=True)
        window.add_custom_overlay_row()
        window.table.table_model.set_cell_text(1, 0, "10")
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "plain_import.xlsx"
            df.to_excel(path, index=False)
            with (
                mock.patch.object(window, "_prompt_unsaved_changes", return_value="discard"),
                mock.patch.object(main_window.QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                mock.patch.object(main_window, "choose_spreadsheet_sheets", side_effect=lambda _parent, sheets: sheets),
            ):
                window.import_excel()

        self.assertEqual(window.custom_overlay_row_count(), 0)
        self.assertFalse(window.settings.extra_custom_overlay)
        self.assertEqual(window.settings.custom_overlay_series, [])
        self.assertEqual(window.sample_start_row(), 1)
        pd.testing.assert_frame_equal(window._user_group_dataframe(), df.astype(str))
