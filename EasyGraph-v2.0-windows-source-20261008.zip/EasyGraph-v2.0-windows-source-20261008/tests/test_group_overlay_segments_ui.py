from dataclasses import asdict
import json
from pathlib import Path
import tempfile
from unittest import mock

import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase, patch_qsettings
from easygraph import template_io
from easygraph.grouping import create_parent
from easygraph.project_io import (
    chart_settings_from_dict,
    read_workbook_project,
    write_project,
)
from easygraph.recovery import RecoveryManager, read_recovery_workbook
from easygraph.settings import ChartSettings
from easygraph.workbook import SHEET_MODE_XY, SheetDocument, WorkbookDocument


class GroupOverlaySegmentsUITests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        preferences, _ = patch_qsettings()
        preferences.start()
        self.addCleanup(preferences.stop)

    def grouped_window(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame([[1, 2, 3], [4, 5, 6]], columns=['A', 'B', 'C'])
        )
        window.table.horizontalHeader().select_parent_columns([0, 1])
        self.assertTrue(window.grouping_controls.merge_selected_headers('Batch'))
        return window

    def test_no_parent_groups_disable_the_unchecked_option(self):
        window = self.make_window()
        checkbox = window.ui.lineOverlayBreakBetweenParentsCheck

        self.assertIs(window.line_overlay_break_between_parents, checkbox)
        self.assertIs(
            window.ui.lineOverlayBreakBetweenParentsLabel.buddy(),
            checkbox,
        )
        self.assertFalse(checkbox.isEnabled())
        self.assertFalse(window.ui.lineOverlayBreakBetweenParentsLabel.isEnabled())
        self.assertFalse(checkbox.isChecked())
        self.assertFalse(window.settings.line_overlay_break_between_parents)
        checkbox.click()
        self.assertFalse(window.settings.line_overlay_break_between_parents)

    def test_merge_enables_option_without_enabling_an_overlay_and_click_updates_settings(self):
        window = self.grouped_window()
        checkbox = window.line_overlay_break_between_parents

        self.assertEqual(window.line_overlay_stat.currentText(), 'None')
        self.assertFalse(window.extra_custom_overlay.isChecked())
        self.assertTrue(checkbox.isEnabled())
        self.assertTrue(window.ui.lineOverlayBreakBetweenParentsLabel.isEnabled())
        with mock.patch.object(window, 'schedule_render') as schedule_render:
            checkbox.click()
        self.assertTrue(window.settings.line_overlay_break_between_parents)
        schedule_render.assert_called()

        checkbox.click()
        self.assertFalse(window.settings.line_overlay_break_between_parents)

    def test_unmerge_disables_without_losing_preference_and_undo_restores_availability(self):
        window = self.grouped_window()
        checkbox = window.line_overlay_break_between_parents
        checkbox.click()
        original = window.table_dataframe()

        self.assertTrue(window.grouping_controls.unmerge_selected_headers())
        self.assertFalse(window.workbook.active_sheet.grouping.parents)
        self.assertFalse(checkbox.isEnabled())
        self.assertTrue(checkbox.isChecked())
        self.assertTrue(window.settings.line_overlay_break_between_parents)
        pd.testing.assert_frame_equal(window.table_dataframe(), original)

        window.undo_table_change()
        self.assertTrue(window.workbook.active_sheet.grouping.parents)
        self.assertTrue(checkbox.isEnabled())
        self.assertTrue(checkbox.isChecked())
        self.assertTrue(window.settings.line_overlay_break_between_parents)
        window.redo_table_change()
        self.assertFalse(checkbox.isEnabled())
        self.assertTrue(window.settings.line_overlay_break_between_parents)

    def test_switching_sheets_keeps_separate_preferences_and_disables_xy(self):
        window = self.grouped_window()
        checkbox = window.line_overlay_break_between_parents
        checkbox.click()
        grouped_sheet = window.workbook.active_sheet

        with mock.patch.object(window, 'render'), mock.patch.object(window, 'schedule_render'):
            window.add_sheet()
            ungrouped_sheet = window.workbook.active_sheet
            self.assertFalse(checkbox.isEnabled())
            self.assertFalse(checkbox.isChecked())
            self.assertFalse(ungrouped_sheet.settings.line_overlay_break_between_parents)

            window.switch_sheet(0)
            self.assertTrue(checkbox.isEnabled())
            self.assertTrue(checkbox.isChecked())
            self.assertIs(window.settings, grouped_sheet.settings)

            window.add_sheet(SHEET_MODE_XY)
            xy_sheet = window.workbook.active_sheet
            xy_sheet.settings.line_overlay_break_between_parents = True
            window.apply_settings_to_controls()
            self.assertFalse(checkbox.isEnabled())
            self.assertTrue(checkbox.isChecked())

            window.switch_sheet(1)
            self.assertFalse(checkbox.isChecked())
            window.switch_sheet(0)
            self.assertTrue(checkbox.isEnabled())
            self.assertTrue(checkbox.isChecked())
            self.assertTrue(xy_sheet.settings.line_overlay_break_between_parents)

    def test_project_roundtrip_restores_option_and_group_availability(self):
        window = self.grouped_window()
        window.line_overlay_break_between_parents.click()
        window._store_active_sheet()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'discrete-lines.eg'
            write_project(path, window.workbook)
            loaded = read_workbook_project(path)

        self.assertTrue(loaded.active_sheet.settings.line_overlay_break_between_parents)
        self.assertEqual(
            asdict(loaded.active_sheet.grouping),
            asdict(window.workbook.active_sheet.grouping),
        )
        restored = self.make_window()
        restored.workbook = loaded
        restored._load_active_sheet(render=False)
        self.assertTrue(restored.line_overlay_break_between_parents.isEnabled())
        self.assertTrue(restored.line_overlay_break_between_parents.isChecked())

    def test_style_template_roundtrip_and_application_keep_discrete_lines(self):
        settings = ChartSettings(line_overlay_break_between_parents=True)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = template_io.write_style_template('Discrete lines', settings, root)
            loaded = template_io.read_style_template(path.stem, root)
        applied = template_io.apply_style_template_settings(ChartSettings(), loaded)
        self.assertTrue(loaded.line_overlay_break_between_parents)
        self.assertTrue(applied.line_overlay_break_between_parents)

    def test_legacy_settings_and_template_keep_continuous_lines_by_default(self):
        legacy = asdict(ChartSettings(line_overlay_break_between_parents=True))
        del legacy['line_overlay_break_between_parents']
        self.assertFalse(chart_settings_from_dict(legacy).line_overlay_break_between_parents)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'legacy.json'
            path.write_text(json.dumps(legacy), encoding='utf-8')
            loaded = template_io.read_style_template_file(path)
        self.assertFalse(loaded.line_overlay_break_between_parents)

    def test_recovery_checkpoint_and_later_settings_edit_preserve_preference(self):
        sheet = SheetDocument(
            'Grouped',
            pd.DataFrame([[1, 2]], columns=['A', 'B']),
            settings=ChartSettings(line_overlay_break_between_parents=True),
        )
        create_parent(sheet.grouping, sheet.column_ids, 'Batch')
        workbook = WorkbookDocument([sheet], sheet.id)
        with tempfile.TemporaryDirectory() as directory:
            manager = RecoveryManager(interval_seconds=2, root=Path(directory))
            try:
                manager.replace_document(workbook, None, dirty=True)
                self.assertTrue(manager.wait_for_checkpoint(10))
                checkpoint, _ = read_recovery_workbook(manager.session_dir)
                self.assertTrue(checkpoint.active_sheet.settings.line_overlay_break_between_parents)

                sheet.settings.line_overlay_break_between_parents = False
                manager.record_settings(sheet.id, sheet.settings)
                self.assertTrue(manager.flush())
                recovered, _ = read_recovery_workbook(manager.session_dir)
                self.assertFalse(recovered.active_sheet.settings.line_overlay_break_between_parents)
                self.assertEqual(asdict(recovered.active_sheet.grouping), asdict(sheet.grouping))
            finally:
                manager.close(discard=True)


if __name__ == '__main__':
    import unittest
    unittest.main()
