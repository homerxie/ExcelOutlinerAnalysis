from __future__ import annotations

import pandas as pd

from tests.easygraph_case import EasyGraphTestCase

from easygraph.analysis_results import AnalysisSettings
from easygraph.settings import ChartSettings
from easygraph.workbook import (
    SHEET_MODE_GROUPS,
    SHEET_MODE_XY,
    SheetDocument,
    WorkbookDocument,
    next_default_sheet_name,
    sheet_name_error,
    unique_sheet_name,
)
from easygraph.xy_series import XYSeriesSpec, XYSettings


class WorkbookTests(EasyGraphTestCase):
    def sheet(self, name: str, value: int) -> SheetDocument:
        return SheetDocument(
            name=name,
            dataframe=pd.DataFrame({"Value": [value]}),
            settings=ChartSettings(title=name),
        )

    def test_workbook_requires_unique_nonempty_sheets_and_keeps_active_identity(self):
        first = self.sheet("First", 1)
        second = self.sheet("Second", 2)
        workbook = WorkbookDocument([first, second], second.id)

        self.assertIs(workbook.active_sheet, second)
        workbook.move_sheet(1, 0)
        self.assertIs(workbook.active_sheet, second)
        self.assertEqual([sheet.name for sheet in workbook.sheets], ["Second", "First"])

        removed = workbook.remove_sheet(0)
        self.assertIs(removed, second)
        self.assertIs(workbook.active_sheet, first)
        with self.assertRaisesRegex(ValueError, "at least one sheet"):
            workbook.remove_sheet(0)

        unsafe = self.sheet("Unsafe", 3)
        unsafe.id = "../../outside"
        with self.assertRaisesRegex(ValueError, "Sheet IDs may contain only"):
            WorkbookDocument([unsafe])

    def test_sheet_clone_copies_content_and_settings_with_a_new_identity(self):
        source = self.sheet("Original", 3)
        source.mode = SHEET_MODE_XY
        source.xy_settings = XYSettings(
            default_x_column_id=source.column_ids[0],
            series=[
                XYSeriesSpec(
                    id="series-1",
                    name="Value",
                    y_column_id=source.column_ids[0],
                    visible=False,
                )
            ],
        )
        source.analysis_settings = AnalysisSettings(
            visible_statistics=["Mean", "Sample"]
        )
        clone = source.clone(name="Copy")

        self.assertNotEqual(clone.id, source.id)
        self.assertEqual(clone.name, "Copy")
        self.assertIsNot(clone.dataframe, source.dataframe)
        self.assertIsNot(clone.settings, source.settings)
        self.assertIsNot(clone.analysis_settings, source.analysis_settings)
        self.assertIsNot(clone.xy_settings, source.xy_settings)
        self.assertEqual(clone.mode, SHEET_MODE_XY)
        self.assertEqual(clone.column_ids, source.column_ids)
        pd.testing.assert_frame_equal(clone.dataframe, source.dataframe)
        self.assertEqual(clone.settings.title, source.settings.title)
        self.assertEqual(
            clone.analysis_settings.visible_statistics,
            ["Mean", "Sample"],
        )

        clone.dataframe.iloc[0, 0] = 99
        clone.settings.title = "Changed"
        clone.analysis_settings.visible_statistics.remove("Mean")
        self.assertEqual(source.dataframe.iloc[0, 0], 3)
        self.assertEqual(source.settings.title, "Original")
        self.assertEqual(
            source.analysis_settings.visible_statistics,
            ["Mean", "Sample"],
        )

    def test_sheet_modes_and_column_ids_are_validated(self):
        groups = self.sheet("Groups", 1)
        self.assertEqual(groups.mode, SHEET_MODE_GROUPS)
        self.assertEqual(len(groups.column_ids), groups.dataframe.shape[1])
        self.assertEqual(len(set(groups.column_ids)), len(groups.column_ids))

        xy = SheetDocument(
            name="XY",
            dataframe=pd.DataFrame({"X": [1], "Y": [2]}),
            mode=SHEET_MODE_XY,
        )
        self.assertEqual(xy.mode, SHEET_MODE_XY)
        self.assertEqual(len(xy.column_ids), 2)

        with self.assertRaisesRegex(ValueError, "Unsupported sheet mode"):
            SheetDocument(
                name="Invalid",
                dataframe=pd.DataFrame({"A": [1]}),
                mode="scatter",
            )
        with self.assertRaisesRegex(ValueError, "Column IDs must match"):
            SheetDocument(
                name="Invalid IDs",
                dataframe=pd.DataFrame({"A": [1], "B": [2]}),
                column_ids=["only-one"],
            )
        with self.assertRaisesRegex(ValueError, "Column IDs must be unique"):
            SheetDocument(
                name="Duplicate IDs",
                dataframe=pd.DataFrame({"A": [1], "B": [2]}),
                column_ids=["same", "same"],
            )

    def test_sheet_names_follow_excel_compatible_user_facing_rules(self):
        self.assertEqual(next_default_sheet_name(["Sheet 1", "Sheet 3"]), "Sheet 2")
        self.assertEqual(unique_sheet_name(["Result"], "Result"), "Result (2)")
        self.assertEqual(unique_sheet_name(["A_B"], "A/B"), "A_B (2)")
        self.assertEqual(sheet_name_error("", []), "Sheet name cannot be empty.")
        self.assertEqual(sheet_name_error("A/B", []), "Sheet name cannot contain: /")
        self.assertEqual(sheet_name_error("result", ["Result"]), "Sheet names must be unique.")


if __name__ == "__main__":
    __import__("unittest").main()
