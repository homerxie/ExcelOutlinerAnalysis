from __future__ import annotations

from copy import deepcopy
import time
from unittest.mock import Mock, patch

from PySide6.QtCore import QPoint, QRect, Qt
from PySide6.QtGui import QValidator
from PySide6.QtWidgets import QDialog, QSizePolicy

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.ui.xy_curve_fit_dialog import XYCurveFitDialog
from easygraph.xy_fitting import (
    FIT_MODEL_REGISTRY,
    FitParameterSpec,
    default_fit_spec,
)


class XYCurveFitDialogTests(EasyGraphQtTestCase):
    def dialog(
        self,
        *,
        x=(0.0, 1.0, 2.0, 3.0),
        y=(1.0, 3.0, 5.0, 7.0),
        existing_specs=(),
        existing_results=None,
        preview_callback=None,
        selected_series_ids=(),
        annotation_mode="equation",
    ) -> XYCurveFitDialog:
        dialog = XYCurveFitDialog(
            None,
            [
                {"id": "series-a", "name": "Response A", "x": x, "y": y},
                {"id": "series-b", "name": "Response B", "x": x, "y": y},
            ],
            existing_specs,
            existing_results,
            selected_series_ids,
            annotation_mode=annotation_mode,
            preview_callback=preview_callback,
        )
        self.addCleanup(dialog.close)
        return dialog

    def wait_until(self, predicate, timeout: float = 5.0) -> None:
        deadline = time.monotonic() + timeout
        while not predicate() and time.monotonic() < deadline:
            self.qapp.processEvents()
            # Release the GIL so QRunnable can execute the Python portion of
            # the fit as well as the NumPy/SciPy calls.
            time.sleep(0.01)
        self.assertTrue(predicate(), "Timed out waiting for the background fit")

    @staticmethod
    def select_model(dialog: XYCurveFitDialog, model_id: str) -> None:
        for index in range(dialog.ui.modelCombo.count()):
            if dialog.ui.modelCombo.itemData(index) == model_id:
                dialog.ui.modelCombo.setCurrentIndex(index)
                return
        raise AssertionError(f"Missing model {model_id}")

    @staticmethod
    def widget_rect_in(widget, ancestor) -> QRect:
        return QRect(widget.mapTo(ancestor, QPoint(0, 0)), widget.size())

    def assert_fit_controls_do_not_overlap(
        self,
        dialog: XYCurveFitDialog,
    ) -> None:
        ui = dialog.ui
        pair_groups = (
            (
                ui.fitPane,
                (
                    (ui.equationLabel, ui.equationDisplayLabel),
                    (ui.equationDisplayLabel, ui.modelDescriptionLabel),
                    (ui.modelDescriptionLabel, ui.customEquationWidget),
                    (ui.customEquationWidget, ui.parameterTable),
                    (ui.parameterTable, ui.parameterHintLabel),
                    (ui.parameterTable, ui.previewButton),
                    (ui.parameterTable, ui.fitButton),
                    (ui.parameterHintLabel, ui.previewButton),
                    (ui.parameterHintLabel, ui.fitButton),
                ),
            ),
            (
                ui.resultsGroup,
                (
                    (ui.annotationModeLabel, ui.equationAnnotationRadioButton),
                    (
                        ui.equationAnnotationRadioButton,
                        ui.parameterAnnotationRadioButton,
                    ),
                    (
                        ui.parameterAnnotationRadioButton,
                        ui.parameterAnnotationSettingsButton,
                    ),
                    (ui.annotationModeLabel, ui.statusLabel),
                    (ui.equationAnnotationRadioButton, ui.statusLabel),
                    (ui.parameterAnnotationRadioButton, ui.statusLabel),
                    (ui.parameterAnnotationSettingsButton, ui.statusLabel),
                    (ui.statusLabel, ui.progressBar),
                    (ui.statusLabel, ui.resultsTable),
                    (ui.progressBar, ui.resultsTable),
                    (ui.resultsTable, ui.selectedFitDetailsLabel),
                    (ui.resultsTable, ui.fitDetailsText),
                    (ui.selectedFitDetailsLabel, ui.fitDetailsText),
                ),
            ),
            (
                ui.mainSplitter,
                ((ui.fitSetupGroup, ui.resultsGroup),),
            ),
        )
        for ancestor, pairs in pair_groups:
            for first, second in pairs:
                first_rect = self.widget_rect_in(first, ancestor)
                second_rect = self.widget_rect_in(second, ancestor)
                self.assertFalse(
                    first_rect.intersects(second_rect),
                    f"{first.objectName()} {first_rect} overlaps "
                    f"{second.objectName()} {second_rect}",
                )

        containers = (
            (
                ui.modelGroup,
                (
                    ui.equationLabel,
                    ui.equationDisplayLabel,
                    ui.modelDescriptionLabel,
                    ui.customEquationWidget,
                    ui.parameterTable,
                    ui.parameterHintLabel,
                    ui.previewButton,
                    ui.fitButton,
                ),
            ),
            (
                ui.resultsGroup,
                (
                    ui.statusLabel,
                    ui.progressBar,
                    ui.annotationModeLabel,
                    ui.equationAnnotationRadioButton,
                    ui.parameterAnnotationRadioButton,
                    ui.parameterAnnotationSettingsButton,
                    ui.resultsTable,
                    ui.selectedFitDetailsLabel,
                    ui.fitDetailsText,
                ),
            ),
            (ui.fitSetupGroup, (ui.setupSplitter,)),
            (ui.setupSplitter, (ui.seriesPane, ui.fitScrollArea)),
        )
        for container, children in containers:
            for child in children:
                child_rect = self.widget_rect_in(child, container)
                self.assertTrue(
                    container.rect().contains(child_rect),
                    f"{child.objectName()} escapes {container.objectName()}",
                )

        custom_children = (
            ui.customEquationEdit,
            ui.insertTemplateLabel,
            ui.insertSigmaButton,
            ui.insertIntegralButton,
            ui.functionTemplateLabel,
            ui.functionCombo,
            ui.insertFunctionButton,
            ui.customEquationHelpLabel,
        )
        for child in custom_children:
            child_rect = self.widget_rect_in(child, ui.customEquationWidget)
            self.assertTrue(
                ui.customEquationWidget.rect().contains(child_rect),
                f"{child.objectName()} escapes customEquationWidget",
            )
        sigma_rect = self.widget_rect_in(
            ui.insertSigmaButton,
            ui.customEquationWidget,
        )
        integral_rect = self.widget_rect_in(
            ui.insertIntegralButton,
            ui.customEquationWidget,
        )
        self.assertFalse(sigma_rect.intersects(integral_rect))
        function_combo_rect = self.widget_rect_in(
            ui.functionCombo,
            ui.customEquationWidget,
        )
        function_button_rect = self.widget_rect_in(
            ui.insertFunctionButton,
            ui.customEquationWidget,
        )
        self.assertFalse(function_combo_rect.intersects(function_button_rect))
        self.assertFalse(integral_rect.intersects(function_combo_rect))
        help_rect = self.widget_rect_in(
            ui.customEquationHelpLabel,
            ui.customEquationWidget,
        )
        self.assertFalse(function_combo_rect.intersects(help_rect))
        self.assertFalse(function_button_rect.intersects(help_rect))

    def test_constructs_with_one_fit_target_and_standard_model_equation(self):
        dialog = self.dialog()

        self.assertEqual(dialog.ui.seriesList.count(), 2)
        self.assertEqual(dialog.selected_series_ids(), ("series-a",))
        self.assertGreater(dialog.ui.modelCombo.count(), 3)
        self.assertEqual(dialog.ui.modelCombo.currentData(), "linear")
        self.assertEqual(dialog.ui.equationLabel.text(), "Equation")
        self.assertEqual(
            dialog.ui.equationDisplayLabel.text(),
            "y = slope * x + intercept",
        )
        self.assertNotIn("x0", dialog.ui.equationDisplayLabel.text())
        self.assertNotIn("z =", dialog.ui.equationDisplayLabel.text())
        self.assertEqual(dialog.ui.parameterTable.item(0, 0).text(), "slope")
        self.assertEqual(dialog.ui.parameterTable.item(1, 0).text(), "intercept")
        self.assertEqual(dialog.ui.parameterTable.item(1, 0).data(Qt.UserRole), "intercept")
        self.assertTrue(dialog.ui.customEquationWidget.isHidden())
        self.assertEqual(dialog.ui.parameterTable.rowCount(), 2)
        self.assertTrue(dialog.ui.equationAnnotationRadioButton.isChecked())
        self.assertFalse(dialog.ui.parameterAnnotationRadioButton.isChecked())
        self.assertFalse(dialog.ui.parameterAnnotationSettingsButton.isEnabled())
        self.assertEqual(dialog.ui.fitSetupGroup.title(), "1. Fit setup")
        self.assertEqual(dialog.ui.seriesHeadingLabel.text(), "Series to fit")
        self.assertEqual(dialog.ui.modelGroup.title(), "Model and starting values")
        self.assertEqual(dialog.ui.resultsGroup.title(), "2. Fit results")

    def test_result_display_switch_is_independent_from_fit_target(self):
        first = default_fit_spec("series-a", "linear")
        first.show_equation = True
        first.equation_position_x = 0.25
        first.equation_position_y = 0.75
        second = default_fit_spec("series-b", "linear")
        second.show_equation = False
        dialog = self.dialog(existing_specs=[first, second])

        self.assertEqual(dialog.selected_series_ids(), ("series-a",))
        self.assertEqual(dialog.ui.resultsTable.item(0, 0).checkState(), Qt.Checked)
        self.assertEqual(dialog.ui.resultsTable.item(1, 0).checkState(), Qt.Unchecked)

        dialog.ui.resultsTable.item(1, 0).setCheckState(Qt.Checked)
        dialog._apply()

        specs = {spec.series_id: spec for spec in dialog.specs()}
        self.assertTrue(specs["series-a"].show_equation)
        self.assertTrue(specs["series-b"].show_equation)
        self.assertEqual(specs["series-a"].equation_position_x, 0.25)
        self.assertEqual(specs["series-a"].equation_position_y, 0.75)

    def test_annotation_mode_is_shared_and_saved_separately_from_rows(self):
        first = default_fit_spec("series-a", "linear")
        first.show_equation = True
        second = default_fit_spec("series-b", "linear")
        second.show_equation = False
        dialog = self.dialog(
            existing_specs=[first, second],
            annotation_mode="parameters",
        )

        self.assertTrue(dialog.ui.parameterAnnotationRadioButton.isChecked())
        self.assertEqual(dialog.annotation_mode(), "parameters")
        dialog.ui.equationAnnotationRadioButton.click()
        self.assertEqual(dialog.annotation_mode(), "equation")
        self.assertTrue(dialog.result().specs[0].show_equation)
        self.assertFalse(dialog.result().specs[1].show_equation)
        self.assertEqual(dialog.result().annotation_mode, "equation")

    def test_new_fit_can_be_enabled_from_its_result_row(self):
        dialog = self.dialog()

        dialog.run_fit()
        self.wait_until(lambda: not dialog._busy)

        self.assertFalse(dialog.specs()[0].show_equation)
        dialog.ui.resultsTable.item(0, 0).setCheckState(Qt.Checked)
        self.assertTrue(dialog.specs()[0].show_equation)

    def test_parameter_display_settings_are_per_fit_and_keep_result_summary(self):
        dialog = self.dialog()
        dialog.run_fit()
        self.wait_until(lambda: not dialog._busy)
        dialog.ui.parameterAnnotationRadioButton.click()
        self.assertTrue(dialog.ui.parameterAnnotationSettingsButton.isEnabled())
        previews = []
        dialog.fitResultsReady.connect(lambda results: previews.append(results))

        with patch(
            "easygraph.ui.xy_curve_fit_dialog.XYFitParameterDisplayDialog"
        ) as dialog_class:
            parameter_dialog = dialog_class.return_value
            parameter_dialog.exec.return_value = QDialog.Accepted
            parameter_dialog.selections.return_value = {
                "series-a": ["intercept"]
            }
            dialog.edit_parameter_annotations()

        spec = dialog.specs()[0]
        self.assertEqual(spec.annotation_parameter_names, ["intercept"])
        self.assertEqual(dialog.annotation_mode(), "parameters")
        self.assertIn("slope =", dialog.ui.resultsTable.item(0, 5).text())
        self.assertIn("intercept =", dialog.ui.resultsTable.item(0, 5).text())
        self.assertEqual(len(previews), 1)

    def test_model_combo_contains_only_selectable_models_and_loads_saved_model(self):
        dialog = self.dialog()
        combo = dialog.ui.modelCombo

        self.assertGreater(combo.count(), 0)
        self.assertEqual(
            {combo.itemData(index) for index in range(combo.count())},
            set(FIT_MODEL_REGISTRY),
        )
        for index in range(combo.count()):
            item = combo.model().item(index)
            self.assertIsNotNone(combo.itemData(index))
            self.assertTrue(item.isEnabled())
            self.assertTrue(item.isSelectable())

        saved = default_fit_spec("series-a", "polynomial5")
        loaded_dialog = self.dialog(existing_specs=[saved])
        self.assertEqual(loaded_dialog.ui.modelCombo.currentData(), "polynomial5")

    def test_each_polynomial_shows_standard_x_equation_and_parameter_names(self):
        dialog = self.dialog(x=(1.0, 2.0, 3.0, 4.0))
        polynomial_model_ids = (
            "polynomial2",
            "polynomial3",
            "polynomial4",
            "polynomial5",
        )
        self.assertTrue(set(polynomial_model_ids).issubset(FIT_MODEL_REGISTRY))

        for model_id in polynomial_model_ids:
            with self.subTest(model_id=model_id):
                self.select_model(dialog, model_id)
                model = FIT_MODEL_REGISTRY[model_id]
                displayed_equation = dialog.ui.equationDisplayLabel.text()
                self.assertEqual(
                    displayed_equation,
                    {
                        "polynomial2": "y = a * x^2 + b * x + c",
                        "polynomial3": "y = a * x^3 + b * x^2 + c * x + d",
                        "polynomial4": (
                            "y = a * x^4 + b * x^3 + c * x^2 + d * x + e"
                        ),
                        "polynomial5": (
                            "y = a * x^5 + b * x^4 + c * x^3 + "
                            "d * x^2 + e * x + f"
                        ),
                    }[model_id],
                )
                self.assertNotIn("x0", displayed_equation)
                self.assertNotIn("z =", displayed_equation)
                self.assertEqual(
                    [
                        dialog.ui.parameterTable.item(row, 0).data(Qt.UserRole)
                        for row in range(dialog.ui.parameterTable.rowCount())
                    ],
                    list(model.parameter_names),
                )
                self.assertEqual(
                    [
                        dialog.ui.parameterTable.item(row, 0).text()
                        for row in range(dialog.ui.parameterTable.rowCount())
                    ],
                    list(model.parameter_names),
                )
                self.assertTrue(dialog.ui.modelDescriptionLabel.text().strip())

    def test_minimum_custom_layout_uses_scrolling_without_overlaps(self):
        dialog = self.dialog()
        dialog.resize(dialog.minimumSize())
        dialog.show()
        self.qapp.processEvents()

        self.select_model(dialog, "custom")
        dialog.ui.equationDisplayLabel.setText(
            "y = baseline + amplitude * exp(-rate * x) + drift * x + "
            "seasonal * sin(frequency * x + phase)"
        )
        dialog.ui.setupSplitter.setSizes([700, 258])
        dialog._set_busy(True)
        self.qapp.processEvents()

        maximum_hint_height = (
            2 * dialog.ui.hintLabel.fontMetrics().lineSpacing() + 8
        )
        self.assertLessEqual(
            dialog.ui.hintLabel.height(),
            maximum_hint_height,
        )
        self.assertFalse(dialog.ui.mainSplitter.childrenCollapsible())
        self.assertFalse(dialog.ui.setupSplitter.childrenCollapsible())
        setup_rect = self.widget_rect_in(
            dialog.ui.fitSetupGroup,
            dialog.ui.mainSplitter,
        )
        results_rect = self.widget_rect_in(
            dialog.ui.resultsGroup,
            dialog.ui.mainSplitter,
        )
        self.assertLess(setup_rect.bottom(), results_rect.top())
        self.assertEqual(setup_rect.width(), results_rect.width())
        self.assertGreaterEqual(dialog.ui.fitScrollArea.width(), 400)
        self.assertLessEqual(dialog.ui.fitScrollArea.viewport().width(), 400)
        self.assertEqual(
            dialog.ui.equationDisplayLabel.geometry().left(),
            dialog.ui.customEquationWidget.geometry().left(),
        )
        self.assertEqual(
            dialog.ui.equationDisplayLabel.geometry().right(),
            dialog.ui.customEquationWidget.geometry().right(),
        )
        self.assertGreaterEqual(
            dialog.ui.equationDisplayLabel.height(),
            dialog.ui.equationDisplayLabel.heightForWidth(
                dialog.ui.equationDisplayLabel.width()
            ),
        )
        self.assert_fit_controls_do_not_overlap(dialog)

        scroll_area = dialog.ui.fitScrollArea
        vertical_bar = scroll_area.verticalScrollBar()
        self.assertGreater(vertical_bar.maximum(), 0)

        vertical_bar.setValue(vertical_bar.maximum())
        self.qapp.processEvents()
        model_rect = self.widget_rect_in(
            dialog.ui.modelGroup,
            scroll_area.viewport(),
        )
        self.assertLessEqual(
            model_rect.bottom(),
            scroll_area.viewport().rect().bottom(),
        )

        vertical_bar.setValue(0)
        fit_pane_minimum_width = dialog.ui.fitPane.minimumWidth()
        dialog.ui.fitPane.setMinimumWidth(
            scroll_area.viewport().width() + 120
        )
        self.qapp.processEvents()
        horizontal_bar = scroll_area.horizontalScrollBar()
        self.assertGreater(horizontal_bar.maximum(), 0)
        self.assertTrue(horizontal_bar.isVisible())

        horizontal_bar.setValue(horizontal_bar.maximum())
        self.qapp.processEvents()
        fit_button_rect = self.widget_rect_in(
            dialog.ui.fitButton,
            scroll_area.viewport(),
        )
        self.assertLessEqual(
            fit_button_rect.right(),
            scroll_area.viewport().rect().right(),
        )
        dialog.ui.fitPane.setMinimumWidth(fit_pane_minimum_width)

    def test_expanded_results_area_gives_extra_height_to_the_table(self):
        dialog = self.dialog()
        dialog.resize(dialog.minimumSize())
        dialog.show()
        self.select_model(dialog, "custom")
        self.qapp.processEvents()
        compact_table_height = dialog.ui.resultsTable.height()

        dialog.resize(dialog.minimumWidth(), 900)
        dialog.ui.mainSplitter.setSizes([280, 540])
        self.qapp.processEvents()

        self.assertEqual(
            dialog.ui.resultsTable.sizePolicy().verticalPolicy(),
            QSizePolicy.Expanding,
        )
        self.assertGreater(
            dialog.ui.resultsTable.height(),
            compact_table_height + 100,
        )
        for label in (
            dialog.ui.annotationModeLabel,
            dialog.ui.statusLabel,
            dialog.ui.selectedFitDetailsLabel,
        ):
            self.assertEqual(
                label.sizePolicy().verticalPolicy(),
                QSizePolicy.Maximum,
            )
            self.assertLessEqual(label.height(), label.sizeHint().height() + 2)
        self.assertEqual(
            dialog.ui.fitDetailsText.sizePolicy().verticalPolicy(),
            QSizePolicy.Maximum,
        )
        self.assertLessEqual(
            dialog.ui.fitDetailsText.height(),
            dialog.ui.fitDetailsText.maximumHeight(),
        )
        self.assert_fit_controls_do_not_overlap(dialog)

    def test_custom_model_identifies_parameters_and_shows_formula_editor(self):
        dialog = self.dialog()

        self.select_model(dialog, "custom")
        dialog.ui.customEquationEdit.setText("a * exp(-k * x) + c")
        self.assertTrue(dialog.regenerate_custom_parameters())

        self.assertFalse(dialog.ui.customEquationWidget.isHidden())
        self.assertEqual(
            [
                dialog.ui.parameterTable.item(row, 0).text()
                for row in range(dialog.ui.parameterTable.rowCount())
            ],
            ["a", "k", "c"],
        )
        self.assertIn("a, k, c", dialog.ui.parameterHintLabel.text())

        self.select_model(dialog, "linear")
        self.assertTrue(dialog.ui.customEquationWidget.isHidden())

    def test_custom_function_picker_has_only_supported_selectable_functions(self):
        dialog = self.dialog()
        self.select_model(dialog, "custom")
        combo = dialog.ui.functionCombo
        expected_names = (
            "exp",
            "ln",
            "log",
            "log10",
            "sqrt",
            "abs",
            "sin",
            "cos",
            "tan",
            "asin",
            "acos",
            "atan",
            "atan2",
            "sec",
            "csc",
            "cot",
            "sinh",
            "cosh",
            "tanh",
        )

        self.assertEqual(
            tuple(combo.itemData(index) for index in range(combo.count())),
            expected_names,
        )
        for index in range(combo.count()):
            item = combo.model().item(index)
            self.assertTrue(item.isEnabled())
            self.assertTrue(item.isSelectable())
            self.assertTrue(combo.itemText(index).startswith(expected_names[index]))

        help_text = dialog.ui.customEquationHelpLabel.text()
        for name in expected_names:
            self.assertIn(name, help_text)
        self.assertIn("radians", help_text)
        self.assertIn("radians", combo.toolTip())
        for name in (
            "sin",
            "cos",
            "tan",
            "asin",
            "acos",
            "atan",
            "atan2",
            "sec",
            "csc",
            "cot",
        ):
            index = expected_names.index(name)
            self.assertIn("radians", combo.itemData(index, Qt.ToolTipRole))
        self.assertIn(
            "between -1 and 1",
            combo.itemData(combo.findData("asin"), Qt.ToolTipRole),
        )
        self.assertIn(
            "between -1 and 1",
            combo.itemData(combo.findData("acos"), Qt.ToolTipRole),
        )
        self.assertIn(
            "undefined",
            combo.itemData(combo.findData("tan"), Qt.ToolTipRole),
        )
        atan2_tooltip = combo.itemData(combo.findData("atan2"), Qt.ToolTipRole)
        self.assertIn("vertical", atan2_tooltip)
        self.assertIn("horizontal", atan2_tooltip)
        log_index = combo.findData("log")
        self.assertEqual(combo.itemText(log_index), "log(u, base)")
        log_tooltip = combo.itemData(log_index, Qt.ToolTipRole)
        self.assertIn("custom base", log_tooltip)
        self.assertIn("not equal to 1", log_tooltip)
        self.assertIn("starts with base 2", log_tooltip)
        self.assertIn("or a parameter", log_tooltip)
        self.assertIn("ln(u) is the natural logarithm", help_text)
        self.assertIn("log(u, base) uses a custom base", help_text)
        self.assertIn("log10(u) uses base 10", help_text)
        self.assertIn("starts with base 2", help_text)
        self.assertIn("or a parameter name", help_text)

    def test_every_custom_function_picker_item_inserts_a_valid_template(self):
        dialog = self.dialog()
        self.select_model(dialog, "custom")
        editor = dialog.ui.customEquationEdit
        combo = dialog.ui.functionCombo

        for index in range(combo.count()):
            name = str(combo.itemData(index))
            with self.subTest(function=name):
                editor.setText("x")
                editor.selectAll()
                combo.setCurrentIndex(index)
                dialog.ui.insertFunctionButton.click()
                if name == "atan2":
                    expected = "atan2(x, x)"
                elif name == "log":
                    expected = "log(x, 2)"
                else:
                    expected = f"{name}(x)"
                self.assertEqual(editor.text(), expected)
                self.assertEqual(
                    editor.selectedText(),
                    "2" if name == "log" else "x",
                )
                self.assertTrue(dialog.regenerate_custom_parameters())

    def test_custom_log_template_guides_expression_and_base_entry(self):
        dialog = self.dialog()
        self.select_model(dialog, "custom")
        editor = dialog.ui.customEquationEdit
        combo = dialog.ui.functionCombo
        combo.setCurrentIndex(combo.findData("log"))

        editor.clear()
        dialog.ui.insertFunctionButton.click()
        self.assertEqual(editor.text(), "log(expression, 2)")
        self.assertEqual(editor.selectedText(), "expression")
        self.assertFalse(dialog.regenerate_custom_parameters())

        editor.setText("offset + x")
        editor.setSelection(len("offset + "), 1)
        dialog.ui.insertFunctionButton.click()
        self.assertEqual(editor.text(), "offset + log(x, 2)")
        self.assertEqual(editor.selectedText(), "2")
        self.assertTrue(dialog.regenerate_custom_parameters())

        editor.insert("chosen_base")
        self.assertEqual(editor.text(), "offset + log(x, chosen_base)")
        self.assertTrue(dialog.regenerate_custom_parameters())
        rows = {
            dialog.ui.parameterTable.item(row, 0).text(): dialog.ui.parameterTable.cellWidget(
                row, 1
            ).text()
            for row in range(dialog.ui.parameterTable.rowCount())
        }
        self.assertEqual(float(rows["chosen_base"]), 2.0)

        editor.setText("chosen_base * x")
        self.assertTrue(dialog.regenerate_custom_parameters())
        dialog.ui.parameterTable.cellWidget(0, 1).setText("1")
        editor.setText("log(x, chosen_base)")
        self.assertTrue(dialog.regenerate_custom_parameters())
        self.assertEqual(
            float(dialog.ui.parameterTable.cellWidget(0, 1).text()),
            2.0,
        )

    def test_custom_function_picker_wraps_selection_and_inserts_atan2_template(self):
        dialog = self.dialog()
        self.select_model(dialog, "custom")
        editor = dialog.ui.customEquationEdit
        combo = dialog.ui.functionCombo

        editor.setText("amplitude * x")
        editor.setSelection(len("amplitude * "), 1)
        combo.setCurrentIndex(combo.findData("sin"))
        dialog.ui.insertFunctionButton.click()
        self.assertEqual(editor.text(), "amplitude * sin(x)")
        self.assertEqual(editor.selectedText(), "x")

        editor.selectAll()
        combo.setCurrentIndex(combo.findData("tanh"))
        dialog.ui.insertFunctionButton.click()
        self.assertEqual(editor.text(), "tanh(amplitude * sin(x))")
        self.assertEqual(editor.selectedText(), "amplitude * sin(x)")

        editor.clear()
        combo.setCurrentIndex(combo.findData("atan2"))
        dialog.ui.insertFunctionButton.click()
        self.assertEqual(editor.text(), "atan2(expression, x)")
        self.assertEqual(editor.selectedText(), "expression")
        self.assertFalse(dialog.regenerate_custom_parameters())
        self.assertIn("Replace", dialog.ui.parameterHintLabel.text())

    def test_custom_template_buttons_insert_and_select_placeholders(self):
        dialog = self.dialog()
        self.select_model(dialog, "custom")
        editor = dialog.ui.customEquationEdit

        editor.clear()
        dialog.ui.insertSigmaButton.click()
        self.assertEqual(editor.text(), "Σ(k, 1, 5, expression)")
        self.assertEqual(editor.selectedText(), "expression")
        self.assertFalse(dialog.regenerate_custom_parameters())
        self.assertIn("Replace", dialog.ui.parameterHintLabel.text())

        editor.clear()
        dialog.ui.insertIntegralButton.click()
        self.assertEqual(editor.text(), "∫(t, 0, x, expression)")
        self.assertEqual(editor.selectedText(), "expression")
        self.assertFalse(dialog.regenerate_custom_parameters())

    def test_custom_template_buttons_wrap_selection_and_preserve_draft(self):
        dialog = self.dialog()
        self.select_model(dialog, "custom")
        editor = dialog.ui.customEquationEdit

        editor.setText("baseline + wave")
        editor.setSelection(len("baseline + "), len("wave"))
        dialog.ui.insertSigmaButton.click()
        self.assertEqual(
            editor.text(),
            "baseline + Σ(k, 1, 5, wave)",
        )
        self.assertEqual(editor.selectedText(), "wave")

        editor.selectAll()
        dialog.ui.insertIntegralButton.click()
        expected = "∫(t, 0, x, baseline + Σ(k, 1, 5, wave))"
        self.assertEqual(editor.text(), expected)
        self.assertEqual(
            editor.selectedText(),
            "baseline + Σ(k, 1, 5, wave)",
        )

        self.select_model(dialog, "linear")
        self.select_model(dialog, "custom")
        self.assertEqual(editor.text(), expected)

    def test_switching_models_preserves_the_custom_equation_and_parameter_draft(self):
        dialog = self.dialog()
        self.select_model(dialog, "custom")
        dialog.ui.customEquationEdit.setText("a * exp(-k * x) + c")
        self.assertTrue(dialog.regenerate_custom_parameters())
        dialog.ui.parameterTable.cellWidget(0, 1).setText("2.5")
        dialog._parameters_edited = True

        self.select_model(dialog, "linear")
        self.select_model(dialog, "custom")

        self.assertEqual(
            dialog.ui.customEquationEdit.text(),
            "a * exp(-k * x) + c",
        )
        self.assertEqual(
            dialog.ui.parameterTable.cellWidget(0, 1).text(),
            "2.5",
        )

    def test_parameter_editors_accept_scientific_notation(self):
        dialog = self.dialog()
        editor = dialog.ui.parameterTable.cellWidget(0, 1)

        state, _text, _position = editor.validator().validate("1e-6", 0)
        self.assertEqual(state, QValidator.Acceptable)
        editor.setText("1e-6")

        self.assertAlmostEqual(
            dialog._parameter_specs_from_table()[0].initial,
            1e-6,
        )

    def test_raw_coefficients_keep_round_trip_precision_in_editor_and_results(self):
        base = 1_000_000_000_000.0
        dialog = self.dialog(
            x=tuple(base + offset for offset in range(4)),
            y=(1.0, 3.0, 5.0, 7.0),
        )
        dialog.ui.seriesList.item(1).setCheckState(Qt.Unchecked)

        intercept_editor = dialog.ui.parameterTable.cellWidget(1, 1)
        expected_intercept = 1.0 - 2.0 * base
        self.assertEqual(float(intercept_editor.text()), expected_intercept)

        dialog.run_fit()
        self.wait_until(lambda: not dialog._busy)

        result = next(iter(dialog.results().values()))
        self.assertAlmostEqual(
            result.parameters["intercept"],
            expected_intercept,
            delta=0.001,
        )
        result_summary = dialog.ui.resultsTable.item(0, 5).text()
        details = dialog.ui.fitDetailsText.toPlainText()
        full_precision_intercept = f"{result.parameters['intercept']:.17g}"
        self.assertIn(full_precision_intercept, result_summary)
        self.assertIn(full_precision_intercept, details)

    def test_single_series_selection_loads_each_series_saved_model(self):
        fit_a = default_fit_spec("series-a", "linear")
        fit_b = default_fit_spec("series-b", "gaussian")
        dialog = self.dialog(existing_specs=[fit_a, fit_b])

        dialog.ui.seriesList.item(1).setCheckState(Qt.Unchecked)
        self.assertEqual(dialog.ui.modelCombo.currentData(), "linear")

        dialog.ui.seriesList.item(1).setCheckState(Qt.Checked)
        dialog.ui.seriesList.item(0).setCheckState(Qt.Unchecked)

        self.assertEqual(dialog.selected_series_ids(), ("series-b",))
        self.assertEqual(dialog.ui.modelCombo.currentData(), "gaussian")

    def test_series_switching_preserves_a_custom_equation_draft(self):
        fit_a = default_fit_spec("series-a", "custom")
        fit_a.expression = "a * x + b"
        fit_a.parameters = [
            FitParameterSpec("a", 1.0),
            FitParameterSpec("b", 0.0),
        ]
        fit_b = default_fit_spec("series-b", "gaussian")
        dialog = self.dialog(existing_specs=[fit_a, fit_b])

        dialog.ui.seriesList.item(1).setCheckState(Qt.Unchecked)
        dialog.ui.customEquationEdit.setText("amp * exp(-rate * x) + base")
        self.assertTrue(dialog.regenerate_custom_parameters())
        dialog.ui.parameterTable.cellWidget(0, 1).setText("2.5")
        dialog._parameters_edited = True

        dialog.ui.seriesList.item(1).setCheckState(Qt.Checked)
        dialog.ui.seriesList.item(0).setCheckState(Qt.Unchecked)
        self.assertEqual(dialog.ui.modelCombo.currentData(), "gaussian")

        dialog.ui.seriesList.item(0).setCheckState(Qt.Checked)
        dialog.ui.seriesList.item(1).setCheckState(Qt.Unchecked)

        self.assertEqual(dialog.ui.modelCombo.currentData(), "custom")
        self.assertEqual(
            dialog.ui.customEquationEdit.text(),
            "amp * exp(-rate * x) + base",
        )
        self.assertEqual(dialog.ui.parameterTable.cellWidget(0, 1).text(), "2.5")

    def test_cancel_and_remove_do_not_mutate_caller_owned_specs(self):
        spec = default_fit_spec("series-a", "linear")
        spec.parameters = [FitParameterSpec("slope", 2.0)]
        caller_specs = [spec]
        snapshot = deepcopy(caller_specs)
        dialog = self.dialog(existing_specs=caller_specs)

        dialog.remove_selected_fits()
        dialog.reject()

        self.assertEqual(caller_specs, snapshot)
        self.assertEqual(spec.parameters[0].initial, 2.0)
        self.assertEqual(dialog.removed_fit_ids(), {spec.id})

    def test_reject_cancels_all_in_flight_workers_and_clears_pending_jobs(self):
        dialog = self.dialog()
        first_worker = Mock()
        second_worker = Mock()
        dialog._workers = {3: first_worker, 4: second_worker}
        dialog._pending_specs = {3: {}, 4: {}}
        dialog._busy = True
        generation = dialog._fit_generation

        dialog.reject()

        first_worker.cancel.assert_called_once_with()
        second_worker.cancel.assert_called_once_with()
        self.assertEqual(dialog._workers, {})
        self.assertEqual(dialog._pending_specs, {})
        self.assertFalse(dialog._busy)
        self.assertEqual(dialog._fit_generation, generation + 1)

    def test_starting_preview_reports_callback_failure_instead_of_claiming_success(self):
        dialog = self.dialog(
            preview_callback=lambda _request: "Response A: coefficients are ill-conditioned"
        )
        dialog.ui.seriesList.item(1).setCheckState(Qt.Unchecked)

        dialog.preview_starting_curves()

        status = dialog.ui.statusLabel.text()
        self.assertIn("Preview unavailable", status)
        self.assertIn("Response A", status)
        self.assertNotIn("preview requested", status.lower())

    def test_background_fit_emits_and_keeps_successful_results(self):
        dialog = self.dialog()
        dialog.ui.selectAllButton.click()
        emitted = []
        dialog.fitResultsReady.connect(lambda results: emitted.append(results))

        dialog.run_fit()
        self.wait_until(lambda: not dialog._busy)

        self.assertEqual(len(emitted), 1)
        self.assertEqual(len(emitted[0]), 2)
        self.assertTrue(all(result.success for result in emitted[0].values()))
        self.assertEqual(len(dialog.specs()), 2)
        self.assertEqual(len(dialog.results()), 2)
        for result in dialog.results().values():
            self.assertAlmostEqual(result.parameters["slope"], 2.0, places=10)
            self.assertAlmostEqual(result.parameters["intercept"], 1.0, places=10)
            curve_x = result.curve_x
            curve_y = result.curve_y
            for x_value, y_value in zip(curve_x, curve_y):
                self.assertAlmostEqual(
                    y_value,
                    result.parameters["slope"] * x_value
                    + result.parameters["intercept"],
                    places=9,
                )
        self.assertEqual(dialog.ui.resultsTable.rowCount(), 2)
        self.assertIn("complete", dialog.ui.statusLabel.text().lower())
        details = dialog.ui.fitDetailsText.toPlainText()
        self.assertIn("SSE", details)
        self.assertIn("RMSE", details)
        self.assertIn("Adjusted R²", details)
        self.assertIn("Data used:", details)
        self.assertIn("standard error", details)
        self.assertIn("95% CI", details)
        self.assertIn("Warnings:", details)
        self.assertIn("Equation: y = slope * x + intercept", details)
        self.assertIn("slope =", details)
        self.assertIn("intercept =", details)
        self.assertNotIn("x0", details)
        self.assertNotIn("z =", details)

    def test_internal_origin_is_result_metadata_not_a_saved_user_setting(self):
        x_origin = 1_000_000_000_000.0
        dialog = self.dialog(
            x=tuple(x_origin + offset for offset in range(4)),
            y=(1.0, 3.0, 5.0, 7.0),
        )
        dialog.ui.seriesList.item(1).setCheckState(Qt.Unchecked)

        dialog.run_fit()
        self.wait_until(lambda: not dialog._busy)

        saved_spec = dialog.specs()[0]
        result = dialog.results()[saved_spec.id]
        self.assertIsNotNone(result.x_origin)
        self.assertIsNone(saved_spec.x_origin)

        self.select_model(dialog, "polynomial2")
        centered_candidate = next(iter(dialog._specs_for_selection().values()))
        self.assertIsNone(centered_candidate.x_origin)

        self.select_model(dialog, "exponential")
        non_polynomial_candidate = next(
            iter(dialog._specs_for_selection().values())
        )
        self.assertIsNone(non_polynomial_candidate.x_origin)

    def test_failed_fit_is_actionable_and_does_not_replace_saved_fit(self):
        saved = default_fit_spec("series-a", "linear")
        dialog = self.dialog(
            x=(0.0, 1.0, 2.0, 3.0),
            y=(1.0, 2.0, 3.0, 4.0),
            existing_specs=[saved],
        )
        # Fit only the first series so the saved fit is easy to compare.
        dialog.ui.seriesList.item(1).setCheckState(Qt.Unchecked)
        self.select_model(dialog, "logarithmic")
        emitted = []
        dialog.fitResultsReady.connect(lambda results: emitted.append(results))

        dialog.run_fit()
        self.wait_until(lambda: not dialog._busy)

        self.assertEqual(len(emitted), 1)
        failed = next(iter(emitted[0].values()))
        self.assertFalse(failed.success)
        self.assertIn("greater than zero", failed.message)
        self.assertEqual(dialog.specs()[0].id, saved.id)
        self.assertEqual(dialog.specs()[0].model_id, "linear")
        self.assertEqual(dialog.ui.resultsTable.rowCount(), 1)
        self.assertEqual(dialog.ui.resultsTable.item(0, 2).text(), "Needs attention")
        self.assertIn("starting values or bounds", dialog.ui.statusLabel.text())


if __name__ == "__main__":
    __import__("unittest").main()
