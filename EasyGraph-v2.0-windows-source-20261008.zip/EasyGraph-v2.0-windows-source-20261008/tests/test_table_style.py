from PySide6.QtCore import Qt
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QStyleOptionViewItem

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.table_style import apply_table_row_styles, header_row_height, row_header_min_width


class TableStyleTests(EasyGraphQtTestCase):
    def test_data_table_names_both_index_headers_for_theme_styling(self):
        table = DataTable()
        self.addCleanup(table.deleteLater)

        self.assertEqual(table.horizontalHeader().objectName(), "dataTableHorizontalHeader")
        self.assertEqual(table.verticalHeader().objectName(), "dataTableVerticalHeader")

    def test_header_row_height_uses_max_header_line_count(self):
        table = DataTable(1, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells([["A", "B\nC\nD"]], column_count=2)

        expected = table.fontMetrics().lineSpacing() * 3 + 14

        self.assertEqual(header_row_height(table), expected)

    def test_header_row_height_defaults_to_one_line_for_empty_headers(self):
        table = DataTable(1, 2)
        self.addCleanup(table.deleteLater)

        expected = table.fontMetrics().lineSpacing() + 14

        self.assertEqual(header_row_height(table), expected)

    def test_row_header_min_width_expands_when_overlay_rows_exist(self):
        self.assertEqual(row_header_min_width(0), 34)
        self.assertEqual(row_header_min_width(2), 86)

    def test_apply_table_row_styles_formats_header_overlay_and_sample_rows(self):
        table = DataTable(3, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells(
            [["A", ""], ["overlay", ""], ["sample", ""]],
            column_count=2,
        )
        table.blockSignals(True)

        apply_table_row_styles(table, sample_start_row=2, blend_colors=lambda base, highlight, ratio: highlight)

        self.assertTrue(table.signalsBlocked())
        model = table.table_model
        self.assertEqual(model.cell_text(0, 1), "Group 2")
        self.assertEqual(model.cell_text(1, 1), "")
        self.assertTrue(model.data(model.index(0, 0), Qt.FontRole).bold())
        self.assertEqual(model.data(model.index(0, 0), Qt.TextAlignmentRole), Qt.AlignCenter)
        self.assertTrue(model.data(model.index(1, 0), Qt.FontRole).bold())
        self.assertEqual(model.data(model.index(1, 0), Qt.TextAlignmentRole), Qt.AlignLeft | Qt.AlignVCenter)
        self.assertFalse(model.data(model.index(2, 0), Qt.FontRole).bold())
        self.assertIsNone(model.data(model.index(2, 0), Qt.BackgroundRole))

    def test_apply_table_row_styles_keeps_dark_theme_text_readable_before_show(self):
        table = DataTable(3, 1)
        self.addCleanup(table.deleteLater)
        table.setStyleSheet(
            "QTableView { color: #e4e7eb; background-color: #202124; "
            "selection-background-color: #3d6d99; }"
        )
        table.table_model.replace_cells(
            [["Group"], ["Overlay"], ["Sample"]],
            column_count=1,
        )

        apply_table_row_styles(table, sample_start_row=2, blend_colors=lambda base, highlight, ratio: base)

        model = table.table_model
        overlay_foreground = model.data(model.index(1, 0), Qt.ForegroundRole)
        self.assertEqual(overlay_foreground.color().name(), "#e4e7eb")
        self.assertIsNone(model.data(model.index(2, 0), Qt.ForegroundRole))

        option = QStyleOptionViewItem()
        option.initFrom(table)
        table.itemDelegate().initStyleOption(option, model.index(2, 0))
        self.assertEqual(option.palette.color(QPalette.ColorRole.Text).name(), "#e4e7eb")

    def test_apply_table_row_styles_uses_light_palette_for_group_header_row(self):
        table = DataTable(2, 1)
        self.addCleanup(table.deleteLater)
        table.setStyleSheet(
            "QTableView { color: #202124; background-color: #ffffff; "
            "selection-background-color: #3d6d99; }"
        )
        table.table_model.replace_cells([["Group"], ["Sample"]], column_count=1)

        apply_table_row_styles(table, sample_start_row=1, blend_colors=lambda base, highlight, ratio: base)

        model = table.table_model
        header_background = model.data(model.index(0, 0), Qt.BackgroundRole)
        header_foreground = model.data(model.index(0, 0), Qt.ForegroundRole)
        self.assertEqual(header_background.color().name(), "#ffffff")
        self.assertEqual(header_foreground.color().name(), "#202124")
