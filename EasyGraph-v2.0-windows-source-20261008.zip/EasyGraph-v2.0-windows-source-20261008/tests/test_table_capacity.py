from __future__ import annotations

import pathlib
import tempfile
from unittest import mock

import pandas as pd
from PySide6.QtCore import QItemSelectionModel, Qt
from PySide6.QtWidgets import QApplication

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph import project_io
from easygraph.spreadsheet_io import SpreadsheetSheet
from easygraph.workbook import SHEET_MODE_XY


class TableCapacityTests(EasyGraphQtTestCase):
    def make_xy_window(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        self.qapp.processEvents()
        return window

    def settle_capacity(self, window) -> None:
        self.qapp.processEvents()
        if window._render_timer.isActive():
            window._render_timer.stop()
        window._render_pending = False

    def assert_last_sample_row_is_blank(self, controller) -> None:
        model = controller.table.table_model
        self.assertGreater(model.rowCount(), controller.sample_start_row())
        self.assertTrue(
            all(
                model.cell_text(model.rowCount() - 1, column) == ""
                for column in range(model.columnCount())
            )
        )

    def assert_one_debounced_render(self, window, operation) -> None:
        self.settle_capacity(window)
        with mock.patch.object(window, "render") as render:
            operation()
            # Capacity normalization is queued at zero delay; process it before
            # explicitly flushing the longer render debounce timer.
            self.qapp.processEvents()
            window.flush_pending_render()
            self.qapp.processEvents()
        render.assert_called_once()

    def test_groups_keep_comfortable_capacity_and_grow_from_the_last_cells(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame({"Dose": ["1", "", ""]}),
        )
        self.settle_capacity(window)
        controller = window._table_controller
        model = window.table.table_model
        sample_start = controller.sample_start_row()

        self.assertEqual(model.rowCount(), sample_start + 12)
        self.assertEqual(model.columnCount(), 3)
        self.assertEqual(model.cell_text(0, 0), "Dose")
        self.assertEqual(
            [model.cell_text(0, column) for column in range(1, 3)],
            ["Group 2", "Group 3"],
        )
        self.assert_last_sample_row_is_blank(controller)
        self.assertTrue(
            all(
                model.cell_text(row, column) == ""
                for row in range(sample_start, model.rowCount())
                for column in (1, 2)
            )
        )
        semantic = window._user_group_dataframe()
        self.assertEqual(
            list(semantic.columns),
            [model.cell_text(0, column) for column in range(model.columnCount() - 1)],
        )
        self.assertEqual(len(semantic), 1)

        old_last_row = model.rowCount() - 1
        old_last_column = model.columnCount() - 1
        model.set_cell_text(old_last_row, old_last_column, "tail")
        self.qapp.processEvents()

        self.assertEqual(model.rowCount(), old_last_row + 2)
        self.assertEqual(model.columnCount(), old_last_column + 2)
        self.assertEqual(model.cell_text(old_last_row, old_last_column), "tail")
        self.assertEqual(model.cell_text(0, model.columnCount() - 1), "Group 4")
        self.assert_last_sample_row_is_blank(controller)

    def test_groups_clear_is_append_only_preserves_named_group_and_undoes_remote_value(self):
        window = self.make_window()
        values = ["1", *("" for _ in range(12)), "tail"]
        window.set_table_dataframe(pd.DataFrame({"Dose": values}))
        self.settle_capacity(window)
        table = window.table
        model = table.table_model
        controller = window._table_controller
        sample_start = controller.sample_start_row()
        spare_column = model.columnCount() - 1

        model.set_cell_text(0, spare_column, "Kept Empty")
        self.qapp.processEvents()
        self.assertEqual(model.columnCount(), 4)
        self.assertEqual(model.cell_text(0, spare_column), "Kept Empty")
        self.assertEqual(model.cell_text(0, model.columnCount() - 1), "Group 4")

        last_used_row = sample_start + len(values) - 1
        self.select_table_range(table, last_used_row, 0, last_used_row, 0)
        window.clear_table_selection(table)
        self.qapp.processEvents()

        expected_rows = sample_start + len(values) + 1
        self.assertEqual(model.rowCount(), expected_rows)
        self.assertEqual(model.columnCount(), 4)
        self.assertEqual(
            [model.cell_text(0, column) for column in range(model.columnCount())],
            ["Dose", "Group 2", "Kept Empty", "Group 4"],
        )
        self.assert_last_sample_row_is_blank(controller)
        self.assertEqual(model.cell_text(last_used_row, 0), "")

        controller.undo()
        self.qapp.processEvents()
        self.assertEqual(model.rowCount(), expected_rows)
        self.assertEqual(model.cell_text(last_used_row, 0), "tail")
        self.assertEqual(model.cell_text(0, spare_column), "Kept Empty")

    def test_groups_custom_group_4_gets_a_distinct_auto_spare_name(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": ["1"],
                    "B": [""],
                    "C": [""],
                    "Group 4": [""],
                }
            )
        )
        self.settle_capacity(window)
        model = window.table.table_model
        names = [
            model.cell_text(0, column)
            for column in range(model.columnCount())
        ]

        self.assertEqual(names[:4], ["A", "B", "C", "Group 4"])
        self.assertEqual(names[-1], "Group 5")
        self.assertEqual(len(names), len(set(names)))
        semantic = window._user_group_dataframe()
        self.assertEqual(
            list(semantic.columns),
            ["A", "B", "C", "Group 4"],
        )
        self.assertEqual(len(semantic), 1)

    def test_groups_custom_and_automatic_spares_are_stable_across_sheet_reloads(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": ["1"],
                    "B": [""],
                    "C": [""],
                    "Group 4": [""],
                }
            )
        )
        self.settle_capacity(window)
        expected_names = ["A", "B", "C", "Group 4", "Group 5"]
        self.assertEqual(
            [
                window.table.table_model.cell_text(0, column)
                for column in range(window.table.table_model.columnCount())
            ],
            expected_names,
        )

        window.add_sheet()
        for _reload in range(3):
            window.sheet_tab_bar.setCurrentIndex(0)
            self.qapp.processEvents()
            model = window.table.table_model
            self.assertEqual(
                [model.cell_text(0, column) for column in range(model.columnCount())],
                expected_names,
            )
            window.sheet_tab_bar.setCurrentIndex(1)
            self.qapp.processEvents()

    def test_groups_user_name_colliding_with_spare_renames_only_the_tracked_spare(self):
        window = self.make_window()
        model = window.table.table_model
        sheet = window.workbook.active_sheet
        original_ids = list(sheet.column_ids)
        original_spare_name = model.cell_text(0, model.columnCount() - 1)

        model.set_cell_text(0, 0, original_spare_name)
        self.assertTrue(window._table_capacity_update_pending)
        window._store_active_sheet()
        self.assertFalse(window._table_capacity_update_pending)

        expected_names = [
            model.cell_text(0, column)
            for column in range(model.columnCount())
        ]
        expected_manual_order = list(window.settings.manual_group_order)
        self.assertEqual(model.columnCount(), len(original_ids))
        self.assertEqual(expected_names[0], original_spare_name)
        self.assertNotEqual(expected_names[-1], original_spare_name)
        self.assertEqual(len(expected_names), len(set(expected_names)))
        self.assertEqual(window.table_group_names(), expected_names[:-1])
        self.assertIn(original_ids[0], expected_manual_order)
        self.assertNotIn(original_ids[-1], expected_manual_order)
        self.assertEqual(sheet.column_ids, original_ids)
        self.assertTrue(window._group_last_column_is_auto_spare())

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "spare-name-collision.eg"
            project_io.write_project(path, window.workbook)
            loaded = self.make_window(initial_render=True)
            with mock.patch.object(loaded, "render"), mock.patch.object(
                loaded.canvas,
                "zoom_to_fit",
            ):
                loaded._load_project_path(path)

        loaded_model = loaded.table.table_model
        loaded_sheet = loaded.workbook.active_sheet
        self.assertEqual(
            [
                loaded_model.cell_text(0, column)
                for column in range(loaded_model.columnCount())
            ],
            expected_names,
        )
        self.assertEqual(loaded_sheet.column_ids, original_ids)
        self.assertEqual(
            loaded.settings.manual_group_order,
            expected_manual_order,
        )
        self.assertEqual(loaded.table_group_names(), expected_names[:-1])
        self.assertEqual(
            list(loaded._user_group_dataframe().columns),
            expected_names[:-1],
        )
        self.assertEqual(
            set(loaded._group_auto_spare_names[loaded_sheet.id]),
            {original_ids[-1]},
        )
        self.assertTrue(loaded._group_last_column_is_auto_spare())

    def test_groups_immediate_store_normalizes_a_pending_spare_name_collision(self):
        window = self.make_window()
        model = window.table.table_model
        sheet = window.workbook.active_sheet
        original_count = model.columnCount()
        original_user_count = len(window.table_group_names())
        original_ids = list(sheet.column_ids)
        spare_name = model.cell_text(0, original_count - 1)

        model.set_cell_text(0, 0, spare_name)
        self.assertTrue(window._table_capacity_update_pending)
        # Intentionally do not process the queued zero-delay capacity callback:
        # storing must synchronously normalize physical capacity first.
        window._store_active_sheet()

        stored_names = [
            model.cell_text(0, column)
            for column in range(model.columnCount())
        ]
        stored_manual_order = list(window.settings.manual_group_order)
        self.assertFalse(window._table_capacity_update_pending)
        self.assertEqual(model.columnCount(), original_count)
        self.assertEqual(len(window.table_group_names()), original_user_count)
        self.assertEqual(len(stored_names), len(set(stored_names)))
        self.assertEqual(stored_names[0], spare_name)
        self.assertNotEqual(stored_names[-1], spare_name)
        self.assertEqual(sheet.column_ids, original_ids)
        self.assertNotIn(stored_names[-1], stored_manual_order)
        self.assertTrue(window._group_last_column_is_auto_spare())

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "immediate-spare-collision.eg"
            project_io.write_project(path, window.workbook)
            loaded = self.make_window(initial_render=True)
            with mock.patch.object(loaded, "render"), mock.patch.object(
                loaded.canvas,
                "zoom_to_fit",
            ):
                loaded._load_project_path(path)

        loaded_model = loaded.table.table_model
        self.assertEqual(
            [
                loaded_model.cell_text(0, column)
                for column in range(loaded_model.columnCount())
            ],
            stored_names,
        )
        self.assertEqual(loaded_model.columnCount(), original_count)
        self.assertEqual(len(loaded.table_group_names()), original_user_count)
        self.assertEqual(loaded.workbook.active_sheet.column_ids, original_ids)
        self.assertEqual(
            loaded.settings.manual_group_order,
            stored_manual_order,
        )
        self.assertEqual(
            list(loaded._user_group_dataframe().columns),
            stored_names[:-1],
        )
        self.assertTrue(loaded._group_last_column_is_auto_spare())

    def test_groups_immediate_store_does_not_double_render_queued_capacity(self):
        window = self.make_window()
        model = window.table.table_model
        spare_name = model.cell_text(0, model.columnCount() - 1)
        self.settle_capacity(window)

        with mock.patch.object(window, "render") as render:
            model.set_cell_text(0, 0, spare_name)
            self.assertTrue(window._table_capacity_update_pending)
            window._store_active_sheet()
            self.qapp.processEvents()
            window.flush_pending_render()
            self.qapp.processEvents()

        render.assert_called_once()

    def test_groups_replacing_four_columns_with_three_keeps_project_state_aligned(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": ["1"],
                    "B": ["2"],
                    "C": ["3"],
                    "D": ["4"],
                }
            )
        )
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": ["1"],
                    "B": ["2"],
                    "Group 3": [""],
                }
            )
        )
        self.settle_capacity(window)
        model = window.table.table_model
        self.assertEqual(
            [model.cell_text(0, column) for column in range(model.columnCount())],
            ["A", "B", "Group 3", "Group 4"],
        )
        semantic = window._user_group_dataframe()
        self.assertEqual(list(semantic.columns), ["A", "B", "Group 3"])
        window._store_active_sheet(commit=False)
        sheet = window.workbook.active_sheet
        physical_columns = model.columnCount()

        self.assertEqual(physical_columns, len(semantic.columns) + 1)
        self.assertEqual(len(sheet.column_ids), physical_columns)
        self.assertEqual(len(sheet.dataframe.columns), physical_columns)
        self.assertEqual(len(window.table_dataframe().columns), physical_columns)

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "capacity.eg"
            project_io.write_project(path, window.workbook)
            loaded = project_io.read_workbook_project(path)

        loaded_sheet = loaded.active_sheet
        self.assertEqual(len(loaded_sheet.column_ids), physical_columns)
        self.assertEqual(len(loaded_sheet.dataframe.columns), physical_columns)

    def test_groups_delete_auto_spare_undo_redo_does_not_append_extra_columns(self):
        window = self.make_window()
        table = window.table
        model = table.table_model
        sheet = window.workbook.active_sheet
        original_names = [
            model.cell_text(0, column)
            for column in range(model.columnCount())
        ]
        original_column_ids = list(sheet.column_ids)
        original_manual_order = list(window.settings.manual_group_order)
        original_count = model.columnCount()
        self.assertNotIn(original_names[-1], original_manual_order)
        table.selectColumn(original_count - 1)

        window.delete_table_structure("entire_column", table)
        self.qapp.processEvents()

        deleted_names = [
            model.cell_text(0, column)
            for column in range(model.columnCount())
        ]
        deleted_column_ids = list(sheet.column_ids)
        self.assertEqual(model.columnCount(), original_count)
        self.assertEqual(deleted_names, original_names)
        self.assertNotEqual(deleted_column_ids, original_column_ids)
        self.assertEqual(window.settings.manual_group_order, original_manual_order)
        self.assertNotIn(deleted_names[-1], window.settings.manual_group_order)

        window.undo_table_change()
        self.qapp.processEvents()
        self.assertEqual(model.columnCount(), original_count)
        self.assertEqual(
            [model.cell_text(0, column) for column in range(model.columnCount())],
            original_names,
        )
        self.assertEqual(sheet.column_ids, original_column_ids)
        self.assertEqual(window.settings.manual_group_order, original_manual_order)
        self.assertNotIn(original_names[-1], window.settings.manual_group_order)

        window.redo_table_change()
        self.qapp.processEvents()
        self.assertEqual(model.columnCount(), original_count)
        self.assertEqual(
            [model.cell_text(0, column) for column in range(model.columnCount())],
            deleted_names,
        )
        self.assertEqual(sheet.column_ids, deleted_column_ids)
        self.assertEqual(window.settings.manual_group_order, original_manual_order)
        self.assertNotIn(deleted_names[-1], window.settings.manual_group_order)

    def test_groups_workbook_import_keeps_canonical_blank_user_group_and_adds_spare(self):
        window = self.make_window()
        imported = SpreadsheetSheet(
            "Imported",
            pd.DataFrame(
                {
                    "A": ["1"],
                    "B": [""],
                    "Group 3": [""],
                }
            ),
        )

        with mock.patch.object(window, "render"):
            window._apply_imported_workbook([imported])
        self.qapp.processEvents()

        model = window.table.table_model
        self.assertEqual(
            [model.cell_text(0, column) for column in range(model.columnCount())],
            ["A", "B", "Group 3", "Group 4"],
        )
        self.assertEqual(window.table_group_names(), ["A", "B", "Group 3"])
        self.assertEqual(
            window.settings.manual_group_order,
            window.workbook.active_sheet.column_ids[:3],
        )
        self.assertNotIn("Group 4", window.settings.manual_group_order)

    def test_groups_project_reload_rebuilds_one_spare_after_custom_empty_group(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": ["1"],
                    "B": [""],
                    "C": [""],
                    "Group 5": [""],
                }
            )
        )
        model = window.table.table_model
        self.assertEqual(
            [model.cell_text(0, column) for column in range(model.columnCount())],
            ["A", "B", "C", "Group 5", "Group 6"],
        )
        model.set_cell_text(0, 3, "D")
        self.qapp.processEvents()
        expected_names = ["A", "B", "C", "D", "Group 6"]
        self.assertEqual(
            [model.cell_text(0, column) for column in range(model.columnCount())],
            expected_names,
        )
        self.assertEqual(
            list(window._user_group_dataframe().columns),
            ["A", "B", "C", "D"],
        )
        window._store_active_sheet(commit=False)

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "spare-reload.eg"
            project_io.write_project(path, window.workbook)
            loaded = self.make_window(initial_render=True)
            with mock.patch.object(loaded, "render"), mock.patch.object(
                loaded.canvas,
                "zoom_to_fit",
            ):
                loaded._load_project_path(path)

        loaded_model = loaded.table.table_model
        self.assertEqual(
            [
                loaded_model.cell_text(0, column)
                for column in range(loaded_model.columnCount())
            ],
            expected_names,
        )
        self.assertEqual(loaded.table_group_names(), ["A", "B", "C", "D"])
        self.assertEqual(
            list(loaded._user_group_dataframe().columns),
            ["A", "B", "C", "D"],
        )
        self.assertIn(loaded.workbook.active_sheet.column_ids[3], loaded.settings.manual_group_order)
        self.assertNotIn("Group 6", loaded.settings.manual_group_order)

    def test_groups_csv_and_all_sheet_excel_exports_use_semantic_frames(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": ["1", "", ""],
                    "Empty A": ["", "", ""],
                }
            )
        )
        first_sheet = window.workbook.active_sheet

        with tempfile.TemporaryDirectory() as tmp:
            csv_path = pathlib.Path(tmp) / "groups.csv"
            with mock.patch(
                "easygraph.ui.main_window.QFileDialog.getSaveFileName",
                return_value=(str(csv_path), "Current Sheet CSV (*.csv)"),
            ):
                window.export_excel()
            exported_csv = pd.read_csv(csv_path, keep_default_na=False)

            self.assertEqual(list(exported_csv.columns), ["A", "Empty A"])
            self.assertEqual(exported_csv.to_dict("records"), [{"A": 1, "Empty A": ""}])

            window.add_sheet()
            window.set_table_dataframe(
                pd.DataFrame(
                    {
                        "B": ["2", "", ""],
                        "Empty B": ["", "", ""],
                    }
                )
            )
            second_sheet = window.workbook.active_sheet
            captured: list[SpreadsheetSheet] = []

            def capture_book(_path, sheets):
                captured.extend(sheets)
                return pathlib.Path(_path)

            excel_path = pathlib.Path(tmp) / "groups.xlsx"
            with (
                mock.patch(
                    "easygraph.ui.main_window.QFileDialog.getSaveFileName",
                    return_value=(str(excel_path), "Excel Workbook — All Sheets (*.xlsx)"),
                ),
                mock.patch(
                    "easygraph.ui.main_window.write_spreadsheet_book",
                    side_effect=capture_book,
                ),
            ):
                window.export_excel()

        self.assertEqual(
            [sheet.name for sheet in captured],
            [first_sheet.name, second_sheet.name],
        )
        self.assertEqual(list(captured[0].dataframe.columns), ["A", "Empty A"])
        self.assertEqual(list(captured[1].dataframe.columns), ["B", "Empty B"])
        self.assertEqual(len(captured[0].dataframe), 1)
        self.assertEqual(len(captured[1].dataframe), 1)

    def test_groups_project_save_keeps_physical_ids_and_history_usable_after_switch_and_reload(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": ["1"],
                    "Empty User": [""],
                }
            )
        )
        self.settle_capacity(window)
        model = window.table.table_model
        sample_start = window._table_controller.sample_start_row()
        expected_names = [
            model.cell_text(0, column)
            for column in range(model.columnCount())
        ]
        expected_column_ids = list(window.workbook.active_sheet.column_ids)
        self.assertEqual(expected_names, ["A", "Empty User", "Group 3"])
        self.assertEqual(
            list(window._user_group_dataframe().columns),
            ["A", "Empty User"],
        )

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "physical-capacity.eg"
            window.current_project = path
            self.assertTrue(window.save_project())

            model.set_cell_text(sample_start, 0, "2")
            self.qapp.processEvents()
            window.add_sheet()
            window.sheet_tab_bar.setCurrentIndex(0)
            self.qapp.processEvents()

            self.assertEqual(
                list(window.workbook.active_sheet.column_ids),
                expected_column_ids,
            )
            self.assertEqual(
                [
                    window.table.table_model.cell_text(0, column)
                    for column in range(window.table.table_model.columnCount())
                ],
                expected_names,
            )
            self.assertEqual(window.table.table_model.cell_text(sample_start, 0), "2")
            window.undo_table_change()
            self.qapp.processEvents()
            self.assertEqual(window.table.table_model.cell_text(sample_start, 0), "1")

            loaded = self.make_window(initial_render=True)
            with mock.patch.object(loaded, "render"), mock.patch.object(
                loaded.canvas,
                "zoom_to_fit",
            ):
                loaded._load_project_path(path)

        loaded_model = loaded.table.table_model
        loaded_start = loaded._table_controller.sample_start_row()
        self.assertEqual(
            [
                loaded_model.cell_text(0, column)
                for column in range(loaded_model.columnCount())
            ],
            expected_names,
        )
        self.assertEqual(
            list(loaded.workbook.active_sheet.column_ids),
            expected_column_ids,
        )
        self.assertEqual(
            len(loaded.workbook.active_sheet.dataframe.columns),
            loaded_model.columnCount(),
        )
        self.assertEqual(
            list(loaded._user_group_dataframe().columns),
            ["A", "Empty User"],
        )
        before = loaded_model.cell_text(loaded_start, 0)
        loaded_model.set_cell_text(loaded_start, 0, "9")
        self.qapp.processEvents()
        loaded.undo_table_change()
        self.qapp.processEvents()
        self.assertEqual(loaded_model.cell_text(loaded_start, 0), before)

    def test_xy_shared_keeps_default_capacity_and_grows_from_the_last_cell(self):
        window = self.make_xy_window()
        table = window.table
        model = table.table_model
        controller = window._table_controller

        self.assertEqual(model.rowCount(), controller.sample_start_row() + 10)
        self.assertEqual(model.columnCount(), 3)
        self.assertEqual(model.cell_text(0, 0), "X")
        self.assertEqual(
            [model.cell_text(0, column) for column in range(1, 3)],
            ["1Y", "2Y"],
        )
        self.assert_last_sample_row_is_blank(controller)

        old_last_row = model.rowCount() - 1
        old_last_column = model.columnCount() - 1
        model.set_cell_text(old_last_row, old_last_column, "10")
        self.qapp.processEvents()

        self.assertEqual(model.rowCount(), old_last_row + 2)
        self.assertEqual(model.columnCount(), old_last_column + 2)
        self.assertEqual(model.cell_text(old_last_row, old_last_column), "10")
        self.assertEqual(model.cell_text(0, model.columnCount() - 1), "3Y")
        self.assert_last_sample_row_is_blank(controller)

    def test_xy_paired_keeps_default_capacity_and_grows_from_the_last_cell(self):
        window = self.make_xy_window()
        table = window.xy_independent_table
        model = table.table_model
        controller = window._xy_paired_controller

        self.assertEqual(model.rowCount(), controller.sample_start_row() + 10)
        self.assertEqual(model.columnCount(), 4)
        self.assertEqual(
            [model.cell_text(0, column) for column in range(4)],
            ["1X", "1Y", "2X", "2Y"],
        )
        self.assert_last_sample_row_is_blank(controller)

        old_last_row = model.rowCount() - 1
        old_last_column = model.columnCount() - 1
        model.set_cell_text(old_last_row, old_last_column, "10")
        self.qapp.processEvents()

        self.assertEqual(model.rowCount(), old_last_row + 2)
        self.assertEqual(model.columnCount(), old_last_column + 3)
        self.assertEqual(model.cell_text(old_last_row, old_last_column), "10")
        self.assertEqual(
            [model.cell_text(0, column) for column in range(4, 6)],
            ["3X", "3Y"],
        )
        self.assert_last_sample_row_is_blank(controller)

    def test_xy_row_only_growth_refreshes_sequential_row_headers(self):
        surfaces = (
            ("shared", lambda window: window.table),
            ("paired", lambda window: window.xy_independent_table),
        )
        for name, table_for_window in surfaces:
            with self.subTest(surface=name):
                window = self.make_xy_window()
                table = table_for_window(window)
                model = table.table_model
                original_columns = model.columnCount()
                last_row = model.rowCount() - 1
                model.set_cell_text(last_row, 0, "tail-x")
                self.qapp.processEvents()

                self.assertEqual(model.rowCount(), last_row + 2)
                self.assertEqual(model.columnCount(), original_columns)
                sample_start = window._controller_for_table(table).sample_start_row()
                self.assertEqual(
                    [
                        model.headerData(row, Qt.Orientation.Vertical, Qt.ItemDataRole.DisplayRole)
                        for row in range(sample_start, model.rowCount())
                    ],
                    [
                        str(number)
                        for number in range(1, model.rowCount() - sample_start + 1)
                    ],
                )

    def test_clear_and_shift_up_keep_append_only_xy_capacity(self):
        window = self.make_xy_window()
        shared = window.table
        shared_model = shared.table_model
        shared_start = window._table_controller.sample_start_row()
        shared_model.set_cell_text(shared_start, 1, "10")
        self.qapp.processEvents()
        self.assertEqual(shared_model.columnCount(), 3)
        last_shared_row = shared_model.rowCount() - 1
        last_shared_column = shared_model.columnCount() - 1
        shared_model.set_cell_text(last_shared_row, last_shared_column, "10")
        self.qapp.processEvents()
        self.assertEqual(shared_model.columnCount(), 4)
        self.select_table_range(
            shared,
            last_shared_row,
            last_shared_column,
            last_shared_row,
            last_shared_column,
        )
        window.clear_table_selection(shared)
        self.qapp.processEvents()
        self.assertEqual(shared_model.rowCount(), shared_start + 11)
        self.assertEqual(shared_model.columnCount(), 4)

        window = self.make_xy_window()
        paired = window.xy_independent_table
        paired_model = paired.table_model
        paired_start = window._xy_paired_controller.sample_start_row()
        last_paired_row = paired_model.rowCount() - 1
        last_paired_column = paired_model.columnCount() - 1
        paired_model.set_cell_text(last_paired_row, last_paired_column, "20")
        self.qapp.processEvents()
        self.assertEqual(paired_model.columnCount(), 6)
        self.select_table_range(
            paired,
            last_paired_row,
            last_paired_column,
            last_paired_row,
            last_paired_column,
        )
        window.delete_table_structure("cells_up", paired)
        self.qapp.processEvents()
        self.assertEqual(paired_model.rowCount(), paired_start + 11)
        self.assertEqual(paired_model.columnCount(), 6)

    def test_xy_remote_clear_settles_capacity_and_undo_restores_shared_and_pair_values(self):
        surfaces = (
            ("shared", lambda window: (window.table, window._table_controller)),
            (
                "paired",
                lambda window: (
                    window.xy_independent_table,
                    window._xy_paired_controller,
                ),
            ),
        )
        for name, surface in surfaces:
            with self.subTest(surface=name):
                window = self.make_xy_window()
                table, controller = surface(window)
                model = table.table_model
                remote_row = model.rowCount() - 1
                remote_column = model.columnCount() - 1
                model.set_cell_text(remote_row, remote_column, "tail")
                self.qapp.processEvents()
                settled_rows = model.rowCount()

                self.select_table_range(
                    table,
                    remote_row,
                    remote_column,
                    remote_row,
                    remote_column,
                )
                window.clear_table_selection(table)
                self.qapp.processEvents()
                self.assertEqual(model.rowCount(), settled_rows)
                self.assertEqual(model.cell_text(remote_row, remote_column), "")

                controller.undo()
                self.qapp.processEvents()
                self.assertEqual(model.rowCount(), settled_rows)
                self.assertEqual(model.cell_text(remote_row, remote_column), "tail")
                self.assert_last_sample_row_is_blank(controller)

    def test_xy_noop_clear_preserves_multiselection_current_cell_and_scroll(self):
        surfaces = (
            ("shared", lambda window: window.table),
            ("paired", lambda window: window.xy_independent_table),
        )
        for name, table_for_window in surfaces:
            with self.subTest(surface=name):
                window = self.make_xy_window()
                table = table_for_window(window)
                window.show()
                table.setFixedSize(180, 105)
                self.qapp.processEvents()
                model = table.table_model
                self.select_table_range(table, 2, 0, 4, 1)
                table.selectionModel().setCurrentIndex(
                    model.index(3, 1),
                    QItemSelectionModel.SelectionFlag.NoUpdate,
                )
                horizontal = table.horizontalScrollBar()
                vertical = table.verticalScrollBar()
                self.assertGreater(
                    horizontal.maximum() + vertical.maximum(),
                    0,
                )
                horizontal.setValue(min(2, horizontal.maximum()))
                vertical.setValue(min(2, vertical.maximum()))
                expected_selection = {
                    (index.row(), index.column())
                    for index in table.selectionModel().selectedIndexes()
                }
                expected_current = (
                    table.currentIndex().row(),
                    table.currentIndex().column(),
                )
                expected_scroll = (horizontal.value(), vertical.value())

                window.clear_table_selection(table)
                self.qapp.processEvents()

                self.assertEqual(
                    {
                        (index.row(), index.column())
                        for index in table.selectionModel().selectedIndexes()
                    },
                    expected_selection,
                )
                self.assertEqual(
                    (table.currentIndex().row(), table.currentIndex().column()),
                    expected_current,
                )
                self.assertEqual(
                    (horizontal.value(), vertical.value()),
                    expected_scroll,
                )

    def test_xy_column_growth_preserves_header_selection_current_cell_and_scroll(self):
        surfaces = (
            ("shared", lambda window: window.table, 1),
            ("paired", lambda window: window.xy_independent_table, 2),
        )
        for name, table_for_window, added_columns in surfaces:
            with self.subTest(surface=name):
                window = self.make_xy_window()
                table = table_for_window(window)
                window.show()
                table.setFixedSize(180, 105)
                self.qapp.processEvents()
                model = table.table_model
                original_columns = model.columnCount()
                selection_model = table.selectionModel()
                table.selectColumn(0)
                selection_model.select(
                    model.index(0, 1),
                    QItemSelectionModel.SelectionFlag.Select
                    | QItemSelectionModel.SelectionFlag.Columns,
                )
                selection_model.setCurrentIndex(
                    model.index(3, 1),
                    QItemSelectionModel.SelectionFlag.NoUpdate,
                )
                window._remember_table_selection_origin(table, "columns")
                horizontal = table.horizontalScrollBar()
                vertical = table.verticalScrollBar()
                horizontal.setValue(min(2, horizontal.maximum()))
                vertical.setValue(min(2, vertical.maximum()))
                expected_scroll = (horizontal.value(), vertical.value())

                model.set_cell_text(1, original_columns - 1, "used")
                self.qapp.processEvents()

                self.assertEqual(
                    model.columnCount(),
                    original_columns + added_columns,
                )
                self.assertEqual(
                    {
                        index.column()
                        for index in selection_model.selectedColumns()
                    },
                    {0, 1},
                )
                self.assertEqual(
                    (table.currentIndex().row(), table.currentIndex().column()),
                    (3, 1),
                )
                self.assertEqual(
                    window._table_selection_origins.get(table),
                    "columns",
                )
                self.assertEqual(
                    (horizontal.value(), vertical.value()),
                    expected_scroll,
                )

    def test_paste_consumes_spares_and_one_undo_restores_original_shape(self):
        window = self.make_window()
        table = window.table
        model = table.table_model
        controller = window._table_controller
        original_shape = (model.rowCount(), model.columnCount())
        start_row = model.rowCount() - 1
        start_column = model.columnCount() - 1
        table.setCurrentIndex(model.index(start_row, start_column))
        QApplication.clipboard().setText("a\tb\nc\td")

        window.paste_table_selection(table)
        self.qapp.processEvents()
        expanded_shape = (model.rowCount(), model.columnCount())
        self.assertGreater(expanded_shape[0], original_shape[0])
        self.assertGreater(expanded_shape[1], original_shape[1])
        self.assertEqual(model.cell_text(start_row + 1, start_column + 1), "d")
        self.assert_last_sample_row_is_blank(controller)
        self.assertTrue(
            all(
                model.cell_text(row, model.columnCount() - 1) == ""
                for row in range(1, model.rowCount())
            )
        )

        controller.undo()
        self.qapp.processEvents()
        self.assertEqual((model.rowCount(), model.columnCount()), original_shape)

        controller.redo()
        self.qapp.processEvents()
        self.assertEqual((model.rowCount(), model.columnCount()), expanded_shape)
        self.assertEqual(model.cell_text(start_row + 1, start_column + 1), "d")

    def test_xy_paste_consumes_spare_and_undo_redo_restores_schema_and_value(self):
        surfaces = (
            (
                "shared",
                lambda window: (window.table, window._table_controller),
                1,
            ),
            (
                "paired",
                lambda window: (
                    window.xy_independent_table,
                    window._xy_paired_controller,
                ),
                2,
            ),
        )
        for name, surface, added_columns in surfaces:
            with self.subTest(surface=name):
                window = self.make_xy_window()
                table, controller = surface(window)
                model = table.table_model
                sheet = window.workbook.active_sheet
                original_model_columns = model.columnCount()
                original_column_ids = list(sheet.column_ids)
                original_series_ids = [
                    series.id for series in sheet.xy_settings.series
                ]
                original_shared_series_ids = [
                    list(shared.series_ids)
                    for shared in sheet.xy_settings.shared_tables
                ]
                original_pair_ids = list(sheet.xy_settings.paired_series_ids)
                target_row = controller.sample_start_row()
                target_column = model.columnCount() - 1
                table.setCurrentIndex(model.index(target_row, target_column))
                QApplication.clipboard().setText("42")

                window.paste_table_selection(table)
                self.qapp.processEvents()

                self.assertEqual(
                    model.columnCount(),
                    original_model_columns + added_columns,
                )
                self.assertEqual(model.cell_text(target_row, target_column), "42")
                expanded_column_ids = list(sheet.column_ids)
                expanded_series_ids = [
                    series.id for series in sheet.xy_settings.series
                ]
                expanded_shared_series_ids = [
                    list(shared.series_ids)
                    for shared in sheet.xy_settings.shared_tables
                ]
                expanded_pair_ids = list(sheet.xy_settings.paired_series_ids)
                trailing_columns = (
                    (model.columnCount() - 1,)
                    if name == "shared"
                    else (model.columnCount() - 2, model.columnCount() - 1)
                )
                self.assertTrue(
                    all(
                        model.cell_text(row, column) == ""
                        for row in range(controller.sample_start_row(), model.rowCount())
                        for column in trailing_columns
                    )
                )

                controller.undo()
                self.qapp.processEvents()
                self.assertEqual(model.columnCount(), original_model_columns)
                self.assertEqual(model.cell_text(target_row, target_column), "")
                self.assertEqual(sheet.column_ids, original_column_ids)
                self.assertEqual(
                    [series.id for series in sheet.xy_settings.series],
                    original_series_ids,
                )
                self.assertEqual(
                    [
                        list(shared.series_ids)
                        for shared in sheet.xy_settings.shared_tables
                    ],
                    original_shared_series_ids,
                )
                self.assertEqual(
                    sheet.xy_settings.paired_series_ids,
                    original_pair_ids,
                )

                controller.redo()
                self.qapp.processEvents()
                self.assertEqual(
                    model.columnCount(),
                    original_model_columns + added_columns,
                )
                self.assertEqual(model.cell_text(target_row, target_column), "42")
                self.assertEqual(sheet.column_ids, expanded_column_ids)
                self.assertEqual(
                    [series.id for series in sheet.xy_settings.series],
                    expanded_series_ids,
                )
                self.assertEqual(
                    [
                        list(shared.series_ids)
                        for shared in sheet.xy_settings.shared_tables
                    ],
                    expanded_shared_series_ids,
                )
                self.assertEqual(
                    sheet.xy_settings.paired_series_ids,
                    expanded_pair_ids,
                )
                self.assert_last_sample_row_is_blank(controller)
        self.assert_last_sample_row_is_blank(controller)

    def test_only_entire_row_delete_reduces_displayed_row_capacity(self):
        groups = self.make_window()
        groups.set_table_dataframe(pd.DataFrame({"Dose": ["1", "2"]}))
        self.settle_capacity(groups)
        groups_table = groups.table
        groups_model = groups_table.table_model
        groups_start = groups._table_controller.sample_start_row()
        groups_before = groups_model.rowCount()
        self.select_table_range(
            groups_table,
            groups_start,
            0,
            groups_start,
            groups_model.columnCount() - 1,
        )
        groups.delete_table_structure("entire_row", groups_table)
        self.qapp.processEvents()
        self.assertEqual(groups_model.rowCount(), groups_before - 1)

        xy = self.make_xy_window()
        paired = xy.xy_independent_table
        paired_model = paired.table_model
        paired_start = xy._xy_paired_controller.sample_start_row()
        paired_before = paired_model.rowCount()
        self.select_table_range(
            paired,
            paired_start,
            0,
            paired_start,
            paired_model.columnCount() - 1,
        )
        xy.delete_table_structure("entire_row", paired)
        self.qapp.processEvents()
        self.assertEqual(paired_model.rowCount(), paired_before - 1)

    def test_structure_and_clipboard_operations_refresh_plot_once_after_debounce(self):
        operations = (
            "insert",
            "delete",
            "down",
            "up",
            "clear",
            "paste",
        )
        for operation_name in operations:
            with self.subTest(operation=operation_name):
                window = self.make_window()
                window.set_table_dataframe(pd.DataFrame({"Dose": ["1", "2"]}))
                self.settle_capacity(window)
                table = window.table
                model = table.table_model
                sample_start = window._table_controller.sample_start_row()
                self.select_table_range(table, sample_start, 0, sample_start, 0)

                if operation_name == "insert":
                    operation = lambda: window.insert_table_structure(
                        "entire_row",
                        table,
                    )
                elif operation_name == "delete":
                    operation = lambda: window.delete_table_structure(
                        "entire_row",
                        table,
                    )
                elif operation_name == "down":
                    operation = lambda: window.insert_table_structure(
                        "cells_down",
                        table,
                    )
                elif operation_name == "up":
                    operation = lambda: window.delete_table_structure(
                        "cells_up",
                        table,
                    )
                elif operation_name == "clear":
                    operation = lambda: window.clear_table_selection(table)
                else:
                    table.setCurrentIndex(model.index(sample_start, 0))
                    QApplication.clipboard().setText("pasted")
                    operation = lambda: window.paste_table_selection(table)

                self.assert_one_debounced_render(window, operation)


if __name__ == "__main__":
    import unittest

    unittest.main()
