from __future__ import annotations

import json
import tempfile
from pathlib import Path

from tests.easygraph_case import ROOT, EasyGraphQtTestCase
from easygraph.packaging_smoke import REQUIRED_LAZY_MODULES, run_packaging_smoke


class PackagingSmokeTests(EasyGraphQtTestCase):
    def test_source_smoke_exercises_lazy_renderers_and_export_backends(self):
        with tempfile.TemporaryDirectory() as tmp:
            report = run_packaging_smoke(tmp, self.qapp)
            stored = json.loads(
                (Path(tmp) / "packaging-smoke.json").read_text(encoding="utf-8")
            )

            self.assertEqual(report, stored)
            self.assertEqual(report["status"], "ok")
            self.assertFalse(report["frozen"])
            self.assertEqual(
                [case["name"] for case in report["cases"]],
                ["box", "violin", "ridge", "quasirandom-large", "xy-mixed"],
            )
            self.assertEqual(report["missing_modules"], [])
            self.assertEqual(report["missing_artifacts"], [])
            self.assertTrue(report["translation"]["zh_CN_available"])
            self.assertTrue(report["translation"]["zh_CN_loadable"])
            self.assertEqual(len(report["artifacts"]), 7)
            self.assertEqual(len(REQUIRED_LAZY_MODULES), 7)
            self.assertEqual(
                report["ui"],
                {
                    "window_visible": True,
                    "placeholder_before_canvas": True,
                    "canvas_ready": True,
                    "table_rows": 37,
                    "table_columns": 4,
                    "menu_actions": 5,
                },
            )

    def test_windows_build_script_collects_every_runtime_lazy_module(self):
        script = (ROOT / "scripts" / "build_and_smoke_windows.ps1").read_text(
            encoding="utf-8"
        )
        build_notes = (ROOT / "WINDOWS_BUILD.md").read_text(encoding="utf-8")

        for module in ("easygraph.packaging_smoke", *REQUIRED_LAZY_MODULES):
            with self.subTest(module=module):
                flag = f"--hidden-import {module}"
                self.assertIn(flag, script)
                self.assertIn(flag, build_notes)
        self.assertIn("Push-Location $ProjectRoot", script)
        self.assertIn("Remove-Item $SmokeDir -Recurse -Force", script)
        self.assertIn("$Report.frozen", script)
        self.assertIn('--add-data "translations;translations"', script)
