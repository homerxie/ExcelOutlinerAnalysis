from __future__ import annotations

from dataclasses import asdict
import json
import pathlib
import sys
import tempfile
import zipfile

import pandas as pd


ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tests.test_support import WarningConfiguredTestCase

from easygraph import project_io, recovery
from easygraph.analysis_results import AnalysisSettings
from easygraph.settings import ChartSettings
from easygraph.workbook import SHEET_MODE_XY, SheetDocument, WorkbookDocument
from easygraph.xy_fitting import FitParameterSpec, XYFitSpec
from easygraph.xy_series import (
    XYSeriesSpec,
    XYSettings,
    remove_xy_column_references,
    remove_xy_series,
)


class XYFitPersistenceTests(WarningConfiguredTestCase):
    @staticmethod
    def fit_spec(
        *,
        fit_id: str = "fit-main",
        series_id: str = "series-a",
    ) -> XYFitSpec:
        return XYFitSpec(
            id=fit_id,
            series_id=series_id,
            model_id="custom",
            expression="a * exp(-k * x) + c",
            parameters=[
                FitParameterSpec("a", 8.0, lower=0.0),
                FitParameterSpec("k", 0.3, lower=0.0, upper=10.0),
                FitParameterSpec("c", 1.0, fixed=True),
            ],
            enabled=True,
            auto_refit=False,
            line_style="Dash-dot",
            line_width=2.75,
            color="#336699",
            show_in_legend=True,
            show_equation=True,
            annotation_parameter_names=["a", "k"],
            equation_position_x=0.32,
            equation_position_y=0.68,
            syntax_version=1,
        )

    @classmethod
    def xy_settings(cls, *, with_fit: bool = True) -> XYSettings:
        return XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(
                    id="series-a",
                    name="Response A",
                    y_column_id="y",
                )
            ],
            fit_specs=[cls.fit_spec()] if with_fit else [],
            fit_annotation_mode="parameters",
        )

    @classmethod
    def xy_sheet(cls, *, with_fit: bool = True) -> SheetDocument:
        return SheetDocument(
            id="xy-sheet",
            name="XY",
            dataframe=pd.DataFrame({"Time": [0.0, 1.0], "Response": [9.0, 7.0]}),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=cls.xy_settings(with_fit=with_fit),
        )

    def test_v5_project_round_trip_rebuilds_nested_fit_dataclasses(self):
        source = WorkbookDocument([self.xy_sheet()], "xy-sheet")

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "fit-roundtrip.eg"
            project_io.write_project(path, source)
            loaded = project_io.read_workbook_project(path)
            with zipfile.ZipFile(path) as archive:
                manifest = json.loads(archive.read("project.json"))

        restored = loaded.active_sheet.xy_settings
        self.assertEqual(manifest, {"version": 5, "app": "EasyGraph"})
        self.assertEqual(asdict(restored), asdict(source.active_sheet.xy_settings))
        self.assertIsInstance(restored.fit_specs[0], XYFitSpec)
        self.assertTrue(
            all(
                isinstance(parameter, FitParameterSpec)
                for parameter in restored.fit_specs[0].parameters
            )
        )

    def test_v4_project_round_trip_preserves_centered_fit_origin(self):
        sheet = self.xy_sheet()
        fit_spec = sheet.xy_settings.fit_specs[0]
        fit_spec.model_id = "polynomial2"
        fit_spec.expression = ""
        fit_spec.parameters = []
        fit_spec.x_origin = 1_000_000_000_000.5
        source = WorkbookDocument([sheet], sheet.id)

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "centered-fit-roundtrip.eg"
            project_io.write_project(path, source)
            loaded = project_io.read_workbook_project(path)

        restored = loaded.active_sheet.xy_settings.fit_specs[0]
        self.assertEqual(restored.model_id, "polynomial2")
        self.assertEqual(restored.x_origin, fit_spec.x_origin)

    def test_fit_payload_without_centered_origin_uses_legacy_default(self):
        payload = asdict(self.xy_settings())
        payload["fit_specs"][0].pop("x_origin")

        restored = project_io.xy_settings_from_dict(payload, ["x", "y"])

        self.assertIsNone(restored.fit_specs[0].x_origin)

    def test_fit_payload_without_equation_visibility_uses_legacy_default(self):
        payload = asdict(self.xy_settings())
        payload["fit_specs"][0].pop("show_equation")

        restored = project_io.xy_settings_from_dict(payload, ["x", "y"])

        self.assertFalse(restored.fit_specs[0].show_equation)

    def test_fit_payload_without_annotation_fields_uses_equation_and_all_parameters(self):
        payload = asdict(self.xy_settings())
        payload.pop("fit_annotation_mode")
        payload["fit_specs"][0].pop("annotation_parameter_names")

        restored = project_io.xy_settings_from_dict(payload, ["x", "y"])

        self.assertEqual(restored.fit_annotation_mode, "equation")
        self.assertEqual(restored.fit_specs[0].annotation_parameter_names, [])

    def test_fit_payload_without_equation_position_uses_automatic_layout(self):
        payload = asdict(self.xy_settings())
        payload["fit_specs"][0].pop("equation_position_x")
        payload["fit_specs"][0].pop("equation_position_y")

        restored = project_io.xy_settings_from_dict(payload, ["x", "y"])

        self.assertIsNone(restored.fit_specs[0].equation_position_x)
        self.assertIsNone(restored.fit_specs[0].equation_position_y)

    def test_v3_project_without_fit_specs_migrates_to_an_empty_list(self):
        settings_payload = asdict(self.xy_settings(with_fit=False))
        settings_payload.pop("fit_specs")

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "xy-v3.eg"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr(
                    "project.json",
                    json.dumps(project_io.project_manifest(3)),
                )
                archive.writestr(
                    "sheets.json",
                    json.dumps(
                        {
                            "active_sheet_id": "xy-sheet",
                            "sheets": [
                                {"id": "xy-sheet", "name": "XY", "mode": "xy"}
                            ],
                        }
                    ),
                )
                archive.writestr("sheets/xy-sheet/data.csv", "Time,Response\n0,9\n")
                archive.writestr(
                    "sheets/xy-sheet/settings.json",
                    json.dumps(
                        {
                            "chart": asdict(ChartSettings()),
                            "xy": settings_payload,
                            "column_ids": ["x", "y"],
                        }
                    ),
                )

            loaded = project_io.read_workbook_project(path)

        self.assertEqual(loaded.active_sheet.xy_settings.fit_specs, [])

    def test_fit_validation_rejects_dangling_duplicate_and_ambiguous_specs(self):
        base = asdict(self.xy_settings(with_fit=False))
        valid_fit = asdict(self.fit_spec())
        cases = [
            (
                "missing series",
                [{**valid_fit, "series_id": "missing"}],
                "references missing series",
            ),
            (
                "duplicate fit ID",
                [valid_fit, valid_fit],
                "fit IDs must be unique",
            ),
            (
                "duplicate fitted series",
                [valid_fit, {**valid_fit, "id": "fit-b"}],
                "Only one XY fit is allowed per series",
            ),
            (
                "duplicate parameter name",
                [
                    {
                        **valid_fit,
                        "parameters": [
                            asdict(FitParameterSpec("a", 1.0)),
                            asdict(FitParameterSpec("a", 2.0)),
                        ],
                    }
                ],
                "parameter names must be unique",
            ),
        ]

        for label, fit_specs, message in cases:
            with self.subTest(label=label):
                with self.assertRaisesRegex(ValueError, message):
                    project_io.xy_settings_from_dict(
                        {**base, "fit_specs": fit_specs},
                        ["x", "y"],
                    )

    def test_fit_decoder_rejects_unknown_fields_at_every_nested_level(self):
        base = asdict(self.xy_settings(with_fit=False))
        valid_fit = asdict(self.fit_spec())
        unknown_fit = {**valid_fit, "retired_solver": "legacy"}
        unknown_parameter = {
            **valid_fit,
            "parameters": [
                {
                    **valid_fit["parameters"][0],
                    "legacy_step_size": 0.1,
                }
            ],
        }

        with self.assertRaisesRegex(
            ValueError,
            r"^Unknown XYFitSpec fields: retired_solver$",
        ):
            project_io.xy_settings_from_dict(
                {**base, "fit_specs": [unknown_fit]},
                ["x", "y"],
            )
        with self.assertRaisesRegex(
            ValueError,
            r"^Unknown FitParameterSpec fields: legacy_step_size$",
        ):
            project_io.xy_settings_from_dict(
                {**base, "fit_specs": [unknown_parameter]},
                ["x", "y"],
            )

    def test_removing_a_series_or_its_column_removes_associated_fits(self):
        settings = self.xy_settings()
        self.assertEqual(remove_xy_series(settings, {"series-a"}), ("series-a",))
        self.assertEqual(settings.series, [])
        self.assertEqual(settings.fit_specs, [])

        settings = self.xy_settings()
        self.assertEqual(
            remove_xy_column_references(settings, {"y"}),
            ("series-a",),
        )
        self.assertEqual(settings.series, [])
        self.assertEqual(settings.fit_specs, [])

    def test_recovery_sheet_state_restores_fit_specs_without_losing_analysis(self):
        sheet = self.xy_sheet(with_fit=False)
        sheet.analysis_settings = AnalysisSettings(visible_statistics=["Mean"])
        workbook = WorkbookDocument([sheet], sheet.id)
        restored_settings = self.xy_settings()

        recovery._apply_operation(
            workbook,
            {
                "type": "sheet_state",
                "sheet_id": sheet.id,
                "mode": SHEET_MODE_XY,
                "column_ids": ["x", "y"],
                "xy": asdict(restored_settings),
            },
        )
        recovery._apply_operation(
            workbook,
            {
                "type": "analysis",
                "sheet_id": sheet.id,
                "analysis": {"visible_statistics": ["Median", "SD"]},
            },
        )

        self.assertEqual(
            asdict(workbook.active_sheet.xy_settings),
            asdict(restored_settings),
        )
        self.assertIsInstance(
            workbook.active_sheet.xy_settings.fit_specs[0],
            XYFitSpec,
        )
        self.assertEqual(
            workbook.active_sheet.analysis_settings.visible_statistics,
            ["Median", "SD"],
        )


if __name__ == "__main__":
    import unittest

    unittest.main()
