from __future__ import annotations

import math
import subprocess
import sys
from dataclasses import FrozenInstanceError
from pathlib import Path

import numpy as np

from tests.easygraph_case import EasyGraphTestCase

from easygraph.xy_fitting import (
    CustomExpressionError,
    FIT_MODEL_REGISTRY,
    FitParameterSpec,
    ParsedCustomExpression,
    default_fit_spec,
    fit_xy_values,
    initial_fit_parameters,
    parse_custom_expression,
)


class CustomExpressionTests(EasyGraphTestCase):
    def test_parsed_expression_keeps_legacy_four_position_construction(self):
        parsed = ParsedCustomExpression(
            "x",
            "x",
            (),
            lambda x, _parameters: 2.0 * x,
        )

        self.assertEqual(parsed.log_base_parameter_names, ())
        np.testing.assert_allclose(parsed.evaluate([1.0, 3.0], {}), [2.0, 6.0])

    def test_parser_accepts_friendly_equation_syntax_and_vectorizes(self):
        parsed = parse_custom_expression("y = a * x^2 + ln(x) + pi")

        self.assertEqual(parsed.parameter_names, ("a",))
        values = parsed.evaluate(np.array([1.0, 2.0]), {"a": 2.0})
        np.testing.assert_allclose(
            values,
            2.0 * np.array([1.0, 4.0]) + np.log([1.0, 2.0]) + np.pi,
        )

    def test_parser_recognizes_parameters_in_first_use_order(self):
        parsed = parse_custom_expression(
            "offset * (amplitude + rate * x) + trailing"
        )

        self.assertEqual(
            parsed.parameter_names,
            ("offset", "amplitude", "rate", "trailing"),
        )

    def test_parser_rejects_python_execution_and_object_access(self):
        unsafe = (
            "__import__('os').system('echo bad')",
            "x.__class__",
            "x[0]",
            "(lambda value: value)(x)",
            "open(path)",
            "[x][0]",
        )

        for expression in unsafe:
            with self.subTest(expression=expression):
                with self.assertRaises(CustomExpressionError):
                    parse_custom_expression(expression)

    def test_parser_rejects_unsupported_operators_and_invalid_calls(self):
        for expression in ("x % 2", "x // 2", "sin(x, 2)", "exp", "y + x"):
            with self.subTest(expression=expression):
                with self.assertRaises(CustomExpressionError):
                    parse_custom_expression(expression)

    def test_log_uses_an_explicit_base_while_ln_remains_natural(self):
        x = np.array([0.25, 1.0, 2.0, 8.0, 16.0])
        parsed = parse_custom_expression(
            "log(x, 2) + log(x, 0.5) + log(x, 10) + ln(x) + log10(x)"
        )

        expected = (
            np.log2(x)
            + np.log(x) / np.log(0.5)
            + np.log10(x)
            + np.log(x)
            + np.log10(x)
        )
        np.testing.assert_allclose(parsed.evaluate(x, {}), expected, rtol=1e-15)

        scalar = parse_custom_expression("log(8, 2)").evaluate(0.0, {})
        self.assertEqual(scalar.shape, ())
        self.assertAlmostEqual(float(scalar), 3.0)

    def test_log_broadcasts_inside_reducers(self):
        summed = parse_custom_expression("sum_over(k, 2, 4, log(x, k))")
        integrated = parse_custom_expression(
            "integral(t, 1, x, log(t, 2), 64)"
        )
        x = np.array([1.0, 2.0, 8.0])
        bases = np.arange(2.0, 5.0)
        expected_sum = np.sum(
            np.log(x[:, np.newaxis]) / np.log(bases[np.newaxis, :]),
            axis=1,
        )
        expected_integral = (x * np.log(x) - x + 1.0) / np.log(2.0)

        np.testing.assert_allclose(summed.evaluate(x, {}), expected_sum, rtol=1e-15)
        np.testing.assert_allclose(
            integrated.evaluate(x, {}),
            expected_integral,
            rtol=2e-14,
            atol=2e-14,
        )

    def test_log_arity_error_points_natural_logs_to_ln(self):
        invalid = ("log(x)", "log()", "log(x, 2, 3)")

        for expression in invalid:
            with self.subTest(expression=expression):
                with self.assertRaisesRegex(
                    CustomExpressionError,
                    r"log\(value, base\).*ln\(value\)",
                ):
                    parse_custom_expression(expression)

        for expression in ("log(x, base=2)", "log(value=x, base=2)"):
            with self.subTest(expression=expression):
                with self.assertRaisesRegex(
                    CustomExpressionError,
                    r"Named values.*base=2.*not supported",
                ):
                    parse_custom_expression(expression)

        with self.assertRaisesRegex(CustomExpressionError, "exactly 1 value"):
            parse_custom_expression("ln(x, 2)")
        with self.assertRaisesRegex(CustomExpressionError, "exactly 1 value"):
            parse_custom_expression("log10(x, 2)")

    def test_log_invalid_real_domains_fail_cleanly(self):
        invalid = (
            "log(0, 2)",
            "log(-1, 2)",
            "log(2, 0)",
            "log(2, -1)",
            "log(2, 1)",
        )

        for expression in invalid:
            with self.subTest(expression=expression):
                parsed = parse_custom_expression(expression)
                self.assertFalse(
                    np.all(np.isfinite(parsed.evaluate([1.0, 2.0], {})))
                )

                spec = default_fit_spec("undefined-log", "custom")
                spec.expression = expression
                result = fit_xy_values([1.0, 2.0], [0.0, 0.0], spec)
                self.assertFalse(result.success)
                self.assertIn("undefined", result.message)
                self.assertIn("function domains", result.message)

    def test_custom_log_base_parameter_can_be_fitted(self):
        x = np.geomspace(0.5, 32.0, 61)
        spec = default_fit_spec("fit-log-base", "custom")
        spec.expression = "log(x, chosen_base)"

        suggested = initial_fit_parameters(x, np.log2(x), spec)
        self.assertEqual(
            suggested,
            (FitParameterSpec("chosen_base", 2.0),),
        )

        result = fit_xy_values(x, np.log2(x), spec)

        self.assertTrue(result.success, result.message)
        self.assertAlmostEqual(result.parameters["chosen_base"], 2.0, places=8)

        fractional_result = fit_xy_values(
            x,
            np.log(x) / np.log(0.5),
            spec,
        )
        self.assertTrue(fractional_result.success, fractional_result.message)
        self.assertAlmostEqual(
            fractional_result.parameters["chosen_base"],
            0.5,
            places=8,
        )
        self.assertLess(fractional_result.rmse, 1e-10)

        for initial, lower, upper, expected_base in (
            (2.0, 0.8, 20.0, 0.9),
            (0.5, 0.1, 1.2, 1.1),
        ):
            with self.subTest(expected_base=expected_base):
                bounded = default_fit_spec("bounded-log-base", "custom")
                bounded.expression = "log(x, chosen_base)"
                bounded.parameters = [
                    FitParameterSpec(
                        "chosen_base",
                        initial,
                        lower,
                        upper,
                    )
                ]
                bounded_result = fit_xy_values(
                    x,
                    np.log(x) / np.log(expected_base),
                    bounded,
                )
                self.assertTrue(bounded_result.success, bounded_result.message)
                self.assertAlmostEqual(
                    bounded_result.parameters["chosen_base"],
                    expected_base,
                    places=7,
                )
                self.assertLess(bounded_result.rmse, 1e-8)

        parsed = parse_custom_expression(
            "offset + log(x, chosen_base) + sum_over(k, 2, 4, log(x, k))"
        )
        self.assertEqual(parsed.log_base_parameter_names, ("chosen_base",))

        two_base_spec = default_fit_spec("two-log-bases", "custom")
        two_base_spec.expression = "log(x, first_base) + log(x + 1, second_base)"
        two_base_y = np.log2(x) + np.log(x + 1) / np.log(3.0)
        two_base_result = fit_xy_values(x, two_base_y, two_base_spec)
        self.assertTrue(two_base_result.success, two_base_result.message)
        self.assertAlmostEqual(
            two_base_result.parameters["first_base"],
            2.0,
            places=8,
        )
        self.assertAlmostEqual(
            two_base_result.parameters["second_base"],
            3.0,
            places=8,
        )
        self.assertLess(two_base_result.function_evaluations, 100)

        noisy_x = np.geomspace(0.25, 64.0, 161)
        noisy_y = (
            np.log(noisy_x) / np.log(0.5)
            + np.log(noisy_x + 1.0) / np.log(3.0)
            + 0.002 * np.sin(np.linspace(0.0, 11.0, noisy_x.size))
        )
        noisy_two_base_result = fit_xy_values(
            noisy_x,
            noisy_y,
            two_base_spec,
        )
        self.assertTrue(
            noisy_two_base_result.success,
            noisy_two_base_result.message,
        )
        self.assertAlmostEqual(
            noisy_two_base_result.parameters["first_base"],
            0.5,
            places=2,
        )
        self.assertAlmostEqual(
            noisy_two_base_result.parameters["second_base"],
            3.0,
            places=2,
        )
        self.assertLess(noisy_two_base_result.function_evaluations, 200)

        huge_bound = default_fit_spec("huge-log-base-bound", "custom")
        huge_bound.expression = "log(x, chosen_base)"
        huge_bound.parameters = [
            FitParameterSpec("chosen_base", 0.5, 0.1, 1e307)
        ]
        huge_bound_result = fit_xy_values(
            x,
            np.log(x) / np.log(100.0),
            huge_bound,
        )
        self.assertTrue(huge_bound_result.success, huge_bound_result.message)
        self.assertAlmostEqual(
            huge_bound_result.parameters["chosen_base"],
            100.0,
            places=6,
        )

        for trend_value in (1e12, 1e16):
            with self.subTest(trend_value=trend_value):
                fixed_trend = default_fit_spec("trend-log-base", "custom")
                fixed_trend.expression = "trend * x + log(x, chosen_base)"
                fixed_trend.parameters = [
                    FitParameterSpec("trend", trend_value, fixed=True),
                    FitParameterSpec("chosen_base", 2.0),
                ]
                fixed_trend_result = fit_xy_values(
                    x,
                    trend_value * x + np.log(x) / np.log(0.5),
                    fixed_trend,
                )
                self.assertTrue(
                    fixed_trend_result.success,
                    fixed_trend_result.message,
                )
                self.assertAlmostEqual(
                    fixed_trend_result.parameters["chosen_base"],
                    0.5,
                    places=8,
                )

        large_offset = default_fit_spec("offset-log-base", "custom")
        large_offset.expression = "offset + log(x, chosen_base)"
        large_offset.parameters = [
            FitParameterSpec("offset", 1e12, fixed=True),
            FitParameterSpec("chosen_base", 2.0),
        ]
        large_offset_result = fit_xy_values(
            x,
            1e12 + np.log(x) / np.log(0.5),
            large_offset,
        )
        self.assertTrue(large_offset_result.success, large_offset_result.message)
        self.assertAlmostEqual(
            large_offset_result.parameters["chosen_base"],
            0.5,
            places=8,
        )
        self.assertLess(large_offset_result.rmse, 1e-8)

    def test_log_base_uncertainty_is_reported_in_raw_base_units(self):
        x = np.geomspace(0.5, 32.0, 81)
        y = np.log2(x) + 0.01 * np.sin(np.linspace(0.0, 9.0, x.size))
        spec = default_fit_spec("log-base-uncertainty", "custom")
        spec.expression = "log(x, chosen_base)"
        result = fit_xy_values(x, y, spec)

        self.assertTrue(result.success, result.message)
        estimate = result.parameter_estimates[0]
        self.assertIsNotNone(estimate.standard_error)
        fitted_base = estimate.value
        fitted_q = math.log(fitted_base)
        prediction = np.log(x) / fitted_q
        residual_standard_deviation = np.linalg.norm(prediction - y) / math.sqrt(
            x.size - 1
        )
        q_jacobian = -np.log(x) / (fitted_q * fitted_q)
        expected_raw_standard_error = (
            fitted_base
            * residual_standard_deviation
            / np.linalg.norm(q_jacobian)
        )
        self.assertAlmostEqual(
            estimate.standard_error,
            expected_raw_standard_error,
            delta=1e-5 * expected_raw_standard_error,
        )

    def test_parser_supports_full_trigonometric_and_hyperbolic_function_set(self):
        x = np.array([-0.7, -0.2, 0.3, 0.9])
        cases = {
            "sin(x)": np.sin(x),
            "cos(x)": np.cos(x),
            "tan(x)": np.tan(x),
            "asin(x)": np.arcsin(x),
            "acos(x)": np.arccos(x),
            "atan(x)": np.arctan(x),
            "atan2(x, 0.5)": np.arctan2(x, 0.5),
            "atan2(x, -0.5)": np.arctan2(x, -0.5),
            "sec(x)": 1.0 / np.cos(x),
            "csc(x)": 1.0 / np.sin(x),
            "cot(x)": np.cos(x) / np.sin(x),
            "sinh(x)": np.sinh(x),
            "cosh(x)": np.cosh(x),
            "tanh(x)": np.tanh(x),
        }

        for expression, expected in cases.items():
            with self.subTest(expression=expression):
                parsed = parse_custom_expression(expression)
                self.assertEqual(parsed.parameter_names, ())
                np.testing.assert_allclose(
                    parsed.evaluate(x, {}),
                    expected,
                    rtol=2e-15,
                    atol=2e-15,
                )

    def test_trigonometric_functions_use_radians_and_accept_scalar_x(self):
        parsed = parse_custom_expression(
            "sin(pi / 2) + cos(pi) + tan(pi / 4) + asin(1) + "
            "acos(0) + atan(1) + atan2(1, 0)"
        )
        scalar = parsed.evaluate(0.0, {})

        self.assertEqual(scalar.shape, ())
        self.assertAlmostEqual(float(scalar), 1.0 + 7.0 * math.pi / 4.0)

    def test_trigonometric_function_arities_are_strict(self):
        invalid = (
            "atan2(x)",
            "atan2(x, 1, 2)",
            "atan2(x, second=1)",
            "sec()",
            "csc(x, 1)",
            "sinh(x, 1)",
        )

        for expression in invalid:
            with self.subTest(expression=expression):
                with self.assertRaises(CustomExpressionError):
                    parse_custom_expression(expression)

    def test_atan2_broadcasts_inside_a_finite_sum(self):
        parsed = parse_custom_expression(
            "sum_over(k, 1, 3, atan2(k, x))"
        )
        x = np.asarray([0.5, 1.5, 3.0])
        expected = np.sum(
            np.arctan2(np.arange(1.0, 4.0)[:, np.newaxis], x),
            axis=0,
        )

        np.testing.assert_allclose(
            parsed.evaluate(x, {}),
            expected,
            rtol=2e-15,
            atol=2e-15,
        )

    def test_new_function_names_cannot_be_parameters_or_reducer_bindings(self):
        names = (
            "asin",
            "acos",
            "atan",
            "atan2",
            "sec",
            "csc",
            "cot",
            "sinh",
            "cosh",
            "tanh",
        )

        for name in names:
            with self.subTest(name=name, use="bare"):
                with self.assertRaises(CustomExpressionError):
                    parse_custom_expression(f"{name} + x")
            with self.subTest(name=name, use="sum binding"):
                with self.assertRaises(CustomExpressionError):
                    parse_custom_expression(f"sum_over({name}, 1, 2, {name} * x)")

    def test_trigonometric_singularities_and_inverse_domains_fail_cleanly(self):
        undefined_expressions = (
            "asin(1.01)",
            "acos(-1.01)",
            "tan(pi / 2)",
            "sec(pi / 2)",
            "csc(0)",
            "cot(pi)",
        )

        for expression in undefined_expressions:
            with self.subTest(expression=expression):
                parsed = parse_custom_expression(expression)
                self.assertFalse(np.all(np.isfinite(parsed.evaluate([0.0, 1.0], {}))))

                spec = default_fit_spec("undefined-trig", "custom")
                spec.expression = expression
                result = fit_xy_values([0.0, 1.0], [0.0, 0.0], spec)
                self.assertFalse(result.success)
                self.assertIn("undefined", result.message)
                self.assertIn("radians", result.message)

    def test_hyperbolic_overflow_returns_an_actionable_fit_failure(self):
        for expression in ("sinh(x)", "cosh(x)"):
            with self.subTest(expression=expression):
                spec = default_fit_spec("overflowing-hyperbolic", "custom")
                spec.expression = expression
                result = fit_xy_values([1_000.0, 1_001.0], [0.0, 0.0], spec)

                self.assertFalse(result.success)
                self.assertIn("undefined", result.message)
                self.assertIn("function domains", result.message)

    def test_custom_trigonometric_and_hyperbolic_curves_can_be_fitted(self):
        x = np.linspace(-2.0, 2.0, 81)
        cases = {
            "sin": np.sin(x),
            "cosh": np.cosh(x),
            "tanh": np.tanh(x),
        }
        for function_name, basis in cases.items():
            with self.subTest(function_name=function_name):
                spec = default_fit_spec(f"fit-{function_name}", "custom")
                spec.expression = (
                    f"amplitude * {function_name}(x) + offset"
                )
                spec.parameters = [
                    FitParameterSpec("amplitude", 1.0),
                    FitParameterSpec("offset", 0.0),
                ]
                result = fit_xy_values(x, 2.5 * basis - 0.4, spec)

                self.assertTrue(result.success, result.message)
                self.assertAlmostEqual(
                    result.parameters["amplitude"], 2.5, places=9
                )
                self.assertAlmostEqual(
                    result.parameters["offset"], -0.4, places=9
                )

    def test_sum_and_integral_are_vectorized_and_keep_local_names_scoped(self):
        parsed = parse_custom_expression(
            "y = Σ(k, 1, 4, a * k * x) + ∫(t, 0, x, b * t, 64) + offset"
        )

        self.assertEqual(parsed.parameter_names, ("a", "b", "offset"))
        self.assertEqual(
            parsed.normalized_expression,
            "sum_over(k, 1, 4, a * k * x) + integral(t, 0, x, b * t, 64) + offset",
        )
        x = np.array([2.0, -1.0, 2.0, 0.5])
        values = parsed.evaluate(x, {"a": 0.3, "b": 1.5, "offset": -0.2})
        np.testing.assert_allclose(
            values,
            0.3 * 10.0 * x + 0.75 * x**2 - 0.2,
            rtol=1e-13,
            atol=1e-13,
        )

    def test_unicode_sum_aliases_and_parameterized_integral_bounds(self):
        sigma = parse_custom_expression("∑(index, -2, 2, index^2 + x)")
        integral = parse_custom_expression(
            "integral(time, lower, x + width, exp(-rate * time))"
        )

        np.testing.assert_allclose(sigma.evaluate([1.0, 3.0], {}), [15.0, 25.0])
        self.assertEqual(integral.parameter_names, ("lower", "width", "rate"))
        x = np.array([0.2, 1.1, 0.2])
        parameters = {"lower": -0.4, "width": 0.3, "rate": 0.7}
        expected = (
            np.exp(-parameters["rate"] * parameters["lower"])
            - np.exp(-parameters["rate"] * (x + parameters["width"]))
        ) / parameters["rate"]
        np.testing.assert_allclose(
            integral.evaluate(x, parameters),
            expected,
            rtol=2e-14,
            atol=2e-14,
        )

    def test_unicode_reducer_symbols_are_only_normalized_as_function_names(self):
        parsed = parse_custom_expression("Σrate * x")

        self.assertEqual(parsed.normalized_expression, "Σrate * x")
        self.assertEqual(parsed.parameter_names, ("Σrate",))

    def test_reducer_syntax_limits_and_nesting_are_rejected(self):
        invalid = (
            "sum_over(k, 1.0, 4, k)",
            "sum_over(k, first, 4, k)",
            "sum_over(k, 4, 1, k)",
            "sum_over(k, 0, 256, k)",
            "sum_over(k, 9007199254740993, 9007199254740993, k)",
            "sum_over(x, 1, 4, x)",
            "sum_over(k, 1, 4, k, x)",
            "sum_over(k, 1, 4, value=k)",
            "integral(t, 0, x, t, 7)",
            "integral(t, 0, x, t, 129)",
            "integral(t, 0, x, t, 32.0)",
            "integral(t, 0, x, t, points)",
            "integral(t, 0, x, t, points=32)",
            "sum_over(k, 1, 5, expression)",
            "integral(t, 0, x, expression)",
            "integral(t, t, x, t)",
            "t + integral(t, 0, x, t)",
            "integral(t, 0, x, t) + t",
            "sum_over(k, 1, 2, integral(t, 0, x, t))",
            "integral(t, sum_over(k, 1, 2, k), x, t)",
            "integral(t, 0, x, sum_over(k, 1, 2, k * t))",
            (
                "sum_over(a, 1, 200, a) + sum_over(b, 1, 200, b) + "
                "sum_over(c, 1, 200, c)"
            ),
        )

        for expression in invalid:
            with self.subTest(expression=expression):
                with self.assertRaises(CustomExpressionError):
                    parse_custom_expression(expression)

    def test_reducers_do_not_relax_expression_security(self):
        unsafe = (
            "sum_over(k, 1, 4, x[k])",
            "sum_over(k, 1, 4, k.__class__)",
            "integral(t, 0, x, open(path))",
            "integral(t, 0, x, __import__('os').system('bad'))",
        )

        for expression in unsafe:
            with self.subTest(expression=expression):
                with self.assertRaises(CustomExpressionError):
                    parse_custom_expression(expression)


class XYFittingTests(EasyGraphTestCase):
    def test_import_does_not_eagerly_load_scipy_optimize(self):
        completed = subprocess.run(
            [
                sys.executable,
                "-c",
                "import sys; sys.path.insert(0, 'src'); import easygraph.xy_fitting; "
                "raise SystemExit('scipy.optimize' in sys.modules)",
            ],
            check=False,
            capture_output=True,
            text=True,
            cwd=Path(__file__).resolve().parents[1],
        )

        self.assertEqual(completed.returncode, 0, completed.stderr)

    def test_fit_honors_cooperative_cancellation_before_work_starts(self):
        result = fit_xy_values(
            np.linspace(0.0, 5.0, 100),
            np.linspace(1.0, 2.0, 100),
            default_fit_spec("cancelled", "exponential"),
            cancel_check=lambda: True,
        )

        self.assertFalse(result.success)
        self.assertEqual(result.status, "cancelled")
        self.assertIn("cancelled", result.message)

        calls = 0

        def cancel_during_active_set() -> bool:
            nonlocal calls
            calls += 1
            return calls >= 4

        bounded = default_fit_spec("cancelled-bounds", "polynomial5")
        bounded.parameters = [
            FitParameterSpec(name, 0.0, lower=-1.0, upper=1.0)
            for name in FIT_MODEL_REGISTRY["polynomial5"].parameter_names
        ]
        active_set_result = fit_xy_values(
            np.linspace(-1.0, 1.0, 41),
            np.zeros(41),
            bounded,
            cancel_check=cancel_during_active_set,
        )
        self.assertFalse(active_set_result.success)
        self.assertEqual(active_set_result.status, "cancelled")
        self.assertGreaterEqual(calls, 4)

    def test_registry_exposes_all_supported_models_and_metadata(self):
        self.assertEqual(
            set(FIT_MODEL_REGISTRY),
            {
                "linear",
                "polynomial2",
                "polynomial3",
                "polynomial4",
                "polynomial5",
                "exponential",
                "logarithmic",
                "power",
                "gaussian",
                "custom",
            },
        )
        for model in FIT_MODEL_REGISTRY.values():
            self.assertTrue(model.display_name)
            self.assertTrue(model.equation)
            self.assertEqual(len(model.parameter_names), len(model.default_bounds))

    def test_linear_fit_reports_parameters_statistics_and_curve(self):
        x = np.linspace(-3.0, 4.0, 30)
        y = 2.5 * x - 1.25
        spec = default_fit_spec("series-a", "linear")

        result = fit_xy_values(x, y, spec)

        self.assertTrue(result.success, result.message)
        self.assertEqual(result.fit_id, spec.id)
        self.assertEqual(result.series_id, "series-a")
        self.assertEqual(result.x_origin, 0.5)
        self.assertAlmostEqual(result.parameters["slope"], 2.5, places=10)
        self.assertAlmostEqual(result.parameters["intercept"], -1.25, places=10)
        self.assertAlmostEqual(result.sse or 0.0, 0.0, places=20)
        self.assertAlmostEqual(result.r_squared or 0.0, 1.0, places=12)
        self.assertEqual(len(result.curve_x), len(result.curve_y))
        self.assertGreaterEqual(len(result.curve_x), 200)
        self.assertEqual(result.equation, "y = slope * x + intercept")
        curve_x = np.asarray(result.curve_x)
        np.testing.assert_allclose(
            result.curve_y,
            result.parameters["slope"] * curve_x + result.parameters["intercept"],
            rtol=0.0,
            atol=1e-12,
        )
        with self.assertRaises(FrozenInstanceError):
            result.message = "changed"  # type: ignore[misc]
        with self.assertRaises(TypeError):
            result.parameters["slope"] = 1.0  # type: ignore[index]

    def test_adjusted_r_squared_counts_each_free_parameter_once(self):
        x = np.arange(8.0)
        y = np.array([0.2, 2.1, 3.8, 6.2, 8.1, 9.7, 12.3, 13.8])

        result = fit_xy_values(x, y, default_fit_spec("series", "linear"))

        self.assertTrue(result.success, result.message)
        expected = 1.0 - (1.0 - float(result.r_squared)) * 7.0 / 6.0
        self.assertAlmostEqual(float(result.adjusted_r_squared), expected, places=12)

    def test_polynomial_and_logarithmic_models_fit_known_data(self):
        x_poly = np.linspace(-2.0, 2.0, 25)
        y_poly = 3.0 * x_poly**2 - 2.0 * x_poly + 4.0
        polynomial = fit_xy_values(
            x_poly,
            y_poly,
            default_fit_spec("poly", "polynomial2"),
        )

        self.assertTrue(polynomial.success, polynomial.message)
        self.assertAlmostEqual(polynomial.parameters["a"], 3.0, places=9)
        self.assertAlmostEqual(polynomial.parameters["b"], -2.0, places=9)
        self.assertAlmostEqual(polynomial.parameters["c"], 4.0, places=9)

        x_log = np.linspace(0.2, 8.0, 40)
        y_log = 1.75 * np.log(x_log) - 0.4
        logarithmic = fit_xy_values(
            x_log,
            y_log,
            default_fit_spec("log", "logarithmic"),
        )
        self.assertTrue(logarithmic.success, logarithmic.message)
        self.assertAlmostEqual(logarithmic.parameters["slope"], 1.75, places=7)
        self.assertAlmostEqual(logarithmic.parameters["intercept"], -0.4, places=7)

    def test_large_x_offset_polynomials_report_raw_coefficients_but_draw_stably(self):
        base = 1e9
        x = base + np.arange(-50.0, 51.0)
        cases = (
            (
                "linear",
                (2.5, -1.25),
            ),
            (
                "polynomial2",
                (3.0, -2.0, 4.0),
            ),
            (
                "polynomial3",
                (0.01, 3.0, 2.0, 1.0),
            ),
            (
                "polynomial4",
                (1e-5, -0.001, 0.02, 1.5, -2.0),
            ),
            (
                "polynomial5",
                (1e-7, -2e-6, 3e-4, -0.01, 0.75, 3.0),
            ),
        )

        for model_id, centered_coefficients in cases:
            with self.subTest(model_id=model_id):
                z = x - base
                y = np.polyval(centered_coefficients, z)
                spec = default_fit_spec(model_id, model_id)
                spec.x_origin = 0.0
                result = fit_xy_values(
                    x,
                    y,
                    spec,
                )

                self.assertTrue(result.success, result.message)
                self.assertEqual(result.x_origin, base)
                self.assertIn("x", result.equation)
                self.assertNotIn("z", result.equation)
                self.assertNotIn("x0", result.equation)
                raw_expected = np.poly1d(centered_coefficients)(
                    np.poly1d([1.0, -base])
                ).c
                raw_actual = np.asarray(tuple(result.parameters.values()))
                np.testing.assert_allclose(
                    raw_actual,
                    raw_expected,
                    rtol=5e-13,
                    atol=1e-12,
                )
                self.assertLess(float(result.rmse), 1e-10)
                self.assertAlmostEqual(float(result.r_squared), 1.0, places=12)

                z_curve = np.asarray(result.curve_x) - float(result.x_origin)
                np.testing.assert_allclose(
                    result.curve_y,
                    np.polyval(centered_coefficients, z_curve),
                    rtol=0.0,
                    atol=1e-8,
                )
                if model_id != "linear":
                    self.assertTrue(
                        any("ill-conditioned" in warning for warning in result.warnings)
                    )
                    self.assertFalse(result.equation_display_reliable)
                else:
                    self.assertTrue(result.equation_display_reliable)

    def test_raw_coefficient_warning_checks_between_irregular_data_points(self):
        base = 1e5
        offsets = np.asarray([-50.0, -49.0, 1.0, 50.0])
        x = base + offsets
        centered_coefficients = (0.001, 0.02, 0.5, 3.0)
        y = np.polyval(centered_coefficients, offsets)

        result = fit_xy_values(x, y, default_fit_spec("irregular", "polynomial3"))

        self.assertTrue(result.success, result.message)
        self.assertLess(float(result.rmse), 1e-10)
        self.assertTrue(
            any("ill-conditioned" in warning for warning in result.warnings)
        )
        self.assertFalse(result.equation_display_reliable)
        raw_curve = np.polyval(
            tuple(result.parameters.values()),
            np.asarray(result.curve_x),
        )
        self.assertGreater(
            float(np.max(np.abs(raw_curve - np.asarray(result.curve_y)))),
            1e-8,
        )

    def test_saved_polynomial_origin_is_replaced_by_current_stable_midpoint(self):
        base = 1e9
        x = base + np.linspace(100.0, 200.0, 101)
        z = x - base
        y = 0.02 * z**2 - 3.0 * z + 7.0
        spec = default_fit_spec("moving", "polynomial2")
        spec.x_origin = 0.0

        result = fit_xy_values(x, y, spec)

        self.assertTrue(result.success, result.message)
        self.assertEqual(result.x_origin, base + 150.0)
        self.assertAlmostEqual(result.parameters["a"], 0.02, places=11)
        self.assertAlmostEqual(result.parameters["b"], -0.04 * base - 3.0, places=6)
        np.testing.assert_allclose(
            result.parameters["c"],
            0.02 * base**2 + 3.0 * base + 7.0,
            rtol=5e-15,
        )

    def test_polynomial_uncertainty_is_transformed_to_raw_x_units(self):
        base = 1e9
        z = np.linspace(-5.0, 5.0, 41)
        x = base + z
        noise = np.sin(np.arange(z.size)) * 0.05
        y = 1.75 * z + 3.0 + noise
        spec = default_fit_spec("uncertainty", "linear")
        spec.x_origin = base

        result = fit_xy_values(x, y, spec)

        self.assertTrue(result.success, result.message)
        matrix = np.column_stack((z, np.ones_like(z)))
        covariance = np.linalg.inv(matrix.T @ matrix) * (
            float(result.sse) / result.degrees_of_freedom
        )
        raw_transform = np.array([[1.0, 0.0], [-base, 1.0]])
        raw_covariance = raw_transform @ covariance @ raw_transform.T
        expected_errors = np.sqrt(np.diag(raw_covariance))
        estimates = {item.name: item for item in result.parameter_estimates}
        np.testing.assert_allclose(
            [
                estimates["slope"].standard_error,
                estimates["intercept"].standard_error,
            ],
            expected_errors,
            rtol=1e-11,
            atol=1e-14,
        )

        quadratic_x = np.linspace(10.0, 14.0, 51)
        quadratic_noise = np.cos(np.arange(quadratic_x.size)) * 0.02
        quadratic_y = (
            2.0 * quadratic_x**2
            - 3.0 * quadratic_x
            + 5.0
            + quadratic_noise
        )
        quadratic = fit_xy_values(
            quadratic_x,
            quadratic_y,
            default_fit_spec("quadratic-uncertainty", "polynomial2"),
        )
        self.assertTrue(quadratic.success, quadratic.message)
        raw_design = np.column_stack(
            (quadratic_x**2, quadratic_x, np.ones_like(quadratic_x))
        )
        raw_covariance = np.linalg.inv(raw_design.T @ raw_design) * (
            float(quadratic.sse) / quadratic.degrees_of_freedom
        )
        quadratic_estimates = {
            item.name: item for item in quadratic.parameter_estimates
        }
        np.testing.assert_allclose(
            [quadratic_estimates[name].standard_error for name in ("a", "b", "c")],
            np.sqrt(np.diag(raw_covariance)),
            rtol=2e-8,
            atol=1e-12,
        )

    def test_extreme_x_scale_raw_standard_error_does_not_underflow_to_zero(self):
        normalized_x = np.linspace(-1.0, 1.0, 41)
        x = normalized_x * 1e300
        noise = np.sin(np.arange(x.size)) * 0.01
        y = 2.0 * normalized_x + noise

        result = fit_xy_values(x, y, default_fit_spec("extreme-se", "linear"))

        self.assertTrue(result.success, result.message)
        slope = next(
            estimate
            for estimate in result.parameter_estimates
            if estimate.name == "slope"
        )
        self.assertIsNotNone(slope.standard_error)
        self.assertGreater(float(slope.standard_error), 0.0)
        normalized_design = np.column_stack(
            (normalized_x, np.ones_like(normalized_x))
        )
        normalized_covariance = np.linalg.inv(
            normalized_design.T @ normalized_design
        ) * (float(result.sse) / result.degrees_of_freedom)
        expected_slope_error = math.sqrt(normalized_covariance[0, 0]) / 1e300
        self.assertAlmostEqual(
            float(slope.standard_error) / expected_slope_error,
            1.0,
            places=10,
        )

        extreme_grid = fit_xy_values(
            np.asarray([-1e308, 0.0, 1e308]),
            np.asarray([-1.0, 0.0, 1.0]),
            default_fit_spec("extreme-grid", "linear"),
        )
        self.assertTrue(extreme_grid.success, extreme_grid.message)
        self.assertEqual(len(extreme_grid.curve_x), 400)
        self.assertTrue(np.all(np.isfinite(extreme_grid.curve_x)))
        self.assertTrue(np.all(np.isfinite(extreme_grid.curve_y)))
        self.assertEqual(extreme_grid.curve_x[0], -1e308)
        self.assertEqual(extreme_grid.curve_x[-1], 1e308)

        constant_spec = default_fit_spec("extreme-custom-grid", "custom")
        constant_spec.expression = "level"
        constant_spec.parameters = [
            FitParameterSpec("level", 1.0, fixed=True),
        ]
        custom_grid = fit_xy_values(
            np.asarray([-1e308, 0.0, 1e308]),
            np.asarray([1.0, 1.0, 1.0]),
            constant_spec,
        )
        self.assertTrue(custom_grid.success, custom_grid.message)
        self.assertEqual(len(custom_grid.curve_x), 400)
        self.assertTrue(np.all(np.isfinite(custom_grid.curve_x)))
        self.assertTrue(np.all(np.isfinite(custom_grid.curve_y)))

        custom_spec = default_fit_spec("extreme-custom-grid", "custom")
        custom_spec.expression = "level"
        custom_spec.parameters = [
            FitParameterSpec("level", 0.0, fixed=True),
        ]
        custom_grid = fit_xy_values(
            np.asarray([-1e308, 0.0, 1e308]),
            np.zeros(3),
            custom_spec,
        )
        self.assertTrue(custom_grid.success, custom_grid.message)
        self.assertEqual(len(custom_grid.curve_x), 400)
        self.assertTrue(np.all(np.isfinite(custom_grid.curve_x)))
        self.assertTrue(np.all(np.isfinite(custom_grid.curve_y)))

    def test_gaussian_model_fits_known_curve(self):
        x = np.linspace(-4.0, 5.0, 90)
        gaussian_y = 0.7 + 3.2 * np.exp(-0.5 * ((x - 0.8) / 1.1) ** 2)
        gaussian = fit_xy_values(
            x,
            gaussian_y,
            default_fit_spec("peak", "gaussian"),
        )

        self.assertTrue(gaussian.success, gaussian.message)
        self.assertAlmostEqual(gaussian.parameters["baseline"], 0.7, places=5)
        self.assertAlmostEqual(gaussian.parameters["amplitude"], 3.2, places=5)
        self.assertAlmostEqual(gaussian.parameters["center"], 0.8, places=5)
        self.assertAlmostEqual(gaussian.parameters["sigma"], 1.1, places=5)

    def test_exponential_power_and_custom_models_fit_known_curves(self):
        x = np.linspace(0.2, 4.0, 50)
        exponential_y = 2.4 * np.exp(-0.65 * x) + 0.8
        exponential = fit_xy_values(
            x,
            exponential_y,
            default_fit_spec("decay", "exponential"),
        )
        self.assertTrue(exponential.success, exponential.message)
        self.assertAlmostEqual(exponential.parameters["amplitude"], 2.4, places=4)
        self.assertAlmostEqual(exponential.parameters["rate"], -0.65, places=4)
        self.assertAlmostEqual(exponential.parameters["offset"], 0.8, places=4)

        power_y = 1.7 * x**2.3
        power = fit_xy_values(x, power_y, default_fit_spec("power", "power"))
        self.assertTrue(power.success, power.message)
        self.assertAlmostEqual(power.parameters["amplitude"], 1.7, places=5)
        self.assertAlmostEqual(power.parameters["exponent"], 2.3, places=5)

        custom_spec = default_fit_spec("custom", "custom")
        custom_spec.expression = "y = a * exp(-k * x) + c"
        custom = fit_xy_values(x, exponential_y, custom_spec)
        self.assertTrue(custom.success, custom.message)
        self.assertAlmostEqual(custom.parameters["a"], 2.4, places=4)
        self.assertAlmostEqual(custom.parameters["k"], 0.65, places=4)
        self.assertAlmostEqual(custom.parameters["c"], 0.8, places=4)

    def test_custom_sum_and_integral_fits_are_order_and_curve_point_invariant(self):
        base_x = np.linspace(0.0, 3.5, 45)
        x = np.concatenate((base_x, base_x[[4, 17, 17, 31]]))
        order = np.random.default_rng(42).permutation(x.size)
        x = x[order]
        y = 0.3 + 2.2 * (1.0 - np.exp(-0.7 * x)) / 0.7

        integral_spec = default_fit_spec("integral", "custom")
        integral_spec.expression = (
            "offset + amplitude * integral(t, 0, x, exp(-rate * t), 64)"
        )
        low_resolution = fit_xy_values(x, y, integral_spec, curve_points=37)
        high_resolution = fit_xy_values(x, y, integral_spec, curve_points=913)
        sorted_result = fit_xy_values(
            np.sort(x),
            0.3 + 2.2 * (1.0 - np.exp(-0.7 * np.sort(x))) / 0.7,
            integral_spec,
            curve_points=211,
        )

        for result in (low_resolution, high_resolution, sorted_result):
            self.assertTrue(result.success, result.message)
            self.assertAlmostEqual(result.parameters["offset"], 0.3, places=6)
            self.assertAlmostEqual(result.parameters["amplitude"], 2.2, places=6)
            self.assertAlmostEqual(result.parameters["rate"], 0.7, places=6)
        for name in ("offset", "amplitude", "rate"):
            self.assertAlmostEqual(
                low_resolution.parameters[name],
                high_resolution.parameters[name],
                places=10,
            )
            self.assertAlmostEqual(
                low_resolution.parameters[name],
                sorted_result.parameters[name],
                places=8,
            )

        sum_x = np.linspace(0.05, 0.85, 50)
        summed_basis = sum(sum_x**index / index for index in range(1, 5))
        sum_y = -0.4 + 1.7 * summed_basis
        sum_spec = default_fit_spec("sum", "custom")
        sum_spec.expression = "offset + amplitude * ∑(k, 1, 4, x^k / k)"
        summed = fit_xy_values(sum_x, sum_y, sum_spec)

        self.assertTrue(summed.success, summed.message)
        self.assertAlmostEqual(summed.parameters["offset"], -0.4, places=7)
        self.assertAlmostEqual(summed.parameters["amplitude"], 1.7, places=7)

    def test_parameter_bounds_and_fixed_values_are_honored(self):
        x = np.linspace(0.0, 4.0, 25)
        y = 3.0 * x + 2.0
        spec = default_fit_spec("bounded", "linear")
        spec.parameters = [
            FitParameterSpec("slope", 1.0, lower=0.0, upper=2.0),
            FitParameterSpec("intercept", 2.0, fixed=True),
        ]

        result = fit_xy_values(x, y, spec)

        self.assertTrue(result.success, result.message)
        self.assertAlmostEqual(result.parameters["slope"], 2.0, places=7)
        self.assertEqual(result.parameters["intercept"], 2.0)
        estimates = {item.name: item for item in result.parameter_estimates}
        self.assertTrue(estimates["slope"].at_bound)
        self.assertIsNone(estimates["slope"].standard_error)
        self.assertIsNone(estimates["slope"].confidence_interval)
        self.assertTrue(estimates["intercept"].fixed)
        self.assertIsNone(estimates["intercept"].standard_error)
        self.assertTrue(
            any("uncertainty is unavailable" in warning for warning in result.warnings)
        )

        quadratic_x = np.linspace(10.0, 14.0, 41)
        quadratic_y = 2.0 * quadratic_x**2 - 3.0 * quadratic_x + 5.0
        quadratic_spec = default_fit_spec("bounded-quadratic", "polynomial2")
        quadratic_spec.parameters = [
            FitParameterSpec("a", 1.0, lower=0.0, upper=1.5),
            FitParameterSpec("b", -3.0),
            FitParameterSpec("c", 5.0),
        ]
        quadratic = fit_xy_values(quadratic_x, quadratic_y, quadratic_spec)
        self.assertTrue(quadratic.success, quadratic.message)
        self.assertAlmostEqual(quadratic.parameters["a"], 1.5, places=7)
        quadratic_a = next(
            item for item in quadratic.parameter_estimates if item.name == "a"
        )
        self.assertTrue(quadratic_a.at_bound)
        self.assertIsNone(quadratic_a.confidence_interval)

    def test_tiny_raw_bounds_use_data_scale_and_precise_bound_detection(self):
        x = np.linspace(-1.0, 1.0, 41)

        clipped_spec = default_fit_spec("tiny-clipped", "linear")
        clipped_spec.parameters = [
            FitParameterSpec("slope", 5e-10, lower=0.0, upper=1e-9),
            FitParameterSpec("intercept", 0.0, fixed=True),
        ]
        clipped = fit_xy_values(x, 1e-7 * x, clipped_spec)
        self.assertTrue(clipped.success, clipped.message)
        self.assertEqual(clipped.parameters["slope"], 1e-9)
        clipped_slope = next(
            item for item in clipped.parameter_estimates if item.name == "slope"
        )
        self.assertTrue(clipped_slope.at_bound)

        midpoint_spec = default_fit_spec("tiny-midpoint", "linear")
        midpoint_spec.parameters = [
            FitParameterSpec("slope", 5e-10, lower=0.0, upper=1e-9),
            FitParameterSpec("intercept", 0.0, fixed=True),
        ]
        midpoint = fit_xy_values(x, 5e-10 * x, midpoint_spec)
        self.assertTrue(midpoint.success, midpoint.message)
        self.assertAlmostEqual(midpoint.parameters["slope"], 5e-10, places=20)
        midpoint_slope = next(
            item for item in midpoint.parameter_estimates if item.name == "slope"
        )
        self.assertFalse(midpoint_slope.at_bound)

    def test_fixed_raw_polynomial_parameter_uses_ordinary_x_semantics(self):
        x = np.linspace(10.0, 14.0, 61)
        y = 3.0 * x**2 + 2.0 * x + 1.0
        spec = default_fit_spec("fixed-poly", "polynomial2")
        spec.parameters = [
            FitParameterSpec("a", 3.0, fixed=True),
            FitParameterSpec("b", 0.0),
            FitParameterSpec("c", 0.0),
        ]

        result = fit_xy_values(x, y, spec)

        self.assertTrue(result.success, result.message)
        self.assertEqual(result.parameters["a"], 3.0)
        self.assertAlmostEqual(result.parameters["b"], 2.0, places=9)
        self.assertAlmostEqual(result.parameters["c"], 1.0, places=8)
        np.testing.assert_allclose(
            result.curve_y,
            3.0 * np.asarray(result.curve_x) ** 2
            + 2.0 * np.asarray(result.curve_x)
            + 1.0,
            rtol=0.0,
            atol=1e-9,
        )
        fixed = next(item for item in result.parameter_estimates if item.name == "a")
        self.assertTrue(fixed.fixed)
        self.assertIsNone(fixed.standard_error)
        self.assertIsNone(fixed.confidence_interval)

    def test_all_fixed_raw_polynomial_curve_is_independent_of_observed_y(self):
        x = np.linspace(0.0, 4.0, 51)
        raw = np.asarray([1 / 6, 2 / 6, 3 / 6, 4 / 6, 5 / 6, 1.0])
        observed_values = (
            np.zeros_like(x),
            np.sin(x),
            np.full_like(x, 100.0),
            -np.sin(x),
        )
        results = []
        for case, y in enumerate(observed_values):
            spec = default_fit_spec(f"all-fixed-{case}", "polynomial5")
            spec.parameters = [
                FitParameterSpec(name, float(value), fixed=True)
                for name, value in zip(
                    FIT_MODEL_REGISTRY["polynomial5"].parameter_names,
                    raw,
                )
            ]
            results.append(fit_xy_values(x, y, spec))

        self.assertTrue(
            all(result.success for result in results),
            [result.message for result in results],
        )
        first_curve = results[0].curve_y
        for result in results:
            self.assertEqual(result.curve_y, first_curve)
            np.testing.assert_array_equal(
                tuple(result.parameters.values()),
                raw,
            )
        np.testing.assert_allclose(
            first_curve,
            np.polyval(raw, np.asarray(results[0].curve_x)),
            rtol=2e-14,
            atol=2e-14,
        )

    def test_partial_raw_fixed_parameters_are_stable_across_y_baselines(self):
        x = np.linspace(98.0, 102.0, 81)
        base_y = 0.1 * x**2 + 0.1 * x + 1.0
        raw_design = np.column_stack((x**2, x))
        for baseline in (-1e6, -100.0, 0.0, 100.0, 1e6):
            with self.subTest(baseline=baseline):
                y = base_y + baseline
                spec = default_fit_spec(f"fixed-c-{baseline}", "polynomial2")
                spec.parameters = [
                    FitParameterSpec("a", 0.0),
                    FitParameterSpec("b", 0.0),
                    FitParameterSpec("c", 1.0, fixed=True),
                ]
                result = fit_xy_values(x, y, spec)
                expected = np.linalg.lstsq(raw_design, y - 1.0, rcond=None)[0]

                self.assertTrue(result.success, result.message)
                self.assertEqual(result.parameters["c"], 1.0)
                np.testing.assert_allclose(
                    [result.parameters["a"], result.parameters["b"]],
                    expected,
                    rtol=2e-11,
                    atol=2e-11,
                )

        linear_x = np.linspace(998.0, 1002.0, 81)
        linear_y = 2.5 * linear_x + 1.0 + 1e6
        linear_spec = default_fit_spec("fixed-intercept", "linear")
        linear_spec.parameters = [
            FitParameterSpec("slope", 0.0),
            FitParameterSpec("intercept", 1.0, fixed=True),
        ]
        linear = fit_xy_values(linear_x, linear_y, linear_spec)
        expected_slope = float(
            np.dot(linear_x, linear_y - 1.0) / np.dot(linear_x, linear_x)
        )
        self.assertTrue(linear.success, linear.message)
        self.assertEqual(linear.parameters["intercept"], 1.0)
        self.assertAlmostEqual(linear.parameters["slope"], expected_slope, places=11)

    def test_large_y_baseline_does_not_turn_distinct_objectives_into_a_tie(self):
        x = np.linspace(998.0, 1002.0, 81)
        y = 1e9 * x + 10.0
        bounded_spec = default_fit_spec("large-objective", "linear")
        bounded_spec.parameters = [
            FitParameterSpec("slope", 1e9),
            FitParameterSpec("intercept", 0.5, lower=0.0, upper=1.0),
        ]

        bounded = fit_xy_values(x, y, bounded_spec)
        fixed_results = []
        for intercept in (0.0, 1.0):
            fixed_spec = default_fit_spec(f"fixed-{intercept}", "linear")
            fixed_spec.parameters = [
                FitParameterSpec("slope", 1e9),
                FitParameterSpec("intercept", intercept, fixed=True),
            ]
            fixed_results.append(fit_xy_values(x, y, fixed_spec))

        self.assertTrue(bounded.success, bounded.message)
        self.assertTrue(all(result.success for result in fixed_results))
        self.assertEqual(bounded.parameters["intercept"], 1.0)
        self.assertLess(float(fixed_results[1].sse), float(fixed_results[0].sse))
        self.assertAlmostEqual(
            float(bounded.sse),
            float(fixed_results[1].sse),
            places=12,
        )

    def test_active_set_matches_raw_box_least_squares_optimum(self):
        from scipy.optimize import lsq_linear

        x = np.linspace(-3.0, 4.0, 60)
        y = np.full(x.shape, 100.0)
        lower = np.asarray([-0.7319211, -1.05601888, -1.53718275, -1.64838401])
        upper = np.asarray([1.87725993, 0.53040244, 1.77115833, 0.10337892])
        initial = (lower + upper) / 2.0
        spec = default_fit_spec("box-optimum", "polynomial3")
        spec.parameters = [
            FitParameterSpec(name, value, lower=low, upper=high)
            for name, value, low, high in zip(
                FIT_MODEL_REGISTRY["polynomial3"].parameter_names,
                initial,
                lower,
                upper,
            )
        ]

        result = fit_xy_values(x, y, spec)
        raw_design = np.vander(x, 4)
        reference = lsq_linear(raw_design, y, bounds=(lower, upper))
        reference_sse = float(np.sum((raw_design @ reference.x - y) ** 2))

        self.assertTrue(result.success, result.message)
        np.testing.assert_allclose(
            tuple(result.parameters.values()),
            reference.x,
            rtol=2e-10,
            atol=2e-10,
        )
        self.assertAlmostEqual(float(result.sse) / reference_sse, 1.0, places=11)
        self.assertLess(result.parameters["a"], upper[0] - 0.1)

    def test_zero_bound_solution_is_order_invariant_and_marked_at_bound(self):
        x = np.asarray([-1.9, -1.3, -0.7, -0.1, 0.2, 0.8, 1.7])
        for degree in range(1, 6):
            model_id = "linear" if degree == 1 else f"polynomial{degree}"
            names = FIT_MODEL_REGISTRY[model_id].parameter_names
            results = []
            for order in (np.arange(x.size), np.arange(x.size - 1, -1, -1)):
                spec = default_fit_spec(f"zero-bound-{degree}", model_id)
                spec.parameters = [
                    *[
                        FitParameterSpec(name, 0.0, fixed=True)
                        for name in names[:-2]
                    ],
                    FitParameterSpec(names[-2], 1.0),
                    FitParameterSpec(names[-1], -1.0, upper=0.0),
                ]
                results.append(fit_xy_values(x[order], x[order], spec))

            with self.subTest(model_id=model_id):
                self.assertTrue(
                    all(result.success for result in results),
                    [result.message for result in results],
                )
                for result in results:
                    self.assertAlmostEqual(result.parameters[names[-2]], 1.0, places=14)
                    self.assertEqual(result.parameters[names[-1]], 0.0)
                    intercept = next(
                        estimate
                        for estimate in result.parameter_estimates
                        if estimate.name == names[-1]
                    )
                    self.assertTrue(intercept.at_bound)
                np.testing.assert_allclose(
                    results[0].curve_y,
                    results[1].curve_y,
                    rtol=0.0,
                    atol=2e-15,
                )

        interior_spec = default_fit_spec("small-interior", "linear")
        interior_spec.parameters = [
            FitParameterSpec("slope", 1.0),
            FitParameterSpec("intercept", 5e-10, lower=0.0, upper=1e-9),
        ]
        interior_x = np.linspace(-2.0, 2.0, 21)
        interior = fit_xy_values(
            interior_x,
            interior_x + 1e-13,
            interior_spec,
        )
        self.assertTrue(interior.success, interior.message)
        self.assertGreater(interior.parameters["intercept"], 5e-14)
        self.assertFalse(
            next(
                estimate
                for estimate in interior.parameter_estimates
                if estimate.name == "intercept"
            ).at_bound
        )

        lower_spec = default_fit_spec("zero-lower", "linear")
        lower_spec.parameters = [
            FitParameterSpec("slope", 1.0),
            FitParameterSpec("intercept", 5e-10, lower=0.0, upper=1e-9),
        ]
        lower = fit_xy_values(interior_x, interior_x, lower_spec)
        self.assertTrue(lower.success, lower.message)
        self.assertEqual(lower.parameters["intercept"], 0.0)
        self.assertTrue(
            next(
                estimate
                for estimate in lower.parameter_estimates
                if estimate.name == "intercept"
            ).at_bound
        )

        near_centered_x = np.linspace(-2.0, 2.0, 12) + 1e-3
        for degree in range(3, 6):
            model_id = f"polynomial{degree}"
            names = FIT_MODEL_REGISTRY[model_id].parameter_names
            spec = default_fit_spec(f"near-centered-{degree}", model_id)
            spec.parameters = [
                FitParameterSpec(
                    name,
                    0.0,
                    fixed=(index == len(names) - 1),
                )
                for index, name in enumerate(names)
            ]
            result = fit_xy_values(near_centered_x, near_centered_x, spec)
            with self.subTest(near_centered_model=model_id):
                self.assertTrue(result.success, result.message)
                self.assertLess(float(result.rmse), 1e-12)

    def test_ill_conditioned_large_x_raw_constraint_fails_clearly(self):
        base = 1e9
        x = base + np.linspace(-20.0, 20.0, 61)
        z = x - base
        y = 3.0 * z**2 + 2.0 * z + 1.0
        spec = default_fit_spec("ill-conditioned-fixed", "polynomial2")
        spec.x_origin = base
        spec.parameters = [
            FitParameterSpec("a", 0.0),
            FitParameterSpec("b", 0.0),
            FitParameterSpec("c", 1.0, fixed=True),
        ]

        result = fit_xy_values(x, y, spec)

        self.assertFalse(result.success)
        self.assertIn("too ill-conditioned", result.message)

        for width in (1e100, 1e300):
            with self.subTest(wide_inactive_bound=width):
                wide_spec = default_fit_spec(f"wide-{width}", "polynomial2")
                wide_spec.parameters = [
                    FitParameterSpec("a", 0.0),
                    FitParameterSpec("b", 0.0),
                    FitParameterSpec("c", 0.0, lower=-width, upper=width),
                ]
                wide = fit_xy_values(x, y, wide_spec)
                self.assertTrue(wide.success, wide.message)
                self.assertLess(float(wide.rmse), 1e-10)

    def test_high_degree_offset_raw_bounds_do_not_depend_on_feasible_initial(self):
        base = 1e6
        x = base + np.linspace(-50.0, 50.0, 81)
        for degree in range(2, 6):
            model_id = f"polynomial{degree}"
            y = ((x - base) / 50.0) ** degree
            results = []
            for initial in (-0.5, 0.5):
                spec = default_fit_spec(f"{model_id}-{initial}", model_id)
                leading_name = FIT_MODEL_REGISTRY[model_id].parameter_names[0]
                spec.parameters = [
                    FitParameterSpec(
                        leading_name,
                        initial,
                        lower=-1.0,
                        upper=1.0,
                    )
                ]
                results.append(fit_xy_values(x, y, spec))

            with self.subTest(model_id=model_id):
                self.assertTrue(
                    all(result.success for result in results),
                    [result.message for result in results],
                )
                self.assertLess(float(results[0].rmse), 1e-12)
                self.assertLess(float(results[1].rmse), 1e-12)
                np.testing.assert_allclose(
                    results[0].curve_y,
                    results[1].curve_y,
                    rtol=0.0,
                    atol=0.0,
                )

    def test_statistics_keep_large_baseline_variation_and_reject_out_of_range(self):
        x = np.arange(64.0)
        y = 1e12 + 0.001 * x
        result = fit_xy_values(x, y, default_fit_spec("large-baseline", "linear"))

        self.assertTrue(result.success, result.message)
        self.assertIsNotNone(result.r_squared)
        self.assertGreater(float(result.r_squared), 0.999)
        self.assertTrue(np.isfinite(result.rmse))

        for magnitude in (1e200, 1e-200):
            with self.subTest(magnitude=magnitude):
                extreme = default_fit_spec("extreme", "custom")
                extreme.expression = "level"
                extreme.parameters = [FitParameterSpec("level", 0.0, fixed=True)]
                failed = fit_xy_values(
                    [0.0, 1.0],
                    [magnitude, -magnitude],
                    extreme,
                )
                self.assertFalse(failed.success)
                self.assertIn("numeric range", failed.message)
                self.assertIsNone(failed.sse)
                self.assertIsNone(failed.rmse)

    def test_exact_large_constant_only_makes_r_squared_undefined(self):
        spec = default_fit_spec("constant", "custom")
        spec.expression = "level"
        spec.parameters = [FitParameterSpec("level", 1e200, fixed=True)]

        result = fit_xy_values([0.0, 1.0, 2.0], [1e200] * 3, spec)

        self.assertTrue(result.success, result.message)
        self.assertEqual(result.sse, 0.0)
        self.assertEqual(result.rmse, 0.0)
        self.assertIsNone(result.r_squared)
        self.assertIn("all Y values are equal", " ".join(result.warnings))

    def test_rank_deficient_polynomial_reports_clear_failure(self):
        base = 1e9
        result = fit_xy_values(
            [base] * 4,
            [1.0, 2.0, 3.0, 4.0],
            default_fit_spec("rank", "polynomial2"),
        )

        self.assertFalse(result.success)
        self.assertIn("cannot be determined uniquely", result.message)

    def test_initial_parameter_helper_is_data_aware(self):
        x = np.linspace(-2.0, 2.0, 10)
        y = 4.0 * x - 3.0

        parameters = initial_fit_parameters(
            x,
            y,
            default_fit_spec("series", "linear"),
        )

        self.assertAlmostEqual(parameters[0].initial, 4.0, places=10)
        self.assertAlmostEqual(parameters[1].initial, -3.0, places=10)

        base = 1e9
        large_x = base + np.linspace(-10.0, 10.0, 31)
        large_y = 2.5 * (large_x - base) - 1.25
        large_parameters = initial_fit_parameters(
            large_x,
            large_y,
            default_fit_spec("large-series", "linear"),
        )
        self.assertAlmostEqual(large_parameters[0].initial, 2.5, places=10)
        self.assertAlmostEqual(
            large_parameters[1].initial,
            -2.5 * base - 1.25,
            places=4,
        )

    def test_ill_conditioned_all_fixed_raw_curve_does_not_depend_on_observed_y(self):
        base = 1e9
        x = base + np.linspace(-20.0, 20.0, 61)
        centered_coefficients = (1e-7, -2e-6, 3e-4, -0.01, 0.75, 3.0)
        y = np.polyval(centered_coefficients, x - base)
        spec = default_fit_spec("preview", "polynomial5")
        spec.parameters = [
            FitParameterSpec(
                parameter.name,
                parameter.initial,
                fixed=True,
            )
            for parameter in initial_fit_parameters(x, y, spec)
        ]

        first = fit_xy_values(x, y, spec)
        second = fit_xy_values(x, y + 12345.0, spec)

        self.assertFalse(first.success)
        self.assertFalse(second.success)
        self.assertIn("too ill-conditioned", first.message)
        self.assertIn("too ill-conditioned", second.message)

    def test_invalid_data_point_count_domain_and_bounds_return_failures(self):
        too_few = fit_xy_values(
            [0.0, 1.0, 2.0],
            [1.0, 2.0, 3.0],
            default_fit_spec("few", "polynomial3"),
        )
        self.assertFalse(too_few.success)
        self.assertIn("Not enough data", too_few.message)

        invalid_domain = fit_xy_values(
            [-1.0, 1.0, 2.0],
            [1.0, 2.0, 3.0],
            default_fit_spec("domain", "logarithmic"),
        )
        self.assertFalse(invalid_domain.success)
        self.assertIn("greater than zero", invalid_domain.message)

        invalid_bounds_spec = default_fit_spec("bounds", "linear")
        invalid_bounds_spec.parameters = [
            FitParameterSpec("slope", 1.0, lower=3.0, upper=2.0)
        ]
        invalid_bounds = fit_xy_values(
            [0.0, 1.0, 2.0],
            [0.0, 1.0, 2.0],
            invalid_bounds_spec,
        )
        self.assertFalse(invalid_bounds.success)
        self.assertIn("lower bound", invalid_bounds.message)

        nonfinite = fit_xy_values(
            [0.0, np.nan, 2.0],
            [0.0, 1.0, 2.0],
            default_fit_spec("nan", "linear"),
        )
        self.assertFalse(nonfinite.success)
        self.assertIn("NaN", nonfinite.message)

    def test_custom_parse_and_initial_domain_errors_return_results_not_exceptions(self):
        unsafe = default_fit_spec("unsafe", "custom")
        unsafe.expression = "__import__('os').getcwd()"
        unsafe_result = fit_xy_values([1.0, 2.0], [1.0, 2.0], unsafe)
        self.assertFalse(unsafe_result.success)

        undefined = default_fit_spec("undefined", "custom")
        undefined.expression = "sqrt(x - shift)"
        undefined.parameters = [FitParameterSpec("shift", 10.0)]
        undefined_result = fit_xy_values([1.0, 2.0], [1.0, 2.0], undefined)
        self.assertFalse(undefined_result.success)
        self.assertIn("undefined", undefined_result.message)

    def test_duplicate_and_unused_parameter_definitions_fail_cleanly(self):
        spec = default_fit_spec("bad-parameters", "linear")
        spec.parameters = [
            FitParameterSpec("slope", 1.0),
            FitParameterSpec("slope", 2.0),
        ]
        duplicate = fit_xy_values([0.0, 1.0], [0.0, 1.0], spec)
        self.assertFalse(duplicate.success)
        self.assertIn("more than once", duplicate.message)

        spec.parameters = [FitParameterSpec("unused", 1.0)]
        unused = fit_xy_values([0.0, 1.0], [0.0, 1.0], spec)
        self.assertFalse(unused.success)
        self.assertIn("not used", unused.message)


if __name__ == "__main__":
    __import__("unittest").main()
