from __future__ import annotations

import json
import math
import pathlib
import tempfile
from dataclasses import asdict

import pandas as pd
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.colors import to_rgba
from matplotlib.figure import Figure
from matplotlib.ticker import MultipleLocator

from tests.easygraph_case import EasyGraphQtTestCase, EasyGraphTestCase
from easygraph import additional_guides, project_io, template_io
from easygraph.plotting.additional_guides import draw_additional_guides
from easygraph.settings import ChartSettings, STYLE_TEMPLATE_CONTENT_FIELDS
from easygraph.xy_series import XYSeriesSpec, XYSettings


class AdditionalGuideModelTests(EasyGraphTestCase):
    def test_module_api_and_default_record_are_stable(self):
        self.assertEqual(
            additional_guides.__all__,
            [
                "MAX_ADDITIONAL_GUIDES",
                "ADDITIONAL_GUIDE_TEXT_SIDES",
                "ADDITIONAL_GUIDE_VERTICAL_POSITIONS",
                "ADDITIONAL_GUIDE_TEXT_COLOR_MODES",
                "default_additional_guide",
                "normalize_additional_guide",
                "normalize_additional_guides",
                "limit_additional_guide_text",
                "format_additional_guide_value",
            ],
        )
        self.assertEqual(
            additional_guides.default_additional_guide(2.5),
            {
                "value": 2.5,
                "color_index": 0,
                "text_color_mode": "auto",
                "show_tick": True,
                "show_value_with_text": False,
                "show_line": False,
                "text": "",
                "show_label_background": False,
                "text_side": "left",
                "vertical_position": "aligned",
            },
        )
        self.assertEqual(
            additional_guides.ADDITIONAL_GUIDE_TEXT_SIDES,
            ("left", "center", "right", "plot_left", "plot_right"),
        )
        self.assertEqual(
            additional_guides.ADDITIONAL_GUIDE_VERTICAL_POSITIONS,
            ("aligned", "above", "below", "plot_bottom", "plot_top"),
        )

    def test_normalization_limits_count_text_values_and_enum_fields(self):
        guides = additional_guides.normalize_additional_guides(
            [
                {
                    "value": float("nan"),
                    "show_tick": "false",
                    "show_line": "yes",
                    "text": "first\r\nsecond\nignored",
                    "show_label_background": "yes",
                    "text_side": "elsewhere",
                    "vertical_position": "UP",
                }
            ]
            * 40
        )

        self.assertEqual(len(guides), additional_guides.MAX_ADDITIONAL_GUIDES)
        self.assertEqual(
            guides[0],
            {
                "value": 0.0,
                "color_index": 0,
                "text_color_mode": "auto",
                "show_tick": False,
                "show_value_with_text": False,
                "show_line": True,
                "text": "first\nsecond",
                "show_label_background": True,
                "text_side": "left",
                "vertical_position": "aligned",
            },
        )
        self.assertEqual(additional_guides.format_additional_guide_value(-0.0), "0")
        self.assertEqual(additional_guides.format_additional_guide_value(12.5), "12.5")
        self.assertEqual(
            additional_guides.normalize_additional_guide(
                {"text_side": "CENTER"}
            )["text_side"],
            "center",
        )
        self.assertEqual(
            additional_guides.normalize_additional_guide(
                {"text_color_mode": " MATCH_LINE "}
            )["text_color_mode"],
            "match_line",
        )
        self.assertEqual(
            additional_guides.normalize_additional_guide(
                {"text_color_mode": "invalid"}
            )["text_color_mode"],
            "auto",
        )
        edge_aligned = additional_guides.normalize_additional_guide(
            {
                "text_side": " PLOT_RIGHT ",
                "vertical_position": "PLOT_TOP",
            }
        )
        self.assertEqual(edge_aligned["text_side"], "plot_right")
        self.assertEqual(edge_aligned["vertical_position"], "plot_top")

    def test_chart_settings_normalize_guides_and_clamp_font_size(self):
        settings = ChartSettings(
            additional_x_axis_guides=[
                {
                    "value": "3.25",
                    "show_tick": 0,
                    "show_line": 1,
                    "text": "one\ntwo\nthree",
                    "show_label_background": 1,
                    "text_side": "RIGHT",
                    "vertical_position": "BELOW",
                }
            ],
            additional_primary_axis_guides="invalid",
            additional_guide_font_size=200,
            additional_guide_line_width=200,
        )

        self.assertEqual(settings.additional_guide_font_size, 36)
        self.assertEqual(settings.additional_guide_line_width, 5.0)
        self.assertEqual(settings.additional_primary_axis_guides, [])
        self.assertEqual(
            settings.additional_x_axis_guides[0],
            {
                "value": 3.25,
                "color_index": 0,
                "text_color_mode": "auto",
                "show_tick": False,
                "show_value_with_text": False,
                "show_line": True,
                "text": "one\ntwo",
                "show_label_background": True,
                "text_side": "right",
                "vertical_position": "below",
            },
        )

    def test_project_roundtrip_preserves_normalized_guides(self):
        settings = ChartSettings(
            additional_guide_palette="Presentation",
            additional_x_axis_guides=[
                {
                    **additional_guides.default_additional_guide(2.5),
                    "color_index": 2,
                    "vertical_position": "plot_top",
                }
            ],
            additional_primary_axis_guides=[
                {
                    **additional_guides.default_additional_guide(-1),
                    "show_line": True,
                    "text": "threshold",
                    "show_value_with_text": True,
                    "show_label_background": True,
                    "color_index": 4,
                    "text_color_mode": "match_line",
                    "text_side": "plot_right",
                }
            ],
            additional_guide_font_size=13,
            additional_guide_line_width=2.4,
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "guides.eg"
            project_io.write_project(path, self.df, settings)
            _, loaded = project_io.read_project(path)

        self.assertEqual(asdict(loaded), asdict(settings))

        legacy_loaded = project_io.chart_settings_from_dict(
            {
                "additional_primary_axis_guides": [
                    {
                        "value": 2.0,
                        "show_tick": True,
                        "show_line": True,
                    }
                ]
            }
        )
        self.assertEqual(
            legacy_loaded.additional_primary_axis_guides[0][
                "text_color_mode"
            ],
            "auto",
        )

    def test_guide_palette_and_color_slots_are_normalized_and_shared(self):
        from easygraph.palette import (
            additional_guide_color,
            additional_guide_palette_colors,
        )

        settings = ChartSettings(
            additional_guide_palette="Presentation",
            additional_x_axis_guides=[
                {**additional_guides.default_additional_guide(1), "color_index": 2}
            ],
            additional_primary_axis_guides=[
                {**additional_guides.default_additional_guide(2), "color_index": 4}
            ],
        )
        palette = additional_guide_palette_colors(settings)

        self.assertEqual(len(palette), 10)

        self.assertEqual(
            additional_guide_color(settings, settings.additional_x_axis_guides[0]),
            palette[2],
        )
        self.assertEqual(
            additional_guide_color(
                settings,
                settings.additional_primary_axis_guides[0],
            ),
            palette[4],
        )
        self.assertEqual(
            ChartSettings(additional_guide_palette="missing").additional_guide_palette,
            "Mono Print",
        )
        self.assertEqual(
            additional_guides.normalize_additional_guide(
                {"color_index": 999}
            )["color_index"],
            additional_guides.MAX_ADDITIONAL_GUIDES * 2 - 1,
        )

        settings.additional_guide_palette = "Viridis"
        from easygraph.palette import palette_choices_for_group_count

        self.assertEqual(
            additional_guide_palette_colors(settings),
            palette_choices_for_group_count("Viridis", 2),
        )
        settings.additional_x_axis_guides.extend(
            {
                **additional_guides.default_additional_guide(value),
                "color_index": value,
            }
            for value in range(3, 16)
        )
        self.assertEqual(
            additional_guide_palette_colors(settings),
            palette_choices_for_group_count("Viridis", 15),
        )

    def test_guides_are_content_but_font_size_is_common_template_style(self):
        settings = ChartSettings(
            additional_guide_palette="Dark Slide",
            additional_x_axis_guides=[
                additional_guides.default_additional_guide(2.5)
            ],
            additional_primary_axis_guides=[
                additional_guides.default_additional_guide(7.5)
            ],
            additional_guide_font_size=17,
            additional_guide_line_width=2.6,
        )
        self.assertIn("additional_x_axis_guides", STYLE_TEMPLATE_CONTENT_FIELDS)
        self.assertIn("additional_primary_axis_guides", STYLE_TEMPLATE_CONTENT_FIELDS)

        with tempfile.TemporaryDirectory() as tmp:
            path = template_io.write_style_template(
                "Guides",
                settings,
                pathlib.Path(tmp),
            )
            payload = json.loads(path.read_text(encoding="utf-8"))
            loaded = template_io.read_style_template_file(path)

        self.assertEqual(payload["common"]["additional_guide_font_size"], 17)
        self.assertEqual(payload["common"]["additional_guide_line_width"], 2.6)
        self.assertEqual(
            payload["common"]["additional_guide_palette"],
            "Dark Slide",
        )
        self.assertNotIn("additional_x_axis_guides", payload["variants"]["groups"])
        self.assertNotIn(
            "additional_primary_axis_guides",
            payload["variants"]["groups"],
        )
        self.assertEqual(loaded.additional_guide_font_size, 17)
        self.assertEqual(loaded.additional_guide_line_width, 2.6)
        self.assertEqual(loaded.additional_x_axis_guides, [])
        self.assertEqual(loaded.additional_primary_axis_guides, [])


class AdditionalGuidePlottingTests(EasyGraphTestCase):
    @staticmethod
    def _axes():
        figure = Figure()
        FigureCanvasAgg(figure)
        axes = figure.subplots()
        axes.set_xlim(0.0, 10.0)
        axes.set_ylim(0.0, 10.0)
        return figure, axes

    @staticmethod
    def _guide_visual_bounds(label, renderer):
        patch = label.get_bbox_patch()
        if patch is None:
            return label.get_window_extent(renderer)
        label.update_bbox_position_size(renderer)
        return patch.get_window_extent(renderer)

    def test_draws_independent_artists_without_changing_limits_or_locator(self):
        figure, axes = self._axes()
        locator = axes.yaxis.get_major_locator()
        limits = (axes.get_xlim(), axes.get_ylim())
        artists = draw_additional_guides(
            axes,
            [
                {
                    **additional_guides.default_additional_guide(2.5),
                    "show_line": True,
                    "text": "first\nsecond",
                    "show_label_background": True,
                    "text_side": "right",
                    "vertical_position": "above",
                }
            ],
            dimension="y",
            side="left",
            font_size=15,
            text_color="#222222",
            grid_color="#D1D5DB",
            guide_line_width=2.4,
            label_facecolor="#FFFFFF",
        )

        self.assertEqual(
            [artist.get_gid() for artist in artists],
            [
                "additional-grid-line",
                "additional-tick",
                "additional-tick-label",
            ],
        )
        self.assertEqual(artists[-1].get_text(), "first\nsecond")
        self.assertEqual(artists[-1].get_fontsize(), 15)
        self.assertEqual(artists[0].get_linestyle(), "--")
        self.assertEqual(artists[0].get_linewidth(), 2.4)
        data_line, = axes.plot([0.0, 10.0], [1.0, 9.0])
        self.assertGreater(artists[0].get_zorder(), axes.yaxis.get_zorder())
        self.assertLess(artists[0].get_zorder(), data_line.get_zorder())
        label_background = artists[-1].get_bbox_patch()
        self.assertIsNotNone(label_background)
        self.assertEqual(label_background.get_facecolor(), to_rgba("#FFFFFF", 0.75))
        self.assertEqual(label_background.get_edgecolor()[3], 0.0)
        self.assertEqual(label_background.get_linewidth(), 0.0)
        self.assertIs(axes.yaxis.get_major_locator(), locator)
        self.assertEqual((axes.get_xlim(), axes.get_ylim()), limits)
        figure.canvas.draw()

    def test_each_grid_line_uses_its_palette_color_and_keeps_row_identity(self):
        figure, axes = self._axes()
        colors = ["#d62728", "#1f77b4"]
        artists = draw_additional_guides(
            axes,
            [
                {
                    **additional_guides.default_additional_guide(value),
                    "show_line": True,
                    "color_index": index,
                }
                for index, value in enumerate((2.5, 7.5))
            ],
            dimension="y",
            side="left",
            font_size=10,
            text_color="#222222",
            grid_color="#cccccc",
            grid_colors=colors,
        )
        lines = [
            artist
            for artist in artists
            if artist.get_gid() == "additional-grid-line"
        ]

        self.assertEqual(
            [to_rgba(line.get_color()) for line in lines],
            [to_rgba(color) for color in colors],
        )
        self.assertEqual(
            [line._easygraph_additional_guide_index for line in lines],
            [0, 1],
        )

    def test_tick_and_custom_text_can_follow_each_guide_line_color(self):
        _, axes = self._axes()
        artists = draw_additional_guides(
            axes,
            [
                {
                    **additional_guides.default_additional_guide(value),
                    "show_value_with_text": True,
                    "text": label,
                    "text_color_mode": (
                        "match_line" if label == "Line" else "auto"
                    ),
                }
                for value, label in ((2.5, "Auto"), (7.5, "Line"))
            ],
            dimension="y",
            side="left",
            font_size=10,
            text_color="#222222",
            grid_color="#cccccc",
            grid_colors=["#d62728", "#1f77b4"],
        )

        custom_labels = {
            artist.get_text(): artist
            for artist in artists
            if artist.get_gid() == "additional-tick-label"
        }
        numeric_labels = {
            float(artist.get_text()): artist
            for artist in artists
            if artist.get_gid() == "additional-tick-value"
        }
        ticks = [
            artist
            for artist in artists
            if artist.get_gid() == "additional-tick"
        ]

        self.assertEqual(custom_labels["Auto"].get_color(), "#222222")
        self.assertEqual(custom_labels["Line"].get_color(), "#1f77b4")
        self.assertEqual(numeric_labels[2.5].get_color(), "#222222")
        self.assertEqual(numeric_labels[7.5].get_color(), "#1f77b4")
        self.assertTrue(all(tick.get_color() == "#222222" for tick in ticks))

    def test_palette_color_restyles_a_colliding_major_grid_line(self):
        figure, axes = self._axes()
        axes.grid(True)
        figure.canvas.draw()
        artists = draw_additional_guides(
            axes,
            [
                {
                    **additional_guides.default_additional_guide(2.0),
                    "show_line": True,
                }
            ],
            dimension="y",
            side="left",
            font_size=10,
            text_color="#222222",
            grid_color="#cccccc",
            grid_colors=["#9467bd"],
        )
        line = next(
            artist
            for artist in artists
            if artist.get_gid() == "additional-grid-line"
        )

        self.assertEqual(to_rgba(line.get_color()), to_rgba("#9467bd"))
        self.assertEqual(line._easygraph_additional_guide_index, 0)

    def test_major_tick_collision_preserves_tick_label_and_offsets_guide_text(self):
        figure, axes = self._axes()
        axes.grid(True)
        figure.canvas.draw()
        major_values = list(axes.yaxis.get_majorticklocs())
        collision_index = next(
            index for index, value in enumerate(major_values) if value == 2.0
        )
        major_gridline = axes.yaxis.get_major_ticks()[collision_index].gridline
        artists = draw_additional_guides(
            axes,
            [
                {
                    **additional_guides.default_additional_guide(2.0),
                    "show_line": True,
                    "text": "custom",
                    "show_value_with_text": True,
                    "text_color_mode": "match_line",
                }
            ],
            dimension="y",
            side="left",
            font_size=10,
            text_color="#222222",
            grid_color="#D1D5DB",
            grid_colors=["#9467bd"],
            guide_line_width=2.2,
        )

        self.assertEqual(
            [artist.get_gid() for artist in artists],
            ["additional-grid-line", "additional-tick-label"],
        )
        self.assertIs(artists[0], major_gridline)
        self.assertEqual(major_gridline.get_linestyle(), "--")
        self.assertEqual(major_gridline.get_linewidth(), 2.2)
        figure.canvas.draw()
        major_tick = axes.yaxis.get_major_ticks()[collision_index]
        self.assertTrue(major_tick.tick1line.get_visible())
        self.assertTrue(major_tick.label1.get_visible())
        self.assertEqual(major_tick.label1.get_color(), "#9467bd")
        self.assertEqual(artists[-1].get_color(), "#9467bd")
        renderer = figure.canvas.get_renderer()
        self.assertLess(
            artists[-1].get_window_extent(renderer).x1,
            major_tick.label1.get_window_extent(renderer).x0,
        )

    def test_x_major_tick_collision_keeps_number_clear_of_background_label(self):
        figure, axes = self._axes()
        figure.canvas.draw()
        major_values = list(axes.xaxis.get_majorticklocs())
        collision_index = next(
            index for index, value in enumerate(major_values) if value == 2.0
        )
        artists = draw_additional_guides(
            axes,
            [
                {
                    **additional_guides.default_additional_guide(2.0),
                    "text": "threshold",
                    "text_side": "right",
                    "vertical_position": "below",
                    "show_label_background": True,
                }
            ],
            dimension="x",
            side="bottom",
            font_size=12,
            text_color="#222222",
            grid_color="#D1D5DB",
        )

        figure.canvas.draw()
        major_tick = axes.xaxis.get_major_ticks()[collision_index]
        self.assertTrue(major_tick.tick1line.get_visible())
        self.assertTrue(major_tick.label1.get_visible())
        self.assertEqual(major_tick.label1.get_rotation(), 0)
        self.assertEqual(artists[-1].get_rotation(), 90)
        renderer = figure.canvas.get_renderer()
        guide_bounds = artists[-1].get_bbox_patch().get_window_extent(renderer)
        major_bounds = major_tick.label1.get_window_extent(renderer)
        self.assertGreater(guide_bounds.x0, major_bounds.x1)

    def test_x_generated_numeric_guide_label_stays_horizontal(self):
        figure, axes = self._axes()
        artists = draw_additional_guides(
            axes,
            [additional_guides.default_additional_guide(2.5)],
            dimension="x",
            side="bottom",
            font_size=12,
            text_color="#222222",
            grid_color="#D1D5DB",
        )

        label = next(
            artist
            for artist in artists
            if artist.get_gid() == "additional-tick-value"
        )
        self.assertEqual(label.get_text(), "2.5")
        self.assertEqual(label.get_rotation(), 0)
        figure.canvas.draw()

    def test_custom_text_can_also_show_axis_aligned_tick_value(self):
        for dimension in ("x", "y"):
            with self.subTest(dimension=dimension):
                figure, axes = self._axes()
                figure.canvas.draw()
                axis = axes.xaxis if dimension == "x" else axes.yaxis
                template_label = axis.get_major_ticks()[0].label1
                artists = draw_additional_guides(
                    axes,
                    [
                        {
                            **additional_guides.default_additional_guide(2.5),
                            "text": "custom",
                            "show_value_with_text": True,
                            "text_side": "right",
                            "vertical_position": "above",
                        }
                    ],
                    dimension=dimension,
                    side="bottom" if dimension == "x" else "left",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )

                figure.canvas.draw()
                value_label = next(
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-value"
                )
                custom_label = next(
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-label"
                )
                renderer = figure.canvas.get_renderer()
                value_bounds = value_label.get_window_extent(renderer)
                template_bounds = template_label.get_window_extent(renderer)
                self.assertEqual(
                    value_label.get_fontproperties(),
                    template_label.get_fontproperties(),
                )
                self.assertEqual(value_label.get_rotation(), 0)
                if dimension == "x":
                    self.assertAlmostEqual(
                        value_bounds.y1,
                        template_bounds.y1,
                        places=5,
                    )
                else:
                    self.assertAlmostEqual(
                        value_bounds.x1,
                        template_bounds.x1,
                        places=5,
                    )
                self.assertFalse(
                    custom_label.get_window_extent(renderer).overlaps(
                        value_bounds
                    )
                )

    def test_generated_numbers_follow_the_axis_offset_formatter(self):
        figure, axes = self._axes()
        axes.set_xlim(1_000_000_000.0, 1_000_000_010.0)
        figure.canvas.draw()
        artists = draw_additional_guides(
            axes,
            [
                additional_guides.default_additional_guide(1_000_000_004.9),
                additional_guides.default_additional_guide(1_000_000_005.1),
            ],
            dimension="x",
            side="bottom",
            font_size=12,
            text_color="#222222",
            grid_color="#D1D5DB",
        )

        figure.canvas.draw()
        labels = [
            artist.get_text()
            for artist in artists
            if artist.get_gid() == "additional-tick-value"
        ]
        self.assertEqual(labels, ["4.9", "5.1"])
        self.assertEqual(axes.xaxis.get_offset_text().get_text(), "+1e9")

    def test_generated_numbers_use_the_live_scalar_formatter_baseline(self):
        figure = Figure(figsize=(3.0, 2.0), dpi=72)
        FigureCanvasAgg(figure)
        axes = figure.subplots()
        lower = -0.010000037544273602
        upper = -0.009999787544273601
        value = -0.01000002106149708
        axes.set_xlim(lower, upper)
        figure.canvas.draw()
        formatter = axes.xaxis.get_major_formatter()
        live_offset = float(formatter.offset)
        live_order = int(formatter.orderOfMagnitude)
        offset_text = axes.xaxis.get_offset_text().get_text()

        artists = draw_additional_guides(
            axes,
            [additional_guides.default_additional_guide(value)],
            dimension="x",
            side="bottom",
            font_size=12,
            text_color="#222222",
            grid_color="#D1D5DB",
        )
        label = next(
            artist
            for artist in artists
            if artist.get_gid() == "additional-tick-value"
        )
        reconstructed = float(label.get_text()) * (10.0**live_order) + live_offset
        self.assertAlmostEqual(reconstructed, value, delta=(upper - lower) * 1e-9)
        self.assertEqual(axes.xaxis.get_offset_text().get_text(), offset_text)

    def test_close_generated_numbers_remain_distinguishable(self):
        figure, axes = self._axes()
        axes.set_xlim(0.0, 1.0)
        figure.canvas.draw()
        artists = draw_additional_guides(
            axes,
            [
                additional_guides.default_additional_guide(0.50001),
                additional_guides.default_additional_guide(0.50002),
            ],
            dimension="x",
            side="bottom",
            font_size=12,
            text_color="#222222",
            grid_color="#D1D5DB",
        )

        labels = [
            artist.get_text()
            for artist in artists
            if artist.get_gid() == "additional-tick-value"
        ]
        self.assertEqual(labels, ["0.50001", "0.50002"])

    def test_y_outer_wing_labels_reuse_space_around_the_native_tick(self):
        figure, axes = self._axes()
        figure.canvas.draw()
        values = (5.9, 5.95, 6.01, 6.08, 6.16)
        artists = draw_additional_guides(
            axes,
            [
                additional_guides.default_additional_guide(value)
                for value in values
            ],
            dimension="y",
            side="left",
            font_size=12,
            text_color="#222222",
            grid_color="#D1D5DB",
        )

        figure.canvas.draw()
        renderer = figure.canvas.get_renderer()
        label_bounds = {
            artist.get_text(): artist.get_window_extent(renderer)
            for artist in artists
            if artist.get_gid() == "additional-tick-value"
        }
        major_index = next(
            index
            for index, value in enumerate(axes.yaxis.get_majorticklocs())
            if value == 6.0
        )
        major_bounds = axes.yaxis.get_major_ticks()[
            major_index
        ].label1.get_window_extent(renderer)
        self.assertAlmostEqual(label_bounds["5.9"].x1, major_bounds.x1, delta=1.0)
        self.assertAlmostEqual(label_bounds["6.16"].x1, major_bounds.x1, delta=1.0)
        self.assertLess(label_bounds["5.9"].y1, major_bounds.y0)
        self.assertGreater(label_bounds["6.16"].y0, major_bounds.y1)

    def test_overlapping_numeric_ticks_move_to_lanes_with_diagonal_leaders(self):
        for dimension, values in (
            ("x", (1.9, 2.02, 2.145)),
            ("y", (5.9, 6.02, 6.145)),
        ):
            with self.subTest(dimension=dimension):
                figure, axes = self._axes()
                figure.canvas.draw()
                entry_colors = ["#d62728", "#2ca02c", "#1f77b4"]
                artists = draw_additional_guides(
                    axes,
                    [
                        {
                            **additional_guides.default_additional_guide(value),
                            "text_color_mode": "match_line",
                        }
                        for value in values
                    ],
                    dimension=dimension,
                    side="bottom" if dimension == "x" else "left",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                    grid_colors=entry_colors,
                )

                figure.canvas.draw()
                renderer = figure.canvas.get_renderer()
                labels = [
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-value"
                ]
                leaders = [
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-leader"
                ]
                self.assertEqual(len(labels), len(values))
                self.assertGreaterEqual(len(leaders), 1)
                self.assertEqual(
                    {to_rgba(label.get_color()) for label in labels},
                    {to_rgba(color) for color in entry_colors},
                )
                self.assertTrue(
                    all(
                        to_rgba(leader.get_edgecolor())[:3]
                        in {to_rgba(color)[:3] for color in entry_colors}
                        for leader in leaders
                    )
                )

                label_bounds = [
                    label.get_window_extent(renderer) for label in labels
                ]
                axis = axes.xaxis if dimension == "x" else axes.yaxis
                major_bounds = [
                    label.get_window_extent(renderer)
                    for label in axis.get_majorticklabels()
                    if label.get_visible() and label.get_text()
                ]
                for index, left in enumerate(label_bounds):
                    for right in label_bounds[index + 1 :]:
                        self.assertFalse(left.overlaps(right))
                    for major in major_bounds:
                        self.assertFalse(left.overlaps(major))

                perpendicular_centers = sorted(
                    (
                        (bounds.y0 + bounds.y1) / 2.0
                        if dimension == "x"
                        else bounds.x1
                    )
                    for bounds in label_bounds
                )
                compact_lanes: list[float] = []
                for center in perpendicular_centers:
                    if not any(abs(center - lane) <= 1.0 for lane in compact_lanes):
                        compact_lanes.append(center)
                self.assertEqual(len(compact_lanes), 2)

                transform = (
                    axes.get_xaxis_transform()
                    if dimension == "x"
                    else axes.get_yaxis_transform()
                )
                for label, bounds in zip(labels, label_bounds):
                    value = float(label.get_text())
                    anchor = transform.transform(
                        (value, 0.0)
                        if dimension == "x"
                        else (0.0, value)
                    )
                    if dimension == "x":
                        detour = max(
                            bounds.x0 - anchor[0],
                            anchor[0] - bounds.x1,
                            0.0,
                        )
                        self.assertLessEqual(detour, bounds.width * 0.55 + 1.0)
                    else:
                        detour = max(
                            bounds.y0 - anchor[1],
                            anchor[1] - bounds.y1,
                            0.0,
                        )
                        self.assertLessEqual(detour, bounds.height * 0.55 + 1.0)

                for leader in leaders:
                    path_bounds = leader.get_path().get_extents()
                    self.assertGreater(path_bounds.width, 0.0)
                    self.assertGreater(path_bounds.height, 0.0)
                    self.assertLessEqual(leader.get_linewidth(), 0.8)
                    self.assertLessEqual(leader.get_alpha(), 0.6)
                    self.assertLess(leader.get_zorder(), axis.get_zorder())

    def test_compact_numeric_fan_uses_screen_order_on_inverted_axes(self):
        for dimension in ("x", "y"):
            with self.subTest(dimension=dimension):
                figure, axes = self._axes()
                if dimension == "x":
                    axes.set_xlim(10.0, 0.0)
                else:
                    axes.set_ylim(10.0, 0.0)
                figure.canvas.draw()
                values = (3.0, 3.1, 3.2)
                artists = draw_additional_guides(
                    axes,
                    [
                        additional_guides.default_additional_guide(value)
                        for value in values
                    ],
                    dimension=dimension,
                    side="bottom" if dimension == "x" else "left",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )

                figure.canvas.draw()
                renderer = figure.canvas.get_renderer()
                labels = [
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-value"
                ]
                bounds = [label.get_window_extent(renderer) for label in labels]
                for index, left in enumerate(bounds):
                    for right in bounds[index + 1 :]:
                        self.assertFalse(left.overlaps(right))
                perpendicular_centers = [
                    (
                        (item.y0 + item.y1) / 2.0
                        if dimension == "x"
                        else item.x1
                    )
                    for item in bounds
                ]
                lanes: list[float] = []
                for center in perpendicular_centers:
                    if not any(abs(center - lane) <= 1.0 for lane in lanes):
                        lanes.append(center)
                self.assertEqual(len(lanes), 2)

    def test_reachable_envelopes_avoid_native_and_neighbor_labels(self):
        cases = (
            ("x", (0.48, 0.52), None),
            ("y", (0.49, 0.53), None),
            ("x", (0.49, 0.53, 0.62), None),
            ("y", (0.41, 0.42, 0.49), (0.0, 1.0)),
        )
        for dimension, values, manual_ticks in cases:
            for inverted in (False, True):
                with self.subTest(
                    dimension=dimension,
                    values=values,
                    inverted=inverted,
                ):
                    figure, axes = self._axes()
                    if dimension == "x":
                        axes.set_xlim(1.0, 0.0) if inverted else axes.set_xlim(0.0, 1.0)
                        if manual_ticks is not None:
                            axes.set_xticks(manual_ticks)
                    else:
                        axes.set_ylim(1.0, 0.0) if inverted else axes.set_ylim(0.0, 1.0)
                        if manual_ticks is not None:
                            axes.set_yticks(manual_ticks)
                    figure.canvas.draw()
                    artists = draw_additional_guides(
                        axes,
                        [
                            additional_guides.default_additional_guide(value)
                            for value in values
                        ],
                        dimension=dimension,
                        side="bottom" if dimension == "x" else "left",
                        font_size=12,
                        text_color="#222222",
                        grid_color="#D1D5DB",
                    )

                    figure.canvas.draw()
                    renderer = figure.canvas.get_renderer()
                    labels = [
                        artist
                        for artist in artists
                        if artist.get_gid() == "additional-tick-value"
                    ]
                    label_bounds = [
                        label.get_window_extent(renderer) for label in labels
                    ]
                    axis = axes.xaxis if dimension == "x" else axes.yaxis
                    native_bounds = [
                        label.get_window_extent(renderer)
                        for label in axis.get_majorticklabels()
                        if label.get_visible() and label.get_text()
                    ]
                    for index, bounds in enumerate(label_bounds):
                        for other in label_bounds[index + 1 :]:
                            self.assertFalse(bounds.overlaps(other))
                        for native in native_bounds:
                            self.assertFalse(bounds.overlaps(native))

                    transform = (
                        axes.get_xaxis_transform()
                        if dimension == "x"
                        else axes.get_yaxis_transform()
                    )
                    for label, bounds in zip(labels, label_bounds):
                        value = float(label.get_text())
                        anchor = transform.transform(
                            (value, 0.0)
                            if dimension == "x"
                            else (0.0, value)
                        )
                        if dimension == "x":
                            detour = max(
                                bounds.x0 - anchor[0],
                                anchor[0] - bounds.x1,
                                0.0,
                            )
                            self.assertLessEqual(
                                detour,
                                bounds.width * 0.55 + 1.0,
                            )
                        else:
                            detour = max(
                                bounds.y0 - anchor[1],
                                anchor[1] - bounds.y1,
                                0.0,
                            )
                            self.assertLessEqual(
                                detour,
                                bounds.height * 0.55 + 1.0,
                            )

    def test_axis_offset_text_is_an_obstacle_for_generated_numbers(self):
        for inverted in (False, True):
            with self.subTest(inverted=inverted):
                figure, axes = self._axes()
                limits = (1_000_000_010.0, 1_000_000_000.0) if inverted else (
                    1_000_000_000.0,
                    1_000_000_010.0,
                )
                axes.set_xlim(*limits)
                figure.canvas.draw()
                artists = draw_additional_guides(
                    axes,
                    [
                        additional_guides.default_additional_guide(
                            1_000_000_009.5
                        )
                    ],
                    dimension="x",
                    side="bottom",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )

                figure.canvas.draw()
                renderer = figure.canvas.get_renderer()
                label = next(
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-value"
                )
                offset = axes.xaxis.get_offset_text()
                self.assertEqual(label.get_text(), "9.5")
                self.assertEqual(offset.get_text(), "+1e9")
                self.assertFalse(
                    label.get_window_extent(renderer).overlaps(
                        offset.get_window_extent(renderer)
                    )
                )

    def test_large_offsets_keep_distinct_guides_and_reject_out_of_range_values(self):
        for base in (1_000_000_000.0, -1_000_000_000.0):
            with self.subTest(kind="distinct", base=base):
                figure, axes = self._axes()
                axes.set_xlim(base, base + 10.0)
                figure.canvas.draw()
                artists = draw_additional_guides(
                    axes,
                    [
                        additional_guides.default_additional_guide(base + 2.0),
                        additional_guides.default_additional_guide(base + 2.05),
                    ],
                    dimension="x",
                    side="bottom",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )
                self.assertEqual(
                    len(
                        [
                            artist
                            for artist in artists
                            if artist.get_gid() == "additional-tick-value"
                        ]
                    ),
                    1,
                )

        for base in (1_000_000_000_000_000.0, -1_000_000_000_000_000.0):
            with self.subTest(kind="range", base=base):
                figure, axes = self._axes()
                axes.set_xlim(base, base + 10.0)
                figure.canvas.draw()
                inside = draw_additional_guides(
                    axes,
                    [additional_guides.default_additional_guide(base + 9.75)],
                    dimension="x",
                    side="bottom",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )
                outside = draw_additional_guides(
                    axes,
                    [additional_guides.default_additional_guide(base + 15.0)],
                    dimension="x",
                    side="bottom",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )
                self.assertTrue(
                    any(
                        artist.get_gid() == "additional-tick-value"
                        for artist in inside
                    )
                )
                self.assertEqual(outside, [])

                next_visible = draw_additional_guides(
                    axes,
                    [
                        additional_guides.default_additional_guide(
                            math.nextafter(base, math.inf)
                        )
                    ],
                    dimension="x",
                    side="bottom",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )
                next_outside = draw_additional_guides(
                    axes,
                    [
                        additional_guides.default_additional_guide(
                            math.nextafter(base + 10.0, math.inf)
                        )
                    ],
                    dimension="x",
                    side="bottom",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )
                self.assertTrue(
                    any(
                        artist.get_gid() == "additional-tick-value"
                        for artist in next_visible
                    )
                )
                self.assertEqual(next_outside, [])

    def test_tiny_scientific_ranges_use_span_relative_tolerances(self):
        cases = (
            (1e-10, 1.1e-10, 1.049e-10, 1.2e-10),
            (0.0, 1e-15, 1e-16, 2e-15),
        )
        for inverted in (False, True):
            for lower, upper, inside_value, outside_value in cases:
                with self.subTest(
                    inverted=inverted,
                    lower=lower,
                    upper=upper,
                ):
                    figure, axes = self._axes()
                    axes.set_xlim(
                        *((upper, lower) if inverted else (lower, upper))
                    )
                    figure.canvas.draw()
                    inside = draw_additional_guides(
                        axes,
                        [
                            additional_guides.default_additional_guide(
                                inside_value
                            )
                        ],
                        dimension="x",
                        side="bottom",
                        font_size=12,
                        text_color="#222222",
                        grid_color="#D1D5DB",
                    )
                    outside = draw_additional_guides(
                        axes,
                        [
                            additional_guides.default_additional_guide(
                                outside_value
                            )
                        ],
                        dimension="x",
                        side="bottom",
                        font_size=12,
                        text_color="#222222",
                        grid_color="#D1D5DB",
                    )
                    self.assertTrue(
                        any(
                            artist.get_gid() == "additional-tick-value"
                            for artist in inside
                        )
                    )
                    self.assertEqual(outside, [])

    def test_x_and_y_numeric_fans_share_corner_space_without_overlap(self):
        for font_size in (18, 36):
            for invert_x, invert_y in ((False, False), (True, True)):
                with self.subTest(
                    font_size=font_size,
                    invert_x=invert_x,
                    invert_y=invert_y,
                ):
                    figure = Figure(figsize=(4.0, 3.0), dpi=100)
                    FigureCanvasAgg(figure)
                    axes = figure.subplots()
                    axes.set_xlim(10.0, 0.0) if invert_x else axes.set_xlim(0.0, 10.0)
                    axes.set_ylim(10.0, 0.0) if invert_y else axes.set_ylim(0.0, 10.0)
                    axes.tick_params(labelsize=font_size)
                    x_values = (
                        (9.98, 9.96, 9.94)
                        if invert_x
                        else (0.02, 0.04, 0.06)
                    )
                    y_values = (
                        (9.98, 9.96, 9.94)
                        if invert_y
                        else (0.02, 0.04, 0.06)
                    )
                    figure.canvas.draw()
                    x_artists = draw_additional_guides(
                        axes,
                        [
                            additional_guides.default_additional_guide(value)
                            for value in x_values
                        ],
                        dimension="x",
                        side="bottom",
                        font_size=12,
                        text_color="#222222",
                        grid_color="#D1D5DB",
                    )
                    y_artists = draw_additional_guides(
                        axes,
                        [
                            additional_guides.default_additional_guide(value)
                            for value in y_values
                        ],
                        dimension="y",
                        side="left",
                        font_size=12,
                        text_color="#222222",
                        grid_color="#D1D5DB",
                    )

                    figure.canvas.draw()
                    renderer = figure.canvas.get_renderer()
                    x_bounds = [
                        artist.get_window_extent(renderer)
                        for artist in x_artists
                        if artist.get_gid() == "additional-tick-value"
                    ]
                    y_bounds = [
                        artist.get_window_extent(renderer)
                        for artist in y_artists
                        if artist.get_gid() == "additional-tick-value"
                    ]
                    for horizontal in x_bounds:
                        for vertical in y_bounds:
                            self.assertFalse(horizontal.overlaps(vertical))

    def test_custom_text_nine_position_grid_uses_visual_bounds(self):
        for dimension in ("x", "y"):
            for text in ("Single line", "Long first line\nshort"):
                for show_background in (False, True):
                    with self.subTest(
                        dimension=dimension,
                        text=text,
                        show_background=show_background,
                    ):
                        figure, axes = self._axes()
                        value = 2.5
                        labels = []
                        for text_side in ("left", "center", "right"):
                            for vertical_position in (
                                "below",
                                "aligned",
                                "above",
                            ):
                                artists = draw_additional_guides(
                                    axes,
                                    [
                                        {
                                            **additional_guides.default_additional_guide(
                                                value
                                            ),
                                            "show_tick": False,
                                            "show_line": False,
                                            "text": text,
                                            "text_side": text_side,
                                            "vertical_position": vertical_position,
                                            "show_label_background": show_background,
                                        }
                                    ],
                                    dimension=dimension,
                                    side=(
                                        "bottom" if dimension == "x" else "left"
                                    ),
                                    font_size=12,
                                    text_color="#222222",
                                    grid_color="#D1D5DB",
                                )
                                label = next(
                                    artist
                                    for artist in artists
                                    if artist.get_gid() == "additional-tick-label"
                                )
                                labels.append(
                                    (text_side, vertical_position, label)
                                )

                        figure.canvas.draw()
                        renderer = figure.canvas.get_renderer()
                        gap = float(renderer.points_to_pixels(4.0))
                        transform = (
                            axes.get_xaxis_transform()
                            if dimension == "x"
                            else axes.get_yaxis_transform()
                        )
                        anchor_x, anchor_y = transform.transform(
                            (value, 0.0)
                            if dimension == "x"
                            else (0.0, value)
                        )
                        for text_side, vertical_position, label in labels:
                            with self.subTest(
                                text_side=text_side,
                                vertical_position=vertical_position,
                            ):
                                bounds = self._guide_visual_bounds(
                                    label,
                                    renderer,
                                )
                                if text_side == "left":
                                    self.assertAlmostEqual(
                                        anchor_x - bounds.x1,
                                        gap,
                                        delta=0.5,
                                    )
                                elif text_side == "right":
                                    self.assertAlmostEqual(
                                        bounds.x0 - anchor_x,
                                        gap,
                                        delta=0.5,
                                    )
                                else:
                                    self.assertAlmostEqual(
                                        (bounds.x0 + bounds.x1) / 2.0,
                                        anchor_x,
                                        delta=0.5,
                                    )
                                if vertical_position == "below":
                                    self.assertAlmostEqual(
                                        anchor_y - bounds.y1,
                                        gap,
                                        delta=0.5,
                                    )
                                elif vertical_position == "above":
                                    self.assertAlmostEqual(
                                        bounds.y0 - anchor_y,
                                        gap,
                                        delta=0.5,
                                    )
                                else:
                                    self.assertAlmostEqual(
                                        (bounds.y0 + bounds.y1) / 2.0,
                                        anchor_y,
                                    delta=0.5,
                                )

    def test_plot_edge_labels_stay_inside_and_background_is_geometry_neutral(self):
        configurations = (
            ("x", "plot_top", "center", "plot_top"),
            ("x", "plot_bottom", "center", "plot_bottom"),
            ("y", "plot_left", "plot_left", "aligned"),
            ("y", "plot_right", "plot_right", "aligned"),
        )

        def render_case(
            dimension: str,
            plot_edge: str,
            text_side: str,
            vertical_position: str,
            *,
            font_size: int,
            text: str,
            inverted: bool,
            boundary_index: int,
            show_background: bool,
        ) -> dict[str, object]:
            figure, axes = self._axes()
            if inverted:
                if dimension == "x":
                    axes.set_xlim(10.0, 0.0)
                else:
                    axes.set_ylim(10.0, 0.0)
            figure.canvas.draw()
            limits = axes.get_xlim() if dimension == "x" else axes.get_ylim()
            # Stay just inside either display-space boundary. This exercises a
            # generated numeric tick and its leader while the custom label is
            # clamped against the corresponding plot edge.
            fraction = 0.003 if boundary_index == 0 else 0.997
            value = float(limits[0] + (limits[1] - limits[0]) * fraction)
            artists = draw_additional_guides(
                axes,
                [
                    {
                        **additional_guides.default_additional_guide(value),
                        "show_tick": True,
                        "show_value_with_text": True,
                        "show_line": True,
                        "text": text,
                        "text_side": text_side,
                        "vertical_position": vertical_position,
                        "show_label_background": show_background,
                    }
                ],
                dimension=dimension,
                # Plot-edge placement is intentionally independent of the
                # conventional bottom-X / left-Y numeric tick side.
                side="bottom" if dimension == "x" else "left",
                font_size=font_size,
                text_color="#222222",
                grid_color="#D1D5DB",
            )

            figure.canvas.draw()
            renderer = figure.canvas.get_renderer()
            custom_label = next(
                artist
                for artist in artists
                if artist.get_gid() == "additional-tick-label"
            )
            numeric_label = next(
                artist
                for artist in artists
                if artist.get_gid() == "additional-tick-value"
            )
            tick = next(
                artist
                for artist in artists
                if artist.get_gid() == "additional-tick"
            )
            grid_line = next(
                artist
                for artist in artists
                if artist.get_gid() == "additional-grid-line"
            )
            leaders = [
                artist
                for artist in artists
                if artist.get_gid() == "additional-tick-leader"
            ]
            custom_bounds = self._guide_visual_bounds(
                custom_label,
                renderer,
            )
            axes_bounds = axes.get_window_extent(renderer)
            gap = float(renderer.points_to_pixels(4.0))
            tolerance = 0.5
            self.assertGreaterEqual(
                custom_bounds.x0,
                axes_bounds.x0 + gap - tolerance,
            )
            self.assertLessEqual(
                custom_bounds.x1,
                axes_bounds.x1 - gap + tolerance,
            )
            self.assertGreaterEqual(
                custom_bounds.y0,
                axes_bounds.y0 + gap - tolerance,
            )
            self.assertLessEqual(
                custom_bounds.y1,
                axes_bounds.y1 - gap + tolerance,
            )
            if plot_edge == "plot_top":
                self.assertAlmostEqual(
                    axes_bounds.y1 - custom_bounds.y1,
                    gap,
                    delta=tolerance,
                )
            elif plot_edge == "plot_bottom":
                self.assertAlmostEqual(
                    custom_bounds.y0 - axes_bounds.y0,
                    gap,
                    delta=tolerance,
                )
            elif plot_edge == "plot_left":
                self.assertAlmostEqual(
                    custom_bounds.x0 - axes_bounds.x0,
                    gap,
                    delta=tolerance,
                )
            else:
                self.assertAlmostEqual(
                    axes_bounds.x1 - custom_bounds.x1,
                    gap,
                    delta=tolerance,
                )

            def extents(bounds) -> tuple[float, float, float, float]:
                return tuple(float(number) for number in bounds.extents)

            def leader_extents(leader) -> tuple[float, float, float, float]:
                vertices = leader.get_transform().transform(
                    leader.get_path().vertices
                )
                return (
                    float(vertices[:, 0].min()),
                    float(vertices[:, 1].min()),
                    float(vertices[:, 0].max()),
                    float(vertices[:, 1].max()),
                )

            background = custom_label.get_bbox_patch()
            self.assertIsNotNone(background)
            return {
                "figure_bounds": extents(figure.bbox),
                "axes_bounds": extents(axes_bounds),
                "custom_bounds": extents(custom_bounds),
                "custom_position": tuple(
                    float(number) for number in custom_label.get_position()
                ),
                "numeric_bounds": extents(
                    numeric_label.get_window_extent(renderer)
                ),
                "tick_bounds": extents(tick.get_window_extent(renderer)),
                "grid_bounds": extents(
                    grid_line.get_window_extent(renderer)
                ),
                "leader_bounds": tuple(
                    leader_extents(leader) for leader in leaders
                ),
                "background_alpha": float(background.get_alpha()),
            }

        for (
            dimension,
            plot_edge,
            text_side,
            vertical_position,
        ) in configurations:
            for font_size in (12, 36):
                for text in ("Edge label", "First line\nsecond"):
                    for inverted in (False, True):
                        for boundary_index in (0, 1):
                            with self.subTest(
                                dimension=dimension,
                                plot_edge=plot_edge,
                                font_size=font_size,
                                text=text,
                                inverted=inverted,
                                boundary_index=boundary_index,
                            ):
                                without_background = render_case(
                                    dimension,
                                    plot_edge,
                                    text_side,
                                    vertical_position,
                                    font_size=font_size,
                                    text=text,
                                    inverted=inverted,
                                    boundary_index=boundary_index,
                                    show_background=False,
                                )
                                with_background = render_case(
                                    dimension,
                                    plot_edge,
                                    text_side,
                                    vertical_position,
                                    font_size=font_size,
                                    text=text,
                                    inverted=inverted,
                                    boundary_index=boundary_index,
                                    show_background=True,
                                )
                                self.assertEqual(
                                    without_background["background_alpha"],
                                    0.0,
                                )
                                self.assertEqual(
                                    with_background["background_alpha"],
                                    0.75,
                                )
                                for key in (
                                    "figure_bounds",
                                    "axes_bounds",
                                    "custom_bounds",
                                    "custom_position",
                                    "numeric_bounds",
                                    "tick_bounds",
                                    "grid_bounds",
                                ):
                                    self.assertEqual(
                                        len(without_background[key]),
                                        len(with_background[key]),
                                    )
                                    for before, after in zip(
                                        without_background[key],
                                        with_background[key],
                                    ):
                                        self.assertAlmostEqual(
                                            before,
                                            after,
                                            delta=1e-6,
                                            msg=key,
                                        )
                                self.assertEqual(
                                    len(without_background["leader_bounds"]),
                                    len(with_background["leader_bounds"]),
                                )
                                for before_bounds, after_bounds in zip(
                                    without_background["leader_bounds"],
                                    with_background["leader_bounds"],
                                ):
                                    for before, after in zip(
                                        before_bounds,
                                        after_bounds,
                                    ):
                                        self.assertAlmostEqual(
                                            before,
                                            after,
                                            delta=1e-6,
                                            msg="leader_bounds",
                                        )

    def test_inside_custom_text_is_not_shifted_by_non_overlapping_tick_value(self):
        for dimension in ("x", "y"):
            with self.subTest(dimension=dimension):
                figure, axes = self._axes()
                value = 4.0
                figure.canvas.draw()
                artists = draw_additional_guides(
                    axes,
                    [
                        {
                            **additional_guides.default_additional_guide(value),
                            "show_tick": True,
                            "show_value_with_text": True,
                            "text": "Inside label",
                            "text_side": "right",
                            "vertical_position": "above",
                            "show_label_background": True,
                        }
                    ],
                    dimension=dimension,
                    side="bottom" if dimension == "x" else "left",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )

                figure.canvas.draw()
                renderer = figure.canvas.get_renderer()
                label = next(
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-label"
                )
                bounds = self._guide_visual_bounds(label, renderer)
                transform = (
                    axes.get_xaxis_transform()
                    if dimension == "x"
                    else axes.get_yaxis_transform()
                )
                anchor_x, anchor_y = transform.transform(
                    (value, 0.0) if dimension == "x" else (0.0, value)
                )
                gap = float(renderer.points_to_pixels(4.0))
                self.assertAlmostEqual(
                    bounds.x0 - anchor_x,
                    gap,
                    delta=0.5,
                )
                self.assertAlmostEqual(
                    bounds.y0 - anchor_y,
                    gap,
                    delta=0.5,
                )

                axis = axes.xaxis if dimension == "x" else axes.yaxis
                tick_index = next(
                    index
                    for index, tick_value in enumerate(axis.get_majorticklocs())
                    if abs(float(tick_value) - value) < 1e-9
                )
                tick_bounds = axis.get_major_ticks()[
                    tick_index
                ].label1.get_window_extent(renderer)
                self.assertFalse(bounds.overlaps(tick_bounds))

    def test_custom_text_still_avoids_a_truly_overlapping_tick_value(self):
        cases = (
            ("x", "bottom", "center", "below"),
            ("y", "left", "left", "aligned"),
        )
        for dimension, side, text_side, vertical_position in cases:
            with self.subTest(dimension=dimension):
                figure, axes = self._axes()
                value = 4.0
                figure.canvas.draw()
                artists = draw_additional_guides(
                    axes,
                    [
                        {
                            **additional_guides.default_additional_guide(value),
                            "show_tick": True,
                            "show_value_with_text": True,
                            "text": "Overlapping value",
                            "text_side": text_side,
                            "vertical_position": vertical_position,
                            "show_label_background": True,
                        }
                    ],
                    dimension=dimension,
                    side=side,
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )

                figure.canvas.draw()
                renderer = figure.canvas.get_renderer()
                label = next(
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-label"
                )
                bounds = self._guide_visual_bounds(label, renderer)
                transform = (
                    axes.get_xaxis_transform()
                    if dimension == "x"
                    else axes.get_yaxis_transform()
                )
                anchor_x, anchor_y = transform.transform(
                    (value, 0.0) if dimension == "x" else (0.0, value)
                )
                axis = axes.xaxis if dimension == "x" else axes.yaxis
                tick_index = next(
                    index
                    for index, tick_value in enumerate(axis.get_majorticklocs())
                    if abs(float(tick_value) - value) < 1e-9
                )
                tick_bounds = axis.get_major_ticks()[
                    tick_index
                ].label1.get_window_extent(renderer)
                placement_gap = float(renderer.points_to_pixels(4.0))
                collision_gap = float(renderer.points_to_pixels(3.0))
                if dimension == "x":
                    self.assertGreater(
                        anchor_y - bounds.y1,
                        placement_gap + 0.5,
                    )
                    self.assertGreaterEqual(
                        tick_bounds.y0 - bounds.y1,
                        collision_gap - 0.5,
                    )
                else:
                    self.assertGreater(
                        anchor_x - bounds.x1,
                        placement_gap + 0.5,
                    )
                    self.assertGreaterEqual(
                        tick_bounds.x0 - bounds.x1,
                        collision_gap - 0.5,
                    )
                self.assertFalse(bounds.overlaps(tick_bounds))

    def test_large_background_keeps_four_point_clearance_from_guide_line(self):
        for dimension in ("x", "y"):
            with self.subTest(dimension=dimension):
                figure, axes = self._axes()
                value = 5.25
                artists = draw_additional_guides(
                    axes,
                    [
                        {
                            **additional_guides.default_additional_guide(value),
                            "show_tick": False,
                            "show_line": True,
                            "text": "Large label\nbackground",
                            "text_side": "right",
                            "vertical_position": "above",
                            "show_label_background": True,
                        }
                    ],
                    dimension=dimension,
                    side="bottom" if dimension == "x" else "left",
                    font_size=36,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )

                figure.canvas.draw()
                renderer = figure.canvas.get_renderer()
                label = next(
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-label"
                )
                bounds = self._guide_visual_bounds(label, renderer)
                transform = (
                    axes.get_xaxis_transform()
                    if dimension == "x"
                    else axes.get_yaxis_transform()
                )
                anchor_x, anchor_y = transform.transform(
                    (value, 0.0) if dimension == "x" else (0.0, value)
                )
                gap = float(renderer.points_to_pixels(4.0))
                self.assertAlmostEqual(
                    bounds.x0 - anchor_x,
                    gap,
                    delta=0.5,
                )
                self.assertAlmostEqual(
                    bounds.y0 - anchor_y,
                    gap,
                    delta=0.5,
                )

    def test_center_text_side_centers_horizontal_and_vertical_labels(self):
        for dimension in ("x", "y"):
            with self.subTest(dimension=dimension):
                figure, axes = self._axes()
                value = 2.5
                artists = draw_additional_guides(
                    axes,
                    [
                        {
                            **additional_guides.default_additional_guide(value),
                            "text": "centered",
                            "text_side": "center",
                        }
                    ],
                    dimension=dimension,
                    side="bottom" if dimension == "x" else "left",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )

                figure.canvas.draw()
                label = artists[-1]
                transform = (
                    axes.get_xaxis_transform()
                    if dimension == "x"
                    else axes.get_yaxis_transform()
                )
                anchor = transform.transform(
                    (value, 0.0) if dimension == "x" else (0.0, value)
                )
                bounds = label.get_window_extent(figure.canvas.get_renderer())
                self.assertAlmostEqual(
                    (bounds.x0 + bounds.x1) / 2.0,
                    anchor[0],
                    places=5,
                )

    def test_stale_manual_locator_labels_are_refreshed_before_collision_layout(self):
        for dimension, text_side, vertical_position in (
            ("x", "right", "below"),
            ("y", "left", "aligned"),
        ):
            with self.subTest(dimension=dimension):
                figure, axes = self._axes()
                figure.canvas.draw()
                axis = axes.xaxis if dimension == "x" else axes.yaxis
                axis.set_major_locator(MultipleLocator(1.0))
                artists = draw_additional_guides(
                    axes,
                    [
                        {
                            **additional_guides.default_additional_guide(5.0),
                            "text": "manual cutoff",
                            "text_side": text_side,
                            "vertical_position": vertical_position,
                            "show_label_background": True,
                        }
                    ],
                    dimension=dimension,
                    side="bottom" if dimension == "x" else "left",
                    font_size=12,
                    text_color="#222222",
                    grid_color="#D1D5DB",
                )

                figure.canvas.draw()
                collision_index = next(
                    index
                    for index, value in enumerate(axis.get_majorticklocs())
                    if value == 5.0
                )
                tick = axis.get_major_ticks()[collision_index]
                renderer = figure.canvas.get_renderer()
                guide_bounds = artists[-1].get_bbox_patch().get_window_extent(
                    renderer
                )
                tick_bounds = tick.label1.get_window_extent(renderer)
                self.assertTrue(tick.tick1line.get_visible())
                self.assertTrue(tick.label1.get_visible())
                self.assertTrue(tick.label1.get_text())
                if text_side == "left":
                    self.assertLess(guide_bounds.x1, tick_bounds.x0)
                else:
                    self.assertGreater(guide_bounds.x0, tick_bounds.x1)

    def test_explicit_line_is_drawn_when_regular_grid_is_hidden(self):
        _, axes = self._axes()
        axes.grid(False)
        artists = draw_additional_guides(
            axes,
            [
                {
                    **additional_guides.default_additional_guide(2.0),
                    "show_line": True,
                }
            ],
            dimension="y",
            side="left",
            font_size=10,
            text_color="#222222",
            grid_color="#D1D5DB",
        )

        self.assertEqual(
            [artist.get_gid() for artist in artists],
            ["additional-grid-line"],
        )
        self.assertEqual(artists[0].get_linestyle(), "--")
        self.assertEqual(artists[0].get_linewidth(), 1.2)

    def test_optional_label_background_adapts_to_light_and_dark_themes(self):
        for facecolor in ("#FFFFFF", "#111827"):
            with self.subTest(facecolor=facecolor):
                _, axes = self._axes()
                artists = draw_additional_guides(
                    axes,
                    [
                        {
                            **additional_guides.default_additional_guide(2.5),
                            "text": "label",
                            "show_label_background": True,
                        }
                    ],
                    dimension="y",
                    side="left",
                    font_size=10,
                    text_color=(
                        "#222222" if facecolor == "#FFFFFF" else "#F9FAFB"
                    ),
                    grid_color="#D1D5DB",
                    label_facecolor=facecolor,
                )

                label = next(
                    artist
                    for artist in artists
                    if artist.get_gid() == "additional-tick-label"
                )
                patch = label.get_bbox_patch()
                self.assertIsNotNone(patch)
                self.assertEqual(patch.get_facecolor(), to_rgba(facecolor, 0.75))

    def test_line_width_normalization_handles_invalid_and_boundary_values(self):
        self.assertEqual(ChartSettings(additional_guide_line_width=-1).additional_guide_line_width, 0.5)
        self.assertEqual(ChartSettings(additional_guide_line_width=99).additional_guide_line_width, 5.0)
        self.assertEqual(
            ChartSettings(additional_guide_line_width=float("nan")).additional_guide_line_width,
            1.2,
        )

    def test_out_of_range_guides_are_saved_but_not_drawn(self):
        _, axes = self._axes()
        guide = {
            **additional_guides.default_additional_guide(25.0),
            "show_line": True,
            "text": "outside",
        }

        artists = draw_additional_guides(
            axes,
            [guide],
            dimension="y",
            side="left",
            font_size=10,
            text_color="#222222",
            grid_color="#D1D5DB",
        )

        self.assertEqual(artists, [])
        self.assertEqual(
            ChartSettings(additional_primary_axis_guides=[guide])
            .additional_primary_axis_guides[0]["value"],
            25.0,
        )


class AdditionalGuideCanvasThemeTests(EasyGraphQtTestCase):
    @staticmethod
    def _major_tick_at(axis, value):
        index = next(
            index
            for index, tick_value in enumerate(axis.get_majorticklocs())
            if abs(float(tick_value) - float(value)) < 1e-9
        )
        return axis.get_major_ticks()[index]

    def _background_geometry_snapshot(
        self,
        *,
        show_background: bool,
        dense: bool,
    ):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {"X": [0.0, 5.0, 10.0], "Y": [0.0, 5.0, 10.0]}
        )
        xy_settings = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )
        x_values = (2.02, 2.08, 2.14) if dense else (3.0,)
        y_values = (6.02, 6.08, 6.14) if dense else (7.0,)

        def guides(values, label):
            label_index = len(values) // 2
            return [
                {
                    **additional_guides.default_additional_guide(value),
                    "show_tick": True,
                    "show_value_with_text": True,
                    "show_line": True,
                    "text": label if index == label_index else "",
                    "text_side": "right",
                    "vertical_position": "above",
                    "show_label_background": (
                        show_background and index == label_index
                    ),
                }
                for index, value in enumerate(values)
            ]

        canvas.render(
            frame,
            ChartSettings(
                show_stat_table=False,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
                additional_x_axis_guides=guides(x_values, "X callout"),
                additional_primary_axis_guides=guides(
                    y_values,
                    "Y callout",
                ),
            ),
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )
        canvas.canvas.draw()
        axes = canvas.figure.axes[0]
        renderer = canvas.canvas.get_renderer()

        def rounded(values):
            return tuple(round(float(value), 6) for value in values)

        numeric_labels = {
            artist.get_text(): (
                rounded(artist.get_position()),
                rounded(artist.get_window_extent(renderer).bounds),
            )
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick-value"
        }
        tick_marks = sorted(
            (
                rounded(
                    artist.get_path()
                    .transformed(artist.get_transform())
                    .vertices.ravel()
                ),
                artist.get_marker(),
                round(float(artist.get_markersize()), 6),
                round(float(artist.get_markeredgewidth()), 6),
            )
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick"
        )
        custom_labels = {
            artist.get_text(): (
                rounded(artist.get_position()),
                rounded(artist.get_window_extent(renderer).bounds),
            )
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick-label"
        }
        custom_backgrounds = {}
        for artist in axes.get_children():
            if artist.get_gid() != "additional-tick-label":
                continue
            patch = artist.get_bbox_patch()
            custom_backgrounds[artist.get_text()] = (
                None
                if patch is None
                else (
                    rounded(patch.get_facecolor()),
                    rounded(patch.get_edgecolor()),
                    round(float(patch.get_alpha()), 6),
                )
            )
        return {
            "canvas_size": (
                canvas.canvas.width(),
                canvas.canvas.height(),
                *rounded(canvas.figure.bbox.bounds),
            ),
            "numeric_labels": numeric_labels,
            "tick_marks": tick_marks,
            "custom_labels": custom_labels,
            "leader_count": sum(
                artist.get_gid() == "additional-tick-leader"
                for artist in axes.get_children()
            ),
            "backgrounds": custom_backgrounds,
        }

    def _assert_background_only_changes_visual_effect(self, *, dense: bool):
        without_background = self._background_geometry_snapshot(
            show_background=False,
            dense=dense,
        )
        with_background = self._background_geometry_snapshot(
            show_background=True,
            dense=dense,
        )

        for key in (
            "canvas_size",
            "numeric_labels",
            "tick_marks",
            "custom_labels",
            "leader_count",
        ):
            self.assertEqual(with_background[key], without_background[key])
        expected_visible_face = tuple(
            round(value, 6) for value in to_rgba("#FFFFFF", 0.75)
        )
        for label in ("X callout", "Y callout"):
            hidden_face, hidden_edge, hidden_alpha = without_background[
                "backgrounds"
            ][label]
            visible_face, visible_edge, visible_alpha = with_background[
                "backgrounds"
            ][label]
            self.assertEqual(hidden_face[:3], visible_face[:3])
            self.assertEqual(hidden_face[-1], 0.0)
            self.assertEqual(hidden_edge[-1], 0.0)
            self.assertEqual(hidden_alpha, 0.0)
            self.assertEqual(visible_face, expected_visible_face)
            self.assertEqual(visible_edge[-1], 0.0)
            self.assertEqual(visible_alpha, 0.75)
        return without_background, with_background

    def test_label_background_does_not_change_default_guide_geometry(self):
        without_background, _with_background = (
            self._assert_background_only_changes_visual_effect(dense=False)
        )
        self.assertEqual(without_background["leader_count"], 0)

    def test_label_background_does_not_change_dense_collision_geometry(self):
        without_background, _with_background = (
            self._assert_background_only_changes_visual_effect(dense=True)
        )
        self.assertGreater(without_background["leader_count"], 0)

    def test_plot_edge_background_toggle_preserves_canvas_and_numeric_layout(self):
        from easygraph.plotting.canvas import PlotCanvas

        frame = pd.DataFrame(
            {"X": [0.0, 5.0, 10.0], "Y": [0.0, 5.0, 10.0]}
        )
        xy_settings = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )

        def snapshot(show_background: bool) -> dict[str, object]:
            def guide(value, text, text_side, vertical_position):
                return {
                    **additional_guides.default_additional_guide(value),
                    "show_tick": True,
                    "show_value_with_text": True,
                    "show_line": True,
                    "text": text,
                    "text_side": text_side,
                    "vertical_position": vertical_position,
                    "show_label_background": show_background,
                }

            canvas = PlotCanvas()
            self.addCleanup(canvas.close)
            canvas.render(
                frame,
                ChartSettings(
                    show_stat_table=False,
                    auto_x_range=False,
                    x_min=0.0,
                    x_max=10.0,
                    x_auto_tick_interval=False,
                    x_tick_interval=1.0,
                    auto_y_range=False,
                    y_min=0.0,
                    y_max=10.0,
                    primary_auto_tick_interval=False,
                    primary_tick_interval=1.0,
                    additional_guide_font_size=36,
                    additional_x_axis_guides=[
                        guide(
                            0.03,
                            "X top\nedge",
                            "center",
                            "plot_top",
                        ),
                        guide(
                            9.97,
                            "X bottom\nedge",
                            "center",
                            "plot_bottom",
                        ),
                    ],
                    additional_primary_axis_guides=[
                        guide(
                            0.03,
                            "Y left\nedge",
                            "plot_left",
                            "aligned",
                        ),
                        guide(
                            9.97,
                            "Y right\nedge",
                            "plot_right",
                            "aligned",
                        ),
                    ],
                ),
                xy_settings=xy_settings,
                column_ids=["x", "y"],
            )
            self.qapp.processEvents()
            canvas.canvas.draw()
            axes = canvas.figure.axes[0]
            renderer = canvas.canvas.get_renderer()
            axes_bounds = axes.get_window_extent(renderer)
            gap = float(renderer.points_to_pixels(4.0))

            def rounded(values):
                return tuple(round(float(value), 6) for value in values)

            custom_bounds = {}
            background_alpha = {}
            for artist in axes.get_children():
                if artist.get_gid() != "additional-tick-label":
                    continue
                artist.update_bbox_position_size(renderer)
                patch = artist.get_bbox_patch()
                self.assertIsNotNone(patch)
                bounds = patch.get_window_extent(renderer)
                custom_bounds[artist.get_text()] = rounded(bounds.extents)
                background_alpha[artist.get_text()] = round(
                    float(patch.get_alpha()),
                    6,
                )
                self.assertGreaterEqual(bounds.x0, axes_bounds.x0 + gap - 0.5)
                self.assertLessEqual(bounds.x1, axes_bounds.x1 - gap + 0.5)
                self.assertGreaterEqual(bounds.y0, axes_bounds.y0 + gap - 0.5)
                self.assertLessEqual(bounds.y1, axes_bounds.y1 - gap + 0.5)

            self.assertAlmostEqual(
                axes_bounds.y1 - custom_bounds["X top\nedge"][3],
                gap,
                delta=0.5,
            )
            self.assertAlmostEqual(
                custom_bounds["X bottom\nedge"][1] - axes_bounds.y0,
                gap,
                delta=0.5,
            )
            self.assertAlmostEqual(
                custom_bounds["Y left\nedge"][0] - axes_bounds.x0,
                gap,
                delta=0.5,
            )
            self.assertAlmostEqual(
                axes_bounds.x1 - custom_bounds["Y right\nedge"][2],
                gap,
                delta=0.5,
            )

            numeric_bounds = sorted(
                rounded(artist.get_window_extent(renderer).extents)
                for artist in axes.get_children()
                if artist.get_gid() == "additional-tick-value"
            )
            leader_bounds = []
            for artist in axes.get_children():
                if artist.get_gid() != "additional-tick-leader":
                    continue
                vertices = artist.get_transform().transform(
                    artist.get_path().vertices
                )
                leader_bounds.append(
                    rounded(
                        (
                            vertices[:, 0].min(),
                            vertices[:, 1].min(),
                            vertices[:, 0].max(),
                            vertices[:, 1].max(),
                        )
                    )
                )
            leader_bounds.sort()
            blit_extents = (
                None
                if canvas._blit_background is None
                else tuple(canvas._blit_background.get_extents())
            )
            return {
                "canvas_size": (
                    canvas.canvas.width(),
                    canvas.canvas.height(),
                    *rounded(canvas.figure.bbox.extents),
                    *canvas._canvas_size,
                    blit_extents,
                ),
                "axes_position": rounded(axes.get_position().bounds),
                "custom_bounds": custom_bounds,
                "numeric_bounds": numeric_bounds,
                "leader_bounds": leader_bounds,
                "background_alpha": background_alpha,
            }

        without_background = snapshot(False)
        with_background = snapshot(True)
        for key in (
            "canvas_size",
            "axes_position",
            "custom_bounds",
            "numeric_bounds",
            "leader_bounds",
        ):
            self.assertEqual(without_background[key], with_background[key])
        self.assertTrue(
            all(
                alpha == 0.0
                for alpha in without_background["background_alpha"].values()
            )
        )
        self.assertTrue(
            all(
                alpha == 0.75
                for alpha in with_background["background_alpha"].values()
            )
        )

    def test_groups_manual_tick_interval_preserves_colliding_tick_label(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            self.df,
            ChartSettings(
                show_stat_table=False,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
                primary_auto_tick_interval=False,
                primary_tick_interval=1.0,
                additional_primary_axis_guides=[
                    {
                        **additional_guides.default_additional_guide(5.0),
                        "text": "manual cutoff",
                        "show_label_background": True,
                    }
                ],
            ),
        )

        axes = canvas.figure.axes[0]
        tick = self._major_tick_at(axes.yaxis, 5.0)
        label = next(
            artist
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick-label"
        )
        renderer = canvas.canvas.get_renderer()
        self.assertTrue(tick.tick1line.get_visible())
        self.assertTrue(tick.label1.get_visible())
        self.assertTrue(tick.label1.get_text())
        self.assertLess(
            label.get_bbox_patch().get_window_extent(renderer).x1,
            tick.label1.get_window_extent(renderer).x0,
        )

    def test_ridge_manual_tick_interval_preserves_colliding_tick_label(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            self.df,
            ChartSettings(
                chart_type="Ridge",
                show_stat_table=False,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
                primary_auto_tick_interval=False,
                primary_tick_interval=1.0,
                additional_primary_axis_guides=[
                    {
                        **additional_guides.default_additional_guide(5.0),
                        "text": "ridge cutoff",
                        "text_side": "right",
                        "vertical_position": "below",
                        "show_label_background": True,
                    }
                ],
            ),
        )

        axes = canvas.figure.axes[0]
        tick = self._major_tick_at(axes.xaxis, 5.0)
        label = next(
            artist
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick-label"
        )
        renderer = canvas.canvas.get_renderer()
        self.assertTrue(tick.tick1line.get_visible())
        self.assertTrue(tick.label1.get_visible())
        self.assertTrue(tick.label1.get_text())
        self.assertGreater(
            label.get_bbox_patch().get_window_extent(renderer).x0,
            tick.label1.get_window_extent(renderer).x1,
        )

    def test_xy_manual_tick_intervals_preserve_both_colliding_tick_labels(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame({"X": [0.0, 5.0, 10.0], "Y": [0.0, 5.0, 10.0]})
        xy_settings = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )
        canvas.render(
            frame,
            ChartSettings(
                show_stat_table=False,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                x_auto_tick_interval=False,
                x_tick_interval=1.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
                primary_auto_tick_interval=False,
                primary_tick_interval=1.0,
                additional_x_axis_guides=[
                    {
                        **additional_guides.default_additional_guide(5.0),
                        "text": "X cutoff",
                        "text_side": "right",
                        "vertical_position": "below",
                        "show_label_background": True,
                    }
                ],
                additional_primary_axis_guides=[
                    {
                        **additional_guides.default_additional_guide(5.0),
                        "text": "Y cutoff",
                        "show_label_background": True,
                    }
                ],
            ),
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )

        axes = canvas.figure.axes[0]
        x_tick = self._major_tick_at(axes.xaxis, 5.0)
        y_tick = self._major_tick_at(axes.yaxis, 5.0)
        labels = {
            artist.get_text(): artist
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick-label"
        }
        renderer = canvas.canvas.get_renderer()
        for tick in (x_tick, y_tick):
            self.assertTrue(tick.tick1line.get_visible())
            self.assertTrue(tick.label1.get_visible())
            self.assertTrue(tick.label1.get_text())
        self.assertGreater(
            labels["X cutoff"].get_bbox_patch().get_window_extent(renderer).x0,
            x_tick.label1.get_window_extent(renderer).x1,
        )
        self.assertLess(
            labels["Y cutoff"].get_bbox_patch().get_window_extent(renderer).x1,
            y_tick.label1.get_window_extent(renderer).x0,
        )

    def test_xy_collision_lanes_and_leaders_remain_inside_expanded_canvas(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame({"X": [0.0, 5.0, 10.0], "Y": [0.0, 5.0, 10.0]})
        xy_settings = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )
        canvas.render(
            frame,
            ChartSettings(
                show_stat_table=False,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
                additional_x_axis_guides=[
                    additional_guides.default_additional_guide(value)
                    for value in (2.02, 2.08, 2.14)
                ],
                additional_primary_axis_guides=[
                    additional_guides.default_additional_guide(value)
                    for value in (6.02, 6.08, 6.14)
                ],
            ),
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )

        axes = canvas.figure.axes[0]
        renderer = canvas.canvas.get_renderer()
        labels = [
            artist
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick-value"
        ]
        leaders = [
            artist
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick-leader"
        ]
        self.assertEqual(len(labels), 6)
        self.assertGreaterEqual(len(leaders), 2)
        padding = renderer.points_to_pixels(3.5)
        for label in labels:
            bounds = label.get_window_extent(renderer)
            self.assertGreaterEqual(bounds.x0, padding)
            self.assertGreaterEqual(bounds.y0, padding)
            self.assertLessEqual(
                bounds.x1,
                canvas.figure.bbox.width - padding,
            )
            self.assertLessEqual(
                bounds.y1,
                canvas.figure.bbox.height - padding,
            )

    def test_hidpi_collision_overflow_keeps_qt_canvas_and_blit_sizes_in_sync(self):
        from easygraph.plotting.canvas import PlotCanvas

        baseline = PlotCanvas()
        collision = PlotCanvas()
        self.addCleanup(baseline.close)
        self.addCleanup(collision.close)
        for plot_canvas in (baseline, collision):
            plot_canvas.canvas._set_device_pixel_ratio(2.0)

        frame = pd.DataFrame({"X": [0.0, 5.0, 10.0], "Y": [0.0, 5.0, 10.0]})
        xy_settings = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )
        common = {
            "show_stat_table": False,
            "auto_x_range": False,
            "x_min": 0.0,
            "x_max": 10.0,
            "auto_y_range": False,
            "y_min": 0.0,
            "y_max": 10.0,
        }
        baseline.render(
            frame,
            ChartSettings(**common),
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )
        collision.render(
            frame,
            ChartSettings(
                **common,
                additional_x_axis_guides=[
                    additional_guides.default_additional_guide(value)
                    for value in (3.0, 3.1, 3.2)
                ],
            ),
            xy_settings=xy_settings,
            column_ids=["x", "y"],
        )
        self.qapp.processEvents()
        collision.canvas.draw()

        self.assertLessEqual(
            collision.canvas.width(),
            baseline.canvas.width() + 1,
        )
        self.assertLess(
            collision.canvas.height(),
            baseline.canvas.height() * 1.5,
        )
        self.assertAlmostEqual(
            collision.figure.bbox.width,
            collision.canvas.width()
            * collision.canvas.device_pixel_ratio,
            delta=2.0,
        )
        self.assertAlmostEqual(
            collision.figure.bbox.height,
            collision.canvas.height()
            * collision.canvas.device_pixel_ratio,
            delta=2.0,
        )
        self.assertIsNotNone(collision._blit_background)
        x0, y0, x1, y1 = collision._blit_background.get_extents()
        self.assertAlmostEqual(x1 - x0, collision.figure.bbox.width, delta=2.0)
        self.assertAlmostEqual(y1 - y0, collision.figure.bbox.height, delta=2.0)
        clean_buffer = bytes(collision.canvas.buffer_rgba())

        target = next(
            target
            for target in collision._interaction_targets
            if target.get("bbox") is not None
        )
        collision._set_feedback_patch(
            "_hover_feedback_patch",
            target["bbox"],
            selected=False,
        )
        self.qapp.processEvents()

        self.assertEqual(
            collision._canvas_size,
            (collision.canvas.width(), collision.canvas.height()),
        )
        self.assertIsNotNone(collision._blit_background)
        collision._remove_feedback_patch("_hover_feedback_patch")
        self.qapp.processEvents()
        self.assertEqual(bytes(collision.canvas.buffer_rgba()), clean_buffer)

    def test_canvas_passes_light_and_dark_theme_backgrounds_and_line_width(self):
        from easygraph.plotting.canvas import PlotCanvas
        from easygraph.palette import additional_guide_color
        from easygraph.settings import PRESETS

        for preset_name in ("Paper Clean", "Dark Slide"):
            with self.subTest(preset=preset_name):
                canvas = PlotCanvas()
                self.addCleanup(canvas.close)
                settings = ChartSettings(
                    preset=preset_name,
                    show_stat_table=False,
                    auto_y_range=False,
                    y_min=0.0,
                    y_max=10.0,
                    additional_guide_line_width=1.9,
                    additional_guide_palette="Presentation",
                    additional_primary_axis_guides=[
                        {
                            **additional_guides.default_additional_guide(5.25),
                            "show_line": True,
                            "text": "auto label",
                            "show_label_background": True,
                        },
                        {
                            **additional_guides.default_additional_guide(6.25),
                            "show_line": False,
                            "show_value_with_text": True,
                            "text": "line label",
                            "text_color_mode": "match_line",
                            "color_index": 1,
                        }
                    ],
                )

                canvas.render(self.df, settings)

                guide_artists = [
                    artist
                    for artist in canvas.figure.axes[0].get_children()
                    if artist.get_gid() in {
                        "additional-grid-line",
                        "additional-tick-label",
                    }
                ]
                line = next(
                    artist
                    for artist in guide_artists
                    if artist.get_gid() == "additional-grid-line"
                )
                labels = {
                    artist.get_text(): artist
                    for artist in guide_artists
                    if artist.get_gid() == "additional-tick-label"
                }
                self.assertEqual(line.get_linestyle(), "--")
                self.assertEqual(line.get_linewidth(), 1.9)
                self.assertEqual(
                    labels["auto label"].get_bbox_patch().get_facecolor(),
                    to_rgba(PRESETS[preset_name]["background"], 0.75),
                )
                automatic_color = (
                    "#222222"
                    if PRESETS[preset_name]["background"] == "#FFFFFF"
                    else "#F9FAFB"
                )
                self.assertEqual(
                    labels["auto label"].get_color(),
                    automatic_color,
                )
                expected_line_color = additional_guide_color(
                    settings,
                    settings.additional_primary_axis_guides[1],
                )
                self.assertEqual(
                    labels["line label"].get_color(),
                    expected_line_color,
                )
                numeric_label = next(
                    artist
                    for artist in canvas.figure.axes[0].get_children()
                    if artist.get_gid() == "additional-tick-value"
                    and math.isclose(
                        float(artist.get_text()),
                        6.25,
                    )
                )
                self.assertEqual(
                    numeric_label.get_color(),
                    expected_line_color,
                )

    def test_out_of_range_long_label_does_not_create_artist_or_enlarge_canvas(self):
        from easygraph.plotting.canvas import PlotCanvas

        baseline = PlotCanvas()
        outside = PlotCanvas()
        self.addCleanup(baseline.close)
        self.addCleanup(outside.close)
        common = {
            "show_stat_table": False,
            "auto_y_range": False,
            "y_min": 0.0,
            "y_max": 10.0,
        }
        baseline.render(self.df, ChartSettings(**common))
        outside.render(
            self.df,
            ChartSettings(
                **common,
                additional_primary_axis_guides=[
                    {
                        **additional_guides.default_additional_guide(1000.0),
                        "show_line": True,
                        "text": "an extremely long label that is outside the axis",
                        "show_label_background": True,
                    }
                ],
            ),
        )

        self.assertEqual(outside.canvas.size(), baseline.canvas.size())
        self.assertEqual(
            outside.figure.get_size_inches().tolist(),
            baseline.figure.get_size_inches().tolist(),
        )
        self.assertFalse(
            any(
                artist.get_gid() == "additional-tick-label"
                for artist in outside.figure.axes[0].get_children()
            )
        )

    def test_ridge_labels_at_both_x_limits_expand_into_visible_canvas(self):
        from easygraph.plotting.canvas import PlotCanvas

        for value, text_side in ((3.0, "left"), (9.0, "right")):
            with self.subTest(value=value, text_side=text_side):
                canvas = PlotCanvas()
                self.addCleanup(canvas.close)
                canvas.render(
                    self.df,
                    ChartSettings(
                        chart_type="Ridge",
                        show_stat_table=False,
                        auto_y_range=False,
                        y_min=3.0,
                        y_max=9.0,
                        additional_primary_axis_guides=[
                            {
                                **additional_guides.default_additional_guide(value),
                                "text": "long boundary label with background",
                                "text_side": text_side,
                                "vertical_position": "below",
                                "show_label_background": True,
                            }
                        ],
                    ),
                )

                axes = canvas.figure.axes[0]
                label = next(
                    artist
                    for artist in axes.get_children()
                    if artist.get_gid() == "additional-tick-label"
                )
                bounds = label.get_bbox_patch().get_window_extent(
                    canvas.canvas.get_renderer()
                )
                padding = canvas.canvas.get_renderer().points_to_pixels(3.5)
                self.assertGreaterEqual(bounds.x0, padding)
                self.assertLessEqual(
                    bounds.x1,
                    canvas.figure.bbox.width - padding,
                )

    def test_ridge_guide_and_axis_title_clear_statistics_table(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            self.df,
            ChartSettings(
                chart_type="Ridge",
                show_stat_table=True,
                additional_guide_font_size=18,
                additional_primary_axis_guides=[
                    {
                        **additional_guides.default_additional_guide(5.0),
                        "text": "Cutoff label with long text\nSecond line",
                        "vertical_position": "below",
                        "show_label_background": True,
                    }
                ],
            ),
        )

        axes = canvas.figure.axes[0]
        table_axes = canvas.figure.axes[1]
        renderer = canvas.canvas.get_renderer()
        label = next(
            artist
            for artist in axes.get_children()
            if artist.get_gid() == "additional-tick-label"
        )
        label_bounds = label.get_bbox_patch().get_window_extent(renderer)
        axis_label_bounds = axes.xaxis.label.get_window_extent(renderer)
        table_bounds = table_axes.get_window_extent(renderer)
        axes_bounds = axes.get_window_extent(renderer)
        required_gap = renderer.points_to_pixels(3.5)
        self.assertGreater(table_bounds.x0, axes_bounds.x1)
        self.assertAlmostEqual(table_bounds.y0, axes_bounds.y0)
        self.assertAlmostEqual(table_bounds.y1, axes_bounds.y1)
        self.assertFalse(label_bounds.overlaps(table_bounds))
        self.assertFalse(axis_label_bounds.overlaps(table_bounds))
        legend_bounds = axes.get_legend().get_window_extent(renderer)
        self.assertLessEqual(legend_bounds.y1 + required_gap, min(label_bounds.y0, axis_label_bounds.y0))
        self.assertGreaterEqual(legend_bounds.y0, required_gap)
