"""Exact table MIME content and clipboard lifetime across QApplication exit."""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys

import shiboken6
from PySide6.QtWidgets import QApplication

from easygraph.clipboard_table import (
    CellMerge,
    ClipboardTable,
    clipboard_table_to_html,
    clipboard_table_to_tsv,
)
from easygraph.ui.table_clipboard_mime import set_table_clipboard_mime
from tests.easygraph_case import EasyGraphQtTestCase


ROOT = Path(__file__).resolve().parents[1]


class TableClipboardMimeTests(EasyGraphQtTestCase):
    def test_native_mime_keeps_exact_merged_html_and_tsv_after_factory_returns(self):
        clipboard = QApplication.clipboard()
        self.addCleanup(clipboard.clear)
        table = ClipboardTable(
            [["WT", ""], ["Control", "Drug"], ["25%", "50％"]],
            [CellMerge(0, 0, colspan=2)],
            header_rows=2,
        )
        text = clipboard_table_to_tsv(table)
        html = clipboard_table_to_html(table)

        set_table_clipboard_mime(text, html)
        self.qapp.processEvents()

        mime = clipboard.mimeData()
        self.assertFalse(shiboken6.createdByPython(mime))
        self.assertEqual(mime.text(), text)
        self.assertEqual(mime.html(), html)
        self.assertEqual(set(mime.formats()), {"text/plain", "text/html"})

    def test_repeated_copy_replaces_native_mime_without_changing_text(self):
        clipboard = QApplication.clipboard()
        self.addCleanup(clipboard.clear)
        for text in ("WT\t", "25%\t50％", "Control\nDay 1"):
            html = "<table><tr><td colspan=\"2\">" + text + "</td></tr></table>"
            set_table_clipboard_mime(text, html)
            self.assertEqual(clipboard.text(), text)
            self.assertEqual(clipboard.mimeData().html(), html)

    def test_table_mime_survives_python_and_qapplication_shutdown(self):
        environment = os.environ.copy()
        environment["QT_QPA_PLATFORM"] = "offscreen"
        environment["PYTHONPATH"] = str(ROOT / "src")
        for explicit_quit in (False, True):
            with self.subTest(explicit_quit=explicit_quit):
                code = f"""
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
from easygraph.ui.table_clipboard_mime import set_table_clipboard_mime

app = QApplication([])
html = '<table data-easygraph-header-rows="2"><tr><td colspan="2">WT</td></tr><tr><td>25%</td><td>50%</td></tr></table>'
set_table_clipboard_mime('WT\\t\\n25%\\t50%', html)
assert app.clipboard().mimeData().html() == html
if {explicit_quit!r}:
    QTimer.singleShot(0, app.quit)
    app.exec()
assert app.clipboard().mimeData().html() == html
print('clipboard-ready', flush=True)
"""
                result = subprocess.run(
                    [sys.executable, "-c", code],
                    cwd=ROOT,
                    env=environment,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=30,
                )
                diagnostics = f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
                self.assertIn("clipboard-ready", result.stdout, msg=diagnostics)
                self.assertEqual(result.returncode, 0, msg=diagnostics)
