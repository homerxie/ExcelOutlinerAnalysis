"""The plot-order editor preserves table structure and survives project reload."""
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import mock

import pandas as pd

from easygraph.data import group_keys
from easygraph.project_io import read_workbook_project, write_project
from easygraph.ui import main_window
from tests.easygraph_case import EasyGraphQtTestCase


class GroupedOrderIntegrationTests(EasyGraphQtTestCase):
    def grouped_window(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame(
            [[1, 3, 5, 7, 9, 11], [2, 4, 6, 8, 10, 12]],
            columns=['Loose first', 'Control', 'Dose', 'Loose middle', 'Control', 'Dose'],
        ))
        header = window.table.horizontalHeader()
        for columns, name in (([1, 2], 'A'), ([4, 5], 'B')):
            header.select_parent_columns(columns)
            window.grouping_controls.merge_selected_headers(name)
        return window, window._group_user_keys()

    def test_mixed_block_and_member_order_changes_only_plot_and_roundtrips(self):
        window, ids = self.grouped_window()
        sheet = window.workbook.active_sheet
        before_cells = window.table.table_model.cells_copy()
        before_ids = list(sheet.column_ids)
        before_grouping = asdict(sheet.grouping)
        expected = [ids[index] for index in (5, 4, 3, 2, 1, 0)]
        with mock.patch.object(main_window, 'run_grouped_order_dialog', return_value=expected):
            window.edit_group_order()
        self.assertEqual(window.settings.group_order, 'Manual')
        self.assertEqual(window.settings.manual_group_order, expected)
        self.assertEqual(window.table.table_model.cells_copy(), before_cells)
        self.assertEqual(sheet.column_ids, before_ids)
        self.assertEqual(asdict(sheet.grouping), before_grouping)
        for chart_type in ('Box', 'Bar', 'Violin', 'Ridge'):
            with self.subTest(chart_type=chart_type):
                window.chart_type.setCurrentText(chart_type)
                window.update_settings()
                window.render()
                self.assertEqual(window.canvas._group_layout.order, tuple(expected))
                self.assertEqual([parent.label for parent in window.canvas._group_layout.parents], ['B', 'A'])
        window._store_active_sheet()
        with TemporaryDirectory() as directory:
            project = Path(directory) / 'ordered.eg'
            write_project(project, window.workbook)
            loaded = read_workbook_project(project).active_sheet
        self.assertEqual(loaded.settings.manual_group_order, expected)
        self.assertEqual(loaded.column_ids, before_ids)
        self.assertEqual(asdict(loaded.grouping), before_grouping)
        restored_frame = window._user_group_sheet_dataframe(loaded)
        window.canvas.render(restored_frame, loaded.settings, grouping=loaded.grouping,
                             column_ids=group_keys(restored_frame))
        self.assertEqual(window.canvas._group_layout.order, tuple(expected))

    def test_editor_starts_from_current_sort_and_includes_hidden_subgroups(self):
        window, ids = self.grouped_window()
        window.group_order.setCurrentText('Mean descending')
        window.update_settings()
        window.settings.group_hidden = [ids[1]]
        before = deepcopy(window.settings)
        with mock.patch.object(main_window, 'run_grouped_order_dialog', return_value=None) as dialog:
            window.edit_group_order()
        self.assertEqual(dialog.call_args.args[1], [ids[index] for index in (0, 2, 1, 3, 5, 4)])
        self.assertEqual(dialog.call_args.args[2], ids)
        self.assertEqual(window.settings, before)

    def test_new_member_joins_parent_in_editor_after_manual_block_reorder(self):
        window, ids = self.grouped_window()
        expected = [ids[index] for index in (5, 4, 3, 2, 1, 0)]
        with mock.patch.object(main_window, 'run_grouped_order_dialog', return_value=expected):
            window.edit_group_order()
        self.select_table_range(window.table, 0, 1, 0, 1)
        window.grouping_controls.insert_selected_subgroup(True)
        new_id = window.workbook.active_sheet.column_ids[2]
        with mock.patch.object(main_window, 'run_grouped_order_dialog', return_value=None) as dialog:
            window.edit_group_order()
        self.assertEqual(dialog.call_args.args[1], expected[:5] + [new_id] + expected[5:])
        window.render()
        self.assertEqual(list(window.canvas._group_layout.order), dialog.call_args.args[1])

    def test_without_parents_uses_original_single_list(self):
        window = self.make_window()
        with mock.patch.object(main_window, 'run_group_order_dialog', return_value=None) as single, \
             mock.patch.object(main_window, 'run_grouped_order_dialog') as grouped:
            window.edit_group_order()
        single.assert_called_once()
        grouped.assert_not_called()
