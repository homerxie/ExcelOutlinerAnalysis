from __future__ import annotations

import numpy as np
import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.additional_guides import default_additional_guide
from easygraph.grouping import GroupingSettings
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings, LEGEND_POSITION_INSIDE


class RidgeLayoutTests(EasyGraphQtTestCase):
    def make_canvas(self):
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        return canvas

    @staticmethod
    def table_axis(canvas):
        return next(axis for axis in canvas.figure.axes if axis.get_gid() == "ridge-stat-table")

    def assert_rows_align(self, canvas):
        axes = canvas.figure.axes[0]
        table = self.table_axis(canvas)
        layout = canvas._group_layout
        label_x = min(text.get_position()[0] for text in table.texts)
        group_labels = [text for text in table.texts if text.get_position()[0] == label_x]
        self.assertEqual([text.get_text() for text in group_labels], [layout.labels[group] for group in layout.order])
        np.testing.assert_allclose(table.get_ylim(), axes.get_ylim())
        renderer = canvas.canvas.get_renderer()
        for group, label in zip(layout.order, group_labels):
            position = layout.coordinate(group, ridge=True)
            expected_y = axes.transData.transform((0, position))[1]
            row_text = [text for text in table.texts if text.get_position()[1] == label.get_position()[1]]
            self.assertGreater(len(row_text), 1)
            for text in row_text:
                bounds = text.get_window_extent(renderer)
                self.assertAlmostEqual((bounds.y0 + bounds.y1) / 2, expected_y, places=5)

    def assert_artist_inside(self, canvas, artist):
        bounds = artist.get_window_extent(canvas.canvas.get_renderer())
        figure = canvas.figure.bbox
        self.assertGreaterEqual(bounds.x0, figure.x0 - 0.01)
        self.assertGreaterEqual(bounds.y0, figure.y0 - 0.01)
        self.assertLessEqual(bounds.x1, figure.x1 + 0.01)
        self.assertLessEqual(bounds.y1, figure.y1 + 0.01)

    def test_right_table_tracks_sorted_rows_and_preserves_plot_dimensions(self):
        canvas = self.make_canvas()
        frame = pd.DataFrame({"Control": [1, 2, 3], "High": [21, 22, 23], "Low": [8, 9, 10]})
        settings = ChartSettings(chart_type="Ridge", group_order="Mean descending", show_stat_table=True, show_points=True)
        canvas.render(frame, settings)
        axes = canvas.figure.axes[0]
        table = self.table_axis(canvas)
        self.assert_rows_align(canvas)
        self.assertEqual([label.get_text() for label in axes.get_yticklabels()], ["High", "Low", "Control"])
        self.assertGreater(table.get_position().x0, axes.get_position().x1)
        self.assertAlmostEqual(axes.get_position().width * canvas.figure.get_figwidth(), settings.width / 2.54, delta=0.015)
        self.assertAlmostEqual(axes.get_position().height * canvas.figure.get_figheight(), settings.height / 2.54, delta=0.015)
        for text in table.texts:
            self.assert_artist_inside(canvas, text)

    def test_grouped_empty_slots_and_split_secondary_keep_rows_aligned(self):
        ids = ["a-control", "a-dose", "b-control", "b-dose"]
        frame = pd.DataFrame([[1, np.nan, 11, 14], [2, np.nan, 12, 15], [3, np.nan, 13, 16]], columns=["Control", "Dose", "Control", "Dose"])
        grouping = GroupingSettings(
            parents=[
                {"id": "a", "name": "Experiment A", "column_ids": ids[:2]},
                {"id": "b", "name": "Experiment B", "column_ids": ids[2:]},
            ],
            shared_subgroups=True,
            subgroup_ids=dict(zip(ids, ["control", "dose", "control", "dose"])),
        )
        for split in (False, True):
            with self.subTest(split=split):
                canvas = self.make_canvas()
                settings = ChartSettings(
                    chart_type="Ridge", group_order="Mean descending", show_stat_sample_size=True,
                    extra_custom_overlay=True, custom_overlay_secondary_axis=True, split_secondary_axis=split,
                    custom_overlay_series=[{"name": "Response", "values": dict(zip(ids, [10, 20, 30, 40]))}],
                )
                canvas.render(frame, settings, grouping=grouping, column_ids=ids)
                self.assert_rows_align(canvas)
                axes = canvas.figure.axes[0]
                table = self.table_axis(canvas)
                secondary = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
                self.assertGreater(table.get_position().x0, max(axes.get_position().x1, secondary.get_position().x1))
                sample_header = next(text for text in table.texts if text.get_text() == "Sample")
                empty_position = canvas._group_layout.coordinate(ids[1], ridge=True)
                empty_sample = next(text for text in table.texts if text.get_position() == (sample_header.get_position()[0], empty_position))
                self.assertEqual(empty_sample.get_text(), "0")
                self.assertEqual(canvas._group_layout.positions["b-dose"], 3.7)

    def test_wrapped_bottom_legend_clears_axis_and_guides(self):
        canvas = self.make_canvas()
        settings = ChartSettings(
            chart_type="Ridge", width=6, height=4,
            show_line_overlay=True, line_overlay_stat="Mean", show_line_values=True,
            legend_font_size=14, legend_width=3, legend_columns=2, legend_auto_width=False,
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Very long treatment response overlay", "values": {"A": 3, "B": 5}},
                {"name": "Another extended response overlay", "values": {"A": 4, "B": 6}},
            ],
            additional_primary_axis_guides=[{
                **default_additional_guide(3),
                "text": "Threshold below the X axis\nwith another line",
                "vertical_position": "below", "show_label_background": True,
            }],
        )
        canvas.render(pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]}), settings)
        self.assert_rows_align(canvas)
        axes = canvas.figure.axes[0]
        renderer = canvas.canvas.get_renderer()
        legend = axes.get_legend()
        self.assertTrue(any("\n" in text.get_text() for text in legend.get_texts()))
        self.assert_artist_inside(canvas, legend)
        legend_bounds = legend.get_window_extent(renderer)
        self.assertLess(legend_bounds.y1, axes.xaxis.get_tightbbox(renderer).y0)
        for bounds in canvas._additional_guide_label_bounds(axes.get_children(), renderer):
            self.assertLess(legend_bounds.y1, bounds.y0)

    def test_oversized_bottom_legend_expands_canvas_without_shrinking_plot(self):
        canvas = self.make_canvas()
        settings = ChartSettings(
            chart_type="Ridge", width=4, height=4, show_stat_table=False,
            legend_font_size=16, legend_columns=1, legend_auto_width=True,
            extra_custom_overlay=True,
            custom_overlay_series=[{"name": "A deliberately very wide custom response legend entry", "values": {"A": 3, "B": 4}}],
        )
        canvas.render(pd.DataFrame({"A": [1, 2, 3], "B": [2, 3, 4]}), settings)
        axes = canvas.figure.axes[0]
        self.assert_artist_inside(canvas, axes.get_legend())
        self.assertAlmostEqual(axes.get_position().width * canvas.figure.get_figwidth(), settings.width / 2.54, delta=0.015)
        self.assertAlmostEqual(axes.get_position().height * canvas.figure.get_figheight(), settings.height / 2.54, delta=0.015)

    def test_explicit_inside_legend_and_hidden_legend_remain_supported(self):
        frame = pd.DataFrame({"A": [1, 2, 3], "B": [2, 3, 4]})
        for visible in (False, True):
            with self.subTest(visible=visible):
                canvas = self.make_canvas()
                settings = ChartSettings(chart_type="Ridge", show_legend=visible, legend_position=LEGEND_POSITION_INSIDE, show_line_overlay=True, line_overlay_stat="Mean")
                canvas.render(frame, settings)
                self.assert_rows_align(canvas)
                axes = canvas.figure.axes[0]
                legend = axes.get_legend()
                if visible:
                    renderer = canvas.canvas.get_renderer()
                    self.assertTrue(axes.get_window_extent(renderer).contains(*legend.get_window_extent(renderer).get_points()[0]))
                    self.assertTrue(axes.get_window_extent(renderer).contains(*legend.get_window_extent(renderer).get_points()[1]))
                else:
                    self.assertIsNone(legend)

    def test_single_group_small_overlap_keeps_table_header_visible(self):
        canvas = self.make_canvas()
        settings = ChartSettings(chart_type="Ridge", ridge_overlap=0.2, width=6, height=4, stat_table_font_size=18)
        canvas.render(pd.DataFrame({"Control\nGroup": [1, 2, 3]}), settings)
        self.assert_rows_align(canvas)
        for text in self.table_axis(canvas).texts:
            self.assert_artist_inside(canvas, text)

    def test_row_bands_fit_text_and_keep_their_height_when_plot_grows(self):
        frame = pd.DataFrame({"Control": [1, 2, 3], "Low dose\nSecond line": [4, 5, 6], "High dose": [7, 8, 9]})
        heights_by_plot_size = []
        for plot_height in (8, 18):
            with self.subTest(plot_height=plot_height):
                canvas = self.make_canvas()
                settings = ChartSettings(chart_type="Ridge", height=plot_height, stat_table_font_size=10)
                canvas.render(frame, settings)
                self.assert_rows_align(canvas)
                table = self.table_axis(canvas)
                vertical_edges = []
                for collection in table.collections:
                    for segment in collection.get_segments():
                        display = collection.get_transform().transform(segment)
                        if np.isclose(display[0, 0], display[1, 0]) and not np.isclose(display[0, 1], display[1, 1]):
                            vertical_edges.append(sorted(display[:, 1]))
                row_heights = []
                row_bounds = []
                for group in canvas._group_layout.order:
                    expected_y = table.transData.transform((0, canvas._group_layout.coordinate(group, ridge=True)))[1]
                    matching_edges = [edge for edge in vertical_edges if abs(sum(edge) / 2 - expected_y) < 0.01]
                    self.assertTrue(matching_edges, f"No centered row band for {group}")
                    bottom, top = matching_edges[0]
                    row_heights.append((top - bottom) / canvas.figure.dpi)
                    row_bounds.append((bottom, top))
                self.assertLess(row_heights[0], 0.45)
                self.assertLess(row_heights[2], 0.45)
                self.assertGreater(row_heights[1], row_heights[0])
                for upper_row, lower_row in zip(row_bounds, row_bounds[1:]):
                    self.assertGreater(upper_row[0], lower_row[1])
                heights_by_plot_size.append(row_heights)
        np.testing.assert_allclose(heights_by_plot_size[0], heights_by_plot_size[1], atol=0.01)

    def test_row_bands_fit_text_after_overlay_labels_expand_category_limits(self):
        for label_font_size, stat_font_size in ((25, 9), (25, 28), (50, 9), (50, 28)):
            with self.subTest(label_font_size=label_font_size, stat_font_size=stat_font_size):
                canvas = self.make_canvas()
                settings = ChartSettings(
                    chart_type="Ridge", height=4, show_points=False, show_outliers=False,
                    show_line_overlay=True, line_overlay_stat="Mean", show_line_values=True,
                    line_value_position="Below", line_value_font_size=label_font_size,
                    stat_table_font_size=stat_font_size,
                )
                canvas.render(self.df, settings)
                self.assert_rows_align(canvas)
                table = self.table_axis(canvas)
                renderer = canvas.canvas.get_renderer()
                for text in table.texts:
                    self.assert_artist_inside(canvas, text)
                self.assertLess(table.get_ylim()[0], -0.4)
                vertical_edges = [
                    sorted(display[:, 1])
                    for collection in table.collections
                    for segment in collection.get_segments()
                    for display in [collection.get_transform().transform(segment)]
                    if np.isclose(display[0, 0], display[1, 0])
                    and not np.isclose(display[0, 1], display[1, 1])
                ]
                for group in canvas._group_layout.order:
                    position = canvas._group_layout.coordinate(group, ridge=True)
                    expected_y = table.transData.transform((0, position))[1]
                    bottom, top = next(
                        edge for edge in vertical_edges
                        if abs(sum(edge) / 2 - expected_y) < 0.01
                    )
                    self.assertAlmostEqual(
                        (top - bottom) / canvas.figure.dpi,
                        canvas._stat_table_row_height_inches(settings),
                        delta=0.01,
                    )
                    for text in table.texts:
                        if text.get_position()[1] == position:
                            bounds = text.get_window_extent(renderer)
                            self.assertGreaterEqual(bounds.y0, bottom)
                            self.assertLessEqual(bounds.y1, top)

    def test_table_header_outside_category_axes_remains_selectable(self):
        canvas = self.make_canvas()
        settings = ChartSettings(chart_type="Ridge", height=4, stat_table_font_size=28)
        canvas.render(self.df, settings)
        table = self.table_axis(canvas)
        renderer = canvas.canvas.get_renderer()
        header = next(text for text in table.texts if text.get_text() == "Mean")
        header_center = header.get_window_extent(renderer).get_points().mean(axis=0)
        self.assertFalse(table.get_window_extent(renderer).contains(*header_center))
        target = next(target for target in canvas._interaction_targets if target["kind"] == "stats_table")
        self.assertTrue(target["bbox"].contains(*header_center))
