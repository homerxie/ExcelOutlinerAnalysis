import csv
from io import StringIO
import unittest

from easygraph.clipboard_table import (
    CellMerge,
    ClipboardTable,
    clipboard_table_from_html,
    clipboard_table_to_html,
    clipboard_table_to_tsv,
)


class ClipboardTableTests(unittest.TestCase):
    def test_office_export_uses_spans_and_blanks_covered_tsv_cells(self):
        table = ClipboardTable(
            [["Treatment", "ignored", "Control"], ["Day 1", "Day 2", "Day 1"]],
            [CellMerge(0, 0, colspan=2)],
            header_rows=2,
        )

        html = clipboard_table_to_html(table)

        self.assertIn('colspan="2"', html)
        self.assertIn('data-easygraph-header-rows="2"', html)
        self.assertNotIn("ignored", html)
        self.assertEqual(html.count("<th"), 5)
        self.assertEqual(
            clipboard_table_to_tsv(table),
            "Treatment\t\tControl\nDay 1\tDay 2\tDay 1",
        )
        self.assertEqual(
            clipboard_table_from_html(html),
            ClipboardTable(
                [["Treatment", "", "Control"], ["Day 1", "Day 2", "Day 1"]],
                table.merges,
                header_rows=2,
            ),
        )

    def test_roundtrip_preserves_special_characters_and_multiline_cells(self):
        table = ClipboardTable(
            [["  中文 <&> \"quoted\"  ", "line 1\n\nline\t2\n", "25%", "x\u00a0y"]],
            header_rows=0,
        )

        html = clipboard_table_to_html(table)

        self.assertNotIn("<&>", html)
        self.assertIn("&lt;&amp;&gt;", html)
        self.assertEqual(clipboard_table_from_html(html), table)
        self.assertEqual(
            list(csv.reader(StringIO(clipboard_table_to_tsv(table)), delimiter="\t")),
            table.rows,
        )

    def test_tsv_retains_trailing_empty_columns_and_rows(self):
        table = ClipboardTable([["A", "", ""], ["", "", ""]])

        self.assertEqual(clipboard_table_to_tsv(table), "A\t\t\n\t\t")

    def test_excel_html_import_preserves_merged_headers_and_displayed_percent(self):
        html = """Version:1.0
StartHTML:00000097
EndHTML:00001234
<html xmlns:x="urn:schemas-microsoft-com:office:excel">
<head><style>.xl1 {mso-number-format:0%;}</style></head><body>
<!--StartFragment--><table>
 <tr height=20>
  <td colspan=2 class=xl1>实验组</td>
  <td colspan=2>Control</td>
 </tr>
 <tr><td>Day <b>1</b></td><td>Day 2</td><td>Day 1</td><td>Day 2</td></tr>
 <tr><td class=xl1 x:num="0.25">25%</td><td>30％</td><td></td><td>40%</td></tr>
</table><!--EndFragment--></body></html>"""

        table = clipboard_table_from_html(html)

        self.assertEqual(
            table,
            ClipboardTable(
                [["实验组", "", "Control", ""], ["Day 1", "Day 2", "Day 1", "Day 2"],
                 ["25%", "30％", "", "40%"]],
                [CellMerge(0, 0, colspan=2), CellMerge(0, 2, colspan=2)],
            ),
        )

    def test_row_and_column_spans_do_not_shift_following_cells(self):
        html = """<table>
<tr><td colspan=2>Group</td><td rowspan=2>Label</td><td>Other</td></tr>
<tr><td>A</td><td>B</td><td>C</td></tr>
<tr><td>D</td><td>E</td><td>F</td><td>G</td></tr>
</table>"""

        table = clipboard_table_from_html(html)

        self.assertEqual(
            table,
            ClipboardTable(
                [["Group", "", "Label", "Other"], ["A", "B", "", "C"],
                 ["D", "E", "F", "G"]],
                [CellMerge(0, 0, colspan=2), CellMerge(0, 2, rowspan=2)],
            ),
        )
        self.assertEqual(clipboard_table_from_html(clipboard_table_to_html(table)), table)

    def test_word_formatting_entities_and_multiline_cells(self):
        html = """<table><tr><td><p class=MsoNormal><span>First &amp; second</span></p>
<p>Third<br style='mso-data-placement:same-cell'>Fourth</p></td>
<td>A&nbsp;B</td></tr></table>"""

        self.assertEqual(
            clipboard_table_from_html(html).rows,
            [["First & second\nThird\nFourth", "A\u00a0B"]],
        )

    def test_first_table_only_and_nested_tables_do_not_create_extra_columns(self):
        html = """<table><tr><td>Outer<table><tr><td>inner</td></tr></table></td>
<td>next</td></tr></table><table><tr><td>second table</td></tr></table>"""

        self.assertEqual(clipboard_table_from_html(html).rows, [["Outerinner", "next"]])

    def test_script_and_style_contents_are_not_cell_values(self):
        html = """<table><tr><td>A<style>.bad{}</style><script>bad()</script>B</td></tr></table>"""

        self.assertEqual(clipboard_table_from_html(html).rows, [["AB"]])

    def test_header_metadata_is_optional_and_preserved_for_parent_only(self):
        table = ClipboardTable([["A", ""]], [CellMerge(0, 0, colspan=2)], header_rows=1)

        self.assertEqual(clipboard_table_from_html(clipboard_table_to_html(table)), table)
        self.assertIsNone(clipboard_table_from_html("<table><tr><th>A</th></tr></table>").header_rows)
        self.assertIsNone(clipboard_table_from_html(
            '<table data-easygraph-header-rows="bad"><tr><td>A</td></tr></table>'
        ).header_rows)

    def test_ragged_rows_are_padded_and_optional_closing_tags_work(self):
        html = "<table><tr><td>A<td>B<tr><td>C</table>"

        self.assertEqual(clipboard_table_from_html(html).rows, [["A", "B"], ["C", ""]])

    def test_invalid_or_huge_spans_fall_back_without_allocating_huge_tables(self):
        for html in (
            "<table><tr><td colspan=1000000000>A</td></tr></table>",
            "<table><tr><td rowspan=1000000000>A</td></tr></table>",
            "<table><tr><td rowspan=10000 colspan=10000>A</td></tr></table>",
            "<table><tr><td>A</td><td rowspan=2>B</td></tr><tr><td colspan=2>C</td></tr></table>",
            "<table></table>",
            "plain text only",
        ):
            with self.subTest(html=html):
                self.assertIsNone(clipboard_table_from_html(html))

    def test_export_rejects_out_of_bounds_and_overlapping_merges(self):
        for merges in (
            [CellMerge(0, 0, colspan=3)],
            [CellMerge(0, 0, colspan=2), CellMerge(0, 1, rowspan=2)],
            [CellMerge(-1, 0)],
        ):
            with self.subTest(merges=merges):
                table = ClipboardTable([["A", "B"], ["C", "D"]], merges)
                with self.assertRaises(ValueError):
                    clipboard_table_to_html(table)
