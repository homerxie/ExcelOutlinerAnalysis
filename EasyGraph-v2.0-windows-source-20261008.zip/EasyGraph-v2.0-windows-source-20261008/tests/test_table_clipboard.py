from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.table_clipboard import (
    clear_selected_table_items,
    cut_selection_to_tsv,
    paste_start_cell,
    paste_rows_into_table,
    paste_tsv_into_table,
    selected_range_to_tsv,
    tsv_to_rows,
)


class TableClipboardTests(EasyGraphQtTestCase):
    def test_selected_range_to_tsv_quotes_multiline_cells(self):
        table = DataTable(1, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells([["Control\nDay 1", "Treatment"]], column_count=2)
        self.select_table_range(table, 0, 0, 0, 1)

        self.assertEqual(selected_range_to_tsv(table), '"Control\nDay 1"\tTreatment')

    def test_selected_range_to_tsv_returns_empty_for_no_selection(self):
        table = DataTable(1, 1)
        self.addCleanup(table.deleteLater)

        self.assertEqual(selected_range_to_tsv(table), "")

    def test_clear_selected_table_items_clears_selection_and_restores_signals(self):
        table = DataTable(1, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells([["A", "B"]], column_count=2)
        self.select_table_range(table, 0, 0, 0, 1)
        table.blockSignals(True)

        changed = clear_selected_table_items(table)

        self.assertTrue(changed)
        self.assertTrue(table.signalsBlocked())
        self.assertEqual(table.table_model.cell_text(0, 0), "")
        self.assertEqual(table.table_model.cell_text(0, 1), "")

    def test_clear_selected_table_items_returns_false_without_selection(self):
        table = DataTable(1, 1)
        self.addCleanup(table.deleteLater)
        table.table_model.set_cell_text(0, 0, "A")

        self.assertFalse(clear_selected_table_items(table))
        self.assertEqual(table.table_model.cell_text(0, 0), "A")

    def test_cut_selection_to_tsv_returns_text_and_clears_selected_cells(self):
        table = DataTable(1, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells([["A", "B"]], column_count=2)
        self.select_table_range(table, 0, 0, 0, 1)

        text = cut_selection_to_tsv(table)

        self.assertEqual(text, "A\tB")
        self.assertEqual(table.table_model.cell_text(0, 0), "")
        self.assertEqual(table.table_model.cell_text(0, 1), "")

    def test_tsv_to_rows_preserves_quoted_multiline_cells(self):
        self.assertEqual(tsv_to_rows('"Control\nDay 1"\tTreatment\n1\t2'), [["Control\nDay 1", "Treatment"], ["1", "2"]])

    def test_paste_start_cell_defaults_negative_indexes_to_origin(self):
        self.assertEqual(paste_start_cell(-1, -1), (0, 0))
        self.assertEqual(paste_start_cell(2, -1), (2, 0))
        self.assertEqual(paste_start_cell(-1, 3), (0, 3))

    def test_paste_rows_into_table_expands_and_writes_cells(self):
        table = DataTable(1, 1)
        self.addCleanup(table.deleteLater)
        table.blockSignals(True)

        paste_rows_into_table(table, [["1", "2"], ["3", "4"]], start_row=1, start_col=1)

        self.assertTrue(table.signalsBlocked())
        self.assertEqual(table.table_model.rowCount(), 3)
        self.assertEqual(table.table_model.columnCount(), 3)
        self.assertEqual(table.table_model.cell_text(0, 1), "Group 2")
        self.assertEqual(table.table_model.cell_text(0, 2), "Group 3")
        self.assertEqual(table.table_model.cell_text(1, 1), "1")
        self.assertEqual(table.table_model.cell_text(1, 2), "2")
        self.assertEqual(table.table_model.cell_text(2, 1), "3")
        self.assertEqual(table.table_model.cell_text(2, 2), "4")

    def test_paste_tsv_into_table_parses_text_and_ignores_empty_clipboard(self):
        table = DataTable(1, 1)
        self.addCleanup(table.deleteLater)
        table.setCurrentIndex(table.table_model.index(-1, -1))

        self.assertFalse(paste_tsv_into_table(table, ""))
        self.assertTrue(paste_tsv_into_table(table, "A\tB\n1\t2"))

        self.assertEqual(table.table_model.rowCount(), 2)
        self.assertEqual(table.table_model.columnCount(), 2)
        self.assertEqual(table.table_model.cell_text(0, 0), "A")
        self.assertEqual(table.table_model.cell_text(1, 1), "2")
