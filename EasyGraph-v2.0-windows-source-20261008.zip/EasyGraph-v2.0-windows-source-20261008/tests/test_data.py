import math
from unittest import mock

import numpy as np
import pandas as pd

from tests.easygraph_case import EasyGraphTestCase
from easygraph import data, overlay_series, palette
from easygraph.settings import ChartSettings, STAT_TABLE_OPTIONS


class DataTests(EasyGraphTestCase):

    def test_percentage_samples_are_used_in_plotting_order_and_overlays(self):
        frame = pd.DataFrame({"A": ["25%", "75%"], "B": ["10％", "30%"]})
        settings = ChartSettings(
            group_order="Mean ascending",
            line_overlay_stat="Mean",
            extra_custom_overlay=True,
            custom_overlay_series=[{"name": "Target", "values": {"A": "60%", "B": "40％"}}],
        )

        prepared = data.prepare_plot_frames(frame, settings)
        self.assertEqual(prepared.groups, ("B", "A"))
        self.assertEqual(prepared.visible["value"].tolist(), [0.1, 0.3, 0.25, 0.75])
        self.assertEqual(data.values_for_group(frame, "A").tolist(), [0.25, 0.75])
        series = overlay_series.line_overlay_series(prepared.visible, settings)
        self.assertEqual(series[0]["values"], [0.2, 0.5])
        self.assertEqual(series[1]["values"], [0.4, 0.6])
        self.assertEqual(frame.iloc[0, 0], "25%")

    def test_prepare_plot_frames_converts_each_wide_column_once(self):
        df = pd.DataFrame(
            [
                [1, "bad", 10],
                [2, 4, 11],
            ],
            columns=["A", "A", "B"],
        )
        settings = ChartSettings(
            group_hidden=["B"],
            group_order="Mean descending",
        )

        with mock.patch.object(
            data.pd,
            "to_numeric",
            wraps=data.pd.to_numeric,
        ) as to_numeric:
            prepared = data.prepare_plot_frames(df, settings)

        self.assertEqual(to_numeric.call_count, df.shape[1])
        self.assertEqual(prepared.groups, ("B", "A [2]", "A [1]"))
        self.assertEqual(prepared.full["group"].tolist(), ["B", "B", "A [2]", "A [1]", "A [1]"])
        self.assertEqual(prepared.full["value"].tolist(), [10.0, 11.0, 4.0, 1.0, 2.0])
        self.assertEqual(prepared.visible["group"].tolist(), ["A [2]", "A [1]", "A [1]"])

    def test_prepare_plot_frames_matches_compatibility_wrappers(self):
        df = pd.DataFrame(
            {
                "B": [3, "", 5],
                "A": [1, 2, np.nan],
                "C": [8, 7, 9],
            }
        )
        settings = ChartSettings(
            group_hidden=["A"],
            group_order="Median ascending",
        )

        prepared = data.prepare_plot_frames(df, settings)

        pd.testing.assert_frame_equal(
            prepared.full,
            data.prepare_plot_data(df, settings, include_hidden=True),
        )
        pd.testing.assert_frame_equal(
            prepared.visible,
            data.prepare_plot_data(df, settings),
        )

    def test_wide_table_is_converted_to_plot_data(self):
        clean = data.prepare_plot_data(self.df, self.settings)

        self.assertEqual(list(self.df.columns), ["Control", "Low dose", "High dose"])
        self.assertEqual(len(clean), 103)
        self.assertEqual(set(clean.columns), {"group", "value"})
        self.assertEqual(set(clean["group"]), {"Control", "Low dose", "High dose"})

    def test_outlier_detection_finds_sample_high_dose_outlier(self):
        clean = data.prepare_plot_data(self.df, self.settings)
        outliers = data.mark_outliers(clean, self.settings)

        self.assertEqual(len(outliers), 1)
        self.assertEqual(outliers.iloc[0]["group"], "High dose")
        self.assertAlmostEqual(outliers.iloc[0]["value"], 8.7)

    def test_box_whisker_modes_map_to_matplotlib_whis_values(self):
        self.assertEqual(data.box_whis("Tukey 1.5 IQR"), 1.5)
        self.assertEqual(data.box_whis("Min-Max"), (0, 100))
        self.assertEqual(data.box_whis("Percentile 5-95"), (5, 95))
        self.assertEqual(data.box_whis("Percentile 10-90"), (10, 90))

    def test_default_jitter_mode_is_quasirandom(self):
        self.assertEqual(ChartSettings().jitter_mode, "Quasirandom")

    def test_group_and_value_labels_map_by_chart_type(self):
        settings = ChartSettings(x_label="Group label", y_label="Value label")

        settings.chart_type = "Box"
        self.assertEqual(data.axis_labels_for_chart(settings), ("Group label", "Value label"))

        settings.chart_type = "Violin"
        self.assertEqual(data.axis_labels_for_chart(settings), ("Group label", "Value label"))

        settings.chart_type = "Ridge"
        self.assertEqual(data.axis_labels_for_chart(settings), ("Value label", "Group label"))

    def test_group_filter_hides_groups_from_plot_data_without_deleting_table_data(self):
        df = pd.DataFrame({
            "B": [3, 4],
            "A": [1, 2],
            "C": [5, 6],
        })
        settings = ChartSettings(group_hidden=["A"])

        clean = data.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["B", "C"])

        full_clean = data.prepare_plot_data(df, settings, include_hidden=True)
        self.assertEqual(list(full_clean["group"].drop_duplicates()), ["B", "A", "C"])

    def test_hidden_group_color_still_occupies_palette_color(self):
        df = pd.DataFrame({
            "A": [1, 2],
            "B": [3, 4],
        })
        settings = ChartSettings(group_hidden=["A"])
        full_clean = data.prepare_plot_data(df, settings, include_hidden=True)
        clean = data.prepare_plot_data(df, settings)
        all_groups = list(full_clean["group"].drop_duplicates())

        full_palette = palette.palette_for(full_clean, settings, color_groups=all_groups)
        visible_palette = palette.palette_for(clean, settings, color_groups=all_groups)

        self.assertEqual(visible_palette, [full_palette[1]])

    def test_line_overlay_statistics_use_mean_or_median(self):
        df = pd.DataFrame({
            "group": ["A", "A", "A", "B", "B"],
            "value": [1, 2, 100, 4, 8],
        })
        settings = ChartSettings(line_overlay_stat="Median")

        self.assertEqual(overlay_series.group_overlay_statistics(df, settings), [("A", 2.0), ("B", 6.0)])

        settings.line_overlay_stat = "Mean"
        self.assertEqual(overlay_series.group_overlay_statistics(df, settings), [("A", 103 / 3), ("B", 6.0)])

    def test_custom_overlay_series_can_create_multiple_plot_lines(self):
        clean = data.prepare_plot_data(self.df, self.settings)
        settings = ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_count=2,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Index", "values": {"Control": "10", "Low dose": "", "High dose": "30"}},
            ],
        )

        series = overlay_series.line_overlay_series(clean, settings)

        self.assertEqual([item["name"] for item in series], ["Target", "Index"])
        self.assertEqual(series[0]["values"], [5.0, 6.0, 7.0])
        self.assertTrue(math.isnan(series[1]["values"][1]))

    def test_custom_overlay_series_can_use_secondary_axis(self):
        clean = data.prepare_plot_data(self.df, self.settings)
        settings = ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        series = overlay_series.line_overlay_series(clean, settings)

        self.assertTrue(series[0]["secondary_axis"])

    def test_stat_table_data_includes_selected_plot_statistics(self):
        df = pd.DataFrame({
            "group": ["A", "A", "A", "B", "B"],
            "value": [1, 2, 3, 10, 14],
        })
        settings = ChartSettings(line_value_decimals=1)
        settings.show_stat_q1 = True
        settings.show_stat_q3 = True
        settings.show_stat_sd = True
        settings.show_stat_sample_size = True
        settings.show_stat_min = False
        settings.show_stat_sem = False

        groups, rows = overlay_series.stat_table_data(df, settings)

        self.assertEqual(groups, ["A", "B"])
        self.assertIn(("Mean", ["2.0", "12.0"]), rows)
        self.assertIn(("Median", ["2.0", "12.0"]), rows)
        self.assertIn(("Q1", ["1.5", "11.0"]), rows)
        self.assertIn(("Q3", ["2.5", "13.0"]), rows)
        self.assertIn(("Max", ["3.0", "14.0"]), rows)
        self.assertIn(("SD", ["1.0", "2.8"]), rows)
        self.assertIn(("Sample", ["3", "2"]), rows)
        self.assertNotIn("Min", [label for label, _ in rows])
        self.assertNotIn("SEM", [label for label, _ in rows])

    def test_percentage_stat_table_formats_values_but_keeps_sample_counts(self):
        settings = ChartSettings(
            show_stat_sample_size=True,
            statistic_formats={"Mean": {"decimals": 1}},
        )
        frame = pd.DataFrame({"group": ["A", "A"], "value": [0.25, 0.75]})

        groups, rows = overlay_series.stat_table_data(frame, settings, percentage=True)

        self.assertEqual(groups, ["A"])
        self.assertIn(("Mean", ["50.0%"]), rows)
        self.assertIn(("Sample", ["2"]), rows)
        self.assertEqual(
            overlay_series.format_overlay_value(0.125, settings, percentage=True),
            "12.50%",
        )

    def test_stat_table_defaults_to_mean_median_min_max(self):
        settings = ChartSettings()
        enabled_labels = [
            label
            for setting_name, label in STAT_TABLE_OPTIONS
            if getattr(settings, setting_name)
        ]

        self.assertEqual(enabled_labels, ["Mean", "Median", "Max", "Min"])

    def test_duplicate_group_names_are_independent_for_plotting(self):
        df = pd.DataFrame(
            [
                [1, 3, 10],
                [2, 4, 11],
            ],
            columns=["A", "A", "B"],
        )

        clean = data.prepare_plot_data(df, self.settings)

        self.assertEqual(list(clean["group"].drop_duplicates()), ["A [1]", "A [2]", "B"])
        self.assertEqual(clean[clean["group"] == "A [1]"]["value"].tolist(), [1.0, 2.0])
        self.assertEqual(clean[clean["group"] == "A [2]"]["value"].tolist(), [3.0, 4.0])

    def test_duplicate_group_names_sort_by_independent_values(self):
        df = pd.DataFrame(
            [
                [10, 30, 1],
                [20, 40, 2],
            ],
            columns=["A", "A", "B"],
        )
        settings = ChartSettings(group_order="Mean descending")

        clean = data.prepare_plot_data(df, settings)

        self.assertEqual(list(clean["group"].drop_duplicates()), ["A [2]", "A [1]", "B"])

    def test_blank_project_data_has_three_empty_columns(self):
        df = data.blank_project_data()

        self.assertEqual(list(df.columns), ["Group 1", "Group 2", "Group 3"])
        self.assertEqual(df.shape[1], 3)
        self.assertTrue((df == "").all().all())

    def test_blank_xy_data_has_ten_rows_and_two_empty_y_columns(self):
        df = data.blank_xy_data()

        self.assertEqual(list(df.columns), ["X", "1Y", "2Y"])
        self.assertEqual(df.shape, (10, 3))
        self.assertTrue((df == "").all().all())
