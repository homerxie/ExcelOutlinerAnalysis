import ast
from pathlib import Path

from tests.easygraph_case import ROOT, EasyGraphTestCase
from easygraph.ui import main_window


DIRECT_OWNER_TESTS = (
    "tests/test_data.py",
    "tests/test_data_module.py",
    "tests/test_data_table.py",
    "tests/test_overlay_series_module.py",
    "tests/test_palette.py",
    "tests/test_palette_module.py",
    "tests/test_project_io.py",
    "tests/test_prism_mapping.py",
    "tests/test_prism_pzfx.py",
    "tests/test_settings_module.py",
    "tests/test_table_clipboard.py",
    "tests/test_table_snapshot.py",
    "tests/test_template_io.py",
)


class ArchitectureTests(EasyGraphTestCase):
    def test_prism_import_uses_the_documented_one_way_boundaries(self):
        prism_package = ROOT / "src" / "easygraph" / "prism_io"
        self.assertEqual(
            {path.name for path in prism_package.glob("*.py")},
            {"__init__.py", "models.py", "mapping.py", "pzfx.py"},
        )
        forbidden_parts = {
            "PySide6",
            "matplotlib",
            "seaborn",
            "scipy",
            "ui",
            "main_window",
            "project_io",
            "spreadsheet_io",
        }
        for path in prism_package.glob("*.py"):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            modules = {
                alias.name
                for node in ast.walk(tree)
                if isinstance(node, ast.Import)
                for alias in node.names
            }
            modules.update(
                node.module
                for node in ast.walk(tree)
                if isinstance(node, ast.ImportFrom) and node.module is not None
            )
            with self.subTest(path=path.name):
                self.assertFalse(
                    any(
                        forbidden in module.split(".")
                        for module in modules
                        for forbidden in forbidden_parts
                    )
                )

        dialog_path = ROOT / "src" / "easygraph" / "ui" / "prism_import_dialog.py"
        dialog_tree = ast.parse(dialog_path.read_text(encoding="utf-8"))
        dialog_imports = {
            (node.module, alias.name)
            for node in ast.walk(dialog_tree)
            if isinstance(node, ast.ImportFrom)
            for alias in node.names
        }
        self.assertIn(("easygraph.prism_io", "inspect_pzfx"), dialog_imports)
        self.assertIn(("easygraph.prism_io", "import_pzfx_table"), dialog_imports)
        self.assertIn(("ui_prism_import_dialog", "Ui_PrismImportDialog"), dialog_imports)
        self.assertTrue((ROOT / "ui" / "prism_import_dialog.ui").is_file())
        self.assertTrue((ROOT / "src" / "ui_prism_import_dialog.py").is_file())
        self.assertNotIn("prism", (ROOT / "src" / "easygraph" / "spreadsheet_io.py").read_text(encoding="utf-8").casefold())

    def test_main_window_has_single_ui_owner(self):
        app_path = ROOT / "src" / "app.py"
        owner_path = ROOT / "src" / "easygraph" / "ui" / "main_window.py"
        self.assertTrue(owner_path.exists())

        app_tree = ast.parse(app_path.read_text(encoding="utf-8"))
        owner_tree = ast.parse(owner_path.read_text(encoding="utf-8"))
        top_level_shape = [
            (
                "from",
                node.module,
                tuple(alias.name for alias in node.names),
            )
            if isinstance(node, ast.ImportFrom)
            else ("function", node.name)
            if isinstance(node, ast.FunctionDef)
            else ("guard",)
            if isinstance(node, ast.If)
            else (type(node).__name__,)
            for node in app_tree.body
        ]
        self.assertEqual(
            top_level_shape,
            [
                ("from", "__future__", ("annotations",)),
                ("from", "PySide6.QtCore", ("QTimer",)),
                (
                    "from",
                    "easygraph.app_icon",
                    ("configure_application_icon", "configure_platform_identity"),
                ),
                ("from", "easygraph.app_preferences", ("install_app_translator",)),
                ("from", "easygraph.app_theme", ("apply_app_theme",)),
                (
                    "from",
                    "easygraph.file_association",
                    (
                        "EasyGraphApplication",
                        "project_path_from_arguments",
                        "register_windows_project_file_association",
                    ),
                ),
                ("from", "easygraph.ui.main_window", ("MainWindow",)),
                ("function", "main"),
                ("guard",),
            ],
        )
        execution_guard = app_tree.body[-1]
        self.assertIsInstance(execution_guard, ast.If)
        self.assertTrue(
            isinstance(execution_guard.test, ast.Compare)
            and isinstance(execution_guard.test.left, ast.Name)
            and execution_guard.test.left.id == "__name__"
            and len(execution_guard.test.ops) == 1
            and isinstance(execution_guard.test.ops[0], ast.Eq)
            and len(execution_guard.test.comparators) == 1
            and isinstance(execution_guard.test.comparators[0], ast.Constant)
            and execution_guard.test.comparators[0].value == "__main__"
            and len(execution_guard.body) == 1
            and isinstance(execution_guard.body[0], ast.Expr)
            and isinstance(execution_guard.body[0].value, ast.Call)
            and isinstance(execution_guard.body[0].value.func, ast.Name)
            and execution_guard.body[0].value.func.id == "main"
            and not execution_guard.body[0].value.args
            and not execution_guard.body[0].value.keywords
            and not execution_guard.orelse
        )
        owner_classes = {
            node.name for node in owner_tree.body if isinstance(node, ast.ClassDef)
        }
        owner_assignments = {
            target.id
            for node in owner_tree.body
            if isinstance(node, ast.Assign)
            for target in node.targets
            if isinstance(target, ast.Name)
        }
        self.assertIn("MainWindow", owner_classes)
        self.assertIn("RenderMode", owner_classes)
        self.assertTrue(
            {
                "APP_CONTROL_HEIGHT",
                "APP_RENDER_DEBOUNCE_MS",
                "COMBO_MIN_WIDTH",
                "COMBO_TEXT_WIDTH_PADDING",
            }.issubset(owner_assignments)
        )
        self.assertFalse(
            any(
                isinstance(node, ast.ClassDef)
                and node.name in {"MainWindow", "RenderMode"}
                for node in app_tree.body
            )
        )
        self.assertFalse(
            any(
                isinstance(node, (ast.Import, ast.ImportFrom))
                and (
                    any(alias.name == "app" for alias in node.names)
                    if isinstance(node, ast.Import)
                    else node.module == "app"
                )
                for node in ast.walk(owner_tree)
            )
        )
        self.assertFalse(
            any(
                isinstance(node, ast.FunctionDef) and node.name == "__getattr__"
                for tree in (app_tree, owner_tree)
                for node in tree.body
            )
        )
        self.assertFalse(
            any(
                isinstance(node, ast.ImportFrom)
                and any(alias.name == "*" for alias in node.names)
                for tree in (app_tree, owner_tree)
                for node in ast.walk(tree)
            )
        )

        app_imports = {
            (node.module, alias.name)
            for node in app_tree.body
            if isinstance(node, ast.ImportFrom) and node.module != "__future__"
            for alias in node.names
        }
        self.assertEqual(
            app_imports,
            {
                ("PySide6.QtCore", "QTimer"),
                ("easygraph.app_icon", "configure_application_icon"),
                ("easygraph.app_icon", "configure_platform_identity"),
                ("easygraph.app_preferences", "install_app_translator"),
                ("easygraph.app_theme", "apply_app_theme"),
                ("easygraph.file_association", "EasyGraphApplication"),
                ("easygraph.file_association", "project_path_from_arguments"),
                (
                    "easygraph.file_association",
                    "register_windows_project_file_association",
                ),
                ("easygraph.ui.main_window", "MainWindow"),
            },
        )
        app_definitions = {
            node.name
            for node in app_tree.body
            if isinstance(node, (ast.ClassDef, ast.FunctionDef))
        }
        self.assertNotIn("export_suffix_for_filter", app_definitions)
        self.assertTrue(
            {
                "APP_CONTROL_HEIGHT",
                "APP_RENDER_DEBOUNCE_MS",
                "COMBO_MIN_WIDTH",
                "COMBO_TEXT_WIDTH_PADDING",
            }.isdisjoint(owner_assignments & {
                target.id
                for node in app_tree.body
                if isinstance(node, ast.Assign)
                for target in node.targets
                if isinstance(target, ast.Name)
            })
        )

        owner_import_bindings = [
            alias.asname or alias.name
            for node in owner_tree.body
            if isinstance(node, (ast.Import, ast.ImportFrom))
            for alias in node.names
            if alias.name != "*"
        ]
        self.assertEqual(len(owner_import_bindings), len(set(owner_import_bindings)))

    def test_app_entrypoint_reexports_only_main_window(self):
        import app

        self.assertIs(app.MainWindow, main_window.MainWindow)

    def test_legacy_programmatic_ui_builders_are_removed(self):
        legacy_builders = (
            "_build_menu",
            "_build_layout",
            "_build_controls",
            "_chart_group",
            "_font_group",
            "_axis_group",
            "_points_group",
            "_outlier_group",
            "_specific_group",
        )
        for name in legacy_builders:
            with self.subTest(name=name):
                self.assertFalse(hasattr(main_window.MainWindow, name))

    def test_main_window_uses_table_controller_boundary(self):
        source = Path(main_window.__file__).read_text(encoding="utf-8")
        tree = ast.parse(source)
        imported_names = {
            (node.module, alias.name)
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom)
            for alias in node.names
        }
        self.assertIn(("easygraph.ui.table_controller", "TableController"), imported_names)
        self.assertIn(("easygraph.ui.table_controller", "TableControllerHooks"), imported_names)
        for old_name in (
            "TableHistoryState",
            "run_table_history_mutation",
            "navigation_delta",
            "next_table_cell",
            "build_table_snapshot",
            "snapshot_shape",
            "selected_range_to_tsv",
            "cut_selection_to_tsv",
            "paste_tsv_into_table",
            "clear_selected_table_items",
            "insert_sample_row",
            "append_group_column",
            "remove_current_or_last_group_column",
            "populate_table_from_dataframe",
            "table_sample_dataframe",
            "refresh_qtable_structure",
        ):
            with self.subTest(old_name=old_name):
                self.assertFalse(any(name == old_name for _module, name in imported_names))

    def test_main_window_uses_dialog_boundary(self):
        window_tree = ast.parse(Path(main_window.__file__).read_text(encoding="utf-8"))
        window_imports = {
            (node.module, alias.name)
            for node in ast.walk(window_tree)
            if isinstance(node, ast.ImportFrom)
            for alias in node.names
        }
        for name in (
            "run_group_order_dialog",
            "run_checklist_filter_dialog",
            "run_group_colors_dialog",
            "run_overlay_styles_dialog",
        ):
            self.assertIn(("easygraph.ui.dialogs", name), window_imports)
        self.assertNotIn(("ui_overlay_styles_dialog", "Ui_OverlayStylesDialog"), window_imports)

        dialogs_path = ROOT / "src" / "easygraph" / "ui" / "dialogs.py"
        dialogs_tree = ast.parse(dialogs_path.read_text(encoding="utf-8"))
        imported_modules = {
            node.module
            for node in ast.walk(dialogs_tree)
            if isinstance(node, ast.ImportFrom) and node.module is not None
        }
        imported_modules.update(
            alias.name
            for node in ast.walk(dialogs_tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        )
        for forbidden in (
            "app",
            "matplotlib",
            "seaborn",
            "scipy",
            "plotting",
            "project_io",
            "template_io",
            "spreadsheet_io",
        ):
            with self.subTest(forbidden=forbidden):
                self.assertFalse(any(forbidden in module.split(".") for module in imported_modules))

    def test_direct_owner_tests_do_not_use_app_facade(self):
        for relative_path in DIRECT_OWNER_TESTS:
            tree = ast.parse((ROOT / relative_path).read_text(encoding="utf-8"))
            violations = []
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    violations.extend(
                        f"import {alias.name}"
                        for alias in node.names
                        if alias.name == "app"
                    )
                elif isinstance(node, ast.ImportFrom):
                    if node.module == "app":
                        violations.append("from app import")
                    if node.module == "tests.easygraph_case" and any(
                        alias.name == "app" for alias in node.names
                    ):
                        violations.append("easygraph_case app import")
                elif (
                    isinstance(node, ast.Attribute)
                    and isinstance(node.value, ast.Name)
                    and node.value.id == "app"
                ):
                    violations.append(f"app.{node.attr}")
            with self.subTest(path=relative_path):
                self.assertEqual(violations, [])

    def test_tests_only_import_app_for_entrypoint_identity(self):
        allowed_path = "tests/test_architecture.py"
        allowed_method = "test_app_entrypoint_reexports_only_main_window"

        for test_path in sorted((ROOT / "tests").rglob("*.py")):
            relative_path = test_path.relative_to(ROOT).as_posix()
            tree = ast.parse(test_path.read_text(encoding="utf-8"))
            allowed_nodes: set[int] = set()
            allowed_attribute_id: int | None = None
            allowed_binding_load_id: int | None = None
            if relative_path == allowed_path:
                allowed_function = next(
                    node
                    for node in ast.walk(tree)
                    if isinstance(node, ast.FunctionDef)
                    and node.name == allowed_method
                )
                allowed_nodes = {id(node) for node in ast.walk(allowed_function)}
                allowed_imports = [
                    alias
                    for node in ast.walk(allowed_function)
                    if isinstance(node, ast.Import)
                    for alias in node.names
                    if alias.name == "app"
                ]
                allowed_attributes = [
                    node
                    for node in ast.walk(allowed_function)
                    if isinstance(node, ast.Attribute)
                    and isinstance(node.value, ast.Name)
                    and node.value.id == "app"
                ]
                self.assertEqual(len(allowed_imports), 1)
                self.assertIsNone(allowed_imports[0].asname)
                self.assertEqual(len(allowed_attributes), 1)
                self.assertEqual(allowed_attributes[0].attr, "MainWindow")
                identity_calls = [
                    node
                    for node in ast.walk(allowed_function)
                    if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and isinstance(node.func.value, ast.Name)
                    and node.func.value.id == "self"
                    and node.func.attr == "assertIs"
                    and len(node.args) == 2
                    and node.args[0] is allowed_attributes[0]
                    and isinstance(node.args[1], ast.Attribute)
                    and isinstance(node.args[1].value, ast.Name)
                    and node.args[1].value.id == "main_window"
                    and node.args[1].attr == "MainWindow"
                ]
                self.assertEqual(len(identity_calls), 1)
                allowed_attribute_id = id(allowed_attributes[0])
                allowed_binding_load_id = id(allowed_attributes[0].value)

            app_bindings = {
                alias.asname or "app"
                for node in ast.walk(tree)
                if isinstance(node, ast.Import)
                for alias in node.names
                if alias.name == "app"
            }
            app_bindings.update(
                alias.asname or "app"
                for node in ast.walk(tree)
                if isinstance(node, ast.ImportFrom)
                and node.module == "tests.easygraph_case"
                for alias in node.names
                if alias.name == "app"
            )
            changed = True
            while changed:
                changed = False
                for node in ast.walk(tree):
                    if (
                        isinstance(node, ast.Assign)
                        and isinstance(node.value, ast.Name)
                        and node.value.id in app_bindings
                    ):
                        for target in node.targets:
                            if (
                                isinstance(target, ast.Name)
                                and target.id not in app_bindings
                            ):
                                app_bindings.add(target.id)
                                changed = True
                    elif (
                        isinstance(node, ast.AnnAssign)
                        and isinstance(node.target, ast.Name)
                        and isinstance(node.value, ast.Name)
                        and node.value.id in app_bindings
                        and node.target.id not in app_bindings
                    ):
                        app_bindings.add(node.target.id)
                        changed = True

            violations = []
            for node in ast.walk(tree):
                is_allowed_node = id(node) in allowed_nodes
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name == "app" and (
                            not is_allowed_node or alias.asname is not None
                        ):
                            violations.append("import app")
                elif isinstance(node, ast.ImportFrom):
                    if node.module == "app":
                        violations.append("from app import")
                    if node.module == "tests.easygraph_case" and any(
                        alias.name == "app" for alias in node.names
                    ):
                        violations.append("easygraph_case app import")
                elif (
                    isinstance(node, ast.Attribute)
                    and isinstance(node.value, ast.Name)
                    and node.value.id in app_bindings
                    and id(node) != allowed_attribute_id
                ):
                    violations.append(f"{node.value.id}.{node.attr}")
                elif (
                    isinstance(node, ast.Name)
                    and isinstance(node.ctx, ast.Load)
                    and node.id in app_bindings
                    and id(node) != allowed_binding_load_id
                ):
                    violations.append(f"load {node.id}")

            with self.subTest(path=relative_path):
                self.assertEqual(violations, [])

    def test_line_style_delegate_has_single_ui_owner(self):
        window_path = Path(main_window.__file__).resolve()
        window_tree = ast.parse(window_path.read_text(encoding="utf-8"))
        self.assertTrue(
            any(
                isinstance(node, ast.ImportFrom)
                and node.module == "easygraph.ui.line_style_delegate"
                and any(alias.name == "LineStyleItemDelegate" for alias in node.names)
                for node in ast.walk(window_tree)
            )
        )
        self.assertFalse(
            any(
                isinstance(node, ast.ClassDef)
                and node.name == "LineStyleItemDelegate"
                for node in ast.walk(window_tree)
            )
        )

        delegate_path = window_path.parent / "line_style_delegate.py"
        delegate_tree = ast.parse(delegate_path.read_text(encoding="utf-8"))
        imported_modules = {
            node.module
            for node in ast.walk(delegate_tree)
            if isinstance(node, ast.ImportFrom) and node.module is not None
        }
        imported_modules.update(
            f"{node.module}.{alias.name}"
            for node in ast.walk(delegate_tree)
            if isinstance(node, ast.ImportFrom) and node.module is not None
            for alias in node.names
            if alias.name != "*"
        )
        imported_modules.update(
            alias.name
            for node in ast.walk(delegate_tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        )
        imported_aliases = [
            alias
            for node in ast.walk(delegate_tree)
            if isinstance(node, (ast.Import, ast.ImportFrom))
            for alias in node.names
        ]
        forbidden_parts = {
            "app",
            "canvas",
            "matplotlib",
            "numpy",
            "pandas",
            "project_io",
            "scipy",
            "seaborn",
            "spreadsheet_io",
            "template_io",
        }
        for module in imported_modules:
            with self.subTest(module=module):
                parts = set(module.split("."))
                self.assertFalse(parts & forbidden_parts)
                self.assertFalse(any(part.startswith("ui_") for part in parts))
        self.assertFalse(
            any(
                alias.name == "MainWindow" or alias.asname == "MainWindow"
                for alias in imported_aliases
            )
        )
