from __future__ import annotations

import pathlib
import tempfile
from types import SimpleNamespace
from unittest import mock

import pandas as pd
from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import QFileDialog, QLineEdit, QMessageBox

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.project_io import write_project
from easygraph.settings import ChartSettings
from easygraph.ui import main_window


class UnsavedChangesTests(EasyGraphQtTestCase):
    def window(self) -> main_window.MainWindow:
        window = main_window.MainWindow(initial_render=False)
        self.addCleanup(window.deleteLater)
        return window

    def test_content_comparison_detects_changes_and_undo_back_to_baseline(self):
        window = self.window()
        self.assertFalse(window.has_unsaved_changes())

        window.table.table_model.set_cell_text(1, 0, "999")
        self.assertTrue(window.has_unsaved_changes())

        window.undo_table_change()
        self.assertFalse(window.has_unsaved_changes())

        original_title = window.title.toPlainText()
        window.title.setPlainText("Changed title")
        self.assertTrue(window.has_unsaved_changes())

        window.title.setPlainText(original_title)
        self.assertFalse(window.has_unsaved_changes())

    def test_deferred_initial_preview_keeps_an_unedited_window_clean(self):
        window = main_window.MainWindow(initial_render=False, defer_preview=True)
        self.addCleanup(window.deleteLater)
        self.assertFalse(window.has_unsaved_changes())

        window.initialize_preview(initial_render=True)

        self.assertFalse(window.has_unsaved_changes())

    def test_unsaved_check_commits_an_active_table_editor(self):
        window = self.window()
        window.show()
        index = window.table.table_model.index(1, 0)
        window.table.setCurrentIndex(index)
        window.table.edit(index)
        self.qapp.processEvents()
        editor = window.table.findChild(QLineEdit)
        self.assertIsNotNone(editor)

        editor.setText("pending edit")

        self.assertTrue(window.has_unsaved_changes())
        self.assertEqual(window.table.table_model.cell_text(1, 0), "pending edit")

    def test_unchanged_close_does_not_prompt(self):
        window = self.window()
        event = QCloseEvent()

        with mock.patch.object(window, "_prompt_unsaved_changes") as prompt:
            window.closeEvent(event)

        self.assertTrue(event.isAccepted())
        prompt.assert_not_called()

    def test_cancel_ignores_close_and_discard_accepts_close(self):
        window = self.window()
        window.title.setPlainText("Changed title")

        cancel_event = QCloseEvent()
        with mock.patch.object(window, "_prompt_unsaved_changes", return_value="cancel"):
            window.closeEvent(cancel_event)
        self.assertFalse(cancel_event.isAccepted())

        discard_event = QCloseEvent()
        with mock.patch.object(window, "_prompt_unsaved_changes", return_value="discard"):
            window.closeEvent(discard_event)
        self.assertTrue(discard_event.isAccepted())

    def test_save_accepts_close_and_updates_baseline(self):
        window = self.window()
        window.title.setPlainText("Changed title")
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "saved.eg"
            window.current_project = path
            event = QCloseEvent()

            with mock.patch.object(window, "_prompt_unsaved_changes", return_value="save"):
                window.closeEvent(event)

            self.assertTrue(event.isAccepted())
            self.assertTrue(path.is_file())
            self.assertFalse(window.has_unsaved_changes())

    def test_cancelled_save_as_ignores_close(self):
        window = self.window()
        window.title.setPlainText("Changed title")
        event = QCloseEvent()

        with mock.patch.object(window, "_prompt_unsaved_changes", return_value="save"):
            with mock.patch.object(QFileDialog, "getSaveFileName", return_value=("", "")):
                window.closeEvent(event)

        self.assertFalse(event.isAccepted())
        self.assertTrue(window.has_unsaved_changes())

    def test_save_failure_reports_error_and_ignores_close(self):
        window = self.window()
        window.current_project = pathlib.Path("/tmp/cannot-save.eg")
        window.title.setPlainText("Changed title")
        event = QCloseEvent()

        with mock.patch.object(window, "_prompt_unsaved_changes", return_value="save"):
            with mock.patch.object(main_window, "write_project", side_effect=OSError("disk full")):
                with mock.patch.object(QMessageBox, "critical") as critical:
                    window.closeEvent(event)

        self.assertFalse(event.isAccepted())
        self.assertTrue(window.has_unsaved_changes())
        critical.assert_called_once()
        self.assertEqual(critical.call_args.args[1], "Project save failed")
        self.assertIn("disk full", critical.call_args.args[2])

    def test_cancel_stops_every_content_replacement_before_its_chooser_or_load(self):
        window = self.window()
        window.title.setPlainText("Changed title")
        original_cells = window.table.table_model.cells_copy()

        with mock.patch.object(window, "_confirm_unsaved_changes", return_value=False):
            window.new_project()
            self.assertEqual(window.table.table_model.cells_copy(), original_cells)

            with mock.patch.object(QFileDialog, "getOpenFileName") as choose_open:
                window.open_project()
                choose_open.assert_not_called()

            with mock.patch.object(QFileDialog, "getOpenFileName") as choose_import:
                window.import_excel()
                choose_import.assert_not_called()

            with mock.patch.object(QFileDialog, "getOpenFileName") as choose_prism:
                window.import_prism_data()
                choose_prism.assert_not_called()

            with tempfile.NamedTemporaryFile(suffix=".eg") as recent:
                with mock.patch.object(window, "_load_project_path") as load_recent:
                    window.open_recent_project(pathlib.Path(recent.name))
                    load_recent.assert_not_called()

    def test_new_and_open_establish_clean_baselines(self):
        window = self.window()
        window.title.setPlainText("Changed title")
        with mock.patch.object(window, "_prompt_unsaved_changes", return_value="discard"):
            window.new_project()
        self.assertFalse(window.has_unsaved_changes())

        settings = ChartSettings(title="Loaded title")
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "loaded.eg"
            write_project(path, self.df, settings)
            window.title.setPlainText("Changed again")
            with mock.patch.object(window, "_prompt_unsaved_changes", return_value="discard"):
                with mock.patch.object(QFileDialog, "getOpenFileName", return_value=(str(path), "")):
                    window.open_project()

        self.assertEqual(window.settings.title, "Loaded title")
        self.assertFalse(window.has_unsaved_changes())

    def test_associated_project_path_opens_without_a_file_dialog(self):
        window = self.window()
        settings = ChartSettings(title="Opened from Finder")
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "associated.eg"
            write_project(path, self.df, settings)

            with mock.patch.object(QFileDialog, "getOpenFileName") as choose_open:
                opened = window.open_project_path(path)

        self.assertTrue(opened)
        choose_open.assert_not_called()
        self.assertEqual(window.settings.title, "Opened from Finder")
        self.assertEqual(window.current_project, path)
        self.assertFalse(window.has_unsaved_changes())

    def test_associated_project_path_reports_a_missing_file(self):
        window = self.window()
        missing = pathlib.Path("/tmp/missing-associated-project.eg")

        with mock.patch.object(QMessageBox, "critical") as critical:
            opened = window.open_project_path(missing)

        self.assertFalse(opened)
        critical.assert_called_once()
        self.assertEqual(critical.call_args.args[1], "Project open failed")

    def test_successful_excel_and_prism_imports_are_unsaved(self):
        imported = pd.DataFrame({"Imported": ["1", "2"]})

        excel_window = self.window()
        with mock.patch.object(QFileDialog, "getOpenFileName", return_value=("data.csv", "")):
            with mock.patch.object(main_window, "read_spreadsheet", return_value=(imported, [])), \
                 mock.patch.object(main_window, "choose_spreadsheet_sheets", side_effect=lambda _parent, sheets: sheets):
                excel_window.import_excel()
        self.assertTrue(excel_window.has_unsaved_changes())

        prism_window = self.window()
        result = SimpleNamespace(
            dataframe=imported,
            excluded_count=0,
            table=SimpleNamespace(display_title="Imported"),
        )
        with mock.patch.object(QFileDialog, "getOpenFileName", return_value=("data.pzfx", "")):
            with mock.patch.object(main_window, "choose_prism_tables", return_value=(result,)):
                prism_window.import_prism_data()
        self.assertTrue(prism_window.has_unsaved_changes())


if __name__ == "__main__":
    __import__("unittest").main()
