from __future__ import annotations

from copy import deepcopy
from unittest import mock

import pandas as pd
from PySide6.QtCore import QItemSelectionModel, QPoint, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMessageBox

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.data_table import DataTable
from easygraph.table_structure import (
    expanded_pair_columns,
    shift_cells_down,
    shift_cells_up,
)
from easygraph.workbook import SHEET_MODE_XY
from easygraph.xy_fitting import default_fit_spec


def action_with_text(menu, text: str):
    return next(action for action in menu.actions() if action.text() == text)


def submenu_with_text(menu, text: str):
    action = action_with_text(menu, text)
    submenu = action.menu()
    if submenu is None:
        raise AssertionError(f"{text!r} has no submenu")
    references = getattr(menu, "_test_submenu_references", [])
    references.extend((action, submenu))
    menu._test_submenu_references = references
    return submenu


def nested_action(menu, parent_text: str, child_text: str):
    submenu = submenu_with_text(menu, parent_text)
    action = action_with_text(submenu, child_text)
    menu._test_submenu_references.append(action)
    return action


def non_separator_texts(menu) -> list[str]:
    return [action.text() for action in menu.actions() if not action.isSeparator()]


def model_cells(table) -> list[list[str]]:
    return table.table_model.cells_copy()


class TableStructurePrimitiveTests(EasyGraphQtTestCase):
    def make_table(self, cells: list[list[str]]) -> DataTable:
        table = DataTable()
        self.addCleanup(table.close)
        table.table_model.replace_cells(cells)
        return table

    def test_cells_down_preserves_used_tail_and_shifts_a_multicell_range(self):
        table = self.make_table(
            [
                ["A", "B", "C"],
                ["a1", "b1", "c1"],
                ["a2", "b2", "c2"],
                ["a3", "b3", "c3"],
            ]
        )

        self.assertTrue(shift_cells_down(table.table_model, 1, (0, 1), 2))

        self.assertEqual(
            model_cells(table),
            [
                ["A", "B", "C"],
                ["", "", "c1"],
                ["", "", "c2"],
                ["a1", "b1", "c3"],
                ["a2", "b2", ""],
                ["a3", "b3", ""],
            ],
        )

    def test_cells_up_shifts_a_multicell_range_and_blanks_the_tail(self):
        table = self.make_table(
            [
                ["A", "B", "C"],
                ["a1", "b1", "c1"],
                ["a2", "b2", "c2"],
                ["a3", "b3", "c3"],
            ]
        )

        self.assertTrue(shift_cells_up(table.table_model, 1, (0, 1), 2))

        self.assertEqual(
            model_cells(table),
            [
                ["A", "B", "C"],
                ["a3", "b3", "c1"],
                ["", "", "c2"],
                ["", "", "c3"],
            ],
        )

    def test_xy_pair_expansion_deduplicates_touched_pair_halves(self):
        self.assertEqual(expanded_pair_columns((1,), 6), (0, 1))
        self.assertEqual(expanded_pair_columns((0, 1), 6), (0, 1))
        self.assertEqual(expanded_pair_columns((1, 2), 6), (0, 1, 2, 3))
        self.assertEqual(expanded_pair_columns((5,), 6), (4, 5))


class TableStructureContextMenuTests(EasyGraphQtTestCase):
    """Black-box coverage for the common Groups/XY structure workflow."""

    def make_xy_window(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        return window

    def set_groups_grid(self, window):
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": ["a1", "a2", "a3"],
                    "B": ["b1", "b2", "b3"],
                    "C": ["c1", "c2", "c3"],
                }
            )
        )
        window._table_controller.reset_history()
        return window.table.table_model

    def assert_common_context_menu_contract(self, window, table) -> None:
        self.assertEqual(
            table.contextMenuPolicy(),
            Qt.ContextMenuPolicy.CustomContextMenu,
        )
        self.assertEqual(
            table.horizontalHeader().contextMenuPolicy(),
            Qt.ContextMenuPolicy.CustomContextMenu,
        )
        self.assertEqual(
            table.verticalHeader().contextMenuPolicy(),
            Qt.ContextMenuPolicy.CustomContextMenu,
        )
        self.select_table_range(table, 1, 0, 1, 0)
        cell_menu = window.table_context_menu(table, "cells")
        self.assertEqual(
            non_separator_texts(cell_menu)[:6],
            ["Copy", "Paste", "Cut", "Clear Contents", "Insert", "Delete"],
        )
        insert_menu = submenu_with_text(cell_menu, "Insert")
        delete_menu = submenu_with_text(cell_menu, "Delete")
        self.assertEqual(
            non_separator_texts(insert_menu),
            ["Shift Cells Down", "Entire Row", *(
                ["Entire Column"] if window._is_xy_sheet()
                else ["Insert subgroup left", "Insert subgroup right"]
            )],
        )
        self.assertEqual(
            non_separator_texts(delete_menu),
            ["Shift Cells Up", "Entire Row", "Entire Column"],
        )
        self.assertNotIn("Shift Cells Right", non_separator_texts(insert_menu))
        self.assertNotIn("Shift Cells Left", non_separator_texts(delete_menu))

        table.selectRow(1)
        row_menu = window.table_context_menu(table, "rows")
        self.assertIsNone(action_with_text(row_menu, "Insert").menu())
        self.assertIsNone(action_with_text(row_menu, "Delete").menu())

        table.selectColumn(0)
        column_menu = window.table_context_menu(table, "columns")
        self.assertIsNone(action_with_text(column_menu, "Insert" if window._is_xy_sheet() else "Insert subgroup left").menu())
        self.assertIsNone(action_with_text(column_menu, "Delete").menu())

    def test_groups_and_xy_surfaces_share_the_excel_style_menu_contract(self):
        groups_window = self.make_window()
        self.assert_common_context_menu_contract(groups_window, groups_window.table)

        xy_window = self.make_xy_window()
        self.assert_common_context_menu_contract(xy_window, xy_window.table)
        self.assert_common_context_menu_contract(
            xy_window,
            xy_window.xy_independent_table,
        )

    def test_viewport_context_handlers_delegate_exactly_once(self):
        window = self.make_xy_window()
        position = QPoint(3, 4)
        with mock.patch.object(
            window,
            "_show_table_viewport_context_menu",
        ) as show_menu:
            window.show_table_context_menu(position)
            show_menu.assert_called_once_with(window.table, position)

        with mock.patch.object(
            window,
            "_show_table_viewport_context_menu",
        ) as show_menu:
            window.show_xy_independent_context_menu(position)
            show_menu.assert_called_once_with(window.xy_independent_table, position)

    def test_header_and_overlay_rows_disable_row_shifts_but_keep_column_actions(self):
        window = self.make_window()
        overlay = [{"name": "Limit", "values": {"A": "9", "B": "8"}}]
        window.settings.custom_overlay_series = overlay
        window.set_table_dataframe(
            pd.DataFrame({"A": ["1", "2"], "B": ["3", "4"]}),
            overlay,
        )

        for row in (0, 1):
            with self.subTest(row=row):
                self.select_table_range(window.table, row, 0, row, 0)
                menu = window.table_context_menu(window.table, "cells")
                self.assertFalse(
                    nested_action(menu, "Insert", "Shift Cells Down").isEnabled()
                )
                self.assertFalse(
                    nested_action(menu, "Insert", "Entire Row").isEnabled()
                )
                self.assertFalse(
                    nested_action(menu, "Delete", "Shift Cells Up").isEnabled()
                )
                self.assertFalse(
                    nested_action(menu, "Delete", "Entire Row").isEnabled()
                )
                self.assertTrue(
                    nested_action(menu, "Insert", "Insert subgroup left").isEnabled()
                )
                self.assertTrue(action_with_text(menu, "Clear Contents").isEnabled())

                window.table.selectRow(row)
                row_menu = window.table_context_menu(window.table, "rows")
                self.assertFalse(action_with_text(row_menu, "Insert").isEnabled())
                self.assertFalse(action_with_text(row_menu, "Delete").isEnabled())

    def test_real_header_context_clicks_select_sections_and_preserve_ranges(self):
        window = self.make_window()
        window.resize(1100, 700)
        window.show()
        self.qapp.processEvents()
        table = window.table
        model = table.table_model
        selection_model = table.selectionModel()

        horizontal = table.horizontalHeader()
        selected_column_x = (
            horizontal.sectionViewportPosition(1)
            + horizontal.sectionSize(1) // 2
        )
        QTest.mouseClick(
            horizontal.viewport(),
            Qt.MouseButton.LeftButton,
            pos=QPoint(selected_column_x, max(1, horizontal.parent_band_rect().top() // 2)),
        )
        self.assertEqual(
            {index.column() for index in selection_model.selectedColumns()},
            {1},
        )

        table.selectColumn(0)
        selection_model.select(
            model.index(0, 1),
            QItemSelectionModel.SelectionFlag.Select
            | QItemSelectionModel.SelectionFlag.Columns,
        )
        fake_menu = mock.Mock()
        with mock.patch.object(
            window,
            "table_context_menu",
            return_value=fake_menu,
        ):
            window.show_table_header_context_menu(
                table,
                Qt.Orientation.Horizontal,
                QPoint(selected_column_x, max(1, horizontal.parent_band_rect().top() // 2)),
            )
        fake_menu.exec.assert_called_once()
        self.assertEqual(
            {index.column() for index in selection_model.selectedColumns()},
            {0, 1},
        )

        unselected_column_x = (
            horizontal.sectionViewportPosition(2)
            + horizontal.sectionSize(2) // 2
        )
        fake_menu = mock.Mock()
        with mock.patch.object(
            window,
            "table_context_menu",
            return_value=fake_menu,
        ):
            window.show_table_header_context_menu(
                table,
                Qt.Orientation.Horizontal,
                QPoint(unselected_column_x, max(1, horizontal.parent_band_rect().top() // 2)),
            )
        fake_menu.exec.assert_called_once()
        self.assertEqual(
            {index.column() for index in selection_model.selectedColumns()},
            {2},
        )

        vertical = table.verticalHeader()
        selected_row_y = (
            vertical.sectionViewportPosition(1)
            + vertical.sectionSize(1) // 2
        )
        QTest.mouseClick(
            vertical.viewport(),
            Qt.MouseButton.LeftButton,
            pos=QPoint(vertical.width() // 2, selected_row_y),
        )
        self.assertEqual(
            {index.row() for index in selection_model.selectedRows()},
            {1},
        )

        table.selectRow(1)
        selection_model.select(
            model.index(2, 0),
            QItemSelectionModel.SelectionFlag.Select
            | QItemSelectionModel.SelectionFlag.Rows,
        )
        selected_row_y = (
            vertical.sectionViewportPosition(2)
            + vertical.sectionSize(2) // 2
        )
        fake_menu = mock.Mock()
        with mock.patch.object(
            window,
            "table_context_menu",
            return_value=fake_menu,
        ):
            window.show_table_header_context_menu(
                table,
                Qt.Orientation.Vertical,
                QPoint(vertical.width() // 2, selected_row_y),
            )
        fake_menu.exec.assert_called_once()
        self.assertEqual(
            {index.row() for index in selection_model.selectedRows()},
            {1, 2},
        )

        unselected_row_y = (
            vertical.sectionViewportPosition(3)
            + vertical.sectionSize(3) // 2
        )
        fake_menu = mock.Mock()
        with mock.patch.object(
            window,
            "table_context_menu",
            return_value=fake_menu,
        ):
            window.show_table_header_context_menu(
                table,
                Qt.Orientation.Vertical,
                QPoint(vertical.width() // 2, unselected_row_y),
            )
        fake_menu.exec.assert_called_once()
        self.assertEqual(
            {index.row() for index in selection_model.selectedRows()},
            {3},
        )

    def test_body_origin_keeps_cell_submenus_for_a_full_row_range(self):
        window = self.make_window()
        window.resize(1100, 700)
        window.show()
        self.qapp.processEvents()
        table = window.table
        first_cell = table.visualRect(table.table_model.index(1, 0)).center()
        QTest.mouseClick(
            table.viewport(),
            Qt.MouseButton.LeftButton,
            pos=first_cell,
        )
        self.select_table_range(
            table,
            1,
            0,
            1,
            table.table_model.columnCount() - 1,
        )

        body_menu = window.table_context_menu(table)
        self.assertIsNotNone(action_with_text(body_menu, "Insert").menu())
        self.assertIsNotNone(action_with_text(body_menu, "Delete").menu())

        vertical = table.verticalHeader()
        row_y = (
            vertical.sectionViewportPosition(1)
            + vertical.sectionSize(1) // 2
        )
        QTest.mouseClick(
            vertical.viewport(),
            Qt.MouseButton.LeftButton,
            pos=QPoint(vertical.width() // 2, row_y),
        )
        header_menu = window.table_context_menu(table)
        self.assertIsNone(action_with_text(header_menu, "Insert").menu())
        self.assertIsNone(action_with_text(header_menu, "Delete").menu())

    def test_groups_multicell_shift_down_is_atomic_and_undoable(self):
        window = self.make_window()
        model = self.set_groups_grid(window)
        original = model.cells_copy()
        self.select_table_range(window.table, 1, 0, 2, 1)

        nested_action(
            window.table_context_menu(window.table, "cells"),
            "Insert",
            "Shift Cells Down",
        ).trigger()

        self.assertEqual(
            [row[:3] for row in model.cells_copy()[:6]],
            [
                ["A", "B", "C"],
                ["", "", "c1"],
                ["", "", "c2"],
                ["a1", "b1", "c3"],
                ["a2", "b2", ""],
                ["a3", "b3", ""],
            ],
        )
        shifted = model.cells_copy()
        self.assertEqual(len(window._table_controller.history.undo_stack), 1)

        window._table_controller.undo()
        self.assertEqual(model.cells_copy(), original)
        window._table_controller.redo()
        self.assertEqual(model.cells_copy(), shifted)

    def test_groups_multicell_delete_shifts_up_without_changing_shape(self):
        window = self.make_window()
        model = self.set_groups_grid(window)
        original_shape = (model.rowCount(), model.columnCount())
        self.select_table_range(window.table, 1, 0, 2, 1)

        nested_action(
            window.table_context_menu(window.table, "cells"),
            "Delete",
            "Shift Cells Up",
        ).trigger()

        self.assertEqual((model.rowCount(), model.columnCount()), original_shape)
        self.assertEqual(
            [row[:3] for row in model.cells_copy()[:4]],
            [
                ["A", "B", "C"],
                ["a3", "b3", "c1"],
                ["", "", "c2"],
                ["", "", "c3"],
            ],
        )

    def test_groups_row_header_inserts_and_deletes_selected_row_count(self):
        window = self.make_window()
        model = self.set_groups_grid(window)
        original = model.cells_copy()
        self.select_table_range(window.table, 1, 0, 2, 2)

        action_with_text(
            window.table_context_menu(window.table, "rows"),
            "Insert",
        ).trigger()

        self.assertEqual(model.rowCount(), len(original) + 2)
        self.assertEqual(model.columnCount(), len(original[0]))
        self.assertEqual(
            [row[:3] for row in model.cells_copy()[:6]],
            [
                ["A", "B", "C"],
                ["", "", ""],
                ["", "", ""],
                ["a1", "b1", "c1"],
                ["a2", "b2", "c2"],
                ["a3", "b3", "c3"],
            ],
        )

        self.select_table_range(window.table, 1, 0, 2, 2)
        action_with_text(
            window.table_context_menu(window.table, "rows"),
            "Delete",
        ).trigger()
        self.assertEqual(model.cells_copy(), original)

    def test_groups_delete_all_sample_rows_keeps_an_editable_recovery_row(self):
        window = self.make_window()
        overlay = [{"name": "Limit", "values": {"A": "9", "B": "8"}}]
        window.settings.custom_overlay_series = overlay
        window.set_table_dataframe(
            pd.DataFrame({"A": ["a1", "a2"], "B": ["b1", "b2"]}),
            overlay,
        )
        controller = window._table_controller
        controller.reset_history()
        table = window.table
        model = table.table_model
        sample_start = controller.sample_start_row()
        self.select_table_range(
            table,
            sample_start,
            0,
            model.rowCount() - 1,
            model.columnCount() - 1,
        )

        action_with_text(
            window.table_context_menu(table, "rows"),
            "Delete",
        ).trigger()

        self.assertGreater(model.rowCount(), sample_start)
        self.assertEqual(model.cell_text(0, 0), "A")
        self.assertEqual(model.cell_text(1, 0), "9")
        self.assertTrue(
            all(
                model.cell_text(sample_start, column) == ""
                for column in range(model.columnCount())
            )
        )
        self.assertTrue(table.currentIndex().isValid())
        self.assertEqual(table.currentIndex().row(), sample_start)
        self.assertTrue(
            model.flags(model.index(sample_start, 0)) & Qt.ItemFlag.ItemIsEditable
        )

        table.setCurrentIndex(model.index(sample_start, 0))
        QApplication.clipboard().setText("restored-a\trestored-b")
        window.paste_table_selection(table)
        self.assertEqual(
            [model.cell_text(sample_start, column) for column in range(2)],
            ["restored-a", "restored-b"],
        )

        before_insert = model.rowCount()
        self.select_table_range(
            table,
            sample_start,
            0,
            sample_start,
            model.columnCount() - 1,
        )
        action_with_text(
            window.table_context_menu(table, "rows"),
            "Insert",
        ).trigger()
        self.assertEqual(model.rowCount(), before_insert + 1)
        self.assertTrue(
            all(
                model.cell_text(sample_start, column) == ""
                for column in range(model.columnCount())
            )
        )
        self.assertEqual(
            [model.cell_text(sample_start + 1, column) for column in range(2)],
            ["restored-a", "restored-b"],
        )

    def test_groups_column_header_inserts_and_deletes_one_physical_column(self):
        window = self.make_window()
        model = self.set_groups_grid(window)
        original = model.cells_copy()
        original_column_count = model.columnCount()
        window.table.selectColumn(1)

        action_with_text(
            window.table_context_menu(window.table, "columns"),
            "Insert subgroup left",
        ).trigger()

        self.assertEqual(model.columnCount(), original_column_count + 1)
        self.assertEqual(
            [model.cell_text(row, 1) for row in range(model.rowCount())],
            [f"Group {original_column_count + 1}", *(
                "" for _row in range(model.rowCount() - 1)
            )],
        )
        self.assertEqual(
            [model.cell_text(row, 2) for row in range(model.rowCount())],
            [row[1] for row in original],
        )

        window.table.selectColumn(1)
        action_with_text(
            window.table_context_menu(window.table, "columns"),
            "Delete",
        ).trigger()
        self.assertEqual(model.cells_copy(), original)

    def test_groups_last_cell_and_minimum_column_boundaries_remain_recoverable(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Only": ["tail"]}))
        model = window.table.table_model
        self.select_table_range(window.table, 1, 0, 1, 0)

        nested_action(
            window.table_context_menu(window.table, "cells"),
            "Insert",
            "Shift Cells Down",
        ).trigger()
        self.assertEqual(model.cell_text(1, 0), "")
        self.assertEqual(model.cell_text(2, 0), "tail")

        self.select_table_range(
            window.table,
            0,
            0,
            model.rowCount() - 1,
            model.columnCount() - 1,
        )
        action_with_text(
            window.table_context_menu(window.table, "columns"),
            "Delete",
        ).trigger()
        self.assertEqual(model.columnCount(), 1)
        self.assertEqual(model.cell_text(0, 0), "Group 1")

        window.table.clearSelection()
        nested_action(
            window.table_context_menu(window.table, "cells"),
            "Insert",
            "Insert subgroup left",
        ).trigger()
        self.assertEqual(model.columnCount(), 2)
        inserted_names = [model.cell_text(0, column) for column in range(2)]
        inserted_ids = list(window.workbook.active_sheet.column_ids)
        inserted_manual_order = list(window.settings.manual_group_order)
        self.assertEqual(len(inserted_names), len(set(inserted_names)))
        self.assertEqual(window.table_group_names(), inserted_names[:-1])
        self.assertIn(inserted_ids[0], inserted_manual_order)
        self.assertNotIn(inserted_ids[-1], inserted_manual_order)
        self.assertTrue(window._group_last_column_is_auto_spare())

        window.undo_table_change()
        self.assertEqual(model.columnCount(), 1)
        self.assertEqual(window.table_group_names(), [])
        self.assertTrue(window._group_last_column_is_auto_spare())

        window.redo_table_change()
        self.assertEqual(
            [model.cell_text(0, column) for column in range(2)],
            inserted_names,
        )
        self.assertEqual(window.workbook.active_sheet.column_ids, inserted_ids)
        self.assertEqual(window.settings.manual_group_order, inserted_manual_order)
        self.assertTrue(window._group_last_column_is_auto_spare())

    def test_clear_contents_changes_only_selected_cells_and_is_undoable(self):
        window = self.make_window()
        model = self.set_groups_grid(window)
        original = model.cells_copy()
        original_shape = (model.rowCount(), model.columnCount())
        original_column_ids = list(window.workbook.active_sheet.column_ids)
        self.select_table_range(window.table, 1, 0, 2, 1)

        action_with_text(
            window.table_context_menu(window.table, "cells"),
            "Clear Contents",
        ).trigger()

        self.assertEqual((model.rowCount(), model.columnCount()), original_shape)
        self.assertEqual(
            [row[:3] for row in model.cells_copy()[:4]],
            [
                ["A", "B", "C"],
                ["", "", "c1"],
                ["", "", "c2"],
                ["a3", "b3", "c3"],
            ],
        )
        self.assertEqual(window.workbook.active_sheet.column_ids, original_column_ids)
        window._table_controller.undo()
        self.assertEqual(model.cells_copy(), original)

    def test_xy_clear_contents_does_not_expand_a_cell_to_its_pair(self):
        window = self.make_xy_window()
        table = window.xy_independent_table
        model = table.table_model
        model.set_cell_text(1, 0, "1")
        model.set_cell_text(1, 1, "10")
        original_pair_ids = list(
            window.workbook.active_sheet.xy_settings.paired_series_ids
        )
        original_column_ids = list(window.workbook.active_sheet.column_ids)
        self.select_table_range(table, 1, 1, 1, 1)

        action_with_text(
            window.table_context_menu(table, "cells"),
            "Clear Contents",
        ).trigger()

        self.assertEqual(table.table_model.cell_text(1, 0), "1")
        self.assertEqual(table.table_model.cell_text(1, 1), "")
        self.assertEqual(
            window.workbook.active_sheet.xy_settings.paired_series_ids,
            original_pair_ids,
        )
        self.assertEqual(window.workbook.active_sheet.column_ids, original_column_ids)

    def assert_xy_pairs_are_aligned(self, window) -> None:
        sheet = window.workbook.active_sheet
        series_by_id = {
            series.id: series for series in sheet.xy_settings.series
        }
        expected_columns = []
        for series_id in sheet.xy_settings.paired_series_ids:
            series = series_by_id[series_id]
            expected_columns.extend((series.x_column_id, series.y_column_id))
        self.assertEqual(
            window._active_xy_paired_column_ids,
            expected_columns,
        )
        self.assertEqual(
            window.xy_independent_table.table_model.columnCount(),
            len(expected_columns),
        )

    def test_xy_shared_x_and_mixed_x_y_deletion_are_blocked(self):
        window = self.make_xy_window()
        table = window.table
        sheet = window.workbook.active_sheet
        original_column_ids = list(sheet.column_ids)
        original_series_ids = [series.id for series in sheet.xy_settings.series]
        original_shared_ids = list(sheet.xy_settings.shared_tables[0].series_ids)

        self.select_table_range(
            table,
            0,
            0,
            table.table_model.rowCount() - 1,
            1,
        )
        menu = window.table_context_menu(table, "columns")

        self.assertFalse(action_with_text(menu, "Delete").isEnabled())
        self.assertFalse(window.delete_table_structure("entire_column", table))
        self.assertEqual(sheet.column_ids, original_column_ids)
        self.assertEqual(
            [series.id for series in sheet.xy_settings.series],
            original_series_ids,
        )
        self.assertEqual(
            sheet.xy_settings.shared_tables[0].series_ids,
            original_shared_ids,
        )

    def test_xy_shared_x_insertion_adds_one_y_after_x_and_undoes(self):
        window = self.make_xy_window()
        table = window.table
        sheet = window.workbook.active_sheet
        controller = window._table_controller
        controller.reset_history()
        original_column_ids = list(sheet.column_ids)
        original_column_names = list(sheet.dataframe.columns)
        original_shared_ids = list(sheet.xy_settings.shared_tables[0].series_ids)
        original_series = deepcopy(sheet.xy_settings.series)
        sheet.xy_settings.series[0].color = "#123456"
        sheet.xy_settings.series[0].point_size = 8.0
        table.selectColumn(0)

        action_with_text(
            window.table_context_menu(table, "columns"),
            "Insert",
        ).trigger()

        inserted_column_ids = list(sheet.column_ids)
        inserted_shared_ids = list(sheet.xy_settings.shared_tables[0].series_ids)
        self.assertEqual(table.table_model.cell_text(0, 0), "X")

        self.assertEqual(table.table_model.cell_text(0, 1), "1Y")
        self.assertEqual(len(inserted_column_ids), len(original_column_ids) + 1)
        self.assertEqual(len(inserted_shared_ids), len(original_shared_ids) + 1)
        self.assertNotIn(inserted_shared_ids[0], original_shared_ids)

        controller.undo()
        self.assertEqual(sheet.column_ids, original_column_ids)
        self.assertEqual(list(sheet.dataframe.columns), original_column_names)
        self.assertEqual(
            sheet.xy_settings.shared_tables[0].series_ids,
            original_shared_ids,
        )
        restored_by_id = {
            series.id: series for series in sheet.xy_settings.series
        }
        self.assertEqual(restored_by_id[original_series[0].id].color, "#123456")
        self.assertEqual(restored_by_id[original_series[0].id].point_size, 8.0)

        controller.redo()
        self.assertEqual(sheet.column_ids, inserted_column_ids)
        self.assertEqual(
            sheet.xy_settings.shared_tables[0].series_ids,
            inserted_shared_ids,
        )

        table.selectColumn(1)
        action_with_text(
            window.table_context_menu(table, "columns"),
            "Delete",
        ).trigger()
        self.assertEqual(len(sheet.column_ids), len(inserted_column_ids) - 1)
        self.assertEqual(
            len(sheet.xy_settings.shared_tables[0].series_ids),
            len(inserted_shared_ids) - 1,
        )
        self.assertEqual(table.table_model.cell_text(0, 0), "X")

    def test_xy_structure_undo_removes_a_later_fit_for_the_undone_series(self):
        window = self.make_xy_window()
        table = window.table
        sheet = window.workbook.active_sheet
        controller = window._table_controller
        controller.reset_history()
        original_series_ids = {series.id for series in sheet.xy_settings.series}
        table.selectColumn(0)

        action_with_text(
            window.table_context_menu(table, "columns"),
            "Insert",
        ).trigger()
        inserted_series = next(
            series
            for series in sheet.xy_settings.series
            if series.id not in original_series_ids
        )
        sheet.xy_settings.fit_specs.append(
            default_fit_spec(inserted_series.id, "linear")
        )
        sheet.xy_settings.__post_init__()

        controller.undo()

        self.assertNotIn(
            inserted_series.id,
            {series.id for series in sheet.xy_settings.series},
        )
        self.assertNotIn(
            inserted_series.id,
            {fit.series_id for fit in sheet.xy_settings.fit_specs},
        )
        sheet.xy_settings.__post_init__()

    def test_xy_paired_column_operations_use_one_aligned_two_column_pair(self):
        window = self.make_xy_window()
        table = window.xy_independent_table
        sheet = window.workbook.active_sheet
        controller = window._xy_paired_controller
        controller.reset_history()
        original_column_ids = list(sheet.column_ids)
        original_column_names = list(sheet.dataframe.columns)
        original_pair_ids = list(sheet.xy_settings.paired_series_ids)
        first_pair = next(
            series
            for series in sheet.xy_settings.series
            if series.id == original_pair_ids[0]
        )
        first_pair.color = "#654321"
        first_pair.line_width = 3.25
        table.selectColumn(1)

        action_with_text(
            window.table_context_menu(table, "columns"),
            "Insert",
        ).trigger()

        inserted_column_ids = list(sheet.column_ids)
        inserted_column_names = list(sheet.dataframe.columns)
        inserted_pair_ids = list(sheet.xy_settings.paired_series_ids)
        self.assertEqual(len(inserted_column_ids), len(original_column_ids) + 2)
        self.assertEqual(len(inserted_pair_ids), len(original_pair_ids) + 1)
        self.assertNotIn(inserted_pair_ids[0], original_pair_ids)
        self.assert_xy_pairs_are_aligned(window)

        controller.undo()
        self.assertEqual(sheet.column_ids, original_column_ids)
        self.assertEqual(list(sheet.dataframe.columns), original_column_names)
        self.assertEqual(sheet.xy_settings.paired_series_ids, original_pair_ids)
        restored = next(
            series
            for series in sheet.xy_settings.series
            if series.id == first_pair.id
        )
        self.assertEqual(restored.color, "#654321")
        self.assertEqual(restored.line_width, 3.25)
        self.assert_xy_pairs_are_aligned(window)

        controller.redo()
        self.assertEqual(sheet.column_ids, inserted_column_ids)
        self.assertEqual(list(sheet.dataframe.columns), inserted_column_names)
        self.assertEqual(sheet.xy_settings.paired_series_ids, inserted_pair_ids)
        self.assert_xy_pairs_are_aligned(window)

        table.selectColumn(1)
        action_with_text(
            window.table_context_menu(table, "columns"),
            "Delete",
        ).trigger()
        self.assertEqual(len(sheet.column_ids), len(inserted_column_ids) - 2)
        self.assertEqual(
            len(sheet.xy_settings.paired_series_ids),
            len(inserted_pair_ids) - 1,
        )
        self.assert_xy_pairs_are_aligned(window)

    def test_xy_paired_column_insert_counts_distinct_touched_pairs(self):
        window = self.make_xy_window()
        table = window.xy_independent_table
        sheet = window.workbook.active_sheet
        controller = window._xy_paired_controller
        original_count = len(sheet.xy_settings.paired_series_ids)
        self.select_table_range(
            table,
            0,
            0,
            table.table_model.rowCount() - 1,
            1,
        )
        pair_menu = window.table_context_menu(table, "columns")
        for text in ("Insert", "Delete"):
            action = action_with_text(pair_menu, text)
            self.assertIn("X/Y pair", action.toolTip())
            self.assertIn("X/Y pair", action.statusTip())

        action_with_text(
            pair_menu,
            "Insert",
        ).trigger()
        self.assertEqual(
            len(sheet.xy_settings.paired_series_ids),
            original_count + 1,
        )
        controller.undo()

        self.select_table_range(
            table,
            0,
            1,
            table.table_model.rowCount() - 1,
            2,
        )
        action_with_text(
            window.table_context_menu(table, "columns"),
            "Insert",
        ).trigger()
        self.assertEqual(
            len(sheet.xy_settings.paired_series_ids),
            original_count + 2,
        )
        self.assert_xy_pairs_are_aligned(window)

    def test_xy_paired_cells_down_and_up_normalize_to_the_complete_pair(self):
        window = self.make_xy_window()
        table = window.xy_independent_table
        model = table.table_model
        controller = window._xy_paired_controller
        for row, values in ((1, ("1", "10")), (2, ("2", "20"))):
            model.set_cell_text(row, 0, values[0])
            model.set_cell_text(row, 1, values[1])
        controller.reset_history()
        self.select_table_range(table, 1, 1, 1, 1)

        nested_action(
            window.table_context_menu(table, "cells"),
            "Insert",
            "Shift Cells Down",
        ).trigger()

        self.assertEqual(
            [[model.cell_text(row, column) for column in (0, 1)] for row in range(1, 4)],
            [["", ""], ["1", "10"], ["2", "20"]],
        )
        controller.undo()
        self.assertEqual(
            [[model.cell_text(row, column) for column in (0, 1)] for row in range(1, 3)],
            [["1", "10"], ["2", "20"]],
        )
        controller.redo()

        self.select_table_range(table, 1, 1, 1, 1)
        nested_action(
            window.table_context_menu(table, "cells"),
            "Delete",
            "Shift Cells Up",
        ).trigger()
        self.assertEqual(
            [[model.cell_text(row, column) for column in (0, 1)] for row in range(1, 3)],
            [["1", "10"], ["2", "20"]],
        )

    def test_xy_entire_row_affects_only_the_current_panel(self):
        window = self.make_xy_window()
        shared = window.table
        paired = window.xy_independent_table
        shared_model = shared.table_model
        paired_model = paired.table_model
        shared_model.set_cell_text(1, 0, "shared-x")
        shared_model.set_cell_text(1, 1, "shared-y")
        paired_model.set_cell_text(1, 0, "pair-x")
        paired_model.set_cell_text(1, 1, "pair-y")
        paired_model.set_cell_text(2, 0, "pair-x-2")
        paired_model.set_cell_text(2, 1, "pair-y-2")
        window._xy_paired_controller.reset_history()
        self.select_table_range(
            paired,
            1,
            0,
            1,
            paired_model.columnCount() - 1,
        )

        action_with_text(
            window.table_context_menu(paired, "rows"),
            "Insert",
        ).trigger()

        self.assertEqual(
            [paired_model.cell_text(1, column) for column in (0, 1)],
            ["", ""],
        )
        self.assertEqual(
            [paired_model.cell_text(2, column) for column in (0, 1)],
            ["pair-x", "pair-y"],
        )
        self.assertEqual(
            [shared_model.cell_text(1, column) for column in (0, 1)],
            ["shared-x", "shared-y"],
        )

        self.select_table_range(
            paired,
            1,
            0,
            1,
            paired_model.columnCount() - 1,
        )
        action_with_text(
            window.table_context_menu(paired, "rows"),
            "Delete",
        ).trigger()
        self.assertEqual(
            [paired_model.cell_text(1, column) for column in (0, 1)],
            ["pair-x", "pair-y"],
        )
        self.assertEqual(
            [shared_model.cell_text(1, column) for column in (0, 1)],
            ["shared-x", "shared-y"],
        )

    def test_xy_delete_all_sample_rows_keeps_an_editable_recovery_row(self):
        window = self.make_xy_window()
        table = window.xy_independent_table
        model = table.table_model
        controller = window._xy_paired_controller
        sample_start = controller.sample_start_row()
        model.set_cell_text(sample_start, 0, "pair-x")
        model.set_cell_text(sample_start, 1, "pair-y")
        controller.reset_history()
        self.select_table_range(
            table,
            sample_start,
            0,
            model.rowCount() - 1,
            model.columnCount() - 1,
        )

        action_with_text(
            window.table_context_menu(table, "rows"),
            "Delete",
        ).trigger()

        self.assertGreater(model.rowCount(), sample_start)
        self.assertTrue(
            all(
                model.cell_text(sample_start, column) == ""
                for column in range(model.columnCount())
            )
        )
        self.assertTrue(table.currentIndex().isValid())
        self.assertEqual(table.currentIndex().row(), sample_start)
        self.assertTrue(
            model.flags(model.index(sample_start, 0)) & Qt.ItemFlag.ItemIsEditable
        )

        table.setCurrentIndex(model.index(sample_start, 0))
        QApplication.clipboard().setText("new-x\tnew-y")
        window.paste_table_selection(table)
        self.assertEqual(
            [model.cell_text(sample_start, column) for column in range(2)],
            ["new-x", "new-y"],
        )

        before_insert = model.rowCount()
        self.select_table_range(
            table,
            sample_start,
            0,
            sample_start,
            model.columnCount() - 1,
        )
        action_with_text(
            window.table_context_menu(table, "rows"),
            "Insert",
        ).trigger()
        self.assertEqual(model.rowCount(), before_insert + 1)
        self.assertTrue(
            all(
                model.cell_text(sample_start, column) == ""
                for column in range(model.columnCount())
            )
        )
        self.assertEqual(
            [model.cell_text(sample_start + 1, column) for column in range(2)],
            ["new-x", "new-y"],
        )

    def test_xy_pair_structure_undo_preserves_later_shared_edits(self):
        window = self.make_xy_window()
        paired = window.xy_independent_table
        sheet = window.workbook.active_sheet
        controller = window._xy_paired_controller
        original_pair_ids = list(sheet.xy_settings.paired_series_ids)
        shared_series_id = sheet.xy_settings.shared_tables[0].series_ids[0]
        shared_series = next(
            series for series in sheet.xy_settings.series if series.id == shared_series_id
        )
        paired.selectColumn(1)
        action_with_text(
            window.table_context_menu(paired, "columns"),
            "Insert",
        ).trigger()

        window.table.table_model.set_cell_text(1, 1, "later-shared")
        shared_series = next(
            series for series in sheet.xy_settings.series if series.id == shared_series_id
        )
        shared_series.color = "#abcdef"
        shared_series.point_size = 11.0
        controller.undo()

        self.assertEqual(sheet.xy_settings.paired_series_ids, original_pair_ids)
        self.assertEqual(window.table.table_model.cell_text(1, 1), "later-shared")
        restored = next(
            series for series in sheet.xy_settings.series if series.id == shared_series_id
        )
        self.assertEqual(restored.color, "#abcdef")
        self.assertEqual(restored.point_size, 11.0)

    def test_xy_shared_structure_undo_preserves_later_paired_edits(self):
        window = self.make_xy_window()
        shared = window.table
        sheet = window.workbook.active_sheet
        controller = window._table_controller
        original_shared_ids = list(sheet.xy_settings.shared_tables[0].series_ids)
        paired_series_id = sheet.xy_settings.paired_series_ids[0]
        shared.selectColumn(1)
        action_with_text(
            window.table_context_menu(shared, "columns"),
            "Insert",
        ).trigger()

        window.xy_independent_table.table_model.set_cell_text(1, 1, "later-paired")
        paired_series = next(
            series for series in sheet.xy_settings.series if series.id == paired_series_id
        )
        paired_series.color = "#fedcba"
        paired_series.line_width = 4.5
        controller.undo()

        self.assertEqual(
            sheet.xy_settings.shared_tables[0].series_ids,
            original_shared_ids,
        )
        self.assertEqual(
            window.xy_independent_table.table_model.cell_text(1, 1),
            "later-paired",
        )
        restored = next(
            series for series in sheet.xy_settings.series if series.id == paired_series_id
        )
        self.assertEqual(restored.color, "#fedcba")
        self.assertEqual(restored.line_width, 4.5)

    def test_shared_table_structure_undo_preserves_a_later_shared_table(self):
        window = self.make_xy_window()
        sheet = window.workbook.active_sheet
        first_table = sheet.xy_settings.shared_tables[0]
        first_history = window._table_controller.history
        window.table.selectColumn(1)
        action_with_text(
            window.table_context_menu(window.table, "columns"),
            "Insert",
        ).trigger()

        with mock.patch.object(window, "render"):
            window.add_xy_shared_table()
        second_table = sheet.xy_settings.shared_tables[-1]
        second_table_id = second_table.id
        series_by_id = {
            series.id: series for series in sheet.xy_settings.series
        }
        second_column_ids = [
            second_table.x_column_id,
            *(series_by_id[series_id].y_column_id for series_id in second_table.series_ids),
        ]
        second_series_id = second_table.series_ids[0]
        series_by_id[second_series_id].color = "#112233"
        series_by_id[second_series_id].line_width = 5.0
        window.table.table_model.set_cell_text(1, 0, "second-x")
        window.table.table_model.set_cell_text(1, 1, "second-y")
        first_index = next(
            index
            for index in range(window.ui.xySharedTabBar.count())
            if window.ui.xySharedTabBar.tabData(index) == first_table.id
        )
        window.switch_xy_shared_table(first_index)
        self.assertIs(window._table_controller.history, first_history)

        first_history.undo(window._table_controller)

        self.assertIn(
            second_table_id,
            [table.id for table in sheet.xy_settings.shared_tables],
        )
        self.assertTrue(set(second_column_ids).issubset(sheet.column_ids))
        second_index = next(
            index
            for index in range(window.ui.xySharedTabBar.count())
            if window.ui.xySharedTabBar.tabData(index) == second_table_id
        )
        window.switch_xy_shared_table(second_index)
        self.assertEqual(window.table.table_model.cell_text(1, 0), "second-x")
        self.assertEqual(window.table.table_model.cell_text(1, 1), "second-y")
        restored_second_series = next(
            series
            for series in sheet.xy_settings.series
            if series.id == second_series_id
        )
        self.assertEqual(restored_second_series.color, "#112233")
        self.assertEqual(restored_second_series.line_width, 5.0)

        window.switch_xy_shared_table(first_index)
        first_history.redo(window._table_controller)
        self.assertIn(
            second_table_id,
            [table.id for table in sheet.xy_settings.shared_tables],
        )
        self.assertTrue(set(second_column_ids).issubset(sheet.column_ids))
        second_index = next(
            index
            for index in range(window.ui.xySharedTabBar.count())
            if window.ui.xySharedTabBar.tabData(index) == second_table_id
        )
        window.switch_xy_shared_table(second_index)
        self.assertEqual(window.table.table_model.cell_text(1, 0), "second-x")
        self.assertEqual(window.table.table_model.cell_text(1, 1), "second-y")
        restored_second_series = next(
            series
            for series in sheet.xy_settings.series
            if series.id == second_series_id
        )
        self.assertEqual(restored_second_series.color, "#112233")
        self.assertEqual(restored_second_series.line_width, 5.0)

    def test_pair_structure_undo_redo_preserves_a_later_shared_table(self):
        window = self.make_xy_window()
        sheet = window.workbook.active_sheet
        pair_history = window._xy_paired_controller.history
        window.xy_independent_table.selectColumn(1)
        action_with_text(
            window.table_context_menu(
                window.xy_independent_table,
                "columns",
            ),
            "Insert",
        ).trigger()

        with mock.patch.object(window, "render"):
            window.add_xy_shared_table()
        second_table = sheet.xy_settings.shared_tables[-1]
        second_table_id = second_table.id
        second_series_id = second_table.series_ids[0]
        second_series = next(
            series
            for series in sheet.xy_settings.series
            if series.id == second_series_id
        )
        second_column_ids = [second_table.x_column_id, second_series.y_column_id]
        second_series.color = "#334455"
        second_series.point_size = 9.0
        window.table.table_model.set_cell_text(1, 0, "new-table-x")
        window.table.table_model.set_cell_text(1, 1, "new-table-y")

        pair_history.undo(window._xy_paired_controller)
        self.assertIn(
            second_table_id,
            [table.id for table in sheet.xy_settings.shared_tables],
        )
        self.assertTrue(set(second_column_ids).issubset(sheet.column_ids))
        self.assertEqual(window.table.table_model.cell_text(1, 0), "new-table-x")
        self.assertEqual(window.table.table_model.cell_text(1, 1), "new-table-y")
        restored = next(
            series
            for series in sheet.xy_settings.series
            if series.id == second_series_id
        )
        self.assertEqual(restored.color, "#334455")
        self.assertEqual(restored.point_size, 9.0)

        pair_history.redo(window._xy_paired_controller)
        self.assertIn(
            second_table_id,
            [table.id for table in sheet.xy_settings.shared_tables],
        )
        self.assertTrue(set(second_column_ids).issubset(sheet.column_ids))
        self.assertEqual(window.table.table_model.cell_text(1, 0), "new-table-x")
        self.assertEqual(window.table.table_model.cell_text(1, 1), "new-table-y")

    def test_structure_undo_redo_does_not_resurrect_a_later_deleted_table(self):
        window = self.make_xy_window()
        sheet = window.workbook.active_sheet
        first_table_id = sheet.xy_settings.shared_tables[0].id
        with mock.patch.object(window, "render"):
            window.add_xy_shared_table()
        removed_table = sheet.xy_settings.shared_tables[-1]
        removed_table_id = removed_table.id
        series_by_id = {
            series.id: series for series in sheet.xy_settings.series
        }
        removed_series_ids = set(removed_table.series_ids)
        removed_column_ids = {
            removed_table.x_column_id,
            *(
                series_by_id[series_id].y_column_id
                for series_id in removed_table.series_ids
            ),
        }
        first_index = next(
            index
            for index in range(window.ui.xySharedTabBar.count())
            if window.ui.xySharedTabBar.tabData(index) == first_table_id
        )
        window.switch_xy_shared_table(first_index)
        first_history = window._table_controller.history
        window.table.selectColumn(1)
        action_with_text(
            window.table_context_menu(window.table, "columns"),
            "Insert",
        ).trigger()

        removed_index = next(
            index
            for index in range(window.ui.xySharedTabBar.count())
            if window.ui.xySharedTabBar.tabData(index) == removed_table_id
        )
        window.switch_xy_shared_table(removed_index)
        with mock.patch.object(
            QMessageBox,
            "question",
            return_value=QMessageBox.StandardButton.Yes,
        ), mock.patch.object(window, "render"):
            window.remove_xy_shared_table()

        def assert_table_stays_deleted() -> None:
            self.assertNotIn(
                removed_table_id,
                [table.id for table in sheet.xy_settings.shared_tables],
            )
            self.assertTrue(removed_column_ids.isdisjoint(sheet.column_ids))
            self.assertTrue(
                removed_series_ids.isdisjoint(
                    series.id for series in sheet.xy_settings.series
                )
            )

        assert_table_stays_deleted()
        first_history.undo(window._table_controller)
        assert_table_stays_deleted()
        first_history.redo(window._table_controller)
        assert_table_stays_deleted()

    def test_structure_undo_keeps_a_later_deleted_default_x_table_deleted(self):
        window = self.make_xy_window()
        sheet = window.workbook.active_sheet
        removed_table = sheet.xy_settings.shared_tables[0]
        removed_table_id = removed_table.id
        original_default_x = sheet.xy_settings.default_x_column_id
        series_by_id = {
            series.id: series for series in sheet.xy_settings.series
        }
        removed_column_ids = {
            removed_table.x_column_id,
            *(
                series_by_id[series_id].y_column_id
                for series_id in removed_table.series_ids
            ),
        }
        with mock.patch.object(window, "render"):
            window.add_xy_shared_table()
        second_table_id = sheet.xy_settings.shared_tables[-1].id
        second_history = window._table_controller.history
        window.table.selectColumn(1)
        action_with_text(
            window.table_context_menu(window.table, "columns"),
            "Insert",
        ).trigger()

        removed_index = next(
            index
            for index in range(window.ui.xySharedTabBar.count())
            if window.ui.xySharedTabBar.tabData(index) == removed_table_id
        )
        window.switch_xy_shared_table(removed_index)
        with mock.patch.object(
            QMessageBox,
            "question",
            return_value=QMessageBox.StandardButton.Yes,
        ), mock.patch.object(window, "render"):
            window.remove_xy_shared_table()

        def assert_default_table_stays_deleted() -> None:
            self.assertNotIn(
                removed_table_id,
                [table.id for table in sheet.xy_settings.shared_tables],
            )
            self.assertIn(
                second_table_id,
                [table.id for table in sheet.xy_settings.shared_tables],
            )
            self.assertTrue(removed_column_ids.isdisjoint(sheet.column_ids))
            self.assertNotEqual(sheet.xy_settings.default_x_column_id, original_default_x)
            self.assertTrue(
                sheet.xy_settings.default_x_column_id is None
                or sheet.xy_settings.default_x_column_id in sheet.column_ids
            )

        assert_default_table_stays_deleted()
        second_history.undo(window._table_controller)
        assert_default_table_stays_deleted()
        second_history.redo(window._table_controller)
        assert_default_table_stays_deleted()


if __name__ == "__main__":
    import unittest

    unittest.main()
