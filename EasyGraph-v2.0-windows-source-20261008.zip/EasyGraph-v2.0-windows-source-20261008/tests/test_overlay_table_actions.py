from tests.easygraph_case import EasyGraphTestCase

from easygraph.overlay_table_actions import (
    overlay_table_state_after_add,
    overlay_table_state_after_remove,
    overlay_table_state_after_rename,
)


class OverlayTableActionsTests(EasyGraphTestCase):
    def test_overlay_table_state_after_add_appends_next_overlay_without_mutating_input(self):
        existing = [{"name": "Overlay 1", "values": {"A": "10"}}]

        series, count, enabled = overlay_table_state_after_add(existing)

        self.assertEqual(existing, [{"name": "Overlay 1", "values": {"A": "10"}}])
        self.assertEqual(
            series,
            [
                {"name": "Overlay 1", "values": {"A": "10"}},
                {"name": "Overlay 2", "values": {}},
            ],
        )
        self.assertEqual(count, 2)
        self.assertTrue(enabled)


    def test_overlay_table_state_after_remove_reindexes_hidden_and_disables_empty_overlay(self):
        series = [{"name": "Overlay 1"}, {"name": "Overlay 2"}, {"name": "Overlay 3"}]

        result = overlay_table_state_after_remove(series, hidden_indexes=[0, 2], index=1)

        self.assertEqual(series, [{"name": "Overlay 1"}, {"name": "Overlay 2"}, {"name": "Overlay 3"}])
        self.assertEqual(result.series, [{"name": "Overlay 1"}, {"name": "Overlay 3"}])
        self.assertEqual(result.hidden_indexes, [0, 1])
        self.assertEqual(result.count, 2)
        self.assertTrue(result.enabled)

        empty = overlay_table_state_after_remove([{"name": "Only"}], hidden_indexes=[0], index=0)

        self.assertEqual(empty.series, [])
        self.assertEqual(empty.hidden_indexes, [])
        self.assertEqual(empty.count, 1)
        self.assertFalse(empty.enabled)


    def test_overlay_table_state_after_rename_trims_falls_back_and_extends_series(self):
        existing = [{"name": "Overlay 1", "values": {"A": "10"}}]

        renamed = overlay_table_state_after_rename(existing, row=1, name="  Target\nDay 2  ")

        self.assertEqual(existing, [{"name": "Overlay 1", "values": {"A": "10"}}])
        self.assertEqual(renamed, [{"name": "Target\nDay 2", "values": {"A": "10"}}])

        extended = overlay_table_state_after_rename([], row=2, name="   ")

        self.assertEqual(
            extended,
            [
                {"name": "Overlay 1", "values": {}},
                {"name": "Overlay 2", "values": {}},
            ],
        )
