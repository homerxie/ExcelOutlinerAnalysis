"""Interaction checks for the parent header's independent block selection."""
from __future__ import annotations

import unittest

from PySide6.QtCore import QPoint, Qt
from PySide6.QtGui import QContextMenuEvent, QStandardItemModel
from PySide6.QtTest import QSignalSpy, QTest
from PySide6.QtWidgets import QApplication, QTableView

from easygraph.ui.group_header import GroupHeaderView


class ParentHeaderSelectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.table = QTableView()
        self.model = QStandardItemModel(3, 7, self.table)
        self.table.setModel(self.model)
        self.header = GroupHeaderView(self.table)
        self.table.setHorizontalHeader(self.header)
        self.header.setDefaultSectionSize(80)
        self.ids = [f'column-{index}' for index in range(6)]
        self.groups = [
            {'id': 'wt', 'name': 'WT', 'column_ids': self.ids[:2]},
            {'id': 'ko', 'name': 'KO', 'column_ids': self.ids[3:5]},
        ]
        self.header.set_grouping(self.groups, self.ids)
        self.table.resize(700, 240)
        self.table.show()
        self.app.processEvents()
        self.addCleanup(self.table.close)
        self.addCleanup(self.table.deleteLater)

    def point(self, column):
        return QPoint(
            self.header.sectionViewportPosition(column) + self.header.sectionSize(column) // 2,
            self.header.parent_band_rect().center().y(),
        )

    def click(self, column, modifiers=Qt.NoModifier):
        QTest.mouseClick(self.header.viewport(), Qt.LeftButton, modifiers, self.point(column))

    def test_blank_cells_and_named_blocks_are_independently_selectable(self):
        changed = QSignalSpy(self.header.parentSelectionChanged)
        self.click(1)
        self.assertEqual(self.header.selected_parent_columns(), [0, 1])
        self.assertEqual(self.header.parent_columns_at(self.point(0)), [0, 1])
        self.assertEqual(self.header.parent_at(self.point(1)), 'wt')
        self.assertFalse(self.table.selectionModel().hasSelection())
        self.click(2)
        self.assertEqual(self.header.selected_parent_columns(), [2])
        self.assertIsNone(self.header.parent_at(self.point(2)))
        self.assertEqual(changed.count(), 2)
        # The extra capacity column has no parent cell and cannot become a group.
        self.click(6)
        self.assertEqual(self.header.selected_parent_columns(), [])
        self.assertEqual(self.header.parent_columns_at(self.point(6)), [])

    def test_shift_click_and_drag_select_contiguous_whole_blocks(self):
        self.click(1)
        self.click(3, Qt.ShiftModifier)
        self.assertEqual(self.header.selected_parent_columns(), list(range(5)))
        self.click(2, Qt.ShiftModifier)
        self.assertEqual(self.header.selected_parent_columns(), [0, 1, 2])
        QTest.mousePress(self.header.viewport(), Qt.LeftButton, Qt.NoModifier, self.point(4))
        QTest.mouseMove(self.header.viewport(), self.point(1))
        QTest.mouseRelease(self.header.viewport(), Qt.LeftButton, Qt.NoModifier, self.point(1))
        self.assertEqual(self.header.selected_parent_columns(), list(range(5)))
        self.assertFalse(self.table.selectionModel().hasSelection())

    def test_context_click_preserves_selection_and_emits_blank_cell_anchor(self):
        self.header.select_parent_columns([0, 4])
        QTest.mouseClick(self.header.viewport(), Qt.RightButton, Qt.NoModifier, self.point(2))
        self.assertEqual(self.header.selected_parent_columns(), list(range(5)))
        context = QSignalSpy(self.header.parentCellContextMenuRequested)
        old_context = QSignalSpy(self.header.parentContextMenuRequested)
        position = self.point(5)
        event = QContextMenuEvent(QContextMenuEvent.Mouse, position, self.header.viewport().mapToGlobal(position))
        QApplication.sendEvent(self.header.viewport(), event)
        self.assertEqual(self.header.selected_parent_columns(), [5])
        self.assertEqual(context.count(), 1)
        self.assertEqual(context.at(0)[0], 5)
        self.assertEqual(old_context.count(), 0)

    def test_double_click_renames_both_empty_and_existing_parent_cells(self):
        double_clicked = QSignalSpy(self.header.parentCellDoubleClicked)
        old_double_clicked = QSignalSpy(self.header.parentDoubleClicked)
        QTest.mouseDClick(self.header.viewport(), Qt.LeftButton, Qt.NoModifier, self.point(2))
        QTest.mouseDClick(self.header.viewport(), Qt.LeftButton, Qt.NoModifier, self.point(4))
        self.assertEqual(double_clicked.count(), 2)
        self.assertEqual(double_clicked.at(0)[0], 2)
        self.assertEqual(double_clicked.at(1)[0], 3)
        self.assertEqual(self.header.selected_parent_columns(), [3, 4])
        self.assertEqual(old_double_clicked.count(), 0)

    def test_number_row_still_selects_a_data_column_and_clears_parent_selection(self):
        self.click(0)
        number = self.point(3)
        number.setY(max(1, self.header.parent_band_rect().top() // 2))
        self.assertEqual(self.header.parent_columns_at(number), [])
        QTest.mouseClick(self.header.viewport(), Qt.LeftButton, Qt.NoModifier, number)
        self.assertEqual(self.header.selected_parent_columns(), [])
        self.assertEqual([index.column() for index in self.table.selectionModel().selectedColumns()], [3])

    def test_flat_groups_keep_blank_band_while_xy_can_disable_it(self):
        self.header.set_grouping([], self.ids)
        self.assertGreater(self.header.band_height(), 0)
        self.click(1)
        self.assertEqual(self.header.selected_parent_columns(), [1])
        self.header.set_parent_band_enabled(False)
        self.assertEqual(self.header.band_height(), 0)
        self.assertEqual(self.header.selected_parent_columns(), [])
        self.assertEqual(self.header.parent_columns_at(self.point(1)), [])
        self.assertEqual(list(self.header.group_rects()), [])
        self.header.set_parent_band_enabled(True)
        self.assertGreater(self.header.band_height(), 0)

    def test_selection_tracks_stable_ids_and_expands_new_members_of_a_selected_parent(self):
        self.header.select_parent_columns([4])
        self.assertEqual(self.header.selected_parent_columns(), [3, 4])
        new_ids = ['inserted-before'] + self.ids
        self.header.set_grouping(self.groups, new_ids)
        self.assertEqual(self.header.selected_parent_columns(), [4, 5])
        # Insert a new member inside KO; preserve selection of its complete block.
        new_ids.insert(5, 'new-member')
        groups = [self.groups[0], dict(self.groups[1], column_ids=[self.ids[3], 'new-member', self.ids[4]])]
        self.header.set_grouping(groups, new_ids)
        self.assertEqual(self.header.selected_parent_columns(), [4, 5, 6])
        # Removing the selected IDs must not redirect the selection to spare slots.
        self.header.set_grouping([], self.ids[:3])
        self.assertEqual(self.header.selected_parent_columns(), [])


if __name__ == '__main__':
    unittest.main()
