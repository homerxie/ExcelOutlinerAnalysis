from __future__ import annotations

import pathlib
import tempfile
from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QDialogButtonBox

from tests.easygraph_case import EasyGraphQtTestCase
from tests.prism_fixtures import column_table, grouped_table, pzfx_document, write_pzfx, xy_table

from easygraph.prism_io import import_pzfx_tables
from easygraph.ui import main_window
from easygraph.ui.prism_import_dialog import (
    PrismImportDialog,
    choose_prism_table,
    choose_prism_tables,
)


class PrismImportDialogTests(EasyGraphQtTestCase):
    def make_pzfx(self, directory: str) -> pathlib.Path:
        return write_pzfx(
            pathlib.Path(directory) / "dialog.pzfx",
            pzfx_document(
                [
                    column_table(table_id="Column", title="Column data"),
                    grouped_table(table_id="Grouped", title="Grouped data"),
                    xy_table(table_id="XY"),
                ],
                sequence_ids=["Column", "Grouped", "XY"],
            ),
        )

    def test_dialog_previews_supported_table_and_explains_unsupported_table(self):
        with tempfile.TemporaryDirectory() as tmp:
            dialog = PrismImportDialog(self.make_pzfx(tmp))
            self.addCleanup(dialog.close)

            self.assertIsNotNone(dialog.selected_result)
            self.assertTrue(dialog.ui.buttonBox.button(QDialogButtonBox.Ok).isEnabled())
            self.assertEqual(dialog.ui.previewTable.columnCount(), 2)
            self.assertIn("Excluded: 1", dialog.ui.summaryLabel.text())
            self.assertEqual(dialog.selected_table_ids, ("Column", "Grouped"))
            self.assertEqual(dialog.ui.selectedCountLabel.text(), "2 tables selected")

            dialog.ui.tableListWidget.item(1).setCheckState(Qt.CheckState.Unchecked)
            self.assertEqual(dialog.selected_table_ids, ("Column",))
            self.assertEqual(dialog.ui.selectedCountLabel.text(), "1 table selected")
            dialog.ui.tableListWidget.item(1).setCheckState(Qt.CheckState.Checked)

            dialog.ui.tableListWidget.setCurrentRow(2)
            self.assertIsNone(dialog.selected_result)
            self.assertTrue(dialog.ui.buttonBox.button(QDialogButtonBox.Ok).isEnabled())
            self.assertIn("XY", dialog.ui.warningLabel.text())

            dialog.ui.clearSelectionButton.click()
            self.assertEqual(dialog.selected_table_ids, ())
            self.assertFalse(dialog.ui.buttonBox.button(QDialogButtonBox.Ok).isEnabled())

            dialog.ui.selectAllSupportedButton.click()
            self.assertEqual(dialog.selected_table_ids, ("Column", "Grouped"))
            self.assertTrue(dialog.ui.buttonBox.button(QDialogButtonBox.Ok).isEnabled())

    def test_choose_prism_table_returns_only_after_acceptance(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.make_pzfx(tmp)
            with mock.patch.object(PrismImportDialog, "exec", return_value=QDialog.Rejected):
                self.assertIsNone(choose_prism_table(None, path))
            with mock.patch.object(PrismImportDialog, "exec", return_value=QDialog.Accepted):
                result = choose_prism_table(None, path)
        self.assertIsNotNone(result)
        self.assertEqual(list(result.dataframe.columns), ["A", "B"])

    def test_choose_prism_tables_returns_all_checked_supported_tables(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.make_pzfx(tmp)
            with mock.patch.object(PrismImportDialog, "exec", return_value=QDialog.Accepted):
                results = choose_prism_tables(None, path)

        self.assertIsNotNone(results)
        self.assertEqual([result.table.id for result in results], ["Column", "Grouped"])

    def test_dialog_stays_open_when_any_checked_table_cannot_be_mapped(self):
        with tempfile.TemporaryDirectory() as tmp:
            invalid_table = column_table(table_id="Invalid").replace(
                "<d>1</d>",
                "<d>not-a-number</d>",
                1,
            )
            path = write_pzfx(
                pathlib.Path(tmp) / "invalid-batch.pzfx",
                pzfx_document(
                    [column_table(table_id="Valid"), invalid_table],
                    sequence_ids=["Valid", "Invalid"],
                ),
            )
            dialog = PrismImportDialog(path)
            self.addCleanup(dialog.close)

            dialog.accept()

        self.assertEqual(dialog.result(), QDialog.DialogCode.Rejected)
        self.assertIn("non-numeric", dialog.ui.warningLabel.text())

    def test_main_window_successfully_applies_confirmed_prism_data(self):
        window = self.make_window(initial_render=True)
        window.add_custom_overlay_row()
        with tempfile.TemporaryDirectory() as tmp:
            path = self.make_pzfx(tmp)
            results = import_pzfx_tables(path, ["Column", "Grouped"])
            with (
                mock.patch.object(window, "_prompt_unsaved_changes", return_value="discard"),
                mock.patch.object(main_window.QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                mock.patch.object(main_window, "choose_prism_tables", return_value=results),
                mock.patch.object(window, "render") as render,
            ):
                window.import_prism_data()

        self.assertEqual(window.settings.custom_overlay_series, [])
        self.assertEqual(window.custom_overlay_row_count(), 0)
        expected_user_data = window._without_trailing_blank_rows(
            results[0].dataframe.fillna("").astype(str)
        )
        pd.testing.assert_frame_equal(
            window._user_group_dataframe(),
            expected_user_data,
        )
        self.assertEqual(
            [sheet.name for sheet in window.workbook.sheets],
            ["Column data", "Grouped data"],
        )
        pd.testing.assert_frame_equal(
            window.workbook.sheets[1].dataframe,
            results[1].dataframe,
        )
        render.assert_called_once_with()
        self.assertIn("Imported 6 Prism groups from 2 tables", window.statusBar().currentMessage())

    def test_main_window_cancel_and_failure_do_not_change_current_data(self):
        window = self.make_window(initial_render=True)
        original = window.table_dataframe().copy()
        with tempfile.TemporaryDirectory() as tmp:
            path = self.make_pzfx(tmp)
            with (
                mock.patch.object(main_window.QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                mock.patch.object(main_window, "choose_prism_tables", return_value=None),
                mock.patch.object(window, "set_table_dataframe") as set_dataframe,
            ):
                window.import_prism_data()
            set_dataframe.assert_not_called()

            with (
                mock.patch.object(main_window.QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                mock.patch.object(main_window, "choose_prism_tables", side_effect=ValueError("broken")),
                mock.patch.object(main_window.QMessageBox, "critical") as critical,
                mock.patch.object(window, "set_table_dataframe") as set_dataframe,
            ):
                window.import_prism_data()
            set_dataframe.assert_not_called()
            critical.assert_called_once()

        pd.testing.assert_frame_equal(window.table_dataframe(), original)

    def test_generated_action_is_connected_to_file_picker(self):
        window = self.make_window()
        with mock.patch.object(main_window.QFileDialog, "getOpenFileName", return_value=("", "")) as picker:
            window.ui.actionImportPrism.trigger()
        picker.assert_called_once()


if __name__ == "__main__":
    raise SystemExit(__import__("unittest").main())
