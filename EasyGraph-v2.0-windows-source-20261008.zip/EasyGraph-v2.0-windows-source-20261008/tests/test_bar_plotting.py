from __future__ import annotations

from pathlib import Path
import tempfile

import numpy as np
import pandas as pd
from matplotlib.container import BarContainer, ErrorbarContainer

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.grouping import GroupingSettings
from easygraph.plotting.canvas import PlotCanvas
from easygraph.project_io import read_workbook_project, write_project
from easygraph.settings import BAR_SUMMARIES, ChartSettings
from easygraph.template_io import read_style_template_file, write_style_template


def bars_on(axis):
    return [patch for container in axis.containers if isinstance(container, BarContainer) for patch in container.patches]


def error_segments(axis):
    return [segment for container in axis.containers if isinstance(container, ErrorbarContainer)
            for collection in container.lines[2] for segment in collection.get_segments()]


class BarPlottingTests(EasyGraphQtTestCase):
    def make_canvas(self):
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        return canvas

    def test_grouped_bars_keep_independent_means_sample_sd_and_all_points(self):
        frame = pd.DataFrame([[1, 10], [2, 20], [3, 30]], columns=['Control', 'Control'])
        ids = ['a-control', 'b-control']
        grouping = GroupingSettings(parents=[
            {'id': 'a', 'name': 'A', 'column_ids': ids[:1]},
            {'id': 'b', 'name': 'B', 'column_ids': ids[1:]},
        ])
        canvas = self.make_canvas()
        canvas.render(frame, ChartSettings(chart_type='Bar', jitter=0, group_outer_spacing=4), grouping=grouping, column_ids=ids)
        axis = canvas.figure.axes[0]
        bars = bars_on(axis)
        np.testing.assert_allclose([bar.get_height() for bar in bars], [2, 20])
        np.testing.assert_allclose([bar.get_x() + bar.get_width()/2 for bar in bars], [0, 4])
        np.testing.assert_allclose(error_segments(axis), [[[0, 1], [0, 3]], [[4, 10], [4, 30]]])
        points = [artist for artist in axis.collections if artist.get_gid() == 'data-points']
        self.assertEqual(sum(len(artist.get_offsets()) for artist in points), 6)
        self.assertEqual(axis.get_ylim()[0], 0)
        self.assertGreater(axis.get_ylim()[1], 30)

    def test_auto_range_starts_at_zero_for_nonnegative_bars_and_scatter(self):
        canvas = self.make_canvas()
        for values in ([2, 3, 4], [0, 0, 0], [7, np.nan, np.nan]):
            for summary in BAR_SUMMARIES:
                with self.subTest(values=values, summary=summary):
                    canvas.render(pd.DataFrame({'A': values}), ChartSettings(
                        chart_type='Bar', bar_summary=summary, show_stat_table=False,
                    ))
                    lower, upper = canvas.figure.axes[0].get_ylim()
                    self.assertEqual(lower, 0)
                    self.assertGreater(upper, max(values))

    def test_negative_scatter_and_manual_range_are_preserved(self):
        canvas = self.make_canvas()
        frame = pd.DataFrame({'A': [-1, 10, 15]})
        canvas.render(frame, ChartSettings(chart_type='Bar', bar_summary='Mean', show_stat_table=False))
        self.assertGreater(bars_on(canvas.figure.axes[0])[0].get_height(), 0)
        self.assertLess(canvas.figure.axes[0].get_ylim()[0], -1)
        canvas.render(pd.DataFrame({'A': [2, 3, 4]}), ChartSettings(
            chart_type='Bar', auto_y_range=False, y_min=-5, y_max=20, show_stat_table=False,
        ))
        self.assertEqual(canvas.figure.axes[0].get_ylim(), (-5, 20))

    def test_mean_error_options_use_sample_sd_sem_and_student_t_ci(self):
        canvas = self.make_canvas()
        for summary, error in [
            ('Mean with SD', 2),
            ('Mean with SEM', 2 / np.sqrt(3)),
            ('Mean with 95% CI', 4.302652729911275 * 2 / np.sqrt(3)),
        ]:
            with self.subTest(summary=summary):
                canvas.render(pd.DataFrame({'A': [1, 3, 5]}), ChartSettings(
                    chart_type='Bar', bar_summary=summary, show_stat_table=False,
                ))
                axis = canvas.figure.axes[0]
                self.assertEqual(bars_on(axis)[0].get_height(), 3)
                np.testing.assert_allclose(error_segments(axis), [[[0, 3-error], [0, 3+error]]])
                self.assertLess(axis.get_ylim()[0], 3-error)
                self.assertGreater(axis.get_ylim()[1], 3+error)

    def test_plain_mean_median_and_ranges_are_independent_of_box_whiskers(self):
        canvas = self.make_canvas()
        for summary, center, bounds in [
            ('Mean', 22, None),
            ('Median', 3, None),
            ('Mean with range', 22, [1, 100]),
            ('Median with range', 3, [1, 100]),
        ]:
            with self.subTest(summary=summary):
                canvas.render(pd.DataFrame({'A': [1, 2, 3, 4, 100]}), ChartSettings(
                    chart_type='Bar', bar_summary=summary, show_stat_table=False,
                ))
                axis = canvas.figure.axes[0]
                self.assertEqual(bars_on(axis)[0].get_height(), center)
                if bounds is None:
                    self.assertEqual(error_segments(axis), [])
                else:
                    np.testing.assert_allclose(error_segments(axis)[0][:, 1], bounds)

    def test_median_ci_uses_observed_binomial_order_bounds_without_symmetrizing(self):
        canvas = self.make_canvas()
        for values, center, bounds in [
            ([1, 2, 3, 4, 5], 3, None),  # Even min/max covers only 93.75%.
            ([1, 2, 3, 4, 5, 6], 3.5, [1, 6]),  # 96.875% coverage.
            ([1, 2, 3, 4, 5, 8, 10, 15, 20, 40], 6.5, [2, 20]),
            ([4] * 6, 4, [4, 4]),
        ]:
            with self.subTest(values=values):
                canvas.render(pd.DataFrame({'A': [*reversed(values), np.nan]}), ChartSettings(
                    chart_type='Bar', bar_summary='Median with 95% CI', show_stat_table=False,
                ))
                axis = canvas.figure.axes[0]
                self.assertEqual(bars_on(axis)[0].get_height(), center)
                if bounds is None:
                    self.assertEqual(error_segments(axis), [])
                else:
                    np.testing.assert_allclose(error_segments(axis)[0][:, 1], bounds)

    def test_no_line_or_error_bar_retains_scatter_and_its_style(self):
        canvas = self.make_canvas()
        canvas.render(pd.DataFrame({'A': [1, 2, 3], 'B': [8, 10, 12]}), ChartSettings(
            chart_type='Bar', bar_summary='No line or error bar', show_stat_table=False,
            jitter=0, point_size=6, point_alpha=0.4,
        ))
        axis = canvas.figure.axes[0]
        self.assertEqual(bars_on(axis), [])
        self.assertEqual(error_segments(axis), [])
        points = [artist for artist in axis.collections if artist.get_gid() == 'data-points']
        self.assertEqual(sum(len(artist.get_offsets()) for artist in points), 6)
        for artist in points:
            np.testing.assert_allclose(artist.get_sizes(), [72])
            self.assertEqual(artist.get_alpha(), 0.4)
        self.assertLess(axis.get_ylim()[0], 1)
        self.assertGreater(axis.get_ylim()[1], 12)

    def test_single_value_omits_undefined_uncertainty_but_keeps_bar_and_scatter(self):
        canvas = self.make_canvas()
        for summary in ['Mean with SD', 'Mean with SEM', 'Mean with 95% CI', 'Median with 95% CI']:
            with self.subTest(summary=summary):
                canvas.render(pd.DataFrame({'A': [7, np.nan]}), ChartSettings(
                    chart_type='Bar', bar_summary=summary, show_stat_table=False,
                ))
                axis = canvas.figure.axes[0]
                self.assertEqual(bars_on(axis)[0].get_height(), 7)
                self.assertEqual(error_segments(axis), [])
                self.assertEqual(sum(len(a.get_offsets()) for a in axis.collections if a.get_gid() == 'data-points'), 1)

    def test_single_empty_constant_and_negative_columns_render_without_false_sd(self):
        frame = pd.DataFrame({'Constant': [4, 4], 'Single': [7, np.nan], 'Empty': [np.nan, np.nan], 'Negative': [-6, -4], 'Zero': [0, 0]})
        canvas = self.make_canvas()
        canvas.render(frame, ChartSettings(chart_type='Bar', show_stat_table=False))
        axis = canvas.figure.axes[0]
        np.testing.assert_allclose([bar.get_height() for bar in bars_on(axis)], [4, 7, -5, 0])
        segments = error_segments(axis)
        self.assertEqual(len(segments), 3)
        self.assertNotIn(1.0, [segment[0, 0] for segment in segments])
        np.testing.assert_allclose(segments[0][:, 1], [4, 4])
        self.assertLess(axis.get_ylim()[0], -5-np.sqrt(2))
        self.assertGreater(axis.get_ylim()[1], 7)

    def test_outlier_exclusion_changes_bars_but_preserves_raw_scatter(self):
        canvas = self.make_canvas()
        canvas.render(pd.DataFrame({'A': [1, 2, 3, 4, 100]}), ChartSettings(
            chart_type='Bar', outlier_effect='Exclude from distribution', show_stat_table=False,
        ))
        axis = canvas.figure.axes[0]
        self.assertEqual(bars_on(axis)[0].get_height(), 2.5)
        sd = np.sqrt(5/3)
        np.testing.assert_allclose(error_segments(axis)[0][:, 1], [2.5-sd, 2.5+sd])
        self.assertEqual(sum(len(artist.get_offsets()) for artist in axis.collections if artist.get_gid() == 'data-points'), 5)
        self.assertEqual(sum(len(artist.get_offsets()) for artist in axis.collections if artist.get_gid() == 'outliers'), 1)

    def test_bar_inspector_and_persistence_keep_scatter_and_error_choice(self):
        window = self.make_window()
        window.chart_type.setCurrentText('Bar')
        self.assertEqual(window.bar_summary.currentData(), 'Mean with SD')
        self.assertEqual(tuple(window.bar_summary.itemData(i) for i in range(window.bar_summary.count())), BAR_SUMMARIES)
        self.assertEqual(len(BAR_SUMMARIES), 9)
        self.assertFalse(any('geometric' in name.lower() for name in BAR_SUMMARIES))
        window.bar_summary.setCurrentIndex(window.bar_summary.findData('Median with 95% CI'))
        window.bar_width.setValue(0.7)
        window.handle_plot_object_selection('plot_area')
        self.assertFalse(window.ui.barSummaryLabel.isHidden())
        self.assertTrue(window.ui.boxWhiskerLabel.isHidden())
        self.assertTrue(window.ui.boxWidthLabel.isHidden())
        self.assertTrue(window.settings.show_points)
        self.assertIn('6', window.bar_summary.toolTip())
        window.flush_pending_render()
        window._store_active_sheet()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'bar.eg'
            write_project(path, window.workbook)
            restored = read_workbook_project(path).active_sheet.settings
            self.assertEqual((restored.chart_type, restored.bar_summary, restored.bar_width), ('Bar', 'Median with 95% CI', 0.7))
            template = write_style_template('Bar style', window.settings, Path(directory))
            self.assertEqual(read_style_template_file(template).bar_summary, 'Median with 95% CI')
        window.chart_type.setCurrentText('Box')
        window.chart_type.setCurrentText('Bar')
        self.assertEqual(window.bar_summary.currentData(), 'Median with 95% CI')
        window.bar_summary.setCurrentIndex(window.bar_summary.findData('No line or error bar'))
        self.assertTrue(window.ui.barWidthLabel.isHidden())
        self.assertTrue(window.ui.fillAlphaLabel.isHidden())
        self.assertFalse(window.ui.barSummaryLabel.isHidden())
        self.assertTrue(window.settings.show_points)
        window.bar_summary.setCurrentIndex(window.bar_summary.findData('Mean with SEM'))
        self.assertFalse(window.ui.barWidthLabel.isHidden())
        self.assertFalse(window.ui.fillAlphaLabel.isHidden())
        self.assertEqual(window.settings.bar_summary, 'Mean with SEM')
