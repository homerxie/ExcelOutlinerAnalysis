from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd

from easygraph.data import attach_group_metadata, prepare_plot_frames
from easygraph.grouping import GroupingSettings, ordered_group_blocks
from easygraph.plotting.group_layout import build_group_layout
from easygraph.project_io import read_workbook_project, write_project
from easygraph.settings import ChartSettings
from easygraph.workbook import WorkbookDocument
from tests.easygraph_case import EasyGraphQtTestCase


class OrderedGroupBlocksTests(unittest.TestCase):
    def setUp(self):
        self.parents = [
            {"id": "a", "name": "Repeated", "column_ids": ["a1", "a2"]},
            {"id": "b", "name": "Repeated", "column_ids": ["b1", "b2"]},
        ]

    def test_interleaved_legacy_order_keeps_parents_whole_and_singles_independent(self):
        order = ["b2", "single2", "a2", "b1", "single1", "a1", "b2"]
        snapshot = deepcopy(self.parents)
        self.assertEqual(
            ordered_group_blocks(order, self.parents),
            [("b", ["b2", "b1"]), (None, ["single2"]),
             ("a", ["a2", "a1"]), (None, ["single1"])],
        )
        self.assertEqual(self.parents, snapshot)
        self.assertEqual(order[-1], "b2")

    def test_outer_order_changes_blocks_without_changing_member_order(self):
        self.assertEqual(
            ordered_group_blocks(
                ["b2", "a2", "b1", "a1", "single"], self.parents,
                ["unknown", "single", "a1", "a2", "b1", "b2"],
            ),
            [(None, ["single"]), ("a", ["a2", "a1"]), ("b", ["b2", "b1"])],
        )

    def test_hidden_sibling_can_anchor_parent_and_new_blocks_are_appended(self):
        self.assertEqual(
            ordered_group_blocks(["single", "a2", "b2", "new"], self.parents, ["a1", "single"]),
            [("a", ["a2"]), (None, ["single"]), ("b", ["b2"]), (None, ["new"])],
        )

    def test_missing_members_empty_parents_and_overlapping_members_are_safe(self):
        self.parents.extend([
            {"id": "empty", "name": "Empty", "column_ids": ["deleted"]},
            {"id": "overlap", "name": "Overlap", "column_ids": ["a2", "other"]},
        ])
        self.assertEqual(
            ordered_group_blocks(["other", "a2", "a2"], self.parents),
            [("overlap", ["other"]), ("a", ["a2"])],
        )
        self.assertEqual(ordered_group_blocks([], self.parents), [])


class GroupedOrderLayoutTests(unittest.TestCase):
    def setUp(self):
        self.ids = ["single1", "a1", "a2", "single2", "b1", "b2"]
        self.frame = pd.DataFrame(
            [[1, 3, 5, 7, 9, 11], [2, 4, 6, 8, 10, 12]],
            columns=["Single", "Control", "Dose", "Single", "Control", "Dose"],
        )
        self.grouping = GroupingSettings(parents=[
            {"id": "a", "name": "Experiment A", "column_ids": ["a1", "a2"]},
            {"id": "b", "name": "Experiment B", "column_ids": ["b1", "b2"]},
        ])
        self.manual = ["b2", "b1", "single2", "a2", "a1", "single1"]

    def layout(self, settings, *, frame=None, grouping=None, ids=None):
        data = self.frame if frame is None else frame
        ids = self.ids if ids is None else ids
        grouping = self.grouping if grouping is None else grouping
        prepared = prepare_plot_frames(attach_group_metadata(data, ids), settings)
        return build_group_layout(prepared.visible, settings, grouping, ids)

    def test_manual_moves_outer_blocks_and_subgroups_without_reassigning_colors(self):
        for color_mode in ("Subgroup", "Parent"):
            with self.subTest(color_mode=color_mode):
                baseline = self.layout(ChartSettings(group_color_mode=color_mode))
                settings = ChartSettings(
                    group_order="Manual", manual_group_order=self.manual,
                    group_color_mode=color_mode,
                )
                reordered = self.layout(settings)
                self.assertEqual(reordered.order, tuple(self.manual))
                self.assertEqual([span.key for span in reordered.parents], ["b", "a"])
                np.testing.assert_allclose(list(reordered.positions.values()), [0, 1, 3.7, 6.4, 7.4, 10.1])
                self.assertEqual(reordered.colors, baseline.colors)
                if color_mode == "Parent":
                    self.assertEqual(
                        [name for name, _color in reordered.legend],
                        ["Experiment B", "Single", "Experiment A", "Single"],
                    )

    def test_automatic_sorting_keeps_physical_outer_order(self):
        layout = self.layout(ChartSettings(group_order="Mean descending"))
        self.assertEqual(layout.order, ("single1", "a2", "a1", "single2", "b2", "b1"))
        self.assertEqual([span.key for span in layout.parents], ["a", "b"])

    def test_hidden_and_empty_members_keep_manual_outer_position_and_empty_slot(self):
        self.frame = self.frame.astype(float)
        self.frame.iloc[:, 4] = np.nan
        settings = ChartSettings(
            group_order="Manual", manual_group_order=["b2", "single2", "a2", "b1", "a1", "single1"],
            group_hidden=["b2"],
        )
        layout = self.layout(settings)
        self.assertEqual(layout.order, ("b1", "single2", "a2", "a1", "single1"))
        self.assertEqual(layout.positions["b1"], 0)
        self.assertEqual([span.key for span in layout.parents], ["b", "a"])
        settings.group_hidden.append("b1")
        hidden_parent = self.layout(settings)
        self.assertEqual(hidden_parent.order, ("single2", "a2", "a1", "single1"))
        self.assertEqual([span.key for span in hidden_parent.parents], ["a"])

    def test_shared_category_legend_follows_manual_members_without_changing_colors(self):
        self.grouping.shared_subgroups = True
        self.grouping.subgroup_ids = {"a1": "control", "b1": "control", "a2": "dose", "b2": "dose"}
        before = self.layout(ChartSettings())
        after = self.layout(ChartSettings(group_order="Manual", manual_group_order=self.manual))
        self.assertEqual(after.colors, before.colors)
        self.assertEqual([label for label, _color in after.legend], ["Dose", "Control", "Single", "Single"])

    def test_inserted_member_joins_its_parent_and_grouping_switch_keeps_flat_order(self):
        self.ids.insert(2, "a-new")
        self.frame.insert(2, "New", [21, 22])
        self.grouping.parents[0]["column_ids"].insert(1, "a-new")
        settings = ChartSettings(group_order="Manual", manual_group_order=self.manual)
        grouped = self.layout(settings)
        self.assertEqual(grouped.order, ("b2", "b1", "single2", "a2", "a1", "a-new", "single1"))
        ungrouped = self.layout(settings, grouping=GroupingSettings())
        self.assertEqual(ungrouped.order, tuple([*self.manual, "a-new"]))
        self.assertEqual(settings.manual_group_order, self.manual)

    def test_project_roundtrip_preserves_flat_order_parent_membership_and_data(self):
        settings = ChartSettings(group_order="Manual", manual_group_order=self.manual)
        book = WorkbookDocument.single(self.frame, settings, column_ids=self.ids, grouping=self.grouping)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "manual.eg"
            write_project(path, book)
            loaded = read_workbook_project(path).active_sheet
        self.assertEqual(loaded.settings.manual_group_order, self.manual)
        self.assertEqual(loaded.grouping, self.grouping)
        pd.testing.assert_frame_equal(loaded.dataframe.astype(float), self.frame.astype(float))
        layout = self.layout(loaded.settings, frame=loaded.dataframe, grouping=loaded.grouping, ids=loaded.column_ids)
        self.assertEqual(layout.order, tuple(self.manual))


class ManualGroupedChartTests(EasyGraphQtTestCase):
    def test_all_chart_types_use_the_manual_parent_and_member_order(self):
        from easygraph.plotting.canvas import PlotCanvas

        ids = ["a1", "a2", "single", "b1", "b2"]
        frame = pd.DataFrame([[1, 4, 7, 10, 13], [2, 5, 8, 11, 14], [3, 6, 9, 12, 15]], columns=["Control", "Dose", "Single", "Control", "Dose"])
        grouping = GroupingSettings(parents=[
            {"id": "a", "name": "Experiment A", "column_ids": ["a1", "a2"]},
            {"id": "b", "name": "Experiment B", "column_ids": ["b1", "b2"]},
        ])
        manual = ["b2", "b1", "single", "a2", "a1"]
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            with self.subTest(chart_type=chart_type):
                canvas = PlotCanvas()
                self.addCleanup(canvas.close)
                settings = ChartSettings(
                    chart_type=chart_type, group_order="Manual", manual_group_order=manual,
                    line_overlay_stat="Mean", jitter=0,
                )
                canvas.render(frame, settings, grouping=grouping, column_ids=ids)
                ax = canvas.figure.axes[0]
                layout = canvas._group_layout
                self.assertEqual(layout.order, tuple(manual))
                ridge = chart_type == "Ridge"
                labels = ax.get_yticklabels() if ridge else ax.get_xticklabels()
                self.assertEqual([label.get_text() for label in labels], ["Dose", "Control", "Single", "Dose", "Control"])
                self.assertEqual([text.get_text() for text in ax.texts if text.get_gid() == "group-parent-label"], ["Experiment B", "Experiment A"])
                mean = next(line for line in ax.lines if line.get_label() == "Mean")
                np.testing.assert_allclose(mean.get_xdata() if ridge else mean.get_ydata(), [14, 11, 8, 5, 2])
                np.testing.assert_allclose(
                    mean.get_ydata() if ridge else mean.get_xdata(),
                    [layout.coordinate(key, ridge=ridge) for key in manual],
                )


if __name__ == "__main__":
    unittest.main()
