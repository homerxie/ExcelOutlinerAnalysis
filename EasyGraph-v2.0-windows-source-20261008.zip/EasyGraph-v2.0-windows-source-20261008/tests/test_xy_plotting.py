from __future__ import annotations

import math
import os
import subprocess
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd
from matplotlib.collections import PathCollection
from matplotlib.lines import Line2D
from matplotlib.ticker import AutoLocator, MultipleLocator
from matplotlib.transforms import Bbox

from tests.easygraph_case import ROOT, EasyGraphQtTestCase, EasyGraphTestCase

from easygraph.settings import ChartSettings, LEGEND_POSITION_INSIDE
from easygraph.xy_data import prepare_xy_data
from easygraph.xy_series import XYSeriesSpec, XYSettings


class XYDataTests(EasyGraphTestCase):
    def test_shared_paired_and_mixed_series_keep_row_order_and_independent_lengths(self):
        frame = pd.DataFrame(
            {
                "shared": [2, 1, 3, 4],
                "a": [20, 10, 30, ""],
                "other": [100, 300, "", ""],
                "b": [1, 3, "", ""],
            }
        )
        settings = XYSettings(
            default_x_column_id="shared",
            series=[
                XYSeriesSpec(id="a-series", name="A", y_column_id="a"),
                XYSeriesSpec(
                    id="b-series",
                    name="B",
                    x_column_id="other",
                    y_column_id="b",
                ),
            ],
        )

        prepared = prepare_xy_data(
            frame,
            ["shared", "a", "other", "b"],
            settings,
        )

        self.assertEqual(prepared.series[0].x.tolist(), [2.0, 1.0, 3.0])
        self.assertEqual(prepared.series[0].y.tolist(), [20.0, 10.0, 30.0])
        self.assertEqual(prepared.series[1].x.tolist(), [100.0, 300.0])
        self.assertEqual(prepared.series[1].y.tolist(), [1.0, 3.0])
        self.assertEqual(prepared.series[0].valid_count, 3)
        self.assertEqual(prepared.series[0].skipped_count, 1)
        self.assertEqual(prepared.series[1].valid_count, 2)
        self.assertEqual(prepared.series[1].skipped_count, 2)

    def test_missing_columns_and_empty_pairs_are_reported_without_shifting_data(self):
        frame = pd.DataFrame({"X": [1, "bad"], "Y": ["", 2]})
        settings = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(id="empty", name="Empty", y_column_id="y"),
                XYSeriesSpec(id="missing", name="Missing", y_column_id="gone"),
            ],
        )

        prepared = prepare_xy_data(frame, ["x", "y"], settings)

        self.assertEqual(prepared.series[0].valid_count, 0)
        self.assertEqual(prepared.series[0].skipped_count, 2)
        self.assertEqual([issue.series_id for issue in prepared.issues], ["empty", "missing"])
        self.assertIn("No valid X/Y pairs", prepared.issues[0].message)
        self.assertIn("missing Y column", prepared.issues[1].message)

    def test_series_can_be_sorted_by_name_without_mutating_mapping_order(self):
        frame = pd.DataFrame({"X": [1], "B": [2], "A": [3]})
        settings = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(id="b", name="Beta", y_column_id="b"),
                XYSeriesSpec(id="a", name="Alpha", y_column_id="a"),
            ],
        )

        prepared = prepare_xy_data(
            frame,
            ["x", "b", "a"],
            settings,
            order_mode="Name A-Z",
        )

        self.assertEqual([series.id for series in prepared.series], ["a", "b"])
        self.assertEqual([series.id for series in settings.series], ["b", "a"])

    def test_xy_data_module_has_no_qt_canvas_or_app_dependency(self):
        source_path = str(ROOT / "src")
        environment = os.environ.copy()
        environment["PYTHONPATH"] = source_path
        code = """
import sys
from easygraph import xy_data
for forbidden in ("PySide6", "matplotlib", "easygraph.plotting.canvas", "easygraph.ui.main_window"):
    if any(name == forbidden or name.startswith(forbidden + ".") for name in sys.modules):
        raise SystemExit("forbidden dependency loaded: " + forbidden)
"""
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=ROOT,
            env=environment,
            capture_output=True,
            text=True,
            timeout=20,
        )
        self.assertEqual(result.returncode, 0, msg=result.stderr or result.stdout)


class XYRendererTests(EasyGraphQtTestCase):
    def test_xy_numeric_x_tick_labels_ignore_category_rotation(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame({"X": [1, 2, 3], "Y": [2, 4, 8]})
        xy = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )

        canvas.render(
            frame,
            ChartSettings(show_stat_table=False, x_tick_rotation=65),
            xy_settings=xy,
            column_ids=["x", "y"],
        )

        labels = canvas.figure.axes[0].get_xticklabels()
        self.assertTrue(labels)
        self.assertTrue(all(label.get_rotation() == 0 for label in labels))

    def test_xy_manual_x_range_and_tick_interval_apply_to_numeric_axis(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame({"X": [1, 2, 3], "Y": [2, 4, 8]})
        xy = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )
        chart = ChartSettings(
            show_stat_table=False,
            auto_x_range=False,
            x_min=-2.0,
            x_max=8.0,
            x_auto_tick_interval=False,
            x_tick_interval=2.5,
        )

        canvas.render(frame, chart, xy_settings=xy, column_ids=["x", "y"])

        ax = canvas.figure.axes[0]
        self.assertEqual(ax.get_xlim(), (-2.0, 8.0))
        self.assertIsInstance(ax.xaxis.get_major_locator(), MultipleLocator)
        visible_ticks = [tick for tick in ax.get_xticks() if -2.0 <= tick <= 8.0]
        self.assertGreaterEqual(len(visible_ticks), 2)
        self.assertTrue(
            all(
                math.isclose(right - left, 2.5)
                for left, right in zip(visible_ticks, visible_ticks[1:])
            )
        )
        self.assertNotIn("x", canvas._auto_tick_interval_fallbacks)

    def test_xy_auto_x_range_uses_visible_data_instead_of_stored_manual_limits(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame({"X": [10, 20], "Y": [2, 4]})
        xy = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )
        chart = ChartSettings(
            show_stat_table=False,
            auto_x_range=True,
            x_min=100.0,
            x_max=200.0,
        )

        canvas.render(frame, chart, xy_settings=xy, column_ids=["x", "y"])

        x_min, x_max = canvas.figure.axes[0].get_xlim()
        self.assertLessEqual(x_min, 10.0)
        self.assertGreaterEqual(x_max, 20.0)
        self.assertLess(x_max, 100.0)

    def test_xy_unsafe_manual_x_tick_intervals_fall_back_to_auto_locator(self):
        from easygraph.plotting.canvas import PlotCanvas

        frame = pd.DataFrame({"X": [0, 10_000], "Y": [2, 4]})
        xy = XYSettings(
            default_x_column_id="x",
            series=[XYSeriesSpec(id="y", name="Y", y_column_id="y")],
        )

        for interval in (0.0, float("nan"), 0.000001):
            with self.subTest(interval=interval):
                canvas = PlotCanvas()
                self.addCleanup(canvas.close)
                chart = ChartSettings(
                    show_stat_table=False,
                    auto_x_range=False,
                    x_min=0.0,
                    x_max=10_000.0,
                    x_auto_tick_interval=False,
                    x_tick_interval=interval,
                )

                canvas.render(
                    frame,
                    chart,
                    xy_settings=xy,
                    column_ids=["x", "y"],
                )

                ax = canvas.figure.axes[0]
                self.assertIsInstance(ax.xaxis.get_major_locator(), AutoLocator)
                self.assertEqual(canvas._auto_tick_interval_fallbacks, {"x"})

    def test_xy_display_modes_create_pickable_series_targets_with_tight_feedback(self):
        from easygraph.plotting.canvas import PlotCanvas

        frame = pd.DataFrame({"X": [1, 2, 3], "Y": [1, 4, 2]})
        modes = (
            ("scatter", True, False, PathCollection),
            ("points and line", True, True, Line2D),
            ("line", False, True, Line2D),
        )

        for mode, show_points, show_line, artist_type in modes:
            with self.subTest(mode=mode):
                canvas = PlotCanvas()
                self.addCleanup(canvas.close)
                selected_kinds = []
                canvas.selection_callback = selected_kinds.append
                xy = XYSettings(
                    default_x_column_id="x",
                    show_points=show_points,
                    show_line=show_line,
                    series=[
                        XYSeriesSpec(id="series-y", name="Y", y_column_id="y")
                    ],
                )

                canvas.render(
                    frame,
                    ChartSettings(
                        title="",
                        x_label="",
                        y_label="",
                        show_stat_table=False,
                    ),
                    xy_settings=xy,
                    column_ids=["x", "y"],
                )

                targets = [
                    target
                    for target in canvas._interaction_targets
                    if target["kind"] == "points"
                    and target.get("source") == "plot"
                ]
                self.assertEqual(len(targets), 1)
                target = targets[0]
                self.assertIsInstance(target["artist"], artist_type)
                self.assertEqual(target["series_id"], "series-y")
                ax = canvas.figure.axes[0]
                axes_bbox = ax.get_window_extent(canvas.canvas.get_renderer())
                self.assertLess(target["bbox"].width, axes_bbox.width)
                self.assertLess(target["bbox"].height, axes_bbox.height)
                self.assertFalse(any(
                    candidate["kind"] == "plot_area"
                    for candidate in canvas._interaction_targets
                ))
                display_x, display_y = ax.transData.transform((2.0, 4.0))
                event = SimpleNamespace(
                    x=float(display_x),
                    y=float(display_y),
                    button=1,
                )
                self.assertIs(canvas._interaction_target_at_event(event), target)

                canvas._handle_plot_motion(event)
                self.assertEqual(canvas._hover_object_kind, "points")
                self.assertEqual(canvas._hover_series_id, "series-y")
                self.assertIsNotNone(canvas._hover_feedback_patch)
                expected_feedback_count = 2 if show_points and show_line else 1
                self.assertEqual(
                    len(canvas._hover_feedback_patch),
                    expected_feedback_count,
                )
                hover_feedback = canvas._hover_feedback_patch[0]
                for feedback in canvas._hover_feedback_patch:
                    self.assertIsInstance(feedback, artist_type)
                    self.assertIs(
                        feedback._easygraph_feedback_source,
                        target["artist"],
                    )
                if artist_type is PathCollection:
                    self.assertEqual(len(hover_feedback.get_facecolors()), 0)
                    self.assertEqual(hover_feedback.get_alpha(), 1.0)
                    self.assertFalse(hover_feedback.get_path_effects())
                else:
                    self.assertTrue(hover_feedback.get_path_effects())
                    if show_points:
                        marker_feedback = canvas._hover_feedback_patch[1]
                        self.assertEqual(marker_feedback.get_linestyle(), "None")
                        self.assertEqual(marker_feedback.get_markerfacecolor(), "none")

                canvas._handle_plot_click(event)

                self.assertEqual(canvas._selected_object_kind, "points")
                self.assertEqual(canvas._xy_selection_scope, "subset")
                self.assertEqual(canvas._selected_series_ids, {"series-y"})
                self.assertEqual(canvas._selected_series_id, "series-y")
                self.assertEqual(selected_kinds, ["points"])
                self.assertIsNotNone(canvas._selected_feedback_patch)
                self.assertEqual(
                    len(canvas._selected_feedback_patch),
                    expected_feedback_count,
                )
                for feedback in canvas._selected_feedback_patch:
                    self.assertIsInstance(feedback, artist_type)
                    self.assertIs(
                        feedback._easygraph_feedback_source,
                        target["artist"],
                    )

                canvas._handle_plot_click(
                    SimpleNamespace(
                        x=float(display_x),
                        y=float(display_y),
                        button=1,
                        dblclick=True,
                    )
                )
                self.assertEqual(canvas._selected_series_id, "series-y")
                self.assertEqual(selected_kinds, ["points", "points"])

                blank_event = None
                for x_fraction in (0.2, 0.4, 0.6, 0.8):
                    for y_fraction in (0.2, 0.4, 0.6, 0.8):
                        candidate = SimpleNamespace(
                            x=axes_bbox.x0 + axes_bbox.width * x_fraction,
                            y=axes_bbox.y0 + axes_bbox.height * y_fraction,
                            button=1,
                        )
                        if canvas._interaction_target_at_event(candidate) is None:
                            blank_event = candidate
                            break
                    if blank_event is not None:
                        break
                self.assertIsNotNone(blank_event)
                canvas._handle_plot_motion(blank_event)
                self.assertIsNone(canvas._hover_object_kind)
                self.assertIsNone(canvas._hover_series_id)
                self.assertIsNone(canvas._hover_feedback_patch)
                canvas._handle_plot_click(blank_event)
                self.assertIsNone(canvas._selected_object_kind)
                self.assertEqual(canvas._xy_selection_scope, "none")
                self.assertEqual(canvas._selected_series_ids, set())
                self.assertIsNone(canvas._selected_series_id)
                self.assertEqual(selected_kinds, ["points", "points", None])

    def test_xy_selection_scope_supports_single_all_and_modifier_toggle(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        selected_kinds = []
        canvas.selection_callback = selected_kinds.append
        canvas.render(
            pd.DataFrame(
                {
                    "X": [2.0, 5.0, 8.0],
                    "A": [2.0, 2.0, 2.0],
                    "B": [5.0, 5.0, 5.0],
                    "C": [8.0, 8.0, 8.0],
                }
            ),
            ChartSettings(
                show_stat_table=False,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
            ),
            xy_settings=XYSettings(
                default_x_column_id="x",
                show_points=True,
                show_line=False,
                series=[
                    XYSeriesSpec(id="a", name="A", y_column_id="a"),
                    XYSeriesSpec(id="b", name="B", y_column_id="b"),
                    XYSeriesSpec(id="c", name="C", y_column_id="c"),
                ],
            ),
            column_ids=["x", "a", "b", "c"],
        )
        axis = canvas.figure.axes[0]

        def event_at(x, y, **kwargs):
            display_x, display_y = axis.transData.transform((x, y))
            return SimpleNamespace(
                x=float(display_x),
                y=float(display_y),
                button=1,
                **kwargs,
            )

        canvas._handle_plot_click(event_at(2.0, 2.0))
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, {"a"})
        self.assertEqual(canvas._selected_series_id, "a")
        self.assertEqual(len(canvas._selected_feedback_patch), 1)

        canvas._handle_plot_click(event_at(2.0, 2.0, dblclick=True))
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, {"a"})
        self.assertEqual(canvas._selected_series_id, "a")

        canvas._handle_plot_click(event_at(5.0, 5.0, key="control"))
        canvas._handle_plot_click(event_at(8.0, 8.0, key="cmd"))
        self.assertEqual(canvas._selected_series_ids, {"a", "b", "c"})
        self.assertIsNone(canvas._selected_series_id)
        self.assertEqual(len(canvas._selected_feedback_patch), 3)

        canvas._handle_plot_click(event_at(2.0, 2.0, key="control"))
        self.assertEqual(canvas._selected_series_ids, {"b", "c"})
        self.assertIsNone(canvas._selected_series_id)

        canvas.set_xy_series_selection("all", set())
        canvas._handle_plot_click(event_at(5.0, 5.0, key="control"))
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, {"a", "c"})
        self.assertIsNone(canvas._selected_series_id)
        canvas._handle_plot_click(event_at(5.0, 5.0, key="control"))
        self.assertEqual(canvas._selected_series_ids, {"a", "b", "c"})
        self.assertIsNone(canvas._selected_series_id)

        canvas.set_xy_series_selection("subset", {"b"})
        canvas._handle_plot_click(event_at(5.0, 5.0, key="control"))
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, set())
        self.assertEqual(canvas._selected_object_kind, "points")
        self.assertIsNone(canvas._selected_series_id)
        self.assertIsNone(canvas._selected_feedback_patch)
        self.assertTrue(all(kind == "points" for kind in selected_kinds))

    def test_xy_subset_selection_keeps_hidden_ids_and_prunes_deleted_ids(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "X": [1.0, 2.0, 3.0],
                "Visible": [1.0, 2.0, 1.0],
                "Hidden": [3.0, 2.0, 3.0],
            }
        )
        chart = ChartSettings(show_stat_table=False)
        xy = XYSettings(
            default_x_column_id="x",
            show_points=False,
            show_line=True,
            series=[
                XYSeriesSpec(id="visible", name="Visible", y_column_id="visible"),
                XYSeriesSpec(
                    id="hidden",
                    name="Hidden",
                    y_column_id="hidden",
                    visible=False,
                ),
            ],
        )
        canvas.render(
            frame,
            chart,
            xy_settings=xy,
            column_ids=["x", "visible", "hidden"],
        )

        canvas.set_xy_series_selection("all", set())
        self.assertEqual(len(canvas._selected_feedback_patch), 1)
        display_x, display_y = canvas.figure.axes[0].transData.transform(
            (2.0, 2.0)
        )
        canvas._handle_plot_click(
            SimpleNamespace(
                x=float(display_x),
                y=float(display_y),
                button=1,
                key="control",
            )
        )
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, {"hidden"})
        self.assertEqual(canvas._selected_series_id, "hidden")
        self.assertIsNone(canvas._selected_feedback_patch)

        canvas.set_xy_series_selection("subset", {"hidden", "deleted"})
        self.assertEqual(canvas._selected_series_ids, {"hidden", "deleted"})
        self.assertIsNone(canvas._selected_feedback_patch)

        canvas.render(
            frame,
            chart,
            xy_settings=xy,
            column_ids=["x", "visible", "hidden"],
        )

        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, {"hidden"})
        self.assertEqual(canvas._selected_series_id, "hidden")
        self.assertEqual(canvas._selected_object_kind, "points")
        self.assertIsNone(canvas._selected_feedback_patch)

        canvas.set_xy_series_selection("subset", set())
        canvas.render(
            frame,
            chart,
            xy_settings=xy,
            column_ids=["x", "visible", "hidden"],
        )
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, set())
        self.assertEqual(canvas._selected_object_kind, "points")

    def test_xy_box_selection_uses_real_line_geometry_and_modifier_operations(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            pd.DataFrame(
                {
                    "X": [1.0, 9.0],
                    "Ascending": [1.0, 9.0],
                    "Descending": [9.0, 1.0],
                }
            ),
            ChartSettings(
                show_stat_table=False,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
            ),
            xy_settings=XYSettings(
                default_x_column_id="x",
                show_points=False,
                show_line=True,
                series=[
                    XYSeriesSpec(
                        id="ascending",
                        name="Ascending",
                        y_column_id="ascending",
                    ),
                    XYSeriesSpec(
                        id="descending",
                        name="Descending",
                        y_column_id="descending",
                    ),
                ],
            ),
            column_ids=["x", "ascending", "descending"],
        )
        axis = canvas.figure.axes[0]
        self.assertFalse(canvas.xy_box_select_button.isHidden())
        self.assertTrue(canvas.xy_box_select_button.isEnabled())
        self.assertEqual(canvas._xy_box_select_shortcut.key().toString(), "B")
        canvas.set_xy_box_select_enabled(True)
        self.assertTrue(canvas._xy_box_select_enabled)

        def event_at(x, y, **kwargs):
            display_x, display_y = axis.transData.transform((x, y))
            return SimpleNamespace(
                x=float(display_x),
                y=float(display_y),
                button=1,
                **kwargs,
            )

        def drag(start, end, **kwargs):
            press = event_at(*start, **kwargs)
            move = event_at(*end)
            canvas._handle_plot_click(press)
            self.assertIsNotNone(canvas._xy_box_select_state)
            canvas._handle_plot_motion(move)
            preview_ids = set(canvas._xy_box_select_state["preview_ids"])
            self.assertIsNotNone(canvas._xy_box_selection_patch)
            canvas._handle_plot_release(move)
            self.assertIsNone(canvas._xy_box_select_state)
            self.assertIsNone(canvas._xy_box_selection_patch)
            self.assertIsNone(canvas._hover_feedback_patch)
            return preview_ids

        canvas.set_xy_series_selection("all", set())
        preview = drag((1.7, 7.7), (2.3, 8.3), key="control")
        self.assertEqual(preview, {"descending"})
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(
            canvas._selected_series_ids,
            {"ascending", "descending"},
        )

        preview = drag((1.7, 7.7), (2.3, 8.3))
        self.assertEqual(preview, {"descending"})
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, {"descending"})

        preview = drag((1.7, 1.7), (2.3, 2.3), key="control")
        self.assertEqual(preview, {"ascending"})
        self.assertEqual(
            canvas._selected_series_ids,
            {"ascending", "descending"},
        )

        preview = drag((1.7, 7.7), (2.3, 8.3), key="alt")
        self.assertEqual(preview, {"descending"})
        self.assertEqual(canvas._selected_series_ids, {"ascending"})
        self.assertEqual(canvas._selected_series_id, "ascending")

        # This rectangle lies inside both artists' outer bboxes, but touches
        # neither diagonal. Replacing with it must produce an empty subset.
        center_x, center_y = axis.transData.transform((2.0, 5.0))
        plot_targets = [
            target
            for target in canvas._interaction_targets
            if target.get("kind") == "points"
            and target.get("source") == "plot"
        ]
        self.assertTrue(
            all(target["bbox"].contains(center_x, center_y) for target in plot_targets)
        )
        preview = drag((1.7, 4.7), (2.3, 5.3))
        self.assertEqual(preview, set())
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, set())
        self.assertEqual(canvas._selected_object_kind, "points")

        canvas.clear_plot_selection()
        self.assertFalse(canvas._xy_box_select_enabled)
        self.assertFalse(canvas.xy_box_select_button.isChecked())

        canvas.render(
            pd.DataFrame({"A": [1.0, 2.0], "B": [3.0, 4.0]}),
            ChartSettings(show_stat_table=False),
        )
        self.assertTrue(canvas.xy_box_select_button.isHidden())
        self.assertFalse(canvas.xy_box_select_button.isEnabled())

    def test_xy_box_selection_uses_scatter_marker_paths_not_collection_bbox(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            pd.DataFrame({"X": [2.0, 8.0], "Y": [2.0, 8.0]}),
            ChartSettings(
                show_stat_table=False,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
            ),
            xy_settings=XYSettings(
                default_x_column_id="x",
                show_points=True,
                show_line=False,
                point_size=8.0,
                series=[XYSeriesSpec(id="series-y", name="Y", y_column_id="y")],
            ),
            column_ids=["x", "y"],
        )
        axis = canvas.figure.axes[0]

        def display_bbox(x0, y0, x1, y1):
            lower, upper = axis.transData.transform([(x0, y0), (x1, y1)])
            return Bbox.from_extents(lower[0], lower[1], upper[0], upper[1])

        empty_bbox = display_bbox(1.8, 7.8, 2.2, 8.2)
        target = next(
            target
            for target in canvas._interaction_targets
            if target.get("kind") == "points"
            and target.get("source") == "plot"
        )
        center_x, center_y = axis.transData.transform((2.0, 8.0))
        self.assertTrue(target["bbox"].contains(center_x, center_y))
        self.assertEqual(
            canvas._xy_series_ids_intersecting_bbox(empty_bbox),
            set(),
        )
        self.assertEqual(
            canvas._xy_series_ids_intersecting_bbox(
                display_bbox(1.95, 1.95, 2.05, 2.05)
            ),
            {"series-y"},
        )

    def test_xy_series_feedback_is_clipped_to_manual_axis_limits(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "X": [1.0, 5.0, 1_000.0],
                "Y": [1.0, 5.0, 1_000.0],
            }
        )
        xy = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=True,
            series=[
                XYSeriesSpec(id="series-y", name="Y", y_column_id="y")
            ],
        )
        chart = ChartSettings(
            title="",
            x_label="",
            y_label="",
            show_stat_table=False,
            auto_x_range=False,
            x_min=0.0,
            x_max=10.0,
            auto_y_range=False,
            y_min=0.0,
            y_max=10.0,
        )

        canvas.render(
            frame,
            chart,
            xy_settings=xy,
            column_ids=["x", "y"],
        )

        target = next(
            target
            for target in canvas._interaction_targets
            if target["kind"] == "points"
            and target.get("source") == "plot"
        )
        axes_bbox = canvas.figure.axes[0].get_window_extent(
            canvas.canvas.get_renderer()
        )
        self.assertGreaterEqual(target["bbox"].x0, axes_bbox.x0)
        self.assertLessEqual(target["bbox"].x1, axes_bbox.x1)
        self.assertGreaterEqual(target["bbox"].y0, axes_bbox.y0)
        self.assertLessEqual(target["bbox"].y1, axes_bbox.y1)

        visible_x, visible_y = canvas.figure.axes[0].transData.transform(
            (5.0, 5.0)
        )
        canvas._handle_plot_click(
            SimpleNamespace(
                x=float(visible_x),
                y=float(visible_y),
                button=1,
            )
        )

        highlight = canvas._selected_feedback_patch[0]
        self.assertIsInstance(highlight, Line2D)
        self.assertIs(highlight._easygraph_feedback_source, target["artist"])
        self.assertEqual(
            tuple(highlight.get_clip_box().extents),
            tuple(target["artist"].get_clip_box().extents),
        )
        self.assertTrue(highlight.get_path_effects())

    def test_xy_scatter_outline_does_not_repaint_transparent_marker_center(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            pd.DataFrame({"X": [5.0], "Y": [5.0]}),
            ChartSettings(
                title="",
                x_label="",
                y_label="",
                show_legend=False,
                show_stat_table=False,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
            ),
            xy_settings=XYSettings(
                default_x_column_id="x",
                show_points=True,
                show_line=False,
                point_size=18.0,
                point_alpha=0.1,
                series=[XYSeriesSpec(id="series-y", name="Y", y_column_id="y")],
            ),
            column_ids=["x", "y"],
        )
        self.qapp.processEvents()
        before = np.asarray(canvas.canvas.buffer_rgba()).copy()
        display_x, display_y = canvas.figure.axes[0].transData.transform((5.0, 5.0))
        canvas._handle_plot_click(
            SimpleNamespace(x=float(display_x), y=float(display_y), button=1)
        )
        self.qapp.processEvents()
        after = np.asarray(canvas.canvas.buffer_rgba()).copy()

        height, width = before.shape[:2]
        column = min(max(int(round(display_x)), 1), width - 2)
        row = min(max(height - 1 - int(round(display_y)), 1), height - 2)
        np.testing.assert_array_equal(
            before[row - 1 : row + 2, column - 1 : column + 2],
            after[row - 1 : row + 2, column - 1 : column + 2],
        )
        radius = 24
        before_crop = before[
            max(0, row - radius) : min(height, row + radius + 1),
            max(0, column - radius) : min(width, column + radius + 1),
        ]
        after_crop = after[
            max(0, row - radius) : min(height, row + radius + 1),
            max(0, column - radius) : min(width, column + radius + 1),
        ]
        self.assertTrue(np.any(before_crop != after_crop))
        outline = canvas._selected_feedback_patch[0]
        self.assertIsInstance(outline, PathCollection)
        self.assertEqual(len(outline.get_facecolors()), 0)
        self.assertEqual(outline.get_alpha(), 1.0)

    def test_xy_scatter_feedback_ignores_individually_clipped_points(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "X": [5.0, 1_000.0],
                "Y": [5.0, 1_000.0],
            }
        )
        xy = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=False,
            series=[
                XYSeriesSpec(id="series-y", name="Y", y_column_id="y")
            ],
        )
        chart = ChartSettings(
            title="",
            x_label="",
            y_label="",
            show_stat_table=False,
            auto_x_range=False,
            x_min=0.0,
            x_max=10.0,
            auto_y_range=False,
            y_min=0.0,
            y_max=10.0,
        )

        canvas.render(
            frame,
            chart,
            xy_settings=xy,
            column_ids=["x", "y"],
        )

        target = next(
            target
            for target in canvas._interaction_targets
            if target["kind"] == "points"
            and target.get("source") == "plot"
        )
        axes_bbox = canvas.figure.axes[0].get_window_extent(
            canvas.canvas.get_renderer()
        )
        self.assertLess(target["bbox"].x1, axes_bbox.x1)
        self.assertLess(target["bbox"].y1, axes_bbox.y1)

    def test_xy_series_hit_testing_requires_the_actual_line_or_marker(self):
        from easygraph.plotting.canvas import PlotCanvas

        frame = pd.DataFrame(
            {
                "X": [2.0, 8.0],
                "Y": [2.0, 8.0],
            }
        )
        for name, show_points, show_line in (
            ("scatter", True, False),
            ("line", False, True),
        ):
            with self.subTest(mode=name):
                canvas = PlotCanvas()
                self.addCleanup(canvas.close)
                xy = XYSettings(
                    default_x_column_id="x",
                    show_points=show_points,
                    show_line=show_line,
                    series=[
                        XYSeriesSpec(
                            id="series-y",
                            name="Y",
                            y_column_id="y",
                        )
                    ],
                )
                canvas.render(
                    frame,
                    ChartSettings(
                        title="",
                        x_label="",
                        y_label="",
                        show_stat_table=False,
                        auto_x_range=False,
                        x_min=0.0,
                        x_max=10.0,
                        auto_y_range=False,
                        y_min=0.0,
                        y_max=10.0,
                    ),
                    xy_settings=xy,
                    column_ids=["x", "y"],
                )

                axis = canvas.figure.axes[0]
                empty_x, empty_y = axis.transData.transform((2.0, 8.0))
                empty_event = SimpleNamespace(
                    x=float(empty_x),
                    y=float(empty_y),
                    button=1,
                )
                target_bbox = next(
                    target["bbox"]
                    for target in canvas._interaction_targets
                    if target["kind"] == "points"
                    and target.get("source") == "plot"
                )
                self.assertTrue(target_bbox.contains(empty_x, empty_y))
                self.assertIsNone(
                    canvas._interaction_target_at_event(empty_event)
                )
                canvas._handle_plot_motion(empty_event)
                self.assertIsNone(canvas._hover_object_kind)
                self.assertIsNone(canvas._hover_series_id)

    def test_xy_series_hit_testing_rejects_clipped_artists_outside_the_axes(self):
        from easygraph.plotting.canvas import PlotCanvas

        cases = (
            (
                "line",
                pd.DataFrame({"X": [1.0, 20.0], "Y": [1.0, 20.0]}),
                False,
                True,
                (10.05, 10.05),
            ),
            (
                "scatter",
                pd.DataFrame({"X": [1.0, 10.05], "Y": [1.0, 5.0]}),
                True,
                False,
                (10.05, 5.0),
            ),
        )
        for name, frame, show_points, show_line, event_data in cases:
            with self.subTest(mode=name):
                canvas = PlotCanvas()
                self.addCleanup(canvas.close)
                canvas.render(
                    frame,
                    ChartSettings(
                        title="",
                        x_label="",
                        y_label="",
                        show_stat_table=False,
                        auto_x_range=False,
                        x_min=0.0,
                        x_max=10.0,
                        auto_y_range=False,
                        y_min=0.0,
                        y_max=10.0,
                    ),
                    xy_settings=XYSettings(
                        default_x_column_id="x",
                        show_points=show_points,
                        show_line=show_line,
                        series=[
                            XYSeriesSpec(
                                id="series-y",
                                name="Y",
                                y_column_id="y",
                            )
                        ],
                    ),
                    column_ids=["x", "y"],
                )

                axis = canvas.figure.axes[0]
                display_x, display_y = axis.transData.transform(event_data)
                axes_bbox = axis.get_window_extent(canvas.canvas.get_renderer())
                self.assertFalse(axes_bbox.contains(display_x, display_y))
                self.assertIsNone(
                    canvas._interaction_target_at_event(
                        SimpleNamespace(
                            x=float(display_x),
                            y=float(display_y),
                            button=1,
                        )
                    )
                )

    def test_xy_overlapping_series_hit_the_topmost_line_or_marker(self):
        from easygraph.plotting.canvas import PlotCanvas

        cases = (
            (
                "crossing-lines",
                pd.DataFrame(
                    {
                        "A X": [0.0, 10.0],
                        "A": [5.0, 5.0],
                        "B X": [5.0, 5.0],
                        "B": [0.0, 10.0],
                    }
                ),
                False,
                True,
            ),
            (
                "overlapping-markers",
                pd.DataFrame(
                    {
                        "A X": [5.0],
                        "A": [5.0],
                        "B X": [5.0],
                        "B": [5.0],
                    }
                ),
                True,
                False,
            ),
        )
        for name, frame, show_points, show_line in cases:
            with self.subTest(mode=name):
                canvas = PlotCanvas()
                self.addCleanup(canvas.close)
                canvas.render(
                    frame,
                    ChartSettings(
                        title="",
                        x_label="",
                        y_label="",
                        show_stat_table=False,
                        legend_position=LEGEND_POSITION_INSIDE,
                        auto_x_range=False,
                        x_min=0.0,
                        x_max=10.0,
                        auto_y_range=False,
                        y_min=0.0,
                        y_max=10.0,
                    ),
                    xy_settings=XYSettings(
                        default_x_column_id="a-x",
                        show_points=show_points,
                        show_line=show_line,
                        series=[
                            XYSeriesSpec(
                                id="a",
                                name="A",
                                y_column_id="a",
                            ),
                            XYSeriesSpec(
                                id="b",
                                name="B",
                                x_column_id="b-x",
                                y_column_id="b",
                            ),
                        ],
                    ),
                    column_ids=["a-x", "a", "b-x", "b"],
                )

                display_x, display_y = canvas.figure.axes[0].transData.transform(
                    (5.0, 5.0)
                )
                target = canvas._interaction_target_at_event(
                    SimpleNamespace(
                        x=float(display_x),
                        y=float(display_y),
                        button=1,
                    )
                )

                self.assertIsNotNone(target)
                self.assertEqual(target["kind"], "points")
                self.assertEqual(target["series_id"], "b")

                canvas._handle_plot_click(
                    SimpleNamespace(
                        x=float(display_x),
                        y=float(display_y),
                        button=1,
                    )
                )

                feedback = canvas._selected_feedback_patch
                self.assertEqual(
                    [
                        artist._easygraph_feedback_source._easygraph_series_id
                        for artist in feedback
                    ],
                    ["b"],
                )
                self.assertEqual(canvas._xy_selection_scope, "subset")
                self.assertEqual(canvas._selected_series_ids, {"b"})
                self.assertEqual(canvas._selected_series_id, "b")
                axis = canvas.figure.axes[0]
                legend = axis.get_legend()
                for artist in feedback:
                    self.assertIn(artist, axis.get_children())
                    self.assertNotIn(artist, canvas.figure.artists)
                    self.assertLess(artist.get_zorder(), legend.get_zorder())

    def test_xy_plot_outline_does_not_repaint_an_inside_legend_during_blit(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        canvas.render(
            pd.DataFrame({"X": [0.0, 10.0], "Y": [5.0, 5.0]}),
            ChartSettings(
                title="",
                x_label="",
                y_label="",
                show_grid=False,
                show_stat_table=False,
                legend_position=LEGEND_POSITION_INSIDE,
                legend_inside_x=0.35,
                legend_inside_y=0.45,
                auto_x_range=False,
                x_min=0.0,
                x_max=10.0,
                auto_y_range=False,
                y_min=0.0,
                y_max=10.0,
            ),
            xy_settings=XYSettings(
                default_x_column_id="x",
                show_points=False,
                show_line=True,
                line_width=2.0,
                series=[XYSeriesSpec(id="series-y", name="Y", y_column_id="y")],
            ),
            column_ids=["x", "y"],
        )
        self.qapp.processEvents()
        self.assertIsNotNone(canvas._blit_background)
        axis = canvas.figure.axes[0]
        renderer = canvas.canvas.get_renderer()
        legend_bbox = canvas._legend_outer_bbox(axis.get_legend(), renderer)
        legend_center_x = (legend_bbox.x0 + legend_bbox.x1) / 2.0
        _line_x, line_y = axis.transData.transform((5.0, 5.0))
        self.assertTrue(legend_bbox.contains(legend_center_x, line_y))
        before = np.asarray(canvas.canvas.buffer_rgba()).copy()

        click_x, click_y = axis.transData.transform((1.0, 5.0))
        canvas._handle_plot_click(
            SimpleNamespace(x=float(click_x), y=float(click_y), button=1)
        )
        self.qapp.processEvents()
        after = np.asarray(canvas.canvas.buffer_rgba()).copy()

        height, width = before.shape[:2]
        left = max(0, int(math.floor(legend_bbox.x0)))
        right = min(width, int(math.ceil(legend_bbox.x1)))
        top = max(0, height - int(math.ceil(legend_bbox.y1)))
        bottom = min(height, height - int(math.floor(legend_bbox.y0)))
        np.testing.assert_array_equal(
            before[top:bottom, left:right],
            after[top:bottom, left:right],
        )
        self.assertTrue(np.any(before != after))

    def test_xy_legend_handles_select_series_while_text_and_padding_select_legend(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "X": [1, 2, 3],
                "A": [1, 2, 1],
                "B": [10, 13, 11],
            }
        )
        xy = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=False,
            series=[
                XYSeriesSpec(id="a", name="A", y_column_id="a"),
                XYSeriesSpec(id="b", name="B", y_column_id="b"),
            ],
        )
        canvas.render(
            frame,
            ChartSettings(show_stat_table=False),
            xy_settings=xy,
            column_ids=["x", "a", "b"],
        )

        legend_series_target = next(
            target
            for target in canvas._interaction_targets
            if target["kind"] == "points"
            and target.get("source") == "legend"
            and target["series_id"] == "b"
        )
        bbox = legend_series_target["bbox"]
        event = SimpleNamespace(
            x=(bbox.x0 + bbox.x1) / 2,
            y=(bbox.y0 + bbox.y1) / 2,
            button=1,
        )
        self.assertIs(canvas._interaction_target_at_event(event), legend_series_target)

        legend_text = next(
            text
            for text in canvas.figure.axes[0].get_legend().get_texts()
            if text.get_text() == "B"
        )
        text_bbox = legend_text.get_window_extent(canvas.canvas.get_renderer())
        text_event = SimpleNamespace(
            x=(text_bbox.x0 + text_bbox.x1) / 2,
            y=(text_bbox.y0 + text_bbox.y1) / 2,
            button=1,
        )
        text_target = canvas._interaction_target_at_event(text_event)
        self.assertEqual(text_target["kind"], "legend")
        canvas._handle_plot_motion(text_event)
        self.assertEqual(canvas._hover_object_kind, "legend")
        self.assertIsNone(canvas._hover_series_id)

        canvas._handle_plot_motion(event)

        self.assertEqual(canvas._hover_object_kind, "points")
        self.assertEqual(canvas._hover_series_id, "b")
        self.assertEqual(len(canvas._hover_feedback_patch), 1)
        self.assertIs(
            canvas._hover_feedback_patch[0]._easygraph_feedback_source,
            legend_series_target["artist"],
        )
        self.assertIn(canvas._hover_feedback_patch[0], canvas.figure.artists)
        self.assertNotIn(
            canvas._hover_feedback_patch[0],
            canvas.figure.axes[0].get_children(),
        )

        canvas._handle_plot_click(event)

        self.assertEqual(canvas._selected_object_kind, "points")
        self.assertEqual(canvas._xy_selection_scope, "subset")
        self.assertEqual(canvas._selected_series_ids, {"b"})
        self.assertEqual(canvas._selected_series_id, "b")
        self.assertEqual(len(canvas._selected_feedback_patch), 1)
        selected_plot_target = next(
            target
            for target in canvas._interaction_targets
            if target["kind"] == "points"
            and target.get("source") == "plot"
            and target["series_id"] == "b"
        )
        self.assertIs(
            canvas._selected_feedback_patch[0]._easygraph_feedback_source,
            selected_plot_target["artist"],
        )

        canvas._handle_plot_click(
            SimpleNamespace(
                x=event.x,
                y=event.y,
                button=1,
                dblclick=True,
            )
        )

        self.assertEqual(canvas._selected_series_id, "b")
        self.assertEqual(len(canvas._selected_feedback_patch), 1)
        selected_source = canvas._selected_feedback_patch[0]._easygraph_feedback_source
        self.assertEqual(selected_source._easygraph_series_id, "b")

        legend_target = next(
            target
            for target in canvas._interaction_targets
            if target["kind"] == "legend"
        )
        legend_blank_event = None
        for x_fraction in (0.02, 0.5, 0.98):
            for y_fraction in (0.02, 0.5, 0.98):
                candidate = SimpleNamespace(
                    x=legend_target["bbox"].x0
                    + legend_target["bbox"].width * x_fraction,
                    y=legend_target["bbox"].y0
                    + legend_target["bbox"].height * y_fraction,
                    button=1,
                )
                hit = canvas._interaction_target_at_event(candidate)
                if hit is legend_target:
                    legend_blank_event = candidate
                    break
            if legend_blank_event is not None:
                break
        self.assertIsNotNone(legend_blank_event)

        canvas._handle_plot_click(legend_blank_event)

        self.assertEqual(canvas._selected_object_kind, "legend")
        self.assertIsNone(canvas._selected_series_id)

    def test_xy_selection_restores_the_same_series_across_artist_type_changes(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "X": [1, 2, 3],
                "A": [1, 2, 1],
                "B": [10, 13, 11],
            }
        )
        chart = ChartSettings(
            title="",
            x_label="",
            y_label="",
            show_stat_table=False,
        )
        scatter = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=False,
            series=[
                XYSeriesSpec(id="a", name="A", y_column_id="a"),
                XYSeriesSpec(id="b", name="B", y_column_id="b"),
            ],
        )
        canvas.render(
            frame,
            chart,
            xy_settings=scatter,
            column_ids=["x", "a", "b"],
        )
        ax = canvas.figure.axes[0]
        display_x, display_y = ax.transData.transform((2.0, 13.0))
        canvas._handle_plot_click(
            SimpleNamespace(
                x=float(display_x),
                y=float(display_y),
                button=1,
                dblclick=True,
            )
        )
        self.assertEqual(canvas._selected_series_id, "b")

        lines = XYSettings(
            default_x_column_id="x",
            show_points=False,
            show_line=True,
            series=[
                XYSeriesSpec(id="a", name="A", y_column_id="a"),
                XYSeriesSpec(id="b", name="B", y_column_id="b"),
            ],
        )
        canvas.render(
            frame,
            chart,
            xy_settings=lines,
            column_ids=["x", "a", "b"],
        )

        self.assertEqual(canvas._selected_object_kind, "points")
        self.assertEqual(canvas._selected_series_id, "b")
        selected_target = next(
            target
            for target in canvas._interaction_targets
            if target["kind"] == "points"
            and target.get("source") == "plot"
            and target["series_id"] == "b"
        )
        self.assertEqual(len(canvas._selected_feedback_patch), 1)
        self.assertIs(
            canvas._selected_feedback_patch[0]._easygraph_feedback_source,
            selected_target["artist"],
        )

    def test_xy_all_series_selection_restores_all_visible_artists_after_render(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "X": [1.0, 2.0, 3.0],
                "A": [1.0, 2.0, 1.0],
                "B": [3.0, 2.0, 3.0],
            }
        )
        chart = ChartSettings(show_stat_table=False)
        xy = XYSettings(
            default_x_column_id="x",
            show_points=False,
            show_line=True,
            series=[
                XYSeriesSpec(id="a", name="A", y_column_id="a"),
                XYSeriesSpec(id="b", name="B", y_column_id="b"),
            ],
        )
        canvas.render(
            frame,
            chart,
            xy_settings=xy,
            column_ids=["x", "a", "b"],
        )
        canvas.set_xy_series_selection("all", set())

        self.assertEqual(canvas._selected_object_kind, "points")
        self.assertEqual(canvas._xy_selection_scope, "all")
        self.assertEqual(canvas._selected_series_ids, set())
        self.assertIsNone(canvas._selected_series_id)
        self.assertEqual(len(canvas._selected_feedback_patch), 2)

        canvas.render(
            frame,
            chart,
            xy_settings=xy,
            column_ids=["x", "a", "b"],
        )

        self.assertEqual(canvas._selected_object_kind, "points")
        self.assertEqual(canvas._xy_selection_scope, "all")
        self.assertEqual(canvas._selected_series_ids, set())
        self.assertIsNone(canvas._selected_series_id)
        self.assertEqual(len(canvas._selected_feedback_patch), 2)
        self.assertEqual(
            {
                feedback._easygraph_feedback_source._easygraph_series_id
                for feedback in canvas._selected_feedback_patch
            },
            {"a", "b"},
        )

    def test_xy_point_opacity_does_not_fade_connecting_lines(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "X": [1, 2, 3],
                "Both": [1, 3, 2],
                "Scatter": [4, 6, 5],
                "Line": [7, 9, 8],
            }
        )
        xy = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=True,
            point_alpha=0.25,
            series=[
                XYSeriesSpec(id="both", name="Both", y_column_id="both"),
                XYSeriesSpec(
                    id="scatter",
                    name="Scatter",
                    y_column_id="scatter",
                    show_line=False,
                ),
                XYSeriesSpec(
                    id="line",
                    name="Line",
                    y_column_id="line",
                    show_points=False,
                ),
            ],
        )

        canvas.render(
            frame,
            ChartSettings(show_stat_table=False),
            xy_settings=xy,
            column_ids=["x", "both", "scatter", "line"],
        )

        ax = canvas.figure.axes[0]
        both = next(artist for artist in ax.lines if artist.get_label() == "Both")
        line = next(artist for artist in ax.lines if artist.get_label() == "Line")
        scatter = next(
            artist
            for artist in ax.collections
            if artist.get_label() == "Scatter"
        )
        self.assertIsNone(both.get_alpha())
        self.assertAlmostEqual(both.get_markerfacecolor()[3], 0.25)
        self.assertAlmostEqual(both.get_markeredgecolor()[3], 0.25)
        self.assertIsNone(line.get_alpha())
        self.assertAlmostEqual(scatter.get_alpha(), 0.25)
        self.assertEqual(
            [text.get_text() for text in ax.get_legend().get_texts()],
            ["Both", "Scatter", "Line"],
        )

    def test_canvas_draws_visible_series_with_independent_display_and_original_order(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame(
            {
                "X": [2, 1, 3],
                "A": [20, 10, 30],
                "B": [200, 100, 300],
                "Hidden": [9000, 8000, 7000],
            }
        )
        settings = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=True,
            series=[
                XYSeriesSpec(id="both", name="Both", y_column_id="a", color="#123456"),
                XYSeriesSpec(
                    id="points",
                    name="Points",
                    y_column_id="b",
                    show_line=False,
                ),
                XYSeriesSpec(
                    id="hidden",
                    name="Hidden",
                    y_column_id="hidden",
                    visible=False,
                ),
            ],
        )
        chart = ChartSettings(
            title="XY plot",
            x_label="Time",
            y_label="Response",
            show_stat_table=False,
        )

        canvas.render(
            frame,
            chart,
            xy_settings=settings,
            column_ids=["x", "a", "b", "hidden"],
        )

        ax = canvas.figure.axes[0]
        both = next(line for line in ax.lines if line.get_label() == "Both")
        self.assertEqual(both.get_xdata().tolist(), [2.0, 1.0, 3.0])
        self.assertNotEqual(both.get_marker(), "None")
        self.assertNotEqual(both.get_linestyle(), "None")
        point_collections = [
            artist
            for artist in ax.collections
            if isinstance(artist, PathCollection) and artist.get_label() == "Points"
        ]
        self.assertEqual(len(point_collections), 1)
        self.assertFalse(any(
            isinstance(artist, (Line2D, PathCollection)) and artist.get_label() == "Hidden"
            for artist in [*ax.lines, *ax.collections]
        ))
        self.assertLess(ax.get_ylim()[1], 1000)
        self.assertEqual(ax.get_title(), "XY plot")
        self.assertEqual(ax.get_xlabel(), "Time")
        self.assertEqual(ax.get_ylabel(), "Response")
        self.assertEqual([text.get_text() for text in ax.get_legend().get_texts()], ["Both", "Points"])
        artists = [
            artist
            for artist in [*ax.lines, *ax.collections]
            if artist.get_label() in {"Both", "Points"}
        ]
        self.assertEqual(
            {artist.get_label(): artist._easygraph_series_id for artist in artists},
            {"Both": "both", "Points": "points"},
        )

    def test_canvas_orders_xy_legend_by_selected_name_order(self):
        from easygraph.plotting.canvas import PlotCanvas

        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        frame = pd.DataFrame({"X": [1, 2], "B": [4, 5], "A": [2, 3]})
        xy = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(id="b", name="Beta", y_column_id="b"),
                XYSeriesSpec(id="a", name="Alpha", y_column_id="a"),
            ],
        )
        chart = ChartSettings(group_order="Name A-Z", show_stat_table=False)

        canvas.render(frame, chart, xy_settings=xy, column_ids=["x", "b", "a"])

        legend = canvas.figure.axes[0].get_legend()
        self.assertEqual(
            [text.get_text() for text in legend.get_texts()],
            ["Alpha", "Beta"],
        )


if __name__ == "__main__":
    __import__("unittest").main()
