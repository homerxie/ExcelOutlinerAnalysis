from __future__ import annotations

import plistlib
from pathlib import Path
from types import SimpleNamespace
import tempfile
from unittest import mock

from PIL import Image
from PySide6.QtGui import QFileOpenEvent

from tests.easygraph_case import EasyGraphTestCase, ROOT
from easygraph import file_association
from scripts.configure_macos_file_association import configure_info_plist


class FileAssociationTests(EasyGraphTestCase):
    def test_project_icon_pack_contains_windows_and_macos_resolutions(self):
        icon_root = ROOT / "icon" / "EasyGraph_Project_Icon_Pack"
        with Image.open(icon_root / "EasyGraph_Project_Icon_Windows.ico") as icon:
            self.assertEqual(icon.format, "ICO")
            self.assertEqual(
                icon.info["sizes"],
                {
                    (16, 16),
                    (20, 20),
                    (24, 24),
                    (32, 32),
                    (40, 40),
                    (48, 48),
                    (64, 64),
                    (96, 96),
                    (128, 128),
                    (256, 256),
                },
            )
        with Image.open(icon_root / "EasyGraph_Project_Icon_macOS.icns") as icon:
            self.assertEqual(icon.format, "ICNS")
            self.assertEqual(icon.size, (1024, 1024))
            self.assertIn((512, 512, 2), icon.info["sizes"])
            self.assertIn((16, 16, 2), icon.info["sizes"])

    def test_command_line_path_selects_only_easygraph_projects(self):
        self.assertEqual(
            file_association.project_path_from_arguments(
                ["--flag", "notes.txt", "project.EG"]
            ),
            Path("project.EG"),
        )
        self.assertIsNone(
            file_association.project_path_from_arguments(["--flag", "notes.txt"])
        )

    def test_file_open_router_preserves_early_macos_events(self):
        router = file_association.ProjectFileOpenRouter()
        opened: list[Path] = []

        self.assertTrue(router.request("first.eg"))
        self.assertFalse(router.request("ignored.xlsx"))
        self.assertTrue(router.request("first.eg"))
        router.set_handler(opened.append)
        router.request("second.eg")

        self.assertEqual(opened, [Path("first.eg"), Path("second.eg")])

    def test_macos_file_open_event_is_routed_to_project_handler(self):
        application = SimpleNamespace(
            request_project_file=mock.Mock(return_value=True)
        )
        event = QFileOpenEvent("/tmp/from-finder.eg")

        handled = file_association.EasyGraphApplication.event(application, event)

        self.assertTrue(handled)
        self.assertTrue(event.isAccepted())
        application.request_project_file.assert_called_once_with(
            "/tmp/from-finder.eg"
        )

    def test_windows_registration_uses_current_user_and_quoted_open_command(self):
        registry = SimpleNamespace(
            HKEY_CURRENT_USER=object(),
            REG_NONE=0,
            REG_SZ=1,
            CreateKey=mock.Mock(side_effect=lambda _root, path: path),
            SetValueEx=mock.Mock(),
            CloseKey=mock.Mock(),
        )
        executable = Path(r"C:\Program Files\EasyGraph\EasyGraph.exe")

        registered = file_association.register_windows_project_file_association(
            executable,
            platform_name="win32",
            frozen=True,
            registry_module=registry,
            notify_shell=False,
        )

        self.assertTrue(registered)
        values = file_association.windows_file_association_registry_values(executable)
        self.assertIn(
            (
                r"Software\Classes\EasyGraph.Project\shell\open\command",
                "",
                r'"C:\Program Files\EasyGraph\EasyGraph.exe" "%1"',
                "string",
            ),
            values,
        )
        self.assertIn(
            (
                r"Software\Classes\EasyGraph.Project\DefaultIcon",
                "",
                r'"C:\Program Files\EasyGraph\EasyGraph_Project_Icon_Windows.ico",0',
                "string",
            ),
            values,
        )
        self.assertIn(
            (
                r"Software\Classes\.eg\DefaultIcon",
                "",
                r'"C:\Program Files\EasyGraph\EasyGraph_Project_Icon_Windows.ico",0',
                "string",
            ),
            values,
        )
        self.assertIn(
            (
                r"Software\Classes\Applications\EasyGraph.exe\DefaultIcon",
                "",
                r'"C:\Program Files\EasyGraph\EasyGraph_Project_Icon_Windows.ico",0',
                "string",
            ),
            values,
        )
        self.assertIn(
            (
                r"Software\EasyGraph\Capabilities\FileAssociations",
                ".eg",
                "EasyGraph.Project",
                "string",
            ),
            values,
        )
        self.assertEqual(registry.CreateKey.call_count, len(values))
        self.assertEqual(registry.SetValueEx.call_count, len(values))
        self.assertEqual(registry.CloseKey.call_count, len(values))

    def test_windows_project_icon_prefers_bundled_internal_resource(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle_root = Path(tmp) / "_internal"
            bundled_icon = bundle_root.joinpath(
                *file_association.WINDOWS_PROJECT_ICON_BUNDLE_PARTS
            )
            bundled_icon.parent.mkdir(parents=True)
            bundled_icon.touch()

            selected = file_association.windows_project_icon_path(
                Path(tmp) / "EasyGraph.exe",
                bundle_root=bundle_root,
            )
            values = file_association.windows_file_association_registry_values(
                Path(tmp) / "EasyGraph.exe",
                selected,
            )

        self.assertEqual(selected, bundled_icon)
        self.assertIn(
            (
                r"Software\Classes\.eg\DefaultIcon",
                "",
                f'"{bundled_icon}",0',
                "string",
            ),
            values,
        )

    def test_windows_registration_refreshes_shell_icon_cache_synchronously(self):
        registry = SimpleNamespace(
            HKEY_CURRENT_USER=object(),
            REG_NONE=0,
            REG_SZ=1,
            CreateKey=mock.Mock(side_effect=lambda _root, path: path),
            SetValueEx=mock.Mock(),
            CloseKey=mock.Mock(),
        )
        with mock.patch.object(
            file_association.ctypes, "windll", create=True
        ) as windll:
            registered = file_association.register_windows_project_file_association(
                Path(r"C:\EasyGraph\EasyGraph-renamed.exe"),
                platform_name="win32",
                frozen=True,
                registry_module=registry,
            )

        self.assertTrue(registered)
        created_paths = {
            call.args[1] for call in registry.CreateKey.call_args_list
        }
        self.assertIn(
            r"Software\Classes\Applications\EasyGraph-renamed.exe\DefaultIcon",
            created_paths,
        )
        windll.shell32.SHChangeNotify.assert_called_once_with(
            file_association.WINDOWS_SHELL_ASSOCIATION_CHANGED,
            file_association.WINDOWS_SHELL_NOTIFY_FLUSH,
            None,
            None,
        )

    def test_windows_registration_is_disabled_for_source_and_other_platforms(self):
        self.assertFalse(
            file_association.register_windows_project_file_association(
                platform_name="darwin",
                frozen=True,
            )
        )
        self.assertFalse(
            file_association.register_windows_project_file_association(
                platform_name="win32",
                frozen=False,
            )
        )

    def test_macos_registration_updates_current_app_bundle(self):
        core_foundation = SimpleNamespace(
            CFURLCreateFromFileSystemRepresentation=mock.Mock(return_value=123),
            CFRelease=mock.Mock(),
        )
        launch_services = SimpleNamespace(
            LSRegisterURL=mock.Mock(return_value=0),
        )
        with tempfile.TemporaryDirectory() as tmp:
            bundle = Path(tmp) / "EasyGraph.app"
            executable = bundle / "Contents" / "MacOS" / "EasyGraph"
            executable.parent.mkdir(parents=True)

            self.assertEqual(
                file_association.macos_application_bundle_path(executable),
                bundle,
            )
            registered = file_association.register_macos_project_file_association(
                bundle,
                platform_name="darwin",
                frozen=True,
                core_foundation=core_foundation,
                launch_services=launch_services,
            )

        self.assertTrue(registered)
        launch_services.LSRegisterURL.assert_called_once_with(123, True)
        core_foundation.CFRelease.assert_called_once_with(123)

    def test_manual_refresh_reports_platform_and_packaging_status(self):
        self.assertEqual(
            file_association.refresh_project_file_association(
                platform_name="linux",
                frozen=True,
            ),
            file_association.FileAssociationRefreshStatus.UNSUPPORTED,
        )
        self.assertEqual(
            file_association.refresh_project_file_association(
                platform_name="win32",
                frozen=False,
            ),
            file_association.FileAssociationRefreshStatus.PACKAGED_APP_REQUIRED,
        )
        with mock.patch.object(
            file_association,
            "register_windows_project_file_association",
            return_value=True,
        ) as register_windows:
            status = file_association.refresh_project_file_association(
                platform_name="win32",
                frozen=True,
            )

        self.assertEqual(
            status,
            file_association.FileAssociationRefreshStatus.REFRESHED,
        )
        register_windows.assert_called_once_with(
            platform_name="win32",
            frozen=True,
        )

    def test_macos_plist_declares_easygraph_document_type_idempotently(self):
        with tempfile.TemporaryDirectory() as tmp:
            info_path = Path(tmp) / "Info.plist"
            with info_path.open("wb") as stream:
                plistlib.dump(
                    {
                        "CFBundleIdentifier": "old.identifier",
                        "CFBundleDocumentTypes": [
                            {
                                "CFBundleTypeName": "Other",
                                "CFBundleTypeExtensions": ["other"],
                            }
                        ],
                    },
                    stream,
                )

            configure_info_plist(info_path)
            configured = configure_info_plist(info_path)

        self.assertEqual(
            configured["CFBundleIdentifier"],
            file_association.MACOS_BUNDLE_IDENTIFIER,
        )
        self.assertEqual(configured["CFBundleDisplayName"], "EasyGraph v2.0")
        self.assertEqual(configured["CFBundleShortVersionString"], "2.0")
        self.assertEqual(configured["CFBundleVersion"], "2.0")
        easygraph_documents = [
            item
            for item in configured["CFBundleDocumentTypes"]
            if file_association.MACOS_PROJECT_UTI
            in item.get("LSItemContentTypes", [])
        ]
        easygraph_types = [
            item
            for item in configured["UTExportedTypeDeclarations"]
            if item.get("UTTypeIdentifier") == file_association.MACOS_PROJECT_UTI
        ]
        self.assertEqual(len(easygraph_documents), 1)
        self.assertEqual(len(easygraph_types), 1)
        self.assertEqual(easygraph_documents[0]["CFBundleTypeExtensions"], ["eg"])
        self.assertEqual(
            easygraph_documents[0]["CFBundleTypeIconFile"],
            "EasyGraph_Project_Icon_macOS.icns",
        )
        self.assertEqual(
            easygraph_types[0]["UTTypeTagSpecification"][
                "public.filename-extension"
            ],
            ["eg"],
        )

    def test_macos_build_configures_bundle_file_association(self):
        script = (ROOT / "scripts" / "build_and_smoke_macos.sh").read_text(
            encoding="utf-8"
        )

        self.assertIn("--osx-bundle-identifier", script)
        self.assertIn("com.easygraph.desktop", script)
        self.assertIn("configure_macos_file_association.py", script)
        self.assertIn("EasyGraph.app/Contents/Info.plist", script)
        self.assertIn(
            'cp "$PROJECT_ICON" "$APP_BUNDLE/Contents/Resources/EasyGraph_Project_Icon_macOS.icns"',
            script,
        )
        self.assertIn("codesign --force --deep --sign", script)
        self.assertIn("codesign --verify --deep --strict", script)

    def test_windows_build_bundles_project_icon_under_internal_directory(self):
        script = (ROOT / "scripts" / "build_and_smoke_windows.ps1").read_text(
            encoding="utf-8"
        )

        self.assertIn(
            r"icon\EasyGraph_Project_Icon_Pack\EasyGraph_Project_Icon_Windows.ico",
            script,
        )
        self.assertIn(
            r"EasyGraph_Project_Icon_Windows.ico;icon\windows\project",
            script,
        )
        self.assertIn(
            r"dist\EasyGraph\_internal\icon\windows\project\EasyGraph_Project_Icon_Windows.ico",
            script,
        )
        self.assertIn("Test-Path $BundledProjectIcon", script)
        self.assertIn('--version-file "scripts\\windows_version_info.py"', script)
