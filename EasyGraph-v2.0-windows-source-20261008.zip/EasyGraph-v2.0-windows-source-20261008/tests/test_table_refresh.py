from PySide6.QtCore import Qt

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.table_refresh import refresh_table_structure


class TableRefreshTests(EasyGraphQtTestCase):
    def test_refresh_table_structure_updates_headers_height_styles_and_row_headers(self):
        table = DataTable(3, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells(
            [["Control\nDay 1", ""], ["10", ""], ["1", ""]],
            column_count=2,
        )
        overlay_series = [{"name": "Target"}]

        refresh_table_structure(
            table,
            sample_start_row=2,
            overlay_series=overlay_series,
            overlay_row_count=1,
            blend_colors=lambda base, highlight, ratio: highlight,
        )

        model = table.table_model
        self.assertEqual(model.headerData(0, Qt.Horizontal), "1")
        self.assertEqual(model.headerData(1, Qt.Horizontal), "2")
        self.assertEqual(model.headerData(0, Qt.Vertical), "")
        self.assertEqual(model.headerData(1, Qt.Vertical), "Target")
        self.assertEqual(model.headerData(2, Qt.Vertical), "1")
        self.assertEqual(table.verticalHeader().minimumWidth(), 86)
        self.assertEqual(table.rowHeight(0), table.fontMetrics().lineSpacing() * 2 + 14)
        self.assertTrue(model.data(model.index(0, 0), Qt.FontRole).bold())
        self.assertTrue(model.data(model.index(1, 0), Qt.FontRole).bold())
        self.assertEqual(model.data(model.index(1, 0), Qt.TextAlignmentRole), Qt.AlignLeft | Qt.AlignVCenter)
        self.assertFalse(model.data(model.index(2, 0), Qt.FontRole).bold())

    def test_refresh_table_structure_sets_custom_headers_and_tooltips(self):
        table = DataTable(2, 2)
        self.addCleanup(table.deleteLater)

        refresh_table_structure(
            table,
            sample_start_row=1,
            overlay_series=[],
            overlay_row_count=0,
            blend_colors=lambda base, highlight, ratio: highlight,
            column_labels=["X", "1Y"],
            column_tooltips=["Matches: 1Y", ""],
        )

        model = table.table_model
        self.assertEqual(model.headerData(0, Qt.Horizontal), "X")
        self.assertEqual(
            model.headerData(0, Qt.Horizontal, Qt.ToolTipRole),
            "Matches: 1Y",
        )
        self.assertIsNone(model.headerData(1, Qt.Horizontal, Qt.ToolTipRole))
