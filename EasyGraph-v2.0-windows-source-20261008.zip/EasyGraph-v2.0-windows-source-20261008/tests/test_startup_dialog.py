from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import mock

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QDialog, QWidget

from tests.easygraph_case import EasyGraphQtTestCase, patch_qsettings

from easygraph.app_preferences import save_recent_project_paths, stored_recent_project_paths
from easygraph.ui.main_window import MainWindow
from easygraph.ui.startup_dialog import StartupDialog, choose_startup
from easygraph.workbook import SHEET_MODE_GROUPS, SHEET_MODE_XY


class StartupDialogTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        preferences_patch, _ = patch_qsettings()
        preferences_patch.start()
        self.addCleanup(preferences_patch.stop)

    def make_dialog(self):
        dialog = StartupDialog()
        self.addCleanup(dialog.deleteLater)
        return dialog

    def make_recent_projects(self):
        directory = TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        root = Path(directory.name)
        paths = [root / "first" / "Study.eg", root / "second" / "Study.eg"]
        for path in paths:
            path.parent.mkdir()
            path.touch()
        save_recent_project_paths(paths)
        return paths

    def test_default_demo_keeps_single_level_headers(self):
        dialog = self.make_dialog()
        self.assertEqual(dialog.ui.demoPresetCombo.count(), 2)
        self.assertEqual(dialog.ui.demoPresetCombo.currentText(), "Single-level headers")
        dialog.ui.demoButton.click()
        self.assertEqual(dialog.choice.mode, SHEET_MODE_GROUPS)
        self.assertTrue(dialog.choice.demo)
        self.assertFalse(dialog.choice.grouped_demo)
        self.assertIsNone(dialog.choice.project_path)

    def test_two_level_group_demo_is_selectable(self):
        dialog = self.make_dialog()
        dialog.ui.demoPresetCombo.setCurrentIndex(1)
        dialog.ui.demoButton.click()
        self.assertTrue(dialog.choice.demo)
        self.assertTrue(dialog.choice.grouped_demo)

    def test_blank_group_ignores_demo_preset(self):
        dialog = self.make_dialog()
        dialog.ui.demoPresetCombo.setCurrentIndex(1)
        dialog.ui.blankButton.click()
        self.assertFalse(dialog.choice.demo)
        self.assertFalse(dialog.choice.grouped_demo)

    def test_xy_has_its_own_demo_and_remembers_group_preset(self):
        dialog = self.make_dialog()
        dialog.ui.demoPresetCombo.setCurrentIndex(1)
        dialog.ui.xyRadioButton.setChecked(True)
        self.assertFalse(dialog.ui.demoPresetCombo.isEnabled())
        self.assertEqual(dialog.ui.demoPresetCombo.count(), 1)
        self.assertEqual(dialog.ui.demoPresetCombo.currentText(), "XY demo")
        dialog.ui.groupRadioButton.setChecked(True)
        self.assertTrue(dialog.ui.demoPresetCombo.isEnabled())
        self.assertEqual(dialog.ui.demoPresetCombo.currentIndex(), 1)
        dialog.ui.xyRadioButton.setChecked(True)
        dialog.ui.demoButton.click()
        self.assertEqual(dialog.choice.mode, SHEET_MODE_XY)
        self.assertTrue(dialog.choice.demo)
        self.assertFalse(dialog.choice.grouped_demo)

    def test_no_recent_projects_shows_empty_state(self):
        dialog = self.make_dialog()
        self.assertTrue(dialog.ui.recentProjectsTable.isHidden())
        self.assertFalse(dialog.ui.recentEmptyLabel.isHidden())
        self.assertFalse(dialog.ui.openRecentButton.isEnabled())
        dialog.ui.openRecentButton.click()
        self.assertIsNone(dialog.choice)

    def test_recent_projects_preserve_order_and_disambiguate_names(self):
        paths = self.make_recent_projects()
        dialog = self.make_dialog()
        table = dialog.ui.recentProjectsTable
        self.assertEqual(table.rowCount(), 2)
        self.assertFalse(table.isHidden())
        self.assertTrue(dialog.ui.recentEmptyLabel.isHidden())
        self.assertFalse(dialog.ui.openRecentButton.isEnabled())
        for row, path in enumerate(paths):
            self.assertEqual(table.item(row, 0).text(), path.name)
            self.assertEqual(table.item(row, 1).text(), str(path.parent))
            self.assertEqual(table.item(row, 0).toolTip(), str(path))
            self.assertEqual(table.item(row, 1).toolTip(), str(path))
        table.selectRow(1)
        self.assertTrue(dialog.ui.openRecentButton.isEnabled())
        dialog.ui.openRecentButton.click()
        self.assertEqual(dialog.result(), QDialog.DialogCode.Accepted)
        self.assertEqual(dialog.choice.project_path, paths[1])
        self.assertFalse(dialog.choice.demo)
        self.assertEqual(stored_recent_project_paths(), paths)

    def test_return_in_recent_table_opens_selected_project_not_demo(self):
        paths = self.make_recent_projects()
        dialog = self.make_dialog()
        dialog.ui.recentProjectsTable.selectRow(0)
        QTest.keyClick(dialog.ui.recentProjectsTable, Qt.Key.Key_Return)
        self.assertEqual(dialog.choice.project_path, paths[0])
        self.assertFalse(dialog.choice.demo)

    def test_return_without_recent_selection_does_not_start_demo(self):
        self.make_recent_projects()
        dialog = self.make_dialog()
        QTest.keyClick(dialog.ui.recentProjectsTable, Qt.Key.Key_Return)
        self.assertIsNone(dialog.choice)
        self.assertEqual(dialog.result(), QDialog.DialogCode.Rejected)

    def test_return_on_open_selected_button_does_not_start_demo(self):
        paths = self.make_recent_projects()
        dialog = self.make_dialog()
        dialog.ui.recentProjectsTable.selectRow(1)
        dialog.show()
        dialog.ui.openRecentButton.setFocus()
        self.qapp.processEvents()
        QTest.keyClick(dialog.ui.openRecentButton, Qt.Key.Key_Return)
        self.assertEqual(dialog.choice.project_path, paths[1])
        self.assertFalse(dialog.choice.demo)

    def test_return_on_blank_button_creates_blank_project(self):
        dialog = self.make_dialog()
        dialog.show()
        dialog.ui.blankButton.setFocus()
        self.qapp.processEvents()
        QTest.keyClick(dialog.ui.blankButton, Qt.Key.Key_Return)
        self.assertIsNotNone(dialog.choice)
        self.assertFalse(dialog.choice.demo)

    def test_double_click_recent_table_opens_project(self):
        paths = self.make_recent_projects()
        dialog = self.make_dialog()
        table = dialog.ui.recentProjectsTable
        dialog.show()
        self.qapp.processEvents()
        cell = table.visualItemRect(table.item(1, 0)).center()
        QTest.mouseClick(table.viewport(), Qt.MouseButton.LeftButton, pos=cell)
        QTest.mouseDClick(table.viewport(), Qt.MouseButton.LeftButton, pos=cell)
        self.assertIsNotNone(dialog.choice)
        self.assertEqual(dialog.choice.project_path, paths[1])

    def test_missing_recent_project_warns_and_removes_only_missing_entry(self):
        paths = self.make_recent_projects()
        paths[0].unlink()
        dialog = self.make_dialog()
        dialog.ui.recentProjectsTable.selectRow(0)
        with mock.patch("easygraph.ui.startup_dialog.QMessageBox.warning") as warning:
            dialog.ui.openRecentButton.click()
        self.assertIsNone(dialog.choice)
        self.assertEqual(dialog.result(), QDialog.DialogCode.Rejected)
        self.assertEqual(stored_recent_project_paths(), [paths[1]])
        self.assertEqual(dialog.ui.recentProjectsTable.rowCount(), 1)
        warning.assert_called_once()
        self.assertIn(str(paths[0]), warning.call_args.args[2])

    def test_cancel_leaves_recent_history_unchanged(self):
        paths = self.make_recent_projects()
        dialog = self.make_dialog()
        dialog.ui.recentProjectsTable.selectRow(1)
        dialog.ui.cancelButton.click()
        self.assertIsNone(dialog.choice)
        self.assertEqual(stored_recent_project_paths(), paths)

    def test_dialog_uses_group_literal_and_returns_selected_blank_xy_choice(self):
        dialog = StartupDialog()
        self.addCleanup(dialog.deleteLater)

        self.assertEqual(dialog.ui.groupRadioButton.text(), "Group")
        self.assertEqual(dialog.ui.xyRadioButton.text(), "XY")
        self.assertTrue(dialog.ui.groupRadioButton.isChecked())
        self.assertIn(
            "only determines the first Sheet",
            dialog.ui.projectNoteLabel.text(),
        )

        dialog.ui.xyRadioButton.setChecked(True)
        dialog.ui.blankButton.click()

        self.assertEqual(dialog.result(), QDialog.DialogCode.Accepted)
        self.assertEqual(dialog.choice.mode, SHEET_MODE_XY)
        self.assertFalse(dialog.choice.demo)

    def test_cancelled_startup_choice_returns_none(self):
        parent = QWidget()
        self.addCleanup(parent.deleteLater)

        with mock.patch.object(
            QDialog,
            "exec",
            return_value=QDialog.DialogCode.Rejected,
        ):
            self.assertIsNone(choose_startup(parent))

    def test_startup_project_supports_blank_and_demo_for_both_sheet_types(self):
        window = MainWindow(initial_render=False, defer_preview=True)

        with mock.patch.object(window, "render") as render:
            window.initialize_startup_project(SHEET_MODE_GROUPS, demo=False)
        self.assertEqual(window.workbook.active_sheet.mode, SHEET_MODE_GROUPS)
        self.assertTrue((window.table.dataframe() == "").all().all())
        render.assert_not_called()

        window.initialize_startup_project(SHEET_MODE_GROUPS, demo=True)
        self.assertEqual(window.workbook.active_sheet.mode, SHEET_MODE_GROUPS)
        self.assertTrue(window.table.dataframe().notna().any().any())

        window.initialize_startup_project(SHEET_MODE_XY, demo=False)
        blank_xy = window.workbook.active_sheet
        self.assertEqual(blank_xy.mode, SHEET_MODE_XY)
        self.assertEqual(len(blank_xy.xy_settings.shared_tables[0].series_ids), 2)
        self.assertEqual(len(blank_xy.xy_settings.paired_series_ids), 2)

        window.initialize_startup_project(SHEET_MODE_XY, demo=True)
        demo_xy = window.workbook.active_sheet
        self.assertEqual(demo_xy.mode, SHEET_MODE_XY)
        self.assertEqual(demo_xy.settings.title, "XY demo")
        self.assertEqual(
            [series.name for series in window._xy_user_series()],
            ["Control", "Treatment", "Sensor A", "Sensor B"],
        )
        self.assertFalse(window.has_unsaved_changes())


if __name__ == "__main__":
    __import__("unittest").main()
