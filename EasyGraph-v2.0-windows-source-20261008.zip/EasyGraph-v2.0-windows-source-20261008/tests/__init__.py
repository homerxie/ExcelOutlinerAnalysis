"""EasyGraph test package."""
