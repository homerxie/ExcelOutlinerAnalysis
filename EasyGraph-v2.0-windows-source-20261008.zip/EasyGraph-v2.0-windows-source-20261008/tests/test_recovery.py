from __future__ import annotations

import json
import pathlib
import tempfile
from threading import Event
import time
from unittest import mock

import numpy as np
import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.analysis_results import AnalysisSettings
from easygraph import recovery
from easygraph.recovery import (
    RecoveryManager,
    discard_recovery,
    find_recovery_candidates,
    read_recovery_workbook,
)
from easygraph.settings import ChartSettings
from easygraph.ui import main_window
from easygraph.workbook import SHEET_MODE_XY, SheetDocument, WorkbookDocument
from easygraph.xy_series import XYSeriesSpec, XYSettings


class RecoveryTests(EasyGraphQtTestCase):
    def workbook(self, *, rows: int = 2, columns: int = 2) -> WorkbookDocument:
        dataframe = pd.DataFrame(
            np.arange(rows * columns).reshape(rows, columns),
            columns=[f"Group {index + 1}" for index in range(columns)],
        )
        sheet = SheetDocument(
            id="sheet",
            name="Data",
            dataframe=dataframe,
            settings=ChartSettings(title="Initial"),
            analysis_settings=AnalysisSettings(visible_statistics=["Mean"]),
        )
        return WorkbookDocument([sheet], sheet.id)

    @staticmethod
    def journal_lines(manager: RecoveryManager) -> list[dict]:
        manifest = json.loads(
            (manager.session_dir / recovery.MANIFEST_FILE).read_text(
                encoding="utf-8"
            )
        )
        path = manager.session_dir / manifest["journal_file"]
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]

    def test_large_import_uses_one_background_checkpoint_and_no_cell_log(self):
        with tempfile.TemporaryDirectory() as tmp:
            manager = RecoveryManager(interval_seconds=2, root=pathlib.Path(tmp))
            workbook = self.workbook(rows=20_000, columns=20)

            started = time.perf_counter()
            manager.replace_document(workbook, None, dirty=True)
            enqueue_elapsed = time.perf_counter() - started

            self.assertLess(enqueue_elapsed, 0.5)
            self.assertTrue(manager.wait_for_checkpoint(30.0))
            self.assertEqual(self.journal_lines(manager), [])
            recovered, source = read_recovery_workbook(manager.session_dir)
            self.assertIsNone(source)
            self.assertEqual(recovered.active_sheet.dataframe.shape, (20_000, 20))
            manager.close(discard=True)

    def test_edits_flush_to_jsonl_while_checkpoint_is_still_running(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manager = RecoveryManager(interval_seconds=2, root=root)
            checkpoint_started = Event()
            allow_checkpoint = Event()
            real_write_project = recovery.write_project

            def delayed_write(*args, **kwargs):
                checkpoint_started.set()
                self.assertTrue(allow_checkpoint.wait(10.0))
                return real_write_project(*args, **kwargs)

            with mock.patch.object(recovery, "write_project", side_effect=delayed_write):
                manager.replace_document(self.workbook(), None, dirty=True)
                self.assertTrue(checkpoint_started.wait(5.0))
                manager.record_cell("sheet", 1, 0, "edited during checkpoint")
                self.assertTrue(manager.flush())
                lines = self.journal_lines(manager)
                self.assertEqual(len(lines), 1)
                self.assertEqual(lines[0]["type"], "set_cell")
                allow_checkpoint.set()
                self.assertTrue(manager.wait_for_checkpoint(10.0))

            recovered, _source = read_recovery_workbook(manager.session_dir)
            self.assertEqual(
                recovered.active_sheet.dataframe.iloc[0, 0],
                "edited during checkpoint",
            )
            manager.close(discard=True)

    def test_incremental_operations_replay_after_checkpoint(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            source = root / "source.eg"
            manager = RecoveryManager(interval_seconds=2, root=root)
            manager.replace_document(self.workbook(), source, dirty=False)
            self.assertTrue(manager.wait_for_checkpoint(10.0))

            manager.record_cell("sheet", 1, 0, "changed")
            manager.record_rows("sheet", 3, 1, inserted=True)
            manager.record_cell("sheet", 3, 1, "new row")
            manager.record_columns("sheet", 1, 1, inserted=True)
            manager.record_cell("sheet", 0, 1, "Inserted")
            manager.record_settings("sheet", ChartSettings(title="Recovered title"))
            manager.record_analysis(
                "sheet", AnalysisSettings(
                    visible_statistics=["Median", "SD"],
                    statistic_formats={"SD": {"decimals": 4, "scientific": True}},
                )
            )
            self.assertTrue(manager.flush())
            session_dir = manager.session_dir
            manager.close(discard=False)

            candidates = find_recovery_candidates(root)
            self.assertEqual([item.session_dir for item in candidates], [session_dir])
            recovered, recovered_source = read_recovery_workbook(candidates[0])
            self.assertEqual(recovered_source, source)
            self.assertEqual(recovered.active_sheet.dataframe.iloc[0, 0], "changed")
            self.assertEqual(recovered.active_sheet.dataframe.iloc[2, 2], "new row")
            self.assertEqual(
                list(recovered.active_sheet.dataframe.columns),
                ["Group 1", "Inserted", "Group 2"],
            )
            self.assertEqual(recovered.active_sheet.settings.title, "Recovered title")
            self.assertEqual(
                recovered.active_sheet.analysis_settings.visible_statistics,
                ["Median", "SD"],
            )
            self.assertEqual(
                recovered.active_sheet.analysis_settings.statistic_formats["SD"],
                {"decimals": 4, "scientific": True, "trim_zeros": False},
            )
            discard_recovery(candidates[0])

    def test_xy_sheet_state_replays_mapping_style_filter_and_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            manager = RecoveryManager(interval_seconds=2, root=pathlib.Path(tmp))
            sheet = SheetDocument(
                id="sheet",
                name="XY",
                dataframe=pd.DataFrame({"X": [0, 1], "A": [2, 3], "B": [4, 5]}),
                mode=SHEET_MODE_XY,
                column_ids=["x", "a", "b"],
                xy_settings=XYSettings(
                    default_x_column_id="x",
                    series=[
                        XYSeriesSpec(id="a-series", name="A", y_column_id="a"),
                        XYSeriesSpec(id="b-series", name="B", y_column_id="b"),
                    ],
                ),
            )
            workbook = WorkbookDocument([sheet], sheet.id)
            manager.replace_document(workbook, None, dirty=False)
            self.assertTrue(manager.wait_for_checkpoint(10.0))

            sheet.xy_settings.show_points = False
            sheet.xy_settings.show_line = True
            sheet.xy_settings.series.reverse()
            sheet.xy_settings.series[0].visible = False
            sheet.xy_settings.series[0].color = "#123456"
            sheet.xy_settings.series[1].x_column_id = "b"
            manager.record_sheet_state(sheet)
            self.assertTrue(manager.flush())

            recovered, _source = read_recovery_workbook(manager.session_dir)
            recovered_sheet = recovered.active_sheet
            self.assertEqual(recovered_sheet.mode, SHEET_MODE_XY)
            self.assertEqual(recovered_sheet.column_ids, ["x", "a", "b"])
            self.assertFalse(recovered_sheet.xy_settings.show_points)
            self.assertTrue(recovered_sheet.xy_settings.show_line)
            self.assertEqual(
                [series.id for series in recovered_sheet.xy_settings.series],
                ["b-series", "a-series"],
            )
            self.assertFalse(recovered_sheet.xy_settings.series[0].visible)
            self.assertEqual(recovered_sheet.xy_settings.series[0].color, "#123456")
            self.assertEqual(recovered_sheet.xy_settings.series[1].x_column_id, "b")
            manager.close(discard=True)

    def test_clean_or_incomplete_sessions_are_not_offered(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manager = RecoveryManager(interval_seconds=2, root=root)
            manager.replace_document(self.workbook(), None, dirty=False)
            self.assertTrue(manager.wait_for_checkpoint(10.0))
            session_dir = manager.session_dir
            manager.close(discard=False)

            self.assertEqual(find_recovery_candidates(root), [])
            self.assertFalse(session_dir.exists())

    def test_recovered_window_stays_unsaved_and_clean_close_discards_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            first = main_window.MainWindow(
                initial_render=False,
                recovery_enabled=True,
                recovery_root=root,
            )
            self.assertTrue(first._recovery_manager.wait_for_checkpoint(10.0))
            first.table.table_model.set_cell_text(1, 0, "survives crash")
            self.assertTrue(first._recovery_manager.flush())
            session_dir = first._recovery_manager.session_dir
            first._recovery_manager.close(discard=False)
            first._recovery_manager = None
            first.deleteLater()

            with mock.patch.object(
                main_window.MainWindow,
                "_prompt_recovery",
                return_value="recover",
            ):
                recovered = main_window.MainWindow(
                    initial_render=False,
                    recovery_enabled=True,
                    recovery_root=root,
                )
            self.assertEqual(
                recovered.table.table_model.cell_text(1, 0),
                "survives crash",
            )
            self.assertTrue(recovered.recovered_on_startup)
            self.assertTrue(recovered.has_unsaved_changes())
            self.assertEqual(recovered._recovery_manager.session_dir, session_dir)

            with mock.patch.object(
                recovered, "_prompt_unsaved_changes", return_value="discard"
            ):
                recovered.close()


if __name__ == "__main__":
    __import__("unittest").main()
