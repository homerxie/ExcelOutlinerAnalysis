from __future__ import annotations

from pathlib import Path
import tempfile
from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog

from tests.easygraph_case import EasyGraphQtTestCase, EasyGraphTestCase
from easygraph.analysis_results import descriptive_statistics_result
from easygraph.data import prepare_plot_data
from easygraph.overlay_series import stat_table_data
from easygraph.settings import ChartSettings, STAT_TABLE_OPTIONS
from easygraph.ui.statistic_format_dialog import StatisticFormatDialog


class SumStatisticsTests(EasyGraphTestCase):
    def test_analysis_sum_keeps_duplicate_columns_independent_and_empty_columns_blank(self):
        frame = pd.DataFrame(
            [
                [1, 10, None, -2, 0, "25%"],
                [2, None, "bad", -3, 0, "75％"],
                ["bad", 20, "", None, None, None],
                [float("nan"), 0, float("nan"), 0, float("nan"), ""],
            ],
            columns=["A", "A", "Empty", "Negative", "Zero", "Percent"],
        )
        before = frame.copy(deep=True)

        result = descriptive_statistics_result(frame, visible_statistics={"Sum"})

        self.assertEqual(result.columns, tuple(frame.columns))
        self.assertEqual(result.row_labels, ("Sum",))
        self.assertEqual(
            result.values,
            (("3.00", "30.00", "", "-5.00", "0.00", "1.00"),),
        )
        pd.testing.assert_frame_equal(frame, before)

    def test_chart_sum_ignores_invalid_values_and_respects_its_own_format(self):
        frame = pd.DataFrame({
            "group": ["A"] * 4 + ["Empty"] * 2 + ["Zero"] * 2,
            "value": [-2, -3, "bad", float("nan"), None, "bad", -1, 1],
        })
        settings = ChartSettings(
            show_stat_sum=True,
            show_stat_sample_size=True,
            line_value_decimals=7,
            statistic_formats={"Sum": {"decimals": 3, "scientific": True}},
        )

        groups, rows = stat_table_data(frame, settings)

        self.assertEqual(groups, ["A", "Empty", "Zero"])
        self.assertEqual(dict(rows)["Sum"], ["-5.000e+00", "", "0.000e+00"])
        self.assertEqual([label for label, _values in rows][-2:], ["Sum", "Sample"])
        settings.show_stat_sum = False
        self.assertNotIn("Sum", dict(stat_table_data(frame, settings)[1]))

    def test_chart_sum_preserves_percentage_units_after_data_preparation(self):
        settings = ChartSettings(
            show_stat_sum=True,
            statistic_formats={"Sum": {"decimals": 1}},
        )
        frame = pd.DataFrame({"Percent": ["25%", "75％", "bad"]})

        groups, rows = stat_table_data(
            prepare_plot_data(frame, settings), settings, percentage=True,
        )

        self.assertEqual(groups, ["Percent"])
        self.assertEqual(dict(rows)["Sum"], ["100.0%"])


class SumStatisticsUITests(EasyGraphQtTestCase):
    def test_sum_renders_in_each_chart_type_with_duplicate_columns(self):
        window = self.make_window()
        frame = pd.DataFrame([[1.25, -1], [2.75, -3]], columns=["A", "A"])
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            with self.subTest(chart_type=chart_type):
                settings = ChartSettings(
                    chart_type=chart_type,
                    statistic_formats={"Sum": {"decimals": 1}},
                )
                for setting_name, label in STAT_TABLE_OPTIONS:
                    setattr(settings, setting_name, label == "Sum")

                window.canvas.render(frame, settings)

                labels = [text.get_text() for text in window.canvas.figure.axes[1].texts]
                self.assertIn("Sum", labels)
                self.assertIn("4.0", labels)
                self.assertIn("-4.0", labels)
                self.assertNotIn("Mean", labels)

    def test_sum_format_dialog_supports_precision_scientific_notation_and_trim(self):
        dialog = StatisticFormatDialog({})
        self.addCleanup(dialog.close)
        override, decimals, notation, trim, preview = dialog.controls["Sum"]

        override.setChecked(True)
        decimals.setValue(4)
        trim.setChecked(True)
        self.assertEqual(preview.text(), "1234.5")
        notation.setCurrentIndex(1)
        self.assertEqual(preview.text(), "1.2345e+03")
        self.assertEqual(dialog.formats()["Sum"], {
            "decimals": 4, "scientific": True, "trim_zeros": True,
        })

    def test_sum_chart_option_analysis_filter_and_formats_survive_project_save(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": [1.25, 2.75]}))
        window.flush_pending_render()
        result = window.results_table.results_model.result
        self.assertEqual(result.values[result.row_labels.index("Sum")][0], "4.00")
        self.assertFalse(window.settings.show_stat_sum)

        for index in range(window.stat_table_options.count()):
            item = window.stat_table_options.item(index)
            item.setCheckState(Qt.Checked if item.text() == "Sum" else Qt.Unchecked)
        window.update_settings()
        self.assertTrue(window.settings.show_stat_sum)

        menu = window.results_table.statistics_filter_menu
        menu.begin_editing()
        menu.clear_button.click()
        window.results_table.statistics_filter_checkboxes["Sum"].setChecked(True)
        menu.apply_button.click()
        self.assertEqual(window.results_table.results_model.result.row_labels, ("Sum",))

        chart_formats = {"Sum": {"decimals": 3, "scientific": False, "trim_zeros": False}}
        analysis_formats = {"Sum": {"decimals": 1, "scientific": True, "trim_zeros": False}}
        with mock.patch.object(StatisticFormatDialog, "exec", return_value=QDialog.Accepted):
            with mock.patch.object(StatisticFormatDialog, "formats", return_value=chart_formats):
                window.ui.statisticNumberFormatsButton.click()
            with mock.patch.object(StatisticFormatDialog, "formats", return_value=analysis_formats):
                window.ui.analysisNumberFormatsButton.click()
        window.flush_pending_render()
        self.assertEqual(window.results_table.results_model.result.values[0][0], "4.0e+00")
        self.assertIn("4.000", [text.get_text() for text in window.canvas.figure.axes[1].texts])
        window.copy_analysis_results_table()
        self.assertIn("Sum\t4.0e+00", self.qapp.clipboard().text())

        with tempfile.TemporaryDirectory() as tmp:
            window.current_project = Path(tmp) / "sum.eg"
            self.assertTrue(window.save_project())
            restored = self.make_window()
            restored._load_project_path(window.current_project)

        self.assertTrue(restored.settings.show_stat_sum)
        self.assertEqual(restored.settings.statistic_formats, chart_formats)
        self.assertEqual(restored.workbook.active_sheet.analysis_settings.statistic_formats, analysis_formats)
        self.assertEqual(restored.results_table.visible_statistics(), frozenset({"Sum"}))
        self.assertEqual(restored.results_table.results_model.result.values[0][0], "4.0e+00")
        self.assertTrue(restored._stat_table_option_checked("show_stat_sum"))
