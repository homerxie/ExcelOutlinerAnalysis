from __future__ import annotations

import pathlib
import tempfile
from unittest import mock

import pandas as pd
from PySide6.QtCore import QPoint, Qt, QTimer
from PySide6.QtGui import QKeySequence
from PySide6.QtTest import QTest

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.analysis_results import (
    AnalysisTableResult,
    DESCRIPTIVE_STATISTICS,
    descriptive_statistics_result,
)
from easygraph.ui.analysis_results_table import AnalysisResultsTable
from easygraph.workbook import SHEET_MODE_XY


class AnalysisResultsTests(EasyGraphQtTestCase):
    def test_descriptive_statistics_include_percentage_samples(self):
        result = descriptive_statistics_result(
            pd.DataFrame({"A": ["25%", "75%", "bad"], "B": ["50％", 1, ""]}),
            visible_statistics={"Mean", "Sample"},
        )

        self.assertEqual(result.row_labels, ("Mean", "Sample"))
        self.assertEqual(result.values, (("0.50", "0.75"), ("2", "2")))

    def test_descriptive_statistics_use_all_source_columns(self):
        frame = pd.DataFrame(
            [[1, 5, 10], [3, 7, 20]],
            columns=["A", "A", "Hidden"],
        )
        result = descriptive_statistics_result(frame)

        self.assertEqual(result.key, "descriptive_statistics")
        self.assertEqual(result.columns, ("A", "A", "Hidden"))
        self.assertEqual(result.row_labels, DESCRIPTIVE_STATISTICS)
        self.assertEqual(
            result.values,
            (
                ("2.00", "6.00", "15.00"),
                ("2.00", "6.00", "15.00"),
                ("1.50", "5.50", "12.50"),
                ("2.50", "6.50", "17.50"),
                ("3.00", "7.00", "20.00"),
                ("1.00", "5.00", "10.00"),
                ("1.41", "1.41", "7.07"),
                ("1.00", "1.00", "5.00"),
                ("4.00", "12.00", "30.00"),
                ("2", "2", "2"),
            ),
        )
        self.assertTrue(result.source_aligned)

    def test_descriptive_statistics_accept_an_independent_visible_row_filter(self):
        frame = pd.DataFrame({"A": [1, 2, 3]})

        result = descriptive_statistics_result(
            frame,
            visible_statistics={"Mean", "Sample"},
        )

        self.assertEqual(result.row_labels, ("Mean", "Sample"))
        self.assertEqual(result.values, (("2.00",), ("3",)))

    def test_results_table_is_read_only_and_copies_a_rectangular_selection(self):
        table = AnalysisResultsTable()
        result = AnalysisTableResult(
            key="example",
            title="Example",
            columns=("A", "B"),
            row_labels=("Mean", "SD"),
            values=(("1.0", "2.0"), ("0.1", "0.2")),
        )
        table.set_result(result)
        table.set_statistics_filter_options(DESCRIPTIVE_STATISTICS)

        model = table.model()
        self.assertEqual(model.headerData(0, Qt.Horizontal), "A")
        self.assertEqual(model.headerData(1, Qt.Vertical), "SD")
        self.assertFalse(model.flags(model.index(0, 0)) & Qt.ItemIsEditable)
        self.assertEqual(
            table.visible_statistics(),
            frozenset(DESCRIPTIVE_STATISTICS),
        )
        table.statistics_filter_menu.begin_editing()
        table.statistics_filter_checkboxes["Q1"].setChecked(False)
        self.assertIn("Q1", table.visible_statistics())
        table.statistics_filter_menu.apply_button.click()
        self.assertNotIn("Q1", table.visible_statistics())
        self.assertEqual(table.statistics_filter_button.text(), "Stats")

        font = table.font()
        font.setPointSize(font.pointSize() + 2)
        table.setFont(font)
        self.qapp.processEvents()
        self.assertEqual(
            table.statistics_filter_button.font().pointSize(),
            table.font().pointSize(),
        )

        selection = table.selectionModel()
        selection.select(
            model.index(0, 0),
            selection.SelectionFlag.ClearAndSelect,
        )
        selection.select(
            model.index(1, 1),
            selection.SelectionFlag.Select,
        )
        self.assertEqual(table.selection_tsv(), "1.0\t\n\t0.2")
        self.assertEqual(
            table.selection_with_headers_tsv(),
            "\tA\tB\nMean\t1.0\t\nSD\t\t0.2",
        )
        self.assertEqual(
            table.table_tsv(),
            "\tA\tB\nMean\t1.0\t2.0\nSD\t0.1\t0.2",
        )

    def test_stats_main_area_selects_all_and_arrow_opens_filter(self):
        table = AnalysisResultsTable()
        table.set_result(
            AnalysisTableResult(
                key="example",
                title="Example",
                columns=("A", "B"),
                row_labels=("Mean", "Sample"),
                values=(("1.50", "3.50"), ("2", "2")),
            )
        )
        table.set_statistics_filter_options(DESCRIPTIVE_STATISTICS)
        table.resize(400, 240)
        table.show()
        self.qapp.processEvents()
        button = table.statistics_filter_button

        self.assertEqual(
            button.popupMode(),
            button.ToolButtonPopupMode.MenuButtonPopup,
        )
        QTest.mouseClick(
            button,
            Qt.MouseButton.LeftButton,
            pos=QPoint(3, button.height() // 2),
        )
        self.assertEqual(
            len(table.selectionModel().selectedIndexes()),
            table.model().rowCount() * table.model().columnCount(),
        )
        self.assertFalse(table.statistics_filter_menu.isVisible())

        menu_was_visible = []

        def record_and_close_menu():
            menu_was_visible.append(table.statistics_filter_menu.isVisible())
            table.statistics_filter_menu.close()

        QTimer.singleShot(0, record_and_close_menu)
        QTest.mouseClick(
            button,
            Qt.MouseButton.LeftButton,
            pos=QPoint(button.width() - 3, button.height() // 2),
        )
        self.assertEqual(menu_was_visible, [True])

    def test_results_row_and_column_headers_select_complete_sections(self):
        table = AnalysisResultsTable()
        table.set_result(
            AnalysisTableResult(
                key="example",
                title="Example",
                columns=("A", "B"),
                row_labels=("Mean", "Sample"),
                values=(("1.50", "3.50"), ("2", "2")),
            )
        )
        table.resize(400, 240)
        table.show()
        self.qapp.processEvents()

        horizontal = table.horizontalHeader()
        column_x = (
            horizontal.sectionViewportPosition(1)
            + horizontal.sectionSize(1) // 2
        )
        QTest.mouseClick(
            horizontal.viewport(),
            Qt.MouseButton.LeftButton,
            pos=QPoint(column_x, horizontal.height() // 2),
        )
        self.assertEqual(
            {(index.row(), index.column()) for index in table.selectedIndexes()},
            {(0, 1), (1, 1)},
        )

        table.clearSelection()
        vertical = table.verticalHeader()
        row_y = (
            vertical.sectionViewportPosition(0)
            + vertical.sectionSize(0) // 2
        )
        QTest.mouseClick(
            vertical.viewport(),
            Qt.MouseButton.LeftButton,
            pos=QPoint(vertical.width() // 2, row_y),
        )
        self.assertEqual(
            {(index.row(), index.column()) for index in table.selectedIndexes()},
            {(0, 0), (0, 1)},
        )

    def test_copy_statistics_button_copies_the_complete_visible_table(self):
        window = self.make_window()
        window.results_table.set_result(
            AnalysisTableResult(
                key="example",
                title="Example",
                columns=("A", "B"),
                row_labels=("Mean", "Sample"),
                values=(("1.50", "3.50"), ("2", "2")),
            )
        )
        self.qapp.clipboard().clear()

        window.ui.copyStatisticsButton.click()

        self.assertEqual(
            self.qapp.clipboard().text(),
            "\tA\tB\nMean\t1.50\t3.50\nSample\t2\t2",
        )
        self.assertEqual(
            window.statusBar().currentMessage(),
            "Statistics table copied to clipboard",
        )

    def test_results_context_menu_copies_selection_or_current_table(self):
        window = self.make_window()
        window.results_table.set_result(
            AnalysisTableResult(
                key="example",
                title="Example",
                columns=("A", "B"),
                row_labels=("Mean", "Sample"),
                values=(("1.50", "3.50"), ("2", "2")),
            )
        )
        model = window.results_table.model()
        window.results_table.selectionModel().select(
            model.index(0, 0),
            window.results_table.selectionModel().SelectionFlag.ClearAndSelect,
        )

        menu = window.analysis_results_context_menu()
        actions = {
            action.text(): action
            for action in menu.actions()
            if not action.isSeparator()
        }

        self.assertEqual(
            window.results_table.contextMenuPolicy(),
            Qt.ContextMenuPolicy.CustomContextMenu,
        )
        self.assertEqual(
            set(actions),
            {
                "Copy Selected Data",
                "Copy Selected Data with Headers",
                "Copy Current Statistics Table",
                "Statistic Number Formats...",
            },
        )
        self.assertTrue(menu.actions()[2].isSeparator())
        self.assertEqual(
            actions["Copy Selected Data"].shortcut(),
            QKeySequence.Copy,
        )
        self.assertTrue(actions["Copy Selected Data"].isEnabled())
        self.assertTrue(actions["Copy Selected Data with Headers"].isEnabled())
        self.assertTrue(actions["Copy Current Statistics Table"].isEnabled())

        actions["Copy Selected Data"].trigger()
        self.assertEqual(self.qapp.clipboard().text(), "1.50")
        actions["Copy Selected Data with Headers"].trigger()
        self.assertEqual(self.qapp.clipboard().text(), "\tA\nMean\t1.50")
        actions["Copy Current Statistics Table"].trigger()
        self.assertEqual(
            self.qapp.clipboard().text(),
            "\tA\tB\nMean\t1.50\t3.50\nSample\t2\t2",
        )

    def test_table_selections_are_exclusive_and_copy_uses_focused_table(self):
        window = self.make_window()
        window.resize(1200, 700)
        window.show()
        self.qapp.processEvents()
        data_model = window.table.model()
        results_model = window.results_table.model()

        window.table.selectionModel().select(
            data_model.index(1, 0),
            window.table.selectionModel().SelectionFlag.ClearAndSelect,
        )
        self.assertTrue(window.table.selectedIndexes())
        window.results_table.selectionModel().select(
            results_model.index(0, 0),
            window.results_table.selectionModel().SelectionFlag.ClearAndSelect,
        )
        self.assertFalse(window.table.selectedIndexes())
        self.assertTrue(window.results_table.selectedIndexes())

        self.assertEqual(
            window.table_copy_shortcut.context(),
            Qt.ShortcutContext.WidgetWithChildrenShortcut,
        )
        self.assertEqual(
            window.results_copy_shortcut.context(),
            Qt.ShortcutContext.WidgetWithChildrenShortcut,
        )
        self.qapp.clipboard().clear()
        window.results_table.setFocus()
        self.qapp.processEvents()
        QTest.keySequence(window.results_table, QKeySequence.Copy)
        self.assertEqual(
            self.qapp.clipboard().text(),
            window.results_table.selection_tsv(),
        )

        window.table.selectionModel().select(
            data_model.index(1, 0),
            window.table.selectionModel().SelectionFlag.ClearAndSelect,
        )
        self.assertFalse(window.results_table.selectedIndexes())
        expected_data_text = window.table.table_model.cell_text(1, 0)
        self.qapp.clipboard().clear()
        window.table.setFocus()
        self.qapp.processEvents()
        QTest.keySequence(window.table, QKeySequence.Copy)
        self.assertEqual(self.qapp.clipboard().text(), expected_data_text)

    def test_statistics_filter_menu_stays_open_and_supports_bulk_or_cancel(self):
        table = AnalysisResultsTable()
        table.set_statistics_filter_options(DESCRIPTIVE_STATISTICS)
        menu = table.statistics_filter_menu
        table.show()
        menu.show()
        self.qapp.processEvents()

        table.statistics_filter_checkboxes["Mean"].click()
        self.assertTrue(menu.isVisible())
        self.assertIn("Mean", table.visible_statistics())

        menu.clear_button.click()
        self.assertFalse(menu.apply_button.isEnabled())
        menu.invert_button.click()
        self.assertTrue(menu.apply_button.isEnabled())
        self.assertTrue(
            all(
                checkbox.isChecked()
                for checkbox in table.statistics_filter_checkboxes.values()
            )
        )
        menu.clear_button.click()
        menu.select_all_button.click()
        table.statistics_filter_checkboxes["Mean"].setChecked(False)
        menu.cancel_button.click()
        self.assertFalse(menu.isVisible())
        self.assertEqual(
            table.visible_statistics(),
            frozenset(DESCRIPTIVE_STATISTICS),
        )

    def test_main_window_links_result_column_widths_and_horizontal_scroll(self):
        window = self.make_window()
        frame = pd.DataFrame(
            {
                f"Group {index + 1}": [index, index + 1, index + 2]
                for index in range(12)
            }
        )
        window.resize(1100, 700)
        window.show()
        window.set_table_dataframe(frame)
        window.render()
        self.qapp.processEvents()

        source_model = window.table.table_model
        result = window.results_table.results_model.result
        self.assertEqual(
            window.results_table.model().columnCount(),
            source_model.columnCount(),
        )
        self.assertEqual(
            result.columns,
            tuple(
                source_model.cell_text(0, column)
                for column in range(source_model.columnCount())
            ),
        )
        self.assertTrue(all(row[-1] == "" for row in result.values))

        window.table.setColumnWidth(0, 173)
        self.assertEqual(window.results_table.columnWidth(0), 173)
        window.results_table.setColumnWidth(1, 149)
        self.assertEqual(window.table.columnWidth(1), 149)
        spare_column = source_model.columnCount() - 1
        window.table.setColumnWidth(spare_column, 181)
        self.assertEqual(window.results_table.columnWidth(spare_column), 181)
        window.results_table.setColumnWidth(spare_column, 167)
        self.assertEqual(window.table.columnWidth(spare_column), 167)

        source_scroll = window.table.horizontalScrollBar()
        result_scroll = window.results_table.horizontalScrollBar()
        self.assertGreater(source_scroll.maximum(), 0)
        self.assertEqual(source_scroll.maximum(), result_scroll.maximum())
        source_scroll.setValue(min(90, source_scroll.maximum()))
        self.assertEqual(result_scroll.value(), source_scroll.value())
        result_scroll.setValue(min(45, result_scroll.maximum()))
        self.assertEqual(source_scroll.value(), result_scroll.value())
        retained_scroll = source_scroll.value()
        window.render()
        self.qapp.processEvents()
        self.assertEqual(source_scroll.maximum(), result_scroll.maximum())
        self.assertEqual(source_scroll.value(), retained_scroll)
        self.assertEqual(result_scroll.value(), retained_scroll)

    def test_groups_results_keep_duplicate_user_columns_and_show_auto_spare_blank(self):
        window = self.make_window()
        frame = pd.DataFrame(
            [[1, 5], [3, 7]],
            columns=["A", "A"],
        )
        window.set_table_dataframe(frame)
        window.render()

        source_model = window.table.table_model
        result = window.results_table.results_model.result
        self.assertEqual(source_model.columnCount(), 3)
        self.assertEqual(
            result.columns,
            tuple(
                source_model.cell_text(0, column)
                for column in range(source_model.columnCount())
            ),
        )
        self.assertEqual(result.columns[:2], ("A", "A"))
        self.assertEqual(
            result.values[result.row_labels.index("Mean")],
            ("2.00", "6.00", ""),
        )
        self.assertEqual(
            result.values[result.row_labels.index("Sample")],
            ("2", "2", ""),
        )
        self.assertTrue(all(row[-1] == "" for row in result.values))
        copied_rows = [
            row.split("\t")
            for row in window.results_table.table_tsv().splitlines()
        ]
        self.assertEqual(tuple(copied_rows[0][1:]), result.columns)
        self.assertTrue(all(row[-1] == "" for row in copied_rows[1:]))
        self.assertTrue(
            all(len(row) == source_model.columnCount() + 1 for row in copied_rows)
        )
        self.assertEqual(list(window._user_group_dataframe().columns), ["A", "A"])

    def test_groups_promoted_spare_gets_statistics_and_new_spare_stays_blank(self):
        window = self.make_window()
        window.set_table_dataframe(
            pd.DataFrame(
                {
                    "A": [1, 3],
                    "B": [2, 4],
                }
            )
        )
        model = window.table.table_model
        sample_start = window._table_controller.sample_start_row()
        promoted_column = model.columnCount() - 1

        model.set_cell_text(sample_start, promoted_column, "5")
        self.qapp.processEvents()
        model.set_cell_text(sample_start + 1, promoted_column, "7")
        model.set_cell_text(0, promoted_column, "Promoted")
        self.qapp.processEvents()
        window.flush_pending_render()
        self.qapp.processEvents()

        result = window.results_table.results_model.result
        self.assertEqual(
            window.results_table.model().columnCount(),
            model.columnCount(),
        )
        self.assertEqual(
            result.columns,
            tuple(
                model.cell_text(0, column)
                for column in range(model.columnCount())
            ),
        )
        self.assertEqual(result.columns[promoted_column], "Promoted")
        self.assertEqual(
            result.values[result.row_labels.index("Mean")][promoted_column],
            "6.00",
        )
        self.assertEqual(
            result.values[result.row_labels.index("Sample")][promoted_column],
            "2",
        )
        self.assertTrue(all(row[-1] == "" for row in result.values))
        self.assertEqual(
            list(window._user_group_dataframe().columns),
            list(result.columns[:-1]),
        )
        self.assertEqual(
            model.columnCount(),
            len(window._user_group_dataframe().columns) + 1,
        )

    def test_xy_sheet_keeps_groups_analysis_hidden_and_unchanged(self):
        window = self.make_window()
        window.render()
        groups_result = window.results_table.results_model.result

        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        window.refresh_analysis_results()

        self.assertTrue(window.results_table.isHidden())
        self.assertEqual(window.results_table.results_model.result, groups_result)

    def test_overlay_row_keeps_source_and_results_origins_aligned(self):
        window = self.make_window()
        window.resize(1200, 700)
        window.show()
        self.qapp.processEvents()

        window.add_custom_overlay_row()
        window.flush_pending_render()
        self.qapp.processEvents()

        self.assertEqual(
            window.table.verticalHeader().width(),
            window.results_table.verticalHeader().width(),
        )
        self.assertEqual(
            window.table.horizontalHeader().geometry().x(),
            window.results_table.horizontalHeader().geometry().x(),
        )
        self.assertGreaterEqual(window.table.verticalHeader().width(), 86)

    def test_results_filter_is_independent_and_splitter_alone_collapses_panes(self):
        window = self.make_window()
        window.resize(1200, 700)
        window.show()
        self.qapp.processEvents()

        self.assertFalse(hasattr(window.ui, "dataPaneButton"))
        self.assertFalse(hasattr(window.ui, "resultsPaneButton"))
        self.assertFalse(hasattr(window.ui, "closeResultsButton"))
        self.assertTrue(window.ui.dataResultsSplitter.childrenCollapsible())

        for index in range(window.stat_table_options.count()):
            window.stat_table_options.item(index).setCheckState(Qt.Unchecked)
        window.update_settings()
        window.flush_pending_render()
        self.assertEqual(
            window.results_table.results_model.result.row_labels,
            DESCRIPTIVE_STATISTICS,
        )

        window.results_table.statistics_filter_menu.begin_editing()
        window.results_table.statistics_filter_checkboxes["SEM"].setChecked(False)
        window.results_table.statistics_filter_menu.apply_button.click()
        self.assertNotIn(
            "SEM",
            window.results_table.results_model.result.row_labels,
        )
        self.assertFalse(window.settings.show_stat_mean)

        splitter = window.ui.dataResultsSplitter
        total = sum(splitter.sizes())
        splitter.setSizes([total, 0])
        self.qapp.processEvents()
        self.assertEqual(splitter.sizes()[1], 0)
        splitter.setSizes([0, total])
        self.qapp.processEvents()
        self.assertEqual(splitter.sizes()[0], 0)

    def test_plot_settings_do_not_change_analysis_results(self):
        window = self.make_window()
        frame = pd.DataFrame(
            {
                "A": [1, 2, 100],
                "B": [10, 20, 30],
            }
        )
        window.set_table_dataframe(frame)
        window.render()
        baseline = window.results_table.results_model.result

        window.settings.group_hidden = ["B"]
        window.settings.group_order = "Name Z-A"
        window.settings.outlier_effect = "Exclude from distribution"
        window.settings.outlier_method = "IQR"
        window.settings.line_value_decimals = 7
        window.settings.line_value_scientific = True
        window.settings.show_stat_table = False
        window.settings.show_stat_mean = False
        window.render()

        self.assertEqual(window.results_table.results_model.result, baseline)

    def test_statistics_visibility_is_saved_and_restored_per_sheet(self):
        window = self.make_window()

        window.results_table.statistics_filter_menu.begin_editing()
        window.results_table.statistics_filter_checkboxes["Q1"].setChecked(False)
        window.results_table.statistics_filter_menu.apply_button.click()
        self.assertTrue(window.has_unsaved_changes())
        self.assertNotIn(
            "Q1",
            window.workbook.active_sheet.analysis_settings.visible_statistics,
        )

        window.add_sheet()
        self.assertEqual(
            window.results_table.visible_statistics(),
            frozenset(DESCRIPTIVE_STATISTICS),
        )
        window.results_table.statistics_filter_menu.begin_editing()
        window.results_table.statistics_filter_checkboxes["Mean"].setChecked(False)
        window.results_table.statistics_filter_menu.apply_button.click()

        window.sheet_tab_bar.setCurrentIndex(0)
        self.assertNotIn("Q1", window.results_table.visible_statistics())
        self.assertIn("Mean", window.results_table.visible_statistics())
        window.sheet_tab_bar.setCurrentIndex(1)
        self.assertNotIn("Mean", window.results_table.visible_statistics())
        self.assertIn("Q1", window.results_table.visible_statistics())

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "analysis-visibility.eg"
            window.current_project = path
            self.assertTrue(window.save_project())
            self.assertFalse(window.has_unsaved_changes())

            loaded = self.make_window()
            loaded._load_project_path(path)

        self.assertEqual(loaded.workbook.active_index, 1)
        self.assertNotIn("Mean", loaded.results_table.visible_statistics())
        self.assertIn("Q1", loaded.results_table.visible_statistics())
        loaded.sheet_tab_bar.setCurrentIndex(0)
        self.assertNotIn("Q1", loaded.results_table.visible_statistics())
        self.assertIn("Mean", loaded.results_table.visible_statistics())
