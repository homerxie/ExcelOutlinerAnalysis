from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path
import zipfile

from tests.easygraph_case import ROOT, EasyGraphTestCase


class WindowsPackageTests(EasyGraphTestCase):
    def test_source_package_supports_external_output_and_contains_smoke_tools(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "scripts" / "package_windows_release.py"),
                    "--output-dir",
                    tmp,
                    "--name",
                    "EasyGraph-test",
                ],
                cwd=ROOT,
                capture_output=True,
                text=True,
                check=False,
                timeout=30,
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            archive_path = Path(result.stdout.strip())
            self.assertTrue(archive_path.is_absolute())
            self.assertTrue(archive_path.is_file())
            with zipfile.ZipFile(archive_path) as archive:
                packaged_paths = {
                    Path(name).parts[-2:]
                    for name in archive.namelist()
                    if not name.endswith("/")
                }

        for expected in (
            ("windows", "EasyGraph.ico"),
            (
                "EasyGraph_Project_Icon_Pack",
                "EasyGraph_Project_Icon_Windows.ico",
            ),
            ("translations", "easygraph_zh_CN.qm"),
            ("scripts", "generate_windows_icons.py"),
            ("scripts", "build_and_smoke_windows.ps1"),
            ("scripts", "package_windows_release.py"),
            ("scripts", "windows_version_info.py"),
            ("easygraph", "packaging_smoke.py"),
            ("easygraph", "file_association.py"),
            ("prism_io", "pzfx.py"),
            ("src", "ui_prism_import_dialog.py"),
            ("ui", "prism_import_dialog.ui"),
            ("src", "ui_startup_dialog.py"),
            ("ui", "startup_dialog.ui"),
            ("scripts", "inspect_prism_samples.py"),
            ("plans", "2026-07-16-prism-raw-data-import.md"),
            ("prism_samples", "SOURCES.md"),
            ("tests", "test_packaging_smoke.py"),
            ("tests", "test_file_association.py"),
            ("tests", "test_prism_pzfx.py"),
            ("tests", "test_windows_package.py"),
        ):
            with self.subTest(expected=expected):
                self.assertIn(expected, packaged_paths)
