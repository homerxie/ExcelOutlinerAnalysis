from pathlib import Path
from unittest import mock

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtGui import QBrush
from PySide6.QtWidgets import QTableView

from tests.easygraph_case import ROOT, EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.table_model import EasyGraphTableModel


class EasyGraphTableModelTests(EasyGraphQtTestCase):
    def test_model_roundtrips_duplicate_groups_overlays_empty_values_and_multiline_names(self):
        model = EasyGraphTableModel()
        frame = pd.DataFrame(
            [[1, 2, None], [3, 4, "x"]],
            columns=["A", "A", "B\nline"],
        )
        overlays = [{"name": "Target\nline", "values": {"A": "10"}}]

        sample_start = model.replace_from_dataframe(frame, overlays)
        model.set_vertical_headers(["", "Target\nline", "1", "2"])

        self.assertEqual(sample_start, 2)
        self.assertEqual((model.rowCount(), model.columnCount()), (4, 3))
        self.assertEqual(model.cell_text(0, 0), "A")
        self.assertEqual(model.cell_text(0, 1), "A")
        self.assertEqual(model.cell_text(1, 0), "10")
        self.assertEqual(model.cell_text(1, 1), "10")
        self.assertEqual(model.cell_text(2, 2), "")
        pd.testing.assert_frame_equal(
            model.sample_dataframe(sample_start),
            pd.DataFrame(
                [["1", "2", ""], ["3", "4", "x"]],
                columns=["A", "A", "B\nline"],
            ),
        )
        self.assertEqual(
            model.overlay_series(sample_start, [], ["A", "A", "B\nline"]),
            [{
                "name": "Target\nline",
                "values": {"A": "10", "B\nline": ""},
            }],
        )

    def test_model_edit_emits_one_change_and_exposes_view_roles(self):
        table = DataTable()
        self.addCleanup(table.deleteLater)
        table.set_dataframe(pd.DataFrame({"A": [1]}))
        table.table_model.configure_style(1, QBrush(), QBrush())
        changed = mock.Mock()
        table.table_model.cellEdited.connect(changed)
        revision = table.table_model.revision

        self.assertTrue(table.table_model.set_cell_text(1, 0, "2"))

        changed.assert_called_once_with(1, 0, "1", "2")
        self.assertEqual(table.table_model.revision, revision + 1)
        self.assertTrue(table.table_model.data(table.table_model.index(0, 0), Qt.FontRole).bold())
        self.assertFalse(table.table_model.data(table.table_model.index(1, 0), Qt.FontRole).bold())
        self.assertEqual(
            table.table_model.data(table.table_model.index(0, 0), Qt.TextAlignmentRole),
            Qt.AlignCenter,
        )

    def test_model_insert_remove_and_bulk_replace_keep_rectangular_storage(self):
        model = EasyGraphTableModel()
        model.replace_cells([["A"], ["1"]], column_count=1)

        self.assertTrue(model.insertColumns(1, 2))
        self.assertTrue(model.insertRows(2, 2))
        model.set_cell_text(3, 2, "tail")
        self.assertEqual(model.cells_copy()[-1], ["", "", "tail"])
        self.assertTrue(model.removeRows(2, 1))
        self.assertTrue(model.removeColumns(1, 1))
        self.assertEqual((model.rowCount(), model.columnCount()), (3, 2))
        self.assertEqual(model.cell_text(2, 1), "tail")

    def test_data_table_is_a_table_view_backed_by_easygraph_model(self):
        table = DataTable()
        self.addCleanup(table.deleteLater)

        self.assertIsInstance(table, QTableView)
        self.assertIs(table.model(), table.table_model)
        self.assertIsInstance(table.model(), EasyGraphTableModel)

    def test_product_table_path_has_no_qtablewidget_item_storage(self):
        paths = [
            ROOT / "src/easygraph/table_model.py",
            ROOT / "src/easygraph/data_table.py",
            ROOT / "src/easygraph/table_data.py",
            ROOT / "src/easygraph/table_actions.py",
            ROOT / "src/easygraph/table_clipboard.py",
            ROOT / "src/easygraph/table_style.py",
            ROOT / "src/easygraph/table_snapshot.py",
            ROOT / "src/easygraph/ui/table_controller.py",
        ]

        for path in paths:
            with self.subTest(path=path.name):
                source = Path(path).read_text(encoding="utf-8")
                self.assertNotIn("QTableWidgetItem", source)
                self.assertNotIn("QTableWidget", source)

    def test_generated_ui_constructs_promoted_data_table(self):
        ui_source = (ROOT / "src/ui_main_window.py").read_text(encoding="utf-8")
        form_source = (ROOT / "ui/main_window.ui").read_text(encoding="utf-8")

        self.assertIn("from easygraph.data_table import DataTable", ui_source)
        self.assertIn("self.dataTable = DataTable(self.xySharedFrame)", ui_source)
        self.assertIn(
            "self.xyIndependentTable = DataTable(self.xyIndependentFrame)",
            ui_source,
        )
        self.assertIn(
            "from easygraph.ui.analysis_results_table import AnalysisResultsTable",
            ui_source,
        )
        self.assertIn(
            "self.analysisResultsTable = AnalysisResultsTable(self.xyIndependentFrame)",
            ui_source,
        )
        self.assertIn('<widget class="DataTable" name="dataTable">', form_source)
        self.assertIn('<widget class="DataTable" name="xyIndependentTable">', form_source)
        self.assertIn(
            '<widget class="AnalysisResultsTable" name="analysisResultsTable"/>',
            form_source,
        )
