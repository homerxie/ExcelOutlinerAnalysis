from __future__ import annotations

import ast
from pathlib import Path
from unittest import mock

import pandas as pd
from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QLineEdit

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.settings import ChartSettings
from easygraph.table_history import BlockEdit, CellEdit, SettingsEdit, StructureSnapshotEdit
from easygraph.ui import table_controller
from easygraph.ui.table_controller import TableController, TableControllerHooks
from easygraph.workbook import SHEET_MODE_XY, SheetDocument
from easygraph.xy_series import XYSeriesSpec, XYSettings


class TableControllerTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.current_settings = ChartSettings()
        self.table = DataTable()
        self.addCleanup(self.table.close)
        self.render = mock.Mock()
        self.update_history_actions = mock.Mock()
        self.update_dependent_controls = mock.Mock()
        self.sync_overlay_controls = mock.Mock()
        self.controller = TableController(
            table=self.table,
            settings=lambda: self.current_settings,
            hooks=TableControllerHooks(
                render=self.render,
                update_history_actions=self.update_history_actions,
                update_dependent_controls=self.update_dependent_controls,
                sync_overlay_controls=self.sync_overlay_controls,
            ),
        )

    def test_controller_uses_latest_settings_from_getter(self):
        replacement = ChartSettings(manual_group_order=["B", "A"], group_hidden=["missing", "B"])
        self.current_settings = replacement
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"], "B": ["2"]}))
        self.controller.sync_manual_group_order()
        self.assertEqual(replacement.manual_group_order, ["B", "A"])
        self.assertEqual(replacement.group_hidden, ["B"])

    def test_set_dataframe_round_trips_samples_and_overlay_rows(self):
        overlays = [{"name": "Limit", "values": {"A": "3", "B": "4"}}]
        self.current_settings.custom_overlay_series = overlays
        frame = pd.DataFrame({"A": ["1"], "B": ["2"]})
        self.controller.set_dataframe(frame, overlays)
        self.assertEqual(self.controller.overlay_row_count(), 1)
        self.assertEqual(self.controller.sample_start_row(), 2)
        self.assertEqual(self.controller.group_names(), ["A", "B"])
        self.assertEqual(self.controller.dataframe().to_dict("list"), {"A": ["1"], "B": ["2"]})
        self.assertEqual(self.controller.overlay_series_from_table(), overlays)

    def test_dataframe_cache_reuses_revision_and_direct_edit_invalidates_it(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"], "B": ["2"]}))

        with mock.patch.object(
            table_controller,
            "table_sample_dataframe",
            wraps=table_controller.table_sample_dataframe,
        ) as read_table:
            first = self.controller.dataframe()
            first.iloc[0, 0] = "caller mutation"
            second = self.controller.dataframe()

            self.assertEqual(read_table.call_count, 1)
            self.assertEqual(second.iloc[0, 0], "1")
            revision = self.controller.data_revision

            self.table.table_model.set_cell_text(1, 0, "changed")
            updated = self.controller.dataframe()

        self.assertGreater(self.controller.data_revision, revision)
        self.assertEqual(read_table.call_count, 2)
        self.assertEqual(updated.iloc[0, 0], "changed")

    def test_blocked_signal_mutation_invalidates_cached_dataframe(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.controller.dataframe()
        revision = self.controller.data_revision
        self.table.setCurrentIndex(self.table.table_model.index(1, 0))

        self.assertTrue(self.controller.paste_text("2"))

        self.assertGreater(self.controller.data_revision, revision)
        self.assertEqual(self.controller.dataframe().iloc[0, 0], "2")

    def test_refresh_structure_and_group_order_are_controller_owned(self):
        self.current_settings.manual_group_order = ["removed", "B"]
        self.current_settings.group_hidden = ["removed", "A"]
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"], "B": ["2"]}))
        self.controller.sync_manual_group_order()
        self.assertEqual(self.current_settings.manual_group_order, ["B", "A"])
        self.assertEqual(self.current_settings.group_hidden, ["A"])
        self.assertEqual(self.table.table_model.headerData(0, Qt.Horizontal), "1")
        self.assertEqual(self.table.table_model.headerData(1, Qt.Horizontal), "2")

    def test_snapshot_restore_round_trips_table_and_current_settings(self):
        self.current_settings.custom_overlay_series = [{"name": "Limit", "values": {"A": "3"}}]
        self.current_settings.custom_overlay_hidden = [0]
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.table.setCurrentIndex(self.table.table_model.index(2, 0))
        snapshot = self.controller.snapshot()
        self.table.table_model.set_cell_text(2, 0, "changed")
        self.current_settings.custom_overlay_hidden = []
        self.controller.restore_snapshot(snapshot)
        self.assertEqual(self.table.table_model.cell_text(2, 0), "1")
        self.assertEqual(self.table.currentIndex().row(), 2)
        self.assertEqual(self.current_settings.custom_overlay_hidden, [0])
        self.sync_overlay_controls.assert_called_once_with()
        self.update_dependent_controls.assert_called_once_with()
        self.render.assert_called_once_with()

    def test_history_mutation_records_once_and_clears_redo(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.controller.reset_history()
        self.controller.history.redo_stack = [CellEdit(0, 0, "redo", "value")]

        def mutate():
            self.table.table_model.set_cell_text(1, 0, "2")

        result = self.controller.run_history_mutation(mutate)
        self.assertIsNone(result)
        self.assertEqual(len(self.controller.history.undo_stack), 1)
        self.assertEqual(self.controller.history.redo_stack, [])
        self.assertIsInstance(
            self.controller.history.undo_stack[-1],
            StructureSnapshotEdit,
        )

    def test_normal_cell_edit_records_incrementally_without_taking_a_snapshot(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.controller.reset_history()

        with mock.patch.object(
            self.controller,
            "snapshot",
            side_effect=AssertionError("ordinary edits must not snapshot the table"),
        ), mock.patch.object(
            self.controller,
            "restore_snapshot",
            side_effect=AssertionError("ordinary undo must not rebuild the table"),
        ):
            self.table.table_model.set_cell_text(1, 0, "2")
            self.controller.record_history_change()
            command = self.controller.history.undo_stack[-1]
            self.controller.undo()
            self.assertEqual(self.table.table_model.cell_text(1, 0), "1")
            self.controller.redo()

        self.assertIsInstance(command, CellEdit)
        self.assertEqual(command, CellEdit(1, 0, "1", "2"))
        self.assertEqual(self.table.table_model.cell_text(1, 0), "2")
        self.assertEqual(self.render.call_count, 2)

    def test_boolean_false_mutation_does_not_create_history(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.controller.reset_history()
        self.assertFalse(self.controller.run_history_mutation(lambda: False))
        self.assertEqual(self.controller.history.undo_stack, [])

    def test_undo_and_redo_restore_cells_and_action_state(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.controller.reset_history()
        self.controller.run_history_mutation(
            lambda: self.table.table_model.set_cell_text(1, 0, "2")
        )
        self.controller.undo()
        self.assertEqual(self.table.table_model.cell_text(1, 0), "1")
        self.controller.redo()
        self.assertEqual(self.table.table_model.cell_text(1, 0), "2")
        self.assertIn(mock.call(False, True), self.update_history_actions.call_args_list)
        self.assertEqual(self.update_history_actions.call_args, mock.call(True, False))

    def test_editor_navigation_commits_once_moves_and_rejects_boundary(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1", "2"]}))
        self.controller.reset_history()
        self.table.table_model.cellEdited.connect(
            lambda *_args: self.controller.record_history_change()
        )
        self.table.setCurrentIndex(self.table.table_model.index(1, 0))
        self.table.edit(self.table.table_model.index(1, 0))
        self.qapp.processEvents()
        editor = self.table.findChild(QLineEdit)
        self.assertIsNotNone(editor)
        editor.setText("committed")
        event = QKeyEvent(QEvent.KeyPress, Qt.Key_Down, Qt.NoModifier)
        self.assertTrue(self.controller.handle_editor_navigation(event, editor))
        self.assertEqual(self.table.table_model.cell_text(1, 0), "committed")
        self.assertEqual((self.table.currentIndex().row(), self.table.currentIndex().column()), (2, 0))
        self.assertEqual(len(self.controller.history.undo_stack), 1)
        self.assertFalse(self.controller.handle_editor_navigation(event, editor))
        self.assertEqual(len(self.controller.history.undo_stack), 1)

    def test_cut_selection_returns_tsv_and_records_one_change(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.select_table_range(self.table, 1, 0, 1, 0)
        self.controller.reset_history()
        self.assertEqual(self.controller.cut_selection(), "1")
        self.assertEqual(self.table.table_model.cell_text(1, 0), "")
        self.assertEqual(len(self.controller.history.undo_stack), 1)
        self.assertIsInstance(self.controller.history.undo_stack[-1], BlockEdit)
        self.render.assert_called_once_with()

    def test_paste_and_clear_each_record_one_change(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.table.setCurrentIndex(self.table.table_model.index(1, 0))
        self.controller.reset_history()
        self.assertTrue(self.controller.paste_text("2\t3"))
        self.assertEqual([self.table.table_model.cell_text(1, col) for col in range(2)], ["2", "3"])
        self.table.clearSelection()
        self.select_table_range(self.table, 1, 0, 1, 1)
        self.assertTrue(self.controller.clear_selection())
        self.assertEqual([self.table.table_model.cell_text(1, col) for col in range(2)], ["", ""])
        self.assertEqual(len(self.controller.history.undo_stack), 2)
        self.assertIsInstance(
            self.controller.history.undo_stack[0],
            StructureSnapshotEdit,
        )
        self.assertIsInstance(self.controller.history.undo_stack[1], BlockEdit)
        self.assertEqual(self.render.call_count, 2)

    def test_same_shape_paste_uses_block_edit_but_expanding_paste_uses_snapshot(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"], "B": ["2"]}))
        self.controller.reset_history()
        self.table.setCurrentIndex(self.table.table_model.index(1, 0))

        self.assertTrue(self.controller.paste_text("3\t4"))
        self.assertIsInstance(self.controller.history.undo_stack[-1], BlockEdit)
        self.assertEqual(
            [self.table.table_model.cell_text(1, column) for column in range(2)],
            ["3", "4"],
        )
        self.controller.undo()
        self.assertEqual(
            [self.table.table_model.cell_text(1, column) for column in range(2)],
            ["1", "2"],
        )

        self.table.setCurrentIndex(self.table.table_model.index(1, 1))
        self.assertTrue(self.controller.paste_text("5\t6"))
        self.assertIsInstance(
            self.controller.history.undo_stack[-1],
            StructureSnapshotEdit,
        )

    def test_group_rename_stores_header_and_manual_order_as_one_block(self):
        self.current_settings.manual_group_order = ["A"]
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.controller.reset_history()

        def rename():
            self.table.table_model.set_cell_text(0, 0, "Renamed\nGroup")
            self.current_settings.manual_group_order = ["Renamed\nGroup"]
            return True

        self.controller.run_block_mutation([(0, 0)], rename)
        command = self.controller.history.undo_stack[-1]

        self.assertIsInstance(command, BlockEdit)
        self.controller.undo()
        self.assertEqual(self.table.table_model.cell_text(0, 0), "A")
        self.assertEqual(self.current_settings.manual_group_order, ["A"])
        self.controller.redo()
        self.assertEqual(self.table.table_model.cell_text(0, 0), "Renamed\nGroup")
        self.assertEqual(
            self.current_settings.manual_group_order,
            ["Renamed\nGroup"],
        )

    def test_settings_only_mutation_uses_settings_edit(self):
        self.current_settings.custom_overlay_series = [
            {"name": "Old", "values": {"A": "1"}}
        ]
        self.controller.set_dataframe(
            pd.DataFrame({"A": ["1"]}),
            self.current_settings.custom_overlay_series,
        )
        self.controller.reset_history()

        self.controller.run_settings_mutation(
            lambda: self.current_settings.custom_overlay_series[0].update(name="New")
        )

        self.assertIsInstance(
            self.controller.history.undo_stack[-1],
            SettingsEdit,
        )
        self.controller.undo()
        self.assertEqual(self.current_settings.custom_overlay_series[0]["name"], "Old")
        self.controller.redo()
        self.assertEqual(self.current_settings.custom_overlay_series[0]["name"], "New")

    def test_row_and_column_mutations_return_indexes_and_record_history(self):
        self.controller.set_dataframe(pd.DataFrame({"A": ["1"]}))
        self.controller.reset_history()
        self.assertEqual(self.controller.add_sample_row(), 2)
        self.assertEqual(self.controller.add_group_column(), 1)
        self.table.setCurrentIndex(self.table.table_model.index(0, 1))
        self.assertTrue(self.controller.delete_group_column())
        self.assertEqual(self.table.table_model.columnCount(), 1)
        self.assertEqual(len(self.controller.history.undo_stack), 3)
        self.assertEqual(self.render.call_count, 3)

    def test_xy_mode_hides_overlay_rows_and_keeps_column_ids_atomic_with_history(self):
        sheet = SheetDocument(
            name="XY",
            dataframe=pd.DataFrame({"X": ["1"], "Y": ["2"]}),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=XYSettings(
                default_x_column_id="x",
                series=[XYSeriesSpec(id="series", name="Y", y_column_id="y")],
            ),
        )
        sheet.settings.custom_overlay_series = [
            {"name": "Must not appear", "values": {"X": "9"}}
        ]
        controller = TableController(
            table=self.table,
            settings=lambda: sheet.settings,
            sheet=lambda: sheet,
            hooks=TableControllerHooks(
                render=self.render,
                update_history_actions=self.update_history_actions,
                update_dependent_controls=self.update_dependent_controls,
                sync_overlay_controls=self.sync_overlay_controls,
            ),
        )
        controller.set_dataframe(sheet.dataframe, sheet.settings.custom_overlay_series)
        controller.reset_history()

        self.assertEqual(controller.overlay_row_count(), 0)
        self.assertEqual(controller.sample_start_row(), 1)
        self.assertEqual(controller.overlay_series_from_table(), [])
        self.assertEqual(self.table.table_model.rowCount(), 2)
        self.assertEqual(self.table.table_model.headerData(0, Qt.Horizontal), "X")
        self.assertEqual(self.table.table_model.headerData(1, Qt.Horizontal), "1Y")
        self.assertEqual(
            self.table.table_model.headerData(0, Qt.Horizontal, Qt.ToolTipRole),
            "Matches: 1Y",
        )

        self.assertEqual(controller.add_group_column(), 2)
        added_column_id = sheet.column_ids[2]
        self.assertNotIn(added_column_id, {"x", "y"})
        self.assertEqual(self.table.table_model.cell_text(0, 2), "Column 3")
        self.table.setCurrentIndex(self.table.table_model.index(0, 0))
        self.assertTrue(controller.delete_group_column())
        self.assertEqual(sheet.column_ids, ["y", added_column_id])
        self.assertEqual(sheet.xy_settings.series, [])

        controller.undo()
        self.assertEqual(sheet.column_ids, ["x", "y", added_column_id])
        self.assertEqual([series.id for series in sheet.xy_settings.series], ["series"])
        controller.redo()
        self.assertEqual(sheet.column_ids, ["y", added_column_id])
        self.assertEqual(sheet.xy_settings.series, [])

    def test_delete_noop_and_module_dependency_boundary(self):
        self.table.table_model.resize(0, 0)
        self.controller.reset_history()
        self.assertFalse(self.controller.delete_group_column())
        self.assertEqual(self.controller.history.undo_stack, [])
        source = Path(table_controller.__file__).read_text(encoding="utf-8")
        tree = ast.parse(source)
        imported_modules = {
            node.module
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module is not None
        }
        imported_modules.update(
            alias.name
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        )
        for forbidden in (
            "app",
            "matplotlib",
            "seaborn",
            "scipy",
            "ui_main_window",
            "project_io",
            "spreadsheet_io",
            "template_io",
        ):
            with self.subTest(forbidden=forbidden):
                self.assertFalse(any(forbidden in module.split(".") for module in imported_modules))
