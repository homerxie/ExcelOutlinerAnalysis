import math
import json
import pathlib
import tempfile
import unittest
from dataclasses import asdict
from types import SimpleNamespace
from unittest import mock

import numpy as np
import pandas as pd
from matplotlib.transforms import Bbox
from PySide6.QtCore import QEvent, QPoint, Qt, qInstallMessageHandler
from PySide6.QtGui import QColor, QFont, QFontDatabase, QKeyEvent, QKeySequence, QPalette
from PySide6.QtTest import QTest
from PySide6.QtWidgets import (
    QAbstractButton,
    QAbstractSpinBox,
    QApplication,
    QComboBox,
    QDialogButtonBox,
    QFormLayout,
    QFrame,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMenu,
    QMenuBar,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QStyle,
    QStyleOptionSpinBox,
    QStyleOptionViewItem,
    QVBoxLayout,
)

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph import (
    app_theme,
    data,
    overlay_series,
    palette,
    project_io,
    template_io,
)
from easygraph.plotting import canvas as plotting_canvas
from easygraph.plotting import layout, overlay_renderer
from easygraph.settings import (
    ChartSettings,
    LEGEND_INSIDE_AUTO_POSITION,
    LEGEND_POSITION_INSIDE,
    LEGEND_POSITION_RIGHT,
    LINE_OVERLAY_STYLES,
)
from easygraph.ui.dialogs import GroupColorSelection, OverlayStyleSelection
from easygraph.ui.line_style_delegate import LineStyleItemDelegate
from easygraph.ui import main_window
from easygraph.workbook import SHEET_MODE_GROUPS, SHEET_MODE_XY
from easygraph.xy_series import XYSeriesSpec
from easygraph.xy_data import prepare_xy_data


class EasyGraphCoreTests(EasyGraphQtTestCase):

    def test_new_menus_offer_groups_and_xy_for_projects_and_sheets(self):
        window = main_window.MainWindow(initial_render=False, defer_preview=True)
        self.addCleanup(window.close)

        self.assertEqual(
            [action.text() for action in window._new_project_menu.actions()],
            ["Groups", "XY"],
        )
        self.assertFalse(hasattr(window.ui, "addSheetButton"))
        sheet_menu = QMenu(window)
        window._populate_sheet_menu(sheet_menu, 0)
        self.assertEqual(sheet_menu.actions()[0].text(), "New")
        self.assertEqual(
            [action.text() for action in sheet_menu.actions()[0].menu().actions()],
            ["Groups", "XY"],
        )

    def test_new_xy_sheet_and_project_create_default_shared_x_mapping(self):
        window = main_window.MainWindow(initial_render=False, defer_preview=True)
        self.addCleanup(window.close)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        sheet = window.workbook.active_sheet
        self.assertEqual(sheet.mode, SHEET_MODE_XY)
        self.assertEqual(
            list(sheet.dataframe.columns),
            ["X", "1Y", "2Y", "1X", "1Y", "2X", "2Y"],
        )
        self.assertEqual(sheet.xy_settings.default_x_column_id, sheet.column_ids[0])
        self.assertEqual(
            [series.y_column_id for series in sheet.xy_settings.series],
            [
                sheet.column_ids[1],
                sheet.column_ids[2],
                sheet.column_ids[4],
                sheet.column_ids[6],
            ],
        )
        self.assertEqual(sheet.dataframe.shape[0], 10)
        self.assertEqual(len(sheet.xy_settings.paired_series_ids), 2)
        self.assertEqual(
            [table.name for table in sheet.xy_settings.shared_tables], ["Sheet1"]
        )
        self.assertTrue(sheet.xy_settings.show_points)
        self.assertTrue(sheet.xy_settings.show_line)

        with mock.patch.object(window, "render"), mock.patch.object(
            window, "_confirm_unsaved_changes", return_value=True
        ):
            window.new_project(SHEET_MODE_XY)
        self.assertEqual(len(window.workbook.sheets), 1)
        self.assertEqual(window.workbook.active_sheet.mode, SHEET_MODE_XY)
        self.assertEqual(window.workbook.active_sheet.settings.chart_type, "Scatter")

        with mock.patch.object(window, "render"), mock.patch.object(
            window, "_confirm_unsaved_changes", return_value=True
        ):
            window.new_project(SHEET_MODE_GROUPS)
        self.assertEqual(window.workbook.active_sheet.mode, SHEET_MODE_GROUPS)

    def test_xy_sheet_uses_scatter_specific_toolbar_and_inspector(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        self.assertEqual(window.group_filter_button.text(), "Series Filter")
        self.assertEqual(window.edit_group_colors_button.text(), "Colors")
        self.assertFalse(window.ui.toolbarOrderLabel.pixmap().isNull())
        self.assertEqual(window.ui.toolbarOrderLabel.toolTip(), "Order")
        self.assertEqual(window.ui.editGroupOrderButton.text(), "Edit")
        self.assertEqual(
            [window.chart_type.itemText(index) for index in range(window.chart_type.count())],
            ["XY"],
        )
        self.assertFalse(window.chart_type.isEnabled())
        self.assertEqual(window.settings.chart_type, "Scatter")
        self.assertEqual(window.ui.pointsGroup.title(), "Series Style")
        self.assertEqual(
            window.ui.templateToolbarLabel.text(),
            "XY Style Templates",
        )
        self.assertEqual(
            window.ui.templateToolbarLabel.toolTip(),
            "Templates available for XY sheets",
        )
        self.assertEqual(window.ui.xLabelLabel.text(), "X axis title")
        self.assertEqual(window.ui.yLabelLabel.text(), "Y axis title")
        self.assertEqual(window.ui.primaryAxisGroup.title(), "Y Axis")

        for group in (
            window.ui.outliersGroup,
            window.ui.lineOverlayGroup,
            window.ui.statsTableGroup,
            window.ui.specificGroup,
            window.ui.secondaryAxisGroup,
        ):
            self.assertTrue(group.isHidden(), group.objectName())
        for group in (
            window.ui.titleAxisGroup,
            window.ui.categoryAxisGroup,
            window.ui.primaryAxisGroup,
            window.ui.axesAppearanceGroup,
            window.ui.pointsGroup,
            window.legend_group,
        ):
            self.assertFalse(group.isHidden(), group.objectName())

        self.assertTrue(window.ui.jitterModeLabel.isHidden())
        self.assertTrue(window.ui.jitterLabel.isHidden())
        self.assertFalse(window.ui.xyMarkerLabel.isHidden())
        self.assertFalse(window.ui.xyShowLineLabel.isHidden())
        self.assertFalse(window.ui.xyLineWidthLabel.isHidden())
        self.assertFalse(window.ui.xyLineStyleLabel.isHidden())
        self.assertTrue(window.ui.xRotationLabel.isHidden())
        self.assertTrue(window.x_tick_rotation.isHidden())
        self.assertTrue(window.add_overlay_button.isHidden())
        self.assertTrue(window.remove_overlay_button.isHidden())
        self.assertTrue(window.ui.copyStatisticsButton.isHidden())
        self.assertFalse(window.width.isHidden())
        self.assertFalse(window.height.isHidden())
        self.assertFalse(window.transparent_background.isHidden())
        self.assertFalse(window.legend_group.isHidden())
        self.assertFalse(window.ui.xySharedTitleLabel.isHidden())
        self.assertFalse(window.ui.xyIndependentTitleLabel.isHidden())
        self.assertTrue(window.ui.resultsTitleLabel.isHidden())
        self.assertTrue(window.results_table.isHidden())
        self.assertEqual(window.ui.xySharedTitleLabel.text(), "Shared X")
        self.assertEqual(window.ui.xyIndependentTitleLabel.text(), "Independent XY")
        self.assertEqual(
            window.ui.xySharedFrame.frameShape(), QFrame.Shape.StyledPanel
        )
        self.assertEqual(
            window.ui.xyIndependentFrame.frameShape(), QFrame.Shape.StyledPanel
        )
        self.assertNotIsInstance(window.ui.dataPanel, QFrame)
        self.assertEqual(
            (
                window.ui.dataLayout.contentsMargins().left(),
                window.ui.dataLayout.contentsMargins().top(),
                window.ui.dataLayout.contentsMargins().right(),
                window.ui.dataLayout.contentsMargins().bottom(),
            ),
            (0, 0, 0, 0),
        )
        self.assertFalse(hasattr(window.ui, "xySharedHeader"))
        self.assertIs(
            window.ui.xySharedTitleLabel.parentWidget(), window.ui.xySharedFrame
        )
        self.assertIs(
            window.ui.xyIndependentTitleLabel.parentWidget(),
            window.ui.xyIndependentFrame,
        )
        self.assertFalse(window.ui.xySharedTabBar.drawBase())
        self.assertEqual(
            window.ui.dataResultsSplitter.indexOf(window.ui.xyIndependentFrame), 0
        )
        self.assertEqual(
            window.ui.dataResultsSplitter.indexOf(window.ui.xySharedFrame), 1
        )
        splitter_sizes = window.ui.dataResultsSplitter.sizes()
        self.assertLessEqual(abs(splitter_sizes[0] - splitter_sizes[1]), 1)
        self.assertTrue(window.ui.dataResultsSplitter.isCollapsible(0))
        self.assertTrue(window.ui.dataResultsSplitter.isCollapsible(1))
        window.ui.dataResultsSplitter.setSizes([0, 600])
        self.assertEqual(window.ui.dataResultsSplitter.sizes()[0], 0)
        window.ui.dataResultsSplitter.setSizes([600, 0])
        self.assertEqual(window.ui.dataResultsSplitter.sizes()[1], 0)
        self.assertFalse(window.xy_independent_table.isHidden())
        self.assertFalse(hasattr(window.ui, "addRowButton"))
        self.assertFalse(hasattr(window.ui, "addColumnButton"))
        self.assertFalse(hasattr(window.ui, "deleteColumnButton"))

    def test_xy_workspace_combines_shared_tabs_and_independent_pairs(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        self.assertEqual(window.ui.xySharedTabBar.count(), 1)
        self.assertEqual(window.ui.xySharedTabBar.tabText(0), "Sheet1")
        self.assertEqual(
            [
                window.table.table_model.headerData(column, Qt.Horizontal)
                for column in range(window.table.table_model.columnCount())
            ],
            ["X", "1Y", "2Y"],
        )
        self.assertEqual(
            [
                window.xy_independent_table.table_model.headerData(column, Qt.Horizontal)
                for column in range(window.xy_independent_table.table_model.columnCount())
            ],
            ["1X", "1Y", "2X", "2Y"],
        )
        self.assertEqual(window.table.table_model.rowCount(), 11)
        self.assertEqual(window.xy_independent_table.table_model.rowCount(), 11)

        window.table.table_model.set_cell_text(1, 0, "1")
        window.table.table_model.set_cell_text(1, 1, "10")
        with mock.patch.object(window, "render"):
            window.add_xy_shared_table()
        self.assertEqual(window.ui.xySharedTabBar.count(), 2)
        self.assertEqual(window.table.table_model.columnCount(), 3)
        self.assertEqual(
            len(window.workbook.active_sheet.xy_settings.shared_tables[1].series_ids),
            2,
        )
        self.assertEqual(
            [window.ui.xySharedTabBar.tabText(index) for index in range(2)],
            ["Sheet1", "Sheet2"],
        )

        window.table.table_model.set_cell_text(1, 0, "2")
        window.table.table_model.set_cell_text(1, 1, "20")
        with mock.patch.object(window, "render"):
            window.add_xy_pair()
        window.xy_independent_table.table_model.set_cell_text(1, 0, "3")
        window.xy_independent_table.table_model.set_cell_text(1, 1, "30")

        prepared = prepare_xy_data(
            window.table_dataframe(),
            window.workbook.active_sheet.column_ids,
            window.workbook.active_sheet.xy_settings,
        )

        numeric = {
            series.id: (series.x.tolist(), series.y.tolist())
            for series in prepared.visible_numeric_series
        }
        self.assertEqual(len(numeric), 3)
        self.assertIn(([1.0], [10.0]), numeric.values())
        self.assertIn(([2.0], [20.0]), numeric.values())
        self.assertIn(([3.0], [30.0]), numeric.values())

    def test_deleting_shared_x_tab_selects_its_nearest_neighbor(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
            window.add_xy_shared_table()
            window.add_xy_shared_table()
            window.add_xy_shared_table()

        window.ui.xySharedTabBar.setCurrentIndex(2)
        with mock.patch.object(
            QMessageBox, "question", return_value=QMessageBox.Yes
        ), mock.patch.object(window, "render"):
            window.remove_xy_shared_table()

        self.assertEqual(
            [
                window.ui.xySharedTabBar.tabText(index)
                for index in range(window.ui.xySharedTabBar.count())
            ],
            ["Sheet1", "Sheet2", "Sheet4"],
        )
        self.assertEqual(window.ui.xySharedTabBar.currentIndex(), 2)
        self.assertEqual(
            window.ui.xySharedTabBar.tabText(
                window.ui.xySharedTabBar.currentIndex()
            ),
            "Sheet4",
        )

        with mock.patch.object(
            QMessageBox, "question", return_value=QMessageBox.Yes
        ), mock.patch.object(window, "render"):
            window.remove_xy_shared_table()

        self.assertEqual(window.ui.xySharedTabBar.currentIndex(), 1)
        self.assertEqual(
            window.ui.xySharedTabBar.tabText(
                window.ui.xySharedTabBar.currentIndex()
            ),
            "Sheet2",
        )

    def test_xy_tables_auto_add_a_trailing_row_y_and_pair(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        window.table.table_model.set_cell_text(1, 1, "10")
        QApplication.processEvents()
        self.assertEqual(window.table.table_model.columnCount(), 3)

        window.xy_independent_table.table_model.set_cell_text(1, 0, "1")
        window.xy_independent_table.table_model.set_cell_text(1, 1, "20")
        QApplication.processEvents()
        self.assertEqual(window.xy_independent_table.table_model.columnCount(), 4)

        last_row = window.table.table_model.rowCount() - 1
        window.table.table_model.set_cell_text(last_row, 0, "9")
        QApplication.processEvents()
        self.assertEqual(window.table.table_model.rowCount(), 12)
        self.assertEqual(
            window.table.table_model.cell_text(11, 0),
            "",
        )

    def test_xy_context_menu_inserts_before_selected_series_or_pair(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        settings = window.workbook.active_sheet.xy_settings

        original_y_ids = list(settings.shared_tables[0].series_ids)
        window.table.setCurrentIndex(window.table.table_model.index(1, 1))
        with mock.patch.object(window, "render"):
            window.insert_xy_y_before_selection()
        self.assertEqual(settings.shared_tables[0].series_ids[1:], original_y_ids)
        self.assertEqual(
            [window.table.table_model.cell_text(0, column) for column in range(4)],
            ["X", "1Y", "2Y", "3Y"],
        )
        with mock.patch.object(window, "render"):
            window.delete_column()
        self.assertEqual(settings.shared_tables[0].series_ids, original_y_ids)

        original_pair_ids = list(settings.paired_series_ids)
        window.xy_independent_table.setCurrentIndex(
            window.xy_independent_table.table_model.index(1, 0)
        )
        with mock.patch.object(window, "render"):
            window.insert_xy_pair_before_selection()
        self.assertEqual(settings.paired_series_ids[1:], original_pair_ids)
        self.assertEqual(
            [
                window.xy_independent_table.table_model.cell_text(0, column)
                for column in range(6)
            ],
            ["1X", "1Y", "2X", "2Y", "3X", "3Y"],
        )
        with mock.patch.object(window, "render"):
            window.remove_xy_pair()
        self.assertEqual(settings.paired_series_ids, original_pair_ids)

        shared_actions = [action.text() for action in window.table_context_menu().actions()]
        paired_actions = [
            action.text()
            for action in window.table_context_menu(window.xy_independent_table).actions()
        ]
        self.assertIn("Insert", shared_actions)
        self.assertIn("Delete", shared_actions)
        self.assertIn("Clear Contents", shared_actions)
        self.assertIn("Insert", paired_actions)
        self.assertIn("Delete", paired_actions)
        self.assertIn("Clear Contents", paired_actions)

    def test_xy_first_row_double_click_uses_multiline_rename_dialog(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        window.show()
        QApplication.processEvents()

        with mock.patch.object(
            QInputDialog,
            "getMultiLineText",
            return_value=("Dose\nresponse", True),
        ) as dialog:
            window.table.horizontalHeader().sectionDoubleClicked.emit(1)
            dialog.assert_not_called()
            position = window.table.visualRect(
                window.table.table_model.index(0, 1)
            ).center()
            QTest.mouseDClick(
                window.table.viewport(),
                Qt.MouseButton.LeftButton,
                pos=position,
            )

        self.assertEqual(window.table.table_model.cell_text(0, 1), "Dose\nresponse")
        dialog.assert_called_once()

    def test_xy_global_point_and_line_style_round_trips_through_controls(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        xy = window.workbook.active_sheet.xy_settings
        xy.show_points = False
        xy.show_line = True
        xy.point_size = 7.5
        xy.point_alpha = 0.55
        xy.marker = "Diamond"
        xy.line_width = 2.4
        xy.line_style = "Dashed"

        window.apply_settings_to_controls()

        self.assertFalse(window.show_points.isChecked())
        self.assertTrue(window.xy_show_line.isChecked())
        self.assertEqual(window.point_size.value(), 7.5)
        self.assertEqual(window.point_alpha.value(), 0.55)
        self.assertEqual(window.xy_marker.currentText(), "Diamond")
        self.assertEqual(window.xy_line_width.value(), 2.4)
        self.assertEqual(window.xy_line_style.currentText(), "Dashed")

        window._applying_settings = True
        try:
            window.show_points.setChecked(True)
            window.xy_show_line.setChecked(False)
            window.point_size.setValue(6.0)
            window.point_alpha.setValue(0.8)
            window.xy_marker.setCurrentText("Square")
            window.xy_line_width.setValue(3.2)
            window.xy_line_style.setCurrentText("Dotted")
        finally:
            window._applying_settings = False
        with mock.patch.object(window, "schedule_render"):
            window.update_settings()

        self.assertTrue(xy.show_points)
        self.assertFalse(xy.show_line)
        self.assertEqual(xy.point_size, 6.0)
        self.assertEqual(xy.point_alpha, 0.8)
        self.assertEqual(xy.marker, "Square")
        self.assertEqual(xy.line_width, 3.2)
        self.assertEqual(xy.line_style, "Dotted")

        window._applying_settings = True
        try:
            window.show_points.setChecked(False)
            window.xy_show_line.setChecked(False)
        finally:
            window._applying_settings = False
        with mock.patch.object(window, "schedule_render"):
            window.update_settings()
        self.assertTrue(window.xy_show_line.isChecked())
        self.assertFalse(xy.show_points)
        self.assertTrue(xy.show_line)

    def test_switching_back_to_groups_restores_distribution_controls(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
            window.switch_sheet(0)

        self.assertEqual(window.workbook.active_sheet.mode, SHEET_MODE_GROUPS)
        self.assertEqual(window.group_filter_button.text(), "Group Filter")
        self.assertEqual(
            window.ui.templateToolbarLabel.text(),
            "Groups Style Templates",
        )
        self.assertEqual(
            window.ui.templateToolbarLabel.toolTip(),
            "Templates available for Groups sheets",
        )
        self.assertEqual(window.ui.editGroupOrderButton.text(), "Edit")
        self.assertEqual(
            [window.chart_type.itemText(index) for index in range(window.chart_type.count())],
            ["Box", "Bar", "Violin", "Ridge"],
        )
        self.assertFalse(window.ui.outliersGroup.isHidden())
        self.assertFalse(window.ui.lineOverlayGroup.isHidden())
        self.assertFalse(window.ui.statsTableGroup.isHidden())
        self.assertFalse(window.ui.specificGroup.isHidden())
        self.assertFalse(window.ui.secondaryAxisGroup.isHidden())
        self.assertFalse(window.ui.jitterModeLabel.isHidden())
        self.assertFalse(window.ui.jitterLabel.isHidden())
        self.assertTrue(window.ui.xyMarkerLabel.isHidden())
        self.assertTrue(window.ui.xyShowLineLabel.isHidden())
        self.assertTrue(window.ui.xyLineWidthLabel.isHidden())
        self.assertTrue(window.ui.xyLineStyleLabel.isHidden())
        self.assertFalse(window.ui.xRotationLabel.isHidden())
        self.assertFalse(window.x_tick_rotation.isHidden())
        self.assertFalse(window.add_overlay_button.isHidden())
        self.assertFalse(window.ui.copyStatisticsButton.isHidden())
        self.assertEqual(window.ui.xySharedFrame.frameShape(), QFrame.Shape.NoFrame)
        self.assertEqual(
            window.ui.xyIndependentFrame.frameShape(), QFrame.Shape.NoFrame
        )
        self.assertEqual(
            window.ui.dataResultsSplitter.indexOf(window.ui.xySharedFrame), 0
        )
        self.assertEqual(
            window.ui.dataResultsSplitter.indexOf(window.ui.xyIndependentFrame), 1
        )

    def test_xy_series_filter_uses_series_ids_without_changing_mappings(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        xy = window.workbook.active_sheet.xy_settings
        series_by_id = {series.id: series for series in xy.series}
        first = series_by_id[xy.shared_tables[0].series_ids[0]]
        second = series_by_id[xy.paired_series_ids[0]]
        first.name = "Dose"
        second.name = "Dose"
        original_mapping = [
            (series.id, series.x_column_id, series.y_column_id)
            for series in xy.series
        ]

        def choose(_parent, title, items, hidden):
            self.assertEqual(title, "Series Filter")
            self.assertEqual([item.key for item in items], [first.id, second.id])
            self.assertEqual(
                [item.label for item in items],
                ["Dose · Sheet1 / 1Y", "Dose · Independent XY · Pair 1"],
            )
            self.assertEqual(hidden, set())
            return [second.id]

        with mock.patch.object(main_window, "run_checklist_filter_dialog", side_effect=choose), \
             mock.patch.object(window, "render") as render:
            window.edit_group_filter()

        updated_xy = window.workbook.active_sheet.xy_settings
        updated_by_id = {series.id: series for series in updated_xy.series}
        self.assertTrue(updated_by_id[first.id].visible)
        self.assertFalse(updated_by_id[second.id].visible)
        self.assertTrue(
            all(
                series.visible
                for series in updated_xy.series
                if series.id not in {first.id, second.id}
            )
        )
        self.assertEqual(
            [
                (series.id, series.x_column_id, series.y_column_id)
                for series in updated_xy.series
            ],
            original_mapping,
        )
        render.assert_called_once_with()

    def test_xy_series_filter_atomically_restores_a_valid_hidden_series(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        xy = window.workbook.active_sheet.xy_settings
        xy.show_points = False
        xy.show_line = True
        hidden = XYSeriesSpec(
            id="hidden",
            name="Hidden",
            y_column_id="hidden-y",
            visible=False,
            show_points=False,
            show_line=False,
            marker="Diamond",
            point_size=7.0,
        )
        xy.series = [hidden]

        with mock.patch.object(
            main_window,
            "run_checklist_filter_dialog",
            return_value=[],
        ), mock.patch.object(window, "render") as render:
            window.edit_group_filter()

        restored = window.workbook.active_sheet.xy_settings.series[0]
        self.assertIsNot(restored, hidden)
        self.assertFalse(hidden.visible)
        self.assertTrue(restored.visible)
        self.assertFalse(restored.show_points)
        self.assertIsNone(restored.show_line)
        self.assertEqual(restored.marker, "Diamond")
        self.assertEqual(restored.point_size, 7.0)
        window.workbook.active_sheet.xy_settings.__post_init__()
        render.assert_called_once_with()

    def test_xy_colors_use_series_ids_and_cancel_restores_preview(self):
        window = self.make_window(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        xy = window.workbook.active_sheet.xy_settings
        series_by_id = {series.id: series for series in xy.series}
        first = series_by_id[xy.shared_tables[0].series_ids[0]]
        second = series_by_id[xy.paired_series_ids[0]]
        first.name = second.name = "Dose"
        first.color = "#112233"
        original_preset = window.settings.preset
        accepted = GroupColorSelection(
            preset="Presentation",
            custom_colors={second.id: "#445566"},
            overlay_palette=window.settings.custom_overlay_palette,
            overlay_colors={},
        )

        def accept(_parent, _settings, keys, overlays, preview, _polish, **kwargs):
            self.assertEqual(keys, [first.id, second.id])
            self.assertEqual(overlays, [])
            self.assertEqual(
                kwargs["item_labels"],
                {
                    first.id: "Dose · Sheet1 / 1Y",
                    second.id: "Dose · Independent XY · Pair 1",
                },
            )
            preview(accepted)
            return accepted

        with mock.patch.object(main_window, "run_group_colors_dialog", side_effect=accept), \
             mock.patch.object(window, "render") as render:
            window.edit_group_colors()
            window.flush_pending_render()

        self.assertEqual(window.settings.preset, "Presentation")
        self.assertIsNone(first.color)
        self.assertEqual(second.color, "#445566")
        render.assert_called_once_with()

        preview = GroupColorSelection(
            preset="Colorblind Safe",
            custom_colors={first.id: "#abcdef"},
            overlay_palette=window.settings.custom_overlay_palette,
            overlay_colors={},
        )

        def cancel(_parent, _settings, _keys, _overlays, apply_preview, _polish, **_kwargs):
            apply_preview(preview)
            return None

        with mock.patch.object(main_window, "run_group_colors_dialog", side_effect=cancel), \
             mock.patch.object(window, "render"):
            window.edit_group_colors()
            window.flush_pending_render()

        self.assertEqual(window.settings.preset, "Presentation")
        self.assertIsNone(first.color)
        self.assertEqual(second.color, "#445566")
        self.assertNotEqual(window.settings.preset, original_preset)

    def test_xy_order_options_omit_distribution_statistics(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        self.assertEqual(
            [window.group_order.itemText(index) for index in range(window.group_order.count())],
            ["Table order", "Manual", "Name A-Z", "Name Z-A"],
        )
        self.assertNotIn("Mean ascending", [
            window.group_order.itemText(index)
            for index in range(window.group_order.count())
        ])

    def test_xy_workspace_hides_distribution_analysis_results(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        self.assertTrue(window.results_table.isHidden())
        self.assertTrue(window.ui.resultsTitleLabel.isHidden())
        self.assertFalse(window.xy_independent_table.isHidden())

    def test_main_window_title_includes_the_release_version(self):
        window = main_window.MainWindow(initial_render=False, defer_preview=True)
        self.addCleanup(window.close)

        self.assertEqual(window.windowTitle(), "EasyGraph v2.0")

    def test_main_window_can_skip_initial_render(self):
        with mock.patch.object(main_window.MainWindow, "render") as render, mock.patch.object(
            main_window.MainWindow, "_fit_initial_plot_to_viewport"
        ) as fit_initial_plot_to_viewport:
            window = main_window.MainWindow(initial_render=False)
            self.addCleanup(window.close)

        render.assert_not_called()
        fit_initial_plot_to_viewport.assert_not_called()

    def test_deferred_preview_creates_and_renders_one_canvas_after_event_loop(self):
        with mock.patch.object(
            plotting_canvas,
            "PlotCanvas",
            wraps=plotting_canvas.PlotCanvas,
        ) as plot_canvas:
            window = main_window.MainWindow(defer_preview=True)
            self.addCleanup(window.close)
            self.assertIsNone(window.canvas)
            self.assertIsNotNone(window._plot_placeholder)

            self.qapp.processEvents()
            self.qapp.processEvents()

        plot_canvas.assert_called_once_with()
        self.assertIsInstance(window.canvas, plotting_canvas.PlotCanvas)
        self.assertIsNone(window._plot_placeholder)
        self.assertTrue(hasattr(window.canvas, "_last_settings"))

    def test_deferred_preview_without_initial_render_waits_for_explicit_initialization(self):
        window = main_window.MainWindow(initial_render=False, defer_preview=True)
        self.addCleanup(window.close)

        self.qapp.processEvents()

        self.assertIsNone(window.canvas)
        window.initialize_preview(initial_render=False)
        self.assertIsInstance(window.canvas, plotting_canvas.PlotCanvas)
        self.assertIs(
            window.canvas.chart_elements_button.menu(),
            window.chart_elements_menu,
        )
        self.assertFalse(hasattr(window.canvas, "_last_settings"))

    def test_apply_app_theme_uses_pyqtdarktheme_stylesheet(self):
        original_qdarktheme = app_theme.qdarktheme

        class FakeDarkTheme:
            @staticmethod
            def load_stylesheet(theme="dark"):
                color = "#ffffff" if theme == "light" else "#111111"
                return f"QWidget {{ background: {color}; }}"

        configure_icon_patcher = mock.patch.object(app_theme, "configure_application_icon")
        configure_icon = configure_icon_patcher.start()
        try:
            app_theme.qdarktheme = FakeDarkTheme()
            self.assertTrue(app_theme.apply_app_theme(self.qapp, "dark"))
            self.assertIn("#111111", self.qapp.styleSheet())
            self.assertIn("QComboBox QAbstractItemView", self.qapp.styleSheet())
            self.assertIn("QSpinBox", self.qapp.styleSheet())
            self.assertIn("QPushButton", self.qapp.styleSheet())
            self.assertIn("QMenu", self.qapp.styleSheet())
            self.assertIn("QMenu::item", self.qapp.styleSheet())
            self.assertIn("QMenuBar::item:selected", app_theme.MENU_HIGHLIGHT_STYLE)
            self.assertIn(
                "QComboBox QAbstractItemView::item:selected",
                app_theme.MENU_HIGHLIGHT_STYLE,
            )
            self.assertNotIn("QComboBox::item {", app_theme.MENU_HIGHLIGHT_STYLE)
            self.assertIn(
                f"border-radius: {app_theme.MENU_HIGHLIGHT_RADIUS}px",
                app_theme.MENU_HIGHLIGHT_STYLE,
            )
            self.assertIn(
                "QMenu::item {\n"
                f"    border-radius: {app_theme.MENU_HIGHLIGHT_RADIUS}px",
                app_theme.APP_THEME_OVERRIDES,
            )
            self.assertIn("border-radius: 6px", self.qapp.styleSheet())
            self.assertTrue(app_theme.apply_app_theme(self.qapp, "light"))
            self.assertIn("#ffffff", self.qapp.styleSheet())
            self.assertIn("#E9EDF2", self.qapp.styleSheet())
            self.assertIn("plotPreviewScroll", self.qapp.styleSheet())
            self.assertIn("gridline-color: #C8D0D9", self.qapp.styleSheet())
            self.assertIn("dataTableHorizontalHeader", self.qapp.styleSheet())
            self.assertIn("border-radius: 0", self.qapp.styleSheet())
            self.assertIn("border-right: 1px solid #C8D0D9", self.qapp.styleSheet())
            self.assertIn("border-bottom: 1px solid #C8D0D9", self.qapp.styleSheet())
            self.assertIn("selection-background-color: #B5CAF4", self.qapp.styleSheet())
            self.assertIn("QWidget {\n    color: #000000;", self.qapp.styleSheet())
            self.assertIn(
                "QPushButton:enabled,\n"
                "QTabBar::tab:selected:enabled {\n"
                "    color: #0081DB;",
                self.qapp.styleSheet(),
            )
            self.assertIn("selection-color: #000000", self.qapp.styleSheet())
            self.assertNotIn("color: #3F4852", app_theme.THEME_COLOR_OVERRIDES["light"])
            self.assertNotIn("color: #5F6B78", app_theme.THEME_COLOR_OVERRIDES["light"])
            self.assertIn("QComboBox QAbstractItemView::item:!selected:hover", self.qapp.styleSheet())
            self.assertIn("QTableView#dataTable::item:selected:!active", self.qapp.styleSheet())
            self.assertIn("QComboBox::item:selected", self.qapp.styleSheet())
            self.assertIn("background: #D3D3D3", self.qapp.styleSheet())
            self.assertIn("background: #004875", app_theme.THEME_COLOR_OVERRIDES["dark"])
            self.assertEqual(
                configure_icon.call_args_list,
                [mock.call(self.qapp, "dark"), mock.call(self.qapp, "light")],
            )
        finally:
            configure_icon_patcher.stop()
            self.qapp.setStyleSheet("")
            app_theme.qdarktheme = original_qdarktheme

    def test_app_theme_module_owns_theme_helpers(self):
        for helper in (
            app_theme.apply_app_theme,
            app_theme.configure_qt_application_font,
            app_theme.configure_matplotlib_fonts,
        ):
            with self.subTest(helper=helper.__name__):
                self.assertEqual(helper.__module__, "easygraph.app_theme")
        self.assertGreater(app_theme.COMPACT_SPIN_TEXT_PADDING, 0)

    def test_light_theme_keeps_blue_actions_and_uses_black_body_text(self):
        original_stylesheet = self.qapp.styleSheet()
        self.addCleanup(self.qapp.setStyleSheet, original_stylesheet)
        app_theme.apply_app_theme(self.qapp, "light")
        label = QLabel("Body")
        button = QPushButton("Action")
        self.addCleanup(label.deleteLater)
        self.addCleanup(button.deleteLater)
        label.ensurePolished()
        button.ensurePolished()

        self.assertEqual(
            label.palette().color(QPalette.ColorRole.WindowText).name(),
            "#000000",
        )
        self.assertEqual(
            button.palette().color(QPalette.ColorRole.ButtonText).name(),
            "#0081db",
        )

    def test_menu_highlight_style_keeps_combo_popup_rows_compact(self):
        original_stylesheet = self.qapp.styleSheet()
        self.addCleanup(self.qapp.setStyleSheet, original_stylesheet)
        app_theme.apply_app_theme(self.qapp, "light")
        combo = QComboBox()
        combo.addItems(["Alpha", "Beta"])

        row_height = combo.view().sizeHintForRow(0)
        popup_margins = combo.view().contentsMargins()

        self.assertGreaterEqual(row_height, combo.fontMetrics().height())
        self.assertLess(row_height, combo.sizeHint().height() * 3)
        self.assertEqual(
            (
                popup_margins.left(),
                popup_margins.top(),
                popup_margins.right(),
                popup_margins.bottom(),
            ),
            (4, 4, 4, 4),
        )

    def test_configure_qt_application_font_uses_installed_family(self):
        selected = app_theme.configure_qt_application_font(self.qapp)

        self.assertIn(selected, QFontDatabase.families())
        self.assertNotEqual(selected, "Sans Serif")
        self.assertEqual(self.qapp.font().family(), selected)

    def test_windows_ui_font_preserves_native_size_across_theme_reapplication(self):
        original_font = QFont(self.qapp.font())
        original_base_font = self.qapp.property(app_theme.WINDOWS_BASE_FONT_PROPERTY)

        def restore_font() -> None:
            self.qapp.setFont(original_font)
            self.qapp.setProperty(
                app_theme.WINDOWS_BASE_FONT_PROPERTY,
                original_base_font,
            )

        self.addCleanup(restore_font)
        available = set(QFontDatabase.families())
        native_family = next(
            family
            for family in app_theme.QT_FONT_FAMILY_CANDIDATES
            if family in available
        )
        native_font = QFont(native_family)
        native_font.setPointSizeF(9.0)
        self.qapp.setFont(native_font)
        self.qapp.setProperty(app_theme.WINDOWS_BASE_FONT_PROPERTY, None)

        selected = app_theme.configure_qt_application_font(
            self.qapp,
            platform_name="win32",
        )

        self.assertEqual(selected, native_family)
        self.assertEqual(self.qapp.font().pointSizeF(), 9.0)

        oversized_font = QFont(native_family)
        oversized_font.setPointSizeF(12.0)
        self.qapp.setFont(oversized_font)
        app_theme.configure_qt_application_font(
            self.qapp,
            platform_name="win32",
        )

        self.assertEqual(self.qapp.font().pointSizeF(), 9.0)

    def test_theme_stylesheet_is_installed_before_application_font(self):
        events = []
        fake_app = SimpleNamespace(
            setStyleSheet=lambda _stylesheet: events.append("stylesheet")
        )
        fake_theme = SimpleNamespace(load_stylesheet=lambda _theme: "QWidget {}")

        with (
            mock.patch.object(app_theme, "qdarktheme", fake_theme),
            mock.patch.object(app_theme, "configure_application_icon"),
            mock.patch.object(
                app_theme,
                "configure_qt_application_font",
                side_effect=lambda _app: events.append("font"),
            ),
        ):
            app_theme.apply_app_theme(fake_app, "light")

        self.assertEqual(events, ["stylesheet", "font"])

    def test_windows_menu_and_widget_fonts_stay_native_across_theme_toggle(self):
        original_font = QFont(self.qapp.font())
        original_stylesheet = self.qapp.styleSheet()
        original_base_font = self.qapp.property(app_theme.WINDOWS_BASE_FONT_PROPERTY)

        def restore_theme_font() -> None:
            self.qapp.setStyleSheet(original_stylesheet)
            self.qapp.setFont(original_font)
            self.qapp.setProperty(
                app_theme.WINDOWS_BASE_FONT_PROPERTY,
                original_base_font,
            )

        self.addCleanup(restore_theme_font)
        available = set(QFontDatabase.families())
        native_family = next(
            family
            for family in app_theme.QT_FONT_FAMILY_CANDIDATES
            if family in available
        )
        native_font = QFont(native_family)
        native_font.setPointSizeF(9.0)
        self.qapp.setFont(native_font)
        self.qapp.setProperty(app_theme.WINDOWS_BASE_FONT_PROPERTY, None)

        with (
            mock.patch.object(app_theme.sys, "platform", "win32"),
            mock.patch.object(app_theme, "configure_application_icon"),
        ):
            app_theme.apply_app_theme(self.qapp, "dark")
            menu_bar = QMenuBar()
            label = QLabel("Label")
            self.addCleanup(menu_bar.deleteLater)
            self.addCleanup(label.deleteLater)

            self.assertEqual(menu_bar.font().pointSizeF(), 9.0)
            self.assertEqual(label.font().pointSizeF(), 9.0)

            app_theme.apply_app_theme(self.qapp, "light")

            self.assertEqual(menu_bar.font().pointSizeF(), 9.0)
            self.assertEqual(label.font().pointSizeF(), 9.0)
            self.assertEqual(menu_bar.font().pointSizeF(), label.font().pointSizeF())

    def test_windows_ui_font_fallback_prefers_native_segoe_then_chinese_ui(self):
        candidates = app_theme.QT_FONT_FAMILY_CANDIDATES

        self.assertEqual(candidates[:3], ["Segoe UI", "Microsoft YaHei UI", "Microsoft YaHei"])
        self.assertLess(candidates.index("Microsoft YaHei UI"), candidates.index("Arial"))

    def test_matplotlib_prefers_microsoft_yahei_for_chinese_chart_text(self):
        self.assertEqual(
            app_theme.MATPLOTLIB_FONT_FAMILY_CANDIDATES[:3],
            ["Microsoft YaHei", "Microsoft YaHei UI", "Segoe UI"],
        )

    def test_office_font_size_helper_lives_in_app_theme(self):
        self.assertEqual(
            app_theme.office_adjacent_font_size.__module__, "easygraph.app_theme"
        )
        self.assertEqual(app_theme.office_adjacent_font_size(16, 1, 5, 72), 18)
        self.assertEqual(app_theme.office_adjacent_font_size(12, -1, 5, 72), 11)
        self.assertEqual(app_theme.office_adjacent_font_size(72, 1, 5, 72), 72)
        self.assertEqual(app_theme.office_adjacent_font_size(5, -1, 5, 72), 5)

    def test_combo_boxes_expand_for_long_options(self):
        window = self.make_window()
        longest = "Exclude from distribution"
        expected_width = window.outlier_effect.fontMetrics().horizontalAdvance(longest) + main_window.COMBO_TEXT_WIDTH_PADDING

        self.assertEqual(window.template_combo.itemText(0), template_io.TEMPLATE_NONE_NAME)
        self.assertEqual(window.template_combo.currentText(), template_io.TEMPLATE_NONE_NAME)
        self.assertEqual(window.template_combo.sizePolicy().horizontalPolicy(), QSizePolicy.Expanding)
        self.assertEqual(window.outlier_effect.minimumWidth(), window.outlier_effect.maximumWidth())
        self.assertGreaterEqual(window.outlier_effect.minimumWidth(), expected_width)
        self.assertGreaterEqual(window.outlier_effect.view().minimumWidth(), expected_width)

    def test_settings_forms_align_labels_left_and_values_right(self):
        window = self.make_window()
        longest = "Exclude from distribution"
        expected_width = window.outlier_effect.fontMetrics().horizontalAdvance(longest) + main_window.COMBO_TEXT_WIDTH_PADDING
        expected_width = min(max(expected_width, main_window.COMBO_MIN_WIDTH), 280)
        field_layout = window.ui.outliersForm.itemAt(3, QFormLayout.FieldRole).layout()
        points_margins = window.ui.pointsForm.contentsMargins()
        outliers_margins = window.ui.outliersForm.contentsMargins()

        self.assertEqual(window.ui.pointsGroup.title(), "Data Points")
        self.assertEqual(window.ui.outliersGroup.title(), "Outliers")
        self.assertEqual(window.outlier_effect.width(), expected_width)
        self.assertEqual(points_margins.left(), 8)
        self.assertEqual(points_margins.right(), 8)
        self.assertEqual(outliers_margins.left(), 8)
        self.assertEqual(outliers_margins.right(), 8)
        self.assertEqual(window.ui.pointsForm.fieldGrowthPolicy(), QFormLayout.AllNonFixedFieldsGrow)
        self.assertEqual(window.ui.outliersForm.fieldGrowthPolicy(), QFormLayout.AllNonFixedFieldsGrow)
        self.assertEqual(field_layout.itemAt(1).widget(), window.outlier_effect)
        self.assertIsNone(field_layout.itemAt(0).widget())

    def test_all_right_sidebar_forms_wrap_long_rows(self):
        window = self.make_window()
        forms = (
            window.ui.titleAxisForm,
            window.ui.categoryAxisForm,
            window.ui.primaryAxisForm,
            window.ui.axesAppearanceForm,
            window.ui.secondaryAxisForm,
            window.ui.pointsForm,
            window.ui.outliersForm,
            window.ui.lineOverlayForm,
            window.ui.legendForm,
            window.ui.specificForm,
        )

        for form in forms:
            with self.subTest(form=form.objectName()):
                self.assertEqual(
                    form.rowWrapPolicy(),
                    QFormLayout.RowWrapPolicy.WrapLongRows,
                )

    def test_legend_layout_has_own_group_with_right_aligned_controls(self):
        window = self.make_window()

        self.assertEqual(window.legend_group.title(), "Legend")
        self.assertIs(window.legend_group, window.ui.legendGroup)
        self.assertIs(window.legend_form, window.ui.legendForm)
        self.assertIs(window.show_legend, window.ui.showLegendCheck)
        self.assertIs(window.legend_position, window.ui.legendPositionCombo)
        self.assertIs(window.legend_auto_width, window.ui.legendAutoWidthCheck)
        self.assertIs(window.legend_width, window.ui.legendWidthSpin)
        self.assertIs(window.legend_columns, window.ui.legendColumnsCombo)
        self.assertEqual(window.show_legend.parent(), window.legend_group)
        self.assertEqual(window.legend_position.parent(), window.legend_group)
        self.assertEqual(window.legend_auto_width.parent(), window.legend_group)
        self.assertEqual(window.legend_width.parent(), window.legend_group)
        self.assertEqual(window.legend_columns.parent(), window.legend_group)
        self.assertEqual(window.legend_font_size.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.decrease_all_fonts_button.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.increase_all_fonts_button.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.title_font_size.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.axis_label_font_size.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.tick_font_size.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.line_value_font_size.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.stat_table_font_size.parent(), window.ui.topToolbarWidget)
        self.assertTrue(window.show_legend.isChecked())
        self.assertTrue(window.settings.show_legend)
        self.assertTrue(window.legend_auto_width.isChecked())
        self.assertTrue(window.settings.legend_auto_width)
        self.assertEqual(window.legend_position.currentText(), "Right side")
        self.assertEqual(window.settings.legend_position, LEGEND_POSITION_RIGHT)
        self.assertEqual(window.legend_columns.currentText(), "1")
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 2).widget(), window.increase_all_fonts_button)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(2, 2).widget(), window.decrease_all_fonts_button)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 4).widget(), window.title_font_size)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 6).widget(), window.axis_label_font_size)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(2, 4).widget(), window.tick_font_size)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(2, 6).widget(), window.legend_font_size)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(3, 4).widget(), window.line_value_font_size)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(3, 6).widget(), window.stat_table_font_size)
        self.assertEqual(window.legend_form.fieldGrowthPolicy(), QFormLayout.AllNonFixedFieldsGrow)
        self.assertEqual(window.legend_form.contentsMargins().left(), 8)
        self.assertEqual(window.legend_form.contentsMargins().right(), 8)
        show_field = window.legend_form.itemAt(0, QFormLayout.FieldRole).layout()
        position_field = window.legend_form.itemAt(1, QFormLayout.FieldRole).layout()
        auto_width_field = window.legend_form.itemAt(2, QFormLayout.FieldRole).layout()
        width_field = window.legend_form.itemAt(3, QFormLayout.FieldRole).layout()
        columns_field = window.legend_form.itemAt(4, QFormLayout.FieldRole).layout()

        self.assertEqual(show_field.itemAt(1).widget(), window.show_legend)
        self.assertEqual(position_field.itemAt(1).widget(), window.legend_position)
        self.assertEqual(auto_width_field.itemAt(1).widget(), window.legend_auto_width)
        self.assertEqual(width_field.itemAt(1).widget(), window.legend_width)
        self.assertEqual(columns_field.itemAt(1).widget(), window.legend_columns)
        self.assertGreater(
            window.ui.controlsLayout.indexOf(window.legend_group),
            window.ui.controlsLayout.indexOf(window.ui.statsTableGroup),
        )

        window.show_legend.setChecked(False)
        window.update_settings()

        self.assertFalse(window.settings.show_legend)
        self.assertFalse(window.legend_position.isEnabled())
        self.assertFalse(window.legend_auto_width.isEnabled())
        self.assertFalse(window.legend_width.isEnabled())
        self.assertFalse(window.legend_columns.isEnabled())
        self.assertFalse(window.legend_font_size.isEnabled())
        self.assertFalse(window.ui.toolbarLegendSizeLabel.isEnabled())
        self.assertFalse(window.ui.legendPositionLabel.isEnabled())
        self.assertFalse(window.ui.legendAutoWidthLabel.isEnabled())
        self.assertFalse(window.ui.legendWidthLabel.isEnabled())
        self.assertFalse(window.ui.legendColumnsLabel.isEnabled())

    def test_legend_auto_width_and_auto_columns_are_mutually_adjusted(self):
        window = self.make_window()

        window.legend_columns.setCurrentText(window.tr("Auto"))

        self.assertFalse(window.legend_auto_width.isChecked())
        self.assertFalse(window.settings.legend_auto_width)
        self.assertEqual(window.settings.legend_columns, 0)
        self.assertTrue(window.legend_width.isEnabled())

        window.legend_auto_width.setChecked(True)

        self.assertTrue(window.legend_auto_width.isChecked())
        self.assertEqual(window.legend_columns.currentText(), "1")
        self.assertTrue(window.settings.legend_auto_width)
        self.assertEqual(window.settings.legend_columns, 1)
        self.assertFalse(window.legend_width.isEnabled())

    def test_missing_legend_auto_width_uses_current_default(self):
        settings = project_io.chart_settings_from_dict({
            "legend_width": 1.2,
            "legend_columns": 1,
        })

        self.assertTrue(settings.legend_auto_width)
        self.assertEqual(settings.legend_width, 1.2)
        self.assertEqual(settings.legend_columns, 1)

    def test_adjust_all_font_sizes_uses_office_like_steps(self):
        window = self.make_window()
        window.title_font_size.setValue(16)
        window.axis_label_font_size.setValue(12)
        window.tick_font_size.setValue(10)
        window.legend_font_size.setValue(10)
        window.line_value_font_size.setValue(9)
        window.stat_table_font_size.setValue(9)

        with mock.patch.object(window, "render"):
            window.increase_all_fonts_button.click()

        self.assertEqual(window.title_font_size.value(), 18)
        self.assertEqual(window.axis_label_font_size.value(), 14)
        self.assertEqual(window.tick_font_size.value(), 11)
        self.assertEqual(window.legend_font_size.value(), 11)
        self.assertEqual(window.line_value_font_size.value(), 10)
        self.assertEqual(window.stat_table_font_size.value(), 10)
        self.assertEqual(window.settings.title_font_size, 18)
        self.assertEqual(window.settings.axis_label_font_size, 14)
        self.assertEqual(window.settings.tick_font_size, 11)
        self.assertEqual(window.settings.legend_font_size, 11)
        self.assertEqual(window.settings.line_value_font_size, 10)
        self.assertEqual(window.settings.stat_table_font_size, 10)

        with mock.patch.object(window, "render"):
            window.decrease_all_fonts_button.click()

        self.assertEqual(window.title_font_size.value(), 16)
        self.assertEqual(window.axis_label_font_size.value(), 12)
        self.assertEqual(window.tick_font_size.value(), 10)
        self.assertEqual(window.legend_font_size.value(), 10)
        self.assertEqual(window.line_value_font_size.value(), 9)
        self.assertEqual(window.stat_table_font_size.value(), 9)

    def test_adjust_all_font_sizes_updates_disabled_module_fonts(self):
        window = self.make_window()
        window.show_legend.setChecked(False)
        window.show_stat_table.setChecked(False)
        window.line_overlay_stat.setCurrentText("Median")
        window.show_line_values.setChecked(False)
        window.update_settings()

        self.assertFalse(window.legend_font_size.isEnabled())
        self.assertFalse(window.stat_table_font_size.isEnabled())
        self.assertFalse(window.line_value_font_size.isEnabled())

        with mock.patch.object(window, "render"):
            window.increase_all_fonts_button.click()

        self.assertEqual(window.legend_font_size.value(), 11)
        self.assertEqual(window.stat_table_font_size.value(), 10)
        self.assertEqual(window.line_value_font_size.value(), 10)
        self.assertEqual(window.settings.legend_font_size, 11)
        self.assertEqual(window.settings.stat_table_font_size, 10)
        self.assertEqual(window.settings.line_value_font_size, 10)

    def test_right_sidebar_width_is_owned_by_the_outer_pane(self):
        window = self.make_window()

        self.assertGreaterEqual(window.ui.controlsPane.minimumWidth(), 420)
        self.assertEqual(window.ui.controlsScroll.minimumWidth(), 0)
        self.assertEqual(window.ui.controlsContent.minimumWidth(), 0)

    def test_window_resize_gives_extra_width_to_plot_panel(self):
        window = self.make_window(initial_render=False)
        window.resize(1800, 800)
        window.show()
        self.qapp.processEvents()
        splitter = window.ui.mainSplitter
        before = splitter.sizes()

        window.resize(2200, 800)
        self.qapp.processEvents()
        after = splitter.sizes()

        self.assertLessEqual(abs(after[0] - before[0]), 1)
        self.assertGreaterEqual(after[1] - before[1], 398)
        self.assertLessEqual(abs(after[2] - before[2]), 1)

        window.resize(2000, 800)
        self.qapp.processEvents()
        contracted = splitter.sizes()

        self.assertLessEqual(abs(contracted[0] - after[0]), 1)
        self.assertGreaterEqual(after[1] - contracted[1], 198)
        self.assertLessEqual(abs(contracted[2] - after[2]), 1)

    def test_single_line_controls_use_matching_heights(self):
        window = self.make_window()

        self.assertIs(window.edit_overlay_styles_button, window.ui.editOverlayStylesButton)
        for widget in [
            window.outlier_effect,
            window.outlier_threshold,
            window.width,
            window.line_overlay_stat,
            window.line_overlay_style,
            window.edit_overlay_styles_button,
            window.line_overlay_width,
            window.line_overlay_point_size,
            window.line_value_position,
            window.line_value_decimals,
            window.line_value_font_size,
            window.stat_table_font_size,
            window.edit_group_colors_button,
            window.ui.loadTemplateButton,
            window.ui.copyImageButton,
            window.ui.copyStatisticsButton,
            window.ui.groupFilterButton,
        ]:
            with self.subTest(widget=widget.objectName()):
                self.assertEqual(widget.minimumHeight(), main_window.APP_CONTROL_HEIGHT)
                self.assertEqual(widget.maximumHeight(), main_window.APP_CONTROL_HEIGHT)

    def test_line_style_combo_items_show_preview_icons(self):
        window = self.make_window()

        self.assertEqual(window.line_overlay_style.count(), len(LINE_OVERLAY_STYLES))
        self.assertEqual(window.line_overlay_style.itemText(0), "Auto")
        self.assertEqual(window.line_overlay_style.iconSize(), overlay_renderer.LINE_STYLE_ICON_SIZE)
        self.assertEqual(window.line_overlay_style.view().iconSize(), overlay_renderer.LINE_STYLE_ICON_SIZE)
        self.assertIsInstance(window.line_overlay_style.view().itemDelegate(), LineStyleItemDelegate)
        self.assertGreaterEqual(window.line_overlay_style.view().minimumWidth(), overlay_renderer.LINE_STYLE_POPUP_PREVIEW_WIDTH + 120)
        self.assertLess(window.line_overlay_style.width(), window.line_overlay_style.view().minimumWidth())
        item_index = window.line_overlay_style.model().index(0, 0)
        hint = window.line_overlay_style.view().itemDelegate().sizeHint(QStyleOptionViewItem(), item_index)
        self.assertGreaterEqual(hint.height(), overlay_renderer.LINE_STYLE_POPUP_ROW_HEIGHT)
        for index in range(window.line_overlay_style.count()):
            with self.subTest(style=window.line_overlay_style.itemText(index)):
                self.assertFalse(window.line_overlay_style.itemIcon(index).isNull())

    def test_line_style_preview_icon_uses_requested_color(self):
        icon = overlay_renderer.line_style_icon("Solid", QColor("#f9fafb"))
        image = icon.pixmap(overlay_renderer.LINE_STYLE_ICON_SIZE).toImage()
        pixel = QColor(image.pixel(overlay_renderer.LINE_STYLE_ICON_SIZE.width() // 2, overlay_renderer.LINE_STYLE_ICON_SIZE.height() // 2))

        self.assertGreater(pixel.lightness(), 220)

    def test_dotted_line_style_preview_uses_round_dots(self):
        icon = overlay_renderer.line_style_icon("Dotted", QColor("#f9fafb"))
        image = icon.pixmap(overlay_renderer.LINE_STYLE_ICON_SIZE).toImage()
        y = overlay_renderer.LINE_STYLE_ICON_SIZE.height() // 2
        runs = []
        current = 0
        for x in range(image.width()):
            if image.pixelColor(x, y).alpha() > 0:
                current += 1
            elif current:
                runs.append(current)
                current = 0
        if current:
            runs.append(current)

        self.assertTrue(runs)
        self.assertLessEqual(max(runs), 6)

    def test_loose_dot_line_style_preview_uses_round_dots(self):
        icon = overlay_renderer.line_style_icon("Loose dot", QColor("#f9fafb"))
        image = icon.pixmap(overlay_renderer.LINE_STYLE_ICON_SIZE).toImage()
        y = overlay_renderer.LINE_STYLE_ICON_SIZE.height() // 2
        runs = []
        current = 0
        for x in range(image.width()):
            if image.pixelColor(x, y).alpha() > 0:
                current += 1
            elif current:
                runs.append(current)
                current = 0
        if current:
            runs.append(current)

        self.assertTrue(runs)
        self.assertLessEqual(max(runs), 6)

    def test_settings_spinboxes_commit_keyboard_input_on_enter_or_focus_out(self):
        window = self.make_window()

        for spin_box in window._spin_boxes():
            with self.subTest(spin_box=spin_box.objectName()):
                self.assertFalse(spin_box.keyboardTracking())

    def test_group_color_button_sits_with_chart_toolbar_controls(self):
        window = self.make_window()

        self.assertIs(window.edit_group_colors_button, window.ui.editGroupColorsButton)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 9).widget(), window.chart_type)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(2, 9).widget(), window.preset)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(2, 10).widget(), window.edit_group_colors_button)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(3, 9).widget(), window.group_order)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(3, 10).widget(), window.ui.editGroupOrderButton)
        for label, control, hint in (
            (window.ui.toolbarChartTypeLabel, window.chart_type, "Type"),
            (window.ui.toolbarPaletteLabel, window.preset, "Palette"),
            (window.ui.toolbarOrderLabel, window.group_order, "Order"),
        ):
            self.assertFalse(label.pixmap().isNull())
            self.assertEqual(label.toolTip(), hint)
            self.assertEqual(label.accessibleName(), hint)
            self.assertIs(label.buddy(), control)
        self.assertEqual(window.ui.topToolbarLayout.horizontalSpacing(), 8)
        self.assertEqual(window.ui.topToolbarLayout.verticalSpacing(), 4)
        self.assertEqual(window.ui.topToolbarLayout.columnStretch(9), 0)
        self.assertEqual(window.chart_type.sizePolicy().horizontalPolicy(), QSizePolicy.Fixed)
        self.assertEqual(window.preset.sizePolicy().horizontalPolicy(), QSizePolicy.Fixed)
        self.assertEqual(window.group_order.sizePolicy().horizontalPolicy(), QSizePolicy.Fixed)
        expected_order_width = max(
            window._combo_full_text_width(window.group_order),
            window._combo_full_text_width(window.preset),
        )
        self.assertEqual(window.ui.topToolbarLayout.columnMinimumWidth(9), expected_order_width)
        self.assertEqual(window.chart_type.width(), expected_order_width)
        self.assertEqual(window.preset.width(), expected_order_width)
        self.assertEqual(window.group_order.width(), expected_order_width)

    def test_primary_settings_are_promoted_to_top_toolbar_and_pinned_sidebar(self):
        window = main_window.MainWindow()

        toolbar = window.ui.topToolbarWidget
        self.assertEqual(toolbar.sizePolicy().verticalPolicy(), QSizePolicy.Maximum)
        self.assertGreaterEqual(toolbar.sizeHint().height(), window.ui.topToolbarLayout.minimumSize().height())
        self.assertGreaterEqual(toolbar.minimumSizeHint().height(), window.ui.topToolbarLayout.minimumSize().height())
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 0).widget(), window.ui.copyImageButton)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(2, 0).widget(), window.ui.copyStatisticsButton)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(3, 0).widget(), window.ui.groupFilterButton)
        self.assertEqual(window.ui.copyToolbarLabel.text(), "Common")
        self.assertEqual(window.width.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.height.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.dpi.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.transparent_background.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.template_combo.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 12).widget(), window.ui.toolbarTemplateIconLabel)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 13).widget(), window.template_combo)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 16).widget(), window.width)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(2, 16).widget(), window.dpi)
        self.assertEqual(
            window.ui.templateToolbarLabel.text(),
            "Groups Style Templates",
        )
        self.assertEqual(
            window.ui.templateToolbarLabel.toolTip(),
            "Templates available for Groups sheets",
        )
        self.assertEqual(window.ui.fontToolbarLabel.text(), "Font")
        self.assertEqual(window.ui.chartToolbarLabel.text(), "Chart Basics")
        self.assertEqual(window.ui.canvasToolbarLabel.text(), "Export & Canvas")
        self.assertEqual(window.ui.titleAxisGroup.title(), "Title")
        self.assertEqual(window.title.parent(), window.ui.titleAxisGroup)
        self.assertEqual(window.x_label.parent(), window.ui.titleAxisGroup)
        self.assertEqual(window.y_label.parent(), window.ui.titleAxisGroup)
        self.assertEqual(window.secondary_y_label.parent(), window.ui.titleAxisGroup)
        self.assertLess(
            window.ui.controlsLayout.indexOf(window.ui.titleAxisGroup),
            window.ui.controlsLayout.indexOf(window.ui.categoryAxisGroup),
        )
        self.assertLess(
            window.ui.controlsLayout.indexOf(window.ui.categoryAxisGroup),
            window.ui.controlsLayout.indexOf(window.ui.primaryAxisGroup),
        )
        self.assertLess(
            window.ui.controlsLayout.indexOf(window.ui.primaryAxisGroup),
            window.ui.controlsLayout.indexOf(window.ui.secondaryAxisGroup),
        )

    def test_top_toolbar_rows_align_without_overlap(self):
        window = main_window.MainWindow()
        window.handle_plot_object_selection("line_overlay")
        window.resize(2048, 900)
        window.show()
        self.qapp.processEvents()

        def bounds(widget):
            point = widget.mapTo(window.ui.topToolbarWidget, QPoint(0, 0))
            return point.y(), point.y() + widget.geometry().height()

        row_groups = [
            [
                window.ui.copyImageButton,
                window.ui.titleFontSizeSpin,
                window.ui.chartTypeCombo,
                window.ui.templateCombo,
                window.ui.widthSpin,
            ],
            [
                window.ui.copyStatisticsButton,
                window.ui.tickFontSizeSpin,
                window.ui.presetCombo,
                window.ui.loadTemplateButton,
                window.ui.dpiSpin,
            ],
            [
                window.ui.groupFilterButton,
                window.ui.lineValueFontSizeSpin,
                window.ui.groupOrderCombo,
            ],
        ]
        input_widgets = [
            window.ui.copyImageButton,
            window.ui.copyStatisticsButton,
            window.ui.groupFilterButton,
            window.ui.increaseAllFontsButton,
            window.ui.decreaseAllFontsButton,
            window.ui.titleFontSizeSpin,
            window.ui.axisLabelFontSizeSpin,
            window.ui.tickFontSizeSpin,
            window.ui.additionalGuideFontSizeSpin,
            window.ui.legendFontSizeSpin,
            window.ui.lineValueFontSizeSpin,
            window.ui.statTableFontSizeSpin,
            window.ui.chartTypeCombo,
            window.ui.presetCombo,
            window.ui.groupOrderCombo,
            window.ui.editGroupOrderButton,
            window.ui.templateCombo,
            window.ui.loadTemplateButton,
            window.ui.saveTemplateButton,
            window.ui.widthSpin,
            window.ui.heightSpin,
            window.ui.dpiSpin,
            window.ui.transparentBackgroundCheck,
        ]
        self.assertEqual({widget.geometry().height() for widget in input_widgets}, {26})
        compact_spin_widgets = [
            window.ui.titleFontSizeSpin,
            window.ui.axisLabelFontSizeSpin,
            window.ui.tickFontSizeSpin,
            window.ui.additionalGuideFontSizeSpin,
            window.ui.legendFontSizeSpin,
            window.ui.lineValueFontSizeSpin,
            window.ui.statTableFontSizeSpin,
            window.ui.widthSpin,
            window.ui.heightSpin,
            window.ui.dpiSpin,
        ]
        for widget in compact_spin_widgets:
            option = QStyleOptionSpinBox()
            widget.initStyleOption(option)
            edit_rect = widget.style().subControlRect(
                QStyle.ComplexControl.CC_SpinBox,
                option,
                QStyle.SubControl.SC_SpinBoxEditField,
                widget,
            )
            button_rect = widget.style().subControlRect(
                QStyle.ComplexControl.CC_SpinBox,
                option,
                QStyle.SubControl.SC_SpinBoxUp,
                widget,
            )
            sample_text = max(
                [
                    widget.textFromValue(widget.minimum()),
                    widget.textFromValue(widget.maximum()),
                    widget.textFromValue(widget.value()),
                ],
                key=widget.fontMetrics().horizontalAdvance,
            )

            self.assertEqual(widget.buttonSymbols(), QAbstractSpinBox.ButtonSymbols.UpDownArrows)
            self.assertLess(widget.width(), main_window.COMBO_MIN_WIDTH)
            self.assertGreater(button_rect.width(), 0)
            self.assertGreaterEqual(
                edit_rect.width(),
                widget.fontMetrics().horizontalAdvance(sample_text)
                + app_theme.COMPACT_SPIN_TEXT_PADDING
                + widget.fontMetrics().horizontalAdvance("0"),
            )

        for row in row_groups:
            centers = [(top + bottom) / 2 for top, bottom in (bounds(widget) for widget in row)]
            self.assertLessEqual(max(centers) - min(centers), 1.5)

        section_columns = [
            [window.ui.copyImageButton, window.ui.copyStatisticsButton, window.ui.groupFilterButton],
            [window.ui.titleFontSizeSpin, window.ui.tickFontSizeSpin, window.ui.lineValueFontSizeSpin],
            [window.ui.chartTypeCombo, window.ui.presetCombo, window.ui.groupOrderCombo],
            [window.ui.templateCombo, window.ui.loadTemplateButton],
            [window.ui.widthSpin, window.ui.dpiSpin],
        ]
        for column in section_columns:
            previous_bottom = None
            for widget in column:
                top, bottom = bounds(widget)
                self.assertGreaterEqual(top, 0)
                self.assertLessEqual(bottom, window.ui.topToolbarWidget.height())
                if previous_bottom is not None:
                    self.assertGreaterEqual(top, previous_bottom)
                previous_bottom = bottom

        chart_type_right = window.ui.chartTypeCombo.mapTo(window.ui.topToolbarWidget, QPoint(window.ui.chartTypeCombo.width(), 0)).x()
        colors_right = window.ui.editGroupColorsButton.mapTo(window.ui.topToolbarWidget, QPoint(window.ui.editGroupColorsButton.width(), 0)).x()
        edit_right = window.ui.editGroupOrderButton.mapTo(window.ui.topToolbarWidget, QPoint(window.ui.editGroupOrderButton.width(), 0)).x()
        preset_right = window.ui.presetCombo.mapTo(window.ui.topToolbarWidget, QPoint(window.ui.presetCombo.width(), 0)).x()
        order_right = window.ui.groupOrderCombo.mapTo(window.ui.topToolbarWidget, QPoint(window.ui.groupOrderCombo.width(), 0)).x()
        expected_order_width = max(
            window._combo_full_text_width(window.group_order),
            window._combo_full_text_width(window.preset),
        )

        self.assertEqual(window.ui.groupOrderCombo.width(), expected_order_width)
        self.assertEqual(window.ui.chartTypeCombo.width(), expected_order_width)
        self.assertEqual(window.ui.presetCombo.width(), expected_order_width)
        self.assertEqual(chart_type_right, preset_right)
        self.assertEqual(colors_right, edit_right)
        self.assertEqual(preset_right, order_right)

    def test_common_toolbar_buttons_are_ordered_in_the_first_column(self):
        window = self.make_window()

        self.assertIs(window.group_filter_button, window.ui.groupFilterButton)
        self.assertEqual(window.group_filter_button.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.ui.copyStatisticsButton.parent(), window.ui.topToolbarWidget)
        self.assertEqual(window.ui.copyStatisticsButton.text(), "Copy Statistics Table")
        self.assertEqual(window.group_filter_button.text(), "Group Filter")
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(1, 0).widget(), window.ui.copyImageButton)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(2, 0).widget(), window.ui.copyStatisticsButton)
        self.assertEqual(window.ui.topToolbarLayout.itemAtPosition(3, 0).widget(), window.group_filter_button)

    def test_filter_dialogs_use_generated_checklist_shell(self):
        window = self.make_window()

        dialog, ui = window._create_checklist_filter_dialog("Group Filter")

        self.assertEqual(dialog.windowTitle(), "Group Filter")
        self.assertEqual(ui.itemList.parent(), dialog)
        self.assertEqual(ui.buttonBox.parent(), dialog)
        self.assertTrue(ui.buttonBox.standardButtons() & QDialogButtonBox.Ok)
        self.assertTrue(ui.buttonBox.standardButtons() & QDialogButtonBox.Cancel)

    def test_group_order_dialog_uses_generated_shell(self):
        window = self.make_window()

        dialog, ui = window._create_group_order_dialog()

        self.assertEqual(dialog.windowTitle(), "Edit Group Order")
        self.assertEqual(ui.hintLabel.text(), "Drag groups to change plot order.")
        self.assertEqual(ui.groupList.parent(), dialog)
        self.assertEqual(ui.tableOrderButton.text(), "Table Order")
        self.assertTrue(ui.buttonBox.standardButtons() & QDialogButtonBox.Ok)
        self.assertTrue(ui.buttonBox.standardButtons() & QDialogButtonBox.Cancel)

    def test_overlay_styles_dialog_uses_generated_shell(self):
        window = self.make_window()

        dialog, ui = window._create_overlay_styles_dialog()

        self.assertEqual(dialog.windowTitle(), "Custom Overlay Line Styles")
        self.assertEqual(ui.rowsScroll.parent(), dialog)
        self.assertIs(ui.rowsContainer, ui.rowsScroll.widget())
        self.assertEqual(ui.rowsLayout.spacing(), 6)
        self.assertTrue(ui.buttonBox.standardButtons() & QDialogButtonBox.Ok)
        self.assertTrue(ui.buttonBox.standardButtons() & QDialogButtonBox.Cancel)

    def test_group_colors_dialog_uses_generated_shell(self):
        window = self.make_window()

        dialog, ui = window._create_group_colors_dialog()

        self.assertEqual(dialog.windowTitle(), "Edit Group Colors")
        self.assertEqual(ui.paletteLabel.text(), "Palette")
        self.assertEqual(ui.overlayPaletteLabel.text(), "Overlay palette")
        self.assertEqual(ui.paletteCombo.parent(), ui.paletteRow)
        self.assertEqual(ui.overlayPaletteCombo.parent(), ui.overlayPaletteRow)
        self.assertIs(ui.rowsContainer, ui.rowsScroll.widget())
        self.assertEqual(ui.rowsLayout.spacing(), 6)
        self.assertTrue(ui.buttonBox.standardButtons() & QDialogButtonBox.Ok)
        self.assertTrue(ui.buttonBox.standardButtons() & QDialogButtonBox.Cancel)

    def test_plot_hover_feedback_does_not_change_inspector_selection(self):
        window = main_window.MainWindow()
        legend_target = next(target for target in window.canvas._interaction_targets if target["kind"] == "legend")
        bbox = legend_target["bbox"]
        event = SimpleNamespace(x=(bbox.x0 + bbox.x1) / 2, y=(bbox.y0 + bbox.y1) / 2, button=1)
        callback = mock.Mock()
        window.canvas.selection_callback = callback

        window.canvas._handle_plot_motion(event)

        callback.assert_not_called()
        self.assertEqual(window.canvas._hover_object_kind, "legend")
        self.assertIsNotNone(window.canvas._hover_feedback_patch)
        self.assertIsNone(window.canvas._selected_feedback_patch)

        window.canvas._handle_plot_click(event)

        callback.assert_called_once_with("legend")
        self.assertEqual(window.canvas._selected_object_kind, "legend")
        self.assertIsNotNone(window.canvas._selected_feedback_patch)

        callback.reset_mock()
        blank_event = SimpleNamespace(x=-10, y=-10, button=1)
        window.canvas._handle_plot_click(blank_event)

        callback.assert_called_once_with(None)
        self.assertIsNone(window.canvas._selected_object_kind)
        self.assertIsNone(window.canvas._selected_feedback_patch)

        window.canvas._handle_plot_leave(None)
        self.assertIsNone(window.canvas._hover_object_kind)
        self.assertIsNone(window.canvas._hover_feedback_patch)

    def test_plot_hover_uses_cached_blit_without_full_draw(self):
        window = main_window.MainWindow()
        legend_target = next(target for target in window.canvas._interaction_targets if target["kind"] == "legend")
        bbox = legend_target["bbox"]
        event = SimpleNamespace(x=(bbox.x0 + bbox.x1) / 2, y=(bbox.y0 + bbox.y1) / 2, button=1)

        self.assertIsNotNone(window.canvas._blit_background)
        with mock.patch.object(window.canvas.canvas, "blit", wraps=window.canvas.canvas.blit) as blit, mock.patch.object(
            window.canvas.canvas,
            "draw_idle",
            wraps=window.canvas.canvas.draw_idle,
        ) as draw_idle:
            window.canvas._handle_plot_motion(event)

        blit.assert_called()
        draw_idle.assert_not_called()
        self.assertTrue(all(patch.get_animated() for patch in window.canvas._hover_feedback_patch))

    def test_plot_feedback_falls_back_when_blitting_is_unavailable(self):
        window = main_window.MainWindow()
        target = next(target for target in window.canvas._interaction_targets if target["kind"] == "legend")

        with mock.patch.object(window.canvas, "_can_blit", return_value=False), mock.patch.object(
            window.canvas.canvas,
            "draw_idle",
            wraps=window.canvas.canvas.draw_idle,
        ) as draw_idle:
            window.canvas._set_feedback_patch("_hover_feedback_patch", target["bbox"], selected=False)

        draw_idle.assert_called_once_with()
        self.assertTrue(all(not patch.get_animated() for patch in window.canvas._hover_feedback_patch))

    def test_resize_invalidates_and_full_draw_recaptures_blit_background(self):
        window = main_window.MainWindow()
        self.assertIsNotNone(window.canvas._blit_background)

        window.canvas._handle_canvas_resize(None)

        self.assertIsNone(window.canvas._blit_background)
        window.canvas.canvas.draw()
        self.assertIsNotNone(window.canvas._blit_background)

    def test_export_hides_plot_interaction_feedback(self):
        window = main_window.MainWindow()
        legend_target = next(target for target in window.canvas._interaction_targets if target["kind"] == "legend")
        bbox = legend_target["bbox"]
        event = SimpleNamespace(x=(bbox.x0 + bbox.x1) / 2, y=(bbox.y0 + bbox.y1) / 2, button=1)

        window.canvas._handle_plot_motion(event)
        window.canvas._handle_plot_click(event)

        feedback_patches = window.canvas._hover_feedback_patch + window.canvas._selected_feedback_patch
        self.assertTrue(all(patch.get_visible() for patch in feedback_patches))

        def assert_feedback_hidden(*_args, **_kwargs):
            self.assertTrue(all(not patch.get_visible() for patch in feedback_patches))

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "figure.png"
            with mock.patch.object(window.canvas.figure, "savefig", side_effect=assert_feedback_hidden) as savefig:
                window.canvas.export(str(path), window.settings)

        savefig.assert_called_once()
        self.assertTrue(all(patch.get_visible() for patch in feedback_patches))

    def test_plot_area_hover_is_not_axis_selection(self):
        window = main_window.MainWindow()
        plot_target = next(target for target in window.canvas._interaction_targets if target["kind"] == "plot_area")
        bbox = plot_target["bbox"]
        event = SimpleNamespace(x=(bbox.x0 + bbox.x1) / 2, y=(bbox.y0 + bbox.y1) / 2, button=1)
        callback = mock.Mock()
        window.canvas.selection_callback = callback

        window.canvas._handle_plot_motion(event)

        callback.assert_not_called()
        self.assertEqual(window.canvas._hover_object_kind, "plot_area")
        self.assertIsNotNone(window.canvas._hover_feedback_patch)

        blank_plot_event = None
        for x_fraction in (0.2, 0.4, 0.6, 0.8):
            for y_fraction in (0.2, 0.4, 0.6, 0.8):
                candidate = SimpleNamespace(
                    x=bbox.x0 + bbox.width * x_fraction,
                    y=bbox.y0 + bbox.height * y_fraction,
                    button=1,
                )
                target = window.canvas._interaction_target_at_event(candidate)
                if target is not None and target["kind"] == "plot_area":
                    blank_plot_event = candidate
                    break
            if blank_plot_event is not None:
                break
        self.assertIsNotNone(blank_plot_event)

        window.canvas._handle_plot_click(blank_plot_event)

        callback.assert_called_once_with("plot_area")
        self.assertEqual(window.canvas._selected_object_kind, "plot_area")
        self.assertIsNotNone(window.canvas._selected_feedback_patch)

    def test_primary_axis_selection_only_hits_primary_axis_regions(self):
        window = main_window.MainWindow()
        axis_target = next(
            target
            for target in window.canvas._interaction_targets
            if target["kind"] == "primary_axis"
        )
        axis_box = axis_target["hit_bboxes"][0]
        axis_event = SimpleNamespace(x=(axis_box.x0 + axis_box.x1) / 2, y=(axis_box.y0 + axis_box.y1) / 2, button=1)

        target = window.canvas._interaction_target_at_event(axis_event)

        self.assertIsNotNone(target)
        self.assertEqual(target["kind"], "primary_axis")

    def test_primary_axis_selection_highlights_only_its_axis_side(self):
        window = main_window.MainWindow()
        axis_target = next(
            target
            for target in window.canvas._interaction_targets
            if target["kind"] == "primary_axis"
        )
        axis_box = axis_target["hit_bboxes"][0]
        axis_event = SimpleNamespace(x=(axis_box.x0 + axis_box.x1) / 2, y=(axis_box.y0 + axis_box.y1) / 2, button=1)

        window.canvas._handle_plot_click(axis_event)

        self.assertEqual(len(axis_target["feedback_bboxes"]), 1)
        self.assertIsInstance(window.canvas._selected_feedback_patch, list)
        self.assertEqual(len(window.canvas._selected_feedback_patch), 1)

    def test_split_axis_selection_highlights_only_the_selected_axis_side(self):
        window = main_window.MainWindow()
        settings = ChartSettings(
            show_stat_table=False,
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            secondary_axis_split_ratio=0.30,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )
        window.canvas.render(window.table.dataframe(), settings)
        axis_targets = [
            target
            for target in window.canvas._interaction_targets
            if target["kind"] in {"category_axis", "primary_axis", "secondary_axis"}
        ]
        self.assertEqual(len(axis_targets), 3)
        self.assertEqual(
            {target["kind"] for target in axis_targets},
            {"category_axis", "primary_axis", "secondary_axis"},
        )

        for axis_target in axis_targets:
            axis_box = axis_target["hit_bboxes"][0]
            axis_event = SimpleNamespace(x=(axis_box.x0 + axis_box.x1) / 2, y=(axis_box.y0 + axis_box.y1) / 2, button=1)

            window.canvas._handle_plot_click(axis_event)

            self.assertEqual(window.canvas._selected_object_kind, axis_target["kind"])
            self.assertEqual(len(axis_target["feedback_bboxes"]), 1)
            self.assertIsInstance(window.canvas._selected_feedback_patch, list)
            self.assertEqual(len(window.canvas._selected_feedback_patch), 1)

    def test_all_titles_select_the_shared_title_context_for_box_and_ridge(self):
        window = main_window.MainWindow()

        for chart_type in ("Box", "Ridge"):
            with self.subTest(chart_type=chart_type):
                window.chart_type.setCurrentText(chart_type)
                window.flush_pending_render()
                renderer = window.canvas.canvas.get_renderer()
                plot_axis = window.canvas.figure.axes[0]

                for artist in (
                    plot_axis.title,
                    plot_axis.xaxis.label,
                    plot_axis.yaxis.label,
                ):
                    label_bbox = artist.get_window_extent(renderer)
                    event = SimpleNamespace(
                        x=(label_bbox.x0 + label_bbox.x1) / 2,
                        y=(label_bbox.y0 + label_bbox.y1) / 2,
                        button=1,
                    )

                    target = window.canvas._interaction_target_at_event(event)

                    self.assertIsNotNone(target)
                    self.assertEqual(target["kind"], "title_axis")
                    window.canvas._handle_plot_click(event)
                    self.assertEqual(
                        window.ui.inspectorContextLabel.text(),
                        f"Editing: {window.ui.titleAxisGroup.title()}",
                    )

    def test_secondary_axis_title_selects_shared_title_context_for_box_and_ridge(self):
        window = main_window.MainWindow()

        for chart_type, dimension in (("Box", "y"), ("Ridge", "x")):
            with self.subTest(chart_type=chart_type):
                settings = ChartSettings(
                    chart_type=chart_type,
                    show_stat_table=False,
                    secondary_y_label="Rate",
                    extra_custom_overlay=True,
                    custom_overlay_secondary_axis=True,
                    custom_overlay_series=[
                        {
                            "name": "Target",
                            "values": {
                                "Control": "50",
                                "Low dose": "60",
                                "High dose": "70",
                            },
                        },
                    ],
                )
                window.canvas.render(window.table.dataframe(), settings)
                secondary_axis = next(
                    axis
                    for axis in window.canvas.figure.axes
                    if axis.get_gid() == "secondary-axis"
                )
                axis = secondary_axis.xaxis if dimension == "x" else secondary_axis.yaxis
                renderer = window.canvas.canvas.get_renderer()
                label_bbox = axis.label.get_window_extent(renderer)
                event = SimpleNamespace(
                    x=(label_bbox.x0 + label_bbox.x1) / 2,
                    y=(label_bbox.y0 + label_bbox.y1) / 2,
                    button=1,
                )

                target = window.canvas._interaction_target_at_event(event)

                self.assertIsNotNone(target)
                self.assertEqual(target["kind"], "title_axis")

    def test_title_selection_highlights_each_visible_title_box(self):
        window = main_window.MainWindow()
        title_target = next(target for target in window.canvas._interaction_targets if target["kind"] == "title_axis")
        title_box = title_target["hit_bboxes"][0]
        event = SimpleNamespace(x=(title_box.x0 + title_box.x1) / 2, y=(title_box.y0 + title_box.y1) / 2, button=1)

        window.canvas._handle_plot_click(event)

        self.assertGreaterEqual(len(title_target["feedback_bboxes"]), 3)
        self.assertIsInstance(window.canvas._selected_feedback_patch, list)
        self.assertEqual(len(window.canvas._selected_feedback_patch), len(title_target["feedback_bboxes"]))

    def test_plot_object_selection_maps_to_context_sections(self):
        window = self.make_window()

        self.assertIs(window._section_for_plot_object("legend"), window.legend_group)
        self.assertIs(window._section_for_plot_object("stats_table"), window.ui.statsTableGroup)
        self.assertIs(window._section_for_plot_object("axis"), window.ui.categoryAxisGroup)
        self.assertIs(window._section_for_plot_object("category_axis"), window.ui.categoryAxisGroup)
        self.assertIs(window._section_for_plot_object("primary_axis"), window.ui.primaryAxisGroup)
        self.assertIs(window._section_for_plot_object("secondary_axis"), window.ui.secondaryAxisGroup)
        self.assertIs(window._section_for_plot_object("title_axis"), window.ui.titleAxisGroup)
        self.assertIs(window._section_for_plot_object("points"), window.ui.pointsGroup)
        self.assertIs(window._section_for_plot_object("outliers"), window.ui.outliersGroup)
        self.assertIs(window._section_for_plot_object("line_overlay"), window.ui.lineOverlayGroup)
        self.assertIs(window._section_for_plot_object("plot_area"), window.ui.specificGroup)
        self.assertIsNone(window._section_for_plot_object(None))

    def test_plot_object_selection_focuses_related_inspector_groups(self):
        window = self.make_window()

        def visible_groups():
            return {group for group in window._inspector_groups() if not group.isHidden()}

        window.handle_plot_object_selection("plot_area")
        self.assertEqual(visible_groups(), {window.ui.specificGroup})

        window.handle_plot_object_selection("points")
        self.assertEqual(visible_groups(), {window.ui.pointsGroup})

        window.handle_plot_object_selection("outliers")
        self.assertEqual(visible_groups(), {window.ui.outliersGroup})

        window.handle_plot_object_selection("line_overlay")
        self.assertEqual(visible_groups(), {window.ui.lineOverlayGroup})

        window.handle_plot_object_selection("axis")
        self.assertEqual(
            visible_groups(),
            {
                window.ui.categoryAxisGroup,
                window.ui.primaryAxisGroup,
                window.ui.secondaryAxisGroup,
                window.ui.axesAppearanceGroup,
            },
        )

        window.handle_plot_object_selection("category_axis")
        self.assertEqual(
            visible_groups(),
            {window.ui.categoryAxisGroup, window.ui.axesAppearanceGroup},
        )

        window.handle_plot_object_selection("primary_axis")
        self.assertEqual(
            visible_groups(),
            {
                window.ui.primaryAxisGroup,
                window.ui.additionalGuidesGroup,
                window.ui.axesAppearanceGroup,
            },
        )

        window.handle_plot_object_selection("secondary_axis")
        self.assertEqual(
            visible_groups(),
            {window.ui.secondaryAxisGroup, window.ui.axesAppearanceGroup},
        )

        window.handle_plot_object_selection("title_axis")
        self.assertEqual(visible_groups(), {window.ui.titleAxisGroup})

        window.handle_plot_object_selection("stats_table")
        self.assertEqual(visible_groups(), {window.ui.statsTableGroup})

        window.handle_plot_object_selection("legend")
        self.assertEqual(visible_groups(), {window.legend_group})

        window.handle_plot_object_selection(None)
        self.assertEqual(visible_groups(), window._mode_inspector_groups())

    def test_point_and_outlier_artists_focus_their_separate_inspector_groups(self):
        window = main_window.MainWindow()
        settings = ChartSettings(
            show_stat_table=False,
            show_points=True,
            show_outliers=True,
        )
        window.canvas.render(
            pd.DataFrame({"A": [1.0, 1.0, 1.0, 1.0, 20.0]}),
            settings,
        )

        for object_kind, expected_group in (
            ("points", window.ui.pointsGroup),
            ("outliers", window.ui.outliersGroup),
        ):
            with self.subTest(object_kind=object_kind):
                target = next(
                    target
                    for target in window.canvas._interaction_targets
                    if target["kind"] == object_kind
                )
                artist = target["artist"]
                data_point = artist.get_offsets()[0]
                display_point = artist.get_offset_transform().transform(data_point)
                event = SimpleNamespace(
                    x=float(display_point[0]),
                    y=float(display_point[1]),
                    button=1,
                )

                window.canvas._handle_plot_click(event)

                self.assertEqual(window.canvas._selected_object_kind, object_kind)
                self.assertEqual(
                    {
                        group
                        for group in window._inspector_groups()
                        if not group.isHidden()
                    },
                    {expected_group},
                )

    def test_groups_point_selection_outlines_every_group_and_restores_after_render(self):
        window = main_window.MainWindow()
        frame = pd.DataFrame(
            {
                "A": [1.0, 2.0, 3.0],
                "B": [2.0, 3.0, 4.0],
                "C": [3.0, 4.0, 5.0],
            }
        )
        settings = ChartSettings(
            show_stat_table=False,
            show_points=True,
            show_outliers=False,
        )
        window.canvas.render(frame, settings)
        point_targets = [
            target
            for target in window.canvas._interaction_targets
            if target.get("kind") == "points"
            and target.get("source") == "plot"
        ]
        self.assertEqual(len(point_targets), 3)
        artist = point_targets[0]["artist"]
        display_point = artist.get_offset_transform().transform(
            artist.get_offsets()[0]
        )

        window.canvas._handle_plot_click(
            SimpleNamespace(
                x=float(display_point[0]),
                y=float(display_point[1]),
                button=1,
            )
        )

        expected_sources = {target["artist"] for target in point_targets}
        self.assertEqual(window.canvas._selected_object_kind, "points")
        self.assertEqual(len(window.canvas._selected_feedback_patch), 3)
        self.assertEqual(
            {
                feedback._easygraph_feedback_source
                for feedback in window.canvas._selected_feedback_patch
            },
            expected_sources,
        )

        window.canvas.render(frame, settings)

        restored_targets = [
            target
            for target in window.canvas._interaction_targets
            if target.get("kind") == "points"
            and target.get("source") == "plot"
        ]
        self.assertEqual(window.canvas._selected_object_kind, "points")
        self.assertEqual(len(window.canvas._selected_feedback_patch), 3)
        self.assertEqual(
            {
                feedback._easygraph_feedback_source
                for feedback in window.canvas._selected_feedback_patch
            },
            {target["artist"] for target in restored_targets},
        )

    def test_inspector_context_bar_shows_selection_and_show_all_restores_groups(self):
        window = main_window.MainWindow()
        context_frame = window.ui.inspectorContextFrame
        context_label = window.ui.inspectorContextLabel
        show_all_button = window.ui.inspectorShowAllButton
        legend_target = next(
            target
            for target in window.canvas._interaction_targets
            if target["kind"] == "legend"
        )
        bbox = legend_target["bbox"]
        event = SimpleNamespace(
            x=(bbox.x0 + bbox.x1) / 2,
            y=(bbox.y0 + bbox.y1) / 2,
            button=1,
        )

        self.assertFalse(context_frame.isHidden())
        self.assertIn("All settings", context_label.text())
        self.assertFalse(show_all_button.isHidden())
        self.assertFalse(show_all_button.isEnabled())

        window.canvas._handle_plot_click(event)

        self.assertFalse(context_frame.isHidden())
        self.assertIn("Legend", context_label.text())
        self.assertEqual(show_all_button.text(), "Show All")
        self.assertFalse(show_all_button.isHidden())
        self.assertTrue(show_all_button.isEnabled())
        self.assertEqual(
            {group for group in window._inspector_groups() if not group.isHidden()},
            {window.legend_group},
        )

        show_all_button.click()

        self.assertFalse(context_frame.isHidden())
        self.assertIn("All settings", context_label.text())
        self.assertFalse(show_all_button.isHidden())
        self.assertFalse(show_all_button.isEnabled())
        self.assertIsNone(window.canvas._selected_object_kind)
        self.assertIsNone(window.canvas._selected_feedback_patch)
        self.assertEqual(
            {group for group in window._inspector_groups() if not group.isHidden()},
            window._mode_inspector_groups(),
        )

    def test_adding_sheet_clears_plot_selection_and_restores_all_inspector_groups(self):
        window = main_window.MainWindow()
        legend_target = next(
            target
            for target in window.canvas._interaction_targets
            if target["kind"] == "legend"
        )
        bbox = legend_target["bbox"]
        event = SimpleNamespace(
            x=(bbox.x0 + bbox.x1) / 2,
            y=(bbox.y0 + bbox.y1) / 2,
            button=1,
        )
        window.canvas._handle_plot_click(event)
        self.assertEqual(window.canvas._selected_object_kind, "legend")

        window.add_sheet()

        self.assertIsNone(window.canvas._selected_object_kind)
        self.assertIsNone(window.canvas._selected_feedback_patch)
        self.assertFalse(window.ui.inspectorContextFrame.isHidden())
        self.assertIn("All settings", window.ui.inspectorContextLabel.text())
        self.assertFalse(window.ui.inspectorShowAllButton.isHidden())
        self.assertFalse(window.ui.inspectorShowAllButton.isEnabled())
        self.assertEqual(
            {group for group in window._inspector_groups() if not group.isHidden()},
            window._mode_inspector_groups(),
        )

    def test_inspector_context_bar_stays_fixed_above_scrolling_settings(self):
        window = main_window.MainWindow()
        window.resize(1200, 600)
        window.show()
        self.qapp.processEvents()
        self.qapp.processEvents()
        controls_pane = window.ui.controlsPane
        pane_layout = window.ui.controlsPaneLayout
        context_frame = window.ui.inspectorContextFrame
        controls_scroll = window.ui.controlsScroll
        controls_content = window.ui.controlsContent
        title_group = window.ui.titleAxisGroup
        plot_host = window.ui.plotHost

        def margins(layout):
            values = layout.contentsMargins()
            return (
                values.left(),
                values.top(),
                values.right(),
                values.bottom(),
            )

        def global_edges(widget):
            top_left = widget.mapToGlobal(QPoint(0, 0))
            return (
                top_left.x(),
                top_left.y(),
                top_left.x() + widget.width(),
                top_left.y() + widget.height(),
            )

        self.assertIsInstance(controls_pane, QFrame)
        self.assertEqual(controls_pane.frameShape(), QFrame.Shape.NoFrame)
        pane_style_sheet = "".join(controls_pane.styleSheet().split())
        self.assertEqual(
            pane_style_sheet,
            "QFrame#controlsPane,QScrollArea#controlsScroll{"
            "border:none;margin:0;padding:0;}",
        )
        self.assertIsInstance(pane_layout, QVBoxLayout)
        self.assertEqual(margins(pane_layout), (0, 0, 0, 0))
        self.assertEqual(pane_layout.spacing(), 10)
        self.assertIs(context_frame.parentWidget(), controls_pane)
        self.assertIs(controls_scroll.parentWidget(), controls_pane)
        self.assertEqual(controls_scroll.frameShape(), QFrame.Shape.NoFrame)
        self.assertEqual(controls_scroll.frameWidth(), 0)
        self.assertFalse(controls_scroll.isAncestorOf(context_frame))
        self.assertLess(
            pane_layout.indexOf(context_frame),
            pane_layout.indexOf(controls_scroll),
        )
        self.assertEqual(margins(window.ui.controlsLayout), (0, 0, 0, 0))
        self.assertEqual(window.ui.controlsLayout.spacing(), 10)
        self.assertIs(controls_scroll.widget(), controls_content)

        controls_scroll.verticalScrollBar().setValue(0)
        self.qapp.processEvents()
        pane_left, _pane_top, pane_right, _pane_bottom = global_edges(
            controls_pane
        )
        context_left, context_top, context_right, context_bottom = global_edges(
            context_frame
        )
        scroll_left, scroll_top, scroll_right, _scroll_bottom = global_edges(
            controls_scroll
        )
        viewport_left, _viewport_top, viewport_right, _viewport_bottom = (
            global_edges(controls_scroll.viewport())
        )
        title_left, title_top, title_right, _title_bottom = global_edges(
            title_group
        )
        plot_host_top = plot_host.mapToGlobal(QPoint(0, 0)).y()

        self.assertEqual(controls_pane.contentsRect(), controls_pane.rect())
        self.assertEqual(controls_scroll.contentsRect(), controls_scroll.rect())
        self.assertEqual((context_left, context_right), (scroll_left, scroll_right))
        self.assertEqual(
            (pane_left, context_left, scroll_left, viewport_left, title_left),
            (pane_left,) * 5,
        )
        self.assertEqual(
            (pane_right, context_right, scroll_right),
            (pane_right,) * 3,
        )
        self.assertEqual(scroll_top - context_bottom, pane_layout.spacing())
        self.assertEqual(title_top - context_bottom, pane_layout.spacing())
        self.assertEqual(title_right, viewport_right)
        self.assertEqual(context_top, plot_host_top)
        self.assertEqual(controls_scroll.horizontalScrollBar().maximum(), 0)
        self.assertEqual(controls_content.width(), controls_scroll.viewport().width())
        self.assertEqual((title_left, title_right), (viewport_left, viewport_right))

        scroll_bar = controls_scroll.verticalScrollBar()
        self.assertGreater(scroll_bar.maximum(), 0)
        position_before_scroll = context_frame.mapToGlobal(QPoint(0, 0))

        scroll_bar.setValue(scroll_bar.maximum())
        self.qapp.processEvents()

        self.assertEqual(
            context_frame.mapToGlobal(QPoint(0, 0)),
            position_before_scroll,
        )

    def test_axis_selection_shows_and_scrolls_to_only_the_exact_axis_group(self):
        window = self.make_window()

        for object_kind, expected_group in (
            ("category_axis", window.ui.categoryAxisGroup),
            ("primary_axis", window.ui.primaryAxisGroup),
            ("secondary_axis", window.ui.secondaryAxisGroup),
        ):
            with self.subTest(object_kind=object_kind), mock.patch.object(
                window.ui.controlsScroll,
                "ensureWidgetVisible",
            ) as ensure_visible:
                window.handle_plot_object_selection(object_kind)

                self.assertIs(window._section_for_plot_object(object_kind), expected_group)
                self.assertEqual(
                    {group for group in window._inspector_groups() if not group.isHidden()},
                    {
                        expected_group,
                        window.ui.axesAppearanceGroup,
                        *(
                            (window.ui.additionalGuidesGroup,)
                            if object_kind == "primary_axis"
                            else ()
                        ),
                    },
                )
                ensure_visible.assert_called_once_with(expected_group, 0, 8)

    def test_chart_elements_menu_is_below_canvas_and_refreshes_without_rendering(self):
        window = self.make_window()
        button = window.canvas.findChild(QAbstractButton, "chartElementsButton")
        expected_action_keys = {
            "legend",
            "stats_table",
            "points",
            "lines",
            "outliers",
            "grid",
            "summary_none",
            "summary_median",
            "summary_mean",
            "custom_overlay",
            "secondary_axis",
            "split_secondary_axis",
            "line_values",
            "add_custom_overlay",
        }

        self.assertIsNotNone(button)
        self.assertIsInstance(button, QPushButton)
        self.assertIs(button.parentWidget(), window.canvas.chart_elements_bar)
        self.assertIsNot(button, window.canvas.canvas)
        self.assertFalse(window.canvas.canvas.isAncestorOf(button))
        self.assertLess(
            window.canvas.layout.indexOf(window.canvas.zoom_bar),
            window.canvas.layout.indexOf(window.canvas.scroll),
        )
        self.assertLess(
            window.canvas.layout.indexOf(window.canvas.scroll),
            window.canvas.layout.indexOf(window.canvas.chart_elements_bar),
        )
        self.assertEqual(set(window.chart_element_actions), expected_action_keys)
        self.assertIsNotNone(window.chart_elements_menu)

        checkable_action_keys = expected_action_keys - {
            "add_custom_overlay",
        }
        self.assertTrue(
            all(
                window.chart_element_actions[key].isCheckable()
                for key in checkable_action_keys
            )
        )

        window._render_timer.stop()
        with mock.patch.object(window, "render") as render, mock.patch.object(
            window.canvas.canvas,
            "draw",
        ) as draw, mock.patch.object(
            window.canvas.canvas,
            "draw_idle",
        ) as draw_idle:
            window.chart_elements_menu.aboutToShow.emit()

        render.assert_not_called()
        draw.assert_not_called()
        draw_idle.assert_not_called()
        self.assertFalse(window._render_timer.isActive())
        self.assertTrue(window.chart_element_actions["summary_none"].isChecked())
        self.assertFalse(window.chart_element_actions["summary_median"].isChecked())
        self.assertFalse(window.chart_element_actions["summary_mean"].isChecked())
        self.assertFalse(window.chart_element_actions["secondary_axis"].isEnabled())
        self.assertEqual(
            {
                "legend": window.show_legend.isChecked(),
                "stats_table": window.show_stat_table.isChecked(),
                "points": window.show_points.isChecked(),
                "outliers": window.show_outliers.isChecked(),
                "grid": window.show_grid.isChecked(),
                "custom_overlay": window.extra_custom_overlay.isChecked(),
                "secondary_axis": window.custom_overlay_secondary_axis.isChecked(),
                "split_secondary_axis": window.split_secondary_axis.isChecked(),
                "line_values": window.show_line_values.isChecked(),
            },
            {
                key: window.chart_element_actions[key].isChecked()
                for key in (
                    "legend",
                    "stats_table",
                    "points",
                    "outliers",
                    "grid",
                    "custom_overlay",
                    "secondary_axis",
                    "split_secondary_axis",
                    "line_values",
                )
            },
        )

    def test_chart_elements_button_hides_the_redundant_menu_indicator(self):
        window = self.make_window()
        button = window.canvas.findChild(QAbstractButton, "chartElementsButton")

        self.assertIsNotNone(button)
        self.assertIs(button.menu(), window.chart_elements_menu)
        stylesheet = app_theme.APP_THEME_OVERRIDES
        self.assertIn("QPushButton#chartElementsButton::menu-indicator", stylesheet)
        self.assertIn("image: none", stylesheet)
        self.assertIn("width: 0px", stylesheet)

    def test_chart_element_visibility_actions_update_settings_with_one_debounced_render(self):
        window = self.make_window()
        window.chart_elements_menu.aboutToShow.emit()
        toggles = (
            ("legend", window.show_legend, "show_legend"),
            ("stats_table", window.show_stat_table, "show_stat_table"),
            ("points", window.show_points, "show_points"),
            ("outliers", window.show_outliers, "show_outliers"),
            ("grid", window.show_grid, "show_grid"),
        )

        window._render_timer.stop()
        with mock.patch.object(window, "render") as render:
            for action_key, checkbox, setting_name in toggles:
                with self.subTest(action_key=action_key):
                    self.assertTrue(checkbox.isChecked())
                    self.assertTrue(getattr(window.settings, setting_name))

                    window.chart_element_actions[action_key].trigger()

                    self.assertFalse(checkbox.isChecked())
                    self.assertFalse(getattr(window.settings, setting_name))

            self.assertTrue(window._render_timer.isActive())
            window.flush_pending_render()

        render.assert_called_once_with()

    def test_chart_element_summary_actions_are_exclusive_and_can_return_to_none(self):
        window = self.make_window()
        actions = window.chart_element_actions
        summary_actions = {
            "summary_none": "None",
            "summary_median": "Median",
            "summary_mean": "Mean",
        }

        window.chart_elements_menu.aboutToShow.emit()
        self.assertEqual(
            [key for key in summary_actions if actions[key].isChecked()],
            ["summary_none"],
        )

        window._render_timer.stop()
        with mock.patch.object(window, "render") as render:
            for action_key in ("summary_median", "summary_mean", "summary_none"):
                with self.subTest(action_key=action_key):
                    actions[action_key].trigger()

                    self.assertEqual(
                        window.line_overlay_stat.currentText(),
                        summary_actions[action_key],
                    )
                    self.assertEqual(
                        window.settings.line_overlay_stat,
                        summary_actions[action_key],
                    )
                    self.assertEqual(
                        [key for key in summary_actions if actions[key].isChecked()],
                        [action_key],
                    )

            actions["summary_median"].trigger()
            window.chart_elements_menu.aboutToShow.emit()
            self.assertTrue(actions["line_values"].isEnabled())
            actions["line_values"].trigger()
            self.assertTrue(window.show_line_values.isChecked())
            self.assertTrue(window.settings.show_line_values)

            self.assertTrue(window._render_timer.isActive())
            window.flush_pending_render()

        render.assert_called_once_with()

    def test_add_custom_overlay_stays_visible_when_summary_line_is_none(self):
        window = self.make_window()
        actions = window.chart_element_actions

        self.assertEqual(window.line_overlay_stat.currentText(), "None")
        self.assertEqual(window.custom_overlay_row_count(), 0)

        actions["add_custom_overlay"].trigger()
        window.chart_elements_menu.aboutToShow.emit()

        self.assertEqual(window.line_overlay_stat.currentText(), "None")
        self.assertEqual(window.custom_overlay_row_count(), 1)
        self.assertTrue(window.extra_custom_overlay.isChecked())
        self.assertTrue(window.settings.extra_custom_overlay)
        self.assertTrue(actions["custom_overlay"].isEnabled())
        self.assertTrue(actions["custom_overlay"].isChecked())
        self.assertTrue(actions["secondary_axis"].isEnabled())

    def test_chart_element_secondary_axis_requires_a_row_and_reenables_custom_overlay(self):
        window = self.make_window()
        actions = window.chart_element_actions

        window.chart_elements_menu.aboutToShow.emit()
        self.assertEqual(window.custom_overlay_row_count(), 0)
        self.assertFalse(actions["custom_overlay"].isEnabled())
        self.assertFalse(actions["secondary_axis"].isEnabled())
        self.assertFalse(actions["split_secondary_axis"].isEnabled())

        window._render_timer.stop()
        with mock.patch.object(window, "render") as render:
            actions["add_custom_overlay"].trigger()

            self.assertEqual(window.custom_overlay_row_count(), 1)
            self.assertTrue(window.extra_custom_overlay.isChecked())
            self.assertTrue(window.settings.extra_custom_overlay)

            window.chart_elements_menu.aboutToShow.emit()
            self.assertTrue(actions["custom_overlay"].isEnabled())
            self.assertTrue(actions["custom_overlay"].isChecked())
            self.assertTrue(actions["secondary_axis"].isEnabled())
            self.assertFalse(actions["split_secondary_axis"].isEnabled())

            actions["custom_overlay"].trigger()
            self.assertFalse(window.extra_custom_overlay.isChecked())
            self.assertFalse(window.settings.extra_custom_overlay)

            window.chart_elements_menu.aboutToShow.emit()
            self.assertTrue(actions["secondary_axis"].isEnabled())
            actions["secondary_axis"].trigger()

            self.assertTrue(window.extra_custom_overlay.isChecked())
            self.assertTrue(window.settings.extra_custom_overlay)
            self.assertTrue(window.custom_overlay_secondary_axis.isChecked())
            self.assertTrue(window.settings.custom_overlay_secondary_axis)

            window.chart_elements_menu.aboutToShow.emit()
            self.assertTrue(actions["secondary_axis"].isChecked())
            self.assertTrue(actions["split_secondary_axis"].isEnabled())
            actions["split_secondary_axis"].trigger()
            self.assertTrue(window.split_secondary_axis.isChecked())
            self.assertTrue(window.settings.split_secondary_axis)

            self.assertTrue(window._render_timer.isActive())
            window.flush_pending_render()

        render.assert_called_once_with()

    def test_chart_element_secondary_axis_reshows_all_hidden_custom_overlays(self):
        window = self.make_window()
        actions = window.chart_element_actions

        actions["add_custom_overlay"].trigger()
        window.custom_overlay_secondary_axis.setChecked(True)
        window.settings.extra_custom_overlay = True
        window.settings.custom_overlay_secondary_axis = True
        window.settings.custom_overlay_hidden = [0]

        self.assertEqual(window.custom_overlay_row_count(), 1)
        self.assertTrue(window.extra_custom_overlay.isChecked())
        self.assertTrue(window.custom_overlay_secondary_axis.isChecked())

        window.chart_elements_menu.aboutToShow.emit()

        self.assertFalse(actions["custom_overlay"].isChecked())
        self.assertFalse(actions["secondary_axis"].isChecked())

        window._render_timer.stop()
        window._render_pending = False
        with mock.patch.object(window, "render") as render:
            actions["secondary_axis"].trigger()

            self.assertEqual(window.settings.custom_overlay_hidden, [])
            self.assertTrue(window.extra_custom_overlay.isChecked())
            self.assertTrue(window.settings.extra_custom_overlay)
            self.assertTrue(window.custom_overlay_secondary_axis.isChecked())
            self.assertTrue(window.settings.custom_overlay_secondary_axis)

            window.chart_elements_menu.aboutToShow.emit()
            self.assertTrue(actions["custom_overlay"].isChecked())
            self.assertTrue(actions["secondary_axis"].isChecked())

            self.assertTrue(window._render_timer.isActive())
            window.flush_pending_render()

        render.assert_called_once_with()

    def test_render_restores_existing_selection_feedback(self):
        window = main_window.MainWindow()
        legend_target = next(
            target
            for target in window.canvas._interaction_targets
            if target["kind"] == "legend"
        )
        bbox = legend_target["bbox"]
        event = SimpleNamespace(
            x=(bbox.x0 + bbox.x1) / 2,
            y=(bbox.y0 + bbox.y1) / 2,
            button=1,
        )
        window.canvas._handle_plot_click(event)

        window.render()

        self.assertEqual(window.canvas._selected_object_kind, "legend")
        self.assertIsNotNone(window.canvas._selected_feedback_patch)
        self.assertFalse(window.ui.inspectorContextFrame.isHidden())
        self.assertEqual(
            {group for group in window._inspector_groups() if not group.isHidden()},
            {window.legend_group},
        )

    def test_render_clears_selection_context_when_selected_object_disappears(self):
        window = main_window.MainWindow()
        legend_target = next(
            target
            for target in window.canvas._interaction_targets
            if target["kind"] == "legend"
        )
        bbox = legend_target["bbox"]
        event = SimpleNamespace(
            x=(bbox.x0 + bbox.x1) / 2,
            y=(bbox.y0 + bbox.y1) / 2,
            button=1,
        )
        window.canvas._handle_plot_click(event)

        window.show_legend.setChecked(False)
        window.flush_pending_render()

        self.assertIsNone(window.canvas._selected_object_kind)
        self.assertIsNone(window.canvas._selected_feedback_patch)
        self.assertFalse(window.ui.inspectorContextFrame.isHidden())
        self.assertIn("All settings", window.ui.inspectorContextLabel.text())
        self.assertFalse(window.ui.inspectorShowAllButton.isHidden())
        self.assertFalse(window.ui.inspectorShowAllButton.isEnabled())
        self.assertEqual(
            {group for group in window._inspector_groups() if not group.isHidden()},
            window._mode_inspector_groups(),
        )

    def test_type_specific_rows_follow_chart_type_and_group_title(self):
        window = self.make_window()
        rows = {
            "box_width": window.ui.boxWidthLabel,
            "bar_width": window.ui.barWidthLabel,
            "bar_summary": window.ui.barSummaryLabel,
            "box_whisker": window.ui.boxWhiskerLabel,
            "violin_width": window.ui.violinWidthLabel,
            "kde_bandwidth": window.ui.kdeBandwidthLabel,
            "ridge_overlap": window.ui.ridgeOverlapLabel,
            "fill_alpha": window.ui.fillAlphaLabel,
        }
        expected_visible_rows = {
            "Box": {"box_width", "box_whisker", "fill_alpha"},
            "Bar": {"bar_width", "bar_summary", "fill_alpha"},
            "Violin": {"violin_width", "kde_bandwidth", "fill_alpha"},
            "Ridge": {"kde_bandwidth", "ridge_overlap", "fill_alpha"},
        }

        for chart_type, visible_row_names in expected_visible_rows.items():
            with self.subTest(chart_type=chart_type):
                window.chart_type.setCurrentText(chart_type)

                self.assertEqual(window.ui.specificGroup.title(), f"{chart_type} Style")
                self.assertEqual(
                    {
                        row_name
                        for row_name, label in rows.items()
                        if window.ui.specificForm.isRowVisible(label)
                    },
                    visible_row_names,
                )

    def test_split_inspector_groups_keep_high_frequency_controls_first(self):
        window = self.make_window()

        def labels_in_row_order(form):
            return [
                (form.itemAt(row, QFormLayout.LabelRole)
                 or form.itemAt(row, QFormLayout.SpanningRole)).widget()
                for row in range(form.rowCount())
            ]

        self.assertEqual(
            labels_in_row_order(window.ui.titleAxisForm),
            [
                window.ui.titleLabel,
                window.ui.xLabelLabel,
                window.ui.yLabelLabel,
                window.ui.secondaryYLabelLabel,
            ],
        )
        self.assertEqual(
            labels_in_row_order(window.ui.categoryAxisForm),
            [
                window.ui.autoXRangeLabel,
                window.ui.xMinLabel,
                window.ui.xMaxLabel,
                window.ui.xAutoTickIntervalLabel,
                window.ui.xTickIntervalLabel,
                window.ui.xRotationLabel,
                window.ui.parentGroupSpacingLabel,
                window.ui.groupLayoutButton,
            ],
        )
        self.assertEqual(
            labels_in_row_order(window.ui.primaryAxisForm),
            [
                window.ui.autoYLabel,
                window.ui.yMinLabel,
                window.ui.yMaxLabel,
                window.ui.primaryAutoTickIntervalLabel,
                window.ui.primaryTickIntervalLabel,
            ],
        )
        self.assertEqual(
            labels_in_row_order(window.ui.axesAppearanceForm),
            [window.ui.showGridLabel, window.ui.axisLineWidthLabel],
        )
        self.assertEqual(
            labels_in_row_order(window.ui.secondaryAxisForm),
            [
                window.ui.secondaryAutoYLabel,
                window.ui.secondaryYMinLabel,
                window.ui.secondaryYMaxLabel,
                window.ui.secondaryAutoTickIntervalLabel,
                window.ui.secondaryTickIntervalLabel,
                window.ui.splitSecondaryAxisLabel,
                window.ui.secondaryAxisSplitRatioLabel,
            ],
        )
        self.assertEqual(
            labels_in_row_order(window.ui.pointsForm),
            [
                window.ui.showPointsLabel,
                window.ui.pointSizeLabel,
                window.ui.pointAlphaLabel,
                window.ui.xyMarkerLabel,
                window.ui.jitterModeLabel,
                window.ui.jitterLabel,
                window.ui.xyShowLineLabel,
                window.ui.xyLineWidthLabel,
                window.ui.xyLineStyleLabel,
            ],
        )
        self.assertEqual(
            labels_in_row_order(window.ui.outliersForm),
            [
                window.ui.highlightLabel,
                window.ui.outlierMethodLabel,
                window.ui.thresholdLabel,
                window.ui.effectLabel,
            ],
        )

        expected_parents = {
            window.ui.titleAxisGroup: (
                window.title,
                window.x_label,
                window.y_label,
                window.secondary_y_label,
            ),
            window.ui.categoryAxisGroup: (
                window.auto_x_range,
                window.x_min,
                window.x_max,
                window.x_auto_tick_interval,
                window.x_tick_interval,
                window.x_tick_rotation,
            ),
            window.ui.primaryAxisGroup: (
                window.auto_y_range,
                window.y_min,
                window.y_max,
                window.primary_auto_tick_interval,
                window.primary_tick_interval,
            ),
            window.ui.axesAppearanceGroup: (
                window.show_grid,
                window.axis_line_width,
            ),
            window.ui.secondaryAxisGroup: (
                window.secondary_auto_y_range,
                window.secondary_y_min,
                window.secondary_y_max,
                window.secondary_auto_tick_interval,
                window.secondary_tick_interval,
                window.split_secondary_axis,
                window.secondary_axis_split_ratio,
            ),
            window.ui.lineOverlayGroup: (
                window.custom_overlay_secondary_axis_label,
                window.custom_overlay_secondary_axis,
            ),
            window.ui.pointsGroup: (
                window.show_points,
                window.point_size,
                window.point_alpha,
                window.jitter_mode,
                window.jitter,
            ),
            window.ui.outliersGroup: (
                window.show_outliers,
                window.outlier_method,
                window.outlier_threshold,
                window.outlier_effect,
            ),
        }
        for expected_parent, controls in expected_parents.items():
            for control in controls:
                self.assertIs(control.parentWidget(), expected_parent)

        self.assertLess(
            window.ui.controlsLayout.indexOf(window.ui.categoryAxisGroup),
            window.ui.controlsLayout.indexOf(window.ui.primaryAxisGroup),
        )
        self.assertLess(
            window.ui.controlsLayout.indexOf(window.ui.primaryAxisGroup),
            window.ui.controlsLayout.indexOf(window.ui.axesAppearanceGroup),
        )
        self.assertLess(
            window.ui.controlsLayout.indexOf(window.ui.axesAppearanceGroup),
            window.ui.controlsLayout.indexOf(window.ui.secondaryAxisGroup),
        )
        self.assertLess(
            window.ui.controlsLayout.indexOf(window.ui.pointsGroup),
            window.ui.controlsLayout.indexOf(window.ui.outliersGroup),
        )

    def test_axis_group_titles_follow_chart_orientation_and_keep_category_rotation_visible(self):
        window = self.make_window()
        expected_titles = {
            "Box": ("X Axis", "Primary Y Axis", "Secondary Y Axis"),
            "Violin": ("X Axis", "Primary Y Axis", "Secondary Y Axis"),
            "Ridge": ("Y Axis", "Primary X Axis", "Secondary X Axis"),
        }

        for chart_type, titles in expected_titles.items():
            with self.subTest(chart_type=chart_type):
                window.chart_type.setCurrentText(chart_type)

                self.assertEqual(
                    (
                        window.ui.categoryAxisGroup.title(),
                        window.ui.primaryAxisGroup.title(),
                        window.ui.secondaryAxisGroup.title(),
                    ),
                    titles,
                )
                self.assertTrue(
                    window.ui.categoryAxisForm.isRowVisible(window.ui.xRotationLabel)
                )

    def test_title_and_table_focus_keep_inspector_group_height_stable(self):
        window = main_window.MainWindow()
        window.resize(1400, 1200)
        window.show()
        self.qapp.processEvents()

        self.assertEqual(window.ui.controlsLayout.alignment(), Qt.AlignTop)
        for group in window._inspector_groups():
            self.assertEqual(group.sizePolicy().verticalPolicy(), QSizePolicy.Maximum)

        for object_kind, group in (
            ("title_axis", window.ui.titleAxisGroup),
            ("stats_table", window.ui.statsTableGroup),
        ):
            with self.subTest(object_kind=object_kind):
                window.handle_plot_object_selection(object_kind)
                self.qapp.processEvents()

                self.assertEqual(group.height(), group.sizeHint().height())

    def test_split_secondary_frame_hover_does_not_change_inspector_selection(self):
        window = main_window.MainWindow()
        settings = ChartSettings(
            show_stat_table=False,
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )
        window.canvas.render(window.table.dataframe(), settings)
        window.handle_plot_object_selection("plot_area")
        secondary_target = next(
            target
            for target in window.canvas._interaction_targets
            if target.get("selection_kind") == "line_overlay"
        )
        bbox = secondary_target["bbox"]
        event = SimpleNamespace(x=(bbox.x0 + bbox.x1) / 2, y=(bbox.y0 + bbox.y1) / 2, button=1)
        callback = mock.Mock(wraps=window.handle_plot_object_selection)
        window.canvas.selection_callback = callback

        window.canvas._handle_plot_motion(event)

        visible_groups = {group for group in window._inspector_groups() if not group.isHidden()}
        self.assertEqual(window.canvas._hover_object_kind, "line_overlay")
        callback.assert_not_called()
        self.assertEqual(visible_groups, {window.ui.specificGroup})

        window.canvas._handle_plot_click(event)

        callback.assert_called_once_with("line_overlay")
        visible_groups = {group for group in window._inspector_groups() if not group.isHidden()}
        self.assertEqual(visible_groups, {window.ui.lineOverlayGroup})

    def test_plot_canvas_has_zoom_to_fit_button(self):
        window = self.make_window()

        button = window.canvas.findChild(QPushButton, "zoomToFitButton")

        self.assertIsNotNone(button)
        self.assertEqual(button.text(), "Fit")

    def test_plot_canvas_keeps_coordinates_without_matplotlib_buttons(self):
        window = self.make_window()

        toolbar = window.canvas.toolbar
        button = window.canvas.findChild(QPushButton, "zoomToFitButton")

        self.assertIsInstance(toolbar, plotting_canvas.CoordinatesToolbar)
        self.assertEqual(len(toolbar.actions()), 1)
        self.assertIs(toolbar.actions()[0].defaultWidget(), toolbar.locLabel)
        self.assertEqual(toolbar.locLabel.objectName(), "plotCoordinatesLabel")
        self.assertLess(window.canvas.zoom_layout.indexOf(toolbar), window.canvas.zoom_layout.indexOf(button))

    def test_plot_coordinates_reserve_stable_width_before_text_is_shown(self):
        window = self.make_window()
        toolbar = window.canvas.toolbar
        representative_coordinates = "x=−12345.678 y=−98765.432"
        initial_minimum_width = window.canvas.minimumSizeHint().width()

        toolbar.set_message(representative_coordinates)
        self.qapp.processEvents()

        self.assertGreaterEqual(
            toolbar.locLabel.minimumWidth(),
            toolbar.locLabel.fontMetrics().horizontalAdvance(representative_coordinates),
        )
        self.assertEqual(window.canvas.minimumSizeHint().width(), initial_minimum_width)

        toolbar.set_message("x=−123456789012345.678 y=−987654321098765.432")
        self.qapp.processEvents()

        self.assertEqual(window.canvas.minimumSizeHint().width(), initial_minimum_width)

    def test_plot_coordinates_repaint_immediately_without_a_layout_change(self):
        window = self.make_window()
        toolbar = window.canvas.toolbar

        with mock.patch.object(toolbar.locLabel, "repaint") as repaint:
            toolbar.set_message("x=1.23 y=4.56")
            toolbar.set_message("x=1.24 y=4.57")

        self.assertEqual(toolbar.locLabel.text(), "x=1.24 y=4.57")
        self.assertEqual(repaint.call_count, 2)

    def test_title_and_axis_label_edits_debounce_render(self):
        window = main_window.MainWindow()

        with mock.patch.object(window.canvas, "render") as render, mock.patch.object(window.canvas.canvas, "draw") as draw:
            window.title.setPlainText("First title")
            window.title.setPlainText("Final title")

            self.assertEqual(window.settings.title, "Final title")
            self.assertTrue(window._render_timer.isActive())
            render.assert_not_called()

            window.flush_pending_render()

        render.assert_not_called()
        draw.assert_called_once()
        self.assertEqual(window.canvas.figure.axes[0].get_title(), "Final title")

    def test_text_only_render_updates_cached_settings_and_title_hit_boxes(self):
        window = main_window.MainWindow()
        title_target = next(
            target
            for target in window.canvas._interaction_targets
            if target["kind"] == "title_axis"
        )
        renderer = window.canvas.canvas.get_renderer()
        original_artist_bbox = window.canvas.figure.axes[0].title.get_window_extent(renderer)
        original_hit_bbox = min(
            title_target["hit_bboxes"],
            key=lambda bbox: abs(bbox.y0 - original_artist_bbox.y0)
            + abs(bbox.y1 - original_artist_bbox.y1),
        ).frozen()
        updated_title = "A substantially wider updated title for hit testing"

        window.title.setPlainText(updated_title)
        window.flush_pending_render()
        window.canvas.canvas.draw()

        self.assertEqual(window.canvas._last_settings.title, updated_title)
        refreshed_target = next(
            target
            for target in window.canvas._interaction_targets
            if target["kind"] == "title_axis"
        )
        renderer = window.canvas.canvas.get_renderer()
        updated_artist_bbox = window.canvas.figure.axes[0].title.get_window_extent(renderer)
        updated_hit_bbox = min(
            refreshed_target["hit_bboxes"],
            key=lambda bbox: abs(bbox.y0 - updated_artist_bbox.y0)
            + abs(bbox.y1 - updated_artist_bbox.y1),
        )

        self.assertGreater(updated_hit_bbox.width, original_hit_bbox.width)
        self.assertAlmostEqual(updated_hit_bbox.x0, updated_artist_bbox.x0, delta=1.0)
        self.assertAlmostEqual(updated_hit_bbox.x1, updated_artist_bbox.x1, delta=1.0)
        self.assertAlmostEqual(updated_hit_bbox.y0, updated_artist_bbox.y0, delta=1.0)
        self.assertAlmostEqual(updated_hit_bbox.y1, updated_artist_bbox.y1, delta=1.0)

    def test_zoom_after_text_only_edit_keeps_current_title(self):
        window = main_window.MainWindow()
        updated_title = "Current title survives preview zoom"
        window.title.setPlainText(updated_title)
        window.flush_pending_render()

        window.canvas.zoom_by(1.12)

        self.assertEqual(window.canvas.figure.axes[0].get_title(), updated_title)
        self.assertEqual(window.canvas._last_settings.title, updated_title)

    def test_non_text_control_changes_debounce_one_full_render(self):
        window = main_window.MainWindow()

        with mock.patch.object(window.canvas, "render") as render:
            for index in range(20):
                value = 1.0 + index * 0.5
                window.point_size.setValue(value)

            self.assertEqual(window.settings.point_size, 10.5)
            self.assertTrue(window._render_pending)
            self.assertTrue(window._render_timer.isActive())
            self.assertEqual(window._scheduled_render_mode, main_window.RenderMode.FULL)
            render.assert_not_called()

            window.flush_pending_render()

        render.assert_called_once()

    def test_settings_fast_path_skips_table_read_and_structure_refresh_until_flush(self):
        window = main_window.MainWindow()

        with mock.patch.object(window._table_controller, "refresh_structure") as refresh, \
             mock.patch.object(
                 window._table_controller,
                 "dataframe",
                 wraps=window._table_controller.dataframe,
             ) as dataframe, \
             mock.patch.object(window.canvas, "render") as render:
            window.point_alpha.setValue(0.65)

            refresh.assert_not_called()
            dataframe.assert_not_called()
            render.assert_not_called()

            window.flush_pending_render()

        refresh.assert_not_called()
        dataframe.assert_called_once_with()
        render.assert_called_once()

    def test_overlay_row_sync_rebuilds_only_when_target_count_changes(self):
        window = self.make_window()

        with mock.patch.object(window, "refresh_table_structure") as refresh, \
             mock.patch.object(window, "set_table_dataframe") as set_dataframe:
            window.sync_custom_overlay_rows(existing_series=[])

            refresh.assert_not_called()
            set_dataframe.assert_not_called()

            target = [{"name": "Target", "values": {"Control": "10"}}]
            window.settings.custom_overlay_series = target
            window.sync_custom_overlay_rows()

        set_dataframe.assert_called_once()
        self.assertEqual(set_dataframe.call_args.args[1], target)

    def test_secondary_axis_title_edits_debounce_render_with_stat_table(self):
        window = main_window.MainWindow()
        window.add_custom_overlay_row()
        window.custom_overlay_secondary_axis.setChecked(True)
        for col in range(window.table.table_model.columnCount()):
            window.table.table_model.set_cell_text(1, col, str(50 + col * 10))
        window.update_settings()
        window.flush_pending_render()

        with mock.patch.object(window.canvas, "render") as render, mock.patch.object(window.canvas.canvas, "draw") as draw:
            window.secondary_y_label.setPlainText("Secondary Axis")
            self.assertEqual(window.settings.secondary_y_label, "Secondary Axis")
            self.assertTrue(window._render_timer.isActive())
            render.assert_not_called()

            window.flush_pending_render()

        render.assert_not_called()
        draw.assert_called_once()
        secondary_ax = next(axis for axis in window.canvas.figure.axes if axis.get_gid() == "secondary-axis")
        self.assertEqual(secondary_ax.yaxis.label.get_text(), "Secondary Axis")

    def test_multiline_secondary_axis_title_uses_full_render_for_layout_width(self):
        window = main_window.MainWindow()
        window.add_custom_overlay_row()
        window.custom_overlay_secondary_axis.setChecked(True)
        for col in range(window.table.table_model.columnCount()):
            window.table.table_model.set_cell_text(1, col, str(50 + col * 10))
        window.update_settings()
        initial_width = window.canvas.canvas.width()

        with mock.patch.object(window.canvas.canvas, "draw_idle") as draw_idle:
            window.secondary_y_label.setPlainText("Secondary\nAxis\nTitle")
            window.flush_pending_render()

        draw_idle.assert_not_called()
        self.assertGreater(window.canvas.canvas.width(), initial_width)
        secondary_ax = next(axis for axis in window.canvas.figure.axes if axis.get_gid() == "secondary-axis")
        self.assertEqual(secondary_ax.yaxis.label.get_text(), "Secondary\nAxis\nTitle")

    def test_text_only_render_falls_back_without_axes(self):
        window = main_window.MainWindow()
        window.title.setPlainText("Fallback title")
        window.canvas.figure.clf()

        with mock.patch.object(window.canvas, "render") as render:
            window.flush_pending_render()

        render.assert_called_once()

    def test_multiline_title_edit_uses_full_render_for_layout_height(self):
        window = main_window.MainWindow()
        initial_height = window.canvas.canvas.height()

        with mock.patch.object(window.canvas.canvas, "draw_idle") as draw_idle:
            window.title.setPlainText("Line 1\nLine 2\nLine 3")
            window.flush_pending_render()

        draw_idle.assert_not_called()
        self.assertGreater(window.canvas.canvas.height(), initial_height)
        self.assertEqual(window.canvas.figure.axes[0].get_title(), "Line 1\nLine 2\nLine 3")

    def test_full_render_overrides_pending_text_only_render(self):
        window = main_window.MainWindow()

        with mock.patch.object(window.canvas, "render") as render:
            window.title.setPlainText("Pending title")
            self.assertTrue(window._render_timer.isActive())

            window.chart_type.setCurrentText("Ridge")

            self.assertTrue(window._render_pending)
            self.assertTrue(window._render_timer.isActive())
            self.assertEqual(window._scheduled_render_mode, main_window.RenderMode.FULL)
            render.assert_not_called()

            window.flush_pending_render()

        render.assert_called_once()

    def test_trackpad_gesture_zoom_is_disabled(self):
        window = self.make_window()

        self.assertFalse(hasattr(window.canvas, "handle_zoom_event"))

    def test_user_preset_change_clears_custom_group_colors(self):
        window = self.make_window()
        window.settings.custom_colors = {"Control": "#446688"}
        window.settings.custom_overlay_colors = {"custom:0": "#884466"}

        window.preset.setCurrentText("Presentation")

        self.assertEqual(window.settings.preset, "Presentation")
        self.assertEqual(window.settings.custom_colors, {})
        self.assertEqual(window.settings.custom_overlay_colors, {})

    def test_group_color_preview_debounces_consecutive_full_renders(self):
        window = self.make_window(initial_render=False)
        first = GroupColorSelection(
            preset=window.settings.preset,
            custom_colors={"Control": "#112233"},
            overlay_palette=window.settings.custom_overlay_palette,
            overlay_colors={},
        )
        second = GroupColorSelection(
            preset=window.settings.preset,
            custom_colors={"Control": "#445566"},
            overlay_palette=window.settings.custom_overlay_palette,
            overlay_colors={},
        )

        with mock.patch.object(window, "render") as render:
            window._preview_group_color_selection(first)
            window._preview_group_color_selection(second)

            render.assert_not_called()
            self.assertTrue(window._render_pending)
            self.assertTrue(window._render_timer.isActive())
            self.assertEqual(
                window._render_timer.interval(),
                main_window.COLOR_PREVIEW_RENDER_DEBOUNCE_MS,
            )
            window.flush_pending_render()

        render.assert_called_once_with()
        self.assertEqual(window.settings.custom_colors, second.custom_colors)

    def test_group_color_accept_flushes_one_pending_preview_without_duplicate_render(self):
        window = self.make_window(initial_render=False)
        selection = GroupColorSelection(
            preset=window.settings.preset,
            custom_colors={"Control": "#112233"},
            overlay_palette=window.settings.custom_overlay_palette,
            overlay_colors={},
        )

        def execute(
            _parent,
            _settings,
            _groups,
            _overlays,
            preview,
            _polish,
            **_kwargs,
        ):
            preview(selection)
            return selection

        with mock.patch.object(main_window, "run_group_colors_dialog", side_effect=execute), \
             mock.patch.object(window, "render") as render:
            window.edit_group_colors()

        render.assert_called_once_with()
        self.assertFalse(window._render_pending)
        self.assertEqual(window.settings.custom_colors, selection.custom_colors)

    def test_group_color_cancel_restores_original_with_one_render(self):
        window = self.make_window(initial_render=False)
        control_id = window.workbook.active_sheet.column_ids[0]
        window.settings.custom_colors = {control_id: "#112233"}
        original = dict(window.settings.custom_colors)
        preview_selection = GroupColorSelection(
            preset=window.settings.preset,
            custom_colors={control_id: "#445566"},
            overlay_palette=window.settings.custom_overlay_palette,
            overlay_colors={},
        )

        def execute(
            _parent,
            _settings,
            _groups,
            _overlays,
            preview,
            _polish,
            **_kwargs,
        ):
            preview(preview_selection)
            return None

        with mock.patch.object(main_window, "run_group_colors_dialog", side_effect=execute), \
             mock.patch.object(window, "render") as render:
            window.edit_group_colors()

        render.assert_called_once_with()
        self.assertEqual(window.settings.custom_colors, original)

    def test_apply_settings_keeps_loaded_custom_group_colors(self):
        window = self.make_window()
        window.settings.preset = "Presentation"
        window.settings.custom_colors = {"Control": "#446688"}

        window.apply_settings_to_controls()

        self.assertEqual(window.preset.currentText(), "Presentation")
        self.assertEqual(window.settings.custom_colors, {"Control": "#446688"})

    def test_apply_settings_does_not_overwrite_loaded_spinbox_values(self):
        window = self.make_window()
        window.x_tick_rotation.setValue(0)
        window.settings.x_tick_rotation = 65
        window.settings.line_overlay_width = 2.7
        window.settings.point_size = 6.5

        window.apply_settings_to_controls()

        self.assertEqual(window.x_tick_rotation.value(), 65)
        self.assertEqual(window.settings.x_tick_rotation, 65)
        self.assertAlmostEqual(window.line_overlay_width.value(), 2.7)
        self.assertAlmostEqual(window.settings.line_overlay_width, 2.7)
        self.assertAlmostEqual(window.point_size.value(), 6.5)
        self.assertAlmostEqual(window.settings.point_size, 6.5)

    def test_auto_y_range_disables_and_syncs_y_limit_controls(self):
        window = main_window.MainWindow()
        window.auto_y_range.setChecked(True)
        window.update_settings()
        window.flush_pending_render()
        y_min, y_max = window.canvas.figure.axes[0].get_ylim()

        self.assertFalse(window.y_min.isEnabled())
        self.assertFalse(window.y_max.isEnabled())
        self.assertFalse(window.ui.yMinLabel.isEnabled())
        self.assertFalse(window.ui.yMaxLabel.isEnabled())
        self.assertAlmostEqual(window.y_min.value(), y_min, places=2)
        self.assertAlmostEqual(window.y_max.value(), y_max, places=2)
        self.assertAlmostEqual(window.settings.y_min, y_min)
        self.assertAlmostEqual(window.settings.y_max, y_max)

        window.auto_y_range.setChecked(False)
        window.update_settings()
        window.flush_pending_render()

        self.assertTrue(window.y_min.isEnabled())
        self.assertTrue(window.y_max.isEnabled())
        self.assertTrue(window.ui.yMinLabel.isEnabled())
        self.assertTrue(window.ui.yMaxLabel.isEnabled())

    def test_auto_y_range_uses_double_default_padding(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(show_stat_table=False, show_points=False, show_outliers=False, auto_y_range=True)
        df = pd.DataFrame({"A": [0, 10], "B": [5, 15]})

        canvas.render(df, settings)

        ax = canvas.figure.axes[0]
        data_min, data_max = ax.dataLim.intervaly
        expected_pad = (data_max - data_min) * layout.AUTO_AXIS_RANGE_PADDING_FRACTION
        self.assertEqual(layout.AUTO_AXIS_RANGE_PADDING_FRACTION, 0.10)
        self.assertAlmostEqual(ax.get_ylim()[0], data_min - expected_pad)
        self.assertAlmostEqual(ax.get_ylim()[1], data_max + expected_pad)
        canvas.close()

    def test_ridge_auto_range_controls_sync_x_axis(self):
        window = main_window.MainWindow()
        window.chart_type.setCurrentText("Ridge")
        window.auto_y_range.setChecked(True)
        window.update_settings()
        window.flush_pending_render()
        x_min, x_max = window.canvas.figure.axes[0].get_xlim()

        self.assertEqual(window.ui.primaryAxisGroup.title(), "Primary X Axis")
        self.assertEqual(window.ui.autoYLabel.text(), "Auto range")
        self.assertEqual(window.ui.yMinLabel.text(), "Minimum")
        self.assertEqual(window.ui.yMaxLabel.text(), "Maximum")
        self.assertFalse(window.y_min.isEnabled())
        self.assertFalse(window.y_max.isEnabled())
        self.assertAlmostEqual(window.y_min.value(), x_min, places=2)
        self.assertAlmostEqual(window.y_max.value(), x_max, places=2)
        self.assertAlmostEqual(window.settings.y_min, x_min)
        self.assertAlmostEqual(window.settings.y_max, x_max)

    def test_ridge_auto_x_range_uses_double_default_padding(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(chart_type="Ridge", show_stat_table=False, show_points=False, show_outliers=False, auto_y_range=True)
        df = pd.DataFrame({"A": [0, 10], "B": [5, 15]})

        canvas.render(df, settings)

        ax = canvas.figure.axes[0]
        data_min, data_max = ax.dataLim.intervalx
        expected_pad = (data_max - data_min) * layout.AUTO_AXIS_RANGE_PADDING_FRACTION
        self.assertAlmostEqual(ax.get_xlim()[0], data_min - expected_pad)
        self.assertAlmostEqual(ax.get_xlim()[1], data_max + expected_pad)
        canvas.close()

    def test_auto_y_range_spinboxes_match_final_overlay_expanded_axis(self):
        window = main_window.MainWindow()
        window.line_overlay_stat.setCurrentText("Median")
        window.add_custom_overlay_row()
        for column, value in enumerate(["10", "1", "2"]):
            window.table.table_model.set_cell_text(1, column, value)
        window.show_line_values.setChecked(True)
        window.line_value_position.setCurrentText("Bottom axis")
        window.custom_line_value_position.setCurrentText("Below")
        window.auto_y_range.setChecked(True)
        window.update_settings()
        window.flush_pending_render()

        y_min, y_max = window.canvas.figure.axes[0].get_ylim()

        self.assertLess(y_min, 0.0)
        self.assertEqual(window.y_min.value(), y_min)
        self.assertEqual(window.y_max.value(), y_max)
        self.assertEqual(window.settings.y_min, y_min)
        self.assertEqual(window.settings.y_max, y_max)

    def test_auto_y_range_spinboxes_match_axis_overlay_label_positions(self):
        base_window = main_window.MainWindow()
        base_window.line_overlay_stat.setCurrentText("Median")
        base_window.show_line_values.setChecked(True)
        base_window.line_value_position.setCurrentText("Above")
        base_window.auto_y_range.setChecked(True)
        base_window.update_settings()
        base_window.flush_pending_render()
        base_y_min, base_y_max = base_window.canvas.figure.axes[0].get_ylim()

        for position in ("Top axis", "Bottom axis"):
            with self.subTest(position=position):
                window = main_window.MainWindow()
                window.line_overlay_stat.setCurrentText("Median")
                window.show_line_values.setChecked(True)
                window.line_value_position.setCurrentText(position)
                window.auto_y_range.setChecked(True)
                window.update_settings()
                window.flush_pending_render()
                y_min, y_max = window.canvas.figure.axes[0].get_ylim()

                self.assertEqual(window.y_min.value(), y_min)
                self.assertEqual(window.y_max.value(), y_max)
                self.assertEqual(window.settings.y_min, y_min)
                self.assertEqual(window.settings.y_max, y_max)
                if position == "Top axis":
                    self.assertEqual(y_min, base_y_min)
                    self.assertGreaterEqual(y_max, base_y_max)
                else:
                    self.assertLessEqual(y_min, base_y_min)
                    self.assertEqual(y_max, base_y_max)

    def test_switching_auto_y_to_manual_keeps_synced_axis_range(self):
        window = main_window.MainWindow()
        window.line_overlay_stat.setCurrentText("Median")
        window.add_custom_overlay_row()
        for column, value in enumerate(["1", "2", "10"]):
            window.table.table_model.set_cell_text(1, column, value)
        window.show_line_values.setChecked(True)
        window.line_value_position.setCurrentText("Bottom axis")
        window.custom_line_value_position.setCurrentText("Auto")
        window.auto_y_range.setChecked(True)
        window.update_settings()
        window.flush_pending_render()
        synced_range = (window.y_min.value(), window.y_max.value())

        window.auto_y_range.setChecked(False)
        window.flush_pending_render()

        self.assertEqual(window.canvas.figure.axes[0].get_ylim(), synced_range)
        self.assertEqual((window.settings.y_min, window.settings.y_max), synced_range)

    def test_line_overlay_style_controls_disable_when_no_overlay_is_active(self):
        window = self.make_window()
        window.show_stat_table.setChecked(False)
        controlled_widgets = [
            window.ui.lineOverlayWidthLabel,
            window.line_overlay_width,
            window.ui.lineOverlayStyleLabel,
            window.line_overlay_style,
            window.ui.lineOverlayPointSizeLabel,
            window.line_overlay_point_size,
            window.ui.showLineValuesLabel,
            window.show_line_values,
            window.ui.lineValueScientificLabel,
            window.line_value_scientific,
            window.ui.lineValueDecimalsLabel,
            window.line_value_decimals,
        ]
        line_value_size_widgets = [window.ui.lineValueSizeLabel, window.line_value_font_size]

        window.line_overlay_stat.setCurrentText("None")
        window.extra_custom_overlay.setChecked(False)
        window.update_settings()

        self.assertTrue(window.line_overlay_stat.isEnabled())
        self.assertTrue(all(not widget.isEnabled() for widget in controlled_widgets))
        self.assertTrue(all(not widget.isEnabled() for widget in line_value_size_widgets))
        self.assertFalse(window.ui.lineValuePositionLabel.isEnabled())
        self.assertFalse(window.line_value_position.isEnabled())
        self.assertFalse(window.ui.customLineValuePositionLabel.isEnabled())
        self.assertFalse(window.custom_line_value_position.isEnabled())

        window.line_overlay_stat.setCurrentText("Median")
        window.update_settings()

        self.assertTrue(all(widget.isEnabled() for widget in controlled_widgets))
        self.assertTrue(all(not widget.isEnabled() for widget in line_value_size_widgets))
        self.assertTrue(window.ui.lineValuePositionLabel.isEnabled())
        self.assertTrue(window.line_value_position.isEnabled())
        self.assertFalse(window.ui.customLineValuePositionLabel.isEnabled())
        self.assertFalse(window.custom_line_value_position.isEnabled())

        window.show_line_values.setChecked(True)
        window.update_settings()

        self.assertTrue(all(widget.isEnabled() for widget in line_value_size_widgets))

        window.line_overlay_stat.setCurrentText("None")
        window.add_custom_overlay_row()
        window.extra_custom_overlay.setChecked(True)
        window.update_settings()

        self.assertFalse(window.ui.lineValuePositionLabel.isEnabled())
        self.assertFalse(window.line_value_position.isEnabled())
        self.assertTrue(window.ui.customLineValuePositionLabel.isEnabled())
        self.assertTrue(window.custom_line_value_position.isEnabled())

    def test_overlay_label_position_controls_are_split_by_series_type(self):
        window = self.make_window()

        stat_options = [window.line_value_position.itemText(index) for index in range(window.line_value_position.count())]
        extra_options = [
            window.custom_line_value_position.itemText(index)
            for index in range(window.custom_line_value_position.count())
        ]

        self.assertIn("Top axis", stat_options)
        self.assertIn("Bottom axis", stat_options)
        self.assertNotIn("Top axis", extra_options)
        self.assertNotIn("Bottom axis", extra_options)
        self.assertNotIn("Axis left", extra_options)
        self.assertNotIn("Axis right", extra_options)

        window.chart_type.setCurrentText("Ridge")
        stat_options = [window.line_value_position.itemText(index) for index in range(window.line_value_position.count())]

        self.assertIn("Axis left", stat_options)
        self.assertIn("Axis right", stat_options)
        self.assertNotIn("Top axis", stat_options)
        self.assertNotIn("Bottom axis", stat_options)

    def test_all_title_controls_stay_together_in_the_title_group(self):
        window = self.make_window()

        self.assertEqual(window.ui.titleLabel.text(), "Chart title")
        self.assertEqual(window.ui.xLabelLabel.text(), "Category axis title")
        self.assertEqual(window.ui.yLabelLabel.text(), "Primary value axis title")
        self.assertEqual(window.secondary_y_label_label.text(), "Secondary value axis title")
        self.assertIs(window.title.parentWidget(), window.ui.titleAxisGroup)
        self.assertIs(window.x_label.parentWidget(), window.ui.titleAxisGroup)
        self.assertIs(window.y_label.parentWidget(), window.ui.titleAxisGroup)
        self.assertIs(window.secondary_y_label_label, window.ui.secondaryYLabelLabel)
        self.assertIs(window.secondary_y_label, window.ui.secondaryYLabelEdit)
        self.assertIs(window.secondary_y_label.parentWidget(), window.ui.titleAxisGroup)
        window.secondary_y_label.setPlainText("Rate\nIndex")
        self.assertEqual(window.secondary_y_label.toPlainText(), "Rate\nIndex")

    def test_custom_overlay_secondary_axis_control_toggles_secondary_range_controls(self):
        window = self.make_window()

        self.assertEqual(window.ui.categoryAxisGroup.title(), "X Axis")
        self.assertEqual(window.ui.primaryAxisGroup.title(), "Primary Y Axis")
        self.assertEqual(window.ui.secondaryAxisGroup.title(), "Secondary Y Axis")
        self.assertFalse(window.ui.categoryAxisGroup.isHidden())
        self.assertFalse(window.ui.primaryAxisGroup.isHidden())
        self.assertFalse(window.ui.secondaryAxisGroup.isHidden())
        self.assertEqual(window.ui.autoYLabel.parent(), window.ui.primaryAxisGroup)
        self.assertEqual(window.primary_tick_interval_label.parent(), window.ui.primaryAxisGroup)
        self.assertIs(window.primary_auto_tick_interval_label, window.ui.primaryAutoTickIntervalLabel)
        self.assertIs(window.primary_auto_tick_interval, window.ui.primaryAutoTickIntervalCheck)
        self.assertIs(window.primary_tick_interval_label, window.ui.primaryTickIntervalLabel)
        self.assertIs(window.primary_tick_interval, window.ui.primaryTickIntervalSpin)
        self.assertEqual(window.secondary_auto_y_range_label.parent(), window.ui.secondaryAxisGroup)
        self.assertEqual(window.secondary_y_min_label.parent(), window.ui.secondaryAxisGroup)
        self.assertEqual(
            window.custom_overlay_secondary_axis_label.text(),
            "Use secondary axis",
        )
        self.assertEqual(window.custom_overlay_secondary_axis_label.parent(), window.ui.lineOverlayGroup)
        self.assertEqual(window.custom_overlay_secondary_axis.parent(), window.ui.lineOverlayGroup)
        self.assertIs(window.secondary_auto_y_range, window.ui.secondaryAutoYRangeCheck)
        self.assertIs(window.secondary_y_min, window.ui.secondaryYMinSpin)
        self.assertIs(window.secondary_y_max, window.ui.secondaryYMaxSpin)
        self.assertIs(window.secondary_auto_tick_interval, window.ui.secondaryAutoTickIntervalCheck)
        self.assertIs(window.secondary_tick_interval, window.ui.secondaryTickIntervalSpin)
        self.assertIs(window.split_secondary_axis, window.ui.splitSecondaryAxisCheck)
        self.assertIs(window.secondary_axis_split_ratio, window.ui.secondaryAxisSplitRatioSpin)
        self.assertFalse(window.custom_overlay_secondary_axis_label.isEnabled())
        self.assertFalse(window.custom_overlay_secondary_axis.isEnabled())
        self.assertFalse(window.secondary_auto_y_range.isEnabled())
        self.assertFalse(window.secondary_y_min.isEnabled())
        self.assertFalse(window.secondary_y_max.isEnabled())
        self.assertFalse(window.secondary_auto_tick_interval.isEnabled())
        self.assertFalse(window.secondary_tick_interval.isEnabled())
        self.assertFalse(window.split_secondary_axis.isEnabled())
        self.assertFalse(window.secondary_axis_split_ratio.isEnabled())

        window.custom_overlay_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.custom_overlay_secondary_axis.isChecked())
        self.assertTrue(window.settings.custom_overlay_secondary_axis)
        self.assertFalse(window.secondary_auto_y_range.isEnabled())
        self.assertFalse(window.split_secondary_axis.isEnabled())

        window.add_custom_overlay_row()

        self.assertTrue(window.custom_overlay_secondary_axis_label.isEnabled())
        self.assertTrue(window.custom_overlay_secondary_axis.isEnabled())

        window.custom_overlay_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.settings.custom_overlay_secondary_axis)
        self.assertTrue(window.secondary_auto_y_range.isEnabled())
        self.assertFalse(window.secondary_y_min.isEnabled())
        self.assertFalse(window.secondary_y_max.isEnabled())
        self.assertTrue(window.secondary_auto_tick_interval.isEnabled())
        self.assertFalse(window.secondary_tick_interval.isEnabled())
        self.assertTrue(window.split_secondary_axis.isEnabled())
        self.assertFalse(window.secondary_axis_split_ratio.isEnabled())

        window.split_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.secondary_axis_split_ratio.isEnabled())

        window.secondary_auto_y_range.setChecked(False)
        window.update_settings()

        self.assertTrue(window.secondary_y_min.isEnabled())
        self.assertTrue(window.secondary_y_max.isEnabled())

        window.secondary_auto_tick_interval.setChecked(False)
        window.update_settings()

        self.assertTrue(window.secondary_tick_interval.isEnabled())

        window.extra_custom_overlay.setChecked(False)
        window.update_settings()

        self.assertTrue(window.custom_overlay_secondary_axis.isChecked())
        self.assertTrue(window.settings.custom_overlay_secondary_axis)
        self.assertFalse(window.custom_overlay_secondary_axis.isEnabled())
        self.assertFalse(window.secondary_auto_y_range.isEnabled())

    def test_selected_custom_overlay_can_enable_and_disable_its_secondary_axis(self):
        for chart_type in ("Box", "Ridge"):
            with self.subTest(chart_type=chart_type):
                window = self.make_window()
                window.chart_type.setCurrentText(chart_type)
                window.add_custom_overlay_row()
                for column in range(window.table.table_model.columnCount()):
                    window.table.table_model.set_cell_text(1, column, str(50 + 10 * column))
                window.flush_pending_render()

                def secondary_axes():
                    return [
                        axis for axis in window.canvas.figure.axes
                        if axis.get_gid() == "secondary-axis"
                    ]

                def overlay_lines(axis):
                    return [line for line in axis.lines if line.get_gid() == "overlay-line"]

                self.assertFalse(window.custom_overlay_secondary_axis.isChecked())
                self.assertEqual(secondary_axes(), [])
                self.assertEqual(len(overlay_lines(window.canvas.figure.axes[0])), 1)

                window.handle_plot_object_selection("line_overlay")

                self.assertEqual(
                    {group for group in window._inspector_groups() if not group.isHidden()},
                    {window.ui.lineOverlayGroup},
                )
                self.assertTrue(window.custom_overlay_secondary_axis.isVisibleTo(window))
                self.assertTrue(window.custom_overlay_secondary_axis.isEnabled())

                window.custom_overlay_secondary_axis.click()
                window.flush_pending_render()

                self.assertTrue(window.settings.custom_overlay_secondary_axis)
                self.assertEqual(len(secondary_axes()), 1)
                self.assertEqual(len(overlay_lines(secondary_axes()[0])), 1)
                self.assertEqual(overlay_lines(window.canvas.figure.axes[0]), [])
                self.assertEqual(window._selected_plot_object_kind, "line_overlay")
                self.assertTrue(window.custom_overlay_secondary_axis.isVisibleTo(window))

                window.custom_overlay_secondary_axis.click()
                window.flush_pending_render()

                self.assertFalse(window.settings.custom_overlay_secondary_axis)
                self.assertEqual(secondary_axes(), [])
                self.assertEqual(len(overlay_lines(window.canvas.figure.axes[0])), 1)
                self.assertEqual(window._selected_plot_object_kind, "line_overlay")

    def test_value_axis_controls_use_group_titles_instead_of_repeating_axis_names(self):
        window = self.make_window()

        self.assertEqual(window.ui.autoYLabel.text(), "Auto range")
        self.assertEqual(window.ui.yMinLabel.text(), "Minimum")
        self.assertEqual(window.ui.yMaxLabel.text(), "Maximum")
        self.assertEqual(window.primary_tick_interval_label.text(), "Tick interval")
        self.assertEqual(window.secondary_auto_y_range_label.text(), "Auto range")
        self.assertEqual(window.secondary_y_min_label.text(), "Minimum")
        self.assertEqual(window.secondary_y_max_label.text(), "Maximum")
        self.assertEqual(window.secondary_tick_interval_label.text(), "Tick interval")

        window.chart_type.setCurrentText("Ridge")
        window.update_settings()

        self.assertEqual(window.ui.categoryAxisGroup.title(), "Y Axis")
        self.assertEqual(window.ui.primaryAxisGroup.title(), "Primary X Axis")
        self.assertEqual(window.ui.secondaryAxisGroup.title(), "Secondary X Axis")
        self.assertEqual(window.ui.autoYLabel.text(), "Auto range")
        self.assertEqual(window.secondary_auto_y_range_label.text(), "Auto range")

    def test_category_tick_rotation_row_stays_available_for_all_chart_types(self):
        window = self.make_window()

        for chart_type in ("Box", "Violin", "Ridge"):
            with self.subTest(chart_type=chart_type):
                window.chart_type.setCurrentText(chart_type)
                window.update_settings()

                self.assertTrue(
                    window.ui.categoryAxisForm.isRowVisible(window.ui.xRotationLabel)
                )
                self.assertTrue(window.x_tick_rotation.isEnabled())

    def test_ridge_secondary_x_axis_controls_support_split_frame(self):
        window = self.make_window()
        window.add_custom_overlay_row()
        window.chart_type.setCurrentText("Ridge")
        window.custom_overlay_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.secondary_auto_y_range.isEnabled())
        self.assertEqual(window.ui.secondaryAxisGroup.title(), "Secondary X Axis")
        self.assertEqual(window.secondary_auto_y_range_label.text(), "Auto range")
        self.assertEqual(window.secondary_y_min_label.text(), "Minimum")
        self.assertEqual(window.secondary_y_max_label.text(), "Maximum")
        self.assertTrue(window.split_secondary_axis.isEnabled())

        window.split_secondary_axis.setChecked(True)
        window.update_settings()

        self.assertTrue(window.settings.split_secondary_axis)
        self.assertTrue(window.secondary_axis_split_ratio.isEnabled())

    def test_secondary_frame_ratio_changes_debounce_full_render(self):
        window = main_window.MainWindow()
        window.add_custom_overlay_row()
        window.custom_overlay_secondary_axis.setChecked(True)
        window.split_secondary_axis.setChecked(True)
        window.update_settings()

        with mock.patch.object(window.canvas, "render") as render:
            window.secondary_axis_split_ratio.setValue(0.45)

            render.assert_not_called()
            self.assertTrue(window._render_timer.isActive())
            window.flush_pending_render()

        render.assert_called_once()
        self.assertEqual(window.settings.secondary_axis_split_ratio, 0.45)

    def test_group_order_controls_plot_order(self):
        df = pd.DataFrame({
            "B": [3, 4],
            "A": [1, 2],
            "C": [5, 6],
        })

        settings = ChartSettings(group_order="Table order")
        clean = data.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["B", "A", "C"])

        settings.group_order = "Name A-Z"
        clean = data.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["A", "B", "C"])

        settings.group_order = "Mean descending"
        clean = data.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["C", "B", "A"])

        settings.group_order = "Manual"
        settings.manual_group_order = ["B", "C", "A"]
        clean = data.prepare_plot_data(df, settings)
        self.assertEqual(list(clean["group"].drop_duplicates()), ["B", "C", "A"])

    def test_custom_overlay_rows_insert_above_sample_values(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        first_sample = model.cell_text(1, 0)

        window.add_custom_overlay_row()
        window.add_custom_overlay_row()

        self.assertEqual(model.headerData(1, Qt.Vertical, Qt.DisplayRole), "Overlay 1")
        self.assertEqual(model.headerData(2, Qt.Vertical, Qt.DisplayRole), "Overlay 2")
        self.assertEqual(model.headerData(3, Qt.Vertical, Qt.DisplayRole), "1")
        self.assertEqual(model.cell_text(3, 0), first_sample)
        self.assertEqual(window.table.dataframe().iloc[0, 0], first_sample)
        overlay_index = model.index(1, 0)
        self.assertEqual(model.data(overlay_index, Qt.TextAlignmentRole), Qt.AlignLeft | Qt.AlignVCenter)
        self.assertNotEqual(model.data(overlay_index, Qt.BackgroundRole).color().name().upper(), "#EAF2FF")

    def test_rename_overlay_row_uses_multiline_text_dialog(self):
        window = main_window.MainWindow()
        window.add_custom_overlay_row()

        with mock.patch.object(main_window.QInputDialog, "getMultiLineText", return_value=("Target\nDay 2", True)) as get_name:
            window.rename_overlay_row(1)

        get_name.assert_called_once()
        self.assertEqual(window.settings.custom_overlay_series[0]["name"], "Target\nDay 2")
        self.assertEqual(window.table.table_model.headerData(1, Qt.Vertical, Qt.DisplayRole), "Target\nDay 2")

    def test_hiding_custom_overlay_preserves_table_values(self):
        window = main_window.MainWindow()
        window.add_custom_overlay_row()
        window.add_custom_overlay_row()
        window.table.table_model.set_cell_text(1, 0, "12")
        window.table.table_model.set_cell_text(2, 0, "34")
        window.settings.custom_overlay_hidden = [1]
        window.update_settings()

        self.assertEqual(window.custom_overlay_row_count(), 2)
        self.assertEqual(window.table.table_model.cell_text(1, 0), "12")
        self.assertEqual(window.table.table_model.cell_text(2, 0), "34")
        clean = data.prepare_plot_data(window._user_group_dataframe(), window.settings)
        self.assertEqual([series["name"] for series in overlay_series.line_overlay_series(clean, window.settings)], ["Overlay 1"])

    def test_overlay_filter_delegates_string_keys_and_stores_integer_indexes(self):
        window = self.make_window()
        window.add_custom_overlay_row()
        window.add_custom_overlay_row()

        with mock.patch.object(main_window, "run_checklist_filter_dialog", return_value=["1"]) as run_dialog:
            window.edit_custom_overlay_filter()

        items = run_dialog.call_args.args[2]
        self.assertEqual([item.key for item in items], ["0", "1"])
        self.assertEqual(window.settings.custom_overlay_hidden, [1])
        self.assertTrue(window.settings.extra_custom_overlay)

    def test_overlay_filter_cancel_leaves_settings_unchanged(self):
        window = self.make_window()
        window.add_custom_overlay_row()
        window.settings.custom_overlay_hidden = [0]

        with mock.patch.object(main_window, "run_checklist_filter_dialog", return_value=None), \
             mock.patch.object(window, "render") as render:
            window.edit_custom_overlay_filter()

        self.assertEqual(window.settings.custom_overlay_hidden, [0])
        render.assert_not_called()

    def test_overlay_styles_accept_applies_typed_result(self):
        window = self.make_window()
        window.add_custom_overlay_row()
        key = overlay_series.overlay_custom_color_key(0)
        result = OverlayStyleSelection({key: "Dashed"})

        with mock.patch.object(main_window, "run_overlay_styles_dialog", return_value=result), \
             mock.patch.object(window, "render") as render:
            window.edit_custom_overlay_styles()

        self.assertEqual(window.settings.custom_overlay_styles, {key: "Dashed"})
        render.assert_called_once_with()

    def test_overlay_styles_cancel_restores_original_after_preview(self):
        window = self.make_window()
        window.add_custom_overlay_row()
        key = overlay_series.overlay_custom_color_key(0)
        original = {key: "Dotted", "stale": "Dashed"}
        window.settings.custom_overlay_styles = dict(original)

        def execute(_parent, _items, _base, _styles, preview, _populate, _polish):
            preview(OverlayStyleSelection({key: "Solid"}))
            return None

        with mock.patch.object(main_window, "run_overlay_styles_dialog", side_effect=execute), \
             mock.patch.object(window, "render") as render:
            window.edit_custom_overlay_styles()

        self.assertEqual(window.settings.custom_overlay_styles, original)
        self.assertEqual(render.call_count, 2)

    def test_overlay_dialogs_report_empty_rows(self):
        window = self.make_window()

        with mock.patch.object(main_window.QMessageBox, "information") as information:
            window.edit_custom_overlay_filter()
            information.assert_called_once_with(
                window,
                "Overlay Filter",
                "Add an overlay row first.",
            )
            information.reset_mock()
            window.edit_custom_overlay_styles()
            information.assert_called_once_with(
                window,
                "Custom Overlay Line Styles",
                "Add an overlay row first.",
            )

    def test_hidden_overlay_keeps_custom_color_when_reshown(self):
        clean = data.prepare_plot_data(self.df, self.settings)
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1"}},
                {"name": "Overlay 2", "values": {"Control": "2"}},
            ],
            custom_overlay_hidden=[1],
            custom_overlay_colors={overlay_series.overlay_custom_color_key(1): "#123456"},
        )

        self.assertEqual([series["name"] for series in overlay_series.line_overlay_series(clean, settings)], ["Overlay 1"])
        self.assertEqual(settings.custom_overlay_colors[overlay_series.overlay_custom_color_key(1)], "#123456")

        settings.custom_overlay_hidden = []

        series = overlay_series.line_overlay_series(clean, settings)
        colors = overlay_series.overlay_palette_for(clean, settings, len(series))
        self.assertEqual([item["name"] for item in series], ["Overlay 1", "Overlay 2"])
        self.assertEqual(colors[1], "#123456")

    def test_remove_custom_overlay_confirms_before_deleting_values(self):
        window = main_window.MainWindow()
        window.add_custom_overlay_row()
        model = window.table.table_model
        model.set_cell_text(1, 0, "12")
        window.table.setCurrentIndex(model.index(1, 0))

        with mock.patch.object(main_window.QMessageBox, "warning", return_value=main_window.QMessageBox.No):
            window.remove_custom_overlay_row()

        self.assertEqual(window.custom_overlay_row_count(), 1)
        self.assertEqual(model.cell_text(1, 0), "12")

        with mock.patch.object(main_window.QMessageBox, "warning", return_value=main_window.QMessageBox.Yes):
            window.remove_custom_overlay_row()

        self.assertEqual(window.custom_overlay_row_count(), 0)
        self.assertEqual(window.settings.custom_overlay_series, [])

    def test_table_editor_arrow_key_commits_and_moves_to_next_cell(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        window.table.setCurrentIndex(model.index(1, 0))
        window.table.edit(model.index(1, 0))
        self.qapp.processEvents()
        editor = window.table.findChild(QLineEdit)

        self.assertIsNotNone(editor)
        editor.setText("123")
        event = QKeyEvent(QEvent.KeyPress, Qt.Key_Right, Qt.KeypadModifier)
        self.qapp.sendEvent(editor, event)
        self.qapp.processEvents()

        self.assertEqual(model.cell_text(1, 0), "123")
        self.assertEqual((window.table.currentIndex().row(), window.table.currentIndex().column()), (1, 1))
        self.assertIsNotNone(window.table.findChild(QLineEdit))

    def test_table_editor_return_key_commits_and_moves_down(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        window.table.setCurrentIndex(model.index(1, 0))
        window.table.edit(model.index(1, 0))
        self.qapp.processEvents()
        editor = window.table.findChild(QLineEdit)

        self.assertIsNotNone(editor)
        editor.setText("456")
        event = QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier)
        qt_messages = []
        previous_handler = qInstallMessageHandler(
            lambda _kind, _context, message: qt_messages.append(message)
        )
        try:
            with mock.patch.object(window, "render") as render:
                self.qapp.sendEvent(editor, event)
                self.qapp.processEvents()
                window.flush_pending_render()
                render.assert_called_once_with()
        finally:
            qInstallMessageHandler(previous_handler)

        self.assertEqual(model.cell_text(1, 0), "456")
        self.assertEqual((window.table.currentIndex().row(), window.table.currentIndex().column()), (2, 0))
        self.assertTrue(window._table_controller.history.can_undo)
        self.assertFalse(
            any("commitData called with an editor" in message for message in qt_messages)
        )

    def test_table_editor_return_from_used_trailing_row_expands_and_moves_down(self):
        window = main_window.MainWindow(initial_render=False)
        model = window.table.table_model
        original_row_count = model.rowCount()
        last_row = original_row_count - 1
        window.table.setCurrentIndex(model.index(last_row, 0))
        window.table.edit(model.index(last_row, 0))
        self.qapp.processEvents()
        editor = window.table.findChild(QLineEdit)

        self.assertIsNotNone(editor)
        editor.setText("789")
        with mock.patch.object(window, "render") as render:
            self.qapp.sendEvent(
                editor,
                QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
            )
            for _ in range(3):
                self.qapp.processEvents()
            window.flush_pending_render()

        self.assertEqual(model.cell_text(last_row, 0), "789")
        self.assertEqual(model.rowCount(), original_row_count + 1)
        self.assertEqual(
            (window.table.currentIndex().row(), window.table.currentIndex().column()),
            (last_row + 1, 0),
        )
        self.assertIsNotNone(window.table.findChild(QLineEdit))
        render.assert_called_once_with()

    def test_xy_table_editor_return_commits_and_moves_down_in_both_views(self):
        window = main_window.MainWindow(initial_render=False)
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        for table in (window.table, window.xy_independent_table):
            with self.subTest(table=table.objectName()):
                model = table.table_model
                table.setCurrentIndex(model.index(1, 0))
                table.edit(model.index(1, 0))
                self.qapp.processEvents()
                editor = table.findChild(QLineEdit)
                self.assertIsNotNone(editor)
                editor.setText("12.5")
                self.qapp.sendEvent(
                    editor,
                    QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
                )
                self.qapp.processEvents()

                self.assertEqual(model.cell_text(1, 0), "12.5")
                self.assertEqual(
                    (table.currentIndex().row(), table.currentIndex().column()),
                    (2, 0),
                )

    def test_table_undo_redo_actions_use_standard_shortcuts(self):
        window = self.make_window()

        self.assertEqual(window.undo_table_action.shortcuts(), QKeySequence.keyBindings(QKeySequence.Undo))
        self.assertEqual(window.redo_table_action.shortcuts(), QKeySequence.keyBindings(QKeySequence.Redo))
        self.assertFalse(window.undo_table_action.isEnabled())
        self.assertFalse(window.redo_table_action.isEnabled())

    def test_file_actions_use_platform_standard_shortcuts(self):
        window = self.make_window()

        self.assertEqual(window.ui.actionOpenProject.shortcuts(), QKeySequence.keyBindings(QKeySequence.Open))
        self.assertEqual(window.ui.actionSaveProject.shortcuts(), QKeySequence.keyBindings(QKeySequence.Save))
        self.assertEqual(window.ui.actionSaveProjectAs.shortcuts(), QKeySequence.keyBindings(QKeySequence.SaveAs))
        self.assertEqual(window.ui.actionCopyFigure.shortcut(), QKeySequence("Ctrl+Shift+C"))
        self.assertNotIn(window.ui.actionCopyFigure.shortcut(), QKeySequence.keyBindings(QKeySequence.Copy))

    def test_table_cell_edit_can_be_undone_and_redone(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        original = model.cell_text(1, 0)

        model.set_cell_text(1, 0, "99")

        self.assertTrue(window.undo_table_action.isEnabled())
        self.assertFalse(window.redo_table_action.isEnabled())
        self.assertEqual(model.cell_text(1, 0), "99")

        window.undo_table_change()

        self.assertEqual(model.cell_text(1, 0), original)
        self.assertFalse(window.undo_table_action.isEnabled())
        self.assertTrue(window.redo_table_action.isEnabled())

        window.redo_table_change()

        self.assertEqual(model.cell_text(1, 0), "99")
        self.assertTrue(window.undo_table_action.isEnabled())
        self.assertFalse(window.redo_table_action.isEnabled())

    def test_secondary_axis_draws_extra_overlay_on_twin_axis(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            line_overlay_stat="None",
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        self.assertGreaterEqual(len(canvas.figure.axes), 2)
        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.yaxis.label.get_text() == "Rate")
        self.assertEqual(secondary_ax.yaxis.label.get_text(), "Rate")
        primary_overlay_lines = [line for line in primary_ax.lines if line.get_gid() == "overlay-line"]
        secondary_overlay_lines = [line for line in secondary_ax.lines if line.get_gid() == "overlay-line"]
        self.assertEqual(len(primary_overlay_lines), 0)
        self.assertEqual(len(secondary_overlay_lines), 1)

    def test_manual_secondary_y_range_applies_to_twin_axis(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            line_overlay_stat="None",
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            secondary_auto_y_range=False,
            secondary_y_min=40.0,
            secondary_y_max=80.0,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        self.assertEqual(secondary_ax.get_ylim(), (40.0, 80.0))

    def test_manual_primary_tick_interval_applies_to_box_y_axis(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            auto_y_range=False,
            y_min=0.0,
            y_max=10.0,
            primary_auto_tick_interval=False,
            primary_tick_interval=2.0,
        )

        canvas.render(self.df, settings)

        ticks = canvas.figure.axes[0].get_yticks()
        visible_ticks = [tick for tick in ticks if 0.0 <= tick <= 10.0]
        self.assertGreaterEqual(len(visible_ticks), 2)
        self.assertTrue(all(math.isclose(float(np.diff(visible_ticks)[index]), 2.0) for index in range(len(visible_ticks) - 1)))

    def test_auto_primary_tick_interval_syncs_spinbox_to_axis_ticks(self):
        window = main_window.MainWindow()
        window.settings = ChartSettings(auto_y_range=False, y_min=0.0, y_max=10.0, primary_auto_tick_interval=True)
        window.apply_settings_to_controls()

        window.render()

        expected_interval = window._auto_tick_interval_for_axis(window.canvas.figure.axes[0])
        self.assertIsNotNone(expected_interval)
        self.assertAlmostEqual(window.primary_tick_interval.value(), expected_interval)
        self.assertAlmostEqual(window.settings.primary_tick_interval, expected_interval)

    def test_manual_primary_tick_interval_falls_back_to_auto_when_too_dense(self):
        window = main_window.MainWindow()
        window.settings = ChartSettings(
            auto_y_range=False,
            y_min=0.0,
            y_max=10000.0,
            primary_auto_tick_interval=False,
            primary_tick_interval=0.000001,
        )
        window.apply_settings_to_controls()

        window.render()

        self.assertTrue(window.primary_auto_tick_interval.isChecked())
        self.assertTrue(window.settings.primary_auto_tick_interval)
        self.assertFalse(window.primary_tick_interval.isEnabled())
        self.assertGreater(window.primary_tick_interval.value(), 0.000001)

    def test_manual_primary_tick_interval_applies_to_ridge_x_axis(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            chart_type="Ridge",
            auto_y_range=False,
            y_min=0.0,
            y_max=10.0,
            primary_auto_tick_interval=False,
            primary_tick_interval=2.5,
        )

        canvas.render(self.df, settings)

        ticks = canvas.figure.axes[0].get_xticks()
        visible_ticks = [tick for tick in ticks if 0.0 <= tick <= 10.0]
        self.assertGreaterEqual(len(visible_ticks), 2)
        self.assertTrue(all(math.isclose(float(np.diff(visible_ticks)[index]), 2.5) for index in range(len(visible_ticks) - 1)))

    def test_manual_secondary_tick_interval_applies_to_twin_axis(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            line_overlay_stat="None",
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            secondary_auto_y_range=False,
            secondary_y_min=40.0,
            secondary_y_max=80.0,
            secondary_auto_tick_interval=False,
            secondary_tick_interval=10.0,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        ticks = secondary_ax.get_yticks()
        visible_ticks = [tick for tick in ticks if 40.0 <= tick <= 80.0]
        self.assertGreaterEqual(len(visible_ticks), 2)
        self.assertTrue(all(math.isclose(float(np.diff(visible_ticks)[index]), 10.0) for index in range(len(visible_ticks) - 1)))

    def test_manual_secondary_tick_interval_falls_back_to_auto_when_too_dense(self):
        window = main_window.MainWindow()
        window.add_custom_overlay_row()
        window.custom_overlay_secondary_axis.setChecked(True)
        window.secondary_auto_y_range.setChecked(False)
        window.secondary_y_min.setValue(0.0)
        window.secondary_y_max.setValue(10000.0)
        window.secondary_auto_tick_interval.setChecked(False)
        window.secondary_tick_interval.setValue(0.000001)

        window.update_settings()
        window.flush_pending_render()

        self.assertTrue(window.secondary_auto_tick_interval.isChecked())
        self.assertTrue(window.settings.secondary_auto_tick_interval)
        self.assertFalse(window.secondary_tick_interval.isEnabled())
        self.assertGreater(window.secondary_tick_interval.value(), 0.000001)

    def test_split_secondary_axis_draws_extra_overlay_in_upper_frame(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            show_stat_table=False,
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            secondary_axis_split_ratio=0.30,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        primary_position = primary_ax.get_position()
        secondary_position = secondary_ax.get_position()

        self.assertAlmostEqual(primary_position.x0, secondary_position.x0)
        self.assertAlmostEqual(primary_position.width, secondary_position.width)
        self.assertAlmostEqual(primary_position.y1, secondary_position.y0)
        total_plot_height = primary_position.height + secondary_position.height
        self.assertAlmostEqual(secondary_position.height / total_plot_height, 0.30)
        self.assertEqual(primary_ax.xaxis.label.get_text(), settings.x_label)
        self.assertEqual(secondary_ax.xaxis.label.get_text(), "")
        self.assertEqual([label.get_text() for label in primary_ax.get_xticklabels()], ["Control", "Low dose", "High dose"])
        self.assertEqual([label.get_text() for label in secondary_ax.get_xticklabels()], [])
        self.assertEqual(primary_ax.get_title(), "")
        self.assertEqual(secondary_ax.get_title(), settings.title)
        self.assertEqual(secondary_ax.yaxis.label.get_text(), "Rate")
        self.assertEqual(secondary_ax.yaxis.get_label_position(), "right")

        primary_overlay_lines = [line for line in primary_ax.lines if line.get_gid() == "overlay-line"]
        secondary_overlay_lines = [line for line in secondary_ax.lines if line.get_gid() == "overlay-line"]
        self.assertEqual(len(primary_overlay_lines), 0)
        self.assertEqual(len(secondary_overlay_lines), 1)

    def test_ridge_split_secondary_axis_draws_extra_overlay_in_right_x_frame(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            chart_type="Ridge",
            show_stat_table=False,
            line_overlay_stat="None",
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            secondary_axis_split_ratio=0.30,
            secondary_auto_y_range=False,
            secondary_y_min=40.0,
            secondary_y_max=80.0,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)

        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        primary_position = primary_ax.get_position()
        secondary_position = secondary_ax.get_position()

        self.assertAlmostEqual(primary_position.y0, secondary_position.y0)
        self.assertAlmostEqual(primary_position.height, secondary_position.height)
        self.assertAlmostEqual(primary_position.x1, secondary_position.x0)
        total_plot_width = primary_position.width + secondary_position.width
        self.assertAlmostEqual(secondary_position.width / total_plot_width, 0.30)
        self.assertEqual(primary_ax.get_title(), "")
        self.assertEqual(secondary_ax.get_title(), settings.title)
        renderer = canvas.canvas.get_renderer()
        title_position = secondary_ax.title.get_window_extent(renderer)
        title_center = (title_position.x0 + title_position.x1) / 2.0 / canvas.figure.bbox.width
        combined_center = (primary_position.x0 + secondary_position.x1) / 2.0
        self.assertAlmostEqual(title_center, combined_center, places=2)
        self.assertEqual(secondary_ax.xaxis.label.get_text(), "Rate")
        self.assertEqual(secondary_ax.xaxis.get_label_position(), "top")
        self.assertEqual(secondary_ax.get_ylabel(), "")
        self.assertEqual(secondary_ax.get_xlim(), (40.0, 80.0))
        self.assertEqual(secondary_ax.get_ylim(), primary_ax.get_ylim())
        self.assertEqual([label.get_text() for label in secondary_ax.get_yticklabels()], [])

        primary_overlay_lines = [line for line in primary_ax.lines if line.get_gid() == "overlay-line"]
        secondary_overlay_lines = [line for line in secondary_ax.lines if line.get_gid() == "overlay-line"]
        self.assertEqual(len(primary_overlay_lines), 0)
        self.assertEqual(len(secondary_overlay_lines), 1)
        self.assertEqual(list(secondary_overlay_lines[0].get_xdata()), [50.0, 60.0, 70.0])
        legend = primary_ax.get_legend()
        self.assertIsNotNone(legend)
        legend_bounds = legend.get_window_extent(renderer)
        secondary_bounds = secondary_ax.get_window_extent(renderer)
        self.assertLess(legend_bounds.y1, primary_ax.xaxis.label.get_window_extent(renderer).y0)
        self.assertAlmostEqual(
            (legend_bounds.x0 + legend_bounds.x1) / 2,
            (primary_ax.get_window_extent(renderer).x0 + secondary_bounds.x1) / 2,
        )

    def test_multiline_split_secondary_title_uses_secondary_frame_and_expands_height(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            show_stat_table=False,
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )
        canvas.render(self.df, settings)
        single_line_height = canvas.figure.get_figheight()

        settings.title = "Distribution plot\nSecondary overlay\nNormalized rate"
        canvas.render(self.df, settings)

        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        self.assertGreater(canvas.figure.get_figheight(), single_line_height)
        self.assertEqual(primary_ax.get_title(), "")
        self.assertEqual(secondary_ax.get_title(), settings.title)

    def test_overlay_color_panel_defaults_to_first_unused_palette_color(self):
        settings = ChartSettings(
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_palette="Dark Slide",
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {}},
                {"name": "Overlay 2", "values": {}},
                {"name": "Overlay 3", "values": {}},
            ],
        )
        colors = palette.expanded_preset_palette("Dark Slide", 3)
        settings.custom_overlay_colors = {overlay_series.overlay_custom_color_key(1): colors[2]}

        color_map = overlay_series.overlay_color_map_for_keys(overlay_series.all_overlay_color_keys(settings), settings)

        self.assertEqual(color_map[overlay_series.overlay_custom_color_key(1)], QColor(colors[2]).name())
        self.assertEqual(color_map[overlay_series.overlay_custom_color_key(2)], QColor(colors[1]).name())

    def test_line_overlay_style_controls_apply_to_plot_line(self):
        settings = ChartSettings(
            show_line_overlay=True,
            line_overlay_width=2.7,
            line_overlay_style="Dash-dot",
            line_overlay_point_size=8.0,
        )
        window = plotting_canvas.PlotCanvas()

        window.render(self.df, settings)
        overlay_line = window.figure.axes[0].lines[-1]

        self.assertEqual(overlay_line.get_linewidth(), 2.7)
        self.assertEqual(overlay_line.get_linestyle(), "-.")
        self.assertEqual(overlay_line.get_markersize(), 8.0)
        self.assertEqual(overlay_line.get_color(), overlay_series.stat_overlay_color(settings))
        self.assertEqual(overlay_line.get_alpha(), overlay_renderer.STAT_OVERLAY_ALPHA)

    def test_custom_overlay_styles_apply_to_individual_plot_lines(self):
        settings = ChartSettings(
            line_overlay_stat="None",
            line_overlay_style="Solid",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Index", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
            custom_overlay_styles={
                overlay_series.overlay_custom_color_key(0): "Dashed",
                overlay_series.overlay_custom_color_key(1): "Dotted",
            },
        )
        window = plotting_canvas.PlotCanvas()

        window.render(self.df, settings)
        overlay_lines = window.figure.axes[0].lines[-2:]

        self.assertEqual(overlay_lines[0].get_linestyle(), "--")
        self.assertEqual(overlay_lines[1].get_linestyle(), ":")

    def test_custom_overlay_extra_styles_apply_to_plot_lines(self):
        settings = ChartSettings(
            line_overlay_stat="None",
            line_overlay_style="Solid",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Index", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
            custom_overlay_styles={
                overlay_series.overlay_custom_color_key(0): "Long dash",
                overlay_series.overlay_custom_color_key(1): "Dash-dot-dot",
            },
        )
        window = plotting_canvas.PlotCanvas()

        window.render(self.df, settings)
        overlay_lines = window.figure.axes[0].lines[-2:]

        self.assertEqual(getattr(overlay_lines[0], "_unscaled_dash_pattern", None), (0, (10, 3)))
        self.assertEqual(getattr(overlay_lines[1], "_unscaled_dash_pattern", None), (0, (7, 2, 1, 2, 1, 2)))
        self.assertEqual(overlay_lines[0].get_dash_capstyle(), "round")
        self.assertEqual(overlay_lines[1].get_dash_capstyle(), "round")

    def test_auto_line_overlay_style_applies_distinct_plot_line_styles(self):
        settings = ChartSettings(
            line_overlay_stat="Mean",
            line_overlay_style="Auto",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "5", "Low dose": "6", "High dose": "7"}},
                {"name": "Index", "values": {"Control": "10", "Low dose": "20", "High dose": "30"}},
            ],
        )
        window = plotting_canvas.PlotCanvas()

        window.render(self.df, settings)
        overlay_lines = window.figure.axes[0].lines[-3:]

        self.assertEqual(overlay_lines[0].get_linestyle(), "-")
        self.assertEqual(overlay_lines[1].get_linestyle(), "--")
        self.assertEqual(overlay_lines[2].get_linestyle(), ":")

    def test_stat_table_master_switch_keeps_checked_options(self):
        window = main_window.MainWindow()
        first_item = window.stat_table_options.item(0)
        df = data.prepare_plot_data(self.df, window.settings)

        self.assertEqual(first_item.checkState(), Qt.Checked)

        window.show_stat_table.setChecked(False)
        groups, rows = overlay_series.stat_table_data(df, window.settings)

        self.assertFalse(window.settings.show_stat_table)
        self.assertTrue(window.settings.show_stat_mean)
        self.assertEqual(first_item.checkState(), Qt.Checked)
        self.assertEqual(groups, [])
        self.assertEqual(rows, [])

    def test_ridge_stat_table_forces_header_control_on(self):
        window = main_window.MainWindow()
        window.show_stat_header.setChecked(False)

        with mock.patch.object(window, "render"):
            window.chart_type.setCurrentText("Ridge")

        self.assertTrue(window.show_stat_header.isChecked())
        self.assertFalse(window.show_stat_header.isEnabled())
        self.assertFalse(window.settings.show_stat_header)

        with mock.patch.object(window, "render"):
            window.chart_type.setCurrentText("Box")

        self.assertFalse(window.show_stat_header.isChecked())
        self.assertTrue(window.show_stat_header.isEnabled())
        self.assertFalse(window.settings.show_stat_header)

        with mock.patch.object(window, "render"):
            window.chart_type.setCurrentText("Ridge")
            window.show_stat_table.setChecked(False)

        self.assertFalse(window.show_stat_header.isChecked())
        self.assertTrue(window.show_stat_header.isEnabled())
        self.assertFalse(window.settings.show_stat_table)

    def test_ridge_stat_table_draws_header_when_setting_is_off(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({"A": [1, 2, 3], "B": [2, 3, 4]})
        settings = ChartSettings(chart_type="Ridge", show_stat_table=True, show_stat_header=False)

        canvas.render(df, settings)

        table_ax = canvas.figure.axes[1]
        table_text = [text.get_text() for text in table_ax.texts]
        self.assertIn("A", table_text)
        self.assertIn("B", table_text)

    def test_stat_table_layout_uses_fixed_row_height_and_group_centers(self):
        window = main_window.MainWindow()
        settings = ChartSettings(show_stat_median=False, show_stat_q1=False, show_stat_q3=False)
        settings.show_stat_max = False
        settings.show_stat_min = False
        settings.show_stat_sd = False
        settings.show_stat_sem = False
        settings.show_stat_sample_size = False
        settings.stat_table_font_size = 9
        window.canvas.render(window.table.dataframe(), settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        one_row_height = table_ax.get_position().height * window.canvas.figure.get_figheight()

        settings.show_stat_sample_size = True
        window.canvas.render(window.table.dataframe(), settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        two_row_height = table_ax.get_position().height * window.canvas.figure.get_figheight() / 2

        self.assertEqual(plot_ax.get_xlim(), table_ax.get_xlim())
        self.assertAlmostEqual(one_row_height, two_row_height)

    def test_stat_table_row_labels_stay_inside_figure(self):
        window = main_window.MainWindow()
        df = pd.DataFrame({"Group 2": [1, 2, 3]})
        settings = ChartSettings()
        settings.show_stat_q1 = False
        settings.show_stat_q3 = False
        settings.show_stat_sd = False
        settings.show_stat_sem = False
        settings.show_stat_sample_size = False
        settings.show_stat_header = True

        window.canvas.render(df, settings)
        table_ax = window.canvas.figure.axes[1]
        renderer = window.canvas.canvas.get_renderer()
        row_label_edges = [
            text.get_window_extent(renderer).x0
            for text in table_ax.texts
            if text.get_text() in {"Mean", "Median", "Max", "Min"}
        ]

        self.assertGreaterEqual(min(row_label_edges), 0)

    def test_stat_table_has_no_background_fill(self):
        window = main_window.MainWindow()
        settings = ChartSettings(transparent_background=True, show_stat_header=True)

        window.canvas.render(window.table.dataframe(), settings)
        table_ax = window.canvas.figure.axes[1]

        self.assertEqual(table_ax.patch.get_facecolor()[3], 0)
        self.assertEqual(len(table_ax.patches), 0)

    def test_stat_table_extends_figure_without_shrinking_plot_height(self):
        window = main_window.MainWindow()
        settings = ChartSettings()
        settings.width = 15.0
        settings.height = 10.0
        settings.show_stat_header = True

        window.canvas.render(window.table.dataframe(), settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        figure_width = window.canvas.figure.get_figwidth()
        figure_height = window.canvas.figure.get_figheight()
        plot_width = plot_ax.get_position().width * figure_width
        plot_height = plot_ax.get_position().height * figure_height
        table_height = table_ax.get_position().height * figure_height

        self.assertAlmostEqual(plot_width, settings.width / 2.54)
        self.assertAlmostEqual(plot_height, settings.height / 2.54)
        self.assertGreater(figure_width, settings.width / 2.54)
        self.assertGreater(figure_height, settings.height / 2.54)
        self.assertGreater(table_height, 0)

    def test_plot_area_size_is_fixed_when_legend_is_outside(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "Control": [1, 2, 3],
            "Low dose": [2, 3, 4],
            "High dose": [3, 4, 10],
        })
        settings = ChartSettings(
            width=15.0,
            height=10.0,
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "TCT1000 cycle结果", "values": {"Control": "1", "Low dose": "2", "High dose": "10"}},
            ],
            legend_font_size=11,
            legend_width=2.8,
            legend_auto_width=False,
            legend_columns=1,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        legend = ax.get_legend()
        figure_width = canvas.figure.get_figwidth()
        figure_height = canvas.figure.get_figheight()
        plot_width = ax.get_position().width * figure_width
        plot_height = ax.get_position().height * figure_height

        self.assertAlmostEqual(plot_width, settings.width / 2.54)
        self.assertAlmostEqual(plot_height, settings.height / 2.54)
        self.assertEqual(legend.get_texts()[0].get_text(), "TCT1000\ncycle结果")
        self.assertLessEqual(legend.get_window_extent(renderer).x1, canvas.figure.bbox.x1)

    def test_narrow_good_template_legend_stays_inside_canvas(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            width=15.5,
            height=7.5,
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "30", "Low dose": "20", "High dose": "100"}},
            ],
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            secondary_axis_split_ratio=0.3,
            show_stat_table=True,
            show_stat_header=False,
            legend_font_size=14,
            legend_width=0.5,
            legend_columns=0,
        )

        canvas.render(data.sample_data(), settings)

        renderer = canvas.canvas.get_renderer()
        legend = canvas.figure.axes[0].get_legend()

        self.assertIsNotNone(legend)
        self.assertLessEqual(legend.get_window_extent(renderer).x1, canvas.figure.bbox.x1)

    def test_plot_frame_has_four_sides_with_and_without_secondary_axis(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
        })

        for uses_secondary_axis in (False, True):
            settings = ChartSettings(
                show_stat_table=False,
                custom_overlay_secondary_axis=uses_secondary_axis,
                extra_custom_overlay=uses_secondary_axis,
                custom_overlay_series=[
                    {"name": "Overlay", "values": {"A": "3", "B": "4"}},
                ],
            )
            canvas.render(df, settings)

            ax = canvas.figure.axes[0]
            for side in ("left", "right", "top", "bottom"):
                self.assertTrue(ax.spines[side].get_visible())
                self.assertAlmostEqual(ax.spines[side].get_linewidth(), settings.axis_line_width)

    def test_stat_table_layout_accounts_for_multiline_axis_text(self):
        window = main_window.MainWindow()
        settings = ChartSettings(show_stat_median=False, show_stat_q1=False, show_stat_q3=False)
        settings.show_stat_max = False
        settings.show_stat_min = False
        settings.show_stat_sd = False
        settings.show_stat_sem = False
        settings.show_stat_sample_size = False
        window.canvas.render(window.table.dataframe(), settings)
        single_line_bottom = window.canvas.figure.axes[0].get_position().y0

        df = pd.DataFrame({
            "Control\nDay 1": [1, 2, 3],
            "Low dose\nDay 1": [4, 5, 6],
            "High dose\nDay 1": [7, 8, 9],
        })
        settings.x_label = "Group\nCondition"
        window.canvas.render(df, settings)
        multiline_bottom = window.canvas.figure.axes[0].get_position().y0

        self.assertGreater(multiline_bottom, single_line_bottom)

    def test_multiline_value_label_expands_figure_width(self):
        window = main_window.MainWindow()
        settings = ChartSettings()
        settings.show_stat_table = False
        window.canvas.render(window.table.dataframe(), settings)
        single_line_width = window.canvas.figure.get_figwidth()

        settings.y_label = "Value\nRelative change\nNormalized units"
        window.canvas.render(window.table.dataframe(), settings)
        multiline_width = window.canvas.figure.get_figwidth()

        self.assertGreater(multiline_width, single_line_width)

    def test_long_box_and_violin_value_label_expands_figure_height(self):
        canvas = plotting_canvas.PlotCanvas()
        long_label = "Very long response axis title with normalized concentration change over repeated treatment cycles"

        for chart_type in ("Box", "Violin"):
            with self.subTest(chart_type=chart_type):
                settings = ChartSettings(chart_type=chart_type, show_stat_table=False)
                canvas.render(self.df, settings)
                default_height = canvas.figure.get_figheight()

                settings.y_label = long_label
                canvas.render(self.df, settings)

                renderer = canvas.canvas.get_renderer()
                label_bounds = canvas.figure.axes[0].yaxis.label.get_window_extent(renderer)
                self.assertGreater(canvas.figure.get_figheight(), default_height)
                self.assertGreaterEqual(label_bounds.y0, canvas.figure.bbox.y0)
                self.assertLessEqual(label_bounds.y1, canvas.figure.bbox.y1)

    def test_long_ridge_x_axis_title_expands_figure_width(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(chart_type="Ridge", show_stat_table=False)
        canvas.render(self.df, settings)
        default_width = canvas.figure.get_figwidth()

        settings.y_label = (
            "Very long numeric axis title with normalized concentration change over repeated treatment cycles "
            "and longitudinal response measurements captured across every scheduled observation window"
        )
        canvas.render(self.df, settings)

        renderer = canvas.canvas.get_renderer()
        label_bounds = canvas.figure.axes[0].xaxis.label.get_window_extent(renderer)
        self.assertGreater(canvas.figure.get_figwidth(), default_width)
        self.assertGreaterEqual(label_bounds.x0, canvas.figure.bbox.x0)
        self.assertLessEqual(label_bounds.x1, canvas.figure.bbox.x1)

    def test_long_secondary_value_label_expands_figure_height(self):
        canvas = plotting_canvas.PlotCanvas()
        long_label = "Very long secondary response axis title with normalized concentration change over repeated cycles"

        for split_secondary_axis in (False, True):
            with self.subTest(split_secondary_axis=split_secondary_axis):
                settings = ChartSettings(
                    show_stat_table=False,
                    extra_custom_overlay=True,
                    custom_overlay_secondary_axis=True,
                    split_secondary_axis=split_secondary_axis,
                    custom_overlay_series=[
                        {"name": "Overlay", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
                    ],
                )
                canvas.render(self.df, settings)
                default_height = canvas.figure.get_figheight()

                settings.secondary_y_label = long_label
                canvas.render(self.df, settings)

                renderer = canvas.canvas.get_renderer()
                secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
                label_bounds = secondary_ax.yaxis.label.get_window_extent(renderer)
                self.assertGreater(canvas.figure.get_figheight(), default_height)
                self.assertGreaterEqual(label_bounds.y0, canvas.figure.bbox.y0)
                self.assertLessEqual(label_bounds.y1, canvas.figure.bbox.y1)

    def test_long_ridge_secondary_x_axis_title_expands_figure_width(self):
        canvas = plotting_canvas.PlotCanvas()
        long_label = (
            "Very long secondary numeric axis title with normalized concentration change over repeated cycles "
            "and longitudinal response measurements captured across scheduled observation windows"
        )

        for split_secondary_axis in (False, True):
            with self.subTest(split_secondary_axis=split_secondary_axis):
                settings = ChartSettings(
                    chart_type="Ridge",
                    show_stat_table=False,
                    extra_custom_overlay=True,
                    custom_overlay_secondary_axis=True,
                    split_secondary_axis=split_secondary_axis,
                    custom_overlay_series=[
                        {"name": "Overlay", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
                    ],
                )
                canvas.render(self.df, settings)
                default_width = canvas.figure.get_figwidth()

                settings.secondary_y_label = long_label
                canvas.render(self.df, settings)

                renderer = canvas.canvas.get_renderer()
                secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
                label_bounds = secondary_ax.xaxis.label.get_window_extent(renderer)
                self.assertGreater(canvas.figure.get_figwidth(), default_width)
                self.assertGreaterEqual(label_bounds.x0, canvas.figure.bbox.x0)
                self.assertLessEqual(label_bounds.x1, canvas.figure.bbox.x1)

    def test_multiline_secondary_value_label_expands_figure_width(self):
        window = main_window.MainWindow()
        settings = ChartSettings(
            show_stat_table=False,
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Overlay", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )
        window.canvas.render(window.table.dataframe(), settings)
        single_line_width = window.canvas.figure.get_figwidth()

        settings.secondary_y_label = "Rate\nNormalized index\nSecondary units"
        window.canvas.render(window.table.dataframe(), settings)
        multiline_width = window.canvas.figure.get_figwidth()

        self.assertGreater(multiline_width, single_line_width)

    def test_right_overlay_legend_avoids_secondary_axis_title(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = ChartSettings(
            show_stat_table=False,
            custom_overlay_secondary_axis=True,
            secondary_y_label="Secondary\nAxis\nTitle",
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Secondary overlay", "values": {"A": "30", "B": "40", "C": "50"}},
            ],
            legend_font_size=10,
            legend_width=3.0,
            legend_auto_width=False,
            legend_columns=1,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        legend = ax.get_legend()
        legend_bounds = legend.get_window_extent(renderer)
        title_bounds = secondary_ax.yaxis.label.get_window_extent(renderer)
        gap_px = legend_bounds.x0 - title_bounds.x1

        self.assertGreaterEqual(gap_px, layout.LEGEND_SECONDARY_AXIS_GAP_PX - 1.0)
        self.assertLess(gap_px, 24.0)

    def test_stat_table_gap_accounts_for_rotated_ticks_and_bottom_axis_labels(self):
        window = main_window.MainWindow()
        df = pd.DataFrame({
            "Control": pd.Series([4.1, 4.6, 5.0]),
            "Low dose": pd.Series([5.1, 5.7, 6.3]),
            "High dose": pd.Series([5.8, 6.3, 7.1]),
            "Group 4": pd.Series([1, 2, 3, 5]),
            "Group 5": pd.Series([1, 2, 3]),
            "Group 6": pd.Series([2, 2, 3]),
            "Group 7": pd.Series([2, 4, 4]),
            "a": pd.Series([3.4, 4.6, 5.5]),
            "c": pd.Series([4.6, 5.6, 6.9]),
            "v": pd.Series([5.0, 6.3, 7.5]),
            "b": pd.Series([1, 2, 3, 4, 5]),
            "t": pd.Series([1, 2, 3]),
            "q": pd.Series([2, 2.5, 3]),
            "w": pd.Series([2, 4, 4]),
            "e": pd.Series([3, 3, 4]),
        })
        settings = ChartSettings(
            show_line_overlay=True,
            show_line_values=True,
            line_value_position="Bottom axis",
            line_value_decimals=2,
            x_tick_rotation=65,
            show_stat_header=False,
        )

        window.canvas.render(df, settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        renderer = window.canvas.canvas.get_renderer()
        table_top = table_ax.get_window_extent(renderer).y1
        plot_bottom_artists = [
            artist
            for artist in [plot_ax.xaxis.label, *plot_ax.get_xticklabels(), *plot_ax.texts]
            if artist.get_visible() and artist.get_text()
        ]

        lowest_plot_text = min(artist.get_window_extent(renderer).y0 for artist in plot_bottom_artists)

        self.assertGreater(lowest_plot_text, table_top)

    def test_stat_table_header_supports_multiline_group_names(self):
        window = main_window.MainWindow()
        df = pd.DataFrame({
            "Control\nDay 1": [1, 2, 3],
            "Low dose\nDay 1": [4, 5, 6],
            "High dose\nDay 1": [7, 8, 9],
        })
        settings = ChartSettings(show_stat_header=True, show_stat_median=False, show_stat_q1=False, show_stat_q3=False)
        settings.show_stat_max = False
        settings.show_stat_min = False
        settings.show_stat_sd = False
        settings.show_stat_sem = False
        settings.show_stat_sample_size = False

        window.canvas.render(df, settings)
        table_ax = window.canvas.figure.axes[1]

        self.assertGreater(table_ax.get_ylim()[1], 2.0)
        self.assertTrue(any("\n" in text.get_text() for text in table_ax.texts))

    def test_line_overlay_label_offsets_avoid_close_points(self):
        self.assertEqual(overlay_renderer.overlay_label_offset(0, [1.0, 1.02, 3.0], "Auto", is_ridge=False), (0, 13, "center", "bottom"))
        self.assertEqual(overlay_renderer.overlay_label_offset(1, [1.0, 1.02, 3.0], "Auto", is_ridge=False), (0, -13, "center", "top"))
        self.assertEqual(overlay_renderer.overlay_label_offset(1, [1.0, 1.02, 3.0], "Auto", is_ridge=True), (-12, 0, "right", "center"))
        self.assertEqual(
            overlay_renderer.overlay_label_offset(0, [1.0, 1.02, 3.0], "Auto", is_ridge=False, series_index=1),
            (8, -13, "center", "top"),
        )
        self.assertEqual(overlay_renderer.overlay_label_offset(0, [1.0], "Right", is_ridge=False), (12, 0, "left", "center"))

    def test_axis_line_overlay_labels_keep_distribution_plots_clear(self):
        df = pd.DataFrame({"A": [1, 2, 3], "B": [10, 11, 12], "C": [20, 21, 22]})
        for chart_type in ("Box", "Violin"):
            for position in ("Top axis", "Bottom axis"):
                with self.subTest(chart_type=chart_type, position=position):
                    settings = ChartSettings(
                        chart_type=chart_type,
                        show_line_overlay=True,
                        show_line_values=True,
                        line_value_position=position,
                        line_value_decimals=0,
                    )
                    window = plotting_canvas.PlotCanvas()
                    window.render(df, settings)
                    renderer = window.canvas.get_renderer()
                    ax = window.figure.axes[0]
                    label_bounds = [
                        artist.get_window_extent(renderer)
                        for artist in ax.texts
                        if artist.get_text() in {"2", "11", "21"}
                    ]

                    self.assertEqual(len(label_bounds), 3)
                    if position == "Bottom axis":
                        data_min_y = ax.transData.transform((0, 1))[1]
                        self.assertGreater(data_min_y, max(bounds.y1 for bounds in label_bounds))
                    else:
                        data_max_y = ax.transData.transform((0, 22))[1]
                        self.assertLess(data_max_y, min(bounds.y0 for bounds in label_bounds))

    def test_axis_line_overlay_padding_preserves_auto_y_base_range(self):
        base_canvas = plotting_canvas.PlotCanvas()
        base_canvas.render(
            data.sample_data(),
            ChartSettings(line_overlay_stat="Median", show_line_values=True, line_value_position="Above"),
        )
        base_y_min, base_y_max = base_canvas.figure.axes[0].get_ylim()

        for position in ("Top axis", "Bottom axis"):
            with self.subTest(position=position):
                canvas = plotting_canvas.PlotCanvas()
                canvas.render(
                    data.sample_data(),
                    ChartSettings(line_overlay_stat="Median", show_line_values=True, line_value_position=position),
                )
                y_min, y_max = canvas.figure.axes[0].get_ylim()
                axes_height_px = canvas.figure.axes[0].get_window_extent(
                    canvas.canvas.get_renderer()
                ).height
                one_pixel = max(
                    base_y_max - base_y_min,
                    y_max - y_min,
                ) / max(axes_height_px, 1.0)

                self.assertLessEqual(y_min, base_y_min + one_pixel)
                self.assertGreaterEqual(y_max, base_y_max - one_pixel)

    def test_plot_content_bbox_keeps_ten_percent_margin_across_chart_heights(self):
        df = pd.DataFrame({"A": [1, 2, 3], "B": [10, 11, 12], "C": [20, 21, 22]})
        for height in (6, 18):
            with self.subTest(height=height):
                settings = ChartSettings(
                    height=height,
                    show_line_overlay=True,
                    show_line_values=True,
                    line_value_position="Above",
                    line_value_decimals=0,
                )
                window = plotting_canvas.PlotCanvas()
                window.render(df, settings)
                renderer = window.canvas.get_renderer()
                ax = window.figure.axes[0]
                content_bounds = [
                    window._plot_content_artist_bounds(artist, ax, renderer)
                    for artist in [*ax.lines, *ax.patches, *ax.collections]
                    if artist.get_gid() in {"plot-content", "data-points", "overlay-line"}
                ]
                content_bounds = [bounds for bounds in content_bounds if bounds is not None]
                content_bounds.extend(
                    window._overlay_label_bounds(text, renderer)
                    for text in ax.texts
                    if text.get_gid() == "overlay-value-label"
                )
                plot_bounds = Bbox.union(content_bounds)
                axes_bounds = ax.get_window_extent(renderer)
                expected_margin = plot_bounds.height * layout.OVERLAY_CONTENT_MARGIN_RATIO

                self.assertGreaterEqual(plot_bounds.y0 - axes_bounds.y0, expected_margin - 0.5)
                self.assertGreaterEqual(axes_bounds.y1 - plot_bounds.y1, expected_margin - 0.5)

    def test_axis_line_overlay_padding_uses_half_label_height(self):
        settings = ChartSettings(line_value_font_size=12)
        canvas = plotting_canvas.PlotCanvas()
        label_height_points = settings.line_value_font_size * 1.35

        margin_points = canvas._overlay_axis_label_margin_points(settings)

        self.assertAlmostEqual(
            margin_points,
            label_height_points
            + layout.OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
            + label_height_points * 0.5,
        )

    def test_overlay_content_bbox_gets_ten_percent_vertical_margin_on_primary_and_secondary_axes(self):
        df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6], "C": [7, 8, 9]})
        for chart_type in ("Box", "Violin"):
            for use_secondary_axis in (False, True):
                with self.subTest(chart_type=chart_type, use_secondary_axis=use_secondary_axis):
                    settings = ChartSettings(
                        chart_type=chart_type,
                        show_stat_table=False,
                        extra_custom_overlay=True,
                        custom_overlay_count=1,
                        custom_overlay_series=[
                            {"name": "Overlay", "values": {"A": "1", "B": "2", "C": "12"}},
                        ],
                        custom_overlay_secondary_axis=use_secondary_axis,
                        split_secondary_axis=use_secondary_axis,
                        show_line_values=True,
                        custom_line_value_position="Below",
                        line_value_font_size=12,
                    )
                    canvas = plotting_canvas.PlotCanvas()
                    canvas.render(df, settings)
                    renderer = canvas.canvas.get_renderer()
                    ax = (
                        next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
                        if use_secondary_axis
                        else canvas.figure.axes[0]
                    )
                    content_bounds = [
                        canvas._overlay_label_bounds(text, renderer)
                        for text in ax.texts
                        if text.get_gid() == "overlay-value-label"
                    ]
                    content_bounds.extend(
                        bounds
                        for artist in [*ax.lines, *ax.patches, *ax.collections]
                        if artist.get_gid() in {"plot-content", "data-points", "overlay-line"}
                        if (bounds := canvas._plot_content_artist_bounds(artist, ax, renderer)) is not None
                    )
                    overlay_bounds = Bbox.union(content_bounds)
                    axes_bounds = ax.get_window_extent(renderer)
                    expected_margin = overlay_bounds.height * layout.OVERLAY_CONTENT_MARGIN_RATIO

                    self.assertGreaterEqual(overlay_bounds.y0 - axes_bounds.y0, expected_margin - 0.5)
                    self.assertGreaterEqual(axes_bounds.y1 - overlay_bounds.y1, expected_margin - 0.5)

    def test_ridge_overlay_content_bbox_gets_ten_percent_horizontal_margin(self):
        df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6], "C": [7, 8, 9]})
        settings = ChartSettings(
            chart_type="Ridge",
            show_stat_table=False,
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Overlay", "values": {"A": "1", "B": "2", "C": "12"}},
            ],
            show_line_values=True,
            custom_line_value_position="Right",
            line_value_font_size=12,
        )
        canvas = plotting_canvas.PlotCanvas()
        canvas.render(df, settings)
        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        content_bounds = [
            canvas._overlay_label_bounds(text, renderer)
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
        ]
        content_bounds.extend(
            bounds
            for artist in [*ax.lines, *ax.patches, *ax.collections]
            if artist.get_gid() in {"plot-content", "data-points", "overlay-line"}
            if (bounds := canvas._plot_content_artist_bounds(artist, ax, renderer)) is not None
        )
        overlay_bounds = Bbox.union(content_bounds)
        axes_bounds = ax.get_window_extent(renderer)
        expected_margin = overlay_bounds.width * layout.OVERLAY_CONTENT_MARGIN_RATIO

        self.assertGreaterEqual(overlay_bounds.x0 - axes_bounds.x0, expected_margin - 0.5)
        self.assertGreaterEqual(axes_bounds.x1 - overlay_bounds.x1, expected_margin - 0.5)

    def test_auto_y_axis_line_overlay_labels_keep_points_inside_plot(self):
        df = data.sample_data()
        for position in ("Top axis", "Bottom axis"):
            with self.subTest(position=position):
                settings = ChartSettings(
                    auto_y_range=True,
                    show_points=True,
                    show_outliers=True,
                    show_line_overlay=True,
                    show_line_values=True,
                    line_value_position=position,
                    line_value_decimals=2,
                )
                window = plotting_canvas.PlotCanvas()
                window.render(df, settings)
                renderer = window.canvas.get_renderer()
                ax = window.figure.axes[0]
                ax_bounds = ax.get_window_extent(renderer)

                for collection in ax.collections:
                    offsets = collection.get_offsets()
                    if len(offsets) == 0:
                        continue
                    points = ax.transData.transform(offsets)
                    finite_y = [point[1] for point in points if math.isfinite(point[1])]
                    if not finite_y:
                        continue
                    sizes = collection.get_sizes()
                    marker_radius_points = (max(sizes) ** 0.5) / 2.0 if len(sizes) else 0.0
                    marker_radius_px = renderer.points_to_pixels(marker_radius_points)

                    self.assertGreaterEqual(min(finite_y) - marker_radius_px, ax_bounds.y0)
                    self.assertLessEqual(max(finite_y) + marker_radius_px, ax_bounds.y1)

    def test_jitter_positions_are_stable_across_zoom_redraws(self):
        window = main_window.MainWindow()
        clean = data.prepare_plot_data(window._user_group_dataframe(), window.settings)
        outliers = data.mark_outliers(clean, window.settings)

        for mode in ["Beeswarm", "Quasirandom", "Random"]:
            window.settings.jitter_mode = mode
            first = window.canvas._point_positions(clean, window.settings)
            window.canvas.zoom_by(1.12)
            second = window.canvas._point_positions(clean, window.settings)
            self.assertAlmostEqual(
                float(first.loc[outliers.index[0]]),
                float(second.loc[outliers.index[0]]),
            )

    def test_zoom_to_fit_scales_to_viewport_without_resize_autofit(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(width=30.0, height=20.0)
        canvas.resize(420, 320)
        canvas.show()
        self.qapp.processEvents()
        canvas.render(self.df, settings)
        canvas.reset_zoom()
        self.qapp.processEvents()

        canvas.zoom_to_fit()
        fitted_zoom = canvas.preview_zoom
        canvas.resize(840, 640)
        self.qapp.processEvents()

        self.assertLess(fitted_zoom, 1.0)
        self.assertEqual(canvas.preview_zoom, fitted_zoom)
        canvas.close()

    def test_open_project_zoom_to_fit_after_loading(self):
        window = main_window.MainWindow()
        window.template_combo.blockSignals(True)
        try:
            window.template_combo.clear()
            window.template_combo.addItems([template_io.TEMPLATE_NONE_NAME, "Template A"])
            window.template_combo.setCurrentText("Template A")
        finally:
            window.template_combo.blockSignals(False)
        self.settings.title = "Saved project title"
        self.settings.width = 19.0
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "fit_on_open.eg"
            project_io.write_project(path, self.df, self.settings)

            with mock.patch.object(main_window.QFileDialog, "getOpenFileName", return_value=(str(path), "")):
                with mock.patch.object(window.canvas, "zoom_to_fit") as zoom_to_fit:
                    window.open_project()

        self.assertEqual(window.current_project, path)
        self.assertEqual(window.template_combo.currentText(), template_io.TEMPLATE_NONE_NAME)
        self.assertEqual(window.settings.title, "Saved project title")
        self.assertEqual(window.settings.width, 19.0)
        self.assertGreaterEqual(zoom_to_fit.call_count, 1)

    def test_initial_render_zoom_to_fit_after_startup(self):
        with mock.patch.object(plotting_canvas.PlotCanvas, "zoom_to_fit", autospec=True) as zoom_to_fit:
            window = main_window.MainWindow()
            self.assertEqual(zoom_to_fit.call_count, 1)

            self.qapp.processEvents()

        self.assertEqual(zoom_to_fit.call_count, 2)
        window.close()

    def test_export_figure_svg_filter_appends_svg_suffix(self):
        window = main_window.MainWindow()
        with mock.patch.object(
            main_window.QFileDialog,
            "getSaveFileName",
            return_value=("/tmp/easygraph_export", "SVG Vector (*.svg)"),
        ):
            with mock.patch.object(window.canvas, "export") as export:
                window.export_figure()

        export.assert_called_once_with("/tmp/easygraph_export.svg", window.settings)

    def test_export_figure_keeps_explicit_suffix(self):
        window = main_window.MainWindow()
        with mock.patch.object(
            main_window.QFileDialog,
            "getSaveFileName",
            return_value=("/tmp/easygraph_export.pdf", "SVG Vector (*.svg)"),
        ):
            with mock.patch.object(window.canvas, "export") as export:
                window.export_figure()

        export.assert_called_once_with("/tmp/easygraph_export.pdf", window.settings)

    def test_export_figure_appends_suffix_for_windows_style_path(self):
        window = main_window.MainWindow()
        windows_path = r"C:\Users\Public\easygraph_export"
        with mock.patch.object(
            main_window.QFileDialog,
            "getSaveFileName",
            return_value=(windows_path, "SVG Vector (*.svg)"),
        ):
            with mock.patch.object(window.canvas, "export") as export:
                window.export_figure()

        export.assert_called_once_with(f"{windows_path}.svg", window.settings)

    def test_save_project_syncs_current_ui_settings(self):
        window = main_window.MainWindow()
        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "ui_sync.eg"
            window.current_project = path
            window.x_tick_rotation.setValue(0)
            window.x_tick_rotation.lineEdit().setText("65")
            window.preset.setCurrentText("Tableau 10")
            window.settings.x_tick_rotation = 0

            window.save_project()
            _roundtrip_df, roundtrip_settings = project_io.read_project(path)

        self.assertEqual(roundtrip_settings.x_tick_rotation, 65)
        self.assertEqual(roundtrip_settings.preset, "Tableau 10")

    def test_new_project_starts_with_three_blank_columns(self):
        window = main_window.MainWindow()

        window.new_project()

        self.assertEqual(window.template_combo.currentText(), template_io.TEMPLATE_NONE_NAME)
        self.assertEqual(window.table.table_model.columnCount(), 3)
        self.assertEqual(list(window.table.dataframe().columns), ["Group 1", "Group 2", "Group 3"])
        self.assertTrue((window.table.dataframe() == "").all().all())

    def test_new_project_with_none_template_does_not_read_template(self):
        window = main_window.MainWindow()
        window.template_combo.setCurrentText(template_io.TEMPLATE_NONE_NAME)

        with mock.patch.object(main_window, "read_style_template") as read_template:
            window.new_project()

        read_template.assert_not_called()
        self.assertEqual(window.settings.chart_type, "Box")
        self.assertEqual(window.settings.title, "Distribution plot")
        self.assertEqual(window.settings.width, 15.0)
        self.assertEqual(window.settings.manual_group_order, window.workbook.active_sheet.column_ids[:2])

    def test_imported_xy_only_template_reports_missing_groups_variant(self):
        window = self.make_window()
        with mock.patch.object(
            main_window.QFileDialog,
            "getOpenFileName",
            return_value=("/tmp/xy-only.json", "Style Template (*.json)"),
        ), mock.patch.object(
            main_window,
            "style_template_families_file",
            return_value={template_io.TEMPLATE_FAMILY_XY},
        ), mock.patch.object(
            main_window,
            "import_style_template",
            return_value=("XY only", ChartSettings()),
        ), mock.patch.object(
            main_window,
            "read_style_template",
        ) as read_template:
            window.load_external_template()

        read_template.assert_not_called()
        self.assertEqual(
            window.statusBar().currentMessage(),
            "Style template imported, but it has no Groups variant "
            "to apply on this sheet.",
        )

    def test_new_project_applies_current_template_settings(self):
        window = main_window.MainWindow()
        template_settings = ChartSettings(
            chart_type="Violin",
            title="Template title",
            width=22.0,
            group_order="Manual",
            manual_group_order=["Old group"],
        )
        window.template_combo.blockSignals(True)
        try:
            window.template_combo.clear()
            window.template_combo.addItem("Template A")
            window.template_combo.setCurrentText("Template A")
        finally:
            window.template_combo.blockSignals(False)

        with mock.patch.object(main_window, "read_style_template", return_value=template_settings):
            window.new_project()

        self.assertEqual(window.settings.chart_type, "Violin")
        self.assertEqual(window.chart_type.currentText(), "Violin")
        self.assertEqual(window.settings.title, "Distribution plot")
        self.assertEqual(window.title.toPlainText(), "Distribution plot")
        self.assertEqual(window.settings.width, 22.0)
        self.assertEqual(list(window.table.dataframe().columns), ["Group 1", "Group 2", "Group 3"])
        self.assertTrue((window.table.dataframe() == "").all().all())
        self.assertEqual(window.settings.manual_group_order, window.workbook.active_sheet.column_ids[:2])

    def test_apply_style_template_preserves_content_and_maps_group_colors_by_index(self):
        template_settings = ChartSettings(
            title="Template title",
            x_label="Template X",
            y_label="Template Y",
            secondary_y_label="Template secondary",
            chart_type="Violin",
            width=22.0,
            custom_colors={"group:1": "#446688"},
            custom_overlay_series=[
                {"name": "Template overlay", "values": {"Control": "99"}},
            ],
            custom_overlay_hidden=[0],
            manual_group_order=["Template A", "Template B"],
            group_hidden=["Template B"],
        )
        window = main_window.MainWindow()
        window.title.setPlainText("Current title")
        window.x_label.setPlainText("Current X")
        window.y_label.setPlainText("Current Y")
        window.secondary_y_label.setPlainText("Current secondary")
        window.add_custom_overlay_row()
        window.table.table_model.set_vertical_header(1, "Current overlay")
        for col, value in enumerate(["30", "20", "40"]):
            window.table.table_model.set_cell_text(1, col, value)
        window.settings.custom_overlay_hidden = []

        window.apply_style_template("Style only", template_settings)

        self.assertEqual(window.settings.chart_type, "Violin")
        self.assertEqual(window.settings.width, 22.0)
        self.assertEqual(window.settings.title, "Current title")
        self.assertEqual(window.settings.x_label, "Current X")
        self.assertEqual(window.settings.y_label, "Current Y")
        self.assertEqual(window.settings.secondary_y_label, "Current secondary")
        self.assertEqual(window.settings.custom_overlay_series[0]["name"], "Current overlay")
        column_ids = window.workbook.active_sheet.column_ids
        self.assertEqual(window.settings.custom_overlay_series[0]["values"][column_ids[0]], "30")
        self.assertEqual(window.settings.custom_colors, {column_ids[1]: "#446688"})
        self.assertEqual(window.settings.manual_group_order, column_ids[:3])
        self.assertEqual(window.settings.group_hidden, [])

    def test_style_template_content_policy_does_not_insert_overlay_rows(self):
        data = asdict(self.settings)
        data["extra_custom_overlay"] = True
        data["custom_overlay_count"] = 1
        data["custom_overlay_secondary_axis"] = True
        data["split_secondary_axis"] = True
        data["custom_overlay_series"] = [
            {"name": "Legacy overlay", "values": {"Group 1": "30"}},
        ]

        with tempfile.TemporaryDirectory() as tmp:
            path = pathlib.Path(tmp) / "legacy.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            settings = template_io.read_style_template_file(path)

        window = main_window.MainWindow()
        window.apply_style_template("Legacy", settings)

        self.assertEqual(window.custom_overlay_row_count(), 0)
        self.assertEqual(window.sample_start_row(), 1)
        self.assertTrue(window.settings.extra_custom_overlay)
        self.assertEqual(window.settings.custom_overlay_series, [])
        self.assertTrue(window.settings.custom_overlay_secondary_axis)
        self.assertTrue(window.settings.split_secondary_axis)

    def test_overlay_visible_template_uses_existing_overlay_rows(self):
        template_settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            custom_overlay_series=[
                {"name": "Template data must not copy", "values": {"Control": "30"}},
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            template_dir = pathlib.Path(tmp)
            path = template_io.write_style_template("Good2", template_settings, template_dir)
            settings = template_io.read_style_template(path.stem, template_dir)

        window = main_window.MainWindow()
        window.add_custom_overlay_row()
        for col, value in enumerate(["30", "20", "40"]):
            window.table.table_model.set_cell_text(1, col, value)
        window.settings.custom_overlay_series = window.custom_overlay_series_from_table()

        window.apply_style_template("Good2", settings)

        custom_lines = [
            line
            for axis in window.canvas.figure.axes
            for line in axis.lines
            if line.get_gid() == "overlay-line" and line.get_label() == "Overlay 1"
        ]
        self.assertTrue(window.settings.extra_custom_overlay)
        self.assertEqual(window.custom_overlay_row_count(), 1)
        self.assertEqual(window.settings.custom_overlay_series[0]["values"][window.workbook.active_sheet.column_ids[0]], "30")
        self.assertEqual(len(custom_lines), 1)

    def test_template_overlay_axis_intent_activates_when_overlay_row_is_added(self):
        settings = ChartSettings(
            extra_custom_overlay=False,
            custom_overlay_series=[],
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
        )
        window = main_window.MainWindow()

        window.apply_style_template("Overlay axis style", settings)

        self.assertEqual(window.custom_overlay_row_count(), 0)
        self.assertTrue(window.custom_overlay_secondary_axis.isChecked())
        self.assertTrue(window.split_secondary_axis.isChecked())
        self.assertFalse(window.custom_overlay_secondary_axis.isEnabled())
        self.assertEqual([axis.get_gid() for axis in window.canvas.figure.axes].count("secondary-axis"), 0)

        window.add_custom_overlay_row()
        window.flush_pending_render()

        self.assertTrue(window.custom_overlay_secondary_axis.isEnabled())
        self.assertTrue(window.secondary_auto_y_range.isEnabled())
        self.assertTrue(window.split_secondary_axis.isEnabled())
        self.assertTrue(window.secondary_axis_split_ratio.isEnabled())
        self.assertEqual([axis.get_gid() for axis in window.canvas.figure.axes].count("secondary-axis"), 1)

    def test_all_chart_types_render_offscreen(self):
        window = main_window.MainWindow()

        for chart_type in ["Box", "Bar", "Violin", "Ridge"]:
            with self.subTest(chart_type=chart_type):
                window.settings.chart_type = chart_type
                window.canvas.render(window.table.dataframe(), window.settings)

    def test_ridge_uses_y_tick_labels_for_group_names(self):
        window = main_window.MainWindow()
        window.settings.chart_type = "Ridge"
        window.canvas.render(window.table.dataframe(), window.settings)
        ax = window.canvas.figure.axes[0]

        labels = [tick.get_text() for tick in ax.get_yticklabels()]
        self.assertEqual(labels, ["Control", "Low dose", "High dose"])

    def test_ridge_outliers_are_included_in_legend(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            chart_type="Ridge",
            show_stat_table=False,
            show_points=True,
            show_outliers=True,
        )

        canvas.render(data.sample_data(), settings)

        ax = canvas.figure.axes[0]
        legend = ax.get_legend()
        self.assertIsNotNone(legend)
        self.assertEqual([text.get_text() for text in legend.get_texts()].count("Outlier"), 1)

    def test_ridge_manual_range_applies_to_x_axis(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(chart_type="Ridge", auto_y_range=False, y_min=-2.0, y_max=9.0)

        canvas.render(self.df, settings)

        self.assertEqual(canvas.figure.axes[0].get_xlim(), (-2.0, 9.0))

    def test_category_tick_rotation_follows_the_category_axis_for_each_chart_type(self):
        for chart_type, category_dimension in (
            ("Box", "x"),
            ("Violin", "x"),
            ("Ridge", "y"),
        ):
            with self.subTest(chart_type=chart_type):
                canvas = plotting_canvas.PlotCanvas()
                self.addCleanup(canvas.close)
                settings = ChartSettings(
                    chart_type=chart_type,
                    show_stat_table=False,
                    x_tick_rotation=65,
                )

                canvas.render(self.df, settings)

                ax = canvas.figure.axes[0]
                category_ticks = (
                    ax.get_xticklabels()
                    if category_dimension == "x"
                    else ax.get_yticklabels()
                )
                value_ticks = (
                    ax.get_yticklabels()
                    if category_dimension == "x"
                    else ax.get_xticklabels()
                )
                self.assertTrue(category_ticks)
                self.assertTrue(
                    all(tick.get_rotation() == 65 for tick in category_ticks)
                )
                self.assertTrue(
                    all(tick.get_rotation() == 0 for tick in value_ticks)
                )

    def test_ridge_auto_x_range_includes_extra_overlay(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "Control": [1, 2, 3],
            "Treatment": [2, 3, 4],
        })
        settings = ChartSettings(
            chart_type="Ridge",
            line_overlay_stat="None",
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "100", "Treatment": "110"}},
            ],
        )

        canvas.render(df, settings)

        self.assertGreater(canvas.figure.axes[0].get_xlim()[1], 110)

    def test_ridge_stat_overlay_supports_axis_left_and_right_labels(self):
        df = pd.DataFrame({"A": [1, 2, 3], "B": [10, 11, 12]})
        for position in ("Axis left", "Axis right"):
            with self.subTest(position=position):
                canvas = plotting_canvas.PlotCanvas()
                settings = ChartSettings(
                    chart_type="Ridge",
                    line_overlay_stat="Median",
                    show_line_values=True,
                    line_value_position=position,
                    line_value_decimals=0,
                )

                canvas.render(df, settings)

                ax = canvas.figure.axes[0]
                labels = [
                    text
                    for text in ax.texts
                    if text.get_text() in {"2", "11"}
                ]
                label_offsets = [
                    text.get_position()[0]
                    for text in ax.texts
                    if text.get_text() in {"2", "11"}
                ]
                label_alignments = [text.get_ha() for text in labels]
                expected_offset = -layout.OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS if position == "Axis right" else layout.OVERLAY_AXIS_LABEL_AXIS_PAD_POINTS
                expected_alignment = "right" if position == "Axis right" else "left"
                self.assertEqual(label_offsets, [expected_offset] * 2)
                self.assertEqual(label_alignments, [expected_alignment] * 2)

    def test_overlay_value_labels_stay_inside_axis_bounds(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "Control": [4, 5, 6],
            "Low dose": [5, 6, 7],
            "High dose": [6, 7, 8],
        })
        settings = ChartSettings(
            chart_type="Ridge",
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1", "Low dose": "2", "High dose": "3"}},
            ],
            show_line_values=True,
            line_value_position="Axis left",
            custom_line_value_position="Left",
            line_value_decimals=2,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        axis_bounds = ax.get_window_extent(renderer)
        for text in ax.texts:
            if text.get_gid() == "overlay-value-label":
                bounds = text.get_bbox_patch().get_window_extent(renderer)
                self.assertGreaterEqual(bounds.x0, axis_bounds.x0 - 0.5)
                self.assertLessEqual(bounds.x1, axis_bounds.x1 + 0.5)
                self.assertGreaterEqual(bounds.y0, axis_bounds.y0 - 0.5)
                self.assertLessEqual(bounds.y1, axis_bounds.y1 + 0.5)

    def test_overlay_value_labels_do_not_overlap_each_other(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({"Control": [1, 2, 3]})
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=2,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "2"}},
                {"name": "Overlay 2", "values": {"Control": "2"}},
            ],
            show_line_values=True,
            custom_line_value_position="Above",
            line_value_decimals=2,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        labels = [
            text
            for text in canvas.figure.axes[0].texts
            if text.get_gid() == "overlay-value-label"
        ]
        bounds = [label.get_bbox_patch().get_window_extent(renderer) for label in labels]
        self.assertEqual(len(bounds), 2)
        for left_index, left_bounds in enumerate(bounds):
            for right_bounds in bounds[left_index + 1:]:
                overlap_x = min(left_bounds.x1, right_bounds.x1) - max(left_bounds.x0, right_bounds.x0)
                overlap_y = min(left_bounds.y1, right_bounds.y1) - max(left_bounds.y0, right_bounds.y0)
                self.assertTrue(overlap_x <= 0.5 or overlap_y <= 0.5)

    def test_stat_overlay_labels_keep_priority_over_extra_overlay_labels(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({"Control": [1, 2, 3]})
        settings = ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "2"}},
            ],
            show_line_values=True,
            line_value_position="Above",
            custom_line_value_position="Above",
            line_value_decimals=2,
        )

        canvas.render(df, settings)

        ax = canvas.figure.axes[0]
        stat_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and getattr(text, "_easygraph_overlay_priority", None) == 0
        )
        extra_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and getattr(text, "_easygraph_overlay_priority", None) == 1
        )

        self.assertEqual(stat_label.get_position(), (0, 13))
        self.assertNotEqual(extra_label.get_position(), (0, 13))

    def test_overlay_value_labels_offset_away_from_line_overlay_points(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({"Control": [1, 2, 3]})
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "2"}},
            ],
            show_line_values=True,
            custom_line_value_position="Right",
            line_overlay_point_size=30.0,
            line_value_decimals=2,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        label = next(text for text in ax.texts if text.get_gid() == "overlay-value-label")
        label_bounds = label.get_bbox_patch().get_window_extent(renderer)
        point_x, point_y = ax.transData.transform((0, 2))
        marker_radius_px = settings.line_overlay_point_size * canvas.figure.dpi / 72.0 / 2.0

        self.assertGreater(label_bounds.x0, point_x + marker_radius_px)

    def test_auto_y_range_expands_before_moving_below_overlay_label_over_marker(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "10", "Low dose": "1", "High dose": "2"}},
            ],
            show_line_values=True,
            line_value_position="Bottom axis",
            custom_line_value_position="Below",
            line_value_decimals=2,
            auto_y_range=True,
        )

        canvas.render(data.sample_data(), settings)

        ax = canvas.figure.axes[0]
        low_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label" and text.get_text() == "1.00"
        )

        self.assertLess(ax.get_ylim()[0], 0.0)
        self.assertLess(low_label.get_position()[1], 0.0)

    def test_custom_auto_overlay_avoids_bottom_axis_stat_labels(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1", "Low dose": "2", "High dose": "10"}},
            ],
            show_line_values=True,
            line_value_position="Bottom axis",
            custom_line_value_position="Auto",
            line_value_decimals=2,
        )

        canvas.render(data.sample_data(), settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        control_stat_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
            and getattr(text, "_easygraph_overlay_priority", None) == 0
            and getattr(text, "xy", (None, None))[0] == 0
        )
        control_custom_label = next(
            text
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
            and getattr(text, "_easygraph_overlay_priority", None) == 1
            and text.get_text() == "1.00"
        )

        self.assertEqual(getattr(control_custom_label, "_easygraph_overlay_position", None), "Above")
        stat_bounds = canvas._overlay_label_bounds(control_stat_label, renderer)
        custom_bounds = canvas._overlay_label_bounds(control_custom_label, renderer)
        overlap_x = min(stat_bounds.x1, custom_bounds.x1) - max(stat_bounds.x0, custom_bounds.x0)
        overlap_y = min(stat_bounds.y1, custom_bounds.y1) - max(stat_bounds.y0, custom_bounds.y0)
        self.assertTrue(overlap_x <= 0.5 or overlap_y <= 0.5)

    def test_manual_y_range_is_not_expanded_for_axis_overlay_labels(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            auto_y_range=False,
            y_min=-0.53,
            y_max=10.45,
            line_overlay_stat="Median",
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1", "Low dose": "2", "High dose": "10"}},
            ],
            show_line_values=True,
            line_value_position="Bottom axis",
            custom_line_value_position="Auto",
            line_value_decimals=2,
        )

        canvas.render(data.sample_data(), settings)

        self.assertEqual(canvas.figure.axes[0].get_ylim(), (-0.53, 10.45))

    def test_manual_y_range_clips_out_of_range_overlay_value_labels(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            auto_y_range=False,
            y_min=2.0,
            y_max=9.0,
            extra_custom_overlay=True,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"Control": "1", "Low dose": "4", "High dose": "10"}},
            ],
            show_line_values=True,
            custom_line_value_position="Below",
            line_value_decimals=2,
        )

        canvas.render(data.sample_data(), settings)

        ax = canvas.figure.axes[0]
        label_texts = [
            text.get_text()
            for text in ax.texts
            if text.get_gid() == "overlay-value-label"
        ]
        self.assertEqual(ax.get_ylim(), (2.0, 9.0))
        self.assertNotIn("1.00", label_texts)
        self.assertIn("4.00", label_texts)
        self.assertNotIn("10.00", label_texts)

    def test_overlay_legend_is_placed_outside_axis_on_the_right(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=2,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"A": "3", "B": "4", "C": "5"}},
                {"name": "Overlay 2", "values": {"A": "2.8", "B": "3.8", "C": "4.8"}},
            ],
            show_line_values=True,
            custom_line_value_position="Above",
            line_value_decimals=1,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        legend = ax.get_legend()
        self.assertIsNotNone(legend)
        self.assertEqual(legend.handlelength, layout.LEGEND_HANDLE_LENGTH)
        legend_bounds = legend.get_window_extent(renderer)
        axis_bounds = ax.get_window_extent(renderer)

        self.assertGreaterEqual(legend_bounds.x0, axis_bounds.x1)
        self.assertFalse(legend.get_frame().get_visible())

    def test_inside_legend_uses_plot_area_without_right_margin(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Overlay", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
            legend_position=LEGEND_POSITION_INSIDE,
        )

        canvas.render(df, settings)
        QApplication.processEvents()

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        legend = ax.get_legend()
        axis_bounds = ax.get_window_extent(renderer)
        legend_bounds = legend.get_frame().get_window_extent(renderer)
        plot_width = ax.get_position().width * canvas.figure.get_figwidth()

        self.assertIsNotNone(legend)
        self.assertTrue(legend.get_frame().get_visible())
        self.assertAlmostEqual(plot_width, settings.width / 2.54)
        self.assertGreaterEqual(legend_bounds.x0, axis_bounds.x0)
        self.assertLessEqual(legend_bounds.x1, axis_bounds.x1)
        self.assertGreaterEqual(legend_bounds.y0, axis_bounds.y0)
        self.assertLessEqual(legend_bounds.y1, axis_bounds.y1)
        self.assertNotEqual(settings.legend_inside_x, LEGEND_INSIDE_AUTO_POSITION)
        self.assertNotEqual(settings.legend_inside_y, LEGEND_INSIDE_AUTO_POSITION)

    def test_inside_legend_stays_visible_and_clamped_across_split_frames(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            show_stat_table=False,
            secondary_y_label="Rate",
            extra_custom_overlay=True,
            custom_overlay_secondary_axis=True,
            split_secondary_axis=True,
            legend_position=LEGEND_POSITION_INSIDE,
            legend_inside_x=0.92,
            legend_inside_y=0.0,
            custom_overlay_series=[
                {"name": "Target", "values": {"Control": "50", "Low dose": "60", "High dose": "70"}},
            ],
        )

        canvas.render(self.df, settings)
        QApplication.processEvents()

        renderer = canvas.canvas.get_renderer()
        primary_ax = canvas.figure.axes[0]
        secondary_ax = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
        legend = primary_ax.get_legend()
        legend_bounds = legend.get_frame().get_window_extent(renderer)
        plot_bounds = Bbox.union([
            primary_ax.get_window_extent(renderer),
            secondary_ax.get_window_extent(renderer),
        ])

        self.assertGreater(primary_ax.get_zorder(), secondary_ax.get_zorder())
        self.assertGreaterEqual(legend_bounds.x0, plot_bounds.x0)
        self.assertLessEqual(legend_bounds.x1, plot_bounds.x1)
        self.assertGreaterEqual(legend_bounds.y0, plot_bounds.y0)
        self.assertLessEqual(legend_bounds.y1, plot_bounds.y1)

        first_bounds = legend_bounds.frozen()
        canvas.render(self.df, settings)
        QApplication.processEvents()
        rerendered_legend = canvas.figure.axes[0].get_legend()
        rerendered_bounds = rerendered_legend.get_frame().get_window_extent(canvas.canvas.get_renderer())
        self.assertAlmostEqual(rerendered_bounds.x0, first_bounds.x0, delta=1.0)
        self.assertAlmostEqual(rerendered_bounds.y1, first_bounds.y1, delta=1.0)

    def test_inside_legend_drag_is_clamped_to_plot_union(self):
        window = main_window.MainWindow()
        window.legend_position.setCurrentText("Inside plot")
        window.update_settings()
        window.flush_pending_render()
        legend_target = next(target for target in window.canvas._interaction_targets if target["kind"] == "legend")
        bbox = legend_target["bbox"]
        press = SimpleNamespace(x=(bbox.x0 + bbox.x1) / 2, y=(bbox.y0 + bbox.y1) / 2, button=1)
        release = SimpleNamespace(x=-5000, y=5000, button=1)

        window.canvas._handle_plot_click(press)
        window.canvas._handle_plot_release(release)

        renderer = window.canvas.canvas.get_renderer()
        ax = window.canvas.figure.axes[0]
        legend = ax.get_legend()
        legend_bounds = legend.get_frame().get_window_extent(renderer)
        axis_bounds = ax.get_window_extent(renderer)

        self.assertEqual(window.settings.legend_position, LEGEND_POSITION_INSIDE)
        self.assertGreaterEqual(legend_bounds.x0, axis_bounds.x0)
        self.assertLessEqual(legend_bounds.x1, axis_bounds.x1)
        self.assertGreaterEqual(legend_bounds.y0, axis_bounds.y0)
        self.assertLessEqual(legend_bounds.y1, axis_bounds.y1)

    def test_inside_legend_motion_uses_blit_instead_of_full_draw(self):
        window = main_window.MainWindow()
        window.legend_position.setCurrentText("Inside plot")
        window.update_settings()
        window.flush_pending_render()
        legend_target = next(target for target in window.canvas._interaction_targets if target["kind"] == "legend")
        bbox = legend_target["bbox"]
        press = SimpleNamespace(x=(bbox.x0 + bbox.x1) / 2, y=(bbox.y0 + bbox.y1) / 2, button=1)
        motion = SimpleNamespace(x=bbox.x0 + 12, y=bbox.y1 - 12, button=1)

        window.canvas._handle_plot_click(press)
        with mock.patch.object(window.canvas.canvas, "blit", wraps=window.canvas.canvas.blit) as blit, mock.patch.object(
            window.canvas.canvas,
            "draw_idle",
            wraps=window.canvas.canvas.draw_idle,
        ) as draw_idle:
            window.canvas._handle_plot_motion(motion)

        blit.assert_called()
        draw_idle.assert_not_called()

    def test_legend_frame_adapts_to_dark_preset(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(
            preset="Dark Slide",
            legend_position=LEGEND_POSITION_INSIDE,
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Overlay", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
        )

        canvas.render(
            pd.DataFrame({
                "A": [1, 2, 3],
                "B": [2, 3, 4],
                "C": [3, 4, 5],
            }),
            settings,
        )

        legend = canvas.figure.axes[0].get_legend()
        frame = legend.get_frame()
        facecolor = QColor.fromRgbF(*frame.get_facecolor())
        edgecolor = QColor.fromRgbF(*frame.get_edgecolor())

        self.assertEqual(facecolor.name().upper(), "#111827")
        self.assertEqual(edgecolor.name().upper(), "#F9FAFB")
        self.assertGreater(frame.get_alpha(), 0.7)
        self.assertAlmostEqual(frame.get_linewidth(), settings.axis_line_width)
        self.assertIn("Square", type(frame.get_boxstyle()).__name__)

    def test_legend_handle_space_tracks_longer_preview_line(self):
        canvas = plotting_canvas.PlotCanvas()
        settings = ChartSettings(legend_font_size=12)

        self.assertAlmostEqual(
            canvas._legend_handle_space_inches(settings),
            12 * layout.LEGEND_HANDLE_SPACE_UNITS / 72.0,
        )

    def test_show_legend_can_hide_overlay_legend(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = ChartSettings(
            show_legend=False,
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Overlay", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
            legend_width=8.0,
        )

        canvas.render(df, settings)

        ax = canvas.figure.axes[0]
        figure_width = canvas.figure.get_figwidth()
        plot_width = ax.get_position().width * figure_width

        self.assertIsNone(ax.get_legend())
        self.assertAlmostEqual(plot_width, settings.width / 2.54)

    def test_overlay_legend_uses_custom_font_size_and_manual_columns_wrap(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Very long overlay legend label", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
            legend_font_size=7,
            legend_width=1.2,
            legend_auto_width=False,
            legend_columns=1,
        )

        canvas.render(df, settings)

        legend = canvas.figure.axes[0].get_legend()
        legend_text = legend.get_texts()[0]
        self.assertEqual(legend_text.get_fontsize(), 7)
        self.assertIn("\n", legend_text.get_text())

    def test_overlay_legend_manual_columns_can_use_auto_width_without_wrapping(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = ChartSettings(
            width=15.0,
            height=10.0,
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Very long overlay legend label", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
            legend_font_size=7,
            legend_width=1.2,
            legend_auto_width=True,
            legend_columns=1,
        )

        canvas.render(df, settings)

        renderer = canvas.canvas.get_renderer()
        ax = canvas.figure.axes[0]
        legend = ax.get_legend()
        plot_width = ax.get_position().width * canvas.figure.get_figwidth()

        self.assertEqual(getattr(legend, "_ncols", 1), 1)
        self.assertNotIn("\n", legend.get_texts()[0].get_text())
        self.assertAlmostEqual(plot_width, settings.width / 2.54)
        self.assertLessEqual(legend.get_window_extent(renderer).x1, canvas.figure.bbox.x1)

    def test_overlay_legend_supports_manual_wrap_with_auto_columns(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
        })
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Manual\\nLegend", "values": {"A": "3", "B": "4"}},
            ],
            legend_columns=0,
        )

        canvas.render(df, settings)

        legend = canvas.figure.axes[0].get_legend()
        self.assertEqual(legend.get_texts()[0].get_text(), "Manual\nLegend")

    def test_overlay_legend_auto_columns_use_total_width_without_wrapping(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=3,
            custom_overlay_series=[
                {"name": "Overlay 1", "values": {"A": "3", "B": "4", "C": "5"}},
                {"name": "Overlay 2", "values": {"A": "2.8", "B": "3.8", "C": "4.8"}},
                {"name": "Overlay 3", "values": {"A": "2.6", "B": "3.6", "C": "4.6"}},
            ],
            legend_width=8.0,
            legend_columns=0,
        )

        canvas.render(df, settings)

        legend = canvas.figure.axes[0].get_legend()
        self.assertGreaterEqual(getattr(legend, "_ncols", 1), 2)
        self.assertNotIn("\n", legend.get_texts()[0].get_text())

    def test_overlay_legend_auto_columns_wrap_when_total_width_is_too_small(self):
        canvas = plotting_canvas.PlotCanvas()
        df = pd.DataFrame({
            "A": [1, 2, 3],
            "B": [2, 3, 4],
            "C": [3, 4, 5],
        })
        settings = ChartSettings(
            extra_custom_overlay=True,
            custom_overlay_count=1,
            custom_overlay_series=[
                {"name": "Very long overlay legend label", "values": {"A": "3", "B": "4", "C": "5"}},
            ],
            legend_font_size=7,
            legend_width=1.2,
            legend_columns=0,
        )

        canvas.render(df, settings)

        legend = canvas.figure.axes[0].get_legend()
        self.assertEqual(getattr(legend, "_ncols", 1), 1)
        self.assertIn("\n", legend.get_texts()[0].get_text())

    def test_ridge_expands_left_margin_for_long_row_labels(self):
        window = main_window.MainWindow()
        df = pd.DataFrame({
            "A very long control group\nwith two lines": [1, 2, 3, 4],
            "低剂量处理组\n第二行": [2, 3, 4, 5],
            "High dose": [3, 4, 5, 6],
        })
        settings = ChartSettings(chart_type="Ridge", show_stat_table=True)
        window.canvas.render(df, settings)
        plot_ax, table_ax = window.canvas.figure.axes[:2]
        renderer = window.canvas.canvas.get_renderer()
        left_edges = [label.get_window_extent(renderer).x0 for label in plot_ax.get_yticklabels()]

        self.assertGreaterEqual(min(left_edges), 0)
        self.assertGreater(table_ax.get_position().x0, plot_ax.get_position().x1)
        self.assertAlmostEqual(plot_ax.get_position().y0, table_ax.get_position().y0)
        self.assertAlmostEqual(plot_ax.get_position().height, table_ax.get_position().height)

    def test_rotated_long_ridge_category_ticks_stay_inside_compact_figure(self):
        canvas = plotting_canvas.PlotCanvas()
        self.addCleanup(canvas.close)
        df = pd.DataFrame({
            "Vehicle control cohort with an extended category label": [1, 2, 3, 4],
            "Low-dose treatment cohort observed across repeated visits": [2, 3, 4, 5],
            "High-dose treatment cohort after prolonged exposure": [3, 4, 5, 6],
        })

        for rotation in (65, 90):
            with self.subTest(rotation=rotation):
                settings = ChartSettings(
                    chart_type="Ridge",
                    width=6.0,
                    height=4.0,
                    show_stat_table=False,
                    show_legend=False,
                    tick_font_size=14,
                    x_tick_rotation=rotation,
                )

                canvas.render(df, settings)

                renderer = canvas.canvas.get_renderer()
                figure_bounds = canvas.figure.bbox
                tick_bounds = [
                    tick.get_window_extent(renderer)
                    for tick in canvas.figure.axes[0].get_yticklabels()
                    if tick.get_visible() and tick.get_text()
                ]
                self.assertTrue(tick_bounds)
                for bounds in tick_bounds:
                    self.assertGreaterEqual(bounds.y0, figure_bounds.y0)
                    self.assertLessEqual(bounds.y1, figure_bounds.y1)

    def test_chinese_font_is_configured_for_matplotlib(self):
        self.assertEqual(app_theme.configure_matplotlib_fonts(), app_theme.DEFAULT_FONT_FAMILY)
        self.assertNotEqual(app_theme.DEFAULT_FONT_FAMILY, "DejaVu Sans")

    def test_chinese_text_renders_without_error(self):
        window = main_window.MainWindow()
        for col, label in enumerate(["对照组", "低剂量", "高剂量"]):
            window.table.table_model.set_cell_text(0, col, label)
        window.settings.title = "分布图\n含所有数据点"
        window.settings.x_label = "分组\n处理条件"
        window.settings.y_label = "数值\n相对表达"
        window.canvas.render(window.table.dataframe(), window.settings)

    def test_multiline_labels_are_read_from_ui(self):
        window = main_window.MainWindow()
        window.title.setPlainText("Line 1\nLine 2")
        window.x_label.setPlainText("X 1\nX 2")
        window.y_label.setPlainText("Y 1\nY 2")
        window.update_settings()

        self.assertEqual(window.settings.title, "Line 1\nLine 2")
        self.assertEqual(window.settings.x_label, "X 1\nX 2")
        self.assertEqual(window.settings.y_label, "Y 1\nY 2")

    def test_multiline_group_names_are_preserved(self):
        window = main_window.MainWindow()
        window.table.table_model.set_cell_text(0, 0, "Control\nDay 1")
        window.update_table_header_height()
        df = window.table.dataframe()
        clean = data.prepare_plot_data(df, window.settings)

        self.assertEqual(df.columns[0], "Control\nDay 1")
        self.assertIn("Control\nDay 1", set(clean["group"]))

        window.settings.chart_type = "Ridge"
        window.canvas.render(df, window.settings)
        labels = [tick.get_text() for tick in window.canvas.figure.axes[0].get_yticklabels()]
        self.assertIn("Control\nDay 1", labels)

    def test_table_header_height_grows_for_multiline_group_names(self):
        window = main_window.MainWindow()
        one_line_height = window.table.rowHeight(0)
        window.table.table_model.set_cell_text(0, 0, "A\nB\nC")
        window.update_table_header_height()

        self.assertGreater(window.table.rowHeight(0), one_line_height)

    def test_table_columns_are_user_resizable(self):
        window = self.make_window()

        self.assertEqual(
            window.table.horizontalHeader().sectionResizeMode(0),
            QHeaderView.Interactive,
        )

    def test_copy_table_selection_uses_tsv_for_excel(self):
        window = self.make_window()
        self.select_table_range(window.table, 0, 0, 1, 1)
        window.copy_table_selection()

        self.assertEqual(QApplication.clipboard().text(), "Control\tLow dose\n4.801\t6.29")

    def test_copy_table_selection_quotes_multiline_group_names(self):
        window = self.make_window()
        window.table.table_model.set_cell_text(0, 0, "Control\nDay 1")
        self.select_table_range(window.table, 0, 0, 0, 1)
        window.copy_table_selection()

        self.assertEqual(QApplication.clipboard().text(), '"Control\nDay 1"\tLow dose')

    def test_cut_table_selection_copies_clears_and_undoes_as_single_change(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        original_a = model.cell_text(1, 0)
        original_b = model.cell_text(1, 1)
        self.select_table_range(window.table, 1, 0, 1, 1)

        window.cut_table_selection()

        self.assertEqual(QApplication.clipboard().text(), f"{original_a}\t{original_b}")
        self.assertEqual(model.cell_text(1, 0), "")
        self.assertEqual(model.cell_text(1, 1), "")

        window.undo_table_change()

        self.assertEqual(model.cell_text(1, 0), original_a)
        self.assertEqual(model.cell_text(1, 1), original_b)

        window.redo_table_change()

        self.assertEqual(model.cell_text(1, 0), "")
        self.assertEqual(model.cell_text(1, 1), "")

    def test_table_context_menu_contains_clipboard_actions_with_standard_shortcuts(self):
        window = self.make_window()
        self.select_table_range(window.table, 1, 0, 1, 0)
        menu = window.table_context_menu()

        action_by_text = {
            action.text(): action
            for action in menu.actions()
            if not action.isSeparator()
        }

        self.assertEqual(window.table.contextMenuPolicy(), Qt.ContextMenuPolicy.CustomContextMenu)
        self.assertEqual(
            set(action_by_text),
            {"Copy", "Paste", "Cut", "Clear Contents", "Insert", "Delete",
             "Parent headers"},
        )
        self.assertEqual(action_by_text["Copy"].shortcut(), QKeySequence.Copy)
        self.assertEqual(action_by_text["Paste"].shortcut(), QKeySequence.Paste)
        self.assertEqual(action_by_text["Cut"].shortcut(), QKeySequence.Cut)
        self.assertTrue(action_by_text["Copy"].isEnabled())
        self.assertTrue(action_by_text["Cut"].isEnabled())

    def test_paste_table_selection_expands_table(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        window.table.setCurrentIndex(model.index(34, 2))
        QApplication.clipboard().setText("1\t2\n3\t4")
        window.paste_table_selection()

        self.assertGreaterEqual(model.rowCount(), 36)
        self.assertGreaterEqual(model.columnCount(), 4)
        self.assertEqual(model.cell_text(34, 2), "1")
        self.assertEqual(model.cell_text(35, 3), "4")

    def test_multicolumn_paste_into_independent_table_adds_xy_pairs(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        model = window.xy_independent_table.table_model
        window.show()
        QApplication.processEvents()
        window.xy_independent_table.setFocus()
        QApplication.processEvents()
        window.xy_independent_table.setCurrentIndex(model.index(0, 0))
        QApplication.clipboard().setText(
            "XA\tYA\tXB\tYB\n1\t10\t100\t1000\n2\t20\t200\t2000"
        )

        with mock.patch.object(window, "render"):
            window.paste_table_selection()

        sheet = window.workbook.active_sheet
        self.assertEqual(
            [model.cell_text(0, column) for column in range(4)],
            ["XA", "YA", "XB", "YB"],
        )
        self.assertEqual(len(sheet.xy_settings.paired_series_ids), 3)
        series_by_id = {series.id: series for series in sheet.xy_settings.series}
        self.assertEqual(
            [
                (
                    series_by_id[series_id].x_column_id,
                    series_by_id[series_id].y_column_id,
                )
                for series_id in sheet.xy_settings.paired_series_ids[:2]
            ],
            [
                tuple(window._active_xy_paired_column_ids[:2]),
                tuple(window._active_xy_paired_column_ids[2:4]),
            ],
        )

    def test_xy_paste_does_not_prompt_once_numeric_series_already_exist(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        model = window.table.table_model
        model.set_cell_text(1, 0, "1")
        model.set_cell_text(1, 1, "2")
        window.table.setCurrentIndex(model.index(2, 0))
        QApplication.clipboard().setText("3\t4")

        window.paste_table_selection()

    def test_paste_table_selection_undo_redo_is_single_table_change(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        original_rows = model.rowCount()
        original_cols = model.columnCount()
        window.table.setCurrentIndex(model.index(34, 2))
        QApplication.clipboard().setText("1\t2\n3\t4")

        window.paste_table_selection()

        self.assertEqual(model.cell_text(34, 2), "1")

        window.undo_table_change()

        self.assertEqual(model.rowCount(), original_rows)
        self.assertEqual(model.columnCount(), original_cols)

        window.redo_table_change()

        self.assertGreaterEqual(model.rowCount(), 36)
        self.assertGreaterEqual(model.columnCount(), 4)
        self.assertEqual(model.cell_text(35, 3), "4")

    def test_paste_table_selection_can_replace_group_name_row(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        window.table.setCurrentIndex(model.index(0, 0))
        QApplication.clipboard().setText('"Control\nDay 1"\tTreatment\n1\t2')
        window.paste_table_selection()

        self.assertEqual(model.cell_text(0, 0), "Control\nDay 1")
        self.assertEqual(list(window.table.dataframe().columns[:2]), ["Control\nDay 1", "Treatment"])

    def test_settings_still_refresh_after_excel_paste(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        window.table.setCurrentIndex(model.index(0, 0))
        QApplication.clipboard().setText("A\tB\n1\t2\n3\t4")
        window.paste_table_selection()

        window.chart_type.setCurrentText("Ridge")
        window.flush_pending_render()

        self.assertEqual(window.canvas._last_settings.chart_type, "Ridge")

    def test_delete_column_removes_current_column(self):
        window = main_window.MainWindow()
        model = window.table.table_model
        original_column_count = model.columnCount()
        window.table.setCurrentIndex(model.index(0, 1))
        window.delete_column()

        self.assertEqual(model.columnCount(), original_column_count - 1)
        self.assertEqual(model.cell_text(0, 1), "High dose")

    def test_delete_column_syncs_manual_group_order(self):
        window = main_window.MainWindow()
        column_ids = list(window.workbook.active_sheet.column_ids)
        window.settings.group_order = "Manual"
        window.settings.manual_group_order = [column_ids[2], column_ids[1], column_ids[0]]
        window.table.setCurrentIndex(window.table.table_model.index(0, 1))
        window.delete_column()

        self.assertEqual(window.settings.manual_group_order, [column_ids[2], column_ids[0]])


if __name__ == "__main__":
    unittest.main()
