"""Context switching and command targeting for the contextual Table toolbar."""
from unittest import mock

import pandas as pd
from PySide6.QtCore import QPoint, Qt
from PySide6.QtGui import QKeySequence
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QInputDialog

from easygraph.workbook import SHEET_MODE_XY
from tests.easygraph_case import EasyGraphQtTestCase


class TableToolsTests(EasyGraphQtTestCase):
    def test_context_tab_respects_manual_chart_choice_and_returns_after_plot(self):
        window = self.make_window()
        tools = window.table_tools
        tabs = window.ui.topToolsTabs
        tools.deactivate()
        self.assertFalse(tabs.isTabVisible(tools.table_index))
        tools.activate(window.table)
        self.assertTrue(tabs.isTabVisible(tools.table_index))
        self.assertEqual(tabs.currentWidget(), window.ui.tableToolsPage)
        tabs.setCurrentWidget(window.ui.chartToolsPage)
        tools.activate(window.table)
        tools.update_state()
        self.assertEqual(tabs.currentWidget(), window.ui.chartToolsPage)
        tools.deactivate()
        self.assertIsNone(tools.active_table)
        self.assertFalse(tabs.isTabVisible(tools.table_index))
        tools.activate(window.table)
        self.assertEqual(tabs.currentWidget(), window.ui.tableToolsPage)

    def test_parent_buttons_share_commands_and_merge_undo_preserves_values(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": [1, 2], "B": [3, 4]}))
        tools = window.table_tools
        tools.activate(window.table)
        self.assertIs(window.ui.tableMergeParentButton.defaultAction(), window.grouping_controls.action("merge"))
        self.assertIs(window.ui.tableInsertParentRightButton.defaultAction(), window.grouping_controls.action("insert_parent_right"))
        self.select_table_range(window.table, 1, 0, 1, 0)
        tools.update_state()
        self.assertTrue(window.ui.tableMergeParentButton.isEnabled())
        header = window.table.horizontalHeader()
        header.select_parent_columns([0, 1])
        self.assertIn("2", window.ui.tableSelectionSummary.text())
        before = window.table.table_model.cells_copy()
        with mock.patch.object(QInputDialog, "getText", return_value=("WT", True)):
            window.ui.tableMergeParentButton.click()
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]["name"], "WT")
        window.ui.tableUnmergeParentButton.click()
        self.assertEqual(window.workbook.active_sheet.grouping.parents, [])
        self.assertEqual(window.table.table_model.cells_copy(), before)
        self.assertTrue(window.ui.tableUndoButton.isEnabled())
        window.ui.tableUndoButton.click()
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]["name"], "WT")

    def test_paired_xy_edit_buttons_retain_table_target_after_toolbar_focus(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)
        tools = window.table_tools
        paired = window.xy_independent_table
        controller = window._controller_for_table(paired)
        row = controller.sample_start_row()
        paired.table_model.set_cell_text(row, 0, "42")
        paired.table_model.set_cell_text(row, 1, "84")
        self.select_table_range(paired, row, 0, row, 1)
        tools.activate(paired)
        window.ui.tableCopyButton.setFocus()
        window.ui.tableCopyButton.click()
        self.assertEqual(QApplication.clipboard().text().strip(), "42\t84")
        self.assertTrue(window.ui.tableParentSection.isHidden())
        window.ui.tableClearButton.click()
        self.assertEqual(paired.table_model.cell_text(row, 0), "")
        self.assertEqual(paired.table_model.cell_text(row, 1), "")
        window.ui.tableUndoButton.click()
        self.assertEqual(paired.table_model.cell_text(row, 0), "42")
        self.assertEqual(paired.table_model.cell_text(row, 1), "84")
        self.assertIs(tools.active_table, paired)

    def test_row_below_insertion_uses_selected_row_and_one_undo(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": ["first", "second", "third"]}))
        table = window.table
        start = window._table_controller.sample_start_row()
        self.select_table_range(table, start, 0, start, 0)
        window.table_tools.activate(table)
        window.ui.tableInsertRowBelowButton.click()
        self.assertEqual(table.table_model.cell_text(start, 0), "first")
        self.assertEqual(table.table_model.cell_text(start + 1, 0), "")
        self.assertEqual(table.table_model.cell_text(start + 2, 0), "second")
        window.ui.tableUndoButton.click()
        self.assertEqual(table.table_model.cell_text(start + 1, 0), "second")

    def test_chart_and_table_pages_keep_equal_toolbar_height(self):
        window = self.make_window()
        window.resize(2048, 900)
        window.show()
        window.table_tools.deactivate()
        self.qapp.processEvents()
        chart_height = window.ui.topToolsTabs.height()
        window.table_tools.activate(window.table)
        self.qapp.processEvents()
        self.assertEqual(window.ui.topToolsTabs.height(), chart_height)
        for button in (
            window.ui.tableCopyButton, window.ui.tableDeleteColumnsButton,
            window.ui.tableMergeParentButton, window.ui.tableUnmergeParentButton,
        ):
            self.assertTrue(button.isVisible())
            self.assertGreaterEqual(button.width(), button.minimumSizeHint().width())

    def test_header_click_shows_table_tools_and_toolbar_click_keeps_header_selection(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": [1, 2], "B": [3, 4]}))
        window.resize(2048, 900)
        window.show()
        self.qapp.processEvents()
        window.table_tools.deactivate()
        header = window.table.horizontalHeader()
        position = QPoint(
            header.sectionViewportPosition(0) + header.sectionSize(0) // 2,
            header.parent_band_rect().center().y(),
        )
        QTest.mouseClick(header.viewport(), Qt.LeftButton, Qt.NoModifier, position)
        self.qapp.processEvents()
        self.assertEqual(window.ui.topToolsTabs.currentWidget(), window.ui.tableToolsPage)
        self.assertEqual(header.selected_parent_columns(), [0])
        self.assertTrue(window.ui.tablePasteButton.isEnabled())
        self.assertFalse(window.ui.tableDeleteColumnsButton.isEnabled())
        with mock.patch.object(QInputDialog, "getText", return_value=("WT", True)):
            QTest.mouseClick(window.ui.tableMergeParentButton, Qt.LeftButton)
        self.assertEqual(window.ui.topToolsTabs.currentWidget(), window.ui.tableToolsPage)
        self.assertEqual(header.selected_parent_columns(), [0])
        self.assertEqual(window.workbook.active_sheet.grouping.parents[0]["name"], "WT")
        window.handle_plot_object_selection("plot_area")
        self.assertFalse(window.ui.topToolsTabs.isTabVisible(window.table_tools.table_index))
        self.assertEqual(window.ui.topToolsTabs.currentWidget(), window.ui.chartToolsPage)

    def test_parent_header_selection_does_not_delete_or_paste_into_stale_cell(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": [1, 2], "B": [3, 4]}))
        table = window.table
        table.setCurrentIndex(table.table_model.index(1, 1))
        window.table_tools.activate(table)
        table.horizontalHeader().select_parent_columns([0])
        before = table.table_model.cells_copy()
        QApplication.clipboard().setText("99")
        window.ui.tablePasteButton.click()
        window.ui.tableDeleteColumnsButton.click()
        self.assertEqual(table.table_model.cells_copy(), before)
        table.horizontalHeader().clear_parent_selection()
        self.select_table_range(table, 1, 1, 1, 1)
        window.table_tools.update_state()
        self.assertTrue(window.ui.tablePasteButton.isEnabled())
        self.assertTrue(window.ui.tableDeleteColumnsButton.isEnabled())

    def test_header_click_blocks_keyboard_edits_until_a_data_cell_is_selected(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": ["11", "22"], "B": ["33", "44"]}))
        window.resize(2048, 900)
        window.show()
        self.qapp.processEvents()
        table = window.table
        old_cell = table.table_model.index(window._table_controller.sample_start_row(), 1)
        QTest.mouseClick(table.viewport(), Qt.LeftButton, Qt.NoModifier, table.visualRect(old_cell).center())
        header = table.horizontalHeader()
        parent_cell = QPoint(
            header.sectionViewportPosition(0) + header.sectionSize(0) // 2,
            header.parent_band_rect().center().y(),
        )
        QTest.mouseClick(header.viewport(), Qt.LeftButton, Qt.NoModifier, parent_cell)
        self.assertEqual(header.selected_parent_columns(), [0])
        self.assertFalse(table.currentIndex().isValid())
        before = table.table_model.cells_copy()
        QApplication.clipboard().setText("99")
        QTest.keySequence(table, QKeySequence(QKeySequence.Paste))
        self.assertEqual(table.table_model.cells_copy(), before)
        QTest.keyClicks(table, "9")
        QTest.keyClick(QApplication.focusWidget(), Qt.Key_Return)
        self.qapp.processEvents()
        self.assertEqual(table.table_model.cells_copy(), before)

        QTest.mouseClick(table.viewport(), Qt.LeftButton, Qt.NoModifier, table.visualRect(old_cell).center())
        self.assertEqual(header.selected_parent_columns(), [])
        QTest.keyClicks(table, "7")
        QTest.keyClick(QApplication.focusWidget(), Qt.Key_Return)
        self.qapp.processEvents()
        self.assertEqual(table.table_model.cell_text(old_cell.row(), old_cell.column()), "7")
        self.assertEqual(table.table_model.cell_text(old_cell.row(), 0), "11")
