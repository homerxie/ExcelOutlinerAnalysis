from __future__ import annotations

from dataclasses import asdict

import numpy as np
import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data import attach_group_metadata, prepare_plot_frames
from easygraph.grouping import GroupingSettings
from easygraph.plotting.group_layout import build_group_layout
from easygraph.plotting.canvas import PlotCanvas
from easygraph.settings import ChartSettings


class GroupedPlottingTests(EasyGraphQtTestCase):
    def setUp(self):
        super().setUp()
        self.ids = ["a-control", "a-dose", "b-control", "b-dose"]
        self.frame = pd.DataFrame([[1, 4, 11, 14], [2, 5, 12, 15], [3, 6, 13, 16]], columns=["Control", "Dose", "Control", "Dose"])
        self.grouping = GroupingSettings(
            parents=[
                {"id": "a", "name": "Experiment A", "column_ids": self.ids[:2]},
                {"id": "b", "name": "Experiment B", "column_ids": self.ids[2:]},
            ],
            shared_subgroups=True,
            subgroup_ids={self.ids[0]: "control", self.ids[1]: "dose", self.ids[2]: "control", self.ids[3]: "dose"},
        )

    def make_canvas(self):
        canvas = PlotCanvas()
        self.addCleanup(canvas.close)
        return canvas

    def test_all_chart_artists_and_statistics_share_group_positions(self):
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            with self.subTest(chart_type=chart_type):
                canvas = self.make_canvas()
                settings = ChartSettings(chart_type=chart_type, jitter=0, show_points=True, line_overlay_stat="Mean", show_stat_table=True, show_stat_mean=True)
                canvas.render(self.frame, settings, grouping=self.grouping, column_ids=self.ids)
                ax = canvas.figure.axes[0]
                layout = canvas._group_layout
                self.assertEqual(list(layout.positions.values()), [0, 1, 3.7, 4.7])
                category_positions = [layout.coordinate(key, ridge=chart_type == "Ridge") for key in self.ids]
                ticks = ax.get_yticks() if chart_type == "Ridge" else ax.get_xticks()
                np.testing.assert_allclose(ticks, category_positions)
                tick_labels = ax.get_yticklabels() if chart_type == "Ridge" else ax.get_xticklabels()
                self.assertEqual([label.get_text() for label in tick_labels], list(self.frame.columns))
                mean_line = next(line for line in ax.lines if line.get_label() == "Mean")
                np.testing.assert_allclose(mean_line.get_ydata() if chart_type == "Ridge" else mean_line.get_xdata(), category_positions)
                np.testing.assert_allclose(mean_line.get_xdata() if chart_type == "Ridge" else mean_line.get_ydata(), [2, 5, 12, 15])
                self.assertEqual([text.get_text() for text in ax.texts if text.get_gid() == "group-parent-label"], ["Experiment A", "Experiment B"])
                table_ax = canvas.figure.axes[1]
                mean_label = next(text for text in table_ax.texts if text.get_text() == "Mean")
                if chart_type == "Ridge":
                    mean_values = [text for text in table_ax.texts if text.get_position()[0] == mean_label.get_position()[0] and text is not mean_label]
                    np.testing.assert_allclose([text.get_position()[1] for text in mean_values], category_positions)
                    np.testing.assert_allclose(
                        [text.get_transform().transform(text.get_position())[1] for text in mean_values],
                        [ax.transData.transform((0, position))[1] for position in category_positions],
                    )
                    self.assertGreater(table_ax.get_position().x0, ax.get_position().x1)
                else:
                    self.assertEqual([text.get_position()[0] for text in table_ax.texts if text.get_position()[1] == mean_label.get_position()[1] and text is not mean_label], [0, 1, 3.7, 4.7])
                self.assertEqual(layout.colors[self.ids[0]], layout.colors[self.ids[2]])
                self.assertEqual([text.get_text() for text in ax.get_legend().get_texts()][:2], ["Control", "Dose"])
                if chart_type == "Box":
                    centers = [(patch.get_path().vertices[:, 0].min() + patch.get_path().vertices[:, 0].max()) / 2 for patch in ax.patches]
                    np.testing.assert_allclose(centers, category_positions)
                elif chart_type == "Violin":
                    from matplotlib.collections import PolyCollection
                    centers = [(collection.get_paths()[0].vertices[:, 0].min() + collection.get_paths()[0].vertices[:, 0].max()) / 2 for collection in ax.collections if isinstance(collection, PolyCollection)]
                    np.testing.assert_allclose(centers, category_positions)

    def test_empty_shared_slot_is_reserved_and_sorting_keeps_parent_blocks(self):
        self.frame = self.frame.astype(float)
        self.frame.iloc[:, 1] = np.nan
        settings = ChartSettings(group_order="Mean descending")
        prepared = prepare_plot_frames(attach_group_metadata(self.frame, self.ids), settings)
        layout = build_group_layout(prepared.visible, settings, self.grouping, self.ids)
        self.assertEqual(layout.order, ("a-control", "a-dose", "b-dose", "b-control"))
        self.assertEqual(layout.positions["b-dose"], 3.7)
        self.assertEqual([parent.center for parent in layout.parents], [0.5, 4.2])

    def test_shared_legend_only_and_zoom_keep_grouping(self):
        settings = ChartSettings(group_label_mode="Legend only", show_outliers=False)
        canvas = self.make_canvas()
        canvas.render(self.frame, settings, grouping=self.grouping, column_ids=self.ids)
        canvas.zoom_by(1.1)
        ax = canvas.figure.axes[0]
        self.assertTrue(all(label.get_text() == "" for label in ax.get_xticklabels()))
        self.assertEqual([text.get_text() for text in ax.get_legend().get_texts()], ["Control", "Dose"])
        self.assertEqual(canvas._group_layout.positions["b-control"], 3.7)

    def test_duplicate_single_level_headers_remain_independent(self):
        canvas = self.make_canvas()
        settings = ChartSettings(line_overlay_stat="Mean", jitter=0)
        canvas.render(self.frame, settings, column_ids=self.ids)
        ax = canvas.figure.axes[0]
        self.assertEqual([label.get_text() for label in ax.get_xticklabels()], list(self.frame.columns))
        means = next(line for line in ax.lines if line.get_label() == "Mean")
        np.testing.assert_allclose(means.get_ydata(), [2, 5, 12, 15])
        self.assertEqual(len(ax.patches), 4)

    def test_secondary_overlays_and_empty_slots_keep_the_same_coordinates(self):
        self.frame = self.frame.astype(float)
        self.frame.iloc[:, 1] = np.nan
        for chart_type in ("Box", "Bar", "Ridge"):
            for split in (False, True):
                with self.subTest(chart_type=chart_type, split=split):
                    canvas = self.make_canvas()
                    settings = ChartSettings(
                        chart_type=chart_type, show_points=False,
                        extra_custom_overlay=True, custom_overlay_secondary_axis=True,
                        split_secondary_axis=split,
                        custom_overlay_series=[{"name": "Response", "values": dict(zip(self.ids, [10, 20, 30, 40]))}],
                    )
                    canvas.render(self.frame, settings, grouping=self.grouping, column_ids=self.ids)
                    ax = canvas.figure.axes[0]
                    secondary = next(axis for axis in canvas.figure.axes if axis.get_gid() == "secondary-axis")
                    line = next(line for line in secondary.lines if line.get_label() == "Response")
                    expected = [canvas._group_layout.coordinate(key, ridge=chart_type == "Ridge") for key in [self.ids[0], self.ids[2], self.ids[3]]]
                    np.testing.assert_allclose(line.get_ydata() if chart_type == "Ridge" else line.get_xdata(), expected)
                    if chart_type == "Ridge":
                        np.testing.assert_allclose(secondary.get_ylim(), ax.get_ylim())
                    else:
                        np.testing.assert_allclose(secondary.get_xlim(), ax.get_xlim())
                        if chart_type == "Bar":
                            self.assertEqual(ax.get_ylim()[0], 0)
                            self.assertGreater(secondary.get_ylim()[0], 0)

    def test_legacy_display_name_settings_are_mapped_without_mutating_caller(self):
        canvas = self.make_canvas()
        settings = ChartSettings(custom_colors={"Control": "#ff0000"})
        canvas.render(self.frame, settings, column_ids=self.ids)
        self.assertEqual(canvas._group_layout.colors[self.ids[0]], "#ff0000")
        self.assertEqual(canvas._group_layout.colors[self.ids[2]], "#ff0000")
        self.assertEqual(settings.custom_colors, {"Control": "#ff0000"})

    def test_parent_coloring_never_hides_subgroup_names(self):
        canvas = self.make_canvas()
        settings = ChartSettings(group_color_mode="Parent", group_label_mode="Legend only")
        canvas.render(self.frame, settings, grouping=self.grouping, column_ids=self.ids)
        self.assertEqual([label.get_text() for label in canvas.figure.axes[0].get_xticklabels()], list(self.frame.columns))

    def test_dataframe_grouping_metadata_is_used_unless_explicitly_overridden(self):
        frame = attach_group_metadata(self.frame, self.ids)
        frame.attrs["grouping"] = asdict(self.grouping)
        canvas = self.make_canvas()
        settings = ChartSettings(group_order="Mean descending")
        canvas.render(frame, settings)
        self.assertEqual([parent.label for parent in canvas._group_layout.parents], ["Experiment A", "Experiment B"])
        self.assertEqual(canvas._group_layout.order, ("a-dose", "a-control", "b-dose", "b-control"))
        self.assertEqual(canvas._group_layout.positions["b-dose"], 3.7)
        self.assertEqual(canvas._last_grouping, self.grouping)

        canvas.render(frame, settings, grouping=GroupingSettings())
        self.assertEqual(canvas._group_layout.parents, ())
        self.assertEqual(canvas._group_layout.order, ("b-dose", "b-control", "a-dose", "a-control"))

    def test_multiline_group_headers_leave_real_text_bounds_clear(self):
        self.frame.columns = [f"{name}\nDay 1\nMorning" for name in self.frame.columns]
        for parent in self.grouping.parents:
            parent["name"] += "\nBiological\nreplicates"
        for chart_type in ("Box", "Bar", "Violin", "Ridge"):
            for rotation in (0, 45):
                for show_table in (False, True):
                    with self.subTest(chart_type=chart_type, rotation=rotation, show_table=show_table):
                        canvas = self.make_canvas()
                        settings = ChartSettings(chart_type=chart_type, x_tick_rotation=rotation, show_stat_table=show_table)
                        canvas.render(self.frame, settings, grouping=self.grouping, column_ids=self.ids)
                        ax = canvas.figure.axes[0]
                        renderer = canvas.canvas.get_renderer()
                        ridge = chart_type == "Ridge"
                        ticks = ax.get_yticklabels() if ridge else ax.get_xticklabels()
                        leaf_bounds = [label.get_window_extent(renderer) for label in ticks]
                        parent_bounds = [text.get_window_extent(renderer) for text in ax.texts if text.get_gid() == "group-parent-label"]
                        bracket_bounds = [line.get_window_extent(renderer) for line in ax.lines if line.get_gid() == "group-parent-bracket"]
                        axis_label = (ax.yaxis.label if ridge else ax.xaxis.label).get_window_extent(renderer)
                        if ridge:
                            self.assertLess(max(bounds.x1 for bounds in bracket_bounds), min(bounds.x0 for bounds in leaf_bounds))
                            self.assertLess(max(bounds.x1 for bounds in parent_bounds), min(bounds.x0 for bounds in bracket_bounds))
                            self.assertLess(axis_label.x1, min(bounds.x0 for bounds in parent_bounds))
                        else:
                            self.assertLess(max(bounds.y1 for bounds in bracket_bounds), min(bounds.y0 for bounds in leaf_bounds))
                            self.assertLess(max(bounds.y1 for bounds in parent_bounds), min(bounds.y0 for bounds in bracket_bounds))
                            self.assertLess(axis_label.y1, min(bounds.y0 for bounds in parent_bounds))
                        for bounds in parent_bounds:
                            self.assertGreaterEqual(bounds.x0, 0)
                            self.assertGreaterEqual(bounds.y0, 0)
