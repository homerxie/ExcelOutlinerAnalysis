from tests.easygraph_case import EasyGraphQtTestCase
from easygraph.data_table import DataTable
from easygraph.grouping import GroupingSettings
from easygraph.settings import ChartSettings
from easygraph.table_snapshot import (
    apply_sheet_state_snapshot,
    apply_snapshot_settings,
    build_sheet_state_snapshot,
    build_table_snapshot,
    snapshot_cell_text,
    snapshot_current_cell,
    snapshot_shape,
)
from easygraph.workbook import SHEET_MODE_XY, SheetDocument
from easygraph.xy_series import XYSeriesSpec, XYSettings

import pandas as pd


class TableSnapshotTests(EasyGraphQtTestCase):
    def test_build_table_snapshot_captures_cells_and_settings(self):
        table = DataTable(2, 2)
        self.addCleanup(table.deleteLater)
        table.table_model.replace_cells([["A", "B"], ["1", ""]], column_count=2)
        table.setCurrentIndex(table.table_model.index(1, 0))
        settings = ChartSettings(
            custom_overlay_series=[{"name": "Overlay", "values": {"A": "10"}}],
            custom_overlay_count=2,
            extra_custom_overlay=True,
            custom_overlay_hidden=[0],
            custom_overlay_styles={"custom:0": "Dashed"},
            manual_group_order=["B", "A"],
            group_hidden=["A"],
        )

        snapshot = build_table_snapshot(table, settings, custom_overlay_rows=1)

        self.assertEqual(snapshot["cells"], [["A", "B"], ["1", ""]])
        self.assertEqual(snapshot["current_row"], 1)
        self.assertEqual(snapshot["current_col"], 0)
        self.assertEqual(snapshot["custom_overlay_rows"], 1)
        self.assertEqual(snapshot["custom_overlay_series"], settings.custom_overlay_series)
        self.assertIsNot(snapshot["custom_overlay_series"], settings.custom_overlay_series)
        self.assertEqual(snapshot["custom_overlay_styles"], {"custom:0": "Dashed"})
        self.assertEqual(snapshot["manual_group_order"], ["B", "A"])
        self.assertEqual(snapshot["group_hidden"], ["A"])

    def test_snapshot_helpers_shape_cells_and_current_cell(self):
        snapshot = {
            "cells": [["A"], ["1", "2"]],
            "current_row": 9,
            "current_col": -2,
        }

        self.assertEqual(snapshot_shape(snapshot), (2, 2))
        self.assertEqual(snapshot_cell_text(snapshot, 1, 1), "2")
        self.assertEqual(snapshot_cell_text(snapshot, 0, 1), "")
        self.assertEqual(snapshot_current_cell(snapshot, row_count=2, col_count=2), (1, 0))

    def test_apply_snapshot_settings_restores_overlay_and_group_state(self):
        settings = ChartSettings(custom_overlay_series=[{"name": "Old", "values": {}}])
        snapshot = {
            "custom_overlay_series": [{"name": "New", "values": {"A": "1"}}],
            "custom_overlay_count": 3,
            "extra_custom_overlay": True,
            "custom_overlay_hidden": [1],
            "custom_overlay_styles": {"custom:0": "Dotted"},
            "manual_group_order": ["A"],
            "group_hidden": ["B"],
        }

        apply_snapshot_settings(snapshot, settings)

        self.assertEqual(settings.custom_overlay_series, [{"name": "New", "values": {"A": "1"}}])
        self.assertEqual(settings.custom_overlay_count, 3)
        self.assertTrue(settings.extra_custom_overlay)
        self.assertEqual(settings.custom_overlay_hidden, [1])
        self.assertEqual(settings.custom_overlay_styles, {"custom:0": "Dotted"})
        self.assertEqual(settings.manual_group_order, ["A"])
        self.assertEqual(settings.group_hidden, ["B"])

    def test_sheet_state_snapshot_deep_copies_xy_mapping_and_restores_it(self):
        sheet = SheetDocument(
            name="XY",
            dataframe=pd.DataFrame({"X": [1], "Y": [2]}),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=XYSettings(
                default_x_column_id="x",
                series=[XYSeriesSpec(id="series", name="Y", y_column_id="y")],
            ),
        )
        snapshot = build_sheet_state_snapshot(sheet)

        sheet.column_ids[0] = "changed"
        sheet.xy_settings.series[0].name = "Changed"
        apply_sheet_state_snapshot(snapshot, sheet)

        self.assertEqual(sheet.mode, SHEET_MODE_XY)
        self.assertEqual(sheet.column_ids, ["x", "y"])
        self.assertEqual(sheet.xy_settings.series[0].name, "Y")
        snapshot["xy_settings"]["series"][0]["name"] = "Snapshot changed"
        self.assertEqual(sheet.xy_settings.series[0].name, "Y")

    def test_sheet_state_snapshot_restores_group_membership_and_shared_categories(self):
        sheet = SheetDocument(name="Groups", dataframe=pd.DataFrame([[1, 2]], columns=["A", "A"]), column_ids=["a", "b"], grouping=GroupingSettings(parents=[{"id": "p", "name": "Parent", "column_ids": ["a", "b"]}], shared_subgroups=True, subgroup_ids={"a": "first", "b": "second"}))
        snapshot = build_sheet_state_snapshot(sheet)
        sheet.grouping.parents[0]["name"] = "Changed"
        sheet.grouping.subgroup_ids.clear()
        apply_sheet_state_snapshot(snapshot, sheet)
        self.assertEqual(sheet.grouping.parents[0]["name"], "Parent")
        self.assertEqual(sheet.grouping.subgroup_ids, {"a": "first", "b": "second"})
        snapshot["grouping"]["parents"][0]["column_ids"].clear()
        self.assertEqual(sheet.grouping.parents[0]["column_ids"], ["a", "b"])
