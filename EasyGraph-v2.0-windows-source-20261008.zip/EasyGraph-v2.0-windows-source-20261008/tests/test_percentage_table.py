from __future__ import annotations

from pathlib import Path
import tempfile
from unittest import mock

import pandas as pd
from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QLineEdit

from tests.easygraph_case import EasyGraphQtTestCase
from easygraph import project_io
from easygraph.data import prepare_plot_frames
from easygraph.data_table import DataTable
from easygraph.table_clipboard import selected_range_to_tsv
from easygraph.ui.table_controller import TableController, TableControllerHooks
from easygraph.workbook import SHEET_MODE_XY, SheetDocument
from easygraph.xy_data import prepare_xy_data
from easygraph.xy_series import XYSeriesSpec, XYSettings


class PercentageTableTests(EasyGraphQtTestCase):
    @staticmethod
    def plotted_group_values(window):
        return sorted(
            float(y)
            for axis in window.canvas.figure.axes
            for artist in axis.collections
            if artist.get_gid() == "data-points"
            for _x, y in artist.get_offsets()
        )

    def test_inline_percentage_edit_plots_and_preserves_copy_and_history(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Rate": [""]}))
        window._table_controller.reset_history()
        model = window.table.table_model
        window.table.setCurrentIndex(model.index(1, 0))
        window.table.edit(model.index(1, 0))
        self.qapp.processEvents()
        editor = window.table.findChild(QLineEdit)
        self.assertIsNotNone(editor)

        QTest.keyClicks(editor, "25%")
        self.qapp.sendEvent(
            editor, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier)
        )
        self.qapp.processEvents()
        window.flush_pending_render()

        self.assertEqual(model.cell_text(1, 0), "25%")
        self.assertEqual(self.plotted_group_values(window), [0.25])
        self.select_table_range(window.table, 1, 0, 1, 0)
        window.copy_table_selection(window.table)
        self.assertEqual(QApplication.clipboard().text(), "25%")

        window.undo_table_change()
        self.assertEqual(model.cell_text(1, 0), "")
        window.redo_table_change()
        self.assertEqual(model.cell_text(1, 0), "25%")
        window.flush_pending_render()
        self.assertEqual(self.plotted_group_values(window), [0.25])

    def test_pasted_percentages_plot_and_survive_project_round_trip(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"A": [""], "B": [""]}))
        window._table_controller.reset_history()
        model = window.table.table_model
        window.table.setCurrentIndex(model.index(1, 0))
        text = "25%\t50%\n-12.5 %\t1.5\ninvalid%\t80％"
        QApplication.clipboard().setText(text)

        window.paste_table_selection(window.table)
        window.flush_pending_render()

        expected_values = [-0.125, 0.25, 0.5, 0.8, 1.5]
        self.assertEqual(self.plotted_group_values(window), expected_values)
        self.select_table_range(window.table, 1, 0, 3, 1)
        window.copy_table_selection(window.table)
        self.assertEqual(QApplication.clipboard().text(), text)
        self.assertEqual(len(window._table_controller.history.undo_stack), 1)

        window.undo_table_change()
        self.assertEqual(model.cell_text(1, 0), "")
        window.redo_table_change()
        self.assertEqual(model.cell_text(1, 0), "25%")
        self.assertEqual(model.cell_text(3, 1), "80％")

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "percentages.eg"
            window.current_project = path
            self.assertTrue(window.save_project())
            restored, restored_settings = project_io.read_project(path)

        self.assertEqual(restored.iloc[:3, :2].values.tolist(), [
            ["25%", "50%"], ["-12.5 %", "1.5"], ["invalid%", "80％"],
        ])
        restored_table = DataTable()
        self.addCleanup(restored_table.deleteLater)
        restored_table.set_dataframe(restored)
        self.assertEqual(restored_table.table_model.cell_text(1, 0), "25%")
        plotted = prepare_plot_frames(restored, restored_settings)
        self.assertEqual(sorted(plotted.visible["value"].tolist()), expected_values)

    def test_xy_controller_paste_keeps_percentage_rows_paired(self):
        sheet = SheetDocument(
            name="Percentages",
            dataframe=pd.DataFrame({"X": ["", "", ""], "Y": ["", "", ""]}),
            mode=SHEET_MODE_XY,
            column_ids=["x", "y"],
            xy_settings=XYSettings(
                default_x_column_id="x",
                series=[XYSeriesSpec(id="series", name="Y", y_column_id="y")],
            ),
        )
        table = DataTable()
        self.addCleanup(table.deleteLater)
        controller = TableController(
            table=table,
            settings=lambda: sheet.settings,
            sheet=lambda: sheet,
            hooks=TableControllerHooks(
                render=mock.Mock(),
                update_history_actions=mock.Mock(),
                update_dependent_controls=mock.Mock(),
                sync_overlay_controls=mock.Mock(),
            ),
        )
        controller.set_dataframe(sheet.dataframe)
        controller.reset_history()
        table.setCurrentIndex(table.table_model.index(1, 0))
        text = "25%\t50%\n10%\tinvalid%\n75%\t100%"

        self.assertTrue(controller.paste_text(text))

        prepared = prepare_xy_data(controller.dataframe(), sheet.column_ids, sheet.xy_settings)
        self.assertEqual(prepared.series[0].x.tolist(), [0.25, 0.75])
        self.assertEqual(prepared.series[0].y.tolist(), [0.5, 1.0])
        self.assertEqual(prepared.series[0].row_indexes, (0, 2))
        self.assertEqual(prepared.series[0].skipped_row_indexes, (1,))
        self.select_table_range(table, 1, 0, 3, 1)
        self.assertEqual(selected_range_to_tsv(table), text)
