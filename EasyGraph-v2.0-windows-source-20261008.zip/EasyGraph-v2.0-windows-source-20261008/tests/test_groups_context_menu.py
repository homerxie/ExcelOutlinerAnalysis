from unittest import mock

import pandas as pd

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.workbook import SHEET_MODE_XY


def action_texts(menu) -> list[str]:
    return [action.text() for action in menu.actions() if not action.isSeparator()]


def action_with_text(menu, text: str):
    return next(action for action in menu.actions() if action.text() == text)


class GroupsContextMenuTests(EasyGraphQtTestCase):
    def test_groups_toolbar_has_no_row_or_column_structure_buttons(self):
        window = self.make_window()

        self.assertFalse(hasattr(window.ui, "addRowButton"))
        self.assertFalse(hasattr(window.ui, "addColumnButton"))
        self.assertFalse(hasattr(window.ui, "deleteColumnButton"))

    def test_groups_cell_selection_offers_unified_structure_submenus(self):
        window = self.make_window()
        self.select_table_range(window.table, 1, 1, 1, 1)

        menu = window.table_context_menu(window.table, "cells")
        texts = action_texts(menu)

        self.assertEqual(
            texts,
            ["Copy", "Paste", "Cut", "Clear Contents", "Insert", "Delete", "Parent headers"],
        )
        self.assertIsNotNone(action_with_text(menu, "Insert").menu())
        self.assertIsNotNone(action_with_text(menu, "Delete").menu())

    def test_groups_row_and_column_headers_offer_direct_structure_actions(self):
        window = self.make_window()
        window.table.selectRow(1)
        row_menu = window.table_context_menu(window.table, "rows")
        window.table.selectColumn(1)
        column_menu = window.table_context_menu(window.table, "columns")

        self.assertIsNone(action_with_text(row_menu, "Insert").menu())
        self.assertIsNone(action_with_text(column_menu, "Insert subgroup left").menu())
        self.assertIsNone(action_with_text(column_menu, "Insert subgroup right").menu())
        for menu in (row_menu, column_menu):
            self.assertIsNone(action_with_text(menu, "Delete").menu())

    def test_groups_single_column_cell_selection_keeps_column_insert_available(self):
        window = self.make_window()
        window.set_table_dataframe(pd.DataFrame({"Only": ["1"]}))
        self.select_table_range(window.table, 1, 0, 1, 0)

        menu = window.table_context_menu(window.table, "cells")
        insert_action = action_with_text(menu, "Insert")
        insert_menu = insert_action.menu()
        self.assertIsNotNone(insert_menu)

        self.assertTrue(action_with_text(insert_menu, "Insert subgroup left").isEnabled())

    def test_xy_context_menus_use_the_same_unified_structure_contract(self):
        window = self.make_window()
        with mock.patch.object(window, "render"):
            window.add_sheet(SHEET_MODE_XY)

        for table in (window.table, window.xy_independent_table):
            self.select_table_range(table, 1, 0, 1, 0)
            texts = action_texts(window.table_context_menu(table, "cells"))
            self.assertIn("Insert", texts)
            self.assertIn("Delete", texts)
            self.assertIn("Clear Contents", texts)
            self.assertNotIn("Insert Y", texts)
            self.assertNotIn("Delete Y", texts)
            self.assertNotIn("Insert Data Pair", texts)
            self.assertNotIn("Delete Data Pair", texts)


if __name__ == "__main__":
    import unittest

    unittest.main()
