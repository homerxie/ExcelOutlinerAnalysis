from __future__ import annotations

import pandas as pd

from tests.easygraph_case import EasyGraphTestCase

from easygraph.xy_table_data import (
    dataframe_column_subset,
    dataframe_with_trailing_blank_row,
    replace_dataframe_columns,
)


class XYTableDataTests(EasyGraphTestCase):
    def test_editable_frame_preserves_rows_and_appends_after_a_used_last_row(self):
        blank = pd.DataFrame([[""]] * 14, columns=["Y"])
        preserved = dataframe_with_trailing_blank_row(blank)
        self.assertEqual(preserved.shape, (14, 1))

        blank.iloc[13, 0] = "value"
        expanded = dataframe_with_trailing_blank_row(blank)
        self.assertEqual(expanded.shape, (15, 1))
        self.assertEqual(expanded.iloc[13, 0], "value")
        self.assertEqual(expanded.iloc[14, 0], "")

    def test_column_subset_uses_stable_ids_with_duplicate_names(self):
        source = pd.DataFrame(
            [[1, 10, 2, 20]],
            columns=["Time", "Response", "Time", "Response"],
        )

        subset = dataframe_column_subset(
            source,
            ["x1", "y1", "x2", "y2"],
            ["x2", "y2"],
        )

        self.assertEqual(list(subset.columns), ["Time", "Response"])
        self.assertEqual(subset.iloc[0].tolist(), [2, 20])

    def test_replacing_subset_updates_names_values_and_extends_other_columns(self):
        source = pd.DataFrame([[1, 10, 100]], columns=["X", "A", "Keep"])
        edited = pd.DataFrame([[2, 20], [3, 30]], columns=["Time", "Dose"])

        result = replace_dataframe_columns(
            source,
            ["x", "a", "keep"],
            edited,
            ["x", "a"],
        )

        self.assertEqual(list(result.columns), ["Time", "Dose", "Keep"])
        self.assertEqual(result.iloc[:, 0].tolist(), [2, 3])
        self.assertEqual(result.iloc[:, 1].tolist(), [20, 30])
        self.assertEqual(result.iloc[0, 2], 100)
        self.assertEqual(result.iloc[1, 2], "")
