from __future__ import annotations

from dataclasses import asdict

import pandas as pd
from matplotlib.figure import Figure
from PySide6.QtWidgets import QWidget

from tests.easygraph_case import EasyGraphQtTestCase

from easygraph.plotting.xy_renderer import draw_xy_series
from easygraph.project_io import xy_settings_from_dict
from easygraph.ui.xy_series_dialog import create_xy_series_dialog
from easygraph.xy_data import prepare_xy_data
from easygraph.xy_series import XYSeriesSpec, XYSettings


class XYSeriesStyleOverrideTests(EasyGraphQtTestCase):
    @staticmethod
    def _prepared(settings: XYSettings):
        frame = pd.DataFrame(
            {
                "X": [0.0, 1.0, 2.0],
                "A": [1.0, 3.0, 2.0],
                "B": [2.0, 1.0, 4.0],
            }
        )
        return prepare_xy_data(frame, ["x", "a", "b"], settings)

    def test_renderer_resolves_numeric_style_overrides_per_series(self):
        settings = XYSettings(
            default_x_column_id="x",
            point_size=4.0,
            point_alpha=0.8,
            line_width=1.5,
            series=[
                XYSeriesSpec(
                    id="a",
                    name="A",
                    y_column_id="a",
                    point_size=8.0,
                    point_alpha=0.25,
                    line_width=3.25,
                ),
                XYSeriesSpec(id="b", name="B", y_column_id="b"),
            ],
        )
        figure = Figure()
        axes = figure.subplots()

        overridden, inherited = draw_xy_series(
            axes,
            self._prepared(settings),
            settings,
            ["#123456", "#abcdef"],
        )

        self.assertEqual(overridden.get_markersize(), 8.0)
        self.assertEqual(overridden.get_linewidth(), 3.25)
        self.assertAlmostEqual(overridden.get_markerfacecolor()[3], 0.25)
        self.assertIsNone(overridden.get_alpha())
        self.assertEqual(inherited.get_markersize(), 4.0)
        self.assertEqual(inherited.get_linewidth(), 1.5)
        self.assertAlmostEqual(inherited.get_markerfacecolor()[3], 0.8)
        self.assertIsNone(inherited.get_alpha())

    def test_scatter_renderer_uses_point_size_and_alpha_override(self):
        settings = XYSettings(
            default_x_column_id="x",
            show_points=True,
            show_line=False,
            point_size=4.0,
            point_alpha=0.8,
            series=[
                XYSeriesSpec(
                    id="a",
                    name="A",
                    y_column_id="a",
                    point_size=7.0,
                    point_alpha=0.35,
                )
            ],
        )
        figure = Figure()
        axes = figure.subplots()

        artist = draw_xy_series(
            axes,
            self._prepared(settings),
            settings,
            ["#123456"],
        )[0]

        self.assertEqual(artist.get_sizes().tolist(), [49.0])
        self.assertEqual(artist.get_alpha(), 0.35)

    def test_project_codec_accepts_new_overrides_and_defaults_old_payloads(self):
        settings = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(
                    id="series-a",
                    name="A",
                    y_column_id="a",
                    point_size=6.5,
                    point_alpha=0.4,
                    line_width=2.75,
                )
            ],
        )
        payload = asdict(settings)

        restored = xy_settings_from_dict(payload, ["x", "a"])

        self.assertEqual(asdict(restored), payload)

        legacy_payload = asdict(settings)
        for field_name in ("point_size", "point_alpha", "line_width"):
            legacy_payload["series"][0].pop(field_name)
        legacy = xy_settings_from_dict(legacy_payload, ["x", "a"])
        self.assertIsNone(legacy.series[0].point_size)
        self.assertIsNone(legacy.series[0].point_alpha)
        self.assertIsNone(legacy.series[0].line_width)

    def test_series_dialog_rebuild_preserves_numeric_style_overrides(self):
        parent = QWidget()
        self.addCleanup(parent.close)
        frame = pd.DataFrame(
            {
                "X": [0.0, 1.0],
                "A": [1.0, 2.0],
                "B": [2.0, 3.0],
            }
        )
        settings = XYSettings(
            default_x_column_id="x",
            series=[
                XYSeriesSpec(
                    id="a",
                    name="A",
                    y_column_id="a",
                    point_size=6.0,
                    point_alpha=0.45,
                    line_width=2.4,
                ),
                XYSeriesSpec(id="b", name="B", y_column_id="b"),
            ],
        )
        controller = create_xy_series_dialog(
            parent,
            frame,
            ["x", "a", "b"],
            settings,
        )
        self.addCleanup(controller.dialog.close)
        controller.ui.seriesTable.selectRow(0)

        controller.move_selected_series(1)
        result = controller.result()
        preserved = next(series for series in result.series if series.id == "a")

        self.assertEqual(preserved.point_size, 6.0)
        self.assertEqual(preserved.point_alpha, 0.45)
        self.assertEqual(preserved.line_width, 2.4)


if __name__ == "__main__":
    __import__("unittest").main()
