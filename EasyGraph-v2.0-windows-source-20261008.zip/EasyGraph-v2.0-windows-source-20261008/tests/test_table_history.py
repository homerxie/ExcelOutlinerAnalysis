from tests.easygraph_case import EasyGraphTestCase
from easygraph.table_history import (
    BlockEdit,
    CellEdit,
    SettingsEdit,
    StructureSnapshotEdit,
    TableHistoryState,
    run_table_history_mutation,
)


class FakeHistoryTarget:
    def __init__(self):
        self.cells = {}
        self.settings = {}
        self.snapshot = None

    def apply_history_cells(self, values, settings=None):
        for row, column, text in values:
            self.cells[(row, column)] = text
        if settings is not None:
            self.settings = settings

    def apply_history_settings(self, settings):
        self.settings = settings

    def restore_history_snapshot(self, snapshot):
        self.snapshot = snapshot


class TableHistoryStateTests(EasyGraphTestCase):
    def test_cell_edit_has_explicit_apply_and_revert_directions(self):
        target = FakeHistoryTarget()
        edit = CellEdit(2, 3, "old", "new")

        edit.apply(target)
        self.assertEqual(target.cells[(2, 3)], "new")
        edit.revert(target)
        self.assertEqual(target.cells[(2, 3)], "old")

    def test_block_edit_applies_cells_and_small_settings_atomically(self):
        target = FakeHistoryTarget()
        edit = BlockEdit(
            cells=(
                CellEdit(1, 0, "a", "A"),
                CellEdit(1, 1, "b", "B"),
            ),
            settings_before={"manual_group_order": ["a", "b"]},
            settings_after={"manual_group_order": ["A", "B"]},
        )

        edit.apply(target)
        self.assertEqual(target.cells, {(1, 0): "A", (1, 1): "B"})
        self.assertEqual(target.settings, {"manual_group_order": ["A", "B"]})
        edit.revert(target)
        self.assertEqual(target.cells, {(1, 0): "a", (1, 1): "b"})
        self.assertEqual(target.settings, {"manual_group_order": ["a", "b"]})

    def test_settings_edit_and_structure_snapshot_have_explicit_directions(self):
        target = FakeHistoryTarget()
        settings = SettingsEdit({"hidden": []}, {"hidden": [1]})
        structure = StructureSnapshotEdit(
            {"cells": [["old"]]},
            {"cells": [["new"]]},
        )

        settings.apply(target)
        self.assertEqual(target.settings, {"hidden": [1]})
        settings.revert(target)
        self.assertEqual(target.settings, {"hidden": []})
        structure.apply(target)
        self.assertEqual(target.snapshot, {"cells": [["new"]]})
        structure.revert(target)
        self.assertEqual(target.snapshot, {"cells": [["old"]]})

    def test_record_limits_commands_clears_redo_and_ignores_noops(self):
        history = TableHistoryState(limit=2)
        history.redo_stack.append(CellEdit(0, 0, "x", "y"))

        history.record(CellEdit(0, 0, "same", "same"))
        self.assertEqual(len(history.undo_stack), 0)
        self.assertEqual(len(history.redo_stack), 1)

        history.record(CellEdit(0, 0, "0", "1"))
        history.record(CellEdit(0, 0, "1", "2"))
        history.record(CellEdit(0, 0, "2", "3"))

        self.assertEqual(
            history.undo_stack,
            [CellEdit(0, 0, "1", "2"), CellEdit(0, 0, "2", "3")],
        )
        self.assertEqual(history.redo_stack, [])

    def test_undo_and_redo_apply_the_same_command_symmetrically(self):
        history = TableHistoryState()
        target = FakeHistoryTarget()
        edit = CellEdit(0, 0, "old", "new")
        history.record(edit)
        target.cells[(0, 0)] = "new"

        self.assertIs(history.undo(target), edit)
        self.assertEqual(target.cells[(0, 0)], "old")
        self.assertFalse(history.can_undo)
        self.assertTrue(history.can_redo)

        self.assertIs(history.redo(target), edit)
        self.assertEqual(target.cells[(0, 0)], "new")
        self.assertTrue(history.can_undo)
        self.assertFalse(history.can_redo)

    def test_run_table_history_mutation_suspends_history_and_reports_changed_result(self):
        calls = []
        suspended = []

        def snapshot():
            calls.append("snapshot")
            return {"cells": [["before"]]}

        def mutate():
            calls.append("mutate")
            return "changed"

        before, result, changed = run_table_history_mutation(
            snapshot,
            suspended.append,
            mutate,
        )

        self.assertEqual(before, {"cells": [["before"]]})
        self.assertEqual(result, "changed")
        self.assertTrue(changed)
        self.assertEqual(calls, ["snapshot", "mutate"])
        self.assertEqual(suspended, [True, False])

    def test_run_table_history_mutation_restores_suspension_when_mutation_fails(self):
        suspended = []

        def mutate():
            raise RuntimeError("boom")

        with self.assertRaisesRegex(RuntimeError, "boom"):
            run_table_history_mutation(lambda: {"cells": []}, suspended.append, mutate)

        self.assertEqual(suspended, [True, False])

    def test_run_table_history_mutation_treats_only_false_bool_as_unchanged(self):
        _before, result, changed = run_table_history_mutation(
            lambda: {"cells": []},
            lambda _value: None,
            lambda: 0,
        )
        self.assertEqual(result, 0)
        self.assertTrue(changed)

        _before, result, changed = run_table_history_mutation(
            lambda: {"cells": []},
            lambda _value: None,
            lambda: False,
        )
        self.assertFalse(result)
        self.assertFalse(changed)
