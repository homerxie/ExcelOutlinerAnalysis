# Lucide toolbar icons

These fourteen icons are vendored unchanged from fixed Lucide releases. All use a
24 × 24 canvas and 2px stroke, matching the Tabler toolbar icons.

From **0.468.0** (ISC; see the included upstream `LICENSE`):

- `table-cells-merge.svg`: https://github.com/lucide-icons/lucide/blob/0.468.0/icons/table-cells-merge.svg
- `table.svg`: https://github.com/lucide-icons/lucide/blob/0.468.0/icons/table.svg
- `chart-candlestick.svg`: https://github.com/lucide-icons/lucide/blob/0.468.0/icons/chart-candlestick.svg

From **1.51.0** (ISC; see the included upstream `LICENSE-1.51.0`):

- `layout-arrow-right.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/layout-arrow-right.svg
- `layout-arrow-down.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/layout-arrow-down.svg
- `broom-sparkles.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/broom-sparkles.svg
- `a-arrow-up.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/a-arrow-up.svg
- `a-arrow-down.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/a-arrow-down.svg
- `zoom-in.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/zoom-in.svg
- `zoom-out.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/zoom-out.svg
- `square-dimensions.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/square-dimensions.svg
- `scaling.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/scaling.svg
- `chart-no-axes-combined.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/chart-no-axes-combined.svg
- `images.svg`: https://github.com/lucide-icons/lucide/blob/1.51.0/icons/images.svg

The `1.51.0` tag resolves to commit `45b0e148db4ee4d748340d0f99982aa1c2159d52`.

Colors are applied at render time. No network access is required at runtime.
