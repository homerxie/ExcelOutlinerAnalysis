# Tabler toolbar icons

This directory contains the 21 outline SVG icons used by EasyGraph's Chart and
Table toolbars, vendored unchanged from Tabler Icons **v3.48.0**.

- Upstream: https://github.com/tabler/tabler-icons/tree/v3.48.0/icons/outline
- License: MIT; see the included upstream `LICENSE`.
- Original canvas: 24 × 24, 2px stroke.

The application replaces `currentColor` while rendering normal and disabled
states, and scales the SVGs for the display's pixel density. No network access
or extra icon package is required at runtime.
