# EasyGraph v2.0

EasyGraph v2.0 is a local Python/PySide6 desktop app for lightweight scientific distribution and XY plots. It is intentionally simpler than GraphPad-style software and focuses on a fast workflow for box, bar, violin, ridge, and multi-series XY plots.

## Quick Start

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
source .venv/bin/activate
python src/app.py
```

The startup window offers **Group** and **XY** sheets. Group demos include the
original **Single-level headers** example and a **Two-level headers** example
with parent groups and shared subgroups. Choose a demo and click **Open Demo**,
or use **Create Blank** to start without sample data. XY keeps its own example.

The **Recent projects** table below lists recently opened or saved projects,
newest first, with their locations. Double-click a row, press Enter on a selected
row, or click **Open selected project** to reopen it. Missing files produce a
message and are removed from the list; a file that cannot be loaded returns to
the startup chooser so you can choose another project or create a new one.
Opening a recent project at startup shows the main window with **Preparing
preview…** before initializing the chart, following the same flow as a demo.

If dependencies are missing:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
source .venv/bin/activate
pip install -r requirements.txt
```

## Windows Packaging

For Windows wheel installation and PyInstaller packaging notes, see
`WINDOWS_BUILD.md`. The Windows dependency file is `requirements-windows.txt`.

macOS application bundles use `icon/dark/EasyGraph_dark.icns` and the matching
light or dark PNG sets retain the standard 100 px master-canvas inset. Windows
builds instead use `icon/windows/EasyGraph.ico` plus the Windows light/dark PNG
sets, whose artwork is cropped to the alpha bounds so the EXE, taskbar, and
window icon do not look undersized. Changing the application theme also changes
the running taskbar or Dock icon.

Create a source package for transfer to Windows:

```bash
cd "/Users/xiezihong/Documents/Programming/EasyGraph"
python scripts/package_windows_release.py
```

On macOS, build the application bundle and run the frozen render/export smoke
test with:

```bash
./scripts/build_and_smoke_macos.sh
```

Packaged Windows and macOS builds register `.eg` as an EasyGraph project type.
On Windows, the portable build installs the per-user association when
`EasyGraph.exe` is first launched; no administrator access is required. On
macOS, the application bundle declares the `com.easygraph.project` document
type, so Finder can open `.eg` files whether EasyGraph is closed or already
running. The project document type uses the dedicated platform icons from
`icon/EasyGraph_Project_Icon_Pack`, independently of the application icon.

## Core Features

- Editable in-app table using a wide data format.
- Percentage input and paste: `25%` (or `25％`) is calculated as `0.25`, with
  percentage tick labels on the corresponding chart axes and exported figures.
- Box plot, violin plot, and ridge plot.
- Multi-series XY plots with shared X, adjacent XY pairs, or mixed per-series X/Y mappings.
- XY points and connecting lines are both enabled by default and can be styled or hidden independently.
- Series visibility, colors, display order, and per-series point/line overrides use stable series identities.
- Show all data points over distributions.
- Data point jitter modes: `Quasirandom` by default, plus `Beeswarm` and `Random`.
- Outlier detection with IQR, Z-score, MAD, or percentile rules.
- Outlier behavior: `Mark only` or `Exclude from distribution`.
- Box whisker modes: Tukey 1.5 IQR, Min-Max, Percentile 5-95, Percentile 10-90.
- Professional presets and transparent background support.
- Copy current figure to clipboard as PNG, with transparent background when enabled.
- Export PNG, SVG, PDF, TIFF, TIF, JPG, or JPEG through Matplotlib.
- Save/open multi-sheet project files with the `.eg` suffix.
- Recover unsaved work after an abnormal exit using background `.eg` checkpoints
  and compact JSONL edit journals.
- Add, duplicate, rename, reorder, switch, and delete independent chart sheets.
- Import/export Excel workbooks and single-sheet CSV files.
- Import all or selected Prism 8–11 PZFX raw Column and Grouped-replicate tables as EasyGraph sheets, with selection and preview.
- Manual group ordering, including a drag-and-drop order dialog.
- Configure automatic recovery, language, and theme from the expandable
  `Settings > Preferences…` dialog. The existing Language and Theme menus remain
  available as shortcuts.

## Important Data Model

Each sheet has a fixed data mode:

- `Groups`: user columns are groups and the available charts are Box, Bar, Violin,
  and Ridge. The visible table also keeps a trailing physical spare column for
  editing capacity.
- `XY`: shared-X tables and independent XY pairs are combined into one XY chart.

Percentage cells retain their original text when copied or saved. Plotting,
statistics, and curve fitting use fractional values: `25%` and `0.25` represent
the same number. A visible percentage value enables percentage tick labels on
its numeric axis (X and Y independently for XY charts). Ordinary numbers keep
their values, so enter `0.25` rather than `25` when mixing decimals with
percentages. Manual axis limits and tick intervals also use fractional values.
Chart value labels and embedded statistics follow the axis percentage format;
sample counts remain integers.

Use `File > New`, the `+` sheet button, or `Sheet > New` to choose Groups or XY. An XY workspace has two vertically split, fully collapsible group boxes:

- **Shared X**: tabs occupy the first row. Each tab is a table whose first column is `X` and whose remaining columns are `1Y`, `2Y`, and so on. The `+` button adds another shared-X dataset with its own X column.
- **Independent XY**: columns are fixed pairs: `1X/1Y`, `2X/2Y`, and so on.

A new XY sheet starts with ten editable rows, a shared-X tab containing `X`,
`1Y`, and `2Y`, and two independent pairs (`1X/1Y` and `2X/2Y`). Each
table keeps at least one blank row after its last populated row. Entering data
in the final displayed row, Y column, or XY pair automatically appends another
blank destination. Automatic capacity is append-only so undo can restore
distant cells reliably; rows shrink only through an explicit whole-row delete.
All data tables use the same Excel-style context menu described below.
Whole-column operations treat a shared-X `Y` as one logical column and an
independent `X/Y` pair as one logical unit; the shared `X` column cannot be
deleted. Double-click a name cell in the bold first row to rename it with the
multiline editor; the fixed mapping header above it is not editable.

Every populated series from both group boxes is drawn automatically on the same chart. Automatically created blank Y columns and XY pairs are editing placeholders and are omitted from series filter, color, and order dialogs. XY sheets hide the Groups descriptive-statistics pane.

Changing a column name does not break a mapping because mappings reference stable physical-column IDs. For every series, X and Y values are validated as a pair on the same source row. A blank or nonnumeric value on either side skips that entire pair; EasyGraph never drops X and Y independently and then joins shifted values. Connecting lines preserve the original table row order and do not silently sort by X.

`Series Filter` hides whole series without deleting source data. `Colors` and `Order` continue to operate on the combined series list from every shared tab and independent pair. Hidden series are excluded from the legend and automatic axis range. XY sheets currently keep every visible series on one shared X/Y coordinate system and do not include point-level filters, error bars, or a secondary Y axis.

Click **Curve Fit...** to fit one or several XY series independently. Built-in
models cover linear, quadratic through quintic polynomial, exponential,
logarithmic, power, and Gaussian curves. The fitting dialog presents them in a
single selectable list with a short description of when to use each model.

**Custom equation** accepts expressions such as `a * exp(-k * x) + c`; `x` is
the independent variable and other names become editable parameters
automatically. Available functions include `exp`, `ln`, `log(value, base)`,
`log10`, `sqrt`, and `abs`; `sin`, `cos`, `tan`, `sec`, `csc`, and `cot`;
inverse functions `asin`, `acos`, `atan`, and `atan2(vertical, horizontal)`;
and `sinh`, `cosh`, and `tanh`. `ln(value)` uses base *e*, while
`log10(value)` uses base 10. `log(value, base)` accepts any positive base other
than 1; the value must also
be positive. Trigonometric inputs and inverse-trigonometric results use radians.
The custom editor can insert these functions and also provides buttons for two
bounded mathematical operators:

- `Σ(k, 1, 5, expression)` (or `sum_over(...)`) adds the expression for every
  integer `k` from 1 through 5, including both limits, with at most 256 terms.
- `integral(t, 0, x, expression)` evaluates a separate definite integral for
  each X value using fixed Gauss–Legendre numerical quadrature. An optional
  final integer selects 8–128 quadrature points; the default is 32. This makes
  the result independent of the source-row order and of the number of points
  used to draw the fitted curve.

The bound names `k` and `t` are local to their respective expression and are
not fitted parameters. Reducers cannot be nested, and their ranges and work are
limited. The expression parser allows only documented numeric operators and
functions and never executes Python code. Starting values are generated
automatically, while an advanced parameter table exposes initial values,
bounds, and fixed parameters when a nonlinear fit needs guidance. Successful
fits report coefficients, standard errors, confidence intervals, SSE, RMSE,
R², and adjusted R². The results table keeps all fitted parameters visible for
comparison. Its **Display** switch independently controls the chart annotation
for each fit, while the shared annotation selector chooses either a typeset
equation or selected fitted parameter values. **Parameter Display Settings…**
chooses the values shown for each result without rerunning the fit. Full
precision remains available in the results table and details. Drag an
annotation directly on the chart to place it manually; its position is saved
with the project and a double-click restores automatic placement. If
ordinary-`x` coefficients cannot be displayed reliably at the current numeric
scale, the chart omits the equation rather than showing a misleading one and
reports the reason with the fit result. Fit definitions are saved in the project; calculated curves are
cached in memory and recomputed in a background worker only when their data or
numeric model settings change. For linear and polynomial fits
through degree five, EasyGraph automatically uses a numerically stable fitting
method. Equations and reported coefficients use the familiar original `x`
values, while centering and scaling stay internal. No extra origin or scaling
settings are exposed in the normal workflow; EasyGraph chooses a stable
internal reference automatically for the current data on every refit.

### Groups table

The table is wide-format:

```text
row 1: group names
row 2+: numeric values
```

The first visible row is not a normal data row. It is the group-name row and is styled differently in the UI. When plotting, EasyGraph treats row 1 as the group labels and all rows below it as values.

A new Groups sheet starts with twelve editable sample rows and three columns.
Using the final displayed row or the automatic blank group appends another
blank destination. An empty group explicitly named by the user is preserved;
the following automatic spare receives a distinct `Group N` name.
Physical capacity (including the spare column, trailing blank rows, and stable
column IDs) is retained in project state. Plotting, chart statistics, overlays,
and Excel/CSV export use the semantic Groups data instead, omitting only the
tracked automatic spare and trailing blank sample rows. The separate Analysis
Results grid still mirrors the physical table columns, but every result cell in
the automatic spare column remains blank.

Group names support forced line breaks. Multiline group names are preserved in:

- the table
- plotted tick labels
- project files
- Excel/TSV copy and paste

Copy/paste supplies both Office-compatible HTML tables and a TSV fallback.
Selecting subgroup names together with data includes the corresponding parent
header row, with merged parent cells preserved when pasted into Excel or Word.
Selecting the parent band copies just those parent cells. Excel tables with a
merged first header row can be pasted back to restore parent groups, subgroup
names, and data in one undo step. Parent-band paste targets the selected header;
pasting a single name retains its existing merge and leaves samples unchanged.
Plain TSV has no merge metadata. When a group name contains a newline, the TSV
writer quotes the cell so Excel can keep it as one cell.

Duplicate group names are allowed. Every physical column is an independent
group for plotting, descriptive statistics, overlays, filtering, and colors,
including in projects saved by earlier versions. Column identities remain
stable when their displayed names change.

Groups tables support two-level headers with an Excel-style merge/unmerge
workflow. Column numbers remain at the top, followed by a permanent parent-header
band and the editable subgroup-name row. Ungrouped columns have blank cells in
the parent band; leaving them blank keeps a single-level plot.

Click a parent cell or drag across adjacent cells to select them. Shift-click
extends the selection, and an existing merged parent is always selected as a
complete block. Choose **Merge parent headers...** in the right-click menu or
**Table** tab and enter the parent title. Adjacent complete parent blocks can be
merged together too. **Unmerge parent headers** restores blank individual cells
for the selected parent headers. Subgroup names, column order, data, and
independent statistics are preserved. Double-click
a blank parent cell to create a title for one column, or an existing parent to
rename it. The merge command stays available with a data-cell selection and
prompts you to select adjacent parent headers instead of modifying them implicitly.

**Insert parent group left/right...** creates a new parent with one blank-data
subgroup outside the current parent's boundary. **Insert subgroup left/right**
adds a blank column immediately next to the selected subgroup and keeps its
parent, including at a boundary between parents. These are distinct operations;
all header and structural edits support undo and redo.

Clicking the table, its headers, or row/column numbers opens the contextual
**Table** tab beside **Chart**. It contains editing, row/column, and parent-header
tools; its parent-header commands share the same actions as the context menus.
Toolbar clicks and dialogs preserve the table selection. A manual switch back to
**Chart** is respected during further edits in the same table; clicking the plot
hides **Table** and returns to chart tools. XY tables expose the applicable editing
and row/column tools without the Groups parent-header band or commands.

**Create parent groups in bulk...** creates several parents with the same subgroup
names. Renaming a shared subgroup updates only its linked columns in that new
batch; existing free groups and earlier batches retain their own name links.
Every column's data and statistics remain independent. Free groups can contain
different numbers of independently named subgroups.

Click the category axis and choose **Group layout...** in the right sidebar to change
subgroup sharing, within-group and between-group spacing, parent/subgroup colors,
and whether subgroup names appear on the axis or only in the shared legend.
**Parent group spacing** is directly available in the same axis section: X Axis
for Box, Bar, and Violin; Y Axis for Ridge. Box, Bar, Violin, Ridge, points, overlays, and chart
statistics use the same grouped positions.

**Edit Group Order** uses two lists when a sheet has parent headers. The left
list orders complete parent groups together with individual ungrouped columns;
the right list orders subgroups within the selected parent. Drag selected items
or use the up/down buttons, including multiple items at once. Subgroups cannot
move into another parent here. **Table Order** restores both levels to their
physical table order. These edits affect the plot only: source data, column
identities, and parent membership remain unchanged, and the order is saved with
the project. Opening the dialog reflects the current plotted order. Name and
statistic sorting continue to sort within parents while preserving the outer
table order; use manual ordering to rearrange complete parents or ungrouped
columns. Sheets without parent headers and XY sheets retain the single list.

Choose **Bar** in the chart-type selector to show columns with the existing
scatter points. Click the plot area to set bar width and the summary/error type
in the right sidebar. Available choices are **Mean**, **Mean with SD** (default),
**Mean with SEM**, **Mean with 95% CI**, **Mean with range**, **Median**,
**Median with 95% CI**, **Median with range**, and **No line or error bar**.
The last option hides summary bars and error bars while retaining the point
visibility/style settings. Geometric summaries are not offered.

SD uses the sample standard deviation; SEM is SD divided by the square root of
the number of valid values. Mean 95% CI uses Student's t distribution with n−1
degrees of freedom. These errors require at least two valid values per column.
Median 95% CI uses observed order statistics and binomial tails with coverage
of at least 95%; the discrete interval may be asymmetric. Fewer than six valid
values cannot yield finite observed bounds with 95% coverage, so only the
median bar is drawn. Range means minimum to maximum, independently of Box
whisker settings. Tooltips explain these choices in the sidebar.

Empty columns have no bar, while grouped layouts retain their empty slot.
Bars start at zero; automatic value-axis limits include zero and visible
observations/error bars. With no negative plotted values (including error bars),
the automatic lower limit is exactly zero. Existing point styling, outlier handling, overlays,
and statistics remain available. Open `demo/grouped_bars.eg` to try shared and
free groups with mean ± SD bars and scatter points.

The `.eg` project format preserves grouping and stable identities. Excel
workbooks export real two-row headers with merged parent titles and restore
them on import. Prism Grouped imports retain their two grouping factors.
CSV preserves independent columns but does not carry the parent hierarchy.
Open `demo/grouped_headers.eg` to try both shared and free subgroup layouts.

**Break between parent groups** in the Line Overlay inspector draws separate
overlay segments within each parent group, preserving points and value labels.
Single-subgroup parents and ungrouped columns keep individual points. This
option applies to statistic and custom overlays, including secondary axes,
and is available only when the Groups sheet has parent headers. It defaults
to off and is saved with projects and style templates; sheets without parent
headers continue to use continuous overlays.

**Use secondary axis** is also available directly in the Line Overlay inspector,
so selecting a custom overlay lets you enable its secondary axis before that
axis exists. Select the secondary axis to adjust its range, ticks, or split view.

**Statistic Number Formats…** in the overlay or in-chart statistics inspector
sets decimal places (0–12), decimal/scientific notation, and trailing-zero
trimming separately for Mean, Median, Q1, Q3, Max, Min, SD, SEM, and Sum. Enable
**Override** for each statistic to customize it; unchecked statistics follow
the existing shared Decimals and Scientific controls. These formats apply to
both statistic labels and the in-chart table, including figure exports.
Custom overlay labels continue to use the shared controls.

Ridge charts place the statistics table to the right, with one row per group
aligned to its Y-axis tick and one column per statistic. Group spacing and
ordering are shared with the plot; row heights fit their text, leaving gaps
between rows when the plot is taller. The outside legend appears below the plot;
the **Inside plot** option remains available.

The **Number Formats…** button beside Analysis Results (also available in its
right-click menu) configures the independent analysis table and its copied
values. Its default remains two decimal places. Sample counts remain integers,
and formatting never rounds the source data or calculations. Settings are
saved separately for each sheet and restored with projects and recovery;
chart formats are also included in style templates.

Analysis Results mirrors the source table's merged parent headers above the
subgroup names, including renames, merges, undo/redo, and sheet changes. Column
widths and horizontal scrolling stay aligned. Copying the statistics table or
selected statistics with headers retains both header levels and their merges
in Office-compatible clipboard HTML.

**Sum** totals the valid numeric values in each column or plotted group. It is
available in the Analysis Results statistics filter and the in-chart statistics
list; empty columns remain blank. Analysis Results include Sum by default for
new sheets, while the in-chart table displays it when selected.

### Spreadsheet import and export

Excel/CSV import lets each worksheet become either a Groups or XY sheet. Imported XY worksheets initially use the first column as shared X and the remaining columns as Y series. Pasting additional columns into a shared-X table automatically adds Y columns; pasting into the independent-XY area automatically adds complete XY pairs. Both areas retain an extra blank destination after the paste.

Excel and CSV export contain the flattened source columns from all shared tabs followed by the independent XY pairs. Internal column IDs, table layout, series filters, custom colors, and per-series display settings are intentionally not embedded in ordinary spreadsheets. Save an `.eg` project when those settings must round-trip.

An EasyGraph project is a workbook. Every sheet owns its own wide table,
overlays, `ChartSettings`, selection position, and undo/redo history. Switching
sheets changes the data table, plot preview, and inspector together. Sheet tabs
can be reordered by dragging; double-clicking a tab renames it.

## Project File Format

Project files use the `.eg` suffix. The file is a zip archive, not a custom binary format.

```text
example.eg
├── project.json
├── sheets.json
└── sheets/
    ├── <sheet-id-1>/
    │   ├── data.csv
    │   └── settings.json
    └── <sheet-id-2>/
        ├── data.csv
        └── settings.json
```

- `project.json`: metadata, currently `{ "version": 5, "app": "EasyGraph" }`.
- `sheets.json`: stable sheet IDs, display names, `groups`/`xy` modes, order, and the active sheet.
- Each sheet directory contains its wide table plus a settings envelope with
  `ChartSettings`, XY series mappings, stable physical-column IDs, and Groups
  parent/subgroup metadata.

Versions 1–4 remain readable. Version 1 single-sheet and version 2 multi-sheet
`.eg` projects are migrated to Groups sheets when opened. Older `.gplite` files can still be opened through
`All Files (*)` in the open dialog.

Normal project saves are atomic: EasyGraph finishes and syncs a temporary archive
beside the destination before replacing the previous `.eg` file. A failed or
interrupted write therefore does not overwrite the last valid project.

## Crash Recovery and Application Preferences

Crash recovery is enabled by the normal `src/app.py` entrypoint and stores its
temporary sessions in the platform-specific local application-data directory.
It does not modify the user's saved project until the user explicitly saves.
After an abnormal exit, the next launch offers to recover, discard, or postpone
each usable recovery session. Cleanly closed and incomplete sessions are not
offered.

Recovery uses two complementary formats:

```text
new/open/import workbook
        ↓
background full .eg recovery checkpoint
        ↓
later small edits appended to changes-<document-id>.jsonl
        ↓
idle or structural checkpoint compacts the journal
```

- Large DataFrame imports are written once as a complete background `.eg`
  checkpoint. They are not expanded into millions of cell operations.
- Individual cell edits and small row/column operations are appended as compact
  JSONL records and flushed with `fsync`.
- The configurable recovery interval controls how often pending JSONL changes
  are flushed. It does **not** create a new `.eg` file on every interval.
- The default interval is 2 seconds and can be set from 1 to 60 seconds under
  `Settings > Preferences… > Recovery`.
- After roughly 30 seconds without another relevant change, or when a structural
  change/log-size limit requires it, EasyGraph builds a new background checkpoint
  and compacts the journal.
- Checkpoint and journal writes use separate background worker threads rather
  than a child process. This avoids serializing or copying a large DataFrame just
  to hand it to another process, while journal writes can continue during a slow
  checkpoint.

The Preferences dialog is category-based so future application settings can add
pages without flattening everything into one form. Its General page currently
contains Language and Theme; language changes take effect after restart, while
theme changes apply immediately. The existing top-level Language and Theme menus
are intentionally retained.

## Main Files

```text
src/app.py
src/easygraph/data.py
src/easygraph/overlay_series.py
src/easygraph/app_preferences.py
src/easygraph/packaging_smoke.py
src/easygraph/palette.py
src/easygraph/plotting/__init__.py
src/easygraph/plotting/canvas.py
src/easygraph/plotting/chart_renderers.py
src/easygraph/plotting/layout.py
src/easygraph/plotting/overlay_renderer.py
src/easygraph/plotting/xy_renderer.py
src/easygraph/plotting/xy_fit_renderer.py
src/easygraph/project_io.py
src/easygraph/recovery.py
src/easygraph/prism_io/__init__.py
src/easygraph/prism_io/models.py
src/easygraph/prism_io/pzfx.py
src/easygraph/prism_io/mapping.py
src/easygraph/settings.py
src/easygraph/spreadsheet_io.py
src/easygraph/data_table.py
src/easygraph/table_model.py
src/easygraph/xy_data.py
src/easygraph/xy_series.py
src/easygraph/xy_fitting.py
src/easygraph/xy_fit_worker.py
src/easygraph/template_io.py
src/easygraph/ui/dialogs.py
src/easygraph/ui/line_style_delegate.py
src/easygraph/ui/main_window.py
src/easygraph/ui/preferences_dialog.py
src/easygraph/ui/prism_import_dialog.py
src/easygraph/ui/startup_dialog.py
src/easygraph/ui/xy_series_dialog.py
src/easygraph/ui/xy_curve_fit_dialog.py
scripts/audit_app_facade.py
scripts/inspect_prism_samples.py
scripts/build_and_smoke_windows.ps1
src/ui_main_window.py
src/ui_group_order_dialog.py
src/ui_prism_import_dialog.py
src/ui_startup_dialog.py
src/ui_xy_curve_fit_dialog.py
ui/main_window.ui
ui/group_order_dialog.ui
ui/prism_import_dialog.ui
ui/startup_dialog.ui
ui/xy_curve_fit_dialog.ui
tests/test_core.py
tests/test_dialogs.py
tests/test_line_style_delegate.py
tests/test_app_facade_audit.py
tests/test_architecture.py
tests/easygraph_case.py
tests/test_app_preferences.py
tests/test_data.py
tests/test_data_module.py
tests/test_overlay_series_module.py
tests/test_packaging_smoke.py
tests/test_palette.py
tests/test_palette_module.py
tests/test_plotting.py
tests/test_project_io.py
tests/test_recovery.py
tests/test_prism_pzfx.py
tests/test_prism_mapping.py
tests/test_prism_import_dialog.py
tests/test_spreadsheet_io.py
tests/test_settings_module.py
tests/test_template_io.py
requirements.txt
```

- `src/easygraph/data.py`: owner of the wide-to-long conversion, duplicate-group aggregation, group ordering, outlier detection, sample/blank data creation, box-whisker values, and chart-axis label semantics.
- `src/easygraph/overlay_series.py`: owner of overlay series construction, visibility, statistics-table data, color allocation, and line-style policy. It uses QtGui `QColor` without importing Qt Widgets or the plotting stack.
- `src/easygraph/packaging_smoke.py`: frozen-build smoke owner for lazy plotting/fitting imports, Box/Violin/Ridge/large-Quasirandom/XY-fit rendering, and PNG/SVG/PDF export artifacts.
- `src/easygraph/palette.py`: owner of palette expansion, `QColor`-based color derivation and contrast calculations, and precomputed palette-cache loading. It uses QtGui `QColor` without importing Qt Widgets, Matplotlib, Seaborn, or SciPy.
- `src/easygraph/plotting/canvas.py`: owner of the Qt/Matplotlib plot canvas lifecycle, render orchestration, zooming, cached-background blitting for transient feedback and inside-legend dragging, figure export/clipboard image, renderer-aware text measurement, actual legend/table drawing, artist placement, overlay rendering, and overlay axis/collision integration.
- `src/easygraph/plotting/chart_renderers.py`: owner of chart-specific drawing helpers for box, violin, ridge, point scatter, and jitter placement. Seaborn and SciPy are imported only by the renderer/algorithm path that needs them; the module avoids Qt, `app.py`, `canvas.py`, generated UI, and persistence imports.
- `src/easygraph/plotting/layout.py`: owner of pure plotting layout calculations, including legend sizing/wrapping heuristics, statistics-table dimensions, overlay axis label margins, secondary-axis activation flags, and plot margin estimates. It avoids Qt, Matplotlib, pandas, Seaborn, SciPy, `app.py`, `canvas.py`, and generated UI imports.
- `src/easygraph/plotting/overlay_renderer.py`: owner of overlay label box/arrow/offset helpers, overlay label-position normalization, line-style mappings, and Qt line-style preview icons. It is intentionally lightweight: it imports QtCore/QtGui plus settings only, not `app.py`, `canvas.py`, Matplotlib, pandas, Seaborn, SciPy, or generated UI modules.
- `src/easygraph/xy_fitting.py`: Qt-free owner of the safe custom-expression parser, built-in model registry, initial-value estimation, bounded/fixed-parameter least-squares fitting, and fit statistics. SciPy is imported only when a nonlinear fit actually runs.
- `src/easygraph/xy_fit_worker.py`: owner of background batch jobs that keep nonlinear fitting off the UI and plot-rendering threads.
- `src/easygraph/project_io.py`: owner of version 4 multi-sheet `.eg` ZIP persistence, older-project migration, and strict `ChartSettings`/XY settings decoding.
- `src/easygraph/recovery.py`: owner of recovery-session discovery, background
  `.eg` checkpoint workers, fsynced JSONL journals, journal replay/compaction,
  and clean-session disposal.
- `src/easygraph/app_preferences.py`: owner of normalized and persisted
  application-level theme, language, recent-project, and recovery-interval
  preferences.
- `src/easygraph/workbook.py`: Qt-free owner of sheet/workbook documents, stable sheet identities, cloning, ordering, and Excel-compatible sheet-name rules.
- `src/easygraph/workbook_session.py`: owner of per-sheet transient selection, scroll, and undo/redo state.
- `src/easygraph/prism_io/`: Qt-free owner of Prism import contracts, safe PZFX 5.00 XML inspection, table classification, and Column/Grouped-to-wide-table mapping. Its package `__init__.py` is the stable public API; container-specific readers must stay separate from DataFrame mapping.
- `src/easygraph/settings.py`: owner of `ChartSettings`, visual presets, and settings-related constants.
- `src/easygraph/spreadsheet_io.py`: owner of overlay-row DataFrames and actual CSV/Excel access, including ordered multi-worksheet import/export and safe worksheet-name normalization.
- `src/easygraph/data_table.py`: the promoted `QTableView` used by the generated UI. It configures selection and headers around `EasyGraphTableModel` without exposing the old `QTableWidgetItem` compatibility API.
- `src/easygraph/table_model.py`: owner of table cells, headers, row roles, revisions, structural mutations, and bulk DataFrame/overlay conversion through `QAbstractTableModel`.
- `src/easygraph/template_io.py`: owner of style-template JSON, the default `src/template` path, filename/list/import helpers, and indexed group colors. It may import QtGui `QColor`, but not Qt Widgets or the plotting stack.
- `src/easygraph/table_actions.py`: owner of low-level sample-row and group-column structure mutations.
- `src/easygraph/table_clipboard.py`: owner of selection-to-TSV conversion, TSV parsing/paste, and selected-cell clearing.
- `src/easygraph/table_data.py`: owner of Qt table reads/writes, group names and order state, overlay-row conversion, and row/column header labels.
- `src/easygraph/table_editor.py`: owner of pure keyboard-navigation decisions for inline table editors.
- `src/easygraph/table_history.py`: owner of incremental cell/block/settings commands, structural snapshot commands, and bounded undo/redo stacks.
- `src/easygraph/table_refresh.py`: owner of coordinated table headers, row styles, and header sizing refresh.
- `src/easygraph/table_snapshot.py`: owner of table/settings snapshot construction and interpretation.
- `src/easygraph/overlay_table_actions.py`: owner of add, remove, and rename state transitions for custom overlay rows.
- `src/easygraph/ui/table_controller.py`: Qt-aware owner of table workflow coordination, including snapshots, history, navigation, clipboard mutations, DataFrame conversion, and basic row/column actions. It receives current settings through a getter and communicates with the window through typed hooks without importing `app.py`.
- `src/easygraph/ui/dialogs.py`: Qt-aware owner of checklist, group-order, group-color, overlay-filter, and overlay-style dialog workflows. It exchanges typed values with `MainWindow` without importing the application, plotting stack, or persistence modules.
- `src/easygraph/ui/line_style_delegate.py`: Qt-aware owner of the line-style combo item delegate. It renders previews through the lightweight overlay-renderer boundary without importing `app.py`, `MainWindow`, canvas, persistence, generated UI, or the scientific plotting stack.
- `src/easygraph/ui/prism_import_dialog.py`: Qt-aware owner of Prism table selection, compatibility warnings, finite data preview, and import confirmation. It consumes only the public `easygraph.prism_io` API.
- `src/easygraph/ui/spreadsheet_import_dialog.py`: Qt-aware owner of multi-worksheet selection and data preview before Excel import.
- `src/easygraph/ui/main_window.py`: sole owner of `MainWindow`, `RenderMode`, window-specific control constants, generated-UI binding, deferred preview initialization, and top-level window orchestration. Importing it does not load Matplotlib, Seaborn, SciPy, or PlotCanvas.
- `src/easygraph/ui/preferences_dialog.py`: category-based application Preferences
  dialog for General and Recovery settings, designed to accept additional pages.
- `scripts/audit_app_facade.py`: deterministic, read-only AST inventory of the real `MainWindow` dependencies, startup-only names, unused entrypoint imports, prohibited historical test facade consumers, and the single allowed `app.MainWindow` identity assertion.
- `scripts/build_and_smoke_windows.ps1`: builds the Windows onedir executable and runs the frozen lazy-import/render/export smoke mode, requiring a machine-readable passing report.
- `scripts/inspect_prism_samples.py`: deterministic, read-only JSON inventory of local ignored PZFX samples, including hashes, writer versions, table classifications, and compatibility warnings.
- `src/app.py`: minimal executable entrypoint. It owns `main()`, application theme/translator startup, and the intentional identity alias `app.MainWindow is easygraph.ui.main_window.MainWindow`; it no longer reexports implementation helpers or Qt/plotting/persistence dependencies.
- `ui/main_window.ui`: main UI source of truth.
- `ui/group_order_dialog.ui`: manual group-order dialog source of truth.
- `ui/prism_import_dialog.ui`: Prism table-selection and data-preview dialog source of truth.
- `ui/startup_dialog.ui`: first-Sheet type, Demo/blank, and recent-project startup dialog source of truth.
- `src/ui_main_window.py`: generated from `ui/main_window.ui`.
- `src/ui_group_order_dialog.py`: generated from `ui/group_order_dialog.ui`.
- `src/ui_prism_import_dialog.py`: generated from `ui/prism_import_dialog.ui`.
- `src/ui_startup_dialog.py`: generated from `ui/startup_dialog.ui`.
- `tests/easygraph_case.py`: shared test fixtures, including the `QApplication`-free base case and the Qt-aware integration base case.
- `tests/test_app_preferences.py`: recent-project preferences and menu behavior tests.
- `tests/test_data.py`: non-UI, `QApplication`-free data-shaping and validation tests.
- `tests/test_data_module.py`: data-module ownership and GUI/plotting-free import tests.
- `tests/test_overlay_series_module.py`: overlay-module ownership, behavior checks, and direct-import boundary checks under normal and optimized Python.
- `tests/test_packaging_smoke.py`: source smoke and Windows hidden-import parity tests for every dynamically loaded renderer/export backend.
- `tests/test_palette.py`: non-UI, `QApplication`-free palette and overlay-policy tests.
- `tests/test_palette_module.py`: palette-module ownership, cache-path, and import-boundary tests.
- `tests/test_plotting.py`: plotting-module contract tests.
- `tests/test_project_io.py`: `QApplication`-free project-format and persistence tests.
- `tests/test_recovery.py`: recovery checkpoint/journal concurrency, replay,
  large-import, session-discovery, and recovered-window integration tests.
- `tests/test_spreadsheet_io.py`: spreadsheet-module and spreadsheet UI integration tests.
- `tests/test_settings_module.py`: settings-module ownership and GUI/plotting-free import tests.
- `tests/test_template_io.py`: template-module ownership and style-template persistence tests.
- `tests/test_core.py`: remaining Qt and plot integration tests, including table behavior, rendering, and UI settings.
- `tests/test_dialogs.py`: focused Qt tests for generated group/overlay dialog shells, accepted/cancelled results, live color/style previews, reset behavior, and selection-copy semantics.
- `tests/test_line_style_delegate.py`: focused Qt construction, paint-boundary,
  size-floor, direct-owner, and import-boundary tests for the line-style
  delegate.
- `tests/test_app_facade_audit.py`: miniature-repository AST classification, deterministic CLI output, and read-only audit tests.
- `tests/test_architecture.py`: architecture checks that keep direct-owner tests, the delegate owner, generated main-window UI, and application boundaries explicit.

## Prism PZFX Import

Status: **implemented** for raw Column and Grouped-replicate tables in Prism
8–11 PZFX 5.00 files. Prism 8/9/10/11 are backed by local Column/Grouped
samples, including a Prism 8 Column document resaved by Prism 9. Native
`.prism` archives remain a later milestone.

The architecture, compatibility assumptions, and acceptance history are in
[`docs/plans/2026-07-16-prism-raw-data-import.md`](docs/plans/2026-07-16-prism-raw-data-import.md).
Local sample provenance, hashes, and validation purpose are recorded in
[`demo/prism_samples/SOURCES.md`](demo/prism_samples/SOURCES.md). The actual
sample data files are ignored and must not be committed unless redistribution
permission is explicitly established.

Ownership layout:

```text
src/easygraph/prism_io/
├── __init__.py              # stable public API
├── models.py                # dataclasses, table kinds, warning/error codes
├── pzfx.py                  # safe PZFX 5.00 XML parsing and classification
└── mapping.py               # Column/Grouped data to wide DataFrame

src/easygraph/ui/prism_import_dialog.py  # table selection and preview workflow
ui/prism_import_dialog.ui                # dialog source of truth
src/ui_prism_import_dialog.py            # generated; do not hand-edit

tests/prism_fixtures.py
tests/test_prism_pzfx.py
tests/test_prism_mapping.py
tests/test_prism_import_dialog.py
scripts/inspect_prism_samples.py
```

Dependency direction is one-way:

```text
main_window
  -> ui.prism_import_dialog
    -> easygraph.prism_io public API
      -> pzfx / mapping / models
```

`easygraph.prism_io` must remain independent of Qt, plotting, generated UI,
project persistence, and `main_window`. `spreadsheet_io.py` remains the CSV/Excel
owner and must not acquire Prism branches. A future native `.prism` reader
belongs in `easygraph/prism_io/archive.py` alongside `pzfx.py`, reusing
`models.py` and `mapping.py`.

Handoff rules for this feature:

- Read `Created/MostRecentVersion@CreatedByVersion` as the authoritative Prism
  application version. Fall back to `OriginalVersion` only when the recent
  version is absent or empty; converted documents can contain an empty
  `OriginalVersion`.
- Dispatch by `ExtTableType`, then `TableType`, then `YFormat`; do not create
  separate Prism-major-version parsers.
- Reject unknown or pre-averaged structures with a reason instead of flattening
  them heuristically.
- Keep real local samples out of CI; use anonymous minimal fixtures for committed
  tests and the inspection script for local regression checks.
- When support expands, update this section, the main file inventory, the plan's
  support matrix, and the sample provenance ledger together.

The importer deliberately rejects XY, Multiple Variables, Nested, HugeTable,
and pre-averaged error formats instead of flattening them heuristically. Empty
PZFX data remain empty cells; `Excluded="true"`/`"1"` values become empty cells
and are counted in the preview. Grouped row and column factors are combined as
`Y title · row title`. Parsing accepts files with or without a default XML
namespace, rejects non-UTF-8/DOCTYPE/ENTITY input, and enforces resource limits.
The selection dialog checks all supported tables by default, also allows an
explicit subset, and keeps unsupported tables visible with an explanation. Each
selected Prism Data Table becomes one EasyGraph Sheet in Prism `TableSequence`
order. All selected tables are mapped successfully before the current workbook
is replaced.

## Platform UI Font Policy

`easygraph.app_theme.configure_qt_application_font()` keeps the native Windows
application font size and DPI behavior. It prefers the Windows system family
when that family is installed, otherwise falls back to `Segoe UI`, with
`Microsoft YaHei UI`/`Microsoft YaHei` retained as Chinese fallbacks. Do not
replace the Windows font with `QFont(family)` alone: that constructor resets the
resolved native 9pt application font to Qt's 12pt default on common Windows
setups.

Theme application installs the stylesheet first and reapplies the cached native
Windows font afterward. This keeps menu bars and ordinary widgets at the same
size on first launch and across Light/Dark switches. Non-Windows font behavior
is intentionally unchanged, and Windows accessibility/DPI settings remain the
source of truth rather than using a hard-coded global scale factor.

The Light theme changes ordinary gray widget, table-selection, combo-popup,
table-header, and preview-placeholder text to solid black. Blue semantic text
remains blue: enabled push buttons and the selected tab use the same `#0081DB`
accent as checked controls. Disabled controls retain their
disabled styling so their state remains recognizable.

Windows icon assets live under `icon/windows/` and are generated from the
light/dark 1024 px masters with `python scripts/generate_windows_icons.py`. The
generator crops each source to its alpha bounds before creating the runtime PNG
set and multi-resolution ICO. Keep the 100 px inset in the macOS assets; Windows
must use its dedicated cropped set so taskbar icons do not regress to the
smaller-looking macOS geometry.

## UI Workflow

The fixed main-window structure is defined in `ui/main_window.ui`. Removed Python
widget-builder methods were unreachable legacy code, not an alternate UI source.
Live programmatic widgets and dialogs have not all moved to `.ui` files; that is
reserved for a later phase.

Regenerate generated Python after editing the main window:

```bash
./.venv/bin/pyside6-uic ui/main_window.ui -o src/ui_main_window.py
```

Regenerate generated Python after editing the group-order dialog:

```bash
./.venv/bin/pyside6-uic ui/group_order_dialog.ui -o src/ui_group_order_dialog.py
```

Regenerate generated Python after editing the Prism import dialog:

```bash
./.venv/bin/pyside6-uic ui/prism_import_dialog.ui -o src/ui_prism_import_dialog.py
```

Regenerate generated Python after editing the startup dialog:

```bash
./.venv/bin/pyside6-uic ui/startup_dialog.ui -o src/ui_startup_dialog.py
```

Do not hand-edit generated `src/ui_*.py` files unless there is a temporary debugging reason. Regenerate them from `.ui` instead.

## Translation Workflow

EasyGraph uses Qt's native translation toolchain. Static UI text comes from
`ui/*.ui`, generated `src/ui_*.py` files use `QCoreApplication.translate(...)`,
and runtime window text in `src/easygraph/ui/main_window.py` should use
`self.tr(...)`.

Simplified Chinese is available from the app's `Language` menu. Changing the
language preference is saved with `QSettings` and takes effect after restarting
EasyGraph. The `EASYGRAPH_LANGUAGE` environment variable can override the saved
preference for testing, for example:

```bash
EASYGRAPH_LANGUAGE=zh_CN python src/app.py
```

When UI text changes, update the translation source file:

```bash
./scripts/update_translations.sh
```

Then open `translations/easygraph_zh_CN.ts` in Qt Linguist, review any
unfinished entries, and compile the runtime translation file:

```bash
./scripts/compile_translations.sh
```

Keep chart option values such as `Box`, `Median`, and `Table order` in English.
They are project/template settings values, not ordinary UI labels.

## Plotting Stack

- Matplotlib owns the figure, canvas, export, clipboard image, and detailed rendering.
- Seaborn is used as a styling and categorical-plot helper for box/violin behavior.
- SciPy `gaussian_kde` is used for ridge distributions.
- Pandas is still used internally for table-to-plot transformations and Excel/CSV I/O.

Plot style is controlled from the right-side settings panel. For XY charts,
single-click a plotted line or point to edit that series. Ctrl/Cmd-click adds
or removes a series from the current selection. Double-click selects that
series and brings its Series Style controls into view. The Series Style panel
mirrors the selection in an ordered checklist: individual checks add or remove
series, Shift-click checks or clears the continuous range from the last clicked
item, and `All series` returns to the global all-series style in one click.
Mixed values remain unchanged until their individual control is edited, and
the selected series can be reset to follow the all-series style again.

For dense plots, enable `Box Select (B)` above the preview and drag across the
visible line or marker geometry. A normal box replaces the current subset,
Ctrl/Cmd-box adds to it, and Alt/Option-box removes from it. Merely overlapping
an artist's outer bounding rectangle does not select that series.

## Palettes and Style Templates

The top-toolbar `Palette` remains a shared built-in palette selector for every
chart type. Its value is stored per sheet, so each sheet restores its own
palette when activated.

Saved Style Templates are split into two compatible chart families:

- Groups templates are shared by Box, Bar, Violin, and Ridge charts.
- XY templates are shared by Scatter and Line charts.

Activating a sheet filters the template menu to that family and resets the
menu to `None`; it does not reapply a template or overwrite later manual edits.
Saving automatically updates the active family's variant. The same template
name may contain both variants in one file: common canvas, typography, legend,
axis, and background settings are shared, while each family keeps its own
specialized settings. Legacy JSON with `xy_style` is treated as XY; legacy JSON
without it is treated as Groups.

## Canvas Behavior

The plot preview uses a fixed physical size in centimeters from settings:

- Width and height are stored in cm.
- Preview has scrollbars if the canvas is larger than the center viewport.
- Ctrl+wheel zoom is supported.
- Trackpad/native pinch zoom is handled where Qt exposes native/pinch gestures.

The rendered figure can have a transparent background. Clipboard copy and export respect the transparent background setting.

## Table Behavior

- The first table row is the group-name row.
- The top horizontal row shows numeric column indices for resizing/orientation.
  Groups tables keep a selectable parent-header band below it, including blank
  parent cells for columns that have not been grouped.
- Columns are user-resizable.
- Right-click selected cells for `Insert > Shift Cells Down / Entire Row`,
  `Delete > Shift Cells Up / Entire Row / Entire Column`, or `Clear Contents`.
  Groups adds left/right subgroup insertion to the Insert submenu; XY offers
  Entire Column insertion. Cell shifts to the right or left are intentionally omitted.
- Right-click a row or column header for the applicable insert and delete
  commands. Groups columns offer explicit left/right subgroup insertion.
  A multi-row or multi-column selection is preserved when it is right-clicked.
  Right-click a parent header for merge/unmerge, rename, and left/right parent
  insertion; ordinary cells expose these through the **Parent headers** submenu.
- The group-name row and Groups overlay rows cannot be shifted, inserted, or
  deleted as ordinary rows; whole-column operations still include their
  metadata. Double-click a group header to rename it.
- In XY independent tables, structural shifts and whole-column operations
  expand either selected half to its complete `X/Y` pair. `Clear Contents`
  affects only the cells actually selected. In shared-X tables, selecting `X`
  for column insertion adds a `Y` immediately after it, while `X` cannot be
  deleted.
- The contextual **Table** tab offers editing, insertion/deletion of rows and
  columns, and Groups parent-header operations. Pasting beyond the current table
  also expands it as needed.
- Groups starts with twelve sample rows and three columns; XY starts with ten
  sample rows, two shared Y columns, and two independent XY pairs. Editing the
  final blank destination appends capacity. Automatic rows and columns are not
  trimmed behind the user's cursor or by `Clear Contents`/cell shifts; use an
  explicit whole-row or whole-column delete to shrink the table.
- Copy/paste works with Excel-style TSV.
- Pasting can expand row/column count.
- Delete clears selected cells.
- Editing row 1 updates group names, manual group order, row height, and plot rendering.

Important implementation details:

- `MainWindow.table_dataframe()` converts the full visible physical table,
  including editing capacity, to a pandas DataFrame.
- `MainWindow._user_group_dataframe()` provides semantic Groups data for
  plotting, analysis, overlays, and spreadsheet export.
- `MainWindow.set_table_dataframe()` loads a DataFrame into the visible table with group names in row 1.
- `easygraph.data.prepare_plot_data()` converts wide data to long plot data.
- `easygraph.data.values_for_group()` combines duplicate group-name columns safely.
- `easygraph.data.ordered_group_columns()` handles table order, manual order, name sorting, and statistic sorting.

Consumers import these helpers directly from `easygraph.data`; `src/app.py`
does not reexport them.

## Settings Highlights

`ChartSettings` in `src/easygraph/settings.py` is the project-serializable
settings object. Consumers import it and settings constants directly from that
module. Important fields include:

- `chart_type`: Box, Bar, Violin, Ridge.
- `preset`: visual preset key.
- `group_order`: Table order, Manual, Name A-Z, Name Z-A, Mean ascending/descending, Median ascending/descending.
- `manual_group_order`: saved manual order list.
- title/group label/value label text, including multiline text.
- canvas width/height in cm, DPI, transparent background.
- title/axis/tick font sizes.
- grid, axis range, axis line width, tick rotation.
- point display, point size, point alpha, jitter mode, jitter amount.
- outlier method, threshold, highlight, and effect.
- box/violin/ridge-specific width/bandwidth/overlap controls.

## Testing

Run these commands from the repository root.

Run the full concise timed suite:

```bash
./.venv/bin/python scripts/run_tests.py
```

Run a focused test by dotted name:

```bash
./.venv/bin/python scripts/run_tests.py -v tests.test_data.DataTests.test_wide_table_is_converted_to_plot_data
```

For direct `unittest` diagnostics without the concise runner:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest discover -s tests -t . -q
```

Run the focused Prism parser, mapping, and UI tests:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python -m unittest \
  tests.test_prism_pzfx \
  tests.test_prism_mapping \
  tests.test_prism_import_dialog -v
```

Audit local ignored Prism samples without modifying them:

```bash
./.venv/bin/python scripts/inspect_prism_samples.py
```

Compile-check key Python files:

```bash
./.venv/bin/python -m py_compile src/app.py src/easygraph/app_preferences.py src/easygraph/data.py src/easygraph/overlay_series.py src/easygraph/overlay_table_actions.py src/easygraph/palette.py src/easygraph/plotting/__init__.py src/easygraph/plotting/canvas.py src/easygraph/plotting/chart_renderers.py src/easygraph/plotting/layout.py src/easygraph/plotting/overlay_renderer.py src/easygraph/project_io.py src/easygraph/recovery.py src/easygraph/settings.py src/easygraph/spreadsheet_io.py src/easygraph/table_actions.py src/easygraph/table_clipboard.py src/easygraph/table_data.py src/easygraph/table_editor.py src/easygraph/table_history.py src/easygraph/table_refresh.py src/easygraph/table_snapshot.py src/easygraph/template_io.py src/easygraph/workbook.py src/easygraph/workbook_session.py src/easygraph/ui/__init__.py src/easygraph/ui/dialogs.py src/easygraph/ui/line_style_delegate.py src/easygraph/ui/main_window.py src/easygraph/ui/preferences_dialog.py src/easygraph/ui/spreadsheet_import_dialog.py src/easygraph/ui/table_controller.py src/ui_main_window.py src/ui_group_order_dialog.py tests/easygraph_case.py tests/test_app_facade_audit.py tests/test_architecture.py tests/test_app_preferences.py tests/test_data.py tests/test_data_module.py tests/test_dialogs.py tests/test_line_style_delegate.py tests/test_multisheet_ui.py tests/test_overlay_series_module.py tests/test_palette.py tests/test_palette_module.py tests/test_performance_benchmark_script.py tests/test_plotting.py tests/test_project_io.py tests/test_recovery.py tests/test_settings_module.py tests/test_spreadsheet_import_dialog.py tests/test_spreadsheet_io.py tests/test_table_controller.py tests/test_template_io.py tests/test_workbook.py tests/test_core.py tests/test_support.py tests/test_warning_policy.py tests/test_test_runner.py scripts/audit_app_facade.py scripts/benchmark_performance.py scripts/run_tests.py
```

## Performance Benchmarking

Performance benchmarks are separate from the normal test suite. List the stable
scenario names without importing the plotting stack:

```bash
./.venv/bin/python scripts/benchmark_performance.py --list
```

Run a small development check across every scenario:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/benchmark_performance.py --quick
```

Run the repeatable full baseline and save the raw measurements:

```bash
QT_QPA_PLATFORM=offscreen ./.venv/bin/python scripts/benchmark_performance.py \
  --json docs/performance/results/latest.json
```

Use repeated `--scenario` options to select individual workloads. The script
uses one warmup and five measured repetitions by default, reports medians and
minimums, and records environment/package versions in JSON. Wall-clock timing
is diagnostic and should be compared on the same machine; it is not a hard
cross-machine test threshold. See
`docs/performance/2026-07-16-performance-optimization-roadmap.md` for the staged
optimization and acceptance plan.

Audit the final `app.py` entrypoint boundary without modifying source files:

```bash
./.venv/bin/python scripts/audit_app_facade.py
```

The current expected full-suite count is **534 tests**. The non-UI test classes
use `EasyGraphTestCase` and do not initialize `QApplication`, although they still
import application modules where needed. UI tests that do not need an initial
plot can use `self.make_window()`; tests needing an initial render construct
`easygraph.ui.main_window.MainWindow` directly or use `self.make_window(initial_render=True)`.

On a macOS development machine on 2026-06-19, comparable runs of
`./.venv/bin/python scripts/run_tests.py --slow 20` around commit `d8e9b003`
observed about 211–213 seconds of `unittest` time. This is a diagnostic
observation, not a guaranteed benchmark or hard speed claim.

The Stage 7A ownership gate on 2026-07-15 ran all 377 tests in 242.052 seconds
with `OK`. This is likewise a diagnostic observation rather than a performance
guarantee.

The final Stage 7B ownership gate on 2026-07-15 ran all 380 tests in 242.859 seconds
with `OK`. The final audit reported no historical test facade consumers and no
unused entrypoint imports; its sole allowed assertion verifies the intentional
`app.MainWindow` identity alias.

## Known Test Output

The known Seaborn `vert` `PendingDeprecationWarning` is narrowly suppressed by
the test warning policy. The policy suppresses only this known warning; all other
warnings follow Python's normal warning filters.

Qt may still print font-alias or `propagateSizeHints` diagnostics. Slow-test
reporting is diagnostic. These warnings and diagnostics are textual; no
screenshot is transmitted unless an image or screenshot tool is explicitly used.

## Agent Handoff Notes

- The project folder is `/Users/xiezihong/Documents/Programming/EasyGraph`; confirm the active workspace and permissions before editing.
- Prefer `rg` for searching.
- Use `apply_patch` for manual edits.
- Fixed main-window and dialog structural changes must start in their `.ui`
  files and regenerate `src/ui_*.py`; runtime window orchestration belongs in
  `easygraph.ui.main_window`, while dialog workflows belong in
  `easygraph.ui.dialogs`.
- Avoid reverting user changes.
- This folder is a Git repository; inspect the active branch and working tree before editing.
- Prism import work must begin with the architecture and acceptance plan linked
  in `Prism PZFX Import`; do not collapse parsing, mapping, and dialog
  responsibilities into `main_window.py` or `spreadsheet_io.py`.
- If paste/refresh bugs appear, inspect table event handling, `paste_table_selection()`, and `handle_table_item_changed()` first.
- If plotting crashes after editing group names, check duplicate group-name handling in `values_for_group()` and `ordered_group_columns()`.
- If Chinese text renders as boxes, inspect `configure_matplotlib_fonts()` and available system fonts.
