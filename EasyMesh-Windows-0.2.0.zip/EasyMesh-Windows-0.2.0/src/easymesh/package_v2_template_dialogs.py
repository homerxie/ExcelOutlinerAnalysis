"""GUI authoring for closed local templates and explicitly bound instances."""
from __future__ import annotations

from copy import deepcopy
import re

from PySide6.QtCore import Qt, Signal, QSignalBlocker
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget, QPushButton,
    QScrollArea, QSplitter, QTableWidget, QTableWidgetItem,
    QTabWidget, QVBoxLayout, QWidget,
)

from .package_v2_local_templates import literal
from .package_v2_local_templates import component_id, component_instances
from .package_v2_local_tables import local_references
from .package_v2_basic_shapes import SHAPE_LABELS, new_basic_shape
from .package_v2_geometry_library import rewrite_scope_references
from .package_v2_expression_edit import ExpressionEdit, ExpressionDelegate
from .package_v2_draft_preview import DraftGeometryPreview, compile_draft_preview


def _expression(value, candidates=()):
    edit = ExpressionEdit(None, tuple(dict.fromkeys((*candidates, "mm", "um"))))
    edit.setText(str(value))
    return edit


def _length_text(edit, unit="mm"):
    text = edit.text().strip()
    if re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", text):
        text += unit
    return text


def _unique(name, names):
    result, n = name, 2
    while result in names:
        result, n = f"{name}_{n}", n + 1
    return result


def _templates_with_draft(templates, request):
    """Install the unsaved template into a private dependency registry."""
    values = deepcopy(list(templates))
    draft, original_id = request["template"], request["original_id"]
    values = [value for value in values if value["id"] != original_id]
    if any(value["id"] == draft["id"] for value in values):
        raise ValueError(f"模板名称重复：{draft['id']}")
    values.append(deepcopy(draft))
    if original_id and original_id != draft["id"]:
        for template in values:
            for child in template["instances"]:
                if child["template"] == original_id:
                    child["template"] = draft["id"]
    return values


def _install_preview(dialog, editor_page, compiler, caption):
    layout = QVBoxLayout(dialog)
    splitter = dialog.preview_splitter = QSplitter(Qt.Orientation.Horizontal)
    splitter.setChildrenCollapsible(False)
    splitter.addWidget(editor_page)
    dialog.preview_panel = DraftGeometryPreview(dialog, compiler, caption)
    dialog.preview = dialog.preview_panel.preview
    splitter.addWidget(dialog.preview_panel)
    splitter.setStretchFactor(0, 3)
    splitter.setStretchFactor(1, 2)
    splitter.setSizes([650, 450])
    layout.addWidget(splitter)


class BoundInstanceDialog(QDialog):
    submitRequested = Signal(object)

    def __init__(self, parent, editor, *, instance=None, duplicate=False, templates=None,
                 candidates=None, child=False, preview_context=None):
        super().__init__(parent)
        self.source_editor = editor
        self.opened_raw_sha256 = editor.raw_sha256
        self.child = child
        self.preview_context = preview_context
        self.original = deepcopy(instance)
        self.original_id = instance["id"] if instance and not duplicate else None
        self.registry = {t["id"]: deepcopy(t) for t in (templates or editor.document["templates"])}
        self.candidates = tuple(candidates if candidates is not None else
            (v["name"] for key in ("parameters", "derived") for v in editor.document["globals"][key]))
        self.setWindowTitle("编辑实例" if self.original_id else "复制实例" if duplicate else "创建实例")
        self.resize(1150, 650)
        editor_page = QWidget()
        root = QVBoxLayout(editor_page)
        root.setContentsMargins(0, 0, 0, 0)
        label = QLabel("为模板的公开 Local variables 赋值。可填写数值或" +
            ("父模板的 Local variable。Origin 使用父模板局部坐标。" if child else
             "Global variable。Origin 是模板原点在工程坐标系中的位置。"))
        label.setWordWrap(True)
        root.addWidget(label)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        root.addLayout(form)
        existing = {i["id"] for i in editor.document["instances"]}
        proposed = instance["id"] if self.original_id else _unique((instance["id"] + "_copy") if instance else "instance", existing)
        self.name_edit = QLineEdit(proposed)
        form.addRow("实例名称", self.name_edit)
        self.template_combo = QComboBox()
        self.template_combo.addItems(list(self.registry))
        if instance:
            self.template_combo.setCurrentText(instance["template"])
        form.addRow("使用模板", self.template_combo)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.parameter_page = QWidget()
        self.parameter_form = QFormLayout(self.parameter_page)
        self.parameter_form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        scroll.setWidget(self.parameter_page)
        root.addWidget(scroll, 1)
        self.parameter_edits = {}
        self.template_combo.currentTextChanged.connect(self._load_template)
        self._load_template(self.template_combo.currentText())
        self.origin_edits, self.rotation_combos, self.mirror_checks = [], [], []
        pose_form = QFormLayout()
        pose_form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        root.addLayout(pose_form)
        for axis, key in enumerate("XYZ"):
            row = QHBoxLayout()
            edit = _expression(instance["origin"][axis] if instance else "0mm", self.candidates)
            edit.returnPressed.connect(self._submit)
            self.origin_edits.append(edit)
            row.addWidget(edit, 1)
            combo = QComboBox()
            for angle in (0, 90, 180, 270):
                combo.addItem(f"{angle}°", angle)
            angle = instance.get("rotation", [0] * 3)[axis] if instance else 0
            matched = combo.findData(angle)
            if matched < 0:
                combo.addItem(f"{angle}°（当前）", angle)
                matched = combo.count() - 1
            combo.setCurrentIndex(matched)
            self.rotation_combos.append(combo)
            row.addWidget(QLabel(f"绕 {key}"))
            row.addWidget(combo)
            mirror = QCheckBox(f"镜像 {key}")
            mirror.setToolTip(f"{key} 坐标取反；先镜像，再按 X → Y → Z 旋转，最后放到 Origin。")
            mirror.setChecked(instance.get("mirrors", [False] * 3)[axis] if instance else False)
            self.mirror_checks.append(mirror)
            row.addWidget(mirror)
            pose_form.addRow(f"Origin {key}", row)
        if not child:
            self.material_edit = QLineEdit(instance["material"] if instance else "solid")
            self.components = component_instances(editor.document)
            self.component_combo = QComboBox()
            self.component_combo.addItem("新建 Component", None)
            for name in self.components:
                self.component_combo.addItem(name, name)
            self.component_name_edit = QLineEdit()
            self.component_name_edit.setPlaceholderText("留空则使用实例名称")
            pose_form.addRow("所属 Component", self.component_combo)
            pose_form.addRow("新 Component 名称", self.component_name_edit)
            pose_form.addRow("材料", self.material_edit)
            def change_component():
                owner = self.component_combo.currentData()
                pose_form.setRowVisible(self.component_name_edit, owner is None)
                self.material_edit.setEnabled(owner is None)
                if owner is not None:
                    self.material_edit.setText(self.components[owner][0]["material"])
            self.component_combo.currentIndexChanged.connect(change_component)
            if self.original_id:
                self.component_combo.setCurrentIndex(self.component_combo.findData(component_id(instance)))
            change_component()
        self.status_label = QLabel()
        self.status_label.setWordWrap(True)
        self.status_label.setTextFormat(Qt.TextFormat.PlainText)
        root.addWidget(self.status_label)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setText("应用" if self.original_id else "创建实例")
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("取消")
        self.buttons.accepted.connect(self._submit)
        self.buttons.rejected.connect(self.reject)
        root.addWidget(self.buttons)
        _install_preview(self, editor_page, self._compile_preview,
            "子实例预览 · 使用父模板默认参数，坐标轴跟随子实例局部原点" if child else
            "实例预览 · 使用当前参数绑定，坐标轴跟随实例局部原点")
        for edit in editor_page.findChildren(QLineEdit):
            if edit not in self.parameter_edits.values():
                edit.textChanged.connect(self._schedule_preview)
        for combo in editor_page.findChildren(QComboBox):
            combo.currentIndexChanged.connect(self._schedule_preview)
        for check in self.mirror_checks:
            check.toggled.connect(self._schedule_preview)

    def _schedule_preview(self, *_args):
        if hasattr(self, "preview_panel"):
            self.preview_panel.schedule()

    def _compile_preview(self):
        templates = list(self.registry.values())
        scope = self.source_editor.document["globals"]
        if self.child:
            if self.preview_context is None:
                raise ValueError("子实例预览需要父模板的局部变量")
            context = self.preview_context()
            scope = context["template"]
            templates = _templates_with_draft(templates, context)
        return compile_draft_preview(templates, self.request(), scope=scope)

    def _load_template(self, name):
        while self.parameter_form.rowCount():
            self.parameter_form.removeRow(0)
        self.parameter_edits = {}
        if name not in self.registry:
            return
        for p in self.registry[name]["parameters"]:
            value = (self.original["bindings"].get(p["name"], p["default"])
                     if self.original and self.original["template"] == name else p["default"])
            if isinstance(value, (int, float)):
                value = literal(value, p["kind"])
            edit = _expression(value, self.candidates)
            edit.returnPressed.connect(self._submit)
            edit.textChanged.connect(self._schedule_preview)
            self.parameter_edits[p["name"]] = edit
            self.parameter_form.addRow(f"{p['name']} ({p['unit']})", edit)

    def request(self):
        name = self.template_combo.currentText()
        if name not in self.registry:
            raise ValueError("请先创建或导入模板")
        bindings = {p["name"]: _length_text(self.parameter_edits[p["name"]], p["unit"])
                    if p["kind"] == "length" else self.parameter_edits[p["name"]].text().strip()
                    for p in self.registry[name]["parameters"]}
        result = {"id": self.name_edit.text().strip(), "template": name, "bindings": bindings,
                  "origin": [_length_text(edit) for edit in self.origin_edits],
                  "rotation": [combo.currentData() for combo in self.rotation_combos],
                  "mirrors": [check.isChecked() for check in self.mirror_checks]}
        if not self.child:
            result["material"] = self.material_edit.text().strip()
            owner = self.component_combo.currentData()
            if owner is None:
                owner = self.component_name_edit.text().strip() or result["id"]
                if owner in self.components:
                    raise ValueError("Component 名称已存在，请从“所属 Component”选择它，或使用新名称")
            result["component_id"] = owner
        return result

    def _submit(self):
        try:
            self.submitRequested.emit(self.request())
        except (ValueError, KeyError, TypeError) as error:
            self.show_compilation_error(error)

    def show_compilation_error(self, error):
        self.status_label.setText(str(error))


class LocalTemplateDialog(QDialog):
    submitRequested = Signal(object)

    def __init__(self, parent, editor, *, template=None, duplicate=False):
        super().__init__(parent)
        self._local_tables_ready = False
        self.source_editor = editor
        self.opened_raw_sha256 = editor.raw_sha256
        self.original_id = template["id"] if template and not duplicate else None
        self.working = deepcopy(template or {"id": "geometry", "parameters": [], "derived": [],
                                                             "solids": [], "instances": []})
        self.child_dialog = None
        self.setWindowTitle("编辑模板" if self.original_id else "创建模板")
        self.resize(1250, 760)
        editor_page = QWidget()
        root = QVBoxLayout(editor_page)
        root.setContentsMargins(0, 0, 0, 0)
        label = QLabel("模板使用独立局部坐标系。公开参数显示在实例中；内部变量、基本图形和子实例只在这里编辑。"
                       "修改已有模板会更新引用它的实例；新增公开参数使用默认值，重命名保留原绑定。")
        label.setWordWrap(True)
        root.addWidget(label)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        root.addLayout(form)
        names = {t["id"] for t in editor.document["templates"]}
        name = self.working["id"] if self.original_id else _unique(self.working["id"], names)
        self.name_edit = QLineEdit(name)
        form.addRow("模板名称", self.name_edit)
        note = QLabel("局部原点固定为 (0, 0, 0)。所有图形坐标均相对此原点；模板在工程中的位置由 Instance 设置。")
        note.setWordWrap(True)
        root.addWidget(note)
        tabs = self.tabs = QTabWidget()
        root.addWidget(tabs, 1)
        locals_page = QWidget(); locals_layout = QVBoxLayout(locals_page)
        self.local_usage_label = QLabel()
        self.local_usage_label.setWordWrap(True)
        locals_layout.addWidget(self.local_usage_label)
        locals_layout.addWidget(QLabel("公开 Local variables"))
        self.parameter_table = self._variable_table(("名称", "类型", "单位", "默认值"), self.working["parameters"], False)
        locals_layout.addWidget(self.parameter_table, 1)
        self._table_actions(locals_layout, self.parameter_table, False)
        locals_layout.addWidget(QLabel("内部变量 / 公式（实例中隐藏；固定值也可填在这里）"))
        self.derived_table = self._variable_table(("名称", "类型", "表达式"), self.working["derived"], True)
        locals_layout.addWidget(self.derived_table, 1)
        self._table_actions(locals_layout, self.derived_table, True)
        tabs.addTab(locals_page, "Local variables")
        solids_page = QWidget(); solids_layout = QVBoxLayout(solids_page)
        splitter = QSplitter()
        self.solid_list = QListWidget()
        splitter.addWidget(self.solid_list)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        self.solid_page = QWidget(); self.solid_form = QFormLayout(self.solid_page)
        self.solid_form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        scroll.setWidget(self.solid_page); splitter.addWidget(scroll)
        splitter.setStretchFactor(1, 2); solids_layout.addWidget(splitter, 1)
        row = QHBoxLayout()
        self.shape_combo = QComboBox()
        for kind, label in SHAPE_LABELS.items():
            self.shape_combo.addItem(label, kind)
        row.addWidget(self.shape_combo)
        self.add_solid_button = QPushButton("添加基本图形")
        self.add_solid_button.clicked.connect(self._add_solid)
        row.addWidget(self.add_solid_button)
        remove = QPushButton("删除选中图形"); remove.clicked.connect(self._remove_solid); row.addWidget(remove)
        solids_layout.addLayout(row)
        tabs.addTab(solids_page, "基本图形")
        self.solid_fields, self.active_solid = [], -1
        for table in (self.parameter_table, self.derived_table):
            table.itemChanged.connect(self._refresh_local_variables)
            table.model().rowsRemoved.connect(self._refresh_local_variables)
        self.solid_list.currentRowChanged.connect(self._show_solid)
        self._refresh_solids()
        children_page = QWidget(); children_layout = QVBoxLayout(children_page)
        self.child_list = QListWidget(); children_layout.addWidget(self.child_list, 1)
        row = QHBoxLayout()
        self.add_child_button = QPushButton("从模板创建子实例…")
        self.add_child_button.clicked.connect(lambda: self._edit_child(False)); row.addWidget(self.add_child_button)
        edit = QPushButton("编辑子实例…"); edit.clicked.connect(lambda: self._edit_child(True)); row.addWidget(edit)
        remove = QPushButton("删除子实例"); remove.clicked.connect(self._remove_child); row.addWidget(remove)
        children_layout.addLayout(row)
        self._refresh_children()
        tabs.addTab(children_page, "子实例")
        self.status_label = QLabel(); self.status_label.setWordWrap(True)
        self.status_label.setTextFormat(Qt.TextFormat.PlainText)
        root.addWidget(self.status_label)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setText("保存模板到工程" if self.original_id else "创建模板")
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("取消")
        self.buttons.accepted.connect(self._submit)
        self.buttons.rejected.connect(self.reject)
        self.finished.connect(lambda: self.child_dialog.reject() if self.child_dialog else None)
        root.addWidget(self.buttons)
        _install_preview(self, editor_page, self._compile_preview,
                         "模板预览 · 使用公开参数默认值，坐标轴标记局部原点")
        self.name_edit.textChanged.connect(self.preview_panel.schedule)
        self._local_tables_ready = True
        self._refresh_local_variables()

    def _compile_preview(self):
        request = self.request()
        template = request["template"]
        templates = _templates_with_draft(self.source_editor.document["templates"], request)
        instance = {"id": "preview", "template": template["id"],
                    "bindings": {p["name"]: p["default"] for p in template["parameters"]},
                    "origin": ["0mm"] * 3}
        return compile_draft_preview(templates, instance)

    def _variable_table(self, headers, values, derived):
        headers = (*headers, "引用情况")
        table = QTableWidget(0, len(headers)); table.setHorizontalHeaderLabels(headers)
        table.setItemDelegate(ExpressionDelegate(table, expression_columns=(2 if derived else 3,),
                                                 candidates=self.local_names if derived else lambda: (),
                                                 name_columns=(0,)))
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        for value in values:
            self._append_variable(table, value, derived)
        return table

    def _append_variable(self, table, value, derived):
        with QSignalBlocker(table):
            index = table.rowCount(); table.insertRow(index)
            name = QTableWidgetItem(value["name"])
            name.setData(Qt.ItemDataRole.UserRole, deepcopy(value))
            name.setData(Qt.ItemDataRole.UserRole + 1, value["name"])
            table.setItem(index, 0, name)
            kind = QComboBox(); kind.addItems(("length", "dimensionless")); kind.setCurrentText(value["kind"])
            kind.currentTextChanged.connect(self._refresh_local_variables)
            table.setCellWidget(index, 1, kind)
            if not derived:
                table.setItem(index, 2, QTableWidgetItem(value["unit"]))
            scalar = value["expression" if derived else "default"]
            table.setItem(index, 2 if derived else 3, QTableWidgetItem(
                literal(scalar, value["kind"]) if isinstance(scalar, (int, float)) else str(scalar)))
            usage = QTableWidgetItem()
            usage.setFlags(usage.flags() & ~Qt.ItemFlag.ItemIsEditable)
            table.setItem(index, table.columnCount() - 1, usage)
        self._refresh_local_variables()

    def _table_actions(self, layout, table, derived):
        row = QHBoxLayout()
        add = QPushButton("添加内部变量" if derived else "添加公开参数")
        def append():
            names = self.local_names()
            value = {"name": _unique("local_value", names), "kind": "length"}
            value.update({"expression": "1mm"} if derived else {"unit": "mm", "default": "1mm"})
            self._append_variable(table, value, derived)
        add.clicked.connect(append)
        delete = QPushButton("删除选中变量")
        delete.clicked.connect(lambda: table.removeRow(table.currentRow()) if table.currentRow() >= 0 else None)
        row.addWidget(add); row.addWidget(delete); row.addStretch(1); layout.addLayout(row)

    def local_names(self):
        return tuple(table.item(row, 0).text().strip() for table in (self.parameter_table, self.derived_table)
                     for row in range(table.rowCount()))

    def _refresh_completions(self, *_args):
        candidates = list(dict.fromkeys((*self.local_names(), "mm", "um")))
        for _path, edit in self.solid_fields:
            if isinstance(edit, ExpressionEdit):
                edit.set_completion_candidates(candidates)

    def _refresh_local_variables(self, *_args):
        if not self._local_tables_ready:
            return
        if _args and isinstance(_args[0], QTableWidgetItem) and _args[0].column() == 0:
            self._rename_local_variable(_args[0])
        self._refresh_completions()
        self._refresh_local_usage()

    def _rename_local_variable(self, item):
        """Update visible draft references immediately; parent bindings change on save."""
        from .package_v2_source import _variable_identifier

        old_name = item.data(Qt.ItemDataRole.UserRole + 1)
        name = item.text()
        if name == old_name:
            return
        try:
            _variable_identifier(name, "/locals/name", field_name="局部变量名称")
            if self.local_names().count(name) > 1:
                raise ValueError(f"局部变量名称 {name!r} 已存在。")
        except ValueError as error:
            with QSignalBlocker(item.tableWidget()):
                item.setText(old_name)
            self.show_compilation_error(error)
            return
        self._save_solid_fields()
        derived, _ = self._read_variables(self.derived_table, True)
        scope = {"derived": derived, "solids": self.working["solids"],
                 "instances": self.working["instances"]}
        rewrite_scope_references(scope, {old_name: name}, allow_incomplete=True)
        self.working["solids"] = scope["solids"]
        with QSignalBlocker(self.derived_table):
            for row, variable in enumerate(derived):
                self.derived_table.item(row, 2).setText(str(variable["expression"]))
        if 0 <= self.active_solid < len(self.working["solids"]):
            for path, edit in self.solid_fields:
                value = self.working["solids"][self.active_solid]
                for key in path:
                    value = value[key]
                with QSignalBlocker(edit):
                    edit.setText(str(value))
        with QSignalBlocker(item.tableWidget()):
            item.setText(name)
            item.setData(Qt.ItemDataRole.UserRole + 1, name)
        self.status_label.setText(f"已更新局部变量 {old_name} → {name} 的引用；保存模板时统一校验。")

    def _refresh_local_usage(self, *_args):
        if not self._local_tables_ready:
            return
        self.preview_panel.schedule()
        self._save_solid_fields()
        template = dict(self.working)
        template["parameters"], _ = self._read_variables(self.parameter_table, False)
        template["derived"], _ = self._read_variables(self.derived_table, True)
        references = local_references(template)
        unused = 0
        for table in (self.parameter_table, self.derived_table):
            with QSignalBlocker(table):
                for row in range(table.rowCount()):
                    owners = references[table.item(row, 0).text().strip()]
                    unused += not owners
                    usage = table.item(row, table.columnCount() - 1)
                    usage.setText("已引用" if owners else "未引用")
                    usage.setData(Qt.ItemDataRole.UserRole, owners)
                    tooltip = ("引用位置：\n" + "\n".join(owners) if owners else
                               "此局部变量未被本模板的基本图形、内部公式或子实例引用。")
                    for column in range(table.columnCount()):
                        item = table.item(row, column)
                        if item is not None:
                            item.setToolTip(tooltip)
                            item.setData(Qt.ItemDataRole.BackgroundRole, QColor("#fff1c2") if not owners else None)
                            item.setData(Qt.ItemDataRole.ForegroundRole, QColor("#654b00") if not owners else None)
        self.local_usage_label.setText(
            f"黄色 / 未引用：{unused} 个。统计本模板内的引用；悬停查看引用位置。")

    def _read_variables(self, table, derived):
        values, renames = [], {}
        for row in range(table.rowCount()):
            name = table.item(row, 0).text()
            original = table.item(row, 0).data(Qt.ItemDataRole.UserRole)
            value = deepcopy(original)
            value.update(name=name, kind=table.cellWidget(row, 1).currentText())
            if name != original["name"]:
                renames[original["name"]] = name
            expression = table.item(row, 2 if derived else 3).text().strip()
            if value["kind"] == "length" and re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", expression):
                expression += "mm" if derived else table.item(row, 2).text().strip()
            value["expression" if derived else "default"] = expression
            if not derived:
                value["unit"] = table.item(row, 2).text().strip()
            values.append(value)
        return values, renames

    def _save_solid_fields(self):
        if self.active_solid < 0 or self.active_solid >= len(self.working["solids"]):
            return
        solid = self.working["solids"][self.active_solid]
        for path, edit in self.solid_fields:
            target = solid
            for key in path[:-1]:
                target = target[key]
            target[path[-1]] = edit.text().strip() if path == ("id",) else _length_text(edit)

    def _show_solid(self, index):
        self._save_solid_fields()
        self.active_solid = index
        while self.solid_form.rowCount():
            self.solid_form.removeRow(0)
        self.solid_fields = []
        if index < 0:
            self._refresh_local_usage()
            return
        solid = self.working["solids"][index]
        descriptions = {
            "bounds_box": "solid：用局部坐标定义长方体。",
            "bounds_ring": "ring：外框与内框定义矩形环，共用 zmin / zmax。",
            "bounds_fillet": "fillet：外框定义底部轮廓，内框定义开口。顶部 X−、X＋、Y−、Y＋宽度分别设置；每侧都可为 0，转角按相邻两侧宽度自动扫掠。",
        }
        note = QLabel(descriptions.get(solid["kind"], "组合基本图形"))
        note.setWordWrap(True)
        self.solid_form.addRow(note)
        def visit(value, path=()):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key == "kind" or (key == "id" and path):
                        continue
                    visit(child, (*path, key))
            elif isinstance(value, list):
                for i, child in enumerate(value):
                    visit(child, (*path, i))
            else:
                edit = QLineEdit(str(value)) if path == ("id",) else _expression(value, self.local_names())
                if isinstance(edit, ExpressionEdit):
                    edit.returnPressed.connect(self._submit)
                label = "名称" if path == ("id",) else " / ".join(map(str, path))
                if path[0] == "bounds":
                    label = ("外框 " if solid["kind"] != "bounds_box" and path[-1][0] != "z" else "") + path[-1]
                elif path[0] == "inner_bounds":
                    label = "内框 " + path[-1]
                elif path[0] == "top_widths":
                    side = {"xmin": "X−", "xmax": "X＋", "ymin": "Y−", "ymax": "Y＋"}[path[-1]]
                    label = f"顶部 {side} 宽度（≥ 0）"
                edit.setToolTip("相对局部原点 (0, 0, 0) 的坐标，可填写 Local variable 或带单位数值。"
                                if path[0] in ("bounds", "inner_bounds") else "")
                if path[0] == "top_widths":
                    edit.setToolTip("该侧顶部从内框向外延伸的宽度，可填写局部变量或带单位数值；0 表示该侧顶部收尖。")
                self.solid_form.addRow(label, edit)
                self.solid_fields.append((path, edit))
                edit.textChanged.connect(self._refresh_local_usage)
        visit(solid)
        self._refresh_local_usage()

    def _refresh_solids(self):
        self.solid_list.blockSignals(True)
        self.solid_list.clear()
        self.solid_list.addItems([f"{s['id']} · {SHAPE_LABELS.get(s['kind'], '组合图形')}" for s in self.working["solids"]])
        self.solid_list.blockSignals(False)
        if self.working["solids"]:
            self.solid_list.setCurrentRow(0)
        else:
            self._show_solid(-1)

    def _add_solid(self):
        self._save_solid_fields(); self.active_solid = -1
        ids = [v["id"] for key in ("solids", "instances") for v in self.working[key]]
        kind = self.shape_combo.currentData()
        self.working["solids"].append(new_basic_shape(kind, _unique(SHAPE_LABELS[kind], ids)))
        self._refresh_solids(); self.solid_list.setCurrentRow(len(self.working["solids"]) - 1)

    def _remove_solid(self):
        index = self.solid_list.currentRow()
        if index >= 0:
            self.active_solid = -1; self.working["solids"].pop(index); self._refresh_solids()

    def _refresh_children(self):
        self.child_list.clear()
        self.child_list.addItems([f"{v['id']} → {v['template']}" for v in self.working["instances"]])
        self._refresh_local_usage()

    def _edit_child(self, editing):
        index = self.child_list.currentRow() if editing else -1
        if editing and index < 0:
            return
        dialog = BoundInstanceDialog(self, self.source_editor, child=True, candidates=self.local_names(),
            instance=self.working["instances"][index] if editing else None,
            preview_context=self.request)
        self.child_dialog = dialog
        def submit(value):
            used = [v["id"] for i, v in enumerate(self.working["instances"]) if i != index] + [v["id"] for v in self.working["solids"]]
            if value["id"] in used:
                dialog.show_compilation_error("子对象名称重复")
                return
            if index < 0:
                self.working["instances"].append(value)
            else:
                self.working["instances"][index] = value
            self._refresh_children(); dialog.accept()
        dialog.submitRequested.connect(submit)
        dialog.finished.connect(lambda: setattr(self, "child_dialog", None))
        dialog.setModal(True); dialog.show()

    def _remove_child(self):
        index = self.child_list.currentRow()
        if index >= 0:
            self.working["instances"].pop(index); self._refresh_children()

    def request(self):
        self._save_solid_fields()
        template = deepcopy(self.working)
        template["id"] = self.name_edit.text().strip()
        template["parameters"], renames = self._read_variables(self.parameter_table, False)
        template["derived"], _ = self._read_variables(self.derived_table, True)
        return {"template": template, "original_id": self.original_id, "renames": renames}

    def _submit(self):
        try:
            self.submitRequested.emit(self.request())
        except (ValueError, KeyError, TypeError, AttributeError) as error:
            self.show_compilation_error(error)

    def show_compilation_error(self, error):
        self.status_label.setText(str(error))
