"""Parse and validate rectangular multi-bump layout files.

The ``.loc`` format contains bounds, templates, bumps, definitions, and mesh
region records::

    Xsize, 0mm, 10mm
    Ysize, 0mm, 5mm
    fine, "meshes/fine.msh"
    110um, 220um, fine
    define, corner = 50um
    mesh, HEX, size, [(0mm,0mm),(50um,0mm),(50um,50um),(0mm,50um)], x, 5um
    mesh, HEX, size, [(0mm,0mm),(50um,0mm),(50um,50um),(0mm,50um)], y, 5um

Lengths are normalized to millimetres at this file/API boundary.  A template
path is kept unchanged when absolute and is resolved relative to the layout
file's directory when relative.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
import math
from pathlib import Path
import re
from typing import Iterable


_COORDINATE_TOLERANCE_MM = 1.0e-12
_LENGTH = re.compile(
    r"(?P<number>[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)"
    r"\s*(?P<unit>mm|um|\N{MICRO SIGN}m|\N{GREEK SMALL LETTER MU}m)\Z",
    re.IGNORECASE,
)
_UNSIGNED_LENGTH_TOKEN = re.compile(
    r"(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"
    r"\s*(?:mm|um|\N{MICRO SIGN}m|\N{GREEK SMALL LETTER MU}m)",
    re.IGNORECASE,
)
_IDENTIFIER_TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_DEFINITION = re.compile(
    r"(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?P<expression>.+)\Z"
)


def _finite_float(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be finite")
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be finite") from error
    if not math.isfinite(parsed):
        raise ValueError(f"{field_name} must be finite")
    return parsed


def _length_mm(value: str, *, line_number: int, field_name: str) -> float:
    match = _LENGTH.fullmatch(value.strip())
    if match is None:
        raise ValueError(
            f"line {line_number}: {field_name} must use um, \N{MICRO SIGN}m, or mm"
        )
    number = float(match.group("number"))
    if not math.isfinite(number):
        raise ValueError(f"line {line_number}: {field_name} must be finite")
    unit = match.group("unit").lower()
    return number if unit == "mm" else number * 1.0e-3


def _non_empty(value: object, *, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a non-empty string")
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{field_name} must be a non-empty string")
    return normalized


def _integer_cell_count(extent_mm: float, size_mm: float, *, axis: str) -> int:
    ratio = extent_mm / size_mm
    count = round(ratio)
    if count < 1 or not math.isclose(ratio, count, rel_tol=1.0e-10, abs_tol=1.0e-10):
        raise ValueError(
            f"structured HEX region {axis} extent must be divisible by its mesh size"
        )
    return count


def _length_expression_mm(
    expression: str,
    definitions: dict[str, float],
    *,
    line_number: int,
    field_name: str,
) -> float:
    """Evaluate the deliberately small ``length (+|-) length`` grammar."""

    source = expression.strip()
    if not source:
        raise ValueError(f"line {line_number}: {field_name} must not be empty")

    position = 0
    sign = 1.0
    if source[position] in "+-":
        sign = -1.0 if source[position] == "-" else 1.0
        position += 1
    total = 0.0
    while True:
        while position < len(source) and source[position].isspace():
            position += 1
        literal_match = _UNSIGNED_LENGTH_TOKEN.match(source, position)
        identifier_match = _IDENTIFIER_TOKEN.match(source, position)
        if literal_match is not None:
            token = literal_match.group(0)
            term = _length_mm(
                token,
                line_number=line_number,
                field_name=field_name,
            )
            position = literal_match.end()
        elif identifier_match is not None:
            name = identifier_match.group(0)
            if name not in definitions:
                raise ValueError(
                    f"line {line_number}: unknown length variable {name!r} in {field_name}"
                )
            term = definitions[name]
            position = identifier_match.end()
        else:
            remainder = source[position:] or "<end>"
            raise ValueError(
                f"line {line_number}: invalid length expression in {field_name} near "
                f"{remainder!r}"
            )
        total += sign * term
        if not math.isfinite(total):
            raise ValueError(f"line {line_number}: {field_name} must be finite")

        while position < len(source) and source[position].isspace():
            position += 1
        if position == len(source):
            return total
        operator = source[position]
        if operator not in "+-":
            raise ValueError(
                f"line {line_number}: invalid length expression in {field_name} near "
                f"{source[position:]!r}"
            )
        sign = -1.0 if operator == "-" else 1.0
        position += 1


def _split_top_level_commas(
    value: str,
    *,
    line_number: int,
    field_name: str,
) -> list[str]:
    """Split commas while respecting the brackets used by mesh polygons."""

    matching = {")": "(", "]": "["}
    stack: list[str] = []
    fields: list[str] = []
    start = 0
    quote: str | None = None
    index = 0
    while index < len(value):
        character = value[index]
        if quote is not None:
            if character == quote:
                if quote == '"' and index + 1 < len(value) and value[index + 1] == '"':
                    index += 2
                    continue
                quote = None
        elif character in {'"', "'"}:
            quote = character
        elif character in "([":
            stack.append(character)
        elif character in ")]":
            if not stack or stack[-1] != matching[character]:
                raise ValueError(
                    f"line {line_number}: mismatched delimiter in {field_name}"
                )
            stack.pop()
        elif character == "," and not stack:
            fields.append(value[start:index].strip())
            start = index + 1
        index += 1

    if quote is not None:
        raise ValueError(f"line {line_number}: unterminated quote in {field_name}")
    if stack:
        raise ValueError(f"line {line_number}: unclosed delimiter in {field_name}")
    fields.append(value[start:].strip())
    return fields


@dataclass(frozen=True, slots=True)
class LayoutBounds:
    """Axis-aligned xy layout bounds, expressed in millimetres."""

    x_min_mm: float
    x_max_mm: float
    y_min_mm: float
    y_max_mm: float

    def __post_init__(self) -> None:
        values = {
            name: _finite_float(getattr(self, name), field_name=name)
            for name in ("x_min_mm", "x_max_mm", "y_min_mm", "y_max_mm")
        }
        for name, value in values.items():
            object.__setattr__(self, name, value)
        if self.x_max_mm <= self.x_min_mm:
            raise ValueError("Xsize maximum must be greater than its minimum")
        if self.y_max_mm <= self.y_min_mm:
            raise ValueError("Ysize maximum must be greater than its minimum")

    @property
    def width_mm(self) -> float:
        return self.x_max_mm - self.x_min_mm

    @property
    def height_mm(self) -> float:
        return self.y_max_mm - self.y_min_mm


@dataclass(frozen=True, slots=True)
class BumpMeshTemplate:
    """A symbolic template name and the mesh file it references."""

    alias: str
    mesh_path: Path

    def __post_init__(self) -> None:
        alias = _non_empty(self.alias, field_name="template alias")
        path = Path(self.mesh_path)
        object.__setattr__(self, "alias", alias)
        object.__setattr__(self, "mesh_path", path)
        if not path.exists():
            raise ValueError(f"template {alias!r} does not exist: {path}")
        if not path.is_file():
            raise ValueError(f"template {alias!r} is not a file: {path}")


@dataclass(frozen=True, slots=True)
class BumpInstance:
    """One bump centre and the symbolic mesh template used at that centre."""

    x_mm: float
    y_mm: float
    template_alias: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "x_mm", _finite_float(self.x_mm, field_name="bump x coordinate")
        )
        object.__setattr__(
            self, "y_mm", _finite_float(self.y_mm, field_name="bump y coordinate")
        )
        object.__setattr__(
            self,
            "template_alias",
            _non_empty(self.template_alias, field_name="bump template alias"),
        )


@dataclass(frozen=True, slots=True)
class StructuredHexRegion:
    """An XY rectangle with independent structured HEX spacings.

    ``size_mm`` is the X spacing and the default Y spacing for compatibility
    with callers that specify a single size.
    """

    x_min_mm: float
    x_max_mm: float
    y_min_mm: float
    y_max_mm: float
    size_mm: float
    size_y_mm: float | None = None

    def __post_init__(self) -> None:
        values = {
            name: _finite_float(getattr(self, name), field_name=name)
            for name in (
                "x_min_mm",
                "x_max_mm",
                "y_min_mm",
                "y_max_mm",
                "size_mm",
            )
        }
        for name, value in values.items():
            object.__setattr__(self, name, value)
        object.__setattr__(
            self,
            "size_y_mm",
            self.size_mm if self.size_y_mm is None else _finite_float(
                self.size_y_mm, field_name="size_y_mm"
            ),
        )
        if self.x_max_mm <= self.x_min_mm:
            raise ValueError(
                "structured HEX region x maximum must be greater than its minimum"
            )
        if self.y_max_mm <= self.y_min_mm:
            raise ValueError(
                "structured HEX region y maximum must be greater than its minimum"
            )
        if self.size_mm <= 0.0 or self.size_y_mm <= 0.0:
            raise ValueError("structured HEX region mesh size must be positive")
        _integer_cell_count(self.width_mm, self.size_mm, axis="x")
        _integer_cell_count(self.height_mm, self.size_y_mm, axis="y")

    @property
    def width_mm(self) -> float:
        return self.x_max_mm - self.x_min_mm

    @property
    def height_mm(self) -> float:
        return self.y_max_mm - self.y_min_mm

    @property
    def size_x_mm(self) -> float:
        return self.size_mm

    @property
    def x_cell_count(self) -> int:
        return _integer_cell_count(self.width_mm, self.size_mm, axis="x")

    @property
    def y_cell_count(self) -> int:
        return _integer_cell_count(self.height_mm, self.size_y_mm, axis="y")


@dataclass(frozen=True, slots=True)
class BumpLayout:
    """An immutable layout whose template footprints are validated when meshed."""

    bounds: LayoutBounds
    templates: tuple[BumpMeshTemplate, ...]
    instances: tuple[BumpInstance, ...]
    source_path: Path | None = None
    mesh_regions: tuple[StructuredHexRegion, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.bounds, LayoutBounds):
            raise TypeError("bounds must be LayoutBounds")
        try:
            templates = tuple(self.templates)
            instances = tuple(self.instances)
            mesh_regions = tuple(self.mesh_regions)
        except TypeError as error:
            raise TypeError(
                "templates, instances, and mesh_regions must be iterables"
            ) from error
        if not templates:
            raise ValueError("a bump layout must define at least one mesh template")
        if not instances:
            raise ValueError("a bump layout must define at least one bump instance")
        if any(not isinstance(item, BumpMeshTemplate) for item in templates):
            raise TypeError("templates must contain BumpMeshTemplate objects")
        if any(not isinstance(item, BumpInstance) for item in instances):
            raise TypeError("instances must contain BumpInstance objects")
        if any(not isinstance(item, StructuredHexRegion) for item in mesh_regions):
            raise TypeError("mesh_regions must contain StructuredHexRegion objects")
        object.__setattr__(self, "templates", templates)
        object.__setattr__(self, "instances", instances)
        object.__setattr__(self, "mesh_regions", mesh_regions)
        if self.source_path is not None:
            object.__setattr__(self, "source_path", Path(self.source_path))

        template_aliases = [template.alias for template in templates]
        if len(set(template_aliases)) != len(template_aliases):
            raise ValueError("mesh template aliases must be unique")
        known_aliases = set(template_aliases)

        for instance in instances:
            if instance.template_alias not in known_aliases:
                raise ValueError(
                    f"bump references unknown mesh template {instance.template_alias!r}"
                )

        for index, first in enumerate(instances):
            for second in instances[index + 1 :]:
                pitch = math.hypot(
                    first.x_mm - second.x_mm,
                    first.y_mm - second.y_mm,
                )
                if pitch <= _COORDINATE_TOLERANCE_MM:
                    raise ValueError(
                        f"duplicate bump coordinate ({first.x_mm:g}, "
                        f"{first.y_mm:g}) mm"
                    )

        for region in mesh_regions:
            if (
                region.x_min_mm < self.bounds.x_min_mm - _COORDINATE_TOLERANCE_MM
                or region.x_max_mm
                > self.bounds.x_max_mm + _COORDINATE_TOLERANCE_MM
                or region.y_min_mm
                < self.bounds.y_min_mm - _COORDINATE_TOLERANCE_MM
                or region.y_max_mm
                > self.bounds.y_max_mm + _COORDINATE_TOLERANCE_MM
            ):
                raise ValueError("structured HEX region must lie within layout bounds")

        for index, first in enumerate(mesh_regions):
            for second in mesh_regions[index + 1 :]:
                overlap_x = min(first.x_max_mm, second.x_max_mm) - max(
                    first.x_min_mm, second.x_min_mm
                )
                overlap_y = min(first.y_max_mm, second.y_max_mm) - max(
                    first.y_min_mm, second.y_min_mm
                )
                if (
                    overlap_x >= -_COORDINATE_TOLERANCE_MM
                    and overlap_y >= -_COORDINATE_TOLERANCE_MM
                ):
                    raise ValueError(
                        "structured HEX regions must not touch or overlap"
                    )

    @property
    def template_by_alias(self) -> dict[str, BumpMeshTemplate]:
        return {template.alias: template for template in self.templates}


def _resolved_template_path(path_text: str, base_directory: Path) -> Path:
    path = Path(path_text.strip()).expanduser()
    if path.is_absolute():
        return path
    return (base_directory / path).resolve()


@dataclass(frozen=True, slots=True)
class _MeshAxisControl:
    x_min_mm: float
    x_max_mm: float
    y_min_mm: float
    y_max_mm: float
    axis: str
    size_mm: float
    line_number: int


def _legacy_csv_row(raw_line: str, *, line_number: int) -> list[str]:
    try:
        rows = list(csv.reader([raw_line], skipinitialspace=True, strict=True))
    except csv.Error as error:
        raise ValueError(f"line {line_number}: invalid CSV syntax: {error}") from error
    if len(rows) != 1:
        raise ValueError(f"line {line_number}: invalid CSV syntax")
    return [field.strip() for field in rows[0]]


def _coordinate_levels(values: Iterable[float]) -> list[float]:
    levels: list[float] = []
    for value in sorted(values):
        if not levels or not math.isclose(
            value,
            levels[-1],
            rel_tol=0.0,
            abs_tol=_COORDINATE_TOLERANCE_MM,
        ):
            levels.append(value)
    return levels


def _parse_mesh_polygon(
    value: str,
    definitions: dict[str, float],
    *,
    line_number: int,
) -> tuple[float, float, float, float]:
    polygon = value.strip()
    if not (polygon.startswith("[") and polygon.endswith("]")):
        raise ValueError(
            f"line {line_number}: mesh region must be a bracketed four-point polygon"
        )
    vertex_fields = _split_top_level_commas(
        polygon[1:-1],
        line_number=line_number,
        field_name="mesh region polygon",
    )
    if len(vertex_fields) != 4:
        raise ValueError(f"line {line_number}: mesh region must contain four points")

    vertices: list[tuple[float, float]] = []
    for vertex_index, vertex_field in enumerate(vertex_fields, start=1):
        vertex = vertex_field.strip()
        if not (vertex.startswith("(") and vertex.endswith(")")):
            raise ValueError(
                f"line {line_number}: mesh region point {vertex_index} must be an "
                "(x, y) pair"
            )
        coordinates = _split_top_level_commas(
            vertex[1:-1],
            line_number=line_number,
            field_name=f"mesh region point {vertex_index}",
        )
        if len(coordinates) != 2:
            raise ValueError(
                f"line {line_number}: mesh region point {vertex_index} must contain x and y"
            )
        vertices.append(
            (
                _length_expression_mm(
                    coordinates[0],
                    definitions,
                    line_number=line_number,
                    field_name=f"mesh region point {vertex_index} x coordinate",
                ),
                _length_expression_mm(
                    coordinates[1],
                    definitions,
                    line_number=line_number,
                    field_name=f"mesh region point {vertex_index} y coordinate",
                ),
            )
        )

    x_levels = _coordinate_levels(vertex[0] for vertex in vertices)
    y_levels = _coordinate_levels(vertex[1] for vertex in vertices)
    if len(x_levels) != 2 or len(y_levels) != 2:
        raise ValueError(
            f"line {line_number}: mesh region must be an axis-aligned rectangle"
        )
    expected_corners = tuple(
        (x_value, y_value) for x_value in x_levels for y_value in y_levels
    )
    for expected_x, expected_y in expected_corners:
        matches = sum(
            math.isclose(
                actual_x,
                expected_x,
                rel_tol=0.0,
                abs_tol=_COORDINATE_TOLERANCE_MM,
            )
            and math.isclose(
                actual_y,
                expected_y,
                rel_tol=0.0,
                abs_tol=_COORDINATE_TOLERANCE_MM,
            )
            for actual_x, actual_y in vertices
        )
        if matches != 1:
            raise ValueError(
                f"line {line_number}: mesh region must contain each rectangle corner once"
            )
    return x_levels[0], x_levels[1], y_levels[0], y_levels[1]


def _parse_mesh_axis_control(
    raw_line: str,
    definitions: dict[str, float],
    *,
    line_number: int,
) -> _MeshAxisControl:
    row = _split_top_level_commas(
        raw_line,
        line_number=line_number,
        field_name="mesh record",
    )
    if len(row) != 6:
        raise ValueError(
            f"line {line_number}: mesh record requires family, quantity, polygon, "
            "axis, and size"
        )
    if row[1].casefold() != "hex":
        raise ValueError(f"line {line_number}: mesh family must be HEX")
    if row[2].casefold() != "size":
        raise ValueError(f"line {line_number}: mesh quantity must be size")
    axis = row[4].casefold()
    if axis not in {"x", "y"}:
        raise ValueError(f"line {line_number}: mesh size axis must be x or y")
    size_mm = _length_expression_mm(
        row[5],
        definitions,
        line_number=line_number,
        field_name=f"mesh {axis} size",
    )
    if size_mm <= 0.0:
        raise ValueError(f"line {line_number}: mesh {axis} size must be positive")
    x_min, x_max, y_min, y_max = _parse_mesh_polygon(
        row[3],
        definitions,
        line_number=line_number,
    )
    return _MeshAxisControl(
        x_min,
        x_max,
        y_min,
        y_max,
        axis,
        size_mm,
        line_number,
    )


def _same_control_rectangle(
    first: _MeshAxisControl,
    second: _MeshAxisControl,
) -> bool:
    return all(
        math.isclose(
            getattr(first, field_name),
            getattr(second, field_name),
            rel_tol=0.0,
            abs_tol=_COORDINATE_TOLERANCE_MM,
        )
        for field_name in ("x_min_mm", "x_max_mm", "y_min_mm", "y_max_mm")
    )


def _merge_mesh_axis_controls(
    controls: Iterable[_MeshAxisControl],
) -> tuple[StructuredHexRegion, ...]:
    groups: list[list[_MeshAxisControl]] = []
    for control in controls:
        group = next(
            (
                candidate
                for candidate in groups
                if _same_control_rectangle(candidate[0], control)
            ),
            None,
        )
        if group is None:
            groups.append([control])
            continue
        if any(candidate.axis == control.axis for candidate in group):
            raise ValueError(
                f"line {control.line_number}: duplicate mesh {control.axis} size for region"
            )
        group.append(control)

    regions: list[StructuredHexRegion] = []
    for group in groups:
        by_axis = {control.axis: control for control in group}
        missing_axes = [axis for axis in ("x", "y") if axis not in by_axis]
        if missing_axes:
            raise ValueError(
                f"line {group[0].line_number}: mesh region must define x and y sizes; "
                f"missing {', '.join(missing_axes)}"
            )
        x_control = by_axis["x"]
        y_control = by_axis["y"]
        try:
            regions.append(
                StructuredHexRegion(
                    x_control.x_min_mm,
                    x_control.x_max_mm,
                    x_control.y_min_mm,
                    x_control.y_max_mm,
                    x_control.size_mm,
                    size_y_mm=y_control.size_mm,
                )
            )
        except ValueError as error:
            raise ValueError(f"line {group[0].line_number}: {error}") from error
    return tuple(regions)


def parse_bump_layout_text(
    text: str,
    base_directory: str | Path | None = None,
    *,
    source_path: str | Path | None = None,
) -> BumpLayout:
    """Parse the multi-record ``.loc`` format and return a validated layout."""

    if not isinstance(text, str):
        raise TypeError("layout text must be a string")
    base = Path.cwd() if base_directory is None else Path(base_directory).expanduser()
    base = base.resolve()

    bounds: dict[str, tuple[float, float]] = {}
    templates: list[BumpMeshTemplate] = []
    instances: list[BumpInstance] = []
    definitions: dict[str, float] = {}
    mesh_controls: list[_MeshAxisControl] = []
    aliases: set[str] = set()

    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        raw_record_name = raw_line.split(",", maxsplit=1)[0].strip()
        if raw_record_name.casefold() == "mesh":
            mesh_controls.append(
                _parse_mesh_axis_control(
                    raw_line,
                    definitions,
                    line_number=line_number,
                )
            )
            continue

        row = _legacy_csv_row(raw_line, line_number=line_number)
        if not row or not any(row) or row[0].startswith("#"):
            continue
        record_name = row[0]
        record_kind = record_name.casefold()
        if record_kind == "define":
            if len(row) != 2:
                raise ValueError(
                    f"line {line_number}: define requires name = length expression"
                )
            assignment = _DEFINITION.fullmatch(row[1])
            if assignment is None:
                raise ValueError(
                    f"line {line_number}: define requires name = length expression"
                )
            name = assignment.group("name")
            if name in definitions:
                raise ValueError(
                    f"line {line_number}: duplicate length variable {name!r}"
                )
            value_mm = _length_expression_mm(
                assignment.group("expression"),
                definitions,
                line_number=line_number,
                field_name=f"length variable {name!r}",
            )
            if value_mm <= 0.0:
                raise ValueError(
                    f"line {line_number}: length variable {name!r} must be positive"
                )
            definitions[name] = value_mm
            continue

        if record_kind in {"xsize", "ysize"}:
            if len(row) != 3:
                raise ValueError(
                    f"line {line_number}: {record_name} requires minimum and maximum"
                )
            if record_kind in bounds:
                raise ValueError(
                    f"line {line_number}: duplicate {record_name} definition"
                )
            bounds[record_kind] = (
                _length_mm(
                    row[1], line_number=line_number, field_name=f"{record_name} minimum"
                ),
                _length_mm(
                    row[2], line_number=line_number, field_name=f"{record_name} maximum"
                ),
            )
            continue

        if len(row) == 2:
            alias = _non_empty(record_name, field_name=f"line {line_number} alias")
            if alias in aliases:
                raise ValueError(
                    f"line {line_number}: duplicate mesh template alias {alias!r}"
                )
            if not row[1]:
                raise ValueError(f"line {line_number}: template path must not be empty")
            templates.append(
                BumpMeshTemplate(
                    alias,
                    _resolved_template_path(row[1], base),
                )
            )
            aliases.add(alias)
            continue

        if len(row) == 3:
            instances.append(
                BumpInstance(
                    _length_mm(
                        row[0], line_number=line_number, field_name="bump x coordinate"
                    ),
                    _length_mm(
                        row[1], line_number=line_number, field_name="bump y coordinate"
                    ),
                    row[2],
                )
            )
            continue

        raise ValueError(
            f"line {line_number}: expected a bounds, template, bump, define, or mesh record"
        )

    missing_bounds = [name for name in ("xsize", "ysize") if name not in bounds]
    if missing_bounds:
        raise ValueError("missing layout bounds: " + ", ".join(missing_bounds))
    x_min, x_max = bounds["xsize"]
    y_min, y_max = bounds["ysize"]
    mesh_regions = _merge_mesh_axis_controls(mesh_controls)
    return BumpLayout(
        bounds=LayoutBounds(x_min, x_max, y_min, y_max),
        templates=tuple(templates),
        instances=tuple(instances),
        source_path=None if source_path is None else Path(source_path),
        mesh_regions=mesh_regions,
    )


def load_bump_layout(path: str | Path) -> BumpLayout:
    """Read a UTF-8 ``.loc`` file and resolve relative templates beside it."""

    source = Path(path).expanduser().resolve()
    return parse_bump_layout_text(
        source.read_text(encoding="utf-8-sig"),
        source.parent,
        source_path=source,
    )


__all__ = [
    "BumpInstance",
    "BumpLayout",
    "BumpMeshTemplate",
    "LayoutBounds",
    "StructuredHexRegion",
    "load_bump_layout",
    "parse_bump_layout_text",
]
