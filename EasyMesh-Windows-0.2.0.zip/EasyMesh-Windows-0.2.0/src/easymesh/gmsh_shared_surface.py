"""Generic Gmsh meshing for a labelled, conformal planar partition.

This module owns no package-component semantics.  Callers describe one or
more coplanar polygonal regions using shared source-node IDs.  Gmsh then owns
all newly generated two-dimensional connectivity.  A complete region may
optionally be supplied as an immutable TRI3/QUAD4 patch; that patch remains
source-owned while every neighbouring Gmsh region reuses its exact perimeter
nodes and edges.

The common use case is a fixed central surface mesh surrounded by a generated
annulus.  The same API also meshes both sides of a labelled internal boundary,
which makes it possible to extract an inner subset and its remainder without
role-specific seam rules.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from statistics import median
from types import MappingProxyType
from typing import Any, Literal, TypeAlias

from .gmsh_runtime import isolated_gmsh_model


Point3D: TypeAlias = tuple[float, float, float]
EdgeKey: TypeAlias = tuple[int, int]
FacetProvenance: TypeAlias = Literal["gmsh_generated", "locked_source"]

_TRI3 = 2
_QUAD4 = 3
_ROUND_DIGITS = 12
_ABSOLUTE_TOLERANCE_MM = 1.0e-10


class SharedSurfaceMeshingError(ValueError):
    """Raised when a planar shared-surface mesh cannot be proven conformal."""


@dataclass(frozen=True, slots=True)
class PlanarRegion:
    """One labelled polygonal region in a common plane.

    Loops use source-node IDs and do not repeat their first node at the end.
    Adjacent regions must spell their common boundary with the same node chain.
    Setting ``recombine`` allows Gmsh to return a mixed TRI3/QUAD4 patch;
    otherwise the generated patch is TRI3-only.
    """

    label: str
    outer_loop: tuple[int, ...]
    holes: tuple[tuple[int, ...], ...] = ()
    recombine: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.label, str) or not self.label.strip():
            raise SharedSurfaceMeshingError("planar region label must be non-empty")
        if not isinstance(self.recombine, bool):
            raise SharedSurfaceMeshingError("planar region recombine must be boolean")


@dataclass(frozen=True, slots=True)
class LockedBoundaryChain:
    """An exact open or closed source-node chain on region boundaries."""

    node_ids: tuple[int, ...]
    closed: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.closed, bool):
            raise SharedSurfaceMeshingError("locked chain closed flag must be boolean")


@dataclass(frozen=True, slots=True)
class SharedSurfaceFacet:
    """One audited result-local TRI3/QUAD4 facet."""

    kind: Literal["TRI3", "QUAD4"]
    node_ids: tuple[int, ...]
    region_label: str
    provenance: FacetProvenance

    def __post_init__(self) -> None:
        expected = 3 if self.kind == "TRI3" else 4 if self.kind == "QUAD4" else 0
        if expected == 0 or len(self.node_ids) != expected:
            raise SharedSurfaceMeshingError("shared facet must be TRI3 or QUAD4")
        if len(set(self.node_ids)) != expected:
            raise SharedSurfaceMeshingError("shared facet contains repeated nodes")
        if self.provenance not in {"gmsh_generated", "locked_source"}:
            raise SharedSurfaceMeshingError("shared facet provenance is invalid")


@dataclass(frozen=True, slots=True)
class GmshSharedSurface:
    """Pure-data, audited result of a Gmsh planar-partition mesh."""

    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    facets: tuple[SharedSurfaceFacet, ...]
    facets_by_region: Mapping[str, tuple[SharedSurfaceFacet, ...]]
    region_area_mm2: Mapping[str, float]
    target_edge_mm: float
    near_edge_mm: float
    transition_distance_mm: float
    background_field_kind: str
    generated_triangle_count: int
    generated_quad_count: int
    locked_triangle_count: int
    locked_quad_count: int
    exterior_boundary_edge_count: int
    shared_interface_edge_count: int
    minimum_quality: float
    duplicate_node_count: int
    duplicate_facet_count: int
    nonmanifold_edge_count: int
    unmatched_region_boundary_edge_count: int
    random_seed: int

    @property
    def node_count(self) -> int:
        return len(self.node_coordinates)

    @property
    def facet_count(self) -> int:
        return len(self.facets)

    @property
    def gmsh_generated_facet_count(self) -> int:
        return self.generated_triangle_count + self.generated_quad_count

    @property
    def locked_facet_count(self) -> int:
        return self.locked_triangle_count + self.locked_quad_count


@dataclass(frozen=True, slots=True)
class _PlaneFrame:
    origin: Point3D
    u: Point3D
    v: Point3D
    normal: Point3D
    tolerance_mm: float


@dataclass(frozen=True, slots=True)
class _PreparedRegion:
    label: str
    outer_loop: tuple[int, ...]
    holes: tuple[tuple[int, ...], ...]
    recombine: bool
    locked_facets: tuple[tuple[int, ...], ...]
    expected_area_mm2: float

    @property
    def loops(self) -> tuple[tuple[int, ...], ...]:
        return (self.outer_loop, *self.holes)


@dataclass(frozen=True, slots=True)
class _RawFacet:
    gmsh_type: int
    gmsh_nodes: tuple[int, ...]
    region_label: str
    quality: float


@dataclass(frozen=True, slots=True)
class _RawMesh:
    gmsh_coordinates: Mapping[int, Point3D]
    generated_facets: tuple[_RawFacet, ...]
    curve_edges: Mapping[int, tuple[EdgeKey, ...]]
    surface_by_region: Mapping[str, int]
    curve_by_source_edge: Mapping[EdgeKey, int]
    background_field_kind: str
    duplicate_node_count: int


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise RuntimeError("Gmsh is required for shared-surface meshing") from error
    return gmsh


def _finite(value: object, *, name: str) -> float:
    if isinstance(value, bool):
        raise SharedSurfaceMeshingError(f"{name} must be finite")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise SharedSurfaceMeshingError(f"{name} must be finite") from error
    if not math.isfinite(result):
        raise SharedSurfaceMeshingError(f"{name} must be finite")
    return result


def _point(value: object, *, name: str) -> Point3D:
    try:
        raw = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise SharedSurfaceMeshingError(f"{name} must be a 3-D point") from error
    if len(raw) != 3:
        raise SharedSurfaceMeshingError(f"{name} must be a 3-D point")
    return tuple(_finite(component, name=name) for component in raw)  # type: ignore[return-value]


def _coordinate_key(point: Sequence[float]) -> Point3D:
    return tuple(round(float(value), _ROUND_DIGITS) for value in point)  # type: ignore[return-value]


def _edge_key(first: int, second: int) -> EdgeKey:
    return (first, second) if first < second else (second, first)


def _subtract(first: Point3D, second: Point3D) -> Point3D:
    return tuple(first[index] - second[index] for index in range(3))  # type: ignore[return-value]


def _dot(first: Point3D, second: Point3D) -> float:
    return math.fsum(first[index] * second[index] for index in range(3))


def _cross(first: Point3D, second: Point3D) -> Point3D:
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _norm(vector: Point3D) -> float:
    return math.sqrt(_dot(vector, vector))


def _normalize(vector: Point3D, *, name: str) -> Point3D:
    length = _norm(vector)
    if length <= _ABSOLUTE_TOLERANCE_MM:
        raise SharedSurfaceMeshingError(f"{name} is degenerate")
    return tuple(value / length for value in vector)  # type: ignore[return-value]


def _loop_edges(loop: Sequence[int]) -> tuple[EdgeKey, ...]:
    return tuple(
        _edge_key(first, second)
        for first, second in zip(loop, (*loop[1:], loop[0]))
    )


def _normalize_loop(value: Sequence[int], *, name: str) -> tuple[int, ...]:
    try:
        raw = tuple(value)
    except TypeError as error:
        raise SharedSurfaceMeshingError(f"{name} must be a node cycle") from error
    if len(raw) >= 2 and raw[0] == raw[-1]:
        raw = raw[:-1]
    if len(raw) < 3:
        raise SharedSurfaceMeshingError(f"{name} must contain at least three nodes")
    if any(isinstance(node, bool) or not isinstance(node, int) for node in raw):
        raise SharedSurfaceMeshingError(f"{name} node IDs must be integers")
    if len(set(raw)) != len(raw):
        raise SharedSurfaceMeshingError(f"{name} contains a repeated node")
    return raw


def _infer_plane(
    coordinates: Mapping[int, Point3D],
    first_loop: Sequence[int],
) -> _PlaneFrame:
    origin = coordinates[first_loop[0]]
    first_vector: Point3D | None = None
    normal_vector: Point3D | None = None
    for node in first_loop[1:]:
        candidate = _subtract(coordinates[node], origin)
        if _norm(candidate) > _ABSOLUTE_TOLERANCE_MM:
            first_vector = candidate
            break
    if first_vector is None:
        raise SharedSurfaceMeshingError("first planar loop is degenerate")
    for node in first_loop[2:]:
        candidate = _cross(first_vector, _subtract(coordinates[node], origin))
        if _norm(candidate) > _ABSOLUTE_TOLERANCE_MM**2:
            normal_vector = candidate
            break
    if normal_vector is None:
        raise SharedSurfaceMeshingError("first planar loop is collinear")
    u = _normalize(first_vector, name="planar frame axis")
    normal = _normalize(normal_vector, name="planar frame normal")
    v = _normalize(_cross(normal, u), name="planar frame second axis")
    axis_min = tuple(min(point[axis] for point in coordinates.values()) for axis in range(3))
    axis_max = tuple(max(point[axis] for point in coordinates.values()) for axis in range(3))
    diameter = max(math.dist(axis_min, axis_max), 1.0)
    tolerance = max(_ABSOLUTE_TOLERANCE_MM, diameter * 1.0e-9)
    for source_id, point in coordinates.items():
        distance = abs(_dot(_subtract(point, origin), normal))
        if distance > tolerance:
            raise SharedSurfaceMeshingError(
                f"source node {source_id} is not in the common plane"
            )
    return _PlaneFrame(origin, u, v, normal, tolerance)


def _project(point: Point3D, frame: _PlaneFrame) -> tuple[float, float]:
    delta = _subtract(point, frame.origin)
    return _dot(delta, frame.u), _dot(delta, frame.v)


def _signed_loop_area(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
    frame: _PlaneFrame,
) -> float:
    projected = tuple(_project(coordinates[node], frame) for node in loop)
    return 0.5 * math.fsum(
        projected[index][0] * projected[(index + 1) % len(projected)][1]
        - projected[(index + 1) % len(projected)][0] * projected[index][1]
        for index in range(len(projected))
    )


def _oriented_loop(
    loop: tuple[int, ...],
    coordinates: Mapping[int, Point3D],
    frame: _PlaneFrame,
    *,
    positive: bool,
    name: str,
) -> tuple[int, ...]:
    area = _signed_loop_area(loop, coordinates, frame)
    if abs(area) <= frame.tolerance_mm**2:
        raise SharedSurfaceMeshingError(f"{name} has zero area")
    return loop if (area > 0.0) == positive else tuple(reversed(loop))


def _facet_area(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> float:
    origin = coordinates[facet[0]]
    return 0.5 * math.fsum(
        _norm(
            _cross(
                _subtract(coordinates[facet[index]], origin),
                _subtract(coordinates[facet[index + 1]], origin),
            )
        )
        for index in range(1, len(facet) - 1)
    )


def _facet_quality(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> float:
    points = tuple(coordinates[node] for node in facet)
    if len(points) == 3:
        lengths_squared = tuple(
            _dot(_subtract(points[index], points[(index + 1) % 3]), _subtract(points[index], points[(index + 1) % 3]))
            for index in range(3)
        )
        denominator = math.fsum(lengths_squared)
        if denominator <= 0.0:
            return 0.0
        return 4.0 * math.sqrt(3.0) * _facet_area(facet, coordinates) / denominator
    qualities: list[float] = []
    signs: list[float] = []
    reference: Point3D | None = None
    for index in range(4):
        previous = _subtract(points[(index - 1) % 4], points[index])
        following = _subtract(points[(index + 1) % 4], points[index])
        denominator = _norm(previous) * _norm(following)
        cross = _cross(following, previous)
        if denominator <= 0.0 or _norm(cross) <= 0.0:
            return 0.0
        if reference is None:
            reference = cross
        signs.append(_dot(cross, reference))
        qualities.append(_norm(cross) / denominator)
    if any(value <= 0.0 for value in signs):
        return 0.0
    return min(qualities)


def _locked_patch_boundary_edges(
    facets: Sequence[Sequence[int]],
) -> tuple[set[EdgeKey], Counter[EdgeKey]]:
    counts: Counter[EdgeKey] = Counter(
        _edge_key(first, second)
        for facet in facets
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    if any(count not in {1, 2} for count in counts.values()):
        raise SharedSurfaceMeshingError("locked patch is non-manifold")
    return {edge for edge, count in counts.items() if count == 1}, counts


def _prepare(
    source_node_coordinates: Mapping[int, Sequence[float]],
    regions: Sequence[PlanarRegion],
    locked_facets_by_region: Mapping[str, Sequence[Sequence[int]]],
    locked_boundary_chains: Sequence[LockedBoundaryChain],
) -> tuple[
    Mapping[int, Point3D],
    tuple[_PreparedRegion, ...],
    _PlaneFrame,
    set[EdgeKey],
]:
    if not isinstance(source_node_coordinates, Mapping) or not source_node_coordinates:
        raise SharedSurfaceMeshingError("source-node coordinates must be non-empty")
    coordinates: dict[int, Point3D] = {}
    coordinate_owners: dict[Point3D, int] = {}
    for source_id, raw_point in source_node_coordinates.items():
        if isinstance(source_id, bool) or not isinstance(source_id, int):
            raise SharedSurfaceMeshingError("source node IDs must be integers")
        point = _point(raw_point, name=f"source node {source_id}")
        key = _coordinate_key(point)
        previous = coordinate_owners.get(key)
        if previous is not None:
            raise SharedSurfaceMeshingError(
                f"source nodes {previous} and {source_id} have duplicate coordinates"
            )
        coordinate_owners[key] = source_id
        coordinates[source_id] = point
    try:
        raw_regions = tuple(regions)
    except TypeError as error:
        raise SharedSurfaceMeshingError("regions must be a sequence") from error
    if not raw_regions:
        raise SharedSurfaceMeshingError("at least one planar region is required")
    if any(not isinstance(region, PlanarRegion) for region in raw_regions):
        raise SharedSurfaceMeshingError("regions must contain PlanarRegion values")
    labels = tuple(region.label.strip() for region in raw_regions)
    if len(set(labels)) != len(labels):
        raise SharedSurfaceMeshingError("planar region labels must be unique")
    unknown_locked = set(locked_facets_by_region).difference(labels)
    if unknown_locked:
        raise SharedSurfaceMeshingError(
            f"locked facets reference unknown region(s): {sorted(unknown_locked)}"
        )

    normalized_loops: list[tuple[str, tuple[int, ...], tuple[tuple[int, ...], ...], bool]] = []
    referenced: set[int] = set()
    for region, label in zip(raw_regions, labels):
        outer = _normalize_loop(region.outer_loop, name=f"region {label} outer loop")
        holes = tuple(
            _normalize_loop(loop, name=f"region {label} hole {index}")
            for index, loop in enumerate(region.holes)
        )
        for node in (*outer, *(node for loop in holes for node in loop)):
            if node not in coordinates:
                raise SharedSurfaceMeshingError(
                    f"region {label} references unknown source node {node}"
                )
            referenced.add(node)
        normalized_loops.append((label, outer, holes, region.recombine))

    frame = _infer_plane(coordinates, normalized_loops[0][1])
    prepared: list[_PreparedRegion] = []
    exact_edges: set[EdgeKey] = set()
    for label, outer, holes, recombine in normalized_loops:
        outer = _oriented_loop(
            outer, coordinates, frame, positive=True, name=f"region {label} outer loop"
        )
        holes = tuple(
            _oriented_loop(
                loop,
                coordinates,
                frame,
                positive=False,
                name=f"region {label} hole {index}",
            )
            for index, loop in enumerate(holes)
        )
        expected_area = abs(_signed_loop_area(outer, coordinates, frame)) - math.fsum(
            abs(_signed_loop_area(loop, coordinates, frame)) for loop in holes
        )
        if expected_area <= frame.tolerance_mm**2:
            raise SharedSurfaceMeshingError(f"region {label} has non-positive area")
        raw_facets = locked_facets_by_region.get(label, ())
        facets: list[tuple[int, ...]] = []
        for facet_index, value in enumerate(raw_facets):
            try:
                facet = tuple(value)
            except TypeError as error:
                raise SharedSurfaceMeshingError(
                    f"region {label} locked facet {facet_index} is invalid"
                ) from error
            if len(facet) not in {3, 4}:
                raise SharedSurfaceMeshingError(
                    f"region {label} locked facets must be TRI3/QUAD4"
                )
            if any(isinstance(node, bool) or not isinstance(node, int) for node in facet):
                raise SharedSurfaceMeshingError("locked facet node IDs must be integers")
            if len(set(facet)) != len(facet):
                raise SharedSurfaceMeshingError("locked facet contains repeated nodes")
            if any(node not in coordinates for node in facet):
                raise SharedSurfaceMeshingError("locked facet references an unknown node")
            if _facet_area(facet, coordinates) <= frame.tolerance_mm**2:
                raise SharedSurfaceMeshingError("locked facet has zero area")
            referenced.update(facet)
            facets.append(facet)
        if len({tuple(sorted(facet)) for facet in facets}) != len(facets):
            raise SharedSurfaceMeshingError("locked facets must be unique")
        if facets:
            boundary, _counts = _locked_patch_boundary_edges(facets)
            declared = set(_loop_edges(outer)).union(*(_loop_edges(loop) for loop in holes))
            if boundary != declared:
                raise SharedSurfaceMeshingError(
                    f"locked region {label} boundary differs from its declared loops"
                )
            actual_area = math.fsum(_facet_area(facet, coordinates) for facet in facets)
            if not math.isclose(
                actual_area,
                expected_area,
                rel_tol=1.0e-9,
                abs_tol=frame.tolerance_mm**2,
            ):
                raise SharedSurfaceMeshingError(
                    f"locked region {label} facets do not cover the declared region"
                )
            exact_edges.update(boundary)
        prepared.append(
            _PreparedRegion(
                label=label,
                outer_loop=outer,
                holes=holes,
                recombine=recombine,
                locked_facets=tuple(facets),
                expected_area_mm2=expected_area,
            )
        )

    declared_edges = {
        edge for region in prepared for loop in region.loops for edge in _loop_edges(loop)
    }
    for chain_index, value in enumerate(locked_boundary_chains):
        if not isinstance(value, LockedBoundaryChain):
            raise SharedSurfaceMeshingError(
                "locked boundary chains must contain LockedBoundaryChain values"
            )
        nodes = tuple(value.node_ids)
        minimum = 3 if value.closed else 2
        if len(nodes) < minimum or len(set(nodes)) != len(nodes):
            raise SharedSurfaceMeshingError(
                f"locked boundary chain {chain_index} is degenerate"
            )
        if any(node not in coordinates for node in nodes):
            raise SharedSurfaceMeshingError("locked boundary chain references an unknown node")
        referenced.update(nodes)
        pairs = list(zip(nodes, nodes[1:]))
        if value.closed:
            pairs.append((nodes[-1], nodes[0]))
        chain_edges = {_edge_key(first, second) for first, second in pairs}
        if not chain_edges.issubset(declared_edges):
            raise SharedSurfaceMeshingError(
                "locked boundary chain is not spelled by declared region edges"
            )
        exact_edges.update(chain_edges)

    if referenced != set(coordinates):
        unused = sorted(set(coordinates).difference(referenced))
        raise SharedSurfaceMeshingError(f"source coordinates contain unused node(s): {unused}")
    return MappingProxyType(coordinates), tuple(prepared), frame, exact_edges


@dataclass(frozen=True, slots=True)
class BoundarySizePolicy:
    """Blend actual locked-edge sizes, optionally via a free-region target."""

    target_edge_mm: float | None = None
    transition_distance_mm: float | None = None

    def __post_init__(self):
        for name in ("target_edge_mm", "transition_distance_mm"):
            value = getattr(self, name)
            if value is not None and (isinstance(value, bool) or not math.isfinite(value) or value <= 0):
                raise SharedSurfaceMeshingError(f"{name} must be finite and positive")


def _boundary_blend_expression(size_fields, nearest_field, policy, automatic_distance, epsilon):
    weights = [f"1/Max(F{tag},{epsilon:.17g})" for _, tag in size_fields]
    inherited = "(" + "+".join(f"{size:.17g}*({weight})" for (size, _), weight in zip(size_fields, weights)) + ")/(" + "+".join(weights) + ")"
    if policy.target_edge_mm is None:
        return inherited
    distance = policy.transition_distance_mm or automatic_distance
    blend = f"Min(1,F{nearest_field}/{distance:.17g})"
    return f"(1-({blend}))*({inherited})+({blend})*{policy.target_edge_mm:.17g}"


def _mesh_with_gmsh(
    gmsh: Any,
    coordinates: Mapping[int, Point3D],
    regions: Sequence[_PreparedRegion],
    exact_edges: set[EdgeKey],
    *,
    target_edge: float,
    near_edge: float,
    transition_distance: float,
    random_seed: int,
    verbose: bool,
    boundary_size_policy: BoundarySizePolicy | None = None,
) -> _RawMesh:
    edge_sizes = {edge: math.dist(coordinates[edge[0]], coordinates[edge[1]]) for edge in exact_edges}
    field_sizes = list(edge_sizes.values())
    if boundary_size_policy is not None and boundary_size_policy.target_edge_mm is not None:
        field_sizes.append(boundary_size_policy.target_edge_mm)
    blended = boundary_size_policy is not None and bool(edge_sizes)
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm": 6.0,
        "Mesh.MeshSizeMin": min(field_sizes) if blended else near_edge,
        "Mesh.MeshSizeMax": max(field_sizes) if blended else target_edge,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
        "Mesh.Optimize": 1.0,
        "Mesh.RandomSeed": float(random_seed),
        "Mesh.RecombineAll": 0.0,
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_gmsh_shared_surface",
        number_options=options,
    ):
        loop_nodes = {node for region in regions for loop in region.loops for node in loop}
        point_tag_by_source = {
            source_id: int(gmsh.model.geo.addPoint(*coordinates[source_id]))
            for source_id in sorted(loop_nodes)
        }
        curve_data: dict[EdgeKey, tuple[int, int, int]] = {}

        def signed_curve(first: int, second: int) -> int:
            key = _edge_key(first, second)
            value = curve_data.get(key)
            if value is None:
                tag = int(
                    gmsh.model.geo.addLine(
                        point_tag_by_source[first], point_tag_by_source[second]
                    )
                )
                curve_data[key] = (tag, first, second)
                return tag
            tag, start, end = value
            if (first, second) == (start, end):
                return tag
            if (first, second) == (end, start):
                return -tag
            raise SharedSurfaceMeshingError("inconsistent shared curve ownership")

        surface_by_region: dict[str, int] = {}
        for region in regions:
            loop_tags: list[int] = []
            for loop in region.loops:
                curves = [
                    signed_curve(first, second)
                    for first, second in zip(loop, (*loop[1:], loop[0]))
                ]
                loop_tags.append(int(gmsh.model.geo.addCurveLoop(curves)))
            if not region.locked_facets:
                surface_by_region[region.label] = int(
                    gmsh.model.geo.addPlaneSurface(loop_tags)
                )
        gmsh.model.geo.synchronize()

        curve_by_source_edge = {
            edge: data[0] for edge, data in curve_data.items()
        }
        for edge in sorted(exact_edges):
            gmsh.model.mesh.setTransfiniteCurve(curve_by_source_edge[edge], 2)
        for region in regions:
            surface_tag = surface_by_region.get(region.label)
            if surface_tag is not None and region.recombine:
                gmsh.model.mesh.setRecombine(2, surface_tag)

        exact_curves = sorted({curve_by_source_edge[edge] for edge in exact_edges})
        if blended:
            # Equal-size edges share a Distance field. Distances, rather than
            # edge counts, weight the sides so splitting a chain does not bias it.
            curves_by_size = {}
            for edge, size in edge_sizes.items():
                curves_by_size.setdefault(float(f"{size:.10g}"), []).append(curve_by_source_edge[edge])
            size_fields = []
            for size, curves in sorted(curves_by_size.items()):
                distance = int(gmsh.model.mesh.field.add("Distance"))
                gmsh.model.mesh.field.setNumbers(distance, "CurvesList", curves)
                gmsh.model.mesh.field.setNumber(distance, "Sampling", 100)
                size_fields.append((size, distance))
            nearest = int(gmsh.model.mesh.field.add("Min"))
            gmsh.model.mesh.field.setNumbers(nearest, "FieldsList", [tag for _, tag in size_fields])
            spans = [max(p[a] for p in coordinates.values()) - min(p[a] for p in coordinates.values()) for a in range(3)]
            scale = max(spans)
            automatic_distance = min(span for span in spans if span > scale * 1.e-10) / 4
            expression = _boundary_blend_expression(size_fields, nearest, boundary_size_policy,
                automatic_distance, max(scale * 1.e-12, 1.e-15))
            field = int(gmsh.model.mesh.field.add("MathEval"))
            gmsh.model.mesh.field.setString(field, "F", expression)
            gmsh.model.mesh.field.setAsBackgroundMesh(field)
            field_kind = ("BoundaryBlendViaTarget" if boundary_size_policy.target_edge_mm is not None else "BoundaryBlend")
        elif exact_curves and transition_distance > 0.0 and near_edge < target_edge:
            distance = int(gmsh.model.mesh.field.add("Distance"))
            gmsh.model.mesh.field.setNumbers(distance, "CurvesList", exact_curves)
            threshold = int(gmsh.model.mesh.field.add("Threshold"))
            for name, value in (
                ("InField", distance),
                ("SizeMin", near_edge),
                ("SizeMax", target_edge),
                ("DistMin", 0.0),
                ("DistMax", transition_distance),
            ):
                gmsh.model.mesh.field.setNumber(threshold, name, value)
            gmsh.model.mesh.field.setAsBackgroundMesh(threshold)
            field_kind = "Distance+Threshold"
        else:
            constant = int(gmsh.model.mesh.field.add("MathEval"))
            gmsh.model.mesh.field.setString(constant, "F", f"{target_edge:.17g}")
            gmsh.model.mesh.field.setAsBackgroundMesh(constant)
            field_kind = "MathEvalConstant"

        gmsh.model.mesh.generate(2)
        raw_tags, raw_coordinates, _ = gmsh.model.mesh.getNodes()
        gmsh_coordinates = {
            int(tag): (
                float(raw_coordinates[3 * index]),
                float(raw_coordinates[3 * index + 1]),
                float(raw_coordinates[3 * index + 2]),
            )
            for index, tag in enumerate(raw_tags)
        }
        if len(raw_coordinates) != 3 * len(raw_tags):
            raise SharedSurfaceMeshingError("Gmsh returned inconsistent node coordinates")

        generated_facets: list[_RawFacet] = []
        for region in regions:
            surface_tag = surface_by_region.get(region.label)
            if surface_tag is None:
                continue
            element_types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
                2, surface_tag
            )
            for raw_type, raw_element_tags, raw_connectivity in zip(
                element_types, tag_blocks, connectivity_blocks
            ):
                gmsh_type = int(raw_type)
                node_count = {_TRI3: 3, _QUAD4: 4}.get(gmsh_type)
                if node_count is None:
                    raise SharedSurfaceMeshingError(
                        f"Gmsh returned unsupported surface type {gmsh_type}"
                    )
                connectivity = tuple(int(node) for node in raw_connectivity)
                if len(connectivity) != node_count * len(raw_element_tags):
                    raise SharedSurfaceMeshingError(
                        "Gmsh returned inconsistent surface connectivity"
                    )
                qualities = tuple(
                    float(value)
                    for value in gmsh.model.mesh.getElementQualities(
                        [int(tag) for tag in raw_element_tags], "minSICN"
                    )
                )
                if len(qualities) != len(raw_element_tags):
                    raise SharedSurfaceMeshingError(
                        "Gmsh returned inconsistent surface quality values"
                    )
                for index, quality in enumerate(qualities):
                    start = index * node_count
                    generated_facets.append(
                        _RawFacet(
                            gmsh_type,
                            connectivity[start : start + node_count],
                            region.label,
                            quality,
                        )
                    )

        curve_edges: dict[int, tuple[EdgeKey, ...]] = {}
        for curve_tag, _start, _end in curve_data.values():
            element_types, _tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
                1, curve_tag
            )
            edges: list[EdgeKey] = []
            for raw_type, raw_connectivity in zip(element_types, connectivity_blocks):
                if int(raw_type) != 1:
                    raise SharedSurfaceMeshingError("Gmsh boundary curve is not LINE2")
                connectivity = tuple(int(node) for node in raw_connectivity)
                if len(connectivity) % 2:
                    raise SharedSurfaceMeshingError(
                        "Gmsh returned inconsistent curve connectivity"
                    )
                edges.extend(
                    _edge_key(connectivity[index], connectivity[index + 1])
                    for index in range(0, len(connectivity), 2)
                )
            if not edges:
                raise SharedSurfaceMeshingError("Gmsh left a region curve unmeshed")
            curve_edges[curve_tag] = tuple(edges)
        return _RawMesh(
            gmsh_coordinates=MappingProxyType(gmsh_coordinates),
            generated_facets=tuple(generated_facets),
            curve_edges=MappingProxyType(curve_edges),
            surface_by_region=MappingProxyType(surface_by_region),
            curve_by_source_edge=MappingProxyType(curve_by_source_edge),
            background_field_kind=field_kind,
            duplicate_node_count=len(tuple(gmsh.model.mesh.getDuplicateNodes())),
        )


def _finalize(
    raw: _RawMesh,
    coordinates: Mapping[int, Point3D],
    regions: Sequence[_PreparedRegion],
    *,
    frame: _PlaneFrame,
    target_edge: float,
    near_edge: float,
    transition_distance: float,
    minimum_quality: float,
    random_seed: int,
) -> GmshSharedSurface:
    if raw.duplicate_node_count:
        raise SharedSurfaceMeshingError("Gmsh produced duplicate planar nodes")
    gmsh_by_coordinate: dict[Point3D, int] = {}
    for gmsh_id, point in raw.gmsh_coordinates.items():
        key = _coordinate_key(point)
        if key in gmsh_by_coordinate:
            raise SharedSurfaceMeshingError("Gmsh produced coincident planar nodes")
        gmsh_by_coordinate[key] = gmsh_id
    source_by_coordinate = {_coordinate_key(point): source for source, point in coordinates.items()}
    source_by_gmsh = {
        gmsh_id: source_by_coordinate[key]
        for key, gmsh_id in gmsh_by_coordinate.items()
        if key in source_by_coordinate
    }
    represented_sources = set(source_by_gmsh.values())
    loop_sources = {node for region in regions for loop in region.loops for node in loop}
    if not loop_sources.issubset(represented_sources):
        missing = sorted(loop_sources.difference(represented_sources))
        raise SharedSurfaceMeshingError(
            f"Gmsh did not preserve declared boundary node(s): {missing}"
        )

    local_coordinates: dict[int, Point3D] = {}
    source_by_local: dict[int, int] = {}
    local_by_gmsh: dict[int, int] = {}
    local_by_source: dict[int, int] = {}
    next_local = 1
    for gmsh_id, point in sorted(
        raw.gmsh_coordinates.items(), key=lambda item: (_coordinate_key(item[1]), item[0])
    ):
        local_by_gmsh[gmsh_id] = next_local
        local_coordinates[next_local] = point
        source = source_by_gmsh.get(gmsh_id)
        if source is not None:
            source_by_local[next_local] = source
            local_by_source[source] = next_local
        next_local += 1
    for source in sorted(set(coordinates).difference(local_by_source)):
        local_by_source[source] = next_local
        local_coordinates[next_local] = coordinates[source]
        source_by_local[next_local] = source
        next_local += 1

    facets: list[SharedSurfaceFacet] = []
    raw_generated_quality: list[float] = []
    for raw_facet in raw.generated_facets:
        local_nodes = tuple(local_by_gmsh[node] for node in raw_facet.gmsh_nodes)
        if _signed_loop_area(local_nodes, local_coordinates, frame) < 0.0:
            local_nodes = tuple(reversed(local_nodes))
        facets.append(
            SharedSurfaceFacet(
                "TRI3" if raw_facet.gmsh_type == _TRI3 else "QUAD4",
                local_nodes,
                raw_facet.region_label,
                "gmsh_generated",
            )
        )
        raw_generated_quality.append(raw_facet.quality)
    for region in regions:
        for source_facet in region.locked_facets:
            local_nodes = tuple(local_by_source[node] for node in source_facet)
            if _signed_loop_area(local_nodes, local_coordinates, frame) < 0.0:
                local_nodes = tuple(reversed(local_nodes))
            facets.append(
                SharedSurfaceFacet(
                    "TRI3" if len(local_nodes) == 3 else "QUAD4",
                    local_nodes,
                    region.label,
                    "locked_source",
                )
            )
    if not facets:
        raise SharedSurfaceMeshingError("shared-surface mesh contains no facets")

    duplicate_facets = len(facets) - len(
        {(facet.region_label, tuple(sorted(facet.node_ids))) for facet in facets}
    )
    if duplicate_facets:
        raise SharedSurfaceMeshingError("shared-surface mesh contains duplicate facets")

    by_region: dict[str, list[SharedSurfaceFacet]] = {
        region.label: [] for region in regions
    }
    for facet in facets:
        by_region[facet.region_label].append(facet)
    region_area: dict[str, float] = {}
    region_boundary_sets: dict[str, set[EdgeKey]] = {}
    unmatched = 0
    for region in regions:
        region_facets = by_region[region.label]
        if not region_facets:
            raise SharedSurfaceMeshingError(f"region {region.label} contains no facets")
        edge_counts: Counter[EdgeKey] = Counter(
            _edge_key(first, second)
            for facet in region_facets
            for first, second in zip(
                facet.node_ids, (*facet.node_ids[1:], facet.node_ids[0])
            )
        )
        if any(count not in {1, 2} for count in edge_counts.values()):
            raise SharedSurfaceMeshingError(
                f"region {region.label} facet graph is non-manifold"
            )
        actual_boundary = {edge for edge, count in edge_counts.items() if count == 1}
        expected_boundary: set[EdgeKey] = set()
        for loop in region.loops:
            for source_edge in _loop_edges(loop):
                curve_tag = raw.curve_by_source_edge[source_edge]
                expected_boundary.update(
                    _edge_key(local_by_gmsh[first], local_by_gmsh[second])
                    for first, second in raw.curve_edges[curve_tag]
                )
        mismatch = actual_boundary.symmetric_difference(expected_boundary)
        unmatched += len(mismatch)
        if mismatch:
            raise SharedSurfaceMeshingError(
                f"region {region.label} boundary differs from its Gmsh curves"
            )
        region_boundary_sets[region.label] = actual_boundary
        area = math.fsum(
            _facet_area(facet.node_ids, local_coordinates) for facet in region_facets
        )
        region_area[region.label] = area
        if not math.isclose(
            area,
            region.expected_area_mm2,
            rel_tol=1.0e-8,
            abs_tol=frame.tolerance_mm**2,
        ):
            raise SharedSurfaceMeshingError(
                f"region {region.label} facet area differs from its geometry"
            )

    boundary_owners: dict[EdgeKey, set[str]] = defaultdict(set)
    for label, edges in region_boundary_sets.items():
        for edge in edges:
            boundary_owners[edge].add(label)
    nonmanifold = sum(len(owners) > 2 for owners in boundary_owners.values())
    if nonmanifold:
        raise SharedSurfaceMeshingError("more than two regions own one boundary edge")
    exterior = sum(len(owners) == 1 for owners in boundary_owners.values())
    shared = sum(len(owners) == 2 for owners in boundary_owners.values())

    computed_qualities = tuple(
        _facet_quality(facet.node_ids, local_coordinates) for facet in facets
    )
    all_qualities = (*raw_generated_quality, *computed_qualities)
    minimum = min(all_qualities, default=0.0)
    if not math.isfinite(minimum) or minimum < minimum_quality:
        raise SharedSurfaceMeshingError(
            f"shared-surface minimum quality {minimum:.6g} is below {minimum_quality:.6g}"
        )

    frozen_by_region = MappingProxyType(
        {
            label: tuple(sorted(values, key=lambda facet: (facet.kind, facet.node_ids)))
            for label, values in by_region.items()
        }
    )
    ordered_facets = tuple(
        facet
        for label in sorted(frozen_by_region)
        for facet in frozen_by_region[label]
    )
    return GmshSharedSurface(
        node_coordinates=MappingProxyType(local_coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        facets=ordered_facets,
        facets_by_region=frozen_by_region,
        region_area_mm2=MappingProxyType(region_area),
        target_edge_mm=target_edge,
        near_edge_mm=near_edge,
        transition_distance_mm=transition_distance,
        background_field_kind=raw.background_field_kind,
        generated_triangle_count=sum(
            facet.kind == "TRI3" and facet.provenance == "gmsh_generated"
            for facet in ordered_facets
        ),
        generated_quad_count=sum(
            facet.kind == "QUAD4" and facet.provenance == "gmsh_generated"
            for facet in ordered_facets
        ),
        locked_triangle_count=sum(
            facet.kind == "TRI3" and facet.provenance == "locked_source"
            for facet in ordered_facets
        ),
        locked_quad_count=sum(
            facet.kind == "QUAD4" and facet.provenance == "locked_source"
            for facet in ordered_facets
        ),
        exterior_boundary_edge_count=exterior,
        shared_interface_edge_count=shared,
        minimum_quality=minimum,
        duplicate_node_count=raw.duplicate_node_count,
        duplicate_facet_count=duplicate_facets,
        nonmanifold_edge_count=nonmanifold,
        unmatched_region_boundary_edge_count=unmatched,
        random_seed=random_seed,
    )


def generate_gmsh_shared_surface(
    source_node_coordinates: Mapping[int, Sequence[float]],
    regions: Sequence[PlanarRegion],
    *,
    locked_facets_by_region: Mapping[str, Sequence[Sequence[int]]] | None = None,
    locked_boundary_chains: Sequence[LockedBoundaryChain] = (),
    contact_partition_loops: Sequence[Sequence[Point3D]] = (),
    target_edge_mm: float,
    transition_distance_mm: float = 0.0,
    boundary_size_policy: BoundarySizePolicy | None = None,
    minimum_quality: float = 0.01,
    random_seed: int = 1,
    verbose: bool = False,
) -> GmshSharedSurface:
    """Mesh a labelled coplanar partition with Gmsh-owned connectivity.

    A region listed in ``locked_facets_by_region`` is immutable and is not
    remeshed.  Its declared loop must equal the exact boundary of the supplied
    TRI3/QUAD4 patch.  Every other region is meshed by Gmsh.  Shared loops use
    the same geometric curves and therefore the same result-local nodes.

    Exact locked chains are expressed using region-loop nodes.  A locked
    region's boundary is made exact automatically.  The transition field uses
    the median exact edge length near those curves and ``target_edge_mm`` away
    from them.
    """

    target = _finite(target_edge_mm, name="target_edge_mm")
    transition = _finite(
        transition_distance_mm, name="transition_distance_mm"
    )
    quality = _finite(minimum_quality, name="minimum_quality")
    if target <= 0.0:
        raise SharedSurfaceMeshingError("target_edge_mm must be positive")
    if transition < 0.0:
        raise SharedSurfaceMeshingError(
            "transition_distance_mm must be non-negative"
        )
    if quality < 0.0 or quality >= 1.0:
        raise SharedSurfaceMeshingError("minimum_quality must be in [0,1)")
    if isinstance(random_seed, bool) or not isinstance(random_seed, int):
        raise SharedSurfaceMeshingError("random_seed must be an integer")
    if not isinstance(verbose, bool):
        raise SharedSurfaceMeshingError("verbose must be boolean")
    locked = locked_facets_by_region or {}
    if not isinstance(locked, Mapping):
        raise SharedSurfaceMeshingError("locked_facets_by_region must be a mapping")
    if contact_partition_loops:
        from .gmsh_planar_contact_partition import partition_contact_regions
        source_node_coordinates, regions = partition_contact_regions(
            source_node_coordinates, regions, locked, contact_partition_loops,
        )
    coordinates, prepared, frame, exact_edges = _prepare(
        source_node_coordinates,
        regions,
        locked,
        locked_boundary_chains,
    )
    exact_lengths = tuple(
        math.dist(coordinates[first], coordinates[second])
        for first, second in exact_edges
    )
    near = min(target, median(exact_lengths)) if exact_lengths else target
    raw = _mesh_with_gmsh(
        _load_gmsh(),
        coordinates,
        prepared,
        exact_edges,
        target_edge=target,
        near_edge=near,
        transition_distance=transition,
        random_seed=random_seed,
        verbose=verbose,
        boundary_size_policy=boundary_size_policy,
    )
    return _finalize(
        raw,
        coordinates,
        prepared,
        frame=frame,
        target_edge=target,
        near_edge=near,
        transition_distance=transition,
        minimum_quality=quality,
        random_seed=random_seed,
    )


__all__ = [
    "GmshSharedSurface",
    "LockedBoundaryChain",
    "PlanarRegion",
    "SharedSurfaceFacet",
    "SharedSurfaceMeshingError",
    "generate_gmsh_shared_surface",
]
