"""Low-cost Package V2 geometry preview rendered by Qt Quick 3D.

The preview deliberately stops at the pure Package V2 compiler boundary.  It
draws semantic faces from the numeric canonical primitives through indexed
``QQuick3DGeometry`` buffers and the cross-platform Qt RHI depth pipeline.
The module never invokes Gmsh or scans mesh nodes/elements. Frozen sources
are represented by wire bounds obtained from bounded MSH header metadata
when possible, or by an explicitly labelled placement proxy when no trustworthy
bounds exist.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import partial
import hashlib
import json
import math
from pathlib import Path
import struct
from typing import Iterable, Mapping, Sequence, TypeAlias

from PySide6.QtCore import (
    QAbstractListModel,
    QByteArray,
    QModelIndex,
    QObject,
    QPointF,
    QSize,
    Qt,
    QUrl,
)
from PySide6.QtGui import (
    QAction,
    QColor,
    QMouseEvent,
    QVector3D,
    QWheelEvent,
)
from PySide6.QtQuick3D import QQuick3DGeometry
from PySide6.QtQuickWidgets import QQuickWidget
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QMenu,
    QPushButton,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .package_v2_geometry import (
    CanonicalBox,
    CanonicalDifference,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalRigidPlacement,
    CanonicalRoundedRectangleExtrusion,
    CanonicalUnion,
)
from .package_v2_local_templates import component_id, pose, resolve_scope


Vec3: TypeAlias = tuple[float, float, float]
Triangle: TypeAlias = tuple[Vec3, Vec3, Vec3]
Edge: TypeAlias = tuple[Vec3, Vec3]
Face: TypeAlias = tuple[Vec3, ...]

MAX_PREVIEW_COMPONENTS = 512
MAX_PREVIEW_TRIANGLES = 10_000
MAX_PREVIEW_GEOMETRY_WARNINGS = 100
MAX_PREVIEW_GEOMETRY_PAIR_CHECKS = 10_000
MAX_PREVIEW_GEOMETRY_PRIMITIVE_PAIR_CHECKS = 20_000
UNDERFILL_ADVISORY_VERTICAL_SLICES = 4
# Edges are a semantic geometry aid, not a display of the internal triangle
# tessellation. Twenty degrees keeps real Box/Frame corners and Underfill
# perimeter transitions while treating its rounded discretisation as smooth.
DEFAULT_CREASE_ANGLE_DEG = 20.0
_BOX_EDGE_INDICES = (
    (0, 1),
    (1, 2),
    (2, 3),
    (3, 0),
    (4, 5),
    (5, 6),
    (6, 7),
    (7, 4),
    (0, 4),
    (1, 5),
    (2, 6),
    (3, 7),
)
_BOX_FACE_INDICES = (
    (0, 3, 2, 1),
    (4, 5, 6, 7),
    (0, 1, 5, 4),
    (1, 2, 6, 5),
    (2, 3, 7, 6),
    (3, 0, 4, 7),
)


def generated_component_key(instance_id: str, component_id: str) -> str:
    """Return the stable public key used by tables and visibility controls."""

    return f"generated/{instance_id}/{component_id}"


def frozen_component_key(source_id: str, component_id: str) -> str:
    """Return the stable public key for one frozen source component."""

    return f"frozen/{source_id}/{component_id}"


def _finite_vec3(value: Sequence[object]) -> Vec3:
    if len(value) != 3:
        raise ValueError("a preview point must contain exactly three values")
    result = tuple(float(item) for item in value)
    if not all(math.isfinite(item) for item in result):
        raise ValueError("preview points must be finite")
    return result  # type: ignore[return-value]


def _add_triangle(output: list[Triangle], a: Vec3, b: Vec3, c: Vec3) -> None:
    first = _subtract(b, a)
    second = _subtract(c, a)
    scale = max(abs(value) for edge in (first, second) for value in edge)
    if not math.isfinite(scale) or scale <= 0.0:
        return
    relative_cross = _cross(
        tuple(value / scale for value in first),  # type: ignore[arg-type]
        tuple(value / scale for value in second),  # type: ignore[arg-type]
    )
    if _length(relative_cross) > 1.0e-14:
        output.append((a, b, c))


def _subtract(first: Vec3, second: Vec3) -> Vec3:
    return (
        first[0] - second[0],
        first[1] - second[1],
        first[2] - second[2],
    )


def _cross(first: Vec3, second: Vec3) -> Vec3:
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _dot(first: Vec3, second: Vec3) -> float:
    return sum(a * b for a, b in zip(first, second))


def _length(value: Vec3) -> float:
    return math.sqrt(_dot(value, value))


def _normalized(value: Vec3) -> Vec3:
    magnitude = _length(value)
    if magnitude <= 1.0e-15:
        return (0.0, 0.0, 1.0)
    return tuple(item / magnitude for item in value)  # type: ignore[return-value]


def _face_normal(face: Sequence[Vec3]) -> Vec3 | None:
    """Return a scale-independent normal for a 3+-vertex planar face."""

    if len(face) < 3:
        return None
    for index in range(1, len(face) - 1):
        first = _subtract(face[index], face[0])
        second = _subtract(face[index + 1], face[0])
        scale = max(abs(value) for edge in (first, second) for value in edge)
        if not math.isfinite(scale) or scale <= 0.0:
            continue
        relative_cross = _cross(
            tuple(value / scale for value in first),  # type: ignore[arg-type]
            tuple(value / scale for value in second),  # type: ignore[arg-type]
        )
        if _length(relative_cross) > 1.0e-14:
            return _normalized(relative_cross)
    return None


@dataclass(frozen=True, slots=True)
class PreviewBounds:
    minimum: Vec3
    maximum: Vec3

    def __post_init__(self) -> None:
        minimum = _finite_vec3(self.minimum)
        maximum = _finite_vec3(self.maximum)
        if any(high <= low for low, high in zip(minimum, maximum)):
            raise ValueError("preview bounds must have a positive extent")
        object.__setattr__(self, "minimum", minimum)
        object.__setattr__(self, "maximum", maximum)

    @property
    def center(self) -> Vec3:
        return tuple(  # type: ignore[return-value]
            (low + high) * 0.5
            for low, high in zip(self.minimum, self.maximum)
        )

    @property
    def diagonal(self) -> float:
        return math.dist(self.minimum, self.maximum)

    @property
    def corners(self) -> tuple[Vec3, ...]:
        x0, y0, z0 = self.minimum
        x1, y1, z1 = self.maximum
        return (
            (x0, y0, z0),
            (x1, y0, z0),
            (x1, y1, z0),
            (x0, y1, z0),
            (x0, y0, z1),
            (x1, y0, z1),
            (x1, y1, z1),
            (x0, y1, z1),
        )


@dataclass(frozen=True, slots=True)
class PreviewEdgeAdjacency:
    """One undirected fill edge and the faces incident to it.

    Triangle indices/normals are cached at scene-build time so the painter can
    select only view-visible silhouettes and real creases. The triangle fill
    tessellation itself is never treated as model structure.
    """

    edge: Edge
    triangle_indices: tuple[int, ...]
    incident_normals: tuple[Vec3, ...]
    semantic_face_indices: tuple[int, ...] = ()

    @property
    def maximum_dihedral_angle_deg(self) -> float:
        if len(self.incident_normals) < 2:
            return 180.0
        maximum = 0.0
        for first_index, first in enumerate(self.incident_normals[:-1]):
            for second in self.incident_normals[first_index + 1 :]:
                cosine = max(-1.0, min(1.0, abs(_dot(first, second))))
                maximum = max(maximum, math.degrees(math.acos(cosine)))
        return maximum

    def is_crease(self, crease_angle_deg: float = DEFAULT_CREASE_ANGLE_DEG) -> bool:
        return (
            len(self.incident_normals) == 1
            or self.maximum_dihedral_angle_deg + 1.0e-9 >= crease_angle_deg
        )


@dataclass(frozen=True, slots=True)
class PreviewComponent:
    key: str
    label: str
    owner_id: str
    component_id: str
    material_name: str | None
    triangles: tuple[Triangle, ...]
    fill_faces: tuple[Face, ...] = ()
    surface_edges: tuple[Edge, ...] = ()
    edge_adjacency: tuple[PreviewEdgeAdjacency, ...] = ()
    wire_corners: tuple[Vec3, ...] = ()
    placement_axes: tuple[Edge, ...] = ()
    frozen: bool = False
    bounds_known: bool = True

    @property
    def points(self) -> tuple[Vec3, ...]:
        if self.wire_corners:
            return self.wire_corners
        return tuple(point for triangle in self.triangles for point in triangle)

    @property
    def center(self) -> Vec3:
        points = self.points
        if not points:
            return (0.0, 0.0, 0.0)
        return tuple(  # type: ignore[return-value]
            (min(point[index] for point in points) + max(point[index] for point in points))
            * 0.5
            for index in range(3)
        )


@dataclass(frozen=True, slots=True)
class PreviewInterface:
    frozen_key: str
    generated_key: str
    mode: str


@dataclass(frozen=True, slots=True)
class PreviewGeometryWarning:
    """One structured, non-blocking geometry diagnostic for the preview.

    ``exact`` distinguishes a complete primitive-level result from a
    conservative advisory. Box and rectangular Frame results use exact Box
    partitions. Underfill advisories use only inscribed straight-side boxes,
    so they never treat the hollow die area or rounded-corner outer bound as
    solid, but may intentionally miss overlap near the curved/tapered surface.
    """

    code: str
    message: str
    component_keys: tuple[str, str]
    component_labels: tuple[str, str]
    minimum_axis_overlap_mm: float
    exact: bool = True


@dataclass(frozen=True, slots=True)
class PreviewLocalFrame:
    """One public instance's frame, before its template is expanded into solids."""

    instance_id: str
    component_key: str
    origin: Vec3
    axes: tuple[Vec3, Vec3, Vec3]


@dataclass(frozen=True, slots=True)
class PreviewScene:
    components: tuple[PreviewComponent, ...] = ()
    interfaces: tuple[PreviewInterface, ...] = ()
    plan_digest: str = ""
    warnings: tuple[str, ...] = ()
    geometry_warnings: tuple[PreviewGeometryWarning, ...] = ()
    geometry_warning_scan_truncated: bool = False
    local_frames: tuple[PreviewLocalFrame, ...] = ()

    @property
    def component_keys(self) -> tuple[str, ...]:
        return tuple(component.key for component in self.components)

    @property
    def triangle_count(self) -> int:
        return sum(len(component.triangles) for component in self.components)

    @property
    def fill_face_count(self) -> int:
        return sum(len(component.fill_faces) for component in self.components)

    @property
    def generated_count(self) -> int:
        return sum(not component.frozen for component in self.components)

    @property
    def frozen_count(self) -> int:
        return sum(component.frozen for component in self.components)

    @property
    def component_by_key(self) -> Mapping[str, PreviewComponent]:
        return {component.key: component for component in self.components}

    @property
    def frozen_components_by_source(
        self,
    ) -> Mapping[str, tuple[PreviewComponent, ...]]:
        """Group Frozen component keys around their shared source geometry.

        Header bounds describe the union of selected physical Components.
        Keeping this grouping on the scene lets the UI
        retain per-Component visibility keys while the canvas paints the
        source-level bounds only once.
        """

        grouped: dict[str, list[PreviewComponent]] = {}
        for component in self.components:
            if component.frozen:
                grouped.setdefault(component.owner_id, []).append(component)
        return {
            source_id: tuple(components)
            for source_id, components in grouped.items()
        }

    def visible_frozen_components_by_source(
        self,
        visible_keys: Iterable[str],
    ) -> Mapping[str, tuple[PreviewComponent, ...]]:
        """Return only sources having at least one visible Component key."""

        visible = frozenset(visible_keys)
        return {
            source_id: visible_components
            for source_id, source_components in self.frozen_components_by_source.items()
            if (
                visible_components := tuple(
                    component
                    for component in source_components
                    if component.key in visible
                )
            )
        }

    def highlighted_frozen_sources(
        self,
        highlighted_keys: Iterable[str],
    ) -> frozenset[str]:
        """Map any highlighted Frozen Component to its shared source box."""

        highlighted = frozenset(highlighted_keys)
        return frozenset(
            source_id
            for source_id, components in self.frozen_components_by_source.items()
            if any(component.key in highlighted for component in components)
        )


def material_color(material: str) -> QColor:
    """Return a deterministic, process-independent categorical material color."""

    known = {
        "al": "#aeb8c4",
        "aluminum": "#aeb8c4",
        "aluminium": "#aeb8c4",
        "cu": "#d77b3f",
        "copper": "#d77b3f",
        "si": "#6f8fa8",
        "sbt": "#4f9d69",
        "sr1": "#9a7ec2",
        "pi": "#e4aa3a",
        "302": "#d98657",
        "epoxy": "#bc6ca7",
    }
    key = material.strip().casefold()
    if key in known:
        return QColor(known[key])
    digest = hashlib.sha256(key.encode("utf-8")).digest()
    hue = int.from_bytes(digest[:2], "big") % 360
    saturation = 135 + digest[2] % 65
    value = 180 + digest[3] % 55
    return QColor.fromHsv(hue, saturation, value)


def _edge_key(first: Vec3, second: Vec3) -> tuple[Vec3, Vec3]:
    """Return an exact undirected key for canonical shared vertices."""

    return tuple(sorted((first, second)))  # type: ignore[return-value]


def build_edge_adjacency(
    triangles: Iterable[Triangle],
    semantic_faces: Iterable[Face] = (),
) -> tuple[PreviewEdgeAdjacency, ...]:
    """Cache topology and face normals for a triangle-filled primitive."""

    triangle_tuple = tuple(triangles)
    face_edges: dict[tuple[Vec3, Vec3], list[int]] = {}
    for face_index, face in enumerate(semantic_faces):
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            face_edges.setdefault(_edge_key(first, second), []).append(face_index)
    records: dict[
        tuple[Vec3, Vec3],
        tuple[Edge, list[int], list[Vec3]],
    ] = {}
    for triangle_index, triangle in enumerate(triangle_tuple):
        normal = _normalized(
            _cross(
                _subtract(triangle[1], triangle[0]),
                _subtract(triangle[2], triangle[0]),
            )
        )
        for first, second in (
            (triangle[0], triangle[1]),
            (triangle[1], triangle[2]),
            (triangle[2], triangle[0]),
        ):
            key = _edge_key(first, second)
            if key not in records:
                records[key] = ((first, second), [triangle_index], [normal])
            else:
                records[key][1].append(triangle_index)
                records[key][2].append(normal)
    return tuple(
        PreviewEdgeAdjacency(
            edge,
            tuple(indices),
            tuple(normals),
            tuple(face_edges.get(_edge_key(*edge), ())),
        )
        for edge, indices, normals in records.values()
    )


def feature_edges(
    triangles: Iterable[Triangle],
    *,
    crease_angle_deg: float = DEFAULT_CREASE_ANGLE_DEG,
) -> tuple[Edge, ...]:
    """Return primitive boundaries/creases, never triangle fill diagonals."""

    if not 0.0 <= crease_angle_deg <= 180.0:
        raise ValueError("crease_angle_deg must be between 0 and 180")
    return tuple(
        adjacency.edge
        for adjacency in build_edge_adjacency(triangles)
        if adjacency.is_crease(crease_angle_deg)
    )


def visible_feature_edges(
    edge_adjacency: Iterable[PreviewEdgeAdjacency],
    front_facing_triangles: Sequence[bool],
    *,
    crease_angle_deg: float = DEFAULT_CREASE_ANGLE_DEG,
) -> tuple[Edge, ...]:
    """Select camera-visible outlines/creases and omit hidden back edges."""

    output: list[Edge] = []
    for adjacency in edge_adjacency:
        incident_front = tuple(
            front_facing_triangles[index]
            for index in adjacency.triangle_indices
            if 0 <= index < len(front_facing_triangles)
        )
        if not incident_front or not any(incident_front):
            continue
        # A smooth shared edge is visible only at the silhouette between a
        # front and back facet. A true crease is visible from its front side.
        if not all(incident_front) or adjacency.is_crease(crease_angle_deg):
            output.append(adjacency.edge)
    return tuple(output)


def _clean_face(points: Iterable[Vec3]) -> Face:
    """Remove degenerate duplicate vertices from one semantic surface patch."""

    output: list[Vec3] = []
    for point in points:
        if not output or point != output[-1]:
            output.append(point)
    if len(output) > 1 and output[0] == output[-1]:
        output.pop()
    return tuple(output) if len(output) >= 3 else ()


def _triangles_from_faces(faces: Iterable[Face]) -> tuple[Triangle, ...]:
    """Triangulate semantic faces only for budgeting/topology, never for strokes."""

    output: list[Triangle] = []
    for face in faces:
        for index in range(1, len(face) - 1):
            _add_triangle(output, face[0], face[index], face[index + 1])
    return tuple(output)


def _box_faces(origin: Vec3, size: Vec3) -> tuple[Face, ...]:
    x0, y0, z0 = origin
    dx, dy, dz = size
    corners = PreviewBounds(origin, (x0 + dx, y0 + dy, z0 + dz)).corners
    return tuple(
        tuple(corners[index] for index in indices)
        for indices in _BOX_FACE_INDICES
    )


def _frame_faces(
    value: CanonicalRectangularFrameExtrusion,
) -> tuple[Face, ...]:
    x0, y0, z0 = value.outer_origin_xyz_mm
    sx, sy = value.outer_size_xy_mm
    ox, oy = value.opening_offset_xy_mm
    ix, iy = value.opening_size_xy_mm
    z1 = z0 + value.height_mm
    outer_xy = ((x0, y0), (x0 + sx, y0), (x0 + sx, y0 + sy), (x0, y0 + sy))
    inner_xy = (
        (x0 + ox, y0 + oy),
        (x0 + ox + ix, y0 + oy),
        (x0 + ox + ix, y0 + oy + iy),
        (x0 + ox, y0 + oy + iy),
    )
    outer_bottom = tuple((x, y, z0) for x, y in outer_xy)
    outer_top = tuple((x, y, z1) for x, y in outer_xy)
    inner_bottom = tuple((x, y, z0) for x, y in inner_xy)
    inner_top = tuple((x, y, z1) for x, y in inner_xy)
    output: list[Face] = []
    for index in range(4):
        nxt = (index + 1) % 4
        output.extend(
            (
                (
                    outer_bottom[index],
                    outer_bottom[nxt],
                    outer_top[nxt],
                    outer_top[index],
                ),
                (
                    inner_bottom[nxt],
                    inner_bottom[index],
                    inner_top[index],
                    inner_top[nxt],
                ),
                (
                    outer_top[index],
                    outer_top[nxt],
                    inner_top[nxt],
                    inner_top[index],
                ),
                (
                    outer_bottom[nxt],
                    outer_bottom[index],
                    inner_bottom[index],
                    inner_bottom[nxt],
                ),
            )
        )
    return tuple(output)


def _rounded_rectangle_contour(
    origin_xy: tuple[float, float],
    size_xy: tuple[float, float],
    radius: float,
    *,
    segments_per_corner: int = 8,
) -> tuple[tuple[float, float], ...]:
    x0, y0 = origin_xy
    sx, sy = size_xy
    if radius <= 1.0e-15:
        return ((x0, y0), (x0 + sx, y0), (x0 + sx, y0 + sy), (x0, y0 + sy))
    centers = (
        (x0 + sx - radius, y0 + radius, -90.0),
        (x0 + sx - radius, y0 + sy - radius, 0.0),
        (x0 + radius, y0 + sy - radius, 90.0),
        (x0 + radius, y0 + radius, 180.0),
    )
    points: list[tuple[float, float]] = []
    for cx, cy, start_deg in centers:
        for step in range(segments_per_corner + 1):
            angle = math.radians(start_deg + 90.0 * step / segments_per_corner)
            points.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
    return tuple(points)


def _rounded_extrusion_faces(
    value: CanonicalRoundedRectangleExtrusion,
) -> tuple[Face, ...]:
    x0, y0, z0 = value.origin_xyz_mm
    contour = _rounded_rectangle_contour(
        (x0, y0),
        value.size_xy_mm,
        value.corner_radius_mm,
    )
    z1 = z0 + value.height_mm
    bottom = tuple((x, y, z0) for x, y in contour)
    top = tuple((x, y, z1) for x, y in contour)
    output: list[Face] = [top, tuple(reversed(bottom))]
    for index in range(len(contour)):
        nxt = (index + 1) % len(contour)
        output.append((bottom[index], bottom[nxt], top[nxt], top[index]))
    return tuple(output)


def _underfill_pairs(
    value: CanonicalRectangularUnderfillFillet,
    *,
    top: bool = False,
    segments_per_corner: int = 8,
) -> tuple[tuple[tuple[float, float], tuple[float, float]], ...]:
    x0, y0 = value.die_origin_xy_mm
    sx, sy = value.die_size_xy_mm
    x1, y1 = x0 + sx, y0 + sy
    from .package_v2_swept_fillet import widths_at
    widths = widths_at(value, 1. if top else 0.)
    toe = max(widths)
    if toe == 0:
        return ()
    pairs: list[tuple[tuple[float, float], tuple[float, float]]] = []

    def add(outer: tuple[float, float], inner: tuple[float, float]) -> None:
        if pairs and math.dist(pairs[-1][0], outer) <= 1.0e-15:
            pairs[-1] = (outer, inner)
        else:
            pairs.append((outer, inner))

    add((x0, y0 - toe), (x0, y0))
    add((x1, y0 - toe), (x1, y0))
    arcs = (
        ((x1, y0), -90.0, (x1, y0), (x1 + toe, y1), (x1, y1)),
        ((x1, y1), 0.0, (x1, y1), (x0, y1 + toe), (x0, y1)),
        ((x0, y1), 90.0, (x0, y1), (x0 - toe, y0), (x0, y0)),
        ((x0, y0), 180.0, (x0, y0), (x0, y0 - toe), (x0, y0)),
    )
    for arc_index, (center, start_deg, inner, next_outer, next_inner) in enumerate(arcs):
        cx, cy = center
        for step in range(1, segments_per_corner + 1):
            angle = math.radians(start_deg + 90.0 * step / segments_per_corner)
            add((cx + toe * math.cos(angle), cy + toe * math.sin(angle)), inner)
        if arc_index < len(arcs) - 1:
            add(next_outer, next_inner)
    if len(pairs) > 1 and math.dist(pairs[0][0], pairs[-1][0]) <= 1.0e-15:
        pairs.pop()
    if value.uses_elliptical_sweep:
        xm, xp, ym, yp = widths
        pairs = [((inner[0] + (outer[0]-inner[0])*(xm if outer[0] < inner[0] else xp)/toe,
                   inner[1] + (outer[1]-inner[1])*(ym if outer[1] < inner[1] else yp)/toe), inner)
                 for outer, inner in pairs]
    return tuple(pairs)


def _underfill_faces(
    value: CanonicalRectangularUnderfillFillet,
) -> tuple[Face, ...]:
    z0 = value.base_z_mm
    z1 = z0 + value.wall_height_mm
    bottom_pairs = _underfill_pairs(value)
    from .package_v2_swept_fillet import widths_at
    if max(widths_at(value, 1.)) == 0.0:
        output: list[Face] = []
        for index, (outer_xy, inner_xy) in enumerate(bottom_pairs):
            next_outer_xy, next_inner_xy = bottom_pairs[
                (index + 1) % len(bottom_pairs)
            ]
            outer = (*outer_xy, z0)
            next_outer = (*next_outer_xy, z0)
            inner_bottom = (*inner_xy, z0)
            next_inner_bottom = (*next_inner_xy, z0)
            inner_top = (*inner_xy, z1)
            next_inner_top = (*next_inner_xy, z1)
            for face in (
                (inner_bottom, inner_top, next_inner_top, next_inner_bottom),
                (inner_top, outer, next_outer, next_inner_top),
                (inner_bottom, next_inner_bottom, next_outer, outer),
            ):
                if cleaned := _clean_face(face):
                    output.append(cleaned)
        return tuple(output)
    top_pairs = (
        _underfill_pairs(value, top=True)
    )
    if len(bottom_pairs) != len(top_pairs):
        return ()
    output: list[Face] = []
    for index, ((bottom_outer_xy, inner_xy), (top_outer_xy, _)) in enumerate(
        zip(bottom_pairs, top_pairs)
    ):
        next_index = (index + 1) % len(bottom_pairs)
        next_bottom_outer_xy, next_inner_xy = bottom_pairs[next_index]
        next_top_outer_xy, _ = top_pairs[next_index]
        bottom_outer = (*bottom_outer_xy, z0)
        next_bottom_outer = (*next_bottom_outer_xy, z0)
        top_outer = (*top_outer_xy, z1)
        next_top_outer = (*next_top_outer_xy, z1)
        inner_bottom = (*inner_xy, z0)
        next_inner_bottom = (*next_inner_xy, z0)
        inner_top = (*inner_xy, z1)
        next_inner_top = (*next_inner_xy, z1)
        for face in (
            (inner_bottom, inner_top, next_inner_top, next_inner_bottom),
            (bottom_outer, next_bottom_outer, next_top_outer, top_outer),
            (inner_bottom, next_inner_bottom, next_bottom_outer, bottom_outer),
            (inner_top, top_outer, next_top_outer, next_inner_top),
        ):
            if cleaned := _clean_face(face):
                output.append(cleaned)
    return tuple(output)


def _node_faces(root: object, warnings: list[str]) -> tuple[Face, ...]:
    if type(root) is CanonicalBox:
        return _box_faces(root.origin_xyz_mm, root.size_xyz_mm)
    if type(root) is CanonicalRectangularFrameExtrusion:
        return _frame_faces(root)
    if type(root) is CanonicalRectangularUnderfillFillet:
        return _underfill_faces(root)
    if type(root) is CanonicalRoundedRectangleExtrusion:
        return _rounded_extrusion_faces(root)
    if type(root) in {CanonicalUnion, CanonicalDifference}:
        from .package_v2_orthogonal_domain_planning import (
            root_boundary_rectangles,
            OrthogonalConstraintError,
        )

        try:
            rectangles = root_boundary_rectangles(root)
        except OrthogonalConstraintError:
            warnings.append("非正交 CSG 的轻量预览仅显示输入外形。")
            children = root.children if type(root) is CanonicalUnion else (root.base,)
            return tuple(
                face for child in children for face in _node_faces(child, warnings)
            )
        faces = []
        for side, axis, end, bounds in rectangles:
            u, v = [a for a in range(3) if a != axis]
            points = []
            for du, dv in ((0, 0), (1, 0), (1, 1), (0, 1)):
                point = [b[0] for b in bounds]
                point[u], point[v] = bounds[u][du], bounds[v][dv]
                points.append(tuple(point))
            if (1 if axis != 1 else -1) != (1 if end else -1):
                points.reverse()
            faces.append(tuple(points))
        return tuple(faces)
    warnings.append(f"不支持的 canonical geometry：{type(root).__name__}")
    return ()


def _rotate_xyz(point: Vec3, rotation_deg_xyz: Vec3) -> Vec3:
    x, y, z = point
    rx, ry, rz = (math.radians(value) for value in rotation_deg_xyz)
    cosine, sine = math.cos(rx), math.sin(rx)
    y, z = cosine * y - sine * z, sine * y + cosine * z
    cosine, sine = math.cos(ry), math.sin(ry)
    x, z = cosine * x + sine * z, -sine * x + cosine * z
    cosine, sine = math.cos(rz), math.sin(rz)
    x, y = cosine * x - sine * y, sine * x + cosine * y
    return (x, y, z)


def transform_generated_point(point: Vec3, placement: CanonicalRigidPlacement) -> Vec3:
    """Apply the compiler-defined ``T + P + Rz Ry Rx (point - P)`` transform."""

    relative = _subtract(point, placement.pivot_xyz_mm)
    rotated = _rotate_xyz(relative, placement.rotation_deg_xyz)
    return tuple(  # type: ignore[return-value]
        rotated[index]
        + placement.pivot_xyz_mm[index]
        + placement.translation_xyz_mm[index]
        for index in range(3)
    )


@dataclass(frozen=True, slots=True)
class _PreviewOrientedBox:
    component_key: str
    component_label: str
    center: Vec3
    axes: tuple[Vec3, Vec3, Vec3]
    half_extents: Vec3
    exact: bool = True


def _preview_oriented_box(
    box: CanonicalBox,
    placement: CanonicalRigidPlacement,
    *,
    component_key: str,
    component_label: str,
    exact: bool = True,
) -> _PreviewOrientedBox:
    local_center = tuple(
        origin + size * 0.5
        for origin, size in zip(box.origin_xyz_mm, box.size_xyz_mm)
    )
    axes = tuple(
        _normalized(_rotate_xyz(axis, placement.rotation_deg_xyz))
        for axis in (
            (1.0, 0.0, 0.0),
            (0.0, 1.0, 0.0),
            (0.0, 0.0, 1.0),
        )
    )
    return _PreviewOrientedBox(
        component_key,
        component_label,
        transform_generated_point(local_center, placement),  # type: ignore[arg-type]
        axes,  # type: ignore[arg-type]
        tuple(size * 0.5 for size in box.size_xyz_mm),  # type: ignore[arg-type]
        exact,
    )


def _exact_box_partition(root: object) -> tuple[CanonicalBox, ...]:
    """Return an exact disjoint Box partition for supported rectilinear solids."""

    if type(root) is CanonicalBox:
        return (root,)
    if type(root) is not CanonicalRectangularFrameExtrusion:
        return ()
    x0, y0, z0 = root.outer_origin_xyz_mm
    sx, sy = root.outer_size_xy_mm
    ox, oy = root.opening_offset_xy_mm
    ix, iy = root.opening_size_xy_mm
    height = root.height_mm
    # Bottom/top span the full X width.  Left/right occupy only the opening's
    # Y interval, making the four rail interiors disjoint while covering the
    # complete Frame solid exactly.
    return (
        CanonicalBox((x0, y0, z0), (sx, oy, height)),
        CanonicalBox(
            (x0, y0 + oy + iy, z0),
            (sx, sy - oy - iy, height),
        ),
        CanonicalBox((x0, y0 + oy, z0), (ox, iy, height)),
        CanonicalBox(
            (x0 + ox + ix, y0 + oy, z0),
            (sx - ox - ix, iy, height),
        ),
    )


def _underfill_advisory_box_partition(
    root: object,
) -> tuple[CanonicalBox, ...]:
    """Return conservative boxes wholly contained by one Underfill solid.

    The canonical Underfill width decreases linearly from ``toe_width`` to
    ``top_width``. Each height slice therefore uses its narrower upper width.
    Four straight-side rails are guaranteed to be inside the solid; rounded
    corners and the final zero-width apex are deliberately omitted. This is a
    one-sided witness for a low-cost advisory, not an exact solid partition.
    """

    if type(root) is not CanonicalRectangularUnderfillFillet:
        return ()
    x0, y0 = root.die_origin_xy_mm
    sx, sy = root.die_size_xy_mm
    z0 = root.base_z_mm
    height = root.wall_height_mm
    output: list[CanonicalBox] = []
    for slice_index in range(UNDERFILL_ADVISORY_VERTICAL_SLICES):
        lower_fraction = slice_index / UNDERFILL_ADVISORY_VERTICAL_SLICES
        upper_fraction = (slice_index + 1) / UNDERFILL_ADVISORY_VERTICAL_SLICES
        from .package_v2_swept_fillet import widths_at
        width = min(*widths_at(root, lower_fraction), *widths_at(root, upper_fraction))
        if width <= 0.0:
            # A zero top width produces a true apex. No positive-volume Box
            # can cover the final complete slice without leaving the solid.
            continue
        slice_z = z0 + height * lower_fraction
        slice_height = height / UNDERFILL_ADVISORY_VERTICAL_SLICES
        output.extend(
            (
                CanonicalBox((x0, y0 - width, slice_z), (sx, width, slice_height)),
                CanonicalBox((x0, y0 + sy, slice_z), (sx, width, slice_height)),
                CanonicalBox((x0 - width, y0, slice_z), (width, sy, slice_height)),
                CanonicalBox((x0 + sx, y0, slice_z), (width, sy, slice_height)),
            )
        )
    return tuple(output)


def _positive_oriented_box_overlap_mm(
    first: _PreviewOrientedBox,
    second: _PreviewOrientedBox,
) -> float | None:
    """Return a SAT overlap witness, excluding touching within roundoff.

    The fifteen face/cross-product axes are complete for two oriented boxes.
    Face axes are normalised. Cross-product axes deliberately are not: keeping
    even a very short, non-zero cross axis avoids treating extremely long,
    almost-parallel boxes as intersecting when that axis still separates them.
    The returned witness is normalised back to millimetres.
    """

    candidate_axes: list[Vec3] = [*first.axes, *second.axes]
    for first_axis in first.axes:
        for second_axis in second.axes:
            axis = _cross(first_axis, second_axis)
            if axis != (0.0, 0.0, 0.0):
                candidate_axes.append(axis)

    delta = _subtract(second.center, first.center)
    minimum_overlap = math.inf
    coordinate_scale = max(
        1.0,
        *(abs(value) for value in first.center),
        *(abs(value) for value in second.center),
        *first.half_extents,
        *second.half_extents,
    )
    roundoff_floor = max(1.0e-12, 64.0 * math.ulp(coordinate_scale))
    for axis in candidate_axes:
        axis_length = math.hypot(*axis)
        if axis_length == 0.0:
            # A non-zero vector whose norm underflowed cannot safely prove an
            # intersection. Suppress the advisory instead of a false exact
            # warning; a final OCC job remains authoritative.
            if axis != (0.0, 0.0, 0.0):
                return None
            continue
        first_radius = sum(
            extent * abs(_dot(local_axis, axis))
            for extent, local_axis in zip(first.half_extents, first.axes)
        )
        second_radius = sum(
            extent * abs(_dot(local_axis, axis))
            for extent, local_axis in zip(second.half_extents, second.axes)
        )
        radius_sum = first_radius + second_radius
        overlap = radius_sum - abs(_dot(delta, axis))
        tolerance = max(
            roundoff_floor * max(abs(value) for value in axis),
            radius_sum * 1.0e-12,
        )
        if overlap <= tolerance:
            return None
        minimum_overlap = min(minimum_overlap, overlap / axis_length)

    return minimum_overlap if math.isfinite(minimum_overlap) else None


@dataclass(frozen=True, slots=True)
class _PreviewBoxComponent:
    key: str
    label: str
    boxes: tuple[_PreviewOrientedBox, ...]
    minimum: Vec3
    maximum: Vec3


def _oriented_box_world_bounds(box: _PreviewOrientedBox) -> tuple[Vec3, Vec3]:
    radii = tuple(
        sum(
            extent * abs(axis[dimension])
            for extent, axis in zip(box.half_extents, box.axes)
        )
        for dimension in range(3)
    )
    return (
        tuple(box.center[index] - radii[index] for index in range(3)),
        tuple(box.center[index] + radii[index] for index in range(3)),
    )  # type: ignore[return-value]


def _box_components(
    boxes: Sequence[_PreviewOrientedBox],
) -> tuple[_PreviewBoxComponent, ...]:
    grouped: dict[str, list[_PreviewOrientedBox]] = {}
    for box in boxes:
        grouped.setdefault(box.component_key, []).append(box)
    output: list[_PreviewBoxComponent] = []
    for key, component_boxes in grouped.items():
        bounds = tuple(_oriented_box_world_bounds(box) for box in component_boxes)
        output.append(
            _PreviewBoxComponent(
                key=key,
                label=component_boxes[0].component_label,
                boxes=tuple(component_boxes),
                minimum=tuple(
                    min(bound[0][axis] for bound in bounds) for axis in range(3)
                ),  # type: ignore[arg-type]
                maximum=tuple(
                    max(bound[1][axis] for bound in bounds) for axis in range(3)
                ),  # type: ignore[arg-type]
            )
        )
    return tuple(sorted(output, key=lambda value: (value.minimum[0], value.key)))


def _generated_box_overlap_warnings(
    boxes: Sequence[_PreviewOrientedBox],
) -> tuple[tuple[PreviewGeometryWarning, ...], bool]:
    """Return bounded exact/advisory warnings and scan truncation state."""

    overlaps: dict[
        tuple[str, str],
        tuple[tuple[str, str], float, bool],
    ] = {}
    pair_checks = 0
    primitive_pair_checks = 0
    components = _box_components(boxes)
    box_bounds = {
        id(box): _oriented_box_world_bounds(box)
        for component in components
        for box in component.boxes
    }
    truncated = False
    for first_index, first in enumerate(components):
        for second in components[first_index + 1 :]:
            if second.minimum[0] >= first.maximum[0]:
                break
            if any(
                first.maximum[axis] <= second.minimum[axis]
                or second.maximum[axis] <= first.minimum[axis]
                for axis in (1, 2)
            ):
                continue
            pair_checks += 1
            if pair_checks > MAX_PREVIEW_GEOMETRY_PAIR_CHECKS:
                truncated = True
                break
            overlap: tuple[float, bool] | None = None
            for first_box in first.boxes:
                for second_box in second.boxes:
                    first_bounds = box_bounds[id(first_box)]
                    second_bounds = box_bounds[id(second_box)]
                    if any(
                        first_bounds[1][axis] <= second_bounds[0][axis]
                        or second_bounds[1][axis] <= first_bounds[0][axis]
                        for axis in range(3)
                    ):
                        continue
                    primitive_pair_checks += 1
                    if (
                        primitive_pair_checks
                        > MAX_PREVIEW_GEOMETRY_PRIMITIVE_PAIR_CHECKS
                    ):
                        truncated = True
                        break
                    witness = _positive_oriented_box_overlap_mm(
                        first_box,
                        second_box,
                    )
                    if witness is not None:
                        witness_exact = first_box.exact and second_box.exact
                        if (
                            overlap is None
                            or (witness_exact and not overlap[1])
                            or (
                                witness_exact == overlap[1]
                                and witness > overlap[0]
                            )
                        ):
                            overlap = (witness, witness_exact)
                        if witness_exact:
                            # One proven exact overlap is sufficient for this
                            # Component pair; penetration depth is diagnostic,
                            # not an optimisation target.
                            break
                if truncated or (overlap is not None and overlap[1]):
                    break
            if overlap is None:
                if truncated:
                    break
                continue
            if first.key < second.key:
                pair = (first.key, second.key)
                labels = (first.label, second.label)
            else:
                pair = (second.key, first.key)
                labels = (second.label, first.label)
            overlaps[pair] = (labels, overlap[0], overlap[1])
            if truncated:
                break
            if len(overlaps) >= MAX_PREVIEW_GEOMETRY_WARNINGS:
                truncated = True
                break
        if truncated:
            break

    return (
        tuple(
            PreviewGeometryWarning(
                code=(
                    "generated_component_positive_volume_overlap"
                    if exact
                    else "generated_underfill_possible_volume_overlap"
                ),
                message=(
                    (
                        f"几何警告：Generated Component「{labels[0]}」与"
                        f"「{labels[1]}」存在正体积重叠；可继续修改草稿，"
                    )
                    if exact
                    else (
                        f"几何提醒：Generated Component「{labels[0]}」与"
                        f"「{labels[1]}」在 Underfill 保守检查中疑似存在"
                        "正体积重叠；此提示不会阻止继续编辑，"
                    )
                )
                + "正式生成网格时仍会严格检查。",
                component_keys=pair,
                component_labels=labels,
                minimum_axis_overlap_mm=overlap,
                exact=exact,
            )
            for pair, (labels, overlap, exact) in sorted(overlaps.items())
        ),
        truncated,
    )


def transform_frozen_point(point: Vec3, placement: object) -> Vec3:
    translation = _finite_vec3(getattr(placement, "translation_xyz_mm"))
    matrix = tuple(tuple(float(value) for value in row) for row in placement.rotation_matrix)
    if len(matrix) != 3 or any(len(row) != 3 for row in matrix):
        raise ValueError("frozen placement rotation matrix must be 3x3")
    return tuple(  # type: ignore[return-value]
        translation[row] + sum(matrix[row][column] * point[column] for column in range(3))
        for row in range(3)
    )


def _transform_faces(
    faces: Iterable[Face],
    placement: CanonicalRigidPlacement,
) -> tuple[Face, ...]:
    return tuple(
        tuple(transform_generated_point(point, placement) for point in face)
        for face in faces
    )


def frozen_bounds_from_mesh_header(frozen_source: object) -> PreviewBounds | None:
    """Read only bounded PhysicalNames/Entities metadata, never mesh data."""
    from .package_v2_mesh_groups import read_mesh_volume_groups

    try:
        catalog = read_mesh_volume_groups(frozen_source.artifacts.mesh_runtime_path)
        bounds = catalog.bounds_for(tuple(binding.local_id for binding in frozen_source.components))
        return PreviewBounds(*bounds) if bounds else None
    except (OSError, ValueError, AttributeError):
        return None


def _coerce_bounds(value: object) -> PreviewBounds | None:
    if value is None:
        return None
    if isinstance(value, PreviewBounds):
        return value
    if isinstance(value, (str, bytes)):
        raise ValueError("frozen bounds must be numeric")
    try:
        items = tuple(value)  # type: ignore[arg-type]
    except TypeError as exc:
        raise ValueError("frozen bounds must be a PreviewBounds or six numbers") from exc
    if len(items) == 2:
        return PreviewBounds(
            _finite_vec3(items[0]),  # type: ignore[arg-type]
            _finite_vec3(items[1]),  # type: ignore[arg-type]
        )
    if len(items) == 6:
        numbers = tuple(float(item) for item in items)
        return PreviewBounds(numbers[:3], numbers[3:])  # type: ignore[arg-type]
    raise ValueError("frozen bounds must contain (minimum, maximum) or six numbers")


def _bounds_for_points(points: Iterable[Vec3]) -> PreviewBounds | None:
    values = tuple(points)
    if not values:
        return None
    minimum = tuple(min(point[index] for point in values) for index in range(3))
    maximum = tuple(max(point[index] for point in values) for index in range(3))
    if any(high <= low for low, high in zip(minimum, maximum)):
        # A flat generated scene still needs a useful fit diagonal.
        epsilon = max(1.0e-6, max(abs(value) for point in values for value in point) * 1.0e-6)
        flat_axes = tuple(high <= low for low, high in zip(minimum, maximum))
        minimum = tuple(
            low - (epsilon * 0.5 if flat else 0.0)
            for low, flat in zip(minimum, flat_axes)
        )
        maximum = tuple(
            high + (epsilon * 0.5 if flat else 0.0)
            for high, flat in zip(maximum, flat_axes)
        )
    return PreviewBounds(minimum, maximum)  # type: ignore[arg-type]


def build_preview_scene(
    compiled: object,
    *,
    frozen_bounds: Mapping[str, object] | None = None,
) -> PreviewScene:
    """Convert one fully compiled Package V2 result into a tiny render scene."""

    generated_instances = tuple(getattr(compiled, "generated_instances", ()))
    frozen_sources = tuple(getattr(compiled, "frozen_sources", ()))
    assembly_policy = getattr(compiled, "assembly_policy", None)
    if assembly_policy is None:
        raise TypeError("compiled must be a PackageV2CompileResult-like object")

    warnings: list[str] = []
    components: list[PreviewComponent] = []
    global_to_key: dict[str, str] = {}
    generated_points: list[Vec3] = []
    generated_boxes: list[_PreviewOrientedBox] = []
    generated_triangle_count = 0
    generated_budget_exhausted = False
    for instance in generated_instances:
        if generated_budget_exhausted:
            break
        geometry = instance.geometry_result.geometry
        descriptor_by_local = instance.component_by_local_id
        for component in geometry.components:
            if len(components) >= MAX_PREVIEW_COMPONENTS:
                warnings.append(
                    "3D 预览已达到 Component 安全上限；其余 Component 未显示。"
                )
                generated_budget_exhausted = True
                break
            key = generated_component_key(
                instance.instance_id,
                component.component_id,
            )
            label = f"{instance.instance_id} / {component.component_id}"
            triangles: list[Triangle] = []
            fill_faces: list[Face] = []
            component_boxes: list[_PreviewOrientedBox] = []
            for fragment in component.fragments:
                local_faces = _node_faces(fragment.root, warnings)
                local = _triangles_from_faces(local_faces)
                if (
                    generated_triangle_count
                    + len(triangles)
                    + len(local)
                    > MAX_PREVIEW_TRIANGLES
                ):
                    warnings.append(
                        "3D 预览已达到三角面安全上限；其余 Component 未显示。"
                    )
                    generated_budget_exhausted = True
                    break
                transformed_faces = _transform_faces(
                    local_faces,
                    fragment.placement,
                )
                fill_faces.extend(transformed_faces)
                # The topology triangles reuse the semantic-face vertices;
                # no second coordinate cloud is allocated for the preview.
                triangles.extend(_triangles_from_faces(transformed_faces))
                for partition_box in _exact_box_partition(fragment.root):
                    component_boxes.append(
                        _preview_oriented_box(
                            partition_box,
                            fragment.placement,
                            component_key=key,
                            component_label=label,
                        )
                    )
                for witness_box in _underfill_advisory_box_partition(fragment.root):
                    component_boxes.append(
                        _preview_oriented_box(
                            witness_box,
                            fragment.placement,
                            component_key=key,
                            component_label=label,
                            exact=False,
                        )
                    )
            if generated_budget_exhausted:
                break
            descriptor = descriptor_by_local[component.component_id]
            global_to_key[descriptor.global_component_id] = key
            component_triangles = tuple(triangles)
            component_fill_faces = tuple(fill_faces)
            edge_adjacency = build_edge_adjacency(
                component_triangles,
                component_fill_faces,
            )
            preview = PreviewComponent(
                key=key,
                label=label,
                owner_id=instance.instance_id,
                component_id=component.component_id,
                material_name=component.material_name,
                triangles=component_triangles,
                fill_faces=component_fill_faces,
                surface_edges=tuple(
                    adjacency.edge
                    for adjacency in edge_adjacency
                    if adjacency.is_crease()
                ),
                edge_adjacency=edge_adjacency,
            )
            components.append(preview)
            generated_boxes.extend(component_boxes)
            generated_points.extend(preview.points)
            generated_triangle_count += len(component_triangles)

    (
        geometry_warnings,
        geometry_warning_scan_truncated,
    ) = _generated_box_overlap_warnings(generated_boxes)
    warnings.extend(value.message for value in geometry_warnings)
    if geometry_warning_scan_truncated:
        warnings.append(
            "Geometry 重叠诊断已达到交互预览上限；"
            "仅显示前若干组，正式生成网格仍会完整严格检查。"
        )
    generated_world_bounds = _bounds_for_points(generated_points)
    proxy_span = max(
        1.0e-3,
        (generated_world_bounds.diagonal * 0.16 if generated_world_bounds else 1.0),
    )
    supplied_bounds = frozen_bounds or {}
    for source in frozen_sources:
        bounds = (
            _coerce_bounds(supplied_bounds[source.source_id])
            if source.source_id in supplied_bounds
            else frozen_bounds_from_mesh_header(source)
        )
        known = bounds is not None
        if bounds is None:
            center = _finite_vec3(source.placement.translation_xyz_mm)
            half = proxy_span * 0.5
            bounds = PreviewBounds(
                (center[0] - half, center[1] - half, center[2] - half),
                (center[0] + half, center[1] + half, center[2] + half),
            )
            # Proxy coordinates are already in world space; keep the placement
            # marker centred without applying translation a second time.
            corners = bounds.corners
            warnings.append(
                f"Frozen {source.source_id} 范围未知；"
                "显示 placement proxy，未读取 MSH 节点和单元。"
            )
        else:
            corners = tuple(
                transform_frozen_point(point, source.placement)
                for point in bounds.corners
            )
        placement_origin = _finite_vec3(source.placement.translation_xyz_mm)
        axis_length = max(bounds.diagonal * 0.16, proxy_span * 0.35)
        placement_axes = tuple(
            (
                placement_origin,
                transform_frozen_point(local_end, source.placement),
            )
            for local_end in (
                (axis_length, 0.0, 0.0),
                (0.0, axis_length, 0.0),
                (0.0, 0.0, axis_length),
            )
        )
        for binding in source.components:
            if len(components) >= MAX_PREVIEW_COMPONENTS:
                warnings.append(
                    "3D 预览已达到 Component 安全上限；其余 Frozen Component 未显示。"
                )
                break
            key = frozen_component_key(source.source_id, binding.local_id)
            global_to_key[binding.global_id] = key
            components.append(
                PreviewComponent(
                    key=key,
                    label=(
                        f"{source.source_id} / {binding.local_id}"
                        + (
                            " · shared source metadata bounds"
                            if known
                            else " · shared source placement proxy / 范围未知"
                        )
                    ),
                    owner_id=source.source_id,
                    component_id=binding.local_id,
                    material_name=None,
                    triangles=(),
                    wire_corners=corners,
                    placement_axes=placement_axes,
                    frozen=True,
                    bounds_known=known,
                )
            )

    interfaces: list[PreviewInterface] = []
    for match in tuple(getattr(assembly_policy, "interface_matches", ())):
        frozen_key = global_to_key.get(match.frozen_component.identifier)
        generated_key_value = global_to_key.get(match.generated_component.identifier)
        if frozen_key is None or generated_key_value is None:
            warnings.append("一条 interface 无法映射到预览 Component。")
            continue
        mode = getattr(match.mode, "value", str(match.mode))
        interfaces.append(
            PreviewInterface(frozen_key, generated_key_value, str(mode))
        )

    # Read the public instance pose from the validated authoring graph. Leaf
    # placements include nested offsets and fold mirrors into geometry, so they
    # cannot recover the parent's actual origin or handedness.
    local_frames = []
    parsed = getattr(compiled, "parsed_source", None)
    if parsed is not None:
        document = json.loads(parsed.raw_text)
        scope = resolve_scope(document["globals"])
        available_keys = {component.key for component in components}
        for instance in document["instances"]:
            owner = component_id(instance)
            key = generated_component_key(owner, owner)
            if key in available_keys:
                matrix, origin = pose(instance, scope)
                axes = tuple(tuple(matrix[row][col] for row in range(3)) for col in range(3))
                local_frames.append(PreviewLocalFrame(instance["id"], key, origin, axes))

    digest = str(getattr(compiled, "plan_digest", ""))
    return PreviewScene(
        components=tuple(components),
        interfaces=tuple(interfaces),
        plan_digest=digest,
        warnings=tuple(dict.fromkeys(warnings)),
        geometry_warnings=geometry_warnings,
        geometry_warning_scan_truncated=geometry_warning_scan_truncated,
        local_frames=tuple(local_frames),
    )


def _quick3d_point(point: Vec3) -> Vec3:
    """Rotate canonical Z-up coordinates into Qt Quick 3D's Y-up space."""

    return (point[0], point[2], -point[1])


def _quick3d_face_geometry(faces: Iterable[Face]) -> QQuick3DGeometry | None:
    """Build indexed, flat-shaded Qt Quick 3D geometry from semantic faces."""

    vertex_values: list[float] = []
    indices: list[int] = []
    bounds_points: list[Vec3] = []
    vertex_count = 0
    for face in faces:
        normal = _face_normal(face)
        if normal is None or len(face) < 3:
            continue
        quick_normal = _quick3d_point(normal)
        quick_face = tuple(_quick3d_point(point) for point in face)
        base = vertex_count
        for point in quick_face:
            vertex_values.extend((*point, *quick_normal))
            bounds_points.append(point)
            vertex_count += 1
        for index in range(1, len(quick_face) - 1):
            indices.extend((base, base + index, base + index + 1))
    if not indices or not bounds_points:
        return None

    geometry = QQuick3DGeometry()
    geometry.setStride(6 * 4)
    geometry.setVertexData(
        QByteArray(struct.pack(f"<{len(vertex_values)}f", *vertex_values))
    )
    geometry.setIndexData(QByteArray(struct.pack(f"<{len(indices)}I", *indices)))
    attribute = QQuick3DGeometry.Attribute
    geometry.addAttribute(
        attribute.PositionSemantic,
        0,
        attribute.F32Type,
    )
    geometry.addAttribute(
        attribute.NormalSemantic,
        3 * 4,
        attribute.F32Type,
    )
    geometry.addAttribute(
        attribute.IndexSemantic,
        0,
        attribute.U32Type,
    )
    geometry.setPrimitiveType(QQuick3DGeometry.PrimitiveType.Triangles)
    minimum = tuple(
        min(point[index] for point in bounds_points) for index in range(3)
    )
    maximum = tuple(
        max(point[index] for point in bounds_points) for index in range(3)
    )
    geometry.setBounds(QVector3D(*minimum), QVector3D(*maximum))
    return geometry


def _quick3d_line_geometry(
    points: Sequence[Vec3],
    edges: Iterable[tuple[int, int]],
) -> QQuick3DGeometry | None:
    """Build portable one-pixel line geometry (no backend-specific width)."""

    quick_points = tuple(_quick3d_point(point) for point in points)
    indices = tuple(index for edge in edges for index in edge)
    if not quick_points or not indices:
        return None
    if any(index < 0 or index >= len(quick_points) for index in indices):
        raise ValueError("Qt Quick 3D line index is outside the vertex buffer")

    vertex_values = tuple(value for point in quick_points for value in point)
    geometry = QQuick3DGeometry()
    geometry.setStride(3 * 4)
    geometry.setVertexData(
        QByteArray(struct.pack(f"<{len(vertex_values)}f", *vertex_values))
    )
    geometry.setIndexData(QByteArray(struct.pack(f"<{len(indices)}I", *indices)))
    attribute = QQuick3DGeometry.Attribute
    geometry.addAttribute(attribute.PositionSemantic, 0, attribute.F32Type)
    geometry.addAttribute(attribute.IndexSemantic, 0, attribute.U32Type)
    geometry.setPrimitiveType(QQuick3DGeometry.PrimitiveType.Lines)
    minimum = tuple(
        min(point[index] for point in quick_points) for index in range(3)
    )
    maximum = tuple(
        max(point[index] for point in quick_points) for index in range(3)
    )
    geometry.setBounds(QVector3D(*minimum), QVector3D(*maximum))
    return geometry


@dataclass(slots=True)
class _Quick3DEntry:
    keys: tuple[str, ...]
    geometry: QQuick3DGeometry
    base_color: QColor
    opacity: float = 1.0
    unlit: bool = False
    no_culling: bool = False
    translucent_capable: bool = False
    visibility_requires_all: bool = False
    visible: bool = True
    highlighted: bool = False
    translucent: bool = False
    focus_faded: bool = False
    focus_context: bool = False

    @property
    def display_color(self) -> QColor:
        if self.focus_context:
            return QColor("#65717b")
        if self.focus_faded:
            # Highlight context is deliberately neutral smoked glass. Mixing
            # several translucent material hues can create a pale composite
            # that looks like a nonexistent white material.
            return QColor("#34414a")
        if not self.highlighted:
            return QColor(self.base_color)
        if self.unlit:
            return QColor("#ffea00")
        # Highlighting must never alter the material of the selected solid.
        # Brightening a lit PrincipledMaterial can clip light-facing surfaces
        # toward white, making it look as if an unrelated white face appeared.
        # The unlit feature-edge entry above provides the visible highlight.
        return QColor(self.base_color)

    @property
    def display_opacity(self) -> float:
        if self.focus_faded:
            return 0.42
        if self.translucent_capable and self.translucent:
            return 0.42
        return self.opacity

    @property
    def transparent_mode(self) -> bool:
        return self.focus_faded or (
            self.translucent_capable and self.translucent
        )

    @property
    def depth_write(self) -> bool:
        return not self.transparent_mode

    @property
    def display_unlit(self) -> bool:
        # Focus mode is an inspection view: selected fills must show the exact
        # material swatch instead of allowing a light-facing slope to clip
        # toward white. The yellow feature edges retain shape readability.
        selected_fill = self.highlighted and self.translucent_capable
        return self.unlit or self.focus_faded or selected_fill


class _Quick3DSceneModel(QAbstractListModel):
    GeometryRole = int(Qt.ItemDataRole.UserRole) + 1
    DisplayColorRole = GeometryRole + 1
    VisibleRole = GeometryRole + 2
    OpacityRole = GeometryRole + 3
    UnlitRole = GeometryRole + 4
    NoCullingRole = GeometryRole + 5
    KeyRole = GeometryRole + 6
    TransparentRole = GeometryRole + 7
    DepthWriteRole = GeometryRole + 8

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._entries: tuple[_Quick3DEntry, ...] = ()

    def roleNames(self) -> Mapping[int, QByteArray]:  # noqa: N802
        return {
            self.GeometryRole: QByteArray(b"geometryObject"),
            self.DisplayColorRole: QByteArray(b"displayColor"),
            self.VisibleRole: QByteArray(b"modelVisible"),
            self.OpacityRole: QByteArray(b"opacityValue"),
            self.UnlitRole: QByteArray(b"unlitMode"),
            self.NoCullingRole: QByteArray(b"noCulling"),
            self.KeyRole: QByteArray(b"componentKey"),
            self.TransparentRole: QByteArray(b"transparentMode"),
            self.DepthWriteRole: QByteArray(b"depthWrite"),
        }

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._entries)

    def data(
        self,
        index: QModelIndex,
        role: int = int(Qt.ItemDataRole.DisplayRole),
    ) -> object:
        if not index.isValid() or not 0 <= index.row() < len(self._entries):
            return None
        entry = self._entries[index.row()]
        if role == self.GeometryRole:
            return entry.geometry
        if role == self.DisplayColorRole:
            return entry.display_color
        if role == self.VisibleRole:
            return entry.visible
        if role == self.OpacityRole:
            return entry.display_opacity
        if role == self.UnlitRole:
            return entry.display_unlit
        if role == self.NoCullingRole:
            return entry.no_culling
        if role == self.KeyRole:
            return entry.keys[0] if entry.keys else ""
        if role == self.TransparentRole:
            return entry.transparent_mode
        if role == self.DepthWriteRole:
            return entry.depth_write
        return None

    @property
    def entries(self) -> tuple[_Quick3DEntry, ...]:
        return self._entries

    def replace_entries(self, entries: Iterable[_Quick3DEntry]) -> None:
        candidate = tuple(entries)
        for entry in candidate:
            entry.geometry.setParent(self)
        retired = self._entries
        self.beginResetModel()
        self._entries = candidate
        self.endResetModel()
        for entry in retired:
            entry.geometry.deleteLater()

    def update_state(
        self,
        visible_keys: frozenset[str],
        highlighted_keys: frozenset[str],
        translucent: bool,
    ) -> None:
        changed = False
        effective_highlights = highlighted_keys & visible_keys
        focus_active = bool(effective_highlights)
        for entry in self._entries:
            if entry.visibility_requires_all:
                component_visible = bool(entry.keys) and all(
                    key in visible_keys for key in entry.keys
                )
            else:
                component_visible = any(key in visible_keys for key in entry.keys)
            highlighted = any(key in effective_highlights for key in entry.keys)
            # Focus is an isolate/wireframe inspection mode. Weighted blended
            # transparency necessarily mixes overlapping material colors and
            # can create a pale surface that belongs to no Component. Hide the
            # unrelated fills and retain their structural lines instead.
            focus_faded = False
            focus_suppressed = (
                focus_active
                and not highlighted
                and entry.translucent_capable
            )
            focus_context = (
                focus_active
                and not highlighted
                and not entry.translucent_capable
            )
            visible = component_visible and not focus_suppressed
            entry_translucent = (
                entry.translucent_capable
                and translucent
            )
            if (
                entry.visible != visible
                or entry.highlighted != highlighted
                or entry.translucent != entry_translucent
                or entry.focus_faded != focus_faded
                or entry.focus_context != focus_context
            ):
                entry.visible = visible
                entry.highlighted = highlighted
                entry.translucent = entry_translucent
                entry.focus_faded = focus_faded
                entry.focus_context = focus_context
                changed = True
        if changed and self._entries:
            self.dataChanged.emit(
                self.index(0, 0),
                self.index(len(self._entries) - 1, 0),
                [
                    self.DisplayColorRole,
                    self.VisibleRole,
                    self.OpacityRole,
                    self.UnlitRole,
                    self.TransparentRole,
                    self.DepthWriteRole,
                ],
            )


class _Quick3DCanvas(QQuickWidget):
    """Qt Quick 3D canvas embedded in the surrounding QWidget UI."""

    _MIN_ZOOM = 0.35
    # Orthographic inspection must span package scale down to micron details:
    # a 100 mm scene at 100,000x has an approximately 1 um-wide viewport.
    _MAX_ZOOM = 100_000.0

    def __init__(self, owner: "PackageV2Preview3D") -> None:
        super().__init__(owner)
        self._owner = owner
        self._scene_model = _Quick3DSceneModel(self)
        self._geometry_revision = -1
        self._yaw_deg = -38.0
        self._pitch_deg = -24.0
        self._zoom = 1.0
        self._pan_x = 0.0
        self._pan_y = 0.0
        self._base_distance = 3.2
        self._scene_radius = 1.0
        self._scene_offset = QVector3D()
        self._drag_position: QPointF | None = None
        self._drag_mode = ""
        self._qml_error = ""
        self._render_error = ""
        self._installed_local_frames: tuple[PreviewLocalFrame, ...] | None = None

        self.setResizeMode(QQuickWidget.ResizeMode.SizeRootObjectToView)
        self.setMinimumSize(280, 210)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setToolTip(
            "左键拖动旋转；Shift+左键、中键或右键拖动平移；"
            "滚轮围绕指针缩放；正交模式最高 100,000×；双击恢复视图"
        )
        self.statusChanged.connect(self._on_qml_status_changed)
        self.quickWindow().sceneGraphInitialized.connect(
            self._apply_root_properties,
            Qt.ConnectionType.QueuedConnection,
        )
        self.quickWindow().sceneGraphError.connect(
            self._on_scene_graph_error,
            Qt.ConnectionType.QueuedConnection,
        )
        qml_path = (
            Path(__file__).resolve().parent
            / "resources"
            / "package_v2_preview_3d.qml"
        )
        self.setSource(QUrl.fromLocalFile(str(qml_path)))
        self._on_qml_status_changed(self.status())

    @property
    def camera_state(self) -> tuple[float, float, float, float, float]:
        return (
            self._yaw_deg,
            self._pitch_deg,
            self._zoom,
            self._pan_x,
            self._pan_y,
        )

    @property
    def render_backend(self) -> str:
        try:
            api = self.quickWindow().rendererInterface().graphicsApi()
        except (AttributeError, RuntimeError):
            return "Unknown"
        return getattr(api, "name", str(api))

    @property
    def render_status(self) -> str:
        if self._render_error:
            return f"render-error: {self._render_error}"
        if self._qml_error:
            return f"error: {self._qml_error}"
        if self.status() == QQuickWidget.Status.Loading:
            return "loading"
        if self.status() != QQuickWidget.Status.Ready or self.rootObject() is None:
            return "not-ready"
        backend = self.render_backend
        if backend in {"Null", "Software"}:
            return f"unsupported-backend: {backend}"
        if backend == "Unknown":
            return "pending-backend: Unknown"
        return f"ready: {backend}"

    def _on_scene_graph_error(self, _error: object, message: str) -> None:
        self._render_error = str(message)
        self._apply_root_properties()

    def _on_qml_status_changed(self, status: QQuickWidget.Status) -> None:
        if status == QQuickWidget.Status.Error:
            self._qml_error = "\n".join(error.toString() for error in self.errors())
            return
        if status != QQuickWidget.Status.Ready:
            return
        self._qml_error = ""
        root = self.rootObject()
        if root is not None:
            root.setProperty("sceneModel", self._scene_model)
        self._apply_root_properties()

    @staticmethod
    def _edge_geometry(edges: Iterable[Edge]) -> QQuick3DGeometry | None:
        points: list[Vec3] = []
        indices: list[tuple[int, int]] = []
        for edge in edges:
            base = len(points)
            points.extend(edge)
            indices.append((base, base + 1))
        return _quick3d_line_geometry(points, indices)

    def _build_scene_entries(self, scene: PreviewScene) -> tuple[_Quick3DEntry, ...]:
        entries: list[_Quick3DEntry] = []
        foreground = self.palette().color(self.foregroundRole())
        edge_color = QColor("#314653" if foreground.lightness() < 128 else "#d7e2e9")

        for component in scene.components:
            if component.frozen:
                continue
            faces = component.fill_faces or tuple(component.triangles)
            geometry = _quick3d_face_geometry(faces)
            if geometry is not None:
                entries.append(
                    _Quick3DEntry(
                        (component.key,),
                        geometry,
                        material_color(component.material_name or "generated"),
                        translucent_capable=True,
                    )
                )
            edge_geometry = self._edge_geometry(component.surface_edges)
            if edge_geometry is not None:
                entries.append(
                    _Quick3DEntry(
                        (component.key,),
                        edge_geometry,
                        edge_color,
                        unlit=True,
                        no_culling=True,
                    )
                )

        axis_colors = (QColor("#d84a4a"), QColor("#3b9b62"), QColor("#347cc2"))
        for source_components in scene.frozen_components_by_source.values():
            representative = source_components[0]
            keys = tuple(component.key for component in source_components)
            if len(representative.wire_corners) == 8:
                geometry = _quick3d_line_geometry(
                    representative.wire_corners,
                    _BOX_EDGE_INDICES,
                )
                if geometry is not None:
                    entries.append(
                        _Quick3DEntry(
                            keys,
                            geometry,
                            QColor(
                                "#57b8e9"
                                if representative.bounds_known
                                else "#78909c"
                            ),
                            unlit=True,
                            no_culling=True,
                        )
                    )
            for axis_index, axis in enumerate(representative.placement_axes):
                geometry = _quick3d_line_geometry(axis, ((0, 1),))
                if geometry is not None:
                    entries.append(
                        _Quick3DEntry(
                            keys,
                            geometry,
                            axis_colors[axis_index],
                            unlit=True,
                            no_culling=True,
                        )
                    )

        by_key = scene.component_by_key
        for relation in scene.interfaces:
            frozen_component = by_key.get(relation.frozen_key)
            generated_component = by_key.get(relation.generated_key)
            if frozen_component is None or generated_component is None:
                continue
            geometry = _quick3d_line_geometry(
                (frozen_component.center, generated_component.center),
                ((0, 1),),
            )
            if geometry is not None:
                entries.append(
                    _Quick3DEntry(
                        (relation.frozen_key, relation.generated_key),
                        geometry,
                        QColor("#00a7c7"),
                        unlit=True,
                        no_culling=True,
                        visibility_requires_all=True,
                    )
                )
        return tuple(entries)

    def prepare_scene(self, scene: PreviewScene) -> tuple[_Quick3DEntry, ...]:
        """Build GPU resource descriptors without mutating the active model."""

        return self._build_scene_entries(scene)

    def install_prepared_scene(
        self,
        revision: int,
        entries: Iterable[_Quick3DEntry],
    ) -> None:
        self._scene_model.replace_entries(entries)
        self._geometry_revision = revision

    def sync_scene(self) -> None:
        scene = self._owner.scene
        if self._geometry_revision != self._owner.scene_revision:
            entries = self._build_scene_entries(scene)
            self._scene_model.replace_entries(entries)
            self._geometry_revision = self._owner.scene_revision
        self._scene_model.update_state(
            self._owner.visible_components,
            self._owner.highlighted_components,
            self._owner.translucent,
        )
        self._fit_visible_scene()
        self._apply_root_properties()

    def _fit_visible_scene(self) -> None:
        scene = self._owner.scene
        visible = self._owner.visible_components
        points = tuple(
            point
            for component in scene.components
            if component.key in visible
            for point in component.points
        )
        if not points:
            points = tuple(
                point for component in scene.components for point in component.points
            )
        bounds = _bounds_for_points(points)
        if bounds is None:
            center = (0.0, 0.0, 0.0)
            radius = 1.0
        else:
            center = bounds.center
            radius = max(bounds.diagonal * 0.5, 1.0e-6)
        quick_center = _quick3d_point(center)
        self._scene_offset = QVector3D(
            -quick_center[0],
            -quick_center[1],
            -quick_center[2],
        )
        self._scene_radius = radius
        self._base_distance = radius * 3.2

    def _apply_root_properties(self) -> None:
        root = self.rootObject()
        if root is None:
            return
        background = self.palette().color(self.backgroundRole())
        foreground = self.palette().color(self.foregroundRole())
        root.setProperty("backgroundColor", background)
        root.setProperty("foregroundColor", foreground)
        root.setProperty("sceneOffset", self._scene_offset)
        origin, axes = self._owner.coordinate_frame
        root.setProperty("coordinateOrigin", QVector3D(*_quick3d_point(origin)))
        for label, axis in zip("XYZ", axes):
            root.setProperty(f"coordinateAxis{label}", QVector3D(*_quick3d_point(axis)))
        root.setProperty("coordinateFrameIsLocal", self._owner.coordinate_frame_is_local)
        frames = self._owner.local_coordinate_frames
        if frames != self._installed_local_frames:
            root.setProperty("localCoordinateFrames", [
                {"name": frame.instance_id, "origin": QVector3D(*_quick3d_point(frame.origin)),
                 **{f"axis{label}": QVector3D(*_quick3d_point(axis))
                    for label, axis in zip("XYZ", frame.axes)}}
                for frame in frames
            ])
            self._installed_local_frames = frames
        root.setProperty("sceneRadius", self._scene_radius)
        root.setProperty("cameraDistance", self._base_distance)
        self._apply_camera_properties()
        root.setProperty(
            "translucentMode",
            self._owner.translucent,
        )
        backend_unsupported = self.render_backend in {"Null", "Software"}
        renderer_unavailable = backend_unsupported or bool(self._render_error)
        has_visible = bool(
            self._owner.scene.components and self._owner.visible_components
        ) and not renderer_unavailable
        root.setProperty("hasScene", has_visible)
        if self._render_error:
            empty_text = f"Qt Quick 3D 渲染器不可用：{self._render_error}"
        elif backend_unsupported:
            empty_text = (
                "Qt Quick 3D 需要可用的 Qt RHI 图形后端；"
                f"当前后端：{self.render_backend}"
            )
        elif not self._owner.scene.components:
            empty_text = self._owner.empty_message
        else:
            empty_text = "所有 Component 已隐藏"
        root.setProperty(
            "emptyText",
            empty_text,
        )

    def _apply_camera_properties(self) -> None:
        """Keep pointer events independent of scene size and QML model updates.

        Reassigning coordinate vectors invalidates the axis Repeater models.
        Camera motion only needs five scalar properties; geometry, palette,
        visibility and local coordinate frames remain installed in the scene.
        """
        root = self.rootObject()
        if root is not None:
            for name, value in zip(
                ("orbitYaw", "orbitPitch", "zoomFactor", "panX", "panY"),
                self.camera_state,
            ):
                root.setProperty(name, value)

    def reset_view(self, *, update: bool = True) -> None:
        self._yaw_deg = -38.0
        self._pitch_deg = -24.0
        self._zoom = 1.0
        self._pan_x = 0.0
        self._pan_y = 0.0
        self._drag_position = None
        self._drag_mode = ""
        self.unsetCursor()
        self._apply_camera_properties()
        if update:
            super().update()

    def set_axis_view(self, axis: str) -> None:
        """Look from a positive canonical axis while preserving zoom/mode."""

        views = {
            "x": (90.0, 0.0),
            "y": (-180.0, 0.0),
            "z": (0.0, -90.0),
        }
        try:
            yaw, pitch = views[axis]
        except (KeyError, TypeError) as exc:
            raise ValueError("axis view must be one of: x, y, z") from exc
        self._yaw_deg = yaw
        self._pitch_deg = pitch
        self._pan_x = 0.0
        self._pan_y = 0.0
        self._drag_position = None
        self._drag_mode = ""
        self.unsetCursor()
        self._apply_camera_properties()
        super().update()

    def wheelEvent(self, event: QWheelEvent) -> None:  # noqa: N802
        if not self._owner.scene.components:
            event.ignore()
            return
        delta = event.angleDelta().y() or event.pixelDelta().y()
        if not delta:
            event.ignore()
            return
        old_zoom = self._zoom
        logarithmic_zoom = math.log(old_zoom) + delta / 120.0 * 0.12
        self._zoom = math.exp(
            max(
                math.log(self._MIN_ZOOM),
                min(math.log(self._MAX_ZOOM), logarithmic_zoom),
            )
        )
        if self._zoom != old_zoom:
            viewport_span = max(1.0, float(min(self.width(), self.height())))
            old_world_per_pixel = (
                self._scene_radius * 2.4 / old_zoom / viewport_span
            )
            new_world_per_pixel = (
                self._scene_radius * 2.4 / self._zoom / viewport_span
            )
            position = event.position()
            offset_x = position.x() - self.width() * 0.5
            offset_y = position.y() - self.height() * 0.5
            self._pan_x += offset_x * (
                old_world_per_pixel - new_world_per_pixel
            )
            self._pan_y += offset_y * (
                new_world_per_pixel - old_world_per_pixel
            )
        self._apply_camera_properties()
        event.accept()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        pan_requested = bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier)
        pan_requested = pan_requested or event.button() in (
            Qt.MouseButton.MiddleButton,
            Qt.MouseButton.RightButton,
        )
        if pan_requested or event.button() == Qt.MouseButton.LeftButton:
            self._drag_position = event.position()
            self._drag_mode = "pan" if pan_requested else "rotate"
            self.setCursor(
                Qt.CursorShape.ClosedHandCursor
                if pan_requested
                else Qt.CursorShape.SizeAllCursor
            )
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self._drag_position is None:
            super().mouseMoveEvent(event)
            return
        delta = event.position() - self._drag_position
        self._drag_position = event.position()
        if self._drag_mode == "pan":
            world_per_pixel = (
                self._scene_radius
                * 2.4
                / self._zoom
                / max(1.0, float(min(self.width(), self.height())))
            )
            self._pan_x -= delta.x() * world_per_pixel
            self._pan_y += delta.y() * world_per_pixel
        else:
            self._yaw_deg = (
                (self._yaw_deg - delta.x() * 0.55 + 180.0) % 360.0
            ) - 180.0
            self._pitch_deg = max(
                -90.0,
                min(90.0, self._pitch_deg - delta.y() * 0.45),
            )
        self._apply_camera_properties()
        event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self._drag_position is not None:
            self._drag_position = None
            self._drag_mode = ""
            self.unsetCursor()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.reset_view()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)


class PackageV2Preview3D(QWidget):
    """Interactive low-poly Package V2 preview with Component visibility."""

    def __init__(self, parent: QWidget | None = None, *, compact: bool = False) -> None:
        super().__init__(parent)
        self._scene = PreviewScene()
        self._visible: set[str] = set()
        self._highlighted: set[str] = set()
        self._translucent = False
        self._scene_revision = 0
        self._coordinate_origin = (0.0, 0.0, 0.0)
        self._coordinate_axes = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
        self._coordinate_frame_is_local = False
        self._show_local_frames = False
        self._local_frame_instance_id: str | None = None
        self._empty_message = "打开有效的 Package V2 Source 或检查 Job 后显示 3D 几何"
        self._visibility_actions: dict[str, QAction] = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        toolbar = QHBoxLayout()
        toolbar.setSpacing(6)
        self.summary_label = QLabel("尚无可预览几何", self)
        self.summary_label.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Preferred,
        )
        self.summary_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        if compact:
            self.summary_label.setWordWrap(True)
            layout.addWidget(self.summary_label)
        else:
            toolbar.addWidget(self.summary_label, 1)
        self.visibility_button = QToolButton(self)
        self.visibility_button.setText("组件显隐")
        self.visibility_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.visibility_menu = QMenu(self.visibility_button)
        self.visibility_button.setMenu(self.visibility_menu)
        toolbar.addWidget(self.visibility_button)
        self.translucent_button = QToolButton(self)
        self.translucent_button.setText("半透明")
        self.translucent_button.setCheckable(True)
        self.translucent_button.setChecked(False)
        self.translucent_button.toggled.connect(self.set_translucent)
        toolbar.addWidget(self.translucent_button)
        self.x_view_button = QToolButton(self)
        self.x_view_button.setText("X")
        self.x_view_button.setToolTip("从 +X 方向朝原点观察（YZ 面）")
        self.x_view_button.clicked.connect(lambda _checked=False: self.set_axis_view("x"))
        toolbar.addWidget(self.x_view_button)
        self.y_view_button = QToolButton(self)
        self.y_view_button.setText("Y")
        self.y_view_button.setToolTip("从 +Y 方向朝原点观察（XZ 面）")
        self.y_view_button.clicked.connect(lambda _checked=False: self.set_axis_view("y"))
        toolbar.addWidget(self.y_view_button)
        self.z_view_button = QToolButton(self)
        self.z_view_button.setText("Z")
        self.z_view_button.setToolTip("从 +Z 方向朝原点观察（XY 面俯视）")
        self.z_view_button.clicked.connect(lambda _checked=False: self.set_axis_view("z"))
        toolbar.addWidget(self.z_view_button)
        self.reset_button = QPushButton("恢复视图", self)
        self.reset_button.setAutoDefault(False)
        self.reset_button.clicked.connect(self.reset_view)
        toolbar.addWidget(self.reset_button)
        layout.addLayout(toolbar)

        self.canvas = _Quick3DCanvas(self)
        layout.addWidget(self.canvas, 1)
        self.hint_label = QLabel(
            "左键旋转 · Shift+左键/中键/右键平移 · 滚轮缩放 · "
            "正交最高 100,000× · Frozen 显示范围框",
            self,
        )
        self.hint_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hint_label.setWordWrap(True)
        layout.addWidget(self.hint_label)
        self.setMinimumSize(300, 240)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._rebuild_visibility_menu()

    def sizeHint(self) -> QSize:
        return QSize(560, 520)

    @property
    def scene(self) -> PreviewScene:
        return self._scene

    @property
    def coordinate_frame(self) -> tuple[Vec3, tuple[Vec3, Vec3, Vec3]]:
        return self._coordinate_origin, self._coordinate_axes

    @property
    def coordinate_frame_is_local(self) -> bool:
        return self._coordinate_frame_is_local

    @property
    def local_coordinate_frames(self) -> tuple[PreviewLocalFrame, ...]:
        if not self._show_local_frames:
            return ()
        selected = self._highlighted & self._visible
        return tuple(frame for frame in self._scene.local_frames
                     if frame.component_key in selected
                     and (self._local_frame_instance_id is None
                          or frame.instance_id == self._local_frame_instance_id))

    def set_coordinate_frame(
        self,
        origin: Vec3 = (0.0, 0.0, 0.0),
        axes: tuple[Vec3, Vec3, Vec3] = (
            (1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0),
        ),
        *,
        local: bool = False,
    ) -> None:
        """Display a frame given its origin (mm) and unit axes in canonical space.

        Defaults to Global. Authoring dialogs pass the draft instance's local
        frame, including its placement, without changing geometry or the camera.
        """
        vectors = tuple(tuple(float(v) for v in vector) for vector in (origin, *axes))
        if len(vectors) != 4 or any(len(v) != 3 or not all(math.isfinite(n) for n in v) for v in vectors):
            raise ValueError("coordinate frame requires a finite origin and three unit axes")
        if any(not math.isclose(sum(n * n for n in v), 1.0, abs_tol=1e-6) for v in vectors[1:]):
            raise ValueError("coordinate frame axes must be unit vectors")
        self._coordinate_origin = vectors[0]
        self._coordinate_axes = vectors[1:]
        self._coordinate_frame_is_local = local
        self.canvas._apply_root_properties()
        self.canvas.update()

    @property
    def scene_revision(self) -> int:
        return self._scene_revision

    @property
    def scene_digest(self) -> str:
        return self._scene.plan_digest

    @property
    def component_keys(self) -> tuple[str, ...]:
        return self._scene.component_keys

    @property
    def visible_components(self) -> frozenset[str]:
        return frozenset(self._visible)

    @property
    def highlighted_components(self) -> frozenset[str]:
        return frozenset(self._highlighted)

    @property
    def translucent(self) -> bool:
        return self._translucent

    @property
    def camera_state(self) -> tuple[float, float, float, float, float]:
        return self.canvas.camera_state

    @property
    def render_backend(self) -> str:
        """Return the active cross-platform Qt RHI backend name."""

        return self.canvas.render_backend

    @property
    def render_status(self) -> str:
        """Return QML/RHI readiness for diagnostics and support reports."""

        return self.canvas.render_status

    @property
    def empty_message(self) -> str:
        return self._empty_message

    @property
    def visibility_actions(self) -> Mapping[str, QAction]:
        return dict(self._visibility_actions)

    def set_compiled_geometry(
        self,
        compiled: object,
        *,
        frozen_bounds: Mapping[str, object] | None = None,
    ) -> None:
        """Atomically replace the scene after successful pure extraction."""

        candidate = build_preview_scene(compiled, frozen_bounds=frozen_bounds)
        prepared_entries = self.canvas.prepare_scene(candidate)
        previous_keys = set(self._scene.component_keys)
        candidate_keys = set(candidate.component_keys)
        preserved_visibility = {
            key for key in self._visible if key in candidate_keys
        }
        new_keys = candidate_keys - previous_keys
        self._visible = preserved_visibility | new_keys
        if not previous_keys:
            self._visible = set(candidate_keys)
        self._highlighted.intersection_update(candidate_keys)
        self._scene = candidate
        self._scene_revision += 1
        self.canvas.install_prepared_scene(
            self._scene_revision,
            prepared_entries,
        )
        self._empty_message = "当前 canonical geometry 没有可显示的 Component"
        self._rebuild_visibility_menu()
        self._refresh_summary()
        self.canvas.sync_scene()
        if previous_keys != candidate_keys:
            self.canvas.reset_view(update=False)
        self.canvas.update()

    # A short alias is convenient for controller code and third-party callers.
    set_compiled = set_compiled_geometry

    def clear_scene(self, message: str = "尚未载入有效的 Package V2 几何") -> None:
        self._scene = PreviewScene()
        self._visible.clear()
        self._highlighted.clear()
        self._show_local_frames = False
        self._local_frame_instance_id = None
        self._scene_revision += 1
        self.canvas.install_prepared_scene(self._scene_revision, ())
        self._empty_message = message
        self._rebuild_visibility_menu()
        self._refresh_summary()
        self.canvas.reset_view(update=False)
        self.canvas.sync_scene()
        self.canvas.update()

    def reset_view(self, _checked: bool = False) -> None:
        del _checked
        self.canvas.reset_view()

    def set_highlighted_components(
        self, keys: Iterable[str], *, show_local_frames: bool = False,
        instance_id: str | None = None,
    ) -> None:
        available = set(self._scene.component_keys)
        self._highlighted = {str(key) for key in keys if str(key) in available}
        self._show_local_frames = show_local_frames
        self._local_frame_instance_id = instance_id
        self.canvas.sync_scene()
        self._refresh_summary()
        self.canvas.update()

    def set_translucent(self, enabled: bool) -> None:
        """Toggle OIT-backed translucency for generated solid faces only."""

        value = bool(enabled)
        if self._translucent == value:
            return
        self._translucent = value
        if self.translucent_button.isChecked() != value:
            self.translucent_button.blockSignals(True)
            self.translucent_button.setChecked(value)
            self.translucent_button.blockSignals(False)
        self.canvas.sync_scene()
        self._refresh_summary()
        self.canvas.update()

    def set_axis_view(self, axis: str) -> None:
        """Select a +X/+Y/+Z canonical view without changing zoom or modes."""

        self.canvas.set_axis_view(axis)

    def set_component_visible(self, key: str, visible: bool) -> None:
        if key not in self._scene.component_keys:
            return
        if visible:
            self._visible.add(key)
        else:
            self._visible.discard(key)
        action = self._visibility_actions.get(key)
        if action is not None and action.isChecked() != visible:
            action.blockSignals(True)
            action.setChecked(visible)
            action.blockSignals(False)
        self._refresh_summary()
        self.canvas.sync_scene()
        self.canvas.update()

    def set_visible_components(self, keys: Iterable[str]) -> None:
        available = set(self._scene.component_keys)
        selected = {str(key) for key in keys}
        self._visible = available & selected
        for key, action in self._visibility_actions.items():
            action.blockSignals(True)
            action.setChecked(key in self._visible)
            action.blockSignals(False)
        self._refresh_summary()
        self.canvas.sync_scene()
        self.canvas.update()

    def _show_all_components(self) -> None:
        self.set_visible_components(self._scene.component_keys)

    def _rebuild_visibility_menu(self) -> None:
        self.visibility_menu.clear()
        self._visibility_actions.clear()
        show_all = self.visibility_menu.addAction("全部显示")
        show_all.triggered.connect(self._show_all_components)
        self.visibility_menu.addSeparator()
        for component in self._scene.components:
            material = component.material_name or "Frozen"
            action = QAction(f"{component.label}  [{material}]", self.visibility_menu)
            action.setCheckable(True)
            action.setChecked(component.key in self._visible)
            action.toggled.connect(partial(self.set_component_visible, component.key))
            self.visibility_menu.addAction(action)
            self._visibility_actions[component.key] = action
        self.visibility_button.setEnabled(bool(self._scene.components))
        self.translucent_button.setEnabled(bool(self._scene.generated_count))
        has_scene = bool(self._scene.components)
        self.x_view_button.setEnabled(has_scene)
        self.y_view_button.setEnabled(has_scene)
        self.z_view_button.setEnabled(has_scene)

    def _refresh_summary(self) -> None:
        scene = self._scene
        if not scene.components:
            self.summary_label.setText("尚无可预览几何")
            return
        hidden = len(scene.components) - len(self._visible)
        summary = (
            f"G {scene.generated_count} · Frozen {scene.frozen_count} · "
            f"语义面 {scene.fill_face_count}"
        )
        if hidden:
            summary += f" · 隐藏 {hidden}"
        if self._translucent:
            summary += " · 半透明"
        effective_highlights = self._highlighted & self._visible
        if effective_highlights:
            summary += f" · 高亮 {len(effective_highlights)}"
        if scene.warnings:
            summary += f" · 提示 {len(scene.warnings)}"
            self.summary_label.setToolTip("\n".join(scene.warnings))
        else:
            self.summary_label.setToolTip("")
        self.summary_label.setText(summary)


__all__ = [
    "DEFAULT_CREASE_ANGLE_DEG",
    "MAX_PREVIEW_COMPONENTS",
    "MAX_PREVIEW_TRIANGLES",
    "PackageV2Preview3D",
    "PreviewBounds",
    "PreviewComponent",
    "PreviewEdgeAdjacency",
    "PreviewGeometryWarning",
    "PreviewInterface",
    "PreviewScene",
    "build_preview_scene",
    "build_edge_adjacency",
    "feature_edges",
    "frozen_bounds_from_mesh_header",
    "frozen_component_key",
    "generated_component_key",
    "material_color",
    "transform_frozen_point",
    "transform_generated_point",
    "visible_feature_edges",
]
