"""Gmsh-owned Cartesian tensor QUAD mesh for one rectangular contact side.

The function in this module creates only first-order 2D connectivity.  It is
used when a ``conformal_hybrid`` volume owns a surface that a lower-priority
``orthogonal_hex`` Component must consume.  Gmsh's transfinite/recombine
algorithm owns the QUAD connectivity; the hybrid closed-shell backend then
owns every TET/PYRAMID/WEDGE transition inside the producer volume.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from types import MappingProxyType
from typing import TypeAlias

from .gmsh_runtime import isolated_gmsh_model
from .occ_locked_hybrid import _load_gmsh


Point3D: TypeAlias = tuple[float, float, float]
Facet: TypeAlias = tuple[int, int, int, int]
_QUAD4 = 3
_TOLERANCE_MM = 1.0e-10
_MAXIMUM_TENSOR_CELL_COUNT = 2_000_000
_MAXIMUM_TENSOR_NODE_COUNT = 2_000_000


class GmshCartesianTensorSurfaceError(ValueError):
    """Gmsh could not prove the requested rectangular tensor surface."""


def _point3(value: Sequence[float], *, field_name: str) -> Point3D:
    try:
        values = tuple(float(item) for item in value)
    except (TypeError, ValueError, OverflowError) as error:
        raise GmshCartesianTensorSurfaceError(
            f"{field_name} must be a finite 3D vector"
        ) from error
    if len(values) != 3 or any(not math.isfinite(item) for item in values):
        raise GmshCartesianTensorSurfaceError(
            f"{field_name} must be a finite 3D vector"
        )
    return values  # type: ignore[return-value]


def _positive(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise GmshCartesianTensorSurfaceError(
            f"{field_name} must be finite and positive"
        )
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise GmshCartesianTensorSurfaceError(
            f"{field_name} must be finite and positive"
        ) from error
    if not math.isfinite(result) or result <= 0.0:
        raise GmshCartesianTensorSurfaceError(
            f"{field_name} must be finite and positive"
        )
    return result


def _active_axis(vector: Point3D, *, field_name: str) -> tuple[int, float]:
    tolerance = max(_TOLERANCE_MM, max(abs(value) for value in vector) * 1.0e-12)
    active = tuple(axis for axis, value in enumerate(vector) if abs(value) > tolerance)
    if len(active) != 1:
        raise GmshCartesianTensorSurfaceError(
            f"{field_name} must follow exactly one Cartesian axis"
        )
    axis = active[0]
    return axis, abs(vector[axis])


def _grid_snap_tolerance_mm(
    corners: Sequence[Point3D],
    *,
    u_length_mm: float,
    v_length_mm: float,
    target_edge_mm: float,
) -> float:
    """Bound grid snapping by local resolution plus coordinate roundoff.

    Absolute package offsets do not describe the requested mesh resolution.
    Only the smaller of each side and the target contributes a relative
    tolerance; absolute coordinates contribute solely through their binary64
    ULP, which is the irreducible representation error at that offset.
    """

    local_resolution = max(
        min(u_length_mm, target_edge_mm),
        min(v_length_mm, target_edge_mm),
    )
    coordinate_ulp = max(
        math.ulp(value)
        for point in corners
        for value in point
    )
    return max(
        _TOLERANCE_MM,
        local_resolution * 1.0e-9,
        64.0 * coordinate_ulp,
    )


@dataclass(frozen=True, slots=True)
class GmshCartesianTensorSurface:
    node_coordinates: Mapping[int, Point3D]
    facets: tuple[Facet, ...]
    u_interval_count: int
    v_interval_count: int
    target_edge_mm: float
    maximum_edge_mm: float
    gmsh_owns_surface_connectivity: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "node_coordinates",
            MappingProxyType(dict(self.node_coordinates)),
        )
        if (
            not self.node_coordinates
            or not self.facets
            or not self.gmsh_owns_surface_connectivity
            or len(self.facets) != self.u_interval_count * self.v_interval_count
            or self.maximum_edge_mm > self.target_edge_mm + max(
                _TOLERANCE_MM,
                self.target_edge_mm * 1.0e-10,
            )
        ):
            raise GmshCartesianTensorSurfaceError(
                "Gmsh Cartesian tensor surface evidence is incomplete"
            )


def generate_gmsh_cartesian_tensor_rectangle(
    origin_xyz_mm: Sequence[float],
    u_vector_xyz_mm: Sequence[float],
    v_vector_xyz_mm: Sequence[float],
    *,
    target_edge_mm: float,
    u_fractions: Sequence[float] | None = None,
    v_fractions: Sequence[float] | None = None,
    verbose: bool = False,
) -> GmshCartesianTensorSurface:
    """Generate one complete rectangular QUAD tensor using Gmsh transfinite."""

    if not isinstance(verbose, bool):
        raise GmshCartesianTensorSurfaceError("verbose must be boolean")
    origin = _point3(origin_xyz_mm, field_name="origin_xyz_mm")
    u_vector = _point3(u_vector_xyz_mm, field_name="u_vector_xyz_mm")
    v_vector = _point3(v_vector_xyz_mm, field_name="v_vector_xyz_mm")
    target = _positive(target_edge_mm, field_name="target_edge_mm")
    u_axis, u_length = _active_axis(u_vector, field_name="u_vector_xyz_mm")
    v_axis, v_length = _active_axis(v_vector, field_name="v_vector_xyz_mm")
    if u_axis == v_axis:
        raise GmshCartesianTensorSurfaceError(
            "rectangle vectors must follow two different Cartesian axes"
        )
    def axis_schedule(values, length):
        if values is None:
            count = max(1, math.ceil(length/target))
            return count, None
        values = tuple(float(v) for v in values)
        if (len(values)<2 or abs(values[0])>1.e-12 or abs(values[-1]-1)>1.e-12
                or any(not math.isfinite(v) for v in values)
                or any(b<=a for a,b in zip(values,values[1:]))):
            raise GmshCartesianTensorSurfaceError("locked axis fractions must strictly increase from 0 to 1")
        return len(values)-1, (0., *values[1:-1], 1.)
    u_intervals, u_positions = axis_schedule(u_fractions, u_length)
    v_intervals, v_positions = axis_schedule(v_fractions, v_length)
    estimated_cell_count = u_intervals * v_intervals
    estimated_node_count = (u_intervals + 1) * (v_intervals + 1)
    if (
        estimated_cell_count > _MAXIMUM_TENSOR_CELL_COUNT
        or estimated_node_count > _MAXIMUM_TENSOR_NODE_COUNT
    ):
        raise GmshCartesianTensorSurfaceError(
            "requested Cartesian tensor exceeds the pre-Gmsh resource ceiling: "
            f"cells={estimated_cell_count}/{_MAXIMUM_TENSOR_CELL_COUNT}, "
            f"nodes={estimated_node_count}/{_MAXIMUM_TENSOR_NODE_COUNT}"
        )
    # Check the resource ceiling before allocating uniform seed arrays.
    if u_positions is None:
        u_positions = tuple(i/u_intervals for i in range(u_intervals+1))
    if v_positions is None:
        v_positions = tuple(i/v_intervals for i in range(v_intervals+1))
    # Inherited steps are authoritative; retain their measured ceiling for
    # the existing surface evidence, independently of the free target.
    if u_fractions is not None or v_fractions is not None:
        target = max(target, *(u_length*(b-a) for a,b in zip(u_positions,u_positions[1:])),
                     *(v_length*(b-a) for a,b in zip(v_positions,v_positions[1:])))
    corners = (
        origin,
        tuple(origin[axis] + u_vector[axis] for axis in range(3)),
        tuple(
            origin[axis] + u_vector[axis] + v_vector[axis]
            for axis in range(3)
        ),
        tuple(origin[axis] + v_vector[axis] for axis in range(3)),
    )
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.RecombineAll": 1.0,
    }
    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_cartesian_tensor_surface",
        number_options=options,
    ):
        try:
            boundary_uv = ([(u,0.) for u in u_positions[:-1]] + [(1.,v) for v in v_positions[:-1]]
                           + [(u,1.) for u in reversed(u_positions[1:])] + [(0.,v) for v in reversed(v_positions[1:])])
            boundary_tags = tuple(int(gmsh.model.geo.addPoint(*(origin[a]+u*u_vector[a]+v*v_vector[a] for a in range(3))))
                                  for u,v in boundary_uv)
            point_tags = tuple(boundary_tags[index] for index in (0,u_intervals,u_intervals+v_intervals,2*u_intervals+v_intervals))
            curve_tags = tuple(int(gmsh.model.geo.addLine(first,second))
                for first,second in zip(boundary_tags,(*boundary_tags[1:],boundary_tags[0])))
            loop = int(gmsh.model.geo.addCurveLoop(curve_tags))
            surface = int(gmsh.model.geo.addPlaneSurface([loop]))
            gmsh.model.geo.synchronize()
            for curve in curve_tags:
                gmsh.model.mesh.setTransfiniteCurve(curve,2)
            gmsh.model.mesh.setTransfiniteSurface(
                surface,
                cornerTags=list(point_tags),
            )
            gmsh.model.mesh.setRecombine(2, surface)
            gmsh.model.mesh.generate(2)
            element_types, _element_tags, connectivity = gmsh.model.mesh.getElements(
                2,
                surface,
            )
            if tuple(int(value) for value in element_types) != (_QUAD4,):
                raise GmshCartesianTensorSurfaceError(
                    "Gmsh transfinite rectangle did not produce QUAD4 only"
                )
            raw_connectivity = tuple(int(value) for value in connectivity[0])
            raw_facets = tuple(
                raw_connectivity[index : index + 4]
                for index in range(0, len(raw_connectivity), 4)
            )
            node_tags, raw_coordinates, _parameters = gmsh.model.mesh.getNodes()
            coordinate_by_tag = {
                int(tag): tuple(
                    float(raw_coordinates[3 * index + axis])
                    for axis in range(3)
                )
                for index, tag in enumerate(node_tags)
            }
        except GmshCartesianTensorSurfaceError:
            raise
        except Exception as error:  # pragma: no cover - Gmsh runtime failure
            raise GmshCartesianTensorSurfaceError(
                "Gmsh could not generate the Cartesian tensor rectangle"
            ) from error

    used = {node for facet in raw_facets for node in facet}
    if used.difference(coordinate_by_tag):
        raise GmshCartesianTensorSurfaceError(
            "Gmsh tensor facet references an unknown node"
        )
    ordered = tuple(
        sorted(
            used,
            key=lambda node: (
                tuple(round(value, 12) for value in coordinate_by_tag[node]),
                node,
            ),
        )
    )
    local_by_gmsh = {
        gmsh_node: local_node
        for local_node, gmsh_node in enumerate(ordered, start=1)
    }
    raw_local_coordinates = {
        local_by_gmsh[node]: coordinate_by_tag[node] for node in ordered
    }
    facets = tuple(
        tuple(local_by_gmsh[node] for node in facet) for facet in raw_facets
    )
    plane_axis = ({0, 1, 2} - {u_axis, v_axis}).pop()
    expected_u = tuple(
        origin[u_axis] + u_vector[u_axis] * fraction
        for fraction in u_positions
    )
    expected_v = tuple(
        origin[v_axis] + v_vector[v_axis] * fraction
        for fraction in v_positions
    )
    snap_tolerance = _grid_snap_tolerance_mm(
        corners,
        u_length_mm=u_length,
        v_length_mm=v_length,
        target_edge_mm=target,
    )
    coordinates: dict[int, Point3D] = {}
    for node, point in raw_local_coordinates.items():
        u_value = min(expected_u, key=lambda value: abs(point[u_axis] - value))
        v_value = min(expected_v, key=lambda value: abs(point[v_axis] - value))
        snapped = [0.0, 0.0, 0.0]
        snapped[u_axis] = u_value
        snapped[v_axis] = v_value
        snapped[plane_axis] = origin[plane_axis]
        expected = tuple(snapped)
        if math.dist(point, expected) > snap_tolerance:
            raise GmshCartesianTensorSurfaceError(
                "Gmsh tensor node escaped its requested Cartesian grid"
            )
        coordinates[node] = expected  # type: ignore[assignment]
    if len(set(coordinates.values())) != len(coordinates):
        raise GmshCartesianTensorSurfaceError(
            "Gmsh tensor rectangle contains coincident snapped nodes"
        )
    maximum_edge = max(
        math.dist(coordinates[first], coordinates[second])
        for facet in facets
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    tolerance = max(_TOLERANCE_MM, target * 1.0e-10)
    if any(
        abs(point[plane_axis] - origin[plane_axis]) > tolerance
        for point in coordinates.values()
    ):
        raise GmshCartesianTensorSurfaceError(
            "Gmsh tensor nodes left the requested Cartesian plane"
        )
    u_levels = sorted(set(expected_u))
    v_levels = sorted(set(expected_v))
    if len(u_levels) != u_intervals + 1 or len(v_levels) != v_intervals + 1:
        raise GmshCartesianTensorSurfaceError(
            "Gmsh tensor rectangle has incomplete axis levels"
        )
    u_index = {value: index for index, value in enumerate(u_levels)}
    v_index = {value: index for index, value in enumerate(v_levels)}
    cells: set[tuple[int, int]] = set()
    for facet in facets:
        indices_u = sorted(
            {u_index[coordinates[node][u_axis]] for node in facet}
        )
        indices_v = sorted(
            {v_index[coordinates[node][v_axis]] for node in facet}
        )
        if (
            len(indices_u) != 2
            or indices_u[1] != indices_u[0] + 1
            or len(indices_v) != 2
            or indices_v[1] != indices_v[0] + 1
        ):
            raise GmshCartesianTensorSurfaceError(
                "Gmsh emitted a split or non-Cartesian tensor cell"
            )
        cells.add((indices_u[0], indices_v[0]))
    expected_cells = {
        (u_index_value, v_index_value)
        for u_index_value in range(u_intervals)
        for v_index_value in range(v_intervals)
    }
    if cells != expected_cells or len(cells) != len(facets):
        raise GmshCartesianTensorSurfaceError(
            "Gmsh tensor rectangle contains a hole or overlapping cell"
        )
    return GmshCartesianTensorSurface(
        MappingProxyType(coordinates),
        facets,  # type: ignore[arg-type]
        u_intervals,
        v_intervals,
        target,
        maximum_edge,
    )


__all__ = [
    "GmshCartesianTensorSurface",
    "GmshCartesianTensorSurfaceError",
    "generate_gmsh_cartesian_tensor_rectangle",
]
