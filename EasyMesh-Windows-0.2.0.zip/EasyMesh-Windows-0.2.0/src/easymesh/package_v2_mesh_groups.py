"""Read only the bounded metadata prefix of a current ASCII MSH 4.1 file."""
from collections import Counter, OrderedDict
from threading import RLock
from dataclasses import dataclass
from pathlib import Path
import shlex
import math
from types import MappingProxyType
from typing import Mapping

from .package_v2_mesh_names import mesh_group_name_error

MAX_GROUP_METADATA_BYTES = 2 * 1024 * 1024
_catalogs = OrderedDict()
_catalog_lock = RLock()


def mesh_file_signature(path):
    value = Path(path).stat()
    return value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns


@dataclass(frozen=True)
class MeshVolumeGroup:
    tag: int
    name: str
    entities: tuple[int, ...]
    error: str = ""


@dataclass(frozen=True)
class MeshVolumeGroups:
    path: Path
    signature: tuple[int, ...]
    groups: tuple[MeshVolumeGroup, ...]
    metadata_bytes: int
    entity_bounds: Mapping[int, tuple[float, ...]]

    def bounds_for(self, names):
        entities = {entity for group in self.groups if group.name in names for entity in group.entities}
        if not entities:
            return None
        bounds = [self.entity_bounds[tag] for tag in entities]
        return (tuple(min(box[axis] for box in bounds) for axis in range(3)),
                tuple(max(box[axis + 3] for box in bounds) for axis in range(3)))

    def selection_error(self, names):
        if not names:
            return "请勾选至少一个网格内体分组。"
        selected = []
        for name in names:
            matches = [group for group in self.groups if group.name == name]
            if len(matches) != 1:
                return f"体分组 {name!r} 不存在或名称重复。"
            if matches[0].error:
                return f"体分组 {name!r}：{matches[0].error}"
            selected.append(matches[0])
        memberships = Counter(entity for group in selected for entity in group.entities)
        if any(count > 1 for count in memberships.values()):
            return "所选分组有重叠，请取消重复覆盖同一部分的分组。"
        return ""

    def default_selection(self):
        if not self.selection_error(("ALL_SOLID_VOLUMES",)):
            return ("ALL_SOLID_VOLUMES",)
        names = tuple(group.name for group in self.groups if not group.error)
        return names if names and not self.selection_error(names) else ()


def read_mesh_volume_groups(path, *, cancelled=lambda: False):
    path = Path(path).resolve()
    signature = mesh_file_signature(path)
    with _catalog_lock:
        if cancelled():
            raise InterruptedError("已取消网格分组读取")
        cached = _catalogs.get(path)
        if cached is not None and cached.signature == signature:
            _catalogs.move_to_end(path)
            return cached
        result = _read_mesh_volume_groups(path, cancelled=cancelled)
        _catalogs[path] = result
        _catalogs.move_to_end(path)
        while len(_catalogs) > 8:
            _catalogs.popitem(last=False)
        return result


def _read_mesh_volume_groups(path, *, cancelled=lambda: False):
    """Stop at the end of PhysicalNames/Entities; never scan Nodes or Elements."""
    path = Path(path).resolve()
    signature = mesh_file_signature(path)
    names, entity_groups, entity_bounds, seen = {}, {}, {}, set()
    with path.open("rb") as stream:
        def line():
            if cancelled():
                raise InterruptedError("已取消网格分组读取")
            remaining = MAX_GROUP_METADATA_BYTES - stream.tell()
            if remaining <= 0:
                raise ValueError("分组头部超过 2 MB，已停止读取，未扫描网格数据。")
            value = stream.readline(min(remaining, 65536) + 1)
            if len(value) > min(remaining, 65536):
                raise ValueError("分组头部过大，已停止读取，未扫描网格数据。")
            if not value:
                raise ValueError("网格文件头部缺少完整的体分组信息。")
            return value.strip()

        def integers(expected):
            values = tuple(int(value) for value in line().split())
            if len(values) != expected or any(value < 0 for value in values):
                raise ValueError("MSH 分组计数格式不正确。")
            return values

        if line() != b"$MeshFormat" or line().split() != [b"4.1", b"0", b"8"] or line() != b"$EndMeshFormat":
            raise ValueError("当前网格实例要求 ASCII Gmsh MSH 4.1 文件。")
        while seen != {b"$PhysicalNames", b"$Entities"}:
            section = line()
            if not section:
                continue
            if section in seen:
                raise ValueError("MSH 包含重复的分组区段。")
            if section == b"$PhysicalNames":
                seen.add(section)
                for _ in range(integers(1)[0]):
                    parts = shlex.split(line().decode("utf-8"))
                    if len(parts) != 3:
                        raise ValueError("MSH PhysicalNames 格式不正确。")
                    dimension, tag = int(parts[0]), int(parts[1])
                    if dimension == 3:
                        if tag < 1 or tag in names:
                            raise ValueError("MSH 体分组标签不正确或重复。")
                        names[tag] = parts[2]
                if line() != b"$EndPhysicalNames":
                    raise ValueError("MSH PhysicalNames 区段不完整。")
            elif section == b"$Entities":
                seen.add(section)
                for dimension, count in enumerate(integers(4)):
                    for _ in range(count):
                        row = line().split()
                        if dimension != 3:
                            continue
                        if len(row) < 9:
                            raise ValueError("MSH 体实体的分组记录不完整。")
                        tag, number = int(row[0]), int(row[7])
                        bounds = tuple(float(value) for value in row[1:7])
                        if (any(not math.isfinite(value) for value in bounds)
                                or any(bounds[i] > bounds[i + 3] for i in range(3))):
                            raise ValueError("MSH 体范围记录不正确。")
                        if tag < 1 or number < 0 or len(row) < 9 + number or tag in entity_groups:
                            raise ValueError("MSH 体实体的分组记录不正确。")
                        groups = tuple(int(value) for value in row[8:8 + number])
                        boundaries = int(row[8 + number])
                        if (len(set(groups)) != len(groups) or any(value < 1 for value in groups)
                                or boundaries < 0 or len(row) != 9 + number + boundaries):
                            raise ValueError("MSH 体实体的分组记录不正确。")
                        entity_groups[tag] = groups
                        entity_bounds[tag] = bounds
                if line() != b"$EndEntities":
                    raise ValueError("MSH Entities 区段不完整。")
            else:
                # An unfamiliar section can contain arbitrarily large data.
                # Respect the user's request: do not search the rest of the MSH.
                raise ValueError("分组信息不在文件头部，未扫描后面的网格数据。")
        metadata_bytes = stream.tell()
    name_counts = Counter(names.values())
    entities_by_group = {}
    for entity, tags in entity_groups.items():
        for tag in tags:
            entities_by_group.setdefault(tag, []).append(entity)
    groups = []
    for tag, name in sorted(names.items()):
        entities = tuple(entities_by_group.get(tag, ()))
        error = ""
        if name_counts[name] > 1:
            error = "网格中存在同名体分组，无法唯一定位"
        elif mesh_group_name_error(name):
            error = mesh_group_name_error(name)
        elif not entities:
            error = "该分组没有体实体"
        groups.append(MeshVolumeGroup(tag, name, entities, error))
    if not groups:
        raise ValueError("文件头部没有已命名的体分组（Physical Volume）。")
    if mesh_file_signature(path) != signature:
        raise ValueError("读取期间网格文件发生变化，请重新读取。")
    return MeshVolumeGroups(path, signature, tuple(groups), metadata_bytes, MappingProxyType(entity_bounds))
