"""Human-readable warning text; the report remains the technical evidence."""

from html import escape
import math
import re


def component_label(identifier: str) -> str:
    """Decode length-prefixed IDs without confusing underscores in names."""
    match = re.match(r"v2[gf]_o(\d+)_", identifier)
    if match:
        end = match.end() + int(match[1])
        local = re.fullmatch(r"_l(\d+)_(.*)", identifier[end:])
        if local and len(local[2]) == int(local[1]):
            return f"{local[2]}（{identifier[match.end():end]}）"
    return identifier or "未指定部件"


def _um(value) -> str:
    if isinstance(value, (int, float)) and math.isfinite(value):
        return f"{value * 1000:,.6g}"
    return "—"


def is_orthogonal_error(diagnostic):
    return (
        isinstance(diagnostic, dict)
        and diagnostic.get("severity") == "error"
        and str(diagnostic.get("code", "")).startswith("orth_")
    )


def orthogonal_error_message(diagnostic):
    """One concrete blocking message, shared by the worker, GUI and log."""
    components = "、".join(
        component_label(str(v)) for v in diagnostic.get("component_ids", ())
    )
    sources = diagnostic.get("sources", ())
    origins = []
    for source in sources:
        text = component_label(str(source.get("component_id", "")))
        if source.get("interface_id"):
            text += " / " + str(source["interface_id"])
        if text not in origins:
            origins.append(text)
    if diagnostic.get("sources_truncated"):
        origins.append(
            f"另有 {diagnostic.get('source_count',32)-32} 个来源；此处仅列出前 32 个"
        )
    titles = {
        "orth_geometry_unsupported": "Orth 几何暂不支持，生成已中止。",
        "orth_geometry_overlap": "Orth 几何归属不明确，生成已中止。",
        "orth_empty_geometry": "Orth 几何没有可生成的单元，生成已中止。",
        "orth_interface_not_quad": "Orth 接口含非 QUAD 面，生成已中止。",
        "orth_interface_not_cartesian": "Orth 接口不是轴对齐矩形，生成已中止。",
        "orth_locked_quad_exit_conflict": "Orth 几何出口切开固定 QUAD，生成已中止。",
        "orth_coordinate_frame_unsupported": "Orth 坐标方向不兼容，生成已中止。",
        "orth_dependency_conflict": "Orth 接口生产依赖无法执行，生成已中止。",
        "orth_seed_resolution_failed": "Orth 网格尺寸无法解析，生成已中止。",
    }
    axis = diagnostic.get("axis")
    coords = diagnostic.get("coordinates_mm", ())
    position = f"冲突方向：{axis}" if axis else ""
    if coords:
        position += "；位置：" + "、".join(_um(v) for v in coords) + " µm"
    bounds = diagnostic.get("bounds_package_mm")
    if bounds:
        position += "；区域：" + "，".join(
            f"{a}={_um(b[0])}–{_um(b[1])} µm" for a, b in zip("XYZ", bounds)
        )
    return "\n".join(
        v
        for v in (
            titles.get(diagnostic.get("code"), "Orth 接口网格不兼容，生成已中止。"),
            "Orth 组件：" + components if components else "",
            str(diagnostic.get("reason", "")),
            "接口来源：" + "；".join(origins) if origins else "",
            position,
            "Orth 仅支持严格正交 HEX8，不使用过渡网格。",
            "请检查上述几何、尺寸和固定接口划分后重新生成。",
            "本次未生成可导出的完整网格。",
        )
        if v
    )


def contact_error_text(diagnostic):
    """Use the same measured contact evidence in logs and result cards."""
    producer = component_label(str(diagnostic.get("component_id", "")))
    consumer = component_label(str(diagnostic.get("adjacent_component_id", "")))
    detail = (f"{producer} 与 {consumer} 的接触边界穿过了已生成的表面单元。"
              "该单元一部分位于接触区内，另一部分位于接触区外，无法形成完整的共享接触面。")
    positions = [
        f"先生成部件的局部 {item['axis']} = {_um(item['coordinate_mm'])} µm；"
        f"跨界单元范围 {_um(item['facet_range_mm'][0])}–{_um(item['facet_range_mm'][1])} µm。"
        for item in diagnostic.get("contact_boundaries_local_mm", ())
    ]
    if diagnostic.get("backend") == "structured_sweep":
        advice = ("请让扫掠分层包含上述接触边界位置；可调整层厚，或检查网格优先级，"
                  "让相邻部件先提供接触面分割，再重新生成。若仍无法对齐，需修复生成前的接触边界分割。")
    else:
        advice = ("请调整先生成部件的网格分割，使单元边界与接触边界对齐；"
                  "也可检查相邻部件的网格优先级。若仍无法对齐，需修复生成前的接触边界分割。")
    return detail, "\n".join(positions), advice


def contact_error_message(diagnostic):
    detail, position, advice = contact_error_text(diagnostic)
    return "\n".join(value for value in (
        "接触边界未对齐，网格生成已中止。", detail, position,
        "建议：" + advice, "本次未生成可导出的完整网格。",
    ) if value)


def report_warnings(report):
    """Expose recorded sizing adjustments, including in existing signed reports.

    The authoring request and the report remain unchanged. Older v28 reports
    store the effective transition only in backend evidence.
    """
    execution = report.get("execution", {})
    warnings = list(execution.get("mesh_warnings", ()))
    components = execution.get("components", {})
    if not isinstance(components, dict):
        return warnings
    code = "hybrid_transition_distance_adjusted"
    recorded = {(w.get("component_id"), w.get("fragment_id"))
                for w in warnings if w.get("code") == code}
    for component_id, component in components.items():
        for fragment_id, evidence in component.get("backend_evidence_by_fragment_id", {}).items():
            if not evidence.get("compatibility_growth_used") or (component_id, fragment_id) in recorded:
                continue
            requested = evidence.get("requested_transition_distance_mm")
            effective = evidence.get("effective_transition_distance_mm")
            if not all(type(v) in (int, float) and math.isfinite(v) and v > 0
                       for v in (requested, effective)):
                continue
            if math.isclose(requested, effective, rel_tol=1.e-12, abs_tol=0.):
                continue
            warnings.append({"code": code, "component_id": component_id, "fragment_id": fragment_id,
                "severity": "warning", "export_allowed": True,
                "requested_transition_distance_mm": requested,
                "effective_transition_distance_mm": effective,
                "target_edge_mm": component.get("requested", {}).get("target_edge_mm"),
                "message": f"Hybrid 过渡距离：请求 {_um(requested)} µm；运行采用 {_um(effective)} µm。",
            })
    return warnings


def _location(warning) -> str:
    if warning.get("code") == "partial_contact_boundary_cuts_facet":
        position = contact_error_text(warning)[1]
        if position:
            return position
    low = warning.get("actual_top_local_z_mm")
    high = warning.get("analytic_top_local_z_mm")
    if low is not None and high is not None:
        return f"局部 Z = {_um(low)}–{_um(high)} µm；网格止于 {_um(low)} µm，原几何延伸至 {_um(high)} µm。"
    points = []
    for location in warning.get("locations", ())[:3]:
        coordinates = location.get("coordinates_package_mm")
        if coordinates is not None:
            points.append("封装坐标 (X, Y, Z) = (" + ", ".join(map(_um, coordinates)) + ") µm")
        elif location.get("bounds_local_mm"):
            points.append("局部单元范围：" + "；".join(
                f"{axis} = {_um(bounds[0])}–{_um(bounds[1])} µm"
                for axis, bounds in zip("XYZ", location["bounds_local_mm"])
            ))
    if points and (len(warning.get("locations", ())) > 3 or warning.get("locations_truncated")):
        points.append("以上为部分位置；完整记录见原始报告。")
    return "\n".join(points)


def warning_html(warnings) -> str:
    """Format known diagnostics as cards, preserving unknown warning messages."""
    cards = []
    sides = {"die_x_min": "−X", "die_x_max": "+X", "die_y_min": "−Y", "die_y_max": "+Y"}
    for index, warning in enumerate(warnings, 1):
        code = warning.get("code", "")
        title = "网格警告"
        detail = str(warning.get("message", "报告未提供说明。"))
        advice = ""
        if is_orthogonal_error(warning):
            title = "Orth 网格错误 · 生成已中止"
            detail = orthogonal_error_message(warning)
        elif code == "partial_contact_boundary_cuts_facet":
            title = "接触边界未对齐 · 生成已中止"
            detail, _position, advice = contact_error_text(warning)
        elif code == "orthogonal_side_tip_truncated":
            side = sides.get(warning.get("geometric_side"), str(warning.get("geometric_side", "")))
            title = f"{side} 侧网格顶部缺失"
            detail = "这段几何内没有候选体单元的中心，因此单元被删除。此处没有 Orth 体单元，与邻接部件也没有共享 QUAD 接触面。"
            advice = "需要保留这段接触时，请细化该侧法向网格或简化几何。若分割继承自相邻部件，需调整提供分割的部件。"
        elif code == "orthogonal_tip_truncated":
            title = "网格顶部缺失"
            detail = "顶部没有候选体单元的中心落入几何，中心筛选后网格被截短。"
            advice = "需要保留顶部细节时，请细化网格尺寸或简化几何。"
        elif code == "orthogonal_edge_or_point_contact":
            title = "单元仅靠边或点连接"
            detail = "中心筛选后，局部单元仅通过边或点相连，没有完整的公共面。"
            advice = "请细化问题位置附近的网格尺寸，或简化该处几何。"
        elif code == "orthogonal_disconnected_cells":
            title = "网格未连成一个整体"
            count = warning.get("connected_component_count")
            detail = f"中心筛选后，体单元分成 {count} 个通过面连接的部分。" if count else "中心筛选后，体单元未通过面连成一个整体。"
            advice = "请检查问题位置，细化局部网格尺寸或简化几何。"
        elif code in {"hybrid_sweep_fallback", "hybrid_tet_unavailable"}:
            title = "Hybrid 已回退为 Sweep" if code == "hybrid_sweep_fallback" else "Hybrid 未生成 TET"
            detail = "TET 路径未通过检查，当前结果未实现通过 TET 加粗内部网格。"
            if code == "hybrid_sweep_fallback":
                detail += "已使用 HEX / WEDGE 单元。"
            advice = "请检查网格尺寸和接触面约束；具体 TET 失败原因保留在原始报告中。"
        elif code == "hybrid_transition_distance_adjusted":
            title = "Hybrid 过渡距离已自动调整"
            detail = (
                f"请求过渡距离：{_um(warning.get('requested_transition_distance_mm'))} µm；"
                f"运行采用：{_um(warning.get('effective_transition_distance_mm'))} µm。"
                f"目标网格尺寸：{_um(warning.get('target_edge_mm'))} µm。"
                "程序采用调整后的尺寸分布，生成了通过检查的网格。"
            )
            advice = ("Job 和设置摘要保留用户请求值，本项显示该次运行的采用值。"
                      "过渡距离控制目标尺寸分布；实际单元边长会有差异，"
                      "不能根据个别边长判断整个过渡是否完成。")

        def paragraph(label, value):
            return f"<p><b>{label}</b>　{escape(str(value)).replace(chr(10), '<br>')}</p>" if value else ""

        ids = warning.get("element_ids", ())
        marked = f"{len(set(ids)):,} 个标记单元" if ids else ""
        element_set = warning.get("element_set_name")
        if element_set:
            marked += f"；单元集 {element_set}" if marked else f"单元集 {element_set}"
        if ids and code in {"orthogonal_side_tip_truncated", "orthogonal_tip_truncated"}:
            marked += "（标记的是缺失区下缘仍保留的单元）"
        export = "报告标记为不允许导出" if warning.get("export_allowed") is False else "允许导出；请根据上述影响判断是否需要调整后重新生成。"
        if code == "partial_contact_boundary_cuts_facet":
            export = "本次生成已中止，未生成可导出的完整网格。"
        cards.append(
            f"<h3>{index}. {escape(title)}</h3>"
            + paragraph("部件", component_label(str(warning.get("component_id", ""))))
            + paragraph("位置", _location(warning))
            + paragraph("说明", detail)
            + paragraph("建议", advice)
            + paragraph("定位", marked)
            + paragraph("导出", export)
        )
    return "<html><head><style>h3 { margin-top: 8px; margin-bottom: 8px; } p { margin-top: 5px; margin-bottom: 5px; }</style></head><body>" + "<hr>".join(cards) + "</body></html>"
