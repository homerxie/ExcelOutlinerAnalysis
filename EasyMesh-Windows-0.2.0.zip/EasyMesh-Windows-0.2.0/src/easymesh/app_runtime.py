"""Cross-platform runtime helpers shared by the Qt controller.

The GUI can run from a source checkout, an installed wheel, or a frozen
application.  Worker processes must use the same Python/application without
assuming that ``run_demo.py`` or a writable repository checkout exists.
"""

from __future__ import annotations

import os
import subprocess
import sys
from collections.abc import Mapping
from importlib import resources
from pathlib import Path
import tempfile


def source_project_root() -> Path | None:
    """Return the repository root when running from an EasyMesh checkout."""

    candidate = Path(__file__).resolve().parents[2]
    if (
        (candidate / "pyproject.toml").is_file()
        and (candidate / "src" / "easymesh").is_dir()
    ):
        return candidate
    return None


def runtime_workspace_root(
    *,
    documents_location: str | Path | None = None,
    environment: Mapping[str, str] | None = None,
) -> Path:
    """Return a writable workspace for source, installed, and frozen builds.

    A source checkout keeps its existing ``examples`` and ``output`` layout.
    Installed applications default to the user's Documents directory.  The
    ``EASYMESH_HOME`` environment variable is an explicit override on every
    platform and is useful for managed or portable installations.
    """

    values = os.environ if environment is None else environment
    configured = values.get("EASYMESH_HOME", "").strip()
    if configured:
        configured_path = Path(configured).expanduser()
        if not configured_path.is_absolute():
            configured_path = Path.home() / configured_path
        return configured_path.resolve()
    project_root = source_project_root()
    if project_root is not None:
        return project_root
    documents = (
        Path(documents_location).expanduser()
        if documents_location
        else Path.home() / "Documents"
    )
    return (documents / "EasyMesh").resolve()


def prepare_runtime_workspace(root: str | Path) -> Path:
    """Create writable folders and seed an editable Layer example.

    Source checkouts already contain the example. Installed wheels and frozen
    applications instead receive a real copy in the user's workspace, never a
    path inside a read-only package or application bundle.
    """

    workspace = Path(root).expanduser().resolve()
    examples = workspace / "examples"
    output = workspace / "output"
    examples.mkdir(parents=True, exist_ok=True)
    output.mkdir(parents=True, exist_ok=True)
    default_layer = examples / "bumpcell.layer"
    if not default_layer.exists():
        layer_text = (
            resources.files("easymesh")
            .joinpath("resources")
            .joinpath("bumpcell.layer")
            .read_text(encoding="utf-8")
        )
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=".bumpcell.", suffix=".layer", dir=examples
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(
                descriptor, "w", encoding="utf-8", newline="\n"
            ) as stream:
                stream.write(layer_text)
            if not default_layer.exists():
                os.replace(temporary, default_layer)
        finally:
            temporary.unlink(missing_ok=True)
    return workspace


def worker_command_prefix() -> list[str]:
    """Return the executable prefix used for one background mesh worker."""

    if bool(getattr(sys, "frozen", False)):
        return [sys.executable, "--worker"]
    if sys.platform == "win32" and Path(sys.executable).name.lower() == "pythonw.exe":
        # GUI entry points use pythonw, whose standard streams may be None.
        # The contact service requires stdin/stdout and mesh jobs require logs.
        # Use the console interpreter from the SAME environment; Popen/QProcess
        # control window visibility independently of the interpreter choice.
        executable = Path(sys.executable).with_name("python.exe")
        if not executable.is_file():
            raise RuntimeError(f"后台任务所需的 Python 解释器不存在：{executable}")
        return [str(executable), "-m", "easymesh", "--worker"]
    return [sys.executable, "-m", "easymesh", "--worker"]


def worker_environment(
    base: Mapping[str, str] | None = None,
) -> dict[str, str]:
    """Build a deterministic UTF-8 worker environment.

    Direct ``run_demo.py`` execution adds ``src`` only to the parent process'
    ``sys.path``.  Propagating the checkout's source directory through
    ``PYTHONPATH`` keeps ``python -m easymesh`` valid without relying on a
    particular current working directory.
    """

    environment = dict(os.environ if base is None else base)
    environment["PYTHONUTF8"] = "1"
    environment["PYTHONIOENCODING"] = "utf-8"
    project_root = source_project_root()
    if project_root is not None:
        source_path = str(project_root / "src")
        existing = environment.get("PYTHONPATH", "")
        entries = [entry for entry in existing.split(os.pathsep) if entry]
        if source_path not in entries:
            environment["PYTHONPATH"] = os.pathsep.join([source_path, *entries])
    return environment


def worker_popen_options() -> dict[str, object]:
    """Return platform-specific ``subprocess.Popen`` keyword arguments."""

    options: dict[str, object] = {
        "env": worker_environment(),
        # Mesh jobs never consume input. A GUI launched without a console can
        # have no valid inherited stdin handle on Windows.
        "stdin": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        no_window = int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if no_window:
            options["creationflags"] = no_window
    return options


__all__ = [
    "prepare_runtime_workspace",
    "runtime_workspace_root",
    "source_project_root",
    "worker_command_prefix",
    "worker_environment",
    "worker_popen_options",
]
