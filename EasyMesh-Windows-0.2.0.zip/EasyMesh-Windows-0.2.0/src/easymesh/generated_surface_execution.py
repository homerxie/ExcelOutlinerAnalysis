"""Execution planning for generated shared surfaces.

The planner in this module is deliberately independent from package roles,
materials and stack position.  A continuity group is the neutral owner of its
surface mesh.  Component volume backends are consumers of that mesh; they do
not independently create, trim or repair the common face.

The group policy selects exactly one surface backend:

* ``shared_cartesian_quad`` -> ``cartesian_quad_surface``;
* ``shared_inherited_sweep_surface`` -> ``inherited_sweep_surface``;
* ``shared_gmsh_conformal_surface`` -> ``gmsh_shared_surface``.

For a group containing several geometrically equivalent faces, the smallest
interface ID is used only as a deterministic scheduling root.  Every other
face must be reachable through a unique tree of already-proven transport
links.  The root choice never changes topology, target size, transition size
or geometry.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import heapq
from types import MappingProxyType
from typing import Literal, TypeAlias

from .component_interface import (
    ComponentMeshRequirement,
    NegotiatedComponentInterface,
)
from .generated_interface_continuity import (
    GeneratedSurfaceEquivalenceGroup,
    SurfaceTransportLink,
    plan_generated_interface_continuity,
)


SurfaceProducerBackend: TypeAlias = Literal[
    "cartesian_quad_surface",
    "inherited_sweep_surface",
    "gmsh_shared_surface",
]
SurfaceExecutionOperation: TypeAlias = Literal[
    "produce_neutral_surface",
    "transport_equivalent_surface",
    "volume_backend_ready",
]


class GeneratedSurfaceExecutionError(ValueError):
    """Raised when a unique, proven surface execution DAG cannot be built."""


@dataclass(frozen=True, slots=True)
class SurfaceExecutionStep:
    """One node in the generated-surface execution DAG."""

    step_id: str
    operation: SurfaceExecutionOperation
    backend: str
    group_id: str | None
    neutral_surface_owner_id: str | None
    component_id: str | None
    input_interface_ids: tuple[str, ...]
    output_interface_ids: tuple[str, ...]
    depends_on_step_ids: tuple[str, ...]
    transport_direction_xyz: tuple[float, float, float] | None = None
    transport_distance_mm: float | None = None
    section_signature: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "step_id": self.step_id,
            "operation": self.operation,
            "backend": self.backend,
            "group_id": self.group_id,
            "neutral_surface_owner_id": self.neutral_surface_owner_id,
            "component_id": self.component_id,
            "input_interface_ids": list(self.input_interface_ids),
            "output_interface_ids": list(self.output_interface_ids),
            "depends_on_step_ids": list(self.depends_on_step_ids),
            "transport_direction_xyz": (
                None
                if self.transport_direction_xyz is None
                else list(self.transport_direction_xyz)
            ),
            "transport_distance_mm": self.transport_distance_mm,
            "section_signature": self.section_signature,
        }


@dataclass(frozen=True, slots=True)
class SurfaceGroupExecution:
    """Neutral ownership and materialization contract for one group."""

    group_id: str
    neutral_surface_owner_id: str
    producer_backend: SurfaceProducerBackend
    surface_policy: str
    permitted_surface_element_kinds: tuple[str, ...]
    root_interface_id: str
    root_selection_reason: str
    interface_ids: tuple[str, ...]
    consumer_component_ids: tuple[str, ...]
    consumer_interface_ids_by_component: Mapping[str, tuple[str, ...]]
    target_edge_mm: float
    transition_distance_mm_by_component: Mapping[str, float]
    producer_step_id: str
    transport_step_ids: tuple[str, ...]
    materializer_step_id_by_interface: Mapping[str, str]

    def to_dict(self) -> dict[str, object]:
        return {
            "group_id": self.group_id,
            "neutral_surface_owner_id": self.neutral_surface_owner_id,
            "producer_backend": self.producer_backend,
            "surface_policy": self.surface_policy,
            "permitted_surface_element_kinds": list(
                self.permitted_surface_element_kinds
            ),
            "root_interface_id": self.root_interface_id,
            "root_selection_reason": self.root_selection_reason,
            "interface_ids": list(self.interface_ids),
            "consumer_component_ids": list(self.consumer_component_ids),
            "consumer_interface_ids_by_component": {
                key: list(value)
                for key, value in self.consumer_interface_ids_by_component.items()
            },
            "target_edge_mm": self.target_edge_mm,
            "transition_distance_mm_by_component": dict(
                self.transition_distance_mm_by_component
            ),
            "producer_step_id": self.producer_step_id,
            "transport_step_ids": list(self.transport_step_ids),
            "materializer_step_id_by_interface": dict(
                self.materializer_step_id_by_interface
            ),
        }


@dataclass(frozen=True, slots=True)
class GeneratedSurfaceExecutionPlan:
    """Auditable, topologically sorted shared-surface execution plan."""

    groups: tuple[SurfaceGroupExecution, ...]
    transport_links: tuple[SurfaceTransportLink, ...]
    steps: tuple[SurfaceExecutionStep, ...]
    execution_order: tuple[str, ...]
    volume_ready_step_id_by_component: Mapping[str, str]
    step_by_id: Mapping[str, SurfaceExecutionStep]
    sweep_direction_xyz_by_component: Mapping[
        str, tuple[float, float, float]
    ]

    def to_dict(self) -> dict[str, object]:
        return {
            "groups": [group.to_dict() for group in self.groups],
            "transport_links": [
                link.to_dict() for link in self.transport_links
            ],
            "steps": [step.to_dict() for step in self.steps],
            "execution_order": list(self.execution_order),
            "volume_ready_step_id_by_component": dict(
                self.volume_ready_step_id_by_component
            ),
            "sweep_direction_xyz_by_component": {
                component_id: list(direction)
                for component_id, direction in sorted(
                    self.sweep_direction_xyz_by_component.items()
                )
            },
        }


_BACKEND_BY_POLICY: Mapping[str, SurfaceProducerBackend] = MappingProxyType(
    {
        "shared_cartesian_quad": "cartesian_quad_surface",
        "shared_inherited_sweep_surface": "inherited_sweep_surface",
        "shared_gmsh_conformal_surface": "gmsh_shared_surface",
    }
)


def _normalize_groups(
    groups: Sequence[GeneratedSurfaceEquivalenceGroup],
) -> tuple[GeneratedSurfaceEquivalenceGroup, ...]:
    if isinstance(groups, (str, bytes)) or not isinstance(groups, Sequence):
        raise GeneratedSurfaceExecutionError(
            "continuity_groups must be a sequence"
        )
    normalized = tuple(groups)
    if any(type(value) is not GeneratedSurfaceEquivalenceGroup for value in normalized):
        raise GeneratedSurfaceExecutionError(
            "continuity_groups must contain GeneratedSurfaceEquivalenceGroup only"
        )
    group_ids: set[str] = set()
    owner_by_interface: dict[str, str] = {}
    for group in normalized:
        if group.group_id in group_ids:
            raise GeneratedSurfaceExecutionError(
                f"multiple neutral surface owners use group ID {group.group_id!r}"
            )
        group_ids.add(group.group_id)
        if not group.interface_ids:
            raise GeneratedSurfaceExecutionError(
                f"continuity group {group.group_id!r} has no interfaces"
            )
        if len(set(group.interface_ids)) != len(group.interface_ids):
            raise GeneratedSurfaceExecutionError(
                f"continuity group {group.group_id!r} repeats an interface"
            )
        for interface_id in group.interface_ids:
            previous = owner_by_interface.get(interface_id)
            if previous is not None:
                raise GeneratedSurfaceExecutionError(
                    f"interface {interface_id!r} has multiple neutral surface "
                    f"owners: {previous!r} and {group.group_id!r}"
                )
            owner_by_interface[interface_id] = group.group_id
    return normalized


def _validate_canonical_groups(
    interfaces: Sequence[NegotiatedComponentInterface],
    groups: Sequence[GeneratedSurfaceEquivalenceGroup],
    links: Sequence[SurfaceTransportLink],
    requirements: Mapping[str, ComponentMeshRequirement],
    sweep_direction_xyz_by_component: Mapping[
        str, tuple[float, float, float]
    ] | None,
) -> tuple[
    tuple[NegotiatedComponentInterface, ...],
    tuple[GeneratedSurfaceEquivalenceGroup, ...],
    tuple[SurfaceTransportLink, ...],
    Mapping[str, str],
    Mapping[str, tuple[float, float, float]],
]:
    if isinstance(interfaces, (str, bytes)) or not isinstance(interfaces, Sequence):
        raise GeneratedSurfaceExecutionError("interfaces must be a sequence")
    normalized_interfaces = tuple(interfaces)
    normalized_groups = _normalize_groups(groups)
    if isinstance(links, (str, bytes)) or not isinstance(links, Sequence):
        raise GeneratedSurfaceExecutionError(
            "continuity_links must be a sequence"
        )
    normalized_links = tuple(links)
    if any(type(value) is not SurfaceTransportLink for value in normalized_links):
        raise GeneratedSurfaceExecutionError(
            "continuity_links must contain SurfaceTransportLink only"
        )
    try:
        canonical = plan_generated_interface_continuity(
            normalized_interfaces,
            requirements,
            sweep_direction_xyz_by_component=(
                sweep_direction_xyz_by_component
            ),
        )
    except ValueError as error:
        raise GeneratedSurfaceExecutionError(str(error)) from error

    provided_by_id = {value.group_id: value for value in normalized_groups}
    canonical_by_id = {value.group_id: value for value in canonical.groups}
    if provided_by_id != canonical_by_id:
        raise GeneratedSurfaceExecutionError(
            "continuity_groups are not the canonical result for the supplied "
            "interfaces, topology, target sizes, transition sizes and transport "
            "evidence"
        )
    if normalized_links != canonical.transport_links:
        raise GeneratedSurfaceExecutionError(
            "continuity_links are not the canonical transport proof for the "
            "supplied interfaces and Component requirements"
        )
    return (
        tuple(sorted(normalized_interfaces, key=lambda value: value.interface_id)),
        tuple(sorted(normalized_groups, key=lambda value: value.group_id)),
        normalized_links,
        MappingProxyType(
            {
                interface_id: group_id
                for interface_id, group_id in canonical.group_id_by_interface.items()
            }
        ),
        canonical.sweep_direction_xyz_by_component,
    )


def _validate_transport_tree(
    group: GeneratedSurfaceEquivalenceGroup,
    links: Sequence[SurfaceTransportLink],
    interface_by_id: Mapping[str, NegotiatedComponentInterface],
    requirements: Mapping[str, ComponentMeshRequirement],
) -> tuple[SurfaceTransportLink, ...]:
    interface_ids = frozenset(group.interface_ids)
    internal = tuple(
        sorted(
            (
                link
                for link in links
                if set(link.interface_ids).issubset(interface_ids)
            ),
            key=lambda value: (
                value.interface_ids,
                value.through_component_id,
            ),
        )
    )
    seen_edges: set[tuple[str, str]] = set()
    adjacency: dict[str, set[str]] = defaultdict(set)
    for link in internal:
        edge = tuple(sorted(link.interface_ids))
        if edge in seen_edges:
            raise GeneratedSurfaceExecutionError(
                f"continuity group {group.group_id!r} has multiple transport "
                f"owners for edge {edge!r}"
            )
        seen_edges.add(edge)
        through = link.through_component_id
        requirement = requirements.get(through)
        if requirement is None:
            raise GeneratedSurfaceExecutionError(
                f"transport component {through!r} has no mesh requirement"
            )
        if requirement.volume_topology not in {
            "structured_sweep",
            "orthogonal_hex",
        }:
            raise GeneratedSurfaceExecutionError(
                f"component {through!r} cannot transport a surface with "
                f"topology {requirement.volume_topology!r}"
            )
        for interface_id in link.interface_ids:
            interface = interface_by_id[interface_id]
            if through not in interface.component_ids:
                raise GeneratedSurfaceExecutionError(
                    f"transport proof for component {through!r} does not touch "
                    f"interface {interface_id!r}"
                )
        first, second = edge
        adjacency[first].add(second)
        adjacency[second].add(first)

    node_count = len(group.interface_ids)
    edge_count = len(internal)
    if node_count == 1:
        if edge_count:
            raise GeneratedSurfaceExecutionError(
                f"singleton continuity group {group.group_id!r} has a transport edge"
            )
        return ()
    if edge_count > node_count - 1:
        raise GeneratedSurfaceExecutionError(
            f"continuity group {group.group_id!r} has a cyclic or multiply-owned "
            "transport graph"
        )
    if edge_count < node_count - 1:
        raise GeneratedSurfaceExecutionError(
            f"continuity group {group.group_id!r} has no unique reachable "
            "transport tree proven by geometry"
        )
    root = min(group.interface_ids)
    reached = {root}
    pending = [root]
    while pending:
        current = pending.pop()
        for neighbour in adjacency.get(current, ()):
            if neighbour in reached:
                continue
            reached.add(neighbour)
            pending.append(neighbour)
    if reached != interface_ids:
        raise GeneratedSurfaceExecutionError(
            f"continuity group {group.group_id!r} has no unique reachable "
            "transport tree proven by geometry"
        )
    return internal


def _group_steps(
    group: GeneratedSurfaceEquivalenceGroup,
    links: Sequence[SurfaceTransportLink],
    interface_by_id: Mapping[str, NegotiatedComponentInterface],
    requirements: Mapping[str, ComponentMeshRequirement],
) -> tuple[
    SurfaceGroupExecution,
    tuple[SurfaceExecutionStep, ...],
]:
    try:
        backend = _BACKEND_BY_POLICY[group.surface_policy]
    except KeyError as error:
        raise GeneratedSurfaceExecutionError(
            f"continuity group {group.group_id!r} has unknown surface policy"
        ) from error
    internal = _validate_transport_tree(
        group,
        links,
        interface_by_id,
        requirements,
    )
    root = min(group.interface_ids)
    neutral_owner = f"neutral-generated-surface::{group.group_id}"
    producer_step_id = f"surface::{group.group_id}::produce::{root}"
    steps: list[SurfaceExecutionStep] = [
        SurfaceExecutionStep(
            step_id=producer_step_id,
            operation="produce_neutral_surface",
            backend=backend,
            group_id=group.group_id,
            neutral_surface_owner_id=neutral_owner,
            component_id=None,
            input_interface_ids=(),
            output_interface_ids=(root,),
            depends_on_step_ids=(),
        )
    ]
    materializer: dict[str, str] = {root: producer_step_id}
    remaining = list(internal)
    transport_step_ids: list[str] = []
    while remaining:
        candidates: list[
            tuple[str, str, str, SurfaceTransportLink]
        ] = []
        for link in remaining:
            first, second = link.interface_ids
            first_known = first in materializer
            second_known = second in materializer
            if first_known == second_known:
                continue
            source, target = (first, second) if first_known else (second, first)
            candidates.append((target, source, link.through_component_id, link))
        if not candidates:
            raise GeneratedSurfaceExecutionError(
                f"continuity group {group.group_id!r} transport tree is not "
                "uniquely reachable from its scheduling root"
            )
        target, source, through, link = min(candidates)
        step_id = (
            f"surface::{group.group_id}::transport::{through}::"
            f"{source}->{target}"
        )
        direction = link.direction_xyz
        if source != link.interface_ids[0]:
            direction = tuple(-value for value in direction)  # type: ignore[assignment]
        step = SurfaceExecutionStep(
            step_id=step_id,
            operation="transport_equivalent_surface",
            backend=requirements[through].volume_topology,
            group_id=group.group_id,
            neutral_surface_owner_id=neutral_owner,
            component_id=through,
            input_interface_ids=(source,),
            output_interface_ids=(target,),
            depends_on_step_ids=(materializer[source],),
            transport_direction_xyz=direction,
            transport_distance_mm=link.distance_mm,
            section_signature=link.section_signature,
        )
        steps.append(step)
        transport_step_ids.append(step_id)
        materializer[target] = step_id
        remaining.remove(link)

    incident: dict[str, list[str]] = defaultdict(list)
    for interface_id in group.interface_ids:
        for component_id in interface_by_id[interface_id].component_ids:
            incident[component_id].append(interface_id)
    consumers = tuple(sorted(incident))
    if consumers != group.component_ids:
        raise GeneratedSurfaceExecutionError(
            f"continuity group {group.group_id!r} consumer components are stale"
        )
    return (
        SurfaceGroupExecution(
            group_id=group.group_id,
            neutral_surface_owner_id=neutral_owner,
            producer_backend=backend,
            surface_policy=group.surface_policy,
            permitted_surface_element_kinds=group.permitted_surface_element_kinds,
            root_interface_id=root,
            root_selection_reason="canonical_schedule_only",
            interface_ids=group.interface_ids,
            consumer_component_ids=consumers,
            consumer_interface_ids_by_component=MappingProxyType(
                {
                    component_id: tuple(sorted(interface_ids))
                    for component_id, interface_ids in sorted(incident.items())
                }
            ),
            target_edge_mm=group.target_edge_mm,
            transition_distance_mm_by_component=MappingProxyType(
                dict(group.transition_distance_mm_by_component)
            ),
            producer_step_id=producer_step_id,
            transport_step_ids=tuple(transport_step_ids),
            materializer_step_id_by_interface=MappingProxyType(
                dict(sorted(materializer.items()))
            ),
        ),
        tuple(steps),
    )


def _topological_order(
    steps: Sequence[SurfaceExecutionStep],
) -> tuple[str, ...]:
    by_id: dict[str, SurfaceExecutionStep] = {}
    for step in steps:
        if step.step_id in by_id:
            raise GeneratedSurfaceExecutionError(
                f"execution step ID {step.step_id!r} has multiple owners"
            )
        by_id[step.step_id] = step
    successors: dict[str, list[str]] = defaultdict(list)
    indegree = {step_id: 0 for step_id in by_id}
    for step in steps:
        if len(set(step.depends_on_step_ids)) != len(step.depends_on_step_ids):
            raise GeneratedSurfaceExecutionError(
                f"execution step {step.step_id!r} repeats a dependency"
            )
        for dependency in step.depends_on_step_ids:
            if dependency not in by_id:
                raise GeneratedSurfaceExecutionError(
                    f"execution step {step.step_id!r} depends on unknown step "
                    f"{dependency!r}"
                )
            successors[dependency].append(step.step_id)
            indegree[step.step_id] += 1
    available = [step_id for step_id, degree in indegree.items() if degree == 0]
    heapq.heapify(available)
    ordered: list[str] = []
    while available:
        current = heapq.heappop(available)
        ordered.append(current)
        for successor in sorted(successors.get(current, ())):
            indegree[successor] -= 1
            if indegree[successor] == 0:
                heapq.heappush(available, successor)
    if len(ordered) != len(steps):
        cyclic = sorted(
            step_id for step_id, degree in indegree.items() if degree > 0
        )
        raise GeneratedSurfaceExecutionError(
            "generated surface execution dependencies contain a cycle: "
            + ", ".join(cyclic)
        )
    return tuple(ordered)


def plan_generated_interface_surface_execution(
    interfaces: Sequence[NegotiatedComponentInterface],
    continuity_groups: Sequence[GeneratedSurfaceEquivalenceGroup],
    continuity_links: Sequence[SurfaceTransportLink],
    requirements: Mapping[str, ComponentMeshRequirement],
    *,
    sweep_direction_xyz_by_component: Mapping[
        str, tuple[float, float, float]
    ] | None = None,
) -> GeneratedSurfaceExecutionPlan:
    """Create a neutral, role-free surface-production execution DAG.

    ``continuity_groups`` and ``continuity_links`` must be the exact canonical
    result for ``interfaces`` and ``requirements``.  The planner recomputes
    that result so stale sizes, forged merges and propagation without geometry
    evidence fail closed.  If any requirement uses ``structured_sweep``,
    ``sweep_direction_xyz_by_component`` is mandatory; this audit never infers
    an axis from the supplied faces.
    """

    (
        normalized_interfaces,
        normalized_groups,
        links,
        group_id_by_interface,
        explicit_sweep_directions,
    ) = _validate_canonical_groups(
        interfaces,
        continuity_groups,
        continuity_links,
        requirements,
        sweep_direction_xyz_by_component,
    )
    if not normalized_interfaces:
        return GeneratedSurfaceExecutionPlan(
            groups=(),
            transport_links=(),
            steps=(),
            execution_order=(),
            volume_ready_step_id_by_component=MappingProxyType({}),
            step_by_id=MappingProxyType({}),
            sweep_direction_xyz_by_component=explicit_sweep_directions,
        )
    interface_by_id = MappingProxyType(
        {value.interface_id: value for value in normalized_interfaces}
    )
    group_executions: list[SurfaceGroupExecution] = []
    steps: list[SurfaceExecutionStep] = []
    materializer_by_interface: dict[str, str] = {}
    for group in normalized_groups:
        execution, group_steps = _group_steps(
            group,
            links,
            interface_by_id,
            requirements,
        )
        group_executions.append(execution)
        steps.extend(group_steps)
        for interface_id, step_id in execution.materializer_step_id_by_interface.items():
            if interface_id in materializer_by_interface:
                raise GeneratedSurfaceExecutionError(
                    f"interface {interface_id!r} is materialized by multiple owners"
                )
            if group_id_by_interface[interface_id] != group.group_id:
                raise GeneratedSurfaceExecutionError(
                    f"interface {interface_id!r} is assigned to a stale group"
                )
            materializer_by_interface[interface_id] = step_id

    incident_interfaces: dict[str, list[str]] = defaultdict(list)
    for interface in normalized_interfaces:
        for component_id in interface.component_ids:
            incident_interfaces[component_id].append(interface.interface_id)
    volume_ready: dict[str, str] = {}
    for component_id, interface_ids in sorted(incident_interfaces.items()):
        requirement = requirements[component_id]
        ordered_interfaces = tuple(sorted(interface_ids))
        dependency_ids = tuple(
            sorted({materializer_by_interface[value] for value in ordered_interfaces})
        )
        step_id = f"volume::{component_id}::ready"
        volume_ready[component_id] = step_id
        steps.append(
            SurfaceExecutionStep(
                step_id=step_id,
                operation="volume_backend_ready",
                backend=requirement.volume_topology,
                group_id=None,
                neutral_surface_owner_id=None,
                component_id=component_id,
                input_interface_ids=ordered_interfaces,
                output_interface_ids=(),
                depends_on_step_ids=dependency_ids,
            )
        )
    execution_order = _topological_order(steps)
    step_by_id = {step.step_id: step for step in steps}
    return GeneratedSurfaceExecutionPlan(
        groups=tuple(group_executions),
        transport_links=links,
        steps=tuple(step_by_id[step_id] for step_id in execution_order),
        execution_order=execution_order,
        volume_ready_step_id_by_component=MappingProxyType(volume_ready),
        step_by_id=MappingProxyType(step_by_id),
        sweep_direction_xyz_by_component=explicit_sweep_directions,
    )


__all__ = [
    "GeneratedSurfaceExecutionError",
    "GeneratedSurfaceExecutionPlan",
    "SurfaceExecutionOperation",
    "SurfaceExecutionStep",
    "SurfaceGroupExecution",
    "SurfaceProducerBackend",
    "plan_generated_interface_surface_execution",
]
