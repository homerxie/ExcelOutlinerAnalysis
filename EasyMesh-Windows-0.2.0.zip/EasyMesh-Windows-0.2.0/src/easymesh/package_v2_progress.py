"""Versioned, non-authoritative progress events for Package V2 workers.

Progress is deliberately separate from the immutable Job and report-ready
artifact contract.  A consumer may use these events to explain what a live
worker is doing, but success still requires the final report and artifact
verification performed by the GUI.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import stat
import time
from typing import Callable, Mapping


PACKAGE_V2_PROGRESS_SCHEMA = "easymesh-package-v2-progress-v1"
PACKAGE_V2_PROGRESS_PHASE_COUNT = 8
PACKAGE_V2_PROGRESS_MAX_LINE_BYTES = 64 * 1024

_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_TOKEN = re.compile(r"[A-Za-z0-9_.:-]{1,160}\Z")
_STATES = frozenset({"started", "progress", "completed", "failed"})


class PackageV2ProgressError(ValueError):
    """Raised when a progress transport or event is malformed."""


@dataclass(frozen=True, slots=True)
class PackageV2ProgressUpdate:
    """One worker-owned update before transport metadata is attached."""

    job_id: str
    request_sha256: str
    phase: str
    phase_index: int
    state: str
    message: str
    current: int | None = None
    total: int | None = None
    unit: str | None = None
    mode: str | None = None
    diagnostic: dict[str, object] | None = None

    def __post_init__(self) -> None:
        if self.diagnostic is not None:
            if not isinstance(self.diagnostic, dict) or self.state != "failed":
                raise PackageV2ProgressError("failure diagnostic is invalid")
            try:
                encoded = json.dumps(self.diagnostic, ensure_ascii=False, allow_nan=False)
            except (TypeError, ValueError) as error:
                raise PackageV2ProgressError("failure diagnostic is not JSON data") from error
            if len(encoded.encode("utf-8")) > 32 * 1024:
                raise PackageV2ProgressError("failure diagnostic is too large")
        if not isinstance(self.job_id, str) or not self.job_id.strip():
            raise PackageV2ProgressError("progress job_id is invalid")
        if (
            not isinstance(self.request_sha256, str)
            or _SHA256.fullmatch(self.request_sha256) is None
        ):
            raise PackageV2ProgressError("progress request_sha256 is invalid")
        if not isinstance(self.phase, str) or _TOKEN.fullmatch(self.phase) is None:
            raise PackageV2ProgressError("progress phase is invalid")
        if (
            isinstance(self.phase_index, bool)
            or not isinstance(self.phase_index, int)
            or not 1 <= self.phase_index <= PACKAGE_V2_PROGRESS_PHASE_COUNT
        ):
            raise PackageV2ProgressError("progress phase_index is invalid")
        if self.state not in _STATES:
            raise PackageV2ProgressError("progress state is invalid")
        if (
            not isinstance(self.message, str)
            or not self.message.strip()
            or len(self.message) > 2_000
        ):
            raise PackageV2ProgressError("progress message is invalid")
        if (self.current is None) != (self.total is None):
            raise PackageV2ProgressError(
                "progress current and total must be supplied together"
            )
        if self.current is not None:
            if (
                isinstance(self.current, bool)
                or not isinstance(self.current, int)
                or isinstance(self.total, bool)
                or not isinstance(self.total, int)
                or self.total <= 0
                or not 0 <= self.current <= self.total
            ):
                raise PackageV2ProgressError("progress counter is invalid")
            if not isinstance(self.unit, str) or _TOKEN.fullmatch(self.unit) is None:
                raise PackageV2ProgressError("progress unit is invalid")
        elif self.unit is not None:
            raise PackageV2ProgressError(
                "progress unit requires current and total"
            )
        if self.mode is not None and (
            not isinstance(self.mode, str) or _TOKEN.fullmatch(self.mode) is None
        ):
            raise PackageV2ProgressError("progress mode is invalid")

    def to_jsonable(
        self,
        *,
        run_id: str,
        sequence: int,
        monotonic_ns: int,
    ) -> dict[str, object]:
        return {
            "schema": PACKAGE_V2_PROGRESS_SCHEMA,
            "run_id": run_id,
            "seq": sequence,
            "monotonic_ns": monotonic_ns,
            "job_id": self.job_id,
            "request_sha256": self.request_sha256,
            "phase": self.phase,
            "phase_index": self.phase_index,
            "phase_count": PACKAGE_V2_PROGRESS_PHASE_COUNT,
            "state": self.state,
            "message": self.message,
            "current": self.current,
            "total": self.total,
            "unit": self.unit,
            "mode": self.mode,
            **({"diagnostic": self.diagnostic} if self.diagnostic is not None else {}),
        }


PackageV2ProgressSink = Callable[[PackageV2ProgressUpdate], None]


class PackageV2ProgressJsonlWriter:
    """Create and flush one private JSONL progress stream."""

    def __init__(self, path: str | Path, *, run_id: str) -> None:
        self.path = Path(path)
        if not self.path.is_absolute() or self.path.suffix.lower() != ".jsonl":
            raise PackageV2ProgressError(
                "progress JSONL path must be an absolute .jsonl path"
            )
        if not isinstance(run_id, str) or _TOKEN.fullmatch(run_id) is None:
            raise PackageV2ProgressError("progress run_id is invalid")
        self.run_id = run_id
        self._stream: object | None = None
        self._sequence = 0
        self._last_update: PackageV2ProgressUpdate | None = None

    def __enter__(self) -> "PackageV2ProgressJsonlWriter":
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        for name in ("O_BINARY", "O_CLOEXEC", "O_NOFOLLOW"):
            flags |= int(getattr(os, name, 0))
        descriptor = os.open(self.path, flags, 0o600)
        try:
            if not stat.S_ISREG(os.fstat(descriptor).st_mode):
                raise PackageV2ProgressError(
                    "progress JSONL target must be a regular file"
                )
            self._stream = os.fdopen(
                descriptor,
                "w",
                encoding="utf-8",
                newline="\n",
                buffering=1,
            )
            descriptor = -1
        finally:
            if descriptor >= 0:
                os.close(descriptor)
        return self

    def __exit__(self, *_args: object) -> None:
        stream = self._stream
        self._stream = None
        if stream is not None:
            stream.close()  # type: ignore[attr-defined]

    def __call__(self, update: PackageV2ProgressUpdate) -> None:
        if not isinstance(update, PackageV2ProgressUpdate):
            raise PackageV2ProgressError(
                "progress writer requires PackageV2ProgressUpdate"
            )
        stream = self._stream
        if stream is None:
            raise PackageV2ProgressError("progress writer is not open")
        self._sequence += 1
        payload = update.to_jsonable(
            run_id=self.run_id,
            sequence=self._sequence,
            monotonic_ns=time.monotonic_ns(),
        )
        encoded = (
            json.dumps(
                payload,
                ensure_ascii=False,
                allow_nan=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        )
        if len(encoded.encode("utf-8")) > PACKAGE_V2_PROGRESS_MAX_LINE_BYTES:
            raise PackageV2ProgressError("progress JSONL event is too large")
        stream.write(encoded)  # type: ignore[attr-defined]
        stream.flush()  # type: ignore[attr-defined]
        self._last_update = update

    def fail(self, message: str) -> None:
        """Best-effort terminal event using the last known worker identity."""

        previous = self._last_update
        if previous is None:
            return
        try:
            self(
                PackageV2ProgressUpdate(
                    previous.job_id,
                    previous.request_sha256,
                    previous.phase,
                    previous.phase_index,
                    "failed",
                    message[:2_000] or "Package V2 worker failed",
                    mode=previous.mode,
                    diagnostic=previous.diagnostic,
                )
            )
        except (OSError, PackageV2ProgressError, UnicodeError):
            pass


def parse_package_v2_progress_event(
    line: bytes,
    *,
    expected_run_id: str,
    expected_job_id: str,
    expected_request_sha256: str,
    after_sequence: int,
) -> Mapping[str, object]:
    """Parse and identity-bind one complete JSONL line for the GUI."""

    if not isinstance(line, bytes) or not line or len(line) > (
        PACKAGE_V2_PROGRESS_MAX_LINE_BYTES
    ):
        raise PackageV2ProgressError("progress JSONL line size is invalid")
    try:
        payload = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise PackageV2ProgressError("progress JSONL line is invalid") from error
    if not isinstance(payload, dict):
        raise PackageV2ProgressError("progress JSONL event must be an object")
    if (
        payload.get("schema") != PACKAGE_V2_PROGRESS_SCHEMA
        or payload.get("run_id") != expected_run_id
        or payload.get("job_id") != expected_job_id
        or payload.get("request_sha256") != expected_request_sha256
    ):
        raise PackageV2ProgressError("progress JSONL identity does not match")
    sequence = payload.get("seq")
    monotonic_ns = payload.get("monotonic_ns")
    phase_count = payload.get("phase_count")
    if (
        isinstance(sequence, bool)
        or not isinstance(sequence, int)
        or sequence <= after_sequence
        or isinstance(monotonic_ns, bool)
        or not isinstance(monotonic_ns, int)
        or monotonic_ns < 0
        or phase_count != PACKAGE_V2_PROGRESS_PHASE_COUNT
    ):
        raise PackageV2ProgressError("progress JSONL sequence is invalid")
    update = PackageV2ProgressUpdate(
        str(payload.get("job_id")),
        str(payload.get("request_sha256")),
        str(payload.get("phase")),
        payload.get("phase_index"),  # type: ignore[arg-type]
        str(payload.get("state")),
        str(payload.get("message")),
        current=payload.get("current"),  # type: ignore[arg-type]
        total=payload.get("total"),  # type: ignore[arg-type]
        unit=payload.get("unit"),  # type: ignore[arg-type]
        mode=payload.get("mode"),  # type: ignore[arg-type]
        diagnostic=payload.get("diagnostic"),
    )
    canonical = update.to_jsonable(
        run_id=expected_run_id,
        sequence=sequence,
        monotonic_ns=monotonic_ns,
    )
    if payload != canonical:
        raise PackageV2ProgressError("progress JSONL event is not canonical")
    return payload


__all__ = [
    "PACKAGE_V2_PROGRESS_MAX_LINE_BYTES",
    "PACKAGE_V2_PROGRESS_PHASE_COUNT",
    "PACKAGE_V2_PROGRESS_SCHEMA",
    "PackageV2ProgressError",
    "PackageV2ProgressJsonlWriter",
    "PackageV2ProgressSink",
    "PackageV2ProgressUpdate",
    "parse_package_v2_progress_event",
]
