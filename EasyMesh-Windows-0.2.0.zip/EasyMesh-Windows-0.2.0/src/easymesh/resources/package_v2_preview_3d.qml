import QtQuick
import QtQuick3D

Rectangle {
    id: root
    width: 560
    height: 420
    color: backgroundColor

    property color backgroundColor: "#20252b"
    property color foregroundColor: "#d9e1e8"
    property var sceneModel: null
    property vector3d sceneOffset: Qt.vector3d(0, 0, 0)
    property vector3d coordinateOrigin: Qt.vector3d(0, 0, 0)
    property vector3d coordinateAxisX: Qt.vector3d(1, 0, 0)
    property vector3d coordinateAxisY: Qt.vector3d(0, 0, -1)
    property vector3d coordinateAxisZ: Qt.vector3d(0, 1, 0)
    property bool coordinateFrameIsLocal: false
    property var localCoordinateFrames: []
    property real sceneRadius: 1.0
    property real orbitYaw: -38.0
    property real orbitPitch: -24.0
    property real cameraDistance: 3.2
    property real zoomFactor: 1.0
    property real panX: 0.0
    property real panY: 0.0
    property bool hasScene: false
    property bool translucentMode: false
    property string emptyText: ""

    View3D {
        id: sceneView
        objectName: "sceneView"
        anchors.fill: parent
        renderMode: View3D.Offscreen
        environment: SceneEnvironment {
            backgroundMode: SceneEnvironment.Color
            clearColor: root.backgroundColor
            depthTestEnabled: true
            oitMethod: root.translucentMode
                ? SceneEnvironment.OITWeightedBlended
                : SceneEnvironment.OITNone
            antialiasingMode: SceneEnvironment.MSAA
            antialiasingQuality: SceneEnvironment.Medium
        }

        Node {
            id: cameraOrbit
            objectName: "cameraOrbit"
            eulerRotation.x: root.orbitPitch
            eulerRotation.y: root.orbitYaw
            OrthographicCamera {
                id: orthographicCamera
                objectName: "orthographicCamera"
                x: root.panX
                y: root.panY
                z: root.cameraDistance
                clipNear: Math.max(0.000001, root.sceneRadius * 0.01)
                clipFar: Math.max(1.0, root.sceneRadius * 24.0)
                horizontalMagnification: Math.max(
                    0.000001,
                    Math.min(sceneView.width, sceneView.height)
                        * root.zoomFactor
                        / Math.max(0.000001, root.sceneRadius * 2.4)
                )
                verticalMagnification: horizontalMagnification
            }
            // Camera-relative studio lights keep every orthographic front
            // view readable instead of leaving X/Y/Z views facing away from
            // world-fixed lights.
            DirectionalLight {
                objectName: "cameraKeyLight"
                // HyperMesh-style default: (0, 0, 1) in screen space.
                // With the light parented to cameraOrbit this is a headlight
                // normal to the current view for every X/Y/Z orientation.
                eulerRotation.x: 0
                eulerRotation.y: 0
                brightness: 0.92
                ambientColor: "#3b4650"
                castsShadow: false
            }
            DirectionalLight {
                objectName: "cameraFillLight"
                eulerRotation.x: 32
                eulerRotation.y: -38
                brightness: 0.24
                castsShadow: false
            }
        }
        camera: orthographicCamera

        Node {
            position: root.sceneOffset
            Repeater3D {
                objectName: "sceneRepeater"
                model: root.sceneModel
                delegate: Model {
                    id: modelDelegate
                    objectName: "sceneModelDelegate"
                    required property var geometryObject
                    required property color displayColor
                    required property bool modelVisible
                    required property real opacityValue
                    required property bool unlitMode
                    required property bool noCulling
                    required property string componentKey
                    required property bool transparentMode
                    required property bool depthWrite
                    visible: modelDelegate.modelVisible
                    geometry: modelDelegate.geometryObject
                    castsShadows: false
                    receivesShadows: false
                    opacity: modelDelegate.opacityValue
                    materials: [
                        PrincipledMaterial {
                            baseColor: modelDelegate.displayColor
                            metalness: 0.0
                            roughness: 0.72
                            lineWidth: 1.0
                            blendMode: PrincipledMaterial.SourceOver
                            alphaMode: modelDelegate.transparentMode
                                ? PrincipledMaterial.Blend
                                : PrincipledMaterial.Opaque
                            lighting: modelDelegate.unlitMode
                                ? PrincipledMaterial.NoLighting
                                : PrincipledMaterial.FragmentLighting
                            cullMode: modelDelegate.noCulling
                                ? Material.NoCulling
                                : Material.BackFaceCulling
                            depthDrawMode: modelDelegate.depthWrite
                                ? Material.AlwaysDepthDraw
                                : Material.NeverDepthDraw
                        }
                    ]
                }
            }
        }
    }

    // Project each true origin into the view. Screen-space arrows remain
    // readable through zoom, and remain visible through the selected solid.
    component CoordinateAxes: Item {
        id: frame
        property vector3d origin: Qt.vector3d(0, 0, 0)
        property vector3d axisX: Qt.vector3d(1, 0, 0)
        property vector3d axisY: Qt.vector3d(0, 0, -1)
        property vector3d axisZ: Qt.vector3d(0, 1, 0)
        property bool localFrame: false
        property string frameName: ""
        property string axisObjectPrefix: "globalAxis"
        anchors.fill: parent
        clip: true
        visible: root.hasScene
        // Different lengths keep xyz and XYZ legible when frames coincide.
        readonly property real axisLength: localFrame ? 40 : 56
        readonly property vector3d originFromCamera: root.sceneOffset.plus(
            origin).minus(orthographicCamera.scenePosition)
        readonly property real originX: width / 2
            + originFromCamera.dotProduct(orthographicCamera.right)
                * orthographicCamera.horizontalMagnification
        readonly property real originY: height / 2
            - originFromCamera.dotProduct(orthographicCamera.up)
                * orthographicCamera.verticalMagnification

        Repeater {
            model: [
                { label: "X", tint: "#ef5350", direction: frame.axisX },
                { label: "Y", tint: "#43c878", direction: frame.axisY },
                { label: "Z", tint: "#479dff", direction: frame.axisZ }
            ]
            delegate: Item {
                id: axis
                required property var modelData
                objectName: frame.axisObjectPrefix + modelData.label
                x: frame.originX
                y: frame.originY
                // Canonical (x,y,z) maps to Quick 3D (x,z,-y).
                readonly property real dx: frame.axisLength
                    * orthographicCamera.right.dotProduct(modelData.direction)
                readonly property real dy: -frame.axisLength
                    * orthographicCamera.up.dotProduct(modelData.direction)
                readonly property real projectedLength: Math.sqrt(dx * dx + dy * dy)
                readonly property real angle: Math.atan2(dy, dx) * 180 / Math.PI
                z: -orthographicCamera.forward.dotProduct(modelData.direction)

                Item {
                    rotation: axis.angle
                    visible: axis.projectedLength > 1
                    Rectangle {
                        y: -1
                        width: axis.projectedLength
                        height: 2
                        color: axis.modelData.tint
                        antialiasing: true
                    }
                    Repeater {
                        model: [-28, 28]
                        Rectangle {
                            required property real modelData
                            x: axis.projectedLength
                            y: -1
                            width: Math.min(8, axis.projectedLength * 0.4)
                            height: 2
                            transformOrigin: Item.Left
                            rotation: 180 + modelData
                            color: axis.modelData.tint
                            antialiasing: true
                        }
                    }
                }
                Text {
                    objectName: axis.objectName + "Label"
                    x: axis.dx + (axis.projectedLength > 1
                        ? axis.dx / axis.projectedLength * 11
                        : frame.localFrame ? -12 : 12) - width / 2
                    y: axis.dy + (axis.projectedLength > 1
                        ? axis.dy / axis.projectedLength * 11 : -12) - height / 2
                    text: frame.localFrame ? axis.modelData.label.toLowerCase() : axis.modelData.label
                    color: axis.modelData.tint
                    font.pixelSize: 13
                    font.bold: true
                    style: Text.Outline
                    styleColor: root.backgroundColor
                }
            }
        }
        Rectangle {
            objectName: "coordinateOriginMarker"
            x: frame.originX - width / 2
            y: frame.originY - height / 2
            z: 2
            width: frame.localFrame ? 10 : 6
            height: width
            radius: width / 2
            color: frame.localFrame ? "transparent" : root.foregroundColor
            border.color: frame.localFrame ? root.foregroundColor : root.backgroundColor
            border.width: 1
            antialiasing: true
        }
        Text {
            x: frame.originX + 8
            y: frame.originY + 6
            text: frame.frameName
            visible: text.length > 0
            color: root.foregroundColor
            font.pixelSize: 11
            style: Text.Outline
            styleColor: root.backgroundColor
        }
    }

    CoordinateAxes {
        objectName: "globalAxes"
        origin: root.coordinateOrigin
        axisX: root.coordinateAxisX
        axisY: root.coordinateAxisY
        axisZ: root.coordinateAxisZ
        localFrame: root.coordinateFrameIsLocal
    }

    Repeater {
        model: root.localCoordinateFrames
        delegate: CoordinateAxes {
            required property var modelData
            objectName: "localAxes/" + modelData.name
            axisObjectPrefix: "localAxis"
            localFrame: true
            frameName: modelData.name
            origin: modelData.origin
            axisX: modelData.axisX
            axisY: modelData.axisY
            axisZ: modelData.axisZ
        }
    }

    Text {
        anchors.centerIn: parent
        width: Math.max(80, parent.width - 56)
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        wrapMode: Text.WordWrap
        visible: !root.hasScene
        text: root.emptyText
        color: root.foregroundColor
    }
}
