"""Preflight the role-free Package V2 mesh-priority constraint graph.

The planner runs after real positive-area generated adjacencies and explicit
Frozen boundary matches have been resolved, but before any volume materializer
is called.  It has one deliberately small authority model:

* every Frozen endpoint is immutable priority ``0``;
* every Generated Component owns one unique positive integer priority;
* the smaller priority produces a shared surface and the larger priority only
  consumes it; and
* free size and origin belong to the higher-priority producer; lower-priority
  sizes never refine it, and downstream meshes inherit its exact shared trace.

Only canonical geometry, explicit topology/size controls, actual side pairs,
and matched facets participate.  Component identifiers are opaque keys;
material, package family, stack position, and manufacturing roles are never
read as decision inputs.
"""

from __future__ import annotations

from collections import defaultdict, deque
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import Enum, IntEnum
import math
from types import MappingProxyType
from typing import TypeAlias

from .package_v2_mesh_sizing import geometry_origin, interval_levels

from .component_interface import ComponentMeshRequirement
from .generated_interface_continuity import GeneratedInterfaceContinuityPlan
from .package_assembly import (
    ComponentLocalDirection,
    OrthogonalHexMeshStrategy,
    GeneratedComponentMeshControl,
    StructuredSweepMeshStrategy,
)
from .package_v2_adjacency_execution import (
    AdjacentFaceExecutionContract,
    CanonicalAdjacentSide,
    ComponentAdjacencyExecutionPlan,
)
from .package_v2_frozen_boundary_matching import MatchedFrozenBoundaryPatch
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalComponentGeometry,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalRigidPlacement,
)
from .package_v2_mixed_source_lowering import (
    FrozenGeneratedInterfaceKey,
    LoweredFrozenInterfaceMatch,
)
from .package_v2_surface_authority import (
    canonical_side_area_mm2,
    canonical_side_cartesian_rectangle,
)
from .volume_mesh import ElementKind


Point3D: TypeAlias = tuple[float, float, float]
Point2D: TypeAlias = tuple[float, float]
CartesianRectangle: TypeAlias = tuple[Point3D, Point3D, Point3D]
_REL_TOLERANCE = 1.0e-9
_ABS_TOLERANCE_MM = 1.0e-10


class MeshOrderingError(ValueError):
    """The declared priority cannot execute without changing a locked mesh."""


class FacetPolicyStrength(IntEnum):
    """Nested surface guarantees used by the constraint graph.

    A stronger value satisfies every weaker value.  ``CARTESIAN_TENSOR_QUAD``
    is therefore also a valid inherited sweep end and a valid conformal shell
    input, while an unconstrained Gmsh TRI/QUAD surface cannot seed an immutable
    structured-sweep end.
    """

    CONFORMAL_TRI_OR_QUAD = 0
    AXIS_ORTHOGONAL_RECTANGULAR_QUAD = 1
    CARTESIAN_TENSOR_QUAD = 2

    @property
    def token(self) -> str:
        return {
            self.CONFORMAL_TRI_OR_QUAD: "conformal_tri_or_quad",
            self.AXIS_ORTHOGONAL_RECTANGULAR_QUAD:
                "axis_orthogonal_rectangular_quad",
            self.CARTESIAN_TENSOR_QUAD: "cartesian_tensor_quad",
        }[self]


class SurfaceContactDomainPolicy(str, Enum):
    """Which geometry owns the positive-area shared contact after meshing."""

    CANONICAL_ANALYTIC = "canonical_analytic_contact"
    ORTHOGONAL_MATERIALIZED = "orthogonal_materialized_contact"


class MaterializedContactDomain(str, Enum):
    """The physical shared-contact domain emitted by the selected producer."""

    CANONICAL_ANALYTIC = "canonical_analytic_contact"
    ORTHOGONAL_STAIRCASE = "orthogonal_staircase_contact"


@dataclass(frozen=True, slots=True)
class OrderedSurfaceMaterializationAudit:
    """Evidence separating the ideal analytic overlap from actual contact.

    For an Orth producer the emitted staircase patch becomes the complete
    physical contact authority.  Its contact coverage is therefore 100%; the
    analytic ratio is retained only as geometry-approximation evidence.  A
    downstream Hybrid/Sweep consumer must reuse every authority facet exactly
    and treats the analytic remainder as a free boundary, not missing contact.
    """

    contact_domain: str
    analytic_candidate_area_mm2: float
    authoritative_contact_area_mm2: float
    producer_contact_coverage_ratio: float
    analytic_approximation_ratio: float
    analytic_uncovered_area_mm2: float
    analytic_overshoot_area_mm2: float

    def __post_init__(self) -> None:
        if self.contact_domain not in {
            MaterializedContactDomain.CANONICAL_ANALYTIC.value,
            MaterializedContactDomain.ORTHOGONAL_STAIRCASE.value,
        }:
            raise MeshOrderingError("unknown materialized contact domain")
        if (
            not math.isfinite(self.analytic_candidate_area_mm2)
            or not math.isfinite(self.authoritative_contact_area_mm2)
            or self.analytic_candidate_area_mm2 <= 0.0
            or self.authoritative_contact_area_mm2 < 0.0
        ):
            raise MeshOrderingError("contact-domain areas must be positive and finite")
        if not math.isclose(
            self.producer_contact_coverage_ratio,
            1.0,
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise MeshOrderingError(
                "the producer must cover 100% of its materialized contact authority"
            )
        if not math.isclose(
            self.analytic_approximation_ratio,
            self.authoritative_contact_area_mm2
            / self.analytic_candidate_area_mm2,
            rel_tol=1.0e-12,
            abs_tol=1.0e-12,
        ):
            raise MeshOrderingError("analytic approximation evidence is inconsistent")
        for field_name in (
            "analytic_uncovered_area_mm2",
            "analytic_overshoot_area_mm2",
        ):
            value = getattr(self, field_name)
            if not math.isfinite(value) or value < 0.0:
                raise MeshOrderingError(
                    "analytic comparison areas cannot be negative"
                )


@dataclass(frozen=True, slots=True)
class OrderedSurfaceConstraint:
    """One actual positive-area surface directed by immutable priority."""

    surface_id: str
    source_kind: str
    face_pair_id: str | None
    producer_component_id: str
    producer_fragment_id: str | None
    producer_side_name: str
    producer_priority: int
    consumer_component_id: str
    consumer_fragment_id: str
    consumer_side_name: str
    consumer_priority: int
    negotiated_target_edge_mm: float
    required_facet_policy: str
    immutable: bool
    area_mm2: float
    contact_domain_policy: str
    immutable_target_edge_override_count: int = 0
    immutable_maximum_edge_mm: float = 0.0


@dataclass(frozen=True, slots=True)
class OrderedSharedEdgeAuthority:
    """One exact one-dimensional authority shared by Cartesian side patches.

    Side interiors remain independent.  Only the ordered nodes on the common
    physical edge are transported, which is the minimum data needed to avoid
    an edge T-junction without inventing a fragment-wide Cartesian tensor.
    """

    edge_id: str
    fragment_id: str
    incident_surface_ids: tuple[str, ...]
    partition_points_package_mm: tuple[Point3D, ...]
    semantic_tokens: tuple[str, ...]
    immutable: bool

    def __post_init__(self) -> None:
        surfaces = tuple(sorted(set(self.incident_surface_ids)))
        points = tuple(self.partition_points_package_mm)
        tokens = tuple(self.semantic_tokens)
        if (
            not self.edge_id
            or not self.fragment_id
            or len(surfaces) < 2
            or len(points) < 2
            or len(points) != len(tokens)
            or len(set(tokens)) != len(tokens)
            or any(
                len(point) != 3
                or any(not math.isfinite(value) for value in point)
                for point in points
            )
        ):
            raise MeshOrderingError("shared Cartesian edge authority is invalid")
        object.__setattr__(self, "incident_surface_ids", surfaces)
        object.__setattr__(self, "partition_points_package_mm", points)
        object.__setattr__(self, "semantic_tokens", tokens)


@dataclass(frozen=True, slots=True)
class MeshOrderingPlan:
    """Auditable, executable priority order and its directed surfaces."""

    generated_component_order: tuple[str, ...]
    priority_by_component_id: Mapping[str, int]
    generated_surface_producer_by_face_pair_id: Mapping[str, str]
    constraints: tuple[OrderedSurfaceConstraint, ...]
    shared_edge_authorities: tuple[OrderedSharedEdgeAuthority, ...] = ()

    def __post_init__(self) -> None:
        for field_name in (
            "priority_by_component_id",
            "generated_surface_producer_by_face_pair_id",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )
        object.__setattr__(
            self, "generated_component_order", tuple(self.generated_component_order)
        )
        object.__setattr__(self, "constraints", tuple(self.constraints))
        object.__setattr__(
            self,
            "shared_edge_authorities",
            tuple(self.shared_edge_authorities),
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "generated_component_order": list(self.generated_component_order),
            "priority_by_component_id": dict(self.priority_by_component_id),
            "generated_surface_producer_by_face_pair_id": dict(
                self.generated_surface_producer_by_face_pair_id
            ),
            "constraints": [
                {
                    "surface_id": value.surface_id,
                    "source_kind": value.source_kind,
                    "face_pair_id": value.face_pair_id,
                    "producer_component_id": value.producer_component_id,
                    "producer_fragment_id": value.producer_fragment_id,
                    "producer_side_name": value.producer_side_name,
                    "producer_priority": value.producer_priority,
                    "consumer_component_id": value.consumer_component_id,
                    "consumer_fragment_id": value.consumer_fragment_id,
                    "consumer_side_name": value.consumer_side_name,
                    "consumer_priority": value.consumer_priority,
                    "negotiated_target_edge_mm": value.negotiated_target_edge_mm,
                    "required_facet_policy": value.required_facet_policy,
                    "immutable": value.immutable,
                    "area_mm2": value.area_mm2,
                    "contact_domain_policy": value.contact_domain_policy,
                    "immutable_target_edge_override_count": (
                        value.immutable_target_edge_override_count
                    ),
                    "immutable_maximum_edge_mm": (
                        value.immutable_maximum_edge_mm
                    ),
                }
                for value in self.constraints
            ],
            "shared_edge_authorities": [
                {
                    "edge_id": value.edge_id,
                    "fragment_id": value.fragment_id,
                    "incident_surface_ids": list(value.incident_surface_ids),
                    "partition_points_package_mm": [
                        list(point)
                        for point in value.partition_points_package_mm
                    ],
                    "semantic_tokens": list(value.semantic_tokens),
                    "immutable": value.immutable,
                }
                for value in self.shared_edge_authorities
            ],
        }


def audit_ordered_surface_materialization(
    constraint: OrderedSurfaceConstraint,
    producer_fragment: CanonicalGeometryFragment,
    node_coordinates_package_mm: Mapping[int, Sequence[float]],
    facets: Sequence[Sequence[int]],
    *, enforce_target_size: bool = True,
) -> OrderedSurfaceMaterializationAudit:
    """Audit one producer patch and return explicit coverage evidence.

    Every patch must lie on the planned side, satisfy its facet/edge contract,
    and contain no overlap.  A canonical producer must cover the complete
    analytic contact.  For an Orth fillet, however, the emitted staircase
    patch itself becomes the complete physical contact domain.  A downstream
    consumer must preserve that domain exactly and may mesh the remainder of
    its analytic end only as a non-contact boundary.
    """

    if type(constraint) is not OrderedSurfaceConstraint:
        raise MeshOrderingError("surface materialization audit has no plan contract")
    if (
        type(producer_fragment) is not CanonicalGeometryFragment
        or constraint.producer_fragment_id != producer_fragment.fragment_id
    ):
        raise MeshOrderingError(
            "surface materialization audit has the wrong canonical producer fragment"
        )
    coordinates: dict[int, Point3D] = {}
    for node, point in node_coordinates_package_mm.items():
        try:
            values = tuple(float(value) for value in point)
        except (TypeError, ValueError, OverflowError) as error:
            raise MeshOrderingError(
                "producer contact coordinate is not a finite 3D point"
            ) from error
        if len(values) != 3 or any(not math.isfinite(value) for value in values):
            raise MeshOrderingError(
                "producer contact coordinate is not a finite 3D point"
            )
        coordinates[int(node)] = values  # type: ignore[assignment]
    values = tuple(tuple(int(node) for node in facet) for facet in facets)
    if not values:
        if constraint.contact_domain_policy == SurfaceContactDomainPolicy.ORTHOGONAL_MATERIALIZED.value:
            return OrderedSurfaceMaterializationAudit(
                MaterializedContactDomain.ORTHOGONAL_STAIRCASE.value,
                constraint.area_mm2, 0.0, 1.0, 0.0, constraint.area_mm2, 0.0,
            )
        raise MeshOrderingError("priority producer emitted an empty contact surface")
    try:
        required = next(
            value
            for value in FacetPolicyStrength
            if value.token == constraint.required_facet_policy
        )
    except StopIteration as error:
        raise MeshOrderingError("surface plan contains an unknown facet policy") from error
    try:
        contact_domain_policy = SurfaceContactDomainPolicy(
            constraint.contact_domain_policy
        )
    except ValueError as error:
        raise MeshOrderingError(
            "surface plan contains an unknown contact-domain policy"
        ) from error
    tensor_quads: list[tuple[Point3D, ...]] = []
    projected_facets: list[tuple[int, tuple[Point2D, ...]]] = []
    materialized_area_mm2 = 0.0
    for facet in values:
        if len(facet) not in {3, 4} or any(node not in coordinates for node in facet):
            raise MeshOrderingError("producer contact facet is not TRI3/QUAD4")
        points = tuple(coordinates[node] for node in facet)
        local_points = tuple(
            _package_to_local(point, producer_fragment.placement)
            for point in points
        )
        producer_root = producer_fragment.root
        if (
            contact_domain_policy
            is SurfaceContactDomainPolicy.ORTHOGONAL_MATERIALIZED
            and type(producer_root) is CanonicalRectangularUnderfillFillet
            and constraint.producer_side_name in {"z_min", "z_max"}
        ):
            # An Orth fillet cap is a staircase approximation by contract.  Its
            # emitted cap is the physical contact authority, so XY containment
            # against the analytic rounded annulus is evidence rather than a
            # validity gate.  It must, however, remain on the exact cap support
            # plane so the downstream consumer can inherit it conformally.
            support_z = (
                producer_root.base_z_mm
                if constraint.producer_side_name == "z_min"
                else producer_root.base_z_mm + producer_root.wall_height_mm
            )
            support_tolerance = _tolerance(
                support_z,
                *(coordinate for point in local_points for coordinate in point),
            )
            if any(
                abs(point[2] - support_z) > support_tolerance
                for point in local_points
            ):
                raise MeshOrderingError(
                    "materialized Orth fillet cap is outside its support plane"
                )
        else:
            _validate_materialized_facet_on_canonical_side(
                producer_fragment,
                constraint.producer_side_name,
                local_points,
            )
        facet_area = _polygon_area_3d(points)
        if facet_area <= _tolerance(
            *(coordinate for point in points for coordinate in point)
        ) ** 2:
            raise MeshOrderingError("materialized contact contains a zero-area facet")
        projected_facets.append(_project_convex_planar_facet(local_points))
        materialized_area_mm2 += facet_area
        for first, second in zip(points, (*points[1:], points[0])):
            edge = math.dist(first, second)
            if enforce_target_size and edge > constraint.negotiated_target_edge_mm + _tolerance(
                edge, constraint.negotiated_target_edge_mm
            ):
                raise MeshOrderingError(
                    "materialized contact edge exceeds its negotiated target"
                )
        if required is FacetPolicyStrength.CONFORMAL_TRI_OR_QUAD:
            continue
        if len(facet) != 4:
            raise MeshOrderingError(
                "materialized orthogonal contact contains a non-QUAD4 facet"
            )
        edges = tuple(
            tuple(second[axis] - first[axis] for axis in range(3))
            for first, second in zip(points, (*points[1:], points[0]))
        )
        lengths = tuple(math.sqrt(math.fsum(value * value for value in edge)) for edge in edges)
        tolerance = _tolerance(*(coordinate for point in points for coordinate in point))
        if any(length <= tolerance for length in lengths):
            raise MeshOrderingError("materialized orthogonal QUAD4 is degenerate")
        dot01 = math.fsum(edges[0][axis] * edges[1][axis] for axis in range(3))
        rectangular_dot_tolerance = max(
            _ABS_TOLERANCE_MM * _ABS_TOLERANCE_MM,
            _REL_TOLERANCE * lengths[0] * lengths[1],
        )
        cross_opposites = tuple(
            math.dist(
                tuple(edges[first][axis] / lengths[first] for axis in range(3)),
                tuple(-edges[second][axis] / lengths[second] for axis in range(3)),
            )
            for first, second in ((0, 2), (1, 3))
        )
        if (
            abs(dot01) > rectangular_dot_tolerance
            or any(value > 1.0e-8 for value in cross_opposites)
        ):
            raise MeshOrderingError(
                "materialized inherited contact QUAD4 is not rectangular"
            )
        if required is FacetPolicyStrength.CARTESIAN_TENSOR_QUAD:
            ranges = tuple(
                max(point[axis] for point in points)
                - min(point[axis] for point in points)
                for axis in range(3)
            )
            constant = tuple(axis for axis, extent in enumerate(ranges) if extent <= tolerance)
            if len(constant) != 1 or any(
                sum(abs(value) > tolerance for value in edge) != 1
                for edge in edges
            ):
                raise MeshOrderingError(
                    "materialized Cartesian contact QUAD4 is not package-axis aligned"
                )
            tensor_quads.append(points)  # type: ignore[arg-type]
    complete = math.isclose(
        materialized_area_mm2,
        constraint.area_mm2,
        rel_tol=5.0e-7,
        abs_tol=max(1.0e-12, constraint.area_mm2 * 5.0e-7),
    )
    canonical_analytic = (
        contact_domain_policy is SurfaceContactDomainPolicy.CANONICAL_ANALYTIC
    )
    curved_fillet_cap = (
        type(producer_fragment.root) is CanonicalRectangularUnderfillFillet
        and _normalized_side_name(constraint.producer_side_name)
        in {"z_min", "z_max"}
    )
    if canonical_analytic and curved_fillet_cap:
        _validate_complete_conformal_fillet_cap(
            producer_fragment,
            constraint.producer_side_name,
            coordinates,
            values,
        )
    elif canonical_analytic and not complete:
        raise MeshOrderingError(
            "materialized contact does not cover the complete planned surface area"
        )
    materialized_domain = (
        MaterializedContactDomain.CANONICAL_ANALYTIC
        if canonical_analytic
        else MaterializedContactDomain.ORTHOGONAL_STAIRCASE
    )
    analytic_uncovered_area_mm2 = (
        0.0
        if canonical_analytic or complete
        else max(0.0, constraint.area_mm2 - materialized_area_mm2)
    )
    analytic_overshoot_area_mm2 = (
        0.0
        if canonical_analytic or complete
        else max(0.0, materialized_area_mm2 - constraint.area_mm2)
    )
    if required is not FacetPolicyStrength.CARTESIAN_TENSOR_QUAD:
        _validate_materialized_facets_do_not_overlap(
            projected_facets,
            planned_area_mm2=constraint.area_mm2,
        )
        return OrderedSurfaceMaterializationAudit(
            materialized_domain.value,
            constraint.area_mm2,
            materialized_area_mm2,
            1.0,
            materialized_area_mm2 / constraint.area_mm2,
            analytic_uncovered_area_mm2,
            analytic_overshoot_area_mm2,
        )
    axis_levels = tuple(
        _clustered_axis_values(
            tuple(point[axis] for points in tensor_quads for point in points)
        )
        for axis in range(3)
    )
    cell_keys: set[tuple[int, int, int, int, int, int]] = set()
    common_plane: tuple[int, int] | None = None
    for points in tensor_quads:
        ranges = tuple(
            max(point[axis] for point in points)
            - min(point[axis] for point in points)
            for axis in range(3)
        )
        tolerance = _tolerance(*(coordinate for point in points for coordinate in point))
        varying = tuple(axis for axis, extent in enumerate(ranges) if extent > tolerance)
        constant = tuple(axis for axis in range(3) if axis not in varying)
        if len(varying) != 2 or len(constant) != 1:
            raise MeshOrderingError(
                "materialized Cartesian contact is not a single planar tensor patch"
            )
        plane_axis = constant[0]
        plane_level = _axis_index(points[0][plane_axis], axis_levels[plane_axis])
        plane = (plane_axis, plane_level)
        if common_plane is None:
            common_plane = plane
        elif common_plane != plane:
            raise MeshOrderingError(
                "materialized Cartesian contact spans multiple planes"
            )
        intervals: list[tuple[int, int]] = []
        for axis in varying:
            indices = sorted({_axis_index(point[axis], axis_levels[axis]) for point in points})
            if len(indices) != 2:
                raise MeshOrderingError(
                    "materialized Cartesian contact QUAD4 does not span two axis levels"
                )
            intervals.append((indices[0], indices[1]))
        cell_key = (
            plane_axis,
            plane_level,
            varying[0],
            intervals[0][0],
            varying[1],
            intervals[1][0],
        )
        if cell_key in cell_keys:
            raise MeshOrderingError(
                "materialized Cartesian contact contains overlapping duplicate cells"
            )
        cell_keys.add(cell_key)
    _validate_cartesian_quad_edge_conformity(projected_facets)
    _validate_materialized_facets_do_not_overlap(
        projected_facets,
        planned_area_mm2=constraint.area_mm2,
    )
    return OrderedSurfaceMaterializationAudit(
        materialized_domain.value,
        constraint.area_mm2,
        materialized_area_mm2,
        1.0,
        materialized_area_mm2 / constraint.area_mm2,
        analytic_uncovered_area_mm2,
        analytic_overshoot_area_mm2,
    )


@dataclass(slots=True)
class _SurfaceRecord:
    surface_id: str
    source_kind: str
    face_pair_id: str | None
    interface_id: str | None
    producer_component_id: str
    producer_fragment_id: str | None
    producer_side_name: str
    producer_priority: int
    consumer_component_id: str
    consumer_fragment_id: str
    consumer_side_name: str
    consumer_priority: int
    area_mm2: float
    direct_target_edge_mm: float
    direct_required_policy: FacetPolicyStrength
    immutable: bool
    frozen_patches: tuple[MatchedFrozenBoundaryPatch, ...] = ()
    negotiated_target_edge_mm: float = 0.0
    required_policy: FacetPolicyStrength = (
        FacetPolicyStrength.CONFORMAL_TRI_OR_QUAD
    )
    immutable_target_edge_override_count: int = 0
    immutable_maximum_edge_mm: float = 0.0


def _tolerance(*values: float) -> float:
    return max(
        _ABS_TOLERANCE_MM,
        _REL_TOLERANCE * max((1.0, *(abs(value) for value in values))),
    )


def _close(first: float, second: float) -> bool:
    return abs(first - second) <= _tolerance(first, second)


def _normalized_side_name(value: str) -> str:
    aliases = {
        "bottom": "z_min",
        "base": "z_min",
        "top": "z_max",
        "cap": "z_max",
    }
    if value.startswith("inner_"):
        return "opening_" + value[len("inner_") :]
    return aliases.get(value, value)


def _rotation_matrix(
    placement: CanonicalRigidPlacement,
) -> tuple[Point3D, Point3D, Point3D]:
    rx, ry, rz = (math.radians(value) for value in placement.rotation_deg_xyz)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    rotate_x = (
        (1.0, 0.0, 0.0),
        (0.0, cx, -sx),
        (0.0, sx, cx),
    )
    rotate_y = (
        (cy, 0.0, sy),
        (0.0, 1.0, 0.0),
        (-sy, 0.0, cy),
    )
    rotate_z = (
        (cz, -sz, 0.0),
        (sz, cz, 0.0),
        (0.0, 0.0, 1.0),
    )

    def multiply(
        left: Sequence[Sequence[float]],
        right: Sequence[Sequence[float]],
    ) -> tuple[Point3D, Point3D, Point3D]:
        return tuple(
            tuple(
                math.fsum(
                    left[row][inner] * right[inner][column]
                    for inner in range(3)
                )
                for column in range(3)
            )
            for row in range(3)
        )  # type: ignore[return-value]

    return multiply(rotate_z, multiply(rotate_y, rotate_x))


def _package_to_local(
    point: Point3D,
    placement: CanonicalRigidPlacement,
) -> Point3D:
    pivot = placement.pivot_xyz_mm
    translated = tuple(
        point[axis] - placement.translation_xyz_mm[axis] - pivot[axis]
        for axis in range(3)
    )
    rotation = _rotation_matrix(placement)
    return tuple(
        pivot[axis]
        + math.fsum(
            rotation[source_axis][axis] * translated[source_axis]
            for source_axis in range(3)
        )
        for axis in range(3)
    )  # type: ignore[return-value]


def _local_to_package(
    point: Point3D,
    placement: CanonicalRigidPlacement,
) -> Point3D:
    pivot = placement.pivot_xyz_mm
    relative = tuple(point[index] - pivot[index] for index in range(3))
    rotation = _rotation_matrix(placement)
    return tuple(
        placement.translation_xyz_mm[row]
        + pivot[row]
        + math.fsum(
            rotation[row][column] * relative[column]
            for column in range(3)
        )
        for row in range(3)
    )  # type: ignore[return-value]


def _polygon_area_3d(points: Sequence[Point3D]) -> float:
    origin = points[0]
    accumulated = [0.0, 0.0, 0.0]
    for index in range(1, len(points) - 1):
        first = tuple(points[index][axis] - origin[axis] for axis in range(3))
        second = tuple(
            points[index + 1][axis] - origin[axis] for axis in range(3)
        )
        cross = (
            first[1] * second[2] - first[2] * second[1],
            first[2] * second[0] - first[0] * second[2],
            first[0] * second[1] - first[1] * second[0],
        )
        for axis in range(3):
            accumulated[axis] += cross[axis]
    return 0.5 * math.sqrt(math.fsum(value * value for value in accumulated))


def _cross_2d(first: Point2D, second: Point2D) -> float:
    return first[0] * second[1] - first[1] * second[0]


def _signed_polygon_area_2d(points: Sequence[Point2D]) -> float:
    return 0.5 * math.fsum(
        first[0] * second[1] - second[0] * first[1]
        for first, second in zip(points, (*points[1:], points[0]))
    )


def _project_convex_planar_facet(
    points: Sequence[Point3D],
) -> tuple[int, tuple[Point2D, ...]]:
    """Project one canonical-side facet and prove a usable convex cycle."""

    tolerance = _tolerance(
        *(coordinate for point in points for coordinate in point)
    )
    ranges = tuple(
        max(point[axis] for point in points)
        - min(point[axis] for point in points)
        for axis in range(3)
    )
    constant = tuple(
        axis for axis, extent in enumerate(ranges) if extent <= tolerance
    )
    if len(constant) != 1:
        raise MeshOrderingError(
            "materialized contact facet is not planar on one canonical side"
        )
    plane_axis = constant[0]
    varying = tuple(axis for axis in range(3) if axis != plane_axis)
    polygon = tuple(
        (point[varying[0]], point[varying[1]]) for point in points
    )
    if any(
        math.dist(first, second) <= tolerance
        for first, second in zip(polygon, (*polygon[1:], polygon[0]))
    ):
        raise MeshOrderingError(
            "materialized contact facet contains a zero-length boundary edge"
        )
    signed_area = _signed_polygon_area_2d(polygon)
    area_tolerance = tolerance * tolerance
    if abs(signed_area) <= area_tolerance:
        raise MeshOrderingError("materialized contact contains a zero-area facet")
    if signed_area < 0.0:
        polygon = tuple(reversed(polygon))
    turns = tuple(
        _cross_2d(
            (second[0] - first[0], second[1] - first[1]),
            (third[0] - second[0], third[1] - second[1]),
        )
        for first, second, third in zip(
            polygon,
            (*polygon[1:], polygon[0]),
            (*polygon[2:], polygon[0], polygon[1]),
        )
    )
    if any(value < -area_tolerance for value in turns):
        raise MeshOrderingError(
            "materialized contact facet is concave or self-intersecting"
        )
    return plane_axis, polygon


def _convex_polygon_intersection_area(
    subject: Sequence[Point2D],
    clip_polygon: Sequence[Point2D],
) -> float:
    """Return the positive-area intersection of two CCW convex polygons."""

    output = list(subject)
    for clip_first, clip_second in zip(
        clip_polygon,
        (*clip_polygon[1:], clip_polygon[0]),
    ):
        if not output:
            return 0.0
        clip_edge = (
            clip_second[0] - clip_first[0],
            clip_second[1] - clip_first[1],
        )

        def signed_distance(point: Point2D) -> float:
            return _cross_2d(
                clip_edge,
                (point[0] - clip_first[0], point[1] - clip_first[1]),
            )

        clipped: list[Point2D] = []
        previous = output[-1]
        previous_distance = signed_distance(previous)
        previous_inside = previous_distance >= 0.0
        for current in output:
            current_distance = signed_distance(current)
            current_inside = current_distance >= 0.0
            if current_inside != previous_inside:
                denominator = previous_distance - current_distance
                if denominator != 0.0:
                    fraction = previous_distance / denominator
                    clipped.append(
                        (
                            previous[0]
                            + fraction * (current[0] - previous[0]),
                            previous[1]
                            + fraction * (current[1] - previous[1]),
                        )
                    )
            if current_inside:
                clipped.append(current)
            previous = current
            previous_distance = current_distance
            previous_inside = current_inside
        output = clipped
    if len(output) < 3:
        return 0.0
    return abs(_signed_polygon_area_2d(output))


def _validate_materialized_facets_do_not_overlap(
    facets: Sequence[tuple[int, tuple[Point2D, ...]]],
    *,
    planned_area_mm2: float,
) -> None:
    """Reject overlap for every policy so summed area cannot conceal a hole."""

    plane_axes = {plane_axis for plane_axis, _polygon in facets}
    if len(plane_axes) != 1:
        raise MeshOrderingError(
            "materialized contact facets do not share one canonical plane"
        )
    coordinates = tuple(
        coordinate
        for _plane_axis, polygon in facets
        for point in polygon
        for coordinate in point
    )
    linear_tolerance = _tolerance(*coordinates)
    area_tolerance = max(
        linear_tolerance * linear_tolerance,
        planned_area_mm2 * 1.0e-10,
    )
    entries = sorted(
        (
            min(point[0] for point in polygon),
            max(point[0] for point in polygon),
            min(point[1] for point in polygon),
            max(point[1] for point in polygon),
            polygon,
        )
        for _plane_axis, polygon in facets
    )
    active: list[
        tuple[float, float, float, float, tuple[Point2D, ...]]
    ] = []
    for entry in entries:
        x_min, x_max, y_min, y_max, polygon = entry
        active = [
            candidate
            for candidate in active
            if candidate[1] > x_min + linear_tolerance
        ]
        for candidate in active:
            if min(y_max, candidate[3]) <= max(y_min, candidate[2]) + linear_tolerance:
                continue
            if (
                _convex_polygon_intersection_area(polygon, candidate[4])
                > area_tolerance
            ):
                raise MeshOrderingError(
                    "materialized contact facets overlap and can conceal an "
                    "unmeshed hole"
                )
        active.append(entry)


def _validate_cartesian_quad_edge_conformity(
    facets: Sequence[tuple[int, tuple[Point2D, ...]]],
) -> None:
    """Reject only real edge T-junctions, not unrelated global axis levels.

    A conforming Cartesian QUAD surface may contain independent partitions in
    disjoint parts of the same side.  Requiring every quad edge to span two
    adjacent values in the *global* union of axis coordinates accidentally
    couples those partitions.  Sweep and Orth consumers need rectangular,
    axis-aligned, edge-conforming quads; they do not need a Cartesian product
    across empty or disconnected regions.
    """

    coordinates = tuple(
        coordinate
        for _plane_axis, polygon in facets
        for point in polygon
        for coordinate in point
    )
    tolerance = _tolerance(*coordinates)
    segments_by_line: dict[
        tuple[int, int], list[tuple[float, float]]
    ] = defaultdict(list)

    # Clustering the constant line coordinate prevents harmless floating-point
    # noise from creating separate buckets while retaining an absolute value
    # for the overlap test itself.
    x_levels = _clustered_axis_values(
        tuple(point[0] for _axis, polygon in facets for point in polygon)
    )
    y_levels = _clustered_axis_values(
        tuple(point[1] for _axis, polygon in facets for point in polygon)
    )
    for _plane_axis, polygon in facets:
        for first, second in zip(polygon, (*polygon[1:], polygon[0])):
            dx = abs(second[0] - first[0])
            dy = abs(second[1] - first[1])
            if dx > tolerance and dy <= tolerance:
                line = (0, _axis_index(first[1], y_levels))
                interval = tuple(sorted((first[0], second[0])))
            elif dy > tolerance and dx <= tolerance:
                line = (1, _axis_index(first[0], x_levels))
                interval = tuple(sorted((first[1], second[1])))
            else:
                raise MeshOrderingError(
                    "materialized Cartesian contact contains a non-axis edge"
                )
            segments_by_line[line].append(interval)  # type: ignore[arg-type]

    for intervals in segments_by_line.values():
        ordered = sorted(intervals)
        for index, first in enumerate(ordered):
            exact_owner_count = 1
            for second in ordered[index + 1 :]:
                if second[0] >= first[1] - tolerance:
                    break
                if (
                    abs(first[0] - second[0]) <= tolerance
                    and abs(first[1] - second[1]) <= tolerance
                ):
                    exact_owner_count += 1
                    if exact_owner_count > 2:
                        raise MeshOrderingError(
                            "materialized Cartesian contact contains a non-manifold edge"
                        )
                    continue
                raise MeshOrderingError(
                    "materialized Cartesian contact contains a partial-edge T-junction"
                )


def _validate_complete_conformal_fillet_cap(
    fragment: CanonicalGeometryFragment,
    raw_side_name: str,
    package_coordinates: Mapping[int, Point3D],
    facets: Sequence[Sequence[int]],
) -> None:
    """Prove topological coverage of a linearized rounded fillet cap.

    A first-order surface mesh represents a CAD arc by chords, so its summed
    triangle area is expected to be slightly smaller than the analytic area.
    Coverage is instead proved from one edge-connected, non-manifold-free
    annulus whose only two boundary cycles are the complete die perimeter and
    the complete analytic offset perimeter.  The area ratio remains separate
    approximation evidence and is never relabelled as missing contact.
    """

    root = fragment.root
    side_name = _normalized_side_name(raw_side_name)
    if (
        type(root) is not CanonicalRectangularUnderfillFillet
        or side_name not in {"z_min", "z_max"}
    ):
        raise MeshOrderingError(
            "complete conformal fillet-cap proof received incompatible geometry"
        )
    local_coordinates = {
        int(node): _package_to_local(point, fragment.placement)
        for node, point in package_coordinates.items()
    }
    normalized_facets = tuple(tuple(int(node) for node in facet) for facet in facets)
    edge_owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for facet_index, facet in enumerate(normalized_facets):
        if len(facet) not in {3, 4} or len(set(facet)) != len(facet):
            raise MeshOrderingError(
                "conformal fillet cap contains an invalid TRI3/QUAD4"
            )
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge = (first, second) if first < second else (second, first)
            edge_owners[edge].append(facet_index)
    if not edge_owners or any(len(owners) not in {1, 2} for owners in edge_owners.values()):
        raise MeshOrderingError(
            "conformal fillet cap contains a non-manifold surface edge"
        )

    facet_adjacency: dict[int, set[int]] = defaultdict(set)
    for owners in edge_owners.values():
        if len(owners) == 2:
            facet_adjacency[owners[0]].add(owners[1])
            facet_adjacency[owners[1]].add(owners[0])
    reached = {0}
    queue = deque((0,))
    while queue:
        current = queue.popleft()
        for neighbor in facet_adjacency[current]:
            if neighbor not in reached:
                reached.add(neighbor)
                queue.append(neighbor)
    if len(reached) != len(normalized_facets):
        raise MeshOrderingError(
            "conformal fillet cap is not one edge-connected contact patch"
        )

    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    width = max(root.side_widths_mm or (root.toe_width_mm,)) if side_name == "z_min" else max(root.top_widths_mm or (root.top_width_mm,))
    z_value = root.base_z_mm if side_name == "z_min" else (
        root.base_z_mm + root.wall_height_mm
    )
    tolerance = _tolerance(x0, x1, y0, y1, z_value, width)

    def inner_sides(point: Point3D) -> frozenset[str]:
        x, y, z = point
        if abs(z - z_value) > tolerance:
            return frozenset()
        values: set[str] = set()
        if abs(x - x0) <= tolerance and y0 - tolerance <= y <= y1 + tolerance:
            values.add("x_min")
        if abs(x - x1) <= tolerance and y0 - tolerance <= y <= y1 + tolerance:
            values.add("x_max")
        if abs(y - y0) <= tolerance and x0 - tolerance <= x <= x1 + tolerance:
            values.add("y_min")
        if abs(y - y1) <= tolerance and x0 - tolerance <= x <= x1 + tolerance:
            values.add("y_max")
        return frozenset(values)

    def on_outer(point: Point3D) -> bool:
        x, y, z = point
        if root.uses_elliptical_sweep:
            from .package_v2_swept_fillet import radial_fraction
            return abs(z-z_value) <= tolerance and abs(radial_fraction(root, point)-1.) <= tolerance
        distance = math.hypot(
            max(x0 - x, 0.0, x - x1),
            max(y0 - y, 0.0, y - y1),
        )
        return abs(z - z_value) <= tolerance and abs(distance - width) <= tolerance

    classified: dict[str, list[tuple[int, int]]] = {
        "inner": [],
        "outer": [],
    }
    for edge, owners in edge_owners.items():
        if len(owners) != 1:
            continue
        first, second = edge
        first_point = local_coordinates[first]
        second_point = local_coordinates[second]
        if inner_sides(first_point).intersection(inner_sides(second_point)):
            classified["inner"].append(edge)
        elif on_outer(first_point) and on_outer(second_point):
            classified["outer"].append(edge)
        else:
            raise MeshOrderingError(
                "conformal fillet cap has a hole or an incomplete analytic boundary"
            )

    def prove_one_cycle(edges: Sequence[tuple[int, int]], *, label: str) -> set[int]:
        graph: dict[int, set[int]] = defaultdict(set)
        for first, second in edges:
            graph[first].add(second)
            graph[second].add(first)
        if not graph or any(len(neighbors) != 2 for neighbors in graph.values()):
            raise MeshOrderingError(
                f"conformal fillet cap {label} boundary is not one closed cycle"
            )
        start = min(graph)
        visited = {start}
        pending = deque((start,))
        while pending:
            current = pending.popleft()
            for neighbor in graph[current]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    pending.append(neighbor)
        if len(visited) != len(graph):
            raise MeshOrderingError(
                f"conformal fillet cap {label} boundary has multiple cycles"
            )
        return visited

    inner_nodes = prove_one_cycle(classified["inner"], label="inner")
    outer_nodes = prove_one_cycle(classified["outer"], label="outer")
    if inner_nodes.intersection(outer_nodes):
        raise MeshOrderingError(
            "conformal fillet cap inner and outer boundaries intersect"
        )
    for corner in ((x0, y0), (x1, y0), (x1, y1), (x0, y1)):
        if not any(
            math.hypot(
                local_coordinates[node][0] - corner[0],
                local_coordinates[node][1] - corner[1],
            )
            <= tolerance
            for node in inner_nodes
        ):
            raise MeshOrderingError(
                "conformal fillet cap does not include the complete die perimeter"
            )


def _polygon_rectangle_overlap_area(
    points: Sequence[tuple[float, float]],
    bounds: tuple[float, float, float, float],
) -> float:
    polygon = list(points)
    x_min, x_max, y_min, y_max = bounds

    def clip(
        values: list[tuple[float, float]],
        *,
        axis: int,
        coordinate: float,
        keep_greater: bool,
    ) -> list[tuple[float, float]]:
        if not values:
            return []

        def inside(point: tuple[float, float]) -> bool:
            return (
                point[axis] >= coordinate
                if keep_greater
                else point[axis] <= coordinate
            )

        output: list[tuple[float, float]] = []
        previous = values[-1]
        previous_inside = inside(previous)
        for current in values:
            current_inside = inside(current)
            if current_inside != previous_inside:
                denominator = current[axis] - previous[axis]
                if denominator != 0.0:
                    fraction = (coordinate - previous[axis]) / denominator
                    output.append(
                        (
                            previous[0]
                            + fraction * (current[0] - previous[0]),
                            previous[1]
                            + fraction * (current[1] - previous[1]),
                        )
                    )
            if current_inside:
                output.append(current)
            previous = current
            previous_inside = current_inside
        return output

    for axis, coordinate, keep_greater in (
        (0, x_min, True),
        (0, x_max, False),
        (1, y_min, True),
        (1, y_max, False),
    ):
        polygon = clip(
            polygon,
            axis=axis,
            coordinate=coordinate,
            keep_greater=keep_greater,
        )
    if len(polygon) < 3:
        return 0.0
    return 0.5 * abs(
        math.fsum(
            first[0] * second[1] - second[0] * first[1]
            for first, second in zip(polygon, (*polygon[1:], polygon[0]))
        )
    )


def _validate_materialized_facet_on_canonical_side(
    fragment: CanonicalGeometryFragment,
    raw_side_name: str,
    points: Sequence[Point3D],
) -> None:
    """Fail unless one emitted facet is wholly on its declared local side."""

    side_name = _normalized_side_name(raw_side_name)
    root = fragment.root
    tolerance = _tolerance(
        *(coordinate for point in points for coordinate in point)
    )

    def all_on(axis: int, coordinate: float) -> bool:
        return all(abs(point[axis] - coordinate) <= tolerance for point in points)

    def all_within(axis: int, bounds: tuple[float, float]) -> bool:
        return all(
            bounds[0] - tolerance <= point[axis] <= bounds[1] + tolerance
            for point in points
        )

    valid = False
    if type(root) is CanonicalBox:
        bounds = tuple(
            (
                root.origin_xyz_mm[axis],
                root.origin_xyz_mm[axis] + root.size_xyz_mm[axis],
            )
            for axis in range(3)
        )
        descriptors = {
            "x_min": (0, bounds[0][0]),
            "x_max": (0, bounds[0][1]),
            "y_min": (1, bounds[1][0]),
            "y_max": (1, bounds[1][1]),
            "z_min": (2, bounds[2][0]),
            "z_max": (2, bounds[2][1]),
        }
        if side_name in descriptors:
            axis, coordinate = descriptors[side_name]
            valid = all_on(axis, coordinate) and all(
                all_within(other, bounds[other])
                for other in range(3)
                if other != axis
            )
    elif type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        x1 = x0 + root.outer_size_xy_mm[0]
        y1 = y0 + root.outer_size_xy_mm[1]
        z1 = z0 + root.height_mm
        hx0 = x0 + root.opening_offset_xy_mm[0]
        hy0 = y0 + root.opening_offset_xy_mm[1]
        hx1 = hx0 + root.opening_size_xy_mm[0]
        hy1 = hy0 + root.opening_size_xy_mm[1]
        vertical = {
            "outer_x_min": (0, x0, 1, (y0, y1)),
            "outer_x_max": (0, x1, 1, (y0, y1)),
            "outer_y_min": (1, y0, 0, (x0, x1)),
            "outer_y_max": (1, y1, 0, (x0, x1)),
            "opening_x_min": (0, hx0, 1, (hy0, hy1)),
            "opening_x_max": (0, hx1, 1, (hy0, hy1)),
            "opening_y_min": (1, hy0, 0, (hx0, hx1)),
            "opening_y_max": (1, hy1, 0, (hx0, hx1)),
        }
        if side_name in {"z_min", "z_max"}:
            coordinate = z0 if side_name == "z_min" else z1
            polygon = tuple((point[0], point[1]) for point in points)
            opening_overlap = _polygon_rectangle_overlap_area(
                polygon, (hx0, hx1, hy0, hy1)
            )
            valid = (
                all_on(2, coordinate)
                and all_within(0, (x0, x1))
                and all_within(1, (y0, y1))
                and opening_overlap <= tolerance * tolerance
            )
        elif side_name in vertical:
            axis, coordinate, tangent, tangent_bounds = vertical[side_name]
            valid = (
                all_on(axis, coordinate)
                and all_within(tangent, tangent_bounds)
                and all_within(2, (z0, z1))
            )
    elif type(root) is CanonicalRectangularUnderfillFillet:
        x0, y0 = root.die_origin_xy_mm
        x1 = x0 + root.die_size_xy_mm[0]
        y1 = y0 + root.die_size_xy_mm[1]
        z0 = root.base_z_mm
        z1 = z0 + root.wall_height_mm
        vertical = {
            "die_x_min": (0, x0, 1, (y0, y1)),
            "die_x_max": (0, x1, 1, (y0, y1)),
            "die_y_min": (1, y0, 0, (x0, x1)),
            "die_y_max": (1, y1, 0, (x0, x1)),
        }
        if side_name in {"z_min", "z_max"}:
            coordinate = z0 if side_name == "z_min" else z1
            width = max(root.side_widths_mm or (root.toe_width_mm,)) if side_name == "z_min" else max(root.top_widths_mm or (root.top_width_mm,))
            polygon = tuple((point[0], point[1]) for point in points)
            die_overlap = _polygon_rectangle_overlap_area(
                polygon, (x0, x1, y0, y1)
            )
            from .package_v2_swept_fillet import radial_fraction
            valid = (
                all_on(2, coordinate)
                and die_overlap <= tolerance * tolerance
                and all(
                    (math.hypot(
                        max(x0 - point[0], 0.0, point[0] - x1),
                        max(y0 - point[1], 0.0, point[1] - y1),
                    )
                    <= width + tolerance if not root.uses_elliptical_sweep else
                    radial_fraction(root, point) <= 1.+tolerance)
                    for point in points
                )
            )
        elif side_name in vertical:
            axis, coordinate, tangent, tangent_bounds = vertical[side_name]
            valid = (
                all_on(axis, coordinate)
                and all_within(tangent, tangent_bounds)
                and all_within(2, (z0, z1))
            )
    elif side_name.startswith("orth:"):
        from .package_v2_orthogonal_domain_planning import rectilinear_side_overlaps

        normal = int(side_name.split(":")[1])
        u, v = [a for a in range(3) if a != normal]
        area = 0.5 * abs(
            math.fsum(
                p[u] * q[v] - q[u] * p[v]
                for p, q in zip(points, (*points[1:], points[0]))
            )
        )
        covered = rectilinear_side_overlaps(root, points, tolerance).get(side_name, 0.0)
        valid = area > tolerance * tolerance and math.isclose(
            covered, area, rel_tol=1e-8, abs_tol=tolerance * tolerance
        )
    if not valid:
        raise MeshOrderingError(
            "materialized contact facet is outside its planned canonical side"
        )


def _placement_is_package_cartesian(
    placement: CanonicalRigidPlacement,
) -> bool:
    rotation = _rotation_matrix(placement)
    tolerance = 1.0e-9
    for row in rotation:
        nonzero = tuple(value for value in row if abs(value) > tolerance)
        if len(nonzero) != 1 or not math.isclose(
            abs(nonzero[0]), 1.0, rel_tol=1.0e-9, abs_tol=1.0e-9
        ):
            return False
    for column in range(3):
        nonzero = tuple(
            rotation[row][column]
            for row in range(3)
            if abs(rotation[row][column]) > tolerance
        )
        if len(nonzero) != 1:
            return False
    return True


def _clustered_axis_values(values: Sequence[float]) -> tuple[float, ...]:
    output: list[float] = []
    for value in sorted(values):
        if not output or not _close(output[-1], value):
            output.append(value)
    return tuple(output)


def _axis_index(value: float, levels: Sequence[float]) -> int:
    matches = tuple(index for index, level in enumerate(levels) if _close(value, level))
    if len(matches) != 1:
        raise MeshOrderingError(
            "Frozen locked point cannot be placed on one Cartesian tensor axis"
        )
    return matches[0]


def _validate_frozen_quad(
    patch: MatchedFrozenBoundaryPatch,
    facet_nodes: Sequence[int],
    fragment: CanonicalGeometryFragment,
    *,
    target_edge_mm: float,
) -> tuple[tuple[Point3D, ...], int, tuple[int, int]]:
    nodes = tuple(facet_nodes)
    if len(nodes) != 4:
        raise MeshOrderingError(
            "Frozen exposed interfaces must contain only immutable QUAD4; "
            "TRI3 cannot be changed into an orthogonal surface"
        )
    points = tuple(
        _package_to_local(patch.node_coordinates[node], fragment.placement)
        for node in nodes
    )
    ranges = tuple(
        max(point[axis] for point in points)
        - min(point[axis] for point in points)
        for axis in range(3)
    )
    tolerance = _tolerance(*(coordinate for point in points for coordinate in point))
    constant_axes = tuple(axis for axis, extent in enumerate(ranges) if extent <= tolerance)
    if len(constant_axes) != 1:
        raise MeshOrderingError(
            "Frozen exposed QUAD4 is not planar on one target-local Cartesian axis"
        )
    plane_axis = constant_axes[0]
    varying = tuple(axis for axis in range(3) if axis != plane_axis)
    levels = tuple(
        _clustered_axis_values(tuple(point[axis] for point in points))
        for axis in varying
    )
    if any(len(values) != 2 for values in levels):
        raise MeshOrderingError(
            "Frozen exposed QUAD4 is not an axis-orthogonal rectangle"
        )
    corners = {
        (
            _axis_index(point[varying[0]], levels[0]),
            _axis_index(point[varying[1]], levels[1]),
        )
        for point in points
    }
    if corners != {(0, 0), (0, 1), (1, 0), (1, 1)}:
        raise MeshOrderingError(
            "Frozen exposed QUAD4 does not contain the four rectangle corners"
        )
    for first, second in zip(points, (*points[1:], points[0])):
        changed = tuple(
            axis
            for axis in varying
            if abs(first[axis] - second[axis]) > tolerance
        )
        edge = math.dist(first, second)
        if len(changed) != 1 or edge <= tolerance:
            raise MeshOrderingError(
                "Frozen exposed QUAD4 cycle has a diagonal or non-Cartesian edge"
            )
    return points, plane_axis, varying  # type: ignore[return-value]


def _validate_frozen_multiblock_for_side(
    entries: Sequence[
        tuple[
            MatchedFrozenBoundaryPatch,
            tuple[int, ...],
            float,
        ]
    ],
    fragment: CanonicalGeometryFragment,
) -> None:
    """Prove one immutable side is a conforming Cartesian-QUAD multiblock.

    A Frozen contact need not be one package-wide tensor.  Different
    canonical sides, disconnected islands, and rectilinear regions separated
    by a hole may legitimately use different interval sequences.  Requiring
    every coordinate found anywhere on the fragment to cut every other QUAD
    would therefore demand splitting an otherwise valid immutable facet.

    The executable contract is local: every facet is one axis-orthogonal
    Cartesian rectangle no coarser than the negotiated target, facets do not
    overlap, and two facets may meet along either one complete common edge or
    at isolated vertices.  A partial collinear edge overlap remains a real
    non-conforming T-junction and is rejected because neither consumer is
    allowed to split the Frozen facet.  The surviving rectangles are atomic
    tensor blocks which Orth and Sweep can consume without inventing a global
    grid.
    """

    validated: list[tuple[tuple[Point3D, ...], int, tuple[int, int]]] = []
    for patch, facet, target in entries:
        validated.append(
            _validate_frozen_quad(
                patch,
                facet,
                fragment,
                target_edge_mm=target,
            )
        )
    if not validated:
        raise MeshOrderingError("Frozen orthogonal side contains no QUAD4 facets")

    plane_axes = {plane_axis for _points, plane_axis, _varying in validated}
    varying_axes = {varying for _points, _plane_axis, varying in validated}
    if len(plane_axes) != 1 or len(varying_axes) != 1:
        raise MeshOrderingError(
            "Frozen orthogonal side spans multiple target-local Cartesian planes"
        )
    plane_axis = next(iter(plane_axes))
    varying = next(iter(varying_axes))
    plane_values = tuple(
        points[0][plane_axis] for points, _axis, _varying in validated
    )
    if any(not _close(plane_values[0], value) for value in plane_values[1:]):
        raise MeshOrderingError(
            "Frozen orthogonal side spans multiple target-local Cartesian planes"
        )

    projected = tuple(
        (
            plane_axis,
            tuple((point[varying[0]], point[varying[1]]) for point in points),
        )
        for points, _axis, _varying in validated
    )
    _validate_materialized_facets_do_not_overlap(
        projected,
        planned_area_mm2=math.fsum(
            _polygon_area_3d(points)
            for points, _axis, _varying in validated
        ),
    )

    levels = {
        axis: _clustered_axis_values(
            tuple(
                point[axis]
                for points, _plane, _varying in validated
                for point in points
            )
        )
        for axis in varying
    }
    edge_groups: dict[
        tuple[int, int],
        list[tuple[int, int, int]],
    ] = defaultdict(list)
    for facet_index, (points, _axis, _varying) in enumerate(validated):
        for first, second in zip(points, (*points[1:], points[0])):
            changed = tuple(
                axis
                for axis in varying
                if not _close(first[axis], second[axis])
            )
            if len(changed) != 1:
                raise MeshOrderingError(
                    "Frozen exposed QUAD4 cycle has a diagonal or "
                    "non-Cartesian edge"
                )
            edge_axis = changed[0]
            constant_axis = varying[1] if edge_axis == varying[0] else varying[0]
            constant_index = _axis_index(
                first[constant_axis], levels[constant_axis]
            )
            endpoints = sorted(
                (
                    _axis_index(first[edge_axis], levels[edge_axis]),
                    _axis_index(second[edge_axis], levels[edge_axis]),
                )
            )
            if endpoints[0] == endpoints[1]:  # pragma: no cover - quad guard
                raise MeshOrderingError(
                    "Frozen exposed QUAD4 contains a zero-length edge"
                )
            edge_groups[(edge_axis, constant_index)].append(
                (endpoints[0], endpoints[1], facet_index)
            )

    for intervals in edge_groups.values():
        ordered = sorted(intervals)
        for index, first in enumerate(ordered):
            first_lower, first_upper, first_facet = first
            exact_owners = {
                facet
                for lower, upper, facet in ordered
                if lower == first_lower and upper == first_upper
            }
            if len(exact_owners) > 2:
                raise MeshOrderingError(
                    "Frozen exposed QUAD4 multiblock has a non-manifold edge"
                )
            for second_lower, second_upper, second_facet in ordered[index + 1 :]:
                if second_lower >= first_upper:
                    break
                if first_facet == second_facet:
                    continue
                if (
                    first_lower == second_lower
                    and first_upper == second_upper
                ):
                    continue
                if min(first_upper, second_upper) > max(
                    first_lower, second_lower
                ):
                    raise MeshOrderingError(
                        "Frozen exposed QUAD4 multiblock contains a partial-edge "
                        "T-junction; consuming it would require splitting an "
                        "immutable facet"
                    )


def _validate_frozen_locked_edges(
    patch: MatchedFrozenBoundaryPatch,
    *,
    target_edge_mm: float,
) -> tuple[int, float]:
    """Return immutable target overrides without weakening the Frozen trace.

    ``target_edge_mm`` constrains newly generated edges.  It cannot require an
    immutable Frozen facet to be split, so coarser locked edges are retained
    and reported as explicit ordering evidence instead of being rejected.
    """

    override_count = 0
    maximum_edge = 0.0
    for facet in patch.facets:
        nodes = facet.source_node_tags
        for first, second in zip(nodes, (*nodes[1:], nodes[0])):
            edge = math.dist(
                patch.node_coordinates[first],
                patch.node_coordinates[second],
            )
            maximum_edge = max(maximum_edge, edge)
            if edge > target_edge_mm + _tolerance(edge, target_edge_mm):
                override_count += 1
    return override_count, maximum_edge


def _policy_strength(surface_policy: str) -> FacetPolicyStrength:
    if surface_policy == "shared_cartesian_quad":
        return FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
    if surface_policy in {
        "shared_inherited_sweep_surface",
        "shared_gmsh_conformal_surface",
    }:
        return FacetPolicyStrength.CONFORMAL_TRI_OR_QUAD
    raise MeshOrderingError(
        f"unknown shared-surface facet policy {surface_policy!r}"
    )


def _sweep_end_contract(
    control: GeneratedComponentMeshControl,
) -> tuple[frozenset[str], str, str]:
    """Return canonical end sides, source side and destination side."""

    strategy = control.strategy
    if type(strategy) is not StructuredSweepMeshStrategy:
        raise MeshOrderingError(
            "structured_sweep requirement requires an exact directed strategy"
        )
    return {
        ComponentLocalDirection.POSITIVE_X: (
            frozenset(("x_min", "x_max")),
            "x_min",
            "x_max",
        ),
        ComponentLocalDirection.NEGATIVE_X: (
            frozenset(("x_min", "x_max")),
            "x_max",
            "x_min",
        ),
        ComponentLocalDirection.POSITIVE_Y: (
            frozenset(("y_min", "y_max")),
            "y_min",
            "y_max",
        ),
        ComponentLocalDirection.NEGATIVE_Y: (
            frozenset(("y_min", "y_max")),
            "y_max",
            "y_min",
        ),
        ComponentLocalDirection.POSITIVE_Z: (
            frozenset(("z_min", "z_max")),
            "z_min",
            "z_max",
        ),
        ComponentLocalDirection.NEGATIVE_Z: (
            frozenset(("z_min", "z_max")),
            "z_max",
            "z_min",
        ),
    }[strategy.direction]


def _is_sweep_end_side(
    side_name: str,
    control: GeneratedComponentMeshControl,
) -> bool:
    end_sides, _source, _destination = _sweep_end_contract(control)
    return _normalized_side_name(side_name) in end_sides


def _side_for_component(
    face: AdjacentFaceExecutionContract,
    component_id: str,
) -> CanonicalAdjacentSide:
    if face.first_side.component_id == component_id:
        return face.first_side
    if face.second_side.component_id == component_id:
        return face.second_side
    raise MeshOrderingError("actual face does not contain its directed endpoint")


def _fragment_mapping(
    components: Mapping[str, CanonicalComponentGeometry],
) -> Mapping[str, CanonicalGeometryFragment]:
    output = {
        fragment.fragment_id: fragment
        for component in components.values()
        for fragment in component.fragments
    }
    expected = sum(len(component.fragments) for component in components.values())
    if len(output) != expected:
        raise MeshOrderingError("canonical fragment IDs must be globally unique")
    return MappingProxyType(output)


def _complete_side_area(
    fragment: CanonicalGeometryFragment,
    side_name: str,
) -> float:
    try:
        return canonical_side_area_mm2(fragment, _normalized_side_name(side_name))
    except Exception as error:
        raise MeshOrderingError(
            f"canonical side {side_name!r} has no complete analytic area proof"
        ) from error


def _area_is_complete(
    fragment: CanonicalGeometryFragment,
    side_name: str,
    area_mm2: float,
) -> bool:
    complete = _complete_side_area(fragment, side_name)
    return math.isclose(
        area_mm2,
        complete,
        rel_tol=5.0e-7,
        abs_tol=max(1.0e-12, complete * 5.0e-7),
    )


def _validate_input_maps(
    components: Mapping[str, CanonicalComponentGeometry],
    controls: Mapping[str, GeneratedComponentMeshControl],
    requirements: Mapping[str, ComponentMeshRequirement],
) -> tuple[Mapping[str, int], tuple[str, ...]]:
    component_ids = set(components)
    if not component_ids or set(controls) != component_ids or set(requirements) != component_ids:
        raise MeshOrderingError(
            "geometry, mesh controls, and mesh requirements must have identical "
            "Generated Component IDs"
        )
    priorities: dict[str, int] = {}
    for component_id in component_ids:
        component = components[component_id]
        control = controls[component_id]
        requirement = requirements[component_id]
        if (
            type(component) is not CanonicalComponentGeometry
            or component.component_id != component_id
            or type(control) is not GeneratedComponentMeshControl
            or type(requirement) is not ComponentMeshRequirement
            or requirement.component_id != component_id
        ):
            raise MeshOrderingError("Generated Component ordering inputs are stale")
        if control.volume_topology is None or (
            control.volume_topology.value != requirement.volume_topology
        ):
            raise MeshOrderingError(
                "mesh priority control and Component topology requirement differ"
            )
        priorities[component_id] = control.mesh_priority
    duplicate_values = sorted(
        priority
        for priority in set(priorities.values())
        if tuple(priorities.values()).count(priority) > 1
    )
    if duplicate_values:
        raise MeshOrderingError(
            "Generated mesh_priority values must be globally unique positive "
            f"integers; duplicate={duplicate_values[0]}"
        )
    ordered = tuple(sorted(component_ids, key=lambda value: priorities[value]))
    return MappingProxyType(priorities), ordered


def _producer_target(control, side):
    """A lower-priority consumer never contributes a size to its producer."""
    strategy = control.strategy
    if hasattr(strategy, "directional_near_edge_mm"):
        axis = 2 if side in {"z_min", "z_max", "base", "cap", "bottom", "top"} else (0 if "x_" in side else 1)
        return max(value for direction, value in strategy.directional_near_edge_mm.items()
                   if direction.value[-1] != "xyz"[axis])
    return getattr(strategy, "surface_size_mm", None) or getattr(strategy, "plane_size_mm", None) or control.target_edge_mm


def _generated_records(
    adjacency: ComponentAdjacencyExecutionPlan,
    continuity: GeneratedInterfaceContinuityPlan,
    priorities: Mapping[str, int],
    requirements: Mapping[str, ComponentMeshRequirement],
    controls: Mapping[str, GeneratedComponentMeshControl],
) -> list[_SurfaceRecord]:
    groups = {value.group_id: value for value in continuity.groups}
    output: list[_SurfaceRecord] = []
    for face in adjacency.face_pairs:
        first = face.first_side.component_id
        second = face.second_side.component_id
        if first not in priorities or second not in priorities:
            raise MeshOrderingError(
                "actual generated adjacency references an unknown Component"
            )
        if priorities[first] == priorities[second]:
            raise MeshOrderingError(
                "an actual shared surface has equal Generated mesh_priority"
            )
        producer = first if priorities[first] < priorities[second] else second
        consumer = second if producer == first else first
        producer_side = _side_for_component(face, producer)
        consumer_side = _side_for_component(face, consumer)
        group_id = continuity.group_id_by_interface.get(face.interface_id)
        group = groups.get(group_id) if group_id is not None else None
        if group is None:
            raise MeshOrderingError(
                "actual generated face is absent from interface continuity"
            )
        # A continuity group may span both ends of one translation-invariant
        # Sweep and therefore advertises the strongest family present anywhere
        # in that group.  The actual face contract remains authoritative for
        # this adjacent pair; group membership transports sizing, not a remote
        # end's QUAD-only requirement.
        required = _policy_strength(face.surface_policy)
        # Priority owns direction, not facet compatibility.  In particular a
        # lower-priority orthogonal consumer may never force its immutable
        # higher-priority neighbour to be remeshed after the fact: that
        # neighbour must be able to produce a package-Cartesian tensor QUAD
        # contact in its own turn.  State this hard requirement here instead
        # of trusting an upstream surface-policy token to imply it.
        if requirements[consumer].volume_topology == "orthogonal_hex":
            required = max(
                required,
                FacetPolicyStrength.CARTESIAN_TENSOR_QUAD,
            )
        output.append(
            _SurfaceRecord(
                face.face_pair_id,
                "generated",
                face.face_pair_id,
                face.interface_id,
                producer,
                producer_side.fragment_id,
                producer_side.side_name,
                priorities[producer],
                consumer,
                consumer_side.fragment_id,
                consumer_side.side_name,
                priorities[consumer],
                face.area_mm2,
                _producer_target(controls[producer], producer_side.side_name),
                required,
                False,
            )
        )
    return output


def _frozen_records(
    matches: Mapping[FrozenGeneratedInterfaceKey, LoweredFrozenInterfaceMatch],
    patches_by_interface: Mapping[
        FrozenGeneratedInterfaceKey,
        tuple[MatchedFrozenBoundaryPatch, ...],
    ],
    priorities: Mapping[str, int],
    requirements: Mapping[str, ComponentMeshRequirement],
) -> list[_SurfaceRecord]:
    if set(matches) != set(patches_by_interface):
        raise MeshOrderingError(
            "Frozen matches and actual positive-area patches differ"
        )
    output: list[_SurfaceRecord] = []
    for key in sorted(matches):
        match = matches[key]
        generated = key.generated_component_global_id
        if generated not in priorities:
            raise MeshOrderingError("Frozen match targets an unknown Generated Component")
        grouped: dict[
            tuple[str, str], list[MatchedFrozenBoundaryPatch]
        ] = defaultdict(list)
        for patch in patches_by_interface[key]:
            grouped[
                (patch.target_fragment_id, _normalized_side_name(patch.side_name))
            ].append(patch)
        for index, ((fragment_id, side_name), patches) in enumerate(
            sorted(grouped.items()), start=1
        ):
            required = (
                FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
                if requirements[generated].volume_topology == "orthogonal_hex"
                else FacetPolicyStrength.CONFORMAL_TRI_OR_QUAD
            )
            output.append(
                _SurfaceRecord(
                    "frozen::"
                    f"{key.frozen_component_global_id}::"
                    f"{generated}::{fragment_id}::{side_name}::{index:04d}",
                    "frozen",
                    None,
                    None,
                    key.frozen_component_global_id,
                    None,
                    "immutable_exterior",
                    0,
                    generated,
                    fragment_id,
                    side_name,
                    priorities[generated],
                    math.fsum(patch.area_mm2 for patch in patches),
                    requirements[generated].target_edge_mm,
                    required,
                    True,
                    tuple(patches),
                )
            )
    return output


class _UnionFind:
    def __init__(self, identifiers: Sequence[str]) -> None:
        self.parent = {value: value for value in identifiers}

    def find(self, value: str) -> str:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, first: str, second: str) -> None:
        left = self.find(first)
        right = self.find(second)
        if left != right:
            self.parent[max(left, right)] = min(left, right)


def _union_all(union: _UnionFind, values: Sequence[str]) -> None:
    if values:
        for value in values[1:]:
            union.union(values[0], value)


def _point_sum(*values: Point3D) -> Point3D:
    return (
        math.fsum(value[0] for value in values),
        math.fsum(value[1] for value in values),
        math.fsum(value[2] for value in values),
    )


def _points_close(first: Point3D, second: Point3D) -> bool:
    return all(_close(first[axis], second[axis]) for axis in range(3))


def _cartesian_rectangle_edges(
    rectangle: CartesianRectangle,
) -> tuple[tuple[Point3D, Point3D], ...]:
    origin, first_axis, second_axis = rectangle
    first = _point_sum(origin, first_axis)
    opposite = _point_sum(origin, first_axis, second_axis)
    second = _point_sum(origin, second_axis)
    return (
        (origin, first),
        (first, opposite),
        (opposite, second),
        (second, origin),
    )


def _rectangles_share_analytic_edge(
    first: CartesianRectangle,
    second: CartesianRectangle,
) -> bool:
    for first_start, first_end in _cartesian_rectangle_edges(first):
        if _points_close(first_start, first_end):
            continue
        for second_start, second_end in _cartesian_rectangle_edges(second):
            if (
                _points_close(first_start, second_start)
                and _points_close(first_end, second_end)
            ) or (
                _points_close(first_start, second_end)
                and _points_close(first_end, second_start)
            ):
                return True
    return False


def _generated_side_endpoints(
    records: Sequence[_SurfaceRecord],
    fragments: Mapping[str, CanonicalGeometryFragment],
) -> Mapping[
    str,
    tuple[tuple[_SurfaceRecord, str, CartesianRectangle, bool], ...],
]:
    by_fragment: dict[
        str,
        list[tuple[_SurfaceRecord, str, CartesianRectangle, bool]],
    ] = defaultdict(list)
    for record in records:
        if record.source_kind != "generated":
            continue
        assert record.producer_fragment_id is not None
        endpoints = (
            (
                record.producer_fragment_id,
                _normalized_side_name(record.producer_side_name),
                False,
            ),
            (
                record.consumer_fragment_id,
                _normalized_side_name(record.consumer_side_name),
                True,
            ),
        )
        for fragment_id, side_name, is_consumer in endpoints:
            rectangle = canonical_side_cartesian_rectangle(
                fragments[fragment_id],
                side_name,
            )
            if rectangle is not None:
                by_fragment[fragment_id].append(
                    (record, side_name, rectangle, is_consumer)
                )
    return MappingProxyType(
        {
            fragment_id: tuple(values)
            for fragment_id, values in by_fragment.items()
        }
    )


def _union_generated_tensor_shared_edges(
    union: _UnionFind,
    records: Sequence[_SurfaceRecord],
    fragments: Mapping[str, CanonicalGeometryFragment],
) -> None:
    """Propagate one uniform tensor target across analytic side edges.

    This deliberately covers only mutable Generated surfaces.  A union group
    containing any Frozen record is excluded instead of changing an immutable
    trace or pretending that a staircase is an analytic shared edge.
    """

    members_by_root: dict[str, list[_SurfaceRecord]] = defaultdict(list)
    for record in records:
        members_by_root[union.find(record.surface_id)].append(record)
    tensor_roots = {
        root
        for root, values in members_by_root.items()
        if all(value.source_kind == "generated" for value in values)
        and max(value.direct_required_policy for value in values)
        >= FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
    }
    for endpoints in _generated_side_endpoints(records, fragments).values():
        for index, endpoint in enumerate(endpoints):
            first, first_side, first_rectangle, _first_is_consumer = endpoint
            first_root = union.find(first.surface_id)
            if first_root not in tensor_roots:
                continue
            for second, second_side, second_rectangle, _second_is_consumer in endpoints[
                index + 1 :
            ]:
                second_root = union.find(second.surface_id)
                if (
                    second_root not in tensor_roots
                    or first_root == second_root
                    or first_side == second_side
                ):
                    continue
                if _rectangles_share_analytic_edge(
                    first_rectangle,
                    second_rectangle,
                ):
                    union.union(first.surface_id, second.surface_id)


def _shared_cartesian_edge(
    first: CartesianRectangle,
    second: CartesianRectangle,
) -> tuple[Point3D, Point3D] | None:
    for first_start, first_end in _cartesian_rectangle_edges(first):
        if _points_close(first_start, first_end):
            continue
        for second_start, second_end in _cartesian_rectangle_edges(second):
            if (
                _points_close(first_start, second_start)
                and _points_close(first_end, second_end)
            ) or (
                _points_close(first_start, second_end)
                and _points_close(first_end, second_start)
            ):
                return tuple(sorted((first_start, first_end)))  # type: ignore[return-value]
    return None


def _edge_coordinate_key(point: Sequence[float]) -> Point3D:
    return tuple(round(float(value), 12) for value in point)  # type: ignore[return-value]


def _edge_key_local(
    edge: tuple[Point3D, Point3D],
) -> tuple[Point3D, Point3D]:
    return tuple(sorted(_edge_coordinate_key(point) for point in edge))  # type: ignore[return-value]


def _point_on_cartesian_edge(
    point: Point3D,
    edge: tuple[Point3D, Point3D],
) -> bool:
    start, end = edge
    varying = tuple(
        axis for axis in range(3) if not _close(start[axis], end[axis])
    )
    if len(varying) != 1:
        raise MeshOrderingError("shared Cartesian side edge is not one axis segment")
    axis = varying[0]
    return all(
        _close(point[constant], start[constant])
        for constant in range(3)
        if constant != axis
    ) and (
        min(start[axis], end[axis]) - _tolerance(start[axis], end[axis])
        <= point[axis]
        <= max(start[axis], end[axis]) + _tolerance(start[axis], end[axis])
    )


def _uniform_edge_points(
    edge: tuple[Point3D, Point3D],
    target_edge_mm: float,
) -> tuple[Point3D, ...]:
    start, end = edge
    length = math.dist(start, end)
    divisions = max(1, math.ceil(length / target_edge_mm))
    return tuple(
        tuple(
            start[axis] + (end[axis] - start[axis]) * index / divisions
            for axis in range(3)
        )
        for index in range(divisions + 1)
    )  # type: ignore[return-value]


def _frozen_edge_trace(
    record: _SurfaceRecord,
    fragment: CanonicalGeometryFragment,
    edge: tuple[Point3D, Point3D],
) -> tuple[tuple[Point3D, ...], tuple[int, ...]]:
    """Extract an exact immutable one-dimensional trace from Frozen QUADs."""

    point_by_key: dict[Point3D, tuple[Point3D, int]] = {}
    actual_segments: set[tuple[Point3D, Point3D]] = set()
    for patch in record.frozen_patches:
        local_by_node = {
            node: _package_to_local(point, fragment.placement)
            for node, point in patch.node_coordinates.items()
        }
        for node, local in local_by_node.items():
            if not _point_on_cartesian_edge(local, edge):
                continue
            key = _edge_coordinate_key(local)
            previous = point_by_key.setdefault(key, (local, node))
            if previous[1] != node:
                raise MeshOrderingError(
                    "coincident Frozen Cartesian edge nodes have different "
                    "immutable identities"
                )
        for facet in patch.facets:
            nodes = facet.source_node_tags
            for first_node, second_node in zip(nodes, (*nodes[1:], nodes[0])):
                first = local_by_node[first_node]
                second = local_by_node[second_node]
                if (
                    _point_on_cartesian_edge(first, edge)
                    and _point_on_cartesian_edge(second, edge)
                    and not _points_close(first, second)
                ):
                    actual_segments.add(
                        tuple(
                            sorted(
                                (
                                    _edge_coordinate_key(first),
                                    _edge_coordinate_key(second),
                                )
                            )
                        )  # type: ignore[arg-type]
                    )
    if len(point_by_key) < 2:
        raise MeshOrderingError(
            "Frozen Cartesian side does not expose its complete shared edge"
        )
    varying = next(
        axis for axis in range(3) if not _close(edge[0][axis], edge[1][axis])
    )
    ordered = tuple(
        sorted(point_by_key.items(), key=lambda value: value[0][varying])
    )
    local_points = tuple(value[1][0] for value in ordered)
    tags = tuple(value[1][1] for value in ordered)
    expected_endpoints = tuple(sorted(edge, key=lambda point: point[varying]))
    if not (
        _points_close(local_points[0], expected_endpoints[0])
        and _points_close(local_points[-1], expected_endpoints[1])
    ):
        raise MeshOrderingError(
            "Frozen Cartesian side does not cover the complete shared edge"
        )
    expected_segments = {
        tuple(sorted((_edge_coordinate_key(first), _edge_coordinate_key(second))))
        for first, second in zip(local_points, local_points[1:])
    }
    if actual_segments != expected_segments:
        raise MeshOrderingError(
            "Frozen Cartesian shared edge contains a gap or partial-edge "
            "T-junction"
        )
    return local_points, tags


def _same_edge_points(
    first: Sequence[Point3D],
    second: Sequence[Point3D],
) -> bool:
    return len(first) == len(second) and all(
        _points_close(left, right) for left, right in zip(first, second)
    )


def _shared_edge_identifier(
    fragment_id: str,
    edge: tuple[Point3D, Point3D],
) -> str:
    coordinates = "::".join(
        ",".join(value.hex() for value in point) for point in edge
    )
    return f"cartesian-edge::{fragment_id}::{coordinates}"


def _generated_edge_node_token(point: Point3D) -> str:
    coordinates = ":".join(
        (0.0 if value == 0.0 else value).hex() for value in point
    )
    return f"generated:cartesian-edge-node:{coordinates}"


def _plan_tensor_shared_edge_authorities(
    records: Sequence[_SurfaceRecord],
    fragments: Mapping[str, CanonicalGeometryFragment],
    controls: Mapping[str, GeneratedComponentMeshControl],
) -> tuple[OrderedSharedEdgeAuthority, ...]:
    """Plan only common 1D traces; never merge independent side interiors."""

    endpoints_by_fragment: dict[
        str, list[tuple[_SurfaceRecord, str, CartesianRectangle]]
    ] = defaultdict(list)
    for fragment_id, endpoints in _generated_side_endpoints(
        records, fragments
    ).items():
        endpoints_by_fragment[fragment_id].extend(
            (record, side, rectangle)
            for record, side, rectangle, _is_consumer in endpoints
            if record.required_policy
            >= FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
        )
    for record in records:
        if (
            record.source_kind != "frozen"
            or record.required_policy
            < FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
        ):
            continue
        fragment_id = record.consumer_fragment_id
        side = _normalized_side_name(record.consumer_side_name)
        rectangle = canonical_side_cartesian_rectangle(
            fragments[fragment_id], side
        )
        if rectangle is not None:
            endpoints_by_fragment[fragment_id].append((record, side, rectangle))

    records_by_edge: dict[
        tuple[str, tuple[Point3D, Point3D]], dict[str, _SurfaceRecord]
    ] = {}
    for fragment_id, endpoints in endpoints_by_fragment.items():
        for index, (first, first_side, first_rectangle) in enumerate(endpoints):
            for second, second_side, second_rectangle in endpoints[index + 1 :]:
                if first.surface_id == second.surface_id or first_side == second_side:
                    continue
                shared = _shared_cartesian_edge(first_rectangle, second_rectangle)
                if shared is None:
                    continue
                edge = _edge_key_local(shared)
                values = records_by_edge.setdefault((fragment_id, edge), {})
                values[first.surface_id] = first
                values[second.surface_id] = second

    provisional: list[
        tuple[
            str,
            str,
            tuple[str, ...],
            tuple[Point3D, ...],
            tuple[int, ...] | None,
            bool,
        ]
    ] = []
    for (fragment_id, edge), values in sorted(records_by_edge.items()):
        incident = tuple(values[key] for key in sorted(values))
        generated = tuple(value for value in incident if value.source_kind == "generated")
        frozen = tuple(value for value in incident if value.source_kind == "frozen")
        target = min(value.negotiated_target_edge_mm for value in incident)
        uniform = _uniform_edge_points(edge, target)
        if generated:
            first = min(generated, key=lambda value: value.producer_priority)
            strategy = controls[first.producer_component_id].strategy
            producer = fragments[first.producer_fragment_id]
            if type(strategy) is OrthogonalHexMeshStrategy:
                package_edge = tuple(_local_to_package(p, fragments[fragment_id].placement) for p in edge)
                local_edge = tuple(_package_to_local(p, producer.placement) for p in package_edge)
                axis = next(a for a in range(3) if not _close(local_edge[0][a],local_edge[1][a]))
                lower,upper = sorted(p[axis] for p in local_edge)
                origin = geometry_origin(producer.root, strategy.sizing, strategy.partition_origin_mm)
                anchor = lower if origin is None else origin[axis]
                negative = strategy.directional_near_edge_mm[ComponentLocalDirection("negative_"+"xyz"[axis])]
                positive = strategy.directional_near_edge_mm[ComponentLocalDirection("positive_"+"xyz"[axis])]
                levels = interval_levels(lower,upper,negative,positive,anchor,strategy.sizing)
                points = []
                for value in levels:
                    point = list(local_edge[0]); point[axis] = value
                    package = _local_to_package(tuple(point),producer.placement)
                    points.append(_package_to_local(package,fragments[fragment_id].placement))
                uniform = tuple(sorted(points))
        selected_points = uniform
        selected_tags: tuple[int, ...] | None = None
        for value in frozen:
            frozen_points, frozen_tags = _frozen_edge_trace(
                value, fragments[fragment_id], edge
            )
            if selected_tags is None:
                selected_points = frozen_points
                selected_tags = frozen_tags
            elif not _same_edge_points(selected_points, frozen_points) or (
                selected_tags != frozen_tags
            ):
                raise MeshOrderingError(
                    "adjacent immutable Frozen Cartesian side partitions have "
                    "incompatible shared-edge node authority"
                )
        # A generated schedule is a free-size proposal, not a second locked
        # front. The immutable edge wins and is transported to both surfaces.
        package_points = tuple(
            _local_to_package(point, fragments[fragment_id].placement)
            for point in selected_points
        )
        provisional.append(
            (
                _shared_edge_identifier(fragment_id, edge),
                fragment_id,
                tuple(value.surface_id for value in incident),
                package_points,
                selected_tags,
                bool(frozen),
            )
        )

    frozen_token_by_coordinate: dict[Point3D, str] = {}
    for _edge_id, _fragment_id, _surfaces, points, tags, _immutable in provisional:
        if tags is None:
            continue
        for point, tag in zip(points, tags):
            key = _edge_coordinate_key(point)
            token = f"frozen:node:{tag}"
            previous = frozen_token_by_coordinate.setdefault(key, token)
            if previous != token:
                raise MeshOrderingError(
                    "coincident Frozen shared-edge vertices have different "
                    "immutable semantic identities"
                )

    return tuple(
        OrderedSharedEdgeAuthority(
            edge_id,
            fragment_id,
            surfaces,
            points,
            tuple(
                frozen_token_by_coordinate.get(
                    _edge_coordinate_key(point),
                    _generated_edge_node_token(point),
                )
                for point in points
            ),
            immutable,
        )
        for edge_id, fragment_id, surfaces, points, _tags, immutable in provisional
    )


def _directed_graph_is_acyclic(
    records: Sequence[_SurfaceRecord],
    priority_by_component: Mapping[str, int],
) -> None:
    nodes = set(priority_by_component)
    successors: dict[str, set[str]] = defaultdict(set)
    indegree = {value: 0 for value in nodes}
    for record in records:
        nodes.update((record.producer_component_id, record.consumer_component_id))
        indegree.setdefault(record.producer_component_id, 0)
        indegree.setdefault(record.consumer_component_id, 0)
        if record.consumer_component_id not in successors[record.producer_component_id]:
            successors[record.producer_component_id].add(record.consumer_component_id)
            indegree[record.consumer_component_id] += 1
    available = deque(sorted(value for value, degree in indegree.items() if degree == 0))
    visited = 0
    while available:
        current = available.popleft()
        visited += 1
        for successor in sorted(successors[current]):
            indegree[successor] -= 1
            if indegree[successor] == 0:
                available.append(successor)
    if visited != len(indegree):
        raise MeshOrderingError("mesh-priority surface constraints contain a cycle")


def plan_mesh_ordering(
    components: Mapping[str, CanonicalComponentGeometry],
    controls: Mapping[str, GeneratedComponentMeshControl],
    requirements: Mapping[str, ComponentMeshRequirement],
    adjacency: ComponentAdjacencyExecutionPlan,
    continuity: GeneratedInterfaceContinuityPlan,
    frozen_matches: Mapping[
        FrozenGeneratedInterfaceKey, LoweredFrozenInterfaceMatch
    ],
    frozen_patches_by_interface: Mapping[
        FrozenGeneratedInterfaceKey,
        tuple[MatchedFrozenBoundaryPatch, ...],
    ],
) -> MeshOrderingPlan:
    """Validate priority, facet, locked-edge, and sweep constraints.

    The function is pure after its inputs have been constructed.  In
    particular, it neither imports Gmsh nor calls a surface/volume materializer.
    """

    if type(adjacency) is not ComponentAdjacencyExecutionPlan:
        raise MeshOrderingError("adjacency must be an actual execution plan")
    if type(continuity) is not GeneratedInterfaceContinuityPlan:
        raise MeshOrderingError("continuity must be a generated interface plan")
    priorities, generated_order = _validate_input_maps(
        components, controls, requirements
    )
    fragments = _fragment_mapping(components)
    records = _generated_records(adjacency, continuity, priorities, requirements, controls)
    records.extend(
        _frozen_records(
            frozen_matches,
            frozen_patches_by_interface,
            priorities,
            requirements,
        )
    )
    if len({value.surface_id for value in records}) != len(records):
        raise MeshOrderingError("actual surface constraint IDs are not unique")

    priority_by_component = dict(priorities)
    for key in frozen_matches:
        previous = priority_by_component.setdefault(
            key.frozen_component_global_id, 0
        )
        if previous != 0:
            raise MeshOrderingError(
                "Frozen Component identity collides with a Generated priority"
            )
    _directed_graph_is_acyclic(records, priority_by_component)

    record_by_id = {value.surface_id: value for value in records}
    union = _UnionFind(tuple(record_by_id))

    # Existing generated continuity is geometry/topology evidence.  Add every
    # actual face-pair belonging to its interface group, never an ID heuristic.
    ids_by_interface: dict[str, list[str]] = defaultdict(list)
    for record in records:
        if record.interface_id is not None:
            ids_by_interface[record.interface_id].append(record.surface_id)
    for group in continuity.groups:
        _union_all(
            union,
            tuple(
                surface_id
                for interface_id in group.interface_ids
                for surface_id in ids_by_interface.get(interface_id, ())
            ),
        )

    side_records: dict[tuple[str, str, str], list[_SurfaceRecord]] = defaultdict(list)
    for record in records:
        if record.source_kind == "generated":
            assert record.producer_fragment_id is not None
            side_records[
                (
                    record.producer_component_id,
                    record.producer_fragment_id,
                    _normalized_side_name(record.producer_side_name),
                )
            ].append(record)
        side_records[
            (
                record.consumer_component_id,
                record.consumer_fragment_id,
                _normalized_side_name(record.consumer_side_name),
            )
        ].append(record)

    complete_by_side: dict[tuple[str, str, str], bool] = {}
    for side_key, values in side_records.items():
        _component_id, fragment_id, side_name = side_key
        fragment = fragments[fragment_id]
        area = math.fsum(value.area_mm2 for value in values)
        complete = _complete_side_area(fragment, side_name)
        tolerance = max(1.0e-12, complete * 5.0e-7)
        if area > complete + tolerance:
            raise MeshOrderingError(
                "one canonical side is claimed by overlapping positive-area "
                "surface constraints"
            )
        complete_by_side[side_key] = math.isclose(
            area, complete, rel_tol=5.0e-7, abs_tol=tolerance
        )
        # A canonical side is only a host for contact domains, not itself a
        # topology-equivalence domain.  Distinct positive-area contacts may be
        # disjoint subsets of the same side (for example an immutable Frozen
        # island beside a Generated frame footprint).  Joining them here would
        # incorrectly transport the strongest policy and finest target across
        # their non-contacting interiors.  Actual Generated face-pairs are
        # already joined above through explicit continuity evidence; Frozen
        # records carry the policy required by their own actual match.

    # Complete and partial invariant sweep ends may both carry conformal
    # TRI3/QUAD4.  The runtime materializer accepts a partial mixed patch only
    # after proving that it is one planar subregion with an unambiguous
    # Box/Frame complement, then asks Gmsh to mesh that remainder.  An
    # outgoing Orth consumer still strengthens the connected end contract
    # below and therefore retains the all-QUAD requirement.

    # Extend continuity through translational ends, including Frozen priority-0
    # surfaces which are intentionally absent from generated-only continuity
    # DTOs.  A structured sweep transports even a partial locked end patch
    # through its completed invariant section, so both ends must negotiate one
    # target size before materialization.  Facet family is still a property of
    # each actual adjacent pair: a QUAD-only contact on one end does not turn an
    # unrelated Sweep/Hybrid contact on the opposite end into QUAD-only.
    # Orthogonal HEX has no such partial end-completion contract and retains the
    # complete-side requirement.
    for component_id, component in components.items():
        topology = requirements[component_id].volume_topology
        sweep_end_sides: frozenset[str] | None = None
        if topology == "structured_sweep":
            sweep_end_sides, _source_side, _destination_side = (
                _sweep_end_contract(controls[component_id])
            )
            direction = controls[component_id].strategy.direction
            axis = {
                ComponentLocalDirection.POSITIVE_X: 0,
                ComponentLocalDirection.NEGATIVE_X: 0,
                ComponentLocalDirection.POSITIVE_Y: 1,
                ComponentLocalDirection.NEGATIVE_Y: 1,
                ComponentLocalDirection.POSITIVE_Z: 2,
                ComponentLocalDirection.NEGATIVE_Z: 2,
            }[direction]  # type: ignore[union-attr]
            for fragment in component.fragments:
                if type(fragment.root) is CanonicalBox:
                    continue
                if (
                    type(fragment.root) is CanonicalRectangularFrameExtrusion
                    and axis == 2
                ):
                    continue
                geometry_name = type(fragment.root).__name__
                raise MeshOrderingError(
                    f"structured_sweep direction {direction.value!r} is not "
                    f"executable for {geometry_name}: the selected axis must "
                    "have one translation-invariant section"
                )
        if topology not in {"structured_sweep", "orthogonal_hex"}:
            continue
        for fragment in component.fragments:
            end_side_names = (
                tuple(sorted(sweep_end_sides))
                if topology == "structured_sweep"
                else ("z_min", "z_max")
            )
            end_values = {
                side: side_records.get((component_id, fragment.fragment_id, side), ())
                for side in end_side_names
            }
            for side, values in end_values.items():
                if values and complete_by_side[
                    (component_id, fragment.fragment_id, side)
                ]:
                    _union_all(union, tuple(value.surface_id for value in values))
            complete_both = all(
                end_values[side]
                and complete_by_side[(component_id, fragment.fragment_id, side)]
                for side in end_side_names
            )
            sweep_connects_partial_ends = (
                topology == "structured_sweep"
                and all(end_values[side] for side in end_side_names)
            )
            if complete_both or sweep_connects_partial_ends:
                union.union(
                    end_values[end_side_names[0]][0].surface_id,
                    end_values[end_side_names[1]][0].surface_id,
                )

    # A sweep which owns an end consumed by Orth asks the backend for explicit
    # tensor-QUAD/HEX mode.  Lateral locks then constrain that same tensor and
    # must share the earliest producer's sizing authority. Hybrid/Sweep consumers can
    # instead inherit the sweep's native mixed TRI/QUAD end, so they do not
    # activate this orthogonal-only rule.
    for component_id, component in components.items():
        if requirements[component_id].volume_topology != "structured_sweep":
            continue
        sweep_control = controls[component_id]
        for fragment in component.fragments:
            outgoing_orthogonal_ends = tuple(
                record
                for record in records
                if record.source_kind == "generated"
                and record.producer_component_id == component_id
                and record.producer_fragment_id == fragment.fragment_id
                and _is_sweep_end_side(
                    record.producer_side_name,
                    sweep_control,
                )
                and requirements[record.consumer_component_id].volume_topology
                == "orthogonal_hex"
            )
            if not outgoing_orthogonal_ends:
                continue
            constrained = list(outgoing_orthogonal_ends)
            constrained.extend(
                record
                for record in records
                if record.consumer_component_id == component_id
                and record.consumer_fragment_id == fragment.fragment_id
                and not _is_sweep_end_side(
                    record.consumer_side_name,
                    sweep_control,
                )
            )
            for record in constrained:
                record.direct_required_policy = max(
                    record.direct_required_policy,
                    FacetPolicyStrength.CARTESIAN_TENSOR_QUAD,
                )
            _union_all(union, tuple(record.surface_id for record in constrained))

    # Two perpendicular Generated tensor sides on one canonical fragment share
    # their complete analytic edge.  They must therefore choose one interval
    # sequence before either producer runs.  Unifying their constraint groups
    # transports the earliest producer's scalar target through the equivalence
    # reduction below.  It does not strengthen an incident surface's facet
    # family; that remains its direct actual-adjacency contract.
    _union_generated_tensor_shared_edges(union, records, fragments)

    equivalence: dict[str, list[_SurfaceRecord]] = defaultdict(list)
    for record in records:
        equivalence[union.find(record.surface_id)].append(record)
    for values in equivalence.values():
        first_priority = min(value.producer_priority for value in values)
        target = max(value.direct_target_edge_mm for value in values if value.producer_priority == first_priority)
        for value in values:
            value.negotiated_target_edge_mm = target
            value.required_policy = value.direct_required_policy

    for record in records:
        if record.required_policy < FacetPolicyStrength.CARTESIAN_TENSOR_QUAD:
            continue
        endpoint_fragment_ids = [record.consumer_fragment_id]
        if record.producer_fragment_id is not None:
            endpoint_fragment_ids.append(record.producer_fragment_id)
        if any(
            not _placement_is_package_cartesian(fragments[fragment_id].placement)
            for fragment_id in endpoint_fragment_ids
        ):
            orth_components = tuple(
                c
                for c in (record.producer_component_id, record.consumer_component_id)
                if c in requirements
                and requirements[c].volume_topology == "orthogonal_hex"
            )
            reason = (
                f"Cartesian contact {record.surface_id!r} has a Component frame "
                "that is not aligned with package Cartesian axes"
            )
            if orth_components:
                from .package_v2_orthogonal_domain_planning import (
                    OrthogonalConstraintError,
                )

                raise OrthogonalConstraintError(
                    "orth_coordinate_frame_unsupported",
                    reason,
                    components=orth_components,
                    sources=(
                        {
                            "component_id": record.producer_component_id,
                            "interface_id": record.surface_id,
                        },
                    ),
                )
            raise MeshOrderingError(reason)

    # Every Frozen edge is immutable.  Cartesian QUAD/tensor proof is required
    # only when the final transported policy is orthogonal; a plain conformal
    # hybrid trace may legitimately retain TRI3 and QUAD4 facets.
    frozen_tensor_entries: dict[
        tuple[str, str],
        list[tuple[MatchedFrozenBoundaryPatch, tuple[int, ...], float]],
    ] = defaultdict(list)
    for record in records:
        if record.source_kind != "frozen":
            continue
        fragment = fragments[record.consumer_fragment_id]
        for patch in record.frozen_patches:
            override_count, maximum_edge = _validate_frozen_locked_edges(
                patch,
                target_edge_mm=record.negotiated_target_edge_mm,
            )
            record.immutable_target_edge_override_count += override_count
            record.immutable_maximum_edge_mm = max(
                record.immutable_maximum_edge_mm,
                maximum_edge,
            )
            if (
                record.required_policy
                < FacetPolicyStrength.AXIS_ORTHOGONAL_RECTANGULAR_QUAD
            ):
                continue
            if (
                requirements[record.consumer_component_id].volume_topology
                == "orthogonal_hex"
            ):
                from .package_v2_orthogonal_domain_planning import (
                    OrthogonalQuad,
                    _quad_bounds,
                )

                for facet in patch.facets:
                    ids = facet.source_node_tags
                    quad = OrthogonalQuad(
                        record.producer_component_id,
                        fragment.fragment_id,
                        record.surface_id,
                        tuple(patch.node_coordinates[n] for n in ids),
                        tuple(f"frozen:node:{n}" for n in ids),
                    )
                    _quad_bounds(quad, (record.consumer_component_id,), 1.0e-10)
                # Retain local overlap/T-junction checks; the domain planner
                # later coordinates different sides and first-exit intervals.
            for facet in patch.facets:
                frozen_tensor_entries[
                    (
                        fragment.fragment_id,
                        _normalized_side_name(patch.side_name),
                    )
                ].append(
                    (
                        patch,
                        facet.source_node_tags,
                        record.negotiated_target_edge_mm,
                    )
                )
    for (fragment_id, side_name), entries in frozen_tensor_entries.items():
        try:
            _validate_frozen_multiblock_for_side(
                entries, fragments[fragment_id]
            )
        except MeshOrderingError as error:
            affected = [
                r
                for r in records
                if r.consumer_fragment_id == fragment_id and r.source_kind == "frozen"
            ]
            orth = [
                r
                for r in affected
                if requirements[r.consumer_component_id].volume_topology
                == "orthogonal_hex"
            ]
            if orth:
                from .package_v2_orthogonal_domain_planning import (
                    OrthogonalConstraintError,
                )

                raise OrthogonalConstraintError(
                    "orth_locked_interface_conflict",
                    str(error),
                    components=tuple(r.consumer_component_id for r in orth),
                    sources=tuple(
                        {
                            "component_id": r.producer_component_id,
                            "interface_id": r.surface_id,
                        }
                        for r in orth
                    ),
                ) from error
            raise MeshOrderingError(
                "Frozen orthogonal contact on fragment "
                f"{fragment_id!r}, side {side_name!r}: {error}"
            ) from error

    shared_edge_authorities = _plan_tensor_shared_edge_authorities(
        records,
        fragments,
        controls,
    )

    outgoing_by_component: dict[str, list[_SurfaceRecord]] = defaultdict(list)
    incoming_by_component: dict[str, list[_SurfaceRecord]] = defaultdict(list)
    for record in records:
        incoming_by_component[record.consumer_component_id].append(record)
        if record.source_kind == "generated":
            outgoing_by_component[record.producer_component_id].append(record)

    capability_by_surface: dict[str, FacetPolicyStrength] = {
        record.surface_id: record.required_policy
        for record in records
        if record.source_kind == "frozen"
    }
    for component_id in generated_order:
        component = components[component_id]
        topology = requirements[component_id].volume_topology
        incoming = incoming_by_component.get(component_id, ())
        for record in incoming:
            capability = capability_by_surface.get(record.surface_id)
            if capability is None:
                raise MeshOrderingError(
                    "lower-priority Component reached a surface before its "
                    "higher-priority producer"
                )
            if capability < record.required_policy:
                raise MeshOrderingError(
                    "higher-priority contact surface cannot provide the required "
                    f"{record.required_policy.token} facet policy"
                )

        sweep_seed_capability: dict[str, FacetPolicyStrength | None] = {}
        if topology == "structured_sweep":
            sweep_end_sides, sweep_source_side, _sweep_destination_side = (
                _sweep_end_contract(controls[component_id])
            )
            for fragment in component.fragments:
                incoming_end_sides: dict[str, list[_SurfaceRecord]] = defaultdict(list)
                for record in incoming:
                    if record.consumer_fragment_id != fragment.fragment_id:
                        continue
                    side = _normalized_side_name(record.consumer_side_name)
                    if side in sweep_end_sides:
                        incoming_end_sides[side].append(record)
                if len(incoming_end_sides) > 1:
                    raise MeshOrderingError(
                        "structured_sweep cannot inherit two independently fixed "
                        "end surfaces"
                    )
                if incoming_end_sides:
                    side, values = next(iter(incoming_end_sides.items()))
                    if side != sweep_source_side:
                        direction = controls[component_id].strategy.direction  # type: ignore[union-attr]
                        raise MeshOrderingError(
                            "structured_sweep incoming end conflicts with its "
                            f"explicit direction {direction.value!r}: inherited "
                            f"end is {side!r}, required source end is "
                            f"{sweep_source_side!r}"
                        )
                    seed = min(capability_by_surface[value.surface_id] for value in values)
                    minimum_seed = FacetPolicyStrength.CONFORMAL_TRI_OR_QUAD
                    if seed < minimum_seed:
                        raise MeshOrderingError(
                            "structured_sweep inherited end patch must contain "
                            "conformal TRI3/QUAD4 facets"
                        )
                    sweep_seed_capability[fragment.fragment_id] = seed
                else:
                    sweep_seed_capability[fragment.fragment_id] = None

        # Disjoint overlaps on one side share one producer mesh. Each contract
        # selects only its own facets; multiple consumers do not duplicate or
        # remesh the physical side.
        for record in outgoing_by_component.get(component_id, ()):
            assert record.producer_fragment_id is not None
            fragment = fragments[record.producer_fragment_id]
            side_name = _normalized_side_name(record.producer_side_name)
            # Authority applies to the actual overlap, not the entire side.
            # Materialization must imprint its boundary before meshing and
            # prove exact facet coverage; partial overlap is not a blocker.
            if topology == "orthogonal_hex":
                capability = FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
            elif topology == "conformal_hybrid":
                capability = (
                    FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
                    if record.required_policy
                    >= FacetPolicyStrength.AXIS_ORTHOGONAL_RECTANGULAR_QUAD
                    and canonical_side_cartesian_rectangle(
                        fragment,
                        side_name,
                    )
                    is not None
                    else FacetPolicyStrength.CONFORMAL_TRI_OR_QUAD
                )
            elif topology == "structured_sweep":
                if _is_sweep_end_side(side_name, controls[component_id]):
                    seed = sweep_seed_capability[record.producer_fragment_id]
                    capability = (
                        FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
                        if record.required_policy
                        >= FacetPolicyStrength.AXIS_ORTHOGONAL_RECTANGULAR_QUAD
                        else FacetPolicyStrength.CONFORMAL_TRI_OR_QUAD
                        if seed is None
                        else seed
                    )
                else:
                    # Extruding an axis-aligned section boundary produces an
                    # immutable rectangular lateral tensor grid even when the
                    # unseeded end surface itself contains triangles.
                    capability = FacetPolicyStrength.CARTESIAN_TENSOR_QUAD
            else:  # guarded by ComponentMeshRequirement
                raise MeshOrderingError("unknown generated volume topology")
            if capability < record.required_policy:
                if (
                    requirements[record.consumer_component_id].volume_topology
                    == "orthogonal_hex"
                ):
                    raise MeshOrderingError(
                        "lower-priority orthogonal_hex Component requires its "
                        "higher-priority contact surface to be a complete "
                        "package-Cartesian tensor QUAD grid"
                    )
                raise MeshOrderingError(
                    "priority-selected higher-priority backend cannot produce the "
                    f"required {record.required_policy.token} contact surface"
                )
            capability_by_surface[record.surface_id] = capability

    if len(capability_by_surface) != len(records):
        raise MeshOrderingError(
            "mesh-priority plan left an actual surface without one producer"
        )

    producer_by_face = {
        record.face_pair_id: record.producer_component_id
        for record in records
        if record.face_pair_id is not None
    }
    constraints = tuple(
        OrderedSurfaceConstraint(
            value.surface_id,
            value.source_kind,
            value.face_pair_id,
            value.producer_component_id,
            value.producer_fragment_id,
            value.producer_side_name,
            value.producer_priority,
            value.consumer_component_id,
            value.consumer_fragment_id,
            value.consumer_side_name,
            value.consumer_priority,
            value.negotiated_target_edge_mm,
            value.required_policy.token,
            value.immutable,
            value.area_mm2,
            (
                SurfaceContactDomainPolicy.ORTHOGONAL_MATERIALIZED.value
                if (
                    value.source_kind == "generated"
                    and requirements[
                        value.producer_component_id
                    ].volume_topology == "orthogonal_hex"
                )
                else SurfaceContactDomainPolicy.CANONICAL_ANALYTIC.value
            ),
            value.immutable_target_edge_override_count,
            value.immutable_maximum_edge_mm,
        )
        for value in sorted(records, key=lambda item: item.surface_id)
    )
    return MeshOrderingPlan(
        generated_order,
        MappingProxyType(priority_by_component),
        MappingProxyType(producer_by_face),
        constraints,
        shared_edge_authorities,
    )


__all__ = [
    "FacetPolicyStrength",
    "MaterializedContactDomain",
    "MeshOrderingError",
    "MeshOrderingPlan",
    "OrderedSharedEdgeAuthority",
    "OrderedSurfaceConstraint",
    "OrderedSurfaceMaterializationAudit",
    "SurfaceContactDomainPolicy",
    "audit_ordered_surface_materialization",
    "plan_mesh_ordering",
]
