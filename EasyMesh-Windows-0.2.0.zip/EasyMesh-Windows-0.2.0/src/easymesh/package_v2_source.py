"""Strict, immutable JSON source model for Package V2 revision 8.

This module is intentionally a source-front-end only.  It decodes UTF-8 JSON
bytes, rejects ambiguous or unsupported input, and returns immutable source
DTOs while retaining the exact input bytes and their SHA-256 identity.  It does
not compile an assembly policy. Revision 8 first resolves its closed local
template graph into numeric fragment declarations, retaining the original bytes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import hashlib
import json
import keyword
import math
from pathlib import PurePosixPath, PureWindowsPath
import re
from types import MappingProxyType
from typing import Mapping, Sequence, TypeAlias

from .package_v2_mesh_sizing import MeshSeedPolicy
from .package_v2_mesh_names import mesh_group_name_error

from .package_assembly import (
    COMPONENT_LOCAL_DIRECTIONS,
    ComponentLocalDirection,
    GeneratedComponentVolumeTopology,
    TemplateDimension,
)
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_SOURCE,
    parse_interface_geometry_tolerance_literal_mm,
)


SOURCE_SCHEMA = "easymesh-package-v2"
SOURCE_SCHEMA_REVISION = 8
MAX_SOURCE_BYTES = 16 * 1024 * 1024
MAX_JSON_NESTING = 64


# The wire schema and every Source authoring surface expose exactly these three
# component-local execution strategies.  Keeping the list next to the strict
# parser prevents GUI/editor option lists from silently drifting away from the
# canonical enum.
AUTHORING_MESH_STRATEGY_TOKENS = (
    GeneratedComponentVolumeTopology.STRUCTURED_SWEEP.value,
    GeneratedComponentVolumeTopology.ORTHOGONAL_HEX.value,
    GeneratedComponentVolumeTopology.CONFORMAL_HYBRID.value,
)


class SourceErrorCode(str, Enum):
    """Stable machine-readable Package V2 source error codes."""

    WRONG_INPUT_TYPE = "V2_WRONG_INPUT_TYPE"
    UTF8_BOM = "V2_UTF8_BOM"
    INVALID_UTF8 = "V2_INVALID_UTF8"
    INVALID_UNICODE = "V2_INVALID_UNICODE"
    INVALID_JSON = "V2_INVALID_JSON"
    DUPLICATE_KEY = "V2_DUPLICATE_KEY"
    NULL_FORBIDDEN = "V2_NULL_FORBIDDEN"
    NONFINITE_NUMBER = "V2_NONFINITE_NUMBER"
    UNKNOWN_SCHEMA = "V2_UNKNOWN_SCHEMA"
    UNKNOWN_REVISION = "V2_UNKNOWN_REVISION"
    UNKNOWN_KEY = "V2_UNKNOWN_KEY"
    MISSING_KEY = "V2_MISSING_KEY"
    WRONG_TYPE = "V2_WRONG_TYPE"
    INVALID_SHAPE = "V2_INVALID_SHAPE"
    INVALID_ID = "V2_INVALID_ID"
    RESERVED_ID = "V2_RESERVED_ID"
    DUPLICATE_ID = "V2_DUPLICATE_ID"
    INVALID_ENUM = "V2_INVALID_ENUM"
    INVALID_UNIT = "V2_INVALID_UNIT"
    INVALID_SCALAR = "V2_INVALID_SCALAR"
    UNKNOWN_REFERENCE = "V2_UNKNOWN_REFERENCE"
    INVALID_RANGE = "V2_INVALID_RANGE"
    INVALID_GEOMETRY_RECORD = "V2_INVALID_GEOMETRY_RECORD"
    INVALID_MESH_CONTROL = "V2_INVALID_MESH_CONTROL"
    UNKNOWN_GEOMETRY_KIND = "V2_UNKNOWN_GEOMETRY_KIND"
    INVALID_PATH = "V2_INVALID_PATH"
    INVALID_ROTATION_MATRIX = "V2_INVALID_ROTATION_MATRIX"
    SOURCE_TOO_LARGE = "V2_SOURCE_TOO_LARGE"
    NESTING_TOO_DEEP = "V2_NESTING_TOO_DEEP"


class PackageV2SourceError(ValueError):
    """One deterministic source diagnostic with a JSON Pointer location."""

    def __init__(
        self,
        code: SourceErrorCode,
        pointer: str,
        message: str,
        *,
        line: int | None = None,
        column: int | None = None,
    ) -> None:
        self.code = code.value
        self.pointer = pointer
        self.message = message
        self.line = line
        self.column = column
        location = pointer if pointer else "<root>"
        suffix = ""
        if line is not None and column is not None:
            suffix = f" (line {line}, column {column})"
        super().__init__(f"{self.code} at {location}: {message}{suffix}")


SourceScalar: TypeAlias = str | int | float


class PackageFamily(str, Enum):
    FCBGA = "fcbga"
    FCCSP = "fccsp"
    CUSTOM = "custom"


class GeometryRecordOperation(str, Enum):
    START_COMPONENT = "start_component"
    APPEND_GEOMETRY = "append_geometry"


@dataclass(frozen=True, slots=True)
class SourceRange:
    minimum: SourceScalar | None = None
    maximum: SourceScalar | None = None


@dataclass(frozen=True, slots=True)
class TemplateParameterSource:
    name: str
    dimension: TemplateDimension
    declared_unit: str
    default: SourceScalar | None = None
    value_range: SourceRange | None = None

    @property
    def required(self) -> bool:
        return self.default is None


@dataclass(frozen=True, slots=True)
class DerivedVariableSource:
    name: str
    dimension: TemplateDimension
    expression_source: str
    value_range: SourceRange | None = None


@dataclass(frozen=True, slots=True)
class BoxGeometrySource:
    identifier: str
    origin: tuple[str, str, str]
    size: tuple[str, str, str]
    kind: str = "box"


@dataclass(frozen=True, slots=True)
class RectangularFrameGeometrySource:
    """Rectangular prism with one strictly interior through-hole."""

    identifier: str
    outer_origin: tuple[str, str, str]
    outer_size: tuple[str, str]
    opening_offset: tuple[str, str]
    opening_size: tuple[str, str]
    height: str
    kind: str = "rectangular_frame_extrusion"


@dataclass(frozen=True, slots=True)
class RectangularUnderfillFilletGeometrySource:
    """Analytic rectangular die-wall/toe underfill envelope."""

    identifier: str
    die_origin: tuple[str, str]
    die_size: tuple[str, str]
    base_z: str
    wall_height: str
    toe_width: str
    top_width: str = "0mm"
    kind: str = "rectangular_underfill_fillet"
    side_widths: tuple[str, str, str, str] | None = field(default=None, kw_only=True)
    top_widths: tuple[str, str, str, str] | None = field(default=None, kw_only=True)


@dataclass(frozen=True, slots=True)
class UnionGeometrySource:
    identifier: str
    children: tuple[GeometrySource, ...]
    kind: str = "union"


@dataclass(frozen=True, slots=True)
class DifferenceGeometrySource:
    identifier: str
    base: GeometrySource
    cutters: tuple[GeometrySource, ...]
    kind: str = "difference"


GeometrySource: TypeAlias = (
    BoxGeometrySource
    | RectangularFrameGeometrySource
    | RectangularUnderfillFilletGeometrySource
    | UnionGeometrySource
    | DifferenceGeometrySource
)


@dataclass(frozen=True, slots=True)
class StructuredSweepMeshStrategySource:
    direction: ComponentLocalDirection
    sizing: MeshSeedPolicy = field(default_factory=MeshSeedPolicy, kw_only=True)
    plane_size_source: str | None = field(default=None, kw_only=True)
    plane_transition_distance_source: str | None = field(default=None, kw_only=True)
    layer_size_source: str | None = field(default=None, kw_only=True)
    partition_origin_source: tuple[str, str, str] | None = field(default=None, kw_only=True)
    kind: GeneratedComponentVolumeTopology = field(
        default=GeneratedComponentVolumeTopology.STRUCTURED_SWEEP,
        init=False,
    )


@dataclass(frozen=True, slots=True)
class ConformalHybridMeshStrategySource:
    surface_size_source: str | None = None
    kind: GeneratedComponentVolumeTopology = field(
        default=GeneratedComponentVolumeTopology.CONFORMAL_HYBRID,
        init=False,
    )


@dataclass(frozen=True, slots=True)
class OrthogonalHexMeshStrategySource:
    """Authored Orth overrides in the generated Component-local frame."""

    directional_near_edge_sources: tuple[
        tuple[ComponentLocalDirection, str], ...
    ] = ()
    partition_origin_source: tuple[str, str, str] | None = None
    sizing: MeshSeedPolicy = field(default_factory=MeshSeedPolicy, kw_only=True)
    kind: GeneratedComponentVolumeTopology = field(
        default=GeneratedComponentVolumeTopology.ORTHOGONAL_HEX,
        init=False,
    )

    @property
    def directional_near_edge_by_direction(
        self,
    ) -> Mapping[ComponentLocalDirection, str]:
        return MappingProxyType(dict(self.directional_near_edge_sources))


GeneratedComponentMeshStrategySource: TypeAlias = (
    StructuredSweepMeshStrategySource
    | OrthogonalHexMeshStrategySource
    | ConformalHybridMeshStrategySource
)


@dataclass(frozen=True, slots=True)
class GeneratedComponentMeshControlSource:
    target_edge_source: str
    mesh_priority: int
    transition_distance_source: str
    strategy: GeneratedComponentMeshStrategySource


@dataclass(frozen=True, slots=True)
class GeometryRecordSource:
    operation: GeometryRecordOperation
    geometry: GeometrySource
    component_id: str | None = None
    material_id: str | None = None
    mesh_control: GeneratedComponentMeshControlSource | None = None
    # Internal numeric placement produced by the closed-template v8 lowerer.
    local_placement: GeneratedInstancePlacementSource | None = None


@dataclass(frozen=True, slots=True)
class TemplateSource:
    """Internal expanded component; local variables have already been resolved."""
    identifier: str
    geometry_records: tuple[GeometryRecordSource, ...]


    @property
    def component_ids(self) -> tuple[str, ...]:
        return tuple(
            record.component_id
            for record in self.geometry_records
            if record.operation is GeometryRecordOperation.START_COMPONENT
            and record.component_id is not None
        )


@dataclass(frozen=True, slots=True)
class GeneratedInstancePlacementSource:
    """Generated Euler placement expressions in the template-instance scope."""

    translation: tuple[str, str, str] = ("0mm", "0mm", "0mm")
    rotation_deg_xyz: tuple[SourceScalar, SourceScalar, SourceScalar] = (
        "0",
        "0",
        "0",
    )
    pivot: tuple[str, str, str] = ("0mm", "0mm", "0mm")


@dataclass(frozen=True, slots=True)
class TemplateInstanceSource:
    identifier: str
    template_id: str


@dataclass(frozen=True, slots=True)
class FrozenArtifactPathsSource:
    mesh: str
    sha256: str | None = None


@dataclass(frozen=True, slots=True)
class FrozenRigidPlacementSource:
    """Frozen-artifact placement using an explicit package-frame matrix."""

    translation: tuple[str, str, str]
    rotation_matrix: tuple[
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
    ]


@dataclass(frozen=True, slots=True)
class FrozenSourceDeclaration:
    identifier: str
    artifacts: FrozenArtifactPathsSource
    components: tuple[str, ...]
    placement: FrozenRigidPlacementSource


# Compatibility name retained explicitly.  Generated instances use
# GeneratedInstancePlacementSource and never this matrix representation.
RigidPlacementSource = FrozenRigidPlacementSource


@dataclass(frozen=True, slots=True)
class PackageMetadataSource:
    identifier: str
    family: PackageFamily


@dataclass(frozen=True, slots=True)
class PackageMeshSettingsSource:
    """Package-global geometry predicates and candidate execution policy."""

    interface_geometry_tolerance_source: str = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_SOURCE
    )
    parallel_tet_candidates: bool = False

    def __post_init__(self) -> None:
        if type(self.parallel_tet_candidates) is not bool:
            raise ValueError("parallel_tet_candidates must be boolean")
        try:
            parse_interface_geometry_tolerance_literal_mm(
                self.interface_geometry_tolerance_source
            )
        except ValueError as error:
            raise ValueError(str(error)) from error

    @property
    def interface_geometry_tolerance_mm(self) -> float:
        return parse_interface_geometry_tolerance_literal_mm(
            self.interface_geometry_tolerance_source
        )


@dataclass(frozen=True, slots=True)
class PackageV2SourceDocument:
    schema: str
    schema_revision: int
    package: PackageMetadataSource
    templates: tuple[TemplateSource, ...]
    instances: tuple[TemplateInstanceSource, ...]
    frozen_sources: tuple[FrozenSourceDeclaration, ...]
    mesh_settings: PackageMeshSettingsSource


@dataclass(frozen=True, slots=True)
class ParsedPackageV2Source:
    source_name: str
    raw_bytes: bytes
    raw_text: str
    raw_sha256: str
    document: PackageV2SourceDocument


@dataclass(frozen=True, slots=True)
class _JSONObjectPairs:
    pairs: tuple[tuple[str, object], ...]


_ASCII_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_ASCII_MATERIAL_NAME = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.+-]*$")
_LENGTH_UNITS = frozenset({"mm", "um", "\N{MICRO SIGN}m", "\N{GREEK SMALL LETTER MU}m"})
_RESERVED_IDENTIFIERS = frozenset(
    {*_LENGTH_UNITS, "__easymesh_length__"}
)


def _pointer(parent: str, token: object) -> str:
    encoded = str(token).replace("~", "~0").replace("/", "~1")
    return f"{parent}/{encoded}" if parent else f"/{encoded}"


def _raise(
    code: SourceErrorCode,
    pointer: str,
    message: str,
    *,
    line: int | None = None,
    column: int | None = None,
) -> None:
    raise PackageV2SourceError(
        code,
        pointer,
        message,
        line=line,
        column=column,
    )


def _pairs_hook(pairs: list[tuple[str, object]]) -> _JSONObjectPairs:
    return _JSONObjectPairs(tuple(pairs))


def _contains_surrogate(value: str) -> bool:
    return any(0xD800 <= ord(character) <= 0xDFFF for character in value)


def _materialize_json(
    value: object,
    pointer: str = "",
    *,
    depth: int = 0,
) -> object:
    if depth > MAX_JSON_NESTING:
        _raise(
            SourceErrorCode.NESTING_TOO_DEEP,
            pointer,
            f"JSON nesting exceeds the limit of {MAX_JSON_NESTING}",
        )
    if isinstance(value, _JSONObjectPairs):
        result: dict[str, object] = {}
        for key, child in value.pairs:
            key_pointer = _pointer(pointer, key)
            if _contains_surrogate(key):
                _raise(
                    SourceErrorCode.INVALID_UNICODE,
                    key_pointer,
                    "JSON object keys must contain Unicode scalar values",
                )
            if key in result:
                _raise(
                    SourceErrorCode.DUPLICATE_KEY,
                    key_pointer,
                    f"duplicate JSON key {key!r}",
                )
            result[key] = _materialize_json(
                child,
                key_pointer,
                depth=depth + 1,
            )
        return result
    if isinstance(value, list):
        return [
            _materialize_json(
                child,
                _pointer(pointer, index),
                depth=depth + 1,
            )
            for index, child in enumerate(value)
        ]
    if value is None:
        _raise(
            SourceErrorCode.NULL_FORBIDDEN,
            pointer,
            "null is not allowed; omit optional fields instead",
        )
    if isinstance(value, float) and not math.isfinite(value):
        _raise(
            SourceErrorCode.NONFINITE_NUMBER,
            pointer,
            "JSON numbers must be finite",
        )
    if isinstance(value, str) and _contains_surrogate(value):
        _raise(
            SourceErrorCode.INVALID_UNICODE,
            pointer,
            "JSON strings must contain Unicode scalar values",
        )
    return value


def _object(value: object, pointer: str) -> dict[str, object]:
    if not isinstance(value, dict):
        _raise(SourceErrorCode.WRONG_TYPE, pointer, "expected an object")
    return value


def _array(value: object, pointer: str) -> list[object]:
    if not isinstance(value, list):
        _raise(SourceErrorCode.WRONG_TYPE, pointer, "expected an array")
    return value


def _check_keys(
    value: Mapping[str, object],
    pointer: str,
    *,
    required: Sequence[str],
    optional: Sequence[str] = (),
) -> None:
    allowed = frozenset((*required, *optional))
    unknown = sorted(set(value).difference(allowed))
    if unknown:
        key = unknown[0]
        _raise(
            SourceErrorCode.UNKNOWN_KEY,
            _pointer(pointer, key),
            f"unknown key {key!r}",
        )
    missing = [key for key in required if key not in value]
    if missing:
        key = missing[0]
        _raise(
            SourceErrorCode.MISSING_KEY,
            _pointer(pointer, key),
            f"missing required key {key!r}",
        )


def _string(value: object, pointer: str, *, field_name: str) -> str:
    if not isinstance(value, str):
        _raise(
            SourceErrorCode.WRONG_TYPE,
            pointer,
            f"{field_name} must be a string",
        )
    if not value.strip():
        _raise(
            SourceErrorCode.INVALID_SCALAR,
            pointer,
            f"{field_name} must not be blank",
        )
    return value


def _identifier(value: object, pointer: str, *, field_name: str) -> str:
    identifier = _string(value, pointer, field_name=field_name)
    if _ASCII_IDENTIFIER.fullmatch(identifier) is None:
        _raise(
            SourceErrorCode.INVALID_ID,
            pointer,
            f"{field_name} must be an ASCII identifier",
        )
    if (
        keyword.iskeyword(identifier)
        or identifier.lower() in _RESERVED_IDENTIFIERS
    ):
        _raise(
            SourceErrorCode.RESERVED_ID,
            pointer,
            f"{field_name} uses reserved name {identifier!r}",
        )
    return identifier


def _material_name(
    value: object,
    pointer: str,
) -> str:
    """Parse a material token accepted by downstream mesh file formats."""

    material = _string(value, pointer, field_name="material name")
    if _ASCII_MATERIAL_NAME.fullmatch(material) is None:
        _raise(
            SourceErrorCode.INVALID_ID,
            pointer,
            "material name must be a safe ASCII token",
        )
    return material


def _variable_identifier(value: object, pointer: str, *, field_name: str) -> str:
    identifier = _identifier(value, pointer, field_name=field_name)
    if (
        keyword.iskeyword(identifier)
        or identifier.lower() in _LENGTH_UNITS
        or identifier == "__easymesh_length__"
    ):
        _raise(
            SourceErrorCode.RESERVED_ID,
            pointer,
            f"{field_name} uses reserved name {identifier!r}",
        )
    return identifier


def _finite_number(value: object, pointer: str, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _raise(
            SourceErrorCode.WRONG_TYPE,
            pointer,
            f"{field_name} must be a finite JSON number",
        )
    try:
        number = float(value)
    except (OverflowError, TypeError, ValueError):
        _raise(
            SourceErrorCode.NONFINITE_NUMBER,
            pointer,
            f"{field_name} must be finite",
        )
    if not math.isfinite(number):
        _raise(
            SourceErrorCode.NONFINITE_NUMBER,
            pointer,
            f"{field_name} must be finite",
        )
    return number


def _positive_mesh_priority(value: object, pointer: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        _raise(
            SourceErrorCode.WRONG_TYPE,
            pointer,
            "component mesh_priority must be a positive JSON integer",
        )
    if value < 1:
        _raise(
            SourceErrorCode.INVALID_MESH_CONTROL,
            pointer,
            "component mesh_priority must be positive",
        )
    return value


def _dimension(value: object, pointer: str) -> TemplateDimension:
    token = _string(value, pointer, field_name="kind")
    try:
        return TemplateDimension(token)
    except ValueError:
        _raise(
            SourceErrorCode.INVALID_ENUM,
            pointer,
            "kind must be 'length' or 'dimensionless'",
        )


def _source_scalar(
    value: object,
    dimension: TemplateDimension,
    pointer: str,
    *,
    field_name: str,
) -> SourceScalar:
    if dimension is TemplateDimension.LENGTH:
        if not isinstance(value, str):
            _raise(
                SourceErrorCode.WRONG_TYPE,
                pointer,
                f"length {field_name} must be a source expression string",
            )
        if not value.strip():
            _raise(
                SourceErrorCode.INVALID_SCALAR,
                pointer,
                f"length {field_name} must not be blank",
            )
        return value
    if isinstance(value, str):
        if not value.strip():
            _raise(
                SourceErrorCode.INVALID_SCALAR,
                pointer,
                f"dimensionless {field_name} must not be blank",
            )
        return value
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _raise(
            SourceErrorCode.WRONG_TYPE,
            pointer,
            f"dimensionless {field_name} must be a finite number or expression string",
        )
    _finite_number(value, pointer, field_name=field_name)
    return value


def _parse_range(
    value: object,
    dimension: TemplateDimension,
    pointer: str,
) -> SourceRange:
    obj = _object(value, pointer)
    _check_keys(obj, pointer, required=(), optional=("min", "max"))
    if not obj:
        _raise(
            SourceErrorCode.INVALID_RANGE,
            pointer,
            "range must declare min, max, or both",
        )
    minimum = (
        _source_scalar(
            obj["min"],
            dimension,
            _pointer(pointer, "min"),
            field_name="range min",
        )
        if "min" in obj
        else None
    )
    maximum = (
        _source_scalar(
            obj["max"],
            dimension,
            _pointer(pointer, "max"),
            field_name="range max",
        )
        if "max" in obj
        else None
    )
    return SourceRange(minimum, maximum)


def _parse_parameter(value: object, pointer: str) -> TemplateParameterSource:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=("name", "kind", "unit"),
        optional=("default", "range"),
    )
    name = _variable_identifier(
        obj["name"],
        _pointer(pointer, "name"),
        field_name="parameter name",
    )
    dimension = _dimension(obj["kind"], _pointer(pointer, "kind"))
    unit = _string(obj["unit"], _pointer(pointer, "unit"), field_name="unit")
    if dimension is TemplateDimension.LENGTH:
        if unit not in _LENGTH_UNITS:
            _raise(
                SourceErrorCode.INVALID_UNIT,
                _pointer(pointer, "unit"),
                "length unit must be mm, um, µm, or μm",
            )
    elif unit != "1":
        _raise(
            SourceErrorCode.INVALID_UNIT,
            _pointer(pointer, "unit"),
            "dimensionless unit must be '1'",
        )
    default = (
        _source_scalar(
            obj["default"],
            dimension,
            _pointer(pointer, "default"),
            field_name="default",
        )
        if "default" in obj
        else None
    )
    value_range = (
        _parse_range(obj["range"], dimension, _pointer(pointer, "range"))
        if "range" in obj
        else None
    )
    return TemplateParameterSource(name, dimension, unit, default, value_range)


def _parse_derived(value: object, pointer: str) -> DerivedVariableSource:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=("name", "kind", "expression"),
        optional=("range",),
    )
    name = _variable_identifier(
        obj["name"],
        _pointer(pointer, "name"),
        field_name="derived variable name",
    )
    dimension = _dimension(obj["kind"], _pointer(pointer, "kind"))
    expression = _string(
        obj["expression"],
        _pointer(pointer, "expression"),
        field_name="derived expression",
    )
    value_range = (
        _parse_range(obj["range"], dimension, _pointer(pointer, "range"))
        if "range" in obj
        else None
    )
    return DerivedVariableSource(name, dimension, expression, value_range)


def _length_expression_vector(
    value: object,
    pointer: str,
    *,
    size: int,
    field_name: str,
) -> tuple[str, ...]:
    items = _array(value, pointer)
    if len(items) != size:
        rendered = "three" if size == 3 else "two" if size == 2 else str(size)
        _raise(
            SourceErrorCode.INVALID_SHAPE,
            pointer,
            f"{field_name} must contain exactly {rendered} length expressions",
        )
    return tuple(
        _source_scalar(
            item,
            TemplateDimension.LENGTH,
            _pointer(pointer, index),
            field_name=field_name,
        )
        for index, item in enumerate(items)
    )


def _length_vector(
    value: object,
    pointer: str,
    *,
    field_name: str,
) -> tuple[str, str, str]:
    return _length_expression_vector(
        value,
        pointer,
        size=3,
        field_name=field_name,
    )  # type: ignore[return-value]


def _dimensionless_expression_vector(
    value: object,
    pointer: str,
    *,
    field_name: str,
) -> tuple[SourceScalar, SourceScalar, SourceScalar]:
    items = _array(value, pointer)
    if len(items) != 3:
        _raise(
            SourceErrorCode.INVALID_SHAPE,
            pointer,
            f"{field_name} must contain exactly three dimensionless expressions",
        )
    return tuple(  # type: ignore[return-value]
        _source_scalar(
            item,
            TemplateDimension.DIMENSIONLESS,
            _pointer(pointer, index),
            field_name=f"{field_name}[{index}]",
        )
        for index, item in enumerate(items)
    )


def _parse_generated_instance_placement(
    value: object,
    pointer: str,
) -> GeneratedInstancePlacementSource:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=("translation", "rotation_deg_xyz", "pivot"),
    )
    return GeneratedInstancePlacementSource(
        translation=_length_vector(
            obj["translation"],
            _pointer(pointer, "translation"),
            field_name="generated instance placement translation",
        ),
        rotation_deg_xyz=_dimensionless_expression_vector(
            obj["rotation_deg_xyz"],
            _pointer(pointer, "rotation_deg_xyz"),
            field_name="generated instance placement rotation_deg_xyz",
        ),
        pivot=_length_vector(
            obj["pivot"],
            _pointer(pointer, "pivot"),
            field_name="generated instance placement pivot",
        ),
    )


def _parse_box(value: object, pointer: str) -> BoxGeometrySource:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=("id", "kind", "origin", "size"),
    )
    identifier = _identifier(
        obj["id"],
        _pointer(pointer, "id"),
        field_name="geometry id",
    )
    kind = _string(obj["kind"], _pointer(pointer, "kind"), field_name="geometry kind")
    if kind != "box":
        _raise(
            SourceErrorCode.UNKNOWN_GEOMETRY_KIND,
            _pointer(pointer, "kind"),
            "expected geometry kind 'box'",
        )
    return BoxGeometrySource(
        identifier,
        _length_vector(obj["origin"], _pointer(pointer, "origin"), field_name="box origin"),
        _length_vector(obj["size"], _pointer(pointer, "size"), field_name="box size"),
    )


def _parse_rectangular_frame(
    value: object,
    pointer: str,
) -> RectangularFrameGeometrySource:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=(
            "id",
            "kind",
            "outer_origin",
            "outer_size",
            "opening_offset",
            "opening_size",
            "height",
        ),
    )
    identifier = _identifier(
        obj["id"],
        _pointer(pointer, "id"),
        field_name="geometry id",
    )
    kind = _string(
        obj["kind"],
        _pointer(pointer, "kind"),
        field_name="geometry kind",
    )
    if kind != "rectangular_frame_extrusion":
        _raise(
            SourceErrorCode.UNKNOWN_GEOMETRY_KIND,
            _pointer(pointer, "kind"),
            "expected geometry kind 'rectangular_frame_extrusion'",
        )
    outer_origin = _length_vector(
        obj["outer_origin"],
        _pointer(pointer, "outer_origin"),
        field_name="rectangular frame outer_origin",
    )
    outer_size = _length_expression_vector(
        obj["outer_size"],
        _pointer(pointer, "outer_size"),
        size=2,
        field_name="rectangular frame outer_size",
    )
    opening_offset = _length_expression_vector(
        obj["opening_offset"],
        _pointer(pointer, "opening_offset"),
        size=2,
        field_name="rectangular frame opening_offset",
    )
    opening_size = _length_expression_vector(
        obj["opening_size"],
        _pointer(pointer, "opening_size"),
        size=2,
        field_name="rectangular frame opening_size",
    )
    height = _source_scalar(
        obj["height"],
        TemplateDimension.LENGTH,
        _pointer(pointer, "height"),
        field_name="rectangular frame height",
    )
    assert isinstance(height, str)
    return RectangularFrameGeometrySource(
        identifier,
        outer_origin,
        outer_size,  # type: ignore[arg-type]
        opening_offset,  # type: ignore[arg-type]
        opening_size,  # type: ignore[arg-type]
        height,
    )


def _parse_rectangular_underfill_fillet(
    value: object,
    pointer: str,
) -> RectangularUnderfillFilletGeometrySource:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=(
            "id",
            "kind",
            "die_origin",
            "die_size",
            "base_z",
            "wall_height",
            "toe_width",
        ),
        optional=("top_width", "side_widths", "top_widths"),
    )
    identifier = _identifier(
        obj["id"],
        _pointer(pointer, "id"),
        field_name="geometry id",
    )
    kind = _string(
        obj["kind"],
        _pointer(pointer, "kind"),
        field_name="geometry kind",
    )
    if kind != "rectangular_underfill_fillet":
        _raise(
            SourceErrorCode.UNKNOWN_GEOMETRY_KIND,
            _pointer(pointer, "kind"),
            "expected geometry kind 'rectangular_underfill_fillet'",
        )
    die_origin = _length_expression_vector(
        obj["die_origin"],
        _pointer(pointer, "die_origin"),
        size=2,
        field_name="rectangular underfill die_origin",
    )
    die_size = _length_expression_vector(
        obj["die_size"],
        _pointer(pointer, "die_size"),
        size=2,
        field_name="rectangular underfill die_size",
    )
    base_z = _source_scalar(
        obj["base_z"],
        TemplateDimension.LENGTH,
        _pointer(pointer, "base_z"),
        field_name="rectangular underfill base_z",
    )
    wall_height = _source_scalar(
        obj["wall_height"],
        TemplateDimension.LENGTH,
        _pointer(pointer, "wall_height"),
        field_name="rectangular underfill wall_height",
    )
    toe_width = _source_scalar(
        obj["toe_width"],
        TemplateDimension.LENGTH,
        _pointer(pointer, "toe_width"),
        field_name="rectangular underfill toe_width",
    )
    top_width = _source_scalar(
        obj.get("top_width", "0mm"),
        TemplateDimension.LENGTH,
        _pointer(pointer, "top_width"),
        field_name="rectangular underfill top_width",
    )
    assert isinstance(base_z, str)
    assert isinstance(wall_height, str)
    assert isinstance(toe_width, str)
    assert isinstance(top_width, str)
    return RectangularUnderfillFilletGeometrySource(
        identifier,
        die_origin,  # type: ignore[arg-type]
        die_size,  # type: ignore[arg-type]
        base_z,
        wall_height,
        toe_width,
        top_width,
        side_widths=(_length_expression_vector(obj["side_widths"], _pointer(pointer, "side_widths"),
                    size=4, field_name="fillet side_widths") if "side_widths" in obj else None),
        top_widths=(_length_expression_vector(obj["top_widths"], _pointer(pointer, "top_widths"),
                    size=4, field_name="fillet top_widths") if "top_widths" in obj else None),
    )


def _parse_geometry(
    value: object,
    pointer: str,
    depth: int = 0,
) -> GeometrySource:
    if depth > 16:
        _raise(
            SourceErrorCode.UNKNOWN_GEOMETRY_KIND,
            pointer,
            "rectilinear CSG nesting exceeds 16 levels",
        )
    obj = _object(value, pointer)
    if "kind" not in obj:
        _raise(
            SourceErrorCode.MISSING_KEY,
            _pointer(pointer, "kind"),
            "missing required key 'kind'",
        )
    kind = _string(
        obj["kind"],
        _pointer(pointer, "kind"),
        field_name="geometry kind",
    )
    if kind in {"union", "difference"}:
        fields = ("children",) if kind == "union" else ("base", "cutters")
        _check_keys(obj, pointer, required=("id", "kind", *fields))
        identifier = _identifier(
            obj["id"], _pointer(pointer, "id"), field_name="geometry id"
        )
        field = "children" if kind == "union" else "cutters"
        items = _array(obj[field], _pointer(pointer, field))
        if len(items) < (2 if kind == "union" else 1):
            _raise(
                SourceErrorCode.UNKNOWN_GEOMETRY_KIND,
                _pointer(pointer, field),
                "union requires two children; difference requires one cutter",
            )

        def child(value, path):
            parsed = _parse_geometry(value, path, depth + 1)
            if isinstance(parsed, RectangularUnderfillFilletGeometrySource):
                _raise(
                    SourceErrorCode.UNKNOWN_GEOMETRY_KIND,
                    path,
                    "CSG accepts rectilinear Box/Frame geometry only",
                )
            return parsed

        values = tuple(
            child(value, _pointer(_pointer(pointer, field), str(i)))
            for i, value in enumerate(items)
        )
        if kind == "union":
            return UnionGeometrySource(identifier, values)
        return DifferenceGeometrySource(
            identifier, child(obj["base"], _pointer(pointer, "base")), values
        )
    if kind == "box":
        return _parse_box(obj, pointer)
    if kind == "rectangular_frame_extrusion":
        return _parse_rectangular_frame(obj, pointer)
    if kind == "rectangular_underfill_fillet":
        return _parse_rectangular_underfill_fillet(obj, pointer)
    _raise(
        SourceErrorCode.UNKNOWN_GEOMETRY_KIND,
        _pointer(pointer, "kind"),
        "supported geometry kinds are 'box', "
        "'rectangular_frame_extrusion', 'rectangular_underfill_fillet', 'union', and 'difference'",
    )


def _optional_size(obj, pointer, name):
    return (_string(obj[name], _pointer(pointer, name), field_name=name)
            if name in obj else None)


def _parse_seed_policy(obj, pointer):
    path = _pointer(pointer, "sizing")
    raw = _object(obj["sizing"], path) if "sizing" in obj else {}
    _check_keys(raw, path, required=(), optional=("constraint", "remainder_ratio", "origin"))
    try:
        policy = MeshSeedPolicy(**raw)
        if policy.origin == "custom" and "partition_origin" not in obj:
            raise ValueError("custom origin requires partition_origin")
        if "partition_origin" in obj and policy.origin not in {"legacy", "custom"}:
            raise ValueError("preset origin and partition_origin cannot both be specified")
        return policy
    except (TypeError, ValueError) as error:
        _raise(SourceErrorCode.INVALID_ENUM, path, str(error))


def _parse_component_mesh_strategy(
    value: object,
    pointer: str,
) -> GeneratedComponentMeshStrategySource:
    obj = _object(value, pointer)
    if "kind" not in obj:
        _raise(
            SourceErrorCode.MISSING_KEY,
            _pointer(pointer, "kind"),
            "missing required key 'kind'",
        )
    kind_source = _string(
        obj["kind"],
        _pointer(pointer, "kind"),
        field_name="component mesh strategy kind",
    )
    try:
        kind = GeneratedComponentVolumeTopology(kind_source)
    except ValueError:
        _raise(
            SourceErrorCode.INVALID_ENUM,
            _pointer(pointer, "kind"),
            "component mesh strategy kind must be 'structured_sweep', "
            "'orthogonal_hex', or 'conformal_hybrid'",
        )
    if kind is GeneratedComponentVolumeTopology.STRUCTURED_SWEEP:
        _check_keys(obj, pointer, required=("kind", "direction"),
                    optional=("sizing", "plane_size", "layer_size", "partition_origin", "plane_transition_distance"))
        direction_pointer = _pointer(pointer, "direction")
        direction_source = _string(
            obj["direction"],
            direction_pointer,
            field_name="structured sweep direction",
        )
        try:
            direction = ComponentLocalDirection(direction_source)
        except ValueError:
            _raise(
                SourceErrorCode.INVALID_ENUM,
                direction_pointer,
                "structured sweep direction must be one of "
                + ", ".join(
                    repr(item.value) for item in COMPONENT_LOCAL_DIRECTIONS
                ),
            )
        return StructuredSweepMeshStrategySource(
            direction, sizing=_parse_seed_policy(obj, pointer),
            plane_size_source=_optional_size(obj, pointer, "plane_size"),
            plane_transition_distance_source=_optional_size(obj, pointer, "plane_transition_distance"),
            layer_size_source=_optional_size(obj, pointer, "layer_size"),
            partition_origin_source=(_length_vector(obj["partition_origin"],
                _pointer(pointer, "partition_origin"), field_name="partition_origin")
                if "partition_origin" in obj else None))
    if kind is GeneratedComponentVolumeTopology.CONFORMAL_HYBRID:
        _check_keys(obj, pointer, required=("kind",), optional=("surface_size",))
        return ConformalHybridMeshStrategySource(_optional_size(obj, pointer, "surface_size"))

    _check_keys(
        obj,
        pointer,
        required=("kind",),
        optional=("directional_near_edge", "partition_origin", "sizing"),
    )
    overrides: list[tuple[ComponentLocalDirection, str]] = []
    if "directional_near_edge" in obj:
        near_pointer = _pointer(pointer, "directional_near_edge")
        near = _object(obj["directional_near_edge"], near_pointer)
        _check_keys(
            near,
            near_pointer,
            required=(),
            optional=tuple(
                direction.value for direction in COMPONENT_LOCAL_DIRECTIONS
            ),
        )
        for direction in COMPONENT_LOCAL_DIRECTIONS:
            if direction.value not in near:
                continue
            value_pointer = _pointer(near_pointer, direction.value)
            overrides.append(
                (
                    direction,
                    _string(
                        near[direction.value],
                        value_pointer,
                        field_name=(
                            "orthogonal directional near-edge expression "
                            f"{direction.value}"
                        ),
                    ),
                )
            )
    partition_origin = (
        _length_vector(
            obj["partition_origin"],
            _pointer(pointer, "partition_origin"),
            field_name="orthogonal partition_origin",
        )
        if "partition_origin" in obj
        else None
    )
    return OrthogonalHexMeshStrategySource(
        tuple(overrides),
        partition_origin,
        sizing=_parse_seed_policy(obj, pointer),
    )


def _parse_component_mesh_control(
    value: object,
    pointer: str,
) -> GeneratedComponentMeshControlSource:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=(
            "target_edge",
            "mesh_priority",
            "transition_distance",
            "strategy",
        ),
    )
    return GeneratedComponentMeshControlSource(
        target_edge_source=_string(
            obj["target_edge"],
            _pointer(pointer, "target_edge"),
            field_name="component target_edge expression",
        ),
        mesh_priority=_positive_mesh_priority(
            obj["mesh_priority"],
            _pointer(pointer, "mesh_priority"),
        ),
        transition_distance_source=_string(
            obj["transition_distance"],
            _pointer(pointer, "transition_distance"),
            field_name="component transition_distance expression",
        ),
        strategy=_parse_component_mesh_strategy(
            obj["strategy"],
            _pointer(pointer, "strategy"),
        ),
    )


def _source_path(value: object, pointer: str, *, field_name: str) -> str:
    path_source = _string(value, pointer, field_name=field_name)
    if path_source != path_source.strip():
        _raise(
            SourceErrorCode.INVALID_PATH,
            pointer,
            f"{field_name} must not contain surrounding whitespace",
        )
    if "~" in path_source or "$" in path_source or "\\" in path_source:
        _raise(
            SourceErrorCode.INVALID_PATH,
            pointer,
            f"{field_name} must be a literal relative POSIX path",
        )
    posix = PurePosixPath(path_source)
    windows = PureWindowsPath(path_source)
    if posix.is_absolute() or windows.is_absolute() or windows.drive:
        _raise(
            SourceErrorCode.INVALID_PATH,
            pointer,
            f"{field_name} must be relative",
        )
    if ".." in posix.parts:
        _raise(
            SourceErrorCode.INVALID_PATH,
            pointer,
            f"{field_name} must not traverse outside the source root",
        )
    if path_source in {".", ""} or posix.as_posix() != path_source:
        _raise(
            SourceErrorCode.INVALID_PATH,
            pointer,
            f"{field_name} must be a normalized relative POSIX path",
        )
    return path_source


def _parse_artifacts(value: object, pointer: str) -> FrozenArtifactPathsSource:
    obj = _object(value, pointer)
    _check_keys(obj, pointer, required=("mesh",), optional=("sha256",))
    digest = obj.get("sha256")
    if digest is not None and (type(digest) is not str or not re.fullmatch(r"[0-9a-f]{64}", digest)):
        _raise(SourceErrorCode.INVALID_SCALAR, _pointer(pointer, "sha256"),
               "网格 SHA-256 必须是 64 位小写十六进制字符串")
    return FrozenArtifactPathsSource(
        _source_path(
            obj["mesh"],
            _pointer(pointer, "mesh"),
            field_name="mesh path",
        ),
        digest,
    )


def _rotation_matrix(
    value: object,
    pointer: str,
) -> tuple[
    tuple[float, float, float],
    tuple[float, float, float],
    tuple[float, float, float],
]:
    raw_rows = _array(value, pointer)
    if len(raw_rows) != 3:
        _raise(
            SourceErrorCode.INVALID_SHAPE,
            pointer,
            "rotation_matrix must contain exactly three rows",
        )
    rows: list[tuple[float, float, float]] = []
    for row_index, raw_row in enumerate(raw_rows):
        row_pointer = _pointer(pointer, row_index)
        raw_values = _array(raw_row, row_pointer)
        if len(raw_values) != 3:
            _raise(
                SourceErrorCode.INVALID_SHAPE,
                row_pointer,
                "rotation_matrix rows must contain exactly three numbers",
            )
        row = tuple(
            _finite_number(
                item,
                _pointer(row_pointer, column_index),
                field_name="rotation matrix entry",
            )
            for column_index, item in enumerate(raw_values)
        )
        rows.append(row)  # type: ignore[arg-type]

    tolerance = 1.0e-9
    for first in range(3):
        for second in range(3):
            dot = sum(rows[first][index] * rows[second][index] for index in range(3))
            expected = 1.0 if first == second else 0.0
            if not math.isclose(dot, expected, rel_tol=0.0, abs_tol=tolerance):
                _raise(
                    SourceErrorCode.INVALID_ROTATION_MATRIX,
                    pointer,
                    "rotation_matrix must be orthonormal",
                )
    determinant = (
        rows[0][0] * (rows[1][1] * rows[2][2] - rows[1][2] * rows[2][1])
        - rows[0][1] * (rows[1][0] * rows[2][2] - rows[1][2] * rows[2][0])
        + rows[0][2] * (rows[1][0] * rows[2][1] - rows[1][1] * rows[2][0])
    )
    if not math.isclose(abs(determinant), 1.0, rel_tol=0.0, abs_tol=tolerance):
        _raise(
            SourceErrorCode.INVALID_ROTATION_MATRIX,
            pointer,
            "rotation_matrix determinant must be +1 or -1 (mirror)",
        )
    return tuple(rows)  # type: ignore[return-value]


def _parse_frozen_placement(
    value: object,
    pointer: str,
) -> FrozenRigidPlacementSource:
    obj = _object(value, pointer)
    _check_keys(obj, pointer, required=("translation", "rotation_matrix"), optional=("rotation", "mirrors"))
    result = FrozenRigidPlacementSource(
        _length_vector(
            obj["translation"],
            _pointer(pointer, "translation"),
            field_name="placement translation",
        ),
        _rotation_matrix(
            obj["rotation_matrix"],
            _pointer(pointer, "rotation_matrix"),
        ),
    )
    from .package_v2_instance_transform import frozen_placement_controls
    try:
        frozen_placement_controls(obj)
    except ValueError as error:
        _raise(SourceErrorCode.INVALID_ROTATION_MATRIX, pointer, str(error))
    return result


def _parse_frozen_source(value: object, pointer: str) -> FrozenSourceDeclaration:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=("id", "artifacts", "components", "placement"),
    )
    identifier = _identifier(
        obj["id"],
        _pointer(pointer, "id"),
        field_name="frozen source id",
    )
    component_items = _array(obj["components"], _pointer(pointer, "components"))
    if not component_items:
        _raise(
            SourceErrorCode.INVALID_SHAPE,
            _pointer(pointer, "components"),
            "a frozen source must declare at least one component",
        )
    components: list[str] = []
    seen: set[str] = set()
    for index, item in enumerate(component_items):
        item_pointer = _pointer(_pointer(pointer, "components"), index)
        # These are exact external Physical Volume names, not authored IDs.
        component_id = _string(item, item_pointer, field_name="frozen mesh group name")
        if error := mesh_group_name_error(component_id):
            _raise(SourceErrorCode.INVALID_ID, item_pointer, error)
        if component_id in seen:
            _raise(
                SourceErrorCode.DUPLICATE_ID,
                item_pointer,
                f"duplicate frozen component id {component_id!r}",
            )
        seen.add(component_id)
        components.append(component_id)
    return FrozenSourceDeclaration(
        identifier,
        _parse_artifacts(obj["artifacts"], _pointer(pointer, "artifacts")),
        tuple(components),
        _parse_frozen_placement(
            obj["placement"],
            _pointer(pointer, "placement"),
        ),
    )


def _parse_package(value: object, pointer: str) -> PackageMetadataSource:
    obj = _object(value, pointer)
    _check_keys(obj, pointer, required=("id", "family"))
    identifier = _identifier(
        obj["id"],
        _pointer(pointer, "id"),
        field_name="package id",
    )
    family_token = _string(
        obj["family"],
        _pointer(pointer, "family"),
        field_name="package family",
    )
    try:
        family = PackageFamily(family_token)
    except ValueError:
        _raise(
            SourceErrorCode.INVALID_ENUM,
            _pointer(pointer, "family"),
            "family must be fcbga, fccsp, or custom",
        )
    return PackageMetadataSource(identifier, family)


def _parse_mesh_settings(value: object, pointer: str) -> PackageMeshSettingsSource:
    obj = _object(value, pointer)
    _check_keys(
        obj,
        pointer,
        required=("interface_geometry_tolerance",),
        optional=("parallel_tet_candidates",),
    )
    tolerance_pointer = _pointer(pointer, "interface_geometry_tolerance")
    source = _string(
        obj["interface_geometry_tolerance"],
        tolerance_pointer,
        field_name="interface_geometry_tolerance",
    ).strip()
    try:
        parse_interface_geometry_tolerance_literal_mm(source)
    except (OverflowError, TypeError, ValueError) as error:
        _raise(
            (
                SourceErrorCode.INVALID_UNIT
                if "must be one positive absolute length literal" in str(error)
                else SourceErrorCode.INVALID_RANGE
            ),
            tolerance_pointer,
            str(error),
        )
    parallel = obj.get("parallel_tet_candidates", False)
    if type(parallel) is not bool:
        _raise(SourceErrorCode.WRONG_TYPE, _pointer(pointer, "parallel_tet_candidates"),
               "parallel_tet_candidates must be boolean")
    return PackageMeshSettingsSource(source, parallel)


def _parse_document(value: object) -> PackageV2SourceDocument:
    root = _object(value, "")
    for key in ("schema", "schema_revision"):
        if key not in root:
            _raise(SourceErrorCode.MISSING_KEY, "/" + key, f"missing required key {key!r}")
    if _string(root["schema"], "/schema", field_name="schema") != SOURCE_SCHEMA:
        _raise(SourceErrorCode.UNKNOWN_SCHEMA, "/schema", f"schema must be {SOURCE_SCHEMA!r}")
    revision = root["schema_revision"]
    if type(revision) is not int:
        _raise(SourceErrorCode.WRONG_TYPE, "/schema_revision", "schema_revision must be an integer")
    if revision != SOURCE_SCHEMA_REVISION:
        _raise(SourceErrorCode.UNKNOWN_REVISION, "/schema_revision",
               f"only current Source revision {SOURCE_SCHEMA_REVISION} is supported; got {revision!r}")
    _check_keys(root, "", required=("schema", "schema_revision", "package", "globals", "templates",
                                   "instances", "frozen_sources", "mesh_settings"))
    package = _parse_package(root["package"], "/package")
    settings = _parse_mesh_settings(root["mesh_settings"], "/mesh_settings")
    frozen_sources = []
    frozen_ids = set()
    for index, value in enumerate(_array(root["frozen_sources"], "/frozen_sources")):
        source = _parse_frozen_source(value, f"/frozen_sources/{index}")
        if source.identifier in frozen_ids:
            _raise(SourceErrorCode.DUPLICATE_ID, f"/frozen_sources/{index}/id", "duplicate Frozen Source id")
        frozen_ids.add(source.identifier)
        frozen_sources.append(source)
    from .package_v2_local_templates import expand_document
    try:
        components = expand_document(root)
        templates, instances = [], []
        for index, component in enumerate(components):
            name, records = component["id"], []
            for leaf_index, (geometry, placement) in enumerate(component["solids"]):
                pointer = f"/instances/{index}/solids/{leaf_index}"
                source = _parse_geometry(geometry, pointer)
                records.append(GeometryRecordSource(
                    GeometryRecordOperation.START_COMPONENT if leaf_index == 0 else GeometryRecordOperation.APPEND_GEOMETRY,
                    source, name if leaf_index == 0 else None,
                    _material_name(component["material"], f"/instances/{index}/material") if leaf_index == 0 else None,
                    _parse_component_mesh_control(component["mesh_control"], f"/instances/{index}/mesh_control") if leaf_index == 0 else None,
                    local_placement=_parse_generated_instance_placement(placement, pointer + "/placement")))
            templates.append(TemplateSource(name, tuple(records)))
            instances.append(TemplateInstanceSource(name, name))
        return PackageV2SourceDocument(SOURCE_SCHEMA, SOURCE_SCHEMA_REVISION, package,
            tuple(templates), tuple(instances), tuple(frozen_sources), settings)
    except PackageV2SourceError:
        raise
    except (ValueError, KeyError, TypeError, OverflowError) as error:
        raise PackageV2SourceError(SourceErrorCode.INVALID_GEOMETRY_RECORD, "/templates", str(error)) from error


def parse_package_v2_json(
    data: bytes,
    *,
    source_name: str = "<memory>",
) -> ParsedPackageV2Source:
    """Parse exact UTF-8 JSON bytes into an immutable revisioned source DTO.

    ``source_name`` is accepted for caller bookkeeping and future diagnostics;
    it does not affect source identity.  The parser performs no file-system
    reads and never compiles assembly policy objects. Local v8 templates are
    independently dimension-checked and lowered to numerical geometry here.
    """

    if not isinstance(data, bytes):
        _raise(
            SourceErrorCode.WRONG_INPUT_TYPE,
            "",
            "Package V2 source input must be bytes",
        )
    if len(data) > MAX_SOURCE_BYTES:
        _raise(
            SourceErrorCode.SOURCE_TOO_LARGE,
            "",
            f"source exceeds the {MAX_SOURCE_BYTES}-byte limit",
        )
    if not isinstance(source_name, str) or not source_name:
        _raise(
            SourceErrorCode.WRONG_INPUT_TYPE,
            "",
            "source_name must be a non-empty string",
        )
    if data.startswith(b"\xef\xbb\xbf"):
        _raise(
            SourceErrorCode.UTF8_BOM,
            "",
            "UTF-8 BOM is not allowed",
        )
    try:
        text = data.decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        _raise(
            SourceErrorCode.INVALID_UTF8,
            "",
            f"source is not valid UTF-8 at byte offset {error.start}",
        )
    try:
        raw_value = json.loads(text, object_pairs_hook=_pairs_hook)
    except RecursionError:
        _raise(
            SourceErrorCode.NESTING_TOO_DEEP,
            "",
            f"JSON nesting exceeds the limit of {MAX_JSON_NESTING}",
        )
    except json.JSONDecodeError as error:
        _raise(
            SourceErrorCode.INVALID_JSON,
            "",
            error.msg,
            line=error.lineno,
            column=error.colno,
        )
    materialized = _materialize_json(raw_value)
    document = _parse_document(materialized)
    return ParsedPackageV2Source(
        source_name=source_name,
        raw_bytes=bytes(data),
        raw_text=text,
        raw_sha256=hashlib.sha256(data).hexdigest(),
        document=document,
    )


__all__ = [
    "AUTHORING_MESH_STRATEGY_TOKENS",
    "BoxGeometrySource",
    "UnionGeometrySource",
    "DifferenceGeometrySource",
    "ConformalHybridMeshStrategySource",
    "DerivedVariableSource",
    "FrozenArtifactPathsSource",
    "FrozenRigidPlacementSource",
    "FrozenSourceDeclaration",
    "GeneratedComponentMeshControlSource",
    "GeneratedComponentMeshStrategySource",
    "GeneratedComponentVolumeTopology",
    "GeneratedInstancePlacementSource",
    "GeometryRecordOperation",
    "GeometryRecordSource",
    "MAX_JSON_NESTING",
    "MAX_SOURCE_BYTES",
    "PackageFamily",
    "PackageMetadataSource",
    "PackageMeshSettingsSource",
    "PackageV2SourceDocument",
    "PackageV2SourceError",
    "ParsedPackageV2Source",
    "OrthogonalHexMeshStrategySource",
    "RectangularFrameGeometrySource",
    "RectangularUnderfillFilletGeometrySource",
    "RigidPlacementSource",
    "SOURCE_SCHEMA",
    "SOURCE_SCHEMA_REVISION",
    "SourceErrorCode",
    "SourceRange",
    "SourceScalar",
    "StructuredSweepMeshStrategySource",
    "TemplateInstanceSource",
    "TemplateParameterSource",
    "TemplateSource",
    "parse_package_v2_json",
]
