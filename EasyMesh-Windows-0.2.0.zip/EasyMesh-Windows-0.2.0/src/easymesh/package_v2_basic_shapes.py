"""Coordinate-based basic shapes in one template-local frame."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import math
from typing import Callable, Mapping


BOUND_NAMES = ("xmin", "xmax", "ymin", "ymax", "zmin", "zmax")
XY_BOUND_NAMES = BOUND_NAMES[:4]
SHAPE_LABELS = {}
BASIC_SHAPES = {}


@dataclass(frozen=True)
class BasicShapeDefinition:
    kind: str
    label: str
    defaults: dict
    coordinate_axes: Mapping[tuple, str]
    lower: Callable


def register_basic_shape(definition):
    """A shape must locate itself along X, Y and Z; field names are unrestricted."""
    if set(definition.coordinate_axes.values()) != set("xyz"):
        raise ValueError("基本图形必须明确提供局部 X、Y、Z 坐标")
    for path in definition.coordinate_axes:
        value = definition.defaults
        for key in path:
            value = value[key]
    if definition.kind in BASIC_SHAPES:
        raise ValueError(f"基本图形类型重复：{definition.kind}")
    BASIC_SHAPES[definition.kind] = definition
    SHAPE_LABELS[definition.kind] = definition.label


def new_basic_shape(kind, identifier):
    if kind not in BASIC_SHAPES:
        raise ValueError(f"未知基本图形 {kind!r}")
    return {"id": identifier, "kind": kind, **deepcopy(BASIC_SHAPES[kind].defaults)}


def _bounds_defaults(kind):
    result = {"bounds": {
        name: "0mm" if name.endswith("min") else "1mm" for name in BOUND_NAMES}}
    if kind in {"bounds_ring", "bounds_fillet"}:
        result["bounds"].update(xmin="-1mm", xmax="1mm", ymin="-1mm", ymax="1mm")
        result["inner_bounds"] = {name: "-0.5mm" if name.endswith("min") else "0.5mm" for name in XY_BOUND_NAMES}
    if kind == "bounds_fillet":
        result["bounds"]["zmax"] = "0.5mm"
        result["top_widths"] = {name: "0mm" for name in XY_BOUND_NAMES}
    return result


def numeric_basic_shape(shape, evaluate):
    definition = BASIC_SHAPES[shape["kind"]]
    for path in definition.coordinate_axes:
        value = shape
        for key in path:
            value = value[key]
        evaluate(value)
    return definition.lower(shape, evaluate)


def _numeric_bounds_shape(shape, evaluate):
    """Validate coordinates and lower to the numerical geometry compiler."""
    from .package_v2_local_templates import _keys, literal
    kind = shape["kind"]
    fields = ("id", "kind", "bounds")
    if kind in {"bounds_ring", "bounds_fillet"}:
        fields += ("inner_bounds",)
    if kind == "bounds_fillet":
        fields += ("top_widths",)
    _keys(shape, fields, where=SHAPE_LABELS[kind])
    _keys(shape["bounds"], BOUND_NAMES, where="外框坐标" if kind != "bounds_box" else "坐标")
    outer = {key: evaluate(value) for key, value in shape["bounds"].items()}
    for axis in "xyz":
        if outer[axis + "max"] <= outer[axis + "min"]:
            raise ValueError(f"{SHAPE_LABELS[kind]}: {axis}max 必须大于 {axis}min")
    origin = [literal(outer[axis + "min"]) for axis in "xyz"]
    size = [literal(outer[axis + "max"] - outer[axis + "min"]) for axis in "xyz"]
    if kind == "bounds_box":
        return {"id": shape["id"], "kind": "box", "origin": origin, "size": size}
    _keys(shape["inner_bounds"], XY_BOUND_NAMES, where="内框坐标")
    inner = {key: evaluate(value) for key, value in shape["inner_bounds"].items()}
    for axis in "xy":
        if inner[axis + "max"] <= inner[axis + "min"]:
            raise ValueError(f"{SHAPE_LABELS[kind]}: 内框 {axis}max 必须大于 {axis}min")
        # Ring containment is audited by the numerical frame compiler, which
        # classifies cross-field edits as transient and checks all hard limits.
        if kind == "bounds_fillet" and not outer[axis + "min"] < inner[axis + "min"] < inner[axis + "max"] < outer[axis + "max"]:
            raise ValueError(f"fillet: {axis} 方向内框必须严格位于外框内")
    if kind == "bounds_ring":
        return {"id": shape["id"], "kind": "rectangular_frame_extrusion", "outer_origin": origin,
                "outer_size": size[:2], "height": size[2],
                "opening_offset": [literal(inner[a + "min"] - outer[a + "min"]) for a in "xy"],
                "opening_size": [literal(inner[a + "max"] - inner[a + "min"]) for a in "xy"]}
    _keys(shape["top_widths"], XY_BOUND_NAMES, where="fillet 顶部四侧宽度")
    tops = [evaluate(shape["top_widths"][key]) for key in XY_BOUND_NAMES]
    for key, value in zip(XY_BOUND_NAMES, tops):
        if value < 0:
            raise ValueError(f"fillet: 顶部 {key} 宽度必须 ≥ 0")
    top = max(tops)
    widths = [inner[key] - outer[key] if key.endswith("min") else outer[key] - inner[key] for key in XY_BOUND_NAMES]
    result = {"id": shape["id"], "kind": "rectangular_underfill_fillet",
              "die_origin": [literal(inner[a + "min"]) for a in "xy"],
              "die_size": [literal(inner[a + "max"] - inner[a + "min"]) for a in "xy"],
              "base_z": origin[2], "wall_height": size[2], "toe_width": literal(max(widths)), "top_width": literal(top)}
    if not all(math.isclose(width, widths[0], rel_tol=1e-12, abs_tol=1e-14) for width in widths) or top >= widths[0]:
        result["side_widths"] = [literal(width) for width in widths]
    if not all(math.isclose(width, tops[0], rel_tol=1e-12, abs_tol=1e-14) for width in tops):
        result["top_widths"] = [literal(width) for width in tops]
    return result


for _kind, _label in (("bounds_box", "solid"), ("bounds_fillet", "fillet"), ("bounds_ring", "ring")):
    _coordinates = {("bounds", name): name[0] for name in BOUND_NAMES}
    if _kind != "bounds_box":
        _coordinates.update({("inner_bounds", name): name[0] for name in XY_BOUND_NAMES})
    register_basic_shape(BasicShapeDefinition(_kind, _label, _bounds_defaults(_kind), _coordinates, _numeric_bounds_shape))
