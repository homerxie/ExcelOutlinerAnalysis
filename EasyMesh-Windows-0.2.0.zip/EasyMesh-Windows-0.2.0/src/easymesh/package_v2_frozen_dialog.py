"""Add/edit Frozen mesh instances with absolute, persistent placement controls."""
from copy import deepcopy
from pathlib import Path

from PySide6.QtCore import QSignalBlocker, Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget,
)

from .package_v2_expression_edit import ExpressionEdit, variable_name_edit
from .package_v2_instance_transform import IDENTITY, discrete_matrix, frozen_placement_controls
from .package_v2_instances import transform_values
from .package_v2_mesh_group_selector import MeshGroupSelector
from .package_v2_mesh_fingerprint import MeshFingerprintWidget


class MeshPlacementWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        help_label = QLabel("网格原点在全局坐标中的位置。先关于网格局部原点镜像，"
                            "再绕局部 X → Y → Z 旋转，最后放到指定位置；正角度遵循右手规则。")
        help_label.setWordWrap(True)
        root.addWidget(help_label)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        root.addLayout(form)
        self.translation_edits, self.rotation_combos, self.mirror_checks = [], [], []
        self._preserved_placement = None
        for axis, plane in zip("XYZ", ("YZ", "XZ", "XY")):
            edit = ExpressionEdit(self, ("mm", "um"))
            edit.setText("0mm")
            edit.setToolTip(f"网格局部原点在全局 {axis} 轴上的坐标；支持 mm、um 和常量公式。")
            self.translation_edits.append(edit)
            form.addRow(f"位置 {axis}", edit)
            row = QHBoxLayout()
            combo = QComboBox()
            for angle in (0, 90, 180, 270):
                combo.addItem(f"{angle}°", angle)
            self.rotation_combos.append(combo)
            row.addWidget(combo, 1)
            check = QCheckBox(f"镜像 {axis}")
            check.setToolTip(f"关于网格局部 {plane} 平面镜像，即局部 {axis} 坐标取反。")
            self.mirror_checks.append(check)
            row.addWidget(check)
            form.addRow(f"绕 {axis} 旋转", row)
        self.custom_label = QLabel()
        self.custom_label.setWordWrap(True)
        root.addWidget(self.custom_label)
        self.replace_orientation_button = QPushButton("改用直角旋转 / 镜像设置")
        self.replace_orientation_button.clicked.connect(self._replace_orientation)
        root.addWidget(self.replace_orientation_button)
        self.load_placement({"translation": ["0mm"] * 3, "rotation_matrix": IDENTITY})

    def _controls(self):
        return (tuple(combo.currentData() for combo in self.rotation_combos),
                tuple(check.isChecked() for check in self.mirror_checks))

    def load_placement(self, placement):
        controls = frozen_placement_controls(placement)
        self._preserved_placement = deepcopy(placement)
        self._preserved_placement["rotation_matrix"] = [list(row) for row in placement["rotation_matrix"]]
        self._original_controls = controls
        for edit, value in zip(self.translation_edits, placement["translation"]):
            edit.setText(str(value))
        for index, (combo, check) in enumerate(zip(self.rotation_combos, self.mirror_checks)):
            combo.clear()
            if controls is None:
                combo.addItem("保留当前自定义姿态", None)
            else:
                for angle in (0, 90, 180, 270):
                    combo.addItem(f"{angle}°", angle)
                combo.setCurrentIndex(combo.findData(controls[0][index]))
            check.setChecked(controls[1][index] if controls is not None else False)
            combo.setEnabled(controls is not None)
            check.setEnabled(controls is not None)
        self.custom_label.setVisible(controls is None)
        self.replace_orientation_button.setVisible(controls is None)
        if controls is None:
            matrix = placement["rotation_matrix"]
            self.custom_label.setText("当前姿态含非直角变换，将原样保留，可直接修改位置。当前矩阵：\n" +
                                      "\n".join("  ".join(f"{v:.6g}" for v in row) for row in matrix))

    def _replace_orientation(self):
        self.load_placement({"translation": [edit.text() for edit in self.translation_edits],
                             "rotation_matrix": [list(row) for row in IDENTITY]})

    def placement(self):
        translations = [edit.text().strip() for edit in self.translation_edits]
        rotations, mirrors = self._controls()
        # Validate coordinates before submission, including units/formulas.
        transform_values(translations, (0, 0, 0), (False, False, False), ("0mm",) * 3)
        if self._original_controls is None:
            result = deepcopy(self._preserved_placement)
        else:
            # Opening/saving or editing position alone must not change the
            # existing matrix, including any accepted floating-point precision.
            if (rotations, mirrors) == self._original_controls:
                result = deepcopy(self._preserved_placement)
            else:
                result = {"rotation_matrix": [list(row) for row in discrete_matrix(rotations, mirrors)]}
                result["rotation"], result["mirrors"] = list(rotations), list(mirrors)
        result["translation"] = translations
        return result


class FrozenMeshInstanceDialog(QDialog):
    submitRequested = Signal(object)

    def __init__(self, parent, editor, *, source_id=None):
        super().__init__(parent)
        self.source_editor = editor
        self.opened_raw_sha256 = editor.raw_sha256
        self.frozen_source_id = source_id
        self._sources = {source["id"]: source for source in editor.document["frozen_sources"]}
        self._original = deepcopy(self._sources[source_id]) if source_id is not None else None
        self.setWindowTitle("编辑网格实例" if source_id is not None else "添加网格实例")
        self.resize(780, 700)
        layout = QVBoxLayout(self)
        help_label = QLabel("选择 .msh 网格文件；文件路径相对于 Source 目录。"
                            "位置、旋转和镜像表示此实例的当前摆放，保存时整体替换。")
        help_label.setWordWrap(True)
        layout.addWidget(help_label)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        layout.addLayout(form)
        self.reuse_combo = QComboBox(self)
        self.reuse_combo.addItem("选择网格文件", None)
        for name in self._sources:
            self.reuse_combo.addItem(f"复用网格实例：{name}", name)
        if source_id is None:
            form.addRow("网格来源", self.reuse_combo)
        else:
            self.reuse_combo.hide()
        self.source_id_edit = variable_name_edit(self)
        self.source_id_edit.setText(self._unique_name())
        form.addRow("实例名称", self.source_id_edit)
        self.artifact_edits = {}
        for key, label in (("mesh", "网格 (.msh)"),):
            row = QHBoxLayout()
            edit = QLineEdit()
            edit.setPlaceholderText("相对于 Source 目录的文件路径")
            self.artifact_edits[key] = edit
            row.addWidget(edit, 1)
            button = QPushButton("浏览…")
            button.clicked.connect(lambda _checked=False, key=key: self._choose_artifact(key))
            row.addWidget(button)
            form.addRow(label, row)
        self.group_selector = MeshGroupSelector(self)
        form.addRow("网格内体分组", self.group_selector)
        self.fingerprint_widget = MeshFingerprintWidget(self)
        self.fingerprint_widget.updateRequested.connect(self.group_selector.reload)
        form.addRow("文件检查", self.fingerprint_widget)
        self.artifact_edits["mesh"].textChanged.connect(self._mesh_path_changed)
        self.finished.connect(self.group_selector.cancel)
        self.finished.connect(self.fingerprint_widget.cancel)
        self.transform = MeshPlacementWidget(self)
        self.translation_edits = self.transform.translation_edits
        layout.addWidget(self.transform)
        self.error_label = QLabel()
        self.error_label.setWordWrap(True)
        self.error_label.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.error_label)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setText("保存修改" if source_id is not None else "添加实例")
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("取消")
        self.buttons.accepted.connect(self._submit)
        self.buttons.rejected.connect(self.reject)
        for edit in self.translation_edits:
            edit.returnPressed.connect(self._submit)
        layout.addWidget(self.buttons)
        self.reuse_combo.currentIndexChanged.connect(self._reuse_source)
        if self._original is not None:
            self._load_source(self._original)

    def _unique_name(self, base="frozen"):
        existing = set(self._sources) | {source["id"] for source in self.source_editor.document["instances"]}
        index = 1
        while f"{base}_{index}" in existing:
            index += 1
        return f"{base}_{index}"

    def _load_source(self, source):
        self.source_id_edit.setText(source["id"])
        for key, edit in self.artifact_edits.items():
            with QSignalBlocker(edit):
                edit.setText(source["artifacts"][key])
        self._set_group_mesh(preferred=source["components"], immediate=True)
        self.transform.load_placement(source["placement"])

    def _set_group_mesh(self, *, preferred=(), immediate=False):
        text = self.artifact_edits["mesh"].text().strip()
        root = self.source_editor.path.parent.resolve()
        path = (root / text).resolve() if text else None
        if path is not None and not path.is_relative_to(root):
            path = None
        reference = self._original or self._sources.get(self.reuse_combo.currentData())
        unchanged = bool(reference and text == reference["artifacts"]["mesh"])
        self.group_selector.set_mesh(path, preferred=preferred,
                                     preserve_unread=unchanged, immediate=immediate)
        self.fingerprint_widget.set_mesh(path,
            sha256=reference["artifacts"].get("sha256") if unchanged else None,
            immediate=immediate)

    def _mesh_path_changed(self):
        self._set_group_mesh()

    def _reuse_source(self):
        name = self.reuse_combo.currentData()
        if name is None:
            self._load_source({"id": self._unique_name(), "artifacts": dict.fromkeys(self.artifact_edits, ""),
                               "components": [],
                               "placement": {"translation": ["0mm"] * 3, "rotation_matrix": IDENTITY}})
        else:
            self._load_source(self._sources[name])
            self.source_id_edit.setText(self._unique_name(f"{name}_copy"))

    def _relative_artifact_path(self, text):
        root = self.source_editor.path.parent.resolve()
        path = (root / Path(text.strip())).resolve()
        try:
            relative = path.relative_to(root).as_posix()
        except ValueError:
            raise ValueError("文件必须位于 Source 所在目录或其子目录。请打开位于网格目录或其上级目录的 Source。")
        if not path.is_file():
            raise ValueError(f"文件不存在：{path}")
        return relative

    def _choose_artifact(self, key):
        selected, _ = QFileDialog.getOpenFileName(
            self, f"选择网格实例 {key}", str(self.source_editor.path.parent),
            "Gmsh mesh (*.msh)",
        )
        if not selected:
            return
        try:
            relative = self._relative_artifact_path(selected)
        except ValueError as error:
            self.show_compilation_error(error)
            return
        self.artifact_edits[key].setText(relative)
        if key == "mesh":
            self.group_selector.reload()
        self.error_label.clear()

    def show_compilation_error(self, error):
        self.error_label.setText(str(error))
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(True)

    def _submit(self):
        try:
            reference = self._original or self._sources.get(self.reuse_combo.currentData())
            artifacts = {}
            for key, edit in self.artifact_edits.items():
                # Existing immutable references can remain offline while users
                # edit placement; a changed/new file must exist on disk.
                text = edit.text().strip()
                artifacts[key] = text if reference and text == reference["artifacts"][key] else self._relative_artifact_path(text)
            offline = bool(self._original and artifacts["mesh"] == self._original["artifacts"]["mesh"]
                           and not (self.source_editor.path.parent / artifacts["mesh"]).exists())
            digest = self.fingerprint_widget.selected_sha256(allow_offline=offline)
            if digest is not None:
                artifacts["sha256"] = digest
            source = {"id": self.source_id_edit.text(), "artifacts": artifacts,
                      "components": self.group_selector.selected_components(),
                      "placement": self.transform.placement()}
            if self._original is None and "rotation" not in source["placement"]:
                controls = frozen_placement_controls(source["placement"])
                if controls is not None:
                    source["placement"]["rotation"], source["placement"]["mirrors"] = map(list, controls)
        except ValueError as error:
            self.show_compilation_error(error)
            return
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
        self.submitRequested.emit(source)
