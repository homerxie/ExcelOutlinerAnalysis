"""Deterministic, Gmsh-free planning for multiple frozen Package V2 sources.

This module is deliberately a narrow Phase-3 slice.  It does not create a
target volume, write an MSH file, or infer topology from a distance tolerance.
It instead proves that immutable frozen-source evidence can be combined into
one collision-free tag namespace before any mutating mesher is entered.

The v1 contract is intentionally strict:

* every input snapshot contains exactly one Component and every volume element
  is copied exactly once;
* placement is applied once, from source-local coordinates to package
  coordinates;
* nodes from different sources are shared only through an explicit
  :class:`DeclaredSharedInterface`; exact undeclared coincidences are errors;
* only explicitly named, explicitly mapped 3D Physical Groups are emitted;
* traces aimed at the same target endpoint are rejected for positive-area
  overlap, duplicate coverage, partial-edge contact, or T-junctions.

The Frozen loader remains the authority for Gmsh ``minDetJac`` on warped
HEX8/WEDGE6/PYRAMID5 mappings.  This pure planner does not reopen artifacts or
replace that isoparametric quality contract with a stricter polyhedral
decomposition.  It independently checks TET4 orientation, for which the
single affine determinant is mathematically equivalent.

The result is an immutable assembly *plan*.  Consuming the plan in Gmsh and
combining it with a generated target are later slices.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
import json
import math
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Sequence

from .package_assembly import AssemblyPolicyError
from .package_v2_frozen import (
    FrozenArtifactIdentity,
    FrozenComponentFingerprint,
    FrozenSourceError,
    FrozenSourceSnapshot,
)
from .package_v2_compile import CanonicalFrozenPlacement
from .package_v2_instance_transform import determinant, placed_connectivity
from .package_v2_trace import (
    FrozenTraceError,
    FrozenTraceToleranceEvidence,
    LockedInterfaceTrace,
    LockedTraceFacet,
    LockedTraceNode,
    LockedTracePatch,
)
from .volume_mesh import (
    ELEMENT_SPECS,
    ElementKind,
    MeshNode,
    PhysicalGroup,
    VolumeElement,
    VolumeMesh,
)


_ARTIFACT_ROLES = frozenset(("mesh",))
_MAXIMUM_NAME_UTF8_BYTES = 4_096
_MAXIMUM_METADATA_TEXT_UTF8_BYTES = 4_096
_HARD_RESOURCE_CEILINGS = {
    "maximum_sources": 256,
    "maximum_nodes": 10_000_000,
    "maximum_elements": 20_000_000,
    "maximum_trace_facets": 2_000_000,
    "maximum_trace_node_memberships": 8_000_000,
    "maximum_shared_node_pairs": 2_000_000,
    "maximum_shared_endpoint_membership_checks": 5_000_000,
    "maximum_trace_facet_pair_checks": 5_000_000,
    "maximum_physical_group_mappings": 1_000_000,
    "maximum_physical_group_memberships": 20_000_000,
    "maximum_metadata_utf8_bytes": 64 * 1024 * 1024,
    "maximum_estimated_output_bytes": 4 * 1024 * 1024 * 1024,
}


class MultiSourceAssemblyError(RuntimeError):
    """Raised when multi-source evidence cannot form an unambiguous plan."""


def _is_positive_int(value: object) -> bool:
    return not isinstance(value, bool) and isinstance(value, int) and value > 0


def _is_canonical_name(value: object) -> bool:
    if not (
        type(value) is str
        and bool(value)
        and value == value.strip()
        and len(value) <= _MAXIMUM_NAME_UTF8_BYTES
        and not any(
            ord(character) < 32
            or 127 <= ord(character) <= 159
            or character == '"'
            for character in value
        )
    ):
        return False
    try:
        return len(value.encode("utf-8")) <= _MAXIMUM_NAME_UTF8_BYTES
    except UnicodeError:
        return False


def _bounded_metadata_text_bytes(value: object, *, field_name: str) -> int:
    if type(value) is not str or not value:
        raise MultiSourceAssemblyError(f"{field_name} must be non-empty text")
    try:
        size = len(value.encode("utf-8"))
    except UnicodeError as error:
        raise MultiSourceAssemblyError(
            f"{field_name} must be valid UTF-8 text"
        ) from error
    if size > _MAXIMUM_METADATA_TEXT_UTF8_BYTES:
        raise MultiSourceAssemblyError(
            f"{field_name} exceeds the UTF-8 byte limit"
        )
    return size


def _canonical_name_bytes(value: object, *, field_name: str) -> int:
    if not _is_canonical_name(value):
        raise MultiSourceAssemblyError(f"{field_name} is not canonical")
    return len(value.encode("utf-8"))


def _is_sha256(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


@dataclass(frozen=True, slots=True)
class MultiSourceLimits:
    """Hard preflight limits for the pure planning pass."""

    maximum_sources: int = 256
    maximum_nodes: int = 10_000_000
    maximum_elements: int = 20_000_000
    maximum_trace_facets: int = 2_000_000
    maximum_trace_node_memberships: int = 8_000_000
    maximum_shared_node_pairs: int = 2_000_000
    maximum_shared_endpoint_membership_checks: int = 5_000_000
    maximum_trace_facet_pair_checks: int = 5_000_000
    maximum_physical_group_mappings: int = 1_000_000
    maximum_physical_group_memberships: int = 20_000_000
    maximum_metadata_utf8_bytes: int = 64 * 1024 * 1024
    maximum_estimated_output_bytes: int = 4 * 1024 * 1024 * 1024

    def __post_init__(self) -> None:
        for field_name in (
            "maximum_sources",
            "maximum_nodes",
            "maximum_elements",
            "maximum_trace_facets",
            "maximum_trace_node_memberships",
            "maximum_shared_node_pairs",
            "maximum_shared_endpoint_membership_checks",
            "maximum_trace_facet_pair_checks",
            "maximum_physical_group_mappings",
            "maximum_physical_group_memberships",
            "maximum_metadata_utf8_bytes",
            "maximum_estimated_output_bytes",
        ):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise MultiSourceAssemblyError(
                    f"{field_name} must be a positive integer"
                )
            if value > _HARD_RESOURCE_CEILINGS[field_name]:
                raise MultiSourceAssemblyError(
                    f"{field_name} exceeds the implementation safety ceiling"
                )


@dataclass(frozen=True, slots=True, order=True)
class ExplicitPhysicalGroupMap:
    """Copy one exact, explicitly named source group to an output group name."""

    source_group_tag: int
    source_group_name: str
    output_group_name: str

    def __post_init__(self) -> None:
        if (
            isinstance(self.source_group_tag, bool)
            or not isinstance(self.source_group_tag, int)
            or self.source_group_tag < 1
        ):
            raise MultiSourceAssemblyError(
                "source Physical Group tag must be a positive integer"
            )
        for field_name in ("source_group_name", "output_group_name"):
            value = getattr(self, field_name)
            if not _is_canonical_name(value):
                raise MultiSourceAssemblyError(
                    f"{field_name} must be a non-empty canonical name"
                )


@dataclass(frozen=True, slots=True)
class DeclaredSharedInterface:
    """Explicit source-to-source node equivalence on a declared interface.

    Pairs are expressed in the source-local node namespaces.  The declaration
    is topology, not a proximity hint: every paired node must occur in a locked
    trace for its source and both placed coordinates must be exactly equal.
    """

    first_source_id: str
    second_source_id: str
    node_pairs: tuple[tuple[int, int], ...]

    def __post_init__(self) -> None:
        for field_name in ("first_source_id", "second_source_id"):
            value = getattr(self, field_name)
            if not _is_canonical_name(value):
                raise MultiSourceAssemblyError(
                    "shared interface source IDs must be canonical names"
                )
        if self.first_source_id == self.second_source_id:
            raise MultiSourceAssemblyError(
                "a shared interface must join two different sources"
            )
        if type(self.node_pairs) is not tuple:
            raise MultiSourceAssemblyError(
                "shared interface node_pairs must be a bounded tuple"
            )
        if not self.node_pairs:
            raise MultiSourceAssemblyError(
                "a shared interface must declare at least one node pair"
            )
        seen_first: set[int] = set()
        seen_second: set[int] = set()
        for pair in self.node_pairs:
            if not isinstance(pair, tuple) or len(pair) != 2:
                raise MultiSourceAssemblyError(
                    "shared interface node pairs must be 2-tuples"
                )
            first, second = pair
            if any(
                isinstance(value, bool)
                or not isinstance(value, int)
                or value < 1
                for value in pair
            ):
                raise MultiSourceAssemblyError(
                    "shared interface node tags must be positive integers"
                )
            if first in seen_first or second in seen_second:
                raise MultiSourceAssemblyError(
                    "one shared interface cannot map a node more than once"
                )
            seen_first.add(first)
            seen_second.add(second)


@dataclass(frozen=True, slots=True)
class MultiSourceInput:
    """One immutable source, its Component identity, traces, and group maps."""

    snapshot: FrozenSourceSnapshot
    component_global_id: str
    traces: tuple[LockedInterfaceTrace, ...]
    physical_group_maps: tuple[ExplicitPhysicalGroupMap, ...]

    def __post_init__(self) -> None:
        if (
            not _is_canonical_name(self.component_global_id)
        ):
            raise MultiSourceAssemblyError(
                "component_global_id must be a non-empty string"
            )
        if (
            type(self.traces) is not tuple
            or type(self.physical_group_maps) is not tuple
        ):
            raise MultiSourceAssemblyError(
                "traces and physical_group_maps must be bounded tuples"
            )
        if not self.traces:
            raise MultiSourceAssemblyError(
                "each multi-source input must contain a locked interface trace"
            )
        if not self.physical_group_maps:
            raise MultiSourceAssemblyError(
                "each multi-source input must explicitly map its Component group"
            )


@dataclass(frozen=True, slots=True)
class AssemblyNode:
    output_tag: int
    package_coordinates_mm: tuple[float, float, float]
    source_nodes: tuple[tuple[str, int], ...]

    def __post_init__(self) -> None:
        if not _is_positive_int(self.output_tag):
            raise MultiSourceAssemblyError(
                "assembly node output_tag must be a positive integer"
            )
        if (
            type(self.package_coordinates_mm) is not tuple
            or len(self.package_coordinates_mm) != 3
            or any(
                type(value) is not float
                or not math.isfinite(value)
                or (value == 0.0 and math.copysign(1.0, value) < 0.0)
                for value in self.package_coordinates_mm
            )
        ):
            raise MultiSourceAssemblyError(
                "assembly node coordinates must be a canonical finite 3-tuple"
            )
        if type(self.source_nodes) is not tuple or not self.source_nodes:
            raise MultiSourceAssemblyError(
                "assembly node provenance must be a non-empty tuple"
            )
        for source_node in self.source_nodes:
            if (
                type(source_node) is not tuple
                or len(source_node) != 2
                or not _is_canonical_name(source_node[0])
                or not _is_positive_int(source_node[1])
            ):
                raise MultiSourceAssemblyError(
                    "assembly node provenance contains an invalid source node"
                )
        if tuple(sorted(set(self.source_nodes))) != self.source_nodes:
            raise MultiSourceAssemblyError(
                "assembly node provenance must be sorted and unique"
            )
        if len({source_id for source_id, _ in self.source_nodes}) != len(
            self.source_nodes
        ):
            raise MultiSourceAssemblyError(
                "one assembly node cannot contain two nodes from one source"
            )


@dataclass(frozen=True, slots=True)
class AssemblyElement:
    output_tag: int
    kind: ElementKind
    gmsh_type: int
    node_tags: tuple[int, ...]
    source_id: str
    source_component_global_id: str
    source_element_tag: int
    source_entity_tag: int
    minimum_jacobian_determinant: float

    def __post_init__(self) -> None:
        if not _is_positive_int(self.output_tag):
            raise MultiSourceAssemblyError(
                "assembly element output_tag must be a positive integer"
            )
        if (
            type(self.kind) is not ElementKind
            or not _is_positive_int(self.gmsh_type)
            or self.gmsh_type not in ELEMENT_SPECS
            or ELEMENT_SPECS[self.gmsh_type][0] is not self.kind
            or type(self.node_tags) is not tuple
            or len(self.node_tags) != ELEMENT_SPECS[self.gmsh_type][1]
            or any(not _is_positive_int(tag) for tag in self.node_tags)
            or len(set(self.node_tags)) != len(self.node_tags)
        ):
            raise MultiSourceAssemblyError(
                "assembly element kind/connectivity evidence is invalid"
            )
        if (
            not _is_canonical_name(self.source_id)
            or not _is_canonical_name(self.source_component_global_id)
            or not _is_positive_int(self.source_element_tag)
            or not _is_positive_int(self.source_entity_tag)
        ):
            raise MultiSourceAssemblyError(
                "assembly element source provenance is invalid"
            )
        if (
            type(self.minimum_jacobian_determinant) is not float
            or not math.isfinite(self.minimum_jacobian_determinant)
            or self.minimum_jacobian_determinant <= 0.0
        ):
            raise MultiSourceAssemblyError(
                "assembly element minimum Jacobian evidence is invalid"
            )


@dataclass(frozen=True, slots=True)
class AssemblyPhysicalGroup:
    output_tag: int
    name: str
    element_tags: tuple[int, ...]
    source_groups: tuple[tuple[str, int, str], ...]

    def __post_init__(self) -> None:
        if not _is_positive_int(self.output_tag) or not _is_canonical_name(self.name):
            raise MultiSourceAssemblyError(
                "assembly Physical Group identity is invalid"
            )
        if (
            type(self.element_tags) is not tuple
            or not self.element_tags
            or any(not _is_positive_int(tag) for tag in self.element_tags)
            or tuple(sorted(set(self.element_tags))) != self.element_tags
        ):
            raise MultiSourceAssemblyError(
                "assembly Physical Group membership must be sorted and unique"
            )
        if type(self.source_groups) is not tuple or not self.source_groups:
            raise MultiSourceAssemblyError(
                "assembly Physical Group provenance must be non-empty"
            )
        for source_group in self.source_groups:
            if (
                type(source_group) is not tuple
                or len(source_group) != 3
                or not _is_canonical_name(source_group[0])
                or not _is_positive_int(source_group[1])
                or not _is_canonical_name(source_group[2])
            ):
                raise MultiSourceAssemblyError(
                    "assembly Physical Group provenance contains an invalid group"
                )
        if tuple(sorted(set(self.source_groups))) != self.source_groups:
            raise MultiSourceAssemblyError(
                "assembly Physical Group provenance must be sorted and unique"
            )


@dataclass(frozen=True, slots=True)
class MultiSourceAssemblyPlan:
    """Immutable, deterministic output of the pure multi-source planner.

    ``numbered_sha256`` is a downstream-verifiable content digest over every
    public plan field, including the opaque provenance digest.
    ``provenance_sha256`` additionally binds builder-only source artifacts,
    traces and declarations.  It is intentionally non-portable because the
    Frozen artifact evidence includes runtime paths; a consumer without those
    original inputs can validate content integrity but cannot re-prove that
    provenance boundary.
    """

    nodes: tuple[AssemblyNode, ...]
    elements: tuple[AssemblyElement, ...]
    physical_groups: tuple[AssemblyPhysicalGroup, ...]
    source_node_output_tags: Mapping[str, Mapping[int, int]]
    source_element_output_tags: Mapping[str, Mapping[int, int]]
    source_component_global_ids: Mapping[str, str]
    source_snapshot_numbered_sha256: Mapping[str, str]
    numbered_sha256: str
    provenance_sha256: str

    def __post_init__(self) -> None:
        if (
            type(self.nodes) is not tuple
            or type(self.elements) is not tuple
            or type(self.physical_groups) is not tuple
        ):
            raise MultiSourceAssemblyError(
                "assembly plan records must be bounded tuples"
            )
        for field_name in (
            "source_node_output_tags",
            "source_element_output_tags",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, Mapping):
                raise MultiSourceAssemblyError(
                    f"assembly plan {field_name} must be a mapping"
                )
            try:
                canonical: dict[str, Mapping[int, int]] = {}
                for source_id, tags in sorted(value.items()):
                    if not isinstance(tags, Mapping):
                        raise TypeError("nested source tag map is not a mapping")
                    canonical[source_id] = MappingProxyType(
                        dict(sorted(tags.items()))
                    )
            except (AttributeError, TypeError, ValueError) as error:
                raise MultiSourceAssemblyError(
                    f"assembly plan {field_name} is not a canonical mapping"
                ) from error
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(canonical),
            )
        for field_name in (
            "source_component_global_ids",
            "source_snapshot_numbered_sha256",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, Mapping):
                raise MultiSourceAssemblyError(
                    f"assembly plan {field_name} must be a mapping"
                )
            try:
                canonical_values = dict(sorted(value.items()))
            except (AttributeError, TypeError, ValueError) as error:
                raise MultiSourceAssemblyError(
                    f"assembly plan {field_name} is not a canonical mapping"
                ) from error
            object.__setattr__(
                self, field_name, MappingProxyType(canonical_values)
            )
        _audit_multi_source_assembly_plan(self)


def _canonical_float(value: float) -> float:
    numeric = float(value)
    if not math.isfinite(numeric):
        raise MultiSourceAssemblyError("multi-source evidence contains non-finite data")
    return 0.0 if numeric == 0.0 else numeric


def _canonical_json_bytes(value: object) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (OverflowError, TypeError, ValueError) as error:
        raise MultiSourceAssemblyError(
            "cannot encode canonical multi-source evidence"
        ) from error


def _digest_payload(value: object) -> str:
    return hashlib.sha256(_canonical_json_bytes(value)).hexdigest()


def _update_digest_record(digest: Any, value: object) -> None:
    encoded = _canonical_json_bytes(value)
    digest.update(len(encoded).to_bytes(8, "big"))
    digest.update(encoded)


def _stream_digest(
    *,
    schema: str,
    metadata: object,
    sections: Iterable[tuple[str, int, Iterable[object]]],
) -> str:
    digest = hashlib.sha256()
    _update_digest_record(digest, {"schema": schema, "metadata": metadata})
    for name, expected_count, records in sections:
        _update_digest_record(
            digest, {"section": name, "count": expected_count}
        )
        actual_count = 0
        for record in records:
            _update_digest_record(digest, record)
            actual_count += 1
        if actual_count != expected_count:
            raise MultiSourceAssemblyError(
                f"multi-source digest section {name!r} has inconsistent length"
            )
    return digest.hexdigest()


def _node_payload(tag: int, coordinates: tuple[float, float, float]) -> list[object]:
    return [tag, *(_canonical_float(value) for value in coordinates)]


def _element_payload(element: Any) -> list[object]:
    return [
        element.tag,
        element.kind.value,
        element.gmsh_type,
        list(element.node_tags),
        element.entity_tag,
        [
            [group.tag, group.name, group.explicitly_named]
            for group in element.physical_groups
        ],
    ]


def _component_numbered_sha256(
    snapshot: FrozenSourceSnapshot,
    local_id: str,
    component: FrozenComponentFingerprint,
) -> tuple[str, str, str]:
    node_by_tag = snapshot.mesh.node_map()
    element_by_tag = {element.tag: element for element in snapshot.mesh.elements}
    metadata = {"component": [local_id, component.global_component_id]}
    node_digest = _stream_digest(
        schema="easymesh-package-v2-frozen-component-nodes-numbered-v2",
        metadata=metadata,
        sections=(
            (
                "nodes",
                len(component.node_tags),
                (
                    _node_payload(tag, node_by_tag[tag].coordinates)
                    for tag in component.node_tags
                ),
            ),
        ),
    )
    element_digest = _stream_digest(
        schema="easymesh-package-v2-frozen-component-elements-numbered-v2",
        metadata=metadata,
        sections=(
            (
                "elements",
                len(component.element_tags),
                (
                    _element_payload(element_by_tag[tag])
                    for tag in component.element_tags
                ),
            ),
        ),
    )
    node_count = len(component.node_tags)
    groups = {
        group
        for tag in component.element_tags
        for element in (element_by_tag[tag],)
        for group in element.physical_groups
        if group.tag == component.physical_group_tag and group.name == local_id
    }
    if len(groups) != 1 or not next(iter(groups)).explicitly_named:
        raise MultiSourceAssemblyError(
            "the frozen Component must bind one exact explicitly named 3D group"
        )
    group = next(iter(groups))
    numbered = _digest_payload(
        {
            "schema": "easymesh-package-v2-frozen-component-numbered-v2",
            "local_component_id": local_id,
            "global_component_id": component.global_component_id,
            "physical_group": [group.tag, group.name, group.explicitly_named],
            "node_count": node_count,
            "element_count": len(component.element_tags),
            "element_kind_counts": dict(
                sorted(
                    Counter(
                        element_by_tag[tag].kind.value
                        for tag in component.element_tags
                    ).items()
                )
            ),
            "node_numbered_sha256": node_digest,
            "element_numbered_sha256": element_digest,
        }
    )
    return node_digest, element_digest, numbered


def _snapshot_numbered_sha256(snapshot: FrozenSourceSnapshot) -> str:
    digest = hashlib.sha256()
    metadata = {
        "source_id": snapshot.source_id,
        "placement": {
            "translation_xyz_mm": list(snapshot.placement.translation_xyz_mm),
            "rotation_matrix": [
                list(row) for row in snapshot.placement.rotation_matrix
            ],
        },
        "artifacts": {
            role: {
                "declaration": identity.declaration,
                "runtime_path": identity.runtime_path,
                "size_bytes": identity.size_bytes,
                "sha256": identity.sha256,
            }
            for role, identity in sorted(snapshot.artifacts.items())
        },
        "components": {
            local_id: component.numbered_sha256
            for local_id, component in sorted(snapshot.components.items())
        },
    }
    _update_digest_record(
        digest,
        {
            "schema": "easymesh-package-v2-frozen-source-numbered-v2",
            "metadata": metadata,
        },
    )
    _update_digest_record(
        digest, {"section": "nodes", "count": len(snapshot.mesh.nodes)}
    )
    for node in snapshot.mesh.nodes:
        _update_digest_record(digest, _node_payload(node.tag, node.coordinates))
    _update_digest_record(
        digest, {"section": "elements", "count": len(snapshot.mesh.elements)}
    )
    for element in snapshot.mesh.elements:
        _update_digest_record(digest, _element_payload(element))
    return digest.hexdigest()


def _placed(
    coordinates: tuple[float, float, float], snapshot: FrozenSourceSnapshot
) -> tuple[float, float, float]:
    rotation = snapshot.placement.rotation_matrix
    translation = snapshot.placement.translation_xyz_mm
    return tuple(
        _canonical_float(
            translation[row]
            + math.fsum(
                rotation[row][column] * coordinates[column]
                for column in range(3)
            )
        )
        for row in range(3)
    )  # type: ignore[return-value]


def _audit_trace_evidence(trace: LockedInterfaceTrace) -> None:
    """Re-run every nested trace invariant without trusting frozen DTO fields."""

    if (
        type(trace) is not LockedInterfaceTrace
        or type(trace.tolerance) is not FrozenTraceToleranceEvidence
        or any(type(value) is not LockedTraceNode for value in trace.nodes)
        or any(type(value) is not LockedTraceFacet for value in trace.facets)
        or any(type(value) is not LockedTracePatch for value in trace.patches)
    ):
        raise MultiSourceAssemblyError("locked trace evidence contains an invalid DTO")
    try:
        tolerance = FrozenTraceToleranceEvidence(
            trace.tolerance.profile,
            trace.tolerance.scale_mm,
            trace.tolerance.distance_mm,
            trace.tolerance.roundoff_mm,
            trace.tolerance.relative_area,
            trace.tolerance.normal_dot_tolerance,
        )
        nodes = tuple(
            LockedTraceNode(
                node.source_node_tag,
                node.source_coordinates_mm,
                node.package_coordinates_mm,
            )
            for node in trace.nodes
        )
        facets = tuple(
            LockedTraceFacet(
                facet.source_node_tags,
                facet.owner_element_tag,
                facet.owner_element_kind,
                facet.owner_local_face_index,
                facet.source_component_global_id,
                facet.target_face,
                facet.patch_index,
                facet.package_unit_normal_xyz,
                facet.area_mm2,
            )
            for facet in trace.facets
        )
        patches = tuple(
            LockedTracePatch(
                patch.patch_index,
                patch.facet_indices,
                patch.source_node_tags,
            )
            for patch in trace.patches
        )
        rebuilt = LockedInterfaceTrace(
            trace.source_id,
            trace.source_component_local_id,
            trace.source_component_global_id,
            trace.source_snapshot_numbered_sha256,
            trace.source_component_numbered_sha256,
            trace.target_instance_id,
            trace.target_component_local_id,
            trace.target_component_global_id,
            trace.target_fragment_id,
            trace.target_face,
            nodes,
            facets,
            patches,
            trace.triangle_count,
            trace.quad_count,
            tolerance,
            trace.maximum_plane_deviation_mm,
            trace.maximum_bounds_overshoot_mm,
            trace.source_trace_numbered_sha256,
            trace.package_geometry_sha256,
        )
    except (FrozenTraceError, AttributeError, TypeError, ValueError) as error:
        raise MultiSourceAssemblyError("locked trace evidence is inconsistent") from error
    if rebuilt != trace:
        raise MultiSourceAssemblyError("locked trace evidence is not canonical")


def _audit_volume_element_record(element: VolumeElement) -> None:
    if (
        isinstance(element.tag, bool)
        or not isinstance(element.tag, int)
        or element.tag < 1
        or isinstance(element.entity_tag, bool)
        or not isinstance(element.entity_tag, int)
        or element.entity_tag < 1
        or isinstance(element.gmsh_type, bool)
        or not isinstance(element.gmsh_type, int)
        or element.gmsh_type not in ELEMENT_SPECS
        or ELEMENT_SPECS[element.gmsh_type][0] is not element.kind
        or type(element.node_tags) is not tuple
        or len(element.node_tags) != ELEMENT_SPECS[element.gmsh_type][1]
        or len(set(element.node_tags)) != len(element.node_tags)
        or any(
            isinstance(tag, bool) or not isinstance(tag, int) or tag < 1
            for tag in element.node_tags
        )
        or isinstance(element.min_jacobian_determinant, bool)
        or not isinstance(element.min_jacobian_determinant, (int, float))
        or not math.isfinite(float(element.min_jacobian_determinant))
        or float(element.min_jacobian_determinant) <= 0.0
    ):
        raise MultiSourceAssemblyError(
            "Frozen source contains an invalid volume element"
        )
    if type(element.physical_groups) is not tuple or any(
        type(group) is not PhysicalGroup
        or isinstance(group.tag, bool)
        or not isinstance(group.tag, int)
        or group.tag < 1
        or not isinstance(group.name, str)
        or not group.name
        or group.name != group.name.strip()
        or any(ord(character) < 32 for character in group.name)
        or type(group.explicitly_named) is not bool
        for group in element.physical_groups
    ):
        raise MultiSourceAssemblyError("Frozen element Physical Groups are invalid")
    if tuple(sorted(set(element.physical_groups))) != element.physical_groups:
        raise MultiSourceAssemblyError(
            "Frozen element Physical Groups are not canonical"
        )


def _normalized_tet_orientation(
    points: tuple[
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
    ],
) -> float:
    anchor = points[0]
    vectors = tuple(
        tuple(point[axis] - anchor[axis] for axis in range(3))
        for point in points[1:]
    )
    scale = max(abs(value) for vector in vectors for value in vector)
    if scale == 0.0:
        return 0.0
    first, second, third = tuple(
        tuple(value / scale for value in vector) for vector in vectors
    )
    cross = (
        second[1] * third[2] - second[2] * third[1],
        second[2] * third[0] - second[0] * third[2],
        second[0] * third[1] - second[1] * third[0],
    )
    return math.fsum(first[axis] * cross[axis] for axis in range(3))


def _audit_source(value: MultiSourceInput) -> tuple[str, FrozenComponentFingerprint]:
    if type(value) is not MultiSourceInput:
        raise MultiSourceAssemblyError("sources must contain MultiSourceInput values")
    snapshot = value.snapshot
    if type(snapshot) is not FrozenSourceSnapshot:
        raise MultiSourceAssemblyError("snapshot must be a FrozenSourceSnapshot")
    if type(snapshot.mesh) is not VolumeMesh:
        raise MultiSourceAssemblyError("snapshot.mesh must be a VolumeMesh")
    if not isinstance(snapshot.source_id, str) or not snapshot.source_id:
        raise MultiSourceAssemblyError("frozen source_id must be non-empty")
    if type(snapshot.placement) is not CanonicalFrozenPlacement:
        raise MultiSourceAssemblyError("Frozen placement evidence has an invalid DTO")
    try:
        canonical_placement = CanonicalFrozenPlacement(
            snapshot.placement.translation_xyz_mm,
            snapshot.placement.rotation_matrix,
        )
    except (AssemblyPolicyError, AttributeError, TypeError, ValueError) as error:
        raise MultiSourceAssemblyError("Frozen placement evidence is invalid") from error
    if canonical_placement != snapshot.placement:
        raise MultiSourceAssemblyError("Frozen placement evidence is not canonical")
    if set(snapshot.artifacts) != _ARTIFACT_ROLES:
        raise MultiSourceAssemblyError(
            "Frozen snapshot artifact identities must be a mesh identity"
        )
    for role, identity in snapshot.artifacts.items():
        if type(identity) is not FrozenArtifactIdentity or identity.role != role:
            raise MultiSourceAssemblyError(
                "Frozen snapshot artifact identity is inconsistent"
            )
        try:
            rebuilt_identity = FrozenArtifactIdentity(
                identity.role,
                identity.declaration,
                identity.runtime_path,
                identity.size_bytes,
                identity.sha256,
            )
        except (FrozenSourceError, AttributeError, TypeError, ValueError) as error:
            raise MultiSourceAssemblyError(
                "Frozen snapshot artifact identity is invalid"
            ) from error
        if rebuilt_identity != identity:
            raise MultiSourceAssemblyError(
                "Frozen snapshot artifact identity is not canonical"
            )
    runtime_paths = tuple(
        identity.runtime_path for identity in snapshot.artifacts.values()
    )
    if len(set(runtime_paths)) != len(runtime_paths):
        raise MultiSourceAssemblyError(
            "Frozen artifact runtime identities must be mutually distinct"
        )
    if str(snapshot.mesh.source_path) != snapshot.artifacts["mesh"].runtime_path:
        raise MultiSourceAssemblyError(
            "Frozen mesh runtime identity differs from mesh.source_path"
        )
    if len(snapshot.components) != 1:
        raise MultiSourceAssemblyError(
            "multi-source v1 requires exactly one Component per snapshot"
        )
    local_id, component = next(iter(snapshot.components.items()))
    if (
        type(component) is not FrozenComponentFingerprint
        or component.local_component_id != local_id
        or component.global_component_id != value.component_global_id
    ):
        raise MultiSourceAssemblyError(
            "input global Component identity differs from the snapshot"
        )
    nodes = snapshot.mesh.nodes
    elements = snapshot.mesh.elements
    if any(type(node) is not MeshNode for node in nodes) or any(
        type(element) is not VolumeElement for element in elements
    ):
        raise MultiSourceAssemblyError("Frozen mesh contains an invalid IR record")
    if any(
        isinstance(node.tag, bool)
        or not isinstance(node.tag, int)
        or node.tag < 1
        or any(
            isinstance(coordinate, bool)
            or not isinstance(coordinate, (int, float))
            or not math.isfinite(float(coordinate))
            for coordinate in node.coordinates
        )
        for node in nodes
    ):
        raise MultiSourceAssemblyError("Frozen mesh contains an invalid node")
    for element in elements:
        _audit_volume_element_record(element)
    node_tags = tuple(node.tag for node in nodes)
    element_tags = tuple(element.tag for element in elements)
    if (
        not nodes
        or not elements
        or node_tags != tuple(sorted(set(node_tags)))
        or element_tags != tuple(sorted(set(element_tags)))
        or any(tag < 1 for tag in node_tags)
        or any(tag < 1 for tag in element_tags)
    ):
        raise MultiSourceAssemblyError(
            "Frozen mesh nodes/elements must be non-empty and canonical"
        )
    node_tag_set = set(node_tags)
    if any(
        tag not in node_tag_set
        for element in elements
        for tag in element.node_tags
    ):
        raise MultiSourceAssemblyError("Frozen element references an unknown node")
    if snapshot.node_count != len(nodes) or snapshot.element_count != len(elements):
        raise MultiSourceAssemblyError("Frozen snapshot counts are inconsistent")
    if snapshot.mesh.dimensional_element_counts != (0, 0, 0, len(elements)):
        raise MultiSourceAssemblyError(
            "Frozen source must contain volume elements only"
        )
    expected_kind_counts = dict(
        sorted(Counter(element.kind.value for element in elements).items())
    )
    if dict(snapshot.element_kind_counts) != expected_kind_counts:
        raise MultiSourceAssemblyError("Frozen element kind counts are inconsistent")
    if component.element_tags != element_tags:
        raise MultiSourceAssemblyError(
            "the sole Frozen Component must own every source element exactly once"
        )
    if (
        isinstance(component.physical_group_tag, bool)
        or not isinstance(component.physical_group_tag, int)
        or component.physical_group_tag < 1
        or any(
            not any(
                group.tag == component.physical_group_tag
                and group.name == local_id
                and group.explicitly_named
                for group in element.physical_groups
            )
            for element in elements
        )
    ):
        raise MultiSourceAssemblyError(
            "the Frozen Component group must own every source element"
        )
    expected_component_nodes = tuple(
        sorted({tag for element in elements for tag in element.node_tags})
    )
    if component.node_tags != expected_component_nodes:
        raise MultiSourceAssemblyError("Frozen Component node membership is stale")
    if (
        component.node_count != len(expected_component_nodes)
        or component.element_count != len(elements)
        or dict(component.element_kind_counts) != expected_kind_counts
    ):
        raise MultiSourceAssemblyError("Frozen Component counts are inconsistent")
    try:
        component_digests = _component_numbered_sha256(
            snapshot, local_id, component
        )
    except KeyError as error:
        raise MultiSourceAssemblyError(
            "Frozen Component fingerprint references unknown mesh tags"
        ) from error
    if component_digests != (
        component.node_numbered_sha256,
        component.element_numbered_sha256,
        component.numbered_sha256,
    ):
        raise MultiSourceAssemblyError(
            "Frozen Component numbered evidence is inconsistent"
        )
    if _snapshot_numbered_sha256(snapshot) != snapshot.numbered_sha256:
        raise MultiSourceAssemblyError(
            "Frozen snapshot numbered evidence is inconsistent"
        )

    group_keys: dict[tuple[int, str], PhysicalGroup] = {}
    tags_to_names: dict[int, str] = {}
    minimum_jacobian = math.inf
    for element in elements:
        minimum_jacobian = min(
            minimum_jacobian, element.min_jacobian_determinant
        )
        for group in element.physical_groups:
            previous_name = tags_to_names.setdefault(group.tag, group.name)
            if previous_name != group.name:
                raise MultiSourceAssemblyError(
                    "one source Physical Group tag has inconsistent names"
                )
            previous_group = group_keys.setdefault((group.tag, group.name), group)
            if previous_group != group:
                raise MultiSourceAssemblyError(
                    "one source Physical Group has inconsistent naming evidence"
                )
    if (
        isinstance(snapshot.mesh.min_jacobian_determinant, bool)
        or not isinstance(snapshot.mesh.min_jacobian_determinant, (int, float))
        or not math.isfinite(float(snapshot.mesh.min_jacobian_determinant))
        or float(snapshot.mesh.min_jacobian_determinant) <= 0.0
        or snapshot.mesh.min_jacobian_determinant != minimum_jacobian
    ):
        raise MultiSourceAssemblyError(
            "Frozen mesh minimum Jacobian evidence is inconsistent"
        )

    mappings: dict[tuple[int, str], ExplicitPhysicalGroupMap] = {}
    for mapping in value.physical_group_maps:
        if type(mapping) is not ExplicitPhysicalGroupMap:
            raise MultiSourceAssemblyError(
                "physical_group_maps contains an invalid value"
            )
        if ExplicitPhysicalGroupMap(
            mapping.source_group_tag,
            mapping.source_group_name,
            mapping.output_group_name,
        ) != mapping:
            raise MultiSourceAssemblyError(
                "physical_group_maps contains non-canonical evidence"
            )
        key = (mapping.source_group_tag, mapping.source_group_name)
        if key in mappings:
            raise MultiSourceAssemblyError(
                "a source Physical Group may be mapped only once"
            )
        group = group_keys.get(key)
        if group is None:
            raise MultiSourceAssemblyError(
                "an explicit Physical Group mapping does not exist in the source"
            )
        if not group.explicitly_named:
            raise MultiSourceAssemblyError(
                "fallback-named Physical Groups cannot be copied or mapped"
            )
        mappings[key] = mapping
    component_key = (component.physical_group_tag, local_id)
    if component_key not in mappings:
        raise MultiSourceAssemblyError(
            "the Component Physical Group requires an explicit output mapping"
        )

    element_by_tag = {element.tag: element for element in elements}
    node_by_tag = snapshot.mesh.node_map()
    for element in elements:
        element_points = tuple(
            node_by_tag[tag].coordinates for tag in element.node_tags
        )
        if element.gmsh_type == 4 and (
            _normalized_tet_orientation(
                tuple(element_points[index] for index in (0, 1, 2, 3))
            )
            <= 0.0
        ):
            raise MultiSourceAssemblyError(
                "Frozen source contains a non-positive affine TET4 cell"
            )
    trace_nodes: dict[int, tuple[float, float, float]] = {}
    owner_faces: set[tuple[int, int]] = set()
    trace_endpoint_keys: set[tuple[str, str, str, str]] = set()
    for trace in value.traces:
        _audit_trace_evidence(trace)
        if (
            trace.source_id != snapshot.source_id
            or trace.source_component_local_id != local_id
            or trace.source_component_global_id != component.global_component_id
            or trace.source_snapshot_numbered_sha256 != snapshot.numbered_sha256
            or trace.source_component_numbered_sha256 != component.numbered_sha256
        ):
            raise MultiSourceAssemblyError(
                "locked trace source evidence differs from the Frozen snapshot"
            )
        endpoint_key = _target_key(trace)
        if endpoint_key in trace_endpoint_keys:
            raise MultiSourceAssemblyError(
                "one source may declare a target trace endpoint only once"
            )
        trace_endpoint_keys.add(endpoint_key)
        for trace_node in trace.nodes:
            source_node = node_by_tag.get(trace_node.source_node_tag)
            if source_node is None or source_node.coordinates != (
                trace_node.source_coordinates_mm
            ):
                raise MultiSourceAssemblyError(
                    "locked trace source node evidence is stale"
                )
            package_point = _placed(source_node.coordinates, snapshot)
            if package_point != trace_node.package_coordinates_mm:
                raise MultiSourceAssemblyError(
                    "locked trace package placement evidence is stale"
                )
            previous = trace_nodes.setdefault(
                trace_node.source_node_tag, trace_node.package_coordinates_mm
            )
            if previous != trace_node.package_coordinates_mm:
                raise MultiSourceAssemblyError(
                    "one source trace node has inconsistent package coordinates"
                )
        for facet in trace.facets:
            owner = element_by_tag.get(facet.owner_element_tag)
            if owner is None or owner.kind is not facet.owner_element_kind:
                raise MultiSourceAssemblyError(
                    "locked trace facet owner evidence is stale"
                )
            faces = ELEMENT_SPECS[owner.gmsh_type][2]
            if facet.owner_local_face_index >= len(faces):
                raise MultiSourceAssemblyError(
                    "locked trace local face index is invalid"
                )
            expected = {
                owner.node_tags[index]
                for index in faces[facet.owner_local_face_index]
            }
            if expected != set(facet.source_node_tags):
                raise MultiSourceAssemblyError(
                    "locked trace facet connectivity differs from its owner"
                )
            face_key = (owner.tag, facet.owner_local_face_index)
            if face_key in owner_faces:
                raise MultiSourceAssemblyError(
                    "one Frozen owner face is declared by more than one trace"
                )
            owner_faces.add(face_key)

    selected_face_keys = {
        tuple(sorted(facet.source_node_tags))
        for trace in value.traces
        for facet in trace.facets
    }
    selected_face_incidence = Counter()
    for element in elements:
        for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
            key = tuple(sorted(element.node_tags[index] for index in local_face))
            if key in selected_face_keys:
                selected_face_incidence[key] += 1
    if any(selected_face_incidence[key] != 1 for key in selected_face_keys):
        raise MultiSourceAssemblyError(
            "a locked trace facet is not an exterior Frozen volume face"
        )

    for trace in value.traces:
        referenced_trace_tags = {
            tag for facet in trace.facets for tag in facet.source_node_tags
        }
        declared_trace_tags = {node.source_node_tag for node in trace.nodes}
        if referenced_trace_tags != declared_trace_tags:
            raise MultiSourceAssemblyError(
                "locked trace nodes must exactly equal facet node membership"
            )
        for facet in trace.facets:
            owner = element_by_tag[facet.owner_element_tag]
            local_face = ELEMENT_SPECS[owner.gmsh_type][2][
                facet.owner_local_face_index
            ]
            raw_cycle = tuple(owner.node_tags[index] for index in local_face)
            raw_points = tuple(node_by_tag[tag].coordinates for tag in raw_cycle)
            area_vector = [0.0, 0.0, 0.0]
            for index in range(1, len(raw_points) - 1):
                second = tuple(
                    raw_points[index][axis] - raw_points[0][axis]
                    for axis in range(3)
                )
                third = tuple(
                    raw_points[index + 1][axis] - raw_points[0][axis]
                    for axis in range(3)
                )
                cross = _cross(second, third)
                for axis in range(3):
                    area_vector[axis] += cross[axis]
            area_length = math.sqrt(math.fsum(value * value for value in area_vector))
            if not math.isfinite(area_length) or area_length <= 0.0:
                raise MultiSourceAssemblyError("Frozen trace owner face is degenerate")
            face_centroid = tuple(
                math.fsum(point[axis] for point in raw_points) / len(raw_points)
                for axis in range(3)
            )
            owner_points = tuple(
                node_by_tag[tag].coordinates for tag in owner.node_tags
            )
            owner_centroid = tuple(
                math.fsum(point[axis] for point in owner_points) / len(owner_points)
                for axis in range(3)
            )
            owner_direction = tuple(
                owner_centroid[axis] - face_centroid[axis] for axis in range(3)
            )
            orientation = math.fsum(
                area_vector[axis] * owner_direction[axis] for axis in range(3)
            )
            if not math.isfinite(orientation) or orientation == 0.0:
                raise MultiSourceAssemblyError(
                    "Frozen trace owner face orientation is ambiguous"
                )
            expected_cycle = (
                tuple(reversed(raw_cycle)) if orientation > 0.0 else raw_cycle
            )
            if determinant(value.snapshot.placement.rotation_matrix) < 0.:
                expected_cycle = tuple(reversed(expected_cycle))
            if facet.source_node_tags != expected_cycle:
                raise MultiSourceAssemblyError(
                    "locked trace facet does not use the exterior owner winding"
                )
    return local_id, component


class _UnionFind:
    def __init__(self, keys: Iterable[tuple[str, int]]) -> None:
        self.parent = {key: key for key in keys}

    def find(self, value: tuple[str, int]) -> tuple[str, int]:
        root = value
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[value] != value:
            parent = self.parent[value]
            self.parent[value] = root
            value = parent
        return root

    def union(self, first: tuple[str, int], second: tuple[str, int]) -> None:
        first_root = self.find(first)
        second_root = self.find(second)
        if first_root == second_root:
            return
        smaller, larger = sorted((first_root, second_root))
        self.parent[larger] = smaller


@dataclass(frozen=True, slots=True)
class _FacetRecord:
    source_id: str
    node_keys: tuple[tuple[str, int], ...]
    points: tuple[tuple[float, float, float], ...]
    roundoff_mm: float


def _target_key(trace: LockedInterfaceTrace) -> tuple[str, str, str, str]:
    return (
        trace.target_instance_id,
        trace.target_component_global_id,
        trace.target_fragment_id,
        trace.target_face.value,
    )


def _dot(first: tuple[float, ...], second: tuple[float, ...]) -> float:
    return sum(left * right for left, right in zip(first, second, strict=True))


def _cross(
    first: tuple[float, float, float], second: tuple[float, float, float]
) -> tuple[float, float, float]:
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _norm(value: tuple[float, ...]) -> float:
    return math.sqrt(_dot(value, value))


def _signed_area(points: tuple[tuple[float, float], ...]) -> float:
    anchor = points[0]
    return 0.5 * math.fsum(
        (points[index][0] - anchor[0])
        * (points[(index + 1) % len(points)][1] - anchor[1])
        - (points[index][1] - anchor[1])
        * (points[(index + 1) % len(points)][0] - anchor[0])
        for index in range(len(points))
    )


def _polygon_has_positive_area(
    points: tuple[tuple[float, float], ...],
) -> bool:
    """Detect rank-two polygons without multiplying subnormal raw lengths."""

    if len(points) < 3:
        return False
    anchor = points[0]
    relative = tuple(
        (point[0] - anchor[0], point[1] - anchor[1]) for point in points
    )
    scale = max(abs(value) for point in relative for value in point)
    if scale == 0.0:
        return False
    normalized = tuple(
        (point[0] / scale, point[1] / scale) for point in relative
    )
    return math.fsum(
        normalized[index][0] * normalized[index + 1][1]
        - normalized[index][1] * normalized[index + 1][0]
        for index in range(1, len(normalized) - 1)
    ) != 0.0


def _orient(
    first: tuple[float, float],
    second: tuple[float, float],
    third: tuple[float, float],
) -> float:
    return (second[0] - first[0]) * (third[1] - first[1]) - (
        second[1] - first[1]
    ) * (third[0] - first[0])


def _project_group(
    records: Sequence[_FacetRecord],
) -> tuple[tuple[tuple[float, float], ...], ...]:
    origin = records[0].points[0]
    first_edge = tuple(
        records[0].points[1][index] - origin[index] for index in range(3)
    )
    second_edge = tuple(
        records[0].points[2][index] - origin[index] for index in range(3)
    )
    normal_raw = _cross(first_edge, second_edge)  # type: ignore[arg-type]
    normal_length = _norm(normal_raw)
    if normal_length == 0.0:
        raise MultiSourceAssemblyError("trace preflight found a degenerate facet")
    normal = tuple(value / normal_length for value in normal_raw)
    dropped_axis = max(range(3), key=lambda axis: abs(normal[axis]))
    projection_axes = tuple(axis for axis in range(3) if axis != dropped_axis)
    maximum_roundoff = max(record.roundoff_mm for record in records)
    projected: list[tuple[tuple[float, float], ...]] = []
    for record in records:
        polygon: list[tuple[float, float]] = []
        for point in record.points:
            relative = tuple(point[index] - origin[index] for index in range(3))
            if abs(_dot(relative, normal)) > maximum_roundoff:
                raise MultiSourceAssemblyError(
                    "traces for one target endpoint are not coplanar"
                )
            polygon.append(
                (point[projection_axes[0]], point[projection_axes[1]])
            )
        value = tuple(polygon)
        if _signed_area(value) < 0.0:
            value = tuple(reversed(value))
        if _signed_area(value) <= 0.0 or any(
            _orient(
                value[index - 1],
                value[index],
                value[(index + 1) % len(value)],
            )
            <= 0.0
            for index in range(len(value))
        ):
            raise MultiSourceAssemblyError(
                "trace conflict preflight requires strictly convex facets"
            )
        projected.append(value)
    return tuple(projected)


def _point_segment_parameter(
    point: tuple[float, float],
    first: tuple[float, float],
    second: tuple[float, float],
) -> tuple[float, float]:
    delta = (second[0] - first[0], second[1] - first[1])
    squared = _dot(delta, delta)
    if squared == 0.0:
        return 0.0, math.dist(point, first)
    parameter = _dot((point[0] - first[0], point[1] - first[1]), delta) / squared
    closest = (first[0] + parameter * delta[0], first[1] + parameter * delta[1])
    return parameter, math.dist(point, closest)


def _point_segment_distance(
    point: tuple[float, float],
    first: tuple[float, float],
    second: tuple[float, float],
) -> float:
    parameter, _distance = _point_segment_parameter(point, first, second)
    parameter = min(1.0, max(0.0, parameter))
    closest = (
        first[0] + parameter * (second[0] - first[0]),
        first[1] + parameter * (second[1] - first[1]),
    )
    return math.dist(point, closest)


def _clip_convex(
    subject: tuple[tuple[float, float], ...],
    clip: tuple[tuple[float, float], ...],
    tolerance: float,
) -> tuple[tuple[float, float], ...]:
    output = list(subject)
    for index, clip_first in enumerate(clip):
        clip_second = clip[(index + 1) % len(clip)]
        before = output
        output = []
        if not before:
            break
        start = before[-1]
        start_inside = _orient(clip_first, clip_second, start) >= -tolerance
        for end in before:
            end_inside = _orient(clip_first, clip_second, end) >= -tolerance
            if end_inside != start_inside:
                direction = (end[0] - start[0], end[1] - start[1])
                edge = (
                    clip_second[0] - clip_first[0],
                    clip_second[1] - clip_first[1],
                )
                denominator = direction[0] * edge[1] - direction[1] * edge[0]
                if denominator != 0.0:
                    offset = (
                        clip_first[0] - start[0],
                        clip_first[1] - start[1],
                    )
                    parameter = (
                        offset[0] * edge[1] - offset[1] * edge[0]
                    ) / denominator
                    output.append(
                        (
                            start[0] + parameter * direction[0],
                            start[1] + parameter * direction[1],
                        )
                    )
            if end_inside:
                output.append(end)
            start = end
            start_inside = end_inside
    return tuple(output)


def _edges(polygon: tuple[tuple[float, float], ...]):
    return tuple(
        (polygon[index], polygon[(index + 1) % len(polygon)])
        for index in range(len(polygon))
    )


def _matching_edge_nodes(
    first_record: _FacetRecord,
    second_record: _FacetRecord,
    first_edge_index: int,
    second_edge_index: int,
    union: _UnionFind,
) -> bool:
    first_keys = (
        first_record.node_keys[first_edge_index],
        first_record.node_keys[(first_edge_index + 1) % len(first_record.node_keys)],
    )
    second_keys = (
        second_record.node_keys[second_edge_index],
        second_record.node_keys[(second_edge_index + 1) % len(second_record.node_keys)],
    )
    return (
        union.find(first_keys[0]) == union.find(second_keys[1])
        and union.find(first_keys[1]) == union.find(second_keys[0])
    ) or (
        union.find(first_keys[0]) == union.find(second_keys[0])
        and union.find(first_keys[1]) == union.find(second_keys[1])
    )


def _audit_facet_pair(
    first_record: _FacetRecord,
    second_record: _FacetRecord,
    first: tuple[tuple[float, float], ...],
    second: tuple[tuple[float, float], ...],
    union: _UnionFind,
) -> None:
    scale = max(
        1.0,
        *(math.dist(edge[0], edge[1]) for edge in (*_edges(first), *_edges(second))),
    )
    distance_tolerance = max(
        first_record.roundoff_mm,
        second_record.roundoff_mm,
        64.0 * math.ulp(scale),
    )
    orientation_tolerance = distance_tolerance * scale
    first_edges = _edges(first)
    second_edges = _edges(second)
    exact_shared_edges: list[
        tuple[tuple[float, float], tuple[float, float]]
    ] = []
    for first_index, (first_a, first_b) in enumerate(first_edges):
        for second_index, (second_a, second_b) in enumerate(second_edges):
            if (
                (first_a == second_a and first_b == second_b)
                or (first_a == second_b and first_b == second_a)
            ) and _matching_edge_nodes(
                first_record,
                second_record,
                first_index,
                second_index,
                union,
            ):
                exact_shared_edges.append((first_a, first_b))

    clipped_both = (
        _clip_convex(first, second, 0.0),
        _clip_convex(second, first, 0.0),
    )
    positive_rank_clips = tuple(
        clip for clip in clipped_both if _polygon_has_positive_area(clip)
    )
    if positive_rank_clips:
        maximum_clip_area = max(
            abs(_signed_area(clip)) for clip in positive_rank_clips
        )
        within_roundoff_capsule = False
        if (
            maximum_clip_area <= distance_tolerance * scale
            and len(exact_shared_edges) == 1
        ):
            edge_first, edge_second = exact_shared_edges[0]
            within_roundoff_capsule = all(
                _point_segment_distance(point, edge_first, edge_second)
                <= distance_tolerance
                for clip in clipped_both
                for point in clip
            )
        if not within_roundoff_capsule:
            raise MultiSourceAssemblyError(
                "multiple source traces have duplicate or positive-area target coverage"
            )

    for first_index, (first_a, first_b) in enumerate(first_edges):
        first_length = math.dist(first_a, first_b)
        for second_index, (second_a, second_b) in enumerate(second_edges):
            second_length = math.dist(second_a, second_b)
            if first_length == 0.0 or second_length == 0.0:
                raise MultiSourceAssemblyError("trace contains a degenerate edge")
            first_on_second = tuple(
                _point_segment_parameter(point, second_a, second_b)
                for point in (first_a, first_b)
            )
            second_on_first = tuple(
                _point_segment_parameter(point, first_a, first_b)
                for point in (second_a, second_b)
            )
            parameter_tolerance = distance_tolerance / min(
                first_length, second_length
            )
            fully_same = all(
                distance <= distance_tolerance
                for _, distance in (*first_on_second, *second_on_first)
            ) and all(
                -parameter_tolerance <= parameter <= 1.0 + parameter_tolerance
                for parameter, _ in (*first_on_second, *second_on_first)
            ) and math.isclose(
                first_length,
                second_length,
                rel_tol=0.0,
                abs_tol=distance_tolerance,
            )
            if fully_same:
                if not _matching_edge_nodes(
                    first_record,
                    second_record,
                    first_index,
                    second_index,
                    union,
                ):
                    raise MultiSourceAssemblyError(
                        "a shared target edge lacks an explicit shared-node declaration"
                    )
                continue
            for point_tests, host_length in (
                (first_on_second, second_length),
                (second_on_first, first_length),
            ):
                for parameter, distance in point_tests:
                    if (
                        distance <= distance_tolerance
                        and distance_tolerance < parameter * host_length
                        and distance_tolerance < (1.0 - parameter) * host_length
                    ):
                        raise MultiSourceAssemblyError(
                            "multiple source traces form a T-junction or "
                            "partial edge overlap"
                        )
            first_side = (
                _orient(first_a, first_b, second_a),
                _orient(first_a, first_b, second_b),
            )
            second_side = (
                _orient(second_a, second_b, first_a),
                _orient(second_a, second_b, first_b),
            )
            if (
                first_side[0] * first_side[1] < 0.0
                and second_side[0] * second_side[1] < 0.0
                and min(
                    *(abs(value) for value in (*first_side, *second_side))
                )
                > orientation_tolerance
            ):
                raise MultiSourceAssemblyError(
                    "multiple source trace boundaries cross"
                )


def _preflight_trace_geometry(
    values: tuple[MultiSourceInput, ...],
    union: _UnionFind,
    *,
    pair_limit: int,
) -> None:
    grouped: dict[tuple[str, str, str, str], list[_FacetRecord]] = defaultdict(list)
    for value in values:
        source_id = value.snapshot.source_id
        for trace in value.traces:
            points_by_tag = {
                node.source_node_tag: node.package_coordinates_mm
                for node in trace.nodes
            }
            for facet in trace.facets:
                grouped[_target_key(trace)].append(
                    _FacetRecord(
                        source_id,
                        tuple((source_id, tag) for tag in facet.source_node_tags),
                        tuple(points_by_tag[tag] for tag in facet.source_node_tags),
                        trace.tolerance.roundoff_mm,
                    )
                )
    pair_count = 0
    for records in grouped.values():
        source_counts = Counter(record.source_id for record in records)
        pair_count += len(records) * (len(records) - 1) // 2
        pair_count -= sum(
            count * (count - 1) // 2 for count in source_counts.values()
        )
        if pair_count > pair_limit:
            break
    if pair_count > pair_limit:
        raise MultiSourceAssemblyError(
            "trace conflict preflight exceeds maximum_trace_facet_pair_checks"
        )
    for records_value in grouped.values():
        records = records_value
        projected = _project_group(records)
        indices_by_source: dict[str, list[int]] = defaultdict(list)
        for index, record in enumerate(records):
            indices_by_source[record.source_id].append(index)
        source_ids = sorted(indices_by_source)
        for first_source_index, first_source_id in enumerate(source_ids):
            for second_source_id in source_ids[first_source_index + 1 :]:
                for first_index in indices_by_source[first_source_id]:
                    for second_index in indices_by_source[second_source_id]:
                        _audit_facet_pair(
                            records[first_index],
                            records[second_index],
                            projected[first_index],
                            projected[second_index],
                            union,
                        )


def _plan_provenance_sha256(
    values: tuple[MultiSourceInput, ...],
    shared_interfaces: tuple[DeclaredSharedInterface, ...],
    nodes: tuple[AssemblyNode, ...],
    elements: tuple[AssemblyElement, ...],
    groups: tuple[AssemblyPhysicalGroup, ...],
) -> str:
    trace_count = sum(len(value.traces) for value in values)
    mapping_count = sum(len(value.physical_group_maps) for value in values)
    shared_pair_count = sum(
        len(declaration.node_pairs) for declaration in shared_interfaces
    )
    group_membership_count = sum(len(group.element_tags) for group in groups)
    group_provenance_count = sum(len(group.source_groups) for group in groups)

    def source_records():
        for value in values:
            yield [
                value.snapshot.source_id,
                value.component_global_id,
                value.snapshot.numbered_sha256,
                list(value.snapshot.placement.translation_xyz_mm),
                [list(row) for row in value.snapshot.placement.rotation_matrix],
                [
                    [
                        role,
                        identity.declaration,
                        identity.runtime_path,
                        identity.size_bytes,
                        identity.sha256,
                    ]
                    for role, identity in sorted(value.snapshot.artifacts.items())
                ],
            ]

    def trace_records():
        for value in values:
            for trace in sorted(
                value.traces,
                key=lambda item: (
                    _target_key(item),
                    item.source_trace_numbered_sha256,
                ),
            ):
                yield [
                    value.snapshot.source_id,
                    trace.source_trace_numbered_sha256,
                    trace.package_geometry_sha256,
                    list(_target_key(trace)),
                ]

    def mapping_records():
        for value in values:
            for mapping in sorted(value.physical_group_maps):
                yield [
                    value.snapshot.source_id,
                    mapping.source_group_tag,
                    mapping.source_group_name,
                    mapping.output_group_name,
                ]

    def shared_interface_records():
        for declaration in shared_interfaces:
            yield [
                declaration.first_source_id,
                declaration.second_source_id,
                len(declaration.node_pairs),
            ]

    def shared_pair_records():
        for declaration in shared_interfaces:
            for first_tag, second_tag in declaration.node_pairs:
                yield [
                    declaration.first_source_id,
                    declaration.second_source_id,
                    first_tag,
                    second_tag,
                ]

    return _stream_digest(
        schema="easymesh-package-v2-multi-source-plan-provenance-v1",
        metadata={
            "source_count": len(values),
            "shared_interface_count": len(shared_interfaces),
            "node_count": len(nodes),
            "element_count": len(elements),
            "physical_group_count": len(groups),
        },
        sections=(
            ("sources", len(values), source_records()),
            ("traces", trace_count, trace_records()),
            ("physical_group_maps", mapping_count, mapping_records()),
            (
                "shared_interfaces",
                len(shared_interfaces),
                shared_interface_records(),
            ),
            ("shared_node_pairs", shared_pair_count, shared_pair_records()),
            (
                "nodes",
                len(nodes),
                (
                    [
                        node.output_tag,
                        list(node.package_coordinates_mm),
                        [list(value) for value in node.source_nodes],
                    ]
                    for node in nodes
                ),
            ),
            (
                "elements",
                len(elements),
                (
                    [
                        element.output_tag,
                        element.kind.value,
                        element.gmsh_type,
                        list(element.node_tags),
                        element.source_id,
                        element.source_component_global_id,
                        element.source_element_tag,
                        element.source_entity_tag,
                        _canonical_float(element.minimum_jacobian_determinant),
                    ]
                    for element in elements
                ),
            ),
            (
                "physical_groups",
                len(groups),
                (
                    [group.output_tag, group.name, len(group.element_tags)]
                    for group in groups
                ),
            ),
            (
                "physical_group_memberships",
                group_membership_count,
                (
                    [group.output_tag, group.name, tag]
                    for group in groups
                    for tag in group.element_tags
                ),
            ),
            (
                "physical_group_provenance",
                group_provenance_count,
                (
                    [group.output_tag, group.name, *source_group]
                    for group in groups
                    for source_group in group.source_groups
                ),
            ),
        ),
    )


def _plan_content_sha256_fields(
    nodes: tuple[AssemblyNode, ...],
    elements: tuple[AssemblyElement, ...],
    physical_groups: tuple[AssemblyPhysicalGroup, ...],
    source_node_output_tags: Mapping[str, Mapping[int, int]],
    source_element_output_tags: Mapping[str, Mapping[int, int]],
    source_component_global_ids: Mapping[str, str],
    source_snapshot_numbered_sha256: Mapping[str, str],
    provenance_sha256: str,
) -> str:
    """Digest every public content field except the digest being computed."""

    node_map_count = sum(
        len(tags) for tags in source_node_output_tags.values()
    )
    element_map_count = sum(
        len(tags) for tags in source_element_output_tags.values()
    )
    group_membership_count = sum(
        len(group.element_tags) for group in physical_groups
    )
    group_provenance_count = sum(
        len(group.source_groups) for group in physical_groups
    )
    return _stream_digest(
        schema="easymesh-package-v2-multi-source-plan-content-v1",
        metadata={
            "source_count": len(source_component_global_ids),
            "node_count": len(nodes),
            "element_count": len(elements),
            "physical_group_count": len(physical_groups),
            "provenance_sha256": provenance_sha256,
        },
        sections=(
            (
                "sources",
                len(source_component_global_ids),
                (
                    [
                        source_id,
                        source_component_global_ids[source_id],
                        source_snapshot_numbered_sha256[source_id],
                        len(source_node_output_tags[source_id]),
                        len(source_element_output_tags[source_id]),
                    ]
                    for source_id in source_component_global_ids
                ),
            ),
            (
                "nodes",
                len(nodes),
                (
                    [
                        node.output_tag,
                        list(node.package_coordinates_mm),
                        [list(value) for value in node.source_nodes],
                    ]
                    for node in nodes
                ),
            ),
            (
                "elements",
                len(elements),
                (
                    [
                        element.output_tag,
                        element.kind.value,
                        element.gmsh_type,
                        list(element.node_tags),
                        element.source_id,
                        element.source_component_global_id,
                        element.source_element_tag,
                        element.source_entity_tag,
                        element.minimum_jacobian_determinant,
                    ]
                    for element in elements
                ),
            ),
            (
                "physical_groups",
                len(physical_groups),
                (
                    [group.output_tag, group.name]
                    for group in physical_groups
                ),
            ),
            (
                "physical_group_memberships",
                group_membership_count,
                (
                    [group.output_tag, tag]
                    for group in physical_groups
                    for tag in group.element_tags
                ),
            ),
            (
                "physical_group_provenance",
                group_provenance_count,
                (
                    [group.output_tag, *source_group]
                    for group in physical_groups
                    for source_group in group.source_groups
                ),
            ),
            (
                "source_node_output_tags",
                node_map_count,
                (
                    [source_id, source_tag, output_tag]
                    for source_id, tags in source_node_output_tags.items()
                    for source_tag, output_tag in tags.items()
                ),
            ),
            (
                "source_element_output_tags",
                element_map_count,
                (
                    [source_id, source_tag, output_tag]
                    for source_id, tags in source_element_output_tags.items()
                    for source_tag, output_tag in tags.items()
                ),
            ),
        ),
    )


def _plan_content_sha256(plan: MultiSourceAssemblyPlan) -> str:
    """Recompute the portable digest using only complete public plan fields."""

    return _plan_content_sha256_fields(
        plan.nodes,
        plan.elements,
        plan.physical_groups,
        plan.source_node_output_tags,
        plan.source_element_output_tags,
        plan.source_component_global_ids,
        plan.source_snapshot_numbered_sha256,
        plan.provenance_sha256,
    )


def _audit_multi_source_assembly_plan(plan: MultiSourceAssemblyPlan) -> None:
    """Deeply validate a plan without relying on dataclass frozen-ness."""

    if type(plan) is not MultiSourceAssemblyPlan:
        raise MultiSourceAssemblyError(
            "assembly plan must be a MultiSourceAssemblyPlan"
        )
    if (
        type(plan.nodes) is not tuple
        or not plan.nodes
        or type(plan.elements) is not tuple
        or not plan.elements
        or type(plan.physical_groups) is not tuple
        or not plan.physical_groups
    ):
        raise MultiSourceAssemblyError(
            "assembly plan records must be non-empty bounded tuples"
        )
    for field_name in (
        "source_node_output_tags",
        "source_element_output_tags",
        "source_component_global_ids",
        "source_snapshot_numbered_sha256",
    ):
        if not isinstance(getattr(plan, field_name), Mapping):
            raise MultiSourceAssemblyError(
                f"assembly plan {field_name} must be a mapping"
            )
    source_ids = tuple(plan.source_component_global_ids)
    if (
        len(source_ids) < 2
        or any(not _is_canonical_name(source_id) for source_id in source_ids)
        or source_ids != tuple(sorted(source_ids))
    ):
        raise MultiSourceAssemblyError(
            "assembly plan source IDs must be canonical and globally unique"
        )
    expected_source_ids = set(source_ids)
    if any(
        set(getattr(plan, field_name)) != expected_source_ids
        for field_name in (
            "source_node_output_tags",
            "source_element_output_tags",
            "source_snapshot_numbered_sha256",
        )
    ):
        raise MultiSourceAssemblyError(
            "assembly plan source map key sets are inconsistent"
        )
    if any(
        tuple(getattr(plan, field_name)) != source_ids
        for field_name in (
            "source_node_output_tags",
            "source_element_output_tags",
            "source_snapshot_numbered_sha256",
        )
    ):
        raise MultiSourceAssemblyError(
            "assembly plan source maps are not canonically ordered"
        )
    component_ids = tuple(plan.source_component_global_ids.values())
    if (
        any(not _is_canonical_name(value) for value in component_ids)
        or len(set(component_ids)) != len(component_ids)
    ):
        raise MultiSourceAssemblyError(
            "assembly plan global Component identities are invalid"
        )
    if any(
        not _is_sha256(value)
        for value in plan.source_snapshot_numbered_sha256.values()
    ):
        raise MultiSourceAssemblyError(
            "assembly plan source snapshot digest is invalid"
        )
    if not _is_sha256(plan.provenance_sha256) or not _is_sha256(
        plan.numbered_sha256
    ):
        raise MultiSourceAssemblyError("assembly plan digest evidence is invalid")

    metadata_bytes = 0

    def add_metadata_name(value: object, *, field_name: str, repeat: int = 1) -> None:
        nonlocal metadata_bytes
        metadata_bytes += (
            _canonical_name_bytes(value, field_name=field_name) * repeat
        )
        if metadata_bytes > _HARD_RESOURCE_CEILINGS[
            "maximum_metadata_utf8_bytes"
        ]:
            raise MultiSourceAssemblyError(
                "assembly plan metadata exceeds the UTF-8 byte ceiling"
            )

    for source_id in source_ids:
        add_metadata_name(
            source_id,
            field_name="assembly source ID",
            repeat=(
                2
                + len(plan.source_node_output_tags[source_id])
                + len(plan.source_element_output_tags[source_id])
            ),
        )
        add_metadata_name(
            plan.source_component_global_ids[source_id],
            field_name="assembly global Component ID",
            repeat=2,
        )

    source_node_membership_count = sum(
        len(tags) for tags in plan.source_node_output_tags.values()
    )
    source_element_membership_count = sum(
        len(tags) for tags in plan.source_element_output_tags.values()
    )
    group_membership_count = sum(
        len(group.element_tags) for group in plan.physical_groups
        if type(group) is AssemblyPhysicalGroup
    )
    group_provenance_count = sum(
        len(group.source_groups) for group in plan.physical_groups
        if type(group) is AssemblyPhysicalGroup
    )
    if (
        len(source_ids) > _HARD_RESOURCE_CEILINGS["maximum_sources"]
        or len(plan.nodes) > _HARD_RESOURCE_CEILINGS["maximum_nodes"]
        or source_node_membership_count
        > _HARD_RESOURCE_CEILINGS["maximum_nodes"]
        or len(plan.elements) > _HARD_RESOURCE_CEILINGS["maximum_elements"]
        or source_element_membership_count
        > _HARD_RESOURCE_CEILINGS["maximum_elements"]
        or len(plan.physical_groups)
        > _HARD_RESOURCE_CEILINGS["maximum_physical_group_mappings"]
        or group_provenance_count
        > _HARD_RESOURCE_CEILINGS["maximum_physical_group_mappings"]
        or group_membership_count
        > _HARD_RESOURCE_CEILINGS["maximum_physical_group_memberships"]
    ):
        raise MultiSourceAssemblyError(
            "assembly plan exceeds an implementation safety ceiling"
        )
    estimated_bytes = (
        source_node_membership_count * 1536
        + len(plan.elements) * 1536
        + group_provenance_count * 256
        + group_membership_count * 128
    )
    if estimated_bytes > _HARD_RESOURCE_CEILINGS["maximum_estimated_output_bytes"]:
        raise MultiSourceAssemblyError(
            "assembly plan exceeds the estimated output memory ceiling"
        )

    if any(type(node) is not AssemblyNode for node in plan.nodes):
        raise MultiSourceAssemblyError(
            "assembly plan contains an invalid node DTO"
        )
    for node in plan.nodes:
        node.__post_init__()
        for source_id, _source_tag in node.source_nodes:
            add_metadata_name(
                source_id,
                field_name="assembly node source ID",
                repeat=2,
            )
    expected_node_tags = tuple(range(1, len(plan.nodes) + 1))
    if tuple(node.output_tag for node in plan.nodes) != expected_node_tags:
        raise MultiSourceAssemblyError(
            "assembly node output tags must be dense and ordered"
        )
    if tuple(node.source_nodes for node in plan.nodes) != tuple(
        sorted(node.source_nodes for node in plan.nodes)
    ):
        raise MultiSourceAssemblyError(
            "assembly nodes are not in canonical provenance order"
        )
    coordinates: set[tuple[float, float, float]] = set()
    expected_node_maps: dict[str, dict[int, int]] = {
        source_id: {} for source_id in source_ids
    }
    node_sources_by_output_tag: dict[int, set[str]] = {}
    for node in plan.nodes:
        if node.package_coordinates_mm in coordinates:
            raise MultiSourceAssemblyError(
                "assembly plan contains two nodes at one exact coordinate"
            )
        coordinates.add(node.package_coordinates_mm)
        node_sources_by_output_tag[node.output_tag] = {
            source_id for source_id, _ in node.source_nodes
        }
        for source_id, source_tag in node.source_nodes:
            if source_id not in expected_source_ids:
                raise MultiSourceAssemblyError(
                    "assembly node provenance references an unknown source"
                )
            if source_tag in expected_node_maps[source_id]:
                raise MultiSourceAssemblyError(
                    "one source node appears in multiple assembly nodes"
                )
            expected_node_maps[source_id][source_tag] = node.output_tag
    for source_id in source_ids:
        actual = plan.source_node_output_tags[source_id]
        if (
            not isinstance(actual, Mapping)
            or any(
                not _is_positive_int(source_tag)
                or not _is_positive_int(output_tag)
                for source_tag, output_tag in actual.items()
            )
            or tuple(actual) != tuple(sorted(actual))
            or dict(actual) != expected_node_maps[source_id]
        ):
            raise MultiSourceAssemblyError(
                "assembly source-node map is not bidirectionally consistent"
            )

    if any(type(element) is not AssemblyElement for element in plan.elements):
        raise MultiSourceAssemblyError(
            "assembly plan contains an invalid element DTO"
        )
    for element in plan.elements:
        element.__post_init__()
        add_metadata_name(
            element.source_id,
            field_name="assembly element source ID",
            repeat=2,
        )
        add_metadata_name(
            element.source_component_global_id,
            field_name="assembly element global Component ID",
            repeat=2,
        )
    expected_element_tags = tuple(range(1, len(plan.elements) + 1))
    if tuple(element.output_tag for element in plan.elements) != expected_element_tags:
        raise MultiSourceAssemblyError(
            "assembly element output tags must be dense and ordered"
        )
    if tuple(
        (element.source_id, element.source_element_tag)
        for element in plan.elements
    ) != tuple(
        sorted(
            (element.source_id, element.source_element_tag)
            for element in plan.elements
        )
    ):
        raise MultiSourceAssemblyError(
            "assembly elements are not in canonical source order"
        )
    expected_element_maps: dict[str, dict[int, int]] = {
        source_id: {} for source_id in source_ids
    }
    element_source_by_output_tag: dict[int, str] = {}
    node_coordinates_by_output_tag = {
        node.output_tag: node.package_coordinates_mm for node in plan.nodes
    }
    for element in plan.elements:
        if element.source_id not in expected_source_ids:
            raise MultiSourceAssemblyError(
                "assembly element provenance references an unknown source"
            )
        if element.source_component_global_id != (
            plan.source_component_global_ids[element.source_id]
        ):
            raise MultiSourceAssemblyError(
                "assembly element global Component provenance is inconsistent"
            )
        if element.source_element_tag in expected_element_maps[element.source_id]:
            raise MultiSourceAssemblyError(
                "one source element appears more than once in the assembly plan"
            )
        expected_element_maps[element.source_id][element.source_element_tag] = (
            element.output_tag
        )
        element_source_by_output_tag[element.output_tag] = element.source_id
        for node_tag in element.node_tags:
            if node_tag not in node_sources_by_output_tag:
                raise MultiSourceAssemblyError(
                    "assembly element references an unknown output node"
                )
            if element.source_id not in node_sources_by_output_tag[node_tag]:
                raise MultiSourceAssemblyError(
                    "assembly element references a node outside its source mapping"
                )
        if element.gmsh_type == 4 and _normalized_tet_orientation(
            tuple(
                node_coordinates_by_output_tag[tag] for tag in element.node_tags
            )
        ) <= 0.0:
            raise MultiSourceAssemblyError(
                "assembly plan contains a non-positive affine TET4 cell"
            )
    for source_id in source_ids:
        actual = plan.source_element_output_tags[source_id]
        if (
            not isinstance(actual, Mapping)
            or any(
                not _is_positive_int(source_tag)
                or not _is_positive_int(output_tag)
                for source_tag, output_tag in actual.items()
            )
            or tuple(actual) != tuple(sorted(actual))
            or dict(actual) != expected_element_maps[source_id]
        ):
            raise MultiSourceAssemblyError(
                "assembly source-element map is not bidirectionally consistent"
            )

    if any(
        type(group) is not AssemblyPhysicalGroup for group in plan.physical_groups
    ):
        raise MultiSourceAssemblyError(
            "assembly plan contains an invalid Physical Group DTO"
        )
    for group in plan.physical_groups:
        group.__post_init__()
        add_metadata_name(
            group.name,
            field_name="assembly Physical Group name",
            repeat=(
                2
                + len(group.element_tags)
                + len(group.source_groups)
            ),
        )
        for source_id, _source_tag, source_name in group.source_groups:
            add_metadata_name(
                source_id,
                field_name="assembly Physical Group source ID",
                repeat=2,
            )
            add_metadata_name(
                source_name,
                field_name="assembly source Physical Group name",
                repeat=2,
            )
    if tuple(group.output_tag for group in plan.physical_groups) != tuple(
        range(1, len(plan.physical_groups) + 1)
    ):
        raise MultiSourceAssemblyError(
            "assembly Physical Group output tags must be dense and ordered"
        )
    group_names = tuple(group.name for group in plan.physical_groups)
    if group_names != tuple(sorted(group_names)) or len(
        {name.casefold() for name in group_names}
    ) != len(group_names):
        raise MultiSourceAssemblyError(
            "assembly Physical Group names are not canonical and collision-free"
        )
    all_members: set[int] = set()
    all_provenance: set[tuple[str, int, str]] = set()
    sources_with_provenance: set[str] = set()
    for group in plan.physical_groups:
        member_sources: set[str] = set()
        for element_tag in group.element_tags:
            source_id = element_source_by_output_tag.get(element_tag)
            if source_id is None:
                raise MultiSourceAssemblyError(
                    "assembly Physical Group references an unknown element"
                )
            member_sources.add(source_id)
            all_members.add(element_tag)
        provenance_sources = {value[0] for value in group.source_groups}
        if provenance_sources != member_sources or not provenance_sources.issubset(
            expected_source_ids
        ):
            raise MultiSourceAssemblyError(
                "assembly Physical Group membership/provenance is inconsistent"
            )
        for source_group in group.source_groups:
            if source_group in all_provenance:
                raise MultiSourceAssemblyError(
                    "one source Physical Group is mapped more than once"
                )
            all_provenance.add(source_group)
            sources_with_provenance.add(source_group[0])
    if all_members != set(expected_element_tags):
        raise MultiSourceAssemblyError(
            "assembly Physical Groups do not cover every source element"
        )
    if sources_with_provenance != expected_source_ids:
        raise MultiSourceAssemblyError(
            "assembly Physical Group provenance does not cover every source"
        )
    if _plan_content_sha256(plan) != plan.numbered_sha256:
        raise MultiSourceAssemblyError(
            "assembly plan numbered content digest is inconsistent"
        )


def audit_multi_source_assembly_plan(plan: MultiSourceAssemblyPlan) -> None:
    """Public fail-closed audit for every downstream plan consumer."""

    _audit_multi_source_assembly_plan(plan)


def _preflight_input_metadata(
    values: tuple[MultiSourceInput, ...],
    declarations: tuple[DeclaredSharedInterface, ...],
    *,
    maximum_bytes: int,
) -> int:
    total = 0

    def add_name(value: object, *, field_name: str, repeat: int = 1) -> None:
        nonlocal total
        total += _canonical_name_bytes(value, field_name=field_name) * repeat
        if total > maximum_bytes:
            raise MultiSourceAssemblyError(
                "multi-source metadata exceeds maximum_metadata_utf8_bytes"
            )

    def add_text(value: object, *, field_name: str) -> None:
        nonlocal total
        total += _bounded_metadata_text_bytes(value, field_name=field_name)
        if total > maximum_bytes:
            raise MultiSourceAssemblyError(
                "multi-source metadata exceeds maximum_metadata_utf8_bytes"
            )

    for value in values:
        snapshot = value.snapshot
        source_id = snapshot.source_id
        add_name(
            source_id,
            field_name="Frozen source ID",
            repeat=(
                3
                + len(snapshot.mesh.nodes)
                + len(snapshot.mesh.elements)
                + len(value.traces)
                + len(value.physical_group_maps)
            ),
        )
        add_name(
            value.component_global_id,
            field_name="Frozen global Component ID",
            repeat=1 + len(snapshot.mesh.elements),
        )
        if not isinstance(snapshot.artifacts, Mapping):
            raise MultiSourceAssemblyError(
                "Frozen artifact metadata must be a mapping"
            )
        for role, identity in snapshot.artifacts.items():
            if type(identity) is not FrozenArtifactIdentity:
                raise MultiSourceAssemblyError(
                    "Frozen artifact metadata contains an invalid identity"
                )
            add_name(role, field_name="Frozen artifact role")
            add_text(
                identity.declaration,
                field_name="Frozen artifact declaration",
            )
            add_text(
                identity.runtime_path,
                field_name="Frozen artifact runtime path",
            )
        for element in snapshot.mesh.elements:
            for group in element.physical_groups:
                if type(group) is not PhysicalGroup:
                    raise MultiSourceAssemblyError(
                        "Frozen Physical Group metadata is invalid"
                    )
                add_name(
                    group.name,
                    field_name="Frozen Physical Group name",
                )
        for trace in value.traces:
            for field_name in (
                "source_id",
                "source_component_local_id",
                "source_component_global_id",
                "target_instance_id",
                "target_component_local_id",
                "target_component_global_id",
                "target_fragment_id",
            ):
                add_name(
                    getattr(trace, field_name),
                    field_name=f"trace {field_name}",
                )
        for mapping in value.physical_group_maps:
            if type(mapping) is not ExplicitPhysicalGroupMap:
                raise MultiSourceAssemblyError(
                    "Physical Group map metadata is invalid"
                )
            add_name(
                mapping.source_group_name,
                field_name="source Physical Group name",
            )
            add_name(
                mapping.output_group_name,
                field_name="output Physical Group name",
            )
    for declaration in declarations:
        add_name(
            declaration.first_source_id,
            field_name="shared first source ID",
            repeat=1 + len(declaration.node_pairs),
        )
        add_name(
            declaration.second_source_id,
            field_name="shared second source ID",
            repeat=1 + len(declaration.node_pairs),
        )
    return total


def build_multi_source_assembly_plan(
    sources: tuple[MultiSourceInput, ...],
    *,
    shared_interfaces: tuple[DeclaredSharedInterface, ...] = (),
    limits: MultiSourceLimits | None = None,
) -> MultiSourceAssemblyPlan:
    """Audit frozen evidence and return a deterministic tag/membership plan."""

    if type(sources) is not tuple:
        raise MultiSourceAssemblyError("sources must be a bounded tuple")
    if type(shared_interfaces) is not tuple:
        raise MultiSourceAssemblyError(
            "shared_interfaces must be a bounded tuple"
        )
    values = sources
    declarations = shared_interfaces
    if limits is None:
        limits = MultiSourceLimits()
    if type(limits) is not MultiSourceLimits:
        raise MultiSourceAssemblyError("limits must be MultiSourceLimits")
    limits.__post_init__()
    if len(values) < 2:
        raise MultiSourceAssemblyError(
            "multi-source planning requires at least two Frozen sources"
        )
    if len(values) > limits.maximum_sources:
        raise MultiSourceAssemblyError("source count exceeds maximum_sources")
    if any(type(value) is not MultiSourceInput for value in values):
        raise MultiSourceAssemblyError("sources contains an invalid input")
    if any(type(value.snapshot) is not FrozenSourceSnapshot for value in values):
        raise MultiSourceAssemblyError(
            "each multi-source input must contain a FrozenSourceSnapshot"
        )
    if any(type(value.snapshot.mesh) is not VolumeMesh for value in values):
        raise MultiSourceAssemblyError("snapshot.mesh must be a VolumeMesh")
    if any(
        type(value.snapshot.mesh.nodes) is not tuple
        or type(value.snapshot.mesh.elements) is not tuple
        for value in values
    ):
        raise MultiSourceAssemblyError(
            "Frozen mesh nodes and elements must be bounded tuples"
        )
    if any(
        type(node) is not MeshNode
        for value in values
        for node in value.snapshot.mesh.nodes
    ) or any(
        type(element) is not VolumeElement
        for value in values
        for element in value.snapshot.mesh.elements
    ):
        raise MultiSourceAssemblyError("Frozen mesh contains an invalid IR record")
    if any(
        type(element.physical_groups) is not tuple
        for value in values
        for element in value.snapshot.mesh.elements
    ):
        raise MultiSourceAssemblyError(
            "Frozen element Physical Groups must be bounded tuples"
        )
    if any(
        type(trace) is not LockedInterfaceTrace
        for value in values
        for trace in value.traces
    ):
        raise MultiSourceAssemblyError("traces contains an invalid value")
    if any(type(value) is not DeclaredSharedInterface for value in declarations):
        raise MultiSourceAssemblyError(
            "shared_interfaces contains an invalid declaration"
        )
    if sum(len(value.node_pairs) for value in declarations) > (
        limits.maximum_shared_node_pairs
    ):
        raise MultiSourceAssemblyError(
            "shared declarations exceed maximum_shared_node_pairs"
        )

    source_ids = tuple(value.snapshot.source_id for value in values)
    component_ids = tuple(value.component_global_id for value in values)
    for source_id in source_ids:
        _canonical_name_bytes(source_id, field_name="Frozen source ID")
    for component_id in component_ids:
        _canonical_name_bytes(
            component_id,
            field_name="Frozen global Component ID",
        )
    if len(set(source_ids)) != len(source_ids):
        raise MultiSourceAssemblyError("Frozen source IDs must be globally unique")
    if len(set(component_ids)) != len(component_ids):
        raise MultiSourceAssemblyError(
            "Frozen global Component identities must be unique"
        )
    values = tuple(sorted(values, key=lambda value: value.snapshot.source_id))
    source_ids = tuple(value.snapshot.source_id for value in values)
    actual_node_count = sum(len(value.snapshot.mesh.nodes) for value in values)
    actual_element_count = sum(len(value.snapshot.mesh.elements) for value in values)
    if actual_node_count > limits.maximum_nodes:
        raise MultiSourceAssemblyError("node count exceeds maximum_nodes")
    if actual_element_count > limits.maximum_elements:
        raise MultiSourceAssemblyError("element count exceeds maximum_elements")
    trace_facet_count = sum(
        len(trace.facets) for value in values for trace in value.traces
    )
    if trace_facet_count > limits.maximum_trace_facets:
        raise MultiSourceAssemblyError("trace facets exceed maximum_trace_facets")
    trace_node_membership_count = sum(
        len(trace.nodes) for value in values for trace in value.traces
    )
    if trace_node_membership_count > limits.maximum_trace_node_memberships:
        raise MultiSourceAssemblyError(
            "trace nodes exceed maximum_trace_node_memberships"
        )
    physical_mapping_count = sum(
        len(value.physical_group_maps) for value in values
    )
    if physical_mapping_count > limits.maximum_physical_group_mappings:
        raise MultiSourceAssemblyError(
            "Physical Group mappings exceed maximum_physical_group_mappings"
        )
    physical_membership_count = sum(
        len(element.physical_groups)
        for value in values
        for element in value.snapshot.mesh.elements
    )
    if physical_membership_count > limits.maximum_physical_group_memberships:
        raise MultiSourceAssemblyError(
            "Physical Group memberships exceed maximum_physical_group_memberships"
        )
    metadata_utf8_bytes = _preflight_input_metadata(
        values,
        declarations,
        maximum_bytes=limits.maximum_metadata_utf8_bytes,
    )
    estimated_output_bytes = (
        actual_node_count * 1536
        + actual_element_count * 1536
        + trace_facet_count * 512
        + trace_node_membership_count * 256
        + sum(len(value.node_pairs) for value in declarations) * 128
        + physical_mapping_count * 256
        + physical_membership_count * 128
        + metadata_utf8_bytes * 2
    )
    if estimated_output_bytes > limits.maximum_estimated_output_bytes:
        raise MultiSourceAssemblyError(
            "estimated plan memory exceeds maximum_estimated_output_bytes"
        )

    for value in values:
        _audit_source(value)

    frozen_component_ids = set(component_ids)
    target_by_global_id: dict[str, tuple[str, str]] = {}
    global_by_target_endpoint: dict[tuple[str, str], str] = {}
    for value in values:
        for trace in value.traces:
            if trace.target_component_global_id in frozen_component_ids:
                raise MultiSourceAssemblyError(
                    "generated and Frozen global Component identities collide"
                )
            endpoint = (trace.target_instance_id, trace.target_component_local_id)
            previous_endpoint = target_by_global_id.setdefault(
                trace.target_component_global_id, endpoint
            )
            previous_global = global_by_target_endpoint.setdefault(
                endpoint, trace.target_component_global_id
            )
            if (
                previous_endpoint != endpoint
                or previous_global != trace.target_component_global_id
            ):
                raise MultiSourceAssemblyError(
                    "target global Component identity is inconsistent across traces"
                )

    output_names: dict[str, str] = {}
    for value in values:
        for mapping in value.physical_group_maps:
            folded = mapping.output_group_name.casefold()
            previous = output_names.setdefault(folded, mapping.output_group_name)
            if previous != mapping.output_group_name:
                raise MultiSourceAssemblyError(
                    "output Physical Group names collide case-insensitively"
                )

    source_by_id = {value.snapshot.source_id: value for value in values}
    coordinates = {
        (value.snapshot.source_id, node.tag): _placed(node.coordinates, value.snapshot)
        for value in values
        for node in value.snapshot.mesh.nodes
    }
    union = _UnionFind(coordinates)
    trace_tags_by_endpoint = {
        (value.snapshot.source_id, _target_key(trace)): frozenset(
            node.source_node_tag for node in trace.nodes
        )
        for value in values
        for trace in value.traces
    }
    endpoints_by_source_node: dict[
        tuple[str, int], set[tuple[str, str, str, str]]
    ] = defaultdict(set)
    for (source_id, endpoint), tags in trace_tags_by_endpoint.items():
        for tag in tags:
            endpoints_by_source_node[(source_id, tag)].add(endpoint)
    endpoint_query_cache: dict[
        tuple[str, tuple[int, ...]], frozenset[tuple[str, str, str, str]]
    ] = {}
    endpoint_membership_checks = 0

    def endpoints_containing_all(
        source_id: str, tags: set[int]
    ) -> frozenset[tuple[str, str, str, str]]:
        nonlocal endpoint_membership_checks
        query_key = (source_id, tuple(sorted(tags)))
        cached = endpoint_query_cache.get(query_key)
        if cached is not None:
            return cached
        memberships = tuple(
            endpoints_by_source_node.get((source_id, tag), set())
            for tag in query_key[1]
        )
        if not memberships or any(not values for values in memberships):
            result: frozenset[tuple[str, str, str, str]] = frozenset()
        else:
            anchor = min(memberships, key=len)
            endpoint_membership_checks += len(anchor) * len(memberships)
            if endpoint_membership_checks > (
                limits.maximum_shared_endpoint_membership_checks
            ):
                raise MultiSourceAssemblyError(
                    "shared trace binding exceeds "
                    "maximum_shared_endpoint_membership_checks"
                )
            result = frozenset(
                endpoint
                for endpoint in anchor
                if all(endpoint in values for values in memberships)
            )
        endpoint_query_cache[query_key] = result
        return result
    canonical_declarations: list[DeclaredSharedInterface] = []
    declared_pair_keys: set[tuple[tuple[str, int], tuple[str, int]]] = set()
    for declaration in declarations:
        if (
            declaration.first_source_id not in source_by_id
            or declaration.second_source_id not in source_by_id
        ):
            raise MultiSourceAssemblyError(
                "shared interface references an unknown Frozen source"
            )
        pairs = declaration.node_pairs
        first_id = declaration.first_source_id
        second_id = declaration.second_source_id
        if second_id < first_id:
            first_id, second_id = second_id, first_id
            pairs = tuple((second, first) for first, second in pairs)
        pairs = tuple(sorted(pairs))
        canonical = DeclaredSharedInterface(first_id, second_id, pairs)
        canonical_declarations.append(canonical)
        first_declared_tags = {first_tag for first_tag, _ in pairs}
        second_declared_tags = {second_tag for _, second_tag in pairs}
        first_endpoints = endpoints_containing_all(first_id, first_declared_tags)
        second_endpoints = endpoints_containing_all(second_id, second_declared_tags)
        if len(first_endpoints.intersection(second_endpoints)) != 1:
            raise MultiSourceAssemblyError(
                "shared interface nodes must bind one common target trace endpoint"
            )
        for first_tag, second_tag in pairs:
            first_key = (first_id, first_tag)
            second_key = (second_id, second_tag)
            if first_key not in coordinates or second_key not in coordinates:
                raise MultiSourceAssemblyError(
                    "shared interface references an unknown source node"
                )
            pair_key = (first_key, second_key)
            if pair_key in declared_pair_keys:
                raise MultiSourceAssemblyError(
                    "one shared source-node pair is declared more than once"
                )
            declared_pair_keys.add(pair_key)
            if coordinates[first_key] != coordinates[second_key]:
                raise MultiSourceAssemblyError(
                    "shared source nodes must have exactly equal placed coordinates"
                )
            union.union(first_key, second_key)
    canonical_declarations.sort(
        key=lambda value: (
            value.first_source_id,
            value.second_source_id,
            value.node_pairs,
        )
    )
    declarations_tuple = tuple(canonical_declarations)

    members_by_root: dict[tuple[str, int], list[tuple[str, int]]] = defaultdict(list)
    for key in sorted(coordinates):
        members_by_root[union.find(key)].append(key)
    for members in members_by_root.values():
        ids = [source_id for source_id, _ in members]
        if len(ids) != len(set(ids)):
            raise MultiSourceAssemblyError(
                "shared declarations would collapse two nodes from one source"
            )

    roots_at_coordinate: dict[
        tuple[float, float, float], set[tuple[str, int]]
    ] = defaultdict(set)
    sources_at_coordinate: dict[tuple[float, float, float], set[str]] = defaultdict(set)
    for key, point in sorted(coordinates.items()):
        root = union.find(key)
        roots_at_coordinate[point].add(root)
        sources_at_coordinate[point].add(key[0])
    if any(
        len(sources_at_coordinate[point]) > 1 and len(roots) > 1
        for point, roots in roots_at_coordinate.items()
    ):
        raise MultiSourceAssemblyError(
            "different Frozen sources contain an undeclared coincident node"
        )

    _preflight_trace_geometry(
        values,
        union,
        pair_limit=limits.maximum_trace_facet_pair_checks,
    )

    ordered_classes = tuple(
        sorted((tuple(sorted(members)) for members in members_by_root.values()))
    )
    output_tag_by_root: dict[tuple[str, int], int] = {}
    output_nodes: list[AssemblyNode] = []
    for output_tag, members in enumerate(ordered_classes, 1):
        points = {coordinates[key] for key in members}
        if len(points) != 1:
            raise MultiSourceAssemblyError(
                "one assembly node class contains inconsistent coordinates"
            )
        for key in members:
            output_tag_by_root[union.find(key)] = output_tag
        output_nodes.append(AssemblyNode(output_tag, next(iter(points)), members))
    node_maps: dict[str, dict[int, int]] = {source_id: {} for source_id in source_ids}
    for key in sorted(coordinates):
        node_maps[key[0]][key[1]] = output_tag_by_root[union.find(key)]

    output_elements: list[AssemblyElement] = []
    element_maps: dict[str, dict[int, int]] = {
        value.snapshot.source_id: {} for value in values
    }
    source_element_keys: set[tuple[str, int]] = set()
    for value in values:
        source_id = value.snapshot.source_id
        for element in value.snapshot.mesh.elements:
            provenance = (source_id, element.tag)
            if provenance in source_element_keys:
                raise MultiSourceAssemblyError("one source element was copied twice")
            source_element_keys.add(provenance)
            output_tag = len(output_elements) + 1
            element_maps[source_id][element.tag] = output_tag
            output_elements.append(
                AssemblyElement(
                    output_tag,
                    element.kind,
                    element.gmsh_type,
                    tuple(node_maps[source_id][tag] for tag in placed_connectivity(
                        element.gmsh_type, element.node_tags, value.snapshot.placement.rotation_matrix)),
                    source_id,
                    value.component_global_id,
                    element.tag,
                    element.entity_tag,
                    _canonical_float(element.min_jacobian_determinant),
                )
            )
    if len(output_elements) != sum(
        value.snapshot.element_count for value in values
    ):
        raise MultiSourceAssemblyError(
            "multi-source plan did not copy every source element exactly once"
        )

    group_memberships: dict[str, set[int]] = defaultdict(set)
    group_provenance: dict[str, set[tuple[str, int, str]]] = defaultdict(set)
    for value in values:
        source_id = value.snapshot.source_id
        map_by_key = {
            (mapping.source_group_tag, mapping.source_group_name): mapping
            for mapping in value.physical_group_maps
        }
        for element in value.snapshot.mesh.elements:
            for group in element.physical_groups:
                mapping = map_by_key.get((group.tag, group.name))
                if mapping is None:
                    continue
                group_memberships[mapping.output_group_name].add(
                    element_maps[source_id][element.tag]
                )
                group_provenance[mapping.output_group_name].add(
                    (source_id, group.tag, group.name)
                )
    physical_groups = tuple(
        AssemblyPhysicalGroup(
            output_tag,
            name,
            tuple(sorted(group_memberships[name])),
            tuple(sorted(group_provenance[name])),
        )
        for output_tag, name in enumerate(sorted(group_memberships), 1)
    )
    nodes_tuple = tuple(output_nodes)
    elements_tuple = tuple(output_elements)
    provenance_sha256 = _plan_provenance_sha256(
        values,
        declarations_tuple,
        nodes_tuple,
        elements_tuple,
        physical_groups,
    )
    component_global_ids = {
        value.snapshot.source_id: value.component_global_id for value in values
    }
    snapshot_numbered_sha256 = {
        value.snapshot.source_id: value.snapshot.numbered_sha256 for value in values
    }
    numbered_sha256 = _plan_content_sha256_fields(
        nodes_tuple,
        elements_tuple,
        physical_groups,
        node_maps,
        element_maps,
        component_global_ids,
        snapshot_numbered_sha256,
        provenance_sha256,
    )
    return MultiSourceAssemblyPlan(
        nodes_tuple,
        elements_tuple,
        physical_groups,
        node_maps,
        element_maps,
        component_global_ids,
        snapshot_numbered_sha256,
        numbered_sha256,
        provenance_sha256,
    )


__all__ = [
    "AssemblyElement",
    "AssemblyNode",
    "AssemblyPhysicalGroup",
    "DeclaredSharedInterface",
    "ExplicitPhysicalGroupMap",
    "MultiSourceAssemblyError",
    "MultiSourceAssemblyPlan",
    "MultiSourceInput",
    "MultiSourceLimits",
    "audit_multi_source_assembly_plan",
    "build_multi_source_assembly_plan",
]
