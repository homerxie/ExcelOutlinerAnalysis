"""Self-contained, editable Layer mesh schemes; no generated mesh is required."""

import json
from pathlib import Path

from .output_artifacts import atomic_write_text
from .project_file import validate_layer_mesh_state

LAYER_MESH_SCHEMA = "easymesh-layer-mesh-v1"
LAYER_MESH_SUFFIX = ".layer-mesh.json"
LAYER_MESH_FILTER = "Layer 网格方案 (*.layer-mesh.json);;JSON (*.json)"
MAX_LAYER_MESH_BYTES = 16 * 1024 * 1024


def normalized_layer_mesh_path(path):
    path = Path(path).expanduser().resolve()
    if not path.name.lower().endswith(LAYER_MESH_SUFFIX):
        path = path.with_suffix(LAYER_MESH_SUFFIX) if path.suffix.lower() == ".json" else path.with_name(path.name + LAYER_MESH_SUFFIX)
    return path


def save_layer_mesh_state(path, state):
    output = normalized_layer_mesh_path(path)
    document = {"schema": LAYER_MESH_SCHEMA, "layer": validate_layer_mesh_state(state)}
    text = json.dumps(document, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if len(text.encode("utf-8")) > MAX_LAYER_MESH_BYTES:
        raise ValueError("Layer 网格方案文件过大")
    atomic_write_text(output, text)
    return output


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"重复字段：{key}")
        result[key] = value
    return result


def load_layer_mesh_state(path):
    source = Path(path).expanduser().resolve()
    with source.open("rb") as stream:
        data = stream.read(MAX_LAYER_MESH_BYTES + 1)
    if len(data) > MAX_LAYER_MESH_BYTES:
        raise ValueError("Layer 网格方案文件过大")
    document = json.loads(data.decode("utf-8-sig"), object_pairs_hook=_unique_object)
    if not isinstance(document, dict) or document.get("schema") != LAYER_MESH_SCHEMA:
        raise ValueError("不是支持的 Layer 网格方案文件")
    if set(document) != {"schema", "layer"}:
        raise ValueError("Layer 网格方案包含不支持的字段")
    state = validate_layer_mesh_state(document["layer"])
    for key in ("source_path", "output_path"):
        if state[key].strip():
            value = Path(state[key]).expanduser()
            state[key] = str((source.parent / value).resolve())
    return state
