from __future__ import annotations

import hashlib
import json
import keyword
import math
import os
import re
import stat
import subprocess
import sys
import time
import unicodedata
import uuid
from collections.abc import Callable, Iterable, Mapping
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PySide6.QtCore import (
    QProcess,
    QProcessEnvironment,
    QStandardPaths,
    Qt,
    QTimer,
    QUrl,
    Signal,
)
from PySide6.QtGui import QCloseEvent, QColor, QDesktopServices, QFontDatabase, QPalette
from PySide6.QtWidgets import (
    QApplication,
    QAbstractItemDelegate,
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHeaderView,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QStyledItemDelegate,
    QTableWidget,
    QTableWidgetItem,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .package_v2_expression_edit import (
    ExpressionEdit as _PackageV2ExpressionEdit, ExpressionDelegate, variable_name_edit,
    install_tab_key_policy,
)

from .axisymmetric import AxisymmetricMeshParameters, IntervalSizeOverride
from .layer_sweep import (
    LayerSweepPolicy, RadialSeedPolicy, ZSweepOverride, RadialSweepOverride,
    parse_z_sweep_overrides, parse_radial_sweep_overrides,
)
from .layer_sweep_dialog import LayerSweepDialog
from .app_runtime import (
    prepare_runtime_workspace,
    runtime_workspace_root,
    source_project_root,
    worker_command_prefix,
    worker_environment,
    worker_popen_options,
)
from .package_assembly import COMPONENT_LOCAL_DIRECTIONS
from .package_v2_mesh_sizing import ORIGIN_LABELS
from .package_v2_geometry_tree import OWNER_CHOICES_ROLE, TEMPLATE_ROLE, GEOMETRY_ROLE
from .bump_layout import BumpLayout, load_bump_layout
from .cdb_exporter import normalized_cdb_output
from .layout_builder import normalize_material_name
from .mesh_controls import (
    ControlAxis,
    MeshControlInterval,
    build_section_control_intervals,
    effective_size,
    validate_size_override,
)
from .output_artifacts import (
    atomic_write_text,
    exclusive_artifact_lock,
    normalized_mesh_output,
    paths_refer_to_same_file,
)
from .parameters import (
    MAX_DEMO_ESTIMATED_ELEMENTS,
    MIN_NUMERICAL_SEPARATION_UM,
    format_diameters,
)
from .package_v2_compile import compile_package_v2
from .package_v2_authoring import materialize_package_v2_job
from .package_v2_job import (
    MAX_JOB_REQUEST_BYTES,
    PackageV2JobRequest,
    parse_package_v2_job_request,
)
from .package_v2_source_editor import (
    PackageV2SourceConflictError,
    PackageV2SourceEditError,
    PackageV2SourcePendingError,
    PackageV2SourceEditor,
    SourceCell,
    SourceCellKind,
    SourceTableSet,
    build_package_v2_source_tables,
    open_package_v2_source_editor,
)
from .package_v2_source import AUTHORING_MESH_STRATEGY_TOKENS
from .package_v2_frozen_dialog import FrozenMeshInstanceDialog
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_SOURCE,
)
from .package_v2_preview_3d import (
    frozen_component_key,
    generated_component_key,
)
from .package_v2_progress import (
    PACKAGE_V2_PROGRESS_MAX_LINE_BYTES,
    PACKAGE_V2_PROGRESS_PHASE_COUNT,
    PackageV2ProgressError,
    parse_package_v2_progress_event,
)
from .layer_mesh_file import (
    LAYER_MESH_FILTER, LAYER_MESH_SUFFIX, load_layer_mesh_state, save_layer_mesh_state,
)
from .project_file import (
    PROJECT_FILE_FILTER,
    PROJECT_SCHEMA,
    PROJECT_SUFFIX,
    PROJECT_V2_SCHEMA,
    PackageV2ProjectSnapshot,
    build_package_v2_artifact_state,
    load_project_document,
    load_package_v2_project_snapshot,
    normalized_project_path,
    project_path_for_output,
    save_project_document,
    save_package_v2_project_snapshot,
    validate_project_document,
    validate_layer_mesh_state,
)
from .section import SectionPlan, build_section_plan, parse_layer_text
from .sample_mesh import (
    SampleMesh,
    load_sample_mesh,
    validate_compatible_outer_boundaries,
)
from .section_preview import SectionPreview
from .topology import build_topology_with_radial_targets
from .ui_main_window import Ui_MainWindow


PROJECT_ROOT = source_project_root() or Path(__file__).resolve().parent
_MISSING_LAYOUT_DEPENDENCY_SIGNATURE = (-1, -1, -1)
_PACKAGE_V2_PREVIEW_ROLE = int(Qt.ItemDataRole.UserRole) + 1
_PACKAGE_V2_COMPLETION_ROLE = int(Qt.ItemDataRole.UserRole) + 2
_PACKAGE_V2_TEMPLATE_ROLE = int(Qt.ItemDataRole.UserRole) + 3
_PACKAGE_V2_COMPONENT_ROLE = int(Qt.ItemDataRole.UserRole) + 4
_PACKAGE_V2_INSTANCE_TOKEN = "generated-instance/"
_PACKAGE_V2_COMPONENT_LOCAL_DIRECTION_TOKENS = tuple(
    direction.value for direction in COMPONENT_LOCAL_DIRECTIONS
)
_PACKAGE_V2_PROGRESS_PHASES = {
    "job_replay": "重放并核对 Job",
    "source_compile": "重新编译 Source",
    "frozen_audit": "Fresh-audit Frozen artifacts",
    "execution_plan": "准备执行计划",
    "mesh_generation": "生成与装配网格",
    "post_mesh_audit": "复核网格和输入",
    "bundle_publication": "发布 MSH/parameters/report",
    "report_verification": "GUI 复核 report-ready 产物",
}


def _defer_package_v2_combo_rebuild(
    combo: QComboBox,
    callback: Callable[[], None],
) -> None:
    """Run a table-rebuilding combo action only after its popup has closed."""

    def wait_for_popup() -> None:
        try:
            popup_visible = combo.view().isVisible()
        except RuntimeError:
            # The owning table went away for another reason; there is no safe
            # edit left to apply.
            return
        if popup_visible or QApplication.activePopupWidget() is not None:
            QTimer.singleShot(10, wait_for_popup)
            return
        callback()

    QTimer.singleShot(0, wait_for_popup)




class _InheritedPlaneSizeDelegate(QStyledItemDelegate):
    """Paint inherited values while leaving the editor and stored override empty."""

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        if not option.text:
            option.text = index.data(Qt.ItemDataRole.UserRole + 1) or ""
            option.palette.setColor(QPalette.ColorRole.Text, QColor("#aab4c2" if option.palette.color(QPalette.ColorRole.Base).lightness() < 128 else "#667085"))


class _PackageV2QuickVariableDialog(QDialog):
    """Compact form for one staged Template parameter or derived variable."""

    def __init__(
        self,
        parent: QWidget,
        *,
        role: str,
        existing_names: Iterable[str],
        expression_candidates: Iterable[str],
        commit: Callable[[dict[str, object]], bool] | None = None,
    ) -> None:
        super().__init__(parent)
        if role not in ("parameter", "derived"):
            raise ValueError("quick variable role must be parameter or derived")
        self._role = role
        self._commit = commit
        self._existing_names = frozenset(existing_names)
        self.setWindowTitle(
            "快速新增 Variable"
            if role == "parameter"
            else "快速新增 Derived Variable"
        )
        self.setMinimumWidth(520)
        root = QVBoxLayout(self)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        root.addLayout(form)

        self.name_edit = variable_name_edit(self)
        self.name_edit.setPlaceholderText("例如 lid_width 或 half_lid_width")
        base_name = "new_variable" if role == "parameter" else "derived_value"
        suggested_name = base_name
        suffix = 2
        while suggested_name in self._existing_names:
            suggested_name = f"{base_name}_{suffix}"
            suffix += 1
        self.name_edit.setText(suggested_name)
        form.addRow("Name", self.name_edit)

        self.dimension_combo = QComboBox(self)
        self.dimension_combo.addItem("Length（长度）", "length")
        self.dimension_combo.addItem("Dimensionless（无量纲）", "dimensionless")
        form.addRow("Kind", self.dimension_combo)

        self.unit_combo: QComboBox | None = None
        if role == "parameter":
            self.unit_combo = QComboBox(self)
            form.addRow("Unit", self.unit_combo)
            self.value_edit = _PackageV2ExpressionEdit(self, ("mm", "um"))
            self.value_edit.setToolTip(
                "Length 的裸数字按所选 Unit 解释；Parameter default 不能引用变量。"
            )
            form.addRow("Default", self.value_edit)
        else:
            self.value_edit = _PackageV2ExpressionEdit(
                self,
                tuple(expression_candidates),
            )
            form.addRow("Expression", self.value_edit)

        self.status_label = QLabel(
            "变量校验通过后加入工程草稿；请保存 Source。" if commit else
            "该变量会先暂存在 Geometry 表单中，最终与 Geometry 一起编译提交。",
            self,
        )
        self.status_label.setWordWrap(True)
        root.addWidget(self.status_label)
        self.buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        stage_button = self.buttons.button(QDialogButtonBox.StandardButton.Ok)
        stage_button.setText("添加" if commit else "暂存")
        stage_button.setDefault(True)
        self.buttons.accepted.connect(self._validate_and_accept)
        self.buttons.rejected.connect(self.reject)
        if isinstance(self.value_edit, _PackageV2ExpressionEdit):
            self.value_edit.returnPressed.connect(self._validate_and_accept)
        root.addWidget(self.buttons)
        self.dimension_combo.currentIndexChanged.connect(
            lambda _index: self._refresh_dimension()
        )
        self._refresh_dimension()

    def _refresh_dimension(self) -> None:
        dimension = self.dimension_combo.currentData()
        previous = self.value_edit.text().strip()
        if self.unit_combo is not None:
            self.unit_combo.clear()
            if dimension == "length":
                self.unit_combo.addItems(("mm", "um"))
            else:
                self.unit_combo.addItem("1")
        if dimension == "length":
            if previous in ("", "1"):
                self.value_edit.setText("1mm")
            self.value_edit.setPlaceholderText(
                "例如 250um 或 width / 2"
                if self._role == "derived"
                else "例如 250、250um 或 0.25mm"
            )
        else:
            if previous in ("", "1mm"):
                self.value_edit.setText("1")
            self.value_edit.setPlaceholderText(
                "例如 2 或 width / height"
                if self._role == "derived"
                else "例如 2 或 0.5"
            )

    def _show_error(self, message: str) -> None:
        self.status_label.setStyleSheet("color: #b42318;")
        self.status_label.setText(message)

    def _validate_and_accept(self) -> None:
        name = self.name_edit.text()
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) is None:
            self._show_error(
                "Name 必须以英文字母或下划线开头，且只含字母、数字、下划线。"
            )
            return
        if (
            keyword.iskeyword(name)
            or name.lower() in {"mm", "um", "µm", "μm"}
            or name == "__easymesh_length__"
        ):
            self._show_error(f"Name {name!r} 是保留名称，请换一个名字。")
            return
        if name in self._existing_names:
            self._show_error(f"变量 {name!r} 已经存在。")
            return
        if not self.value_edit.text().strip():
            self._show_error(
                "Default 不能为空。"
                if self._role == "parameter"
                else "Expression 不能为空。"
            )
            return
        if self._commit is None or self._commit(self.variable_record()):
            self.accept()

    def variable_record(self) -> dict[str, object]:
        name = self.name_edit.text()
        dimension = self.dimension_combo.currentData()
        assert isinstance(dimension, str)
        if self._role == "parameter":
            assert self.unit_combo is not None
            unit = self.unit_combo.currentText()
            default = self.value_edit.text().strip()
            if (
                dimension == "length"
                and re.fullmatch(
                    r"[+-]?(?:(?:[0-9]+(?:\.[0-9]*)?)|(?:\.[0-9]+))"
                    r"(?:[eE][+-]?[0-9]+)?",
                    default,
                )
                is not None
            ):
                default = f"{default}{unit}"
            return {
                "name": name,
                "kind": dimension,
                "unit": unit,
                "default": default,
            }
        return {
            "name": name,
            "kind": dimension,
            "expression": self.value_edit.text().strip(),
        }




def _package_v2_mesh_options_summary(strategy, resolved):
    if resolved is None:
        return "尚无实例计算结果"
    length = lambda value: f"{value:.12g} mm"
    target = length(resolved.target_edge_mm)
    transition = length(resolved.transition_distance_mm)
    strategy = deepcopy(dict(strategy))
    for name in ("layer_size", "plane_size", "surface_size", "plane_transition_distance"):
        value = getattr(resolved, name + "_mm")
        if value is not None:
            strategy[name] = length(value)
    strategy["directional_near_edge"] = {
        direction: length(value) for direction, value in resolved.directional_near_edge_mm
        if direction in strategy.get("directional_near_edge", {})
    }
    if resolved.partition_origin_mm is not None:
        strategy["partition_origin"] = [length(value) for value in resolved.partition_origin_mm]
    kind = strategy["kind"]
    short = lambda direction: ("+" if direction.startswith("positive") else "−") + direction[-1].upper()
    if kind == "structured_sweep":
        items = [f"方向：{short(strategy['direction'])}",
                 f"层厚：{strategy.get('layer_size', target)}",
                 f"面内尺寸：{strategy.get('plane_size', '继承边之间自动过渡')}"]
    elif kind == "conformal_hybrid":
        return f"体内尺寸：{target}；表面尺寸：{strategy.get('surface_size', target)}；过渡距离：{transition}"
    else:
        overrides = strategy.get("directional_near_edge", {})
        items = [f"基础尺寸：{target}"]
        items.extend(f"{short(d)}：{overrides[d]}" for d in _PACKAGE_V2_COMPONENT_LOCAL_DIRECTION_TOKENS if d in overrides)
    policy = strategy.get("sizing", {})
    hard = policy.get("constraint", "soft") == "hard"
    items.append("约束：" + ("强" if hard else "弱"))
    origin = policy.get("origin", "custom" if "partition_origin" in strategy else "legacy")
    if origin == "legacy" and "partition_origin" in strategy:
        origin = "custom"
    items.append("Origin：" + (", ".join(strategy["partition_origin"]) if origin == "custom" else ORIGIN_LABELS[origin]))
    if hard:
        items.append(f"余量比例：{policy.get('remainder_ratio', .25):.1%}")
    if kind == "structured_sweep":
        if "plane_size" in strategy:
            items.append(f"面内过渡距离：{strategy.get('plane_transition_distance', '自动')}")
    else:
        items.append(f"过渡距离：{transition}")
    return "；".join(items)








class _PackageV2MeshOptionsDialog(QDialog):
    """Only the selected mesher's free-direction settings are authored here."""
    def __init__(self, parent, *, strategy, target, transition, expression_candidates=()):
        super().__init__(parent)
        self.setWindowTitle("高级网格设置")
        self.resize(560, 400)
        self._strategy = deepcopy(dict(strategy))
        self.kind = strategy["kind"]
        root = QVBoxLayout(self)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        root.addLayout(form)
        self._form = form
        def expression(label, value="", fallback=""):
            edit = _PackageV2ExpressionEdit(self, expression_candidates)
            edit.returnPressed.connect(self._accept_options)
            edit.setText(value)
            edit.setPlaceholderText(fallback)
            form.addRow(label, edit)
            return edit
        self.target_edit = expression("基础尺寸", target)
        self._legacy_transition = transition
        if self.kind != "structured_sweep":
            self.transition_edit = expression("过渡距离", transition)
        self.direction_edits = {}
        if self.kind == "orthogonal_hex":
            for direction in _PACKAGE_V2_COMPONENT_LOCAL_DIRECTION_TOKENS:
                label = ("+" if direction.startswith("positive") else "−") + direction[-1].upper()
                self.direction_edits[direction] = expression(label + " 尺寸", strategy.get("directional_near_edge", {}).get(direction, ""), "留空使用基础尺寸")
        elif self.kind == "structured_sweep":
            self.sweep_combo = QComboBox(self)
            for direction in _PACKAGE_V2_COMPONENT_LOCAL_DIRECTION_TOKENS:
                label = ("+" if direction.startswith("positive") else "−") + direction[-1].upper()
                self.sweep_combo.addItem(label, direction)
            self.sweep_combo.setCurrentIndex(self.sweep_combo.findData(strategy["direction"]))
            form.addRow("扫掠方向", self.sweep_combo)
            self.layer_edit = expression("扫掠层厚", strategy.get("layer_size", ""), "留空使用基础尺寸")
            self.plane_edit = expression("面内目标尺寸", strategy.get("plane_size", ""), "留空：在继承边尺寸之间自动过渡；无继承边时使用基础尺寸")
            self.transition_edit = expression("面内过渡距离", strategy.get("plane_transition_distance", ""), "留空：自动；空间不足时可能达不到目标尺寸")
            self.plane_edit.textChanged.connect(self._update_plane_transition)
            self._update_plane_transition()
        else:
            self.surface_edit = expression("自由表面目标尺寸", strategy.get("surface_size", ""), "留空使用基础尺寸")
        if self.kind != "conformal_hybrid":
            policy = strategy.get("sizing", {})
            self.constraint_combo = QComboBox(self)
            self.constraint_combo.addItem("弱约束：允许调整", "soft")
            self.constraint_combo.addItem("强约束：固定步长，边界收尾", "hard")
            self.constraint_combo.setCurrentIndex(self.constraint_combo.findData(policy.get("constraint", "soft")))
            form.addRow("约束强度", self.constraint_combo)
            self.ratio_spin = QDoubleSpinBox(self)
            self.ratio_spin.setDecimals(3)
            self.ratio_spin.setRange(.001, 1.)
            self.ratio_spin.setSingleStep(.05)
            self.ratio_spin.setValue(policy.get("remainder_ratio", .25))
            form.addRow("余量保留比例", self.ratio_spin)
            self.origin_combo = QComboBox(self)
            for key, label in ORIGIN_LABELS.items():
                self.origin_combo.addItem(label, key)
            mode = policy.get("origin", "custom" if "partition_origin" in strategy else "legacy")
            if mode == "legacy" and "partition_origin" in strategy:
                mode = "custom"
            self.origin_combo.setCurrentIndex(self.origin_combo.findData(mode))
            form.addRow("布种 Origin", self.origin_combo)
            values = strategy.get("partition_origin", ("", "", ""))
            self.origin_edits = tuple(expression("Origin " + axis, value) for axis, value in zip("XYZ", values))
            self.constraint_combo.currentIndexChanged.connect(self._update_fields)
            self.origin_combo.currentIndexChanged.connect(self._update_fields)
            self._update_fields()
        self.status = QLabel("尺寸与 Origin 用于各方向尚无接口约束的部分。", self)
        self.status.setWordWrap(True)
        root.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, self)
        buttons.accepted.connect(self._accept_options)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def _update_plane_transition(self):
        self.transition_edit.setEnabled(bool(self.plane_edit.text().strip()))
        self.transition_edit.setToolTip("仅填写面内目标尺寸时生效；只影响自由截面，不改变继承节点或扫掠层厚。")

    def _update_fields(self):
        self._form.setRowVisible(self.ratio_spin, self.constraint_combo.currentData() == "hard")
        for edit in self.origin_edits:
            self._form.setRowVisible(edit, self.origin_combo.currentData() == "custom")

    def options(self):
        strategy = {"kind": self.kind}
        if self.kind == "conformal_hybrid":
            if self.surface_edit.text().strip():
                strategy["surface_size"] = self.surface_edit.text().strip()
        else:
            strategy["sizing"] = {"constraint": self.constraint_combo.currentData(),
                "remainder_ratio": self.ratio_spin.value(), "origin": self.origin_combo.currentData()}
            if self.origin_combo.currentData() == "custom":
                strategy["partition_origin"] = [edit.text().strip() for edit in self.origin_edits]
            if self.kind == "structured_sweep":
                strategy["direction"] = self.sweep_combo.currentData()
                for key, edit in (("layer_size", self.layer_edit), ("plane_size", self.plane_edit)):
                    if edit.text().strip():
                        strategy[key] = edit.text().strip()
                if self.plane_edit.text().strip() and self.transition_edit.text().strip():
                    strategy["plane_transition_distance"] = self.transition_edit.text().strip()
            else:
                overrides = {d: e.text().strip() for d,e in self.direction_edits.items() if e.text().strip()}
                if overrides:
                    strategy["directional_near_edge"] = overrides
        return dict(strategy=strategy, target_edge=self.target_edit.text().strip(),
                    transition_distance=(self._legacy_transition if self.kind == "structured_sweep"
                        else self.transition_edit.text().strip()))

    def _accept_options(self):
        options = self.options()
        if not options["target_edge"] or not options["transition_distance"]:
            self.status.setText("基础尺寸与过渡距离不能为空。")
            return
        if "partition_origin" in options["strategy"] and not all(options["strategy"]["partition_origin"]):
            self.status.setText("自定义 Origin 的 X、Y、Z 必须全部填写。")
            return
        self.accept()




class _PackageV2SourceDelegate(ExpressionDelegate):
    """Use completion only for cells carrying validated Source candidates."""

    def createEditor(
        self,
        parent: object,
        option: object,
        index: object,
    ) -> object:
        choices = index.data(OWNER_CHOICES_ROLE)
        if choices:
            combo = QComboBox(parent)
            combo.addItems(choices)
            def commit_choice(_index):
                self.commitData.emit(combo)
                self.closeEditor.emit(combo, QAbstractItemDelegate.EndEditHint.SubmitModelCache)
            combo.activated.connect(commit_choice)
            return combo
        if not index.data(Qt.ItemDataRole.UserRole):
            return None
        pointer = index.data(Qt.ItemDataRole.UserRole)
        if isinstance(pointer, str) and pointer.startswith("/globals/") and pointer.endswith("/name"):
            return variable_name_edit(parent)
        raw = index.data(_PACKAGE_V2_COMPLETION_ROLE)  # type: ignore[attr-defined]
        if isinstance(raw, (tuple, list)) and raw:
            candidates = tuple(
                dict.fromkeys(str(value) for value in raw if str(value))
            )
            if candidates:
                return _PackageV2ExpressionEdit(parent, candidates)
        return super().createEditor(parent, option, index)  # type: ignore[arg-type]

    def setEditorData(self, editor, index):
        if isinstance(editor, QComboBox):
            editor.setCurrentText(index.data(Qt.ItemDataRole.DisplayRole))
        else:
            super().setEditorData(editor, index)

    def setModelData(self, editor, model, index):
        if isinstance(editor, QComboBox):
            # Defer until Qt has closed the editor; the commit rebuilds the tree.
            tree = self.parent()
            item = tree.itemFromIndex(index)
            template_id = item.data(0, TEMPLATE_ROLE)
            geometry_id = item.data(0, GEOMETRY_ROLE)
            component_id = editor.currentText()
            if component_id != index.data(Qt.ItemDataRole.DisplayRole):
                tree.moveRequested.emit(
                    template_id, geometry_id, component_id,
                )
        else:
            super().setModelData(editor, model, index)



@dataclass(frozen=True, slots=True)
class _LayoutReportIdentity:
    """Semantic layout inputs that one worker report must reproduce exactly."""

    source: Path
    far_field_um: float
    transition_um: float
    bounds_mm: tuple[float, float, float, float]
    templates: tuple[tuple[str, Path], ...]
    instances: tuple[tuple[float, float, str], ...]
    structured_regions: tuple[
        tuple[float, float, float, float, float, float], ...
    ]
    z_levels_mm: tuple[float, ...] | None
    void_slab_intervals_mm: tuple[tuple[float, float], ...] | None
    template_slab_components: tuple[str, ...]
    transition_slab_components: tuple[str, ...]
    template_slab_materials: tuple[str, ...]
    transition_slab_materials: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class _CdbJobIdentity:
    """Input and options that one MSH→CDB worker must reproduce."""

    source: Path
    output: Path
    element_type: int
    coordinate_scale: float
    units_label: str | None
    source_signature: tuple[int, int, int]


@dataclass(frozen=True, slots=True)
class _PackageV2GuiIdentity:
    """Immutable Job evidence rendered and launched by the Package V2 page."""

    request_path: Path
    request_signature: tuple[int, int, int]
    request_transport_sha256: str
    request_sha256: str
    launch_identity_sha256: str
    raw_source_sha256: str
    plan_sha256: str
    job_id: str
    output: Path
    source_name: str


@dataclass(slots=True)
class _PackageV2RunState:
    """Ephemeral GUI state for one Package V2 worker invocation."""

    progress_path: Path
    run_id: str
    job_id: str
    request_sha256: str
    started_at: float
    progress_offset: int = 0
    progress_buffer: bytes = b""
    log_offset: int = 0
    last_sequence: int = 0
    cancel_requested: bool = False
    cancel_deadline: float | None = None


@dataclass(frozen=True, slots=True)
class _ValidatedLayoutReport:
    quality: Mapping[str, object]
    parameters: Mapping[str, object]
    expected_mesh: Path
    checks: tuple[tuple[str, bool], ...]
    native_ring_preserved: bool

    @property
    def all_checks_pass(self) -> bool:
        return self.native_ring_preserved and all(
            passed for _label, passed in self.checks
        )


def _value(item: object, name: str, default: Any = None) -> Any:
    """Read a section-model field from either a dataclass/object or a mapping."""

    if isinstance(item, Mapping):
        return item.get(name, default)
    return getattr(item, name, default)


def _items(value: object | None) -> tuple[object, ...]:
    if value is None or isinstance(value, (str, bytes)):
        return ()
    try:
        return tuple(value)  # type: ignore[arg-type]
    except TypeError:
        return ()


class ConcentricMeshApp(QMainWindow, Ui_MainWindow):
    def __init__(self) -> None:
        super().__init__()
        install_tab_key_policy()
        self._project_path: Path | None = None
        self._clean_project_document: dict[str, Any] | None = None
        self._loading_project = True
        self._base_window_title = "EasyMesh"
        self._jobs: list[tuple[subprocess.Popen[str], Path, Path, bool]] = []
        # Keep the public/private 4-tuple job shape for compatibility, while
        # routing each subprocess to the status area of the tab that launched
        # it.  Jobs inserted by legacy callers default to the Layer tab.
        self._job_kinds: dict[int, str] = {}
        self._job_report_snapshots: dict[
            int, tuple[int, int, int] | None
        ] = {}
        self._job_layout_settings: dict[
            int, tuple[Path, Path, float, float, int]
        ] = {}
        self._job_layout_dependencies: dict[
            int, dict[Path, tuple[int, int, int]]
        ] = {}
        self._job_layout_report_identities: dict[int, _LayoutReportIdentity] = {}
        self._job_cdb_identities: dict[int, _CdbJobIdentity] = {}
        self._job_package_v2_identities: dict[
            int, _PackageV2GuiIdentity
        ] = {}
        self._package_v2_runs: dict[int, _PackageV2RunState] = {}
        self._job_layer_parameters: dict[
            int, AxisymmetricMeshParameters
        ] = {}
        self._job_ids: dict[int, str] = {}
        self._job_project_snapshots: dict[
            int,
            tuple[
                Path,
                dict[str, Any],
                tuple[int, int, int] | None,
            ],
        ] = {}
        self._job_project_publication_deferred: set[int] = set()
        self._job_project_artifact_stale: set[int] = set()
        self._job_report_validation: dict[int, bool] = {}
        self._job_config_snapshots: dict[int, Path] = {}
        # A report may contain a shape warning, an aspect-ratio advisory, or
        # both.  Track the report rather than the message kind so a running
        # preview never opens a second dialog when the worker exits later.
        self._quality_warning_reports: set[Path] = set()
        self._loading_layer_text = False
        self._layer_mesh_path: Path | None = None
        self._clean_layer_mesh_state = None
        self._saved_layer_path: Path | None = None
        self._saved_layer_text: str | None = None
        self._layer_file_modified = False
        self._section_plan: SectionPlan | None = None
        self._focused_z_key = None
        self._focused_r_key = None
        self._focused_z_height = None
        self._control_intervals: tuple[MeshControlInterval, ...] = ()
        # Keys come from MeshControlInterval.key and are therefore stable across
        # harmless Layer text edits.  Valid overrides stay numeric, while a
        # separate text map keeps an invalid in-progress edit visible.
        self._local_size_overrides: dict[tuple[str, float, float], float] = {}
        self._local_size_inputs: dict[tuple[str, float, float], str] = {}
        self._interval_sweep_policies = {}
        self._updating_control_tables = False
        self._control_override_errors: tuple[str, ...] = ()
        self._bump_layout: BumpLayout | None = None
        self._loaded_layout_source: Path | None = None
        self._layout_template_meshes: dict[str, SampleMesh] = {}
        self._layout_template_details_loaded = False
        self._layout_template_inspection_attempted = False
        self._layout_validation_error: str | None = None
        self._layout_template_slab_components: tuple[str, ...] = ()
        self._layout_template_slab_materials: tuple[str, ...] = ()
        self._layout_template_z_levels_mm: tuple[float, ...] = ()
        self._layout_void_slab_intervals_mm: tuple[tuple[float, float], ...] = ()
        self._layout_material_inputs: dict[str, str] = {}
        self._updating_layout_material_tables = False
        self._loading_layout_path = False
        self._layout_source_revision = 0
        self._layout_dependency_signatures: dict[Path, tuple[int, int, int]] = {}
        self._rendered_layout_report_settings: (
            tuple[
                Path,
                Path,
                float,
                float,
                int,
                tuple[str, ...],
                tuple[str, ...],
                tuple[str, ...],
                tuple[str, ...],
            ]
            | None
        ) = None
        self._rendered_cdb_identity: _CdbJobIdentity | None = None
        self._package_v2_identity: _PackageV2GuiIdentity | None = None
        self._package_v2_ready_identity: _PackageV2GuiIdentity | None = None
        self._package_v2_project_snapshot: PackageV2ProjectSnapshot | None = None
        self._clean_package_v2_job_path = ""
        self._package_v2_artifact_state_dirty = False
        self._loading_package_v2_path = False
        self._package_v2_source_editor: PackageV2SourceEditor | None = None
        self._package_v2_frozen_dialog: FrozenMeshInstanceDialog | None = None
        self._package_v2_authoring_dialog: QDialog | None = None
        self._package_v2_pending_source_edits: dict[str, str] = {}
        self._package_v2_pending_source_text: str | None = None
        self._package_v2_pending_source_warning: str | None = None
        self._updating_package_v2_source_tables = False
        self._package_v2_job_stale = False
        self._package_v2_preview_keys_by_instance: dict[str, tuple[str, ...]] = {}
        self._package_v2_preview_selection_table: QTableWidget | QTreeWidget | None = None
        self._active_job_outputs: set[Path] = set()
        self._active_job_kinds: set[str] = set()
        self._contact_process = None
        self._contact_output_buffer = b""
        self._contact_generation = 0
        self._contact_request = None
        self._contact_digest = None
        self._contact_artifact_paths = ()
        self._contact_artifact_signature = ()
        self._contact_timer = QTimer(self)
        self._contact_timer.setSingleShot(True)
        self._contact_timer.setInterval(400)
        self._contact_timer.timeout.connect(self._start_contact_preview)
        self._contact_watch = QTimer(self)
        self._contact_watch.setInterval(1000)
        self._contact_watch.timeout.connect(self._watch_contact_inputs)
        self._contact_watch.start()

        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(500)
        self._poll_timer.timeout.connect(self._poll_jobs)
        self._section_timer = QTimer(self)
        self._section_timer.setSingleShot(True)
        self._section_timer.setInterval(250)
        self._section_timer.timeout.connect(self._refresh_section_preview)

        self.setupUi(self)
        self._configure_runtime_widgets()
        self._connect_signals()
        self._refresh_derived()
        self._load_layer_file(show_error=False)
        if self.layout_path_edit.text().strip():
            self._load_layout_file(show_error=False, inspect_templates=False)
        else:
            self.layout_status_label.setStyleSheet(self._semantic_style("muted"))
            self.layout_status_label.setText(
                "请选择包含模板路径和 bump 坐标的 .loc 布局文件。"
            )
        self._base_window_title = self.windowTitle()
        self._loading_project = False
        self._set_project_path(None)
        self._mark_project_clean()

    def _configure_runtime_widgets(self) -> None:
        """Apply runtime-only values that do not belong in the Designer form."""

        for index, value in enumerate(("soft", "hard")):
            self.z_constraint_combo.setItemData(index, value)
        for index, value in enumerate(("negative_z", "positive_z", "both_z")):
            self.z_seed_direction_combo.setItemData(index, value)
        self.z_center_merge_ratio_spin.setMinimum(self.z_merge_ratio_spin.value())
        self.z_merge_ratio_spin.valueChanged.connect(
            self.z_center_merge_ratio_spin.setMinimum
        )
        self.z_control_table = self.zControlTable
        self.mesh_preview_splitter.setStretchFactor(0, 1)
        self.mesh_preview_splitter.setStretchFactor(1, 1)
        self.mesh_preview_splitter.setSizes([500, 500])
        self.radial_control_table = self.radialControlTable
        self.r_control_table = self.radial_control_table
        self.radial_control_table.setItemDelegate(_InheritedPlaneSizeDelegate(self.radial_control_table))

        documents_location = QStandardPaths.writableLocation(
            QStandardPaths.StandardLocation.DocumentsLocation
        )
        self._workspace_root = prepare_runtime_workspace(
            runtime_workspace_root(documents_location=documents_location or None)
        )
        examples_root = self._workspace_root / "examples"
        output_root = self._workspace_root / "output"
        self.layer_path_edit.setText(str(examples_root / "bumpcell.layer"))
        self.output_edit.setText(str(output_root / "concentric_demo.msh"))
        default_layout = examples_root / "bumps.loc"
        self.layout_path_edit.setText(
            str(default_layout) if default_layout.is_file() else ""
        )
        self.layout_output_edit.setText(str(output_root / "bumps_connected.msh"))

        fixed_font = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        self.layer_editor.setFont(fixed_font)
        self.layout_source_view.setFont(fixed_font)
        self.cdb_report_view.setFont(fixed_font)
        self.package_v2_source_view.setFont(fixed_font)
        self.package_v2_report_view.setFont(fixed_font)
        self.package_v2_log_view.setFont(fixed_font)
        self.package_v2_log_view.document().setMaximumBlockCount(600)
        self.package_v2_progress_bar.setRange(
            0, PACKAGE_V2_PROGRESS_PHASE_COUNT
        )
        self.package_v2_progress_bar.setValue(0)
        self.package_v2_progress_bar.setFormat("等待执行")
        self.status_bar.addPermanentWidget(self.package_v2_activity_box, 1)
        self.package_v2_progress_bar.setFixedWidth(180)
        self.package_v2_progress_bar.setMaximumHeight(20)
        self.package_v2_phase_label.setMinimumWidth(150)
        self.package_v2_phase_label.setMaximumWidth(270)
        for label in (self.package_v2_phase_label, self.package_v2_detail_label):
            label.setWordWrap(False)
        self.package_v2_phase_label.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        self.package_v2_detail_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.package_v2_activity_layout.setStretch(1, 1)
        self.cdb_element_type_combo.setItemData(0, 185)
        self.cdb_element_type_combo.setItemData(1, 186)

        resize_to_contents = QHeaderView.ResizeMode.ResizeToContents
        stretch = QHeaderView.ResizeMode.Stretch
        table_modes = (
            (
                self.z_control_table,
                (
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                ),
            ),
            (
                self.radial_control_table,
                (resize_to_contents,) * 3 + (stretch, stretch, resize_to_contents),
            ),
            (
                self.layout_placement_table,
                (
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                    resize_to_contents,
                ),
            ),
            (
                self.layout_template_table,
                (
                    resize_to_contents,
                    stretch,
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                ),
            ),
            (
                self.layout_structured_region_table,
                (
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                    stretch,
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                ),
            ),
            (self.layout_material_mapping_table, (stretch, stretch)),
            (
                self.layout_component_table,
                (
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                    stretch,
                    stretch,
                    stretch,
                ),
            ),
            (
                self.package_v2_variables_table,
                (
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                ),
            ),
            (
                self.package_v2_mesh_table,
                (resize_to_contents,) * 6,
            ),
            (
                self.package_v2_frozen_table,
                (
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                    stretch,
                    stretch,
                    stretch,
                    stretch,
                    resize_to_contents,
                ),
            ),
            (
                self.package_v2_interfaces_table,
                (
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    resize_to_contents,
                    stretch,
                ),
            ),
        )
        for table, modes in table_modes:
            header = table.horizontalHeader()
            for column, mode in enumerate(modes):
                header.setSectionResizeMode(column, mode)

        for table in (self.package_v2_variables_table,
                      self.package_v2_mesh_table, self.package_v2_frozen_table,
                      self.package_v2_interfaces_table):
            table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
            table.setWordWrap(False)
            table.horizontalHeader().setStretchLastSection(False)
            table.horizontalHeader().setSectionResizeMode(resize_to_contents)
            table.horizontalHeader().setResizeContentsPrecision(-1)
        geometry = self.package_v2_geometry_tree
        geometry.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        geometry.header().setStretchLastSection(False)
        geometry.header().setSectionResizeMode(resize_to_contents)
        geometry.header().setMinimumSectionSize(100)
        geometry.header().setResizeContentsPrecision(-1)
        self.package_v2_contacts_json.setLineWrapMode(self.package_v2_contacts_json.LineWrapMode.NoWrap)

        splitter_settings = (
            (self.layer_splitter, (0, 1), (430, 900)),
            (self.section_controls_splitter, (3, 2), (300, 240)),
            (self.layout_splitter, (4, 6), (500, 820)),
            (
                self.layout_details_splitter,
                (3, 2, 4, 2),
                (260, 180, 360, 180),
            ),
            (self.cdb_splitter, (4, 6), (500, 820)),
            (self.package_v2_splitter, (2, 3), (520, 780)),
            (self.package_v2_input_splitter, (1,), (700,)),
        )
        for splitter, factors, sizes in splitter_settings:
            for index, factor in enumerate(factors):
                splitter.setStretchFactor(index, factor)
            splitter.setSizes(list(sizes))
        screen = QApplication.primaryScreen()
        if screen is not None:
            available = screen.availableGeometry().size()
            minimum_width = min(960, max(760, available.width()))
            minimum_height = min(640, max(560, available.height()))
            self.setMinimumSize(minimum_width, minimum_height)
            self.resize(
                min(1420, max(minimum_width, int(available.width() * 0.94))),
                min(880, max(minimum_height, int(available.height() * 0.90))),
            )

    def _workspace_path(self, value: str | Path) -> Path:
        """Resolve a user-entered path without depending on process CWD."""

        path = Path(value).expanduser()
        if not path.is_absolute():
            path = self._workspace_root / path
        return path.resolve()

    def _semantic_style(self, tone: str) -> str:
        """Return an accessible status color for the active system palette."""

        dark_theme = (
            self.palette().color(QPalette.ColorRole.Window).lightness() < 128
        )
        colors = {
            "error": ("#b42318", "#ff8a80"),
            "success": ("#287a3d", "#7ee787"),
            "warning": ("#805500", "#ffd166"),
            "muted": ("#52606d", "#b7c4ce"),
        }
        try:
            light, dark = colors[tone]
        except KeyError as exc:
            raise ValueError(f"unknown semantic color: {tone}") from exc
        return f"color: {dark if dark_theme else light};"

    def _workspace_mesh_output(self, value: str | Path) -> Path:
        return normalized_mesh_output(self._workspace_path(value))

    def _workspace_cdb_output(self, value: str | Path) -> Path:
        return normalized_cdb_output(self._workspace_path(value))

    def _active_project_tab_name(self) -> str:
        current = self.main_tabs.currentWidget()
        if current is self.layout_tab:
            return "layout"
        if current is self.cdb_tab:
            return "cdb"
        if current is self.package_v2_tab:
            return "package_v2"
        return "layer"

    def _refresh_layer_mesh_file_status(self):
        path = self._layer_mesh_path
        if path is None:
            self.layer_mesh_file_label.setText("网格方案未保存")
            return
        dirty = self._current_layer_mesh_state() != self._clean_layer_mesh_state
        self.layer_mesh_file_label.setText(f"{path.name} · {'未保存修改' if dirty else '已保存'}")
        self.layer_mesh_file_label.setToolTip(str(path))

    def _save_layer_mesh_settings_to_path(self, path):
        try:
            if self._section_timer.isActive():
                self._section_timer.stop()
                self._refresh_section_preview()
            state = self._current_layer_mesh_state()
            portable = dict(state)
            for key in ("source_path", "output_path"):
                if portable[key].strip():
                    portable[key] = str(self._workspace_path(portable[key]))
            saved = save_layer_mesh_state(path, portable)
        except (OSError, ValueError, TypeError) as exc:
            QMessageBox.critical(self, "网格方案保存失败", str(exc))
            return False
        self._layer_mesh_path = saved
        self._clean_layer_mesh_state = state
        self._refresh_project_modified()
        self.statusBar().showMessage(f"网格方案已保存：{saved}", 6000)
        return True

    def _save_layer_mesh_settings(self, _checked=False):
        if self._layer_mesh_path is None:
            return self._save_layer_mesh_settings_as()
        return self._save_layer_mesh_settings_to_path(self._layer_mesh_path)

    def _save_layer_mesh_settings_as(self, _checked=False):
        initial = self._layer_mesh_path
        if initial is None:
            source = self._workspace_path(self.layer_path_edit.text() or "layer.layer")
            initial = source.with_name(source.stem + LAYER_MESH_SUFFIX)
        selected, _filter = QFileDialog.getSaveFileName(
            self, "保存 Layer 网格方案", str(initial), LAYER_MESH_FILTER)
        return bool(selected) and self._save_layer_mesh_settings_to_path(selected)

    def _open_layer_mesh_settings(self, _checked=False):
        initial = self._layer_mesh_path or self._workspace_path(self.layer_path_edit.text() or ".")
        selected, _filter = QFileDialog.getOpenFileName(
            self, "载入 Layer 网格方案", str(initial), LAYER_MESH_FILTER)
        if not selected:
            return False
        try:
            state = load_layer_mesh_state(selected)
        except (OSError, ValueError, TypeError) as exc:
            QMessageBox.critical(self, "网格方案载入失败", str(exc))
            return False
        baseline = self._clean_layer_mesh_state
        if baseline is None and self._clean_project_document is not None:
            baseline = self._clean_project_document["layer"]
        if baseline is not None and self._current_layer_mesh_state() != baseline:
            answer = QMessageBox.warning(
                self, "当前网格方案有未保存修改",
                "载入方案将替换当前 Layer 定义和网格设置。是否先保存当前方案？",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Save)
            if answer == QMessageBox.StandardButton.Cancel:
                return False
            if answer == QMessageBox.StandardButton.Save and not self._save_layer_mesh_settings():
                return False
        self._apply_layer_mesh_state(state)
        self._layer_mesh_path = Path(selected).expanduser().resolve()
        self._clean_layer_mesh_state = self._current_layer_mesh_state()
        self.main_tabs.setCurrentWidget(self.layer_tab)
        self.layer_config_tabs.setCurrentWidget(self.mesh_settings_tab)
        self._refresh_project_modified()
        self.statusBar().showMessage(f"网格方案已载入：{self._layer_mesh_path}", 6000)
        return True

    def _current_layer_mesh_state(self):
        local_size_inputs = []
        for (axis, start_um, end_um), value in sorted(
            self._local_size_inputs.items(),
            key=lambda item: (str(item[0][0]), item[0][1], item[0][2]),
        ):
            axis_text = axis.value if isinstance(axis, ControlAxis) else str(axis)
            local_size_inputs.append(
                {
                    "axis": axis_text,
                    "start_um": start_um,
                    "end_um": end_um,
                    "text": value,
                }
            )

        return validate_layer_mesh_state({
            "source_path": self.layer_path_edit.text(),
            "source_text": self.layer_editor.toPlainText(),
            "target_xy_text": self.xy_size_edit.text(),
            "target_angular_text": self.angular_size_edit.text(),
            "target_z_text": self.z_size_edit.text(),
            "z_sweep": self._z_sweep_policy().to_dict(),
            "z_sweep_overrides": [item.to_dict() for item in self._sweep_overrides(ControlAxis.Z)],
            "radial_sweep_overrides": [item.to_dict() for item in self._sweep_overrides(ControlAxis.RADIAL)],
            "symmetry_mode": (
                "xy"
                if self.xy_symmetry_only_checkbox.isChecked()
                else "xy_45"
            ),
            "output_path": self.output_edit.text(),
            "local_size_inputs": local_size_inputs,
        })

    def _current_project_document(
        self,
        *,
        active_tab: str | None = None,
    ) -> dict[str, Any]:
        """Capture raw editable state without serializing derived/runtime data."""

        requested_tab = active_tab or self._active_project_tab_name()
        legacy_tab = "layer" if requested_tab == "package_v2" else requested_tab
        return validate_project_document(
            {
                "schema": PROJECT_SCHEMA,
                "active_tab": legacy_tab,
                "layer": self._current_layer_mesh_state(),
                "layout": {
                    "source_path": self.layout_path_edit.text(),
                    "source_text": self.layout_source_view.toPlainText(),
                    "far_field_size_text": self.far_field_size_edit.text(),
                    "transition_distance_text": (
                        self.transition_distance_edit.text()
                    ),
                    "output_path": self.layout_output_edit.text(),
                    "material_inputs": dict(self._layout_material_inputs),
                },
                "cdb": {
                    "input_path": self.cdb_input_edit.text(),
                    "output_path": self.cdb_output_edit.text(),
                    "element_type": self._selected_cdb_element_type(),
                    "coordinate_scale_text": (
                        self.cdb_coordinate_scale_edit.text()
                    ),
                    "units": self.cdb_units_combo.currentText().strip().upper(),
                },
            }
        )

    @staticmethod
    def _project_content_for_dirty(document: Mapping[str, object]) -> dict[str, object]:
        """Exclude the selected tab so merely browsing the UI stays clean."""

        content = {**document, "active_tab": "layer"}
        content.pop("export", None)
        return content

    def _refresh_project_modified(self, *_args: object) -> None:
        if self._loading_project:
            return
        self._refresh_layer_mesh_file_status()
        if self._clean_project_document is None:
            self.setWindowModified(True)
            return
        try:
            current = self._current_project_document()
        except (TypeError, ValueError):
            self.setWindowModified(True)
            return
        # Without a bound whole-project file, a saved standalone scheme fully
        # accounts for Layer changes; other tabs retain their own dirty state.
        if self._project_path is None and current["layer"] == self._clean_layer_mesh_state:
            current = {**current, "layer": self._clean_project_document["layer"]}
        legacy_modified = (
            self._project_content_for_dirty(current)
            != self._project_content_for_dirty(self._clean_project_document)
        )
        package_modified = (
            self.package_v2_job_path_edit.text().strip()
            != self._clean_package_v2_job_path
        ) or self._package_v2_artifact_state_dirty or bool(
            self._package_v2_source_editor
            and (
                self._package_v2_source_editor.dirty
                or self._package_v2_job_stale
                or bool(self._package_v2_pending_source_edits)
            )
        )
        self.setWindowModified(legacy_modified or package_modified)

    def _set_project_path(self, path: Path | None) -> None:
        self._project_path = None if path is None else path.expanduser().resolve()
        self.setWindowFilePath(
            "" if self._project_path is None else str(self._project_path)
        )
        project_name = (
            "未命名工程"
            if self._project_path is None
            else self._project_path.name
        )
        self.setWindowTitle(f"{project_name}[*] — {self._base_window_title}")

    def _mark_project_clean(self) -> None:
        self._clean_project_document = self._current_project_document()
        self._clean_package_v2_job_path = (
            self.package_v2_job_path_edit.text().strip()
        )
        self._package_v2_artifact_state_dirty = False
        self.setWindowModified(False)

    def _default_project_path(self) -> Path:
        if self._project_path is not None:
            return self._project_path
        active_tab = self._active_project_tab_name()
        if active_tab == "package_v2":
            raw_job = self.package_v2_job_path_edit.text().strip()
            if raw_job:
                job = self._workspace_path(raw_job)
                return job.with_name(job.stem + PROJECT_SUFFIX)
            return self._workspace_root / f"Package-V2-project{PROJECT_SUFFIX}"
        raw_output = {
            "layer": self.output_edit.text().strip(),
            "layout": self.layout_output_edit.text().strip(),
            "cdb": self.cdb_output_edit.text().strip(),
        }[active_tab]
        if raw_output:
            return project_path_for_output(self._workspace_path(raw_output))
        return self._workspace_root / f"EasyMesh-project{PROJECT_SUFFIX}"

    @staticmethod
    def _package_v2_source_path(
        request: PackageV2JobRequest,
        job_path: Path,
    ) -> Path | None:
        raw = request.source_name
        if raw.startswith("<") and raw.endswith(">"):
            return None
        source = Path(raw).expanduser()
        if source.is_absolute():
            return source.resolve()
        if request.source_root is not None:
            return (Path(request.source_root) / source).resolve()
        return (job_path.parent / source).resolve()

    @staticmethod
    def _regular_file_matches_bytes(path: Path, expected: bytes) -> bool:
        flags = os.O_RDONLY
        for name in ("O_BINARY", "O_CLOEXEC", "O_NONBLOCK"):
            flags |= int(getattr(os, name, 0))
        try:
            descriptor = os.open(path, flags)
        except OSError:
            return False
        try:
            information = os.fstat(descriptor)
            if (
                not stat.S_ISREG(information.st_mode)
                or information.st_size != len(expected)
            ):
                return False
            chunks: list[bytes] = []
            remaining = len(expected) + 1
            while remaining:
                chunk = os.read(descriptor, min(1024 * 1024, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
            return b"".join(chunks) == expected
        finally:
            os.close(descriptor)

    def _package_v2_artifact_state_for_project(
        self,
        project_path: Path,
        job_bytes: bytes,
        output: Path,
    ) -> dict[str, object] | None:
        report = output.with_suffix(".report.json")
        if not report.is_file():
            return None
        cdb: Path | None = None
        try:
            cdb_input = self._workspace_path(self.cdb_input_edit.text().strip())
            candidate = self._workspace_path(self.cdb_output_edit.text().strip())
        except (OSError, RuntimeError, ValueError):
            pass
        else:
            if cdb_input == output and candidate.is_file():
                cdb = candidate
        try:
            return build_package_v2_artifact_state(
                project_path,
                job_bytes,
                report,
                cdb_path=cdb,
            )
        except (OSError, RuntimeError, TypeError, ValueError):
            if cdb is None:
                return None
            try:
                return build_package_v2_artifact_state(
                    project_path,
                    job_bytes,
                    report,
                )
            except (OSError, RuntimeError, TypeError, ValueError):
                return None

    def _write_current_project(
        self,
        path: str | Path,
        *,
        make_current: bool,
    ) -> bool:
        editor = self._package_v2_source_editor
        if editor is not None and (
            editor.dirty or self._package_v2_pending_source_edits
        ):
            message = (
                "Package V2 Source 有未保存或尚未联合通过的修改；"
                "工程保存已拒绝，请先完成并保存 Source。"
            )
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("error")
            )
            self.package_v2_status_label.setText(message)
            self._set_package_v2_source_state(message, tone="error")
            return False
        if self._package_v2_job_stale and editor is not None:
            message = (
                "Package V2 Job 与当前 Source 不一致；"
                "工程保存已拒绝，请重新创建 Job。"
            )
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("error")
            )
            self.package_v2_status_label.setText(message)
            self._set_package_v2_source_state(message, tone="error")
            return False
        try:
            document = self._current_project_document()
            raw_job = self.package_v2_job_path_edit.text().strip()
            if raw_job:
                project_path = normalized_project_path(path)
                preserved = self._package_v2_project_snapshot
                use_preserved = False
                if preserved is not None:
                    try:
                        displayed_job = self._workspace_path(raw_job)
                    except (OSError, RuntimeError, ValueError):
                        displayed_job = None
                    inspected = self._package_v2_identity
                    use_preserved = (
                        displayed_job == preserved.job_path
                        and (
                            inspected is None
                            or not self._package_v2_identity_is_current(
                                inspected
                            )
                        )
                    )
                if use_preserved:
                    assert preserved is not None
                    request = preserved.job_request
                    job_bytes = preserved.job_bytes
                    job_path = project_path.parent / preserved.job_relative_path
                    source_bytes = preserved.source_bytes
                    source_path = (
                        None
                        if preserved.source_relative_path is None
                        else project_path.parent
                        / preserved.source_relative_path
                    )
                    output = Path(request.output_mesh_path).resolve()
                else:
                    identity, request, job_bytes, _compiled = (
                        self._load_package_v2_job()
                    )
                    job_path = identity.request_path
                    output = identity.output
                    source_path = self._package_v2_source_path(
                        request,
                        identity.request_path,
                    )
                    source_bytes = request.source_text.encode("utf-8")
                if source_path is not None and not source_path.is_relative_to(
                    project_path.parent
                ):
                    source_path = None
                if (
                    not use_preserved
                    and source_path is not None
                    and not self._regular_file_matches_bytes(
                        source_path,
                        source_bytes,
                    )
                ):
                    source_path = None
                artifact_state = self._package_v2_artifact_state_for_project(
                    project_path,
                    job_bytes,
                    output,
                )
                snapshot = save_package_v2_project_snapshot(
                    project_path,
                    document,
                    source_path=source_path,
                    source_bytes=source_bytes,
                    job_path=job_path,
                    job_bytes=job_bytes,
                    artifact_state=artifact_state,
                    active_tab=self._active_project_tab_name(),
                )
                saved_path = snapshot.project_path
                self._package_v2_project_snapshot = snapshot
            else:
                saved_path = save_project_document(path, document)
                self._package_v2_project_snapshot = None
        except (OSError, UnicodeError, TypeError, ValueError) as exc:
            QMessageBox.critical(self, "工程保存失败", f"无法保存工程：\n{exc}")
            return False

        if make_current:
            self._set_project_path(saved_path)
            self._clean_project_document = document
            self._clean_package_v2_job_path = (
                self.package_v2_job_path_edit.text().strip()
            )
            self._package_v2_artifact_state_dirty = False
            self.setWindowModified(False)
        return True

    def _save_project(self, _checked: bool = False) -> bool:
        del _checked
        if self._project_path is None:
            return self._save_project_as()
        return self._write_current_project(self._project_path, make_current=True)

    def _save_project_as(self, _checked: bool = False) -> bool:
        del _checked
        selected, _filter = QFileDialog.getSaveFileName(
            self,
            "保存 EasyMesh 工程",
            str(self._default_project_path()),
            PROJECT_FILE_FILTER,
        )
        if not selected:
            return False
        return self._write_current_project(
            normalized_project_path(selected),
            make_current=True,
        )

    def _confirm_replace_modified_project(self) -> bool:
        if not self.isWindowModified():
            return True
        answer = QMessageBox.warning(
            self,
            "当前工程尚未保存",
            "打开其他工程会替换当前页面设置。是否先保存当前工程？",
            (
                QMessageBox.StandardButton.Save
                | QMessageBox.StandardButton.Discard
                | QMessageBox.StandardButton.Cancel
            ),
            QMessageBox.StandardButton.Save,
        )
        if answer == QMessageBox.StandardButton.Cancel:
            return False
        if answer == QMessageBox.StandardButton.Save:
            return self._save_project()
        return answer == QMessageBox.StandardButton.Discard

    def _open_project(self, _checked: bool = False) -> bool:
        del _checked
        initial = (
            self._project_path.parent
            if self._project_path is not None
            else self._workspace_root
        )
        selected, _filter = QFileDialog.getOpenFileName(
            self,
            "打开 EasyMesh 工程",
            str(initial),
            PROJECT_FILE_FILTER,
        )
        if not selected:
            return False
        source = Path(selected).expanduser().resolve()
        if not self._confirm_replace_modified_project():
            return False
        try:
            document = load_project_document(source)
            package_snapshot = (
                load_package_v2_project_snapshot(source)
                if document.get("schema") == PROJECT_V2_SCHEMA
                else None
            )
        except (
            OSError,
            UnicodeError,
            TypeError,
            ValueError,
            json.JSONDecodeError,
        ) as exc:
            QMessageBox.critical(self, "工程打开失败", f"无法读取工程：\n{exc}")
            return False
        try:
            self._apply_project_document(
                document,
                package_snapshot=package_snapshot,
            )
        except (OSError, UnicodeError, TypeError, ValueError) as exc:
            QMessageBox.critical(self, "工程打开失败", f"无法恢复工程设置：\n{exc}")
            return False

        self._set_project_path(source)
        self._mark_project_clean()
        return True

    def _restore_layout_material_inputs(
        self,
        material_inputs: Mapping[str, object],
    ) -> None:
        restored: dict[str, str] = {}
        live_sources_by_key: dict[str, list[str]] = {}
        for live_source in self._ordered_unique(
            self._layout_template_slab_materials
        ):
            lookup_key = unicodedata.normalize("NFKC", live_source).casefold()
            live_sources_by_key.setdefault(lookup_key, []).append(live_source)
        for source_value, target_value in material_inputs.items():
            source = str(source_value)
            target = str(target_value)
            try:
                source = normalize_material_name(
                    source,
                    field_name="project transition material source",
                )
                if target.strip():
                    target = normalize_material_name(
                        target,
                        field_name="project transition material target",
                    )
            except ValueError:
                # Preserve invalid in-progress project text so the normal table
                # validation can explain it without silently discarding input.
                pass
            candidates = live_sources_by_key.get(
                unicodedata.normalize("NFKC", source).casefold(),
                (),
            )
            if len(candidates) == 1:
                source = candidates[0]
            restored[source] = target
        self._layout_material_inputs = restored
        self._updating_layout_material_tables = True
        try:
            for row in range(self.layout_material_mapping_table.rowCount()):
                source_item = self.layout_material_mapping_table.item(row, 0)
                target_item = self.layout_material_mapping_table.item(row, 1)
                if source_item is None or target_item is None:
                    continue
                target_item.setText(
                    self._layout_material_inputs.get(source_item.text(), "")
                )
        finally:
            self._updating_layout_material_tables = False
        self._refresh_layout_material_table_values()
        self._refresh_layout_launch_state()

    def _apply_layer_mesh_state(self, layer):
        layer = validate_layer_mesh_state(layer)
        widgets = (self.layer_path_edit, self.output_edit, self.xy_size_edit, self.angular_size_edit,
                   self.z_size_edit, self.z_constraint_combo, self.z_seed_direction_combo,
                   self.z_merge_ratio_spin, self.z_center_merge_ratio_spin,
                   self.xy_symmetry_only_checkbox, self.layer_editor)
        blocked = [widget.blockSignals(True) for widget in widgets]
        try:
            self._section_timer.stop()
            self.layer_path_edit.setText(layer["source_path"])
            self.output_edit.setText(layer["output_path"])
            self.xy_size_edit.setText(layer["target_xy_text"])
            self.angular_size_edit.setText(layer["target_angular_text"])
            self.z_size_edit.setText(layer["target_z_text"])
            sweep = layer["z_sweep"]
            self.z_constraint_combo.setCurrentIndex(
                self.z_constraint_combo.findData(sweep["constraint"])
            )
            self.z_seed_direction_combo.setCurrentIndex(
                self.z_seed_direction_combo.findData(sweep["direction"])
            )
            self.z_center_merge_ratio_spin.setMinimum(0.001)
            self.z_merge_ratio_spin.setValue(sweep["remainder_ratio"])
            self.z_center_merge_ratio_spin.setValue(sweep["center_merge_ratio"])
            self.z_center_merge_ratio_spin.setMinimum(sweep["remainder_ratio"])
            self.xy_symmetry_only_checkbox.setChecked(
                layer["symmetry_mode"] == "xy"
            )
            self._local_size_inputs = {
                (
                    item["axis"],
                    float(item["start_um"]),
                    float(item["end_um"]),
                ): item["text"]
                for item in layer["local_size_inputs"]
            }
            self._local_size_overrides.clear()
            self._interval_sweep_policies = {
                item.key: item.policy for item in (
                    *parse_z_sweep_overrides(layer["z_sweep_overrides"]),
                    *parse_radial_sweep_overrides(layer["radial_sweep_overrides"]),
                )
            }
            self._loading_layer_text = True
            try:
                self.layer_editor.setPlainText(layer["source_text"])
            finally:
                self._loading_layer_text = False
        finally:
            for widget, was_blocked in zip(widgets, blocked):
                widget.blockSignals(was_blocked)
        self._update_z_sweep_controls()
        self._sync_layer_file_state_from_disk()
        self._refresh_section_preview()


    def _apply_project_document(
        self,
        document: object,
        *,
        package_snapshot: PackageV2ProjectSnapshot | None = None,
    ) -> None:
        restored = validate_project_document(document)
        if (
            restored["schema"] == PROJECT_V2_SCHEMA
            and package_snapshot is None
        ):
            raise ValueError("Package V2 Project 缺少 replay snapshot。")
        if (
            restored["schema"] == PROJECT_SCHEMA
            and package_snapshot is not None
        ):
            raise ValueError("legacy Project 不能携带 Package V2 snapshot。")
        layer = restored["layer"]
        layout = restored["layout"]
        cdb = restored["cdb"]
        self._layer_mesh_path = None
        self._clean_layer_mesh_state = None
        self._loading_project = True
        try:
            self._apply_layer_mesh_state(layer)

            self.layout_path_edit.setText(layout["source_path"])
            self.far_field_size_edit.setText(layout["far_field_size_text"])
            self.transition_distance_edit.setText(
                layout["transition_distance_text"]
            )
            self.layout_output_edit.setText(layout["output_path"])
            layout_snapshot_mismatch = False
            if layout["source_path"]:
                if layout["source_text"]:
                    try:
                        current_layout_text = self._workspace_path(
                            layout["source_path"]
                        ).read_text(encoding="utf-8-sig")
                    except (OSError, UnicodeError):
                        pass
                    else:
                        layout_snapshot_mismatch = (
                            current_layout_text != layout["source_text"]
                        )
                if layout_snapshot_mismatch:
                    self._set_layout_error(
                        "布局文件在工程快照保存后发生了变化；"
                        "已显示快照内容，请确认后重新载入当前文件。",
                        clear_source=True,
                    )
                else:
                    self._load_layout_file(
                        show_error=False,
                        inspect_templates=True,
                    )
            else:
                self._set_layout_error(
                    "工程中未保存布局文件路径。",
                    clear_source=True,
                )
            if self._loaded_layout_source is None and layout["source_text"]:
                self.layout_source_view.setPlainText(layout["source_text"])
            self._restore_layout_material_inputs(layout["material_inputs"])

            self.cdb_input_edit.setText(cdb["input_path"])
            self.cdb_output_edit.setText(cdb["output_path"])
            element_index = self.cdb_element_type_combo.findData(
                cdb["element_type"]
            )
            if element_index < 0:
                raise ValueError(
                    f"工程中的 CDB 单元类型不受支持：{cdb['element_type']}"
                )
            self.cdb_element_type_combo.setCurrentIndex(element_index)
            self.cdb_coordinate_scale_edit.setText(
                cdb["coordinate_scale_text"]
            )
            units_index = self.cdb_units_combo.findText(cdb["units"])
            if units_index < 0:
                raise ValueError(f"工程中的 CDB 单位不受支持：{cdb['units']}")
            self.cdb_units_combo.setCurrentIndex(units_index)

            self._package_v2_project_snapshot = package_snapshot
            self._package_v2_artifact_state_dirty = False
            if self._package_v2_frozen_dialog is not None:
                self._package_v2_frozen_dialog.reject()
            if self._package_v2_authoring_dialog is not None:
                self._package_v2_authoring_dialog.reject()
            self._clear_package_v2_pending_source_edits()
            self._package_v2_source_editor = None
            self._package_v2_job_stale = False
            self._loading_package_v2_path = True
            try:
                self.package_v2_job_path_edit.setText(
                    ""
                    if package_snapshot is None
                    else str(package_snapshot.job_path)
                )
            finally:
                self._loading_package_v2_path = False
            self._package_v2_identity = None
            self._package_v2_ready_identity = None
            self._clear_package_v2_source_tables()
            self.package_v2_report_view.clear()
            if package_snapshot is not None:
                request = package_snapshot.job_request
                compiled = compile_package_v2(
                    package_snapshot.source_bytes,
                    source_name=request.source_name,
                    source_root=request.source_root,
                )
                if package_snapshot.runtime_job_path is not None:
                    identity = self._inspect_package_v2_job(show_error=False)
                    if identity is None:
                        raise ValueError(
                            "Project V2 的 current Job 无法通过 GUI replay。"
                        )
                else:
                    self._install_package_v2_job_snapshot(
                        request,
                        compiled,
                        label="Project 内嵌 Source 快照",
                    )
                    self.package_v2_status_label.setStyleSheet(
                        self._semantic_style("warning")
                    )
                    self.package_v2_status_label.setText(
                        "Project V2 已恢复嵌入快照，但外部 Job 已陈旧；"
                        "执行保持禁用。\n"
                        f"原因：{package_snapshot.job_stale_reason}"
                    )
                    self.package_v2_report_view.setStyleSheet(
                        self._semantic_style("warning")
                    )
                    self.package_v2_report_view.setPlainText(
                        json.dumps(
                            {
                                "status": "stale_project_snapshot",
                                "job_path": str(package_snapshot.job_path),
                                "reason": package_snapshot.job_stale_reason,
                                "embedded_request_sha256": request.sha256,
                                "embedded_launch_identity_sha256": (
                                    request.launch_identity.sha256
                                ),
                            },
                            ensure_ascii=False,
                            indent=2,
                            sort_keys=True,
                        )
                    )
                artifact_status = package_snapshot.artifact_status
                if artifact_status.recorded and not artifact_status.valid:
                    self.package_v2_status_label.setStyleSheet(
                        self._semantic_style("warning")
                    )
                    self.package_v2_status_label.setText(
                        self.package_v2_status_label.text()
                        + "\n先前 artifact state 已失效："
                        + str(artifact_status.reason)
                    )
                elif artifact_status.valid:
                    self.package_v2_status_label.setText(
                        self.package_v2_status_label.text()
                        + "\nProject 中记录的 mesh/parameters/report 仍与 Job 一致。"
                    )
            else:
                self._set_package_v2_source_state(
                    "未打开可编辑 Source；Job / Project 快照保持只读。",
                    tone="muted",
                )

            tab = {
                "layer": self.layer_tab,
                "layout": self.layout_tab,
                "cdb": self.cdb_tab,
                "package_v2": self.package_v2_tab,
            }[restored["active_tab"]]
            self.main_tabs.setCurrentWidget(tab)
            self._refresh_derived()
            self._refresh_layout_launch_state()
            self._refresh_cdb_launch_state()
            self._refresh_package_v2_launch_state(preserve_status=True)
        finally:
            self._loading_project = False
        self._refresh_project_modified()

    def _queue_export_project(
        self,
        process: subprocess.Popen[str],
        output: Path,
        document: dict[str, Any],
    ) -> None:
        """Retain the launch snapshot until the matching output is verified."""

        project_path = project_path_for_output(output)
        job_id = self._job_ids[id(process)]
        export_document = {
            **document,
            "export": {
                "job_id": job_id,
                "artifact_path": str(output),
            },
        }
        self._job_project_snapshots[id(process)] = (
            project_path,
            export_document,
            self._report_signature(project_path),
        )

    def _publish_job_project(self, process_id: int) -> bool:
        """Publish one verified job snapshot without changing the open project."""

        snapshot = self._job_project_snapshots.get(process_id)
        if snapshot is None:
            return True
        self._job_project_artifact_stale.discard(process_id)
        project_path, document, baseline_signature = snapshot
        next_export = document.get("export")
        if not isinstance(next_export, Mapping):
            self._job_project_snapshots.pop(process_id, None)
            return False
        artifact_path = Path(
            str(next_export.get("artifact_path", ""))
        ).expanduser().resolve()
        lock_acquired = False
        try:
            with exclusive_artifact_lock(artifact_path):
                lock_acquired = True
                if not self._job_artifact_is_current(process_id, artifact_path):
                    self._job_project_snapshots.pop(process_id, None)
                    self._job_project_publication_deferred.discard(process_id)
                    self._job_project_artifact_stale.add(process_id)
                    return False

                if self._report_signature(project_path) != baseline_signature:
                    allow_auto_snapshot_replacement = False
                    try:
                        current_document = load_project_document(project_path)
                        current_export = current_document.get("export")
                        if isinstance(current_export, Mapping):
                            current_artifact = Path(
                                str(current_export.get("artifact_path", ""))
                            ).expanduser().resolve()
                            allow_auto_snapshot_replacement = (
                                current_artifact == artifact_path
                                and project_path_for_output(artifact_path)
                                == project_path
                            )
                    except (
                        OSError,
                        UnicodeError,
                        TypeError,
                        ValueError,
                        json.JSONDecodeError,
                    ):
                        pass
                    if not allow_auto_snapshot_replacement:
                        self._job_project_snapshots.pop(process_id, None)
                        self._job_project_publication_deferred.discard(process_id)
                        QMessageBox.warning(
                            self,
                            "工程快照未覆盖",
                            "网格或 CDB 已生成并通过复核，但目标工程文件在任务期间"
                            "发生了变化，因此未覆盖：\n"
                            f"{project_path}",
                        )
                        return False
                saved_path = save_project_document(project_path, document)
        except RuntimeError as exc:
            if not lock_acquired:
                self._job_project_publication_deferred.add(process_id)
                return False
            self._job_project_snapshots.pop(process_id, None)
            self._job_project_publication_deferred.discard(process_id)
            QMessageBox.warning(
                self,
                "工程快照保存失败",
                "网格或 CDB 已生成并通过复核，但对应工程快照无法保存：\n"
                f"{project_path}\n\n{exc}",
            )
            return False
        except (OSError, UnicodeError, TypeError, ValueError) as exc:
            self._job_project_snapshots.pop(process_id, None)
            self._job_project_publication_deferred.discard(process_id)
            QMessageBox.warning(
                self,
                "工程快照保存失败",
                "网格或 CDB 已生成并通过复核，但对应工程快照无法保存：\n"
                f"{project_path}\n\n{exc}",
            )
            return False
        self._job_project_snapshots.pop(process_id, None)
        self._job_project_publication_deferred.discard(process_id)
        self._job_project_artifact_stale.discard(process_id)
        if self._project_path is not None and saved_path == self._project_path:
            self._clean_project_document = document
            self._refresh_project_modified()
        return True

    def _mesh_job_artifacts_are_verified(
        self,
        process_id: int,
        *,
        kind: str,
        output: Path,
        report_path: Path,
        fresh_report: bool,
    ) -> bool:
        if not fresh_report or not output.is_file():
            return False
        if not self._job_report_id_matches(process_id, report_path):
            return False
        if kind == "layer":
            return self._validate_layer_job_report(
                process_id,
                output,
                report_path,
            )
        if kind != "layout":
            return False
        return self._validate_layout_job_report(
            process_id,
            report_path,
            render=False,
        )

    def _job_artifact_is_current(
        self,
        process_id: int,
        expected_output: Path,
    ) -> bool:
        """Revalidate artifact identity while its cross-process lock is held."""

        job = next(
            (
                (process, output)
                for process, output, _log_path, _preview in self._jobs
                if id(process) == process_id
            ),
            None,
        )
        if job is None:
            return False
        process, output = job
        if output != expected_output:
            return False
        kind = self._job_kinds.get(process_id, "layer")
        report_path = self._report_path_for_job(output, kind)
        if not self._job_report_is_fresh(process, report_path):
            return False
        if not self._job_report_id_matches(process_id, report_path):
            return False
        if kind == "cdb":
            identity = self._job_cdb_identities.get(process_id)
            if identity is None:
                return False
            try:
                self._validate_cdb_report_payload(report_path, identity)
            except (
                OSError,
                UnicodeError,
                ValueError,
                TypeError,
                json.JSONDecodeError,
            ):
                return False
            return True
        return self._mesh_job_artifacts_are_verified(
            process_id,
            kind=kind,
            output=output,
            report_path=report_path,
            fresh_report=True,
        )

    def _validate_layer_job_report(
        self,
        process_id: int,
        output: Path,
        report_path: Path,
    ) -> bool:
        expected = self._job_layer_parameters.get(process_id)
        if expected is None:
            return False
        try:
            payload = json.loads(report_path.read_text(encoding="utf-8"))
            if not isinstance(payload, Mapping):
                raise ValueError("Layer 报告根节点不是对象")
            if payload.get("parameters") != expected.to_dict():
                raise ValueError("Layer 报告参数与 worker 启动快照不一致")
            artifact = payload.get("mesh_artifact")
            if not isinstance(artifact, Mapping):
                raise ValueError("Layer 报告缺少 mesh_artifact")
            artifact_path = artifact.get("path")
            if not isinstance(artifact_path, str):
                raise ValueError("Layer 报告 mesh_artifact.path 无效")
            if Path(artifact_path).expanduser().resolve() != output:
                raise ValueError("Layer 报告 artifact 路径与输出不一致")
            actual_size = output.stat().st_size
            reported_size = artifact.get("size_bytes")
            if (
                isinstance(reported_size, bool)
                or not isinstance(reported_size, int)
                or reported_size != actual_size
            ):
                raise ValueError("Layer MSH 字节数与报告不一致")
            reported_sha = artifact.get("sha256")
            if (
                not isinstance(reported_sha, str)
                or len(reported_sha) != 64
                or self._sha256_file(output) != reported_sha.lower()
            ):
                raise ValueError("Layer MSH SHA-256 与报告不一致")
        except (
            OSError,
            UnicodeError,
            ValueError,
            TypeError,
            json.JSONDecodeError,
        ):
            return False
        return True

    def _job_report_id_matches(self, process_id: int, report_path: Path) -> bool:
        """Bind an output report to the exact GUI worker invocation."""

        expected = self._job_ids.get(process_id)
        if expected is None:
            return True
        try:
            payload = json.loads(report_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            return False
        return isinstance(payload, Mapping) and payload.get("job_id") == expected

    def _publish_ready_job_projects(self) -> None:
        """Best-effort publication for completed artifacts before shutdown."""

        for process, output, _log_path, _preview in tuple(self._jobs):
            process_id = id(process)
            if process_id not in self._job_project_snapshots:
                continue
            kind = self._job_kinds.get(process_id, "layer")
            report_path = self._report_path_for_job(output, kind)
            fresh_report = self._job_report_is_fresh(process, report_path)
            if kind == "cdb":
                identity = self._job_cdb_identities.get(process_id)
                if identity is None or not fresh_report:
                    continue
                try:
                    self._validate_cdb_report_payload(report_path, identity)
                except (
                    OSError,
                    UnicodeError,
                    ValueError,
                    TypeError,
                    json.JSONDecodeError,
                ):
                    continue
                if not self._job_report_id_matches(process_id, report_path):
                    continue
                self._publish_job_project(process_id)
                continue
            if self._mesh_job_artifacts_are_verified(
                process_id,
                kind=kind,
                output=output,
                report_path=report_path,
                fresh_report=fresh_report,
            ):
                self._publish_job_project(process_id)

    def _connect_signals(self) -> None:
        self.layer_mesh_open_button.clicked.connect(self._open_layer_mesh_settings)
        self.layer_mesh_save_button.clicked.connect(self._save_layer_mesh_settings)
        self.layer_mesh_save_as_button.clicked.connect(self._save_layer_mesh_settings_as)
        self.open_project_action.triggered.connect(self._open_project)
        self.save_project_action.triggered.connect(self._save_project)
        self.save_project_as_action.triggered.connect(self._save_project_as)
        for editor in (
            self.xy_size_edit,
            self.angular_size_edit,
            self.z_size_edit,
        ):
            editor.textChanged.connect(self._refresh_derived)
        self.xy_symmetry_only_checkbox.toggled.connect(self._refresh_derived)
        self.z_constraint_combo.currentIndexChanged.connect(self._on_z_sweep_changed)
        self.z_seed_direction_combo.currentIndexChanged.connect(self._on_z_sweep_changed)
        self.z_merge_ratio_spin.valueChanged.connect(self._on_z_sweep_changed)
        self.z_center_merge_ratio_spin.valueChanged.connect(self._on_z_sweep_changed)
        self.output_button.clicked.connect(self._choose_output)
        self.preview_button.clicked.connect(lambda _checked=False: self._launch(preview=True))
        self.generate_button.clicked.connect(lambda _checked=False: self._launch(preview=False))
        self.preview_reset_button.clicked.connect(
            lambda _checked=False: self.section_preview.reset_view()
        )
        self.preview_reset_button.clicked.connect(
            lambda _checked=False: self.planar_mesh_preview.reset_view()
        )
        self.preview_z_mesh_checkbox.toggled.connect(self.section_preview.set_z_mesh_visible)
        self.layer_browse_button.clicked.connect(self._choose_layer_file)
        self.layer_reload_button.clicked.connect(
            lambda _checked=False: self._load_layer_file(confirm_replace=True)
        )
        self.layer_save_button.clicked.connect(self._save_layer_file)
        self.layer_path_edit.returnPressed.connect(
            lambda: self._load_layer_file(confirm_replace=True)
        )
        self.layer_path_edit.textChanged.connect(self._refresh_layer_file_modified)
        self.layer_editor.textChanged.connect(self._schedule_section_refresh)
        self.layer_editor.textChanged.connect(self._refresh_layer_file_modified)
        self.z_control_table.itemChanged.connect(self._on_control_item_changed)
        self.z_control_table.currentItemChanged.connect(self._on_z_interval_current_changed)
        self.z_control_table.cellDoubleClicked.connect(
            lambda _row, _column: self._on_z_interval_current_changed(self.z_control_table.currentItem(), None)
        )
        self.section_preview.z_interval_activated.connect(self._on_section_z_interval_activated)
        self.radial_control_table.itemChanged.connect(self._on_control_item_changed)
        self.radial_control_table.currentItemChanged.connect(self._on_r_interval_current_changed)
        self.planar_mesh_preview.r_interval_activated.connect(self._on_planar_r_interval_activated)
        self.main_tabs.currentChanged.connect(self._on_main_tab_changed)
        self.layout_path_edit.textChanged.connect(self._on_layout_path_changed)
        self.layout_path_edit.returnPressed.connect(self._load_layout_file)
        self.layout_browse_button.clicked.connect(self._choose_layout_file)
        self.layout_reload_button.clicked.connect(self._load_layout_file)
        self.layout_output_button.clicked.connect(self._choose_layout_output)
        self.far_field_size_edit.textChanged.connect(self._refresh_layout_launch_state)
        self.transition_distance_edit.textChanged.connect(
            self._refresh_layout_launch_state
        )
        self.layout_output_edit.textChanged.connect(self._refresh_layout_launch_state)
        self.layout_material_mapping_table.itemChanged.connect(
            self._on_layout_material_mapping_changed
        )
        self.layout_preview_button.clicked.connect(
            lambda _checked=False: self._launch_layout(preview=True)
        )
        self.layout_generate_button.clicked.connect(
            lambda _checked=False: self._launch_layout(preview=False)
        )
        self.cdb_input_edit.textChanged.connect(self._refresh_cdb_launch_state)
        self.cdb_output_edit.textChanged.connect(self._refresh_cdb_launch_state)
        self.cdb_element_type_combo.currentIndexChanged.connect(
            self._refresh_cdb_launch_state
        )
        self.cdb_coordinate_scale_edit.textChanged.connect(
            self._refresh_cdb_launch_state
        )
        self.cdb_units_combo.currentIndexChanged.connect(
            self._refresh_cdb_launch_state
        )
        self.cdb_input_button.clicked.connect(self._choose_cdb_input)
        self.cdb_output_button.clicked.connect(self._choose_cdb_output)
        self.cdb_convert_button.clicked.connect(self._launch_cdb)
        self._refresh_cdb_launch_state()
        self.package_v2_source_open_button.clicked.connect(
            self._open_package_v2_source
        )
        self.package_v2_source_new_button.clicked.connect(self._new_local_source)
        self.package_v2_source_reload_button.clicked.connect(
            self._reload_package_v2_source
        )
        self.package_v2_source_save_button.clicked.connect(
            self._save_package_v2_source
        )
        self.package_v2_advanced_settings_box.toggled.connect(
            self.package_v2_advanced_settings_content.setVisible
        )
        self.package_v2_advanced_settings_content.setVisible(
            self.package_v2_advanced_settings_box.isChecked()
        )
        self.package_v2_interface_tolerance_edit.editingFinished.connect(
            self._on_package_v2_interface_tolerance_submitted
        )
        self.package_v2_parallel_tet_candidates_check.toggled.connect(
            self._on_package_v2_parallel_tet_candidates_changed
        )
        self.package_v2_interface_tolerance_reset_button.clicked.connect(
            self._reset_package_v2_interface_tolerance
        )
        self.package_v2_geometry_add_button.clicked.connect(
            self._add_package_v2_geometry
        )
        self.package_v2_geometry_delete_button.clicked.connect(self._delete_package_v2_geometry)
        self.package_v2_component_delete_button.clicked.connect(self._delete_package_v2_component)
        self.package_v2_geometry_edit_button.clicked.connect(self._edit_package_v2_geometry)
        self.package_v2_geometry_instance_button.clicked.connect(self._create_package_v2_geometry_instance)
        self.package_v2_frozen_edit_button.clicked.connect(self._edit_package_v2_frozen)
        self.package_v2_geometry_save_preset_button.clicked.connect(self._create_package_v2_template)
        self.package_v2_geometry_insert_preset_button.clicked.connect(self._import_package_v2_template)
        self.package_v2_template_edit_button.clicked.connect(lambda: self._edit_local_template(editing=True))
        self.package_v2_template_export_button.clicked.connect(self._export_local_template)
        self.package_v2_variable_add_button.clicked.connect(lambda: self._add_package_v2_variable("parameter"))
        self.package_v2_derived_add_button.clicked.connect(lambda: self._add_package_v2_variable("derived"))
        self.package_v2_variable_delete_button.clicked.connect(self._delete_package_v2_variable)
        self.package_v2_variables_table.itemSelectionChanged.connect(self._refresh_package_v2_source_controls)
        self.package_v2_frozen_add_button.clicked.connect(self._add_package_v2_frozen)
        self.package_v2_frozen_delete_button.clicked.connect(self._delete_package_v2_frozen)
        self.package_v2_frozen_table.itemSelectionChanged.connect(self._refresh_package_v2_source_controls)
        self.package_v2_geometry_tree.moveRequested.connect(self._move_package_v2_geometry_deferred)
        self.package_v2_geometry_tree.currentItemChanged.connect(
            lambda *_args: self._refresh_package_v2_source_controls()
        )
        for table in (
            self.package_v2_variables_table,
            self.package_v2_geometry_tree,
            self.package_v2_mesh_table,
            self.package_v2_frozen_table,
            self.package_v2_interfaces_table,
        ):
            table.setItemDelegate(_PackageV2SourceDelegate(table))
            table.itemChanged.connect(self._on_package_v2_source_item_changed)
            table.currentItemChanged.connect(
                self._on_package_v2_preview_current_item_changed
            )
            table.itemSelectionChanged.connect(
                self._on_package_v2_preview_selection_changed
            )
        self.package_v2_job_path_edit.textChanged.connect(
            self._on_package_v2_job_path_changed
        )
        self.package_v2_job_path_edit.returnPressed.connect(
            self._inspect_package_v2_job
        )
        self.package_v2_job_browse_button.clicked.connect(
            self._choose_package_v2_job
        )
        self.package_v2_create_job_button.clicked.connect(
            self._create_package_v2_job_from_source
        )
        self.package_v2_inspect_button.clicked.connect(
            self._inspect_package_v2_job
        )
        self.package_v2_generate_button.clicked.connect(
            self._launch_package_v2
        )
        self.package_v2_cancel_button.clicked.connect(
            self._cancel_package_v2_job
        )
        self.package_v2_cdb_button.clicked.connect(
            self._handoff_package_v2_to_cdb
        )
        self.package_v2_open_msh_button.clicked.connect(self._open_package_v2_msh)
        self._refresh_package_v2_launch_state()

        for editor in (
            self.layer_path_edit,
            self.output_edit,
            self.xy_size_edit,
            self.angular_size_edit,
            self.z_size_edit,
            self.layout_path_edit,
            self.far_field_size_edit,
            self.transition_distance_edit,
            self.layout_output_edit,
            self.cdb_input_edit,
            self.cdb_output_edit,
            self.cdb_coordinate_scale_edit,
        ):
            editor.textChanged.connect(self._refresh_project_modified)
        self.layer_editor.textChanged.connect(self._refresh_project_modified)
        self.layout_source_view.textChanged.connect(
            self._refresh_project_modified
        )
        self.xy_symmetry_only_checkbox.toggled.connect(
            self._refresh_project_modified
        )
        self.z_control_table.itemChanged.connect(self._refresh_project_modified)
        self.radial_control_table.itemChanged.connect(
            self._refresh_project_modified
        )
        self.layout_material_mapping_table.itemChanged.connect(
            self._refresh_project_modified
        )
        self.cdb_element_type_combo.currentIndexChanged.connect(
            self._refresh_project_modified
        )
        self.cdb_units_combo.currentIndexChanged.connect(
            self._refresh_project_modified
        )

    @staticmethod
    def _read_only_table_item(text: str) -> QTableWidgetItem:
        item = QTableWidgetItem(text)
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        return item

    @staticmethod
    def _format_size(value: float) -> str:
        return f"{value:g}"

    def _global_size_text(self, axis: ControlAxis) -> str:
        return {ControlAxis.RADIAL: self.xy_size_edit, ControlAxis.ANGULAR: self.angular_size_edit, ControlAxis.Z: self.z_size_edit}[axis].text()

    def _install_control_intervals(self, plan: SectionPlan) -> None:
        intervals = build_section_control_intervals(plan)
        live_keys = {interval.key for interval in intervals}
        live_keys |= {("angular", i.start_um, i.end_um) for i in intervals if i.axis is ControlAxis.RADIAL}
        for key in tuple(self._local_size_inputs):
            if key not in live_keys:
                del self._local_size_inputs[key]
        for key in tuple(self._local_size_overrides):
            if key not in live_keys:
                del self._local_size_overrides[key]
        for key in tuple(self._interval_sweep_policies):
            if key not in live_keys:
                del self._interval_sweep_policies[key]
        self._control_intervals = intervals
        self._rebuild_control_tables()

    def _clear_control_interval_views(self) -> None:
        """Clear rows for invalid geometry without discarding pending values.

        Keeping the keyed values until the next valid rebuild lets a transient
        Layer syntax error preserve overrides for boundaries that still exist.
        """

        self._control_intervals = ()
        self._rebuild_control_tables()

    def _rebuild_control_tables(self) -> None:
        radial = tuple(
            interval
            for interval in self._control_intervals
            if interval.axis is ControlAxis.RADIAL
        )
        vertical = tuple(
            interval for interval in self._control_intervals if interval.axis is ControlAxis.Z
        )
        self._updating_control_tables = True
        try:
            self._populate_radial_control_table(radial)
            self._populate_z_control_table(tuple(reversed(vertical)))
        finally:
            self._updating_control_tables = False
        self._update_control_table_values()
        self._sync_r_preview_focus()

    def _override_item(self, interval: MeshControlInterval, axis=None) -> QTableWidgetItem:
        key = ((axis.value, interval.start_um, interval.end_um) if axis else interval.key)
        override = QTableWidgetItem(self._local_size_inputs.get(key, ""))
        override.setData(Qt.ItemDataRole.UserRole, key)
        override.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        override.setToolTip(
            "留空继承对应方向的全局尺寸（µm）"
            if interval.axis is ControlAxis.RADIAL
            else "留空继承全局 Z 尺寸；输入正有限数字以覆写（µm）"
        )
        return override

    def _populate_z_control_table(
        self,
        intervals: tuple[MeshControlInterval, ...],
    ) -> None:
        self._populate_interval_control_table(self.z_control_table, intervals)

    def _populate_interval_control_table(self, table, intervals):
        table.clearContents()
        table.setRowCount(len(intervals))
        for row, interval in enumerate(intervals):
            identifier = self._read_only_table_item(interval.identifier)
            identifier.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            table.setItem(row, 0, identifier)

            position = self._read_only_table_item(interval.display_position)
            position.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            position.setToolTip(interval.display_position_tooltip)
            table.setItem(row, 1, position)
            table.setItem(row, 2, self._interval_thickness_item(interval))

            global_item = self._read_only_table_item("")
            global_item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            table.setItem(row, 3, global_item)

            table.setItem(row, 4, self._override_item(interval))

            effective = self._read_only_table_item("")
            effective.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            table.setItem(row, 5, effective)
            table.setCellWidget(row, 6, self._interval_advanced_button(interval, table))
            table.setRowHeight(row, 28)

    def _interval_thickness_item(self, interval):
        item = self._read_only_table_item(self._format_size(interval.end_um - interval.start_um))
        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        item.setToolTip("径向实际厚度 Δr（直径差的一半），单位 µm"
                        if interval.axis is ControlAxis.RADIAL else "Z 区间总厚度，单位 µm")
        return item

    def _populate_radial_control_table(
        self,
        intervals: tuple[MeshControlInterval, ...],
    ) -> None:
        table = self.radial_control_table
        table.clearContents()
        table.setRowCount(len(intervals))
        for row, interval in enumerate(intervals):
            for column, text in enumerate((interval.identifier, interval.display_position)):
                item = self._read_only_table_item(text)
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                table.setItem(row, column, item)
            table.setItem(row, 2, self._interval_thickness_item(interval))
            table.setItem(row, 3, self._override_item(interval))
            table.setItem(row, 4, self._override_item(interval, ControlAxis.ANGULAR))
            table.setCellWidget(row, 5, self._interval_advanced_button(interval, table))
            table.setRowHeight(row, 28)

    def _interval_advanced_button(self, interval, table):
        policy = self._interval_sweep_policies.get(interval.key)
        button = QPushButton("高级…" if policy is None else ("强约束…" if policy.constraint == "hard" else "弱约束…"), table)
        button.setAutoDefault(False)
        button.setToolTip(f"{interval.identifier}：设置约束、seed 方向和两个 merge 比例" + ("（继承默认）" if policy is None else "（已单独设置）"))
        button.clicked.connect(lambda _checked=False: self._edit_interval_sweep(interval))
        return button

    def _edit_interval_sweep(self, interval):
        inherited = self._z_sweep_policy() if interval.axis is ControlAxis.Z else RadialSeedPolicy()
        dialog = LayerSweepDialog(interval, inherited, self._interval_sweep_policies.get(interval.key), self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        policy = dialog.policy()
        if policy is None:
            self._interval_sweep_policies.pop(interval.key, None)
        else:
            self._interval_sweep_policies[interval.key] = policy
        self._rebuild_control_tables()
        self._refresh_derived()
        self._refresh_project_modified()

    def _sweep_overrides(self, axis):
        cls = ZSweepOverride if axis is ControlAxis.Z else RadialSweepOverride
        return tuple(cls(key[1], key[2], policy)
                     for key, policy in sorted(self._interval_sweep_policies.items())
                     if key[0] == axis.value)

    def _on_z_interval_current_changed(self, current, _previous):
        if self._updating_control_tables or current is None:
            return
        identifier = self.z_control_table.item(current.row(), 0)
        if identifier is None:
            return
        interval = next((i for i in self._control_intervals
                         if i.axis is ControlAxis.Z and i.identifier == identifier.text()), None)
        if interval is not None:
            self._focus_z_interval(interval, ensure_visible=True)

    def _on_section_z_interval_activated(self, key, height):
        interval = next((i for i in self._control_intervals if i.key == key), None)
        if interval is not None:
            self.layer_config_tabs.setCurrentWidget(self.local_size_tab)
            self._focus_z_interval(interval, height, reveal_row=True)

    def _focus_z_interval(self, interval, height=None, *, reveal_row=False, ensure_visible=False):
        height = interval.midpoint_um if height is None else height
        self._focused_z_key = interval.key
        self._focused_z_height = height
        table = self.z_control_table
        self._select_interval_row(table, interval, reveal_row=reveal_row)
        self.section_preview.set_selected_z_interval(interval.key, height, ensure_visible=ensure_visible)
        if self._section_plan is not None:
            self.planar_mesh_preview.set_height_slice(
                self._section_plan, height, interval.identifier, self.section_preview.material_palette()
            )
            self._annotate_plane_size_ranges()

    def _annotate_plane_size_ranges(self):
        topology = self.planar_mesh_preview.topology
        if topology is None:
            return
        ranges = getattr(self.planar_mesh_preview, "_region_size_ranges", {})
        blocked = self.radial_control_table.blockSignals(True)
        try:
            for row in range(self.radial_control_table.rowCount()):
                for column, axis, offset in ((3, ControlAxis.RADIAL, 0), (4, ControlAxis.ANGULAR, 2)):
                    item = self.radial_control_table.item(row, column)
                    if item is None:
                        continue
                    target = (topology.radial_target_sizes_um if axis is ControlAxis.RADIAL
                              else topology.angular_target_sizes_um)[row]
                    tip = f"目标：{target:g} µm；留空继承全局，双击修改"
                    if row in ranges:
                        lower, upper = ranges[row][offset:offset + 2]
                        tip += f"\n实际{'径向间距' if offset == 0 else '环向弧长'}：{lower:.6g}–{upper:.6g} µm"
                        tip += f"\n偏差：{(lower / target - 1) * 100:+.1f}%～{(upper / target - 1) * 100:+.1f}%"
                        if lower < .75 * target or upper > 1.25 * target:
                            tip += "\n部分单元与目标偏差超过 25%（边界、对称、merge 或连接调整）"
                    else:
                        tip += "\n当前高度无实体"
                    item.setToolTip(tip)
        finally:
            self.radial_control_table.blockSignals(blocked)

    @staticmethod
    def _select_interval_row(table, interval, *, reveal_row=False):
        blocked = table.blockSignals(True)
        try:
            for row in range(table.rowCount()):
                item = table.item(row, 0)
                if item is not None and item.text() == interval.identifier:
                    if table.currentRow() != row:
                        table.setCurrentCell(row, 0)
                    table.selectRow(row)
                    if reveal_row:
                        table.scrollToItem(item, QAbstractItemView.ScrollHint.PositionAtCenter)
                        table.setFocus(Qt.FocusReason.OtherFocusReason)
                    break
        finally:
            table.blockSignals(blocked)

    def _on_r_interval_current_changed(self, current, _previous):
        if self._updating_control_tables or current is None:
            return
        identifier = self.radial_control_table.item(current.row(), 0)
        interval = next((i for i in self._control_intervals
                         if i.axis is ControlAxis.RADIAL and identifier is not None
                         and i.identifier == identifier.text()), None)
        if interval is not None:
            self._focus_r_interval(interval, ensure_visible=True)

    def _on_planar_r_interval_activated(self, key):
        interval = next((i for i in self._control_intervals if i.key == key), None)
        if interval is not None:
            self.layer_config_tabs.setCurrentWidget(self.local_size_tab)
            self._focus_r_interval(interval, reveal_row=True)

    def _focus_r_interval(self, interval, *, reveal_row=False, ensure_visible=False):
        self._focused_r_key = interval.key
        self._select_interval_row(self.radial_control_table, interval, reveal_row=reveal_row)
        self.planar_mesh_preview.set_selected_r_interval(interval.key, ensure_visible=ensure_visible)

    def _sync_r_preview_focus(self):
        interval = next((i for i in self._control_intervals if i.key == self._focused_r_key), None)
        if interval is None:
            self._focused_r_key = None
            self.planar_mesh_preview.set_selected_r_interval(None)
        else:
            self._focus_r_interval(interval)

    def _sync_z_preview_focus(self):
        vertical = tuple(i for i in self._control_intervals if i.axis is ControlAxis.Z)
        if not vertical:
            self._focused_z_key = None
            self._focused_z_height = None
            self.section_preview.set_selected_z_interval(None)
            return
        interval = next((i for i in vertical if i.key == self._focused_z_key), vertical[-1])
        height = self._focused_z_height
        if height is None or not interval.start_um <= height < interval.end_um:
            height = interval.midpoint_um
        self._focus_z_interval(interval, height)

    @staticmethod
    def _clear_item_colors(item: QTableWidgetItem) -> None:
        item.setData(Qt.ItemDataRole.BackgroundRole, None)
        item.setData(Qt.ItemDataRole.ForegroundRole, None)

    @staticmethod
    def _control_value_cells(table: QTableWidget, axis: ControlAxis):
        """Yield identifier/global/override/effective cells for either axis."""

        for row in range(table.rowCount()):
            identifier = table.item(row, 0)
            if axis is ControlAxis.Z:
                yield identifier.text(), table.item(row, 3), table.item(row, 4), table.item(row, 5)
            else:
                yield identifier.text(), None, table.item(row, 3 if axis is ControlAxis.RADIAL else 4), None

    def _update_control_table_values(self) -> None:
        if self._updating_control_tables:
            return
        self._updating_control_tables = True
        errors, valid_overrides = [], {}
        try:
            for table, axis in ((self.radial_control_table, ControlAxis.RADIAL),
                                (self.radial_control_table, ControlAxis.ANGULAR),
                                (self.z_control_table, ControlAxis.Z)):
                direction = {ControlAxis.RADIAL: "R", ControlAxis.ANGULAR: "环向", ControlAxis.Z: "Z"}[axis]
                global_text = self._global_size_text(axis).strip()
                try:
                    global_value = effective_size(global_text)
                    global_error = ""
                except ValueError:
                    global_value, global_error = None, f"全局 {direction} 尺寸必须是有限正数"
                for identifier, global_item, item, effective_item in self._control_value_cells(table, axis):
                    if item is None:
                        continue
                    key = item.data(Qt.ItemDataRole.UserRole)
                    for cell in (global_item, item, effective_item):
                        if cell is not None:
                            self._clear_item_colors(cell)
                    if global_item is not None:
                        global_item.setText(self._format_size(global_value) if global_value is not None else global_text)
                        global_item.setToolTip(global_error or "全局目标尺寸（µm）")
                    raw = item.text().strip()
                    if raw:
                        self._local_size_inputs[key] = raw
                    else:
                        self._local_size_inputs.pop(key, None)
                    try:
                        value, error = validate_size_override(raw), ""
                    except ValueError:
                        value, error = None, "局部覆写必须是有限正数，或留空继承"
                        errors.append(f"{identifier} {direction}: {error}")
                    if value is not None:
                        valid_overrides[key] = value
                    resolved = value if value is not None else global_value
                    display = self._format_size(resolved) if resolved is not None and not error else "—"
                    tip = error or global_error or f"{direction} 目标：{display} µm；留空继承全局，双击修改"
                    item.setToolTip(tip)
                    item.setData(Qt.ItemDataRole.UserRole + 1, f"继承：{display}")
                    if effective_item is not None:
                        effective_item.setText(display)
                        effective_item.setToolTip(tip)
                    if error or global_error:
                        item.setBackground(QColor("#ffe2df"))
                        item.setForeground(QColor("#b42318"))
                    elif value is not None:
                        item.setBackground(QColor("#fff0b8"))
                        item.setForeground(QColor("#805500"))
        finally:
            self._updating_control_tables = False
        self._local_size_overrides.clear()
        self._local_size_overrides.update(valid_overrides)
        self._control_override_errors = tuple(errors)
        self.section_preview.set_control_intervals(self._control_intervals, valid_overrides)
        self.planar_mesh_preview.set_control_intervals(self._control_intervals, valid_overrides)

    def _on_control_item_changed(self, item: QTableWidgetItem) -> None:
        if self._updating_control_tables:
            return
        key = item.data(Qt.ItemDataRole.UserRole)
        if not isinstance(key, tuple) or len(key) != 3:
            return
        text = item.text().strip()
        if text:
            self._local_size_inputs[key] = text
        else:
            self._local_size_inputs.pop(key, None)
        self._refresh_derived()

    def _validate_control_overrides(self) -> None:
        self._update_control_table_values()
        if self._control_override_errors:
            raise ValueError(self._control_override_errors[0])

    def _z_sweep_policy(self):
        return LayerSweepPolicy(
            constraint=self.z_constraint_combo.currentData(),
            direction=self.z_seed_direction_combo.currentData(),
            remainder_ratio=self.z_merge_ratio_spin.value(),
            center_merge_ratio=self.z_center_merge_ratio_spin.value(),
        )

    def _on_z_sweep_changed(self, *_args):
        self._update_z_sweep_controls()
        self._refresh_derived()
        self._refresh_project_modified()

    def _update_z_sweep_controls(self):
        hard = self.z_constraint_combo.currentData() == "hard"
        self.z_seed_direction_combo.setEnabled(hard)
        self.z_merge_ratio_spin.setEnabled(hard)
        self.z_center_merge_ratio_spin.setEnabled(
            hard and self.z_seed_direction_combo.currentData() == "both_z"
        )

    def _parameters(self) -> AxisymmetricMeshParameters:
        if self._section_plan is None:
            raise ValueError("请先提供有效的 Layer 截面定义。")
        if not self._section_plan.diameters_um:
            raise ValueError("Layer 截面没有可用于平面网格的非零径向边界。")
        overrides = tuple(
            IntervalSizeOverride(
                axis=axis,
                start_um=start_um,
                end_um=end_um,
                size_um=size_um,
            )
            for (axis, start_um, end_um), size_um in sorted(
                self._local_size_overrides.items()
            )
        )
        return AxisymmetricMeshParameters(
            layer_text=self.layer_editor.toPlainText(),
            target_xy_um=float(self.xy_size_edit.text()),
            target_angular_um=float(self.angular_size_edit.text()),
            target_z_um=float(self.z_size_edit.text()),
            z_sweep=self._z_sweep_policy(),
            z_sweep_overrides=self._sweep_overrides(ControlAxis.Z),
            radial_sweep_overrides=self._sweep_overrides(ControlAxis.RADIAL),
            overrides=overrides,
            symmetry_mode=(
                "xy" if self.xy_symmetry_only_checkbox.isChecked() else "xy_45"
            ),
        )

    def _refresh_derived(self, *_args: object) -> None:
        self._update_control_table_values()
        try:
            parameters = self._parameters()
            self._validate_control_overrides()
            topology = build_topology_with_radial_targets(
                parameters.planar_parameters,
                parameters.effective_radial_sizes_um,
                parameters.effective_radial_policies,
                angular_target_sizes_um=parameters.effective_angular_sizes_um,
            )
        except (ValueError, TypeError) as exc:
            self.section_preview.set_z_mesh_levels(())
            self.planar_mesh_preview.set_topology(None, "网格参数待修正")
            self.section_heading_label.setText("Z 分层：—　·　3D 网格：—")
            self.section_heading_label.setToolTip("Layer 或网格参数待修正，暂无法统计")
            self.derived_label.setText(f"参数待修正：{exc}")
            self.derived_label.setStyleSheet(self._semantic_style("error"))
            self.preview_button.setEnabled(False)
            self.generate_button.setEnabled(False)
            return
        layer_job_active = "layer" in self._active_job_kinds
        self.preview_button.setEnabled(not layer_job_active)
        self.generate_button.setEnabled(not layer_job_active)
        self.derived_label.setStyleSheet("")

        z_levels = parameters.z_levels_um
        self.section_preview.set_z_mesh_levels(z_levels)
        self.planar_mesh_preview.set_topology(topology)
        self._sync_z_preview_focus()
        active_slabs_by_region: list[int] = []
        for column in parameters.section_plan.columns:
            active = 0
            for lower, upper in zip(z_levels, z_levels[1:]):
                midpoint = 0.5 * (lower + upper)
                if any(
                    span.z_bottom_um <= midpoint < span.z_top_um
                    for span in column.spans
                ):
                    active += 1
            active_slabs_by_region.append(active)
        projected_hex_by_region = [0] * len(active_slabs_by_region)
        projected_wedge_by_region = [0] * len(active_slabs_by_region)
        for face in topology.faces:
            if len(face.node_ids) == 4:
                projected_hex_by_region[face.region] += 1
            else:
                projected_wedge_by_region[face.region] += 1
        estimated_hex = sum(
            count * active_slabs_by_region[index]
            for index, count in enumerate(projected_hex_by_region)
        )
        estimated_wedge = sum(
            count * active_slabs_by_region[index]
            for index, count in enumerate(projected_wedge_by_region)
        )
        self.section_heading_label.setText(
            f"Z 分层：{len(z_levels) - 1:,} 层　·　3D 网格：{estimated_hex + estimated_wedge:,} 个"
        )
        self.section_heading_label.setToolTip(
            "统计整个模型，不随当前预览高度或选中区间变化。\n"
            "Z 为全局网格分层数，不是 Layer 文件行数。\n"
            f"六面体 HEX8：{estimated_hex:,} 个；三棱柱 WEDGE6：{estimated_wedge:,} 个。\n"
            "3D 总数按各径向区间的实际实体 Z 层累加，排除孔洞和空气间隙，无需运行 Gmsh。"
        )
        if len(topology.faces) * (len(z_levels) - 1) > MAX_DEMO_ESTIMATED_ELEMENTS:
            self.derived_label.setText(
                "参数待修正：预计三维单元数超过当前 demo 的安全上限 "
                f"{MAX_DEMO_ESTIMATED_ELEMENTS:,}；请增大 R、环向或 Z 尺寸。"
            )
            self.derived_label.setStyleSheet(self._semantic_style("error"))
            self.preview_button.setEnabled(False)
            self.generate_button.setEnabled(False)
            return
        radial_override_count = sum(
            override.axis is ControlAxis.RADIAL for override in parameters.overrides
        )
        angular_override_count = sum(item.axis is ControlAxis.ANGULAR for item in parameters.overrides)
        z_override_count = sum(item.axis is ControlAxis.Z for item in parameters.overrides)
        sector_angle_deg = 360.0 / topology.sector_count
        sector_angle_text = f"{sector_angle_deg:g}"
        symmetry_axes_text = (
            "X (0°)、Y (90°)"
            if parameters.symmetry_mode == "xy"
            else "X (0°)、45°、Y (90°)、135°"
        )
        self.derived_label.setText(
            "\n".join(
                (
                    f"由 Layer 派生直径：{format_diameters(parameters.diameters_um)} µm",
                    f"由 Layer 派生总高度：{parameters.max_height_um:g} µm",
                    (
                        f"每 {sector_angle_text}° 外圈周向单元数："
                        f"{topology.rings[-1].elements_per_sector}"
                    ),
                    f"强制镜像轴：{symmetry_axes_text}",
                    f"中心增边路径：{' → '.join(map(str, topology.center_count_path))}",
                    (
                        "各 R 区间径向层数："
                        f"{', '.join(map(str, (len(topology.center_count_path), *topology.outer_radial_layers)))}"
                    ),
                    f"全部 Z 区间合计层数：{len(z_levels) - 1}",
                    (
                        "预计 HEX8 / WEDGE6："
                        f"{estimated_hex:,} / {estimated_wedge:,}"
                    ),
                    (
                        "实际投影边长（含径向、环向及过渡边）："
                        f"{topology.edge_length.minimum_um:.3f}–{topology.edge_length.maximum_um:.3f} µm，"
                        f"均值={topology.edge_length.mean_um:.3f} µm，"
                        f"CV={topology.edge_length.cv:.1%}"
                    ),
                    f"全局目标：R={parameters.target_xy_um:g} / 环向弧长={parameters.target_angular_um:g} / Z={parameters.target_z_um:g} µm",
                    "实际尺寸与目标偏差可在平面区间表、圆盘单元悬停查看；共享边界和过渡处可能加密。",
                    (
                        "四边形实际投影面积："
                        f"{topology.quad_area.minimum_um2:.3f}–{topology.quad_area.maximum_um2:.3f} µm²，"
                        f"CV={topology.quad_area.cv:.1%}"
                    ),
                    f"WEDGE6 三角形投影区域：{topology.triangle_count} 个/厚度层（不写入二维单元）",
                    (
                        f"已接入生成的局部覆写：R {radial_override_count} 个 / 环向 {angular_override_count} 个 / Z {z_override_count} 个；"
                        "R 与环向独立设置，连接时统一协调"
                    ),
                )
            )
        )

    def _on_main_tab_changed(self, _index: int) -> None:
        if self.main_tabs.currentWidget() is self.package_v2_tab:
            self._refresh_package_v2_launch_state()
            return
        if self.main_tabs.currentWidget() is not self.layout_tab:
            return
        if (
            self._bump_layout is not None
            and not self._layout_template_details_loaded
            and not self._layout_template_inspection_attempted
        ):
            self._inspect_layout_templates(show_error=True)

    def _on_layout_path_changed(self, _text: str) -> None:
        if self._loading_layout_path:
            return
        self._layout_source_revision += 1
        self._bump_layout = None
        self._loaded_layout_source = None
        self._layout_template_meshes.clear()
        self._layout_template_slab_components = ()
        self._layout_template_slab_materials = ()
        self._layout_template_z_levels_mm = ()
        self._layout_void_slab_intervals_mm = ()
        self._layout_material_inputs.clear()
        self._layout_dependency_signatures.clear()
        self._layout_template_details_loaded = False
        self._layout_template_inspection_attempted = False
        self._layout_validation_error = "布局路径已修改，请重新载入并校验。"
        self.layout_source_view.clear()
        self.layout_placement_table.setRowCount(0)
        self.layout_template_table.setRowCount(0)
        self.layout_structured_region_table.setRowCount(0)
        self.layout_material_mapping_table.setRowCount(0)
        self.layout_component_table.setRowCount(0)
        self.layout_summary_label.setText("布局路径已修改，尚未载入。")
        self.layout_report_view.clear()
        self._rendered_layout_report_settings = None
        self.layout_status_label.setStyleSheet(self._semantic_style("error"))
        self.layout_status_label.setText("布局路径已修改，请重新载入并校验。")
        self._refresh_layout_launch_state()

    def _choose_layout_file(self) -> None:
        current = self._workspace_path(self.layout_path_edit.text())
        initial = (
            current.parent
            if current.parent.exists()
            else self._workspace_root / "examples"
        )
        selected, _filter = QFileDialog.getOpenFileName(
            self,
            "选择多 Bump 布局文件",
            str(initial),
            "EasyMesh layout (*.loc);;Text files (*.txt);;All files (*)",
        )
        if selected:
            self.layout_path_edit.setText(selected)
            self._load_layout_file(inspect_templates=True)

    def _choose_layout_output(self) -> None:
        current = self._workspace_path(self.layout_output_edit.text())
        selected, _filter = QFileDialog.getSaveFileName(
            self,
            "选择连接网格输出文件",
            str(current),
            "Gmsh mesh (*.msh);;All files (*)",
        )
        if selected:
            path = self._workspace_mesh_output(selected)
            self.layout_output_edit.setText(str(path))

    def _choose_cdb_input(self) -> None:
        raw_current = self.cdb_input_edit.text().strip()
        current = (
            self._workspace_path(raw_current)
            if raw_current
            else self._workspace_root / "output"
        )
        initial = current.parent if current.suffix else current
        if not initial.exists():
            initial = self._workspace_root / "output"
        selected, _filter = QFileDialog.getOpenFileName(
            self,
            "选择 Gmsh MSH 4.1 文件",
            str(initial),
            "Gmsh mesh (*.msh *.MSH);;All files (*)",
        )
        if not selected:
            return
        source = self._workspace_path(selected)
        self.cdb_input_edit.setText(str(source))
        self.cdb_output_edit.setText(str(normalized_cdb_output(source)))

    def _choose_cdb_output(self) -> None:
        raw_current = self.cdb_output_edit.text().strip()
        if raw_current:
            current = self._workspace_cdb_output(raw_current)
        else:
            raw_source = self.cdb_input_edit.text().strip()
            current = (
                normalized_cdb_output(self._workspace_path(raw_source))
                if raw_source
                else self._workspace_root / "output" / "converted.cdb"
            )
        selected, _filter = QFileDialog.getSaveFileName(
            self,
            "选择 ANSYS CDB 输出文件",
            str(current),
            "ANSYS CDB (*.cdb);;All files (*)",
        )
        if selected:
            self.cdb_output_edit.setText(str(self._workspace_cdb_output(selected)))

    def _selected_cdb_element_type(self) -> int:
        value = self.cdb_element_type_combo.currentData()
        if value is None:
            value = self.cdb_element_type_combo.currentText().removeprefix("SOLID")
        try:
            element_type = int(value)
        except (TypeError, ValueError) as exc:
            raise ValueError("请选择 SOLID185 或 SOLID186。") from exc
        if element_type not in (185, 186):
            raise ValueError("ANSYS 体单元只支持 SOLID185 或 SOLID186。")
        return element_type

    def _current_cdb_job_identity(
        self,
        *,
        enforce_idle: bool,
    ) -> _CdbJobIdentity:
        source_text = self.cdb_input_edit.text().strip()
        if not source_text:
            raise ValueError("请选择 Gmsh MSH 4.1 文件。")
        source = self._workspace_path(source_text)
        if source.suffix.lower() != ".msh":
            raise ValueError("输入文件扩展名必须是 .msh。")
        if not source.is_file():
            raise ValueError(f"MSH 输入不存在或不是普通文件：{source}")

        output_text = self.cdb_output_edit.text().strip()
        if not output_text:
            raise ValueError("请选择 CDB 输出文件。")
        output = self._workspace_cdb_output(output_text)
        if paths_refer_to_same_file(source, output):
            raise ValueError("MSH 输入与 CDB 输出不能是同一个文件。")

        try:
            coordinate_scale = float(
                self.cdb_coordinate_scale_edit.text().strip()
            )
        except ValueError as exc:
            raise ValueError("坐标比例必须是有限正数。") from exc
        if not math.isfinite(coordinate_scale) or coordinate_scale <= 0.0:
            raise ValueError("坐标比例必须是有限正数。")

        units_token = self.cdb_units_combo.currentText().strip().upper()
        if units_token not in {"MPA", "NONE"}:
            raise ValueError("/UNITS 标签只支持 MPA 或 NONE。")
        units_label = None if units_token == "NONE" else units_token

        if enforce_idle:
            if source in self._active_job_outputs:
                raise ValueError("输入 MSH 正由另一个任务写出，请等待其完成。")
            if output in self._active_job_outputs:
                raise ValueError(f"该 CDB 输出已有任务正在运行：{output}")
            if "cdb" in self._active_job_kinds:
                raise ValueError("CDB 页面已有转换任务正在运行，请等待其完成。")

        return _CdbJobIdentity(
            source=source,
            output=output,
            element_type=self._selected_cdb_element_type(),
            coordinate_scale=coordinate_scale,
            units_label=units_label,
            source_signature=self._layout_dependency_signature(source),
        )

    def _refresh_cdb_launch_state(
        self,
        *_args: object,
        preserve_status: bool = False,
    ) -> None:
        del _args
        raw_source = self.cdb_input_edit.text().strip()
        try:
            current = self._current_cdb_job_identity(enforce_idle=False)
            error: str | None = None
        except (OSError, ValueError) as exc:
            current = None
            error = str(exc)

        active_identity = next(iter(self._job_cdb_identities.values()), None)
        cdb_job_active = "cdb" in self._active_job_kinds
        inputs_changed_during_job = bool(
            cdb_job_active
            and active_identity is not None
            and current != active_identity
        )
        self.cdb_convert_button.setEnabled(error is None and not cdb_job_active)

        if inputs_changed_during_job:
            self._rendered_cdb_identity = None
            self.cdb_report_view.setStyleSheet(self._semantic_style("warning"))
            self.cdb_report_view.setPlainText(
                "当前转换输入或选项已修改；正在运行的 worker 属于先前设置。"
                "它完成后不会覆盖当前结果区。"
            )
        elif (
            self._rendered_cdb_identity is not None
            and current != self._rendered_cdb_identity
        ):
            self._rendered_cdb_identity = None
            self.cdb_report_view.setStyleSheet("")
            self.cdb_report_view.setPlainText(
                "输入、输出或 CDB 选项已修改；此前报告不再对应当前页面。"
            )

        if preserve_status:
            return
        if not raw_source:
            self.cdb_status_label.setStyleSheet(self._semantic_style("muted"))
            self.cdb_status_label.setText("请选择 Gmsh MSH 4.1 文件…")
        elif error is not None:
            self.cdb_status_label.setStyleSheet(self._semantic_style("error"))
            self.cdb_status_label.setText(f"转换待修正：{error}")
        elif inputs_changed_during_job:
            self.cdb_status_label.setStyleSheet(self._semantic_style("warning"))
            self.cdb_status_label.setText(
                "当前输入已修改；先前设置的 CDB 转换仍在后台运行。"
            )
        elif cdb_job_active:
            self.cdb_status_label.setStyleSheet(self._semantic_style("muted"))
            self.cdb_status_label.setText("正在后台转换 MSH → CDB…")
        else:
            self.cdb_status_label.setStyleSheet(self._semantic_style("success"))
            self.cdb_status_label.setText("输入和 CDB 选项有效，可以开始转换。")

    def _load_layout_file(
        self,
        _checked: bool = False,
        *,
        show_error: bool = True,
        inspect_templates: bool = True,
    ) -> None:
        del _checked
        raw_path = self.layout_path_edit.text().strip()
        if not raw_path:
            self._set_layout_error("请先选择 .loc 文件。", clear_source=True)
            if show_error:
                QMessageBox.critical(self, "布局载入失败", "请先选择 .loc 文件。")
            return
        source = self._workspace_path(raw_path)
        try:
            layout = load_bump_layout(source)
            resolved = source.resolve()
            text = resolved.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError, ValueError, TypeError) as exc:
            message = f"无法载入 {source}：{exc}"
            self._set_layout_error(message, clear_source=True)
            if show_error:
                QMessageBox.critical(self, "布局载入失败", message)
            return

        self._loading_layout_path = True
        self.layout_path_edit.setText(str(resolved))
        self._loading_layout_path = False
        self._bump_layout = layout
        self._loaded_layout_source = resolved
        self._layout_source_revision += 1
        self._layout_template_meshes.clear()
        self._layout_template_slab_components = ()
        self._layout_template_slab_materials = ()
        self._layout_template_z_levels_mm = ()
        self._layout_void_slab_intervals_mm = ()
        self._layout_dependency_signatures.clear()
        self._layout_template_details_loaded = False
        self._layout_template_inspection_attempted = False
        self._layout_validation_error = None
        self._rendered_layout_report_settings = None
        self.layout_source_view.setPlainText(text)
        self.layout_structured_region_table.setRowCount(0)
        self.layout_material_mapping_table.setRowCount(0)
        self.layout_component_table.setRowCount(0)
        self._populate_layout_source_summary(layout)
        self.layout_report_view.setPlainText(
            "布局来源已校验；模板 connectivity、接口共形和写出复核将在模板校验/生成后显示。"
        )
        self.layout_report_view.setStyleSheet("")
        if inspect_templates:
            self._inspect_layout_templates(show_error=show_error)
        else:
            self.layout_status_label.setStyleSheet(self._semantic_style("success"))
            self.layout_status_label.setText(
                "已读取 .loc；切换到本页或点击“载入并校验模板”后读取原生 ring、Z surfaces 和 component stack。"
            )
            self._refresh_layout_launch_state()

    def _populate_layout_source_summary(self, layout: BumpLayout) -> None:
        bounds = layout.bounds
        pitch_um = self._minimum_layout_pitch_um(layout)
        pitch_text = "单个 bump" if pitch_um is None else f"{pitch_um:g} µm"
        mesh_regions = tuple(getattr(layout, "mesh_regions", ()))
        planar_quad_count = sum(
            int(_value(region, "x_cell_count"))
            * int(_value(region, "y_cell_count"))
            for region in mesh_regions
        )
        structured_text = (
            f"局部结构化 HEX：{len(mesh_regions)} 区，"
            f"{planar_quad_count:,} 个 XY 方格/层；Z 继承模板 Layer surfaces。"
            if mesh_regions
            else "局部结构化 HEX：未定义；外部使用 WEDGE6 过渡。"
        )
        self.layout_summary_label.setStyleSheet("")
        self.layout_summary_label.setText(
            f"XY 范围：X={bounds.x_min_mm:g}–{bounds.x_max_mm:g} mm，"
            f"Y={bounds.y_min_mm:g}–{bounds.y_max_mm:g} mm（{bounds.width_mm:g} × "
            f"{bounds.height_mm:g} mm）\n"
            f"Bump：{len(layout.instances)} 个，模板：{len(layout.templates)} 种，"
            f"最小中心 pitch={pitch_text}（不设固定下限）；直径由模板外缘读取。\n"
            f"{structured_text}\n"
            "来源规则已通过；模板接口详情尚待读取。"
        )

        self.layout_placement_table.setRowCount(len(layout.instances))
        for row, instance in enumerate(layout.instances):
            values = (
                str(row + 1),
                f"{instance.x_mm * 1000:g}",
                f"{instance.y_mm * 1000:g}",
                instance.template_alias,
                "待读取",
            )
            for column, value in enumerate(values):
                item = self._read_only_table_item(value)
                if column in (0, 1, 2, 4):
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter
                    )
                self.layout_placement_table.setItem(row, column, item)
            self.layout_placement_table.setRowHeight(row, 25)

        self.layout_template_table.setRowCount(len(layout.templates))
        for row, template in enumerate(layout.templates):
            values = (
                template.alias,
                template.mesh_path.name,
                "待读取",
                "待读取",
                "待读取",
            )
            for column, value in enumerate(values):
                item = self._read_only_table_item(value)
                if column == 1:
                    item.setToolTip(str(template.mesh_path))
                if column in (2, 3, 4):
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter
                    )
                self.layout_template_table.setItem(row, column, item)
            self.layout_template_table.setRowHeight(row, 25)

        self._populate_layout_structured_region_table(layout)

    def _populate_layout_structured_region_table(
        self,
        layout: BumpLayout,
        *,
        z_surface_count: int | None = None,
        active_slab_count: int | None = None,
    ) -> None:
        """Show normalized .loc HEX regions without making them editable."""

        mesh_regions = tuple(getattr(layout, "mesh_regions", ()))
        self.layout_structured_region_table.setRowCount(len(mesh_regions))
        if z_surface_count is None or active_slab_count is None:
            z_source = "继承模板（待读取）"
        else:
            z_source = (
                f"继承模板（{z_surface_count} surfaces / "
                f"{active_slab_count} solid slabs）"
            )
        for row, region in enumerate(mesh_regions):
            x_min_mm = float(_value(region, "x_min_mm"))
            x_max_mm = float(_value(region, "x_max_mm"))
            y_min_mm = float(_value(region, "y_min_mm"))
            y_max_mm = float(_value(region, "y_max_mm"))
            size_x_mm = float(
                _value(region, "size_x_mm", _value(region, "size_mm"))
            )
            size_y_mm = float(
                _value(region, "size_y_mm", _value(region, "size_mm"))
            )
            values = (
                str(row + 1),
                "HEX8",
                f"{x_min_mm * 1000:g} → {x_max_mm * 1000:g}",
                f"{y_min_mm * 1000:g} → {y_max_mm * 1000:g}",
                f"{size_x_mm * 1000:g}",
                f"{size_y_mm * 1000:g}",
                z_source,
            )
            for column, value in enumerate(values):
                item = self._read_only_table_item(value)
                if column != 6:
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter
                    )
                self.layout_structured_region_table.setItem(row, column, item)
            self.layout_structured_region_table.setRowHeight(row, 25)

    @staticmethod
    def _minimum_layout_pitch_um(layout: BumpLayout) -> float | None:
        if len(layout.instances) < 2:
            return None
        minimum_mm = min(
            math.hypot(first.x_mm - second.x_mm, first.y_mm - second.y_mm)
            for index, first in enumerate(layout.instances)
            for second in layout.instances[index + 1 :]
        )
        return minimum_mm * 1000.0

    @staticmethod
    def _layout_material_name(names: Iterable[str]) -> str:
        unique = tuple(sorted(set(str(name) for name in names if str(name))))
        candidates = tuple(
            name
            for name in unique
            if name not in {"ALL_SOLID_VOLUMES", "TRANSITION_SOLID_VOLUMES"}
            and not name.startswith(("COMPONENT_", "HM_", "TEMPLATE_"))
            and not name.startswith("TRANSITION_")
        )
        if len(candidates) == 1:
            candidate = candidates[0]
            if candidate.startswith("MATERIAL_"):
                return normalize_material_name(candidate)
            return candidate
        rendered = ", ".join(unique) or "<none>"
        raise ValueError(
            "模板单元/边缘 slab 必须恰好映射到一个材料 Physical Group，"
            f"实际为：{rendered}"
        )

    @classmethod
    def _layout_component_name(cls, names: Iterable[str]) -> str:
        """Resolve one component while retaining a legacy material fallback."""

        unique = tuple(sorted(set(str(name) for name in names if str(name))))
        explicit = tuple(
            name.removeprefix("COMPONENT_")
            for name in unique
            if name.startswith("COMPONENT_")
        )
        if len(explicit) == 1 and explicit[0]:
            return explicit[0]
        if not explicit:
            material = cls._layout_material_name(unique)
            token = re.sub(r"[^A-Za-z0-9]+", "_", material).strip("_").upper()
            return token or "COMPONENT"
        rendered = ", ".join(unique) or "<none>"
        raise ValueError(
            "模板单元/边缘 slab 必须恰好映射到一个 COMPONENT_* Physical Group，"
            f"实际为：{rendered}"
        )

    @staticmethod
    def _normalize_layout_transition_material(value: str, source: str) -> str:
        """Normalize a GUI target while an empty cell inherits its source."""

        stripped = value.strip()
        if not stripped:
            return source
        try:
            return normalize_material_name(
                stripped,
                field_name="external transition material",
            )
        except (TypeError, ValueError) as exc:
            raise ValueError(
                "外部材料必须是无前缀、可打印且不与系统组冲突的原名；"
                "留空表示继承。"
            ) from exc

    @staticmethod
    def _ordered_unique(values: Iterable[str]) -> tuple[str, ...]:
        return tuple(dict.fromkeys(values))

    def _effective_layout_transition_materials(self) -> tuple[str, ...]:
        if not self._layout_template_slab_materials:
            raise ValueError("模板边缘材料 stack 尚未载入。")
        resolved_by_source = {
            source: self._normalize_layout_transition_material(
                self._layout_material_inputs.get(source, ""),
                source,
            )
            for source in self._ordered_unique(self._layout_template_slab_materials)
        }
        return tuple(
            resolved_by_source[source]
            for source in self._layout_template_slab_materials
        )

    def _layout_material_overrides(self) -> tuple[tuple[str, str], ...]:
        transition_stack = self._effective_layout_transition_materials()
        resolved_by_source = dict(
            zip(self._layout_template_slab_materials, transition_stack)
        )
        return tuple(
            (source, resolved_by_source[source])
            for source in self._ordered_unique(self._layout_template_slab_materials)
            if resolved_by_source[source] != source
        )

    def _populate_layout_material_tables(self, intervals: Iterable[object]) -> None:
        interval_items = tuple(intervals)
        live_sources = self._ordered_unique(self._layout_template_slab_materials)
        self._layout_material_inputs = {
            source: value
            for source, value in self._layout_material_inputs.items()
            if source in live_sources
        }
        self._updating_layout_material_tables = True
        try:
            self.layout_material_mapping_table.setRowCount(len(live_sources))
            for row, source in enumerate(live_sources):
                source_item = self._read_only_table_item(source)
                source_item.setData(Qt.ItemDataRole.UserRole, source)
                target_item = QTableWidgetItem(
                    self._layout_material_inputs.get(source, "")
                )
                target_item.setData(Qt.ItemDataRole.UserRole, source)
                target_item.setToolTip(
                    f"留空继承 {source}；输入 UF 后材料名保持为 UF"
                )
                self.layout_material_mapping_table.setItem(row, 0, source_item)
                self.layout_material_mapping_table.setItem(row, 1, target_item)
                self.layout_material_mapping_table.setRowHeight(row, 25)

            self.layout_component_table.setRowCount(len(interval_items))
            component_stack = (
                self._layout_template_slab_components
                or self._layout_template_slab_materials
            )
            if len(component_stack) != len(interval_items):
                raise ValueError("模板边缘 component stack 与高度区间数量不一致")
            for row, (interval, component, source) in enumerate(
                zip(
                    interval_items,
                    component_stack,
                    self._layout_template_slab_materials,
                    strict=True,
                )
            ):
                values = (
                    f"S{row + 1:02d}",
                    f"{float(_value(interval, 'z_min')) * 1000:g} → "
                    f"{float(_value(interval, 'z_max')) * 1000:g}",
                    component,
                    source,
                    component,
                    source,
                )
                for column, value in enumerate(values):
                    item = self._read_only_table_item(value)
                    if column in (0, 1):
                        item.setTextAlignment(
                            Qt.AlignmentFlag.AlignCenter
                            | Qt.AlignmentFlag.AlignVCenter
                        )
                    self.layout_component_table.setItem(row, column, item)
                self.layout_component_table.setRowHeight(row, 24)
        finally:
            self._updating_layout_material_tables = False
        self._refresh_layout_material_table_values()

    def _refresh_layout_material_table_values(self) -> None:
        if self._updating_layout_material_tables:
            return
        self._updating_layout_material_tables = True
        try:
            resolved_by_source: dict[str, str] = {}
            errors_by_source: dict[str, str] = {}
            for row in range(self.layout_material_mapping_table.rowCount()):
                source_item = self.layout_material_mapping_table.item(row, 0)
                target_item = self.layout_material_mapping_table.item(row, 1)
                if source_item is None or target_item is None:
                    continue
                source = source_item.text()
                self._clear_item_colors(target_item)
                try:
                    target = self._normalize_layout_transition_material(
                        target_item.text(), source
                    )
                except ValueError as exc:
                    errors_by_source[source] = str(exc)
                    target_item.setBackground(QColor("#ffe2df"))
                    target_item.setForeground(QColor("#b42318"))
                    target_item.setToolTip(str(exc))
                else:
                    resolved_by_source[source] = target
                    target_item.setToolTip(
                        f"有效外部材料：{target}；留空继承 {source}"
                    )
                    if target != source:
                        target_item.setBackground(QColor("#fff0b8"))
                        target_item.setForeground(QColor("#805500"))

            for row, source in enumerate(self._layout_template_slab_materials):
                target_item = self.layout_component_table.item(row, 5)
                if target_item is None:
                    continue
                self._clear_item_colors(target_item)
                if source in errors_by_source:
                    target_item.setText("输入无效")
                    target_item.setBackground(QColor("#ffe2df"))
                    target_item.setForeground(QColor("#b42318"))
                    target_item.setToolTip(errors_by_source[source])
                    continue
                target = resolved_by_source.get(source, source)
                target_item.setText(target)
                target_item.setToolTip(
                    "继承模板边缘材料"
                    if target == source
                    else f"用户映射：{source} → {target}"
                )
                if target != source:
                    target_item.setBackground(QColor("#fff0b8"))
                    target_item.setForeground(QColor("#805500"))
        finally:
            self._updating_layout_material_tables = False

    def _on_layout_material_mapping_changed(self, item: QTableWidgetItem) -> None:
        if self._updating_layout_material_tables or item.column() != 1:
            return
        source_item = self.layout_material_mapping_table.item(item.row(), 0)
        if source_item is None:
            return
        source = source_item.text()
        raw_value = item.text()
        if not raw_value.strip():
            self._layout_material_inputs.pop(source, None)
            if raw_value:
                self._updating_layout_material_tables = True
                try:
                    item.setText("")
                finally:
                    self._updating_layout_material_tables = False
        else:
            try:
                normalized = self._normalize_layout_transition_material(
                    raw_value, source
                )
            except ValueError:
                self._layout_material_inputs[source] = raw_value
            else:
                self._layout_material_inputs[source] = normalized
                if raw_value != normalized:
                    self._updating_layout_material_tables = True
                    try:
                        item.setText(normalized)
                    finally:
                        self._updating_layout_material_tables = False
        self._refresh_layout_material_table_values()
        self._refresh_layout_launch_state()

    @staticmethod
    def _layout_dependency_signature(path: Path) -> tuple[int, int, int]:
        stat = path.stat()
        return (int(stat.st_ino), int(stat.st_mtime_ns), int(stat.st_size))

    def _layout_dependency_snapshot_signature(
        self,
        path: Path,
    ) -> tuple[int, int, int]:
        """Snapshot an expected dependency path, including its absence."""

        try:
            return self._layout_dependency_signature(path)
        except FileNotFoundError:
            return _MISSING_LAYOUT_DEPENDENCY_SIGNATURE

    def _inspect_layout_templates(self, *, show_error: bool) -> None:
        layout = self._bump_layout
        if layout is None:
            return
        self._layout_template_inspection_attempted = True
        self.layout_status_label.setStyleSheet(self._semantic_style("muted"))
        self.layout_status_label.setText(
            "正在读取模板外缘、Z surfaces 和 component/material stack…"
        )
        try:
            meshes = {
                template.alias: load_sample_mesh(template.mesh_path)
                for template in layout.templates
            }
            validate_compatible_outer_boundaries(
                tuple(meshes.values()),
                require_identical_radius=False,
            )
            reference_identities: set[tuple[str, str]] | None = None
            for alias, mesh in meshes.items():
                identities = {
                    (
                        self._layout_component_name(element.physical_names),
                        self._layout_material_name(element.physical_names),
                    )
                    for element in mesh.elements
                }
                if reference_identities is None:
                    reference_identities = identities
                elif identities != reference_identities:
                    raise ValueError(
                        f"模板 {alias} 的内部 material/component 集合与首个模板不一致"
                    )
        except Exception as exc:
            message = f"模板接口校验失败：{exc}"
            self._layout_template_meshes.clear()
            self._layout_template_slab_components = ()
            self._layout_template_slab_materials = ()
            self._layout_template_z_levels_mm = ()
            self._layout_void_slab_intervals_mm = ()
            self.layout_material_mapping_table.setRowCount(0)
            self.layout_component_table.setRowCount(0)
            self._layout_template_details_loaded = False
            self._layout_validation_error = message
            self.layout_status_label.setStyleSheet(self._semantic_style("error"))
            self.layout_status_label.setText(message)
            self.layout_summary_label.setStyleSheet(self._semantic_style("error"))
            self.layout_summary_label.setText(
                self.layout_summary_label.text() + f"\n{message}"
            )
            self._refresh_layout_launch_state()
            if show_error:
                QMessageBox.critical(self, "模板接口校验失败", str(exc))
            return

        self._layout_template_meshes = meshes
        self._layout_template_details_loaded = True
        self._layout_validation_error = None
        assert self._loaded_layout_source is not None
        template_paths = tuple(
            template.mesh_path.resolve() for template in layout.templates
        )
        sidecar_paths = tuple(
            candidate
            for mesh_path in template_paths
            for candidate in (
                mesh_path.with_suffix(".parameters.json"),
                mesh_path.with_suffix(".report.json"),
            )
        )
        dependency_paths = (
            self._loaded_layout_source,
            *template_paths,
            *sidecar_paths,
        )
        self._layout_dependency_signatures = {
            path: self._layout_dependency_snapshot_signature(path)
            for path in dependency_paths
        }
        ring_counts = {
            alias: next(
                len(tags)
                for _z_level, tags in mesh.outer_boundary.node_tags_by_z
                if tags
            )
            for alias, mesh in meshes.items()
        }
        for row, instance in enumerate(layout.instances):
            self.layout_placement_table.item(row, 4).setText(
                str(ring_counts[instance.template_alias])
            )
        for row, template in enumerate(layout.templates):
            mesh = meshes[template.alias]
            self.layout_template_table.item(row, 2).setText(
                str(ring_counts[template.alias])
            )
            self.layout_template_table.item(row, 3).setText(
                str(len(mesh.outer_boundary.z_levels))
            )
            self.layout_template_table.item(row, 4).setText(f"{len(mesh.elements):,}")

        reference = next(iter(meshes.values()))
        intervals = reference.outer_boundary.surface_intervals
        self._layout_template_z_levels_mm = tuple(
            reference.outer_boundary.z_levels
        )
        self._layout_void_slab_intervals_mm = tuple(
            reference.outer_boundary.void_intervals
        )
        self._layout_template_slab_components = tuple(
            self._layout_component_name(interval.physical_names)
            for interval in intervals
        )
        self._layout_template_slab_materials = tuple(
            self._layout_material_name(interval.physical_names)
            for interval in intervals
        )
        self._populate_layout_material_tables(intervals)
        self._populate_layout_structured_region_table(
            layout,
            z_surface_count=len(reference.outer_boundary.z_levels),
            active_slab_count=len(intervals),
        )

        levels_um = tuple(value * 1000.0 for value in reference.outer_boundary.z_levels)
        void_intervals_um = tuple(
            (z_min * 1000.0, z_max * 1000.0)
            for z_min, z_max in reference.outer_boundary.void_intervals
        )
        ring_text = " / ".join(
            f"{template.alias}={ring_counts[template.alias]}"
            for template in layout.templates
        )
        diameter_text = " / ".join(
            f"{template.alias}=Ø{meshes[template.alias].outer_boundary.radius * 2000:g} µm"
            for template in layout.templates
        )
        source_summary = self.layout_summary_label.text().split(
            "\n来源规则已通过", 1
        )[0]
        self.layout_summary_label.setStyleSheet("")
        self.layout_summary_label.setText(
            f"{source_summary}\n"
            f"模板外径：{diameter_text}；原生 ring：{ring_text}。\n"
            f"各模板共同保留 {len(levels_um)} 个精确 Z surfaces "
            f"（{levels_um[0]:g}–{levels_um[-1]:g} µm）；"
            f"air gap 外缘空洞区间={len(void_intervals_um)}。\n"
            "接口兼容：各模板自身外缘、全部 surface 高度及逐层 component/material stack "
            "有效；不同直径和 ring 节点数均可混用。"
        )
        self.layout_status_label.setStyleSheet(self._semantic_style("success"))
        self.layout_status_label.setText(
            "布局来源与模板接口格式有效，可以在后台尝试连接；实际净空和过渡质量由拼接阶段判定。"
            "模板体网格及每个边缘 surface 高度不会改变。"
        )
        self._refresh_layout_launch_state()
        self._load_existing_layout_report()

    def _set_layout_error(self, message: str, *, clear_source: bool) -> None:
        self._bump_layout = None
        self._loaded_layout_source = None
        self._layout_template_meshes.clear()
        self._layout_template_slab_components = ()
        self._layout_template_slab_materials = ()
        self._layout_template_z_levels_mm = ()
        self._layout_void_slab_intervals_mm = ()
        self._layout_material_inputs.clear()
        self._layout_dependency_signatures.clear()
        self._layout_template_details_loaded = False
        self._layout_template_inspection_attempted = False
        self._layout_validation_error = message
        if clear_source:
            self.layout_source_view.clear()
        self.layout_placement_table.setRowCount(0)
        self.layout_template_table.setRowCount(0)
        self.layout_structured_region_table.setRowCount(0)
        self.layout_material_mapping_table.setRowCount(0)
        self.layout_component_table.setRowCount(0)
        self.layout_summary_label.setStyleSheet(self._semantic_style("error"))
        self.layout_summary_label.setText(message)
        self.layout_report_view.clear()
        self._rendered_layout_report_settings = None
        self.layout_status_label.setStyleSheet(self._semantic_style("error"))
        self.layout_status_label.setText(message)
        self._refresh_layout_launch_state()

    @staticmethod
    def _positive_layout_value(text: str, label: str) -> float:
        try:
            value = float(text)
        except ValueError as exc:
            raise ValueError(f"{label}必须是正有限数字。") from exc
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"{label}必须是正有限数字。")
        if value < MIN_NUMERICAL_SEPARATION_UM:
            raise ValueError(
                f"{label}低于数值建模下限 {MIN_NUMERICAL_SEPARATION_UM:g} µm。"
            )
        return value

    def _validate_layout_size_budget(self, far_field_size_um: float) -> None:
        layout = self._bump_layout
        if layout is None:
            return
        slab_count = 17
        if self._layout_template_meshes:
            reference = next(iter(self._layout_template_meshes.values()))
            slab_count = len(reference.outer_boundary.surface_intervals)
        far_field_size_mm = far_field_size_um * 1.0e-3
        estimated_triangles = math.ceil(
            3.0
            * layout.bounds.width_mm
            * layout.bounds.height_mm
            / (far_field_size_mm * far_field_size_mm)
        )
        template_elements = 0
        minimum_ring_triangles = 0
        if self._layout_template_meshes:
            for instance in layout.instances:
                mesh = self._layout_template_meshes[instance.template_alias]
                template_elements += len(mesh.elements)
                minimum_ring_triangles += 2 * next(
                    len(tags)
                    for _z_level, tags in mesh.outer_boundary.node_tags_by_z
                    if tags
                )
        estimated_volume_elements = (
            max(estimated_triangles, minimum_ring_triangles) * slab_count
            + template_elements
        )
        if estimated_volume_elements > MAX_DEMO_ESTIMATED_ELEMENTS:
            raise ValueError(
                "按当前 XY 范围和远场尺寸保守估算的过渡体单元超过安全上限 "
                f"{MAX_DEMO_ESTIMATED_ELEMENTS:,}（估算 {estimated_volume_elements:,}）；"
                "请增大远场 XY 尺寸或缩小布局范围。"
            )

    def _refresh_layout_launch_state(
        self,
        *_args: object,
        preserve_status: bool = False,
    ) -> None:
        error: str | None = self._layout_validation_error
        if self._bump_layout is None:
            error = error or "请先载入有效的 .loc。"
        elif not self._layout_template_details_loaded:
            error = error or "请先读取并校验模板接口。"
        try:
            far_field_size_um = self._positive_layout_value(
                self.far_field_size_edit.text().strip(), "远场 XY 尺寸"
            )
            self._validate_layout_size_budget(far_field_size_um)
            self._positive_layout_value(
                self.transition_distance_edit.text().strip(), "过渡距离"
            )
            if self._layout_template_details_loaded:
                self._effective_layout_transition_materials()
            if not self.layout_output_edit.text().strip():
                raise ValueError("请选择连接网格输出文件。")
        except ValueError as exc:
            error = str(exc)
        layout_job_active = "layout" in self._active_job_kinds
        enabled = error is None and not layout_job_active
        self.layout_preview_button.setEnabled(enabled)
        self.layout_generate_button.setEnabled(enabled)
        current_settings = self._current_layout_report_settings()
        active_layout_settings = tuple(self._job_layout_settings.values())
        inputs_changed_during_job = bool(
            layout_job_active
            and active_layout_settings
            and current_settings != active_layout_settings[0]
        )
        if inputs_changed_during_job:
            self._rendered_layout_report_settings = None
            self.layout_report_view.setStyleSheet(self._semantic_style("warning"))
            self.layout_report_view.setPlainText(
                "当前布局输入已修改；正在运行的 worker 属于先前参数。"
                "它完成后不会覆盖当前结果区。"
            )
        if self._rendered_layout_report_settings is not None:
            if current_settings != self._rendered_layout_report_settings:
                self._rendered_layout_report_settings = None
                self.layout_report_view.setStyleSheet("")
                self.layout_report_view.setPlainText(
                    "布局输出或过渡参数已修改；此前结果不再对应当前页面，请重新生成或载入匹配的报告。"
                )
        if error is not None and not preserve_status:
            self.layout_status_label.setStyleSheet(self._semantic_style("error"))
            self.layout_status_label.setText(f"布局待修正：{error}")
        elif inputs_changed_during_job and not preserve_status:
            self.layout_status_label.setStyleSheet(self._semantic_style("warning"))
            self.layout_status_label.setText(
                "当前输入已修改；先前参数的连接任务仍在后台运行。"
            )
        elif not layout_job_active and not preserve_status:
            self.layout_status_label.setStyleSheet(self._semantic_style("success"))
            self.layout_status_label.setText(
                "布局来源、模板接口格式和过渡参数有效，可以在后台尝试连接；"
                "实际净空与网格质量由拼接阶段判定。"
            )

    def _current_layout_report_settings(
        self,
    ) -> tuple[
        Path,
        Path,
        float,
        float,
        int,
        tuple[str, ...],
        tuple[str, ...],
    ] | None:
        if self._loaded_layout_source is None:
            return None
        output_text = self.layout_output_edit.text().strip()
        if not output_text:
            return None
        try:
            far_field_um = self._positive_layout_value(
                self.far_field_size_edit.text().strip(), "远场 XY 尺寸"
            )
            transition_um = self._positive_layout_value(
                self.transition_distance_edit.text().strip(), "过渡距离"
            )
            transition_slab_materials = (
                self._effective_layout_transition_materials()
            )
        except ValueError:
            return None
        output = self._workspace_mesh_output(output_text)
        return (
            self._loaded_layout_source,
            output,
            far_field_um,
            transition_um,
            self._layout_source_revision,
            self._layout_template_slab_components,
            self._layout_template_slab_components,
            self._layout_template_slab_materials,
            transition_slab_materials,
        )

    @staticmethod
    def _layout_report_identity(
        layout: BumpLayout,
        source: Path,
        far_field_um: float,
        transition_um: float,
        z_levels_mm: tuple[float, ...],
        void_slab_intervals_mm: tuple[tuple[float, float], ...],
        template_slab_components: tuple[str, ...],
        transition_slab_components: tuple[str, ...],
        template_slab_materials: tuple[str, ...],
        transition_slab_materials: tuple[str, ...],
    ) -> _LayoutReportIdentity:
        return _LayoutReportIdentity(
            source=source.resolve(),
            far_field_um=far_field_um,
            transition_um=transition_um,
            bounds_mm=(
                layout.bounds.x_min_mm,
                layout.bounds.x_max_mm,
                layout.bounds.y_min_mm,
                layout.bounds.y_max_mm,
            ),
            templates=tuple(
                (template.alias, template.mesh_path.expanduser().resolve())
                for template in layout.templates
            ),
            instances=tuple(
                (instance.x_mm, instance.y_mm, instance.template_alias)
                for instance in layout.instances
            ),
            structured_regions=tuple(
                (
                    float(_value(region, "x_min_mm")),
                    float(_value(region, "x_max_mm")),
                    float(_value(region, "y_min_mm")),
                    float(_value(region, "y_max_mm")),
                    float(
                        _value(
                            region,
                            "size_x_mm",
                            _value(region, "size_mm"),
                        )
                    ),
                    float(
                        _value(
                            region,
                            "size_y_mm",
                            _value(region, "size_mm"),
                        )
                    ),
                )
                for region in tuple(getattr(layout, "mesh_regions", ()))
            ),
            z_levels_mm=z_levels_mm,
            void_slab_intervals_mm=void_slab_intervals_mm,
            template_slab_components=template_slab_components,
            transition_slab_components=transition_slab_components,
            template_slab_materials=template_slab_materials,
            transition_slab_materials=transition_slab_materials,
        )

    def _current_layout_job_report_identity(
        self,
    ) -> _LayoutReportIdentity | None:
        settings = self._current_layout_report_settings()
        layout = self._bump_layout
        if settings is None or layout is None:
            return None
        (
            source,
            _output,
            far_field_um,
            transition_um,
            _revision,
            template_slab_components,
            transition_slab_components,
            template_slab_materials,
            transition_slab_materials,
        ) = settings
        return self._layout_report_identity(
            layout,
            source,
            far_field_um,
            transition_um,
            self._layout_template_z_levels_mm,
            self._layout_void_slab_intervals_mm,
            template_slab_components,
            transition_slab_components,
            template_slab_materials,
            transition_slab_materials,
        )

    @staticmethod
    def _layout_report_number(value: object, label: str) -> float:
        if isinstance(value, bool):
            raise ValueError(f"报告 {label} 不是有限数字")
        try:
            number = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"报告 {label} 不是有限数字") from exc
        if not math.isfinite(number):
            raise ValueError(f"报告 {label} 不是有限数字")
        return number

    @staticmethod
    def _layout_report_text(value: object, label: str) -> str:
        if not isinstance(value, str) or not value:
            raise ValueError(f"报告 {label} 不是非空字符串")
        return value

    @classmethod
    def _layout_report_material_stack(
        cls,
        value: object,
        label: str,
    ) -> tuple[str, ...]:
        if not isinstance(value, (list, tuple)) or not value:
            raise ValueError(f"报告 {label} 不是非空数组")
        return tuple(
            cls._layout_report_text(item, f"{label}[{index}]")
            for index, item in enumerate(value)
        )

    @classmethod
    def _layout_report_component_contract(
        cls,
        container: Mapping[str, object],
        *,
        label: str,
        expected_slab_count: int,
        required: bool = False,
    ) -> tuple[tuple[str, ...], tuple[str, ...]]:
        """Read optional component stacks from v2 reports.

        Early v2 reports predate component-aware identity and omit both fields.
        Once either field is present, both become a strict part of the report
        identity and must align one-to-one with the material slabs.
        """

        template_value = container.get("template_slab_components")
        transition_value = container.get("transition_slab_components")
        if template_value is None and transition_value is None:
            if required:
                raise ValueError(f"报告 {label} 缺少 component stacks")
            return (), ()
        if template_value is None or transition_value is None:
            raise ValueError(
                f"报告 {label} 必须同时提供 template_slab_components "
                "和 transition_slab_components"
            )
        template_components = cls._layout_report_material_stack(
            template_value,
            f"{label}.template_slab_components",
        )
        transition_components = cls._layout_report_material_stack(
            transition_value,
            f"{label}.transition_slab_components",
        )
        if (
            len(template_components) != expected_slab_count
            or len(transition_components) != expected_slab_count
        ):
            raise ValueError(
                f"报告 {label} 的 component/material stack 长度不一致"
            )
        return template_components, transition_components

    @classmethod
    def _layout_report_outer_geometry(
        cls,
        container: Mapping[str, object],
        *,
        label: str,
        values_are_um: bool,
    ) -> tuple[tuple[float, ...], tuple[tuple[float, float], ...]]:
        """Normalize one report's complete outer Z/void geometry to millimetres."""

        z_field = "z_levels_um" if values_are_um else "z_levels"
        void_field = (
            "void_slab_intervals_um"
            if values_are_um
            else "void_slab_intervals"
        )
        raw_levels = container.get(z_field)
        if not isinstance(raw_levels, (list, tuple)) or len(raw_levels) < 2:
            raise ValueError(f"报告 {label}.{z_field} 不是至少两项的数组")
        scale = 0.001 if values_are_um else 1.0
        levels = tuple(
            scale * cls._layout_report_number(item, f"{label}.{z_field}[{index}]")
            for index, item in enumerate(raw_levels)
        )
        if any(upper <= lower for lower, upper in zip(levels, levels[1:])):
            raise ValueError(f"报告 {label}.{z_field} 必须严格递增")

        raw_voids = container.get(void_field)
        if not isinstance(raw_voids, (list, tuple)):
            raise ValueError(f"报告 {label}.{void_field} 不是数组")
        voids: list[tuple[float, float]] = []
        for index, raw_interval in enumerate(raw_voids):
            if not isinstance(raw_interval, (list, tuple)) or len(raw_interval) != 2:
                raise ValueError(
                    f"报告 {label}.{void_field}[{index}] 不是两项区间"
                )
            lower = scale * cls._layout_report_number(
                raw_interval[0], f"{label}.{void_field}[{index}][0]"
            )
            upper = scale * cls._layout_report_number(
                raw_interval[1], f"{label}.{void_field}[{index}][1]"
            )
            if upper <= lower:
                raise ValueError(
                    f"报告 {label}.{void_field}[{index}] 必须是正宽度区间"
                )
            voids.append((lower, upper))
        normalized_voids = tuple(sorted(set(voids)))
        if tuple(voids) != normalized_voids:
            raise ValueError(f"报告 {label}.{void_field} 必须有序且不重复")

        slabs = tuple(zip(levels, levels[1:]))
        for interval in normalized_voids:
            if not any(
                math.isclose(interval[0], slab[0], rel_tol=1.0e-12, abs_tol=1.0e-12)
                and math.isclose(
                    interval[1], slab[1], rel_tol=1.0e-12, abs_tol=1.0e-12
                )
                for slab in slabs
            ):
                raise ValueError(
                    f"报告 {label}.{void_field} 必须对齐相邻 Z surfaces"
                )
        return levels, normalized_voids

    @classmethod
    def _layout_report_material_override_contract(
        cls,
        value: object,
        *,
        template_slab_materials: tuple[str, ...],
        label: str,
    ) -> tuple[tuple[tuple[str, str], ...], tuple[str, ...]]:
        """Normalize one override mapping and expand it over a template stack."""

        if not isinstance(value, Mapping):
            raise ValueError(f"报告 {label} 不是对象")

        normalized_source_candidates: dict[str, list[str]] = {}
        for template_source in sorted(set(template_slab_materials)):
            try:
                normalized_source = normalize_material_name(
                    template_source,
                    field_name=f"报告 {label} 模板源 material",
                )
            except ValueError:
                # Legacy/noncanonical template names remain valid when inherited,
                # but cannot be addressed by the normalized override interface.
                continue
            lookup_key = unicodedata.normalize("NFKC", normalized_source).casefold()
            normalized_source_candidates.setdefault(lookup_key, []).append(
                template_source
            )

        normalized_overrides: dict[str, str] = {}
        exterior_by_template_source: dict[str, str] = {}
        for raw_source, raw_target in value.items():
            try:
                source = normalize_material_name(
                    raw_source,
                    field_name=f"报告 {label} source",
                )
                target = normalize_material_name(
                    raw_target,
                    field_name=f"报告 {label} target",
                )
            except ValueError as exc:
                raise ValueError(f"报告 {label} 包含无效 material：{exc}") from exc

            lookup_key = unicodedata.normalize("NFKC", source).casefold()
            candidates = normalized_source_candidates.get(lookup_key, ())
            if not candidates:
                raise ValueError(
                    f"报告 {label} 引用了未知模板源 material：{source}"
                )
            if len(candidates) != 1:
                rendered = "、".join(candidates)
                raise ValueError(
                    f"报告 {label} 的源 material {source} 不唯一：{rendered}"
                )
            canonical_source = candidates[0]
            if canonical_source in normalized_overrides:
                raise ValueError(
                    f"报告 {label} 在规范化后重复定义了 {canonical_source}"
                )
            normalized_overrides[canonical_source] = target
            exterior_by_template_source[canonical_source] = target

        expanded_stack = tuple(
            exterior_by_template_source.get(material, material)
            for material in template_slab_materials
        )
        return tuple(sorted(normalized_overrides.items())), expanded_stack

    @classmethod
    def _layout_report_v2_material_contract(
        cls,
        container: Mapping[str, object],
        *,
        label: str,
        require_cli_args: bool,
    ) -> tuple[tuple[str, ...], tuple[str, ...], tuple[tuple[str, str], ...]]:
        template_slab_materials = cls._layout_report_material_stack(
            container.get("template_slab_materials"),
            f"{label}.template_slab_materials",
        )
        transition_slab_materials = cls._layout_report_material_stack(
            container.get("transition_slab_materials"),
            f"{label}.transition_slab_materials",
        )
        if len(template_slab_materials) != len(transition_slab_materials):
            raise ValueError(f"报告 {label} 的模板与外部 material stack 长度不一致")

        normalized_overrides, expanded_stack = (
            cls._layout_report_material_override_contract(
                container.get("transition_material_overrides"),
                template_slab_materials=template_slab_materials,
                label=f"{label}.transition_material_overrides",
            )
        )
        if expanded_stack != transition_slab_materials:
            raise ValueError(
                f"报告 {label}.transition_material_overrides 按模板 stack "
                "展开后与 transition_slab_materials 不一致"
            )

        compatibility_stack = cls._layout_report_material_stack(
            container.get("slab_materials"),
            f"{label}.slab_materials",
        )
        if compatibility_stack != transition_slab_materials:
            raise ValueError(
                f"报告 {label}.slab_materials 与 transition_slab_materials 不一致"
            )

        if require_cli_args:
            cli_value = container.get("transition_material_cli_args")
            if not isinstance(cli_value, (list, tuple)):
                raise ValueError(
                    f"报告 {label}.transition_material_cli_args 不是数组"
                )
            cli_args = tuple(
                cls._layout_report_text(
                    item,
                    f"{label}.transition_material_cli_args[{index}]",
                )
                for index, item in enumerate(cli_value)
            )
            expected_cli_args = tuple(
                item
                for source, target in normalized_overrides
                for item in (
                    "--transition-material",
                    f"{source}={target}",
                )
            )
            if cli_args != expected_cli_args:
                raise ValueError(
                    f"报告 {label}.transition_material_cli_args "
                    "与规范化后的 transition_material_overrides 不一致"
                )

        return (
            template_slab_materials,
            transition_slab_materials,
            normalized_overrides,
        )

    @classmethod
    def _layout_report_structured_regions(
        cls,
        value: object,
        *,
        required: bool,
    ) -> tuple[tuple[float, float, float, float, float, float], ...]:
        """Read the normalized v4 structured-HEX region identity."""

        if value is None and not required:
            return ()
        if not isinstance(value, (list, tuple)):
            raise ValueError("报告 structured_regions 不是数组")
        regions: list[tuple[float, float, float, float, float, float]] = []
        for index, item in enumerate(value):
            if not isinstance(item, Mapping):
                raise ValueError(f"报告 structured_regions[{index}] 不是对象")
            reported_index = item.get("index")
            if (
                isinstance(reported_index, bool)
                or not isinstance(reported_index, int)
                or reported_index != index
            ):
                raise ValueError(
                    f"报告 structured_regions[{index}].index 必须连续且从 0 开始"
                )
            if item.get("element_type") != "HEX8":
                raise ValueError(
                    f"报告 structured_regions[{index}].element_type 必须为 HEX8"
                )
            if item.get("z_source") != "template_layer_surfaces":
                raise ValueError(
                    f"报告 structured_regions[{index}].z_source "
                    "必须为 template_layer_surfaces"
                )
            region = tuple(
                cls._layout_report_number(
                    item.get(name),
                    f"structured_regions[{index}].{name}",
                )
                for name in (
                    "x_min",
                    "x_max",
                    "y_min",
                    "y_max",
                    "size_x",
                    "size_y",
                )
            )
            x_min, x_max, y_min, y_max, size_x, size_y = region
            if x_max <= x_min or y_max <= y_min:
                raise ValueError(
                    f"报告 structured_regions[{index}] 必须是正面积矩形"
                )
            if size_x <= 0.0 or size_y <= 0.0:
                raise ValueError(
                    f"报告 structured_regions[{index}] XY 尺寸必须为正数"
                )
            regions.append(
                (x_min, x_max, y_min, y_max, size_x, size_y)
            )
        return tuple(regions)

    @classmethod
    def _layout_report_identity_from_parameters(
        cls,
        parameters: Mapping[str, object],
    ) -> _LayoutReportIdentity:
        schema = parameters.get("schema")
        if schema not in {
            "easymesh-bump-layout-v1",
            "easymesh-bump-layout-v2",
            "easymesh-bump-layout-v3",
            "easymesh-bump-layout-v4",
        }:
            raise ValueError("报告不是受支持的 EasyMesh bump-layout schema")
        source = Path(
            cls._layout_report_text(parameters.get("source_path"), "source_path")
        ).expanduser().resolve()
        bounds = parameters.get("bounds")
        if not isinstance(bounds, Mapping):
            raise ValueError("报告缺少 bounds")
        bounds_mm = tuple(
            cls._layout_report_number(bounds.get(name), f"bounds.{name}")
            for name in ("x_min", "x_max", "y_min", "y_max")
        )
        templates_value = parameters.get("templates")
        if not isinstance(templates_value, (list, tuple)):
            raise ValueError("报告 templates 不是数组")
        templates: list[tuple[str, Path]] = []
        for index, item in enumerate(templates_value):
            if not isinstance(item, Mapping):
                raise ValueError(f"报告 templates[{index}] 不是对象")
            alias = cls._layout_report_text(item.get("alias"), f"templates[{index}].alias")
            mesh_path = Path(
                cls._layout_report_text(
                    item.get("mesh_path"), f"templates[{index}].mesh_path"
                )
            ).expanduser().resolve()
            templates.append((alias, mesh_path))
        instances_value = parameters.get("instances")
        if not isinstance(instances_value, (list, tuple)):
            raise ValueError("报告 instances 不是数组")
        instances: list[tuple[float, float, str]] = []
        for index, item in enumerate(instances_value):
            if not isinstance(item, Mapping):
                raise ValueError(f"报告 instances[{index}] 不是对象")
            instances.append(
                (
                    cls._layout_report_number(item.get("x"), f"instances[{index}].x"),
                    cls._layout_report_number(item.get("y"), f"instances[{index}].y"),
                    cls._layout_report_text(
                        item.get("template"), f"instances[{index}].template"
                    ),
                )
            )
        structured_regions = (
            cls._layout_report_structured_regions(
                parameters.get("structured_regions"),
                required=True,
            )
            if schema == "easymesh-bump-layout-v4"
            else ()
        )
        if schema == "easymesh-bump-layout-v1":
            z_levels_mm = None
            void_slab_intervals_mm = None
            template_slab_components = ()
            transition_slab_components = ()
            template_slab_materials = cls._layout_report_material_stack(
                parameters.get("slab_materials"), "slab_materials"
            )
            transition_slab_materials = template_slab_materials
        else:
            z_levels_mm, void_slab_intervals_mm = (
                cls._layout_report_outer_geometry(
                    parameters,
                    label="parameters",
                    values_are_um=False,
                )
            )
            (
                template_slab_materials,
                transition_slab_materials,
                _normalized_overrides,
            ) = cls._layout_report_v2_material_contract(
                parameters,
                label="parameters",
                require_cli_args=True,
            )
            (
                template_slab_components,
                transition_slab_components,
            ) = cls._layout_report_component_contract(
                parameters,
                label="parameters",
                expected_slab_count=len(template_slab_materials),
                required=schema
                in {
                    "easymesh-bump-layout-v3",
                    "easymesh-bump-layout-v4",
                },
            )
        return _LayoutReportIdentity(
            source=source,
            far_field_um=1000.0
            * cls._layout_report_number(
                parameters.get("far_field_size"), "far_field_size"
            ),
            transition_um=1000.0
            * cls._layout_report_number(
                parameters.get("transition_distance"), "transition_distance"
            ),
            bounds_mm=(bounds_mm[0], bounds_mm[1], bounds_mm[2], bounds_mm[3]),
            templates=tuple(templates),
            instances=tuple(instances),
            structured_regions=structured_regions,
            z_levels_mm=z_levels_mm,
            void_slab_intervals_mm=void_slab_intervals_mm,
            template_slab_components=template_slab_components,
            transition_slab_components=transition_slab_components,
            template_slab_materials=template_slab_materials,
            transition_slab_materials=transition_slab_materials,
        )

    @staticmethod
    def _layout_number_sequences_match(
        actual: tuple[float, ...],
        expected: tuple[float, ...],
    ) -> bool:
        return len(actual) == len(expected) and all(
            math.isclose(
                actual_value,
                expected_value,
                rel_tol=1.0e-12,
                abs_tol=1.0e-12,
            )
            for actual_value, expected_value in zip(actual, expected, strict=True)
        )

    @classmethod
    def _layout_interval_sequences_match(
        cls,
        actual: tuple[tuple[float, float], ...],
        expected: tuple[tuple[float, float], ...],
    ) -> bool:
        return len(actual) == len(expected) and all(
            cls._layout_number_sequences_match(actual_interval, expected_interval)
            for actual_interval, expected_interval in zip(
                actual,
                expected,
                strict=True,
            )
        )

    @classmethod
    def _layout_report_identities_match(
        cls,
        actual: _LayoutReportIdentity,
        expected: _LayoutReportIdentity,
    ) -> bool:
        if (
            actual.source != expected.source
            or actual.templates != expected.templates
            or len(actual.instances) != len(expected.instances)
            or len(actual.structured_regions) != len(expected.structured_regions)
            or actual.template_slab_components
            != expected.template_slab_components
            or actual.transition_slab_components
            != expected.transition_slab_components
            or actual.template_slab_materials
            != expected.template_slab_materials
            or actual.transition_slab_materials
            != expected.transition_slab_materials
        ):
            return False
        if not all(
            cls._layout_number_sequences_match(actual_region, expected_region)
            for actual_region, expected_region in zip(
                actual.structured_regions,
                expected.structured_regions,
                strict=True,
            )
        ):
            return False
        # v1 reports predate the outer-geometry contract. Keep reading them as
        # legacy reports, while requiring every v2 report to match the complete
        # normalized Z stack and its intentionally unmeshed outer slabs.
        if actual.z_levels_mm is None:
            if expected.void_slab_intervals_mm:
                return False
        else:
            if expected.z_levels_mm is None or not cls._layout_number_sequences_match(
                actual.z_levels_mm,
                expected.z_levels_mm,
            ):
                return False
            if (
                actual.void_slab_intervals_mm is None
                or expected.void_slab_intervals_mm is None
                or not cls._layout_interval_sequences_match(
                    actual.void_slab_intervals_mm,
                    expected.void_slab_intervals_mm,
                )
            ):
                return False
        if not math.isclose(
            actual.far_field_um,
            expected.far_field_um,
            rel_tol=1.0e-12,
            abs_tol=1.0e-9,
        ) or not math.isclose(
            actual.transition_um,
            expected.transition_um,
            rel_tol=1.0e-12,
            abs_tol=1.0e-9,
        ):
            return False
        if not all(
            math.isclose(actual_value, expected_value, rel_tol=1.0e-12, abs_tol=1.0e-12)
            for actual_value, expected_value in zip(
                actual.bounds_mm, expected.bounds_mm, strict=True
            )
        ):
            return False
        return all(
            actual_template == expected_template
            and math.isclose(actual_x, expected_x, rel_tol=1.0e-12, abs_tol=1.0e-12)
            and math.isclose(actual_y, expected_y, rel_tol=1.0e-12, abs_tol=1.0e-12)
            for (actual_x, actual_y, actual_template), (
                expected_x,
                expected_y,
                expected_template,
            ) in zip(actual.instances, expected.instances, strict=True)
        )

    def _load_existing_layout_report(self) -> None:
        layout = self._bump_layout
        if self._loaded_layout_source is None or layout is None:
            return
        output_text = self.layout_output_edit.text().strip()
        if not output_text:
            return
        output = self._workspace_mesh_output(output_text)
        report_path = output.with_suffix(".report.json")
        if not report_path.exists():
            return
        try:
            payload = json.loads(report_path.read_text(encoding="utf-8"))
            if not isinstance(payload, Mapping):
                raise ValueError("报告根节点不是对象")
            parameters = payload.get("parameters")
            if not isinstance(parameters, Mapping):
                raise ValueError("报告缺少 parameters")
            actual_identity = self._layout_report_identity_from_parameters(parameters)
            expected_identity = self._current_layout_job_report_identity()
            if expected_identity is None:
                raise ValueError("当前页面尚未形成稳定的材料映射快照")
            if self._layout_dependency_signatures:
                dependency_mtime = max(
                    signature[1]
                    for signature in self._layout_dependency_signatures.values()
                )
            else:
                dependency_paths = (
                    self._loaded_layout_source,
                    *(template.mesh_path for template in layout.templates),
                )
                dependency_mtime = max(
                    path.stat().st_mtime_ns for path in dependency_paths
                )
            matches = (
                self._layout_report_identities_match(
                    actual_identity,
                    expected_identity,
                )
                and report_path.stat().st_mtime_ns >= dependency_mtime
            )
        except (OSError, UnicodeError, ValueError, TypeError, json.JSONDecodeError):
            return
        if matches:
            self._render_layout_report(report_path, payload=payload)
        else:
            self.layout_report_view.setStyleSheet("")
            self.layout_report_view.setPlainText(
                "输出目录中存在旧报告，但其 .loc、模板 Z/air gap、过渡参数或"
                "外部材料映射与当前页面不同；"
                "生成后再显示本次复核结果。"
            )

    @staticmethod
    def _report_metric(value: object, *, digits: int = 4) -> str:
        if isinstance(value, bool):
            return "—"
        if isinstance(value, int):
            return f"{value:,}"
        try:
            number = float(value)
        except (TypeError, ValueError):
            return "—"
        if not math.isfinite(number):
            return "—"
        return f"{number:.{digits}g}"

    @staticmethod
    def _mesh_path_for_report(report_path: Path) -> Path:
        suffix = ".report.json"
        if report_path.name.endswith(suffix):
            return report_path.with_name(report_path.name[: -len(suffix)] + ".msh")
        return report_path.with_suffix(".msh")

    @staticmethod
    def _sha256_file(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            while chunk := stream.read(1024 * 1024):
                digest.update(chunk)
        return digest.hexdigest()

    def _validate_cdb_report_payload(
        self,
        report_path: Path,
        identity: _CdbJobIdentity,
    ) -> Mapping[str, object]:
        payload = json.loads(report_path.read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("报告根节点不是对象")

        def _reported_path(name: str) -> Path:
            value = payload.get(name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"报告缺少有效的 {name}")
            return Path(value).expanduser().resolve()

        def _count(name: str) -> int:
            value = payload.get(name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"报告 {name} 必须是非负整数")
            return value

        def _optional_count(name: str) -> int:
            # CDB reports written before mixed-cell support have only the
            # HEX8/WEDGE6 counters.  Their missing new-kind counts are exactly
            # zero, while an explicitly present malformed value must fail.
            return 0 if name not in payload else _count(name)

        expected_report = self._report_path_for_job(identity.output, "cdb")
        if _reported_path("source_mesh_path") != identity.source:
            raise ValueError("报告 source_mesh_path 与该 worker 输入不一致")
        if _reported_path("cdb_path") != identity.output:
            raise ValueError("报告 cdb_path 与该 worker 输出不一致")
        if _reported_path("report_path") != expected_report:
            raise ValueError("报告 report_path 与约定的 .cdb.report.json 不一致")
        if report_path.resolve() != expected_report:
            raise ValueError("读取的报告路径不属于该 CDB 输出")

        if payload.get("element_type") != identity.element_type:
            raise ValueError("报告 SOLID 类型与该 worker 启动选项不一致")
        try:
            reported_scale = float(payload.get("coordinate_scale"))
        except (TypeError, ValueError) as exc:
            raise ValueError("报告 coordinate_scale 无效") from exc
        if not math.isclose(
            reported_scale,
            identity.coordinate_scale,
            rel_tol=1.0e-12,
            abs_tol=1.0e-15,
        ):
            raise ValueError("报告坐标比例与该 worker 启动选项不一致")
        if payload.get("units_label") != identity.units_label:
            raise ValueError("报告 /UNITS 标签与该 worker 启动选项不一致")
        self._validated_package_v2_artifact(
            payload.get("source_mesh_artifact"),
            expected_path=identity.source,
            field_name="source MSH",
        )
        if self._layout_dependency_signature(identity.source) != identity.source_signature:
            raise ValueError("输入 MSH 在转换期间发生了变化")

        source_nodes = _count("source_node_count")
        output_nodes = _count("node_count")
        generated_nodes = _count("generated_midside_node_count")
        elements = _count("element_count")
        hex_count = _count("hex_count")
        wedge_count = _count("wedge_count")
        tet_count = _optional_count("tet_count")
        pyramid_count = _optional_count("pyramid_count")
        component_count = _count("component_count")
        hypermesh_component_count = _count("hypermesh_component_count")
        _count("overlapping_element_count")
        _count("max_components_per_element")
        if output_nodes != source_nodes + generated_nodes:
            raise ValueError("报告节点计数不满足 source + midside = output")
        if elements != hex_count + wedge_count + tet_count + pyramid_count:
            raise ValueError(
                "报告单元计数不满足 "
                "HEX8 + WEDGE6 + TET4 + PYRAMID5 = total"
            )

        component_mappings = payload.get("component_mappings")
        primary_partition = payload.get("primary_partition")
        hypermesh_components = payload.get("hypermesh_components")
        if not isinstance(component_mappings, list):
            raise ValueError("报告缺少 component_mappings")
        if component_count != len(component_mappings):
            raise ValueError("报告 component_count 与映射数量不一致")
        if not isinstance(primary_partition, list):
            raise ValueError("报告缺少 primary_partition")
        if not isinstance(hypermesh_components, list):
            raise ValueError("报告缺少 hypermesh_components")
        if hypermesh_component_count != len(hypermesh_components):
            raise ValueError(
                "报告 hypermesh_component_count 与映射数量不一致"
            )

        def _component_integer(
            mapping: Mapping[str, object],
            name: str,
            *,
            positive: bool = False,
        ) -> int:
            value = mapping.get(name)
            minimum = 1 if positive else 0
            if (
                isinstance(value, bool)
                or not isinstance(value, int)
                or value < minimum
            ):
                qualifier = "正整数" if positive else "非负整数"
                raise ValueError(
                    f"报告 hypermesh_components.{name} 必须是{qualifier}"
                )
            return value

        def _component_name(mapping: Mapping[str, object], name: str) -> str:
            value = mapping.get(name)
            if (
                not isinstance(value, str)
                or not value.strip()
                or value != value.strip()
            ):
                raise ValueError(
                    f"报告 hypermesh_components.{name} 必须是非空名称"
                )
            return value

        primary_materials_by_id: dict[int, str] = {}
        for mapping in primary_partition:
            if not isinstance(mapping, Mapping):
                raise ValueError("primary_partition 项不是对象")
            material_id = mapping.get("material_id")
            if (
                isinstance(material_id, bool)
                or not isinstance(material_id, int)
                or material_id <= 0
            ):
                raise ValueError(
                    "报告 primary_partition.material_id 必须是正整数"
                )
            physical_name = mapping.get("physical_name")
            if (
                not isinstance(physical_name, str)
                or not physical_name.strip()
                or physical_name != physical_name.strip()
            ):
                raise ValueError(
                    "报告 primary_partition.physical_name 必须是非空名称"
                )
            if material_id in primary_materials_by_id:
                raise ValueError("报告 primary_partition material_id 重复")
            primary_materials_by_id[material_id] = physical_name

        component_ids: set[int] = set()
        component_names: set[str] = set()
        material_bindings: dict[str, tuple[int, str]] = {}
        hypermesh_element_total = 0
        for mapping in hypermesh_components:
            if not isinstance(mapping, Mapping):
                raise ValueError("hypermesh_components 项不是对象")

            component_id = _component_integer(
                mapping,
                "component_id",
                positive=True,
            )
            component_name = _component_name(mapping, "component_name")
            origin = _component_name(mapping, "origin")
            element_type_id = _component_integer(
                mapping,
                "element_type_id",
                positive=True,
            )
            material_id = _component_integer(
                mapping,
                "material_id",
                positive=True,
            )
            material_physical_name = _component_name(
                mapping,
                "material_physical_name",
            )
            material_name = _component_name(mapping, "material_name")
            real_constant_id = _component_integer(
                mapping,
                "real_constant_id",
            )
            section_id = _component_integer(mapping, "section_id")
            element_count = _component_integer(
                mapping,
                "element_count",
                positive=True,
            )

            expected_physical_name = primary_materials_by_id.get(material_id)
            if expected_physical_name is None:
                raise ValueError(
                    "报告 HyperMesh Component material_id 不属于 primary_partition"
                )
            if material_physical_name != expected_physical_name:
                raise ValueError(
                    "报告 HyperMesh Component 的 material_id/"
                    "material_physical_name 与 primary_partition 不一致"
                )

            expected_type_by_origin = {"TEMPLATE": 1, "TRANSITION": 2}
            expected_type_id = expected_type_by_origin.get(origin)
            if expected_type_id is None:
                raise ValueError(
                    "报告 HyperMesh Component origin 只支持 TEMPLATE/TRANSITION"
                )
            if element_type_id != expected_type_id:
                raise ValueError(
                    "报告 HyperMesh Component origin 与 element_type_id 不一致"
                )
            if real_constant_id != 0 or section_id != 0:
                raise ValueError(
                    "报告 HyperMesh Component 的 REAL/SECNUM 必须保持为 0"
                )
            if not material_name.startswith("MAT_") or len(material_name) <= 4:
                raise ValueError(
                    "报告 HyperMesh material_name 必须采用 MAT_<名称>"
                )

            normalized_component_name = component_name.upper()
            if normalized_component_name in component_names:
                raise ValueError("报告 HyperMesh Component 名称重复")
            component_names.add(normalized_component_name)
            if component_id in component_ids:
                raise ValueError("报告 HyperMesh Component ID 重复")
            component_ids.add(component_id)

            normalized_physical_name = material_physical_name.upper()
            material_binding = (material_id, material_name)
            previous_binding = material_bindings.setdefault(
                normalized_physical_name,
                material_binding,
            )
            if previous_binding != material_binding:
                raise ValueError(
                    "报告同一 material_physical_name 的 MAT ID/名称不一致"
                )
            hypermesh_element_total += element_count

        if hypermesh_element_total != elements:
            raise ValueError(
                "报告 HyperMesh Component 元素总数与体单元总数不一致"
            )

        artifact = payload.get("cdb_artifact")
        if not isinstance(artifact, Mapping):
            raise ValueError("报告缺少 cdb_artifact")
        artifact_path = artifact.get("path")
        if not isinstance(artifact_path, str):
            raise ValueError("报告 cdb_artifact.path 无效")
        if Path(artifact_path).expanduser().resolve() != identity.output:
            raise ValueError("报告 artifact 路径与该 worker 输出不一致")
        if not identity.output.is_file():
            raise ValueError("worker 未写出 CDB 文件")
        actual_size = identity.output.stat().st_size
        artifact_size = artifact.get("size_bytes")
        if (
            isinstance(artifact_size, bool)
            or not isinstance(artifact_size, int)
            or artifact_size != actual_size
        ):
            raise ValueError("CDB 文件大小与报告不一致")
        artifact_sha = artifact.get("sha256")
        normalized_sha = artifact_sha.lower() if isinstance(artifact_sha, str) else ""
        if len(normalized_sha) != 64 or any(
            character not in "0123456789abcdef" for character in normalized_sha
        ):
            raise ValueError("报告 CDB SHA-256 摘要无效")
        if self._sha256_file(identity.output) != normalized_sha:
            raise ValueError("CDB SHA-256 与报告不一致")
        return payload

    def _render_cdb_job_report(
        self,
        report_path: Path,
        identity: _CdbJobIdentity,
    ) -> bool:
        try:
            payload = self._validate_cdb_report_payload(report_path, identity)
            artifact = payload["cdb_artifact"]
            assert isinstance(artifact, Mapping)
            component_mappings = payload["component_mappings"]
            primary_partition = payload["primary_partition"]
            hypermesh_components = payload["hypermesh_components"]
            assert isinstance(component_mappings, list)
            assert isinstance(primary_partition, list)
            assert isinstance(hypermesh_components, list)

            lines = [
                "MSH → ANSYS CDB 转换完成",
                "",
                f"输入：{identity.source}",
                f"输出：{identity.output}",
                f"报告：{report_path}",
                f"ANSYS 单元：SOLID{identity.element_type}",
                (
                    "节点："
                    f"{int(payload['source_node_count']):,} → "
                    f"{int(payload['node_count']):,}"
                    f"（新增中边节点 {int(payload['generated_midside_node_count']):,}）"
                ),
                (
                    f"体单元：{int(payload['element_count']):,} "
                    f"（HEX8 {int(payload['hex_count']):,} / "
                    f"WEDGE6 {int(payload['wedge_count']):,} / "
                    f"TET4 {int(payload.get('tet_count', 0)):,} / "
                    f"PYRAMID5 {int(payload.get('pyramid_count', 0)):,}）"
                ),
                (
                    f"CMBLOCK：{int(payload['component_count']):,}；"
                    f"多组归属单元 {int(payload['overlapping_element_count']):,}；"
                    f"单元最大组数 {int(payload['max_components_per_element']):,}"
                ),
                (
                    "主分区："
                    f"{payload.get('primary_partition_kind', '—')} "
                    f"({len(primary_partition):,} 个互斥 MAT 分区)"
                ),
                (
                    "HyperMesh Components："
                    f"{int(payload['hypermesh_component_count']):,}；"
                    "互斥来源 × component 单元归属，共享 MAT"
                ),
                (
                    f"坐标比例：{identity.coordinate_scale:g}；"
                    f"/UNITS：{identity.units_label or 'NONE'}"
                ),
                f"CDB 大小：{int(artifact['size_bytes']):,} bytes",
                f"SHA-256：{artifact['sha256']}",
            ]
            if component_mappings:
                lines.extend(("", "MSH Element Sets → CMBLOCK："))
                for mapping in component_mappings:
                    if not isinstance(mapping, Mapping):
                        raise ValueError("component_mappings 项不是对象")
                    lines.append(
                        "  "
                        f"{mapping.get('physical_name', '—')} → "
                        f"{mapping.get('component_name', '—')} "
                        f"({int(mapping.get('element_count', 0)):,} elements)"
                    )
            if hypermesh_components:
                lines.extend(("", "HyperMesh Components（共享 MAT）："))
                for mapping in hypermesh_components:
                    if not isinstance(mapping, Mapping):
                        raise ValueError("hypermesh_components 项不是对象")
                    lines.append(
                        "  "
                        f"{mapping['component_name']} [{mapping['origin']}] → "
                        f"TYPE {int(mapping['element_type_id'])} / "
                        f"MAT {int(mapping['material_id'])} "
                        f"{mapping['material_name']} "
                        f"({mapping['material_physical_name']}; "
                        f"{int(mapping['element_count']):,} elements)"
                    )
        except (
            AssertionError,
            KeyError,
            OSError,
            UnicodeError,
            ValueError,
            TypeError,
            json.JSONDecodeError,
        ) as exc:
            self._rendered_cdb_identity = None
            self.cdb_report_view.setStyleSheet(self._semantic_style("error"))
            self.cdb_report_view.setPlainText(
                f"CDB 报告复核失败：{report_path}\n{exc}"
            )
            return False

        self._rendered_cdb_identity = identity
        self.cdb_report_view.setStyleSheet("")
        self.cdb_report_view.setPlainText("\n".join(lines))
        return True

    def _validate_layout_report_payload(
        self,
        report_path: Path,
        *,
        payload: object | None = None,
    ) -> _ValidatedLayoutReport:
        if payload is None:
            payload = json.loads(report_path.read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("报告根节点不是对象")
        quality = payload.get("quality")
        parameters = payload.get("parameters")
        if not isinstance(quality, Mapping) or not isinstance(parameters, Mapping):
            raise ValueError("报告缺少 parameters/quality")
        report_identity = self._layout_report_identity_from_parameters(parameters)
        schema = parameters.get("schema")
        structured_checks: tuple[tuple[str, bool], ...] = ()
        if schema in {
            "easymesh-bump-layout-v2",
            "easymesh-bump-layout-v3",
            "easymesh-bump-layout-v4",
        }:
            (
                parameter_template_materials,
                parameter_transition_materials,
                parameter_material_overrides,
            ) = self._layout_report_v2_material_contract(
                parameters,
                label="parameters",
                require_cli_args=True,
            )
            (
                quality_template_materials,
                quality_transition_materials,
                quality_material_overrides,
            ) = self._layout_report_v2_material_contract(
                quality,
                label="quality",
                require_cli_args=False,
            )
            if quality_template_materials != parameter_template_materials:
                raise ValueError(
                    "报告 quality.template_slab_materials 与 parameters 不一致"
                )
            if quality_transition_materials != parameter_transition_materials:
                raise ValueError(
                    "报告 quality.transition_slab_materials 与 parameters 不一致"
                )
            if quality_material_overrides != parameter_material_overrides:
                raise ValueError(
                    "报告 quality.transition_material_overrides 与 parameters 不一致"
                )
            (
                parameter_template_components,
                parameter_transition_components,
            ) = self._layout_report_component_contract(
                parameters,
                label="parameters",
                expected_slab_count=len(parameter_template_materials),
                required=schema
                in {
                    "easymesh-bump-layout-v3",
                    "easymesh-bump-layout-v4",
                },
            )
            (
                quality_template_components,
                quality_transition_components,
            ) = self._layout_report_component_contract(
                quality,
                label="quality",
                expected_slab_count=len(quality_template_materials),
                required=schema
                in {
                    "easymesh-bump-layout-v3",
                    "easymesh-bump-layout-v4",
                },
            )
            if quality_template_components != parameter_template_components:
                raise ValueError(
                    "报告 quality.template_slab_components 与 parameters 不一致"
                )
            if quality_transition_components != parameter_transition_components:
                raise ValueError(
                    "报告 quality.transition_slab_components 与 parameters 不一致"
                )
            quality_z_levels_mm, quality_void_slab_intervals_mm = (
                self._layout_report_outer_geometry(
                    quality,
                    label="quality",
                    values_are_um=True,
                )
            )
            assert report_identity.z_levels_mm is not None
            assert report_identity.void_slab_intervals_mm is not None
            if not self._layout_number_sequences_match(
                quality_z_levels_mm,
                report_identity.z_levels_mm,
            ):
                raise ValueError(
                    "报告 quality.z_levels_um 与 parameters.z_levels 不一致"
                )
            if not self._layout_interval_sequences_match(
                quality_void_slab_intervals_mm,
                report_identity.void_slab_intervals_mm,
            ):
                raise ValueError(
                    "报告 quality.void_slab_intervals_um "
                    "与 parameters.void_slab_intervals 不一致"
                )
        if schema == "easymesh-bump-layout-v4":
            def quality_count(name: str) -> int:
                value = quality.get(name)
                if (
                    isinstance(value, bool)
                    or not isinstance(value, int)
                    or value < 0
                ):
                    raise ValueError(f"报告 quality.{name} 必须是非负整数")
                return value

            structured_region_count = quality_count("structured_region_count")
            planar_quad_count = quality_count("planar_quad_count")
            planar_triangle_count = quality_count("planar_triangle_count")
            transition_hex_count = quality_count("transition_hex_count")
            transition_wedge_count = quality_count("transition_wedge_count")
            transition_element_count = quality_count("transition_element_count")
            if structured_region_count != len(report_identity.structured_regions):
                raise ValueError(
                    "报告 quality.structured_region_count 与 parameters 不一致"
                )

            expected_planar_quad_count = 0
            for index, region in enumerate(report_identity.structured_regions):
                x_min, x_max, y_min, y_max, size_x, size_y = region
                x_ratio = (x_max - x_min) / size_x
                y_ratio = (y_max - y_min) / size_y
                x_cells = round(x_ratio)
                y_cells = round(y_ratio)
                if (
                    x_cells <= 0
                    or y_cells <= 0
                    or not math.isclose(
                        x_ratio,
                        x_cells,
                        rel_tol=1.0e-10,
                        abs_tol=1.0e-10,
                    )
                    or not math.isclose(
                        y_ratio,
                        y_cells,
                        rel_tol=1.0e-10,
                        abs_tol=1.0e-10,
                    )
                ):
                    raise ValueError(
                        f"报告 structured_regions[{index}] 的 XY 范围"
                        "不能被指定尺寸整除"
                    )
                expected_planar_quad_count += x_cells * y_cells
            if planar_quad_count != expected_planar_quad_count:
                raise ValueError(
                    "报告 quality.planar_quad_count 与局部 HEX XY 划分不一致"
                )
            assert report_identity.z_levels_mm is not None
            assert report_identity.void_slab_intervals_mm is not None
            active_slab_count = (
                len(report_identity.z_levels_mm)
                - 1
                - len(report_identity.void_slab_intervals_mm)
            )
            if transition_hex_count != planar_quad_count * active_slab_count:
                raise ValueError(
                    "报告 quality.transition_hex_count 与 XY QUAD 及"
                    "模板有效 Z slabs 数不一致"
                )
            if transition_wedge_count != planar_triangle_count * active_slab_count:
                raise ValueError(
                    "报告 quality.transition_wedge_count 与 XY TRI 及"
                    "模板有效 Z slabs 数不一致"
                )
            if transition_element_count != (
                transition_hex_count + transition_wedge_count
            ):
                raise ValueError(
                    "报告 quality.transition_element_count 与 HEX8/WEDGE6 "
                    "过渡单元总数不一致"
                )
            structured_checks = (
                (
                    "局部 HEX 区域 XY 边界精确保持",
                    quality.get("structured_region_bounds_preserved") is True,
                ),
                (
                    "局部 HEX 区域 XY 方格尺寸精确保持",
                    quality.get("structured_region_xy_sizes_preserved") is True,
                ),
                (
                    "指定区域内仅生成 HEX8",
                    quality.get("structured_region_hex8_only") is True,
                ),
                (
                    "局部 HEX 高度继承模板 Layer surfaces",
                    quality.get("structured_region_z_surfaces_preserved") is True,
                ),
                (
                    "局部 HEX/外部过渡接口逐面共形",
                    quality.get(
                        "structured_region_transition_interface_conformal"
                    )
                    is True,
                ),
                (
                    "局部 HEX component/material 符合过渡映射",
                    quality.get(
                        "structured_region_material_assignment_verified"
                    )
                    is True,
                ),
            )
        expected_mesh = self._mesh_path_for_report(report_path).resolve()
        reported_mesh = Path(str(quality.get("mesh_path", ""))).expanduser().resolve()
        if reported_mesh != expected_mesh:
            raise ValueError(
                f"报告绑定的 mesh_path 与当前输出不一致：{reported_mesh} != {expected_mesh}"
            )
        if not expected_mesh.is_file():
            raise ValueError(f"报告对应的 MSH 不存在：{expected_mesh}")
        artifact = payload.get("mesh_artifact")
        if not isinstance(artifact, Mapping):
            raise ValueError("报告缺少最终 MSH identity")
        artifact_path = Path(str(artifact.get("path", ""))).expanduser().resolve()
        if artifact_path != expected_mesh:
            raise ValueError("mesh_artifact.path 与当前输出不一致")
        expected_size = artifact.get("size_bytes")
        if (
            not isinstance(expected_size, int)
            or isinstance(expected_size, bool)
            or expected_size != expected_mesh.stat().st_size
        ):
            raise ValueError("最终 MSH 字节数与报告不一致")
        expected_sha256 = artifact.get("sha256")
        if (
            not isinstance(expected_sha256, str)
            or len(expected_sha256) != 64
            or self._sha256_file(expected_mesh) != expected_sha256.lower()
        ):
            raise ValueError("最终 MSH SHA-256 与报告不一致")

        hard_constraints = parameters.get("hard_constraints", {})
        checks = (
            (
                "模板节点与 connectivity 原样保留",
                quality.get("template_connectivity_preserved") is True,
            ),
            (
                "模板内部材料分配原样保留",
                schema == "easymesh-bump-layout-v1"
                or (
                    isinstance(hard_constraints, Mapping)
                    and hard_constraints.get("template_materials_unchanged")
                    is True
                ),
            ),
            (
                "模板边缘每个 component surface 高度不变",
                quality.get("component_surface_heights_preserved") is True,
            ),
            (
                "air gap 外缘空洞保持无网格",
                schema == "easymesh-bump-layout-v1"
                or (
                    isinstance(hard_constraints, Mapping)
                    and hard_constraints.get("outer_void_slabs_left_unmeshed")
                    is True
                ),
            ),
            (
                "模板/过渡接口逐面共形",
                quality.get("interface_conformal") is True,
            ),
            (
                "外部过渡 WEDGE6/HEX8 材料符合用户映射",
                (
                    quality.get(
                        "interface_exterior_material_assignment_verified"
                    )
                    is True
                    if schema in {
                        "easymesh-bump-layout-v2",
                        "easymesh-bump-layout-v3",
                        "easymesh-bump-layout-v4",
                    }
                    else report_identity.template_slab_materials
                    == report_identity.transition_slab_materials
                ),
            ),
            (
                "写出 MSH 已重开并复核 connectivity/Physical Groups",
                quality.get("written_mesh_reopened_verified") is True,
            ),
            (
                "无重复节点",
                isinstance(quality.get("duplicate_node_count"), int)
                and not isinstance(quality.get("duplicate_node_count"), bool)
                and quality.get("duplicate_node_count") == 0,
            ),
            *structured_checks,
        )
        native_ring_preserved = (
            isinstance(hard_constraints, Mapping)
            and hard_constraints.get("native_ring_topology_preserved") is True
        )
        return _ValidatedLayoutReport(
            quality=quality,
            parameters=parameters,
            expected_mesh=expected_mesh,
            checks=checks,
            native_ring_preserved=native_ring_preserved,
        )

    def _render_layout_report(
        self,
        report_path: Path,
        *,
        payload: object | None = None,
    ) -> bool:
        try:
            validation = self._validate_layout_report_payload(
                report_path,
                payload=payload,
            )
            quality = validation.quality
            expected_mesh = validation.expected_mesh
            checks = validation.checks
            native_ring_preserved = validation.native_ring_preserved
            all_checks_pass = validation.all_checks_pass
            report_identity = self._layout_report_identity_from_parameters(
                validation.parameters
            )
            material_mappings = tuple(
                dict.fromkeys(
                    zip(
                        report_identity.template_slab_materials,
                        report_identity.transition_slab_materials,
                    )
                )
            )
            changed_material_mappings = tuple(
                f"{source} → {target}"
                for source, target in material_mappings
                if source != target
            )
            material_mapping_text = (
                "；".join(changed_material_mappings)
                if changed_material_mappings
                else "全部继承模板边缘材料"
            )
            component_mappings = tuple(
                dict.fromkeys(
                    zip(
                        report_identity.template_slab_components,
                        report_identity.transition_slab_components,
                    )
                )
            )
            component_mapping_text = (
                "；".join(
                    source if source == target else f"{source} → {target}"
                    for source, target in component_mappings
                )
                if component_mappings
                else "旧报告未记录 component stack"
            )

            ring_counts = quality.get("ring_node_counts", ())
            ring_text = (
                "/".join(str(value) for value in ring_counts)
                if isinstance(ring_counts, (list, tuple))
                else "—"
            )
            structured_lines = (
                (
                    "局部结构化 HEX8：区域="
                    f"{self._report_metric(quality.get('structured_region_count'))}；"
                    "XY QUAD/层="
                    f"{self._report_metric(quality.get('planar_quad_count'))}；"
                    "新过渡 HEX8="
                    f"{self._report_metric(quality.get('transition_hex_count'))}；"
                    "Z=继承模板 Layer surfaces"
                ),
            ) if validation.parameters.get("schema") == "easymesh-bump-layout-v4" else ()
            lines = [
                f"网格：{expected_mesh}",
                (
                    "节点 / 体单元："
                    f"{self._report_metric(quality.get('node_count'))} / "
                    f"{self._report_metric(quality.get('element_count'))}"
                ),
                (
                    "模板 / 新过渡单元："
                    f"{self._report_metric(quality.get('template_element_count'))} / "
                    f"{self._report_metric(quality.get('transition_element_count'))}；"
                    f"HEX8 / WEDGE6="
                    f"{self._report_metric(quality.get('hex_count'))} / "
                    f"{self._report_metric(quality.get('wedge_count'))}"
                ),
                (
                    "原生 ring 节点（逐实例）："
                    f"{ring_text}；接口 QUAD4="
                    f"{self._report_metric(quality.get('interface_face_count'))}；"
                    f"最窄净空={self._report_metric(quality.get('minimum_geometric_clearance_um'))} µm"
                ),
                f"边缘 component 衔接：{component_mapping_text}",
                f"外部材料映射：{material_mapping_text}",
                *structured_lines,
                (
                    "二维过渡：minSICN="
                    f"{self._report_metric(quality.get('planar_min_sicn'))}，minSIGE="
                    f"{self._report_metric(quality.get('planar_min_sige'))}；"
                    "接口邻域 minSICN/minSIGE="
                    f"{self._report_metric(quality.get('interface_planar_min_sicn'))}/"
                    f"{self._report_metric(quality.get('interface_planar_min_sige'))}"
                ),
                (
                    "三维新过渡体（WEDGE6/HEX8）：minSJ="
                    f"{self._report_metric(quality.get('transition_min_scaled_jacobian'))}，"
                    f"minSIGE={self._report_metric(quality.get('transition_min_sige'))}，"
                    f"minSICN={self._report_metric(quality.get('transition_min_sicn'))}"
                    "（薄 Z 层各向异性会降低 SICN）"
                ),
                "",
                "硬约束复核：",
                f"{'✓' if native_ring_preserved else '✗'} 各模板保留自己的原生 ring topology",
                *(f"{'✓' if passed else '✗'} {label}" for label, passed in checks),
            ]
            warnings = quality.get("quality_warnings", ())
            advisories = quality.get("quality_advisories", ())
            if isinstance(warnings, (list, tuple)) and warnings:
                lines.extend(("", "形状质量警告：", *(f"• {item}" for item in warnings)))
            if isinstance(advisories, (list, tuple)) and advisories:
                lines.extend(("", "各向异性提示：", *(f"• {item}" for item in advisories)))
        except (OSError, UnicodeError, ValueError, TypeError, json.JSONDecodeError) as exc:
            self._rendered_layout_report_settings = None
            self.layout_report_view.setStyleSheet(self._semantic_style("error"))
            self.layout_report_view.setPlainText(f"质量报告不可读：{report_path}\n{exc}")
            return False

        self.layout_report_view.setStyleSheet(
            "" if all_checks_pass else self._semantic_style("error")
        )
        self.layout_report_view.setPlainText("\n".join(lines))
        self._rendered_layout_report_settings = self._current_layout_report_settings()
        return all_checks_pass

    def _validate_layout_job_report(
        self,
        process_id: int,
        report_path: Path,
        *,
        render: bool,
    ) -> bool:
        expected_identity = self._job_layout_report_identities.get(process_id)
        if expected_identity is None:
            if render:
                return self._render_layout_report(report_path)
            try:
                return self._validate_layout_report_payload(
                    report_path
                ).all_checks_pass
            except (OSError, UnicodeError, ValueError, TypeError, json.JSONDecodeError):
                return False
        try:
            payload = json.loads(report_path.read_text(encoding="utf-8"))
            if not isinstance(payload, Mapping):
                raise ValueError("报告根节点不是对象")
            parameters = payload.get("parameters")
            if not isinstance(parameters, Mapping):
                raise ValueError("报告缺少 parameters")
            actual_identity = self._layout_report_identity_from_parameters(parameters)
            if not self._layout_report_identities_match(
                actual_identity,
                expected_identity,
            ):
                raise ValueError(
                    "报告 parameters 与该 worker 启动快照不一致；"
                    "拒绝把其他任务的输出识别为本次结果"
                )
            if render:
                return self._render_layout_report(report_path, payload=payload)
            return self._validate_layout_report_payload(
                report_path,
                payload=payload,
            ).all_checks_pass
        except (OSError, UnicodeError, ValueError, TypeError, json.JSONDecodeError) as exc:
            if render:
                self._rendered_layout_report_settings = None
                self.layout_report_view.setStyleSheet(self._semantic_style("error"))
                self.layout_report_view.setPlainText(
                    f"质量报告不属于该启动任务：{report_path}\n{exc}"
                )
            return False

    def _choose_output(self) -> None:
        current = self._workspace_path(self.output_edit.text())
        selected, _filter = QFileDialog.getSaveFileName(
            self,
            "选择 Gmsh 网格输出文件",
            str(current),
            "Gmsh mesh (*.msh);;All files (*)",
        )
        if selected:
            path = self._workspace_mesh_output(selected)
            self.output_edit.setText(str(path))

    def _current_layer_file_path(self) -> Path | None:
        raw_path = self.layer_path_edit.text().strip()
        return self._workspace_path(raw_path).resolve() if raw_path else None

    def _refresh_layer_file_modified(self, *_args: object) -> None:
        """Keep Layer-file persistence separate from project persistence."""

        current_path = self._current_layer_file_path()
        current_text = self.layer_editor.toPlainText()
        self._layer_file_modified = (
            current_path != self._saved_layer_path
            or current_text != self._saved_layer_text
        )
        self.layer_save_button.setEnabled(
            current_path is not None and self._layer_file_modified
        )
        if self._layer_file_modified:
            self.layer_editor_box.setTitle("Layer 文本（可直接编辑 · 未保存）")
            self.layer_save_button.setToolTip(
                "将当前文本原子写入 Layer 文件；保存工程不会替代这个操作"
            )
        else:
            self.layer_editor_box.setTitle("Layer 文本（可直接编辑 · 已保存）")
            self.layer_save_button.setToolTip("当前 Layer 文件已保存")

    def _sync_layer_file_state_from_disk(self) -> None:
        """Compare a restored project snapshot with its referenced Layer file."""

        path = self._current_layer_file_path()
        disk_text: str | None = None
        if path is not None:
            try:
                disk_text = path.read_text(encoding="utf-8-sig")
            except (OSError, UnicodeError):
                pass
        self._saved_layer_path = path
        self._saved_layer_text = disk_text
        self._refresh_layer_file_modified()

    def _confirm_layer_overwrite(
        self,
        path: Path,
        *,
        expected_text: str | None,
    ) -> bool:
        """Avoid silently overwriting a Layer file changed outside EasyMesh."""

        if not path.exists():
            return True
        try:
            disk_text = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError):
            # The atomic writer will provide the actionable error if saving is
            # impossible; do not hide that behind a speculative read failure.
            return True
        if disk_text == expected_text or disk_text == self.layer_editor.toPlainText():
            return True
        if not self.isVisible():
            return False
        answer = QMessageBox.warning(
            self,
            "Layer 文件已在外部修改",
            f"{path}\n\n磁盘内容已在载入后发生变化。是否用编辑器中的内容覆盖它？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        return answer == QMessageBox.StandardButton.Yes

    def _write_layer_file(self, path: Path, *, make_current: bool) -> bool:
        resolved = path.expanduser().resolve()
        expected_text = (
            self._saved_layer_text
            if self._saved_layer_path == resolved
            else None
        )
        if not self._confirm_layer_overwrite(
            resolved,
            expected_text=expected_text,
        ):
            return False
        text = self.layer_editor.toPlainText()
        try:
            atomic_write_text(resolved, text)
        except (OSError, UnicodeError, RuntimeError) as exc:
            QMessageBox.critical(
                self,
                "Layer 保存失败",
                f"无法保存 {resolved}：\n{exc}",
            )
            return False

        self._saved_layer_path = resolved
        self._saved_layer_text = text
        if make_current:
            self.layer_path_edit.setText(str(resolved))
        self._refresh_layer_file_modified()
        return True

    def _save_layer_file(self, _checked: bool = False) -> bool:
        del _checked
        path = self._current_layer_file_path()
        if path is None:
            QMessageBox.critical(
                self,
                "Layer 保存失败",
                "请先在“Layer 文件”中填写保存路径。",
            )
            return False
        return self._write_layer_file(path, make_current=True)

    def _confirm_replace_modified_layer(self) -> bool:
        """Protect editor changes before an interactive reload or file switch."""

        if not self._layer_file_modified or not self.isVisible():
            return True
        answer = QMessageBox.warning(
            self,
            "Layer 尚未保存",
            "载入其他 Layer 会替换编辑器中的修改。是否先保存当前 Layer？",
            (
                QMessageBox.StandardButton.Save
                | QMessageBox.StandardButton.Discard
                | QMessageBox.StandardButton.Cancel
            ),
            QMessageBox.StandardButton.Save,
        )
        if answer == QMessageBox.StandardButton.Cancel:
            return False
        if answer == QMessageBox.StandardButton.Discard:
            return True
        target = self._saved_layer_path or self._current_layer_file_path()
        return target is not None and self._write_layer_file(
            target,
            make_current=False,
        )

    def _choose_layer_file(self) -> None:
        if not self._confirm_replace_modified_layer():
            return
        current = self._workspace_path(self.layer_path_edit.text())
        initial = (
            current.parent
            if current.parent.exists()
            else self._workspace_root / "examples"
        )
        selected, _filter = QFileDialog.getOpenFileName(
            self,
            "选择截面 Layer 文件",
            str(initial),
            "EasyMesh layer (*.layer);;Text files (*.txt);;All files (*)",
        )
        if selected:
            self.layer_path_edit.setText(selected)
            self._load_layer_file()

    def _load_layer_file(
        self,
        _checked: bool = False,
        *,
        show_error: bool = True,
        confirm_replace: bool = False,
    ) -> None:
        del _checked
        raw_path = self.layer_path_edit.text().strip()
        if confirm_replace and not self._confirm_replace_modified_layer():
            return
        if not raw_path:
            message = "请先选择 .layer 文件。"
            self._set_section_error(message)
            if show_error:
                QMessageBox.critical(self, "Layer 载入失败", message)
            return
        path = self._workspace_path(raw_path)
        try:
            text = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError) as exc:
            message = f"无法读取 {path}：{exc}"
            self._set_section_error(message)
            if show_error:
                QMessageBox.critical(self, "Layer 载入失败", message)
            return

        self.layer_path_edit.setText(str(path.resolve()))
        self._loading_layer_text = True
        self.layer_editor.setPlainText(text)
        self._loading_layer_text = False
        self._saved_layer_path = path.resolve()
        self._saved_layer_text = text
        self._refresh_layer_file_modified()
        self._section_timer.stop()
        self._refresh_section_preview()

    def _schedule_section_refresh(self) -> None:
        if not self._loading_layer_text:
            # Do not allow a pending/invalid edit to generate with the previous
            # section's radial boundaries while the debounce timer is running.
            self._section_plan = None
            self._refresh_derived()
            self._section_timer.start()

    def _refresh_section_preview(self) -> None:
        self._section_plan = None
        text = self.layer_editor.toPlainText()
        try:
            layers = parse_layer_text(text)
            if not layers:
                raise ValueError("Layer 截面至少需要一条有效定义。")
            plan = build_section_plan(layers)
        except Exception as exc:  # parser errors should remain inside the editor UI
            self._set_section_error(str(exc))
            return

        self._section_plan = plan
        self.section_preview.set_plan(plan)
        self._install_control_intervals(plan)
        self._refresh_derived()
        columns = _items(_value(plan, "columns", ()))
        materials_value = _value(plan, "materials", ())
        if isinstance(materials_value, Mapping):
            materials = tuple(str(item) for item in materials_value)
        else:
            materials = tuple(str(item) for item in _items(materials_value))
        if not materials:
            materials = tuple(
                dict.fromkeys(
                    str(_value(span, "material", "未命名材料"))
                    for column in columns
                    for span in _items(_value(column, "spans", ()))
                )
            )
        radius = _value(plan, "max_radius_um", "?")
        solid_height = _value(plan, "max_height_um", "?")
        construction_height = _value(
            plan,
            "construction_height_um",
            solid_height,
        )
        height_text = f"H={solid_height} µm"
        if construction_height != solid_height:
            height_text = (
                f"实体 H={solid_height} µm，"
                f"含 air gap 构造面 H={construction_height} µm"
            )
        try:
            layer_count = len(layers)  # type: ignore[arg-type]
        except TypeError:
            layer_count = sum(1 for _ in layers) if isinstance(layers, Iterable) else 0
        self.section_status_label.setStyleSheet(self._semantic_style("success"))
        self.section_status_label.setText(
            f"几何定义有效：{layer_count} 层，{len(columns)} 个径向区间，"
            f"R={radius} µm，{height_text}；"
            f"R/Z 控制区间={len(self._control_intervals)}；材料：{', '.join(materials) or '无'}。"
        )

    def _set_section_error(self, message: str) -> None:
        self._section_plan = None
        self._clear_control_interval_views()
        self._refresh_derived()
        friendly = message.strip() or "截面定义无效"
        self.section_preview.set_plan(None, f"截面定义待修正\n{friendly}")
        self.section_status_label.setStyleSheet(self._semantic_style("error"))
        self.section_status_label.setText(f"截面定义待修正：{friendly}")

    def _mark_layout_dependencies_stale(self, paths: Iterable[Path]) -> str:
        changed = "、".join(str(path) for path in dict.fromkeys(paths))
        message = "布局或模板在校验后发生了变化，请重新载入并校验"
        if changed:
            message += "：" + changed
        self._layout_template_details_loaded = False
        self._layout_template_inspection_attempted = True
        self._layout_validation_error = message
        self._rendered_layout_report_settings = None
        self._refresh_layout_launch_state()
        self.layout_report_view.setStyleSheet(self._semantic_style("error"))
        self.layout_report_view.setPlainText(message)
        return message

    def _layout_launch_values(
        self,
    ) -> tuple[
        BumpLayout,
        Path,
        float,
        float,
        tuple[tuple[str, str], ...],
        Path,
    ]:
        layout = self._bump_layout
        source = self._loaded_layout_source
        if layout is None or source is None:
            raise ValueError("请先载入有效的 .loc。")
        if self._layout_validation_error is not None:
            raise ValueError(self._layout_validation_error)
        if not self._layout_template_details_loaded:
            raise ValueError("请先读取并校验模板接口。")
        if not self._layout_dependency_signatures:
            raise ValueError("模板依赖尚未形成校验快照，请重新载入。")
        changed_dependencies: list[Path] = []
        for path, signature in self._layout_dependency_signatures.items():
            current_signature = self._layout_dependency_snapshot_signature(path)
            if current_signature != signature:
                changed_dependencies.append(path)
        if changed_dependencies:
            message = self._mark_layout_dependencies_stale(changed_dependencies)
            raise ValueError(message)
        far_field_size_um = self._positive_layout_value(
            self.far_field_size_edit.text().strip(), "远场 XY 尺寸"
        )
        self._validate_layout_size_budget(far_field_size_um)
        transition_distance_um = self._positive_layout_value(
            self.transition_distance_edit.text().strip(), "过渡距离"
        )
        transition_material_overrides = self._layout_material_overrides()
        output_text = self.layout_output_edit.text().strip()
        if not output_text:
            raise ValueError("请选择连接网格输出文件。")
        output = self._workspace_mesh_output(output_text)
        if str(output) != output_text:
            self.layout_output_edit.setText(str(output))
        if any(
            paths_refer_to_same_file(template.mesh_path, output)
            for template in layout.templates
        ):
            raise ValueError("连接网格输出不能覆盖任一输入模板。")
        if output in self._active_job_outputs:
            raise ValueError(f"该输出已有生成任务正在运行：{output}")
        return (
            layout,
            source,
            far_field_size_um,
            transition_distance_um,
            transition_material_overrides,
            output,
        )

    def _launch_layout(self, *, preview: bool) -> None:
        try:
            (
                _layout,
                source,
                far_field_size_um,
                transition_distance_um,
                transition_material_overrides,
                output,
            ) = self._layout_launch_values()
            output.parent.mkdir(parents=True, exist_ok=True)
            project_document = self._current_project_document(
                active_tab="layout"
            )
            command = [
                *worker_command_prefix(),
                "--layout",
                str(source),
                "--far-field-size",
                f"{far_field_size_um:.17g}",
                "--transition-distance",
                f"{transition_distance_um:.17g}",
            ]
            for source_material, target_material in transition_material_overrides:
                command.extend(
                    [
                        "--transition-material",
                        f"{source_material}={target_material}",
                    ]
                )
            command.extend(["--output", str(output)])
            if preview:
                command.append("--preview")
            process = self._start_job(
                command,
                output,
                preview=preview,
                kind="layout",
            )
            self._queue_export_project(process, output, project_document)
        except (ValueError, OSError) as exc:
            self.layout_status_label.setStyleSheet(self._semantic_style("error"))
            self.layout_status_label.setText(f"无法启动布局生成：{exc}")
            self.layout_report_view.setStyleSheet(self._semantic_style("error"))
            self.layout_report_view.setPlainText(f"后台 worker 未启动：{exc}")
            QMessageBox.critical(self, "布局生成参数错误", str(exc))
            return

        self.layout_report_view.setStyleSheet("")
        self._rendered_layout_report_settings = None
        self.layout_report_view.setPlainText(
            "后台 worker 正在生成。模板 connectivity、逐层 surface 高度、外部材料映射及写出重开检查完成后会在这里刷新。"
        )
        self.layout_status_label.setStyleSheet(self._semantic_style("muted"))
        self.layout_status_label.setText(
            "正在后台生成多 Bump 连接网格；Gmsh 预览窗口打开后可查看统一的材料、模板 Sets 和 HM Components。"
            if preview
            else "正在后台生成多 Bump 连接网格…"
        )

    @staticmethod
    def _package_v2_resolved_text(values: Iterable[object]) -> str:
        rendered: list[str] = []
        for value in values:
            owner = str(getattr(value, "owner_id", ""))
            display = str(getattr(value, "display", value))
            rendered.append(f"{owner}={display}" if owner else display)
        return "; ".join(rendered) or "—"

    @staticmethod
    def _package_v2_mesh_length_text(value_mm: float) -> str:
        """Render small package mesh controls compactly without losing units."""

        if abs(value_mm) < 1.0:
            return f"{value_mm * 1000.0:.12g} µm"
        return f"{value_mm:.12g} mm"

    @staticmethod
    def _package_v2_source_table_item(
        text: object,
        *,
        cell: SourceCell | None = None,
        editable: bool = False,
        preview_keys: Iterable[str] = (),
        edit_hint: str = "",
        completion_candidates: Iterable[str] = (),
        tooltip: str = "",
    ) -> QTableWidgetItem:
        item = QTableWidgetItem(str(text))
        keys = tuple(dict.fromkeys(str(key) for key in preview_keys if str(key)))
        if keys:
            item.setData(_PACKAGE_V2_PREVIEW_ROLE, keys)
        completions = tuple(
            dict.fromkeys(
                str(value) for value in completion_candidates if str(value)
            )
        )
        if completions:
            item.setData(_PACKAGE_V2_COMPLETION_ROLE, completions)
        if cell is not None:
            details = [f"JSON Pointer: {cell.pointer}"]
            if cell.dependencies:
                details.append(f"Dependencies: {', '.join(cell.dependencies)}")
            if editable:
                details.insert(0, "双击编辑；完整编译通过后进入未保存草稿。")
            if edit_hint:
                details.insert(0, edit_hint)
            if completions:
                details.insert(
                    0,
                    "输入时自动补全变量名；Ctrl+Space 显示全部候选。",
                )
            item.setToolTip("\n".join(details))
        elif tooltip:
            item.setToolTip(tooltip)
        if editable and cell is not None:
            item.setData(Qt.ItemDataRole.UserRole, cell.pointer)
            font = item.font()
            font.setBold(True)
            item.setFont(font)
        else:
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        return item

    @staticmethod
    def _package_v2_snapshot_tables(compiled: object) -> SourceTableSet:
        """Build the same compact rows for an immutable Job/Project snapshot."""

        # A snapshot deliberately receives no editor session, so the GUI
        # strips every editable flag even though the rows retain pointers.
        return build_package_v2_source_tables(compiled)  # type: ignore[arg-type]

    def _clear_package_v2_source_tables(self, *, clear_json: bool = True) -> None:
        self._invalidate_contact_preview()
        self._reset_package_v2_quality_table()
        self.package_v2_variable_help_label.setText("打开 Source 后编辑工程变量；黄色标记未引用变量。")
        self._updating_package_v2_source_tables = True
        try:
            for table in (
                self.package_v2_variables_table,
                self.package_v2_mesh_table,
                self.package_v2_frozen_table,
                self.package_v2_interfaces_table,
            ):
                table.clearContents()
                table.setRowCount(0)
            self.package_v2_geometry_tree.clear()
            self.package_v2_interface_tolerance_edit.clear()
            self.package_v2_parallel_tet_candidates_check.setChecked(False)
            self.package_v2_interface_tolerance_resolved_label.setText("—")
            if clear_json:
                self.package_v2_source_view.clear()
        finally:
            self._updating_package_v2_source_tables = False
        self._package_v2_preview_keys_by_instance.clear()
        self._package_v2_preview_selection_table = None
        self.package_v2_preview_3d.clear_scene(
            "打开有效的 Package V2 Source 或检查 Job 后显示 3D 几何"
        )
        self._refresh_package_v2_source_controls()

    def _refresh_package_v2_source_controls(self) -> None:
        editor = self._package_v2_source_editor
        active = "package_v2" in self._active_job_kinds
        editable = bool(editor is not None and not editor.read_only)
        pending = bool(self._package_v2_pending_source_edits)
        self.package_v2_source_reload_button.setEnabled(editable and not active)
        self.package_v2_source_new_button.setEnabled(not active and not pending and not (editor and editor.dirty))
        self.package_v2_source_save_button.setEnabled(
            bool(editable and editor and editor.dirty)
            and not active
            and not pending
        )
        local_mode = editor is not None
        has_templates = bool(editor and editor.document["templates"])
        self.package_v2_geometry_add_button.setEnabled(
            editable and has_templates and not active and not pending
        )
        self.package_v2_geometry_delete_button.setEnabled(
            editable and not active and not pending
            and self.package_v2_geometry_tree.selected_geometry() is not None
        )
        settings_editable = editable and not active and not pending
        selected_component = self.package_v2_geometry_tree.selected_context()[1] is not None
        self.package_v2_geometry_edit_button.setEnabled(settings_editable and selected_component)
        self.package_v2_geometry_instance_button.setEnabled(settings_editable and selected_component)
        frozen_selected = bool(self.package_v2_frozen_table.selectedItems())
        self.package_v2_frozen_edit_button.setEnabled(settings_editable and frozen_selected)
        self.package_v2_geometry_save_preset_button.setEnabled(settings_editable and selected_component)
        self.package_v2_geometry_insert_preset_button.setEnabled(settings_editable and has_templates)
        self.package_v2_variable_add_button.setEnabled(settings_editable and has_templates)
        self.package_v2_derived_add_button.setEnabled(settings_editable and has_templates)
        self.package_v2_variable_delete_button.setEnabled(settings_editable and bool(self.package_v2_variables_table.selectedItems()))
        self.package_v2_frozen_add_button.setEnabled(settings_editable)
        self.package_v2_frozen_delete_button.setEnabled(
            settings_editable and bool(self.package_v2_frozen_table.selectedItems())
        )
        self.package_v2_interface_tolerance_edit.setEnabled(settings_editable)
        self.package_v2_parallel_tet_candidates_check.setEnabled(settings_editable)
        self.package_v2_interface_tolerance_reset_button.setEnabled(
            settings_editable
        )
        self.package_v2_template_edit_button.setVisible(local_mode)
        self.package_v2_template_export_button.setVisible(local_mode)
        self.package_v2_template_edit_button.setEnabled(settings_editable and has_templates)
        self.package_v2_template_export_button.setEnabled(settings_editable and has_templates)
        if local_mode:
            self.package_v2_geometry_save_preset_button.setEnabled(settings_editable)
            self.package_v2_geometry_insert_preset_button.setEnabled(settings_editable)
            selected_instance = bool(self.package_v2_geometry_tree.selected_geometry())
            self.package_v2_geometry_delete_button.setEnabled(settings_editable and selected_instance)
            self.package_v2_geometry_edit_button.setEnabled(settings_editable and selected_instance)
            self.package_v2_geometry_instance_button.setEnabled(settings_editable and selected_instance)
            self.package_v2_variable_add_button.setEnabled(settings_editable)
            self.package_v2_derived_add_button.setEnabled(settings_editable)
        self.package_v2_component_delete_button.setEnabled(settings_editable and bool(selected_component))
        self.package_v2_component_delete_button.setVisible(local_mode)
        for button in (self.package_v2_geometry_add_button, self.package_v2_geometry_instance_button,
                       self.package_v2_geometry_edit_button, self.package_v2_geometry_delete_button,
                       self.package_v2_geometry_save_preset_button, self.package_v2_geometry_insert_preset_button):
            button.setVisible(editor is not None)
        if local_mode:
            self.package_v2_geometry_add_button.setToolTip("选择模板，为公开参数绑定 Global variable 或数值，并设置 Origin。")
            self.package_v2_geometry_instance_button.setToolTip("复制实例的绑定与摆放，继续引用同一个模板。")
            self.package_v2_geometry_edit_button.setToolTip("编辑选中实例的公开参数、摆放位置和所属 Component。")
            self.package_v2_geometry_save_preset_button.setToolTip("定义独立的局部变量、基本图形和子实例，创建新模板。")
            self.package_v2_geometry_delete_button.setToolTip("删除工程中的实例，保留其模板。保存 Source 前可重新载入撤回。")
        self.package_v2_geometry_help_label.setText(
            "请先打开或新建 Source，再创建实例或模板。" if editor is None else
            "Component 包含实例，统一维护材料和网格。展开实例编辑公开参数；内部构造通过“编辑模板”维护。")

    def _populate_package_v2_source_tables(
        self,
        tables: SourceTableSet,
        *,
        raw_text: str,
        editable: bool,
    ) -> None:
        """Render five compact source tables from one validated model."""

        names_by_template: dict[str, list[str]] = {}
        for variable in tables.variables:
            names_by_template.setdefault(variable.template_id, []).append(
                variable.name
            )
        candidates_by_template = {
            template_id: tuple(dict.fromkeys((*names, "um", "mm")))
            for template_id, names in names_by_template.items()
        }

        def expression_candidates(
            cell: SourceCell | None,
            template_id: str | None,
        ) -> tuple[str, ...]:
            if cell is None or cell.kind is not SourceCellKind.EXPRESSION:
                return ()
            if template_id is None:
                return ("um", "mm")
            return candidates_by_template.get(template_id, ("um", "mm"))

        self._updating_package_v2_source_tables = True
        try:
            tolerance_cell = tables.settings.interface_geometry_tolerance
            self.package_v2_parallel_tet_candidates_check.setChecked(tables.settings.parallel_tet_candidates)
            self.package_v2_interface_tolerance_edit.setText(
                tolerance_cell.display
            )
            resolved_tolerance = (
                tolerance_cell.resolved[0].display
                if tolerance_cell.resolved
                else "—"
            )
            self.package_v2_interface_tolerance_resolved_label.setText(
                f"= {resolved_tolerance}"
            )
            variables = self.package_v2_variables_table
            variables.clearContents()
            # Dropping the rows also destroys any unit QComboBox left by the
            # previous validated Source model.
            variables.setRowCount(0)
            variables.setRowCount(len(tables.variables))
            source_document = json.loads(raw_text)
            project_preview_keys = tuple(dict.fromkeys(
                _PACKAGE_V2_INSTANCE_TOKEN + value.get("component_id", value["id"])
                for value in source_document["instances"]
            ))
            single_instance = all(len(row.resolved) <= 1 for row in tables.variables)
            variable_names = [row.name for row in tables.variables]
            variables.setColumnHidden(0, len(variable_names) == len(set(variable_names)))
            variables.setColumnHidden(1, single_instance)
            project_label = "Global variables（局部变量通过“编辑模板”维护）。"
            unused_count = sum(not row.references for row in tables.variables)
            self.package_v2_variable_help_label.setText(
                f"{project_label}黄色 / 未引用：{unused_count} 个。删除前请先解除引用。"
            )
            for row_index, row in enumerate(tables.variables):
                owner_ids = tuple(
                    dict.fromkeys(value.owner_id for value in row.resolved)
                )
                owners = ", ".join(owner_ids) or "—"
                # Global variables belong to the whole project preview scope.
                preview_keys = project_preview_keys
                source_names = ", ".join(
                    dict.fromkeys(value.source for value in row.resolved)
                ) or ("derived" if row.role == "derived" else "—")
                values: tuple[object, ...] = (
                    row.template_id,
                    owners,
                    row.name,
                    row.role,
                    row.display,
                    row.declared_unit,
                    row.resolved[0].display if single_instance and len(row.resolved) == 1
                    else self._package_v2_resolved_text(row.resolved),
                    source_names,
                    ", ".join(row.dependencies) or "—",
                    "已引用" if row.references else "未引用",
                )
                for column, value in enumerate(values):
                    cell = (
                        row.value
                        if column == 4
                        else row.unit if column == 5
                        else row.name_cell if column == 2 else None
                    )
                    has_unit_combo = bool(
                        column == 5
                        and editable
                        and row.unit is not None
                        and row.unit.editable
                    )
                    completions = expression_candidates(cell, row.template_id)
                    if row.role == "parameter" and column == 4:
                        completions = ("um", "mm")
                    item = self._package_v2_source_table_item(
                        # A native macOS QComboBox has translucent margins.
                        # Drawing the unit in the backing table item as well
                        # makes the two labels overlap and look like a ghosted
                        # duplicate.  Editable unit cells are painted solely
                        # by the combo box; snapshot/read-only rows keep their
                        # ordinary item text.
                        "" if has_unit_combo else value,
                        cell=cell,
                        editable=bool(
                            editable
                            and cell
                            and cell.editable
                            and column != 5
                        ),
                        preview_keys=preview_keys,
                        edit_hint=(
                            f"裸数字按本行单位 {row.declared_unit} 解释；"
                            "也可输入 0.25mm 或 250um。"
                            if column == 4
                            and row.role == "parameter"
                            and row.dimension == "length"
                            else "修改名称会自动更新所有 Global 引用。" if column == 2 else ""
                        ),
                        completion_candidates=completions,
                    )
                    variables.setItem(row_index, column, item)
                    if has_unit_combo:
                        assert row.unit is not None
                        unit_combo = QComboBox(variables)
                        unit_combo.addItems(("um", "mm"))
                        current_unit = (
                            "um"
                            if row.declared_unit in ("um", "µm", "μm")
                            else row.declared_unit
                        )
                        unit_combo.setCurrentText(current_unit)
                        unit_combo.setToolTip(
                            "切换参数输入单位；简单数值会等值换算并同步到 JSON。"
                        )
                        unit_combo.currentTextChanged.connect(
                            lambda unit,
                            pointer=row.unit.pointer,
                            combo=unit_combo: (
                                _defer_package_v2_combo_rebuild(
                                    combo,
                                    lambda pointer=pointer, unit=unit: (
                                        self._on_package_v2_parameter_unit_changed(
                                            pointer,
                                            unit,
                                        )
                                    ),
                                )
                            )
                        )
                        variables.setCellWidget(row_index, column, unit_combo)
                for column in range(variables.columnCount()):
                    item = variables.item(row_index, column)
                    if item is not None:
                        usage = "引用位置：" + ", ".join(row.references) if row.references else "此变量未被任何几何、网格设置、摆放位置或其他变量引用。"
                        item.setToolTip(item.toolTip() + "\n" + usage)
                        if not row.references:
                            item.setBackground(QColor("#fff1c2"))
                            item.setForeground(QColor("#654b00"))
                variables.setRowHeight(row_index, 24)

            self.package_v2_geometry_tree.populate(
                tables.geometry, editable=editable, candidates=candidates_by_template,
            )
            self.package_v2_geometry_tree.setColumnHidden(3, False)
            self.package_v2_geometry_tree.headerItem().setText(0, "Component / 实例 / 参数")
            self.package_v2_geometry_tree.headerItem().setText(1, "Template / 类型")
            self.package_v2_geometry_tree.headerItem().setText(4, "绑定表达式")

            mesh = self.package_v2_mesh_table
            mesh.clearContents()
            mesh_rows = tuple(
                (row, resolved)
                for row in tables.meshes
                for resolved in (row.resolved or (None,))
            )
            mesh.setRowCount(len(mesh_rows))
            for row_index, (row, resolved) in enumerate(mesh_rows):
                owner = resolved.instance_id if resolved is not None else "—"
                preview_keys = (
                    (
                        generated_component_key(owner, row.component_id),
                    )
                    if resolved is not None
                    else ()
                )
                summary = _package_v2_mesh_options_summary(row.strategy_options, resolved)
                values = (owner, row.component_id, row.mesh_priority.display,
                    row.strategy_kind, "", summary)
                for column, value in enumerate(values):
                    cell = row.mesh_priority if column == 2 else None
                    item = self._package_v2_source_table_item(
                        "" if column == 3 and editable else value, cell=cell,
                        editable=bool(editable and cell and cell.editable), preview_keys=preview_keys,
                        completion_candidates=expression_candidates(cell, row.template_id))
                    if column == 5:
                        item.setToolTip(summary)
                    mesh.setItem(row_index, column, item)
                if editable:
                    strategy_combo = QComboBox(mesh)
                    strategy_combo.addItems(AUTHORING_MESH_STRATEGY_TOKENS)
                    strategy_combo.setCurrentText(row.strategy_kind)
                    strategy_combo.currentTextChanged.connect(
                        lambda strategy, pointer=row.pointer, combo=strategy_combo:
                            _defer_package_v2_combo_rebuild(combo,
                                lambda: self._on_package_v2_mesh_strategy_changed(pointer, strategy, "positive_z")))
                    mesh.setCellWidget(row_index, 3, strategy_combo)
                button = QPushButton("高级…", mesh)
                button.setEnabled(editable)
                button.clicked.connect(lambda checked=False, pointer=row.pointer:
                    self._on_package_v2_mesh_options_clicked(pointer))
                mesh.setCellWidget(row_index, 4, button)
                mesh.setRowHeight(row_index, 32)

            frozen = self.package_v2_frozen_table
            frozen.clearContents()
            frozen.setRowCount(len(tables.frozen))
            for row_index, row in enumerate(tables.frozen):
                preview_keys = tuple(
                    frozen_component_key(row.source_id, component_id)
                    for component_id in row.components
                )
                translation = ", ".join(value.display for value in row.translation)
                rotation = row.orientation_description
                values = (
                    row.source_id,
                    ", ".join(row.components),
                    row.artifacts[0].display,
                    translation,
                    rotation,
                    "可编辑" if editable and row.editable else "只读",
                )
                for column, value in enumerate(values):
                    cell = row.artifacts[0] if column == 2 else None
                    frozen.setItem(
                        row_index,
                        column,
                        self._package_v2_source_table_item(
                            value,
                            cell=cell,
                            editable=bool(editable and cell and cell.editable),
                            preview_keys=preview_keys,
                        ),
                    )
                frozen.setRowHeight(row_index, 24)

            # Actual contacts are populated asynchronously, never from the
            # source-authored (possibly stale) interface list.
            self.package_v2_interfaces_table.setRowCount(0)

            self.package_v2_source_view.setPlainText(raw_text)
        finally:
            self._updating_package_v2_source_tables = False

    def _on_package_v2_preview_selection_changed(self) -> None:
        """Qt can clear selection while retaining the current cell/item."""
        if self._updating_package_v2_source_tables:
            return
        table = self.sender()
        if not isinstance(table, (QTableWidget, QTreeWidget)):
            return
        selected = table.selectedItems()
        if selected:
            current = table.currentItem()
            self._on_package_v2_preview_current_item_changed(
                current if current is not None and current.isSelected() else selected[0], None,
            )
        elif table is self._package_v2_preview_selection_table:
            self._on_package_v2_preview_current_item_changed(None, None)

    def _on_package_v2_preview_current_item_changed(
        self,
        current: QTableWidgetItem | QTreeWidgetItem | None,
        previous: QTableWidgetItem | QTreeWidgetItem | None,
    ) -> None:
        """Mirror the active relationship-table row into the 3D highlight."""

        del previous
        if self._updating_package_v2_source_tables:
            return
        self._package_v2_preview_selection_table = (
            current.treeWidget() if isinstance(current, QTreeWidgetItem)
            else current.tableWidget() if current is not None else None
        )
        raw_keys = (
            None
            if current is None
            else current.data(0, _PACKAGE_V2_PREVIEW_ROLE)
            if isinstance(current, QTreeWidgetItem)
            else current.data(_PACKAGE_V2_PREVIEW_ROLE)
        )
        if isinstance(raw_keys, str):
            tokens = (raw_keys,)
        elif raw_keys is None:
            tokens = ()
        else:
            try:
                tokens = tuple(str(value) for value in raw_keys)
            except TypeError:
                tokens = ()
        expanded: list[str] = []
        for token in tokens:
            if token.startswith(_PACKAGE_V2_INSTANCE_TOKEN):
                instance_id = token.removeprefix(_PACKAGE_V2_INSTANCE_TOKEN)
                expanded.extend(
                    self._package_v2_preview_keys_by_instance.get(
                        instance_id,
                        (),
                    )
                )
            else:
                expanded.append(token)
        geometry_selected = (
            isinstance(current, QTreeWidgetItem)
            and current.treeWidget() is self.package_v2_geometry_tree
        )
        self.package_v2_preview_3d.set_highlighted_components(
            expanded, show_local_frames=geometry_selected,
            instance_id=current.data(0, GEOMETRY_ROLE) if geometry_selected else None,
        )

    def _install_package_v2_compiled_preview(self, compiled: object) -> None:
        geometry_selected = bool(self.package_v2_preview_3d.local_coordinate_frames)
        generated = tuple(getattr(compiled, "generated_instances", ()))
        candidate_keys_by_instance = {
            instance.instance_id: tuple(
                generated_component_key(
                    instance.instance_id,
                    component.local_component_id,
                )
                for component in instance.components
            )
            for instance in generated
        }
        try:
            self.package_v2_preview_3d.set_compiled_geometry(compiled)
        except (OSError, OverflowError, RuntimeError, TypeError, ValueError) as exc:
            # Preview extraction is intentionally auxiliary.  Keep its last
            # legal scene without weakening the already successful compiler
            # transaction or blocking Source editing.
            self.package_v2_preview_3d.summary_label.setText(
                "3D 预览更新失败；已保留上一帧合法几何"
            )
            self.package_v2_preview_3d.summary_label.setToolTip(str(exc))
            return
        self._package_v2_preview_keys_by_instance = candidate_keys_by_instance
        self.package_v2_preview_3d.set_highlighted_components(())
        if geometry_selected:
            self._on_package_v2_preview_current_item_changed(
                self.package_v2_geometry_tree.currentItem(), None,
            )

    def _set_package_v2_source_state(
        self,
        text: str,
        *,
        tone: str,
        tooltip: str = "",
    ) -> None:
        self.package_v2_source_state_label.setStyleSheet(
            self._semantic_style(tone)
        )
        self.package_v2_source_state_label.setText(text)
        self.package_v2_source_state_label.setToolTip(tooltip)

    def _package_v2_geometry_warning_state(
        self,
        *,
        expected_plan_digest: str | None = None,
    ) -> tuple[tuple[object, ...], bool]:
        scene = self.package_v2_preview_3d.scene
        editor = self._package_v2_source_editor
        if expected_plan_digest is None:
            if editor is None:
                return (), False
            expected_plan_digest = editor.compiled.plan_digest
        if (
            expected_plan_digest is not None
            and scene.plan_digest != expected_plan_digest
        ):
            return (), False
        warnings = getattr(scene, "geometry_warnings", ())
        return (
            tuple(
                warning
                for warning in warnings
                if str(getattr(warning, "message", "")).strip()
            ),
            bool(getattr(scene, "geometry_warning_scan_truncated", False)),
        )

    def _set_package_v2_compiled_source_state(
        self,
        text: str,
        *,
        tone: str,
        expected_plan_digest: str | None = None,
    ) -> None:
        warnings, truncated = self._package_v2_geometry_warning_state(
            expected_plan_digest=expected_plan_digest,
        )
        if not warnings and not truncated:
            self._set_package_v2_source_state(text, tone=tone)
            return
        exact_count = sum(
            1 for warning in warnings if bool(getattr(warning, "exact", False))
        )
        advisory_count = len(warnings) - exact_count
        warning_component_keys = tuple(
            dict.fromkeys(
                key
                for warning in warnings
                for key in tuple(getattr(warning, "component_keys", ()))
                if isinstance(key, str) and key
            )
        )
        if warning_component_keys:
            self.package_v2_preview_3d.set_highlighted_components(
                warning_component_keys
            )
        editor = self._package_v2_source_editor
        editable = bool(editor is not None and not editor.read_only)
        if editable:
            action = "非阻断警告；可继续修改并保存"
        else:
            action = "非阻断诊断；当前快照只读"
        details = [
            "3D 预览诊断不改变有效 Source；"
            "正式生成网格仍由 Gmsh/OpenCASCADE 完整严格检查。"
        ]
        details.extend(
            str(getattr(warning, "message", "")) for warning in warnings
        )
        if truncated:
            details.append(
                "交互预览已达到诊断上限，仅显示前若干组；"
                "正式生成网格不会跳过其余检查。"
            )
        if warnings:
            categories: list[str] = []
            if exact_count:
                categories.append(f"{exact_count} 组 Box/Frame 正体积重叠")
            if advisory_count:
                categories.append(
                    f"{advisory_count} 组 Underfill 疑似正体积重叠"
                )
            shown = "、".join(categories)
            if truncated:
                shown = f"已显示 {shown}，其余诊断未完成"
            warning_text = f"{shown}（{action}）"
        else:
            warning_text = f"Component 重叠诊断达到交互上限（{action}）"
        self._set_package_v2_source_state(
            f"{text} ⚠ {warning_text}。",
            tone="warning",
            tooltip="\n".join(details),
        )

    def _clear_package_v2_pending_source_edits(self) -> None:
        self._package_v2_pending_source_edits.clear()
        self._package_v2_pending_source_text = None
        self._package_v2_pending_source_warning = None

    def _apply_package_v2_pending_source_overlay(self) -> None:
        if not self._package_v2_pending_source_edits:
            return
        self._updating_package_v2_source_tables = True
        try:
            for table in (
                self.package_v2_variables_table,
                self.package_v2_mesh_table,
                self.package_v2_frozen_table,
                self.package_v2_interfaces_table,
            ):
                for row in range(table.rowCount()):
                    for column in range(table.columnCount()):
                        item = table.item(row, column)
                        if item is None:
                            continue
                        pointer = item.data(Qt.ItemDataRole.UserRole)
                        pending = self._package_v2_pending_source_edits.get(
                            pointer
                        )
                        if pending is not None:
                            item.setText(pending)
            self.package_v2_geometry_tree.apply_pending_edits(
                self._package_v2_pending_source_edits
            )
            if self._package_v2_pending_source_text is not None:
                self.package_v2_source_view.setPlainText(
                    self._package_v2_pending_source_text
                )
        finally:
            self._updating_package_v2_source_tables = False

    def _show_package_v2_pending_source_state(self) -> None:
        self._invalidate_contact_preview()
        self.package_v2_contacts_status.setText("Source 有尚未通过校验的修改；接触结果已失效，不能继续显示旧配对。")
        count = len(self._package_v2_pending_source_edits)
        warning = self._package_v2_pending_source_warning or (
            "当前几何需要同时调整多个字段。"
        )
        self._set_package_v2_source_state(
            f"⚠ 已暂存 {count} 项尚未联合通过的几何修改；输入未回滚。"
            "请继续修改相关尺寸，全部通过后会一次写入 Source 草稿。"
            "暂存期间不能保存或创建 Job，可用“重新载入”放弃。",
            tone="warning",
            tooltip=warning,
        )

    def _package_v2_pending_blocks_structural_edit(self) -> bool:
        if not self._package_v2_pending_source_edits:
            return False
        editor = self._package_v2_source_editor
        if editor is not None:
            self._populate_package_v2_source_tables(
                editor.tables,
                raw_text=editor.raw_text,
                editable=not editor.read_only,
            )
        self._apply_package_v2_pending_source_overlay()
        self._show_package_v2_pending_source_state()
        return True

    def _install_package_v2_source_editor(
        self,
        editor: PackageV2SourceEditor,
    ) -> None:
        frozen_dialog = self._package_v2_frozen_dialog
        if frozen_dialog is not None and frozen_dialog.source_editor is not editor:
            frozen_dialog.reject()
        dialog = self._package_v2_authoring_dialog
        if dialog is not None and dialog.source_editor is not editor:
            dialog.reject()
        self._clear_package_v2_pending_source_edits()
        self._package_v2_source_editor = editor
        self._populate_package_v2_source_tables(
            editor.tables,
            raw_text=editor.raw_text,
            editable=not editor.read_only,
        )
        self._refresh_package_v2_compiled_preview(editor.compiled)
        if editor.dirty:
            message = f"{editor.path.name} 有未保存的有效修改。"
            tone = "warning"
        else:
            message = f"可编辑 Source：{editor.path}"
            tone = "success"
        self._set_package_v2_compiled_source_state(message, tone=tone)
        self._refresh_package_v2_source_controls()

    def _install_package_v2_job_snapshot(
        self,
        request: PackageV2JobRequest,
        compiled: object,
        *,
        label: str = "Job 内嵌 Source 快照",
    ) -> None:
        if self._package_v2_frozen_dialog is not None:
            self._package_v2_frozen_dialog.reject()
        if self._package_v2_authoring_dialog is not None:
            self._package_v2_authoring_dialog.reject()
        self._clear_package_v2_pending_source_edits()
        self._package_v2_source_editor = None
        self._populate_package_v2_source_tables(
            self._package_v2_snapshot_tables(compiled),
            raw_text=request.source_text,
            editable=False,
        )
        self._refresh_package_v2_compiled_preview(compiled)
        self._set_package_v2_compiled_source_state(
            f"{label}只读；打开外部 *.source.json 后才可编辑。",
            tone="muted",
            expected_plan_digest=str(getattr(compiled, "plan_digest")),
        )
        self._refresh_package_v2_source_controls()

    def _matching_package_v2_external_editor(
        self,
        request: PackageV2JobRequest,
        job_path: Path,
    ) -> PackageV2SourceEditor | None:
        source = self._package_v2_source_path(request, job_path)
        if source is None or not source.name.endswith(".source.json"):
            return None
        expected = request.source_text.encode("utf-8")
        if not self._regular_file_matches_bytes(source, expected):
            return None
        try:
            editor = open_package_v2_source_editor(source)
        except (OSError, RuntimeError, ValueError):
            return None
        return editor if editor.raw_bytes == expected else None

    def _reconcile_package_v2_editor_with_job(self) -> None:
        editor = self._package_v2_source_editor
        raw_job = self.package_v2_job_path_edit.text().strip()
        if editor is None or not raw_job:
            self._package_v2_job_stale = False
            return
        try:
            identity, request, _data, _compiled = self._load_package_v2_job()
        except (OSError, RuntimeError, TypeError, ValueError):
            self._package_v2_identity = None
            self._package_v2_ready_identity = None
            self._package_v2_job_stale = False
            return
        matches = (
            request.source_text.encode("utf-8") == editor.raw_bytes
            and identity.raw_source_sha256 == editor.raw_sha256
            and identity.plan_sha256 == editor.compiled.plan_digest
        )
        self._package_v2_job_stale = not matches
        self._package_v2_identity = identity if matches else None
        if not matches:
            self._package_v2_ready_identity = None

    def _new_local_source(self, _checked=False):
        from .package_v2_local_templates import new_document
        current = self._package_v2_source_editor
        if "package_v2" in self._active_job_kinds or self._package_v2_pending_source_edits or (current and current.dirty):
            return
        selected, _ = QFileDialog.getSaveFileName(self, "新建 Template / Instance Source", str(PROJECT_ROOT / "output" / "package.source.json"),
                                                 "Package V2 Source (*.source.json)")
        if not selected:
            return
        path = Path(selected if selected.endswith(".source.json") else selected + ".source.json")
        identifier = re.sub(r"[^A-Za-z0-9_]", "_", path.name.removesuffix(".source.json"))
        if not identifier or identifier[0].isdigit():
            identifier = "package_" + identifier
        try:
            data = (json.dumps(new_document(identifier), ensure_ascii=False, indent=2) + "\n").encode("utf-8")
            compile_package_v2(data, source_root=path.parent)
            path.write_bytes(data)
            editor = open_package_v2_source_editor(path)
        except (OSError, RuntimeError, ValueError) as error:
            self._set_package_v2_source_state(str(error), tone="error")
            return
        self._install_package_v2_source_editor(editor)
        self._reconcile_package_v2_editor_with_job()

    def _open_package_v2_source(self, _checked: bool = False) -> None:
        del _checked
        current = self._package_v2_source_editor
        if current is not None and (
            current.dirty or self._package_v2_pending_source_edits
        ):
            self._set_package_v2_source_state(
                "当前 Source 有未保存或尚未联合通过的修改；"
                "请先完成保存或重新载入。",
                tone="error",
            )
            return
        initial = current.path.parent if current is not None else PROJECT_ROOT / "output"
        selected, _filter = QFileDialog.getOpenFileName(
            self,
            "打开 Package V2 Source",
            str(initial),
            "Package V2 Source (*.source.json);;JSON (*.json);;所有文件 (*)",
        )
        if not selected:
            return
        try:
            editor = open_package_v2_source_editor(selected)
        except (OSError, RuntimeError, ValueError) as exc:
            self._set_package_v2_source_state(
                f"Source 打开失败：{exc}", tone="error"
            )
            return
        self._install_package_v2_source_editor(editor)
        self._reconcile_package_v2_editor_with_job()
        if self._package_v2_job_stale:
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_status_label.setText(
                "当前 Source 与已选 Job 不一致；请重新创建 Job。"
            )
        self._refresh_package_v2_launch_state(preserve_status=True)
        self._refresh_project_modified()

    def _reload_package_v2_source(self, _checked: bool = False) -> None:
        del _checked
        current = self._package_v2_source_editor
        if current is None:
            self._set_package_v2_source_state(
                "当前没有可重新载入的外部 Source。", tone="warning"
            )
            return
        if current.dirty or self._package_v2_pending_source_edits:
            choice = QMessageBox.question(
                self,
                "放弃 Source 草稿？",
                "重新载入会丢弃当前尚未保存的有效修改和暂存中的多字段修改。\n"
                "确定从磁盘重新载入吗？",
                QMessageBox.StandardButton.Yes
                | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel,
            )
            if choice != QMessageBox.StandardButton.Yes:
                return
        try:
            editor = open_package_v2_source_editor(current.path)
        except (OSError, RuntimeError, ValueError) as exc:
            self._set_package_v2_source_state(
                f"Source 重新载入失败：{exc}", tone="error"
            )
            return
        self._install_package_v2_source_editor(editor)
        self._reconcile_package_v2_editor_with_job()
        self._refresh_package_v2_launch_state(preserve_status=True)
        self._refresh_project_modified()

    def _save_package_v2_source(self, _checked: bool = False) -> None:
        del _checked
        editor = self._package_v2_source_editor
        if editor is None or editor.read_only:
            self._set_package_v2_source_state(
                "当前 Source 快照只读，无法保存。", tone="warning"
            )
            return
        if self._package_v2_pending_source_edits:
            self._show_package_v2_pending_source_state()
            return
        try:
            editor.save()
        except (OSError, RuntimeError, PackageV2SourceConflictError) as exc:
            self._set_package_v2_source_state(
                f"Source 保存失败，已保留未保存修改：{exc}",
                tone="error",
            )
            self._refresh_package_v2_launch_state(preserve_status=True)
            self._refresh_project_modified()
            return
        self._install_package_v2_source_editor(editor)
        if self._package_v2_job_stale:
            self._set_package_v2_compiled_source_state(
                f"Source 已原子保存：{editor.path}；旧 Job 仍已失效。",
                tone="warning",
            )
        self._refresh_package_v2_launch_state(preserve_status=True)
        self._refresh_project_modified()

    def _rollback_package_v2_source_edit(
        self,
        editor: PackageV2SourceEditor,
        error: PackageV2SourceEditError,
    ) -> None:
        self._populate_package_v2_source_tables(
            editor.tables,
            raw_text=editor.raw_text,
            editable=not editor.read_only,
        )
        self._apply_package_v2_pending_source_overlay()
        message = error.message
        if "must evaluate to a length" in message:
            message = "长度需要单位；可输入纯数字（按本行单位），或输入 0.25mm / 250um。"
        if self._package_v2_pending_source_edits:
            self._invalidate_contact_preview()
            self._set_package_v2_source_state(
                f"当前输入已拒绝（{error.pointer}），此前暂存修改仍保留：{message}",
                tone="error",
                tooltip=self._package_v2_pending_source_warning or "",
            )
        else:
            # Repopulating the tables clears contacts; refresh even when an
            # invalid edit was rolled back to the last valid geometry.
            self._queue_contact_preview(editor.compiled)
            self._set_package_v2_source_state(
                f"修改已回滚（{error.pointer}）：{message}",
                tone="error",
            )
        self._refresh_package_v2_source_controls()

    def _finish_package_v2_source_edit(self, pointer: str) -> None:
        self._reset_package_v2_quality_table()
        editor = self._package_v2_source_editor
        if editor is None:
            return
        self._clear_package_v2_pending_source_edits()
        self._package_v2_ready_identity = None
        self._reconcile_package_v2_editor_with_job()
        self._populate_package_v2_source_tables(
            editor.tables,
            raw_text=editor.raw_text,
            editable=not editor.read_only,
        )
        self._refresh_package_v2_compiled_preview(editor.compiled)
        if editor.dirty:
            source_message = f"有效修改已写入草稿：{pointer}；请保存 Source。"
            source_tone = "warning"
        else:
            source_message = "当前草稿已回到磁盘 Source；无需保存。"
            source_tone = "success"
        self._set_package_v2_compiled_source_state(
            source_message,
            tone=source_tone,
        )
        if self._package_v2_job_stale:
            self.package_v2_report_view.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_report_view.setPlainText(
                "Source 已修改；旧 Job、mesh 和 report identity 不再可用。"
            )
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_status_label.setText(
                "Source 草稿已更新；保存后请重新创建 immutable Job。"
            )
        elif self._package_v2_identity is not None:
            self.package_v2_report_view.setStyleSheet(
                self._semantic_style("muted")
            )
            self.package_v2_report_view.setPlainText(
                "当前 Source 再次与所选 Job 一致；"
                "重新检查 Job 后可恢复 report-ready 证据。"
            )
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("success")
            )
            self.package_v2_status_label.setText(
                "当前 Source 与 immutable Job identity 一致。"
            )
        self._refresh_package_v2_launch_state(preserve_status=True)
        self._refresh_package_v2_source_controls()
        self._refresh_project_modified()

    def _selected_package_v2_geometry_context(
        self,
        editor: PackageV2SourceEditor,
    ) -> tuple[str | None, str | None]:
        return self.package_v2_geometry_tree.selected_context()

    def _select_added_package_v2_geometry(self, record_pointer: str) -> None:
        self.package_v2_geometry_tree.select_geometry(record_pointer)
        self._on_package_v2_preview_current_item_changed(
            self.package_v2_geometry_tree.currentItem(), None,
        )

    def _move_package_v2_geometry_deferred(self, template_id, geometry_id, component_id):
        editor = self._package_v2_source_editor
        digest = editor.raw_sha256 if editor is not None else None
        def apply():
            if self._package_v2_source_editor is editor and editor is not None and editor.raw_sha256 == digest:
                self._change_package_v2_geometry(template_id, geometry_id, component_id)
        QTimer.singleShot(0, apply)

    def _package_v2_authoring_editor(self):
        editor = self._package_v2_source_editor
        if (editor is None or editor.read_only or self._updating_package_v2_source_tables
                or "package_v2" in self._active_job_kinds
                or self._package_v2_pending_blocks_structural_edit()):
            return None
        return editor

    def _package_v2_authoring_template(self, editor):
        return "Global"

    def _show_package_v2_authoring_dialog(self, dialog):
        if self._package_v2_authoring_dialog is not None:
            self._package_v2_authoring_dialog.reject()
        self._package_v2_authoring_dialog = dialog
        def release(_result):
            if self._package_v2_authoring_dialog is dialog:
                self._package_v2_authoring_dialog = None
            dialog.deleteLater()
            self._refresh_package_v2_source_controls()
        dialog.finished.connect(release)
        dialog.setModal(False)
        dialog.show()

    def _commit_package_v2_authoring_dialog(self, dialog, operation):
        if self._package_v2_authoring_dialog is not dialog:
            return False
        editor = dialog.source_editor
        if (self._package_v2_source_editor is not editor or editor.raw_sha256 != dialog.opened_raw_sha256):
            dialog.show_compilation_error("Source 已切换或修改，请重新打开此窗口。")
            return False
        if self._package_v2_authoring_editor() is not editor:
            dialog.show_compilation_error("请先完成暂存修改，并等待当前任务结束。")
            return False
        try:
            result = operation()
        except PackageV2SourceEditError as error:
            dialog.show_compilation_error(error)
            return False
        if result.changed:
            self._finish_package_v2_source_edit(result.pointer)
            self.package_v2_geometry_tree.select_geometry(result.pointer)
        return True

    def _add_package_v2_variable(self, role):
        editor = self._package_v2_authoring_editor()
        if editor is None:
            return
        template_id = self._package_v2_authoring_template(editor)
        if template_id is None:
            return
        names = tuple(row.name for row in editor.tables.variables if row.template_id == template_id)
        dialog = _PackageV2QuickVariableDialog(
            self, role=role, existing_names=names, expression_candidates=(*names, "mm", "um"),
            commit=lambda record: self._commit_package_v2_authoring_dialog(
                dialog, lambda: editor.add_variable(template_id, role, record)),
        )
        dialog.source_editor = editor
        dialog.opened_raw_sha256 = editor.raw_sha256
        dialog.show_compilation_error = lambda error: dialog._show_error(str(error))
        self._show_package_v2_authoring_dialog(dialog)

    def _delete_package_v2_variable(self, _checked=False):
        editor = self._package_v2_authoring_editor()
        table = self.package_v2_variables_table
        if editor is None or not table.selectedItems():
            return
        row = table.currentRow()
        if table.item(row, 0) is None or table.item(row, 2) is None:
            return
        try:
            result = editor.delete_variable(table.item(row, 0).text(), table.item(row, 2).text())
        except PackageV2SourceEditError as error:
            self._set_package_v2_source_state(str(error), tone="warning")
            return
        if result.changed:
            self._finish_package_v2_source_edit(result.pointer)

    def _edit_package_v2_geometry(self, _checked=False):
        self._edit_bound_instance(editing=True)

    def _create_package_v2_template(self, _checked=False):
        self._edit_local_template()


    def _import_package_v2_template(self, _checked=False):
        self._import_local_template()

    def _create_package_v2_geometry_instance(self, _checked=False):
        self._edit_bound_instance(duplicate=True)

    def _selected_bound_instance(self, editor):
        selected = self.package_v2_geometry_tree.selected_geometry()
        return next((value for value in editor.document["instances"]
                     if selected and value["id"] == selected[1]), None)

    def _edit_bound_instance(self, *, editing=False, duplicate=False):
        from .package_v2_template_dialogs import BoundInstanceDialog
        editor = self._package_v2_authoring_editor()
        if editor is None:
            return
        instance = self._selected_bound_instance(editor) if editing or duplicate else None
        if (editing or duplicate) and instance is None:
            return
        dialog = BoundInstanceDialog(self, editor, instance=instance, duplicate=duplicate)
        def submit(value):
            if self._commit_package_v2_authoring_dialog(dialog, lambda: editor.upsert_bound_instance(
                    value, original_id=dialog.original_id, duplicate_from=instance["id"] if duplicate else None)):
                dialog.accept()
        dialog.submitRequested.connect(submit)
        self._show_package_v2_authoring_dialog(dialog)

    def _choose_local_template(self, editor):
        names = [value["id"] for value in editor.document["templates"]]
        if not names:
            return None
        selected = self.package_v2_geometry_tree.selected_context()[0]
        name, accepted = QInputDialog.getItem(self, "选择模板", "模板", names,
            names.index(selected) if selected in names else 0, False)
        return next(value for value in editor.document["templates"] if value["id"] == name) if accepted else None

    def _edit_local_template(self, *, editing=False):
        from .package_v2_template_dialogs import LocalTemplateDialog
        editor = self._package_v2_authoring_editor()
        if editor is None:
            return
        template = self._choose_local_template(editor) if editing else None
        if editing and template is None:
            return
        dialog = LocalTemplateDialog(self, editor, template=template)
        def submit(request):
            if self._commit_package_v2_authoring_dialog(dialog, lambda: editor.upsert_local_template(**request)):
                dialog.accept()
        dialog.submitRequested.connect(submit)
        self._show_package_v2_authoring_dialog(dialog)

    def _export_local_template(self, _checked=False):
        from .package_v2_local_templates import export_library
        editor = self._package_v2_authoring_editor()
        if editor is None:
            return
        template = self._choose_local_template(editor)
        if template is None:
            return
        selected, _ = QFileDialog.getSaveFileName(self, "Export template", str(editor.path.parent / f"{template['id']}.template.json"),
                                                 "EasyMesh Template (*.template.json)")
        if not selected:
            return
        path = Path(selected if selected.endswith(".template.json") else selected + ".template.json")
        try:
            path.write_text(json.dumps(export_library(editor.document, template["id"]), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        except (OSError, ValueError) as error:
            self._set_package_v2_source_state(str(error), tone="warning")
            return
        self._set_package_v2_source_state(f"已导出独立模板及其子模板：{path}", tone="success")

    def _import_local_template(self):
        from .package_v2_local_templates import decode_library
        editor = self._package_v2_authoring_editor()
        if editor is None:
            return
        selected, _ = QFileDialog.getOpenFileName(self, "Import template", str(editor.path.parent),
            "EasyMesh Template (*.template.json)")
        if not selected:
            return
        try:
            path = Path(selected)
            if path.stat().st_size > 16 * 1024 * 1024:
                raise ValueError("模板文件不能超过 16 MB")
            library = decode_library(path.read_bytes())
            result = editor.import_local_template(library)
        except (OSError, ValueError, TypeError) as error:
            self._set_package_v2_source_state(str(error), tone="warning")
            return
        if result.changed:
            self._finish_package_v2_source_edit(result.pointer)
        self._set_package_v2_source_state(f"已导入模板：{library['root']}。选择“创建实例”使用它。", tone="success")

    def _add_package_v2_frozen(self, _checked: bool = False) -> None:
        self._open_package_v2_frozen_dialog()

    def _edit_package_v2_frozen(self, _checked: bool = False) -> None:
        table = self.package_v2_frozen_table
        if table.selectedItems() and (item := table.item(table.currentRow(), 0)) is not None:
            self._open_package_v2_frozen_dialog(source_id=item.text())

    def _open_package_v2_frozen_dialog(self, *, source_id=None) -> None:
        editor = self._package_v2_source_editor
        if (editor is None or editor.read_only or "package_v2" in self._active_job_kinds
                or self._updating_package_v2_source_tables
                or self._package_v2_pending_blocks_structural_edit()):
            return
        if self._package_v2_frozen_dialog is not None:
            self._package_v2_frozen_dialog.raise_()
            self._package_v2_frozen_dialog.activateWindow()
            return
        dialog = FrozenMeshInstanceDialog(self, editor, source_id=source_id)
        dialog.setModal(False)
        dialog.submitRequested.connect(lambda source: self._submit_package_v2_frozen(dialog, source))
        dialog.finished.connect(lambda _result: self._release_package_v2_frozen_dialog(dialog))
        self._package_v2_frozen_dialog = dialog
        dialog.show()

    def _release_package_v2_frozen_dialog(self, dialog: FrozenMeshInstanceDialog) -> None:
        if self._package_v2_frozen_dialog is dialog:
            self._package_v2_frozen_dialog = None
        dialog.deleteLater()
        self._refresh_package_v2_source_controls()

    def _submit_package_v2_frozen(self, dialog: FrozenMeshInstanceDialog, source: object) -> None:
        if self._package_v2_frozen_dialog is not dialog:
            return
        editor = dialog.source_editor
        if (self._package_v2_source_editor is not editor or editor.read_only
                or editor.raw_sha256 != dialog.opened_raw_sha256):
            dialog.show_compilation_error("Source 已切换或修改，请关闭并重新打开网格实例窗口。")
            return
        if "package_v2" in self._active_job_kinds or self._package_v2_pending_source_edits:
            dialog.show_compilation_error("请等待当前任务结束，并完成暂存中的多字段修改后重试。")
            return
        try:
            result = (editor.add_frozen_source(source) if dialog.frozen_source_id is None
                      else editor.update_frozen_source(dialog.frozen_source_id, source))
        except PackageV2SourceEditError as error:
            dialog.show_compilation_error(error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(result.pointer)
        for index, row in enumerate(editor.tables.frozen):
            if row.source_id == source["id"]:
                self.package_v2_frozen_table.setCurrentCell(index, 0)
                break
        dialog.accept()

    def _delete_package_v2_frozen(self, _checked: bool = False) -> None:
        editor = self._package_v2_source_editor
        table = self.package_v2_frozen_table
        if (editor is None or editor.read_only or "package_v2" in self._active_job_kinds
                or self._updating_package_v2_source_tables or not table.selectedItems()
                or self._package_v2_pending_blocks_structural_edit()):
            return
        item = table.item(table.currentRow(), 0)
        if item is None:
            return
        source_id = item.text()
        try:
            result = editor.delete_frozen_source(source_id)
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(result.pointer)

    def _delete_package_v2_component(self, _checked=False):
        editor = self._package_v2_authoring_editor()
        selected = self.package_v2_geometry_tree.selected_context()[1]
        if editor is None or selected is None:
            return
        try:
            result = editor.delete_bound_component(selected)
            self._finish_package_v2_source_edit(result.pointer)
        except PackageV2SourceEditError as error:
            self._set_package_v2_source_state(str(error), tone="warning")

    def _delete_package_v2_geometry(self, _checked=False):
        editor = self._package_v2_authoring_editor()
        if editor is None:
            return
        instance = self._selected_bound_instance(editor)
        if instance is not None:
            try:
                result = editor.delete_bound_instance(instance["id"])
                self._finish_package_v2_source_edit(result.pointer)
            except PackageV2SourceEditError as error:
                self._set_package_v2_source_state(str(error), tone="warning")

    def _change_package_v2_geometry(self, template_id, geometry_id, component_id=None):
        editor = self._package_v2_source_editor
        if (editor is None or editor.read_only or "package_v2" in self._active_job_kinds
                or self._updating_package_v2_source_tables):
            return
        if self._package_v2_pending_blocks_structural_edit():
            return
        try:
            value = next(value for value in editor.document["instances"] if value["id"] == geometry_id)
            value["component_id"] = component_id
            result = editor.upsert_bound_instance(value, original_id=geometry_id)
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(result.pointer)
            if component_id is not None:
                self._select_added_package_v2_geometry(result.pointer)
            action = "已删除" if component_id is None else f"已移入 {component_id}，并继承其材料和网格设置"
            self._set_package_v2_compiled_source_state(
                f"实例 {geometry_id} {action}；请保存 Source。", tone="warning",
            )

    def _add_package_v2_geometry(self, _checked=False):
        self._edit_bound_instance()



    def _on_package_v2_parameter_unit_changed(
        self,
        pointer: str,
        unit: str,
    ) -> None:
        if self._updating_package_v2_source_tables:
            return
        if self._package_v2_pending_blocks_structural_edit():
            return
        editor = self._package_v2_source_editor
        if editor is None:
            return
        try:
            result = editor.change_parameter_unit(pointer, unit)
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(pointer)

    def _on_package_v2_parallel_tet_candidates_changed(self, enabled: bool) -> None:
        if self._updating_package_v2_source_tables:
            return
        if self._package_v2_pending_blocks_structural_edit():
            return
        editor = self._package_v2_source_editor
        if editor is None:
            return
        try:
            result = editor.change_parallel_tet_candidates(enabled)
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit("/mesh_settings/parallel_tet_candidates")

    def _on_package_v2_interface_tolerance_submitted(self) -> None:
        if self._updating_package_v2_source_tables:
            return
        if self._package_v2_pending_blocks_structural_edit():
            return
        editor = self._package_v2_source_editor
        if editor is None:
            return
        pointer = "/mesh_settings/interface_geometry_tolerance"
        try:
            result = editor.change_interface_geometry_tolerance(
                self.package_v2_interface_tolerance_edit.text()
            )
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(pointer)

    def _reset_package_v2_interface_tolerance(
        self,
        _checked: bool = False,
    ) -> None:
        if self._updating_package_v2_source_tables:
            return
        self.package_v2_interface_tolerance_edit.setText(
            DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_SOURCE
        )
        self._on_package_v2_interface_tolerance_submitted()

    def _on_package_v2_mesh_options_clicked(self, pointer):
        if self._package_v2_pending_blocks_structural_edit():
            return
        editor = self._package_v2_source_editor
        if editor is None or editor.read_only:
            return
        row = next((v for v in editor.tables.meshes if v.pointer == pointer), None)
        if row is None:
            return
        dialog = _PackageV2MeshOptionsDialog(self, strategy=row.strategy_options,
            target=row.target_edge.display, transition=row.transition_distance.display,
            expression_candidates=("um", "mm", *(value.name for value in editor.tables.variables
                if value.template_id == row.template_id)))
        while dialog.exec() == QDialog.DialogCode.Accepted:
            try:
                result = editor.change_mesh_options(pointer, **dialog.options())
            except PackageV2SourceEditError as error:
                dialog.status.setText(str(error))
                continue
            if result.changed:
                self._finish_package_v2_source_edit(pointer)
            break
        dialog.deleteLater()

    def _on_package_v2_mesh_strategy_changed(
        self,
        pointer: str,
        strategy: str,
        sweep_direction: str,
    ) -> None:
        if self._updating_package_v2_source_tables:
            return
        if self._package_v2_pending_blocks_structural_edit():
            return
        editor = self._package_v2_source_editor
        if editor is None:
            return
        try:
            result = editor.change_mesh_strategy(
                pointer,
                strategy,
                sweep_direction=(
                    sweep_direction
                    if strategy == "structured_sweep"
                    else None
                ),
            )
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(pointer)

    def _on_package_v2_sweep_direction_changed(
        self,
        pointer: str,
        direction: str,
    ) -> None:
        if self._updating_package_v2_source_tables:
            return
        if self._package_v2_pending_blocks_structural_edit():
            return
        editor = self._package_v2_source_editor
        if editor is None:
            return
        try:
            result = editor.change_structured_sweep_direction(
                pointer,
                direction,
            )
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(
                f"{pointer}/strategy/direction"
            )

    def _on_package_v2_orth_direction_submitted(
        self,
        pointer: str,
        direction: str,
        text: str,
    ) -> None:
        if self._updating_package_v2_source_tables:
            return
        if self._package_v2_pending_blocks_structural_edit():
            return
        editor = self._package_v2_source_editor
        if editor is None:
            return
        try:
            result = editor.change_orthogonal_directional_near_edge(
                pointer,
                direction,
                text.strip() or None,
            )
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(pointer)

    def _on_package_v2_orth_origin_submitted(
        self,
        pointer: str,
        values: tuple[str, str, str],
    ) -> None:
        if self._updating_package_v2_source_tables:
            return
        if self._package_v2_pending_blocks_structural_edit():
            return
        editor = self._package_v2_source_editor
        if editor is None:
            return
        normalized = tuple(value.strip() for value in values)
        if any(normalized) and not all(normalized):
            error = PackageV2SourceEditError(
                pointer,
                "partition_origin 的 X/Y/Z 必须同时填写或同时留空",
            )
            self._rollback_package_v2_source_edit(editor, error)
            return
        try:
            result = editor.change_orthogonal_partition_origin(
                pointer,
                normalized if all(normalized) else None,
            )
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            return
        if result.changed:
            self._finish_package_v2_source_edit(pointer)

    def _submit_package_v2_scalar_source_edit(
        self,
        pointer: str,
        text: str,
    ) -> None:
        """Apply one cell together with any transient multi-field edits."""

        editor = self._package_v2_source_editor
        if editor is None:
            return
        edits = dict(self._package_v2_pending_source_edits)
        edits[pointer] = text
        try:
            result = editor.edit_many(edits)
        except PackageV2SourcePendingError as error:
            self._package_v2_pending_source_edits = edits
            self._package_v2_pending_source_text = error.candidate_text
            self._package_v2_pending_source_warning = error.message
            self._package_v2_ready_identity = None
            self._apply_package_v2_pending_source_overlay()
            self._show_package_v2_pending_source_state()
            self.package_v2_report_view.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_report_view.setPlainText(
                "Source 中有尚未联合通过的几何尺寸修改；3D 预览保持上一帧合法几何。\n"
                "继续编辑相关字段，全部通过后这些值会一次提交。"
            )
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_status_label.setText(
                "几何修改已暂存，保存、创建 Job 和运行已暂停。"
            )
            self._refresh_package_v2_launch_state(preserve_status=True)
            self._refresh_package_v2_source_controls()
            self._refresh_project_modified()
            return
        except PackageV2SourceEditError as error:
            self._rollback_package_v2_source_edit(editor, error)
            self._refresh_project_modified()
            return
        had_pending = bool(self._package_v2_pending_source_edits)
        if result.changed or had_pending:
            self._clear_package_v2_pending_source_edits()
            self._finish_package_v2_source_edit(pointer)

    def _on_package_v2_source_item_changed(
        self,
        item: QTableWidgetItem | QTreeWidgetItem,
        column: int = 0,
    ) -> None:
        if self._updating_package_v2_source_tables:
            return
        editor = self._package_v2_source_editor
        pointer = (item.data(column, Qt.ItemDataRole.UserRole) if isinstance(item, QTreeWidgetItem)
                   else item.data(Qt.ItemDataRole.UserRole))
        if editor is None or not isinstance(pointer, str):
            return
        text = item.text(column) if isinstance(item, QTreeWidgetItem) else item.text()
        self._submit_package_v2_scalar_source_edit(pointer, text)

    @staticmethod
    def _read_package_v2_job_file(
        path: Path,
    ) -> tuple[bytes, tuple[int, int, int]]:
        """Read one regular Job file without crossing the parser byte limit."""

        flags = os.O_RDONLY
        for name in ("O_BINARY", "O_CLOEXEC", "O_NONBLOCK"):
            flags |= int(getattr(os, name, 0))
        descriptor = os.open(path, flags)
        try:
            before = os.fstat(descriptor)
            if not stat.S_ISREG(before.st_mode):
                raise ValueError("Package V2 Job 必须是普通文件。")
            if before.st_size > MAX_JOB_REQUEST_BYTES:
                raise ValueError("Package V2 Job 超过 32 MiB 安全上限。")
            remaining = MAX_JOB_REQUEST_BYTES + 1
            chunks: list[bytes] = []
            while remaining:
                chunk = os.read(descriptor, min(1024 * 1024, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
            data = b"".join(chunks)
            if len(data) > MAX_JOB_REQUEST_BYTES:
                raise ValueError("Package V2 Job 超过 32 MiB 安全上限。")
            after = os.fstat(descriptor)
        finally:
            os.close(descriptor)
        before_signature = (
            int(before.st_ino),
            int(before.st_mtime_ns),
            int(before.st_size),
        )
        after_signature = (
            int(after.st_ino),
            int(after.st_mtime_ns),
            int(after.st_size),
        )
        if before_signature != after_signature or len(data) != before.st_size:
            raise ValueError("Package V2 Job 在读取期间发生变化。")
        return data, before_signature

    @staticmethod
    def _write_private_package_v2_job(path: Path, data: bytes) -> None:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        for name in ("O_BINARY", "O_CLOEXEC"):
            flags |= int(getattr(os, name, 0))
        descriptor = os.open(path, flags, 0o600)
        try:
            offset = 0
            while offset < len(data):
                written = os.write(descriptor, data[offset:])
                if written <= 0:
                    raise OSError("cannot write the private Package V2 Job")
                offset += written
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _package_v2_job_path(self) -> Path:
        raw = self.package_v2_job_path_edit.text().strip()
        if not raw:
            raise ValueError("请选择 Package V2 Job JSON。")
        path = self._workspace_path(raw)
        if path.suffix.lower() != ".json":
            raise ValueError("Package V2 Job 必须使用 .json 文件。")
        return path

    def _load_package_v2_job(
        self,
    ) -> tuple[
        _PackageV2GuiIdentity,
        PackageV2JobRequest,
        bytes,
        object,
    ]:
        path = self._package_v2_job_path()
        data, signature = self._read_package_v2_job_file(path)
        request = parse_package_v2_job_request(data)
        compiled = compile_package_v2(
            request.source_text.encode("utf-8"),
            source_name=request.source_name,
            source_root=request.source_root,
        )
        if (
            compiled.raw_source_digest
            != request.launch_identity.raw_source_sha256
            or compiled.plan_digest != request.launch_identity.plan_sha256
        ):
            raise ValueError(
                "Job 内嵌 source 的重新编译 identity 与 launch identity 不一致。"
            )
        identity = _PackageV2GuiIdentity(
            path,
            signature,
            hashlib.sha256(data).hexdigest(),
            request.sha256,
            request.launch_identity.sha256,
            compiled.raw_source_digest,
            compiled.plan_digest,
            request.job_id,
            Path(request.output_mesh_path).resolve(),
            request.source_name,
        )
        return identity, request, data, compiled

    def _contact_input_signature(self):
        values = []
        for path in self._contact_artifact_paths:
            try:
                st = path.stat()
                values.append((str(path), st.st_size, st.st_mtime_ns, st.st_ctime_ns, st.st_ino))
            except OSError:
                values.append((str(path), None))
        return tuple(values)

    def _invalidate_contact_preview(self, *, stop_process=False):
        self._contact_generation += 1
        self._contact_timer.stop()
        process = self._contact_process
        if stop_process and process is not None and process.state() != QProcess.ProcessState.NotRunning:
            self._contact_process = None
            process.terminate()
            if not process.waitForFinished(100):
                process.kill()
                process.waitForFinished(500)
        self._contact_request = None
        self._contact_digest = None
        self._contact_artifact_paths = ()
        self._contact_compiled = None
        self.package_v2_interfaces_table.setRowCount(0)
        self.package_v2_contacts_json.clear()
        self.package_v2_contacts_status.setText("尚未检测；接触仅由实际几何计算。")

    def _queue_contact_preview(self, compiled):
        self._invalidate_contact_preview()
        self._contact_compiled = compiled
        self._contact_digest = compiled.raw_source_digest
        self._contact_artifact_paths = tuple(
            path for source in compiled.frozen_sources for path in (
                    source.artifacts.mesh_runtime_path,
            )
        )
        if compiled.frozen_sources:
            artifact = compiled.frozen_sources[0].artifacts
            root = artifact.mesh_runtime_path
            for _ in Path(artifact.mesh_declaration).parts:
                root = root.parent
        else:
            editor = self._package_v2_source_editor
            root = editor.path.parent if editor is not None else Path.cwd()
        self._contact_request = {"source_text": compiled.parsed_source.raw_text, "source_root": str(root),
                                 "generation": self._contact_generation, "realtime": True, "service": True}
        self._contact_artifact_signature = self._contact_input_signature()
        self.package_v2_contacts_status.setText("正在自动后台检测当前几何接触；不等待体网格审计，结果将分阶段刷新。")
        self._contact_timer.start()

    def _watch_contact_inputs(self):
        if self._contact_request is not None and self._contact_input_signature() != self._contact_artifact_signature:
            self._queue_contact_preview(self._contact_compiled)

    def _start_contact_preview(self):
        if self._contact_request is None:
            return
        if self._contact_process is not None:
            if self._contact_process.state() == QProcess.ProcessState.Running:
                self._send_contact_preview_request()
                return
            if self._contact_process.state() == QProcess.ProcessState.Starting:
                return
        process = QProcess(self)
        self._contact_process = process
        self._contact_output_buffer = b""
        environment = QProcessEnvironment()
        for key, value in worker_environment().items():
            environment.insert(key, value)
        process.setProcessEnvironment(environment)
        command = [*worker_command_prefix(), "--package-v2-contact-preview"]
        process.started.connect(self._send_contact_preview_request)
        process.readyReadStandardOutput.connect(lambda: self._read_contact_preview_output(process))
        errors = bytearray()

        def read_errors():
            errors.extend(bytes(process.readAllStandardError()))
            del errors[:-2400]

        process.readyReadStandardError.connect(read_errors)

        def finished(*_):
            if self._contact_process is process:
                self._read_contact_preview_output(process)
                self._contact_process = None
                if self._contact_request is not None:
                    detail = errors.decode("utf-8", errors="replace")
                    self._apply_contact_preview({"geometry_contacts_complete": False,
                        "error": "接触检测进程退出：" + (detail or process.errorString()), "interfaces": []},
                        self._contact_generation)
            process.deleteLater()

        process.finished.connect(finished)
        process.errorOccurred.connect(
            lambda error: finished() if error == QProcess.ProcessError.FailedToStart else None
        )
        process.start(command[0], command[1:])

    def _send_contact_preview_request(self):
        if self._contact_process is not None and self._contact_request is not None:
            self._contact_process.write((json.dumps(self._contact_request, ensure_ascii=False) + "\n").encode("utf-8"))

    def _read_contact_preview_output(self, process):
        if self._contact_process is not process:
            return
        self._contact_output_buffer += bytes(process.readAllStandardOutput())
        while b"\n" in self._contact_output_buffer:
            line, self._contact_output_buffer = self._contact_output_buffer.split(b"\n", 1)
            try:
                payload = json.loads(line)
            except (ValueError, UnicodeError):
                continue
            generation = payload.get("generation")
            if generation != self._contact_generation or self._contact_request is None:
                continue
            if self._contact_input_signature() != self._contact_artifact_signature:
                self._queue_contact_preview(self._contact_compiled)
                continue
            self._apply_contact_preview(payload, generation)

    def _apply_contact_preview(self, payload, generation):
        if generation != self._contact_generation:
            return
        if (payload.get("geometry_contacts_complete") or payload.get("preview_rows_available")) and payload.get("raw_source_sha256") != self._contact_digest:
            return
        self.package_v2_contacts_json.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
        table = self.package_v2_interfaces_table
        rows = payload.get("interfaces", []) if (payload.get("geometry_contacts_complete") or payload.get("preview_rows_available")) else []
        self._updating_package_v2_source_tables = True
        try:
            table.setRowCount(len(rows))
            for index, row in enumerate(rows):
                first, second = row["first"], row["second"]
                source_key = (frozen_component_key if row["kind"].startswith("Frozen") else generated_component_key)(first["instance"], first["component"])
                target_key = generated_component_key(second["instance"], second["component"])
                area = row.get("area_mm2")
                area_text = f"{area:.8g} mm²" if area is not None else "已接触，曲线裁切面积待计算"
                detail = f"{row['kind']} · {area_text} · {', '.join(row['sides'])}"
                if "producer_side_complete" in row:
                    detail += " · 出面方" + ("完整面" if row["producer_side_complete"] else "局部面")
                    detail += " / 接收方" + ("完整面" if row["consumer_side_complete"] else "局部面")
                else:
                    detail += f" · {row['facet_count']} facets"
                    if row.get("partial_facet_count"):
                        detail += f" · {row['partial_facet_count']} 个 Frozen 面片部分接触，网格兼容待检查"
                values = (first["instance"], first["component"], second["instance"], second["component"], row["mode"], detail)
                for column, value in enumerate(values):
                    table.setItem(index, column, self._package_v2_source_table_item(
                        value, editable=False, preview_keys=(source_key, target_key),
                        tooltip=json.dumps(row, ensure_ascii=False, indent=2),
                    ))
        finally:
            self._updating_package_v2_source_tables = False
        if payload.get("stage") == "generated_geometry" and not payload.get("geometry_contacts_complete"):
            status = f"Generated 几何接触已显示：{len(rows)} 条；正在检测 Frozen 实际外表面。"
        elif not payload.get("geometry_contacts_complete"):
            status = "接触检测未完成（不是零接触）：" + str(payload.get("error", "未知错误"))
        else:
            status = f"实际接触已刷新：{len(rows)} 条。对应结果在 JSON 页统一展示；Source 不包含手工接口配对。"
            if payload.get("mesh_ordering_error"):
                status += " 网格约束尚未通过：" + payload["mesh_ordering_error"]
            if payload.get("check_scope") == "geometry_preview":
                status += f" 耗时 {payload.get('elapsed_seconds', 0):.2f} 秒；几何接触不等于网格兼容，完整审计在执行前进行。"
        self.package_v2_contacts_status.setText(status)

    def _refresh_package_v2_compiled_preview(self, compiled: object) -> None:
        self._install_package_v2_compiled_preview(compiled)
        self._queue_contact_preview(compiled)

    def _package_v2_identity_is_current(
        self,
        identity: _PackageV2GuiIdentity,
    ) -> bool:
        try:
            path = self._package_v2_job_path()
            data, signature = self._read_package_v2_job_file(path)
        except (OSError, RuntimeError, ValueError):
            return False
        return (
            path == identity.request_path
            and signature == identity.request_signature
            and hashlib.sha256(data).hexdigest()
            == identity.request_transport_sha256
        )

    def _package_v2_identity_payload(
        self,
        identity: _PackageV2GuiIdentity,
        request: PackageV2JobRequest,
        compiled: object,
    ) -> dict[str, object]:
        return {
            "status": "canonical_job_ready",
            "job_path": str(identity.request_path),
            "job_id": identity.job_id,
            "output_mesh_path": str(identity.output),
            "request_sha256": identity.request_sha256,
            "launch_identity_sha256": identity.launch_identity_sha256,
            "raw_source_sha256": identity.raw_source_sha256,
            "compiled_plan_sha256": identity.plan_sha256,
            "runtime_profile": request.launch_identity.runtime_profile.to_jsonable(),
            "generated_instance_count": len(
                tuple(getattr(compiled, "generated_instances", ()))
            ),
            "frozen_source_count": len(
                tuple(getattr(compiled, "frozen_sources", ()))
            ),
            "contact_discovery": "automatic_geometry",
            "gui_overrides_allowed": False,
        }

    def _inspect_package_v2_job(
        self,
        _checked: bool = False,
        *,
        show_error: bool = True,
        loaded: tuple[
            _PackageV2GuiIdentity,
            PackageV2JobRequest,
            bytes,
            object,
        ]
        | None = None,
    ) -> _PackageV2GuiIdentity | None:
        del _checked
        self._reset_package_v2_quality_table()
        try:
            identity, request, _data, compiled = (
                self._load_package_v2_job() if loaded is None else loaded
            )
        except Exception as exc:
            self._package_v2_identity = None
            self._package_v2_ready_identity = None
            self.package_v2_generate_button.setEnabled(False)
            self.package_v2_cdb_button.setEnabled(False)
            self.package_v2_open_msh_button.setEnabled(False)
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("error")
            )
            selected = self.package_v2_job_path_edit.text().strip()
            if selected.lower().endswith(".source.json"):
                message = (
                    "当前选择的是 Package V2 Source，不是 immutable Job。"
                    "请点击‘从 Source 创建 Job…’先绑定本机输出与"
                    "runtime profile。"
                )
            else:
                message = f"Job 检查失败：{exc}"
            self.package_v2_status_label.setText(message)
            self.package_v2_report_view.setStyleSheet(
                self._semantic_style("error")
            )
            self.package_v2_report_view.setPlainText(
                f"{message}\n\n底层校验信息：\n{exc}"
            )
            if show_error:
                QMessageBox.critical(self, "Package V2 Job 无效", message)
            return None

        self._loading_package_v2_path = True
        try:
            self.package_v2_job_path_edit.setText(str(identity.request_path))
        finally:
            self._loading_package_v2_path = False
        active_editor = self._package_v2_source_editor
        expected_source = request.source_text.encode("utf-8")
        request_source = self._package_v2_source_path(
            request,
            identity.request_path,
        )
        same_source_path = bool(
            active_editor is not None
            and request_source is not None
            and active_editor.path == request_source
        )
        preserves_active_source = bool(
            active_editor is not None
            and (
                bool(self._package_v2_pending_source_edits)
                or active_editor.raw_bytes != expected_source
            )
            and (
                active_editor.dirty
                or bool(self._package_v2_pending_source_edits)
                or same_source_path
            )
        )
        if preserves_active_source:
            self._package_v2_job_stale = True
            self._package_v2_ready_identity = None
            if self._package_v2_pending_source_edits:
                self._show_package_v2_pending_source_state()
            else:
                self._set_package_v2_compiled_source_state(
                    "当前 Source 与 Job 不同；已保留 Source 并禁用 Job。",
                    tone="warning",
                    expected_plan_digest=active_editor.compiled.plan_digest,
                )
        else:
            if (
                active_editor is not None
                and same_source_path
                and active_editor.raw_bytes == expected_source
            ):
                external_editor = active_editor
            else:
                external_editor = self._matching_package_v2_external_editor(
                    request,
                    identity.request_path,
                )
            if external_editor is None:
                self._install_package_v2_job_snapshot(request, compiled)
            else:
                self._install_package_v2_source_editor(external_editor)
            self._package_v2_job_stale = False
        self._package_v2_identity = identity
        payload = self._package_v2_identity_payload(identity, request, compiled)
        self.package_v2_report_view.setStyleSheet("")
        self.package_v2_report_view.setPlainText(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
        )
        self.package_v2_status_label.setStyleSheet(
            self._semantic_style("success")
        )
        self.package_v2_status_label.setText(
            "Job canonical replay 与纯编译 identity 一致；"
            f"实例={payload['generated_instance_count']}，"
            f"Frozen Source={payload['frozen_source_count']}，"
            "接口由实际几何自动检测。\n"
            f"输出由 Job 固定为：{identity.output}"
        )
        if preserves_active_source:
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_status_label.setText(
                self.package_v2_status_label.text()
                + "\n但当前 Source 与 Job 不同；执行保持禁用。"
            )
        self._package_v2_ready_identity = None
        existing_report = identity.output.with_suffix(".report.json")
        if existing_report.is_file() and not self._package_v2_job_stale:
            try:
                existing_payload = self._validate_package_v2_report(
                    identity,
                    existing_report,
                )
            except (OSError, RuntimeError, TypeError, ValueError):
                pass
            else:
                self._package_v2_ready_identity = identity
                self._show_package_v2_quality_report(existing_payload)
                self.package_v2_report_view.setPlainText(
                    json.dumps(
                        existing_payload,
                        ensure_ascii=False,
                        indent=2,
                        sort_keys=True,
                    )
                )
                self.package_v2_status_label.setText(
                    self.package_v2_status_label.text()
                    + "\n现有 report-ready artifact 仍与该 Job 一致。"
                )
                mesh_warnings = existing_payload.get("execution", {}).get("mesh_warnings", ())
                if mesh_warnings:
                    self.package_v2_status_label.setStyleSheet(self._semantic_style("warning"))
                    self.package_v2_status_label.setText(
                        self.package_v2_status_label.text()
                        + f" 网格警告 {len(mesh_warnings)} 项，请查看‘结果报告 → 网格警告’。"
                    )
        self._refresh_package_v2_launch_state(preserve_status=True)
        return identity

    def _on_package_v2_job_path_changed(self, _text: str) -> None:
        if self._loading_package_v2_path:
            return
        self._package_v2_identity = None
        self._package_v2_ready_identity = None
        self.package_v2_generate_button.setEnabled(False)
        self.package_v2_cdb_button.setEnabled(False)
        if self._package_v2_source_editor is None:
            self._clear_package_v2_source_tables()
        self.package_v2_report_view.clear()
        self._reset_package_v2_warning_display()
        self._refresh_package_v2_launch_state()
        self._refresh_project_modified()

    def _choose_package_v2_job(self, _checked: bool = False) -> None:
        del _checked
        initial = self._workspace_root
        raw = self.package_v2_job_path_edit.text().strip()
        if raw:
            try:
                initial = self._workspace_path(raw).parent
            except (OSError, RuntimeError, ValueError):
                pass
        selected, _filter = QFileDialog.getOpenFileName(
            self,
            "选择 Package V2 Job",
            str(initial),
            "Package V2 Job (*.json);;JSON (*.json);;所有文件 (*)",
        )
        if not selected:
            return
        self.package_v2_job_path_edit.setText(
            str(Path(selected).expanduser().resolve())
        )
        self._inspect_package_v2_job()

    def _create_package_v2_job_from_source(
        self,
        _checked: bool = False,
    ) -> None:
        del _checked
        editor = self._package_v2_source_editor
        if editor is not None:
            if self._package_v2_pending_source_edits:
                self._show_package_v2_pending_source_state()
                return
            if editor.dirty:
                self._set_package_v2_source_state(
                    "请先保存 Source 草稿，再创建 immutable Job。",
                    tone="warning",
                )
                return
            source = editor.path
        else:
            source_name, _source_filter = QFileDialog.getOpenFileName(
                self,
                "选择 Package V2 Source",
                str(PROJECT_ROOT / "output"),
                "Package V2 Source (*.source.json);;JSON (*.json);;所有文件 (*)",
            )
            if not source_name:
                return
            source = Path(source_name).expanduser().resolve()
        stem = source.name.removesuffix(".source.json") or "package_v2"
        initial_output = self._workspace_root / "output" / f"{stem}.msh"
        output_name, _output_filter = QFileDialog.getSaveFileName(
            self,
            "选择 Package V2 网格输出",
            str(initial_output),
            "Gmsh mesh (*.msh)",
        )
        if not output_name:
            return
        output = normalized_mesh_output(output_name)
        job = output.with_suffix(".job.json")
        job_id_token = re.sub(r"[^A-Za-z0-9_.-]+", "-", stem).strip(".-")
        job_id = f"gui-{job_id_token or 'package-v2'}"
        self.package_v2_create_job_button.setEnabled(False)
        self.package_v2_status_label.setStyleSheet(
            self._semantic_style("muted")
        )
        self.package_v2_status_label.setText(
            "正在编译 Source、fresh-audit Frozen artifacts 并生成"
            "本机 immutable Job…"
        )
        QApplication.processEvents()
        try:
            materialize_package_v2_job(
                source,
                job,
                output,
                job_id=job_id,
            )
        except (OSError, RuntimeError, TypeError, ValueError) as exc:
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("error")
            )
            self.package_v2_status_label.setText(
                f"无法从 Source 创建 Package V2 Job：{exc}"
            )
            QMessageBox.critical(self, "Package V2 Job 创建失败", str(exc))
            self._refresh_package_v2_launch_state(preserve_status=True)
            return
        finally:
            if "package_v2" not in self._active_job_kinds:
                self.package_v2_create_job_button.setEnabled(True)
        self.package_v2_job_path_edit.setText(str(job))
        self._package_v2_job_stale = False
        self._inspect_package_v2_job()
        self._refresh_project_modified()

    def _refresh_package_v2_launch_state(
        self,
        *_args: object,
        preserve_status: bool = False,
    ) -> None:
        active = "package_v2" in self._active_job_kinds
        pending = bool(self._package_v2_pending_source_edits)
        identity = self._package_v2_identity
        current = bool(
            identity
            and not self._package_v2_job_stale
            and self._package_v2_identity_is_current(identity)
            and not pending
        )
        self.package_v2_generate_button.setEnabled(current and not active)
        ready = (
            current
            and self._package_v2_ready_identity == identity
            and "cdb" not in self._active_job_kinds
        )
        self.package_v2_cdb_button.setEnabled(bool(ready) and not active)
        self.package_v2_open_msh_button.setEnabled(bool(
            current and self._package_v2_ready_identity == identity
            and not active and identity.output.is_file()
        ))
        self.package_v2_inspect_button.setEnabled(not active)
        self.package_v2_job_browse_button.setEnabled(not active)
        self.package_v2_create_job_button.setEnabled(not active and not pending)
        editor = self._package_v2_source_editor
        self.package_v2_source_open_button.setEnabled(not active)
        self.package_v2_source_reload_button.setEnabled(
            editor is not None and not active
        )
        self.package_v2_source_save_button.setEnabled(
            bool(editor and editor.dirty and not editor.read_only)
            and not active
            and not pending
        )
        self.package_v2_source_tabs.setEnabled(not active)
        self.package_v2_cancel_button.setEnabled(active)
        if not active:
            self.package_v2_cancel_button.setText("取消任务")
        if preserve_status:
            return
        if active:
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("muted")
            )
            self.package_v2_status_label.setText(
                "Package V2 worker 正在运行；详细阶段见执行进度。"
            )
        elif not self.package_v2_job_path_edit.text().strip():
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("muted")
            )
            self.package_v2_status_label.setText("请选择 Package V2 Job JSON。")
        elif self._package_v2_job_stale:
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_status_label.setText(
                "Source 已改变，当前 Job/report 已失效；"
                "保存 Source 后请重新创建 Job。"
            )
        elif not current:
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_status_label.setText(
                "Job 尚未检查，或文件在检查后发生变化；执行已禁用。"
            )

    @staticmethod
    def _package_v2_elapsed_text(seconds: float) -> str:
        elapsed = max(0, int(seconds))
        hours, remainder = divmod(elapsed, 3600)
        minutes, seconds = divmod(remainder, 60)
        return (
            f"已用时 {hours:02d}:{minutes:02d}:{seconds:02d}"
            if hours
            else f"已用时 {minutes:02d}:{seconds:02d}"
        )

    def _reset_package_v2_quality_table(self) -> None:
        self._reset_package_v2_warning_display()
        self._package_v2_quality_events = []
        self.package_v2_quality_table.setRowCount(0)
        self.package_v2_quality_note.setText(
            "各组件按执行顺序显示生成状态和质量；有优化时另列每轮数据。生成完成仍需整包审计，最终指标以写后重开为准。"
        )

    def _populate_package_v2_quality_table(self, rows) -> None:
        from .package_v2_quality_history import METRICS

        table = self.package_v2_quality_table
        table.setColumnCount(10)
        table.setHorizontalHeaderLabels(("组件", "候选/算法", "轮次", "阶段", *METRICS, "单元数", "状态"))
        table.setRowCount(len(rows))
        for index, row in enumerate(rows):
            candidate = str(row.get("candidate", ""))
            algorithm = re.search(r"algorithm=(\d+)/seed=(\d+)", candidate)
            display = {"orthogonal_hex": "Orth", "structured_sweep": "Sweep",
                       "conformal_hybrid": "Hybrid"}.get(candidate, candidate)
            if algorithm:
                name = {"1": "Delaunay", "10": "HXT"}.get(algorithm[1], algorithm[1])
                display = f"{name} / seed {algorithm[2]}"
                attempt = re.search(r"attempt=(\d+)", candidate)
                if attempt:
                    display = f"#{attempt[1]} {display}"
            component = re.sub(r"^v2g_.*?_l\d+_", "", str(row.get("component", "")))
            metrics = row.get("metrics", {})
            values = (component, display, row.get("iteration", "—"), row.get("phase", ""),
                      *(f"{metrics[name]:.8g}" if isinstance(metrics.get(name), (int, float)) else "—" for name in METRICS),
                      row.get("element_count") if row.get("element_count") is not None else "—", row.get("status", ""))
            for column, value in enumerate(values):
                item = self._read_only_table_item(str(value))
                item.setToolTip(f"{row.get('component', '')}\n{candidate}\n{row.get('detail', '')}")
                table.setItem(index, column, item)
        table.resizeColumnsToContents()
        table.horizontalHeader().setStretchLastSection(True)

    def _reset_package_v2_warning_display(self) -> None:
        self._package_v2_failure_diagnostics = []
        self.package_v2_warnings_box.setTitle("网格警告")
        self.package_v2_warnings_view.clear()
        self.package_v2_warnings_summary.clear()
        self.package_v2_warnings_box.hide()

    def _show_package_v2_quality_report(self, payload, *, current: bool = True) -> None:
        from .package_v2_quality_history import quality_rows_from_report
        from .package_v2_warning_display import report_warnings, warning_html

        self._populate_package_v2_quality_table(quality_rows_from_report(payload))
        note = "最终值来自本报告的写后重开审计；历史轮次没有记录的指标显示‘—’，不从最终值反填。"
        components = payload.get("execution", {}).get("components", {})
        deviations = [e["recovery_maximum_radial_deviation_mm"] * 1000
                      for component in (components.values() if isinstance(components, dict) else components)
                      for e in component.get("backend_evidence_by_fragment_id", {}).values()
                      if isinstance(e.get("recovery_maximum_radial_deviation_mm"), (int, float))]
        if deviations:
            note += f" 注意：几何恢复最大径向偏差 {max(deviations):.6g} µm；质量通过不等于严格贴合原始解析外形。"
        warnings = report_warnings(payload)
        self._reset_package_v2_warning_display()
        if warnings:
            note += f" 网格警告 {len(warnings)} 项，见上方‘网格警告’。"
            export = "报告包含不允许导出的项" if any(w.get("export_allowed") is False for w in warnings) else "允许导出"
            summary = f"{len(warnings)} 项警告 · {export}。请查看各项影响及处理建议。"
            if not current:
                summary = "旧任务的警告，当前设置已变化；不代表当前网格。\n" + summary
            self.package_v2_warnings_summary.setText(summary)
            self.package_v2_warnings_summary.setStyleSheet(self._semantic_style("warning"))
            self.package_v2_warnings_view.setHtml(warning_html(warnings))
            self.package_v2_warnings_box.show()
            for warning in warnings:
                self._append_package_v2_runtime_log(
                    "WARNING " + json.dumps(warning, ensure_ascii=False)
                )
        self.package_v2_quality_note.setText(note)

    def _show_package_v2_contact_failure(self, diagnostic, *, current: bool = True) -> None:
        from .package_v2_quality_history import quality_rows_from_events
        from .package_v2_warning_display import (
            contact_error_message,
            warning_html,
            is_orthogonal_error,
            orthogonal_error_message,
        )

        orth_error = is_orthogonal_error(diagnostic)
        if not isinstance(diagnostic, dict) or (
            diagnostic.get("code") != "partial_contact_boundary_cuts_facet"
            and not orth_error
        ):
            return
        format_error = orthogonal_error_message if orth_error else contact_error_message
        diagnostics = getattr(self, "_package_v2_failure_diagnostics", [])
        if not any(d == diagnostic for d in diagnostics):
            diagnostics.append(diagnostic)
            events = getattr(self, "_package_v2_quality_events", [])
            events.append(
                {
                    "stage": "contact_validation",
                    "state": "failed",
                    "component_id": diagnostic.get("component_id"),
                    "candidate": diagnostic.get("backend", ""),
                    "detail": format_error(diagnostic),
                }
            )
            self._package_v2_quality_events = events
            self._populate_package_v2_quality_table(quality_rows_from_events(events))
        self._package_v2_failure_diagnostics = diagnostics
        self._package_v2_ready_identity = None
        self.package_v2_warnings_box.setTitle("网格错误")
        summary = "接触边界未对齐，生成已中止。本次未生成可导出的完整网格。"
        if orth_error:
            summary = orthogonal_error_message(diagnostic)
        if not current:
            summary = "旧任务的错误，当前设置已变化；不代表当前网格。\n" + summary
        self.package_v2_warnings_summary.setText(summary)
        self.package_v2_warnings_summary.setStyleSheet(self._semantic_style("error"))
        self.package_v2_warnings_view.setHtml(warning_html(diagnostics))
        self.package_v2_warnings_box.show()
        self.package_v2_quality_note.setText(
            "接触面检查失败；表中保留的是已生成组件的质量观测，本次未完成整包审计。"
        )

    def _append_package_v2_runtime_log(self, text: str) -> None:
        rendered = text.rstrip("\r\n")
        if rendered:
            self.package_v2_log_view.appendPlainText(rendered)

    def _render_package_v2_progress_event(
        self,
        event: Mapping[str, object],
    ) -> None:
        phase = str(event["phase"])
        phase_index = int(event["phase_index"])
        phase_count = int(event["phase_count"])
        state = str(event["state"])
        message = str(event["message"])
        from .package_v2_quality_history import QUALITY_PROGRESS_PREFIX, quality_rows_from_events

        if message.startswith(QUALITY_PROGRESS_PREFIX):
            try:
                quality_event = json.loads(message[len(QUALITY_PROGRESS_PREFIX):])
            except (ValueError, TypeError):
                quality_event = None
            if isinstance(quality_event, dict):
                events = getattr(self, "_package_v2_quality_events", [])
                events.append(quality_event)
                self._package_v2_quality_events = events
                self._populate_package_v2_quality_table(quality_rows_from_events(events))
                metrics = quality_event.get("metrics", {})
                metric_text = ", ".join(f"{name}={value:.8g}" for name, value in metrics.items()
                                        if isinstance(value, (int, float))) if isinstance(metrics, dict) else ""
                iteration = quality_event.get("iteration")
                message = f"{quality_event.get('component_id', '')} / {quality_event.get('candidate', '')} / {quality_event.get('stage', '')}: {quality_event.get('state', '')}"
                if iteration is not None:
                    message += f"；第 {iteration} 轮"
                if metric_text:
                    message += "；" + metric_text
                if quality_event.get("detail"):
                    message += "；" + str(quality_event["detail"])
        if state == "failed" and event.get("diagnostic") is not None:
            self._show_package_v2_contact_failure(event["diagnostic"])
        mode = event.get("mode")
        title = _PACKAGE_V2_PROGRESS_PHASES.get(phase, phase)
        mode_suffix = f" · {mode}" if isinstance(mode, str) and mode else ""
        self.package_v2_phase_label.setText(
            f"阶段 {phase_index}/{phase_count} · {title}{mode_suffix}"
        )
        self.package_v2_detail_label.setText(message)
        self.package_v2_detail_label.setToolTip(message)
        current = event.get("current")
        total = event.get("total")
        unit = event.get("unit")
        if isinstance(current, int) and isinstance(total, int) and total > 0:
            self.package_v2_progress_bar.setRange(0, total)
            self.package_v2_progress_bar.setValue(current)
            unit_text = str(unit or "item")
            self.package_v2_progress_bar.setFormat(
                f"{unit_text} %v/%m"
            )
        elif state in {"started", "progress"} and phase in {
            "mesh_generation",
            "execution_plan",
        }:
            self.package_v2_progress_bar.setRange(0, 0)
        else:
            completed = phase_index if state == "completed" else phase_index - 1
            self.package_v2_progress_bar.setRange(0, phase_count)
            self.package_v2_progress_bar.setValue(max(0, completed))
            self.package_v2_progress_bar.setFormat("阶段 %v/%m")
        if state == "failed":
            self.package_v2_progress_bar.setRange(0, phase_count)
            self.package_v2_progress_bar.setValue(max(0, phase_index - 1))
            self.package_v2_progress_bar.setFormat("执行失败")
        self._append_package_v2_runtime_log(
            f"[阶段 {phase_index}/{phase_count}] {message}"
        )

    @staticmethod
    def _read_appended_file_bytes(path: Path, offset: int) -> tuple[bytes, int]:
        try:
            with path.open("rb") as stream:
                stream.seek(offset)
                chunk = stream.read()
        except FileNotFoundError:
            return b"", offset
        return chunk, offset + len(chunk)

    def _poll_package_v2_run(
        self,
        process: subprocess.Popen[str],
        log_path: Path,
    ) -> _PackageV2RunState | None:
        process_id = id(process)
        state = self._package_v2_runs.get(process_id)
        if state is None:
            return None
        self.package_v2_elapsed_label.setText(
            self._package_v2_elapsed_text(time.monotonic() - state.started_at)
        )

        try:
            chunk, state.progress_offset = self._read_appended_file_bytes(
                state.progress_path,
                state.progress_offset,
            )
        except OSError as error:
            self._append_package_v2_runtime_log(
                f"[进度读取警告] {error}"
            )
            chunk = b""
        if chunk:
            combined = state.progress_buffer + chunk
            lines = combined.split(b"\n")
            state.progress_buffer = lines.pop()
            if len(state.progress_buffer) > PACKAGE_V2_PROGRESS_MAX_LINE_BYTES:
                self._append_package_v2_runtime_log(
                    "[进度读取警告] 丢弃超长的未完成事件。"
                )
                state.progress_buffer = b""
            for line in lines:
                if not line:
                    continue
                try:
                    event = parse_package_v2_progress_event(
                        line,
                        expected_run_id=state.run_id,
                        expected_job_id=state.job_id,
                        expected_request_sha256=state.request_sha256,
                        after_sequence=state.last_sequence,
                    )
                except PackageV2ProgressError as error:
                    self._append_package_v2_runtime_log(
                        f"[进度事件已忽略] {error}"
                    )
                    continue
                state.last_sequence = int(event["seq"])
                self._render_package_v2_progress_event(event)

        try:
            log_chunk, state.log_offset = self._read_appended_file_bytes(
                log_path,
                state.log_offset,
            )
        except OSError as error:
            self._append_package_v2_runtime_log(f"[日志读取警告] {error}")
            log_chunk = b""
        if log_chunk:
            self._append_package_v2_runtime_log(
                log_chunk.decode("utf-8", errors="replace")
            )

        if (
            state.cancel_requested
            and state.cancel_deadline is not None
            and process.poll() is None
            and time.monotonic() >= state.cancel_deadline
        ):
            try:
                process.kill()
                self._append_package_v2_runtime_log(
                    "取消等待超时，已强制停止 worker。"
                )
            except OSError as error:
                self._append_package_v2_runtime_log(
                    f"无法强制停止 worker：{error}"
                )
            state.cancel_deadline = None
        return state

    def _cleanup_package_v2_run(self, process_id: int) -> None:
        state = self._package_v2_runs.pop(process_id, None)
        if state is None:
            return
        try:
            state.progress_path.unlink(missing_ok=True)
        except OSError:
            pass

    def _cancel_package_v2_job(self, _checked: bool = False) -> None:
        del _checked
        for process, _output, log_path, _preview in tuple(self._jobs):
            process_id = id(process)
            if self._job_kinds.get(process_id) != "package_v2":
                continue
            state = self._package_v2_runs.get(process_id)
            if state is None or state.cancel_requested:
                return
            if process.poll() is not None:
                self._poll_jobs()
                return
            state.cancel_requested = True
            state.cancel_deadline = time.monotonic() + 3.0
            self.package_v2_cancel_button.setEnabled(False)
            self.package_v2_cancel_button.setText("正在取消…")
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("warning")
            )
            self.package_v2_status_label.setText(
                "已请求取消 Package V2 worker；正在等待安全退出。"
            )
            self.package_v2_phase_label.setText("正在取消 Package V2 Job")
            self.package_v2_detail_label.setText(
                "已发送 terminate；若 3 秒内未退出将自动 kill。"
            )
            self.package_v2_progress_bar.setRange(0, 0)
            self._append_package_v2_runtime_log("用户请求取消任务。")
            try:
                process.terminate()
            except OSError as error:
                self._append_package_v2_runtime_log(
                    f"无法发送 terminate：{error}"
                )
            self._poll_package_v2_run(process, log_path)
            return

    def _launch_package_v2(self, _checked: bool = False) -> None:
        del _checked
        private_job: Path | None = None
        progress_path: Path | None = None
        self.package_v2_log_view.clear()
        self.package_v2_phase_label.setText("正在准备 Package V2 Job")
        self.package_v2_detail_label.setText(
            "正在读取、重新编译并核对 immutable Job；此步骤在 worker 启动前完成。"
        )
        self.package_v2_progress_bar.setRange(0, 0)
        self.package_v2_elapsed_label.setText("已用时 00:00")
        QApplication.processEvents()
        try:
            loaded = self._load_package_v2_job()
            identity = self._inspect_package_v2_job(
                show_error=False,
                loaded=loaded,
            )
            if identity is None:
                raise ValueError("Package V2 Job 未通过检查。")
            if self._package_v2_job_stale:
                raise ValueError(
                    "Source 已修改，当前 immutable Job 已失效；"
                    "请保存 Source 并重新创建 Job。"
                )
            loaded_identity, request, data, _compiled = loaded
            if loaded_identity != identity:
                raise ValueError("Package V2 Job 在启动快照前发生变化。")
            output = identity.output
            output.parent.mkdir(parents=True, exist_ok=True)
            run_id = uuid.uuid4().hex
            private_job = output.parent / (
                f".{output.stem}.{run_id}.package-v2-job.json"
            )
            progress_path = output.parent / (
                f".{output.stem}.{run_id}.package-v2-progress.jsonl"
            )
            self._write_private_package_v2_job(private_job, data)
            process = self._start_job(
                [
                    *worker_command_prefix(),
                    "--package-v2-job",
                    str(private_job),
                    "--progress-jsonl",
                    str(progress_path),
                    "--progress-run-id",
                    run_id,
                ],
                output,
                preview=False,
                kind="package_v2",
                append_job_id=False,
                bound_job_id=request.job_id,
            )
            process_id = id(process)
            self._job_package_v2_identities[process_id] = identity
            self._job_config_snapshots[process_id] = private_job
            self._package_v2_runs[process_id] = _PackageV2RunState(
                progress_path,
                run_id,
                request.job_id,
                request.sha256,
                time.monotonic(),
            )
            self._reset_package_v2_quality_table()
            self._package_v2_ready_identity = None
            self._package_v2_artifact_state_dirty = True
            self._refresh_project_modified()
        except (OSError, RuntimeError, TypeError, ValueError) as exc:
            if private_job is not None:
                try:
                    private_job.unlink(missing_ok=True)
                except OSError:
                    pass
            if progress_path is not None:
                try:
                    progress_path.unlink(missing_ok=True)
                except OSError:
                    pass
            self.package_v2_phase_label.setText("Package V2 启动失败")
            self.package_v2_detail_label.setText(str(exc))
            self.package_v2_progress_bar.setRange(
                0, PACKAGE_V2_PROGRESS_PHASE_COUNT
            )
            self.package_v2_progress_bar.setValue(0)
            self.package_v2_progress_bar.setFormat("启动失败")
            self.package_v2_status_label.setStyleSheet(
                self._semantic_style("error")
            )
            self.package_v2_status_label.setText(
                f"无法启动 Package V2 worker：{exc}"
            )
            QMessageBox.critical(self, "Package V2 启动失败", str(exc))
            return
        self.package_v2_phase_label.setText("阶段 1/8 · 重放并核对 Job")
        self.package_v2_detail_label.setText(
            "worker 已启动，正在等待第一条身份绑定的进度事件。"
        )
        self.package_v2_progress_bar.setRange(0, 0)
        self._append_package_v2_runtime_log(
            f"worker 已启动；进度通道：{progress_path}\n完整日志：{output.with_suffix('.log')}"
        )
        self._refresh_package_v2_launch_state()

    @staticmethod
    def _validated_package_v2_artifact(
        value: object,
        *,
        expected_path: Path,
        field_name: str,
    ) -> dict[str, object]:
        if not isinstance(value, Mapping):
            raise ValueError(f"{field_name} artifact evidence is missing")
        if set(value) != {"path", "size_bytes", "sha256"}:
            raise ValueError(f"{field_name} artifact evidence is not canonical")
        path = value.get("path")
        size = value.get("size_bytes")
        digest = value.get("sha256")
        if type(path) is not str or Path(path).resolve() != expected_path:
            raise ValueError(f"{field_name} artifact path changed")
        if type(size) is not int or size < 0:
            raise ValueError(f"{field_name} artifact size is invalid")
        if (
            type(digest) is not str
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
        ):
            raise ValueError(f"{field_name} artifact SHA-256 is invalid")
        current = expected_path.stat()
        if not stat.S_ISREG(current.st_mode) or current.st_size != size:
            raise ValueError(f"{field_name} artifact is missing or stale")
        if ConcentricMeshApp._sha256_file(expected_path) != digest:
            raise ValueError(f"{field_name} artifact bytes are stale")
        return {"path": path, "size_bytes": size, "sha256": digest}

    def _validate_package_v2_report(
        self,
        identity: _PackageV2GuiIdentity,
        report_path: Path,
    ) -> dict[str, object]:
        data, _signature = self._read_package_v2_job_file(report_path)
        try:
            payload = json.loads(data.decode("utf-8"))
        except (UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError("Package V2 report 不是有效 UTF-8 JSON") from exc
        if not isinstance(payload, dict):
            raise ValueError("Package V2 report 必须是 JSON object")
        from .package_v2_worker import PACKAGE_V2_WORKER_REPORT_SCHEMA

        if (
            payload.get("schema") != PACKAGE_V2_WORKER_REPORT_SCHEMA
            or payload.get("status") != "complete"
            or payload.get("job_id") != identity.job_id
            or payload.get("request_sha256") != identity.request_sha256
        ):
            raise ValueError("Package V2 report 不属于当前 Job")
        launch = payload.get("launch_identity")
        current = payload.get("current_evidence")
        if not isinstance(launch, Mapping) or not isinstance(current, Mapping):
            raise ValueError("Package V2 report identity evidence is incomplete")
        if (
            launch.get("sha256") != identity.launch_identity_sha256
            or current.get("raw_source_sha256") != identity.raw_source_sha256
            or current.get("compiled_plan_sha256") != identity.plan_sha256
        ):
            raise ValueError("Package V2 report identity 已陈旧")
        capabilities = payload.get("capabilities")
        if (
            not isinstance(capabilities, Mapping)
            or capabilities.get("complete_package_mesh") is not True
        ):
            raise ValueError("Package V2 report 未证明 complete package mesh")
        artifacts = payload.get("artifacts")
        if not isinstance(artifacts, Mapping) or set(artifacts) != {
            "mesh",
            "parameters",
        }:
            raise ValueError("Package V2 report artifact evidence is incomplete")
        self._validated_package_v2_artifact(
            artifacts["mesh"],
            expected_path=identity.output,
            field_name="mesh",
        )
        self._validated_package_v2_artifact(
            artifacts["parameters"],
            expected_path=identity.output.with_suffix(".parameters.json"),
            field_name="parameters",
        )
        binding = payload.get("binding_sha256")
        if type(binding) is not str or len(binding) != 64:
            raise ValueError("Package V2 report binding SHA-256 is invalid")
        unsigned = dict(payload)
        unsigned.pop("binding_sha256", None)
        canonical = json.dumps(
            unsigned,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        if hashlib.sha256(canonical).hexdigest() != binding:
            raise ValueError("Package V2 report binding SHA-256 不匹配")
        return payload

    def _complete_package_v2_job(
        self,
        process: subprocess.Popen[str],
        output: Path,
        log_path: Path,
        return_code: int,
    ) -> None:
        process_id = id(process)
        identity = self._job_package_v2_identities.get(process_id)
        report_path = output.with_suffix(".report.json")
        self.package_v2_phase_label.setText(
            "阶段 8/8 · GUI 复核 report-ready 产物"
        )
        self.package_v2_detail_label.setText(
            "worker 已退出；正在独立核对 report identity、MSH 和 parameters hash。"
        )
        self.package_v2_progress_bar.setRange(0, 0)
        fresh_report = self._job_report_is_fresh(process, report_path)
        if return_code == 0 and identity is not None and fresh_report:
            try:
                payload = self._validate_package_v2_report(
                    identity,
                    report_path,
                )
            except (OSError, RuntimeError, TypeError, ValueError) as exc:
                self.package_v2_status_label.setStyleSheet(
                    self._semantic_style("error")
                )
                self.package_v2_status_label.setText(
                    f"worker 已退出，但 report-ready 证据复核失败：{exc}"
                )
                self.package_v2_report_view.setStyleSheet(
                    self._semantic_style("error")
                )
                self.package_v2_report_view.setPlainText(
                    f"报告复核失败：\n{exc}\n\n报告：{report_path}"
                )
                self.package_v2_detail_label.setText(
                    f"report-ready 证据复核失败：{exc}"
                )
                self.package_v2_progress_bar.setRange(
                    0, PACKAGE_V2_PROGRESS_PHASE_COUNT
                )
                self.package_v2_progress_bar.setValue(7)
                self.package_v2_progress_bar.setFormat("复核失败")
                self.package_v2_result_tabs.setCurrentWidget(
                    self.package_v2_log_tab
                )
                return
            current = self._package_v2_identity_is_current(identity)
            self._show_package_v2_quality_report(payload, current=current)
            self.package_v2_report_view.setPlainText(
                json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
            )
            if current:
                self._package_v2_ready_identity = identity
                self.package_v2_report_view.setStyleSheet("")
                mesh_warnings = payload.get("execution", {}).get("mesh_warnings", ())
                self.package_v2_status_label.setStyleSheet(
                    self._semantic_style("warning" if mesh_warnings else "success")
                )
                self.package_v2_status_label.setText(
                    f"Package V2 complete package 已通过 report-ready 复核：{output}"
                    + (f" · 网格警告 {len(mesh_warnings)} 项，请查看‘结果报告 → 网格警告’" if mesh_warnings else "")
                )
                self.package_v2_phase_label.setText(
                    "阶段 8/8 · Package V2 Job 完成"
                )
                self.package_v2_detail_label.setText(
                    f"MSH、parameters 与 report 已验证：{output}"
                )
                self.package_v2_progress_bar.setRange(
                    0, PACKAGE_V2_PROGRESS_PHASE_COUNT
                )
                self.package_v2_progress_bar.setValue(
                    PACKAGE_V2_PROGRESS_PHASE_COUNT
                )
                self.package_v2_progress_bar.setFormat("完成 %v/%m")
            else:
                self._package_v2_ready_identity = None
                self.package_v2_report_view.setStyleSheet(
                    self._semantic_style("warning")
                )
                self.package_v2_status_label.setStyleSheet(
                    self._semantic_style("warning")
                )
                self.package_v2_status_label.setText(
                    "先前 Job 已完成并通过报告复核，但当前 Job 文件或路径已变化；"
                    "旧结果不代表当前页面。"
                )
                self.package_v2_detail_label.setText(
                    "旧任务产物已验证，但当前页面 Job 已变化。"
                )
                self.package_v2_progress_bar.setRange(
                    0, PACKAGE_V2_PROGRESS_PHASE_COUNT
                )
                self.package_v2_progress_bar.setValue(
                    PACKAGE_V2_PROGRESS_PHASE_COUNT
                )
                self.package_v2_progress_bar.setFormat("旧任务完成")
            return

        try:
            details = (
                log_path.read_text(encoding="utf-8", errors="replace")
                if log_path.exists()
                else "无日志"
            )
        except (OSError, UnicodeError) as exc:
            details = f"日志读取失败：{exc}"
        reason = (
            "worker 返回成功但没有发布属于当前 Job 的 fresh report"
            if return_code == 0
            else f"worker 退出码={return_code}"
        )
        diagnostics = getattr(self, "_package_v2_failure_diagnostics", [])
        if diagnostics:
            reason = "接触边界未对齐，生成已中止"
            self._show_package_v2_contact_failure(
                diagnostics[0], current=identity is None or self._package_v2_identity_is_current(identity)
            )
        self.package_v2_status_label.setStyleSheet(self._semantic_style("error"))
        self.package_v2_status_label.setText(
            f"Package V2 生成失败：{reason}；日志：{log_path}"
        )
        self.package_v2_report_view.setStyleSheet(self._semantic_style("error"))
        self.package_v2_report_view.setPlainText(
            f"{reason}\n日志：{log_path}\n\n"
            + (json.dumps({"status": "failed", "mesh_errors": diagnostics}, ensure_ascii=False, indent=2)
               if diagnostics else details[-5000:])
        )
        self.package_v2_phase_label.setText("Package V2 Job 执行失败")
        self.package_v2_detail_label.setText(
            f"{reason}；详见结果报告中的‘网格错误’。" if diagnostics else f"{reason}；详见运行日志。"
        )
        self.package_v2_progress_bar.setRange(
            0, PACKAGE_V2_PROGRESS_PHASE_COUNT
        )
        self.package_v2_progress_bar.setValue(0)
        self.package_v2_progress_bar.setFormat("执行失败")
        self.package_v2_result_tabs.setCurrentWidget(
            self.package_v2_report_tab if diagnostics else self.package_v2_log_tab
        )

    def _open_package_v2_msh(self, _checked: bool = False) -> None:
        self._refresh_package_v2_launch_state(preserve_status=True)
        if not self.package_v2_open_msh_button.isEnabled():
            QMessageBox.warning(
                self, "暂无可预览的网格",
                "请先生成网格，或检查已有 Job；当前任务需有已完成的 MSH 文件。",
            )
            return
        path = self._package_v2_ready_identity.output
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(path))):
            QMessageBox.warning(
                self, "无法打开网格预览",
                "请安装 Gmsh 等网格查看器，并将其设为 .msh 文件的默认打开程序。"
                f"\n\n网格文件：{path}",
            )

    def _handoff_package_v2_to_cdb(self, _checked: bool = False) -> None:
        del _checked
        identity = self._package_v2_ready_identity
        if identity is None or not self._package_v2_identity_is_current(identity):
            self._package_v2_ready_identity = None
            self._refresh_package_v2_launch_state()
            QMessageBox.warning(
                self,
                "Package V2 artifact 已陈旧",
                "只有仍与当前 immutable Job 一致的 report-ready MSH 才能交给 CDB 页。",
            )
            return
        try:
            self._validate_package_v2_report(
                identity,
                identity.output.with_suffix(".report.json"),
            )
        except (OSError, RuntimeError, TypeError, ValueError) as exc:
            self._package_v2_ready_identity = None
            self._refresh_package_v2_launch_state()
            QMessageBox.warning(
                self,
                "Package V2 artifact 复核失败",
                str(exc),
            )
            return
        self.cdb_input_edit.setText(str(identity.output))
        self.cdb_output_edit.setText(str(identity.output.with_suffix(".cdb")))
        self.main_tabs.setCurrentWidget(self.cdb_tab)
        self._refresh_cdb_launch_state()
        self._refresh_project_modified()

    def _launch_cdb(self) -> None:
        try:
            identity = self._current_cdb_job_identity(enforce_idle=True)
            if str(identity.source) != self.cdb_input_edit.text().strip():
                self.cdb_input_edit.setText(str(identity.source))
            if str(identity.output) != self.cdb_output_edit.text().strip():
                self.cdb_output_edit.setText(str(identity.output))
            identity.output.parent.mkdir(parents=True, exist_ok=True)
            project_document = self._current_project_document(active_tab="cdb")
            command = [
                *worker_command_prefix(),
                "--convert-msh",
                str(identity.source),
                "--output",
                str(identity.output),
                "--cdb-element-type",
                str(identity.element_type),
                "--cdb-coordinate-scale",
                f"{identity.coordinate_scale:.17g}",
                "--cdb-units",
                identity.units_label or "NONE",
            ]
            process = self._start_job(
                command,
                identity.output,
                preview=False,
                kind="cdb",
            )
            self._job_cdb_identities[id(process)] = identity
            self._queue_export_project(
                process,
                identity.output,
                project_document,
            )
        except (OSError, ValueError) as exc:
            self.cdb_status_label.setStyleSheet(self._semantic_style("error"))
            self.cdb_status_label.setText(f"无法启动 CDB 转换：{exc}")
            self.cdb_report_view.setStyleSheet(self._semantic_style("error"))
            self.cdb_report_view.setPlainText(f"后台 worker 未启动：{exc}")
            QMessageBox.critical(self, "CDB 转换参数错误", str(exc))
            return

        self._rendered_cdb_identity = None
        self.cdb_report_view.setStyleSheet("")
        self.cdb_report_view.setPlainText(
            "后台 worker 正在转换。完成后将校验报告路径、SOLID 类型、"
            "节点/单元计数和 CDB 文件大小，并显示 worker 写入的 SHA-256。"
        )
        self.cdb_status_label.setStyleSheet(self._semantic_style("muted"))
        self.cdb_status_label.setText(
            f"正在后台转换为 SOLID{identity.element_type} CDB…"
        )

    @staticmethod
    def _report_path_for_job(output: Path, kind: str) -> Path:
        if kind == "cdb":
            return output.with_name(f"{output.name}.report.json")
        return output.with_suffix(".report.json")

    @staticmethod
    def _log_path_for_job(output: Path, kind: str) -> Path:
        if kind == "cdb":
            return output.with_name(f"{output.name}.log")
        return output.with_suffix(".log")

    @staticmethod
    def _report_signature(path: Path) -> tuple[int, int, int] | None:
        try:
            stat = path.stat()
        except OSError:
            return None
        return (int(stat.st_ino), int(stat.st_mtime_ns), int(stat.st_size))

    def _start_job(
        self,
        command: list[str],
        output: Path,
        *,
        preview: bool,
        kind: str,
        append_job_id: bool = True,
        bound_job_id: str | None = None,
    ) -> subprocess.Popen[str]:
        if output in self._active_job_outputs:
            raise ValueError(f"该输出已有生成任务正在运行：{output}")
        if kind != "cdb" and any(
            paths_refer_to_same_file(output, identity.source)
            for identity in self._job_cdb_identities.values()
        ):
            raise ValueError("该 MSH 正作为 CDB 转换输入，不能同时被生成任务覆盖。")
        if kind in self._active_job_kinds:
            raise ValueError("该页面已有生成任务正在运行，请等待其完成。")
        layout_settings = (
            self._current_layout_report_settings() if kind == "layout" else None
        )
        layout_report_identity = (
            self._current_layout_job_report_identity()
            if kind == "layout"
            else None
        )
        if kind == "layout" and layout_settings is None:
            raise ValueError("布局页面参数尚未形成稳定的任务快照。")
        if kind == "layout" and layout_report_identity is None:
            raise ValueError("布局页面内容尚未形成稳定的报告校验快照。")
        log_path = self._log_path_for_job(output, kind)
        report_path = self._report_path_for_job(output, kind)
        baseline_report = self._report_signature(report_path)
        job_id = bound_job_id or uuid.uuid4().hex
        worker_command = (
            [*command, "--job-id", job_id]
            if append_job_id
            else list(command)
        )
        log_file = log_path.open("w", encoding="utf-8")
        try:
            process = subprocess.Popen(
                worker_command,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                text=True,
                **worker_popen_options(),
            )
        finally:
            log_file.close()
        process_id = id(process)
        self._quality_warning_reports.discard(report_path)
        self._jobs.append((process, output, log_path, preview))
        self._job_kinds[process_id] = kind
        self._job_ids[process_id] = job_id
        self._job_report_snapshots[process_id] = baseline_report
        if kind == "layout":
            assert layout_settings is not None
            assert layout_report_identity is not None
            self._job_layout_settings[process_id] = layout_settings
            self._job_layout_dependencies[process_id] = dict(
                self._layout_dependency_signatures
            )
            self._job_layout_report_identities[process_id] = layout_report_identity
        self._active_job_outputs.add(output)
        self._active_job_kinds.add(kind)
        if kind == "layout":
            self.layout_preview_button.setEnabled(False)
            self.layout_generate_button.setEnabled(False)
        elif kind == "cdb":
            self.cdb_convert_button.setEnabled(False)
        elif kind == "package_v2":
            self.package_v2_generate_button.setEnabled(False)
            self.package_v2_inspect_button.setEnabled(False)
            self.package_v2_job_browse_button.setEnabled(False)
            self.package_v2_create_job_button.setEnabled(False)
        else:
            self.preview_button.setEnabled(False)
            self.generate_button.setEnabled(False)
        if not self._poll_timer.isActive():
            self._poll_timer.start()
        return process

    def _launch(self, *, preview: bool) -> None:
        try:
            parameters = self._parameters()
            self._validate_control_overrides()
            output_text = self.output_edit.text().strip()
            if not output_text:
                raise ValueError("请选择网格输出文件。")
            output = self._workspace_mesh_output(output_text)
            if str(output) != output_text:
                self.output_edit.setText(str(output))
            if output in self._active_job_outputs:
                raise ValueError(f"该输出已有生成任务正在运行：{output}")
            output.parent.mkdir(parents=True, exist_ok=True)
            project_document = self._current_project_document(active_tab="layer")
        except (ValueError, OSError) as exc:
            QMessageBox.critical(self, "参数错误", str(exc))
            return

        config_path = output.with_name(
            f".{output.stem}.{uuid.uuid4().hex}.input.json"
        )
        try:
            parameters.save_json(config_path)
            command = [
                *worker_command_prefix(),
                "--config",
                str(config_path),
                "--output",
                str(output),
            ]
            if preview:
                command.append("--preview")
            process = self._start_job(
                command,
                output,
                preview=preview,
                kind="layer",
            )
            self._job_config_snapshots[id(process)] = config_path
            self._job_layer_parameters[id(process)] = parameters
            self._queue_export_project(process, output, project_document)
        except (OSError, ValueError) as exc:
            try:
                config_path.unlink(missing_ok=True)
            except OSError:
                pass
            QMessageBox.critical(self, "无法启动 Gmsh", str(exc))
            return

        self.status_label.setText(
            "正在生成 Layer 轴对称网格；Gmsh 原生窗口打开后可旋转、剖切和查看材料 Physical Groups。"
            if preview
            else "正在后台生成 Layer 轴对称网格…"
        )

    def _complete_cdb_job(
        self,
        process: subprocess.Popen[str],
        output: Path,
        log_path: Path,
        return_code: int,
    ) -> None:
        process_id = id(process)
        identity = self._job_cdb_identities.get(process_id)
        report_path = self._report_path_for_job(output, "cdb")
        fresh_report = self._job_report_is_fresh(process, report_path)
        try:
            current_identity = self._current_cdb_job_identity(enforce_idle=False)
        except (OSError, ValueError):
            current_identity = None
        job_is_current = identity is not None and identity == current_identity

        if return_code == 0 and not job_is_current:
            stale_report_valid = False
            if identity is not None and fresh_report:
                try:
                    self._validate_cdb_report_payload(report_path, identity)
                except (
                    OSError,
                    UnicodeError,
                    ValueError,
                    TypeError,
                    json.JSONDecodeError,
                ):
                    pass
                else:
                    stale_report_valid = self._job_report_id_matches(
                        process_id,
                        report_path,
                    )
            if stale_report_valid:
                self._publish_job_project(process_id)
                if process_id in self._job_project_artifact_stale:
                    stale_report_valid = False
            self.cdb_status_label.setStyleSheet(self._semantic_style("warning"))
            if stale_report_valid:
                self.cdb_status_label.setText(
                    f"先前设置的 CDB 转换已完成并通过报告复核：{output}\n"
                    "当前输入或选项已经修改，旧任务报告未覆盖当前结果区。"
                )
            else:
                self.cdb_status_label.setText(
                    "先前设置的 worker 已退出，但其新报告缺失或未通过复核；"
                    "当前结果区未被覆盖。"
                )
            self.cdb_report_view.setStyleSheet(self._semantic_style("warning"))
            self.cdb_report_view.setPlainText(
                (
                    f"先前设置的 worker 报告已复核，位于：{report_path}\n"
                    if stale_report_valid
                    else f"先前设置的 worker 报告未通过复核：{report_path}\n"
                )
                + "当前页面设置与该任务不一致，因此未载入。"
            )
            return

        if return_code == 0:
            report_valid = bool(
                identity is not None
                and fresh_report
                and self._job_report_id_matches(process_id, report_path)
                and self._render_cdb_job_report(report_path, identity)
            )
            if report_valid:
                assert identity is not None
                self._publish_job_project(process_id)
                if process_id in self._job_project_artifact_stale:
                    report_valid = False
                    self._rendered_cdb_identity = None
                    self.cdb_report_view.setStyleSheet(
                        self._semantic_style("error")
                    )
                    self.cdb_report_view.setPlainText(
                        "CDB 产物在发布工程快照前已被替换，"
                        "本次转换复核失败；未保留先前的成功报告。"
                    )
            if report_valid:
                assert identity is not None
                self.cdb_status_label.setStyleSheet(
                    self._semantic_style("success")
                )
                self.cdb_status_label.setText(
                    f"完成：{output}\n"
                    f"SOLID{identity.element_type} 报告：{report_path}"
                )
                return
            message = (
                "worker 已退出，但本次新报告缺失、不可读，或 CDB 文件复核失败。\n"
                f"输出：{output}\n报告：{report_path}"
            )
            self.cdb_status_label.setStyleSheet(self._semantic_style("error"))
            self.cdb_status_label.setText(message)
            if not fresh_report:
                self._rendered_cdb_identity = None
                self.cdb_report_view.setStyleSheet(
                    self._semantic_style("error")
                )
                self.cdb_report_view.setPlainText(
                    f"本次转换没有生成新的结构化报告：{report_path}"
                )
            QMessageBox.critical(self, "CDB 转换复核失败", message)
            return

        try:
            details = (
                log_path.read_text(encoding="utf-8", errors="replace")
                if log_path.exists()
                else "无日志"
            )
        except (OSError, UnicodeError) as exc:
            details = f"日志读取失败：{exc}"
        if not job_is_current:
            self.cdb_status_label.setStyleSheet(self._semantic_style("warning"))
            self.cdb_status_label.setText(
                f"先前设置的 CDB 转换失败，日志：{log_path}\n"
                "当前输入已经修改，旧任务错误未覆盖当前结果区。"
            )
            return
        self._rendered_cdb_identity = None
        self.cdb_status_label.setStyleSheet(self._semantic_style("error"))
        self.cdb_status_label.setText(f"CDB 转换失败，详见：{log_path}")
        self.cdb_report_view.setStyleSheet(self._semantic_style("error"))
        self.cdb_report_view.setPlainText(
            f"MSH → CDB 转换失败。\n日志：{log_path}\n\n{details[-3000:]}"
        )
        QMessageBox.critical(self, "CDB 转换失败", details[-5000:])

    def _poll_jobs(self) -> None:
        remaining: list[tuple[subprocess.Popen[str], Path, Path, bool]] = []
        for process, output, log_path, preview in self._jobs:
            process_id = id(process)
            self._job_project_publication_deferred.discard(process_id)
            kind = self._job_kinds.get(process_id, "layer")
            if kind == "package_v2":
                run_state = self._poll_package_v2_run(process, log_path)
                return_code = process.poll()
                if return_code is None:
                    remaining.append((process, output, log_path, preview))
                    continue
                if run_state is not None and run_state.cancel_requested:
                    self._package_v2_ready_identity = None
                    self.package_v2_status_label.setStyleSheet(
                        self._semantic_style("warning")
                    )
                    self.package_v2_status_label.setText(
                        f"Package V2 Job 已由用户取消；日志：{log_path}"
                    )
                    self.package_v2_phase_label.setText(
                        "Package V2 Job 已取消"
                    )
                    self.package_v2_detail_label.setText(
                        "未接受本次运行的 report 或产物；完整日志已保留。"
                    )
                    self.package_v2_progress_bar.setRange(
                        0, PACKAGE_V2_PROGRESS_PHASE_COUNT
                    )
                    self.package_v2_progress_bar.setValue(0)
                    self.package_v2_progress_bar.setFormat("已取消")
                    self._append_package_v2_runtime_log(
                        f"worker 已退出，return code={return_code}；任务标记为用户取消。"
                    )
                else:
                    self._complete_package_v2_job(
                        process,
                        output,
                        log_path,
                        return_code,
                    )
                self._job_kinds.pop(process_id, None)
                self._job_report_snapshots.pop(process_id, None)
                self._job_package_v2_identities.pop(process_id, None)
                self._job_ids.pop(process_id, None)
                private_job = self._job_config_snapshots.pop(process_id, None)
                if private_job is not None:
                    try:
                        private_job.unlink(missing_ok=True)
                    except OSError:
                        pass
                self._cleanup_package_v2_run(process_id)
                self._active_job_outputs.discard(output)
                self._active_job_kinds.discard(kind)
                self._refresh_package_v2_launch_state(preserve_status=True)
                continue
            if kind == "cdb":
                return_code = process.poll()
                if return_code is None:
                    remaining.append((process, output, log_path, preview))
                    continue
                self._complete_cdb_job(
                    process,
                    output,
                    log_path,
                    return_code,
                )
                if process_id in self._job_project_publication_deferred:
                    self.cdb_status_label.setStyleSheet(
                        self._semantic_style("muted")
                    )
                    self.cdb_status_label.setText(
                        "CDB 已通过复核；正在等待同名产物锁以发布工程快照。"
                    )
                    remaining.append((process, output, log_path, preview))
                    continue
                self._job_kinds.pop(process_id, None)
                self._job_report_snapshots.pop(process_id, None)
                self._job_cdb_identities.pop(process_id, None)
                self._job_ids.pop(process_id, None)
                self._job_report_validation.pop(process_id, None)
                self._job_project_snapshots.pop(process_id, None)
                self._job_project_publication_deferred.discard(process_id)
                self._job_project_artifact_stale.discard(process_id)
                self._active_job_outputs.discard(output)
                self._active_job_kinds.discard(kind)
                self._refresh_cdb_launch_state(preserve_status=True)
                continue
            status_label = (
                self.layout_status_label if kind == "layout" else self.status_label
            )
            model_label = "多 Bump 连接网格" if kind == "layout" else "Layer 轴对称网格"
            dependency_snapshot = self._job_layout_dependencies.get(process_id)
            changed_dependencies: list[Path] = []
            if dependency_snapshot is not None:
                for path, signature in dependency_snapshot.items():
                    current_signature = self._layout_dependency_snapshot_signature(
                        path
                    )
                    if current_signature != signature:
                        changed_dependencies.append(path)
            dependencies_unchanged = not changed_dependencies
            current_layout_settings = self._current_layout_report_settings()
            job_layout_settings = self._job_layout_settings.get(process_id)
            layout_settings_match = (
                job_layout_settings is None
                or job_layout_settings == current_layout_settings
            )
            layout_page_marked_stale = bool(
                kind == "layout"
                and changed_dependencies
                and dependency_snapshot is not None
                and dependency_snapshot == self._layout_dependency_signatures
            )
            if layout_page_marked_stale:
                self._mark_layout_dependencies_stale(changed_dependencies)
            layout_job_is_current = (
                kind != "layout"
                or job_layout_settings is None
                or (layout_settings_match and dependencies_unchanged)
            )
            return_code = process.poll()
            report_path = output.with_suffix(".report.json")
            fresh_report = self._job_report_is_fresh(process, report_path)
            strict_job_report = process_id in self._job_ids
            project_snapshot_pending = process_id in self._job_project_snapshots
            artifacts_verified = (
                strict_job_report
                and self._mesh_job_artifacts_are_verified(
                    process_id,
                    kind=kind,
                    output=output,
                    report_path=report_path,
                    fresh_report=fresh_report,
                )
            )
            if artifacts_verified:
                self._job_report_validation[process_id] = True
                if project_snapshot_pending and (return_code == 0 or preview):
                    self._publish_job_project(process_id)
                    if process_id in self._job_project_artifact_stale:
                        artifacts_verified = False
                        self._job_report_validation[process_id] = False
            elif strict_job_report:
                self._job_report_validation[process_id] = False
            launch_report_verified = (
                artifacts_verified
                if strict_job_report
                else self._job_report_validation.get(process_id, False)
            )
            if (
                return_code is not None
                and process_id in self._job_project_publication_deferred
            ):
                status_label.setStyleSheet(self._semantic_style("muted"))
                status_label.setText(
                    f"{model_label}已通过复核；正在等待同名产物锁以发布工程快照。"
                )
                remaining.append((process, output, log_path, preview))
                continue
            if return_code is None:
                if preview and fresh_report:
                    if kind == "layout" and not layout_job_is_current:
                        if not layout_page_marked_stale:
                            status_label.setStyleSheet(self._semantic_style("warning"))
                            status_label.setText(
                                "先前页面参数的连接网格已生成，Gmsh 预览仍在运行；"
                                "当前输入已修改，因此未把旧任务报告载入当前结果区。"
                            )
                        remaining.append((process, output, log_path, preview))
                        continue
                    report_valid = launch_report_verified if strict_job_report else True
                    if kind == "layout" and report_valid:
                        report_valid = self._validate_layout_job_report(
                            process_id,
                            report_path,
                            render=True,
                        )
                        self._job_report_validation[process_id] = report_valid
                    elif (
                        kind == "layout"
                        and strict_job_report
                        and fresh_report
                        and self._job_report_id_matches(process_id, report_path)
                    ):
                        self._validate_layout_job_report(
                            process_id,
                            report_path,
                            render=True,
                        )
                    elif kind == "layout" and not strict_job_report:
                        if process_id not in self._job_report_validation:
                            self._job_report_validation[process_id] = (
                                self._validate_layout_job_report(
                                    process_id,
                                    report_path,
                                    render=True,
                                )
                        )
                        report_valid = self._job_report_validation[process_id]
                    if not report_valid:
                        status_label.setStyleSheet(self._semantic_style("error"))
                        status_label.setText(
                            f"检测到新的{model_label}报告，但它不属于本次任务或复核失败；"
                            "预览窗口仍在运行，工程快照尚未发布。"
                        )
                    elif not self._show_quality_feedback(
                        output,
                        report_path,
                        preview_running=True,
                        status_label=status_label,
                    ):
                        status_label.setStyleSheet("")
                        status_label.setText(
                            f"{model_label}已生成：{output}\nGmsh 预览窗口正在运行。"
                        )
                remaining.append((process, output, log_path, preview))
                continue
            if return_code == 0:
                if strict_job_report:
                    report_valid = launch_report_verified
                    if kind == "layout" and report_valid and layout_job_is_current:
                        report_valid = self._validate_layout_job_report(
                            process_id,
                            report_path,
                            render=True,
                        )
                        self._job_report_validation[process_id] = report_valid
                    elif (
                        kind == "layout"
                        and layout_job_is_current
                        and fresh_report
                        and self._job_report_id_matches(process_id, report_path)
                    ):
                        self._validate_layout_job_report(
                            process_id,
                            report_path,
                            render=True,
                        )
                else:
                    report_valid = True
                    if kind == "layout" and layout_job_is_current:
                        report_valid = fresh_report and (
                            self._validate_layout_job_report(
                                process_id,
                                report_path,
                                render=True,
                            )
                        )
                        self._job_report_validation[process_id] = report_valid
                if kind == "layout" and not layout_job_is_current:
                    if not layout_page_marked_stale:
                        if report_valid:
                            status_label.setStyleSheet(
                                self._semantic_style("warning")
                            )
                            status_label.setText(
                                f"先前页面参数的任务已完成：{output}\n"
                                "当前输入已经修改，旧任务报告未覆盖当前结果区。"
                            )
                        else:
                            status_label.setStyleSheet(
                                self._semantic_style("error")
                            )
                            status_label.setText(
                                "先前页面参数的 worker 已退出，但新报告缺失、"
                                "不属于本次任务或复核失败；工程快照未发布。"
                            )
                elif not report_valid:
                    message = (
                        "worker 已退出，但新报告缺失、不可读、不属于本次任务，"
                        "或产物复核失败；工程快照未发布。\n"
                        f"输出：{output}\n报告：{report_path}"
                    )
                    status_label.setStyleSheet(self._semantic_style("error"))
                    status_label.setText(message)
                    QMessageBox.critical(
                        self,
                        (
                            "连接网格复核失败"
                            if kind == "layout"
                            else "Layer 网格复核失败"
                        ),
                        message,
                    )
                elif layout_job_is_current and not self._show_quality_feedback(
                    output,
                    report_path,
                    preview_running=False,
                    status_label=status_label,
                ):
                    status_label.setStyleSheet("")
                    status_label.setText(f"完成：{output}\n质量报告：{report_path}")
            else:
                try:
                    details = (
                        log_path.read_text(encoding="utf-8", errors="replace")
                        if log_path.exists()
                        else "无日志"
                    )
                except (OSError, UnicodeError) as exc:
                    details = f"日志读取失败：{exc}"
                report_valid = launch_report_verified if strict_job_report else True
                if preview and report_valid and kind == "layout":
                    report_valid = self._validate_layout_job_report(
                        process_id,
                        report_path,
                        render=layout_job_is_current,
                    )
                    self._job_report_validation[process_id] = report_valid
                elif preview and fresh_report and kind == "layout" and not strict_job_report:
                    report_valid = self._validate_layout_job_report(
                        process_id,
                        report_path,
                        render=layout_job_is_current,
                    )
                    self._job_report_validation[process_id] = report_valid
                preview_mesh_ready = preview and fresh_report and report_valid
                if preview_mesh_ready:
                    if kind == "layout" and not layout_job_is_current:
                        if not layout_page_marked_stale:
                            status_label.setStyleSheet(self._semantic_style("warning"))
                            status_label.setText(
                                "先前页面参数的连接网格已生成并通过任务报告复核；"
                                "Gmsh 预览进程退出失败。当前结果区未被覆盖。"
                            )
                    else:
                        status_label.setStyleSheet(self._semantic_style("warning"))
                        status_label.setText(
                            f"{model_label}已生成并通过报告复核：{output}\n"
                            f"但 Gmsh 预览进程退出失败，详见：{log_path}"
                        )
                        QMessageBox.warning(
                            self,
                            "网格已生成，预览失败",
                            f"网格和质量报告已经写出；只有 Gmsh 预览进程失败。\n\n"
                            f"{details[-5000:]}",
                        )
                elif kind == "layout" and not layout_job_is_current:
                    if not layout_page_marked_stale:
                        status_label.setStyleSheet(self._semantic_style("warning"))
                        status_label.setText(
                            f"先前页面参数的连接任务失败，日志：{log_path}\n"
                            "当前输入已经修改，旧任务错误未覆盖当前结果区。"
                        )
                else:
                    status_label.setStyleSheet(self._semantic_style("error"))
                    status_label.setText(f"{model_label}生成失败，详见：{log_path}")
                if kind == "layout" and layout_job_is_current and not preview_mesh_ready:
                    self.layout_report_view.setStyleSheet(self._semantic_style("error"))
                    self.layout_report_view.setPlainText(
                        f"连接网格生成失败。\n日志：{log_path}\n\n{details[-3000:]}"
                    )
                if not preview_mesh_ready and not (
                    kind == "layout" and not layout_job_is_current
                ):
                    QMessageBox.critical(self, "Gmsh 生成失败", details[-5000:])
            self._job_kinds.pop(process_id, None)
            self._job_report_snapshots.pop(process_id, None)
            self._job_layout_settings.pop(process_id, None)
            self._job_layout_dependencies.pop(process_id, None)
            self._job_layout_report_identities.pop(process_id, None)
            self._job_layer_parameters.pop(process_id, None)
            self._job_ids.pop(process_id, None)
            self._job_report_validation.pop(process_id, None)
            self._job_project_snapshots.pop(process_id, None)
            self._job_project_publication_deferred.discard(process_id)
            self._job_project_artifact_stale.discard(process_id)
            config_snapshot = self._job_config_snapshots.pop(process_id, None)
            if config_snapshot is not None:
                try:
                    config_snapshot.unlink(missing_ok=True)
                except OSError:
                    pass
            self._active_job_outputs.discard(output)
            self._active_job_kinds.discard(kind)
            if kind == "layout":
                self._refresh_layout_launch_state(preserve_status=True)
            else:
                self._refresh_derived()
        self._jobs = remaining
        if not self._jobs:
            self._poll_timer.stop()

    def _job_report_is_fresh(
        self,
        process: subprocess.Popen[str],
        report_path: Path,
    ) -> bool:
        process_id = id(process)
        current = self._report_signature(report_path)
        if process_id not in self._job_report_snapshots:
            # Legacy/tests may insert a job tuple directly.  Preserve the old
            # behavior for those callers, while launched jobs use a baseline.
            return current is not None
        return current is not None and current != self._job_report_snapshots[process_id]

    def _show_quality_feedback(
        self,
        output: Path,
        report_path: Path,
        *,
        preview_running: bool,
        status_label: QLabel | None = None,
    ) -> bool:
        """Surface shape warnings and aspect-ratio advice once per report."""

        target = self.status_label if status_label is None else status_label
        quality_warnings, quality_advisories = self._read_quality_feedback(report_path)
        if not quality_warnings and not quality_advisories:
            return False

        warning_text = "\n".join(f"• {item}" for item in quality_warnings)
        advisory_text = "\n".join(f"• {item}" for item in quality_advisories)
        preview_suffix = "\nGmsh 预览窗口正在运行。" if preview_running else ""

        if quality_warnings:
            advisory_status = (
                f"\n另有高长宽比提示：\n{advisory_text}"
                if quality_advisories
                else ""
            )
            target.setStyleSheet(self._semantic_style("error"))
            target.setText(
                f"完成，但存在形状质量警告：{output}\n"
                f"质量报告：{report_path}\n{warning_text}"
                f"{advisory_status}{preview_suffix}"
            )
        else:
            target.setStyleSheet("")
            target.setText(
                f"完成：{output}\n"
                f"质量报告：{report_path}\n"
                f"高长宽比提示：\n{advisory_text}{preview_suffix}"
            )

        if report_path not in self._quality_warning_reports:
            self._quality_warning_reports.add(report_path)
            if quality_warnings:
                advisory_message = (
                    "\n\n另有高长宽比提示：\n"
                    f"{advisory_text}"
                    if quality_advisories
                    else ""
                )
                QMessageBox.warning(
                    self,
                    "形状质量警告",
                    "网格已成功生成，但以下指标显示存在明显形状扭曲：\n\n"
                    f"{warning_text}{advisory_message}\n\n"
                    "请检查局部网格尺寸和过渡。",
                )
            else:
                QMessageBox.information(
                    self,
                    "高长宽比提示",
                    "网格已成功生成。以下指标更可能由单元高长宽比主导，"
                    "不等同于形状扭曲：\n\n"
                    f"{advisory_text}\n\n"
                    "若短边方向与薄层或主要场梯度一致，通常可以接受；"
                    "建议用网格收敛验证确认。",
                )
        return True

    @staticmethod
    def _read_quality_feedback(
        report_path: Path,
    ) -> tuple[tuple[str, ...], tuple[str, ...]]:
        """Best-effort report inspection; a read error cannot undo mesh success."""

        def _messages(value: object) -> tuple[str, ...]:
            if not isinstance(value, (list, tuple)):
                return ()
            return tuple(
                item.strip()
                for item in value
                if isinstance(item, str) and item.strip()
            )

        try:
            payload = json.loads(report_path.read_text(encoding="utf-8"))
            quality = payload.get("quality", {})
            return (
                _messages(quality.get("quality_warnings", ())),
                _messages(quality.get("quality_advisories", ())),
            )
        except (OSError, UnicodeError, json.JSONDecodeError, AttributeError):
            return (), ()

    # Kept for callers that inspect legacy reports directly.
    @staticmethod
    def _read_quality_warnings(report_path: Path) -> tuple[str, ...]:
        return ConcentricMeshApp._read_quality_feedback(report_path)[0]

    # The old private entry point remains an alias for compatibility.  It now
    # also handles the advisory-only report schema.
    def _show_quality_warnings(
        self,
        output: Path,
        report_path: Path,
        *,
        preview_running: bool,
    ) -> bool:
        return self._show_quality_feedback(
            output, report_path, preview_running=preview_running
        )

    def closeEvent(self, event: QCloseEvent) -> None:  # noqa: N802 - Qt API
        """Confirm and stop live mesh workers before the Qt window exits."""

        self._publish_ready_job_projects()
        if self.isWindowModified() and self.isVisible():
            answer = QMessageBox.warning(
                self,
                "当前工程尚未保存",
                "当前工程包含尚未保存的设置。关闭前是否保存？",
                (
                    QMessageBox.StandardButton.Save
                    | QMessageBox.StandardButton.Discard
                    | QMessageBox.StandardButton.Cancel
                ),
                QMessageBox.StandardButton.Save,
            )
            if answer == QMessageBox.StandardButton.Cancel:
                event.ignore()
                return
            if (
                answer == QMessageBox.StandardButton.Save
                and not self._save_project()
            ):
                event.ignore()
                return

        live_processes = [
            process
            for process, _output, _log_path, _preview in self._jobs
            if process.poll() is None
        ]
        if live_processes and self.isVisible():
            answer = QMessageBox.question(
                self,
                "生成任务仍在运行",
                "关闭 EasyMesh 将停止仍在运行的网格生成、CDB 转换或 Gmsh 预览。\n"
                "确定要关闭吗？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return

        self._poll_timer.stop()
        self._contact_watch.stop()
        self._invalidate_contact_preview(stop_process=True)
        for process in live_processes:
            try:
                process.terminate()
            except OSError:
                pass
        for process in live_processes:
            try:
                process.wait(timeout=3.0)
            except subprocess.TimeoutExpired:
                try:
                    process.kill()
                    process.wait(timeout=1.0)
                except (OSError, subprocess.TimeoutExpired):
                    pass
            except OSError:
                pass
        self._publish_ready_job_projects()
        for config_path in tuple(self._job_config_snapshots.values()):
            try:
                config_path.unlink(missing_ok=True)
            except OSError:
                pass
        for state in tuple(self._package_v2_runs.values()):
            try:
                state.progress_path.unlink(missing_ok=True)
            except OSError:
                pass
        self._jobs.clear()
        self._job_kinds.clear()
        self._job_report_snapshots.clear()
        self._job_layout_settings.clear()
        self._job_layout_dependencies.clear()
        self._job_layout_report_identities.clear()
        self._job_cdb_identities.clear()
        self._job_package_v2_identities.clear()
        self._package_v2_runs.clear()
        self._job_layer_parameters.clear()
        self._job_ids.clear()
        self._job_report_validation.clear()
        self._job_project_snapshots.clear()
        self._job_project_publication_deferred.clear()
        self._job_project_artifact_stale.clear()
        self._job_config_snapshots.clear()
        self._active_job_outputs.clear()
        self._active_job_kinds.clear()
        event.accept()


def run_gui() -> None:
    QApplication.setOrganizationName("EasyMesh")
    QApplication.setOrganizationDomain("easymesh.local")
    QApplication.setApplicationName("EasyMesh")
    QApplication.setApplicationDisplayName("EasyMesh")
    app = QApplication.instance()
    owns_application = app is None
    if app is None:
        app = QApplication(sys.argv)
    window = ConcentricMeshApp()
    window.show()
    if owns_application:
        app.exec()
