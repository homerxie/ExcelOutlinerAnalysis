"""Transactional table model for editable Package V2 Source files.

This module deliberately has no Qt dependency.  It opens a real
``*.source.json`` file, compiles the exact bytes before materialising an
ordered JSON document, and exposes compact typed rows for a GUI adapter.

Scalar and supported structural edits are JSON-Pointer-addressed
transactions.  A candidate document must pass the complete Package V2
parser/compiler before it replaces the in-memory draft.  Saving is a separate
atomic compare-and-swap operation; it never creates or mutates an immutable
Package V2 Job.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation, localcontext
from enum import Enum
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tempfile
from typing import Mapping, Sequence

from .output_artifacts import exclusive_artifact_lock
from .package_assembly import (
    COMPONENT_LOCAL_DIRECTIONS,
    ComponentLocalDirection,
    OrthogonalHexMeshStrategy,
    StructuredSweepMeshStrategy,
)
from .package_v2_compile import PackageV2CompileResult, compile_package_v2
from .package_v2_geometry import GeometryTransientConstraintError
from .package_v2_instances import transform_values
from .package_v2_instance_transform import compose_placement, describe_orientation, frozen_placement_controls
from .package_v2_source import (
    AUTHORING_MESH_STRATEGY_TOKENS,
    MAX_SOURCE_BYTES,
)


JsonToken = str | int
JsonDocument = dict[str, object]


class SourceCellKind(str, Enum):
    """How GUI text is decoded before it is placed in the JSON document."""

    EXPRESSION = "expression"
    MATERIAL = "material"
    PATH = "path"
    INTEGER = "integer"
    NUMBER = "number"
    UNIT = "unit"
    VARIABLE_NAME = "variable_name"


@dataclass(frozen=True, slots=True)
class SourceFileSignature:
    device: int
    inode: int
    modified_ns: int
    size: int


@dataclass(frozen=True, slots=True)
class ResolvedValue:
    owner_id: str
    value: float | int | str
    unit: str
    source: str = "compiled"

    @property
    def display(self) -> str:
        if isinstance(self.value, float):
            rendered = f"{self.value:.12g}"
        else:
            rendered = str(self.value)
        return f"{rendered} {self.unit}" if self.unit else rendered


@dataclass(frozen=True, slots=True)
class SourceCell:
    """One stable scalar cell bound to an RFC-6901 JSON Pointer."""

    pointer: str
    label: str
    display: str
    editable: bool
    kind: SourceCellKind
    resolved: tuple[ResolvedValue, ...] = ()
    dependencies: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class VariableRow:
    pointer: str
    display: str
    editable: bool
    resolved: tuple[ResolvedValue, ...]
    dependencies: tuple[str, ...]
    template_id: str
    name: str
    role: str
    dimension: str
    declared_unit: str
    value: SourceCell | None
    unit: SourceCell | None = None
    references: tuple[str, ...] = ()
    name_cell: SourceCell | None = None


@dataclass(frozen=True, slots=True)
class GeometryFragmentRow:
    pointer: str
    geometry_id: str
    kind: str
    leaves: tuple[SourceCell, ...]


@dataclass(frozen=True, slots=True)
class GeometryRow:
    pointer: str
    display: str
    editable: bool
    resolved: tuple[ResolvedValue, ...]
    dependencies: tuple[str, ...]
    template_id: str
    component_id: str
    material: SourceCell
    fragments: tuple[GeometryFragmentRow, ...]


@dataclass(frozen=True, slots=True)
class ResolvedMeshControl:
    instance_id: str
    mesh_priority: int
    target_edge_mm: float
    transition_distance_mm: float
    strategy_kind: str
    sweep_direction: str | None = None
    directional_near_edge_mm: tuple[tuple[str, float], ...] = ()
    partition_origin_mm: tuple[float, float, float] | None = None
    plane_size_mm: float | None = None
    plane_transition_distance_mm: float | None = None
    layer_size_mm: float | None = None
    surface_size_mm: float | None = None


@dataclass(frozen=True, slots=True)
class MeshRow:
    pointer: str
    display: str
    editable: bool
    resolved: tuple[ResolvedMeshControl, ...]
    dependencies: tuple[str, ...]
    template_id: str
    component_id: str
    mesh_priority: SourceCell
    target_edge: SourceCell
    transition_distance: SourceCell
    strategy_kind: str
    sweep_direction: str | None = None
    directional_near_edge: tuple[SourceCell, ...] = ()
    partition_origin: tuple[SourceCell, ...] = ()
    strategy_options: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class FrozenRow:
    pointer: str
    display: str
    editable: bool
    resolved: tuple[ResolvedValue, ...]
    dependencies: tuple[str, ...]
    source_id: str
    components: tuple[str, ...]
    artifacts: tuple[SourceCell, ...]
    translation: tuple[SourceCell, ...]
    rotation_matrix: tuple[SourceCell, ...]
    orientation_description: str = ""


@dataclass(frozen=True, slots=True)
class MeshSettingsRow:
    interface_geometry_tolerance: SourceCell
    parallel_tet_candidates: bool = False


@dataclass(frozen=True, slots=True)
class SourceTableSet:
    variables: tuple[VariableRow, ...]
    geometry: tuple[GeometryRow, ...]
    meshes: tuple[MeshRow, ...]
    frozen: tuple[FrozenRow, ...]
    settings: MeshSettingsRow

    @property
    def mesh(self) -> tuple[MeshRow, ...]:
        """Singular mesh-table accessor."""

        return self.meshes


@dataclass(frozen=True, slots=True)
class SourceEditResult:
    pointer: str
    previous_display: str
    current_display: str
    raw_sha256: str
    plan_sha256: str
    changed: bool


@dataclass(frozen=True, slots=True)
class SourceUnitChangeResult:
    unit_pointer: str
    previous_unit: str
    current_unit: str
    converted_pointers: tuple[str, ...]
    raw_sha256: str
    plan_sha256: str
    changed: bool


class PackageV2SourceEditorError(ValueError):
    """Base error for Source editor loading, editing, and publication."""


class PackageV2SourceEditError(PackageV2SourceEditorError):
    def __init__(self, pointer: str, message: str) -> None:
        self.pointer = pointer
        self.message = message
        super().__init__(f"Package V2 Source edit failed at {pointer}: {message}")


class PackageV2SourcePendingError(PackageV2SourceEditError):
    """A valid JSON candidate blocked only by a transient geometry constraint.

    The editor remains on its last fully compiled state.  GUI adapters may
    retain ``candidate_text`` and coordinate more scalar edits before retrying
    them together with :meth:`PackageV2SourceEditor.edit_many`.
    """

    def __init__(
        self,
        pointer: str,
        message: str,
        *,
        candidate_text: str,
        pointers: Sequence[str],
        constraint_code: str,
        constraint_paths: Sequence[str],
    ) -> None:
        super().__init__(pointer, message)
        self.candidate_text = candidate_text
        # Explicit alias for non-GUI adapters that describe the payload as raw
        # Source text.  Both names intentionally contain the exact same JSON.
        self.candidate_raw_text = candidate_text
        self.pointers = tuple(pointers)
        self.constraint_code = constraint_code
        self.constraint_paths = tuple(constraint_paths)


class PackageV2SourceConflictError(PackageV2SourceEditorError):
    """The on-disk Source no longer matches the editor's saved baseline."""


@dataclass(frozen=True, slots=True)
class _CellBinding:
    tokens: tuple[JsonToken, ...]
    kind: SourceCellKind
    cell: SourceCell
    length_unit: str | None = None
    parameter_key: tuple[str, str] | None = None


@dataclass(frozen=True, slots=True)
class _BuiltTables:
    tables: SourceTableSet
    bindings: Mapping[str, _CellBinding]


_IDENTIFIER_TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_FINITE_NUMBER_TEXT = re.compile(
    r"[+-]?(?:(?:[0-9]+(?:\.[0-9]*)?)|(?:\.[0-9]+))"
    r"(?:[eE][+-]?[0-9]+)?"
)
_SIMPLE_LENGTH_LITERAL = re.compile(
    r"\s*(?P<number>[+-]?(?:(?:[0-9]+(?:\.[0-9]*)?)|(?:\.[0-9]+))"
    r"(?:[eE][+-]?[0-9]+)?)\s*"
    r"(?P<unit>mm|um|\N{MICRO SIGN}m|\N{GREEK SMALL LETTER MU}m)\s*"
)
_MICROMETRE_UNITS = frozenset(
    {"um", "\N{MICRO SIGN}m", "\N{GREEK SMALL LETTER MU}m"}
)


def _transient_geometry_constraint(
    error: BaseException,
) -> GeometryTransientConstraintError | None:
    """Find a structured constraint through explicit stage-wrapper causes.

    Deliberately do not follow ``__context__``.  An isolated validation raised
    while handling an earlier transient error inherits that outer exception as
    implicit context; treating it as part of the new compiler failure would
    let the earlier transient mask an independently hard-invalid value.
    """

    current: BaseException | None = error
    visited: set[int] = set()
    while current is not None and id(current) not in visited:
        if isinstance(current, GeometryTransientConstraintError):
            return current
        visited.add(id(current))
        current = current.__cause__
    return None


def _audit_candidate_hard_template_constraints(data: bytes, *, source_name: str) -> None:
    """Check every current local scope and numeric leaf while deferring relationships.

    Only the editor uses this audit to retain a combined draft. Normal Source
    compilation and Job creation still reject every transient constraint.
    """
    from .package_template import resolve_template_parameters
    from .package_v2_compile import _compile_component_mesh_control
    from .package_v2_local_templates import expand_document, _validate_numeric_geometry
    from .package_v2_source import _parse_component_mesh_control

    def validate_hard_geometry(geometry):
        # Inspect children independently so a transient sibling cannot hide a
        # hard-invalid dimension inside a Boolean construction.
        if geometry["kind"] == "union":
            children = geometry["children"]
        elif geometry["kind"] == "difference":
            children = [geometry["base"], *geometry["cutters"]]
        else:
            children = []
        for child in children:
            validate_hard_geometry(child)
        try:
            _validate_numeric_geometry(geometry)
        except GeometryTransientConstraintError:
            pass

    components = expand_document(json.loads(data), geometry_validator=validate_hard_geometry)
    resolved = resolve_template_parameters(())
    for component in components:
        context = f"{source_name}/component[{component['id']}].mesh_control"
        control = _parse_component_mesh_control(component["mesh_control"], context)
        _compile_component_mesh_control(control, resolved, context=context)


def _escape_pointer_token(token: JsonToken) -> str:
    return str(token).replace("~", "~0").replace("/", "~1")


def _pointer(tokens: Sequence[JsonToken]) -> str:
    return "".join(f"/{_escape_pointer_token(token)}" for token in tokens)


def _display(value: object) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def _signature(value: os.stat_result) -> SourceFileSignature:
    return SourceFileSignature(
        int(value.st_dev),
        int(value.st_ino),
        int(value.st_mtime_ns),
        int(value.st_size),
    )


def _read_regular_source(path: Path) -> tuple[bytes, SourceFileSignature]:
    flags = os.O_RDONLY
    for name in ("O_BINARY", "O_CLOEXEC", "O_NONBLOCK"):
        flags |= int(getattr(os, name, 0))
    descriptor = os.open(path, flags)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise PackageV2SourceEditorError(
                "Package V2 Source must be a regular file"
            )
        if before.st_size > MAX_SOURCE_BYTES:
            raise PackageV2SourceEditorError(
                f"Package V2 Source exceeds the {MAX_SOURCE_BYTES}-byte limit"
            )
        remaining = MAX_SOURCE_BYTES + 1
        chunks: list[bytes] = []
        while remaining:
            chunk = os.read(descriptor, min(1024 * 1024, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        data = b"".join(chunks)
        after = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    if len(data) > MAX_SOURCE_BYTES:
        raise PackageV2SourceEditorError(
            f"Package V2 Source exceeds the {MAX_SOURCE_BYTES}-byte limit"
        )
    if _signature(before) != _signature(after) or len(data) != before.st_size:
        raise PackageV2SourceConflictError(
            "Package V2 Source changed while it was being read"
        )
    return data, _signature(after)


def _prepare_source_temporary(path: Path, data: bytes) -> Path:
    """Write and fsync a hidden sibling without changing the destination."""

    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.stem}.",
        suffix=path.suffix,
        dir=path.parent,
    )
    temporary = Path(temporary_name)
    try:
        offset = 0
        while offset < len(data):
            written = os.write(descriptor, data[offset:])
            if written <= 0:
                raise OSError("cannot write Package V2 Source draft")
            offset += written
        os.fsync(descriptor)
    except BaseException:
        os.close(descriptor)
        temporary.unlink(missing_ok=True)
        raise
    os.close(descriptor)
    return temporary


def _sync_file(path: Path) -> None:
    flags = os.O_RDONLY | int(getattr(os, "O_CLOEXEC", 0))
    descriptor = os.open(path, flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _sync_directory(path: Path) -> None:
    if os.name != "posix":  # Windows cannot open directories for fsync.
        return
    flags = os.O_RDONLY | int(getattr(os, "O_CLOEXEC", 0))
    descriptor = os.open(path, flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _bounded_xattrs(path: Path) -> tuple[tuple[bytes, bytes], ...]:
    """Read bounded extended attributes without assuming Python exposes xattr."""

    if all(hasattr(os, name) for name in ("listxattr", "getxattr")):
        names = tuple(os.listxattr(path))  # type: ignore[attr-defined]
        if len(names) > 4096:
            raise PackageV2SourceEditorError(
                "Package V2 Source has too many extended attributes"
            )
        values: list[tuple[bytes, bytes]] = []
        total = 0
        for name in names:
            encoded_name = os.fsencode(name)
            value = os.getxattr(path, name)  # type: ignore[attr-defined]
            total += len(encoded_name) + len(value)
            if total > MAX_SOURCE_BYTES:
                raise PackageV2SourceEditorError(
                    "Package V2 Source extended metadata exceeds the byte limit"
                )
            values.append((encoded_name, value))
        return tuple(values)
    if sys.platform != "darwin":
        return ()

    # The macOS Python shipped with some Gmsh/PySide runtimes omits os.*xattr,
    # while the filesystem still supports native attributes.  Bind the libc
    # calls directly so atomic replacement does not silently strip them.
    import ctypes

    libc = ctypes.CDLL(None, use_errno=True)
    listxattr = libc.listxattr
    listxattr.argtypes = [
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.c_int,
    ]
    listxattr.restype = ctypes.c_ssize_t
    getxattr = libc.getxattr
    getxattr.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.c_uint32,
        ctypes.c_int,
    ]
    getxattr.restype = ctypes.c_ssize_t
    encoded_path = os.fsencode(path)
    names_size = int(listxattr(encoded_path, None, 0, 0))
    if names_size < 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error), path)
    if names_size > MAX_SOURCE_BYTES:
        raise PackageV2SourceEditorError(
            "Package V2 Source extended metadata exceeds the byte limit"
        )
    if names_size == 0:
        return ()
    names_buffer = ctypes.create_string_buffer(names_size)
    consumed = int(listxattr(encoded_path, names_buffer, names_size, 0))
    if consumed < 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error), path)
    names = tuple(
        value for value in names_buffer.raw[:consumed].split(b"\0") if value
    )
    if len(names) > 4096:
        raise PackageV2SourceEditorError(
            "Package V2 Source has too many extended attributes"
        )
    values = []
    total = consumed
    for name in names:
        value_size = int(getxattr(encoded_path, name, None, 0, 0, 0))
        if value_size < 0:
            error = ctypes.get_errno()
            raise OSError(error, os.strerror(error), path)
        total += value_size
        if total > MAX_SOURCE_BYTES:
            raise PackageV2SourceEditorError(
                "Package V2 Source extended metadata exceeds the byte limit"
            )
        if value_size == 0:
            value = b""
        else:
            value_buffer = ctypes.create_string_buffer(value_size)
            copied = int(
                getxattr(
                    encoded_path,
                    name,
                    value_buffer,
                    value_size,
                    0,
                    0,
                )
            )
            if copied < 0:
                error = ctypes.get_errno()
                raise OSError(error, os.strerror(error), path)
            value = value_buffer.raw[:copied]
        values.append((name, value))
    return tuple(values)


def _copy_source_xattrs(source: Path, target: Path) -> None:
    values = _bounded_xattrs(source)
    if not values:
        return
    if hasattr(os, "setxattr"):
        for encoded_name, value in values:
            os.setxattr(  # type: ignore[attr-defined]
                target,
                os.fsdecode(encoded_name),
                value,
            )
        return
    if sys.platform != "darwin":
        raise PackageV2SourceEditorError(
            "cannot preserve Package V2 Source extended attributes"
        )

    import ctypes

    libc = ctypes.CDLL(None, use_errno=True)
    setxattr = libc.setxattr
    setxattr.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.c_uint32,
        ctypes.c_int,
    ]
    setxattr.restype = ctypes.c_int
    encoded_target = os.fsencode(target)
    for name, value in values:
        buffer = None if not value else ctypes.create_string_buffer(value)
        pointer = None if buffer is None else ctypes.cast(buffer, ctypes.c_void_p)
        if setxattr(encoded_target, name, pointer, len(value), 0, 0) != 0:
            error = ctypes.get_errno()
            raise OSError(error, os.strerror(error), target)


def _publish_source_draft(
    path: Path,
    temporary: Path,
    *,
    saved_bytes: bytes,
    saved_signature: SourceFileSignature,
) -> None:
    """Compare and publish under the cooperative per-Source writer lock."""

    with exclusive_artifact_lock(path):
        current_bytes, current_signature = _read_regular_source(path)
        if current_signature != saved_signature or current_bytes != saved_bytes:
            raise PackageV2SourceConflictError(
                "Package V2 Source changed outside this editor; "
                "refusing to overwrite it"
            )

        # Preserve the Source's access policy and extended metadata.  The
        # generic artifact publisher intentionally forces 0644 and is not
        # suitable for an editable user-owned source file.
        shutil.copystat(path, temporary, follow_symlinks=True)
        _copy_source_xattrs(path, temporary)
        os.utime(temporary, None)
        _sync_file(temporary)
        os.replace(temporary, path)
        _sync_directory(path.parent)


def _ordered_document(compiled: PackageV2CompileResult) -> JsonDocument:
    # Compilation has already performed strict UTF-8, duplicate-key, null,
    # nesting and schema validation.  The standard decoder is used only after
    # that boundary and preserves insertion order on supported Python versions.
    value = json.loads(compiled.parsed_source.raw_text)
    if not isinstance(value, dict):  # defensive; strict parser already proves it
        raise PackageV2SourceEditorError("Package V2 Source root is not an object")
    return value


def _encode_document(document: JsonDocument) -> bytes:
    return (
        json.dumps(
            document,
            ensure_ascii=False,
            allow_nan=False,
            indent=2,
            sort_keys=False,
        )
        + "\n"
    ).encode("utf-8")


def _unique_resolved(values: Sequence[ResolvedValue]) -> tuple[ResolvedValue, ...]:
    return tuple(dict.fromkeys(values))


def _cell(
    *,
    tokens: Sequence[JsonToken],
    label: str,
    value: object,
    editable: bool,
    kind: SourceCellKind,
    resolved: Sequence[ResolvedValue] = (),
    dependencies: Sequence[str] = (),
) -> SourceCell:
    return SourceCell(
        pointer=_pointer(tokens),
        label=label,
        display=_display(value),
        editable=editable,
        kind=kind,
        resolved=tuple(resolved),
        dependencies=tuple(dependencies),
    )


def _register(
    bindings: dict[str, _CellBinding],
    cell: SourceCell,
    tokens: Sequence[JsonToken],
    *,
    length_unit: str | None = None,
    parameter_key: tuple[str, str] | None = None,
) -> None:
    if not cell.editable:
        return
    if cell.pointer in bindings:
        raise PackageV2SourceEditorError(
            f"duplicate editable JSON Pointer {cell.pointer!r}"
        )
    bindings[cell.pointer] = _CellBinding(
        tuple(tokens),
        cell.kind,
        cell,
        length_unit,
        parameter_key,
    )


def _resolved_mesh_rows(
    compiled: PackageV2CompileResult,
) -> Mapping[tuple[str, str], tuple[ResolvedMeshControl, ...]]:
    values: dict[tuple[str, str], list[ResolvedMeshControl]] = {}
    for instance in compiled.generated_instances:
        for component in instance.components:
            control = component.mesh_control
            if control is None:
                continue
            strategy = control.strategy
            directional: tuple[tuple[str, float], ...] = ()
            partition_origin = None
            sweep_direction = None
            if type(strategy) is OrthogonalHexMeshStrategy:
                directional = tuple(
                    (
                        direction.value,
                        strategy.directional_near_edge_mm[direction],
                    )
                    for direction in COMPONENT_LOCAL_DIRECTIONS
                )
                partition_origin = strategy.partition_origin_mm
            elif type(strategy) is StructuredSweepMeshStrategy:
                sweep_direction = strategy.direction.value
                partition_origin = strategy.partition_origin_mm
            values.setdefault(
                (instance.template_id, component.local_component_id), []
            ).append(
                ResolvedMeshControl(
                    instance_id=instance.instance_id,
                    mesh_priority=control.mesh_priority,
                    target_edge_mm=control.target_edge_mm,
                    transition_distance_mm=control.transition_distance_mm,
                    strategy_kind=strategy.kind.value,
                    sweep_direction=sweep_direction,
                    directional_near_edge_mm=directional,
                    partition_origin_mm=partition_origin,
                    plane_size_mm=getattr(strategy, "plane_size_mm", None),
                    plane_transition_distance_mm=getattr(strategy, "plane_transition_distance_mm", None),
                    layer_size_mm=getattr(strategy, "layer_size_mm", None),
                    surface_size_mm=getattr(strategy, "surface_size_mm", None),
                )
            )
    return {key: tuple(value) for key, value in values.items()}


def _frozen_rows(
    document: JsonDocument,
    compiled: PackageV2CompileResult,
    *,
    read_only: bool,
    bindings: dict[str, _CellBinding],
) -> tuple[FrozenRow, ...]:
    compiled_by_id = {value.source_id: value for value in compiled.frozen_sources}
    rows: list[FrozenRow] = []
    values = document["frozen_sources"]
    assert isinstance(values, list)
    for index, raw_source in enumerate(values):
        assert isinstance(raw_source, dict)
        source_id = raw_source["id"]
        components = tuple(raw_source["components"])  # type: ignore[arg-type]
        assert isinstance(source_id, str)
        base_tokens: tuple[JsonToken, ...] = ("frozen_sources", index)
        raw_artifacts = raw_source["artifacts"]
        placement = raw_source["placement"]
        assert isinstance(raw_artifacts, dict) and isinstance(placement, dict)
        artifacts: list[SourceCell] = []
        for field_name in ("mesh",):
            tokens = (*base_tokens, "artifacts", field_name)
            cell = _cell(
                tokens=tokens,
                label=field_name,
                value=raw_artifacts[field_name],
                editable=not read_only,
                kind=SourceCellKind.PATH,
            )
            artifacts.append(cell)
            _register(bindings, cell, tokens)
        compiled_source = compiled_by_id[source_id]
        translation: list[SourceCell] = []
        raw_translation = placement["translation"]
        assert isinstance(raw_translation, list)
        for axis, scalar in enumerate(raw_translation):
            tokens = (*base_tokens, "placement", "translation", axis)
            cell = _cell(
                tokens=tokens,
                label=f"translation[{axis}]",
                value=scalar,
                editable=not read_only,
                kind=SourceCellKind.EXPRESSION,
                resolved=(
                    ResolvedValue(
                        source_id,
                        compiled_source.placement.translation_xyz_mm[axis],
                        "mm",
                    ),
                ),
            )
            translation.append(cell)
            _register(bindings, cell, tokens)
        rotation: list[SourceCell] = []
        raw_rotation = placement["rotation_matrix"]
        assert isinstance(raw_rotation, list)
        for row_index, raw_row in enumerate(raw_rotation):
            assert isinstance(raw_row, list)
            for column_index, scalar in enumerate(raw_row):
                tokens = (
                    *base_tokens,
                    "placement",
                    "rotation_matrix",
                    row_index,
                    column_index,
                )
                cell = _cell(
                    tokens=tokens,
                    label=f"rotation[{row_index},{column_index}]",
                    value=scalar,
                    editable=not read_only,
                    kind=SourceCellKind.NUMBER,
                    resolved=(
                        ResolvedValue(
                            source_id,
                            compiled_source.placement.rotation_matrix[row_index][
                                column_index
                            ],
                            "",
                        ),
                    ),
                )
                rotation.append(cell)
                _register(bindings, cell, tokens)
        all_cells = (*artifacts, *translation, *rotation)
        rows.append(
            FrozenRow(
                _pointer(base_tokens),
                f"{source_id} · {', '.join(components)}",
                any(cell.editable for cell in all_cells),
                _unique_resolved(
                    tuple(value for cell in all_cells for value in cell.resolved)
                ),
                (),
                source_id,
                components,  # type: ignore[arg-type]
                tuple(artifacts),
                tuple(translation),
                tuple(rotation),
                describe_orientation(frozen_placement_controls(placement)),
            )
        )
    return tuple(rows)


def _mesh_settings_row(
    document: JsonDocument,
    compiled: PackageV2CompileResult,
    *,
    read_only: bool,
) -> MeshSettingsRow:
    settings = compiled.parsed_source.document.mesh_settings
    raw_settings = document.get("mesh_settings")
    raw_value = settings.interface_geometry_tolerance_source
    if isinstance(raw_settings, dict):
        authored = raw_settings.get("interface_geometry_tolerance")
        if isinstance(authored, str):
            raw_value = authored
    cell = _cell(
        tokens=("mesh_settings", "interface_geometry_tolerance"),
        label="interface_geometry_tolerance",
        value=raw_value,
        editable=not read_only,
        kind=SourceCellKind.EXPRESSION,
        resolved=(
            ResolvedValue(
                compiled.parsed_source.document.package.identifier,
                compiled.interface_geometry_tolerance_mm,
                "mm",
                "source" if isinstance(raw_settings, dict) else "default",
            ),
        ),
    )
    return MeshSettingsRow(cell, settings.parallel_tet_candidates)


def _build_tables(document: JsonDocument, compiled: PackageV2CompileResult) -> _BuiltTables:
    from .package_v2_local_tables import build_tables
    return build_tables(document, compiled)


def _document_value(document: JsonDocument, tokens: Sequence[JsonToken]) -> object:
    value: object = document
    for token in tokens:
        if isinstance(token, int):
            assert isinstance(value, list)
            value = value[token]
        else:
            assert isinstance(value, dict)
            value = value[token]
    return value


def _set_document_value(
    document: JsonDocument,
    tokens: Sequence[JsonToken],
    new_value: object,
) -> None:
    if not tokens:
        raise PackageV2SourceEditorError("cannot replace the JSON root")
    parent: object = document
    for token in tokens[:-1]:
        if isinstance(token, int):
            assert isinstance(parent, list)
            parent = parent[token]
        else:
            assert isinstance(parent, dict)
            parent = parent[token]
    final = tokens[-1]
    if isinstance(final, int):
        assert isinstance(parent, list)
        parent[final] = new_value
    else:
        assert isinstance(parent, dict)
        parent[final] = new_value


def _source_length_unit(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("length unit must be um or mm")
    token = value.strip()
    if token == "mm" or token in _MICROMETRE_UNITS:
        return token
    raise ValueError("length unit must be um or mm")


def _canonical_length_unit(value: str) -> str:
    token = _source_length_unit(value)
    return "um" if token in _MICROMETRE_UNITS else "mm"


def _finite_decimal(value: str) -> Decimal | None:
    if _FINITE_NUMBER_TEXT.fullmatch(value) is None:
        return None
    try:
        number = Decimal(value)
    except InvalidOperation:
        return None
    return number if number.is_finite() else None


def _decimal_text(value: Decimal) -> str:
    if not value:
        return "0"
    with localcontext() as context:
        context.prec = max(50, len(value.as_tuple().digits) + 10)
        normalized = value.normalize()
    adjusted = normalized.adjusted()
    if -100 <= adjusted <= 100:
        return format(normalized, "f")
    rendered = format(normalized, "E").replace("E+", "e").replace("E", "e")
    return rendered


def _convert_simple_length_literal(value: str, target_unit: str) -> str:
    matched = _SIMPLE_LENGTH_LITERAL.fullmatch(value)
    if matched is None:
        return value
    number = _finite_decimal(matched.group("number"))
    if number is None:
        return value
    source_unit = matched.group("unit")
    source_scale_mm = (
        Decimal("0.001") if source_unit in _MICROMETRE_UNITS else Decimal(1)
    )
    target_scale_mm = Decimal("0.001") if target_unit == "um" else Decimal(1)
    with localcontext() as context:
        context.prec = max(50, len(number.as_tuple().digits) + 10)
        converted = number * source_scale_mm / target_scale_mm
    return f"{_decimal_text(converted)}{target_unit}"


def _decode_edit(
    text: str,
    kind: SourceCellKind,
    *,
    length_unit: str | None = None,
) -> object:
    if not isinstance(text, str):
        raise TypeError("cell text must be a string")
    if kind in (
        SourceCellKind.EXPRESSION,
        SourceCellKind.MATERIAL,
        SourceCellKind.PATH,
    ):
        if kind is SourceCellKind.EXPRESSION and length_unit is not None:
            stripped = text.strip()
            if _finite_decimal(stripped) is not None:
                return f"{stripped}{_source_length_unit(length_unit)}"
        return text
    if kind is SourceCellKind.UNIT:
        return _canonical_length_unit(text)
    if kind is SourceCellKind.INTEGER:
        if re.fullmatch(r"[+-]?[0-9]+", text) is None:
            raise ValueError("expected an integer")
        return int(text, 10)
    try:
        value = json.loads(text)
    except json.JSONDecodeError as error:
        raise ValueError("expected a finite JSON number") from error
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("expected a finite JSON number")
    try:
        number = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError("expected a finite JSON number") from error
    if not math.isfinite(number):
        raise ValueError("expected a finite JSON number")
    return value


class PackageV2SourceEditor:
    """One transactional editor session for a real portable Source file."""

    def __init__(
        self,
        *,
        path: Path,
        saved_bytes: bytes,
        saved_signature: SourceFileSignature,
        document: JsonDocument,
        compiled: PackageV2CompileResult,
        built: _BuiltTables,
    ) -> None:
        self._path = path
        self._saved_bytes = saved_bytes
        self._saved_signature = saved_signature
        self._saved_document = deepcopy(document)
        self._draft_bytes = saved_bytes
        self._document = document
        self._compiled = compiled
        self._tables = built.tables
        self._bindings = dict(built.bindings)

    @classmethod
    def open(cls, path: str | os.PathLike[str]) -> "PackageV2SourceEditor":
        requested = Path(path).expanduser()
        if not requested.name.endswith(".source.json"):
            raise PackageV2SourceEditorError(
                "Package V2 Source path must end in .source.json"
            )
        resolved = requested.resolve(strict=True)
        data, signature = _read_regular_source(resolved)
        # Strict compile is intentionally first.  The mutable/order-preserving
        # DOM is never constructed for an invalid or unsupported Source.
        compiled = compile_package_v2(
            data,
            source_name=resolved.name,
            source_root=resolved.parent,
        )
        document = _ordered_document(compiled)
        built = _build_tables(document, compiled)
        return cls(
            path=resolved,
            saved_bytes=data,
            saved_signature=signature,
            document=document,
            compiled=compiled,
            built=built,
        )

    @property
    def path(self) -> Path:
        return self._path

    @property
    def schema_revision(self) -> int:
        return self._compiled.parsed_source.document.schema_revision

    @property
    def read_only(self) -> bool:
        return False

    @property
    def dirty(self) -> bool:
        return self._draft_bytes != self._saved_bytes

    @property
    def raw_bytes(self) -> bytes:
        return bytes(self._draft_bytes)

    @property
    def raw_text(self) -> str:
        return self._draft_bytes.decode("utf-8")

    @property
    def raw_sha256(self) -> str:
        return hashlib.sha256(self._draft_bytes).hexdigest()

    @property
    def saved_sha256(self) -> str:
        return hashlib.sha256(self._saved_bytes).hexdigest()

    @property
    def saved_signature(self) -> SourceFileSignature:
        return self._saved_signature

    @property
    def compiled(self) -> PackageV2CompileResult:
        return self._compiled

    @property
    def tables(self) -> SourceTableSet:
        return self._tables

    @property
    def editable_pointers(self) -> frozenset[str]:
        return frozenset(self._bindings)

    @property
    def document(self) -> JsonDocument:
        return deepcopy(self._document)

    def _commit_structural_edit(
        self,
        *,
        pointer: str,
        previous: str,
        current: str,
        candidate_document: JsonDocument,
    ) -> SourceEditResult:
        """Compile and install one structural JSON edit atomically."""
        self._share_component_edit(candidate_document, pointer)

        if candidate_document == self._document:
            return SourceEditResult(
                pointer,
                previous,
                previous,
                self.raw_sha256,
                self._compiled.plan_digest,
                False,
            )
        try:
            encoded_candidate = _encode_document(candidate_document)
            candidate_bytes = (
                self._saved_bytes
                if encoded_candidate == _encode_document(self._saved_document)
                else encoded_candidate
            )
            candidate_compiled = compile_package_v2(
                candidate_bytes,
                source_name=self._path.name,
                source_root=self._path.parent,
            )
            candidate_built = _build_tables(
                candidate_document,
                candidate_compiled,
            )
        except Exception as error:
            raise PackageV2SourceEditError(pointer, str(error)) from error

        self._document = candidate_document
        self._draft_bytes = candidate_bytes
        self._compiled = candidate_compiled
        self._tables = candidate_built.tables
        self._bindings = dict(candidate_built.bindings)
        return SourceEditResult(
            pointer,
            previous,
            current,
            self.raw_sha256,
            self._compiled.plan_digest,
            True,
        )

    def change_parallel_tet_candidates(self, enabled: bool) -> SourceEditResult:
        pointer = "/mesh_settings/parallel_tet_candidates"
        if self.read_only:
            raise PackageV2SourceEditError(pointer, "the Source is read-only")
        if type(enabled) is not bool:
            raise PackageV2SourceEditError(pointer, "parallel_tet_candidates must be boolean")
        candidate = deepcopy(self._document)
        candidate["mesh_settings"]["parallel_tet_candidates"] = enabled
        return self._commit_structural_edit(
            pointer=pointer,
            previous=self._compiled.parsed_source.document.mesh_settings.parallel_tet_candidates,
            current=enabled, candidate_document=candidate,
        )

    def change_interface_geometry_tolerance(
        self,
        source_literal: str,
    ) -> SourceEditResult:
        """Set the Package-global absolute interface predicate tolerance."""

        pointer = "/mesh_settings/interface_geometry_tolerance"
        if self.read_only:
            raise PackageV2SourceEditError(pointer, "the Source is read-only")
        if not isinstance(source_literal, str):
            raise PackageV2SourceEditError(
                pointer,
                "interface geometry tolerance must be text with a length unit",
            )
        current = (
            self._compiled.parsed_source.document.mesh_settings
            .interface_geometry_tolerance_source
        )
        requested = source_literal.strip()
        candidate = deepcopy(self._document)
        raw_settings = candidate.setdefault("mesh_settings", {})
        if not isinstance(raw_settings, dict):
            raise PackageV2SourceEditError(
                pointer,
                "mesh_settings is not an object",
            )
        raw_settings["interface_geometry_tolerance"] = requested
        return self._commit_structural_edit(
            pointer=pointer,
            previous=current,
            current=requested,
            candidate_document=candidate,
        )

    def _template_edit_context(self, template_id: str):
        if self.read_only or template_id != "Global":
            raise PackageV2SourceEditError("/globals", "工程变量只属于 Global；局部变量请通过模板编辑器修改")
        candidate = deepcopy(self._document)
        return candidate, candidate["globals"], "/globals"

    def add_variable(self, template_id: str, role: str, record: Mapping[str, object]) -> SourceEditResult:
        candidate, template, pointer = self._template_edit_context(template_id)
        if role not in ("parameter", "derived") or not isinstance(record, Mapping):
            raise PackageV2SourceEditError(pointer, "无效的变量定义。")
        collection = "parameters" if role == "parameter" else "derived"
        pointer += f"/{collection}/{len(template[collection])}"
        template[collection].append(deepcopy(dict(record)))
        return self._commit_structural_edit(pointer=pointer, previous="—", current=str(record.get("name", "")),
                                            candidate_document=candidate)

    def delete_variable(self, template_id: str, name: str) -> SourceEditResult:
        candidate, template, pointer = self._template_edit_context(template_id)
        from .package_v2_local_tables import global_references
        references = global_references(candidate)
        if name not in references:
            raise PackageV2SourceEditError(pointer, f"找不到变量 {name!r}。")
        if references[name]:
            raise PackageV2SourceEditError(pointer, f"变量 {name!r} 仍被引用：{', '.join(references[name])}。请先修改引用。")
        for collection in ("parameters", "derived"):
            for index, record in enumerate(template[collection]):
                if record["name"] == name:
                    template[collection].pop(index)
                    pointer += f"/{collection}/{index}"
                    break
        return self._commit_structural_edit(pointer=pointer, previous=name, current="—", candidate_document=candidate)

    def rename_variable(self, template_id: str, name: str, new_name: str) -> SourceEditResult:
        """Rename one Global and its references in a single validated transaction."""
        from .package_v2_geometry_library import rewrite_scope_references
        from .package_v2_source import _variable_identifier

        candidate, variables, pointer = self._template_edit_context(template_id)
        records = [(collection, index, record)
                   for collection in ("parameters", "derived")
                   for index, record in enumerate(variables[collection])]
        found = next((value for value in records if value[2]["name"] == name), None)
        if found is None:
            raise PackageV2SourceEditError(pointer, f"找不到变量 {name!r}。")
        collection, index, record = found
        pointer += f"/{collection}/{index}/name"
        try:
            new_name = _variable_identifier(new_name, pointer, field_name="变量名称")
        except ValueError as error:
            raise PackageV2SourceEditError(pointer, str(error)) from error
        if any(value["name"] == new_name and value is not record for _, _, value in records):
            raise PackageV2SourceEditError(pointer, f"变量名称 {new_name!r} 已存在。")
        record["name"] = new_name
        rewrite_scope_references({"derived": variables["derived"], "instances": candidate["instances"]},
                                 {name: new_name})
        return self._commit_structural_edit(pointer=pointer, previous=name, current=new_name,
                                            candidate_document=candidate)


    def upsert_local_template(self, template, *, original_id=None, renames=None) -> SourceEditResult:
        if self.read_only:
            raise PackageV2SourceEditError("/templates", "请先转换为 Template / Instance Source")
        candidate = deepcopy(self._document)
        if original_id is not None and not any(value["id"] == original_id for value in candidate["templates"]):
            raise PackageV2SourceEditError("/templates", f"找不到 Template {original_id!r}")
        name = template.get("id")
        if original_id is None and any(value["id"] == name for value in candidate["templates"]):
            raise PackageV2SourceEditError("/templates", "模板名称已存在")
        index = next((i for i, value in enumerate(candidate["templates"]) if value["id"] == original_id), len(candidate["templates"]))
        if index == len(candidate["templates"]):
            candidate["templates"].append(deepcopy(template))
        else:
            candidate["templates"][index] = deepcopy(template)
        if original_id is not None:
            for instance in candidate["instances"] + [child for value in candidate["templates"] for child in value["instances"]]:
                if instance["template"] != original_id:
                    continue
                instance["template"] = name
                old = {(renames or {}).get(key, key): value for key, value in instance["bindings"].items()}
                instance["bindings"] = {parameter["name"]: old.get(parameter["name"], parameter["default"])
                                        for parameter in template["parameters"]}
        return self._commit_structural_edit(pointer=f"/templates/{index}", previous=original_id or "—", current=name,
                                            candidate_document=candidate)

    @staticmethod
    def _share_component_edit(document, pointer):
        """Mirror the one component-owned material/mesh value to its members."""
        from .package_v2_local_templates import component_id
        parts = pointer.split("/")
        if len(parts) < 4 or parts[1] != "instances" or parts[3] not in {"material", "mesh_control"}:
            return
        source = document["instances"][int(parts[2])]
        for member in document["instances"]:
            if component_id(member) == component_id(source):
                member[parts[3]] = deepcopy(source[parts[3]])

    def upsert_bound_instance(self, instance, *, original_id=None, duplicate_from=None) -> SourceEditResult:
        """Apply geometry edits while keeping mesh settings owned by the Mesh page."""
        if self.read_only:
            raise PackageV2SourceEditError("/instances", "请先转换为 Template / Instance Source")
        candidate = deepcopy(self._document)
        if original_id is not None and not any(value["id"] == original_id for value in candidate["instances"]):
            raise PackageV2SourceEditError("/instances", f"找不到 Instance {original_id!r}")
        if original_id is None and any(value["id"] == instance.get("id") for value in candidate["instances"]):
            raise PackageV2SourceEditError("/instances", "Instance 名称已存在")
        mesh_source = None
        if duplicate_from is not None:
            if original_id is not None:
                raise PackageV2SourceEditError("/instances", "复制 Instance 时不能同时编辑已有 Instance")
            mesh_source = next((value for value in candidate["instances"] if value["id"] == duplicate_from), None)
            if mesh_source is None:
                raise PackageV2SourceEditError("/instances", f"找不到 Instance {duplicate_from!r}")
        index = next((i for i, value in enumerate(candidate["instances"]) if value["id"] == original_id), len(candidate["instances"]))
        value = deepcopy(instance)
        from .package_v2_local_templates import component_id, template_registry
        if "component_id" not in value and original_id is not None:
            value["component_id"] = component_id(candidate["instances"][index])
        owner = component_id(value)
        old_owner = component_id(candidate["instances"][index]) if original_id is not None else None
        owner_source = next((item for i, item in enumerate(candidate["instances"])
                             if i != index and component_id(item) == owner), None)
        if owner_source is not None:
            value["mesh_control"] = deepcopy(owner_source["mesh_control"])
            value["material"] = owner_source["material"]
        if "mesh_control" not in value:
            if original_id is not None and owner == old_owner:
                value["mesh_control"] = deepcopy(candidate["instances"][index]["mesh_control"])
            else:
                control = deepcopy(mesh_source["mesh_control"]) if mesh_source else {
                    "target_edge": "0.1mm", "transition_distance": "0.2mm",
                    "strategy": {"kind": "orthogonal_hex"},
                }
                if mesh_source is None:
                    registry = template_registry(candidate)
                    def needs_hybrid(name):
                        template = registry[name]
                        return (any(shape["kind"] == "bounds_fillet" for shape in template["solids"])
                                or any(needs_hybrid(child["template"]) for child in template["instances"]))
                    if value.get("template") in registry and needs_hybrid(value["template"]):
                        control["strategy"] = {"kind": "conformal_hybrid"}
                used = {item["mesh_control"]["mesh_priority"] for item in candidate["instances"]}
                priority = 1
                while priority in used:
                    priority += 1
                control["mesh_priority"] = priority
                value["mesh_control"] = control
        if index == len(candidate["instances"]):
            candidate["instances"].append(value)
        else:
            candidate["instances"][index] = value
        return self._commit_structural_edit(pointer=f"/instances/{index}", previous=original_id or "—",
            current=instance.get("id", ""), candidate_document=candidate)

    def delete_bound_instance(self, identifier) -> SourceEditResult:
        if self.read_only:
            raise PackageV2SourceEditError("/instances", "Instance 不可编辑")
        candidate = deepcopy(self._document)
        index = next((i for i, value in enumerate(candidate["instances"]) if value["id"] == identifier), None)
        if index is None:
            raise PackageV2SourceEditError("/instances", f"找不到 Instance {identifier!r}")
        candidate["instances"].pop(index)
        return self._commit_structural_edit(pointer=f"/instances/{index}", previous=identifier, current="—", candidate_document=candidate)

    def delete_bound_component(self, identifier) -> SourceEditResult:
        from .package_v2_local_templates import component_id
        if self.read_only:
            raise PackageV2SourceEditError("/instances", "Component 不可编辑")
        candidate = deepcopy(self._document)
        remaining = [value for value in candidate["instances"] if component_id(value) != identifier]
        if len(remaining) == len(candidate["instances"]):
            raise PackageV2SourceEditError("/instances", f"找不到 Component {identifier!r}")
        candidate["instances"] = remaining
        return self._commit_structural_edit(pointer="/instances", previous=identifier, current="—", candidate_document=candidate)

    def import_local_template(self, library) -> SourceEditResult:
        from .package_v2_local_templates import import_library
        if self.read_only:
            raise PackageV2SourceEditError("/templates", "Template 不可编辑")
        try:
            candidate = import_library(self._document, library)
        except (ValueError, KeyError, TypeError) as error:
            raise PackageV2SourceEditError("/templates", str(error)) from error
        return self._commit_structural_edit(pointer="/templates", previous="—", current=library["root"], candidate_document=candidate)

    def transform_frozen_source(self, source_id: str, *, name: str | None = None,
                                translation, rotations, mirrors, pivot) -> SourceEditResult:
        if self.read_only:
            raise PackageV2SourceEditError("/frozen_sources", "the Source is read-only")
        candidate = deepcopy(self._document)
        try:
            index = next(i for i, source in enumerate(candidate["frozen_sources"]) if source["id"] == source_id)
            source = deepcopy(candidate["frozen_sources"][index])
            compiled = next(source for source in self._compiled.frozen_sources if source.source_id == source_id)
            offset, matrix, pivot_mm = transform_values(translation, rotations, mirrors, pivot)
            rotation, position = compose_placement(matrix, compiled.placement.rotation_matrix,
                                                   compiled.placement.translation_xyz_mm, offset, pivot_mm)
            source["placement"] = {"translation": [f"{value:.17g}mm" for value in position],
                                   "rotation_matrix": [list(row) for row in rotation]}
            if name is None:
                candidate["frozen_sources"][index] = source
            else:
                source["id"] = name
                index = len(candidate["frozen_sources"])
                candidate["frozen_sources"].append(source)
        except (ValueError, KeyError, TypeError, StopIteration) as error:
            raise PackageV2SourceEditError("/frozen_sources", str(error)) from error
        return self._commit_structural_edit(pointer=f"/frozen_sources/{index}", previous=source_id,
                                            current=source["id"], candidate_document=candidate)

    def add_frozen_source(self, source: Mapping[str, object]) -> SourceEditResult:
        """Append a Frozen declaration after compiling the complete candidate."""
        pointer = "/frozen_sources"
        if self.read_only or not isinstance(source, Mapping):
            raise PackageV2SourceEditError(pointer, "Frozen Source is not editable or is invalid")
        candidate = deepcopy(self._document)
        sources = candidate["frozen_sources"]
        pointer = f"{pointer}/{len(sources)}"
        sources.append(deepcopy(dict(source)))
        return self._commit_structural_edit(
            pointer=pointer, previous="—", current=str(source.get("id", "")),
            candidate_document=candidate,
        )

    def update_frozen_source(self, source_id: str, source: Mapping[str, object]) -> SourceEditResult:
        """Replace absolute instance settings in one validated transaction."""
        pointer = "/frozen_sources"
        if self.read_only or not isinstance(source, Mapping):
            raise PackageV2SourceEditError(pointer, "网格实例不可编辑")
        candidate = deepcopy(self._document)
        for index, previous in enumerate(candidate["frozen_sources"]):
            if previous["id"] == source_id:
                candidate["frozen_sources"][index] = deepcopy(dict(source))
                return self._commit_structural_edit(
                    pointer=f"{pointer}/{index}", previous=source_id,
                    current=str(source.get("id", "")), candidate_document=candidate,
                )
        raise PackageV2SourceEditError(pointer, f"找不到网格实例 {source_id!r}")

    def delete_frozen_source(self, source_id: str) -> SourceEditResult:
        """Remove a declaration only; the immutable artifact files stay intact."""
        pointer = "/frozen_sources"
        if self.read_only:
            raise PackageV2SourceEditError(pointer, "the Source is read-only")
        candidate = deepcopy(self._document)
        sources = candidate["frozen_sources"]
        for index, source in enumerate(sources):
            if source["id"] == source_id:
                sources.pop(index)
                return self._commit_structural_edit(
                    pointer=f"{pointer}/{index}", previous=source_id, current="—",
                    candidate_document=candidate,
                )
        raise PackageV2SourceEditError(pointer, f"unknown Frozen Source {source_id!r}")


    def change_mesh_options(self, mesh_pointer: str, *, strategy: Mapping[str, object],
                            target_edge: str, transition_distance: str) -> SourceEditResult:
        """Commit all advanced choices in one validated transaction."""
        row = next((v for v in self._tables.meshes if v.pointer == mesh_pointer), None)
        if row is None or self.read_only:
            raise PackageV2SourceEditError(mesh_pointer, "mesh_control is not editable")
        binding = self._bindings[row.target_edge.pointer]
        candidate = deepcopy(self._document)
        control = _document_value(candidate, binding.tokens[:-1])
        previous = json.dumps(control, sort_keys=True, ensure_ascii=False)
        control.update(strategy=deepcopy(dict(strategy)), target_edge=target_edge,
                       transition_distance=transition_distance)
        current = json.dumps(control, sort_keys=True, ensure_ascii=False)
        if previous == current:
            return SourceEditResult(mesh_pointer, previous, current, self.raw_sha256,
                                    self._compiled.plan_digest, False)
        return self._commit_structural_edit(pointer=mesh_pointer, previous=previous,
            current=current, candidate_document=candidate)

    def change_mesh_strategy(
        self,
        mesh_pointer: str,
        new_kind: str,
        *,
        sweep_direction: str | None = None,
    ) -> SourceEditResult:
        """Atomically replace one Component's strict mesh-strategy variant.

        Switching variants intentionally discards fields owned by the previous
        variant.  Sweep requires its Component-local signed direction in this
        same transaction; no incomplete ``structured_sweep`` object is ever
        installed.  An Orth strategy starts without explicit directional
        overrides, so compilation resolves all six directions to
        ``target_edge``.
        """

        row = next(
            (value for value in self._tables.meshes if value.pointer == mesh_pointer),
            None,
        )
        if row is None or self.read_only:
            raise PackageV2SourceEditError(
                str(mesh_pointer),
                "the pointer is not an editable Component mesh_control",
            )
        if new_kind not in AUTHORING_MESH_STRATEGY_TOKENS:
            raise PackageV2SourceEditError(
                mesh_pointer,
                "mesh strategy must be structured_sweep, orthogonal_hex, "
                "or conformal_hybrid",
            )
        canonical_sweep_direction: str | None = None
        if new_kind == "structured_sweep":
            try:
                canonical_sweep_direction = ComponentLocalDirection(
                    sweep_direction
                ).value
            except (TypeError, ValueError) as error:
                raise PackageV2SourceEditError(
                    mesh_pointer,
                    "structured_sweep requires an explicit Component-local "
                    "direction: positive_x, negative_x, positive_y, "
                    "negative_y, positive_z, or negative_z",
                ) from error
        previous = row.strategy_kind
        if previous == new_kind:
            if (
                new_kind == "structured_sweep"
                and canonical_sweep_direction != row.sweep_direction
            ):
                return self.change_structured_sweep_direction(
                    mesh_pointer,
                    canonical_sweep_direction,
                )
            return SourceEditResult(
                mesh_pointer,
                previous,
                previous,
                self.raw_sha256,
                self._compiled.plan_digest,
                False,
            )

        target_binding = self._bindings.get(row.target_edge.pointer)
        if target_binding is None:
            raise PackageV2SourceEditError(
                mesh_pointer,
                "mesh_control target_edge is not editable",
            )
        candidate = deepcopy(self._document)
        control = _document_value(candidate, target_binding.tokens[:-1])
        assert isinstance(control, dict)
        control["strategy"] = {"kind": new_kind}
        if canonical_sweep_direction is not None:
            control["strategy"]["direction"] = canonical_sweep_direction  # type: ignore[index]
        return self._commit_structural_edit(
            pointer=mesh_pointer,
            previous=previous,
            current=new_kind,
            candidate_document=candidate,
        )

    def change_structured_sweep_direction(
        self,
        mesh_pointer: str,
        direction: str,
    ) -> SourceEditResult:
        """Replace the authoritative direction of one Sweep Component."""

        row = next(
            (value for value in self._tables.meshes if value.pointer == mesh_pointer),
            None,
        )
        if row is None or self.read_only:
            raise PackageV2SourceEditError(
                str(mesh_pointer),
                "the pointer is not an editable Component mesh_control",
            )
        if row.strategy_kind != "structured_sweep":
            raise PackageV2SourceEditError(
                mesh_pointer,
                "direction is available only for structured_sweep",
            )
        try:
            canonical = ComponentLocalDirection(direction).value
        except (TypeError, ValueError) as error:
            raise PackageV2SourceEditError(
                mesh_pointer,
                "structured_sweep direction must be positive_x, negative_x, "
                "positive_y, negative_y, positive_z, or negative_z",
            ) from error
        if row.sweep_direction == canonical:
            return SourceEditResult(
                mesh_pointer,
                canonical,
                canonical,
                self.raw_sha256,
                self._compiled.plan_digest,
                False,
            )
        target_binding = self._bindings.get(row.target_edge.pointer)
        if target_binding is None:
            raise PackageV2SourceEditError(
                mesh_pointer,
                "mesh_control target_edge is not editable",
            )
        candidate = deepcopy(self._document)
        control = _document_value(candidate, target_binding.tokens[:-1])
        assert isinstance(control, dict)
        strategy = control["strategy"]
        assert isinstance(strategy, dict)
        previous = strategy.get("direction")
        strategy["direction"] = canonical
        return self._commit_structural_edit(
            pointer=f"{mesh_pointer}/strategy/direction",
            previous=str(previous),
            current=canonical,
            candidate_document=candidate,
        )

    def change_orthogonal_directional_near_edge(
        self,
        mesh_pointer: str,
        direction: str,
        source: str | None,
    ) -> SourceEditResult:
        """Add, replace, or remove one Orth component-local size override."""

        row = next(
            (value for value in self._tables.meshes if value.pointer == mesh_pointer),
            None,
        )
        if row is None or self.read_only:
            raise PackageV2SourceEditError(
                str(mesh_pointer),
                "the pointer is not an editable Component mesh_control",
            )
        try:
            canonical_direction = ComponentLocalDirection(direction).value
        except (TypeError, ValueError) as exc:
            raise PackageV2SourceEditError(
                mesh_pointer,
                "direction must be positive_x, negative_x, positive_y, "
                "negative_y, positive_z, or negative_z",
            ) from exc
        if row.strategy_kind != "orthogonal_hex":
            raise PackageV2SourceEditError(
                mesh_pointer,
                "directional near-edge sizes are available only for "
                "orthogonal_hex",
            )
        if source is not None and (
            not isinstance(source, str) or not source.strip()
        ):
            raise PackageV2SourceEditError(
                mesh_pointer,
                "directional near-edge size must be a non-empty expression or null",
            )

        target_binding = self._bindings.get(row.target_edge.pointer)
        if target_binding is None:
            raise PackageV2SourceEditError(
                mesh_pointer,
                "mesh_control target_edge is not editable",
            )
        candidate = deepcopy(self._document)
        control = _document_value(candidate, target_binding.tokens[:-1])
        assert isinstance(control, dict)
        strategy = control["strategy"]
        assert isinstance(strategy, dict)
        raw_directional = strategy.get("directional_near_edge")
        previous = "target_edge"
        if isinstance(raw_directional, dict):
            previous_value = raw_directional.get(canonical_direction)
            if isinstance(previous_value, str):
                previous = previous_value

        current = "target_edge" if source is None else source
        if previous == current:
            return SourceEditResult(
                mesh_pointer,
                previous,
                previous,
                self.raw_sha256,
                self._compiled.plan_digest,
                False,
            )
        directions = [canonical_direction]
        if source is None:
            assert isinstance(raw_directional, dict)
            for value in directions:
                raw_directional.pop(value, None)
            if not raw_directional:
                strategy.pop("directional_near_edge", None)
        else:
            if raw_directional is None:
                raw_directional = {}
                strategy["directional_near_edge"] = raw_directional
            assert isinstance(raw_directional, dict)
            for value in directions:
                raw_directional[value] = source
        return self._commit_structural_edit(
            pointer=mesh_pointer,
            previous=previous,
            current=current,
            candidate_document=candidate,
        )

    def change_orthogonal_partition_origin(
        self,
        mesh_pointer: str,
        origin: Sequence[str] | None,
    ) -> SourceEditResult:
        """Set or clear the optional single-fragment Orth partition origin."""

        row = next(
            (value for value in self._tables.meshes if value.pointer == mesh_pointer),
            None,
        )
        if row is None or self.read_only:
            raise PackageV2SourceEditError(
                str(mesh_pointer),
                "the pointer is not an editable Component mesh_control",
            )
        if row.strategy_kind != "orthogonal_hex":
            raise PackageV2SourceEditError(
                mesh_pointer,
                "partition_origin is available only for orthogonal_hex",
            )
        if origin is not None:
            if isinstance(origin, (str, bytes)):
                raise PackageV2SourceEditError(
                    mesh_pointer,
                    "partition_origin must contain exactly three non-empty expressions",
                )
            try:
                origin_values = tuple(origin)
            except TypeError as error:
                raise PackageV2SourceEditError(
                    mesh_pointer,
                    "partition_origin must contain exactly three non-empty expressions",
                ) from error
            if len(origin_values) != 3 or any(
                not isinstance(value, str) or not value.strip()
                for value in origin_values
            ):
                raise PackageV2SourceEditError(
                    mesh_pointer,
                    "partition_origin must contain exactly three non-empty expressions",
                )
        else:
            origin_values = ()

        target_binding = self._bindings.get(row.target_edge.pointer)
        if target_binding is None:
            raise PackageV2SourceEditError(
                mesh_pointer,
                "mesh_control target_edge is not editable",
            )
        candidate = deepcopy(self._document)
        control = _document_value(candidate, target_binding.tokens[:-1])
        assert isinstance(control, dict)
        strategy = control["strategy"]
        assert isinstance(strategy, dict)
        raw_previous = strategy.get("partition_origin")
        previous = (
            json.dumps(raw_previous, ensure_ascii=False)
            if isinstance(raw_previous, list)
            else "none"
        )
        current = (
            json.dumps(list(origin_values), ensure_ascii=False)
            if origin is not None
            else "none"
        )
        if previous == current:
            return SourceEditResult(
                mesh_pointer,
                previous,
                previous,
                self.raw_sha256,
                self._compiled.plan_digest,
                False,
            )
        if origin is None:
            strategy.pop("partition_origin", None)
        else:
            strategy["partition_origin"] = list(origin_values)
        return self._commit_structural_edit(
            pointer=mesh_pointer,
            previous=previous,
            current=current,
            candidate_document=candidate,
        )

    def edit_many(self, edits: Mapping[str, str]) -> SourceEditResult:
        """Atomically compile and install several scalar Source edits.

        The first mapping entry is the primary edit represented by the
        :class:`SourceEditResult` fields.  Every supplied value is nevertheless
        decoded and applied to one candidate document before compilation.  If
        that candidate violates only a structured cross-field geometry
        constraint, :class:`PackageV2SourcePendingError` exposes its exact JSON
        text while this editor retains its last fully legal state.
        """

        if not isinstance(edits, Mapping):
            raise PackageV2SourceEditError("<batch>", "edits must be a mapping")
        items = tuple(edits.items())
        if not items:
            raise PackageV2SourceEditError(
                "<batch>",
                "edit mapping must contain at least one field",
            )

        prepared: list[tuple[str, _CellBinding, object]] = []
        for raw_pointer, text in items:
            if not isinstance(raw_pointer, str) or not raw_pointer.startswith("/"):
                raise PackageV2SourceEditError(
                    str(raw_pointer),
                    "invalid JSON Pointer",
                )
            pointer = raw_pointer
            binding = self._bindings.get(pointer)
            if binding is None:
                raise PackageV2SourceEditError(
                    pointer,
                    "the field is absent, structural, or read-only",
                )
            if binding.kind is SourceCellKind.VARIABLE_NAME:
                if len(items) != 1:
                    raise PackageV2SourceEditError(pointer, "请先完成其他修改，再重命名变量。")
                return self.rename_variable("Global", binding.cell.display, text)
            if binding.kind is SourceCellKind.UNIT:
                if len(items) != 1:
                    raise PackageV2SourceEditError(
                        pointer,
                        "parameter unit changes cannot be combined with other edits",
                    )
                changed = self.change_parameter_unit(pointer, text)
                return SourceEditResult(
                    pointer,
                    changed.previous_unit,
                    changed.current_unit,
                    changed.raw_sha256,
                    changed.plan_sha256,
                    changed.changed,
                )
            try:
                value = _decode_edit(
                    text,
                    binding.kind,
                    length_unit=binding.length_unit,
                )
            except (TypeError, ValueError) as error:
                raise PackageV2SourceEditError(pointer, str(error)) from error
            prepared.append((pointer, binding, value))

        primary_pointer, primary_binding, _primary_value = prepared[0]
        previous = primary_binding.cell.display
        candidate_document = deepcopy(self._document)
        changed = False
        for _pointer, binding, value in prepared:
            current_value = _document_value(self._document, binding.tokens)
            if type(current_value) is type(value) and current_value == value:
                continue
            _set_document_value(candidate_document, binding.tokens, value)
            self._share_component_edit(candidate_document, _pointer)
            changed = True
        if not changed:
            return SourceEditResult(
                primary_pointer,
                previous,
                previous,
                self.raw_sha256,
                self._compiled.plan_digest,
                False,
            )

        encoded_saved = _encode_document(self._saved_document)

        def compile_candidate(document: dict[str, object]):
            encoded = _encode_document(document)
            source_bytes = self._saved_bytes if encoded == encoded_saved else encoded
            compiled = compile_package_v2(
                source_bytes,
                source_name=self._path.name,
                source_root=self._path.parent,
            )
            return source_bytes, compiled, _build_tables(document, compiled)

        candidate_bytes = _encode_document(candidate_document)
        if candidate_bytes == encoded_saved:
            candidate_bytes = self._saved_bytes
        try:
            (
                candidate_bytes,
                candidate_compiled,
                candidate_built,
            ) = compile_candidate(
                candidate_document,
            )
        except Exception as error:
            constraint = _transient_geometry_constraint(error)
            if constraint is not None:
                frozen_pointer = next(
                    (
                        pointer
                        for pointer, _binding, _value in prepared
                        if pointer.startswith("/frozen_sources/")
                    ),
                    None,
                )
                if frozen_pointer is not None:
                    raise PackageV2SourceEditError(
                        frozen_pointer,
                        "finish the pending Template geometry dimensions before "
                        "editing Frozen placement values",
                    ) from error
                try:
                    _audit_candidate_hard_template_constraints(
                        candidate_bytes,
                        source_name=self._path.name,
                    )
                except Exception as hard_error:
                    # The combined-candidate audit is authoritative. Isolated
                    # audits run only after it proves a hard error, solely to
                    # report a more useful pointer when one edit is sufficient
                    # to reproduce that failure.
                    hard_pointer = primary_pointer
                    for pointer, binding, value in prepared:
                        isolated_document = deepcopy(self._document)
                        _set_document_value(isolated_document, binding.tokens, value)
                        isolated_bytes = _encode_document(isolated_document)
                        try:
                            _audit_candidate_hard_template_constraints(
                                isolated_bytes,
                                source_name=self._path.name,
                            )
                        except Exception:
                            hard_pointer = pointer
                            break
                    raise PackageV2SourceEditError(
                        hard_pointer,
                        str(hard_error),
                    ) from hard_error
                raise PackageV2SourcePendingError(
                    primary_pointer,
                    str(error),
                    candidate_text=candidate_bytes.decode("utf-8"),
                    pointers=tuple(pointer for pointer, _binding, _value in prepared),
                    constraint_code=constraint.code,
                    constraint_paths=constraint.field_paths,
                ) from error
            raise PackageV2SourceEditError(primary_pointer, str(error)) from error

        self._document = candidate_document
        self._draft_bytes = candidate_bytes
        self._compiled = candidate_compiled
        self._tables = candidate_built.tables
        self._bindings = dict(candidate_built.bindings)
        current = self._bindings[primary_pointer].cell.display
        return SourceEditResult(
            primary_pointer,
            previous,
            current,
            self.raw_sha256,
            self._compiled.plan_digest,
            True,
        )

    def edit(self, pointer: str, text: str) -> SourceEditResult:
        """Atomically apply one scalar edit via :meth:`edit_many`."""

        return self.edit_many({pointer: text})

    def change_parameter_unit(
        self,
        unit_pointer: str,
        new_unit: str,
    ) -> SourceUnitChangeResult:
        """Atomically switch one length parameter's declared unit.

        ``unit_pointer`` is the stable pointer exposed as ``VariableRow.unit``.
        The public GUI choices are ``um`` and ``mm``; Unicode ``µm``/``μm``
        inputs are accepted and canonicalised to ``um``. Simple physical
        literals in the Global parameter default/range
        are converted to the requested unit.  Compound expressions are left
        byte-for-byte equal as JSON string values.
        """

        if not isinstance(unit_pointer, str) or not unit_pointer.startswith("/"):
            raise PackageV2SourceEditError(
                str(unit_pointer),
                "invalid parameter unit JSON Pointer",
            )
        binding = self._bindings.get(unit_pointer)
        if (
            binding is None
            or binding.kind is not SourceCellKind.UNIT
            or binding.parameter_key is None
        ):
            raise PackageV2SourceEditError(
                unit_pointer,
                "the pointer is not an editable length parameter unit",
            )
        try:
            target_unit = _canonical_length_unit(new_unit)
        except (TypeError, ValueError) as error:
            raise PackageV2SourceEditError(unit_pointer, str(error)) from error

        previous_unit = binding.cell.display
        candidate_document = deepcopy(self._document)
        parameter = _document_value(candidate_document, binding.tokens[:-1])
        assert isinstance(parameter, dict)
        converted_pointers: list[str] = []

        if parameter["unit"] != target_unit:
            parameter["unit"] = target_unit

        def convert_literal(
            container: dict[str, object],
            field_name: str,
            tokens: tuple[JsonToken, ...],
        ) -> None:
            value = container.get(field_name)
            if not isinstance(value, str):
                return
            converted = _convert_simple_length_literal(value, target_unit)
            if converted == value:
                return
            container[field_name] = converted
            converted_pointers.append(_pointer(tokens))

        parameter_tokens = binding.tokens[:-1]
        convert_literal(
            parameter,
            "default",
            (*parameter_tokens, "default"),
        )
        raw_range = parameter.get("range")
        if isinstance(raw_range, dict):
            for bound in ("min", "max"):
                convert_literal(
                    raw_range,
                    bound,
                    (*parameter_tokens, "range", bound),
                )

        if candidate_document == self._document:
            return SourceUnitChangeResult(
                unit_pointer,
                previous_unit,
                previous_unit,
                (),
                self.raw_sha256,
                self._compiled.plan_digest,
                False,
            )

        try:
            encoded_candidate = _encode_document(candidate_document)
            candidate_bytes = (
                self._saved_bytes
                if encoded_candidate == _encode_document(self._saved_document)
                else encoded_candidate
            )
            candidate_compiled = compile_package_v2(
                candidate_bytes,
                source_name=self._path.name,
                source_root=self._path.parent,
            )
            candidate_built = _build_tables(
                candidate_document,
                candidate_compiled,
            )
        except Exception as error:
            raise PackageV2SourceEditError(unit_pointer, str(error)) from error

        self._document = candidate_document
        self._draft_bytes = candidate_bytes
        self._compiled = candidate_compiled
        self._tables = candidate_built.tables
        self._bindings = dict(candidate_built.bindings)
        current_unit = self._bindings[unit_pointer].cell.display
        return SourceUnitChangeResult(
            unit_pointer,
            previous_unit,
            current_unit,
            tuple(converted_pointers),
            self.raw_sha256,
            self._compiled.plan_digest,
            True,
        )

    def save(self) -> SourceFileSignature:
        if not self.dirty:
            return self._saved_signature
        temporary = _prepare_source_temporary(self._path, self._draft_bytes)
        try:
            try:
                _publish_source_draft(
                    self._path,
                    temporary,
                    saved_bytes=self._saved_bytes,
                    saved_signature=self._saved_signature,
                )
            except PackageV2SourceConflictError:
                raise
            except PackageV2SourceEditorError:
                raise
            except FileNotFoundError as error:
                raise PackageV2SourceConflictError(
                    "Package V2 Source can no longer be read at its saved path; "
                    "refusing to publish the draft"
                ) from error
        finally:
            temporary.unlink(missing_ok=True)
        published_bytes, published_signature = _read_regular_source(self._path)
        if published_bytes != self._draft_bytes:
            raise PackageV2SourceConflictError(
                "published Package V2 Source bytes changed unexpectedly"
            )
        self._saved_bytes = published_bytes
        self._saved_signature = published_signature
        self._saved_document = deepcopy(self._document)
        return published_signature


def open_package_v2_source_editor(
    path: str | os.PathLike[str],
) -> PackageV2SourceEditor:
    """Open and fully validate one real Package V2 ``*.source.json`` file."""

    return PackageV2SourceEditor.open(path)


def build_package_v2_source_tables(
    compiled: PackageV2CompileResult,
) -> SourceTableSet:
    """Build read-only-capable relationship rows from a compiled snapshot.

    The returned cells retain their JSON Pointers, but the caller decides
    whether editing is enabled.  This is used by the GUI to render an
    immutable Job/Project source snapshot without creating a file editor.
    """

    document = _ordered_document(compiled)
    return _build_tables(document, compiled).tables


__all__ = [
    "FrozenRow",
    "GeometryFragmentRow",
    "GeometryRow",
    "MeshRow",
    "MeshSettingsRow",
    "PackageV2SourceConflictError",
    "PackageV2SourceEditError",
    "PackageV2SourcePendingError",
    "PackageV2SourceEditor",
    "PackageV2SourceEditorError",
    "ResolvedMeshControl",
    "ResolvedValue",
    "SourceCell",
    "SourceCellKind",
    "SourceEditResult",
    "SourceFileSignature",
    "SourceTableSet",
    "SourceUnitChangeResult",
    "VariableRow",
    "build_package_v2_source_tables",
    "open_package_v2_source_editor",
]
