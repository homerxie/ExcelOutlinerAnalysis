"""Compile parameterized Package V2 geometry into a numeric canonical IR.

The source records in this module are deliberately small and declarative.  A
source scalar is always a string expression and every such expression is
resolved through :class:`~easymesh.package_assembly.ResolvedTemplateParameters`.
The resulting canonical records contain finite millimetre/degree values only;
they have no expression, unit, AST, or callable escape hatch.

This module does not create OCC entities or import frozen mesh assets.  It is
the pure compilation boundary immediately before a generated-geometry backend.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import keyword
import math
from typing import Mapping, Sequence, TypeAlias

from .package_assembly import (
    AssemblyPolicyError,
    GeometryRecord,
    ResolvedTemplateParameters,
    TemplateDimension,
    compile_geometry_records,
)


_CANONICAL_SCHEMA = "easymesh-package-v2-canonical-geometry-v2"
_CANONICAL_FRAGMENT_SCHEMA = "easymesh-package-v2-canonical-fragment-v1"
_MAX_CSG_DEPTH = 8
_MAX_CSG_NODES = 64
_RESERVED_IDENTIFIERS = frozenset(
    {"mm", "um", "\N{MICRO SIGN}m", "\N{GREEK SMALL LETTER MU}m", "__easymesh_length__"}
)


class GeometryCompilationError(AssemblyPolicyError):
    """Raised when source geometry cannot become an unambiguous numeric IR."""


class GeometryTransientConstraintError(GeometryCompilationError):
    """A cross-field geometry constraint that an author may fix in one batch.

    Canonical geometry remains strict: this exception is still a compilation
    failure.  The structured ``code`` and ``field_paths`` merely let an
    authoring adapter retain the candidate text while the user coordinates
    several related scalar edits.  Production compilation and workers must
    continue to treat it as an ordinary :class:`GeometryCompilationError`.
    """

    def __init__(
        self,
        code: str,
        message: str,
        *,
        field_paths: Sequence[str],
    ) -> None:
        if not isinstance(code, str) or not code:
            raise TypeError("transient geometry constraint code must be non-empty")
        paths = tuple(field_paths)
        if not paths or any(not isinstance(path, str) or not path for path in paths):
            raise TypeError(
                "transient geometry constraint field paths must be non-empty strings"
            )
        self.code = code
        self.field_paths = paths
        super().__init__(message)


def _label(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise GeometryCompilationError(f"{field_name} must be a non-empty string")
    return value.strip()


def _identifier(value: object, *, field_name: str) -> str:
    identifier = _label(value, field_name=field_name)
    if (
        not identifier.isascii()
        or not identifier.isidentifier()
        or keyword.iskeyword(identifier)
        or identifier.lower() in _RESERVED_IDENTIFIERS
    ):
        raise GeometryCompilationError(
            f"{field_name} must be an ASCII identifier"
        )
    return identifier


def _expression(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise GeometryCompilationError(
            f"{field_name} must be a non-empty expression string"
        )
    # Preserve the source exactly for provenance; evaluation handles whitespace.
    return value


def _expression_vector(
    value: object,
    *,
    size: int,
    field_name: str,
) -> tuple[str, ...]:
    if isinstance(value, (str, bytes)):
        raise GeometryCompilationError(
            f"{field_name} must contain exactly {size} expressions"
        )
    try:
        items = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise GeometryCompilationError(
            f"{field_name} must contain exactly {size} expressions"
        ) from error
    if len(items) != size:
        raise GeometryCompilationError(
            f"{field_name} must contain exactly {size} expressions"
        )
    return tuple(
        _expression(item, field_name=f"{field_name}[{index}]")
        for index, item in enumerate(items)
    )


def _finite_float(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise GeometryCompilationError(f"{field_name} must be a finite number")
    try:
        number = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise GeometryCompilationError(f"{field_name} must be a finite number") from error
    if not math.isfinite(number):
        raise GeometryCompilationError(f"{field_name} must be a finite number")
    # A canonical digest must not distinguish positive and negative zero.
    return 0.0 if number == 0.0 else number


def _float_vector(
    value: object,
    *,
    size: int,
    field_name: str,
) -> tuple[float, ...]:
    if isinstance(value, (str, bytes)):
        raise GeometryCompilationError(
            f"{field_name} must contain exactly {size} finite numbers"
        )
    try:
        items = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise GeometryCompilationError(
            f"{field_name} must contain exactly {size} finite numbers"
        ) from error
    if len(items) != size:
        raise GeometryCompilationError(
            f"{field_name} must contain exactly {size} finite numbers"
        )
    return tuple(
        _finite_float(item, field_name=f"{field_name}[{index}]")
        for index, item in enumerate(items)
    )


def _objects(value: object, *, field_name: str) -> tuple[object, ...]:
    if isinstance(value, (str, bytes)):
        raise GeometryCompilationError(f"{field_name} must be a sequence")
    try:
        return tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise GeometryCompilationError(f"{field_name} must be a sequence") from error


def _require_positive(value: float, *, field_name: str) -> None:
    if value <= 0.0:
        raise GeometryCompilationError(f"{field_name} must be greater than zero")


def _validate_box_size(size_xyz_mm: tuple[float, float, float], *, prefix: str) -> None:
    for index, value in enumerate(size_xyz_mm):
        _require_positive(value, field_name=f"{prefix}.size_xyz_mm[{index}]")


def _validate_frame_dimensions(
    outer_size_xy_mm: tuple[float, float],
    opening_offset_xy_mm: tuple[float, float],
    opening_size_xy_mm: tuple[float, float],
    height_mm: float,
    *,
    prefix: str,
) -> None:
    for index, value in enumerate(outer_size_xy_mm):
        _require_positive(value, field_name=f"{prefix}.outer_size_xy_mm[{index}]")
    for index, value in enumerate(opening_size_xy_mm):
        _require_positive(value, field_name=f"{prefix}.opening_size_xy_mm[{index}]")
    _require_positive(height_mm, field_name=f"{prefix}.height_mm")
    for index, (outer, offset, opening) in enumerate(
        zip(outer_size_xy_mm, opening_offset_xy_mm, opening_size_xy_mm)
    ):
        if offset <= 0.0:
            offset_path = f"{prefix}.opening_offset_xy_mm[{index}]"
            raise GeometryTransientConstraintError(
                "frame_opening_near_wall",
                f"{offset_path} must leave a positive wall",
                field_paths=(offset_path,),
            )
        if offset + opening >= outer:
            outer_path = f"{prefix}.outer_size_xy_mm[{index}]"
            offset_path = f"{prefix}.opening_offset_xy_mm[{index}]"
            opening_path = f"{prefix}.opening_size_xy_mm[{index}]"
            raise GeometryTransientConstraintError(
                "frame_opening_far_wall",
                f"{opening_path} must leave a positive far wall",
                field_paths=(outer_path, offset_path, opening_path),
            )


def _validate_rounded_dimensions(
    size_xy_mm: tuple[float, float],
    height_mm: float,
    corner_radius_mm: float,
    *,
    prefix: str,
) -> None:
    for index, value in enumerate(size_xy_mm):
        _require_positive(value, field_name=f"{prefix}.size_xy_mm[{index}]")
    _require_positive(height_mm, field_name=f"{prefix}.height_mm")
    if corner_radius_mm < 0.0:
        raise GeometryCompilationError(
            f"{prefix}.corner_radius_mm must be non-negative"
        )
    if corner_radius_mm >= min(size_xy_mm) / 2.0:
        radius_path = f"{prefix}.corner_radius_mm"
        raise GeometryTransientConstraintError(
            "rounded_corner_radius_vs_size",
            f"{radius_path} must be less than half the shorter side",
            field_paths=(
                f"{prefix}.size_xy_mm[0]",
                f"{prefix}.size_xy_mm[1]",
                radius_path,
            ),
        )


def _validate_rectangular_underfill_fillet_dimensions(
    die_size_xy_mm: tuple[float, float],
    wall_height_mm: float,
    toe_width_mm: float,
    top_width_mm: float = 0.0,
    *,
    prefix: str,
    side_widths_mm=None,
    top_widths_mm=None,
) -> None:
    for index, value in enumerate(die_size_xy_mm):
        _require_positive(value, field_name=f"{prefix}.die_size_xy_mm[{index}]")
    _require_positive(wall_height_mm, field_name=f"{prefix}.wall_height_mm")
    _require_positive(toe_width_mm, field_name=f"{prefix}.toe_width_mm")
    if top_width_mm < 0.0:
        raise GeometryCompilationError(
            f"{prefix}.top_width_mm must be non-negative"
        )
    if side_widths_mm is not None:
        for i, width in enumerate(side_widths_mm):
            _require_positive(width, field_name=f"{prefix}.side_widths_mm[{i}]")
    if top_widths_mm is not None:
        for i, width in enumerate(top_widths_mm):
            if width < 0:
                raise GeometryCompilationError(f"{prefix}.top_widths_mm[{i}] must be non-negative")
    if side_widths_mm is None and top_widths_mm is None and top_width_mm >= toe_width_mm:
        top_path = f"{prefix}.top_width_mm"
        toe_path = f"{prefix}.toe_width_mm"
        raise GeometryTransientConstraintError(
            "underfill_top_width_vs_toe_width",
            f"{top_path} must be less than toe_width_mm",
            field_paths=(toe_path, top_path),
        )


# ---------------------------------------------------------------------------
# Parameterized source DTOs


@dataclass(frozen=True, slots=True)
class RigidPlacementSource:
    """A right-handed Rx-then-Ry-then-Rz rigid placement expression."""

    translation_xyz: tuple[str, str, str] = ("0mm", "0mm", "0mm")
    rotation_deg_xyz: tuple[str, str, str] = ("0", "0", "0")
    pivot_xyz: tuple[str, str, str] = ("0mm", "0mm", "0mm")

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "translation_xyz",
            _expression_vector(
                self.translation_xyz,
                size=3,
                field_name="rigid placement translation_xyz",
            ),
        )
        object.__setattr__(
            self,
            "rotation_deg_xyz",
            _expression_vector(
                self.rotation_deg_xyz,
                size=3,
                field_name="rigid placement rotation_deg_xyz",
            ),
        )
        object.__setattr__(
            self,
            "pivot_xyz",
            _expression_vector(
                self.pivot_xyz,
                size=3,
                field_name="rigid placement pivot_xyz",
            ),
        )


@dataclass(frozen=True, slots=True)
class BoxSource:
    origin_xyz: tuple[str, str, str]
    size_xyz: tuple[str, str, str]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "origin_xyz",
            _expression_vector(self.origin_xyz, size=3, field_name="box origin_xyz"),
        )
        object.__setattr__(
            self,
            "size_xyz",
            _expression_vector(self.size_xyz, size=3, field_name="box size_xyz"),
        )


@dataclass(frozen=True, slots=True)
class RectangularFrameExtrusionSource:
    """A rectangular outer prism with one strictly interior rectangular hole."""

    outer_origin_xyz: tuple[str, str, str]
    outer_size_xy: tuple[str, str]
    opening_offset_xy: tuple[str, str]
    opening_size_xy: tuple[str, str]
    height: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "outer_origin_xyz",
            _expression_vector(
                self.outer_origin_xyz,
                size=3,
                field_name="rectangular frame outer_origin_xyz",
            ),
        )
        for field_name in (
            "outer_size_xy",
            "opening_offset_xy",
            "opening_size_xy",
        ):
            object.__setattr__(
                self,
                field_name,
                _expression_vector(
                    getattr(self, field_name),
                    size=2,
                    field_name=f"rectangular frame {field_name}",
                ),
            )
        object.__setattr__(
            self,
            "height",
            _expression(self.height, field_name="rectangular frame height"),
        )


@dataclass(frozen=True, slots=True)
class RectangularUnderfillFilletSource:
    """Analytic rectangular die-wall fillet with an outward toe."""

    die_origin_xy: tuple[str, str]
    die_size_xy: tuple[str, str]
    base_z: str
    wall_height: str
    toe_width: str
    top_width: str = "0mm"
    side_widths: tuple[str, str, str, str] | None = field(default=None, kw_only=True)
    top_widths: tuple[str, str, str, str] | None = field(default=None, kw_only=True)

    def __post_init__(self) -> None:
        if self.side_widths is not None:
            object.__setattr__(self, "side_widths", _expression_vector(self.side_widths, size=4, field_name="fillet side_widths"))
        if self.top_widths is not None:
            object.__setattr__(self, "top_widths", _expression_vector(self.top_widths, size=4, field_name="fillet top_widths"))
        for field_name in ("die_origin_xy", "die_size_xy"):
            object.__setattr__(
                self,
                field_name,
                _expression_vector(
                    getattr(self, field_name),
                    size=2,
                    field_name=f"rectangular underfill fillet {field_name}",
                ),
            )
        for field_name in ("base_z", "wall_height", "toe_width", "top_width"):
            object.__setattr__(
                self,
                field_name,
                _expression(
                    getattr(self, field_name),
                    field_name=f"rectangular underfill fillet {field_name}",
                ),
            )


@dataclass(frozen=True, slots=True)
class RoundedRectangleExtrusionSource:
    """A Z extrusion of an axis-aligned rounded rectangle."""

    origin_xyz: tuple[str, str, str]
    size_xy: tuple[str, str]
    height: str
    corner_radius: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "origin_xyz",
            _expression_vector(
                self.origin_xyz,
                size=3,
                field_name="rounded rectangle origin_xyz",
            ),
        )
        object.__setattr__(
            self,
            "size_xy",
            _expression_vector(
                self.size_xy,
                size=2,
                field_name="rounded rectangle size_xy",
            ),
        )
        object.__setattr__(
            self,
            "height",
            _expression(self.height, field_name="rounded rectangle height"),
        )
        object.__setattr__(
            self,
            "corner_radius",
            _expression(
                self.corner_radius,
                field_name="rounded rectangle corner_radius",
            ),
        )


@dataclass(frozen=True, slots=True)
class UnionSource:
    children: tuple["GeometryNodeSource", ...]

    def __post_init__(self) -> None:
        children = _objects(self.children, field_name="CSG union children")
        if len(children) < 2:
            raise GeometryCompilationError("CSG union requires at least two children")
        if any(type(child) not in _SOURCE_NODE_TYPES for child in children):
            raise GeometryCompilationError("CSG union contains an unsupported child")
        object.__setattr__(self, "children", children)


@dataclass(frozen=True, slots=True)
class DifferenceSource:
    base: "GeometryNodeSource"
    cutters: tuple["GeometryNodeSource", ...]

    def __post_init__(self) -> None:
        if type(self.base) not in _SOURCE_NODE_TYPES:
            raise GeometryCompilationError("CSG difference base is unsupported")
        cutters = _objects(self.cutters, field_name="CSG difference cutters")
        if not cutters:
            raise GeometryCompilationError(
                "CSG difference requires at least one cutter"
            )
        if any(type(cutter) not in _SOURCE_NODE_TYPES for cutter in cutters):
            raise GeometryCompilationError(
                "CSG difference contains an unsupported cutter"
            )
        object.__setattr__(self, "cutters", cutters)


GeometryNodeSource: TypeAlias = (
    BoxSource
    | RectangularFrameExtrusionSource
    | RectangularUnderfillFilletSource
    | RoundedRectangleExtrusionSource
    | UnionSource
    | DifferenceSource
)
_SOURCE_NODE_TYPES = (
    BoxSource,
    RectangularFrameExtrusionSource,
    RectangularUnderfillFilletSource,
    RoundedRectangleExtrusionSource,
    UnionSource,
    DifferenceSource,
)


@dataclass(frozen=True, slots=True)
class GeometryFragmentSource:
    fragment_id: str
    root: GeometryNodeSource
    placement: RigidPlacementSource = field(default_factory=RigidPlacementSource)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "fragment_id",
            _identifier(
                self.fragment_id,
                field_name="geometry fragment identifier",
            ),
        )
        if type(self.root) not in _SOURCE_NODE_TYPES:
            raise GeometryCompilationError("geometry fragment root is unsupported")
        if type(self.placement) is not RigidPlacementSource:
            raise GeometryCompilationError(
                "geometry fragment placement must be RigidPlacementSource"
            )


# ---------------------------------------------------------------------------
# Numeric canonical DTOs


@dataclass(frozen=True, slots=True)
class CanonicalRigidPlacement:
    """Rigid placement: ``T + P + Rz @ Ry @ Rx @ (point - P)``."""

    translation_xyz_mm: tuple[float, float, float]
    rotation_deg_xyz: tuple[float, float, float]
    pivot_xyz_mm: tuple[float, float, float]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "translation_xyz_mm",
            _float_vector(
                self.translation_xyz_mm,
                size=3,
                field_name="canonical placement translation_xyz_mm",
            ),
        )
        object.__setattr__(
            self,
            "rotation_deg_xyz",
            _float_vector(
                self.rotation_deg_xyz,
                size=3,
                field_name="canonical placement rotation_deg_xyz",
            ),
        )
        object.__setattr__(
            self,
            "pivot_xyz_mm",
            _float_vector(
                self.pivot_xyz_mm,
                size=3,
                field_name="canonical placement pivot_xyz_mm",
            ),
        )


@dataclass(frozen=True, slots=True)
class CanonicalBox:
    origin_xyz_mm: tuple[float, float, float]
    size_xyz_mm: tuple[float, float, float]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "origin_xyz_mm",
            _float_vector(
                self.origin_xyz_mm,
                size=3,
                field_name="canonical box origin_xyz_mm",
            ),
        )
        object.__setattr__(
            self,
            "size_xyz_mm",
            _float_vector(
                self.size_xyz_mm,
                size=3,
                field_name="canonical box size_xyz_mm",
            ),
        )
        _validate_box_size(self.size_xyz_mm, prefix="canonical box")


@dataclass(frozen=True, slots=True)
class CanonicalRectangularFrameExtrusion:
    outer_origin_xyz_mm: tuple[float, float, float]
    outer_size_xy_mm: tuple[float, float]
    opening_offset_xy_mm: tuple[float, float]
    opening_size_xy_mm: tuple[float, float]
    height_mm: float

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "outer_origin_xyz_mm",
            _float_vector(
                self.outer_origin_xyz_mm,
                size=3,
                field_name="canonical frame outer_origin_xyz_mm",
            ),
        )
        for field_name in (
            "outer_size_xy_mm",
            "opening_offset_xy_mm",
            "opening_size_xy_mm",
        ):
            object.__setattr__(
                self,
                field_name,
                _float_vector(
                    getattr(self, field_name),
                    size=2,
                    field_name=f"canonical frame {field_name}",
                ),
            )
        object.__setattr__(
            self,
            "height_mm",
            _finite_float(self.height_mm, field_name="canonical frame height_mm"),
        )
        _validate_frame_dimensions(
            self.outer_size_xy_mm,
            self.opening_offset_xy_mm,
            self.opening_size_xy_mm,
            self.height_mm,
            prefix="canonical frame",
        )


@dataclass(frozen=True, slots=True)
class CanonicalRectangularUnderfillFillet:
    die_origin_xy_mm: tuple[float, float]
    die_size_xy_mm: tuple[float, float]
    base_z_mm: float
    wall_height_mm: float
    toe_width_mm: float
    top_width_mm: float = 0.0
    side_widths_mm: tuple[float, float, float, float] | None = field(default=None, kw_only=True)
    top_widths_mm: tuple[float, float, float, float] | None = field(default=None, kw_only=True)

    @property
    def uses_elliptical_sweep(self) -> bool:
        return self.side_widths_mm is not None or self.top_widths_mm is not None

    def __post_init__(self) -> None:
        if self.side_widths_mm is not None:
            object.__setattr__(self, "side_widths_mm", _float_vector(self.side_widths_mm, size=4, field_name="fillet side_widths_mm"))
        if self.top_widths_mm is not None:
            object.__setattr__(self, "top_widths_mm", _float_vector(self.top_widths_mm, size=4, field_name="fillet top_widths_mm"))
        for field_name in ("die_origin_xy_mm", "die_size_xy_mm"):
            object.__setattr__(
                self,
                field_name,
                _float_vector(
                    getattr(self, field_name),
                    size=2,
                    field_name=f"canonical rectangular underfill fillet {field_name}",
                ),
            )
        for field_name in (
            "base_z_mm",
            "wall_height_mm",
            "toe_width_mm",
            "top_width_mm",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_float(
                    getattr(self, field_name),
                    field_name=f"canonical rectangular underfill fillet {field_name}",
                ),
            )
        _validate_rectangular_underfill_fillet_dimensions(
            self.die_size_xy_mm,
            self.wall_height_mm,
            self.toe_width_mm,
            self.top_width_mm,
            prefix="canonical rectangular underfill fillet",
            side_widths_mm=self.side_widths_mm,
            top_widths_mm=self.top_widths_mm,
        )


@dataclass(frozen=True, slots=True)
class CanonicalRoundedRectangleExtrusion:
    origin_xyz_mm: tuple[float, float, float]
    size_xy_mm: tuple[float, float]
    height_mm: float
    corner_radius_mm: float

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "origin_xyz_mm",
            _float_vector(
                self.origin_xyz_mm,
                size=3,
                field_name="canonical rounded rectangle origin_xyz_mm",
            ),
        )
        object.__setattr__(
            self,
            "size_xy_mm",
            _float_vector(
                self.size_xy_mm,
                size=2,
                field_name="canonical rounded rectangle size_xy_mm",
            ),
        )
        object.__setattr__(
            self,
            "height_mm",
            _finite_float(
                self.height_mm,
                field_name="canonical rounded rectangle height_mm",
            ),
        )
        object.__setattr__(
            self,
            "corner_radius_mm",
            _finite_float(
                self.corner_radius_mm,
                field_name="canonical rounded rectangle corner_radius_mm",
            ),
        )
        _validate_rounded_dimensions(
            self.size_xy_mm,
            self.height_mm,
            self.corner_radius_mm,
            prefix="canonical rounded rectangle",
        )


@dataclass(frozen=True, slots=True)
class CanonicalUnion:
    children: tuple["CanonicalGeometryNode", ...]

    def __post_init__(self) -> None:
        children = _objects(self.children, field_name="canonical CSG union children")
        if len(children) < 2:
            raise GeometryCompilationError(
                "canonical CSG union requires at least two children"
            )
        if any(type(child) not in _CANONICAL_NODE_TYPES for child in children):
            raise GeometryCompilationError(
                "canonical CSG union contains an unresolved or unsupported child"
            )
        object.__setattr__(self, "children", children)


@dataclass(frozen=True, slots=True)
class CanonicalDifference:
    base: "CanonicalGeometryNode"
    cutters: tuple["CanonicalGeometryNode", ...]

    def __post_init__(self) -> None:
        if type(self.base) not in _CANONICAL_NODE_TYPES:
            raise GeometryCompilationError(
                "canonical CSG difference base is unresolved or unsupported"
            )
        cutters = _objects(self.cutters, field_name="canonical CSG difference cutters")
        if not cutters:
            raise GeometryCompilationError(
                "canonical CSG difference requires at least one cutter"
            )
        if any(type(cutter) not in _CANONICAL_NODE_TYPES for cutter in cutters):
            raise GeometryCompilationError(
                "canonical CSG difference contains an unresolved or unsupported cutter"
            )
        object.__setattr__(self, "cutters", cutters)


CanonicalGeometryNode: TypeAlias = (
    CanonicalBox
    | CanonicalRectangularFrameExtrusion
    | CanonicalRectangularUnderfillFillet
    | CanonicalRoundedRectangleExtrusion
    | CanonicalUnion
    | CanonicalDifference
)
_CANONICAL_NODE_TYPES = (
    CanonicalBox,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalRoundedRectangleExtrusion,
    CanonicalUnion,
    CanonicalDifference,
)


@dataclass(frozen=True, slots=True)
class CanonicalGeometryFragment:
    fragment_id: str
    root: CanonicalGeometryNode
    placement: CanonicalRigidPlacement

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "fragment_id",
            _identifier(
                self.fragment_id,
                field_name="canonical fragment identifier",
            ),
        )
        if type(self.root) not in _CANONICAL_NODE_TYPES:
            raise GeometryCompilationError(
                "canonical fragment contains an unresolved or unsupported root"
            )
        if type(self.placement) is not CanonicalRigidPlacement:
            raise GeometryCompilationError(
                "canonical fragment placement must be numeric"
            )


@dataclass(frozen=True, slots=True)
class CanonicalComponentGeometry:
    component_id: str
    material_name: str
    fragments: tuple[CanonicalGeometryFragment, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "component_id",
            _identifier(
                self.component_id,
                field_name="canonical component identifier",
            ),
        )
        object.__setattr__(
            self,
            "material_name",
            _label(self.material_name, field_name="canonical component material"),
        )
        fragments = _objects(self.fragments, field_name="canonical component fragments")
        if not fragments:
            raise GeometryCompilationError(
                "canonical generated component must contain geometry"
            )
        if any(type(fragment) is not CanonicalGeometryFragment for fragment in fragments):
            raise GeometryCompilationError(
                "canonical component contains an unresolved fragment"
            )
        identifiers = tuple(fragment.fragment_id for fragment in fragments)
        if len(set(identifiers)) != len(identifiers):
            raise GeometryCompilationError(
                "canonical component fragment identifiers must be unique"
            )
        object.__setattr__(self, "fragments", fragments)


@dataclass(frozen=True, slots=True)
class CanonicalGeneratedGeometry:
    instance_id: str
    components: tuple[CanonicalComponentGeometry, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "instance_id",
            _identifier(
                self.instance_id,
                field_name="geometry instance identifier",
            ),
        )
        components = _objects(self.components, field_name="canonical components")
        if not components:
            raise GeometryCompilationError(
                "canonical generated geometry must contain a component"
            )
        if any(type(component) is not CanonicalComponentGeometry for component in components):
            raise GeometryCompilationError(
                "canonical geometry contains an unresolved component"
            )
        identifiers = tuple(component.component_id for component in components)
        if len(set(identifiers)) != len(identifiers):
            raise GeometryCompilationError(
                "canonical component identifiers must be unique"
            )
        fragment_ids = tuple(
            fragment.fragment_id
            for component in components
            for fragment in component.fragments
        )
        if len(set(fragment_ids)) != len(fragment_ids):
            raise GeometryCompilationError(
                "canonical fragment identifiers must be globally unique"
            )
        object.__setattr__(self, "components", components)


@dataclass(frozen=True, slots=True)
class GeometryBinding:
    """Separate provenance for one source expression bound to a numeric leaf."""

    field_path: str
    expression_source: str
    dimension: TemplateDimension
    canonical_value: float

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "field_path",
            _label(self.field_path, field_name="geometry binding field_path"),
        )
        object.__setattr__(
            self,
            "expression_source",
            _expression(
                self.expression_source,
                field_name="geometry binding expression_source",
            ),
        )
        dimension = self.dimension
        if isinstance(dimension, str) and not isinstance(dimension, TemplateDimension):
            try:
                dimension = TemplateDimension(dimension)
            except ValueError as error:
                raise GeometryCompilationError(
                    "geometry binding dimension must be length or dimensionless"
                ) from error
            object.__setattr__(self, "dimension", dimension)
        if not isinstance(dimension, TemplateDimension):
            raise GeometryCompilationError(
                "geometry binding dimension must be length or dimensionless"
            )
        object.__setattr__(
            self,
            "canonical_value",
            _finite_float(
                self.canonical_value,
                field_name="geometry binding canonical_value",
            ),
        )

    @property
    def canonical_unit(self) -> str:
        return "mm" if self.dimension is TemplateDimension.LENGTH else "number"


@dataclass(frozen=True, slots=True)
class CanonicalGeometryAudit:
    component_count: int
    fragment_count: int
    csg_node_count: int
    numeric_field_paths: tuple[str, ...]

    @property
    def numeric_field_count(self) -> int:
        return len(self.numeric_field_paths)


@dataclass(frozen=True, slots=True)
class GeometryCompilationResult:
    geometry: CanonicalGeneratedGeometry
    bindings: tuple[GeometryBinding, ...]

    def __post_init__(self) -> None:
        if type(self.geometry) is not CanonicalGeneratedGeometry:
            raise GeometryCompilationError(
                "geometry compilation result requires canonical geometry"
            )
        bindings = _objects(self.bindings, field_name="geometry bindings")
        if any(type(binding) is not GeometryBinding for binding in bindings):
            raise GeometryCompilationError(
                "geometry compilation result contains an invalid binding"
            )
        paths = tuple(binding.field_path for binding in bindings)
        if len(set(paths)) != len(paths):
            raise GeometryCompilationError("geometry binding paths must be unique")
        object.__setattr__(self, "bindings", bindings)


# ---------------------------------------------------------------------------
# Compilation


class _Compiler:
    def __init__(self, resolved: ResolvedTemplateParameters) -> None:
        if type(resolved) is not ResolvedTemplateParameters:
            raise GeometryCompilationError(
                "resolved must be ResolvedTemplateParameters"
            )
        self.resolved = resolved
        self.bindings: list[GeometryBinding] = []
        self.node_count = 0

    def bind(
        self,
        source: str,
        dimension: TemplateDimension,
        *,
        path: str,
    ) -> float:
        try:
            value = self.resolved.evaluate_expression(
                source,
                dimension=dimension,
                field_name=path,
            )
        except AssemblyPolicyError as error:
            raise GeometryCompilationError(str(error)) from error
        canonical = _finite_float(value, field_name=path)
        self.bindings.append(
            GeometryBinding(path, source, dimension, canonical)
        )
        return canonical

    def bind_vector(
        self,
        source: tuple[str, ...],
        dimension: TemplateDimension,
        *,
        path: str,
    ) -> tuple[float, ...]:
        return tuple(
            self.bind(expression, dimension, path=f"{path}[{index}]")
            for index, expression in enumerate(source)
        )

    def compile_placement(
        self,
        source: RigidPlacementSource,
        *,
        path: str,
    ) -> CanonicalRigidPlacement:
        return CanonicalRigidPlacement(
            translation_xyz_mm=self.bind_vector(
                source.translation_xyz,
                TemplateDimension.LENGTH,
                path=f"{path}.translation_xyz_mm",
            ),  # type: ignore[arg-type]
            rotation_deg_xyz=self.bind_vector(
                source.rotation_deg_xyz,
                TemplateDimension.DIMENSIONLESS,
                path=f"{path}.rotation_deg_xyz",
            ),  # type: ignore[arg-type]
            pivot_xyz_mm=self.bind_vector(
                source.pivot_xyz,
                TemplateDimension.LENGTH,
                path=f"{path}.pivot_xyz_mm",
            ),  # type: ignore[arg-type]
        )

    def compile_node(
        self,
        source: GeometryNodeSource,
        *,
        path: str,
        depth: int,
    ) -> CanonicalGeometryNode:
        if depth > _MAX_CSG_DEPTH:
            raise GeometryCompilationError(
                f"{path} exceeds the maximum CSG depth {_MAX_CSG_DEPTH}"
            )
        self.node_count += 1
        if self.node_count > _MAX_CSG_NODES:
            raise GeometryCompilationError(
                f"{path} exceeds the maximum CSG node count {_MAX_CSG_NODES}"
            )

        if type(source) is BoxSource:
            origin = self.bind_vector(
                source.origin_xyz,
                TemplateDimension.LENGTH,
                path=f"{path}.origin_xyz_mm",
            )
            size = self.bind_vector(
                source.size_xyz,
                TemplateDimension.LENGTH,
                path=f"{path}.size_xyz_mm",
            )
            assert len(origin) == 3 and len(size) == 3
            _validate_box_size(size, prefix=path)  # type: ignore[arg-type]
            return CanonicalBox(origin, size)  # type: ignore[arg-type]

        if type(source) is RectangularFrameExtrusionSource:
            origin = self.bind_vector(
                source.outer_origin_xyz,
                TemplateDimension.LENGTH,
                path=f"{path}.outer_origin_xyz_mm",
            )
            outer = self.bind_vector(
                source.outer_size_xy,
                TemplateDimension.LENGTH,
                path=f"{path}.outer_size_xy_mm",
            )
            offset = self.bind_vector(
                source.opening_offset_xy,
                TemplateDimension.LENGTH,
                path=f"{path}.opening_offset_xy_mm",
            )
            opening = self.bind_vector(
                source.opening_size_xy,
                TemplateDimension.LENGTH,
                path=f"{path}.opening_size_xy_mm",
            )
            height = self.bind(
                source.height,
                TemplateDimension.LENGTH,
                path=f"{path}.height_mm",
            )
            assert len(origin) == 3
            assert len(outer) == len(offset) == len(opening) == 2
            _validate_frame_dimensions(
                outer,  # type: ignore[arg-type]
                offset,  # type: ignore[arg-type]
                opening,  # type: ignore[arg-type]
                height,
                prefix=path,
            )
            return CanonicalRectangularFrameExtrusion(
                origin,  # type: ignore[arg-type]
                outer,  # type: ignore[arg-type]
                offset,  # type: ignore[arg-type]
                opening,  # type: ignore[arg-type]
                height,
            )

        if type(source) is RectangularUnderfillFilletSource:
            die_origin = self.bind_vector(
                source.die_origin_xy,
                TemplateDimension.LENGTH,
                path=f"{path}.die_origin_xy_mm",
            )
            die_size = self.bind_vector(
                source.die_size_xy,
                TemplateDimension.LENGTH,
                path=f"{path}.die_size_xy_mm",
            )
            base_z = self.bind(
                source.base_z,
                TemplateDimension.LENGTH,
                path=f"{path}.base_z_mm",
            )
            wall_height = self.bind(
                source.wall_height,
                TemplateDimension.LENGTH,
                path=f"{path}.wall_height_mm",
            )
            toe_width = self.bind(
                source.toe_width,
                TemplateDimension.LENGTH,
                path=f"{path}.toe_width_mm",
            )
            top_width = self.bind(
                source.top_width,
                TemplateDimension.LENGTH,
                path=f"{path}.top_width_mm",
            )
            assert len(die_origin) == len(die_size) == 2
            widths = (self.bind_vector(source.side_widths, TemplateDimension.LENGTH, path=f"{path}.side_widths_mm")
                      if source.side_widths is not None else None)
            tops = (self.bind_vector(source.top_widths, TemplateDimension.LENGTH, path=f"{path}.top_widths_mm")
                    if source.top_widths is not None else None)
            _validate_rectangular_underfill_fillet_dimensions(
                die_size,  # type: ignore[arg-type]
                wall_height,
                toe_width,
                top_width,
                prefix=path,
                side_widths_mm=widths,
                top_widths_mm=tops,
            )
            return CanonicalRectangularUnderfillFillet(
                die_origin,  # type: ignore[arg-type]
                die_size,  # type: ignore[arg-type]
                base_z,
                wall_height,
                toe_width,
                top_width,
                side_widths_mm=widths,
                top_widths_mm=tops,
            )

        if type(source) is RoundedRectangleExtrusionSource:
            origin = self.bind_vector(
                source.origin_xyz,
                TemplateDimension.LENGTH,
                path=f"{path}.origin_xyz_mm",
            )
            size = self.bind_vector(
                source.size_xy,
                TemplateDimension.LENGTH,
                path=f"{path}.size_xy_mm",
            )
            height = self.bind(
                source.height,
                TemplateDimension.LENGTH,
                path=f"{path}.height_mm",
            )
            radius = self.bind(
                source.corner_radius,
                TemplateDimension.LENGTH,
                path=f"{path}.corner_radius_mm",
            )
            assert len(origin) == 3 and len(size) == 2
            _validate_rounded_dimensions(
                size,  # type: ignore[arg-type]
                height,
                radius,
                prefix=path,
            )
            return CanonicalRoundedRectangleExtrusion(
                origin,  # type: ignore[arg-type]
                size,  # type: ignore[arg-type]
                height,
                radius,
            )

        if type(source) is UnionSource:
            return CanonicalUnion(
                tuple(
                    self.compile_node(
                        child,
                        path=f"{path}.children[{index}]",
                        depth=depth + 1,
                    )
                    for index, child in enumerate(source.children)
                )
            )

        if type(source) is DifferenceSource:
            return CanonicalDifference(
                base=self.compile_node(
                    source.base,
                    path=f"{path}.base",
                    depth=depth + 1,
                ),
                cutters=tuple(
                    self.compile_node(
                        cutter,
                        path=f"{path}.cutters[{index}]",
                        depth=depth + 1,
                    )
                    for index, cutter in enumerate(source.cutters)
                ),
            )

        raise GeometryCompilationError(f"{path} contains an unsupported source node")


def compile_rigid_placement(
    source: RigidPlacementSource,
    resolved: ResolvedTemplateParameters,
    *,
    field_path: str,
) -> CanonicalRigidPlacement:
    """Resolve one explicit placement without compiling or inferring geometry."""

    if type(source) is not RigidPlacementSource:
        raise GeometryCompilationError("source must be a RigidPlacementSource")
    compiler = _Compiler(resolved)
    return compiler.compile_placement(source, path=field_path)


def compile_generated_geometry_instance(
    *,
    instance_id: str,
    records: Sequence[GeometryRecord],
    fragment_sources: Mapping[str, GeometryFragmentSource],
    resolved: ResolvedTemplateParameters,
) -> GeometryCompilationResult:
    """Compile one resolved template instance into generated canonical geometry."""

    resolved_instance_id = _identifier(
        instance_id,
        field_name="geometry instance identifier",
    )
    if not isinstance(fragment_sources, Mapping):
        raise GeometryCompilationError("fragment_sources must be a mapping")
    registry: dict[str, GeometryFragmentSource] = {}
    for raw_key, source in fragment_sources.items():
        if not isinstance(raw_key, str) or not raw_key.strip():
            raise GeometryCompilationError(
                "fragment_sources keys must be non-empty strings"
            )
        if raw_key != raw_key.strip():
            raise GeometryCompilationError(
                f"fragment_sources key {raw_key!r} must not contain outer whitespace"
            )
        if type(source) is not GeometryFragmentSource:
            raise GeometryCompilationError(
                f"fragment_sources[{raw_key!r}] must be GeometryFragmentSource"
            )
        if source.fragment_id != raw_key:
            raise GeometryCompilationError(
                f"fragment_sources key {raw_key!r} does not match fragment_id "
                f"{source.fragment_id!r}"
            )
        registry[raw_key] = source

    try:
        components = compile_geometry_records(records)
    except AssemblyPolicyError as error:
        raise GeometryCompilationError(str(error)) from error
    referenced = tuple(
        geometry_ref
        for component in components
        for geometry_ref in component.geometry_refs
    )
    referenced_set = set(referenced)
    missing = sorted(referenced_set.difference(registry))
    unused = sorted(set(registry).difference(referenced_set))
    if missing or unused:
        details: list[str] = []
        if missing:
            details.append(f"missing fragment source {missing[0]!r}")
        if unused:
            details.append(f"unused fragment source {unused[0]!r}")
        raise GeometryCompilationError(
            "fragment registry must exactly match geometry records: " + "; ".join(details)
        )

    compiler = _Compiler(resolved)
    canonical_components: list[CanonicalComponentGeometry] = []
    for component in components:
        assert component.material_name is not None
        fragments: list[CanonicalGeometryFragment] = []
        for fragment_id in component.geometry_refs:
            source = registry[fragment_id]
            path = (
                f"instance[{resolved_instance_id}]/component[{component.identifier}]"
                f"/fragment[{fragment_id}]"
            )
            # The complexity contract applies independently to each fragment
            # root, not to an otherwise harmless multi-fragment component.
            compiler.node_count = 0
            root = compiler.compile_node(source.root, path=f"{path}.root", depth=1)
            placement = compiler.compile_placement(
                source.placement,
                path=f"{path}.placement",
            )
            fragments.append(
                CanonicalGeometryFragment(fragment_id, root, placement)
            )
        canonical_components.append(
            CanonicalComponentGeometry(
                component.identifier,
                component.material_name,
                tuple(fragments),
            )
        )

    geometry = CanonicalGeneratedGeometry(
        resolved_instance_id,
        tuple(canonical_components),
    )
    audit = audit_canonical_geometry(geometry)
    binding_paths = tuple(binding.field_path for binding in compiler.bindings)
    if binding_paths != audit.numeric_field_paths:
        raise GeometryCompilationError(
            "internal geometry binding audit failed: source and canonical numeric "
            "fields differ"
        )
    return GeometryCompilationResult(geometry, tuple(compiler.bindings))


# ---------------------------------------------------------------------------
# Type-aware unresolved-token audit and explicit serialization


def _audit_float_vector(
    value: tuple[float, ...],
    *,
    path: str,
    expected_size: int,
    output: list[str],
) -> None:
    if type(value) is not tuple or len(value) != expected_size:
        raise GeometryCompilationError(
            f"{path} must be a canonical {expected_size}-value tuple"
        )
    for index, item in enumerate(value):
        item_path = f"{path}[{index}]"
        if type(item) is not float or not math.isfinite(item):
            raise GeometryCompilationError(
                f"{item_path} contains an unresolved or non-finite value"
            )
        output.append(item_path)


def _audit_node(
    node: CanonicalGeometryNode,
    *,
    path: str,
    depth: int,
    numeric_paths: list[str],
) -> int:
    if depth > _MAX_CSG_DEPTH:
        raise GeometryCompilationError(
            f"{path} exceeds the maximum CSG depth {_MAX_CSG_DEPTH}"
        )
    if type(node) is CanonicalBox:
        _audit_float_vector(
            node.origin_xyz_mm,
            path=f"{path}.origin_xyz_mm",
            expected_size=3,
            output=numeric_paths,
        )
        _audit_float_vector(
            node.size_xyz_mm,
            path=f"{path}.size_xyz_mm",
            expected_size=3,
            output=numeric_paths,
        )
        _validate_box_size(node.size_xyz_mm, prefix=path)
        return 1
    if type(node) is CanonicalRectangularFrameExtrusion:
        _audit_float_vector(
            node.outer_origin_xyz_mm,
            path=f"{path}.outer_origin_xyz_mm",
            expected_size=3,
            output=numeric_paths,
        )
        _audit_float_vector(
            node.outer_size_xy_mm,
            path=f"{path}.outer_size_xy_mm",
            expected_size=2,
            output=numeric_paths,
        )
        _audit_float_vector(
            node.opening_offset_xy_mm,
            path=f"{path}.opening_offset_xy_mm",
            expected_size=2,
            output=numeric_paths,
        )
        _audit_float_vector(
            node.opening_size_xy_mm,
            path=f"{path}.opening_size_xy_mm",
            expected_size=2,
            output=numeric_paths,
        )
        if type(node.height_mm) is not float or not math.isfinite(node.height_mm):
            raise GeometryCompilationError(
                f"{path}.height_mm contains an unresolved or non-finite value"
            )
        numeric_paths.append(f"{path}.height_mm")
        _validate_frame_dimensions(
            node.outer_size_xy_mm,
            node.opening_offset_xy_mm,
            node.opening_size_xy_mm,
            node.height_mm,
            prefix=path,
        )
        return 1
    if type(node) is CanonicalRectangularUnderfillFillet:
        _audit_float_vector(
            node.die_origin_xy_mm,
            path=f"{path}.die_origin_xy_mm",
            expected_size=2,
            output=numeric_paths,
        )
        _audit_float_vector(
            node.die_size_xy_mm,
            path=f"{path}.die_size_xy_mm",
            expected_size=2,
            output=numeric_paths,
        )
        for field_name in (
            "base_z_mm",
            "wall_height_mm",
            "toe_width_mm",
            "top_width_mm",
        ):
            value = getattr(node, field_name)
            if type(value) is not float or not math.isfinite(value):
                raise GeometryCompilationError(
                    f"{path}.{field_name} contains an unresolved or non-finite value"
                )
            numeric_paths.append(f"{path}.{field_name}")
        if node.side_widths_mm is not None:
            _audit_float_vector(node.side_widths_mm, path=f"{path}.side_widths_mm", expected_size=4, output=numeric_paths)
        if node.top_widths_mm is not None:
            _audit_float_vector(node.top_widths_mm, path=f"{path}.top_widths_mm", expected_size=4, output=numeric_paths)
        _validate_rectangular_underfill_fillet_dimensions(
            node.die_size_xy_mm,
            node.wall_height_mm,
            node.toe_width_mm,
            node.top_width_mm,
            prefix=path,
            side_widths_mm=node.side_widths_mm,
            top_widths_mm=node.top_widths_mm,
        )
        return 1
    if type(node) is CanonicalRoundedRectangleExtrusion:
        _audit_float_vector(
            node.origin_xyz_mm,
            path=f"{path}.origin_xyz_mm",
            expected_size=3,
            output=numeric_paths,
        )
        _audit_float_vector(
            node.size_xy_mm,
            path=f"{path}.size_xy_mm",
            expected_size=2,
            output=numeric_paths,
        )
        for field_name in ("height_mm", "corner_radius_mm"):
            value = getattr(node, field_name)
            if type(value) is not float or not math.isfinite(value):
                raise GeometryCompilationError(
                    f"{path}.{field_name} contains an unresolved or non-finite value"
                )
            numeric_paths.append(f"{path}.{field_name}")
        _validate_rounded_dimensions(
            node.size_xy_mm,
            node.height_mm,
            node.corner_radius_mm,
            prefix=path,
        )
        return 1
    if type(node) is CanonicalUnion:
        if len(node.children) < 2:
            raise GeometryCompilationError(f"{path} has an invalid CSG union")
        total = 1
        for index, child in enumerate(node.children):
            if type(child) not in _CANONICAL_NODE_TYPES:
                raise GeometryCompilationError(
                    f"{path}.children[{index}] is unresolved or unsupported"
                )
            total += _audit_node(
                child,
                path=f"{path}.children[{index}]",
                depth=depth + 1,
                numeric_paths=numeric_paths,
            )
        return total
    if type(node) is CanonicalDifference:
        if type(node.base) not in _CANONICAL_NODE_TYPES or not node.cutters:
            raise GeometryCompilationError(f"{path} has an invalid CSG difference")
        total = 1 + _audit_node(
            node.base,
            path=f"{path}.base",
            depth=depth + 1,
            numeric_paths=numeric_paths,
        )
        for index, cutter in enumerate(node.cutters):
            if type(cutter) not in _CANONICAL_NODE_TYPES:
                raise GeometryCompilationError(
                    f"{path}.cutters[{index}] is unresolved or unsupported"
                )
            total += _audit_node(
                cutter,
                path=f"{path}.cutters[{index}]",
                depth=depth + 1,
                numeric_paths=numeric_paths,
            )
        return total
    raise GeometryCompilationError(f"{path} is unresolved or unsupported")


def _audit_placement(
    placement: CanonicalRigidPlacement,
    *,
    path: str,
    numeric_paths: list[str],
) -> None:
    if type(placement) is not CanonicalRigidPlacement:
        raise GeometryCompilationError(f"{path} is unresolved or unsupported")
    _audit_float_vector(
        placement.translation_xyz_mm,
        path=f"{path}.translation_xyz_mm",
        expected_size=3,
        output=numeric_paths,
    )
    _audit_float_vector(
        placement.rotation_deg_xyz,
        path=f"{path}.rotation_deg_xyz",
        expected_size=3,
        output=numeric_paths,
    )
    _audit_float_vector(
        placement.pivot_xyz_mm,
        path=f"{path}.pivot_xyz_mm",
        expected_size=3,
        output=numeric_paths,
    )


def audit_canonical_geometry(
    geometry: CanonicalGeneratedGeometry,
) -> CanonicalGeometryAudit:
    """Fail closed if a canonical numeric slot still contains source data."""

    if type(geometry) is not CanonicalGeneratedGeometry:
        raise GeometryCompilationError(
            "canonical geometry audit accepts CanonicalGeneratedGeometry only"
        )
    numeric_paths: list[str] = []
    csg_nodes = 0
    fragment_count = 0
    for component in geometry.components:
        if type(component) is not CanonicalComponentGeometry:
            raise GeometryCompilationError(
                "canonical geometry contains an unresolved component"
            )
        for fragment in component.fragments:
            if type(fragment) is not CanonicalGeometryFragment:
                raise GeometryCompilationError(
                    "canonical geometry contains an unresolved fragment"
                )
            fragment_count += 1
            path = (
                f"instance[{geometry.instance_id}]/component[{component.component_id}]"
                f"/fragment[{fragment.fragment_id}]"
            )
            before = csg_nodes
            csg_nodes += _audit_node(
                fragment.root,
                path=f"{path}.root",
                depth=1,
                numeric_paths=numeric_paths,
            )
            if csg_nodes - before > _MAX_CSG_NODES:
                raise GeometryCompilationError(
                    f"{path}.root exceeds the maximum CSG node count {_MAX_CSG_NODES}"
                )
            _audit_placement(
                fragment.placement,
                path=f"{path}.placement",
                numeric_paths=numeric_paths,
            )
    return CanonicalGeometryAudit(
        component_count=len(geometry.components),
        fragment_count=fragment_count,
        csg_node_count=csg_nodes,
        numeric_field_paths=tuple(numeric_paths),
    )


def _placement_json(placement: CanonicalRigidPlacement) -> dict[str, object]:
    return {
        "translation_xyz_mm": list(placement.translation_xyz_mm),
        "rotation_deg_xyz": list(placement.rotation_deg_xyz),
        "pivot_xyz_mm": list(placement.pivot_xyz_mm),
        "rotation_convention": "right_handed_rx_then_ry_then_rz",
    }


def _node_json(node: CanonicalGeometryNode) -> dict[str, object]:
    if type(node) is CanonicalBox:
        return {
            "kind": "box",
            "origin_xyz_mm": list(node.origin_xyz_mm),
            "size_xyz_mm": list(node.size_xyz_mm),
        }
    if type(node) is CanonicalRectangularFrameExtrusion:
        return {
            "kind": "rectangular_frame_extrusion",
            "outer_origin_xyz_mm": list(node.outer_origin_xyz_mm),
            "outer_size_xy_mm": list(node.outer_size_xy_mm),
            "opening_offset_xy_mm": list(node.opening_offset_xy_mm),
            "opening_size_xy_mm": list(node.opening_size_xy_mm),
            "height_mm": node.height_mm,
        }
    if type(node) is CanonicalRectangularUnderfillFillet:
        return {
            "kind": "rectangular_underfill_fillet",
            "die_origin_xy_mm": list(node.die_origin_xy_mm),
            "die_size_xy_mm": list(node.die_size_xy_mm),
            "base_z_mm": node.base_z_mm,
            "wall_height_mm": node.wall_height_mm,
            "toe_width_mm": node.toe_width_mm,
            "top_width_mm": node.top_width_mm,
            **({"side_widths_mm": list(node.side_widths_mm)} if node.side_widths_mm is not None else {}),
            **({"top_widths_mm": list(node.top_widths_mm)} if node.top_widths_mm is not None else {}),
        }
    if type(node) is CanonicalRoundedRectangleExtrusion:
        return {
            "kind": "rounded_rectangle_extrusion",
            "origin_xyz_mm": list(node.origin_xyz_mm),
            "size_xy_mm": list(node.size_xy_mm),
            "height_mm": node.height_mm,
            "corner_radius_mm": node.corner_radius_mm,
        }
    if type(node) is CanonicalUnion:
        return {
            "kind": "union",
            "children": [_node_json(child) for child in node.children],
        }
    if type(node) is CanonicalDifference:
        return {
            "kind": "difference",
            "base": _node_json(node.base),
            "cutters": [_node_json(cutter) for cutter in node.cutters],
        }
    raise GeometryCompilationError("cannot serialize unresolved geometry")


def canonical_fragment_to_jsonable(
    fragment: CanonicalGeometryFragment,
) -> dict[str, object]:
    """Return one complete canonical fragment payload for stable binding."""

    if type(fragment) is not CanonicalGeometryFragment:
        raise GeometryCompilationError(
            "canonical fragment digest requires resolved canonical geometry"
        )
    numeric_paths: list[str] = []
    node_count = _audit_node(
        fragment.root,
        path=f"fragment[{fragment.fragment_id}].root",
        depth=1,
        numeric_paths=numeric_paths,
    )
    if node_count > _MAX_CSG_NODES:
        raise GeometryCompilationError(
            "canonical fragment exceeds the maximum CSG node count"
        )
    _audit_placement(
        fragment.placement,
        path=f"fragment[{fragment.fragment_id}].placement",
        numeric_paths=numeric_paths,
    )
    return {
        "schema": _CANONICAL_FRAGMENT_SCHEMA,
        "fragment_id": fragment.fragment_id,
        "root": _node_json(fragment.root),
        "placement": _placement_json(fragment.placement),
    }


def canonical_fragment_sha256(fragment: CanonicalGeometryFragment) -> str:
    """Hash every canonical root and placement field of one fragment."""

    payload = json.dumps(
        canonical_fragment_to_jsonable(fragment),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def canonical_geometry_to_jsonable(
    geometry: CanonicalGeneratedGeometry,
) -> dict[str, object]:
    """Return the explicit canonical JSON payload after a full numeric audit."""

    audit_canonical_geometry(geometry)
    return {
        "schema": _CANONICAL_SCHEMA,
        "instance_id": geometry.instance_id,
        "components": [
            {
                "component_id": component.component_id,
                "material_name": component.material_name,
                "fragments": [
                    {
                        "fragment_id": fragment.fragment_id,
                        "root": _node_json(fragment.root),
                        "placement": _placement_json(fragment.placement),
                    }
                    for fragment in component.fragments
                ],
            }
            for component in geometry.components
        ],
    }


def canonical_geometry_json(geometry: CanonicalGeneratedGeometry) -> str:
    """Serialize canonical geometry deterministically without non-finite JSON."""

    return json.dumps(
        canonical_geometry_to_jsonable(geometry),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def canonical_geometry_sha256(geometry: CanonicalGeneratedGeometry) -> str:
    """Return the SHA-256 of the deterministic canonical JSON serialization."""

    return hashlib.sha256(canonical_geometry_json(geometry).encode("utf-8")).hexdigest()


__all__ = [
    "BoxSource",
    "CanonicalBox",
    "CanonicalComponentGeometry",
    "CanonicalDifference",
    "CanonicalGeneratedGeometry",
    "CanonicalGeometryAudit",
    "CanonicalGeometryFragment",
    "CanonicalGeometryNode",
    "CanonicalRectangularFrameExtrusion",
    "CanonicalRectangularUnderfillFillet",
    "CanonicalRigidPlacement",
    "CanonicalRoundedRectangleExtrusion",
    "CanonicalUnion",
    "DifferenceSource",
    "GeometryBinding",
    "GeometryCompilationError",
    "GeometryTransientConstraintError",
    "GeometryCompilationResult",
    "GeometryFragmentSource",
    "GeometryNodeSource",
    "RectangularFrameExtrusionSource",
    "RectangularUnderfillFilletSource",
    "RigidPlacementSource",
    "RoundedRectangleExtrusionSource",
    "UnionSource",
    "audit_canonical_geometry",
    "canonical_fragment_sha256",
    "canonical_fragment_to_jsonable",
    "canonical_geometry_json",
    "canonical_geometry_sha256",
    "canonical_geometry_to_jsonable",
    "compile_generated_geometry_instance",
    "compile_rigid_placement",
]
