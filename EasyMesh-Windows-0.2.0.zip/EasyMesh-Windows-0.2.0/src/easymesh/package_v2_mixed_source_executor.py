"""Role-free execution of a lowered mixed Package V2 Source.

This module is the execution counterpart of
``package_v2_mixed_source_lowering``.  It deliberately does not know package
roles, material meanings, stack order, or names such as "upper" and "lower".
The only scheduling edges are the real positive-area face pairs selected by
``plan_neutral_surface_authorities``.

Each shared surface is materialized once by its authority.  Its package-frame
coordinates, TRI/QUAD connectivity and semantic node tokens are then supplied
unchanged to the consumer volume backend.  Frozen volume connectivity remains
immutable in the imported source and is never propagated into a Generated
Component.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
import math
from pathlib import Path
from types import MappingProxyType
from typing import Literal, TypeAlias

from .component_interface import ComponentMeshRequirement
from .gmsh_cartesian_tensor_surface import (
    GmshCartesianTensorSurfaceError,
    generate_gmsh_cartesian_tensor_rectangle,
)
from .package_assembly import (
    ComponentLocalDirection,
    InterfaceMatchMode,
    OrthogonalHexMeshStrategy,
    StructuredSweepMeshStrategy,
)
from .package_v2_adjacency_execution import CanonicalAdjacentSide
from .package_v2_conformal_hybrid_materializer import (
    ConformalHybridComponentMesh,
    materialize_conformal_hybrid_component,
)
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalComponentGeometry,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalRigidPlacement,
)
from .package_v2_mixed_execution_context import MixedExecutionContext
from .package_v2_locked_surface_patch import LockedGeneratedSurfacePatch
from .package_v2_mesh_ordering import (
    MaterializedContactDomain,
    MeshOrderingError,
    OrderedSurfaceConstraint,
    OrderedSurfaceMaterializationAudit,
    audit_ordered_surface_materialization,
)
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)
from .package_v2_mixed_mesh_assembly import (
    ComponentLocalMeshFragment,
    ComponentMeshNode,
    DeclaredSharedSeam,
    ExpectedCompleteSupportPlaneInterface,
    FROZEN_FRAGMENT_KEY,
    FragmentFaceReference,
    MixedMeshAssemblyPlan,
    MixedMeshWriteResult,
    assemble_mixed_volume_mesh,
    frozen_node_semantic_token,
    write_mixed_volume_mesh,
)
from .package_v2_mixed_mesh_fragments import (
    declared_shared_seams_from_facets,
    fragment_from_orthogonal_fillet_mesh,
    placed_frozen_volume_mesh,
)
from .package_v2_orthogonal_fillet import (
    LockedCartesianBoundaryChain,
    LockedCartesianQuad,
    OrthogonalBoundarySide,
    OrthogonalFilletMesh,
    OrthogonalMultiblockFilletMesh,
    mesh_rectangular_fillet_orthogonal_hex,
    mesh_rectangular_fillet_orthogonal_hex_multiblock,
)
from .package_v2_orthogonal_box_frame_materializer import (
    OrthogonalBoxFrameMaterializationError,
    materialize_orthogonal_box_frame_component,
)
from .package_v2_surface_authority import (
    NeutralSurfaceAuthority,
    NeutralSurfaceAuthorityPlan,
    canonical_side_cartesian_rectangle,
    plan_neutral_surface_authorities,
)
from .package_v2_structured_sweep_materializer import (
    StructuredSweepMaterializationError,
    materialize_structured_sweep_component,
)
from .package_v2_compile import PackageV2CompileResult
from .package_v2_orthogonal_candidates import OrthogonalCandidateGrid
from .package_v2_frozen import FrozenSourceSnapshot
from .package_v2_mixed_execution_context import build_mixed_execution_context
from .package_v2_mixed_source_lowering import (
    FrozenGeneratedInterfaceKey,
    lower_mixed_source,
)


Point3D: TypeAlias = tuple[float, float, float]
FragmentSideKey: TypeAlias = tuple[str, str]
PendingDependencyKind: TypeAlias = Literal[
    "upstream_surface",
    "structured_sweep_backend",
    "structured_sweep_locked_section",
    "orthogonal_geometry_backend",
    "orthogonal_locked_boundary_chain",
    "orthogonal_locked_patch",
]

class MixedSourceExecutionError(ValueError):
    """The neutral execution contract cannot be materialized losslessly."""


class PartialContactBoundaryError(MixedSourceExecutionError):
    """A rejected facet, with read-only evidence for the result report."""

    def __init__(self, diagnostic):
        from .package_v2_warning_display import contact_error_message

        self.diagnostic = diagnostic
        super().__init__(contact_error_message(diagnostic))


def _partial_contact_boundary_error(authority, producer, consumer, points, backend, tolerance):
    # Inspect only the facet that already failed the existing contact check.
    # These coordinates never participate in meshing or contact selection.
    local_points = tuple(_package_to_local(p, producer.placement) for p in points)
    bounds = tuple((min(p[a] for p in local_points), max(p[a] for p in local_points))
                   for a in range(3))
    boundaries = []
    rectangle = canonical_side_cartesian_rectangle(consumer, authority.consumer_side_name)
    if rectangle is not None:
        origin, u, v = rectangle
        corners = tuple(_package_to_local(_local_to_package(
            tuple(origin[a] + du*u[a] + dv*v[a] for a in range(3)), consumer.placement),
            producer.placement) for du, dv in ((0, 0), (1, 0), (1, 1), (0, 1)))
        for first, second in zip(corners, (*corners[1:], corners[0])):
            for axis, (low, high) in enumerate(bounds):
                value = (first[axis] + second[axis]) / 2
                if (abs(first[axis] - second[axis]) <= tolerance
                        and low + tolerance < value < high - tolerance
                        and not any(b["axis"] == "XYZ"[axis]
                                    and abs(b["coordinate_mm"] - value) <= tolerance for b in boundaries)):
                    boundaries.append({"axis": "XYZ"[axis], "coordinate_mm": value,
                                       "facet_range_mm": [low, high]})
    return PartialContactBoundaryError({
        "code": "partial_contact_boundary_cuts_facet", "severity": "error", "export_allowed": False,
        "component_id": authority.producer_component_id,
        "adjacent_component_id": authority.consumer_component_id,
        "fragment_id": authority.producer_fragment_id,
        "adjacent_fragment_id": authority.consumer_fragment_id,
        "geometric_side": authority.producer_side_name,
        "adjacent_geometric_side": authority.consumer_side_name,
        "face_pair_id": authority.face_pair_id, "backend": backend,
        "contact_boundaries_local_mm": boundaries,
        "locations": [{"bounds_local_mm": [list(b) for b in bounds]}],
        "example_facet_coordinates_package_mm": [list(p) for p in points],
    })


def _text(value: object, *, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or any(ord(character) < 32 for character in value)
    ):
        raise MixedSourceExecutionError(
            f"{field_name} must be a canonical non-empty string"
        )
    return value


def _point3(value: Sequence[float], *, field_name: str) -> Point3D:
    try:
        raw = tuple(value)
    except TypeError as error:
        raise MixedSourceExecutionError(
            f"{field_name} must contain x, y and z"
        ) from error
    if len(raw) != 3:
        raise MixedSourceExecutionError(
            f"{field_name} must contain x, y and z"
        )
    output: list[float] = []
    for item in raw:
        if isinstance(item, bool):
            raise MixedSourceExecutionError(f"{field_name} must be finite")
        try:
            number = float(item)
        except (TypeError, ValueError, OverflowError) as error:
            raise MixedSourceExecutionError(f"{field_name} must be finite") from error
        if not math.isfinite(number):
            raise MixedSourceExecutionError(f"{field_name} must be finite")
        output.append(0.0 if number == 0.0 else number)
    return tuple(output)  # type: ignore[return-value]


def _facet(value: Sequence[int], *, field_name: str) -> tuple[int, ...]:
    try:
        nodes = tuple(value)
    except TypeError as error:
        raise MixedSourceExecutionError(
            f"{field_name} must be a TRI3 or QUAD4"
        ) from error
    if (
        len(nodes) not in {3, 4}
        or len(set(nodes)) != len(nodes)
        or any(
            isinstance(node, bool) or not isinstance(node, int) or node < 1
            for node in nodes
        )
    ):
        raise MixedSourceExecutionError(
            f"{field_name} must be a TRI3 or QUAD4"
        )
    return nodes


@dataclass(frozen=True, slots=True)
class MaterializedSurfacePatch:
    """One authority-owned physical interface in package coordinates."""

    face_pair_id: str
    interface_id: str
    producer_side: CanonicalAdjacentSide
    consumer_side: CanonicalAdjacentSide
    surface_policy: str
    node_coordinates_package_mm: Mapping[int, Point3D]
    facets: tuple[tuple[int, ...], ...]
    semantic_tokens_by_node_id: Mapping[int, str]
    provenance: str
    contact_audit: OrderedSurfaceMaterializationAudit
    candidate_quads_package_mm: tuple[tuple[Point3D, ...], ...] = ()

    def __post_init__(self) -> None:
        for field_name in (
            "face_pair_id",
            "interface_id",
            "surface_policy",
            "provenance",
        ):
            object.__setattr__(
                self,
                field_name,
                _text(getattr(self, field_name), field_name=field_name),
            )
        if type(self.producer_side) is not CanonicalAdjacentSide or type(
            self.consumer_side
        ) is not CanonicalAdjacentSide:
            raise MixedSourceExecutionError(
                "materialized surface sides must be canonical adjacent sides"
            )
        if type(self.contact_audit) is not OrderedSurfaceMaterializationAudit:
            raise MixedSourceExecutionError(
                "materialized surface patch requires contact-domain evidence"
            )
        coordinates = {
            node: _point3(point, field_name="surface node coordinate")
            for node, point in self.node_coordinates_package_mm.items()
        }
        if any(
            isinstance(node, bool) or not isinstance(node, int) or node < 1
            for node in coordinates
        ):
            raise MixedSourceExecutionError("surface node IDs must be positive")
        facets = tuple(
            _facet(value, field_name="surface facet") for value in self.facets
        )
        if (not facets and self.provenance != "orthogonal_hex") or len({tuple(sorted(value)) for value in facets}) != len(
            facets
        ):
            raise MixedSourceExecutionError(
                "materialized surface facets must be non-empty and unique"
            )
        referenced = {node for value in facets for node in value}
        if referenced != set(coordinates):
            raise MixedSourceExecutionError(
                "surface coordinates must contain exactly the referenced nodes"
            )
        tokens = {
            node: _text(token, field_name="surface node semantic token")
            for node, token in self.semantic_tokens_by_node_id.items()
        }
        if set(tokens) != referenced or len(set(tokens.values())) != len(tokens):
            raise MixedSourceExecutionError(
                "every surface node requires one unique semantic token"
            )
        object.__setattr__(
            self,
            "node_coordinates_package_mm",
            MappingProxyType(coordinates),
        )
        object.__setattr__(self, "facets", facets)
        object.__setattr__(
            self,
            "semantic_tokens_by_node_id",
            MappingProxyType(tokens),
        )


@dataclass(frozen=True, slots=True)
class MaterializedComponent:
    """Assembly-ready component fragments plus their geometric boundaries."""

    component_id: str
    backend: str
    fragments_by_id: Mapping[str, ComponentLocalMeshFragment]
    boundary_facets_by_fragment_side: Mapping[
        FragmentSideKey, tuple[tuple[int, ...], ...]
    ]
    locked_facets_by_fragment_side: Mapping[
        FragmentSideKey, tuple[tuple[int, ...], ...]
    ]
    external: bool = False
    backend_evidence_by_fragment_id: Mapping[
        str, Mapping[str, object]
    ] = field(default_factory=dict)
    candidate_endpoint_quads: Mapping[FragmentSideKey, tuple[tuple[Point3D, ...], ...]] = field(default_factory=dict)
    orthogonal_candidate_grids: Mapping[str, OrthogonalCandidateGrid] = field(default_factory=dict)

    def __post_init__(self) -> None:
        component_id = _text(self.component_id, field_name="component_id")
        object.__setattr__(self, "component_id", component_id)
        object.__setattr__(
            self, "backend", _text(self.backend, field_name="component backend")
        )
        if not isinstance(self.external, bool):
            raise MixedSourceExecutionError("external must be boolean")
        fragments = dict(self.fragments_by_id)
        if not fragments or any(
            not isinstance(fragment_id, str)
            or not isinstance(fragment, ComponentLocalMeshFragment)
            or fragment.fragment_key != fragment_id
            or fragment.component_key != component_id
            for fragment_id, fragment in fragments.items()
        ):
            raise MixedSourceExecutionError(
                "materialized component fragments have inconsistent identity"
            )
        normalized: dict[str, Mapping[FragmentSideKey, tuple[tuple[int, ...], ...]]] = {}
        for field_name in (
            "boundary_facets_by_fragment_side",
            "locked_facets_by_fragment_side",
        ):
            raw = getattr(self, field_name)
            values: dict[FragmentSideKey, tuple[tuple[int, ...], ...]] = {}
            for key, facets in raw.items():
                if (
                    not isinstance(key, tuple)
                    or len(key) != 2
                    or key[0] not in fragments
                    or not isinstance(key[1], str)
                    or not key[1]
                ):
                    raise MixedSourceExecutionError(
                        f"{field_name} contains an unknown fragment side"
                    )
                values[key] = tuple(
                    _facet(value, field_name=f"{field_name} facet")
                    for value in facets
                )
            normalized[field_name] = MappingProxyType(values)
        object.__setattr__(self, "fragments_by_id", MappingProxyType(fragments))
        for field_name, values in normalized.items():
            object.__setattr__(self, field_name, values)
        backend_evidence: dict[str, Mapping[str, object]] = {}
        for fragment_id, evidence in self.backend_evidence_by_fragment_id.items():
            if fragment_id not in fragments or not isinstance(evidence, Mapping):
                raise MixedSourceExecutionError(
                    "backend evidence references an unknown fragment"
                )
            backend_evidence[fragment_id] = MappingProxyType(dict(evidence))
        object.__setattr__(
            self,
            "backend_evidence_by_fragment_id",
            MappingProxyType(backend_evidence),
        )
        for field_name in ("candidate_endpoint_quads", "orthogonal_candidate_grids"):
            object.__setattr__(self, field_name, MappingProxyType(dict(getattr(self, field_name))))


@dataclass(frozen=True, slots=True)
class InterfaceFacetSet:
    face_pair_id: str
    producer_fragment_id: str
    producer_facets: tuple[tuple[int, ...], ...]
    consumer_fragment_id: str
    consumer_facets: tuple[tuple[int, ...], ...]


@dataclass(frozen=True, slots=True)
class FrozenInterfaceFacetSet:
    interface_key: FrozenGeneratedInterfaceKey
    generated_fragment_id: str
    generated_side_name: str
    frozen_facets: tuple[tuple[int, ...], ...]
    generated_facets: tuple[tuple[int, ...], ...]
    semantic_tokens_by_frozen_node_tag: Mapping[int, str]

    def __post_init__(self) -> None:
        if type(self.interface_key) is not FrozenGeneratedInterfaceKey:
            raise MixedSourceExecutionError("Frozen interface key is invalid")
        object.__setattr__(
            self,
            "semantic_tokens_by_frozen_node_tag",
            MappingProxyType(dict(self.semantic_tokens_by_frozen_node_tag)),
        )


@dataclass(frozen=True, slots=True)
class ComponentExecutionEvidence:
    component_id: str
    requested_topology: str
    applied_backend: str | None
    element_kind_counts: Mapping[str, int]
    materialized_fragment_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "component_id",
            _text(self.component_id, field_name="evidence component_id"),
        )
        object.__setattr__(
            self,
            "requested_topology",
            _text(
                self.requested_topology,
                field_name="evidence requested_topology",
            ),
        )
        if self.applied_backend is not None:
            object.__setattr__(
                self,
                "applied_backend",
                _text(self.applied_backend, field_name="evidence applied_backend"),
            )
        object.__setattr__(
            self,
            "element_kind_counts",
            MappingProxyType(dict(self.element_kind_counts)),
        )


@dataclass(frozen=True, slots=True)
class PendingExecutionDependency:
    component_id: str
    kind: PendingDependencyKind
    face_pair_ids: tuple[str, ...]
    detail: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "component_id",
            _text(self.component_id, field_name="pending component_id"),
        )
        if self.kind not in {
            "upstream_surface",
            "structured_sweep_backend",
            "structured_sweep_locked_section",
            "orthogonal_geometry_backend",
            "orthogonal_locked_boundary_chain",
            "orthogonal_locked_patch",
        }:
            raise MixedSourceExecutionError("pending dependency kind is invalid")
        object.__setattr__(self, "face_pair_ids", tuple(self.face_pair_ids))
        object.__setattr__(
            self, "detail", _text(self.detail, field_name="pending detail")
        )


@dataclass(frozen=True, slots=True)
class RoleFreeSourceExecutionPlan:
    authority_plan: NeutralSurfaceAuthorityPlan
    component_order: tuple[str, ...]
    incoming_face_pair_ids_by_component: Mapping[str, tuple[str, ...]]
    outgoing_face_pair_ids_by_component: Mapping[str, tuple[str, ...]]

    def __post_init__(self) -> None:
        for field_name in (
            "incoming_face_pair_ids_by_component",
            "outgoing_face_pair_ids_by_component",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )


@dataclass(frozen=True, slots=True)
class MixedSourceExecutionResult:
    plan: RoleFreeSourceExecutionPlan
    components_by_id: Mapping[str, MaterializedComponent]
    surface_patches_by_face_pair_id: Mapping[str, MaterializedSurfacePatch]
    interface_facet_sets_by_face_pair_id: Mapping[str, InterfaceFacetSet]
    frozen_interface_facet_sets: tuple[FrozenInterfaceFacetSet, ...]
    frozen_semantic_tokens_by_source_node_tag: Mapping[int, str]
    declared_seams: tuple[DeclaredSharedSeam, ...]
    component_evidence_by_id: Mapping[str, ComponentExecutionEvidence]
    pending_dependencies: tuple[PendingExecutionDependency, ...]
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    )

    def __post_init__(self) -> None:
        for field_name in (
            "components_by_id",
            "surface_patches_by_face_pair_id",
            "interface_facet_sets_by_face_pair_id",
            "frozen_semantic_tokens_by_source_node_tag",
            "component_evidence_by_id",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )
        try:
            tolerance = validate_interface_geometry_tolerance_mm(
                self.interface_geometry_tolerance_mm
            )
        except ValueError as error:
            raise MixedSourceExecutionError(str(error)) from error
        object.__setattr__(self, "interface_geometry_tolerance_mm", tolerance)

    @property
    def complete(self) -> bool:
        return not self.pending_dependencies

    @property
    def component_fragments(self) -> tuple[ComponentLocalMeshFragment, ...]:
        return tuple(
            fragment
            for component_id in sorted(self.components_by_id)
            for fragment in self.components_by_id[component_id].fragments_by_id.values()
        )

    @property
    def expected_complete_support_plane_interfaces(
        self,
    ) -> tuple[ExpectedCompleteSupportPlaneInterface, ...]:
        """Return complete, package-axis planar contacts for final audit.

        The authority patch is used only to identify the physical support
        plane. The complete-plane check applies only when both sides keep
        the same patch. Partial Orth occupancy uses the exact shared-facet
        declarations and unpaired-overlap audit instead.
        """

        return _expected_complete_support_plane_interfaces(self)


def _expected_complete_support_plane_interfaces(
    result: MixedSourceExecutionResult,
) -> tuple[ExpectedCompleteSupportPlaneInterface, ...]:
    tolerance = result.interface_geometry_tolerance_mm
    output: list[ExpectedCompleteSupportPlaneInterface] = []
    for authority in sorted(
        result.plan.authority_plan.authorities,
        key=lambda value: value.face_pair_id,
    ):
        if not all(
            coverage.covers_complete_side
            for coverage in authority.side_coverages
        ):
            continue
        patch = result.surface_patches_by_face_pair_id.get(
            authority.face_pair_id
        )
        if patch is None:
            if result.complete:
                raise MixedSourceExecutionError(
                    "complete execution is missing a materialized authority "
                    f"patch: face_pair_id={authority.face_pair_id!r}"
                )
            continue
        points = tuple(patch.node_coordinates_package_mm.values())
        actual = result.interface_facet_sets_by_face_pair_id.get(authority.face_pair_id)
        if not points or (actual is not None and len(actual.producer_facets) != len(patch.facets)):
            # Centre-filtered Orth contacts are subsets. Declared surviving
            # seams and the unpaired-overlap audit still verify actual contact.
            continue
        constant_axes = tuple(
            axis
            for axis in range(3)
            if max(point[axis] for point in points)
            - min(point[axis] for point in points)
            <= tolerance
        )
        is_orthogonal_staircase = (
            patch.contact_audit.contact_domain
            == MaterializedContactDomain.ORTHOGONAL_STAIRCASE.value
        )
        if len(constant_axes) != 1:
            if is_orthogonal_staircase:
                raise MixedSourceExecutionError(
                    "a complete Orth staircase contact must lie on exactly "
                    "one package-axis support plane; rotated or multi-height "
                    "complete staircase contacts are unsupported: "
                    f"face_pair_id={authority.face_pair_id!r}, "
                    f"constant_axes={constant_axes!r}"
                )
            continue
        axis = constant_axes[0]
        coordinate = math.fsum(point[axis] for point in points) / len(points)
        output.append(
            ExpectedCompleteSupportPlaneInterface(
                interface_key=authority.face_pair_id,
                first_fragment_key=authority.producer_fragment_id,
                second_fragment_key=authority.consumer_fragment_id,
                plane_axis=axis,
                plane_coordinate_mm=coordinate,
            )
        )
    return tuple(output)


def plan_role_free_source_execution(
    components: Mapping[str, CanonicalComponentGeometry],
    requirements: Mapping[str, ComponentMeshRequirement],
    authority_plan: NeutralSurfaceAuthorityPlan,
    *,
    priority_component_order: Sequence[str],
) -> RoleFreeSourceExecutionPlan:
    """Bind the preflight priority schedule to the surface-authority DAG."""

    component_ids = set(components)
    if set(requirements) != component_ids:
        raise MixedSourceExecutionError(
            "component geometry and mesh requirements must have identical IDs"
        )
    order = tuple(priority_component_order)
    if len(order) != len(component_ids) or set(order) != component_ids:
        raise MixedSourceExecutionError(
            "priority component order must contain every Component exactly once"
        )
    position = {component_id: index for index, component_id in enumerate(order)}
    incoming: dict[str, list[str]] = {value: [] for value in component_ids}
    outgoing: dict[str, list[str]] = {value: [] for value in component_ids}
    for authority in authority_plan.authorities:
        producer = authority.producer_component_id
        consumer = authority.consumer_component_id
        if producer not in component_ids or consumer not in component_ids:
            raise MixedSourceExecutionError(
                "surface authority references an unknown component"
            )
        outgoing[producer].append(authority.face_pair_id)
        incoming[consumer].append(authority.face_pair_id)
        if position[producer] >= position[consumer]:
            raise MixedSourceExecutionError(
                "surface authority reverses the preflight mesh-priority order"
            )
    if len(position) != len(order):
        raise MixedSourceExecutionError(
            "priority component order contains duplicate Components"
        )
    return RoleFreeSourceExecutionPlan(
        authority_plan,
        order,
        MappingProxyType(
            {key: tuple(sorted(values)) for key, values in sorted(incoming.items())}
        ),
        MappingProxyType(
            {key: tuple(sorted(values)) for key, values in sorted(outgoing.items())}
        ),
    )


def build_role_free_source_execution_plan(
    context: MixedExecutionContext,
) -> RoleFreeSourceExecutionPlan:
    if type(context) is not MixedExecutionContext:
        raise MixedSourceExecutionError("context must be a MixedExecutionContext")
    lowering = context.lowering
    authorities = plan_neutral_surface_authorities(
        lowering.canonical_components_by_global_id,
        context.adjacency_execution,
        lowering.generated_interface_continuity_plan,
        producer_component_id_by_face_pair_id=(
            context.mesh_ordering.generated_surface_producer_by_face_pair_id
        ),
        negotiated_target_edge_mm_by_face_pair_id={
            constraint.face_pair_id: constraint.negotiated_target_edge_mm
            for constraint in context.mesh_ordering.constraints
            if constraint.face_pair_id is not None
        },
    )
    return plan_role_free_source_execution(
        lowering.canonical_components_by_global_id,
        lowering.component_mesh_requirements,
        authorities,
        priority_component_order=(
            context.mesh_ordering.generated_component_order
        ),
    )


def _rotation_matrix(
    placement: CanonicalRigidPlacement,
) -> tuple[Point3D, Point3D, Point3D]:
    rx, ry, rz = (math.radians(value) for value in placement.rotation_deg_xyz)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    rotate_x = (
        (1.0, 0.0, 0.0),
        (0.0, cx, -sx),
        (0.0, sx, cx),
    )
    rotate_y = (
        (cy, 0.0, sy),
        (0.0, 1.0, 0.0),
        (-sy, 0.0, cy),
    )
    rotate_z = (
        (cz, -sz, 0.0),
        (sz, cz, 0.0),
        (0.0, 0.0, 1.0),
    )

    def multiply(
        left: Sequence[Sequence[float]],
        right: Sequence[Sequence[float]],
    ) -> tuple[Point3D, Point3D, Point3D]:
        return tuple(
            tuple(
                math.fsum(
                    left[row][inner] * right[inner][column]
                    for inner in range(3)
                )
                for column in range(3)
            )
            for row in range(3)
        )  # type: ignore[return-value]

    return multiply(rotate_z, multiply(rotate_y, rotate_x))


def _package_to_local(
    point: Point3D,
    placement: CanonicalRigidPlacement,
) -> Point3D:
    pivot = placement.pivot_xyz_mm
    translated = tuple(
        point[axis] - placement.translation_xyz_mm[axis] - pivot[axis]
        for axis in range(3)
    )
    rotation = _rotation_matrix(placement)
    return tuple(
        pivot[axis]
        + math.fsum(
            rotation[source_axis][axis] * translated[source_axis]
            for source_axis in range(3)
        )
        for axis in range(3)
    )  # type: ignore[return-value]


def _local_to_package(
    point: Point3D,
    placement: CanonicalRigidPlacement,
) -> Point3D:
    pivot = placement.pivot_xyz_mm
    relative = tuple(point[index] - pivot[index] for index in range(3))
    rotation = _rotation_matrix(placement)
    return tuple(
        placement.translation_xyz_mm[row]
        + pivot[row]
        + math.fsum(
            rotation[row][column] * relative[column]
            for column in range(3)
        )
        for row in range(3)
    )  # type: ignore[return-value]


def _shell_side(fragment: CanonicalGeometryFragment, side: str) -> str:
    if side.startswith("orth:"):
        return side
    root = fragment.root
    if type(root) is CanonicalBox:
        return {"z_min": "bottom", "z_max": "top"}.get(side, side)
    if type(root) is CanonicalRectangularFrameExtrusion:
        if side == "z_min":
            return "bottom"
        if side == "z_max":
            return "top"
        if side.startswith("opening_"):
            return "inner_" + side[len("opening_") :]
        return side
    if type(root) is CanonicalRectangularUnderfillFillet:
        return {"z_min": "base", "z_max": "cap"}.get(side, side)
    raise MixedSourceExecutionError(
        "source executor supports canonical Box, Frame and rectangular fillet"
    )


class _Locks:
    def __init__(self, fragment: CanonicalGeometryFragment) -> None:
        self.fragment = fragment
        self.coordinates: dict[int, Point3D] = {}
        self.tokens: dict[int, str] = {}
        self.facets_by_side: dict[str, list[tuple[int, ...]]] = defaultdict(list)
        self.source_topology_by_side_facet: dict[
            str, dict[tuple[int, ...], str]
        ] = defaultdict(dict)
        self._node_by_key: dict[tuple[float, float, float], int] = {}

    def semantic_token_at_local_coordinate(
        self,
        point: Point3D,
    ) -> str | None:
        """Return an existing immutable node identity at a local coordinate."""

        key = tuple(round(value, 12) for value in point)
        node_id = self._node_by_key.get(key)
        return None if node_id is None else self.tokens[node_id]

    def add(
        self,
        package_coordinates: Mapping[int, Point3D],
        facets: Sequence[Sequence[int]],
        tokens: Mapping[int, str],
        *,
        side_name: str,
        source_topology: str,
    ) -> None:
        local_by_source: dict[int, int] = {}
        for source_node in sorted({node for facet in facets for node in facet}):
            local = _package_to_local(
                package_coordinates[source_node], self.fragment.placement
            )
            key = tuple(round(value, 12) for value in local)
            token = tokens[source_node]
            existing = self._node_by_key.get(key)
            if existing is not None:
                if self.tokens[existing] != token:
                    raise MixedSourceExecutionError(
                        "coincident locked nodes have different semantic identity"
                    )
                local_by_source[source_node] = existing
                continue
            node_id = len(self.coordinates) + 1
            self._node_by_key[key] = node_id
            self.coordinates[node_id] = local
            self.tokens[node_id] = token
            local_by_source[source_node] = node_id
        side = _shell_side(self.fragment, side_name)
        known = {
            tuple(sorted(value)) for value in self.facets_by_side[side]
        }
        for facet in facets:
            mapped = tuple(local_by_source[node] for node in facet)
            key = tuple(sorted(mapped))
            previous_topology = self.source_topology_by_side_facet[side].get(
                key
            )
            self.source_topology_by_side_facet[side][key] = (
                source_topology
                if previous_topology in {None, source_topology}
                else "mixed"
            )
            if key in known:
                continue
            known.add(key)
            self.facets_by_side[side].append(mapped)

    def side_is_exclusively_from(
        self,
        side_name: str,
        source_topology: str,
    ) -> bool:
        facets = self.facets_by_side.get(side_name, ())
        origins = self.source_topology_by_side_facet.get(side_name, {})
        keys = {tuple(sorted(facet)) for facet in facets}
        return bool(keys) and set(origins) == keys and all(
            origins[key] == source_topology for key in keys
        )


def _add_frozen_trace_locks(
    context: MixedExecutionContext,
    component_id: str,
    locks_by_fragment: Mapping[str, _Locks],
) -> None:
    lowering = context.lowering
    for key, match in lowering.frozen_interface_matches.items():
        if (
            key.generated_component_global_id != component_id
            or match.mode is not InterfaceMatchMode.PRESERVE_INTERFACE_TRACE
        ):
            continue
        for patch in context.frozen_patches_by_interface[key]:
            locks = locks_by_fragment[patch.target_fragment_id]
            tokens = {
                node: frozen_node_semantic_token(node)
                for node in patch.node_coordinates
            }
            locks.add(
                patch.node_coordinates,
                tuple(facet.source_node_tags for facet in patch.facets),
                tokens,
                side_name=patch.side_name,
                source_topology="frozen",
            )


def _add_incoming_surface_locks(
    context: MixedExecutionContext,
    plan: RoleFreeSourceExecutionPlan,
    component_id: str,
    patches: Mapping[str, MaterializedSurfacePatch],
    locks_by_fragment: Mapping[str, _Locks],
) -> tuple[str, ...]:
    missing: list[str] = []
    for face_pair_id in plan.incoming_face_pair_ids_by_component[component_id]:
        patch = patches.get(face_pair_id)
        if patch is None:
            missing.append(face_pair_id)
            continue
        locks_by_fragment[patch.consumer_side.fragment_id].add(
            patch.node_coordinates_package_mm,
            patch.facets,
            patch.semantic_tokens_by_node_id,
            side_name=patch.consumer_side.side_name,
            source_topology=(
                context.lowering.component_mesh_requirements[
                    plan.authority_plan.authority_by_face_pair_id[
                        face_pair_id
                    ].producer_component_id
                ].volume_topology
            ),
        )
    return tuple(missing)


def _add_hybrid_outgoing_tensor_locks(
    context: MixedExecutionContext,
    component_id: str,
    locks_by_fragment: Mapping[str, _Locks],
    *,
    verbose: bool,
) -> None:
    """Ask Gmsh for producer-owned tensor QUADs before hybrid volume fill."""

    grouped: dict[str, list[OrderedSurfaceConstraint]] = defaultdict(list)
    for constraint in context.mesh_ordering.constraints:
        if (
            constraint.source_kind == "generated"
            and constraint.producer_component_id == component_id
            and constraint.producer_fragment_id is not None
            and constraint.required_facet_policy
            in {
                "axis_orthogonal_rectangular_quad",
                "cartesian_tensor_quad",
            }
        ):
            grouped[constraint.producer_fragment_id].append(constraint)
    for fragment_id, raw_constraints in grouped.items():
        constraints = tuple(raw_constraints)
        locks = locks_by_fragment[fragment_id]
        # The producer's negotiated target supplies free axes. Shared-edge
        # schedules below override it wherever inherited nodes are authoritative.
        tensor_target = min(
            value.negotiated_target_edge_mm for value in constraints
        )
        for constraint in constraints:
            rectangle = canonical_side_cartesian_rectangle(
                locks.fragment,
                constraint.producer_side_name,
            )
            if rectangle is None:
                raise MixedSourceExecutionError(
                    "conformal_hybrid cannot produce a Cartesian tensor on "
                    f"non-rectangular side {constraint.producer_side_name!r}"
                )
            axis_overrides = {}
            rectangle_origin, u_vector, v_vector = rectangle
            for edge in context.mesh_ordering.shared_edge_authorities:
                if constraint.surface_id not in edge.incident_surface_ids:
                    continue
                local_points = tuple(_package_to_local(point, locks.fragment.placement)
                                     for point in edge.partition_points_package_mm)
                for key, vector in (("u_fractions", u_vector), ("v_fractions", v_vector)):
                    axis = next(a for a in range(3) if abs(vector[a])>1.e-12)
                    fractions = tuple(sorted({round((p[axis]-rectangle_origin[axis])/vector[axis], 12)
                                              for p in local_points}))
                    if len(fractions)>1 and abs(fractions[0])<1.e-10 and abs(fractions[-1]-1)<1.e-10:
                        previous = axis_overrides.setdefault(key, fractions)
                        if previous != fractions:
                            raise MixedSourceExecutionError("inherited opposite edges disagree on the tensor partition")
            try:
                surface = generate_gmsh_cartesian_tensor_rectangle(
                    *rectangle,
                    target_edge_mm=tensor_target,
                    **axis_overrides,
                    verbose=verbose,
                )
            except GmshCartesianTensorSurfaceError as error:
                raise MixedSourceExecutionError(
                    "conformal_hybrid failed to generate its required Gmsh "
                    f"Cartesian contact on {constraint.producer_side_name!r}: "
                    f"{error}"
                ) from error
            package_coordinates = {
                node: _local_to_package(point, locks.fragment.placement)
                for node, point in surface.node_coordinates.items()
            }
            tokens: dict[int, str] = {}
            for node, point in surface.node_coordinates.items():
                key = tuple(round(value, 12) for value in point)
                existing_token = locks.semantic_token_at_local_coordinate(point)
                if existing_token is not None:
                    tokens[node] = existing_token
                    continue
                coordinate_token = ":".join(
                    (0.0 if value == 0.0 else value).hex()
                    for value in key
                )
                tokens[node] = (
                    f"generated:tensor:{component_id}:{fragment_id}:"
                    f"{coordinate_token}"
                )
            locks.add(
                package_coordinates,
                surface.facets,
                tokens,
                side_name=constraint.producer_side_name,
                source_topology="conformal_hybrid",
            )


def _hybrid_conformal_outgoing_target_edge_mm(
    context: MixedExecutionContext,
    component_id: str,
    fragment_id: str,
) -> float | None:
    targets = tuple(
        constraint.negotiated_target_edge_mm
        for constraint in context.mesh_ordering.constraints
        if constraint.source_kind == "generated"
        and constraint.producer_component_id == component_id
        and constraint.producer_fragment_id == fragment_id
        and constraint.required_facet_policy == "conformal_tri_or_quad"
    )
    return min(targets) if targets else None


def _feature_resolved_hybrid_requirement(
    fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
) -> ComponentMeshRequirement:
    """Cap Gmsh's target by the body's smallest positive analytic feature.

    ``target_edge_mm`` is a target, not permission to ignore a thinner body.
    Applying the same geometry-only cap to every canonical fragment prevents
    flat TETs in thin Boxes/Frames without introducing any package role or
    manufacturing three-dimensional connectivity outside Gmsh.
    """

    root = fragment.root
    if type(root) is CanonicalBox:
        features = root.size_xyz_mm
    elif type(root) is CanonicalRectangularFrameExtrusion:
        outer_x, outer_y = root.outer_size_xy_mm
        offset_x, offset_y = root.opening_offset_xy_mm
        opening_x, opening_y = root.opening_size_xy_mm
        features = (
            root.height_mm,
            offset_x,
            outer_x - offset_x - opening_x,
            offset_y,
            outer_y - offset_y - opening_y,
        )
    elif type(root) is CanonicalRectangularUnderfillFillet:
        features = (
            root.wall_height_mm,
            *(root.side_widths_mm or (root.toe_width_mm,)),
            *(root.top_widths_mm or (root.top_width_mm,)),
        )
    else:  # materializer performs the authoritative type rejection
        return requirement
    positive = tuple(value for value in features if value > 0.0)
    if not positive:
        return requirement
    resolved = min(requirement.target_edge_mm, min(positive))
    if resolved == requirement.target_edge_mm:
        return requirement
    return replace(requirement, target_edge_mm=resolved)


def _negotiated_outgoing_surface_target_edge_mm(
    plan: RoleFreeSourceExecutionPlan,
    component_id: str,
    *,
    fragment_id: str | None = None,
) -> float | None:
    """Return the finest target of the actual surfaces owned by one producer.

    This is deliberately not a replacement Component requirement.  The local
    target remains the far-field size and the Component keeps its own
    transition distance.  A fragment filter prevents an unrelated fragment in
    the same Component from inheriting another fragment's surface contract.
    """

    outgoing = tuple(
        face_pair_id
        for face_pair_id in plan.outgoing_face_pair_ids_by_component[component_id]
        if fragment_id is None
        or plan.authority_plan.authority_by_face_pair_id[
            face_pair_id
        ].producer_fragment_id
        == fragment_id
    )
    if not outgoing:
        return None
    return min(
        (
            plan.authority_plan.authority_by_face_pair_id[
                face_pair_id
            ].negotiated_target_edge_mm
            for face_pair_id in outgoing
        ),
    )


def _gmsh_surface_characteristic_size_mm(target_edge_mm: float) -> float:
    """Translate a hard surface-edge ceiling to Gmsh characteristic length.

    Gmsh's ``MeshSizeMax`` bounds its characteristic size; it is not a hard
    upper bound on every TRI3 edge.  A triangle cut from one size-bounded cell
    can have a diagonal up to ``sqrt(2) * h``.  Shared-surface authorities
    therefore receive the negotiated maximum edge unchanged at planning level,
    while their non-Cartesian Gmsh producer uses ``h = edge / sqrt(2)``.  The
    reopened numbered mesh remains the authority: it rejects any backend result
    whose real ordered-facet edge still exceeds the negotiated value.

    The returned value is a producer-surface near size, not a Component target.
    """

    return target_edge_mm / math.sqrt(2.0)


def _cross_section_producer_requirement(
    requirement: ComponentMeshRequirement,
    surface_target_edge_mm: float | None,
    *,
    gmsh_triangular_surface: bool,
) -> ComponentMeshRequirement:
    """Derive a topology-limited cross-section size without changing Source.

    Sweep and Cartesian backends cannot transition within a producer section:
    the complete inherited section must retain its finest shared-surface size.
    This backend-only DTO keeps the original transition distance; reporting and
    every downstream policy continue to use the unmodified local requirement.
    """

    if surface_target_edge_mm is None:
        return requirement
    backend_target = (
        _gmsh_surface_characteristic_size_mm(surface_target_edge_mm)
        if gmsh_triangular_surface
        else surface_target_edge_mm
    )
    resolved = min(requirement.target_edge_mm, backend_target)
    if resolved == requirement.target_edge_mm:
        return requirement
    return replace(requirement, target_edge_mm=resolved)


def _orthogonal_strategy_with_surface_caps(
    plan: RoleFreeSourceExecutionPlan,
    component_id: str,
    fragment: CanonicalGeometryFragment,
    strategy: OrthogonalHexMeshStrategy,
) -> OrthogonalHexMeshStrategy:
    """Keep free-direction requests; incoming traces are applied per axis."""

    # The source values are fallback sizes, not shared-face ceilings. Exact
    # inherited coordinates are supplied to the backend separately per axis.
    return strategy


def _requires_orthogonal_outgoing_end(
    context: MixedExecutionContext,
    plan: RoleFreeSourceExecutionPlan,
    component_id: str,
    fragment: CanonicalGeometryFragment,
    *,
    sweep_direction: ComponentLocalDirection | None = None,
) -> bool:
    """Return whether an actual outgoing end contract requires QUAD output."""

    if sweep_direction is None:
        end_sides = {"bottom", "top"}
    else:
        end_sides = {
            ComponentLocalDirection.POSITIVE_X: {"x_min", "x_max"},
            ComponentLocalDirection.NEGATIVE_X: {"x_min", "x_max"},
            ComponentLocalDirection.POSITIVE_Y: {"y_min", "y_max"},
            ComponentLocalDirection.NEGATIVE_Y: {"y_min", "y_max"},
            ComponentLocalDirection.POSITIVE_Z: {"bottom", "top"},
            ComponentLocalDirection.NEGATIVE_Z: {"bottom", "top"},
        }[sweep_direction]

    for face_pair_id in plan.outgoing_face_pair_ids_by_component[component_id]:
        authority = plan.authority_plan.authority_by_face_pair_id[face_pair_id]
        if (
            authority.producer_fragment_id == fragment.fragment_id
            and _shell_side(fragment, authority.producer_side_name)
            in end_sides
            and context.lowering.component_mesh_requirements[
                authority.consumer_component_id
            ].volume_topology
            == "orthogonal_hex"
        ):
            return True
    return False


def _orthogonal_outgoing_end_contact_regions(context, plan, component_id, fragment):
    """Scope a partial Frame end contract to its actual outer collar.

    Full end contracts keep the existing all-orthogonal requirement. Other
    partial shapes also keep that conservative path until their planar
    completion has a geometric proof in the sweep materializer.
    """
    regions = []
    for face_id in plan.outgoing_face_pair_ids_by_component[component_id]:
        authority = plan.authority_plan.authority_by_face_pair_id[face_id]
        if (authority.producer_fragment_id != fragment.fragment_id
            or _shell_side(fragment, authority.producer_side_name) not in {"bottom", "top"}
            or context.lowering.component_mesh_requirements[
                authority.consumer_component_id].volume_topology != "orthogonal_hex"):
            continue
        coverage = next(v for v in authority.side_coverages
                        if v.component_id == component_id and v.fragment_id == fragment.fragment_id)
        target = context.lowering.canonical_fragments_by_global_id[authority.consumer_fragment_id]
        if (coverage.covers_complete_side
            or type(target.root) is not CanonicalRectangularFrameExtrusion
            or authority.consumer_side_name not in {"z_min", "z_max"}):
            return ()
        root = target.root
        x, y, z = root.outer_origin_xyz_mm
        if authority.consumer_side_name == "z_max":
            z += root.height_mm
        loops = []
        for ox, oy, sx, sy in (
            (x, y, *root.outer_size_xy_mm),
            (x + root.opening_offset_xy_mm[0], y + root.opening_offset_xy_mm[1],
             *root.opening_size_xy_mm),
        ):
            loops.append(tuple(_local_to_package(p, target.placement) for p in (
                (ox, oy, z), (ox+sx, oy, z), (ox+sx, oy+sy, z), (ox, oy+sy, z))))
        regions.append(tuple(loops))
    return tuple(regions)


def _materialize_hybrid(
    context: MixedExecutionContext,
    plan: RoleFreeSourceExecutionPlan,
    component_id: str,
    patches: Mapping[str, MaterializedSurfacePatch],
    *,
    verbose: bool,
) -> MaterializedComponent:
    lowering = context.lowering
    component = lowering.canonical_components_by_global_id[component_id]
    requirement = lowering.component_mesh_requirements[component_id]
    locks_by_fragment = {
        fragment.fragment_id: _Locks(fragment) for fragment in component.fragments
    }
    _add_frozen_trace_locks(context, component_id, locks_by_fragment)
    missing = _add_incoming_surface_locks(
        context, plan, component_id, patches, locks_by_fragment
    )
    if missing:  # guarded by the caller; keep the materializer fail-closed
        raise MixedSourceExecutionError(
            "conformal component is missing upstream surface locks"
        )
    forced_partial_sides_by_fragment: dict[str, set[str]] = defaultdict(set)
    for face_pair_id in plan.incoming_face_pair_ids_by_component[component_id]:
        patch = patches[face_pair_id]
        authority = plan.authority_plan.authority_by_face_pair_id[face_pair_id]
        consumer_coverage = next(
            value
            for value in authority.side_coverages
            if value.component_id == component_id
            and value.fragment_id == patch.consumer_side.fragment_id
        )
        consumer_fragment = locks_by_fragment[
            patch.consumer_side.fragment_id
        ].fragment
        # UF annulus reconstruction may promote a closed locked loop to the
        # complete base/cap geometry authority.  That is exactly the required
        # behavior when an Orth producer supplied its complete materialized
        # endpoint: the consumer must use the Orth staircase itself as its
        # endpoint geometry, not imprint it onto a second analytic surface.
        # Keep only genuinely partial canonical contacts as imprints.
        # Box/Frame shells always treat incoming patches as imprints and need
        # no override.
        if (
            type(consumer_fragment.root)
            is CanonicalRectangularUnderfillFillet
            and not consumer_coverage.covers_complete_side
        ):
            forced_partial_sides_by_fragment[
                patch.consumer_side.fragment_id
            ].add(
                _shell_side(
                    consumer_fragment,
                    patch.consumer_side.side_name,
                )
            )
    _add_hybrid_outgoing_tensor_locks(
        context,
        component_id,
        locks_by_fragment,
        verbose=verbose,
    )
    fragments: dict[str, ComponentLocalMeshFragment] = {}
    boundary: dict[FragmentSideKey, tuple[tuple[int, ...], ...]] = {}
    locked: dict[FragmentSideKey, tuple[tuple[int, ...], ...]] = {}
    backend_evidence: dict[str, Mapping[str, object]] = {}
    for fragment in component.fragments:
        values = locks_by_fragment[fragment.fragment_id]
        materializer_requirement = _feature_resolved_hybrid_requirement(
            fragment,
            requirement,
        )
        hybrid_strategy = lowering.component_mesh_controls_by_global_id[component_id].strategy
        negotiated_surface_target = (
            _hybrid_conformal_outgoing_target_edge_mm(
                context,
                component_id,
                fragment.fragment_id,
            )
        )
        surface_target_size = (
            None
            if negotiated_surface_target is None
            else min(
                materializer_requirement.target_edge_mm,
                _gmsh_surface_characteristic_size_mm(
                    negotiated_surface_target
                ),
            )
        )
        try:
            result: ConformalHybridComponentMesh = (
                materialize_conformal_hybrid_component(
                    fragment,
                    values.coordinates,
                    values.facets_by_side,
                    materializer_requirement,
                    material_name=component.material_name,
                    fragment_key=fragment.fragment_id,
                    semantic_tokens_by_locked_node_id=values.tokens,
                    surface_target_size_mm=(surface_target_size if values.facets_by_side or surface_target_size is not None
                        else hybrid_strategy.surface_size_mm),
                    contact_partition_loops=tuple(
                        tuple(_package_to_local(p, fragment.placement) for p in loop)
                        for loop in _partial_contact_boundary_loops(context, plan, component_id, fragment)
                    ),
                    orthogonal_hex_locked_base=(
                        values.side_is_exclusively_from(
                            "base", "orthogonal_hex"
                        )
                    ),
                    forced_partial_locked_sides=tuple(
                        sorted(
                            forced_partial_sides_by_fragment.get(
                                fragment.fragment_id,
                                (),
                            )
                        )
                    ),
                    interface_geometry_tolerance_mm=(
                        context.interface_geometry_tolerance_mm
                    ),
                    verbose=verbose,
                )
            )
            result_fragment = result.component_fragment
            result_boundary = result.boundary_facets_by_geometric_side
            result_locked = result.locked_facets_by_geometric_side
            backend_evidence[fragment.fragment_id] = result.backend_evidence
        except Exception as native_error:
            # Whole-body extrusion is a last resort after applicable TET
            # candidates fail. Preserve exportability, but explicitly report
            # that the requested TET interior/coarsening was not achieved.
            if type(fragment.root) not in {
                CanonicalBox,
                CanonicalRectangularFrameExtrusion,
            }:
                raise MixedSourceExecutionError(
                    f"conformal_hybrid Component {component_id!r} fragment "
                    f"{fragment.fragment_id!r} failed: {native_error}"
                ) from native_error
            locked_facets_by_side = {
                side: tuple(facets)
                for side, facets in values.facets_by_side.items()
                if facets
            }
            locked_package_nodes = (
                {
                    node: _local_to_package(
                        values.coordinates[node], fragment.placement
                    )
                    for node in sorted(values.coordinates)
                }
                if locked_facets_by_side
                else None
            )
            locked_tokens = (
                {node: values.tokens[node] for node in sorted(values.tokens)}
                if locked_facets_by_side
                else None
            )
            require_orthogonal_end_sections = (
                _requires_orthogonal_outgoing_end(
                    context,
                    plan,
                    component_id,
                    fragment,
                )
            )
            hybrid_adapter_direction = (
                ComponentLocalDirection.NEGATIVE_Z
                if "top" in locked_facets_by_side
                and "bottom" not in locked_facets_by_side
                else ComponentLocalDirection.POSITIVE_Z
            )
            adapter_requirement = replace(
                materializer_requirement,
                volume_topology="structured_sweep",
            )
            try:
                adapter = materialize_structured_sweep_component(
                    fragment,
                    None,
                    None,
                    adapter_requirement,
                    sweep_direction=hybrid_adapter_direction,
                    material_name=component.material_name,
                    fragment_key=fragment.fragment_id,
                    provenance=(
                        "gmsh_conformal_hybrid_structured_sweep_adapter"
                    ),
                    contact_partition_loops_package_mm=_partial_contact_boundary_loops(context, plan, component_id, fragment),
                    locked_boundary_node_coordinates_package_mm=(
                        locked_package_nodes
                    ),
                    locked_boundary_facets_by_geometric_side=(
                        locked_facets_by_side
                        if locked_facets_by_side
                        else None
                    ),
                    semantic_tokens_by_locked_node_id=locked_tokens,
                    require_orthogonal_end_sections=(
                        require_orthogonal_end_sections
                    ),
                    allow_partial_lateral_locks=True,
                    interface_geometry_tolerance_mm=(
                        context.interface_geometry_tolerance_mm
                    ),
                    verbose=verbose,
                )
            except StructuredSweepMaterializationError as adapter_error:
                raise MixedSourceExecutionError(
                    f"conformal_hybrid Component {component_id!r} fragment "
                    f"{fragment.fragment_id!r} failed: {native_error}; "
                    "Gmsh structured Hybrid adapter was not executable: "
                    f"{adapter_error}"
                ) from native_error
            result_fragment = adapter.component_fragment
            result_boundary = adapter.boundary_facets_by_geometric_side
            result_locked = adapter.locked_facets_by_geometric_side
            backend_evidence[fragment.fragment_id] = MappingProxyType(
                {
                    "applied_volume_path": (
                        "gmsh_conformal_hybrid_structured_sweep_adapter"
                    ),
                    "gmsh_owns_all_volume_connectivity": True,
                    "partial_lateral_locks_verified": adapter.partial_lateral_locks_verified,
                    "native_candidate_rejection": str(native_error),
                    "tet_preferred": True,
                    "sweep_fallback_used": True,
                    "strategy_warnings": [{
                        "code": "hybrid_sweep_fallback", "severity": "warning", "export_allowed": True,
                        "message": "Hybrid 的 TET 路径未通过检查，已回退为 Sweep（HEX/WEDGE）；未实现 TET 内部加粗。允许导出，请检查尺寸与接口约束。",
                        "tet_candidate_rejection": str(native_error),
                    }],
                    "source_side_name": adapter.source_side_name,
                    "layer_thicknesses_mm": adapter.layer_thicknesses_mm,
                    "source_facet_preserved_count": adapter.source_facet_preserved_count,
                    "locked_facet_counts_by_side": {
                        side: len(facets)
                        for side, facets in adapter.locked_facets_by_geometric_side.items()
                    },
                    "analytic_volume_mm3": adapter.analytic_volume_mm3,
                    "element_volume_mm3": adapter.element_volume_mm3,
                    "relative_volume_error": adapter.relative_volume_error,
                    "minimum_sicn": adapter.minimum_sicn,
                    "minimum_sige": adapter.minimum_sige,
                    "minimum_scaled_jacobian": adapter.minimum_scaled_jacobian,
                }
            )
        fragments[fragment.fragment_id] = result_fragment
        boundary.update(
            {
                (fragment.fragment_id, side): facets
                for side, facets in result_boundary.items()
            }
        )
        locked.update(
            {
                (fragment.fragment_id, side): facets
                for side, facets in result_locked.items()
            }
        )
    return MaterializedComponent(
        component_id,
        "conformal_hybrid",
        fragments,
        boundary,
        locked,
        backend_evidence_by_fragment_id=backend_evidence,
    )


def _materialize_sweep(
    context: MixedExecutionContext,
    plan: RoleFreeSourceExecutionPlan,
    component_id: str,
    patches: Mapping[str, MaterializedSurfacePatch],
    *,
    verbose: bool,
) -> MaterializedComponent:
    lowering = context.lowering
    component = lowering.canonical_components_by_global_id[component_id]
    requirement = lowering.component_mesh_requirements[component_id]
    control = lowering.component_mesh_controls_by_global_id[component_id]
    if type(control.strategy) is not StructuredSweepMeshStrategy:
        raise MixedSourceExecutionError(
            "structured sweep executor requires an exact "
            "StructuredSweepMeshStrategy"
        )
    sweep_direction = control.strategy.direction
    locks_by_fragment = {
        fragment.fragment_id: _Locks(fragment) for fragment in component.fragments
    }
    _add_frozen_trace_locks(context, component_id, locks_by_fragment)
    missing = _add_incoming_surface_locks(
        context, plan, component_id, patches, locks_by_fragment
    )
    if missing:
        raise MixedSourceExecutionError(
            "structured sweep is missing an upstream inherited section"
        )

    fragments: dict[str, ComponentLocalMeshFragment] = {}
    boundary: dict[FragmentSideKey, tuple[tuple[int, ...], ...]] = {}
    locked: dict[FragmentSideKey, tuple[tuple[int, ...], ...]] = {}
    backend_evidence: dict[str, Mapping[str, object]] = {}
    for fragment in component.fragments:
        backend_requirement = _cross_section_producer_requirement(
            requirement,
            _negotiated_outgoing_surface_target_edge_mm(
                plan,
                component_id,
                fragment_id=fragment.fragment_id,
            ),
            gmsh_triangular_surface=True,
        )
        if type(fragment.root) not in {
            CanonicalBox,
            CanonicalRectangularFrameExtrusion,
        }:
            raise MixedSourceExecutionError(
                "structured_sweep currently supports canonical Box and Frame "
                "extrusion"
            )
        values = locks_by_fragment[fragment.fragment_id]
        locked_facets_by_side = {
            side: tuple(facets)
            for side, facets in values.facets_by_side.items()
            if facets
        }
        locked_package_nodes = (
            {
                node: _local_to_package(
                    values.coordinates[node], fragment.placement
                )
                for node in sorted(values.coordinates)
            }
            if locked_facets_by_side
            else None
        )
        locked_tokens = (
            {node: values.tokens[node] for node in sorted(values.tokens)}
            if locked_facets_by_side
            else None
        )
        require_orthogonal_end_sections = _requires_orthogonal_outgoing_end(
            context,
            plan,
            component_id,
            fragment,
            sweep_direction=sweep_direction,
        )
        orthogonal_end_regions = (
            _orthogonal_outgoing_end_contact_regions(context, plan, component_id, fragment)
            if require_orthogonal_end_sections else ()
        )
        try:
            result = materialize_structured_sweep_component(
                fragment,
                None,
                None,
                backend_requirement,
                sweep_direction=sweep_direction,
                sweep_strategy=replace(control.strategy, layer_size_mm=(
                    control.strategy.layer_size_mm or control.target_edge_mm)),
                material_name=component.material_name,
                fragment_key=fragment.fragment_id,
                contact_partition_loops_package_mm=_partial_contact_boundary_loops(context, plan, component_id, fragment),
                locked_boundary_node_coordinates_package_mm=(
                    locked_package_nodes
                ),
                locked_boundary_facets_by_geometric_side=(
                    locked_facets_by_side if locked_facets_by_side else None
                ),
                semantic_tokens_by_locked_node_id=locked_tokens,
                require_orthogonal_end_sections=(
                    require_orthogonal_end_sections
                ),
                orthogonal_end_contact_regions_package_mm=orthogonal_end_regions,
                allow_partial_lateral_locks=True,
                interface_geometry_tolerance_mm=context.interface_geometry_tolerance_mm,
                verbose=verbose,
            )
        except StructuredSweepMaterializationError as error:
            raise MixedSourceExecutionError(str(error)) from error
        fragments[fragment.fragment_id] = result.component_fragment
        backend_evidence[fragment.fragment_id] = {
            "applied_volume_path": "gmsh_structured_sweep",
            "gmsh_owns_all_volume_connectivity": result.gmsh_owns_all_volume_connectivity,
            "partial_lateral_locks_verified": result.partial_lateral_locks_verified,
            "layer_count": result.layer_count,
            "layer_thicknesses_mm": result.layer_thicknesses_mm,
            "orthogonal_end_contact_region_count": len(orthogonal_end_regions),
        }
        boundary.update(
            {
                (fragment.fragment_id, side): facets
                for side, facets in result.boundary_facets_by_geometric_side.items()
            }
        )
        locked.update(
            {
                (fragment.fragment_id, side): facets
                for side, facets in result.locked_facets_by_geometric_side.items()
            }
        )
    return MaterializedComponent(
        component_id,
        "structured_sweep",
        fragments,
        boundary,
        locked,
        backend_evidence_by_fragment_id=backend_evidence,
    )


def _orthogonal_side(side: str) -> OrthogonalBoundarySide:
    aliases = {
        "z_min": OrthogonalBoundarySide.BASE,
        "base": OrthogonalBoundarySide.BASE,
        "z_max": OrthogonalBoundarySide.CAP,
        "cap": OrthogonalBoundarySide.CAP,
        "die_x_min": OrthogonalBoundarySide.DIE_X_MIN,
        "die_x_max": OrthogonalBoundarySide.DIE_X_MAX,
        "die_y_min": OrthogonalBoundarySide.DIE_Y_MIN,
        "die_y_max": OrthogonalBoundarySide.DIE_Y_MAX,
    }
    try:
        return aliases[side]
    except KeyError as error:
        raise MixedSourceExecutionError(
            f"orthogonal fillet has no canonical side {side!r}"
        ) from error


def _boundary_edge_coordinates(
    facets: Sequence[Sequence[int]],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[Point3D, Point3D], ...]:
    counts: Counter[tuple[int, int]] = Counter()
    oriented: dict[tuple[int, int], tuple[int, int]] = {}
    for facet in facets:
        for first, second in zip(facet, (*facet[1:], facet[0])):
            key = tuple(sorted((first, second)))
            counts[key] += 1
            oriented.setdefault(key, (first, second))
    return tuple(
        (coordinates[oriented[key][0]], coordinates[oriented[key][1]])
        for key, count in counts.items()
        if count == 1
    )


def _chain_side(
    root: CanonicalRectangularUnderfillFillet,
    first: Point3D,
    second: Point3D,
    tolerance: float,
) -> OrthogonalBoundarySide | None:
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    z0 = root.base_z_mm
    if abs(first[2] - z0) > tolerance or abs(second[2] - z0) > tolerance:
        return None
    values = (
        (OrthogonalBoundarySide.DIE_X_MIN, 0, x0, 1, (y0, y1)),
        (OrthogonalBoundarySide.DIE_X_MAX, 0, x1, 1, (y0, y1)),
        (OrthogonalBoundarySide.DIE_Y_MIN, 1, y0, 0, (x0, x1)),
        (OrthogonalBoundarySide.DIE_Y_MAX, 1, y1, 0, (x0, x1)),
    )
    for side, axis, coordinate, tangent, bounds in values:
        if (
            abs(first[axis] - coordinate) <= tolerance
            and abs(second[axis] - coordinate) <= tolerance
            and bounds[0] - tolerance <= first[tangent] <= bounds[1] + tolerance
            and bounds[0] - tolerance <= second[tangent] <= bounds[1] + tolerance
            and abs(first[tangent] - second[tangent]) > tolerance
        ):
            return side
    return None


def _locked_chain_candidates(
    context: MixedExecutionContext,
    authority: NeutralSurfaceAuthority,
    target_fragment: CanonicalGeometryFragment,
) -> tuple[LockedCartesianBoundaryChain, ...]:
    """Intersect actual adjacent locked patches with one shared-base boundary."""

    root = target_fragment.root
    if type(root) is not CanonicalRectangularUnderfillFillet:
        return ()
    consumer = authority.consumer_component_id
    edges_by_side: dict[
        OrthogonalBoundarySide, set[tuple[Point3D, Point3D]]
    ] = defaultdict(set)
    tolerance = context.interface_geometry_tolerance_mm
    for key, patches in context.frozen_patches_by_interface.items():
        if key.generated_component_global_id != consumer:
            continue
        for patch in patches:
            package_facets = tuple(
                facet.source_node_tags for facet in patch.facets
            )
            for package_first, package_second in _boundary_edge_coordinates(
                package_facets, patch.node_coordinates
            ):
                first = _package_to_local(
                    package_first, target_fragment.placement
                )
                second = _package_to_local(
                    package_second, target_fragment.placement
                )
                side = _chain_side(root, first, second, tolerance)
                if side is None:
                    continue
                endpoints = tuple(
                    sorted(
                        (
                            tuple(round(value, 12) for value in first),
                            tuple(round(value, 12) for value in second),
                        )
                    )
                )
                edges_by_side[side].add(endpoints)  # type: ignore[arg-type]
    if not edges_by_side:
        return ()
    expected = {
        OrthogonalBoundarySide.DIE_X_MIN,
        OrthogonalBoundarySide.DIE_X_MAX,
        OrthogonalBoundarySide.DIE_Y_MIN,
        OrthogonalBoundarySide.DIE_Y_MAX,
    }
    if set(edges_by_side) != expected:
        raise MixedSourceExecutionError(
            "adjacent locked geometry exposes only a partial orthogonal base "
            "boundary chain set"
        )
    output: list[LockedCartesianBoundaryChain] = []
    for side in sorted(expected, key=lambda value: value.value):
        tangent = 1 if side in {
            OrthogonalBoundarySide.DIE_X_MIN,
            OrthogonalBoundarySide.DIE_X_MAX,
        } else 0
        points = tuple(
            sorted(
                {point for edge in edges_by_side[side] for point in edge},
                key=lambda point: point[tangent],
            )
        )
        expected_edges = {
            tuple(sorted((first, second)))
            for first, second in zip(points, points[1:])
        }
        if edges_by_side[side] != expected_edges:
            raise MixedSourceExecutionError(
                "adjacent locked geometry does not form one exact monotone "
                "orthogonal boundary chain"
            )
        output.append(
            LockedCartesianBoundaryChain(
                f"{authority.face_pair_id}:{side.value}",
                side,
                points,
            )
        )
    return tuple(output)


def _orthogonal_locked_quads(
    context: MixedExecutionContext,
    plan: RoleFreeSourceExecutionPlan,
    component_id: str,
    fragment: CanonicalGeometryFragment,
    patches: Mapping[str, MaterializedSurfacePatch],
) -> tuple[
    tuple[LockedCartesianQuad, ...],
    tuple[LockedCartesianQuad, ...],
    tuple[LockedCartesianQuad, ...],
    Mapping[tuple[float, float, float], str],
]:
    grouped: dict[OrthogonalBoundarySide, list[LockedCartesianQuad]] = defaultdict(list)
    semantic_token_by_local_coordinate: dict[
        tuple[float, float, float], str
    ] = {}
    local_coordinate_by_semantic_token: dict[
        str, tuple[float, float, float]
    ] = {}

    def add_patch(
        node_coordinates: Mapping[int, Point3D],
        facets: Sequence[Sequence[int]],
        semantic_tokens_by_node_id: Mapping[int, str],
        side_name: str,
        prefix: str,
    ) -> None:
        side = _orthogonal_side(side_name)
        referenced = {node for facet in facets for node in facet}
        if not referenced.issubset(node_coordinates):
            raise MixedSourceExecutionError(
                "orthogonal fillet lock has missing node coordinates"
            )
        if not referenced.issubset(semantic_tokens_by_node_id):
            raise MixedSourceExecutionError(
                "orthogonal fillet lock has missing semantic node identity"
            )
        local_by_source: dict[int, Point3D] = {}
        for node in sorted(referenced):
            local = _package_to_local(
                node_coordinates[node], fragment.placement
            )
            coordinate_key = tuple(round(value, 12) for value in local)
            token = semantic_tokens_by_node_id[node]
            previous_token = semantic_token_by_local_coordinate.setdefault(
                coordinate_key, token
            )
            if previous_token != token:
                raise MixedSourceExecutionError(
                    "coincident orthogonal fillet lock nodes have different "
                    "semantic identities"
                )
            previous_coordinate = local_coordinate_by_semantic_token.setdefault(
                token, coordinate_key
            )
            if previous_coordinate != coordinate_key:
                raise MixedSourceExecutionError(
                    "one orthogonal fillet semantic identity maps to multiple "
                    "target-local coordinates"
                )
            local_by_source[node] = local
        for index, facet in enumerate(facets, start=1):
            if len(facet) != 4:
                raise MixedSourceExecutionError(
                    "orthogonal_hex can only consume an exact Cartesian QUAD lock"
                )
            grouped[side].append(
                LockedCartesianQuad(
                    f"{prefix}:{index:06d}",
                    tuple(
                        local_by_source[node]
                        for node in facet
                    ),  # type: ignore[arg-type]
                )
            )

    for face_pair_id in plan.incoming_face_pair_ids_by_component[component_id]:
        patch = patches[face_pair_id]
        add_patch(
            patch.node_coordinates_package_mm,
            patch.facets,
            patch.semantic_tokens_by_node_id,
            patch.consumer_side.side_name,
            face_pair_id,
        )
        authority = plan.authority_plan.authority_by_face_pair_id[face_pair_id]
        if patch.candidate_quads_package_mm and all(c.covers_complete_side for c in authority.side_coverages):
            side = _orthogonal_side(patch.consumer_side.side_name)
            if side in {OrthogonalBoundarySide.BASE, OrthogonalBoundarySide.CAP}:
                # Inherit the candidate partition, independently of occupancy.
                grouped[side] = [
                    LockedCartesianQuad(
                        f"{face_pair_id}:candidate:{index:06d}",
                        tuple(_package_to_local(point, fragment.placement) for point in quad),
                    )
                    for index, quad in enumerate(patch.candidate_quads_package_mm)
                ]
    for key, match in context.lowering.frozen_interface_matches.items():
        if (
            key.generated_component_global_id != component_id
            or match.mode is not InterfaceMatchMode.PRESERVE_INTERFACE_TRACE
        ):
            continue
        for patch_index, patch in enumerate(
            context.frozen_patches_by_interface[key], start=1
        ):
            add_patch(
                patch.node_coordinates,
                tuple(facet.source_node_tags for facet in patch.facets),
                {
                    node: frozen_node_semantic_token(node)
                    for node in patch.node_coordinates
                },
                patch.side_name,
                f"frozen:{patch_index:06d}",
            )
    return (
        tuple(grouped[OrthogonalBoundarySide.BASE]),
        tuple(grouped[OrthogonalBoundarySide.CAP]),
        tuple(
            value
            for side in (
                OrthogonalBoundarySide.DIE_X_MIN,
                OrthogonalBoundarySide.DIE_X_MAX,
                OrthogonalBoundarySide.DIE_Y_MIN,
                OrthogonalBoundarySide.DIE_Y_MAX,
            )
            for value in grouped[side]
        ),
        MappingProxyType(dict(semantic_token_by_local_coordinate)),
    )


def _orthogonal_fillet_semantic_tokens_by_node_id(
    mesh: OrthogonalFilletMesh | OrthogonalMultiblockFilletMesh,
    semantic_token_by_local_coordinate: Mapping[
        tuple[float, float, float], str
    ],
    *,
    locked_quad_seam_ids: frozenset[str],
) -> Mapping[int, str]:
    """Resolve every immutable lock identity onto one final fillet node.

    The orthogonal backend owns node numbering.  Incoming/Frozen identities
    therefore cross that backend only through their already validated
    target-local coordinates.  This is deliberately a bijection and fails
    closed: neither a missing node, a duplicate final coordinate, a reused
    token nor an unaccounted locked-QUAD node is accepted.
    """

    final_node_by_local_coordinate: dict[
        tuple[float, float, float], int
    ] = {}
    for node in mesh.nodes:
        coordinate_key = tuple(
            round(value, 12) for value in node.target_local_coordinates_mm
        )
        previous = final_node_by_local_coordinate.setdefault(
            coordinate_key, node.node_index
        )
        if previous != node.node_index:
            raise MixedSourceExecutionError(
                "orthogonal fillet mesh repeats one target-local node coordinate"
            )

    output: dict[int, str] = {}
    owner_by_token: dict[str, int] = {}
    for coordinate_key, token in semantic_token_by_local_coordinate.items():
        node_id = final_node_by_local_coordinate.get(coordinate_key)
        if node_id is None:
            continue  # No surviving cell uses this candidate interface node.
        previous_token = output.setdefault(node_id, token)
        if previous_token != token:  # pragma: no cover - coordinate map guards
            raise MixedSourceExecutionError(
                "one orthogonal fillet node received multiple semantic identities"
            )
        previous_node = owner_by_token.setdefault(token, node_id)
        if previous_node != node_id:
            raise MixedSourceExecutionError(
                "one orthogonal fillet semantic identity resolved to multiple "
                "final mesh nodes"
            )

    return MappingProxyType(dict(sorted(output.items())))


def _partial_contact_boundary_loops(context, plan, component_id, fragment):
    """Consumer-side boundaries to imprint on a partial producer before meshing."""
    from .package_v2_surface_authority import canonical_side_cartesian_rectangle

    loops = []
    for face_id in plan.outgoing_face_pair_ids_by_component[component_id]:
        authority = plan.authority_plan.authority_by_face_pair_id[face_id]
        if authority.producer_fragment_id != fragment.fragment_id:
            continue
        coverage = next(v for v in authority.side_coverages if v.component_id == component_id)
        if coverage.covers_complete_side:
            continue
        target = context.lowering.canonical_fragments_by_global_id[authority.consumer_fragment_id]
        rectangle = canonical_side_cartesian_rectangle(target, authority.consumer_side_name)
        if rectangle is not None:
            origin, u, v = rectangle
            points = tuple(tuple(origin[a] + du*u[a] + dv*v[a] for a in range(3))
                           for du, dv in ((0, 0), (1, 0), (1, 1), (0, 1)))
            loops.append(tuple(_local_to_package(p, target.placement) for p in points))
        elif type(target.root) is CanonicalRectangularFrameExtrusion and authority.consumer_side_name in {"z_min", "z_max"}:
            root = target.root
            x, y, z = root.outer_origin_xyz_mm
            if authority.consumer_side_name == "z_max":
                z += root.height_mm
            for ox, oy, sx, sy in ((x, y, *root.outer_size_xy_mm),
                                   (x + root.opening_offset_xy_mm[0], y + root.opening_offset_xy_mm[1], *root.opening_size_xy_mm)):
                points = ((ox, oy, z), (ox+sx, oy, z), (ox+sx, oy+sy, z), (ox, oy+sy, z))
                loops.append(tuple(_local_to_package(p, target.placement) for p in points))
        elif authority.consumer_side_name.startswith("orth:"):
            from .package_v2_orthogonal_domain_planning import root_boundary_rectangles

            for side, axis, end, bounds in root_boundary_rectangles(target.root):
                if side != authority.consumer_side_name:
                    continue
                u, v = [a for a in range(3) if a != axis]
                points = []
                for du, dv in ((0, 0), (1, 0), (1, 1), (0, 1)):
                    point = [b[0] for b in bounds]
                    point[u], point[v] = bounds[u][du], bounds[v][dv]
                    points.append(_local_to_package(tuple(point), target.placement))
                loops.append(tuple(points))
    return tuple(loops)


def _materialize_orthogonal(
    context: MixedExecutionContext,
    plan: RoleFreeSourceExecutionPlan,
    component_id: str,
    patches: Mapping[str, MaterializedSurfacePatch],
) -> MaterializedComponent:
    lowering = context.lowering
    component = lowering.canonical_components_by_global_id[component_id]
    requirement = lowering.component_mesh_requirements[component_id]
    control = lowering.component_mesh_controls_by_global_id[component_id]
    if type(control.strategy) is not OrthogonalHexMeshStrategy:
        raise MixedSourceExecutionError(
            "orthogonal executor requires an exact OrthogonalHexMeshStrategy"
        )
    orthogonal_strategy = control.strategy
    if all(
        type(fragment.root) in {CanonicalBox, CanonicalRectangularFrameExtrusion}
        for fragment in component.fragments
    ):
        locks_by_fragment = {
            fragment.fragment_id: _Locks(fragment)
            for fragment in component.fragments
        }
        _add_frozen_trace_locks(context, component_id, locks_by_fragment)
        missing = _add_incoming_surface_locks(
            context, plan, component_id, patches, locks_by_fragment
        )
        if missing:
            raise MixedSourceExecutionError(
                "orthogonal Box/Frame component is missing an upstream "
                "Cartesian QUAD surface"
            )
        fragments: dict[str, ComponentLocalMeshFragment] = {}
        boundary: dict[FragmentSideKey, tuple[tuple[int, ...], ...]] = {}
        locked: dict[FragmentSideKey, tuple[tuple[int, ...], ...]] = {}
        backend_evidence: dict[str, Mapping[str, object]] = {}
        for fragment in component.fragments:
            backend_strategy = _orthogonal_strategy_with_surface_caps(
                plan,
                component_id,
                fragment,
                orthogonal_strategy,
            )
            backend_requirement = _cross_section_producer_requirement(
                requirement,
                _negotiated_outgoing_surface_target_edge_mm(
                    plan,
                    component_id,
                    fragment_id=fragment.fragment_id,
                ),
                gmsh_triangular_surface=False,
            )
            values = locks_by_fragment[fragment.fragment_id]
            locked_facets_by_side = {
                side: tuple(facets)
                for side, facets in values.facets_by_side.items()
                if facets
            }
            locked_package_nodes = (
                {
                    node: _local_to_package(
                        values.coordinates[node], fragment.placement
                    )
                    for node in sorted(values.coordinates)
                }
                if locked_facets_by_side
                else None
            )
            locked_tokens = (
                {node: values.tokens[node] for node in sorted(values.tokens)}
                if locked_facets_by_side
                else None
            )
            try:
                result = materialize_orthogonal_box_frame_component(
                    fragment,
                    backend_requirement,
                    orthogonal_strategy=backend_strategy,
                    contact_partition_points_package_mm=tuple(p for loop in _partial_contact_boundary_loops(context, plan, component_id, fragment) for p in loop),
                    material_name=component.material_name,
                    fragment_key=fragment.fragment_id,
                    locked_boundary_node_coordinates_package_mm=(
                        locked_package_nodes
                    ),
                    locked_boundary_facets_by_geometric_side=(
                        locked_facets_by_side if locked_facets_by_side else None
                    ),
                    semantic_tokens_by_locked_node_id=locked_tokens,
                )
            except OrthogonalBoxFrameMaterializationError as error:
                raise MixedSourceExecutionError(str(error)) from error
            fragments[fragment.fragment_id] = result.component_fragment
            boundary.update(
                {
                    (fragment.fragment_id, side): facets
                    for side, facets in
                    result.boundary_facets_by_geometric_side.items()
                }
            )
            locked.update(
                {
                    (fragment.fragment_id, side): facets
                    for side, facets in
                    result.locked_facets_by_geometric_side.items()
                }
            )
            backend_evidence[fragment.fragment_id] = MappingProxyType(
                {
                    "applied_volume_path": "gmsh_orthogonal_hex_box_frame",
                    "gmsh_owns_all_volume_connectivity": (
                        result.gmsh_owns_all_volume_connectivity
                    ),
                    "cartesian_hex_verified": result.cartesian_hex_verified,
                    "immutable_target_edge_override_count": (
                        result.immutable_target_edge_override_count
                    ),
                    "immutable_maximum_edge_mm": (
                        result.immutable_maximum_edge_mm
                    ),
                    "relative_volume_error": result.relative_volume_error,
                }
            )
        return MaterializedComponent(
            component_id,
            "orthogonal_hex",
            fragments,
            boundary,
            locked,
            backend_evidence_by_fragment_id=backend_evidence,
        )
    if (
        len(component.fragments) != 1
        or type(component.fragments[0].root)
        is not CanonicalRectangularUnderfillFillet
    ):
        raise MixedSourceExecutionError(
            "orthogonal executor requires canonical Box/Frame fragments or one "
            "canonical rectangular fillet fragment"
        )
    fragment = component.fragments[0]
    backend_strategy = _orthogonal_strategy_with_surface_caps(
        plan,
        component_id,
        fragment,
        orthogonal_strategy,
    )
    backend_requirement = _cross_section_producer_requirement(
        requirement,
        _negotiated_outgoing_surface_target_edge_mm(
            plan,
            component_id,
            fragment_id=fragment.fragment_id,
        ),
        gmsh_triangular_surface=False,
    )
    base, cap, walls, semantic_token_by_local_coordinate = (
        _orthogonal_locked_quads(
            context, plan, component_id, fragment, patches
        )
    )
    base_authorities = tuple(
        plan.authority_plan.authority_by_face_pair_id[value]
        for value in plan.outgoing_face_pair_ids_by_component[component_id]
        if _orthogonal_side(
            plan.authority_plan.authority_by_face_pair_id[value].producer_side_name
        )
        is OrthogonalBoundarySide.BASE
    )
    if len(base_authorities) > 1:
        raise MixedSourceExecutionError(
            "one orthogonal base side has multiple surface authorities"
        )
    chains = (
        ()
        if not base_authorities
        else _locked_chain_candidates(context, base_authorities[0], fragment)
    )
    complete_incoming_orth_endpoints = tuple(
        authority
        for face_pair_id in plan.incoming_face_pair_ids_by_component[component_id]
        for authority in (plan.authority_plan.authority_by_face_pair_id[face_pair_id],)
        if context.lowering.component_mesh_requirements[
            authority.producer_component_id
        ].volume_topology
        == "orthogonal_hex"
        and all(
            coverage.covers_complete_side
            for coverage in authority.side_coverages
        )
        and _orthogonal_side(authority.consumer_side_name)
        in {OrthogonalBoundarySide.BASE, OrthogonalBoundarySide.CAP}
    )
    if len(complete_incoming_orth_endpoints) > 1:
        raise MixedSourceExecutionError(
            "one orthogonal fillet endpoint has multiple complete Orth surface "
            "authorities"
        )
    complete_incoming_orth_endpoint = (
        None
        if not complete_incoming_orth_endpoints
        else complete_incoming_orth_endpoints[0]
    )
    if (
        complete_incoming_orth_endpoint is not None
        and _orthogonal_side(
            complete_incoming_orth_endpoint.consumer_side_name
        )
        is OrthogonalBoundarySide.CAP
    ):
        raise MixedSourceExecutionError(
            "complete per-side Orth endpoint -> Orth fillet CAP is not "
            "supported: reverse traversal would have to generate new outer "
            "eight-block columns as the fillet widens toward its BASE"
        )
    if complete_incoming_orth_endpoint is not None:
        face_pair_id = complete_incoming_orth_endpoint.face_pair_id
        expected_patch = patches[face_pair_id]
        if (
            len(base) != len(expected_patch.candidate_quads_package_mm or expected_patch.facets)
            or any(
                not quad.seam_id.startswith(f"{face_pair_id}:")
                for quad in base
            )
        ):
            raise MixedSourceExecutionError(
                "complete per-side Orth BASE authority cannot be combined with "
                "another base lock"
            )
        if cap or walls or chains:
            raise MixedSourceExecutionError(
                "complete per-side Orth BASE authority cannot be combined with "
                "a CAP, die-wall lock, or independently derived boundary chain"
            )
        mesh = mesh_rectangular_fillet_orthogonal_hex_multiblock(
            fragment,
            backend_requirement.target_edge_mm,
            base_quads=base,
            orthogonal_strategy=backend_strategy,
        )
    elif chains or walls or not (base or cap):
        if base or cap:
            raise MixedSourceExecutionError(
                "orthogonal per-side multiblock does not accept an additional "
                "locked base/cap patch in its first implementation"
            )
        mesh: OrthogonalFilletMesh | OrthogonalMultiblockFilletMesh = (
            mesh_rectangular_fillet_orthogonal_hex_multiblock(
                fragment,
                backend_requirement.target_edge_mm,
                base_boundary_chains=chains,
                die_wall_quads=walls,
                shared_surface_id=(
                    None
                    if not base_authorities
                    else base_authorities[0].face_pair_id
                ),
                orthogonal_strategy=backend_strategy,
            )
        )
    else:
        mesh = mesh_rectangular_fillet_orthogonal_hex(
            fragment,
            backend_requirement.target_edge_mm,
            base_quads=base,
            cap_quads=cap,
            die_wall_quads=walls,
            orthogonal_strategy=backend_strategy,
        )
    locked_quads = (*base, *cap, *walls)
    semantic_tokens_by_node_id = (
        _orthogonal_fillet_semantic_tokens_by_node_id(
            mesh,
            semantic_token_by_local_coordinate,
            locked_quad_seam_ids=frozenset(
                quad.seam_id for quad in locked_quads
            ),
        )
    )
    result_fragment = fragment_from_orthogonal_fillet_mesh(
        mesh,
        fragment_key=fragment.fragment_id,
        component_key=component_id,
        material_name=component.material_name,
        provenance="orthogonal_hex",
        semantic_tokens_by_node_id=semantic_tokens_by_node_id,
    )
    boundary = {
        (fragment.fragment_id, side.value): tuple(
            facet.node_indices for facet in mesh.boundary_facets_for_side(side)
        )
        for side in OrthogonalBoundarySide
        if mesh.boundary_facets_for_side(side)
    }
    locked = {
        (fragment.fragment_id, side.value): tuple(
            facet.node_indices
            for facet in mesh.boundary_facets_for_side(side)
            if facet.locked_seam_ids
        )
        for side in OrthogonalBoundarySide
        if any(
            facet.locked_seam_ids
            for facet in mesh.boundary_facets_for_side(side)
        )
    }
    audit = mesh.audit
    backend_evidence: dict[str, object] = {
        "applied_volume_path": (
            "orthogonal_hex_rectangular_fillet_multiblock"
            if isinstance(mesh, OrthogonalMultiblockFilletMesh)
            else "orthogonal_hex_rectangular_fillet_cartesian"
        ),
        "cartesian_hex_verified": True,
        "maximum_generated_edge_mm": audit.maximum_generated_edge_mm,
        "relative_volume_error": audit.relative_volume_error,
        "cut_cell_rule": audit.cut_cell_rule,
        "mesh_warnings": audit.mesh_warnings,
        "signed_volume_error_mm3": audit.signed_volume_error_mm3,
        "analytic_volume_mm3": audit.analytic_volume_mm3,
        "z_levels_mm": audit.z_levels_mm,
    }
    if isinstance(mesh, OrthogonalMultiblockFilletMesh):
        def maximum_gap(values: Sequence[float]) -> float:
            return max(
                (
                    second - first
                    for first, second in zip(values, values[1:])
                ),
                default=0.0,
            )

        backend_evidence.update(
            {
                "near_edge_mm": audit.near_edge_mm,
                "side_tangential_maximum_edge_mm": {
                    side: maximum_gap(levels)
                    for side, levels in audit.side_tangential_levels_mm
                },
                "side_normal_maximum_edge_mm": {
                    side: maximum_gap(levels)
                    for side, levels in audit.side_normal_offsets_mm
                },
                "immutable_target_edge_override_count": (
                    audit.immutable_target_edge_override_count
                ),
                "immutable_maximum_edge_mm": audit.immutable_maximum_edge_mm,
                "authoritative_base_override_count": (
                    audit.authoritative_base_override_count
                ),
                "base_shared_quad_count": audit.base_shared_quad_count,
                "accepted_full_cell_count": audit.accepted_full_cell_count,
                "accepted_cut_cell_count": audit.accepted_cut_cell_count,
                "rejected_cut_cell_count": audit.rejected_cut_cell_count,
            }
        )
    return MaterializedComponent(
        component_id,
        "orthogonal_hex",
        {fragment.fragment_id: result_fragment},
        boundary,
        locked,
        backend_evidence_by_fragment_id={
            fragment.fragment_id: MappingProxyType(backend_evidence)
        },
        candidate_endpoint_quads={
            (fragment.fragment_id, side.value): tuple(
                tuple(_local_to_package(point, fragment.placement) for point in (
                    (xb[0], yb[0], z), (xb[1], yb[0], z),
                    (xb[1], yb[1], z), (xb[0], yb[1], z),
                ))
                for xb, yb in mesh.candidate_xy_cells_mm
            )
            for side, z in (
                (OrthogonalBoundarySide.BASE, fragment.root.base_z_mm),
                (OrthogonalBoundarySide.CAP, fragment.root.base_z_mm + fragment.root.wall_height_mm),
            )
        },
        orthogonal_candidate_grids={fragment.fragment_id: OrthogonalCandidateGrid.from_mesh(fragment, mesh)},
    )


def _authority_sides(
    authority: NeutralSurfaceAuthority,
) -> tuple[CanonicalAdjacentSide, CanonicalAdjacentSide]:
    values = {
        authority.producer_component_id: CanonicalAdjacentSide(
            authority.producer_component_id,
            authority.producer_fragment_id,
            authority.producer_side_name,
        ),
        authority.consumer_component_id: CanonicalAdjacentSide(
            authority.consumer_component_id,
            authority.consumer_fragment_id,
            authority.consumer_side_name,
        ),
    }
    return values[authority.producer_component_id], values[
        authority.consumer_component_id
    ]


def _boundary_facets_for_authority(
    component: MaterializedComponent,
    fragment: CanonicalGeometryFragment,
    side_name: str,
    *,
    tolerance_mm: float,
) -> tuple[tuple[int, ...], ...]:
    side = _shell_side(fragment, side_name)
    if (
        component.backend == "orthogonal_hex"
        and type(fragment.root) is CanonicalRectangularUnderfillFillet
    ):
        orthogonal_side = _orthogonal_side(side_name)
        # An Orth fillet's physical endpoint is the complete exposed plane.
        # ``CAP`` contains Cartesian cells wholly inside the analytic section;
        # the coplanar ``STAIRCASE_Z_MAX`` cells are the indispensable edge
        # approximation.  Selecting CAP alone silently turns the latter into
        # overlapping free faces on both components.  The z_min pairing is
        # kept symmetric for future reversed stacks.
        endpoint_sides = {
            OrthogonalBoundarySide.BASE: (
                OrthogonalBoundarySide.BASE,
                OrthogonalBoundarySide.STAIRCASE_Z_MIN,
            ),
            OrthogonalBoundarySide.CAP: (
                OrthogonalBoundarySide.CAP,
                OrthogonalBoundarySide.STAIRCASE_Z_MAX,
            ),
        }.get(orthogonal_side, (orthogonal_side,))
        candidates = tuple(
            facet
            for endpoint_side in endpoint_sides
            for facet in component.boundary_facets_by_fragment_side.get(
                (fragment.fragment_id, endpoint_side.value), ()
            )
        )
        if orthogonal_side in {
            OrthogonalBoundarySide.BASE,
            OrthogonalBoundarySide.CAP,
        }:
            root = fragment.root
            support_z = (
                root.base_z_mm
                if orthogonal_side is OrthogonalBoundarySide.BASE
                else root.base_z_mm + root.wall_height_mm
            )
            node_by_id = {
                node.local_node_id: node
                for node in component.fragments_by_id[
                    fragment.fragment_id
                ].nodes
            }
            facets = tuple(
                facet
                for facet in candidates
                if all(
                    abs(
                        _package_to_local(
                            node_by_id[node].coordinates_mm,
                            fragment.placement,
                        )[2]
                        - support_z
                    )
                    <= tolerance_mm
                    for node in facet
                )
            )
        else:
            facets = candidates
    else:
        facets = component.boundary_facets_by_fragment_side.get(
            (fragment.fragment_id, side), ()
        )
    if not facets and component.backend != "orthogonal_hex":
        raise MixedSourceExecutionError(
            f"surface authority produced no boundary facets on {side_name!r}"
        )
    return facets


def _retoken_outgoing_surfaces(
    context: MixedExecutionContext,
    component: MaterializedComponent,
    component_geometry: CanonicalComponentGeometry,
    authorities: Sequence[NeutralSurfaceAuthority],
) -> tuple[MaterializedComponent, tuple[MaterializedSurfacePatch, ...]]:
    fragment_geometry = {
        value.fragment_id: value for value in component_geometry.fragments
    }
    facets_by_authority: dict[str, tuple[tuple[int, ...], ...]] = {}
    required_nodes_by_fragment: dict[str, set[int]] = defaultdict(set)
    frozen_token_by_coordinate: dict[tuple[float, float, float], str] = {}
    planned_edge_tokens_by_surface: dict[
        str, dict[tuple[float, float, float], str]
    ] = defaultdict(dict)
    for edge in context.mesh_ordering.shared_edge_authorities:
        for surface_id in edge.incident_surface_ids:
            values = planned_edge_tokens_by_surface[surface_id]
            for point, token in zip(
                edge.partition_points_package_mm,
                edge.semantic_tokens,
            ):
                key = tuple(round(value, 12) for value in point)
                previous = values.setdefault(key, token)
                if previous != token:
                    raise MixedSourceExecutionError(
                        "planned Cartesian shared-edge node has conflicting "
                        "semantic authority"
                    )
    constraint_by_face_pair_id = {
        value.face_pair_id: value
        for value in context.mesh_ordering.constraints
        if value.face_pair_id is not None
    }
    planned_token_by_fragment_node: dict[tuple[str, int], str] = {}
    for authority in authorities:
        fragment = fragment_geometry[authority.producer_fragment_id]
        facets = _boundary_facets_for_authority(
            component,
            fragment,
            authority.producer_side_name,
            tolerance_mm=context.interface_geometry_tolerance_mm,
        )
        coverage = next(value for value in authority.side_coverages
                        if value.component_id == authority.producer_component_id)
        if not coverage.covers_complete_side:
            from .package_v2_frozen_boundary_matching import _side_for_points, _positive_overlap_sides

            consumer_fragment = context.lowering.canonical_fragments_by_global_id[authority.consumer_fragment_id]
            consumer_side = _shell_side(consumer_fragment, authority.consumer_side_name)
            coordinates = {node.local_node_id: node.coordinates_mm
                           for node in component.fragments_by_id[fragment.fragment_id].nodes}
            selected = []
            for facet in facets:
                points = tuple(coordinates[node] for node in facet)
                if _side_for_points(consumer_fragment, points, context.interface_geometry_tolerance_mm) == consumer_side:
                    selected.append(facet)
                elif consumer_side in _positive_overlap_sides(consumer_fragment, points, context.interface_geometry_tolerance_mm):
                    raise _partial_contact_boundary_error(
                        authority, fragment, consumer_fragment, points,
                        component.backend, context.interface_geometry_tolerance_mm,
                    )
            facets = tuple(selected)
        facets_by_authority[authority.face_pair_id] = facets
        required_nodes_by_fragment[fragment.fragment_id].update(
            node for facet in facets for node in facet
        )
        constraint = constraint_by_face_pair_id[authority.face_pair_id]
        edge_tokens = planned_edge_tokens_by_surface.get(
            constraint.surface_id,
            {},
        )
        if edge_tokens:
            node_by_id = {
                node.local_node_id: node
                for node in component.fragments_by_id[
                    fragment.fragment_id
                ].nodes
            }
            for node in {value for facet in facets for value in facet}:
                token = edge_tokens.get(
                    tuple(
                        round(value, 12)
                        for value in node_by_id[node].coordinates_mm
                    )
                )
                if token is None:
                    continue
                key = (fragment.fragment_id, node)
                previous = planned_token_by_fragment_node.setdefault(key, token)
                if previous != token:
                    raise MixedSourceExecutionError(
                        "one Cartesian shared-edge node received incompatible "
                        "one-dimensional authorities"
                    )
        # A surface-authority node on the boundary of the actual adjacent
        # consumer's immutable Frozen patch retains that Frozen identity.
        # This is a geometric edge intersection, not a component-role rule.
        for key, frozen_patches in context.frozen_patches_by_interface.items():
            if key.generated_component_global_id != authority.consumer_component_id:
                continue
            for frozen_patch in frozen_patches:
                for source_node, point in frozen_patch.node_coordinates.items():
                    coordinate_key = tuple(round(value, 12) for value in point)
                    token = frozen_node_semantic_token(source_node)
                    previous = frozen_token_by_coordinate.setdefault(
                        coordinate_key, token
                    )
                    if previous != token:
                        raise MixedSourceExecutionError(
                            "coincident adjacent Frozen nodes have different "
                            "semantic identities"
                        )

    updated_fragments: dict[str, ComponentLocalMeshFragment] = {}
    for fragment_id, fragment in component.fragments_by_id.items():
        required = required_nodes_by_fragment.get(fragment_id, set())
        nodes: list[ComponentMeshNode] = []
        used_tokens = {
            node.semantic_token
            for node in fragment.nodes
            if node.semantic_token is not None
        }
        for node in fragment.nodes:
            token = node.semantic_token
            if node.local_node_id in required:
                inherited_frozen = frozen_token_by_coordinate.get(
                    tuple(round(value, 12) for value in node.coordinates_mm)
                )
                planned_edge = planned_token_by_fragment_node.get(
                    (fragment_id, node.local_node_id)
                )
                if (
                    inherited_frozen is not None
                    and planned_edge is not None
                    and inherited_frozen != planned_edge
                ):
                    raise MixedSourceExecutionError(
                        "Frozen and planned Cartesian shared-edge identities differ"
                    )
                inherited = (
                    inherited_frozen
                    if inherited_frozen is not None
                    else planned_edge
                )
                if inherited is not None:
                    if (
                        token is not None
                        and token.startswith("frozen:")
                        and token != inherited
                    ):
                        raise MixedSourceExecutionError(
                            "surface authority conflicts with an immutable Frozen "
                            "boundary-node identity"
                        )
                    token = inherited
                elif token is None:
                    token = (
                        "neutral-surface-node::"
                        f"{component.component_id}::{fragment_id}::"
                        f"{node.local_node_id}"
                    )
            if node.local_node_id in required and token is not None:
                if token in used_tokens:
                    if node.semantic_token != token:
                        raise MixedSourceExecutionError(
                            "surface semantic token collides inside one fragment"
                        )
                used_tokens.add(token)
            nodes.append(replace(node, semantic_token=token))
        updated_fragments[fragment_id] = replace(fragment, nodes=tuple(nodes))
    updated = replace(component, fragments_by_id=updated_fragments)

    patches: list[MaterializedSurfacePatch] = []
    for authority in authorities:
        producer_side, consumer_side = _authority_sides(authority)
        fragment = updated.fragments_by_id[producer_side.fragment_id]
        node_by_id = {node.local_node_id: node for node in fragment.nodes}
        facets = facets_by_authority[authority.face_pair_id]
        referenced = {node for facet in facets for node in facet}
        coordinates = {
            node: node_by_id[node].coordinates_mm
            for node in sorted(referenced)
        }
        try:
            coverage = audit_ordered_surface_materialization(
                constraint_by_face_pair_id[authority.face_pair_id],
                fragment_geometry[producer_side.fragment_id],
                coordinates,
                facets,
                enforce_target_size=False
            )
        except (KeyError, MeshOrderingError) as error:
            raise MixedSourceExecutionError(
                "priority producer emitted a contact surface that violates "
                "preflight before consumer start: "
                f"{authority.face_pair_id}: {error}"
            ) from error
        patches.append(
            MaterializedSurfacePatch(
                authority.face_pair_id,
                authority.interface_id,
                producer_side,
                consumer_side,
                authority.surface_policy,
                coordinates,
                facets,
                {
                    node: node_by_id[node].semantic_token
                    for node in sorted(referenced)
                    if node_by_id[node].semantic_token is not None
                },
                component.backend,
                coverage,
                component.candidate_endpoint_quads.get(
                    (producer_side.fragment_id, _orthogonal_side(producer_side.side_name).value), ()
                ) if component.backend == "orthogonal_hex" and type(fragment_geometry[producer_side.fragment_id].root) is CanonicalRectangularUnderfillFillet else (),
            )
        )
    return updated, tuple(patches)


def _consumer_facets(
    component: MaterializedComponent,
    patch: MaterializedSurfacePatch,
    fragment: CanonicalGeometryFragment,
) -> tuple[tuple[int, ...], ...]:
    """Return exact surviving consumer facets from the incoming partition.

    Boundary coincidence is insufficient: Hybrid/Sweep must report the
    incoming staircase facets in their explicit locked-facet map.  Exact
    semantic facet signatures prove connectivity reuse. Orth may remove
    incident HEX cells by centre sampling; Hybrid/Sweep must retain the patch.
    """

    local_fragment = component.fragments_by_id[patch.consumer_side.fragment_id]
    node_by_id = {node.local_node_id: node for node in local_fragment.nodes}
    desired = {
        frozenset(patch.semantic_tokens_by_node_id[node] for node in facet)
        for facet in patch.facets
    }
    side = _shell_side(fragment, patch.consumer_side.side_name)
    if (
        component.backend == "orthogonal_hex"
        and type(fragment.root) is CanonicalRectangularUnderfillFillet
    ):
        side = _orthogonal_side(patch.consumer_side.side_name).value
    candidates = component.locked_facets_by_fragment_side.get(
        (fragment.fragment_id, side), ()
    )
    matched: list[tuple[int, ...]] = []
    signatures: set[frozenset[str]] = set()
    for facet in candidates:
        tokens = tuple(node_by_id[node].semantic_token for node in facet)
        if any(value is None for value in tokens):
            continue
        signature = frozenset(value for value in tokens if value is not None)
        if signature in desired:
            matched.append(facet)
            signatures.add(signature)
    if component.backend != "orthogonal_hex" and (signatures != desired or len(matched) != len(desired)):
        raise MixedSourceExecutionError(
            "consumer locked contact does not cover 100% of the authority "
            "surface tokens and facets exactly"
        )
    return tuple(matched)


def _frozen_interface_outputs(
    context: MixedExecutionContext,
    completed: Mapping[str, MaterializedComponent],
) -> tuple[
    tuple[FrozenInterfaceFacetSet, ...],
    Mapping[int, str],
    tuple[DeclaredSharedSeam, ...],
]:
    """Declare every completed generated/Frozen face without coordinate merge."""

    output: list[FrozenInterfaceFacetSet] = []
    seams: list[DeclaredSharedSeam] = []
    all_tokens: dict[int, str] = {}
    component_geometry = context.lowering.canonical_components_by_global_id
    for interface_key, patches in sorted(
        context.frozen_patches_by_interface.items()
    ):
        component = completed.get(interface_key.generated_component_global_id)
        if component is None:
            continue
        for patch_index, patch in enumerate(patches, start=1):
            geometry = next(
                value
                for value in component_geometry[
                    interface_key.generated_component_global_id
                ].fragments
                if value.fragment_id == patch.target_fragment_id
            )
            fragment = component.fragments_by_id[patch.target_fragment_id]
            node_by_id = {node.local_node_id: node for node in fragment.nodes}
            frozen_facets = tuple(
                facet.source_node_tags for facet in patch.facets
            )
            frozen_tokens = {
                node: frozen_node_semantic_token(node)
                for node in patch.node_coordinates
            }
            for node, token in frozen_tokens.items():
                previous = all_tokens.setdefault(node, token)
                if previous != token:  # pragma: no cover - deterministic helper
                    raise MixedSourceExecutionError(
                        "one Frozen node has multiple semantic identities"
                    )
            desired_by_signature = {
                frozenset(frozen_tokens[node] for node in facet): facet
                for facet in frozen_facets
            }
            if len(desired_by_signature) != len(frozen_facets):
                raise MixedSourceExecutionError(
                    "Frozen interface facets repeat one semantic signature"
                )
            side = _shell_side(geometry, patch.side_name)
            if (
                component.backend == "orthogonal_hex"
                and type(geometry.root) is CanonicalRectangularUnderfillFillet
            ):
                side = _orthogonal_side(patch.side_name).value
            side_key = (patch.target_fragment_id, side)
            # A preserve-interface trace is proved first by the exact lock map
            # returned by the selected backend.  Complete boundary
            # classification is only a compatibility fallback for backends
            # whose public result predates explicit locked-facet evidence.
            candidates = component.locked_facets_by_fragment_side.get(
                side_key,
                (),
            )
            if not candidates:
                candidates = component.boundary_facets_by_fragment_side.get(
                    side_key,
                    (),
                )
            generated_by_signature: dict[frozenset[str], tuple[int, ...]] = {}
            for facet in candidates:
                node_tokens = tuple(
                    node_by_id[node].semantic_token for node in facet
                )
                if any(token is None for token in node_tokens):
                    continue
                signature = frozenset(
                    token for token in node_tokens if token is not None
                )
                if signature not in desired_by_signature:
                    continue
                if signature in generated_by_signature:
                    raise MixedSourceExecutionError(
                        "generated Frozen seam repeats one semantic facet"
                    )
                generated_by_signature[signature] = facet
            if component.backend != "orthogonal_hex" and set(generated_by_signature) != set(desired_by_signature):
                missing_count = len(
                    set(desired_by_signature).difference(
                        generated_by_signature
                    )
                )
                expected_tokens = set().union(*desired_by_signature)
                candidate_tokens = {
                    token
                    for facet in candidates
                    for node in facet
                    if (token := node_by_id[node].semantic_token) is not None
                }
                raise MixedSourceExecutionError(
                    "completed component does not retain every explicit Frozen "
                    "interface facet and semantic token: "
                    f"component={interface_key.generated_component_global_id!r}, "
                    f"side={patch.side_name!r}, "
                    f"expected={len(desired_by_signature)}, "
                    f"matched={len(generated_by_signature)}, "
                    f"missing={missing_count}, candidates={len(candidates)}, "
                    "expected/candidate-token-overlap="
                    f"{len(expected_tokens.intersection(candidate_tokens))}/"
                    f"{len(expected_tokens)}"
                )
            signatures = tuple(
                sorted(
                    generated_by_signature,
                    key=lambda value: (len(value), tuple(sorted(value))),
                )
            )
            generated_facets = tuple(
                generated_by_signature[value] for value in signatures
            )
            ordered_frozen = tuple(
                desired_by_signature[value] for value in signatures
            )
            output.append(
                FrozenInterfaceFacetSet(
                    interface_key,
                    patch.target_fragment_id,
                    patch.side_name,
                    ordered_frozen,
                    generated_facets,
                    {
                        node: frozen_tokens[node]
                        for node in sorted(
                            {value for facet in ordered_frozen for value in facet}
                        )
                    },
                )
            )
            prefix = (
                f"frozen::{interface_key.frozen_component_global_id}::"
                f"{interface_key.generated_component_global_id}::"
                f"{patch.target_fragment_id}::{patch_index:04d}"
            )
            seams.extend(
                DeclaredSharedSeam(
                    f"{prefix}:{index:06d}",
                    (
                        FragmentFaceReference(
                            FROZEN_FRAGMENT_KEY,
                            frozen_facet,
                        ),
                        FragmentFaceReference(
                            patch.target_fragment_id,
                            generated_facet,
                        ),
                    ),
                )
                for index, (frozen_facet, generated_facet) in enumerate(
                    zip(ordered_frozen, generated_facets), start=1
                )
            )
    return (
        tuple(output),
        MappingProxyType(dict(sorted(all_tokens.items()))),
        tuple(seams),
    )


def _component_evidence(
    context: MixedExecutionContext,
    completed: Mapping[str, MaterializedComponent],
) -> Mapping[str, ComponentExecutionEvidence]:
    result: dict[str, ComponentExecutionEvidence] = {}
    for component_id, requirement in sorted(
        context.lowering.component_mesh_requirements.items()
    ):
        component = completed.get(component_id)
        counts: Counter[str] = Counter()
        if component is not None:
            for fragment in component.fragments_by_id.values():
                counts.update(element.kind.value for element in fragment.elements)
        result[component_id] = ComponentExecutionEvidence(
            component_id,
            requirement.volume_topology,
            None if component is None else component.backend,
            MappingProxyType(dict(sorted(counts.items()))),
            () if component is None else tuple(sorted(component.fragments_by_id)),
        )
    return MappingProxyType(result)


def _validate_materialized_component_contract(
    context: MixedExecutionContext,
    plan: RoleFreeSourceExecutionPlan,
    component: MaterializedComponent,
) -> None:
    """Validate a private resume-cache entry against its declared Component."""

    component_id = component.component_id
    lowering = context.lowering
    canonical = lowering.canonical_components_by_global_id.get(component_id)
    requirement = lowering.component_mesh_requirements.get(component_id)
    if canonical is None or requirement is None:
        raise MixedSourceExecutionError(
            "trusted materialization references an unknown Component"
        )
    expected_fragments = {fragment.fragment_id for fragment in canonical.fragments}
    if set(component.fragments_by_id) != expected_fragments or any(
        fragment.component_key != component_id
        or fragment.material_name != canonical.material_name
        for fragment in component.fragments_by_id.values()
    ):
        raise MixedSourceExecutionError(
            "materialized Component does not exactly cover its canonical fragments"
        )
    kinds = {
        element.kind.value
        for fragment in component.fragments_by_id.values()
        for element in fragment.elements
    }
    allowed_kinds = {
        "orthogonal_hex": {"HEX8"},
        "structured_sweep": {"HEX8", "WEDGE6"},
        "conformal_hybrid": {"TET4", "HEX8", "WEDGE6", "PYRAMID5"},
    }[requirement.volume_topology]
    if component.backend != requirement.volume_topology or not kinds.issubset(
        allowed_kinds
    ):
        raise MixedSourceExecutionError(
            "materialized Component backend or element kinds differ from its "
            "requested topology"
        )


def _execute_role_free_mixed_source(
    context: MixedExecutionContext,
    *,
    verbose: bool = False,
) -> MixedSourceExecutionResult:
    """Execute every currently satisfiable component in authority-DAG order."""

    if type(context) is not MixedExecutionContext:
        raise MixedSourceExecutionError("context must be a MixedExecutionContext")
    if not isinstance(verbose, bool):
        raise MixedSourceExecutionError("verbose must be boolean")
    for identifier, component in context.lowering.canonical_components_by_global_id.items():
        if any(type(fragment.root) is CanonicalRectangularUnderfillFillet and fragment.root.uses_elliptical_sweep
               for fragment in component.fragments):
            if context.lowering.component_mesh_controls_by_global_id[identifier].volume_topology != "conformal_hybrid":
                raise MixedSourceExecutionError("不等宽或外扩 fillet 请在 Mesh 页选择 conformal_hybrid")
    plan = build_role_free_source_execution_plan(context)
    lowering = context.lowering

    completed: dict[str, MaterializedComponent] = {}
    patches: dict[str, MaterializedSurfacePatch] = {}
    pending: list[PendingExecutionDependency] = []
    from .package_v2_orthogonal_domain_execution import (
        execution_groups,
        incoming_external,
        materialize_group,
        publish_group,
        store_patch,
    )
    from .package_v2_orthogonal_domain_planning import OrthogonalConstraintError

    groups = execution_groups(context, plan)
    internal_orthogonal_seams = []
    remaining = list(plan.component_order)
    while remaining:
        component_id = next(
            (
                c
                for c in remaining
                if all(
                    f in patches
                    for f in (
                        incoming_external(plan, groups[c])
                        if c in groups
                        else plan.incoming_face_pair_ids_by_component[c]
                    )
                )
            ),
            None,
        )
        if component_id is None:
            # Resolve interleaved Orth -> non-Orth -> Orth dependencies by
            # publishing ready surfaces first. Those surfaces become locks
            # when the final group binds all upstream interfaces.
            advanced = False
            for group in dict.fromkeys(groups[c] for c in remaining if c in groups):
                ready_faces = {
                    a.face_pair_id
                    for a in plan.authority_plan.authorities
                    if a.producer_component_id in group
                    and a.consumer_component_id not in group
                    and a.face_pair_id not in patches
                    and all(
                        f in patches
                        or plan.authority_plan.authority_by_face_pair_id[
                            f
                        ].producer_component_id
                        in group
                        for f in plan.incoming_face_pair_ids_by_component[
                            a.producer_component_id
                        ]
                    )
                }
                if not ready_faces:
                    continue
                preview, _ = materialize_group(
                    context, plan, group, patches, verbose=verbose
                )
                _, produced = publish_group(context, plan, preview)
                for patch in produced:
                    if patch.face_pair_id in ready_faces:
                        store_patch(patches, patch)
                        advanced = True
            if advanced:
                continue
            if pending:
                pending.extend(
                    PendingExecutionDependency(
                        c,
                        "upstream_surface",
                        tuple(
                            f
                            for f in plan.incoming_face_pair_ids_by_component[c]
                            if f not in patches
                        ),
                        "upstream surface producer did not complete",
                    )
                    for c in remaining
                )
                break
            raise OrthogonalConstraintError(
                "orth_dependency_conflict",
                "接口生产依赖形成闭环，尚无可冻结的上游面。",
                components=tuple(remaining),
            )
        if component_id in groups:
            from .gmsh_candidate_runtime import (
                candidate_event_context,
                emit_candidate_event,
                has_candidate_observer,
            )
            from .package_v2_quality_history import component_quality_observation

            group = groups[component_id]
            for c in group:
                with candidate_event_context(component_id=c):
                    emit_candidate_event(
                        {
                            "stage": "component",
                            "state": "started",
                            "candidate": "orthogonal_hex",
                            "detail": "共同规划相接 Orth Solid 的局部正交网格",
                        }
                    )
            try:
                generated, shared = materialize_group(
                    context, plan, group, patches, verbose=verbose
                )
                generated, produced = publish_group(context, plan, generated)
                for patch in produced:
                    store_patch(patches, patch)
            except Exception as error:
                for c in group:
                    with candidate_event_context(component_id=c):
                        emit_candidate_event(
                            {
                                "stage": "component",
                                "state": "failed",
                                "candidate": "orthogonal_hex",
                                "detail": str(error),
                            }
                        )
                raise
            completed.update(generated)
            internal_orthogonal_seams.extend(shared)
            if has_candidate_observer():
                for c, value in generated.items():
                    with candidate_event_context(component_id=c):
                        observation = {
                            "stage": "component",
                            "state": "completed",
                            "candidate": "orthogonal_hex",
                            "element_count": sum(
                                len(f.elements) for f in value.fragments_by_id.values()
                            ),
                        }
                        try:
                            observation["metrics"] = component_quality_observation(
                                value
                            )
                        except Exception as error:
                            observation["detail"] = (
                                f"质量观测未完成：{error}；最终质量由写出审计检查。"
                            )
                        emit_candidate_event(observation)
            remaining = [c for c in remaining if c not in group]
            continue
        remaining.remove(component_id)
        def observed_materialization(function, *args, **kwargs):
            from .gmsh_candidate_runtime import candidate_event_context, emit_candidate_event, has_candidate_observer
            from .package_v2_quality_history import component_quality_observation

            with candidate_event_context(component_id=component_id):
                label = lowering.component_mesh_requirements[component_id].volume_topology
                emit_candidate_event({"stage": "component", "state": "started", "candidate": label})
                try:
                    result = function(*args, **kwargs)
                except Exception as error:
                    emit_candidate_event({"stage": "component", "state": "failed", "candidate": label, "detail": str(error)})
                    raise
                if has_candidate_observer():
                    observation = {"stage": "component", "state": "completed", "candidate": label,
                        "element_count": sum(len(f.elements) for f in result.fragments_by_id.values())}
                    try:
                        observation["metrics"] = component_quality_observation(result)
                    except Exception as error:
                        observation["detail"] = f"质量观测未完成：{error}；最终质量仍由写出审计检查。"
                    emit_candidate_event(observation)
                return result

        incoming = plan.incoming_face_pair_ids_by_component[component_id]
        missing = tuple(value for value in incoming if value not in patches)
        if missing:
            pending.append(
                PendingExecutionDependency(
                    component_id,
                    "upstream_surface",
                    missing,
                    "surface-authority producer has not materialized every "
                    "required incoming patch",
                )
            )
            continue
        topology = lowering.component_mesh_requirements[
            component_id
        ].volume_topology
        if topology == "conformal_hybrid":
            component = observed_materialization(_materialize_hybrid,
                context,
                plan,
                component_id,
                patches,
                verbose=verbose,
            )
        elif topology == "orthogonal_hex":
            try:
                component = observed_materialization(_materialize_orthogonal,
                    context, plan, component_id, patches
                )
            except MixedSourceExecutionError as error:
                code = (
                    "orth_geometry_unsupported"
                    if "not supported" in str(error)
                    or "requires canonical" in str(error)
                    or "first implementation" in str(error)
                    else "orth_locked_interface_conflict"
                )
                raise OrthogonalConstraintError(
                    code,
                    str(error),
                    components=(component_id,),
                    sources=tuple(
                        {
                            "component_id": plan.authority_plan.authority_by_face_pair_id[
                                f
                            ].producer_component_id,
                            "interface_id": f,
                        }
                        for f in incoming
                    ),
                ) from error
        elif topology == "structured_sweep":
            try:
                component = observed_materialization(_materialize_sweep,
                    context,
                    plan,
                    component_id,
                    patches,
                    verbose=verbose,
                )
            except MixedSourceExecutionError as error:
                pending.append(
                    PendingExecutionDependency(
                        component_id,
                        "structured_sweep_locked_section",
                        incoming,
                        str(error),
                    )
                )
                continue
        else:  # pragma: no cover - lowering validates the closed vocabulary
            raise MixedSourceExecutionError(
                f"unknown component topology {topology!r}"
            )

        outgoing_authorities = tuple(
            plan.authority_plan.authority_by_face_pair_id[value]
            for value in plan.outgoing_face_pair_ids_by_component[component_id]
        )
        component, produced = _retoken_outgoing_surfaces(
            context,
            component,
            lowering.canonical_components_by_global_id[component_id],
            outgoing_authorities,
        )
        completed[component_id] = component
        for patch in produced:
            if patch.face_pair_id in patches:
                raise MixedSourceExecutionError(
                    "one face pair was materialized by multiple authorities"
                )
            patches[patch.face_pair_id] = patch

    effective_surface_sizes = {}
    for face_id, patch in patches.items():
        authority = plan.authority_plan.authority_by_face_pair_id[face_id]
        maximum = max((math.dist(patch.node_coordinates_package_mm[a], patch.node_coordinates_package_mm[b])
            for facet in patch.facets for a,b in zip(facet, (*facet[1:], facet[0]))), default=0.)
        key = authority.continuity_group_id
        effective_surface_sizes[key] = max(effective_surface_sizes.get(key, 0.),
                                           authority.negotiated_target_edge_mm, maximum)

    facet_sets: dict[str, InterfaceFacetSet] = {}
    seams: list[DeclaredSharedSeam] = list(internal_orthogonal_seams)
    fragment_geometry = lowering.canonical_fragments_by_global_id
    for face_pair_id, patch in sorted(patches.items()):
        consumer = completed.get(patch.consumer_side.component_id)
        if consumer is None:
            continue
        authority = plan.authority_plan.authority_by_face_pair_id[face_pair_id]
        consumer_facets = _consumer_facets(
            consumer,
            patch,
            fragment_geometry[patch.consumer_side.fragment_id],
        )
        producer_fragment = completed[
            patch.producer_side.component_id
        ].fragments_by_id[patch.producer_side.fragment_id]
        consumer_fragment = consumer.fragments_by_id[
            patch.consumer_side.fragment_id
        ]
        consumer_tokens = {node.local_node_id: node.semantic_token for node in consumer_fragment.nodes}
        retained_signatures = {
            frozenset(consumer_tokens[node] for node in facet) for facet in consumer_facets
        }
        producer_facets = tuple(
            facet for facet in patch.facets
            if frozenset(patch.semantic_tokens_by_node_id[node] for node in facet) in retained_signatures
        )
        declared = declared_shared_seams_from_facets(
            producer_fragment,
            producer_facets,
            consumer_fragment,
            consumer_facets,
            seam_key_prefix=face_pair_id,
            sizing_contract_id=authority.continuity_group_id,
            target_edge_mm=effective_surface_sizes[authority.continuity_group_id],
        ) if producer_facets else ()
        facet_sets[face_pair_id] = InterfaceFacetSet(
            face_pair_id,
            patch.producer_side.fragment_id,
            producer_facets,
            patch.consumer_side.fragment_id,
            consumer_facets,
        )
        seams.extend(declared)

    frozen_sets, frozen_tokens, frozen_seams = _frozen_interface_outputs(
        context,
        completed,
    )
    seams.extend(frozen_seams)

    return MixedSourceExecutionResult(
        plan,
        MappingProxyType(completed),
        MappingProxyType(patches),
        MappingProxyType(facet_sets),
        frozen_sets,
        frozen_tokens,
        tuple(seams),
        _component_evidence(context, completed),
        tuple(pending),
        context.interface_geometry_tolerance_mm,
    )


def execute_role_free_mixed_source(
    context: MixedExecutionContext,
    *,
    verbose: bool = False,
) -> MixedSourceExecutionResult:
    """Execute the strategy DAG without any external volume-mesh injection."""

    if type(context) is not MixedExecutionContext:
        raise MixedSourceExecutionError("context must be a MixedExecutionContext")
    return _execute_role_free_mixed_source(
        context,
        verbose=verbose,
    )


def execute_compiled_mixed_source(
    compiled: PackageV2CompileResult,
    snapshot: FrozenSourceSnapshot,
    *,
    verbose: bool = False,
) -> MixedSourceExecutionResult:
    """High-level worker entry from compiler result and immutable snapshot."""

    if type(compiled) is not PackageV2CompileResult:
        raise MixedSourceExecutionError(
            "compiled must be a PackageV2CompileResult"
        )
    if type(snapshot) is not FrozenSourceSnapshot:
        raise MixedSourceExecutionError("snapshot must be a FrozenSourceSnapshot")
    lowering = lower_mixed_source(compiled, snapshot)
    context = build_mixed_execution_context(lowering, snapshot)
    from .gmsh_candidate_runtime import candidate_execution_context

    with candidate_execution_context(
        parallel_tet_candidates=compiled.parsed_source.document.mesh_settings.parallel_tet_candidates,
    ):
        return _execute_role_free_mixed_source(context, verbose=verbose)


def assemble_role_free_mixed_source(
    result: MixedSourceExecutionResult,
    snapshot: FrozenSourceSnapshot,
) -> MixedMeshAssemblyPlan:
    """Create the exact final assembly plan from a complete execution result."""

    if not isinstance(result, MixedSourceExecutionResult):
        raise MixedSourceExecutionError(
            "result must be a MixedSourceExecutionResult"
        )
    if not result.complete:
        raise MixedSourceExecutionError(
            "cannot assemble while execution dependencies remain pending"
        )
    if type(snapshot) is not FrozenSourceSnapshot:
        raise MixedSourceExecutionError("snapshot must be a FrozenSourceSnapshot")
    return assemble_mixed_volume_mesh(
        result.component_fragments,
        frozen_mesh=placed_frozen_volume_mesh(snapshot),
        declared_seams=result.declared_seams,
        expected_complete_support_plane_interfaces=(
            result.expected_complete_support_plane_interfaces
        ),
        interface_geometry_tolerance_mm=(
            result.interface_geometry_tolerance_mm
        ),
    )


def write_role_free_mixed_source(
    result: MixedSourceExecutionResult,
    snapshot: FrozenSourceSnapshot,
    output_path: str | Path,
    *,
    verbose: bool = False,
) -> MixedMeshWriteResult:
    """Publish and reopen the complete role-free mixed volume mesh."""

    if not isinstance(result, MixedSourceExecutionResult):
        raise MixedSourceExecutionError(
            "result must be a MixedSourceExecutionResult"
        )
    if not result.complete:
        raise MixedSourceExecutionError(
            "cannot write while execution dependencies remain pending"
        )
    if type(snapshot) is not FrozenSourceSnapshot:
        raise MixedSourceExecutionError("snapshot must be a FrozenSourceSnapshot")
    return write_mixed_volume_mesh(
        output_path,
        result.component_fragments,
        frozen_mesh=placed_frozen_volume_mesh(snapshot),
        declared_seams=result.declared_seams,
        expected_complete_support_plane_interfaces=(
            result.expected_complete_support_plane_interfaces
        ),
        interface_geometry_tolerance_mm=(
            result.interface_geometry_tolerance_mm
        ),
        verbose=verbose,
    )


__all__ = [
    "ComponentExecutionEvidence",
    "FrozenInterfaceFacetSet",
    "InterfaceFacetSet",
    "MaterializedComponent",
    "MaterializedSurfacePatch",
    "MixedSourceExecutionError",
    "MixedSourceExecutionResult",
    "PendingExecutionDependency",
    "RoleFreeSourceExecutionPlan",
    "build_role_free_source_execution_plan",
    "execute_compiled_mixed_source",
    "execute_role_free_mixed_source",
    "assemble_role_free_mixed_source",
    "plan_role_free_source_execution",
    "write_role_free_mixed_source",
]
