"""Role-free execution contracts for real generated-component adjacencies.

The planner binds four independent facts without inventing a package role:

* canonical fragment geometry identifies each real boundary-side pair;
* :class:`CommonFaceCapability` proves the component adjacency;
* :class:`NegotiatedComponentInterface` carries shared-surface topology;
* :class:`ComponentMeshRequirement` owns target and transition sizes.

The resulting reservation records can be consumed by a preserve-volume
propagation backend.  Physical surface producer selection is deliberately
absent here and belongs only to ``NeutralSurfaceAuthority``.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from types import MappingProxyType
from typing import Any, TypeAlias

from .component_interface import (
    CommonFaceCapability,
    ComponentMeshRequirement,
    NegotiatedComponentInterface,
    negotiate_component_interface,
)
from .gmsh_runtime import isolated_gmsh_model
from .package_v2_component_adjacency import (
    ComponentAdjacencyError,
    _occ_add_fillet,
    extract_component_adjacencies,
)
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalComponentGeometry,
    CanonicalGeneratedGeometry,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalRigidPlacement,
)
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)


Point3D: TypeAlias = tuple[float, float, float]
CanonicalComponentInput: TypeAlias = (
    CanonicalGeneratedGeometry
    | Mapping[str, CanonicalComponentGeometry]
    | Sequence[CanonicalComponentGeometry]
)
_OCC_SIDE_ABSOLUTE_TOLERANCE_MM = 5.0e-7


class AdjacencyExecutionError(ValueError):
    """Actual adjacency geometry and negotiated policy do not form one plan."""


@dataclass(frozen=True, slots=True, order=True)
class CanonicalAdjacentSide:
    component_id: str
    fragment_id: str
    side_name: str

    def to_dict(self) -> dict[str, str]:
        return {
            "component_id": self.component_id,
            "fragment_id": self.fragment_id,
            "side_name": self.side_name,
        }


@dataclass(frozen=True, slots=True)
class AdjacentFaceExecutionContract:
    face_pair_id: str
    interface_id: str
    first_side: CanonicalAdjacentSide
    second_side: CanonicalAdjacentSide
    surface_policy: str
    permitted_surface_element_kinds: tuple[str, ...]
    interface_target_edge_mm: float
    component_target_edge_mm_by_component: Mapping[str, float]
    transition_distance_mm_by_component: Mapping[str, float]
    volume_topology_by_component: Mapping[str, str]
    permitted_volume_element_kinds_by_component: Mapping[
        str, tuple[str, ...]
    ]
    area_mm2: float
    geometric_patch_count: int

    def __post_init__(self) -> None:
        for field_name in (
            "component_target_edge_mm_by_component",
            "transition_distance_mm_by_component",
            "volume_topology_by_component",
            "permitted_volume_element_kinds_by_component",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )

    @property
    def shared_topology(self) -> str:
        return self.surface_policy

    def to_dict(self) -> dict[str, object]:
        return {
            "face_pair_id": self.face_pair_id,
            "interface_id": self.interface_id,
            "first_side": self.first_side.to_dict(),
            "second_side": self.second_side.to_dict(),
            "shared_topology": self.shared_topology,
            "permitted_surface_element_kinds": list(
                self.permitted_surface_element_kinds
            ),
            "interface_target_edge_mm": self.interface_target_edge_mm,
            "component_target_edge_mm_by_component": dict(
                self.component_target_edge_mm_by_component
            ),
            "transition_distance_mm_by_component": dict(
                self.transition_distance_mm_by_component
            ),
            "volume_topology_by_component": dict(
                self.volume_topology_by_component
            ),
            "permitted_volume_element_kinds_by_component": {
                key: list(value)
                for key, value in self.permitted_volume_element_kinds_by_component.items()
            },
            "area_mm2": self.area_mm2,
            "geometric_patch_count": self.geometric_patch_count,
        }


@dataclass(frozen=True, slots=True)
class ReservedTargetBoundarySource:
    component_id: str
    fragment_id: str
    target_boundary_name: str
    interface_id: str
    face_pair_id: str
    actual_side_name: str

    def to_dict(self) -> dict[str, str]:
        return {
            "component_id": self.component_id,
            "fragment_id": self.fragment_id,
            "target_boundary_name": self.target_boundary_name,
            "interface_id": self.interface_id,
            "face_pair_id": self.face_pair_id,
            "actual_side_name": self.actual_side_name,
        }


@dataclass(frozen=True, slots=True)
class ComponentBoundaryReservation:
    component_id: str
    fragment_id: str
    reserved_target_boundary_names: tuple[str, ...]
    sources: tuple[ReservedTargetBoundarySource, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "component_id": self.component_id,
            "fragment_id": self.fragment_id,
            "reserved_target_boundary_names": list(
                self.reserved_target_boundary_names
            ),
            "sources": [value.to_dict() for value in self.sources],
        }


@dataclass(frozen=True, slots=True)
class ComponentAdjacencyExecutionPlan:
    face_pairs: tuple[AdjacentFaceExecutionContract, ...]
    boundary_reservations: tuple[ComponentBoundaryReservation, ...]
    face_pairs_by_interface: Mapping[
        str, tuple[AdjacentFaceExecutionContract, ...]
    ]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "face_pairs_by_interface",
            MappingProxyType(dict(self.face_pairs_by_interface)),
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "face_pairs": [value.to_dict() for value in self.face_pairs],
            "boundary_reservations": [
                value.to_dict() for value in self.boundary_reservations
            ],
        }


@dataclass(frozen=True, slots=True)
class _GeometricSidePair:
    first_fragment_id: str
    first_side_name: str
    second_fragment_id: str
    second_side_name: str
    area_mm2: float
    patch_count: int


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise AdjacencyExecutionError(
            "Gmsh is required to enumerate actual adjacency faces"
        ) from error
    return gmsh


def _add_root(gmsh: Any, root: object) -> tuple[int, ...]:
    from .package_v2_geometry import CanonicalUnion, CanonicalDifference

    if isinstance(root, (CanonicalUnion, CanonicalDifference)):
        from .package_v2_component_adjacency import _occ_add_root

        return _occ_add_root(gmsh, root)
    if type(root) is CanonicalBox:
        return (
            int(
                gmsh.model.occ.addBox(
                    *root.origin_xyz_mm,
                    *root.size_xyz_mm,
                )
            ),
        )
    if type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        outer = int(
            gmsh.model.occ.addBox(
                x0,
                y0,
                z0,
                root.outer_size_xy_mm[0],
                root.outer_size_xy_mm[1],
                root.height_mm,
            )
        )
        inner = int(
            gmsh.model.occ.addBox(
                x0 + root.opening_offset_xy_mm[0],
                y0 + root.opening_offset_xy_mm[1],
                z0,
                root.opening_size_xy_mm[0],
                root.opening_size_xy_mm[1],
                root.height_mm,
            )
        )
        cut, _mapping = gmsh.model.occ.cut(
            [(3, outer)],
            [(3, inner)],
            removeObject=True,
            removeTool=True,
        )
        result = tuple(
            int(tag) for dimension, tag in cut if int(dimension) == 3
        )
        if not result:
            raise AdjacencyExecutionError(
                "OCC did not construct a canonical rectangular frame"
            )
        return result
    if type(root) is CanonicalRectangularUnderfillFillet:
        try:
            return _occ_add_fillet(gmsh, root)
        except ValueError as error:
            raise AdjacencyExecutionError(str(error)) from error
    raise AdjacencyExecutionError(
        "actual adjacency side enumeration supports canonical Box, Frame and "
        "RectangularUnderfillFillet fragments"
    )


def _apply_placement(
    gmsh: Any,
    volume_tags: Sequence[int],
    placement: CanonicalRigidPlacement,
) -> None:
    values = [(3, int(tag)) for tag in volume_tags]
    pivot = placement.pivot_xyz_mm
    for axis, angle in (
        ((1.0, 0.0, 0.0), placement.rotation_deg_xyz[0]),
        ((0.0, 1.0, 0.0), placement.rotation_deg_xyz[1]),
        ((0.0, 0.0, 1.0), placement.rotation_deg_xyz[2]),
    ):
        if angle != 0.0:
            gmsh.model.occ.rotate(
                values,
                *pivot,
                *axis,
                math.radians(angle),
            )
    if placement.translation_xyz_mm != (0.0, 0.0, 0.0):
        gmsh.model.occ.translate(values, *placement.translation_xyz_mm)


def _rotation_matrix(
    placement: CanonicalRigidPlacement,
) -> tuple[Point3D, Point3D, Point3D]:
    rx, ry, rz = (math.radians(value) for value in placement.rotation_deg_xyz)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    rotate_x = (
        (1.0, 0.0, 0.0),
        (0.0, cx, -sx),
        (0.0, sx, cx),
    )
    rotate_y = (
        (cy, 0.0, sy),
        (0.0, 1.0, 0.0),
        (-sy, 0.0, cy),
    )
    rotate_z = (
        (cz, -sz, 0.0),
        (sz, cz, 0.0),
        (0.0, 0.0, 1.0),
    )

    def multiply(
        left: Sequence[Sequence[float]],
        right: Sequence[Sequence[float]],
    ) -> tuple[Point3D, Point3D, Point3D]:
        return tuple(
            tuple(
                math.fsum(
                    left[row][inner] * right[inner][column]
                    for inner in range(3)
                )
                for column in range(3)
            )
            for row in range(3)
        )  # type: ignore[return-value]

    return multiply(rotate_z, multiply(rotate_y, rotate_x))


def _package_to_local(
    point: Point3D,
    placement: CanonicalRigidPlacement,
) -> Point3D:
    pivot = placement.pivot_xyz_mm
    translated = tuple(
        point[axis] - placement.translation_xyz_mm[axis] - pivot[axis]
        for axis in range(3)
    )
    rotation = _rotation_matrix(placement)
    return tuple(
        pivot[axis]
        + math.fsum(
            rotation[source_axis][axis] * translated[source_axis]
            for source_axis in range(3)
        )
        for axis in range(3)
    )  # type: ignore[return-value]


def _close(first: float, second: float, tolerance: float) -> bool:
    return abs(first - second) <= tolerance


def _all_on(
    points: Sequence[Point3D],
    axis: int,
    coordinate: float,
    tolerance: float,
) -> bool:
    return all(_close(point[axis], coordinate, tolerance) for point in points)


def _within(value: float, bounds: tuple[float, float], tolerance: float) -> bool:
    return bounds[0] - tolerance <= value <= bounds[1] + tolerance


def _outside_die_distance(
    root: CanonicalRectangularUnderfillFillet,
    point: Point3D,
) -> float:
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    return math.hypot(
        max(x0 - point[0], 0.0, point[0] - x1),
        max(y0 - point[1], 0.0, point[1] - y1),
    )


def _fillet_width(
    root: CanonicalRectangularUnderfillFillet,
    z_value: float,
) -> float:
    ratio = (z_value - root.base_z_mm) / root.wall_height_mm
    if root.uses_elliptical_sweep:
        from .package_v2_swept_fillet import widths_at
        return max(widths_at(root, ratio))
    return root.toe_width_mm + ratio * (
        root.top_width_mm - root.toe_width_mm
    )


def _classify_local_side(
    fragment: CanonicalGeometryFragment,
    package_points: Sequence[Point3D],
    interface_geometry_tolerance_mm: float,
) -> str:
    points = tuple(
        _package_to_local(point, fragment.placement)
        for point in package_points
    )
    root = fragment.root
    scale = max(
        1.0,
        *(abs(coordinate) for point in points for coordinate in point),
    )
    tolerance = max(
        1.0e-9 * scale,
        interface_geometry_tolerance_mm,
    )
    candidates: list[str] = []
    if type(root) is CanonicalBox:
        bounds = tuple(
            (
                root.origin_xyz_mm[axis],
                root.origin_xyz_mm[axis] + root.size_xyz_mm[axis],
            )
            for axis in range(3)
        )
        for axis, axis_name in enumerate(("x", "y", "z")):
            for coordinate, suffix in (
                (bounds[axis][0], "min"),
                (bounds[axis][1], "max"),
            ):
                if _all_on(points, axis, coordinate, tolerance):
                    candidates.append(f"{axis_name}_{suffix}")
    elif type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        x1 = x0 + root.outer_size_xy_mm[0]
        y1 = y0 + root.outer_size_xy_mm[1]
        z1 = z0 + root.height_mm
        hx0 = x0 + root.opening_offset_xy_mm[0]
        hy0 = y0 + root.opening_offset_xy_mm[1]
        hx1 = hx0 + root.opening_size_xy_mm[0]
        hy1 = hy0 + root.opening_size_xy_mm[1]
        for coordinate, name in ((z0, "z_min"), (z1, "z_max")):
            if _all_on(points, 2, coordinate, tolerance):
                candidates.append(name)
        for name, axis, coordinate, tangent, tangent_bounds in (
            ("outer_x_min", 0, x0, 1, (y0, y1)),
            ("outer_x_max", 0, x1, 1, (y0, y1)),
            ("outer_y_min", 1, y0, 0, (x0, x1)),
            ("outer_y_max", 1, y1, 0, (x0, x1)),
            ("opening_x_min", 0, hx0, 1, (hy0, hy1)),
            ("opening_x_max", 0, hx1, 1, (hy0, hy1)),
            ("opening_y_min", 1, hy0, 0, (hx0, hx1)),
            ("opening_y_max", 1, hy1, 0, (hx0, hx1)),
        ):
            if _all_on(points, axis, coordinate, tolerance) and all(
                _within(point[tangent], tangent_bounds, tolerance)
                for point in points
            ):
                candidates.append(name)
    elif type(root) is CanonicalRectangularUnderfillFillet:
        x0, y0 = root.die_origin_xy_mm
        x1 = x0 + root.die_size_xy_mm[0]
        y1 = y0 + root.die_size_xy_mm[1]
        z0 = root.base_z_mm
        z1 = z0 + root.wall_height_mm
        for coordinate, name in ((z0, "z_min"), (z1, "z_max")):
            if _all_on(points, 2, coordinate, tolerance):
                candidates.append(name)
        for name, axis, coordinate, tangent, tangent_bounds in (
            ("die_x_min", 0, x0, 1, (y0, y1)),
            ("die_x_max", 0, x1, 1, (y0, y1)),
            ("die_y_min", 1, y0, 0, (x0, x1)),
            ("die_y_max", 1, y1, 0, (x0, x1)),
        ):
            if _all_on(points, axis, coordinate, tolerance) and all(
                _within(point[tangent], tangent_bounds, tolerance)
                for point in points
            ):
                candidates.append(name)
        from .package_v2_swept_fillet import on_outer_surface
        if not candidates and all(
            _within(point[2], (z0, z1), tolerance)
            and (on_outer_surface(root, point, tolerance) if root.uses_elliptical_sweep else
                 _close(_outside_die_distance(root, point), _fillet_width(root, min(max(point[2], z0), z1)), tolerance))
            for point in points
        ):
            candidates.append("analytic_free_surface")
    else:
        from .package_v2_geometry import CanonicalUnion, CanonicalDifference

        if isinstance(root, (CanonicalUnion, CanonicalDifference)):
            from .package_v2_orthogonal_domain_planning import classify_rectilinear_side

            side = classify_rectilinear_side(root, points, tolerance)
            if side is not None:
                return side
        raise AdjacencyExecutionError(
            "unsupported canonical fragment reached side classification"
        )
    if len(candidates) != 1:
        raise AdjacencyExecutionError(
            f"actual surface on fragment {fragment.fragment_id!r} has "
            f"ambiguous canonical side identity {tuple(candidates)!r}"
        )
    return candidates[0]


def _surface_points(gmsh: Any, surface_tag: int) -> tuple[Point3D, ...]:
    point_tags = tuple(
        int(tag)
        for dimension, tag in gmsh.model.getBoundary(
            [(2, surface_tag)],
            oriented=False,
            recursive=True,
        )
        if int(dimension) == 0
    )
    points = tuple(
        tuple(float(value) for value in gmsh.model.getValue(0, tag, ()))
        for tag in sorted(set(point_tags))
    )
    if points:
        return points  # type: ignore[return-value]
    center = tuple(
        float(value) for value in gmsh.model.occ.getCenterOfMass(2, surface_tag)
    )
    if len(center) != 3 or any(not math.isfinite(value) for value in center):
        raise AdjacencyExecutionError(
            "OCC shared surface has no finite classification sample"
        )
    return (center,)  # type: ignore[return-value]


def _volume_surfaces(gmsh: Any, volume_tag: int) -> tuple[int, ...]:
    return tuple(
        int(tag)
        for dimension, tag in gmsh.model.getBoundary(
            [(3, int(volume_tag))],
            oriented=False,
            recursive=False,
        )
        if int(dimension) == 2
    )


def _enumerate_component_pair_sides(
    first: CanonicalComponentGeometry,
    second: CanonicalComponentGeometry,
    interface_geometry_tolerance_mm: float,
) -> tuple[_GeometricSidePair, ...]:
    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_actual_adjacency_execution",
        number_options={
            "General.Terminal": 0.0,
            "Geometry.Tolerance": interface_geometry_tolerance_mm,
        },
    ):
        records: list[tuple[str, CanonicalGeometryFragment, int]] = []
        first_input_count = 0
        for component_index, component in enumerate((first, second)):
            for fragment in component.fragments:
                volumes = _add_root(gmsh, fragment.root)
                _apply_placement(gmsh, volumes, fragment.placement)
                for tag in volumes:
                    records.append((component.component_id, fragment, tag))
                    if component_index == 0:
                        first_input_count += 1
        objects = [(3, value[2]) for value in records[:first_input_count]]
        tools = [(3, value[2]) for value in records[first_input_count:]]
        if not objects or not tools:
            raise AdjacencyExecutionError(
                "actual component adjacency requires geometry on both sides"
            )
        _fragmented, raw_mapping = gmsh.model.occ.fragment(
            objects,
            tools,
            removeObject=True,
            removeTool=True,
        )
        gmsh.model.occ.synchronize()
        if len(raw_mapping) != len(records):
            raise AdjacencyExecutionError(
                "OCC fragment mapping lost canonical fragment ownership"
            )
        outputs_by_fragment: dict[str, set[int]] = defaultdict(set)
        outputs_by_component: dict[str, set[int]] = defaultdict(set)
        fragment_by_id: dict[str, CanonicalGeometryFragment] = {}
        for (component_id, fragment, _tag), mapped in zip(records, raw_mapping):
            resolved = {
                int(tag)
                for dimension, tag in mapped
                if int(dimension) == 3
            }
            if not resolved:
                raise AdjacencyExecutionError(
                    "OCC fragment mapping removed a canonical positive volume"
                )
            outputs_by_fragment[fragment.fragment_id].update(resolved)
            outputs_by_component[component_id].update(resolved)
            fragment_by_id[fragment.fragment_id] = fragment

        overlap = (
            outputs_by_component[first.component_id]
            & outputs_by_component[second.component_id]
        )
        if any(
            float(gmsh.model.occ.getMass(3, tag))
            > interface_geometry_tolerance_mm**3
            for tag in overlap
        ):
            raise AdjacencyExecutionError(
                "actual component adjacency overlaps by positive volume"
            )
        surface_by_volume = {
            volume: _volume_surfaces(gmsh, volume)
            for volumes in outputs_by_component.values()
            for volume in volumes
        }

        def external_surfaces(component_id: str) -> set[int]:
            counts: Counter[int] = Counter(
                surface
                for volume in outputs_by_component[component_id]
                for surface in surface_by_volume[volume]
            )
            return {surface for surface, count in counts.items() if count == 1}

        shared = external_surfaces(first.component_id) & external_surfaces(
            second.component_id
        )
        grouped_area: dict[tuple[str, str, str, str], float] = defaultdict(float)
        grouped_count: Counter[tuple[str, str, str, str]] = Counter()
        for surface in sorted(shared):
            area = float(gmsh.model.occ.getMass(2, surface))
            if (
                not math.isfinite(area)
                or area <= interface_geometry_tolerance_mm**2
            ):
                continue

            def owning_fragment(component_id: str) -> str:
                candidates = tuple(
                    sorted(
                        fragment_id
                        for fragment_id, volumes in outputs_by_fragment.items()
                        if any(
                            surface in surface_by_volume[volume]
                            for volume in volumes
                        )
                        and any(
                            value[0] == component_id
                            and value[1].fragment_id == fragment_id
                            for value in records
                        )
                    )
                )
                if len(candidates) != 1:
                    raise AdjacencyExecutionError(
                        "one actual shared surface has ambiguous canonical "
                        f"fragment ownership on component {component_id!r}"
                    )
                return candidates[0]

            first_fragment_id = owning_fragment(first.component_id)
            second_fragment_id = owning_fragment(second.component_id)
            points = _surface_points(gmsh, surface)
            first_side = _classify_local_side(
                fragment_by_id[first_fragment_id],
                points,
                interface_geometry_tolerance_mm,
            )
            second_side = _classify_local_side(
                fragment_by_id[second_fragment_id],
                points,
                interface_geometry_tolerance_mm,
            )
            key = (
                first_fragment_id,
                first_side,
                second_fragment_id,
                second_side,
            )
            grouped_area[key] += area
            grouped_count[key] += 1
        if not grouped_area:
            raise AdjacencyExecutionError(
                "declared component adjacency has no enumerated positive-area "
                "canonical side pair"
            )
        return tuple(
            _GeometricSidePair(*key, grouped_area[key], grouped_count[key])
            for key in sorted(grouped_area)
        )


def _normalized_inputs(
    canonical_components: CanonicalComponentInput,
    requirements: Mapping[str, ComponentMeshRequirement],
    adjacencies: Sequence[CommonFaceCapability],
    negotiated_interfaces: Sequence[NegotiatedComponentInterface],
    interface_geometry_tolerance_mm: float,
) -> tuple[
    Mapping[str, CanonicalComponentGeometry],
    Mapping[str, ComponentMeshRequirement],
    tuple[CommonFaceCapability, ...],
    Mapping[str, NegotiatedComponentInterface],
]:
    if type(canonical_components) is CanonicalGeneratedGeometry:
        components = canonical_components.components
    elif isinstance(canonical_components, Mapping):
        if any(
            not isinstance(key, str)
            or type(value) is not CanonicalComponentGeometry
            or key != value.component_id
            for key, value in canonical_components.items()
        ):
            raise AdjacencyExecutionError(
                "canonical component mapping keys must equal component IDs"
            )
        components = tuple(canonical_components.values())
    elif not isinstance(canonical_components, (str, bytes)) and isinstance(
        canonical_components, Sequence
    ):
        components = tuple(canonical_components)
    else:
        raise AdjacencyExecutionError(
            "canonical_components must be generated geometry, a component "
            "mapping, or a component sequence"
        )
    if not components or any(
        type(value) is not CanonicalComponentGeometry for value in components
    ):
        raise AdjacencyExecutionError(
            "canonical_components must contain canonical component geometry"
        )
    component_ids = tuple(value.component_id for value in components)
    if len(set(component_ids)) != len(component_ids):
        raise AdjacencyExecutionError(
            "canonical component IDs must be unique"
        )
    fragment_ids = tuple(
        fragment.fragment_id
        for component in components
        for fragment in component.fragments
    )
    if len(set(fragment_ids)) != len(fragment_ids):
        raise AdjacencyExecutionError(
            "canonical fragment IDs must be globally unique"
        )
    if not isinstance(requirements, Mapping):
        raise AdjacencyExecutionError(
            "requirements must map canonical component IDs"
        )
    component_by_id = {
        component.component_id: component
        for component in sorted(
            components,
            key=lambda value: value.component_id,
        )
    }
    if set(requirements) != set(component_by_id):
        raise AdjacencyExecutionError(
            "requirement keys must exactly match canonical components"
        )
    normalized_requirements: dict[str, ComponentMeshRequirement] = {}
    for component_id in sorted(component_by_id):
        requirement = requirements[component_id]
        if (
            type(requirement) is not ComponentMeshRequirement
            or requirement.component_id != component_id
        ):
            raise AdjacencyExecutionError(
                "component requirement identity is invalid"
            )
        normalized_requirements[component_id] = requirement

    if (
        isinstance(adjacencies, (str, bytes))
        or not isinstance(adjacencies, Sequence)
        or any(type(value) is not CommonFaceCapability for value in adjacencies)
    ):
        raise AdjacencyExecutionError(
            "adjacencies must contain CommonFaceCapability values"
        )
    normalized_adjacencies = tuple(
        sorted(adjacencies, key=lambda value: value.interface_id)
    )
    if len({value.interface_id for value in normalized_adjacencies}) != len(
        normalized_adjacencies
    ):
        raise AdjacencyExecutionError(
            "adjacency interface IDs must be unique"
        )
    supplied_by_pair: dict[tuple[str, str], CommonFaceCapability] = {}
    for capability in normalized_adjacencies:
        key = (
            capability.first_component_id,
            capability.second_component_id,
        )
        if (
            key[0] not in component_by_id
            or key[1] not in component_by_id
            or key in supplied_by_pair
        ):
            raise AdjacencyExecutionError(
                "adjacencies must uniquely identify canonical component pairs"
            )
        supplied_by_pair[key] = capability
    try:
        geometry_adjacencies = extract_component_adjacencies(
            tuple(component_by_id.values()),
            interface_namespace="__execution_geometry__",
            interface_geometry_tolerance_mm=(
                interface_geometry_tolerance_mm
            ),
        )
    except ComponentAdjacencyError as error:
        raise AdjacencyExecutionError(
            "canonical component adjacency geometry is invalid"
        ) from error
    geometry_by_pair = {
        (
            capability.first_component_id,
            capability.second_component_id,
        ): capability
        for capability in geometry_adjacencies
    }
    if set(supplied_by_pair) != set(geometry_by_pair):
        raise AdjacencyExecutionError(
            "adjacencies do not exactly cover real canonical geometry pairs"
        )
    for key, supplied in supplied_by_pair.items():
        actual = geometry_by_pair[key]
        if (
            supplied.axis_aligned_planar != actual.axis_aligned_planar
            or supplied.sweep_section_compatible
            != actual.sweep_section_compatible
            or supplied.transport_evidence != actual.transport_evidence
        ):
            raise AdjacencyExecutionError(
                "adjacency capability is not the real canonical geometry result"
            )

    if (
        isinstance(negotiated_interfaces, (str, bytes))
        or not isinstance(negotiated_interfaces, Sequence)
        or any(
            type(value) is not NegotiatedComponentInterface
            for value in negotiated_interfaces
        )
    ):
        raise AdjacencyExecutionError(
            "negotiated_interfaces must contain negotiated policies"
        )
    negotiated_by_id: dict[str, NegotiatedComponentInterface] = {}
    capability_by_id = {
        value.interface_id: value for value in normalized_adjacencies
    }
    for supplied in negotiated_interfaces:
        capability = capability_by_id.get(supplied.interface_id)
        if capability is None or supplied.interface_id in negotiated_by_id:
            raise AdjacencyExecutionError(
                "negotiated interface IDs must exactly cover adjacencies"
            )
        expected = negotiate_component_interface(
            capability,
            normalized_requirements[capability.first_component_id],
            normalized_requirements[capability.second_component_id],
        )
        if supplied != expected:
            raise AdjacencyExecutionError(
                "negotiated interface policy is stale or non-canonical"
            )
        negotiated_by_id[supplied.interface_id] = supplied
    if set(negotiated_by_id) != set(capability_by_id):
        raise AdjacencyExecutionError(
            "negotiated interfaces do not cover every real adjacency"
        )
    return (
        MappingProxyType(component_by_id),
        MappingProxyType(normalized_requirements),
        normalized_adjacencies,
        MappingProxyType(negotiated_by_id),
    )


def plan_component_adjacency_execution(
    canonical_components: CanonicalComponentInput,
    requirements: Mapping[str, ComponentMeshRequirement],
    adjacencies: Sequence[CommonFaceCapability],
    negotiated_interfaces: Sequence[NegotiatedComponentInterface],
    *,
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
) -> ComponentAdjacencyExecutionPlan:
    """Bind real canonical side pairs to their negotiated execution policy."""

    try:
        tolerance = validate_interface_geometry_tolerance_mm(
            interface_geometry_tolerance_mm
        )
    except ValueError as error:
        raise AdjacencyExecutionError(str(error)) from error
    (
        component_by_id,
        normalized_requirements,
        normalized_adjacencies,
        policy_by_id,
    ) = _normalized_inputs(
        canonical_components,
        requirements,
        adjacencies,
        negotiated_interfaces,
        tolerance,
    )
    face_pairs: list[AdjacentFaceExecutionContract] = []
    reservation_sources: list[ReservedTargetBoundarySource] = []
    for capability in normalized_adjacencies:
        policy = policy_by_id[capability.interface_id]
        first_component = component_by_id[capability.first_component_id]
        second_component = component_by_id[capability.second_component_id]
        geometric_pairs = _enumerate_component_pair_sides(
            first_component,
            second_component,
            tolerance,
        )
        transition_by_component = MappingProxyType(
            {
                policy.component_ids[0]: policy.first_transition_distance_mm,
                policy.component_ids[1]: policy.second_transition_distance_mm,
            }
        )
        target_by_component = MappingProxyType(
            {
                component_id: normalized_requirements[component_id].target_edge_mm
                for component_id in policy.component_ids
            }
        )
        topology_by_component = MappingProxyType(
            {
                component_id: normalized_requirements[
                    component_id
                ].volume_topology
                for component_id in policy.component_ids
            }
        )
        permitted_volume_by_component = MappingProxyType(
            {
                policy.component_ids[0]: policy.first_permitted_volume_element_kinds,
                policy.component_ids[1]: policy.second_permitted_volume_element_kinds,
            }
        )
        for index, geometric in enumerate(geometric_pairs, start=1):
            face_pair_id = f"{capability.interface_id}/face-pair/{index:04d}"
            first_side = CanonicalAdjacentSide(
                capability.first_component_id,
                geometric.first_fragment_id,
                geometric.first_side_name,
            )
            second_side = CanonicalAdjacentSide(
                capability.second_component_id,
                geometric.second_fragment_id,
                geometric.second_side_name,
            )
            contract = AdjacentFaceExecutionContract(
                face_pair_id,
                capability.interface_id,
                first_side,
                second_side,
                policy.surface_policy,
                policy.permitted_surface_element_kinds,
                policy.interface_target_edge_mm,
                target_by_component,
                transition_by_component,
                topology_by_component,
                permitted_volume_by_component,
                geometric.area_mm2,
                geometric.patch_count,
            )
            face_pairs.append(contract)
            for side in (first_side, second_side):
                reservation_sources.append(
                    ReservedTargetBoundarySource(
                        side.component_id,
                        side.fragment_id,
                        side.side_name,
                        capability.interface_id,
                        face_pair_id,
                        side.side_name,
                    )
                )

    grouped_reservations: dict[
        tuple[str, str], list[ReservedTargetBoundarySource]
    ] = defaultdict(list)
    for source in reservation_sources:
        grouped_reservations[(source.component_id, source.fragment_id)].append(
            source
        )
    reservations = tuple(
        ComponentBoundaryReservation(
            component_id,
            fragment_id,
            tuple(
                sorted(
                    {
                        source.target_boundary_name
                        for source in grouped_reservations[
                            (component_id, fragment_id)
                        ]
                    }
                )
            ),
            tuple(
                sorted(
                    grouped_reservations[(component_id, fragment_id)],
                    key=lambda value: (
                        value.target_boundary_name,
                        value.interface_id,
                        value.face_pair_id,
                    ),
                )
            ),
        )
        for component_id, fragment_id in sorted(grouped_reservations)
    )
    ordered_pairs = tuple(
        sorted(face_pairs, key=lambda value: value.face_pair_id)
    )
    by_interface: dict[str, list[AdjacentFaceExecutionContract]] = defaultdict(
        list
    )
    for value in ordered_pairs:
        by_interface[value.interface_id].append(value)
    return ComponentAdjacencyExecutionPlan(
        ordered_pairs,
        reservations,
        MappingProxyType(
            {
                interface_id: tuple(values)
                for interface_id, values in sorted(by_interface.items())
            }
        ),
    )


__all__ = [
    "AdjacentFaceExecutionContract",
    "AdjacencyExecutionError",
    "CanonicalAdjacentSide",
    "CanonicalComponentInput",
    "ComponentAdjacencyExecutionPlan",
    "ComponentBoundaryReservation",
    "ReservedTargetBoundarySource",
    "plan_component_adjacency_execution",
]
