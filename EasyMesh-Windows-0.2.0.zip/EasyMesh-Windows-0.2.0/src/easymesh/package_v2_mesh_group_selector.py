"""Responsive group selection from bounded MSH metadata, with stale-read guards."""
from threading import Event

from PySide6.QtCore import QObject, QRunnable, QThreadPool, QTimer, Qt, Signal
from PySide6.QtWidgets import QHBoxLayout, QLabel, QLineEdit, QPushButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget

from .package_v2_mesh_groups import mesh_file_signature, read_mesh_volume_groups


class _ScanSignals(QObject):
    finished = Signal(int, object, str)


class _GroupScan(QRunnable):
    def __init__(self, generation, path):
        super().__init__()
        self.generation, self.path = generation, path
        self.cancelled = Event()
        self.signals = _ScanSignals()

    def run(self):
        try:
            result = read_mesh_volume_groups(self.path, cancelled=self.cancelled.is_set)
        except (OSError, ValueError) as error:
            result, message = None, str(error)
        else:
            message = ""
        if not self.cancelled.is_set():
            self.signals.finished.emit(self.generation, result, message)


class MeshGroupSelector(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.catalog = None
        self.path = None
        self._generation = 0
        self._scan = None
        self._preferred = ()
        self._preserve_unread = False
        self._loading = False
        self._error = "请先选择网格文件。"
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("筛选体分组名称")
        self.search.textChanged.connect(self._filter)
        row.addWidget(self.search, 1)
        self.reload_button = QPushButton("重新读取")
        self.reload_button.clicked.connect(self.reload)
        row.addWidget(self.reload_button)
        layout.addLayout(row)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["网格分组"])
        self.tree.setRootIsDecorated(False)
        self.tree.setSelectionMode(QTreeWidget.SelectionMode.NoSelection)
        self.tree.setMinimumHeight(100)
        self.tree.setMaximumHeight(145)
        self.tree.setColumnWidth(0, 330)
        self.tree.itemChanged.connect(self._selection_changed)
        layout.addWidget(self.tree)
        self.status = QLabel(self._error)
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.status)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(180)
        self.timer.timeout.connect(self.reload)

    @property
    def loading(self):
        return self._loading

    def cancel(self):
        self.timer.stop()
        self._generation += 1
        if self._scan is not None:
            self._scan.cancelled.set()
            self._scan = None
        self._loading = False

    def set_mesh(self, path, *, preferred=(), preserve_unread=False, immediate=False):
        self.cancel()
        self.path = path
        self.catalog = None
        self._preferred = tuple(preferred)
        self._preserve_unread = bool(preserve_unread)
        self._error = "正在读取文件头部的体分组…" if path else "请先选择网格文件。"
        self._loading = bool(path)
        self._fill_unread()
        self.status.setText(self._error)
        if path:
            self.reload() if immediate else self.timer.start()

    def reload(self):
        if self.path is None:
            return
        if self.catalog is not None:
            self._preferred = self.checked_names()
        self.cancel()
        self.catalog = None
        self._loading = True
        self.tree.setEnabled(False)
        self.status.setText("正在读取文件头部的体分组…")
        scan = _GroupScan(self._generation, self.path)
        scan.signals.finished.connect(self._loaded)
        self._scan = scan
        QThreadPool.globalInstance().start(scan)

    def _fill_unread(self):
        self.tree.clear()
        for name in self._preferred:
            item = QTreeWidgetItem(self.tree, [name])
            item.setToolTip(0, "未读取")
            item.setCheckState(0, Qt.CheckState.Checked)
        self.tree.setEnabled(False)

    def _loaded(self, generation, catalog, error):
        if generation != self._generation:
            return
        self._loading = False
        self._scan = None
        self.catalog, self._error = catalog, error
        if catalog is None:
            self._fill_unread()
            self.status.setText(error + (" 已保留原分组，可仅修改实例摆放。" if self._preserve_unread else ""))
            return
        selected = self._preferred or catalog.default_selection()
        self.tree.blockSignals(True)
        self.tree.clear()
        for group in catalog.groups:
            item = QTreeWidgetItem(self.tree, [group.name])
            item.setData(0, Qt.ItemDataRole.UserRole, group.name)
            item.setCheckState(0, Qt.CheckState.Checked if group.name in selected else Qt.CheckState.Unchecked)
            item.setToolTip(0, group.error or "可以只使用这个分组。")
            if group.error and group.name not in selected:
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
        available = {group.name for group in catalog.groups}
        for name in selected:
            if name not in available:
                item = QTreeWidgetItem(self.tree, [name])
                item.setToolTip(0, "网格中不存在")
                item.setCheckState(0, Qt.CheckState.Checked)
        self.tree.blockSignals(False)
        self.tree.setEnabled(True)
        self._filter()
        self._selection_changed()
        for index in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(index)
            if item.checkState(0) == Qt.CheckState.Checked:
                self.tree.scrollToItem(item)
                break

    def checked_names(self):
        checked = [self.tree.topLevelItem(i).text(0) for i in range(self.tree.topLevelItemCount())
                   if self.tree.topLevelItem(i).checkState(0) == Qt.CheckState.Checked]
        return tuple(dict.fromkeys([name for name in self._preferred if name in checked] + checked))

    def _filter(self):
        query = self.search.text().casefold()
        for index in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(index)
            item.setHidden(query not in item.text(0).casefold())

    def _selection_changed(self, *_args):
        if self.catalog is None:
            return
        names = self.checked_names()
        error = self.catalog.selection_error(names)
        self.status.setText(error or f"已选 {len(names)} 个体分组；允许只使用部分网格。仅读取了文件头部。")

    def selected_components(self):
        if self._loading:
            raise ValueError("正在读取网格体分组，请稍候。")
        if self.catalog is None:
            if self._preserve_unread and self._preferred:
                return list(self._preferred)
            raise ValueError(self._error or "请先读取网格体分组。")
        try:
            signature = mesh_file_signature(self.path)
        except OSError as error:
            self.reload()
            raise ValueError(f"无法访问网格文件：{error}。请重新核对文件。") from error
        if signature != self.catalog.signature:
            self.reload()
            raise ValueError("网格文件已变化，正在重新读取体分组，请核对后保存。")
        names = self.checked_names()
        error = self.catalog.selection_error(names)
        if error:
            raise ValueError(error)
        return list(names)
