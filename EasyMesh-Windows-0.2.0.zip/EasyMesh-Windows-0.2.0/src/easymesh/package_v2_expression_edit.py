"""Scoped, token-aware formula completion shared by tables and dialogs."""
from __future__ import annotations

from collections.abc import Iterable
import re

from PySide6.QtCore import QEvent, QObject, QRegularExpression, QStringListModel, Qt, Signal
from PySide6.QtGui import QRegularExpressionValidator
from PySide6.QtWidgets import (
    QAbstractItemDelegate, QApplication, QCompleter, QLineEdit, QSizePolicy, QStyledItemDelegate,
    QWidget,
)


class _TabKeyPolicy(QObject):
    """Reserve plain Tab for completion before Qt focus/delegate navigation."""

    def eventFilter(self, watched, event):
        if not isinstance(watched, QWidget) or event.type() not in (
            QEvent.Type.ShortcutOverride, QEvent.Type.KeyPress,
        ):
            return False
        if event.key() not in (Qt.Key.Key_Tab, Qt.Key.Key_Backtab):
            return False
        if event.modifiers() & (
            Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier
            | Qt.KeyboardModifier.MetaModifier
        ):
            return False
        if (event.type() == QEvent.Type.KeyPress and event.key() == Qt.Key.Key_Tab
                and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier):
            # A completer popup may receive the key instead of its line edit.
            for receiver in (watched, QApplication.focusWidget()):
                while receiver is not None and not isinstance(receiver, ExpressionEdit):
                    receiver = receiver.parent()
                if isinstance(receiver, ExpressionEdit):
                    receiver.accept_current_completion()
                    break
        event.accept()
        return True


def install_tab_key_policy():
    """Install once per QApplication, including for standalone authoring dialogs."""
    app = QApplication.instance()
    if app is not None and not hasattr(app, "_easymesh_tab_key_policy"):
        policy = _TabKeyPolicy(app)
        app._easymesh_tab_key_policy = policy
        app.installEventFilter(policy)


class ExpressionEdit(QLineEdit):
    """Small token-aware expression editor backed by Qt's QCompleter."""

    completionInserted = Signal()

    _LEFT_TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*$")
    _RIGHT_TOKEN = re.compile(r"^[A-Za-z0-9_]*")
    _EXPONENT_PREFIX = re.compile(r"(?<![A-Za-z0-9_.])(?:\d+(?:\.\d*)?|\.\d+)[eE][+-]?$")
    _SEPARATORS = "+-*/%^(,=<>!&|?:[{}~"

    def __init__(self, parent: object, candidates: tuple[str, ...]) -> None:
        super().__init__(parent)  # type: ignore[arg-type]
        install_tab_key_policy()
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        normalized = self._candidates = tuple(dict.fromkeys(candidates))
        self.setProperty("package_v2_completion_candidates", normalized)
        self._completion_model = QStringListModel(list(normalized), self)
        self._completion = QCompleter(self._completion_model, self)
        self._completion.setWidget(self)
        self._completion.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._completion.setCompletionMode(
            QCompleter.CompletionMode.PopupCompletion
        )
        self._completion.setFilterMode(Qt.MatchFlag.MatchContains)
        self._completion.setMaxVisibleItems(12)
        self._completion.activated[str].connect(self._insert_completion)
        self.textEdited.connect(self._update_completion_popup)
        self.cursorPositionChanged.connect(self._refresh_visible_popup)
        self.selectionChanged.connect(self._refresh_visible_popup)
        # Handle Enter before QCompleter. Tab is handled by the application
        # policy before either widget filters or table delegates see it.
        self.installEventFilter(self)
        self.setToolTip(
            "按空格、运算符和括号分隔补全当前变量；↑/↓选择，Tab 填入，Enter 提交，"
            "Ctrl+Space 显示全部。"
        )

    def set_completion_candidates(self, candidates: Iterable[str]) -> None:
        """Replace suggestions while preserving the current expression."""

        normalized = self._candidates = tuple(
            dict.fromkeys(str(value) for value in candidates if str(value))
        )
        self.setProperty("package_v2_completion_candidates", normalized)
        self._completion_model.setStringList(list(normalized))

    def completer(self):
        return self._completion

    def _token_span(self) -> tuple[int, int, str]:
        if self.hasSelectedText():
            start = self.selectionStart()
            selected = self.selectedText()
            prefix = selected if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", selected) else ""
            return start, start + len(selected), prefix
        cursor = self.cursorPosition()
        left = self._LEFT_TOKEN.search(self.text()[:cursor])
        start = left.start() if left is not None else cursor
        prefix = self.text()[start:cursor]
        right = self._RIGHT_TOKEN.match(self.text()[cursor:])
        end = cursor + (right.end() if right is not None else 0)
        return start, end, prefix

    def _prepare_completions(self, prefix: str) -> None:
        start, _end, _prefix = self._token_span()
        # A token directly after a number is a unit, including scientific notation.
        unit_position = start > 0 and (self.text()[start - 1].isdigit() or self.text()[start - 1] == ".")
        candidates = tuple(name for name in self._candidates if name in ("mm", "um")) if unit_position else self._candidates
        self._completion_model.setStringList(list(candidates))
        self._completion.setCompletionPrefix(prefix)

    def _show_completions(self, prefix: str) -> None:
        self._prepare_completions(prefix)
        popup = self._completion.popup()
        popup.setCurrentIndex(self._completion.completionModel().index(0, 0))
        self._completion.complete()

    def _update_completion_popup(self, _text: str) -> None:
        _start, _end, prefix = self._token_span()
        preceding = self.text()[:self.cursorPosition()]
        boundary = bool(preceding and (preceding[-1].isspace() or preceding[-1] in self._SEPARATORS))
        if prefix or (boundary and not self._EXPONENT_PREFIX.search(preceding)):
            self._show_completions(prefix)
        else:
            self._completion.popup().hide()

    def _refresh_visible_popup(self, *_args):
        if self._completion.popup().isVisible():
            self._update_completion_popup(self.text())

    def _insert_completion(self, completion: str) -> None:
        start, end, _prefix = self._token_span()
        updated = self.text()[:start] + completion + self.text()[end:]
        self.setText(updated)
        self.setCursorPosition(start + len(completion))
        self._completion.popup().hide()
        self.completionInserted.emit()

    def accept_current_completion(self) -> bool:
        """Insert one suggestion without ending the table edit session."""

        _start, _end, prefix = self._token_span()
        popup = self._completion.popup()
        completion = ""
        if popup.isVisible():
            selected = popup.currentIndex()
            if selected.isValid():
                value = selected.data(Qt.ItemDataRole.DisplayRole)
                completion = value if isinstance(value, str) else ""
        if not completion:
            if not prefix:
                return False
            self._prepare_completions(prefix)
            if self._completion.completionCount() < 1:
                return False
            if not self._completion.setCurrentRow(0):
                return False
            completion = self._completion.currentCompletion()
        if not completion:
            return False
        self._insert_completion(completion)
        return True

    def eventFilter(self, watched: object, event: object) -> bool:
        if (
            watched is self
            and event.type() == QEvent.Type.KeyPress  # type: ignore[attr-defined]
        ):
            key = event.key()  # type: ignore[attr-defined]
            if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                self._completion.popup().hide()
                self.returnPressed.emit()
                event.accept()  # type: ignore[attr-defined]
                return True
        return super().eventFilter(watched, event)  # type: ignore[arg-type]

    def keyPressEvent(self, event: object) -> None:
        if event.key() in (  # type: ignore[attr-defined]
            Qt.Key.Key_Return,
            Qt.Key.Key_Enter,
        ):
            self._completion.popup().hide()
            self.returnPressed.emit()
            event.accept()  # type: ignore[attr-defined]
            return
        if (
            event.key() == Qt.Key.Key_Space  # type: ignore[attr-defined]
            and event.modifiers() & Qt.KeyboardModifier.ControlModifier  # type: ignore[attr-defined]
        ):
            self._show_completions("")
            return
        super().keyPressEvent(event)  # type: ignore[arg-type]


def variable_name_edit(parent=None):
    """No whitespace, punctuation or leading digits in variable names."""
    edit = QLineEdit(parent)
    edit.setValidator(QRegularExpressionValidator(QRegularExpression(r"[A-Za-z_][A-Za-z0-9_]*"), edit))
    edit.setToolTip("变量名只能包含英文字母、数字和下划线，不能含空格，且不能以数字开头。")
    return edit


class ExpressionDelegate(QStyledItemDelegate):
    """Formula editors with dynamic scope candidates and Tab/Enter semantics."""

    def __init__(self, parent=None, *, expression_columns=(), candidates=lambda: (), name_columns=()):
        super().__init__(parent)
        self.expression_columns = frozenset(expression_columns)
        self.name_columns = frozenset(name_columns)
        self.candidates = candidates

    def createEditor(self, parent, option, index):
        if index.column() in self.name_columns:
            return variable_name_edit(parent)
        if index.column() in self.expression_columns:
            return ExpressionEdit(parent, tuple(dict.fromkeys((*self.candidates(), "mm", "um"))))
        return super().createEditor(parent, option, index)

    def eventFilter(self, editor, event):
        if isinstance(editor, ExpressionEdit) and event.type() == QEvent.Type.KeyPress:
            if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                editor._completion.popup().hide()
                self.commitData.emit(editor)
                self.closeEditor.emit(editor, QAbstractItemDelegate.EndEditHint.SubmitModelCache)
                event.accept()
                return True
        return super().eventFilter(editor, event)
