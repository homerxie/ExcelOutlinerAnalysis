"""Convert EasyMesh Gmsh MSH 4.1 volume meshes to blocked ANSYS CDB.

The exporter keeps two distinct concepts explicit:

* Gmsh ``TEMPLATE_<template>_<component>`` Physical Volumes become ANSYS
  ``CMBLOCK`` element sets together with the material/transition/global sets;
* HyperMesh's ``HM_<component>_TEMPLATE/TRANSITION`` single-owner Components
  preserve ``origin × component`` and each binds exactly one material.
  ``TYPE=1`` means template/BUMP mesh, ``TYPE=2`` means transition mesh, while
  the EBLOCK ``MAT`` field records that binding.

Current EasyMesh TET4, HEX8, WEDGE6, and PYRAMID5 cells can be written as
SOLID185.  HEX8 and WEDGE6 can also be written as SOLID186; that path elevates
the linear source mesh by creating one globally shared midpoint node per
topological edge.  Lower-order non-brick shapes use ANSYS's documented
repeated-node degeneration patterns.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
from typing import Mapping, Sequence, TextIO

from .output_artifacts import (
    atomic_output_path,
    atomic_write_text,
    exclusive_artifact_lock,
    file_artifact,
    paths_refer_to_same_file,
)
from .volume_mesh import (
    ElementKind,
    MeshNode,
    PhysicalGroup,
    VolumeElement,
    VolumeMesh,
    VolumeMeshError,
    load_volume_mesh,
)


_ANSYS_INTEGER_MAX = 999_999_999
_RESERVED_COMPONENT_NAMES = {"ALL", "STAT", "DEFA"}
_VALID_COMPONENT_CHARACTER = re.compile(r"[^A-Z0-9_]+")
_SUPPORTED_ANSYS_ELEMENT_TYPES = (185, 186)
_HYPERMESH_TEMPLATE = "TEMPLATE"
_HYPERMESH_TRANSITION = "TRANSITION"
_HYPERMESH_TYPE_BY_ORIGIN = {
    _HYPERMESH_TEMPLATE: 1,
    _HYPERMESH_TRANSITION: 2,
}
_SYSTEM_PHYSICAL_GROUP_NAMES = {
    "ORTH_MESH_WARNINGS",
    "ALL_SOLID_VOLUMES",
    "TEMPLATE_SOLID_VOLUMES",
    "TRANSITION_SOLID_VOLUMES",
}
_SYSTEM_PHYSICAL_GROUP_PREFIXES = (
    "BUMP_",
    "COMPONENT_",
    "HM_",
    "TEMPLATE_",
    "TRANSITION_",
)


class CdbExportError(ValueError):
    """Raised when a mesh cannot be represented by this CDB profile."""


@dataclass(frozen=True, slots=True)
class CdbExportOptions:
    """Options for the EasyMesh-compatible structural-solid CDB profile."""

    element_type: int = 185
    coordinate_scale: float = 1.0
    units_label: str | None = "MPA"
    component_name_limit: int = 32
    primary_group_prefixes: tuple[str, ...] = ("MATERIAL_", "REGION_")

    def validate(self) -> None:
        if self.element_type not in _SUPPORTED_ANSYS_ELEMENT_TYPES:
            raise CdbExportError("element_type 只支持 SOLID185(185) 或 SOLID186(186)")
        if not math.isfinite(self.coordinate_scale) or self.coordinate_scale <= 0.0:
            raise CdbExportError("coordinate_scale 必须是有限正数")
        if self.component_name_limit < 8 or self.component_name_limit > 32:
            raise CdbExportError(
                "legacy HyperMesh CDB 的 component_name_limit 必须位于 8..32"
            )
        if self.units_label is not None:
            token = self.units_label.strip().upper()
            if not token or not re.fullmatch(r"[A-Z0-9_]+", token):
                raise CdbExportError("units_label 必须是简单的 ANSYS 单位标签")
        for prefix in self.primary_group_prefixes:
            if not prefix:
                raise CdbExportError("primary_group_prefixes 不能包含空前缀")


@dataclass(frozen=True, slots=True)
class ComponentMapping:
    physical_tag: int | None
    physical_name: str
    component_name: str
    element_count: int


@dataclass(frozen=True, slots=True)
class PrimaryPartitionMapping:
    physical_tag: int | None
    physical_name: str
    component_name: str | None
    material_id: int
    element_count: int


@dataclass(frozen=True, slots=True)
class HyperMeshComponentMapping:
    """One exclusive HyperMesh Component and its ANSYS property tuple."""

    component_id: int
    component_name: str
    origin: str
    element_type_id: int
    material_id: int
    material_physical_name: str
    material_name: str
    real_constant_id: int
    section_id: int
    element_count: int


@dataclass(frozen=True, slots=True)
class CdbExportSummary:
    source_mesh_path: str
    source_mesh_artifact: Mapping[str, str | int]
    cdb_path: str
    report_path: str
    source_node_count: int
    node_count: int
    generated_midside_node_count: int
    element_count: int
    hex_count: int
    wedge_count: int
    tet_count: int
    pyramid_count: int
    component_count: int
    component_mappings: tuple[ComponentMapping, ...]
    primary_partition_kind: str
    primary_partition: tuple[PrimaryPartitionMapping, ...]
    hypermesh_component_count: int
    hypermesh_components: tuple[HyperMeshComponentMapping, ...]
    overlapping_element_count: int
    max_components_per_element: int
    element_type: int
    coordinate_scale: float
    units_label: str | None
    source_min_jacobian_determinant: float
    material_properties_written: bool
    cdb_artifact: Mapping[str, str | int]

    def to_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["component_mappings"] = [
            asdict(mapping) for mapping in self.component_mappings
        ]
        data["primary_partition"] = [
            asdict(mapping) for mapping in self.primary_partition
        ]
        data["hypermesh_components"] = [
            asdict(mapping) for mapping in self.hypermesh_components
        ]
        data["source_mesh_artifact"] = dict(self.source_mesh_artifact)
        data["cdb_artifact"] = dict(self.cdb_artifact)
        return data


@dataclass(frozen=True, slots=True)
class _ExportPlan:
    component_mappings: tuple[ComponentMapping, ...]
    component_members: Mapping[str, tuple[int, ...]]
    primary_partition_kind: str
    primary_partition: tuple[PrimaryPartitionMapping, ...]
    material_by_element: Mapping[int, int]
    hypermesh_components: tuple[HyperMeshComponentMapping, ...]
    hypermesh_component_members: Mapping[str, tuple[int, ...]]
    overlapping_element_count: int
    max_components_per_element: int


@dataclass(frozen=True, slots=True)
class _ComponentSource:
    physical_tag: int | None
    physical_name: str
    element_tags: tuple[int, ...]


def _hm_component_identity(name: str) -> tuple[str, str] | None:
    """Return ``(origin, component)`` for current or legacy HM group names."""

    normalized = name.strip().upper()
    if not normalized.startswith("HM_"):
        return None
    token_pattern = r"[A-Z0-9]+(?:_[A-Z0-9]+)*"
    current = re.fullmatch(
        rf"HM_(?P<component>{token_pattern})_"
        rf"(?P<origin>{_HYPERMESH_TEMPLATE}|{_HYPERMESH_TRANSITION})",
        normalized,
    )
    legacy = re.fullmatch(
        rf"HM_(?P<origin>{_HYPERMESH_TEMPLATE}|{_HYPERMESH_TRANSITION})_"
        rf"(?P<component>{token_pattern})",
        normalized,
    )
    # The suffix contract is authoritative.  Only fall back to the legacy
    # prefix form when the name cannot be parsed as a current component; this
    # also lets current component tokens contain TEMPLATE/TRANSITION words.
    for match in (current, legacy):
        if match is not None:
            return (match.group("origin"), match.group("component"))
    raise CdbExportError(
        "HM Component 必须命名为 HM_<component>_TEMPLATE/TRANSITION；"
        f"旧 HM_TEMPLATE/TRANSITION_<component> 也可读取：{name!r}"
    )


def _canonical_hm_component_name(origin: str, component: str) -> str:
    return f"HM_{component}_{origin}"


@dataclass(frozen=True, slots=True)
class _CdbTopology:
    nodes: tuple[MeshNode, ...]
    midpoint_node_by_edge: Mapping[tuple[int, int], int]
    generated_midside_node_count: int


@dataclass(frozen=True, slots=True)
class _WriteResult:
    plan: _ExportPlan
    topology: _CdbTopology


def normalized_cdb_output(path: str | Path) -> Path:
    """Return one absolute, lower-case ``.cdb`` output path."""

    output = Path(path).expanduser().resolve()
    if output.suffix != ".cdb":
        output = output.with_suffix(".cdb")
    return output


def _component_base_name(
    physical_name: str,
    physical_tag: int | None,
    limit: int,
) -> str:
    token = _VALID_COMPONENT_CHARACTER.sub("_", physical_name.strip().upper())
    token = token.strip("._")
    if not token:
        token = (
            f"PHYSICAL_3_{physical_tag}"
            if physical_tag is not None
            else "ALL_SOLID_VOLUMES"
        )
    if not token[0].isalpha() or token in _RESERVED_COMPONENT_NAMES:
        token = f"C_{token}"
    return token[:limit]


def sanitize_component_names(
    groups: Sequence[tuple[int | None, str]],
    *,
    limit: int = 32,
) -> tuple[str, ...]:
    """Return deterministic, collision-free legacy-compatible CDB names."""

    if limit < 8 or limit > 32:
        raise CdbExportError(
            "legacy HyperMesh component name limit 必须位于 8..32"
        )
    used: set[str] = set()
    resolved: list[str] = []
    for index, (physical_tag, physical_name) in enumerate(groups, start=1):
        base = _component_base_name(physical_name, physical_tag, limit)
        candidate = base
        if candidate in used:
            identity = physical_tag if physical_tag is not None else index
            readable_suffix = f"_P{identity}"
            suffix = (
                readable_suffix
                if len(readable_suffix) < limit
                else "_" + hashlib.sha1(
                    f"{identity}:{physical_name}".encode("utf-8")
                ).hexdigest()[: min(6, limit - 2)].upper()
            )
            candidate = f"{base[: limit - len(suffix)]}{suffix}"
            collision_index = 2
            while candidate in used:
                digest = hashlib.sha1(
                    f"{identity}:{physical_name}:{collision_index}".encode("utf-8")
                ).hexdigest()[: min(6, limit - 2)].upper()
                suffix = f"_{digest}"
                candidate = f"{base[: limit - len(suffix)]}{suffix}"
                collision_index += 1
        used.add(candidate)
        resolved.append(candidate)
    return tuple(resolved)


def _physical_component_members(
    mesh: VolumeMesh,
) -> tuple[_ComponentSource, ...]:
    groups_by_tag: dict[int, PhysicalGroup] = {}
    members_by_tag: dict[int, set[int]] = {}
    for element in mesh.elements:
        for group in element.physical_groups:
            previous = groups_by_tag.setdefault(group.tag, group)
            if previous.name != group.name:
                raise CdbExportError(
                    f"Physical tag {group.tag} 同时使用了不同名称"
                )
            members_by_tag.setdefault(group.tag, set()).add(element.tag)

    records = [
        _ComponentSource(
            physical_tag=groups_by_tag[tag].tag,
            physical_name=groups_by_tag[tag].name,
            element_tags=tuple(sorted(members)),
        )
        for tag, members in sorted(members_by_tag.items())
        if members
    ]
    all_element_tags = tuple(sorted(element.tag for element in mesh.elements))
    all_group = next(
        (
            record
            for record in records
            if record.physical_name.upper() == "ALL_SOLID_VOLUMES"
        ),
        None,
    )
    if all_group is None:
        records.append(
            _ComponentSource(
                physical_tag=None,
                physical_name="ALL_SOLID_VOLUMES",
                element_tags=all_element_tags,
            )
        )
    elif all_group.element_tags != all_element_tags:
        raise CdbExportError(
            "ALL_SOLID_VOLUMES 必须包含全部三维单元，不能是部分集合"
        )
    return tuple(records)


def _select_primary_partition(
    elements: Sequence[VolumeElement],
    components: Sequence[_ComponentSource],
    component_name_by_tag: Mapping[int, str],
    prefixes: Sequence[str],
) -> tuple[
    str,
    tuple[PrimaryPartitionMapping, ...],
    dict[int, int],
]:
    selected = _primary_component_sources(components, prefixes)
    if selected is not None:
        prefix, candidates = selected
        return _validated_primary_partition(
            elements,
            candidates,
            component_name_by_tag,
            kind=prefix,
            error_subject=f"主分区前缀 {prefix!r}",
        )

    unprefixed_candidates = _unprefixed_primary_component_sources(components)
    if unprefixed_candidates:
        return _validated_primary_partition(
            elements,
            unprefixed_candidates,
            component_name_by_tag,
            kind="UNPREFIXED",
            error_subject="无前缀材料候选组",
        )

    return (
        "DEFAULT",
        (
            PrimaryPartitionMapping(
                physical_tag=None,
                physical_name="DEFAULT_MATERIAL",
                component_name=None,
                material_id=1,
                element_count=len(elements),
            ),
        ),
        {element.tag: 1 for element in elements},
    )


def _validated_primary_partition(
    elements: Sequence[VolumeElement],
    candidates: Sequence[_ComponentSource],
    component_name_by_tag: Mapping[int, str],
    *,
    kind: str,
    error_subject: str,
) -> tuple[
    str,
    tuple[PrimaryPartitionMapping, ...],
    dict[int, int],
]:
    """Validate and materialize one exact EID partition."""

    all_element_tags = {element.tag for element in elements}
    memberships: dict[int, list[_ComponentSource]] = {
        tag: [] for tag in all_element_tags
    }
    for component in candidates:
        if component.physical_tag is None:
            raise AssertionError("a material candidate must have a Physical tag")
        for tag in component.element_tags:
            memberships[tag].append(component)
    missing = sorted(tag for tag, groups in memberships.items() if not groups)
    ambiguous = sorted(
        tag for tag, groups in memberships.items() if len(groups) > 1
    )
    if missing or ambiguous:
        details: list[str] = []
        if missing:
            details.append(f"{len(missing)} 个单元未命中")
        if ambiguous:
            details.append(f"{len(ambiguous)} 个单元命中多个组")
        candidate_names = ", ".join(
            repr(component.physical_name) for component in candidates
        )
        raise CdbExportError(
            f"{error_subject} 不是互斥完备分区："
            + "，".join(details)
            + f"；候选组：{candidate_names}"
        )

    material_id_by_tag = {
        component.physical_tag: index
        for index, component in enumerate(candidates, start=1)
    }
    material_by_element = {
        tag: material_id_by_tag[groups[0].physical_tag]
        for tag, groups in memberships.items()
    }
    mappings = tuple(
        PrimaryPartitionMapping(
            physical_tag=component.physical_tag,
            physical_name=component.physical_name,
            component_name=component_name_by_tag[component.physical_tag],
            material_id=material_id_by_tag[component.physical_tag],
            element_count=len(component.element_tags),
        )
        for component in candidates
        if component.physical_tag is not None
    )
    return kind, mappings, material_by_element


def _primary_component_sources(
    components: Sequence[_ComponentSource],
    prefixes: Sequence[str],
) -> tuple[str, tuple[_ComponentSource, ...]] | None:
    """Return the first configured material/region Physical Group family."""

    for prefix in prefixes:
        candidates = tuple(
            component
            for component in components
            if component.physical_tag is not None
            and component.physical_name.upper().startswith(prefix.upper())
        )
        if candidates:
            return prefix, candidates
    return None


def _unprefixed_primary_component_sources(
    components: Sequence[_ComponentSource],
) -> tuple[_ComponentSource, ...]:
    """Return all non-system named groups as one conservative candidate family."""

    return tuple(
        component
        for component in components
        if component.physical_tag is not None
        and not _is_system_physical_group(component.physical_name)
    )


def _is_system_physical_group(name: str) -> bool:
    normalized = name.strip().upper()
    return normalized in _SYSTEM_PHYSICAL_GROUP_NAMES or normalized.startswith(
        _SYSTEM_PHYSICAL_GROUP_PREFIXES
    )


def _material_token(
    mapping: PrimaryPartitionMapping,
    prefixes: Sequence[str],
) -> str:
    """Return a short readable token for generated HyperMesh names."""

    token = mapping.physical_name.strip().upper()
    for prefix in prefixes:
        normalized_prefix = prefix.strip().upper()
        if token.startswith(normalized_prefix):
            token = token[len(normalized_prefix) :]
            break
    if token == "DEFAULT_MATERIAL":
        token = "DEFAULT"
    token = _VALID_COMPONENT_CHARACTER.sub("_", token).strip("._")
    return token or f"M{mapping.material_id}"


def _classify_origin_members(
    elements: Sequence[VolumeElement],
    physical_components: Sequence[_ComponentSource],
) -> tuple[dict[str, tuple[int, ...]], bool]:
    """Resolve the exclusive template/transition provenance of every EID."""

    all_element_tags = {element.tag for element in elements}
    bump_sources = tuple(
        component
        for component in physical_components
        if component.physical_name.strip().upper().startswith("BUMP_")
    )
    if bump_sources:
        raise CdbExportError(
            "检测到旧版 BUMP_<实例编号>_<模板别名> Physical Groups；"
            "请用当前 EasyMesh 重新生成统一分类的 MSH"
        )
    explicit_template_sources = tuple(
        component
        for component in physical_components
        if component.physical_name.strip().upper()
        == "TEMPLATE_SOLID_VOLUMES"
    )
    unified_template_sources = tuple(
        component
        for component in physical_components
        if component.physical_name.strip().upper().startswith("TEMPLATE_")
        and component.physical_name.strip().upper()
        != "TEMPLATE_SOLID_VOLUMES"
    )
    transition_sources = tuple(
        component
        for component in physical_components
        if component.physical_name.strip().upper()
        == "TRANSITION_SOLID_VOLUMES"
    )
    source_hm_components = tuple(
        (component, identity)
        for component in physical_components
        if (identity := _hm_component_identity(component.physical_name))
        is not None
    )
    source_template_components = tuple(
        component
        for component, (origin, _component_token) in source_hm_components
        if origin == _HYPERMESH_TEMPLATE
    )
    source_transition_components = tuple(
        component
        for component, (origin, _component_token) in source_hm_components
        if origin == _HYPERMESH_TRANSITION
    )
    has_layout_markers = bool(
        bump_sources
        or explicit_template_sources
        or unified_template_sources
        or transition_sources
        or source_template_components
        or source_transition_components
    )

    explicit_template_tags = {
        tag
        for component in explicit_template_sources
        for tag in component.element_tags
    }
    unified_membership_counts: Counter[int] = Counter()
    for component in unified_template_sources:
        unified_membership_counts.update(component.element_tags)
    duplicate_unified_members = tuple(
        sorted(
            tag
            for tag, count in unified_membership_counts.items()
            if count > 1
        )
    )
    unified_template_tags = set(unified_membership_counts)
    source_template_membership_counts: Counter[int] = Counter()
    for component in source_template_components:
        source_template_membership_counts.update(component.element_tags)
    duplicate_source_template_members = tuple(
        sorted(
            tag
            for tag, count in source_template_membership_counts.items()
            if count > 1
        )
    )
    source_template_tags = set(source_template_membership_counts)
    template_candidates = tuple(
        tags
        for tags in (
            explicit_template_tags,
            unified_template_tags,
            source_template_tags,
        )
        if tags
    )
    if template_candidates and any(
        tags != template_candidates[0] for tags in template_candidates[1:]
    ):
        raise CdbExportError(
            "TEMPLATE Sets 与 HM_TEMPLATE Components 的模板区成员不一致"
        )
    template_tags = template_candidates[0] if template_candidates else set()
    transition_tags = {
        tag
        for component in transition_sources
        for tag in component.element_tags
    }
    source_transition_membership_counts: Counter[int] = Counter()
    for component in source_transition_components:
        source_transition_membership_counts.update(component.element_tags)
    duplicate_source_transition_members = tuple(
        sorted(
            tag
            for tag, count in source_transition_membership_counts.items()
            if count > 1
        )
    )
    source_transition_tags = set(source_transition_membership_counts)
    if transition_tags and source_transition_tags and (
        transition_tags != source_transition_tags
    ):
        raise CdbExportError(
            "TRANSITION_SOLID_VOLUMES 与 HM_*_TRANSITION 的成员不一致"
        )
    transition_tags = transition_tags or source_transition_tags

    uses_unified_layout_contract = bool(
        unified_template_sources
        or source_template_components
        or transition_sources
        or source_transition_components
    )
    if uses_unified_layout_contract:
        missing_families: list[str] = []
        if not unified_template_sources:
            missing_families.append("TEMPLATE_<模板>_<component> Sets")
        if not source_template_components:
            missing_families.append("HM_<component>_TEMPLATE Components")
        if transition_tags and not transition_sources:
            missing_families.append("TRANSITION_SOLID_VOLUMES Set")
        if transition_tags and not source_transition_components:
            missing_families.append("HM_<component>_TRANSITION Components")
        if missing_families:
            raise CdbExportError(
                "布局 MSH 缺少统一分类：" + "，".join(missing_families)
            )

    if has_layout_markers:
        overlap = template_tags.intersection(transition_tags)
        uncovered = all_element_tags.difference(template_tags, transition_tags)
        if (
            duplicate_unified_members
            or duplicate_source_template_members
            or duplicate_source_transition_members
            or overlap
            or uncovered
        ):
            details: list[str] = []
            if duplicate_unified_members:
                details.append(
                    f"{len(duplicate_unified_members)} 个单元命中多个 TEMPLATE_* Set"
                )
            if duplicate_source_template_members:
                details.append(
                    f"{len(duplicate_source_template_members)} 个单元命中多个 "
                    "HM_*_TEMPLATE 组"
                )
            if duplicate_source_transition_members:
                details.append(
                    f"{len(duplicate_source_transition_members)} 个单元命中多个 "
                    "HM_*_TRANSITION 组"
                )
            if overlap:
                details.append(
                    f"{len(overlap)} 个单元同时属于模板与过渡区"
                )
            if uncovered:
                details.append(
                    f"{len(uncovered)} 个单元未归入模板或过渡区"
                )
            raise CdbExportError(
                "模板/TRANSITION_SOLID_VOLUMES 不是互斥完备分区："
                + "，".join(details)
            )
    else:
        # Non-layout and legacy meshes are entirely template mesh.
        template_tags = set(all_element_tags)

    return (
        {
            _HYPERMESH_TEMPLATE: tuple(sorted(template_tags)),
            _HYPERMESH_TRANSITION: tuple(sorted(transition_tags)),
        },
        has_layout_markers,
    )


def _cdb_set_sources(
    physical_components: Sequence[_ComponentSource],
    origin_members: Mapping[str, tuple[int, ...]],
) -> tuple[_ComponentSource, ...]:
    """Keep unified Sets while excluding source-side HM owner markers."""

    retained: list[_ComponentSource] = []
    template_insertion_index: int | None = None
    has_unified_template_sets = False
    for component in physical_components:
        normalized_name = component.physical_name.strip().upper()
        if _hm_component_identity(component.physical_name) is not None:
            continue
        if normalized_name.startswith("BUMP_"):
            raise CdbExportError(
                "旧版 BUMP_* Physical Groups 不受支持；请重新生成 MSH"
            )
        if normalized_name == "TEMPLATE_SOLID_VOLUMES":
            if template_insertion_index is None:
                template_insertion_index = len(retained)
            continue
        if normalized_name.startswith("TEMPLATE_"):
            has_unified_template_sets = True
        retained.append(component)

    template_tags = origin_members[_HYPERMESH_TEMPLATE]
    if template_tags:
        if template_insertion_index is None:
            template_insertion_index = next(
                (
                    index
                    for index, component in enumerate(retained)
                    if component.physical_name.strip().upper()
                    in {"TRANSITION_SOLID_VOLUMES", "ALL_SOLID_VOLUMES"}
                ),
                len(retained),
            )
        if has_unified_template_sets:
            template_sets: tuple[_ComponentSource, ...] = ()
        else:
            # A non-layout mesh has no instance alias to recover.  It is one
            # template kind, so retain the legacy generic name.
            template_sets = (
                _ComponentSource(
                    physical_tag=None,
                    physical_name="TEMPLATE_SOLID_VOLUMES",
                    element_tags=template_tags,
                ),
            )
        if template_sets:
            retained[template_insertion_index:template_insertion_index] = template_sets
    return tuple(retained)


def _validate_unified_layout_contract(
    physical_components: Sequence[_ComponentSource],
    origin_members: Mapping[str, tuple[int, ...]],
    primary_partition: Sequence[PrimaryPartitionMapping],
    material_by_element: Mapping[int, int],
) -> tuple[_ComponentSource, ...]:
    """Validate exact Set/Component names and memberships in a layout MSH."""

    template_sets = tuple(
        component
        for component in physical_components
        if component.physical_name.strip().upper().startswith("TEMPLATE_")
        and component.physical_name.strip().upper()
        != "TEMPLATE_SOLID_VOLUMES"
    )
    source_hm_components = tuple(
        component
        for component in physical_components
        if _hm_component_identity(component.physical_name) is not None
    )
    if not template_sets and not source_hm_components:
        return ()

    material_by_id = {
        mapping.material_id: mapping for mapping in primary_partition
    }
    template_origin = set(origin_members[_HYPERMESH_TEMPLATE])
    transition_origin = set(origin_members[_HYPERMESH_TRANSITION])

    source_by_identity: dict[tuple[str, str], _ComponentSource] = {}
    source_identity_by_element: dict[int, tuple[str, str]] = {}
    for component in source_hm_components:
        identity = _hm_component_identity(component.physical_name)
        if identity is None:
            raise AssertionError("validated source must be an HM Component")
        origin, component_suffix = identity
        previous_source = source_by_identity.setdefault(identity, component)
        if previous_source is not component:
            canonical_name = _canonical_hm_component_name(*identity)
            raise CdbExportError(
                f"布局 MSH 包含重复 Component 语义：{canonical_name}"
            )
        if origin == _HYPERMESH_TEMPLATE:
            origin_tags = template_origin
        elif origin == _HYPERMESH_TRANSITION:
            origin_tags = transition_origin
        else:  # guarded by source_hm_components filtering above
            raise AssertionError("unexpected HM component family")
        members = set(component.element_tags)
        if not members.issubset(origin_tags):
            raise CdbExportError(
                f"布局 MSH Component {component.physical_name!r} 包含错误来源单元"
            )
        material_ids = {material_by_element[tag] for tag in members}
        if len(material_ids) != 1:
            material_names = ", ".join(
                sorted(
                    material_by_id[material_id].physical_name
                    for material_id in material_ids
                )
            )
            raise CdbExportError(
                f"布局 MSH Component {component.physical_name!r} 必须只绑定一种材料，"
                f"实际为：{material_names}"
            )
        for tag in members:
            previous = source_identity_by_element.setdefault(tag, identity)
            if previous != identity:
                raise CdbExportError(
                    f"element {tag} 同时属于多个 HM Component"
                )

    for component in template_sets:
        members = set(component.element_tags)
        if not members.issubset(template_origin):
            raise CdbExportError(
                f"模板 Set {component.physical_name!r} 包含过渡区单元"
            )
        owner_identities = {
            source_identity_by_element[tag]
            for tag in members
            if tag in source_identity_by_element
        }
        if len(owner_identities) != 1 or len(members) != sum(
            tag in source_identity_by_element for tag in members
        ):
            raise CdbExportError(
                f"模板 Set {component.physical_name!r} 必须只属于一个 "
                "HM_<component>_TEMPLATE Component"
            )
        owner_origin, component_suffix = next(iter(owner_identities))
        if owner_origin != _HYPERMESH_TEMPLATE:
            raise CdbExportError(
                f"模板 Set {component.physical_name!r} 不能属于过渡区 Component"
            )
        normalized_name = component.physical_name.strip().upper()
        required_suffix = f"_{component_suffix}"
        if (
            not normalized_name.endswith(required_suffix)
            or len(normalized_name) <= len("TEMPLATE_") + len(required_suffix)
        ):
            raise CdbExportError(
                "模板 Set 必须命名为 TEMPLATE_<模板别名>_<component>："
                f"{component.physical_name!r}"
            )

    def source_order(component: _ComponentSource) -> tuple[str, int, str, int]:
        identity = _hm_component_identity(component.physical_name)
        if identity is None:
            raise AssertionError("validated source must be an HM Component")
        origin, component_token = identity
        return (
            component_token,
            0 if origin == _HYPERMESH_TEMPLATE else 1,
            _canonical_hm_component_name(origin, component_token),
            component.physical_tag or 0,
        )

    return tuple(sorted(source_hm_components, key=source_order))


def _build_hypermesh_partition(
    elements: Sequence[VolumeElement],
    cdb_set_components: Sequence[_ComponentSource],
    has_layout_markers: bool,
    primary_partition_kind: str,
    primary_partition: Sequence[PrimaryPartitionMapping],
    material_by_element: Mapping[int, int],
    origin_members: Mapping[str, tuple[int, ...]],
    options: CdbExportOptions,
    source_hm_components: Sequence[_ComponentSource] = (),
) -> tuple[
    tuple[HyperMeshComponentMapping, ...],
    dict[str, tuple[int, ...]],
]:
    """Build one exclusive source component with one MAT assignment."""

    all_element_tags = {element.tag for element in elements}
    if has_layout_markers and primary_partition_kind == "DEFAULT":
        raise CdbExportError(
            "布局网格必须提供可验证的互斥完备材料分区"
        )
    transition_tags = set(origin_members[_HYPERMESH_TRANSITION])

    origin_by_element = {
        tag: (
            _HYPERMESH_TRANSITION
            if tag in transition_tags
            else _HYPERMESH_TEMPLATE
        )
        for tag in all_element_tags
    }

    material_tokens = {
        mapping.material_id: _material_token(
            mapping,
            options.primary_group_prefixes,
        )
        for mapping in primary_partition
    }
    material_names = sanitize_component_names(
        tuple(
            (
                mapping.physical_tag,
                f"MAT_{material_tokens[mapping.material_id]}",
            )
            for mapping in primary_partition
        ),
        limit=options.component_name_limit,
    )
    material_name_by_id = {
        mapping.material_id: name
        for mapping, name in zip(primary_partition, material_names)
    }

    specifications: list[
        tuple[str, int, PrimaryPartitionMapping, tuple[int, ...], str]
    ] = []
    material_by_id = {
        mapping.material_id: mapping for mapping in primary_partition
    }
    if source_hm_components:
        for component in source_hm_components:
            identity = _hm_component_identity(component.physical_name)
            if identity is None:
                raise AssertionError("validated source must be an HM Component")
            origin, component_token = identity
            members = tuple(sorted(component.element_tags))
            material_ids = {material_by_element[tag] for tag in members}
            if len(material_ids) != 1:
                raise AssertionError(
                    "validated HM Component must bind exactly one material"
                )
            material = material_by_id[next(iter(material_ids))]
            specifications.append(
                (
                    origin,
                    _HYPERMESH_TYPE_BY_ORIGIN[origin],
                    material,
                    members,
                    _canonical_hm_component_name(origin, component_token),
                )
            )
    else:
        # Non-layout meshes have no component-owner markers.  Keep the legacy
        # origin x material collector construction for those inputs.
        for material in primary_partition:
            for origin in (_HYPERMESH_TEMPLATE, _HYPERMESH_TRANSITION):
                members = tuple(
                    sorted(
                        tag
                        for tag in all_element_tags
                        if material_by_element[tag] == material.material_id
                        and origin_by_element[tag] == origin
                    )
                )
                if not members:
                    continue
                specifications.append(
                    (
                        origin,
                        _HYPERMESH_TYPE_BY_ORIGIN[origin],
                        material,
                        members,
                        _canonical_hm_component_name(
                            origin,
                            material_tokens[material.material_id],
                        ),
                    )
                )

    source_name_inputs = tuple(
        (component.physical_tag, component.physical_name)
        for component in cdb_set_components
    )
    all_resolved_names = sanitize_component_names(
        source_name_inputs
        + tuple(
            (index, specification[4])
            for index, specification in enumerate(specifications, start=1)
        ),
        limit=options.component_name_limit,
    )
    # APDL CM and CMBLOCK share one component namespace.  Resolve generated
    # HyperMesh collector names together with every source-set name so neither
    # can overwrite the other on CDREAD/import.
    component_names = all_resolved_names[len(source_name_inputs) :]
    mappings = tuple(
        HyperMeshComponentMapping(
            component_id=index,
            component_name=component_name,
            origin=origin,
            element_type_id=element_type_id,
            material_id=material.material_id,
            material_physical_name=material.physical_name,
            material_name=material_name_by_id[material.material_id],
            real_constant_id=0,
            section_id=0,
            element_count=len(members),
        )
        for index, (
            component_name,
            (origin, element_type_id, material, members, _raw_name),
        ) in enumerate(
            zip(component_names, specifications),
            start=1,
        )
    )
    members_by_name = {
        mapping.component_name: specification[3]
        for mapping, specification in zip(mappings, specifications)
    }

    owner_counts: Counter[int] = Counter()
    for members in members_by_name.values():
        owner_counts.update(members)
    invalid_owners = tuple(
        sorted(
            tag
            for tag in all_element_tags
            if owner_counts[tag] != 1
        )
    )
    if invalid_owners:
        raise CdbExportError(
            "内部错误：HyperMesh Component 分区不是互斥完备分区"
        )
    return mappings, members_by_name


def _build_export_plan(mesh: VolumeMesh, options: CdbExportOptions) -> _ExportPlan:
    if any(mesh.dimensional_element_counts[dimension] for dimension in range(3)):
        rendered = ", ".join(
            f"dim{dimension}={mesh.dimensional_element_counts[dimension]}"
            for dimension in range(3)
            if mesh.dimensional_element_counts[dimension]
        )
        raise CdbExportError(
            "当前 CDB profile 只接受纯三维体网格；发现低维单元：" + rendered
        )
    for label, tags in (
        ("node", (node.tag for node in mesh.nodes)),
        ("element", (element.tag for element in mesh.elements)),
    ):
        for tag in tags:
            if tag < 1 or tag > _ANSYS_INTEGER_MAX:
                raise CdbExportError(
                    f"{label} tag {tag} 超出 CDB i9 支持范围 1..{_ANSYS_INTEGER_MAX}"
                )

    physical_components = _physical_component_members(mesh)
    origin_members, has_layout_markers = _classify_origin_members(
        mesh.elements,
        physical_components,
    )
    cdb_set_components = _cdb_set_sources(
        physical_components,
        origin_members,
    )
    names = sanitize_component_names(
        tuple(
            (component.physical_tag, component.physical_name)
            for component in cdb_set_components
        ),
        limit=options.component_name_limit,
    )
    component_name_by_tag = {
        component.physical_tag: name
        for component, name in zip(cdb_set_components, names)
        if component.physical_tag is not None
    }
    component_mappings = tuple(
        ComponentMapping(
            physical_tag=component.physical_tag,
            physical_name=component.physical_name,
            component_name=name,
            element_count=len(component.element_tags),
        )
        for component, name in zip(cdb_set_components, names)
    )
    component_members = {
        name: component.element_tags
        for component, name in zip(cdb_set_components, names)
    }
    primary_kind, primary_partition, material_by_element = (
        _select_primary_partition(
            mesh.elements,
            cdb_set_components,
            component_name_by_tag,
            options.primary_group_prefixes,
        )
    )
    source_hm_components = _validate_unified_layout_contract(
        physical_components,
        origin_members,
        primary_partition,
        material_by_element,
    )
    hypermesh_components, hypermesh_component_members = (
        _build_hypermesh_partition(
            mesh.elements,
            cdb_set_components,
            has_layout_markers,
            primary_kind,
            primary_partition,
            material_by_element,
            origin_members,
            options,
            source_hm_components,
        )
    )
    source_hm_component_names = {
        _canonical_hm_component_name(*identity)
        for component in source_hm_components
        if (identity := _hm_component_identity(component.physical_name))
        is not None
    }
    if source_hm_components and {
        mapping.component_name for mapping in hypermesh_components
    } != source_hm_component_names:
        raise CdbExportError(
            "CDB Component 命名与 MSH 的 HM Component 分类不一致"
        )

    membership_counts: Counter[int] = Counter()
    for tags in component_members.values():
        membership_counts.update(tags)
    missing_from_components = [
        element.tag for element in mesh.elements if membership_counts[element.tag] == 0
    ]
    if missing_from_components:
        raise CdbExportError("内部错误：存在未写入任何 CMBLOCK 的三维单元")
    return _ExportPlan(
        component_mappings=component_mappings,
        component_members=component_members,
        primary_partition_kind=primary_kind,
        primary_partition=primary_partition,
        material_by_element=material_by_element,
        hypermesh_components=hypermesh_components,
        hypermesh_component_members=hypermesh_component_members,
        overlapping_element_count=sum(
            count > 1 for count in membership_counts.values()
        ),
        max_components_per_element=max(membership_counts.values(), default=0),
    )


def _format_ansys_real(value: float) -> str:
    """Format one value for the CDB ``e21.13e3`` node-block field."""

    if not math.isfinite(value):
        raise CdbExportError("CDB 不能写出非有限坐标")
    mantissa, exponent = f"{value:.13E}".split("E")
    exponent_value = int(exponent)
    token = f"{mantissa}E{exponent_value:+04d}"
    if len(token) > 21:
        raise CdbExportError(f"坐标 {value:g} 超出 e21.13e3 字段范围")
    return f"{token:>21}"


def solid185_connectivity(element: VolumeElement) -> tuple[int, ...]:
    """Return the eight I..P node slots required by ANSYS SOLID185."""

    if element.kind is ElementKind.TET4:
        if len(element.node_tags) != 4:
            raise CdbExportError(f"TET4 element {element.tag} 必须有 4 个节点")
        i, j, k, m = element.node_tags
        # ANSYS Degenerated Shape Elements: condense a prism's K-L edge and
        # then its complete M-N-O-P face to obtain the tetrahedral pattern.
        return (i, j, k, k, m, m, m, m)
    if element.kind is ElementKind.HEX8:
        if len(element.node_tags) != 8:
            raise CdbExportError(f"HEX8 element {element.tag} 必须有 8 个节点")
        return element.node_tags
    if element.kind is ElementKind.WEDGE6:
        if len(element.node_tags) != 6:
            raise CdbExportError(f"WEDGE6 element {element.tag} 必须有 6 个节点")
        i, j, k, m, n, o = element.node_tags
        return (i, j, k, k, m, n, o, o)
    if element.kind is ElementKind.PYRAMID5:
        if len(element.node_tags) != 5:
            raise CdbExportError(
                f"PYRAMID5 element {element.tag} 必须有 5 个节点"
            )
        i, j, k, l, m = element.node_tags
        # Preserve the I-J-K-L quadrilateral base and condense the opposite
        # M-N-O-P face to the pyramid apex.
        return (i, j, k, l, m, m, m, m)
    raise CdbExportError(f"不支持的单元类型：{element.kind}")


def _edge_key(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def _element_edges(element: VolumeElement) -> tuple[tuple[int, int], ...]:
    nodes = element.node_tags
    if element.kind is ElementKind.HEX8:
        if len(nodes) != 8:
            raise CdbExportError(f"HEX8 element {element.tag} 必须有 8 个节点")
        local_edges = (
            (0, 1),
            (1, 2),
            (2, 3),
            (3, 0),
            (4, 5),
            (5, 6),
            (6, 7),
            (7, 4),
            (0, 4),
            (1, 5),
            (2, 6),
            (3, 7),
        )
    elif element.kind is ElementKind.WEDGE6:
        if len(nodes) != 6:
            raise CdbExportError(f"WEDGE6 element {element.tag} 必须有 6 个节点")
        local_edges = (
            (0, 1),
            (1, 2),
            (2, 0),
            (3, 4),
            (4, 5),
            (5, 3),
            (0, 3),
            (1, 4),
            (2, 5),
        )
    else:
        raise CdbExportError(f"不支持的单元类型：{element.kind}")
    return tuple(_edge_key(nodes[left], nodes[right]) for left, right in local_edges)


def solid186_connectivity(
    element: VolumeElement,
    midpoint_node_by_edge: Mapping[tuple[int, int], int],
) -> tuple[int, ...]:
    """Return the 20 SOLID186 node slots for one elevated source element."""

    def midpoint(first: int, second: int) -> int:
        edge = _edge_key(first, second)
        try:
            return midpoint_node_by_edge[edge]
        except KeyError as exc:
            raise CdbExportError(
                f"element {element.tag} 的边 {edge} 缺少 SOLID186 中节点"
            ) from exc

    if element.kind is ElementKind.HEX8:
        if len(element.node_tags) != 8:
            raise CdbExportError(f"HEX8 element {element.tag} 必须有 8 个节点")
        i, j, k, l, m, n, o, p = element.node_tags
        return (
            i,
            j,
            k,
            l,
            m,
            n,
            o,
            p,
            midpoint(i, j),
            midpoint(j, k),
            midpoint(k, l),
            midpoint(l, i),
            midpoint(m, n),
            midpoint(n, o),
            midpoint(o, p),
            midpoint(p, m),
            midpoint(i, m),
            midpoint(j, n),
            midpoint(k, o),
            midpoint(l, p),
        )
    if element.kind is ElementKind.WEDGE6:
        if len(element.node_tags) != 6:
            raise CdbExportError(f"WEDGE6 element {element.tag} 必须有 6 个节点")
        i, j, k, m, n, o = element.node_tags
        # Degenerate the fourth and eighth corner slots (L=K, P=O).  The
        # corresponding collapsed-edge midside slots are the corner nodes;
        # both K-O and L-P share the same physical edge midpoint.
        ko = midpoint(k, o)
        return (
            i,
            j,
            k,
            k,
            m,
            n,
            o,
            o,
            midpoint(i, j),
            midpoint(j, k),
            k,
            midpoint(k, i),
            midpoint(m, n),
            midpoint(n, o),
            o,
            midpoint(o, m),
            midpoint(i, m),
            midpoint(j, n),
            ko,
            ko,
        )
    raise CdbExportError(f"不支持的单元类型：{element.kind}")


def _build_cdb_topology(
    mesh: VolumeMesh,
    element_type: int,
) -> _CdbTopology:
    source_nodes = tuple(sorted(mesh.nodes, key=lambda node: node.tag))
    source_node_tags = [node.tag for node in source_nodes]
    if len(source_node_tags) != len(set(source_node_tags)):
        raise CdbExportError("mesh 包含重复的 node tag")
    element_tags = [element.tag for element in mesh.elements]
    if len(element_tags) != len(set(element_tags)):
        raise CdbExportError("mesh 包含重复的 element tag")
    node_by_tag = {node.tag: node for node in source_nodes}
    referenced_tags = {
        tag for element in mesh.elements for tag in element.node_tags
    }
    missing = sorted(referenced_tags.difference(node_by_tag))
    if missing:
        raise CdbExportError(f"element connectivity 引用了不存在的节点 {missing[0]}")

    if element_type == 185:
        return _CdbTopology(
            nodes=source_nodes,
            midpoint_node_by_edge={},
            generated_midside_node_count=0,
        )
    if element_type != 186:
        raise CdbExportError(f"不支持的 ANSYS element type：{element_type}")

    unsupported_kinds = tuple(
        sorted(
            {
                element.kind
                for element in mesh.elements
                if element.kind not in (ElementKind.HEX8, ElementKind.WEDGE6)
            },
            key=lambda kind: kind.value,
        )
    )
    if unsupported_kinds:
        rendered = ", ".join(kind.value for kind in unsupported_kinds)
        raise CdbExportError(
            "SOLID186 导出目前只支持 HEX8/WEDGE6；"
            f"发现 {rendered}。请使用 SOLID185。"
        )

    if not source_nodes:
        raise CdbExportError("mesh 不包含节点")
    next_generated_tag = max(source_node_tags) + 1
    midpoint_node_by_edge: dict[tuple[int, int], int] = {}
    generated_nodes: list[MeshNode] = []
    # First-seen assignment over sorted elements and fixed local-edge order is
    # deterministic without materializing both a giant edge set and a sorted
    # copy.  This matters for the current several-hundred-thousand-cell meshes.
    for element in sorted(mesh.elements, key=lambda item: item.tag):
        for edge in _element_edges(element):
            if edge in midpoint_node_by_edge:
                continue
            if next_generated_tag > _ANSYS_INTEGER_MAX:
                raise CdbExportError(
                    "生成 SOLID186 边中节点后，node tag 超出 CDB i9 上限"
                )
            midpoint_node_by_edge[edge] = next_generated_tag
            generated_nodes.append(
                MeshNode(
                    tag=next_generated_tag,
                    x=(node_by_tag[edge[0]].x + node_by_tag[edge[1]].x) / 2.0,
                    y=(node_by_tag[edge[0]].y + node_by_tag[edge[1]].y) / 2.0,
                    z=(node_by_tag[edge[0]].z + node_by_tag[edge[1]].z) / 2.0,
                )
            )
            next_generated_tag += 1
    return _CdbTopology(
        nodes=source_nodes + tuple(generated_nodes),
        midpoint_node_by_edge=midpoint_node_by_edge,
        generated_midside_node_count=len(generated_nodes),
    )


def _write_component_block(
    stream: TextIO,
    name: str,
    element_tags: Sequence[int],
) -> None:
    # Intentionally do not use negative compact ranges.  Positive explicit IDs
    # avoid historical reader differences and make NUMITEMS unambiguous.
    stream.write(f"CMBLOCK,{name},ELEM,{len(element_tags)}\n")
    stream.write("(8i10)\n")
    for start in range(0, len(element_tags), 8):
        stream.write(
            "".join(f"{tag:10d}" for tag in element_tags[start : start + 8])
            + "\n"
        )


def write_cdb(
    mesh: VolumeMesh,
    stream: TextIO,
    *,
    options: CdbExportOptions | None = None,
) -> _WriteResult:
    """Stream one blocked structural-solid CDB and return resolved metadata."""

    resolved = options or CdbExportOptions()
    resolved.validate()
    plan = _build_export_plan(mesh, resolved)
    topology = _build_cdb_topology(mesh, resolved.element_type)
    node_tags = {node.tag for node in topology.nodes}

    stream.write("/COM,EasyMesh Gmsh MSH 4.1 to ANSYS blocked CDB\n")
    stream.write("/COM,Coordinates are copied from the MSH with the reported scale\n")
    if topology.generated_midside_node_count:
        stream.write(
            "/COM,SOLID186 midside nodes were generated at shared edge midpoints\n"
        )
    stream.write("/PREP7\n")
    if resolved.units_label is not None:
        stream.write(f"/UNITS,{resolved.units_label.strip().upper()}\n")

    stream.write(
        f"NBLOCK,6,SOLID,{max(node_tags):9d},{len(topology.nodes):9d}\n"
    )
    stream.write("(3i9,6e21.13e3)\n")
    for node in topology.nodes:
        coordinates = tuple(
            value * resolved.coordinate_scale for value in node.coordinates
        )
        stream.write(
            f"{node.tag:9d}{0:9d}{0:9d}"
            + "".join(_format_ansys_real(value) for value in coordinates)
            + "\n"
        )
    stream.write("N,R5.3,LOC,       -1,\n")

    material_name_by_id: dict[int, str] = {}
    for component in plan.hypermesh_components:
        previous = material_name_by_id.setdefault(
            component.material_id,
            component.material_name,
        )
        if previous != component.material_name:
            raise AssertionError("one MAT ID must have one HyperMesh material name")
    for material in plan.primary_partition:
        material_name = material_name_by_id[material.material_id]
        stream.write("!!HMNAME MAT\n")
        stream.write(f'!!{material.material_id:10d} "{material_name}"\n')
        # HyperMesh's own ANSYS export emits this empty material scaffold when
        # a named MAT collector has no constitutive MP/MPDATA values.
        stream.write("MPTEMP,R5.0,1,1\n\n")

    used_type_ids = {
        component.element_type_id for component in plan.hypermesh_components
    }
    for origin in (_HYPERMESH_TEMPLATE, _HYPERMESH_TRANSITION):
        local_type_id = _HYPERMESH_TYPE_BY_ORIGIN[origin]
        if local_type_id not in used_type_ids:
            continue
        stream.write("!!HMNAME ET\n")
        stream.write(
            f'!!{local_type_id:10d} "{origin}_SOLID{resolved.element_type}"\n'
        )
        stream.write(f"ET,{local_type_id},{resolved.element_type}\n")

    element_by_tag = {element.tag: element for element in mesh.elements}
    for component in plan.hypermesh_components:
        property_key = (
            f"{component.element_type_id}-{component.material_id}-"
            f"{component.real_constant_id}"
        )
        color = 3 + ((component.component_id - 1) % 12)
        stream.write("!!HMNAME COMP\n")
        stream.write(
            f'!!   {property_key} {component.component_id} '
            f'"{component.component_name}"\n'
        )
        stream.write("!!HWCOLOR COMP\n")
        stream.write(f"!!   {property_key} {color}\n")
        stream.write(
            f"TYPE,{component.element_type_id} $ "
            f"MAT,{component.material_id} $ "
            f"REAL,{component.real_constant_id}\n"
        )
        member_tags = plan.hypermesh_component_members[
            component.component_name
        ]
        stream.write(
            f"EBLOCK,19,SOLID,{max(member_tags):9d},{len(member_tags):9d}\n"
        )
        stream.write("(19i9)\n")
        for element_tag in member_tags:
            element = element_by_tag[element_tag]
            connectivity = (
                solid185_connectivity(element)
                if resolved.element_type == 185
                else solid186_connectivity(
                    element,
                    topology.midpoint_node_by_edge,
                )
            )
            fields = (
                component.material_id,
                component.element_type_id,
                component.real_constant_id,
                component.section_id,
                0,  # element coordinate system
                0,  # birth/death flag
                0,  # solid-model reference
                0,  # shape flag; connectivity carries the degeneration
                len(connectivity),
                0,  # unused
                element.tag,
                *connectivity[:8],
            )
            if len(fields) != 19:
                raise AssertionError(
                    "EBLOCK first record must contain 19 integers"
                )
            stream.write("".join(f"{value:9d}" for value in fields) + "\n")
            if len(connectivity) > 8:
                stream.write(
                    "".join(
                        f"{value:9d}" for value in connectivity[8:]
                    )
                    + "\n"
                )
        stream.write(f"{-1:9d}\n")
        stream.write(f"CM, {component.component_name}, ELEM\n")
        stream.write("ESEL, NONE\n")

    stream.write("ESEL, ALL\n")

    for mapping in plan.component_mappings:
        _write_component_block(
            stream,
            mapping.component_name,
            plan.component_members[mapping.component_name],
        )
    stream.write("ALLSEL,ALL\n")
    stream.write("FINISH\n")
    return _WriteResult(plan=plan, topology=topology)


def export_msh_to_cdb(
    msh_path: str | Path,
    cdb_path: str | Path | None = None,
    *,
    options: CdbExportOptions | None = None,
    job_id: str | None = None,
) -> CdbExportSummary:
    """Load, validate, atomically publish, and report one MSH→CDB conversion."""

    source = Path(msh_path).expanduser().resolve()
    output = normalized_cdb_output(
        source.with_suffix(".cdb") if cdb_path is None else cdb_path
    )
    resolved = options or CdbExportOptions()
    resolved.validate()
    report_path = output.with_name(f"{output.name}.report.json")
    for artifact_name, artifact_path in (
        ("CDB 输出", output),
        ("CDB report", report_path),
    ):
        if paths_refer_to_same_file(source, artifact_path):
            raise CdbExportError(
                f"MSH 输入不能被{artifact_name}覆盖：{artifact_path}"
            )
    if paths_refer_to_same_file(output, report_path):
        raise CdbExportError("CDB 输出与 report 路径不能指向同一个文件")

    output.parent.mkdir(parents=True, exist_ok=True)
    with exclusive_artifact_lock(output):
        # Use the same global lock order as package assembly: output first,
        # immutable source second.  The same-file checks above are deliberately
        # completed before either lock so this cannot recursively lock one
        # artifact through two aliases.
        with exclusive_artifact_lock(source):
            try:
                source_artifact = file_artifact(source)
            except OSError as exc:
                raise CdbExportError(
                    f"无法读取或指纹校验 MSH 输入：{source}"
                ) from exc
            load_error: VolumeMeshError | None = None
            try:
                mesh = load_volume_mesh(source)
            except VolumeMeshError as exc:
                load_error = exc
            try:
                source_artifact_after_load = file_artifact(source)
            except OSError as exc:
                raise CdbExportError(
                    f"无法读取或指纹校验 MSH 输入：{source}"
                ) from exc
            if source_artifact != source_artifact_after_load:
                raise CdbExportError(
                    "MSH 输入在读取期间发生变化（size/SHA-256 不稳定）："
                    f"{source}"
                )
            if load_error is not None:
                raise CdbExportError(str(load_error)) from load_error

            with atomic_output_path(output) as temporary_output:
                with temporary_output.open(
                    "w",
                    encoding="ascii",
                    newline="\n",
                ) as stream:
                    write_result = write_cdb(mesh, stream, options=resolved)
                    stream.flush()
                    os.fsync(stream.fileno())
                artifact = file_artifact(
                    temporary_output,
                    published_path=output,
                )

            kind_counts = Counter(element.kind for element in mesh.elements)
            plan = write_result.plan
            topology = write_result.topology
            summary = CdbExportSummary(
                source_mesh_path=str(source),
                source_mesh_artifact=source_artifact,
                cdb_path=str(output),
                report_path=str(report_path),
                source_node_count=len(mesh.nodes),
                node_count=len(topology.nodes),
                generated_midside_node_count=topology.generated_midside_node_count,
                element_count=len(mesh.elements),
                hex_count=kind_counts[ElementKind.HEX8],
                wedge_count=kind_counts[ElementKind.WEDGE6],
                tet_count=kind_counts[ElementKind.TET4],
                pyramid_count=kind_counts[ElementKind.PYRAMID5],
                component_count=len(plan.component_mappings),
                component_mappings=plan.component_mappings,
                primary_partition_kind=plan.primary_partition_kind,
                primary_partition=plan.primary_partition,
                hypermesh_component_count=len(plan.hypermesh_components),
                hypermesh_components=plan.hypermesh_components,
                overlapping_element_count=plan.overlapping_element_count,
                max_components_per_element=plan.max_components_per_element,
                element_type=resolved.element_type,
                coordinate_scale=resolved.coordinate_scale,
                units_label=(
                    resolved.units_label.strip().upper()
                    if resolved.units_label is not None
                    else None
                ),
                source_min_jacobian_determinant=mesh.min_jacobian_determinant,
                material_properties_written=False,
                cdb_artifact=artifact,
            )
            report_payload: dict[str, object] = summary.to_dict()
            if job_id is not None:
                report_payload["job_id"] = job_id
            atomic_write_text(
                report_path,
                json.dumps(report_payload, indent=2, ensure_ascii=False),
            )
    return summary


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="easymesh-msh-to-cdb",
        description=(
            "把 EasyMesh Gmsh MSH 4.1 TET4/HEX8/WEDGE6/PYRAMID5 "
            "转为 ANSYS SOLID185 CDB；HEX8/WEDGE6 也可转 SOLID186，"
            "保留模板 × component、过渡、材料及全局 Sets。"
        ),
    )
    parser.add_argument("msh", type=Path, help="输入 Gmsh MSH 4.1 文件")
    parser.add_argument("--job-id", help=argparse.SUPPRESS)
    parser.add_argument("-o", "--output", type=Path, help="输出 .cdb 文件")
    parser.add_argument(
        "--element-type",
        type=int,
        choices=_SUPPORTED_ANSYS_ELEMENT_TYPES,
        default=185,
        help=(
            "ANSYS 体单元：185（线性，默认，支持全部四种形状）；"
            "186（二次，仅 HEX8/WEDGE6，自动生成边中节点）"
        ),
    )
    parser.add_argument(
        "--coordinate-scale",
        type=float,
        default=1.0,
        help="写出坐标缩放；EasyMesh 的 mm→mm 保持默认 1.0",
    )
    parser.add_argument(
        "--units",
        default="MPA",
        help="写入 /UNITS 标签；默认 MPA（长度 mm），使用 NONE 可省略",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(sys.argv[1:] if argv is None else argv)
    units = None if args.units.upper() == "NONE" else args.units
    try:
        job_options = {"job_id": args.job_id} if args.job_id else {}
        summary = export_msh_to_cdb(
            args.msh,
            args.output,
            options=CdbExportOptions(
                element_type=args.element_type,
                coordinate_scale=args.coordinate_scale,
                units_label=units,
            ),
            **job_options,
        )
    except (CdbExportError, OSError, RuntimeError) as exc:
        print(f"MSH→CDB 转换失败：{exc}", file=sys.stderr)
        return 2
    print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
    return 0


__all__ = [
    "CdbExportError",
    "CdbExportOptions",
    "CdbExportSummary",
    "ComponentMapping",
    "HyperMeshComponentMapping",
    "PrimaryPartitionMapping",
    "export_msh_to_cdb",
    "main",
    "normalized_cdb_output",
    "sanitize_component_names",
    "solid185_connectivity",
    "solid186_connectivity",
    "write_cdb",
]


if __name__ == "__main__":  # pragma: no cover - exercised through console script
    raise SystemExit(main())
