"""Reopen and audit one assembled mixed Package V2 volume mesh.

Requested strategy is not evidence.  This module binds the numbered MSH back
to the exact assembly plan, asks Gmsh for signed first-order quality metrics,
and checks every Generated cell against its Component-owned strategy.
Frozen volume connectivity is immutable and never copied into a Generated
Component.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
from types import MappingProxyType

from .component_interface import ComponentMeshRequirement
from .gmsh_runtime import isolated_gmsh_model
from .package_v2_mixed_mesh_assembly import (
    AssembledMixedElement,
    FROZEN_FRAGMENT_KEY,
    MixedMeshAssemblyPlan,
    _audit_no_unpaired_coplanar_free_face_overlap,
    _polygon_area_3d,
)
from .package_v2_mixed_mesh_fragments import (
    ORTHOGONAL_HEX_CONTINUATION_PROVENANCE,
)
from .volume_mesh import ELEMENT_SPECS, ElementKind, VolumeMesh, load_volume_mesh


_QUALITY_NAMES = ("minDetJac", "minSJ", "minSICN", "minSIGE", "volume")
_QUALITY_FLOOR = 0.03
_SHARED_SURFACE_EDGE_REL_TOLERANCE = 1.0e-8
_SHARED_SURFACE_EDGE_ABS_TOLERANCE_MM = 1.0e-10


class MixedMeshReopenAuditError(ValueError):
    """The serialized MSH does not prove the declared mixed-mesh contract."""


def numbered_mixed_mesh_sha256(mesh: VolumeMesh) -> str:
    """Bind exact numbering, coordinates, connectivity, entities and groups."""

    if not isinstance(mesh, VolumeMesh):
        raise MixedMeshReopenAuditError("mesh must be a VolumeMesh")
    payload = {
        "schema": "easymesh-package-v2-mixed-numbered-mesh-v1",
        "dimensional_element_counts": list(mesh.dimensional_element_counts),
        "nodes": [
            [
                node.tag,
                *[0.0 if value == 0.0 else value for value in node.coordinates],
            ]
            for node in sorted(mesh.nodes, key=lambda value: value.tag)
        ],
        "elements": [
            [
                element.tag,
                element.kind.value,
                element.gmsh_type,
                list(element.node_tags),
                element.entity_tag,
                [
                    [group.tag, group.name, group.explicitly_named]
                    for group in sorted(
                        element.physical_groups,
                        key=lambda value: value.tag,
                    )
                ],
            ]
            for element in sorted(mesh.elements, key=lambda value: value.tag)
        ],
    }
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _finite_floor(value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise MixedMeshReopenAuditError("minimum_quality must be numeric")
    result = float(value)
    if not math.isfinite(result) or result < _QUALITY_FLOOR or result >= 1.0:
        raise MixedMeshReopenAuditError(
            "minimum_quality must be finite, at least 0.03, and below one"
        )
    return result


def _freeze_counts(
    values: Mapping[str, Counter[str]],
) -> Mapping[str, Mapping[str, int]]:
    return MappingProxyType(
        {
            key: MappingProxyType(dict(sorted(counter.items())))
            for key, counter in sorted(values.items())
        }
    )


def _cartesian_hex(
    node_tags: Sequence[int],
    coordinates: Mapping[int, tuple[float, float, float]],
    *,
    tolerance: float = 1.0e-10,
) -> bool:
    points = tuple(coordinates[tag] for tag in node_tags)
    levels: list[tuple[float, float]] = []
    for axis in range(3):
        ordered = sorted(point[axis] for point in points)
        clusters: list[list[float]] = []
        for value in ordered:
            if not clusters or abs(value - clusters[-1][-1]) > tolerance:
                clusters.append([value])
            else:
                clusters[-1].append(value)
        if len(clusters) != 2:
            return False
        levels.append(
            tuple(math.fsum(cluster) / len(cluster) for cluster in clusters)  # type: ignore[arg-type]
        )
    expected = {
        (x_value, y_value, z_value)
        for x_value in levels[0]
        for y_value in levels[1]
        for z_value in levels[2]
    }
    for point in points:
        if not any(math.dist(point, expected_point) <= tolerance for expected_point in expected):
            return False
    return len(
        {
            min(expected, key=lambda value: math.dist(point, value))
            for point in points
        }
    ) == 8


@dataclass(frozen=True, slots=True)
class ReopenedComponentQuality:
    component_id: str
    minimum_jacobian_determinant: float
    minimum_scaled_jacobian: float
    minimum_sicn: float
    minimum_sige: float
    volume_mm3: float


@dataclass(frozen=True, slots=True)
class ReopenedOrthogonalSicnAspectRatioExemption:
    component_id: str
    minimum_sicn: float
    element_count: int
    required_quality: float
    cartesian_hex_verified: bool = True

    def __post_init__(self) -> None:
        if (
            not self.component_id
            or not math.isfinite(self.minimum_sicn)
            or self.minimum_sicn <= 0.0
            or not math.isfinite(self.required_quality)
            or self.minimum_sicn >= self.required_quality
            or self.element_count < 1
            or self.cartesian_hex_verified is not True
        ):
            raise MixedMeshReopenAuditError(
                "orthogonal SICN aspect-ratio exemption evidence is invalid"
            )


@dataclass(frozen=True, slots=True)
class ReopenedOrthogonalHexContinuationSicnExemption:
    component_id: str
    minimum_sicn: float
    element_count: int
    required_quality: float
    producer_component_ids: tuple[str, ...]
    shared_surface_sizing_contract_ids: tuple[str, ...]
    exact_shared_quad_owner_verified: bool = True
    cartesian_hex_verified: bool = True

    def __post_init__(self) -> None:
        if (
            not self.component_id
            or not math.isfinite(self.minimum_sicn)
            or self.minimum_sicn <= 0.0
            or not math.isfinite(self.required_quality)
            or self.minimum_sicn >= self.required_quality
            or self.element_count < 1
            or not self.producer_component_ids
            or not self.shared_surface_sizing_contract_ids
            or self.exact_shared_quad_owner_verified is not True
            or self.cartesian_hex_verified is not True
        ):
            raise MixedMeshReopenAuditError(
                "Orth-origin HEX continuation SICN exemption evidence is invalid"
            )


@dataclass(frozen=True, slots=True)
class MixedMeshReopenAudit:
    mesh: VolumeMesh
    node_count: int
    element_count: int
    duplicate_node_count: int
    free_face_count: int
    internal_face_count: int
    minimum_jacobian_determinant: float
    minimum_scaled_jacobian: float
    minimum_sicn: float
    minimum_sige: float
    volume_mm3: float
    component_quality: Mapping[str, ReopenedComponentQuality]
    component_element_kind_counts: Mapping[str, Mapping[str, int]]
    orthogonal_cartesian_hex_verified: Mapping[str, bool]
    orthogonal_sicn_aspect_ratio_exemptions: Mapping[
        str, ReopenedOrthogonalSicnAspectRatioExemption
    ]
    orthogonal_hex_continuation_sicn_aspect_ratio_exemptions: Mapping[
        str, ReopenedOrthogonalHexContinuationSicnExemption
    ]
    shared_surface_target_edge_mm_by_contract_id: Mapping[str, float]
    shared_surface_maximum_edge_mm_by_contract_id: Mapping[str, float]
    shared_surface_facet_count_by_contract_id: Mapping[str, int]
    complete_support_plane_area_mm2_by_interface_key: Mapping[str, float]
    complete_support_plane_facet_count_by_interface_key: Mapping[str, int]
    shared_surface_sizing_verified: bool = True
    complete_support_plane_interfaces_verified: bool = True
    unpaired_coplanar_free_faces_verified: bool = True
    numbered_plan_replay_verified: bool = True
    strategy_aware_quality_floor_met: bool = True

    def __post_init__(self) -> None:
        for field_name in (
            "component_quality",
            "component_element_kind_counts",
            "orthogonal_cartesian_hex_verified",
            "orthogonal_sicn_aspect_ratio_exemptions",
            "orthogonal_hex_continuation_sicn_aspect_ratio_exemptions",
            "shared_surface_target_edge_mm_by_contract_id",
            "shared_surface_maximum_edge_mm_by_contract_id",
            "shared_surface_facet_count_by_contract_id",
            "complete_support_plane_area_mm2_by_interface_key",
            "complete_support_plane_facet_count_by_interface_key",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )
        if any(
            component_id != evidence.component_id
            or self.orthogonal_cartesian_hex_verified.get(component_id) is not True
            for component_id, evidence in (
                self.orthogonal_sicn_aspect_ratio_exemptions.items()
            )
        ):
            raise MixedMeshReopenAuditError(
                "orthogonal SICN exemptions require matching Cartesian evidence"
            )
        if any(
            component_id != evidence.component_id
            for component_id, evidence in (
                self.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions.items()
            )
        ):
            raise MixedMeshReopenAuditError(
                "Orth-origin HEX continuation exemptions require matching "
                "Component evidence"
            )
        if self.shared_surface_sizing_verified is not True:
            raise MixedMeshReopenAuditError(
                "shared-surface sizing must be verified"
            )
        if self.complete_support_plane_interfaces_verified is not True:
            raise MixedMeshReopenAuditError(
                "complete support-plane interfaces must be verified"
            )
        if self.unpaired_coplanar_free_faces_verified is not True:
            raise MixedMeshReopenAuditError(
                "unpaired coplanar free faces must be rejected"
            )
        if self.numbered_plan_replay_verified is not True:
            raise MixedMeshReopenAuditError("numbered plan replay must be verified")
        if self.strategy_aware_quality_floor_met is not True:
            raise MixedMeshReopenAuditError(
                "strategy-aware reopened quality floor must be verified"
            )


def _replay_numbered_plan(mesh: VolumeMesh, plan: MixedMeshAssemblyPlan) -> None:
    if len(mesh.nodes) != len(plan.nodes) or len(mesh.elements) != len(plan.elements):
        raise MixedMeshReopenAuditError(
            "reopened MSH node/element counts differ from the assembly plan"
        )
    node_by_tag = mesh.node_map()
    if set(node_by_tag) != {node.output_tag for node in plan.nodes}:
        raise MixedMeshReopenAuditError("reopened MSH node tags changed")
    for node in plan.nodes:
        if math.dist(
            node_by_tag[node.output_tag].coordinates,
            node.coordinates_mm,
        ) > 1.0e-12:
            raise MixedMeshReopenAuditError("reopened MSH node coordinates changed")
    element_by_tag = {element.tag: element for element in mesh.elements}
    if set(element_by_tag) != {element.output_tag for element in plan.elements}:
        raise MixedMeshReopenAuditError("reopened MSH element tags changed")
    for expected in plan.elements:
        actual = element_by_tag[expected.output_tag]
        if (
            actual.gmsh_type != expected.gmsh_type
            or actual.node_tags != expected.node_tags
        ):
            raise MixedMeshReopenAuditError(
                "reopened MSH element type or ordered connectivity changed"
            )


def _face_counts(mesh: VolumeMesh) -> tuple[int, int]:
    owners: Counter[tuple[int, ...]] = Counter()
    for element in mesh.elements:
        for face in ELEMENT_SPECS[element.gmsh_type][2]:
            owners[
                tuple(sorted(element.node_tags[index] for index in face))
            ] += 1
    if any(count not in {1, 2} for count in owners.values()):
        raise MixedMeshReopenAuditError(
            "reopened MSH contains a non-manifold volume face"
        )
    return (
        sum(count == 1 for count in owners.values()),
        sum(count == 2 for count in owners.values()),
    )


def _orthogonal_hex_continuation_evidence(
    plan: MixedMeshAssemblyPlan,
    requirements: Mapping[str, ComponentMeshRequirement],
    coordinates: Mapping[int, tuple[float, float, float]],
    face_owners: Mapping[tuple[int, ...], Sequence[AssembledMixedElement]],
) -> Mapping[str, tuple[tuple[int, ...], tuple[str, ...], tuple[str, ...]]]:
    """Prove each marked Hybrid HEX is the exact owner behind an Orth QUAD."""

    contract_ids_by_face: dict[tuple[int, ...], set[str]] = defaultdict(set)
    for contract in plan.shared_surface_sizing_contracts:
        for facet in contract.face_node_tags:
            contract_ids_by_face[tuple(sorted(facet))].add(contract.contract_id)

    tags_by_component: dict[str, list[int]] = defaultdict(list)
    producers_by_component: dict[str, set[str]] = defaultdict(set)
    contracts_by_component: dict[str, set[str]] = defaultdict(set)
    for element in plan.elements:
        if element.provenance != ORTHOGONAL_HEX_CONTINUATION_PROVENANCE:
            continue
        requirement = requirements.get(element.component_key)
        if (
            requirement is None
            or requirement.volume_topology != "conformal_hybrid"
            or element.gmsh_type != 5
        ):
            raise MixedMeshReopenAuditError(
                "Orth-origin HEX continuation provenance requires one "
                "Generated conformal_hybrid HEX8"
            )
        continuation_is_cartesian = _cartesian_hex(
            element.node_tags,
            coordinates,
            tolerance=plan.interface_geometry_tolerance_mm,
        )
        qualifying: list[tuple[str, str]] = []
        for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
            facet = tuple(element.node_tags[index] for index in local_face)
            key = tuple(sorted(facet))
            if len(facet) != 4 or key not in contract_ids_by_face:
                continue
            owners = tuple(face_owners.get(key, ()))
            if len(owners) != 2:
                continue
            other = next(
                (
                    owner
                    for owner in owners
                    if owner.output_tag != element.output_tag
                ),
                None,
            )
            other_requirement = (
                None
                if other is None
                else requirements.get(other.component_key)
            )
            if (
                other is None
                or other_requirement is None
                or other_requirement.volume_topology != "orthogonal_hex"
                or other.gmsh_type != 5
                or not _cartesian_hex(
                    other.node_tags,
                    coordinates,
                    tolerance=plan.interface_geometry_tolerance_mm,
                )
            ):
                continue
            contract_ids = contract_ids_by_face[key]
            if len(contract_ids) != 1:
                raise MixedMeshReopenAuditError(
                    "one Orth-origin HEX continuation face must belong to "
                    "exactly one shared-surface sizing contract"
                )
            qualifying.append((other.component_key, next(iter(contract_ids))))
        if len(qualifying) != 1:
            raise MixedMeshReopenAuditError(
                "marked Orth-origin HEX continuation does not own exactly one "
                "contracted shared QUAD opposite a Cartesian Orth HEX"
            )
        producer_component_id, contract_id = qualifying[0]
        if continuation_is_cartesian:
            tags_by_component[element.component_key].append(element.output_tag)
            producers_by_component[element.component_key].add(producer_component_id)
            contracts_by_component[element.component_key].add(contract_id)

    return MappingProxyType(
        {
            component_id: (
                tuple(sorted(tags)),
                tuple(sorted(producers_by_component[component_id])),
                tuple(sorted(contracts_by_component[component_id])),
            )
            for component_id, tags in sorted(tags_by_component.items())
        }
    )


def _audit_complete_support_plane_interfaces(
    mesh: VolumeMesh,
    plan: MixedMeshAssemblyPlan,
) -> tuple[Mapping[str, float], Mapping[str, int]]:
    """Replay every complete-plane adjacency against the numbered MSH."""

    planned_by_tag = {element.output_tag: element for element in plan.elements}
    face_owners: dict[
        tuple[int, ...], list[AssembledMixedElement]
    ] = defaultdict(list)
    for element in mesh.elements:
        planned = planned_by_tag[element.tag]
        for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
            face_owners[
                tuple(sorted(element.node_tags[index] for index in local_face))
            ].append(planned)
    coordinates = {node.tag: node.coordinates for node in mesh.nodes}
    tolerance = plan.interface_geometry_tolerance_mm
    areas: dict[str, float] = {}
    counts: dict[str, int] = {}
    seen_faces: dict[tuple[int, ...], str] = {}
    for interface in plan.complete_support_plane_interfaces:
        if interface.interface_key in areas:
            raise MixedMeshReopenAuditError(
                "assembly plan repeats a complete support-plane interface"
            )
        measured_area = 0.0
        for cycle in interface.face_node_tags:
            key = tuple(sorted(cycle))
            previous = seen_faces.setdefault(key, interface.interface_key)
            if previous != interface.interface_key:
                raise MixedMeshReopenAuditError(
                    "one numbered facet belongs to multiple complete "
                    "support-plane interfaces"
                )
            if any(
                abs(
                    coordinates[node][interface.plane_axis]
                    - interface.plane_coordinate_mm
                )
                > tolerance
                for node in cycle
            ):
                raise MixedMeshReopenAuditError(
                    "numbered complete-interface facet left its support plane"
                )
            owners = face_owners.get(key, ())
            if (
                len(owners) != 2
                or {owner.source_fragment_key for owner in owners}
                != {
                    interface.first_fragment_key,
                    interface.second_fragment_key,
                }
            ):
                raise MixedMeshReopenAuditError(
                    "numbered complete-interface facet is not shared by exactly "
                    "its two expected fragments"
                )
            owner_sides: list[int] = []
            for owner in owners:
                signed_distances = tuple(
                    coordinates[node][interface.plane_axis]
                    - interface.plane_coordinate_mm
                    for node in owner.node_tags
                    if node not in key
                )
                if not signed_distances or any(
                    abs(distance) <= tolerance for distance in signed_distances
                ):
                    raise MixedMeshReopenAuditError(
                        "numbered complete-interface owner has no unambiguous "
                        "volume side"
                    )
                signs = {1 if distance > 0.0 else -1 for distance in signed_distances}
                if len(signs) != 1:
                    raise MixedMeshReopenAuditError(
                        "numbered complete-interface owner straddles its plane"
                    )
                owner_sides.append(next(iter(signs)))
            if set(owner_sides) != {-1, 1}:
                raise MixedMeshReopenAuditError(
                    "numbered complete-interface owners do not occupy opposite "
                    "sides"
                )
            measured_area += _polygon_area_3d(
                tuple(coordinates[node] for node in cycle)
            )
        area_tolerance = max(
            tolerance * tolerance,
            8.0 * tolerance * math.sqrt(max(interface.area_mm2, tolerance**2)),
            1.0e-10 * interface.area_mm2,
        )
        if abs(measured_area - interface.area_mm2) > area_tolerance:
            raise MixedMeshReopenAuditError(
                "numbered complete support-plane interface area changed: "
                f"interface={interface.interface_key!r}, "
                f"measured={measured_area:.12g} mm2, "
                f"planned={interface.area_mm2:.12g} mm2"
            )
        areas[interface.interface_key] = measured_area
        counts[interface.interface_key] = len(interface.face_node_tags)
    if (
        len(areas) != plan.audit.complete_support_plane_interface_count
        or sum(counts.values())
        != plan.audit.complete_support_plane_face_count
    ):
        raise MixedMeshReopenAuditError(
            "complete support-plane evidence differs from the assembly audit"
        )
    return (
        MappingProxyType(dict(sorted(areas.items()))),
        MappingProxyType(dict(sorted(counts.items()))),
    )


def _audit_shared_surface_sizes(
    mesh: VolumeMesh,
    plan: MixedMeshAssemblyPlan,
) -> tuple[
    Mapping[str, float],
    Mapping[str, float],
    Mapping[str, int],
]:
    coordinates = {node.tag: node.coordinates for node in mesh.nodes}
    targets: dict[str, float] = {}
    maxima: dict[str, float] = {}
    counts: dict[str, int] = {}
    for contract in plan.shared_surface_sizing_contracts:
        if contract.contract_id in targets:
            raise MixedMeshReopenAuditError(
                "assembly plan repeats a shared-surface sizing contract"
            )
        target = float(contract.target_edge_mm)
        edges = tuple(
            math.dist(
                coordinates[face[index]],
                coordinates[face[(index + 1) % len(face)]],
            )
            for face in contract.face_node_tags
            for index in range(len(face))
        )
        if not edges:
            raise MixedMeshReopenAuditError(
                "shared-surface sizing contract contains no facet edges"
            )
        maximum = max(edges)
        tolerance = max(
            _SHARED_SURFACE_EDGE_ABS_TOLERANCE_MM,
            target * _SHARED_SURFACE_EDGE_REL_TOLERANCE,
        )
        if maximum > target + tolerance:
            raise MixedMeshReopenAuditError(
                "reopened shared surface exceeds its negotiated target edge: "
                f"contract={contract.contract_id!r}, maximum={maximum:.12g} mm, "
                f"target={target:.12g} mm, tolerance={tolerance:.12g} mm"
            )
        targets[contract.contract_id] = target
        maxima[contract.contract_id] = maximum
        counts[contract.contract_id] = len(contract.face_node_tags)
    return (
        MappingProxyType(dict(sorted(targets.items()))),
        MappingProxyType(dict(sorted(maxima.items()))),
        MappingProxyType(dict(sorted(counts.items()))),
    )


def _gmsh_quality(
    gmsh: object,
    tags: Sequence[int],
) -> Mapping[str, tuple[float, ...]]:
    metrics: dict[str, tuple[float, ...]] = {}
    for name in _QUALITY_NAMES:
        values = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(tags, name)  # type: ignore[attr-defined]
        )
        if len(values) != len(tags) or any(not math.isfinite(value) for value in values):
            raise MixedMeshReopenAuditError(
                f"Gmsh returned incomplete or non-finite {name} evidence"
            )
        metrics[name] = values
    return MappingProxyType(metrics)


def _format_point(point: Sequence[float]) -> str:
    return "(" + ", ".join(f"{float(value):.12g}" for value in point) + ")"


def _worst_quality_element_evidence(
    mesh: VolumeMesh,
    plan: MixedMeshAssemblyPlan,
    tags: Sequence[int],
    metrics: Mapping[str, Sequence[float]],
    metric_names: Sequence[str],
    *,
    candidate_tags_by_metric: Mapping[str, Sequence[int]] | None = None,
) -> str:
    """Render deterministic ownership and location evidence for failed metrics."""

    plan_by_tag = {element.output_tag: element for element in plan.elements}
    mesh_by_tag = {element.tag: element for element in mesh.elements}
    coordinates = {node.tag: node.coordinates for node in mesh.nodes}
    rendered: list[str] = []
    for metric_name in metric_names:
        values = metrics[metric_name]
        candidate_tags = (
            None
            if candidate_tags_by_metric is None
            else frozenset(candidate_tags_by_metric[metric_name])
        )
        candidate_indices = tuple(
            index
            for index, tag in enumerate(tags)
            if candidate_tags is None or tag in candidate_tags
        )
        if not candidate_indices:
            raise MixedMeshReopenAuditError(
                f"no candidate elements exist for failed metric {metric_name}"
            )
        worst_index = min(
            candidate_indices,
            key=lambda index: (float(values[index]), int(tags[index])),
        )
        element_tag = int(tags[worst_index])
        element = mesh_by_tag[element_tag]
        planned = plan_by_tag[element_tag]
        node_coordinates = tuple(
            coordinates[node_tag] for node_tag in element.node_tags
        )
        centroid = tuple(
            math.fsum(point[axis] for point in node_coordinates)
            / len(node_coordinates)
            for axis in range(3)
        )
        ownership = (
            "Frozen"
            if planned.component_key == FROZEN_FRAGMENT_KEY
            else "Generated"
        )
        rendered.append(
            "{"
            f"metric={metric_name}, value={float(values[worst_index]):.12g}, "
            f"element_tag={element_tag}, component_key={planned.component_key!r}, "
            f"element_kind={element.kind.value}, ownership={ownership}, "
            f"source_fragment_key={planned.source_fragment_key!r}, "
            f"centroid_mm={_format_point(centroid)}, "
            f"node_tags={element.node_tags!r}, "
            "node_coordinates_mm=("
            + ", ".join(_format_point(point) for point in node_coordinates)
            + ")}"
        )
    return "; ".join(rendered)


def audit_reopened_mixed_volume_mesh(
    mesh_path: str | Path,
    plan: MixedMeshAssemblyPlan,
    requirements: Mapping[str, ComponentMeshRequirement],
    *,
    minimum_quality: float = _QUALITY_FLOOR,
    verbose: bool = False,
) -> MixedMeshReopenAudit:
    """Audit serialized topology, quality and strategy conformance."""

    path = Path(mesh_path).expanduser().resolve()
    if not path.is_file():
        raise MixedMeshReopenAuditError("mixed MSH does not exist")
    if not isinstance(plan, MixedMeshAssemblyPlan):
        raise MixedMeshReopenAuditError("plan must be a MixedMeshAssemblyPlan")
    if not isinstance(requirements, Mapping):
        raise MixedMeshReopenAuditError("requirements must be a mapping")
    floor = _finite_floor(minimum_quality)
    if not isinstance(verbose, bool):
        raise MixedMeshReopenAuditError("verbose must be boolean")

    generated_components = {
        element.component_key
        for element in plan.elements
        if element.component_key != FROZEN_FRAGMENT_KEY
    }
    if set(requirements) != generated_components or any(
        type(requirement) is not ComponentMeshRequirement
        or requirement.component_id != component_id
        for component_id, requirement in requirements.items()
    ):
        raise MixedMeshReopenAuditError(
            "requirements must exactly cover generated assembly Components"
        )

    mesh = load_volume_mesh(path)
    if mesh.dimensional_element_counts[:3] != (0, 0, 0):
        raise MixedMeshReopenAuditError(
            "reopened mixed MSH contains independent 0D/1D/2D elements"
        )
    _replay_numbered_plan(mesh, plan)
    free_faces, internal_faces = _face_counts(mesh)
    if (
        free_faces != plan.audit.free_face_count
        or internal_faces != plan.audit.internal_face_count
    ):
        raise MixedMeshReopenAuditError(
            "reopened MSH face ownership differs from the assembly plan"
        )
    (
        shared_surface_targets,
        shared_surface_maxima,
        shared_surface_facet_counts,
    ) = _audit_shared_surface_sizes(mesh, plan)
    (
        complete_support_plane_areas,
        complete_support_plane_facet_counts,
    ) = _audit_complete_support_plane_interfaces(mesh, plan)
    plan_face_owners: dict[
        tuple[int, ...], list[AssembledMixedElement]
    ] = defaultdict(list)
    for element in plan.elements:
        for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
            plan_face_owners[
                tuple(sorted(element.node_tags[index] for index in local_face))
            ].append(element)
    try:
        _audit_no_unpaired_coplanar_free_face_overlap(
            plan.elements,
            {node.tag: node.coordinates for node in mesh.nodes},
            plan_face_owners,
            tolerance=plan.interface_geometry_tolerance_mm,
            error_type=MixedMeshReopenAuditError,
        )
    except MixedMeshReopenAuditError:
        raise
    except ValueError as error:
        raise MixedMeshReopenAuditError(str(error)) from error

    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover
        raise MixedMeshReopenAuditError("Gmsh is required for reopened quality") from error
    tags = tuple(element.tag for element in mesh.elements)
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_mixed_reopen_audit",
        number_options={"General.Terminal": 1.0 if verbose else 0.0},
    ):
        gmsh.merge(str(path))
        metrics = _gmsh_quality(gmsh, tags)
        duplicate_nodes = len(tuple(gmsh.model.mesh.getDuplicateNodes()))
    if duplicate_nodes:
        raise MixedMeshReopenAuditError(
            "reopened mixed MSH contains duplicate nodes"
        )
    minima = {
        name: min(metrics[name])
        for name in ("minDetJac", "minSJ", "minSICN", "minSIGE")
    }
    if minima["minDetJac"] <= 0.0:
        raise MixedMeshReopenAuditError(
            "reopened mixed MSH contains a non-positive Jacobian"
        )

    metric_by_tag = {
        tag: {name: metrics[name][index] for name in _QUALITY_NAMES}
        for index, tag in enumerate(tags)
    }
    plan_by_tag = {element.output_tag: element for element in plan.elements}
    coordinates = {node.tag: node.coordinates for node in mesh.nodes}
    all_counts: dict[str, Counter[str]] = defaultdict(Counter)
    tags_by_component: dict[str, list[int]] = defaultdict(list)
    cartesian_by_component: dict[str, bool] = {}
    for element in mesh.elements:
        planned = plan_by_tag[element.tag]
        component_id = planned.component_key
        tags_by_component[component_id].append(element.tag)
        all_counts[component_id][element.kind.value] += 1

    allowed = {
        "orthogonal_hex": {ElementKind.HEX8.value},
        "structured_sweep": {ElementKind.HEX8.value, ElementKind.WEDGE6.value},
        "conformal_hybrid": {
            ElementKind.TET4.value,
            ElementKind.HEX8.value,
            ElementKind.PYRAMID5.value,
            ElementKind.WEDGE6.value,
        },
    }
    mesh_element_by_tag = {element.tag: element for element in mesh.elements}
    for component_id, requirement in sorted(requirements.items()):
        counts = all_counts[component_id]
        if not counts:
            raise MixedMeshReopenAuditError(
                f"Generated Component {component_id!r} contains no cells"
            )
        if not set(counts).issubset(allowed[requirement.volume_topology]):
            raise MixedMeshReopenAuditError(
                f"Component {component_id!r} element kinds do not "
                f"match {requirement.volume_topology!r}: {dict(counts)!r}"
            )
        if requirement.volume_topology == "orthogonal_hex":
            verified = all(
                _cartesian_hex(
                    mesh_element_by_tag[tag].node_tags,
                    coordinates,
                    tolerance=plan.interface_geometry_tolerance_mm,
                )
                for tag in tags_by_component[component_id]
            )
            if not verified:
                raise MixedMeshReopenAuditError(
                    f"orthogonal_hex Component {component_id!r} contains a "
                    "non-Cartesian HEX8"
                )
            cartesian_by_component[component_id] = True

    continuation_evidence = _orthogonal_hex_continuation_evidence(
        plan,
        requirements,
        coordinates,
        plan_face_owners,
    )

    component_quality: dict[str, ReopenedComponentQuality] = {}
    for component_id, component_tags in sorted(tags_by_component.items()):
        values = tuple(metric_by_tag[tag] for tag in component_tags)
        component_quality[component_id] = ReopenedComponentQuality(
            component_id,
            min(value["minDetJac"] for value in values),
            min(value["minSJ"] for value in values),
            min(value["minSICN"] for value in values),
            min(value["minSIGE"] for value in values),
            math.fsum(value["volume"] for value in values),
        )

    exemptions: dict[str, ReopenedOrthogonalSicnAspectRatioExemption] = {}
    continuation_exemptions: dict[
        str, ReopenedOrthogonalHexContinuationSicnExemption
    ] = {}
    sicn_exempt_tags: set[int] = set()
    for component_id, component_tags in sorted(tags_by_component.items()):
        requirement = requirements.get(component_id)
        if (
            requirement is not None
            and requirement.volume_topology == "orthogonal_hex"
        ):
            sicn_exempt_tags.update(component_tags)
            quality = component_quality[component_id]
            if 0.0 < quality.minimum_sicn < floor:
                exemptions[component_id] = (
                    ReopenedOrthogonalSicnAspectRatioExemption(
                        component_id=component_id,
                        minimum_sicn=quality.minimum_sicn,
                        element_count=len(component_tags),
                        required_quality=floor,
                    )
                )
    for component_id, (
        continuation_tags,
        producer_component_ids,
        contract_ids,
    ) in continuation_evidence.items():
        sicn_exempt_tags.update(continuation_tags)
        minimum_continuation_sicn = min(
            metric_by_tag[tag]["minSICN"] for tag in continuation_tags
        )
        if 0.0 < minimum_continuation_sicn < floor:
            continuation_exemptions[component_id] = (
                ReopenedOrthogonalHexContinuationSicnExemption(
                    component_id=component_id,
                    minimum_sicn=minimum_continuation_sicn,
                    element_count=len(continuation_tags),
                    required_quality=floor,
                    producer_component_ids=producer_component_ids,
                    shared_surface_sizing_contract_ids=contract_ids,
                )
            )
    # Frozen, Sweep, unmarked Hybrid HEX, PYR/WEDGE/TET and every other cell
    # retain the fixed SICN floor.  Provenance alone is insufficient: the
    # helper above has already proved the exact shared QUAD and Cartesian
    # Orth owner for each excluded continuation HEX.
    # The exemption removes only the aspect-ratio floor.  A zero or negative
    # signed inverse condition number cannot be explained by a long, valid
    # Orth trace and remains a hard failure.
    non_exempt_sicn_tags = [
        tag
        for tag in tags
        if tag not in sicn_exempt_tags or metric_by_tag[tag]["minSICN"] <= 0.0
    ]

    hard_minima = dict(minima)
    candidate_tags_by_metric: dict[str, Sequence[int]] = {}
    misses: list[str] = []
    for name in ("minSJ", "minSIGE"):
        if minima[name] < floor:
            misses.append(name)
            candidate_tags_by_metric[name] = tags
    if non_exempt_sicn_tags:
        non_exempt_minimum_sicn = min(
            metric_by_tag[tag]["minSICN"] for tag in non_exempt_sicn_tags
        )
        hard_minima["minSICN"] = non_exempt_minimum_sicn
        if non_exempt_minimum_sicn < floor:
            misses.append("minSICN")
            candidate_tags_by_metric["minSICN"] = non_exempt_sicn_tags
    if misses:
        ordered_misses = tuple(
            name for name in ("minSJ", "minSICN", "minSIGE") if name in misses
        )
        rendered = ", ".join(
            f"{name}={hard_minima[name]:.8g}"
            for name in ("minSJ", "minSICN", "minSIGE")
        )
        worst_elements = _worst_quality_element_evidence(
            mesh,
            plan,
            tags,
            metrics,
            ordered_misses,
            candidate_tags_by_metric=candidate_tags_by_metric,
        )
        raise MixedMeshReopenAuditError(
            f"reopened mixed MSH quality floor was not met: {rendered}; "
            f"required={floor:.8g}; worst_failed_elements=[{worst_elements}]"
        )

    return MixedMeshReopenAudit(
        mesh=mesh,
        node_count=len(mesh.nodes),
        element_count=len(mesh.elements),
        duplicate_node_count=duplicate_nodes,
        free_face_count=free_faces,
        internal_face_count=internal_faces,
        minimum_jacobian_determinant=minima["minDetJac"],
        minimum_scaled_jacobian=minima["minSJ"],
        minimum_sicn=minima["minSICN"],
        minimum_sige=minima["minSIGE"],
        volume_mm3=math.fsum(metrics["volume"]),
        component_quality=MappingProxyType(component_quality),
        component_element_kind_counts=_freeze_counts(all_counts),
        orthogonal_cartesian_hex_verified=MappingProxyType(
            dict(sorted(cartesian_by_component.items()))
        ),
        orthogonal_sicn_aspect_ratio_exemptions=MappingProxyType(
            dict(sorted(exemptions.items()))
        ),
        orthogonal_hex_continuation_sicn_aspect_ratio_exemptions=(
            MappingProxyType(dict(sorted(continuation_exemptions.items())))
        ),
        shared_surface_target_edge_mm_by_contract_id=shared_surface_targets,
        shared_surface_maximum_edge_mm_by_contract_id=shared_surface_maxima,
        shared_surface_facet_count_by_contract_id=shared_surface_facet_counts,
        complete_support_plane_area_mm2_by_interface_key=(
            complete_support_plane_areas
        ),
        complete_support_plane_facet_count_by_interface_key=(
            complete_support_plane_facet_counts
        ),
    )


__all__ = [
    "MixedMeshReopenAudit",
    "MixedMeshReopenAuditError",
    "ReopenedComponentQuality",
    "ReopenedOrthogonalHexContinuationSicnExemption",
    "ReopenedOrthogonalSicnAspectRatioExemption",
    "audit_reopened_mixed_volume_mesh",
    "numbered_mixed_mesh_sha256",
]
