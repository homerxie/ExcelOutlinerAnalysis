"""Geometry-only adjacency discovery for generated Package V2 Components.

The extractor deliberately has no package-role vocabulary and never selects a
volume mesher.  It examines canonical positive geometry, keeps only pairs whose
boundaries share positive area, and returns
:class:`~easymesh.component_interface.CommonFaceCapability` records for the
separate topology negotiation layer.

Single-fragment axis-aligned Box/Frame pairs use a pure analytic rectangle
query.  Multi-fragment, rotated, and underfill-fillet pairs use an isolated OCC
geometry query so curved canonical solids remain exact; that fallback performs
only Boolean/boundary inspection and never generates a mesh.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
import math
from typing import Iterable, Mapping, Sequence

from .component_interface import (
    CommonFaceCapability,
    ComponentMeshRequirement,
    NegotiatedComponentInterface,
    PlanarTransportEvidence,
    negotiate_component_interface,
)
from .gmsh_runtime import isolated_gmsh_model
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalComponentGeometry,
    CanonicalGeneratedGeometry,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalRigidPlacement,
)
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)


_ANALYTIC_ABSOLUTE_TOLERANCE_MM = 1.0e-10
_ANALYTIC_RELATIVE_TOLERANCE = 1.0e-10
_OCC_ABSOLUTE_TOLERANCE_MM = 5.0e-7


class ComponentAdjacencyError(ValueError):
    """Raised when canonical components cannot form an adjacency graph."""


Vec3 = tuple[float, float, float]
Bounds3 = tuple[tuple[float, float], tuple[float, float], tuple[float, float]]


@dataclass(frozen=True, slots=True)
class _AxisRectangle:
    axis: int
    coordinate: float
    first_range: tuple[float, float]
    second_range: tuple[float, float]
    outward_sign: int


@dataclass(frozen=True, slots=True)
class _LocalRectangle:
    vertices: tuple[Vec3, Vec3, Vec3, Vec3]
    normal: Vec3


@dataclass(frozen=True, slots=True)
class _PairCapability:
    axis_aligned_planar: bool
    sweep_section_compatible: bool
    transport_evidence: PlanarTransportEvidence | None = None


def _matrix_product(
    left: tuple[Vec3, Vec3, Vec3],
    right: tuple[Vec3, Vec3, Vec3],
) -> tuple[Vec3, Vec3, Vec3]:
    return tuple(
        tuple(
            sum(left[row][inner] * right[inner][column] for inner in range(3))
            for column in range(3)
        )
        for row in range(3)
    )  # type: ignore[return-value]


def _rotation_matrix(placement: CanonicalRigidPlacement) -> tuple[Vec3, Vec3, Vec3]:
    rx, ry, rz = (math.radians(value) for value in placement.rotation_deg_xyz)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    rotate_x: tuple[Vec3, Vec3, Vec3] = (
        (1.0, 0.0, 0.0),
        (0.0, cx, -sx),
        (0.0, sx, cx),
    )
    rotate_y: tuple[Vec3, Vec3, Vec3] = (
        (cy, 0.0, sy),
        (0.0, 1.0, 0.0),
        (-sy, 0.0, cy),
    )
    rotate_z: tuple[Vec3, Vec3, Vec3] = (
        (cz, -sz, 0.0),
        (sz, cz, 0.0),
        (0.0, 0.0, 1.0),
    )
    return _matrix_product(rotate_z, _matrix_product(rotate_y, rotate_x))


def _matrix_vector(matrix: tuple[Vec3, Vec3, Vec3], value: Vec3) -> Vec3:
    return tuple(
        sum(matrix[row][column] * value[column] for column in range(3))
        for row in range(3)
    )  # type: ignore[return-value]


def _transform_point(
    point: Vec3,
    placement: CanonicalRigidPlacement,
    matrix: tuple[Vec3, Vec3, Vec3],
) -> Vec3:
    pivot = placement.pivot_xyz_mm
    shifted = tuple(point[index] - pivot[index] for index in range(3))
    rotated = _matrix_vector(matrix, shifted)  # type: ignore[arg-type]
    return tuple(
        placement.translation_xyz_mm[index] + pivot[index] + rotated[index]
        for index in range(3)
    )  # type: ignore[return-value]


def _scale_tolerance(values: Iterable[float]) -> float:
    scale = max((abs(float(value)) for value in values), default=1.0)
    return max(
        _ANALYTIC_ABSOLUTE_TOLERANCE_MM,
        _ANALYTIC_RELATIVE_TOLERANCE * max(scale, 1.0),
    )


def _rectangle(
    axis: int,
    coordinate: float,
    first_range: tuple[float, float],
    second_range: tuple[float, float],
    outward_sign: int,
) -> _LocalRectangle:
    other = tuple(index for index in range(3) if index != axis)
    vertices: list[Vec3] = []
    for first, second in (
        (first_range[0], second_range[0]),
        (first_range[1], second_range[0]),
        (first_range[1], second_range[1]),
        (first_range[0], second_range[1]),
    ):
        point = [0.0, 0.0, 0.0]
        point[axis] = coordinate
        point[other[0]] = first
        point[other[1]] = second
        vertices.append(tuple(point))  # type: ignore[arg-type]
    normal = [0.0, 0.0, 0.0]
    normal[axis] = float(outward_sign)
    return _LocalRectangle(
        tuple(vertices),  # type: ignore[arg-type]
        tuple(normal),  # type: ignore[arg-type]
    )


def _box_rectangles(root: CanonicalBox) -> tuple[_LocalRectangle, ...]:
    minimum = root.origin_xyz_mm
    maximum = tuple(
        minimum[index] + root.size_xyz_mm[index] for index in range(3)
    )
    output: list[_LocalRectangle] = []
    for axis in range(3):
        other = tuple(index for index in range(3) if index != axis)
        ranges = (
            (minimum[other[0]], maximum[other[0]]),
            (minimum[other[1]], maximum[other[1]]),
        )
        output.extend(
            (
                _rectangle(axis, minimum[axis], ranges[0], ranges[1], -1),
                _rectangle(axis, maximum[axis], ranges[0], ranges[1], 1),
            )
        )
    return tuple(output)


def _frame_xy_regions(
    root: CanonicalRectangularFrameExtrusion,
) -> tuple[tuple[tuple[float, float], tuple[float, float]], ...]:
    x0, y0, _z0 = root.outer_origin_xyz_mm
    x1 = x0 + root.outer_size_xy_mm[0]
    y1 = y0 + root.outer_size_xy_mm[1]
    hx0 = x0 + root.opening_offset_xy_mm[0]
    hy0 = y0 + root.opening_offset_xy_mm[1]
    hx1 = hx0 + root.opening_size_xy_mm[0]
    hy1 = hy0 + root.opening_size_xy_mm[1]
    return (
        ((x0, hx0), (y0, y1)),
        ((hx1, x1), (y0, y1)),
        ((hx0, hx1), (y0, hy0)),
        ((hx0, hx1), (hy1, y1)),
    )


def _frame_rectangles(
    root: CanonicalRectangularFrameExtrusion,
) -> tuple[_LocalRectangle, ...]:
    x0, y0, z0 = root.outer_origin_xyz_mm
    x1 = x0 + root.outer_size_xy_mm[0]
    y1 = y0 + root.outer_size_xy_mm[1]
    z1 = z0 + root.height_mm
    hx0 = x0 + root.opening_offset_xy_mm[0]
    hy0 = y0 + root.opening_offset_xy_mm[1]
    hx1 = hx0 + root.opening_size_xy_mm[0]
    hy1 = hy0 + root.opening_size_xy_mm[1]
    output: list[_LocalRectangle] = []
    for x_range, y_range in _frame_xy_regions(root):
        output.extend(
            (
                _rectangle(2, z0, x_range, y_range, -1),
                _rectangle(2, z1, x_range, y_range, 1),
            )
        )
    output.extend(
        (
            _rectangle(0, x0, (y0, y1), (z0, z1), -1),
            _rectangle(0, x1, (y0, y1), (z0, z1), 1),
            _rectangle(1, y0, (x0, x1), (z0, z1), -1),
            _rectangle(1, y1, (x0, x1), (z0, z1), 1),
            _rectangle(0, hx0, (hy0, hy1), (z0, z1), 1),
            _rectangle(0, hx1, (hy0, hy1), (z0, z1), -1),
            _rectangle(1, hy0, (hx0, hx1), (z0, z1), 1),
            _rectangle(1, hy1, (hx0, hx1), (z0, z1), -1),
        )
    )
    return tuple(output)


def _root_rectangles(root: object) -> tuple[_LocalRectangle, ...] | None:
    if type(root) is CanonicalBox:
        return _box_rectangles(root)
    if type(root) is CanonicalRectangularFrameExtrusion:
        return _frame_rectangles(root)
    return None


def _root_box_cells(root: object) -> tuple[Bounds3, ...] | None:
    if type(root) is CanonicalBox:
        minimum = root.origin_xyz_mm
        maximum = tuple(
            minimum[index] + root.size_xyz_mm[index] for index in range(3)
        )
        return (tuple(zip(minimum, maximum)),)  # type: ignore[return-value]
    if type(root) is CanonicalRectangularFrameExtrusion:
        z0 = root.outer_origin_xyz_mm[2]
        z1 = z0 + root.height_mm
        return tuple(
            (x_range, y_range, (z0, z1))
            for x_range, y_range in _frame_xy_regions(root)
        )
    return None


def _transform_rectangle(
    rectangle: _LocalRectangle,
    placement: CanonicalRigidPlacement,
    matrix: tuple[Vec3, Vec3, Vec3],
) -> _AxisRectangle | None:
    normal = _matrix_vector(matrix, rectangle.normal)
    axis = max(range(3), key=lambda index: abs(normal[index]))
    tolerance = _scale_tolerance((*normal,))
    if abs(abs(normal[axis]) - 1.0) > tolerance or any(
        abs(normal[index]) > tolerance for index in range(3) if index != axis
    ):
        return None
    vertices = tuple(
        _transform_point(point, placement, matrix) for point in rectangle.vertices
    )
    coordinate = sum(point[axis] for point in vertices) / len(vertices)
    if any(abs(point[axis] - coordinate) > tolerance for point in vertices):
        return None
    other = tuple(index for index in range(3) if index != axis)
    first = tuple(point[other[0]] for point in vertices)
    second = tuple(point[other[1]] for point in vertices)
    return _AxisRectangle(
        axis,
        coordinate,
        (min(first), max(first)),
        (min(second), max(second)),
        1 if normal[axis] > 0.0 else -1,
    )


def _transform_bounds(
    bounds: Bounds3,
    placement: CanonicalRigidPlacement,
    matrix: tuple[Vec3, Vec3, Vec3],
) -> Bounds3 | None:
    corners = tuple(
        _transform_point((x, y, z), placement, matrix)
        for x in bounds[0]
        for y in bounds[1]
        for z in bounds[2]
    )
    output: list[tuple[float, float]] = []
    for axis in range(3):
        values = tuple(point[axis] for point in corners)
        output.append((min(values), max(values)))
    source_lengths = sorted(high - low for low, high in bounds)
    target_lengths = sorted(high - low for low, high in output)
    tolerance = _scale_tolerance((*source_lengths, *target_lengths))
    if any(
        abs(source - target) > tolerance
        for source, target in zip(source_lengths, target_lengths)
    ):
        return None
    return tuple(output)  # type: ignore[return-value]


def _analytic_component(
    component: CanonicalComponentGeometry,
) -> tuple[tuple[_AxisRectangle, ...], tuple[Bounds3, ...]] | None:
    if len(component.fragments) != 1:
        return None
    fragment = component.fragments[0]
    rectangles = _root_rectangles(fragment.root)
    cells = _root_box_cells(fragment.root)
    if rectangles is None or cells is None:
        return None
    matrix = _rotation_matrix(fragment.placement)
    transformed_rectangles = tuple(
        _transform_rectangle(value, fragment.placement, matrix)
        for value in rectangles
    )
    transformed_cells = tuple(
        _transform_bounds(value, fragment.placement, matrix) for value in cells
    )
    if any(value is None for value in transformed_rectangles) or any(
        value is None for value in transformed_cells
    ):
        return None
    return (
        tuple(value for value in transformed_rectangles if value is not None),
        tuple(value for value in transformed_cells if value is not None),
    )


def _positive_interval_overlap(
    first: tuple[float, float],
    second: tuple[float, float],
    tolerance: float,
) -> float:
    return max(0.0, min(first[1], second[1]) - max(first[0], second[0]) - tolerance)


def _analytic_pair_has_overlap(
    first: Sequence[Bounds3],
    second: Sequence[Bounds3],
    interface_geometry_tolerance_mm: float,
) -> bool:
    values = tuple(
        coordinate
        for cell in (*first, *second)
        for interval in cell
        for coordinate in interval
    )
    tolerance = max(
        interface_geometry_tolerance_mm,
        _scale_tolerance(values),
    )
    return any(
        all(
            _positive_interval_overlap(left[axis], right[axis], tolerance) > 0.0
            for axis in range(3)
        )
        for left in first
        for right in second
    )


def _analytic_common_face(
    first: Sequence[_AxisRectangle],
    second: Sequence[_AxisRectangle],
    interface_geometry_tolerance_mm: float,
) -> _PairCapability | None:
    values = tuple(
        coordinate
        for rectangle in (*first, *second)
        for coordinate in (
            rectangle.coordinate,
            *rectangle.first_range,
            *rectangle.second_range,
        )
    )
    tolerance = max(
        interface_geometry_tolerance_mm,
        _scale_tolerance(values),
    )
    patches: list[
        tuple[int, float, tuple[float, float], tuple[float, float]]
    ] = []
    for left in first:
        for right in second:
            if (
                left.axis != right.axis
                or left.outward_sign != -right.outward_sign
                or abs(left.coordinate - right.coordinate) > tolerance
            ):
                continue
            first_range = (
                max(left.first_range[0], right.first_range[0]),
                min(left.first_range[1], right.first_range[1]),
            )
            second_range = (
                max(left.second_range[0], right.second_range[0]),
                min(left.second_range[1], right.second_range[1]),
            )
            if (
                first_range[1] - first_range[0] > tolerance
                and second_range[1] - second_range[0] > tolerance
            ):
                patches.append(
                    (left.axis, left.coordinate, first_range, second_range)
                )
    if not patches:
        return None

    planes = {
        (axis, round(coordinate, 12)) for axis, coordinate, _first, _second in patches
    }
    if len(planes) != 1:
        return _PairCapability(True, True, None)
    axis, rounded_coordinate = next(iter(planes))
    unique_patches = tuple(
        sorted(
            {
                (
                    round(first_range[0], 12),
                    round(first_range[1], 12),
                    round(second_range[0], 12),
                    round(second_range[1], 12),
                )
                for patch_axis, _coordinate, first_range, second_range in patches
                if patch_axis == axis
            }
        )
    )
    weighted_first = 0.0
    weighted_second = 0.0
    area = 0.0
    for first_min, first_max, second_min, second_max in unique_patches:
        patch_area = (first_max - first_min) * (second_max - second_min)
        area += patch_area
        weighted_first += 0.5 * (first_min + first_max) * patch_area
        weighted_second += 0.5 * (second_min + second_max) * patch_area
    if area <= tolerance**2:
        return None
    other = tuple(index for index in range(3) if index != axis)
    centroid = [0.0, 0.0, 0.0]
    centroid[axis] = rounded_coordinate
    centroid[other[0]] = weighted_first / area
    centroid[other[1]] = weighted_second / area
    normal = [0.0, 0.0, 0.0]
    normal[axis] = 1.0
    signature = (
        f"axis={axis};patches="
        + "|".join(
            ",".join(f"{value:.12g}" for value in patch)
            for patch in unique_patches
        )
    )
    return _PairCapability(
        True,
        True,
        PlanarTransportEvidence(
            tuple(normal),  # type: ignore[arg-type]
            tuple(centroid),  # type: ignore[arg-type]
            signature,
        ),
    )


def _load_gmsh() -> object:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - installation error
        raise ComponentAdjacencyError(
            "Gmsh is required for rotated, multi-fragment, or fillet adjacency "
            "geometry queries"
        ) from error
    return gmsh


def _clean_polygon(points: Sequence[Vec3]) -> tuple[Vec3, ...]:
    output: list[Vec3] = []
    for point in points:
        if not output or math.dist(point, output[-1]) > 1.0e-14:
            output.append(point)
    if len(output) > 1 and math.dist(output[0], output[-1]) <= 1.0e-14:
        output.pop()
    if len(output) < 3:
        raise ComponentAdjacencyError(
            "underfill side construction produced a degenerate polygon"
        )
    return tuple(output)


def _occ_plane_surface(gmsh: object, points: Sequence[Vec3]) -> int:
    polygon = _clean_polygon(points)
    point_tags = [gmsh.model.occ.addPoint(*point) for point in polygon]  # type: ignore[attr-defined]
    curve_tags = [
        gmsh.model.occ.addLine(  # type: ignore[attr-defined]
            point_tags[index],
            point_tags[(index + 1) % len(point_tags)],
        )
        for index in range(len(point_tags))
    ]
    loop = gmsh.model.occ.addCurveLoop(curve_tags)  # type: ignore[attr-defined]
    return int(gmsh.model.occ.addPlaneSurface([loop]))  # type: ignore[attr-defined]


def _occ_add_fillet(
    gmsh: object,
    root: CanonicalRectangularUnderfillFillet,
) -> tuple[int, ...]:
    if root.uses_elliptical_sweep:
        from .package_v2_swept_fillet import occ_add
        return occ_add(gmsh, root)
    x0, y0 = root.die_origin_xy_mm
    sx, sy = root.die_size_xy_mm
    x1, y1 = x0 + sx, y0 + sy
    z0 = root.base_z_mm
    z1 = z0 + root.wall_height_mm
    toe = root.toe_width_mm
    top = root.top_width_mm
    volumes: list[int] = []
    side_specs = (
        (
            ((x0, y0, z0), (x0, y0 - toe, z0), (x0, y0 - top, z1), (x0, y0, z1)),
            (sx, 0.0, 0.0),
        ),
        (
            ((x0, y1, z0), (x0, y1 + toe, z0), (x0, y1 + top, z1), (x0, y1, z1)),
            (sx, 0.0, 0.0),
        ),
        (
            ((x0, y0, z0), (x0 - toe, y0, z0), (x0 - top, y0, z1), (x0, y0, z1)),
            (0.0, sy, 0.0),
        ),
        (
            ((x1, y0, z0), (x1 + toe, y0, z0), (x1 + top, y0, z1), (x1, y0, z1)),
            (0.0, sy, 0.0),
        ),
    )
    for polygon, direction in side_specs:
        surface = _occ_plane_surface(gmsh, polygon)
        extruded = gmsh.model.occ.extrude(  # type: ignore[attr-defined]
            [(2, surface)],
            *direction,
        )
        volumes.extend(int(tag) for dimension, tag in extruded if int(dimension) == 3)

    epsilon = max(_OCC_ABSOLUTE_TOLERANCE_MM, toe * 1.0e-7)
    corner_specs = (
        (x0, y0, x0 - toe - epsilon, y0 - toe - epsilon),
        (x1, y0, x1, y0 - toe - epsilon),
        (x1, y1, x1, y1),
        (x0, y1, x0 - toe - epsilon, y1),
    )
    for center_x, center_y, box_x, box_y in corner_specs:
        cone = int(
            gmsh.model.occ.addCone(  # type: ignore[attr-defined]
                center_x,
                center_y,
                z0,
                0.0,
                0.0,
                root.wall_height_mm,
                toe,
                top,
            )
        )
        quadrant = int(
            gmsh.model.occ.addBox(  # type: ignore[attr-defined]
                box_x,
                box_y,
                z0 - epsilon,
                toe + epsilon,
                toe + epsilon,
                root.wall_height_mm + 2.0 * epsilon,
            )
        )
        intersection, _mapping = gmsh.model.occ.intersect(  # type: ignore[attr-defined]
            [(3, cone)],
            [(3, quadrant)],
            removeObject=True,
            removeTool=True,
        )
        volumes.extend(
            int(tag) for dimension, tag in intersection if int(dimension) == 3
        )
    if len(volumes) != 8:
        raise ComponentAdjacencyError(
            "OCC did not construct the eight analytic underfill sectors"
        )
    fused, _mapping = gmsh.model.occ.fuse(  # type: ignore[attr-defined]
        [(3, volumes[0])],
        [(3, tag) for tag in volumes[1:]],
        removeObject=True,
        removeTool=True,
    )
    result = tuple(int(tag) for dimension, tag in fused if int(dimension) == 3)
    if not result:
        raise ComponentAdjacencyError("OCC did not fuse the canonical underfill")
    return result


def _occ_add_root(gmsh: object, root: object) -> tuple[int, ...]:
    from .package_v2_geometry import CanonicalUnion, CanonicalDifference

    if isinstance(root, (CanonicalUnion, CanonicalDifference)):
        from .package_v2_orthogonal_domain_planning import root_boxes

        volumes = [
            (
                3,
                int(
                    gmsh.model.occ.addBox(
                        *(b[0] for b in box), *(b[1] - b[0] for b in box)
                    )
                ),
            )
            for box in root_boxes(root)
        ]
        if len(volumes) > 1:
            fused, _ = gmsh.model.occ.fuse(
                volumes[:1], volumes[1:], removeObject=True, removeTool=True
            )
            return tuple(int(tag) for dim, tag in fused if dim == 3)
        return tuple(tag for dim, tag in volumes)
    if type(root) is CanonicalBox:
        tag = gmsh.model.occ.addBox(  # type: ignore[attr-defined]
            *root.origin_xyz_mm,
            *root.size_xyz_mm,
        )
        return (int(tag),)
    if type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        outer = int(
            gmsh.model.occ.addBox(  # type: ignore[attr-defined]
                x0,
                y0,
                z0,
                root.outer_size_xy_mm[0],
                root.outer_size_xy_mm[1],
                root.height_mm,
            )
        )
        inner = int(
            gmsh.model.occ.addBox(  # type: ignore[attr-defined]
                x0 + root.opening_offset_xy_mm[0],
                y0 + root.opening_offset_xy_mm[1],
                z0,
                root.opening_size_xy_mm[0],
                root.opening_size_xy_mm[1],
                root.height_mm,
            )
        )
        cut, _mapping = gmsh.model.occ.cut(  # type: ignore[attr-defined]
            [(3, outer)],
            [(3, inner)],
            removeObject=True,
            removeTool=True,
        )
        result = tuple(int(tag) for dimension, tag in cut if int(dimension) == 3)
        if not result:
            raise ComponentAdjacencyError("OCC did not construct the canonical frame")
        return result
    if type(root) is CanonicalRectangularUnderfillFillet:
        return _occ_add_fillet(gmsh, root)
    raise ComponentAdjacencyError(
        "component adjacency supports canonical Box, "
        "RectangularFrameExtrusion, and RectangularUnderfillFillet fragments"
    )


def _occ_apply_placement(
    gmsh: object,
    volume_tags: Sequence[int],
    placement: CanonicalRigidPlacement,
) -> None:
    dim_tags = [(3, int(tag)) for tag in volume_tags]
    pivot = placement.pivot_xyz_mm
    rotations = (
        ((1.0, 0.0, 0.0), placement.rotation_deg_xyz[0]),
        ((0.0, 1.0, 0.0), placement.rotation_deg_xyz[1]),
        ((0.0, 0.0, 1.0), placement.rotation_deg_xyz[2]),
    )
    for axis, degrees in rotations:
        if degrees != 0.0:
            gmsh.model.occ.rotate(  # type: ignore[attr-defined]
                dim_tags,
                *pivot,
                *axis,
                math.radians(degrees),
            )
    if placement.translation_xyz_mm != (0.0, 0.0, 0.0):
        gmsh.model.occ.translate(  # type: ignore[attr-defined]
            dim_tags,
            *placement.translation_xyz_mm,
        )


def _occ_add_component(
    gmsh: object,
    component: CanonicalComponentGeometry,
) -> tuple[int, ...]:
    volumes: list[int] = []
    for fragment in component.fragments:
        fragment_volumes = _occ_add_root(gmsh, fragment.root)
        _occ_apply_placement(gmsh, fragment_volumes, fragment.placement)
        volumes.extend(fragment_volumes)
    if len(volumes) == 1:
        return tuple(volumes)
    fused, _mapping = gmsh.model.occ.fuse(  # type: ignore[attr-defined]
        [(3, volumes[0])],
        [(3, tag) for tag in volumes[1:]],
        removeObject=True,
        removeTool=True,
    )
    result = tuple(int(tag) for dimension, tag in fused if int(dimension) == 3)
    if not result:
        raise ComponentAdjacencyError(
            f"OCC did not fuse Component {component.component_id!r} fragments"
        )
    return result


def _occ_common_face_capability(
    first: CanonicalComponentGeometry,
    second: CanonicalComponentGeometry,
    interface_geometry_tolerance_mm: float,
) -> _PairCapability | None:
    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_component_adjacency",
        number_options={
            "General.Terminal": 0.0,
            "Geometry.Tolerance": interface_geometry_tolerance_mm,
        },
    ):
        first_volumes = _occ_add_component(gmsh, first)
        second_volumes = _occ_add_component(gmsh, second)
        fragmented, mapping = gmsh.model.occ.fragment(  # type: ignore[attr-defined]
            [(3, tag) for tag in first_volumes],
            [(3, tag) for tag in second_volumes],
            removeObject=True,
            removeTool=True,
        )
        gmsh.model.occ.synchronize()  # type: ignore[attr-defined]
        if not any(int(dimension) == 3 for dimension, _tag in fragmented):
            raise ComponentAdjacencyError("OCC adjacency query lost both Components")
        first_map = {
            int(tag)
            for values in mapping[: len(first_volumes)]
            for dimension, tag in values
            if int(dimension) == 3
        }
        second_map = {
            int(tag)
            for values in mapping[len(first_volumes) :]
            for dimension, tag in values
            if int(dimension) == 3
        }
        overlapping = first_map & second_map
        if any(
            float(gmsh.model.occ.getMass(3, tag))  # type: ignore[attr-defined]
            > interface_geometry_tolerance_mm**3
            for tag in overlapping
        ):
            raise ComponentAdjacencyError(
                f"generated Components {first.component_id!r} and "
                f"{second.component_id!r} overlap by positive volume"
            )

        def boundary_surfaces(volumes: Iterable[int]) -> set[int]:
            output: set[int] = set()
            for volume in volumes:
                output.update(
                    int(tag)
                    for dimension, tag in gmsh.model.getBoundary(  # type: ignore[attr-defined]
                        [(3, int(volume))],
                        oriented=False,
                        recursive=False,
                    )
                    if int(dimension) == 2
                )
            return output

        shared = boundary_surfaces(first_map) & boundary_surfaces(second_map)
        positive_surfaces = tuple(
            tag
            for tag in shared
            if float(gmsh.model.occ.getMass(2, tag))  # type: ignore[attr-defined]
            > interface_geometry_tolerance_mm**2
        )
        if not positive_surfaces:
            return None
        planar = tuple(
            str(gmsh.model.getType(2, tag)) == "Plane"  # type: ignore[attr-defined]
            for tag in positive_surfaces
        )
        axis_aligned = []
        for tag, is_planar in zip(positive_surfaces, planar):
            if not is_planar:
                axis_aligned.append(False)
                continue
            bounds = tuple(
                float(value)
                for value in gmsh.model.getBoundingBox(2, tag)  # type: ignore[attr-defined]
            )
            extents = tuple(bounds[index + 3] - bounds[index] for index in range(3))
            tolerance = max(
                interface_geometry_tolerance_mm,
                max(extents, default=1.0) * 1.0e-8,
            )
            axis_aligned.append(any(value <= tolerance for value in extents))
        return _PairCapability(all(axis_aligned), all(planar), None)


def _pair_capability(
    first: CanonicalComponentGeometry,
    second: CanonicalComponentGeometry,
    interface_geometry_tolerance_mm: float,
) -> _PairCapability | None:
    analytic_first = _analytic_component(first)
    analytic_second = _analytic_component(second)
    if analytic_first is not None and analytic_second is not None:
        first_faces, first_cells = analytic_first
        second_faces, second_cells = analytic_second
        if _analytic_pair_has_overlap(
            first_cells,
            second_cells,
            interface_geometry_tolerance_mm,
        ):
            raise ComponentAdjacencyError(
                f"generated Components {first.component_id!r} and "
                f"{second.component_id!r} overlap by positive volume"
            )
        return _analytic_common_face(
            first_faces,
            second_faces,
            interface_geometry_tolerance_mm,
        )
    return _occ_common_face_capability(
        first,
        second,
        interface_geometry_tolerance_mm,
    )


def extract_component_adjacencies(
    components: Sequence[CanonicalComponentGeometry],
    *,
    interface_namespace: str = "generated",
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
) -> tuple[CommonFaceCapability, ...]:
    """Return all positive-area common faces between canonical Components.

    Input order and material names do not affect the result.  Point/edge-only
    contact is omitted.  Positive-volume overlap is rejected because it is not
    a valid adjacency and would make shared-surface ownership ambiguous.
    """

    if isinstance(components, (str, bytes)) or not isinstance(components, Sequence):
        raise ComponentAdjacencyError(
            "components must be a sequence of CanonicalComponentGeometry"
        )
    normalized = tuple(components)
    if any(type(value) is not CanonicalComponentGeometry for value in normalized):
        raise ComponentAdjacencyError(
            "components must contain CanonicalComponentGeometry only"
        )
    identifiers = tuple(value.component_id for value in normalized)
    if len(set(identifiers)) != len(identifiers):
        raise ComponentAdjacencyError("component identifiers must be unique")
    if not isinstance(interface_namespace, str) or not interface_namespace.strip():
        raise ComponentAdjacencyError("interface_namespace must be non-empty")
    try:
        tolerance = validate_interface_geometry_tolerance_mm(
            interface_geometry_tolerance_mm
        )
    except ValueError as error:
        raise ComponentAdjacencyError(str(error)) from error
    namespace = interface_namespace.strip().rstrip("/")
    ordered = tuple(sorted(normalized, key=lambda value: value.component_id))
    output: list[CommonFaceCapability] = []
    for first, second in combinations(ordered, 2):
        capability = _pair_capability(first, second, tolerance)
        if capability is None:
            continue
        output.append(
            CommonFaceCapability(
                interface_id=(
                    f"{namespace}/{first.component_id}--{second.component_id}"
                ),
                first_component_id=first.component_id,
                second_component_id=second.component_id,
                axis_aligned_planar=capability.axis_aligned_planar,
                sweep_section_compatible=capability.sweep_section_compatible,
                transport_evidence=capability.transport_evidence,
            )
        )
    return tuple(output)


def extract_generated_component_adjacencies(
    geometry: CanonicalGeneratedGeometry,
    *,
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
) -> tuple[CommonFaceCapability, ...]:
    """Discover one canonical generated instance's Component adjacency graph."""

    if type(geometry) is not CanonicalGeneratedGeometry:
        raise ComponentAdjacencyError(
            "geometry must be a CanonicalGeneratedGeometry"
        )
    return extract_component_adjacencies(
        geometry.components,
        interface_namespace=f"generated/{geometry.instance_id}",
        interface_geometry_tolerance_mm=interface_geometry_tolerance_mm,
    )


def negotiate_generated_component_interfaces(
    geometry: CanonicalGeneratedGeometry,
    policies: Mapping[str, ComponentMeshRequirement],
    *,
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
) -> tuple[NegotiatedComponentInterface, ...]:
    """Discover and negotiate every positive-area generated interface.

    ``policies`` is deliberately keyed by the canonical ``component_id``.  Its
    key set must match the geometry exactly and every value must repeat that
    same ID, preventing positional, stack-order, material, or naming heuristics
    from silently selecting a topology.  Geometry discovery remains separate:
    only discovered positive-area common faces are negotiated.
    """

    if type(geometry) is not CanonicalGeneratedGeometry:
        raise ComponentAdjacencyError(
            "geometry must be a CanonicalGeneratedGeometry"
        )
    if not isinstance(policies, Mapping):
        raise ComponentAdjacencyError(
            "policies must map every canonical component_id to a "
            "ComponentMeshRequirement"
        )
    expected = {component.component_id for component in geometry.components}
    actual = set(policies)
    missing = tuple(sorted(expected - actual))
    extra = tuple(sorted(actual - expected, key=str))
    if missing or extra:
        details: list[str] = []
        if missing:
            details.append("missing=" + ",".join(missing))
        if extra:
            details.append("extra=" + ",".join(repr(value) for value in extra))
        raise ComponentAdjacencyError(
            "policy component_id keys must exactly match canonical geometry ("
            + "; ".join(details)
            + ")"
        )
    normalized: dict[str, ComponentMeshRequirement] = {}
    for component_id in sorted(expected):
        requirement = policies[component_id]
        if type(requirement) is not ComponentMeshRequirement:
            raise ComponentAdjacencyError(
                f"policy {component_id!r} must be a ComponentMeshRequirement"
            )
        if requirement.component_id != component_id:
            raise ComponentAdjacencyError(
                f"policy key {component_id!r} does not match embedded "
                f"component_id {requirement.component_id!r}"
            )
        normalized[component_id] = requirement

    evidence = tuple(
        negotiate_component_interface(
            capability,
            normalized[capability.first_component_id],
            normalized[capability.second_component_id],
        )
        for capability in extract_generated_component_adjacencies(
            geometry,
            interface_geometry_tolerance_mm=(
                interface_geometry_tolerance_mm
            ),
        )
    )
    return tuple(sorted(evidence, key=lambda value: value.interface_id))


__all__ = [
    "ComponentAdjacencyError",
    "extract_component_adjacencies",
    "extract_generated_component_adjacencies",
    "negotiate_generated_component_interfaces",
]
