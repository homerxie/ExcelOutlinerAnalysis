"""Isolated authoring previews using the production compiler and 3D widget."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import json

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

from .package_v2_compile import PackageV2CompileResult, compile_package_v2
from .package_v2_local_templates import new_document, pose, resolve_scope
from .package_v2_preview_3d import PackageV2Preview3D, Vec3


@dataclass(frozen=True)
class DraftPreview:
    compiled: PackageV2CompileResult
    origin: Vec3
    axes: tuple[Vec3, Vec3, Vec3]


def compile_draft_preview(templates, instance, *, scope=None):
    """Compile one draft and its template dependencies without touching Source.

    The supplied scope is project Globals for a top-level instance, the parent's
    Locals for a child, and empty for a template's default-parameter preview.
    Mesh settings are placeholders: previewing only extracts canonical geometry.
    """
    registry = {value["id"]: deepcopy(value) for value in templates}
    needed = set()

    def visit(name):
        if name in needed:
            return  # The compiler reports dependency cycles with full context.
        if name not in registry:
            raise ValueError(f"未知模板 {name!r}")
        needed.add(name)
        for child in registry[name]["instances"]:
            visit(child["template"])

    visit(instance["template"])
    document = new_document("geometry_preview")
    document["templates"] = [value for name, value in registry.items() if name in needed]
    if scope is not None:
        document["globals"] = deepcopy({key: scope[key] for key in ("parameters", "derived")})
    value = deepcopy(instance)
    value.setdefault("material", "solid")
    value["mesh_control"] = {
        "mesh_priority": 1, "target_edge": "0.1mm", "transition_distance": "0.2mm",
        "strategy": {"kind": "conformal_hybrid"},
    }
    document["instances"] = [value]
    compiled = compile_package_v2(json.dumps(document, ensure_ascii=False).encode("utf-8"))
    matrix, origin = pose(value, resolve_scope(document["globals"]))
    axes = tuple(tuple(matrix[row][column] for row in range(3)) for column in range(3))
    return DraftPreview(compiled, origin, axes)


class DraftGeometryPreview(QWidget):
    """Debounce draft edits and retain the last valid scene during typing."""

    def __init__(self, parent, compiler, caption):
        super().__init__(parent)
        self.compiler = compiler
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        label = QLabel(caption)
        label.setWordWrap(True)
        layout.addWidget(label)
        self.preview = PackageV2Preview3D(self, compact=True)
        self.preview.hint_label.setText("左键旋转 · Shift+左键/中键/右键平移 · 滚轮缩放")
        self.preview.clear_scene("填写有效参数后显示几何预览")
        layout.addWidget(self.preview, 1)
        self.status_label = QLabel()
        self.status_label.setWordWrap(True)
        self.status_label.setTextFormat(Qt.TextFormat.PlainText)
        # Long compiler messages must wrap instead of widening the dialog.
        self.status_label.setMinimumWidth(0)
        layout.addWidget(self.status_label)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(200)
        self.timer.timeout.connect(self.refresh)
        parent.finished.connect(self.timer.stop)
        self.schedule()

    def schedule(self, *_args):
        self.timer.start()

    def refresh(self):
        self.timer.stop()
        try:
            draft = self.compiler()
            if draft.compiled.plan_digest != self.preview.scene_digest:
                self.preview.set_compiled_geometry(draft.compiled)
            self.preview.set_coordinate_frame(draft.origin, draft.axes, local=True)
        except (ValueError, KeyError, TypeError, ArithmeticError) as error:
            state = "保留上次有效预览" if self.preview.scene.components else "暂无有效预览"
            self.status_label.setText(f"{state}：{error}")
        else:
            self.status_label.clear()
