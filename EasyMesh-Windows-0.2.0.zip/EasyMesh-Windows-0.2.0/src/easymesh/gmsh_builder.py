from __future__ import annotations

import json
import math
import statistics
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .gmsh_runtime import preview_mesh_file
from .output_artifacts import (
    atomic_output_path,
    atomic_write_text,
    exclusive_output_lock,
    file_artifact,
    normalized_mesh_output,
)
from .parameters import MAX_DEMO_ESTIMATED_ELEMENTS, MeshParameters
from .quality import classify_mesh_quality
from .topology import TopologyPlan, build_topology


@dataclass(frozen=True)
class BuildSummary:
    mesh_path: str
    report_path: str
    node_count: int
    element_count: int
    hex_count: int
    wedge_count: int
    volume_count: int
    two_dimensional_element_count: int
    element_types: tuple[str, ...]
    physical_volume_groups: dict[str, int]
    min_scaled_jacobian: float
    p01_scaled_jacobian: float
    median_scaled_jacobian: float
    min_sicn: float
    min_sige: float
    min_jacobian_determinant: float
    duplicate_node_count: int
    symmetry_ok: bool
    topology_symmetry_ok: bool
    symmetry_axes_deg: tuple[int, ...]
    quality_warnings: tuple[str, ...]
    quality_advisories: tuple[str, ...]
    quality_classification: str
    projected_edge_length: dict[str, float | int]
    projected_edge_length_by_region: dict[str, dict[str, float | int]]
    quadrilateral_projected_area: dict[str, float | int]
    triangle_projected_area_excluded: dict[str, float | int]
    quadrilateral_projected_area_by_region: dict[str, dict[str, float | int]]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["element_types"] = list(self.element_types)
        data["symmetry_axes_deg"] = list(self.symmetry_axes_deg)
        data["quality_warnings"] = list(self.quality_warnings)
        data["quality_advisories"] = list(self.quality_advisories)
        data["wedge_fraction"] = self.wedge_count / self.element_count
        return data


def _load_gmsh():
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "未安装 Gmsh Python 包。请先运行：python3 -m pip install -r requirements.txt"
        ) from exc
    return gmsh


def _percentile(sorted_values: list[float], percentile: float) -> float:
    if not sorted_values:
        raise ValueError("Cannot compute a percentile of an empty sequence")
    if len(sorted_values) == 1:
        return sorted_values[0]
    position = (len(sorted_values) - 1) * percentile
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    fraction = position - lower
    return sorted_values[lower] * (1.0 - fraction) + sorted_values[upper] * fraction


def _region_name(index: int, lower_um: float, upper_um: float) -> str:
    def token(value: float) -> str:
        rendered = f"{value:g}".replace(".", "P")
        return rendered.replace("-", "M")

    return f"REGION_{index + 1:02d}_D{token(lower_um)}_TO_D{token(upper_um)}"


def _region_names(parameters: MeshParameters) -> tuple[str, ...]:
    ascending = sorted(parameters.diameters_um)
    return tuple(
        _region_name(
            index,
            0.0 if index == 0 else ascending[index - 1],
            ascending[index],
        )
        for index in range(len(ascending))
    )


def _mesh_is_reflection_symmetric(
    coordinates: Iterable[float], axes_deg: tuple[int, ...], relative_tolerance: float = 1.0e-7
) -> bool:
    coords = list(coordinates)
    raw_points = [tuple(coords[i : i + 3]) for i in range(0, len(coords), 3)]
    scale = max((abs(value) for value in coords), default=1.0)
    tolerance = max(scale * relative_tolerance, 1.0e-12)
    tolerance_squared = tolerance * tolerance

    def cell(point: tuple[float, float, float]) -> tuple[int, int, int]:
        return tuple(math.floor(value / tolerance) for value in point)  # type: ignore[return-value]

    buckets: dict[tuple[int, int, int], list[tuple[float, float, float]]] = {}
    for point in raw_points:
        buckets.setdefault(cell(point), []).append(point)

    def contains_near(point: tuple[float, float, float]) -> bool:
        key = cell(point)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for candidate in buckets.get((key[0] + dx, key[1] + dy, key[2] + dz), ()):
                        if sum((left - right) ** 2 for left, right in zip(point, candidate)) <= tolerance_squared:
                            return True
        return False

    for angle_deg in axes_deg:
        twice_angle = math.radians(2.0 * angle_deg)
        cosine = math.cos(twice_angle)
        sine = math.sin(twice_angle)
        for x, y, z in raw_points:
            if not contains_near((cosine * x + sine * y, sine * x - cosine * y, z)):
                return False
    return True


def _node_tag(node_2d: int, z_index: int, node_count_2d: int) -> int:
    return z_index * node_count_2d + node_2d + 1


def _add_discrete_mesh(
    gmsh: Any,
    parameters: MeshParameters,
    topology: TopologyPlan,
) -> dict[str, int]:
    region_names = _region_names(parameters)
    volume_entities = [gmsh.model.addDiscreteEntity(3, index + 1) for index in range(len(region_names))]
    node_count_2d = len(topology.coordinates_mm)
    node_tags: list[int] = []
    coordinates: list[float] = []
    for z_index in range(parameters.thickness_layers + 1):
        z = parameters.thickness_mm * z_index / parameters.thickness_layers
        for node_2d, (x, y) in enumerate(topology.coordinates_mm):
            node_tags.append(_node_tag(node_2d, z_index, node_count_2d))
            coordinates.extend((x, y, z))
    # A Gmsh node tag must be classified only once. Elements in the other
    # discrete entities reference this shared global node block.
    gmsh.model.mesh.addNodes(3, volume_entities[0], node_tags, coordinates)

    elements: dict[tuple[int, int], list[tuple[int, ...]]] = {}
    for z_index in range(parameters.thickness_layers):
        for face in topology.faces:
            bottom = tuple(_node_tag(node, z_index, node_count_2d) for node in face.node_ids)
            top = tuple(_node_tag(node, z_index + 1, node_count_2d) for node in face.node_ids)
            element_type = 6 if len(face.node_ids) == 3 else 5
            elements.setdefault((face.region, element_type), []).append(bottom + top)

    next_element_tag = 1
    element_count_by_region = {index: 0 for index in range(len(region_names))}
    for region in range(len(region_names)):
        for element_type in (5, 6):
            connectivity = elements.get((region, element_type), [])
            if not connectivity:
                continue
            tags = list(range(next_element_tag, next_element_tag + len(connectivity)))
            gmsh.model.mesh.addElementsByType(
                volume_entities[region],
                element_type,
                tags,
                [node for element in connectivity for node in element],
            )
            next_element_tag += len(connectivity)
            element_count_by_region[region] += len(connectivity)

    physical_volume_groups: dict[str, int] = {}
    palette = (
        (226, 93, 93),
        (244, 162, 97),
        (233, 196, 106),
        (42, 157, 143),
        (69, 123, 157),
        (106, 76, 147),
    )
    for region, (entity, name) in enumerate(zip(volume_entities, region_names)):
        physical_tag = gmsh.model.addPhysicalGroup(3, [entity])
        gmsh.model.setPhysicalName(3, physical_tag, name)
        physical_volume_groups[name] = element_count_by_region[region]
        gmsh.model.setColor([(3, entity)], *palette[region % len(palette)], 255)
    all_tag = gmsh.model.addPhysicalGroup(3, volume_entities)
    gmsh.model.setPhysicalName(3, all_tag, "ALL_SOLID_VOLUMES")
    return physical_volume_groups


def _summarize_mesh(
    gmsh: Any,
    parameters: MeshParameters,
    topology: TopologyPlan,
    mesh_path: Path,
    report_path: Path,
    physical_volume_groups: dict[str, int],
) -> BuildSummary:
    _, two_dimensional_tags, _ = gmsh.model.mesh.getElements(2)
    two_dimensional_element_count = sum(
        len(tags) for tags in two_dimensional_tags
    )
    if two_dimensional_element_count != 0:
        raise RuntimeError(
            "模型包含不允许的独立二维单元："
            f"{two_dimensional_element_count} 个。"
        )

    element_types, element_tags, _ = gmsh.model.mesh.getElements(3)
    type_names: list[str] = []
    all_element_tags: list[int] = []
    type_counts: dict[str, int] = {}
    allowed = {"Hexahedron 8", "Prism 6"}
    for element_type, tags in zip(element_types, element_tags):
        name, dimension, order, _, _, _ = gmsh.model.mesh.getElementProperties(int(element_type))
        name = str(name)
        if dimension != 3 or order != 1 or name not in allowed:
            raise RuntimeError(f"发现不允许的三维单元：{name}")
        type_names.append(name)
        type_counts[name] = len(tags)
        all_element_tags.extend(int(tag) for tag in tags)
    if not all_element_tags:
        raise RuntimeError("Gmsh 没有生成任何三维单元。")

    scaled_jacobians = sorted(
        float(value) for value in gmsh.model.mesh.getElementQualities(all_element_tags, "minSJ")
    )
    sicn = [float(value) for value in gmsh.model.mesh.getElementQualities(all_element_tags, "minSICN")]
    sige = [float(value) for value in gmsh.model.mesh.getElementQualities(all_element_tags, "minSIGE")]
    determinants = [
        float(value) for value in gmsh.model.mesh.getElementQualities(all_element_tags, "minDetJac")
    ]
    min_scaled_jacobian = min(scaled_jacobians)
    min_sicn = min(sicn)
    min_sige = min(sige)
    quality = classify_mesh_quality(min_scaled_jacobian, min_sicn, min_sige)
    if min(determinants) <= 0.0 or not quality.is_valid:
        raise RuntimeError(
            "网格包含无效单元："
            f"minDetJac={min(determinants):.6g}, "
            f"minSJ={min_scaled_jacobian:.6g}, "
            f"minSICN={min_sicn:.6g}, minSIGE={min_sige:.6g}"
        )

    duplicate_nodes = gmsh.model.mesh.getDuplicateNodes()
    if len(duplicate_nodes) != 0:
        raise RuntimeError(
            f"网格包含 {len(duplicate_nodes)} 个重复节点；请增大相邻圆间距或模型厚度。"
        )
    node_tags, coordinates, _ = gmsh.model.mesh.getNodes()
    axes = topology.symmetry_axes_deg
    coordinate_symmetry = _mesh_is_reflection_symmetric(coordinates, axes)
    if not coordinate_symmetry or not topology.symmetry_ok:
        raise RuntimeError("网格未通过 0°/45°/90°/135° 镜像对称检查。")

    names = _region_names(parameters)
    area_by_region = {
        name: topology.quad_area_by_region[index].to_dict()
        for index, name in enumerate(names)
    }
    edge_by_region = {
        name: topology.edge_length_by_region[index].to_dict()
        for index, name in enumerate(names)
    }
    return BuildSummary(
        mesh_path=str(mesh_path),
        report_path=str(report_path),
        node_count=len(node_tags),
        element_count=len(all_element_tags),
        hex_count=type_counts.get("Hexahedron 8", 0),
        wedge_count=type_counts.get("Prism 6", 0),
        volume_count=len(gmsh.model.getEntities(3)),
        two_dimensional_element_count=two_dimensional_element_count,
        element_types=tuple(type_names),
        physical_volume_groups=physical_volume_groups,
        min_scaled_jacobian=min_scaled_jacobian,
        p01_scaled_jacobian=_percentile(scaled_jacobians, 0.01),
        median_scaled_jacobian=statistics.median(scaled_jacobians),
        min_sicn=min_sicn,
        min_sige=min_sige,
        min_jacobian_determinant=min(determinants),
        duplicate_node_count=len(duplicate_nodes),
        symmetry_ok=coordinate_symmetry,
        topology_symmetry_ok=topology.symmetry_ok,
        symmetry_axes_deg=axes,
        quality_warnings=quality.quality_warnings,
        quality_advisories=quality.quality_advisories,
        quality_classification=quality.classification,
        projected_edge_length=topology.edge_length.to_dict(),
        projected_edge_length_by_region=edge_by_region,
        quadrilateral_projected_area=topology.quad_area.to_dict(),
        triangle_projected_area_excluded=topology.triangle_area.to_dict(),
        quadrilateral_projected_area_by_region=area_by_region,
    )


def build_mesh(
    parameters: MeshParameters,
    mesh_path: str | Path,
    *,
    preview: bool = False,
    verbose: bool = False,
) -> BuildSummary:
    """Generate one legacy mesh while locking its complete artifact bundle."""

    output = normalized_mesh_output(mesh_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with exclusive_output_lock(output):
        summary = _build_mesh_locked(
            parameters,
            output,
            verbose=verbose,
        )
    if preview:
        preview_mesh_file(output, verbose=verbose)
    return summary


def _build_mesh_locked(
    parameters: MeshParameters,
    mesh_path: str | Path,
    *,
    verbose: bool = False,
) -> BuildSummary:
    """Generate, verify and write a mixed HEX8/WEDGE6 mesh."""
    parameters.validate()
    topology = build_topology(parameters)
    estimated_element_count = len(topology.faces) * parameters.thickness_layers
    if estimated_element_count > MAX_DEMO_ESTIMATED_ELEMENTS:
        raise ValueError(
            "实际拓扑预计生成的三维单元数超过当前 demo 的安全上限 "
            f"{MAX_DEMO_ESTIMATED_ELEMENTS:,}；请增大网格尺寸。"
        )
    if not topology.symmetry_ok:
        raise RuntimeError("二维拓扑在进入 Gmsh 前未通过镜像对称检查。")
    gmsh = _load_gmsh()
    output = normalized_mesh_output(mesh_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    report_path = output.with_suffix(".report.json")
    parameter_path = output.with_suffix(".parameters.json")

    initialized = False
    try:
        gmsh.initialize()
        initialized = True
        gmsh.option.setNumber("General.Terminal", 1 if verbose else 0)
        gmsh.option.setNumber("Mesh.MshFileVersion", 4.1)
        gmsh.option.setNumber("Mesh.Binary", 0)
        gmsh.option.setNumber("Mesh.ElementOrder", 1)
        gmsh.option.setNumber("Mesh.SaveAll", 1)
        gmsh.model.add(parameters.model_name)

        physical_groups = _add_discrete_mesh(gmsh, parameters, topology)
        gmsh.model.mesh.renumberNodes()
        gmsh.model.mesh.renumberElements()
        summary = _summarize_mesh(
            gmsh, parameters, topology, output, report_path, physical_groups
        )
        with atomic_output_path(output) as temporary_mesh:
            gmsh.write(str(temporary_mesh))
            mesh_artifact = file_artifact(
                temporary_mesh,
                published_path=output,
            )
        parameter_document = {
            "parameters": parameters.to_dict(),
            "derived": parameters.derived_dict(),
        }
        atomic_write_text(
            parameter_path,
            json.dumps(parameter_document, indent=2, ensure_ascii=False),
        )
        report = {
            **parameter_document,
            "quality": summary.to_dict(),
            "mesh_artifact": mesh_artifact,
        }
        atomic_write_text(
            report_path,
            json.dumps(report, indent=2, ensure_ascii=False),
        )

        return summary
    finally:
        if initialized:
            gmsh.finalize()
