"""Persistent GUI project snapshots for EasyMesh.

The worker-side ``*.parameters.json`` files intentionally describe one mesh
generation job.  A GUI project has a wider scope: it preserves the editable
state of the Layer, layout, and CDB tabs, including temporarily invalid text
that a user may still be working on.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import stat
import unicodedata
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from .output_artifacts import atomic_write_text
from .layer_sweep import LayerSweepPolicy, parse_z_sweep_overrides, parse_radial_sweep_overrides
from .package_v2_compile import PackageV2CompilationError, compile_package_v2
from .package_v2_job import (
    MAX_JOB_REQUEST_BYTES,
    PackageV2JobError,
    PackageV2JobRequest,
    parse_package_v2_job_request,
)
from .package_v2_source import (
    MAX_SOURCE_BYTES,
    PackageV2SourceError,
    ParsedPackageV2Source,
    parse_package_v2_json,
)
from .package_v2_worker import PACKAGE_V2_WORKER_REPORT_SCHEMA


PROJECT_SCHEMA = "easymesh-gui-project-v1"
PROJECT_V2_SCHEMA = "easymesh-gui-project-v2"
PACKAGE_V2_ARTIFACT_STATE_SCHEMA = (
    "easymesh-package-v2-project-artifact-state-v2"
)
PROJECT_SUFFIX = ".easymesh.json"
PROJECT_FILE_FILTER = "EasyMesh project (*.easymesh.json);;JSON files (*.json);;All files (*)"
MAX_PROJECT_BYTES = 128 * 1024 * 1024
MAX_PROJECT_REPORT_BYTES = 16 * 1024 * 1024

_TAB_NAMES = frozenset(("layer", "layout", "cdb"))
_V2_TAB_NAMES = frozenset((*_TAB_NAMES, "package_v2"))
_SYMMETRY_MODES = frozenset(("xy", "xy_45"))
_CDB_ELEMENT_TYPES = frozenset((185, 186))
_CDB_UNITS = frozenset(("MPA", "NONE"))
_SHA256 = frozenset("0123456789abcdef")
_WINDOWS_RESERVED_NAMES = frozenset(
    {"CON", "PRN", "AUX", "NUL"}
    | {f"COM{index}" for index in range(1, 10)}
    | {f"LPT{index}" for index in range(1, 10)}
)
_V2_ROOT_KEYS = frozenset(
    ("schema", "active_tab", "layer", "layout", "cdb", "export", "package_v2")
)
_V2_PACKAGE_KEYS = frozenset(
    ("source", "job", "artifact_state", "replay_sha256")
)
_V2_SOURCE_KEYS = frozenset(("path", "text", "raw_sha256"))
_V2_JOB_KEYS = frozenset(
    (
        "path",
        "text",
        "file_sha256",
        "request_sha256",
        "launch_identity_sha256",
        "raw_source_sha256",
        "plan_sha256",
    )
)
_ARTIFACT_STATE_KEYS = frozenset(
    (
        "schema",
        "request_sha256",
        "launch_identity_sha256",
        "raw_source_sha256",
        "plan_sha256",
        "mesh",
        "parameters",
        "report",
        "cdb",
        "cdb_report",
    )
)
_ARTIFACT_KEYS = frozenset(("path", "size_bytes", "sha256"))


@dataclass(frozen=True, slots=True)
class PackageV2ArtifactStatus:
    """Current/stale result for one previously published worker bundle."""

    recorded: bool
    valid: bool
    reason: str | None
    mesh_path: Path | None = None
    parameters_path: Path | None = None
    report_path: Path | None = None
    cdb_path: Path | None = None
    cdb_report_path: Path | None = None


@dataclass(frozen=True, slots=True)
class PackageV2ProjectSnapshot:
    """Audited, path-resolved Package V2 state restored from one project."""

    project_path: Path
    source_relative_path: str | None
    source_path: Path | None
    source_bytes: bytes
    parsed_source: ParsedPackageV2Source
    source_file_current: bool | None
    job_relative_path: str
    job_path: Path
    job_bytes: bytes
    job_request: PackageV2JobRequest
    job_file_current: bool
    job_matches_source: bool
    job_stale_reason: str | None
    artifact_status: PackageV2ArtifactStatus

    @property
    def runtime_job_path(self) -> Path | None:
        """Return the external Job only when all persisted inputs are current."""

        if (
            self.source_file_current is not False
            and self.job_file_current
            and self.job_matches_source
        ):
            return self.job_path
        return None

    def require_current_job_path(self) -> Path:
        """Return an executable external Job path or fail closed."""

        path = self.runtime_job_path
        if path is None:
            reason = self.job_stale_reason or "project source/job files are stale"
            raise ValueError(f"Package V2 project Job is not current: {reason}")
        return path


def normalized_project_path(path: str | Path) -> Path:
    """Return an absolute path ending in the canonical project suffix."""

    output = Path(path).expanduser().resolve()
    if not output.name.lower().endswith(PROJECT_SUFFIX):
        if output.suffix.lower() == ".json":
            output = output.with_suffix(PROJECT_SUFFIX)
        else:
            output = output.with_name(output.name + PROJECT_SUFFIX)
    return output


def project_path_for_output(path: str | Path) -> Path:
    """Return the unambiguous GUI snapshot sidecar for one exported artifact."""

    output = Path(path).expanduser().resolve()
    return output.with_name(output.name + PROJECT_SUFFIX)


def _mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"project field {label!r} must be an object")
    return value


def _text(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"project field {label!r} must be text")
    return value


def _choice(value: object, choices: frozenset[object], label: str) -> object:
    if value not in choices:
        rendered = ", ".join(repr(item) for item in sorted(choices, key=str))
        raise ValueError(f"project field {label!r} must be one of {rendered}")
    return value


def _finite_number(value: object, label: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"project field {label!r} must be a finite number")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"project field {label!r} must be a finite number"
        ) from exc
    if not math.isfinite(number):
        raise ValueError(f"project field {label!r} must be a finite number")
    return number


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _sha256_text(value: str, label: str) -> str:
    try:
        encoded = value.encode("utf-8")
    except UnicodeEncodeError as error:
        raise ValueError(f"project field {label!r} is not valid Unicode") from error
    return _sha256_bytes(encoded)


def _sha256(value: object, label: str) -> str:
    text = _text(value, label)
    if len(text) != 64 or any(character not in _SHA256 for character in text):
        raise ValueError(f"project field {label!r} must be a lower-case SHA-256")
    return text


def _canonical_json(value: object) -> str:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    except (OverflowError, TypeError, UnicodeEncodeError, ValueError) as error:
        raise ValueError("Package V2 project evidence is not canonical JSON") from error


def _exact_keys(
    value: Mapping[str, object],
    expected: frozenset[str],
    label: str,
) -> None:
    actual = set(value)
    if actual != set(expected):
        missing = sorted(set(expected) - actual)
        extra = sorted(actual - set(expected))
        details: list[str] = []
        if missing:
            details.append(f"missing {missing!r}")
        if extra:
            details.append(f"unexpected {extra!r}")
        raise ValueError(
            f"project field {label!r} has invalid keys ({'; '.join(details)})"
        )


def _portable_relative_path(value: object, label: str) -> str:
    text = _text(value, label)
    try:
        encoded_length = len(text.encode("utf-8"))
    except UnicodeEncodeError as error:
        raise ValueError(
            f"project field {label!r} is not valid Unicode"
        ) from error
    if (
        not text
        or "\x00" in text
        or "\\" in text
        or text.startswith("/")
        or encoded_length > 4096
        or any(character in '<>"|?*' for character in text)
        or any(ord(character) < 32 for character in text)
    ):
        raise ValueError(
            f"project field {label!r} must be a portable relative path"
        )
    path = PurePosixPath(text)
    parts = path.parts
    if (
        path.is_absolute()
        or not parts
        or path.as_posix() != text
        or any(part in ("", ".", "..") for part in parts)
        or any(":" in part for part in parts)
    ):
        raise ValueError(
            f"project field {label!r} must not escape the project directory"
        )
    for part in parts:
        stem = unicodedata.normalize("NFKC", part.split(".", 1)[0]).upper()
        if part.endswith((" ", ".")) or stem in _WINDOWS_RESERVED_NAMES:
            raise ValueError(
                f"project field {label!r} is not portable to Windows"
            )
    return path.as_posix()


def _artifact_descriptor(value: object, label: str) -> dict[str, object]:
    item = _mapping(value, label)
    _exact_keys(item, _ARTIFACT_KEYS, label)
    size = item.get("size_bytes")
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise ValueError(
            f"project field {label + '.size_bytes'!r} must be a non-negative integer"
        )
    return {
        "path": _portable_relative_path(item.get("path"), f"{label}.path"),
        "size_bytes": size,
        "sha256": _sha256(item.get("sha256"), f"{label}.sha256"),
    }


def _validate_artifact_state(value: object) -> dict[str, object] | None:
    if value is None:
        return None
    item = _mapping(value, "package_v2.artifact_state")
    _exact_keys(item, _ARTIFACT_STATE_KEYS, "package_v2.artifact_state")
    if item.get("schema") != PACKAGE_V2_ARTIFACT_STATE_SCHEMA:
        raise ValueError("unsupported Package V2 project artifact-state schema")
    cdb = item.get("cdb")
    cdb_report = item.get("cdb_report")
    if (cdb is None) != (cdb_report is None):
        raise ValueError(
            "Package V2 project CDB artifact and report must be recorded together"
        )
    canonical = {
        "schema": PACKAGE_V2_ARTIFACT_STATE_SCHEMA,
        "request_sha256": _sha256(
            item.get("request_sha256"),
            "package_v2.artifact_state.request_sha256",
        ),
        "launch_identity_sha256": _sha256(
            item.get("launch_identity_sha256"),
            "package_v2.artifact_state.launch_identity_sha256",
        ),
        "raw_source_sha256": _sha256(
            item.get("raw_source_sha256"),
            "package_v2.artifact_state.raw_source_sha256",
        ),
        "plan_sha256": _sha256(
            item.get("plan_sha256"),
            "package_v2.artifact_state.plan_sha256",
        ),
        "mesh": _artifact_descriptor(
            item.get("mesh"), "package_v2.artifact_state.mesh"
        ),
        "parameters": _artifact_descriptor(
            item.get("parameters"), "package_v2.artifact_state.parameters"
        ),
        "report": _artifact_descriptor(
            item.get("report"), "package_v2.artifact_state.report"
        ),
        "cdb": (
            None
            if cdb is None
            else _artifact_descriptor(cdb, "package_v2.artifact_state.cdb")
        ),
        "cdb_report": (
            None
            if cdb_report is None
            else _artifact_descriptor(
                cdb_report,
                "package_v2.artifact_state.cdb_report",
            )
        ),
    }
    mesh_path = str(canonical["mesh"]["path"])  # type: ignore[index]
    parameters_path = str(canonical["parameters"]["path"])  # type: ignore[index]
    report_path = str(canonical["report"]["path"])  # type: ignore[index]
    cdb_record = canonical["cdb"]
    cdb_path = None if cdb_record is None else str(cdb_record["path"])  # type: ignore[index]
    cdb_report_record = canonical["cdb_report"]
    cdb_report_path = (
        None
        if cdb_report_record is None
        else str(cdb_report_record["path"])  # type: ignore[index]
    )
    if PurePosixPath(mesh_path).suffix != ".msh":
        raise ValueError("Package V2 project mesh artifact must end in .msh")
    expected_stem = mesh_path[: -len(".msh")]
    if parameters_path != expected_stem + ".parameters.json":
        raise ValueError("Package V2 project parameters path is inconsistent")
    if report_path != expected_stem + ".report.json":
        raise ValueError("Package V2 project report path is inconsistent")
    if cdb_path is not None and PurePosixPath(cdb_path).suffix != ".cdb":
        raise ValueError("Package V2 project CDB artifact must end in .cdb")
    if (
        cdb_path is not None
        and cdb_report_path != cdb_path + ".report.json"
    ):
        raise ValueError("Package V2 project CDB report path is inconsistent")
    paths = [mesh_path, parameters_path, report_path]
    if cdb_path is not None:
        assert cdb_report_path is not None
        paths.extend((cdb_path, cdb_report_path))
    if len(set(paths)) != len(paths):
        raise ValueError("Package V2 project artifact paths must be distinct")
    return canonical


def _validate_package_v2_section(value: object) -> dict[str, object]:
    section = _mapping(value, "package_v2")
    _exact_keys(section, _V2_PACKAGE_KEYS, "package_v2")

    source = _mapping(section.get("source"), "package_v2.source")
    _exact_keys(source, _V2_SOURCE_KEYS, "package_v2.source")
    raw_source_path = source.get("path")
    source_path = (
        None
        if raw_source_path is None
        else _portable_relative_path(
            raw_source_path, "package_v2.source.path"
        )
    )
    if source_path is not None and PurePosixPath(source_path).suffix != ".json":
        raise ValueError(
            "Package V2 project Source path must end in lower-case .json"
        )
    source_text = _text(source.get("text"), "package_v2.source.text")
    try:
        source_bytes = source_text.encode("utf-8")
    except UnicodeEncodeError as error:
        raise ValueError("Package V2 project source is not valid Unicode") from error
    if len(source_bytes) > MAX_SOURCE_BYTES:
        raise ValueError("Package V2 project source exceeds its byte limit")
    try:
        parsed = parse_package_v2_json(
            source_bytes,
            source_name=source_path or "<embedded-job-source>",
        )
    except PackageV2SourceError as error:
        raise ValueError("Package V2 project source snapshot is invalid") from error
    source_digest = _sha256(
        source.get("raw_sha256"), "package_v2.source.raw_sha256"
    )
    if parsed.raw_sha256 != source_digest:
        raise ValueError("Package V2 project source SHA-256 is stale")
    canonical_source = {
        "path": source_path,
        "text": source_text,
        "raw_sha256": source_digest,
    }

    job = _mapping(section.get("job"), "package_v2.job")
    _exact_keys(job, _V2_JOB_KEYS, "package_v2.job")
    job_path = _portable_relative_path(job.get("path"), "package_v2.job.path")
    if PurePosixPath(job_path).suffix != ".json":
        raise ValueError("Package V2 project Job path must end in lower-case .json")
    job_text = _text(job.get("text"), "package_v2.job.text")
    try:
        job_bytes = job_text.encode("utf-8")
    except UnicodeEncodeError as error:
        raise ValueError("Package V2 project Job is not valid Unicode") from error
    if len(job_bytes) > MAX_JOB_REQUEST_BYTES:
        raise ValueError("Package V2 project Job exceeds its byte limit")
    try:
        request = parse_package_v2_job_request(job_bytes)
    except PackageV2JobError as error:
        raise ValueError("Package V2 project Job snapshot is invalid") from error
    canonical_job = {
        "path": job_path,
        "text": job_text,
        "file_sha256": _sha256(
            job.get("file_sha256"), "package_v2.job.file_sha256"
        ),
        "request_sha256": _sha256(
            job.get("request_sha256"), "package_v2.job.request_sha256"
        ),
        "launch_identity_sha256": _sha256(
            job.get("launch_identity_sha256"),
            "package_v2.job.launch_identity_sha256",
        ),
        "raw_source_sha256": _sha256(
            job.get("raw_source_sha256"), "package_v2.job.raw_source_sha256"
        ),
        "plan_sha256": _sha256(
            job.get("plan_sha256"), "package_v2.job.plan_sha256"
        ),
    }
    expected_job_evidence = {
        "file_sha256": _sha256_bytes(job_bytes),
        "request_sha256": request.sha256,
        "launch_identity_sha256": request.launch_identity.sha256,
        "raw_source_sha256": request.launch_identity.raw_source_sha256,
        "plan_sha256": request.launch_identity.plan_sha256,
    }
    for field_name, expected in expected_job_evidence.items():
        if canonical_job[field_name] != expected:
            raise ValueError(
                f"Package V2 project Job {field_name} evidence is stale"
            )

    artifact_state = _validate_artifact_state(section.get("artifact_state"))
    replay_payload = {
        "schema": PROJECT_V2_SCHEMA,
        "source": canonical_source,
        "job": canonical_job,
        "artifact_state": artifact_state,
    }
    replay_sha256 = _sha256(
        section.get("replay_sha256"), "package_v2.replay_sha256"
    )
    if _sha256_text(_canonical_json(replay_payload), "package_v2") != replay_sha256:
        raise ValueError("Package V2 project replay SHA-256 is stale")
    return {
        "source": canonical_source,
        "job": canonical_job,
        "artifact_state": artifact_state,
        "replay_sha256": replay_sha256,
    }


def validate_layer_mesh_state(value: object) -> dict[str, Any]:
    """Canonical editable Layer geometry and meshing state, independent of other tabs."""
    layer = _mapping(value, "layer")
    symmetry_mode = _choice(
        layer.get("symmetry_mode"), _SYMMETRY_MODES, "layer.symmetry_mode"
    )
    raw_overrides = layer.get("local_size_inputs")
    if not isinstance(raw_overrides, list):
        raise ValueError("project field 'layer.local_size_inputs' must be an array")
    overrides: list[dict[str, object]] = []
    seen_override_keys: set[tuple[str, float, float]] = set()
    for index, value in enumerate(raw_overrides):
        label = f"layer.local_size_inputs[{index}]"
        item = _mapping(value, label)
        axis = _choice(item.get("axis"), frozenset(("radial", "angular", "z")), f"{label}.axis")
        start_um = _finite_number(item.get("start_um"), f"{label}.start_um")
        end_um = _finite_number(item.get("end_um"), f"{label}.end_um")
        if end_um <= start_um:
            raise ValueError(f"project field {label!r} must have end_um > start_um")
        key = (str(axis), start_um, end_um)
        if key in seen_override_keys:
            raise ValueError(f"duplicate project local-size interval: {key!r}")
        seen_override_keys.add(key)
        overrides.append(
            {
                "axis": axis,
                "start_um": start_um,
                "end_um": end_um,
                "text": _text(item.get("text"), f"{label}.text"),
            }
        )

    return {
        "source_path": _text(layer.get("source_path"), "layer.source_path"),
        "source_text": _text(layer.get("source_text"), "layer.source_text"),
        "target_xy_text": _text(
            layer.get("target_xy_text"), "layer.target_xy_text"
        ),
        "target_angular_text": _text(layer.get("target_angular_text", layer.get("target_xy_text")), "layer.target_angular_text"),
        "target_z_text": _text(
            layer.get("target_z_text"), "layer.target_z_text"
        ),
        "symmetry_mode": symmetry_mode,
        "z_sweep": LayerSweepPolicy.from_dict(layer.get("z_sweep", {})).to_dict(),
        "z_sweep_overrides": [item.to_dict() for item in parse_z_sweep_overrides(
            layer.get("z_sweep_overrides", [])
        )],
        "radial_sweep_overrides": [item.to_dict() for item in parse_radial_sweep_overrides(
            layer.get("radial_sweep_overrides", [])
        )],
        "output_path": _text(layer.get("output_path"), "layer.output_path"),
        "local_size_inputs": overrides,
    }


def validate_project_document(document: object) -> dict[str, Any]:
    """Validate and canonicalize one versioned GUI project document.

    Text entry values deliberately remain strings.  This makes Save useful
    while a field is incomplete or invalid; reopening the project restores the
    same editor state and lets the normal GUI validators explain the problem.
    """

    root = _mapping(document, "<root>")
    schema = _text(root.get("schema"), "schema")
    if schema not in (PROJECT_SCHEMA, PROJECT_V2_SCHEMA):
        raise ValueError(f"unsupported EasyMesh project schema: {schema!r}")
    if schema == PROJECT_V2_SCHEMA:
        required = _V2_ROOT_KEYS - {"export"}
        actual = set(root)
        if not required.issubset(actual) or not actual.issubset(_V2_ROOT_KEYS):
            missing = sorted(required - actual)
            extra = sorted(actual - _V2_ROOT_KEYS)
            raise ValueError(
                "Package V2 project root has invalid keys "
                f"(missing={missing!r}, unexpected={extra!r})"
            )

    active_tab = _choice(
        root.get("active_tab"),
        _V2_TAB_NAMES if schema == PROJECT_V2_SCHEMA else _TAB_NAMES,
        "active_tab",
    )

    layer = validate_layer_mesh_state(root.get("layer"))

    layout = _mapping(root.get("layout"), "layout")
    raw_material_inputs = _mapping(
        layout.get("material_inputs"), "layout.material_inputs"
    )
    material_inputs: dict[str, str] = {}
    for source, target in raw_material_inputs.items():
        if not isinstance(source, str) or not source:
            raise ValueError(
                "project field 'layout.material_inputs' must use non-empty text keys"
            )
        material_inputs[source] = _text(
            target, f"layout.material_inputs[{source!r}]"
        )

    cdb = _mapping(root.get("cdb"), "cdb")
    element_type = cdb.get("element_type")
    if isinstance(element_type, bool) or element_type not in _CDB_ELEMENT_TYPES:
        raise ValueError("project field 'cdb.element_type' must be 185 or 186")
    units = _choice(cdb.get("units"), _CDB_UNITS, "cdb.units")

    canonical: dict[str, Any] = {
        "schema": schema,
        "active_tab": active_tab,
        "layer": layer,
        "layout": {
            "source_path": _text(layout.get("source_path"), "layout.source_path"),
            "source_text": _text(layout.get("source_text"), "layout.source_text"),
            "far_field_size_text": _text(
                layout.get("far_field_size_text"), "layout.far_field_size_text"
            ),
            "transition_distance_text": _text(
                layout.get("transition_distance_text"),
                "layout.transition_distance_text",
            ),
            "output_path": _text(layout.get("output_path"), "layout.output_path"),
            "material_inputs": dict(sorted(material_inputs.items())),
        },
        "cdb": {
            "input_path": _text(cdb.get("input_path"), "cdb.input_path"),
            "output_path": _text(cdb.get("output_path"), "cdb.output_path"),
            "element_type": int(element_type),
            "coordinate_scale_text": _text(
                cdb.get("coordinate_scale_text"), "cdb.coordinate_scale_text"
            ),
            "units": units,
        },
    }
    raw_export = root.get("export")
    if raw_export is not None:
        export = _mapping(raw_export, "export")
        job_id = _text(export.get("job_id"), "export.job_id")
        artifact_path = _text(
            export.get("artifact_path"),
            "export.artifact_path",
        )
        if not job_id.strip():
            raise ValueError("project field 'export.job_id' must not be empty")
        if not artifact_path.strip():
            raise ValueError(
                "project field 'export.artifact_path' must not be empty"
            )
        canonical["export"] = {
            "job_id": job_id,
            "artifact_path": artifact_path,
        }
    if schema == PROJECT_V2_SCHEMA:
        canonical["package_v2"] = _validate_package_v2_section(
            root.get("package_v2")
        )
    return canonical


def _read_bounded_regular_file(path: Path, maximum_bytes: int) -> bytes:
    flags = os.O_RDONLY
    for name in ("O_BINARY", "O_CLOEXEC", "O_NONBLOCK", "O_NOFOLLOW"):
        flags |= int(getattr(os, name, 0))
    try:
        descriptor = os.open(path, flags)
    except OSError as error:
        raise ValueError(f"cannot read project dependency: {path}") from error
    try:
        information = os.fstat(descriptor)
        if not stat.S_ISREG(information.st_mode):
            raise ValueError(f"project dependency must be a regular file: {path}")
        if information.st_size > maximum_bytes:
            raise ValueError(f"project dependency exceeds its byte limit: {path}")
        before = (
            information.st_dev,
            information.st_ino,
            information.st_size,
            information.st_mtime_ns,
            information.st_ctime_ns,
        )
        chunks: list[bytes] = []
        remaining = maximum_bytes + 1
        while remaining > 0:
            chunk = os.read(descriptor, min(1024 * 1024, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        value = b"".join(chunks)
        if len(value) > maximum_bytes:
            raise ValueError(f"project dependency exceeds its byte limit: {path}")
        after_information = os.fstat(descriptor)
        after = (
            after_information.st_dev,
            after_information.st_ino,
            after_information.st_size,
            after_information.st_mtime_ns,
            after_information.st_ctime_ns,
        )
        if after != before or len(value) != after_information.st_size:
            raise ValueError(f"project dependency changed while reading: {path}")
        return value
    finally:
        os.close(descriptor)


def _resolve_project_child(project_root: Path, value: object, label: str) -> Path:
    relative = _portable_relative_path(value, label)
    candidate = (project_root / Path(*PurePosixPath(relative).parts)).resolve()
    try:
        candidate.relative_to(project_root)
    except ValueError as error:
        raise ValueError(f"project field {label!r} escapes through a symlink") from error
    return candidate


def _relative_project_child(
    project_root: Path,
    value: str | Path,
    label: str,
) -> tuple[str, Path]:
    raw = Path(value).expanduser()
    candidate = (
        (project_root / raw).resolve() if not raw.is_absolute() else raw.resolve()
    )
    try:
        relative = candidate.relative_to(project_root)
    except ValueError as error:
        raise ValueError(f"{label} must be inside the project directory") from error
    portable = _portable_relative_path(
        PurePosixPath(*relative.parts).as_posix(), label
    )
    return portable, candidate


def _bytes_or_file(
    value: bytes | None,
    path: Path,
    maximum_bytes: int,
    label: str,
) -> bytes:
    if value is None:
        return _read_bounded_regular_file(path, maximum_bytes)
    if not isinstance(value, bytes):
        raise ValueError(f"{label} must be bytes")
    if len(value) > maximum_bytes:
        raise ValueError(f"{label} exceeds its byte limit")
    return value


def _legacy_fields(document: Mapping[str, object]) -> dict[str, object]:
    result: dict[str, object] = {
        "schema": PROJECT_V2_SCHEMA,
        "active_tab": document["active_tab"],
        "layer": document["layer"],
        "layout": document["layout"],
        "cdb": document["cdb"],
    }
    if "export" in document:
        result["export"] = document["export"]
    return result


def build_package_v2_project_document(
    base_document: object,
    *,
    project_path: str | Path,
    job_path: str | Path,
    source_path: str | Path | None = None,
    source_bytes: bytes | None = None,
    job_bytes: bytes | None = None,
    artifact_state: object = None,
    active_tab: str | None = None,
) -> dict[str, Any]:
    """Build one relocatable V2 project from exact Source and Job bytes.

    ``base_document`` may be an existing v1 or v2 GUI project.  This is the
    explicit v1-to-v2 adapter: all legacy editor fields survive unchanged,
    while Package V2 paths are stored only as portable project-relative paths.
    """

    base = validate_project_document(base_document)
    project = normalized_project_path(project_path)
    root = project.parent.resolve()
    if source_path is None:
        source_relative: str | None = None
        source: Path | None = None
    else:
        source_relative, source = _relative_project_child(
            root, source_path, "Package V2 source path"
        )
    job_relative, job = _relative_project_child(
        root, job_path, "Package V2 Job path"
    )
    if (source is not None and source in (project, job)) or job == project:
        raise ValueError("Package V2 project, Source and Job paths must be distinct")

    exact_job = _bytes_or_file(
        job_bytes, job, MAX_JOB_REQUEST_BYTES, "Package V2 Job snapshot"
    )
    try:
        job_text = exact_job.decode("utf-8", errors="strict")
        request = parse_package_v2_job_request(exact_job)
    except (UnicodeDecodeError, PackageV2JobError) as error:
        raise ValueError("Package V2 Job snapshot is invalid") from error
    if source is None and source_bytes is None:
        exact_source = request.source_text.encode("utf-8")
    elif source is None:
        exact_source = _bytes_or_file(
            source_bytes,
            project,
            MAX_SOURCE_BYTES,
            "Package V2 source snapshot",
        )
    else:
        exact_source = _bytes_or_file(
            source_bytes, source, MAX_SOURCE_BYTES, "Package V2 source snapshot"
        )
    try:
        source_text = exact_source.decode("utf-8", errors="strict")
        parsed = parse_package_v2_json(
            exact_source,
            source_name=source_relative or request.source_name,
        )
    except (UnicodeDecodeError, PackageV2SourceError) as error:
        raise ValueError("Package V2 source snapshot is invalid") from error

    source_record = {
        "path": source_relative,
        "text": source_text,
        "raw_sha256": parsed.raw_sha256,
    }
    job_record = {
        "path": job_relative,
        "text": job_text,
        "file_sha256": _sha256_bytes(exact_job),
        "request_sha256": request.sha256,
        "launch_identity_sha256": request.launch_identity.sha256,
        "raw_source_sha256": request.launch_identity.raw_source_sha256,
        "plan_sha256": request.launch_identity.plan_sha256,
    }
    canonical_artifact_state = _validate_artifact_state(artifact_state)
    replay_payload = {
        "schema": PROJECT_V2_SCHEMA,
        "source": source_record,
        "job": job_record,
        "artifact_state": canonical_artifact_state,
    }
    section = {
        "source": source_record,
        "job": job_record,
        "artifact_state": canonical_artifact_state,
        "replay_sha256": _sha256_text(
            _canonical_json(replay_payload), "package_v2"
        ),
    }
    result = _legacy_fields(base)
    if active_tab is not None:
        result["active_tab"] = active_tab
    result["package_v2"] = section
    return validate_project_document(result)


def _regular_file_matches(path: Path, expected: bytes, maximum_bytes: int) -> bool:
    try:
        return _read_bounded_regular_file(path, maximum_bytes) == expected
    except (OSError, ValueError):
        return False


def _artifact_file_record(
    project_root: Path,
    path: Path,
    label: str,
) -> dict[str, object]:
    relative, resolved = _relative_project_child(project_root, path, label)
    flags = os.O_RDONLY
    for name in ("O_BINARY", "O_CLOEXEC", "O_NONBLOCK", "O_NOFOLLOW"):
        flags |= int(getattr(os, name, 0))
    try:
        descriptor = os.open(resolved, flags)
    except OSError as error:
        raise ValueError(f"cannot read {label}: {resolved}") from error
    digest = hashlib.sha256()
    try:
        information = os.fstat(descriptor)
        if not stat.S_ISREG(information.st_mode):
            raise ValueError(f"{label} must be a regular file")
        before = (
            information.st_dev,
            information.st_ino,
            information.st_size,
            information.st_mtime_ns,
            information.st_ctime_ns,
        )
        size = 0
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            digest.update(chunk)
        after_information = os.fstat(descriptor)
        after = (
            after_information.st_dev,
            after_information.st_ino,
            after_information.st_size,
            after_information.st_mtime_ns,
            after_information.st_ctime_ns,
        )
        if before != after or size != after_information.st_size:
            raise ValueError(f"{label} changed while hashing")
    except OSError as error:
        raise ValueError(f"cannot hash {label}: {resolved}") from error
    finally:
        os.close(descriptor)
    return {
        "path": relative,
        "size_bytes": size,
        "sha256": digest.hexdigest(),
    }


def _unique_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def _json_object(data: bytes, label: str) -> Mapping[str, object]:
    try:
        value = json.loads(
            data.decode("utf-8", errors="strict"),
            object_pairs_hook=_unique_json_object,
            parse_constant=lambda token: (_ for _ in ()).throw(
                ValueError(f"non-finite token {token!r}")
            ),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise ValueError(f"{label} is not strict UTF-8 JSON") from error
    return _mapping(value, label)


def _audit_worker_report(
    report: Mapping[str, object],
    request: PackageV2JobRequest,
) -> Mapping[str, object]:
    if report.get("schema") != PACKAGE_V2_WORKER_REPORT_SCHEMA:
        raise ValueError("Package V2 worker report schema is unsupported")
    if report.get("status") != "complete":
        raise ValueError("Package V2 worker report is not complete")
    if report.get("request_sha256") != request.sha256:
        raise ValueError("Package V2 worker report belongs to another Job")
    launch = _mapping(report.get("launch_identity"), "worker report launch_identity")
    if launch.get("sha256") != request.launch_identity.sha256:
        raise ValueError("Package V2 worker report launch identity is stale")
    evidence = _mapping(report.get("current_evidence"), "worker report current_evidence")
    if (
        evidence.get("raw_source_sha256")
        != request.launch_identity.raw_source_sha256
        or evidence.get("compiled_plan_sha256")
        != request.launch_identity.plan_sha256
    ):
        raise ValueError("Package V2 worker report source/plan evidence is stale")
    binding = _sha256(report.get("binding_sha256"), "worker report binding_sha256")
    without_binding = dict(report)
    without_binding.pop("binding_sha256", None)
    if _sha256_text(_canonical_json(without_binding), "worker report") != binding:
        raise ValueError("Package V2 worker report binding is stale")
    artifacts = _mapping(report.get("artifacts"), "worker report artifacts")
    if set(artifacts) != {"mesh", "parameters"}:
        raise ValueError("Package V2 worker report artifact evidence is incomplete")
    return artifacts


def _audit_cdb_report_artifact(
    value: object,
    *,
    expected_path: Path,
    expected_record: Mapping[str, object],
    label: str,
) -> None:
    artifact = _mapping(value, label)
    _exact_keys(artifact, _ARTIFACT_KEYS, label)
    raw_path = artifact.get("path")
    if not isinstance(raw_path, str):
        raise ValueError(f"{label}.path is invalid")
    path = Path(raw_path).expanduser()
    if not path.is_absolute() or path.resolve() != expected_path:
        raise ValueError(f"{label}.path differs from the published artifact")
    size = artifact.get("size_bytes")
    if type(size) is not int or size < 0:
        raise ValueError(f"{label}.size_bytes is invalid")
    digest = _sha256(artifact.get("sha256"), f"{label}.sha256")
    if (
        size != expected_record["size_bytes"]
        or digest != expected_record["sha256"]
    ):
        raise ValueError(f"{label} is stale")


def _audit_cdb_report(
    report: Mapping[str, object],
    *,
    source_mesh: Path,
    source_record: Mapping[str, object],
    cdb: Path,
    cdb_record: Mapping[str, object],
    report_path: Path,
) -> None:
    expected_paths = {
        "source_mesh_path": source_mesh,
        "cdb_path": cdb,
        "report_path": report_path,
    }
    for field_name, expected in expected_paths.items():
        raw_path = report.get(field_name)
        if not isinstance(raw_path, str):
            raise ValueError(f"CDB report {field_name} is invalid")
        path = Path(raw_path).expanduser()
        if not path.is_absolute() or path.resolve() != expected:
            raise ValueError(f"CDB report {field_name} is stale")
    _audit_cdb_report_artifact(
        report.get("source_mesh_artifact"),
        expected_path=source_mesh,
        expected_record=source_record,
        label="CDB report source_mesh_artifact",
    )
    _audit_cdb_report_artifact(
        report.get("cdb_artifact"),
        expected_path=cdb,
        expected_record=cdb_record,
        label="CDB report cdb_artifact",
    )
    element_type = report.get("element_type")
    if type(element_type) is not int or element_type not in _CDB_ELEMENT_TYPES:
        raise ValueError("CDB report element_type is invalid")
    coordinate_scale = report.get("coordinate_scale")
    if (
        type(coordinate_scale) not in (int, float)
        or not math.isfinite(float(coordinate_scale))
        or float(coordinate_scale) <= 0.0
    ):
        raise ValueError("CDB report coordinate_scale is invalid")
    units = report.get("units_label")
    if units is not None and (
        not isinstance(units, str)
        or not units.strip()
        or units != units.strip()
    ):
        raise ValueError("CDB report units_label is invalid")


def _build_artifact_state(
    project: Path,
    request: PackageV2JobRequest,
    report_path: Path,
    cdb_path: Path | None,
) -> dict[str, object]:
    root = project.parent.resolve()
    expected_output = Path(request.output_mesh_path).resolve()
    expected_paths = {
        "mesh": expected_output,
        "parameters": expected_output.with_suffix(".parameters.json"),
    }
    if report_path.resolve() != expected_output.with_suffix(".report.json"):
        raise ValueError("Package V2 worker report path differs from the Job output")
    report_bytes = _read_bounded_regular_file(
        report_path, MAX_PROJECT_REPORT_BYTES
    )
    report = _json_object(report_bytes, "Package V2 worker report")
    reported_artifacts = _audit_worker_report(report, request)

    records: dict[str, dict[str, object]] = {}
    for role in ("mesh", "parameters"):
        reported = _mapping(
            reported_artifacts.get(role), f"worker report artifacts.{role}"
        )
        if set(reported) != {"path", "size_bytes", "sha256"}:
            raise ValueError(f"worker report {role} artifact evidence is invalid")
        reported_path = reported.get("path")
        if not isinstance(reported_path, str):
            raise ValueError(f"worker report {role} path is invalid")
        raw_reported_path = Path(reported_path).expanduser()
        if (
            not raw_reported_path.is_absolute()
            or raw_reported_path.resolve() != expected_paths[role]
        ):
            raise ValueError(f"worker report {role} path differs from the Job")
        record = _artifact_file_record(
            root, raw_reported_path, f"Package V2 {role} artifact"
        )
        if (
            reported.get("size_bytes") != record["size_bytes"]
            or reported.get("sha256") != record["sha256"]
        ):
            raise ValueError(f"Package V2 {role} artifact is stale")
        records[role] = record

    cdb_record: dict[str, object] | None = None
    cdb_report_record: dict[str, object] | None = None
    if cdb_path is not None:
        cdb_record = _artifact_file_record(
            root,
            cdb_path,
            "Package V2 CDB artifact",
        )
        cdb_report_path = cdb_path.with_name(
            f"{cdb_path.name}.report.json"
        )
        try:
            cdb_report_bytes = _read_bounded_regular_file(
                cdb_report_path,
                MAX_PROJECT_REPORT_BYTES,
            )
        except ValueError as error:
            raise ValueError(
                "Package V2 CDB report is missing or invalid"
            ) from error
        cdb_report = _json_object(cdb_report_bytes, "Package V2 CDB report")
        _audit_cdb_report(
            cdb_report,
            source_mesh=expected_output,
            source_record=records["mesh"],
            cdb=cdb_path,
            cdb_record=cdb_record,
            report_path=cdb_report_path,
        )
        cdb_report_record = _artifact_file_record(
            root,
            cdb_report_path,
            "Package V2 CDB report",
        )

    state: dict[str, object] = {
        "schema": PACKAGE_V2_ARTIFACT_STATE_SCHEMA,
        "request_sha256": request.sha256,
        "launch_identity_sha256": request.launch_identity.sha256,
        "raw_source_sha256": request.launch_identity.raw_source_sha256,
        "plan_sha256": request.launch_identity.plan_sha256,
        "mesh": records["mesh"],
        "parameters": records["parameters"],
        "report": _artifact_file_record(
            root, report_path, "Package V2 worker report"
        ),
        "cdb": cdb_record,
        "cdb_report": cdb_report_record,
    }
    validated = _validate_artifact_state(state)
    assert validated is not None
    return validated


def build_package_v2_artifact_state(
    project_path: str | Path,
    job_bytes: bytes,
    report_path: str | Path,
    *,
    cdb_path: str | Path | None = None,
) -> dict[str, object]:
    """Bind one fresh worker report and its exact artifacts to a Project V2."""

    project = normalized_project_path(project_path)
    if not isinstance(job_bytes, bytes):
        raise ValueError("Package V2 Job snapshot must be bytes")
    try:
        request = parse_package_v2_job_request(job_bytes)
    except PackageV2JobError as error:
        raise ValueError("Package V2 Job snapshot is invalid") from error
    report = Path(report_path).expanduser().resolve()
    cdb = None if cdb_path is None else Path(cdb_path).expanduser().resolve()
    return _build_artifact_state(project, request, report, cdb)


def save_project_document(path: str | Path, document: object) -> Path:
    """Validate and atomically write one GUI project file."""

    output = normalized_project_path(path)
    canonical = validate_project_document(document)
    serialized = json.dumps(canonical, indent=2, ensure_ascii=False) + "\n"
    try:
        encoded_size = len(serialized.encode("utf-8"))
    except UnicodeEncodeError as error:
        raise ValueError("EasyMesh project is not valid Unicode") from error
    if encoded_size > MAX_PROJECT_BYTES:
        raise ValueError("EasyMesh project exceeds its byte limit")
    atomic_write_text(
        output,
        serialized,
    )
    return output


def load_project_document(path: str | Path) -> dict[str, Any]:
    """Read, validate, and canonicalize one GUI project file."""

    source = Path(path).expanduser().resolve()
    data = _read_bounded_regular_file(source, MAX_PROJECT_BYTES)
    try:
        payload = json.loads(
            data.decode("utf-8-sig", errors="strict"),
            object_pairs_hook=_unique_json_object,
            parse_constant=lambda token: (_ for _ in ()).throw(
                ValueError(f"non-finite token {token!r}")
            ),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise ValueError("EasyMesh project is not strict UTF-8 JSON") from error
    return validate_project_document(payload)


def _project_artifact_status(
    project: Path,
    request: PackageV2JobRequest,
    value: object,
    *,
    job_is_current: bool,
) -> PackageV2ArtifactStatus:
    state = _validate_artifact_state(value)
    if state is None:
        return PackageV2ArtifactStatus(False, False, "no artifact state recorded")
    root = project.parent.resolve()
    mesh = _resolve_project_child(
        root,
        state["mesh"]["path"],  # type: ignore[index]
        "artifact mesh path",
    )
    parameters = _resolve_project_child(
        root,
        state["parameters"]["path"],  # type: ignore[index]
        "artifact parameters path",
    )
    report = _resolve_project_child(
        root,
        state["report"]["path"],  # type: ignore[index]
        "artifact report path",
    )
    cdb_record = state["cdb"]
    cdb = (
        None
        if cdb_record is None
        else _resolve_project_child(
            root, cdb_record["path"], "artifact CDB path"  # type: ignore[index]
        )
    )
    cdb_report_record = state["cdb_report"]
    cdb_report = (
        None
        if cdb_report_record is None
        else _resolve_project_child(
            root,
            cdb_report_record["path"],  # type: ignore[index]
            "artifact CDB report path",
        )
    )
    paths = {
        "mesh_path": mesh,
        "parameters_path": parameters,
        "report_path": report,
        "cdb_path": cdb,
        "cdb_report_path": cdb_report,
    }
    if not job_is_current:
        return PackageV2ArtifactStatus(
            True,
            False,
            "Package V2 Source or Job is stale",
            **paths,
        )
    expected_identity = {
        "request_sha256": request.sha256,
        "launch_identity_sha256": request.launch_identity.sha256,
        "raw_source_sha256": request.launch_identity.raw_source_sha256,
        "plan_sha256": request.launch_identity.plan_sha256,
    }
    for field_name, expected in expected_identity.items():
        if state[field_name] != expected:
            return PackageV2ArtifactStatus(
                True,
                False,
                f"artifact state {field_name} is stale",
                **paths,
            )
    try:
        rebuilt = _build_artifact_state(project, request, report, cdb)
    except (OSError, ValueError) as error:
        return PackageV2ArtifactStatus(
            True,
            False,
            str(error),
            **paths,
        )
    if rebuilt != state:
        return PackageV2ArtifactStatus(
            True,
            False,
            "Package V2 artifact bytes differ from project evidence",
            **paths,
        )
    return PackageV2ArtifactStatus(True, True, None, **paths)


def load_package_v2_project_snapshot(
    path: str | Path,
) -> PackageV2ProjectSnapshot:
    """Restore one V2 project and replay its Source/Job identity evidence.

    Embedded bytes remain available even when an external relative path is
    missing or modified.  ``runtime_job_path`` is exposed only when the two
    external files and the semantic Source-to-Job replay are all current.
    """

    project = Path(path).expanduser().resolve()
    document = load_project_document(project)
    if document["schema"] != PROJECT_V2_SCHEMA:
        raise ValueError("EasyMesh project is not a Package V2 project")
    section = document["package_v2"]
    source_record = section["source"]
    job_record = section["job"]
    root = project.parent.resolve()
    source = (
        None
        if source_record["path"] is None
        else _resolve_project_child(
            root, source_record["path"], "package_v2.source.path"
        )
    )
    job = _resolve_project_child(root, job_record["path"], "package_v2.job.path")
    if (source is not None and source in (project, job)) or job == project:
        raise ValueError("Package V2 project, Source and Job paths must be distinct")
    source_bytes = source_record["text"].encode("utf-8")
    job_bytes = job_record["text"].encode("utf-8")
    try:
        request = parse_package_v2_job_request(job_bytes)
        parsed = parse_package_v2_json(
            source_bytes,
            source_name=(
                str(source_record["path"])
                if source_record["path"] is not None
                else request.source_name
            ),
        )
    except (PackageV2JobError, PackageV2SourceError) as error:
        raise ValueError("Package V2 project replay input is invalid") from error

    stale_reason: str | None = None
    if request.source_text.encode("utf-8") != source_bytes:
        stale_reason = "embedded Source bytes differ from the immutable Job"
    elif request.launch_identity.raw_source_sha256 != parsed.raw_sha256:
        stale_reason = "embedded Source raw identity differs from the Job"
    else:
        try:
            compiled = compile_package_v2(
                source_bytes,
                source_name=request.source_name,
                source_root=(
                    source.parent if source is not None else request.source_root
                ),
            )
        except PackageV2CompilationError as error:
            stale_reason = f"embedded Source cannot be replayed: {error}"
        else:
            if compiled.plan_digest != request.launch_identity.plan_sha256:
                stale_reason = "embedded Source plan identity differs from the Job"
            elif (
                source is not None
                and
                request.source_root is not None
                and Path(request.source_root).resolve() != source.parent
            ):
                stale_reason = "immutable Job source_root differs from the relative Source"

    source_current = (
        None
        if source is None
        else _regular_file_matches(source, source_bytes, MAX_SOURCE_BYTES)
    )
    job_current = _regular_file_matches(job, job_bytes, MAX_JOB_REQUEST_BYTES)
    if stale_reason is None and source_current is False:
        stale_reason = "external relative Source is missing or modified"
    if stale_reason is None and not job_current:
        stale_reason = "external relative Job is missing or modified"
    job_matches_source = stale_reason is None
    artifact_status = _project_artifact_status(
        project,
        request,
        section["artifact_state"],
        job_is_current=job_matches_source,
    )
    return PackageV2ProjectSnapshot(
        project,
        (
            None
            if source_record["path"] is None
            else str(source_record["path"])
        ),
        source,
        source_bytes,
        parsed,
        source_current,
        str(job_record["path"]),
        job,
        job_bytes,
        request,
        job_current,
        job_matches_source,
        stale_reason,
        artifact_status,
    )


def save_package_v2_project_snapshot(
    path: str | Path,
    base_document: object,
    *,
    job_path: str | Path,
    source_path: str | Path | None = None,
    source_bytes: bytes | None = None,
    job_bytes: bytes | None = None,
    artifact_state: object = None,
    active_tab: str | None = None,
) -> PackageV2ProjectSnapshot:
    """Atomically save and immediately replay-audit one Package V2 project."""

    project = normalized_project_path(path)
    document = build_package_v2_project_document(
        base_document,
        project_path=project,
        source_path=source_path,
        job_path=job_path,
        source_bytes=source_bytes,
        job_bytes=job_bytes,
        artifact_state=artifact_state,
        active_tab=active_tab,
    )
    save_project_document(project, document)
    return load_package_v2_project_snapshot(project)


__all__ = [
    "MAX_PROJECT_BYTES",
    "MAX_PROJECT_REPORT_BYTES",
    "PACKAGE_V2_ARTIFACT_STATE_SCHEMA",
    "PROJECT_FILE_FILTER",
    "PROJECT_SCHEMA",
    "PROJECT_SUFFIX",
    "PROJECT_V2_SCHEMA",
    "PackageV2ArtifactStatus",
    "PackageV2ProjectSnapshot",
    "build_package_v2_artifact_state",
    "build_package_v2_project_document",
    "load_project_document",
    "load_package_v2_project_snapshot",
    "normalized_project_path",
    "project_path_for_output",
    "save_package_v2_project_snapshot",
    "save_project_document",
    "validate_project_document",
]
