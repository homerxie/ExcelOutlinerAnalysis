"""Topology-neutral DTO for an already materialized interface surface.

The producer owns the coordinates, facet connectivity, and semantic node
identity.  A downstream volume backend may validate this patch against its
own canonical side, but may not split, trim, remesh, or retoken it.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from types import MappingProxyType
from typing import TypeAlias


Point3D: TypeAlias = tuple[float, float, float]
Facet: TypeAlias = tuple[int, ...]


class LockedSurfacePatchError(ValueError):
    """An authority-owned surface patch is internally inconsistent."""


def _text(value: object, *, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or any(ord(character) < 32 for character in value)
    ):
        raise LockedSurfacePatchError(
            f"{field_name} must be a canonical non-empty string"
        )
    return value


def _point(value: Sequence[float], *, field_name: str) -> Point3D:
    try:
        raw = tuple(value)
    except TypeError as error:
        raise LockedSurfacePatchError(
            f"{field_name} must contain finite x,y,z"
        ) from error
    if len(raw) != 3:
        raise LockedSurfacePatchError(
            f"{field_name} must contain finite x,y,z"
        )
    result: list[float] = []
    for item in raw:
        if isinstance(item, bool):
            raise LockedSurfacePatchError(
                f"{field_name} must contain finite x,y,z"
            )
        try:
            number = float(item)
        except (TypeError, ValueError, OverflowError) as error:
            raise LockedSurfacePatchError(
                f"{field_name} must contain finite x,y,z"
            ) from error
        if not math.isfinite(number):
            raise LockedSurfacePatchError(
                f"{field_name} must contain finite x,y,z"
            )
        result.append(0.0 if number == 0.0 else number)
    return tuple(result)  # type: ignore[return-value]


@dataclass(frozen=True, slots=True)
class LockedGeneratedSurfacePatch:
    """One immutable generated seam in package coordinates.

    Numeric node IDs are patch-local.  Semantic tokens, not coincident
    coordinates or component names, authorize node sharing.
    """

    side_name: str
    node_coordinates: Mapping[int, Point3D]
    facets: tuple[Facet, ...]
    semantic_tokens_by_node_id: Mapping[int, str]

    def __post_init__(self) -> None:
        side = _text(self.side_name, field_name="surface patch side_name")
        if not isinstance(self.node_coordinates, Mapping) or not isinstance(
            self.semantic_tokens_by_node_id, Mapping
        ):
            raise LockedSurfacePatchError(
                "surface patch coordinates and tokens must be mappings"
            )
        coordinates: dict[int, Point3D] = {}
        for raw_node, raw_point in self.node_coordinates.items():
            if (
                isinstance(raw_node, bool)
                or not isinstance(raw_node, int)
                or raw_node < 1
            ):
                raise LockedSurfacePatchError(
                    "surface patch node IDs must be positive integers"
                )
            coordinates[raw_node] = _point(
                raw_point,
                field_name=f"surface patch node {raw_node}",
            )
        try:
            facets = tuple(tuple(facet) for facet in self.facets)
        except TypeError as error:
            raise LockedSurfacePatchError(
                "surface patch facets must be TRI3/QUAD4"
            ) from error
        if (
            not facets
            or any(
                len(facet) not in {3, 4}
                or len(set(facet)) != len(facet)
                or any(node not in coordinates for node in facet)
                for facet in facets
            )
        ):
            raise LockedSurfacePatchError(
                "surface patch facets must be non-empty valid TRI3/QUAD4"
            )
        face_keys = tuple(tuple(sorted(facet)) for facet in facets)
        if len(set(face_keys)) != len(face_keys):
            raise LockedSurfacePatchError("surface patch facets are duplicated")
        referenced = {node for facet in facets for node in facet}
        if referenced != set(coordinates):
            raise LockedSurfacePatchError(
                "surface patch coordinates must exactly cover its facets"
            )
        tokens = {
            node: _text(token, field_name="surface patch semantic token")
            for node, token in self.semantic_tokens_by_node_id.items()
        }
        if set(tokens) != referenced or len(set(tokens.values())) != len(tokens):
            raise LockedSurfacePatchError(
                "surface patch must assign one unique semantic token to every node"
            )
        object.__setattr__(self, "side_name", side)
        object.__setattr__(
            self,
            "node_coordinates",
            MappingProxyType(coordinates),
        )
        object.__setattr__(self, "facets", facets)
        object.__setattr__(
            self,
            "semantic_tokens_by_node_id",
            MappingProxyType(tokens),
        )


__all__ = [
    "LockedGeneratedSurfacePatch",
    "LockedSurfacePatchError",
]
