"""Direct Gmsh conformal meshing for a rectangular underfill fillet.

The default geometry is the analytic
:class:`~easymesh.uf_skin.RectangularUfEnvelope` slice between two Z planes.
A complete locked base or cap annulus can instead become the planar geometry
authority and is joined by ruled surfaces to the opposite analytic boundary.
OpenCASCADE builds that solid and Gmsh owns every three-dimensional element.
EasyMesh only installs explicitly locked boundary TRI3/QUAD4 meshes on named
geometric sides before asking Gmsh to generate the volume.  In particular,
this module never creates a Cartesian volume scaffold, never deletes cut cells
and never manufactures TET/PYRAMID/WEDGE connectivity.

The public boundary contract is deliberately independent of a lower/upper UF
split.  A caller supplies facets by geometric side identity; adjacency and
topology negotiation remain the caller's responsibility.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
import time
import uuid
from contextlib import nullcontext
from statistics import median
from types import MappingProxyType
from typing import Any, TypeAlias

from .gmsh_runtime import isolated_gmsh_model
from .gmsh_candidate_runtime import (
    DIRECT_VOLUME_THREADS_BY_ALGORITHM,
    CandidateSearchExhausted,
    bounded_candidate_search,
    candidate_stage,
    candidate_event_context,
    check_candidate_budget,
    emit_candidate_event,
    run_isolated_candidate,
    race_isolated_candidates,
    parallel_tet_candidates_enabled,
    reserve_fallback_budget,
)
from .occ_locked_hybrid import (
    ConstrainedHybridError,
    _all_nodes,
    _coordinate_key,
    _face_key,
    _finite,
    _load_gmsh,
    _surface_shell_is_watertight,
)
from .package_v2_quality_history import emit_quality_snapshot
from .uf_skin import RectangularUfEnvelope
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]
FaceKey: TypeAlias = tuple[int, ...]

_TRI3 = 2
_QUAD4 = 3
_TET4 = 4
_WEDGE6 = 6
_PYRAMID5 = 7
_SUPPORTED_VOLUME_TYPES = frozenset({_TET4, _WEDGE6, _PYRAMID5})
_COORDINATE_TOLERANCE_MM = 1.0e-10
_OCC_TOLERANCE_MM = 1.0e-7

_LOCKED_SIDE_ORDER = (
    "base",
    "cap",
    "die_x_min",
    "die_x_max",
    "die_y_min",
    "die_y_max",
)
_LOCKED_SIDE_SET = frozenset(_LOCKED_SIDE_ORDER)


@dataclass(frozen=True, slots=True)
class GmshUfVolumeElement:
    """One Gmsh-owned first-order UF volume element."""

    gmsh_type: int
    node_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        expected = ELEMENT_SPECS.get(self.gmsh_type, (None, 0, ()))[1]
        if (
            self.gmsh_type not in _SUPPORTED_VOLUME_TYPES
            or len(self.node_ids) != expected
        ):
            raise ConstrainedHybridError(
                "direct UF conformal element must be TET4, WEDGE6 or PYRAMID5"
            )
        if len(set(self.node_ids)) != expected:
            raise ConstrainedHybridError(
                "direct UF conformal element contains repeated nodes"
            )


@dataclass(frozen=True, slots=True)
class GmshUfConformalVolume:
    """Audited result of one direct OCC/Gmsh underfill-fillet mesh."""

    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    elements: tuple[GmshUfVolumeElement, ...]
    locked_facets_by_side: Mapping[str, tuple[tuple[int, ...], ...]]
    base_facets: tuple[tuple[int, ...], ...]
    cap_facets: tuple[tuple[int, ...], ...]
    die_wall_facets: tuple[tuple[int, ...], ...]
    free_surface_facets: tuple[tuple[int, ...], ...]
    tet4_count: int
    wedge6_count: int
    pyramid5_count: int
    locked_triangle_count: int
    locked_quad_count: int
    target_size_mm: float
    near_size_mm: float
    transition_distance_mm: float
    background_field_kind: str
    geometry_authority: str
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    minimum_determinant: float
    duplicate_node_count: int
    duplicate_element_count: int
    cad_volume_mm3: float
    analytic_volume_mm3: float
    element_volume_mm3: float
    cad_relative_volume_error: float
    element_relative_volume_error: float
    random_seed: int
    algorithm_3d: int = 1

    @property
    def node_count(self) -> int:
        return len(self.node_coordinates)

    @property
    def element_count(self) -> int:
        return len(self.elements)

    @property
    def locked_face_count(self) -> int:
        return self.locked_triangle_count + self.locked_quad_count


@dataclass(frozen=True, slots=True)
class PlanarAnnulusRuledCorrespondence:
    """Explicit side strips joining two locked planar annuli.

    Facets use the caller's locked node IDs.  ``outer_facets`` join the two
    outer perimeter loops and ``inner_facets`` join the two die-inner loops.
    Validation against the actual base/cap patches is deliberately deferred
    until a generator call, where exact endpoint edge ownership can be proved.
    """

    outer_facets: tuple[tuple[int, ...], ...]
    inner_facets: tuple[tuple[int, ...], ...]

    def __post_init__(self) -> None:
        for field_name in ("outer_facets", "inner_facets"):
            try:
                raw_facets = tuple(
                    tuple(facet) for facet in getattr(self, field_name)
                )
            except (TypeError, ValueError, OverflowError) as error:
                raise ConstrainedHybridError(
                    "planar-annulus ruled correspondence facets are invalid"
                ) from error
            if not raw_facets or any(
                len(facet) not in {3, 4}
                or len(set(facet)) != len(facet)
                or any(
                    isinstance(node, bool)
                    or not isinstance(node, int)
                    or node < 1
                    for node in facet
                )
                for facet in raw_facets
            ):
                raise ConstrainedHybridError(
                    "planar-annulus ruled correspondence requires TRI3/QUAD4 "
                    "facets with positive unique node IDs"
                )
            object.__setattr__(self, field_name, raw_facets)

    @property
    def facet_count(self) -> int:
        return len(self.outer_facets) + len(self.inner_facets)


@dataclass(frozen=True, slots=True)
class _PreparedLockedPatch:
    side: str
    facets: tuple[tuple[int, ...], ...]
    boundary_loops: tuple[tuple[int, ...], ...]
    outward: Point3D
    component_index: int = 0


@dataclass(frozen=True, slots=True)
class _PreparedInput:
    envelope: RectangularUfEnvelope
    z_min: float
    z_max: float
    geometry_tolerance_mm: float
    coordinates: Mapping[int, Point3D]
    patches: tuple[_PreparedLockedPatch, ...]

    @property
    def base_patch(self) -> _PreparedLockedPatch | None:
        return self.combined_patch("base")

    @property
    def cap_patch(self) -> _PreparedLockedPatch | None:
        return self.combined_patch("cap")

    def combined_patch(self, side: str) -> _PreparedLockedPatch | None:
        selected = tuple(patch for patch in self.patches if patch.side == side)
        if not selected:
            return None
        facets = tuple(
            facet for patch in selected for facet in patch.facets
        )
        return _PreparedLockedPatch(
            side=side,
            facets=facets,
            boundary_loops=_boundary_loops(facets),
            outward=_side_outward(side),
        )


@dataclass(frozen=True, slots=True)
class _PreparedRuledCorrespondence:
    outer_facets: tuple[tuple[int, ...], ...]
    inner_facets: tuple[tuple[int, ...], ...]


@dataclass(frozen=True, slots=True)
class _RawCandidate:
    coordinates: Mapping[int, Point3D]
    elements: tuple[tuple[int, int, tuple[int, ...]], ...]
    determinants: tuple[float, ...]
    sicn: tuple[float, ...]
    sige: tuple[float, ...]
    scaled_jacobian: tuple[float, ...]
    duplicate_node_count: int
    seed: int


def _edge_key(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def _normal(first: Point3D, second: Point3D, third: Point3D) -> Point3D:
    first_edge = tuple(second[index] - first[index] for index in range(3))
    second_edge = tuple(third[index] - first[index] for index in range(3))
    return (
        first_edge[1] * second_edge[2] - first_edge[2] * second_edge[1],
        first_edge[2] * second_edge[0] - first_edge[0] * second_edge[2],
        first_edge[0] * second_edge[1] - first_edge[1] * second_edge[0],
    )


def _facet_area(facet: Sequence[int], coordinates: Mapping[int, Point3D]) -> float:
    origin = coordinates[facet[0]]
    return 0.5 * math.fsum(
        math.sqrt(math.fsum(value * value for value in _normal(
            origin,
            coordinates[facet[index]],
            coordinates[facet[index + 1]],
        )))
        for index in range(1, len(facet) - 1)
    )


def _boundary_loops(
    facets: Sequence[Sequence[int]],
) -> tuple[tuple[int, ...], ...]:
    edge_counts: Counter[tuple[int, int]] = Counter()
    neighbors: dict[int, set[int]] = defaultdict(set)
    for facet in facets:
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge_counts[_edge_key(first, second)] += 1
    if any(count not in {1, 2} for count in edge_counts.values()):
        raise ConstrainedHybridError("locked UF boundary patch is non-manifold")
    boundary_edges = {edge for edge, count in edge_counts.items() if count == 1}
    if not boundary_edges:
        raise ConstrainedHybridError("locked UF boundary patch has no perimeter")
    for first, second in boundary_edges:
        neighbors[first].add(second)
        neighbors[second].add(first)
    if any(len(values) != 2 for values in neighbors.values()):
        raise ConstrainedHybridError(
            "locked UF boundary patch perimeter is not closed"
        )
    unused = set(boundary_edges)
    loops: list[tuple[int, ...]] = []
    while unused:
        start = min(node for edge in unused for node in edge)
        loop = [start]
        previous: int | None = None
        while True:
            candidates = sorted(
                node
                for node in neighbors[loop[-1]]
                if _edge_key(loop[-1], node) in unused
                and (previous is None or node != previous)
            )
            if not candidates:
                raise ConstrainedHybridError(
                    "locked UF boundary patch perimeter is open"
                )
            following = candidates[0]
            unused.remove(_edge_key(loop[-1], following))
            if following == start:
                break
            previous = loop[-1]
            loop.append(following)
            if len(loop) > len(boundary_edges):
                raise ConstrainedHybridError(
                    "locked UF boundary patch perimeter is invalid"
                )
        loops.append(tuple(loop))
    return tuple(sorted(loops, key=lambda loop: (len(loop), loop)))


def _facets_connected(facets: Sequence[Sequence[int]]) -> bool:
    owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            owners[_edge_key(first, second)].append(index)
    adjacency: dict[int, set[int]] = defaultdict(set)
    for indices in owners.values():
        if len(indices) == 2:
            adjacency[indices[0]].add(indices[1])
            adjacency[indices[1]].add(indices[0])
    seen: set[int] = set()
    queue = deque([0])
    while queue:
        current = queue.popleft()
        if current in seen:
            continue
        seen.add(current)
        queue.extend(adjacency[current].difference(seen))
    return len(seen) == len(facets)


def _facet_connected_components(
    facets: Sequence[tuple[int, ...]],
) -> tuple[tuple[tuple[int, ...], ...], ...]:
    owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            owners[_edge_key(first, second)].append(index)
    adjacency: dict[int, set[int]] = defaultdict(set)
    for indices in owners.values():
        if len(indices) == 2:
            adjacency[indices[0]].add(indices[1])
            adjacency[indices[1]].add(indices[0])
    remaining = set(range(len(facets)))
    components: list[tuple[tuple[int, ...], ...]] = []
    while remaining:
        start = min(remaining)
        seen: set[int] = set()
        queue = deque((start,))
        while queue:
            current = queue.popleft()
            if current in seen:
                continue
            seen.add(current)
            queue.extend(adjacency[current].difference(seen))
        remaining.difference_update(seen)
        components.append(tuple(facets[index] for index in sorted(seen)))
    return tuple(components)


def _loop_xy_area(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> float:
    return 0.5 * math.fsum(
        coordinates[loop[index]][0]
        * coordinates[loop[(index + 1) % len(loop)]][1]
        - coordinates[loop[(index + 1) % len(loop)]][0]
        * coordinates[loop[index]][1]
        for index in range(len(loop))
    )


def _inner_loop_is_die_perimeter(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
    envelope: RectangularUfEnvelope,
    *,
    tolerance_mm: float = _COORDINATE_TOLERANCE_MM,
) -> bool:
    tolerance = tolerance_mm
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    sides: set[str] = set()
    for first, second in zip(loop, (*loop[1:], loop[0])):
        points = (coordinates[first], coordinates[second])
        if all(abs(point[0] - x_min) <= tolerance for point in points):
            side = "die_x_min"
        elif all(abs(point[0] - x_max) <= tolerance for point in points):
            side = "die_x_max"
        elif all(abs(point[1] - y_min) <= tolerance for point in points):
            side = "die_y_min"
        elif all(abs(point[1] - y_max) <= tolerance for point in points):
            side = "die_y_max"
        else:
            return False
        if any(
            point[0] < x_min - tolerance
            or point[0] > x_max + tolerance
            or point[1] < y_min - tolerance
            or point[1] > y_max + tolerance
            for point in points
        ):
            return False
        sides.add(side)
    return sides == {
        "die_x_min",
        "die_x_max",
        "die_y_min",
        "die_y_max",
    }


def _complete_annulus_loops(
    patch: _PreparedLockedPatch | None,
    coordinates: Mapping[int, Point3D],
    envelope: RectangularUfEnvelope,
    *,
    tolerance_mm: float = _COORDINATE_TOLERANCE_MM,
) -> tuple[tuple[int, ...], tuple[int, ...]] | None:
    """Return outer/inner loops only for one complete planar annulus."""

    if (
        patch is None
        or not _facets_connected(patch.facets)
        or len(patch.boundary_loops) != 2
    ):
        return None
    ordered = tuple(
        sorted(
            patch.boundary_loops,
            key=lambda loop: abs(_loop_xy_area(loop, coordinates)),
            reverse=True,
        )
    )
    outer_loop, inner_loop = ordered
    if (
        abs(_loop_xy_area(outer_loop, coordinates))
        <= abs(_loop_xy_area(inner_loop, coordinates))
        + tolerance_mm**2
        or not _inner_loop_is_die_perimeter(
            inner_loop,
            coordinates,
            envelope,
            tolerance_mm=tolerance_mm,
        )
    ):
        return None
    return outer_loop, inner_loop


def _locked_base_maximum_outside_distance(
    prepared: _PreparedInput,
) -> float:
    """Return the physical radial extent of a complete locked base."""

    loops = _complete_annulus_loops(
        prepared.base_patch,
        prepared.coordinates,
        prepared.envelope,
        tolerance_mm=prepared.geometry_tolerance_mm,
    )
    if loops is None:
        raise ConstrainedHybridError(
            "locked UF base geometry authority is not one complete annulus"
        )
    return max(
        prepared.envelope.outside_distance(
            *prepared.coordinates[node][:2]
        )
        for node in loops[0]
    )


def _patch_spans_die(
    facets: Sequence[Sequence[int]],
    coordinates: Mapping[int, Point3D],
    envelope: RectangularUfEnvelope,
    *,
    tolerance_mm: float = _COORDINATE_TOLERANCE_MM,
) -> bool:
    referenced = {node for facet in facets for node in facet}
    x_values = tuple(coordinates[node][0] for node in referenced)
    y_values = tuple(coordinates[node][1] for node in referenced)
    tolerance = tolerance_mm
    return (
        min(x_values) <= envelope.center_x - envelope.half_die_width + tolerance
        and max(x_values) >= envelope.center_x + envelope.half_die_width - tolerance
        and min(y_values) <= envelope.center_y - envelope.half_die_length + tolerance
        and max(y_values) >= envelope.center_y + envelope.half_die_length - tolerance
    )


def _point_on_side(
    side: str,
    point: Point3D,
    envelope: RectangularUfEnvelope,
    z_min: float,
    z_max: float,
    *,
    tolerance_mm: float = _COORDINATE_TOLERANCE_MM,
) -> bool:
    x_value, y_value, z_value = point
    tolerance = tolerance_mm
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    if side == "base":
        return (
            abs(z_value - z_min) <= tolerance
            and (
                abs(x_value - envelope.center_x)
                >= envelope.half_die_width - tolerance
                or abs(y_value - envelope.center_y)
                >= envelope.half_die_length - tolerance
            )
            and envelope.outside_distance(x_value, y_value)
            <= envelope.fillet_width + tolerance
        )
    if side == "cap":
        cap_radius = envelope.fillet_width * (
            envelope.apex_z - z_max
        ) / envelope.height
        return (
            cap_radius > tolerance
            and abs(z_value - z_max) <= tolerance
            and (
                abs(x_value - envelope.center_x)
                >= envelope.half_die_width - tolerance
                or abs(y_value - envelope.center_y)
                >= envelope.half_die_length - tolerance
            )
            and envelope.outside_distance(x_value, y_value)
            <= cap_radius + tolerance
        )
    if not (z_min - tolerance <= z_value <= z_max + tolerance):
        return False
    return {
        "die_x_min": (
            abs(x_value - x_min) <= tolerance
            and y_min - tolerance <= y_value <= y_max + tolerance
        ),
        "die_x_max": (
            abs(x_value - x_max) <= tolerance
            and y_min - tolerance <= y_value <= y_max + tolerance
        ),
        "die_y_min": (
            abs(y_value - y_min) <= tolerance
            and x_min - tolerance <= x_value <= x_max + tolerance
        ),
        "die_y_max": (
            abs(y_value - y_max) <= tolerance
            and x_min - tolerance <= x_value <= x_max + tolerance
        ),
    }[side]


def _side_outward(side: str) -> Point3D:
    return {
        "base": (0.0, 0.0, -1.0),
        "cap": (0.0, 0.0, 1.0),
        "die_x_min": (1.0, 0.0, 0.0),
        "die_x_max": (-1.0, 0.0, 0.0),
        "die_y_min": (0.0, 1.0, 0.0),
        "die_y_max": (0.0, -1.0, 0.0),
    }[side]


def _prepare_inputs(
    locked_node_coordinates: Mapping[int, Sequence[float]],
    locked_boundary_facets: Mapping[str, Sequence[Sequence[int]]],
    envelope: RectangularUfEnvelope,
    z_min_mm: float,
    z_max_mm: float,
    *,
    geometry_tolerance_mm: float = _COORDINATE_TOLERANCE_MM,
) -> _PreparedInput:
    if not isinstance(envelope, RectangularUfEnvelope):
        raise ConstrainedHybridError(
            "direct UF conformal geometry must be RectangularUfEnvelope"
        )
    z_min = _finite(z_min_mm, name="direct UF slice minimum Z")
    z_max = _finite(z_max_mm, name="direct UF slice maximum Z")
    tolerance = _finite(
        geometry_tolerance_mm,
        name="direct UF interface geometry tolerance",
    )
    if tolerance <= 0.0:
        raise ConstrainedHybridError(
            "direct UF interface geometry tolerance must be positive"
        )
    if not (
        envelope.base_z - tolerance <= z_min
        < z_max
        <= envelope.apex_z + tolerance
    ):
        raise ConstrainedHybridError(
            "direct UF slice must lie inside the analytic fillet height"
        )
    if not isinstance(locked_node_coordinates, Mapping):
        raise ConstrainedHybridError("locked UF node coordinates must be a mapping")
    if not isinstance(locked_boundary_facets, Mapping):
        raise ConstrainedHybridError("locked UF facets must be grouped by side")
    unknown = set(locked_boundary_facets).difference(_LOCKED_SIDE_SET)
    if unknown:
        raise ConstrainedHybridError(
            "unknown locked UF boundary side(s): " + ", ".join(sorted(unknown))
        )

    coordinates: dict[int, Point3D] = {}
    for raw_id, raw_point in locked_node_coordinates.items():
        if isinstance(raw_id, bool) or not isinstance(raw_id, int) or raw_id < 1:
            raise ConstrainedHybridError(
                "locked UF node IDs must be positive integers"
            )
        try:
            values = tuple(raw_point)
        except TypeError as error:
            raise ConstrainedHybridError(
                "locked UF coordinate must contain x,y,z"
            ) from error
        if len(values) != 3:
            raise ConstrainedHybridError(
                "locked UF coordinate must contain x,y,z"
            )
        coordinates[raw_id] = tuple(
            _finite(value, name=f"locked UF node {raw_id}") for value in values
        )  # type: ignore[assignment]
    if len({_coordinate_key(point) for point in coordinates.values()}) != len(
        coordinates
    ):
        raise ConstrainedHybridError("locked UF nodes contain duplicate coordinates")

    patches: list[_PreparedLockedPatch] = []
    all_face_keys: set[FaceKey] = set()
    referenced: set[int] = set()
    for side in _LOCKED_SIDE_ORDER:
        raw_group = locked_boundary_facets.get(side, ())
        try:
            raw_facets = tuple(tuple(facet) for facet in raw_group)
        except TypeError as error:
            raise ConstrainedHybridError(
                f"locked UF {side} facets must be TRI3/QUAD4"
            ) from error
        if not raw_facets:
            continue
        facets: list[tuple[int, ...]] = []
        for raw_facet in raw_facets:
            if len(raw_facet) not in {3, 4}:
                raise ConstrainedHybridError(
                    f"locked UF {side} facets must be TRI3/QUAD4"
                )
            if any(
                isinstance(node, bool) or not isinstance(node, int)
                for node in raw_facet
            ):
                raise ConstrainedHybridError(
                    f"locked UF {side} node IDs must be integers"
                )
            facet = tuple(int(node) for node in raw_facet)
            if len(set(facet)) != len(facet) or any(
                node not in coordinates for node in facet
            ):
                raise ConstrainedHybridError(
                    f"locked UF {side} facet is invalid"
                )
            if side in {"base", "cap"}:
                expected_z = z_min if side == "base" else z_max
                if any(
                    abs(coordinates[node][2] - expected_z)
                    > tolerance
                    for node in facet
                ):
                    raise ConstrainedHybridError(
                        f"locked UF {side} patch must be planar at the "
                        f"slice {'minimum' if side == 'base' else 'maximum'} Z"
                    )
            if side not in {"base", "cap"} and not all(
                _point_on_side(
                    side,
                    coordinates[node],
                    envelope,
                    z_min,
                    z_max,
                    tolerance_mm=tolerance,
                )
                for node in facet
            ):
                raise ConstrainedHybridError(
                    f"locked UF {side} facet is not on that analytic side"
                )
            if _facet_area(facet, coordinates) <= _COORDINATE_TOLERANCE_MM**2:
                raise ConstrainedHybridError(
                    f"locked UF {side} facet has zero area"
                )
            key = _face_key(facet)
            if key in all_face_keys:
                raise ConstrainedHybridError("locked UF facets must be unique")
            all_face_keys.add(key)
            referenced.update(facet)
            facets.append(facet)
        # Completeness/geometry authority is a side-level property.  A caller
        # may nevertheless lock several disjoint islands on the same geometric
        # side (for example propagated target-exterior islands).  Audit the
        # union here, then materialize each edge-connected component as its own
        # OCC imprint below so no surface mapping can overwrite another merely
        # because both share a side name.
        combined_patch = _PreparedLockedPatch(
            side=side,
            facets=tuple(facets),
            boundary_loops=_boundary_loops(facets),
            outward=_side_outward(side),
        )
        if side in {"base", "cap"}:
            complete_annulus = _complete_annulus_loops(
                combined_patch,
                coordinates,
                envelope,
                tolerance_mm=tolerance,
            )
            outside_analytic = tuple(
                node
                for node in {value for facet in facets for value in facet}
                if not _point_on_side(
                    side,
                    coordinates[node],
                    envelope,
                    z_min,
                    z_max,
                    tolerance_mm=tolerance,
                )
            )
            if complete_annulus is None and outside_analytic:
                if _patch_spans_die(
                    facets,
                    coordinates,
                    envelope,
                    tolerance_mm=tolerance,
                ):
                    raise ConstrainedHybridError(
                        f"locked UF {side} geometry authority is missing its one "
                        "die-inner-loop"
                    )
                raise ConstrainedHybridError(
                    f"partial locked UF {side} facet is not on the analytic side; "
                    "only a complete planar annulus with one die-inner-loop "
                    f"may define {side} geometry"
                )
            if complete_annulus is not None:
                opposite_radius = max(
                    0.0,
                    _slice_radius(
                        envelope,
                        z_max if side == "base" else z_min,
                    ),
                )
                referenced_annulus = {
                    value for facet in facets for value in facet
                }
                inside_penetration = tuple(
                    min(
                        envelope.half_die_width
                        - abs(coordinates[node][0] - envelope.center_x),
                        envelope.half_die_length
                        - abs(coordinates[node][1] - envelope.center_y),
                    )
                    for node in referenced_annulus
                    if not envelope.is_outside_die(*coordinates[node][:2])
                )
                if inside_penetration and max(inside_penetration) > tolerance:
                    raise ConstrainedHybridError(
                        f"complete locked UF {side} annulus crosses the die "
                        "interior beyond the configured interface geometry "
                        f"tolerance: maximum_penetration_mm="
                        f"{max(inside_penetration):.12g}, "
                        f"tolerance_mm={tolerance:.12g}"
                    )
                # A cap authority must fit inside the wider analytic base so a
                # ruled shell cannot turn back on itself.  A base authority is
                # intentionally allowed to be the Orth staircase footprint,
                # including its bounded overshoot beyond the analytic toe.
                if side == "cap" and any(
                    envelope.outside_distance(*coordinates[node][:2])
                    > opposite_radius + tolerance
                    for node in complete_annulus[0]
                ):
                    raise ConstrainedHybridError(
                        "complete locked UF cap cannot be ruled to the analytic "
                        "base without leaving its footprint"
                    )
        for component_index, component_facets in enumerate(
            _facet_connected_components(tuple(facets))
        ):
            patches.append(
                _PreparedLockedPatch(
                    side=side,
                    facets=component_facets,
                    boundary_loops=_boundary_loops(component_facets),
                    outward=_side_outward(side),
                    component_index=component_index,
                )
            )
    if referenced != set(coordinates):
        raise ConstrainedHybridError(
            "every locked UF node must be referenced by a boundary facet"
        )
    return _PreparedInput(
        envelope=envelope,
        z_min=z_min,
        z_max=z_max,
        geometry_tolerance_mm=tolerance,
        coordinates=MappingProxyType(coordinates),
        patches=tuple(patches),
    )


def _loop_edges(loop: Sequence[int]) -> set[tuple[int, int]]:
    return {
        _edge_key(first, second)
        for first, second in zip(loop, (*loop[1:], loop[0]))
    }


def _quad_is_planar(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> bool:
    if len(facet) == 3:
        return True
    first, second, third, fourth = (
        coordinates[node] for node in facet
    )
    normal = _normal(first, second, third)
    magnitude = math.sqrt(math.fsum(value * value for value in normal))
    if magnitude <= _COORDINATE_TOLERANCE_MM**2:
        return False
    offset = tuple(fourth[index] - first[index] for index in range(3))
    distance = abs(
        math.fsum(normal[index] * offset[index] for index in range(3))
    ) / magnitude
    return distance <= _OCC_TOLERANCE_MM


def _validate_ruled_strip(
    facets: Sequence[Sequence[int]],
    first_loop: Sequence[int],
    second_loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
    *,
    label: str,
    envelope: RectangularUfEnvelope,
) -> tuple[tuple[int, ...], ...]:
    values = tuple(tuple(facet) for facet in facets)
    first_nodes = set(first_loop)
    second_nodes = set(second_loop)
    allowed_nodes = first_nodes.union(second_nodes)
    face_keys = tuple(_face_key(facet) for facet in values)
    if len(set(face_keys)) != len(face_keys):
        raise ConstrainedHybridError(
            f"two-boundary {label} ruled facets are duplicated"
        )
    for facet in values:
        if (
            any(node not in allowed_nodes for node in facet)
            or not first_nodes.intersection(facet)
            or not second_nodes.intersection(facet)
        ):
            raise ConstrainedHybridError(
                f"two-boundary {label} ruled facet must join only its two "
                "endpoint loops"
            )
        if (
            _facet_area(facet, coordinates)
            <= _COORDINATE_TOLERANCE_MM**2
            or not _quad_is_planar(facet, coordinates)
        ):
            raise ConstrainedHybridError(
                f"two-boundary {label} ruled facet is zero-area or non-planar"
            )
    if not _facets_connected(values):
        raise ConstrainedHybridError(
            f"two-boundary {label} ruled strip is disconnected"
        )
    edge_counts = Counter(
        _edge_key(first, second)
        for facet in values
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    if any(count not in {1, 2} for count in edge_counts.values()):
        raise ConstrainedHybridError(
            f"two-boundary {label} ruled strip is non-manifold"
        )
    actual_boundary = {
        edge for edge, count in edge_counts.items() if count == 1
    }
    expected_boundary = _loop_edges(first_loop).union(
        _loop_edges(second_loop)
    )
    if actual_boundary != expected_boundary:
        missing = expected_boundary.difference(actual_boundary)
        extra = actual_boundary.difference(expected_boundary)
        raise ConstrainedHybridError(
            f"two-boundary {label} ruled strip does not preserve endpoint "
            f"edges: missing={len(missing)}, extra={len(extra)}"
        )
    if label == "inner":
        x_min = envelope.center_x - envelope.half_die_width
        x_max = envelope.center_x + envelope.half_die_width
        y_min = envelope.center_y - envelope.half_die_length
        y_max = envelope.center_y + envelope.half_die_length
        if any(
            not any(
                all(
                    abs(coordinates[node][axis] - value)
                    <= _COORDINATE_TOLERANCE_MM
                    for node in facet
                )
                for axis, value in (
                    (0, x_min),
                    (0, x_max),
                    (1, y_min),
                    (1, y_max),
                )
            )
            for facet in values
        ):
            raise ConstrainedHybridError(
                "two-boundary inner ruled facets must stay on one die wall"
            )
    return values


def _prepare_ruled_correspondence(
    prepared: _PreparedInput,
    correspondence: PlanarAnnulusRuledCorrespondence | None,
) -> _PreparedRuledCorrespondence | None:
    if correspondence is None:
        return None
    if type(correspondence) is not PlanarAnnulusRuledCorrespondence:
        raise ConstrainedHybridError(
            "two-boundary correspondence has an invalid type"
        )
    base_loops = _complete_annulus_loops(
        prepared.base_patch,
        prepared.coordinates,
        prepared.envelope,
        tolerance_mm=prepared.geometry_tolerance_mm,
    )
    cap_loops = _complete_annulus_loops(
        prepared.cap_patch,
        prepared.coordinates,
        prepared.envelope,
        tolerance_mm=prepared.geometry_tolerance_mm,
    )
    if base_loops is None or cap_loops is None:
        raise ConstrainedHybridError(
            "two-boundary correspondence requires complete locked planar "
            "base and cap annuli"
        )
    outer = _validate_ruled_strip(
        correspondence.outer_facets,
        base_loops[0],
        cap_loops[0],
        prepared.coordinates,
        label="outer",
        envelope=prepared.envelope,
    )
    inner = _validate_ruled_strip(
        correspondence.inner_facets,
        base_loops[1],
        cap_loops[1],
        prepared.coordinates,
        label="inner",
        envelope=prepared.envelope,
    )
    if {_face_key(facet) for facet in outer}.intersection(
        {_face_key(facet) for facet in inner}
    ):
        raise ConstrainedHybridError(
            "two-boundary outer and inner ruled facets overlap"
        )
    closed_edge_counts = Counter(
        _edge_key(first, second)
        for facet in (
            *prepared.base_patch.facets,  # type: ignore[union-attr]
            *prepared.cap_patch.facets,  # type: ignore[union-attr]
            *outer,
            *inner,
        )
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    bad_edges = {
        edge: count for edge, count in closed_edge_counts.items() if count != 2
    }
    if bad_edges:
        raise ConstrainedHybridError(
            "two-boundary ruled loft is not a closed two-manifold: "
            f"bad_edges={len(bad_edges)}"
        )
    return _PreparedRuledCorrespondence(outer, inner)


def _canonical_xy_loop(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[int, ...]:
    values = tuple(loop)
    if _loop_xy_area(values, coordinates) < 0.0:
        values = tuple(reversed(values))
    start = min(
        range(len(values)),
        key=lambda index: (
            round(coordinates[values[index]][0], 12),
            round(coordinates[values[index]][1], 12),
            values[index],
        ),
    )
    return values[start:] + values[:start]


def _normalized_loop_positions(
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[float, ...]:
    lengths = tuple(
        math.dist(coordinates[first], coordinates[second])
        for first, second in zip(loop, (*loop[1:], loop[0]))
    )
    total = math.fsum(lengths)
    if total <= _COORDINATE_TOLERANCE_MM:
        raise ConstrainedHybridError(
            "two-boundary endpoint loop has zero perimeter"
        )
    positions = [0.0]
    running = 0.0
    for length in lengths:
        running += length
        positions.append(running / total)
    positions[-1] = 1.0
    return tuple(positions)


def _zipper_ruled_loops(
    first_loop: Sequence[int],
    second_loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[int, ...], ...]:
    first = _canonical_xy_loop(first_loop, coordinates)
    second = _canonical_xy_loop(second_loop, coordinates)
    first_positions = _normalized_loop_positions(first, coordinates)
    second_positions = _normalized_loop_positions(second, coordinates)
    first_index = 0
    second_index = 0
    facets: list[tuple[int, ...]] = []
    tolerance = 1.0e-12
    while first_index < len(first) or second_index < len(second):
        first_next = (
            first_positions[first_index + 1]
            if first_index < len(first)
            else math.inf
        )
        second_next = (
            second_positions[second_index + 1]
            if second_index < len(second)
            else math.inf
        )
        first_node = first[first_index % len(first)]
        second_node = second[second_index % len(second)]
        if abs(first_next - second_next) <= tolerance:
            first_following = first[(first_index + 1) % len(first)]
            second_following = second[(second_index + 1) % len(second)]
            facets.append((first_node, first_following, second_following))
            facets.append((first_node, second_following, second_node))
            first_index += 1
            second_index += 1
        elif first_next < second_next:
            first_following = first[(first_index + 1) % len(first)]
            facets.append((first_node, first_following, second_node))
            first_index += 1
        else:
            second_following = second[(second_index + 1) % len(second)]
            facets.append((first_node, second_following, second_node))
            second_index += 1
    return tuple(facets)


def derive_planar_annulus_ruled_correspondence(
    locked_node_coordinates: Mapping[int, Sequence[float]],
    locked_boundary_facets: Mapping[str, Sequence[Sequence[int]]],
    envelope: RectangularUfEnvelope,
    z_min_mm: float,
    z_max_mm: float,
) -> PlanarAnnulusRuledCorrespondence:
    """Derive and fully validate an explicit ruled-strip correspondence."""

    prepared = _prepare_inputs(
        locked_node_coordinates,
        locked_boundary_facets,
        envelope,
        z_min_mm,
        z_max_mm,
    )
    base_loops = _complete_annulus_loops(
        prepared.base_patch,
        prepared.coordinates,
        prepared.envelope,
        tolerance_mm=prepared.geometry_tolerance_mm,
    )
    cap_loops = _complete_annulus_loops(
        prepared.cap_patch,
        prepared.coordinates,
        prepared.envelope,
        tolerance_mm=prepared.geometry_tolerance_mm,
    )
    if base_loops is None or cap_loops is None:
        raise ConstrainedHybridError(
            "ruled correspondence derivation requires complete locked planar "
            "base and cap annuli"
        )
    result = PlanarAnnulusRuledCorrespondence(
        outer_facets=_zipper_ruled_loops(
            base_loops[0],
            cap_loops[0],
            prepared.coordinates,
        ),
        inner_facets=_zipper_ruled_loops(
            base_loops[1],
            cap_loops[1],
            prepared.coordinates,
        ),
    )
    _prepare_ruled_correspondence(prepared, result)
    return result


def _add_plane_surface(gmsh: Any, points: Sequence[Point3D]) -> int:
    point_tags = tuple(int(gmsh.model.occ.addPoint(*point)) for point in points)
    curves = tuple(
        int(gmsh.model.occ.addLine(first, second))
        for first, second in zip(point_tags, (*point_tags[1:], point_tags[0]))
    )
    loop = int(gmsh.model.occ.addCurveLoop(curves))
    return int(gmsh.model.occ.addPlaneSurface([loop]))


def _add_prism(
    gmsh: Any,
    section_points: Sequence[Point3D],
    vector: Point3D,
) -> int:
    surface = _add_plane_surface(gmsh, section_points)
    volumes = tuple(
        int(tag)
        for dimension, tag in gmsh.model.occ.extrude(
            [(2, surface)], *vector
        )
        if int(dimension) == 3
    )
    if len(volumes) != 1:
        raise ConstrainedHybridError("OCC could not extrude an exact UF side prism")
    return volumes[0]


def _slice_radius(
    envelope: RectangularUfEnvelope,
    z_value: float,
) -> float:
    return envelope.fillet_width * (
        envelope.apex_z - z_value
    ) / envelope.height


def _analytic_slice_volume(prepared: _PreparedInput) -> float:
    envelope = prepared.envelope
    height = prepared.z_max - prepared.z_min
    bottom_radius = _slice_radius(envelope, prepared.z_min)
    top_radius = max(0.0, _slice_radius(envelope, prepared.z_max))
    return height * (
        (envelope.die_width + envelope.die_length)
        * (bottom_radius + top_radius)
        + math.pi
        * (
            bottom_radius * bottom_radius
            + bottom_radius * top_radius
            + top_radius * top_radius
        )
        / 3.0
    )


def _add_authoritative_base_to_zero_width_cap(
    gmsh: Any,
    prepared: _PreparedInput,
    outer_loop: Sequence[int],
    inner_loop: Sequence[int],
) -> tuple[int, float]:
    """Close one complete locked base at the zero-width analytic apex.

    This deliberately narrow construction is accepted only when radial
    projection of the locked outer staircase onto the die perimeter has the
    exact same undirected edge partition as the locked inner loop.  The common
    projected cycle is then used once by both the outer ruled faces and the
    four inner die walls; no zero-area cap surface is manufactured.  OCC owns
    this two-dimensional shell and Gmsh still owns all volume connectivity.
    """

    envelope = prepared.envelope
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    top_z = prepared.z_max

    def project(point: Point3D) -> Point3D:
        x_value, y_value, _z_value = point
        anchor_x = min(max(x_value, x_min), x_max)
        anchor_y = min(max(y_value, y_min), y_max)
        if math.hypot(x_value - anchor_x, y_value - anchor_y) <= (
            _COORDINATE_TOLERANCE_MM
        ):
            raise ConstrainedHybridError(
                "locked UF base outer loop touches the die perimeter before "
                "the zero-width cap"
            )
        return anchor_x, anchor_y, top_z

    projected_by_outer_node = {
        node: project(prepared.coordinates[node]) for node in outer_loop
    }

    def cycle_coordinate_edges(
        points: Sequence[Point3D],
    ) -> frozenset[tuple[tuple[float, float, float], tuple[float, float, float]]]:
        collapsed: list[tuple[float, float, float]] = []
        for point in points:
            key = _coordinate_key(point)
            if not collapsed or key != collapsed[-1]:
                collapsed.append(key)
        if len(collapsed) > 1 and collapsed[0] == collapsed[-1]:
            collapsed.pop()
        if len(collapsed) < 4:
            raise ConstrainedHybridError(
                "locked UF base projection cannot form the zero-width cap cycle"
            )
        return frozenset(
            tuple(sorted((first, second)))
            for first, second in zip(
                collapsed,
                (*collapsed[1:], collapsed[0]),
            )
        )

    projected_edges = cycle_coordinate_edges(
        tuple(projected_by_outer_node[node] for node in outer_loop)
    )
    inner_top_points = tuple(
        (
            prepared.coordinates[node][0],
            prepared.coordinates[node][1],
            top_z,
        )
        for node in inner_loop
    )
    if projected_edges != cycle_coordinate_edges(inner_top_points):
        raise ConstrainedHybridError(
            "zero-width locked-base UF requires the projected outer staircase "
            "cycle to match the die-inner cycle exactly"
        )

    point_by_coordinate: dict[tuple[float, float, float], int] = {}
    curve_by_edge: dict[tuple[int, int], tuple[int, int, int]] = {}

    def point_tag(point: Point3D) -> int:
        key = _coordinate_key(point)
        tag = point_by_coordinate.get(key)
        if tag is None:
            tag = int(gmsh.model.occ.addPoint(*point))
            point_by_coordinate[key] = tag
        return tag

    def oriented_curve(first: int, second: int) -> int:
        key = _edge_key(first, second)
        stored = curve_by_edge.get(key)
        if stored is None:
            tag = int(gmsh.model.occ.addLine(first, second))
            curve_by_edge[key] = (tag, first, second)
            return tag
        tag, stored_first, stored_second = stored
        return tag if (first, second) == (stored_first, stored_second) else -tag

    def curve_loop(tags: Sequence[int]) -> int:
        return int(
            gmsh.model.occ.addCurveLoop(
                tuple(
                    oriented_curve(first, second)
                    for first, second in zip(tags, (*tags[1:], tags[0]))
                )
            )
        )

    def plane_surface(tags: Sequence[int]) -> int:
        if len(set(tags)) < 3:
            raise ConstrainedHybridError(
                "zero-width locked-base UF produced a degenerate ruled face"
            )
        return int(gmsh.model.occ.addPlaneSurface([curve_loop(tags)]))

    outer_base_tags = tuple(
        point_tag(prepared.coordinates[node]) for node in outer_loop
    )
    inner_base_tags = tuple(
        point_tag(prepared.coordinates[node]) for node in inner_loop
    )
    outer_top_tags = tuple(
        point_tag(projected_by_outer_node[node]) for node in outer_loop
    )
    inner_top_tags = tuple(point_tag(point) for point in inner_top_points)

    base_surface = int(
        gmsh.model.occ.addPlaneSurface(
            [curve_loop(outer_base_tags), curve_loop(inner_base_tags)]
        )
    )

    outer_surfaces: list[int] = []
    for index in range(len(outer_base_tags)):
        following = (index + 1) % len(outer_base_tags)
        bottom_first = outer_base_tags[index]
        bottom_second = outer_base_tags[following]
        top_first = outer_top_tags[index]
        top_second = outer_top_tags[following]
        if top_first == top_second:
            outer_surfaces.append(
                plane_surface((bottom_first, bottom_second, top_first))
            )
        else:
            outer_surfaces.append(
                plane_surface((bottom_first, bottom_second, top_second))
            )
            outer_surfaces.append(
                plane_surface((bottom_first, top_second, top_first))
            )

    inner_edge_sides: list[str] = []
    for index in range(len(inner_loop)):
        following = (index + 1) % len(inner_loop)
        points = (
            prepared.coordinates[inner_loop[index]],
            prepared.coordinates[inner_loop[following]],
        )
        if all(abs(point[0] - x_min) <= _COORDINATE_TOLERANCE_MM for point in points):
            inner_edge_sides.append("die_x_min")
        elif all(abs(point[0] - x_max) <= _COORDINATE_TOLERANCE_MM for point in points):
            inner_edge_sides.append("die_x_max")
        elif all(abs(point[1] - y_min) <= _COORDINATE_TOLERANCE_MM for point in points):
            inner_edge_sides.append("die_y_min")
        elif all(abs(point[1] - y_max) <= _COORDINATE_TOLERANCE_MM for point in points):
            inner_edge_sides.append("die_y_max")
        else:  # pragma: no cover - complete-annulus validation guards this
            raise ConstrainedHybridError(
                "zero-width locked-base UF inner edge escaped the die perimeter"
            )
    cut = next(
        (
            index
            for index in range(len(inner_loop))
            if inner_edge_sides[index] != inner_edge_sides[index - 1]
        ),
        0,
    )
    ordered_indices = tuple(
        (cut + offset) % len(inner_loop) for offset in range(len(inner_loop))
    )
    runs: list[list[int]] = []
    for index in ordered_indices:
        if not runs or inner_edge_sides[index] != inner_edge_sides[runs[-1][-1]]:
            runs.append([])
        runs[-1].append(index)
    if len(runs) != 4:
        raise ConstrainedHybridError(
            "zero-width locked-base UF inner loop does not define four die sides"
        )

    inner_surfaces: list[int] = []
    for run in runs:
        bottom_chain_indices = [
            run[0],
            *((index + 1) % len(inner_loop) for index in run),
        ]
        bottom_chain = [
            inner_base_tags[index] for index in bottom_chain_indices
        ]
        top_chain = [
            inner_top_tags[index]
            for index in reversed(bottom_chain_indices)
        ]
        inner_surfaces.append(
            plane_surface((*bottom_chain, *top_chain))
        )

    shell = int(
        gmsh.model.occ.addSurfaceLoop(
            [base_surface, *outer_surfaces, *inner_surfaces],
            sewing=False,
        )
    )
    return int(gmsh.model.occ.addVolume([shell])), _analytic_slice_volume(prepared)


def _add_authoritative_annulus_uf_slice(
    gmsh: Any,
    prepared: _PreparedInput,
    *,
    authority_side: str,
) -> tuple[int, float]:
    """Create a ruled fillet from one complete locked planar annulus.

    The locked base or cap is the geometry authority on its own Z plane.  Its
    outer polygon is connected to the opposite analytic offset curve, while
    the die perimeter is carried vertically.  All entities built here are CAD
    curves/surfaces; Gmsh still owns every volume element.
    """

    if authority_side not in {"base", "cap"}:
        raise AssertionError("UF annulus authority side is invalid")
    base_patch = (
        prepared.base_patch
        if authority_side == "base"
        else prepared.cap_patch
    )
    if base_patch is None:  # pragma: no cover - guarded by the dispatcher
        raise AssertionError(f"authoritative UF {authority_side} is unavailable")
    opposite_z = (
        prepared.z_max if authority_side == "base" else prepared.z_min
    )
    top_radius = max(0.0, _slice_radius(prepared.envelope, opposite_z))
    complete_loops = _complete_annulus_loops(
        base_patch,
        prepared.coordinates,
        prepared.envelope,
        tolerance_mm=prepared.geometry_tolerance_mm,
    )
    if complete_loops is None:
        raise ConstrainedHybridError(
            f"locked UF {authority_side} geometry authority must be one "
            "complete annulus with one die-inner-loop"
        )
    outer_loop, inner_loop = complete_loops
    envelope = prepared.envelope
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    if not all(
        (
            abs(prepared.coordinates[node][0] - x_min)
            <= _COORDINATE_TOLERANCE_MM
            or abs(prepared.coordinates[node][0] - x_max)
            <= _COORDINATE_TOLERANCE_MM
            or abs(prepared.coordinates[node][1] - y_min)
            <= _COORDINATE_TOLERANCE_MM
            or abs(prepared.coordinates[node][1] - y_max)
            <= _COORDINATE_TOLERANCE_MM
        )
        and x_min - _COORDINATE_TOLERANCE_MM
        <= prepared.coordinates[node][0]
        <= x_max + _COORDINATE_TOLERANCE_MM
        and y_min - _COORDINATE_TOLERANCE_MM
        <= prepared.coordinates[node][1]
        <= y_max + _COORDINATE_TOLERANCE_MM
        for node in inner_loop
    ):
        raise ConstrainedHybridError(
            f"locked UF {authority_side} annulus inner loop must equal the "
            "die perimeter"
        )
    if top_radius <= _COORDINATE_TOLERANCE_MM:
        if authority_side != "base":  # pragma: no cover - canonical toe is positive
            raise ConstrainedHybridError(
                "a locked UF cap requires a positive-width analytic base"
            )
        return _add_authoritative_base_to_zero_width_cap(
            gmsh,
            prepared,
            outer_loop,
            inner_loop,
        )

    base_outer_points = tuple(prepared.coordinates[node] for node in outer_loop)
    base_inner_points = tuple(prepared.coordinates[node] for node in inner_loop)
    raw_top_outer_points: list[Point3D] = []
    for x_value, y_value, _z_value in base_outer_points:
        anchor_x = min(max(x_value, x_min), x_max)
        anchor_y = min(max(y_value, y_min), y_max)
        delta_x = x_value - anchor_x
        delta_y = y_value - anchor_y
        distance = math.hypot(delta_x, delta_y)
        if distance <= _COORDINATE_TOLERANCE_MM:
            raise ConstrainedHybridError(
                f"locked UF {authority_side} outer loop touches the die perimeter"
            )
        raw_top_outer_points.append(
            (
                anchor_x + top_radius * delta_x / distance,
                anchor_y + top_radius * delta_y / distance,
                opposite_z,
            )
        )
    top_outer_points: list[Point3D] = []
    top_index_by_base: list[int] = []
    top_index_by_coordinate: dict[tuple[float, float, float], int] = {}
    for point in raw_top_outer_points:
        key = _coordinate_key(point)
        top_index = top_index_by_coordinate.get(key)
        if top_index is None:
            top_index = len(top_outer_points)
            top_index_by_coordinate[key] = top_index
            top_outer_points.append(point)
        top_index_by_base.append(top_index)
    if len(top_outer_points) < 3:
        raise ConstrainedHybridError(
            f"locked UF {authority_side} cannot form a positive-area "
            "opposite analytic annulus"
        )
    top_inner_points = tuple(
        (x_value, y_value, opposite_z)
        for x_value, y_value, _z_value in base_inner_points
    )

    def add_points(points: Sequence[Point3D]) -> tuple[int, ...]:
        return tuple(int(gmsh.model.occ.addPoint(*point)) for point in points)

    def add_cycle(points: Sequence[int]) -> tuple[int, ...]:
        return tuple(
            int(gmsh.model.occ.addLine(first, second))
            for first, second in zip(points, (*points[1:], points[0]))
        )

    base_outer_tags = add_points(base_outer_points)
    top_outer_tags = add_points(top_outer_points)
    base_inner_tags = add_points(base_inner_points)
    top_inner_tags = add_points(top_inner_points)
    base_outer_edges = add_cycle(base_outer_tags)
    top_outer_edges = add_cycle(top_outer_tags)
    base_inner_edges = add_cycle(base_inner_tags)
    top_inner_edges = add_cycle(top_inner_tags)
    base_surface = int(
        gmsh.model.occ.addPlaneSurface(
            [
                int(gmsh.model.occ.addCurveLoop(base_outer_edges)),
                int(gmsh.model.occ.addCurveLoop(base_inner_edges)),
            ]
        )
    )
    cap_surface = int(
        gmsh.model.occ.addPlaneSurface(
            [
                int(gmsh.model.occ.addCurveLoop(top_outer_edges)),
                int(gmsh.model.occ.addCurveLoop(top_inner_edges)),
            ]
        )
    )

    outer_vertical = tuple(
        int(
            gmsh.model.occ.addLine(
                base_tag,
                top_outer_tags[top_index_by_base[index]],
            )
        )
        for index, base_tag in enumerate(base_outer_tags)
    )
    free_surfaces: list[int] = []
    outer_count = len(base_outer_tags)
    for index in range(outer_count):
        following = (index + 1) % outer_count
        top_index = top_index_by_base[index]
        following_top_index = top_index_by_base[following]
        if top_index == following_top_index:
            loop = int(
                gmsh.model.occ.addCurveLoop(
                    (
                        base_outer_edges[index],
                        outer_vertical[following],
                        -outer_vertical[index],
                    )
                )
            )
            free_surfaces.append(int(gmsh.model.occ.addPlaneSurface([loop])))
            continue
        if following_top_index == (top_index + 1) % len(top_outer_tags):
            top_edge = top_outer_edges[top_index]
        elif top_index == (following_top_index + 1) % len(top_outer_tags):
            top_edge = -top_outer_edges[following_top_index]
        else:
            raise ConstrainedHybridError(
                f"locked UF {authority_side} projects to a self-intersecting "
                "opposite loop"
            )
        diagonal = int(
            gmsh.model.occ.addLine(
                base_outer_tags[index],
                top_outer_tags[following_top_index],
            )
        )
        first_loop = int(
            gmsh.model.occ.addCurveLoop(
                (
                    base_outer_edges[index],
                    outer_vertical[following],
                    -diagonal,
                )
            )
        )
        second_loop = int(
            gmsh.model.occ.addCurveLoop(
                (
                    diagonal,
                    -top_edge,
                    -outer_vertical[index],
                )
            )
        )
        free_surfaces.append(int(gmsh.model.occ.addPlaneSurface([first_loop])))
        free_surfaces.append(int(gmsh.model.occ.addPlaneSurface([second_loop])))

    inner_vertical = tuple(
        int(gmsh.model.occ.addLine(first, second))
        for first, second in zip(base_inner_tags, top_inner_tags)
    )
    inner_count = len(base_inner_tags)
    inner_edge_sides: list[str] = []
    for index in range(inner_count):
        following = (index + 1) % inner_count
        points = (base_inner_points[index], base_inner_points[following])
        if all(abs(point[0] - x_min) <= _COORDINATE_TOLERANCE_MM for point in points):
            inner_edge_sides.append("die_x_min")
        elif all(abs(point[0] - x_max) <= _COORDINATE_TOLERANCE_MM for point in points):
            inner_edge_sides.append("die_x_max")
        elif all(abs(point[1] - y_min) <= _COORDINATE_TOLERANCE_MM for point in points):
            inner_edge_sides.append("die_y_min")
        elif all(abs(point[1] - y_max) <= _COORDINATE_TOLERANCE_MM for point in points):
            inner_edge_sides.append("die_y_max")
        else:  # pragma: no cover - validated above
            raise ConstrainedHybridError(
                f"locked UF {authority_side} inner edge escaped the die perimeter"
            )
    cut = next(
        (
            index
            for index in range(inner_count)
            if inner_edge_sides[index] != inner_edge_sides[index - 1]
        ),
        0,
    )
    ordered_indices = tuple(
        (cut + offset) % inner_count for offset in range(inner_count)
    )
    runs: list[list[int]] = []
    for index in ordered_indices:
        if not runs or inner_edge_sides[index] != inner_edge_sides[runs[-1][-1]]:
            runs.append([])
        runs[-1].append(index)
    if len(runs) != 4 or {inner_edge_sides[run[0]] for run in runs} != {
        "die_x_min",
        "die_x_max",
        "die_y_min",
        "die_y_max",
    }:
        raise ConstrainedHybridError(
            f"locked UF {authority_side} inner loop does not define four die sides"
        )
    die_surfaces: list[int] = []
    for run in runs:
        start_index = run[0]
        end_node = (run[-1] + 1) % inner_count
        loop = int(
            gmsh.model.occ.addCurveLoop(
                (
                    *(base_inner_edges[index] for index in run),
                    inner_vertical[end_node],
                    *(-top_inner_edges[index] for index in reversed(run)),
                    -inner_vertical[start_index],
                )
            )
        )
        die_surfaces.append(int(gmsh.model.occ.addPlaneSurface([loop])))

    shell = int(
        gmsh.model.occ.addSurfaceLoop(
            [base_surface, cap_surface, *free_surfaces, *die_surfaces],
            sewing=False,
        )
    )
    volume_tag = int(gmsh.model.occ.addVolume([shell]))
    return volume_tag, _analytic_slice_volume(prepared)


def _add_authoritative_base_uf_slice(
    gmsh: Any,
    prepared: _PreparedInput,
) -> tuple[int, float]:
    return _add_authoritative_annulus_uf_slice(
        gmsh,
        prepared,
        authority_side="base",
    )


def _add_authoritative_cap_uf_slice(
    gmsh: Any,
    prepared: _PreparedInput,
) -> tuple[int, float]:
    return _add_authoritative_annulus_uf_slice(
        gmsh,
        prepared,
        authority_side="cap",
    )


def _add_authoritative_two_boundary_uf_slice(
    gmsh: Any,
    prepared: _PreparedInput,
    correspondence: _PreparedRuledCorrespondence,
) -> tuple[int, float]:
    base_loops = _complete_annulus_loops(
        prepared.base_patch,
        prepared.coordinates,
        prepared.envelope,
        tolerance_mm=prepared.geometry_tolerance_mm,
    )
    cap_loops = _complete_annulus_loops(
        prepared.cap_patch,
        prepared.coordinates,
        prepared.envelope,
        tolerance_mm=prepared.geometry_tolerance_mm,
    )
    if base_loops is None or cap_loops is None:  # pragma: no cover - dispatcher
        raise AssertionError("two-boundary authoritative annuli are unavailable")

    point_by_source: dict[int, int] = {}
    curve_by_edge: dict[tuple[int, int], tuple[int, int, int]] = {}

    def point_tag(source_id: int) -> int:
        tag = point_by_source.get(source_id)
        if tag is None:
            tag = int(
                gmsh.model.occ.addPoint(*prepared.coordinates[source_id])
            )
            point_by_source[source_id] = tag
        return tag

    def oriented_curve(first: int, second: int) -> int:
        key = _edge_key(first, second)
        stored = curve_by_edge.get(key)
        if stored is None:
            tag = int(
                gmsh.model.occ.addLine(point_tag(first), point_tag(second))
            )
            curve_by_edge[key] = (tag, first, second)
            return tag
        tag, stored_first, stored_second = stored
        if (first, second) == (stored_first, stored_second):
            return tag
        if (first, second) == (stored_second, stored_first):
            return -tag
        raise AssertionError("OCC curve edge registry is inconsistent")

    def curve_loop(nodes: Sequence[int]) -> int:
        curves = tuple(
            oriented_curve(first, second)
            for first, second in zip(nodes, (*nodes[1:], nodes[0]))
        )
        return int(gmsh.model.occ.addCurveLoop(curves))

    def plane_surface(facet: Sequence[int]) -> int:
        return int(gmsh.model.occ.addPlaneSurface([curve_loop(facet)]))

    base_surface = int(
        gmsh.model.occ.addPlaneSurface(
            [curve_loop(base_loops[0]), curve_loop(base_loops[1])]
        )
    )
    cap_surface = int(
        gmsh.model.occ.addPlaneSurface(
            [curve_loop(cap_loops[0]), curve_loop(cap_loops[1])]
        )
    )
    outer_surfaces = tuple(
        plane_surface(facet) for facet in correspondence.outer_facets
    )
    # Every inner ruled facet lies on exactly one rectangular die-wall plane
    # (proved by _validate_ruled_strip).  Internal zipper diagonals express the
    # correspondence proof, not mandatory CAD seams.  Merge each coplanar wall
    # strip into one surface so a connected locked die-wall patch maps to one
    # OCC surface instead of being split once per correspondence triangle.
    envelope = prepared.envelope
    die_planes = (
        ("die_x_min", 0, envelope.center_x - envelope.half_die_width),
        ("die_x_max", 0, envelope.center_x + envelope.half_die_width),
        ("die_y_min", 1, envelope.center_y - envelope.half_die_length),
        ("die_y_max", 1, envelope.center_y + envelope.half_die_length),
    )
    inner_by_side: dict[str, list[tuple[int, ...]]] = {
        side: [] for side, _axis, _value in die_planes
    }
    for facet in correspondence.inner_facets:
        side = next(
            (
                name
                for name, axis, value in die_planes
                if all(
                    abs(prepared.coordinates[node][axis] - value)
                    <= _COORDINATE_TOLERANCE_MM
                    for node in facet
                )
            ),
            None,
        )
        if side is None:  # pragma: no cover - correspondence validation guards it
            raise AssertionError("inner ruled facet escaped the die walls")
        inner_by_side[side].append(facet)
    inner_surfaces: list[int] = []
    for side, _axis, _value in die_planes:
        facets = tuple(inner_by_side[side])
        if not facets:
            raise ConstrainedHybridError(
                "two-boundary inner ruled loft does not cover all four die walls"
            )
        loops = _boundary_loops(facets)
        if len(loops) != 1:
            raise ConstrainedHybridError(
                f"two-boundary inner ruled {side} is not one planar strip"
            )
        inner_surfaces.append(plane_surface(loops[0]))
    shell = int(
        gmsh.model.occ.addSurfaceLoop(
            [base_surface, cap_surface, *outer_surfaces, *inner_surfaces],
            sewing=False,
        )
    )
    volume_tag = int(gmsh.model.occ.addVolume([shell]))
    return volume_tag, _analytic_slice_volume(prepared)


def _add_geometry_authority_uf_slice(
    gmsh: Any,
    prepared: _PreparedInput,
    correspondence: _PreparedRuledCorrespondence | None = None,
    *,
    force_partial_locked_sides: Sequence[str] = (),
) -> tuple[int, float, str]:
    forced = frozenset(force_partial_locked_sides)
    complete_base = (
        None
        if "base" in forced
        else _complete_annulus_loops(
            prepared.base_patch,
            prepared.coordinates,
            prepared.envelope,
            tolerance_mm=prepared.geometry_tolerance_mm,
        )
    )
    complete_cap = (
        None
        if "cap" in forced
        else _complete_annulus_loops(
            prepared.cap_patch,
            prepared.coordinates,
            prepared.envelope,
            tolerance_mm=prepared.geometry_tolerance_mm,
        )
    )
    if complete_base is not None and complete_cap is not None:
        if correspondence is None:
            raise ConstrainedHybridError(
                "complete locked UF base and cap cannot both be geometry "
                "authorities; an explicit two-boundary correspondence is "
                "required"
            )
        volume_tag, analytic_volume = (
            _add_authoritative_two_boundary_uf_slice(
                gmsh,
                prepared,
                correspondence,
            )
        )
        return (
            volume_tag,
            analytic_volume,
            "locked_base_and_cap_annuli_with_verified_ruled_correspondence",
        )
    if correspondence is not None:
        raise ConstrainedHybridError(
            "two-boundary correspondence requires both complete locked annuli"
        )
    if complete_base is not None:
        volume_tag, analytic_volume = _add_authoritative_base_uf_slice(
            gmsh,
            prepared,
        )
        geometry_authority = (
            "locked_base_annulus_to_zero_width_apex"
            if _slice_radius(prepared.envelope, prepared.z_max)
            <= _COORDINATE_TOLERANCE_MM
            else "locked_base_annulus_to_analytic_cap"
        )
        return (
            volume_tag,
            analytic_volume,
            geometry_authority,
        )
    if complete_cap is not None:
        volume_tag, analytic_volume = _add_authoritative_cap_uf_slice(
            gmsh,
            prepared,
        )
        return (
            volume_tag,
            analytic_volume,
            "locked_cap_annulus_to_analytic_base",
        )
    volume_tag, analytic_volume = _add_exact_uf_slice(gmsh, prepared)
    partial = tuple(
        side
        for side, patch in (
            ("base", prepared.base_patch),
            ("cap", prepared.cap_patch),
        )
        if patch is not None
    )
    authority = (
        "analytic_envelope"
        if not partial
        else "analytic_envelope_with_partial_locked_" + "_and_".join(partial)
    )
    return volume_tag, analytic_volume, authority


def _add_exact_uf_slice(
    gmsh: Any,
    prepared: _PreparedInput,
) -> tuple[int, float]:
    envelope = prepared.envelope
    x_half = envelope.half_die_width
    y_half = envelope.half_die_length
    center_x = envelope.center_x
    center_y = envelope.center_y
    x_min = center_x - x_half
    x_max = center_x + x_half
    y_min = center_y - y_half
    y_max = center_y + y_half
    z_min = prepared.z_min
    z_max = prepared.z_max
    height = z_max - z_min
    bottom_radius = _slice_radius(envelope, z_min)
    top_radius = max(0.0, _slice_radius(envelope, z_max))
    if bottom_radius <= _COORDINATE_TOLERANCE_MM:
        raise ConstrainedHybridError("direct UF slice has zero plan-view width")

    def side_section(points: Sequence[Point3D]) -> tuple[Point3D, ...]:
        if top_radius <= _COORDINATE_TOLERANCE_MM:
            return (points[0], points[1], points[3])
        return tuple(points)

    volumes = [
        _add_prism(
            gmsh,
            side_section(
                (
                    (x_max, y_min, z_min),
                    (x_max + bottom_radius, y_min, z_min),
                    (x_max + top_radius, y_min, z_max),
                    (x_max, y_min, z_max),
                )
            ),
            (0.0, envelope.die_length, 0.0),
        ),
        _add_prism(
            gmsh,
            side_section(
                (
                    (x_min - bottom_radius, y_min, z_min),
                    (x_min, y_min, z_min),
                    (x_min, y_min, z_max),
                    (x_min - top_radius, y_min, z_max),
                )
            ),
            (0.0, envelope.die_length, 0.0),
        ),
        _add_prism(
            gmsh,
            side_section(
                (
                    (x_min, y_max, z_min),
                    (x_min, y_max + bottom_radius, z_min),
                    (x_min, y_max + top_radius, z_max),
                    (x_min, y_max, z_max),
                )
            ),
            (envelope.die_width, 0.0, 0.0),
        ),
        _add_prism(
            gmsh,
            side_section(
                (
                    (x_min, y_min - bottom_radius, z_min),
                    (x_min, y_min, z_min),
                    (x_min, y_min, z_max),
                    (x_min, y_min - top_radius, z_max),
                )
            ),
            (envelope.die_width, 0.0, 0.0),
        ),
    ]
    for corner_x, corner_y, rotation in (
        (x_max, y_max, 0.0),
        (x_min, y_max, 0.5 * math.pi),
        (x_min, y_min, math.pi),
        (x_max, y_min, 1.5 * math.pi),
    ):
        cone = int(
            gmsh.model.occ.addCone(
                corner_x,
                corner_y,
                z_min,
                0.0,
                0.0,
                height,
                bottom_radius,
                top_radius,
                angle=0.5 * math.pi,
            )
        )
        if rotation:
            gmsh.model.occ.rotate(
                [(3, cone)],
                corner_x,
                corner_y,
                z_min,
                0.0,
                0.0,
                1.0,
                rotation,
            )
        volumes.append(cone)
    fused, _maps = gmsh.model.occ.fuse(
        [(3, volumes[0])],
        [(3, tag) for tag in volumes[1:]],
        removeObject=True,
        removeTool=True,
    )
    volume_tags = tuple(
        int(tag) for dimension, tag in fused if int(dimension) == 3
    )
    if len(volume_tags) != 1:
        raise ConstrainedHybridError("OCC did not fuse the analytic UF into one volume")
    return volume_tags[0], _analytic_slice_volume(prepared)


def _projected_loop_area(
    side: str,
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> float:
    if side in {"base", "cap"}:
        first_axis, second_axis = 0, 1
    elif side.startswith("die_x"):
        first_axis, second_axis = 1, 2
    else:
        first_axis, second_axis = 0, 2
    return 0.5 * math.fsum(
        coordinates[loop[index]][first_axis]
        * coordinates[loop[(index + 1) % len(loop)]][second_axis]
        - coordinates[loop[(index + 1) % len(loop)]][first_axis]
        * coordinates[loop[index]][second_axis]
        for index in range(len(loop))
    )


def _add_locked_patch_surface(
    gmsh: Any,
    prepared: _PreparedInput,
    patch: _PreparedLockedPatch,
) -> int:
    ordered_loops = tuple(
        sorted(
            patch.boundary_loops,
            key=lambda loop: abs(
                _projected_loop_area(patch.side, loop, prepared.coordinates)
            ),
            reverse=True,
        )
    )
    wire_tags: list[int] = []
    for loop in ordered_loops:
        point_tags = tuple(
            int(gmsh.model.occ.addPoint(*prepared.coordinates[node]))
            for node in loop
        )
        curves = tuple(
            int(gmsh.model.occ.addLine(first, second))
            for first, second in zip(
                point_tags,
                (*point_tags[1:], point_tags[0]),
            )
        )
        wire_tags.append(int(gmsh.model.occ.addCurveLoop(curves)))
    return int(gmsh.model.occ.addPlaneSurface(wire_tags))


def _facet_boundary_edges(
    facets: Sequence[Sequence[int]],
) -> set[tuple[int, int]]:
    counts: Counter[tuple[int, int]] = Counter(
        _edge_key(first, second)
        for facet in facets
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    return {edge for edge, count in counts.items() if count == 1}


def _curve_source_chain(
    gmsh: Any,
    curve_tag: int,
    expected_edges: set[tuple[int, int]],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[float, int], ...]:
    bounds = gmsh.model.getBoundingBox(1, curve_tag)
    boundary_nodes = {node for edge in expected_edges for node in edge}
    candidates: list[tuple[float, int]] = []
    for source_id in boundary_nodes:
        point = coordinates[source_id]
        if not all(
            bounds[axis] - _OCC_TOLERANCE_MM
            <= point[axis]
            <= bounds[axis + 3] + _OCC_TOLERANCE_MM
            for axis in range(3)
        ):
            continue
        try:
            parameter = float(
                gmsh.model.getParametrization(1, curve_tag, list(point))[0]
            )
            closest, _ = gmsh.model.getClosestPoint(1, curve_tag, list(point))
        except Exception:
            continue
        if math.dist(
            point,
            tuple(float(closest[index]) for index in range(3)),
        ) <= _OCC_TOLERANCE_MM:
            candidates.append((parameter, source_id))
    ordered = tuple(sorted(candidates))
    chain = tuple(source_id for _parameter, source_id in ordered)
    actual_edges = {
        _edge_key(first, second) for first, second in zip(chain, chain[1:])
    }
    if len(chain) < 2 or not actual_edges or not actual_edges.issubset(
        expected_edges
    ):
        raise ConstrainedHybridError(
            "could not match a locked UF OCC curve to source edges"
        )
    return ordered


def _install_locked_curves(
    gmsh: Any,
    prepared: _PreparedInput,
    surface_by_patch: Mapping[int, int],
) -> None:
    expected_edges = set().union(
        *(
            _facet_boundary_edges(patch.facets)
            for patch_index, patch in enumerate(prepared.patches)
            if patch_index in surface_by_patch
        )
    )
    curve_tags = {
        int(tag)
        for surface_tag in surface_by_patch.values()
        for dimension, tag in gmsh.model.getBoundary(
            [(2, surface_tag)], oriented=False, recursive=False
        )
        if int(dimension) == 1
    }
    gmsh.model.mesh.generate(1)
    gmsh.model.mesh.clear([(1, tag) for tag in sorted(curve_tags)])
    next_node = int(gmsh.model.mesh.getMaxNodeTag()) + 1
    next_element = int(gmsh.model.mesh.getMaxElementTag()) + 1
    by_coordinate = {
        _coordinate_key(point): tag for tag, point in _all_nodes(gmsh).items()
    }
    installed_edges: set[tuple[int, int]] = set()
    for curve_tag in sorted(curve_tags):
        ordered = _curve_source_chain(
            gmsh,
            curve_tag,
            expected_edges,
            prepared.coordinates,
        )
        line_nodes: list[int] = []
        new_tags: list[int] = []
        new_coordinates: list[float] = []
        new_parameters: list[float] = []
        for parameter, source_id in ordered:
            point = prepared.coordinates[source_id]
            key = _coordinate_key(point)
            node_tag = by_coordinate.get(key)
            if node_tag is None:
                node_tag = next_node
                next_node += 1
                by_coordinate[key] = node_tag
                new_tags.append(node_tag)
                new_coordinates.extend(point)
                new_parameters.append(parameter)
            line_nodes.append(node_tag)
        if new_tags:
            gmsh.model.mesh.addNodes(
                1,
                curve_tag,
                new_tags,
                new_coordinates,
                new_parameters,
            )
        element_tags = list(
            range(next_element, next_element + len(line_nodes) - 1)
        )
        next_element += len(element_tags)
        gmsh.model.mesh.addElementsByType(
            curve_tag,
            1,
            element_tags,
            [node for pair in zip(line_nodes, line_nodes[1:]) for node in pair],
        )
        chain = tuple(source_id for _parameter, source_id in ordered)
        installed_edges.update(
            _edge_key(first, second) for first, second in zip(chain, chain[1:])
        )
    if installed_edges != expected_edges:
        missing_edges = expected_edges.difference(installed_edges)
        extra_edges = installed_edges.difference(expected_edges)
        raise ConstrainedHybridError(
            "OCC did not preserve every locked UF boundary edge: "
            f"expected={len(expected_edges)}, installed={len(installed_edges)}, "
            f"missing={len(missing_edges)}, extra={len(extra_edges)}, "
            f"missing_sample={sorted(missing_edges)[:4]!r}"
        )
    gmsh.model.mesh.generate(1)


def _oriented_facet(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
    outward: Point3D,
) -> tuple[int, ...]:
    normal = _normal(*(coordinates[node] for node in facet[:3]))
    if math.fsum(normal[index] * outward[index] for index in range(3)) < 0.0:
        return tuple(reversed(facet))
    return tuple(facet)


def _replace_locked_surfaces(
    gmsh: Any,
    prepared: _PreparedInput,
    surface_by_patch: Mapping[int, int],
) -> None:
    gmsh.model.mesh.clear(
        [(2, surface_tag) for surface_tag in surface_by_patch.values()]
    )
    by_coordinate = {
        _coordinate_key(point): tag for tag, point in _all_nodes(gmsh).items()
    }
    next_node = int(gmsh.model.mesh.getMaxNodeTag()) + 1
    next_element = int(gmsh.model.mesh.getMaxElementTag()) + 1
    gmsh_tag_by_source: dict[int, int] = {}
    for patch_index, surface_tag in surface_by_patch.items():
        patch = prepared.patches[patch_index]
        source_ids = sorted({node for facet in patch.facets for node in facet})
        new_tags: list[int] = []
        new_coordinates: list[float] = []
        for source_id in source_ids:
            point = prepared.coordinates[source_id]
            node_tag = by_coordinate.get(_coordinate_key(point))
            if node_tag is None:
                node_tag = next_node
                next_node += 1
                by_coordinate[_coordinate_key(point)] = node_tag
                new_tags.append(node_tag)
                new_coordinates.extend(point)
            gmsh_tag_by_source[source_id] = node_tag
        if new_tags:
            gmsh.model.mesh.addNodes(2, surface_tag, new_tags, new_coordinates)
        oriented = tuple(
            _oriented_facet(facet, prepared.coordinates, patch.outward)
            for facet in patch.facets
        )
        for node_count, gmsh_type in ((3, _TRI3), (4, _QUAD4)):
            block = tuple(facet for facet in oriented if len(facet) == node_count)
            if not block:
                continue
            element_tags = list(range(next_element, next_element + len(block)))
            next_element += len(block)
            gmsh.model.mesh.addElementsByType(
                surface_tag,
                gmsh_type,
                element_tags,
                [gmsh_tag_by_source[node] for facet in block for node in facet],
            )
    if set(gmsh_tag_by_source) != set(prepared.coordinates):
        raise ConstrainedHybridError(
            "OCC locked UF surfaces did not classify every source node"
        )
    _surface_shell_is_watertight(gmsh)


def _extract_candidate(gmsh: Any, volume_tag: int, seed: int) -> _RawCandidate:
    coordinates = _all_nodes(gmsh)
    raw_types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
        3, volume_tag
    )
    elements: list[tuple[int, int, tuple[int, ...]]] = []
    quality_tags: list[int] = []
    for raw_type, raw_tags, raw_connectivity in zip(
        raw_types, tag_blocks, connectivity_blocks
    ):
        gmsh_type = int(raw_type)
        if gmsh_type not in _SUPPORTED_VOLUME_TYPES:
            raise ConstrainedHybridError(
                f"Gmsh produced unsupported direct UF volume type {gmsh_type}"
            )
        node_count = ELEMENT_SPECS[gmsh_type][1]
        connectivity = tuple(int(node) for node in raw_connectivity)
        if len(connectivity) != node_count * len(raw_tags):
            raise ConstrainedHybridError("Gmsh UF connectivity is inconsistent")
        for index, raw_tag in enumerate(raw_tags):
            start = index * node_count
            elements.append(
                (
                    gmsh_type,
                    int(raw_tag),
                    connectivity[start : start + node_count],
                )
            )
            quality_tags.append(int(raw_tag))
    if not elements:
        raise ConstrainedHybridError("Gmsh produced an empty direct UF volume")
    metrics = {}
    for name in ("minDetJac", "minSICN", "minSIGE", "minSJ"):
        with candidate_stage(f"quality/{name}"):
            metrics[name] = tuple(
                float(value)
                for value in gmsh.model.mesh.getElementQualities(quality_tags, name)
            )
    if any(len(values) != len(elements) for values in metrics.values()):
        raise ConstrainedHybridError("Gmsh returned inconsistent UF quality arrays")
    return _RawCandidate(
        coordinates=MappingProxyType(coordinates),
        elements=tuple(elements),
        determinants=metrics["minDetJac"],
        sicn=metrics["minSICN"],
        sige=metrics["minSIGE"],
        scaled_jacobian=metrics["minSJ"],
        duplicate_node_count=len(tuple(gmsh.model.mesh.getDuplicateNodes())),
        seed=seed,
    )


def _mesh_candidate(
    gmsh: Any,
    prepared: _PreparedInput,
    correspondence: _PreparedRuledCorrespondence | None,
    *,
    target_size: float,
    near_size: float,
    transition_distance: float,
    optimization_rounds: int,
    seed: int,
    algorithm_3d: int,
    verbose: bool,
    thread_count: int | None = None,
    swept_root=None,
) -> tuple[_RawCandidate, float, float, str, str]:
    # Explicit override is private and used only by the diagnostic benchmark.
    threads = DIRECT_VOLUME_THREADS_BY_ALGORITHM[algorithm_3d] if thread_count is None else thread_count
    if type(threads) is not int or threads < 1:
        raise ValueError("Gmsh candidate thread count must be a positive integer")
    options = {
        "General.NumThreads": float(threads),
        "Mesh.MaxNumThreads1D": float(threads),
        "Mesh.MaxNumThreads2D": float(threads),
        "Mesh.MaxNumThreads3D": float(threads),
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm": 6.0,
        "Mesh.Algorithm3D": float(algorithm_3d),
        "Mesh.MeshOnlyEmpty": 1.0,
        "Mesh.MeshSizeMin": near_size,
        "Mesh.MeshSizeMax": target_size,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
        "Mesh.Optimize": 1.0 if optimization_rounds else 0.0,
        "Mesh.OptimizePyramids": 1.0,
        "Mesh.RandomSeed": float(seed),
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_occ_uf_conformal",
        number_options=options,
    ):
        actual_threads = {
            name: int(gmsh.option.getNumber(name))
            for name in ("General.NumThreads", "Mesh.MaxNumThreads1D",
                         "Mesh.MaxNumThreads2D", "Mesh.MaxNumThreads3D")
        }
        emit_candidate_event({
            "stage": "thread_configuration", "state": "configured",
            "algorithm_3d": algorithm_3d, "thread_options": actual_threads,
            "detail": f"algorithm_3d={algorithm_3d}, threads={actual_threads['General.NumThreads']}",
        })
        geometry_started = time.monotonic()
        emit_candidate_event({"stage": "geometry", "state": "started"})
        if swept_root is None:
            volume_tag, analytic_volume, geometry_authority = _add_geometry_authority_uf_slice(gmsh, prepared, correspondence)
        else:
            from .package_v2_swept_fillet import occ_add, volume
            volume_tag, = occ_add(gmsh, swept_root)
            analytic_volume = volume(swept_root)
            geometry_authority = "elliptical_cross_section_sweep"
        patch_surfaces = tuple(
            _add_locked_patch_surface(gmsh, prepared, patch)
            for patch in prepared.patches
        )
        surface_by_patch: dict[int, int] = {}
        if patch_surfaces:
            _outputs, maps = gmsh.model.occ.fragment(
                [(3, volume_tag)],
                [(2, surface) for surface in patch_surfaces],
                removeObject=True,
                removeTool=True,
            )
            gmsh.model.occ.synchronize()
            volumes = tuple(
                int(tag) for dimension, tag in gmsh.model.getEntities(3)
            )
            if len(volumes) != 1:
                raise ConstrainedHybridError(
                    "locked boundary imprints split the UF into multiple volumes"
                )
            volume_tag = volumes[0]
            boundary_surfaces = {
                int(tag)
                for dimension, tag in gmsh.model.getBoundary(
                    [(3, volume_tag)], oriented=False, recursive=False
                )
                if int(dimension) == 2
            }
            detached_surfaces = {
                int(tag)
                for dimension, tag in gmsh.model.getEntities(2)
                if int(dimension) == 2 and int(tag) not in boundary_surfaces
            }
            if detached_surfaces:
                gmsh.model.occ.remove(
                    [(2, tag) for tag in sorted(detached_surfaces)],
                    recursive=True,
                )
                gmsh.model.occ.synchronize()
            if len(maps) != 1 + len(prepared.patches):
                raise ConstrainedHybridError(
                    "OCC returned inconsistent locked UF boundary maps"
                )
            for patch_index, (patch, mapping) in enumerate(
                zip(prepared.patches, maps[1:])
            ):
                mapped = {
                    int(tag)
                    for dimension, tag in mapping
                    if int(dimension) == 2 and int(tag) in boundary_surfaces
                }
                if len(mapped) != 1:
                    raise ConstrainedHybridError(
                        f"locked UF side {patch.side} component "
                        f"{patch.component_index} did not map to one surface"
                    )
                surface_by_patch[patch_index] = mapped.pop()
            _install_locked_curves(gmsh, prepared, surface_by_patch)
        else:
            gmsh.model.occ.synchronize()

        cad_volume = float(gmsh.model.occ.getMass(3, volume_tag))
        cad_error = abs(cad_volume - analytic_volume) / analytic_volume
        if (
            not math.isfinite(cad_volume)
            or cad_volume <= 0.0
            or (
                (geometry_authority.startswith("analytic_envelope") or swept_root is not None)
                and cad_error > 1.0e-8
            )
        ):
            raise ConstrainedHybridError(
                f"OCC UF volume differs from the analytic fillet by {cad_error:.3g}"
            )

        if surface_by_patch and near_size < target_size:
            distance = int(gmsh.model.mesh.field.add("Distance"))
            gmsh.model.mesh.field.setNumbers(
                distance,
                "SurfacesList",
                list(surface_by_patch.values()),
            )
            threshold = int(gmsh.model.mesh.field.add("Threshold"))
            for name, value in (
                ("InField", distance),
                ("SizeMin", near_size),
                ("SizeMax", target_size),
                ("DistMin", 0.0),
                ("DistMax", transition_distance),
            ):
                gmsh.model.mesh.field.setNumber(threshold, name, value)
            gmsh.model.mesh.field.setAsBackgroundMesh(threshold)
            field_kind = "Distance+Threshold"
        else:
            field = int(gmsh.model.mesh.field.add("MathEval"))
            gmsh.model.mesh.field.setString(field, "F", f"{target_size:.17g}")
            gmsh.model.mesh.field.setAsBackgroundMesh(field)
            field_kind = "MathEvalConstant"

        emit_candidate_event({"stage": "geometry", "state": "completed",
                              "elapsed_seconds": time.monotonic() - geometry_started})
        with candidate_stage("generate_2d"):
            gmsh.model.mesh.generate(2)
        if surface_by_patch:
            _replace_locked_surfaces(gmsh, prepared, surface_by_patch)
        try:
            with candidate_stage("generate_3d_including_implicit_optimization"):
                gmsh.model.mesh.generate(3)
        except Exception as error:
            raise ConstrainedHybridError(
                "Gmsh could not fill the direct analytic UF geometry"
            ) from error
        # A ruled authority shell can contain coincident CAD vertices where
        # several projected staircase points collapse onto one analytic cap
        # point.  Let Gmsh merge those classifications and update its own
        # connectivity before quality extraction.
        if tuple(gmsh.model.mesh.getDuplicateNodes()):
            gmsh.model.mesh.removeDuplicateNodes()
        candidate = _extract_candidate(gmsh, volume_tag, seed)
        emit_quality_snapshot(candidate, 0, phase="生成后")
        for _iteration in range(optimization_rounds):
            with candidate_stage(f"optimize/{_iteration + 1}/Relocate3D"):
                gmsh.model.mesh.optimize(
                    "Relocate3D", force=True, niter=3, dimTags=[(3, volume_tag)]
                )
            with candidate_stage(f"optimize/{_iteration + 1}/default"):
                gmsh.model.mesh.optimize(
                    "", force=True, niter=50, dimTags=[(3, volume_tag)]
                )
            candidate = _extract_candidate(gmsh, volume_tag, seed)
            emit_quality_snapshot(candidate, _iteration + 1)
        return (
            candidate,
            cad_volume,
            analytic_volume,
            field_kind,
            geometry_authority,
        )


def _tetra_volume(
    first: Point3D,
    second: Point3D,
    third: Point3D,
    fourth: Point3D,
) -> float:
    ab = tuple(second[index] - first[index] for index in range(3))
    ac = tuple(third[index] - first[index] for index in range(3))
    ad = tuple(fourth[index] - first[index] for index in range(3))
    cross = (
        ac[1] * ad[2] - ac[2] * ad[1],
        ac[2] * ad[0] - ac[0] * ad[2],
        ac[0] * ad[1] - ac[1] * ad[0],
    )
    return abs(math.fsum(ab[index] * cross[index] for index in range(3))) / 6.0


def _element_volume(
    element: GmshUfVolumeElement,
    coordinates: Mapping[int, Point3D],
) -> float:
    points = tuple(coordinates[node] for node in element.node_ids)
    if element.gmsh_type == _TET4:
        return _tetra_volume(*points)  # type: ignore[arg-type]
    if element.gmsh_type == _PYRAMID5:
        return _tetra_volume(points[0], points[1], points[2], points[4]) + _tetra_volume(
            points[0], points[2], points[3], points[4]
        )
    return math.fsum(
        (
            _tetra_volume(points[0], points[1], points[2], points[3]),
            _tetra_volume(points[1], points[2], points[4], points[3]),
            _tetra_volume(points[2], points[4], points[5], points[3]),
        )
    )


def _on_die_wall(
    cycle: Sequence[int],
    coordinates: Mapping[int, Point3D],
    envelope: RectangularUfEnvelope,
) -> bool:
    points = tuple(coordinates[node] for node in cycle)
    tolerance = _OCC_TOLERANCE_MM
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    return any(
        all(
            abs(point[axis] - value) <= tolerance
            and tangent_min - tolerance
            <= point[tangent_axis]
            <= tangent_max + tolerance
            and envelope.base_z - tolerance
            <= point[2]
            <= envelope.apex_z + tolerance
            for point in points
        )
        for axis, value, tangent_axis, tangent_min, tangent_max in (
            (0, x_min, 1, y_min, y_max),
            (0, x_max, 1, y_min, y_max),
            (1, y_min, 0, x_min, x_max),
            (1, y_max, 0, x_min, x_max),
        )
    )


def _finalize_candidate(
    candidate: _RawCandidate,
    prepared: _PreparedInput,
    cad_volume: float,
    analytic_volume: float,
    field_kind: str,
    geometry_authority: str,
    *,
    target_size: float,
    near_size: float,
    transition_distance: float,
    minimum_quality: float,
    algorithm_3d: int,
    swept_root=None,
) -> GmshUfConformalVolume:
    if candidate.duplicate_node_count:
        raise ConstrainedHybridError("Gmsh produced duplicate direct UF nodes")
    if any(
        not math.isfinite(value) or value <= 0.0 for value in candidate.determinants
    ):
        raise ConstrainedHybridError("direct UF mesh contains a non-positive element")
    metrics = (candidate.sicn, candidate.sige, candidate.scaled_jacobian)
    if any(not math.isfinite(value) for values in metrics for value in values):
        raise ConstrainedHybridError("direct UF mesh quality is non-finite")
    if any(min(values) < minimum_quality for values in metrics):
        worst_rows: list[str] = []
        for metric_name, values in (
            ("minSICN", candidate.sicn),
            ("minSIGE", candidate.sige),
            ("minSJ", candidate.scaled_jacobian),
        ):
            index = min(
                range(len(values)),
                key=lambda value: (values[value], candidate.elements[value][1]),
            )
            gmsh_type, tag, nodes = candidate.elements[index]
            centroid = tuple(
                math.fsum(candidate.coordinates[node][axis] for node in nodes)
                / len(nodes)
                for axis in range(3)
            )
            worst_rows.append(
                f"{metric_name}=(value={values[index]:.8g},type={gmsh_type},"
                f"tag={tag},centroid_mm={centroid!r})"
            )
        raise ConstrainedHybridError(
            "direct UF quality floor was not met: "
            f"minSJ={min(candidate.scaled_jacobian):.8g}, "
            f"minSICN={min(candidate.sicn):.8g}, "
            f"minSIGE={min(candidate.sige):.8g}, "
            f"worst=({', '.join(worst_rows)}), "
            f"required={minimum_quality:.8g}"
        )

    gmsh_by_coordinate: dict[tuple[float, float, float], int] = {}
    for gmsh_tag, point in candidate.coordinates.items():
        key = _coordinate_key(point)
        if key in gmsh_by_coordinate:
            raise ConstrainedHybridError("direct UF mesh has coincident nodes")
        gmsh_by_coordinate[key] = gmsh_tag
    gmsh_source_by_tag: dict[int, int] = {}
    for source_id, point in prepared.coordinates.items():
        gmsh_tag = gmsh_by_coordinate.get(_coordinate_key(point))
        if gmsh_tag is None or math.dist(candidate.coordinates[gmsh_tag], point) > (
            _COORDINATE_TOLERANCE_MM
        ):
            raise ConstrainedHybridError("Gmsh changed a locked UF node")
        gmsh_source_by_tag[gmsh_tag] = source_id

    ordered_gmsh = tuple(
        sorted(
            candidate.coordinates,
            key=lambda tag: (_coordinate_key(candidate.coordinates[tag]), tag),
        )
    )
    local_by_gmsh = {
        gmsh_tag: local_id
        for local_id, gmsh_tag in enumerate(ordered_gmsh, start=1)
    }
    coordinates = {
        local_by_gmsh[tag]: candidate.coordinates[tag] for tag in ordered_gmsh
    }
    source_by_local = {
        local_by_gmsh[gmsh_tag]: source_id
        for gmsh_tag, source_id in gmsh_source_by_tag.items()
    }
    elements = tuple(
        sorted(
            (
                GmshUfVolumeElement(
                    gmsh_type,
                    tuple(local_by_gmsh[node] for node in nodes),
                )
                for gmsh_type, _tag, nodes in candidate.elements
            ),
            key=lambda element: (
                element.gmsh_type,
                tuple(sorted(element.node_ids)),
                element.node_ids,
            ),
        )
    )
    duplicate_elements = len(elements) - len(
        {(element.gmsh_type, _face_key(element.node_ids)) for element in elements}
    )
    if duplicate_elements:
        raise ConstrainedHybridError("Gmsh produced duplicate direct UF elements")

    owners: dict[FaceKey, list[tuple[int, int, tuple[int, ...]]]] = defaultdict(list)
    for element_index, element in enumerate(elements):
        for face_index, local_face in enumerate(ELEMENT_SPECS[element.gmsh_type][2]):
            cycle = tuple(element.node_ids[index] for index in local_face)
            owners[_face_key(cycle)].append((element_index, face_index, cycle))
    if any(len(face_owners) not in {1, 2} for face_owners in owners.values()):
        raise ConstrainedHybridError("direct UF mesh contains a non-manifold face")
    boundary = {
        key: face_owners[0][2]
        for key, face_owners in owners.items()
        if len(face_owners) == 1
    }

    local_by_source = {source: local for local, source in source_by_local.items()}
    locked_local_lists: dict[str, list[tuple[int, ...]]] = defaultdict(list)
    locked_triangle_count = 0
    locked_quad_count = 0
    for patch in prepared.patches:
        mapped_facets: list[tuple[int, ...]] = []
        for facet in patch.facets:
            local_facet = tuple(local_by_source[node] for node in facet)
            key = _face_key(local_facet)
            face_owners = owners.get(key, ())
            if len(face_owners) != 1:
                raise ConstrainedHybridError(
                    f"locked UF {patch.side} facet does not have one volume owner"
                )
            owner = elements[face_owners[0][0]]
            if len(facet) == 3:
                if owner.gmsh_type not in {_TET4, _WEDGE6, _PYRAMID5}:
                    raise ConstrainedHybridError(
                        "locked UF TRI3 has an unsupported transition owner"
                    )
                locked_triangle_count += 1
            else:
                if owner.gmsh_type not in {_WEDGE6, _PYRAMID5}:
                    raise ConstrainedHybridError(
                        "locked UF QUAD4 is not owned by WEDGE6/PYRAMID5"
                    )
                locked_quad_count += 1
            mapped_facets.append(local_facet)
        locked_local_lists[patch.side].extend(mapped_facets)
    locked_local = {
        side: tuple(facets) for side, facets in locked_local_lists.items()
    }

    tolerance = _OCC_TOLERANCE_MM
    base_keys = {
        key
        for key, cycle in boundary.items()
        if all(
            abs(coordinates[node][2] - prepared.z_min) <= tolerance
            for node in cycle
        )
    }
    cap_keys = {
        key
        for key, cycle in boundary.items()
        if all(
            abs(coordinates[node][2] - prepared.z_max) <= tolerance
            for node in cycle
        )
    }
    die_keys = {
        key
        for key, cycle in boundary.items()
        if key not in base_keys
        and key not in cap_keys
        and _on_die_wall(cycle, coordinates, prepared.envelope)
    }
    free_keys = set(boundary).difference(base_keys, cap_keys, die_keys)
    if not base_keys or not die_keys or not free_keys:
        raise ConstrainedHybridError("direct UF boundary classification is incomplete")
    if swept_root is None:
        capped = prepared.z_max < prepared.envelope.apex_z - tolerance
    else:
        from .package_v2_swept_fillet import slice_area
        capped = slice_area(swept_root, 1.) > tolerance*tolerance
    if capped and not cap_keys:
        raise ConstrainedHybridError("capped direct UF slice has no cap facets")
    for key in free_keys:
        for node in key:
            x_value, y_value, z_value = coordinates[node]
            top_height = prepared.envelope.top_height(x_value, y_value)
            if swept_root is not None:
                from .package_v2_swept_fillet import on_outer_surface
                valid = on_outer_surface(swept_root, coordinates[node], 5.0 * _OCC_TOLERANCE_MM)
            elif geometry_authority.startswith("analytic_envelope"):
                valid = abs(z_value - top_height) <= 5.0 * _OCC_TOLERANCE_MM
            elif geometry_authority in {
                "locked_cap_annulus_to_analytic_base",
                "locked_base_and_cap_annuli_with_verified_ruled_correspondence",
            }:
                valid = (
                    prepared.envelope.is_outside_die(x_value, y_value)
                    and prepared.envelope.outside_distance(x_value, y_value)
                    <= _slice_radius(prepared.envelope, prepared.z_min)
                    + 5.0 * _OCC_TOLERANCE_MM
                    and prepared.z_min - 5.0 * _OCC_TOLERANCE_MM
                    <= z_value
                    <= prepared.z_max + 5.0 * _OCC_TOLERANCE_MM
                )
            elif geometry_authority in {
                "locked_base_annulus_to_analytic_cap",
                "locked_base_annulus_to_zero_width_apex",
            }:
                valid = (
                    prepared.envelope.is_outside_die(x_value, y_value)
                    and prepared.envelope.outside_distance(x_value, y_value)
                    <= _locked_base_maximum_outside_distance(prepared)
                    + 5.0 * _OCC_TOLERANCE_MM
                    and prepared.z_min - 5.0 * _OCC_TOLERANCE_MM
                    <= z_value
                    <= prepared.z_max + 5.0 * _OCC_TOLERANCE_MM
                )
            else:  # pragma: no cover - geometry-authority dispatch is exhaustive
                valid = (
                    prepared.envelope.contains_xy(x_value, y_value)
                    and z_value <= top_height + 5.0 * _OCC_TOLERANCE_MM
                )
            if not valid:
                raise ConstrainedHybridError(
                    "Gmsh free-surface node escaped the negotiated UF geometry"
                )

    classified_by_side = {
        "base": base_keys,
        "cap": cap_keys,
        "die_x_min": die_keys,
        "die_x_max": die_keys,
        "die_y_min": die_keys,
        "die_y_max": die_keys,
    }
    for side, facets in locked_local.items():
        keys = {_face_key(facet) for facet in facets}
        if not keys.issubset(classified_by_side[side]):
            raise ConstrainedHybridError(
                f"Gmsh changed the locked UF {side} facet set"
            )
    authoritative_sides = {
        "locked_base_annulus_to_analytic_cap": "base",
        "locked_base_annulus_to_zero_width_apex": "base",
        "locked_cap_annulus_to_analytic_base": "cap",
        "locked_base_and_cap_annuli_with_verified_ruled_correspondence": (
            "base",
            "cap",
        ),
    }.get(geometry_authority, ())
    if isinstance(authoritative_sides, str):
        authoritative_sides = (authoritative_sides,)
    for authoritative_side in authoritative_sides:
        authoritative_keys = {
            _face_key(facet)
            for facet in locked_local[authoritative_side]
        }
        classified_keys = (
            base_keys if authoritative_side == "base" else cap_keys
        )
        if classified_keys != authoritative_keys:
            raise ConstrainedHybridError(
                f"locked UF {authoritative_side} authority acquired additional "
                "boundary facets"
            )

    element_volume = math.fsum(
        _element_volume(element, coordinates) for element in elements
    )
    element_error = abs(element_volume - cad_volume) / cad_volume
    cad_error = abs(cad_volume - analytic_volume) / analytic_volume
    # OCC keeps the circular corner cones exact, while first-order Gmsh
    # boundary triangles approximate them by chords.  Their element-volume
    # sum therefore converges to, but cannot bit-match, the exact CAD mass.
    # Keep the approximation visible in the result and reject only a material
    # loss of volume (a missing layer/crack is orders of magnitude larger).
    if element_error > 2.0e-2:
        raise ConstrainedHybridError(
            f"direct UF mesh/CAD volume mismatch is {element_error:.3g}"
        )

    ordered_cycles = lambda keys: tuple(boundary[key] for key in sorted(keys))
    return GmshUfConformalVolume(
        node_coordinates=MappingProxyType(coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        elements=elements,
        locked_facets_by_side=MappingProxyType(locked_local),
        base_facets=ordered_cycles(base_keys),
        cap_facets=ordered_cycles(cap_keys),
        die_wall_facets=ordered_cycles(die_keys),
        free_surface_facets=ordered_cycles(free_keys),
        tet4_count=sum(element.gmsh_type == _TET4 for element in elements),
        wedge6_count=sum(element.gmsh_type == _WEDGE6 for element in elements),
        pyramid5_count=sum(element.gmsh_type == _PYRAMID5 for element in elements),
        locked_triangle_count=locked_triangle_count,
        locked_quad_count=locked_quad_count,
        target_size_mm=target_size,
        near_size_mm=near_size,
        transition_distance_mm=transition_distance,
        background_field_kind=field_kind,
        geometry_authority=geometry_authority,
        minimum_sicn=min(candidate.sicn),
        minimum_sige=min(candidate.sige),
        minimum_scaled_jacobian=min(candidate.scaled_jacobian),
        minimum_determinant=min(candidate.determinants),
        duplicate_node_count=candidate.duplicate_node_count,
        duplicate_element_count=duplicate_elements,
        cad_volume_mm3=cad_volume,
        analytic_volume_mm3=analytic_volume,
        element_volume_mm3=element_volume,
        cad_relative_volume_error=cad_error,
        element_relative_volume_error=element_error,
        random_seed=candidate.seed,
        algorithm_3d=algorithm_3d,
    )


def _isolated_mesh_candidate(prepared, correspondence, **kwargs):
    return _mesh_candidate(_load_gmsh(), prepared, correspondence, **kwargs)


@bounded_candidate_search
def generate_rectangular_uf_conformal_hybrid(
    locked_node_coordinates: Mapping[int, Sequence[float]],
    locked_boundary_facets: Mapping[str, Sequence[Sequence[int]]],
    envelope: RectangularUfEnvelope,
    z_min_mm: float,
    z_max_mm: float,
    *,
    target_size_mm: float,
    transition_distance_mm: float,
    near_size_mm: float | None = None,
    two_boundary_correspondence: PlanarAnnulusRuledCorrespondence | None = None,
    minimum_quality: float = 0.03,
    random_seeds: Sequence[int] = (1, 2, 3),
    optimization_rounds: int = 2,
    algorithm_3d: int | None = None,
    interface_geometry_tolerance_mm: float = _COORDINATE_TOLERANCE_MM,
    verbose: bool = False,
    candidate_validator=None,
    swept_root=None,
) -> GmshUfConformalVolume:
    """Mesh a rectangular UF slice directly with OCC/Gmsh.

    ``locked_boundary_facets`` is a geometry-adjacency contract keyed by
    ``base``, ``cap``, ``die_x_min``, ``die_x_max``, ``die_y_min`` or
    ``die_y_max``.  The mapping can be empty: with no QUAD lock to transition,
    Gmsh creates a global TET mesh.  Locked QUADs are retained verbatim and
    Gmsh is allowed to introduce PYRAMID5/WEDGE6 before its TET bulk.

    With no explicit algorithm, QUAD locks use Delaunay; all-TRI or empty
    locks try HXT then Delaunay. The execution context can race those two
    candidates. ``candidate_validator`` must raise to reject a result after
    the local audit (e.g. a failed combined adapter audit), before selection
    and cancellation of the other candidate.

    A complete planar ``base`` or ``cap`` annulus with exactly one die-inner
    loop becomes geometry authority.  Partial patches remain analytic imprints;
    simultaneous complete base/cap authorities require an explicit, validated
    ``two_boundary_correspondence``.  Its ruled strips join the exact endpoint
    loops even when the two annuli use different edge segmentations.

    ``target_size_mm`` and ``transition_distance_mm`` are passed to a Gmsh
    Distance+Threshold background field whenever a finer locked-boundary size
    is requested.  No volume connectivity is created by EasyMesh.

    When ``swept_root`` is supplied, mesh its actual four-side elliptical
    sweep, including collapsed top edges. The envelope only prepares planar
    locks; CAD volume and free vertices are checked against the sweep.
    """

    prepared = _prepare_inputs(
        locked_node_coordinates,
        locked_boundary_facets,
        envelope,
        z_min_mm,
        z_max_mm,
        geometry_tolerance_mm=interface_geometry_tolerance_mm,
    )
    prepared_correspondence = _prepare_ruled_correspondence(
        prepared,
        two_boundary_correspondence,
    )
    target_size = _finite(target_size_mm, name="direct UF target size")
    transition_distance = _finite(
        transition_distance_mm,
        name="direct UF transition distance",
    )
    if near_size_mm is None:
        locked_edges = tuple(
            math.dist(
                prepared.coordinates[first],
                prepared.coordinates[second],
            )
            for patch in prepared.patches
            for facet in patch.facets
            for first, second in zip(facet, (*facet[1:], facet[0]))
        )
        near_size = min(target_size, median(locked_edges)) if locked_edges else target_size
    else:
        near_size = _finite(near_size_mm, name="direct UF near size")
    quality_floor = _finite(minimum_quality, name="direct UF minimum quality")
    if (
        target_size <= 0.0
        or near_size <= 0.0
        or near_size > target_size
        or transition_distance <= 0.0
        or quality_floor <= 0.0
        or quality_floor >= 1.0
    ):
        raise ConstrainedHybridError(
            "direct UF sizes, transition distance or quality floor are invalid"
        )
    try:
        seeds = tuple(dict.fromkeys(tuple(random_seeds)))
    except TypeError as error:
        raise ConstrainedHybridError(
            "direct UF random seeds must be a sequence"
        ) from error
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
        for seed in seeds
    ):
        raise ConstrainedHybridError(
            "direct UF random seeds must be positive integers"
        )
    if (
        isinstance(optimization_rounds, bool)
        or not isinstance(optimization_rounds, int)
        or optimization_rounds < 0
        or optimization_rounds > 4
    ):
        raise ConstrainedHybridError(
            "direct UF optimization rounds must be 0..4"
        )
    if algorithm_3d is not None and (
        isinstance(algorithm_3d, bool)
        or not isinstance(algorithm_3d, int)
        or algorithm_3d not in {1, 4, 10}
    ):
        raise ConstrainedHybridError(
            "direct UF algorithm_3d must be Gmsh Delaunay(1), Frontal(4), "
            "or HXT(10)"
        )

    has_locked_quads = any(len(facet) == 4 for group in prepared.patches for facet in group.facets)
    algorithms = (algorithm_3d,) if algorithm_3d is not None else ((1,) if has_locked_quads else (10, 1))
    failures: list[str] = []

    def choice(algorithm, seed):
        return (
            _isolated_mesh_candidate, (prepared, prepared_correspondence),
            dict(target_size=target_size, near_size=near_size,
                 transition_distance=transition_distance,
                 optimization_rounds=optimization_rounds, seed=seed,
                 algorithm_3d=algorithm, verbose=verbose, swept_root=swept_root),
            f"trial={uuid.uuid4().hex[:12]}/direct_volume/algorithm={algorithm}/seed={seed}",
        )

    def accept(values, label):
        candidate, cad_volume, analytic_volume, field_kind, geometry_authority = values
        algorithm = int(label.split("algorithm=")[1].split("/")[0])
        with candidate_event_context(candidate=label), candidate_stage(f"{label}/audit"):
            result = _finalize_candidate(
                candidate, prepared, cad_volume, analytic_volume,
                field_kind, geometry_authority, target_size=target_size,
                near_size=near_size, transition_distance=transition_distance,
                minimum_quality=quality_floor, algorithm_3d=algorithm,
                swept_root=swept_root,
            )
            if candidate_validator is not None:
                candidate_validator(result)
        return result

    if len(algorithms) == 2 and parallel_tet_candidates_enabled():
        for seed in seeds:
            try:
                return race_isolated_candidates([choice(a, seed) for a in algorithms], accept)
            except CandidateSearchExhausted:
                raise
            except Exception as error:
                failures.append(f"seed {seed}: {error}")
    else:
        for index, algorithm in enumerate(algorithms):
            # HXT must leave time for Delaunay even after multiple bad seeds.
            budget = reserve_fallback_budget() if len(algorithms) == 2 and index == 0 else nullcontext()
            try:
                with budget:
                    for seed in seeds:
                        check_candidate_budget()
                        function, args, kwargs, label = choice(algorithm, seed)
                        try:
                            values = run_isolated_candidate(function, args, kwargs, label=label)
                            result = accept(values, label)
                            check_candidate_budget()
                            emit_candidate_event({"stage": "candidate_selection", "state": "accepted", "candidate": label})
                            return result
                        except CandidateSearchExhausted:
                            raise
                        except Exception as error:
                            failures.append(f"{label}: {error}")
            except CandidateSearchExhausted as error:
                if index == len(algorithms) - 1:
                    raise
                failures.append(f"algorithm {algorithm}: {error}; reserved budget retained for Delaunay")
    raise ConstrainedHybridError(
        f"all direct OCC/Gmsh UF algorithms {algorithms} candidates failed; "
        + "; ".join(failures)
    )


__all__ = [
    "GmshUfConformalVolume",
    "GmshUfVolumeElement",
    "PlanarAnnulusRuledCorrespondence",
    "derive_planar_annulus_ruled_correspondence",
    "generate_rectangular_uf_conformal_hybrid",
]
