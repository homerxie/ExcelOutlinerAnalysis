"""Direct OCC/Gmsh conformal meshing for an axis-aligned rectangular frame.

The frame is an outer rectangular prism with a rectangular through-hole.
Locked TRI3/QUAD4 patches are supplied by geometric side identity.  OpenCASCADE
owns the analytic frame and Gmsh owns every three-dimensional connection; this
module contains no Cartesian fill, cut-cell deletion or hand-built star mesh.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from statistics import median
from types import MappingProxyType
from typing import Any, TypeAlias

from .gmsh_runtime import isolated_gmsh_model
from .occ_locked_hybrid import (
    ConstrainedHybridError,
    _coordinate_key,
    _face_key,
    _finite,
    _load_gmsh,
    _surface_shell_is_watertight,
)
from .occ_uf_conformal import (
    _RawCandidate,
    _boundary_loops,
    _extract_candidate,
    _facets_connected,
    _facet_area,
    _install_locked_curves,
    _replace_locked_surfaces,
)
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]

_TET4 = 4
_WEDGE6 = 6
_PYRAMID5 = 7
_SUPPORTED_VOLUME_TYPES = frozenset({_TET4, _WEDGE6, _PYRAMID5})
_COORDINATE_TOLERANCE = 1.0e-10
_GEOMETRY_TOLERANCE = 1.0e-7

_SIDE_ORDER = (
    "bottom",
    "top",
    "outer_x_min",
    "outer_x_max",
    "outer_y_min",
    "outer_y_max",
    "inner_x_min",
    "inner_x_max",
    "inner_y_min",
    "inner_y_max",
)
_SIDE_SET = frozenset(_SIDE_ORDER)


@dataclass(frozen=True, slots=True)
class RectangularFrameGeometry:
    """Axis-aligned outer and inner XY bounds for a through-frame."""

    outer_x_min: float
    outer_x_max: float
    outer_y_min: float
    outer_y_max: float
    inner_x_min: float
    inner_x_max: float
    inner_y_min: float
    inner_y_max: float

    def __post_init__(self) -> None:
        values = tuple(
            _finite(value, name="rectangular frame bound")
            for value in (
                self.outer_x_min,
                self.outer_x_max,
                self.outer_y_min,
                self.outer_y_max,
                self.inner_x_min,
                self.inner_x_max,
                self.inner_y_min,
                self.inner_y_max,
            )
        )
        if values != (
            self.outer_x_min,
            self.outer_x_max,
            self.outer_y_min,
            self.outer_y_max,
            self.inner_x_min,
            self.inner_x_max,
            self.inner_y_min,
            self.inner_y_max,
        ):
            raise ConstrainedHybridError("rectangular frame bounds are invalid")
        if not (
            self.outer_x_min < self.inner_x_min < self.inner_x_max < self.outer_x_max
            and self.outer_y_min
            < self.inner_y_min
            < self.inner_y_max
            < self.outer_y_max
        ):
            raise ConstrainedHybridError(
                "rectangular frame inner bounds must lie strictly inside outer bounds"
            )

    @property
    def area(self) -> float:
        return (
            (self.outer_x_max - self.outer_x_min)
            * (self.outer_y_max - self.outer_y_min)
            - (self.inner_x_max - self.inner_x_min)
            * (self.inner_y_max - self.inner_y_min)
        )

    def contains_frame_xy(self, x_value: float, y_value: float) -> bool:
        tolerance = _COORDINATE_TOLERANCE
        in_outer = (
            self.outer_x_min - tolerance
            <= x_value
            <= self.outer_x_max + tolerance
            and self.outer_y_min - tolerance
            <= y_value
            <= self.outer_y_max + tolerance
        )
        strictly_in_hole = (
            self.inner_x_min + tolerance < x_value < self.inner_x_max - tolerance
            and self.inner_y_min + tolerance < y_value < self.inner_y_max - tolerance
        )
        return in_outer and not strictly_in_hole


@dataclass(frozen=True, slots=True)
class GmshRectangularFrameElement:
    gmsh_type: int
    node_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        expected = ELEMENT_SPECS.get(self.gmsh_type, (None, 0, ()))[1]
        if self.gmsh_type not in _SUPPORTED_VOLUME_TYPES or len(self.node_ids) != expected:
            raise ConstrainedHybridError(
                "rectangular frame element must be TET4, WEDGE6 or PYRAMID5"
            )
        if len(set(self.node_ids)) != expected:
            raise ConstrainedHybridError(
                "rectangular frame element contains repeated nodes"
            )


@dataclass(frozen=True, slots=True)
class GmshRectangularFrameVolume:
    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    elements: tuple[GmshRectangularFrameElement, ...]
    locked_facets_by_side: Mapping[str, tuple[tuple[int, ...], ...]]
    boundary_facets_by_side: Mapping[str, tuple[tuple[int, ...], ...]]
    tet4_count: int
    wedge6_count: int
    pyramid5_count: int
    locked_triangle_count: int
    locked_quad_count: int
    target_size_mm: float
    near_size_mm: float
    transition_distance_mm: float
    background_field_kind: str
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    minimum_determinant: float
    duplicate_node_count: int
    duplicate_element_count: int
    cad_volume_mm3: float
    element_volume_mm3: float
    relative_volume_error: float
    random_seed: int

    @property
    def node_count(self) -> int:
        return len(self.node_coordinates)

    @property
    def element_count(self) -> int:
        return len(self.elements)

    @property
    def locked_face_count(self) -> int:
        return self.locked_triangle_count + self.locked_quad_count


@dataclass(frozen=True, slots=True)
class _FramePatch:
    side: str
    facets: tuple[tuple[int, ...], ...]
    boundary_loops: tuple[tuple[int, ...], ...]
    outward: Point3D


@dataclass(frozen=True, slots=True)
class _PreparedFrame:
    geometry: RectangularFrameGeometry
    z_min: float
    z_max: float
    coordinates: Mapping[int, Point3D]
    patches: tuple[_FramePatch, ...]


def _outward(side: str) -> Point3D:
    return {
        "bottom": (0.0, 0.0, -1.0),
        "top": (0.0, 0.0, 1.0),
        "outer_x_min": (-1.0, 0.0, 0.0),
        "outer_x_max": (1.0, 0.0, 0.0),
        "outer_y_min": (0.0, -1.0, 0.0),
        "outer_y_max": (0.0, 1.0, 0.0),
        "inner_x_min": (1.0, 0.0, 0.0),
        "inner_x_max": (-1.0, 0.0, 0.0),
        "inner_y_min": (0.0, 1.0, 0.0),
        "inner_y_max": (0.0, -1.0, 0.0),
    }[side]


def _point_on_side(
    side: str,
    point: Point3D,
    geometry: RectangularFrameGeometry,
    z_min: float,
    z_max: float,
) -> bool:
    x_value, y_value, z_value = point
    tolerance = _COORDINATE_TOLERANCE
    if side == "bottom":
        return abs(z_value - z_min) <= tolerance and geometry.contains_frame_xy(
            x_value, y_value
        )
    if side == "top":
        return abs(z_value - z_max) <= tolerance and geometry.contains_frame_xy(
            x_value, y_value
        )
    if not (z_min - tolerance <= z_value <= z_max + tolerance):
        return False
    return {
        "outer_x_min": abs(x_value - geometry.outer_x_min) <= tolerance
        and geometry.outer_y_min - tolerance
        <= y_value
        <= geometry.outer_y_max + tolerance,
        "outer_x_max": abs(x_value - geometry.outer_x_max) <= tolerance
        and geometry.outer_y_min - tolerance
        <= y_value
        <= geometry.outer_y_max + tolerance,
        "outer_y_min": abs(y_value - geometry.outer_y_min) <= tolerance
        and geometry.outer_x_min - tolerance
        <= x_value
        <= geometry.outer_x_max + tolerance,
        "outer_y_max": abs(y_value - geometry.outer_y_max) <= tolerance
        and geometry.outer_x_min - tolerance
        <= x_value
        <= geometry.outer_x_max + tolerance,
        "inner_x_min": abs(x_value - geometry.inner_x_min) <= tolerance
        and geometry.inner_y_min - tolerance
        <= y_value
        <= geometry.inner_y_max + tolerance,
        "inner_x_max": abs(x_value - geometry.inner_x_max) <= tolerance
        and geometry.inner_y_min - tolerance
        <= y_value
        <= geometry.inner_y_max + tolerance,
        "inner_y_min": abs(y_value - geometry.inner_y_min) <= tolerance
        and geometry.inner_x_min - tolerance
        <= x_value
        <= geometry.inner_x_max + tolerance,
        "inner_y_max": abs(y_value - geometry.inner_y_max) <= tolerance
        and geometry.inner_x_min - tolerance
        <= x_value
        <= geometry.inner_x_max + tolerance,
    }[side]


def _prepare_inputs(
    locked_node_coordinates: Mapping[int, Sequence[float]],
    locked_boundary_facets: Mapping[str, Sequence[Sequence[int]]],
    geometry: RectangularFrameGeometry,
    z_min_mm: float,
    z_max_mm: float,
) -> _PreparedFrame:
    if not isinstance(geometry, RectangularFrameGeometry):
        raise ConstrainedHybridError(
            "rectangular frame geometry must be RectangularFrameGeometry"
        )
    z_min = _finite(z_min_mm, name="rectangular frame minimum Z")
    z_max = _finite(z_max_mm, name="rectangular frame maximum Z")
    if z_max <= z_min:
        raise ConstrainedHybridError("rectangular frame Z interval must be positive")
    if not isinstance(locked_node_coordinates, Mapping):
        raise ConstrainedHybridError("locked frame coordinates must be a mapping")
    if not isinstance(locked_boundary_facets, Mapping):
        raise ConstrainedHybridError("locked frame facets must be grouped by side")
    unknown = set(locked_boundary_facets).difference(_SIDE_SET)
    if unknown:
        raise ConstrainedHybridError(
            "unknown locked frame side(s): " + ", ".join(sorted(unknown))
        )

    coordinates: dict[int, Point3D] = {}
    for raw_id, raw_point in locked_node_coordinates.items():
        if isinstance(raw_id, bool) or not isinstance(raw_id, int) or raw_id < 1:
            raise ConstrainedHybridError(
                "locked frame node IDs must be positive integers"
            )
        values = tuple(raw_point)
        if len(values) != 3:
            raise ConstrainedHybridError("locked frame point must contain x,y,z")
        coordinates[raw_id] = tuple(
            _finite(value, name=f"locked frame node {raw_id}") for value in values
        )  # type: ignore[assignment]
    if len({_coordinate_key(point) for point in coordinates.values()}) != len(
        coordinates
    ):
        raise ConstrainedHybridError("locked frame nodes contain duplicates")

    patches: list[_FramePatch] = []
    referenced: set[int] = set()
    face_keys: set[tuple[int, ...]] = set()
    for side in _SIDE_ORDER:
        try:
            raw_facets = tuple(
                tuple(facet) for facet in locked_boundary_facets.get(side, ())
            )
        except TypeError as error:
            raise ConstrainedHybridError(
                f"locked frame {side} facets must be TRI3/QUAD4"
            ) from error
        if not raw_facets:
            continue
        facets: list[tuple[int, ...]] = []
        for raw_facet in raw_facets:
            if len(raw_facet) not in {3, 4} or any(
                isinstance(node, bool) or not isinstance(node, int)
                for node in raw_facet
            ):
                raise ConstrainedHybridError(
                    f"locked frame {side} facets must be TRI3/QUAD4"
                )
            facet = tuple(int(node) for node in raw_facet)
            if len(set(facet)) != len(facet) or any(
                node not in coordinates for node in facet
            ):
                raise ConstrainedHybridError(f"locked frame {side} facet is invalid")
            if not all(
                _point_on_side(side, coordinates[node], geometry, z_min, z_max)
                for node in facet
            ):
                raise ConstrainedHybridError(
                    f"locked frame {side} facet is not on that geometric side"
                )
            if _facet_area(facet, coordinates) <= _COORDINATE_TOLERANCE**2:
                raise ConstrainedHybridError(
                    f"locked frame {side} facet has zero area"
                )
            key = _face_key(facet)
            if key in face_keys:
                raise ConstrainedHybridError("locked frame facets must be unique")
            face_keys.add(key)
            referenced.update(facet)
            facets.append(facet)
        if not _facets_connected(facets):
            raise ConstrainedHybridError(
                f"locked frame {side} facets must form one connected patch"
            )
        patches.append(
            _FramePatch(
                side=side,
                facets=tuple(facets),
                boundary_loops=_boundary_loops(facets),
                outward=_outward(side),
            )
        )
    if referenced != set(coordinates):
        raise ConstrainedHybridError(
            "every locked frame node must be referenced by a facet"
        )
    return _PreparedFrame(
        geometry=geometry,
        z_min=z_min,
        z_max=z_max,
        coordinates=MappingProxyType(coordinates),
        patches=tuple(patches),
    )


def _projected_loop_area(
    side: str,
    loop: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> float:
    if side in {"bottom", "top"}:
        axes = (0, 1)
    elif side.endswith("x_min") or side.endswith("x_max"):
        axes = (1, 2)
    else:
        axes = (0, 2)
    first_axis, second_axis = axes
    return 0.5 * math.fsum(
        coordinates[loop[index]][first_axis]
        * coordinates[loop[(index + 1) % len(loop)]][second_axis]
        - coordinates[loop[(index + 1) % len(loop)]][first_axis]
        * coordinates[loop[index]][second_axis]
        for index in range(len(loop))
    )


def _add_patch_surface(
    gmsh: Any,
    prepared: _PreparedFrame,
    patch: _FramePatch,
) -> int:
    loops = tuple(
        sorted(
            patch.boundary_loops,
            key=lambda loop: abs(
                _projected_loop_area(patch.side, loop, prepared.coordinates)
            ),
            reverse=True,
        )
    )
    wire_tags: list[int] = []
    for loop in loops:
        points = tuple(
            int(gmsh.model.occ.addPoint(*prepared.coordinates[node])) for node in loop
        )
        curves = tuple(
            int(gmsh.model.occ.addLine(first, second))
            for first, second in zip(points, (*points[1:], points[0]))
        )
        wire_tags.append(int(gmsh.model.occ.addCurveLoop(curves)))
    return int(gmsh.model.occ.addPlaneSurface(wire_tags))


def _add_frame_volume(gmsh: Any, prepared: _PreparedFrame) -> tuple[int, float]:
    geometry = prepared.geometry
    height = prepared.z_max - prepared.z_min
    outer = int(
        gmsh.model.occ.addBox(
            geometry.outer_x_min,
            geometry.outer_y_min,
            prepared.z_min,
            geometry.outer_x_max - geometry.outer_x_min,
            geometry.outer_y_max - geometry.outer_y_min,
            height,
        )
    )
    inner = int(
        gmsh.model.occ.addBox(
            geometry.inner_x_min,
            geometry.inner_y_min,
            prepared.z_min,
            geometry.inner_x_max - geometry.inner_x_min,
            geometry.inner_y_max - geometry.inner_y_min,
            height,
        )
    )
    cut, _maps = gmsh.model.occ.cut(
        [(3, outer)], [(3, inner)], removeObject=True, removeTool=True
    )
    volumes = tuple(int(tag) for dimension, tag in cut if int(dimension) == 3)
    if len(volumes) != 1:
        raise ConstrainedHybridError("OCC did not create one rectangular frame")
    return volumes[0], geometry.area * height


def _mesh_candidate(
    gmsh: Any,
    prepared: _PreparedFrame,
    *,
    target_size: float,
    near_size: float,
    transition_distance: float,
    optimization_rounds: int,
    seed: int,
    verbose: bool,
) -> tuple[_RawCandidate, float, str]:
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_occ_rectangular_frame_conformal",
        number_options={
            "General.Terminal": 1.0 if verbose else 0.0,
            "Mesh.ElementOrder": 1.0,
            "Mesh.Algorithm": 6.0,
            "Mesh.Algorithm3D": 1.0,
            "Mesh.MeshOnlyEmpty": 1.0,
            "Mesh.MeshSizeMin": near_size,
            "Mesh.MeshSizeMax": target_size,
            "Mesh.MeshSizeExtendFromBoundary": 0.0,
            "Mesh.MeshSizeFromCurvature": 0.0,
            "Mesh.MeshSizeFromPoints": 0.0,
            "Mesh.Optimize": 1.0 if optimization_rounds else 0.0,
            "Mesh.OptimizePyramids": 1.0,
            "Mesh.RandomSeed": float(seed),
        },
    ):
        volume_tag, analytic_volume = _add_frame_volume(gmsh, prepared)
        patch_surfaces = tuple(
            _add_patch_surface(gmsh, prepared, patch)
            for patch in prepared.patches
        )
        # The shared locked-surface installer addresses prepared patches by
        # stable positional identity.  A geometric side can contain more than
        # one disconnected patch, so side names are neither unique nor a
        # valid replacement for this index.
        surface_by_patch: dict[int, int] = {}
        if patch_surfaces:
            _outputs, maps = gmsh.model.occ.fragment(
                [(3, volume_tag)],
                [(2, tag) for tag in patch_surfaces],
                removeObject=True,
                removeTool=True,
            )
            gmsh.model.occ.synchronize()
            volumes = tuple(int(tag) for dimension, tag in gmsh.model.getEntities(3))
            if len(volumes) != 1:
                raise ConstrainedHybridError(
                    "locked frame patches split the volume into multiple regions"
                )
            volume_tag = volumes[0]
            boundary_surfaces = {
                int(tag)
                for dimension, tag in gmsh.model.getBoundary(
                    [(3, volume_tag)], oriented=False, recursive=False
                )
                if int(dimension) == 2
            }
            detached = {
                int(tag)
                for dimension, tag in gmsh.model.getEntities(2)
                if int(tag) not in boundary_surfaces
            }
            if detached:
                gmsh.model.occ.remove(
                    [(2, tag) for tag in sorted(detached)], recursive=True
                )
                gmsh.model.occ.synchronize()
            if len(maps) != 1 + len(prepared.patches):
                raise ConstrainedHybridError(
                    "OCC returned inconsistent locked frame patch maps"
                )
            for patch_index, (patch, mapping) in enumerate(
                zip(prepared.patches, maps[1:])
            ):
                mapped = {
                    int(tag)
                    for dimension, tag in mapping
                    if int(dimension) == 2 and int(tag) in boundary_surfaces
                }
                if len(mapped) != 1:
                    raise ConstrainedHybridError(
                        f"locked frame side {patch.side} did not map to one surface"
                    )
                surface_by_patch[patch_index] = mapped.pop()
            _install_locked_curves(gmsh, prepared, surface_by_patch)
        else:
            gmsh.model.occ.synchronize()

        cad_volume = float(gmsh.model.occ.getMass(3, volume_tag))
        if (
            not math.isfinite(cad_volume)
            or cad_volume <= 0.0
            or abs(cad_volume - analytic_volume) / analytic_volume > 1.0e-10
        ):
            raise ConstrainedHybridError("OCC rectangular frame volume is inconsistent")
        if surface_by_patch and near_size < target_size:
            distance = int(gmsh.model.mesh.field.add("Distance"))
            gmsh.model.mesh.field.setNumbers(
                distance, "SurfacesList", list(surface_by_patch.values())
            )
            threshold = int(gmsh.model.mesh.field.add("Threshold"))
            for name, value in (
                ("InField", distance),
                ("SizeMin", near_size),
                ("SizeMax", target_size),
                ("DistMin", 0.0),
                ("DistMax", transition_distance),
            ):
                gmsh.model.mesh.field.setNumber(threshold, name, value)
            gmsh.model.mesh.field.setAsBackgroundMesh(threshold)
            field_kind = "Distance+Threshold"
        else:
            field = int(gmsh.model.mesh.field.add("MathEval"))
            gmsh.model.mesh.field.setString(field, "F", f"{target_size:.17g}")
            gmsh.model.mesh.field.setAsBackgroundMesh(field)
            field_kind = "MathEvalConstant"

        gmsh.model.mesh.generate(2)
        if surface_by_patch:
            _replace_locked_surfaces(gmsh, prepared, surface_by_patch)
        try:
            gmsh.model.mesh.generate(3)
        except Exception as error:
            raise ConstrainedHybridError(
                "Gmsh could not fill the rectangular frame"
            ) from error
        if tuple(gmsh.model.mesh.getDuplicateNodes()):
            gmsh.model.mesh.removeDuplicateNodes()
        for _iteration in range(optimization_rounds):
            gmsh.model.mesh.optimize(
                "Relocate3D", force=True, niter=3, dimTags=[(3, volume_tag)]
            )
            gmsh.model.mesh.optimize(
                "", force=True, niter=50, dimTags=[(3, volume_tag)]
            )
        return _extract_candidate(gmsh, volume_tag, seed), cad_volume, field_kind


def _tetra_volume(
    first: Point3D,
    second: Point3D,
    third: Point3D,
    fourth: Point3D,
) -> float:
    ab = tuple(second[index] - first[index] for index in range(3))
    ac = tuple(third[index] - first[index] for index in range(3))
    ad = tuple(fourth[index] - first[index] for index in range(3))
    cross = (
        ac[1] * ad[2] - ac[2] * ad[1],
        ac[2] * ad[0] - ac[0] * ad[2],
        ac[0] * ad[1] - ac[1] * ad[0],
    )
    return abs(math.fsum(ab[index] * cross[index] for index in range(3))) / 6.0


def _element_volume(
    element: GmshRectangularFrameElement,
    coordinates: Mapping[int, Point3D],
) -> float:
    points = tuple(coordinates[node] for node in element.node_ids)
    if element.gmsh_type == _TET4:
        return _tetra_volume(*points)  # type: ignore[arg-type]
    if element.gmsh_type == _PYRAMID5:
        return _tetra_volume(points[0], points[1], points[2], points[4]) + _tetra_volume(
            points[0], points[2], points[3], points[4]
        )
    return math.fsum(
        (
            _tetra_volume(points[0], points[1], points[2], points[3]),
            _tetra_volume(points[1], points[2], points[4], points[3]),
            _tetra_volume(points[2], points[4], points[5], points[3]),
        )
    )


def _classify_boundary_face(
    cycle: Sequence[int],
    coordinates: Mapping[int, Point3D],
    prepared: _PreparedFrame,
) -> str:
    matches = tuple(
        side
        for side in _SIDE_ORDER
        if all(
            _point_on_side(
                side,
                coordinates[node],
                prepared.geometry,
                prepared.z_min,
                prepared.z_max,
            )
            for node in cycle
        )
    )
    if len(matches) != 1:
        raise ConstrainedHybridError(
            "Gmsh rectangular frame boundary facet has ambiguous geometry"
        )
    return matches[0]


def _finalize_candidate(
    candidate: _RawCandidate,
    prepared: _PreparedFrame,
    cad_volume: float,
    field_kind: str,
    *,
    target_size: float,
    near_size: float,
    transition_distance: float,
    minimum_quality: float,
) -> GmshRectangularFrameVolume:
    if candidate.duplicate_node_count:
        raise ConstrainedHybridError("Gmsh frame mesh contains duplicate nodes")
    if any(
        not math.isfinite(value) or value <= 0.0 for value in candidate.determinants
    ):
        raise ConstrainedHybridError("Gmsh frame mesh has a non-positive element")
    if any(
        not math.isfinite(value)
        for values in (candidate.sicn, candidate.sige, candidate.scaled_jacobian)
        for value in values
    ):
        raise ConstrainedHybridError("Gmsh frame quality is non-finite")
    if any(
        min(values) < minimum_quality
        for values in (candidate.sicn, candidate.sige, candidate.scaled_jacobian)
    ):
        raise ConstrainedHybridError(
            "Gmsh rectangular frame quality floor was not met: "
            f"minSJ={min(candidate.scaled_jacobian):.8g}, "
            f"minSICN={min(candidate.sicn):.8g}, "
            f"minSIGE={min(candidate.sige):.8g}, required={minimum_quality:.8g}"
        )

    gmsh_by_coordinate: dict[tuple[float, float, float], int] = {}
    for tag, point in candidate.coordinates.items():
        key = _coordinate_key(point)
        if key in gmsh_by_coordinate:
            raise ConstrainedHybridError("Gmsh frame mesh has coincident nodes")
        gmsh_by_coordinate[key] = tag
    gmsh_source: dict[int, int] = {}
    for source_id, point in prepared.coordinates.items():
        tag = gmsh_by_coordinate.get(_coordinate_key(point))
        if tag is None or math.dist(candidate.coordinates[tag], point) > (
            _COORDINATE_TOLERANCE
        ):
            raise ConstrainedHybridError("Gmsh changed a locked frame node")
        gmsh_source[tag] = source_id
    ordered_gmsh = tuple(
        sorted(
            candidate.coordinates,
            key=lambda tag: (_coordinate_key(candidate.coordinates[tag]), tag),
        )
    )
    local_by_gmsh = {
        tag: local for local, tag in enumerate(ordered_gmsh, start=1)
    }
    coordinates = {
        local_by_gmsh[tag]: candidate.coordinates[tag] for tag in ordered_gmsh
    }
    source_by_local = {
        local_by_gmsh[tag]: source for tag, source in gmsh_source.items()
    }
    elements = tuple(
        sorted(
            (
                GmshRectangularFrameElement(
                    gmsh_type,
                    tuple(local_by_gmsh[node] for node in nodes),
                )
                for gmsh_type, _tag, nodes in candidate.elements
            ),
            key=lambda element: (
                element.gmsh_type,
                tuple(sorted(element.node_ids)),
                element.node_ids,
            ),
        )
    )
    duplicate_elements = len(elements) - len(
        {(element.gmsh_type, _face_key(element.node_ids)) for element in elements}
    )
    if duplicate_elements:
        raise ConstrainedHybridError("Gmsh frame mesh has duplicate elements")
    owners: dict[
        tuple[int, ...], list[tuple[int, tuple[int, ...]]]
    ] = defaultdict(list)
    for element_index, element in enumerate(elements):
        for face in ELEMENT_SPECS[element.gmsh_type][2]:
            cycle = tuple(element.node_ids[index] for index in face)
            owners[_face_key(cycle)].append((element_index, cycle))
    if any(len(values) not in {1, 2} for values in owners.values()):
        raise ConstrainedHybridError("Gmsh frame mesh is non-manifold")
    boundary = {
        key: values[0][1] for key, values in owners.items() if len(values) == 1
    }
    boundary_keys_by_side: dict[str, set[tuple[int, ...]]] = {
        side: set() for side in _SIDE_ORDER
    }
    for key, cycle in boundary.items():
        boundary_keys_by_side[
            _classify_boundary_face(cycle, coordinates, prepared)
        ].add(key)
    if any(not values for values in boundary_keys_by_side.values()):
        raise ConstrainedHybridError("Gmsh frame boundary classification is incomplete")

    local_by_source = {source: local for local, source in source_by_local.items()}
    locked_by_side: dict[str, tuple[tuple[int, ...], ...]] = {}
    locked_triangles = 0
    locked_quads = 0
    for patch in prepared.patches:
        mapped: list[tuple[int, ...]] = []
        for facet in patch.facets:
            local_facet = tuple(local_by_source[node] for node in facet)
            key = _face_key(local_facet)
            if key not in boundary_keys_by_side[patch.side] or len(owners.get(key, ())) != 1:
                raise ConstrainedHybridError(
                    f"Gmsh changed the locked frame {patch.side} facet set"
                )
            if len(facet) == 3:
                locked_triangles += 1
            else:
                owner_element = elements[owners[key][0][0]]
                if owner_element.gmsh_type not in {_WEDGE6, _PYRAMID5}:
                    raise ConstrainedHybridError(
                        "locked frame QUAD4 lacks a Gmsh hybrid owner"
                    )
                locked_quads += 1
            mapped.append(local_facet)
        locked_by_side[patch.side] = tuple(mapped)

    element_volume = math.fsum(
        _element_volume(element, coordinates) for element in elements
    )
    volume_error = abs(element_volume - cad_volume) / cad_volume
    if volume_error > 1.0e-8:
        raise ConstrainedHybridError(
            f"Gmsh frame mesh/CAD volume mismatch is {volume_error:.3g}"
        )
    boundary_by_side = {
        side: tuple(boundary[key] for key in sorted(keys))
        for side, keys in boundary_keys_by_side.items()
    }
    return GmshRectangularFrameVolume(
        node_coordinates=MappingProxyType(coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        elements=elements,
        locked_facets_by_side=MappingProxyType(locked_by_side),
        boundary_facets_by_side=MappingProxyType(boundary_by_side),
        tet4_count=sum(element.gmsh_type == _TET4 for element in elements),
        wedge6_count=sum(element.gmsh_type == _WEDGE6 for element in elements),
        pyramid5_count=sum(element.gmsh_type == _PYRAMID5 for element in elements),
        locked_triangle_count=locked_triangles,
        locked_quad_count=locked_quads,
        target_size_mm=target_size,
        near_size_mm=near_size,
        transition_distance_mm=transition_distance,
        background_field_kind=field_kind,
        minimum_sicn=min(candidate.sicn),
        minimum_sige=min(candidate.sige),
        minimum_scaled_jacobian=min(candidate.scaled_jacobian),
        minimum_determinant=min(candidate.determinants),
        duplicate_node_count=candidate.duplicate_node_count,
        duplicate_element_count=duplicate_elements,
        cad_volume_mm3=cad_volume,
        element_volume_mm3=element_volume,
        relative_volume_error=volume_error,
        random_seed=candidate.seed,
    )


def generate_rectangular_frame_conformal_hybrid(
    locked_node_coordinates: Mapping[int, Sequence[float]],
    locked_boundary_facets: Mapping[str, Sequence[Sequence[int]]],
    geometry: RectangularFrameGeometry,
    z_min_mm: float,
    z_max_mm: float,
    *,
    target_size_mm: float,
    transition_distance_mm: float,
    near_size_mm: float | None = None,
    minimum_quality: float = 0.03,
    random_seeds: Sequence[int] = (1, 2, 3),
    optimization_rounds: int = 2,
    verbose: bool = False,
) -> GmshRectangularFrameVolume:
    """Mesh a rectangular frame with arbitrary named locked side patches."""

    prepared = _prepare_inputs(
        locked_node_coordinates,
        locked_boundary_facets,
        geometry,
        z_min_mm,
        z_max_mm,
    )
    target_size = _finite(target_size_mm, name="frame target size")
    transition_distance = _finite(
        transition_distance_mm, name="frame transition distance"
    )
    if near_size_mm is None:
        edges = tuple(
            math.dist(prepared.coordinates[first], prepared.coordinates[second])
            for patch in prepared.patches
            for facet in patch.facets
            for first, second in zip(facet, (*facet[1:], facet[0]))
        )
        near_size = min(target_size, median(edges)) if edges else target_size
    else:
        near_size = _finite(near_size_mm, name="frame near size")
    quality_floor = _finite(minimum_quality, name="frame minimum quality")
    if (
        target_size <= 0.0
        or near_size <= 0.0
        or near_size > target_size
        or transition_distance <= 0.0
        or quality_floor <= 0.0
        or quality_floor >= 1.0
    ):
        raise ConstrainedHybridError("frame sizes or quality floor are invalid")
    try:
        seeds = tuple(dict.fromkeys(random_seeds))
    except TypeError as error:
        raise ConstrainedHybridError("frame random seeds must be a sequence") from error
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
        for seed in seeds
    ):
        raise ConstrainedHybridError("frame random seeds must be positive integers")
    if (
        isinstance(optimization_rounds, bool)
        or not isinstance(optimization_rounds, int)
        or optimization_rounds < 0
        or optimization_rounds > 4
    ):
        raise ConstrainedHybridError("frame optimization rounds must be 0..4")

    gmsh = _load_gmsh()
    failures: list[str] = []
    for seed in seeds:
        try:
            candidate, cad_volume, field_kind = _mesh_candidate(
                gmsh,
                prepared,
                target_size=target_size,
                near_size=near_size,
                transition_distance=transition_distance,
                optimization_rounds=optimization_rounds,
                seed=seed,
                verbose=verbose,
            )
            return _finalize_candidate(
                candidate,
                prepared,
                cad_volume,
                field_kind,
                target_size=target_size,
                near_size=near_size,
                transition_distance=transition_distance,
                minimum_quality=quality_floor,
            )
        except ConstrainedHybridError as error:
            failures.append(f"seed {seed}: {error}")
        except Exception as error:  # pragma: no cover - Gmsh runtime failure
            failures.append(f"seed {seed}: Gmsh runtime failure: {error}")
    raise ConstrainedHybridError(
        "all direct OCC/Gmsh frame candidates failed; " + "; ".join(failures)
    )


__all__ = [
    "GmshRectangularFrameElement",
    "GmshRectangularFrameVolume",
    "RectangularFrameGeometry",
    "generate_rectangular_frame_conformal_hybrid",
]
