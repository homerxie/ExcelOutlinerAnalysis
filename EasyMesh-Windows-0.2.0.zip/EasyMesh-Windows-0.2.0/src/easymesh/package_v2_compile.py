"""End-to-end pure compiler for Package V2 Source revision 8.

The pipeline is deliberately free of Gmsh and mesh-file I/O:

``JSON bytes -> source DTO -> template instances -> numeric generated geometry
-> assembly policy -> canonical plan identity``.

Generated instances support independently placed nested leaves.
Template geometry, strategy directions and Orth
partition origins remain component-local before the instance rotation.  Frozen
artifact declarations are resolved to lexical runtime paths for later workers,
but no artifact is opened, stat'ed, or hashed.  Only normalized relative
artifact declarations participate in the portable canonical plan digest.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import math
import os
import re
from pathlib import Path, PurePosixPath
from types import MappingProxyType
from typing import Mapping, NoReturn, Sequence, TypeVar

from .package_assembly import (
    AssemblyPolicyError,
    COMPONENT_LOCAL_DIRECTIONS,
    Component,
    ComponentLocalDirection,
    ConformalHybridMeshStrategy,
    FrozenSource,
    GeneratedComponentMeshControl,
    GeometryRecord,
    GeometryRecordKind,
    OrthogonalHexMeshStrategy,
    PackageAssemblyPolicy,
    ResolvedTemplateParameters,
    StructuredSweepMeshStrategy,
    TemplateDimension,
    resolve_template_parameters,
)
from .package_template import (
    TemplateCompileResult,
    TemplateDefinition,
    TemplateInstance,
    compile_template_instance,
)
from .package_v2_geometry import (
    BoxSource,
    UnionSource,
    DifferenceSource,
    CanonicalBox,
    CanonicalRigidPlacement as CanonicalGeneratedPlacement,
    GeometryCompilationError,
    GeometryCompilationResult,
    GeometryFragmentSource,
    RectangularFrameExtrusionSource,
    RectangularUnderfillFilletSource,
    RigidPlacementSource as GeneratedPlacementExpressionSource,
    canonical_geometry_to_jsonable,
    compile_generated_geometry_instance,
    compile_rigid_placement,
)
from .package_v2_source import (
    BoxGeometrySource,
    UnionGeometrySource,
    DifferenceGeometrySource,
    ConformalHybridMeshStrategySource,
    FrozenRigidPlacementSource,
    FrozenSourceDeclaration,
    GeneratedComponentMeshControlSource,
    GeneratedInstancePlacementSource,
    GeometryRecordOperation,
    PackageV2SourceError,
    OrthogonalHexMeshStrategySource,
    ParsedPackageV2Source,
    RectangularFrameGeometrySource,
    RectangularUnderfillFilletGeometrySource,
    StructuredSweepMeshStrategySource,
    TemplateInstanceSource,
    TemplateSource,
    parse_package_v2_json,
)

PACKAGE_V2_PLAN_SCHEMA = "easymesh-package-v2-canonical-plan-v3"
GENERATED_INSTANCE_PLACEMENT_SUPPORTED = True


class PackageV2CompilationError(AssemblyPolicyError):
    """A stage-qualified semantic compilation failure."""

    def __init__(self, stage: str, context: str, message: str) -> None:
        self.stage = stage
        self.context = context
        self.message = message
        super().__init__(f"Package V2 {stage} error at {context}: {message}")


def _raise_context(stage: str, context: str, error: BaseException) -> NoReturn:
    if isinstance(error, PackageV2CompilationError):
        raise error
    raise PackageV2CompilationError(stage, context, str(error)) from error


def _nonempty_text(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AssemblyPolicyError(f"{field_name} must be a non-empty string")
    return value.strip()


_T = TypeVar("_T")


def _typed_tuple(
    value: object,
    expected_type: type[_T],
    *,
    field_name: str,
) -> tuple[_T, ...]:
    if isinstance(value, (str, bytes)):
        raise AssemblyPolicyError(f"{field_name} must be a sequence")
    try:
        items = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise AssemblyPolicyError(f"{field_name} must be a sequence") from error
    if any(type(item) is not expected_type for item in items):
        raise AssemblyPolicyError(
            f"{field_name} must contain {expected_type.__name__} values"
        )
    return items


def _finite_number(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise AssemblyPolicyError(f"{field_name} must be a finite number")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise AssemblyPolicyError(f"{field_name} must be a finite number") from error
    if not math.isfinite(result):
        raise AssemblyPolicyError(f"{field_name} must be a finite number")
    return 0.0 if result == 0.0 else result


def _numeric_row(value: object, *, field_name: str) -> tuple[float, float, float]:
    if isinstance(value, (str, bytes)):
        raise AssemblyPolicyError(
            f"{field_name} must contain exactly three finite numbers"
        )
    try:
        items = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise AssemblyPolicyError(
            f"{field_name} must contain exactly three finite numbers"
        ) from error
    if len(items) != 3:
        raise AssemblyPolicyError(
            f"{field_name} must contain exactly three finite numbers"
        )
    return tuple(  # type: ignore[return-value]
        _finite_number(item, field_name=f"{field_name}[{index}]")
        for index, item in enumerate(items)
    )


def _canonical_float(value: float) -> float:
    if not math.isfinite(value):
        raise PackageV2CompilationError(
            "plan",
            "canonical numeric value",
            "non-finite values are forbidden",
        )
    return 0.0 if value == 0.0 else value


def _canonical_json(payload: object) -> str:
    try:
        return json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    except (OverflowError, TypeError, ValueError) as error:
        _raise_context("plan", "canonical JSON", error)


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _qualified_identifier(
    prefix: str,
    owner_id: str,
    local_id: str,
) -> str:
    """Return an injective, identifier-safe length-prefixed global ID."""

    prefix = _nonempty_text(prefix, field_name="global identifier prefix")
    owner_id = _nonempty_text(owner_id, field_name="global identifier owner")
    local_id = _nonempty_text(local_id, field_name="local identifier")
    return (
        f"v2{prefix}_o{len(owner_id)}_{owner_id}"
        f"_l{len(local_id)}_{local_id}"
    )


def generated_component_global_id(instance_id: str, component_id: str) -> str:
    return _qualified_identifier("g", instance_id, component_id)


def frozen_component_global_id(source_id: str, component_id: str) -> str:
    if re.fullmatch(r"[A-Za-z0-9_]+", component_id):
        return _qualified_identifier("f", source_id, component_id)
    # Preserve the external name in IdentifierBinding.local_id; encode only
    # the internal ID. A separate prefix prevents collisions with literal hex
    # names, while existing identifier-safe groups retain their IDs.
    return _qualified_identifier("fx", source_id, component_id.encode("utf-8").hex())


def generated_fragment_global_id(instance_id: str, fragment_id: str) -> str:
    return _qualified_identifier("r", instance_id, fragment_id)


@dataclass(frozen=True, slots=True)
class IdentifierBinding:
    """One source-local identifier and its collision-safe global identity."""

    local_id: str
    global_id: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "local_id",
            _nonempty_text(self.local_id, field_name="local identifier"),
        )
        object.__setattr__(
            self,
            "global_id",
            _nonempty_text(self.global_id, field_name="global identifier"),
        )


@dataclass(frozen=True, slots=True)
class GeneratedComponentDescriptor:
    local_component_id: str
    global_component_id: str
    material_name: str
    fragments: tuple[IdentifierBinding, ...]
    mesh_control: GeneratedComponentMeshControl | None
    policy_component: Component = field(repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "local_component_id",
            _nonempty_text(
                self.local_component_id,
                field_name="local component identifier",
            ),
        )
        object.__setattr__(
            self,
            "global_component_id",
            _nonempty_text(
                self.global_component_id,
                field_name="global component identifier",
            ),
        )
        object.__setattr__(
            self,
            "material_name",
            _nonempty_text(self.material_name, field_name="component material"),
        )
        fragments = _typed_tuple(
            self.fragments,
            IdentifierBinding,
            field_name="component fragments",
        )
        if not fragments:
            raise AssemblyPolicyError(
                "a generated component descriptor must contain geometry"
            )
        if len({value.local_id for value in fragments}) != len(fragments):
            raise AssemblyPolicyError("local fragment identifiers must be unique")
        if len({value.global_id for value in fragments}) != len(fragments):
            raise AssemblyPolicyError("global fragment identifiers must be unique")
        object.__setattr__(self, "fragments", fragments)
        if self.mesh_control is not None and type(
            self.mesh_control
        ) is not GeneratedComponentMeshControl:
            raise AssemblyPolicyError(
                "descriptor mesh_control must be a GeneratedComponentMeshControl"
            )
        if type(self.policy_component) is not Component:
            raise AssemblyPolicyError("policy_component must be a Component")
        if (
            self.policy_component.identifier != self.global_component_id
            or self.policy_component.material_name != self.material_name
            or self.policy_component.geometry_refs
            != tuple(value.global_id for value in fragments)
            or self.policy_component.mesh_control != self.mesh_control
        ):
            raise AssemblyPolicyError(
                "generated component descriptor does not match policy_component"
            )


@dataclass(frozen=True, slots=True)
class CompiledGeneratedInstance:
    """One resolved instance; v8 composites can contain placed child fragments."""

    instance_id: str
    template_id: str
    template_result: TemplateCompileResult
    geometry_result: GeometryCompilationResult
    placement: CanonicalGeneratedPlacement
    components: tuple[GeneratedComponentDescriptor, ...]
    nested_placements: bool = field(default=False, kw_only=True)
    generated_instance_placement_supported: bool = field(
        default=True,
        init=False,
    )

    def __post_init__(self) -> None:
        if type(self.nested_placements) is not bool:
            raise AssemblyPolicyError("nested_placements must be boolean")
        object.__setattr__(
            self,
            "instance_id",
            _nonempty_text(self.instance_id, field_name="instance identifier"),
        )
        object.__setattr__(
            self,
            "template_id",
            _nonempty_text(self.template_id, field_name="template identifier"),
        )
        if type(self.template_result) is not TemplateCompileResult:
            raise AssemblyPolicyError(
                "template_result must be a TemplateCompileResult"
            )
        if type(self.geometry_result) is not GeometryCompilationResult:
            raise AssemblyPolicyError(
                "geometry_result must be a GeometryCompilationResult"
            )
        if type(self.placement) is not CanonicalGeneratedPlacement:
            raise AssemblyPolicyError(
                "placement must be a CanonicalGeneratedPlacement"
            )
        if (
            self.template_result.instance_id != self.instance_id
            or self.template_result.template_id != self.template_id
            or self.geometry_result.geometry.instance_id != self.instance_id
        ):
            raise AssemblyPolicyError(
                "compiled generated instance identifiers do not match"
            )
        components = _typed_tuple(
            self.components,
            GeneratedComponentDescriptor,
            field_name="compiled generated components",
        )
        if not components:
            raise AssemblyPolicyError(
                "a compiled generated instance must contain a component"
            )
        if len({value.local_component_id for value in components}) != len(components):
            raise AssemblyPolicyError("local component identifiers must be unique")
        if len({value.global_component_id for value in components}) != len(components):
            raise AssemblyPolicyError("global component identifiers must be unique")
        object.__setattr__(self, "components", components)
        fragment_placements = tuple(
            fragment.placement
            for component in self.geometry_result.geometry.components
            for fragment in component.fragments
        )
        if not fragment_placements or (not self.nested_placements and any(
            value != self.placement for value in fragment_placements
        )):
            raise AssemblyPolicyError(
                "every generated fragment must use the explicit instance placement"
            )

    @property
    def component_by_local_id(self) -> Mapping[str, GeneratedComponentDescriptor]:
        return MappingProxyType(
            {value.local_component_id: value for value in self.components}
        )


@dataclass(frozen=True, slots=True)
class FrozenArtifactDescriptor:
    """Portable mesh reference and optional content fingerprint recorded at import."""

    mesh_declaration: str
    mesh_runtime_path: Path
    sha256: str | None = None

    def __post_init__(self) -> None:
        for field_name in (
            "mesh_declaration",
        ):
            declaration = _nonempty_text(
                getattr(self, field_name),
                field_name=field_name,
            )
            relative = PurePosixPath(declaration)
            if (
                "\\" in declaration
                or relative.is_absolute()
                or str(relative) != declaration
                or any(part in ("", ".", "..") for part in relative.parts)
            ):
                raise AssemblyPolicyError(
                    f"{field_name} must be a normalized relative POSIX path"
                )
            object.__setattr__(self, field_name, declaration)
        for field_name in (
            "mesh_runtime_path",
        ):
            raw_path = getattr(self, field_name)
            if isinstance(raw_path, bytes):
                raise AssemblyPolicyError(f"{field_name} must be a text path")
            try:
                path = Path(raw_path)
            except (TypeError, ValueError) as error:
                raise AssemblyPolicyError(
                    f"{field_name} must be a text path"
                ) from error
            if not path.is_absolute():
                raise AssemblyPolicyError(f"{field_name} must be absolute")
            object.__setattr__(self, field_name, path)
        if self.sha256 is not None and (type(self.sha256) is not str or not re.fullmatch(r"[0-9a-f]{64}", self.sha256)):
            raise AssemblyPolicyError("mesh sha256 must be 64 lower-case hexadecimal characters")

    @property
    def declarations(self) -> Mapping[str, str]:
        return MappingProxyType(
            {
                "mesh": self.mesh_declaration,
            }
        )

    @property
    def runtime_paths(self) -> Mapping[str, Path]:
        return MappingProxyType(
            {
                "mesh": self.mesh_runtime_path,
            }
        )


@dataclass(frozen=True, slots=True)
class CanonicalFrozenPlacement:
    translation_xyz_mm: tuple[float, float, float]
    rotation_matrix: tuple[
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
    ]

    def __post_init__(self) -> None:
        translation = _numeric_row(
            self.translation_xyz_mm,
            field_name="frozen placement translation_xyz_mm",
        )
        if isinstance(self.rotation_matrix, (str, bytes)):
            raise AssemblyPolicyError(
                "frozen placement rotation_matrix must contain exactly three rows"
            )
        try:
            raw_rows = tuple(self.rotation_matrix)
        except TypeError as error:
            raise AssemblyPolicyError(
                "frozen placement rotation_matrix must contain exactly three rows"
            ) from error
        if len(raw_rows) != 3:
            raise AssemblyPolicyError(
                "frozen placement rotation_matrix must contain exactly three rows"
            )
        rotation = tuple(
            _numeric_row(
                row,
                field_name=f"frozen placement rotation_matrix[{index}]",
            )
            for index, row in enumerate(raw_rows)
        )
        tolerance = 1.0e-9
        for first in range(3):
            for second in range(3):
                dot = sum(
                    rotation[first][index] * rotation[second][index]
                    for index in range(3)
                )
                expected = 1.0 if first == second else 0.0
                if not math.isclose(
                    dot,
                    expected,
                    rel_tol=0.0,
                    abs_tol=tolerance,
                ):
                    raise AssemblyPolicyError(
                        "frozen placement rotation_matrix must be orthonormal"
                    )
        determinant = (
            rotation[0][0]
            * (rotation[1][1] * rotation[2][2] - rotation[1][2] * rotation[2][1])
            - rotation[0][1]
            * (rotation[1][0] * rotation[2][2] - rotation[1][2] * rotation[2][0])
            + rotation[0][2]
            * (rotation[1][0] * rotation[2][1] - rotation[1][1] * rotation[2][0])
        )
        if not math.isclose(
            abs(determinant),
            1.0,
            rel_tol=0.0,
            abs_tol=tolerance,
        ):
            raise AssemblyPolicyError(
                "frozen placement rotation_matrix determinant must be +1 or -1 (mirror)"
            )
        object.__setattr__(self, "translation_xyz_mm", translation)
        object.__setattr__(self, "rotation_matrix", rotation)


@dataclass(frozen=True, slots=True)
class CompiledFrozenSource:
    source_id: str
    artifacts: FrozenArtifactDescriptor
    placement: CanonicalFrozenPlacement
    components: tuple[IdentifierBinding, ...]
    policy_source: FrozenSource = field(repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "source_id",
            _nonempty_text(self.source_id, field_name="frozen source identifier"),
        )
        if type(self.artifacts) is not FrozenArtifactDescriptor:
            raise AssemblyPolicyError(
                "artifacts must be a FrozenArtifactDescriptor"
            )
        if type(self.placement) is not CanonicalFrozenPlacement:
            raise AssemblyPolicyError(
                "placement must be a CanonicalFrozenPlacement"
            )
        components = _typed_tuple(
            self.components,
            IdentifierBinding,
            field_name="frozen component bindings",
        )
        if not components:
            raise AssemblyPolicyError(
                "a compiled frozen source must contain a component"
            )
        if len({value.local_id for value in components}) != len(components):
            raise AssemblyPolicyError("local frozen component identifiers must be unique")
        if len({value.global_id for value in components}) != len(components):
            raise AssemblyPolicyError("global frozen component identifiers must be unique")
        object.__setattr__(self, "components", components)
        if type(self.policy_source) is not FrozenSource:
            raise AssemblyPolicyError("policy_source must be a FrozenSource")
        if (
            self.policy_source.source_id != self.source_id
            or self.policy_source.component_ids
            != tuple(value.global_id for value in components)
        ):
            raise AssemblyPolicyError(
                "compiled frozen source does not match policy_source"
            )

    @property
    def component_by_local_id(self) -> Mapping[str, Component]:
        return MappingProxyType(
            {
                binding.local_id: component
                for binding, component in zip(
                    self.components,
                    self.policy_source.components,
                )
            }
        )


@dataclass(frozen=True, slots=True)
class _TemplateCompilationInputs:
    definition: TemplateDefinition
    records: tuple[GeometryRecord, ...]
    fragments: Mapping[str, GeometryFragmentSource]
    mesh_control_sources: Mapping[
        str,
        GeneratedComponentMeshControlSource | None,
    ]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "fragments",
            MappingProxyType(dict(self.fragments)),
        )
        object.__setattr__(
            self,
            "mesh_control_sources",
            MappingProxyType(dict(self.mesh_control_sources)),
        )


@dataclass(frozen=True, slots=True)
class PackageV2CompileResult:
    """Complete immutable pure plan, with raw and canonical identities separate."""

    parsed_source: ParsedPackageV2Source
    template_definitions: tuple[TemplateDefinition, ...]
    generated_instances: tuple[CompiledGeneratedInstance, ...]
    frozen_sources: tuple[CompiledFrozenSource, ...]
    assembly_policy: PackageAssemblyPolicy
    canonical_plan_json: str = field(init=False, repr=False)
    plan_digest: str = field(init=False)
    generated_instance_placement_supported: bool = field(
        default=True,
        init=False,
    )

    def __post_init__(self) -> None:
        if type(self.parsed_source) is not ParsedPackageV2Source:
            raise AssemblyPolicyError(
                "parsed_source must be a ParsedPackageV2Source"
            )
        definitions = _typed_tuple(
            self.template_definitions,
            TemplateDefinition,
            field_name="template_definitions",
        )
        generated = _typed_tuple(
            self.generated_instances,
            CompiledGeneratedInstance,
            field_name="generated_instances",
        )
        frozen = _typed_tuple(
            self.frozen_sources,
            CompiledFrozenSource,
            field_name="frozen_sources",
        )
        if type(self.assembly_policy) is not PackageAssemblyPolicy:
            raise AssemblyPolicyError(
                "assembly_policy must be a PackageAssemblyPolicy"
            )
        if len({value.template_id for value in definitions}) != len(definitions):
            raise AssemblyPolicyError("template definition identifiers must be unique")
        if len({value.instance_id for value in generated}) != len(generated):
            raise AssemblyPolicyError("generated instance identifiers must be unique")
        if len({value.source_id for value in frozen}) != len(frozen):
            raise AssemblyPolicyError("frozen source identifiers must be unique")
        object.__setattr__(self, "template_definitions", definitions)
        object.__setattr__(self, "generated_instances", generated)
        object.__setattr__(self, "frozen_sources", frozen)
        plan_json = _canonical_json(_plan_payload(self))
        object.__setattr__(self, "canonical_plan_json", plan_json)
        object.__setattr__(self, "plan_digest", _sha256(plan_json))

    @property
    def raw_source_digest(self) -> str:
        return self.parsed_source.raw_sha256

    @property
    def interface_geometry_tolerance_mm(self) -> float:
        return (
            self.parsed_source.document.mesh_settings
            .interface_geometry_tolerance_mm
        )

    @property
    def generated_instance_by_id(self) -> Mapping[str, CompiledGeneratedInstance]:
        return MappingProxyType(
            {value.instance_id: value for value in self.generated_instances}
        )

    @property
    def frozen_source_by_id(self) -> Mapping[str, CompiledFrozenSource]:
        return MappingProxyType(
            {value.source_id: value for value in self.frozen_sources}
        )

    @property
    def component_by_global_id(self) -> Mapping[str, Component]:
        return self.assembly_policy.component_by_id


def _geometry_expression_root(geometry):
    if type(geometry) is BoxGeometrySource:
        root = BoxSource(geometry.origin, geometry.size)
    elif type(geometry) is RectangularFrameGeometrySource:
        root = RectangularFrameExtrusionSource(
            outer_origin_xyz=geometry.outer_origin,
            outer_size_xy=geometry.outer_size,
            opening_offset_xy=geometry.opening_offset,
            opening_size_xy=geometry.opening_size,
            height=geometry.height,
        )
    elif type(geometry) is RectangularUnderfillFilletGeometrySource:
        root = RectangularUnderfillFilletSource(
            die_origin_xy=geometry.die_origin,
            die_size_xy=geometry.die_size,
            base_z=geometry.base_z,
            wall_height=geometry.wall_height,
            toe_width=geometry.toe_width,
            top_width=geometry.top_width,
            side_widths=geometry.side_widths,
            top_widths=geometry.top_widths,
        )
    elif isinstance(geometry, UnionGeometrySource):
        root = UnionSource(
            tuple(_geometry_expression_root(v) for v in geometry.children)
        )
    elif isinstance(geometry, DifferenceGeometrySource):
        root = DifferenceSource(
            _geometry_expression_root(geometry.base),
            tuple(_geometry_expression_root(v) for v in geometry.cutters),
        )
    else:
        raise AssemblyPolicyError(
            f"geometry {geometry.identifier!r} has an unsupported source type"
        )
    return root


def _compile_template_source(source: TemplateSource) -> _TemplateCompilationInputs:
    definition = TemplateDefinition(source.identifier, (), ())

    records: list[GeometryRecord] = []
    fragments: dict[str, GeometryFragmentSource] = {}
    mesh_control_sources: dict[
        str,
        GeneratedComponentMeshControlSource | None,
    ] = {}
    for record in source.geometry_records:
        geometry = record.geometry
        root = _geometry_expression_root(geometry)
        if record.operation is GeometryRecordOperation.START_COMPONENT:
            assert record.component_id is not None
            assert record.material_id is not None
            records.append(
                GeometryRecord(
                    GeometryRecordKind.START_COMPONENT,
                    geometry.identifier,
                    component_id=record.component_id,
                    material_name=record.material_id,
                )
            )
            mesh_control_sources[record.component_id] = record.mesh_control
        else:
            records.append(
                GeometryRecord(
                    GeometryRecordKind.APPEND_GEOMETRY,
                    geometry.identifier,
                )
            )
        fragments[geometry.identifier] = GeometryFragmentSource(
            geometry.identifier,
            root,
            (_generated_placement_expression(record.local_placement)
             if record.local_placement is not None else GeneratedPlacementExpressionSource()),
        )
    return _TemplateCompilationInputs(
        definition,
        tuple(records),
        fragments,
        mesh_control_sources,
    )


def _compile_component_mesh_control(
    source: GeneratedComponentMeshControlSource | None,
    resolved: ResolvedTemplateParameters,
    *,
    context: str,
) -> GeneratedComponentMeshControl | None:
    if source is None:
        return None
    if type(source) is not GeneratedComponentMeshControlSource:
        raise AssemblyPolicyError(
            "component mesh_control source has an invalid type"
        )
    if (
        not isinstance(source.target_edge_source, str)
        or not source.target_edge_source.strip()
    ):
        raise AssemblyPolicyError(
            "component target_edge source must be a length expression"
        )
    target_edge = resolved.evaluate_expression(
        source.target_edge_source,
        dimension=TemplateDimension.LENGTH,
        field_name=f"{context}.target_edge",
    )
    if (
        not isinstance(source.transition_distance_source, str)
        or not source.transition_distance_source.strip()
    ):
        raise AssemblyPolicyError(
            "component transition_distance source must be a length expression"
        )
    transition_distance = resolved.evaluate_expression(
        source.transition_distance_source,
        dimension=TemplateDimension.LENGTH,
        field_name=f"{context}.transition_distance",
    )
    strategy_source = source.strategy
    def optional_length(name):
        expression = getattr(strategy_source, name + "_source", None)
        return (None if expression is None else resolved.evaluate_expression(
            expression, dimension=TemplateDimension.LENGTH,
            field_name=f"{context}.strategy.{name}"))
    origin_source = getattr(strategy_source, "partition_origin_source", None)
    partition_origin = (None if origin_source is None else tuple(
        resolved.evaluate_expression(expression, dimension=TemplateDimension.LENGTH,
            field_name=f"{context}.strategy.partition_origin[{index}]")
        for index, expression in enumerate(origin_source)))
    if type(strategy_source) is StructuredSweepMeshStrategySource:
        strategy = StructuredSweepMeshStrategy(strategy_source.direction, sizing=strategy_source.sizing,
            plane_size_mm=optional_length("plane_size"), layer_size_mm=optional_length("layer_size"),
            plane_transition_distance_mm=optional_length("plane_transition_distance"),
            partition_origin_mm=partition_origin)
    elif type(strategy_source) is ConformalHybridMeshStrategySource:
        strategy = ConformalHybridMeshStrategy(surface_size_mm=optional_length("surface_size"))
    elif type(strategy_source) is OrthogonalHexMeshStrategySource:
        authored = strategy_source.directional_near_edge_by_direction
        directional: dict[ComponentLocalDirection, float] = {}
        for direction in COMPONENT_LOCAL_DIRECTIONS:
            expression = authored.get(direction)
            directional[direction] = (
                target_edge
                if expression is None
                else resolved.evaluate_expression(
                    expression,
                    dimension=TemplateDimension.LENGTH,
                    field_name=(
                        f"{context}.strategy.directional_near_edge."
                        f"{direction.value}"
                    ),
                )
            )
        strategy = OrthogonalHexMeshStrategy(
            directional,
            partition_origin,  # type: ignore[arg-type]
            sizing=strategy_source.sizing,
        )
    else:
        raise AssemblyPolicyError("component mesh strategy source is invalid")
    return GeneratedComponentMeshControl(
        target_edge_mm=target_edge,
        transition_distance_mm=transition_distance,
        strategy=strategy,
        mesh_priority=source.mesh_priority,
    )


def _generated_placement_expression(
    source: GeneratedInstancePlacementSource,
) -> GeneratedPlacementExpressionSource:
    if type(source) is not GeneratedInstancePlacementSource:
        raise AssemblyPolicyError(
            "generated instance placement source has an invalid type"
        )
    return GeneratedPlacementExpressionSource(
        translation_xyz=source.translation,
        rotation_deg_xyz=tuple(
            value if isinstance(value, str) else repr(value)
            for value in source.rotation_deg_xyz
        ),  # type: ignore[arg-type]
        pivot_xyz=source.pivot,
    )


def _compile_generated_instance(
    source: TemplateInstanceSource,
    template: _TemplateCompilationInputs,
) -> CompiledGeneratedInstance:
    instance = TemplateInstance(
        source.identifier,
        source.template_id,
        {},
    )
    template_result = compile_template_instance(template.definition, instance)
    placement_source = GeneratedPlacementExpressionSource()
    placement = compile_rigid_placement(
        placement_source,
        template_result.resolved_parameters,
        field_path=f"instance[{source.identifier}].placement",
    )
    resolved_mesh_controls = {
        component_id: _compile_component_mesh_control(
            mesh_control_source,
            template_result.resolved_parameters,
            context=(
                f"instance[{source.identifier}].component[{component_id}]"
                ".mesh_control"
            ),
        )
        for component_id, mesh_control_source in template.mesh_control_sources.items()
    }
    resolved_records = tuple(
        GeometryRecord(
            record.kind,
            record.geometry_ref,
            component_id=record.component_id,
            material_name=record.material_name,
            mesh_control=(
                resolved_mesh_controls[record.component_id]
                if record.kind is GeometryRecordKind.START_COMPONENT
                and record.component_id is not None
                else None
            ),
        )
        for record in template.records
    )
    placed_fragments = {
        fragment_id: GeometryFragmentSource(
            fragment.fragment_id,
            fragment.root,
            fragment.placement,
        )
        for fragment_id, fragment in template.fragments.items()
    }
    geometry_result = compile_generated_geometry_instance(
        instance_id=source.identifier,
        records=resolved_records,
        fragment_sources=placed_fragments,
        resolved=template_result.resolved_parameters,
    )

    descriptors: list[GeneratedComponentDescriptor] = []
    for component in geometry_result.geometry.components:
        fragments = tuple(
            IdentifierBinding(
                value.fragment_id,
                generated_fragment_global_id(
                    source.identifier,
                    value.fragment_id,
                ),
            )
            for value in component.fragments
        )
        global_id = generated_component_global_id(
            source.identifier,
            component.component_id,
        )
        mesh_control = resolved_mesh_controls[component.component_id]
        if (
            mesh_control is not None
            and type(mesh_control.strategy) is OrthogonalHexMeshStrategy
            and len(component.fragments) == 1
            and type(component.fragments[0].root) is CanonicalBox
        ):
            mesh_control.strategy.validate_single_box_sizes()
        policy_component = Component.generated(
            global_id,
            component.material_name,
            tuple(value.global_id for value in fragments),
            mesh_control=mesh_control,
        )
        descriptors.append(
            GeneratedComponentDescriptor(
                component.component_id,
                global_id,
                component.material_name,
                fragments,
                mesh_control,
                policy_component,
            )
        )
    placements = [fragment.placement for component in geometry_result.geometry.components for fragment in component.fragments]
    if all(value == placements[0] for value in placements):
        placement = placements[0]
    return CompiledGeneratedInstance(
        source.identifier,
        source.template_id,
        template_result,
        geometry_result,
        placement,
        tuple(descriptors),
        nested_placements=True,
    )


def _runtime_root(
    parsed: ParsedPackageV2Source,
    source_root: str | os.PathLike[str] | None,
) -> Path:
    if source_root is not None:
        if isinstance(source_root, bytes):
            raise AssemblyPolicyError("source_root must be a text path")
        raw_root = os.fspath(source_root)
    elif parsed.source_name.startswith("<") and parsed.source_name.endswith(">"):
        raise AssemblyPolicyError(
            "source_root is required for frozen artifacts when source_name "
            "is not a file path"
        )
    else:
        raw_root = os.fspath(Path(parsed.source_name).parent)
    return Path(os.path.abspath(raw_root))


def _runtime_artifact_path(root: Path, declaration: str) -> Path:
    relative = PurePosixPath(declaration)
    return Path(os.path.abspath(os.fspath(root.joinpath(*relative.parts))))


def _compile_frozen_placement(
    source: FrozenRigidPlacementSource,
    *,
    source_id: str,
    empty_resolved: ResolvedTemplateParameters,
) -> CanonicalFrozenPlacement:
    """Compile the independent frozen matrix form in the package frame."""

    translation_values: list[float] = []
    for index, expression in enumerate(source.translation):
        value = empty_resolved.evaluate_expression(
            expression,
            dimension=TemplateDimension.LENGTH,
            field_name=(
                f"frozen_source[{source_id}]"
                f".placement.translation[{index}]"
            ),
        )
        translation_values.append(_canonical_float(value))
    rotation = tuple(
        tuple(_canonical_float(value) for value in row)
        for row in source.rotation_matrix
    )
    return CanonicalFrozenPlacement(
        tuple(translation_values),  # type: ignore[arg-type]
        rotation,  # type: ignore[arg-type]
    )


def _compile_frozen_source(
    source: FrozenSourceDeclaration,
    *,
    root: Path,
    empty_resolved: ResolvedTemplateParameters,
) -> CompiledFrozenSource:
    artifacts = FrozenArtifactDescriptor(
        source.artifacts.mesh,
        _runtime_artifact_path(root, source.artifacts.mesh),
        source.artifacts.sha256,
    )
    placement = _compile_frozen_placement(
        source.placement,
        source_id=source.identifier,
        empty_resolved=empty_resolved,
    )
    bindings = tuple(
        IdentifierBinding(
            local_id,
            frozen_component_global_id(source.identifier, local_id),
        )
        for local_id in source.components
    )
    components = tuple(
        Component.frozen(binding.global_id, source.identifier)
        for binding in bindings
    )
    policy_source = FrozenSource(source.identifier, components)
    return CompiledFrozenSource(
        source.identifier,
        artifacts,
        placement,
        bindings,
        policy_source,
    )


def _mesh_control_payload(
    value: GeneratedComponentMeshControl | None,
) -> dict[str, object]:
    if value is None:
        return {"status": "unspecified"}
    payload: dict[str, object] = {
        "status": "explicit",
        "target_edge_mm": _canonical_float(value.target_edge_mm),
        "mesh_priority": value.mesh_priority,
        "transition_distance_mm": _canonical_float(
            value.transition_distance_mm
        ),
    }
    strategy = value.strategy
    if type(strategy) is StructuredSweepMeshStrategy:
        payload["strategy"] = {
            "kind": strategy.kind.value,
            "direction": strategy.direction.value,
        }
    elif type(strategy) is ConformalHybridMeshStrategy:
        payload["strategy"] = {"kind": strategy.kind.value}
    else:
        assert type(strategy) is OrthogonalHexMeshStrategy
        payload["strategy"] = {
            "kind": strategy.kind.value,
            "directional_near_edge_mm": {
                direction.value: _canonical_float(
                    strategy.directional_near_edge_mm[direction]
                )
                for direction in COMPONENT_LOCAL_DIRECTIONS
            },
            "partition_origin_mm": (
                None
                if strategy.partition_origin_mm is None
                else [
                    _canonical_float(value)
                    for value in strategy.partition_origin_mm
                ]
            ),
        }
    strategy_payload = payload["strategy"]
    if hasattr(strategy, "sizing") and strategy.sizing.to_dict() != {
            "constraint": "soft", "origin": "legacy", "remainder_ratio": .25}:
        strategy_payload["sizing"] = strategy.sizing.to_dict()
    for name in ("plane_size_mm", "layer_size_mm", "surface_size_mm", "plane_transition_distance_mm"):
        size = getattr(strategy, name, None)
        if size is not None:
            strategy_payload[name] = _canonical_float(size)
    if type(strategy) is StructuredSweepMeshStrategy and strategy.partition_origin_mm is not None:
        strategy_payload["partition_origin_mm"] = list(strategy.partition_origin_mm)
    return payload


def _generated_placement_payload(
    value: CanonicalGeneratedPlacement,
) -> dict[str, object]:
    return {
        "translation_xyz_mm": list(value.translation_xyz_mm),
        "rotation_deg_xyz": list(value.rotation_deg_xyz),
        "pivot_xyz_mm": list(value.pivot_xyz_mm),
    }


def _resolved_payload(result: TemplateCompileResult) -> list[dict[str, object]]:
    return [
        {
            "name": value.name,
            "dimension": value.dimension.value,
            "canonical_unit": value.canonical_unit,
            "value": _canonical_float(value.value),
        }
        for value in sorted(
            result.resolved_parameters.values,
            key=lambda item: item.name,
        )
    ]


def _plan_payload(result: PackageV2CompileResult) -> dict[str, object]:
    document = result.parsed_source.document
    generated_geometry_kinds = [
        "box",
        "rectangular_frame_extrusion",
        "rectangular_underfill_fillet",
    ]
    payload = {
        "schema": PACKAGE_V2_PLAN_SCHEMA,
        "source_schema_revision": document.schema_revision,
        "capabilities": {
            "generated_instance_placement": True,
            "generated_component_mesh_control": True,
            "generated_component_mesh_priority_required": True,
            "generated_component_mesh_priority_unique_in_final_package": True,
            "frozen_mesh_priority": 0,
            "generated_geometry_kinds": generated_geometry_kinds,
            "frozen_artifact_content_loaded": False,
        },
        "coordinate_semantics": {
            "generated_instance_placement": (
                "T + P + Rz @ Ry @ Rx @ (point - P)"
            ),
            "mesh_strategy_component_local": (
                "XYZ axes before target generated-instance rotation"
            ),
        },
        "mesh_settings": {
            "parallel_tet_candidates": document.mesh_settings.parallel_tet_candidates,
            "interface_geometry_tolerance_mm": _canonical_float(
                result.interface_geometry_tolerance_mm
            ),
            "scope": "package_mesh_policy",
        },
        "package": {
            "id": document.package.identifier,
            "family": document.package.family.value,
        },
        "generated_instances": [
            {
                "instance_id": value.instance_id,
                "template_id": value.template_id,
                "placement": _generated_placement_payload(value.placement),
                "resolved_variables": _resolved_payload(value.template_result),
                "geometry": canonical_geometry_to_jsonable(
                    value.geometry_result.geometry
                ),
                "component_identities": [
                    {
                        "local_component_id": component.local_component_id,
                        "global_component_id": component.global_component_id,
                        "mesh_control": _mesh_control_payload(
                            component.mesh_control
                        ),
                        "fragments": [
                            {
                                "local_fragment_id": fragment.local_id,
                                "global_fragment_id": fragment.global_id,
                            }
                            for fragment in component.fragments
                        ],
                    }
                    for component in value.components
                ],
            }
            for value in result.generated_instances
        ],
        "frozen_sources": [
            {
                "source_id": value.source_id,
                "artifacts": dict(value.artifacts.declarations),
                "mesh_sha256": value.artifacts.sha256,
                "placement": {
                    "translation_xyz_mm": list(
                        value.placement.translation_xyz_mm
                    ),
                    "rotation_matrix": [
                        list(row) for row in value.placement.rotation_matrix
                    ],
                },
                "component_identities": [
                    {
                        "local_component_id": component.local_id,
                        "global_component_id": component.global_id,
                        "mesh_priority": 0,
                    }
                    for component in value.components
                ],
            }
            for value in result.frozen_sources
        ],
        "assembly_policy": {
            "coupling": result.assembly_policy.coupling.value,
            "generated_components": [
                {
                    "component_id": value.identifier,
                    "material_name": value.material_name,
                    "geometry_refs": list(value.geometry_refs),
                    "mesh_control": _mesh_control_payload(value.mesh_control),
                }
                for value in result.assembly_policy.generated_components
            ],
            "frozen_sources": [
                {
                    "source_id": value.source_id,
                    "component_ids": list(value.component_ids),
                    "mesh_priority": 0,
                    "whole_source_frozen": value.whole_source_frozen,
                }
                for value in result.assembly_policy.frozen_sources
            ],
            "contact_discovery": "automatic_geometry",
        },
    }
    return payload


def compile_parsed_package_v2(
    parsed: ParsedPackageV2Source,
    *,
    source_root: str | os.PathLike[str] | None = None,
) -> PackageV2CompileResult:
    """Compile an already parsed document without reading frozen artifacts."""

    if not isinstance(parsed, ParsedPackageV2Source):
        raise PackageV2CompilationError(
            "source",
            "<root>",
            "parsed must be ParsedPackageV2Source",
        )
    document = parsed.document

    templates: dict[str, _TemplateCompilationInputs] = {}
    for source in document.templates:
        context = f"template[{source.identifier}]"
        try:
            templates[source.identifier] = _compile_template_source(source)
        except (AssemblyPolicyError, GeometryCompilationError) as error:
            _raise_context("template", context, error)

    generated: list[CompiledGeneratedInstance] = []
    for source in document.instances:
        context = f"instance[{source.identifier}]"
        try:
            generated.append(
                _compile_generated_instance(
                    source,
                    templates[source.template_id],
                )
            )
        except (AssemblyPolicyError, GeometryCompilationError) as error:
            _raise_context("instance", context, error)

    frozen: list[CompiledFrozenSource] = []
    empty_resolved: ResolvedTemplateParameters | None = None
    if document.frozen_sources:
        try:
            root = _runtime_root(parsed, source_root)
            empty_resolved = resolve_template_parameters(())
        except (AssemblyPolicyError, OSError, TypeError, ValueError) as error:
            _raise_context("frozen source", "runtime root", error)
        for source in document.frozen_sources:
            context = f"frozen_source[{source.identifier}]"
            try:
                frozen.append(
                    _compile_frozen_source(
                        source,
                        root=root,
                        empty_resolved=empty_resolved,
                    )
                )
            except (AssemblyPolicyError, OSError, TypeError, ValueError) as error:
                _raise_context("frozen source", context, error)

    generated_components = tuple(
        component.policy_component
        for instance in generated
        for component in instance.components
    )
    generated_priorities: dict[int, str] = {}
    for component in generated_components:
        control = component.mesh_control
        if control is None:
            raise PackageV2CompilationError(
                "mesh control",
                f"generated_component[{component.identifier}]",
                "every generated Component must declare an explicit mesh_control",
            )
        previous = generated_priorities.get(control.mesh_priority)
        if previous is not None:
            raise PackageV2CompilationError(
                "mesh control",
                f"generated_component[{component.identifier}]",
                "mesh_priority must be unique among generated Components in "
                f"the final package; priority {control.mesh_priority} is also "
                f"used by {previous!r}",
            )
        generated_priorities[control.mesh_priority] = component.identifier
    try:
        policy = PackageAssemblyPolicy(
            generated_components,
            tuple(value.policy_source for value in frozen),
            (),  # Contacts are derived from geometry, never Source declarations.
            allow_empty=True,
        )
        return PackageV2CompileResult(
            parsed,
            tuple(value.definition for value in templates.values()),
            tuple(generated),
            tuple(frozen),
            policy,
        )
    except (AssemblyPolicyError, TypeError, ValueError) as error:
        _raise_context("assembly", f"package[{document.package.identifier}]", error)


def compile_package_v2(
    data: bytes,
    *,
    source_name: str = "<memory>",
    source_root: str | os.PathLike[str] | None = None,
) -> PackageV2CompileResult:
    """Parse and purely compile exact Package V2 JSON bytes."""

    try:
        parsed = parse_package_v2_json(data, source_name=source_name)
    except PackageV2SourceError as error:
        context = error.pointer if error.pointer else "<root>"
        _raise_context("source", context, error)
    return compile_parsed_package_v2(parsed, source_root=source_root)


__all__ = [
    "GENERATED_INSTANCE_PLACEMENT_SUPPORTED",
    "PACKAGE_V2_PLAN_SCHEMA",
    "CanonicalFrozenPlacement",
    "CanonicalGeneratedPlacement",
    "CompiledFrozenSource",
    "CompiledGeneratedInstance",
    "FrozenArtifactDescriptor",
    "GeneratedComponentDescriptor",
    "IdentifierBinding",
    "PackageV2CompilationError",
    "PackageV2CompileResult",
    "compile_package_v2",
    "compile_parsed_package_v2",
    "frozen_component_global_id",
    "generated_component_global_id",
    "generated_fragment_global_id",
]
