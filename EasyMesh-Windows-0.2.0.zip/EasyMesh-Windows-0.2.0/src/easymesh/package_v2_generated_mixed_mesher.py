"""Public generated-only adapter for the common role-free Package V2 executor.

This module intentionally contains no second geometry or volume-meshing path.
Canonical Box, Frame and RectangularUnderfillFillet inputs are lowered by
``package_v2_generated_role_free_mesher`` into the same adjacency, surface-
authority and component-backend executor used by mixed Frozen/generated
Sources.  The public result below is assembled only from executed backend
evidence and the reopened MSH audit.

Component names, materials and stack position never select a topology.  The
only volume modes are the three explicit Component requirements:
``structured_sweep``, ``orthogonal_hex`` and ``conformal_hybrid``.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
import hashlib
import json
import math
from pathlib import Path
from types import MappingProxyType
from typing import Mapping, Sequence

from .package_assembly import GeneratedComponentMeshControl
from .package_v2_generated_role_free_mesher import (
    execute_generated_role_free_mesh,
)
from .package_v2_geometry import CanonicalGeneratedGeometry
from .package_v2_mesher import GeneratedComponentKey
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
)
from .package_v2_mixed_mesh_assembly import (
    AssembledCompleteSupportPlaneInterface,
    _polygon_area_3d,
)
from .package_v2_mixed_mesh_audit import numbered_mixed_mesh_sha256
from .package_v2_orthogonal_candidates import orthogonal_execution_metadata


_QUALITY_FLOOR = 0.03


class GeneratedMixedMeshError(RuntimeError):
    """A generated-only mixed mesh could not satisfy its explicit contract."""


def _positive(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise GeneratedMixedMeshError(f"{field_name} must be positive and finite")
    result = float(value)
    if not math.isfinite(result) or result <= 0.0:
        raise GeneratedMixedMeshError(f"{field_name} must be positive and finite")
    return result


@dataclass(frozen=True, slots=True)
class GeneratedMixedMeshControls:
    random_seed: int = 1
    optimize: bool = True
    maximum_element_count: int = 2_000_000
    minimum_quality: float = _QUALITY_FLOOR

    def __post_init__(self) -> None:
        if (
            isinstance(self.random_seed, bool)
            or not isinstance(self.random_seed, int)
            or not 0 <= self.random_seed <= 2_147_483_647
        ):
            raise GeneratedMixedMeshError("random_seed is outside Gmsh's range")
        if not isinstance(self.optimize, bool):
            raise GeneratedMixedMeshError("optimize must be boolean")
        if (
            isinstance(self.maximum_element_count, bool)
            or not isinstance(self.maximum_element_count, int)
            or self.maximum_element_count < 1
        ):
            raise GeneratedMixedMeshError(
                "maximum_element_count must be a positive integer"
            )
        floor = _positive(self.minimum_quality, field_name="minimum_quality")
        if floor >= 1.0:
            raise GeneratedMixedMeshError("minimum_quality must be less than one")
        object.__setattr__(self, "minimum_quality", floor)


@dataclass(frozen=True, slots=True)
class GeneratedMixedComponentAudit:
    key: GeneratedComponentKey
    requested_topology: str
    target_edge_mm: float
    transition_distance_mm: float
    applied_backend: str
    backend_provenance: str
    element_kind_counts: Mapping[str, int]
    canonical_fragment_count: int
    analytic_target_volume_mm3: float
    reopened_volume_mm3: float
    relative_volume_error: float
    full_boundary_preserved: bool
    cartesian_hex_verified: bool
    minimum_sicn: float
    orthogonal_sicn_aspect_ratio_exempted: bool
    orthogonal_hex_continuation_sicn_aspect_ratio_exempted: bool = False
    orthogonal_hex_continuation_element_count: int = 0
    orthogonal_hex_continuation_minimum_sicn: float | None = None
    orthogonal_hex_continuation_producer_component_ids: tuple[str, ...] = ()
    orthogonal_hex_continuation_contract_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "element_kind_counts",
            MappingProxyType(dict(self.element_kind_counts)),
        )
        if not math.isfinite(self.minimum_sicn):
            raise GeneratedMixedMeshError(
                "generated Component minimum_sicn must be finite"
            )
        if self.orthogonal_sicn_aspect_ratio_exempted and (
            self.requested_topology != "orthogonal_hex"
            or not self.cartesian_hex_verified
            or self.minimum_sicn <= 0.0
        ):
            raise GeneratedMixedMeshError(
                "SICN aspect-ratio exemption requires a Cartesian Orth component"
            )
        continuation_exempted = (
            self.orthogonal_hex_continuation_sicn_aspect_ratio_exempted
        )
        if continuation_exempted:
            if (
                self.requested_topology != "conformal_hybrid"
                or self.orthogonal_hex_continuation_element_count < 1
                or self.orthogonal_hex_continuation_minimum_sicn is None
                or not math.isfinite(
                    self.orthogonal_hex_continuation_minimum_sicn
                )
                or self.orthogonal_hex_continuation_minimum_sicn <= 0.0
                or self.orthogonal_hex_continuation_minimum_sicn
                >= _QUALITY_FLOOR
                or not self.orthogonal_hex_continuation_producer_component_ids
                or not self.orthogonal_hex_continuation_contract_ids
            ):
                raise GeneratedMixedMeshError(
                    "Orth-origin HEX continuation exemption lacks exact "
                    "Hybrid/Orth interface evidence"
                )
        elif (
            self.orthogonal_hex_continuation_element_count != 0
            or self.orthogonal_hex_continuation_minimum_sicn is not None
            or self.orthogonal_hex_continuation_producer_component_ids
            or self.orthogonal_hex_continuation_contract_ids
        ):
            raise GeneratedMixedMeshError(
                "unused Orth-origin HEX continuation evidence is inconsistent"
            )


@dataclass(frozen=True, slots=True)
class GeneratedMixedInterfaceAudit:
    interface_id: str
    first: GeneratedComponentKey
    second: GeneratedComponentKey
    producer: GeneratedComponentKey
    consumer: GeneratedComponentKey
    producer_mesh_priority: int
    consumer_mesh_priority: int
    required_facet_policy: str
    geometric_patch_count: int
    surface_policy: str
    contact_domain: str
    analytic_candidate_area_mm2: float
    authoritative_contact_area_mm2: float
    producer_contact_coverage_ratio: float
    consumer_contact_coverage_ratio: float
    analytic_approximation_ratio: float
    analytic_uncovered_area_mm2: float
    analytic_overshoot_area_mm2: float
    negotiated_target_edge_mm: float
    first_transition_distance_mm: float
    second_transition_distance_mm: float
    facet_kind_counts: Mapping[str, int]
    shared_node_count: int
    maximum_facet_edge_mm: float
    shared_facet_sha256: str
    shared_nodes_verified: bool

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "facet_kind_counts",
            MappingProxyType(dict(self.facet_kind_counts)),
        )
        if self.contact_domain not in {
            "canonical_analytic_contact",
            "orthogonal_staircase_contact",
        }:
            raise GeneratedMixedMeshError(
                "interface has an unknown materialized contact domain"
            )
        _positive(self.analytic_candidate_area_mm2, field_name="analytic_candidate_area_mm2")
        for field_name in (
            "authoritative_contact_area_mm2",
            "analytic_uncovered_area_mm2",
            "analytic_overshoot_area_mm2",
        ):
            value = getattr(self, field_name)
            if not math.isfinite(value) or value < 0.0:
                raise GeneratedMixedMeshError(
                    "analytic comparison areas must be finite and non-negative"
                )
        if any(not math.isfinite(ratio) or not 0.0 <= ratio <= 1.0 + 1.e-12 for ratio in (
            self.producer_contact_coverage_ratio, self.consumer_contact_coverage_ratio
        )):
            raise GeneratedMixedMeshError(
                "actual contact coverage ratios must be between zero and one"
            )
        expected_approximation = (
            self.authoritative_contact_area_mm2
            / self.analytic_candidate_area_mm2
        )
        if not math.isclose(
            self.analytic_approximation_ratio,
            expected_approximation,
            rel_tol=1.0e-12,
            abs_tol=1.0e-12,
        ):
            raise GeneratedMixedMeshError(
                "interface analytic approximation evidence is inconsistent"
            )


@dataclass(frozen=True, slots=True)
class GeneratedMixedMeshSummary:
    mesh_path: str
    node_count: int
    element_count: int
    global_element_kind_counts: Mapping[str, int]
    components: Mapping[GeneratedComponentKey, GeneratedMixedComponentAudit]
    interfaces: tuple[GeneratedMixedInterfaceAudit, ...]
    duplicate_node_count: int
    nonmanifold_face_count: int
    min_jacobian_determinant: float
    min_scaled_jacobian: float
    min_sicn: float
    min_sige: float
    numbered_mesh_sha256: str
    mesh_artifact: Mapping[str, str | int]
    written_mesh_reopened_verified: bool
    strategy_aware_quality_floor_met: bool
    complete_support_plane_interfaces: tuple[
        AssembledCompleteSupportPlaneInterface, ...
    ]
    complete_support_plane_area_mm2_by_interface_key: Mapping[str, float]
    complete_support_plane_facet_count_by_interface_key: Mapping[str, int]
    complete_support_plane_interfaces_verified: bool
    unpaired_coplanar_free_faces_verified: bool
    orthogonal_metadata: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "complete_support_plane_interfaces",
            tuple(self.complete_support_plane_interfaces),
        )
        object.__setattr__(
            self,
            "global_element_kind_counts",
            MappingProxyType(dict(self.global_element_kind_counts)),
        )
        object.__setattr__(self, "components", MappingProxyType(dict(self.components)))
        object.__setattr__(
            self,
            "mesh_artifact",
            MappingProxyType(dict(self.mesh_artifact)),
        )
        for field_name in (
            "complete_support_plane_area_mm2_by_interface_key",
            "complete_support_plane_facet_count_by_interface_key",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )
        interface_keys = tuple(
            value.interface_key
            for value in self.complete_support_plane_interfaces
            if type(value) is AssembledCompleteSupportPlaneInterface
        )
        if (
            any(
                type(value) is not AssembledCompleteSupportPlaneInterface
                for value in self.complete_support_plane_interfaces
            )
            or len(interface_keys) != len(set(interface_keys))
            or set(interface_keys)
            != set(self.complete_support_plane_area_mm2_by_interface_key)
            or set(interface_keys)
            != set(self.complete_support_plane_facet_count_by_interface_key)
            or any(
                not value.interface_key
                or not value.first_fragment_key
                or not value.second_fragment_key
                or value.first_fragment_key == value.second_fragment_key
                or value.plane_axis not in {0, 1, 2}
                or not math.isfinite(value.plane_coordinate_mm)
                or not value.face_node_tags
                or any(
                    len(face) not in {3, 4} or len(set(face)) != len(face)
                    for face in value.face_node_tags
                )
                or not math.isfinite(value.area_mm2)
                or value.area_mm2 <= 0.0
                or self.complete_support_plane_facet_count_by_interface_key[
                    value.interface_key
                ]
                != len(value.face_node_tags)
                or not math.isclose(
                    self.complete_support_plane_area_mm2_by_interface_key[
                        value.interface_key
                    ],
                    value.area_mm2,
                    rel_tol=1.0e-12,
                    abs_tol=1.0e-12,
                )
                for value in self.complete_support_plane_interfaces
            )
            or self.written_mesh_reopened_verified is not True
            or self.complete_support_plane_interfaces_verified is not True
            or self.unpaired_coplanar_free_faces_verified is not True
        ):
            raise GeneratedMixedMeshError(
                "generated mixed summary requires complete final-interface "
                "audit evidence"
            )
        if self.strategy_aware_quality_floor_met is not True:
            raise GeneratedMixedMeshError(
                "generated mixed summary requires strategy-aware quality proof"
            )


def _semantic_facet_sha256(
    facets: Sequence[Sequence[int]],
    semantic_tokens_by_node_id: Mapping[int, str],
) -> str:
    payload = tuple(
        sorted(
            tuple(sorted(semantic_tokens_by_node_id[int(node)] for node in facet))
            for facet in facets
        )
    )
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _role_free_generated_summary(
    geometries: Sequence[CanonicalGeneratedGeometry],
    mesh_controls: Mapping[GeneratedComponentKey, GeneratedComponentMeshControl],
    output_path: str | Path,
    controls: GeneratedMixedMeshControls,
    interface_geometry_tolerance_mm: float,
    *,
    verbose: bool,
) -> GeneratedMixedMeshSummary:
    if controls.random_seed != 1 or controls.optimize is not True:
        raise GeneratedMixedMeshError(
            "the common role-free executor currently has one audited deterministic "
            "control profile: random_seed=1 and optimize=true"
        )
    try:
        run = execute_generated_role_free_mesh(
            geometries,
            mesh_controls,
            output_path,
            minimum_quality=controls.minimum_quality,
            maximum_element_count=controls.maximum_element_count,
            interface_geometry_tolerance_mm=(
                interface_geometry_tolerance_mm
            ),
            verbose=verbose,
        )
    except GeneratedMixedMeshError:
        raise
    except Exception as error:
        raise GeneratedMixedMeshError(str(error)) from error

    audit = run.reopen_audit
    execution = run.execution
    component_audits: dict[
        GeneratedComponentKey, GeneratedMixedComponentAudit
    ] = {}
    for global_id, key in sorted(run.key_by_global_component_id.items()):
        requirement = run.context.lowering.component_mesh_requirements[global_id]
        evidence = execution.component_evidence_by_id[global_id]
        if evidence.applied_backend is None:
            raise GeneratedMixedMeshError(
                f"generated Component {key!r} has no applied backend evidence"
            )
        reopened_counts = audit.component_element_kind_counts[global_id]
        if dict(evidence.element_kind_counts) != dict(reopened_counts):
            raise GeneratedMixedMeshError(
                f"generated Component {key!r} backend kinds changed after reopen"
            )
        provenances = tuple(
            sorted(
                {
                    element.provenance
                    for fragment in execution.components_by_id[
                        global_id
                    ].fragments_by_id.values()
                    for element in fragment.elements
                }
            )
        )
        if not provenances:
            raise GeneratedMixedMeshError(
                f"generated Component {key!r} has no backend provenance"
            )
        analytic_volume = run.analytic_target_volume_mm3_by_key[key]
        reopened_volume = audit.component_quality[global_id].volume_mm3
        component_audits[key] = GeneratedMixedComponentAudit(
            key,
            requirement.volume_topology,
            requirement.target_edge_mm,
            requirement.transition_distance_mm,
            evidence.applied_backend,
            "+".join(provenances),
            reopened_counts,
            run.canonical_fragment_count_by_key[key],
            analytic_volume,
            reopened_volume,
            abs(reopened_volume - analytic_volume) / analytic_volume,
            True,
            audit.orthogonal_cartesian_hex_verified.get(global_id, False),
            audit.component_quality[global_id].minimum_sicn,
            global_id in audit.orthogonal_sicn_aspect_ratio_exemptions,
            global_id
            in audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions,
            (
                0
                if global_id
                not in audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions
                else audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions[
                    global_id
                ].element_count
            ),
            (
                None
                if global_id
                not in audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions
                else audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions[
                    global_id
                ].minimum_sicn
            ),
            (
                ()
                if global_id
                not in audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions
                else audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions[
                    global_id
                ].producer_component_ids
            ),
            (
                ()
                if global_id
                not in audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions
                else audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions[
                    global_id
                ].shared_surface_sizing_contract_ids
            ),
        )

    contract_by_id = {
        value.face_pair_id: value
        for value in run.context.adjacency_execution.face_pairs
    }
    authority_by_id = execution.plan.authority_plan.authority_by_face_pair_id
    ordering_constraint_by_id = {
        value.face_pair_id: value
        for value in run.context.mesh_ordering.constraints
        if value.face_pair_id is not None
    }
    if set(ordering_constraint_by_id) != set(authority_by_id):
        raise GeneratedMixedMeshError(
            "generated summary ordering constraints differ from actual faces"
        )
    interfaces: list[GeneratedMixedInterfaceAudit] = []
    for face_pair_id, facet_set in sorted(
        execution.interface_facet_sets_by_face_pair_id.items()
    ):
        contract = contract_by_id[face_pair_id]
        authority = authority_by_id[face_pair_id]
        ordering_constraint = ordering_constraint_by_id[face_pair_id]
        if (
            authority.producer_component_id
            != ordering_constraint.producer_component_id
            or authority.consumer_component_id
            != ordering_constraint.consumer_component_id
        ):
            raise GeneratedMixedMeshError(
                "generated summary authority direction differs from mesh priority"
            )
        patch = execution.surface_patches_by_face_pair_id[face_pair_id]
        first_global = contract.first_side.component_id
        second_global = contract.second_side.component_id
        first_key = run.key_by_global_component_id[first_global]
        second_key = run.key_by_global_component_id[second_global]
        if second_key < first_key:
            first_key, second_key = second_key, first_key
            first_global, second_global = second_global, first_global
        producer_key = run.key_by_global_component_id[
            ordering_constraint.producer_component_id
        ]
        consumer_key = run.key_by_global_component_id[
            ordering_constraint.consumer_component_id
        ]
        facet_counts = Counter(
            "TRI3" if len(facet) == 3 else "QUAD4"
            for facet in facet_set.producer_facets
        )
        referenced = {node for facet in facet_set.producer_facets for node in facet}
        shared_area = math.fsum(
            _polygon_area_3d(tuple(patch.node_coordinates_package_mm[n] for n in facet))
            for facet in facet_set.producer_facets
        )
        producer_area = patch.contact_audit.authoritative_contact_area_mm2
        analytic_area = patch.contact_audit.analytic_candidate_area_mm2
        if len(facet_set.producer_facets) == len(patch.facets):
            shared_area = producer_area
        maximum_edge = max(
            (math.dist(
                patch.node_coordinates_package_mm[facet[index]],
                patch.node_coordinates_package_mm[
                    facet[(index + 1) % len(facet)]
                ],
            )
            for facet in facet_set.producer_facets
            for index in range(len(facet))), default=0.0,
        )
        interfaces.append(
            GeneratedMixedInterfaceAudit(
                face_pair_id,
                first_key,
                second_key,
                producer_key,
                consumer_key,
                ordering_constraint.producer_priority,
                ordering_constraint.consumer_priority,
                ordering_constraint.required_facet_policy,
                contract.geometric_patch_count,
                authority.surface_policy,
                patch.contact_audit.contact_domain,
                patch.contact_audit.analytic_candidate_area_mm2,
                shared_area,
                shared_area / producer_area if producer_area else 0.0,
                1.0,
                shared_area / analytic_area,
                max(0.0, analytic_area - shared_area),
                max(0.0, shared_area - analytic_area),
                ordering_constraint.negotiated_target_edge_mm,
                contract.transition_distance_mm_by_component[first_global],
                contract.transition_distance_mm_by_component[second_global],
                dict(sorted(facet_counts.items())),
                len(referenced),
                maximum_edge,
                _semantic_facet_sha256(
                    facet_set.producer_facets,
                    patch.semantic_tokens_by_node_id,
                ),
                True,
            )
        )

    return GeneratedMixedMeshSummary(
        str(run.write_result.output_path),
        audit.node_count,
        audit.element_count,
        dict(
            sorted(
                Counter(
                    element.kind.value for element in audit.mesh.elements
                ).items()
            )
        ),
        component_audits,
        tuple(interfaces),
        audit.duplicate_node_count,
        0,
        audit.minimum_jacobian_determinant,
        audit.minimum_scaled_jacobian,
        audit.minimum_sicn,
        audit.minimum_sige,
        numbered_mixed_mesh_sha256(audit.mesh),
        run.write_result.artifact,
        audit.numbered_plan_replay_verified,
        audit.strategy_aware_quality_floor_met,
        run.write_result.plan.complete_support_plane_interfaces,
        audit.complete_support_plane_area_mm2_by_interface_key,
        audit.complete_support_plane_facet_count_by_interface_key,
        audit.complete_support_plane_interfaces_verified,
        audit.unpaired_coplanar_free_faces_verified,
        orthogonal_execution_metadata(execution, run.write_result),
    )


def build_generated_mixed_mesh(
    geometries: Sequence[CanonicalGeneratedGeometry],
    mesh_controls: Mapping[GeneratedComponentKey, GeneratedComponentMeshControl],
    output_path: str | Path,
    *,
    controls: GeneratedMixedMeshControls = GeneratedMixedMeshControls(),
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
    verbose: bool = False,
) -> GeneratedMixedMeshSummary:
    """Build, publish, reopen and audit through the one role-free executor."""

    if type(controls) is not GeneratedMixedMeshControls:
        raise GeneratedMixedMeshError("controls must be GeneratedMixedMeshControls")
    if not isinstance(verbose, bool):
        raise GeneratedMixedMeshError("verbose must be boolean")
    return _role_free_generated_summary(
        geometries,
        mesh_controls,
        output_path,
        controls,
        interface_geometry_tolerance_mm,
        verbose=verbose,
    )


__all__ = [
    "GeneratedMixedComponentAudit",
    "GeneratedMixedInterfaceAudit",
    "GeneratedMixedMeshControls",
    "GeneratedMixedMeshError",
    "GeneratedMixedMeshSummary",
    "build_generated_mixed_mesh",
]
