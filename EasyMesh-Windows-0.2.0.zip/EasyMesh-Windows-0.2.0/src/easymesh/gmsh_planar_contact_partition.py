"""Gmsh OCC imprint of contact boundaries into unlocked planar mesh regions."""
from __future__ import annotations

import math
from .gmsh_runtime import isolated_gmsh_model
from .gmsh_shared_surface import PlanarRegion, SharedSurfaceMeshingError, _load_gmsh


def add_occ_contact_surfaces(gmsh, loops):
    """Create geometry-only imprint tools; no mesh connectivity is authored."""
    surfaces = []
    for loop in loops:
        points = [gmsh.model.occ.addPoint(*p) for p in loop]
        curves = [gmsh.model.occ.addLine(a, b) for a, b in zip(points, points[1:] + points[:1])]
        surfaces.append(gmsh.model.occ.addPlaneSurface([gmsh.model.occ.addCurveLoop(curves)]))
    return surfaces


def partition_contact_regions(coordinates, regions, locked, loops):
    # Lateral contact loops can project to a line on a sweep section. Their
    # axial boundaries are handled by the sweep layer planner; they are not
    # two-dimensional OCC imprint tools on this plane.
    def nondegenerate(points):
        normal = [
            sum(
                p[(a + 1) % 3] * q[(a + 2) % 3] - p[(a + 2) % 3] * q[(a + 1) % 3]
                for p, q in zip(points, (*points[1:], points[0]))
            )
            for a in range(3)
        ]
        return len(set(points)) >= 3 and max(map(abs, normal)) > 1.0e-20

    loops = tuple(points for points in loops if nondegenerate(points))
    if not loops:
        return coordinates, regions
    coordinates = dict(coordinates)
    by_point = {tuple(round(v, 12) for v in p): n for n, p in coordinates.items()}
    gmsh = _load_gmsh()
    with isolated_gmsh_model(gmsh, "__contact_partition", number_options={"General.Terminal": 0}):
        def point_tag(point):
            return gmsh.model.occ.addPoint(*point)
        def loop_tag(points):
            tags = [point_tag(p) for p in points]
            return gmsh.model.occ.addCurveLoop([
                gmsh.model.occ.addLine(a, b) for a, b in zip(tags, tags[1:] + tags[:1])
            ])
        def region_surface(region):
            outer = [coordinates[n] for n in region.outer_loop]
            surface = gmsh.model.occ.addPlaneSurface([loop_tag(outer)])
            holes = []
            for cycle in region.holes:
                hole = [coordinates[n] for n in cycle]
                holes.append((2, gmsh.model.occ.addPlaneSurface([loop_tag(hole)])))
            if holes:
                # Explicit geometric subtraction avoids OCC interpreting a
                # complex inherited inner wire as additional face area. Only
                # CAD tools change; original locked facets remain untouched.
                output, _ = gmsh.model.occ.cut([(2, surface)], holes)
                faces = [tag for dim, tag in output if dim == 2]
                if len(faces) != 1:
                    raise SharedSurfaceMeshingError("contact imprint region holes did not define one planar region")
                surface = faces[0]
            return surface
        unlocked = [r for r in regions if r.label not in locked]
        objects = [(2, region_surface(r)) for r in unlocked]
        tools = [(2, gmsh.model.occ.addPlaneSurface([loop_tag(points)])) for points in loops]
        if not objects:
            return coordinates, regions
        _, mapping = gmsh.model.occ.fragment(objects, tools)
        gmsh.model.occ.synchronize()
        result = [r for r in regions if r.label in locked]
        def source_node(tag):
            point = tuple(float(v) for v in gmsh.model.getValue(0, tag, []))
            key = tuple(round(v, 12) for v in point)
            if key not in by_point:
                node = max(coordinates, default=0) + 1
                by_point[key] = node
                coordinates[node] = point
            return by_point[key]
        for region, outputs in zip(unlocked, mapping):
            for _, surface in sorted(set((int(d), int(t)) for d, t in outputs if d == 2)):
                _, curve_loops = gmsh.model.occ.getCurveLoops(surface)
                cycles = []
                for curves in curve_loops:
                    edges = [tuple(int(t) for _, t in gmsh.model.getBoundary([(1, abs(int(c)))], oriented=False)) for c in curves]
                    if any(len(e) != 2 for e in edges):
                        raise SharedSurfaceMeshingError("contact imprint did not produce straight closed loops")
                    a, b = edges.pop(0)
                    cycle, current = [a], b
                    while current != cycle[0]:
                        cycle.append(current)
                        index = next((i for i, edge in enumerate(edges) if current in edge), None)
                        if index is None:
                            raise SharedSurfaceMeshingError("contact imprint boundary is open")
                        edge = edges.pop(index)
                        current = edge[1] if edge[0] == current else edge[0]
                    if edges:
                        raise SharedSurfaceMeshingError("contact imprint boundary branches")
                    cycles.append(tuple(source_node(t) for t in cycle))
                def area(cycle):
                    pts = [coordinates[n] for n in cycle]
                    normal = [0., 0., 0.]
                    for a, b in zip(pts, pts[1:] + pts[:1]):
                        for axis in range(3):
                            normal[axis] += a[(axis+1)%3]*b[(axis+2)%3] - a[(axis+2)%3]*b[(axis+1)%3]
                    return math.sqrt(sum(v*v for v in normal))
                cycles.sort(key=area, reverse=True)
                result.append(PlanarRegion(f"{region.label}/contact/{surface}", cycles[0], tuple(cycles[1:]), region.recombine))
        # No imprint may split an inherited boundary edge. It must be planned
        # earlier if the cut would pass through an immutable upstream facet.
        for region in regions:
            if region.label not in locked:
                continue
            for cycle in (region.outer_loop, *region.holes):
                for a, b in zip(cycle, cycle[1:] + cycle[:1]):
                    pa, pb = coordinates[a], coordinates[b]
                    length = math.dist(pa, pb)
                    for node, point in coordinates.items():
                        if node not in (a, b) and min(math.dist(pa, point), math.dist(pb, point)) > 1e-10 and abs(math.dist(pa, point) + math.dist(point, pb) - length) < 1e-11:
                            raise SharedSurfaceMeshingError("contact imprint would split an immutable inherited edge")
    return coordinates, tuple(result)
