"""Immutable template-instance compilation and resolution provenance.

This module sits above :mod:`easymesh.package_assembly`'s typed scalar
resolver.  It records source declarations and raw instance inputs while the
meshing boundary continues to consume only canonical millimetre or
dimensionless values.

``declared_units`` are source metadata in this slice.  Omitting them defaults
length variables to ``mm`` and dimensionless variables to ``1`` so callers of
the existing canonical-value API remain concise.  A future V2 source parser
must provide and validate explicit units; this module never uses declared-unit
metadata to rescale a numeric default or override.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import hashlib
import io
import json
import keyword
import math
import tokenize
from types import MappingProxyType
from typing import Mapping

from .package_assembly import (
    AssemblyPolicyError,
    DerivedVariable,
    ResolvedTemplateParameters,
    TemplateDimension,
    TemplateParameter,
    TemplateScalar,
    TemplateValueSource,
    resolve_template_parameters,
)


TEMPLATE_PROVENANCE_SCHEMA_VERSION = 1
TEMPLATE_EVALUATOR_VERSION = "package-assembly-scalar-v1"
_LENGTH_DECLARED_UNITS = frozenset(
    {"mm", "um", "\N{MICRO SIGN}m", "\N{GREEK SMALL LETTER MU}m"}
)
_RESERVED_IDENTIFIERS = frozenset(
    {*_LENGTH_DECLARED_UNITS, "__easymesh_length__"}
)


def _identifier(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AssemblyPolicyError(f"{field_name} must be a non-empty identifier")
    identifier = value.strip()
    if (
        not identifier.isascii()
        or not identifier.isidentifier()
        or keyword.iskeyword(identifier)
        or identifier.lower() in _RESERVED_IDENTIFIERS
    ):
        raise AssemblyPolicyError(
            f"{field_name} must be a non-reserved ASCII identifier"
        )
    return identifier


def _tuple(value: object, *, field_name: str) -> tuple[object, ...]:
    if isinstance(value, (str, bytes)):
        raise AssemblyPolicyError(f"{field_name} must be a sequence")
    try:
        return tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise AssemblyPolicyError(f"{field_name} must be a sequence") from error


def _dimension(value: object, *, field_name: str) -> TemplateDimension:
    if isinstance(value, TemplateDimension):
        return value
    if isinstance(value, str):
        try:
            return TemplateDimension(value)
        except ValueError as error:
            raise AssemblyPolicyError(
                f"{field_name} must be 'length' or 'dimensionless'"
            ) from error
    raise AssemblyPolicyError(f"{field_name} must be a TemplateDimension")


def _raw_scalar(
    value: object,
    *,
    field_name: str,
    allow_none: bool = False,
) -> TemplateScalar | None:
    if value is None and allow_none:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise AssemblyPolicyError(
            f"{field_name} must be a numeric value or scalar expression"
        )
    if isinstance(value, float) and not math.isfinite(value):
        raise AssemblyPolicyError(f"{field_name} must be finite")
    if isinstance(value, str) and not value.strip():
        raise AssemblyPolicyError(f"{field_name} must not be blank")
    return value


def _declared_unit(
    value: object,
    dimension: TemplateDimension,
    *,
    field_name: str,
) -> str:
    if not isinstance(value, str):
        raise AssemblyPolicyError(f"{field_name} must be a string")
    if dimension is TemplateDimension.LENGTH:
        if value not in _LENGTH_DECLARED_UNITS:
            raise AssemblyPolicyError(
                f"{field_name} must be mm, um, \N{MICRO SIGN}m, or "
                "\N{GREEK SMALL LETTER MU}m for a length"
            )
        return value
    if value != "1":
        raise AssemblyPolicyError(
            f"{field_name} must be '1' for a dimensionless variable"
        )
    return value


def _default_declared_unit(dimension: TemplateDimension) -> str:
    return "mm" if dimension is TemplateDimension.LENGTH else "1"


def _canonical_json(payload: object) -> str:
    try:
        return json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    except (OverflowError, TypeError, ValueError) as error:
        raise AssemblyPolicyError(
            "template provenance contains a non-canonical JSON value"
        ) from error


def _sha256(canonical_json: str) -> str:
    return hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()


def _canonical_resolved_number(value: float) -> float:
    # Positive and negative zero are the same canonical scalar.  Their raw
    # spelling remains distinguishable in the source snapshot.
    return 0.0 if value == 0.0 else value


class TemplateVariableRole(str, Enum):
    """Whether a provenance entry is an input or a read-only expression."""

    PARAMETER = "parameter"
    DERIVED = "derived"


@dataclass(frozen=True, slots=True)
class TemplateDefinition:
    """One immutable template declaration.

    ``declared_units`` is metadata only.  Numeric length values in the reused
    resolver are already canonical millimetres even when this metadata says
    ``um``/``µm``/``μm``.  A source parser must convert source numbers before
    constructing this semantic IR.
    """

    template_id: str
    parameters: tuple[TemplateParameter, ...]
    derived_variables: tuple[DerivedVariable, ...] = ()
    declared_units: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "template_id",
            _identifier(self.template_id, field_name="template_id"),
        )
        parameters = _tuple(self.parameters, field_name="template parameters")
        derived = _tuple(self.derived_variables, field_name="derived variables")
        if any(not isinstance(value, TemplateParameter) for value in parameters):
            raise AssemblyPolicyError(
                "parameters must contain TemplateParameter values"
            )
        if any(not isinstance(value, DerivedVariable) for value in derived):
            raise AssemblyPolicyError(
                "derived_variables must contain DerivedVariable values"
            )
        parameter_values = tuple(parameters)
        derived_values = tuple(derived)
        names = tuple(
            value.name for value in (*parameter_values, *derived_values)
        )
        if len(set(names)) != len(names):
            duplicate = next(name for name in names if names.count(name) > 1)
            raise AssemblyPolicyError(
                f"duplicate template variable name {duplicate!r}"
            )
        object.__setattr__(self, "parameters", parameter_values)
        object.__setattr__(self, "derived_variables", derived_values)

        if not isinstance(self.declared_units, Mapping):
            raise AssemblyPolicyError("declared_units must be a mapping")
        dimensions = {
            value.name: value.dimension
            for value in (*parameter_values, *derived_values)
        }
        supplied_units: dict[str, object] = {}
        for raw_name, raw_unit in self.declared_units.items():
            name = _identifier(raw_name, field_name="declared unit variable name")
            if name in supplied_units:
                raise AssemblyPolicyError(f"duplicate declared unit for {name!r}")
            supplied_units[name] = raw_unit
        unknown = sorted(set(supplied_units).difference(dimensions))
        if unknown:
            raise AssemblyPolicyError(
                f"declared unit references unknown template variable {unknown[0]!r}"
            )
        units = {
            name: _declared_unit(
                supplied_units.get(name, _default_declared_unit(dimension)),
                dimension,
                field_name=f"declared unit for {name!r}",
            )
            for name, dimension in dimensions.items()
        }
        object.__setattr__(self, "declared_units", MappingProxyType(units))

    @property
    def parameter_by_name(self) -> Mapping[str, TemplateParameter]:
        return MappingProxyType({value.name: value for value in self.parameters})

    @property
    def derived_by_name(self) -> Mapping[str, DerivedVariable]:
        return MappingProxyType(
            {value.name: value for value in self.derived_variables}
        )

    @property
    def declared_unit_by_name(self) -> Mapping[str, str]:
        return self.declared_units

    def compile(self, instance: "TemplateInstance") -> "TemplateCompileResult":
        """Compile one isolated instance of this definition."""

        return compile_template_instance(self, instance)


@dataclass(frozen=True, slots=True)
class TemplateInstance:
    """One immutable template reference with raw dependency-free overrides."""

    instance_id: str
    template_id: str
    overrides: Mapping[str, TemplateScalar] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "instance_id",
            _identifier(self.instance_id, field_name="instance_id"),
        )
        object.__setattr__(
            self,
            "template_id",
            _identifier(self.template_id, field_name="instance template_id"),
        )
        if not isinstance(self.overrides, Mapping):
            raise AssemblyPolicyError("template overrides must be a mapping")
        overrides: dict[str, TemplateScalar] = {}
        for raw_name, raw_value in self.overrides.items():
            name = _identifier(raw_name, field_name="template override name")
            if name in overrides:
                raise AssemblyPolicyError(f"duplicate template override {name!r}")
            value = _raw_scalar(
                raw_value,
                field_name=f"template override {name!r}",
            )
            assert value is not None
            overrides[name] = value
        object.__setattr__(self, "overrides", MappingProxyType(overrides))


@dataclass(frozen=True, slots=True)
class TemplateVariableProvenance:
    """Raw and canonical provenance for one resolved template variable."""

    name: str
    role: TemplateVariableRole
    dimension: TemplateDimension
    declared_unit: str
    source: TemplateValueSource
    raw_default: TemplateScalar | None
    raw_override: TemplateScalar | None
    raw_derived: str | None
    raw_range: tuple[TemplateScalar | None, TemplateScalar | None]
    dependencies: tuple[str, ...]
    resolved_value: float

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "name",
            _identifier(self.name, field_name="provenance variable name"),
        )
        role = self.role
        if isinstance(role, str) and not isinstance(role, TemplateVariableRole):
            try:
                role = TemplateVariableRole(role)
            except ValueError as error:
                raise AssemblyPolicyError(
                    "provenance role must be parameter or derived"
                ) from error
        if not isinstance(role, TemplateVariableRole):
            raise AssemblyPolicyError(
                "provenance role must be a TemplateVariableRole"
            )
        object.__setattr__(self, "role", role)

        dimension = _dimension(
            self.dimension,
            field_name=f"provenance variable {self.name!r} dimension",
        )
        object.__setattr__(self, "dimension", dimension)
        object.__setattr__(
            self,
            "declared_unit",
            _declared_unit(
                self.declared_unit,
                dimension,
                field_name=f"declared unit for {self.name!r}",
            ),
        )

        source = self.source
        if isinstance(source, str) and not isinstance(source, TemplateValueSource):
            try:
                source = TemplateValueSource(source)
            except ValueError as error:
                raise AssemblyPolicyError(
                    "provenance source must be default, override, or derived"
                ) from error
        if not isinstance(source, TemplateValueSource):
            raise AssemblyPolicyError(
                "provenance source must be a TemplateValueSource"
            )
        object.__setattr__(self, "source", source)

        for field_name in ("raw_default", "raw_override"):
            object.__setattr__(
                self,
                field_name,
                _raw_scalar(
                    getattr(self, field_name),
                    field_name=f"{self.name!r} {field_name}",
                    allow_none=True,
                ),
            )
        if self.raw_derived is not None and (
            not isinstance(self.raw_derived, str)
            or not self.raw_derived.strip()
        ):
            raise AssemblyPolicyError("raw_derived must be a non-blank string")

        raw_range = _tuple(self.raw_range, field_name="raw_range")
        if len(raw_range) != 2:
            raise AssemblyPolicyError("raw_range must contain minimum and maximum")
        range_values = tuple(
            _raw_scalar(
                value,
                field_name=f"{self.name!r} raw_range",
                allow_none=True,
            )
            for value in raw_range
        )
        object.__setattr__(self, "raw_range", range_values)

        dependencies = tuple(
            sorted(
                {
                    _identifier(value, field_name="dependency name")
                    for value in _tuple(
                        self.dependencies,
                        field_name="provenance dependencies",
                    )
                }
            )
        )
        object.__setattr__(self, "dependencies", dependencies)
        if isinstance(self.resolved_value, bool):
            raise AssemblyPolicyError("resolved provenance values must be finite")
        try:
            resolved_value = float(self.resolved_value)
        except (OverflowError, TypeError, ValueError) as error:
            raise AssemblyPolicyError(
                "resolved provenance values must be finite"
            ) from error
        if not math.isfinite(resolved_value):
            raise AssemblyPolicyError("resolved provenance values must be finite")
        object.__setattr__(self, "resolved_value", resolved_value)

        if role is TemplateVariableRole.PARAMETER:
            if self.raw_derived is not None or dependencies:
                raise AssemblyPolicyError(
                    "parameter provenance cannot declare an expression or dependencies"
                )
            if source is TemplateValueSource.DERIVED:
                raise AssemblyPolicyError(
                    "parameter provenance cannot have derived source"
                )
            if source is TemplateValueSource.DEFAULT and self.raw_default is None:
                raise AssemblyPolicyError(
                    "default provenance requires a raw_default"
                )
            if source is TemplateValueSource.DEFAULT and self.raw_override is not None:
                raise AssemblyPolicyError(
                    "default provenance cannot contain a raw_override"
                )
            if source is TemplateValueSource.OVERRIDE and self.raw_override is None:
                raise AssemblyPolicyError(
                    "override provenance requires a raw_override"
                )
            return
        if source is not TemplateValueSource.DERIVED:
            raise AssemblyPolicyError("derived provenance must have derived source")
        if self.raw_derived is None:
            raise AssemblyPolicyError(
                "derived provenance requires a raw_derived expression"
            )
        if self.raw_default is not None or self.raw_override is not None:
            raise AssemblyPolicyError(
                "derived provenance cannot contain defaults or overrides"
            )

    @property
    def canonical_unit(self) -> str:
        return "mm" if self.dimension is TemplateDimension.LENGTH else "number"

    @property
    def raw_expression(self) -> str | None:
        """Compatibility label for the raw derived expression."""

        return self.raw_derived

    @property
    def raw_minimum(self) -> TemplateScalar | None:
        return self.raw_range[0]

    @property
    def raw_maximum(self) -> TemplateScalar | None:
        return self.raw_range[1]


@dataclass(frozen=True, slots=True)
class TemplateResolutionProvenance:
    """Immutable source/resolved snapshots and their stable SHA256 digests."""

    template_id: str
    instance_id: str
    variables: tuple[TemplateVariableProvenance, ...]
    source_canonical_json: str = field(init=False, repr=False)
    resolved_canonical_json: str = field(init=False, repr=False)
    source_digest: str = field(init=False)
    resolved_digest: str = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "template_id",
            _identifier(self.template_id, field_name="provenance template_id"),
        )
        object.__setattr__(
            self,
            "instance_id",
            _identifier(self.instance_id, field_name="provenance instance_id"),
        )
        raw_variables = _tuple(self.variables, field_name="provenance variables")
        if any(
            not isinstance(value, TemplateVariableProvenance)
            for value in raw_variables
        ):
            raise AssemblyPolicyError(
                "variables must contain TemplateVariableProvenance values"
            )
        variables = tuple(raw_variables)
        names = tuple(value.name for value in variables)
        if len(set(names)) != len(names):
            raise AssemblyPolicyError("provenance variable names must be unique")
        object.__setattr__(self, "variables", variables)

        source_payload = {
            "evaluator_version": TEMPLATE_EVALUATOR_VERSION,
            "instance_id": self.instance_id,
            "schema_version": TEMPLATE_PROVENANCE_SCHEMA_VERSION,
            "template_id": self.template_id,
            "variables": [
                {
                    "declared_unit": value.declared_unit,
                    "dependencies": list(value.dependencies),
                    "dimension": value.dimension.value,
                    "name": value.name,
                    "raw_default": value.raw_default,
                    "raw_derived": value.raw_derived,
                    "raw_override": value.raw_override,
                    "raw_range": {
                        "maximum": value.raw_range[1],
                        "minimum": value.raw_range[0],
                    },
                    "role": value.role.value,
                    "source": value.source.value,
                }
                for value in variables
            ],
        }
        resolved_payload = {
            "schema_version": TEMPLATE_PROVENANCE_SCHEMA_VERSION,
            "variables": [
                {
                    "canonical_unit": value.canonical_unit,
                    "dimension": value.dimension.value,
                    "name": value.name,
                    "value": _canonical_resolved_number(value.resolved_value),
                }
                for value in sorted(variables, key=lambda item: item.name)
            ],
        }
        source_json = _canonical_json(source_payload)
        resolved_json = _canonical_json(resolved_payload)
        object.__setattr__(self, "source_canonical_json", source_json)
        object.__setattr__(self, "resolved_canonical_json", resolved_json)
        object.__setattr__(self, "source_digest", _sha256(source_json))
        object.__setattr__(self, "resolved_digest", _sha256(resolved_json))

    @property
    def by_name(self) -> Mapping[str, TemplateVariableProvenance]:
        return MappingProxyType({value.name: value for value in self.variables})


@dataclass(frozen=True, slots=True)
class TemplateCompileResult:
    """One fully resolved isolated instance and its immutable provenance."""

    definition: TemplateDefinition
    instance: TemplateInstance
    resolved_parameters: ResolvedTemplateParameters
    provenance: TemplateResolutionProvenance

    def __post_init__(self) -> None:
        if not isinstance(self.definition, TemplateDefinition):
            raise AssemblyPolicyError("definition must be a TemplateDefinition")
        if not isinstance(self.instance, TemplateInstance):
            raise AssemblyPolicyError("instance must be a TemplateInstance")
        if not isinstance(self.resolved_parameters, ResolvedTemplateParameters):
            raise AssemblyPolicyError(
                "resolved_parameters must be ResolvedTemplateParameters"
            )
        if not isinstance(self.provenance, TemplateResolutionProvenance):
            raise AssemblyPolicyError(
                "provenance must be TemplateResolutionProvenance"
            )
        if self.definition.template_id != self.instance.template_id:
            raise AssemblyPolicyError(
                "template definition and instance identifiers do not match"
            )
        if (
            self.provenance.template_id != self.definition.template_id
            or self.provenance.instance_id != self.instance.instance_id
        ):
            raise AssemblyPolicyError(
                "template provenance identifiers do not match the compile inputs"
            )
        resolved_by_name = self.resolved_parameters.by_name
        if set(resolved_by_name) != set(self.provenance.by_name):
            raise AssemblyPolicyError(
                "resolved parameters and provenance variable names do not match"
            )
        for name, value in resolved_by_name.items():
            provenance = self.provenance.by_name[name]
            if (
                provenance.dimension is not value.dimension
                or provenance.source is not value.source
                or provenance.resolved_value != value.value
            ):
                raise AssemblyPolicyError(
                    f"resolved parameter {name!r} does not match its provenance"
                )

    @property
    def template_id(self) -> str:
        return self.definition.template_id

    @property
    def instance_id(self) -> str:
        return self.instance.instance_id

    @property
    def resolved(self) -> ResolvedTemplateParameters:
        return self.resolved_parameters

    @property
    def canonical_values(self) -> Mapping[str, float]:
        return self.resolved_parameters.canonical_values

    @property
    def source_digest(self) -> str:
        return self.provenance.source_digest

    @property
    def resolved_digest(self) -> str:
        return self.provenance.resolved_digest

    @property
    def source_canonical_json(self) -> str:
        return self.provenance.source_canonical_json

    @property
    def resolved_canonical_json(self) -> str:
        return self.provenance.resolved_canonical_json


def _expression_dependencies(
    expression_source: str,
    known_names: frozenset[str],
) -> tuple[str, ...]:
    """Return stable complete-NAME dependencies after resolver validation."""

    dependencies: set[str] = set()
    try:
        tokens = tokenize.generate_tokens(io.StringIO(expression_source).readline)
        for token in tokens:
            if token.type == tokenize.NAME and token.string in known_names:
                dependencies.add(token.string)
    except (tokenize.TokenError, IndentationError, SyntaxError) as error:
        raise AssemblyPolicyError(
            f"cannot collect derived dependencies: {error}"
        ) from error
    return tuple(sorted(dependencies))


def compile_template_instance(
    definition: TemplateDefinition,
    instance: TemplateInstance,
) -> TemplateCompileResult:
    """Resolve one instance and capture source-sensitive provenance."""

    if not isinstance(definition, TemplateDefinition):
        raise AssemblyPolicyError("definition must be a TemplateDefinition")
    if not isinstance(instance, TemplateInstance):
        raise AssemblyPolicyError("instance must be a TemplateInstance")
    if instance.template_id != definition.template_id:
        raise AssemblyPolicyError(
            f"instance {instance.instance_id!r} references template "
            f"{instance.template_id!r}, not {definition.template_id!r}"
        )

    parameter_names = frozenset(value.name for value in definition.parameters)
    derived_names = frozenset(
        value.name for value in definition.derived_variables
    )
    for name in instance.overrides:
        if name in derived_names:
            raise AssemblyPolicyError(
                f"derived variable {name!r} cannot be overridden"
            )
        if name not in parameter_names:
            raise AssemblyPolicyError(
                f"orphan or unknown template override {name!r}"
            )

    resolved = resolve_template_parameters(
        definition.parameters,
        definition.derived_variables,
        instance.overrides,
    )
    known_names = parameter_names.union(derived_names)
    variable_provenance: list[TemplateVariableProvenance] = []
    for parameter in definition.parameters:
        resolved_value = resolved[parameter.name]
        raw_override = (
            instance.overrides[parameter.name]
            if parameter.name in instance.overrides
            else None
        )
        variable_provenance.append(
            TemplateVariableProvenance(
                name=parameter.name,
                role=TemplateVariableRole.PARAMETER,
                dimension=parameter.dimension,
                declared_unit=definition.declared_units[parameter.name],
                source=resolved_value.source,
                raw_default=parameter.default,
                raw_override=raw_override,
                raw_derived=None,
                raw_range=(parameter.minimum, parameter.maximum),
                dependencies=(),
                resolved_value=resolved_value.value,
            )
        )
    for derived in definition.derived_variables:
        resolved_value = resolved[derived.name]
        variable_provenance.append(
            TemplateVariableProvenance(
                name=derived.name,
                role=TemplateVariableRole.DERIVED,
                dimension=derived.dimension,
                declared_unit=definition.declared_units[derived.name],
                source=resolved_value.source,
                raw_default=None,
                raw_override=None,
                raw_derived=derived.expression_source,
                raw_range=(derived.minimum, derived.maximum),
                dependencies=_expression_dependencies(
                    derived.expression_source,
                    known_names,
                ),
                resolved_value=resolved_value.value,
            )
        )

    provenance = TemplateResolutionProvenance(
        template_id=definition.template_id,
        instance_id=instance.instance_id,
        variables=tuple(variable_provenance),
    )
    return TemplateCompileResult(
        definition=definition,
        instance=instance,
        resolved_parameters=resolved,
        provenance=provenance,
    )


__all__ = [
    "TEMPLATE_EVALUATOR_VERSION",
    "TEMPLATE_PROVENANCE_SCHEMA_VERSION",
    "TemplateCompileResult",
    "TemplateDefinition",
    "TemplateInstance",
    "TemplateResolutionProvenance",
    "TemplateVariableProvenance",
    "TemplateVariableRole",
    "compile_template_instance",
]
