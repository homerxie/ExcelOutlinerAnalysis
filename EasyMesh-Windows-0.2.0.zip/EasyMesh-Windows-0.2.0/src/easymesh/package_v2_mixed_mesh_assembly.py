"""Identity-driven assembly and verified MSH writing for mixed volume meshes.

This module is deliberately role-neutral.  It knows only immutable Frozen
volume elements and component-local generated fragments.  Node sharing is
authorized exclusively by a common semantic token or an explicit
``DeclaredSharedCoordinate``; coordinates are audited but never used as an
implicit merge key.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
import math
from pathlib import Path
import re
from statistics import median
from types import MappingProxyType
from typing import Any, Mapping, Sequence, TypeAlias

from .gmsh_runtime import isolated_gmsh_model
from .output_artifacts import (
    atomic_output_path,
    exclusive_output_lock,
    file_artifact,
    normalized_mesh_output,
    paths_refer_to_same_file,
)
from .package_v2_mesh_settings import (
    validate_interface_geometry_tolerance_mm,
)
from .volume_mesh import (
    ELEMENT_SPECS,
    ElementKind,
    PhysicalGroup,
    VolumeElement,
    VolumeMesh,
    load_volume_mesh,
)


Point3D: TypeAlias = tuple[float, float, float]
FROZEN_FRAGMENT_KEY = "@frozen"
_DEFAULT_FROZEN_NAMESPACE = "frozen"
_ALL_SOLID_VOLUMES = "ALL_SOLID_VOLUMES"
_NON_MATERIAL_GROUP_NAMES = frozenset(
    {
        "ORTH_MESH_WARNINGS",
        _ALL_SOLID_VOLUMES,
        "TEMPLATE_SOLID_VOLUMES",
        "TRANSITION_SOLID_VOLUMES",
    }
)
_NON_MATERIAL_GROUP_PREFIXES = (
    "BUMP_",
    "COMPONENT_",
    "HM_",
    "MATERIAL_",
    "REGION_",
    "TEMPLATE_",
    "TRANSITION_",
)


class MixedMeshAssemblyError(ValueError):
    """A mixed mesh cannot be assembled without changing its declared identity."""


def _canonical_text(value: object, *, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or any(ord(character) < 32 for character in value)
    ):
        raise MixedMeshAssemblyError(f"{field_name} must be a canonical string")
    return value


def _positive_int(value: object, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise MixedMeshAssemblyError(f"{field_name} must be a positive integer")
    return value


def _point3(value: Sequence[float], *, field_name: str) -> Point3D:
    try:
        raw = tuple(value)
    except TypeError as error:
        raise MixedMeshAssemblyError(f"{field_name} must contain x,y,z") from error
    if len(raw) != 3:
        raise MixedMeshAssemblyError(f"{field_name} must contain x,y,z")
    result: list[float] = []
    for item in raw:
        if isinstance(item, bool):
            raise MixedMeshAssemblyError(f"{field_name} must be finite")
        try:
            number = float(item)
        except (TypeError, ValueError, OverflowError) as error:
            raise MixedMeshAssemblyError(f"{field_name} must be finite") from error
        if not math.isfinite(number):
            raise MixedMeshAssemblyError(f"{field_name} must be finite")
        result.append(0.0 if number == 0.0 else number)
    return tuple(result)  # type: ignore[return-value]


@dataclass(frozen=True, slots=True)
class ComponentMeshNode:
    local_node_id: int
    coordinates_mm: Point3D
    semantic_token: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "local_node_id",
            _positive_int(self.local_node_id, field_name="local_node_id"),
        )
        object.__setattr__(
            self,
            "coordinates_mm",
            _point3(self.coordinates_mm, field_name="node coordinates_mm"),
        )
        if self.semantic_token is not None:
            object.__setattr__(
                self,
                "semantic_token",
                _canonical_text(
                    self.semantic_token, field_name="node semantic_token"
                ),
            )


@dataclass(frozen=True, slots=True)
class ComponentMeshElement:
    local_element_id: int
    gmsh_type: int
    node_ids: tuple[int, ...]
    provenance: str
    element_set_names: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "element_set_names", tuple(sorted({
            _canonical_text(name, field_name="element set name") for name in self.element_set_names
        })))
        object.__setattr__(
            self,
            "local_element_id",
            _positive_int(self.local_element_id, field_name="local_element_id"),
        )
        if self.gmsh_type not in ELEMENT_SPECS:
            raise MixedMeshAssemblyError(
                "generated element must be first-order TET4/HEX8/WEDGE6/PYRAMID5"
            )
        try:
            nodes = tuple(self.node_ids)
        except TypeError as error:
            raise MixedMeshAssemblyError("element node_ids are invalid") from error
        expected = ELEMENT_SPECS[self.gmsh_type][1]
        if (
            len(nodes) != expected
            or len(set(nodes)) != expected
            or any(
                isinstance(node, bool) or not isinstance(node, int) or node < 1
                for node in nodes
            )
        ):
            raise MixedMeshAssemblyError("element connectivity is invalid")
        object.__setattr__(self, "node_ids", nodes)
        object.__setattr__(
            self,
            "provenance",
            _canonical_text(self.provenance, field_name="element provenance"),
        )

    @property
    def kind(self) -> ElementKind:
        return ELEMENT_SPECS[self.gmsh_type][0]


@dataclass(frozen=True, slots=True)
class ComponentLocalMeshFragment:
    fragment_key: str
    component_key: str
    material_name: str
    nodes: tuple[ComponentMeshNode, ...]
    elements: tuple[ComponentMeshElement, ...]

    def __post_init__(self) -> None:
        for field_name in ("fragment_key", "component_key", "material_name"):
            object.__setattr__(
                self,
                field_name,
                _canonical_text(getattr(self, field_name), field_name=field_name),
            )
        if self.fragment_key == FROZEN_FRAGMENT_KEY:
            raise MixedMeshAssemblyError("fragment_key is reserved for Frozen input")
        nodes = tuple(self.nodes)
        elements = tuple(self.elements)
        if (
            not nodes
            or not elements
            or any(not isinstance(node, ComponentMeshNode) for node in nodes)
            or any(
                not isinstance(element, ComponentMeshElement)
                for element in elements
            )
        ):
            raise MixedMeshAssemblyError(
                "component-local fragment must contain nodes and elements"
            )
        node_ids = tuple(node.local_node_id for node in nodes)
        element_ids = tuple(element.local_element_id for element in elements)
        if len(set(node_ids)) != len(node_ids):
            raise MixedMeshAssemblyError("fragment node IDs are duplicated")
        if len(set(element_ids)) != len(element_ids):
            raise MixedMeshAssemblyError("fragment element IDs are duplicated")
        known = set(node_ids)
        if any(node not in known for element in elements for node in element.node_ids):
            raise MixedMeshAssemblyError("fragment element references an unknown node")
        tokens = [node.semantic_token for node in nodes if node.semantic_token is not None]
        if len(set(tokens)) != len(tokens):
            raise MixedMeshAssemblyError(
                "one fragment cannot repeat a semantic node token"
            )
        object.__setattr__(
            self, "nodes", tuple(sorted(nodes, key=lambda node: node.local_node_id))
        )
        object.__setattr__(
            self,
            "elements",
            tuple(sorted(elements, key=lambda element: element.local_element_id)),
        )


@dataclass(frozen=True, slots=True, order=True)
class MeshNodeReference:
    fragment_key: str
    local_node_id: int

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "fragment_key",
            _canonical_text(self.fragment_key, field_name="node reference fragment_key"),
        )
        object.__setattr__(
            self,
            "local_node_id",
            _positive_int(
                self.local_node_id, field_name="node reference local_node_id"
            ),
        )


@dataclass(frozen=True, slots=True)
class DeclaredSharedCoordinate:
    declaration_key: str
    nodes: tuple[MeshNodeReference, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "declaration_key",
            _canonical_text(
                self.declaration_key, field_name="shared coordinate declaration_key"
            ),
        )
        nodes = tuple(self.nodes)
        if (
            len(nodes) < 2
            or len(set(nodes)) != len(nodes)
            or any(not isinstance(node, MeshNodeReference) for node in nodes)
        ):
            raise MixedMeshAssemblyError(
                "shared coordinate must declare at least two distinct node references"
            )
        object.__setattr__(self, "nodes", tuple(sorted(nodes)))


@dataclass(frozen=True, slots=True)
class FragmentFaceReference:
    fragment_key: str
    node_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "fragment_key",
            _canonical_text(self.fragment_key, field_name="face reference fragment_key"),
        )
        nodes = tuple(self.node_ids)
        if (
            len(nodes) not in {3, 4}
            or len(set(nodes)) != len(nodes)
            or any(
                isinstance(node, bool) or not isinstance(node, int) or node < 1
                for node in nodes
            )
        ):
            raise MixedMeshAssemblyError("face reference must be TRI3/QUAD4")
        object.__setattr__(self, "node_ids", nodes)


@dataclass(frozen=True, slots=True)
class DeclaredSharedSeam:
    seam_key: str
    faces: tuple[FragmentFaceReference, FragmentFaceReference]
    sizing_contract_id: str | None = None
    target_edge_mm: float | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "seam_key",
            _canonical_text(self.seam_key, field_name="seam_key"),
        )
        faces = tuple(self.faces)
        if (
            len(faces) != 2
            or any(not isinstance(face, FragmentFaceReference) for face in faces)
            or faces[0] == faces[1]
            or faces[0].fragment_key == faces[1].fragment_key
        ):
            raise MixedMeshAssemblyError(
                "declared seam must contain two faces from distinct fragments"
            )
        object.__setattr__(self, "faces", faces)
        if (self.sizing_contract_id is None) != (self.target_edge_mm is None):
            raise MixedMeshAssemblyError(
                "declared seam sizing_contract_id and target_edge_mm must be "
                "provided together"
            )
        if self.sizing_contract_id is not None:
            object.__setattr__(
                self,
                "sizing_contract_id",
                _canonical_text(
                    self.sizing_contract_id,
                    field_name="seam sizing_contract_id",
                ),
            )
            if (
                isinstance(self.target_edge_mm, bool)
                or not isinstance(self.target_edge_mm, (int, float))
                or not math.isfinite(float(self.target_edge_mm))
                or float(self.target_edge_mm) <= 0.0
            ):
                raise MixedMeshAssemblyError(
                    "declared seam target_edge_mm must be finite and positive"
                )
            object.__setattr__(self, "target_edge_mm", float(self.target_edge_mm))


@dataclass(frozen=True, slots=True)
class ExpectedCompleteSupportPlaneInterface:
    """One adjacency whose complete physical contact is one support plane.

    This is intentionally stronger than an expected analytic area.  The final
    assembler discovers *all* source-boundary facets from both fragments on
    the declared plane and requires the two facet-key sets to be identical
    after semantic node unification.  It therefore catches a partially
    inherited staircase, a footprint gap and a different TRI/QUAD partition.
    """

    interface_key: str
    first_fragment_key: str
    second_fragment_key: str
    plane_axis: int
    plane_coordinate_mm: float

    def __post_init__(self) -> None:
        for field_name in (
            "interface_key",
            "first_fragment_key",
            "second_fragment_key",
        ):
            object.__setattr__(
                self,
                field_name,
                _canonical_text(getattr(self, field_name), field_name=field_name),
            )
        if self.first_fragment_key == self.second_fragment_key:
            raise MixedMeshAssemblyError(
                "complete support-plane interface requires two distinct fragments"
            )
        if (
            isinstance(self.plane_axis, bool)
            or not isinstance(self.plane_axis, int)
            or self.plane_axis not in {0, 1, 2}
        ):
            raise MixedMeshAssemblyError("support-plane axis must be 0, 1 or 2")
        if (
            isinstance(self.plane_coordinate_mm, bool)
            or not isinstance(self.plane_coordinate_mm, (int, float))
            or not math.isfinite(float(self.plane_coordinate_mm))
        ):
            raise MixedMeshAssemblyError(
                "support-plane coordinate must be finite"
            )
        object.__setattr__(
            self,
            "plane_coordinate_mm",
            0.0
            if float(self.plane_coordinate_mm) == 0.0
            else float(self.plane_coordinate_mm),
        )


def frozen_node_semantic_token(
    node_tag: int,
    *,
    namespace: str = _DEFAULT_FROZEN_NAMESPACE,
) -> str:
    return (
        f"{_canonical_text(namespace, field_name='Frozen semantic namespace')}"
        f":node:{_positive_int(node_tag, field_name='Frozen node tag')}"
    )


@dataclass(frozen=True, slots=True)
class AssembledMixedNode:
    output_tag: int
    coordinates_mm: Point3D
    source_references: tuple[MeshNodeReference, ...]
    semantic_tokens: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class AssembledMixedElement:
    output_tag: int
    gmsh_type: int
    node_tags: tuple[int, ...]
    entity_tag: int
    source_fragment_key: str
    component_key: str
    material_name: str
    provenance: str
    physical_groups: tuple[PhysicalGroup, ...]
    original_frozen_element_tag: int | None = None
    source_local_element_id: int | None = None

    @property
    def kind(self) -> ElementKind:
        return ELEMENT_SPECS[self.gmsh_type][0]


@dataclass(frozen=True, slots=True)
class MixedMeshAssemblyAudit:
    node_count: int
    element_count: int
    free_face_count: int
    internal_face_count: int
    declared_seam_count: int
    declared_seam_face_count: int
    complete_support_plane_interface_count: int
    complete_support_plane_face_count: int
    unpaired_coplanar_free_face_overlap_count: int
    component_kind_counts: Mapping[str, Mapping[str, int]]
    component_provenance_counts: Mapping[str, Mapping[str, int]]


@dataclass(frozen=True, slots=True)
class AssembledSharedSurfaceSizingContract:
    contract_id: str
    target_edge_mm: float
    face_node_tags: tuple[tuple[int, ...], ...]


@dataclass(frozen=True, slots=True)
class AssembledCompleteSupportPlaneInterface:
    interface_key: str
    first_fragment_key: str
    second_fragment_key: str
    plane_axis: int
    plane_coordinate_mm: float
    face_node_tags: tuple[tuple[int, ...], ...]
    area_mm2: float


@dataclass(frozen=True, slots=True)
class MixedMeshAssemblyPlan:
    nodes: tuple[AssembledMixedNode, ...]
    elements: tuple[AssembledMixedElement, ...]
    physical_groups: tuple[PhysicalGroup, ...]
    entity_physical_groups: Mapping[int, tuple[PhysicalGroup, ...]]
    component_physical_groups: Mapping[str, PhysicalGroup]
    material_physical_groups: Mapping[str, PhysicalGroup]
    shared_surface_sizing_contracts: tuple[
        AssembledSharedSurfaceSizingContract, ...
    ]
    complete_support_plane_interfaces: tuple[
        AssembledCompleteSupportPlaneInterface, ...
    ]
    interface_geometry_tolerance_mm: float
    audit: MixedMeshAssemblyAudit


@dataclass(frozen=True, slots=True)
class MixedMeshWriteResult:
    output_path: Path
    mesh: VolumeMesh
    plan: MixedMeshAssemblyPlan
    artifact: Mapping[str, str | int]


class _DisjointSet:
    def __init__(self, values: Sequence[MeshNodeReference]) -> None:
        self.parent = {value: value for value in values}

    def root(self, value: MeshNodeReference) -> MeshNodeReference:
        parent = self.parent[value]
        if parent != value:
            self.parent[value] = self.root(parent)
        return self.parent[value]

    def join(self, first: MeshNodeReference, second: MeshNodeReference) -> None:
        first_root, second_root = self.root(first), self.root(second)
        if first_root == second_root:
            return
        if second_root < first_root:
            first_root, second_root = second_root, first_root
        self.parent[second_root] = first_root


@dataclass(frozen=True, slots=True)
class _InputNode:
    coordinates: Point3D
    semantic_token: str | None
    frozen: bool


@dataclass(frozen=True, slots=True)
class _InputElement:
    source_fragment_key: str
    local_element_id: int
    gmsh_type: int
    local_node_ids: tuple[int, ...]
    component_key: str
    material_name: str
    provenance: str
    frozen_element: VolumeElement | None
    element_set_names: tuple[str, ...] = ()


def _freeze_nested_counts(
    values: Mapping[str, Counter[str]],
) -> Mapping[str, Mapping[str, int]]:
    return MappingProxyType(
        {
            key: MappingProxyType(dict(sorted(counter.items())))
            for key, counter in sorted(values.items())
        }
    )


def _physical_registry(
    frozen_mesh: VolumeMesh | None,
) -> dict[int, PhysicalGroup]:
    groups: dict[int, PhysicalGroup] = {}
    if frozen_mesh is None:
        return groups
    candidates = [
        group
        for values in frozen_mesh.entity_physical_groups.values()
        for group in values
    ] + [
        group for element in frozen_mesh.elements for group in element.physical_groups
    ]
    for group in candidates:
        previous = groups.get(group.tag)
        if previous is not None and previous != group:
            raise MixedMeshAssemblyError(
                f"Frozen Physical Group tag {group.tag} has inconsistent identity"
            )
        groups[group.tag] = group
    return groups


def _allocate_group(
    registry: dict[int, PhysicalGroup],
    *,
    name: str,
) -> PhysicalGroup:
    used_names = {group.name.casefold() for group in registry.values()}
    if name.casefold() in used_names:
        raise MixedMeshAssemblyError(
            f"generated Physical Group name collides with Frozen identity: {name!r}"
        )
    tag = 1
    while tag in registry:
        tag += 1
    group = PhysicalGroup(tag, name, True)
    registry[tag] = group
    return group


def _component_physical_name(component: str) -> str:
    token = re.sub(r"[^A-Z0-9]+", "_", component.upper()).strip("_")
    token = (token or "ID")[:40]
    digest = hashlib.sha256(component.encode("utf-8")).hexdigest()[:12].upper()
    return f"COMPONENT_{token}_{digest}"


def _groups_named(
    registry: Mapping[int, PhysicalGroup],
    name: str,
) -> tuple[PhysicalGroup, ...]:
    folded = name.casefold()
    return tuple(
        sorted(
            (group for group in registry.values() if group.name.casefold() == folded),
            key=lambda group: group.tag,
        )
    )


def _all_solids_group(
    registry: dict[int, PhysicalGroup],
    frozen_mesh: VolumeMesh | None,
) -> PhysicalGroup:
    matches = _groups_named(registry, _ALL_SOLID_VOLUMES)
    if frozen_mesh is None:
        if matches:
            raise MixedMeshAssemblyError(
                "generated-only assembly unexpectedly contains ALL_SOLID_VOLUMES"
            )
        return _allocate_group(registry, name=_ALL_SOLID_VOLUMES)
    if len(matches) != 1:
        raise MixedMeshAssemblyError(
            "Frozen input must contain exactly one ALL_SOLID_VOLUMES identity"
        )
    group = matches[0]
    if any(group not in element.physical_groups for element in frozen_mesh.elements):
        raise MixedMeshAssemblyError(
            "Frozen ALL_SOLID_VOLUMES must contain every Frozen volume element"
        )
    return group


def _material_physical_group(
    registry: dict[int, PhysicalGroup],
    material: str,
) -> PhysicalGroup:
    normalized = material.upper()
    if normalized in _NON_MATERIAL_GROUP_NAMES or normalized.startswith(
        _NON_MATERIAL_GROUP_PREFIXES
    ):
        raise MixedMeshAssemblyError(
            f"material name collides with a reserved Physical Group family: {material!r}"
        )
    matches = _groups_named(registry, material)
    if len(matches) > 1:
        raise MixedMeshAssemblyError(
            f"material Physical Group identity is ambiguous: {material!r}"
        )
    if matches:
        group = matches[0]
        if group.name != material:
            raise MixedMeshAssemblyError(
                "material name differs from an existing Frozen identity only by case: "
                f"{material!r} versus {group.name!r}"
            )
        return group
    return _allocate_group(registry, name=material)


def _validate_frozen_mesh(mesh: VolumeMesh) -> None:
    if not isinstance(mesh, VolumeMesh):
        raise MixedMeshAssemblyError("frozen_mesh must be a VolumeMesh")
    node_tags = {node.tag for node in mesh.nodes}
    element_tags = {element.tag for element in mesh.elements}
    if (
        not mesh.nodes
        or not mesh.elements
        or len(node_tags) != len(mesh.nodes)
        or len(element_tags) != len(mesh.elements)
    ):
        raise MixedMeshAssemblyError("Frozen mesh is empty or has duplicate tags")
    if any(
        isinstance(node.tag, bool)
        or not isinstance(node.tag, int)
        or node.tag < 1
        or any(not math.isfinite(value) for value in node.coordinates)
        for node in mesh.nodes
    ):
        raise MixedMeshAssemblyError("Frozen mesh nodes are invalid")
    if any(
        isinstance(element.tag, bool)
        or not isinstance(element.tag, int)
        or element.tag < 1
        or isinstance(element.entity_tag, bool)
        or not isinstance(element.entity_tag, int)
        or element.entity_tag < 1
        or element.gmsh_type not in ELEMENT_SPECS
        or ELEMENT_SPECS[element.gmsh_type][0] is not element.kind
        or len(element.node_tags) != ELEMENT_SPECS[element.gmsh_type][1]
        or len(set(element.node_tags)) != len(element.node_tags)
        or any(node not in node_tags for node in element.node_tags)
        or not math.isfinite(element.min_jacobian_determinant)
        or element.min_jacobian_determinant <= 0.0
        for element in mesh.elements
    ):
        raise MixedMeshAssemblyError("Frozen mesh connectivity is invalid")
    all_group_sequences = tuple(mesh.entity_physical_groups.values()) + tuple(
        element.physical_groups for element in mesh.elements
    )
    for entity_tag, groups in mesh.entity_physical_groups.items():
        if (
            isinstance(entity_tag, bool)
            or not isinstance(entity_tag, int)
            or entity_tag < 1
            or not isinstance(groups, tuple)
        ):
            raise MixedMeshAssemblyError(
                "Frozen entity Physical Group mapping is invalid"
            )
    for groups in all_group_sequences:
        if (
            any(not isinstance(group, PhysicalGroup) for group in groups)
            or len({group.tag for group in groups}) != len(groups)
        ):
            raise MixedMeshAssemblyError("Frozen Physical Groups are invalid")
        for group in groups:
            _positive_int(group.tag, field_name="Frozen Physical Group tag")
            _canonical_text(group.name, field_name="Frozen Physical Group name")
            if not isinstance(group.explicitly_named, bool):
                raise MixedMeshAssemblyError(
                    "Frozen Physical Group naming evidence is invalid"
                )
    groups_by_entity: dict[int, tuple[PhysicalGroup, ...]] = {}
    for element in mesh.elements:
        signature = tuple(sorted(element.physical_groups, key=lambda value: value.tag))
        previous = groups_by_entity.setdefault(element.entity_tag, signature)
        if previous != signature:
            raise MixedMeshAssemblyError(
                "Frozen entity has inconsistent Physical Group membership"
            )
        declared = mesh.entity_physical_groups.get(element.entity_tag)
        if declared is not None and tuple(
            sorted(declared, key=lambda value: value.tag)
        ) != signature:
            raise MixedMeshAssemblyError(
                "Frozen entity Physical Group mapping is inconsistent"
            )


def _nearby_identity_collision(
    coordinates: Mapping[MeshNodeReference, Point3D],
    tolerance: float,
) -> tuple[MeshNodeReference, MeshNodeReference] | None:
    buckets: dict[tuple[int, int, int], list[MeshNodeReference]] = defaultdict(list)
    for reference in sorted(coordinates):
        point = coordinates[reference]
        bucket = tuple(math.floor(value / tolerance) for value in point)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for previous in buckets.get(
                        (bucket[0] + dx, bucket[1] + dy, bucket[2] + dz), ()
                    ):
                        if math.dist(point, coordinates[previous]) <= tolerance:
                            return previous, reference
        buckets[bucket].append(reference)
    return None


def _subtract(first: Point3D, second: Point3D) -> Point3D:
    return tuple(first[index] - second[index] for index in range(3))  # type: ignore[return-value]


def _cross(first: Point3D, second: Point3D) -> Point3D:
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _dot(first: Point3D, second: Point3D) -> float:
    return math.fsum(first[index] * second[index] for index in range(3))


def _norm(value: Point3D) -> float:
    return math.sqrt(_dot(value, value))


def _polygon_area_3d(points: Sequence[Point3D]) -> float:
    if len(points) not in {3, 4}:
        raise MixedMeshAssemblyError("surface facet must be TRI3/QUAD4")
    origin = points[0]
    return 0.5 * math.fsum(
        _norm(
            _cross(
                _subtract(points[index], origin),
                _subtract(points[index + 1], origin),
            )
        )
        for index in range(1, len(points) - 1)
    )


@dataclass(frozen=True, slots=True)
class _BoundaryFaceGeometry:
    fragment_key: str
    element_tag: int
    node_tags: tuple[int, ...]
    points: tuple[Point3D, ...]
    minimum: Point3D
    maximum: Point3D
    unit_normal: Point3D
    plane_offset: float


def _boundary_face_geometry(
    element: AssembledMixedElement,
    node_tags: tuple[int, ...],
    coordinates: Mapping[int, Point3D],
    *,
    tolerance: float,
) -> _BoundaryFaceGeometry | None:
    points = tuple(coordinates[node] for node in node_tags)
    candidates = tuple(
        _cross(
            _subtract(points[second], points[first]),
            _subtract(points[third], points[first]),
        )
        for first in range(len(points) - 2)
        for second in range(first + 1, len(points) - 1)
        for third in range(second + 1, len(points))
    )
    normal = max(candidates, key=_norm)
    length = _norm(normal)
    if length <= max(1.0e-18, tolerance * tolerance):
        raise MixedMeshAssemblyError(
            "mixed mesh contains a degenerate free boundary facet: "
            f"fragment={element.source_fragment_key!r}, "
            f"element={element.output_tag}, nodes={node_tags!r}"
        )
    unit = tuple(value / length for value in normal)  # type: ignore[assignment]
    dominant = max(range(3), key=lambda axis: abs(unit[axis]))
    if unit[dominant] < 0.0:
        unit = tuple(-value for value in unit)  # type: ignore[assignment]
    offset = _dot(unit, points[0])
    # A warped QUAD has no unique positive-area common plane.  Exact shared
    # warped facets have already become internal by node/facet identity; only
    # genuinely planar free facets participate in this geometric leak audit.
    if any(abs(_dot(unit, point) - offset) > tolerance for point in points):
        return None
    return _BoundaryFaceGeometry(
        element.source_fragment_key,
        element.output_tag,
        node_tags,
        points,
        tuple(min(point[axis] for point in points) for axis in range(3)),  # type: ignore[arg-type]
        tuple(max(point[axis] for point in points) for axis in range(3)),  # type: ignore[arg-type]
        unit,
        offset,
    )


def _signed_area_2d(points: Sequence[tuple[float, float]]) -> float:
    return 0.5 * math.fsum(
        first[0] * second[1] - first[1] * second[0]
        for first, second in zip(points, (*points[1:], points[0]))
    )


def _cross_2d(
    first: tuple[float, float],
    second: tuple[float, float],
    third: tuple[float, float],
) -> float:
    return (
        (second[0] - first[0]) * (third[1] - first[1])
        - (second[1] - first[1]) * (third[0] - first[0])
    )


def _convex_clip_area_2d(
    subject: Sequence[tuple[float, float]],
    clip: Sequence[tuple[float, float]],
) -> float:
    """Return the intersection area of two convex cyclic polygons."""

    output = list(subject)
    orientation = 1.0 if _signed_area_2d(clip) >= 0.0 else -1.0
    scale = max(
        1.0,
        *(abs(value) for point in (*subject, *clip) for value in point),
    )
    epsilon = 128.0 * math.ulp(scale) * scale
    for clip_first, clip_second in zip(clip, (*clip[1:], clip[0])):
        source = output
        output = []
        if not source:
            break
        previous = source[-1]
        previous_value = orientation * _cross_2d(
            clip_first, clip_second, previous
        )
        previous_inside = previous_value >= -epsilon
        for current in source:
            current_value = orientation * _cross_2d(
                clip_first, clip_second, current
            )
            current_inside = current_value >= -epsilon
            if current_inside != previous_inside:
                denominator = previous_value - current_value
                if abs(denominator) > epsilon:
                    fraction = previous_value / denominator
                    output.append(
                        (
                            previous[0]
                            + fraction * (current[0] - previous[0]),
                            previous[1]
                            + fraction * (current[1] - previous[1]),
                        )
                    )
            if current_inside:
                output.append(current)
            previous = current
            previous_value = current_value
            previous_inside = current_inside
    return abs(_signed_area_2d(output)) if len(output) >= 3 else 0.0


def _triangles_2d(
    points: Sequence[tuple[float, float]],
) -> tuple[tuple[tuple[float, float], ...], ...]:
    if len(points) == 3:
        return (tuple(points),)
    return (
        (points[0], points[1], points[2]),
        (points[0], points[2], points[3]),
    )


def _coplanar_overlap_area_mm2(
    first: _BoundaryFaceGeometry,
    second: _BoundaryFaceGeometry,
    *,
    tolerance: float,
) -> float:
    # Vertex-to-opposite-plane distance is the actual absolute-tolerance
    # contract.  A fixed angular cutoff is incorrect: two 1 mm faces whose
    # normals differ by 5e-6 still describe the same plane to 1e-5 mm, while
    # the same angle can be material for a much larger face.
    if any(
        abs(_dot(first.unit_normal, point) - first.plane_offset) > tolerance
        for point in second.points
    ) or any(
        abs(_dot(second.unit_normal, point) - second.plane_offset) > tolerance
        for point in first.points
    ):
        return 0.0
    drop_axis = max(range(3), key=lambda axis: abs(first.unit_normal[axis]))
    projected_axes = tuple(axis for axis in range(3) if axis != drop_axis)
    first_2d = tuple(
        (point[projected_axes[0]], point[projected_axes[1]])
        for point in first.points
    )
    second_2d = tuple(
        (point[projected_axes[0]], point[projected_axes[1]])
        for point in second.points
    )
    projected_area = math.fsum(
        _convex_clip_area_2d(left, right)
        for left in _triangles_2d(first_2d)
        for right in _triangles_2d(second_2d)
    )
    normal_scale = abs(first.unit_normal[drop_axis])
    if normal_scale <= 0.0:
        return 0.0
    area = projected_area / normal_scale
    return area if area > tolerance * tolerance else 0.0


def _bbox_overlaps(
    first: _BoundaryFaceGeometry,
    second: _BoundaryFaceGeometry,
    *,
    tolerance: float,
) -> bool:
    return all(
        first.maximum[axis] + tolerance >= second.minimum[axis]
        and second.maximum[axis] + tolerance >= first.minimum[axis]
        for axis in range(3)
    )


def _audit_no_unpaired_coplanar_free_face_overlap(
    elements: Sequence[AssembledMixedElement],
    nodes: Mapping[int, Point3D],
    face_owners: Mapping[tuple[int, ...], Sequence[AssembledMixedElement]],
    *,
    tolerance: float,
    error_type: type[ValueError] = MixedMeshAssemblyError,
) -> None:
    """Reject positive-area coincident free faces from distinct fragments."""

    faces: list[_BoundaryFaceGeometry] = []
    for element in elements:
        for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
            cycle = tuple(element.node_tags[index] for index in local_face)
            key = tuple(sorted(cycle))
            if len(face_owners[key]) != 1:
                continue
            geometry = _boundary_face_geometry(
                element,
                cycle,
                nodes,
                tolerance=tolerance,
            )
            if geometry is not None:
                faces.append(geometry)
    if len(faces) < 2:
        return
    cell_size = max(
        4.0 * tolerance,
        median(math.sqrt(_polygon_area_3d(face.points)) for face in faces),
    )
    buckets: dict[
        tuple[int, int, int], dict[str, list[int]]
    ] = defaultdict(lambda: defaultdict(list))
    broad_faces_by_fragment: dict[str, list[int]] = defaultdict(list)
    prior_faces_by_fragment: dict[str, list[int]] = defaultdict(list)
    maximum_buckets_per_face = 4096
    for current_index, current in enumerate(faces):
        ranges = tuple(
            range(
                math.floor((current.minimum[axis] - tolerance) / cell_size),
                math.floor((current.maximum[axis] + tolerance) / cell_size) + 1,
            )
            for axis in range(3)
        )
        bucket_count = math.prod(len(value) for value in ranges)
        keys = (
            tuple((x, y, z) for x in ranges[0] for y in ranges[1] for z in ranges[2])
            if bucket_count <= maximum_buckets_per_face
            else ()
        )
        candidates = {
            index
            for fragment_key, indices in broad_faces_by_fragment.items()
            if fragment_key != current.fragment_key
            for index in indices
        }
        if keys:
            for key in keys:
                candidates.update(
                    index
                    for fragment_key, indices in buckets.get(key, {}).items()
                    if fragment_key != current.fragment_key
                    for index in indices
                )
        else:
            candidates.update(
                index
                for fragment_key, indices in prior_faces_by_fragment.items()
                if fragment_key != current.fragment_key
                for index in indices
            )
        for previous_index in sorted(candidates):
            previous = faces[previous_index]
            if (
                previous.fragment_key == current.fragment_key
                or not _bbox_overlaps(previous, current, tolerance=tolerance)
            ):
                continue
            area = _coplanar_overlap_area_mm2(
                previous,
                current,
                tolerance=tolerance,
            )
            if area <= 0.0:
                continue
            raise error_type(
                "distinct fragments contain unpaired positive-area coplanar "
                "free faces: "
                f"first_fragment={previous.fragment_key!r}, "
                f"first_element={previous.element_tag}, "
                f"first_nodes={previous.node_tags!r}; "
                f"second_fragment={current.fragment_key!r}, "
                f"second_element={current.element_tag}, "
                f"second_nodes={current.node_tags!r}; "
                f"overlap_area_mm2={area:.12g}, tolerance_mm={tolerance:.12g}"
            )
        if keys:
            for key in keys:
                buckets[key][current.fragment_key].append(current_index)
        else:
            broad_faces_by_fragment[current.fragment_key].append(current_index)
        prior_faces_by_fragment[current.fragment_key].append(current_index)


def assemble_mixed_volume_mesh(
    fragments: Sequence[ComponentLocalMeshFragment],
    *,
    frozen_mesh: VolumeMesh | None = None,
    shared_coordinates: Sequence[DeclaredSharedCoordinate] = (),
    declared_seams: Sequence[DeclaredSharedSeam] = (),
    expected_complete_support_plane_interfaces: Sequence[
        ExpectedCompleteSupportPlaneInterface
    ] = (),
    frozen_semantic_namespace: str = _DEFAULT_FROZEN_NAMESPACE,
    coordinate_tolerance_mm: float = 1.0e-10,
    interface_geometry_tolerance_mm: float | None = None,
) -> MixedMeshAssemblyPlan:
    """Assemble an immutable volume-only plan without coordinate-based merging."""

    try:
        fragment_values = tuple(fragments)
        coordinate_values = tuple(shared_coordinates)
        seam_values = tuple(declared_seams)
        expected_interface_values = tuple(
            expected_complete_support_plane_interfaces
        )
    except TypeError as error:
        raise MixedMeshAssemblyError("mixed mesh inputs must be sequences") from error
    if any(
        not isinstance(fragment, ComponentLocalMeshFragment)
        for fragment in fragment_values
    ):
        raise MixedMeshAssemblyError(
            "fragments must contain ComponentLocalMeshFragment values"
        )
    if any(
        not isinstance(value, DeclaredSharedCoordinate)
        for value in coordinate_values
    ) or any(not isinstance(value, DeclaredSharedSeam) for value in seam_values):
        raise MixedMeshAssemblyError("shared declarations are invalid")
    if any(
        type(value) is not ExpectedCompleteSupportPlaneInterface
        for value in expected_interface_values
    ):
        raise MixedMeshAssemblyError(
            "expected complete support-plane interfaces are invalid"
        )
    if not fragment_values and frozen_mesh is None:
        raise MixedMeshAssemblyError("mixed mesh assembly cannot be empty")
    if (
        isinstance(coordinate_tolerance_mm, bool)
        or not isinstance(coordinate_tolerance_mm, (int, float))
        or not math.isfinite(float(coordinate_tolerance_mm))
        or coordinate_tolerance_mm <= 0.0
    ):
        raise MixedMeshAssemblyError("coordinate_tolerance_mm must be positive")
    tolerance = float(coordinate_tolerance_mm)
    if interface_geometry_tolerance_mm is None:
        shared_tolerance = tolerance
    else:
        try:
            shared_tolerance = validate_interface_geometry_tolerance_mm(
                interface_geometry_tolerance_mm
            )
        except ValueError as error:
            raise MixedMeshAssemblyError(str(error)) from error
    namespace = _canonical_text(
        frozen_semantic_namespace, field_name="Frozen semantic namespace"
    )
    if frozen_mesh is not None:
        _validate_frozen_mesh(frozen_mesh)

    fragment_by_key: dict[str, ComponentLocalMeshFragment] = {}
    component_material: dict[str, str] = {}
    for fragment in fragment_values:
        if fragment.fragment_key in fragment_by_key:
            raise MixedMeshAssemblyError("fragment_key values must be unique")
        fragment_by_key[fragment.fragment_key] = fragment
        previous = component_material.setdefault(
            fragment.component_key, fragment.material_name
        )
        if previous != fragment.material_name:
            raise MixedMeshAssemblyError(
                "one generated component cannot have multiple materials"
            )
    known_fragment_keys = set(fragment_by_key)
    if frozen_mesh is not None:
        known_fragment_keys.add(FROZEN_FRAGMENT_KEY)
    interface_keys: set[str] = set()
    for expected in expected_interface_values:
        if expected.interface_key in interface_keys:
            raise MixedMeshAssemblyError(
                "expected complete support-plane interface keys must be unique"
            )
        interface_keys.add(expected.interface_key)
        if {
            expected.first_fragment_key,
            expected.second_fragment_key,
        } - known_fragment_keys:
            raise MixedMeshAssemblyError(
                "expected complete support-plane interface references an unknown "
                "fragment"
            )

    nodes: dict[MeshNodeReference, _InputNode] = {}
    input_elements: list[_InputElement] = []
    if frozen_mesh is not None:
        for node in frozen_mesh.nodes:
            reference = MeshNodeReference(FROZEN_FRAGMENT_KEY, node.tag)
            nodes[reference] = _InputNode(
                node.coordinates,
                frozen_node_semantic_token(node.tag, namespace=namespace),
                True,
            )
        for element in frozen_mesh.elements:
            input_elements.append(
                _InputElement(
                    FROZEN_FRAGMENT_KEY,
                    element.tag,
                    element.gmsh_type,
                    element.node_tags,
                    FROZEN_FRAGMENT_KEY,
                    FROZEN_FRAGMENT_KEY,
                    "frozen_source",
                    element,
                )
            )
    for fragment in sorted(fragment_values, key=lambda value: value.fragment_key):
        for node in fragment.nodes:
            reference = MeshNodeReference(
                fragment.fragment_key, node.local_node_id
            )
            nodes[reference] = _InputNode(
                node.coordinates_mm, node.semantic_token, False
            )
        for element in fragment.elements:
            input_elements.append(
                _InputElement(
                    fragment.fragment_key,
                    element.local_element_id,
                    element.gmsh_type,
                    element.node_ids,
                    fragment.component_key,
                    fragment.material_name,
                    element.provenance,
                    None,
                    element.element_set_names,
                )
            )

    disjoint = _DisjointSet(tuple(nodes))
    by_token: dict[str, list[MeshNodeReference]] = defaultdict(list)
    for reference, node in nodes.items():
        if node.semantic_token is not None:
            by_token[node.semantic_token].append(reference)
    for references in by_token.values():
        for reference in references[1:]:
            disjoint.join(references[0], reference)
    declaration_keys: set[str] = set()
    for declaration in coordinate_values:
        if declaration.declaration_key in declaration_keys:
            raise MixedMeshAssemblyError(
                "shared coordinate declaration keys must be unique"
            )
        declaration_keys.add(declaration.declaration_key)
        if any(reference not in nodes for reference in declaration.nodes):
            raise MixedMeshAssemblyError(
                "shared coordinate references an unknown input node"
            )
        for reference in declaration.nodes[1:]:
            disjoint.join(declaration.nodes[0], reference)

    members_by_root: dict[MeshNodeReference, list[MeshNodeReference]] = defaultdict(list)
    for reference in sorted(nodes):
        members_by_root[disjoint.root(reference)].append(reference)
    canonical_coordinate: dict[MeshNodeReference, Point3D] = {}
    for root, members in members_by_root.items():
        frozen_members = [reference for reference in members if nodes[reference].frozen]
        if len(frozen_members) > 1:
            raise MixedMeshAssemblyError(
                "distinct Frozen nodes cannot be merged by a semantic declaration"
            )
        coordinate = (
            nodes[frozen_members[0]].coordinates
            if frozen_members
            else nodes[min(members)].coordinates
        )
        if any(
            math.dist(coordinate, nodes[reference].coordinates) > shared_tolerance
            for reference in members
        ):
            raise MixedMeshAssemblyError(
                "shared semantic/declaration nodes disagree in coordinate"
            )
        canonical_coordinate[root] = coordinate
    collision = _nearby_identity_collision(canonical_coordinate, tolerance)
    if collision is not None:
        raise MixedMeshAssemblyError(
            "coincident nodes lack a common semantic token or explicit "
            f"shared-coordinate declaration: {collision!r}"
        )

    output_tag_by_root: dict[MeshNodeReference, int] = {}
    maximum_frozen_node = (
        max(node.tag for node in frozen_mesh.nodes) if frozen_mesh is not None else 0
    )
    generated_roots: list[MeshNodeReference] = []
    for root, members in members_by_root.items():
        frozen_members = [reference for reference in members if nodes[reference].frozen]
        if frozen_members:
            output_tag_by_root[root] = frozen_members[0].local_node_id
        else:
            generated_roots.append(root)
    for offset, root in enumerate(
        sorted(generated_roots, key=lambda value: tuple(members_by_root[value])),
        start=1,
    ):
        output_tag_by_root[root] = maximum_frozen_node + offset
    output_tag_by_reference = {
        reference: output_tag_by_root[disjoint.root(reference)]
        for reference in nodes
    }
    assembled_nodes = tuple(
        sorted(
            (
                AssembledMixedNode(
                    output_tag_by_root[root],
                    canonical_coordinate[root],
                    tuple(members),
                    tuple(
                        sorted(
                            {
                                token
                                for reference in members
                                if (token := nodes[reference].semantic_token)
                                is not None
                            }
                        )
                    ),
                )
                for root, members in members_by_root.items()
            ),
            key=lambda value: value.output_tag,
        )
    )

    group_registry = _physical_registry(frozen_mesh)
    all_solids_group = _all_solids_group(group_registry, frozen_mesh)
    component_groups = {
        component: _allocate_group(
            group_registry, name=_component_physical_name(component)
        )
        for component in sorted(component_material)
    }
    material_groups = {
        material: _material_physical_group(group_registry, material)
        for material in sorted(set(component_material.values()))
    }
    element_set_groups = {
        name: _allocate_group(group_registry, name=name)
        for name in sorted({name for value in input_elements for name in value.element_set_names})
    }

    frozen_entities = (
        {
            *(element.entity_tag for element in frozen_mesh.elements),
            *frozen_mesh.entity_physical_groups,
        }
        if frozen_mesh is not None
        else set()
    )
    if any(tag < 1 for tag in frozen_entities):
        raise MixedMeshAssemblyError("Frozen entity tags must be positive")
    next_entity = max(frozen_entities, default=0) + 1
    entity_by_fragment = {FROZEN_FRAGMENT_KEY: 0}
    for fragment_key in sorted(fragment_by_key):
        while next_entity in frozen_entities:
            next_entity += 1
        entity_by_fragment[fragment_key] = next_entity
        next_entity += 1
    maximum_frozen_element = (
        max(element.tag for element in frozen_mesh.elements)
        if frozen_mesh is not None
        else 0
    )
    entity_by_set_partition = {}
    next_generated_element = maximum_frozen_element + 1
    assembled_elements: list[AssembledMixedElement] = []
    local_face_owners: Counter[tuple[str, tuple[int, ...]]] = Counter()
    local_face_cycles: dict[
        tuple[str, tuple[int, ...]], tuple[int, ...]
    ] = {}
    for value in input_elements:
        specification = ELEMENT_SPECS[value.gmsh_type]
        for face in specification[2]:
            cycle = tuple(value.local_node_ids[index] for index in face)
            local_key = (value.source_fragment_key, tuple(sorted(cycle)))
            local_face_owners[local_key] += 1
            local_face_cycles.setdefault(local_key, cycle)
        if value.frozen_element is not None:
            frozen = value.frozen_element
            output_tag = frozen.tag
            output_nodes = frozen.node_tags
            entity_tag = frozen.entity_tag
            groups = tuple(sorted(frozen.physical_groups, key=lambda group: group.tag))
            original = frozen.tag
        else:
            output_tag = next_generated_element
            next_generated_element += 1
            output_nodes = tuple(
                output_tag_by_reference[
                    MeshNodeReference(value.source_fragment_key, node)
                ]
                for node in value.local_node_ids
            )
            entity_tag = entity_by_fragment[value.source_fragment_key]
            if value.element_set_names:
                key = (value.source_fragment_key, value.element_set_names)
                if key not in entity_by_set_partition:
                    entity_by_set_partition[key] = next_entity
                    next_entity += 1
                entity_tag = entity_by_set_partition[key]
            groups = tuple(
                sorted(
                    (
                        component_groups[value.component_key],
                        material_groups[value.material_name],
                        all_solids_group,
                        *(element_set_groups[name] for name in value.element_set_names),
                    ),
                    key=lambda group: group.tag,
                )
            )
            original = None
        if len(set(output_nodes)) != len(output_nodes):
            raise MixedMeshAssemblyError(
                "node sharing collapsed one volume element connectivity"
            )
        assembled_elements.append(
            AssembledMixedElement(
                output_tag,
                value.gmsh_type,
                output_nodes,
                entity_tag,
                value.source_fragment_key,
                value.component_key,
                value.material_name,
                value.provenance,
                groups,
                original,
                value.local_element_id,
            )
        )
    assembled_elements.sort(key=lambda value: value.output_tag)
    if len({element.output_tag for element in assembled_elements}) != len(
        assembled_elements
    ):
        raise MixedMeshAssemblyError("Frozen and generated element tags collide")

    duplicate_elements: dict[
        tuple[int, tuple[int, ...]], AssembledMixedElement
    ] = {}
    for element in assembled_elements:
        key = (element.gmsh_type, tuple(sorted(element.node_tags)))
        previous = duplicate_elements.get(key)
        if previous is not None:
            raise MixedMeshAssemblyError(
                "duplicate volume elements are forbidden: "
                f"{previous.output_tag} and {element.output_tag}"
            )
        duplicate_elements[key] = element

    face_owners: dict[
        tuple[int, ...], list[AssembledMixedElement]
    ] = defaultdict(list)
    for element in assembled_elements:
        for face in ELEMENT_SPECS[element.gmsh_type][2]:
            face_owners[
                tuple(sorted(element.node_tags[index] for index in face))
            ].append(element)
    over_owned = next(
        (
            (face, owners)
            for face, owners in sorted(face_owners.items())
            if len(owners) not in {1, 2}
        ),
        None,
    )
    if over_owned is not None:
        face, owners = over_owned
        raise MixedMeshAssemblyError(
            f"volume face {face!r} has {len(owners)} owners; expected one or two"
        )

    seam_keys: set[str] = set()
    declared_face_keys: dict[tuple[int, ...], str] = {}
    sizing_target_by_contract: dict[str, float] = {}
    sizing_faces_by_contract: dict[str, list[tuple[int, ...]]] = defaultdict(list)
    for seam in seam_values:
        if seam.seam_key in seam_keys:
            raise MixedMeshAssemblyError("declared seam keys must be unique")
        seam_keys.add(seam.seam_key)
        mapped_face_cycles: list[tuple[int, ...]] = []
        mapped_face_keys: list[tuple[int, ...]] = []
        for face in seam.faces:
            if face.fragment_key == FROZEN_FRAGMENT_KEY:
                if frozen_mesh is None:
                    raise MixedMeshAssemblyError(
                        "declared seam references Frozen input, but none was supplied"
                    )
            elif face.fragment_key not in fragment_by_key:
                raise MixedMeshAssemblyError(
                    "declared seam references an unknown fragment"
                )
            references = tuple(
                MeshNodeReference(face.fragment_key, node)
                for node in face.node_ids
            )
            if any(reference not in nodes for reference in references):
                raise MixedMeshAssemblyError(
                    "declared seam face references an unknown node"
                )
            local_key = (face.fragment_key, tuple(sorted(face.node_ids)))
            if local_face_owners[local_key] != 1:
                raise MixedMeshAssemblyError(
                    "each declared seam face must be owned by exactly one "
                    "source-fragment element"
                )
            cycle = tuple(
                output_tag_by_reference[reference]
                for reference in references
            )
            mapped_face_cycles.append(cycle)
            mapped_face_keys.append(tuple(sorted(cycle)))
        if mapped_face_keys[0] != mapped_face_keys[1]:
            raise MixedMeshAssemblyError(
                "declared seam faces do not resolve to the same shared nodes"
            )
        face_key = mapped_face_keys[0]
        if face_key in declared_face_keys:
            raise MixedMeshAssemblyError(
                "one assembled face cannot be covered by multiple seam declarations"
            )
        owners = face_owners.get(face_key, ())
        expected_fragments = {face.fragment_key for face in seam.faces}
        if (
            len(owners) != 2
            or {owner.source_fragment_key for owner in owners}
            != expected_fragments
        ):
            raise MixedMeshAssemblyError(
                "declared seam must resolve to exactly two owners from its two "
                "declared fragments"
            )
        declared_face_keys[face_key] = seam.seam_key
        if seam.sizing_contract_id is not None:
            assert seam.target_edge_mm is not None
            previous_target = sizing_target_by_contract.setdefault(
                seam.sizing_contract_id,
                seam.target_edge_mm,
            )
            if not math.isclose(
                previous_target,
                seam.target_edge_mm,
                rel_tol=1.0e-12,
                abs_tol=1.0e-12,
            ):
                raise MixedMeshAssemblyError(
                    "one shared-surface sizing contract has inconsistent targets"
                )
            # ``face_key`` is intentionally unordered and is used only for
            # identity/ownership checks.  Edge-size audit needs a real
            # boundary cycle; retain the first declared owner's ordered facet
            # after node unification instead of accidentally treating a
            # sorted QUAD key as a polygon (which would measure a diagonal).
            sizing_faces_by_contract[seam.sizing_contract_id].append(
                mapped_face_cycles[0]
            )

    expected_face_owner: dict[tuple[int, ...], str] = {}
    assembled_complete_interfaces: list[
        AssembledCompleteSupportPlaneInterface
    ] = []

    def support_plane_faces(
        fragment_key: str,
        axis: int,
        coordinate: float,
    ) -> dict[tuple[int, ...], tuple[int, ...]]:
        output: dict[tuple[int, ...], tuple[int, ...]] = {}
        for local_key, owner_count in local_face_owners.items():
            if local_key[0] != fragment_key or owner_count != 1:
                continue
            local_cycle = local_face_cycles[local_key]
            references = tuple(
                MeshNodeReference(fragment_key, node) for node in local_cycle
            )
            if not all(
                abs(nodes[reference].coordinates[axis] - coordinate)
                <= shared_tolerance
                for reference in references
            ):
                continue
            cycle = tuple(output_tag_by_reference[reference] for reference in references)
            face_key = tuple(sorted(cycle))
            previous = output.setdefault(face_key, cycle)
            if previous != cycle:
                raise MixedMeshAssemblyError(
                    "support-plane node unification collapsed distinct source "
                    "boundary facets"
                )
        return output

    assembled_coordinate_by_tag = {
        node.output_tag: node.coordinates_mm for node in assembled_nodes
    }
    for expected in sorted(
        expected_interface_values, key=lambda value: value.interface_key
    ):
        first_faces = support_plane_faces(
            expected.first_fragment_key,
            expected.plane_axis,
            expected.plane_coordinate_mm,
        )
        second_faces = support_plane_faces(
            expected.second_fragment_key,
            expected.plane_axis,
            expected.plane_coordinate_mm,
        )
        if not first_faces or not second_faces:
            raise MixedMeshAssemblyError(
                "expected complete support-plane interface has an empty side: "
                f"interface={expected.interface_key!r}, "
                f"first_face_count={len(first_faces)}, "
                f"second_face_count={len(second_faces)}"
            )
        if set(first_faces) != set(second_faces):
            first_only = tuple(sorted(set(first_faces) - set(second_faces)))
            second_only = tuple(sorted(set(second_faces) - set(first_faces)))
            raise MixedMeshAssemblyError(
                "expected complete support-plane interface is not 100% "
                "node/facet conformal: "
                f"interface={expected.interface_key!r}, "
                f"first_fragment={expected.first_fragment_key!r}, "
                f"second_fragment={expected.second_fragment_key!r}, "
                f"first_face_count={len(first_faces)}, "
                f"second_face_count={len(second_faces)}, "
                f"first_only_count={len(first_only)}, "
                f"second_only_count={len(second_only)}, "
                f"first_only_sample={first_only[:3]!r}, "
                f"second_only_sample={second_only[:3]!r}"
            )
        area = 0.0
        cycles: list[tuple[int, ...]] = []
        for face_key in sorted(first_faces):
            previous_interface = expected_face_owner.setdefault(
                face_key, expected.interface_key
            )
            if previous_interface != expected.interface_key:
                raise MixedMeshAssemblyError(
                    "one complete support-plane facet belongs to multiple "
                    "expected interfaces"
                )
            owners = face_owners.get(face_key, ())
            if (
                len(owners) != 2
                or {owner.source_fragment_key for owner in owners}
                != {
                    expected.first_fragment_key,
                    expected.second_fragment_key,
                }
            ):
                raise MixedMeshAssemblyError(
                    "expected complete support-plane facet does not have exactly "
                    "the two declared fragment owners: "
                    f"interface={expected.interface_key!r}, face={face_key!r}"
                )
            owner_sides: list[int] = []
            for owner in owners:
                off_face_nodes = tuple(
                    node for node in owner.node_tags if node not in face_key
                )
                signed_distances = tuple(
                    assembled_coordinate_by_tag[node][expected.plane_axis]
                    - expected.plane_coordinate_mm
                    for node in off_face_nodes
                )
                if not signed_distances or any(
                    abs(distance) <= shared_tolerance
                    for distance in signed_distances
                ):
                    raise MixedMeshAssemblyError(
                        "complete support-plane owner has no unambiguous volume "
                        "side beyond the interface tolerance: "
                        f"interface={expected.interface_key!r}, "
                        f"element={owner.output_tag}"
                    )
                signs = {1 if distance > 0.0 else -1 for distance in signed_distances}
                if len(signs) != 1:
                    raise MixedMeshAssemblyError(
                        "one complete support-plane owner straddles its interface: "
                        f"interface={expected.interface_key!r}, "
                        f"element={owner.output_tag}"
                    )
                owner_sides.append(next(iter(signs)))
            if set(owner_sides) != {-1, 1}:
                raise MixedMeshAssemblyError(
                    "complete support-plane owners do not occupy opposite sides: "
                    f"interface={expected.interface_key!r}, face={face_key!r}, "
                    f"owner_elements={tuple(owner.output_tag for owner in owners)!r}"
                )
            if face_key not in declared_face_keys:
                raise MixedMeshAssemblyError(
                    "expected complete support-plane facet lacks an explicit seam "
                    f"declaration: interface={expected.interface_key!r}, "
                    f"face={face_key!r}"
                )
            cycle = first_faces[face_key]
            face_area = _polygon_area_3d(
                tuple(assembled_coordinate_by_tag[node] for node in cycle)
            )
            if face_area <= shared_tolerance * shared_tolerance:
                raise MixedMeshAssemblyError(
                    "expected complete support-plane interface contains a "
                    "zero-area facet"
                )
            area += face_area
            cycles.append(cycle)
        assembled_complete_interfaces.append(
            AssembledCompleteSupportPlaneInterface(
                expected.interface_key,
                expected.first_fragment_key,
                expected.second_fragment_key,
                expected.plane_axis,
                expected.plane_coordinate_mm,
                tuple(cycles),
                area,
            )
        )

    for face_key, owners in sorted(face_owners.items()):
        if (
            len(owners) == 2
            and owners[0].source_fragment_key
            != owners[1].source_fragment_key
            and face_key not in declared_face_keys
        ):
            raise MixedMeshAssemblyError(
                "an internal face shared by distinct fragments lacks an explicit "
                f"seam declaration: {face_key!r}"
            )

    _audit_no_unpaired_coplanar_free_face_overlap(
        assembled_elements,
        assembled_coordinate_by_tag,
        face_owners,
        tolerance=shared_tolerance,
    )

    entity_groups: dict[int, tuple[PhysicalGroup, ...]] = {}
    if frozen_mesh is not None:
        frozen_element_groups = {
            element.entity_tag: tuple(
                sorted(element.physical_groups, key=lambda group: group.tag)
            )
            for element in frozen_mesh.elements
        }
        for entity_tag in sorted(frozen_entities):
            entity_groups[entity_tag] = tuple(
                sorted(
                    frozen_mesh.entity_physical_groups.get(
                        entity_tag,
                        frozen_element_groups.get(entity_tag, ()),
                    ),
                    key=lambda group: group.tag,
                )
            )
    for fragment in fragment_values:
        entity_groups[entity_by_fragment[fragment.fragment_key]] = tuple(
            sorted(
                (
                    component_groups[fragment.component_key],
                    material_groups[fragment.material_name],
                    all_solids_group,
                ),
                key=lambda group: group.tag,
            )
        )
    for element in assembled_elements:
        groups = entity_groups.setdefault(element.entity_tag, element.physical_groups)
        if groups != element.physical_groups:
            raise MixedMeshAssemblyError(
                "one volume entity cannot carry inconsistent Physical Groups"
            )

    kind_counts: dict[str, Counter[str]] = defaultdict(Counter)
    provenance_counts: dict[str, Counter[str]] = defaultdict(Counter)
    for element in assembled_elements:
        kind_counts[element.component_key][element.kind.value] += 1
        provenance_counts[element.component_key][element.provenance] += 1

    audit = MixedMeshAssemblyAudit(
        node_count=len(assembled_nodes),
        element_count=len(assembled_elements),
        free_face_count=sum(len(owners) == 1 for owners in face_owners.values()),
        internal_face_count=sum(len(owners) == 2 for owners in face_owners.values()),
        declared_seam_count=len(seam_values),
        declared_seam_face_count=len(declared_face_keys),
        complete_support_plane_interface_count=len(
            assembled_complete_interfaces
        ),
        complete_support_plane_face_count=sum(
            len(value.face_node_tags) for value in assembled_complete_interfaces
        ),
        unpaired_coplanar_free_face_overlap_count=0,
        component_kind_counts=_freeze_nested_counts(kind_counts),
        component_provenance_counts=_freeze_nested_counts(provenance_counts),
    )
    sizing_contracts = tuple(
        AssembledSharedSurfaceSizingContract(
            contract_id,
            sizing_target_by_contract[contract_id],
            tuple(
                sorted(
                    sizing_faces_by_contract[contract_id],
                    key=lambda value: (len(value), tuple(sorted(value))),
                )
            ),
        )
        for contract_id in sorted(sizing_target_by_contract)
    )
    return MixedMeshAssemblyPlan(
        nodes=assembled_nodes,
        elements=tuple(assembled_elements),
        physical_groups=tuple(
            sorted(group_registry.values(), key=lambda group: group.tag)
        ),
        entity_physical_groups=MappingProxyType(
            dict(sorted(entity_groups.items()))
        ),
        component_physical_groups=MappingProxyType(
            dict(sorted(component_groups.items()))
        ),
        material_physical_groups=MappingProxyType(
            dict(sorted(material_groups.items()))
        ),
        shared_surface_sizing_contracts=sizing_contracts,
        complete_support_plane_interfaces=tuple(assembled_complete_interfaces),
        interface_geometry_tolerance_mm=shared_tolerance,
        audit=audit,
    )


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise MixedMeshAssemblyError(
            "Gmsh is required to write a mixed volume mesh"
        ) from error
    return gmsh


def _add_live_model(gmsh: Any, plan: MixedMeshAssemblyPlan) -> None:
    entity_tags = tuple(sorted(plan.entity_physical_groups))
    if not entity_tags:
        raise MixedMeshAssemblyError("mixed mesh plan has no volume entities")
    for entity_tag in entity_tags:
        actual = int(gmsh.model.addDiscreteEntity(3, entity_tag))
        if actual != entity_tag:
            raise MixedMeshAssemblyError("Gmsh changed a volume entity tag")
    host_entity = entity_tags[0]
    gmsh.model.mesh.addNodes(
        3,
        host_entity,
        [node.output_tag for node in plan.nodes],
        [coordinate for node in plan.nodes for coordinate in node.coordinates_mm],
    )
    elements_by_entity: dict[int, list[AssembledMixedElement]] = defaultdict(list)
    for element in plan.elements:
        elements_by_entity[element.entity_tag].append(element)
    for entity_tag in entity_tags:
        selected = elements_by_entity.get(entity_tag, ())
        for gmsh_type in sorted({element.gmsh_type for element in selected}):
            block = tuple(
                element for element in selected if element.gmsh_type == gmsh_type
            )
            gmsh.model.mesh.addElementsByType(
                entity_tag,
                gmsh_type,
                [element.output_tag for element in block],
                [node for element in block for node in element.node_tags],
            )
    for group in plan.physical_groups:
        members = tuple(
            entity_tag
            for entity_tag, groups in plan.entity_physical_groups.items()
            if group in groups
        )
        if not members:
            raise MixedMeshAssemblyError(
                f"Physical Group {group.tag} has no volume entity"
            )
        actual = int(gmsh.model.addPhysicalGroup(3, list(members), group.tag))
        if actual != group.tag:
            raise MixedMeshAssemblyError("Gmsh changed a Physical Group tag")
        if group.explicitly_named:
            gmsh.model.setPhysicalName(3, group.tag, group.name)


def _roundtrip_coordinate_matches(
    actual: float,
    expected: float,
    *,
    tolerance: float,
) -> bool:
    if actual == expected:
        return True
    return abs(actual - expected) <= min(
        tolerance,
        64.0 * max(math.ulp(actual), math.ulp(expected)),
    )


def _audit_reopened_mesh(
    mesh: VolumeMesh,
    plan: MixedMeshAssemblyPlan,
    *,
    frozen_mesh: VolumeMesh | None,
    coordinate_tolerance_mm: float,
) -> None:
    if mesh.dimensional_element_counts != (0, 0, 0, len(plan.elements)):
        raise MixedMeshAssemblyError(
            "reopened MSH does not contain the expected volume-only elements"
        )
    expected_nodes = {node.output_tag: node for node in plan.nodes}
    actual_nodes = mesh.node_map()
    if set(actual_nodes) != set(expected_nodes):
        raise MixedMeshAssemblyError("reopened MSH node tags changed")
    for tag, expected in expected_nodes.items():
        actual = actual_nodes[tag].coordinates
        if not all(
            _roundtrip_coordinate_matches(
                actual[index],
                expected.coordinates_mm[index],
                tolerance=coordinate_tolerance_mm,
            )
            for index in range(3)
        ):
            raise MixedMeshAssemblyError(
                f"reopened MSH changed node {tag} coordinates"
            )

    expected_elements = {element.output_tag: element for element in plan.elements}
    if {element.tag for element in mesh.elements} != set(expected_elements):
        raise MixedMeshAssemblyError("reopened MSH element tags changed")
    for actual in mesh.elements:
        expected = expected_elements[actual.tag]
        if (
            actual.gmsh_type != expected.gmsh_type
            or actual.kind is not expected.kind
            or actual.node_tags != expected.node_tags
            or actual.entity_tag != expected.entity_tag
            or actual.physical_groups != expected.physical_groups
        ):
            raise MixedMeshAssemblyError(
                f"reopened MSH changed element {actual.tag} identity"
            )
    if dict(mesh.entity_physical_groups) != dict(plan.entity_physical_groups):
        raise MixedMeshAssemblyError(
            "reopened MSH changed entity Physical Group membership"
        )

    if frozen_mesh is not None:
        frozen_nodes = frozen_mesh.node_map()
        for tag, frozen in frozen_nodes.items():
            actual = actual_nodes.get(tag)
            if actual is None or any(
                not _roundtrip_coordinate_matches(
                    actual.coordinates[index],
                    frozen.coordinates[index],
                    tolerance=coordinate_tolerance_mm,
                )
                for index in range(3)
            ):
                raise MixedMeshAssemblyError(
                    f"reopened MSH did not preserve Frozen node {tag}"
                )
        frozen_elements = {element.tag: element for element in frozen_mesh.elements}
        actual_elements = {element.tag: element for element in mesh.elements}
        for tag, frozen in frozen_elements.items():
            actual = actual_elements.get(tag)
            if actual is None or (
                actual.gmsh_type,
                actual.node_tags,
                actual.entity_tag,
                actual.physical_groups,
            ) != (
                frozen.gmsh_type,
                frozen.node_tags,
                frozen.entity_tag,
                frozen.physical_groups,
            ):
                raise MixedMeshAssemblyError(
                    f"reopened MSH did not preserve Frozen element {tag}"
                )


def _audit_reopened_gmsh(
    gmsh: Any,
    path: Path,
    plan: MixedMeshAssemblyPlan,
) -> None:
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_package_v2_mixed_reopen",
        number_options={"General.Terminal": 0.0},
    ):
        gmsh.merge(str(path))
        entities = tuple(
            sorted(
                (int(dimension), int(tag))
                for dimension, tag in gmsh.model.getEntities()
            )
        )
        expected_entities = tuple(
            (3, entity_tag) for entity_tag in sorted(plan.entity_physical_groups)
        )
        if entities != expected_entities:
            raise MixedMeshAssemblyError("reopened Gmsh entity set changed")
        if tuple(gmsh.model.mesh.getDuplicateNodes()):
            raise MixedMeshAssemblyError(
                "reopened Gmsh reports duplicate/coincident unshared nodes"
            )


def write_mixed_volume_mesh(
    output_path: str | Path,
    fragments: Sequence[ComponentLocalMeshFragment],
    *,
    frozen_mesh: VolumeMesh | None = None,
    shared_coordinates: Sequence[DeclaredSharedCoordinate] = (),
    declared_seams: Sequence[DeclaredSharedSeam] = (),
    expected_complete_support_plane_interfaces: Sequence[
        ExpectedCompleteSupportPlaneInterface
    ] = (),
    frozen_semantic_namespace: str = _DEFAULT_FROZEN_NAMESPACE,
    coordinate_tolerance_mm: float = 1.0e-10,
    interface_geometry_tolerance_mm: float | None = None,
    verbose: bool = False,
) -> MixedMeshWriteResult:
    """Atomically write an audited mixed MSH 4.1 file and reopen it."""

    output = normalized_mesh_output(output_path)
    if frozen_mesh is not None and paths_refer_to_same_file(
        output, frozen_mesh.source_path
    ):
        raise MixedMeshAssemblyError("output cannot overwrite its Frozen source")
    plan = assemble_mixed_volume_mesh(
        fragments,
        frozen_mesh=frozen_mesh,
        shared_coordinates=shared_coordinates,
        declared_seams=declared_seams,
        expected_complete_support_plane_interfaces=(
            expected_complete_support_plane_interfaces
        ),
        frozen_semantic_namespace=frozen_semantic_namespace,
        coordinate_tolerance_mm=coordinate_tolerance_mm,
        interface_geometry_tolerance_mm=interface_geometry_tolerance_mm,
    )
    gmsh = _load_gmsh()
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "General.NumThreads": 1.0,
        "Mesh.MshFileVersion": 4.1,
        "Mesh.Binary": 0.0,
        "Mesh.SaveAll": 1.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.MaxNumThreads1D": 1.0,
        "Mesh.MaxNumThreads2D": 1.0,
        "Mesh.MaxNumThreads3D": 1.0,
    }
    try:
        with exclusive_output_lock(output):
            with atomic_output_path(output) as temporary_mesh:
                with isolated_gmsh_model(
                    gmsh,
                    "__easymesh_package_v2_mixed_writer",
                    number_options=options,
                ):
                    _add_live_model(gmsh, plan)
                    if tuple(gmsh.model.mesh.getDuplicateNodes()):
                        raise MixedMeshAssemblyError(
                            "live mixed mesh contains duplicate/coincident nodes"
                        )
                    gmsh.write(str(temporary_mesh))
                reopened = load_volume_mesh(temporary_mesh)
                _audit_reopened_mesh(
                    reopened,
                    plan,
                    frozen_mesh=frozen_mesh,
                    coordinate_tolerance_mm=float(coordinate_tolerance_mm),
                )
                _audit_reopened_gmsh(gmsh, temporary_mesh, plan)
                artifact = file_artifact(temporary_mesh, published_path=output)
    except MixedMeshAssemblyError:
        raise
    except Exception as error:
        raise MixedMeshAssemblyError(
            f"cannot publish mixed volume mesh: {error}"
        ) from error
    published = load_volume_mesh(output)
    _audit_reopened_mesh(
        published,
        plan,
        frozen_mesh=frozen_mesh,
        coordinate_tolerance_mm=float(coordinate_tolerance_mm),
    )
    return MixedMeshWriteResult(
        output,
        published,
        plan,
        MappingProxyType(dict(artifact)),
    )


__all__ = [
    "AssembledCompleteSupportPlaneInterface",
    "AssembledMixedElement",
    "AssembledMixedNode",
    "AssembledSharedSurfaceSizingContract",
    "ComponentLocalMeshFragment",
    "ComponentMeshElement",
    "ComponentMeshNode",
    "DeclaredSharedCoordinate",
    "DeclaredSharedSeam",
    "ExpectedCompleteSupportPlaneInterface",
    "FROZEN_FRAGMENT_KEY",
    "FragmentFaceReference",
    "MeshNodeReference",
    "MixedMeshAssemblyAudit",
    "MixedMeshAssemblyError",
    "MixedMeshAssemblyPlan",
    "MixedMeshWriteResult",
    "assemble_mixed_volume_mesh",
    "frozen_node_semantic_token",
    "write_mixed_volume_mesh",
]
