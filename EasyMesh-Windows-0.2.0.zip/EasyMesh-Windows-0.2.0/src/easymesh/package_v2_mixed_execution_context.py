"""Role-free executable context for one lowered mixed Package V2 Source.

This layer binds neutral lowering to exact canonical fragment sides and real
Frozen boundary patches. Actual positive-area geometry creates the interface
policies; source-authored endpoint lists cannot create or suppress contact.
It does not choose a mesh backend: topology remains Component-owned.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from dataclasses import dataclass, replace
from types import MappingProxyType

from .package_assembly import Component, InterfaceMatch
from .package_v2_adjacency_execution import (
    ComponentAdjacencyExecutionPlan,
    plan_component_adjacency_execution,
)
from .package_v2_frozen import FrozenSourceSnapshot
from .package_v2_frozen_boundary_matching import (
    FrozenBoundaryMatchingError,
    MatchedFrozenBoundaryPatch,
    match_frozen_component_boundaries,
)
from .package_v2_geometry import CanonicalGeneratedGeometry
from .package_v2_mesh_ordering import MeshOrderingPlan, plan_mesh_ordering
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)
from .package_v2_mixed_source_lowering import (
    FrozenGeneratedInterfaceKey,
    LoweredFrozenInterfaceMatch,
    MixedSourceLowering,
)


class MixedExecutionContextError(ValueError):
    """Neutral lowering cannot be bound to unambiguous real boundaries."""


@dataclass(frozen=True, slots=True)
class MixedExecutionContext:
    lowering: MixedSourceLowering
    adjacency_execution: ComponentAdjacencyExecutionPlan
    frozen_patches_by_interface: Mapping[
        FrozenGeneratedInterfaceKey,
        tuple[MatchedFrozenBoundaryPatch, ...],
    ]
    mesh_ordering: MeshOrderingPlan
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    )

    def __post_init__(self) -> None:
        if type(self.lowering) is not MixedSourceLowering:
            raise MixedExecutionContextError("lowering has an invalid type")
        if type(self.adjacency_execution) is not ComponentAdjacencyExecutionPlan:
            raise MixedExecutionContextError(
                "adjacency_execution has an invalid type"
            )
        if not isinstance(self.frozen_patches_by_interface, Mapping):
            raise MixedExecutionContextError(
                "frozen_patches_by_interface must be a mapping"
            )
        object.__setattr__(
            self,
            "frozen_patches_by_interface",
            MappingProxyType(dict(self.frozen_patches_by_interface)),
        )
        if type(self.mesh_ordering) is not MeshOrderingPlan:
            raise MixedExecutionContextError("mesh_ordering has an invalid type")
        try:
            tolerance = validate_interface_geometry_tolerance_mm(
                self.interface_geometry_tolerance_mm
            )
        except ValueError as error:
            raise MixedExecutionContextError(str(error)) from error
        object.__setattr__(self, "interface_geometry_tolerance_mm", tolerance)


def _global_geometry(lowering: MixedSourceLowering) -> CanonicalGeneratedGeometry:
    return CanonicalGeneratedGeometry(
        "source",
        tuple(
            lowering.canonical_components_by_global_id[component_id]
            for component_id in sorted(
                lowering.canonical_components_by_global_id
            )
        ),
    )


def _patch_face_key(
    patch: MatchedFrozenBoundaryPatch,
    facet_index: int,
) -> tuple[int, ...]:
    return tuple(sorted(patch.facets[facet_index].source_node_tags))


def _discover_frozen_interfaces(
    lowering: MixedSourceLowering,
    snapshot: FrozenSourceSnapshot,
    *,
    interface_geometry_tolerance_mm: float,
) -> Mapping[
    FrozenGeneratedInterfaceKey,
    tuple[MatchedFrozenBoundaryPatch, ...],
]:
    output: dict[
        FrozenGeneratedInterfaceKey,
        list[MatchedFrozenBoundaryPatch],
    ] = defaultdict(list)
    owner_by_frozen_face: dict[
        tuple[str, tuple[int, ...]],
        tuple[FrozenGeneratedInterfaceKey, str, str],
    ] = {}
    components = lowering.canonical_components_by_global_id
    frozen_global_ids = tuple(
        sorted(
            {
                component.global_component_id
                for component in snapshot.components.values()
            }
        )
    )
    for frozen_global_id in frozen_global_ids:
        fragment_counts = tuple(
            len(component.fragments)
            for component in components.values()
        )
        for fragment_index in range(max(fragment_counts, default=0)):
            target_fragments = {
                component_id: component.fragments[fragment_index]
                for component_id, component in components.items()
                if fragment_index < len(component.fragments)
            }
            try:
                matched = match_frozen_component_boundaries(
                    snapshot,
                    frozen_component_global_id=frozen_global_id,
                    target_fragments=target_fragments,
                    allow_empty=True,
                    interface_geometry_tolerance_mm=(
                        interface_geometry_tolerance_mm
                    ),
                )
            except FrozenBoundaryMatchingError as error:
                raise MixedExecutionContextError(
                    "Frozen contact discovery is not executable for "
                    f"{frozen_global_id!r}, fragment batch {fragment_index}: "
                    f"{error}"
                ) from error
            for patch in matched:
                key = FrozenGeneratedInterfaceKey(
                    frozen_global_id,
                    patch.target_component_id,
                )
                expected_fragment = target_fragments[
                    patch.target_component_id
                ].fragment_id
                if patch.target_fragment_id != expected_fragment:
                    raise MixedExecutionContextError(
                        "Frozen matcher changed an explicit fragment identity"
                    )
                for index in range(len(patch.facets)):
                    face_key = _patch_face_key(patch, index)
                    owner_key = (frozen_global_id, face_key)
                    owner = (key, patch.target_fragment_id, patch.side_name)
                    previous = owner_by_frozen_face.setdefault(owner_key, owner)
                    if previous != owner:
                        raise MixedExecutionContextError(
                            "one Frozen exterior facet matches multiple generated "
                            "fragment sides"
                        )
                output[key].append(patch)

    resolved: dict[
        FrozenGeneratedInterfaceKey,
        tuple[MatchedFrozenBoundaryPatch, ...],
    ] = {}
    for key in sorted(output):
        patches = output[key]
        resolved[key] = tuple(
            sorted(
                patches,
                key=lambda value: (
                    value.target_fragment_id,
                    value.side_name,
                    tuple(
                        sorted(
                            tuple(sorted(facet.source_node_tags))
                            for facet in value.facets
                        )
                    ),
                ),
            )
        )
    return MappingProxyType(resolved)


def _bind_discovered_interfaces(
    lowering: MixedSourceLowering,
    snapshot: FrozenSourceSnapshot,
    patches: Mapping[FrozenGeneratedInterfaceKey, tuple[MatchedFrozenBoundaryPatch, ...]],
) -> MixedSourceLowering:
    """Create immutable trace policies only for measured positive-area contact."""
    local_by_global = {
        global_id: local
        for local, global_id in lowering.component_global_id_by_local_key.items()
    }
    frozen_local_by_global = {
        value.global_component_id: local for local, value in snapshot.components.items()
    }
    matches: dict[FrozenGeneratedInterfaceKey, LoweredFrozenInterfaceMatch] = {}
    for key in patches:
        global_id = key.generated_component_global_id
        local = local_by_global[global_id]
        geometry = lowering.canonical_components_by_global_id[global_id]
        policy = InterfaceMatch(
            Component.frozen(key.frozen_component_global_id, snapshot.source_id),
            Component.generated(
                global_id,
                geometry.material_name,
                tuple(fragment.fragment_id for fragment in geometry.fragments),
                mesh_control=lowering.component_mesh_controls_by_global_id[global_id],
            ),
        )
        matches[key] = LoweredFrozenInterfaceMatch(
            key,
            snapshot.source_id,
            frozen_local_by_global[key.frozen_component_global_id],
            local.instance_id,
            local.local_component_id,
            policy,
        )
    return replace(lowering, frozen_interface_matches=matches)


def discover_mixed_contacts(
    lowering: MixedSourceLowering,
    snapshot: FrozenSourceSnapshot,
):
    """Discover real contacts before testing whether their mesh order is executable."""

    if type(lowering) is not MixedSourceLowering:
        raise MixedExecutionContextError("lowering must be MixedSourceLowering")
    if type(snapshot) is not FrozenSourceSnapshot:
        raise MixedExecutionContextError("snapshot must be FrozenSourceSnapshot")
    tolerance = lowering.interface_geometry_tolerance_mm
    if (
        lowering.frozen_source_id != snapshot.source_id
        or lowering.frozen_snapshot_numbered_sha256 != snapshot.numbered_sha256
    ):
        raise MixedExecutionContextError(
            "lowering and Frozen snapshot identity differ"
        )
    geometry = _global_geometry(lowering)
    adjacency_execution = plan_component_adjacency_execution(
        geometry,
        lowering.component_mesh_requirements,
        lowering.generated_adjacencies,
        lowering.generated_interface_policies,
        interface_geometry_tolerance_mm=tolerance,
    )
    patches = _discover_frozen_interfaces(
        lowering,
        snapshot,
        interface_geometry_tolerance_mm=tolerance,
    )
    lowering = _bind_discovered_interfaces(lowering, snapshot, patches)
    return lowering, adjacency_execution, patches


def build_mixed_execution_context(
    lowering: MixedSourceLowering,
    snapshot: FrozenSourceSnapshot,
) -> MixedExecutionContext:
    """Bind generic lowering to actual side pairs and Frozen boundary faces."""
    lowering, adjacency_execution, patches = discover_mixed_contacts(lowering, snapshot)
    tolerance = lowering.interface_geometry_tolerance_mm
    source_face_owners: dict[
        tuple[int, ...], list[FrozenGeneratedInterfaceKey]
    ] = defaultdict(list)
    for key, values in patches.items():
        for patch in values:
            for index in range(len(patch.facets)):
                source_face_owners[_patch_face_key(patch, index)].append(key)
    duplicated = {
        face: owners
        for face, owners in source_face_owners.items()
        if len(set(owners)) > 1
    }
    if duplicated:
        raise MixedExecutionContextError(
            "one Frozen exterior facet is claimed by multiple explicit targets"
        )
    try:
        mesh_ordering = plan_mesh_ordering(
            lowering.canonical_components_by_global_id,
            lowering.component_mesh_controls_by_global_id,
            lowering.component_mesh_requirements,
            adjacency_execution,
            lowering.generated_interface_continuity_plan,
            lowering.frozen_interface_matches,
            patches,
        )
    except Exception as error:
        raise MixedExecutionContextError(
            f"mesh-priority constraint graph is not executable: {error}"
        ) from error
    return MixedExecutionContext(
        lowering,
        adjacency_execution,
        MappingProxyType(patches),
        mesh_ordering,
        tolerance,
    )


__all__ = [
    "MixedExecutionContext",
    "MixedExecutionContextError",
    "build_mixed_execution_context",
    "discover_mixed_contacts",
]
