"""Role-free Gmsh extrusion for Box and rectangular Frame geometry.

An inherited end section may be a complete mixed TRI3/QUAD4 partition or a
compatible partial coplanar patch.  For a partial mixed patch whose boundary
proves one complete planar subregion, Gmsh meshes the complementary
Box/Frame section while retaining every inherited node, facet and boundary
edge.  An axis-orthogonal QUAD-only partial patch may instead complete on one
compatible tensor partition.  Gmsh's native extrusion then returns
WEDGE6/HEX8 without EasyMesh inventing volume connectivity.  When no end section is
inherited, immutable lateral patches may instead prove a complete
section-boundary chain swept through one common set of axial levels. Partial
wall locks can also constrain this chain and the global layers without reaching
either endpoint. A downstream rectangular outer collar may require orthogonal
QUADs locally while the rest of the section remains mixed. Gmsh may then
complete the source section itself and return WEDGE6 and/or HEX8. EasyMesh
never trims a peripheral facet, drops a CUT cell, or manufactures 3-D
connectivity.

Only geometry and the component-owned mesh requirement participate in the
decision.  In particular, this module has no material, package-role, stack,
underfill, ``lower`` or ``upper`` routing.  A body whose complete sections are
not related by one translation is rejected with a geometric proof blocker.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace, replace
import math
from types import MappingProxyType
from typing import Any, TypeAlias

from .package_v2_mesh_sizing import MeshSeedPolicy, geometry_origin, interval_levels
from .package_assembly import StructuredSweepMeshStrategy
from .component_interface import ComponentMeshRequirement
from .gmsh_runtime import isolated_gmsh_model
from .gmsh_shared_surface import (
    BoundarySizePolicy,
    LockedBoundaryChain,
    PlanarRegion,
    generate_gmsh_shared_surface,
)
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRigidPlacement,
)
from .package_assembly import ComponentLocalDirection
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)
from .package_v2_mixed_mesh_assembly import (
    ComponentLocalMeshFragment,
    ComponentMeshElement,
    ComponentMeshNode,
)
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]
EndContactRegion: TypeAlias = tuple[tuple[Point3D, ...], ...]
_QUALITY_FLOOR = 0.03


@dataclass(frozen=True, slots=True)
class _LateralSweepTrace:
    """A proven Cartesian product of section edges and axial levels."""

    levels_mm: tuple[float, ...]
    segments_by_side: Mapping[str, tuple[tuple[float, float], ...]]


class StructuredSweepMaterializationError(ValueError):
    """A complete inherited section cannot be extruded without mutation."""


@dataclass(frozen=True, slots=True)
class StructuredSweepComponentMesh:
    canonical_fragment: CanonicalGeometryFragment
    requirement: ComponentMeshRequirement
    source_side_name: str
    component_fragment: ComponentLocalMeshFragment
    locked_facets_by_geometric_side: Mapping[
        str, tuple[tuple[int, ...], ...]
    ]
    boundary_facets_by_geometric_side: Mapping[
        str, tuple[tuple[int, ...], ...]
    ]
    source_node_id_by_local_id: Mapping[int, int]
    destination_node_id_by_source_node_id: Mapping[int, int]
    source_facets: tuple[tuple[int, ...], ...]
    destination_facets: tuple[tuple[int, ...], ...]
    element_counts: Mapping[str, int]
    face_incidence_histogram: Mapping[int, int]
    source_was_inherited: bool
    layer_count: int
    layer_thicknesses_mm: tuple[float, ...]
    source_section_area_mm2: float
    analytic_volume_mm3: float
    element_volume_mm3: float
    relative_volume_error: float
    boundary_face_count: int
    internal_face_count: int
    source_boundary_edge_count: int
    lateral_boundary_face_count: int
    source_facet_preserved_count: int
    destination_facet_correspondence_count: int
    minimum_determinant: float
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    gmsh_owns_all_volume_connectivity: bool = True
    partial_lateral_locks_verified: bool = False

    def __post_init__(self) -> None:
        for field_name in (
            "locked_facets_by_geometric_side",
            "boundary_facets_by_geometric_side",
            "source_node_id_by_local_id",
            "destination_node_id_by_source_node_id",
            "element_counts",
            "face_incidence_histogram",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )
        if self.requirement.volume_topology != "structured_sweep":
            raise StructuredSweepMaterializationError(
                "structured sweep result has the wrong requested topology"
            )
        if not self.gmsh_owns_all_volume_connectivity:
            raise StructuredSweepMaterializationError(
                "structured sweep volume connectivity must be Gmsh-owned"
            )
        if not isinstance(self.source_was_inherited, bool):
            raise StructuredSweepMaterializationError(
                "source_was_inherited must be boolean"
            )
        if self.layer_count < 1 or len(self.layer_thicknesses_mm) != self.layer_count:
            raise StructuredSweepMaterializationError(
                "structured sweep layer evidence is inconsistent"
            )
        if any(value <= 0.0 for value in self.layer_thicknesses_mm):
            raise StructuredSweepMaterializationError(
                "structured sweep layers must have positive thickness"
            )
        if self.source_facet_preserved_count != len(self.source_facets):
            raise StructuredSweepMaterializationError(
                "structured sweep did not preserve every source facet"
            )
        if self.destination_facet_correspondence_count != len(
            self.destination_facets
        ) or len(self.destination_facets) != len(self.source_facets):
            raise StructuredSweepMaterializationError(
                "structured sweep end sections are not in facet bijection"
            )
        if set(self.face_incidence_histogram).difference({1, 2}):
            raise StructuredSweepMaterializationError(
                "structured sweep has a non-manifold face incidence"
            )
        if self.face_incidence_histogram.get(1, 0) != self.boundary_face_count:
            raise StructuredSweepMaterializationError(
                "structured sweep boundary incidence evidence is inconsistent"
            )
        if self.face_incidence_histogram.get(2, 0) != self.internal_face_count:
            raise StructuredSweepMaterializationError(
                "structured sweep internal incidence evidence is inconsistent"
            )
        if self.analytic_volume_mm3 <= 0.0 or self.element_volume_mm3 <= 0.0:
            raise StructuredSweepMaterializationError(
                "structured sweep volume evidence must be positive"
            )
        if not math.isfinite(self.relative_volume_error) or (
            self.relative_volume_error > 1.0e-9
        ):
            raise StructuredSweepMaterializationError(
                "structured sweep volume does not equal section area times path length"
            )
        if not math.isfinite(self.minimum_determinant) or self.minimum_determinant <= 0.0:
            raise StructuredSweepMaterializationError(
                "structured sweep contains a non-positive Jacobian determinant"
            )
        if min(
            self.minimum_sicn,
            self.minimum_sige,
            self.minimum_scaled_jacobian,
        ) < _QUALITY_FLOOR:
            raise StructuredSweepMaterializationError(
                "structured sweep quality is below 0.03"
            )

    @property
    def element_count(self) -> int:
        return len(self.component_fragment.elements)

    @property
    def node_count(self) -> int:
        return len(self.component_fragment.nodes)

    @property
    def maximum_layer_thickness_mm(self) -> float:
        return max(self.layer_thicknesses_mm)

    @property
    def maximum_layer_growth_ratio(self) -> float:
        if len(self.layer_thicknesses_mm) < 2:
            return 1.0
        return max(
            max(first, second) / min(first, second)
            for first, second in zip(
                self.layer_thicknesses_mm,
                self.layer_thicknesses_mm[1:],
            )
        )


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover
        raise RuntimeError("Gmsh is required for structured sweep") from error
    return gmsh


def _point3(value: Sequence[float], *, field_name: str) -> Point3D:
    try:
        raw = tuple(value)
    except TypeError as error:
        raise StructuredSweepMaterializationError(
            f"{field_name} must contain finite x,y,z"
        ) from error
    if len(raw) != 3:
        raise StructuredSweepMaterializationError(
            f"{field_name} must contain finite x,y,z"
        )
    output: list[float] = []
    for item in raw:
        if isinstance(item, bool):
            raise StructuredSweepMaterializationError(
                f"{field_name} must contain finite x,y,z"
            )
        try:
            number = float(item)
        except (TypeError, ValueError, OverflowError) as error:
            raise StructuredSweepMaterializationError(
                f"{field_name} must contain finite x,y,z"
            ) from error
        if not math.isfinite(number):
            raise StructuredSweepMaterializationError(
                f"{field_name} must contain finite x,y,z"
            )
        output.append(0.0 if number == 0.0 else number)
    return tuple(output)  # type: ignore[return-value]


def _rotation_matrix(
    placement: CanonicalRigidPlacement,
) -> tuple[Point3D, Point3D, Point3D]:
    rx, ry, rz = (math.radians(value) for value in placement.rotation_deg_xyz)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    x = ((1.0, 0.0, 0.0), (0.0, cx, -sx), (0.0, sx, cx))
    y = ((cy, 0.0, sy), (0.0, 1.0, 0.0), (-sy, 0.0, cy))
    z = ((cz, -sz, 0.0), (sz, cz, 0.0), (0.0, 0.0, 1.0))

    def product(left: Sequence[Sequence[float]], right: Sequence[Sequence[float]]):
        return tuple(
            tuple(
                math.fsum(left[row][inner] * right[inner][column] for inner in range(3))
                for column in range(3)
            )
            for row in range(3)
        )

    return product(z, product(y, x))  # type: ignore[return-value]


def _to_package(point: Point3D, placement: CanonicalRigidPlacement) -> Point3D:
    rotation = _rotation_matrix(placement)
    pivot = placement.pivot_xyz_mm
    relative = tuple(point[index] - pivot[index] for index in range(3))
    return tuple(
        placement.translation_xyz_mm[row]
        + pivot[row]
        + math.fsum(rotation[row][column] * relative[column] for column in range(3))
        for row in range(3)
    )  # type: ignore[return-value]


def _to_local(point: Point3D, placement: CanonicalRigidPlacement) -> Point3D:
    """Apply the exact inverse of :func:`_to_package`."""

    pivot = placement.pivot_xyz_mm
    translated = tuple(
        point[axis] - placement.translation_xyz_mm[axis] - pivot[axis]
        for axis in range(3)
    )
    rotation = _rotation_matrix(placement)
    return tuple(
        pivot[axis]
        + math.fsum(
            rotation[source_axis][axis] * translated[source_axis]
            for source_axis in range(3)
        )
        for axis in range(3)
    )  # type: ignore[return-value]


def _section_bounds(
    fragment: CanonicalGeometryFragment,
) -> tuple[
    tuple[float, float, float, float, float, float],
    tuple[float, float, float, float] | None,
]:
    root = fragment.root
    if type(root) is CanonicalBox:
        x0, y0, z0 = root.origin_xyz_mm
        sx, sy, sz = root.size_xyz_mm
        return (x0, x0 + sx, y0, y0 + sy, z0, z0 + sz), None
    if type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        x1 = x0 + root.outer_size_xy_mm[0]
        y1 = y0 + root.outer_size_xy_mm[1]
        ix0 = x0 + root.opening_offset_xy_mm[0]
        iy0 = y0 + root.opening_offset_xy_mm[1]
        return (
            x0,
            x1,
            y0,
            y1,
            z0,
            z0 + root.height_mm,
        ), (
            ix0,
            ix0 + root.opening_size_xy_mm[0],
            iy0,
            iy0 + root.opening_size_xy_mm[1],
        )
    root_name = type(root).__name__
    raise StructuredSweepMaterializationError(
        "structured_sweep requires all complete sections to be related by "
        "one bijective translation. Canonical Box and "
        "RectangularFrameExtrusion prove that map; "
        f"{root_name} does not provide that proof. No topology fallback was used"
    )


_IDENTITY_PLACEMENT = CanonicalRigidPlacement(
    (0.0, 0.0, 0.0),
    (0.0, 0.0, 0.0),
    (0.0, 0.0, 0.0),
)


def _sweep_axis_and_sign(
    direction: ComponentLocalDirection,
) -> tuple[int, bool]:
    return {
        ComponentLocalDirection.POSITIVE_X: (0, True),
        ComponentLocalDirection.NEGATIVE_X: (0, False),
        ComponentLocalDirection.POSITIVE_Y: (1, True),
        ComponentLocalDirection.NEGATIVE_Y: (1, False),
        ComponentLocalDirection.POSITIVE_Z: (2, True),
        ComponentLocalDirection.NEGATIVE_Z: (2, False),
    }[direction]


def _box_shell_side(axis: int, at_maximum: bool) -> str:
    if axis == 2:
        return "top" if at_maximum else "bottom"
    return f"{'xy'[axis]}_{'max' if at_maximum else 'min'}"


def _box_side_axis(side: str) -> tuple[int, bool]:
    canonical = {"bottom": "z_min", "top": "z_max"}.get(side, side)
    values = {
        "x_min": (0, False),
        "x_max": (0, True),
        "y_min": (1, False),
        "y_max": (1, True),
        "z_min": (2, False),
        "z_max": (2, True),
    }
    try:
        return values[canonical]
    except KeyError as error:
        raise StructuredSweepMaterializationError(
            f"structured sweep received unknown Box side {side!r}"
        ) from error


def _box_work_axes(sweep_axis: int) -> tuple[int, int, int]:
    """Return a right-handed original-to-working cyclic permutation."""

    return {
        0: (1, 2, 0),
        1: (2, 0, 1),
        2: (0, 1, 2),
    }[sweep_axis]


def _permute_point_to_work(
    point: Point3D,
    work_axes: tuple[int, int, int],
) -> Point3D:
    return tuple(point[axis] for axis in work_axes)  # type: ignore[return-value]


def _unpermute_point_from_work(
    point: Point3D,
    work_axes: tuple[int, int, int],
) -> Point3D:
    output = [0.0, 0.0, 0.0]
    for work_axis, original_axis in enumerate(work_axes):
        output[original_axis] = point[work_axis]
    return tuple(output)  # type: ignore[return-value]


def _box_side_to_work(
    side: str,
    work_axes: tuple[int, int, int],
) -> str:
    original_axis, at_maximum = _box_side_axis(side)
    return _box_shell_side(work_axes.index(original_axis), at_maximum)


def _box_side_from_work(
    side: str,
    work_axes: tuple[int, int, int],
) -> str:
    work_axis, at_maximum = _box_side_axis(side)
    return _box_shell_side(work_axes[work_axis], at_maximum)


def _lateral_side_specifications(
    fragment: CanonicalGeometryFragment,
) -> Mapping[str, tuple[int, float, int, float, float]]:
    """Return ``side -> (normal axis/value, tangent axis/range)``."""

    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, _z0, _z1 = bounds
    values: dict[str, tuple[int, float, int, float, float]] = {
        ("x_min" if opening is None else "outer_x_min"): (0, x0, 1, y0, y1),
        ("x_max" if opening is None else "outer_x_max"): (0, x1, 1, y0, y1),
        ("y_min" if opening is None else "outer_y_min"): (1, y0, 0, x0, x1),
        ("y_max" if opening is None else "outer_y_max"): (1, y1, 0, x0, x1),
    }
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        values.update(
            {
                "inner_x_min": (0, ix0, 1, iy0, iy1),
                "inner_x_max": (0, ix1, 1, iy0, iy1),
                "inner_y_min": (1, iy0, 0, ix0, ix1),
                "inner_y_max": (1, iy1, 0, ix0, ix1),
            }
        )
    return MappingProxyType(values)


def _clustered_values(
    values: Sequence[float],
    *,
    tolerance: float,
) -> tuple[float, ...]:
    groups: list[list[float]] = []
    for value in sorted(values):
        if not groups or value - groups[-1][-1] > tolerance:
            groups.append([value])
        else:
            groups[-1].append(value)
    return tuple(math.fsum(group) / len(group) for group in groups)


def _nearest_level_index(
    value: float,
    levels: Sequence[float],
    *,
    tolerance: float,
) -> int:
    distances = tuple(abs(value - level) for level in levels)
    index = min(range(len(levels)), key=distances.__getitem__)
    if distances[index] > tolerance:
        raise StructuredSweepMaterializationError(
            "lateral locked trace does not use one common axial level set"
        )
    return index


def _prove_lateral_sweep_trace(
    fragment: CanonicalGeometryFragment,
    coordinates: Mapping[int, Point3D],
    facets_by_side: Mapping[str, Sequence[Sequence[int]]],
) -> _LateralSweepTrace | None:
    """Prove every lateral lock is a complete section chain extrusion.

    This is deliberately stricter than merely checking that QUAD4 vertices
    lie on an analytic wall.  Each side must be the Cartesian product of one
    complete source-section boundary chain and the same global axial levels;
    otherwise a Gmsh extrusion cannot reproduce the supplied facets exactly.
    """

    specifications = _lateral_side_specifications(fragment)
    lateral = {
        side: tuple(tuple(facet) for facet in facets)
        for side, facets in facets_by_side.items()
        if side not in {"bottom", "top"} and facets
    }
    if not lateral:
        return None
    unknown = set(lateral).difference(specifications)
    if unknown:
        raise StructuredSweepMaterializationError(
            "structured sweep received unknown lateral geometric side(s): "
            + ", ".join(sorted(unknown))
        )
    bounds, _opening = _section_bounds(fragment)
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    z0, z1 = bounds[4], bounds[5]
    common_levels: tuple[float, ...] | None = None
    output_segments: dict[str, tuple[tuple[float, float], ...]] = {}
    for side in sorted(lateral):
        facets = lateral[side]
        normal_axis, normal_value, tangent_axis, tangent_min, tangent_max = (
            specifications[side]
        )
        if any(len(facet) != 4 for facet in facets):
            triangle_count = sum(len(facet) == 3 for facet in facets)
            quad_count = sum(len(facet) == 4 for facet in facets)
            referenced = {
                node
                for facet in facets
                for node in facet
                if node in coordinates
            }
            axial_values = tuple(
                coordinates[node][2] for node in referenced
            )
            axial_range = (
                "unknown"
                if not axial_values
                else f"[{min(axial_values):.12g}, {max(axial_values):.12g}] mm"
            )
            raise StructuredSweepMaterializationError(
                "structured sweep cannot reproduce a TRI3 lateral lock: native "
                "TRI-to-WEDGE/QUAD-to-HEX extrusion creates QUAD4 lateral "
                f"faces; side={side!r}, TRI3={triangle_count}, "
                f"QUAD4={quad_count}, locked_axial_range={axial_range}, "
                f"required_complete_range=[{z0:.12g}, {z1:.12g}] mm"
            )
        if any(
            len(set(facet)) != 4 or any(node not in coordinates for node in facet)
            for facet in facets
        ):
            raise StructuredSweepMaterializationError(
                "lateral structured-sweep lock contains an invalid QUAD4"
            )
        side_nodes = {node for facet in facets for node in facet}
        if any(
            abs(coordinates[node][normal_axis] - normal_value) > tolerance
            or not tangent_min - tolerance
            <= coordinates[node][tangent_axis]
            <= tangent_max + tolerance
            or not z0 - tolerance <= coordinates[node][2] <= z1 + tolerance
            for node in side_nodes
        ):
            raise StructuredSweepMaterializationError(
                f"lateral locked trace {side!r} is not on its canonical side"
            )
        levels = _clustered_values(
            tuple(coordinates[node][2] for node in side_nodes),
            tolerance=tolerance,
        )
        if (
            len(levels) < 2
            or abs(levels[0] - z0) > tolerance
            or abs(levels[-1] - z1) > tolerance
            or any(second - first <= tolerance for first, second in zip(levels, levels[1:]))
        ):
            raise StructuredSweepMaterializationError(
                "lateral locked trace must span the complete sweep path"
            )
        levels = (z0, *levels[1:-1], z1)
        if common_levels is None:
            common_levels = levels
        elif len(levels) != len(common_levels) or any(
            abs(first - second) > tolerance
            for first, second in zip(levels, common_levels)
        ):
            raise StructuredSweepMaterializationError(
                "all lateral locked traces must use the same global axial levels"
            )

        segments_by_interval: dict[int, list[tuple[float, float]]] = defaultdict(list)
        seen_facets: set[tuple[int, ...]] = set()
        for facet in facets:
            key = _face_key(facet)
            if key in seen_facets:
                raise StructuredSweepMaterializationError(
                    "lateral locked trace repeats a facet"
                )
            seen_facets.add(key)
            node_indices = {
                node: _nearest_level_index(
                    coordinates[node][2], levels, tolerance=tolerance
                )
                for node in facet
            }
            occupied = sorted(set(node_indices.values()))
            if (
                len(occupied) != 2
                or occupied[1] != occupied[0] + 1
                or Counter(node_indices.values()) != Counter(
                    {occupied[0]: 2, occupied[1]: 2}
                )
            ):
                raise StructuredSweepMaterializationError(
                    "lateral QUAD4 must span exactly one adjacent axial interval"
                )
            lower_tangent = sorted(
                coordinates[node][tangent_axis]
                for node, index in node_indices.items()
                if index == occupied[0]
            )
            upper_tangent = sorted(
                coordinates[node][tangent_axis]
                for node, index in node_indices.items()
                if index == occupied[1]
            )
            if (
                lower_tangent[1] - lower_tangent[0] <= tolerance
                or any(
                    abs(first - second) > tolerance
                    for first, second in zip(lower_tangent, upper_tangent)
                )
            ):
                raise StructuredSweepMaterializationError(
                    "lateral QUAD4 is not one source edge translated along the sweep"
                )
            segments_by_interval[occupied[0]].append(
                (lower_tangent[0], lower_tangent[1])
            )
        if set(segments_by_interval) != set(range(len(levels) - 1)):
            raise StructuredSweepMaterializationError(
                "lateral locked trace omits an axial interval"
            )

        canonical_segments: tuple[tuple[float, float], ...] | None = None
        for interval in range(len(levels) - 1):
            raw_segments = sorted(segments_by_interval[interval])
            if len(
                {
                    (
                        round(first / tolerance),
                        round(second / tolerance),
                    )
                    for first, second in raw_segments
                }
            ) != len(raw_segments):
                raise StructuredSweepMaterializationError(
                    "lateral locked trace duplicates one swept source edge"
                )
            if (
                abs(raw_segments[0][0] - tangent_min) > tolerance
                or abs(raw_segments[-1][1] - tangent_max) > tolerance
                or any(
                    abs(first[1] - second[0]) > tolerance
                    for first, second in zip(raw_segments, raw_segments[1:])
                )
            ):
                raise StructuredSweepMaterializationError(
                    "lateral locked trace is not one complete source boundary chain"
                )
            normalized = (
                (tangent_min, raw_segments[0][1]),
                *raw_segments[1:-1],
                (raw_segments[-1][0], tangent_max),
            ) if len(raw_segments) > 1 else ((tangent_min, tangent_max),)
            if canonical_segments is None:
                canonical_segments = tuple(normalized)
            elif len(normalized) != len(canonical_segments) or any(
                abs(a - c) > tolerance or abs(b - d) > tolerance
                for (a, b), (c, d) in zip(normalized, canonical_segments)
            ):
                raise StructuredSweepMaterializationError(
                    "lateral locked trace changes its section chain between levels"
                )
        assert canonical_segments is not None
        output_segments[side] = canonical_segments
    assert common_levels is not None
    return _LateralSweepTrace(
        common_levels,
        MappingProxyType(output_segments),
    )


def _prove_partial_lateral_sweep_trace(
    fragment: CanonicalGeometryFragment,
    coordinates: Mapping[int, Point3D],
    facets_by_side: Mapping[str, Sequence[Sequence[int]]],
    *,
    source_side: str,
    tolerance: float,
    target_edge_mm: float,
    sizing: MeshSeedPolicy = MeshSeedPolicy(),
    seed_origin: float | None = None,
) -> _LateralSweepTrace:
    """Prove locked wall QUADs are a subset of one translational extrusion.

    This only plans layers and verifies existing facets. Gmsh still generates
    every volume cell. A new layer may never split a protected wall QUAD. When
    no end is inherited, projected wall edges constrain the generated section.
    """
    seed = tuple(facets_by_side.get(source_side, ()))
    seed_nodes = {node for facet in seed for node in facet}
    seed_coordinates = {node: coordinates[node] for node in seed_nodes}
    if seed:
        oriented_seed = _consistently_oriented_planar_facets(seed_coordinates, seed)
        _validate_complete_section(fragment, seed_coordinates, oriented_seed)
    edge_counts = Counter(
        tuple(sorted((first, second)))
        for facet in seed
        for first, second in zip(facet, (*facet[1:], facet[0]))
    )
    specifications = _lateral_side_specifications(fragment)
    edges_by_side: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for (first, second), count in edge_counts.items():
        if count != 1:
            continue
        p, q = coordinates[first], coordinates[second]
        for side, (axis, value, tangent, _lo, _hi) in specifications.items():
            if abs(p[axis] - value) <= tolerance and abs(q[axis] - value) <= tolerance:
                edges_by_side[side].append(tuple(sorted((p[tangent], q[tangent]))))

    bounds, _opening = _section_bounds(fragment)
    z0, z1 = bounds[4:6]
    protected: list[tuple[str, float, float]] = []
    for side, facets in facets_by_side.items():
        if side in {"bottom", "top"} or not facets:
            continue
        if side not in specifications:
            raise StructuredSweepMaterializationError(
                f"partial lateral sweep received unknown side {side!r}"
            )
        axis, value, tangent, tangent_min, tangent_max = specifications[side]
        seen: set[tuple[int, ...]] = set()
        for facet in facets:
            if len(facet) != 4 or len(set(facet)) != 4:
                raise StructuredSweepMaterializationError(
                    "partial lateral sweep requires rectangular QUAD4 locks"
                )
            key = _face_key(facet)
            if key in seen:
                raise StructuredSweepMaterializationError(
                    "partial lateral sweep repeats a locked QUAD"
                )
            seen.add(key)
            points = tuple(coordinates[node] for node in facet)
            if any(abs(p[axis] - value) > tolerance for p in points):
                raise StructuredSweepMaterializationError(
                    f"partial lateral lock is not on canonical side {side!r}"
                )
            heights = _clustered_values(tuple(p[2] for p in points), tolerance=tolerance)
            if len(heights) != 2 or heights[0] < z0 - tolerance or heights[1] > z1 + tolerance:
                raise StructuredSweepMaterializationError(
                    "partial lateral QUAD must span two in-bounds axial levels"
                )
            low = sorted(p[tangent] for p in points if abs(p[2] - heights[0]) <= tolerance)
            high = sorted(p[tangent] for p in points if abs(p[2] - heights[1]) <= tolerance)
            if (
                len(low) != 2
                or len(high) != 2
                or low[1] - low[0] <= tolerance
                or low[0] < tangent_min - tolerance
                or low[1] > tangent_max + tolerance
                or any(abs(a - b) > tolerance for a, b in zip(low, high))
            ):
                raise StructuredSweepMaterializationError(
                    "partial lateral QUAD is not a translated source edge"
                )
            if seed:
                matches = [
                    edge for edge in edges_by_side[side]
                    if all(abs(a - b) <= tolerance for a, b in zip(edge, low))
                ]
                if len(matches) != 1:
                    raise StructuredSweepMaterializationError(
                        f"partial lateral lock {side!r} does not match one inherited perimeter edge"
                    )
            else:
                # A generated section can inherit these projected edges even
                # when no wall reaches either sweep endpoint. Distinct traces
                # must not overlap: that would require splitting a locked edge.
                for edge in edges_by_side[side]:
                    if all(abs(a-b) <= tolerance for a, b in zip(edge, low)):
                        break
                    if min(edge[1], low[1]) - max(edge[0], low[0]) > tolerance:
                        raise StructuredSweepMaterializationError(
                            f"partial lateral traces on {side!r} would split a locked source edge"
                        )
                else:
                    edges_by_side[side].append(tuple(low))
            # Require a perimeter cycle, not a crossed quad with the same vertices.
            if any(
                (abs(p[tangent] - q[tangent]) > tolerance)
                and (abs(p[2] - q[2]) > tolerance)
                for p, q in zip(points, (*points[1:], points[0]))
            ):
                raise StructuredSweepMaterializationError(
                    "partial lateral QUAD has a crossed perimeter cycle"
                )
            protected.append((side, *heights))

    levels = list(_clustered_values(
        (z0, z1, *(z for _side, lo, hi in protected for z in (lo, hi))),
        tolerance=tolerance,
    ))
    levels[0], levels[-1] = z0, z1
    for side, lo, hi in protected:
        if any(lo + tolerance < z < hi - tolerance for z in levels):
            raise StructuredSweepMaterializationError(
                f"partial lateral sweep axial partition would split a locked QUAD on {side!r}"
            )
    refined = [levels[0]]
    for lo, hi in zip(levels, levels[1:]):
        locked_interval = any(
            a < hi - tolerance and b > lo + tolerance for _side, a, b in protected
        )
        if locked_interval:
            refined.append(hi)
        else:
            anchor = (z1 if source_side == "top" else z0) if seed_origin is None else seed_origin
            refined.extend(interval_levels(lo, hi, target_edge_mm, target_edge_mm, anchor, sizing)[1:])
    return _LateralSweepTrace(
        tuple(refined),
        MappingProxyType({side: tuple(sorted(edges)) for side, edges in edges_by_side.items()}),
    )


def _generated_section_from_lateral_trace(
    fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
    coordinates: Mapping[int, Point3D],
    facets_by_side: Mapping[str, Sequence[Sequence[int]]],
    *,
    source_side_name: str,
    projected_trace: _LateralSweepTrace | None = None,
    contact_partition_loops=(),
    minimum_quality: float,
    verbose: bool,
    boundary_size_policy: BoundarySizePolicy | None = None,
) -> tuple[Mapping[int, Point3D], tuple[tuple[int, ...], ...]]:
    """Generate one end section directly from proven lateral endpoint chains."""

    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    z = z1 if source_side_name == "top" else z0
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    endpoint_nodes = {
        node
        for side, facets in facets_by_side.items()
        if side not in {"bottom", "top"}
        for facet in facets
        for node in facet
        if abs(coordinates[node][2] - z) <= tolerance
    }
    source_coordinates: dict[int, Point3D] = {}
    node_by_coordinate: dict[tuple[int, int, int], int] = {}
    for node in sorted(endpoint_nodes):
        point = coordinates[node]
        key = tuple(round(value / tolerance) for value in point)
        if key in node_by_coordinate:
            raise StructuredSweepMaterializationError(
                "lateral endpoint chains contain coincident nodes with different IDs"
            )
        source_coordinates[node] = point
        node_by_coordinate[key] = node
    next_node = max(source_coordinates, default=0) + 1

    def boundary_node(x_value: float, y_value: float) -> int:
        nonlocal next_node
        point = (x_value, y_value, z)
        key = tuple(round(value / tolerance) for value in point)
        existing = node_by_coordinate.get(key)
        if existing is not None:
            return existing
        node = next_node
        next_node += 1
        source_coordinates[node] = point
        node_by_coordinate[key] = node
        return node

    specifications = _lateral_side_specifications(fragment)
    locked_chains: list[LockedBoundaryChain] = []

    def side_chain(
        side: str,
        start_xy: tuple[float, float],
        end_xy: tuple[float, float],
    ) -> tuple[int, ...]:
        if projected_trace is not None and side in projected_trace.segments_by_side:
            normal_axis, normal_value, tangent_axis, lower, upper = specifications[side]
            values = _partition_orthogonal_axis(
                (lower, upper), projected_trace.segments_by_side[side],
                requirement.target_edge_mm, tolerance=tolerance, allow_oversize_protected=True,
            )
            if end_xy[tangent_axis] < start_xy[tangent_axis]:
                values = tuple(reversed(values))
            nodes = tuple(boundary_node(
                normal_value if normal_axis == 0 else v,
                v if normal_axis == 0 else normal_value,
            ) for v in values)
            locked_chains.append(LockedBoundaryChain(nodes))
            return nodes
        if facets_by_side.get(side):
            _normal_axis, _normal_value, tangent_axis, _lower, _upper = (
                specifications[side]
            )
            nodes = tuple(
                sorted(
                    {
                        node
                        for facet in facets_by_side[side]
                        for node in facet
                        if abs(coordinates[node][2] - z) <= tolerance
                    },
                    key=lambda node: coordinates[node][tangent_axis],
                )
            )
            start_tangent = start_xy[tangent_axis]
            end_tangent = end_xy[tangent_axis]
            if end_tangent < start_tangent:
                nodes = tuple(reversed(nodes))
            if (
                not nodes
                or math.dist(coordinates[nodes[0]], (*start_xy, z)) > tolerance
                or math.dist(coordinates[nodes[-1]], (*end_xy, z)) > tolerance
            ):
                raise StructuredSweepMaterializationError(
                    "lateral trace endpoint chain does not meet canonical corners"
                )
            locked_chains.append(LockedBoundaryChain(nodes))
            return nodes
        return (
            boundary_node(*start_xy),
            boundary_node(*end_xy),
        )

    def rectangular_loop(
        xmin: float,
        xmax: float,
        ymin: float,
        ymax: float,
        *,
        prefix: str,
    ) -> tuple[int, ...]:
        sides = (
            (f"{prefix}y_min", (xmin, ymin), (xmax, ymin)),
            (f"{prefix}x_max", (xmax, ymin), (xmax, ymax)),
            (f"{prefix}y_max", (xmax, ymax), (xmin, ymax)),
            (f"{prefix}x_min", (xmin, ymax), (xmin, ymin)),
        )
        loop: list[int] = []
        for side, start, end in sides:
            chain = side_chain(side, start, end)
            if not loop:
                loop.extend(chain)
            elif loop[-1] == chain[0]:
                loop.extend(chain[1:])
            else:
                raise StructuredSweepMaterializationError(
                    "lateral endpoint chains do not form one conformal section loop"
                )
        if loop[-1] != loop[0]:
            raise StructuredSweepMaterializationError(
                "lateral endpoint chains do not close the section loop"
            )
        return tuple(loop[:-1])

    outer_prefix = "" if opening is None else "outer_"
    outer_loop = rectangular_loop(x0, x1, y0, y1, prefix=outer_prefix)
    holes: tuple[tuple[int, ...], ...] = ()
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        holes = (
            rectangular_loop(ix0, ix1, iy0, iy1, prefix="inner_"),
        )
    surface = generate_gmsh_shared_surface(
        source_coordinates,
        (PlanarRegion("section", outer_loop, holes),),
        locked_boundary_chains=tuple(locked_chains),
        contact_partition_loops=contact_partition_loops,
        target_edge_mm=requirement.target_edge_mm,
        transition_distance_mm=requirement.transition_distance_mm,
        boundary_size_policy=boundary_size_policy,
        minimum_quality=minimum_quality,
        verbose=verbose,
    )
    return (
        surface.node_coordinates,
        tuple(facet.node_ids for facet in surface.facets),
    )


def _partition_orthogonal_axis(
    feature_values: Sequence[float],
    protected_segments: Sequence[tuple[float, float]],
    target_edge_mm: float,
    *,
    tolerance: float,
    allow_oversize_protected: bool = False,
) -> tuple[float, ...]:
    locked_values = tuple(
        value for segment in protected_segments for value in segment
    )
    base = _clustered_values(
        (*tuple(feature_values), *locked_values),
        tolerance=tolerance,
    )
    protected_indices: set[tuple[int, int]] = set()
    for raw_lower, raw_upper in protected_segments:
        lower, upper = sorted((raw_lower, raw_upper))
        indices = tuple(
            index
            for index, value in enumerate(base)
            if lower - tolerance <= value <= upper + tolerance
        )
        if (
            len(indices) != 2
            or indices[1] != indices[0] + 1
            or abs(base[indices[0]] - lower) > tolerance
            or abs(base[indices[1]] - upper) > tolerance
        ):
            raise StructuredSweepMaterializationError(
                "locked sweep grid edges are incompatible with one "
                "orthogonal end-section tensor partition"
            )
        if (
            not allow_oversize_protected
            and upper - lower > target_edge_mm * (1.0 + 1.0e-12)
        ):
            raise StructuredSweepMaterializationError(
                "a locked lateral boundary edge exceeds target_edge_mm and "
                "cannot be split while producing an orthogonal sweep end"
            )
        protected_indices.add((indices[0], indices[1]))

    output: list[float] = [base[0]]
    for index, (lower, upper) in enumerate(zip(base, base[1:])):
        length = upper - lower
        if length <= tolerance:
            raise StructuredSweepMaterializationError(
                "orthogonal sweep end contains a non-positive tensor interval"
            )
        divisions = (
            1
            if (index, index + 1) in protected_indices
            else max(1, int(math.ceil(length / target_edge_mm)))
        )
        output.extend(
            lower + length * step / divisions
            for step in range(1, divisions + 1)
        )
    return tuple(output)


def _orthogonal_section_axes(
    fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
    lateral_trace: _LateralSweepTrace | None,
    locked_end_coordinates: Mapping[int, Point3D] | None = None,
    locked_end_facets: Sequence[Sequence[int]] = (),
) -> tuple[tuple[float, ...], tuple[float, ...]]:
    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, _z0, _z1 = bounds
    feature_values: dict[int, list[float]] = {0: [x0, x1], 1: [y0, y1]}
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        feature_values[0].extend((ix0, ix1))
        feature_values[1].extend((iy0, iy1))
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    lateral_protected: dict[int, list[tuple[float, float]]] = {
        0: [],
        1: [],
    }
    if lateral_trace is not None:
        specifications = _lateral_side_specifications(fragment)
        for side, segments in lateral_trace.segments_by_side.items():
            tangent_axis = specifications[side][2]
            lateral_protected[tangent_axis].extend(segments)
    end_protected: dict[int, list[tuple[float, float]]] = {0: [], 1: []}
    if locked_end_facets:
        if locked_end_coordinates is None:
            raise StructuredSweepMaterializationError(
                "locked end facets require their immutable coordinates"
            )
        for facet in locked_end_facets:
            points = tuple(locked_end_coordinates[node] for node in facet)
            x_values = _clustered_values(
                tuple(point[0] for point in points),
                tolerance=tolerance,
            )
            y_values = _clustered_values(
                tuple(point[1] for point in points),
                tolerance=tolerance,
            )
            if len(x_values) != 2 or len(y_values) != 2:
                raise StructuredSweepMaterializationError(
                    "locked end patch is not an orthogonal QUAD partition"
                )
            end_protected[0].append((x_values[0], x_values[1]))
            end_protected[1].append((y_values[0], y_values[1]))
    return (
        _partition_orthogonal_axis(
            feature_values[0],
            (*lateral_protected[0], *end_protected[0]),
            requirement.target_edge_mm,
            tolerance=tolerance,
            # Every protected segment is immutable authority.  target_edge is
            # a ceiling for newly generated intervals, not permission to split
            # a Frozen or higher-priority edge.
            allow_oversize_protected=bool(
                lateral_protected[0] or end_protected[0]
            ),
        ),
        _partition_orthogonal_axis(
            feature_values[1],
            (*lateral_protected[1], *end_protected[1]),
            requirement.target_edge_mm,
            tolerance=tolerance,
            allow_oversize_protected=bool(
                lateral_protected[1] or end_protected[1]
            ),
        ),
    )


def _preserve_locked_end_patch(
    generated_coordinates: Mapping[int, Point3D],
    generated_facets: Sequence[Sequence[int]],
    locked_coordinates: Mapping[int, Point3D],
    locked_facets: Sequence[Sequence[int]],
    *,
    tolerance: float,
) -> tuple[Mapping[int, Point3D], tuple[tuple[int, ...], ...]]:
    """Replace matching Gmsh tensor cells with immutable caller identities.

    Gmsh still creates every cell of the complete 2-D tensor partition.  This
    adapter only binds nodes/cycles of cells already owned by the incoming
    patch back to their immutable IDs; it never creates a surface cell or any
    volume connectivity.
    """

    if not locked_facets:
        return MappingProxyType(dict(generated_coordinates)), tuple(
            tuple(facet) for facet in generated_facets
        )
    generated_node_by_locked: dict[int, int] = {}
    for node, point in locked_coordinates.items():
        candidates = tuple(
            generated
            for generated, generated_point in generated_coordinates.items()
            if math.dist(generated_point, point) <= tolerance
        )
        if not candidates:
            raise StructuredSweepMaterializationError(
                "Gmsh end-section completion did not retain a locked patch node"
            )
        if len(candidates) != 1:
            raise StructuredSweepMaterializationError(
                "Gmsh completed end section repeats a locked geometric node"
            )
        generated_node_by_locked[node] = candidates[0]
    if len(set(generated_node_by_locked.values())) != len(
        generated_node_by_locked
    ):
        raise StructuredSweepMaterializationError(
            "Gmsh end-section completion merged distinct locked patch nodes"
        )

    final_by_generated = {
        generated: locked
        for locked, generated in generated_node_by_locked.items()
    }
    used_final = set(locked_coordinates)
    next_node = 1
    for generated in sorted(
        generated_coordinates,
        key=lambda node: (*generated_coordinates[node], node),
    ):
        if generated in final_by_generated:
            continue
        while next_node in used_final:
            next_node += 1
        final_by_generated[generated] = next_node
        used_final.add(next_node)
        next_node += 1
    final_coordinates = MappingProxyType(
        {
            final_by_generated[node]: point
            for node, point in generated_coordinates.items()
        }
    )

    locked_by_cell: dict[frozenset[int], tuple[int, ...]] = {}
    locked_orientation: float | None = None
    for facet in locked_facets:
        normalized = tuple(facet)
        key = frozenset(
            generated_node_by_locked[node] for node in normalized
        )
        if key in locked_by_cell:
            raise StructuredSweepMaterializationError(
                "locked end patch repeats one orthogonal cell"
            )
        orientation = _signed_area_xy(
            _facet_polygon_xy(normalized, locked_coordinates)
        )
        if locked_orientation is None:
            locked_orientation = orientation
        elif orientation * locked_orientation <= 0.0:
            raise StructuredSweepMaterializationError(
                "locked end patch facet cycles are not consistently oriented"
            )
        locked_by_cell[key] = normalized

    completed: list[tuple[int, ...]] = []
    matched_locked: set[frozenset[int]] = set()
    for raw_facet in generated_facets:
        raw = tuple(raw_facet)
        key = frozenset(raw)
        locked = locked_by_cell.get(key)
        if locked is not None:
            mapped_nodes = {
                final_by_generated[node] for node in raw
            }
            if mapped_nodes != set(locked):
                raise StructuredSweepMaterializationError(
                    "Gmsh completed cell changed locked patch corner identity"
                )
            completed.append(locked)
            matched_locked.add(key)
            continue
        mapped = tuple(final_by_generated[node] for node in raw)
        if locked_orientation is not None and _signed_area_xy(
            _facet_polygon_xy(mapped, final_coordinates)
        ) * locked_orientation <= 0.0:
            mapped = tuple(reversed(mapped))
        completed.append(mapped)
    if matched_locked != set(locked_by_cell):
        raise StructuredSweepMaterializationError(
            "locked end patch is incompatible with the completed tensor cells"
        )
    return final_coordinates, tuple(completed)


def _generated_orthogonal_section(
    fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
    lateral_trace: _LateralSweepTrace | None,
    *,
    at_top: bool,
    minimum_quality: float,
    verbose: bool,
    locked_end_coordinates: Mapping[int, Point3D] | None = None,
    locked_end_facets: Sequence[Sequence[int]] = (),
    contact_partition_loops=(),
) -> tuple[Mapping[int, Point3D], tuple[tuple[int, ...], ...]]:
    """Ask Gmsh to mesh a tensor CAD partition as immutable QUAD4 cells."""

    bounds, opening = _section_bounds(fragment)
    _x0, _x1, _y0, _y1, z0, z1 = bounds
    z_value = z1 if at_top else z0
    x_values, y_values = _orthogonal_section_axes(
        fragment,
        requirement,
        lateral_trace,
        locked_end_coordinates,
        locked_end_facets,
    )
    x_values = tuple(sorted(set(x_values) | {p[0] for loop in contact_partition_loops for p in loop if bounds[0] < p[0] < bounds[1]}))
    y_values = tuple(sorted(set(y_values) | {p[1] for loop in contact_partition_loops for p in loop if bounds[2] < p[1] < bounds[3]}))
    retained_cells = tuple(
        (x_index, y_index)
        for x_index in range(len(x_values) - 1)
        for y_index in range(len(y_values) - 1)
        if opening is None
        or not (
            opening[0]
            < 0.5 * (x_values[x_index] + x_values[x_index + 1])
            < opening[1]
            and opening[2]
            < 0.5 * (y_values[y_index] + y_values[y_index + 1])
            < opening[3]
        )
    )
    if not retained_cells:
        raise StructuredSweepMaterializationError(
            "orthogonal sweep end-section partition contains no cells"
        )

    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_structured_sweep_quad_section",
        number_options={
            "General.Terminal": 1.0 if verbose else 0.0,
            "Mesh.ElementOrder": 1.0,
            "Mesh.Optimize": 0.0,
            "Mesh.RecombineAll": 0.0,
        },
    ):
        used_indices = {
            value
            for x_index, y_index in retained_cells
            for value in (
                (x_index, y_index),
                (x_index + 1, y_index),
                (x_index + 1, y_index + 1),
                (x_index, y_index + 1),
            )
        }
        point_by_index = {
            key: int(
                gmsh.model.geo.addPoint(
                    x_values[key[0]],
                    y_values[key[1]],
                    z_value,
                )
            )
            for key in sorted(used_indices)
        }
        curve_data: dict[
            tuple[tuple[int, int], tuple[int, int]],
            tuple[int, tuple[int, int], tuple[int, int]],
        ] = {}

        def signed_curve(
            first: tuple[int, int], second: tuple[int, int]
        ) -> int:
            key = tuple(sorted((first, second)))
            existing = curve_data.get(key)  # type: ignore[arg-type]
            if existing is None:
                tag = int(
                    gmsh.model.geo.addLine(
                        point_by_index[first], point_by_index[second]
                    )
                )
                curve_data[key] = (tag, first, second)  # type: ignore[index]
                return tag
            tag, start, end = existing
            return tag if (first, second) == (start, end) else -tag

        surfaces: list[int] = []
        for x_index, y_index in retained_cells:
            corners = (
                (x_index, y_index),
                (x_index + 1, y_index),
                (x_index + 1, y_index + 1),
                (x_index, y_index + 1),
            )
            curves = tuple(
                signed_curve(first, second)
                for first, second in zip(
                    corners,
                    (*corners[1:], corners[0]),
                )
            )
            loop = int(gmsh.model.geo.addCurveLoop(curves))
            surfaces.append(int(gmsh.model.geo.addPlaneSurface([loop])))
        gmsh.model.geo.synchronize()
        for curve_tag, _start, _end in curve_data.values():
            gmsh.model.mesh.setTransfiniteCurve(curve_tag, 2)
        for surface in surfaces:
            gmsh.model.mesh.setTransfiniteSurface(surface)
            gmsh.model.mesh.setRecombine(2, surface)
        gmsh.model.mesh.generate(2)

        raw_coordinates: dict[int, Point3D] = {}
        raw_facets: list[tuple[int, ...]] = []
        element_tags: list[int] = []
        for surface in surfaces:
            types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
                2, surface
            )
            for raw_type, tags, connectivity in zip(
                types, tag_blocks, connectivity_blocks
            ):
                if int(raw_type) != 3:
                    raise StructuredSweepMaterializationError(
                        "Gmsh cannot guarantee an all-QUAD orthogonal sweep "
                        "end section for this tensor partition"
                    )
                values = tuple(int(node) for node in connectivity)
                raw_facets.extend(
                    values[index : index + 4]
                    for index in range(0, len(values), 4)
                )
                element_tags.extend(int(tag) for tag in tags)
        if len(raw_facets) != len(retained_cells):
            raise StructuredSweepMaterializationError(
                "Gmsh changed the one-QUAD-per-tensor-cell end partition"
            )
        used_tags = {node for facet in raw_facets for node in facet}
        for node in used_tags:
            values, _parametric, _dimension, _entity = gmsh.model.mesh.getNode(node)
            raw_coordinates[node] = tuple(float(value) for value in values)  # type: ignore[assignment]
        qualities = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(
                element_tags, "minSICN"
            )
        )
        if (
            len(qualities) != len(raw_facets)
            or min(qualities, default=0.0) < minimum_quality
        ):
            raise StructuredSweepMaterializationError(
                "Gmsh orthogonal sweep end-section quality is below 0.03"
            )
        if tuple(gmsh.model.mesh.getDuplicateNodes()):
            raise StructuredSweepMaterializationError(
                "Gmsh orthogonal sweep end section contains duplicate nodes"
            )

    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    snapped: dict[int, Point3D] = {}
    for node, point in raw_coordinates.items():
        x_value = min(x_values, key=lambda value: abs(point[0] - value))
        y_value = min(y_values, key=lambda value: abs(point[1] - value))
        expected = (x_value, y_value, z_value)
        if math.dist(point, expected) > tolerance:
            raise StructuredSweepMaterializationError(
                "Gmsh orthogonal sweep end node escaped its tensor grid"
            )
        snapped[node] = expected
    ordered = tuple(
        sorted(snapped, key=lambda node: (*snapped[node], node))
    )
    local_by_gmsh = {
        node: local for local, node in enumerate(ordered, start=1)
    }
    coordinates: Mapping[int, Point3D] = MappingProxyType(
        {local_by_gmsh[node]: snapped[node] for node in ordered}
    )
    facets: tuple[tuple[int, ...], ...] = tuple(
        tuple(local_by_gmsh[node] for node in facet) for facet in raw_facets
    )
    if locked_end_facets:
        if locked_end_coordinates is None:  # pragma: no cover - signature guard
            raise StructuredSweepMaterializationError(
                "locked end facets require their immutable coordinates"
            )
        coordinates, facets = _preserve_locked_end_patch(
            coordinates,
            facets,
            locked_end_coordinates,
            locked_end_facets,
            tolerance=tolerance,
        )
    _validate_inherited_orthogonal_quad_partition(
        fragment,
        coordinates,
        facets,
    )
    _validate_complete_section(fragment, coordinates, facets)
    return coordinates, facets


def _generated_section(
    fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
    *,
    at_top: bool,
    contact_partition_loops=(),
    verbose: bool,
    boundary_size_policy: BoundarySizePolicy | None = None,
) -> tuple[
    Mapping[int, Point3D],
    tuple[tuple[int, ...], ...],
]:
    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    z = z1 if at_top else z0
    coordinates: dict[int, Point3D] = {
        1: (x0, y0, z),
        2: (x1, y0, z),
        3: (x1, y1, z),
        4: (x0, y1, z),
    }
    holes: tuple[tuple[int, ...], ...] = ()
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        coordinates.update(
            {
                5: (ix0, iy0, z),
                6: (ix1, iy0, z),
                7: (ix1, iy1, z),
                8: (ix0, iy1, z),
            }
        )
        holes = ((5, 6, 7, 8),)
    surface = generate_gmsh_shared_surface(
        coordinates,
        (PlanarRegion("section", (1, 2, 3, 4), holes),),
        contact_partition_loops=contact_partition_loops,
        target_edge_mm=requirement.target_edge_mm,
        transition_distance_mm=requirement.transition_distance_mm,
        boundary_size_policy=boundary_size_policy,
        minimum_quality=0.03,
        verbose=verbose,
    )
    return (
        surface.node_coordinates,
        tuple(facet.node_ids for facet in surface.facets),
    )


def _face_key(nodes: Sequence[int]) -> tuple[int, ...]:
    return tuple(sorted(nodes))


def _signed_area_xy(points: Sequence[tuple[float, float]]) -> float:
    return 0.5 * math.fsum(
        first[0] * second[1] - second[0] * first[1]
        for first, second in zip(points, (*points[1:], points[0]))
    )


def _facet_polygon_xy(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[float, float], ...]:
    return tuple((coordinates[node][0], coordinates[node][1]) for node in facet)


def _cross2(
    first: tuple[float, float],
    second: tuple[float, float],
    third: tuple[float, float],
) -> float:
    return (
        (second[0] - first[0]) * (third[1] - second[1])
        - (second[1] - first[1]) * (third[0] - second[0])
    )


def _ccw(
    polygon: Sequence[tuple[float, float]],
) -> tuple[tuple[float, float], ...]:
    values = tuple(polygon)
    return values if _signed_area_xy(values) > 0.0 else tuple(reversed(values))


def _line_intersection(
    first: tuple[float, float],
    second: tuple[float, float],
    clip_first: tuple[float, float],
    clip_second: tuple[float, float],
) -> tuple[float, float]:
    dx = second[0] - first[0]
    dy = second[1] - first[1]
    ex = clip_second[0] - clip_first[0]
    ey = clip_second[1] - clip_first[1]
    denominator = dx * ey - dy * ex
    if abs(denominator) <= 1.0e-30:
        return second
    offset_x = clip_first[0] - first[0]
    offset_y = clip_first[1] - first[1]
    parameter = (offset_x * ey - offset_y * ex) / denominator
    return (first[0] + parameter * dx, first[1] + parameter * dy)


def _convex_intersection_area(
    subject: Sequence[tuple[float, float]],
    clip: Sequence[tuple[float, float]],
    *,
    tolerance: float,
) -> float:
    output = list(_ccw(subject))
    clip_values = _ccw(clip)
    for clip_first, clip_second in zip(
        clip_values, (*clip_values[1:], clip_values[0])
    ):
        input_values = output
        output = []
        if not input_values:
            break

        def inside(point: tuple[float, float]) -> bool:
            return (
                (clip_second[0] - clip_first[0])
                * (point[1] - clip_first[1])
                - (clip_second[1] - clip_first[1])
                * (point[0] - clip_first[0])
            ) >= -tolerance

        previous = input_values[-1]
        previous_inside = inside(previous)
        for current in input_values:
            current_inside = inside(current)
            if current_inside != previous_inside:
                output.append(
                    _line_intersection(
                        previous,
                        current,
                        clip_first,
                        clip_second,
                    )
                )
            if current_inside:
                output.append(current)
            previous = current
            previous_inside = current_inside
    return abs(_signed_area_xy(output)) if len(output) >= 3 else 0.0


def _boundary_segment_name(
    first: Point3D,
    second: Point3D,
    bounds: tuple[float, float, float, float, float, float],
    opening: tuple[float, float, float, float] | None,
    *,
    tolerance: float,
) -> str | None:
    x0, x1, y0, y1, _z0, _z1 = bounds

    def on(axis: int, value: float, lower: float, upper: float) -> bool:
        tangent = 1 - axis
        return (
            abs(first[axis] - value) <= tolerance
            and abs(second[axis] - value) <= tolerance
            and lower - tolerance <= first[tangent] <= upper + tolerance
            and lower - tolerance <= second[tangent] <= upper + tolerance
        )

    for name, axis, value, lower, upper in (
        ("outer_x_min", 0, x0, y0, y1),
        ("outer_x_max", 0, x1, y0, y1),
        ("outer_y_min", 1, y0, x0, x1),
        ("outer_y_max", 1, y1, x0, x1),
    ):
        if on(axis, value, lower, upper):
            return name
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        for name, axis, value, lower, upper in (
            ("inner_x_min", 0, ix0, iy0, iy1),
            ("inner_x_max", 0, ix1, iy0, iy1),
            ("inner_y_min", 1, iy0, ix0, ix1),
            ("inner_y_max", 1, iy1, ix0, ix1),
        ):
            if on(axis, value, lower, upper):
                return name
    return None


def _validate_complete_section(
    fragment: CanonicalGeometryFragment,
    coordinates: Mapping[int, Point3D],
    facets: Sequence[Sequence[int]],
) -> tuple[float, int]:
    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, _z0, _z1 = bounds
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    area_tolerance = 1.0e-12 * scale * scale
    expected_area = (x1 - x0) * (y1 - y0)
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        expected_area -= (ix1 - ix0) * (iy1 - iy0)

    coordinate_keys = {
        tuple(round(value / tolerance) for value in point): node
        for node, point in coordinates.items()
    }
    if len(coordinate_keys) != len(coordinates):
        raise StructuredSweepMaterializationError(
            "inherited section repeats one geometric node under different IDs"
        )

    polygons: list[tuple[tuple[float, float], ...]] = []
    signed_areas: list[float] = []
    facet_keys: set[tuple[int, ...]] = set()
    for facet_index, facet in enumerate(facets, start=1):
        if (
            len(facet) not in {3, 4}
            or len(set(facet)) != len(facet)
            or any(node not in coordinates for node in facet)
        ):
            raise StructuredSweepMaterializationError(
                f"inherited section facet {facet_index} is not a valid TRI3/QUAD4"
            )
        key = _face_key(facet)
        if key in facet_keys:
            raise StructuredSweepMaterializationError(
                "inherited section repeats a facet"
            )
        facet_keys.add(key)
        polygon = _facet_polygon_xy(facet, coordinates)
        signed_area = _signed_area_xy(polygon)
        if abs(signed_area) <= area_tolerance:
            raise StructuredSweepMaterializationError(
                "inherited section contains a zero-area facet"
            )
        cross_values = tuple(
            _cross2(
                polygon[index - 1],
                polygon[index],
                polygon[(index + 1) % len(polygon)],
            )
            for index in range(len(polygon))
        )
        facet_orientation = 1.0 if signed_area > 0.0 else -1.0
        if any(
            value * facet_orientation <= area_tolerance
            for value in cross_values
        ):
            raise StructuredSweepMaterializationError(
                "inherited section facets must be strictly convex and non-self-intersecting"
            )
        if any(
            not (
                x0 - tolerance <= x <= x1 + tolerance
                and y0 - tolerance <= y <= y1 + tolerance
            )
            for x, y in polygon
        ):
            raise StructuredSweepMaterializationError(
                "inherited section facet escapes the canonical outer boundary"
            )
        polygons.append(polygon)
        signed_areas.append(signed_area)

    orientation = 1.0 if signed_areas[0] > 0.0 else -1.0
    if any(value * orientation <= 0.0 for value in signed_areas):
        raise StructuredSweepMaterializationError(
            "inherited section facet cycles are not consistently oriented"
        )

    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        opening_polygon = (
            (ix0, iy0),
            (ix1, iy0),
            (ix1, iy1),
            (ix0, iy1),
        )
        if any(
            _convex_intersection_area(
                polygon,
                opening_polygon,
                tolerance=tolerance,
            )
            > area_tolerance
            for polygon in polygons
        ):
            raise StructuredSweepMaterializationError(
                "inherited Frame section covers positive area inside its opening"
            )

    indexed_bounds = sorted(
        (
            min(point[0] for point in polygon),
            max(point[0] for point in polygon),
            min(point[1] for point in polygon),
            max(point[1] for point in polygon),
            index,
        )
        for index, polygon in enumerate(polygons)
    )
    active: deque[tuple[float, float, float, int]] = deque()
    for min_x, max_x, min_y, max_y, index in indexed_bounds:
        while active and active[0][0] < min_x - tolerance:
            active.popleft()
        for _other_max_x, other_min_y, other_max_y, other_index in active:
            if other_max_y < min_y - tolerance or max_y < other_min_y - tolerance:
                continue
            overlap = _convex_intersection_area(
                polygons[index],
                polygons[other_index],
                tolerance=tolerance,
            )
            if overlap > area_tolerance:
                raise StructuredSweepMaterializationError(
                    "inherited section facets overlap in positive area"
                )
        insertion = (max_x, min_y, max_y, index)
        if active and insertion[0] < active[-1][0]:
            ordered = sorted((*active, insertion), key=lambda value: value[0])
            active = deque(ordered)
        else:
            active.append(insertion)

    actual_area = math.fsum(abs(value) for value in signed_areas)
    if not math.isclose(
        actual_area,
        expected_area,
        rel_tol=1.0e-9,
        abs_tol=1.0e-12,
    ):
        raise StructuredSweepMaterializationError(
            "inherited section does not cover the complete canonical end surface"
        )
    edge_counts: Counter[tuple[int, int]] = Counter()
    edge_owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for facet_index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            key = tuple(sorted((first, second)))
            edge_counts[key] += 1
            edge_owners[key].append(facet_index)
    if any(value not in {1, 2} for value in edge_counts.values()):
        raise StructuredSweepMaterializationError(
            "inherited section is non-manifold"
        )

    adjacency: dict[int, set[int]] = defaultdict(set)
    for owners in edge_owners.values():
        if len(owners) == 2:
            adjacency[owners[0]].add(owners[1])
            adjacency[owners[1]].add(owners[0])
    reached = {0}
    queue = deque((0,))
    while queue:
        current = queue.popleft()
        for neighbor in adjacency[current]:
            if neighbor not in reached:
                reached.add(neighbor)
                queue.append(neighbor)
    if len(reached) != len(facets):
        raise StructuredSweepMaterializationError(
            "inherited section facets are not one edge-connected mesh"
        )

    boundary_length = 0.0
    for first, second in (edge for edge, count in edge_counts.items() if count == 1):
        first_point = coordinates[first]
        second_point = coordinates[second]
        if _boundary_segment_name(
            first_point,
            second_point,
            bounds,
            opening,
            tolerance=tolerance,
        ) is None:
            raise StructuredSweepMaterializationError(
                "inherited section has an interior open edge"
            )
        boundary_length += math.dist(first_point, second_point)
    expected_boundary_length = 2.0 * ((x1 - x0) + (y1 - y0))
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        expected_boundary_length += 2.0 * ((ix1 - ix0) + (iy1 - iy0))
    if not math.isclose(
        boundary_length,
        expected_boundary_length,
        rel_tol=1.0e-9,
        abs_tol=1.0e-12,
    ):
        raise StructuredSweepMaterializationError(
            "inherited section does not preserve the complete peripheral boundary"
        )
    return actual_area, sum(count == 1 for count in edge_counts.values())


def _validate_inherited_orthogonal_quad_partition(
    fragment: CanonicalGeometryFragment,
    coordinates: Mapping[int, Point3D],
    facets: Sequence[Sequence[int]],
) -> None:
    """Prove that an inherited end is an immutable Cartesian QUAD partition.

    The proof is evaluated in the canonical component frame.  A rigidly placed
    component can therefore be arbitrarily oriented in package coordinates,
    while every inherited facet must still be a true rectangle whose four
    edges follow the two axes perpendicular to the proven sweep direction.
    """

    bounds, _opening = _section_bounds(fragment)
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    if not facets or any(len(facet) != 4 for facet in facets):
        raise StructuredSweepMaterializationError(
            "an inherited sweep end section must contain only "
            "axis-orthogonal rectangular QUAD4 facets; TRI3 and other "
            "facet families cannot be extruded as an immutable HEX sweep"
        )

    for facet_index, facet in enumerate(facets, start=1):
        points = tuple(coordinates[node] for node in facet)
        x_values = _clustered_values(
            tuple(point[0] for point in points),
            tolerance=tolerance,
        )
        y_values = _clustered_values(
            tuple(point[1] for point in points),
            tolerance=tolerance,
        )
        if len(x_values) != 2 or len(y_values) != 2:
            raise StructuredSweepMaterializationError(
                f"inherited sweep end facet {facet_index} is not an "
                "axis-orthogonal rectangular QUAD4"
            )
        expected_corners = {
            (x_value, y_value)
            for x_value in x_values
            for y_value in y_values
        }
        actual_corners = {
            (
                min(x_values, key=lambda value: abs(point[0] - value)),
                min(y_values, key=lambda value: abs(point[1] - value)),
            )
            for point in points
        }
        if actual_corners != expected_corners:
            raise StructuredSweepMaterializationError(
                f"inherited sweep end facet {facet_index} is not an "
                "axis-orthogonal rectangular QUAD4"
            )
        for first, second in zip(points, (*points[1:], points[0])):
            x_changes = abs(first[0] - second[0]) > tolerance
            y_changes = abs(first[1] - second[1]) > tolerance
            if x_changes == y_changes:
                raise StructuredSweepMaterializationError(
                    f"inherited sweep end facet {facet_index} is not an "
                    "axis-orthogonal rectangular QUAD4"
                )


def _validate_partial_locked_end_patch(
    fragment: CanonicalGeometryFragment,
    coordinates: Mapping[int, Point3D],
    facets: Sequence[Sequence[int]],
    *,
    source_side_name: str,
) -> None:
    """Validate an immutable mixed planar subset before Gmsh completes it."""

    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    expected_z = z1 if source_side_name == "top" else z0
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    area_tolerance = 1.0e-12 * scale * scale
    coordinate_keys = {
        tuple(round(value / tolerance) for value in point)
        for point in coordinates.values()
    }
    if len(coordinate_keys) != len(coordinates):
        raise StructuredSweepMaterializationError(
            "locked end patch repeats one geometric node under different IDs"
        )
    if any(
        abs(point[2] - expected_z) > tolerance
        for point in coordinates.values()
    ):
        raise StructuredSweepMaterializationError(
            "locked end patch is not coplanar with the selected canonical end"
        )

    polygons: list[tuple[tuple[float, float], ...]] = []
    orientations: list[float] = []
    facet_keys: set[tuple[int, ...]] = set()
    edge_counts: Counter[tuple[int, int]] = Counter()
    for facet in facets:
        if (
            len(facet) not in {3, 4}
            or len(set(facet)) != len(facet)
            or any(node not in coordinates for node in facet)
        ):
            raise StructuredSweepMaterializationError(
                "locked end patch must contain valid TRI3/QUAD4 facets"
            )
        key = _face_key(facet)
        if key in facet_keys:
            raise StructuredSweepMaterializationError(
                "locked end patch repeats a facet"
            )
        facet_keys.add(key)
        polygon = _facet_polygon_xy(facet, coordinates)
        orientation = _signed_area_xy(polygon)
        if abs(orientation) <= area_tolerance:
            raise StructuredSweepMaterializationError(
                "locked end patch contains a zero-area facet"
            )
        facet_sign = 1.0 if orientation > 0.0 else -1.0
        if any(
            _cross2(
                polygon[index - 1],
                polygon[index],
                polygon[(index + 1) % len(polygon)],
            )
            * facet_sign
            <= area_tolerance
            for index in range(len(polygon))
        ):
            raise StructuredSweepMaterializationError(
                "locked end patch facets must be strictly convex and "
                "non-self-intersecting"
            )
        if any(
            not (
                x0 - tolerance <= x_value <= x1 + tolerance
                and y0 - tolerance <= y_value <= y1 + tolerance
            )
            for x_value, y_value in polygon
        ):
            raise StructuredSweepMaterializationError(
                "locked end patch escapes the canonical outer boundary"
            )
        if opening is not None:
            ix0, ix1, iy0, iy1 = opening
            opening_polygon = (
                (ix0, iy0),
                (ix1, iy0),
                (ix1, iy1),
                (ix0, iy1),
            )
            if _convex_intersection_area(
                polygon,
                opening_polygon,
                tolerance=tolerance,
            ) > area_tolerance:
                raise StructuredSweepMaterializationError(
                    "locked Frame end patch covers positive area inside its opening"
                )
        polygons.append(polygon)
        orientations.append(orientation)
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge_counts[tuple(sorted((first, second)))] += 1
    reference_orientation = orientations[0]
    if any(value * reference_orientation <= 0.0 for value in orientations):
        raise StructuredSweepMaterializationError(
            "locked end patch facet cycles are not consistently oriented"
        )
    if any(count not in {1, 2} for count in edge_counts.values()):
        raise StructuredSweepMaterializationError(
            "locked end patch is non-manifold"
        )
    for index, polygon in enumerate(polygons):
        for other in polygons[index + 1 :]:
            if _convex_intersection_area(
                polygon,
                other,
                tolerance=tolerance,
            ) > area_tolerance:
                raise StructuredSweepMaterializationError(
                    "locked end patch facets overlap in positive area"
                )


def _consistently_oriented_planar_facets(
    coordinates: Mapping[int, Point3D],
    facets: Sequence[Sequence[int]],
) -> tuple[tuple[int, ...], ...]:
    """Choose one consumer-side cycle orientation without changing face keys.

    Shared-surface authority is the immutable geometric facet (its node set
    and edges), not the producer's outward cycle direction.  Facets arriving
    from multiple producers can therefore legitimately have opposite cycle
    directions when viewed from one sweep endpoint.  Gmsh needs one coherent
    section orientation, so only those cycles are reversed locally; the
    reported locked facets retain their original caller cycles.
    """

    signed = tuple(
        _signed_area_xy(_facet_polygon_xy(facet, coordinates))
        for facet in facets
    )
    nonzero = next((value for value in signed if value != 0.0), None)
    if nonzero is None:
        return tuple(tuple(facet) for facet in facets)
    reference = 1.0 if nonzero > 0.0 else -1.0
    return tuple(
        tuple(facet) if value * reference > 0.0 else tuple(reversed(facet))
        for facet, value in zip(facets, signed)
    )


def _point_inside_polygon(
    point: tuple[float, float],
    polygon: Sequence[tuple[float, float]],
) -> bool:
    """Return odd-even containment for a point known not to lie on an edge."""

    x_value, y_value = point
    inside = False
    previous = polygon[-1]
    for current in polygon:
        if (current[1] > y_value) != (previous[1] > y_value):
            crossing_x = (
                previous[0]
                + (y_value - previous[1])
                * (current[0] - previous[0])
                / (current[1] - previous[1])
            )
            if crossing_x > x_value:
                inside = not inside
        previous = current
    return inside


def _locked_patch_boundary_cycles(
    coordinates: Mapping[int, Point3D],
    facets: Sequence[Sequence[int]],
) -> tuple[tuple[int, ...], ...]:
    """Recover exact boundary cycles of one edge-connected locked patch."""

    edge_owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for facet_index, facet in enumerate(facets):
        for first, second in zip(facet, (*facet[1:], facet[0])):
            edge_owners[tuple(sorted((first, second)))].append(facet_index)
    if any(len(owners) not in {1, 2} for owners in edge_owners.values()):
        raise StructuredSweepMaterializationError(
            "partial mixed locked end is non-manifold"
        )

    facet_adjacency: dict[int, set[int]] = defaultdict(set)
    for owners in edge_owners.values():
        if len(owners) == 2:
            facet_adjacency[owners[0]].add(owners[1])
            facet_adjacency[owners[1]].add(owners[0])
    reached = {0}
    pending = deque((0,))
    while pending:
        current = pending.popleft()
        for neighbor in facet_adjacency[current]:
            if neighbor not in reached:
                reached.add(neighbor)
                pending.append(neighbor)
    if len(reached) != len(facets):
        raise StructuredSweepMaterializationError(
            "partial mixed locked end must be one edge-connected planar subregion"
        )

    boundary_edges = {
        edge for edge, owners in edge_owners.items() if len(owners) == 1
    }
    graph: dict[int, set[int]] = defaultdict(set)
    for first, second in boundary_edges:
        graph[first].add(second)
        graph[second].add(first)
    if not graph or any(len(neighbors) != 2 for neighbors in graph.values()):
        raise StructuredSweepMaterializationError(
            "partial mixed locked end boundary is not a union of closed cycles"
        )

    remaining = set(boundary_edges)
    cycles: list[tuple[int, ...]] = []
    while remaining:
        first_edge = min(remaining)
        start, current = first_edge
        previous = start
        cycle = [start]
        while True:
            cycle.append(current)
            remaining.discard(tuple(sorted((previous, current))))
            choices = tuple(
                node for node in graph[current] if node != previous
            )
            if len(choices) != 1:
                raise StructuredSweepMaterializationError(
                    "partial mixed locked end boundary branches"
                )
            following = choices[0]
            if following == start:
                remaining.discard(tuple(sorted((current, following))))
                break
            if following in cycle:
                raise StructuredSweepMaterializationError(
                    "partial mixed locked end boundary self-intersects"
                )
            previous, current = current, following
        cycles.append(tuple(cycle))
    return tuple(cycles)


def _complete_mixed_locked_end_patch(
    fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
    locked_coordinates: Mapping[int, Point3D],
    locked_facets: Sequence[Sequence[int]],
    *,
    minimum_quality: float,
    contact_partition_loops=(),
    outer_boundary_coordinates: Mapping[int, Point3D] | None = None,
    outer_boundary_loop: Sequence[int] = (),
    verbose: bool,
    boundary_size_policy: BoundarySizePolicy | None = None,
) -> tuple[Mapping[int, Point3D], tuple[tuple[int, ...], ...]]:
    """Let Gmsh complete a proven nested planar subregion around a lock.

    The supported proof is geometric rather than role based: one connected
    locked patch has one strictly interior outer cycle and, for a Frame, may
    use the complete canonical opening as its sole hole.  Its complement is
    consequently one unambiguous planar region.  Boundary-touching or nested
    multi-island arrangements remain explicit capability blockers instead of
    being guessed or trimmed.
    """

    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    area_tolerance = 1.0e-12 * scale * scale
    cycles = _locked_patch_boundary_cycles(locked_coordinates, locked_facets)
    polygons = {
        cycle: _facet_polygon_xy(cycle, locked_coordinates)
        for cycle in cycles
    }
    outer_cycle = max(
        cycles,
        key=lambda cycle: abs(_signed_area_xy(polygons[cycle])),
    )
    hole_cycles = tuple(cycle for cycle in cycles if cycle != outer_cycle)
    outer_polygon = polygons[outer_cycle]
    if any(
        not _point_inside_polygon(polygons[cycle][0], outer_polygon)
        for cycle in hole_cycles
    ):
        raise StructuredSweepMaterializationError(
            "partial mixed locked end has multiple outer islands; one sweep "
            "section complement cannot be proven"
        )
    facet_area = math.fsum(
        abs(_signed_area_xy(_facet_polygon_xy(facet, locked_coordinates)))
        for facet in locked_facets
    )
    cycle_area = abs(_signed_area_xy(outer_polygon)) - math.fsum(
        abs(_signed_area_xy(polygons[cycle])) for cycle in hole_cycles
    )
    if not math.isclose(
        facet_area,
        cycle_area,
        rel_tol=1.0e-9,
        abs_tol=area_tolerance,
    ):
        raise StructuredSweepMaterializationError(
            "partial mixed locked end facets do not fill their boundary cycles"
        )

    # A strictly interior outer loop makes the complement representable as
    # one Gmsh planar region with this loop as a hole.  If it touches an outer
    # boundary, a more general polygonal Boolean partition would be required;
    # fail closed rather than infer one from component semantics.
    if any(
        (
            abs(point[0] - x0) <= tolerance
            or abs(point[0] - x1) <= tolerance
            or abs(point[1] - y0) <= tolerance
            or abs(point[1] - y1) <= tolerance
        )
        for point in outer_polygon
    ):
        raise StructuredSweepMaterializationError(
            "partial mixed locked end touches the canonical outer boundary; "
            "its complementary planar region is not uniquely proven"
        )

    opening_absorbed = False
    if hole_cycles:
        if opening is None or len(hole_cycles) != 1:
            raise StructuredSweepMaterializationError(
                "partial mixed locked end contains an unsupported interior hole"
            )
        hole = hole_cycles[0]
        hole_polygon = polygons[hole]
        ix0, ix1, iy0, iy1 = opening
        expected_opening_area = (ix1 - ix0) * (iy1 - iy0)
        segment_names = {
            _boundary_segment_name(
                locked_coordinates[first],
                locked_coordinates[second],
                bounds,
                opening,
                tolerance=tolerance,
            )
            for first, second in zip(hole, (*hole[1:], hole[0]))
        }
        if (
            None in segment_names
            or segment_names
            != {
                "inner_x_min",
                "inner_x_max",
                "inner_y_min",
                "inner_y_max",
            }
            or not math.isclose(
                abs(_signed_area_xy(hole_polygon)),
                expected_opening_area,
                rel_tol=1.0e-9,
                abs_tol=area_tolerance,
            )
        ):
            raise StructuredSweepMaterializationError(
                "partial mixed locked end hole is not the complete canonical "
                "Frame opening"
            )
        opening_absorbed = True

    source_coordinates = dict(locked_coordinates)
    if outer_boundary_coordinates:
        if set(source_coordinates).intersection(outer_boundary_coordinates):
            raise StructuredSweepMaterializationError(
                "completion outer boundary must use distinct source node IDs"
            )
        source_coordinates.update(outer_boundary_coordinates)
    preserved_coordinates = dict(source_coordinates)
    next_node = max(source_coordinates, default=0) + 1

    def canonical_node(point: Point3D) -> int:
        nonlocal next_node
        matches = tuple(
            node
            for node, existing in source_coordinates.items()
            if math.dist(existing, point) <= tolerance
        )
        if len(matches) > 1:
            raise StructuredSweepMaterializationError(
                "partial mixed locked end repeats one canonical corner"
            )
        if matches:
            return matches[0]
        node = next_node
        next_node += 1
        source_coordinates[node] = point
        return node

    source_z = next(iter(locked_coordinates.values()))[2]
    if not (
        abs(source_z - z0) <= tolerance
        or abs(source_z - z1) <= tolerance
    ):
        raise StructuredSweepMaterializationError(
            "partial mixed locked end is not on a canonical sweep endpoint"
        )
    canonical_outer = tuple(
        canonical_node(point)
        for point in (
            (x0, y0, source_z),
            (x1, y0, source_z),
            (x1, y1, source_z),
            (x0, y1, source_z),
        )
    )
    if outer_boundary_loop:
        canonical_outer = tuple(outer_boundary_loop)
    remainder_holes: list[tuple[int, ...]] = [outer_cycle]
    if opening is not None and not opening_absorbed:
        ix0, ix1, iy0, iy1 = opening
        remainder_holes.append(
            tuple(
                canonical_node(point)
                for point in (
                    (ix0, iy0, source_z),
                    (ix1, iy0, source_z),
                    (ix1, iy1, source_z),
                    (ix0, iy1, source_z),
                )
            )
        )
    surface = generate_gmsh_shared_surface(
        source_coordinates,
        (
            PlanarRegion(
                "generated_remainder",
                canonical_outer,
                holes=tuple(remainder_holes),
            ),
            PlanarRegion(
                "locked_patch",
                outer_cycle,
                holes=hole_cycles,
            ),
        ),
        locked_facets_by_region={"locked_patch": tuple(locked_facets)},
        locked_boundary_chains=(
            (LockedBoundaryChain(tuple(outer_boundary_loop), closed=True),)
            if outer_boundary_loop else ()
        ),
        contact_partition_loops=contact_partition_loops,
        target_edge_mm=requirement.target_edge_mm,
        transition_distance_mm=requirement.transition_distance_mm,
        boundary_size_policy=boundary_size_policy,
        minimum_quality=minimum_quality,
        verbose=verbose,
    )

    # Restore immutable caller IDs/cycles while assigning collision-free IDs
    # to Gmsh's complementary nodes.  Connectivity remains exactly what Gmsh
    # returned for the generated region.
    final_by_surface: dict[int, int] = {}
    used_final = set(preserved_coordinates)
    for local_node, source_node in surface.source_node_id_by_local_id.items():
        if source_node in preserved_coordinates:
            final_by_surface[local_node] = source_node
    next_final = 1
    for local_node in sorted(surface.node_coordinates):
        if local_node in final_by_surface:
            continue
        while next_final in used_final:
            next_final += 1
        final_by_surface[local_node] = next_final
        used_final.add(next_final)
        next_final += 1
    final_coordinates = MappingProxyType(
        {
            final_by_surface[node]: point
            for node, point in surface.node_coordinates.items()
        }
    )
    locked_by_key = {
        _face_key(facet): tuple(facet) for facet in locked_facets
    }
    reference_sign = 1.0 if _signed_area_xy(
        _facet_polygon_xy(locked_facets[0], locked_coordinates)
    ) > 0.0 else -1.0
    completed: list[tuple[int, ...]] = []
    recovered_locked: set[tuple[int, ...]] = set()
    for surface_facet in surface.facets:
        mapped = tuple(final_by_surface[node] for node in surface_facet.node_ids)
        if surface_facet.provenance == "locked_source":
            key = _face_key(mapped)
            original = locked_by_key.get(key)
            if original is None:
                raise StructuredSweepMaterializationError(
                    "Gmsh planar completion changed a locked end facet"
                )
            completed.append(original)
            recovered_locked.add(key)
            continue
        if _signed_area_xy(
            _facet_polygon_xy(mapped, final_coordinates)
        ) * reference_sign <= 0.0:
            mapped = tuple(reversed(mapped))
        completed.append(mapped)
    if recovered_locked != set(locked_by_key):
        raise StructuredSweepMaterializationError(
            "Gmsh planar completion omitted a locked end facet"
        )
    return final_coordinates, tuple(completed)


def _orthogonal_contact_rectangle(
    loop: Sequence[Point3D], *, tolerance: float,
) -> tuple[float, float, float, float]:
    points = tuple(loop)
    xs = _clustered_values(tuple(p[0] for p in points), tolerance=tolerance)
    ys = _clustered_values(tuple(p[1] for p in points), tolerance=tolerance)
    if len(points) != 4 or len(xs) != 2 or len(ys) != 2:
        raise StructuredSweepMaterializationError(
            "scoped orthogonal sweep contact requires a canonical rectangle"
        )
    coordinates = dict(enumerate(points, start=1))
    # Check the perimeter cycle as well as the four coordinate combinations.
    probe = CanonicalGeometryFragment(
        "contact_rectangle",
        CanonicalBox((xs[0], ys[0], points[0][2]),
                     (xs[1] - xs[0], ys[1] - ys[0], 1.0)),
        _IDENTITY_PLACEMENT,
    )
    _validate_inherited_orthogonal_quad_partition(probe, coordinates, ((1, 2, 3, 4),))
    return xs[0], xs[1], ys[0], ys[1]


def _complete_locked_end_with_orthogonal_collar(
    fragment: CanonicalGeometryFragment,
    requirement: ComponentMeshRequirement,
    locked_coordinates: Mapping[int, Point3D],
    locked_facets: Sequence[Sequence[int]],
    regions: Sequence[EndContactRegion],
    *,
    minimum_quality: float,
    verbose: bool,
    boundary_size_policy: BoundarySizePolicy | None = None,
    contact_partition_loops=(),
) -> tuple[Mapping[int, Point3D], tuple[tuple[int, ...], ...]]:
    """Mesh a rectangular outer contact separately from its mixed interior.

    This bounded geometric proof accepts one Frame contact sharing the sweep's
    outer perimeter. Its opening must enclose the immutable end patch and the
    sweep opening. Gmsh meshes the contact as rectangular QUADs, then completes
    the interior while reusing the contact's exact inner boundary chain.
    """
    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    tolerance = 1.e-9 * max(1., *(abs(v) for v in bounds))
    if len(regions) != 1 or len(regions[0]) != 2:
        raise StructuredSweepMaterializationError(
            "partial orthogonal end completion requires one rectangular outer collar"
        )
    outer, inner = (
        _orthogonal_contact_rectangle(loop, tolerance=tolerance)
        for loop in regions[0]
    )
    if any(abs(a-b) > tolerance for a, b in zip(outer, bounds[:4])):
        raise StructuredSweepMaterializationError(
            "orthogonal end collar must share the canonical outer perimeter"
        )
    ix0, ix1, iy0, iy1 = inner
    if not (x0 < ix0 < ix1 < x1 and y0 < iy0 < iy1 < y1):
        raise StructuredSweepMaterializationError("orthogonal end collar has an invalid opening")
    if opening is not None and not (
        ix0 < opening[0] < opening[1] < ix1
        and iy0 < opening[2] < opening[3] < iy1
    ):
        raise StructuredSweepMaterializationError(
            "orthogonal end collar must enclose the canonical sweep opening"
        )
    if any(not (ix0 + tolerance < p[0] < ix1 - tolerance
                and iy0 + tolerance < p[1] < iy1 - tolerance)
           for p in locked_coordinates.values()):
        raise StructuredSweepMaterializationError(
            "orthogonal end collar intersects an immutable inherited patch"
        )
    collar = CanonicalGeometryFragment(
        fragment.fragment_id,
        CanonicalRectangularFrameExtrusion(
            (x0, y0, z0), (x1-x0, y1-y0), (ix0-x0, iy0-y0),
            (ix1-ix0, iy1-iy0), z1-z0,
        ), _IDENTITY_PLACEMENT,
    )
    at_top = abs(next(iter(locked_coordinates.values()))[2] - z1) <= tolerance
    collar_coordinates, collar_facets = _generated_orthogonal_section(
        collar, requirement, None, at_top=at_top,
        contact_partition_loops=contact_partition_loops,
        minimum_quality=minimum_quality, verbose=verbose,
    )
    offset = max(locked_coordinates, default=0)
    collar_coordinates = {n+offset: p for n, p in collar_coordinates.items()}
    collar_facets = tuple(tuple(n+offset for n in f) for f in collar_facets)
    cycles = _locked_patch_boundary_cycles(collar_coordinates, collar_facets)
    inner_cycle = min(cycles, key=lambda c: abs(_signed_area_xy(
        _facet_polygon_xy(c, collar_coordinates))))
    inner_coordinates = {n: collar_coordinates[n] for n in inner_cycle}
    remainder_root = (
        CanonicalBox((ix0, iy0, z0), (ix1-ix0, iy1-iy0, z1-z0))
        if opening is None else CanonicalRectangularFrameExtrusion(
            (ix0, iy0, z0), (ix1-ix0, iy1-iy0),
            (opening[0]-ix0, opening[2]-iy0),
            (opening[1]-opening[0], opening[3]-opening[2]), z1-z0,
        )
    )
    remainder = CanonicalGeometryFragment(fragment.fragment_id, remainder_root, _IDENTITY_PLACEMENT)
    completed_coordinates, completed_facets = _complete_mixed_locked_end_patch(
        remainder, requirement, locked_coordinates, locked_facets,
        outer_boundary_coordinates=inner_coordinates, outer_boundary_loop=inner_cycle,
        boundary_size_policy=boundary_size_policy,
        contact_partition_loops=contact_partition_loops,
        minimum_quality=minimum_quality, verbose=verbose,
    )
    # Keep immutable IDs and shared collar-chain IDs; allocate fresh IDs only
    # for the complementary Gmsh nodes before joining the two surface meshes.
    fixed = set(locked_coordinates) | set(inner_coordinates)
    next_node = max(collar_coordinates) + 1
    remap = {}
    for node in sorted(completed_coordinates):
        if node in fixed:
            remap[node] = node
        else:
            remap[node] = next_node
            next_node += 1
    coordinates = dict(collar_coordinates)
    coordinates.update({remap[n]: p for n, p in completed_coordinates.items()})
    facets = (*collar_facets, *(tuple(remap[n] for n in f) for f in completed_facets))
    facets = _consistently_oriented_planar_facets(coordinates, facets)
    _validate_complete_section(fragment, coordinates, facets)
    return coordinates, facets


def _validate_orthogonal_end_contacts(
    fragment: CanonicalGeometryFragment,
    coordinates: Mapping[int, Point3D],
    facets: Sequence[Sequence[int]],
    regions: Sequence[EndContactRegion],
) -> None:
    """Prove rectangular facets cover each contact exactly, with no cut cells."""
    bounds, _opening = _section_bounds(fragment)
    tolerance = 1.e-12 * max(1., *(abs(v) for v in bounds)) ** 2
    for loops in regions:
        polygons = tuple(tuple((p[0], p[1]) for p in loop) for loop in loops)
        expected = abs(_signed_area_xy(polygons[0])) - math.fsum(
            abs(_signed_area_xy(p)) for p in polygons[1:])
        selected, areas = [], []
        for facet in facets:
            polygon = _facet_polygon_xy(facet, coordinates)
            overlap = _convex_intersection_area(polygon, polygons[0], tolerance=tolerance) - math.fsum(
                _convex_intersection_area(polygon, hole, tolerance=tolerance) for hole in polygons[1:])
            if overlap <= tolerance:
                continue
            if not math.isclose(overlap, abs(_signed_area_xy(polygon)), rel_tol=1.e-9, abs_tol=tolerance):
                raise StructuredSweepMaterializationError(
                    "orthogonal end contact boundary would split a sweep facet"
                )
            selected.append(facet)
            areas.append(overlap)
        if expected <= tolerance or not math.isclose(math.fsum(areas), expected, rel_tol=1.e-9, abs_tol=tolerance):
            raise StructuredSweepMaterializationError("orthogonal end contact is not completely covered")
        _validate_inherited_orthogonal_quad_partition(fragment, coordinates, selected)


def _boundary_faces(
    element_rows: Sequence[tuple[int, int, tuple[int, ...]]],
) -> tuple[tuple[tuple[int, ...], ...], Mapping[int, int]]:
    counts: Counter[tuple[int, ...]] = Counter()
    original: dict[tuple[int, ...], tuple[int, ...]] = {}
    for _tag, gmsh_type, nodes in element_rows:
        for local_face in ELEMENT_SPECS[gmsh_type][2]:
            face = tuple(nodes[index] for index in local_face)
            key = _face_key(face)
            counts[key] += 1
            original.setdefault(key, face)
    if any(value not in {1, 2} for value in counts.values()):
        raise StructuredSweepMaterializationError(
            "Gmsh sweep volume is non-manifold"
        )
    return (
        tuple(original[key] for key, count in counts.items() if count == 1),
        MappingProxyType(dict(sorted(Counter(counts.values()).items()))),
    )


def _classify_face(
    face: Sequence[int],
    coordinates: Mapping[int, Point3D],
    fragment: CanonicalGeometryFragment,
) -> str:
    bounds, opening = _section_bounds(fragment)
    x0, x1, y0, y1, z0, z1 = bounds
    points = tuple(coordinates[node] for node in face)
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale

    def on(axis: int, value: float) -> bool:
        return all(abs(point[axis] - value) <= tolerance for point in points)

    if on(2, z0):
        return "bottom"
    if on(2, z1):
        return "top"
    for name, axis, value in (
        ("outer_x_min", 0, x0),
        ("outer_x_max", 0, x1),
        ("outer_y_min", 1, y0),
        ("outer_y_max", 1, y1),
    ):
        if on(axis, value):
            return name[6:] if opening is None else name
    if opening is not None:
        ix0, ix1, iy0, iy1 = opening
        for name, axis, value in (
            ("inner_x_min", 0, ix0),
            ("inner_x_max", 0, ix1),
            ("inner_y_min", 1, iy0),
            ("inner_y_max", 1, iy1),
        ):
            if on(axis, value):
                return name
    raise StructuredSweepMaterializationError(
        "Gmsh sweep boundary facet escaped canonical geometry"
    )


def _validate_lateral_rectangular_quads(
    boundary: Mapping[str, Sequence[Sequence[int]]],
    coordinates: Mapping[int, Point3D],
    fragment: CanonicalGeometryFragment,
) -> None:
    """Audit the lateral contact capability of a translational sweep."""

    bounds, _opening = _section_bounds(fragment)
    scale = max(1.0, *(abs(value) for value in bounds))
    tolerance = 1.0e-9 * scale
    specifications = _lateral_side_specifications(fragment)
    for side, facets in boundary.items():
        if side in {"bottom", "top"}:
            continue
        try:
            normal_axis, normal_value, tangent_axis, _lower, _upper = (
                specifications[side]
            )
        except KeyError as error:  # pragma: no cover - classification guards this
            raise StructuredSweepMaterializationError(
                f"structured sweep has no lateral capability proof for {side!r}"
            ) from error
        for facet in facets:
            if len(facet) != 4:
                raise StructuredSweepMaterializationError(
                    "structured sweep lateral contact is not an orthogonal "
                    "rectangular QUAD4"
                )
            points = tuple(coordinates[node] for node in facet)
            normal_levels = _clustered_values(
                tuple(point[normal_axis] for point in points),
                tolerance=tolerance,
            )
            tangent_levels = _clustered_values(
                tuple(point[tangent_axis] for point in points),
                tolerance=tolerance,
            )
            axial_levels = _clustered_values(
                tuple(point[2] for point in points),
                tolerance=tolerance,
            )
            if (
                len(normal_levels) != 1
                or abs(normal_levels[0] - normal_value) > tolerance
                or len(tangent_levels) != 2
                or len(axial_levels) != 2
                or {
                    (
                        min(
                            tangent_levels,
                            key=lambda value: abs(point[tangent_axis] - value),
                        ),
                        min(
                            axial_levels,
                            key=lambda value: abs(point[2] - value),
                        ),
                    )
                    for point in points
                }
                != {
                    (tangent, axial)
                    for tangent in tangent_levels
                    for axial in axial_levels
                }
            ):
                raise StructuredSweepMaterializationError(
                    "structured sweep lateral contact is not an orthogonal "
                    "rectangular QUAD4"
                )


def materialize_structured_sweep_component(
    canonical_fragment: CanonicalGeometryFragment,
    source_node_coordinates_package_mm: Mapping[int, Sequence[float]] | None,
    source_facets: Sequence[Sequence[int]] | None,
    requirement: ComponentMeshRequirement,
    *,
    sweep_direction: ComponentLocalDirection | str,
    sweep_strategy: StructuredSweepMeshStrategy | None = None,
    source_side_name: str | None = None,
    material_name: str,
    fragment_key: str | None = None,
    provenance: str = "gmsh_structured_sweep",
    semantic_tokens_by_source_node_id: Mapping[int, str] | None = None,
    locked_boundary_node_coordinates_package_mm: Mapping[
        int, Sequence[float]
    ] | None = None,
    locked_boundary_facets_by_geometric_side: Mapping[
        str, Sequence[Sequence[int]]
    ] | None = None,
    semantic_tokens_by_locked_node_id: Mapping[int, str] | None = None,
    require_orthogonal_end_sections: bool = False,
    orthogonal_end_contact_regions_package_mm: Sequence[EndContactRegion] = (),
    allow_partial_lateral_locks: bool = False,
    contact_partition_loops_package_mm=(),
    interface_geometry_tolerance_mm: float = DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    minimum_quality: float = _QUALITY_FLOOR,
    verbose: bool = False,
) -> StructuredSweepComponentMesh:
    """Extrude one complete section in an explicit Component-local direction.

    Passing both source arguments as ``None`` asks the backend to generate a
    complete authority surface.  A complete inherited end may contain any
    non-overlapping convex TRI3/QUAD4 partition; Gmsh maps TRI to WEDGE and
    QUAD to HEX through its native extrusion.  A partial inherited end may be
    a mixed, connected planar subregion when its complementary Box/Frame
    region is uniquely proven; Gmsh retains the subregion and meshes the
    remainder.  Orthogonal QUAD-only partial ends retain the tensor completion
    path. Sweep executors and Hybrid adapters enable partial lateral locks:
    these must match the inherited end's perimeter edges, or constrain a newly
    generated end when no end is inherited. All locks use a common axial level
    union, with no lock skipping a level. Unlocked intervals use the target size.
    Set ``require_orthogonal_end_sections`` only when a downstream Orth
    interface requires rectangular QUAD4 output. An actual partial outer Frame
    contact can scope this requirement with ``orthogonal_end_contact_regions``;
    its inner complement may remain mixed. No 3-D connectivity is manufactured
    by EasyMesh.
    """

    if type(canonical_fragment) is not CanonicalGeometryFragment:
        raise StructuredSweepMaterializationError(
            "canonical_fragment must be canonical geometry"
        )
    if type(requirement) is not ComponentMeshRequirement or (
        requirement.volume_topology != "structured_sweep"
    ):
        raise StructuredSweepMaterializationError(
            "materializer requires structured_sweep topology"
        )
    try:
        requested_direction = (
            sweep_direction
            if isinstance(sweep_direction, ComponentLocalDirection)
            else ComponentLocalDirection(sweep_direction)
        )
    except (TypeError, ValueError) as error:
        raise StructuredSweepMaterializationError(
            "structured sweep requires one explicit Component-local direction"
        ) from error
    sweep_axis, positive = _sweep_axis_and_sign(requested_direction)
    root = canonical_fragment.root
    if type(root) is CanonicalRectangularFrameExtrusion and sweep_axis != 2:
        raise StructuredSweepMaterializationError(
            "structured_sweep direction "
            f"{requested_direction.value!r} is invalid for "
            "RectangularFrameExtrusion: its invariant section is normal to "
            "Component-local Z, so only positive_z or negative_z is executable"
        )
    if type(root) is CanonicalBox:
        expected_source_side = _box_shell_side(sweep_axis, not positive)
    elif type(root) is CanonicalRectangularFrameExtrusion:
        expected_source_side = "bottom" if positive else "top"
    else:
        # Keep the existing geometry-specific proof diagnostic.
        _section_bounds(canonical_fragment)
        raise AssertionError("unreachable")
    if source_side_name is None:
        source_side_name = expected_source_side
    elif source_side_name != expected_source_side:
        raise StructuredSweepMaterializationError(
            "structured sweep source side conflicts with explicit direction: "
            f"{requested_direction.value!r} requires {expected_source_side!r}, "
            f"got {source_side_name!r}"
        )

    sizing = MeshSeedPolicy() if sweep_strategy is None else sweep_strategy.sizing
    seed_origin = (None if sweep_strategy is None else geometry_origin(
        root, sizing, sweep_strategy.partition_origin_mm))
    axial_target = (requirement.target_edge_mm if sweep_strategy is None or
                    sweep_strategy.layer_size_mm is None else sweep_strategy.layer_size_mm)
    # The proven extrusion kernel is written in one right-handed XY/Z frame.
    # A Box may sweep along any local axis, so cyclically permute its local
    # coordinates into that frame, run the same audited Gmsh path, then map
    # only coordinates and geometric side labels back.  Connectivity remains
    # exactly what Gmsh emitted.
    if type(root) is CanonicalBox and sweep_axis != 2:
        work_axes = _box_work_axes(sweep_axis)
        working_root = CanonicalBox(
            _permute_point_to_work(root.origin_xyz_mm, work_axes),
            _permute_point_to_work(root.size_xyz_mm, work_axes),
        )
        working_fragment = CanonicalGeometryFragment(
            canonical_fragment.fragment_id,
            working_root,
            _IDENTITY_PLACEMENT,
        )

        def package_to_work(point: Sequence[float]) -> Point3D:
            package_point = _point3(point, field_name="sweep input coordinate")
            return _permute_point_to_work(
                _to_local(package_point, canonical_fragment.placement),
                work_axes,
            )

        working_source_coordinates = (
            None
            if source_node_coordinates_package_mm is None
            else {
                node: package_to_work(point)
                for node, point in source_node_coordinates_package_mm.items()
            }
        )
        working_locked_coordinates = (
            None
            if locked_boundary_node_coordinates_package_mm is None
            else {
                node: package_to_work(point)
                for node, point in locked_boundary_node_coordinates_package_mm.items()
            }
        )
        working_locked_facets = (
            None
            if locked_boundary_facets_by_geometric_side is None
            else {
                _box_side_to_work(side, work_axes): facets
                for side, facets in locked_boundary_facets_by_geometric_side.items()
            }
        )
        working_direction = (
            ComponentLocalDirection.POSITIVE_Z
            if positive
            else ComponentLocalDirection.NEGATIVE_Z
        )
        working_result = materialize_structured_sweep_component(
            working_fragment,
            working_source_coordinates,
            source_facets,
            requirement,
            sweep_direction=working_direction,
            sweep_strategy=(None if sweep_strategy is None else replace(
                sweep_strategy, direction=working_direction,
                sizing=replace(sizing, origin="custom" if seed_origin is not None else "legacy"),
                partition_origin_mm=(None if seed_origin is None else _permute_point_to_work(seed_origin, work_axes)))),
            source_side_name="bottom" if positive else "top",
            material_name=material_name,
            fragment_key=fragment_key,
            provenance=provenance,
            semantic_tokens_by_source_node_id=semantic_tokens_by_source_node_id,
            locked_boundary_node_coordinates_package_mm=(
                working_locked_coordinates
            ),
            locked_boundary_facets_by_geometric_side=working_locked_facets,
            semantic_tokens_by_locked_node_id=semantic_tokens_by_locked_node_id,
            require_orthogonal_end_sections=require_orthogonal_end_sections,
            orthogonal_end_contact_regions_package_mm=tuple(
                tuple(tuple(package_to_work(p) for p in loop) for loop in region)
                for region in orthogonal_end_contact_regions_package_mm
            ),
            allow_partial_lateral_locks=allow_partial_lateral_locks,
            contact_partition_loops_package_mm=tuple(tuple(package_to_work(p) for p in loop) for loop in contact_partition_loops_package_mm),
            interface_geometry_tolerance_mm=interface_geometry_tolerance_mm,
            minimum_quality=minimum_quality,
            verbose=verbose,
        )

        def work_to_package(point: Point3D) -> Point3D:
            return _to_package(
                _unpermute_point_from_work(point, work_axes),
                canonical_fragment.placement,
            )

        result_fragment = replace(
            working_result.component_fragment,
            nodes=tuple(
                replace(node, coordinates_mm=work_to_package(node.coordinates_mm))
                for node in working_result.component_fragment.nodes
            ),
        )
        return replace(
            working_result,
            canonical_fragment=canonical_fragment,
            source_side_name=expected_source_side,
            component_fragment=result_fragment,
            locked_facets_by_geometric_side={
                _box_side_from_work(side, work_axes): facets
                for side, facets in working_result.locked_facets_by_geometric_side.items()
            },
            boundary_facets_by_geometric_side={
                _box_side_from_work(side, work_axes): facets
                for side, facets in working_result.boundary_facets_by_geometric_side.items()
            },
        )

    if source_side_name not in {"bottom", "top"}:
        raise StructuredSweepMaterializationError(
            "internal structured sweep source must be bottom or top after "
            "direction normalization"
        )
    if not isinstance(verbose, bool):
        raise StructuredSweepMaterializationError("verbose must be boolean")
    if not isinstance(require_orthogonal_end_sections, bool):
        raise StructuredSweepMaterializationError(
            "require_orthogonal_end_sections must be boolean"
        )
    if (
        isinstance(minimum_quality, bool)
        or not isinstance(minimum_quality, (int, float))
        or not math.isfinite(float(minimum_quality))
        or not _QUALITY_FLOOR <= float(minimum_quality) < 1.0
    ):
        raise StructuredSweepMaterializationError(
            "minimum_quality must be finite, at least 0.03, and below one"
        )
    resolved_quality = float(minimum_quality)
    if not isinstance(allow_partial_lateral_locks, bool):
        raise StructuredSweepMaterializationError("allow_partial_lateral_locks must be boolean")
    geometry_tolerance = validate_interface_geometry_tolerance_mm(interface_geometry_tolerance_mm)
    bounds, _opening = _section_bounds(canonical_fragment)
    z0, z1 = bounds[4], bounds[5]
    contact_partition_loops = tuple(
        tuple((*_to_local(point, canonical_fragment.placement)[:2], z1 if source_side_name == "top" else z0)
              for point in loop)
        for loop in contact_partition_loops_package_mm
    )
    coordinate_tolerance = 1.0e-9 * max(
        1.0, *(abs(value) for value in bounds)
    )
    orthogonal_end_regions = tuple(
        tuple(tuple((*_to_local(p, canonical_fragment.placement)[:2],
                     z1 if source_side_name == "top" else z0) for p in loop)
              for loop in region)
        for region in orthogonal_end_contact_regions_package_mm
    )
    if orthogonal_end_regions and not require_orthogonal_end_sections:
        raise StructuredSweepMaterializationError(
            "scoped orthogonal end contacts require an outgoing Orth contract"
        )

    if (
        locked_boundary_node_coordinates_package_mm is None
    ) != (locked_boundary_facets_by_geometric_side is None):
        raise StructuredSweepMaterializationError(
            "locked boundary coordinates and facets must be supplied together"
        )
    locked_package_coordinates: dict[int, Point3D] = {}
    locked_local_coordinates: dict[int, Point3D] = {}
    normalized_locked_facets: dict[str, tuple[tuple[int, ...], ...]] = {}
    if locked_boundary_node_coordinates_package_mm is not None:
        if not isinstance(locked_boundary_node_coordinates_package_mm, Mapping) or not isinstance(
            locked_boundary_facets_by_geometric_side, Mapping
        ):
            raise StructuredSweepMaterializationError(
                "locked structured-sweep boundary must be grouped by geometric side"
            )
        for node, point in locked_boundary_node_coordinates_package_mm.items():
            if isinstance(node, bool) or not isinstance(node, int) or node < 1:
                raise StructuredSweepMaterializationError(
                    "locked boundary node IDs must be positive integers"
                )
            locked_package_coordinates[node] = _point3(
                point,
                field_name=f"locked boundary package node {node}",
            )
        for side, raw_group in locked_boundary_facets_by_geometric_side.items():
            if not isinstance(side, str) or not side:
                raise StructuredSweepMaterializationError(
                    "locked boundary geometric side names must be non-empty"
                )
            try:
                group = tuple(tuple(facet) for facet in raw_group)
            except TypeError as error:
                raise StructuredSweepMaterializationError(
                    "locked boundary facets must be TRI3/QUAD4 sequences"
                ) from error
            if any(
                len(facet) not in {3, 4}
                or len(set(facet)) != len(facet)
                or any(
                    isinstance(node, bool)
                    or not isinstance(node, int)
                    or node < 1
                    or node not in locked_package_coordinates
                    for node in facet
                )
                for facet in group
            ):
                raise StructuredSweepMaterializationError(
                    "locked boundary facets must be valid TRI3/QUAD4 values"
                )
            if group:
                normalized_locked_facets[side] = group
        referenced_locked = {
            node
            for facets_on_side in normalized_locked_facets.values()
            for facet in facets_on_side
            for node in facet
        }
        if referenced_locked != set(locked_package_coordinates):
            raise StructuredSweepMaterializationError(
                "locked boundary coordinates must exactly match their facets"
            )
        locked_local_coordinates = {
            node: _to_local(point, canonical_fragment.placement)
            for node, point in locked_package_coordinates.items()
        }

    end_lock_sides = tuple(
        side
        for side in ("bottom", "top")
        if normalized_locked_facets.get(side)
    )
    direct_source_supplied = source_node_coordinates_package_mm is not None
    if end_lock_sides and any(side != source_side_name for side in end_lock_sides):
        raise StructuredSweepMaterializationError(
            "locked end section conflicts with explicit structured sweep "
            f"direction {requested_direction.value!r}: expected "
            f"{source_side_name!r}, got {end_lock_sides!r}"
        )
    if not direct_source_supplied and len(end_lock_sides) > 1:
        raise StructuredSweepMaterializationError(
            "structured sweep requires one inherited end seed, not two independent ends"
        )

    boundary_size_policy = (None if sweep_strategy is None else BoundarySizePolicy(
        sweep_strategy.plane_size_mm, sweep_strategy.plane_transition_distance_mm))
    partial_lateral_locks_verified = False
    try:
        lateral_trace = _prove_lateral_sweep_trace(
            canonical_fragment,
            locked_local_coordinates,
            normalized_locked_facets,
        )
    except StructuredSweepMaterializationError:
        if not allow_partial_lateral_locks:
            raise
        lateral_trace = _prove_partial_lateral_sweep_trace(
            canonical_fragment,
            locked_local_coordinates,
            normalized_locked_facets,
            source_side=source_side_name,
            tolerance=geometry_tolerance,
            target_edge_mm=axial_target, sizing=sizing,
            seed_origin=None if seed_origin is None else seed_origin[2],
        )
        partial_lateral_locks_verified = True
    source_was_inherited = bool(
        direct_source_supplied
        or any(normalized_locked_facets.values())
    )
    complete_inherited_end = False
    if (
        source_node_coordinates_package_mm is None
        and source_facets is None
        and normalized_locked_facets
    ):
        if end_lock_sides:
            original_locked_end_facets = normalized_locked_facets[
                source_side_name
            ]
            source_nodes = {
                node for facet in original_locked_end_facets for node in facet
            }
            locked_end_coordinates = {
                node: locked_local_coordinates[node]
                for node in sorted(source_nodes)
            }
            locked_end_facets = _consistently_oriented_planar_facets(
                locked_end_coordinates,
                original_locked_end_facets,
            )
            try:
                _validate_complete_section(
                    canonical_fragment,
                    locked_end_coordinates,
                    locked_end_facets,
                )
            except StructuredSweepMaterializationError:
                _validate_partial_locked_end_patch(
                    canonical_fragment,
                    locked_end_coordinates,
                    locked_end_facets,
                    source_side_name=source_side_name,
                )
                if require_orthogonal_end_sections:
                    if orthogonal_end_regions:
                        coordinates, facets = _complete_locked_end_with_orthogonal_collar(
                            canonical_fragment, requirement, locked_end_coordinates,
                            locked_end_facets, orthogonal_end_regions,
                            boundary_size_policy=boundary_size_policy,
                            contact_partition_loops=contact_partition_loops,
                            minimum_quality=resolved_quality, verbose=verbose,
                        )
                    else:
                        _validate_inherited_orthogonal_quad_partition(
                            canonical_fragment,
                            locked_end_coordinates,
                            locked_end_facets,
                        )
                        coordinates, facets = _generated_orthogonal_section(
                            canonical_fragment,
                            requirement,
                            lateral_trace,
                            at_top=source_side_name == "top",
                            minimum_quality=resolved_quality,
                            verbose=verbose,
                            locked_end_coordinates=locked_end_coordinates,
                            locked_end_facets=locked_end_facets,
                            contact_partition_loops=contact_partition_loops,
                        )
                else:
                    # QUAD on the locked subregion does not require the whole
                    # completed section to become one Cartesian tensor.  Keep
                    # those QUADs and let Gmsh mesh only the complement with
                    # TRI/QUAD; the extrusion then yields HEX/WEDGE.  The
                    # stricter all-QUAD completion is selected solely for an
                    # actual outgoing Orth consumer.
                    coordinates, facets = _complete_mixed_locked_end_patch(
                        canonical_fragment,
                        requirement,
                        locked_end_coordinates,
                        locked_end_facets,
                        boundary_size_policy=boundary_size_policy,
                        contact_partition_loops=contact_partition_loops,
                        minimum_quality=resolved_quality,
                        verbose=verbose,
                    )
            else:
                # The inherited end already is the complete invariant
                # section.  Preserve its exact mixed TRI/QUAD connectivity;
                # Gmsh's extrusion owns the resulting WEDGE/HEX volume.
                complete_inherited_end = True
                coordinates = dict(locked_end_coordinates)
                facets = tuple(locked_end_facets)
        elif lateral_trace is not None:
            if require_orthogonal_end_sections:
                coordinates, facets = _generated_orthogonal_section(
                    canonical_fragment,
                    requirement,
                    lateral_trace,
                    contact_partition_loops=contact_partition_loops,
                    at_top=source_side_name == "top",
                    minimum_quality=resolved_quality,
                    verbose=verbose,
                )
            else:
                coordinates, facets = _generated_section_from_lateral_trace(
                    canonical_fragment,
                    requirement,
                    locked_local_coordinates,
                    normalized_locked_facets,
                    boundary_size_policy=boundary_size_policy,
                    contact_partition_loops=contact_partition_loops,
                    source_side_name=source_side_name,
                    projected_trace=lateral_trace if partial_lateral_locks_verified else None,
                    minimum_quality=resolved_quality,
                    verbose=verbose,
                )
        else:  # pragma: no cover - guarded by lateral proof validation
            raise StructuredSweepMaterializationError(
                "locked structured-sweep sides do not prove an inherited "
                "complete end or a complete lateral sweep trace"
            )
        package_input_coordinates = {
            node: _to_package(point, canonical_fragment.placement)
            for node, point in coordinates.items()
        }
    elif source_node_coordinates_package_mm is None and source_facets is None:
        section_requirement = requirement
        if (sweep_strategy is not None and sweep_strategy.plane_size_mm is not None
                and not require_orthogonal_end_sections):
            section_requirement = replace(requirement, target_edge_mm=sweep_strategy.plane_size_mm)
        if require_orthogonal_end_sections:
            generated_local_coordinates, facets = _generated_orthogonal_section(
                canonical_fragment,
                section_requirement,
                None,
                contact_partition_loops=contact_partition_loops,
                at_top=source_side_name == "top",
                minimum_quality=resolved_quality,
                verbose=verbose,
            )
        else:
            generated_local_coordinates, facets = _generated_section(
                canonical_fragment,
                section_requirement,
                boundary_size_policy=boundary_size_policy,
                contact_partition_loops=contact_partition_loops,
                at_top=source_side_name == "top",
                verbose=verbose,
            )
        package_input_coordinates = {
            node: _to_package(point, canonical_fragment.placement)
            for node, point in generated_local_coordinates.items()
        }
        coordinates = dict(generated_local_coordinates)
    elif source_node_coordinates_package_mm is None or source_facets is None:
        raise StructuredSweepMaterializationError(
            "source coordinates and facets must be supplied together"
        )
    else:
        if not isinstance(source_node_coordinates_package_mm, Mapping):
            raise StructuredSweepMaterializationError(
                "source package coordinates must be a mapping"
            )
        package_input_coordinates: dict[int, Point3D] = {}
        for node, point in source_node_coordinates_package_mm.items():
            if isinstance(node, bool) or not isinstance(node, int) or node < 1:
                raise StructuredSweepMaterializationError(
                    "source node IDs must be positive integers"
                )
            package_input_coordinates[node] = _point3(
                point,
                field_name=f"source package node {node}",
            )
        try:
            raw_facets = tuple(source_facets)
        except TypeError as error:
            raise StructuredSweepMaterializationError(
                "source facets must be a sequence"
            ) from error
        normalized_facets: list[tuple[int, ...]] = []
        for raw_facet in raw_facets:
            try:
                facet = tuple(raw_facet)
            except TypeError as error:
                raise StructuredSweepMaterializationError(
                    "complete sweep section must contain TRI3/QUAD4 facets"
                ) from error
            if any(
                isinstance(node, bool) or not isinstance(node, int) or node < 1
                for node in facet
            ):
                raise StructuredSweepMaterializationError(
                    "complete sweep section must contain TRI3/QUAD4 facets"
                )
            normalized_facets.append(facet)
        facets = tuple(normalized_facets)
        coordinates = {
            node: _to_local(point, canonical_fragment.placement)
            for node, point in package_input_coordinates.items()
        }
    if not facets or any(len(facet) not in {3, 4} for facet in facets):
        raise StructuredSweepMaterializationError(
            "complete sweep section must contain TRI3/QUAD4 facets"
        )
    referenced = {node for facet in facets for node in facet}
    if referenced != set(coordinates):
        raise StructuredSweepMaterializationError(
            "sweep section coordinates must exactly match its facets"
        )
    expected_z = z1 if source_side_name == "top" else z0
    if any(
        abs(point[2] - expected_z) > coordinate_tolerance
        for point in coordinates.values()
    ):
        raise StructuredSweepMaterializationError(
            "package-frame inherited surface does not transform onto the "
            "selected complete canonical section"
        )
    if orthogonal_end_regions:
        _validate_orthogonal_end_contacts(canonical_fragment, coordinates, facets, orthogonal_end_regions)
    elif require_orthogonal_end_sections and (
        direct_source_supplied or complete_inherited_end
    ):
        _validate_inherited_orthogonal_quad_partition(
            canonical_fragment,
            coordinates,
            facets,
        )
    source_section_area, source_boundary_edge_count = _validate_complete_section(
        canonical_fragment,
        coordinates,
        facets,
    )
    source_tokens = {} if semantic_tokens_by_source_node_id is None else dict(
        semantic_tokens_by_source_node_id
    )
    if direct_source_supplied and set(source_tokens) != set(coordinates):
        raise StructuredSweepMaterializationError(
            "every inherited section node requires one semantic token"
        )
    if not set(source_tokens).issubset(coordinates):
        raise StructuredSweepMaterializationError(
            "sweep semantic token references an unknown source node"
        )
    locked_tokens = (
        {}
        if semantic_tokens_by_locked_node_id is None
        else dict(semantic_tokens_by_locked_node_id)
    )
    if locked_local_coordinates and set(locked_tokens) != set(locked_local_coordinates):
        raise StructuredSweepMaterializationError(
            "every locked boundary node requires one semantic token"
        )
    if not set(locked_tokens).issubset(locked_local_coordinates):
        raise StructuredSweepMaterializationError(
            "locked boundary token references an unknown node"
        )
    all_token_values = (*source_tokens.values(), *locked_tokens.values())
    if (
        any(
            not isinstance(token, str)
            or not token
            or token != token.strip()
            or any(ord(character) < 32 for character in token)
            for token in all_token_values
        )
    ):
        raise StructuredSweepMaterializationError(
            "sweep semantic tokens must be unique canonical strings"
        )
    token_by_coordinate: dict[tuple[int, int, int], str] = {}
    token_coordinate_by_value: dict[str, tuple[int, int, int]] = {}
    for token_coordinates, token_values in (
        (coordinates, source_tokens),
        (locked_local_coordinates, locked_tokens),
    ):
        for node, token in token_values.items():
            key = tuple(
                round(value / coordinate_tolerance)
                for value in token_coordinates[node]
            )
            previous_token = token_by_coordinate.get(key)
            previous_key = token_coordinate_by_value.get(token)
            if (
                previous_token is not None and previous_token != token
            ) or (
                previous_key is not None and previous_key != key
            ):
                raise StructuredSweepMaterializationError(
                    "sweep semantic identity conflicts at a geometric node"
                )
            token_by_coordinate[key] = token
            token_coordinate_by_value[token] = key

    height = z1 - z0
    direction = -height if source_side_name == "top" else height
    if lateral_trace is None:
        anchor = (z1 if source_side_name == "top" else z0) if seed_origin is None else seed_origin[2]
        level_values = interval_levels(z0, z1, axial_target, axial_target, anchor, sizing)
        layer_thicknesses = tuple(b-a for a,b in zip(level_values, level_values[1:]))
        layers = len(layer_thicknesses)
        extrusion_num_elements = [1]*layers
        extrusion_heights = ([(v-z0)/height for v in level_values[1:]]
            if source_side_name == "bottom" else [(z1-v)/height for v in reversed(level_values[:-1])])
    else:
        level_values = lateral_trace.levels_mm
        layer_thicknesses = tuple(
            second - first for first, second in zip(level_values, level_values[1:])
        )
        layers = len(layer_thicknesses)
        extrusion_num_elements = [1] * layers
        if source_side_name == "bottom":
            extrusion_heights = [
                (level - z0) / height for level in level_values[1:]
            ]
        else:
            extrusion_heights = [
                (z1 - level) / height for level in reversed(level_values[:-1])
            ]
    # ``lateral_trace`` levels are immutable.  They may be coarser than the
    # local target and are retained as a measured target override; generated
    # layers use the local target only when no locked axial spacing exists.
    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_structured_sweep",
        number_options={
            "General.Terminal": 1.0 if verbose else 0.0,
            "Mesh.ElementOrder": 1.0,
            "Mesh.Optimize": 0.0,
        },
    ):
        source_surface = int(gmsh.model.addDiscreteEntity(2))
        source_ids = tuple(sorted(coordinates))
        gmsh.model.mesh.addNodes(
            2,
            source_surface,
            source_ids,
            tuple(
                coordinate
                for node in source_ids
                for coordinate in coordinates[node]
            ),
        )
        by_type = {
            2: tuple(facet for facet in facets if len(facet) == 3),
            3: tuple(facet for facet in facets if len(facet) == 4),
        }
        next_element = 1
        for gmsh_type, values in by_type.items():
            if not values:
                continue
            gmsh.model.mesh.addElementsByType(
                source_surface,
                gmsh_type,
                tuple(range(next_element, next_element + len(values))),
                tuple(node for facet in values for node in facet),
            )
            next_element += len(values)
        extrusion_options: dict[str, object] = {
            "numElements": extrusion_num_elements,
            "recombine": True,
        }
        if extrusion_heights is not None:
            extrusion_options["heights"] = extrusion_heights
        gmsh.model.geo.extrude(
            [(2, source_surface)],
            0.0,
            0.0,
            direction,
            **extrusion_options,
        )
        gmsh.model.geo.synchronize()
        gmsh.model.mesh.generate(3)

        raw_node_tags, raw_coordinates, _ = gmsh.model.mesh.getNodes()
        local_coordinates = {
            int(tag): (
                float(raw_coordinates[3 * index]),
                float(raw_coordinates[3 * index + 1]),
                float(raw_coordinates[3 * index + 2]),
            )
            for index, tag in enumerate(raw_node_tags)
        }
        element_rows: list[tuple[int, int, tuple[int, ...]]] = []
        all_tags: list[int] = []
        types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(3)
        for raw_type, raw_tags, raw_connectivity in zip(
            types, tag_blocks, connectivity_blocks
        ):
            gmsh_type = int(raw_type)
            if gmsh_type not in {5, 6}:
                raise StructuredSweepMaterializationError(
                    "Gmsh structured sweep emitted a non-HEX8/WEDGE6 element"
                )
            node_count = ELEMENT_SPECS[gmsh_type][1]
            connectivity = tuple(int(value) for value in raw_connectivity)
            for index, raw_tag in enumerate(raw_tags):
                tag = int(raw_tag)
                all_tags.append(tag)
                element_rows.append(
                    (
                        tag,
                        gmsh_type,
                        connectivity[
                            node_count * index : node_count * index + node_count
                        ],
                    )
                )
        if not element_rows:
            raise StructuredSweepMaterializationError(
                "Gmsh structured sweep returned no volume elements"
            )
        quality_values: dict[str, float] = {}
        for name in ("minDetJac", "minSJ", "minSICN", "minSIGE"):
            values = tuple(
                float(value)
                for value in gmsh.model.mesh.getElementQualities(all_tags, name)
            )
            minimum = min(values, default=0.0)
            failed_floor = (
                minimum <= 0.0
                if name == "minDetJac"
                else minimum < resolved_quality
            )
            if not math.isfinite(minimum) or failed_floor:
                raise StructuredSweepMaterializationError(
                    f"Gmsh structured sweep {name}={minimum:.12g} failed the "
                    f"requested quality floor {resolved_quality:.12g}"
                )
            quality_values[name] = minimum
        volume_values = tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(all_tags, "volume")
        )
        if (
            len(volume_values) != len(element_rows)
            or any(not math.isfinite(value) or value <= 0.0 for value in volume_values)
        ):
            raise StructuredSweepMaterializationError(
                "Gmsh structured sweep returned invalid element volumes"
            )
        element_volume = math.fsum(volume_values)

    expected_element_count = len(facets) * layers
    if len(element_rows) != expected_element_count:
        raise StructuredSweepMaterializationError(
            "Gmsh changed the one-prism-per-source-facet-per-layer sweep topology"
        )
    expected_kind_counts = {
        "WEDGE6": sum(len(facet) == 3 for facet in facets) * layers,
        "HEX8": sum(len(facet) == 4 for facet in facets) * layers,
    }
    actual_kind_counts = Counter(
        "WEDGE6" if gmsh_type == 6 else "HEX8"
        for _tag, gmsh_type, _nodes in element_rows
    )
    if any(actual_kind_counts[kind] != count for kind, count in expected_kind_counts.items()):
        raise StructuredSweepMaterializationError(
            "Gmsh sweep element family no longer matches its source facet family"
        )

    boundary_faces, face_incidence_histogram = _boundary_faces(element_rows)
    boundary: dict[str, list[tuple[int, ...]]] = {}
    for face in boundary_faces:
        side = _classify_face(face, local_coordinates, canonical_fragment)
        boundary.setdefault(side, []).append(face)
    _validate_lateral_rectangular_quads(
        boundary,
        local_coordinates,
        canonical_fragment,
    )

    nodes_by_coordinate: dict[tuple[int, int, int], list[int]] = defaultdict(list)
    for node, point in local_coordinates.items():
        key = tuple(round(value / coordinate_tolerance) for value in point)
        nodes_by_coordinate[key].append(node)
    source_local_by_input: dict[int, int] = {}
    for source_node, expected in coordinates.items():
        key = tuple(round(value / coordinate_tolerance) for value in expected)
        candidates = tuple(
            node
            for node in nodes_by_coordinate.get(key, ())
            if math.dist(local_coordinates[node], expected) <= coordinate_tolerance
        )
        if len(candidates) != 1:
            raise StructuredSweepMaterializationError(
                "Gmsh did not retain one exact volume node per inherited source node"
            )
        source_local_by_input[source_node] = candidates[0]
    if len(set(source_local_by_input.values())) != len(source_local_by_input):
        raise StructuredSweepMaterializationError(
            "Gmsh merged distinct inherited section nodes"
        )
    source_by_local = {
        local_node: source_node
        for source_node, local_node in source_local_by_input.items()
    }
    remapped_source_facets = tuple(
        tuple(source_local_by_input[node] for node in facet)
        for facet in facets
    )
    source_result_facets = tuple(boundary[source_side_name])
    if {_face_key(value) for value in source_result_facets} != {
        _face_key(value) for value in remapped_source_facets
    }:
        expected_source_keys = {
            _face_key(value) for value in remapped_source_facets
        }
        actual_source_keys = {_face_key(value) for value in source_result_facets}
        raise StructuredSweepMaterializationError(
            "Gmsh changed the inherited source section connectivity: "
            f"missing={len(expected_source_keys - actual_source_keys)}, "
            f"unexpected={len(actual_source_keys - expected_source_keys)}"
        )

    opposite_side = "bottom" if source_side_name == "top" else "top"
    destination_z = z0 if source_side_name == "top" else z1
    destination_by_source: dict[int, int] = {}
    for source_node, point in coordinates.items():
        expected = (point[0], point[1], destination_z)
        key = tuple(round(value / coordinate_tolerance) for value in expected)
        candidates = tuple(
            node
            for node in nodes_by_coordinate.get(key, ())
            if math.dist(local_coordinates[node], expected) <= coordinate_tolerance
        )
        if len(candidates) != 1:
            raise StructuredSweepMaterializationError(
                "Gmsh sweep did not retain one translated destination node per source node"
            )
        destination_by_source[source_node] = candidates[0]
    destination_facets = tuple(
        tuple(destination_by_source[node] for node in facet)
        for facet in facets
    )
    destination_result_keys = {
        _face_key(value) for value in boundary[opposite_side]
    }
    if {_face_key(value) for value in destination_facets} != destination_result_keys:
        raise StructuredSweepMaterializationError(
            "Gmsh sweep destination section is not in facet bijection with its source"
        )

    # Preserve the caller's exact facet cycles on both end sections.  The
    # element-face incidence above proves these keys are real boundary faces.
    boundary[source_side_name] = list(remapped_source_facets)
    boundary[opposite_side] = list(destination_facets)

    locked_local_by_input: dict[int, int] = {}
    for locked_node, expected in locked_local_coordinates.items():
        key = tuple(round(value / coordinate_tolerance) for value in expected)
        candidates = tuple(
            node
            for node in nodes_by_coordinate.get(key, ())
            if math.dist(local_coordinates[node], expected) <= coordinate_tolerance
        )
        if len(candidates) != 1:
            raise StructuredSweepMaterializationError(
                "Gmsh extrusion did not retain one exact node per locked boundary node"
            )
        locked_local_by_input[locked_node] = candidates[0]
    remapped_locked: dict[str, list[tuple[int, ...]]] = defaultdict(list)
    if direct_source_supplied:
        remapped_locked[source_side_name].extend(remapped_source_facets)
    for side, locked_facets in normalized_locked_facets.items():
        remapped_locked[side].extend(
            tuple(locked_local_by_input[node] for node in facet)
            for facet in locked_facets
        )
    locked_result: dict[str, tuple[tuple[int, ...], ...]] = {}
    for side, values in sorted(remapped_locked.items()):
        unique: list[tuple[int, ...]] = []
        seen: set[tuple[int, ...]] = set()
        for facet in values:
            key = _face_key(facet)
            if key in seen:
                continue
            seen.add(key)
            unique.append(facet)
        boundary_keys = {_face_key(facet) for facet in boundary.get(side, ())}
        if seen != seen.intersection(boundary_keys):
            raise StructuredSweepMaterializationError(
                f"Gmsh extrusion changed locked {side!r} boundary connectivity"
            )
        locked_result[side] = tuple(unique)

    lateral_boundary_face_count = sum(
        len(values)
        for side, values in boundary.items()
        if side not in {source_side_name, opposite_side}
    )
    expected_lateral_count = source_boundary_edge_count * layers
    if lateral_boundary_face_count != expected_lateral_count:
        raise StructuredSweepMaterializationError(
            "structured sweep deleted or duplicated a peripheral boundary facet"
        )
    expected_boundary_count = 2 * len(facets) + expected_lateral_count
    if len(boundary_faces) != expected_boundary_count:
        raise StructuredSweepMaterializationError(
            "structured sweep boundary-face incidence is incomplete"
        )

    analytic_volume = source_section_area * height
    relative_volume_error = abs(element_volume - analytic_volume) / analytic_volume
    if relative_volume_error > 1.0e-9:
        raise StructuredSweepMaterializationError(
            "structured sweep element volume does not equal analytic swept volume"
        )
    package_coordinates = {
        node: _to_package(point, canonical_fragment.placement)
        for node, point in local_coordinates.items()
    }
    fragment = ComponentLocalMeshFragment(
        canonical_fragment.fragment_id if fragment_key is None else fragment_key,
        requirement.component_id,
        material_name,
        tuple(
            ComponentMeshNode(
                node,
                package_coordinates[node],
                token_by_coordinate.get(
                    tuple(
                        round(value / coordinate_tolerance)
                        for value in local_coordinates[node]
                    )
                ),
            )
            for node in sorted(package_coordinates)
        ),
        tuple(
            ComponentMeshElement(tag, gmsh_type, nodes, provenance)
            for tag, gmsh_type, nodes in sorted(element_rows)
        ),
    )
    counts = Counter(element.kind.value for element in fragment.elements)
    return StructuredSweepComponentMesh(
        canonical_fragment=canonical_fragment,
        requirement=requirement,
        source_side_name=source_side_name,
        component_fragment=fragment,
        locked_facets_by_geometric_side=MappingProxyType(
            locked_result
        ),
        boundary_facets_by_geometric_side=MappingProxyType(
            {
                side: tuple(values)
                for side, values in sorted(boundary.items())
            }
        ),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        destination_node_id_by_source_node_id=MappingProxyType(
            destination_by_source
        ),
        source_facets=remapped_source_facets,
        destination_facets=destination_facets,
        element_counts=MappingProxyType(dict(sorted(counts.items()))),
        face_incidence_histogram=face_incidence_histogram,
        source_was_inherited=source_was_inherited,
        layer_count=layers,
        layer_thicknesses_mm=layer_thicknesses,
        source_section_area_mm2=source_section_area,
        analytic_volume_mm3=analytic_volume,
        element_volume_mm3=element_volume,
        relative_volume_error=relative_volume_error,
        boundary_face_count=len(boundary_faces),
        internal_face_count=face_incidence_histogram.get(2, 0),
        source_boundary_edge_count=source_boundary_edge_count,
        lateral_boundary_face_count=lateral_boundary_face_count,
        source_facet_preserved_count=len(source_result_facets),
        destination_facet_correspondence_count=len(destination_facets),
        minimum_determinant=quality_values["minDetJac"],
        minimum_sicn=quality_values["minSICN"],
        minimum_sige=quality_values["minSIGE"],
        minimum_scaled_jacobian=quality_values["minSJ"],
        partial_lateral_locks_verified=partial_lateral_locks_verified,
    )


__all__ = [
    "StructuredSweepComponentMesh",
    "StructuredSweepMaterializationError",
    "materialize_structured_sweep_component",
]
