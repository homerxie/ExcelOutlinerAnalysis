"""Canonical package-assembly ownership and interface policy records.

This module is deliberately independent of :mod:`easymesh.package_builder`
and Gmsh.  It defines the immutable policy boundary needed before a general
package assembler can be implemented:

* typed template parameters and derived expressions resolve to immutable,
  canonical millimetre/dimensionless values before geometry is compiled;
* flat generated geometry records compile into explicit control components;
* imported sources are frozen as complete sources, never as tag ranges;
* the only coupling is a conformal shared-node interface;
* a complete frozen source may supply an immutable interface trace; source
  nodes and elements are never moved, copied, or propagated into a generated
  target; and
* internal interface resolution never exposes a user-facing ``AUTO`` mode.

All strategy directions and partition origins are expressed in the generated
component's local, right-handed X/Y/Z frame.  Lengths are normalized to
millimetres.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import io
import keyword
import math
import tokenize
from types import MappingProxyType
from typing import Mapping, Sequence, TypeAlias

from .package_v2_mesh_sizing import MeshSeedPolicy

from .package_spec import ScalarExpression


class AssemblyPolicyError(ValueError):
    """Raised when an assembly policy is ambiguous or internally inconsistent."""


def _name(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AssemblyPolicyError(f"{field_name} must be a non-empty string")
    return value.strip()


def _tuple(value: object, *, field_name: str) -> tuple[object, ...]:
    if isinstance(value, (str, bytes)):
        raise AssemblyPolicyError(f"{field_name} must be a sequence")
    try:
        return tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise AssemblyPolicyError(f"{field_name} must be a sequence") from error


TemplateScalar: TypeAlias = float | int | str
_TEMPLATE_UNIT_NAMES = frozenset(
    {"mm", "um", "\N{MICRO SIGN}m", "\N{GREEK SMALL LETTER MU}m"}
)
_SCALAR_EXPRESSION_HELPER = "__easymesh_length__"
_MAX_TEMPLATE_EXPRESSION_CHARACTERS = 4096
_MAX_TEMPLATE_EXPRESSION_TOKENS = 512
_TEMPLATE_RANGE_REL_TOLERANCE = 1.0e-12
_TEMPLATE_RANGE_ABS_TOLERANCE = 1.0e-15


class TemplateDimension(str, Enum):
    """Physical dimensions supported by the V2 template kernel."""

    LENGTH = "length"
    DIMENSIONLESS = "dimensionless"

    @property
    def length_power(self) -> int:
        return 1 if self is TemplateDimension.LENGTH else 0


class TemplateValueSource(str, Enum):
    """Why one canonical template value was selected."""

    DEFAULT = "default"
    OVERRIDE = "override"
    DERIVED = "derived"


def _template_dimension(value: object, *, field_name: str) -> TemplateDimension:
    if isinstance(value, TemplateDimension):
        return value
    if isinstance(value, str):
        try:
            return TemplateDimension(value)
        except ValueError as error:
            raise AssemblyPolicyError(
                f"{field_name} must be 'length' or 'dimensionless'"
            ) from error
    raise AssemblyPolicyError(f"{field_name} must be a TemplateDimension")


def _template_identifier(value: object, *, field_name: str) -> str:
    name = _name(value, field_name=field_name)
    if (
        not name.isascii()
        or not name.isidentifier()
        or keyword.iskeyword(name)
        or name.lower() in _TEMPLATE_UNIT_NAMES
        or name == _SCALAR_EXPRESSION_HELPER
    ):
        raise AssemblyPolicyError(
            f"{field_name} must be a non-reserved ASCII identifier"
        )
    return name


def _template_scalar(value: object, *, field_name: str) -> TemplateScalar:
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise AssemblyPolicyError(
            f"{field_name} must be a numeric value or scalar expression"
        )
    if isinstance(value, str) and not value.strip():
        raise AssemblyPolicyError(f"{field_name} must not be blank")
    return value


@dataclass(frozen=True, slots=True)
class TemplateParameter:
    """One independent input with an optional dependency-free default.

    Numeric length literals are already canonical millimetres.  String length
    expressions must carry units.  Defaults and range bounds may use the safe
    scalar operators but are deliberately dependency-free; cross-variable
    expressions belong in
    :class:`DerivedVariable`.
    """

    name: str
    dimension: TemplateDimension
    default: TemplateScalar | None = None
    minimum: TemplateScalar | None = None
    maximum: TemplateScalar | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "name",
            _template_identifier(self.name, field_name="template parameter name"),
        )
        object.__setattr__(
            self,
            "dimension",
            _template_dimension(
                self.dimension,
                field_name=f"template parameter {self.name!r} dimension",
            ),
        )
        for field_name in ("default", "minimum", "maximum"):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(
                    self,
                    field_name,
                    _template_scalar(
                        value,
                        field_name=f"template parameter {self.name!r} {field_name}",
                    ),
                )

    @property
    def required(self) -> bool:
        return self.default is None


@dataclass(frozen=True, slots=True)
class DerivedVariable:
    """One dimensioned expression derived from parameters or other variables.

    ``expression_source`` is retained exactly as supplied.  Evaluation uses a
    separate token-substituted string and never mutates this audit source.
    """

    name: str
    dimension: TemplateDimension
    expression_source: str
    minimum: TemplateScalar | None = None
    maximum: TemplateScalar | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "name",
            _template_identifier(self.name, field_name="derived variable name"),
        )
        object.__setattr__(
            self,
            "dimension",
            _template_dimension(
                self.dimension,
                field_name=f"derived variable {self.name!r} dimension",
            ),
        )
        if not isinstance(self.expression_source, str) or not self.expression_source.strip():
            raise AssemblyPolicyError(
                f"derived variable {self.name!r} expression_source must not be blank"
            )
        for field_name in ("minimum", "maximum"):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(
                    self,
                    field_name,
                    _template_scalar(
                        value,
                        field_name=f"derived variable {self.name!r} {field_name}",
                    ),
                )


@dataclass(frozen=True, slots=True)
class ResolvedTemplateValue:
    """One finite canonical value in millimetres or dimensionless units."""

    name: str
    dimension: TemplateDimension
    value: float
    source: TemplateValueSource

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "name",
            _template_identifier(self.name, field_name="resolved template value name"),
        )
        object.__setattr__(
            self,
            "dimension",
            _template_dimension(
                self.dimension,
                field_name=f"resolved template value {self.name!r} dimension",
            ),
        )
        if isinstance(self.value, bool):
            raise AssemblyPolicyError("resolved template values must be finite")
        try:
            value = float(self.value)
        except (OverflowError, TypeError, ValueError) as error:
            raise AssemblyPolicyError(
                "resolved template values must be finite"
            ) from error
        if not math.isfinite(value):
            raise AssemblyPolicyError("resolved template values must be finite")
        object.__setattr__(self, "value", value)
        if isinstance(self.source, str) and not isinstance(
            self.source, TemplateValueSource
        ):
            try:
                object.__setattr__(self, "source", TemplateValueSource(self.source))
            except ValueError as error:
                raise AssemblyPolicyError(
                    "resolved value source must be default, override, or derived"
                ) from error
        if not isinstance(self.source, TemplateValueSource):
            raise AssemblyPolicyError("source must be a TemplateValueSource")

    @property
    def canonical_unit(self) -> str:
        return "mm" if self.dimension is TemplateDimension.LENGTH else "number"


@dataclass(frozen=True, slots=True)
class ResolvedTemplateParameters:
    """Immutable resolved template values in declaration order."""

    values: tuple[ResolvedTemplateValue, ...]

    def __post_init__(self) -> None:
        raw_values = _tuple(self.values, field_name="resolved template values")
        if any(not isinstance(value, ResolvedTemplateValue) for value in raw_values):
            raise AssemblyPolicyError(
                "resolved template values must contain ResolvedTemplateValue entries"
            )
        values = tuple(raw_values)
        names = tuple(value.name for value in values)
        if len(set(names)) != len(names):
            raise AssemblyPolicyError("resolved template value names must be unique")
        object.__setattr__(self, "values", values)

    @property
    def by_name(self) -> Mapping[str, ResolvedTemplateValue]:
        return MappingProxyType({value.name: value for value in self.values})

    @property
    def canonical_values(self) -> Mapping[str, float]:
        return MappingProxyType({value.name: value.value for value in self.values})

    def __getitem__(self, name: str) -> ResolvedTemplateValue:
        return self.by_name[name]

    def evaluate_expression(
        self,
        expression_source: str,
        *,
        dimension: TemplateDimension,
        field_name: str = "template expression",
    ) -> float:
        """Evaluate a geometry scalar against this immutable resolved table."""

        resolved_dimension = _template_dimension(
            dimension,
            field_name=f"{field_name} dimension",
        )
        return _resolved_expression_value(
            expression_source,
            resolved_dimension,
            self.by_name,
            field_name=field_name,
        )


@dataclass(frozen=True, slots=True)
class _ExpressionScan:
    names: frozenset[str]
    token_error: str | None


def _scan_expression_names(source: str) -> _ExpressionScan:
    """Collect complete Python NAME tokens without evaluating the expression."""

    if len(source) > _MAX_TEMPLATE_EXPRESSION_CHARACTERS:
        return _ExpressionScan(
            frozenset(),
            "expression exceeds the 4096-character limit",
        )
    names: set[str] = set()
    token_error: str | None = None
    try:
        tokens = tokenize.generate_tokens(io.StringIO(source).readline)
        for token_index, token in enumerate(tokens, start=1):
            if token_index > _MAX_TEMPLATE_EXPRESSION_TOKENS:
                token_error = "expression exceeds the 512-token limit"
                break
            if (
                token.type == tokenize.NAME
                and token.string.lower() not in _TEMPLATE_UNIT_NAMES
            ):
                names.add(token.string)
    except (tokenize.TokenError, IndentationError, SyntaxError) as error:
        token_error = str(error)
    return _ExpressionScan(frozenset(names), token_error)


def _dependency_free_value(
    raw_value: TemplateScalar,
    dimension: TemplateDimension,
    *,
    field_name: str,
) -> float:
    """Resolve one dependency-free scalar through ScalarExpression."""

    if isinstance(raw_value, bool):  # Defensive for internal callers.
        raise AssemblyPolicyError(f"{field_name} must be finite")
    if isinstance(raw_value, (int, float)):
        try:
            value = float(raw_value)
        except (OverflowError, TypeError, ValueError) as error:
            raise AssemblyPolicyError(f"{field_name} must be finite") from error
        if not math.isfinite(value):
            raise AssemblyPolicyError(f"{field_name} must be finite")
        return value

    scan = _scan_expression_names(raw_value)
    if scan.names:
        raise AssemblyPolicyError(
            f"{field_name} must be dependency-free; unknown variable "
            f"{sorted(scan.names)[0]!r}"
        )
    if scan.token_error is not None:
        raise AssemblyPolicyError(
            f"{field_name} is not a valid scalar expression: {scan.token_error}"
        )
    try:
        expression = ScalarExpression.parse(
            raw_value,
            allowed_names=(),
            expected_length_power=dimension.length_power,
            field_name=field_name,
        )
        value = expression.evaluate()
    except OverflowError as error:
        raise AssemblyPolicyError(f"{field_name} must be finite") from error
    except RecursionError as error:
        raise AssemblyPolicyError(
            f"{field_name} exceeds the expression complexity limit"
        ) from error
    except ValueError as error:
        raise AssemblyPolicyError(f"invalid {field_name}: {error}") from error
    if not math.isfinite(value):  # ScalarExpression also enforces this.
        raise AssemblyPolicyError(f"{field_name} must be finite")
    return value


def _substitute_resolved_names(
    source: str,
    resolved: Mapping[str, ResolvedTemplateValue],
) -> str:
    """Replace only exact NAME tokens with dimension-carrying literals."""

    rewritten: list[tuple[int, str]] = []
    try:
        tokens = tokenize.generate_tokens(io.StringIO(source).readline)
        for token in tokens:
            value = resolved.get(token.string) if token.type == tokenize.NAME else None
            if value is None:
                rewritten.append((token.type, token.string))
                continue
            literal = format(value.value, ".17g")
            if value.dimension is TemplateDimension.LENGTH:
                literal = f"{literal}mm"
            else:
                # ScalarExpression deliberately treats a bare numeric zero as
                # dimension-neutral so expressions such as ``length + 0`` are
                # convenient.  A resolved dimensionless *variable* is not a
                # dimension-neutral literal, however.  Multiplying by an
                # explicit unit ratio preserves length power zero even when
                # the variable's current value is exactly zero.
                literal = f"{literal}*(1mm/1mm)"
            rewritten.append((tokenize.NUMBER, f"({literal})"))
    except (tokenize.TokenError, IndentationError, SyntaxError) as error:
        raise AssemblyPolicyError(
            f"cannot tokenize derived expression: {error}"
        ) from error
    return tokenize.untokenize(rewritten).strip()


def _resolved_expression_value(
    source: str,
    dimension: TemplateDimension,
    resolved: Mapping[str, ResolvedTemplateValue],
    *,
    field_name: str,
) -> float:
    """Evaluate one typed expression through the shared ScalarExpression API."""

    if not isinstance(source, str) or not source.strip():
        raise AssemblyPolicyError(f"{field_name} must not be blank")
    scan = _scan_expression_names(source)
    unknown = sorted(scan.names.difference(resolved))
    if unknown:
        raise AssemblyPolicyError(
            f"{field_name} references unknown variable {unknown[0]!r}"
        )
    if scan.token_error is not None:
        raise AssemblyPolicyError(
            f"{field_name} is not a valid scalar expression: {scan.token_error}"
        )
    substituted = _substitute_resolved_names(source, resolved)
    try:
        expression = ScalarExpression.parse(
            substituted,
            allowed_names=(),
            expected_length_power=dimension.length_power,
            field_name=field_name,
        )
        value = expression.evaluate()
    except OverflowError as error:
        raise AssemblyPolicyError(f"{field_name} must be finite") from error
    except RecursionError as error:
        raise AssemblyPolicyError(
            f"{field_name} exceeds the expression complexity limit"
        ) from error
    except ValueError as error:
        raise AssemblyPolicyError(f"invalid {field_name}: {error}") from error
    if not math.isfinite(value):
        raise AssemblyPolicyError(f"{field_name} must be finite")
    return value


def _range_bounds(
    dimension: TemplateDimension,
    minimum: TemplateScalar | None,
    maximum: TemplateScalar | None,
    *,
    field_name: str,
) -> tuple[float | None, float | None]:
    lower = (
        None
        if minimum is None
        else _dependency_free_value(
            minimum,
            dimension,
            field_name=f"{field_name} minimum",
        )
    )
    upper = (
        None
        if maximum is None
        else _dependency_free_value(
            maximum,
            dimension,
            field_name=f"{field_name} maximum",
        )
    )
    if (
        lower is not None
        and upper is not None
        and lower > upper
        and not math.isclose(
            lower,
            upper,
            rel_tol=_TEMPLATE_RANGE_REL_TOLERANCE,
            abs_tol=_TEMPLATE_RANGE_ABS_TOLERANCE,
        )
    ):
        raise AssemblyPolicyError(f"{field_name} minimum exceeds maximum")
    return lower, upper


def _validated_range(
    value: float,
    dimension: TemplateDimension,
    minimum: TemplateScalar | None,
    maximum: TemplateScalar | None,
    *,
    field_name: str,
) -> None:
    lower, upper = _range_bounds(
        dimension,
        minimum,
        maximum,
        field_name=field_name,
    )
    if (
        lower is not None
        and value < lower
        and not math.isclose(
            value,
            lower,
            rel_tol=_TEMPLATE_RANGE_REL_TOLERANCE,
            abs_tol=_TEMPLATE_RANGE_ABS_TOLERANCE,
        )
    ):
        raise AssemblyPolicyError(f"{field_name} is below its minimum")
    if (
        upper is not None
        and value > upper
        and not math.isclose(
            value,
            upper,
            rel_tol=_TEMPLATE_RANGE_REL_TOLERANCE,
            abs_tol=_TEMPLATE_RANGE_ABS_TOLERANCE,
        )
    ):
        raise AssemblyPolicyError(f"{field_name} is above its maximum")


def _dependency_cycle_path(
    pending_names: Sequence[str],
    dependencies: Mapping[str, frozenset[str]],
) -> tuple[str, ...]:
    """Return one stable derived-variable cycle without recursive traversal."""

    ordered = tuple(pending_names)
    pending = frozenset(ordered)
    rank = {name: index for index, name in enumerate(ordered)}
    state: dict[str, int] = {}
    for start in ordered:
        if state.get(start, 0) != 0:
            continue
        state[start] = 1
        node_stack = [start]
        iterator_stack = [
            iter(sorted(dependencies[start].intersection(pending), key=rank.get))
        ]
        active_index = {start: 0}
        while node_stack:
            try:
                neighbor = next(iterator_stack[-1])
            except StopIteration:
                finished = node_stack.pop()
                iterator_stack.pop()
                active_index.pop(finished, None)
                state[finished] = 2
                continue
            neighbor_state = state.get(neighbor, 0)
            if neighbor_state == 0:
                state[neighbor] = 1
                active_index[neighbor] = len(node_stack)
                node_stack.append(neighbor)
                iterator_stack.append(
                    iter(
                        sorted(
                            dependencies[neighbor].intersection(pending),
                            key=rank.get,
                        )
                    )
                )
                continue
            if neighbor_state == 1:
                cycle_start = active_index[neighbor]
                return tuple((*node_stack[cycle_start:], neighbor))
    return ()


def resolve_template_parameters(
    parameters: Sequence[TemplateParameter],
    derived_variables: Sequence[DerivedVariable] = (),
    overrides: Mapping[str, TemplateScalar] | None = None,
) -> ResolvedTemplateParameters:
    """Resolve defaults, instance overrides, and derived expressions safely."""

    raw_parameters = _tuple(parameters, field_name="template parameters")
    raw_derived = _tuple(derived_variables, field_name="derived variables")
    if any(not isinstance(value, TemplateParameter) for value in raw_parameters):
        raise AssemblyPolicyError(
            "template parameters must contain TemplateParameter values"
        )
    if any(not isinstance(value, DerivedVariable) for value in raw_derived):
        raise AssemblyPolicyError(
            "derived variables must contain DerivedVariable values"
        )
    parameter_values = tuple(raw_parameters)
    derived_values = tuple(raw_derived)
    all_names = tuple(value.name for value in (*parameter_values, *derived_values))
    if len(set(all_names)) != len(all_names):
        duplicate = next(name for name in all_names if all_names.count(name) > 1)
        raise AssemblyPolicyError(f"duplicate template variable name {duplicate!r}")
    known_names = frozenset(all_names)
    derived_names = frozenset(value.name for value in derived_values)

    # Definition validity is independent of an instance's overrides.  A bad
    # default or range must not become invisible merely because one instance
    # happens to replace that parameter.
    for parameter in parameter_values:
        _range_bounds(
            parameter.dimension,
            parameter.minimum,
            parameter.maximum,
            field_name=f"template parameter {parameter.name!r}",
        )
        if parameter.default is not None:
            default_value = _dependency_free_value(
                parameter.default,
                parameter.dimension,
                field_name=f"template parameter {parameter.name!r} default",
            )
            _validated_range(
                default_value,
                parameter.dimension,
                parameter.minimum,
                parameter.maximum,
                field_name=f"template parameter {parameter.name!r} default",
            )
    for derived in derived_values:
        _range_bounds(
            derived.dimension,
            derived.minimum,
            derived.maximum,
            field_name=f"derived variable {derived.name!r}",
        )

    if overrides is None:
        raw_overrides: Mapping[object, object] = {}
    elif isinstance(overrides, Mapping):
        raw_overrides = overrides
    else:
        raise AssemblyPolicyError("template overrides must be a mapping")
    normalized_overrides: dict[str, TemplateScalar] = {}
    for raw_name, raw_value in raw_overrides.items():
        name = _template_identifier(raw_name, field_name="template override name")
        if name in normalized_overrides:
            raise AssemblyPolicyError(f"duplicate template override {name!r}")
        normalized_overrides[name] = _template_scalar(
            raw_value,
            field_name=f"template override {name!r}",
        )
    overridden_derived = sorted(derived_names.intersection(normalized_overrides))
    if overridden_derived:
        raise AssemblyPolicyError(
            f"derived variable {overridden_derived[0]!r} cannot be overridden"
        )
    unknown_overrides = sorted(set(normalized_overrides).difference(known_names))
    if unknown_overrides:
        raise AssemblyPolicyError(
            f"unknown template override {unknown_overrides[0]!r}"
        )

    scans: dict[str, _ExpressionScan] = {
        value.name: _scan_expression_names(value.expression_source)
        for value in derived_values
    }
    for value in derived_values:
        unknown = sorted(scans[value.name].names.difference(known_names))
        if unknown:
            raise AssemblyPolicyError(
                f"derived variable {value.name!r} references unknown variable "
                f"{unknown[0]!r}"
            )
    for value in derived_values:
        token_error = scans[value.name].token_error
        if token_error is not None:
            raise AssemblyPolicyError(
                f"derived variable {value.name!r} has an invalid expression: "
                f"{token_error}"
            )

    dependency_names = {
        value.name: scans[value.name].names.intersection(derived_names)
        for value in derived_values
    }
    pending = list(derived_values)
    evaluation_order: list[DerivedVariable] = []
    available = {value.name for value in parameter_values}
    while pending:
        next_index = next(
            (
                index
                for index, value in enumerate(pending)
                if dependency_names[value.name].issubset(available)
            ),
            None,
        )
        if next_index is None:
            cycle = _dependency_cycle_path(
                tuple(value.name for value in pending),
                dependency_names,
            )
            cycle_names = " -> ".join(cycle)
            raise AssemblyPolicyError(
                f"derived variable dependency cycle: {cycle_names}"
            )
        value = pending.pop(next_index)
        evaluation_order.append(value)
        available.add(value.name)

    resolved: dict[str, ResolvedTemplateValue] = {}
    for parameter in parameter_values:
        if parameter.name in normalized_overrides:
            raw_value = normalized_overrides[parameter.name]
            source = TemplateValueSource.OVERRIDE
        elif parameter.default is not None:
            raw_value = parameter.default
            source = TemplateValueSource.DEFAULT
        else:
            raise AssemblyPolicyError(
                f"required template parameter {parameter.name!r} is missing"
            )
        value = _dependency_free_value(
            raw_value,
            parameter.dimension,
            field_name=f"template parameter {parameter.name!r}",
        )
        _validated_range(
            value,
            parameter.dimension,
            parameter.minimum,
            parameter.maximum,
            field_name=f"template parameter {parameter.name!r}",
        )
        resolved[parameter.name] = ResolvedTemplateValue(
            parameter.name,
            parameter.dimension,
            value,
            source,
        )

    for derived in evaluation_order:
        value = _resolved_expression_value(
            derived.expression_source,
            derived.dimension,
            resolved,
            field_name=f"derived variable {derived.name!r}",
        )
        _validated_range(
            value,
            derived.dimension,
            derived.minimum,
            derived.maximum,
            field_name=f"derived variable {derived.name!r}",
        )
        resolved[derived.name] = ResolvedTemplateValue(
            derived.name,
            derived.dimension,
            value,
            TemplateValueSource.DERIVED,
        )

    output_order = tuple(value.name for value in (*parameter_values, *derived_values))
    return ResolvedTemplateParameters(
        tuple(resolved[name] for name in output_order)
    )


class ComponentKind(str, Enum):
    """Whether a component is generated locally or imported without mutation."""

    GENERATED = "generated"
    FROZEN = "frozen"


class GeometryRecordKind(str, Enum):
    """Flat positive-geometry ownership records."""

    START_COMPONENT = "START_COMPONENT"
    APPEND_GEOMETRY = "APPEND_GEOMETRY"


class GeneratedComponentVolumeTopology(str, Enum):
    """Explicit, component-local volume meshing topology policy.

    The tokens deliberately describe generic algorithms and element families;
    they do not encode a geometry kind, material, or Component name.
    ``ORTHOGONAL_HEX`` means axis-aligned HEX8 whose corners are right angles;
    the three edge lengths need not be equal and a stair-step boundary may
    approximate non-orthogonal geometry.
    """

    ORTHOGONAL_HEX = "orthogonal_hex"
    STRUCTURED_SWEEP = "structured_sweep"
    CONFORMAL_HYBRID = "conformal_hybrid"


class ComponentLocalDirection(str, Enum):
    """One signed direction in a generated Component's local frame."""

    POSITIVE_X = "positive_x"
    NEGATIVE_X = "negative_x"
    POSITIVE_Y = "positive_y"
    NEGATIVE_Y = "negative_y"
    POSITIVE_Z = "positive_z"
    NEGATIVE_Z = "negative_z"


COMPONENT_LOCAL_DIRECTIONS = tuple(ComponentLocalDirection)


def _positive_finite_length(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise AssemblyPolicyError(f"{field_name} must be a positive finite length")
    try:
        number = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise AssemblyPolicyError(
            f"{field_name} must be a positive finite length"
        ) from error
    if not math.isfinite(number) or number <= 0.0:
        raise AssemblyPolicyError(f"{field_name} must be a positive finite length")
    return number


def _validate_strategy_sizing(strategy):
    if type(strategy.sizing) is not MeshSeedPolicy:
        raise AssemblyPolicyError("sizing must be a MeshSeedPolicy")
    if strategy.sizing.origin == "custom" and strategy.partition_origin_mm is None:
        raise AssemblyPolicyError("custom origin requires partition_origin")
    for field_name in ("plane_size_mm", "layer_size_mm", "plane_transition_distance_mm"):
        value = getattr(strategy, field_name, None)
        if value is not None:
            _positive_finite_length(value, field_name=field_name)
    if strategy.partition_origin_mm is not None:
        object.__setattr__(strategy, "partition_origin_mm", _finite_point3(
            strategy.partition_origin_mm, field_name="partition_origin_mm"
        ))


@dataclass(frozen=True, slots=True)
class StructuredSweepMeshStrategy:
    """Directed sweep selected explicitly in one Component-local frame.

    ``direction`` is authoritative: its axis is the translation-invariant
    section normal, its negative endpoint is the source for a positive
    direction, and its positive endpoint is the source for a negative
    direction.  Executors must never infer or reverse it from package roles,
    adjacency order, or the location of an available contact patch.
    """

    direction: ComponentLocalDirection
    sizing: MeshSeedPolicy = field(default_factory=MeshSeedPolicy, kw_only=True)
    plane_size_mm: float | None = field(default=None, kw_only=True)
    plane_transition_distance_mm: float | None = field(default=None, kw_only=True)
    layer_size_mm: float | None = field(default=None, kw_only=True)
    partition_origin_mm: tuple[float, float, float] | None = field(default=None, kw_only=True)

    kind: GeneratedComponentVolumeTopology = field(
        default=GeneratedComponentVolumeTopology.STRUCTURED_SWEEP,
        init=False,
    )

    def __post_init__(self) -> None:
        try:
            direction = (
                self.direction
                if isinstance(self.direction, ComponentLocalDirection)
                else ComponentLocalDirection(self.direction)
            )
        except (TypeError, ValueError) as error:
            raise AssemblyPolicyError(
                "structured sweep direction must be one Component-local "
                "signed axis"
            ) from error
        object.__setattr__(self, "direction", direction)
        _validate_strategy_sizing(self)


@dataclass(frozen=True, slots=True)
class ConformalHybridMeshStrategy:
    """Gmsh-owned conformal hybrid strategy for one generated Component."""

    surface_size_mm: float | None = None

    def __post_init__(self):
        if self.surface_size_mm is not None:
            _positive_finite_length(self.surface_size_mm, field_name="surface_size_mm")

    kind: GeneratedComponentVolumeTopology = field(
        default=GeneratedComponentVolumeTopology.CONFORMAL_HYBRID,
        init=False,
    )


def _finite_point3(
    value: object,
    *,
    field_name: str,
) -> tuple[float, float, float]:
    if isinstance(value, (str, bytes)):
        raise AssemblyPolicyError(f"{field_name} must contain exactly three numbers")
    try:
        raw = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise AssemblyPolicyError(
            f"{field_name} must contain exactly three numbers"
        ) from error
    if len(raw) != 3:
        raise AssemblyPolicyError(f"{field_name} must contain exactly three numbers")
    output: list[float] = []
    for index, item in enumerate(raw):
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            raise AssemblyPolicyError(f"{field_name}[{index}] must be finite")
        number = float(item)
        if not math.isfinite(number):
            raise AssemblyPolicyError(f"{field_name}[{index}] must be finite")
        output.append(0.0 if number == 0.0 else number)
    return tuple(output)  # type: ignore[return-value]


@dataclass(frozen=True, slots=True)
class OrthogonalHexMeshStrategy:
    """Canonical Orth sizing and optional local partition anchor.

    ``directional_near_edge_mm`` is complete: the compiler expands every
    omitted authored direction to the Component's ``target_edge_mm``.  These
    values size only newly generated cells leaving a constraint/anchor; an
    immutable interface trace remains authoritative in its tangential axes.
    ``partition_origin_mm`` remains active on each axis not fixed by an
    inherited interface. The sizing policy controls only newly generated cells.
    """

    directional_near_edge_mm: Mapping[ComponentLocalDirection, float]
    partition_origin_mm: tuple[float, float, float] | None = None
    sizing: MeshSeedPolicy = field(default_factory=MeshSeedPolicy, kw_only=True)
    kind: GeneratedComponentVolumeTopology = field(
        default=GeneratedComponentVolumeTopology.ORTHOGONAL_HEX,
        init=False,
    )

    def validate_single_box_sizes(self) -> None:
        """Opposite directions may use different steps around a shared origin."""

    def __post_init__(self) -> None:
        _validate_strategy_sizing(self)
        if not isinstance(self.directional_near_edge_mm, Mapping):
            raise AssemblyPolicyError(
                "orthogonal directional_near_edge_mm must be a mapping"
            )
        resolved: dict[ComponentLocalDirection, float] = {}
        for raw_direction, raw_size in self.directional_near_edge_mm.items():
            try:
                direction = (
                    raw_direction
                    if isinstance(raw_direction, ComponentLocalDirection)
                    else ComponentLocalDirection(raw_direction)
                )
            except (TypeError, ValueError) as error:
                raise AssemblyPolicyError(
                    "orthogonal directional near-edge direction is invalid"
                ) from error
            if direction in resolved:
                raise AssemblyPolicyError(
                    "orthogonal directional near-edge direction is duplicated"
                )
            resolved[direction] = _positive_finite_length(
                raw_size,
                field_name=(
                    "orthogonal directional near edge " f"{direction.value}"
                ),
            )
        expected = set(COMPONENT_LOCAL_DIRECTIONS)
        if set(resolved) != expected:
            missing = ", ".join(
                direction.value
                for direction in COMPONENT_LOCAL_DIRECTIONS
                if direction not in resolved
            )
            raise AssemblyPolicyError(
                "orthogonal directional_near_edge_mm must resolve every "
                f"component-local direction; missing: {missing}"
            )
        object.__setattr__(
            self,
            "directional_near_edge_mm",
            MappingProxyType(
                {
                    direction: resolved[direction]
                    for direction in COMPONENT_LOCAL_DIRECTIONS
                }
            ),
        )
        if self.partition_origin_mm is not None:
            object.__setattr__(
                self,
                "partition_origin_mm",
                _finite_point3(
                    self.partition_origin_mm,
                    field_name="orthogonal partition_origin_mm",
                ),
            )


GeneratedComponentMeshStrategy: TypeAlias = (
    StructuredSweepMeshStrategy
    | OrthogonalHexMeshStrategy
    | ConformalHybridMeshStrategy
)


@dataclass(frozen=True, slots=True)
class GeneratedComponentMeshControl:
    """Explicit high-level sizing owned by one generated Component.

    No production default is implied.  ``None`` on :class:`Component` means
    the source did not specify a worker-ready size profile.
    """

    target_edge_mm: float
    transition_distance_mm: float
    strategy: GeneratedComponentMeshStrategy
    mesh_priority: int = field(kw_only=True)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "target_edge_mm",
            _positive_finite_length(
                self.target_edge_mm,
                field_name="component target_edge_mm",
            ),
        )
        if (
            isinstance(self.mesh_priority, bool)
            or not isinstance(self.mesh_priority, int)
            or self.mesh_priority < 1
        ):
            raise AssemblyPolicyError(
                "component mesh_priority must be a positive integer"
            )
        object.__setattr__(
            self,
            "transition_distance_mm",
            _positive_finite_length(
                self.transition_distance_mm,
                field_name="component transition_distance_mm",
            ),
        )
        if type(self.strategy) not in {
            StructuredSweepMeshStrategy,
            OrthogonalHexMeshStrategy,
            ConformalHybridMeshStrategy,
        }:
            raise AssemblyPolicyError(
                "component strategy must be structured sweep, orthogonal hex, "
                "or conformal hybrid"
            )

    @property
    def volume_topology(self) -> GeneratedComponentVolumeTopology:
        """Read-only view of the sole topology authority ``strategy.kind``."""

        return self.strategy.kind


@dataclass(frozen=True, slots=True)
class Component:
    """One immutable mesh-control owner.

    Generated components own one or more geometry references and one material.
    Frozen components own no new geometry or material assignment: those facts
    remain authoritative in their complete :class:`FrozenSource`.
    """

    identifier: str
    kind: ComponentKind
    material_name: str | None = None
    geometry_refs: tuple[str, ...] = ()
    source_id: str | None = None
    mesh_control: GeneratedComponentMeshControl | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "identifier",
            _name(self.identifier, field_name="component identifier"),
        )
        if isinstance(self.kind, str) and not isinstance(self.kind, ComponentKind):
            try:
                object.__setattr__(self, "kind", ComponentKind(self.kind))
            except ValueError as error:
                raise AssemblyPolicyError(
                    "component kind must be 'generated' or 'frozen'"
                ) from error
        if not isinstance(self.kind, ComponentKind):
            raise AssemblyPolicyError("kind must be a ComponentKind")

        raw_refs = _tuple(self.geometry_refs, field_name="geometry_refs")
        refs = tuple(
            _name(value, field_name="geometry reference") for value in raw_refs
        )
        if len(set(refs)) != len(refs):
            raise AssemblyPolicyError("component geometry references must be unique")
        object.__setattr__(self, "geometry_refs", refs)

        if self.kind is ComponentKind.GENERATED:
            if not refs:
                raise AssemblyPolicyError(
                    "a generated component must contain geometry"
                )
            object.__setattr__(
                self,
                "material_name",
                _name(self.material_name, field_name="generated component material"),
            )
            if self.source_id is not None:
                raise AssemblyPolicyError(
                    "a generated component cannot belong to a frozen source"
                )
            if self.mesh_control is not None and type(
                self.mesh_control
            ) is not GeneratedComponentMeshControl:
                raise AssemblyPolicyError(
                    "generated component mesh_control must be a "
                    "GeneratedComponentMeshControl"
                )
            return

        if refs:
            raise AssemblyPolicyError(
                "a frozen component cannot declare generated geometry"
            )
        if self.material_name is not None:
            raise AssemblyPolicyError(
                "a frozen component cannot override its source material"
            )
        if self.mesh_control is not None:
            raise AssemblyPolicyError(
                "a frozen component cannot declare generated mesh control"
            )
        object.__setattr__(
            self,
            "source_id",
            _name(self.source_id, field_name="frozen component source_id"),
        )

    @classmethod
    def generated(
        cls,
        identifier: str,
        material_name: str,
        geometry_refs: Sequence[str],
        *,
        mesh_control: GeneratedComponentMeshControl | None = None,
    ) -> "Component":
        refs = _tuple(geometry_refs, field_name="geometry_refs")
        return cls(
            identifier=identifier,
            kind=ComponentKind.GENERATED,
            material_name=material_name,
            geometry_refs=refs,  # type: ignore[arg-type]
            mesh_control=mesh_control,
        )

    @classmethod
    def frozen(cls, identifier: str, source_id: str) -> "Component":
        return cls(
            identifier=identifier,
            kind=ComponentKind.FROZEN,
            source_id=source_id,
        )

    def require_mesh_control(self) -> GeneratedComponentMeshControl:
        """Return explicit worker sizing, or fail before any mesh work starts."""

        if self.kind is not ComponentKind.GENERATED or self.mesh_control is None:
            raise AssemblyPolicyError(
                f"generated Component {self.identifier!r} requires an explicit "
                "mesh_control for this worker profile"
            )
        return self.mesh_control


@dataclass(frozen=True, slots=True)
class GeometryRecord:
    """One flat generated-geometry ownership record.

    ``START_COMPONENT`` declares the only component/material hierarchy entry.
    ``APPEND_GEOMETRY`` carries geometry only and therefore cannot silently
    create or override a component or material.
    """

    kind: GeometryRecordKind
    geometry_ref: str
    component_id: str | None = None
    material_name: str | None = None
    mesh_control: GeneratedComponentMeshControl | None = None

    def __post_init__(self) -> None:
        if isinstance(self.kind, str) and not isinstance(self.kind, GeometryRecordKind):
            try:
                object.__setattr__(self, "kind", GeometryRecordKind(self.kind))
            except ValueError as error:
                raise AssemblyPolicyError(
                    "geometry record kind must be START_COMPONENT or APPEND_GEOMETRY"
                ) from error
        if not isinstance(self.kind, GeometryRecordKind):
            raise AssemblyPolicyError("kind must be a GeometryRecordKind")
        object.__setattr__(
            self,
            "geometry_ref",
            _name(self.geometry_ref, field_name="geometry reference"),
        )

        if self.kind is GeometryRecordKind.START_COMPONENT:
            object.__setattr__(
                self,
                "component_id",
                _name(self.component_id, field_name="START_COMPONENT component_id"),
            )
            object.__setattr__(
                self,
                "material_name",
                _name(self.material_name, field_name="START_COMPONENT material"),
            )
            if self.mesh_control is not None and type(
                self.mesh_control
            ) is not GeneratedComponentMeshControl:
                raise AssemblyPolicyError(
                    "START_COMPONENT mesh_control must be a "
                    "GeneratedComponentMeshControl"
                )
            return
        if (
            self.component_id is not None
            or self.material_name is not None
            or self.mesh_control is not None
        ):
            raise AssemblyPolicyError(
                "APPEND_GEOMETRY cannot declare a component, material, or mesh_control"
            )


def compile_geometry_records(records: Sequence[GeometryRecord]) -> tuple[Component, ...]:
    """Compile flat records into generated control components in source order."""

    raw_records = _tuple(records, field_name="geometry records")
    if not raw_records:
        raise AssemblyPolicyError("geometry records must not be empty")
    if any(not isinstance(record, GeometryRecord) for record in raw_records):
        raise AssemblyPolicyError("geometry records must contain GeometryRecord values")

    components: list[Component] = []
    component_ids: set[str] = set()
    geometry_refs: set[str] = set()
    current_id: str | None = None
    current_material: str | None = None
    current_mesh_control: GeneratedComponentMeshControl | None = None
    current_geometry: list[str] = []

    def finish_current() -> None:
        if current_id is None:
            return
        assert current_material is not None
        components.append(
            Component.generated(
                current_id,
                current_material,
                current_geometry,
                mesh_control=current_mesh_control,
            )
        )

    for record in raw_records:
        assert isinstance(record, GeometryRecord)
        if record.geometry_ref in geometry_refs:
            raise AssemblyPolicyError(
                f"duplicate geometry reference {record.geometry_ref!r}"
            )
        geometry_refs.add(record.geometry_ref)

        if record.kind is GeometryRecordKind.START_COMPONENT:
            assert record.component_id is not None
            assert record.material_name is not None
            finish_current()
            if record.component_id in component_ids:
                raise AssemblyPolicyError(
                    f"duplicate component identifier {record.component_id!r}"
                )
            component_ids.add(record.component_id)
            current_id = record.component_id
            current_material = record.material_name
            current_mesh_control = record.mesh_control
            current_geometry = [record.geometry_ref]
            continue
        if current_id is None:
            raise AssemblyPolicyError(
                "APPEND_GEOMETRY requires a preceding START_COMPONENT"
            )
        current_geometry.append(record.geometry_ref)

    finish_current()
    return tuple(components)


@dataclass(frozen=True, slots=True)
class FrozenSource:
    """A complete imported source whose component meshes are all immutable."""

    source_id: str
    components: tuple[Component, ...]
    whole_source_frozen: bool = field(default=True, init=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "source_id",
            _name(self.source_id, field_name="frozen source_id"),
        )
        raw_components = _tuple(
            self.components, field_name="frozen source components"
        )
        if not raw_components:
            raise AssemblyPolicyError(
                "a frozen source must contain at least one component"
            )
        if any(not isinstance(component, Component) for component in raw_components):
            raise AssemblyPolicyError(
                "frozen source components must contain Component values"
            )
        components = tuple(raw_components)
        if any(component.kind is not ComponentKind.FROZEN for component in components):
            raise AssemblyPolicyError(
                "every component in a frozen source must be frozen"
            )
        if any(component.source_id != self.source_id for component in components):
            raise AssemblyPolicyError(
                "every frozen component must reference its complete source"
            )
        identifiers = tuple(component.identifier for component in components)
        if len(set(identifiers)) != len(identifiers):
            raise AssemblyPolicyError(
                "frozen source component identifiers must be unique"
            )
        object.__setattr__(self, "components", components)

    @property
    def component_ids(self) -> tuple[str, ...]:
        return tuple(component.identifier for component in self.components)


class InterfaceCoupling(str, Enum):
    """The only package-interface coupling supported by this policy slice."""

    SHARED_NODES = "shared_nodes"


class InterfaceMatchMode(str, Enum):
    """The sole explicit Frozen-to-Generated interface preservation mode."""

    PRESERVE_INTERFACE_TRACE = "preserve_interface_trace"


@dataclass(frozen=True, slots=True)
class InterfaceMatch:
    """One explicit frozen-to-generated shared-node preservation rule.

    The complete Frozen source is always read-only.  The Generated endpoint
    reuses only the exact contact trace; Frozen owner-volume connectivity is
    never inherited or propagated.
    """

    frozen_component: Component
    generated_component: Component
    mode: InterfaceMatchMode = InterfaceMatchMode.PRESERVE_INTERFACE_TRACE
    coupling: InterfaceCoupling = InterfaceCoupling.SHARED_NODES

    def __post_init__(self) -> None:
        if not isinstance(self.frozen_component, Component):
            raise AssemblyPolicyError("frozen_component must be a Component")
        if self.frozen_component.kind is not ComponentKind.FROZEN:
            raise AssemblyPolicyError("InterfaceMatch must start at a frozen component")
        if not isinstance(self.generated_component, Component):
            raise AssemblyPolicyError("generated_component must be a Component")
        if self.generated_component.kind is not ComponentKind.GENERATED:
            raise AssemblyPolicyError("InterfaceMatch must end at a generated component")
        if self.frozen_component.identifier == self.generated_component.identifier:
            raise AssemblyPolicyError("interface components must be distinct")

        if isinstance(self.mode, str) and not isinstance(self.mode, InterfaceMatchMode):
            try:
                object.__setattr__(self, "mode", InterfaceMatchMode(self.mode))
            except ValueError as error:
                raise AssemblyPolicyError(
                    "interface match mode must be preserve_interface_trace"
                ) from error
        if not isinstance(self.mode, InterfaceMatchMode):
            raise AssemblyPolicyError("mode must be an InterfaceMatchMode")
        if isinstance(self.coupling, str) and not isinstance(
            self.coupling, InterfaceCoupling
        ):
            try:
                object.__setattr__(self, "coupling", InterfaceCoupling(self.coupling))
            except ValueError as error:
                raise AssemblyPolicyError(
                    "package interfaces support shared_nodes only"
                ) from error
        if self.coupling is not InterfaceCoupling.SHARED_NODES:
            raise AssemblyPolicyError("package interfaces support shared_nodes only")


@dataclass(frozen=True, slots=True)
class InterfaceTraceSignature:
    """Immutable identity used to prove equality of two frozen traces."""

    fingerprint: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "fingerprint",
            _name(self.fingerprint, field_name="interface trace fingerprint"),
        )


class ResolvedInterfaceStrategy(str, Enum):
    """Internal interface decisions; these are not user match modes."""

    COMMON_GMSH = "common_gmsh"
    USE_FROZEN_TRACE = "use_frozen_trace"
    REQUIRE_EQUAL_FROZEN_TRACES = "require_equal_frozen_traces"


@dataclass(frozen=True, slots=True)
class ResolvedInterfacePolicy:
    """A validated internal shared-node decision for two components."""

    first_component: Component
    second_component: Component
    strategy: ResolvedInterfaceStrategy
    coupling: InterfaceCoupling = InterfaceCoupling.SHARED_NODES
    trace_signature: InterfaceTraceSignature | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.first_component, Component) or not isinstance(
            self.second_component, Component
        ):
            raise AssemblyPolicyError(
                "resolved interface endpoints must be Component values"
            )
        if self.first_component.identifier >= self.second_component.identifier:
            raise AssemblyPolicyError(
                "resolved interface endpoints must be distinct and canonical"
            )
        if not isinstance(self.strategy, ResolvedInterfaceStrategy):
            raise AssemblyPolicyError(
                "strategy must be a ResolvedInterfaceStrategy"
            )
        if self.coupling is not InterfaceCoupling.SHARED_NODES:
            raise AssemblyPolicyError("resolved interfaces support shared_nodes only")

        kinds = (self.first_component.kind, self.second_component.kind)
        frozen_count = sum(kind is ComponentKind.FROZEN for kind in kinds)
        if self.strategy is ResolvedInterfaceStrategy.COMMON_GMSH:
            if frozen_count or self.trace_signature is not None:
                raise AssemblyPolicyError(
                    "common_gmsh requires two generated components and no frozen policy"
                )
            return
        if self.strategy is ResolvedInterfaceStrategy.USE_FROZEN_TRACE:
            if frozen_count != 1 or self.trace_signature is not None:
                raise AssemblyPolicyError(
                    "use_frozen_trace requires one frozen and one generated component"
                )
            return
        if (
            frozen_count != 2
            or not isinstance(self.trace_signature, InterfaceTraceSignature)
        ):
            raise AssemblyPolicyError(
                "equal frozen traces require two frozen components and one signature"
            )

    @property
    def component_ids(self) -> tuple[str, str]:
        return (
            self.first_component.identifier,
            self.second_component.identifier,
        )


def resolve_interface_policy(
    first: Component,
    second: Component,
    *,
    match: InterfaceMatch | None = None,
    first_trace: InterfaceTraceSignature | None = None,
    second_trace: InterfaceTraceSignature | None = None,
) -> ResolvedInterfacePolicy:
    """Resolve one internal shared-node strategy without a user ``AUTO`` mode."""

    if not isinstance(first, Component) or not isinstance(second, Component):
        raise AssemblyPolicyError("interface endpoints must be Component values")
    if first.identifier == second.identifier:
        raise AssemblyPolicyError("interface endpoints must be distinct")
    ordered = tuple(sorted((first, second), key=lambda item: item.identifier))
    first_ordered, second_ordered = ordered
    frozen_count = sum(
        component.kind is ComponentKind.FROZEN for component in ordered
    )

    if frozen_count == 0:
        if match is not None:
            raise AssemblyPolicyError(
                "generated-generated interfaces cannot declare InterfaceMatch"
            )
        if first_trace is not None or second_trace is not None:
            raise AssemblyPolicyError(
                "generated-generated interfaces cannot declare frozen traces"
            )
        return ResolvedInterfacePolicy(
            first_ordered,
            second_ordered,
            ResolvedInterfaceStrategy.COMMON_GMSH,
        )

    if frozen_count == 1:
        if first_trace is not None or second_trace is not None:
            raise AssemblyPolicyError(
                "frozen-generated interfaces do not compare two frozen traces"
            )
        frozen = next(
            component
            for component in ordered
            if component.kind is ComponentKind.FROZEN
        )
        generated = next(
            component
            for component in ordered
            if component.kind is ComponentKind.GENERATED
        )
        if match is None:
            return ResolvedInterfacePolicy(
                first_ordered,
                second_ordered,
                ResolvedInterfaceStrategy.USE_FROZEN_TRACE,
            )
        if not isinstance(match, InterfaceMatch):
            raise AssemblyPolicyError("match must be an InterfaceMatch")
        if match.frozen_component != frozen or match.generated_component != generated:
            raise AssemblyPolicyError(
                "InterfaceMatch endpoints do not match the resolved interface"
            )
        return ResolvedInterfacePolicy(
            first_ordered,
            second_ordered,
            ResolvedInterfaceStrategy.USE_FROZEN_TRACE,
        )

    if match is not None:
        raise AssemblyPolicyError(
            "frozen-frozen interfaces cannot declare InterfaceMatch"
        )
    if not isinstance(first_trace, InterfaceTraceSignature) or not isinstance(
        second_trace, InterfaceTraceSignature
    ):
        raise AssemblyPolicyError(
            "frozen-frozen interfaces require both trace signatures"
        )
    if first_trace != second_trace:
        raise AssemblyPolicyError("frozen-frozen interface traces do not match")
    return ResolvedInterfacePolicy(
        first_ordered,
        second_ordered,
        ResolvedInterfaceStrategy.REQUIRE_EQUAL_FROZEN_TRACES,
        trace_signature=first_trace,
    )


@dataclass(frozen=True, slots=True)
class PackageAssemblyPolicy:
    """Complete immutable policy input for the future package assembler."""

    generated_components: tuple[Component, ...]
    frozen_sources: tuple[FrozenSource, ...]
    interface_matches: tuple[InterfaceMatch, ...] = ()
    allow_empty: bool = field(default=False, kw_only=True)
    coupling: InterfaceCoupling = InterfaceCoupling.SHARED_NODES

    def __post_init__(self) -> None:
        if type(self.allow_empty) is not bool:
            raise AssemblyPolicyError("allow_empty must be boolean")
        raw_generated = _tuple(
            self.generated_components, field_name="generated_components"
        )
        raw_sources = _tuple(self.frozen_sources, field_name="frozen_sources")
        raw_matches = _tuple(self.interface_matches, field_name="interface_matches")
        if any(
            not isinstance(component, Component)
            or component.kind is not ComponentKind.GENERATED
            for component in raw_generated
        ):
            raise AssemblyPolicyError(
                "generated_components must contain generated Component values"
            )
        if any(not isinstance(source, FrozenSource) for source in raw_sources):
            raise AssemblyPolicyError(
                "frozen_sources must contain FrozenSource values"
            )
        if any(not isinstance(match, InterfaceMatch) for match in raw_matches):
            raise AssemblyPolicyError(
                "interface_matches must contain InterfaceMatch values"
            )
        generated = tuple(raw_generated)
        sources = tuple(raw_sources)
        matches = tuple(raw_matches)
        object.__setattr__(self, "generated_components", generated)
        object.__setattr__(self, "frozen_sources", sources)
        object.__setattr__(self, "interface_matches", matches)

        source_ids = tuple(source.source_id for source in sources)
        if len(set(source_ids)) != len(source_ids):
            raise AssemblyPolicyError("frozen source identifiers must be unique")
        frozen = tuple(
            component for source in sources for component in source.components
        )
        components = generated + frozen
        if not components and not self.allow_empty:
            raise AssemblyPolicyError(
                "a package assembly must contain at least one component"
            )
        identifiers = tuple(component.identifier for component in components)
        if len(set(identifiers)) != len(identifiers):
            raise AssemblyPolicyError("assembly component identifiers must be unique")
        by_id = {component.identifier: component for component in components}

        pairs: set[tuple[str, str]] = set()
        for match in matches:
            frozen_id = match.frozen_component.identifier
            generated_id = match.generated_component.identifier
            if by_id.get(frozen_id) != match.frozen_component or by_id.get(
                generated_id
            ) != match.generated_component:
                raise AssemblyPolicyError(
                    "InterfaceMatch references a component outside the assembly"
                )
            pair = (frozen_id, generated_id)
            if pair in pairs:
                raise AssemblyPolicyError(
                    "an assembly interface may have only one InterfaceMatch"
                )
            pairs.add(pair)

        if isinstance(self.coupling, str) and not isinstance(
            self.coupling, InterfaceCoupling
        ):
            try:
                object.__setattr__(self, "coupling", InterfaceCoupling(self.coupling))
            except ValueError as error:
                raise AssemblyPolicyError(
                    "package assemblies support shared_nodes only"
                ) from error
        if self.coupling is not InterfaceCoupling.SHARED_NODES:
            raise AssemblyPolicyError("package assemblies support shared_nodes only")

    @property
    def components(self) -> tuple[Component, ...]:
        return self.generated_components + tuple(
            component
            for source in self.frozen_sources
            for component in source.components
        )

    @property
    def component_by_id(self) -> Mapping[str, Component]:
        return MappingProxyType(
            {component.identifier: component for component in self.components}
        )


__all__ = [
    "AssemblyPolicyError",
    "COMPONENT_LOCAL_DIRECTIONS",
    "Component",
    "ComponentKind",
    "ComponentLocalDirection",
    "ConformalHybridMeshStrategy",
    "DerivedVariable",
    "FrozenSource",
    "GeometryRecord",
    "GeometryRecordKind",
    "GeneratedComponentMeshControl",
    "GeneratedComponentMeshStrategy",
    "GeneratedComponentVolumeTopology",
    "InterfaceCoupling",
    "InterfaceMatch",
    "InterfaceMatchMode",
    "InterfaceTraceSignature",
    "OrthogonalHexMeshStrategy",
    "PackageAssemblyPolicy",
    "ResolvedInterfacePolicy",
    "ResolvedInterfaceStrategy",
    "ResolvedTemplateParameters",
    "ResolvedTemplateValue",
    "TemplateDimension",
    "TemplateParameter",
    "TemplateScalar",
    "TemplateValueSource",
    "StructuredSweepMeshStrategy",
    "compile_geometry_records",
    "resolve_interface_policy",
    "resolve_template_parameters",
]
