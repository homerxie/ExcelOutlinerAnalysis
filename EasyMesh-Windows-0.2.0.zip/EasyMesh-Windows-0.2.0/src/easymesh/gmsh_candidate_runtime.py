"""Bounded, observable execution of independent native Gmsh candidates.

Native calls cannot safely be cancelled by a Python thread. Each candidate
owns a fresh spawned process; timeout never damages the caller's Gmsh model.
Only trusted internal Python objects travel over the private process pipe.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar, copy_context
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import copyreg
from dataclasses import dataclass
from functools import wraps
import math
import multiprocessing
import os
import tempfile
import time
import threading
from types import MappingProxyType
from typing import Callable


@dataclass(frozen=True)
class CandidateExecutionPolicy:
    candidate_timeout_seconds: float = 60.0
    search_timeout_seconds: float = 240.0

    def __post_init__(self):
        for value in (self.candidate_timeout_seconds, self.search_timeout_seconds):
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not math.isfinite(value) or value <= 0):
                raise ValueError("candidate execution budgets must be finite and positive")


DEFAULT_CANDIDATE_POLICY = CandidateExecutionPolicy()
# Measured native-candidate policy, independent of component identity.
DIRECT_VOLUME_THREADS_BY_ALGORITHM = MappingProxyType({1: 1, 4: 1, 10: 4})
_policy = ContextVar("gmsh_candidate_policy", default=DEFAULT_CANDIDATE_POLICY)
_deadline = ContextVar("gmsh_candidate_deadline", default=None)
_observer = ContextVar("gmsh_candidate_observer", default=None)
_sequence = ContextVar("gmsh_candidate_sequence", default=None)
_parallel_tet = ContextVar("gmsh_parallel_tet_candidates", default=False)
_event_metadata = ContextVar("gmsh_candidate_event_metadata", default={})


@contextmanager
def candidate_event_context(**metadata):
    token = _event_metadata.set({**_event_metadata.get(), **metadata})
    try:
        yield
    finally:
        _event_metadata.reset(token)


class CandidateExecutionError(RuntimeError):
    pass


class CandidateTimeoutError(CandidateExecutionError):
    pass


class CandidateSearchExhausted(CandidateExecutionError):
    pass


def _restore_proxy(values):
    return MappingProxyType(values)


def _reduce_proxy(value):
    return _restore_proxy, (dict(value),)


# Immutable mesh DTOs contain mapping proxies. Preserve their immutability
# across spawn instead of relying on fork and inherited native runtime state.
copyreg.pickle(type(MappingProxyType({})), _reduce_proxy)


@contextmanager
def candidate_execution_context(*, observer=None, policy=None, parallel_tet_candidates=None):
    if policy is not None and not isinstance(policy, CandidateExecutionPolicy):
        raise TypeError("policy must be CandidateExecutionPolicy")
    if parallel_tet_candidates is not None and type(parallel_tet_candidates) is not bool:
        raise TypeError("parallel_tet_candidates must be boolean")
    tokens = []
    if observer is not None:
        tokens.append((_observer, _observer.set(observer)))
    if policy is not None:
        tokens.append((_policy, _policy.set(policy)))
    if parallel_tet_candidates is not None:
        tokens.append((_parallel_tet, _parallel_tet.set(parallel_tet_candidates)))
    try:
        yield
    finally:
        for variable, token in reversed(tokens):
            variable.reset(token)


def parallel_tet_candidates_enabled():
    return _parallel_tet.get()


@contextmanager
def reserve_fallback_budget():
    """Give the preferred algorithm at most half the remaining shared budget."""
    deadline = _deadline.get()
    now = time.monotonic()
    token = _deadline.set(now + max(0., deadline - now) / 2) if deadline is not None else None
    try:
        yield
    finally:
        if token is not None:
            _deadline.reset(token)


def emit_candidate_event(event):
    observer = _observer.get()
    if observer is not None:
        # Logging must not alter meshing semantics.
        try:
            observer({**_event_metadata.get(), **dict(event)})
        except Exception:
            pass


def has_candidate_observer():
    return _observer.get() is not None


@contextmanager
def candidate_stage(stage: str):
    start = time.monotonic()
    emit_candidate_event({"stage": stage, "state": "started"})
    try:
        yield
    except Exception as error:
        emit_candidate_event({"stage": stage, "state": "failed",
                              "elapsed_seconds": time.monotonic() - start,
                              "detail": str(error)})
        raise
    else:
        emit_candidate_event({"stage": stage, "state": "completed",
                              "elapsed_seconds": time.monotonic() - start})


def check_candidate_budget():
    deadline = _deadline.get()
    if deadline is not None and time.monotonic() >= deadline:
        raise CandidateSearchExhausted(
            "Gmsh candidate search budget exhausted; unverified candidates are not accepted"
        )


def bounded_candidate_search(function):
    @wraps(function)
    def bounded(*args, **kwargs):
        token = None
        sequence_token = None
        if _deadline.get() is None:
            token = _deadline.set(time.monotonic() + _policy.get().search_timeout_seconds)
            sequence_token = _sequence.set([0])
        try:
            check_candidate_budget()
            return function(*args, **kwargs)
        finally:
            if token is not None:
                _deadline.reset(token)
                _sequence.reset(sequence_token)
    return bounded


def _child(connection, function, args, kwargs, scratch, metadata):
    try:
        # Some native optimizers write diagnostics in their current directory.
        # They must not overwrite files in the user's project.
        os.chdir(scratch)
        with candidate_event_context(**metadata), candidate_execution_context(
            observer=lambda event: connection.send(("event", event))
        ):
            value = function(*args, **kwargs)
        connection.send(("result", value))
    except Exception as error:
        connection.send(("error", f"{type(error).__name__}: {error}"))
    finally:
        connection.close()


def run_isolated_candidate(function: Callable, args: tuple, kwargs: dict, *, label: str, cancel_event=None):
    check_candidate_budget()
    sequence = _sequence.get()
    if sequence is not None:
        sequence[0] += 1
        label = f"attempt={sequence[0]}/{label}"
    timeout = _policy.get().candidate_timeout_seconds
    if _deadline.get() is not None:
        timeout = min(timeout, _deadline.get() - time.monotonic())
    context = multiprocessing.get_context("spawn")
    receive, send = context.Pipe(duplex=False)
    scratch = tempfile.TemporaryDirectory(prefix="easymesh-gmsh-candidate-")
    process = context.Process(target=_child, args=(send, function, args, kwargs, scratch.name, _event_metadata.get()))
    started = time.monotonic()
    last_stage = "startup"
    emit_candidate_event({"candidate": label, "stage": "candidate", "state": "started",
                          "timeout_seconds": timeout})
    try:
        process.start()
        send.close()
        while True:
            if cancel_event is not None and cancel_event.is_set():
                raise CandidateExecutionError(f"Gmsh candidate {label} cancelled by candidate search cleanup")
            remaining = timeout - (time.monotonic() - started)
            if remaining <= 0:
                raise CandidateTimeoutError(
                    f"Gmsh candidate {label} exceeded {timeout:.3g}s in {last_stage}; "
                    "candidate discarded without relaxing mesh audits"
                )
            if not receive.poll(min(0.1, remaining)):
                if not process.is_alive():
                    raise CandidateExecutionError(f"Gmsh candidate {label} exited with {process.exitcode}")
                continue
            try:
                kind, value = receive.recv()
            except EOFError as error:
                raise CandidateExecutionError(f"Gmsh candidate {label} exited without a result") from error
            if kind == "event":
                last_stage = value["stage"]
                emit_candidate_event({**value, "candidate": label})
            elif kind == "result":
                check_candidate_budget()
                emit_candidate_event({"candidate": label, "stage": "candidate", "state": "completed",
                                      "elapsed_seconds": time.monotonic() - started})
                return value
            else:
                raise CandidateExecutionError(f"Gmsh candidate {label}: {value}")
    except Exception as error:
        emit_candidate_event({"candidate": label, "stage": last_stage,
                              "state": "timeout" if isinstance(error, CandidateTimeoutError) else "failed",
                              "elapsed_seconds": time.monotonic() - started, "detail": str(error)})
        raise
    finally:
        receive.close()
        send.close()
        if process.pid is not None:
            process.join(timeout=0.1)
            if process.is_alive():
                process.terminate()
                process.join(timeout=1.0)
            if process.is_alive():
                process.kill()
                process.join(timeout=5.0)
            process.close()
        scratch.cleanup()


def race_isolated_candidates(choices, accept):
    """Race at most two native processes; only a parent-audited result wins.

    Threads only supervise independent spawned processes. No Gmsh API or mesh
    audits execute concurrently in this parent process. On every exit path,
    cancellation is signalled and supervisors reap all children before return.
    """
    if not 1 <= len(choices) <= 2:
        raise ValueError("a native candidate race requires one or two choices")
    check_candidate_budget()
    stop = threading.Event()
    observer = _observer.get()
    observer_lock = threading.Lock()
    failures = []

    def serialized_observer(event):
        if observer is not None:
            with observer_lock:
                observer(event)

    def supervise(choice):
        function, args, kwargs, label = choice
        # Labels already carry algorithm and seed; do not mutate the shared
        # serial attempt counter from supervising threads.
        token = _sequence.set(None)
        try:
            with candidate_execution_context(observer=serialized_observer):
                return run_isolated_candidate(function, args, kwargs, label=label, cancel_event=stop)
        finally:
            _sequence.reset(token)

    with ThreadPoolExecutor(max_workers=len(choices)) as pool:
        pending = {pool.submit(copy_context().run, supervise, choice): choice[3] for choice in choices}
        try:
            while pending:
                check_candidate_budget()
                completed, _ = wait(pending, timeout=.1, return_when=FIRST_COMPLETED)
                for future in completed:
                    label = pending.pop(future)
                    try:
                        value = future.result()
                        check_candidate_budget()
                        accepted = accept(value, label)
                        check_candidate_budget()
                    except CandidateSearchExhausted:
                        raise
                    except Exception as error:
                        failures.append(f"{label}: {error}")
                        continue
                    emit_candidate_event({"stage": "candidate_selection", "state": "accepted", "candidate": label})
                    return accepted
            raise CandidateExecutionError("all parallel candidates failed audit: " + " | ".join(failures))
        finally:
            stop.set()
