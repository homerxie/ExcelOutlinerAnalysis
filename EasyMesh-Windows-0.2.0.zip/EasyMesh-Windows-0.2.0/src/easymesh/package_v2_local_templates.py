"""Closed local templates and parent-scoped instance bindings (Source v8).

The authoring graph stays intact in the Source. Lowering evaluates bindings at
each boundary and emits numerical fragments for the existing mesh compiler.
No global environment is passed into a template's evaluation scope.
"""
from __future__ import annotations

from copy import deepcopy
import json

from .package_assembly import DerivedVariable, TemplateDimension, TemplateParameter, resolve_template_parameters
from .package_v2_instance_transform import IDENTITY, MIRROR_X, determinant, euler_angles, matvec, multiply, rotation_matrix
from .package_v2_basic_shapes import SHAPE_LABELS, numeric_basic_shape

REVISION = 8
LIBRARY_SCHEMA = "easymesh-local-template-library"
MAX_DEPTH = 16
MAX_EXPANDED_SOLIDS = 20000


def _keys(value, required, optional=(), *, where):
    if not isinstance(value, dict):
        raise ValueError(f"{where}: 必须是对象")
    missing, extra = set(required) - value.keys(), value.keys() - set(required) - set(optional)
    if missing or extra:
        raise ValueError(f"{where}: 缺少字段 {sorted(missing)}；未知字段 {sorted(extra)}")


def _identifier(value, where):
    from .package_v2_source import _identifier as parse_identifier
    return parse_identifier(value, where, field_name=where)


def _array(value, where):
    if not isinstance(value, list):
        raise ValueError(f"{where}: 必须是数组")
    return value


def literal(value, kind="length"):
    text = str(float(value))
    return text + "mm" if kind == "length" else text


def resolve_scope(definition, overrides=None, *, where="locals"):
    from .package_v2_source import _parse_parameter, _parse_derived
    params = [_parse_parameter(item, f"{where}/parameters/{i}")
              for i, item in enumerate(_array(definition["parameters"], where))]
    derived = [_parse_derived(item, f"{where}/derived/{i}")
               for i, item in enumerate(_array(definition["derived"], where))]
    def bounds(value):
        return ((value.value_range.minimum, value.value_range.maximum)
                if value.value_range else (None, None))
    if any(parameter.default is None for parameter in params):
        raise ValueError(f"{where}: 每个公开参数需要默认值，用于独立验证和创建实例")
    return resolve_template_parameters(
        tuple(TemplateParameter(p.name, p.dimension, p.default, *bounds(p)) for p in params),
        tuple(DerivedVariable(p.name, p.dimension, p.expression_source, *bounds(p)) for p in derived),
        overrides,
    )


def evaluate(value, scope, kind="length"):
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise ValueError("参数必须是数值或表达式")
    if isinstance(value, (int, float)):
        value = literal(value, kind)
    return scope.evaluate_expression(value, dimension=TemplateDimension(kind))


def vector(values, scope):
    if not isinstance(values, (list, tuple)) or len(values) != 3:
        raise ValueError("Origin 必须包含 X/Y/Z 三项")
    return tuple(evaluate(value, scope) for value in values)


def pose(instance, scope):
    angles = instance.get("rotation", [0, 0, 0])
    if not isinstance(angles, list) or len(angles) != 3:
        raise ValueError("rotation 必须包含 X/Y/Z 三项")
    angles = tuple(evaluate(value, scope, "dimensionless") for value in angles)
    mirrors = instance.get("mirrors", [False] * 3)
    if not isinstance(mirrors, list) or len(mirrors) != 3 or any(type(v) is not bool for v in mirrors):
        raise ValueError("mirrors 必须包含三个布尔开关")
    reflection = tuple(tuple((-1. if mirrors[i] else 1.) if i == j else 0. for j in range(3)) for i in range(3))
    return multiply(rotation_matrix(angles), reflection), vector(instance["origin"], scope)


def bound_scope(template, bindings, parent_scope):
    expected = {p["name"] for p in template["parameters"]}
    if not isinstance(bindings, dict) or set(bindings) != expected:
        raise ValueError(f"模板 {template['id']} 的公开参数必须逐一赋值：{sorted(expected)}")
    overrides = {p["name"]: literal(evaluate(bindings[p["name"]], parent_scope, p["kind"]), p["kind"])
                 for p in template["parameters"]}
    return resolve_scope(template, overrides, where=f"template/{template['id']}")


def builtin_templates():
    result = []
    for name, centered in (("box_zmin_center", True), ("box_min_corner", False)):
        bounds = {"xmin": "-x_size / 2" if centered else "0mm",
                  "xmax": "x_size / 2" if centered else "x_size",
                  "ymin": "-y_size / 2" if centered else "0mm",
                  "ymax": "y_size / 2" if centered else "y_size",
                  "zmin": "0mm", "zmax": "z_size"}
        result.append({"id": name, "parameters": [
            {"name": f"{axis}_size", "kind": "length", "unit": "mm", "default": "1mm"} for axis in "xyz"],
            "derived": [],
            "solids": [{"id": "body", "kind": "bounds_box", "bounds": bounds}], "instances": []})
    return result


def new_document(identifier="package"):
    return {"schema": "easymesh-package-v2", "schema_revision": 8,
            "package": {"id": identifier, "family": "custom"},
            "globals": {"parameters": [], "derived": []}, "templates": builtin_templates(),
            "instances": [], "frozen_sources": [],
            "mesh_settings": {"interface_geometry_tolerance": "0.01um"}}


def decode_library(data):
    if len(data) > 16 * 1024 * 1024:
        raise ValueError("模板文件不能超过 16 MB")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f"模板文件字段重复：{key}")
            result[key] = value
        return result
    def constant(value):
        raise ValueError(f"模板文件不允许非有限数值：{value}")
    try:
        result = json.loads(data, object_pairs_hook=pairs, parse_constant=constant)
        if not isinstance(result, dict):
            raise ValueError("模板文件根节点必须是对象")
        return result
    except RecursionError as error:
        raise ValueError("模板文件嵌套过深") from error


def _numeric_geometry(geometry, scope):
    if geometry.get("kind") in SHAPE_LABELS:
        return numeric_basic_shape(geometry, lambda value: evaluate(value, scope))
    if geometry.get("kind") == "union":
        return dict(geometry, children=[_numeric_geometry(child, scope) for child in geometry["children"]])
    if geometry.get("kind") == "difference":
        return dict(geometry, base=_numeric_geometry(geometry["base"], scope),
                    cutters=[_numeric_geometry(child, scope) for child in geometry["cutters"]])
    raise ValueError(f"未知基本图形 {geometry.get('kind')!r}；请使用当前坐标型基本图形")


def _validate_numeric_geometry(geometry):
    from .package_v2_source import _parse_geometry
    from .package_v2_compile import _geometry_expression_root
    from .package_v2_geometry import GeometryFragmentSource, compile_generated_geometry_instance
    from .package_assembly import GeometryRecord, GeometryRecordKind
    source = _parse_geometry(geometry, "/solid")
    compile_generated_geometry_instance(instance_id="validation",
        records=(GeometryRecord(GeometryRecordKind.START_COMPONENT, source.identifier,
                    component_id="body", material_name="solid"),),
        fragment_sources={source.identifier: GeometryFragmentSource(source.identifier, _geometry_expression_root(source))},
        resolved=resolve_template_parameters(()))


def _check_instance(instance, templates, *, top):
    _keys(instance, ("id", "template", "bindings", "origin"),
          ("rotation", "mirrors", "material", "mesh_control", "component_id") if top else ("rotation", "mirrors"),
          where="Instance")
    _identifier(instance["id"], "/instance/id")
    if instance["template"] not in templates:
        raise ValueError(f"未知模板 {instance['template']!r}")
    if top and ("material" not in instance or "mesh_control" not in instance):
        raise ValueError("工程 Instance 必须指定材料与网格设置")
    if top:
        _identifier(component_id(instance), "/instance/component_id")


def component_id(instance):
    return instance.get("component_id", instance["id"])


def component_instances(document):
    groups = {}
    for instance in document["instances"]:
        groups.setdefault(component_id(instance), []).append(instance)
    return groups


def template_registry(document):
    templates = {}
    for template in _array(document["templates"], "/templates"):
        _keys(template, ("id", "parameters", "derived", "solids", "instances"), where="Template")
        name = _identifier(template["id"], "/template/id")
        if name in templates:
            raise ValueError(f"模板名称重复：{name}")
        _array(template["solids"], f"{name}/solids")
        _array(template["instances"], f"{name}/instances")
        template = deepcopy(template)
        templates[name] = template
        if not template["solids"] and not template["instances"]:
            raise ValueError(f"模板 {name} 至少需要一个基本图形或子 Instance")
        ids = [value["id"] for value in template["solids"] + template["instances"]]
        if len(ids) != len(set(ids)):
            raise ValueError(f"模板 {name} 内基本图形 / Instance 名称重复")
        for identifier in ids:
            _identifier(identifier, f"{name}/child/id")
    complete = set()
    def visit(name, stack):
        if name in stack:
            raise ValueError("模板引用循环：" + " → ".join((*stack, name)))
        if len(stack) >= MAX_DEPTH:
            raise ValueError(f"模板嵌套不能超过 {MAX_DEPTH} 层")
        if name in complete:
            return
        for child in templates[name]["instances"]:
            _check_instance(child, templates, top=False)
            visit(child["template"], (*stack, name))
        complete.add(name)
    for name in templates:
        visit(name, ())
    return templates


def expanded_solids(template_id, bindings, parent_scope, templates, matrix=IDENTITY, translation=(0., 0., 0.), *, geometry_validator=_validate_numeric_geometry):
    from .package_v2_instances import _reflect_geometry_x
    result = []
    def walk(name, values, parent, matrix, translation, path, depth):
        if depth >= MAX_DEPTH:
            raise ValueError("模板嵌套层数超限")
        template = templates[name]
        local = bound_scope(template, values, parent)
        for solid in template["solids"]:
            if len(result) >= MAX_EXPANDED_SOLIDS:
                raise ValueError("模板展开后的 Solid 数量超限")
            geometry = _numeric_geometry(solid, local)
            # Length-encoded path segments avoid ambiguous concatenation.
            parts = (*path, solid["id"])
            geometry["id"] = "s_" + "_".join(f"{len(part)}_{part}" for part in parts)
            proper = matrix
            if determinant(matrix) < 0.:
                _reflect_geometry_x(geometry)
                proper = multiply(matrix, MIRROR_X)
            geometry_validator(geometry)
            result.append((geometry, {"translation": [literal(v) for v in translation],
                "rotation_deg_xyz": list(euler_angles(proper)), "pivot": ["0mm"] * 3}))
        for child in template["instances"]:
            child_matrix, child_origin = pose(child, local)
            shifted = matvec(matrix, child_origin)
            walk(child["template"], child["bindings"], local, multiply(matrix, child_matrix),
                 tuple(translation[i] + shifted[i] for i in range(3)), (*path, child["id"]), depth + 1)
    walk(template_id, bindings, parent_scope, matrix, translation, (), 0)
    return result


def expand_document(document, *, geometry_validator=_validate_numeric_geometry):
    """Evaluate the current authoring graph into component-local numerical leaves.

    This internal representation has no Source schema or legacy template/override
    records. Only the revision-8 frontend can create it.
    """
    from .package_v2_geometry_library import map_expressions
    _keys(document["globals"], ("parameters", "derived"), where="Global variables")
    global_scope = resolve_scope(document["globals"], where="globals")
    templates = template_registry(document)
    empty = resolve_template_parameters(())
    for name, template in templates.items():
        expanded_solids(name, {p["name"]: p["default"] for p in template["parameters"]}, empty, templates, geometry_validator=geometry_validator)
    ids, total, groups = set(), 0, {}
    for index, instance in enumerate(_array(document["instances"], "/instances")):
        _check_instance(instance, templates, top=True)
        from .package_v2_source import _parse_component_mesh_control
        _parse_component_mesh_control(instance["mesh_control"], f"/instances/{index}/mesh_control")
        name = instance["id"]
        if name in ids:
            raise ValueError(f"Instance 名称重复：{name}")
        ids.add(name)
        matrix, translation = pose(instance, global_scope)
        solids = expanded_solids(instance["template"], instance["bindings"], global_scope, templates, matrix, translation, geometry_validator=geometry_validator)
        total += len(solids)
        if total > MAX_EXPANDED_SOLIDS:
            raise ValueError("工程展开后的 Solid 数量超限")
        owner = component_id(instance)
        if owner not in groups:
            groups[owner] = (instance, [])
        first, members = groups[owner]
        if instance["mesh_control"] != first["mesh_control"] or instance["material"] != first["material"]:
            raise ValueError(f"Component {owner} 的 Geometry 必须共享材料和网格设置")
        members.append((name, solids))
    result = []
    for owner, (first, members) in groups.items():
        control = map_expressions(first["mesh_control"], lambda expr: literal(evaluate(expr, global_scope)))
        solids = []
        for name, values in members:
            for geometry, placement in values:
                if len(members) > 1:
                    geometry["id"] = f"i_{len(name)}_{name}_{geometry['id']}"
                solids.append((geometry, placement))
        result.append({"id": owner, "material": first["material"], "mesh_control": control, "solids": solids})
    return result


def export_library(document, template_id):
    registry = template_registry(document)
    needed = set()
    def visit(name):
        if name in needed:
            return
        needed.add(name)
        for child in registry[name]["instances"]:
            visit(child["template"])
    visit(template_id)
    return {"schema": LIBRARY_SCHEMA, "schema_revision": 1, "root": template_id,
            "templates": [deepcopy(value) for name, value in registry.items() if name in needed]}


def import_library(document, library):
    _keys(library, ("schema", "schema_revision", "root", "templates"), where="Template library")
    if library["schema"] != LIBRARY_SCHEMA or type(library["schema_revision"]) is not int or library["schema_revision"] != 1:
        raise ValueError("不是受支持的 Local template 文件")
    imported = template_registry(library)
    if library["root"] not in imported:
        raise ValueError("Template library 缺少根模板")
    result = deepcopy(document)
    existing = {item["id"]: item for item in result["templates"]}
    for name, template in imported.items():
        if name in existing and existing[name] != template:
            raise ValueError(f"同名模板 {name} 内容不同，请先更名")
        if name not in existing:
            result["templates"].append(deepcopy(template))
    # Prove the library closes on itself, not on this project's registry.
    probe = {"schema": "easymesh-package-v2", "schema_revision": 8,
             "package": {"id": "library", "family": "custom"}, "globals": {"parameters": [], "derived": []},
             "templates": library["templates"], "instances": [], "frozen_sources": [],
             "mesh_settings": {"interface_geometry_tolerance": "0.01um"}}
    expand_document(probe)
    return result
