"""Build a conformal material mesh around immutable bump-mesh templates.

The templates used by this project are straight extrusions whose native outer
side walls share the same component-surface heights, while fine/medium/coarse
templates deliberately use different angular node counts.  The safest
transition is therefore a 2.5-D construction:

* keep every template node and HEX8/WEDGE6 connectivity unchanged;
* mesh the XY rectangle minus each template's own polygonal outer ring;
* preserve optional ``.loc`` rectangular QUAD4 patches with their exact XY
  spacing, then extrude those patches into structured HEX8 blocks;
* reuse the exact template-ring nodes at every unchanged source Z level; and
* extrude each remaining XY TRI3 into a WEDGE6, assigning both new element
  families to the component touching the template edge in that Z interval,
  unless an explicit exterior-material mapping replaces that material outside
  the immutable template.

No standardized collar, radial scaling, tetrahedralization, or Z smoothing is
used.  Gmsh supplies the mature constrained 2-D triangulation and the final
quality evaluation; EasyMesh owns the template preservation and material
mapping rules.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass, replace
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
from typing import Any, Iterable, Mapping, Sequence
import unicodedata
import uuid

from .bump_layout import BumpLayout, load_bump_layout
from .gmsh_runtime import isolated_gmsh_model, preview_mesh_file
from .output_artifacts import (
    atomic_output_path,
    atomic_write_text,
    exclusive_output_lock,
    file_artifact,
    normalized_mesh_output,
    paths_refer_to_same_file,
)
from .planar_transition import (
    PlanarTransitionMesh,
    TransitionRing,
    generate_planar_transition_mesh,
)
from .quality import classify_mesh_quality
from .sample_mesh import (
    MeshNode,
    SampleMesh,
    SampleMeshError,
    SampleMeshInstance,
    instantiate_sample_mesh,
    load_sample_mesh,
)


_GEOMETRY_TOLERANCE_MM = 1.0e-10
_COORDINATE_KEY_DIGITS = 13
_MIN_TRANSITION_SHAPE_QUALITY = 0.30
_ALL_SOLIDS_NAME = "ALL_SOLID_VOLUMES"
_TRANSITION_SOURCE = "TRANSITION"
_TRANSITION_SOLIDS_NAME = "TRANSITION_SOLID_VOLUMES"
_RESERVED_MATERIAL_PREFIXES = (
    "BUMP_",
    "COMPONENT_",
    "HM_",
    "MATERIAL_",
    "REGION_",
    "TEMPLATE_",
    "TRANSITION_",
)
_RESERVED_PHYSICAL_NAMES = {_ALL_SOLIDS_NAME, _TRANSITION_SOLIDS_NAME}


def _positive(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be a positive finite number")
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be a positive finite number") from error
    if not math.isfinite(parsed) or parsed <= 0.0:
        raise ValueError(f"{field_name} must be a positive finite number")
    return parsed


def _safe_token(value: str) -> str:
    token = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").upper()
    return token or "TEMPLATE"


def _material_token(material: str) -> str:
    raw = material.removeprefix("MATERIAL_") or material
    return _safe_token(raw)


def _template_token_from_source_group(source_group: str) -> str:
    matched = re.fullmatch(r"BUMP_[0-9]+_(?P<template>[A-Z0-9_]+)", source_group)
    if matched is None:
        raise RuntimeError(f"invalid internal bump source group: {source_group!r}")
    return matched.group("template")


def _template_set_physical_name(source_group: str, component: str) -> str:
    return (
        f"TEMPLATE_{_template_token_from_source_group(source_group)}_"
        f"{_material_token(component)}"
    )


def _hypermesh_component_physical_name(origin: str, component: str) -> str:
    return f"HM_{_material_token(component)}_{origin}"


def _validate_template_group_tokens(layout: BumpLayout) -> None:
    """Ensure MSH Physical Group names preserve every template identity."""

    alias_by_token: dict[str, str] = {}
    for template in layout.templates:
        token = _safe_token(template.alias)
        previous = alias_by_token.setdefault(token, template.alias)
        if previous != template.alias:
            raise ValueError(
                "mesh template aliases must remain unique after Physical Group "
                f"normalization: {previous!r} and {template.alias!r} both become "
                f"{token!r}"
            )


def normalize_material_name(
    value: object,
    *,
    field_name: str = "material",
) -> str:
    """Validate and return an exact, prefix-free material Physical Name.

    The legacy ``MATERIAL_`` prefix is accepted only as an input convenience;
    new MSH files always use the remaining material name verbatim.  This keeps
    Layer templates and their surrounding transition cells in the same
    Physical Group (for example ``USG`` or ``302``).
    """

    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError(
            f"{field_name} must be a non-empty, trimmed material name"
        )
    material = value
    if material.upper().startswith("MATERIAL_"):
        material = material[len("MATERIAL_") :]
    if not material or material != material.strip():
        raise ValueError(f"{field_name} has an empty legacy material suffix")
    if '"' in material or not material.isprintable():
        raise ValueError(
            f"{field_name} must contain only printable characters and no quote"
        )
    normalized = material.upper()
    if (
        normalized.startswith(_RESERVED_MATERIAL_PREFIXES)
        or normalized in _RESERVED_PHYSICAL_NAMES
    ):
        raise ValueError(
            f"{field_name} uses a reserved physical-group name: {value!r}"
        )
    return material


def _material_lookup_key(value: str) -> str:
    """Return a Unicode/case-insensitive key used only to resolve overrides."""

    return unicodedata.normalize("NFKC", value).casefold()


def _resolve_transition_material_overrides(
    template_slab_materials: Sequence[str],
    overrides: Mapping[str, str] | None,
) -> tuple[tuple[str, ...], tuple[tuple[str, str], ...]]:
    """Expand a validated source-material mapping over the exterior Z stack."""

    if overrides is None:
        return tuple(template_slab_materials), ()
    if not isinstance(overrides, Mapping):
        raise TypeError("transition_material_overrides must be a mapping or None")

    known_sources = set(template_slab_materials)
    normalized_source_candidates: dict[str, list[str]] = {}
    for template_source in sorted(known_sources):
        try:
            normalized_source = normalize_material_name(
                template_source,
                field_name="template edge material",
            )
        except ValueError:
            # Default generation still preserves legacy/noncanonical template
            # names.  Such a source simply cannot be selected through the
            # normalized override API unless it has a valid canonical form.
            continue
        normalized_source_candidates.setdefault(
            _material_lookup_key(normalized_source), []
        ).append(
            template_source
        )

    normalized_by_source: dict[str, str] = {}
    exterior_by_template_source: dict[str, str] = {}
    for raw_source, raw_exterior in overrides.items():
        source = normalize_material_name(
            raw_source,
            field_name="transition material override source",
        )
        exterior = normalize_material_name(
            raw_exterior,
            field_name="transition material override target",
        )
        candidates = normalized_source_candidates.get(_material_lookup_key(source), ())
        if not candidates:
            raise ValueError(
                f"unknown template edge material in transition override: {source}"
            )
        if len(candidates) != 1:
            rendered = ", ".join(repr(item) for item in candidates)
            raise ValueError(
                "ambiguous normalized template edge material in transition override: "
                f"{source} matches {rendered}"
            )
        canonical_source = candidates[0]
        if canonical_source in normalized_by_source:
            raise ValueError(
                "duplicate transition override for normalized source material "
                f"{canonical_source}"
            )
        normalized_by_source[canonical_source] = exterior
        exterior_by_template_source[canonical_source] = exterior
    transition_slab_materials = tuple(
        exterior_by_template_source.get(material, material)
        for material in template_slab_materials
    )
    return transition_slab_materials, tuple(sorted(normalized_by_source.items()))


def _material_name(names: Iterable[str], *, context: str) -> str:
    unique = tuple(sorted(set(str(name) for name in names if str(name))))
    candidates = tuple(
        name
        for name in unique
        if name not in {_ALL_SOLIDS_NAME, _TRANSITION_SOLIDS_NAME}
        and not name.startswith(("COMPONENT_", "HM_", "TEMPLATE_"))
        and not name.startswith("TRANSITION_")
    )
    if len(candidates) == 1:
        candidate = candidates[0]
        if candidate.startswith("MATERIAL_"):
            return normalize_material_name(candidate, field_name=context)
        return candidate
    rendered = ", ".join(unique) or "<none>"
    raise SampleMeshError(
        f"{context} 必须恰好映射到一个材料 Physical Group，实际为：{rendered}"
    )


def _component_name(names: Iterable[str], *, context: str) -> str:
    """Return the component token, with a legacy material-based fallback."""

    unique = tuple(sorted(set(str(name) for name in names if str(name))))
    explicit = tuple(
        name.removeprefix("COMPONENT_")
        for name in unique
        if name.startswith("COMPONENT_")
    )
    if len(explicit) == 1 and explicit[0]:
        return explicit[0]
    if not explicit:
        return _material_token(_material_name(unique, context=context))
    rendered = ", ".join(unique) or "<none>"
    raise SampleMeshError(
        f"{context} 必须恰好映射到一个 COMPONENT_* 物理组，实际为：{rendered}"
    )


def _xy_key(x: float, y: float) -> tuple[float, float]:
    return (round(x, _COORDINATE_KEY_DIGITS), round(y, _COORDINATE_KEY_DIGITS))


def _coordinate_key(x: float, y: float, z: float) -> tuple[float, float, float]:
    return (
        round(x, _COORDINATE_KEY_DIGITS),
        round(y, _COORDINATE_KEY_DIGITS),
        round(z, _COORDINATE_KEY_DIGITS),
    )


@dataclass(frozen=True, slots=True)
class _TemplateRing:
    """One template's native angular topology repeated on all source Z levels."""

    relative_xy: tuple[tuple[float, float], ...]
    node_tags_by_z: tuple[tuple[int, ...], ...]
    target_size_mm: float

    @property
    def node_count_per_level(self) -> int:
        return len(self.relative_xy)


@dataclass(frozen=True, slots=True)
class PlannedLayoutElement:
    """One immutable template element or newly extruded transition cell."""

    tag: int
    source_group: str
    component: str
    material: str
    gmsh_type: int
    node_tags: tuple[int, ...]
    placement_index: int | None

    def __post_init__(self) -> None:
        expected = {5: 8, 6: 6}.get(self.gmsh_type)
        if expected is None or len(self.node_tags) != expected:
            raise ValueError("layout elements must be first-order HEX8 or WEDGE6")
        if self.tag <= 0 or any(tag <= 0 for tag in self.node_tags):
            raise ValueError("layout node and element tags must be positive")
        if len(set(self.node_tags)) != len(self.node_tags):
            raise ValueError("a layout element must not repeat a node")
        if not self.source_group or not self.component or not self.material:
            raise ValueError(
                "layout element source, component, and material must not be empty"
            )

    @property
    def is_transition(self) -> bool:
        return self.source_group == _TRANSITION_SOURCE


@dataclass(frozen=True, slots=True)
class LayoutMeshPlan:
    """Complete component/material mesh plan before final Gmsh serialization."""

    layout: BumpLayout
    template_meshes: tuple[tuple[str, SampleMesh], ...]
    instances: tuple[SampleMeshInstance, ...]
    nodes: tuple[MeshNode, ...]
    elements: tuple[PlannedLayoutElement, ...]
    planar_mesh: PlanarTransitionMesh
    z_levels_mm: tuple[float, ...]
    void_slab_indices: tuple[int, ...]
    template_slab_components: tuple[str, ...]
    transition_slab_components: tuple[str, ...]
    template_slab_materials: tuple[str, ...]
    transition_slab_materials: tuple[str, ...]
    transition_material_overrides: tuple[tuple[str, str], ...]
    ring_node_counts: tuple[int, ...]
    interface_face_count: int
    interface_planar_min_sicn: float
    interface_planar_min_sige: float
    minimum_geometric_clearance_mm: float
    transition_only_node_count: int
    far_field_size_mm: float
    transition_distance_mm: float

    @property
    def node_count(self) -> int:
        return len(self.nodes)

    @property
    def element_count(self) -> int:
        return len(self.elements)

    @property
    def template_element_count(self) -> int:
        return sum(not element.is_transition for element in self.elements)

    @property
    def transition_element_count(self) -> int:
        return sum(element.is_transition for element in self.elements)

    @property
    def transition_hex_count(self) -> int:
        return sum(
            element.is_transition and element.gmsh_type == 5
            for element in self.elements
        )

    @property
    def transition_wedge_count(self) -> int:
        return sum(
            element.is_transition and element.gmsh_type == 6
            for element in self.elements
        )

    @property
    def material_element_counts(self) -> dict[str, int]:
        return dict(Counter(element.material for element in self.elements))

    @property
    def transition_material_element_counts(self) -> dict[str, int]:
        return dict(
            Counter(
                element.material for element in self.elements if element.is_transition
            )
        )

    @property
    def component_element_counts(self) -> dict[str, int]:
        return dict(Counter(element.component for element in self.elements))

    @property
    def slab_materials(self) -> tuple[str, ...]:
        """Compatibility alias for the effective exterior transition stack."""

        return self.transition_slab_materials

    @property
    def void_slab_intervals_mm(self) -> tuple[tuple[float, float], ...]:
        """Outer Z intervals intentionally left without transition elements."""

        return tuple(
            (self.z_levels_mm[index], self.z_levels_mm[index + 1])
            for index in self.void_slab_indices
        )


@dataclass(frozen=True, slots=True)
class LayoutBuildSummary:
    mesh_path: str
    report_path: str
    parameters_path: str
    strategy: str
    bump_count: int
    template_aliases: tuple[str, ...]
    ring_node_counts: tuple[int, ...]
    z_levels_um: tuple[float, ...]
    void_slab_intervals_um: tuple[tuple[float, float], ...]
    template_slab_components: tuple[str, ...]
    transition_slab_components: tuple[str, ...]
    template_slab_materials: tuple[str, ...]
    transition_slab_materials: tuple[str, ...]
    transition_material_overrides: tuple[tuple[str, str], ...]
    node_count: int
    element_count: int
    template_element_count: int
    transition_element_count: int
    transition_hex_count: int
    transition_wedge_count: int
    hex_count: int
    wedge_count: int
    volume_count: int
    two_dimensional_element_count: int
    interface_face_count: int
    minimum_geometric_clearance_um: float
    transition_only_node_count: int
    physical_volume_groups: dict[str, int]
    bump_physical_groups: dict[str, int]
    template_set_physical_groups: dict[str, int]
    hypermesh_component_physical_groups: dict[str, int]
    transition_physical_groups: dict[str, int]
    material_element_counts: dict[str, int]
    transition_material_element_counts: dict[str, int]
    planar_node_count: int
    planar_triangle_count: int
    planar_quad_count: int
    structured_region_count: int
    planar_min_sicn: float
    planar_min_sige: float
    interface_planar_min_sicn: float
    interface_planar_min_sige: float
    planar_minimum_edge_um: float
    planar_maximum_edge_um: float
    min_scaled_jacobian: float
    p01_scaled_jacobian: float
    median_scaled_jacobian: float
    min_sicn: float
    min_sige: float
    min_jacobian_determinant: float
    template_min_scaled_jacobian: float
    template_min_sicn: float
    template_min_sige: float
    template_min_jacobian_determinant: float
    transition_min_scaled_jacobian: float
    transition_min_sicn: float
    transition_min_sige: float
    transition_min_jacobian_determinant: float
    duplicate_node_count: int
    template_connectivity_preserved: bool
    component_surface_heights_preserved: bool
    interface_conformal: bool
    interface_exterior_material_assignment_verified: bool
    structured_region_bounds_preserved: bool
    structured_region_xy_sizes_preserved: bool
    structured_region_hex8_only: bool
    structured_region_z_surfaces_preserved: bool
    structured_region_transition_interface_conformal: bool
    structured_region_material_assignment_verified: bool
    written_mesh_reopened_verified: bool
    quality_warnings: tuple[str, ...]
    quality_advisories: tuple[str, ...]
    quality_classification: str

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        for key in (
            "template_aliases",
            "ring_node_counts",
            "z_levels_um",
            "template_slab_components",
            "transition_slab_components",
            "template_slab_materials",
            "transition_slab_materials",
            "quality_warnings",
            "quality_advisories",
        ):
            data[key] = list(data[key])
        data["void_slab_intervals_um"] = [
            list(interval) for interval in self.void_slab_intervals_um
        ]
        data["slab_materials"] = list(self.transition_slab_materials)
        data["transition_material_overrides"] = dict(
            self.transition_material_overrides
        )
        return data

    @property
    def slab_materials(self) -> tuple[str, ...]:
        """Compatibility alias for the effective exterior transition stack."""

        return self.transition_slab_materials


def _ordered_template_ring(template: SampleMesh) -> _TemplateRing:
    outer = template.outer_boundary
    node_by_tag = template.node_map()
    if len(outer.z_levels) < 2 or not outer.surface_intervals:
        raise SampleMeshError(f"模板没有完整外缘层：{template.source_path}")
    if tuple(level for level, _ in outer.node_tags_by_z) != outer.z_levels:
        raise SampleMeshError(f"模板外缘 node-tags-by-z 不完整：{template.source_path}")

    first_tags = next(
        (tags for _z_level, tags in outer.node_tags_by_z if tags),
        (),
    )
    if len(first_tags) < 8:
        raise SampleMeshError(f"模板外缘每层至少需要 8 个节点：{template.source_path}")
    center_x, center_y = outer.center_xy

    radial_tolerance = max(outer.radius * 1.0e-8, 1.0e-12)
    outer_extent_levels = {outer.z_levels[0], outer.z_levels[-1]}
    void_boundary_levels = {
        level for interval in outer.void_intervals for level in interval
    }

    def bounds_declared_air_gap(face_nodes: Sequence[MeshNode]) -> bool:
        radii = tuple(
            math.hypot(node.x - center_x, node.y - center_y)
            for node in face_nodes
        )
        z_values = tuple(node.z for node in face_nodes)
        horizontal = max(z_values) - min(z_values) <= _GEOMETRY_TOLERANCE_MM
        for radius_min, radius_max, z_min, z_max in outer.declared_air_gap_regions:
            within_radial_footprint = all(
                radius_min - radial_tolerance
                <= radius
                <= radius_max + radial_tolerance
                for radius in radii
            )
            on_horizontal_boundary = horizontal and within_radial_footprint and (
                abs(z_values[0] - z_min) <= _GEOMETRY_TOLERANCE_MM
                or abs(z_values[0] - z_max) <= _GEOMETRY_TOLERANCE_MM
            )
            within_vertical_span = all(
                z_min - _GEOMETRY_TOLERANCE_MM
                <= value
                <= z_max + _GEOMETRY_TOLERANCE_MM
                for value in z_values
            )
            on_radial_boundary = within_vertical_span and (
                all(abs(radius - radius_min) <= radial_tolerance for radius in radii)
                or all(abs(radius - radius_max) <= radial_tolerance for radius in radii)
            )
            if on_horizontal_boundary or on_radial_boundary:
                return True
        return False

    for face in template.boundary_faces:
        face_nodes = tuple(node_by_tag[tag] for tag in face.node_tags)
        # Horizontal faces on either side of an explicit air gap are valid
        # exterior skin, not an internal crack in the material union.
        horizontal = all(
            node.z == face_nodes[0].z for node in face_nodes[1:]
        )
        horizontal_exterior = horizontal and face_nodes[0].z in (
            outer_extent_levels | void_boundary_levels
        )
        lateral_exterior = all(
            abs(math.hypot(node.x - center_x, node.y - center_y) - outer.radius)
            <= radial_tolerance
            for node in face_nodes
        )
        if (
            not horizontal_exterior
            and not lateral_exterior
            and not bounds_declared_air_gap(face_nodes)
        ):
            raise SampleMeshError(
                "模板体并集包含不属于顶面、底面或外缘的自由面；"
                f"可能存在内部裂缝：{template.source_path}"
            )

    def relative_xy(tag: int) -> tuple[float, float]:
        node = node_by_tag[tag]
        return (node.x - center_x, node.y - center_y)

    ordered_first = tuple(
        sorted(
            first_tags,
            key=lambda tag: math.atan2(relative_xy(tag)[1], relative_xy(tag)[0])
            % (2.0 * math.pi),
        )
    )
    base_xy = tuple(relative_xy(tag) for tag in ordered_first)
    twice_area = sum(
        base_xy[index][0] * base_xy[(index + 1) % len(base_xy)][1]
        - base_xy[(index + 1) % len(base_xy)][0] * base_xy[index][1]
        for index in range(len(base_xy))
    )
    if twice_area <= 0.0:
        raise SampleMeshError(f"模板外缘角向顺序不是逆时针：{template.source_path}")

    base_keys = tuple(_xy_key(*point) for point in base_xy)
    if len(set(base_keys)) != len(base_keys):
        raise SampleMeshError(f"模板外缘包含重合 XY 节点：{template.source_path}")
    ordered_by_z: list[tuple[int, ...]] = []
    for z_level, tags in outer.node_tags_by_z:
        if not tags:
            ordered_by_z.append(())
            continue
        if len(tags) != len(first_tags):
            raise SampleMeshError(
                f"模板不同 Z 层的外缘角向节点数不一致：{template.source_path}"
            )
        keyed: dict[tuple[float, float], int] = {}
        for tag in tags:
            node = node_by_tag[tag]
            if node.z != z_level:
                raise SampleMeshError(
                    f"模板外缘节点高度与所属 Z 层不一致：{template.source_path}"
                )
            key = _xy_key(node.x - center_x, node.y - center_y)
            if key in keyed:
                raise SampleMeshError(
                    f"模板同一 Z 层包含重合外缘节点：{template.source_path}"
                )
            keyed[key] = tag
        if set(keyed) != set(base_keys):
            raise SampleMeshError(
                "模板外缘必须是无缩放、无扭转的直挤出；"
                f"XY ring 在 z={z_level:g} mm 发生变化：{template.source_path}"
            )
        ordered_by_z.append(tuple(keyed[key] for key in base_keys))

    expected_by_slab: list[set[tuple[int, ...]] | None] = []
    for z_index in range(len(outer.z_levels) - 1):
        lower = ordered_by_z[z_index]
        upper = ordered_by_z[z_index + 1]
        if not lower or not upper:
            expected_by_slab.append(None)
            continue
        expected_by_slab.append(
            {
                tuple(
                    sorted(
                        (
                            lower[index],
                            lower[(index + 1) % len(lower)],
                            upper[(index + 1) % len(upper)],
                            upper[index],
                        )
                    )
                )
                for index in range(len(lower))
            }
        )

    interval_by_bounds = {
        (interval.z_min, interval.z_max): interval
        for interval in outer.surface_intervals
    }
    if len(interval_by_bounds) != len(outer.surface_intervals):
        raise SampleMeshError(f"模板外缘包含重复 Z interval：{template.source_path}")
    expected_bounds = {
        (outer.z_levels[index], outer.z_levels[index + 1])
        for index in range(len(outer.z_levels) - 1)
    }
    declared_void_bounds = set(outer.void_intervals)
    unexpected = set(interval_by_bounds).difference(expected_bounds)
    if unexpected:
        raise SampleMeshError(
            f"模板外缘 component surface 高度顺序不一致：{template.source_path}"
        )
    for z_index, expected_faces in enumerate(expected_by_slab):
        bounds = (outer.z_levels[z_index], outer.z_levels[z_index + 1])
        interval = interval_by_bounds.get(bounds)
        if interval is None:
            if bounds not in declared_void_bounds:
                raise SampleMeshError(
                    "模板体并集存在未由可信 air-gap 旁车声明的缺失外缘侧壁；"
                    f"可能存在内部裂缝：{template.source_path}, interval={bounds}"
                )
            continue
        if expected_faces is None:
            raise SampleMeshError(
                f"模板外缘实体 interval 缺少端点 XY ring：{template.source_path}"
            )
        if any(len(face) != 4 for face in interval.face_node_tags):
            raise SampleMeshError(
                f"模板外缘必须全部由 QUAD4 构成：{template.source_path}"
            )
        actual = {tuple(sorted(face)) for face in interval.face_node_tags}
        if actual != expected_faces:
            raise SampleMeshError(
                "模板外缘 QUAD4 必须逐边连接相邻的原始 Z surface："
                f"{template.source_path}"
            )

    chord_lengths = tuple(
        math.hypot(
            base_xy[index][0] - base_xy[(index + 1) % len(base_xy)][0],
            base_xy[index][1] - base_xy[(index + 1) % len(base_xy)][1],
        )
        for index in range(len(base_xy))
    )
    return _TemplateRing(
        relative_xy=base_xy,
        node_tags_by_z=tuple(ordered_by_z),
        target_size_mm=statistics.fmean(chord_lengths),
    )


def _validate_template_library(
    templates: Sequence[tuple[str, SampleMesh]],
    rings: Mapping[str, _TemplateRing],
) -> tuple[
    tuple[float, ...],
    tuple[str, ...],
    tuple[str, ...],
    tuple[int, ...],
]:
    if not templates:
        raise ValueError("layout must contain at least one template")
    reference_alias, reference = templates[0]
    reference_levels = reference.outer_boundary.z_levels
    reference_identities = {
        (
            _component_name(
                element.physical_names,
                context=f"模板 {reference_alias} element {element.tag}",
            ),
            _material_name(
                element.physical_names,
                context=f"模板 {reference_alias} element {element.tag}",
            ),
        )
        for element in reference.elements
    }

    def aligned_stack(
        alias: str,
        template: SampleMesh,
    ) -> tuple[tuple[str, str] | None, ...]:
        outer = template.outer_boundary
        interval_by_bounds = {
            (interval.z_min, interval.z_max): interval
            for interval in outer.surface_intervals
        }
        return tuple(
            (
                (
                    _component_name(
                        interval_by_bounds[(z_min, z_max)].physical_names,
                        context=f"模板 {alias} 外缘 interval",
                    ),
                    _material_name(
                        interval_by_bounds[(z_min, z_max)].physical_names,
                        context=f"模板 {alias} 外缘 interval",
                    ),
                )
                if (z_min, z_max) in interval_by_bounds
                else None
            )
            for z_min, z_max in zip(outer.z_levels, outer.z_levels[1:])
        )

    reference_stack = aligned_stack(reference_alias, reference)
    for alias, template in templates:
        outer = template.outer_boundary
        if outer.z_levels != reference_levels:
            raise SampleMeshError(
                f"模板 {alias} 改变了外缘 component surface 的精确高度"
            )
        stack = aligned_stack(alias, template)
        if stack != reference_stack:
            raise SampleMeshError(
                f"模板 {alias} 的外缘 component/material stack 与 {reference_alias} 不一致"
            )
        identities = {
            (
                _component_name(
                    element.physical_names,
                    context=f"模板 {alias} element {element.tag}",
                ),
                _material_name(
                    element.physical_names,
                    context=f"模板 {alias} element {element.tag}",
                ),
            )
            for element in template.elements
        }
        if identities != reference_identities:
            raise SampleMeshError(
                f"模板 {alias} 的内部 component/material 集合与 "
                f"{reference_alias} 不一致"
            )
        if alias not in rings:
            raise RuntimeError(f"missing native ring data for template {alias}")
    return (
        reference_levels,
        tuple(
            identity[0] for identity in reference_stack if identity is not None
        ),
        tuple(
            identity[1] for identity in reference_stack if identity is not None
        ),
        tuple(
            index for index, identity in enumerate(reference_stack) if identity is None
        ),
    )


def _add_unique_node(nodes: dict[int, MeshNode], node: MeshNode) -> None:
    if node.tag in nodes:
        raise RuntimeError(f"duplicate global node tag {node.tag}")
    nodes[node.tag] = node


def _validate_interface_faces(
    instances: Sequence[SampleMeshInstance],
    elements: Sequence[PlannedLayoutElement],
    z_levels: Sequence[float],
    exterior_slab_components: Sequence[str],
    exterior_slab_materials: Sequence[str],
    void_slab_indices: Sequence[int],
) -> int:
    void_indices = set(void_slab_indices)
    solid_indices = tuple(
        index for index in range(len(z_levels) - 1) if index not in void_indices
    )
    if not (
        len(exterior_slab_components)
        == len(exterior_slab_materials)
        == len(solid_indices)
    ):
        raise RuntimeError(
            "exterior slab component/material count does not match non-void Z slabs"
        )
    expected_by_interval = {
        (z_levels[index], z_levels[index + 1]): (component, material)
        for index, component, material in zip(
            solid_indices,
            exterior_slab_components,
            exterior_slab_materials,
            strict=True,
        )
    }
    template_faces: dict[
        tuple[int, ...], tuple[str, str, str, str, tuple[int, ...]]
    ] = {}
    for placement_index, instance in enumerate(instances):
        for interval in instance.outer_boundary.surface_intervals:
            template_component = _component_name(
                interval.physical_names,
                context=f"bump {placement_index} outer surface",
            )
            template_material = _material_name(
                interval.physical_names,
                context=f"bump {placement_index} outer surface",
            )
            interval_key = (interval.z_min, interval.z_max)
            try:
                expected_exterior_component, expected_exterior_material = (
                    expected_by_interval[interval_key]
                )
            except KeyError as error:
                raise RuntimeError(
                    "template outer interval does not match the source Z slab stack: "
                    f"{interval_key}"
                ) from error
            for face in interval.face_node_tags:
                key = tuple(sorted(face))
                if key in template_faces:
                    raise RuntimeError("two template cells claim the same outer interface face")
                template_faces[key] = (
                    template_component,
                    template_material,
                    expected_exterior_component,
                    expected_exterior_material,
                    face,
                )

    transition_faces: dict[
        tuple[int, ...], tuple[str, str, tuple[int, ...]]
    ] = {}
    for element in elements:
        if not element.is_transition:
            continue
        local_quad_faces = {
            5: ((0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)),
            6: ((0, 1, 4, 3), (1, 2, 5, 4), (2, 0, 3, 5)),
        }[element.gmsh_type]
        for local_face in local_quad_faces:
            face = tuple(element.node_tags[index] for index in local_face)
            key = tuple(sorted(face))
            if key not in template_faces:
                continue
            if key in transition_faces:
                raise RuntimeError(
                    "two transition cells claim the same bump interface face"
                )
            transition_faces[key] = (element.component, element.material, face)

    if set(template_faces) != set(transition_faces):
        missing = set(template_faces).difference(transition_faces)
        extra = set(transition_faces).difference(template_faces)
        raise RuntimeError(
            "template/transition interface is not conformal: "
            f"missing={len(missing)}, extra={len(extra)}"
        )
    for key, (
        template_component,
        template_material,
        expected_exterior_component,
        expected_exterior_material,
        template_face,
    ) in template_faces.items():
        transition_component, transition_material, transition_face = transition_faces[key]
        if (
            transition_component != expected_exterior_component
            or transition_material != expected_exterior_material
        ):
            raise RuntimeError(
                "template/transition interface exterior component/material mismatch: "
                f"template={template_component}/{template_material}, expected exterior="
                f"{expected_exterior_component}/{expected_exterior_material}, actual="
                f"{transition_component}/{transition_material}"
            )
        reversed_template = tuple(reversed(template_face))
        opposite = any(
            transition_face
            == reversed_template[offset:] + reversed_template[:offset]
            for offset in range(len(reversed_template))
        )
        if not opposite:
            raise RuntimeError(
                "template/transition interface faces do not have opposite orientation"
            )
    return len(template_faces)


def _interface_planar_quality(mesh: PlanarTransitionMesh) -> tuple[float, float]:
    boundary_edges: set[tuple[int, int]] = set()
    for ring in mesh.ring_node_indices:
        for index, first in enumerate(ring):
            second = ring[(index + 1) % len(ring)]
            boundary_edges.add(
                (first, second) if first < second else (second, first)
            )
    adjacent_indices: list[int] = []
    for triangle_index, triangle in enumerate(mesh.triangles):
        edges = (
            (triangle[0], triangle[1]),
            (triangle[1], triangle[2]),
            (triangle[2], triangle[0]),
        )
        if any(
            ((first, second) if first < second else (second, first))
            in boundary_edges
            for first, second in edges
        ):
            adjacent_indices.append(triangle_index)
    if not adjacent_indices:
        raise RuntimeError("planar transition has no cells adjacent to a bump ring")
    return (
        min(mesh.triangle_sicn[index] for index in adjacent_indices),
        min(mesh.triangle_sige[index] for index in adjacent_indices),
    )


def _validate_transition_extrusion_faces(
    mesh: PlanarTransitionMesh,
    planar_tag_by_level: Sequence[Sequence[int]],
    solid_slab_indices: Sequence[int],
    elements: Sequence[PlannedLayoutElement],
) -> None:
    """Prove that every extruded planar edge has the expected 3-D side face."""

    planar_edge_counts: Counter[tuple[int, int]] = Counter()
    for cell in (*mesh.triangles, *mesh.quads):
        for index, first in enumerate(cell):
            second = cell[(index + 1) % len(cell)]
            planar_edge_counts[
                (first, second) if first < second else (second, first)
            ] += 1

    expected_faces: Counter[tuple[int, ...]] = Counter()
    for slab_index in solid_slab_indices:
        lower = planar_tag_by_level[slab_index]
        upper = planar_tag_by_level[slab_index + 1]
        for (first, second), count in planar_edge_counts.items():
            expected_faces[
                tuple(
                    sorted(
                        (
                            lower[first],
                            lower[second],
                            upper[first],
                            upper[second],
                        )
                    )
                )
            ] = count

    actual_faces: Counter[tuple[int, ...]] = Counter()
    local_faces_by_type = {
        5: ((0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)),
        6: ((0, 1, 4, 3), (1, 2, 5, 4), (2, 0, 3, 5)),
    }
    for element in elements:
        if not element.is_transition:
            continue
        for local_face in local_faces_by_type[element.gmsh_type]:
            actual_faces[
                tuple(sorted(element.node_tags[index] for index in local_face))
            ] += 1
    if actual_faces != expected_faces:
        raise RuntimeError(
            "extruded TRI3/QUAD4 transition side faces are not exactly conformal"
        )


def _minimum_geometric_clearance(
    layout: BumpLayout,
    template_by_alias: Mapping[str, SampleMesh],
) -> float:
    clearances: list[float] = []
    for placement in layout.instances:
        radius = template_by_alias[placement.template_alias].outer_boundary.radius
        clearances.extend(
            (
                placement.x_mm - layout.bounds.x_min_mm - radius,
                layout.bounds.x_max_mm - placement.x_mm - radius,
                placement.y_mm - layout.bounds.y_min_mm - radius,
                layout.bounds.y_max_mm - placement.y_mm - radius,
            )
        )
    for first_index, first in enumerate(layout.instances):
        first_radius = template_by_alias[first.template_alias].outer_boundary.radius
        for second in layout.instances[first_index + 1 :]:
            second_radius = template_by_alias[
                second.template_alias
            ].outer_boundary.radius
            clearances.append(
                math.hypot(first.x_mm - second.x_mm, first.y_mm - second.y_mm)
                - first_radius
                - second_radius
            )
    minimum = min(clearances)
    if minimum <= _GEOMETRY_TOLERANCE_MM:
        raise RuntimeError(
            "模板 footprint 相切、重叠或越出 XY 过渡域，无法形成过渡区域："
            f"有符号净空={minimum * 1000:g}um"
        )
    return minimum


def plan_layout_mesh(
    layout: BumpLayout | str | Path,
    *,
    far_field_size_um: float = 80.0,
    transition_distance_um: float = 120.0,
    transition_material_overrides: Mapping[str, str] | None = None,
    verbose: bool = False,
) -> LayoutMeshPlan:
    """Create a conformal template-plus-transition volume plan.

    Different template diameters and native angular node counts are supported
    directly. Compatibility concerns each template's valid extruded ring,
    exact Z levels, and the source edge component stack—not identical radius or
    outer-ring topology.
    A source-material mapping may independently change the exterior transition
    material without changing any template element, node, or Z surface.
    """

    resolved_layout = load_bump_layout(layout) if isinstance(layout, (str, Path)) else layout
    if not isinstance(resolved_layout, BumpLayout):
        raise TypeError("layout must be a BumpLayout or .loc path")
    _validate_template_group_tokens(resolved_layout)
    far_field_size_mm = _positive(
        far_field_size_um, field_name="far_field_size_um"
    ) * 1.0e-3
    transition_distance_mm = _positive(
        transition_distance_um, field_name="transition_distance_um"
    ) * 1.0e-3

    loaded_templates = tuple(
        (template.alias, load_sample_mesh(template.mesh_path))
        for template in resolved_layout.templates
    )
    template_by_alias = dict(loaded_templates)
    native_rings = {
        alias: _ordered_template_ring(template)
        for alias, template in loaded_templates
    }
    (
        z_levels,
        template_slab_components,
        template_slab_materials,
        void_slab_indices,
    ) = _validate_template_library(loaded_templates, native_rings)
    void_slab_index_set = set(void_slab_indices)
    solid_slab_indices = tuple(
        index
        for index in range(len(z_levels) - 1)
        if index not in void_slab_index_set
    )
    if not (
        len(solid_slab_indices)
        == len(template_slab_components)
        == len(template_slab_materials)
    ):
        raise RuntimeError("template solid/void outer slab accounting is inconsistent")
    transition_slab_components = template_slab_components
    transition_slab_materials, normalized_material_overrides = (
        _resolve_transition_material_overrides(
            template_slab_materials,
            transition_material_overrides,
        )
    )
    minimum_geometric_clearance_mm = _minimum_geometric_clearance(
        resolved_layout, template_by_alias
    )

    instances: list[SampleMeshInstance] = []
    ring_tags_by_instance: list[tuple[tuple[int, ...], ...]] = []
    transition_rings: list[TransitionRing] = []
    nodes_by_tag: dict[int, MeshNode] = {}
    elements: list[PlannedLayoutElement] = []
    next_node_tag = 1
    next_element_tag = 1
    next_entity_tag = 1

    for placement_index, placement in enumerate(resolved_layout.instances):
        template = template_by_alias[placement.template_alias]
        native_ring = native_rings[placement.template_alias]
        dx = placement.x_mm - template.outer_boundary.center_xy[0]
        dy = placement.y_mm - template.outer_boundary.center_xy[1]
        instance = instantiate_sample_mesh(
            template,
            dx,
            dy,
            node_tag_start=next_node_tag,
            element_tag_start=next_element_tag,
            entity_tag_start=next_entity_tag,
        )
        instances.append(instance)
        next_node_tag = max(instance.node_tag_map.values()) + 1
        next_element_tag = max(instance.element_tag_map.values()) + 1
        next_entity_tag = max(instance.entity_tag_map.values()) + 1

        source_group = f"BUMP_{placement_index:04d}_{_safe_token(placement.template_alias)}"
        for source_node, instance_node in zip(template.nodes, instance.nodes):
            if instance_node.z != source_node.z:
                raise RuntimeError("template instantiation changed a source Z coordinate")
            if (
                instance_node.x != source_node.x + dx
                or instance_node.y != source_node.y + dy
            ):
                raise RuntimeError("template instantiation changed more than XY translation")
            _add_unique_node(nodes_by_tag, instance_node)
        for source_element, instance_element in zip(
            template.elements, instance.elements
        ):
            expected_connectivity = tuple(
                instance.node_tag_map[tag] for tag in source_element.node_tags
            )
            if instance_element.node_tags != expected_connectivity:
                raise RuntimeError("template element connectivity was not preserved")
            elements.append(
                PlannedLayoutElement(
                    tag=instance_element.tag,
                    source_group=source_group,
                    component=_component_name(
                        instance_element.physical_names,
                        context=(
                            f"bump {placement_index} template element "
                            f"{instance_element.tag}"
                        ),
                    ),
                    material=_material_name(
                        instance_element.physical_names,
                        context=(
                            f"bump {placement_index} template element "
                            f"{instance_element.tag}"
                        ),
                    ),
                    gmsh_type=instance_element.gmsh_type,
                    node_tags=instance_element.node_tags,
                    placement_index=placement_index,
                )
            )

        global_tags_by_z = tuple(
            tuple(instance.node_tag_map[tag] for tag in level_tags)
            for level_tags in native_ring.node_tags_by_z
        )
        ring_tags_by_instance.append(global_tags_by_z)
        ring_coordinates = tuple(
            (placement.x_mm + relative_x, placement.y_mm + relative_y)
            for relative_x, relative_y in native_ring.relative_xy
        )
        transition_rings.append(
            TransitionRing(
                placement_index=placement_index,
                coordinates_mm=ring_coordinates,
                target_size_mm=native_ring.target_size_mm,
            )
        )

    planar_mesh = generate_planar_transition_mesh(
        resolved_layout.bounds,
        transition_rings,
        structured_regions=resolved_layout.mesh_regions,
        far_field_size_mm=far_field_size_mm,
        transition_distance_mm=transition_distance_mm,
        verbose=verbose,
    )
    if (
        planar_mesh.minimum_sicn < _MIN_TRANSITION_SHAPE_QUALITY
        or planar_mesh.minimum_sige < _MIN_TRANSITION_SHAPE_QUALITY
    ):
        raise RuntimeError(
            "planar transition shape quality is below 0.30: "
            f"minSICN={planar_mesh.minimum_sicn:.6g}, "
            f"minSIGE={planar_mesh.minimum_sige:.6g}"
        )

    interface_planar_min_sicn, interface_planar_min_sige = (
        _interface_planar_quality(planar_mesh)
    )
    interface_node_tag: dict[tuple[int, int], int] = {}
    for ring_index, (planar_indices, global_tags_by_z) in enumerate(
        zip(planar_mesh.ring_node_indices, ring_tags_by_instance)
    ):
        populated_ring = next((tags for tags in global_tags_by_z if tags), ())
        if len(planar_indices) != len(populated_ring):
            raise RuntimeError("Gmsh changed a native template-ring node count")
        for z_index, level_tags in enumerate(global_tags_by_z):
            if not level_tags:
                continue
            if len(level_tags) != len(planar_indices):
                raise RuntimeError("template ring node count changes across Z levels")
            for angular_index, planar_index in enumerate(planar_indices):
                tag = level_tags[angular_index]
                key = (planar_index, z_index)
                if key in interface_node_tag:
                    raise RuntimeError("two bump rings share a planar interface node")
                interface_node_tag[key] = tag
                node = nodes_by_tag[tag]
                x, y = planar_mesh.coordinates_mm[planar_index]
                if (
                    abs(node.x - x) > _GEOMETRY_TOLERANCE_MM
                    or abs(node.y - y) > _GEOMETRY_TOLERANCE_MM
                    or node.z != z_levels[z_index]
                ):
                    raise RuntimeError(
                        f"Gmsh moved bump {ring_index} interface coordinates"
                    )

    coordinate_owner = {
        _coordinate_key(node.x, node.y, node.z): node.tag
        for node in nodes_by_tag.values()
    }
    planar_tag_by_level: list[tuple[int, ...]] = []
    transition_only_node_count = 0
    active_transition_levels = {
        level_index
        for slab_index in solid_slab_indices
        for level_index in (slab_index, slab_index + 1)
    }
    for z_index, z_level in enumerate(z_levels):
        if z_index not in active_transition_levels:
            planar_tag_by_level.append(())
            continue
        level_tags: list[int] = []
        for planar_index, (x, y) in enumerate(planar_mesh.coordinates_mm):
            existing_tag = interface_node_tag.get((planar_index, z_index))
            if existing_tag is not None:
                level_tags.append(existing_tag)
                continue
            coordinate_key = _coordinate_key(x, y, z_level)
            if coordinate_key in coordinate_owner:
                raise RuntimeError(
                    "a transition node unexpectedly overlaps a non-interface template node"
                )
            node = MeshNode(next_node_tag, x, y, z_level)
            _add_unique_node(nodes_by_tag, node)
            coordinate_owner[coordinate_key] = next_node_tag
            level_tags.append(next_node_tag)
            next_node_tag += 1
            transition_only_node_count += 1
        planar_tag_by_level.append(tuple(level_tags))

    for z_index, component, material in zip(
        solid_slab_indices,
        transition_slab_components,
        transition_slab_materials,
        strict=True,
    ):
        lower = planar_tag_by_level[z_index]
        upper = planar_tag_by_level[z_index + 1]
        for triangle in planar_mesh.triangles:
            connectivity = (
                lower[triangle[0]],
                lower[triangle[1]],
                lower[triangle[2]],
                upper[triangle[0]],
                upper[triangle[1]],
                upper[triangle[2]],
            )
            elements.append(
                PlannedLayoutElement(
                    tag=next_element_tag,
                    source_group=_TRANSITION_SOURCE,
                    component=component,
                    material=material,
                    gmsh_type=6,
                    node_tags=connectivity,
                    placement_index=None,
                )
            )
            next_element_tag += 1
        for quad in planar_mesh.quads:
            connectivity = (
                lower[quad[0]],
                lower[quad[1]],
                lower[quad[2]],
                lower[quad[3]],
                upper[quad[0]],
                upper[quad[1]],
                upper[quad[2]],
                upper[quad[3]],
            )
            elements.append(
                PlannedLayoutElement(
                    tag=next_element_tag,
                    source_group=_TRANSITION_SOURCE,
                    component=component,
                    material=material,
                    gmsh_type=5,
                    node_tags=connectivity,
                    placement_index=None,
                )
            )
            next_element_tag += 1

    _validate_transition_extrusion_faces(
        planar_mesh,
        planar_tag_by_level,
        solid_slab_indices,
        elements,
    )
    interface_face_count = _validate_interface_faces(
        instances,
        elements,
        z_levels,
        transition_slab_components,
        transition_slab_materials,
        void_slab_indices,
    )
    if len(nodes_by_tag) != len(coordinate_owner):
        raise RuntimeError("combined layout plan contains duplicate node coordinates")

    return LayoutMeshPlan(
        layout=resolved_layout,
        template_meshes=loaded_templates,
        instances=tuple(instances),
        nodes=tuple(nodes_by_tag[tag] for tag in sorted(nodes_by_tag)),
        elements=tuple(sorted(elements, key=lambda element: element.tag)),
        planar_mesh=planar_mesh,
        z_levels_mm=z_levels,
        void_slab_indices=void_slab_indices,
        template_slab_components=template_slab_components,
        transition_slab_components=transition_slab_components,
        template_slab_materials=template_slab_materials,
        transition_slab_materials=transition_slab_materials,
        transition_material_overrides=normalized_material_overrides,
        ring_node_counts=tuple(
            native_rings[placement.template_alias].node_count_per_level
            for placement in resolved_layout.instances
        ),
        interface_face_count=interface_face_count,
        interface_planar_min_sicn=interface_planar_min_sicn,
        interface_planar_min_sige=interface_planar_min_sige,
        minimum_geometric_clearance_mm=minimum_geometric_clearance_mm,
        transition_only_node_count=transition_only_node_count,
        far_field_size_mm=far_field_size_mm,
        transition_distance_mm=transition_distance_mm,
    )


def _validate_layout_physical_group_names(plan: LayoutMeshPlan) -> None:
    """Keep MSH and legacy HyperMesh CDB names exact and collision-free."""

    materials = tuple(sorted(plan.material_element_counts))
    template_pairs = tuple(
        sorted(
            {
                (
                    _template_token_from_source_group(element.source_group),
                    element.component,
                )
                for element in plan.elements
                if not element.is_transition
            }
        )
    )
    transition_materials = tuple(sorted(plan.transition_material_element_counts))
    specifications: list[tuple[tuple[str, ...], str]] = [
        (("MATERIAL", material), material) for material in materials
    ]
    specifications.extend(
        (
            ("TEMPLATE_SET", template_alias, component_token),
            f"TEMPLATE_{template_alias}_{component_token}",
        )
        for template_alias, component_token in template_pairs
    )
    if transition_materials:
        specifications.append(
            (("TRANSITION_SET", "ALL"), _TRANSITION_SOLIDS_NAME)
        )
    components = tuple(sorted(plan.component_element_counts))
    for component in components:
        if any(
            not element.is_transition and element.component == component
            for element in plan.elements
        ):
            specifications.append(
                (
                    ("HM_COMPONENT", "TEMPLATE", component),
                    _hypermesh_component_physical_name("TEMPLATE", component),
                )
            )
        if any(
            element.is_transition and element.component == component
            for element in plan.elements
        ):
            specifications.append(
                (
                    ("HM_COMPONENT", "TRANSITION", component),
                    _hypermesh_component_physical_name("TRANSITION", component),
                )
            )
    specifications.append((("GLOBAL_SET", "ALL"), _ALL_SOLIDS_NAME))

    # A HyperMesh component can bind only one material.  Template and
    # transition origins are intentionally independent so an exterior material
    # override can change the transition side without modifying the template.
    materials_by_origin_component: dict[tuple[str, str], set[str]] = {}
    for element in plan.elements:
        origin = "TRANSITION" if element.is_transition else "TEMPLATE"
        materials_by_origin_component.setdefault(
            (origin, element.component), set()
        ).add(element.material)
    ambiguous_components = {
        identity: tuple(sorted(material_names))
        for identity, material_names in materials_by_origin_component.items()
        if len(material_names) != 1
    }
    if ambiguous_components:
        raise ValueError(
            "each template/transition component must bind exactly one material: "
            f"{ambiguous_components}"
        )

    identity_by_name: dict[str, tuple[str, ...]] = {}
    for identity, name in specifications:
        is_material = identity[0] == "MATERIAL"
        valid_name = (
            bool(name)
            and name == name.strip()
            and '"' not in name
            and name.isprintable()
            and (
                is_material
                or (
                    len(name) <= 32
                    and re.fullmatch(r"[A-Z][A-Z0-9_]*", name) is not None
                )
            )
        )
        if not valid_name:
            raise ValueError(
                "layout material names must be trimmed printable strings without a "
                "quote; generated Set/Component names must match [A-Z][A-Z0-9_]* "
                f"and stay within 32 characters: {name!r}"
            )
        previous = identity_by_name.setdefault(name, identity)
        if previous != identity:
            raise ValueError(
                "layout Physical Group name collision after normalization: "
                f"{previous!r} and {identity!r} both become {name!r}"
            )


def _add_discrete_mesh(
    gmsh: Any,
    plan: LayoutMeshPlan,
) -> tuple[
    dict[str, int],
    dict[str, int],
    dict[str, int],
    dict[str, int],
]:
    _validate_layout_physical_group_names(plan)
    entity_keys: list[tuple[str, str, str]] = []
    seen_entity_keys: set[tuple[str, str, str]] = set()
    for element in plan.elements:
        key = (element.source_group, element.component, element.material)
        if key not in seen_entity_keys:
            seen_entity_keys.add(key)
            entity_keys.append(key)
    entity_by_key = {
        key: gmsh.model.addDiscreteEntity(3, index)
        for index, key in enumerate(entity_keys, start=1)
    }

    entity_rank = {key: index for index, key in enumerate(entity_keys)}
    incident_entities: dict[int, set[tuple[str, str, str]]] = {
        node.tag: set() for node in plan.nodes
    }
    for element in plan.elements:
        key = (element.source_group, element.component, element.material)
        for tag in element.node_tags:
            incident_entities[tag].add(key)
    owner_by_node = {
        tag: min(keys, key=entity_rank.__getitem__)
        for tag, keys in incident_entities.items()
    }
    node_by_tag = {node.tag: node for node in plan.nodes}
    owned_tags_by_key: dict[tuple[str, str, str], list[int]] = {
        key: [] for key in entity_keys
    }
    for tag in sorted(node_by_tag):
        owned_tags_by_key[owner_by_node[tag]].append(tag)
    for key in entity_keys:
        owned_tags = owned_tags_by_key[key]
        if not owned_tags:
            continue
        coordinates = [
            value
            for tag in owned_tags
            for value in node_by_tag[tag].coordinates
        ]
        gmsh.model.mesh.addNodes(3, entity_by_key[key], owned_tags, coordinates)

    grouped_elements: dict[
        tuple[tuple[str, str, str], int], list[PlannedLayoutElement]
    ] = {}
    for element in plan.elements:
        key = (element.source_group, element.component, element.material)
        grouped_elements.setdefault((key, element.gmsh_type), []).append(element)
    for key in entity_keys:
        for gmsh_type in (5, 6):
            block = grouped_elements.get((key, gmsh_type), ())
            if not block:
                continue
            gmsh.model.mesh.addElementsByType(
                entity_by_key[key],
                gmsh_type,
                [element.tag for element in block],
                [tag for element in block for tag in element.node_tags],
            )

    material_counts = plan.material_element_counts
    material_groups: dict[str, int] = {}
    for material in sorted(material_counts):
        entity_tags = [
            entity_by_key[key] for key in entity_keys if key[2] == material
        ]
        physical_tag = gmsh.model.addPhysicalGroup(3, entity_tags)
        gmsh.model.setPhysicalName(3, physical_tag, material)
        material_groups[material] = material_counts[material]

    template_set_keys: dict[str, list[tuple[str, str, str]]] = {}
    for key in entity_keys:
        source_group, component, _material = key
        if source_group == _TRANSITION_SOURCE:
            continue
        name = _template_set_physical_name(source_group, component)
        template_set_keys.setdefault(name, []).append(key)
    template_set_groups: dict[str, int] = {}
    for name, keys in sorted(template_set_keys.items()):
        entity_tags = [entity_by_key[key] for key in keys]
        physical_tag = gmsh.model.addPhysicalGroup(3, entity_tags)
        gmsh.model.setPhysicalName(3, physical_tag, name)
        template_set_groups[name] = sum(
            1
            for element in plan.elements
            if not element.is_transition
            and _template_set_physical_name(
                element.source_group,
                element.component,
            )
            == name
        )

    transition_groups: dict[str, int] = {}
    transition_entities = [
        entity_by_key[key] for key in entity_keys if key[0] == _TRANSITION_SOURCE
    ]
    if transition_entities:
        physical_tag = gmsh.model.addPhysicalGroup(3, transition_entities)
        gmsh.model.setPhysicalName(3, physical_tag, _TRANSITION_SOLIDS_NAME)
        transition_groups[_TRANSITION_SOLIDS_NAME] = plan.transition_element_count

    hypermesh_component_groups: dict[str, int] = {}
    for component in sorted(plan.component_element_counts):
        template_keys = [
            key
            for key in entity_keys
            if key[0] != _TRANSITION_SOURCE and key[1] == component
        ]
        if template_keys:
            name = _hypermesh_component_physical_name("TEMPLATE", component)
            physical_tag = gmsh.model.addPhysicalGroup(
                3,
                [entity_by_key[key] for key in template_keys],
            )
            gmsh.model.setPhysicalName(3, physical_tag, name)
            hypermesh_component_groups[name] = sum(
                not element.is_transition and element.component == component
                for element in plan.elements
            )
        transition_keys = [
            key
            for key in entity_keys
            if key[0] == _TRANSITION_SOURCE and key[1] == component
        ]
        if transition_keys:
            name = _hypermesh_component_physical_name("TRANSITION", component)
            physical_tag = gmsh.model.addPhysicalGroup(
                3,
                [entity_by_key[key] for key in transition_keys],
            )
            gmsh.model.setPhysicalName(3, physical_tag, name)
            hypermesh_component_groups[name] = sum(
                element.is_transition and element.component == component
                for element in plan.elements
            )

    all_entities = [entity_by_key[key] for key in entity_keys]
    all_tag = gmsh.model.addPhysicalGroup(3, all_entities)
    gmsh.model.setPhysicalName(3, all_tag, _ALL_SOLIDS_NAME)

    palette = (
        (226, 93, 93),
        (244, 162, 97),
        (233, 196, 106),
        (42, 157, 143),
        (69, 123, 157),
        (106, 76, 147),
    )
    for index, material in enumerate(sorted(material_counts)):
        keys = [key for key in entity_keys if key[2] == material]
        gmsh.model.setColor(
            [(3, entity_by_key[key]) for key in keys],
            *palette[index % len(palette)],
            255,
        )
    return (
        material_groups,
        template_set_groups,
        transition_groups,
        hypermesh_component_groups,
    )


def _percentile(sorted_values: Sequence[float], fraction: float) -> float:
    if not sorted_values:
        raise ValueError("cannot compute a percentile of an empty sequence")
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    position = fraction * (len(sorted_values) - 1)
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return float(sorted_values[lower])
    weight = position - lower
    return float(
        sorted_values[lower] * (1.0 - weight) + sorted_values[upper] * weight
    )


@dataclass(frozen=True, slots=True)
class _QualityMetrics:
    min_scaled_jacobian: float
    min_sicn: float
    min_sige: float
    min_jacobian_determinant: float


def _quality_metrics(gmsh: Any, element_tags: Sequence[int]) -> _QualityMetrics:
    if not element_tags:
        raise RuntimeError("cannot evaluate an empty element set")
    scaled_jacobians = tuple(
        float(value)
        for value in gmsh.model.mesh.getElementQualities(element_tags, "minSJ")
    )
    sicn = tuple(
        float(value)
        for value in gmsh.model.mesh.getElementQualities(element_tags, "minSICN")
    )
    sige = tuple(
        float(value)
        for value in gmsh.model.mesh.getElementQualities(element_tags, "minSIGE")
    )
    determinants = tuple(
        float(value)
        for value in gmsh.model.mesh.getElementQualities(element_tags, "minDetJac")
    )
    return _QualityMetrics(
        min_scaled_jacobian=min(scaled_jacobians),
        min_sicn=min(sicn),
        min_sige=min(sige),
        min_jacobian_determinant=min(determinants),
    )


def _summarize(
    gmsh: Any,
    plan: LayoutMeshPlan,
    mesh_path: Path,
    report_path: Path,
    parameters_path: Path,
    physical_groups: tuple[
        dict[str, int],
        dict[str, int],
        dict[str, int],
        dict[str, int],
    ],
) -> LayoutBuildSummary:
    surface_entities = tuple(gmsh.model.getEntities(2))
    _, surface_tag_blocks, _ = gmsh.model.mesh.getElements(2)
    two_dimensional_count = sum(len(tags) for tags in surface_tag_blocks)
    if surface_entities or two_dimensional_count:
        raise RuntimeError("layout output must contain only 3-D volume elements")

    element_types, element_tag_blocks, _ = gmsh.model.mesh.getElements(3)
    type_counts: Counter[str] = Counter()
    actual_tags: list[int] = []
    for element_type, tags in zip(element_types, element_tag_blocks):
        name, dimension, order, _, _, _ = gmsh.model.mesh.getElementProperties(
            int(element_type)
        )
        name = str(name)
        if int(dimension) != 3 or int(order) != 1 or name not in {
            "Hexahedron 8",
            "Prism 6",
        }:
            raise RuntimeError(f"unsupported layout volume element: {name}")
        type_counts[name] += len(tags)
        actual_tags.extend(int(tag) for tag in tags)
    planned_tags = {element.tag for element in plan.elements}
    if set(actual_tags) != planned_tags or len(actual_tags) != len(planned_tags):
        raise RuntimeError("Gmsh element tags differ from the immutable layout plan")

    sorted_scaled_jacobians = sorted(
        float(value)
        for value in gmsh.model.mesh.getElementQualities(actual_tags, "minSJ")
    )
    all_metrics = _quality_metrics(gmsh, actual_tags)
    template_tags = [
        element.tag for element in plan.elements if not element.is_transition
    ]
    transition_tags = [
        element.tag for element in plan.elements if element.is_transition
    ]
    template_metrics = _quality_metrics(gmsh, template_tags)
    transition_metrics = _quality_metrics(gmsh, transition_tags)

    quality = classify_mesh_quality(
        all_metrics.min_scaled_jacobian,
        all_metrics.min_sicn,
        all_metrics.min_sige,
    )
    if all_metrics.min_jacobian_determinant <= 0.0 or not quality.is_valid:
        raise RuntimeError(
            "combined layout contains an invalid element: "
            f"minDetJac={all_metrics.min_jacobian_determinant:.6g}, "
            f"minSJ={all_metrics.min_scaled_jacobian:.6g}, "
            f"minSICN={all_metrics.min_sicn:.6g}, "
            f"minSIGE={all_metrics.min_sige:.6g}"
        )
    if (
        transition_metrics.min_scaled_jacobian < _MIN_TRANSITION_SHAPE_QUALITY
        or transition_metrics.min_sige < _MIN_TRANSITION_SHAPE_QUALITY
    ):
        raise RuntimeError(
            "new transition HEX8/WEDGE6 shape quality is below 0.30: "
            f"minSJ={transition_metrics.min_scaled_jacobian:.6g}, "
            f"minSIGE={transition_metrics.min_sige:.6g}"
        )

    duplicate_nodes = tuple(gmsh.model.mesh.getDuplicateNodes())
    if duplicate_nodes:
        raise RuntimeError(f"combined layout contains {len(duplicate_nodes)} duplicate nodes")
    node_tags, _, _ = gmsh.model.mesh.getNodes()
    if len(node_tags) != plan.node_count:
        raise RuntimeError("Gmsh node count differs from the immutable layout plan")

    (
        material_groups,
        template_set_groups,
        transition_groups,
        hypermesh_component_groups,
    ) = physical_groups
    return LayoutBuildSummary(
        mesh_path=str(mesh_path),
        report_path=str(report_path),
        parameters_path=str(parameters_path),
        strategy="native-ring-layer-extrusion",
        bump_count=len(plan.layout.instances),
        template_aliases=tuple(
            placement.template_alias for placement in plan.layout.instances
        ),
        ring_node_counts=plan.ring_node_counts,
        z_levels_um=tuple(round(value * 1000.0, 12) for value in plan.z_levels_mm),
        void_slab_intervals_um=tuple(
            (
                round(z_min * 1000.0, 12),
                round(z_max * 1000.0, 12),
            )
            for z_min, z_max in plan.void_slab_intervals_mm
        ),
        template_slab_materials=plan.template_slab_materials,
        transition_slab_materials=plan.transition_slab_materials,
        template_slab_components=plan.template_slab_components,
        transition_slab_components=plan.transition_slab_components,
        transition_material_overrides=plan.transition_material_overrides,
        node_count=plan.node_count,
        element_count=plan.element_count,
        template_element_count=plan.template_element_count,
        transition_element_count=plan.transition_element_count,
        transition_hex_count=plan.transition_hex_count,
        transition_wedge_count=plan.transition_wedge_count,
        hex_count=type_counts["Hexahedron 8"],
        wedge_count=type_counts["Prism 6"],
        volume_count=len(gmsh.model.getEntities(3)),
        two_dimensional_element_count=two_dimensional_count,
        interface_face_count=plan.interface_face_count,
        minimum_geometric_clearance_um=(
            round(plan.minimum_geometric_clearance_mm * 1000.0, 12)
        ),
        transition_only_node_count=plan.transition_only_node_count,
        physical_volume_groups=material_groups,
        bump_physical_groups={},
        template_set_physical_groups=template_set_groups,
        hypermesh_component_physical_groups=hypermesh_component_groups,
        transition_physical_groups=transition_groups,
        material_element_counts=plan.material_element_counts,
        transition_material_element_counts=plan.transition_material_element_counts,
        planar_node_count=plan.planar_mesh.node_count,
        planar_triangle_count=plan.planar_mesh.triangle_count,
        planar_quad_count=plan.planar_mesh.quad_count,
        structured_region_count=len(plan.layout.mesh_regions),
        planar_min_sicn=plan.planar_mesh.minimum_sicn,
        planar_min_sige=plan.planar_mesh.minimum_sige,
        interface_planar_min_sicn=plan.interface_planar_min_sicn,
        interface_planar_min_sige=plan.interface_planar_min_sige,
        planar_minimum_edge_um=plan.planar_mesh.minimum_edge_mm * 1000.0,
        planar_maximum_edge_um=plan.planar_mesh.maximum_edge_mm * 1000.0,
        min_scaled_jacobian=all_metrics.min_scaled_jacobian,
        p01_scaled_jacobian=_percentile(sorted_scaled_jacobians, 0.01),
        median_scaled_jacobian=statistics.median(sorted_scaled_jacobians),
        min_sicn=all_metrics.min_sicn,
        min_sige=all_metrics.min_sige,
        min_jacobian_determinant=all_metrics.min_jacobian_determinant,
        template_min_scaled_jacobian=template_metrics.min_scaled_jacobian,
        template_min_sicn=template_metrics.min_sicn,
        template_min_sige=template_metrics.min_sige,
        template_min_jacobian_determinant=template_metrics.min_jacobian_determinant,
        transition_min_scaled_jacobian=transition_metrics.min_scaled_jacobian,
        transition_min_sicn=transition_metrics.min_sicn,
        transition_min_sige=transition_metrics.min_sige,
        transition_min_jacobian_determinant=transition_metrics.min_jacobian_determinant,
        duplicate_node_count=0,
        template_connectivity_preserved=True,
        component_surface_heights_preserved=True,
        interface_conformal=True,
        interface_exterior_material_assignment_verified=True,
        structured_region_bounds_preserved=True,
        structured_region_xy_sizes_preserved=True,
        structured_region_hex8_only=True,
        structured_region_z_surfaces_preserved=True,
        structured_region_transition_interface_conformal=True,
        structured_region_material_assignment_verified=True,
        written_mesh_reopened_verified=False,
        quality_warnings=quality.quality_warnings,
        quality_advisories=quality.quality_advisories,
        quality_classification=quality.classification,
    )


def _record_fingerprint(records: Iterable[bytes]) -> tuple[int, int, int]:
    """Return a deterministic order-independent fingerprint and record count."""

    count = 0
    xor_value = 0
    sum_value = 0
    modulus = 1 << 128
    for record in records:
        digest = int.from_bytes(
            hashlib.blake2b(record, digest_size=16).digest(), "big"
        )
        count += 1
        xor_value ^= digest
        sum_value = (sum_value + digest) % modulus
    return count, xor_value, sum_value


def _element_record(
    tag: int, gmsh_type: int, node_tags: Sequence[int]
) -> bytes:
    connectivity = ",".join(str(value) for value in node_tags)
    return f"{tag}|{gmsh_type}|{connectivity}".encode("ascii")


def _tag_record(tag: int) -> bytes:
    return str(tag).encode("ascii")


def _validate_written_mesh(
    gmsh: Any,
    output: Path,
    plan: LayoutMeshPlan,
    physical_groups: tuple[
        dict[str, int],
        dict[str, int],
        dict[str, int],
        dict[str, int],
    ],
) -> None:
    """Reopen the serialized MSH in an empty model and audit its exact content."""

    original_model = str(gmsh.model.getCurrent())
    reopened_model = f"__easymesh_reopen_validation_{uuid.uuid4().hex}"
    gmsh.model.add(reopened_model)
    gmsh.model.setCurrent(reopened_model)
    try:
        gmsh.merge(str(output))
        surface_entities = tuple(gmsh.model.getEntities(2))
        _, surface_blocks, _ = gmsh.model.mesh.getElements(2)
        if surface_entities or sum(len(tags) for tags in surface_blocks):
            raise RuntimeError("reopened layout unexpectedly contains 2-D elements")

        node_tags, coordinates, _ = gmsh.model.mesh.getNodes()
        expected_node_by_tag = {node.tag: node for node in plan.nodes}
        actual_node_tags = {int(tag) for tag in node_tags}
        if actual_node_tags != set(expected_node_by_tag):
            raise RuntimeError("reopened MSH node tags differ from the layout plan")
        # ASCII MSH round-tripping can change the final binary floating-point
        # bit by one ULP.  Compare by global tag with a tolerance far below any
        # geometric or meshing tolerance instead of hashing decimal strings.
        coordinate_tolerance = 1.0e-14
        for index, tag_value in enumerate(node_tags):
            expected = expected_node_by_tag[int(tag_value)]
            actual = (
                float(coordinates[3 * index]),
                float(coordinates[3 * index + 1]),
                float(coordinates[3 * index + 2]),
            )
            if any(
                abs(actual_value - expected_value) > coordinate_tolerance
                for actual_value, expected_value in zip(
                    actual, expected.coordinates
                )
            ):
                raise RuntimeError(
                    "reopened MSH node coordinates differ from the layout plan"
                )

        expected_element_fingerprint = _record_fingerprint(
            _element_record(element.tag, element.gmsh_type, element.node_tags)
            for element in plan.elements
        )
        element_types, element_tag_blocks, connectivity_blocks = (
            gmsh.model.mesh.getElements(3)
        )

        def actual_element_records() -> Iterable[bytes]:
            for gmsh_type_value, tags, flat_connectivity in zip(
                element_types, element_tag_blocks, connectivity_blocks
            ):
                gmsh_type = int(gmsh_type_value)
                expected_nodes = {5: 8, 6: 6}.get(gmsh_type)
                if expected_nodes is None:
                    raise RuntimeError(
                        "reopened MSH contains a non-HEX8/WEDGE6 volume element"
                    )
                for index, tag in enumerate(tags):
                    start = index * expected_nodes
                    yield _element_record(
                        int(tag),
                        gmsh_type,
                        tuple(
                            int(value)
                            for value in flat_connectivity[
                                start : start + expected_nodes
                            ]
                        ),
                    )

        actual_element_fingerprint = _record_fingerprint(actual_element_records())
        if actual_element_fingerprint != expected_element_fingerprint:
            raise RuntimeError("reopened MSH element connectivity differs from the plan")

        entity_element_tags: dict[int, tuple[int, ...]] = {}
        for _, entity_tag_value in gmsh.model.getEntities(3):
            entity_tag = int(entity_tag_value)
            _, tag_blocks, _ = gmsh.model.mesh.getElements(3, entity_tag)
            entity_element_tags[entity_tag] = tuple(
                int(tag) for tags in tag_blocks for tag in tags
            )
        actual_physical_counts: dict[str, int] = {}
        actual_physical_membership: dict[str, tuple[int, int, int]] = {}
        for dimension, physical_tag_value in gmsh.model.getPhysicalGroups(3):
            if int(dimension) != 3:
                continue
            physical_tag = int(physical_tag_value)
            name = str(gmsh.model.getPhysicalName(3, physical_tag))
            if not name or name in actual_physical_counts:
                raise RuntimeError("reopened MSH has missing or duplicate physical names")
            membership = _record_fingerprint(
                _tag_record(tag)
                for entity_tag in gmsh.model.getEntitiesForPhysicalGroup(
                    3, physical_tag
                )
                for tag in entity_element_tags[int(entity_tag)]
            )
            actual_physical_counts[name] = membership[0]
            actual_physical_membership[name] = membership
        (
            material_groups,
            template_set_groups,
            transition_groups,
            hypermesh_component_groups,
        ) = physical_groups
        expected_physical_counts = {
            **material_groups,
            **template_set_groups,
            **transition_groups,
            **hypermesh_component_groups,
            _ALL_SOLIDS_NAME: plan.element_count,
        }
        if actual_physical_counts != expected_physical_counts:
            raise RuntimeError(
                "reopened MSH physical-volume groups differ from the layout plan"
            )
        expected_physical_membership: dict[str, tuple[int, int, int]] = {
            _ALL_SOLIDS_NAME: _record_fingerprint(
                _tag_record(element.tag) for element in plan.elements
            )
        }
        for material in material_groups:
            expected_physical_membership[material] = _record_fingerprint(
                _tag_record(element.tag)
                for element in plan.elements
                if element.material == material
            )
        for template_set_name in template_set_groups:
            expected_physical_membership[template_set_name] = _record_fingerprint(
                _tag_record(element.tag)
                for element in plan.elements
                if not element.is_transition
                and _template_set_physical_name(
                    element.source_group,
                    element.component,
                )
                == template_set_name
            )
        if _TRANSITION_SOLIDS_NAME in transition_groups:
            expected_physical_membership[_TRANSITION_SOLIDS_NAME] = (
                _record_fingerprint(
                    _tag_record(element.tag)
                    for element in plan.elements
                    if element.is_transition
                )
            )
        for component in plan.component_element_counts:
            template_component_name = _hypermesh_component_physical_name(
                "TEMPLATE",
                component,
            )
            if template_component_name in hypermesh_component_groups:
                expected_physical_membership[template_component_name] = (
                    _record_fingerprint(
                        _tag_record(element.tag)
                        for element in plan.elements
                        if not element.is_transition
                        and element.component == component
                    )
                )
            transition_component_name = _hypermesh_component_physical_name(
                "TRANSITION",
                component,
            )
            if transition_component_name in hypermesh_component_groups:
                expected_physical_membership[transition_component_name] = (
                    _record_fingerprint(
                        _tag_record(element.tag)
                        for element in plan.elements
                        if element.is_transition and element.component == component
                    )
                )
        if actual_physical_membership != expected_physical_membership:
            raise RuntimeError(
                "reopened MSH physical-volume membership differs from the layout plan"
            )
        if tuple(gmsh.model.mesh.getDuplicateNodes()):
            raise RuntimeError("reopened MSH contains duplicate nodes")
    finally:
        try:
            gmsh.model.setCurrent(reopened_model)
            gmsh.model.remove()
        finally:
            gmsh.model.setCurrent(original_model)


def _layout_payload(plan: LayoutMeshPlan) -> dict[str, Any]:
    layout = plan.layout
    normalized_overrides = dict(plan.transition_material_overrides)
    return {
        "schema": "easymesh-bump-layout-v4",
        "source_path": str(layout.source_path) if layout.source_path else None,
        "units": "mm",
        "strategy": "native-ring-layer-extrusion",
        "bounds": {
            "x_min": layout.bounds.x_min_mm,
            "x_max": layout.bounds.x_max_mm,
            "y_min": layout.bounds.y_min_mm,
            "y_max": layout.bounds.y_max_mm,
        },
        "templates": [
            {"alias": template.alias, "mesh_path": str(template.mesh_path)}
            for template in layout.templates
        ],
        "instances": [
            {
                "index": index,
                "x": placement.x_mm,
                "y": placement.y_mm,
                "template": placement.template_alias,
                "native_ring_node_count": plan.ring_node_counts[index],
            }
            for index, placement in enumerate(layout.instances)
        ],
        "structured_regions": [
            {
                "index": index,
                "element_type": "HEX8",
                "x_min": region.x_min_mm,
                "x_max": region.x_max_mm,
                "y_min": region.y_min_mm,
                "y_max": region.y_max_mm,
                "size_x": region.size_x_mm,
                "size_y": region.size_y_mm,
                "z_source": "template_layer_surfaces",
            }
            for index, region in enumerate(layout.mesh_regions)
        ],
        "far_field_size": plan.far_field_size_mm,
        "transition_distance": plan.transition_distance_mm,
        "z_levels": [round(value, 15) for value in plan.z_levels_mm],
        "void_slab_intervals": [
            [round(z_min, 15), round(z_max, 15)]
            for z_min, z_max in plan.void_slab_intervals_mm
        ],
        "template_slab_materials": list(plan.template_slab_materials),
        "transition_slab_materials": list(plan.transition_slab_materials),
        "template_slab_components": list(plan.template_slab_components),
        "transition_slab_components": list(plan.transition_slab_components),
        # Compatibility alias retained for existing report consumers.
        "slab_materials": list(plan.transition_slab_materials),
        "transition_material_overrides": normalized_overrides,
        "transition_material_cli_args": [
            item
            for source, target in plan.transition_material_overrides
            for item in (
                "--transition-material",
                f"{source}={target}",
            )
        ],
        "hard_constraints": {
            "template_nodes_and_connectivity_unchanged": True,
            "template_materials_unchanged": True,
            "native_ring_topology_preserved": True,
            "component_surface_heights_unchanged": True,
            "outer_void_slabs_left_unmeshed": True,
            "template_transition_interface_conformal": True,
            "interface_exterior_material_assignment_verified": True,
            "structured_region_bounds_preserved": True,
            "structured_region_xy_sizes_preserved": True,
            "structured_region_hex8_only": True,
            "structured_region_z_surfaces_preserved": True,
            "structured_region_transition_interface_conformal": True,
            "structured_region_material_assignment_verified": True,
        },
    }


def build_layout_mesh(
    layout: BumpLayout | str | Path,
    mesh_path: str | Path,
    *,
    far_field_size_um: float = 80.0,
    transition_distance_um: float = 120.0,
    transition_material_overrides: Mapping[str, str] | None = None,
    preview: bool = False,
    verbose: bool = False,
    job_id: str | None = None,
) -> LayoutBuildSummary:
    """Build one layout while preventing cross-process output interleaving."""

    output = normalized_mesh_output(mesh_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with exclusive_output_lock(output):
        summary = _build_layout_mesh_locked(
            layout,
            output,
            far_field_size_um=far_field_size_um,
            transition_distance_um=transition_distance_um,
            transition_material_overrides=transition_material_overrides,
            verbose=verbose,
            job_id=job_id,
        )
    if preview:
        preview_mesh_file(output, verbose=verbose)
    return summary


def _build_layout_mesh_locked(
    layout: BumpLayout | str | Path,
    mesh_path: str | Path,
    *,
    far_field_size_um: float = 80.0,
    transition_distance_um: float = 120.0,
    transition_material_overrides: Mapping[str, str] | None = None,
    verbose: bool = False,
    job_id: str | None = None,
) -> LayoutBuildSummary:
    """Build, verify, and write a mixed-template bump layout as MSH 4.1."""

    resolved_layout = (
        load_bump_layout(layout) if isinstance(layout, (str, Path)) else layout
    )
    if not isinstance(resolved_layout, BumpLayout):
        raise TypeError("layout must be a BumpLayout or .loc path")
    output = normalized_mesh_output(mesh_path)
    for template in resolved_layout.templates:
        if paths_refer_to_same_file(template.mesh_path, output):
            raise ValueError(
                f"output path must not overwrite input template {template.alias!r}: "
                f"{output}"
            )
    output.parent.mkdir(parents=True, exist_ok=True)
    report_path = output.with_suffix(".report.json")
    parameters_path = output.with_suffix(".parameters.json")

    plan = plan_layout_mesh(
        resolved_layout,
        far_field_size_um=far_field_size_um,
        transition_distance_um=transition_distance_um,
        transition_material_overrides=transition_material_overrides,
        verbose=verbose,
    )

    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise RuntimeError("Gmsh is required to write the layout mesh") from error

    option_values = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.MshFileVersion": 4.1,
        "Mesh.Binary": 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.SaveAll": 1.0,
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_bump_layout",
        number_options=option_values,
    ):
        physical_groups = _add_discrete_mesh(gmsh, plan)
        summary = _summarize(
            gmsh,
            plan,
            output,
            report_path,
            parameters_path,
            physical_groups,
        )
        with atomic_output_path(output) as temporary_mesh:
            gmsh.write(str(temporary_mesh))
            _validate_written_mesh(gmsh, temporary_mesh, plan, physical_groups)
            summary = replace(summary, written_mesh_reopened_verified=True)
            mesh_artifact = file_artifact(
                temporary_mesh,
                published_path=output,
            )

        parameter_payload = _layout_payload(plan)
        atomic_write_text(
            parameters_path,
            json.dumps(parameter_payload, indent=2, ensure_ascii=False),
        )
        report_payload: dict[str, object] = {
            "parameters": parameter_payload,
            "quality": summary.to_dict(),
            "mesh_artifact": mesh_artifact,
        }
        if job_id is not None:
            report_payload["job_id"] = job_id
        atomic_write_text(
            report_path,
            json.dumps(report_payload, indent=2, ensure_ascii=False),
        )

        return summary


__all__ = [
    "LayoutBuildSummary",
    "LayoutMeshPlan",
    "PlannedLayoutElement",
    "build_layout_mesh",
    "normalize_material_name",
    "plan_layout_mesh",
]
