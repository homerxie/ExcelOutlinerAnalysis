"""Topology- and geometry-driven continuity groups for generated interfaces.

One negotiated interface is one real positive-area common face.  This module
builds a graph whose vertices are those faces.  A volume component may connect
two vertices only when its selected topology transports a section and the
canonical geometry proves that the two faces are corresponding sweep sections.
No component name, material, stack position or geometry role participates in
the decision.

``conformal_hybrid`` deliberately never creates a cross-body graph edge.  It
can consume each adjacent locked surface independently, so its opposite ends
must not be forced into one topology-equivalence group.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from types import MappingProxyType

from .component_interface import (
    ComponentMeshRequirement,
    NegotiatedComponentInterface,
    PlanarTransportEvidence,
)
from .package_assembly import (
    COMPONENT_LOCAL_DIRECTIONS,
    ComponentLocalDirection,
    GeneratedComponentMeshControl,
    StructuredSweepMeshStrategy,
)
from .package_v2_geometry import (
    CanonicalComponentGeometry,
    CanonicalRigidPlacement,
)
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)


class GeneratedInterfaceContinuityError(ValueError):
    """Raised when continuity cannot be proven from geometry and policies."""


Vec3 = tuple[float, float, float]


_LOCAL_DIRECTION_VECTOR: Mapping[ComponentLocalDirection, Vec3] = (
    MappingProxyType(
        {
            ComponentLocalDirection.POSITIVE_X: (1.0, 0.0, 0.0),
            ComponentLocalDirection.NEGATIVE_X: (-1.0, 0.0, 0.0),
            ComponentLocalDirection.POSITIVE_Y: (0.0, 1.0, 0.0),
            ComponentLocalDirection.NEGATIVE_Y: (0.0, -1.0, 0.0),
            ComponentLocalDirection.POSITIVE_Z: (0.0, 0.0, 1.0),
            ComponentLocalDirection.NEGATIVE_Z: (0.0, 0.0, -1.0),
        }
    )
)


@dataclass(frozen=True, slots=True)
class SurfaceTransportLink:
    """One proven equivalence between two faces through one component."""

    through_component_id: str
    interface_ids: tuple[str, str]
    direction_xyz: tuple[float, float, float]
    distance_mm: float
    section_signature: str

    def to_dict(self) -> dict[str, object]:
        return {
            "through_component_id": self.through_component_id,
            "interface_ids": list(self.interface_ids),
            "direction_xyz": list(self.direction_xyz),
            "distance_mm": self.distance_mm,
            "section_signature": self.section_signature,
        }


@dataclass(frozen=True, slots=True)
class RejectedSurfaceTransportPair:
    """A candidate pair deliberately kept in separate equivalence groups."""

    through_component_id: str
    interface_ids: tuple[str, str]
    reason: str

    def to_dict(self) -> dict[str, object]:
        return {
            "through_component_id": self.through_component_id,
            "interface_ids": list(self.interface_ids),
            "reason": self.reason,
        }


@dataclass(frozen=True, slots=True)
class GeneratedSurfaceEquivalenceGroup:
    """Interfaces that must receive one topologically equivalent surface."""

    group_id: str
    interface_ids: tuple[str, ...]
    component_ids: tuple[str, ...]
    transport_component_ids: tuple[str, ...]
    surface_policy: str
    permitted_surface_element_kinds: tuple[str, ...]
    target_edge_mm: float
    transition_distance_mm_by_component: Mapping[str, float]

    def to_dict(self) -> dict[str, object]:
        return {
            "group_id": self.group_id,
            "interface_ids": list(self.interface_ids),
            "component_ids": list(self.component_ids),
            "transport_component_ids": list(self.transport_component_ids),
            "surface_policy": self.surface_policy,
            "permitted_surface_element_kinds": list(
                self.permitted_surface_element_kinds
            ),
            "target_edge_mm": self.target_edge_mm,
            "transition_distance_mm_by_component": dict(
                self.transition_distance_mm_by_component
            ),
        }


@dataclass(frozen=True, slots=True)
class GeneratedInterfaceContinuityPlan:
    """Auditable result of continuity graph construction."""

    groups: tuple[GeneratedSurfaceEquivalenceGroup, ...]
    transport_links: tuple[SurfaceTransportLink, ...]
    rejected_transport_pairs: tuple[RejectedSurfaceTransportPair, ...]
    group_id_by_interface: Mapping[str, str]
    sweep_direction_xyz_by_component: Mapping[str, Vec3]

    def to_dict(self) -> dict[str, object]:
        return {
            "groups": [group.to_dict() for group in self.groups],
            "transport_links": [link.to_dict() for link in self.transport_links],
            "rejected_transport_pairs": [
                value.to_dict() for value in self.rejected_transport_pairs
            ],
            "group_id_by_interface": dict(self.group_id_by_interface),
            "sweep_direction_xyz_by_component": {
                component_id: list(direction)
                for component_id, direction in sorted(
                    self.sweep_direction_xyz_by_component.items()
                )
            },
        }


def _close(first: float, second: float) -> bool:
    return math.isclose(first, second, rel_tol=1.0e-12, abs_tol=1.0e-12)


def _expected_surface_policy(topologies: set[str]) -> tuple[str, tuple[str, ...]]:
    if "orthogonal_hex" in topologies:
        return "shared_cartesian_quad", ("QUAD4",)
    if "structured_sweep" in topologies:
        return "shared_inherited_sweep_surface", ("TRI3", "QUAD4")
    return "shared_gmsh_conformal_surface", ("TRI3", "QUAD4")


def _validate_inputs(
    interfaces: Sequence[NegotiatedComponentInterface],
    requirements: Mapping[str, ComponentMeshRequirement],
) -> tuple[
    tuple[NegotiatedComponentInterface, ...],
    Mapping[str, ComponentMeshRequirement],
]:
    if isinstance(interfaces, (str, bytes)) or not isinstance(interfaces, Sequence):
        raise GeneratedInterfaceContinuityError(
            "interfaces must be a sequence of NegotiatedComponentInterface"
        )
    normalized = tuple(interfaces)
    if any(type(value) is not NegotiatedComponentInterface for value in normalized):
        raise GeneratedInterfaceContinuityError(
            "interfaces must contain NegotiatedComponentInterface only"
        )
    identifiers = tuple(value.interface_id for value in normalized)
    if len(set(identifiers)) != len(identifiers):
        raise GeneratedInterfaceContinuityError("interface IDs must be unique")
    if not isinstance(requirements, Mapping):
        raise GeneratedInterfaceContinuityError(
            "requirements must map component IDs to ComponentMeshRequirement"
        )
    requirement_ids = tuple(requirements)
    if any(
        not isinstance(component_id, str) or not component_id
        for component_id in requirement_ids
    ):
        raise GeneratedInterfaceContinuityError(
            "requirement keys must be non-empty Component IDs"
        )
    policies: dict[str, ComponentMeshRequirement] = {}
    referenced = {
        component_id for interface in normalized for component_id in interface.component_ids
    }
    missing = sorted(referenced.difference(requirements))
    if missing:
        raise GeneratedInterfaceContinuityError(
            "missing component mesh requirement(s): " + ", ".join(missing)
        )
    for component_id in sorted(requirement_ids):
        requirement = requirements[component_id]
        if type(requirement) is not ComponentMeshRequirement:
            raise GeneratedInterfaceContinuityError(
                f"requirement {component_id!r} must be ComponentMeshRequirement"
            )
        if requirement.component_id != component_id:
            raise GeneratedInterfaceContinuityError(
                f"requirement key {component_id!r} does not match its component_id"
            )
        policies[component_id] = requirement

    for interface in normalized:
        if (
            len(interface.component_ids) != 2
            or interface.component_ids[0] == interface.component_ids[1]
            or tuple(sorted(interface.component_ids)) != interface.component_ids
        ):
            raise GeneratedInterfaceContinuityError(
                f"interface {interface.interface_id!r} has invalid component IDs"
            )
        first = policies[interface.component_ids[0]]
        second = policies[interface.component_ids[1]]
        expected_policy, expected_kinds = _expected_surface_policy(
            {first.volume_topology, second.volume_topology}
        )
        if interface.surface_policy != expected_policy:
            raise GeneratedInterfaceContinuityError(
                f"interface {interface.interface_id!r} surface policy does not "
                "match its component topology requirements"
            )
        if interface.permitted_surface_element_kinds != expected_kinds:
            raise GeneratedInterfaceContinuityError(
                f"interface {interface.interface_id!r} surface kinds do not "
                "match its negotiated policy"
            )
        if not _close(
            interface.interface_target_edge_mm,
            min(first.target_edge_mm, second.target_edge_mm),
        ):
            raise GeneratedInterfaceContinuityError(
                f"interface {interface.interface_id!r} target size is stale"
            )
        if not _close(
            interface.first_transition_distance_mm,
            first.transition_distance_mm,
        ) or not _close(
            interface.second_transition_distance_mm,
            second.transition_distance_mm,
        ):
            raise GeneratedInterfaceContinuityError(
                f"interface {interface.interface_id!r} transition distances are stale"
            )
        if interface.transport_evidence is not None and type(
            interface.transport_evidence
        ) is not PlanarTransportEvidence:
            raise GeneratedInterfaceContinuityError(
                f"interface {interface.interface_id!r} has invalid transport evidence"
            )
    return tuple(sorted(normalized, key=lambda value: value.interface_id)), MappingProxyType(
        policies
    )


def _vector_subtract(
    first: tuple[float, float, float],
    second: tuple[float, float, float],
) -> tuple[float, float, float]:
    return tuple(first[index] - second[index] for index in range(3))  # type: ignore[return-value]


def _dot(
    first: tuple[float, float, float],
    second: tuple[float, float, float],
) -> float:
    return math.fsum(first[index] * second[index] for index in range(3))


def _norm(value: tuple[float, float, float]) -> float:
    return math.sqrt(_dot(value, value))


def _matrix_product(
    left: tuple[Vec3, Vec3, Vec3],
    right: tuple[Vec3, Vec3, Vec3],
) -> tuple[Vec3, Vec3, Vec3]:
    return tuple(
        tuple(
            math.fsum(
                left[row][inner] * right[inner][column]
                for inner in range(3)
            )
            for column in range(3)
        )
        for row in range(3)
    )  # type: ignore[return-value]


def _rotation_matrix(
    placement: CanonicalRigidPlacement,
) -> tuple[Vec3, Vec3, Vec3]:
    """Return the canonical ``Rz @ Ry @ Rx`` fragment rotation."""

    rx, ry, rz = (math.radians(value) for value in placement.rotation_deg_xyz)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    rotate_x: tuple[Vec3, Vec3, Vec3] = (
        (1.0, 0.0, 0.0),
        (0.0, cx, -sx),
        (0.0, sx, cx),
    )
    rotate_y: tuple[Vec3, Vec3, Vec3] = (
        (cy, 0.0, sy),
        (0.0, 1.0, 0.0),
        (-sy, 0.0, cy),
    )
    rotate_z: tuple[Vec3, Vec3, Vec3] = (
        (cz, -sz, 0.0),
        (sz, cz, 0.0),
        (0.0, 0.0, 1.0),
    )
    return _matrix_product(
        rotate_z,
        _matrix_product(rotate_y, rotate_x),
    )


def _matrix_vector(
    matrix: tuple[Vec3, Vec3, Vec3],
    vector: Vec3,
) -> Vec3:
    return tuple(
        math.fsum(matrix[row][column] * vector[column] for column in range(3))
        for row in range(3)
    )  # type: ignore[return-value]


def _unit_vector(value: object, *, field_name: str) -> Vec3:
    if isinstance(value, (str, bytes)):
        raise GeneratedInterfaceContinuityError(
            f"{field_name} must be a finite non-zero 3-D vector"
        )
    try:
        raw = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise GeneratedInterfaceContinuityError(
            f"{field_name} must be a finite non-zero 3-D vector"
        ) from error
    if len(raw) != 3:
        raise GeneratedInterfaceContinuityError(
            f"{field_name} must be a finite non-zero 3-D vector"
        )
    output: list[float] = []
    for coordinate in raw:
        if isinstance(coordinate, bool) or not isinstance(
            coordinate, (int, float)
        ):
            raise GeneratedInterfaceContinuityError(
                f"{field_name} must be a finite non-zero 3-D vector"
            )
        number = float(coordinate)
        if not math.isfinite(number):
            raise GeneratedInterfaceContinuityError(
                f"{field_name} must be a finite non-zero 3-D vector"
            )
        output.append(number)
    length = _norm(tuple(output))  # type: ignore[arg-type]
    if not math.isfinite(length) or length <= 0.0:
        raise GeneratedInterfaceContinuityError(
            f"{field_name} must be a finite non-zero 3-D vector"
        )
    return tuple(
        0.0 if abs(coordinate / length) <= 1.0e-15 else coordinate / length
        for coordinate in output
    )  # type: ignore[return-value]


def resolve_package_frame_sweep_directions(
    components: Mapping[str, CanonicalComponentGeometry],
    mesh_controls: Mapping[str, GeneratedComponentMeshControl],
) -> Mapping[str, Vec3]:
    """Resolve every explicit Component-local Sweep direction into package space.

    A Component control is shared by all of its fragments.  Consequently every
    fragment placement must rotate the signed local direction to the same signed
    package-frame unit vector.  Translation and pivot do not affect a direction.
    """

    if not isinstance(components, Mapping):
        raise GeneratedInterfaceContinuityError("components must be a mapping")
    if not isinstance(mesh_controls, Mapping):
        raise GeneratedInterfaceContinuityError("mesh_controls must be a mapping")
    component_ids = set(components)
    control_ids = set(mesh_controls)
    if component_ids != control_ids:
        raise GeneratedInterfaceContinuityError(
            "generated mesh controls must match canonical Components exactly; "
            f"missing={sorted(component_ids - control_ids)!r}, "
            f"extra={sorted(control_ids - component_ids)!r}"
        )

    output: dict[str, Vec3] = {}
    for component_id in sorted(component_ids):
        component = components[component_id]
        control = mesh_controls[component_id]
        if type(component) is not CanonicalComponentGeometry:
            raise GeneratedInterfaceContinuityError(
                f"component {component_id!r} must be CanonicalComponentGeometry"
            )
        if component.component_id != component_id:
            raise GeneratedInterfaceContinuityError(
                f"component key {component_id!r} does not match its component_id"
            )
        if type(control) is not GeneratedComponentMeshControl:
            raise GeneratedInterfaceContinuityError(
                f"generated Component {component_id!r} lacks an explicit mesh control"
            )
        strategy = control.strategy
        if type(strategy) is not StructuredSweepMeshStrategy:
            continue
        if strategy.direction not in COMPONENT_LOCAL_DIRECTIONS:
            raise GeneratedInterfaceContinuityError(
                f"structured-sweep Component {component_id!r} lacks an explicit "
                "Component-local direction"
            )
        local_direction = _LOCAL_DIRECTION_VECTOR[strategy.direction]
        fragment_directions = tuple(
            _unit_vector(
                _matrix_vector(
                    _rotation_matrix(fragment.placement),
                    local_direction,
                ),
                field_name=(
                    f"structured-sweep Component {component_id!r} fragment "
                    f"{fragment.fragment_id!r} package-frame direction"
                ),
            )
            for fragment in component.fragments
        )
        package_direction = fragment_directions[0]
        if any(
            not math.isclose(
                _dot(package_direction, candidate),
                1.0,
                rel_tol=1.0e-9,
                abs_tol=1.0e-9,
            )
            for candidate in fragment_directions[1:]
        ):
            raise GeneratedInterfaceContinuityError(
                f"structured-sweep Component {component_id!r} fragment placements "
                "rotate its explicit signed direction to inconsistent package-frame "
                "axes"
            )
        output[component_id] = package_direction
    return MappingProxyType(output)


def _normalize_explicit_sweep_directions(
    policies: Mapping[str, ComponentMeshRequirement],
    value: Mapping[str, Vec3] | None,
) -> Mapping[str, Vec3]:
    """Validate the explicit package-frame direction for every Sweep body.

    Geometry is never used as a fallback for a missing direction.  The public
    low-level planner accepts ``None`` only when no Component in the plan uses
    ``structured_sweep``.
    """

    expected = {
        component_id
        for component_id, requirement in policies.items()
        if requirement.volume_topology == "structured_sweep"
    }
    if value is None:
        if expected:
            raise GeneratedInterfaceContinuityError(
                "missing explicit package-frame direction for structured-sweep "
                "Component(s): "
                + ", ".join(sorted(expected))
            )
        return MappingProxyType({})
    if not isinstance(value, Mapping):
        raise GeneratedInterfaceContinuityError(
            "sweep_direction_xyz_by_component must be a mapping"
        )
    supplied = tuple(value)
    if any(
        not isinstance(component_id, str) or not component_id
        for component_id in supplied
    ):
        raise GeneratedInterfaceContinuityError(
            "package-frame Sweep direction keys must be non-empty Component IDs"
        )
    supplied_ids = set(supplied)
    missing = sorted(expected.difference(supplied_ids))
    if missing:
        raise GeneratedInterfaceContinuityError(
            "missing explicit package-frame direction for structured-sweep "
            "Component(s): "
            + ", ".join(missing)
        )
    extra = sorted(supplied_ids.difference(expected))
    if extra:
        raise GeneratedInterfaceContinuityError(
            "package-frame Sweep direction supplied for non-sweep or unknown "
            "Component(s): "
            + ", ".join(extra)
        )
    return MappingProxyType(
        {
            component_id: _unit_vector(
                value[component_id],
                field_name=(
                    f"structured-sweep Component {component_id!r} package-frame "
                    "direction"
                ),
            )
            for component_id in sorted(expected)
        }
    )


def _transport_link(
    component_id: str,
    first: NegotiatedComponentInterface,
    second: NegotiatedComponentInterface,
    interface_geometry_tolerance_mm: float,
    expected_sweep_direction_xyz: Vec3 | None = None,
) -> tuple[SurfaceTransportLink | None, str | None]:
    first_evidence = first.transport_evidence
    second_evidence = second.transport_evidence
    if first_evidence is None or second_evidence is None:
        missing = []
        if first_evidence is None:
            missing.append(first.interface_id)
        if second_evidence is None:
            missing.append(second.interface_id)
        return None, "missing planar transport evidence on " + ", ".join(missing)

    normal_dot = _dot(
        first_evidence.unit_normal_xyz,
        second_evidence.unit_normal_xyz,
    )
    if not math.isclose(abs(normal_dot), 1.0, rel_tol=1.0e-9, abs_tol=1.0e-9):
        return None, "common-face normals are not parallel"
    if expected_sweep_direction_xyz is not None and not math.isclose(
        abs(_dot(first_evidence.unit_normal_xyz, expected_sweep_direction_xyz)),
        1.0,
        rel_tol=1.0e-9,
        abs_tol=1.0e-9,
    ):
        return (
            None,
            "common-face normals are not aligned with the explicit "
            "structured-sweep axis",
        )
    delta = _vector_subtract(
        second_evidence.centroid_xyz_mm,
        first_evidence.centroid_xyz_mm,
    )
    distance = _norm(delta)
    tolerance = max(interface_geometry_tolerance_mm, distance * 1.0e-9)
    if distance <= tolerance:
        return None, "common-face centroids are not distinct"
    normal = first_evidence.unit_normal_xyz
    axial = _dot(delta, normal)
    residual = tuple(delta[index] - axial * normal[index] for index in range(3))
    if _norm(residual) > tolerance:
        return None, "common-face centroids are not collinear along the sweep direction"
    if first_evidence.section_signature != second_evidence.section_signature:
        return None, "common-face section signatures do not match"
    direction = tuple(value / distance for value in delta)
    ordered_ids = tuple(sorted((first.interface_id, second.interface_id)))
    return (
        SurfaceTransportLink(
            through_component_id=component_id,
            interface_ids=ordered_ids,  # type: ignore[arg-type]
            direction_xyz=direction,  # type: ignore[arg-type]
            distance_mm=distance,
            section_signature=first_evidence.section_signature,
        ),
        None,
    )


def _continuity_links(
    interfaces: Sequence[NegotiatedComponentInterface],
    requirements: Mapping[str, ComponentMeshRequirement],
    interface_geometry_tolerance_mm: float,
    sweep_direction_xyz_by_component: Mapping[str, Vec3],
) -> tuple[
    tuple[SurfaceTransportLink, ...],
    tuple[RejectedSurfaceTransportPair, ...],
]:
    incident: dict[str, list[NegotiatedComponentInterface]] = defaultdict(list)
    for interface in interfaces:
        for component_id in interface.component_ids:
            incident[component_id].append(interface)
    links: list[SurfaceTransportLink] = []
    rejections: list[RejectedSurfaceTransportPair] = []
    for component_id in sorted(incident):
        requirement = requirements[component_id]
        if requirement.volume_topology == "conformal_hybrid":
            continue
        faces = tuple(sorted(incident[component_id], key=lambda value: value.interface_id))
        if len(faces) < 2:
            continue
        candidates: list[SurfaceTransportLink] = []
        expected_sweep_direction = (
            None
            if requirement.volume_topology != "structured_sweep"
            else sweep_direction_xyz_by_component[component_id]
        )
        for first_index, first in enumerate(faces):
            for second in faces[first_index + 1 :]:
                link, reason = _transport_link(
                    component_id,
                    first,
                    second,
                    interface_geometry_tolerance_mm,
                    expected_sweep_direction,
                )
                if link is not None:
                    candidates.append(link)
                elif reason is not None:
                    rejections.append(
                        RejectedSurfaceTransportPair(
                            through_component_id=component_id,
                            interface_ids=tuple(
                                sorted((first.interface_id, second.interface_id))
                            ),  # type: ignore[arg-type]
                            reason=reason,
                        )
                    )
        ownership: dict[str, list[SurfaceTransportLink]] = defaultdict(list)
        for candidate in candidates:
            for interface_id in candidate.interface_ids:
                ownership[interface_id].append(candidate)
        ambiguous = {
            interface_id: values
            for interface_id, values in ownership.items()
            if len(values) > 1
        }
        if ambiguous:
            raise GeneratedInterfaceContinuityError(
                f"component {component_id!r} has ambiguous parallel sweep faces: "
                + ", ".join(sorted(ambiguous))
            )
        links.extend(candidates)
    return (
        tuple(
            sorted(
                links,
                key=lambda value: (
                    value.interface_ids,
                    value.through_component_id,
                ),
            )
        ),
        tuple(
            sorted(
                rejections,
                key=lambda value: (
                    value.interface_ids,
                    value.through_component_id,
                ),
            )
        ),
    )


def plan_generated_interface_continuity(
    interfaces: Sequence[NegotiatedComponentInterface],
    requirements: Mapping[str, ComponentMeshRequirement],
    *,
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
    sweep_direction_xyz_by_component: Mapping[str, Vec3] | None = None,
) -> GeneratedInterfaceContinuityPlan:
    """Build surface-equivalence groups from real negotiated common faces.

    Structured-sweep and orthogonal-HEX bodies may connect two corresponding
    end faces.  Every Sweep Component requires one explicit package-frame signed
    direction.  A Sweep link additionally has to lie on that axis; production
    lowering derives it from the user's Component-local direction and fragment
    placement.  Geometry never supplies a fallback direction.
    Hybrid bodies never connect faces.  Group surface constraints use the
    strongest actual member requirement: Cartesian QUAD for any orthogonal
    member, inherited sweep surface for any sweep member, otherwise Gmsh
    conformal.  Target size is the group minimum; each component retains its
    own transition distance.
    """

    try:
        tolerance = validate_interface_geometry_tolerance_mm(
            interface_geometry_tolerance_mm
        )
    except ValueError as error:
        raise GeneratedInterfaceContinuityError(str(error)) from error
    normalized, policies = _validate_inputs(interfaces, requirements)
    explicit_sweep_directions = _normalize_explicit_sweep_directions(
        policies,
        sweep_direction_xyz_by_component,
    )
    if not normalized:
        return GeneratedInterfaceContinuityPlan(
            (),
            (),
            (),
            MappingProxyType({}),
            explicit_sweep_directions,
        )
    links, rejections = _continuity_links(
        normalized,
        policies,
        tolerance,
        explicit_sweep_directions,
    )
    parent = {interface.interface_id: interface.interface_id for interface in normalized}

    def find(value: str) -> str:
        while parent[value] != value:
            parent[value] = parent[parent[value]]
            value = parent[value]
        return value

    def union(first: str, second: str) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root == second_root:
            return
        canonical_first, canonical_second = sorted((first_root, second_root))
        parent[canonical_second] = canonical_first

    for link in links:
        union(*link.interface_ids)
    members: dict[str, list[NegotiatedComponentInterface]] = defaultdict(list)
    for interface in normalized:
        members[find(interface.interface_id)].append(interface)
    ordered_member_sets = tuple(
        sorted(
            (tuple(sorted(values, key=lambda value: value.interface_id)) for values in members.values()),
            key=lambda values: values[0].interface_id,
        )
    )
    groups: list[GeneratedSurfaceEquivalenceGroup] = []
    group_by_interface: dict[str, str] = {}
    for index, values in enumerate(ordered_member_sets, start=1):
        group_id = f"generated-surface-group-{index}"
        interface_ids = tuple(value.interface_id for value in values)
        component_ids = tuple(
            sorted({component for value in values for component in value.component_ids})
        )
        topologies = {policies[value].volume_topology for value in component_ids}
        surface_policy, surface_kinds = _expected_surface_policy(topologies)
        transport_components = tuple(
            sorted(
                {
                    link.through_component_id
                    for link in links
                    if set(link.interface_ids).issubset(interface_ids)
                }
            )
        )
        group = GeneratedSurfaceEquivalenceGroup(
            group_id=group_id,
            interface_ids=interface_ids,
            component_ids=component_ids,
            transport_component_ids=transport_components,
            surface_policy=surface_policy,
            permitted_surface_element_kinds=surface_kinds,
            target_edge_mm=min(policies[value].target_edge_mm for value in component_ids),
            transition_distance_mm_by_component=MappingProxyType(
                {
                    value: policies[value].transition_distance_mm
                    for value in component_ids
                }
            ),
        )
        groups.append(group)
        group_by_interface.update({value: group_id for value in interface_ids})
    return GeneratedInterfaceContinuityPlan(
        groups=tuple(groups),
        transport_links=links,
        rejected_transport_pairs=rejections,
        group_id_by_interface=MappingProxyType(group_by_interface),
        sweep_direction_xyz_by_component=explicit_sweep_directions,
    )


__all__ = [
    "GeneratedInterfaceContinuityError",
    "GeneratedInterfaceContinuityPlan",
    "GeneratedSurfaceEquivalenceGroup",
    "RejectedSurfaceTransportPair",
    "SurfaceTransportLink",
    "plan_generated_interface_continuity",
    "resolve_package_frame_sweep_directions",
]
