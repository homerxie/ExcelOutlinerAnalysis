"""Extrude a planar cell patch and fill its prism with hybrid star cells.

This is a small, Gmsh-independent adapter around
:func:`easymesh.hybrid_bulk.fill_hybrid_bulk`.  A connected, simply connected
patch of counter-clockwise TRI3/QUAD4 cells is copied to ``z_bottom`` and
``z_top``.  Boundary edges of the patch become vertical QUAD4 facets, giving
one closed prism shell.  The shell is then filled with TET4/PYRAMID5 cells from
one visibility-kernel point.

The adapter deliberately fails closed.  In particular, the planar patch must
be embedded, the boundary must be one loop, and its strict visibility kernel
must have non-zero area.  A concave footprint is supported when that kernel is
non-empty; a non-star-shaped footprint is rejected before volume elements are
created.

Bottom and top cells are retained as complete boundary facets.  A QUAD4 on
either horizontal face, or any vertical side QUAD4, may additionally be marked
``locked``.  Locked facets remain complete PYRAMID5 bases.  The companion
:func:`validate_shared_locked_interface` proves that two independently filled
macroblocks use the same node ids and coordinates with opposite outward
orientations on their locked docking interface.

The module is used by the package builder's limited Phase-2 hybrid demo above
the protected UF/contact height.  It remains deliberately small: it changes
the thickness schedule of one planar footprint, but does not agglomerate the
XY topology.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass
from enum import Enum
import math
from types import MappingProxyType
from typing import TypeAlias

from .hybrid_bulk import (
    BoundaryFacet,
    BoundaryFacetKind,
    HybridBulkError,
    HybridBulkMesh,
    Point3D,
    StarElement,
    StarElementKind,
    fill_hybrid_bulk,
)


Point2D: TypeAlias = tuple[float, float]
PlanarEdge: TypeAlias = tuple[int, int]


class HybridPrismError(HybridBulkError):
    """Raised when a planar patch cannot safely become one hybrid prism."""


class PlanarCellKind(str, Enum):
    """Supported first-order cells in the source XY patch."""

    TRI3 = "TRI3"
    QUAD4 = "QUAD4"


class PrismFaceLocation(str, Enum):
    """Location of a selectable QUAD4 docking face."""

    BOTTOM = "BOTTOM"
    TOP = "TOP"
    SIDE = "SIDE"


@dataclass(frozen=True, slots=True)
class PlanarCell:
    """One counter-clockwise TRI3 or strictly convex QUAD4 XY cell."""

    kind: PlanarCellKind
    node_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.kind, PlanarCellKind):
            raise HybridPrismError("planar cell kind must be TRI3 or QUAD4")
        try:
            canonical_node_ids = tuple(self.node_ids)
        except TypeError as exc:
            raise HybridPrismError(
                "planar cell node_ids must be a sequence"
            ) from exc
        object.__setattr__(self, "node_ids", canonical_node_ids)
        expected = 3 if self.kind is PlanarCellKind.TRI3 else 4
        if len(canonical_node_ids) != expected:
            raise HybridPrismError(
                f"{self.kind.value} planar cell requires {expected} node ids, "
                f"got {len(canonical_node_ids)}"
            )
        if any(
            isinstance(node_id, bool) or not isinstance(node_id, int)
            for node_id in canonical_node_ids
        ):
            raise HybridPrismError("planar cell node ids must be integers")
        if len(set(canonical_node_ids)) != expected:
            raise HybridPrismError(
                f"{self.kind.value} planar cell contains repeated node ids: "
                f"{canonical_node_ids}"
            )

    @classmethod
    def tri3(cls, node_ids: Sequence[int]) -> PlanarCell:
        """Construct one counter-clockwise TRI3 cell."""

        return cls(PlanarCellKind.TRI3, node_ids)  # type: ignore[arg-type]

    @classmethod
    def quad4(cls, node_ids: Sequence[int]) -> PlanarCell:
        """Construct one counter-clockwise, convex QUAD4 cell."""

        return cls(PlanarCellKind.QUAD4, node_ids)  # type: ignore[arg-type]


@dataclass(frozen=True, slots=True)
class LockedPrismFace:
    """One requested locked QUAD4, expressed with source planar node ids.

    A bottom/top selection must identify a complete QUAD4 planar cell.  A side
    selection must identify one boundary edge.  Ordering is not significant
    for selection; the helper derives the correct outward orientation.
    """

    location: PrismFaceLocation
    planar_node_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.location, PrismFaceLocation):
            raise HybridPrismError(
                "locked prism face location must be BOTTOM, TOP, or SIDE"
            )
        try:
            canonical_node_ids = tuple(self.planar_node_ids)
        except TypeError as exc:
            raise HybridPrismError(
                "locked prism face planar_node_ids must be a sequence"
            ) from exc
        object.__setattr__(self, "planar_node_ids", canonical_node_ids)
        expected = 2 if self.location is PrismFaceLocation.SIDE else 4
        if len(canonical_node_ids) != expected:
            raise HybridPrismError(
                f"locked {self.location.value} face requires {expected} "
                f"planar node ids, got {len(canonical_node_ids)}"
            )
        if any(
            isinstance(node_id, bool) or not isinstance(node_id, int)
            for node_id in canonical_node_ids
        ):
            raise HybridPrismError("locked face planar node ids must be integers")
        if len(set(canonical_node_ids)) != expected:
            raise HybridPrismError("locked face contains repeated planar node ids")

    @classmethod
    def bottom(cls, planar_node_ids: Sequence[int]) -> LockedPrismFace:
        """Select a complete bottom QUAD4 cell as a locked face."""

        return cls(PrismFaceLocation.BOTTOM, planar_node_ids)  # type: ignore[arg-type]

    @classmethod
    def top(cls, planar_node_ids: Sequence[int]) -> LockedPrismFace:
        """Select a complete top QUAD4 cell as a locked face."""

        return cls(PrismFaceLocation.TOP, planar_node_ids)  # type: ignore[arg-type]

    @classmethod
    def side(cls, planar_node_ids: Sequence[int]) -> LockedPrismFace:
        """Select the vertical QUAD4 generated from one boundary edge."""

        return cls(PrismFaceLocation.SIDE, planar_node_ids)  # type: ignore[arg-type]


@dataclass(frozen=True, slots=True)
class PrismStarAudit:
    """Combinatorial proof that the star-fill complex is conformal."""

    boundary_base_count: int
    internal_triangle_count: int
    locked_base_count: int


@dataclass(frozen=True, slots=True)
class ExtrudedHybridPrism:
    """Checked hybrid fill plus its deterministic extrusion correspondence."""

    mesh: HybridBulkMesh
    planar_node_coordinates: Mapping[int, Point2D]
    planar_cells: tuple[PlanarCell, ...]
    bottom_node_ids: Mapping[int, int]
    top_node_ids: Mapping[int, int]
    boundary_edges: tuple[PlanarEdge, ...]
    bottom_facets: tuple[BoundaryFacet, ...]
    top_facets: tuple[BoundaryFacet, ...]
    side_facets: tuple[BoundaryFacet, ...]
    kernel_xy: Point2D
    z_bottom: float
    z_top: float
    audit: PrismStarAudit

    @property
    def node_coordinates(self) -> Mapping[int, Point3D]:
        """Forward the complete 3-D node mapping, including the kernel node."""

        return self.mesh.node_coordinates

    @property
    def elements(self) -> tuple[StarElement, ...]:
        """Return the generated TET4/PYRAMID5 cells."""

        return self.mesh.elements

    @property
    def locked_facets(self) -> tuple[BoundaryFacet, ...]:
        """Return all locked boundary facets in deterministic order."""

        return tuple(facet for facet in self.mesh.boundary_facets if facet.locked)


@dataclass(frozen=True, slots=True)
class SharedLockedInterfaceAudit:
    """Result of an exact locked-interface comparison between two prisms."""

    shared_face_count: int
    shared_node_id_keys: tuple[tuple[int, ...], ...]


def _canonical_xy(point: Sequence[float], *, label: str) -> Point2D:
    if isinstance(point, (str, bytes, bytearray)):
        raise HybridPrismError(f"{label} must contain exactly two coordinates")
    try:
        values = tuple(point)
    except TypeError as exc:
        raise HybridPrismError(
            f"{label} must contain exactly two coordinates"
        ) from exc
    if len(values) != 2 or any(isinstance(value, bool) for value in values):
        raise HybridPrismError(f"{label} must contain two finite coordinates")
    try:
        result = tuple(float(value) for value in values)
    except (TypeError, ValueError, OverflowError) as exc:
        raise HybridPrismError(
            f"{label} must contain two finite coordinates"
        ) from exc
    if any(not math.isfinite(value) for value in result):
        raise HybridPrismError(f"{label} must contain two finite coordinates")
    return result  # type: ignore[return-value]


def _finite_float(value: float, *, label: str) -> float:
    if isinstance(value, bool):
        raise HybridPrismError(f"{label} must be a finite number")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise HybridPrismError(f"{label} must be a finite number") from exc
    if not math.isfinite(result):
        raise HybridPrismError(f"{label} must be a finite number")
    return result


def _parse_relative_tolerance(value: float) -> float:
    result = _finite_float(value, label="relative_tolerance")
    if not 0.0 < result < 1.0:
        raise HybridPrismError(
            "relative_tolerance must be finite and between 0 and 1"
        )
    return result


def _cross2(first: Point2D, second: Point2D, third: Point2D) -> float:
    return (
        (second[0] - first[0]) * (third[1] - first[1])
        - (second[1] - first[1]) * (third[0] - first[0])
    )


def _distance(first: Point2D, second: Point2D) -> float:
    return math.hypot(second[0] - first[0], second[1] - first[1])


def _canonical_cycle(node_ids: tuple[int, ...]) -> tuple[int, ...]:
    anchor = min(range(len(node_ids)), key=lambda index: node_ids[index])
    return node_ids[anchor:] + node_ids[:anchor]


def _canonical_cell(cell: PlanarCell) -> PlanarCell:
    return PlanarCell(cell.kind, _canonical_cycle(cell.node_ids))


def _cell_edges(cell: PlanarCell) -> tuple[PlanarEdge, ...]:
    return tuple(
        (cell.node_ids[index], cell.node_ids[(index + 1) % len(cell.node_ids)])
        for index in range(len(cell.node_ids))
    )


def _geometry_tolerance(
    coordinates: Mapping[int, Point2D],
    *,
    relative_tolerance: float,
) -> tuple[float, float]:
    xs = tuple(point[0] for point in coordinates.values())
    ys = tuple(point[1] for point in coordinates.values())
    scale = max(max(xs) - min(xs), max(ys) - min(ys))
    if scale <= 0.0 or not math.isfinite(scale):
        raise HybridPrismError("planar patch has zero spatial extent")
    coordinate_scale = max(
        scale,
        max(abs(value) for point in coordinates.values() for value in point),
    )
    length_tolerance = max(
        relative_tolerance * scale,
        64.0 * math.ulp(coordinate_scale),
    )
    return length_tolerance, length_tolerance * scale


def _validate_cell_geometry(
    cell: PlanarCell,
    coordinates: Mapping[int, Point2D],
    *,
    area_tolerance: float,
) -> None:
    points = tuple(coordinates[node_id] for node_id in cell.node_ids)
    double_area = math.fsum(
        points[index][0] * points[(index + 1) % len(points)][1]
        - points[(index + 1) % len(points)][0] * points[index][1]
        for index in range(len(points))
    )
    if double_area <= area_tolerance:
        raise HybridPrismError(
            f"{cell.kind.value} planar cell {cell.node_ids} must be "
            "counter-clockwise and non-degenerate"
        )
    if cell.kind is PlanarCellKind.QUAD4:
        for index in range(4):
            previous = points[index - 1]
            current = points[index]
            following = points[(index + 1) % 4]
            if _cross2(previous, current, following) <= area_tolerance:
                raise HybridPrismError(
                    f"QUAD4 planar cell {cell.node_ids} must be strictly "
                    "convex and cyclically ordered"
                )


def _segments_intersect(
    first: tuple[Point2D, Point2D],
    second: tuple[Point2D, Point2D],
    *,
    length_tolerance: float,
    area_tolerance: float,
) -> bool:
    """Return whether two closed segments intersect within tolerance."""

    a, b = first
    c, d = second
    turns = (
        _cross2(a, b, c),
        _cross2(a, b, d),
        _cross2(c, d, a),
        _cross2(c, d, b),
    )
    if (
        max(min(a[0], b[0]), min(c[0], d[0]))
        > min(max(a[0], b[0]), max(c[0], d[0])) + length_tolerance
        or max(min(a[1], b[1]), min(c[1], d[1]))
        > min(max(a[1], b[1]), max(c[1], d[1])) + length_tolerance
    ):
        return False
    return (
        turns[0] * turns[1] <= area_tolerance * area_tolerance
        and turns[2] * turns[3] <= area_tolerance * area_tolerance
    )


def _validate_planar_embedding(
    edges: Sequence[PlanarEdge],
    coordinates: Mapping[int, Point2D],
    *,
    length_tolerance: float,
    area_tolerance: float,
) -> None:
    unique_edges = tuple(
        sorted(
            {tuple(sorted(edge)) for edge in edges},
            key=lambda edge: (edge[0], edge[1]),
        )
    )
    for first_index, first_edge in enumerate(unique_edges):
        for second_edge in unique_edges[first_index + 1 :]:
            shared_ids = set(first_edge).intersection(second_edge)
            if shared_ids:
                # Distinct mesh edges are allowed to meet only at their one
                # shared endpoint.  Collinear overlap is caught by testing an
                # endpoint not shared by the pair.
                if len(shared_ids) != 1:
                    continue
                shared_id = next(iter(shared_ids))
                first_other = next(node for node in first_edge if node != shared_id)
                second_other = next(node for node in second_edge if node != shared_id)
                shared = coordinates[shared_id]
                if (
                    abs(
                        _cross2(
                            coordinates[first_other],
                            shared,
                            coordinates[second_other],
                        )
                    )
                    <= area_tolerance
                    and (
                        (coordinates[first_other][0] - shared[0])
                        * (coordinates[second_other][0] - shared[0])
                        + (coordinates[first_other][1] - shared[1])
                        * (coordinates[second_other][1] - shared[1])
                    )
                    > 0.0
                ):
                    raise HybridPrismError(
                        "planar patch contains overlapping collinear edges "
                        f"{first_edge} and {second_edge}"
                    )
                continue
            if _segments_intersect(
                (coordinates[first_edge[0]], coordinates[first_edge[1]]),
                (coordinates[second_edge[0]], coordinates[second_edge[1]]),
                length_tolerance=length_tolerance,
                area_tolerance=area_tolerance,
            ):
                raise HybridPrismError(
                    "planar patch contains crossing or touching non-adjacent "
                    f"edges {first_edge} and {second_edge}"
                )


def _extract_boundary_edges(
    cells: Sequence[PlanarCell],
) -> tuple[PlanarEdge, ...]:
    incidences: dict[tuple[int, int], list[tuple[int, int, int]]] = defaultdict(list)
    for cell_index, cell in enumerate(cells):
        for start, end in _cell_edges(cell):
            incidences[min(start, end), max(start, end)].append(
                (cell_index, start, end)
            )

    overused = tuple(
        (edge, len(owners))
        for edge, owners in sorted(incidences.items())
        if len(owners) > 2
    )
    if overused:
        raise HybridPrismError(
            "planar patch is non-manifold: an edge belongs to more than two "
            f"cells ({overused[:4]})"
        )
    inconsistent = tuple(
        edge
        for edge, owners in sorted(incidences.items())
        if len(owners) == 2
        and (owners[0][1], owners[0][2]) != (owners[1][2], owners[1][1])
    )
    if inconsistent:
        raise HybridPrismError(
            "adjacent planar cells have inconsistent orientation on shared "
            f"edges ({inconsistent[:6]})"
        )

    adjacency: list[set[int]] = [set() for _cell in cells]
    for owners in incidences.values():
        if len(owners) == 2:
            first = owners[0][0]
            second = owners[1][0]
            adjacency[first].add(second)
            adjacency[second].add(first)
    visited: set[int] = set()
    pending = [0]
    while pending:
        current = pending.pop()
        if current in visited:
            continue
        visited.add(current)
        pending.extend(adjacency[current].difference(visited))
    if len(visited) != len(cells):
        raise HybridPrismError(
            "planar patch cells must form one edge-connected component"
        )

    boundary = tuple(
        owners[0][1:]
        for _edge, owners in sorted(incidences.items())
        if len(owners) == 1
    )
    outgoing: dict[int, list[int]] = defaultdict(list)
    incoming: dict[int, list[int]] = defaultdict(list)
    for start, end in boundary:
        outgoing[start].append(end)
        incoming[end].append(start)
    boundary_vertices = set(outgoing).union(incoming)
    invalid_degrees = tuple(
        (
            vertex,
            len(incoming.get(vertex, ())),
            len(outgoing.get(vertex, ())),
        )
        for vertex in sorted(boundary_vertices)
        if len(incoming.get(vertex, ())) != 1
        or len(outgoing.get(vertex, ())) != 1
    )
    if invalid_degrees:
        raise HybridPrismError(
            "planar patch boundary must be a manifold loop; invalid "
            f"in/out degrees {invalid_degrees[:6]}"
        )

    # Walk all directed loops.  More than one means a hole; a single star
    # kernel cannot safely fill that extruded shell.
    remaining = set(boundary)
    loops: list[tuple[PlanarEdge, ...]] = []
    while remaining:
        first = min(remaining)
        loop: list[PlanarEdge] = []
        current = first
        while current in remaining:
            remaining.remove(current)
            loop.append(current)
            current = (current[1], outgoing[current[1]][0])
        if current != first:
            raise HybridPrismError("planar patch boundary loop does not close")
        loops.append(tuple(loop))
    if len(loops) != 1:
        raise HybridPrismError(
            "planar patch must be simply connected with one boundary loop, "
            f"got {len(loops)} loops"
        )
    return loops[0]


def _clip_visibility_kernel(
    coordinates: Mapping[int, Point2D],
    boundary_edges: Sequence[PlanarEdge],
    *,
    length_tolerance: float,
    area_tolerance: float,
) -> tuple[Point2D, tuple[Point2D, ...]]:
    xs = tuple(point[0] for point in coordinates.values())
    ys = tuple(point[1] for point in coordinates.values())
    polygon: list[Point2D] = [
        (min(xs), min(ys)),
        (max(xs), min(ys)),
        (max(xs), max(ys)),
        (min(xs), max(ys)),
    ]

    for start_id, end_id in boundary_edges:
        start = coordinates[start_id]
        end = coordinates[end_id]
        clipped: list[Point2D] = []
        if not polygon:
            break
        previous = polygon[-1]
        previous_value = _cross2(start, end, previous)
        previous_inside = previous_value >= -area_tolerance
        for current in polygon:
            current_value = _cross2(start, end, current)
            current_inside = current_value >= -area_tolerance
            if current_inside != previous_inside:
                denominator = previous_value - current_value
                if abs(denominator) > area_tolerance:
                    fraction = previous_value / denominator
                    clipped.append(
                        (
                            previous[0] + fraction * (current[0] - previous[0]),
                            previous[1] + fraction * (current[1] - previous[1]),
                        )
                    )
            if current_inside:
                clipped.append(current)
            previous = current
            previous_value = current_value
            previous_inside = current_inside

        deduplicated: list[Point2D] = []
        for point in clipped:
            if not deduplicated or _distance(deduplicated[-1], point) > length_tolerance:
                deduplicated.append(point)
        if (
            len(deduplicated) > 1
            and _distance(deduplicated[0], deduplicated[-1]) <= length_tolerance
        ):
            deduplicated.pop()
        polygon = deduplicated

    if len(polygon) < 3:
        raise HybridPrismError(
            "planar footprint is not strictly star-shaped: visibility kernel "
            "is empty or lower-dimensional"
        )
    double_area = abs(
        math.fsum(
            polygon[index][0] * polygon[(index + 1) % len(polygon)][1]
            - polygon[(index + 1) % len(polygon)][0] * polygon[index][1]
            for index in range(len(polygon))
        )
    )
    if double_area <= area_tolerance:
        raise HybridPrismError(
            "planar footprint is not strictly star-shaped: visibility kernel "
            "has zero usable area"
        )

    # A convex combination with every vertex weighted positively lies in the
    # strict interior of the full-dimensional convex visibility kernel.
    kernel = (
        math.fsum(point[0] for point in polygon) / len(polygon),
        math.fsum(point[1] for point in polygon) / len(polygon),
    )
    _validate_kernel_xy(
        kernel,
        coordinates,
        boundary_edges,
        length_tolerance=length_tolerance,
    )
    return kernel, tuple(polygon)


def _validate_kernel_xy(
    kernel: Point2D,
    coordinates: Mapping[int, Point2D],
    boundary_edges: Sequence[PlanarEdge],
    *,
    length_tolerance: float,
) -> None:
    for edge in boundary_edges:
        start = coordinates[edge[0]]
        end = coordinates[edge[1]]
        signed_distance = _cross2(start, end, kernel) / _distance(start, end)
        if signed_distance <= length_tolerance:
            raise HybridPrismError(
                "kernel_xy must lie strictly inside the footprint visibility "
                f"kernel; failed at boundary edge {edge}"
            )


def _canonical_id_map(
    supplied: Mapping[int, int] | None,
    planar_ids: tuple[int, ...],
    *,
    label: str,
    default_start: int | None = None,
) -> dict[int, int]:
    if supplied is None:
        if default_start is None:
            return {node_id: node_id for node_id in planar_ids}
        return {
            node_id: default_start + index
            for index, node_id in enumerate(planar_ids)
        }
    if not isinstance(supplied, Mapping):
        raise HybridPrismError(f"{label} must be a mapping")
    if set(supplied) != set(planar_ids):
        missing = tuple(sorted(set(planar_ids).difference(supplied)))
        extra = tuple(sorted(set(supplied).difference(planar_ids)))
        raise HybridPrismError(
            f"{label} keys must exactly match planar nodes; missing={missing}, "
            f"extra={extra}"
        )
    result: dict[int, int] = {}
    for planar_id in planar_ids:
        node_id = supplied[planar_id]
        if isinstance(node_id, bool) or not isinstance(node_id, int):
            raise HybridPrismError(f"{label} values must be integer node ids")
        result[planar_id] = node_id
    if len(set(result.values())) != len(result):
        raise HybridPrismError(f"{label} values must be one-to-one")
    return result


def _locked_selection_keys(
    locked_faces: Collection[LockedPrismFace],
    cells: Sequence[PlanarCell],
    boundary_edges: Sequence[PlanarEdge],
) -> set[tuple[PrismFaceLocation, frozenset[int]]]:
    if isinstance(locked_faces, (str, bytes, bytearray)):
        raise HybridPrismError("locked_faces must be a collection")
    try:
        locked_tuple = tuple(locked_faces)
    except TypeError as exc:
        raise HybridPrismError("locked_faces must be a collection") from exc
    if any(not isinstance(face, LockedPrismFace) for face in locked_tuple):
        raise HybridPrismError(
            "every locked_faces entry must be a LockedPrismFace"
        )
    keys = {
        (face.location, frozenset(face.planar_node_ids)) for face in locked_tuple
    }
    if len(keys) != len(locked_tuple):
        raise HybridPrismError("locked_faces contains duplicate selections")

    quad_keys = {
        frozenset(cell.node_ids)
        for cell in cells
        if cell.kind is PlanarCellKind.QUAD4
    }
    boundary_keys = {frozenset(edge) for edge in boundary_edges}
    for location, key in sorted(
        keys,
        key=lambda item: (item[0].value, tuple(sorted(item[1]))),
    ):
        valid = key in (
            boundary_keys if location is PrismFaceLocation.SIDE else quad_keys
        )
        if not valid:
            expected = "boundary edge" if location is PrismFaceLocation.SIDE else "QUAD4 cell"
            raise HybridPrismError(
                f"locked {location.value} selection {tuple(sorted(key))} does "
                f"not identify a complete {expected}"
            )
    return keys


def _facet_tuple_for_ids(
    mesh: HybridBulkMesh,
    requested: Sequence[BoundaryFacet],
) -> tuple[BoundaryFacet, ...]:
    by_key = {
        frozenset(facet.node_ids): facet for facet in mesh.boundary_facets
    }
    return tuple(
        by_key[frozenset(facet.node_ids)]
        for facet in requested
    )


def _audit_star_complex(mesh: HybridBulkMesh) -> PrismStarAudit:
    boundary_keys = {
        frozenset(facet.node_ids): facet for facet in mesh.boundary_facets
    }
    if len(boundary_keys) != len(mesh.boundary_facets):
        raise HybridPrismError("star fill contains duplicate boundary bases")
    element_bases: dict[frozenset[int], StarElement] = {}
    internal_triangles: dict[frozenset[int], int] = defaultdict(int)
    for element in mesh.elements:
        base_key = frozenset(element.source_facet_node_ids)
        if base_key in element_bases:
            raise HybridPrismError("more than one star element owns a boundary base")
        element_bases[base_key] = element
        source = element.source_facet_node_ids
        for index, first in enumerate(source):
            second = source[(index + 1) % len(source)]
            internal_triangles[frozenset((first, second, mesh.kernel_node_id))] += 1
    if set(element_bases) != set(boundary_keys):
        raise HybridPrismError(
            "star elements do not preserve the complete boundary-facet set"
        )
    bad_internal = tuple(
        (tuple(sorted(key)), count)
        for key, count in sorted(
            internal_triangles.items(), key=lambda item: tuple(sorted(item[0]))
        )
        if count != 2
    )
    if bad_internal:
        raise HybridPrismError(
            "star elements do not share every radial triangle exactly twice: "
            f"{bad_internal[:6]}"
        )
    locked_count = 0
    for key, facet in boundary_keys.items():
        element = element_bases[key]
        if set(element.base_node_ids) != set(facet.node_ids):
            raise HybridPrismError("star element base changed a boundary facet")
        if facet.locked:
            locked_count += 1
            if element.kind is not StarElementKind.PYRAMID5:
                raise HybridPrismError(
                    "a locked QUAD4 was not retained as a PYRAMID5 base"
                )
    return PrismStarAudit(
        boundary_base_count=len(boundary_keys),
        internal_triangle_count=len(internal_triangles),
        locked_base_count=locked_count,
    )


def fill_extruded_planar_prism(
    planar_node_coordinates: Mapping[int, Sequence[float]],
    planar_cells: Sequence[PlanarCell],
    z_bottom: float,
    z_top: float,
    *,
    bottom_node_ids: Mapping[int, int] | None = None,
    top_node_ids: Mapping[int, int] | None = None,
    kernel_xy: Sequence[float] | None = None,
    kernel_node_id: int | None = None,
    locked_faces: Collection[LockedPrismFace] = (),
    relative_tolerance: float = 1.0e-10,
) -> ExtrudedHybridPrism:
    """Extrude one planar patch and star-fill the resulting closed prism.

    ``planar_cells`` must use counter-clockwise XY connectivity.  Bottom and
    top node-id maps allow exact reuse of nodes from neighbouring macroblocks;
    absent maps use the planar ids on the bottom and fresh ids on the top.
    ``kernel_xy=None`` deterministically selects an interior point from the
    footprint's visibility kernel.  A supplied point is still checked against
    every boundary half-plane.
    """

    relative_tolerance = _parse_relative_tolerance(relative_tolerance)
    bottom_z = _finite_float(z_bottom, label="z_bottom")
    top_z = _finite_float(z_top, label="z_top")
    if top_z <= bottom_z:
        raise HybridPrismError("z_top must be greater than z_bottom")
    if not isinstance(planar_node_coordinates, Mapping) or not planar_node_coordinates:
        raise HybridPrismError(
            "planar_node_coordinates must be a non-empty mapping"
        )
    if isinstance(planar_cells, (str, bytes, bytearray)):
        raise HybridPrismError("planar_cells must be a sequence of PlanarCell")
    try:
        raw_cells = tuple(planar_cells)
    except TypeError as exc:
        raise HybridPrismError(
            "planar_cells must be a sequence of PlanarCell"
        ) from exc
    if not raw_cells or any(not isinstance(cell, PlanarCell) for cell in raw_cells):
        raise HybridPrismError(
            "planar_cells must be a non-empty sequence of PlanarCell"
        )
    cells = tuple(
        sorted(
            (_canonical_cell(cell) for cell in raw_cells),
            key=lambda cell: (
                tuple(sorted(cell.node_ids)),
                cell.kind.value,
                cell.node_ids,
            ),
        )
    )
    cell_keys = tuple(frozenset(cell.node_ids) for cell in cells)
    if len(cell_keys) != len(set(cell_keys)):
        raise HybridPrismError("planar_cells contains duplicate cells")

    referenced_ids = tuple(
        sorted({node_id for cell in cells for node_id in cell.node_ids})
    )
    missing = tuple(sorted(set(referenced_ids).difference(planar_node_coordinates)))
    if missing:
        raise HybridPrismError(f"planar cells reference missing nodes: {missing}")
    coordinates: dict[int, Point2D] = {}
    for node_id in referenced_ids:
        if isinstance(node_id, bool) or not isinstance(node_id, int):
            raise HybridPrismError("planar node ids must be integers")
        coordinates[node_id] = _canonical_xy(
            planar_node_coordinates[node_id], label=f"planar node {node_id}"
        )
    coordinate_owners: dict[Point2D, int] = {}
    for node_id, point in coordinates.items():
        previous = coordinate_owners.setdefault(point, node_id)
        if previous != node_id:
            raise HybridPrismError(
                f"planar nodes {previous} and {node_id} have duplicate coordinates"
            )
    length_tolerance, area_tolerance = _geometry_tolerance(
        coordinates,
        relative_tolerance=relative_tolerance,
    )
    for cell in cells:
        _validate_cell_geometry(
            cell, coordinates, area_tolerance=area_tolerance
        )
    all_edges = tuple(edge for cell in cells for edge in _cell_edges(cell))
    _validate_planar_embedding(
        all_edges,
        coordinates,
        length_tolerance=length_tolerance,
        area_tolerance=area_tolerance,
    )
    boundary_edges = _extract_boundary_edges(cells)
    automatic_kernel, _kernel_polygon = _clip_visibility_kernel(
        coordinates,
        boundary_edges,
        length_tolerance=length_tolerance,
        area_tolerance=area_tolerance,
    )
    if kernel_xy is None:
        chosen_kernel = automatic_kernel
    else:
        chosen_kernel = _canonical_xy(kernel_xy, label="kernel_xy")
        _validate_kernel_xy(
            chosen_kernel,
            coordinates,
            boundary_edges,
            length_tolerance=length_tolerance,
        )

    bottom_ids = _canonical_id_map(
        bottom_node_ids,
        referenced_ids,
        label="bottom_node_ids",
    )
    top_start = max(bottom_ids.values()) + 1
    top_ids = _canonical_id_map(
        top_node_ids,
        referenced_ids,
        label="top_node_ids",
        default_start=top_start,
    )
    overlap = tuple(sorted(set(bottom_ids.values()).intersection(top_ids.values())))
    if overlap:
        raise HybridPrismError(
            f"bottom and top node ids must be disjoint; overlap={overlap}"
        )
    lock_keys = _locked_selection_keys(locked_faces, cells, boundary_edges)

    nodes3d: dict[int, tuple[float, float, float]] = {}
    for planar_id in referenced_ids:
        x, y = coordinates[planar_id]
        nodes3d[bottom_ids[planar_id]] = (x, y, bottom_z)
        nodes3d[top_ids[planar_id]] = (x, y, top_z)

    requested_bottom: list[BoundaryFacet] = []
    requested_top: list[BoundaryFacet] = []
    for cell in cells:
        planar_key = frozenset(cell.node_ids)
        bottom_cycle = tuple(
            reversed(tuple(bottom_ids[node_id] for node_id in cell.node_ids))
        )
        top_cycle = tuple(top_ids[node_id] for node_id in cell.node_ids)
        if cell.kind is PlanarCellKind.TRI3:
            requested_bottom.append(BoundaryFacet.tri3(bottom_cycle))
            requested_top.append(BoundaryFacet.tri3(top_cycle))
        else:
            requested_bottom.append(
                BoundaryFacet.quad4(
                    bottom_cycle,
                    locked=(PrismFaceLocation.BOTTOM, planar_key) in lock_keys,
                )
            )
            requested_top.append(
                BoundaryFacet.quad4(
                    top_cycle,
                    locked=(PrismFaceLocation.TOP, planar_key) in lock_keys,
                )
            )

    requested_side = tuple(
        BoundaryFacet.quad4(
            (
                bottom_ids[start],
                bottom_ids[end],
                top_ids[end],
                top_ids[start],
            ),
            locked=(PrismFaceLocation.SIDE, frozenset((start, end))) in lock_keys,
        )
        for start, end in boundary_edges
    )
    requested_boundary = (
        tuple(requested_bottom) + tuple(requested_top) + requested_side
    )
    try:
        mesh = fill_hybrid_bulk(
            nodes3d,
            requested_boundary,
            (chosen_kernel[0], chosen_kernel[1], 0.5 * (bottom_z + top_z)),
            kernel_node_id=kernel_node_id,
            relative_tolerance=relative_tolerance,
        )
    except HybridBulkError as exc:
        raise HybridPrismError(f"extruded prism star fill failed: {exc}") from exc
    audit = _audit_star_complex(mesh)
    return ExtrudedHybridPrism(
        mesh=mesh,
        planar_node_coordinates=MappingProxyType(dict(sorted(coordinates.items()))),
        planar_cells=cells,
        bottom_node_ids=MappingProxyType(dict(sorted(bottom_ids.items()))),
        top_node_ids=MappingProxyType(dict(sorted(top_ids.items()))),
        boundary_edges=boundary_edges,
        bottom_facets=_facet_tuple_for_ids(mesh, requested_bottom),
        top_facets=_facet_tuple_for_ids(mesh, requested_top),
        side_facets=_facet_tuple_for_ids(mesh, requested_side),
        kernel_xy=chosen_kernel,
        z_bottom=bottom_z,
        z_top=top_z,
        audit=audit,
    )


def _cycles_are_opposite(
    first: tuple[int, ...],
    second: tuple[int, ...],
) -> bool:
    reversed_first = tuple(reversed(first))
    return any(
        second == reversed_first[offset:] + reversed_first[:offset]
        for offset in range(len(first))
    )


def validate_shared_locked_interface(
    first: ExtrudedHybridPrism,
    second: ExtrudedHybridPrism,
) -> SharedLockedInterfaceAudit:
    """Prove that two macroblocks have one exact locked QUAD interface set.

    All locked facets in each argument are treated as the intended interface.
    Their node-id sets must match exactly, coordinates must be identical, and
    outward cycles must be opposite.  Each face must be the base of exactly
    one PYRAMID5 on either side.
    """

    if not isinstance(first, ExtrudedHybridPrism) or not isinstance(
        second, ExtrudedHybridPrism
    ):
        raise HybridPrismError(
            "shared-interface arguments must be ExtrudedHybridPrism objects"
        )
    first_facets = {
        tuple(sorted(facet.node_ids)): facet for facet in first.locked_facets
    }
    second_facets = {
        tuple(sorted(facet.node_ids)): facet for facet in second.locked_facets
    }
    if not first_facets or not second_facets:
        raise HybridPrismError(
            "both macroblocks must select at least one locked interface face"
        )
    if set(first_facets) != set(second_facets):
        only_first = tuple(sorted(set(first_facets).difference(second_facets)))
        only_second = tuple(sorted(set(second_facets).difference(first_facets)))
        raise HybridPrismError(
            "locked interface face node ids do not match exactly; "
            f"only_first={only_first[:4]}, only_second={only_second[:4]}"
        )

    def element_by_source(
        prism: ExtrudedHybridPrism,
    ) -> dict[tuple[int, ...], StarElement]:
        return {
            tuple(sorted(element.source_facet_node_ids)): element
            for element in prism.elements
            if element.source_facet_locked
        }

    first_elements = element_by_source(first)
    second_elements = element_by_source(second)
    interface_keys = tuple(sorted(first_facets))
    if set(first_elements) != set(first_facets) or set(second_elements) != set(
        second_facets
    ):
        raise HybridPrismError(
            "locked interface is not owned by exactly one star element per side"
        )
    for key in interface_keys:
        first_facet = first_facets[key]
        second_facet = second_facets[key]
        if not _cycles_are_opposite(first_facet.node_ids, second_facet.node_ids):
            raise HybridPrismError(
                f"locked interface face {key} does not have opposite outward "
                "orientations"
            )
        for node_id in key:
            if first.node_coordinates[node_id] != second.node_coordinates[node_id]:
                raise HybridPrismError(
                    f"locked interface node {node_id} coordinates differ "
                    "between macroblocks"
                )
        if (
            first_elements[key].kind is not StarElementKind.PYRAMID5
            or second_elements[key].kind is not StarElementKind.PYRAMID5
        ):
            raise HybridPrismError(
                f"locked interface face {key} must remain a PYRAMID5 base"
            )
    return SharedLockedInterfaceAudit(
        shared_face_count=len(interface_keys),
        shared_node_id_keys=interface_keys,
    )


__all__ = [
    "ExtrudedHybridPrism",
    "HybridPrismError",
    "LockedPrismFace",
    "PlanarCell",
    "PlanarCellKind",
    "Point2D",
    "PrismFaceLocation",
    "PrismStarAudit",
    "SharedLockedInterfaceAudit",
    "fill_extruded_planar_prism",
    "validate_shared_locked_interface",
]
