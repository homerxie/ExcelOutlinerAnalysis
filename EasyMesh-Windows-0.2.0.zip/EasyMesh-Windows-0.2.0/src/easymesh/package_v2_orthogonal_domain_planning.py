"""Geometry-first planning of locally conforming, strictly Cartesian HEX blocks.

Blocks exchange the two tangential partitions of an actual common face.  An
axis schedule is never broadcast to a disconnected projection or across air.
Frozen QUADs constrain complete intervals, not just their corner coordinates.
This module is pure: it neither calls Gmsh nor changes an incoming mesh.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, replace
from itertools import combinations, product
from functools import lru_cache
import math

from .package_assembly import ComponentLocalDirection, OrthogonalHexMeshStrategy
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalGeometryFragment,
    CanonicalDifference,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalUnion,
)
from .package_v2_mesh_sizing import geometry_origin, interval_levels, ray_levels


class OrthogonalConstraintError(ValueError):
    """A final, located failure; never a request to try a transition backend."""

    def __init__(
        self,
        code,
        message,
        *,
        components=(),
        sources=(),
        axis=None,
        bounds=None,
        coordinates=(),
    ):
        evidence = {}
        for source in sources:
            identity = (
                source.get("component_id"),
                source.get("interface_id"),
                source.get("fragment_id"),
            )
            evidence.setdefault(identity, source)
        source_values = list(evidence.values())
        self.diagnostic = {
            "code": code,
            "severity": "error",
            "export_allowed": False,
            "backend": "orthogonal_hex",
            "component_ids": sorted(set(components)),
            "component_id": next(iter(components), ""),
            "sources": source_values[:32],
            "source_count": len(source_values),
            "sources_truncated": len(source_values) > 32,
            "axis": None if axis is None else "XYZ"[axis],
            "bounds_package_mm": bounds,
            "coordinates_mm": list(coordinates)[:32],
            "coordinate_count": len(coordinates),
            "coordinates_truncated": len(coordinates) > 32,
            "reason": message,
        }
        from .package_v2_warning_display import orthogonal_error_message

        super().__init__(orthogonal_error_message(self.diagnostic))


def key(point):
    return tuple(round(float(v), 12) for v in point)


def corners(bounds):
    return tuple(product(*bounds))


@lru_cache(maxsize=256)
def root_boxes(root):
    """Return a nonoverlapping local orthogonal cover, exact except for Fillet."""
    if isinstance(root, CanonicalBox):
        return (
            tuple((a, a + b) for a, b in zip(root.origin_xyz_mm, root.size_xyz_mm)),
        )
    if isinstance(root, CanonicalRectangularFrameExtrusion):
        x, y, z = root.outer_origin_xyz_mm
        sx, sy = root.outer_size_xy_mm
        hx, hy = (x + root.opening_offset_xy_mm[0], y + root.opening_offset_xy_mm[1])
        ex, ey = hx + root.opening_size_xy_mm[0], hy + root.opening_size_xy_mm[1]
        return tuple(
            ((a, b), (c, d), (z, z + root.height_mm))
            for a, b, c, d in (
                (x, x + sx, y, hy),
                (x, x + sx, ey, y + sy),
                (x, hx, hy, ey),
                (ex, x + sx, hy, ey),
            )
        )
    if isinstance(root, CanonicalRectangularUnderfillFillet):
        if root.uses_elliptical_sweep:
            raise ValueError("不等宽或外扩 fillet 请在 Mesh 页选择 conformal_hybrid")
        x, y = root.die_origin_xy_mm
        sx, sy = root.die_size_xy_mm
        w = max(root.toe_width_mm, root.top_width_mm)
        return root_boxes(
            CanonicalRectangularFrameExtrusion(
                (x - w, y - w, root.base_z_mm),
                (sx + 2 * w, sy + 2 * w),
                (w, w),
                (sx, sy),
                root.wall_height_mm,
            )
        )
    if isinstance(root, (CanonicalUnion, CanonicalDifference)):
        children = (
            root.children
            if isinstance(root, CanonicalUnion)
            else (root.base, *root.cutters)
        )
        if any(
            isinstance(child, CanonicalRectangularUnderfillFillet) for child in children
        ):
            raise OrthogonalConstraintError(
                "orth_geometry_unsupported",
                "CSG 布尔运算只接受正交 Box/Frame；Fillet 应作为独立 Solid 保留中心筛选语义。",
            )
        child_boxes = [root_boxes(child) for child in children]
        axes = [
            sorted({v for boxes in child_boxes for box in boxes for v in box[a]})
            for a in range(3)
        ]
        result = []
        for spans in product(*(tuple(zip(v, v[1:])) for v in axes)):
            center = tuple((a + b) / 2 for a, b in spans)
            inside = [
                any(all(a < p < b for p, (a, b) in zip(center, box)) for box in boxes)
                for boxes in child_boxes
            ]
            if (
                any(inside)
                if isinstance(root, CanonicalUnion)
                else inside[0] and not any(inside[1:])
            ):
                result.append(spans)
        return _merge_boxes(result)
    raise OrthogonalConstraintError(
        "orth_geometry_unsupported",
        f"当前 Orth 不支持几何 {type(root).__name__} 的正交分块。",
    )


def _merge_boxes(boxes):
    boxes = sorted(set(boxes))
    changed = True
    while changed:
        changed = False
        for axis in range(3):
            groups = defaultdict(list)
            for box in boxes:
                groups[tuple(box[a] for a in range(3) if a != axis)].append(box)
            merged = []
            for group in groups.values():
                current = None
                for box in sorted(group, key=lambda b: b[axis]):
                    if current is not None and current[axis][1] == box[axis][0]:
                        spans = list(current)
                        spans[axis] = (current[axis][0], box[axis][1])
                        current = tuple(spans)
                        changed = True
                    else:
                        if current is not None:
                            merged.append(current)
                        current = box
                if current is not None:
                    merged.append(current)
            boxes = sorted(merged)
    return tuple(boxes)


def to_package(point, placement):
    from .package_v2_orthogonal_box_frame_materializer import _to_package

    return key(_to_package(point, placement))


def to_local(point, placement):
    from .package_v2_orthogonal_box_frame_materializer import _to_local

    return _to_local(point, placement)


@dataclass(frozen=True)
class OrthogonalInput:
    component_id: str
    fragment: CanonicalGeometryFragment
    material: str
    priority: int
    target: float
    strategy: OrthogonalHexMeshStrategy


@dataclass(frozen=True)
class OrthogonalBlock:
    source: int
    bounds: tuple


@dataclass(frozen=True)
class OrthogonalQuad:
    source_component_id: str
    target_fragment_id: str
    interface_id: str
    points: tuple
    tokens: tuple

    def evidence(self):
        return {
            "component_id": self.source_component_id,
            "fragment_id": self.target_fragment_id,
            "interface_id": self.interface_id,
            "coordinates_package_mm": self.points,
        }


@dataclass(frozen=True)
class OrthogonalDomainPlan:
    inputs: tuple
    blocks: tuple
    neighbors: tuple
    levels: tuple
    domains: tuple
    inner_corners: tuple
    locks: tuple
    axis_sources: tuple

    def to_dict(self):
        return {
            "schema": "easymesh-orthogonal-domain-plan-v1",
            "coordinate_frame": "package_mm",
            "component_ids": sorted({s.component_id for s in self.inputs}),
            "blocks": [
                {
                    "fragment_id": self.inputs[b.source].fragment.fragment_id,
                    "bounds_mm": b.bounds,
                    "levels_mm": self.levels[i],
                    "domain": self.domains[i],
                    "axis_sources": self.axis_sources[i],
                }
                for i, b in enumerate(self.blocks)
            ],
            "inner_corners_package_mm": self.inner_corners,
            "inner_corner_sources": [
                {
                    "point_package_mm": point,
                    "blocks": [
                        {
                            "block_index": i,
                            "fragment_id": self.inputs[b.source].fragment.fragment_id,
                            "component_id": self.inputs[b.source].component_id,
                            "valid_directions": [
                                ("positive_" if end == 0 else "negative_") + "xyz"[a]
                                for a in range(3)
                                for end in (0, 1)
                                if point[a] == b.bounds[a][end]
                            ],
                            "bounds_package_mm": b.bounds,
                        }
                        for i, b in enumerate(self.blocks)
                        if all(lo <= v <= hi for v, (lo, hi) in zip(point, b.bounds))
                    ],
                }
                for point in self.inner_corners
            ],
            "neighbors": [list(v) for v in self.neighbors],
        }


def face_axis(a, b, tolerance=1e-10):
    for axis in range(3):
        if (
            abs(a[axis][1] - b[axis][0]) <= tolerance
            or abs(b[axis][1] - a[axis][0]) <= tolerance
        ):
            if all(
                min(a[t][1], b[t][1]) - max(a[t][0], b[t][0]) > tolerance
                for t in range(3)
                if t != axis
            ):
                return axis
    return None


def _split(block, cuts):
    spans = []
    for a, (lo, hi) in enumerate(block.bounds):
        values = [lo, *sorted(v for v in cuts[a] if lo < v < hi), hi]
        spans.append(tuple(zip(values, values[1:])))
    return [replace(block, bounds=b) for b in product(*spans)]


def _conforming_blocks(blocks, tolerance):
    """Imprint only actual partial contacts, iterating until block faces match."""
    while True:
        cuts = [[set() for _ in range(3)] for _ in blocks]
        for i, j in combinations(range(len(blocks)), 2):
            a, b = blocks[i].bounds, blocks[j].bounds
            axis = face_axis(a, b, tolerance)
            if axis is None:
                if not all(
                    min(a[t][1], b[t][1]) - max(a[t][0], b[t][0]) > tolerance
                    for t in range(3)
                ):
                    continue
            for t in range(3):
                if t == axis:
                    continue
                for v in b[t]:
                    if a[t][0] + tolerance < v < a[t][1] - tolerance:
                        cuts[i][t].add(v)
                for v in a[t]:
                    if b[t][0] + tolerance < v < b[t][1] - tolerance:
                        cuts[j][t].add(v)
        if not any(any(v) for v in cuts):
            return tuple(blocks)
        blocks = [
            part
            for block, values in zip(blocks, cuts)
            for part in _split(block, values)
        ]


class _Union:
    def __init__(self, n):
        self.p = list(range(n))

    def find(self, a):
        while a != self.p[a]:
            self.p[a] = self.p[self.p[a]]
            a = self.p[a]
        return a

    def join(self, a, b):
        a, b = self.find(a), self.find(b)
        self.p[max(a, b)] = min(a, b)


def _inner_corners(blocks):
    result = []
    for point in sorted({p for b in blocks for p in corners(b.bounds)}):
        occupied = set()
        for signs in product((-1, 1), repeat=3):
            if any(
                all(
                    (lo <= p < hi if s > 0 else lo < p <= hi)
                    for p, s, (lo, hi) in zip(point, signs, b.bounds)
                )
                for b in blocks
            ):
                occupied.add(signs)
        # A reentrant edge has three occupied quadrants in a transverse slice.
        if any(
            sum(s in occupied for s in product((-1, 1), repeat=3) if s[axis] == sign)
            == 3
            for axis in range(3)
            for sign in (-1, 1)
        ):
            result.append(point)
    return tuple(result)


@lru_cache(maxsize=256)
def root_boundary_rectangles(root):
    """Exact oriented planar rectangles for rectilinear CSG contact queries."""
    blocks = _conforming_blocks(
        [OrthogonalBlock(0, b) for b in root_boxes(root)], 1e-10
    )
    faces = defaultdict(list)
    for block in blocks:
        for axis in range(3):
            for end in (0, 1):
                spans = list(block.bounds)
                c = spans[axis][end]
                spans[axis] = (c, c)
                faces[tuple(spans)].append((axis, end))
    return tuple(
        (f"orth:{a}:{end}:{float(bounds[a][0]).hex()}", a, end, bounds)
        for bounds, owners in sorted(faces.items())
        if len(owners) == 1
        for a, end in owners
    )


def classify_rectilinear_side(root, points, tolerance):
    candidates = defaultdict(list)
    for side, a, end, bounds in root_boundary_rectangles(root):
        if all(abs(p[a] - bounds[a][0]) <= tolerance for p in points):
            candidates[side].append(bounds)
    for side, rectangles in candidates.items():
        if all(
            any(
                all(lo - tolerance <= v <= hi + tolerance for v, (lo, hi) in zip(p, b))
                for b in rectangles
            )
            for p in points
        ):
            return side
    return None


def rectilinear_side_overlaps(root, points, tolerance):
    from .package_v2_frozen_boundary_matching import (
        _polygon_rectangle_intersection_area,
    )

    areas = defaultdict(float)
    for side, axis, end, bounds in root_boundary_rectangles(root):
        if not all(abs(p[axis] - bounds[axis][0]) <= tolerance for p in points):
            continue
        u, v = [a for a in range(3) if a != axis]
        area = _polygon_rectangle_intersection_area(
            points, (*bounds[u], *bounds[v]), axes=(u, v), tolerance=tolerance
        )
        if area > tolerance * tolerance:
            areas[side] += area
    return dict(areas)


def orthogonal_corner_sizes(lower, upper, negative_size, positive_size, origin):
    """Choose each inward front's size from its corner's side of the Origin.

    Advancing toward negative coordinates does not imply the negative size:
    an upper corner above the Origin still belongs to its positive side. At
    the Origin itself, use the side into which that front starts. Automatic
    sizing without an Origin keeps the legacy inward-direction convention.
    """
    if origin is None:
        return positive_size, negative_size
    tolerance = max(upper - lower, negative_size, positive_size) * 1e-12
    return (
        positive_size if lower >= origin - tolerance else negative_size,
        negative_size if upper <= origin + tolerance else positive_size,
    )


def orthogonal_meeting_levels(lower, upper, left_size, right_size, ratio=0.25):
    """Protect both first cells; compress two colliding cells proportionally."""
    if not all(
        math.isfinite(v) for v in (lower, upper, left_size, right_size, ratio)
    ) or (upper <= lower or min(left_size, right_size) <= 0 or not 0 < ratio <= 1):
        raise ValueError(
            "Orth meeting interval, sizes and remainder ratio must be positive and finite"
        )
    length = upper - lower
    tol = max(length, left_size, right_size) * 1e-12
    if length <= left_size + right_size + tol:
        split = lower + length * (left_size / (left_size + right_size))
        return (lower, split, upper)
    mid = max(lower + left_size, min((lower + upper) / 2, upper - right_size))
    nl = max(1, math.floor((mid - lower) / left_size + 1e-12))
    nr = max(1, math.floor((upper - mid) / right_size + 1e-12))
    left = [lower + i * left_size for i in range(nl + 1)]
    right = [upper - i * right_size for i in range(nr + 1)]
    gap = right[-1] - left[-1]
    if gap <= tol:
        meeting = (left[-1] + right[-1]) / 2
        return (*left[:-1], meeting, *reversed(right[:-1]))
    if gap < ratio * min(left_size, right_size) - tol and (nl > 1 or nr > 1):
        # Remove a free interior front, never either protected first-cell edge.
        if nl > 1 and (nr == 1 or left_size <= right_size):
            left.pop()
        else:
            right.pop()
    return (*left, *reversed(right))


def _quad_bounds(quad, components, tolerance):
    points = tuple(key(p) for p in quad.points)

    def fail(code, reason):
        raise OrthogonalConstraintError(
            code, reason, components=components, sources=(quad.evidence(),)
        )

    if any(len(p) != 3 or not all(math.isfinite(v) for v in p) for p in points):
        fail("orth_interface_not_cartesian", "固定接口含非有限或无效节点坐标。")
    if len(points) != 4 or len(set(points)) != 4:
        fail(
            "orth_interface_not_quad",
            "接触面含非 QUAD 或退化面，不能生成严格正交 HEX8。",
        )
    values = [sorted({p[a] for p in points}) for a in range(3)]
    constant = [a for a, v in enumerate(values) if max(v) - min(v) <= tolerance]
    if len(constant) != 1 or any(
        len(values[a]) != 2 for a in range(3) if a not in constant
    ):
        fail("orth_interface_not_cartesian", "固定 QUAD 不是共同坐标系中的轴对齐矩形。")
    axis = constant[0]
    if set(product(*values)) != set(points):
        fail(
            "orth_interface_not_cartesian", "固定 QUAD 的四个节点不能构成完整正交矩形。"
        )
    if len(quad.tokens) != 4 or len(set(quad.tokens)) != 4:
        fail("orth_locked_identity_conflict", "固定 QUAD 必须保留四个不同节点身份。")
    if any(
        sum(abs(p[a] - q[a]) > tolerance for a in range(3)) != 1
        for p, q in zip(points, (*points[1:], points[0]))
    ):
        fail("orth_interface_not_cartesian", "固定 QUAD 的连接顺序包含对角线或自交。")
    return axis, tuple((min(v), max(v)) for v in values)


def _component_origins(inputs, blocks):
    """Resolve one origin per Component, including disconnected child solids."""
    from .package_v2_orthogonal_box_frame_materializer import _rotation_matrix

    origins = {}
    for component in sorted({s.component_id for s in inputs}):
        sources = [s for s in inputs if s.component_id == component]
        source = sources[0]
        sizing = source.strategy.sizing
        if len(sources) == 1 or sizing.origin in {"legacy", "custom"}:
            try:
                point = geometry_origin(
                    source.fragment.root, sizing, source.strategy.partition_origin_mm
                )
                origins[component] = (
                    None
                    if point is None
                    else to_package(point, source.fragment.placement)
                )
                continue
            except ValueError:
                if sizing.origin == "custom":
                    raise
        owned = [b.bounds for b in blocks if inputs[b.source].component_id == component]
        volumes = [math.prod(hi - lo for lo, hi in b) for b in owned]
        total = math.fsum(volumes)
        point = [
            math.fsum(v * (b[a][0] + b[a][1]) / 2 for b, v in zip(owned, volumes))
            / total
            for a in range(3)
        ]
        if sizing.origin != "center":
            local_axis = "xyz".index(sizing.origin[-1])
            rotation = _rotation_matrix(source.fragment.placement)
            axis = max(range(3), key=lambda a: abs(rotation[a][local_axis]))
            positive = sizing.origin.startswith("positive") == (
                rotation[axis][local_axis] > 0
            )
            end = 1 if positive else 0
            extreme = (max if positive else min)(b[axis][end] for b in owned)
            face_boxes = [b for b in owned if b[axis][end] == extreme]
            areas = [
                math.prod(b[a][1] - b[a][0] for a in range(3) if a != axis)
                for b in face_boxes
            ]
            point = [
                math.fsum(
                    v * (b[a][0] + b[a][1]) / 2 for b, v in zip(face_boxes, areas)
                )
                / math.fsum(areas)
                for a in range(3)
            ]
            point[axis] = extreme
        origins[component] = tuple(point)
    return origins


def plan_orthogonal_domain(
    inputs, *, locked_quads=(), contact_points=(), tolerance=1e-10
):
    inputs = tuple(inputs)
    locks = tuple(locked_quads)
    components = tuple(sorted({v.component_id for v in inputs}))
    from .package_v2_orthogonal_box_frame_materializer import (
        _require_axis_permutation,
        _rotation_matrix,
    )

    blocks = []
    for i, source in enumerate(inputs):
        try:
            _require_axis_permutation(source.fragment.placement)
        except ValueError as error:
            raise OrthogonalConstraintError(
                "orth_coordinate_frame_unsupported", str(error), components=components
            ) from error
        for bounds in root_boxes(source.fragment.root):
            pts = [to_package(p, source.fragment.placement) for p in corners(bounds)]
            blocks.append(
                OrthogonalBlock(
                    i,
                    tuple(
                        (min(p[a] for p in pts), max(p[a] for p in pts))
                        for a in range(3)
                    ),
                )
            )
    # Partial external patches have geometric perimeters. Split only touched blocks.
    for target, points in contact_points:
        if not points:
            continue
        points = tuple(key(p) for p in points)
        bounds = tuple(
            (min(p[a] for p in points), max(p[a] for p in points)) for a in range(3)
        )
        normal = next(
            (a for a in range(3) if bounds[a][1] - bounds[a][0] <= tolerance), None
        )
        if normal is None:
            continue
        updated = []
        for block in blocks:
            cuts = [set() for _ in range(3)]
            if inputs[block.source].fragment.fragment_id == target and any(
                abs(v - bounds[normal][0]) <= tolerance for v in block.bounds[normal]
            ):
                if all(
                    min(block.bounds[a][1], bounds[a][1])
                    > max(block.bounds[a][0], bounds[a][0]) + tolerance
                    for a in range(3)
                    if a != normal
                ):
                    for a in range(3):
                        if a != normal:
                            cuts[a].update(
                                v
                                for v in bounds[a]
                                if block.bounds[a][0] + tolerance
                                < v
                                < block.bounds[a][1] - tolerance
                            )
            updated.extend(_split(block, cuts))
        blocks = updated
    if not blocks:
        raise OrthogonalConstraintError(
            "orth_empty_geometry", "布尔筛选后没有正体积几何。", components=components
        )
    blocks = _conforming_blocks(blocks, tolerance)
    owners = {}
    for block in blocks:
        previous = owners.get(block.bounds)
        if previous is not None:
            same = (
                inputs[previous.source].component_id
                == inputs[block.source].component_id
            )
            reason = (
                "同 Component 的独立 Solid 存在正体积重叠；请用 Union 表达合法并集，避免重复单元和模糊的 Solid 归属。"
                if same
                else "不同 Component 存在正体积重叠，无法唯一分配材料。"
            )
            raise OrthogonalConstraintError(
                "orth_geometry_overlap",
                reason,
                components=components,
                bounds=block.bounds,
            )
        owners[block.bounds] = block
    blocks = tuple(sorted(blocks, key=lambda b: (b.bounds, b.source)))
    axes = _Union(3 * len(blocks))
    domains = _Union(len(blocks))
    neighbors = []
    for i, j in combinations(range(len(blocks)), 2):
        axis = face_axis(blocks[i].bounds, blocks[j].bounds, tolerance)
        if axis is None:
            if blocks[i].bounds == blocks[j].bounds:
                domains.join(i, j)
                for a in range(3):
                    axes.join(3 * i + a, 3 * j + a)
            continue
        domains.join(i, j)
        neighbors.append((i, j, axis))
        for a in range(3):
            if a != axis:
                axes.join(3 * i + a, 3 * j + a)
    inner = _inner_corners(blocks)
    groups = defaultdict(list)
    for i in range(len(blocks)):
        for a in range(3):
            groups[axes.find(3 * i + a)].append((i, a))
    locked = defaultdict(list)
    for quad in locks:
        normal, bounds = _quad_bounds(quad, components, tolerance)
        hit = False
        for i, block in enumerate(blocks):
            if inputs[block.source].fragment.fragment_id != quad.target_fragment_id:
                continue
            if not any(
                abs(v - bounds[normal][0]) <= tolerance for v in block.bounds[normal]
            ):
                continue
            if not all(
                min(block.bounds[a][1], bounds[a][1])
                > max(block.bounds[a][0], bounds[a][0]) + tolerance
                for a in range(3)
                if a != normal
            ):
                continue
            hit = True
            for a in range(3):
                if a == normal:
                    continue
                lo, hi = block.bounds[a]
                if any(
                    bounds[a][0] + tolerance < v < bounds[a][1] - tolerance
                    for v in (lo, hi)
                ):
                    raise OrthogonalConstraintError(
                        "orth_locked_quad_exit_conflict",
                        "几何出口或接触边界需要切开一个固定 QUAD，严格正交网格无法保持原接口。",
                        components=components,
                        sources=(quad.evidence(),),
                        axis=a,
                        bounds=block.bounds,
                        coordinates=(lo, hi),
                    )
                locked[axes.find(3 * i + a)].append((bounds[a][0], bounds[a][1], quad))
        if not hit:
            raise OrthogonalConstraintError(
                "orth_interface_outside_domain",
                "固定接口未落在目标 Orth 实体的边界上。",
                components=components,
                sources=(quad.evidence(),),
                bounds=bounds,
            )
    origins = _component_origins(inputs, blocks)
    levels = [[None] * 3 for _ in blocks]
    provenance = [[None] * 3 for _ in blocks]
    for group, members in sorted(groups.items()):
        i, a = min(
            members,
            key=lambda m: (
                inputs[blocks[m[0]].source].priority,
                blocks[m[0]].bounds,
                m[0],
            ),
        )
        source = inputs[blocks[i].source]
        lo, hi = blocks[i].bounds[a]
        constraints = locked[group]
        anchors = sorted({lo, hi, *(v for l, h, q in constraints for v in (l, h))})
        for l, h, q in constraints:
            conflicts = [v for v in anchors if l + tolerance < v < h - tolerance]
            if conflicts:
                raise OrthogonalConstraintError(
                    "orth_locked_interface_conflict",
                    "多个固定接口要求不同的切向 QUAD 分区，无法同时满足。",
                    components=components,
                    sources=tuple(v[2].evidence() for v in constraints),
                    axis=a,
                    bounds=blocks[i].bounds,
                    coordinates=tuple(conflicts),
                )
        rotation = _rotation_matrix(source.fragment.placement)
        local_axis = max(range(3), key=lambda j: abs(rotation[a][j]))
        sign = 1 if rotation[a][local_axis] > 0 else -1
        axis_name = "xyz"[local_axis]
        sizes = source.strategy.directional_near_edge_mm
        neg = sizes[
            ComponentLocalDirection(
                ("negative_" if sign > 0 else "positive_") + axis_name
            )
        ]
        pos = sizes[
            ComponentLocalDirection(
                ("positive_" if sign > 0 else "negative_") + axis_name
            )
        ]
        sizing = source.strategy.sizing
        origin_point = origins[source.component_id]
        origin = None if origin_point is None else origin_point[a]
        inner_ends = set()
        for bi, _ in members:
            b = blocks[bi]
            for point in inner:
                if all(
                    b.bounds[t][0] - tolerance <= point[t] <= b.bounds[t][1] + tolerance
                    for t in range(3)
                ):
                    for end in (lo, hi):
                        if abs(point[a] - end) <= tolerance:
                            inner_ends.add(end)
        values = [lo]
        for lower, upper in zip(anchors, anchors[1:]):
            left_size, right_size = orthogonal_corner_sizes(
                lower, upper, neg, pos, origin
            )
            if any(
                abs(lower - l) <= tolerance and abs(upper - h) <= tolerance
                for l, h, _ in constraints
            ):
                part = (lower, upper)
            elif lower in inner_ends and upper in inner_ends:
                part = orthogonal_meeting_levels(
                    lower, upper, left_size, right_size, sizing.remainder_ratio
                )
            elif lower in inner_ends:
                part = ray_levels(
                    lower, upper, left_size, replace(sizing, constraint="hard")
                )
            elif upper in inner_ends:
                part = tuple(
                    reversed(
                        ray_levels(
                            upper, lower, right_size, replace(sizing, constraint="hard")
                        )
                    )
                )
            else:
                part = interval_levels(
                    lower, upper, neg, pos, lower if origin is None else origin, sizing
                )
            values.extend(part[1:])
        values = tuple(round(v, 12) for v in values)
        if any(x >= y for x, y in zip(values, values[1:])):
            raise OrthogonalConstraintError(
                "orth_seed_resolution_failed",
                "布种产生非正长度区间。",
                components=components,
                axis=a,
            )
        for bi, axis in members:
            levels[bi][axis] = values
            provenance[bi][axis] = {
                "component_id": source.component_id,
                "priority": source.priority,
                "locked_interfaces": sorted(
                    {q.interface_id for _, _, q in constraints}
                ),
                "target_negative_mm": neg,
                "target_positive_mm": pos,
                "origin_package_mm": origin,
                "seed_coordinates_mm": values,
                "protected_coordinates_mm": tuple(anchors),
                "inner_corner_starts_mm": tuple(sorted(inner_ends)),
            }
    return OrthogonalDomainPlan(
        inputs,
        blocks,
        tuple(neighbors),
        tuple(tuple(v) for v in levels),
        tuple(domains.find(i) for i in range(len(blocks))),
        inner,
        locks,
        tuple(tuple(v) for v in provenance),
    )
