"""EasyMesh concentric-ring geometry and Gmsh prototype."""

from .axisymmetric import (
    AXISYMMETRIC_PARAMETERS_SCHEMA,
    AxisymmetricMeshParameters,
    IntervalSizeOverride,
    MeshParameterSet,
    load_mesh_parameters,
    load_parameters_json,
    mesh_parameters_from_dict,
    parameters_from_dict,
)
from .axisymmetric_builder import (
    AxisymmetricBuildSummary,
    AxisymmetricElementPlan,
    PlannedVolumeElement,
    build_axisymmetric_mesh,
    component_physical_name_map,
    plan_axisymmetric_elements,
)
from .bump_layout import (
    BumpInstance,
    BumpLayout,
    BumpMeshTemplate,
    LayoutBounds,
    StructuredHexRegion,
    load_bump_layout,
    parse_bump_layout_text,
)
from .layout_builder import (
    LayoutBuildSummary,
    LayoutMeshPlan,
    PlannedLayoutElement,
    build_layout_mesh,
    plan_layout_mesh,
)
from .parameters import MeshParameters, SymmetryMode
from .quality import (
    QUALITY_WARNING_THRESHOLD,
    QualityAssessment,
    QualityClassification,
    classify_mesh_quality,
)
from .mesh_controls import (
    ControlAxis,
    MeshControlInterval,
    build_section_control_intervals,
    effective_size,
    validate_size_override,
)
from .section import (
    AirGapSpan,
    LayerDefinition,
    LayerMode,
    SectionPlan,
    WaterReference,
    build_section_plan,
    load_layer_file,
    parse_layer_text,
)

__all__ = [
    "AXISYMMETRIC_PARAMETERS_SCHEMA",
    "AirGapSpan",
    "AxisymmetricMeshParameters",
    "AxisymmetricBuildSummary",
    "AxisymmetricElementPlan",
    "BumpInstance",
    "BumpLayout",
    "BumpMeshTemplate",
    "IntervalSizeOverride",
    "LayerDefinition",
    "LayerMode",
    "WaterReference",
    "LayoutBounds",
    "LayoutBuildSummary",
    "LayoutMeshPlan",
    "ControlAxis",
    "MeshParameterSet",
    "MeshParameters",
    "QUALITY_WARNING_THRESHOLD",
    "QualityAssessment",
    "QualityClassification",
    "SymmetryMode",
    "StructuredHexRegion",
    "MeshControlInterval",
    "SectionPlan",
    "PlannedVolumeElement",
    "PlannedLayoutElement",
    "build_axisymmetric_mesh",
    "component_physical_name_map",
    "build_layout_mesh",
    "classify_mesh_quality",
    "build_section_control_intervals",
    "build_section_plan",
    "effective_size",
    "load_mesh_parameters",
    "load_parameters_json",
    "load_layer_file",
    "load_bump_layout",
    "mesh_parameters_from_dict",
    "parameters_from_dict",
    "parse_layer_text",
    "parse_bump_layout_text",
    "plan_layout_mesh",
    "plan_axisymmetric_elements",
    "validate_size_override",
]
__version__ = "0.2.0"
