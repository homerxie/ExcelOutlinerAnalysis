"""Component-local seed schedules; inherited topology always takes precedence."""
from __future__ import annotations

from dataclasses import dataclass
import math


ORIGIN_LABELS = {
    "legacy": "自动",
    "center": "几何中心",
    "positive_x": "+X 面中心", "negative_x": "−X 面中心",
    "positive_y": "+Y 面中心", "negative_y": "−Y 面中心",
    "positive_z": "+Z 面中心", "negative_z": "−Z 面中心",
    "custom": "自定义坐标",
}


@dataclass(frozen=True, slots=True)
class MeshSeedPolicy:
    constraint: str = "soft"
    remainder_ratio: float = 0.25
    origin: str = "legacy"

    def __post_init__(self):
        if self.constraint not in {"soft", "hard"}:
            raise ValueError("constraint must be soft or hard")
        if (isinstance(self.remainder_ratio, bool)
            or not isinstance(self.remainder_ratio, (int, float))
            or not math.isfinite(self.remainder_ratio)
            or not 0 < self.remainder_ratio <= 1):
            raise ValueError("remainder_ratio must be in (0, 1]")
        if self.origin not in ORIGIN_LABELS:
            raise ValueError("unknown seed origin")

    def to_dict(self):
        return {"constraint": self.constraint, "remainder_ratio": self.remainder_ratio,
                "origin": self.origin}


def ray_levels(start, end, size, policy=MeshSeedPolicy()):
    """March to a boundary, modifying only the terminal cell in hard mode."""
    if not math.isfinite(size) or size <= 0:
        raise ValueError("seed size must be finite and positive")
    distance = abs(end - start)
    if distance == 0:
        return (start,)
    ratio = distance / size
    nearest = round(ratio)
    whole = nearest > 0 and math.isclose(ratio, nearest, rel_tol=1.e-12, abs_tol=1.e-12)
    if policy.constraint == "soft":
        count = max(1, nearest if whole else math.ceil(ratio))
        return tuple(start + (end-start)*i/count for i in range(count)) + (end,)
    count = nearest if whole else math.floor(ratio)
    sign = 1 if end > start else -1
    levels = [start + sign*size*i for i in range(count+1)]
    if whole:
        levels[-1] = end
    elif count and ratio-count < policy.remainder_ratio - 1.e-12:
        levels[-1] = end
    else:
        levels.append(end)
    return tuple(levels)


def interval_levels(lower, upper, negative_size, positive_size, origin, policy):
    """An origin outside an interval projects onto its nearest endpoint."""
    anchor = min(upper, max(lower, origin))
    left = tuple(reversed(ray_levels(anchor, lower, negative_size, policy)))
    right = ray_levels(anchor, upper, positive_size, policy)
    return left[:-1] + right


def meeting_levels(lower, upper, left_size, right_size, origin, policy):
    """Two fronts arriving around a visible hole meet without pinning its center.

    Only the collision cell may be shortened/merged. All shared edges consume
    this same schedule, so the front cannot introduce hanging nodes at corners.
    """
    if policy.constraint == "soft":
        return interval_levels(lower, upper, right_size, left_size, origin, policy)
    anchor = min(upper, max(lower, origin))
    nl = max(0, math.floor((anchor-lower)/left_size + 1.e-12))
    nr = max(0, math.floor((upper-anchor)/right_size + 1.e-12))
    left = [lower+i*left_size for i in range(nl+1)]
    right = [upper-i*right_size for i in range(nr+1)]
    tol = max(upper-lower, left_size, right_size)*1.e-12
    while right[-1]-left[-1] > left_size+tol:
        left.append(left[-1]+left_size)
    gap = right[-1]-left[-1]
    if gap <= tol:
        return tuple(left[:-1] + list(reversed(right)))
    if gap < policy.remainder_ratio*min(left_size, right_size)-tol:
        if len(left) > 1:
            left.pop()
        elif len(right) > 1:
            right.pop()
    return tuple(left + list(reversed(right)))


def geometry_origin(root, policy, custom=None):
    """Resolve geometry/face centroids in the Component-local frame."""
    from .package_v2_geometry import (
        CanonicalBox,
        CanonicalRectangularFrameExtrusion,
        CanonicalRectangularUnderfillFillet,
        CanonicalUnion,
        CanonicalDifference,
    )

    if custom is not None and policy.origin in {"legacy", "custom"}:
        return tuple(custom)
    if policy.origin == "custom":
        raise ValueError("custom origin requires three coordinates")
    if policy.origin == "legacy":
        return None
    if type(root) is CanonicalBox:
        lo = root.origin_xyz_mm
        hi = tuple(a+b for a,b in zip(lo, root.size_xyz_mm))
        center = tuple((a+b)/2 for a,b in zip(lo, hi))
    elif type(root) is CanonicalRectangularFrameExtrusion:
        lo = root.outer_origin_xyz_mm
        sx, sy = root.outer_size_xy_mm
        ix, iy = root.opening_size_xy_mm
        ox, oy = root.opening_offset_xy_mm
        hi = (lo[0]+sx, lo[1]+sy, lo[2]+root.height_mm)
        area, hole = sx*sy, ix*iy
        center = (lo[0]+(area*sx/2-hole*(ox+ix/2))/(area-hole),
                  lo[1]+(area*sy/2-hole*(oy+iy/2))/(area-hole), (lo[2]+hi[2])/2)
    elif type(root) is CanonicalRectangularUnderfillFillet:
        x,y = root.die_origin_xy_mm
        sx,sy = root.die_size_xy_mm
        w,d = root.toe_width_mm, root.top_width_mm-root.toe_width_mm
        a = 2*(sx+sy)*w + math.pi*w*w
        b = 2*(sx+sy)*d + 2*math.pi*w*d
        c = math.pi*d*d
        fraction = (a/2+b/3+c/4)/(a+b/2+c/3)
        center = (x+sx/2, y+sy/2, root.base_z_mm+root.wall_height_mm*fraction)
        lo = (x-w, y-w, root.base_z_mm)
        hi = (x+sx+w, y+sy+w, root.base_z_mm+root.wall_height_mm)
    elif type(root) in {CanonicalUnion, CanonicalDifference}:
        from .package_v2_orthogonal_domain_planning import root_boxes

        boxes = root_boxes(root)
        if not boxes:
            raise ValueError("empty rectilinear geometry has no seed origin")
        volumes = [math.prod(b - a for a, b in box) for box in boxes]
        lo = tuple(min(b[a][0] for b in boxes) for a in range(3))
        hi = tuple(max(b[a][1] for b in boxes) for a in range(3))
        center = tuple(
            math.fsum(v * (b[a][0] + b[a][1]) / 2 for b, v in zip(boxes, volumes))
            / math.fsum(volumes)
            for a in range(3)
        )
    else:
        raise ValueError("unsupported geometry for seed origin")
    if policy.origin == "center":
        return center
    axis = "xyz".index(policy.origin[-1])
    result = list(center)
    if type(root) is CanonicalRectangularFrameExtrusion and axis != 2:
        # Outer side faces are solid rectangles even for an eccentric opening.
        result = [(a+b)/2 for a,b in zip(lo, hi)]
    if type(root) is CanonicalRectangularUnderfillFillet and axis != 2:
        # Centroid of the straight sloping outer side (the rounded corner
        # patches do not have a single signed-axis surface normal).
        offset = (root.toe_width_mm + root.top_width_mm)/2
        result[2] = root.base_z_mm + root.wall_height_mm/2
        result[axis] = (root.die_origin_xy_mm[axis] + root.die_size_xy_mm[axis] + offset
                        if policy.origin.startswith("positive") else root.die_origin_xy_mm[axis] - offset)
        return tuple(result)
    result[axis] = hi[axis] if policy.origin.startswith("positive") else lo[axis]
    return tuple(result)
