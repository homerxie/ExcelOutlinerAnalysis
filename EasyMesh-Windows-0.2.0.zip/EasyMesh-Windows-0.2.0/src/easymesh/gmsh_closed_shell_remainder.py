"""Gmsh-owned filling of a locked, closed TRI/QUAD shell.

Geometry/surface executors provide a complete closed boundary and identify any
locked docking facets.  EasyMesh installs that immutable surface mesh and asks
Gmsh to create every three-dimensional element inside the shell.  The helper
is shared by the conformal-hybrid strategy and structured Gmsh adapters; it
does not inherit or copy volume elements from a neighboring component.

No package role, material, selected component name or underfill vocabulary is
accepted here.  In particular, this module never manufactures a TET, PYRAMID
or WEDGE connection.  Gmsh's discrete-volume mesher consumes locked TRI3 and
QUAD4 facets directly; QUAD-to-TET transitions therefore appear as native
PYRAMID5/WEDGE6 elements when required.
"""

from __future__ import annotations

import uuid
from .gmsh_candidate_runtime import candidate_event_context, emit_candidate_event
from .package_v2_quality_history import emit_quality_snapshot

from collections import Counter, defaultdict, deque
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from statistics import median
from types import MappingProxyType
from typing import Any, TypeAlias

from .gmsh_runtime import isolated_gmsh_model
from .occ_locked_hybrid import ConstrainedHybridError, _finite, _load_gmsh
from .volume_mesh import ELEMENT_SPECS


Point3D: TypeAlias = tuple[float, float, float]
FaceKey: TypeAlias = tuple[int, ...]

_TRI3 = 2
_QUAD4 = 3
_TET4 = 4
_WEDGE6 = 6
_PYRAMID5 = 7
_HEX8 = 5
# Native conformal closed-shell generation is intentionally limited to the
# hybrid families below.  A proved selected backend may still package HEX8 in
# the public remainder DTO for the common preservation assembler.
_VOLUME_TYPES = frozenset({_TET4, _WEDGE6, _PYRAMID5})
_ASSEMBLY_VOLUME_TYPES = frozenset((*_VOLUME_TYPES, _HEX8))
_COORDINATE_TOLERANCE = 1.0e-10


@dataclass(frozen=True, slots=True)
class GmshClosedShellElement:
    gmsh_type: int
    node_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        expected = ELEMENT_SPECS.get(self.gmsh_type, (None, 0, ()))[1]
        if (
            self.gmsh_type not in _ASSEMBLY_VOLUME_TYPES
            or len(self.node_ids) != expected
        ):
            raise ConstrainedHybridError(
                "closed-shell remainder element must be TET4, HEX8, WEDGE6 "
                "or PYRAMID5"
            )
        if len(set(self.node_ids)) != expected:
            raise ConstrainedHybridError(
                "closed-shell remainder element repeats a node"
            )


@dataclass(frozen=True, slots=True)
class GmshClosedShellRemainder:
    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    elements: tuple[GmshClosedShellElement, ...]
    boundary_facets: tuple[tuple[int, ...], ...]
    docking_facets: tuple[tuple[int, ...], ...]
    tet4_count: int
    hex8_count: int
    wedge6_count: int
    pyramid5_count: int
    locked_triangle_count: int
    locked_quad_count: int
    target_size_mm: float
    near_size_mm: float
    transition_distance_mm: float
    background_field_kind: str
    minimum_sicn: float
    minimum_sige: float
    minimum_scaled_jacobian: float
    minimum_determinant: float
    duplicate_node_count: int
    duplicate_element_count: int
    shell_volume_mm3: float
    element_volume_mm3: float
    relative_volume_error: float
    random_seed: int
    pyramid_untangler_used: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "node_coordinates", MappingProxyType(dict(self.node_coordinates))
        )
        object.__setattr__(
            self,
            "source_node_id_by_local_id",
            MappingProxyType(dict(self.source_node_id_by_local_id)),
        )

    @property
    def node_count(self) -> int:
        return len(self.node_coordinates)

    @property
    def element_count(self) -> int:
        return len(self.elements)


@dataclass(frozen=True, slots=True)
class _PreparedShell:
    coordinates: Mapping[int, Point3D]
    facets: tuple[tuple[int, ...], ...]
    docking_keys: frozenset[FaceKey]
    shell_volume: float


@dataclass(frozen=True, slots=True)
class _Candidate:
    coordinates: Mapping[int, Point3D]
    elements: tuple[tuple[int, int, tuple[int, ...]], ...]
    boundary_facets: tuple[tuple[int, ...], ...]
    determinants: tuple[float, ...]
    sicn: tuple[float, ...]
    sige: tuple[float, ...]
    scaled_jacobian: tuple[float, ...]
    duplicate_node_count: int
    seed: int
    field_kind: str
    pyramid_untangler_used: bool


def _coordinate_key(point: Sequence[float]) -> tuple[float, float, float]:
    return tuple(round(float(value), 12) for value in point)  # type: ignore[return-value]


def _face_key(facet: Sequence[int]) -> FaceKey:
    return tuple(sorted(int(value) for value in facet))


def _edge_key(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def _directed_edges(facet: Sequence[int]) -> tuple[tuple[int, int], ...]:
    values = tuple(facet)
    return tuple(zip(values, (*values[1:], values[0])))


def _reverse(facet: Sequence[int]) -> tuple[int, ...]:
    values = tuple(facet)
    return (values[0], *reversed(values[1:]))


def _signed_tetra_volume(
    first: Point3D,
    second: Point3D,
    third: Point3D,
) -> float:
    return (
        first[0] * (second[1] * third[2] - second[2] * third[1])
        - first[1] * (second[0] * third[2] - second[2] * third[0])
        + first[2] * (second[0] * third[1] - second[1] * third[0])
    ) / 6.0


def _surface_signed_volume(
    facets: Sequence[Sequence[int]],
    coordinates: Mapping[int, Point3D],
) -> float:
    total = 0.0
    for facet in facets:
        first = coordinates[facet[0]]
        for index in range(1, len(facet) - 1):
            total += _signed_tetra_volume(
                first,
                coordinates[facet[index]],
                coordinates[facet[index + 1]],
            )
    return total


def _orient_closed_shell(
    facets: Sequence[tuple[int, ...]],
    coordinates: Mapping[int, Point3D],
) -> tuple[tuple[tuple[int, ...], ...], float]:
    edge_owners: dict[tuple[int, int], list[tuple[int, int, int]]] = defaultdict(list)
    for index, facet in enumerate(facets):
        for first, second in _directed_edges(facet):
            edge_owners[_edge_key(first, second)].append((index, first, second))
    if any(len(owners) != 2 for owners in edge_owners.values()):
        counts = Counter(len(owners) for owners in edge_owners.values())
        raise ConstrainedHybridError(
            "closed-shell remainder boundary is not a two-manifold: "
            f"edge_owner_counts={dict(sorted(counts.items()))!r}"
        )

    adjacency: dict[int, list[tuple[int, bool]]] = defaultdict(list)
    for owners in edge_owners.values():
        (first_index, first_a, first_b), (
            second_index,
            second_a,
            second_b,
        ) = owners
        same_direction = first_a == second_a and first_b == second_b
        adjacency[first_index].append((second_index, same_direction))
        adjacency[second_index].append((first_index, same_direction))

    flip: dict[int, bool] = {0: False}
    queue = deque((0,))
    while queue:
        current = queue.popleft()
        for neighbor, same_direction in adjacency[current]:
            expected = flip[current] ^ same_direction
            previous = flip.get(neighbor)
            if previous is None:
                flip[neighbor] = expected
                queue.append(neighbor)
            elif previous != expected:
                raise ConstrainedHybridError(
                    "closed-shell remainder boundary is not orientable"
                )
    if len(flip) != len(facets):
        raise ConstrainedHybridError(
            "closed-shell remainder boundary must have one connected component"
        )
    oriented = tuple(
        _reverse(facet) if flip[index] else facet
        for index, facet in enumerate(facets)
    )
    signed_volume = _surface_signed_volume(oriented, coordinates)
    if not math.isfinite(signed_volume) or abs(signed_volume) <= 1.0e-18:
        raise ConstrainedHybridError(
            "closed-shell remainder boundary has zero signed volume"
        )
    if signed_volume < 0.0:
        oriented = tuple(_reverse(facet) for facet in oriented)
        signed_volume = -signed_volume
    return oriented, signed_volume


def _prepare_shell(
    node_coordinates: Mapping[int, Sequence[float]],
    boundary_facets: Sequence[Sequence[int]],
    docking_facets: Sequence[Sequence[int]],
) -> _PreparedShell:
    if not isinstance(node_coordinates, Mapping):
        raise ConstrainedHybridError("closed-shell coordinates must be a mapping")
    coordinates: dict[int, Point3D] = {}
    for raw_id, raw_point in node_coordinates.items():
        if isinstance(raw_id, bool) or not isinstance(raw_id, int) or raw_id < 1:
            raise ConstrainedHybridError(
                "closed-shell source node IDs must be positive integers"
            )
        try:
            values = tuple(raw_point)
        except TypeError as error:
            raise ConstrainedHybridError(
                "closed-shell source node coordinate must be a sequence"
            ) from error
        if len(values) != 3:
            raise ConstrainedHybridError(
                "closed-shell source node coordinate must contain x,y,z"
            )
        coordinates[raw_id] = tuple(
            _finite(value, name=f"closed-shell source node {raw_id}")
            for value in values
        )  # type: ignore[assignment]
    if len({_coordinate_key(value) for value in coordinates.values()}) != len(
        coordinates
    ):
        raise ConstrainedHybridError(
            "closed-shell source coordinates contain coincident nodes"
        )
    try:
        raw_facets = tuple(tuple(value) for value in boundary_facets)
        raw_docking = tuple(tuple(value) for value in docking_facets)
    except TypeError as error:
        raise ConstrainedHybridError(
            "closed-shell facets must be TRI3/QUAD4 sequences"
        ) from error
    if not raw_facets:
        raise ConstrainedHybridError("closed-shell boundary cannot be empty")
    facets: list[tuple[int, ...]] = []
    keys: set[FaceKey] = set()
    referenced: set[int] = set()
    for raw_facet in raw_facets:
        if len(raw_facet) not in (3, 4) or any(
            isinstance(node, bool) or not isinstance(node, int)
            for node in raw_facet
        ):
            raise ConstrainedHybridError(
                "closed-shell boundary facets must be TRI3/QUAD4"
            )
        facet = tuple(int(node) for node in raw_facet)
        if len(set(facet)) != len(facet) or any(
            node not in coordinates for node in facet
        ):
            raise ConstrainedHybridError("closed-shell boundary facet is invalid")
        key = _face_key(facet)
        if key in keys:
            raise ConstrainedHybridError(
                "closed-shell boundary facets must be unique"
            )
        keys.add(key)
        referenced.update(facet)
        facets.append(facet)
    if referenced != set(coordinates):
        raise ConstrainedHybridError(
            "every closed-shell source node must appear on the boundary"
        )
    docking_keys: set[FaceKey] = set()
    for facet in raw_docking:
        key = _face_key(facet)
        if len(facet) not in (3, 4) or key not in keys:
            raise ConstrainedHybridError(
                "each docking facet must be an exact closed-shell boundary facet"
            )
        if key in docking_keys:
            raise ConstrainedHybridError("docking facets must be unique")
        docking_keys.add(key)
    oriented, volume = _orient_closed_shell(facets, coordinates)
    return _PreparedShell(
        MappingProxyType(coordinates),
        oriented,
        frozenset(docking_keys),
        volume,
    )


def _all_nodes(gmsh: Any) -> dict[int, Point3D]:
    tags, raw_coordinates, _parameters = gmsh.model.mesh.getNodes(
        -1, -1, includeBoundary=True, returnParametricCoord=False
    )
    coordinates = tuple(float(value) for value in raw_coordinates)
    return {
        int(tag): tuple(coordinates[3 * index : 3 * index + 3])  # type: ignore[misc]
        for index, tag in enumerate(tags)
    }


def _candidate(
    gmsh: Any,
    surface_tags: Sequence[int],
    volume_tag: int,
    *,
    seed: int,
    field_kind: str,
    pyramid_untangler_used: bool,
) -> _Candidate:
    coordinates = MappingProxyType(_all_nodes(gmsh))
    raw_types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
        3, volume_tag
    )
    elements: list[tuple[int, int, tuple[int, ...]]] = []
    quality_tags: list[int] = []
    for raw_type, raw_tags, raw_connectivity in zip(
        raw_types, tag_blocks, connectivity_blocks
    ):
        gmsh_type = int(raw_type)
        if gmsh_type not in _VOLUME_TYPES:
            raise ConstrainedHybridError(
                f"Gmsh closed-shell remainder emitted unsupported type {gmsh_type}"
            )
        node_count = ELEMENT_SPECS[gmsh_type][1]
        connectivity = tuple(int(value) for value in raw_connectivity)
        if len(connectivity) != node_count * len(raw_tags):
            raise ConstrainedHybridError(
                "Gmsh closed-shell remainder connectivity is inconsistent"
            )
        for index, raw_tag in enumerate(raw_tags):
            start = index * node_count
            elements.append(
                (
                    gmsh_type,
                    int(raw_tag),
                    connectivity[start : start + node_count],
                )
            )
            quality_tags.append(int(raw_tag))
    if not elements:
        raise ConstrainedHybridError("Gmsh produced an empty closed-shell remainder")
    boundary: list[tuple[int, ...]] = []
    for surface_tag in surface_tags:
        surface_types, _surface_tags, surface_connectivity = (
            gmsh.model.mesh.getElements(2, surface_tag)
        )
        for raw_type, raw_connectivity in zip(
            surface_types, surface_connectivity
        ):
            gmsh_type = int(raw_type)
            if gmsh_type not in (_TRI3, _QUAD4):
                raise ConstrainedHybridError(
                    "Gmsh changed the closed-shell boundary element family"
                )
            node_count = 3 if gmsh_type == _TRI3 else 4
            values = tuple(int(value) for value in raw_connectivity)
            boundary.extend(
                values[index : index + node_count]
                for index in range(0, len(values), node_count)
            )
    metrics = {
        name: tuple(
            float(value)
            for value in gmsh.model.mesh.getElementQualities(quality_tags, name)
        )
        for name in ("minDetJac", "minSICN", "minSIGE", "minSJ")
    }
    if any(len(values) != len(elements) for values in metrics.values()):
        raise ConstrainedHybridError(
            "Gmsh returned inconsistent closed-shell quality arrays"
        )
    return _Candidate(
        coordinates,
        tuple(elements),
        tuple(boundary),
        metrics["minDetJac"],
        metrics["minSICN"],
        metrics["minSIGE"],
        metrics["minSJ"],
        len(tuple(gmsh.model.mesh.getDuplicateNodes())),
        seed,
        field_kind,
        pyramid_untangler_used,
    )


def _candidate_is_structurally_safe_for_optimization(
    candidate: _Candidate,
    prepared: _PreparedShell,
) -> bool:
    """Return whether a raw Gmsh candidate may enter topology optimization.

    Gmsh's default optimizer is useful for a valid low-quality candidate, but
    it is not an untangler for an already invalid PLC fill.  In particular,
    feeding it duplicate nodes, inverted cells or a non-conservative volume
    can enter native edge-cavity/Winslow failure paths before Python regains
    control.  This gate depends only on the candidate and immutable shell; it
    does not inspect a Component role or selected topology.
    """

    if candidate.duplicate_node_count or any(
        not math.isfinite(value) or value <= 0.0
        for value in candidate.determinants
    ):
        return False
    if len(candidate.elements) != len(
        {
            (gmsh_type, tuple(sorted(nodes)))
            for gmsh_type, _tag, nodes in candidate.elements
        }
    ):
        return False
    if _folded_internal_face_count(candidate.elements, candidate.coordinates):
        return False

    expected_boundary = {
        tuple(
            sorted(_coordinate_key(prepared.coordinates[node]) for node in facet)
        )
        for facet in prepared.facets
    }
    actual_boundary = {
        tuple(
            sorted(_coordinate_key(candidate.coordinates[node]) for node in facet)
        )
        for facet in candidate.boundary_facets
    }
    if actual_boundary != expected_boundary:
        return False

    element_volume = math.fsum(
        _element_volume(gmsh_type, nodes, candidate.coordinates)
        for gmsh_type, _tag, nodes in candidate.elements
    )
    relative_error = abs(element_volume - prepared.shell_volume) / (
        prepared.shell_volume
    )
    return math.isfinite(relative_error) and relative_error <= 1.0e-8


def _install_surface_entities(
    gmsh: Any,
    prepared: _PreparedShell,
) -> tuple[tuple[int, ...], int | None]:
    """Install docking and non-docking facets as exact discrete surfaces.

    A single closed-shell surface makes Gmsh's Distance field treat every
    exterior face as a near-size source.  Splitting only the entity
    classification lets the field reference the immutable docking patch while
    leaving all source nodes, facets and generated volume connectivity intact.
    """

    docking_facets = tuple(
        facet
        for facet in prepared.facets
        if _face_key(facet) in prepared.docking_keys
    )
    other_facets = tuple(
        facet
        for facet in prepared.facets
        if _face_key(facet) not in prepared.docking_keys
    )
    groups = tuple(
        facets for facets in (docking_facets, other_facets) if facets
    )
    surface_tags = tuple(
        int(gmsh.model.addDiscreteEntity(2)) for _facets in groups
    )
    docking_surface_tag = surface_tags[0] if docking_facets else None

    docking_nodes = {node for facet in docking_facets for node in facet}
    unclassified_nodes = set(prepared.coordinates)
    next_element = 1
    for group_index, (surface_tag, facets) in enumerate(
        zip(surface_tags, groups)
    ):
        if docking_facets and group_index == 0:
            owned_nodes = tuple(sorted(docking_nodes))
        else:
            owned_nodes = tuple(sorted(unclassified_nodes))
        if owned_nodes:
            gmsh.model.mesh.addNodes(
                2,
                surface_tag,
                list(owned_nodes),
                [
                    coordinate
                    for source_id in owned_nodes
                    for coordinate in prepared.coordinates[source_id]
                ],
            )
            unclassified_nodes.difference_update(owned_nodes)
        for node_count, gmsh_type in ((3, _TRI3), (4, _QUAD4)):
            typed_facets = tuple(
                facet for facet in facets if len(facet) == node_count
            )
            if not typed_facets:
                continue
            tags = list(
                range(next_element, next_element + len(typed_facets))
            )
            next_element += len(typed_facets)
            gmsh.model.mesh.addElementsByType(
                surface_tag,
                gmsh_type,
                tags,
                [node for facet in typed_facets for node in facet],
            )
    if unclassified_nodes:  # pragma: no cover - guarded by _prepare_shell
        raise ConstrainedHybridError(
            "closed-shell surface installation left unclassified nodes"
        )
    return surface_tags, docking_surface_tag


def _mesh_candidate(
    prepared: _PreparedShell,
    *,
    target_size: float,
    near_size: float,
    transition_distance: float,
    seed: int,
    optimization_rounds: int,
    verbose: bool,
    pyramid_untangler: bool = False,
) -> _Candidate:
    gmsh = _load_gmsh()
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "General.NumThreads": 1.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm3D": 1.0,
        "Mesh.MeshOnlyEmpty": 1.0,
        "Mesh.MeshSizeMin": near_size,
        "Mesh.MeshSizeMax": target_size,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
        # Generation and optimization are separate audited stages.  Enabling
        # Gmsh's implicit optimizer here invokes its unconstrained edge-swap
        # path before EasyMesh can inspect the raw locked-shell candidate; on
        # large QUAD/TET/PYRAMID interfaces that path can delete cavity tets or
        # terminate in the native Winslow untangler.  Keep generation raw and
        # allow only the explicit relocation pass below.
        "Mesh.Optimize": 0.0,
        # Mode 0 is Gmsh's pyramid smoother; mode 1 is its hybrid-mesh
        # untangler.  The untangler is never the ordinary generation path: it
        # is selected only by the public driver after a raw, positive-element
        # rectangular-box candidate has proved a pyramid-recovery fold.
        "Mesh.OptimizePyramids": 1.0 if pyramid_untangler else 0.0,
        "Mesh.RandomSeed": float(seed),
        "Mesh.MaxNumThreads1D": 1.0,
        "Mesh.MaxNumThreads2D": 1.0,
        "Mesh.MaxNumThreads3D": 1.0,
    }
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_closed_shell_remainder",
        number_options=options,
    ):
        surface_tags, docking_surface_tag = _install_surface_entities(
            gmsh, prepared
        )
        volume_tag = int(
            gmsh.model.addDiscreteEntity(3, boundary=list(surface_tags))
        )
        gmsh.model.mesh.createGeometry([(3, volume_tag)])
        if near_size < target_size:
            distance = int(gmsh.model.mesh.field.add("Distance"))
            gmsh.model.mesh.field.setNumbers(
                distance,
                "SurfacesList",
                (
                    [docking_surface_tag]
                    if docking_surface_tag is not None
                    else list(surface_tags)
                ),
            )
            threshold = int(gmsh.model.mesh.field.add("Threshold"))
            for name, value in (
                ("InField", distance),
                ("SizeMin", near_size),
                ("SizeMax", target_size),
                ("DistMin", 0.0),
                ("DistMax", transition_distance),
            ):
                gmsh.model.mesh.field.setNumber(threshold, name, value)
            gmsh.model.mesh.field.setAsBackgroundMesh(threshold)
            field_kind = "Distance+Threshold"
        else:
            constant = int(gmsh.model.mesh.field.add("MathEval"))
            gmsh.model.mesh.field.setString(constant, "F", f"{target_size:.17g}")
            gmsh.model.mesh.field.setAsBackgroundMesh(constant)
            field_kind = "MathEvalConstant"
        try:
            gmsh.model.mesh.generate(3)
        except Exception as error:
            try:
                last_node_tags = tuple(
                    int(value) for value in gmsh.model.mesh.getLastNodeError()
                )
            except Exception:  # pragma: no cover - older Gmsh diagnostic API
                last_node_tags = ()
            try:
                last_entities = tuple(
                    (int(dimension), int(tag))
                    for dimension, tag in gmsh.model.mesh.getLastEntityError()
                )
            except Exception:  # pragma: no cover - older Gmsh diagnostic API
                last_entities = ()
            diagnostic = str(error).strip() or type(error).__name__
            raise ConstrainedHybridError(
                "Gmsh could not fill the locked closed-shell remainder: "
                f"{diagnostic}; last_node_tags={last_node_tags!r}; "
                f"last_entities={last_entities!r}"
            ) from error
        candidate = _candidate(
            gmsh,
            surface_tags,
            volume_tag,
            seed=seed,
            field_kind=field_kind,
            pyramid_untangler_used=pyramid_untangler,
        )
        emit_quality_snapshot(candidate, 0, phase="生成后")
        if not _candidate_is_structurally_safe_for_optimization(
            candidate,
            prepared,
        ):
            return candidate
        for _iteration in range(optimization_rounds):
            gmsh.model.mesh.optimize(
                "Relocate3D", force=True, niter=3, dimTags=[(3, volume_tag)]
            )
            candidate = _candidate(
                gmsh,
                surface_tags,
                volume_tag,
                seed=seed,
                field_kind=field_kind,
                pyramid_untangler_used=pyramid_untangler,
            )
            if not _candidate_is_structurally_safe_for_optimization(
                candidate,
                prepared,
            ):
                emit_quality_snapshot(candidate, _iteration + 1, phase="优化中止（Relocate3D 后）")
                return candidate
            gmsh.model.mesh.optimize(
                "", force=True, niter=30, dimTags=[(3, volume_tag)]
            )
            candidate = _candidate(
                gmsh,
                surface_tags,
                volume_tag,
                seed=seed,
                field_kind=field_kind,
                pyramid_untangler_used=pyramid_untangler,
            )
            emit_quality_snapshot(candidate, _iteration + 1)
            if not _candidate_is_structurally_safe_for_optimization(
                candidate,
                prepared,
            ):
                return candidate
        return candidate


def _tetra_volume(
    first: Point3D,
    second: Point3D,
    third: Point3D,
    fourth: Point3D,
) -> float:
    ab = tuple(second[index] - first[index] for index in range(3))
    ac = tuple(third[index] - first[index] for index in range(3))
    ad = tuple(fourth[index] - first[index] for index in range(3))
    cross = (
        ac[1] * ad[2] - ac[2] * ad[1],
        ac[2] * ad[0] - ac[0] * ad[2],
        ac[0] * ad[1] - ac[1] * ad[0],
    )
    return abs(math.fsum(ab[index] * cross[index] for index in range(3))) / 6.0


def _element_volume(
    gmsh_type: int,
    nodes: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> float:
    points = tuple(coordinates[node] for node in nodes)
    if gmsh_type == _TET4:
        return _tetra_volume(*points)  # type: ignore[arg-type]
    if gmsh_type == _PYRAMID5:
        return _tetra_volume(points[0], points[1], points[2], points[4]) + (
            _tetra_volume(points[0], points[2], points[3], points[4])
        )
    return math.fsum(
        (
            _tetra_volume(points[0], points[1], points[2], points[3]),
            _tetra_volume(points[1], points[2], points[4], points[3]),
            _tetra_volume(points[2], points[4], points[5], points[3]),
        )
    )


def _folded_internal_face_count(
    elements: Sequence[tuple[int, int, tuple[int, ...]]],
    coordinates: Mapping[int, Point3D],
) -> int:
    """Count topological neighbors embedded on the same side of their face.

    Face-owner counts alone prove only that the numbered cells form a
    topological two-complex.  They do not prove that its embedding is a
    non-overlapping volume: Gmsh can very rarely return a positive-Jacobian
    tetrahedron whose four neighbors all lie on the same geometric side of
    their shared faces.  In that case summing positive element volumes counts
    the folded tetrahedron twice even though the exterior shell is unchanged.

    This check is intentionally independent of the analytic CAD volume.  It
    compares only Gmsh's numbered volume cells with their own shared planar
    faces, so a curved CAD approximation cannot make it pass or fail.
    """

    owners: dict[FaceKey, list[Point3D]] = defaultdict(list)
    scale = max(
        1.0,
        *(
            abs(value)
            for point in coordinates.values()
            for value in point
        ),
    )
    normal_tolerance = 1.0e-14 * scale * scale
    side_tolerance = 1.0e-14 * scale * scale * scale
    for gmsh_type, _tag, nodes in elements:
        centroid = tuple(
            math.fsum(coordinates[node][axis] for node in nodes) / len(nodes)
            for axis in range(3)
        )
        for local_face in ELEMENT_SPECS[gmsh_type][2]:
            face = tuple(nodes[index] for index in local_face)
            owners[_face_key(face)].append(centroid)  # type: ignore[arg-type]

    folded = 0
    for face_key, centroids in owners.items():
        if len(centroids) != 2:
            continue
        points = tuple(coordinates[node] for node in face_key)
        first = tuple(points[1][axis] - points[0][axis] for axis in range(3))
        second = tuple(points[2][axis] - points[0][axis] for axis in range(3))
        normal = (
            first[1] * second[2] - first[2] * second[1],
            first[2] * second[0] - first[0] * second[2],
            first[0] * second[1] - first[1] * second[0],
        )
        normal_norm = math.sqrt(math.fsum(value * value for value in normal))
        if normal_norm <= normal_tolerance:
            # A collapsed face is independently rejected by the Jacobian and
            # quality audits; do not turn roundoff on that face into a fold.
            continue
        face_centroid = tuple(
            math.fsum(point[axis] for point in points) / len(points)
            for axis in range(3)
        )
        signed_sides = tuple(
            math.fsum(
                normal[axis] * (centroid[axis] - face_centroid[axis])
                for axis in range(3)
            )
            for centroid in centroids
        )
        if (
            abs(signed_sides[0]) > side_tolerance
            and abs(signed_sides[1]) > side_tolerance
            and signed_sides[0] * signed_sides[1] > 0.0
        ):
            folded += 1
    return folded


def _facet_area(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
) -> float:
    first = coordinates[facet[0]]
    areas: list[float] = []
    for index in range(1, len(facet) - 1):
        second = coordinates[facet[index]]
        third = coordinates[facet[index + 1]]
        first_edge = tuple(second[axis] - first[axis] for axis in range(3))
        second_edge = tuple(third[axis] - first[axis] for axis in range(3))
        cross = (
            first_edge[1] * second_edge[2] - first_edge[2] * second_edge[1],
            first_edge[2] * second_edge[0] - first_edge[0] * second_edge[2],
            first_edge[0] * second_edge[1] - first_edge[1] * second_edge[0],
        )
        areas.append(
            0.5 * math.sqrt(math.fsum(value * value for value in cross))
        )
    return math.fsum(areas)


def _is_complete_axis_aligned_box_shell(prepared: _PreparedShell) -> bool:
    """Prove the narrow geometry on which the pyramid untangler is tried.

    Gmsh's pyramid untangler is a useful second official algorithm for a
    convex rectangular PLC, but it has unsafe native failure modes on general
    discrete shells.  Keep it behind a geometry-only proof: six complete
    axis-aligned rectangular sides, exact box volume and at least one QUAD4.
    Component names, materials and package roles are deliberately unavailable.
    """

    if not any(len(facet) == 4 for facet in prepared.facets):
        return False
    bounds = tuple(
        (
            min(point[axis] for point in prepared.coordinates.values()),
            max(point[axis] for point in prepared.coordinates.values()),
        )
        for axis in range(3)
    )
    lengths = tuple(upper - lower for lower, upper in bounds)
    scale = max(1.0, *(abs(value) for pair in bounds for value in pair))
    tolerance = _COORDINATE_TOLERANCE * scale
    if any(length <= tolerance for length in lengths):
        return False

    side_areas: dict[tuple[int, int], float] = defaultdict(float)
    for facet in prepared.facets:
        matches = tuple(
            (axis, side)
            for axis, pair in enumerate(bounds)
            for side, coordinate in enumerate(pair)
            if all(
                abs(prepared.coordinates[node][axis] - coordinate)
                <= tolerance
                for node in facet
            )
        )
        if len(matches) != 1:
            return False
        area = _facet_area(facet, prepared.coordinates)
        if not math.isfinite(area) or area <= tolerance * tolerance:
            return False
        side_areas[matches[0]] += area

    for axis in range(3):
        expected = lengths[(axis + 1) % 3] * lengths[(axis + 2) % 3]
        for side in (0, 1):
            actual = float(side_areas[axis, side])
            if not math.isclose(
                actual,
                expected,
                rel_tol=1.0e-9,
                abs_tol=max(1.0e-14, tolerance * tolerance),
            ):
                return False
    box_volume = math.prod(lengths)
    return math.isclose(
        prepared.shell_volume,
        box_volume,
        rel_tol=1.0e-10,
        abs_tol=max(1.0e-15, tolerance**3),
    )


def _candidate_is_eligible_for_box_pyramid_untangler(
    candidate: _Candidate,
    prepared: _PreparedShell,
) -> bool:
    """Return whether a raw fold may enter Gmsh's pyramid untangler path."""

    if not _is_complete_axis_aligned_box_shell(prepared):
        return False
    if candidate.duplicate_node_count or any(
        not math.isfinite(value) or value <= 0.0
        for value in candidate.determinants
    ):
        return False
    if len(candidate.elements) != len(
        {
            (gmsh_type, tuple(sorted(nodes)))
            for gmsh_type, _tag, nodes in candidate.elements
        }
    ):
        return False
    if not _folded_internal_face_count(candidate.elements, candidate.coordinates):
        return False

    expected_boundary = {
        tuple(
            sorted(_coordinate_key(prepared.coordinates[node]) for node in facet)
        )
        for facet in prepared.facets
    }
    actual_boundary = {
        tuple(
            sorted(_coordinate_key(candidate.coordinates[node]) for node in facet)
        )
        for facet in candidate.boundary_facets
    }
    if actual_boundary != expected_boundary:
        return False
    element_volume = math.fsum(
        _element_volume(gmsh_type, nodes, candidate.coordinates)
        for gmsh_type, _tag, nodes in candidate.elements
    )
    relative_excess = (element_volume - prepared.shell_volume) / (
        prepared.shell_volume
    )
    return (
        math.isfinite(relative_excess)
        and relative_excess > 0.0
        and relative_excess <= 1.0e-2
    )


def _finalize(
    candidate: _Candidate,
    prepared: _PreparedShell,
    *,
    target_size: float,
    near_size: float,
    transition_distance: float,
    minimum_quality: float,
) -> GmshClosedShellRemainder:
    if candidate.duplicate_node_count:
        raise ConstrainedHybridError(
            "Gmsh closed-shell remainder contains duplicate nodes"
        )
    if any(
        not math.isfinite(value) or value <= 0.0
        for value in candidate.determinants
    ):
        raise ConstrainedHybridError(
            "Gmsh closed-shell remainder contains a non-positive element"
        )
    folded_internal_faces = _folded_internal_face_count(
        candidate.elements,
        candidate.coordinates,
    )
    if folded_internal_faces:
        raise ConstrainedHybridError(
            "Gmsh closed-shell volume connectivity folds across internal "
            f"faces: folded_internal_face_count={folded_internal_faces}"
        )
    metrics = (candidate.sicn, candidate.sige, candidate.scaled_jacobian)
    if any(not math.isfinite(value) for values in metrics for value in values):
        raise ConstrainedHybridError(
            "Gmsh closed-shell remainder quality is non-finite"
        )
    if any(min(values) < minimum_quality for values in metrics):
        raise ConstrainedHybridError(
            "closed-shell remainder quality floor was not met: "
            f"minSJ={min(candidate.scaled_jacobian):.8g}, "
            f"minSICN={min(candidate.sicn):.8g}, "
            f"minSIGE={min(candidate.sige):.8g}, "
            f"required={minimum_quality:.8g}"
        )

    gmsh_by_coordinate: dict[tuple[float, float, float], int] = {}
    for tag, point in candidate.coordinates.items():
        key = _coordinate_key(point)
        if key in gmsh_by_coordinate:
            raise ConstrainedHybridError(
                "Gmsh closed-shell remainder has coincident nodes"
            )
        gmsh_by_coordinate[key] = tag
    source_by_gmsh: dict[int, int] = {}
    for source_id, point in prepared.coordinates.items():
        gmsh_tag = gmsh_by_coordinate.get(_coordinate_key(point))
        if gmsh_tag is None or math.dist(candidate.coordinates[gmsh_tag], point) > (
            _COORDINATE_TOLERANCE
        ):
            raise ConstrainedHybridError(
                "Gmsh changed a locked closed-shell node"
            )
        source_by_gmsh[gmsh_tag] = source_id

    # ``createGeometry`` is allowed to renumber nodes of a discrete entity.
    # Compare locked facets in the caller's source-ID namespace recovered from
    # immutable coordinates, never in Gmsh's transient tag namespace.
    actual_by_source_key: dict[FaceKey, tuple[int, ...]] = {}
    for facet in candidate.boundary_facets:
        try:
            source_facet = tuple(source_by_gmsh[node] for node in facet)
        except KeyError as error:
            raise ConstrainedHybridError(
                "Gmsh inserted a node into the locked closed-shell boundary"
            ) from error
        key = _face_key(source_facet)
        if key in actual_by_source_key:
            raise ConstrainedHybridError(
                "Gmsh duplicated a locked closed-shell boundary facet"
            )
        actual_by_source_key[key] = facet
    expected_keys = {_face_key(facet) for facet in prepared.facets}
    if set(actual_by_source_key) != expected_keys:
        raise ConstrainedHybridError(
            "Gmsh changed the locked closed-shell boundary facets"
        )

    ordered_gmsh = tuple(
        sorted(
            candidate.coordinates,
            key=lambda tag: (_coordinate_key(candidate.coordinates[tag]), tag),
        )
    )
    local_by_gmsh = {
        gmsh_tag: local_id
        for local_id, gmsh_tag in enumerate(ordered_gmsh, start=1)
    }
    coordinates = {
        local_by_gmsh[tag]: candidate.coordinates[tag] for tag in ordered_gmsh
    }
    source_by_local = {
        local_by_gmsh[gmsh_tag]: source_id
        for gmsh_tag, source_id in source_by_gmsh.items()
    }
    elements = tuple(
        sorted(
            (
                GmshClosedShellElement(
                    gmsh_type,
                    tuple(local_by_gmsh[node] for node in nodes),
                )
                for gmsh_type, _tag, nodes in candidate.elements
            ),
            key=lambda element: (
                element.gmsh_type,
                tuple(sorted(element.node_ids)),
                element.node_ids,
            ),
        )
    )
    duplicate_elements = len(elements) - len(
        {
            (element.gmsh_type, tuple(sorted(element.node_ids)))
            for element in elements
        }
    )
    if duplicate_elements:
        raise ConstrainedHybridError(
            "Gmsh closed-shell remainder contains duplicate elements"
        )
    boundary = tuple(
        sorted(
            (
                tuple(local_by_gmsh[node] for node in actual_by_source_key[key])
                for key in expected_keys
            ),
            key=lambda facet: (len(facet), tuple(sorted(facet)), facet),
        )
    )
    docking = tuple(
        facet
        for facet in boundary
        if _face_key(
            tuple(
                source_by_local[node]
                for node in facet
            )
        )
        in prepared.docking_keys
    )
    counts = Counter(element.gmsh_type for element in elements)
    element_volume = math.fsum(
        _element_volume(element.gmsh_type, element.node_ids, coordinates)
        for element in elements
    )
    relative_error = abs(element_volume - prepared.shell_volume) / (
        prepared.shell_volume
    )
    if relative_error > 1.0e-8:
        raise ConstrainedHybridError(
            "Gmsh closed-shell element volume differs from its locked shell: "
            f"relative_error={relative_error:.8g}"
        )
    return GmshClosedShellRemainder(
        MappingProxyType(coordinates),
        MappingProxyType(source_by_local),
        elements,
        boundary,
        docking,
        counts[_TET4],
        counts[_HEX8],
        counts[_WEDGE6],
        counts[_PYRAMID5],
        sum(len(facet) == 3 for facet in boundary),
        sum(len(facet) == 4 for facet in boundary),
        target_size,
        near_size,
        transition_distance,
        candidate.field_kind,
        min(candidate.sicn),
        min(candidate.sige),
        min(candidate.scaled_jacobian),
        min(candidate.determinants),
        candidate.duplicate_node_count,
        duplicate_elements,
        prepared.shell_volume,
        element_volume,
        relative_error,
        candidate.seed,
        candidate.pyramid_untangler_used,
    )


def generate_closed_shell_conformal_remainder(
    node_coordinates: Mapping[int, Sequence[float]],
    boundary_facets: Sequence[Sequence[int]],
    docking_facets: Sequence[Sequence[int]],
    *,
    target_size_mm: float,
    transition_distance_mm: float,
    near_size_mm: float | None = None,
    minimum_quality: float = 0.03,
    random_seeds: Sequence[int] = (1, 2, 3),
    optimization_rounds: int = 2,
    verbose: bool = False,
) -> GmshClosedShellRemainder:
    """Fill a complete locked remainder shell using Gmsh connectivity only."""

    prepared = _prepare_shell(
        node_coordinates,
        boundary_facets,
        docking_facets,
    )
    target_size = _finite(target_size_mm, name="closed-shell target size")
    transition_distance = _finite(
        transition_distance_mm, name="closed-shell transition distance"
    )
    if near_size_mm is None:
        docking_edges = tuple(
            math.dist(
                prepared.coordinates[first],
                prepared.coordinates[second],
            )
            for facet in prepared.facets
            if _face_key(facet) in prepared.docking_keys
            for first, second in _directed_edges(facet)
        )
        near_size = (
            min(target_size, median(docking_edges))
            if docking_edges
            else target_size
        )
    else:
        near_size = _finite(near_size_mm, name="closed-shell near size")
    quality_floor = _finite(
        minimum_quality, name="closed-shell minimum quality"
    )
    if (
        target_size <= 0.0
        or near_size <= 0.0
        or near_size > target_size
        or transition_distance <= 0.0
        or quality_floor <= 0.0
        or quality_floor >= 1.0
    ):
        raise ConstrainedHybridError(
            "closed-shell sizes, transition distance or quality floor are invalid"
        )
    try:
        seeds = tuple(dict.fromkeys(tuple(random_seeds)))
    except TypeError as error:
        raise ConstrainedHybridError(
            "closed-shell random seeds must be a sequence"
        ) from error
    if not seeds or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 1
        for seed in seeds
    ):
        raise ConstrainedHybridError(
            "closed-shell random seeds must be positive integers"
        )
    if (
        isinstance(optimization_rounds, bool)
        or not isinstance(optimization_rounds, int)
        or optimization_rounds < 0
    ):
        raise ConstrainedHybridError(
            "closed-shell optimization_rounds must be non-negative"
        )
    if not isinstance(verbose, bool):
        raise ConstrainedHybridError("closed-shell verbose must be boolean")

    failures: list[str] = []
    pyramid_untangler_seeds: list[int] = []

    def run_observed(seed, untangler=False):
        label = f"trial={uuid.uuid4().hex[:12]}/closed_shell/algorithm=1/seed={seed}/untangler={int(untangler)}"
        candidate = None
        with candidate_event_context(candidate=label):
            emit_candidate_event({"stage": "candidate", "state": "started"})
            try:
                candidate = _mesh_candidate(
                    prepared, target_size=target_size, near_size=near_size,
                    transition_distance=transition_distance, seed=seed,
                    optimization_rounds=optimization_rounds, verbose=verbose,
                    pyramid_untangler=untangler,
                )
                result = _finalize(
                    candidate, prepared, target_size=target_size, near_size=near_size,
                    transition_distance=transition_distance, minimum_quality=quality_floor,
                )
            except ConstrainedHybridError as error:
                emit_candidate_event({"stage": "candidate_audit", "state": "failed", "detail": str(error)})
                return candidate, None, error
            emit_candidate_event({"stage": "candidate_audit", "state": "completed"})
            return candidate, result, None

    for seed in seeds:
        candidate, result, error = run_observed(seed)
        if result is not None:
            return result
        failures.append(f"seed={seed}: {error}")
        if candidate is not None and _candidate_is_eligible_for_box_pyramid_untangler(candidate, prepared):
            pyramid_untangler_seeds.append(seed)

    # Gmsh documents mode 1 of ``Mesh.OptimizePyramids`` as its hybrid-mesh
    # untangler.  It can repair the small overlapping-TET cavities produced by
    # automatic pyramid recovery, but is not safe as a blanket option for an
    # arbitrary PLC.  Retry it only after the raw result proved positive,
    # boundary-exact, mildly volume-conservative folds in a complete convex
    # axis-aligned box.  The returned candidate still passes every ordinary
    # boundary, fold, volume and quality audit below.
    for seed in pyramid_untangler_seeds:
        _candidate_value, result, error = run_observed(seed, True)
        if result is not None:
            return result
        failures.append(f"seed={seed}, pyramid_untangler=1: {error}")
    raise ConstrainedHybridError(
        "Gmsh could not produce an audited closed-shell remainder; "
        + " | ".join(failures)
    )


__all__ = [
    "GmshClosedShellElement",
    "GmshClosedShellRemainder",
    "generate_closed_shell_conformal_remainder",
]
