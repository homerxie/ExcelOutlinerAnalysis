"""Z seed schedules for each material interval in a Layer template."""

from dataclasses import asdict, dataclass
import math

from .package_v2_mesh_sizing import MeshSeedPolicy, ray_levels
from .mesh_controls import ControlAxis, MeshControlInterval


@dataclass(frozen=True, slots=True)
class LayerSweepPolicy:
    constraint: str = "soft"
    direction: str = "negative_z"
    remainder_ratio: float = 0.25
    center_merge_ratio: float = 0.5

    def __post_init__(self):
        MeshSeedPolicy(self.constraint, self.remainder_ratio)
        MeshSeedPolicy(self.constraint, self.center_merge_ratio)
        if self.center_merge_ratio < self.remainder_ratio:
            raise ValueError("中心合并比例必须大于或等于向外 Merge 边界比例")
        if self.direction not in {"negative_z", "positive_z", "both_z"}:
            raise ValueError("Z seed direction must be negative_z, positive_z or both_z")

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, value):
        if not isinstance(value, dict):
            raise ValueError("z_sweep must be a mapping")
        return cls(**value)

    def levels(self, lower, upper, size):
        """Return ascending levels; merge never crosses a material boundary.

        For two fronts the two terminal sizes are measured separately against
        the seed size. The first threshold is exclusive, the second inclusive.
        """
        if not math.isfinite(size) or size <= 0:
            raise ValueError("seed size must be finite and positive")
        if not math.isfinite(lower) or not math.isfinite(upper) or upper <= lower:
            raise ValueError("Z interval must have finite increasing boundaries")
        policy = MeshSeedPolicy(self.constraint, self.remainder_ratio)
        if self.constraint == "soft" or self.direction == "negative_z":
            return ray_levels(lower, upper, size, policy)
        if self.direction == "positive_z":
            return tuple(reversed(ray_levels(upper, lower, size, policy)))

        # Seed each half without independently merging its last cell: the
        # center decision must preserve reflection symmetry.
        center = lower + (upper - lower) / 2
        half_ratio = (center - lower) / size
        count = math.floor(half_ratio)
        nearest = round(half_ratio)
        if nearest > 0 and math.isclose(half_ratio, nearest, rel_tol=1e-12, abs_tol=1e-12):
            left = [lower + i * size for i in range(nearest)] + [center]
            right = [upper - i * size for i in range(nearest)]
            return tuple(left + list(reversed(right)))
        left = [lower + i * size for i in range(count + 1)]
        right = [upper - i * size for i in range(count + 1)]
        remainder = half_ratio - count
        if remainder < self.remainder_ratio - 1e-12 and count:
            left.pop()
            right.pop()
        elif remainder <= self.center_merge_ratio + 1e-12:
            return tuple(left + list(reversed(right)))
        return tuple(left + [center] + list(reversed(right)))


@dataclass(frozen=True, slots=True)
class ZSweepOverride:
    start_um: float
    end_um: float
    policy: LayerSweepPolicy

    def __post_init__(self):
        interval = MeshControlInterval("Z sweep", ControlAxis.Z, self.start_um, self.end_um)
        object.__setattr__(self, "start_um", interval.start_um)
        object.__setattr__(self, "end_um", interval.end_um)
        if not isinstance(self.policy, LayerSweepPolicy):
            raise ValueError("Z sweep override requires a LayerSweepPolicy")

    @property
    def key(self):
        return ("z", self.start_um, self.end_um)

    def to_dict(self):
        return {"start_um": self.start_um, "end_um": self.end_um,
                "policy": self.policy.to_dict()}

    @classmethod
    def from_dict(cls, value):
        if not isinstance(value, dict):
            raise ValueError("Z sweep override must be a mapping")
        return cls(value.get("start_um"), value.get("end_um"),
                   LayerSweepPolicy.from_dict(value.get("policy", {})))


def parse_z_sweep_overrides(values):
    if not isinstance(values, (list, tuple)):
        raise ValueError("z_sweep_overrides must be a list")
    result = tuple(ZSweepOverride.from_dict(value) for value in values)
    if len({item.key for item in result}) != len(result):
        raise ValueError("duplicate Z sweep override interval")
    return result


@dataclass(frozen=True, slots=True)
class RadialSeedPolicy:
    constraint: str = "soft"
    direction: str = "inner"
    remainder_ratio: float = .25
    center_merge_ratio: float = .5

    def __post_init__(self):
        self._sweep()

    def _sweep(self):
        directions = {"inner": "negative_z", "outer": "positive_z", "both_r": "both_z"}
        if self.direction not in directions:
            raise ValueError("radial seed direction must be inner, outer or both_r")
        return LayerSweepPolicy(self.constraint, directions[self.direction],
                                self.remainder_ratio, self.center_merge_ratio)

    def levels(self, lower, upper, size):
        return self._sweep().levels(lower, upper, size)

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, value):
        if not isinstance(value, dict):
            raise ValueError("radial seed policy must be a mapping")
        return cls(**value)


@dataclass(frozen=True, slots=True)
class RadialSweepOverride:
    start_um: float
    end_um: float
    policy: RadialSeedPolicy

    def __post_init__(self):
        interval = MeshControlInterval("R seed", ControlAxis.RADIAL, self.start_um, self.end_um)
        object.__setattr__(self, "start_um", interval.start_um)
        object.__setattr__(self, "end_um", interval.end_um)
        if not isinstance(self.policy, RadialSeedPolicy):
            raise ValueError("radial override requires a RadialSeedPolicy")

    @property
    def key(self):
        return ("radial", self.start_um, self.end_um)

    def to_dict(self):
        return {"start_um": self.start_um, "end_um": self.end_um,
                "policy": self.policy.to_dict()}

    @classmethod
    def from_dict(cls, value):
        if not isinstance(value, dict):
            raise ValueError("radial sweep override must be a mapping")
        return cls(value.get("start_um"), value.get("end_um"),
                   RadialSeedPolicy.from_dict(value.get("policy", {})))


def parse_radial_sweep_overrides(values):
    if not isinstance(values, (list, tuple)):
        raise ValueError("radial_sweep_overrides must be a list")
    result = tuple(RadialSweepOverride.from_dict(value) for value in values)
    if len({item.key for item in result}) != len(result):
        raise ValueError("duplicate radial sweep override interval")
    return result
