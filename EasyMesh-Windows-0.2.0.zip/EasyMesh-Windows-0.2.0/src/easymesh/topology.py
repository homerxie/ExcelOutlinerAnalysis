from __future__ import annotations

import functools
import math
import statistics
from dataclasses import dataclass
from typing import Iterable

from .parameters import (
    MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS,
    MAX_NUMERICAL_LENGTH_UM,
    MIN_NUMERICAL_SEPARATION_UM,
    MeshParameters,
    SECTOR_COUNT,
    UM_TO_MM,
)


@dataclass(frozen=True)
class Ring:
    radius_um: float
    elements_per_sector: int
    node_ids: tuple[int, ...]
    sector_count: int = SECTOR_COUNT

    @property
    def angular_node_count(self) -> int:
        return self.sector_count * self.elements_per_sector


@dataclass(frozen=True)
class Face2D:
    node_ids: tuple[int, ...]
    region: int

    @property
    def kind(self) -> str:
        return "triangle" if len(self.node_ids) == 3 else "quadrilateral"


@dataclass(frozen=True)
class AreaStatistics:
    count: int
    minimum_um2: float
    maximum_um2: float
    mean_um2: float
    cv: float

    @classmethod
    def from_values(cls, values: Iterable[float]) -> "AreaStatistics":
        samples = tuple(float(value) for value in values)
        if not samples:
            return cls(0, 0.0, 0.0, 0.0, 0.0)
        mean = statistics.mean(samples)
        return cls(
            count=len(samples),
            minimum_um2=min(samples),
            maximum_um2=max(samples),
            mean_um2=mean,
            cv=statistics.pstdev(samples) / mean if mean > 0.0 else 0.0,
        )

    def to_dict(self) -> dict[str, float | int]:
        return {
            "count": self.count,
            "minimum_um2": self.minimum_um2,
            "maximum_um2": self.maximum_um2,
            "mean_um2": self.mean_um2,
            "cv": self.cv,
        }


@dataclass(frozen=True)
class EdgeStatistics:
    count: int
    minimum_um: float
    maximum_um: float
    mean_um: float
    cv: float
    rms_log_error: float
    within_25_percent: float

    @classmethod
    def from_values(
        cls, values: Iterable[float], target_um: float
    ) -> "EdgeStatistics":
        samples = tuple(float(value) for value in values)
        if not samples:
            return cls(0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        mean = statistics.mean(samples)
        return cls(
            count=len(samples),
            minimum_um=min(samples),
            maximum_um=max(samples),
            mean_um=mean,
            cv=statistics.pstdev(samples) / mean if mean > 0.0 else 0.0,
            rms_log_error=math.sqrt(
                statistics.mean(math.log(value / target_um) ** 2 for value in samples)
            ),
            within_25_percent=sum(
                0.75 * target_um <= value <= 1.25 * target_um for value in samples
            )
            / len(samples),
        )

    def to_dict(self) -> dict[str, float | int]:
        return {
            "count": self.count,
            "minimum_um": self.minimum_um,
            "maximum_um": self.maximum_um,
            "mean_um": self.mean_um,
            "cv": self.cv,
            "rms_log_error": self.rms_log_error,
            "within_25_percent": self.within_25_percent,
        }


@dataclass(frozen=True)
class TopologyPlan:
    coordinates_mm: tuple[tuple[float, float], ...]
    faces: tuple[Face2D, ...]
    rings: tuple[Ring, ...]
    outer_node_ids: tuple[int, ...]
    center_count_path: tuple[int, ...]
    outer_radial_layers: tuple[int, ...]
    target_quad_area_um2: float
    edge_length: EdgeStatistics
    edge_length_by_region: dict[int, EdgeStatistics]
    quad_area: AreaStatistics
    triangle_area: AreaStatistics
    quad_area_by_region: dict[int, AreaStatistics]
    symmetry_ok: bool
    radial_target_sizes_um: tuple[float, ...] = ()
    sector_count: int = SECTOR_COUNT
    symmetry_axes_deg: tuple[int, ...] = (0, 45, 90, 135)
    angular_target_sizes_um: tuple[float, ...] = ()

    @property
    def quadrilateral_count(self) -> int:
        return self.quad_area.count

    @property
    def triangle_count(self) -> int:
        return self.triangle_area.count


def _polygon_area_um2(points: Iterable[tuple[float, float]]) -> float:
    coordinates = tuple(points)
    twice_area = sum(
        coordinates[index][0] * coordinates[(index + 1) % len(coordinates)][1]
        - coordinates[(index + 1) % len(coordinates)][0] * coordinates[index][1]
        for index in range(len(coordinates))
    )
    return 0.5 * abs(twice_area)


def _extra_intervals(inner_count: int, outer_count: int) -> set[int]:
    extra_count = outer_count - inner_count
    if extra_count <= 0:
        return set()
    if outer_count > 2 * inner_count:
        raise ValueError("相邻圆环的周向边数增长不能超过 2:1。")
    # The half-cell offset distributes the split intervals as evenly as possible.
    return {
        min(inner_count - 1, math.floor((index + 0.5) * inner_count / extra_count))
        for index in range(extra_count)
    }


def _add_ring(
    coordinates_mm: list[tuple[float, float]],
    radius_um: float,
    count_per_sector: int,
    sector_count: int,
) -> Ring:
    total_count = sector_count * count_per_sector
    ids: list[int] = []
    for index in range(total_count):
        angle = 2.0 * math.pi * index / total_count
        ids.append(len(coordinates_mm))
        coordinates_mm.append(
            (
                radius_um * UM_TO_MM * math.cos(angle),
                radius_um * UM_TO_MM * math.sin(angle),
            )
        )
    return Ring(radius_um, count_per_sector, tuple(ids), sector_count)


def _connect_equal_rings(inner: Ring, outer: Ring, region: int) -> list[Face2D]:
    faces: list[Face2D] = []
    count = inner.angular_node_count
    for index in range(count):
        faces.append(
            Face2D(
                (
                    inner.node_ids[index],
                    outer.node_ids[index],
                    outer.node_ids[(index + 1) % count],
                    inner.node_ids[(index + 1) % count],
                ),
                region,
            )
        )
    return faces


def _connect_doubling_rings(inner: Ring, outer: Ring, region: int) -> list[Face2D]:
    """Use alternating diagonals while preserving configured sector axes."""
    if inner.sector_count != outer.sector_count:
        raise ValueError("相邻圆环的镜像扇区数必须一致。")
    faces: list[Face2D] = []
    inner_total = inner.angular_node_count
    outer_total = outer.angular_node_count
    for index in range(inner_total):
        next_inner = (index + 1) % inner_total
        first_outer = 2 * index
        middle_outer = (first_outer + 1) % outer_total
        last_outer = (first_outer + 2) % outer_total
        if index % 2 == 0:
            faces.append(
                Face2D(
                    (inner.node_ids[index], outer.node_ids[first_outer], outer.node_ids[middle_outer]),
                    region,
                )
            )
            faces.append(
                Face2D(
                    (
                        inner.node_ids[index],
                        outer.node_ids[middle_outer],
                        outer.node_ids[last_outer],
                        inner.node_ids[next_inner],
                    ),
                    region,
                )
            )
        else:
            faces.append(
                Face2D(
                    (
                        inner.node_ids[index],
                        outer.node_ids[first_outer],
                        outer.node_ids[middle_outer],
                        inner.node_ids[next_inner],
                    ),
                    region,
                )
            )
            faces.append(
                Face2D(
                    (inner.node_ids[next_inner], outer.node_ids[middle_outer], outer.node_ids[last_outer]),
                    region,
                )
            )
    return faces


def _connect_general_rings(inner: Ring, outer: Ring, region: int) -> list[Face2D]:
    """Connect a non-doubling increase using mirrored configured sectors."""
    if inner.sector_count != outer.sector_count:
        raise ValueError("相邻圆环的镜像扇区数必须一致。")
    inner_count = inner.elements_per_sector
    outer_count = outer.elements_per_sector
    split_intervals = _extra_intervals(inner_count, outer_count)
    base_faces: list[tuple[str, tuple[tuple[str, int], ...]]] = []
    outer_index = 0
    for inner_index in range(inner_count):
        if inner_index in split_intervals:
            base_faces.append(
                ("triangle", (("i", inner_index), ("o", outer_index), ("o", outer_index + 1)))
            )
            base_faces.append(
                (
                    "quadrilateral",
                    (
                        ("i", inner_index),
                        ("o", outer_index + 1),
                        ("o", outer_index + 2),
                        ("i", inner_index + 1),
                    ),
                )
            )
            outer_index += 2
        else:
            base_faces.append(
                (
                    "quadrilateral",
                    (
                        ("i", inner_index),
                        ("o", outer_index),
                        ("o", outer_index + 1),
                        ("i", inner_index + 1),
                    ),
                )
            )
            outer_index += 1

    faces: list[Face2D] = []
    for sector in range(inner.sector_count):
        mirrored = sector % 2 == 1

        def resolve(reference: tuple[str, int]) -> int:
            kind, local_index = reference
            ring = inner if kind == "i" else outer
            count = inner_count if kind == "i" else outer_count
            if mirrored:
                global_index = ((sector + 1) * count - local_index) % ring.angular_node_count
            else:
                global_index = sector * count + local_index
            return ring.node_ids[global_index]

        for _, references in base_faces:
            node_ids = tuple(resolve(reference) for reference in references)
            if mirrored:
                node_ids = tuple(reversed(node_ids))
            faces.append(Face2D(node_ids, region))
    return faces


def _connect_rings(inner: Ring, outer: Ring, region: int) -> list[Face2D]:
    if inner.elements_per_sector > outer.elements_per_sector:
        return [Face2D(tuple(reversed(face.node_ids)), region)
                for face in _connect_rings(outer, inner, region)]
    if outer.elements_per_sector == inner.elements_per_sector:
        return _connect_equal_rings(inner, outer, region)
    if outer.elements_per_sector == 2 * inner.elements_per_sector:
        return _connect_doubling_rings(inner, outer, region)
    return _connect_general_rings(inner, outer, region)


def _topology_is_reflection_symmetric(
    coordinates_mm: tuple[tuple[float, float], ...],
    faces: tuple[Face2D, ...],
    symmetry_axes_deg: tuple[int, ...],
) -> bool:
    precision = 11

    def point_key(point: tuple[float, float]) -> tuple[float, float]:
        return (round(point[0], precision), round(point[1], precision))

    signatures = {
        (
            len(face.node_ids),
            face.region,
            tuple(sorted(point_key(coordinates_mm[node]) for node in face.node_ids)),
        )
        for face in faces
    }
    for axis_deg in symmetry_axes_deg:
        twice_angle = math.radians(2.0 * axis_deg)
        cosine = math.cos(twice_angle)
        sine = math.sin(twice_angle)
        for face in faces:
            reflected = tuple(
                sorted(
                    point_key(
                        (
                            cosine * coordinates_mm[node][0] + sine * coordinates_mm[node][1],
                            sine * coordinates_mm[node][0] - cosine * coordinates_mm[node][1],
                        )
                    )
                    for node in face.node_ids
                )
            )
            if (len(face.node_ids), face.region, reflected) not in signatures:
                return False
    return True


@dataclass
class _RingRequest:
    radius_um: float
    elements_per_sector: int
    region: int
    fixed_radius: bool


def _round_positive(value: float) -> int:
    return max(1, math.floor(value + 0.5))


def _chord_length_um(
    radius_um: float, elements_per_sector: int, sector_count: int
) -> float:
    return 2.0 * radius_um * math.sin(
        math.pi / (sector_count * elements_per_sector)
    )


def _closest_angular_count(
    radius_um: float,
    target_um: float,
    sector_count: int,
    minimum: int = 1,
    maximum: int | None = None,
) -> int:
    approximate = 2.0 * math.pi * radius_um / (sector_count * target_um)
    upper = (
        max(minimum, maximum)
        if maximum is not None
        else max(minimum, math.ceil(approximate) + 2)
    )
    return min(
        range(minimum, upper + 1),
        key=lambda count: abs(
            math.log(
                _chord_length_um(radius_um, count, sector_count) / target_um
            )
        ),
    )


def _center_counts(
    radii_um: list[float],
    target_um: float,
    final_count: int,
    sector_count: int,
) -> list[int]:
    counts = [
        _closest_angular_count(
            radius, target_um, sector_count, 1, final_count
        )
        for radius in radii_um
    ]
    counts[0] = 1
    counts[-1] = final_count
    for index in range(1, len(counts)):
        if sector_count == 4:
            # A 90-degree sector has roughly twice as many angular elements
            # per sector as the legacy 45-degree plan.  Cap the preferred
            # intermediate count so the first transition from the four-node
            # centre ring remains connectable.  Leave the historical 8-sector
            # path byte-for-byte unchanged.
            counts[index] = max(
                counts[index - 1],
                min(counts[index], 2 * counts[index - 1]),
            )
        else:
            counts[index] = max(counts[index - 1], counts[index])
    for index in range(len(counts) - 2, -1, -1):
        counts[index] = max(counts[index], math.ceil(counts[index + 1] / 2.0))
    counts[0] = 1
    if len(counts) > 1 and counts[1] > 2:
        raise ValueError("中心径向层数不足以完成不超过 2:1 的周向增边。")
    return counts


def _band_counts(
    radii_um: list[float],
    target_um: float,
    inner_count: int,
    outer_count: int,
    sector_count: int,
) -> list[int]:
    counts: list[int] = []
    previous = inner_count
    for index, radius in enumerate(radii_um):
        count = (
            outer_count
            if index == len(radii_um) - 1
            else _closest_angular_count(
                radius,
                target_um,
                sector_count,
                previous,
                outer_count,
            )
        )
        count = max(previous, min(count, 2 * previous, outer_count))
        counts.append(count)
        previous = count
    if counts[-1] != outer_count:
        # This is rare for concentric bump dimensions; add-layer planning in
        # the caller guarantees enough steps before reaching this branch.
        counts[-1] = outer_count
    return counts


def _initial_edge_requests(
    parameters: MeshParameters,
    radial_target_sizes_um: tuple[float, ...],
    sector_count: int,
) -> tuple[list[_RingRequest], tuple[int, ...]]:
    radii_um = [radius / UM_TO_MM for radius in parameters.radii_mm_ascending]
    angular_target = parameters.target_xy_um
    physical_counts: list[int] = []
    previous = 1
    for radius in radii_um:
        count = _closest_angular_count(
            radius, angular_target, sector_count, previous
        )
        count = max(previous, count)
        physical_counts.append(count)
        previous = count

    center_radial_target = radial_target_sizes_um[0]
    center_layers = max(
        1,
        _round_positive(radii_um[0] / center_radial_target),
        math.ceil(math.log2(max(1, physical_counts[0]))) + 1,
    )
    center_radii = [
        radii_um[0] * layer / center_layers
        for layer in range(1, center_layers + 1)
    ]
    center_counts = _center_counts(
        center_radii,
        angular_target,
        physical_counts[0],
        sector_count,
    )
    requests = [
        _RingRequest(
            radius,
            count,
            0,
            index == len(center_radii) - 1,
        )
        for index, (radius, count) in enumerate(zip(center_radii, center_counts))
    ]

    outer_layers: list[int] = []
    for region, (inner_radius, outer_radius, inner_count, outer_count) in enumerate(
        zip(radii_um, radii_um[1:], physical_counts, physical_counts[1:]),
        start=1,
    ):
        radial_target = radial_target_sizes_um[region]
        layer_count = max(
            1,
            _round_positive((outer_radius - inner_radius) / radial_target),
            math.ceil(math.log2(max(1.0, outer_count / inner_count))),
        )
        outer_layers.append(layer_count)
        layer_radii = [
            inner_radius + (outer_radius - inner_radius) * layer / layer_count
            for layer in range(1, layer_count + 1)
        ]
        layer_counts = _band_counts(
            layer_radii,
            angular_target,
            inner_count,
            outer_count,
            sector_count,
        )
        requests.extend(
            _RingRequest(
                radius,
                count,
                region,
                index == len(layer_radii) - 1,
            )
            for index, (radius, count) in enumerate(
                zip(layer_radii, layer_counts)
            )
        )
    return requests, tuple(outer_layers)


def _assemble_geometry(
    requests: list[_RingRequest],
    sector_count: int,
) -> tuple[list[tuple[float, float]], list[Ring], list[Face2D]]:
    coordinates_mm: list[tuple[float, float]] = [(0.0, 0.0)]
    rings = [
        _add_ring(
            coordinates_mm,
            request.radius_um,
            request.elements_per_sector,
            sector_count,
        )
        for request in requests
    ]
    faces: list[Face2D] = []
    first_ring = rings[0]
    for index in range(first_ring.angular_node_count):
        faces.append(
            Face2D(
                (
                    0,
                    first_ring.node_ids[index],
                    first_ring.node_ids[
                        (index + 1) % first_ring.angular_node_count
                    ],
                ),
                0,
            )
        )
    for inner, outer, request in zip(rings, rings[1:], requests[1:]):
        faces.extend(_connect_rings(inner, outer, request.region))
    return coordinates_mm, rings, faces


def _unique_edge_lengths_um(
    coordinates_mm: list[tuple[float, float]] | tuple[tuple[float, float], ...],
    faces: Iterable[Face2D],
) -> dict[tuple[int, int], float]:
    values: dict[tuple[int, int], float] = {}
    for face in faces:
        for first, second in zip(
            face.node_ids, face.node_ids[1:] + face.node_ids[:1]
        ):
            edge = tuple(sorted((first, second)))
            values[edge] = (
                math.dist(coordinates_mm[first], coordinates_mm[second]) / UM_TO_MM
            )
    return values


def _request_scores(
    requests: list[_RingRequest], target_um: float, sector_count: int
) -> tuple[float, float]:
    coordinates, _, faces = _assemble_geometry(requests, sector_count)
    edge_values = _unique_edge_lengths_um(coordinates, faces).values()
    edge_score = math.sqrt(
        statistics.mean(math.log(value / target_um) ** 2 for value in edge_values)
    )
    quad_areas = [
        _polygon_area_um2(coordinates[node] for node in face.node_ids)
        / (UM_TO_MM * UM_TO_MM)
        for face in faces
        if face.kind == "quadrilateral"
    ]
    area_score = statistics.pstdev(quad_areas) / statistics.mean(quad_areas)
    return edge_score, area_score


def _optimize_request_radii(
    requests: list[_RingRequest], target_um: float, sector_count: int
) -> None:
    """Minimize unique-edge log error; use quad area only inside a 0.5% edge band."""
    auxiliary = [
        index for index, request in enumerate(requests) if not request.fixed_radius
    ]
    if not auxiliary:
        return
    # For fine meshes, the initial target-spaced rings are already close to
    # the continuous optimum (typically within a few percent in RMS-log
    # score). Rebuilding thousands of faces for every trial radius would make
    # live GUI editing needlessly slow, so reserve the continuous refinement
    # for the smaller coarse/medium plans where it has visible value.
    if len(_assemble_geometry(requests, sector_count)[2]) > 750:
        return
    best_edge, best_area = _request_scores(requests, target_um, sector_count)
    minimum_gap = 0.05 * target_um
    steps = [target_um / divisor for divisor in (4.0, 8.0, 16.0, 32.0, 64.0)]

    # The linearly spaced initial radii are already within roughly one target
    # length of the edge optimum. A bounded forward/backward sweep propagates
    # neighbouring-ring changes without the unbounded rebuild loop that made
    # very fine targets disproportionately expensive.
    for step in steps:
        for sweep in (auxiliary, tuple(reversed(auxiliary))):
            for index in sweep:
                current = requests[index].radius_um
                lower = (
                    minimum_gap
                    if index == 0
                    else requests[index - 1].radius_um + minimum_gap
                )
                upper = requests[index + 1].radius_um - minimum_gap
                candidate_best = (best_edge, best_area, current)
                for candidate in (current - step, current + step):
                    if not lower < candidate < upper:
                        continue
                    requests[index].radius_um = candidate
                    edge_score, area_score = _request_scores(
                        requests, target_um, sector_count
                    )
                    if edge_score < candidate_best[0] - 1.0e-10:
                        candidate_best = (edge_score, area_score, candidate)
                requests[index].radius_um = candidate_best[2]
                if abs(candidate_best[2] - current) > 1.0e-12:
                    best_edge, best_area = candidate_best[:2]

    edge_limit = best_edge * 1.005
    for step in reversed(steps):
        for index in auxiliary:
            current = requests[index].radius_um
            lower = minimum_gap if index == 0 else requests[index - 1].radius_um + minimum_gap
            upper = requests[index + 1].radius_um - minimum_gap
            candidate_best = (best_area, best_edge, current)
            for candidate in (current - step, current + step):
                if not lower < candidate < upper:
                    continue
                requests[index].radius_um = candidate
                edge_score, area_score = _request_scores(
                    requests, target_um, sector_count
                )
                if edge_score <= edge_limit and area_score < candidate_best[0] - 1.0e-10:
                    candidate_best = (area_score, edge_score, candidate)
            requests[index].radius_um = candidate_best[2]
            best_area, best_edge = candidate_best[:2]


def _validated_radial_target_sizes(
    parameters: MeshParameters,
    radial_target_sizes_um: Iterable[float],
) -> tuple[float, ...]:
    if isinstance(radial_target_sizes_um, (str, bytes)):
        raise ValueError("径向目标尺寸必须按内到外传入一个数值序列。")
    try:
        raw_targets = tuple(radial_target_sizes_um)
    except TypeError as exc:
        raise ValueError("径向目标尺寸必须按内到外传入一个数值序列。") from exc
    expected_count = len(parameters.diameters_um)
    if len(raw_targets) != expected_count:
        raise ValueError(
            "径向目标尺寸数量必须与物理径向区间数一致："
            f"需要 {expected_count} 个，实际收到 {len(raw_targets)} 个。"
        )

    targets: list[float] = []
    for index, source in enumerate(raw_targets, start=1):
        if isinstance(source, bool):
            raise ValueError(f"径向区间 R{index:02d} 的目标尺寸必须是有限正数。")
        try:
            target = float(source)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"径向区间 R{index:02d} 的目标尺寸必须是有限正数。"
            ) from exc
        if not math.isfinite(target) or target <= 0.0:
            raise ValueError(f"径向区间 R{index:02d} 的目标尺寸必须是有限正数。")
        if target < MIN_NUMERICAL_SEPARATION_UM:
            raise ValueError(
                f"径向区间 R{index:02d} 的目标尺寸小于数值建模下限 "
                f"{MIN_NUMERICAL_SEPARATION_UM:g} µm。"
            )
        if target > MAX_NUMERICAL_LENGTH_UM:
            raise ValueError(
                f"径向区间 R{index:02d} 的目标尺寸超过数值建模上限 "
                f"{MAX_NUMERICAL_LENGTH_UM:g} µm。"
            )
        targets.append(target)
    return tuple(targets)


def _symmetry_definition(
    parameters: MeshParameters,
) -> tuple[int, tuple[int, ...]]:
    """Return the projected-sector contract, with legacy-safe fallbacks.

    ``MeshParameters`` now exposes these values directly.  The fallbacks keep
    topology planning compatible with older saved/custom parameter objects
    while the default continues to mean eight mirrored 45-degree sectors.
    """

    sector_count = int(getattr(parameters, "sector_count", SECTOR_COUNT))
    mode = getattr(parameters, "symmetry_mode", "xy_45")
    mode_value = getattr(mode, "value", mode)
    default_axes = (0, 90) if mode_value == "xy" else (0, 45, 90, 135)
    axes = tuple(
        int(axis)
        for axis in getattr(parameters, "symmetry_axes_deg", default_axes)
    )
    if sector_count not in (4, 8):
        raise ValueError("二维拓扑仅支持 4 个或 8 个镜像扇区。")
    expected_axes = (0, 90) if sector_count == 4 else (0, 45, 90, 135)
    if axes != expected_axes:
        raise ValueError("镜像轴与扇区数不一致。")
    return sector_count, axes


def _independent_plane_requests(parameters, radial_targets, angular_targets, policies, sectors):
    """Preserve hard radii; resolve shared arc targets and conformal 2:1 joins."""
    from .layer_sweep import RadialSeedPolicy

    radii = tuple(radius / UM_TO_MM for radius in parameters.radii_mm_ascending)
    policies = policies or (RadialSeedPolicy(),) * len(radii)
    # One physical boundary ring is shared by its two adjacent regions.
    boundary_counts = tuple(max(1, math.ceil(2 * math.pi * radius / (sectors * min(
        angular_targets[index:index + 2])))) for index, radius in enumerate(radii))
    limit = MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS // sectors
    if max(boundary_counts) > limit:
        raise ValueError("环向尺寸过小，二维投影单元数超过交互上限")
    requests = []
    budget = 0
    for region, (lower, upper, size, arc, policy) in enumerate(zip(
            (0.,) + radii[:-1], radii, radial_targets, angular_targets, policies)):
        if math.ceil((upper - lower) / size) > limit:
            raise ValueError("径向层数超过交互上限，请增大 R 尺寸")
        levels = policy.levels(lower, upper, size)
        previous_radius = lower
        previous_count = boundary_counts[region - 1] if region else 0
        for radius in levels[1:]:
            count = (boundary_counts[region] if radius == upper else
                     max(1, math.ceil(2 * math.pi * radius / (sectors * arc))))
            steps = 1
            if previous_count and policy.constraint != "hard":
                steps = max(1, math.ceil(math.log2(max(count / previous_count, previous_count / count))))
            start_count = previous_count
            for step in range(1, steps + 1):
                r = previous_radius + (radius - previous_radius) * step / steps
                n = count
                if step < steps:
                    remaining = steps - step
                    low = max(1, math.ceil(start_count / 2), math.ceil(count / 2**remaining))
                    high = min(start_count * 2, count * 2**remaining)
                    n = max(low, min(high, math.ceil(2 * math.pi * r / (sectors * arc))))
                budget += n
                if budget > limit:
                    raise ValueError("平面网格超过交互上限，请增大 R 或环向尺寸")
                requests.append(_RingRequest(r, n, region, True))
                start_count = n
            previous_radius, previous_count = radius, count
    # Propagate only additional divisions, leaving hard radial positions intact.
    for index in range(len(requests) - 2, -1, -1):
        requests[index].elements_per_sector = max(requests[index].elements_per_sector,
            math.ceil(requests[index + 1].elements_per_sector / 2))
    for index in range(1, len(requests)):
        requests[index].elements_per_sector = max(requests[index].elements_per_sector,
            math.ceil(requests[index - 1].elements_per_sector / 2))
    face_count_per_sector = requests[0].elements_per_sector + sum(
        max(a.elements_per_sector, b.elements_per_sector) for a, b in zip(requests, requests[1:]))
    if face_count_per_sector > limit:
        raise ValueError("网格连接调整后超过交互上限，请增大 R 或环向尺寸")
    outer_layers = tuple(sum(request.region == region for request in requests)
                         for region in range(1, len(radii)))
    return requests, outer_layers


@functools.lru_cache(maxsize=16)
def _build_topology_cached(
    parameters: MeshParameters,
    radial_target_sizes_um: tuple[float, ...],
    radial_policies: tuple = (),
    angular_targets: tuple = (),
) -> TopologyPlan:
    sector_count, symmetry_axes_deg = _symmetry_definition(parameters)
    if angular_targets:
        requests, outer_layers = _independent_plane_requests(
            parameters, radial_target_sizes_um, angular_targets, radial_policies, sector_count)
    else:
        uses_global_radial_target = all(
            target == parameters.target_xy_um for target in radial_target_sizes_um
        )
        if not uses_global_radial_target:
            physical_radii_um = tuple(
                radius / UM_TO_MM for radius in parameters.radii_mm_ascending
            )
            interval_widths_um = (
                physical_radii_um[0],
                *(
                    outer - inner
                    for inner, outer in zip(
                        physical_radii_um, physical_radii_um[1:]
                    )
                ),
            )
            minimum_ring_count = sum(
                max(1, _round_positive(width / target))
                for width, target in zip(
                    interval_widths_um, radial_target_sizes_um
                )
            )
            if sector_count * minimum_ring_count > MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS:
                raise ValueError(
                    "局部径向目标尺寸生成的二维投影单元数超过当前 demo "
                    f"的交互上限 {MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS:,}。"
                )

        global_radial_targets = (
            parameters.target_xy_um,
        ) * len(parameters.diameters_um)
        baseline_requests, baseline_outer_layers = _initial_edge_requests(
            parameters, global_radial_targets, sector_count
        )
        _optimize_request_radii(
            baseline_requests, parameters.target_xy_um, sector_count
        )

        if uses_global_radial_target:
            requests = baseline_requests
            outer_layers = baseline_outer_layers
        else:
            local_requests, local_outer_layers = _initial_edge_requests(
                parameters,
                tuple(parameters.target_xy_um if radial_policies and radial_policies[region].constraint == "hard" else size
                      for region, size in enumerate(radial_target_sizes_um)),
                sector_count,
            )
            overridden_regions = {
                region
                for region, target in enumerate(radial_target_sizes_um)
                if target != parameters.target_xy_um
            }
            requests = [
                request
                for region in range(len(radial_target_sizes_um))
                for request in (
                    local_requests
                    if region in overridden_regions
                    else baseline_requests
                )
                if request.region == region
            ]
            outer_layers = tuple(
                (
                    local_outer_layers[region - 1]
                    if region in overridden_regions
                    else baseline_outer_layers[region - 1]
                )
                for region in range(1, len(radial_target_sizes_um))
            )
            estimated_face_count = sum(
                sector_count * request.elements_per_sector for request in requests
            )
            if estimated_face_count > MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS:
                raise ValueError(
                    "局部径向目标尺寸生成的二维投影单元数超过当前 demo "
                    f"的交互上限 {MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS:,}。"
                )

        if radial_policies:
            physical_radii = tuple(radius / UM_TO_MM for radius in parameters.radii_mm_ascending)
            for region, (inner, outer, size, policy) in enumerate(zip(
                (0.,) + physical_radii[:-1], physical_radii,
                radial_target_sizes_um, radial_policies,
            )):
                if policy.constraint != "hard":
                    continue
                # Hard radial seeds are ring positions, independent of the angular
                # target. Never send these radii through the radius optimizer.
                if (math.ceil((outer - inner) / size) + 1) * sector_count > MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS:
                    raise ValueError("强约束径向层数超过二维投影单元数上限；请增大径向尺寸。")
                radii = policy.levels(inner, outer, size)[1:]
                replacement = [
                    _RingRequest(radius, _closest_angular_count(radius, parameters.target_xy_um, sector_count), region, True)
                    for radius in radii
                ]
                requests = [request for request in requests if request.region != region] + replacement
            requests.sort(key=lambda request: request.radius_um)
            # A coarse hard interval may have fewer rings than the usual angular
            # transition. Increase counts inward to retain conformal <=2:1 joins;
            # the innermost ring is a triangle fan and accepts any positive count.
            for index in range(len(requests) - 2, -1, -1):
                requests[index].elements_per_sector = max(
                    requests[index].elements_per_sector,
                    math.ceil(requests[index + 1].elements_per_sector / 2),
                )
            outer_layers = tuple(sum(request.region == region for request in requests)
                                 for region in range(1, len(physical_radii)))
            if sum(sector_count * request.elements_per_sector for request in requests) > MAX_DEMO_ESTIMATED_PROJECTED_ELEMENTS:
                raise ValueError("强约束径向网格超过二维投影单元数上限；请增大网格尺寸。")

    # Start from the fully optimized global plan and replace only overridden
    # regions with their uniform local subdivision.  This keeps every untouched
    # auxiliary radius byte-for-byte compatible with build_topology(), while
    # avoiding the mistake of using a radial override as a chord-length target.
    coordinates_mm, rings, faces = _assemble_geometry(requests, sector_count)

    coordinates = tuple(coordinates_mm)
    face_tuple = tuple(faces)
    unique_edges = _unique_edge_lengths_um(coordinates, face_tuple)
    edge_by_region: dict[int, set[tuple[int, int]]] = {
        region: set() for region in range(len(parameters.diameters_um))
    }
    quad_values: list[float] = []
    triangle_values: list[float] = []
    quad_by_region: dict[int, list[float]] = {
        region: [] for region in range(len(parameters.diameters_um))
    }
    for face in face_tuple:
        for first, second in zip(
            face.node_ids, face.node_ids[1:] + face.node_ids[:1]
        ):
            edge_by_region[face.region].add(tuple(sorted((first, second))))
        area_mm2 = _polygon_area_um2(coordinates[node] for node in face.node_ids)
        area_um2 = area_mm2 / (UM_TO_MM * UM_TO_MM)
        if face.kind == "quadrilateral":
            quad_values.append(area_um2)
            quad_by_region[face.region].append(area_um2)
        else:
            triangle_values.append(area_um2)

    return TopologyPlan(
        coordinates_mm=coordinates,
        faces=face_tuple,
        rings=tuple(rings),
        outer_node_ids=rings[-1].node_ids,
        center_count_path=tuple(
            request.elements_per_sector
            for request in requests
            if request.region == 0
        ),
        outer_radial_layers=outer_layers,
        radial_target_sizes_um=radial_target_sizes_um,
        target_quad_area_um2=parameters.target_xy_um**2,
        edge_length=EdgeStatistics.from_values(
            unique_edges.values(), parameters.target_xy_um
        ),
        edge_length_by_region={
            region: EdgeStatistics.from_values(
                (unique_edges[edge] for edge in edges), parameters.target_xy_um
            )
            for region, edges in edge_by_region.items()
        },
        quad_area=AreaStatistics.from_values(quad_values),
        triangle_area=AreaStatistics.from_values(triangle_values),
        quad_area_by_region={
            region: AreaStatistics.from_values(values)
            for region, values in quad_by_region.items()
        },
        symmetry_ok=_topology_is_reflection_symmetric(
            coordinates, face_tuple, symmetry_axes_deg
        ),
        sector_count=sector_count,
        symmetry_axes_deg=symmetry_axes_deg,
        angular_target_sizes_um=angular_targets,
    )


@functools.lru_cache(maxsize=16)
def build_topology(parameters: MeshParameters) -> TopologyPlan:
    """Build the legacy isotropic projected topology.

    Both radial spacing and circumferential chord length use
    :attr:`MeshParameters.target_xy_um`, preserving the original public API and
    cached behaviour.
    """

    radial_targets = (parameters.target_xy_um,) * len(parameters.diameters_um)
    return _build_topology_cached(parameters, radial_targets)


def build_topology_with_radial_targets(
    parameters: MeshParameters,
    radial_target_sizes_um: Iterable[float],
    radial_policies: Iterable | None = None,
    *,
    angular_target_sizes_um: Iterable[float] | None = None,
) -> TopologyPlan:
    """Build a topology with an independent radial target in every region.

    ``radial_target_sizes_um`` is ordered from the centre outwards and must
    contain one value per physical radial region.  These values control only
    the number and positions of radial auxiliary rings.  Circumferential node
    counts use independent arc-length targets when supplied; otherwise the
    legacy global XY planner is retained for older callers.
    """

    targets = _validated_radial_target_sizes(parameters, radial_target_sizes_um)
    from .layer_sweep import RadialSeedPolicy

    policies = tuple(radial_policies) if radial_policies is not None else ()
    if policies and (len(policies) != len(targets) or any(
        not isinstance(policy, RadialSeedPolicy) for policy in policies
    )):
        raise ValueError("径向 seed 策略必须与径向区间一一对应。")
    if angular_target_sizes_um is not None:
        try:
            angular_targets = _validated_radial_target_sizes(parameters, angular_target_sizes_um)
        except ValueError as exc:
            raise ValueError(str(exc).replace("径向", "环向")) from exc
        return _build_topology_cached(parameters, targets, policies, angular_targets)
    if not any(policy.constraint == "hard" for policy in policies):
        return _build_topology_cached(parameters, targets)
    return _build_topology_cached(parameters, targets, policies)
