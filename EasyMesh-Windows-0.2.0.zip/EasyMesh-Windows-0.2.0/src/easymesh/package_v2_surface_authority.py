"""Choose a neutral shared-surface producer from geometry and mesh policy.

The decision made here is deliberately smaller than volume meshing.  For each
real positive-area side pair produced by :mod:`package_v2_adjacency_execution`
it identifies which *geometric side* can materialize the complete common
patch without trimming an independently generated surface afterwards.

Component names, materials, stack position and package roles are not inputs.
The only inputs are canonical side area, negotiated surface topology and the
two Component-local volume requirements already carried by the adjacency
execution contract.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import math
from types import MappingProxyType

from .generated_interface_continuity import GeneratedInterfaceContinuityPlan
from .package_v2_adjacency_execution import (
    AdjacentFaceExecutionContract,
    ComponentAdjacencyExecutionPlan,
)
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalComponentGeometry,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
)


class SurfaceAuthorityError(ValueError):
    """A common patch has no unambiguous geometry/policy-owned producer."""


CartesianRectangle = tuple[
    tuple[float, float, float],
    tuple[float, float, float],
    tuple[float, float, float],
]


@dataclass(frozen=True, slots=True)
class SideCoverage:
    component_id: str
    fragment_id: str
    side_name: str
    interface_area_mm2: float
    complete_side_area_mm2: float
    covers_complete_side: bool


@dataclass(frozen=True, slots=True)
class NeutralSurfaceAuthority:
    face_pair_id: str
    interface_id: str
    continuity_group_id: str
    negotiated_target_edge_mm: float
    producer_component_id: str
    producer_fragment_id: str
    producer_side_name: str
    consumer_component_id: str
    consumer_fragment_id: str
    consumer_side_name: str
    surface_policy: str
    selection_reason: str
    side_coverages: tuple[SideCoverage, SideCoverage]


@dataclass(frozen=True, slots=True)
class NeutralSurfaceAuthorityPlan:
    authorities: tuple[NeutralSurfaceAuthority, ...]
    authority_by_face_pair_id: Mapping[str, NeutralSurfaceAuthority]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "authority_by_face_pair_id",
            MappingProxyType(dict(self.authority_by_face_pair_id)),
        )


def _fillet_slice_area(
    root: CanonicalRectangularUnderfillFillet,
    width: float,
) -> float:
    return (
        2.0 * sum(root.die_size_xy_mm) * width
        + math.pi * width * width
    )


def canonical_side_area_mm2(
    fragment: CanonicalGeometryFragment,
    side_name: str,
) -> float:
    """Return the complete analytic area of one classified local side."""

    if type(fragment) is not CanonicalGeometryFragment:
        raise SurfaceAuthorityError("fragment must be canonical geometry")
    if not isinstance(side_name, str) or not side_name:
        raise SurfaceAuthorityError("side_name is invalid")
    root = fragment.root
    if side_name.startswith("orth:"):
        from .package_v2_orthogonal_domain_planning import root_boundary_rectangles

        return sum(
            math.prod(b[t][1] - b[t][0] for t in range(3) if t != a)
            for side, a, end, b in root_boundary_rectangles(root)
            if side == side_name
        )
    if type(root) is CanonicalBox:
        sx, sy, sz = root.size_xyz_mm
        areas = {
            "x_min": sy * sz,
            "x_max": sy * sz,
            "y_min": sx * sz,
            "y_max": sx * sz,
            "z_min": sx * sy,
            "z_max": sx * sy,
        }
    elif type(root) is CanonicalRectangularFrameExtrusion:
        ox, oy = root.outer_size_xy_mm
        ix, iy = root.opening_size_xy_mm
        height = root.height_mm
        areas = {
            "z_min": ox * oy - ix * iy,
            "z_max": ox * oy - ix * iy,
            "outer_x_min": oy * height,
            "outer_x_max": oy * height,
            "outer_y_min": ox * height,
            "outer_y_max": ox * height,
            "opening_x_min": iy * height,
            "opening_x_max": iy * height,
            "opening_y_min": ix * height,
            "opening_y_max": ix * height,
        }
    elif type(root) is CanonicalRectangularUnderfillFillet:
        from .package_v2_swept_fillet import slice_area
        dx, dy = root.die_size_xy_mm
        height = root.wall_height_mm
        areas = {
            "z_min": slice_area(root, 0.),
            "z_max": slice_area(root, 1.),
            "die_x_min": dy * height,
            "die_x_max": dy * height,
            "die_y_min": dx * height,
            "die_y_max": dx * height,
        }
    else:
        raise SurfaceAuthorityError(
            "surface authority supports canonical Box, Frame and rectangular "
            "fillet sides"
        )
    try:
        area = float(areas[side_name])
    except KeyError as error:
        raise SurfaceAuthorityError(
            f"side {side_name!r} is not a complete side of fragment "
            f"{fragment.fragment_id!r}"
        ) from error
    if not math.isfinite(area) or area <= 0.0:
        raise SurfaceAuthorityError("canonical side has no positive area")
    return area


def canonical_side_cartesian_rectangle(
    fragment: CanonicalGeometryFragment,
    side_name: str,
) -> CartesianRectangle | None:
    """Return ``origin, u, v`` for one complete rectangular local side.

    ``None`` means the analytic side is not a single rectangle and therefore
    cannot be promised as one Cartesian tensor patch.  Placement is kept out
    of this pure geometry helper; the ordering planner separately proves that
    the local axes map to package Cartesian axes whenever this capability is
    required.
    """

    if type(fragment) is not CanonicalGeometryFragment:
        raise SurfaceAuthorityError("fragment must be canonical geometry")
    aliases = {
        "bottom": "z_min",
        "base": "z_min",
        "top": "z_max",
        "cap": "z_max",
    }
    side = aliases.get(side_name, side_name)
    if side.startswith("orth:"):
        from .package_v2_orthogonal_domain_planning import root_boundary_rectangles

        rectangles = [
            (a, b)
            for name, a, end, b in root_boundary_rectangles(fragment.root)
            if name == side
        ]
        if not rectangles:
            return None
        axis = rectangles[0][0]
        u, v = [a for a in range(3) if a != axis]
        bounds = tuple(
            (min(b[a][0] for _, b in rectangles), max(b[a][1] for _, b in rectangles))
            for a in range(3)
        )
        area = sum((b[u][1] - b[u][0]) * (b[v][1] - b[v][0]) for _, b in rectangles)
        if not math.isclose(
            area,
            (bounds[u][1] - bounds[u][0]) * (bounds[v][1] - bounds[v][0]),
            rel_tol=1e-9,
        ):
            return None
        origin = tuple(b[0] for b in bounds)
        du = [0.0] * 3
        dv = [0.0] * 3
        du[u] = bounds[u][1] - bounds[u][0]
        dv[v] = bounds[v][1] - bounds[v][0]
        return origin, tuple(du), tuple(dv)
    if side.startswith("inner_"):
        side = "opening_" + side[len("inner_") :]

    root = fragment.root
    if type(root) is CanonicalBox:
        x0, y0, z0 = root.origin_xyz_mm
        sx, sy, sz = root.size_xyz_mm
        rectangles: dict[str, CartesianRectangle] = {
            "x_min": ((x0, y0, z0), (0.0, sy, 0.0), (0.0, 0.0, sz)),
            "x_max": ((x0 + sx, y0, z0), (0.0, sy, 0.0), (0.0, 0.0, sz)),
            "y_min": ((x0, y0, z0), (sx, 0.0, 0.0), (0.0, 0.0, sz)),
            "y_max": ((x0, y0 + sy, z0), (sx, 0.0, 0.0), (0.0, 0.0, sz)),
            "z_min": ((x0, y0, z0), (sx, 0.0, 0.0), (0.0, sy, 0.0)),
            "z_max": ((x0, y0, z0 + sz), (sx, 0.0, 0.0), (0.0, sy, 0.0)),
        }
        return rectangles.get(side)

    if type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        sx, sy = root.outer_size_xy_mm
        hx0 = x0 + root.opening_offset_xy_mm[0]
        hy0 = y0 + root.opening_offset_xy_mm[1]
        hsx, hsy = root.opening_size_xy_mm
        height = root.height_mm
        rectangles = {
            "outer_x_min": ((x0, y0, z0), (0.0, sy, 0.0), (0.0, 0.0, height)),
            "outer_x_max": ((x0 + sx, y0, z0), (0.0, sy, 0.0), (0.0, 0.0, height)),
            "outer_y_min": ((x0, y0, z0), (sx, 0.0, 0.0), (0.0, 0.0, height)),
            "outer_y_max": ((x0, y0 + sy, z0), (sx, 0.0, 0.0), (0.0, 0.0, height)),
            "opening_x_min": ((hx0, hy0, z0), (0.0, hsy, 0.0), (0.0, 0.0, height)),
            "opening_x_max": ((hx0 + hsx, hy0, z0), (0.0, hsy, 0.0), (0.0, 0.0, height)),
            "opening_y_min": ((hx0, hy0, z0), (hsx, 0.0, 0.0), (0.0, 0.0, height)),
            "opening_y_max": ((hx0, hy0 + hsy, z0), (hsx, 0.0, 0.0), (0.0, 0.0, height)),
        }
        return rectangles.get(side)

    if type(root) is CanonicalRectangularUnderfillFillet:
        x0, y0 = root.die_origin_xy_mm
        sx, sy = root.die_size_xy_mm
        z0 = root.base_z_mm
        height = root.wall_height_mm
        rectangles = {
            "die_x_min": ((x0, y0, z0), (0.0, sy, 0.0), (0.0, 0.0, height)),
            "die_x_max": ((x0 + sx, y0, z0), (0.0, sy, 0.0), (0.0, 0.0, height)),
            "die_y_min": ((x0, y0, z0), (sx, 0.0, 0.0), (0.0, 0.0, height)),
            "die_y_max": ((x0, y0 + sy, z0), (sx, 0.0, 0.0), (0.0, 0.0, height)),
        }
        return rectangles.get(side)

    raise SurfaceAuthorityError(
        "Cartesian side capability supports canonical Box, Frame and "
        "rectangular fillet geometry"
    )


def _coverage(
    component_id: str,
    fragment: CanonicalGeometryFragment,
    side_name: str,
    interface_area: float,
) -> SideCoverage:
    complete = canonical_side_area_mm2(fragment, side_name)
    tolerance = max(1.0e-12, 5.0e-7 * complete)
    if interface_area > complete + tolerance:
        raise SurfaceAuthorityError(
            "actual common-face area exceeds its canonical side area"
        )
    return SideCoverage(
        component_id,
        fragment.fragment_id,
        side_name,
        interface_area,
        complete,
        math.isclose(
            interface_area,
            complete,
            rel_tol=5.0e-7,
            abs_tol=1.0e-12,
        ),
    )


def plan_neutral_surface_authorities(
    components: Mapping[str, CanonicalComponentGeometry],
    adjacency_execution: ComponentAdjacencyExecutionPlan,
    continuity: GeneratedInterfaceContinuityPlan,
    *,
    producer_component_id_by_face_pair_id: Mapping[str, str],
    negotiated_target_edge_mm_by_face_pair_id: Mapping[str, float],
) -> NeutralSurfaceAuthorityPlan:
    """Bind preflight-approved priority direction to every actual face pair."""

    if not isinstance(components, Mapping) or any(
        not isinstance(key, str)
        or type(value) is not CanonicalComponentGeometry
        or value.component_id != key
        for key, value in components.items()
    ):
        raise SurfaceAuthorityError(
            "components must map canonical global IDs to geometry"
        )
    if type(adjacency_execution) is not ComponentAdjacencyExecutionPlan:
        raise SurfaceAuthorityError("adjacency_execution has an invalid type")
    if type(continuity) is not GeneratedInterfaceContinuityPlan:
        raise SurfaceAuthorityError("continuity has an invalid type")
    if not isinstance(producer_component_id_by_face_pair_id, Mapping) or set(
        producer_component_id_by_face_pair_id
    ) != {value.face_pair_id for value in adjacency_execution.face_pairs}:
        raise SurfaceAuthorityError(
            "priority producer mapping must exactly cover actual face pairs"
        )
    if not isinstance(negotiated_target_edge_mm_by_face_pair_id, Mapping) or set(
        negotiated_target_edge_mm_by_face_pair_id
    ) != {value.face_pair_id for value in adjacency_execution.face_pairs}:
        raise SurfaceAuthorityError(
            "priority target mapping must exactly cover actual face pairs"
        )
    group_by_id = {value.group_id: value for value in continuity.groups}
    if len(group_by_id) != len(continuity.groups):
        raise SurfaceAuthorityError("continuity group IDs are not unique")
    face_interface_ids = {
        value.interface_id for value in adjacency_execution.face_pairs
    }
    if set(continuity.group_id_by_interface) != face_interface_ids:
        raise SurfaceAuthorityError(
            "continuity interfaces do not exactly cover actual face contracts"
        )
    for interface_id, group_id in continuity.group_id_by_interface.items():
        group = group_by_id.get(group_id)
        if group is None or interface_id not in group.interface_ids:
            raise SurfaceAuthorityError(
                "continuity interface-to-group mapping is inconsistent"
            )
    fragment_by_id = {
        fragment.fragment_id: fragment
        for component in components.values()
        for fragment in component.fragments
    }
    if len(fragment_by_id) != sum(
        len(component.fragments) for component in components.values()
    ):
        raise SurfaceAuthorityError("canonical fragment IDs are not unique")

    authorities: list[NeutralSurfaceAuthority] = []
    def append_authority(
        face: AdjacentFaceExecutionContract,
        coverages: tuple[SideCoverage, SideCoverage],
        producer: SideCoverage,
        reason: str,
    ) -> None:
        group_id = continuity.group_id_by_interface[face.interface_id]
        group = group_by_id[group_id]
        target_edge = negotiated_target_edge_mm_by_face_pair_id[face.face_pair_id]
        if (
            isinstance(target_edge, bool)
            or not isinstance(target_edge, (int, float))
            or not math.isfinite(float(target_edge))
            or target_edge <= 0.0
        ):
            raise SurfaceAuthorityError(
                "priority producer target is invalid"
            )
        target_edge = float(target_edge)
        consumer = coverages[1] if producer == coverages[0] else coverages[0]
        authorities.append(
            NeutralSurfaceAuthority(
                face.face_pair_id,
                face.interface_id,
                group_id,
                target_edge,
                producer.component_id,
                producer.fragment_id,
                producer.side_name,
                consumer.component_id,
                consumer.fragment_id,
                consumer.side_name,
                face.surface_policy,
                reason,
                coverages,
            )
        )

    for face in adjacency_execution.face_pairs:
        try:
            first_fragment = fragment_by_id[face.first_side.fragment_id]
            second_fragment = fragment_by_id[face.second_side.fragment_id]
        except KeyError as error:
            raise SurfaceAuthorityError(
                "actual side references an unknown canonical fragment"
            ) from error
        coverages = (
            _coverage(
                face.first_side.component_id,
                first_fragment,
                face.first_side.side_name,
                face.area_mm2,
            ),
            _coverage(
                face.second_side.component_id,
                second_fragment,
                face.second_side.side_name,
                face.area_mm2,
            ),
        )
        producer_id = producer_component_id_by_face_pair_id[face.face_pair_id]
        producer = next(
            (value for value in coverages if value.component_id == producer_id),
            None,
        )
        if producer is None:
            raise SurfaceAuthorityError(
                "priority producer is not an endpoint of its actual face pair"
            )
        append_authority(
            face,
            coverages,
            producer,
            "mesh_priority_preflight_orders_surface_once",
        )
    ordered = tuple(sorted(authorities, key=lambda value: value.face_pair_id))
    by_id = {value.face_pair_id: value for value in ordered}
    if len(by_id) != len(ordered):
        raise SurfaceAuthorityError("face-pair IDs are not unique")
    return NeutralSurfaceAuthorityPlan(ordered, MappingProxyType(by_id))


__all__ = [
    "NeutralSurfaceAuthority",
    "NeutralSurfaceAuthorityPlan",
    "SideCoverage",
    "SurfaceAuthorityError",
    "canonical_side_cartesian_rectangle",
    "canonical_side_area_mm2",
    "plan_neutral_surface_authorities",
]
