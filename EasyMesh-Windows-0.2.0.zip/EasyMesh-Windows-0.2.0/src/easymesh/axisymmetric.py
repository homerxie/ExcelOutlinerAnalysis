"""Layer-driven parameters for the axisymmetric section mesh.

The legacy :class:`~easymesh.parameters.MeshParameters` describes one flat
extrusion with a single thickness.  This module keeps that format intact and
adds the configuration needed by the layer-defined cross-section: the source
``.layer`` text, radial and vertical interval targets, and deterministic
vertical levels which retain every physical material boundary.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import math
from pathlib import Path
from typing import Any, TypeAlias, Union

from .mesh_controls import (
    ControlAxis,
    MeshControlInterval,
    build_section_control_intervals,
)
from .parameters import (
    MAX_DEMO_THICKNESS_LAYERS,
    MAX_NUMERICAL_LENGTH_UM,
    MIN_NUMERICAL_SEPARATION_UM,
    MeshParameters,
    SymmetryMode,
    normalize_symmetry_mode,
)
from .section import LayerDefinition, SectionPlan, build_section_plan, parse_layer_text
from .layer_sweep import LayerSweepPolicy, ZSweepOverride, parse_z_sweep_overrides
from .layer_sweep import RadialSeedPolicy, RadialSweepOverride, parse_radial_sweep_overrides


AXISYMMETRIC_PARAMETERS_SCHEMA = "easymesh.axisymmetric_mesh_parameters/v1"


def _positive_finite(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be a positive finite number")
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be a positive finite number") from error
    if not math.isfinite(parsed) or parsed <= 0.0:
        raise ValueError(f"{field_name} must be a positive finite number")
    return parsed


def _control_axis(value: object) -> ControlAxis:
    """Normalize R, angular/theta, and Z spellings to the persisted axis."""

    if isinstance(value, ControlAxis):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"r", "radial"}:
            return ControlAxis.RADIAL
        if normalized in {"theta", "angular", "环向"}:
            return ControlAxis.ANGULAR
        if normalized == "z":
            return ControlAxis.Z
    raise ValueError("axis must be radial (R), angular (theta), or vertical (Z)")


def _subdivision_count(width_um: float, target_um: float) -> int:
    """Return a stable ceil(width/target), avoiding a floating-point extra layer."""

    ratio = width_um / target_um
    nearest_integer = round(ratio)
    if math.isclose(
        ratio,
        nearest_integer,
        rel_tol=1.0e-12,
        abs_tol=1.0e-12,
    ):
        return max(1, int(nearest_integer))
    return max(1, math.ceil(ratio))


@dataclass(frozen=True, slots=True)
class IntervalSizeOverride:
    """One local mesh-size override on an exact section-control interval.

    A radial override controls only the radial direction in the xy plane.  It
    intentionally carries no circumferential/azimuthal sizing semantics.
    """

    axis: ControlAxis
    start_um: float
    end_um: float
    size_um: float

    def __post_init__(self) -> None:
        axis = _control_axis(self.axis)
        # Reuse the control-row constructor so coordinates use exactly the same
        # validation and 10-decimal canonicalization as GUI interval keys.
        interval = MeshControlInterval(
            "override",
            axis,
            self.start_um,
            self.end_um,
        )
        object.__setattr__(self, "axis", axis)
        object.__setattr__(self, "start_um", interval.start_um)
        object.__setattr__(self, "end_um", interval.end_um)
        object.__setattr__(
            self,
            "size_um",
            _positive_finite(self.size_um, field_name="override size"),
        )

    @property
    def key(self) -> tuple[str, float, float]:
        return (self.axis.value, self.start_um, self.end_um)

    def to_dict(self) -> dict[str, Any]:
        return {
            "axis": self.axis.value,
            "start_um": self.start_um,
            "end_um": self.end_um,
            "size_um": self.size_um,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "IntervalSizeOverride":
        if not isinstance(data, dict):
            raise TypeError("an interval override must be a mapping")
        try:
            return cls(
                axis=data["axis"],
                start_um=data["start_um"],
                end_um=data["end_um"],
                size_um=data["size_um"],
            )
        except KeyError as error:
            raise ValueError(f"missing override field: {error.args[0]}") from error


@dataclass(frozen=True, slots=True)
class AxisymmetricMeshParameters:
    """Serializable layer-driven geometry and local interval mesh targets."""

    layer_text: str
    target_xy_um: float = 4.0  # Persisted legacy name for the global R target.
    target_z_um: float = 1.35
    overrides: tuple[IntervalSizeOverride, ...] = ()
    model_name: str = "axisymmetric_layer_model"
    symmetry_mode: SymmetryMode = SymmetryMode.XY_45
    z_sweep: LayerSweepPolicy = field(default_factory=LayerSweepPolicy)
    z_sweep_overrides: tuple[ZSweepOverride, ...] = ()
    radial_sweep_overrides: tuple[RadialSweepOverride, ...] = ()
    target_angular_um: float | None = None
    _layers: tuple[LayerDefinition, ...] = field(
        init=False, repr=False, compare=False
    )
    _section_plan: SectionPlan = field(init=False, repr=False, compare=False)
    _control_intervals: tuple[MeshControlInterval, ...] = field(
        init=False, repr=False, compare=False
    )
    _z_layer_counts: tuple[int, ...] = field(
        init=False, repr=False, compare=False
    )
    _z_levels: tuple[float, ...] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        if not isinstance(self.layer_text, str):
            raise TypeError("layer_text must be a string")
        layers = parse_layer_text(self.layer_text)
        if not layers:
            raise ValueError("layer_text must define at least one layer")
        plan = build_section_plan(layers)
        if not plan.diameters_um or plan.max_height_um <= 0.0:
            raise ValueError("layer_text must define a non-empty section")

        z_breakpoints = plan.z_breakpoints_um
        if any(
            upper - lower < MIN_NUMERICAL_SEPARATION_UM
            for lower, upper in zip(z_breakpoints, z_breakpoints[1:])
        ):
            raise ValueError(
                "相邻材料高度边界的间距小于数值建模下限 "
                f"{MIN_NUMERICAL_SEPARATION_UM:g} µm。"
            )

        target_xy = _positive_finite(self.target_xy_um, field_name="target_xy_um")
        if not MIN_NUMERICAL_SEPARATION_UM <= target_xy <= MAX_NUMERICAL_LENGTH_UM:
            raise ValueError("R 目标尺寸超出数值建模范围")
        angular = _positive_finite(self.target_xy_um if self.target_angular_um is None else self.target_angular_um, field_name="target_angular_um")
        if not MIN_NUMERICAL_SEPARATION_UM <= angular <= MAX_NUMERICAL_LENGTH_UM:
            raise ValueError("环向目标尺寸超出数值建模范围")
        target_z = _positive_finite(self.target_z_um, field_name="target_z_um")
        symmetry_mode = normalize_symmetry_mode(self.symmetry_mode)
        if not isinstance(self.z_sweep, LayerSweepPolicy):
            raise TypeError("z_sweep must be a LayerSweepPolicy")
        if not isinstance(self.model_name, str) or not self.model_name.strip():
            raise ValueError("model_name must not be empty")

        try:
            overrides = tuple(self.overrides)
        except TypeError as error:
            raise TypeError("overrides must be an iterable") from error
        if any(not isinstance(item, IntervalSizeOverride) for item in overrides):
            raise TypeError("overrides must contain IntervalSizeOverride objects")

        intervals = build_section_control_intervals(plan)
        valid_keys = {interval.key for interval in intervals}
        sweep_overrides = tuple(self.z_sweep_overrides)
        if any(not isinstance(item, ZSweepOverride) for item in sweep_overrides):
            raise TypeError("z_sweep_overrides must contain ZSweepOverride objects")
        if any(item.key not in valid_keys for item in sweep_overrides):
            raise ValueError("Z sweep override interval does not belong to this layer section")
        sweep_by_key = {item.key: item.policy for item in sweep_overrides}
        if len(sweep_by_key) != len(sweep_overrides):
            raise ValueError("duplicate Z sweep override interval")
        radial_overrides = tuple(self.radial_sweep_overrides)
        if any(not isinstance(item, RadialSweepOverride) for item in radial_overrides):
            raise TypeError("radial_sweep_overrides must contain RadialSweepOverride objects")
        if any(item.key not in valid_keys for item in radial_overrides):
            raise ValueError("radial sweep override interval does not belong to this layer section")
        if len({item.key for item in radial_overrides}) != len(radial_overrides):
            raise ValueError("duplicate radial sweep override interval")
        valid_keys |= {("angular", i.start_um, i.end_um) for i in intervals if i.axis is ControlAxis.RADIAL}
        seen: set[tuple[str, float, float]] = set()
        for override in overrides:
            if override.key not in valid_keys:
                raise ValueError(
                    "override interval does not belong to this layer section: "
                    f"{override.key!r}"
                )
            if override.key in seen:
                raise ValueError(f"duplicate override interval: {override.key!r}")
            if override.size_um < MIN_NUMERICAL_SEPARATION_UM:
                raise ValueError(
                    "局部网格尺寸小于数值建模下限 "
                    f"{MIN_NUMERICAL_SEPARATION_UM:g} µm。"
                )
            if override.size_um > MAX_NUMERICAL_LENGTH_UM:
                raise ValueError(
                    "局部网格尺寸超过数值建模上限 "
                    f"{MAX_NUMERICAL_LENGTH_UM:g} µm。"
                )
            seen.add(override.key)

        # Reuse the legacy numerical/safety validation for the Layer-derived
        # xy geometry and global sizes.  This object is also the exact bridge
        # later consumed by the projected-topology planner.
        MeshParameters(
            diameters_um=plan.diameters_um,
            thickness_um=plan.max_height_um,
            target_xy_um=max(target_xy, angular),
            target_z_um=target_z,
            model_name=self.model_name.strip(),
            symmetry_mode=symmetry_mode,
        )

        override_sizes = {override.key: override.size_um for override in overrides}
        z_intervals = tuple(
            interval for interval in intervals if interval.axis is ControlAxis.Z
        )
        z_layer_counts = tuple(
            _subdivision_count(
                interval.end_um - interval.start_um,
                override_sizes.get(interval.key, target_z),
            )
            for interval in z_intervals
        )
        if sum(z_layer_counts) > MAX_DEMO_THICKNESS_LAYERS:
            raise ValueError(
                "厚度方向层数超过当前 demo 的安全上限 "
                f"{MAX_DEMO_THICKNESS_LAYERS:,}；请增大 Z 网格尺寸。"
            )

        schedules = tuple(
            sweep_by_key.get(interval.key, self.z_sweep).levels(
                interval.start_um, interval.end_um,
                override_sizes.get(interval.key, target_z),
            )
            for interval in z_intervals
        )
        z_layer_counts = tuple(len(levels) - 1 for levels in schedules)
        if sum(z_layer_counts) > MAX_DEMO_THICKNESS_LAYERS:
            raise ValueError("厚度方向层数超过当前 demo 的安全上限；请增大 Z 网格尺寸。")
        z_levels = (schedules[0][0],) + tuple(
            level for levels in schedules for level in levels[1:]
        )

        object.__setattr__(self, "target_angular_um", angular)
        object.__setattr__(self, "target_xy_um", target_xy)
        object.__setattr__(self, "target_z_um", target_z)
        object.__setattr__(self, "overrides", overrides)
        object.__setattr__(self, "model_name", self.model_name.strip())
        object.__setattr__(self, "symmetry_mode", symmetry_mode)
        object.__setattr__(self, "_layers", layers)
        object.__setattr__(self, "_section_plan", plan)
        object.__setattr__(self, "_control_intervals", intervals)
        object.__setattr__(self, "_z_layer_counts", z_layer_counts)
        object.__setattr__(self, "_z_levels", z_levels)
        object.__setattr__(self, "z_sweep_overrides", sweep_overrides)
        object.__setattr__(self, "radial_sweep_overrides", radial_overrides)

    @property
    def layers(self) -> tuple[LayerDefinition, ...]:
        return self._layers

    @property
    def section_plan(self) -> SectionPlan:
        return self._section_plan

    @property
    def control_intervals(self) -> tuple[MeshControlInterval, ...]:
        return self._control_intervals

    @property
    def radial_intervals(self) -> tuple[MeshControlInterval, ...]:
        return tuple(
            interval
            for interval in self._control_intervals
            if interval.axis is ControlAxis.RADIAL
        )

    @property
    def z_intervals(self) -> tuple[MeshControlInterval, ...]:
        return tuple(
            interval
            for interval in self._control_intervals
            if interval.axis is ControlAxis.Z
        )

    @property
    def diameters_um(self) -> tuple[float, ...]:
        return self._section_plan.diameters_um

    @property
    def max_height_um(self) -> float:
        return self._section_plan.max_height_um

    @property
    def sector_count(self) -> int:
        return self.symmetry_mode.sector_count

    @property
    def symmetry_axes_deg(self) -> tuple[int, ...]:
        return self.symmetry_mode.symmetry_axes_deg

    @property
    def effective_size_by_key(self) -> dict[tuple[str, float, float], float]:
        overrides = {override.key: override.size_um for override in self.overrides}
        return {
            interval.key: overrides.get(
                interval.key,
                self.target_xy_um
                if interval.axis is ControlAxis.RADIAL
                else self.target_z_um,
            )
            for interval in self._control_intervals
        }

    @property
    def effective_radial_sizes(self) -> tuple[float, ...]:
        """Inner-to-outer radial sizes; no circumferential sizes are encoded."""

        sizes = self.effective_size_by_key
        return tuple(sizes[interval.key] for interval in self.radial_intervals)

    @property
    def effective_z_sizes(self) -> tuple[float, ...]:
        """Bottom-to-top vertical sizes, aligned with :attr:`z_intervals`."""

        sizes = self.effective_size_by_key
        return tuple(sizes[interval.key] for interval in self.z_intervals)

    # Explicit-unit aliases are useful at meshing boundaries while retaining
    # the concise names specified by the saved-configuration API.
    @property
    def effective_radial_sizes_um(self) -> tuple[float, ...]:
        return self.effective_radial_sizes

    @property
    def effective_angular_sizes_um(self) -> tuple[float, ...]:
        overrides = {item.key: item.size_um for item in self.overrides}
        return tuple(overrides.get(("angular", i.start_um, i.end_um), self.target_angular_um)
                     for i in self.radial_intervals)

    @property
    def effective_radial_policies(self) -> tuple[RadialSeedPolicy, ...]:
        policies = {item.key: item.policy for item in self.radial_sweep_overrides}
        return tuple(policies.get(interval.key, RadialSeedPolicy()) for interval in self.radial_intervals)

    @property
    def effective_z_sizes_um(self) -> tuple[float, ...]:
        return self.effective_z_sizes

    @property
    def z_layer_counts(self) -> tuple[int, ...]:
        """Bottom-to-top subdivision counts, aligned with ``z_intervals``."""

        return self._z_layer_counts

    @property
    def z_levels_um(self) -> tuple[float, ...]:
        """Strictly increasing vertical levels which retain every Z boundary."""

        return self._z_levels

    def to_planar_parameters(self) -> MeshParameters:
        """Build the legacy flat parameters used only by xy topology planning."""

        return MeshParameters(
            diameters_um=self.diameters_um,
            thickness_um=self.max_height_um,
            target_xy_um=self.planar_reference_target_um,
            target_z_um=self.target_z_um,
            model_name=self.model_name,
            symmetry_mode=self.symmetry_mode,
        )

    @property
    def planar_reference_target_um(self) -> float:
        # The legacy container assumes isotropic cells for its early estimate.
        # Use a coarse reference here; the independent planner checks the actual
        # radial/angular counts before allocating geometry or 3D elements.
        return max(self.target_xy_um, self.target_angular_um)

    @property
    def planar_parameters(self) -> MeshParameters:
        return self.to_planar_parameters()

    @property
    def legacy_parameters(self) -> MeshParameters:
        """Compatibility alias for callers which still build a flat topology."""

        return self.to_planar_parameters()

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": AXISYMMETRIC_PARAMETERS_SCHEMA,
            "layer_text": self.layer_text,
            "target_xy_um": self.target_xy_um,
            "target_angular_um": self.target_angular_um,
            "target_z_um": self.target_z_um,
            "overrides": [override.to_dict() for override in self.overrides],
            "model_name": self.model_name,
            "symmetry_mode": self.symmetry_mode.value,
            "z_sweep": self.z_sweep.to_dict(),
            "z_sweep_overrides": [item.to_dict() for item in self.z_sweep_overrides],
            "radial_sweep_overrides": [item.to_dict() for item in self.radial_sweep_overrides],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AxisymmetricMeshParameters":
        if not isinstance(data, dict):
            raise TypeError("axisymmetric parameters must be a mapping")
        if "parameters" in data:
            nested = data["parameters"]
            if not isinstance(nested, dict):
                raise TypeError("parameters must be a mapping")
            data = nested
        schema = data.get("schema")
        if schema is not None and schema != AXISYMMETRIC_PARAMETERS_SCHEMA:
            raise ValueError(f"unsupported axisymmetric parameter schema: {schema!r}")
        try:
            layer_text = data["layer_text"]
        except KeyError as error:
            raise ValueError("missing axisymmetric parameter field: layer_text") from error
        raw_overrides = data.get("overrides", ())
        if isinstance(raw_overrides, (str, bytes, dict)):
            raise TypeError("overrides must be a list of mappings")
        try:
            overrides = tuple(
                item
                if isinstance(item, IntervalSizeOverride)
                else IntervalSizeOverride.from_dict(item)
                for item in raw_overrides
            )
        except TypeError as error:
            raise TypeError("overrides must be a list of mappings") from error
        return cls(
            layer_text=layer_text,
            target_xy_um=data.get("target_xy_um", 4.0),
            target_angular_um=data.get("target_angular_um"),
            target_z_um=data.get("target_z_um", 1.35),
            overrides=overrides,
            model_name=data.get("model_name", "axisymmetric_layer_model"),
            symmetry_mode=data.get("symmetry_mode", SymmetryMode.XY_45.value),
            z_sweep=LayerSweepPolicy.from_dict(data.get("z_sweep", {})),
            z_sweep_overrides=parse_z_sweep_overrides(data.get("z_sweep_overrides", [])),
            radial_sweep_overrides=parse_radial_sweep_overrides(data.get("radial_sweep_overrides", [])),
        )

    def save_json(self, path: str | Path) -> Path:
        output = Path(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(self.to_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        return output

    @classmethod
    def load_json(cls, path: str | Path) -> "AxisymmetricMeshParameters":
        data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
        return cls.from_dict(data)


MeshParameterSet: TypeAlias = Union[AxisymmetricMeshParameters, MeshParameters]


def parameters_from_dict(data: dict[str, Any]) -> MeshParameterSet:
    """Load either the new layer schema or the legacy flat schema."""

    if not isinstance(data, dict):
        raise TypeError("mesh parameters must be a mapping")
    candidate = data.get("parameters", data)
    if not isinstance(candidate, dict):
        raise TypeError("parameters must be a mapping")
    if (
        candidate.get("schema") == AXISYMMETRIC_PARAMETERS_SCHEMA
        or "layer_text" in candidate
    ):
        return AxisymmetricMeshParameters.from_dict(data)
    return MeshParameters.from_dict(data)


def load_parameters_json(path: str | Path) -> MeshParameterSet:
    """Read a JSON configuration and dispatch by schema without breaking v0."""

    data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    return parameters_from_dict(data)


# Descriptive aliases for entrypoints which prefer the word ``mesh``.
load_mesh_parameters = load_parameters_json
mesh_parameters_from_dict = parameters_from_dict


__all__ = [
    "AXISYMMETRIC_PARAMETERS_SCHEMA",
    "AxisymmetricMeshParameters",
    "IntervalSizeOverride",
    "MeshParameterSet",
    "SymmetryMode",
    "load_mesh_parameters",
    "load_parameters_json",
    "mesh_parameters_from_dict",
    "parameters_from_dict",
]
