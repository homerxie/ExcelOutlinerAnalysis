"""Resolve one immutable frozen-to-generated Package V2 interface trace.

This module is deliberately a geometry/audit layer, not a mesher.  It applies
the frozen and generated rigid placements exactly once, extracts complete
TRI3/QUAD4 facets from the *global* exterior of a frozen source, and proves
that every selected facet lies on one semantic face of one generated Box.

The returned trace never edits or snaps source nodes.  In particular, QUAD4
facets remain QUAD4; a later conformal volume mesher must consume each one as
the complete base of a PYRAMID5 before entering a TET4 bulk.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from enum import Enum
import hashlib
from itertools import chain
import json
import math
import re
from typing import Iterable, Mapping, Sequence

from .package_assembly import InterfaceTraceSignature
from .package_v2_compile import CompiledGeneratedInstance
from .package_v2_frozen import FrozenSourceSnapshot
from .package_v2_geometry import CanonicalBox, CanonicalRigidPlacement
from .package_v2_instance_transform import determinant
from .volume_mesh import ELEMENT_SPECS, ElementKind, VolumeElement


_TRACE_PROFILE = "easymesh-package-v2-box-trace-tolerance-v1"
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_DEFAULT_MAXIMUM_VOLUME_FACE_COUNT = 2_000_000
_DEFAULT_MAXIMUM_EXTERIOR_FACE_COUNT = 1_000_000
_DEFAULT_MAXIMUM_TRACE_FACET_COUNT = 500_000
_DEFAULT_MAXIMUM_OVERLAP_PAIR_CHECKS = 5_000_000
_DEFAULT_MAXIMUM_ESTIMATED_WORKING_BYTES = 4 * 1024 * 1024 * 1024

# These are implementation ceilings, not tuning defaults.  A caller may only
# lower a quota.  Raising one would defeat the fail-before-expansion contract.
_HARD_RESOURCE_CEILINGS = {
    "maximum_volume_face_count": _DEFAULT_MAXIMUM_VOLUME_FACE_COUNT,
    "maximum_exterior_face_count": _DEFAULT_MAXIMUM_EXTERIOR_FACE_COUNT,
    "maximum_trace_facet_count": _DEFAULT_MAXIMUM_TRACE_FACET_COUNT,
    "maximum_overlap_pair_checks": _DEFAULT_MAXIMUM_OVERLAP_PAIR_CHECKS,
    "maximum_estimated_working_bytes": _DEFAULT_MAXIMUM_ESTIMATED_WORKING_BYTES,
}


class FrozenTraceError(RuntimeError):
    """Raised when a frozen trace cannot be resolved without changing it."""


def _finite_positive(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise FrozenTraceError(f"{field_name} must be a positive finite number")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise FrozenTraceError(
            f"{field_name} must be a positive finite number"
        ) from error
    if not math.isfinite(result) or result <= 0.0:
        raise FrozenTraceError(f"{field_name} must be a positive finite number")
    return result


def _positive_integer(value: object, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise FrozenTraceError(f"{field_name} must be a positive integer")
    return value


def _point3(value: object, *, field_name: str) -> tuple[float, float, float]:
    if isinstance(value, (str, bytes)):
        raise FrozenTraceError(f"{field_name} must contain three finite numbers")
    try:
        values = tuple(value)  # type: ignore[arg-type]
    except TypeError as error:
        raise FrozenTraceError(
            f"{field_name} must contain three finite numbers"
        ) from error
    if len(values) != 3:
        raise FrozenTraceError(f"{field_name} must contain three finite numbers")
    result: list[float] = []
    for item in values:
        if isinstance(item, bool):
            raise FrozenTraceError(
                f"{field_name} must contain three finite numbers"
            )
        try:
            number = float(item)
        except (OverflowError, TypeError, ValueError) as error:
            raise FrozenTraceError(
                f"{field_name} must contain three finite numbers"
            ) from error
        if not math.isfinite(number):
            raise FrozenTraceError(
                f"{field_name} must contain three finite numbers"
            )
        result.append(0.0 if number == 0.0 else number)
    return tuple(result)  # type: ignore[return-value]


@dataclass(frozen=True, slots=True)
class FrozenTraceControls:
    """Versioned internal classification tolerances; these do not snap nodes."""

    relative_distance: float = 1.0e-10
    minimum_distance_mm: float = 1.0e-12
    ulp_multiplier: float = 64.0
    relative_area: float = 1.0e-9
    normal_dot_tolerance: float = 1.0e-8
    maximum_volume_face_count: int = _DEFAULT_MAXIMUM_VOLUME_FACE_COUNT
    maximum_exterior_face_count: int = _DEFAULT_MAXIMUM_EXTERIOR_FACE_COUNT
    maximum_trace_facet_count: int = _DEFAULT_MAXIMUM_TRACE_FACET_COUNT
    maximum_overlap_pair_checks: int = _DEFAULT_MAXIMUM_OVERLAP_PAIR_CHECKS
    maximum_estimated_working_bytes: int = (
        _DEFAULT_MAXIMUM_ESTIMATED_WORKING_BYTES
    )

    def __post_init__(self) -> None:
        for field_name in (
            "relative_distance",
            "minimum_distance_mm",
            "ulp_multiplier",
            "relative_area",
            "normal_dot_tolerance",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_positive(getattr(self, field_name), field_name=field_name),
            )
        if self.normal_dot_tolerance >= 1.0:
            raise FrozenTraceError("normal_dot_tolerance must be less than one")
        if self.relative_distance > 1.0e-8:
            raise FrozenTraceError("relative_distance exceeds the v1 safety limit")
        if self.minimum_distance_mm > 1.0e-8:
            raise FrozenTraceError(
                "minimum_distance_mm exceeds the v1 safety limit"
            )
        if self.ulp_multiplier < 64.0 or self.ulp_multiplier > 256.0:
            raise FrozenTraceError(
                "ulp_multiplier must remain within the v1 safety range [64, 256]"
            )
        if self.relative_area > 1.0e-6:
            raise FrozenTraceError("relative_area exceeds the v1 safety limit")
        if self.normal_dot_tolerance > 1.0e-4:
            raise FrozenTraceError(
                "normal_dot_tolerance exceeds the v1 safety limit"
            )
        for field_name in (
            "maximum_volume_face_count",
            "maximum_exterior_face_count",
            "maximum_trace_facet_count",
            "maximum_overlap_pair_checks",
            "maximum_estimated_working_bytes",
        ):
            value = _positive_integer(
                getattr(self, field_name), field_name=field_name
            )
            if value > _HARD_RESOURCE_CEILINGS[field_name]:
                raise FrozenTraceError(
                    f"{field_name} exceeds the implementation safety ceiling"
                )
            object.__setattr__(
                self,
                field_name,
                value,
            )


@dataclass(frozen=True, slots=True)
class FrozenTraceToleranceEvidence:
    profile: str
    scale_mm: float
    distance_mm: float
    roundoff_mm: float
    relative_area: float
    normal_dot_tolerance: float

    def __post_init__(self) -> None:
        if self.profile != _TRACE_PROFILE:
            raise FrozenTraceError("trace tolerance profile is invalid")
        for field_name in (
            "scale_mm",
            "distance_mm",
            "roundoff_mm",
            "relative_area",
            "normal_dot_tolerance",
        ):
            object.__setattr__(
                self,
                field_name,
                _finite_positive(getattr(self, field_name), field_name=field_name),
            )
        if self.roundoff_mm > self.distance_mm:
            raise FrozenTraceError(
                "trace roundoff evidence cannot exceed classification distance"
            )
        if self.distance_mm > max(1.0e-8, 1.0e-8 * self.scale_mm):
            raise FrozenTraceError(
                "trace classification distance exceeds the v1 safety envelope"
            )
        if self.relative_area > 1.0e-6:
            raise FrozenTraceError("trace relative area exceeds the v1 safety limit")
        if self.normal_dot_tolerance > 1.0e-4:
            raise FrozenTraceError(
                "trace normal tolerance exceeds the v1 safety limit"
            )


class TargetBoxFace(str, Enum):
    NEGATIVE_X = "-X"
    POSITIVE_X = "+X"
    NEGATIVE_Y = "-Y"
    POSITIVE_Y = "+Y"
    NEGATIVE_Z = "-Z"
    POSITIVE_Z = "+Z"


@dataclass(frozen=True, slots=True)
class LockedTraceNode:
    source_node_tag: int
    source_coordinates_mm: tuple[float, float, float]
    package_coordinates_mm: tuple[float, float, float]

    def __post_init__(self) -> None:
        if (
            isinstance(self.source_node_tag, bool)
            or not isinstance(self.source_node_tag, int)
            or self.source_node_tag < 1
        ):
            raise FrozenTraceError("locked trace source_node_tag must be positive")
        object.__setattr__(
            self,
            "source_coordinates_mm",
            _point3(
                self.source_coordinates_mm,
                field_name="locked trace source_coordinates_mm",
            ),
        )
        object.__setattr__(
            self,
            "package_coordinates_mm",
            _point3(
                self.package_coordinates_mm,
                field_name="locked trace package_coordinates_mm",
            ),
        )


@dataclass(frozen=True, slots=True)
class LockedTraceFacet:
    """Original source node IDs in placed, outward winding.

    owner_local_face_index always refers to the original immutable cell;
    reflection reverses the cycle without changing that provenance.
    """
    source_node_tags: tuple[int, ...]
    owner_element_tag: int
    owner_element_kind: ElementKind
    owner_local_face_index: int
    source_component_global_id: str
    target_face: TargetBoxFace
    patch_index: int
    package_unit_normal_xyz: tuple[float, float, float]
    area_mm2: float

    def __post_init__(self) -> None:
        object.__setattr__(self, "source_node_tags", tuple(self.source_node_tags))
        if len(self.source_node_tags) not in (3, 4):
            raise FrozenTraceError("locked facets must be TRI3 or QUAD4")
        if any(
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 1
            for value in self.source_node_tags
        ):
            raise FrozenTraceError(
                "locked facet source node tags must be positive integers"
            )
        if len(set(self.source_node_tags)) != len(self.source_node_tags):
            raise FrozenTraceError("locked facet contains repeated source nodes")
        if (
            isinstance(self.owner_element_tag, bool)
            or not isinstance(self.owner_element_tag, int)
            or self.owner_element_tag < 1
            or isinstance(self.owner_local_face_index, bool)
            or not isinstance(self.owner_local_face_index, int)
            or self.owner_local_face_index < 0
        ):
            raise FrozenTraceError("locked facet owner metadata is invalid")
        if not isinstance(self.owner_element_kind, ElementKind):
            raise FrozenTraceError("locked facet owner kind is invalid")
        if not isinstance(self.target_face, TargetBoxFace):
            raise FrozenTraceError("locked facet target face is invalid")
        if (
            isinstance(self.patch_index, bool)
            or not isinstance(self.patch_index, int)
            or self.patch_index < 0
        ):
            raise FrozenTraceError("locked facet patch index is invalid")
        if (
            not isinstance(self.source_component_global_id, str)
            or not self.source_component_global_id
        ):
            raise FrozenTraceError("locked facet source Component ID is invalid")
        normal = _point3(
            self.package_unit_normal_xyz,
            field_name="locked facet package_unit_normal_xyz",
        )
        if not math.isclose(_norm(normal), 1.0, rel_tol=0.0, abs_tol=1.0e-9):
            raise FrozenTraceError("locked facet normal must be a unit vector")
        object.__setattr__(self, "package_unit_normal_xyz", normal)
        object.__setattr__(
            self,
            "area_mm2",
            _finite_positive(self.area_mm2, field_name="locked facet area_mm2"),
        )

    @property
    def target_node_tags(self) -> tuple[int, ...]:
        """The exact opposite winding to be consumed by the generated side."""

        return tuple(reversed(self.source_node_tags))


@dataclass(frozen=True, slots=True)
class LockedTracePatch:
    patch_index: int
    facet_indices: tuple[int, ...]
    source_node_tags: tuple[int, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "facet_indices", tuple(self.facet_indices))
        object.__setattr__(self, "source_node_tags", tuple(self.source_node_tags))
        if (
            isinstance(self.patch_index, bool)
            or not isinstance(self.patch_index, int)
            or self.patch_index < 0
            or not self.facet_indices
            or not self.source_node_tags
        ):
            raise FrozenTraceError("locked trace patch is empty or invalid")
        if (
            tuple(sorted(set(self.facet_indices))) != self.facet_indices
            or any(
                isinstance(value, bool)
                or not isinstance(value, int)
                or value < 0
                for value in self.facet_indices
            )
        ):
            raise FrozenTraceError("locked trace patch facet indices are invalid")
        if (
            tuple(sorted(set(self.source_node_tags))) != self.source_node_tags
            or any(
                isinstance(value, bool)
                or not isinstance(value, int)
                or value < 1
                for value in self.source_node_tags
            )
        ):
            raise FrozenTraceError("locked trace patch node tags are invalid")


@dataclass(frozen=True, slots=True)
class LockedInterfaceTrace:
    source_id: str
    source_component_local_id: str
    source_component_global_id: str
    source_snapshot_numbered_sha256: str
    source_component_numbered_sha256: str
    target_instance_id: str
    target_component_local_id: str
    target_component_global_id: str
    target_fragment_id: str
    target_face: TargetBoxFace
    nodes: tuple[LockedTraceNode, ...]
    facets: tuple[LockedTraceFacet, ...]
    patches: tuple[LockedTracePatch, ...]
    triangle_count: int
    quad_count: int
    tolerance: FrozenTraceToleranceEvidence
    maximum_plane_deviation_mm: float
    maximum_bounds_overshoot_mm: float
    source_trace_numbered_sha256: str
    package_geometry_sha256: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "nodes", tuple(self.nodes))
        object.__setattr__(self, "facets", tuple(self.facets))
        object.__setattr__(self, "patches", tuple(self.patches))
        if not self.nodes or not self.facets or not self.patches:
            raise FrozenTraceError("locked interface trace must be non-empty")
        for field_name in (
            "source_id",
            "source_component_local_id",
            "source_component_global_id",
            "target_instance_id",
            "target_component_local_id",
            "target_component_global_id",
            "target_fragment_id",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value:
                raise FrozenTraceError(f"locked trace {field_name} is invalid")
        for field_name in (
            "source_snapshot_numbered_sha256",
            "source_component_numbered_sha256",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not _SHA256.fullmatch(value):
                raise FrozenTraceError(f"locked trace {field_name} is invalid")
        if not isinstance(self.target_face, TargetBoxFace):
            raise FrozenTraceError("locked trace target_face is invalid")
        if not isinstance(self.tolerance, FrozenTraceToleranceEvidence):
            raise FrozenTraceError("locked trace tolerance evidence is invalid")
        node_tags = tuple(node.source_node_tag for node in self.nodes)
        if tuple(sorted(set(node_tags))) != node_tags:
            raise FrozenTraceError("locked trace nodes are not canonical")
        for field_name in ("triangle_count", "quad_count"):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise FrozenTraceError(
                    f"locked interface {field_name} is invalid"
                )
        if self.triangle_count + self.quad_count != len(self.facets):
            raise FrozenTraceError("locked interface facet counts are inconsistent")
        if self.triangle_count != sum(
            len(facet.source_node_tags) == 3 for facet in self.facets
        ) or self.quad_count != sum(
            len(facet.source_node_tags) == 4 for facet in self.facets
        ):
            raise FrozenTraceError("locked interface facet arities are inconsistent")
        node_tag_set = set(node_tags)
        if any(
            tag not in node_tag_set
            for facet in self.facets
            for tag in facet.source_node_tags
        ):
            raise FrozenTraceError("locked facet references an unknown trace node")
        if tuple(patch.patch_index for patch in self.patches) != tuple(
            range(len(self.patches))
        ):
            raise FrozenTraceError("locked trace patch indices are not canonical")
        if any(facet.target_face is not self.target_face for facet in self.facets):
            raise FrozenTraceError("locked trace spans multiple target Box faces")
        if any(
            facet.source_component_global_id != self.source_component_global_id
            for facet in self.facets
        ):
            raise FrozenTraceError(
                "locked facet Component identity differs from the trace source"
            )
        referenced_indices = tuple(
            index for patch in self.patches for index in patch.facet_indices
        )
        if tuple(sorted(referenced_indices)) != tuple(range(len(self.facets))):
            raise FrozenTraceError("locked patches do not partition all facets")
        for patch in self.patches:
            expected_tags = tuple(
                sorted(
                    {
                        tag
                        for index in patch.facet_indices
                        for tag in self.facets[index].source_node_tags
                    }
                )
            )
            if patch.source_node_tags != expected_tags or any(
                self.facets[index].patch_index != patch.patch_index
                for index in patch.facet_indices
            ):
                raise FrozenTraceError("locked patch membership is inconsistent")
        for field_name in (
            "maximum_plane_deviation_mm",
            "maximum_bounds_overshoot_mm",
        ):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise FrozenTraceError(f"locked trace {field_name} is invalid")
            if not math.isfinite(float(value)) or float(value) < 0.0:
                raise FrozenTraceError(f"locked trace {field_name} is invalid")
            if float(value) > self.tolerance.roundoff_mm:
                raise FrozenTraceError(
                    f"locked trace {field_name} exceeds roundoff evidence"
                )
        for value in (
            self.source_trace_numbered_sha256,
            self.package_geometry_sha256,
        ):
            if not isinstance(value, str) or not _SHA256.fullmatch(value):
                raise FrozenTraceError("locked trace fingerprint is invalid")
        package_coordinates = {
            node.source_node_tag: node.package_coordinates_mm for node in self.nodes
        }
        for facet in self.facets:
            points = tuple(
                package_coordinates[tag] for tag in facet.source_node_tags
            )
            area_vector = _polygon_area_vector(points)
            area = _norm(area_vector)
            area_absolute_tolerance = 64.0 * max(
                math.ulp(area),
                math.ulp(facet.area_mm2),
            )
            if area <= 0.0 or not math.isclose(
                area,
                facet.area_mm2,
                rel_tol=1.0e-10,
                abs_tol=area_absolute_tolerance,
            ):
                raise FrozenTraceError(
                    "locked facet area is inconsistent with its package nodes"
                )
            normal = tuple(value / area for value in area_vector)
            if _dot(normal, facet.package_unit_normal_xyz) < 1.0 - 1.0e-9:
                raise FrozenTraceError(
                    "locked facet normal is inconsistent with its package winding"
                )
        if _package_geometry_digest(self.nodes, self.facets, self.patches) != (
            self.package_geometry_sha256
        ):
            raise FrozenTraceError(
                "locked trace package geometry fingerprint is inconsistent"
            )
        if _source_numbered_digest(
            source_id=self.source_id,
            source_component_local_id=self.source_component_local_id,
            source_component_global_id=self.source_component_global_id,
            source_snapshot_numbered_sha256=(
                self.source_snapshot_numbered_sha256
            ),
            source_component_numbered_sha256=(
                self.source_component_numbered_sha256
            ),
            target_instance_id=self.target_instance_id,
            target_component_local_id=self.target_component_local_id,
            target_component_global_id=self.target_component_global_id,
            target_fragment_id=self.target_fragment_id,
            target_face=self.target_face,
            tolerance=self.tolerance,
            nodes=self.nodes,
            facets=self.facets,
        ) != self.source_trace_numbered_sha256:
            raise FrozenTraceError(
                "locked trace numbered fingerprint is inconsistent"
            )

    @property
    def trace_signature(self) -> InterfaceTraceSignature:
        return InterfaceTraceSignature(self.package_geometry_sha256)


@dataclass(frozen=True, slots=True)
class _FaceSpec:
    face: TargetBoxFace
    axis: int
    sign: float
    u_axis: int
    v_axis: int


_FACE_SPECS = (
    _FaceSpec(TargetBoxFace.NEGATIVE_X, 0, -1.0, 1, 2),
    _FaceSpec(TargetBoxFace.POSITIVE_X, 0, 1.0, 1, 2),
    _FaceSpec(TargetBoxFace.NEGATIVE_Y, 1, -1.0, 0, 2),
    _FaceSpec(TargetBoxFace.POSITIVE_Y, 1, 1.0, 0, 2),
    _FaceSpec(TargetBoxFace.NEGATIVE_Z, 2, -1.0, 0, 1),
    _FaceSpec(TargetBoxFace.POSITIVE_Z, 2, 1.0, 0, 1),
)


@dataclass(frozen=True, slots=True)
class _ExteriorFacet:
    cycle: tuple[int, ...]
    owner: VolumeElement
    owner_component_local_id: str
    owner_component_global_id: str
    local_face_index: int
    source_coordinates: tuple[tuple[float, float, float], ...]
    package_coordinates: tuple[tuple[float, float, float], ...]
    package_normal: tuple[float, float, float]
    source_normal: tuple[float, float, float]
    area: float


@dataclass(frozen=True, slots=True)
class _AcceptedFacet:
    facet: _ExteriorFacet
    target_face: TargetBoxFace
    target_polygon_uv: tuple[tuple[float, float], ...]
    maximum_plane_deviation_mm: float
    maximum_bounds_overshoot_mm: float


@dataclass(frozen=True, slots=True)
class _DeferredNearZeroContact:
    facet: _ExteriorFacet
    target_face: TargetBoxFace
    contact_local: tuple[tuple[float, float, float], ...]
    plane_deviation_mm: float
    target_polygon_uv: tuple[tuple[float, float], ...]
    target_bounds_uv: tuple[float, float, float, float]
    was_positive: bool


def _canonical_float(value: float) -> float:
    if not math.isfinite(value):
        raise FrozenTraceError("trace geometry contains a non-finite coordinate")
    return 0.0 if value == 0.0 else value


def _canonical_json_bytes(value: object) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (OverflowError, TypeError, ValueError) as error:
        raise FrozenTraceError("cannot encode canonical trace geometry") from error


def _stream_digest(metadata: object, records: Iterable[object]) -> str:
    digest = hashlib.sha256()
    for value in ({"metadata": metadata},):
        encoded = _canonical_json_bytes(value)
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
    for value in records:
        encoded = _canonical_json_bytes(value)
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
    return digest.hexdigest()


def _source_numbered_digest(
    *,
    source_id: str,
    source_component_local_id: str,
    source_component_global_id: str,
    source_snapshot_numbered_sha256: str,
    source_component_numbered_sha256: str,
    target_instance_id: str,
    target_component_local_id: str,
    target_component_global_id: str,
    target_fragment_id: str,
    target_face: TargetBoxFace,
    tolerance: FrozenTraceToleranceEvidence,
    nodes: Sequence[LockedTraceNode],
    facets: Sequence[LockedTraceFacet],
) -> str:
    metadata = {
        "schema": "easymesh-package-v2-frozen-trace-numbered-v2",
        "source": [
            source_id,
            source_snapshot_numbered_sha256,
        ],
        "source_component": [
            source_component_local_id,
            source_component_global_id,
            source_component_numbered_sha256,
        ],
        "target": [
            target_instance_id,
            target_component_local_id,
            target_component_global_id,
            target_fragment_id,
            target_face.value,
        ],
        "tolerance": {
            "profile": tolerance.profile,
            "scale_mm": tolerance.scale_mm,
            "distance_mm": tolerance.distance_mm,
            "roundoff_mm": tolerance.roundoff_mm,
            "relative_area": tolerance.relative_area,
            "normal_dot_tolerance": tolerance.normal_dot_tolerance,
        },
    }
    return _stream_digest(
        metadata,
        chain(
            (
                [
                    "node",
                    node.source_node_tag,
                    list(node.source_coordinates_mm),
                    list(node.package_coordinates_mm),
                ]
                for node in nodes
            ),
            (
                [
                    "facet",
                    facet.owner_element_tag,
                    facet.owner_local_face_index,
                    facet.owner_element_kind.value,
                    facet.source_component_global_id,
                    list(facet.source_node_tags),
                    facet.target_face.value,
                    facet.patch_index,
                ]
                for facet in facets
            ),
        ),
    )


def _canonical_unoriented_cycle(cycle: tuple[int, ...]) -> tuple[int, ...]:
    forward = tuple(
        cycle[index:] + cycle[:index] for index in range(len(cycle))
    )
    reversed_cycle = tuple(reversed(cycle))
    backward = tuple(
        reversed_cycle[index:] + reversed_cycle[:index]
        for index in range(len(reversed_cycle))
    )
    return min(forward + backward)


def _package_geometry_digest(
    nodes: Sequence[LockedTraceNode],
    facets: Sequence[LockedTraceFacet],
    patches: Sequence[LockedTracePatch],
) -> str:
    package_node_by_tag = {
        node.source_node_tag: node.package_coordinates_mm for node in nodes
    }
    canonical_coordinates = tuple(sorted(set(package_node_by_tag.values())))
    if len(canonical_coordinates) != len(package_node_by_tag):
        raise FrozenTraceError(
            "locked trace contains coincident package nodes with different tags"
        )
    coordinate_index = {
        coordinates: index
        for index, coordinates in enumerate(canonical_coordinates)
    }
    facet_cycles = tuple(
        _canonical_unoriented_cycle(
            tuple(
                coordinate_index[package_node_by_tag[tag]]
                for tag in facet.source_node_tags
            )
        )
        for facet in facets
    )
    patch_records: list[object] = []
    for patch in patches:
        cycles = tuple(sorted(facet_cycles[index] for index in patch.facet_indices))
        patch_records.append(["patch", [list(cycle) for cycle in cycles]])
    patch_records.sort(key=_canonical_json_bytes)
    return _stream_digest(
        {
            "schema": "easymesh-package-v2-frozen-trace-geometry-v2",
            "coordinate_space": "package_mm",
            "facet_orientation": "unoriented",
        },
        chain(
            (
                ["node", index, list(coordinates)]
                for index, coordinates in enumerate(canonical_coordinates)
            ),
            patch_records,
        ),
    )


def _vector_subtract(
    first: Sequence[float], second: Sequence[float]
) -> tuple[float, float, float]:
    return tuple(first[index] - second[index] for index in range(3))  # type: ignore[return-value]


def _dot(first: Sequence[float], second: Sequence[float]) -> float:
    return math.fsum(first[index] * second[index] for index in range(3))


def _cross(
    first: Sequence[float], second: Sequence[float]
) -> tuple[float, float, float]:
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _norm(value: Sequence[float]) -> float:
    return math.sqrt(_dot(value, value))


def _centroid(
    points: Sequence[Sequence[float]],
) -> tuple[float, float, float]:
    origin = points[0]
    return tuple(
        origin[index]
        + math.fsum(point[index] - origin[index] for point in points) / len(points)
        for index in range(3)
    )  # type: ignore[return-value]


def _matmul(
    first: Sequence[Sequence[float]], second: Sequence[Sequence[float]]
) -> tuple[tuple[float, float, float], ...]:
    return tuple(
        tuple(
            math.fsum(first[row][inner] * second[inner][column] for inner in range(3))
            for column in range(3)
        )
        for row in range(3)
    )


def _matvec(
    matrix: Sequence[Sequence[float]], vector: Sequence[float]
) -> tuple[float, float, float]:
    return tuple(_dot(row, vector) for row in matrix)  # type: ignore[return-value]


def _transpose(
    matrix: Sequence[Sequence[float]],
) -> tuple[tuple[float, float, float], ...]:
    return tuple(tuple(matrix[row][column] for row in range(3)) for column in range(3))


def _generated_rotation(
    placement: CanonicalRigidPlacement,
) -> tuple[tuple[float, float, float], ...]:
    x, y, z = (math.radians(value) for value in placement.rotation_deg_xyz)
    rx = ((1.0, 0.0, 0.0), (0.0, math.cos(x), -math.sin(x)), (0.0, math.sin(x), math.cos(x)))
    ry = ((math.cos(y), 0.0, math.sin(y)), (0.0, 1.0, 0.0), (-math.sin(y), 0.0, math.cos(y)))
    rz = ((math.cos(z), -math.sin(z), 0.0), (math.sin(z), math.cos(z), 0.0), (0.0, 0.0, 1.0))
    return _matmul(rz, _matmul(ry, rx))


def _frozen_to_package(
    point: Sequence[float], snapshot: FrozenSourceSnapshot
) -> tuple[float, float, float]:
    rotated = _matvec(snapshot.placement.rotation_matrix, point)
    return tuple(
        _canonical_float(rotated[index] + snapshot.placement.translation_xyz_mm[index])
        for index in range(3)
    )  # type: ignore[return-value]


def _source_to_generated_local(
    point: Sequence[float],
    snapshot: FrozenSourceSnapshot,
    placement: CanonicalRigidPlacement,
    inverse_generated_rotation: Sequence[Sequence[float]],
) -> tuple[float, float, float]:
    """Transform without first adding, then subtracting, a large package offset."""

    pivot = placement.pivot_xyz_mm
    frozen_rotated = _matvec(snapshot.placement.rotation_matrix, point)
    translation_delta = tuple(
        snapshot.placement.translation_xyz_mm[index]
        - placement.translation_xyz_mm[index]
        - pivot[index]
        for index in range(3)
    )
    relative = tuple(
        frozen_rotated[index] + translation_delta[index]
        for index in range(3)
    )
    local_delta = _matvec(inverse_generated_rotation, relative)
    return tuple(
        _canonical_float(local_delta[index] + pivot[index]) for index in range(3)
    )  # type: ignore[return-value]


def _polygon_area_vector(
    points: Sequence[Sequence[float]],
) -> tuple[float, float, float]:
    origin = points[0]
    total = [0.0, 0.0, 0.0]
    for index in range(1, len(points) - 1):
        value = _cross(
            _vector_subtract(points[index], origin),
            _vector_subtract(points[index + 1], origin),
        )
        for axis in range(3):
            total[axis] += value[axis]
    return tuple(0.5 * value for value in total)  # type: ignore[return-value]


def _polygon_area_2d(points: Sequence[tuple[float, float]]) -> float:
    if len(points) < 3:
        return 0.0
    origin = points[0]
    return 0.5 * abs(
        math.fsum(
            _cross_2d(
                _vector_subtract_2d(points[index], origin),
                _vector_subtract_2d(points[index + 1], origin),
            )
            for index in range(1, len(points) - 1)
        )
    )


def _polygon_has_positive_area(
    points: Sequence[tuple[float, float]],
) -> bool:
    """Detect two-dimensional extent without multiplying tiny raw lengths."""

    if len(points) < 3:
        return False
    origin = points[0]
    relative = tuple(_vector_subtract_2d(point, origin) for point in points)
    scale = max(abs(value) for point in relative for value in point)
    if scale == 0.0:
        return False
    normalized = tuple(
        (point[0] / scale, point[1] / scale) for point in relative
    )
    signed_double_area = math.fsum(
        _cross_2d(normalized[index], normalized[index + 1])
        for index in range(1, len(normalized) - 1)
    )
    return signed_double_area != 0.0


def _clip_axis(
    polygon: Sequence[tuple[float, float]],
    *,
    axis: int,
    bound: float,
    keep_greater: bool,
) -> tuple[tuple[float, float], ...]:
    if not polygon:
        return ()
    output: list[tuple[float, float]] = []

    def inside(point: tuple[float, float]) -> bool:
        return point[axis] >= bound if keep_greater else point[axis] <= bound

    previous = polygon[-1]
    previous_inside = inside(previous)
    for current in polygon:
        current_inside = inside(current)
        if current_inside != previous_inside:
            denominator = current[axis] - previous[axis]
            if denominator != 0.0:
                ratio = (bound - previous[axis]) / denominator
                output.append(
                    (
                        previous[0] + ratio * (current[0] - previous[0]),
                        previous[1] + ratio * (current[1] - previous[1]),
                    )
                )
        if current_inside:
            output.append(current)
        previous = current
        previous_inside = current_inside
    return tuple(output)


def _clip_rectangle(
    polygon: Sequence[tuple[float, float]],
    bounds: tuple[float, float, float, float],
) -> tuple[tuple[float, float], ...]:
    u_min, u_max, v_min, v_max = bounds
    result = tuple(polygon)
    for axis, bound, keep_greater in (
        (0, u_min, True),
        (0, u_max, False),
        (1, v_min, True),
        (1, v_max, False),
    ):
        result = _clip_axis(
            result,
            axis=axis,
            bound=bound,
            keep_greater=keep_greater,
        )
    return result


def _signed_polygon_area_2d(points: Sequence[tuple[float, float]]) -> float:
    if len(points) < 3:
        return 0.0
    origin = points[0]
    return 0.5 * math.fsum(
        _cross_2d(
            _vector_subtract_2d(points[index], origin),
            _vector_subtract_2d(points[index + 1], origin),
        )
        for index in range(1, len(points) - 1)
    )


def _cross_2d(first: tuple[float, float], second: tuple[float, float]) -> float:
    return first[0] * second[1] - first[1] * second[0]


def _oriented_convex_polygon(
    points: Sequence[tuple[float, float]],
) -> tuple[tuple[float, float], ...]:
    values = tuple(points)
    signed_area = _signed_polygon_area_2d(values)
    if signed_area == 0.0:
        raise FrozenTraceError("trace polygon has zero projected area")
    oriented = values if signed_area > 0.0 else tuple(reversed(values))
    signs: set[int] = set()
    for index, current in enumerate(oriented):
        first = _vector_subtract_2d(
            oriented[(index + 1) % len(oriented)],
            current,
        )
        second = _vector_subtract_2d(
            oriented[(index + 2) % len(oriented)],
            oriented[(index + 1) % len(oriented)],
        )
        cross = _cross_2d(first, second)
        if cross != 0.0:
            signs.add(1 if cross > 0.0 else -1)
    if signs != {1}:
        raise FrozenTraceError("trace polygon must be convex and consistently ordered")
    return oriented


def _vector_subtract_2d(
    first: tuple[float, float], second: tuple[float, float]
) -> tuple[float, float]:
    return (first[0] - second[0], first[1] - second[1])


def _convex_hull_2d(
    points: Sequence[tuple[float, float]],
) -> tuple[tuple[float, float], ...]:
    values = tuple(sorted(set(points)))
    if len(values) < 3:
        return values

    def turn(
        first: tuple[float, float],
        second: tuple[float, float],
        third: tuple[float, float],
    ) -> float:
        return _cross_2d(
            _vector_subtract_2d(second, first),
            _vector_subtract_2d(third, second),
        )

    lower: list[tuple[float, float]] = []
    for point in values:
        while len(lower) >= 2 and turn(lower[-2], lower[-1], point) <= 0.0:
            lower.pop()
        lower.append(point)
    upper: list[tuple[float, float]] = []
    for point in reversed(values):
        while len(upper) >= 2 and turn(upper[-2], upper[-1], point) <= 0.0:
            upper.pop()
        upper.append(point)
    return tuple(lower[:-1] + upper[:-1])


def _element_edges(gmsh_type: int) -> tuple[tuple[int, int], ...]:
    specification = ELEMENT_SPECS.get(gmsh_type)
    if specification is None:
        raise FrozenTraceError("frozen mesh contains an unsupported element kind")
    # Use every vertex pair, not just topology edges.  For a warped
    # isoparametric HEX/WEDGE/PYRAMID this clips the vertex convex hull, a
    # conservative over-approximation of the target-side cap.  It may reject a
    # badly warped but disjoint cell; it cannot miss a real overlap merely
    # because a bilinear face bows between topology edges.
    node_count = specification[1]
    return tuple(
        (first, second)
        for first in range(node_count)
        for second in range(first + 1, node_count)
    )


def _target_side_projection(
    local_points: Sequence[tuple[float, float, float]],
    *,
    gmsh_type: int,
    spec: _FaceSpec,
    plane: float,
) -> tuple[tuple[float, float], ...]:
    signed = tuple(
        spec.sign * (point[spec.axis] - plane) for point in local_points
    )
    clipped_points: list[tuple[float, float, float]] = [
        point for point, value in zip(local_points, signed) if value <= 0.0
    ]
    for first_index, second_index in _element_edges(gmsh_type):
        first_side = signed[first_index]
        second_side = signed[second_index]
        if not (
            (first_side < 0.0 < second_side)
            or (second_side < 0.0 < first_side)
        ):
            continue
        ratio = first_side / (first_side - second_side)
        first = local_points[first_index]
        second = local_points[second_index]
        clipped_points.append(
            tuple(
                first[axis] + ratio * (second[axis] - first[axis])
                for axis in range(3)
            )  # type: ignore[arg-type]
        )
    return _convex_hull_2d(
        tuple(
            (point[spec.u_axis], point[spec.v_axis])
            for point in clipped_points
        )
    )


def _lower_dimensional_intersects_rectangle(
    points: Sequence[tuple[float, float]],
    bounds: tuple[float, float, float, float],
    *,
    tolerance: float,
) -> bool:
    if not points:
        return False
    expanded = (
        bounds[0] - tolerance,
        bounds[1] + tolerance,
        bounds[2] - tolerance,
        bounds[3] + tolerance,
    )

    def point_inside(point: tuple[float, float]) -> bool:
        return (
            expanded[0] <= point[0] <= expanded[1]
            and expanded[2] <= point[1] <= expanded[3]
        )

    if any(point_inside(point) for point in points):
        return True
    for index, first in enumerate(points):
        second = points[(index + 1) % len(points)]
        direction = _vector_subtract_2d(second, first)
        lower = 0.0
        upper = 1.0
        for axis, minimum, maximum in (
            (0, expanded[0], expanded[1]),
            (1, expanded[2], expanded[3]),
        ):
            if direction[axis] == 0.0:
                if first[axis] < minimum or first[axis] > maximum:
                    lower, upper = 1.0, 0.0
                    break
                continue
            first_parameter = (minimum - first[axis]) / direction[axis]
            second_parameter = (maximum - first[axis]) / direction[axis]
            lower = max(lower, min(first_parameter, second_parameter))
            upper = min(upper, max(first_parameter, second_parameter))
            if lower > upper:
                break
        if lower <= upper:
            return True
    return False


def _line_intersection_2d(
    first: tuple[float, float],
    second: tuple[float, float],
    clip_first: tuple[float, float],
    clip_second: tuple[float, float],
) -> tuple[float, float]:
    direction = _vector_subtract_2d(second, first)
    clip_direction = _vector_subtract_2d(clip_second, clip_first)
    denominator = _cross_2d(direction, clip_direction)
    if denominator == 0.0:
        return second
    ratio = _cross_2d(
        _vector_subtract_2d(clip_first, first),
        clip_direction,
    ) / denominator
    return (
        first[0] + ratio * direction[0],
        first[1] + ratio * direction[1],
    )


def _point_on_segment_parameter(
    point: tuple[float, float],
    first: tuple[float, float],
    second: tuple[float, float],
    *,
    tolerance: float,
) -> float | None:
    direction = _vector_subtract_2d(second, first)
    length_squared = direction[0] ** 2 + direction[1] ** 2
    if length_squared == 0.0:
        raise FrozenTraceError("trace boundary contains a zero-length edge")
    offset = _vector_subtract_2d(point, first)
    length = math.sqrt(length_squared)
    if abs(_cross_2d(direction, offset)) > tolerance * length:
        return None
    parameter = (
        direction[0] * offset[0] + direction[1] * offset[1]
    ) / length_squared
    endpoint_tolerance = tolerance / length
    if parameter < -endpoint_tolerance or parameter > 1.0 + endpoint_tolerance:
        return None
    return parameter


def _segments_have_forbidden_intersection(
    first: tuple[float, float],
    second: tuple[float, float],
    third: tuple[float, float],
    fourth: tuple[float, float],
    *,
    tolerance: float,
) -> bool:
    first_length = math.dist(first, second)
    second_length = math.dist(third, fourth)
    if first_length == 0.0 or second_length == 0.0:
        raise FrozenTraceError("trace boundary contains a zero-length edge")
    for point, edge_first, edge_second, edge_length in (
        (first, third, fourth, second_length),
        (second, third, fourth, second_length),
        (third, first, second, first_length),
        (fourth, first, second, first_length),
    ):
        parameter = _point_on_segment_parameter(
            point,
            edge_first,
            edge_second,
            tolerance=tolerance,
        )
        if parameter is None:
            continue
        margin = tolerance / edge_length
        if margin < parameter < 1.0 - margin:
            return True

    first_direction = _vector_subtract_2d(second, first)
    second_direction = _vector_subtract_2d(fourth, third)
    first_crosses = (
        _cross_2d(first_direction, _vector_subtract_2d(third, first)),
        _cross_2d(first_direction, _vector_subtract_2d(fourth, first)),
    )
    second_crosses = (
        _cross_2d(second_direction, _vector_subtract_2d(first, third)),
        _cross_2d(second_direction, _vector_subtract_2d(second, third)),
    )
    return (
        (
            (first_crosses[0] < 0.0 < first_crosses[1])
            or (first_crosses[1] < 0.0 < first_crosses[0])
        )
        and (
            (second_crosses[0] < 0.0 < second_crosses[1])
            or (second_crosses[1] < 0.0 < second_crosses[0])
        )
        and min(abs(value) for value in first_crosses) > tolerance * first_length
        and min(abs(value) for value in second_crosses) > tolerance * second_length
    )


def _require_compatible_trace_boundaries(
    first_polygon: Sequence[tuple[float, float]],
    first_cycle: Sequence[int],
    second_polygon: Sequence[tuple[float, float]],
    second_cycle: Sequence[int],
    *,
    tolerance: float,
) -> None:
    for first_index, first_start in enumerate(first_polygon):
        first_end = first_polygon[(first_index + 1) % len(first_polygon)]
        first_tags = (
            first_cycle[first_index],
            first_cycle[(first_index + 1) % len(first_cycle)],
        )
        first_key = tuple(
            sorted(first_tags)
        )
        for second_index, second_start in enumerate(second_polygon):
            second_end = second_polygon[(second_index + 1) % len(second_polygon)]
            second_tags = (
                second_cycle[second_index],
                second_cycle[(second_index + 1) % len(second_cycle)],
            )
            second_key = tuple(
                sorted(second_tags)
            )
            if first_key == second_key:
                continue
            for first_point, first_tag in zip(
                (first_start, first_end),
                first_tags,
            ):
                for second_point, second_tag in zip(
                    (second_start, second_end),
                    second_tags,
                ):
                    if (
                        first_tag != second_tag
                        and math.dist(first_point, second_point) <= tolerance
                    ):
                        raise FrozenTraceError(
                            "locked trace contains a sub-resolution overlap or "
                            "distinct endpoints inside the roundoff ambiguity band"
                        )
            if _segments_have_forbidden_intersection(
                first_start,
                first_end,
                second_start,
                second_end,
                tolerance=tolerance,
            ):
                raise FrozenTraceError(
                    "locked trace contains a hanging node, partial-edge junction, "
                    "or boundary overlap"
                )


def _convex_intersection_polygon(
    first: Sequence[tuple[float, float]],
    second: Sequence[tuple[float, float]],
) -> tuple[tuple[float, float], ...]:
    result = _oriented_convex_polygon(first)
    clip = _oriented_convex_polygon(second)
    for index, clip_first in enumerate(clip):
        clip_second = clip[(index + 1) % len(clip)]
        if not result:
            return ()
        output: list[tuple[float, float]] = []
        previous = result[-1]
        previous_inside = _cross_2d(
            _vector_subtract_2d(clip_second, clip_first),
            _vector_subtract_2d(previous, clip_first),
        ) >= 0.0
        for current in result:
            current_inside = _cross_2d(
                _vector_subtract_2d(clip_second, clip_first),
                _vector_subtract_2d(current, clip_first),
            ) >= 0.0
            if current_inside != previous_inside:
                output.append(
                    _line_intersection_2d(
                        previous,
                        current,
                        clip_first,
                        clip_second,
                    )
                )
            if current_inside:
                output.append(current)
            previous = current
            previous_inside = current_inside
        result = tuple(output)
    return result


def _point_to_segment_distance_2d(
    point: tuple[float, float],
    first: tuple[float, float],
    second: tuple[float, float],
) -> float:
    direction = _vector_subtract_2d(second, first)
    length_squared = direction[0] ** 2 + direction[1] ** 2
    if length_squared == 0.0:
        return math.dist(point, first)
    offset = _vector_subtract_2d(point, first)
    parameter = (
        direction[0] * offset[0] + direction[1] * offset[1]
    ) / length_squared
    parameter = min(1.0, max(0.0, parameter))
    closest = (
        first[0] + parameter * direction[0],
        first[1] + parameter * direction[1],
    )
    return math.dist(point, closest)


def _intersection_is_one_shared_edge_roundoff(
    first_polygon: Sequence[tuple[float, float]],
    first_cycle: Sequence[int],
    second_polygon: Sequence[tuple[float, float]],
    second_cycle: Sequence[int],
    intersections: Sequence[Sequence[tuple[float, float]]],
    *,
    tolerance: float,
) -> bool:
    if (
        len(first_polygon) != len(first_cycle)
        or len(second_polygon) != len(second_cycle)
    ):
        raise FrozenTraceError("trace boundary metadata is incomplete")

    def edge_keys(cycle: Sequence[int]) -> set[tuple[int, int]]:
        return {
            tuple(sorted((cycle[index], cycle[(index + 1) % len(cycle)])))
            for index in range(len(cycle))
        }

    shared_keys = edge_keys(first_cycle).intersection(edge_keys(second_cycle))
    points = tuple(point for polygon in intersections for point in polygon)
    if len(shared_keys) != 1 or not points:
        return False
    shared_key = next(iter(shared_keys))
    first_by_tag = dict(zip(first_cycle, first_polygon))
    second_by_tag = dict(zip(second_cycle, second_polygon))
    if any(
        tag not in first_by_tag
        or tag not in second_by_tag
        or math.dist(first_by_tag[tag], second_by_tag[tag]) > tolerance
        for tag in shared_key
    ):
        return False
    first, second = (first_by_tag[tag] for tag in shared_key)
    if math.dist(first, second) == 0.0:
        return False
    # The roundoff capsule of one segment is convex.  Both convex clipping
    # orders must stay inside that same exact source-edge capsule; this proves
    # the apparent positive strip is only a winding/order roundoff artifact.
    return all(
        _point_to_segment_distance_2d(point, first, second) <= tolerance
        for point in points
    )


def _face_plane_and_bounds(
    box: CanonicalBox, spec: _FaceSpec
) -> tuple[float, tuple[float, float, float, float]]:
    minimum = box.origin_xyz_mm
    maximum = tuple(minimum[index] + box.size_xyz_mm[index] for index in range(3))
    plane = minimum[spec.axis] if spec.sign < 0.0 else maximum[spec.axis]
    return plane, (
        minimum[spec.u_axis],
        maximum[spec.u_axis],
        minimum[spec.v_axis],
        maximum[spec.v_axis],
    )


def _face_uv_to_local(
    spec: _FaceSpec,
    plane: float,
    point: tuple[float, float],
) -> tuple[float, float, float]:
    result = [0.0, 0.0, 0.0]
    result[spec.axis] = plane
    result[spec.u_axis] = point[0]
    result[spec.v_axis] = point[1]
    return tuple(result)  # type: ignore[return-value]


def _point_on_segment_3d(
    point: Sequence[float],
    first: Sequence[float],
    second: Sequence[float],
    *,
    tolerance: float,
) -> bool:
    direction = _vector_subtract(second, first)
    length_squared = _dot(direction, direction)
    if length_squared == 0.0:
        return math.dist(point, first) <= tolerance
    parameter = _dot(_vector_subtract(point, first), direction) / length_squared
    margin = tolerance / math.sqrt(length_squared)
    if parameter < -margin or parameter > 1.0 + margin:
        return False
    closest = tuple(
        first[index] + parameter * direction[index] for index in range(3)
    )
    return math.dist(point, closest) <= tolerance


def _zero_contact_follows_trace_boundary(
    contact: Sequence[tuple[float, float, float]],
    contact_facet: _ExteriorFacet,
    *,
    boundary_edge_by_key: Mapping[
        tuple[int, int],
        tuple[tuple[float, float, float], tuple[float, float, float]],
    ],
    tolerance: float,
) -> bool:
    contact_edge_keys = {
        tuple(
            sorted(
                (
                    contact_facet.cycle[index],
                    contact_facet.cycle[(index + 1) % len(contact_facet.cycle)],
                )
            )
        )
        for index in range(len(contact_facet.cycle))
    }
    boundary_edges = tuple(
        boundary_edge_by_key[key]
        for key in contact_edge_keys
        if key in boundary_edge_by_key
    )
    if not boundary_edges or not contact:
        return False

    def point_on_boundary(point: tuple[float, float, float]) -> bool:
        return any(
            _point_on_segment_3d(
                point,
                first,
                second,
                tolerance=tolerance,
            )
            for first, second in boundary_edges
        )

    def segment_covered_by_boundary(
        first: tuple[float, float, float],
        second: tuple[float, float, float],
    ) -> bool:
        direction = _vector_subtract(second, first)
        length_squared = _dot(direction, direction)
        if length_squared == 0.0:
            return point_on_boundary(first)
        length = math.sqrt(length_squared)
        margin = tolerance / length
        intervals: list[tuple[float, float]] = []
        for edge_first, edge_second in boundary_edges:
            parameters: list[float] = []
            collinear = True
            for point in (edge_first, edge_second):
                parameter = (
                    _dot(_vector_subtract(point, first), direction)
                    / length_squared
                )
                closest = tuple(
                    first[axis] + parameter * direction[axis]
                    for axis in range(3)
                )
                if math.dist(point, closest) > tolerance:
                    collinear = False
                    break
                parameters.append(parameter)
            if not collinear:
                continue
            start = max(0.0, min(parameters))
            end = min(1.0, max(parameters))
            if end >= start:
                intervals.append((start, end))
        if not intervals:
            return False
        covered_until = 0.0
        for start, end in sorted(intervals):
            if start > covered_until + margin:
                return False
            covered_until = max(covered_until, end)
            if covered_until >= 1.0 - margin:
                return True
        return False

    for index, first in enumerate(contact):
        second = contact[(index + 1) % len(contact)]
        if not segment_covered_by_boundary(first, second):
            return False
    return True


def _point_to_segment_distance_3d(
    point: Sequence[float],
    first: Sequence[float],
    second: Sequence[float],
) -> float:
    direction = _vector_subtract(second, first)
    length_squared = _dot(direction, direction)
    if length_squared == 0.0:
        return math.dist(point, first)
    parameter = _dot(_vector_subtract(point, first), direction) / length_squared
    parameter = min(1.0, max(0.0, parameter))
    closest = tuple(
        first[index] + parameter * direction[index] for index in range(3)
    )
    return math.dist(point, closest)


def _near_zero_contact_follows_one_trace_edge(
    contact: Sequence[tuple[float, float, float]],
    contact_facet: _ExteriorFacet,
    *,
    boundary_edge_by_key: Mapping[
        tuple[int, int],
        tuple[tuple[float, float, float], tuple[float, float, float]],
    ],
    tolerance: float,
) -> tuple[int, int] | None:
    contact_edge_keys = {
        tuple(
            sorted(
                (
                    contact_facet.cycle[index],
                    contact_facet.cycle[(index + 1) % len(contact_facet.cycle)],
                )
            )
        )
        for index in range(len(contact_facet.cycle))
    }
    shared_keys = tuple(
        key for key in contact_edge_keys if key in boundary_edge_by_key
    )
    if len(shared_keys) != 1 or not contact:
        return None
    key = shared_keys[0]
    first, second = boundary_edge_by_key[key]
    if math.dist(first, second) == 0.0:
        return None
    # A segment capsule is convex.  The clipped polygon is convex too, so
    # checking every vertex proves its complete area and perimeter remain in
    # the same exact trace-edge roundoff tube.  The clamped projection avoids
    # independently granting axial and radial endpoint margins.
    if any(
        _point_to_segment_distance_3d(point, first, second) > tolerance
        for point in contact
    ):
        return None
    return key


def _deferred_contact_is_roundoff_edge_trace(
    candidate: _DeferredNearZeroContact,
    *,
    accepted_face: TargetBoxFace,
    boundary_edge_by_key: Mapping[
        tuple[int, int],
        tuple[tuple[float, float, float], tuple[float, float, float]],
    ],
    tolerance: float,
) -> bool:
    if (
        candidate.target_face is accepted_face
        or candidate.plane_deviation_mm > tolerance
    ):
        return False
    shared_key = _near_zero_contact_follows_one_trace_edge(
        candidate.contact_local,
        candidate.facet,
        boundary_edge_by_key=boundary_edge_by_key,
        tolerance=tolerance,
    )
    if shared_key is None:
        return False
    shared_nodes = set(shared_key)
    bounds = candidate.target_bounds_uv
    for tag, point in zip(
        candidate.facet.cycle,
        candidate.target_polygon_uv,
    ):
        if tag in shared_nodes:
            continue
        if not (
            point[0] < bounds[0] - tolerance
            or point[0] > bounds[1] + tolerance
            or point[1] < bounds[2] - tolerance
            or point[1] > bounds[3] + tolerance
        ):
            return False
    return True


def _trace_boundary_edges(
    accepted: Sequence[_AcceptedFacet],
    *,
    spec: _FaceSpec,
    box: CanonicalBox,
) -> Mapping[
    tuple[int, int],
    tuple[tuple[float, float, float], tuple[float, float, float]],
]:
    plane, _ = _face_plane_and_bounds(box, spec)
    edge_owners: dict[
        tuple[int, int],
        list[tuple[tuple[float, float, float], tuple[float, float, float]]],
    ] = {}
    for value in accepted:
        cycle = value.facet.cycle
        polygon = value.target_polygon_uv
        for index, first_tag in enumerate(cycle):
            second_index = (index + 1) % len(cycle)
            key = tuple(sorted((first_tag, cycle[second_index])))
            edge_owners.setdefault(key, []).append(
                (
                    _face_uv_to_local(spec, plane, polygon[index]),
                    _face_uv_to_local(spec, plane, polygon[second_index]),
                )
            )
    return {
        key: owners[0] for key, owners in edge_owners.items() if len(owners) == 1
    }


def _noncoplanar_zero_contact(
    local_points: Sequence[tuple[float, float, float]],
    *,
    spec: _FaceSpec,
    plane: float,
    bounds: tuple[float, float, float, float],
    tolerance: float,
) -> tuple[tuple[float, float, float], ...]:
    near_plane = tuple(
        point
        for point in local_points
        if abs(point[spec.axis] - plane) <= tolerance
    )
    if not near_plane:
        return ()
    projected = tuple(
        (point[spec.u_axis], point[spec.v_axis]) for point in near_plane
    )
    if len(projected) == 1:
        point = projected[0]
        if not (
            bounds[0] - tolerance <= point[0] <= bounds[1] + tolerance
            and bounds[2] - tolerance <= point[1] <= bounds[3] + tolerance
        ):
            return ()
        clipped = projected
    else:
        clipped = _clip_rectangle(projected, bounds)
        if not clipped:
            return ()
    return tuple(_face_uv_to_local(spec, plane, point) for point in clipped)


def _element_component_map(
    snapshot: FrozenSourceSnapshot,
) -> Mapping[int, tuple[str, str]]:
    result: dict[int, tuple[str, str]] = {}
    for local_id, component in snapshot.components.items():
        for element_tag in component.element_tags:
            if element_tag in result:
                raise FrozenTraceError(
                    f"frozen element {element_tag} belongs to multiple Components"
                )
            result[element_tag] = (local_id, component.global_component_id)
    actual = {element.tag for element in snapshot.mesh.elements}
    if set(result) != actual:
        raise FrozenTraceError("frozen Component partition does not cover the mesh")
    return result


def _preflight_trace_resources(
    snapshot: FrozenSourceSnapshot,
    controls: FrozenTraceControls,
) -> int:
    """Reject oversized work before constructing any full-size lookup table."""

    volume_face_count = 0
    for element in snapshot.mesh.elements:
        specification = ELEMENT_SPECS.get(element.gmsh_type)
        if specification is None:
            raise FrozenTraceError("frozen mesh contains an unsupported element kind")
        volume_face_count += len(specification[2])
        if volume_face_count > controls.maximum_volume_face_count:
            raise FrozenTraceError(
                "frozen volume face count exceeds the trace resource limit: "
                f"{volume_face_count} > {controls.maximum_volume_face_count}"
            )
    # Conservative incremental Python-object budget for the two node maps,
    # Component map and face-incidence table.  Exterior DTOs are budgeted in a
    # second stage once their exact count is known.
    estimated_bytes = (
        len(snapshot.mesh.nodes) * 512
        + len(snapshot.mesh.elements) * 256
        + volume_face_count * 512
    )
    if estimated_bytes > controls.maximum_estimated_working_bytes:
        raise FrozenTraceError(
            "trace working-set estimate exceeds the resource limit: "
            f"{estimated_bytes} > {controls.maximum_estimated_working_bytes} bytes"
        )
    return volume_face_count


def _exterior_facets(
    snapshot: FrozenSourceSnapshot,
    *,
    source_component_id: str,
    distance_tolerance: float,
    controls: FrozenTraceControls,
) -> tuple[_ExteriorFacet, ...]:
    _preflight_trace_resources(snapshot, controls)
    node_by_tag = snapshot.mesh.node_map()
    component_by_element = _element_component_map(snapshot)
    package_coordinate_owner: dict[tuple[float, float, float], int] = {}
    for node in snapshot.mesh.nodes:
        package_point = _frozen_to_package(node.coordinates, snapshot)
        previous = package_coordinate_owner.setdefault(package_point, node.tag)
        if previous != node.tag:
            raise FrozenTraceError(
                "frozen source contains coincident nodes with different tags"
            )

    owners: dict[
        tuple[int, ...], tuple[VolumeElement, int, tuple[int, ...]] | None
    ] = {}
    for element in snapshot.mesh.elements:
        specification = ELEMENT_SPECS[element.gmsh_type]
        for face_index, local_face in enumerate(specification[2]):
            cycle = tuple(element.node_tags[index] for index in local_face)
            key = tuple(sorted(cycle))
            previous = owners.get(key)
            if key not in owners:
                owners[key] = (element, face_index, cycle)
                continue
            if previous is None:
                raise FrozenTraceError(
                    "frozen source contains a non-manifold volume face"
                )
            previous_element, _previous_index, previous_cycle = previous
            face_points = tuple(
                node_by_tag[tag].coordinates for tag in previous_cycle
            )
            normal = _polygon_area_vector(face_points)
            face_centroid = _centroid(face_points)
            previous_centroid = _centroid(
                tuple(
                    node_by_tag[tag].coordinates
                    for tag in previous_element.node_tags
                )
            )
            current_centroid = _centroid(
                tuple(node_by_tag[tag].coordinates for tag in element.node_tags)
            )
            first_side = _dot(
                normal,
                _vector_subtract(previous_centroid, face_centroid),
            )
            second_side = _dot(
                normal,
                _vector_subtract(current_centroid, face_centroid),
            )
            if not (
                (first_side < 0.0 < second_side)
                or (second_side < 0.0 < first_side)
            ):
                raise FrozenTraceError(
                    "two frozen face owners do not lie on opposite sides"
                )
            owners[key] = None

    exterior_count = sum(value is not None for value in owners.values())
    if exterior_count > controls.maximum_exterior_face_count:
        raise FrozenTraceError(
            "frozen exterior face count exceeds the trace resource limit: "
            f"{exterior_count} > {controls.maximum_exterior_face_count}"
        )
    peak_estimated_bytes = (
        len(snapshot.mesh.nodes) * 512
        + len(snapshot.mesh.elements) * 256
        + len(owners) * 512
        + exterior_count * 1_536
    )
    if peak_estimated_bytes > controls.maximum_estimated_working_bytes:
        raise FrozenTraceError(
            "trace exterior working-set estimate exceeds the resource limit: "
            f"{peak_estimated_bytes} > "
            f"{controls.maximum_estimated_working_bytes} bytes"
        )

    exterior: list[_ExteriorFacet] = []
    for value in owners.values():
        if value is None:
            continue
        element, local_face_index, raw_cycle = value
        local_id, global_id = component_by_element[element.tag]
        source_coordinates = tuple(node_by_tag[tag].coordinates for tag in raw_cycle)
        package_coordinates = tuple(
            _frozen_to_package(point, snapshot) for point in source_coordinates
        )
        if len(set(package_coordinates)) != len(package_coordinates):
            raise FrozenTraceError("frozen exterior facet has duplicate coordinates")
        area_vector = _polygon_area_vector(source_coordinates)
        area = _norm(area_vector)
        if not math.isfinite(area) or area <= distance_tolerance**2:
            raise FrozenTraceError("frozen exterior facet has zero or ambiguous area")
        source_normal = tuple(value / area for value in area_vector)
        face_centroid = _centroid(source_coordinates)
        element_points = tuple(
            node_by_tag[tag].coordinates for tag in element.node_tags
        )
        owner_direction = _vector_subtract(_centroid(element_points), face_centroid)
        orientation = _dot(source_normal, owner_direction)
        if abs(orientation) <= distance_tolerance:
            raise FrozenTraceError("frozen exterior facet orientation is ambiguous")
        cycle = raw_cycle
        if orientation > 0.0:
            cycle = tuple(reversed(raw_cycle))
            source_coordinates = tuple(node_by_tag[tag].coordinates for tag in cycle)
            package_coordinates = tuple(
                _frozen_to_package(point, snapshot) for point in source_coordinates
            )
            area_vector = _polygon_area_vector(source_coordinates)
            area = _norm(area_vector)
            source_normal = tuple(value / area for value in area_vector)
        package_normal = _matvec(snapshot.placement.rotation_matrix, source_normal)
        exterior.append(
            _ExteriorFacet(
                cycle,
                element,
                local_id,
                global_id,
                local_face_index,
                source_coordinates,
                package_coordinates,
                package_normal,
                source_normal,
                area,
            )
        )
    return tuple(exterior)


def _resolved_tolerance(
    snapshot: FrozenSourceSnapshot,
    box: CanonicalBox,
    placement: CanonicalRigidPlacement,
    controls: FrozenTraceControls,
    *,
    source_component_id: str,
) -> FrozenTraceToleranceEvidence:
    if any(
        box.origin_xyz_mm[index] + box.size_xyz_mm[index]
        == box.origin_xyz_mm[index]
        for index in range(3)
    ):
        raise FrozenTraceError(
            "target Box is poorly conditioned and loses an axis at its coordinate "
            "scale"
        )
    scale = max(1.0, _norm(box.size_xyz_mm))
    requested_distance = max(
        controls.minimum_distance_mm,
        controls.relative_distance * scale,
    )
    node_by_tag = snapshot.mesh.node_map()
    inverse = _transpose(_generated_rotation(placement))
    maximum_operation_magnitude = max(
        1.0,
        *(abs(value) for value in snapshot.placement.translation_xyz_mm),
        *(abs(value) for value in placement.translation_xyz_mm),
        *(abs(value) for value in placement.pivot_xyz_mm),
        *(abs(value) for value in box.origin_xyz_mm),
        *(
            abs(box.origin_xyz_mm[index] + box.size_xyz_mm[index])
            for index in range(3)
        ),
    )
    for tag in snapshot.components[source_component_id].node_tags:
        source_point = node_by_tag[tag].coordinates
        package_point = _frozen_to_package(source_point, snapshot)
        target_local_point = _source_to_generated_local(
            source_point,
            snapshot,
            placement,
            inverse,
        )
        maximum_operation_magnitude = max(
            maximum_operation_magnitude,
            *(abs(value) for value in source_point),
            *(abs(value) for value in package_point),
            *(abs(value) for value in target_local_point),
        )
    operation_roundoff = controls.ulp_multiplier * math.ulp(
        maximum_operation_magnitude
    )
    if operation_roundoff > requested_distance:
        raise FrozenTraceError(
            "trace placement or target geometry is poorly conditioned at its "
            "coordinate scale"
        )
    roundoff = max(
        controls.minimum_distance_mm,
        controls.ulp_multiplier * math.ulp(scale),
        operation_roundoff,
    )
    distance = max(requested_distance, roundoff)
    return FrozenTraceToleranceEvidence(
        _TRACE_PROFILE,
        scale,
        distance,
        roundoff,
        controls.relative_area,
        controls.normal_dot_tolerance,
    )


def _target_box(
    generated: CompiledGeneratedInstance,
    component_id: str,
) -> tuple[str, str, CanonicalBox, CanonicalRigidPlacement]:
    descriptor = generated.component_by_local_id.get(component_id)
    if descriptor is None:
        raise FrozenTraceError(
            f"generated Component {component_id!r} is not in the target instance"
        )
    geometries = {
        component.component_id: component
        for component in generated.geometry_result.geometry.components
    }
    geometry = geometries.get(component_id)
    if geometry is None or len(geometry.fragments) != 1:
        raise FrozenTraceError(
            "trace resolver currently requires one target geometry fragment"
        )
    fragment = geometry.fragments[0]
    if type(fragment.root) is not CanonicalBox:
        raise FrozenTraceError("trace resolver currently requires one target Box")
    if fragment.placement != generated.placement:
        raise FrozenTraceError("target placement is inconsistent across the instance")
    return (
        descriptor.global_component_id,
        fragment.fragment_id,
        fragment.root,
        fragment.placement,
    )


def _classify_facets(
    exterior: Sequence[_ExteriorFacet],
    *,
    snapshot: FrozenSourceSnapshot,
    source_component_id: str,
    box: CanonicalBox,
    placement: CanonicalRigidPlacement,
    tolerance: FrozenTraceToleranceEvidence,
    controls: FrozenTraceControls,
) -> tuple[tuple[_AcceptedFacet, ...], _FaceSpec]:
    rotation = _generated_rotation(placement)
    inverse = _transpose(rotation)
    accepted: list[_AcceptedFacet] = []
    zero_area_contacts: list[
        tuple[_ExteriorFacet, tuple[tuple[float, float, float], ...]]
    ] = []
    deferred_near_zero_contacts: list[_DeferredNearZeroContact] = []
    for facet in exterior:
        if facet.owner_component_local_id != source_component_id:
            continue
        local_points = tuple(
            _source_to_generated_local(
                point,
                snapshot,
                placement,
                inverse,
            )
            for point in facet.source_coordinates
        )
        local_normal = _matvec(inverse, facet.package_normal)
        for spec in _FACE_SPECS:
            plane, bounds = _face_plane_and_bounds(box, spec)
            plane_deviation = max(
                abs(point[spec.axis] - plane) for point in local_points
            )
            if plane_deviation > tolerance.distance_mm:
                tangent_contact = _noncoplanar_zero_contact(
                    local_points,
                    spec=spec,
                    plane=plane,
                    bounds=bounds,
                    tolerance=tolerance.roundoff_mm,
                )
                if tangent_contact:
                    zero_area_contacts.append((facet, tangent_contact))
                continue
            polygon = tuple(
                (point[spec.u_axis], point[spec.v_axis]) for point in local_points
            )
            polygon_area = _polygon_area_2d(polygon)
            clipped_polygon = _clip_rectangle(polygon, bounds)
            clipped_area = _polygon_area_2d(clipped_polygon)
            area_tolerance = max(
                tolerance.distance_mm**2,
                tolerance.relative_area * max(polygon_area, clipped_area, 1.0e-300),
            )
            u_values = tuple(point[0] for point in polygon)
            v_values = tuple(point[1] for point in polygon)
            bounding_touch = (
                max(min(u_values), bounds[0])
                <= min(max(u_values), bounds[1]) + tolerance.distance_mm
                and max(min(v_values), bounds[2])
                <= min(max(v_values), bounds[3]) + tolerance.distance_mm
            )
            if bounding_touch and len(facet.cycle) == 4:
                first = facet.source_coordinates[0]
                warped = max(
                    abs(
                        _dot(
                            _vector_subtract(point, first),
                            facet.source_normal,
                        )
                    )
                    for point in facet.source_coordinates
                )
                if warped > tolerance.distance_mm:
                    raise FrozenTraceError(
                        "candidate frozen QUAD4 interface facet is warped"
                    )
            if clipped_area <= area_tolerance:
                if clipped_area == 0.0:
                    if _polygon_has_positive_area(clipped_polygon):
                        raise FrozenTraceError(
                            "target Box has an ambiguous positive-area frozen "
                            "intersection"
                        )
                    if clipped_polygon:
                        deferred_near_zero_contacts.append(
                            _DeferredNearZeroContact(
                                facet,
                                spec.face,
                                tuple(
                                    _face_uv_to_local(spec, plane, point)
                                    for point in clipped_polygon
                                ),
                                plane_deviation,
                                polygon,
                                bounds,
                                False,
                            )
                        )
                    continue
                deferred_near_zero_contacts.append(
                    _DeferredNearZeroContact(
                        facet,
                        spec.face,
                        tuple(
                            _face_uv_to_local(spec, plane, point)
                            for point in clipped_polygon
                        ),
                        plane_deviation,
                        polygon,
                        bounds,
                        True,
                    )
                )
                continue
            if polygon_area <= area_tolerance:
                raise FrozenTraceError(
                    "frozen interface facet is below the trace area resolution"
                )
            bounds_overshoot = max(
                0.0,
                *(bounds[0] - point[0] for point in polygon),
                *(point[0] - bounds[1] for point in polygon),
                *(bounds[2] - point[1] for point in polygon),
                *(point[1] - bounds[3] for point in polygon),
            )
            expected_normal = [0.0, 0.0, 0.0]
            expected_normal[spec.axis] = spec.sign
            if _dot(local_normal, expected_normal) > (
                -1.0 + tolerance.normal_dot_tolerance
            ):
                raise FrozenTraceError(
                    "frozen and target interface normals are not opposite"
                )
            if (
                abs(clipped_area - polygon_area) > area_tolerance
                or bounds_overshoot > tolerance.distance_mm
            ):
                raise FrozenTraceError(
                    "target Box boundary cuts through a frozen interface facet"
                )
            if (
                plane_deviation > tolerance.roundoff_mm
                or bounds_overshoot > tolerance.roundoff_mm
            ):
                raise FrozenTraceError(
                    "frozen interface lies in an ambiguous geometric tolerance band"
                )
            if len(accepted) >= controls.maximum_trace_facet_count:
                raise FrozenTraceError(
                    "resolved trace facet count exceeds the resource limit: "
                    f"> {controls.maximum_trace_facet_count}"
                )
            accepted.append(
                _AcceptedFacet(
                    facet,
                    spec.face,
                    polygon,
                    plane_deviation,
                    bounds_overshoot,
                )
            )
            break

    if not accepted:
        if any(value.was_positive for value in deferred_near_zero_contacts):
            raise FrozenTraceError(
                "target Box has an ambiguous positive-area frozen intersection"
            )
        if zero_area_contacts or deferred_near_zero_contacts:
            raise FrozenTraceError(
                "frozen and target Components have edge/point-only contact"
            )
        raise FrozenTraceError("frozen and target Components have no positive-area interface")
    faces = {value.target_face for value in accepted}
    if len(faces) != 1:
        raise FrozenTraceError(
            "trace resolver currently supports one target semantic Box face"
        )
    face = next(iter(faces))
    spec = next(value for value in _FACE_SPECS if value.face is face)
    boundary_edge_by_key = _trace_boundary_edges(
        accepted,
        spec=spec,
        box=box,
    )
    positive_contacts = tuple(
        value for value in deferred_near_zero_contacts if value.was_positive
    )
    if any(
        not _deferred_contact_is_roundoff_edge_trace(
            candidate,
            accepted_face=face,
            boundary_edge_by_key=boundary_edge_by_key,
            tolerance=tolerance.roundoff_mm,
        )
        for candidate in positive_contacts
    ):
        raise FrozenTraceError(
            "target Box has an ambiguous positive-area frozen intersection"
        )
    zero_area_contacts.extend(
        (candidate.facet, candidate.contact_local)
        for candidate in deferred_near_zero_contacts
        if not candidate.was_positive
        and not _deferred_contact_is_roundoff_edge_trace(
            candidate,
            accepted_face=face,
            boundary_edge_by_key=boundary_edge_by_key,
            tolerance=tolerance.roundoff_mm,
        )
    )
    if any(
        not (
            _zero_contact_follows_trace_boundary(
                contact,
                facet,
                boundary_edge_by_key=boundary_edge_by_key,
                tolerance=tolerance.roundoff_mm,
            )
            or _near_zero_contact_follows_one_trace_edge(
                contact,
                facet,
                boundary_edge_by_key=boundary_edge_by_key,
                tolerance=tolerance.roundoff_mm,
            )
            is not None
        )
        for facet, contact in zero_area_contacts
    ):
        raise FrozenTraceError(
            "frozen and target Components have additional edge/point-only contact"
        )
    return tuple(accepted), spec


def _require_embedded_trace_surface(
    exterior: Sequence[_ExteriorFacet],
    accepted: Sequence[_AcceptedFacet],
    *,
    snapshot: FrozenSourceSnapshot,
    box: CanonicalBox,
    placement: CanonicalRigidPlacement,
    spec: _FaceSpec,
    tolerance: FrozenTraceToleranceEvidence,
    controls: FrozenTraceControls,
) -> None:
    """Reject cracks/overlap, including nonconformal frozen-frozen overlays."""

    rotation = _generated_rotation(placement)
    inverse = _transpose(rotation)
    plane, bounds = _face_plane_and_bounds(box, spec)
    accepted_ids = {id(value.facet) for value in accepted}
    candidates: list[
        tuple[
            tuple[tuple[float, float], ...],
            bool,
            str,
            tuple[int, ...] | None,
        ]
    ] = [
        (
            value.target_polygon_uv,
            True,
            value.facet.owner_component_local_id,
            value.facet.cycle,
        )
        for value in accepted
    ]
    for facet in exterior:
        if id(facet) in accepted_ids:
            continue
        local_points = tuple(
            _source_to_generated_local(
                point,
                snapshot,
                placement,
                inverse,
            )
            for point in facet.source_coordinates
        )
        plane_deviation = max(
            abs(point[spec.axis] - plane) for point in local_points
        )
        if plane_deviation > tolerance.distance_mm:
            continue
        polygon = tuple(
            (point[spec.u_axis], point[spec.v_axis]) for point in local_points
        )
        clipped_polygon = _clip_rectangle(polygon, bounds)
        clipped_area = _polygon_area_2d(clipped_polygon)
        if clipped_area == 0.0:
            if _polygon_has_positive_area(clipped_polygon):
                raise FrozenTraceError(
                    "another frozen exterior facet has an ambiguous positive-area "
                    "interface intersection"
                )
            continue
        if plane_deviation > tolerance.roundoff_mm:
            raise FrozenTraceError(
                "another frozen exterior facet lies in an ambiguous interface band"
            )
        candidates.append(
            (polygon, False, facet.owner_component_local_id, facet.cycle)
        )

    indexed: list[
        tuple[
            float,
            float,
            float,
            float,
            tuple[tuple[float, float], ...],
            bool,
            str,
            tuple[int, ...] | None,
        ]
    ] = []
    for polygon, selected, component_id, cycle in candidates:
        _oriented_convex_polygon(polygon)
        u_values = tuple(point[0] for point in polygon)
        v_values = tuple(point[1] for point in polygon)
        indexed.append(
            (
                min(u_values),
                max(u_values),
                min(v_values),
                max(v_values),
                polygon,
                selected,
                component_id,
                cycle,
            )
        )
    indexed.sort(key=lambda value: (value[0], value[2], value[1], value[3]))
    active: list[
        tuple[
            float,
            float,
            float,
            float,
            tuple[tuple[float, float], ...],
            bool,
            str,
            tuple[int, ...] | None,
        ]
    ] = []
    overlap_floor = tolerance.roundoff_mm**2
    overlap_pair_checks = 0
    for current in indexed:
        active = [
            value
            for value in active
            if value[1] >= current[0] - tolerance.roundoff_mm
        ]
        overlap_pair_checks += len(active)
        if overlap_pair_checks > controls.maximum_overlap_pair_checks:
            raise FrozenTraceError(
                "trace overlap audit exceeds its resource limit: "
                f"> {controls.maximum_overlap_pair_checks}"
            )
        for previous in active:
            if not (previous[5] or current[5]):
                continue
            if (
                previous[3] < current[2] - tolerance.roundoff_mm
                or current[3] < previous[2] - tolerance.roundoff_mm
            ):
                continue
            if previous[5] or current[5]:
                if previous[7] is None or current[7] is None:
                    raise FrozenTraceError("trace boundary metadata is incomplete")
                _require_compatible_trace_boundaries(
                    previous[4],
                    previous[7],
                    current[4],
                    current[7],
                    tolerance=tolerance.roundoff_mm,
                )
            forward_intersection = _convex_intersection_polygon(
                previous[4],
                current[4],
            )
            reverse_intersection = _convex_intersection_polygon(
                current[4],
                previous[4],
            )
            intersections = (forward_intersection, reverse_intersection)
            overlap = max(
                _polygon_area_2d(intersection)
                for intersection in intersections
            )
            has_positive_rank = any(
                _polygon_has_positive_area(intersection)
                for intersection in intersections
            )
            if overlap == 0.0:
                if not has_positive_rank:
                    continue
            if _intersection_is_one_shared_edge_roundoff(
                previous[4],
                previous[7],
                current[4],
                current[7],
                intersections,
                tolerance=tolerance.roundoff_mm,
            ):
                continue
            if overlap == 0.0:
                raise FrozenTraceError(
                    "frozen trace contains an ambiguous sub-resolution overlap"
                )
            if overlap <= overlap_floor:
                raise FrozenTraceError(
                    "frozen trace contains an ambiguous sub-resolution overlap"
                )
            if previous[5] and current[5]:
                raise FrozenTraceError(
                    "frozen interface facets overlap with positive area"
                )
            raise FrozenTraceError(
                "another frozen exterior facet overlaps the resolved interface"
            )
        active.append(current)


def _require_source_outside_target(
    snapshot: FrozenSourceSnapshot,
    *,
    source_component_id: str,
    box: CanonicalBox,
    placement: CanonicalRigidPlacement,
    spec: _FaceSpec,
    tolerance: FrozenTraceToleranceEvidence,
) -> None:
    rotation = _generated_rotation(placement)
    inverse = _transpose(rotation)
    plane, bounds = _face_plane_and_bounds(box, spec)
    target_rectangle = (
        (bounds[0], bounds[2]),
        (bounds[1], bounds[2]),
        (bounds[1], bounds[3]),
        (bounds[0], bounds[3]),
    )
    node_by_tag = snapshot.mesh.node_map()
    component = snapshot.components[source_component_id]
    component_element_tags = set(component.element_tags)
    for element in snapshot.mesh.elements:
        if element.tag not in component_element_tags:
            continue
        local_points = tuple(
            _source_to_generated_local(
                node_by_tag[tag].coordinates,
                snapshot,
                placement,
                inverse,
            )
            for tag in element.node_tags
        )
        u_values = tuple(point[spec.u_axis] for point in local_points)
        v_values = tuple(point[spec.v_axis] for point in local_points)
        if (
            max(u_values) < bounds[0] - tolerance.distance_mm
            or min(u_values) > bounds[1] + tolerance.distance_mm
            or max(v_values) < bounds[2] - tolerance.distance_mm
            or min(v_values) > bounds[3] + tolerance.distance_mm
        ):
            continue
        maximum_penetration = max(
            0.0,
            *(
                -spec.sign * (point[spec.axis] - plane)
                for point in local_points
            ),
        )
        if maximum_penetration <= tolerance.roundoff_mm:
            continue
        projected_hull = _target_side_projection(
            local_points,
            gmsh_type=element.gmsh_type,
            spec=spec,
            plane=plane,
        )
        if len(projected_hull) < 3:
            if _lower_dimensional_intersects_rectangle(
                projected_hull,
                bounds,
                tolerance=tolerance.roundoff_mm,
            ):
                raise FrozenTraceError(
                    "frozen source has additional edge/point-only target contact"
                )
            continue
        projected_intersection = _convex_intersection_polygon(
            projected_hull,
            target_rectangle,
        )
        projected_overlap = _polygon_area_2d(projected_intersection)
        if projected_overlap == 0.0:
            if _polygon_has_positive_area(projected_intersection):
                raise FrozenTraceError(
                    "frozen source has an ambiguous sub-resolution target overlap"
                )
            if projected_intersection:
                raise FrozenTraceError(
                    "frozen source has additional edge/point-only target contact"
                )
            continue
        if (
            maximum_penetration <= tolerance.distance_mm
            or projected_overlap <= tolerance.distance_mm**2
        ):
            raise FrozenTraceError(
                "frozen source has an ambiguous sub-resolution target overlap"
            )
        raise FrozenTraceError(
            "frozen source crosses the target interface plane and may overlap it"
        )


def _patches(
    accepted: Sequence[_AcceptedFacet],
) -> tuple[tuple[tuple[_AcceptedFacet, ...], ...], tuple[_AcceptedFacet, ...]]:
    ordered = tuple(
        sorted(
            accepted,
            key=lambda value: (
                tuple(sorted(value.facet.cycle)),
                value.facet.owner.tag,
                value.facet.local_face_index,
            ),
        )
    )
    edge_owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for index, value in enumerate(ordered):
        cycle = value.facet.cycle
        for position, first in enumerate(cycle):
            second = cycle[(position + 1) % len(cycle)]
            edge_owners[tuple(sorted((first, second)))].append(index)
    if any(len(values) > 2 for values in edge_owners.values()):
        raise FrozenTraceError("locked trace contains a non-manifold edge")
    adjacency: dict[int, set[int]] = {index: set() for index in range(len(ordered))}
    for values in edge_owners.values():
        if len(values) == 2:
            first, second = values
            adjacency[first].add(second)
            adjacency[second].add(first)
    remaining = set(adjacency)
    components: list[tuple[int, ...]] = []
    while remaining:
        stack = [min(remaining)]
        found: set[int] = set()
        while stack:
            current = stack.pop()
            if current in found:
                continue
            found.add(current)
            stack.extend(sorted(adjacency[current].difference(found), reverse=True))
        remaining.difference_update(found)
        components.append(tuple(sorted(found)))
    components.sort(key=lambda values: tuple(sorted(ordered[values[0]].facet.cycle)))
    node_patch: dict[int, int] = {}
    for patch_index, indices in enumerate(components):
        incident_cycles: dict[int, list[tuple[int, ...]]] = defaultdict(list)
        for index in indices:
            cycle = ordered[index].facet.cycle
            for node_tag in cycle:
                previous = node_patch.setdefault(node_tag, patch_index)
                if previous != patch_index:
                    raise FrozenTraceError(
                        "locked trace patches have an unsupported point-only junction"
                    )
                incident_cycles[node_tag].append(cycle)
        for node_tag, cycles in incident_cycles.items():
            link_adjacency: dict[int, set[int]] = defaultdict(set)
            link_edges: set[tuple[int, int]] = set()
            for cycle in cycles:
                position = cycle.index(node_tag)
                previous = cycle[position - 1]
                following = cycle[(position + 1) % len(cycle)]
                edge = tuple(sorted((previous, following)))
                if edge in link_edges:
                    raise FrozenTraceError(
                        "locked trace contains a non-manifold vertex fan"
                    )
                link_edges.add(edge)
                link_adjacency[previous].add(following)
                link_adjacency[following].add(previous)
            link_nodes = set(link_adjacency)
            stack = [min(link_nodes)]
            reached: set[int] = set()
            while stack:
                current = stack.pop()
                if current in reached:
                    continue
                reached.add(current)
                stack.extend(link_adjacency[current].difference(reached))
            degrees = tuple(len(link_adjacency[value]) for value in link_nodes)
            boundary_degree_count = sum(value == 1 for value in degrees)
            if (
                reached != link_nodes
                or any(value not in (1, 2) for value in degrees)
                or boundary_degree_count not in (0, 2)
            ):
                raise FrozenTraceError(
                    "locked trace contains a non-manifold vertex fan"
                )
    grouped = tuple(tuple(ordered[index] for index in values) for values in components)
    flattened = tuple(value for group in grouped for value in group)
    return grouped, flattened


def resolve_frozen_generated_trace(
    snapshot: FrozenSourceSnapshot,
    generated: CompiledGeneratedInstance,
    *,
    frozen_component_global_id: str,
    generated_component_global_id: str,
    controls: FrozenTraceControls | None = None,
) -> LockedInterfaceTrace:
    """Resolve all complete common facets for one Component pair.

    The frozen-to-generated policy defaults to ``preserve_interface_trace``;
    callers therefore do not need to manufacture an explicit user
    ``InterfaceMatch`` merely to request the default behavior.
    """

    if type(snapshot) is not FrozenSourceSnapshot:
        raise FrozenTraceError("snapshot must be a FrozenSourceSnapshot")
    if type(generated) is not CompiledGeneratedInstance:
        raise FrozenTraceError("generated must be a CompiledGeneratedInstance")
    for field_name, value in (
        ("frozen_component_global_id", frozen_component_global_id),
        ("generated_component_global_id", generated_component_global_id),
    ):
        if not isinstance(value, str) or not value:
            raise FrozenTraceError(f"{field_name} must be a non-empty string")
    source_matches = tuple(
        (local_id, component)
        for local_id, component in snapshot.components.items()
        if component.global_component_id == frozen_component_global_id
    )
    if len(source_matches) != 1:
        raise FrozenTraceError(
            f"frozen Component {frozen_component_global_id!r} is not in the source"
        )
    frozen_component_id, source_component = source_matches[0]
    target_matches = tuple(
        descriptor
        for descriptor in generated.components
        if descriptor.global_component_id == generated_component_global_id
    )
    if len(target_matches) != 1:
        raise FrozenTraceError(
            f"generated Component {generated_component_global_id!r} is not in "
            "the target instance"
        )
    generated_component_id = target_matches[0].local_component_id
    if controls is None:
        controls = FrozenTraceControls()
    if type(controls) is not FrozenTraceControls:
        raise FrozenTraceError("controls must be FrozenTraceControls")

    target_global_id, fragment_id, box, placement = _target_box(
        generated,
        generated_component_id,
    )
    if source_component.global_component_id == target_global_id:
        raise FrozenTraceError("frozen and generated Component identities collide")
    _preflight_trace_resources(snapshot, controls)
    tolerance = _resolved_tolerance(
        snapshot,
        box,
        placement,
        controls,
        source_component_id=frozen_component_id,
    )
    exterior = _exterior_facets(
        snapshot,
        source_component_id=frozen_component_id,
        distance_tolerance=tolerance.distance_mm,
        controls=controls,
    )
    accepted, face_spec = _classify_facets(
        exterior,
        snapshot=snapshot,
        source_component_id=frozen_component_id,
        box=box,
        placement=placement,
        tolerance=tolerance,
        controls=controls,
    )
    _require_embedded_trace_surface(
        exterior,
        accepted,
        snapshot=snapshot,
        box=box,
        placement=placement,
        spec=face_spec,
        tolerance=tolerance,
        controls=controls,
    )
    _require_source_outside_target(
        snapshot,
        source_component_id=frozen_component_id,
        box=box,
        placement=placement,
        spec=face_spec,
        tolerance=tolerance,
    )
    grouped, ordered = _patches(accepted)

    facet_patch_index = {
        id(value): patch_index
        for patch_index, group in enumerate(grouped)
        for value in group
    }
    facets = tuple(
        LockedTraceFacet(
            (tuple(reversed(value.facet.cycle))
             if determinant(snapshot.placement.rotation_matrix) < 0.
             else value.facet.cycle),
            value.facet.owner.tag,
            value.facet.owner.kind,
            value.facet.local_face_index,
            value.facet.owner_component_global_id,
            value.target_face,
            facet_patch_index[id(value)],
            value.facet.package_normal,
            value.facet.area,
        )
        for value in ordered
    )
    nodes_by_tag = snapshot.mesh.node_map()
    selected_tags = tuple(
        sorted({tag for facet in facets for tag in facet.source_node_tags})
    )
    nodes = tuple(
        LockedTraceNode(
            tag,
            nodes_by_tag[tag].coordinates,
            _frozen_to_package(nodes_by_tag[tag].coordinates, snapshot),
        )
        for tag in selected_tags
    )
    patches: list[LockedTracePatch] = []
    final_index_by_id = {id(value): index for index, value in enumerate(ordered)}
    for patch_index, group in enumerate(grouped):
        indices = tuple(sorted(final_index_by_id[id(value)] for value in group))
        tags = tuple(
            sorted({tag for index in indices for tag in facets[index].source_node_tags})
        )
        patches.append(LockedTracePatch(patch_index, indices, tags))

    source_numbered_sha256 = _source_numbered_digest(
        source_id=snapshot.source_id,
        source_component_local_id=frozen_component_id,
        source_component_global_id=source_component.global_component_id,
        source_snapshot_numbered_sha256=snapshot.numbered_sha256,
        source_component_numbered_sha256=source_component.numbered_sha256,
        target_instance_id=generated.instance_id,
        target_component_local_id=generated_component_id,
        target_component_global_id=target_global_id,
        target_fragment_id=fragment_id,
        target_face=face_spec.face,
        tolerance=tolerance,
        nodes=nodes,
        facets=facets,
    )
    package_geometry_sha256 = _package_geometry_digest(nodes, facets, patches)
    maximum_plane_deviation = max(
        value.maximum_plane_deviation_mm for value in accepted
    )
    maximum_bounds_overshoot = max(
        value.maximum_bounds_overshoot_mm for value in accepted
    )
    return LockedInterfaceTrace(
        source_id=snapshot.source_id,
        source_component_local_id=frozen_component_id,
        source_component_global_id=source_component.global_component_id,
        source_snapshot_numbered_sha256=snapshot.numbered_sha256,
        source_component_numbered_sha256=source_component.numbered_sha256,
        target_instance_id=generated.instance_id,
        target_component_local_id=generated_component_id,
        target_component_global_id=target_global_id,
        target_fragment_id=fragment_id,
        target_face=face_spec.face,
        nodes=nodes,
        facets=facets,
        patches=tuple(patches),
        triangle_count=sum(len(facet.source_node_tags) == 3 for facet in facets),
        quad_count=sum(len(facet.source_node_tags) == 4 for facet in facets),
        tolerance=tolerance,
        maximum_plane_deviation_mm=maximum_plane_deviation,
        maximum_bounds_overshoot_mm=maximum_bounds_overshoot,
        source_trace_numbered_sha256=source_numbered_sha256,
        package_geometry_sha256=package_geometry_sha256,
    )


__all__ = [
    "FrozenTraceControls",
    "FrozenTraceError",
    "FrozenTraceToleranceEvidence",
    "LockedInterfaceTrace",
    "LockedTraceFacet",
    "LockedTraceNode",
    "LockedTracePatch",
    "TargetBoxFace",
    "resolve_frozen_generated_trace",
]
