"""Component → Instance → parameter editor for generated Package V2 geometry."""

from __future__ import annotations

from collections.abc import Iterable, Mapping

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QTreeWidget, QTreeWidgetItem, QTreeWidgetItemIterator

from .package_v2_preview_3d import generated_component_key
from .package_v2_source_editor import GeometryRow, SourceCell, SourceCellKind


PREVIEW_ROLE = int(Qt.ItemDataRole.UserRole) + 1
COMPLETION_ROLE = int(Qt.ItemDataRole.UserRole) + 2
TEMPLATE_ROLE = int(Qt.ItemDataRole.UserRole) + 3
COMPONENT_ROLE = int(Qt.ItemDataRole.UserRole) + 4
GEOMETRY_ROLE = int(Qt.ItemDataRole.UserRole) + 5
KEY_ROLE = int(Qt.ItemDataRole.UserRole) + 6
RECORD_ROLE = int(Qt.ItemDataRole.UserRole) + 7
OWNER_CHOICES_ROLE = int(Qt.ItemDataRole.UserRole) + 8


class PackageV2GeometryTree(QTreeWidget):
    """Stable IDs retain expansion/selection when source pointers shift."""

    moveRequested = Signal(str, str, str)

    def items(self) -> Iterable[QTreeWidgetItem]:
        iterator = QTreeWidgetItemIterator(self)
        while item := iterator.value():
            yield item
            iterator += 1

    def selected_context(self) -> tuple[str | None, str | None]:
        item = self.currentItem()
        return ((item.data(0, TEMPLATE_ROLE), item.data(0, COMPONENT_ROLE))
                if item is not None else (None, None))

    def selected_geometry(self) -> tuple[str, str] | None:
        item = self.currentItem()
        if item is None or not item.data(0, GEOMETRY_ROLE):
            return None
        return item.data(0, TEMPLATE_ROLE), item.data(0, GEOMETRY_ROLE)

    def select_geometry(self, record_pointer: str) -> None:
        for item in self.items():
            if item.data(0, RECORD_ROLE) == record_pointer:
                parent = item.parent()
                while parent is not None:
                    parent.setExpanded(True)
                    parent = parent.parent()
                self.setCurrentItem(item)
                self.scrollToItem(item)
                return

    def apply_pending_edits(self, edits: Mapping[str, str]) -> None:
        for item in self.items():
            for column in range(self.columnCount()):
                pointer = item.data(column, Qt.ItemDataRole.UserRole)
                if pointer in edits:
                    item.setText(column, edits[pointer])

    def populate(
        self, rows: Iterable[GeometryRow], *, editable: bool,
        candidates: Mapping[str, tuple[str, ...]],
    ) -> None:
        expanded = {item.data(0, KEY_ROLE): item.isExpanded() for item in self.items()}
        current = self.currentItem()
        selected = current.data(0, KEY_ROLE) if current is not None else None
        selected_column = self.currentColumn()
        scroll = self.verticalScrollBar().value()
        self.clear()
        rows = tuple(rows)
        def cell(item: QTreeWidgetItem, column: int, source: SourceCell, template: str) -> None:
            item.setText(column, source.display)
            details = [f"JSON Pointer: {source.pointer}"]
            if source.dependencies:
                details.append("Dependencies: " + ", ".join(source.dependencies))
            if editable and source.editable:
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
                item.setData(column, Qt.ItemDataRole.UserRole, source.pointer)
                font = item.font(column)
                font.setBold(True)
                item.setFont(column, font)
                details.insert(0, "双击编辑；校验通过后写入草稿。")
                if source.kind is SourceCellKind.EXPRESSION:
                    item.setData(column, COMPLETION_ROLE, candidates.get(template, ("um", "mm")))
            item.setToolTip(column, "\n".join(details))

        def node(parent, row, texts, key, geometry_id=None):
            item = QTreeWidgetItem(parent, texts)
            item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            item.setData(0, KEY_ROLE, key)
            item.setData(0, TEMPLATE_ROLE, row.template_id)
            item.setData(0, COMPONENT_ROLE, row.component_id)
            item.setData(0, GEOMETRY_ROLE, geometry_id)
            owners = tuple(dict.fromkeys(value.owner_id for value in row.resolved))
            item.setData(0, PREVIEW_ROLE, tuple(
                generated_component_key(owner, row.component_id) for owner in owners
            ))
            item.setToolTip(0, f"Template: {row.template_id}\nInstance: {', '.join(owners) or '—'}")
            return item

        components = {}
        for row in rows:
            component_key = ("component", row.component_id)
            component = components.get(row.component_id)
            if component is None:
                component = node(self, row, [row.component_id, "Component"], component_key)
                component.setData(0, TEMPLATE_ROLE, None)
                cell(component, 2, row.material, "Global")
                font = component.font(0); font.setBold(True); component.setFont(0, font)
                component.setExpanded(expanded.get(component_key, True))
                components[row.component_id] = component
            fragment = row.fragments[0]
            key = ("instance", fragment.geometry_id)
            geometry = node(component, row, [fragment.geometry_id, row.template_id, "", row.component_id], key, fragment.geometry_id)
            geometry.setData(0, RECORD_ROLE, row.pointer)
            geometry.setToolTip(3, "所属 Component；双击更改。材料和网格设置由 Component 统一维护。")
            if editable:
                geometry.setFlags(geometry.flags() | Qt.ItemFlag.ItemIsEditable)
                geometry.setData(3, OWNER_CHOICES_ROLE, tuple(dict.fromkeys(row.component_id for row in rows)))
            for leaf in fragment.leaves:
                parameter = node(geometry, row, [leaf.label], (*key, leaf.label), fragment.geometry_id)
                parameter.setData(0, RECORD_ROLE, row.pointer)
                cell(parameter, 4, leaf, "Global")
                parameter.setText(5, "; ".join(value.display for value in leaf.resolved) or "—")
            geometry.setExpanded(expanded.get(key, False))
        for item in self.items():
            if item.data(0, KEY_ROLE) == selected:
                self.setCurrentItem(item, selected_column)
                break
        self.verticalScrollBar().setValue(scroll)
