"""TET-preferred OCC Box route, with exact mixed interfaces on any axis."""

from collections import defaultdict
from dataclasses import asdict

from .gmsh_candidate_runtime import (
    CandidateExecutionError, bounded_candidate_search, run_isolated_candidate, emit_candidate_event,
)
from .gmsh_closed_shell_remainder import GmshClosedShellElement, GmshClosedShellRemainder
from .occ_locked_hybrid import ConstrainedHybridError, generate_locked_box_hybrid
from .volume_mesh import ELEMENT_SPECS


SIDES = {"x_min": (0, 0), "x_max": (0, 1), "y_min": (1, 0),
         "y_max": (1, 1), "bottom": (2, 0), "top": (2, 1)}


@bounded_candidate_search
def generate_box_tet(root, coordinates, facets_by_side, *, target_size_mm,
                     near_size_mm, transition_distance_mm, minimum_quality,
                     random_seeds, contact_partition_loops=(), verbose=False):
    """Try complete docking ends; preserve every authored partition and lock.

    A positive cyclic permutation maps each candidate normal to Z without
    reflecting cells. Native input validation proves the complete docking
    rectangle and any adjoining rectangular side patches before meshing.
    """
    errors = []
    locked = {side: tuple(tuple(f) for f in facets) for side, facets in facets_by_side.items() if facets}
    for side in ("top", "bottom", "x_max", "x_min", "y_max", "y_min"):
        if side not in locked:
            continue
        axis, upper = SIDES[side]
        opposite = next(name for name, pair in SIDES.items() if pair == (axis, 1 - upper))
        if opposite in locked:
            continue  # Two independent end locks require the closed-shell route.
        order = ((axis + 1) % 3, (axis + 2) % 3, axis)
        origin = tuple(root.origin_xyz_mm[a] for a in order)
        size = tuple(root.size_xyz_mm[a] for a in order)
        docking = locked[side]
        lateral = tuple(f for name, fs in locked.items() if name != side for f in fs)
        docking_nodes = {n for f in docking for n in f}
        lateral_nodes = {n for f in lateral for n in f}
        # Regenerating a free surface must not erase a contact partition.
        # Loops already represented by locked facet edges need no reimprint.
        locked_edges = {tuple(sorted((tuple(coordinates[a]), tuple(coordinates[b]))))
                        for fs in locked.values() for f in fs
                        for a, b in zip(f, (*f[1:], f[0]))}
        if not _loops_covered(contact_partition_loops, locked_edges):
            errors.append(f"{side}: free contact partition requires closed-shell route")
            continue
        permuted = {n: tuple(p[a] for a in order) for n, p in coordinates.items()}
        # Hybrid sizes are targets. If the authored growth produces invalid
        # cells, try a finer interior field with a bounded spatial size slope.
        # Keep both distances in evidence; never move or remesh inherited locks.
        transitions = [transition_distance_mm]
        compatible_distance = 2. * max(0., target_size_mm - near_size_mm)
        if compatible_distance > transition_distance_mm * (1. + 1.e-12):
            transitions.append(compatible_distance)
        attempts = [(distance, seed) for distance in transitions for seed in random_seeds]
        for distance, seed in attempts:
            variant = "requested" if distance == transition_distance_mm else "compatible-growth"
            label = f"direct-occ-box-tet/{side}/{variant}/seed={seed}"
            try:
                volume = run_isolated_candidate(
                    generate_locked_box_hybrid,
                    ({n: permuted[n] for n in docking_nodes}, docking,
                     (origin[0], origin[0] + size[0], origin[1], origin[1] + size[1]),
                     origin[2] + upper * size[2], origin[2] + (1 - upper) * size[2]),
                    dict(maximum_size_mm=target_size_mm, near_size_mm=near_size_mm,
                         transition_distance_mm=distance,
                         locked_side_node_coordinates={n: permuted[n] for n in lateral_nodes} or None,
                         locked_side_facets=lateral, minimum_quality=minimum_quality,
                         random_seeds=(seed,), verbose=verbose),
                    label=label,
                )
                result = _adapt(volume, root, order, locked, side, target_size_mm,
                                near_size_mm, distance, errors)
                result[3].update(requested_transition_distance_mm=transition_distance_mm,
                                 effective_transition_distance_mm=distance,
                                 compatibility_growth_used=distance != transition_distance_mm)
                emit_candidate_event({"stage": "candidate_selection", "state": "accepted", "candidate": label,
                    "detail": (f"请求过渡距离 {transition_distance_mm * 1000:.8g} μm；"
                               f"采用过渡距离 {distance * 1000:.8g} μm；接口及质量检查通过。")})
                return result
            except (ConstrainedHybridError, CandidateExecutionError) as error:
                errors.append(f"{side}/{variant}/seed={seed}: {error}")
    raise ConstrainedHybridError("direct OCC Box TET route: " + "; ".join(errors or ["no eligible complete docking end"]))


def _loops_covered(loops, edges):
    """Each loop segment must be covered, without gaps, by collinear lock edges."""
    tolerance = 1.e-9
    for loop in loops:
        for a, b in zip(loop, (*loop[1:], loop[0])):
            delta = tuple(b[i] - a[i] for i in range(3))
            length2 = sum(v*v for v in delta)
            if length2 <= tolerance**2:
                continue
            intervals = []
            for edge in edges:
                parameters = [sum((p[i]-a[i])*delta[i] for i in range(3))/length2 for p in edge]
                if all(sum((p[i]-a[i]-t*delta[i])**2 for i in range(3)) <= tolerance**2
                       for p, t in zip(edge, parameters)):
                    intervals.append(sorted(parameters))
            end = 0.
            for lower, upper in sorted(intervals):
                if lower > end + tolerance:
                    break
                end = max(end, upper)
            if end < 1 - tolerance:
                return False
    return True


def _adapt(volume, root, order, locked, side, target, near, transition, failures):
    coordinates = {n: tuple(p[order.index(a)] for a in range(3)) for n, p in volume.node_coordinates.items()}
    owners = defaultdict(list)
    for element in volume.elements:
        for indices in ELEMENT_SPECS[element.gmsh_type][2]:
            face = tuple(element.node_ids[i] for i in indices)
            owners[tuple(sorted(face))].append(face)
    boundary = {side: [] for side in SIDES}
    for faces in owners.values():
        if len(faces) != 1:
            continue
        face = faces[0]
        matches = [name for name, (axis, upper) in SIDES.items()
                   if all(abs(coordinates[n][axis] - root.origin_xyz_mm[axis] - upper*root.size_xyz_mm[axis]) < 1.e-9 for n in face)]
        if len(matches) != 1:
            raise ConstrainedHybridError("direct Box TET has an ambiguous exterior facet")
        boundary[matches[0]].append(face)
    local_by_source = {source: local for local, source in volume.source_node_id_by_local_id.items()}
    locked_final = {name: tuple(tuple(local_by_source[n] for n in f) for f in fs) for name, fs in locked.items()}
    remainder = GmshClosedShellRemainder(
        node_coordinates=coordinates, source_node_id_by_local_id=volume.source_node_id_by_local_id,
        elements=tuple(GmshClosedShellElement(e.gmsh_type, e.node_ids) for e in volume.elements),
        boundary_facets=tuple(f for fs in boundary.values() for f in fs),
        docking_facets=tuple(f for fs in locked_final.values() for f in fs),
        tet4_count=volume.tet4_count, hex8_count=0, wedge6_count=0, pyramid5_count=volume.pyramid5_count,
        locked_triangle_count=volume.docking_triangle_count + volume.locked_side_triangle_count,
        locked_quad_count=volume.docking_quad_count + volume.locked_side_quad_count,
        target_size_mm=target, near_size_mm=near, transition_distance_mm=transition,
        background_field_kind="MathEval: linear distance from docking plane",
        minimum_sicn=volume.minimum_sicn, minimum_sige=volume.minimum_sige,
        minimum_scaled_jacobian=volume.minimum_scaled_jacobian, minimum_determinant=volume.minimum_determinant,
        duplicate_node_count=volume.duplicate_node_count, duplicate_element_count=volume.duplicate_element_count,
        shell_volume_mm3=volume.box_volume_mm3, element_volume_mm3=volume.element_volume_mm3,
        relative_volume_error=volume.relative_volume_error, random_seed=volume.random_seed,
    )
    evidence = dict(docking_side=side, tet_preferred=True, sweep_fallback_used=False,
                    near_median_edge_mm=volume.near_median_edge_mm, far_median_edge_mm=volume.far_median_edge_mm,
                    near_far_edge_growth_ratio=volume.far_median_edge_mm/volume.near_median_edge_mm,
                    growth_by_axis={"xyz"[a]: asdict(volume.growth_by_axis["xyz"[order.index(a)]]) for a in range(3)},
                    optimized_interior_pyramid_node_count=volume.optimized_interior_pyramid_node_count,
                    optimized_interior_quality_node_count=volume.optimized_interior_quality_node_count,
                    candidate_rejections=tuple(failures))
    return remainder, locked_final, {side: tuple(fs) for side, fs in boundary.items()}, evidence
