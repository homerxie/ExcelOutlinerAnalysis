"""Preview-only Frozen boundary geometry. Never certifies an executable mesh.

The bounded, process-local cache retains geometry by mesh content fingerprint.
It never substitutes preview evidence for an audited FrozenSourceSnapshot.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from copy import deepcopy
import math
from pathlib import Path
import time

from .gmsh_runtime import isolated_gmsh_model
from .volume_mesh import ELEMENT_SPECS
from .package_v2_frozen import FrozenSourceLimits, _preflight_private_mesh
from .package_v2_mesh_cache import mesh_file_entry, verify_mesh_entry, trim_parsed_meshes
from .package_v2_frozen_boundary_matching import (
    _area, _frozen_to_package, _positive_overlap_sides, _side_for_points,
    _owner_point_is_outside_target,
)


@dataclass(frozen=True)
class BoundaryFace:
    groups: tuple[str, ...]
    points: tuple[tuple[float, float, float], ...]
    owner_center: tuple[float, float, float]


def mesh_signature(path):
    path = Path(path).resolve(strict=True)
    stat = path.stat()
    return str(path), stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino


class BoundaryCache:
    def __init__(self):
        self._items = OrderedDict()
        self.contacts = OrderedDict()

    def get(self, path, *, components=(), sha256=None):
        entry = mesh_file_entry(path)
        if sha256 is not None and sha256 != entry.capture.snapshot.sha256:
            raise ValueError("网格文件内容已变化，请核对后更新网格引用。")
        key = (entry.capture.snapshot.sha256, tuple(sorted(components)))
        if key in self._items:
            self._items.move_to_end(key)
            return self._items[key], True
        with entry.lock:
            if entry.geometry_data is None:
                entry.geometry_memory = _preflight_private_mesh(entry.private_path, limits=FrozenSourceLimits())[2]
                entry.geometry_data = _read_geometry(entry.private_path)
            result = _read_exterior(entry.geometry_data, components)
            trim_parsed_meshes(entry)
        verify_mesh_entry(entry)
        self._items[key] = result
        while len(self._items) > 2:
            self._items.popitem(last=False)
        return result, False


def _read_geometry(path):
    import gmsh
    records = []
    registry = {}
    with isolated_gmsh_model(gmsh, "contact_geometry", number_options={"General.Terminal": 0.0}):
        gmsh.merge(str(path))
        tags, flat, _ = gmsh.model.mesh.getNodes()
        nodes = {int(tag): tuple(float(v) for v in flat[3*i:3*i+3]) for i, tag in enumerate(tags)}
        if any(not all(math.isfinite(v) for v in p) for p in nodes.values()):
            raise ValueError("Frozen 网格包含非有限坐标")
        for _, group in gmsh.model.getPhysicalGroups(3):
            name = gmsh.model.getPhysicalName(3, group)
            if name:
                registry.setdefault(name, []).append(int(group))
        for _, entity in gmsh.model.getEntities(3):
            groups = tuple(gmsh.model.getPhysicalName(3, int(g))
                           for g in gmsh.model.getPhysicalGroupsForEntity(3, entity))
            types, tag_blocks, blocks = gmsh.model.mesh.getElements(3, entity)
            for kind, element_tags, block in zip(types, tag_blocks, blocks):
                if int(kind) not in ELEMENT_SPECS:
                    raise ValueError(f"接触预览不支持 Frozen 单元类型 {kind}")
                _, width, faces = ELEMENT_SPECS[int(kind)]
                values = tuple(int(v) for v in block)
                for i in range(len(element_tags)):
                    connectivity = values[i*width:(i+1)*width]
                    records.append((groups, connectivity, faces))
    return nodes, tuple(records), registry


def _read_exterior(data, selected=()):
    nodes, records, registry = data
    owners, counts = {}, {}
    selected = set(selected)
    for groups, connectivity, faces in records:
        if selected and not selected.intersection(groups):
            continue
        center = tuple(math.fsum(nodes[n][a] for n in connectivity) / len(connectivity) for a in range(3))
        for face in faces:
            facet = tuple(connectivity[j] for j in face)
            key = tuple(sorted(facet))
            counts[key] = counts.get(key, 0) + 1
            if counts[key] == 1:
                owners[key] = (groups, facet, center)
            else:
                owners.pop(key, None)
            if counts[key] > 2:
                raise ValueError("Frozen 网格存在非流形面，无法确认外表面")
    result = tuple(BoundaryFace(groups, tuple(nodes[n] for n in facet), center)
                   for groups, facet, center in owners.values())
    return result, registry


def frozen_geometry_rows(compiled, components, names, cache):
    rows = []
    evidence = []
    tolerance = compiled.interface_geometry_tolerance_mm
    for source in compiled.frozen_sources:
        start = time.perf_counter()
        signature = mesh_signature(source.artifacts.mesh_runtime_path)
        (boundary, registry), hit = cache.get(source.artifacts.mesh_runtime_path,
            components=tuple(b.local_id for b in source.components), sha256=source.artifacts.sha256)
        if mesh_signature(source.artifacts.mesh_runtime_path) != signature:
            raise ValueError("Frozen 网格在检测时发生变化，请重新检测")
        bindings = {b.local_id: b.global_id for b in source.components}
        for name in bindings:
            if len(registry.get(name, ())) != 1:
                raise ValueError(f"Frozen Component {name!r} 必须对应唯一的具名三维 Physical Group")
        source_key = (mesh_file_entry(source.artifacts.mesh_runtime_path).capture.snapshot.sha256, repr(source.placement),
                      tuple(bindings.items()), tolerance)
        pending = {}
        reused = 0
        for component_id, component in components.items():
            key = source_key, repr(component), repr(names[component_id])
            if key in cache.contacts:
                cache.contacts.move_to_end(key)
                rows.extend(deepcopy(cache.contacts[key]))
                reused += 1
            else:
                pending[component_id] = (component, key)
        groups = {}
        for face in boundary if pending else ():
            selected = set(face.groups).intersection(bindings)
            if len(selected) != 1:
                raise ValueError("Frozen 外表面的 Component 归属缺失或重叠")
            local_id = next(iter(selected))
            points = tuple(_frozen_to_package(p, source) for p in face.points)
            center = _frozen_to_package(face.owner_center, source)
            for component_id, (component, _) in pending.items():
                for fragment in component.fragments:
                    areas = {}
                    sides = _positive_overlap_sides(fragment, points, tolerance, areas=areas)
                    if not sides:
                        continue
                    whole_side = _side_for_points(fragment, points, tolerance)
                    for side in sides:
                        if side != "analytic_free_surface" and not _owner_point_is_outside_target(
                            fragment, side, center, tolerance,
                        ):
                            raise ValueError("Frozen/Generated 在边界同侧存在体积重叠，不是接触接口")
                        key = local_id, component_id
                        row = groups.setdefault(key, {
                            "kind": "Frozen→Generated",
                            "first": {"instance": source.source_id, "component": local_id},
                            "second": names[component_id],
                            "first_global_id": bindings[local_id], "second_global_id": component_id,
                            "area_mm2": 0.0, "facet_count": 0, "partial_facet_count": 0,
                            "sides": set(), "mode": "preserve_interface_trace",
                            "mesh_compatibility": "pending_execution_audit",
                        })
                        area = _area(points) if whole_side == side else areas.get(side)
                        if area is None:
                            row["area_mm2"] = None
                        elif row["area_mm2"] is not None:
                            row["area_mm2"] += area
                        row["facet_count"] += 1
                        row["partial_facet_count"] += int(whole_side != side)
                        row["sides"].add(side)
        for row in groups.values():
            row["sides"] = sorted(row["sides"])
            if row["partial_facet_count"]:
                row["mesh_compatibility"] = "partial_frozen_facet_requires_check"
            if row["area_mm2"] is None:
                row["area_status"] = "curved_partial_overlap_not_integrated"
        if mesh_signature(source.artifacts.mesh_runtime_path) != signature:
            raise ValueError("Frozen 网格在检测时发生变化，请重新检测")
        rows.extend(groups.values())
        for component_id, (_, key) in pending.items():
            cache.contacts[key] = deepcopy([row for row in groups.values()
                                           if row["second_global_id"] == component_id])
        while len(cache.contacts) > 128:
            cache.contacts.popitem(last=False)
        evidence.append({"path": str(source.artifacts.mesh_runtime_path), "cache_hit": hit,
                         "reused_component_count": reused, "recomputed_component_count": len(pending),
                         "boundary_facet_count": len(boundary),
                         "elapsed_seconds": time.perf_counter() - start})
    return rows, evidence
