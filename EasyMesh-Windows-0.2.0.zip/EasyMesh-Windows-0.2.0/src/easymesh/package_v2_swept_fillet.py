"""Four-sided fillet: linear Z profiles and tangent elliptical corner sweeps."""
from __future__ import annotations

from dataclasses import replace
import math


def widths_at(root, fraction=0.):
    base = root.side_widths_mm or (root.toe_width_mm,) * 4
    top = root.top_widths_mm or (root.top_width_mm,) * 4
    return tuple(w + fraction * (end - w) for w, end in zip(base, top))


def slice_area(root, fraction):
    xm, xp, ym, yp = widths_at(root, fraction)
    dx, dy = root.die_size_xy_mm
    return dy * (xm + xp) + dx * (ym + yp) + math.pi / 4 * (xm + xp) * (ym + yp)


def volume(root):
    return root.wall_height_mm * (slice_area(root, 0.) + 4 * slice_area(root, .5) + slice_area(root, 1.)) / 6


def radial_fraction(root, point):
    """Elliptical radius outside the inner rectangle; one on the free surface."""
    x, y, z = point
    x0, y0 = root.die_origin_xy_mm
    x1, y1 = x0 + root.die_size_xy_mm[0], y0 + root.die_size_xy_mm[1]
    widths = widths_at(root, min(1., max(0., (z - root.base_z_mm) / root.wall_height_mm)))
    dx, dy = max(x0 - x, 0., x - x1), max(y0 - y, 0., y - y1)
    wx, wy = widths[0 if x < x0 else 1], widths[2 if y < y0 else 3]
    def ratio(distance, width):
        return distance / width if width > 0 else (0. if distance < 1e-12 else math.inf)
    return math.hypot(ratio(dx, wx), ratio(dy, wy))


def on_outer_surface(root, point, tolerance=1e-7):
    x, y, z = point
    if z < root.base_z_mm-tolerance or z > root.base_z_mm+root.wall_height_mm+tolerance:
        return False
    xm, xp, ym, yp = widths_at(root, (z-root.base_z_mm)/root.wall_height_mm)
    x0, y0 = root.die_origin_xy_mm
    x1, y1 = x0+root.die_size_xy_mm[0], y0+root.die_size_xy_mm[1]
    if (any(width <= tolerance and abs(x-side) <= tolerance for width, side in ((xm, x0), (xp, x1)))
            and y0-ym-tolerance <= y <= y1+yp+tolerance):
        return True
    if (any(width <= tolerance and abs(y-side) <= tolerance for width, side in ((ym, y0), (yp, y1)))
            and x0-xm-tolerance <= x <= x1+xp+tolerance):
        return True
    scale = min((w for w in (xm, xp, ym, yp) if w > tolerance), default=1.)
    return abs(radial_fraction(root, point)-1.) <= tolerance/scale


def enclosing_envelope(root):
    """Only for planar-lock preparation; the actual CAD comes from occ_add."""
    from .uf_skin import RectangularUfEnvelope
    width = max(*widths_at(root), *widths_at(root, 1.))
    x0, y0 = root.die_origin_xy_mm
    dx, dy = root.die_size_xy_mm
    return RectangularUfEnvelope(die_width=dx, die_length=dy, base_z=root.base_z_mm,
        height=2*root.wall_height_mm, fillet_width=2*width, center_x=x0+dx/2, center_y=y0+dy/2)


def occ_add(gmsh, root):
    from .package_v2_component_adjacency import _occ_plane_surface
    occ = gmsh.model.occ
    x0, y0 = root.die_origin_xy_mm
    dx, dy = root.die_size_xy_mm
    x1, y1 = x0 + dx, y0 + dy
    z0, h = root.base_z_mm, root.wall_height_mm
    z1 = z0 + h
    xm, xp, ym, yp = widths_at(root)
    txm, txp, tym, typ = widths_at(root, 1.)
    volumes = []
    for polygon, direction in (
        (((x0, y0, z0), (x0, y0-ym, z0), (x0, y0-tym, z1), (x0, y0, z1)), (dx, 0., 0.)),
        (((x0, y1, z0), (x0, y1+yp, z0), (x0, y1+typ, z1), (x0, y1, z1)), (dx, 0., 0.)),
        (((x0, y0, z0), (x0-xm, y0, z0), (x0-txm, y0, z1), (x0, y0, z1)), (0., dy, 0.)),
        (((x1, y0, z0), (x1+xp, y0, z0), (x1+txp, y0, z1), (x1, y0, z1)), (0., dy, 0.)),
    ):
        surface = _occ_plane_surface(gmsh, polygon)
        volumes.extend(tag for dim, tag in occ.extrude([(2, surface)], *direction) if dim == 3)
    for cx, cy, sx, sy, wx, wy, tx, ty in (
        (x0, y0, -1, -1, xm, ym, txm, tym), (x1, y0, 1, -1, xp, ym, txp, tym),
        (x1, y1, 1, 1, xp, yp, txp, typ), (x0, y1, -1, 1, xm, yp, txm, typ),
    ):
        def wire(z, rx, ry):
            center = occ.addPoint(cx, cy, z)
            px, py = occ.addPoint(cx+sx*rx, cy, z), occ.addPoint(cx, cy+sy*ry, z)
            arc = (occ.addCircleArc(px, center, py) if math.isclose(rx, ry, rel_tol=1e-12)
                   else occ.addEllipseArc(px, center, px if rx >= ry else py, py))
            return occ.addWire([occ.addLine(center, px), arc, occ.addLine(py, center)], checkClosed=True)
        # A rational quadratic quarter ellipse swept linearly in Z remains
        # exact even when its upper edge degenerates to a segment or a point.
        poles = [occ.addPoint(*point) for rx, ry, z in ((wx, wy, z0), (tx, ty, z1))
                 for point in ((cx+sx*rx, cy, z), (cx+sx*rx, cy+sy*ry, z), (cx, cy+sy*ry, z))]
        outer = occ.addBSplineSurface(poles, 3, degreeU=2, degreeV=1,
            weights=[1., math.sqrt(.5), 1.] * 2, knotsU=[0., 1.], knotsV=[0., 1.],
            multiplicitiesU=[3, 3], multiplicitiesV=[2, 2])
        surfaces = [outer, occ.addPlaneSurface([wire(z0, wx, wy)]),
            _occ_plane_surface(gmsh, ((cx, cy, z0), (cx+sx*wx, cy, z0), (cx+sx*tx, cy, z1), (cx, cy, z1))),
            _occ_plane_surface(gmsh, ((cx, cy, z0), (cx, cy+sy*wy, z0), (cx, cy+sy*ty, z1), (cx, cy, z1)))]
        if tx > 0 and ty > 0:
            surfaces.append(occ.addPlaneSurface([wire(z1, tx, ty)]))
        volumes.append(occ.addVolume([occ.addSurfaceLoop(surfaces, sewing=True)]))
    fused, _ = occ.fuse([(3, volumes[0])], [(3, tag) for tag in volumes[1:]])
    result = tuple(tag for dim, tag in fused if dim == 3)
    if len(result) != 1:
        raise ValueError("fillet 的直边与四个扫掠角未连接成一个实体")
    return result


def surface_area(root):
    """Integrate the smooth ruled corner surfaces with Gaussian quadrature."""
    import numpy as np
    q, weights = np.polynomial.legendre.leggauss(32)
    t, theta = (q + 1) / 2, (q + 1) * math.pi / 4
    xm, xp, ym, yp = widths_at(root)
    txm, txp, tym, typ = widths_at(root, 1.)
    dx, dy = root.die_size_xy_mm
    h = root.wall_height_mm
    area = slice_area(root, 0.) + slice_area(root, 1.) + 2*(dx+dy)*h
    area += dy * sum(math.hypot(h, end-w) for w, end in ((xm, txm), (xp, txp)))
    area += dx * sum(math.hypot(h, end-w) for w, end in ((ym, tym), (yp, typ)))
    for wx, wy, tx, ty in ((xm, ym, txm, tym), (xp, ym, txp, tym), (xp, yp, txp, typ), (xm, yp, txm, typ)):
        rx, ry = wx + t[:, None]*(tx-wx), wy + t[:, None]*(ty-wy)
        c, s = np.cos(theta), np.sin(theta)
        jac = np.sqrt(h*h*(ry*ry*c*c + rx*rx*s*s) + (rx*(ty-wy)*s*s + ry*(tx-wx)*c*c)**2)
        area += float(np.sum(jac * weights[:, None] * weights[None, :])) * math.pi / 8
    return area


def cad_metrics(root):
    from .gmsh_runtime import isolated_gmsh_model
    from .occ_locked_hybrid import _load_gmsh
    gmsh = _load_gmsh()
    with isolated_gmsh_model(gmsh, "__elliptical_fillet_audit", number_options={"General.Terminal": 0.}):
        tags = occ_add(gmsh, root)
        gmsh.model.occ.synchronize()
        surfaces = gmsh.model.getBoundary([(3, tag) for tag in tags], oriented=False)
        return (sum(gmsh.model.occ.getMass(3, tag) for tag in tags),
                sum(gmsh.model.occ.getMass(2, tag) for dim, tag in surfaces if dim == 2))


def _reference_mapping(root):
    base = max(*widths_at(root), *widths_at(root, 1.))
    top = max(widths_at(root, 1.))
    ref_top = top if top < base else base / 2
    reference = replace(root, toe_width_mm=base, top_width_mm=ref_top, side_widths_mm=None, top_widths_mm=None)
    x0, y0 = root.die_origin_xy_mm
    dx, dy = root.die_size_xy_mm
    def warp(point, inverse=False):
        t = min(1., max(0., (point[2]-root.base_z_mm)/root.wall_height_mm))
        actual, reference_widths = widths_at(root, t), widths_at(reference, t)
        src, dst = (actual, reference_widths) if inverse else (reference_widths, actual)
        result = list(point)
        for axis, (lo, hi) in enumerate(((x0, x0+dx), (y0, y0+dy))):
            if point[axis] < lo or point[axis] > hi:
                side = axis*2 + (0 if point[axis] < lo else 1)
                anchor = lo if side % 2 == 0 else hi
                result[axis] = anchor + (point[axis]-anchor) * dst[side] / src[side] if src[side] > 1e-14 else anchor
        return tuple(result)
    return reference, warp


def surface_shell(root, locked_nodes, locked_facets, *, target_size_mm, transition_distance_mm,
                  near_size_mm=None, contact_partition_loops=(), force_partial_locked_sides=(), verbose=False):
    """Map a Gmsh-owned reference surface mesh onto the elliptical sweep.

    The monotone map is exact on the parametric surface. Source lock coordinates
    are restored verbatim; only Gmsh creates the final volume connectivity.
    """
    from .occ_uf_surface_shell import generate_rectangular_uf_surface_shell
    from .occ_uf_conformal import _facet_area
    from .uf_skin import RectangularUfEnvelope
    if max(widths_at(root, 1.)) > 0 and not locked_nodes and not contact_partition_loops:
        return _free_cad_shell(root, target_size_mm, near_size_mm or target_size_mm, transition_distance_mm, verbose)
    if root.top_widths_mm is not None:
        return generate_rectangular_uf_surface_shell(locked_nodes, locked_facets, enclosing_envelope(root),
            root.base_z_mm, root.base_z_mm+root.wall_height_mm, target_size_mm=target_size_mm,
            near_size_mm=near_size_mm, transition_distance_mm=transition_distance_mm,
            contact_partition_loops=contact_partition_loops, force_partial_locked_sides=force_partial_locked_sides,
            swept_root=root, verbose=verbose)
    reference, warp = _reference_mapping(root)
    base, ref_top = reference.toe_width_mm, reference.top_width_mm
    x0, y0 = root.die_origin_xy_mm
    dx, dy = root.die_size_xy_mm
    envelope = RectangularUfEnvelope(die_width=dx, die_length=dy, base_z=root.base_z_mm,
        height=root.wall_height_mm*base/(base-ref_top), fillet_width=base, center_x=x0+dx/2, center_y=y0+dy/2)
    # Bound the reference-to-actual map's stretching, including its Z shear.
    stretch = 2 + max(abs(end-w) for w, end in zip(widths_at(root), widths_at(root, 1.))) / root.wall_height_mm
    shell = generate_rectangular_uf_surface_shell(
        {node: warp(point, True) for node, point in locked_nodes.items()}, locked_facets,
        envelope, root.base_z_mm, root.base_z_mm+root.wall_height_mm,
        target_size_mm=target_size_mm/stretch, near_size_mm=(near_size_mm or target_size_mm)/stretch,
        transition_distance_mm=transition_distance_mm,
        contact_partition_loops=tuple(tuple(warp(p, True) for p in loop) for loop in contact_partition_loops),
        force_partial_locked_sides=force_partial_locked_sides, verbose=verbose)
    coordinates = {node: warp(point) for node, point in shell.node_coordinates.items()}
    for node, source in shell.source_node_id_by_local_id.items():
        coordinates[node] = tuple(locked_nodes[source])
    analytic_area = surface_area(root)
    cad_volume, cad_area = cad_metrics(root)
    if abs(cad_volume-volume(root)) > 1e-6*volume(root):
        raise ValueError("fillet 扫掠体积与截面积分不一致")
    mesh_area = sum(_facet_area(facet, coordinates) for facet in shell.boundary_facets)
    return replace(shell, node_coordinates=coordinates, target_size_mm=target_size_mm,
        near_size_mm=near_size_mm or target_size_mm, geometry_authority="elliptical_cross_section_sweep",
        cad_surface_area_mm2=cad_area, analytic_surface_area_mm2=analytic_area,
        mesh_surface_area_mm2=mesh_area, mesh_to_cad_area_relative_error=abs(mesh_area-cad_area)/cad_area,
        cad_to_analytic_area_relative_error=abs(cad_area-analytic_area)/analytic_area)


def _audit_mapped_volume(elements, coordinates, minimum_quality, verbose):
    from .gmsh_closed_shell_remainder import _folded_internal_face_count
    from .gmsh_runtime import isolated_gmsh_model
    from .occ_locked_hybrid import _load_gmsh
    gmsh = _load_gmsh()
    with isolated_gmsh_model(gmsh, "__swept_fillet_volume_audit", number_options={"General.Terminal": float(verbose)}):
        entity = gmsh.model.addDiscreteEntity(3)
        gmsh.model.mesh.addNodes(3, entity, list(coordinates), [value for point in coordinates.values() for value in point])
        records = []
        for kind in sorted({element.gmsh_type for element in elements}):
            subset = [(i, element) for i, element in enumerate(elements, 1) if element.gmsh_type == kind]
            gmsh.model.mesh.addElementsByType(entity, kind, [i for i, _ in subset], [node for _, element in subset for node in element.node_ids])
            records.extend((kind, i, element.node_ids) for i, element in subset)
        metrics = {}
        for metric in ("minDetJac", "minSICN", "minSIGE", "minSJ", "volume"):
            values = tuple(float(v) for v in gmsh.model.mesh.getElementQualities([i for _, i, _ in records], metric))
            if len(values) != len(elements) or not values or any(not math.isfinite(v) or v <= 0 for v in values):
                raise ValueError(f"fillet 扫掠网格的 {metric} 检查失败")
            metrics[metric] = math.fsum(values) if metric == "volume" else min(values)
    if (min(metrics[key] for key in ("minSICN", "minSIGE", "minSJ")) < minimum_quality
            or _folded_internal_face_count(records, coordinates)):
        raise ValueError("fillet 四侧扫掠网格未通过 Jacobian / 质量检查")
    return metrics


def direct_swept_fill(root, locked_nodes, locked_facets, **options):
    """Let Gmsh build the exact independently capped fillet, including zero sides."""
    from .occ_uf_conformal import generate_rectangular_uf_conformal_hybrid
    def audit(result):
        _audit_mapped_volume(result.elements, result.node_coordinates, options["minimum_quality"], options.get("verbose", False))
    return generate_rectangular_uf_conformal_hybrid(locked_nodes, locked_facets, enclosing_envelope(root),
        root.base_z_mm, root.base_z_mm+root.wall_height_mm, swept_root=root, candidate_validator=audit, **options)


def pointed_wall_fill(root, locked_nodes, locked_facets, **options):
    """Retain Gmsh's apex/pyramid topology, then map and audit the real shape."""
    from .occ_uf_conformal import generate_rectangular_uf_conformal_hybrid
    from .package_v2_conformal_hybrid_materializer import _fillet_envelope
    from .gmsh_closed_shell_remainder import _orient_closed_shell
    if max(widths_at(root, 1.)) != 0:
        raise ValueError("收尖 fillet 网格要求顶部宽度为零")
    reference, warp = _reference_mapping(root)
    result = generate_rectangular_uf_conformal_hybrid(
        {node: warp(point, True) for node, point in locked_nodes.items()}, locked_facets,
        _fillet_envelope(reference), root.base_z_mm, root.base_z_mm + root.wall_height_mm, **options)
    coordinates = {node: warp(point) for node, point in result.node_coordinates.items()}
    for node, source in result.source_node_id_by_local_id.items():
        coordinates[node] = tuple(locked_nodes[source])
    metrics = _audit_mapped_volume(result.elements, coordinates, options["minimum_quality"], options.get("verbose", False))
    boundary = (*result.base_facets, *result.cap_facets, *result.die_wall_facets, *result.free_surface_facets)
    _, shell_volume = _orient_closed_shell(boundary, coordinates)
    if shell_volume <= 0 or abs(metrics["volume"] - shell_volume) > 1e-8 * shell_volume:
        raise ValueError(f"fillet 收尖网格与闭合边界体积不一致：elements={metrics['volume']:.12g}, shell={shell_volume:.12g}")
    cad_volume, _ = cad_metrics(root)
    true_volume = volume(root)
    element_error = abs(metrics["volume"] - cad_volume) / cad_volume
    cad_error = abs(cad_volume - true_volume) / true_volume
    if element_error > .02 or cad_error > 1e-6:
        raise ValueError("fillet 收尖网格与扫掠几何体积不一致")
    return replace(result, node_coordinates=coordinates,
        minimum_determinant=metrics["minDetJac"], minimum_sicn=metrics["minSICN"],
        minimum_sige=metrics["minSIGE"], minimum_scaled_jacobian=metrics["minSJ"],
        cad_volume_mm3=cad_volume, analytic_volume_mm3=true_volume, element_volume_mm3=metrics["volume"],
        cad_relative_volume_error=cad_error, element_relative_volume_error=element_error,
        geometry_authority="elliptical_cross_section_sweep")


def locked_wall_fill(shell, root, *, target_size_mm, transition_distance_mm, near_size_mm, minimum_quality, verbose=False):
    """Map the Gmsh-generated four-wall fallback, then re-audit every element."""
    from .gmsh_rectangular_uf_structured_fill import generate_rectangular_uf_locked_quad_structured_fill
    from .volume_mesh import ELEMENT_SPECS
    reference, warp = _reference_mapping(root)
    ref_shell = replace(shell, node_coordinates={node: warp(point, True) for node, point in shell.node_coordinates.items()})
    result = generate_rectangular_uf_locked_quad_structured_fill(ref_shell, reference,
        target_size_mm=target_size_mm, transition_distance_mm=transition_distance_mm,
        near_size_mm=near_size_mm, minimum_quality=minimum_quality, verbose=verbose)
    remainder = result.remainder
    coordinates = {node: warp(point) for node, point in remainder.node_coordinates.items()}
    for node, source in remainder.source_node_id_by_local_id.items():
        coordinates[node] = shell.node_coordinates[source]
    metrics = _audit_mapped_volume(remainder.elements, coordinates, minimum_quality, verbose)
    xm, xp, ym, yp = widths_at(root)
    dx, dy = root.die_size_xy_mm
    txm, txp, tym, typ = widths_at(root, 1.)
    straight = root.wall_height_mm*(dy*(xm+xp+txm+txp)+dx*(ym+yp+tym+typ))/2
    true = volume(root)
    n = result.angular_layer_count
    polygonal = straight+(true-straight)*2*n*math.sin(math.pi/(2*n))/math.pi
    error = abs(metrics["volume"]-polygonal)/polygonal
    if error > 1e-8:
        raise ValueError("fillet 扫掠网格体积与截面扫掠不一致")
    locked_nodes = set(remainder.source_node_id_by_local_id)
    maximum = 0.
    for element in remainder.elements:
        for face in ELEMENT_SPECS[element.gmsh_type][2]:
            nodes = [element.node_ids[i] for i in face]
            for a, b in zip(nodes, nodes[1:]+nodes[:1]):
                if a not in locked_nodes or b not in locked_nodes:
                    maximum = max(maximum, math.dist(coordinates[a], coordinates[b]))
    if maximum > target_size_mm*(1+1e-8):
        raise ValueError("fillet 扫掠网格边长超过目标尺寸")
    mapped = replace(remainder, node_coordinates=coordinates, minimum_sicn=metrics["minSICN"], minimum_sige=metrics["minSIGE"],
        minimum_scaled_jacobian=metrics["minSJ"], minimum_determinant=metrics["minDetJac"],
        shell_volume_mm3=polygonal, element_volume_mm3=metrics["volume"], relative_volume_error=error)
    return replace(result, remainder=mapped, true_geometry_volume_mm3=true, polygonal_geometry_volume_mm3=polygonal,
        geometry_volume_relative_error=abs(polygonal-true)/true, maximum_generated_edge_mm=maximum,
        applied_path="gmsh_locked_quad_elliptical_corner_sweep")


def _free_cad_shell(root, target, near, transition, verbose):
    from .gmsh_runtime import isolated_gmsh_model
    from .occ_locked_hybrid import _load_gmsh, _all_nodes, _face_key
    from .occ_box_frame_surface_shell import _raw_surface_records, _orient_boundary_cycles, _edge_audit
    from .occ_uf_surface_shell import GmshUfSurfaceShell
    from .occ_uf_conformal import _facet_area
    from .package_v2_adjacency_execution import _classify_local_side
    from .package_v2_geometry import CanonicalGeometryFragment, CanonicalRigidPlacement
    fragment = CanonicalGeometryFragment("fillet", root, CanonicalRigidPlacement((0.,)*3, (0.,)*3, (0.,)*3))
    gmsh = _load_gmsh()
    with isolated_gmsh_model(gmsh, "__swept_fillet_surface", number_options={
        "General.Terminal": float(verbose), "Mesh.ElementOrder": 1., "Mesh.Algorithm": 6.,
        "Mesh.MeshSizeMax": target, "Mesh.MeshSizeMin": min(near, target),
    }):
        tags = occ_add(gmsh, root)
        gmsh.model.occ.synchronize()
        surfaces = [tag for dim, tag in gmsh.model.getBoundary([(3, tag) for tag in tags], oriented=False) if dim == 2]
        gmsh.model.mesh.generate(2)
        records = _raw_surface_records(gmsh, surfaces)
        all_nodes = _all_nodes(gmsh)
        used = {int(node) for _, _, nodes in records for node in nodes}
        coordinates = {node: all_nodes[node] for node in used}
        facets = tuple(_orient_boundary_cycles({_face_key(nodes): tuple(nodes) for _, _, nodes in records}, {}).values())
        edges, bad, oriented = _edge_audit(facets)
        if bad or not oriented:
            raise ValueError("fillet 扫掠曲面网格未闭合")
        grouped = {side: [] for side in ("base", "cap", "die_x_min", "die_x_max", "die_y_min", "die_y_max", "outer_free")}
        names = {"z_min": "base", "z_max": "cap", "analytic_free_surface": "outer_free"}
        for facet in facets:
            side = _classify_local_side(fragment, tuple(coordinates[node] for node in facet), 1e-6)
            grouped[names.get(side, side)].append(facet)
        cad_area = sum(gmsh.model.occ.getMass(2, surface) for surface in surfaces)
        cad_volume = sum(gmsh.model.occ.getMass(3, tag) for tag in tags)
        if abs(cad_volume-volume(root)) > 1e-6*volume(root):
            raise ValueError("fillet 扫掠体积与截面积分不一致")
        area = surface_area(root)
        mesh_area = sum(_facet_area(facet, coordinates) for facet in facets)
        triangles = sum(len(facet) == 3 for facet in facets)
        quads = len(facets)-triangles
        return GmshUfSurfaceShell(node_coordinates=coordinates, source_node_id_by_local_id={}, boundary_facets=facets,
            locked_facets_by_side={}, free_facets=facets, facets_by_geometric_side={key: tuple(value) for key, value in grouped.items()},
            triangle_count=triangles, quad_count=quads, locked_triangle_count=0, locked_quad_count=0,
            free_triangle_count=triangles, free_quad_count=quads, target_size_mm=target, near_size_mm=near,
            transition_distance_mm=transition, background_field_kind="uniform", geometry_authority="elliptical_cross_section_sweep",
            cad_surface_area_mm2=cad_area, analytic_surface_area_mm2=area, mesh_surface_area_mm2=mesh_area,
            mesh_to_cad_area_relative_error=abs(mesh_area-cad_area)/cad_area,
            cad_to_analytic_area_relative_error=abs(cad_area-area)/area, watertight=True, consistently_oriented=True,
            boundary_edge_count=edges, bad_edge_count=0, removed_duplicate_node_count=0, duplicate_node_count=0,
            duplicate_facet_count=0, volume_element_count=0)
