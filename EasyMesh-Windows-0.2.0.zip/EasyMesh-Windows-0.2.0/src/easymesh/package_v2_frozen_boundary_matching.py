"""Geometry-only matching of Frozen exterior facets to generated boundaries.

The matcher is intentionally independent of interface mode and volume
topology.  It extracts the real exterior faces of one immutable Frozen
Component, applies the stored Frozen placement once, and classifies positive
area faces on canonical generated primitives.  A later interface executor can
either preserve the returned trace or propagate its owner volume elements;
this module makes neither decision.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
import math
from types import MappingProxyType
from typing import Mapping, Sequence

from .package_v2_frozen import FrozenSourceSnapshot
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    CanonicalRigidPlacement,
)
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)
from .volume_mesh import ELEMENT_SPECS, ElementKind, VolumeElement


Point3D = tuple[float, float, float]
_SPEC_BY_KIND = {
    specification[0]: specification
    for specification in ELEMENT_SPECS.values()
}


class FrozenBoundaryMatchingError(ValueError):
    """Frozen exterior faces cannot be matched without changing geometry."""


@dataclass(frozen=True, slots=True)
class MatchedFrozenFacet:
    source_node_tags: tuple[int, ...]
    owner_element_tag: int
    owner_element_kind: ElementKind
    owner_local_face_index: int
    area_mm2: float

    def __post_init__(self) -> None:
        nodes = tuple(self.source_node_tags)
        if len(nodes) not in (3, 4) or len(set(nodes)) != len(nodes):
            raise FrozenBoundaryMatchingError(
                "matched Frozen facet must be TRI3 or QUAD4"
            )
        if any(
            isinstance(node, bool) or not isinstance(node, int) or node < 1
            for node in nodes
        ):
            raise FrozenBoundaryMatchingError(
                "matched Frozen facet node tags must be positive integers"
            )
        if (
            isinstance(self.owner_element_tag, bool)
            or not isinstance(self.owner_element_tag, int)
            or self.owner_element_tag < 1
            or isinstance(self.owner_local_face_index, bool)
            or not isinstance(self.owner_local_face_index, int)
            or self.owner_local_face_index < 0
            or not isinstance(self.owner_element_kind, ElementKind)
        ):
            raise FrozenBoundaryMatchingError(
                "matched Frozen facet owner is invalid"
            )
        if not math.isfinite(self.area_mm2) or self.area_mm2 <= 0.0:
            raise FrozenBoundaryMatchingError(
                "matched Frozen facet area must be positive"
            )
        object.__setattr__(self, "source_node_tags", nodes)


@dataclass(frozen=True, slots=True)
class MatchedFrozenBoundaryPatch:
    target_component_id: str
    target_fragment_id: str
    side_name: str
    node_coordinates: Mapping[int, Point3D]
    facets: tuple[MatchedFrozenFacet, ...]

    def __post_init__(self) -> None:
        for field_name in (
            "target_component_id",
            "target_fragment_id",
            "side_name",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value:
                raise FrozenBoundaryMatchingError(f"{field_name} is invalid")
        facets = tuple(self.facets)
        if not facets:
            raise FrozenBoundaryMatchingError(
                "matched Frozen boundary patch cannot be empty"
            )
        if any(not isinstance(value, MatchedFrozenFacet) for value in facets):
            raise FrozenBoundaryMatchingError("matched Frozen facets are invalid")
        coordinates = dict(self.node_coordinates)
        if any(
            isinstance(tag, bool)
            or not isinstance(tag, int)
            or tag < 1
            or len(point) != 3
            or any(not math.isfinite(value) for value in point)
            for tag, point in coordinates.items()
        ):
            raise FrozenBoundaryMatchingError(
                "matched Frozen patch coordinates are invalid"
            )
        referenced = {
            node for facet in facets for node in facet.source_node_tags
        }
        if referenced != set(coordinates):
            raise FrozenBoundaryMatchingError(
                "matched Frozen patch coordinates are not exact"
            )
        object.__setattr__(self, "facets", facets)
        object.__setattr__(
            self, "node_coordinates", MappingProxyType(coordinates)
        )

    @property
    def area_mm2(self) -> float:
        return math.fsum(value.area_mm2 for value in self.facets)


def _subtract(first: Sequence[float], second: Sequence[float]) -> Point3D:
    return tuple(first[index] - second[index] for index in range(3))  # type: ignore[return-value]


def _cross(first: Sequence[float], second: Sequence[float]) -> Point3D:
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _dot(first: Sequence[float], second: Sequence[float]) -> float:
    return math.fsum(first[index] * second[index] for index in range(3))


def _area(points: Sequence[Point3D]) -> float:
    origin = points[0]
    vector = [0.0, 0.0, 0.0]
    for index in range(1, len(points) - 1):
        cross = _cross(
            _subtract(points[index], origin),
            _subtract(points[index + 1], origin),
        )
        for axis in range(3):
            vector[axis] += cross[axis]
    return 0.5 * math.sqrt(_dot(vector, vector))


def _rotation_matrix(placement: CanonicalRigidPlacement) -> tuple[Point3D, ...]:
    result = (
        (1.0, 0.0, 0.0),
        (0.0, 1.0, 0.0),
        (0.0, 0.0, 1.0),
    )

    def multiply(
        first: Sequence[Sequence[float]],
        second: Sequence[Sequence[float]],
    ) -> tuple[Point3D, ...]:
        return tuple(
            tuple(
                math.fsum(first[row][inner] * second[inner][column] for inner in range(3))
                for column in range(3)
            )
            for row in range(3)
        )  # type: ignore[return-value]

    for angle, axis in zip(placement.rotation_deg_xyz, range(3)):
        radians = math.radians(angle)
        cosine, sine = math.cos(radians), math.sin(radians)
        matrices = (
            ((1.0, 0.0, 0.0), (0.0, cosine, -sine), (0.0, sine, cosine)),
            ((cosine, 0.0, sine), (0.0, 1.0, 0.0), (-sine, 0.0, cosine)),
            ((cosine, -sine, 0.0), (sine, cosine, 0.0), (0.0, 0.0, 1.0)),
        )
        result = multiply(matrices[axis], result)
    return result


def _package_to_fragment_local(
    point: Point3D,
    placement: CanonicalRigidPlacement,
) -> Point3D:
    if placement.rotation_deg_xyz == (0.0, 0.0, 0.0):
        return tuple(point[a] - placement.translation_xyz_mm[a] for a in range(3))
    translated = tuple(
        point[axis] - placement.translation_xyz_mm[axis]
        for axis in range(3)
    )
    pivot = placement.pivot_xyz_mm
    relative = tuple(translated[axis] - pivot[axis] for axis in range(3))
    rotation = _rotation_matrix(placement)
    return tuple(
        pivot[row]
        + math.fsum(rotation[column][row] * relative[column] for column in range(3))
        for row in range(3)
    )  # type: ignore[return-value]


def _frozen_to_package(
    point: Point3D,
    snapshot: FrozenSourceSnapshot,
) -> Point3D:
    placement = snapshot.placement
    return tuple(
        placement.translation_xyz_mm[row]
        + math.fsum(
            placement.rotation_matrix[row][column] * point[column]
            for column in range(3)
        )
        for row in range(3)
    )  # type: ignore[return-value]


def _close(first: float, second: float, tolerance: float) -> bool:
    return abs(first - second) <= tolerance


def _within(value: float, bounds: tuple[float, float], tolerance: float) -> bool:
    return bounds[0] - tolerance <= value <= bounds[1] + tolerance


def _all_on_plane(
    points: Sequence[Point3D],
    axis: int,
    coordinate: float,
    tolerance: float,
) -> bool:
    return all(_close(point[axis], coordinate, tolerance) for point in points)


def _clip_polygon_to_rectangle(
    points: Sequence[tuple[float, float]],
    bounds: tuple[float, float, float, float],
    *,
    tolerance: float = 0.0,
) -> list[tuple[float, float]]:
    """Clip one convex polygon after local canonical-boundary snapping.

    Snapping is predicate-local: it never changes the immutable Frozen node
    coordinates returned to later stages.  It only prevents a point that is
    within the Package interface tolerance of a rectangle edge from creating
    an artificial positive-area sliver during floating-point clipping.
    """

    x_min, x_max, y_min, y_max = bounds

    def snap(value: float, lower: float, upper: float) -> float:
        candidates = tuple(
            boundary
            for boundary in (lower, upper)
            if abs(value - boundary) <= tolerance
        )
        if not candidates:
            return value
        return min(candidates, key=lambda boundary: (abs(value - boundary), boundary))

    polygon = [
        (snap(point[0], x_min, x_max), snap(point[1], y_min, y_max))
        for point in points
    ]

    def clip(
        values: list[tuple[float, float]],
        *,
        axis: int,
        coordinate: float,
        keep_greater: bool,
    ) -> list[tuple[float, float]]:
        if not values:
            return []

        def inside(point: tuple[float, float]) -> bool:
            return (
                point[axis] >= coordinate
                if keep_greater
                else point[axis] <= coordinate
            )

        result: list[tuple[float, float]] = []
        previous = values[-1]
        previous_inside = inside(previous)
        for current in values:
            current_inside = inside(current)
            if current_inside != previous_inside:
                denominator = current[axis] - previous[axis]
                if denominator != 0.0:
                    fraction = (coordinate - previous[axis]) / denominator
                    raw_intersection = (
                        previous[0] + fraction * (current[0] - previous[0]),
                        previous[1] + fraction * (current[1] - previous[1]),
                    )
                    snapped = [
                        snap(raw_intersection[0], x_min, x_max),
                        snap(raw_intersection[1], y_min, y_max),
                    ]
                    # The active clipping coordinate is a semantic canonical
                    # boundary, so retain it exactly after interpolating the
                    # other coordinate.
                    snapped[axis] = coordinate
                    intersection = (snapped[0], snapped[1])
                    result.append(intersection)
            if current_inside:
                result.append(current)
            previous = current
            previous_inside = current_inside
        return result

    for axis, coordinate, keep_greater in (
        (0, x_min, True),
        (0, x_max, False),
        (1, y_min, True),
        (1, y_max, False),
    ):
        polygon = clip(
            polygon,
            axis=axis,
            coordinate=coordinate,
            keep_greater=keep_greater,
        )
    return polygon


def _polygon_area_2d(points: Sequence[tuple[float, float]]) -> float:
    if len(points) < 3:
        return 0.0
    origin = points[0]
    shifted = tuple(
        (point[0] - origin[0], point[1] - origin[1])
        for point in points
    )
    return 0.5 * abs(
        math.fsum(
            first[0] * second[1] - second[0] * first[1]
            for first, second in zip(
                shifted,
                (*shifted[1:], shifted[0]),
            )
        )
    )


def _minimum_polygon_width_2d(
    points: Sequence[tuple[float, float]],
) -> float:
    """Return the minimum convex-polygon width over its edge normals."""

    if len(points) < 3:
        return 0.0
    widths: list[float] = []
    for first, second in zip(points, (*points[1:], points[0])):
        dx = second[0] - first[0]
        dy = second[1] - first[1]
        length = math.hypot(dx, dy)
        if length == 0.0:
            continue
        normal = (-dy / length, dx / length)
        projections = tuple(
            point[0] * normal[0] + point[1] * normal[1]
            for point in points
        )
        widths.append(max(projections) - min(projections))
    return min(widths, default=0.0)


def _polygon_rectangle_intersection_area(
    points: Sequence[Point3D],
    bounds: tuple[float, float, float, float],
    *,
    axes: tuple[int, int] = (0, 1),
    tolerance: float = 0.0,
) -> float:
    """Return an exact convex-polygon/axis rectangle overlap on one plane."""

    projected = tuple((point[axes[0]], point[axes[1]]) for point in points)
    clipped = _clip_polygon_to_rectangle(
        projected,
        bounds,
        tolerance=tolerance,
    )
    area = _polygon_area_2d(clipped)
    if tolerance > 0.0 and (
        _minimum_polygon_width_2d(clipped) <= tolerance
        or area <= tolerance * tolerance
    ):
        return 0.0
    return area


def _outside_die_distance(
    root: CanonicalRectangularUnderfillFillet,
    point: Point3D,
) -> float:
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    dx = max(x0 - point[0], 0.0, point[0] - x1)
    dy = max(y0 - point[1], 0.0, point[1] - y1)
    return math.hypot(dx, dy)


def _fillet_width(
    root: CanonicalRectangularUnderfillFillet,
    z_value: float,
) -> float:
    ratio = (z_value - root.base_z_mm) / root.wall_height_mm
    if root.uses_elliptical_sweep:
        from .package_v2_swept_fillet import widths_at
        return max(widths_at(root, ratio))
    return root.toe_width_mm + ratio * (
        root.top_width_mm - root.toe_width_mm
    )


def _point_in_polygon_2d(
    point: tuple[float, float],
    polygon: Sequence[tuple[float, float]],
) -> bool:
    inside = False
    previous = polygon[-1]
    for current in polygon:
        if (current[1] > point[1]) != (previous[1] > point[1]):
            crossing_x = (
                (previous[0] - current[0])
                * (point[1] - current[1])
                / (previous[1] - current[1])
                + current[0]
            )
            if point[0] < crossing_x:
                inside = not inside
        previous = current
    return inside


def _point_to_segment_distance_2d(
    point: tuple[float, float],
    first: tuple[float, float],
    second: tuple[float, float],
) -> float:
    dx = second[0] - first[0]
    dy = second[1] - first[1]
    length_squared = dx * dx + dy * dy
    if length_squared == 0.0:
        return math.dist(point, first)
    fraction = max(
        0.0,
        min(
            1.0,
            ((point[0] - first[0]) * dx + (point[1] - first[1]) * dy)
            / length_squared,
        ),
    )
    closest = (first[0] + fraction * dx, first[1] + fraction * dy)
    return math.dist(point, closest)


def _point_to_polygon_distance_2d(
    point: tuple[float, float],
    polygon: Sequence[tuple[float, float]],
) -> float:
    if _point_in_polygon_2d(point, polygon):
        return 0.0
    return min(
        _point_to_segment_distance_2d(point, first, second)
        for first, second in zip(polygon, (*polygon[1:], polygon[0]))
    )


def _rounded_annulus_overlap_positive(
    points: Sequence[Point3D],
    root: CanonicalRectangularUnderfillFillet,
    width: float,
    tolerance: float,
) -> bool:
    """Return whether a planar facet overlaps one exact rounded-rect annulus."""

    if width <= tolerance:
        return False
    x0, y0 = root.die_origin_xy_mm
    x1 = x0 + root.die_size_xy_mm[0]
    y1 = y0 + root.die_size_xy_mm[1]
    from .package_v2_swept_fillet import widths_at
    xm, xp, ym, yp = (widths_at(root, (points[0][2]-root.base_z_mm)/root.wall_height_mm)
                      if root.uses_elliptical_sweep else (width,)*4)
    horizontal = _polygon_rectangle_intersection_area(
        points,
        (x0 - xm, x1 + xp, y0, y1),
        tolerance=tolerance,
    )
    vertical = _polygon_rectangle_intersection_area(
        points,
        (x0, x1, y0 - ym, y1 + yp),
        tolerance=tolerance,
    )
    die = _polygon_rectangle_intersection_area(
        points,
        (x0, x1, y0, y1),
        tolerance=tolerance,
    )
    if horizontal + vertical - 2.0 * die > tolerance * tolerance:
        return True

    projected = tuple((point[0], point[1]) for point in points)
    for center, bounds, wx, wy in (
        ((x0, y0), (x0 - xm, x0, y0 - ym, y0), xm, ym),
        ((x0, y1), (x0 - xm, x0, y1, y1 + yp), xm, yp),
        ((x1, y0), (x1, x1 + xp, y0 - ym, y0), xp, ym),
        ((x1, y1), (x1, x1 + xp, y1, y1 + yp), xp, yp),
    ):
        if wx <= tolerance or wy <= tolerance:
            continue
        clipped = _clip_polygon_to_rectangle(
            projected,
            bounds,
            tolerance=tolerance,
        )
        if (
            _polygon_area_2d(clipped) > tolerance * tolerance
            and _minimum_polygon_width_2d(clipped) > tolerance
            and _point_to_polygon_distance_2d((0., 0.), tuple(((p[0]-center[0])/wx, (p[1]-center[1])/wy) for p in clipped))
            < 1. - tolerance/min(wx, wy)
        ):
            return True
    return False


def _positive_overlap_sides(
    fragment: CanonicalGeometryFragment,
    package_points: Sequence[Point3D],
    tolerance: float,
    *,
    areas: dict[str, float | None] | None = None,
) -> tuple[str, ...]:
    """Discover every canonical side with positive-area facet overlap.

    Unlike :func:`_side_for_points`, this deliberately detects partial overlap.
    A partial immutable Frozen facet is not returned as a match: the caller
    rejects it because making a conformal seam would require splitting it.
    """

    points = tuple(
        _package_to_fragment_local(point, fragment.placement)
        for point in package_points
    )
    root = fragment.root
    from .package_v2_geometry import CanonicalUnion, CanonicalDifference

    if isinstance(root, (CanonicalUnion, CanonicalDifference)):
        from .package_v2_orthogonal_domain_planning import rectilinear_side_overlaps

        overlaps = rectilinear_side_overlaps(root, points, tolerance)
        if areas is not None:
            areas.update(overlaps)
        return tuple(sorted(overlaps))
    sides: set[str] = set()

    last_rectangle_area = 0.0

    def rectangle_overlap(
        *,
        plane_axis: int,
        plane_coordinate: float,
        axes: tuple[int, int],
        bounds: tuple[float, float, float, float],
    ) -> bool:
        nonlocal last_rectangle_area
        last_rectangle_area = 0.0
        if not _all_on_plane(
            points,
            plane_axis,
            plane_coordinate,
            tolerance,
        ):
            return False
        last_rectangle_area = _polygon_rectangle_intersection_area(
            points,
            bounds,
            axes=axes,
            tolerance=tolerance,
        )
        return last_rectangle_area > tolerance * tolerance

    if type(root) is CanonicalBox:
        bounds = tuple(
            (
                root.origin_xyz_mm[axis],
                root.origin_xyz_mm[axis] + root.size_xyz_mm[axis],
            )
            for axis in range(3)
        )
        for name, plane_axis, coordinate, axes in (
            ("x_min", 0, bounds[0][0], (1, 2)),
            ("x_max", 0, bounds[0][1], (1, 2)),
            ("y_min", 1, bounds[1][0], (0, 2)),
            ("y_max", 1, bounds[1][1], (0, 2)),
            ("bottom", 2, bounds[2][0], (0, 1)),
            ("top", 2, bounds[2][1], (0, 1)),
        ):
            first, second = axes
            if rectangle_overlap(
                plane_axis=plane_axis,
                plane_coordinate=coordinate,
                axes=axes,
                bounds=(
                    bounds[first][0],
                    bounds[first][1],
                    bounds[second][0],
                    bounds[second][1],
                ),
            ):
                sides.add(name)
                if areas is not None:
                    areas[name] = last_rectangle_area
    elif type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        x1 = x0 + root.outer_size_xy_mm[0]
        y1 = y0 + root.outer_size_xy_mm[1]
        z1 = z0 + root.height_mm
        hx0 = x0 + root.opening_offset_xy_mm[0]
        hy0 = y0 + root.opening_offset_xy_mm[1]
        hx1 = hx0 + root.opening_size_xy_mm[0]
        hy1 = hy0 + root.opening_size_xy_mm[1]
        for name, coordinate in (("bottom", z0), ("top", z1)):
            if _all_on_plane(points, 2, coordinate, tolerance):
                material_overlap = _polygon_rectangle_intersection_area(
                    points,
                    (x0, x1, y0, y1),
                    tolerance=tolerance,
                ) - _polygon_rectangle_intersection_area(
                    points,
                    (hx0, hx1, hy0, hy1),
                    tolerance=tolerance,
                )
                if material_overlap > tolerance * tolerance:
                    sides.add(name)
                    if areas is not None:
                        areas[name] = material_overlap
        for name, axis, coordinate, tangent, tangent_bounds in (
            ("outer_x_min", 0, x0, 1, (y0, y1)),
            ("outer_x_max", 0, x1, 1, (y0, y1)),
            ("outer_y_min", 1, y0, 0, (x0, x1)),
            ("outer_y_max", 1, y1, 0, (x0, x1)),
            ("inner_x_min", 0, hx0, 1, (hy0, hy1)),
            ("inner_x_max", 0, hx1, 1, (hy0, hy1)),
            ("inner_y_min", 1, hy0, 0, (hx0, hx1)),
            ("inner_y_max", 1, hy1, 0, (hx0, hx1)),
        ):
            if rectangle_overlap(
                plane_axis=axis,
                plane_coordinate=coordinate,
                axes=(tangent, 2),
                bounds=(*tangent_bounds, z0, z1),
            ):
                sides.add(name)
                if areas is not None:
                    areas[name] = last_rectangle_area
    elif type(root) is CanonicalRectangularUnderfillFillet:
        x0, y0 = root.die_origin_xy_mm
        x1 = x0 + root.die_size_xy_mm[0]
        y1 = y0 + root.die_size_xy_mm[1]
        z0 = root.base_z_mm
        z1 = z0 + root.wall_height_mm
        for name, coordinate in (("base", z0), ("cap", z1)):
            if _all_on_plane(points, 2, coordinate, tolerance) and (
                _rounded_annulus_overlap_positive(
                    points,
                    root,
                    _fillet_width(root, coordinate),
                    tolerance,
                )
            ):
                sides.add(name)
                if areas is not None:
                    # Exact curved clipping is not provided by this predicate.
                    # Never report the whole facet area for a partial overlap.
                    areas[name] = None
        for name, axis, coordinate, tangent, tangent_bounds in (
            ("die_x_min", 0, x0, 1, (y0, y1)),
            ("die_x_max", 0, x1, 1, (y0, y1)),
            ("die_y_min", 1, y0, 0, (x0, x1)),
            ("die_y_max", 1, y1, 0, (x0, x1)),
        ):
            if rectangle_overlap(
                plane_axis=axis,
                plane_coordinate=coordinate,
                axes=(tangent, 2),
                bounds=(*tangent_bounds, z0, z1),
            ):
                sides.add(name)
                if areas is not None:
                    areas[name] = last_rectangle_area

        from .package_v2_swept_fillet import widths_at
        xm, xp, ym, yp = widths_at(root)
        sxm, sxp, sym, syp = [(end-w)/root.wall_height_mm for w, end in zip((xm, xp, ym, yp), widths_at(root, 1.))]
        panels = (
            (0, 1, 1.0, sxm, x0 - xm + sxm * z0),
            (0, 1, 1.0, -sxp, x1 + xp - sxp * z0),
            (1, 0, 1.0, sym, y0 - ym + sym * z0),
            (1, 0, 1.0, -syp, y1 + yp - syp * z0),
        )
        for normal_axis, tangent, normal_factor, z_factor, constant in panels:
            if all(
                abs(
                    normal_factor * point[normal_axis]
                    + z_factor * point[2]
                    - constant
                )
                <= tolerance * math.hypot(normal_factor, z_factor)
                for point in points
            ):
                tangent_bounds = (y0, y1) if tangent == 1 else (x0, x1)
                projected_area = _polygon_rectangle_intersection_area(
                    points,
                    (*tangent_bounds, z0, z1),
                    axes=(tangent, 2),
                    tolerance=tolerance,
                )
                if projected_area > tolerance * tolerance:
                    sides.add("analytic_free_surface")
                    if areas is not None:
                        areas["analytic_free_surface"] = projected_area * math.hypot(normal_factor, z_factor)
    else:
        raise FrozenBoundaryMatchingError(
            "Frozen boundary contact discovery does not support this canonical primitive"
        )
    return tuple(sorted(sides))


def _owner_element_is_outside_target(
    fragment: CanonicalGeometryFragment,
    side_name: str,
    owner_element: VolumeElement,
    package_by_tag: Mapping[int, Point3D],
    tolerance: float,
) -> bool:
    """Prove that a Frozen face owner lies outside the Generated solid."""

    centroid_package = tuple(
        math.fsum(package_by_tag[node][axis] for node in owner_element.node_tags)
        / len(owner_element.node_tags)
        for axis in range(3)
    )
    return _owner_point_is_outside_target(fragment, side_name, centroid_package, tolerance)


def _owner_point_is_outside_target(fragment, side_name, centroid_package, tolerance):
    """Geometry-only half-space test, also used by the lightweight preview."""
    point = _package_to_fragment_local(
        centroid_package,  # type: ignore[arg-type]
        fragment.placement,
    )
    root = fragment.root
    if side_name.startswith("orth:"):
        _, axis, end, coordinate = side_name.split(":")
        axis, end, coordinate = int(axis), int(end), float.fromhex(coordinate)
        return (
            point[axis] > coordinate + tolerance
            if end
            else point[axis] < coordinate - tolerance
        )
    if type(root) is CanonicalBox:
        bounds = tuple(
            (
                root.origin_xyz_mm[axis],
                root.origin_xyz_mm[axis] + root.size_xyz_mm[axis],
            )
            for axis in range(3)
        )
        directions = {
            "x_min": point[0] < bounds[0][0] - tolerance,
            "x_max": point[0] > bounds[0][1] + tolerance,
            "y_min": point[1] < bounds[1][0] - tolerance,
            "y_max": point[1] > bounds[1][1] + tolerance,
            "bottom": point[2] < bounds[2][0] - tolerance,
            "top": point[2] > bounds[2][1] + tolerance,
        }
    elif type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        x1 = x0 + root.outer_size_xy_mm[0]
        y1 = y0 + root.outer_size_xy_mm[1]
        z1 = z0 + root.height_mm
        hx0 = x0 + root.opening_offset_xy_mm[0]
        hy0 = y0 + root.opening_offset_xy_mm[1]
        hx1 = hx0 + root.opening_size_xy_mm[0]
        hy1 = hy0 + root.opening_size_xy_mm[1]
        directions = {
            "outer_x_min": point[0] < x0 - tolerance,
            "outer_x_max": point[0] > x1 + tolerance,
            "outer_y_min": point[1] < y0 - tolerance,
            "outer_y_max": point[1] > y1 + tolerance,
            "inner_x_min": point[0] > hx0 + tolerance,
            "inner_x_max": point[0] < hx1 - tolerance,
            "inner_y_min": point[1] > hy0 + tolerance,
            "inner_y_max": point[1] < hy1 - tolerance,
            "bottom": point[2] < z0 - tolerance,
            "top": point[2] > z1 + tolerance,
        }
    elif type(root) is CanonicalRectangularUnderfillFillet:
        x0, y0 = root.die_origin_xy_mm
        x1 = x0 + root.die_size_xy_mm[0]
        y1 = y0 + root.die_size_xy_mm[1]
        z0 = root.base_z_mm
        z1 = z0 + root.wall_height_mm
        directions = {
            "die_x_min": point[0] > x0 + tolerance,
            "die_x_max": point[0] < x1 - tolerance,
            "die_y_min": point[1] > y0 + tolerance,
            "die_y_max": point[1] < y1 - tolerance,
            "base": point[2] < z0 - tolerance,
            "cap": point[2] > z1 + tolerance,
        }
    else:  # guarded by contact discovery
        return False
    return directions.get(side_name, False)


def _side_for_points(
    fragment: CanonicalGeometryFragment,
    package_points: Sequence[Point3D],
    tolerance: float,
) -> str | None:
    points = tuple(
        _package_to_fragment_local(point, fragment.placement)
        for point in package_points
    )
    root = fragment.root
    from .package_v2_geometry import CanonicalUnion, CanonicalDifference

    if isinstance(root, (CanonicalUnion, CanonicalDifference)):
        from .package_v2_orthogonal_domain_planning import rectilinear_side_overlaps

        overlaps = rectilinear_side_overlaps(root, points, tolerance)
        for side, area in overlaps.items():
            axis = int(side.split(":")[1])
            axes = [a for a in range(3) if a != axis]
            total = _polygon_area_2d(tuple((p[axes[0]], p[axes[1]]) for p in points))
            if abs(area - total) <= max(tolerance * tolerance, total * 1e-9):
                return side
        return None
    if type(root) is CanonicalBox:
        bounds = tuple(
            (
                root.origin_xyz_mm[axis],
                root.origin_xyz_mm[axis] + root.size_xyz_mm[axis],
            )
            for axis in range(3)
        )
        names = (
            ("x_min", 0, bounds[0][0]),
            ("x_max", 0, bounds[0][1]),
            ("y_min", 1, bounds[1][0]),
            ("y_max", 1, bounds[1][1]),
            ("bottom", 2, bounds[2][0]),
            ("top", 2, bounds[2][1]),
        )
        for name, axis, coordinate in names:
            if _all_on_plane(points, axis, coordinate, tolerance) and all(
                _within(point[other], bounds[other], tolerance)
                for point in points
                for other in range(3)
                if other != axis
            ):
                return name
        return None

    if type(root) is CanonicalRectangularFrameExtrusion:
        x0, y0, z0 = root.outer_origin_xyz_mm
        x1 = x0 + root.outer_size_xy_mm[0]
        y1 = y0 + root.outer_size_xy_mm[1]
        z1 = z0 + root.height_mm
        ix0 = x0 + root.opening_offset_xy_mm[0]
        iy0 = y0 + root.opening_offset_xy_mm[1]
        ix1 = ix0 + root.opening_size_xy_mm[0]
        iy1 = iy0 + root.opening_size_xy_mm[1]
        for name, coordinate in (("bottom", z0), ("top", z1)):
            if (
                _all_on_plane(points, 2, coordinate, tolerance)
                and all(
                    _within(point[0], (x0, x1), tolerance)
                    and _within(point[1], (y0, y1), tolerance)
                    for point in points
                )
                and _polygon_rectangle_intersection_area(
                    points,
                    (ix0, ix1, iy0, iy1),
                    tolerance=tolerance,
                )
                <= tolerance * tolerance
            ):
                return name
        vertical = (
            ("outer_x_min", 0, x0, 1, (y0, y1)),
            ("outer_x_max", 0, x1, 1, (y0, y1)),
            ("outer_y_min", 1, y0, 0, (x0, x1)),
            ("outer_y_max", 1, y1, 0, (x0, x1)),
            ("inner_x_min", 0, ix0, 1, (iy0, iy1)),
            ("inner_x_max", 0, ix1, 1, (iy0, iy1)),
            ("inner_y_min", 1, iy0, 0, (ix0, ix1)),
            ("inner_y_max", 1, iy1, 0, (ix0, ix1)),
        )
        for name, axis, coordinate, tangent, tangent_bounds in vertical:
            if (
                _all_on_plane(points, axis, coordinate, tolerance)
                and all(_within(point[tangent], tangent_bounds, tolerance) for point in points)
                and all(_within(point[2], (z0, z1), tolerance) for point in points)
            ):
                return name
        return None

    if type(root) is CanonicalRectangularUnderfillFillet:
        x0, y0 = root.die_origin_xy_mm
        x1 = x0 + root.die_size_xy_mm[0]
        y1 = y0 + root.die_size_xy_mm[1]
        z0 = root.base_z_mm
        z1 = z0 + root.wall_height_mm
        vertical = (
            ("die_x_min", 0, x0, 1, (y0, y1)),
            ("die_x_max", 0, x1, 1, (y0, y1)),
            ("die_y_min", 1, y0, 0, (x0, x1)),
            ("die_y_max", 1, y1, 0, (x0, x1)),
        )
        for name, axis, coordinate, tangent, tangent_bounds in vertical:
            if (
                _all_on_plane(points, axis, coordinate, tolerance)
                and all(_within(point[tangent], tangent_bounds, tolerance) for point in points)
                and all(_within(point[2], (z0, z1), tolerance) for point in points)
            ):
                return name
        for name, coordinate in (("base", z0), ("cap", z1)):
            if not _all_on_plane(points, 2, coordinate, tolerance):
                continue
            width = _fillet_width(root, coordinate)
            from .package_v2_swept_fillet import radial_fraction
            if (
                all(
                    (_outside_die_distance(root, point) <= width + tolerance if not root.uses_elliptical_sweep
                     else radial_fraction(root, point) <= 1.+tolerance)
                    for point in points
                )
                and _polygon_rectangle_intersection_area(
                    points,
                    (x0, x1, y0, y1),
                    tolerance=tolerance,
                )
                <= tolerance * tolerance
            ):
                return name
        return None
    raise FrozenBoundaryMatchingError(
        "Frozen boundary matcher does not support this canonical primitive"
    )


def match_frozen_component_boundaries(
    snapshot: FrozenSourceSnapshot,
    *,
    frozen_component_global_id: str,
    target_fragments: Mapping[str, CanonicalGeometryFragment],
    allow_empty: bool = False,
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
) -> tuple[MatchedFrozenBoundaryPatch, ...]:
    """Match real Frozen exterior facets to canonical target boundaries."""

    if type(snapshot) is not FrozenSourceSnapshot:
        raise FrozenBoundaryMatchingError(
            "snapshot must be an exact FrozenSourceSnapshot"
        )
    if not isinstance(allow_empty, bool):
        raise FrozenBoundaryMatchingError("allow_empty must be boolean")
    try:
        tolerance = validate_interface_geometry_tolerance_mm(
            interface_geometry_tolerance_mm
        )
    except ValueError as error:
        raise FrozenBoundaryMatchingError(str(error)) from error
    if not isinstance(frozen_component_global_id, str) or not frozen_component_global_id:
        raise FrozenBoundaryMatchingError(
            "frozen_component_global_id is invalid"
        )
    if not isinstance(target_fragments, Mapping) or not target_fragments:
        raise FrozenBoundaryMatchingError("target_fragments must be a mapping")
    if any(
        not isinstance(component_id, str)
        or not component_id
        or type(fragment) is not CanonicalGeometryFragment
        for component_id, fragment in target_fragments.items()
    ):
        raise FrozenBoundaryMatchingError("target fragment mapping is invalid")
    matches = tuple(
        (local_id, component)
        for local_id, component in snapshot.components.items()
        if component.global_component_id == frozen_component_global_id
    )
    if len(matches) != 1:
        raise FrozenBoundaryMatchingError(
            "Frozen Component is absent or ambiguous"
        )
    _local_id, component = matches[0]
    element_by_tag = {element.tag: element for element in snapshot.mesh.elements}
    node_by_tag = {node.tag: node.coordinates for node in snapshot.mesh.nodes}
    package_by_tag = {
        tag: _frozen_to_package(point, snapshot)
        for tag, point in node_by_tag.items()
    }
    coordinate_scale = max(
        1.0,
        *(
            abs(coordinate)
            for point in package_by_tag.values()
            for coordinate in point
        ),
    )
    degeneracy_length = max(1.0e-15, 32.0 * math.ulp(coordinate_scale))
    degeneracy_area = degeneracy_length * degeneracy_length
    component_element_tags = set(component.element_tags)
    if any(tag not in element_by_tag for tag in component_element_tags):
        raise FrozenBoundaryMatchingError(
            "Frozen Component references an unknown element"
        )
    # Exterior ownership is global to the immutable Frozen mesh.  Restricting
    # the owner count to one Physical Component would incorrectly expose an
    # internal material interface as a free Frozen boundary.
    face_owners: dict[
        tuple[int, ...], list[tuple[VolumeElement, int, tuple[int, ...]]]
    ] = defaultdict(list)
    for element in snapshot.mesh.elements:
        specification = _SPEC_BY_KIND.get(element.kind)
        if specification is None:
            raise FrozenBoundaryMatchingError(
                "Frozen Component contains an unsupported element kind"
            )
        for local_face_index, local_face in enumerate(
            specification[2]
        ):
            facet = tuple(element.node_tags[index] for index in local_face)
            face_owners[tuple(sorted(facet))].append(
                (element, local_face_index, facet)
            )
    if any(len(owners) > 2 for owners in face_owners.values()):
        raise FrozenBoundaryMatchingError("Frozen Component mesh is non-manifold")
    exterior = tuple(
        owners[0]
        for owners in face_owners.values()
        if len(owners) == 1 and owners[0][0].tag in component_element_tags
    )
    if not exterior:
        raise FrozenBoundaryMatchingError("Frozen Component has no exterior facets")

    grouped: dict[
        tuple[str, str, str], list[MatchedFrozenFacet]
    ] = defaultdict(list)
    for element, local_face_index, facet in exterior:
        package_points = tuple(package_by_tag[tag] for tag in facet)
        area = _area(package_points)
        if not math.isfinite(area) or area <= degeneracy_area:
            raise FrozenBoundaryMatchingError(
                "Frozen exterior contains a zero-area facet"
            )
        candidates: list[tuple[str, str, str]] = []
        partial_or_unsupported: list[tuple[str, str, str]] = []
        for component_id, fragment in target_fragments.items():
            side = _side_for_points(fragment, package_points, tolerance)
            overlaps = _positive_overlap_sides(
                fragment,
                package_points,
                tolerance,
            )
            if side is not None:
                if not _owner_element_is_outside_target(
                    fragment,
                    side,
                    element,
                    package_by_tag,
                    tolerance,
                ):
                    raise FrozenBoundaryMatchingError(
                        "Frozen/Generated volumes lie on the same side of a "
                        "matched boundary; positive-volume overlap is not an "
                        "interface"
                    )
                candidates.append((component_id, fragment.fragment_id, side))
                partial_or_unsupported.extend(
                    (component_id, fragment.fragment_id, value)
                    for value in overlaps
                    if value != side
                )
            else:
                partial_or_unsupported.extend(
                    (component_id, fragment.fragment_id, value)
                    for value in overlaps
                )
        if partial_or_unsupported:
            raise FrozenBoundaryMatchingError(
                "immutable Frozen exterior facet has a partial or unsupported "
                "positive-area Generated contact and cannot be split: "
                f"{tuple(sorted(partial_or_unsupported))!r}"
            )
        if len(candidates) > 1:
            raise FrozenBoundaryMatchingError(
                "one positive-area Frozen exterior facet matches multiple "
                f"generated boundaries: {candidates!r}"
            )
        if not candidates:
            continue
        candidate = candidates[0]
        grouped[candidate].append(
            MatchedFrozenFacet(
                facet,
                element.tag,
                element.kind,
                local_face_index,
                area,
            )
        )
    patches: list[MatchedFrozenBoundaryPatch] = []
    for (component_id, fragment_id, side), facets in sorted(grouped.items()):
        referenced = {node for facet in facets for node in facet.source_node_tags}
        patches.append(
            MatchedFrozenBoundaryPatch(
                component_id,
                fragment_id,
                side,
                {tag: package_by_tag[tag] for tag in sorted(referenced)},
                tuple(
                    sorted(
                        facets,
                        key=lambda value: (
                            tuple(sorted(value.source_node_tags)),
                            value.owner_element_tag,
                        ),
                    )
                ),
            )
        )
    if not patches and not allow_empty:
        raise FrozenBoundaryMatchingError(
            "Frozen Component has no positive-area generated boundary match"
        )
    return tuple(patches)


__all__ = [
    "FrozenBoundaryMatchingError",
    "MatchedFrozenBoundaryPatch",
    "MatchedFrozenFacet",
    "match_frozen_component_boundaries",
]
