"""Production Package V2 job execution and report publication.

The worker never accepts a persisted compiled, trace, or assembly plan.  It
replays the immutable job request, recompiles the exact embedded source,
reloads every Frozen artifact, verifies the launch identity, and only then
dispatches one of the currently complete mesh paths:

* generated-only Box/rectangular-frame geometry -> role-free per-Component
  ``structured_sweep`` / ``orthogonal_hex`` / ``conformal_hybrid`` mesh;
* one Frozen source plus one or more generated Components -> the role-free
  authority-DAG executor, with each Component independently selecting
  ``structured_sweep``, ``orthogonal_hex`` or ``conformal_hybrid`` and each
  Frozen interface independently selecting its preservation policy.

Multiple Frozen sources remain outside this executor because their immutable
node namespaces need a separate multi-source assembly contract. Numerical
policy not present in the source is fixed by
``PACKAGE_V2_WORKER_IMPLEMENTATION_VERSION`` and therefore by the trusted
runtime profile.  Per-Component strategy, target edge and transition distance
must be explicit.

The mesh is built in a private staging directory.  The final MSH and sidecars
are individually replaced atomically under one bundle lock, with the report
published last as the readiness marker.  Every report binds the freshly
recompiled source/plan, launch/request identities, current Frozen snapshots,
reopened mesh evidence, and exact output artifact hashes.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import tempfile
from types import MappingProxyType
from typing import Mapping

from .component_interface import ComponentMeshRequirement
from .package_assembly import (
    GeneratedComponentMeshControl,
    OrthogonalHexMeshStrategy,
    StructuredSweepMeshStrategy,
)
from .output_artifacts import (
    atomic_output_path,
    exclusive_output_lock,
    file_artifact,
    paths_refer_to_same_file,
)
from .package_v2_compile import (
    PackageV2CompileResult,
    compile_package_v2,
)
from .package_v2_frozen import (
    FrozenArtifactIdentity,
    FrozenSourceSnapshot,
    audit_frozen_source_snapshot,
    load_compiled_frozen_source,
)
from .package_v2_job import (
    PackageV2JobRequest,
    PackageV2RuntimeProfile,
    parse_package_v2_job_request,
    verify_package_v2_job_request,
)
from .package_v2_progress import (
    PackageV2ProgressSink,
    PackageV2ProgressUpdate,
)
from .package_v2_generated_mixed_mesher import (
    GeneratedMixedMeshControls,
    GeneratedMixedMeshSummary,
    build_generated_mixed_mesh,
)
from .package_v2_mesher import (
    GeneratedComponentKey,
)
from .package_v2_mixed_mesh_audit import (
    MixedMeshReopenAudit,
    audit_reopened_mixed_volume_mesh,
    numbered_mixed_mesh_sha256,
)
from .package_v2_mesh_ordering import MeshOrderingPlan
from .package_v2_mesh_sizing import MeshSeedPolicy
from .package_v2_mixed_execution_context import build_mixed_execution_context
from .package_v2_mixed_source_executor import (
    MixedSourceExecutionResult,
    execute_role_free_mixed_source,
    write_role_free_mixed_source,
)
from .package_v2_mixed_source_lowering import (
    MixedSourceLowering,
    lower_mixed_source,
)
from .volume_mesh import ELEMENT_SPECS
from .gmsh_candidate_runtime import (
    DEFAULT_CANDIDATE_POLICY, DIRECT_VOLUME_THREADS_BY_ALGORITHM, candidate_execution_context,
)
from .package_v2_quality_history import QUALITY_PROGRESS_PREFIX


PACKAGE_V2_WORKER_IMPLEMENTATION_VERSION = "worker-3.22.0"
PACKAGE_V2_WORKER_PROFILE_ID = "easymesh-package-v2-role-free-mixed-v29"
PACKAGE_V2_FROZEN_IMPORT_VERSION = "frozen-mesh-sha256-v4"
PACKAGE_V2_WORKER_PARAMETERS_SCHEMA = "easymesh-package-v2-worker-parameters-v4"
PACKAGE_V2_WORKER_REPORT_SCHEMA = "easymesh-package-v2-worker-report-v7"

_GENERATED_RANDOM_SEED = 1
_GENERATED_OPTIMIZE = True
_GENERATED_MINIMUM_QUALITY = 0.03
_MAXIMUM_ELEMENT_COUNT = 2_000_000
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_MAPPING_PROXY_TYPE = type(MappingProxyType({}))


class PackageV2WorkerError(RuntimeError):
    """Raised when a request cannot produce one complete Package mesh."""


class PackageV2WorkerMode(str, Enum):
    GENERATED_MIXED = "generated_mixed_three_topology_v1"
    ROLE_FREE_FROZEN_GENERATED_MIXED = "role_free_frozen_generated_mixed_v1"


def _emit_progress(
    sink: PackageV2ProgressSink | None,
    request: PackageV2JobRequest,
    *,
    phase: str,
    phase_index: int,
    state: str,
    message: str,
    current: int | None = None,
    total: int | None = None,
    unit: str | None = None,
    mode: PackageV2WorkerMode | None = None,
    diagnostic: dict[str, object] | None = None,
) -> None:
    """Best-effort observability that never changes mesh semantics."""

    if sink is None:
        return
    try:
        sink(
            PackageV2ProgressUpdate(
                request.job_id,
                request.sha256,
                phase,
                phase_index,
                state,
                message,
                current=current,
                total=total,
                unit=unit,
                mode=None if mode is None else mode.value,
                diagnostic=diagnostic,
            )
        )
    except Exception:
        # A progress transport is non-authoritative.  The report-last contract,
        # not UI observability, decides whether the mesh succeeds.
        return


def _installed_gmsh_version() -> str:
    try:
        import gmsh
    except Exception as error:
        raise PackageV2WorkerError(
            "the Package V2 worker requires the installed Gmsh runtime"
        ) from error
    value = getattr(gmsh, "__version__", None)
    if type(value) is not str or not value:
        raise PackageV2WorkerError("the installed Gmsh version is unavailable")
    return value


def current_package_v2_runtime_profile() -> PackageV2RuntimeProfile:
    """Return the only runtime profile trusted by this installed worker."""

    try:
        return PackageV2RuntimeProfile(
            PACKAGE_V2_WORKER_PROFILE_ID,
            PACKAGE_V2_WORKER_IMPLEMENTATION_VERSION,
            _installed_gmsh_version(),
            PACKAGE_V2_FROZEN_IMPORT_VERSION,
        )
    except PackageV2WorkerError:
        raise
    except Exception as error:
        raise PackageV2WorkerError(
            "cannot construct the current Package V2 runtime profile"
        ) from error


def _canonical_json(value: object) -> str:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    except (OverflowError, TypeError, UnicodeEncodeError, ValueError) as error:
        raise PackageV2WorkerError(
            "worker evidence is not canonical UTF-8 JSON"
        ) from error


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _artifact_from_bytes(path: Path, value: bytes) -> dict[str, str | int]:
    return {
        "path": str(path),
        "size_bytes": len(value),
        "sha256": _sha256_bytes(value),
    }


def _audit_artifact(value: object, *, expected_path: Path) -> Mapping[str, str | int]:
    if type(value) not in (dict, _MAPPING_PROXY_TYPE):
        raise PackageV2WorkerError("worker artifact evidence must be a mapping")
    if set(value) != {"path", "size_bytes", "sha256"}:
        raise PackageV2WorkerError("worker artifact evidence is incomplete")
    path = value["path"]
    size = value["size_bytes"]
    digest = value["sha256"]
    if (
        type(path) is not str
        or path != str(expected_path)
        or type(size) is not int
        or size < 0
        or type(digest) is not str
        or _SHA256.fullmatch(digest) is None
    ):
        raise PackageV2WorkerError("worker artifact evidence is invalid")
    return MappingProxyType(dict(value))


@dataclass(frozen=True, slots=True)
class PackageV2WorkerSummary:
    """Immutable, report-ready evidence returned after bundle publication."""

    mode: PackageV2WorkerMode
    output_mesh_path: str
    parameters_path: str
    report_path: str
    request_sha256: str
    launch_identity_sha256: str
    raw_source_sha256: str
    compiled_plan_sha256: str
    snapshot_numbered_sha256: tuple[tuple[str, str], ...]
    mesh_numbered_sha256: str
    report_binding_sha256: str
    artifacts: Mapping[str, Mapping[str, str | int]]
    complete_package_mesh: bool
    report_ready: bool

    def __post_init__(self) -> None:
        if type(self.mode) is not PackageV2WorkerMode:
            raise PackageV2WorkerError("worker summary mode is invalid")
        output = Path(self.output_mesh_path)
        parameters = Path(self.parameters_path)
        report = Path(self.report_path)
        if (
            not output.is_absolute()
            or output.suffix != ".msh"
            or parameters != output.with_suffix(".parameters.json")
            or report != output.with_suffix(".report.json")
        ):
            raise PackageV2WorkerError("worker summary output paths are invalid")
        for field_name in (
            "request_sha256",
            "launch_identity_sha256",
            "raw_source_sha256",
            "compiled_plan_sha256",
            "mesh_numbered_sha256",
            "report_binding_sha256",
        ):
            value = getattr(self, field_name)
            if type(value) is not str or _SHA256.fullmatch(value) is None:
                raise PackageV2WorkerError(
                    f"worker summary {field_name} is invalid"
                )
        if (
            type(self.snapshot_numbered_sha256) is not tuple
            or tuple(sorted(set(self.snapshot_numbered_sha256)))
            != self.snapshot_numbered_sha256
            or any(
                type(value) is not tuple
                or len(value) != 2
                or type(value[0]) is not str
                or not value[0]
                or type(value[1]) is not str
                or _SHA256.fullmatch(value[1]) is None
                for value in self.snapshot_numbered_sha256
            )
        ):
            raise PackageV2WorkerError(
                "worker summary Frozen snapshot evidence is invalid"
            )
        if type(self.artifacts) not in (dict, _MAPPING_PROXY_TYPE) or set(
            self.artifacts
        ) != {"mesh", "parameters", "report"}:
            raise PackageV2WorkerError("worker summary artifact triple is invalid")
        canonical_artifacts = {
            "mesh": _audit_artifact(self.artifacts["mesh"], expected_path=output),
            "parameters": _audit_artifact(
                self.artifacts["parameters"], expected_path=parameters
            ),
            "report": _audit_artifact(
                self.artifacts["report"], expected_path=report
            ),
        }
        object.__setattr__(
            self,
            "artifacts",
            MappingProxyType(canonical_artifacts),
        )
        if self.complete_package_mesh is not True or self.report_ready is not True:
            raise PackageV2WorkerError(
                "worker summary must describe one complete report-ready Package"
            )

    def to_report_dict(self) -> dict[str, object]:
        return {
            "schema": "easymesh-package-v2-worker-summary-v1",
            "mode": self.mode.value,
            "output_mesh_path": self.output_mesh_path,
            "parameters_path": self.parameters_path,
            "report_path": self.report_path,
            "request_sha256": self.request_sha256,
            "launch_identity_sha256": self.launch_identity_sha256,
            "raw_source_sha256": self.raw_source_sha256,
            "compiled_plan_sha256": self.compiled_plan_sha256,
            "snapshot_numbered_sha256": [
                list(value) for value in self.snapshot_numbered_sha256
            ],
            "mesh_numbered_sha256": self.mesh_numbered_sha256,
            "report_binding_sha256": self.report_binding_sha256,
            "artifacts": {
                role: dict(self.artifacts[role])
                for role in ("mesh", "parameters", "report")
            },
            "complete_package_mesh": self.complete_package_mesh,
            "report_ready": self.report_ready,
        }


def _replay_request(request: PackageV2JobRequest) -> PackageV2JobRequest:
    if type(request) is not PackageV2JobRequest:
        raise PackageV2WorkerError("request must be a PackageV2JobRequest")
    try:
        encoded = _canonical_json(request.to_jsonable()).encode("utf-8")
        replayed = parse_package_v2_job_request(encoded)
    except Exception as error:
        raise PackageV2WorkerError("Package V2 job request audit failed") from error
    if replayed != request:
        raise PackageV2WorkerError("Package V2 job request is stale or non-canonical")
    return replayed


def _audit_runtime_profile(
    request: PackageV2JobRequest,
    expected: PackageV2RuntimeProfile,
) -> None:
    if type(expected) is not PackageV2RuntimeProfile:
        raise PackageV2WorkerError(
            "expected_runtime_profile must be a PackageV2RuntimeProfile"
        )
    current = current_package_v2_runtime_profile()
    if expected != current:
        raise PackageV2WorkerError(
            "expected runtime profile is not the current trusted worker profile"
        )
    if request.launch_identity.runtime_profile != current:
        raise PackageV2WorkerError(
            "job runtime profile differs from the trusted worker profile"
        )


def _sidecar_paths(output: Path) -> tuple[Path, Path]:
    return output.with_suffix(".parameters.json"), output.with_suffix(".report.json")


def _reject_output_aliases(request: PackageV2JobRequest) -> None:
    output = Path(request.output_mesh_path)
    parameters, report = _sidecar_paths(output)
    outputs = (output, parameters, report)
    for index, first in enumerate(outputs):
        for second in outputs[index + 1 :]:
            if paths_refer_to_same_file(first, second):
                raise PackageV2WorkerError(
                    "worker output bundle paths alias one another"
                )
    for dependency in request.runtime_dependencies:
        for target in outputs:
            if paths_refer_to_same_file(target, dependency.runtime_path):
                raise PackageV2WorkerError(
                    "worker output bundle aliases an immutable Frozen artifact"
                )


def _audit_compiled_runtime_paths(
    request: PackageV2JobRequest,
    compiled: PackageV2CompileResult,
) -> None:
    dependencies = {
        (value.source_id, value.role): value
        for value in request.runtime_dependencies
    }
    if set(compiled.frozen_source_by_id) != {
        value.source_id for value in request.launch_identity.frozen_sources
    }:
        raise PackageV2WorkerError(
            "recompiled Frozen sources differ from the launch identity"
        )
    for source in compiled.frozen_sources:
        for role in ("mesh",):
            dependency = dependencies.get((source.source_id, role))
            if dependency is None:
                raise PackageV2WorkerError(
                    "job request is missing one Frozen runtime dependency"
                )
            runtime_path = str(source.artifacts.runtime_paths[role].resolve())
            if (
                runtime_path != dependency.runtime_path
                or source.artifacts.declarations[role] != dependency.declaration
            ):
                raise PackageV2WorkerError(
                    "recompiled Frozen runtime path differs from the job request"
                )


def _explicit_generated_mixed_requirements(
    compiled: PackageV2CompileResult,
) -> Mapping[GeneratedComponentKey, ComponentMeshRequirement]:
    """Lower canonical Component-owned controls without role-based policy.

    A generated-only Job is self-describing: topology, target and transition
    are all mandatory on every Component.  The key is the canonical
    ``instance_id/component_id`` pair consumed by the generated mixed mesher;
    material, stack order and geometry role never participate.
    """

    if not compiled.generated_instances:
        raise PackageV2WorkerError(
            "generated-only worker mode requires generated geometry"
        )
    requirements: dict[GeneratedComponentKey, ComponentMeshRequirement] = {}
    for instance in compiled.generated_instances:
        geometry_ids = {
            component.component_id
            for component in instance.geometry_result.geometry.components
        }
        descriptor_ids = {
            component.local_component_id for component in instance.components
        }
        if geometry_ids != descriptor_ids:
            raise PackageV2WorkerError(
                "compiled generated Component controls do not match canonical geometry"
            )
        for component in instance.components:
            control = component.mesh_control
            if control is None:
                raise PackageV2WorkerError(
                    "every generated Component requires an explicit target_edge, "
                    "transition_distance and strategy"
                )
            key = GeneratedComponentKey(
                instance.instance_id,
                component.local_component_id,
            )
            if key in requirements:
                raise PackageV2WorkerError(
                    f"duplicate generated Component mesh requirement {key!r}"
                )
            try:
                requirements[key] = ComponentMeshRequirement(
                    component.local_component_id,
                    control.volume_topology.value,
                    control.target_edge_mm,
                    control.transition_distance_mm,
                )
            except Exception as error:
                raise PackageV2WorkerError(
                    f"generated Component mesh control is invalid for {key!r}"
                ) from error
    return MappingProxyType(requirements)


def _explicit_generated_mesh_controls(
    compiled: PackageV2CompileResult,
) -> Mapping[GeneratedComponentKey, GeneratedComponentMeshControl]:
    """Return exact compiled strategies without reconstructing their options."""

    controls: dict[GeneratedComponentKey, GeneratedComponentMeshControl] = {}
    for instance in compiled.generated_instances:
        for component in instance.components:
            control = component.mesh_control
            if control is None:
                raise PackageV2WorkerError(
                    "every generated Component requires explicit mesh_control"
                )
            key = GeneratedComponentKey(
                instance.instance_id,
                component.local_component_id,
            )
            if key in controls:
                raise PackageV2WorkerError(
                    f"duplicate generated Component mesh control {key!r}"
                )
            controls[key] = control
    return MappingProxyType(controls)


def _is_role_free_frozen_generated_candidate(
    compiled: PackageV2CompileResult,
) -> bool:
    """Select the generic mixed executor from structure, never package roles."""

    return (
        len(compiled.frozen_sources) == 1
        and sum(
            len(instance.components)
            for instance in compiled.generated_instances
        ) >= 1
    )


def _preflight_role_free_frozen_generated(
    compiled: PackageV2CompileResult,
) -> None:
    """Validate only Component-local controls needed by neutral lowering."""

    if not _is_role_free_frozen_generated_candidate(compiled):
        raise PackageV2WorkerError(
            "role-free mixed mode requires one Frozen source and at least one "
            "generated Component"
        )
    _explicit_generated_mixed_requirements(compiled)


def _preflight_compiled_capability(
    compiled: PackageV2CompileResult,
) -> float | None:
    if _is_role_free_frozen_generated_candidate(compiled):
        _preflight_role_free_frozen_generated(compiled)
        # Sizing is Component-local.  A package-wide target size would erase
        # the policy separation that this executor is required to preserve.
        return None
    matches = compiled.assembly_policy.interface_matches
    if not compiled.frozen_sources:
        if not compiled.generated_instances or matches:
            raise PackageV2WorkerError(
                "generated-only worker mode requires generated geometry and no interfaces"
            )
        _explicit_generated_mixed_requirements(compiled)
        # Generated-only sizing is Component-local.  Returning a fabricated
        # package-wide size here would reintroduce the removed uniform policy.
        return None
    raise PackageV2WorkerError(
        "the clean worker supports generated-only Sources or exactly one "
        "Frozen source combined with one or more generated Components"
    )


def _generated_summary_payload(
    value: GeneratedMixedMeshSummary,
    control_by_key: Mapping[
        GeneratedComponentKey, GeneratedComponentMeshControl
    ],
) -> dict[str, object]:
    if (
        not isinstance(control_by_key, Mapping)
        or set(control_by_key) != set(value.components)
        or any(
            type(key) is not GeneratedComponentKey
            or type(control) is not GeneratedComponentMeshControl
            for key, control in control_by_key.items()
        )
    ):
        raise PackageV2WorkerError(
            "generated Component report controls do not match executed Components"
        )
    orthogonal_sicn_exemptions = [
        {
            "instance_id": key.instance_id,
            "component_id": key.component_id,
            "minimum_sicn": component.minimum_sicn,
            "element_count": sum(component.element_kind_counts.values()),
            "required_quality": _GENERATED_MINIMUM_QUALITY,
            "cartesian_hex_verified": component.cartesian_hex_verified,
        }
        for key, component in sorted(value.components.items())
        if component.orthogonal_sicn_aspect_ratio_exempted
    ]
    continuation_sicn_exemptions = [
        {
            "instance_id": key.instance_id,
            "component_id": key.component_id,
            "minimum_sicn": (
                component.orthogonal_hex_continuation_minimum_sicn
            ),
            "element_count": (
                component.orthogonal_hex_continuation_element_count
            ),
            "required_quality": _GENERATED_MINIMUM_QUALITY,
            "producer_component_ids": list(
                component.orthogonal_hex_continuation_producer_component_ids
            ),
            "shared_surface_sizing_contract_ids": list(
                component.orthogonal_hex_continuation_contract_ids
            ),
            "exact_shared_quad_owner_verified": True,
            "cartesian_hex_verified": True,
        }
        for key, component in sorted(value.components.items())
        if component.orthogonal_hex_continuation_sicn_aspect_ratio_exempted
    ]
    raw_all_metrics_floor_met = all(
        metric >= _GENERATED_MINIMUM_QUALITY
        for metric in (
            value.min_scaled_jacobian,
            value.min_sicn,
            value.min_sige,
        )
    )
    strategy_aware_floor_met = (
        value.strategy_aware_quality_floor_met
        and value.min_jacobian_determinant > 0.0
        and value.min_scaled_jacobian >= _GENERATED_MINIMUM_QUALITY
        and value.min_sige >= _GENERATED_MINIMUM_QUALITY
        and all(
            component.minimum_sicn >= _GENERATED_MINIMUM_QUALITY
            or component.orthogonal_sicn_aspect_ratio_exempted
            or component.orthogonal_hex_continuation_sicn_aspect_ratio_exempted
            for component in value.components.values()
        )
    )
    return {
        "schema": "easymesh-package-v2-generated-mixed-summary-v6",
        **value.orthogonal_metadata,
        "node_count": value.node_count,
        "element_count": value.element_count,
        "canonical_fragment_count": sum(
            component.canonical_fragment_count
            for component in value.components.values()
        ),
        "element_kind_counts": dict(value.global_element_kind_counts),
        "components": [
            {
                "instance_id": key.instance_id,
                "component_id": key.component_id,
                "requested_strategy_kind": component.requested_topology,
                "requested": {
                    "strategy": _strategy_payload(control_by_key[key]),
                    "target_edge_mm": component.target_edge_mm,
                    "transition_distance_mm": (
                        component.transition_distance_mm
                    ),
                },
                "target_edge_mm": component.target_edge_mm,
                "transition_distance_mm": component.transition_distance_mm,
                "applied_backend": component.applied_backend,
                "backend_provenance": component.backend_provenance,
                "element_kind_counts": dict(component.element_kind_counts),
                "element_count": sum(component.element_kind_counts.values()),
                "canonical_fragment_count": component.canonical_fragment_count,
                "analytic_target_volume_mm3": (
                    component.analytic_target_volume_mm3
                ),
                "reopened_volume_mm3": component.reopened_volume_mm3,
                "relative_volume_error": component.relative_volume_error,
                "full_boundary_preserved": component.full_boundary_preserved,
                "cartesian_hex_verified": component.cartesian_hex_verified,
                "minimum_sicn": component.minimum_sicn,
                "orthogonal_sicn_aspect_ratio_exempted": (
                    component.orthogonal_sicn_aspect_ratio_exempted
                ),
                "orthogonal_hex_continuation_sicn_aspect_ratio_exempted": (
                    component.orthogonal_hex_continuation_sicn_aspect_ratio_exempted
                ),
            }
            for key, component in sorted(value.components.items())
        ],
        "interfaces": [
            {
                "interface_id": item.interface_id,
                "face_pair_id": item.interface_id,
                "first": [item.first.instance_id, item.first.component_id],
                "second": [item.second.instance_id, item.second.component_id],
                "producer": {
                    "instance_id": item.producer.instance_id,
                    "component_id": item.producer.component_id,
                    "mesh_priority": item.producer_mesh_priority,
                },
                "consumer": {
                    "instance_id": item.consumer.instance_id,
                    "component_id": item.consumer.component_id,
                    "mesh_priority": item.consumer_mesh_priority,
                },
                "required_facet_policy": item.required_facet_policy,
                "geometric_patch_count": item.geometric_patch_count,
                "surface_policy": item.surface_policy,
                "contact_domain": item.contact_domain,
                "analytic_candidate_area_mm2": (
                    item.analytic_candidate_area_mm2
                ),
                "authoritative_contact_area_mm2": (
                    item.authoritative_contact_area_mm2
                ),
                "producer_contact_coverage_ratio": (
                    item.producer_contact_coverage_ratio
                ),
                "consumer_contact_coverage_ratio": (
                    item.consumer_contact_coverage_ratio
                ),
                "analytic_approximation_ratio": (
                    item.analytic_approximation_ratio
                ),
                "analytic_uncovered_area_mm2": (
                    item.analytic_uncovered_area_mm2
                ),
                "analytic_overshoot_area_mm2": (
                    item.analytic_overshoot_area_mm2
                ),
                "negotiated_target_edge_mm": item.negotiated_target_edge_mm,
                "transition_distance_mm_by_component": {
                    f"{item.first.instance_id}/{item.first.component_id}": (
                        item.first_transition_distance_mm
                    ),
                    f"{item.second.instance_id}/{item.second.component_id}": (
                        item.second_transition_distance_mm
                    ),
                },
                "facet_kind_counts": dict(item.facet_kind_counts),
                "shared_node_count": item.shared_node_count,
                "maximum_facet_edge_mm": item.maximum_facet_edge_mm,
                "shared_facet_sha256": item.shared_facet_sha256,
                "shared_nodes_verified": item.shared_nodes_verified,
            }
            for item in value.interfaces
        ],
        "assembly": {
            "complete_support_plane_interface_count": len(
                value.complete_support_plane_interfaces
            ),
            "complete_support_plane_face_count": sum(
                len(item.face_node_tags)
                for item in value.complete_support_plane_interfaces
            ),
            "unpaired_coplanar_free_face_overlap_count": 0,
            "complete_support_plane_interfaces": [
                {
                    "interface_key": item.interface_key,
                    "first_fragment_key": item.first_fragment_key,
                    "second_fragment_key": item.second_fragment_key,
                    "plane_axis": item.plane_axis,
                    "plane_coordinate_mm": item.plane_coordinate_mm,
                    "facet_count": len(item.face_node_tags),
                    "area_mm2": item.area_mm2,
                }
                for item in value.complete_support_plane_interfaces
            ],
        },
        "reopened_audit": {
            "complete_support_plane_interfaces_verified": (
                value.complete_support_plane_interfaces_verified
            ),
            "unpaired_coplanar_free_faces_verified": (
                value.unpaired_coplanar_free_faces_verified
            ),
            "complete_support_plane_area_mm2_by_interface_key": dict(
                value.complete_support_plane_area_mm2_by_interface_key
            ),
            "complete_support_plane_facet_count_by_interface_key": dict(
                value.complete_support_plane_facet_count_by_interface_key
            ),
        },
        "duplicate_node_count": value.duplicate_node_count,
        "nonmanifold_face_count": value.nonmanifold_face_count,
        "quality": {
            "minimum_determinant": value.min_jacobian_determinant,
            "minimum_scaled_jacobian": value.min_scaled_jacobian,
            "minimum_sicn": value.min_sicn,
            "minimum_sige": value.min_sige,
            "required_minimum_signed_quality": _GENERATED_MINIMUM_QUALITY,
            # ``floor_met`` remains the compatibility spelling, but now
            # represents the executed strategy-aware contract.  The raw
            # all-metric comparison remains visible separately.
            "floor_met": strategy_aware_floor_met,
            "strategy_aware_floor_met": strategy_aware_floor_met,
            "raw_all_metrics_floor_met": raw_all_metrics_floor_met,
            "orthogonal_sicn_aspect_ratio_exemption_count": len(
                orthogonal_sicn_exemptions
            ),
            "orthogonal_sicn_aspect_ratio_exemptions": (
                orthogonal_sicn_exemptions
            ),
            "orthogonal_hex_continuation_sicn_aspect_ratio_exemption_count": (
                len(continuation_sicn_exemptions)
            ),
            "orthogonal_hex_continuation_sicn_aspect_ratio_exemptions": (
                continuation_sicn_exemptions
            ),
        },
        "numbered_mesh_sha256": value.numbered_mesh_sha256,
        "written_mesh_reopened_verified": value.written_mesh_reopened_verified,
    }


def _strategy_payload(control: GeneratedComponentMeshControl) -> dict[str, object]:
    strategy: dict[str, object] = {"kind": control.strategy.kind.value}
    if type(control.strategy) is StructuredSweepMeshStrategy:
        strategy["direction"] = control.strategy.direction.value
    elif type(control.strategy) is OrthogonalHexMeshStrategy:
        strategy["directional_near_edge_mm"] = {
            direction.value: value
            for direction, value in control.strategy.directional_near_edge_mm.items()
        }
        strategy["partition_origin_mm"] = (
            None
            if control.strategy.partition_origin_mm is None
            else list(control.strategy.partition_origin_mm)
        )
    if isinstance(control.strategy, (StructuredSweepMeshStrategy, OrthogonalHexMeshStrategy)):
        if control.strategy.sizing != MeshSeedPolicy():
            strategy["sizing"] = control.strategy.sizing.to_dict()
        if control.strategy.partition_origin_mm is not None:
            strategy["partition_origin_mm"] = list(control.strategy.partition_origin_mm)
    for name in ("plane_size_mm", "layer_size_mm", "surface_size_mm", "plane_transition_distance_mm"):
        value = getattr(control.strategy, name, None)
        if value is not None:
            strategy[name] = value
    return strategy


def _component_local_control_payloads(
    compiled: PackageV2CompileResult,
) -> list[dict[str, object]]:
    """Serialize every generated control without collapsing it package-wide."""

    output: list[dict[str, object]] = []
    for instance in sorted(
        compiled.generated_instances,
        key=lambda value: value.instance_id,
    ):
        for component in sorted(
            instance.components,
            key=lambda value: value.global_component_id,
        ):
            control = component.mesh_control
            if control is None:
                raise PackageV2WorkerError(
                    "generated Component lacks its explicit local mesh control"
                )
            output.append(
                {
                    "instance_id": instance.instance_id,
                    "local_component_id": component.local_component_id,
                    "component_id": component.local_component_id,
                    "global_component_id": component.global_component_id,
                    "global_fragment_ids": [
                        binding.global_id for binding in component.fragments
                    ],
                    "strategy": _strategy_payload(control),
                    "mesh_priority": control.mesh_priority,
                    "target_edge_mm": control.target_edge_mm,
                    "transition_distance_mm": control.transition_distance_mm,
                }
            )
    return output


def _frozen_interface_control_payloads(
    compiled: PackageV2CompileResult,
) -> list[dict[str, object]]:
    return [
        {
            "frozen_component_global_id": match.frozen_component.identifier,
            "generated_component_global_id": match.generated_component.identifier,
            "mode": match.mode.value,
            "coupling": match.coupling.value,
        }
        for match in sorted(
            compiled.assembly_policy.interface_matches,
            key=lambda value: (
                value.frozen_component.identifier,
                value.generated_component.identifier,
            ),
        )
    ]


def _mesh_priority_report_payload(
    compiled: PackageV2CompileResult,
) -> dict[str, object]:
    generated: list[dict[str, object]] = []
    for instance in compiled.generated_instances:
        for component in instance.components:
            if component.mesh_control is None:
                raise PackageV2WorkerError(
                    "mesh-priority report cannot omit a Generated Component "
                    "without an explicit mesh control"
                )
            generated.append(
                {
                    "component_kind": "generated",
                    "instance_id": instance.instance_id,
                    "local_component_id": component.local_component_id,
                    "global_component_id": component.global_component_id,
                    "mesh_priority": component.mesh_control.mesh_priority,
                    "immutable": False,
                }
            )
    generated.sort(key=lambda value: int(value["mesh_priority"]))
    frozen = [
        {
            "component_kind": "frozen",
            "source_id": source.source_id,
            "local_component_id": component.local_id,
            "global_component_id": component.global_id,
            "mesh_priority": 0,
            "immutable": True,
        }
        for source in compiled.frozen_sources
        for component in source.components
    ]
    frozen.sort(
        key=lambda value: (
            str(value["source_id"]),
            str(value["local_component_id"]),
        )
    )
    generated_priorities_unique = (
        len({value["mesh_priority"] for value in generated}) == len(generated)
    )
    if not generated_priorities_unique:
        raise PackageV2WorkerError(
            "mesh-priority report found duplicate Generated priorities"
        )
    return {
        "frozen_implicit_priority": 0,
        "frozen_participates_in_generated_reordering": False,
        "frozen_component_count": len(frozen),
        "frozen_components": frozen,
        "generated_priorities_unique": generated_priorities_unique,
        "generated_components": generated,
    }


def _mesh_settings_report_payload(
    compiled: PackageV2CompileResult,
) -> dict[str, object]:
    settings = compiled.parsed_source.document.mesh_settings
    return {
        "parallel_tet_candidates": settings.parallel_tet_candidates,
        "interface_geometry_tolerance": {
            "authored_source": (
                settings.interface_geometry_tolerance_source
            ),
            "resolved_mm": compiled.interface_geometry_tolerance_mm,
            "absolute": True,
            "scope": "interface_geometry_predicates_only",
            "general_node_proximity_merge": False,
        }
    }


def _nested_counts(value: Mapping[str, Mapping[str, int]]) -> dict[str, dict[str, int]]:
    return {
        component_id: dict(sorted(counts.items()))
        for component_id, counts in sorted(value.items())
    }


def _role_free_mixed_execution_payload(
    result: MixedSourceExecutionResult,
    lowering: MixedSourceLowering,
    write_result: object,
    audit: MixedMeshReopenAudit,
    ordering: MeshOrderingPlan,
) -> dict[str, object]:
    """Bind neutral planning, applied backends, seams and reopened evidence."""

    if type(ordering) is not MeshOrderingPlan:
        raise PackageV2WorkerError(
            "mixed report requires the exact executed mesh-ordering plan"
        )
    if tuple(result.plan.component_order) != tuple(
        ordering.generated_component_order
    ):
        raise PackageV2WorkerError(
            "mixed report mesh ordering differs from the executed Component order"
        )
    constraints_by_face_pair_id = {
        value.face_pair_id: value
        for value in ordering.constraints
        if value.face_pair_id is not None
    }
    authority_face_pair_ids = {
        value.face_pair_id for value in result.plan.authority_plan.authorities
    }
    if set(constraints_by_face_pair_id) != authority_face_pair_ids:
        raise PackageV2WorkerError(
            "mixed report ordering constraints do not match actual generated faces"
        )

    authority_entries: list[dict[str, object]] = []
    for authority in result.plan.authority_plan.authorities:
        constraint = constraints_by_face_pair_id[authority.face_pair_id]
        if (
            constraint.producer_component_id
            != authority.producer_component_id
            or constraint.consumer_component_id
            != authority.consumer_component_id
        ):
            raise PackageV2WorkerError(
                "mixed report authority direction differs from mesh priority"
            )
        authority_entries.append(
            {
                "face_pair_id": authority.face_pair_id,
                "interface_id": authority.interface_id,
                "producer": {
                    "component_id": authority.producer_component_id,
                    "fragment_id": authority.producer_fragment_id,
                    "geometric_side": authority.producer_side_name,
                    "mesh_priority": constraint.producer_priority,
                },
                "consumer": {
                    "component_id": authority.consumer_component_id,
                    "fragment_id": authority.consumer_fragment_id,
                    "geometric_side": authority.consumer_side_name,
                    "mesh_priority": constraint.consumer_priority,
                },
                "surface_policy": authority.surface_policy,
                "required_facet_policy": constraint.required_facet_policy,
                "continuity_group_id": authority.continuity_group_id,
                "negotiated_target_edge_mm": (
                    constraint.negotiated_target_edge_mm
                ),
                "continuity_target_edge_mm": (
                    authority.negotiated_target_edge_mm
                ),
                "selection_reason": authority.selection_reason,
                "canonical_candidate_side_coverages": [
                    {
                        "component_id": coverage.component_id,
                        "fragment_id": coverage.fragment_id,
                        "geometric_side": coverage.side_name,
                        "canonical_candidate_interface_area_mm2": (
                            coverage.interface_area_mm2
                        ),
                        "complete_side_area_mm2": coverage.complete_side_area_mm2,
                        "candidate_covers_complete_side": (
                            coverage.covers_complete_side
                        ),
                    }
                    for coverage in authority.side_coverages
                ],
            }
        )

    generated_interfaces: list[dict[str, object]] = []
    for face_pair_id, facet_set in sorted(
        result.interface_facet_sets_by_face_pair_id.items()
    ):
        surface_patch = result.surface_patches_by_face_pair_id[face_pair_id]
        contact_audit = surface_patch.contact_audit
        from .package_v2_mixed_mesh_assembly import _polygon_area_3d
        shared_area = math.fsum(
            _polygon_area_3d(tuple(surface_patch.node_coordinates_package_mm[n] for n in face))
            for face in facet_set.producer_facets
        )
        producer_area = contact_audit.authoritative_contact_area_mm2
        analytic_area = contact_audit.analytic_candidate_area_mm2
        if len(facet_set.producer_facets) == len(surface_patch.facets):
            shared_area = producer_area
        generated_interfaces.append(
            {
                "face_pair_id": face_pair_id,
                "producer_fragment_id": facet_set.producer_fragment_id,
                "consumer_fragment_id": facet_set.consumer_fragment_id,
                "producer_facet_count": len(facet_set.producer_facets),
                "consumer_facet_count": len(facet_set.consumer_facets),
                "contact_domain": contact_audit.contact_domain,
                "analytic_candidate_area_mm2": (
                    contact_audit.analytic_candidate_area_mm2
                ),
                "authoritative_contact_area_mm2": (
                    shared_area
                ),
                "producer_surface_area_mm2": producer_area,
                "producer_surface_facet_count": len(surface_patch.facets),
                "producer_contact_coverage_ratio": (
                    shared_area / producer_area if producer_area else 0.0
                ),
                "surviving_shared_facets_conformal": True,
                "analytic_approximation_ratio": (
                    shared_area / analytic_area
                ),
                "analytic_uncovered_area_mm2": (
                    max(0.0, analytic_area - shared_area)
                ),
                "analytic_overshoot_area_mm2": (
                    max(0.0, shared_area - analytic_area)
                ),
                "semantic_token_count": len(
                    surface_patch.semantic_tokens_by_node_id
                ),
                "semantic_token_sha256": _sha256_bytes(
                    _canonical_json(
                        [
                            [node, token]
                            for node, token in sorted(
                                surface_patch.semantic_tokens_by_node_id.items()
                            )
                        ]
                    ).encode("utf-8")
                ),
                "facet_pair_sha256": _sha256_bytes(
                    _canonical_json(
                        [
                            list(map(list, facet_set.producer_facets)),
                            list(map(list, facet_set.consumer_facets)),
                        ]
                    ).encode("utf-8")
                ),
            }
        )

    frozen_interfaces: list[dict[str, object]] = []
    for facet_set in result.frozen_interface_facet_sets:
        frozen_interfaces.append(
            {
                "frozen_component_global_id": (
                    facet_set.interface_key.frozen_component_global_id
                ),
                "generated_component_global_id": (
                    facet_set.interface_key.generated_component_global_id
                ),
                "generated_fragment_id": facet_set.generated_fragment_id,
                "generated_geometric_side": facet_set.generated_side_name,
                "frozen_facet_count": len(facet_set.frozen_facets),
                "generated_facet_count": len(facet_set.generated_facets),
                "frozen_node_token_count": len(
                    facet_set.semantic_tokens_by_frozen_node_tag
                ),
                "frozen_node_token_sha256": _sha256_bytes(
                    _canonical_json(
                        [
                            [node, token]
                            for node, token in sorted(
                                facet_set.semantic_tokens_by_frozen_node_tag.items()
                            )
                        ]
                    ).encode("utf-8")
                ),
                "facet_pair_sha256": _sha256_bytes(
                    _canonical_json(
                        [
                            list(map(list, facet_set.frozen_facets)),
                            list(map(list, facet_set.generated_facets)),
                        ]
                    ).encode("utf-8")
                ),
            }
        )

    seam_records = [
        [
            seam.seam_key,
            [seam.faces[0].fragment_key, list(seam.faces[0].node_ids)],
            [seam.faces[1].fragment_key, list(seam.faces[1].node_ids)],
            seam.sizing_contract_id,
            seam.target_edge_mm,
        ]
        for seam in result.declared_seams
    ]
    seam_pair_counts: dict[str, int] = {}
    for seam in result.declared_seams:
        pair = " <-> ".join(
            sorted((seam.faces[0].fragment_key, seam.faces[1].fragment_key))
        )
        seam_pair_counts[pair] = seam_pair_counts.get(pair, 0) + 1

    component_entries: dict[str, dict[str, object]] = {}
    orthogonal_sicn_exemptions = {
        component_id: {
            "minimum_sicn": evidence.minimum_sicn,
            "element_count": evidence.element_count,
            "required_quality": evidence.required_quality,
            "cartesian_hex_verified": evidence.cartesian_hex_verified,
        }
        for component_id, evidence in sorted(
            audit.orthogonal_sicn_aspect_ratio_exemptions.items()
        )
    }
    continuation_sicn_exemptions = {
        component_id: {
            "minimum_sicn": evidence.minimum_sicn,
            "element_count": evidence.element_count,
            "required_quality": evidence.required_quality,
            "producer_component_ids": list(evidence.producer_component_ids),
            "shared_surface_sizing_contract_ids": list(
                evidence.shared_surface_sizing_contract_ids
            ),
            "exact_shared_quad_owner_verified": (
                evidence.exact_shared_quad_owner_verified
            ),
            "cartesian_hex_verified": evidence.cartesian_hex_verified,
        }
        for component_id, evidence in sorted(
            audit.orthogonal_hex_continuation_sicn_aspect_ratio_exemptions.items()
        )
    }
    for component_id, requirement in sorted(
        lowering.component_mesh_requirements.items()
    ):
        execution = result.component_evidence_by_id[component_id]
        quality = audit.component_quality[component_id]
        control = lowering.component_mesh_controls_by_global_id[component_id]
        materialized = result.components_by_id[component_id]
        backend_provenance_by_fragment_id = {
            fragment_id: sorted(
                {element.provenance for element in fragment.elements}
            )
            for fragment_id, fragment in sorted(
                materialized.fragments_by_id.items()
            )
        }
        locked_facet_ownership_by_fragment_id: dict[
            str, dict[str, object]
        ] = {}
        for fragment_id, fragment in sorted(
            materialized.fragments_by_id.items()
        ):
            locked_facets = {
                tuple(sorted(facet)): tuple(facet)
                for (candidate_fragment_id, _side), facets in
                materialized.locked_facets_by_fragment_side.items()
                if candidate_fragment_id == fragment_id
                for facet in facets
            }
            if not locked_facets:
                continue
            owner_types = {key: [] for key in locked_facets}
            for element in fragment.elements:
                for local_face in ELEMENT_SPECS[element.gmsh_type][2]:
                    key = tuple(
                        sorted(
                            element.node_ids[index]
                            for index in local_face
                        )
                    )
                    if key in owner_types:
                        owner_types[key].append(element.gmsh_type)
            locked_quads = {
                key for key, facet in locked_facets.items() if len(facet) == 4
            }
            single_owner_count = sum(
                len(owners) == 1 for owners in owner_types.values()
            )
            single_hex_owner_quad_count = sum(
                owner_types[key] == [5] for key in locked_quads
            )
            locked_facet_ownership_by_fragment_id[fragment_id] = {
                "locked_triangle_count": sum(
                    len(facet) == 3 for facet in locked_facets.values()
                ),
                "locked_quad_count": len(locked_quads),
                "single_volume_owner_count": single_owner_count,
                "single_hex_owner_locked_quad_count": (
                    single_hex_owner_quad_count
                ),
                "all_locked_facets_single_owned": (
                    single_owner_count == len(locked_facets)
                ),
                "all_locked_quads_single_hex_owned": (
                    single_hex_owner_quad_count == len(locked_quads)
                ),
            }
        component_entries[component_id] = {
            "requested": {
                "strategy": _strategy_payload(control),
                "target_edge_mm": requirement.target_edge_mm,
                "transition_distance_mm": requirement.transition_distance_mm,
            },
            "applied_backend": execution.applied_backend,
            "backend_provenance_by_fragment_id": (
                backend_provenance_by_fragment_id
            ),
            "backend_evidence_by_fragment_id": {
                fragment_id: dict(evidence)
                for fragment_id, evidence in sorted(
                    materialized.backend_evidence_by_fragment_id.items()
                )
            },
            "locked_facet_ownership_by_fragment_id": (
                locked_facet_ownership_by_fragment_id
            ),
            "materialized_fragment_ids": list(
                execution.materialized_fragment_ids
            ),
            "materializer_element_kind_counts": dict(
                sorted(execution.element_kind_counts.items())
            ),
            "final_element_kind_counts": dict(
                sorted(
                    audit.component_element_kind_counts.get(
                        component_id, {}
                    ).items()
                )
            ),
            "orthogonal_cartesian_hex_verified": (
                audit.orthogonal_cartesian_hex_verified.get(component_id)
            ),
            "orthogonal_sicn_aspect_ratio_exemption": (
                orthogonal_sicn_exemptions.get(component_id)
            ),
            "orthogonal_hex_continuation_sicn_aspect_ratio_exemption": (
                continuation_sicn_exemptions.get(component_id)
            ),
            "quality": {
                "minimum_jacobian_determinant": (
                    quality.minimum_jacobian_determinant
                ),
                "minimum_scaled_jacobian": quality.minimum_scaled_jacobian,
                "minimum_sicn": quality.minimum_sicn,
                "minimum_sige": quality.minimum_sige,
                "volume_mm3": quality.volume_mm3,
            },
        }

    from .package_v2_orthogonal_candidates import orthogonal_execution_metadata

    write_artifact = dict(write_result.artifact)  # type: ignore[attr-defined]
    plan = write_result.plan  # type: ignore[attr-defined]
    return {
        "schema": "easymesh-package-v2-role-free-mixed-execution-v6",
        "executor": "role_free_authority_dag",
        "frozen_source_id": lowering.frozen_source_id,
        "frozen_snapshot_numbered_sha256": (
            lowering.frozen_snapshot_numbered_sha256
        ),
        "component_order": list(result.plan.component_order),
        "mesh_ordering": ordering.to_dict(),
        "pending_dependencies": [],
        **orthogonal_execution_metadata(result, write_result),
        "actual_generated_adjacencies": authority_entries,
        "generated_interface_facet_sets": generated_interfaces,
        "frozen_interface_facet_sets": frozen_interfaces,
        "declared_seams": {
            "count": len(result.declared_seams),
            "fragment_pair_counts": dict(sorted(seam_pair_counts.items())),
            "declaration_sha256": _sha256_bytes(
                _canonical_json(seam_records).encode("utf-8")
            ),
        },
        "components": component_entries,
        "quality": {
            "minimum_determinant": audit.minimum_jacobian_determinant,
            "minimum_scaled_jacobian": audit.minimum_scaled_jacobian,
            "minimum_sicn": audit.minimum_sicn,
            "minimum_sige": audit.minimum_sige,
            "required_minimum_signed_quality": _GENERATED_MINIMUM_QUALITY,
            "floor_met": audit.strategy_aware_quality_floor_met,
            "strategy_aware_floor_met": (
                audit.strategy_aware_quality_floor_met
            ),
            "raw_all_metrics_floor_met": all(
                metric >= _GENERATED_MINIMUM_QUALITY
                for metric in (
                    audit.minimum_scaled_jacobian,
                    audit.minimum_sicn,
                    audit.minimum_sige,
                )
            ),
            "orthogonal_sicn_aspect_ratio_exemption_count": len(
                orthogonal_sicn_exemptions
            ),
            "orthogonal_sicn_aspect_ratio_exemptions": (
                orthogonal_sicn_exemptions
            ),
            "orthogonal_hex_continuation_sicn_aspect_ratio_exemption_count": (
                len(continuation_sicn_exemptions)
            ),
            "orthogonal_hex_continuation_sicn_aspect_ratio_exemptions": (
                continuation_sicn_exemptions
            ),
        },
        "assembly": {
            "node_count": plan.audit.node_count,
            "element_count": plan.audit.element_count,
            "free_face_count": plan.audit.free_face_count,
            "internal_face_count": plan.audit.internal_face_count,
            "declared_seam_count": plan.audit.declared_seam_count,
            "declared_seam_face_count": plan.audit.declared_seam_face_count,
            "complete_support_plane_interface_count": (
                plan.audit.complete_support_plane_interface_count
            ),
            "complete_support_plane_face_count": (
                plan.audit.complete_support_plane_face_count
            ),
            "unpaired_coplanar_free_face_overlap_count": (
                plan.audit.unpaired_coplanar_free_face_overlap_count
            ),
            "complete_support_plane_interfaces": [
                {
                    "interface_key": value.interface_key,
                    "first_fragment_key": value.first_fragment_key,
                    "second_fragment_key": value.second_fragment_key,
                    "plane_axis": value.plane_axis,
                    "plane_coordinate_mm": value.plane_coordinate_mm,
                    "facet_count": len(value.face_node_tags),
                    "area_mm2": value.area_mm2,
                }
                for value in plan.complete_support_plane_interfaces
            ],
            "component_kind_counts": _nested_counts(
                plan.audit.component_kind_counts
            ),
            "component_provenance_counts": _nested_counts(
                plan.audit.component_provenance_counts
            ),
        },
        "reopened_audit": {
            "node_count": audit.node_count,
            "element_count": audit.element_count,
            "duplicate_node_count": audit.duplicate_node_count,
            "free_face_count": audit.free_face_count,
            "internal_face_count": audit.internal_face_count,
            "minimum_jacobian_determinant": audit.minimum_jacobian_determinant,
            "minimum_scaled_jacobian": audit.minimum_scaled_jacobian,
            "minimum_sicn": audit.minimum_sicn,
            "minimum_sige": audit.minimum_sige,
            "volume_mm3": audit.volume_mm3,
            "numbered_plan_replay_verified": (
                audit.numbered_plan_replay_verified
            ),
            "shared_surface_sizing_verified": (
                audit.shared_surface_sizing_verified
            ),
            "complete_support_plane_interfaces_verified": (
                audit.complete_support_plane_interfaces_verified
            ),
            "unpaired_coplanar_free_faces_verified": (
                audit.unpaired_coplanar_free_faces_verified
            ),
            "strategy_aware_quality_floor_met": (
                audit.strategy_aware_quality_floor_met
            ),
            "orthogonal_sicn_aspect_ratio_exemption_count": len(
                orthogonal_sicn_exemptions
            ),
            "orthogonal_sicn_aspect_ratio_exemptions": (
                orthogonal_sicn_exemptions
            ),
            "shared_surface_target_edge_mm_by_contract_id": dict(
                audit.shared_surface_target_edge_mm_by_contract_id
            ),
            "shared_surface_maximum_edge_mm_by_contract_id": dict(
                audit.shared_surface_maximum_edge_mm_by_contract_id
            ),
            "shared_surface_facet_count_by_contract_id": dict(
                audit.shared_surface_facet_count_by_contract_id
            ),
            "complete_support_plane_area_mm2_by_interface_key": dict(
                audit.complete_support_plane_area_mm2_by_interface_key
            ),
            "complete_support_plane_facet_count_by_interface_key": dict(
                audit.complete_support_plane_facet_count_by_interface_key
            ),
            "component_quality": {
                component_id: {
                    "minimum_jacobian_determinant": (
                        quality.minimum_jacobian_determinant
                    ),
                    "minimum_scaled_jacobian": quality.minimum_scaled_jacobian,
                    "minimum_sicn": quality.minimum_sicn,
                    "minimum_sige": quality.minimum_sige,
                    "volume_mm3": quality.volume_mm3,
                }
                for component_id, quality in sorted(
                    audit.component_quality.items()
                )
            },
        },
        "mesh_identity": {
            "kind": "serialized_msh_sha256",
            "size_bytes": write_artifact["size_bytes"],
            "sha256": write_artifact["sha256"],
        },
        "numbered_mesh_sha256": numbered_mixed_mesh_sha256(audit.mesh),
    }


def _snapshot_evidence(
    request: PackageV2JobRequest,
    snapshots: tuple[FrozenSourceSnapshot, ...],
) -> list[dict[str, object]]:
    pin_by_source = {
        value.source_id: value for value in request.launch_identity.frozen_sources
    }
    return [
        {
            "source_id": snapshot.source_id,
            "snapshot_content_sha256": pin_by_source[
                snapshot.source_id
            ].snapshot_content_sha256,
            "snapshot_numbered_sha256": snapshot.numbered_sha256,
            "artifacts": [
                {
                    "role": role,
                    "declaration": identity.declaration,
                    "runtime_path": identity.runtime_path,
                    "size_bytes": identity.size_bytes,
                    "sha256": identity.sha256,
                }
                for role, identity in sorted(snapshot.artifacts.items())
            ],
        }
        for snapshot in snapshots
    ]


def _parameters_payload(
    request: PackageV2JobRequest,
    compiled: PackageV2CompileResult,
    mode: PackageV2WorkerMode,
    target_edge_mm: float | None,
) -> dict[str, object]:
    strategy_mesh_controls: dict[str, object] | None = None
    generated_component_mesh_controls: list[dict[str, object]] | None = None
    if mode in {
        PackageV2WorkerMode.GENERATED_MIXED,
        PackageV2WorkerMode.ROLE_FREE_FROZEN_GENERATED_MIXED,
    }:
        _explicit_generated_mixed_requirements(compiled)
        generated_component_mesh_controls = _component_local_control_payloads(
            compiled
        )
    if mode is PackageV2WorkerMode.ROLE_FREE_FROZEN_GENERATED_MIXED:
        if target_edge_mm is not None:
            raise PackageV2WorkerError(
                "role-free mixed sizing must remain Component-local"
            )
        strategy_mesh_controls = {
            "executor_id": "role_free_authority_dag_v1",
            "component_local_mesh_controls": True,
            "package_wide_target_edge": None,
            "frozen_contact_discovery": "actual_geometry",
            "frozen_interface_mode": "preserve_interface_trace",
            "implicit_topology_selection": False,
            "role_or_material_based_routing": False,
        }
    return {
        "schema": PACKAGE_V2_WORKER_PARAMETERS_SCHEMA,
        "worker_implementation_version": PACKAGE_V2_WORKER_IMPLEMENTATION_VERSION,
        "job_id": request.job_id,
        "mode": mode.value,
        "source_name": request.source_name,
        "raw_source_sha256": compiled.raw_source_digest,
        "compiled_plan_sha256": compiled.plan_digest,
        "mesh_settings": _mesh_settings_report_payload(compiled),
        "target_edge_mm": target_edge_mm,
        "generated_component_mesh_controls": generated_component_mesh_controls,
        "strategy_mesh_controls": strategy_mesh_controls,
        "fixed_policy": {
            "generated_random_seed": _GENERATED_RANDOM_SEED,
            "generated_optimize": _GENERATED_OPTIMIZE,
            "generated_minimum_quality": _GENERATED_MINIMUM_QUALITY,
            "maximum_element_count": _MAXIMUM_ELEMENT_COUNT,
            "reopened_mixed_minimum_quality": _GENERATED_MINIMUM_QUALITY,
            "role_free_mixed_executor_bound_to_worker_version": True,
            "direct_volume_candidate_timeout_seconds": DEFAULT_CANDIDATE_POLICY.candidate_timeout_seconds,
            "quadtri_search_timeout_seconds": DEFAULT_CANDIDATE_POLICY.search_timeout_seconds,
            "direct_volume_threads_by_algorithm": {
                str(algorithm): count for algorithm, count in DIRECT_VOLUME_THREADS_BY_ALGORITHM.items()
            },
        },
        "compiled_plan": json.loads(compiled.canonical_plan_json),
    }


def _write_binary_atomically(source: Path, target: Path) -> None:
    with atomic_output_path(target) as temporary:
        with source.open("rb") as input_stream, temporary.open("wb") as output_stream:
            shutil.copyfileobj(input_stream, output_stream, length=1024 * 1024)
            output_stream.flush()
            os.fsync(output_stream.fileno())


def _write_bytes_atomically(value: bytes, target: Path) -> None:
    with atomic_output_path(target) as temporary:
        with temporary.open("wb") as output_stream:
            output_stream.write(value)
            output_stream.flush()
            os.fsync(output_stream.fileno())


def _publish_bundle(
    stage_mesh: Path,
    output: Path,
    parameters_path: Path,
    parameters_bytes: bytes,
    report_path: Path,
    report_bytes: bytes,
    expected_artifacts: Mapping[str, Mapping[str, str | int]],
) -> None:
    marker_invalidated = False
    try:
        # The report is the sole readiness marker.  Remove a marker from any
        # older bundle before replacing the first payload file, so a
        # mid-commit failure cannot advertise mismatched bytes as ready.
        report_path.unlink(missing_ok=True)
        marker_invalidated = True
        _write_binary_atomically(stage_mesh, output)
        _write_bytes_atomically(parameters_bytes, parameters_path)
        _write_bytes_atomically(report_bytes, report_path)
        actual_artifacts = {
            "mesh": file_artifact(output),
            "parameters": file_artifact(parameters_path),
            "report": file_artifact(report_path),
        }
        if actual_artifacts != {
            role: dict(expected_artifacts[role])
            for role in ("mesh", "parameters", "report")
        }:
            raise PackageV2WorkerError(
                "published Package V2 artifact bundle differs from its evidence"
            )
    except BaseException as error:
        if marker_invalidated:
            try:
                report_path.unlink(missing_ok=True)
            except OSError as cleanup_error:
                raise PackageV2WorkerError(
                    "Package V2 publication failed and its report marker "
                    "could not be invalidated"
                ) from cleanup_error
        if isinstance(error, PackageV2WorkerError):
            raise
        if isinstance(error, (KeyboardInterrupt, SystemExit)):
            raise
        raise PackageV2WorkerError(
            "Package V2 bundle publication failed; no ready report remains"
        ) from error


def _dispatch(
    compiled: PackageV2CompileResult,
    snapshots: tuple[FrozenSourceSnapshot, ...],
    stage_mesh: Path,
    *,
    target_edge_mm: float | None,
    verbose: bool,
    progress: PackageV2ProgressSink | None = None,
    request: PackageV2JobRequest | None = None,
) -> tuple[PackageV2WorkerMode, dict[str, object], str]:
    if _is_role_free_frozen_generated_candidate(compiled):
        if len(snapshots) != 1:
            raise PackageV2WorkerError(
                "role-free mixed execution requires one Frozen snapshot"
            )
        if target_edge_mm is not None:
            raise PackageV2WorkerError(
                "role-free mixed execution cannot use a package-wide target size"
            )
        if request is not None:
            _emit_progress(
                progress,
                request,
                phase="mesh_generation",
                phase_index=5,
                state="progress",
                message=(
                    "正在按实际相邻面的 authority DAG 执行三拓扑混搭，"
                    "由真实几何自动发现 Frozen 接触并保留其不可修改的网格。"
                ),
                mode=PackageV2WorkerMode.ROLE_FREE_FROZEN_GENERATED_MIXED,
            )
        candidate_events: list[dict[str, object]] = []

        def report_candidate_event(event):
            candidate_events.append(dict(event))
            if request is not None:
                label = event.get("candidate", "")
                elapsed = event.get("elapsed_seconds")
                duration = "" if elapsed is None else f"，耗时 {elapsed:.3f}s"
                message = f"Gmsh 候选 {label} / {event['stage']}: {event['state']}{duration}"
                message += f"；{event['detail']}" if event.get("detail") else ""
                if event.get("stage") in {"component", "candidate", "quality_snapshot", "candidate_audit", "candidate_selection"} or event.get("state") in {"timeout", "failed"} or str(event.get("stage", "")).endswith("/audit"):
                    compact = {k: v for k, v in event.items() if k in (
                        "candidate", "component_id", "stage", "state", "iteration",
                        "measurement_phase", "metrics", "element_count", "detail",
                    )}
                    if "detail" in compact:
                        compact["detail"] = str(compact["detail"])[:700]
                    message = QUALITY_PROGRESS_PREFIX + json.dumps(compact, ensure_ascii=False, allow_nan=False)
                _emit_progress(
                    progress, request, phase="mesh_generation", phase_index=5,
                    state="progress",
                    message=message,
                    mode=PackageV2WorkerMode.ROLE_FREE_FROZEN_GENERATED_MIXED,
                )

        try:
            lowering = lower_mixed_source(
                compiled,
                snapshots[0],
            )
            reporting_context = build_mixed_execution_context(
                lowering,
                snapshots[0],
            )
            lowering = reporting_context.lowering
            with candidate_execution_context(
                observer=report_candidate_event,
                parallel_tet_candidates=compiled.parsed_source.document.mesh_settings.parallel_tet_candidates,
            ):
                result = execute_role_free_mixed_source(
                    reporting_context,
                    verbose=verbose,
                )
            if not result.complete:
                pending = "; ".join(
                    f"{value.component_id}:{value.kind}:{value.detail}"
                    for value in result.pending_dependencies
                )
                raise PackageV2WorkerError(
                    "role-free mixed execution has unresolved dependencies: "
                    + pending
                )
            write_result = write_role_free_mixed_source(
                result,
                snapshots[0],
                stage_mesh,
                verbose=verbose,
            )
            audit = audit_reopened_mixed_volume_mesh(
                stage_mesh,
                write_result.plan,
                lowering.component_mesh_requirements,
                minimum_quality=_GENERATED_MINIMUM_QUALITY,
                verbose=verbose,
            )
        except PackageV2WorkerError:
            raise
        except Exception as error:
            raise PackageV2WorkerError(
                f"role-free mixed execution failed: {error}"
            ) from error
        if audit.element_count > _MAXIMUM_ELEMENT_COUNT:
            raise PackageV2WorkerError(
                "role-free mixed execution exceeded the element-count limit"
            )
        execution = _role_free_mixed_execution_payload(
            result,
            lowering,
            write_result,
            audit,
            reporting_context.mesh_ordering,
        )
        execution["candidate_execution_events"] = candidate_events
        execution["frozen_contact_discovery"] = {
            "mode": "actual_geometry",
            "interface_geometry_tolerance_mm": reporting_context.interface_geometry_tolerance_mm,
            "interfaces": [
                {
                    "frozen_component_global_id": key.frozen_component_global_id,
                    "generated_component_global_id": key.generated_component_global_id,
                    "facet_count": sum(len(patch.facets) for patch in patches),
                    "mode": "preserve_interface_trace",
                }
                for key, patches in reporting_context.frozen_patches_by_interface.items()
            ],
        }
        numbered_sha256 = numbered_mixed_mesh_sha256(audit.mesh)
        return (
            PackageV2WorkerMode.ROLE_FREE_FROZEN_GENERATED_MIXED,
            execution,
            numbered_sha256,
        )
    matches = compiled.assembly_policy.interface_matches
    if not snapshots:
        if not compiled.generated_instances or matches:
            raise PackageV2WorkerError(
                "generated-only worker mode requires generated geometry and no interfaces"
            )
        mesh_controls = _explicit_generated_mesh_controls(compiled)
        if request is not None:
            _emit_progress(
                progress,
                request,
                phase="mesh_generation",
                phase_index=5,
                state="progress",
                message=(
                    "正在按真实相邻面与 Component 局部尺寸协商共享面，"
                    "并显式执行 sweep / 正交 HEX / Gmsh hybrid 混搭；"
                    "此步骤没有可靠百分比。"
                ),
                mode=PackageV2WorkerMode.GENERATED_MIXED,
            )
        summary = build_generated_mixed_mesh(
            tuple(
                value.geometry_result.geometry
                for value in compiled.generated_instances
            ),
            mesh_controls,
            stage_mesh,
            controls=GeneratedMixedMeshControls(
                random_seed=_GENERATED_RANDOM_SEED,
                optimize=_GENERATED_OPTIMIZE,
                maximum_element_count=_MAXIMUM_ELEMENT_COUNT,
                minimum_quality=_GENERATED_MINIMUM_QUALITY,
            ),
            interface_geometry_tolerance_mm=(
                compiled.interface_geometry_tolerance_mm
            ),
            verbose=verbose,
        )
        return (
            PackageV2WorkerMode.GENERATED_MIXED,
            _generated_summary_payload(summary, mesh_controls),
            summary.numbered_mesh_sha256,
        )
    raise PackageV2WorkerError("compiled Source did not match a clean worker mode")


def execute_package_v2_job(
    request: PackageV2JobRequest,
    *,
    expected_runtime_profile: PackageV2RuntimeProfile,
    verbose: bool = False,
    progress: PackageV2ProgressSink | None = None,
) -> PackageV2WorkerSummary:
    """Rebuild, execute, verify and publish one complete Package V2 job."""

    if type(verbose) is not bool:
        raise PackageV2WorkerError("verbose must be boolean")
    request = _replay_request(request)
    _emit_progress(
        progress,
        request,
        phase="job_replay",
        phase_index=1,
        state="started",
        message="正在重放 immutable Job 并核对 runtime/output identity。",
    )
    _audit_runtime_profile(request, expected_runtime_profile)
    _reject_output_aliases(request)
    _emit_progress(
        progress,
        request,
        phase="job_replay",
        phase_index=1,
        state="completed",
        message="Job、runtime profile 与输出身份核对完成。",
    )
    _emit_progress(
        progress,
        request,
        phase="source_compile",
        phase_index=2,
        state="started",
        message="正在重新编译 Job 内嵌 Source 并执行能力/资源预检。",
    )
    try:
        source_bytes = request.source_text.encode("utf-8")
        compiled = compile_package_v2(
            source_bytes,
            source_name=request.source_name,
            source_root=request.source_root,
        )
    except Exception as error:
        raise PackageV2WorkerError("worker source recompilation failed") from error
    _audit_compiled_runtime_paths(request, compiled)
    target_edge_mm = _preflight_compiled_capability(compiled)
    _emit_progress(
        progress,
        request,
        phase="source_compile",
        phase_index=2,
        state="completed",
        message="Source canonical plan 与 worker 能力预检完成。",
    )
    frozen_total = len(compiled.frozen_sources)
    _emit_progress(
        progress,
        request,
        phase="frozen_audit",
        phase_index=3,
        state="started",
        message=(
            "没有 Frozen artifacts；跳过运行时加载。"
            if frozen_total == 0
            else f"正在加载并 fresh-audit Frozen Source（0/{frozen_total}）。"
        ),
    )
    try:
        loaded_snapshots: list[FrozenSourceSnapshot] = []
        for index, value in enumerate(compiled.frozen_sources, start=1):
            loaded_snapshots.append(load_compiled_frozen_source(value))
            _emit_progress(
                progress,
                request,
                phase="frozen_audit",
                phase_index=3,
                state="progress",
                message=(
                    f"Frozen Source {value.source_id} 已通过 fresh audit "
                    f"（{index}/{frozen_total}）。"
                ),
                current=index,
                total=frozen_total,
                unit="source",
            )
        snapshots = tuple(loaded_snapshots)
        verify_package_v2_job_request(
            request,
            compiled,
            snapshots,
            expected_runtime_profile=expected_runtime_profile,
        )
    except Exception as error:
        raise PackageV2WorkerError(
            "worker Frozen reload or launch verification failed"
        ) from error
    _emit_progress(
        progress,
        request,
        phase="frozen_audit",
        phase_index=3,
        state="completed",
        message=(
            "Frozen artifacts 与 launch identity 复核完成。"
            if snapshots
            else "当前模式不含 Frozen artifacts。"
        ),
    )

    _emit_progress(
        progress,
        request,
        phase="execution_plan",
        phase_index=4,
        state="started",
        message="正在选择 worker mode、解析接口并准备私有 staging。",
    )

    output = Path(request.output_mesh_path)
    parameters_path, report_path = _sidecar_paths(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with exclusive_output_lock(output):
        with tempfile.TemporaryDirectory(
            prefix=f".{output.stem}.package-v2-worker-",
            dir=output.parent,
        ) as temporary_directory:
            stage_mesh = Path(temporary_directory, "package.msh")
            _emit_progress(
                progress,
                request,
                phase="execution_plan",
                phase_index=4,
                state="completed",
                message="输出锁与私有 staging 已就绪；执行计划固定完成。",
            )
            _emit_progress(
                progress,
                request,
                phase="mesh_generation",
                phase_index=5,
                state="started",
                message="正在进入网格生成与装配；长 Gmsh 调用使用不定进度。",
            )
            try:
                mode, execution, mesh_numbered_sha256 = _dispatch(
                    compiled,
                    snapshots,
                    stage_mesh,
                    target_edge_mm=target_edge_mm,
                    verbose=verbose,
                    progress=progress,
                    request=request,
                )
            except Exception as error:
                from .package_v2_mixed_source_executor import PartialContactBoundaryError
                from .package_v2_orthogonal_domain_planning import (
                    OrthogonalConstraintError,
                )

                cause = error
                seen = set()
                while cause is not None and id(cause) not in seen:
                    seen.add(id(cause))
                    if isinstance(
                        cause, (PartialContactBoundaryError, OrthogonalConstraintError)
                    ):
                        _emit_progress(
                            progress, request, phase="mesh_generation", phase_index=5,
                            state="failed", message=str(cause)[:2000], diagnostic=cause.diagnostic,
                        )
                        raise PackageV2WorkerError(str(cause)) from error
                    cause = cause.__cause__
                if isinstance(error, PackageV2WorkerError):
                    raise
                raise PackageV2WorkerError("Package V2 mesher execution failed") from error

            _emit_progress(
                progress,
                request,
                phase="mesh_generation",
                phase_index=5,
                state="completed",
                message=f"{mode.value} 网格已生成并通过内部写出/重开审计。",
                mode=mode,
            )
            _emit_progress(
                progress,
                request,
                phase="post_mesh_audit",
                phase_index=6,
                state="started",
                message="正在重新审计 Frozen 输入并计算最终网格 evidence。",
                mode=mode,
            )

            try:
                audited_snapshots: list[FrozenSourceSnapshot] = []
                for index, value in enumerate(snapshots, start=1):
                    audited_snapshots.append(audit_frozen_source_snapshot(value))
                    _emit_progress(
                        progress,
                        request,
                        phase="post_mesh_audit",
                        phase_index=6,
                        state="progress",
                        message=(
                            "网格生成后的 Frozen 输入复核 "
                            f"{index}/{len(snapshots)} 完成。"
                        ),
                        current=index,
                        total=len(snapshots),
                        unit="source",
                        mode=mode,
                    )
                current_snapshots = tuple(audited_snapshots)
                verify_package_v2_job_request(
                    request,
                    compiled,
                    current_snapshots,
                    expected_runtime_profile=expected_runtime_profile,
                )
            except Exception as error:
                raise PackageV2WorkerError(
                    "Frozen inputs changed during worker execution"
                ) from error

            mesh_artifact = file_artifact(stage_mesh, published_path=output)
            _emit_progress(
                progress,
                request,
                phase="post_mesh_audit",
                phase_index=6,
                state="completed",
                message="输入稳定性与最终 mesh identity 复核完成。",
                mode=mode,
            )
            _emit_progress(
                progress,
                request,
                phase="bundle_publication",
                phase_index=7,
                state="started",
                message="正在生成 parameters/report evidence 并按 report-last 发布。",
                mode=mode,
            )
            parameters_payload = _parameters_payload(
                request,
                compiled,
                mode,
                target_edge_mm,
            )
            if "frozen_contact_discovery" in execution:
                parameters_payload["frozen_contact_discovery"] = execution["frozen_contact_discovery"]
            parameters_bytes = (
                _canonical_json(parameters_payload) + "\n"
            ).encode("utf-8")
            parameters_artifact = _artifact_from_bytes(
                parameters_path,
                parameters_bytes,
            )
            capabilities = {
                "complete_package_mesh": True,
                "fresh_source_recompiled": True,
                "fresh_frozen_artifacts_reloaded": True,
                "persisted_plan_consumed": False,
                "generated_only_supported": True,
                "generated_only_mixed_topologies_supported": True,
                "generated_only_volume_topologies": [
                    "structured_sweep",
                    "orthogonal_hex",
                    "conformal_hybrid",
                ],
                "generated_only_component_local_target_and_transition": True,
                "generated_geometry_kinds": [
                    "box",
                    "rectangular_frame_extrusion",
                    "rectangular_underfill_fillet",
                ],
                "preserve_interface_trace_supported": True,
                "frozen_interface_modes": ["preserve_interface_trace"],
                "frozen_volume_connectivity_is_never_propagated": True,
                "orthogonal_directional_near_edge_supported": True,
                "orthogonal_partition_origin_supported": True,
                "hybrid_permitted_volume_element_kinds": [
                    "HEX8",
                    "WEDGE6",
                    "PYRAMID5",
                    "TET4",
                ],
                "one_frozen_source_with_any_positive_generated_count": True,
                "multiple_frozen_sources_supported": False,
                "additional_frozen_physical_groups_supported": (
                    mode
                    is PackageV2WorkerMode.ROLE_FREE_FROZEN_GENERATED_MIXED
                ),
                "role_free_frozen_generated_mixed_supported": True,
                "role_free_mixed_geometry_kinds": [
                    "box",
                    "rectangular_frame_extrusion",
                    "rectangular_underfill_fillet",
                ],
                "role_free_mixed_volume_topologies": [
                    "structured_sweep",
                    "orthogonal_hex",
                    "conformal_hybrid",
                ],
                "role_free_mixed_authority_from_actual_adjacency": True,
                "role_free_mixed_component_local_sizing": True,
                "interface_mode_is_trace_only": True,
                "interface_mode_does_not_select_or_constrain_strategy": True,
                "current_mode_additional_frozen_physical_groups_preserved": (
                    mode
                    is PackageV2WorkerMode.ROLE_FREE_FROZEN_GENERATED_MIXED
                ),
                "mesh_identity_kind": "canonical_numbered_mesh_sha256",
            }
            mesh_identity = {
                "kind": "canonical_numbered_mesh_sha256",
                "sha256": mesh_numbered_sha256,
            }
            if mode is PackageV2WorkerMode.ROLE_FREE_FROZEN_GENERATED_MIXED:
                serialized_identity = execution.get("mesh_identity")
                if (
                    type(serialized_identity) is not dict
                    or serialized_identity.get("kind")
                    != "serialized_msh_sha256"
                    or serialized_identity.get("sha256")
                    != mesh_artifact["sha256"]
                ):
                    raise PackageV2WorkerError(
                        "role-free mixed serialized mesh identity is inconsistent"
                    )
            report_payload: dict[str, object] = {
                "schema": PACKAGE_V2_WORKER_REPORT_SCHEMA,
                "status": "complete",
                "worker_implementation_version": (
                    PACKAGE_V2_WORKER_IMPLEMENTATION_VERSION
                ),
                "job_id": request.job_id,
                "mode": mode.value,
                "request_sha256": request.sha256,
                "launch_identity": request.launch_identity.to_jsonable(),
                "current_evidence": {
                    "raw_source_sha256": compiled.raw_source_digest,
                    "compiled_plan_sha256": compiled.plan_digest,
                    "snapshots": _snapshot_evidence(request, current_snapshots),
                    "mesh_numbered_sha256": mesh_numbered_sha256,
                    "mesh_identity": mesh_identity,
                },
                "execution": execution,
                "mesh_priority_contract": _mesh_priority_report_payload(
                    compiled
                ),
                "mesh_settings": _mesh_settings_report_payload(compiled),
                "capabilities": capabilities,
                "artifacts": {
                    "mesh": mesh_artifact,
                    "parameters": parameters_artifact,
                },
                "bundle_commit_protocol": {
                    "individual_artifacts_atomic": True,
                    "previous_report_invalidated_before_payload_commit": True,
                    "report_published_last": True,
                    "report_is_readiness_marker": True,
                },
            }
            report_binding = _sha256_bytes(
                _canonical_json(report_payload).encode("utf-8")
            )
            report_payload["binding_sha256"] = report_binding
            report_bytes = (_canonical_json(report_payload) + "\n").encode("utf-8")
            report_artifact = _artifact_from_bytes(report_path, report_bytes)

            snapshot_digests = tuple(
                sorted(
                    (value.source_id, value.numbered_sha256)
                    for value in current_snapshots
                )
            )
            summary = PackageV2WorkerSummary(
                mode,
                str(output),
                str(parameters_path),
                str(report_path),
                request.sha256,
                request.launch_identity.sha256,
                compiled.raw_source_digest,
                compiled.plan_digest,
                snapshot_digests,
                mesh_numbered_sha256,
                report_binding,
                {
                    "mesh": mesh_artifact,
                    "parameters": parameters_artifact,
                    "report": report_artifact,
                },
                True,
                True,
            )

            _publish_bundle(
                stage_mesh,
                output,
                parameters_path,
                parameters_bytes,
                report_path,
                report_bytes,
                summary.artifacts,
            )
            _emit_progress(
                progress,
                request,
                phase="bundle_publication",
                phase_index=7,
                state="completed",
                message="MSH、parameters 与 report 已按 report-last 协议发布。",
                mode=mode,
            )
            return summary


def execute_package_v2_job_bytes(
    data: bytes,
    *,
    expected_runtime_profile: PackageV2RuntimeProfile,
    verbose: bool = False,
    progress: PackageV2ProgressSink | None = None,
) -> PackageV2WorkerSummary:
    """Parse a serialized job request and execute the canonical replay."""

    try:
        request = parse_package_v2_job_request(data)
    except Exception as error:
        raise PackageV2WorkerError("cannot parse Package V2 job request") from error
    return execute_package_v2_job(
        request,
        expected_runtime_profile=expected_runtime_profile,
        verbose=verbose,
        progress=progress,
    )


__all__ = [
    "PACKAGE_V2_FROZEN_IMPORT_VERSION",
    "PACKAGE_V2_WORKER_IMPLEMENTATION_VERSION",
    "PACKAGE_V2_WORKER_PARAMETERS_SCHEMA",
    "PACKAGE_V2_WORKER_PROFILE_ID",
    "PACKAGE_V2_WORKER_REPORT_SCHEMA",
    "PackageV2WorkerError",
    "PackageV2WorkerMode",
    "PackageV2WorkerSummary",
    "current_package_v2_runtime_profile",
    "execute_package_v2_job",
    "execute_package_v2_job_bytes",
]
