"""Canonical paths, locking, and crash-safe artifact publication."""

from __future__ import annotations

from contextlib import contextmanager
import hashlib
import os
from pathlib import Path
import tempfile
from typing import Iterator


def normalized_mesh_output(path: str | Path) -> Path:
    """Return one absolute, lower-case ``.msh`` path for an output bundle."""

    output = Path(path).expanduser().resolve()
    if output.suffix != ".msh":
        output = output.with_suffix(".msh")
    return output


def paths_refer_to_same_file(left: str | Path, right: str | Path) -> bool:
    """Compare paths by spelling first, then by existing filesystem identity."""

    left_path = Path(left).expanduser().resolve()
    right_path = Path(right).expanduser().resolve()
    if left_path == right_path:
        return True
    try:
        return left_path.samefile(right_path)
    except OSError:
        return False


def sha256_file(path: str | Path) -> str:
    """Return the lower-case SHA-256 digest of one file."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def file_artifact(
    path: str | Path,
    *,
    published_path: str | Path | None = None,
) -> dict[str, str | int]:
    """Describe bytes at ``path`` under their eventual published name."""

    source = Path(path)
    target = source if published_path is None else Path(published_path)
    return {
        "path": str(target),
        "size_bytes": source.stat().st_size,
        "sha256": sha256_file(source),
    }


@contextmanager
def atomic_output_path(path: str | Path) -> Iterator[Path]:
    """Yield a temporary sibling and replace ``path`` only after success.

    Writing in the destination directory keeps :func:`os.replace` on the same
    filesystem.  If the writer raises (including ``KeyboardInterrupt``), the
    temporary file is removed and an existing published file is untouched.
    A process terminated inside the writer can leave only the hidden temporary
    sibling behind; it never exposes a partial final artifact.
    """

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{target.stem}.",
        suffix=target.suffix,
        dir=target.parent,
    )
    os.close(descriptor)
    temporary_path = Path(temporary_name)
    try:
        yield temporary_path
        if not temporary_path.is_file():
            raise RuntimeError(
                f"artifact writer did not create its temporary output: "
                f"{temporary_path}"
            )
        os.chmod(temporary_path, 0o644)
        os.replace(temporary_path, target)
    finally:
        temporary_path.unlink(missing_ok=True)


def atomic_write_text(
    path: str | Path,
    text: str,
    *,
    encoding: str = "utf-8",
) -> None:
    """Atomically publish a text file through a temporary sibling."""

    with atomic_output_path(path) as temporary_path:
        with temporary_path.open("w", encoding=encoding) as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())


@contextmanager
def exclusive_artifact_lock(output: str | Path) -> Iterator[None]:
    """Hold a non-blocking lock for one exact, suffix-preserving artifact."""

    canonical_output = Path(output).expanduser().resolve()
    canonical_output.parent.mkdir(parents=True, exist_ok=True)
    lock_path = canonical_output.with_name(
        f".{canonical_output.name}.easymesh.lock"
    )
    if os.name == "posix":
        import fcntl

        stream = lock_path.open("a+b")
        locked = False
        try:
            try:
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                raise RuntimeError(
                    f"another EasyMesh worker is already writing {canonical_output}"
                ) from exc
            locked = True
            yield
        finally:
            try:
                if locked:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
            finally:
                stream.close()
        return

    if os.name == "nt":  # pragma: no cover - exercised by Windows packaging
        import msvcrt

        stream = lock_path.open("a+b")
        locked = False
        try:
            stream.seek(0, os.SEEK_END)
            if stream.tell() == 0:
                stream.write(b"\0")
                stream.flush()
            stream.seek(0)
            try:
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise RuntimeError(
                    f"another EasyMesh worker is already writing {canonical_output}"
                ) from exc
            locked = True
            yield
        finally:
            try:
                if locked:
                    stream.seek(0)
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            finally:
                stream.close()
        return

    descriptor: int | None = None  # pragma: no cover - uncommon platform fallback
    try:
        descriptor = os.open(
            lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644
        )
        yield
    except FileExistsError as exc:
        raise RuntimeError(
            f"another EasyMesh worker is already writing {canonical_output}"
        ) from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
            lock_path.unlink(missing_ok=True)


@contextmanager
def exclusive_output_lock(output: str | Path) -> Iterator[None]:
    """Hold the historical bundle lock keyed by normalized ``.msh`` output."""

    with exclusive_artifact_lock(normalized_mesh_output(output)):
        yield


__all__ = [
    "atomic_output_path",
    "atomic_write_text",
    "exclusive_artifact_lock",
    "exclusive_output_lock",
    "file_artifact",
    "normalized_mesh_output",
    "paths_refer_to_same_file",
    "sha256_file",
]
