"""Gmsh generation and exact identity assembly for a planned Orth domain."""

from collections import defaultdict
from dataclasses import replace
import hashlib
import math

from .gmsh_runtime import isolated_gmsh_model
from .package_v2_geometry import CanonicalRectangularUnderfillFillet
from .package_v2_mixed_mesh_assembly import (
    ComponentLocalMeshFragment,
    ComponentMeshNode,
    ComponentMeshElement,
)
from .package_v2_mixed_mesh_fragments import declared_shared_seams_from_facets
from .package_v2_orthogonal_candidates import OrthogonalBlockCandidates
from .package_v2_orthogonal_domain_planning import (
    OrthogonalConstraintError,
    key,
    to_local,
    corners,
    root_boxes,
)

HEX_FACES = (
    (0, 1, 2, 3),
    (4, 5, 6, 7),
    (0, 1, 5, 4),
    (1, 2, 6, 5),
    (2, 3, 7, 6),
    (3, 0, 4, 7),
)


def _generated_blocks(plan, verbose=False):
    """Gmsh owns HEX connectivity; planned blocks own the coordinate addresses."""
    if len(plan.blocks) > 1:
        # Coincident discrete source entities in one Gmsh model interfere with
        # extrusion lookup. Keep each block isolated and assemble only through
        # the planner's already-proved common-face coordinate addresses.
        return tuple(
            _generated_blocks(
                replace(plan, blocks=(block,), levels=(levels,)), verbose
            )[0]
            for block, levels in zip(plan.blocks, plan.levels)
        )
    import gmsh

    result = []
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_orthogonal_domain",
        number_options={
            "General.Terminal": float(verbose),
            "Mesh.ElementOrder": 1.0,
            "Mesh.Optimize": 0.0,
        },
    ):
        volumes = []
        next_node = 1
        next_face = 1
        for block, levels in zip(plan.blocks, plan.levels):
            x, y, z = levels
            points = [(a, b, z[0]) for b in y for a in x]
            node_tags = tuple(range(next_node, next_node + len(points)))
            next_node += len(points)
            surface = gmsh.model.addDiscreteEntity(2)
            gmsh.model.mesh.addNodes(
                2, surface, node_tags, tuple(v for p in points for v in p)
            )
            quads = []
            for j in range(len(y) - 1):
                for i in range(len(x) - 1):
                    quads.append(
                        tuple(
                            node_tags[k]
                            for k in (
                                j * len(x) + i,
                                j * len(x) + i + 1,
                                (j + 1) * len(x) + i + 1,
                                (j + 1) * len(x) + i,
                            )
                        )
                    )
            gmsh.model.mesh.addElementsByType(
                surface,
                3,
                tuple(range(next_face, next_face + len(quads))),
                tuple(n for q in quads for n in q),
            )
            next_face += len(quads)
            extruded = gmsh.model.geo.extrude(
                [(2, surface)],
                0,
                0,
                z[-1] - z[0],
                numElements=[1] * (len(z) - 1),
                heights=[(v - z[0]) / (z[-1] - z[0]) for v in z[1:]],
                recombine=True,
            )
            volumes.append(tuple(tag for dim, tag in extruded if dim == 3))
        gmsh.model.geo.synchronize()
        gmsh.model.mesh.generate(3)
        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        points = {
            int(tag): key(coordinates[3 * i : 3 * i + 3]) for i, tag in enumerate(tags)
        }
        for bi, entities in enumerate(volumes):
            rows = []
            element_ids = []
            for volume in entities:
                types, ids, connectivity = gmsh.model.mesh.getElements(3, volume)
                for kind, block_ids, block_nodes in zip(types, ids, connectivity):
                    if int(kind) != 5:
                        raise OrthogonalConstraintError(
                            "orth_non_cartesian_output", "Gmsh 未生成纯 HEX8。"
                        )
                    for i, tag in enumerate(block_ids):
                        element_ids.append(int(tag))
                        pts = tuple(
                            points[int(v)] for v in block_nodes[8 * i : 8 * i + 8]
                        )
                        bounds = tuple(
                            (min(p[a] for p in pts), max(p[a] for p in pts))
                            for a in range(3)
                        )
                        if set(pts) != set(corners(bounds)):
                            raise OrthogonalConstraintError(
                                "orth_non_cartesian_output",
                                "Gmsh 单元不是轴对齐正交 HEX8。",
                            )
                        rows.append((bounds, pts))
            expected = math.prod(len(v) - 1 for v in plan.levels[bi])
            if len(rows) != expected:
                raise OrthogonalConstraintError(
                    "orth_non_cartesian_output", "Gmsh 改变了已规划的正交单元数量。"
                )
            if (
                min(
                    gmsh.model.mesh.getElementQualities(element_ids, "minDetJac"),
                    default=0,
                )
                <= 0
            ):
                raise OrthogonalConstraintError(
                    "orth_non_cartesian_output", "Orth 网格含非正体积单元。"
                )
            result.append(tuple(sorted(rows)))
    return tuple(result)


def materialize_orthogonal_domain(plan, *, extra_tokens=None, verbose=False):
    # Import only here: the executor consumes this module after its DTOs exist.
    from .package_v2_mixed_source_executor import MaterializedComponent, _shell_side
    from .package_v2_adjacency_execution import _classify_local_side
    from .package_v2_orthogonal_fillet import (
        _contains_point,
        _boundary_side,
        _analytic_volume,
        _mesh_topology_warnings,
        OrthogonalHexNode,
        OrthogonalHexElement,
        OrthogonalCellClass,
        OrthogonalRetentionReason,
    )

    generated = _generated_blocks(plan, verbose)
    prefix = hashlib.sha256(
        "|".join(sorted(s.fragment.fragment_id for s in plan.inputs)).encode()
    ).hexdigest()[:20]
    token_map = {}
    components = tuple(sorted({s.component_id for s in plan.inputs}))

    def bind(fragment_id, point, token, evidence=()):
        for i, block in enumerate(plan.blocks):
            if plan.inputs[block.source].fragment.fragment_id != fragment_id:
                continue
            if all(
                lo - 1e-10 <= p <= hi + 1e-10
                for p, (lo, hi) in zip(point, block.bounds)
            ):
                address = (plan.domains[i], key(point))
                previous = token_map.setdefault(address, token)
                if previous != token:
                    raise OrthogonalConstraintError(
                        "orth_locked_identity_conflict",
                        "相接固定接口在同一节点给出了不同的不可变身份。",
                        components=components,
                        sources=evidence,
                    )

    for quad in plan.locks:
        for point, token in zip(quad.points, quad.tokens):
            bind(quad.target_fragment_id, point, token, (quad.evidence(),))
    for (fragment_id, point), token in (extra_tokens or {}).items():
        bind(fragment_id, point, token)
    nodes = defaultdict(dict)
    elements = defaultdict(list)
    candidate = defaultdict(list)
    assigned = defaultdict(list)
    for i, rows in enumerate(generated):
        source = plan.inputs[plan.blocks[i].source]
        fragment = source.fragment
        fid = fragment.fragment_id
        for bounds, points in rows:
            candidate_index = len(candidate[fid])
            candidate[fid].append(bounds)
            if isinstance(fragment.root, CanonicalRectangularUnderfillFillet):
                center = to_local(
                    tuple((a + b) / 2 for a, b in bounds), fragment.placement
                )
                if not _contains_point(fragment.root, center, 1e-10):
                    continue
            assigned[fid].append(candidate_index)
            ids = []
            for point in points:
                address = (plan.domains[i], point)
                node = nodes[fid].get(address)
                if node is None:
                    token = token_map.get(
                        address, f"orth-domain::{prefix}::{address[0]}::{point}"
                    )
                    node = ComponentMeshNode(len(nodes[fid]) + 1, point, token)
                    nodes[fid][address] = node
                ids.append(node.local_node_id)
            elements[fid].append(
                ComponentMeshElement(
                    len(elements[fid]) + 1, 5, tuple(ids), "gmsh_orthogonal_domain"
                )
            )
    fragments = {}
    faces_by_fragment = {}
    boundaries = defaultdict(dict)
    locked = defaultdict(dict)
    evidence = defaultdict(dict)
    grids = defaultdict(dict)
    endpoints = defaultdict(dict)
    shared_face_owners = defaultdict(list)
    plan_evidence = plan.to_dict()
    for source in plan.inputs:
        fid = source.fragment.fragment_id
        component = source.component_id
        if not elements[fid]:
            raise OrthogonalConstraintError(
                "orth_empty_geometry",
                "几何筛选后 Solid 没有保留任何正体积 HEX。",
                components=(component,),
            )
        fragment = ComponentLocalMeshFragment(
            fid,
            component,
            source.material,
            tuple(nodes[fid].values()),
            tuple(elements[fid]),
        )
        fragments[fid] = fragment
        node_by_id = {n.local_node_id: n for n in fragment.nodes}
        faces = defaultdict(list)
        for element in fragment.elements:
            for indices in HEX_FACES:
                face = tuple(element.node_ids[j] for j in indices)
                signature = frozenset(node_by_id[n].semantic_token for n in face)
                faces[signature].append(face)
        if any(len(v) > 2 for v in faces.values()):
            raise OrthogonalConstraintError(
                "orth_nonmanifold_output",
                "正交网格出现重复或非流形体单元。",
                components=(component,),
            )
        exterior = {sig: fs[0] for sig, fs in faces.items() if len(fs) == 1}
        faces_by_fragment[fid] = exterior
        by_side = defaultdict(list)
        for signature, face in exterior.items():
            shared_face_owners[signature].append((fid, face))
            points = tuple(node_by_id[n].coordinates_mm for n in face)
            if isinstance(source.fragment.root, CanonicalRectangularUnderfillFillet):
                local = tuple(to_local(p, source.fragment.placement) for p in points)
                side = _boundary_side(source.fragment.root, local, 1e-10, None).value
            else:
                side = _shell_side(
                    source.fragment,
                    _classify_local_side(source.fragment, points, 1e-10),
                )
            by_side[side].append(face)
        boundaries[component].update({(fid, s): tuple(v) for s, v in by_side.items()})
        # Every actual boundary facet is available for exact semantic matching.
        locked[component].update({(fid, s): tuple(v) for s, v in by_side.items()})
        volume = sum(
            math.prod(b - a for a, b in candidate[fid][j]) for j in assigned[fid]
        )
        analytic = (
            _analytic_volume(source.fragment.root)
            if isinstance(source.fragment.root, CanonicalRectangularUnderfillFillet)
            else math.fsum(
                math.prod(b - a for a, b in box)
                for box in root_boxes(source.fragment.root)
            )
        )
        locked_edges = tuple(
            math.dist(a, b)
            for q in plan.locks
            if q.target_fragment_id == fid
            for a, b in zip(q.points, (*q.points[1:], q.points[0]))
        )
        evidence[component][fid] = {
            "applied_volume_path": "gmsh_orthogonal_domain",
            "gmsh_owns_all_volume_connectivity": True,
            "cartesian_hex_verified": True,
            "orthogonal_domain_plan": plan_evidence,
            "analytic_volume_mm3": analytic,
            "signed_volume_error_mm3": volume - analytic,
            "relative_volume_error": abs(volume - analytic) / analytic,
            "immutable_target_edge_override_count": sum(
                v > source.target + 1.0e-10 for v in locked_edges
            ),
            "immutable_maximum_edge_mm": max(locked_edges, default=0.0),
        }
        grids[component][fid] = OrthogonalBlockCandidates(
            fid, tuple(candidate[fid]), tuple(assigned[fid])
        )
        if isinstance(source.fragment.root, CanonicalRectangularUnderfillFillet):
            diagnostic_nodes = tuple(
                OrthogonalHexNode(
                    n.local_node_id,
                    to_local(n.coordinates_mm, source.fragment.placement),
                    n.coordinates_mm,
                )
                for n in fragment.nodes
            )
            diagnostic_elements = []
            diagnostic_faces = defaultdict(list)
            for element in fragment.elements:
                points = [
                    to_local(node_by_id[n].coordinates_mm, source.fragment.placement)
                    for n in element.node_ids
                ]
                bounds = tuple(
                    (min(p[a] for p in points), max(p[a] for p in points))
                    for a in range(3)
                )
                row = OrthogonalHexElement(
                    element.local_element_id,
                    element.node_ids,
                    (element.local_element_id - 1, 0, 0),
                    bounds,
                    OrthogonalCellClass.CUT,
                    OrthogonalRetentionReason.CUT_CENTER_INSIDE,
                    (),
                    math.prod(b - a for a, b in bounds),
                )
                diagnostic_elements.append(row)
                for indices in HEX_FACES:
                    face = tuple(element.node_ids[j] for j in indices)
                    diagnostic_faces[frozenset(face)].append((row, face))
            evidence[component][fid]["mesh_warnings"] = _mesh_topology_warnings(
                source.fragment, diagnostic_nodes, diagnostic_elements, diagnostic_faces
            )
            for side, z in (
                ("base", source.fragment.root.base_z_mm),
                (
                    "cap",
                    source.fragment.root.base_z_mm
                    + source.fragment.root.wall_height_mm,
                ),
            ):
                quads = []
                for bounds in candidate[fid]:
                    on = tuple(
                        p
                        for p in corners(bounds)
                        if abs(to_local(p, source.fragment.placement)[2] - z) < 1e-10
                    )
                    if len(on) == 4:
                        normal = next(
                            a for a in range(3) if len({p[a] for p in on}) == 1
                        )
                        u, v = [a for a in range(3) if a != normal]
                        center = tuple(sum(p[a] for p in on) / 4 for a in range(3))
                        quads.append(
                            tuple(
                                sorted(
                                    on,
                                    key=lambda p: math.atan2(
                                        p[v] - center[v], p[u] - center[u]
                                    ),
                                )
                            )
                        )
                endpoints[component][(fid, side)] = tuple(quads)
    # Hard patches must survive exactly for rectilinear solids. Fillet retains
    # its explicit centre-sampling contract and reports actual surviving contact.
    for quad in plan.locks:
        source = next(
            v for v in plan.inputs if v.fragment.fragment_id == quad.target_fragment_id
        )
        if isinstance(source.fragment.root, CanonicalRectangularUnderfillFillet):
            continue
        if frozenset(quad.tokens) not in faces_by_fragment[quad.target_fragment_id]:
            raise OrthogonalConstraintError(
                "orth_locked_interface_conflict",
                "生成后的 Orth 接触面未完整保留固定 QUAD。",
                components=components,
                sources=(quad.evidence(),),
            )
    internal = []
    source_by_id = {v.fragment.fragment_id: v for v in plan.inputs}
    pairs = defaultdict(lambda: ([], []))
    for owners in shared_face_owners.values():
        if len(owners) > 2:
            raise OrthogonalConstraintError(
                "orth_nonmanifold_output",
                "共享面拥有超过两个体单元。",
                components=components,
            )
        if len(owners) == 2:
            (f, a), (g, b) = sorted(owners)
            if source_by_id[f].component_id == source_by_id[g].component_id:
                pairs[(f, g)][0].append(a)
                pairs[(f, g)][1].append(b)
    for (f, g), (a, b) in pairs.items():
        internal.extend(
            declared_shared_seams_from_facets(
                fragments[f],
                a,
                fragments[g],
                b,
                seam_key_prefix=f"orth-internal::{f}::{g}",
            )
        )
    output = {}
    for component in components:
        output[component] = MaterializedComponent(
            component,
            "orthogonal_hex",
            {
                s.fragment.fragment_id: fragments[s.fragment.fragment_id]
                for s in plan.inputs
                if s.component_id == component
            },
            boundaries[component],
            locked[component],
            backend_evidence_by_fragment_id=evidence[component],
            orthogonal_candidate_grids=grids[component],
            candidate_endpoint_quads=endpoints[component],
        )
    return output, tuple(internal)
