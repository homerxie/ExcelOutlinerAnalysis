"""Load and fingerprint one immutable Package V2 frozen-source bundle.

This first frozen-source slice is intentionally read-only.  It binds an exact
MSH content fingerprint to a :class:`CompiledFrozenSource`,
selects the declared source-local Components, validates their non-overlap, and preserves the compiled rigid
placement for a later assembly stage.  It does not transform, merge or remesh
the imported volume mesh.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, replace
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
from types import MappingProxyType
from typing import Any, Iterable, Mapping

from .package_assembly import AssemblyPolicyError, Component, FrozenSource
from .package_v2_compile import (
    CanonicalFrozenPlacement,
    CompiledFrozenSource,
    FrozenArtifactDescriptor,
    IdentifierBinding,
    frozen_component_global_id,
)
from .volume_mesh import (
    ELEMENT_SPECS,
    ElementKind,
    MeshNode,
    PhysicalGroup,
    VolumeElement,
    VolumeMesh,
)
from .volume_mesh import load_volume_mesh


DEFAULT_MAX_FROZEN_MESH_BYTES = 512 * 1024 * 1024
DEFAULT_MAX_FROZEN_NODES = 5_000_000
DEFAULT_MAX_FROZEN_ELEMENTS = 10_000_000
DEFAULT_MAX_FROZEN_ESTIMATED_MEMORY_BYTES = 4 * 1024 * 1024 * 1024
DEFAULT_MAX_FROZEN_ENTITIES = 10_000_000
DEFAULT_MAX_FROZEN_CONNECTIVITY = 80_000_000
DEFAULT_MAX_FROZEN_PHYSICAL_GROUP_MEMBERSHIPS = 20_000_000
_READ_BLOCK_BYTES = 1024 * 1024
_MAX_MSH_LINE_BYTES = 1024 * 1024
_MAX_FROZEN_MSH_TAG = 2_147_483_647
_ESTIMATED_BYTES_PER_NODE = 512
_ESTIMATED_BYTES_PER_ELEMENT = 1024
_SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")
_ARTIFACT_ROLES = ("mesh",)
_MAPPING_PROXY_TYPE = type(MappingProxyType({}))
_MAX_FROZEN_ID_UTF8_BYTES = 4_096
_MAX_FROZEN_GLOBAL_ID_UTF8_BYTES = 16_384
_FROZEN_AUDIT_MESH_COPY_COUNT = 3
_ELEMENT_KIND_NAMES = frozenset(value.value for value in ElementKind)
_FROZEN_LIMIT_CEILINGS = {
    "maximum_mesh_bytes": DEFAULT_MAX_FROZEN_MESH_BYTES,
    "maximum_node_count": DEFAULT_MAX_FROZEN_NODES,
    "maximum_element_count": DEFAULT_MAX_FROZEN_ELEMENTS,
    "maximum_estimated_memory_bytes": DEFAULT_MAX_FROZEN_ESTIMATED_MEMORY_BYTES,
    "maximum_entity_count": DEFAULT_MAX_FROZEN_ENTITIES,
    "maximum_connectivity_count": DEFAULT_MAX_FROZEN_CONNECTIVITY,
    "maximum_physical_group_membership_count": (
        DEFAULT_MAX_FROZEN_PHYSICAL_GROUP_MEMBERSHIPS
    ),
}


class FrozenSourceError(RuntimeError):
    """Raised when a frozen artifact bundle is incomplete or inconsistent."""


def _positive_limit(value: object, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise FrozenSourceError(f"{field_name} must be a positive integer")
    return value


def _bounded_identity(
    value: object,
    *,
    field_name: str,
    maximum_utf8_bytes: int = _MAX_FROZEN_ID_UTF8_BYTES,
) -> str:
    if (
        type(value) is not str
        or not value
        or value != value.strip()
        or len(value) > maximum_utf8_bytes
        or any(ord(character) < 32 or 127 <= ord(character) <= 159 for character in value)
    ):
        raise FrozenSourceError(f"{field_name} is invalid")
    if len(value.encode("utf-8")) > maximum_utf8_bytes:
        raise FrozenSourceError(f"{field_name} exceeds the UTF-8 byte limit")
    return value


def _strictly_increasing(values: Iterable[Any]) -> bool:
    iterator = iter(values)
    try:
        previous = next(iterator)
    except StopIteration:
        return True
    for current in iterator:
        if not previous < current:
            return False
        previous = current
    return True


@dataclass(frozen=True, slots=True)
class FrozenSourceLimits:
    """Explicit resource budget applied before Gmsh expands an ASCII MSH."""

    maximum_mesh_bytes: int = DEFAULT_MAX_FROZEN_MESH_BYTES
    maximum_node_count: int = DEFAULT_MAX_FROZEN_NODES
    maximum_element_count: int = DEFAULT_MAX_FROZEN_ELEMENTS
    maximum_estimated_memory_bytes: int = (
        DEFAULT_MAX_FROZEN_ESTIMATED_MEMORY_BYTES
    )
    maximum_entity_count: int = DEFAULT_MAX_FROZEN_ENTITIES
    maximum_connectivity_count: int = DEFAULT_MAX_FROZEN_CONNECTIVITY
    maximum_physical_group_membership_count: int = (
        DEFAULT_MAX_FROZEN_PHYSICAL_GROUP_MEMBERSHIPS
    )

    def __post_init__(self) -> None:
        for field_name, ceiling in _FROZEN_LIMIT_CEILINGS.items():
            value = _positive_limit(getattr(self, field_name), field_name=field_name)
            if value > ceiling:
                raise FrozenSourceError(
                    f"{field_name} exceeds the implementation safety ceiling"
                )
            object.__setattr__(self, field_name, value)


def _replay_frozen_limits(value: FrozenSourceLimits) -> FrozenSourceLimits:
    if type(value) is not FrozenSourceLimits:
        raise FrozenSourceError("limits must be an exact FrozenSourceLimits")
    replayed = FrozenSourceLimits(
        maximum_mesh_bytes=value.maximum_mesh_bytes,
        maximum_node_count=value.maximum_node_count,
        maximum_element_count=value.maximum_element_count,
        maximum_estimated_memory_bytes=value.maximum_estimated_memory_bytes,
        maximum_entity_count=value.maximum_entity_count,
        maximum_connectivity_count=value.maximum_connectivity_count,
        maximum_physical_group_membership_count=(
            value.maximum_physical_group_membership_count
        ),
    )
    if replayed != value:
        raise FrozenSourceError("frozen source limits are stale or non-canonical")
    return replayed


def _sha256_text(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _canonical_json_bytes(value: object) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (OverflowError, TypeError, ValueError) as error:
        raise FrozenSourceError("cannot encode canonical frozen JSON") from error


def _digest_payload(value: object) -> str:
    return _sha256_text(_canonical_json_bytes(value))


def _update_digest_record(digest: Any, value: object) -> None:
    encoded = _canonical_json_bytes(value)
    digest.update(len(encoded).to_bytes(8, "big"))
    digest.update(encoded)


def _stream_numbered_digest(
    *,
    schema: str,
    metadata: object,
    sections: tuple[tuple[str, int, Iterable[object]], ...],
) -> str:
    """Hash canonical rows without constructing a whole-mesh JSON tree."""

    digest = hashlib.sha256()
    _update_digest_record(digest, {"schema": schema, "metadata": metadata})
    for name, expected_count, records in sections:
        _update_digest_record(
            digest,
            {"section": name, "count": expected_count},
        )
        actual_count = 0
        for record in records:
            _update_digest_record(digest, record)
            actual_count += 1
        if actual_count != expected_count:
            raise FrozenSourceError(
                f"frozen fingerprint section {name!r} has inconsistent length"
            )
    return digest.hexdigest()


def _canonical_float(value: float) -> float:
    if not math.isfinite(value):
        raise FrozenSourceError("frozen fingerprint contains a non-finite number")
    return 0.0 if value == 0.0 else value


@dataclass(frozen=True, slots=True)
class FrozenArtifactIdentity:
    role: str
    declaration: str
    runtime_path: str
    size_bytes: int
    sha256: str

    def __post_init__(self) -> None:
        if self.role not in _ARTIFACT_ROLES:
            raise FrozenSourceError("frozen artifact role is invalid")
        if not isinstance(self.declaration, str) or not self.declaration:
            raise FrozenSourceError("frozen artifact declaration must be non-empty")
        if not isinstance(self.runtime_path, str) or not self.runtime_path:
            raise FrozenSourceError("frozen artifact runtime_path must be non-empty")
        if (
            isinstance(self.size_bytes, bool)
            or not isinstance(self.size_bytes, int)
            or self.size_bytes < 0
        ):
            raise FrozenSourceError("frozen artifact size_bytes must be non-negative")
        if not isinstance(self.sha256, str) or not _SHA256_PATTERN.fullmatch(
            self.sha256
        ):
            raise FrozenSourceError("frozen artifact sha256 must be lower-case hex")


@dataclass(frozen=True, slots=True)
class FrozenComponentFingerprint:
    local_component_id: str
    global_component_id: str
    physical_group_tag: int
    element_count: int
    node_count: int
    element_kind_counts: Mapping[str, int]
    element_tags: tuple[int, ...]
    node_tags: tuple[int, ...]
    node_numbered_sha256: str
    element_numbered_sha256: str
    numbered_sha256: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "element_kind_counts",
            MappingProxyType(dict(self.element_kind_counts)),
        )
        object.__setattr__(self, "element_tags", tuple(self.element_tags))
        object.__setattr__(self, "node_tags", tuple(self.node_tags))


@dataclass(frozen=True, slots=True)
class FrozenSourceSnapshot:
    source_id: str
    placement: CanonicalFrozenPlacement
    mesh: VolumeMesh
    artifacts: Mapping[str, FrozenArtifactIdentity]
    components: Mapping[str, FrozenComponentFingerprint]
    node_count: int
    element_count: int
    preflight_estimated_memory_bytes: int
    element_kind_counts: Mapping[str, int]
    numbered_sha256: str

    def __post_init__(self) -> None:
        for field_name in (
            "node_count",
            "element_count",
            "preflight_estimated_memory_bytes",
        ):
            object.__setattr__(
                self,
                field_name,
                _positive_limit(getattr(self, field_name), field_name=field_name),
            )
        object.__setattr__(self, "artifacts", MappingProxyType(dict(self.artifacts)))
        object.__setattr__(self, "components", MappingProxyType(dict(self.components)))
        object.__setattr__(
            self,
            "element_kind_counts",
            MappingProxyType(dict(self.element_kind_counts)),
        )


@dataclass(frozen=True, slots=True)
class _ArtifactSnapshot:
    role: str
    path: Path
    size_bytes: int
    sha256: str
    device: int
    inode: int


@dataclass(frozen=True, slots=True)
class _ArtifactCapture:
    snapshot: _ArtifactSnapshot


def _stat_signature(value: os.stat_result) -> tuple[int, int, int, int, int]:
    return (
        int(value.st_dev),
        int(value.st_ino),
        int(value.st_size),
        int(getattr(value, "st_mtime_ns", round(value.st_mtime * 1.0e9))),
        int(getattr(value, "st_ctime_ns", round(value.st_ctime * 1.0e9))),
    )


def _regular_lstat(path: Path, *, role: str) -> os.stat_result:
    try:
        result = os.lstat(path)
    except OSError as error:
        raise FrozenSourceError(
            f"frozen {role} artifact is not readable: {path}"
        ) from error
    if not stat.S_ISREG(result.st_mode):
        raise FrozenSourceError(
            f"frozen {role} artifact must be a regular file: {path}"
        )
    return result


def _open_read_flags() -> int:
    flags = os.O_RDONLY
    flags |= getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_NONBLOCK", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    return flags


def _capture_regular_file(
    path: Path,
    *,
    role: str,
    maximum_size: int | None = None,
    snapshot_copy_path: Path | None = None,
    cancelled=lambda: False,
) -> _ArtifactCapture:
    before = _regular_lstat(path, role=role)
    if maximum_size is not None and before.st_size > maximum_size:
        raise FrozenSourceError(
            f"frozen {role} artifact exceeds the "
            f"{maximum_size}-byte limit"
        )

    descriptor: int | None = None
    copy_descriptor: int | None = None
    digest = hashlib.sha256()
    byte_count = 0
    try:
        descriptor = os.open(path, _open_read_flags())
        if snapshot_copy_path is not None:
            copy_descriptor = os.open(
                snapshot_copy_path,
                os.O_WRONLY
                | os.O_CREAT
                | os.O_EXCL
                | getattr(os, "O_BINARY", 0),
                0o600,
            )
        opened = os.fstat(descriptor)
        if not stat.S_ISREG(opened.st_mode):
            raise FrozenSourceError(
                f"frozen {role} artifact must remain a regular file: {path}"
            )
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise FrozenSourceError(
                f"frozen {role} artifact changed while it was opened: {path}"
            )
        while True:
            if cancelled():
                raise InterruptedError("已取消网格指纹计算")
            block = os.read(descriptor, _READ_BLOCK_BYTES)
            if not block:
                break
            byte_count += len(block)
            if maximum_size is not None and byte_count > maximum_size:
                raise FrozenSourceError(
                    f"frozen {role} artifact exceeds the "
                    f"{maximum_size}-byte limit"
                )
            digest.update(block)
            if copy_descriptor is not None:
                remaining = memoryview(block)
                while remaining:
                    written = os.write(copy_descriptor, remaining)
                    if written <= 0:
                        raise FrozenSourceError(
                            "cannot write the private frozen mesh snapshot"
                        )
                    remaining = remaining[written:]
        if copy_descriptor is not None:
            os.fsync(copy_descriptor)
            if os.fstat(copy_descriptor).st_size != byte_count:
                raise FrozenSourceError(
                    "private frozen mesh snapshot size is inconsistent"
                )
        after_descriptor = os.fstat(descriptor)
    except FrozenSourceError:
        raise
    except OSError as error:
        raise FrozenSourceError(
            f"cannot snapshot frozen {role} artifact: {path}"
        ) from error
    finally:
        if copy_descriptor is not None:
            os.close(copy_descriptor)
        if descriptor is not None:
            os.close(descriptor)

    after_path = _regular_lstat(path, role=role)
    if (
        _stat_signature(before) != _stat_signature(opened)
        or _stat_signature(opened) != _stat_signature(after_descriptor)
        or _stat_signature(after_descriptor) != _stat_signature(after_path)
        or byte_count != int(after_descriptor.st_size)
    ):
        raise FrozenSourceError(
            f"frozen {role} artifact changed while it was snapshotted: {path}"
        )
    snapshot = _ArtifactSnapshot(
        role,
        path,
        byte_count,
        digest.hexdigest(),
        int(after_descriptor.st_dev),
        int(after_descriptor.st_ino),
    )
    return _ArtifactCapture(snapshot)


def _runtime_paths(source: CompiledFrozenSource) -> dict[str, Path]:
    path = source.artifacts.mesh_runtime_path
    _regular_lstat(path, role="mesh")
    return {"mesh": path}


def _bounded_msh_line(stream: Any, *, context: str) -> bytes:
    line = stream.readline(_MAX_MSH_LINE_BYTES + 1)
    if len(line) > _MAX_MSH_LINE_BYTES:
        raise FrozenSourceError(
            f"frozen MSH contains an oversized {context} line"
        )
    return line


def _msh_section_count(line: bytes, *, section: str) -> int:
    fields = line.split()
    if len(fields) != 4:
        raise FrozenSourceError(f"frozen MSH {section} header is invalid")
    try:
        block_count, value_count, minimum_tag, maximum_tag = (
            int(value) for value in fields
        )
    except ValueError as error:
        raise FrozenSourceError(
            f"frozen MSH {section} header is invalid"
        ) from error
    if (
        block_count < 1
        or value_count < 1
        or block_count > value_count
        or minimum_tag < 1
        or maximum_tag < minimum_tag
        or maximum_tag > _MAX_FROZEN_MSH_TAG
    ):
        raise FrozenSourceError(f"frozen MSH {section} counts are invalid")
    return value_count


def _msh_section_name(marker: bytes) -> str:
    if not marker.startswith(b"$") or marker.startswith(b"$End"):
        raise FrozenSourceError("frozen MSH contains an invalid section marker")
    try:
        name = marker[1:].decode("ascii", errors="strict")
    except UnicodeError as error:
        raise FrozenSourceError(
            "frozen MSH section names must be ASCII"
        ) from error
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name):
        raise FrozenSourceError("frozen MSH contains an invalid section name")
    return name


def _skip_msh_section(stream: Any, *, section: str) -> None:
    expected_end = f"$End{section}".encode("ascii")
    while True:
        line = _bounded_msh_line(stream, context=f"{section} body")
        if not line:
            raise FrozenSourceError(
                f"frozen MSH section {section!r} is not closed"
            )
        if line.strip() == expected_end:
            return


def _preflight_entities_section(
    stream: Any,
    *,
    limits: FrozenSourceLimits,
) -> dict[int, int]:
    fields = _bounded_msh_line(stream, context="Entities header").split()
    if len(fields) != 4:
        raise FrozenSourceError("frozen MSH Entities header is invalid")
    try:
        counts = tuple(int(value) for value in fields)
    except ValueError as error:
        raise FrozenSourceError("frozen MSH Entities header is invalid") from error
    if any(value < 0 for value in counts):
        raise FrozenSourceError("frozen MSH Entities counts are invalid")
    volume_count = counts[3]
    if volume_count > limits.maximum_entity_count:
        raise FrozenSourceError(
            "frozen MSH entity count exceeds the resource limit"
        )

    volume_physical_counts: dict[int, int] = {}
    entity_memberships = 0
    for dimension, count in enumerate(counts):
        for _index in range(count):
            line = _bounded_msh_line(
                stream,
                context=f"Entities dimension {dimension} record",
            )
            record = line.split()
            if not record:
                raise FrozenSourceError(
                    "frozen MSH contains an empty entity record"
                )
            if dimension != 3:
                continue
            try:
                entity_tag = int(record[0])
                physical_count = int(record[7])
            except (IndexError, ValueError) as error:
                raise FrozenSourceError(
                    "frozen MSH volume entity record is invalid"
                ) from error
            physical_end = 8 + physical_count
            try:
                boundary_count = int(record[physical_end])
                physical_tags = tuple(
                    int(value) for value in record[8:physical_end]
                )
                boundary_tags = tuple(
                    int(value) for value in record[physical_end + 1 :]
                )
            except (IndexError, ValueError) as error:
                raise FrozenSourceError(
                    "frozen MSH volume entity record is invalid"
                ) from error
            if (
                entity_tag < 1
                or entity_tag > _MAX_FROZEN_MSH_TAG
                or entity_tag in volume_physical_counts
                or physical_count < 0
                or len(physical_tags) != physical_count
                or any(value < 1 for value in physical_tags)
                or any(value > _MAX_FROZEN_MSH_TAG for value in physical_tags)
                or len(set(physical_tags)) != len(physical_tags)
                or boundary_count < 0
                or len(boundary_tags) != boundary_count
                or any(value == 0 for value in boundary_tags)
            ):
                raise FrozenSourceError(
                    "frozen MSH volume entity record is invalid"
                )
            entity_memberships += physical_count
            if entity_memberships > (
                limits.maximum_physical_group_membership_count
            ):
                raise FrozenSourceError(
                    "frozen MSH Physical Group memberships exceed the resource limit"
                )
            volume_physical_counts[entity_tag] = physical_count
    if _bounded_msh_line(
        stream,
        context="Entities terminator",
    ).strip() != b"$EndEntities":
        raise FrozenSourceError("frozen MSH Entities section is not closed")
    return volume_physical_counts


def _preflight_nodes_section(
    stream: Any,
    *,
    limits: FrozenSourceLimits,
) -> int:
    fields = _bounded_msh_line(stream, context="Nodes header").split()
    if len(fields) != 4:
        raise FrozenSourceError("frozen MSH Nodes header is invalid")
    try:
        block_count, node_count, minimum_tag, maximum_tag = (
            int(value) for value in fields
        )
    except ValueError as error:
        raise FrozenSourceError("frozen MSH Nodes header is invalid") from error
    if (
        block_count < 1
        or node_count < 1
        or block_count > node_count
        or minimum_tag < 1
        or maximum_tag < minimum_tag
        or maximum_tag > _MAX_FROZEN_MSH_TAG
    ):
        raise FrozenSourceError("frozen MSH Nodes counts are invalid")
    if node_count > limits.maximum_node_count:
        raise FrozenSourceError(
            "frozen MSH declared node count exceeds the resource limit: "
            f"{node_count} > {limits.maximum_node_count}"
        )

    parsed_nodes = 0
    node_tags: set[int] = set()
    for _block_index in range(block_count):
        block_fields = _bounded_msh_line(
            stream,
            context="Nodes block header",
        ).split()
        if len(block_fields) != 4:
            raise FrozenSourceError("frozen MSH Nodes block is invalid")
        try:
            dimension, entity_tag, parametric, block_nodes = (
                int(value) for value in block_fields
            )
        except ValueError as error:
            raise FrozenSourceError(
                "frozen MSH Nodes block is invalid"
            ) from error
        if (
            dimension not in (0, 1, 2, 3)
            or entity_tag < 1
            or entity_tag > _MAX_FROZEN_MSH_TAG
            or parametric not in (0, 1)
            or block_nodes < 1
        ):
            raise FrozenSourceError("frozen MSH Nodes block is invalid")
        parsed_nodes += block_nodes
        if parsed_nodes > node_count:
            raise FrozenSourceError(
                "frozen MSH Nodes blocks exceed the declared count"
            )

        for _node_index in range(block_nodes):
            record = _bounded_msh_line(
                stream,
                context="Nodes tag record",
            ).split()
            if len(record) != 1:
                raise FrozenSourceError("frozen MSH node tag record is invalid")
            try:
                node_tag = int(record[0])
            except ValueError as error:
                raise FrozenSourceError(
                    "frozen MSH node tag record is invalid"
                ) from error
            if (
                node_tag < minimum_tag
                or node_tag > maximum_tag
                or node_tag > _MAX_FROZEN_MSH_TAG
                or node_tag in node_tags
            ):
                raise FrozenSourceError("frozen MSH node tag record is invalid")
            node_tags.add(node_tag)

        coordinate_count = 3 + (dimension if parametric else 0)
        for _node_index in range(block_nodes):
            record = _bounded_msh_line(
                stream,
                context="Nodes coordinate record",
            ).split()
            if len(record) != coordinate_count:
                raise FrozenSourceError(
                    "frozen MSH node coordinate record is invalid"
                )
            try:
                coordinates = tuple(float(value) for value in record)
            except ValueError as error:
                raise FrozenSourceError(
                    "frozen MSH node coordinate record is invalid"
                ) from error
            if any(not math.isfinite(value) for value in coordinates):
                raise FrozenSourceError(
                    "frozen MSH node coordinate record is invalid"
                )
    if (
        parsed_nodes != node_count
        or len(node_tags) != node_count
        or min(node_tags) != minimum_tag
        or max(node_tags) != maximum_tag
    ):
        raise FrozenSourceError(
            "frozen MSH Nodes blocks differ from the declared count or tag range"
        )
    if _bounded_msh_line(
        stream,
        context="Nodes terminator",
    ).strip() != b"$EndNodes":
        raise FrozenSourceError("frozen MSH Nodes section is not closed")
    return node_count


def _preflight_elements_section(
    stream: Any,
    *,
    limits: FrozenSourceLimits,
    volume_physical_counts: Mapping[int, int],
) -> tuple[int, int]:
    fields = _bounded_msh_line(stream, context="Elements header").split()
    if len(fields) != 4:
        raise FrozenSourceError("frozen MSH Elements header is invalid")
    try:
        block_count, element_count, minimum_tag, maximum_tag = (
            int(value) for value in fields
        )
    except ValueError as error:
        raise FrozenSourceError("frozen MSH Elements header is invalid") from error
    if (
        block_count < 1
        or element_count < 1
        or block_count > element_count
        or minimum_tag < 1
        or maximum_tag < minimum_tag
        or maximum_tag > _MAX_FROZEN_MSH_TAG
    ):
        raise FrozenSourceError("frozen MSH Elements counts are invalid")
    if element_count > limits.maximum_element_count:
        raise FrozenSourceError(
            "frozen MSH declared element count exceeds the resource limit: "
            f"{element_count} > {limits.maximum_element_count}"
        )

    parsed_elements = 0
    connectivity_count = 0
    element_group_memberships = 0
    for _block_index in range(block_count):
        block_fields = _bounded_msh_line(
            stream,
            context="Elements block header",
        ).split()
        if len(block_fields) != 4:
            raise FrozenSourceError("frozen MSH Elements block is invalid")
        try:
            dimension, entity_tag, gmsh_type, block_elements = (
                int(value) for value in block_fields
            )
        except ValueError as error:
            raise FrozenSourceError(
                "frozen MSH Elements block is invalid"
            ) from error
        specification = ELEMENT_SPECS.get(gmsh_type)
        if (
            dimension != 3
            or entity_tag not in volume_physical_counts
            or entity_tag > _MAX_FROZEN_MSH_TAG
            or specification is None
            or block_elements < 1
        ):
            raise FrozenSourceError(
                "frozen MSH must contain supported volume elements only"
            )
        node_count = specification[1]
        parsed_elements += block_elements
        connectivity_count += block_elements * node_count
        element_group_memberships += (
            block_elements * volume_physical_counts[entity_tag]
        )
        if parsed_elements > element_count:
            raise FrozenSourceError(
                "frozen MSH Elements blocks exceed the declared count"
            )
        if connectivity_count > limits.maximum_connectivity_count:
            raise FrozenSourceError(
                "frozen MSH connectivity count exceeds the resource limit"
            )
        if element_group_memberships > (
            limits.maximum_physical_group_membership_count
        ):
            raise FrozenSourceError(
                "frozen MSH Physical Group memberships exceed the resource limit"
            )
        for _element_index in range(block_elements):
            record = _bounded_msh_line(
                stream,
                context="Elements record",
            ).split()
            if len(record) != node_count + 1:
                raise FrozenSourceError(
                    "frozen MSH element connectivity record is invalid"
                )
            try:
                values = tuple(int(value) for value in record)
            except ValueError as error:
                raise FrozenSourceError(
                    "frozen MSH element connectivity record is invalid"
                ) from error
            if (
                values[0] < 1
                or values[0] > _MAX_FROZEN_MSH_TAG
                or any(
                    value < 1 or value > _MAX_FROZEN_MSH_TAG
                    for value in values[1:]
                )
            ):
                raise FrozenSourceError(
                    "frozen MSH element connectivity record is invalid"
                )
    if parsed_elements != element_count:
        raise FrozenSourceError(
            "frozen MSH Elements blocks differ from the declared count"
        )
    if _bounded_msh_line(
        stream,
        context="Elements terminator",
    ).strip() != b"$EndElements":
        raise FrozenSourceError("frozen MSH Elements section is not closed")
    return element_count, connectivity_count


def _preflight_private_mesh(
    path: Path,
    *,
    limits: FrozenSourceLimits,
) -> tuple[int, int, int]:
    declared_nodes: int | None = None
    declared_elements: int | None = None
    volume_physical_counts: dict[int, int] | None = None
    try:
        with path.open("rb") as stream:
            marker = _bounded_msh_line(stream, context="format marker").strip()
            format_fields = _bounded_msh_line(
                stream,
                context="format header",
            ).split()
            if marker != b"$MeshFormat" or format_fields != [b"4.1", b"0", b"8"]:
                raise FrozenSourceError(
                    "frozen MSH must be ASCII Gmsh MSH 4.1"
                )
            format_end = _bounded_msh_line(
                stream,
                context="format terminator",
            ).strip()
            if format_end != b"$EndMeshFormat":
                raise FrozenSourceError(
                    "frozen MSH MeshFormat section is not closed"
                )
            while True:
                raw_line = _bounded_msh_line(stream, context="section marker")
                if not raw_line:
                    break
                line = raw_line.strip()
                if not line:
                    continue
                section = _msh_section_name(line)
                if section == "MeshFormat":
                    raise FrozenSourceError(
                        "frozen MSH contains a duplicate MeshFormat section"
                    )
                if section == "Entities":
                    if volume_physical_counts is not None:
                        raise FrozenSourceError(
                            "frozen MSH contains duplicate Entities sections"
                        )
                    volume_physical_counts = _preflight_entities_section(
                        stream,
                        limits=limits,
                    )
                    continue
                if section == "Nodes":
                    if declared_nodes is not None:
                        raise FrozenSourceError(
                            "frozen MSH contains duplicate Nodes sections"
                        )
                    declared_nodes = _preflight_nodes_section(
                        stream,
                        limits=limits,
                    )
                    continue
                elif section == "Elements":
                    if declared_elements is not None:
                        raise FrozenSourceError(
                            "frozen MSH contains duplicate Elements sections"
                        )
                    if volume_physical_counts is None:
                        raise FrozenSourceError(
                            "frozen MSH Elements must follow Entities metadata"
                        )
                    declared_elements, _connectivity_count = (
                        _preflight_elements_section(
                            stream,
                            limits=limits,
                            volume_physical_counts=volume_physical_counts,
                        )
                    )
                    continue
                _skip_msh_section(stream, section=section)
    except FrozenSourceError:
        raise
    except OSError as error:
        raise FrozenSourceError("cannot preflight the private frozen MSH") from error

    if (
        volume_physical_counts is None
        or declared_nodes is None
        or declared_elements is None
    ):
        raise FrozenSourceError(
            "frozen MSH is missing Entities, Nodes, or Elements metadata"
        )
    if declared_nodes > limits.maximum_node_count:
        raise FrozenSourceError(
            "frozen MSH declared node count exceeds the resource limit: "
            f"{declared_nodes} > {limits.maximum_node_count}"
        )
    if declared_elements > limits.maximum_element_count:
        raise FrozenSourceError(
            "frozen MSH declared element count exceeds the resource limit: "
            f"{declared_elements} > {limits.maximum_element_count}"
        )
    estimated_memory = (
        declared_nodes * _ESTIMATED_BYTES_PER_NODE
        + declared_elements * _ESTIMATED_BYTES_PER_ELEMENT
    )
    combined_estimated_memory = (
        estimated_memory * _FROZEN_AUDIT_MESH_COPY_COUNT
    )
    if combined_estimated_memory > limits.maximum_estimated_memory_bytes:
        raise FrozenSourceError(
            "frozen MSH estimated in-memory expansion for loader plus "
            "artifact-bound audit replay exceeds the resource limit: "
            f"{combined_estimated_memory} > "
            f"{limits.maximum_estimated_memory_bytes}"
        )
    return declared_nodes, declared_elements, estimated_memory


def _physical_group_registry(
    mesh: VolumeMesh,
) -> dict[str, tuple[PhysicalGroup, ...]]:
    by_name: dict[str, tuple[PhysicalGroup, ...]] = {}
    by_tag: dict[int, str] = {}
    for groups in mesh.entity_physical_groups.values():
        for group in groups:
            previous = by_tag.setdefault(group.tag, group.name)
            if previous != group.name:
                raise FrozenSourceError(
                    f"3D Physical Group tag {group.tag} has inconsistent names"
                )
            candidates = by_name.get(group.name)
            if candidates is None:
                by_name[group.name] = (group,)
            elif group not in candidates and len(candidates) == 1:
                # Only cardinality one vs. many is consumed downstream.  Do
                # not retain an unbounded duplicate-name set.
                by_name[group.name] = (candidates[0], group)
    return by_name


def _node_payload(tag: int, coordinates: tuple[float, float, float]) -> list[object]:
    return [tag, *(_canonical_float(value) for value in coordinates)]


def _element_payload(element: VolumeElement) -> list[object]:
    return [
        element.tag,
        element.kind.value,
        element.gmsh_type,
        list(element.node_tags),
        element.entity_tag,
        [
            [group.tag, group.name, group.explicitly_named]
            for group in element.physical_groups
        ],
    ]


def _component_fingerprint(
    *,
    local_id: str,
    global_id: str,
    group: PhysicalGroup,
    elements: tuple[VolumeElement, ...],
    node_by_tag: Mapping[int, MeshNode],
) -> FrozenComponentFingerprint:
    element_tags = tuple(element.tag for element in elements)
    if not _strictly_increasing(element_tags):
        raise FrozenSourceError(
            "frozen Component elements are not in canonical tag order"
        )
    node_tags = tuple(
        sorted({tag for element in elements for tag in element.node_tags})
    )
    node_sha256 = _stream_numbered_digest(
        schema="easymesh-package-v2-frozen-component-nodes-numbered-v2",
        metadata={"component": [local_id, global_id]},
        sections=(
            (
                "nodes",
                len(node_tags),
                (
                    _node_payload(tag, node_by_tag[tag].coordinates)
                    for tag in node_tags
                ),
            ),
        ),
    )
    element_sha256 = _stream_numbered_digest(
        schema="easymesh-package-v2-frozen-component-elements-numbered-v2",
        metadata={"component": [local_id, global_id]},
        sections=(
            (
                "elements",
                len(elements),
                (_element_payload(element) for element in elements),
            ),
        ),
    )
    kind_counts = Counter(element.kind.value for element in elements)
    numbered_sha256 = _digest_payload(
        {
            "schema": "easymesh-package-v2-frozen-component-numbered-v2",
            "local_component_id": local_id,
            "global_component_id": global_id,
            "physical_group": [
                group.tag,
                group.name,
                group.explicitly_named,
            ],
            "node_count": len(node_tags),
            "element_count": len(elements),
            "element_kind_counts": dict(sorted(kind_counts.items())),
            "node_numbered_sha256": node_sha256,
            "element_numbered_sha256": element_sha256,
        }
    )
    return FrozenComponentFingerprint(
        local_id,
        global_id,
        group.tag,
        len(elements),
        len(node_tags),
        dict(sorted(kind_counts.items())),
        element_tags,
        node_tags,
        node_sha256,
        element_sha256,
        numbered_sha256,
    )


def _selected_frozen_mesh(mesh: VolumeMesh, source: CompiledFrozenSource) -> VolumeMesh:
    """Select whole physical volumes without changing source tags/connectivity.

    The artifact identity still binds the complete original MSH. Audit replay
    repeats this selection, so a selected snapshot remains artifact-verifiable.
    """
    if type(mesh) is not VolumeMesh:
        raise FrozenSourceError("frozen mesh loader returned an invalid mesh object")
    registry = _physical_group_registry(mesh)
    selected_groups = set()
    for binding in source.components:
        candidates = registry.get(binding.local_id, ())
        if not candidates:
            raise FrozenSourceError(f"declared frozen Component {binding.local_id!r} is missing its exact 3D Physical Group")
        if len(candidates) != 1:
            raise FrozenSourceError(f"declared frozen Component {binding.local_id!r} must match exactly one 3D Physical Group")
        if not candidates[0].explicitly_named:
            raise FrozenSourceError(f"declared frozen Component {binding.local_id!r} must match an explicitly named 3D Physical Group")
        selected_groups.add(candidates[0])
    elements = tuple(element for element in mesh.elements if selected_groups.intersection(element.physical_groups))
    if len(elements) == len(mesh.elements):
        return mesh
    if not elements:
        raise FrozenSourceError("selected frozen Component groups are empty")
    nodes = {tag for element in elements for tag in element.node_tags}
    entities = {element.entity_tag for element in elements}
    return replace(
        mesh, elements=elements, nodes=tuple(node for node in mesh.nodes if node.tag in nodes),
        entity_physical_groups=MappingProxyType({tag: groups for tag, groups in mesh.entity_physical_groups.items()
                                                 if tag in entities}),
        dimensional_element_counts=(*mesh.dimensional_element_counts[:3], len(elements)),
        min_jacobian_determinant=min(element.min_jacobian_determinant for element in elements),
    )


def _audit_mesh_and_components(
    mesh: VolumeMesh,
    source: CompiledFrozenSource,
    *,
    limits: FrozenSourceLimits,
) -> tuple[dict[str, FrozenComponentFingerprint], dict[str, int]]:
    if type(mesh) is not VolumeMesh:
        raise FrozenSourceError("frozen mesh loader returned an invalid mesh object")
    if mesh.dimensional_element_counts[:3] != (0, 0, 0):
        raise FrozenSourceError(
            "frozen MSH must contain volume elements only; lower-dimensional "
            "elements are forbidden"
        )
    if mesh.dimensional_element_counts[3] != len(mesh.elements):
        raise FrozenSourceError("frozen MSH volume element count is inconsistent")
    supported = {
        ElementKind.TET4,
        ElementKind.HEX8,
        ElementKind.WEDGE6,
        ElementKind.PYRAMID5,
    }
    if any(element.kind not in supported for element in mesh.elements):
        raise FrozenSourceError("frozen MSH contains an unsupported volume element")
    if len(mesh.entity_physical_groups) > limits.maximum_entity_count:
        raise FrozenSourceError(
            "frozen MSH entity count exceeds the resource limit"
        )
    connectivity_count = sum(len(element.node_tags) for element in mesh.elements)
    if connectivity_count > limits.maximum_connectivity_count:
        raise FrozenSourceError(
            "frozen MSH connectivity count exceeds the resource limit"
        )
    element_group_memberships = sum(
        len(element.physical_groups) for element in mesh.elements
    )
    entity_group_memberships = sum(
        len(groups) for groups in mesh.entity_physical_groups.values()
    )
    if max(element_group_memberships, entity_group_memberships) > (
        limits.maximum_physical_group_membership_count
    ):
        raise FrozenSourceError(
            "frozen MSH Physical Group memberships exceed the resource limit"
        )
    if any(
        not math.isfinite(element.min_jacobian_determinant)
        or element.min_jacobian_determinant <= 0.0
        for element in mesh.elements
    ):
        raise FrozenSourceError("frozen MSH contains a non-positive Jacobian")

    registry = _physical_group_registry(mesh)
    groups_by_local_id: dict[str, PhysicalGroup] = {}
    for binding in source.components:
        candidates = registry.get(binding.local_id, ())
        if not candidates:
            raise FrozenSourceError(
                f"declared frozen Component {binding.local_id!r} is missing its "
                "exact 3D Physical Group"
            )
        if len(candidates) != 1:
            raise FrozenSourceError(
                f"declared frozen Component {binding.local_id!r} must match "
                "exactly one 3D Physical Group"
            )
        if not candidates[0].explicitly_named:
            raise FrozenSourceError(
                f"declared frozen Component {binding.local_id!r} must match "
                "an explicitly named 3D Physical Group"
            )
        groups_by_local_id[binding.local_id] = candidates[0]

    selected_groups = set(groups_by_local_id.values())
    node_by_tag = mesh.node_map()
    elements_by_local_id: dict[str, list[VolumeElement]] = {
        binding.local_id: [] for binding in source.components
    }
    for element in mesh.elements:
        memberships = selected_groups.intersection(element.physical_groups)
        if not memberships:
            raise FrozenSourceError(
                "declared frozen Component groups form an incomplete volume "
                f"partition at element {element.tag}"
            )
        if len(memberships) != 1:
            raise FrozenSourceError(
                "declared frozen Component groups overlap at volume element "
                f"{element.tag}"
            )
        group = next(iter(memberships))
        elements_by_local_id[group.name].append(element)

    fingerprints: dict[str, FrozenComponentFingerprint] = {}
    for binding in source.components:
        elements = tuple(elements_by_local_id[binding.local_id])
        if not elements:
            raise FrozenSourceError(
                f"declared frozen Component {binding.local_id!r} is empty"
            )
        fingerprints[binding.local_id] = _component_fingerprint(
            local_id=binding.local_id,
            global_id=binding.global_id,
            group=groups_by_local_id[binding.local_id],
            elements=elements,
            node_by_tag=node_by_tag,
        )
    kind_counts = Counter(element.kind.value for element in mesh.elements)
    return fingerprints, dict(sorted(kind_counts.items()))


def _artifact_identities(
    source: CompiledFrozenSource,
    captures: Mapping[str, _ArtifactCapture],
) -> dict[str, FrozenArtifactIdentity]:
    declarations = source.artifacts.declarations
    return {
        role: FrozenArtifactIdentity(
            role,
            declarations[role],
            str(captures[role].snapshot.path),
            captures[role].snapshot.size_bytes,
            captures[role].snapshot.sha256,
        )
        for role in _ARTIFACT_ROLES
    }


def _whole_source_numbered_sha256(
    *,
    source: CompiledFrozenSource,
    mesh: VolumeMesh,
    identities: Mapping[str, FrozenArtifactIdentity],
    components: Mapping[str, FrozenComponentFingerprint],
) -> str:
    return _stream_numbered_digest(
        schema="easymesh-package-v2-frozen-source-numbered-v2",
        metadata={
            "source_id": source.source_id,
            "placement": {
                "translation_xyz_mm": list(source.placement.translation_xyz_mm),
                "rotation_matrix": [
                    list(row) for row in source.placement.rotation_matrix
                ],
            },
            "artifacts": {
                role: {
                    "declaration": identity.declaration,
                    "runtime_path": identity.runtime_path,
                    "size_bytes": identity.size_bytes,
                    "sha256": identity.sha256,
                }
                for role, identity in sorted(identities.items())
            },
            "components": {
                local_id: fingerprint.numbered_sha256
                for local_id, fingerprint in sorted(components.items())
            },
        },
        sections=(
            (
                "nodes",
                len(mesh.nodes),
                (
                    _node_payload(node.tag, node.coordinates)
                    for node in mesh.nodes
                ),
            ),
            (
                "elements",
                len(mesh.elements),
                (_element_payload(element) for element in mesh.elements),
            ),
        ),
    )


def _audit_compiled_source_contract(
    source: CompiledFrozenSource,
    *,
    limits: FrozenSourceLimits,
) -> None:
    """Replay identity fields before paths, JSON, or Gmsh are touched."""

    _bounded_identity(source.source_id, field_name="source_id")
    if type(source.artifacts) is not FrozenArtifactDescriptor:
        raise FrozenSourceError("source artifacts evidence is invalid")
    try:
        artifacts = FrozenArtifactDescriptor(
            source.artifacts.mesh_declaration,
            source.artifacts.mesh_runtime_path,
            source.artifacts.sha256,
        )
    except (AssemblyPolicyError, AttributeError, TypeError, ValueError) as error:
        raise FrozenSourceError("source artifacts evidence is invalid") from error
    if artifacts != source.artifacts:
        raise FrozenSourceError("source artifacts evidence is non-canonical")

    placement = source.placement
    if (
        type(placement) is not CanonicalFrozenPlacement
        or type(placement.translation_xyz_mm) is not tuple
        or len(placement.translation_xyz_mm) != 3
        or any(
            type(value) is not float or not math.isfinite(value)
            for value in placement.translation_xyz_mm
        )
        or type(placement.rotation_matrix) is not tuple
        or len(placement.rotation_matrix) != 3
        or any(
            type(row) is not tuple
            or len(row) != 3
            or any(
                type(value) is not float or not math.isfinite(value)
                for value in row
            )
            for row in placement.rotation_matrix
        )
    ):
        raise FrozenSourceError("source placement evidence is invalid")
    try:
        replayed_placement = CanonicalFrozenPlacement(
            placement.translation_xyz_mm,
            placement.rotation_matrix,
        )
    except (AssemblyPolicyError, TypeError, ValueError) as error:
        raise FrozenSourceError("source placement evidence is invalid") from error
    if replayed_placement != placement:
        raise FrozenSourceError("source placement evidence is non-canonical")

    if (
        type(source.components) is not tuple
        or not source.components
        or len(source.components) > limits.maximum_element_count
    ):
        raise FrozenSourceError("source component bindings are invalid")
    if type(source.policy_source) is not FrozenSource:
        raise FrozenSourceError("source policy evidence is invalid")
    policy = source.policy_source
    if (
        type(policy.source_id) is not str
        or policy.source_id != source.source_id
        or type(policy.components) is not tuple
        or len(policy.components) != len(source.components)
        or type(policy.whole_source_frozen) is not bool
        or not policy.whole_source_frozen
    ):
        raise FrozenSourceError("source policy evidence is inconsistent")

    local_ids: set[str] = set()
    for binding, component in zip(
        source.components,
        policy.components,
        strict=True,
    ):
        if type(binding) is not IdentifierBinding:
            raise FrozenSourceError("source component binding is invalid")
        local_id = _bounded_identity(
            binding.local_id,
            field_name="local Component ID",
        )
        global_id = _bounded_identity(
            binding.global_id,
            field_name="global Component ID",
            maximum_utf8_bytes=_MAX_FROZEN_GLOBAL_ID_UTF8_BYTES,
        )
        if local_id in local_ids:
            raise FrozenSourceError("source local Component IDs are not unique")
        local_ids.add(local_id)
        if global_id != frozen_component_global_id(source.source_id, local_id):
            raise FrozenSourceError(
                "source global Component ID is not compiler-canonical"
            )
        if type(component) is not Component:
            raise FrozenSourceError("source policy Component is invalid")
        try:
            expected_component = Component.frozen(global_id, source.source_id)
        except (AssemblyPolicyError, TypeError, ValueError) as error:
            raise FrozenSourceError("source policy Component is invalid") from error
        if component != expected_component:
            raise FrozenSourceError("source policy Component is inconsistent")


def _copy_cached_volume_mesh(mesh: VolumeMesh, path: Path) -> VolumeMesh:
    """Never expose the cached object graph to mutable public snapshot DTOs."""
    groups = {}

    def copy_group(group):
        key = (group.tag, group.name, group.explicitly_named)
        if key not in groups:
            groups[key] = replace(group)
        return groups[key]

    return replace(mesh, source_path=path,
        nodes=tuple(replace(node) for node in mesh.nodes),
        elements=tuple(replace(element, physical_groups=tuple(copy_group(g) for g in element.physical_groups))
                       for element in mesh.elements),
        entity_physical_groups=MappingProxyType({tag: tuple(copy_group(g) for g in values)
                                                 for tag, values in mesh.entity_physical_groups.items()}))


def load_compiled_frozen_source(
    source: CompiledFrozenSource,
    *,
    limits: FrozenSourceLimits | None = None,
) -> FrozenSourceSnapshot:
    """Load one exact frozen bundle without transforming its source-local mesh."""

    if type(source) is not CompiledFrozenSource:
        raise FrozenSourceError("source must be a CompiledFrozenSource")
    if limits is None:
        limits = FrozenSourceLimits()
    limits = _replay_frozen_limits(limits)
    _audit_compiled_source_contract(source, limits=limits)
    paths = _runtime_paths(source)
    from .package_v2_mesh_cache import mesh_file_entry, verify_mesh_entry, trim_parsed_meshes

    entry = mesh_file_entry(paths["mesh"], maximum_mesh_bytes=limits.maximum_mesh_bytes)
    with entry.lock:
        before = {"mesh": entry.capture}
        expected_sha256 = source.artifacts.sha256
        if expected_sha256 is not None and before["mesh"].snapshot.sha256 != expected_sha256:
            raise FrozenSourceError(
                f"网格文件内容已变化或被同名文件替换：{paths['mesh']}。"
                "请核对文件后，在编辑网格实例中使用“更新网格引用”。"
            )
        if entry.parsed_mesh is None or entry.parsed_limits != limits:
            counts = _preflight_private_mesh(entry.private_path, limits=limits)
            try:
                private_mesh = load_volume_mesh(entry.private_path)
            except FrozenSourceError:
                raise
            except Exception as error:
                raise FrozenSourceError(f"cannot load frozen volume mesh: {paths['mesh']}") from error
            entry.parsed_mesh, entry.parsed_limits, entry.counts = private_mesh, limits, counts
        declared_nodes, declared_elements, estimated_memory = entry.counts
        mesh = _copy_cached_volume_mesh(entry.parsed_mesh, paths["mesh"])
        if len(mesh.nodes) != declared_nodes or sum(
            mesh.dimensional_element_counts
        ) != declared_elements:
            raise FrozenSourceError(
                "frozen MSH parsed counts differ from its declared metadata"
            )
        mesh = _selected_frozen_mesh(mesh, source)
        estimated_memory = (len(mesh.nodes) * _ESTIMATED_BYTES_PER_NODE
                            + len(mesh.elements) * _ESTIMATED_BYTES_PER_ELEMENT)
        components, kind_counts = _audit_mesh_and_components(
            mesh,
            source,
            limits=limits,
        )

        verify_mesh_entry(entry)
        trim_parsed_meshes(entry)

        identities = _artifact_identities(source, before)
        numbered_sha256 = _whole_source_numbered_sha256(
            source=source,
            mesh=mesh,
            identities=identities,
            components=components,
        )
        return FrozenSourceSnapshot(
            source.source_id,
            source.placement,
            mesh,
            identities,
            components,
            len(mesh.nodes),
            len(mesh.elements),
            estimated_memory,
            kind_counts,
            numbered_sha256,
        )


def _exact_positive_snapshot_integer(value: object, *, field_name: str) -> int:
    if type(value) is not int or value < 1:
        raise FrozenSourceError(f"snapshot {field_name} must be a positive integer")
    return value


def _audit_snapshot_group(value: object) -> PhysicalGroup:
    if (
        type(value) is not PhysicalGroup
        or type(value.tag) is not int
        or value.tag < 1
        or type(value.name) is not str
        or not value.name
        or type(value.explicitly_named) is not bool
    ):
        raise FrozenSourceError("snapshot mesh Physical Group evidence is invalid")
    return value


def _audit_snapshot_mesh_shape(
    snapshot: FrozenSourceSnapshot,
    limits: FrozenSourceLimits,
) -> int:
    mesh = snapshot.mesh
    if type(mesh) is not VolumeMesh:
        raise FrozenSourceError("snapshot.mesh must be an exact VolumeMesh")
    if (
        not isinstance(mesh.source_path, Path)
        or not mesh.source_path.is_absolute()
        or type(mesh.nodes) is not tuple
        or type(mesh.elements) is not tuple
    ):
        raise FrozenSourceError("snapshot mesh outer evidence is invalid")
    if len(mesh.nodes) > limits.maximum_node_count:
        raise FrozenSourceError("snapshot node count exceeds the resource limit")
    if len(mesh.elements) > limits.maximum_element_count:
        raise FrozenSourceError("snapshot element count exceeds the resource limit")
    if (
        type(mesh.dimensional_element_counts) is not tuple
        or len(mesh.dimensional_element_counts) != 4
        or any(
            type(value) is not int or value < 0
            for value in mesh.dimensional_element_counts
        )
        or type(mesh.min_jacobian_determinant) is not float
        or not math.isfinite(mesh.min_jacobian_determinant)
        or mesh.min_jacobian_determinant <= 0.0
    ):
        raise FrozenSourceError("snapshot mesh count/quality evidence is invalid")

    node_tag_set: set[int] = set()
    previous_node_tag = 0
    for node in mesh.nodes:
        if (
            type(node) is not MeshNode
            or type(node.tag) is not int
            or node.tag < 1
            or node.tag <= previous_node_tag
            or any(
                type(value) is not float or not math.isfinite(value)
                for value in node.coordinates
            )
        ):
            raise FrozenSourceError("snapshot mesh node evidence is invalid")
        node_tag_set.add(node.tag)
        previous_node_tag = node.tag

    element_group_memberships = 0
    connectivity_count = 0
    previous_element_tag = 0
    for element in mesh.elements:
        specification = (
            ELEMENT_SPECS.get(element.gmsh_type)
            if type(element) is VolumeElement
            and type(element.gmsh_type) is int
            else None
        )
        if (
            type(element) is not VolumeElement
            or type(element.tag) is not int
            or element.tag < 1
            or element.tag <= previous_element_tag
            or type(element.kind) is not ElementKind
            or type(element.gmsh_type) is not int
            or element.gmsh_type < 1
            or type(element.node_tags) is not tuple
            or any(type(tag) is not int or tag < 1 for tag in element.node_tags)
            or specification is None
            or specification[0] is not element.kind
            or len(element.node_tags) != specification[1]
            or len(set(element.node_tags)) != len(element.node_tags)
            or any(tag not in node_tag_set for tag in element.node_tags)
            or type(element.entity_tag) is not int
            or element.entity_tag < 1
            or type(element.physical_groups) is not tuple
            or type(element.min_jacobian_determinant) is not float
            or not math.isfinite(element.min_jacobian_determinant)
            or element.min_jacobian_determinant <= 0.0
        ):
            raise FrozenSourceError("snapshot mesh element evidence is invalid")
        for group in element.physical_groups:
            _audit_snapshot_group(group)
        if not _strictly_increasing(element.physical_groups):
            raise FrozenSourceError(
                "snapshot element Physical Groups are not canonical"
            )
        connectivity_count += len(element.node_tags)
        if connectivity_count > limits.maximum_connectivity_count:
            raise FrozenSourceError(
                "snapshot connectivity count exceeds the resource limit"
            )
        element_group_memberships += len(element.physical_groups)
        if element_group_memberships > (
            limits.maximum_physical_group_membership_count
        ):
            raise FrozenSourceError(
                "snapshot element Physical Group memberships exceed the safety limit"
            )
        previous_element_tag = element.tag

    if type(mesh.entity_physical_groups) is not _MAPPING_PROXY_TYPE:
        raise FrozenSourceError(
            "snapshot entity Physical Group evidence must be immutable"
        )
    if len(mesh.entity_physical_groups) > limits.maximum_entity_count:
        raise FrozenSourceError(
            "snapshot entity count exceeds the resource limit"
        )
    entity_group_memberships = 0
    previous_entity_tag = 0
    for entity_tag, groups in mesh.entity_physical_groups.items():
        if (
            type(entity_tag) is not int
            or entity_tag <= previous_entity_tag
            or type(groups) is not tuple
        ):
            raise FrozenSourceError(
                "snapshot entity Physical Group evidence is invalid"
            )
        for group in groups:
            _audit_snapshot_group(group)
        if not _strictly_increasing(groups):
            raise FrozenSourceError(
                "snapshot entity Physical Groups are not canonical"
            )
        entity_group_memberships += len(groups)
        if entity_group_memberships > (
            limits.maximum_physical_group_membership_count
        ):
            raise FrozenSourceError(
                "snapshot entity Physical Group memberships exceed the safety limit"
            )
        previous_entity_tag = entity_tag
    for element in mesh.elements:
        if mesh.entity_physical_groups.get(element.entity_tag) != (
            element.physical_groups
        ):
            raise FrozenSourceError(
                "snapshot element/entity Physical Groups are inconsistent"
            )
    return (
        len(mesh.nodes) * _ESTIMATED_BYTES_PER_NODE
        + len(mesh.elements) * _ESTIMATED_BYTES_PER_ELEMENT
    )


def audit_frozen_source_snapshot(
    snapshot: FrozenSourceSnapshot,
    *,
    limits: FrozenSourceLimits | None = None,
) -> FrozenSourceSnapshot:
    """Deeply replay one snapshot against its immutable mesh content.

    The returned value is a fresh canonical snapshot loaded through the same
    private-copy, resource-preflight, mesh-quality, Component-partition and
    artifact-digest boundary as :func:`load_compiled_frozen_source`.  Public
    consumers should use this returned value instead of continuing with the
    caller-owned DTO.  This prevents a separately supplied path/digest claim,
    or a post-construction mutation of a frozen dataclass, from becoming a
    trusted downstream artifact identity.
    """

    if type(snapshot) is not FrozenSourceSnapshot:
        raise FrozenSourceError(
            "snapshot must be an exact FrozenSourceSnapshot"
        )
    if limits is None:
        limits = FrozenSourceLimits()
    limits = _replay_frozen_limits(limits)

    # Cheap exact-type/cardinality checks precede artifact hashing, Gmsh, and
    # any reconstruction proportional to caller-controlled mesh evidence.
    _bounded_identity(snapshot.source_id, field_name="source_id")
    expected_memory = _audit_snapshot_mesh_shape(snapshot, limits)
    combined_estimated_memory = (
        expected_memory * _FROZEN_AUDIT_MESH_COPY_COUNT
    )
    if combined_estimated_memory > limits.maximum_estimated_memory_bytes:
        raise FrozenSourceError(
            "snapshot plus artifact-bound replay estimated memory exceeds "
            "the resource limit"
        )
    node_count = _exact_positive_snapshot_integer(
        snapshot.node_count,
        field_name="node_count",
    )
    element_count = _exact_positive_snapshot_integer(
        snapshot.element_count,
        field_name="element_count",
    )
    memory_count = _exact_positive_snapshot_integer(
        snapshot.preflight_estimated_memory_bytes,
        field_name="preflight_estimated_memory_bytes",
    )
    if (
        node_count != len(snapshot.mesh.nodes)
        or element_count != len(snapshot.mesh.elements)
        or memory_count != expected_memory
    ):
        raise FrozenSourceError("snapshot mesh resource evidence is inconsistent")

    if type(snapshot.placement) is not CanonicalFrozenPlacement:
        raise FrozenSourceError("snapshot placement evidence is invalid")
    if (
        type(snapshot.placement.translation_xyz_mm) is not tuple
        or len(snapshot.placement.translation_xyz_mm) != 3
        or any(
            type(value) is not float or not math.isfinite(value)
            for value in snapshot.placement.translation_xyz_mm
        )
        or type(snapshot.placement.rotation_matrix) is not tuple
        or len(snapshot.placement.rotation_matrix) != 3
        or any(
            type(row) is not tuple
            or len(row) != 3
            or any(
                type(value) is not float or not math.isfinite(value)
                for value in row
            )
            for row in snapshot.placement.rotation_matrix
        )
    ):
        raise FrozenSourceError("snapshot placement numeric types are invalid")
    try:
        placement = CanonicalFrozenPlacement(
            snapshot.placement.translation_xyz_mm,
            snapshot.placement.rotation_matrix,
        )
    except (AssemblyPolicyError, AttributeError, TypeError, ValueError) as error:
        raise FrozenSourceError("snapshot placement evidence is invalid") from error
    if placement != snapshot.placement:
        raise FrozenSourceError(
            "snapshot placement evidence is stale or non-canonical"
        )

    if (
        type(snapshot.artifacts) is not _MAPPING_PROXY_TYPE
        or len(snapshot.artifacts) != len(_ARTIFACT_ROLES)
        or tuple(sorted(snapshot.artifacts)) != tuple(sorted(_ARTIFACT_ROLES))
    ):
        raise FrozenSourceError(
            "snapshot artifacts must contain exactly one mesh identity"
        )
    identities: dict[str, FrozenArtifactIdentity] = {}
    for role in _ARTIFACT_ROLES:
        identity = snapshot.artifacts[role]
        if type(identity) is not FrozenArtifactIdentity or identity.role != role:
            raise FrozenSourceError("snapshot artifact identity is invalid")
        rebuilt = FrozenArtifactIdentity(
            identity.role,
            identity.declaration,
            identity.runtime_path,
            identity.size_bytes,
            identity.sha256,
        )
        if rebuilt != identity:
            raise FrozenSourceError(
                "snapshot artifact identity is stale or non-canonical"
            )
        if role == "mesh" and identity.size_bytes > limits.maximum_mesh_bytes:
            raise FrozenSourceError(
                "snapshot mesh artifact exceeds the resource limit"
            )
        identities[role] = rebuilt
    if str(snapshot.mesh.source_path) != identities["mesh"].runtime_path:
        raise FrozenSourceError(
            "snapshot mesh source_path differs from its artifact identity"
        )

    if (
        type(snapshot.components) is not _MAPPING_PROXY_TYPE
        or not snapshot.components
        or len(snapshot.components) > element_count
    ):
        raise FrozenSourceError("snapshot components must be a non-empty mapping")
    bindings: list[IdentifierBinding] = []
    component_element_memberships = 0
    component_node_memberships = 0
    for local_id, fingerprint in snapshot.components.items():
        _bounded_identity(local_id, field_name="local Component ID")
        if (
            type(fingerprint) is not FrozenComponentFingerprint
            or fingerprint.local_component_id != local_id
        ):
            raise FrozenSourceError("snapshot Component fingerprint is invalid")
        expected_global_id = frozen_component_global_id(snapshot.source_id, local_id)
        _bounded_identity(
            fingerprint.global_component_id,
            field_name="global Component ID",
            maximum_utf8_bytes=_MAX_FROZEN_GLOBAL_ID_UTF8_BYTES,
        )
        if fingerprint.global_component_id != expected_global_id:
            raise FrozenSourceError(
                "snapshot global Component ID is not compiler-canonical"
            )
        if (
            type(fingerprint.physical_group_tag) is not int
            or fingerprint.physical_group_tag < 1
            or type(fingerprint.element_count) is not int
            or fingerprint.element_count < 1
            or type(fingerprint.node_count) is not int
            or fingerprint.node_count < 1
            or type(fingerprint.element_tags) is not tuple
            or type(fingerprint.node_tags) is not tuple
            or len(fingerprint.element_tags) != fingerprint.element_count
            or len(fingerprint.node_tags) != fingerprint.node_count
            or any(type(tag) is not int or tag < 1 for tag in fingerprint.element_tags)
            or any(type(tag) is not int or tag < 1 for tag in fingerprint.node_tags)
            or not _strictly_increasing(fingerprint.element_tags)
            or not _strictly_increasing(fingerprint.node_tags)
            or type(fingerprint.element_kind_counts) is not _MAPPING_PROXY_TYPE
            or len(fingerprint.element_kind_counts) > len(ElementKind)
            or any(
                type(kind) is not str
                or kind not in _ELEMENT_KIND_NAMES
                or type(count) is not int
                or count < 1
                for kind, count in fingerprint.element_kind_counts.items()
            )
            or sum(fingerprint.element_kind_counts.values())
            != fingerprint.element_count
            or any(
                type(value) is not str
                or not _SHA256_PATTERN.fullmatch(value)
                for value in (
                    fingerprint.node_numbered_sha256,
                    fingerprint.element_numbered_sha256,
                    fingerprint.numbered_sha256,
                )
            )
        ):
            raise FrozenSourceError(
                "snapshot Component fingerprint fields are invalid"
            )
        component_element_memberships += len(fingerprint.element_tags)
        component_node_memberships += len(fingerprint.node_tags)
        if (
            component_element_memberships > element_count
            or component_node_memberships > 8 * element_count
        ):
            raise FrozenSourceError(
                "snapshot Component memberships exceed mesh resource bounds"
            )
        try:
            bindings.append(
                IdentifierBinding(local_id, fingerprint.global_component_id)
            )
        except (AssemblyPolicyError, TypeError, ValueError) as error:
            raise FrozenSourceError(
                "snapshot Component identity is invalid"
            ) from error

    if component_element_memberships != element_count:
        raise FrozenSourceError(
            "snapshot Component element memberships do not partition the mesh"
        )
    if (
        type(snapshot.element_kind_counts) is not _MAPPING_PROXY_TYPE
        or len(snapshot.element_kind_counts) > len(ElementKind)
        or any(
            type(kind) is not str
            or kind not in _ELEMENT_KIND_NAMES
            or type(count) is not int
            or count < 1
            for kind, count in snapshot.element_kind_counts.items()
        )
        or sum(snapshot.element_kind_counts.values()) != element_count
        or type(snapshot.numbered_sha256) is not str
        or not _SHA256_PATTERN.fullmatch(snapshot.numbered_sha256)
    ):
        raise FrozenSourceError("snapshot whole-source evidence is invalid")

    try:
        artifact_descriptor = FrozenArtifactDescriptor(
            identities["mesh"].declaration,
            Path(identities["mesh"].runtime_path),
            identities["mesh"].sha256,
        )
        policy_source = FrozenSource(
            snapshot.source_id,
            tuple(
                Component.frozen(binding.global_id, snapshot.source_id)
                for binding in bindings
            ),
        )
        compiled = CompiledFrozenSource(
            snapshot.source_id,
            artifact_descriptor,
            placement,
            tuple(bindings),
            policy_source,
        )
    except (AssemblyPolicyError, AttributeError, TypeError, ValueError) as error:
        raise FrozenSourceError(
            "snapshot source identity is invalid or non-canonical"
        ) from error

    replayed = load_compiled_frozen_source(compiled, limits=limits)
    if replayed != snapshot:
        raise FrozenSourceError(
            "snapshot differs from the artifact-bound canonical replay"
        )
    return replayed


__all__ = [
    "FrozenArtifactIdentity",
    "FrozenComponentFingerprint",
    "FrozenSourceError",
    "FrozenSourceLimits",
    "FrozenSourceSnapshot",
    "DEFAULT_MAX_FROZEN_ELEMENTS",
    "DEFAULT_MAX_FROZEN_ESTIMATED_MEMORY_BYTES",
    "DEFAULT_MAX_FROZEN_MESH_BYTES",
    "DEFAULT_MAX_FROZEN_NODES",
    "audit_frozen_source_snapshot",
    "load_compiled_frozen_source",
]
