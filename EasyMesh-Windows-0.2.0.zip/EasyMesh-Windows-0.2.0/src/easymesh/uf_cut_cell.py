"""Local mixed-element decomposition of Cartesian UF surface cut cells.

This module is intentionally independent of the package writer and global node
tags.  It samples the exact :class:`~easymesh.uf_skin.RectangularUfEnvelope`,
builds an inscribed convex polyhedron inside one axis-aligned ``CUT`` cell, and
connects every boundary facet to one interior point:

* an untouched Cartesian QUAD face becomes one PYRAMID5;
* every other boundary polygon is triangulated canonically and becomes TET4.

Sampling coordinates, analytic edge roots, point rounding, and polygon
diagonals are all functions of global coordinates.  This makes shared facets
deterministic for the supported straight/corner/toe cases, but it is still an
experimental surface-skin path: a package-scale batch must reject the whole
skin if any cut cell degenerates or any neighbouring facet audit disagrees.
The conservative production fallback is the closed staircase formed by
``FULL_HEX`` cells only, not a mixture of isolated skipped cut cells.

The MVP requires the Cartesian grid to split at the die side planes.  A cut
cell crossing the open die interior could contain a non-convex/disconnected UF
fragment and is rejected rather than silently tetrahedralised incorrectly.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import Enum
import itertools
import math
from typing import TypeAlias

from .uf_skin import (
    CartesianCell,
    CellIndex,
    Point3D,
    RectangularUfEnvelope,
    UfCellClass,
    UfCellClassification,
)


_COORDINATE_DIGITS = 12
_RELATIVE_TOLERANCE = 1.0e-10

CoordinateFacetKey: TypeAlias = tuple[Point3D, ...]


class UfCutCellError(ValueError):
    """Raised when one cut cell cannot be decomposed safely."""


class LocalElementKind(str, Enum):
    PYRAMID5 = "PYRAMID5"
    TET4 = "TET4"


class LocalFacetKind(str, Enum):
    QUAD4 = "QUAD4"
    TRI3 = "TRI3"


def _canonical_coordinate(value: float) -> float:
    rounded = round(float(value), _COORDINATE_DIGITS)
    return 0.0 if rounded == 0.0 else rounded


def canonical_point(point: Sequence[float]) -> Point3D:
    """Return the stable coordinate representation used on shared facets."""

    if len(point) != 3:
        raise UfCutCellError("a point must contain exactly three coordinates")
    result = tuple(_canonical_coordinate(value) for value in point)
    if any(not math.isfinite(value) for value in result):
        raise UfCutCellError("point coordinates must be finite")
    return result  # type: ignore[return-value]


def canonical_facet_key(points: Sequence[Point3D]) -> CoordinateFacetKey:
    """Orientation-independent coordinate key for crack auditing."""

    return tuple(sorted(canonical_point(point) for point in points))


def _add(first: Point3D, second: Point3D) -> Point3D:
    return (
        first[0] + second[0],
        first[1] + second[1],
        first[2] + second[2],
    )


def _subtract(first: Point3D, second: Point3D) -> Point3D:
    return (
        first[0] - second[0],
        first[1] - second[1],
        first[2] - second[2],
    )


def _scale(vector: Point3D, factor: float) -> Point3D:
    return (vector[0] * factor, vector[1] * factor, vector[2] * factor)


def _dot(first: Point3D, second: Point3D) -> float:
    return first[0] * second[0] + first[1] * second[1] + first[2] * second[2]


def _cross(first: Point3D, second: Point3D) -> Point3D:
    return (
        first[1] * second[2] - first[2] * second[1],
        first[2] * second[0] - first[0] * second[2],
        first[0] * second[1] - first[1] * second[0],
    )


def _norm(vector: Point3D) -> float:
    return math.sqrt(_dot(vector, vector))


def _unit(vector: Point3D) -> Point3D:
    length = _norm(vector)
    if length == 0.0:
        raise UfCutCellError("cannot normalize a zero vector")
    return _scale(vector, 1.0 / length)


def _cell_scale(cell: CartesianCell) -> float:
    values = (
        abs(cell.x_min),
        abs(cell.x_max),
        abs(cell.y_min),
        abs(cell.y_max),
        abs(cell.z_min),
        abs(cell.z_max),
        cell.x_max - cell.x_min,
        cell.y_max - cell.y_min,
        cell.z_max - cell.z_min,
    )
    return max(1.0, *values)


def _cell_tolerance(cell: CartesianCell) -> float:
    return _RELATIVE_TOLERANCE * _cell_scale(cell)


def _inside_with_tolerance(
    envelope: RectangularUfEnvelope,
    point: Point3D,
    tolerance: float,
) -> bool:
    x, y, z = point
    outside_die = (
        abs(x - envelope.center_x) >= envelope.half_die_width - tolerance
        or abs(y - envelope.center_y) >= envelope.half_die_length - tolerance
    )
    return (
        outside_die
        and envelope.outside_distance(x, y) <= envelope.fillet_width + tolerance
        and z >= envelope.base_z - tolerance
        and z <= envelope.top_height(x, y) + tolerance
    )


def _within(value: float, minimum: float, maximum: float, tolerance: float) -> bool:
    return minimum - tolerance <= value <= maximum + tolerance


def _sample_coordinates(minimum: float, maximum: float) -> tuple[float, float, float]:
    # Package Z schedules are assembled from several arithmetic paths, so a
    # nominal 0.4257 mm plane can arrive as 0.42569999999999997.  Canonicalise
    # before evaluating analytic roots; otherwise two algebraically identical
    # side/corner roots can differ by a few nanometres and create a spurious
    # near-collinear hull facet.
    return (
        _canonical_coordinate(minimum),
        _canonical_coordinate(0.5 * (minimum + maximum)),
        _canonical_coordinate(maximum),
    )


def _stable_pythagorean_component(radius: float, fixed: float) -> float:
    """Return ``sqrt(radius**2-fixed**2)`` with tangent roots snapped to zero."""

    radicand = (radius - fixed) * (radius + fixed)
    roundoff = 64.0 * math.ulp(max(1.0, radius * radius, fixed * fixed))
    if abs(radicand) <= roundoff:
        return 0.0
    if radicand < 0.0:
        raise UfCutCellError("surface-root radicand is negative")
    return math.sqrt(radicand)


def _cell_crosses_open_die(
    envelope: RectangularUfEnvelope,
    cell: CartesianCell,
) -> bool:
    left = envelope.center_x - envelope.half_die_width
    right = envelope.center_x + envelope.half_die_width
    bottom = envelope.center_y - envelope.half_die_length
    top = envelope.center_y + envelope.half_die_length
    overlaps_interior = (
        cell.x_min < right
        and cell.x_max > left
        and cell.y_min < top
        and cell.y_max > bottom
    )
    wholly_inside = (
        cell.x_min >= left
        and cell.x_max <= right
        and cell.y_min >= bottom
        and cell.y_max <= top
    )
    return overlaps_interior and not wholly_inside


def _collect_inscribed_points(
    envelope: RectangularUfEnvelope,
    cell: CartesianCell,
) -> tuple[Point3D, ...]:
    """Collect exact interior samples and surface roots on a 3x3x3 stencil."""

    tolerance = _cell_tolerance(cell)
    xs = _sample_coordinates(cell.x_min, cell.x_max)
    ys = _sample_coordinates(cell.y_min, cell.y_max)
    zs = _sample_coordinates(cell.z_min, cell.z_max)
    points: set[Point3D] = set()

    def add_candidate(x: float, y: float, z: float) -> None:
        if not (
            _within(x, cell.x_min, cell.x_max, tolerance)
            and _within(y, cell.y_min, cell.y_max, tolerance)
            and _within(z, cell.z_min, cell.z_max, tolerance)
        ):
            return
        point = canonical_point((x, y, z))
        if _inside_with_tolerance(envelope, point, 10.0 * tolerance):
            points.add(point)

    # All lattice points already within the closed UF solid.
    for x, y, z in itertools.product(xs, ys, zs):
        add_candidate(x, y, z)

    # Vertical stencil lines meet the exact base and exact free surface.
    for x, y in itertools.product(xs, ys):
        if not envelope.contains_xy(x, y):
            continue
        add_candidate(x, y, envelope.base_z)
        add_candidate(x, y, envelope.top_height(x, y))

    # At fixed y,z, solve d(x,y) == radius(z) analytically.  These roots
    # include the straight-side and both corner branches.
    slope = envelope.height / envelope.fillet_width
    for y, z in itertools.product(ys, zs):
        radius = (envelope.apex_z - z) / slope
        if radius < -tolerance or radius > envelope.fillet_width + tolerance:
            continue
        radius = min(max(radius, 0.0), envelope.fillet_width)
        dy = max(abs(y - envelope.center_y) - envelope.half_die_length, 0.0)
        if dy > radius + tolerance:
            continue
        dx = _stable_pythagorean_component(radius, dy)
        for sign in (-1.0, 1.0):
            x = envelope.center_x + sign * (envelope.half_die_width + dx)
            add_candidate(x, y, z)

    # Symmetric roots at fixed x,z.
    for x, z in itertools.product(xs, zs):
        radius = (envelope.apex_z - z) / slope
        if radius < -tolerance or radius > envelope.fillet_width + tolerance:
            continue
        radius = min(max(radius, 0.0), envelope.fillet_width)
        dx = max(abs(x - envelope.center_x) - envelope.half_die_width, 0.0)
        if dx > radius + tolerance:
            continue
        dy = _stable_pythagorean_component(radius, dx)
        for sign in (-1.0, 1.0):
            y = envelope.center_y + sign * (envelope.half_die_length + dy)
            add_candidate(x, y, z)

    return tuple(sorted(points))


def _signed_tetra_volume(
    first: Point3D,
    second: Point3D,
    third: Point3D,
    fourth: Point3D,
) -> float:
    return _dot(
        _cross(_subtract(second, first), _subtract(third, first)),
        _subtract(fourth, first),
    ) / 6.0


def _oriented_face(
    first: int,
    second: int,
    third: int,
    points: Sequence[Point3D],
    interior_reference: Point3D,
) -> tuple[int, int, int]:
    a, b, c = points[first], points[second], points[third]
    normal = _cross(_subtract(b, a), _subtract(c, a))
    if _dot(normal, _subtract(interior_reference, a)) > 0.0:
        return (first, third, second)
    return (first, second, third)


def _initial_tetrahedron(
    points: Sequence[Point3D],
    tolerance: float,
) -> tuple[int, int, int, int]:
    first = 0
    second = max(
        range(1, len(points)),
        key=lambda index: _dot(
            _subtract(points[index], points[first]),
            _subtract(points[index], points[first]),
        ),
    )
    line = _subtract(points[second], points[first])
    third = max(
        (index for index in range(len(points)) if index not in {first, second}),
        key=lambda index: _norm(
            _cross(line, _subtract(points[index], points[first]))
        ),
    )
    area = _norm(_cross(line, _subtract(points[third], points[first])))
    if area <= tolerance * tolerance:
        raise UfCutCellError("CUT cell samples are collinear")
    fourth = max(
        (
            index
            for index in range(len(points))
            if index not in {first, second, third}
        ),
        key=lambda index: abs(
            _signed_tetra_volume(
                points[first],
                points[second],
                points[third],
                points[index],
            )
        ),
    )
    volume = abs(
        _signed_tetra_volume(
            points[first], points[second], points[third], points[fourth]
        )
    )
    if volume <= tolerance * tolerance * tolerance:
        raise UfCutCellError("CUT cell samples have no positive volume")
    return (first, second, third, fourth)


def _triangular_hull_faces(
    points: Sequence[Point3D],
    tolerance: float,
) -> tuple[tuple[int, int, int], ...]:
    if len(points) < 4:
        raise UfCutCellError("CUT cell requires at least four sampled points")
    tetrahedron = _initial_tetrahedron(points, tolerance)
    interior = _scale(
        tuple(
            sum(points[index][axis] for index in tetrahedron)
            for axis in range(3)
        ),  # type: ignore[arg-type]
        0.25,
    )
    first, second, third, fourth = tetrahedron
    faces = [
        _oriented_face(first, second, third, points, interior),
        _oriented_face(first, fourth, second, points, interior),
        _oriented_face(second, fourth, third, points, interior),
        _oriented_face(third, fourth, first, points, interior),
    ]

    for point_index in range(len(points)):
        if point_index in tetrahedron:
            continue
        point = points[point_index]
        visible: list[tuple[int, int, int]] = []
        for face in faces:
            a, b, c = (points[index] for index in face)
            normal = _cross(_subtract(b, a), _subtract(c, a))
            if _dot(normal, _subtract(point, a)) > tolerance * _norm(normal):
                visible.append(face)
        if not visible:
            continue

        edge_counts: dict[tuple[int, int], int] = defaultdict(int)
        for face in visible:
            for edge in (
                (face[0], face[1]),
                (face[1], face[2]),
                (face[2], face[0]),
            ):
                edge_counts[tuple(sorted(edge))] += 1
        horizon = sorted(edge for edge, count in edge_counts.items() if count == 1)
        visible_set = set(visible)
        faces = [face for face in faces if face not in visible_set]
        faces.extend(
            _oriented_face(edge[0], edge[1], point_index, points, interior)
            for edge in horizon
        )

    unique = {tuple(face) for face in faces}
    return tuple(sorted(unique))


def _face_plane(
    face: tuple[int, int, int],
    points: Sequence[Point3D],
) -> tuple[Point3D, float]:
    a, b, c = (points[index] for index in face)
    normal = _unit(_cross(_subtract(b, a), _subtract(c, a)))
    return normal, _dot(normal, a)


def _strict_plane_tolerance(points: Sequence[Point3D]) -> float:
    """Tolerance for deciding true coplanarity after coordinate canonicalisation."""

    scale = max(1.0, *(abs(value) for point in points for value in point))
    coordinate_quantum = 10.0 ** (-_COORDINATE_DIGITS)
    return max(
        10.0 * coordinate_quantum,
        100.0 * math.ulp(scale),
    )


def _coplanar_face_groups(
    faces: Sequence[tuple[int, int, int]],
    points: Sequence[Point3D],
    tolerance: float,
) -> tuple[tuple[int, ...], ...]:
    edge_faces: dict[tuple[int, int], list[int]] = defaultdict(list)
    for face_index, face in enumerate(faces):
        for edge in (
            (face[0], face[1]),
            (face[1], face[2]),
            (face[2], face[0]),
        ):
            edge_faces[tuple(sorted(edge))].append(face_index)

    planes = tuple(_face_plane(face, points) for face in faces)
    plane_tolerance = _strict_plane_tolerance(points)
    neighbours: dict[int, set[int]] = defaultdict(set)
    for incident in edge_faces.values():
        if len(incident) != 2:
            continue
        first, second = incident
        first_normal, first_offset = planes[first]
        second_normal, second_offset = planes[second]
        if (
            _dot(first_normal, second_normal) >= 1.0 - 1.0e-12
            and abs(first_offset - second_offset) <= plane_tolerance
        ):
            neighbours[first].add(second)
            neighbours[second].add(first)

    remaining = set(range(len(faces)))
    groups: list[tuple[int, ...]] = []
    while remaining:
        seed = min(remaining)
        stack = [seed]
        group: set[int] = set()
        while stack:
            current = stack.pop()
            if current not in remaining:
                continue
            remaining.remove(current)
            group.add(current)
            stack.extend(sorted(neighbours[current], reverse=True))
        groups.append(tuple(sorted(group)))
    return tuple(groups)


def _plane_basis(normal: Point3D) -> tuple[Point3D, Point3D]:
    reference = (1.0, 0.0, 0.0) if abs(normal[0]) < 0.8 else (0.0, 1.0, 0.0)
    first = _unit(_cross(reference, normal))
    second = _cross(normal, first)
    return first, second


def _convex_polygon_on_plane(
    candidate_indices: Sequence[int],
    points: Sequence[Point3D],
    normal: Point3D,
    tolerance: float,
) -> tuple[int, ...]:
    first_axis, second_axis = _plane_basis(normal)
    projected = sorted(
        (
            _dot(points[index], first_axis),
            _dot(points[index], second_axis),
            index,
        )
        for index in set(candidate_indices)
    )
    if len(projected) < 3:
        raise UfCutCellError("a hull facet has fewer than three points")

    def cross_2d(
        origin: tuple[float, float, int],
        first: tuple[float, float, int],
        second: tuple[float, float, int],
    ) -> float:
        return (first[0] - origin[0]) * (second[1] - origin[1]) - (
            first[1] - origin[1]
        ) * (second[0] - origin[0])

    # ``cross_2d`` has dimensions of area.  Use a relative area tolerance based
    # on this facet's own span: a global length tolerance is dimensionally
    # wrong, while tolerance**2 alone is too small to remove analytically
    # collinear cone samples after their coordinates are rounded for sharing.
    first_span = projected[-1][0] - projected[0][0]
    second_values = tuple(point[1] for point in projected)
    second_span = max(second_values) - min(second_values)
    area_scale = max(first_span, second_span) ** 2
    area_tolerance = max(
        100.0 * tolerance * tolerance,
        _RELATIVE_TOLERANCE * area_scale,
    )
    lower: list[tuple[float, float, int]] = []
    for point in projected:
        while (
            len(lower) >= 2
            and cross_2d(lower[-2], lower[-1], point) <= area_tolerance
        ):
            lower.pop()
        lower.append(point)
    upper: list[tuple[float, float, int]] = []
    for point in reversed(projected):
        while (
            len(upper) >= 2
            and cross_2d(upper[-2], upper[-1], point) <= area_tolerance
        ):
            upper.pop()
        upper.append(point)
    polygon = tuple(point[2] for point in lower[:-1] + upper[:-1])
    if len(polygon) < 3:
        raise UfCutCellError("a hull facet collapsed during collinear cleanup")

    a, b, c = (points[index] for index in polygon[:3])
    polygon_normal = _cross(_subtract(b, a), _subtract(c, a))
    if _dot(polygon_normal, normal) < 0.0:
        polygon = tuple(reversed(polygon))
    return polygon


def _convex_hull_polygons(
    points: Sequence[Point3D],
    tolerance: float,
) -> tuple[tuple[int, ...], ...]:
    triangle_faces = _triangular_hull_faces(points, tolerance)
    groups = _coplanar_face_groups(triangle_faces, points, tolerance)
    polygons: list[tuple[int, ...]] = []
    for group in groups:
        normal, _offset = _face_plane(triangle_faces[group[0]], points)
        # Use only vertices owned by the grouped hull triangles.  Searching all
        # samples with a distance tolerance can pull a neighbouring curved
        # surface point onto this plane; the resulting almost-coplanar quad
        # creates a zero/negative fan tetrahedron at real mm scale.
        on_plane = sorted(
            {
                point_index
                for face_index in group
                for point_index in triangle_faces[face_index]
            }
        )
        polygons.append(
            _convex_polygon_on_plane(on_plane, points, normal, tolerance)
        )
    return tuple(
        sorted(
            polygons,
            key=lambda polygon: canonical_facet_key(
                tuple(points[index] for index in polygon)
            ),
        )
    )


def _cartesian_face_keys(cell: CartesianCell) -> dict[CoordinateFacetKey, str]:
    x0, x1 = cell.x_min, cell.x_max
    y0, y1 = cell.y_min, cell.y_max
    z0, z1 = cell.z_min, cell.z_max
    faces = {
        "x_min": ((x0, y0, z0), (x0, y1, z0), (x0, y1, z1), (x0, y0, z1)),
        "x_max": ((x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0)),
        "y_min": ((x0, y0, z0), (x0, y0, z1), (x1, y0, z1), (x1, y0, z0)),
        "y_max": ((x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)),
        "z_min": ((x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)),
        "z_max": ((x0, y0, z1), (x0, y1, z1), (x1, y1, z1), (x1, y0, z1)),
    }
    return {canonical_facet_key(points): name for name, points in faces.items()}


def _canonical_polygon_rotation(
    polygon: tuple[int, ...],
    points: Sequence[Point3D],
) -> tuple[int, ...]:
    anchor = min(range(len(polygon)), key=lambda index: points[polygon[index]])
    return polygon[anchor:] + polygon[:anchor]


def _triangulate_polygon(
    polygon: tuple[int, ...],
    points: Sequence[Point3D],
) -> tuple[tuple[int, int, int], ...]:
    rotated = _canonical_polygon_rotation(polygon, points)
    return tuple(
        (rotated[0], rotated[index], rotated[index + 1])
        for index in range(1, len(rotated) - 1)
    )


@dataclass(frozen=True, slots=True)
class LocalBoundaryFacet:
    """One outward-oriented boundary facet using mesh-local node indices."""

    kind: LocalFacetKind
    node_indices: tuple[int, ...]
    cartesian_face: str | None


@dataclass(frozen=True, slots=True)
class LocalCutElement:
    """TET4 or PYRAMID5 connectivity using zero-based local node indices."""

    kind: LocalElementKind
    node_indices: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class CutCellMesh:
    """Pure local decomposition of one analytic UF ``CUT`` cell."""

    cell: CartesianCell
    classification: UfCellClassification
    node_coordinates: tuple[Point3D, ...]
    boundary_facets: tuple[LocalBoundaryFacet, ...]
    elements: tuple[LocalCutElement, ...]
    sampled_point_count: int

    def facet_points(self, facet: LocalBoundaryFacet) -> tuple[Point3D, ...]:
        return tuple(self.node_coordinates[index] for index in facet.node_indices)

    def facet_key(self, facet: LocalBoundaryFacet) -> CoordinateFacetKey:
        return canonical_facet_key(self.facet_points(facet))

    def element_signed_volume(self, element: LocalCutElement) -> float:
        points = tuple(
            self.node_coordinates[index] for index in element.node_indices
        )
        if element.kind is LocalElementKind.TET4:
            return _signed_tetra_volume(*points)  # type: ignore[arg-type]
        if element.kind is LocalElementKind.PYRAMID5:
            return _signed_tetra_volume(
                points[0], points[1], points[2], points[4]
            ) + _signed_tetra_volume(
                points[0],
                points[2],
                points[3],
                points[4],
            )
        raise AssertionError(f"unsupported local element kind: {element.kind}")

    @property
    def minimum_signed_volume(self) -> float:
        return min(self.element_signed_volume(element) for element in self.elements)


def mesh_uf_cut_cell(
    envelope: RectangularUfEnvelope,
    cell: CartesianCell,
) -> CutCellMesh:
    """Create a deterministic PYRAMID5/TET4 decomposition of one CUT cell."""

    if not isinstance(envelope, RectangularUfEnvelope):
        raise TypeError("envelope must be a RectangularUfEnvelope")
    if not isinstance(cell, CartesianCell):
        raise TypeError("cell must be a CartesianCell")
    classification = envelope.classify_cell(cell)
    if classification.kind is not UfCellClass.CUT:
        raise UfCutCellError(
            f"surface decomposition requires a CUT cell, got {classification.kind.value}"
        )
    if _cell_crosses_open_die(envelope, cell):
        raise UfCutCellError(
            "CUT cell crosses the open die interior; split the Cartesian grid "
            "at the die side planes before surface decomposition"
        )

    tolerance = _cell_tolerance(cell)
    sampled_points = _collect_inscribed_points(envelope, cell)
    polygons = _convex_hull_polygons(sampled_points, tolerance)
    boundary_point_indices = sorted({index for polygon in polygons for index in polygon})
    boundary_points = tuple(sampled_points[index] for index in boundary_point_indices)
    centre = canonical_point(
        tuple(
            sum(point[axis] for point in boundary_points) / len(boundary_points)
            for axis in range(3)
        )
    )
    local_points = tuple(sorted(set(boundary_points))) + (centre,)
    local_index = {point: index for index, point in enumerate(local_points)}
    centre_index = len(local_points) - 1
    if local_index[centre] != centre_index:
        raise UfCutCellError("CUT cell interior point collapsed onto its boundary")

    cartesian_faces = _cartesian_face_keys(cell)
    facets: list[LocalBoundaryFacet] = []
    elements: list[LocalCutElement] = []
    for polygon in polygons:
        polygon_points = tuple(sampled_points[index] for index in polygon)
        polygon_local = tuple(local_index[point] for point in polygon_points)
        key = canonical_facet_key(polygon_points)
        cartesian_face = cartesian_faces.get(key)
        if cartesian_face is not None and len(polygon_local) == 4:
            facets.append(
                LocalBoundaryFacet(
                    kind=LocalFacetKind.QUAD4,
                    node_indices=polygon_local,
                    cartesian_face=cartesian_face,
                )
            )
            # Hull polygons point outwards; a positive pyramid uses an inward
            # base normal, hence the reversed base ordering.
            inward_base = (
                polygon_local[0],
                polygon_local[3],
                polygon_local[2],
                polygon_local[1],
            )
            elements.append(
                LocalCutElement(
                    LocalElementKind.PYRAMID5,
                    inward_base + (centre_index,),
                )
            )
            continue

        for triangle in _triangulate_polygon(polygon, sampled_points):
            triangle_points = tuple(sampled_points[index] for index in triangle)
            triangle_local = tuple(local_index[point] for point in triangle_points)
            facets.append(
                LocalBoundaryFacet(
                    kind=LocalFacetKind.TRI3,
                    node_indices=triangle_local,
                    cartesian_face=None,
                )
            )
            # Reverse the outward triangle so the fourth (interior) node gives
            # a strictly positive signed tetrahedron volume.
            elements.append(
                LocalCutElement(
                    LocalElementKind.TET4,
                    (
                        triangle_local[0],
                        triangle_local[2],
                        triangle_local[1],
                        centre_index,
                    ),
                )
            )

    ordered = sorted(
        zip(facets, elements),
        key=lambda pair: (
            pair[0].kind.value,
            canonical_facet_key(
                tuple(local_points[index] for index in pair[0].node_indices)
            ),
        ),
    )
    result = CutCellMesh(
        cell=cell,
        classification=classification,
        node_coordinates=local_points,
        boundary_facets=tuple(pair[0] for pair in ordered),
        elements=tuple(pair[1] for pair in ordered),
        sampled_point_count=len(sampled_points),
    )
    volume_tolerance = tolerance * tolerance * tolerance
    if not result.elements or result.minimum_signed_volume <= volume_tolerance:
        raise UfCutCellError("surface decomposition produced a non-positive element")
    return result


def mesh_uf_cut_cells(
    envelope: RectangularUfEnvelope,
    cells: Mapping[CellIndex, CartesianCell],
) -> dict[CellIndex, CutCellMesh]:
    """Mesh only ``CUT`` members of an indexed Cartesian collection.

    ``FULL_HEX`` and ``OUTSIDE`` cells are deliberately absent from the return
    value, making the "non-HEX only in the CUT band" contract explicit.
    """

    result: dict[CellIndex, CutCellMesh] = {}
    for index, cell in cells.items():
        if (
            not isinstance(index, tuple)
            or len(index) != 3
            or any(isinstance(value, bool) or not isinstance(value, int) for value in index)
        ):
            raise UfCutCellError("Cartesian cell indices must be integer triples")
        classification = envelope.classify_cell(cell)
        if classification.kind is UfCellClass.CUT:
            result[index] = mesh_uf_cut_cell(envelope, cell)
    _validate_cut_cell_batch_facets(result)
    return result


def _cell_axis_bounds(cell: CartesianCell, axis: int) -> tuple[float, float]:
    if axis == 0:
        return cell.x_min, cell.x_max
    if axis == 1:
        return cell.y_min, cell.y_max
    if axis == 2:
        return cell.z_min, cell.z_max
    raise AssertionError("Cartesian axis must be 0, 1, or 2")


def _facets_on_plane(
    mesh: CutCellMesh,
    *,
    axis: int,
    value: float,
) -> set[CoordinateFacetKey]:
    tolerance = _cell_tolerance(mesh.cell)
    return {
        mesh.facet_key(facet)
        for facet in mesh.boundary_facets
        if all(
            math.isclose(
                point[axis],
                value,
                rel_tol=0.0,
                abs_tol=tolerance,
            )
            for point in mesh.facet_points(facet)
        )
    }


def _validate_cut_cell_batch_facets(
    meshes: Mapping[CellIndex, CutCellMesh],
) -> None:
    """Fail closed when adjacent CUT cells expose different shared facets.

    The experimental local kernel is useful only if the complete batch is
    watertight.  Returning a partially valid mapping would make it too easy for
    a caller to publish a skin with cracks, so every positive-index CUT/CUT
    neighbour is checked before any result leaves :func:`mesh_uf_cut_cells`.
    """

    for index, first in meshes.items():
        for axis in range(3):
            neighbour_index = tuple(
                value + (1 if position == axis else 0)
                for position, value in enumerate(index)
            )
            second = meshes.get(neighbour_index)  # type: ignore[arg-type]
            if second is None:
                continue
            first_bounds = tuple(_cell_axis_bounds(first.cell, value) for value in range(3))
            second_bounds = tuple(_cell_axis_bounds(second.cell, value) for value in range(3))
            tolerance = max(_cell_tolerance(first.cell), _cell_tolerance(second.cell))
            aligned = math.isclose(
                first_bounds[axis][1],
                second_bounds[axis][0],
                rel_tol=0.0,
                abs_tol=tolerance,
            ) and all(
                math.isclose(
                    first_bounds[other][0],
                    second_bounds[other][0],
                    rel_tol=0.0,
                    abs_tol=tolerance,
                )
                and math.isclose(
                    first_bounds[other][1],
                    second_bounds[other][1],
                    rel_tol=0.0,
                    abs_tol=tolerance,
                )
                for other in range(3)
                if other != axis
            )
            if not aligned:
                raise UfCutCellError(
                    "indexed Cartesian CUT neighbours do not share one complete face: "
                    f"{index!r}, {neighbour_index!r}"
                )
            plane = first_bounds[axis][1]
            first_facets = _facets_on_plane(first, axis=axis, value=plane)
            second_facets = _facets_on_plane(second, axis=axis, value=plane)
            if first_facets != second_facets:
                raise UfCutCellError(
                    "adjacent CUT-cell facet audit failed; discard the complete "
                    f"experimental skin batch at {index!r}/{neighbour_index!r}"
                )


__all__ = [
    "CoordinateFacetKey",
    "CutCellMesh",
    "LocalBoundaryFacet",
    "LocalCutElement",
    "LocalElementKind",
    "LocalFacetKind",
    "UfCutCellError",
    "canonical_facet_key",
    "canonical_point",
    "mesh_uf_cut_cell",
    "mesh_uf_cut_cells",
]
