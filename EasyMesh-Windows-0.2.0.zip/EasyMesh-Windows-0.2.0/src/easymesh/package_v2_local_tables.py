"""Project table rows and scoped variable usage for local-template authoring."""
from __future__ import annotations
from copy import deepcopy
import io
import tokenize

from .package_v2_local_templates import bound_scope, resolve_scope, vector
from .package_v2_geometry_library import expression_names, map_expressions


def global_references(document):
    names = {v["name"] for key in ("parameters", "derived") for v in document["globals"][key]}
    references = {name: set() for name in names}
    def scan(value, owner):
        def expression(text):
            for name in expression_names(text) & names:
                references[name].add(owner)
            return text
        map_expressions(value, expression)
    for variable in document["globals"]["derived"]:
        scan(variable["expression"], f"Global {variable['name']}")
    for instance in document["instances"]:
        for key in ("bindings", "origin", "rotation", "mesh_control"):
            if key in instance:
                scan(instance[key], f"Instance {instance['id']} · {key}")
    return {name: tuple(sorted(values)) for name, values in references.items()}


def local_references(template, *, renames=None):
    """Collect direct uses inside this template, including incomplete GUI drafts.

    Instance assignments and other templates do not consume a local variable.
    Renames follow the dialog's pending identifier rewrites when it is saved.
    """
    references = {v["name"]: set() for key in ("parameters", "derived") for v in template[key]}
    renames = renames or {}

    def scan(value, owner):
        def expression(text):
            try:
                for token in tokenize.generate_tokens(io.StringIO(text).readline):
                    if token.type == tokenize.NAME:
                        name = renames.get(token.string, token.string)
                        if name in references:
                            references[name].add(owner)
            except (tokenize.TokenError, SyntaxError):
                # Keep identifiers already read while the user finishes typing.
                pass
            return text
        map_expressions(value, expression)

    for variable in template["derived"]:
        scan(variable["expression"], f"内部变量 {variable['name']}")
    for solid in template["solids"]:
        scan(solid, f"基本图形 {solid['id']}")
    for child in template["instances"]:
        for name, value in child["bindings"].items():
            scan(value, f"子实例 {child['id']} · 参数 {name}")
        for key, label in (("origin", "位置"), ("rotation", "旋转")):
            for axis, value in zip("XYZ", child.get(key, ())):
                scan(value, f"子实例 {child['id']} · {label} {axis}")
    return {name: tuple(sorted(owners)) for name, owners in references.items()}


def build_tables(document, compiled):
    from .package_v2_source_editor import (
        SourceTableSet, VariableRow, GeometryRow, GeometryFragmentRow, MeshRow,
        SourceCellKind as Kind, ResolvedValue, _BuiltTables, _cell, _register,
        _frozen_rows, _mesh_settings_row, _resolved_mesh_rows,
    )
    bindings, variables, geometries, meshes = {}, [], [], []
    global_scope = resolve_scope(document["globals"])
    values = {v.name: v for v in global_scope.values}
    references = global_references(document)
    names = set(values)
    def cell(tokens, value, label, *, resolved=(), kind=Kind.EXPRESSION, unit=None):
        deps = tuple(sorted(expression_names(value) & names)) if isinstance(value, str) and kind is Kind.EXPRESSION else ()
        result = _cell(tokens=tokens, label=label, value=value, editable=True, kind=kind,
                       resolved=resolved, dependencies=deps)
        _register(bindings, result, tokens, length_unit=unit)
        return result
    for key, role, field in (("parameters", "parameter", "default"), ("derived", "derived", "expression")):
        for index, variable in enumerate(document["globals"][key]):
            name, dimension = variable["name"], variable["kind"]
            unit = variable.get("unit", "mm" if dimension == "length" else "1")
            resolved = (ResolvedValue("Global", values[name].value, values[name].canonical_unit, role),)
            value = cell(("globals", key, index, field), variable[field], name, resolved=resolved,
                         unit=unit if dimension == "length" else None)
            name_cell = cell(("globals", key, index, "name"), name, "变量名称", kind=Kind.VARIABLE_NAME)
            unit_cell = None
            if role == "parameter" and dimension == "length":
                tokens = ("globals", key, index, "unit")
                unit_cell = _cell(tokens=tokens, label="Unit", value=unit, editable=True, kind=Kind.UNIT)
                _register(bindings, unit_cell, tokens, parameter_key=("Global", name))
            variables.append(VariableRow(value.pointer, value.display, True, resolved, value.dependencies,
                                         "Global", name, role, dimension, unit, value, unit=unit_cell,
                                         references=references[name], name_cell=name_cell))
    templates = {t["id"]: t for t in document["templates"]}
    resolved_mesh = _resolved_mesh_rows(compiled)
    component_roots, component_materials = {}, {}
    for index, instance in enumerate(document["instances"]):
        identifier = instance["id"]
        component_id = instance.get("component_id", identifier)
        root = ("instances", index)
        scope = bound_scope(templates[instance["template"]], instance["bindings"], global_scope)
        local_values = {v.name: v for v in scope.values}
        leaves = []
        for parameter in templates[instance["template"]]["parameters"]:
            name = parameter["name"]
            value = local_values[name]
            leaves.append(cell((*root, "bindings", name), instance["bindings"][name], name,
                resolved=(ResolvedValue(identifier, value.value, value.canonical_unit),),
                unit=parameter["unit"] if parameter["kind"] == "length" else None))
        origin = vector(instance["origin"], global_scope)
        for axis in range(3):
            leaves.append(cell((*root, "origin", axis), instance["origin"][axis], f"Origin {'XYZ'[axis]}",
                resolved=(ResolvedValue(identifier, origin[axis], "mm"),), unit="mm"))
        owner_root = component_roots.setdefault(component_id, root)
        if component_id not in component_materials:
            component_materials[component_id] = cell((*owner_root, "material"), instance["material"], "material", kind=Kind.MATERIAL)
        material = component_materials[component_id]
        geometries.append(GeometryRow(f"/instances/{index}", identifier, True,
            (ResolvedValue(component_id, identifier, ""),), (), instance["template"], component_id, material,
            (GeometryFragmentRow(f"/instances/{index}", identifier, "instance", tuple(leaves)),)))
        if owner_root != root:
            continue
        control = instance["mesh_control"]
        control_root = (*root, "mesh_control")
        resolved = resolved_mesh[(component_id, component_id)]
        priority = cell((*control_root, "mesh_priority"), control["mesh_priority"], "mesh_priority", kind=Kind.INTEGER)
        target = cell((*control_root, "target_edge"), control["target_edge"], "target_edge", unit="mm")
        transition = cell((*control_root, "transition_distance"), control["transition_distance"], "transition_distance", unit="mm")
        strategy = control["strategy"]
        directional = tuple(cell((*control_root, "strategy", "directional_near_edge", name), value, name, unit="mm")
                            for name, value in strategy.get("directional_near_edge", {}).items())
        partition = tuple(cell((*control_root, "strategy", "partition_origin", axis), value, f"partition_origin[{axis}]", unit="mm")
                          for axis, value in enumerate(strategy.get("partition_origin", [])))
        dependencies = set()
        def collect_dependency(text):
            dependencies.update(expression_names(text) & names)
            return text
        map_expressions(control, collect_dependency)
        meshes.append(MeshRow(f"/instances/{index}/mesh_control", identifier, True, resolved, tuple(sorted(dependencies)), "Global", component_id,
            priority, target, transition, strategy["kind"], strategy.get("direction"), directional, partition, deepcopy(strategy)))
    return _BuiltTables(SourceTableSet(tuple(variables), tuple(geometries), tuple(meshes),
        _frozen_rows(document, compiled, read_only=False, bindings=bindings),
        _mesh_settings_row(document, compiled, read_only=False)), bindings)
