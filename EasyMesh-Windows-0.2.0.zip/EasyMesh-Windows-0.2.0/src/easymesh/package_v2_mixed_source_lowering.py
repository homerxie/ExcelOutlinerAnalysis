"""Role-free lowering of one compiled mixed Package V2 Source.

This module is the neutral bridge between the pure Package V2 compiler and
mixed generated/Frozen execution.  It deliberately has no package-profile,
material-role, stack-position, or geometry-role vocabulary.  Every generated
Component contributes exactly the canonical geometry and explicit mesh control
that it owns.  Generated interfaces are discovered from real common geometry;
Frozen matches are copied by their compiled global endpoint identities.

The lowering does not execute a volume mesher and does not infer a topology
from an InterfaceMatch.  Frozen matches have one meaning only: preserve the
actual shared trace while leaving all Frozen volume connectivity untouched.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType

from .component_interface import (
    CommonFaceCapability,
    ComponentInterfaceError,
    ComponentMeshRequirement,
    NegotiatedComponentInterface,
    negotiate_component_interface,
)
from .generated_interface_continuity import (
    GeneratedInterfaceContinuityError,
    GeneratedInterfaceContinuityPlan,
    plan_generated_interface_continuity,
    resolve_package_frame_sweep_directions,
)
from .package_assembly import (
    GeneratedComponentMeshControl,
    InterfaceCoupling,
    InterfaceMatch,
    InterfaceMatchMode,
)
from .package_v2_compile import PackageV2CompileResult
from .package_v2_component_adjacency import (
    ComponentAdjacencyError,
    extract_component_adjacencies,
)
from .package_v2_frozen import FrozenSourceSnapshot
from .package_v2_geometry import (
    CanonicalComponentGeometry,
    CanonicalGeneratedGeometry,
    CanonicalGeometryFragment,
)
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)


MIXED_SOURCE_LOWERING_SCHEMA = (
    "easymesh-package-v2-role-free-mixed-source-lowering-v2"
)


class MixedSourceLoweringError(ValueError):
    """Raised when compiled identity or explicit mesh policy is incomplete."""


def _nonempty(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value:
        raise MixedSourceLoweringError(f"{field_name} must be a non-empty string")
    return value


@dataclass(frozen=True, order=True, slots=True)
class GeneratedLocalComponentKey:
    """Collision-safe key for a Component's source-local identifier."""

    instance_id: str
    local_component_id: str

    def __post_init__(self) -> None:
        _nonempty(self.instance_id, field_name="generated instance ID")
        _nonempty(
            self.local_component_id,
            field_name="generated local Component ID",
        )


@dataclass(frozen=True, order=True, slots=True)
class GeneratedLocalFragmentKey:
    """Collision-safe key for a fragment's source-local identifier."""

    instance_id: str
    local_fragment_id: str

    def __post_init__(self) -> None:
        _nonempty(self.instance_id, field_name="generated instance ID")
        _nonempty(
            self.local_fragment_id,
            field_name="generated local fragment ID",
        )


@dataclass(frozen=True, order=True, slots=True)
class FrozenGeneratedInterfaceKey:
    """Directional global-identity key for one explicit Frozen match."""

    frozen_component_global_id: str
    generated_component_global_id: str

    def __post_init__(self) -> None:
        _nonempty(
            self.frozen_component_global_id,
            field_name="Frozen global Component ID",
        )
        _nonempty(
            self.generated_component_global_id,
            field_name="generated global Component ID",
        )


@dataclass(frozen=True, slots=True)
class LoweredFrozenInterfaceMatch:
    """One lossless ID binding around the compiler-owned InterfaceMatch."""

    key: FrozenGeneratedInterfaceKey
    frozen_source_id: str
    frozen_component_local_id: str
    generated_instance_id: str
    generated_component_local_id: str
    policy: InterfaceMatch = field(repr=False)

    def __post_init__(self) -> None:
        if type(self.key) is not FrozenGeneratedInterfaceKey:
            raise MixedSourceLoweringError("Frozen match key is invalid")
        _nonempty(self.frozen_source_id, field_name="Frozen source ID")
        _nonempty(
            self.frozen_component_local_id,
            field_name="Frozen local Component ID",
        )
        _nonempty(self.generated_instance_id, field_name="generated instance ID")
        _nonempty(
            self.generated_component_local_id,
            field_name="generated local Component ID",
        )
        if type(self.policy) is not InterfaceMatch:
            raise MixedSourceLoweringError("Frozen match policy is invalid")
        if (
            self.policy.frozen_component.identifier
            != self.key.frozen_component_global_id
            or self.policy.generated_component.identifier
            != self.key.generated_component_global_id
        ):
            raise MixedSourceLoweringError(
                "Frozen match endpoints do not match their global-ID key"
            )

    @property
    def mode(self) -> InterfaceMatchMode:
        return self.policy.mode

    @property
    def coupling(self) -> InterfaceCoupling:
        return self.policy.coupling


@dataclass(frozen=True, slots=True)
class MixedSourceLowering:
    """Immutable, auditable neutral lowering for mixed Source execution."""

    compiled_plan_sha256: str
    frozen_source_id: str
    frozen_snapshot_numbered_sha256: str
    canonical_geometries_by_instance_id: Mapping[str, CanonicalGeneratedGeometry]
    canonical_components_by_local_key: Mapping[
        GeneratedLocalComponentKey,
        CanonicalComponentGeometry,
    ]
    canonical_components_by_global_id: Mapping[str, CanonicalComponentGeometry]
    component_global_id_by_local_key: Mapping[GeneratedLocalComponentKey, str]
    canonical_fragments_by_local_key: Mapping[
        GeneratedLocalFragmentKey,
        CanonicalGeometryFragment,
    ]
    canonical_fragments_by_global_id: Mapping[str, CanonicalGeometryFragment]
    fragment_global_id_by_local_key: Mapping[GeneratedLocalFragmentKey, str]
    component_mesh_controls_by_global_id: Mapping[
        str,
        GeneratedComponentMeshControl,
    ]
    component_mesh_requirements: Mapping[str, ComponentMeshRequirement]
    generated_adjacencies: tuple[CommonFaceCapability, ...]
    generated_interface_policies: tuple[NegotiatedComponentInterface, ...]
    generated_interface_continuity_plan: GeneratedInterfaceContinuityPlan
    frozen_interface_matches: Mapping[
        FrozenGeneratedInterfaceKey,
        LoweredFrozenInterfaceMatch,
    ]
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    )
    schema: str = field(default=MIXED_SOURCE_LOWERING_SCHEMA, init=False)

    def __post_init__(self) -> None:
        for field_name in (
            "canonical_geometries_by_instance_id",
            "canonical_components_by_local_key",
            "canonical_components_by_global_id",
            "component_global_id_by_local_key",
            "canonical_fragments_by_local_key",
            "canonical_fragments_by_global_id",
            "fragment_global_id_by_local_key",
            "component_mesh_controls_by_global_id",
            "component_mesh_requirements",
            "frozen_interface_matches",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, Mapping):
                raise MixedSourceLoweringError(f"{field_name} must be a mapping")
            object.__setattr__(self, field_name, MappingProxyType(dict(value)))
        object.__setattr__(
            self,
            "generated_adjacencies",
            tuple(self.generated_adjacencies),
        )
        object.__setattr__(
            self,
            "generated_interface_policies",
            tuple(self.generated_interface_policies),
        )
        try:
            tolerance = validate_interface_geometry_tolerance_mm(
                self.interface_geometry_tolerance_mm
            )
        except ValueError as error:
            raise MixedSourceLoweringError(str(error)) from error
        object.__setattr__(self, "interface_geometry_tolerance_mm", tolerance)


@dataclass(frozen=True, slots=True)
class _GeneratedIdentity:
    instance_id: str
    local_component_id: str
    global_component_id: str


def _lower_generated_components(
    compiled: PackageV2CompileResult,
) -> tuple[
    dict[str, CanonicalGeneratedGeometry],
    dict[GeneratedLocalComponentKey, CanonicalComponentGeometry],
    dict[str, CanonicalComponentGeometry],
    dict[GeneratedLocalComponentKey, str],
    dict[GeneratedLocalFragmentKey, CanonicalGeometryFragment],
    dict[str, CanonicalGeometryFragment],
    dict[GeneratedLocalFragmentKey, str],
    dict[str, GeneratedComponentMeshControl],
    dict[str, ComponentMeshRequirement],
    dict[str, _GeneratedIdentity],
]:
    geometries: dict[str, CanonicalGeneratedGeometry] = {}
    local_components: dict[
        GeneratedLocalComponentKey,
        CanonicalComponentGeometry,
    ] = {}
    global_components: dict[str, CanonicalComponentGeometry] = {}
    global_component_id_by_local: dict[GeneratedLocalComponentKey, str] = {}
    local_fragments: dict[
        GeneratedLocalFragmentKey,
        CanonicalGeometryFragment,
    ] = {}
    global_fragments: dict[str, CanonicalGeometryFragment] = {}
    global_fragment_id_by_local: dict[GeneratedLocalFragmentKey, str] = {}
    controls: dict[str, GeneratedComponentMeshControl] = {}
    requirements: dict[str, ComponentMeshRequirement] = {}
    identity_by_global: dict[str, _GeneratedIdentity] = {}

    for instance in compiled.generated_instances:
        geometry = instance.geometry_result.geometry
        if geometry.instance_id != instance.instance_id:
            raise MixedSourceLoweringError(
                "compiled generated geometry has a stale instance ID"
            )
        if instance.instance_id in geometries:
            raise MixedSourceLoweringError("generated instance IDs are not unique")
        geometries[instance.instance_id] = geometry
        descriptor_by_local = {
            descriptor.local_component_id: descriptor
            for descriptor in instance.components
        }
        component_by_local = {
            component.component_id: component for component in geometry.components
        }
        if set(descriptor_by_local) != set(component_by_local):
            raise MixedSourceLoweringError(
                "compiled Component descriptors do not match canonical geometry IDs"
            )

        for local_component_id in sorted(component_by_local):
            descriptor = descriptor_by_local[local_component_id]
            component = component_by_local[local_component_id]
            local_key = GeneratedLocalComponentKey(
                instance.instance_id,
                local_component_id,
            )
            global_component_id = descriptor.global_component_id
            if (
                local_key in local_components
                or global_component_id in global_components
                or global_component_id in identity_by_global
            ):
                raise MixedSourceLoweringError(
                    "generated Component identities are not unique"
                )

            control = descriptor.mesh_control
            if type(control) is not GeneratedComponentMeshControl:
                raise MixedSourceLoweringError(
                    f"generated Component {global_component_id!r} lacks explicit "
                    "mesh_control"
                )
            descriptor_fragments = {
                binding.local_id: binding for binding in descriptor.fragments
            }
            component_fragments = {
                fragment.fragment_id: fragment for fragment in component.fragments
            }
            if set(descriptor_fragments) != set(component_fragments):
                raise MixedSourceLoweringError(
                    f"generated Component {global_component_id!r} fragment IDs "
                    "do not match canonical geometry"
                )
            global_component_fragments: list[CanonicalGeometryFragment] = []
            for local_fragment_id in sorted(component_fragments):
                binding = descriptor_fragments[local_fragment_id]
                local_fragment = component_fragments[local_fragment_id]
                fragment_key = GeneratedLocalFragmentKey(
                    instance.instance_id,
                    local_fragment_id,
                )
                global_fragment_id = binding.global_id
                if (
                    fragment_key in local_fragments
                    or global_fragment_id in global_fragments
                ):
                    raise MixedSourceLoweringError(
                        "generated fragment identities are not unique"
                    )
                global_fragment = CanonicalGeometryFragment(
                    global_fragment_id,
                    local_fragment.root,
                    local_fragment.placement,
                )
                local_fragments[fragment_key] = local_fragment
                global_fragments[global_fragment_id] = global_fragment
                global_fragment_id_by_local[fragment_key] = global_fragment_id
                global_component_fragments.append(global_fragment)

            global_component = CanonicalComponentGeometry(
                global_component_id,
                component.material_name,
                tuple(global_component_fragments),
            )
            requirement = ComponentMeshRequirement(
                global_component_id,
                control.volume_topology.value,
                control.target_edge_mm,
                control.transition_distance_mm,
            )
            local_components[local_key] = component
            global_components[global_component_id] = global_component
            global_component_id_by_local[local_key] = global_component_id
            controls[global_component_id] = control
            requirements[global_component_id] = requirement
            identity_by_global[global_component_id] = _GeneratedIdentity(
                instance.instance_id,
                local_component_id,
                global_component_id,
            )

    return (
        geometries,
        local_components,
        global_components,
        global_component_id_by_local,
        local_fragments,
        global_fragments,
        global_fragment_id_by_local,
        controls,
        requirements,
        identity_by_global,
    )


def _lower_generated_interfaces(
    components: Mapping[str, CanonicalComponentGeometry],
    requirements: Mapping[str, ComponentMeshRequirement],
    mesh_controls: Mapping[str, GeneratedComponentMeshControl],
    interface_geometry_tolerance_mm: float,
) -> tuple[
    tuple[CommonFaceCapability, ...],
    tuple[NegotiatedComponentInterface, ...],
    GeneratedInterfaceContinuityPlan,
]:
    try:
        adjacencies = extract_component_adjacencies(
            tuple(components[component_id] for component_id in sorted(components)),
            interface_namespace="generated/source",
            interface_geometry_tolerance_mm=(
                interface_geometry_tolerance_mm
            ),
        )
        policies = tuple(
            sorted(
                (
                    negotiate_component_interface(
                        adjacency,
                        requirements[adjacency.first_component_id],
                        requirements[adjacency.second_component_id],
                    )
                    for adjacency in adjacencies
                ),
                key=lambda value: value.interface_id,
            )
        )
        sweep_directions = resolve_package_frame_sweep_directions(
            components,
            mesh_controls,
        )
        continuity = plan_generated_interface_continuity(
            policies,
            requirements,
            interface_geometry_tolerance_mm=(
                interface_geometry_tolerance_mm
            ),
            sweep_direction_xyz_by_component=sweep_directions,
        )
    except (
        ComponentAdjacencyError,
        ComponentInterfaceError,
        GeneratedInterfaceContinuityError,
    ) as error:
        raise MixedSourceLoweringError(
            "generated interface lowering failed from canonical geometry and "
            f"Component mesh requirements: {error}"
        ) from error
    return adjacencies, policies, continuity


def _lower_frozen_matches(
    compiled: PackageV2CompileResult,
    snapshot: FrozenSourceSnapshot,
    generated_identity_by_global_id: Mapping[str, _GeneratedIdentity],
) -> dict[FrozenGeneratedInterfaceKey, LoweredFrozenInterfaceMatch]:
    compiled_source = compiled.frozen_source_by_id.get(snapshot.source_id)
    if compiled_source is None:
        raise MixedSourceLoweringError(
            "Frozen snapshot source ID is absent from the compiled Source"
        )
    if snapshot.placement != compiled_source.placement:
        raise MixedSourceLoweringError(
            "Frozen snapshot placement differs from the compiled Source"
        )
    binding_by_local = {
        binding.local_id: binding for binding in compiled_source.components
    }
    if set(snapshot.components) != set(binding_by_local):
        raise MixedSourceLoweringError(
            "Frozen snapshot Component IDs differ from the compiled Source"
        )
    frozen_local_by_global: dict[str, str] = {}
    for local_id, binding in binding_by_local.items():
        fingerprint = snapshot.components[local_id]
        if (
            fingerprint.local_component_id != local_id
            or fingerprint.global_component_id != binding.global_id
        ):
            raise MixedSourceLoweringError(
                "Frozen snapshot Component identity differs from the compiled Source"
            )
        frozen_local_by_global[binding.global_id] = local_id

    output: dict[
        FrozenGeneratedInterfaceKey,
        LoweredFrozenInterfaceMatch,
    ] = {}
    for match in compiled.assembly_policy.interface_matches:
        frozen_global_id = match.frozen_component.identifier
        generated_global_id = match.generated_component.identifier
        frozen_local_id = frozen_local_by_global.get(frozen_global_id)
        if frozen_local_id is None:
            raise MixedSourceLoweringError(
                "an InterfaceMatch Frozen endpoint is not represented by the "
                "provided snapshot"
            )
        generated_identity = generated_identity_by_global_id.get(
            generated_global_id
        )
        if generated_identity is None:
            raise MixedSourceLoweringError(
                "an InterfaceMatch target is absent from canonical generated geometry"
            )
        key = FrozenGeneratedInterfaceKey(
            frozen_global_id,
            generated_global_id,
        )
        if key in output:
            raise MixedSourceLoweringError(
                "an InterfaceMatch global endpoint pair is duplicated"
            )
        output[key] = LoweredFrozenInterfaceMatch(
            key,
            snapshot.source_id,
            frozen_local_id,
            generated_identity.instance_id,
            generated_identity.local_component_id,
            match,
        )
    return output


def lower_mixed_source(
    compiled: PackageV2CompileResult,
    snapshot: FrozenSourceSnapshot,
) -> MixedSourceLowering:
    """Lower generic compiled evidence without interpreting package semantics."""

    if type(compiled) is not PackageV2CompileResult:
        raise MixedSourceLoweringError("compiled must be a PackageV2CompileResult")
    if type(snapshot) is not FrozenSourceSnapshot:
        raise MixedSourceLoweringError("snapshot must be a FrozenSourceSnapshot")

    (
        geometries,
        local_components,
        global_components,
        global_component_id_by_local,
        local_fragments,
        global_fragments,
        global_fragment_id_by_local,
        controls,
        requirements,
        generated_identity_by_global,
    ) = _lower_generated_components(compiled)
    adjacencies, policies, continuity = (
        _lower_generated_interfaces(
            global_components,
            requirements,
            controls,
            compiled.interface_geometry_tolerance_mm,
        )
    )
    frozen_matches = _lower_frozen_matches(
        compiled,
        snapshot,
        generated_identity_by_global,
    )
    return MixedSourceLowering(
        compiled.plan_digest,
        snapshot.source_id,
        snapshot.numbered_sha256,
        geometries,
        local_components,
        global_components,
        global_component_id_by_local,
        local_fragments,
        global_fragments,
        global_fragment_id_by_local,
        controls,
        requirements,
        adjacencies,
        policies,
        continuity,
        frozen_matches,
        interface_geometry_tolerance_mm=(
            compiled.interface_geometry_tolerance_mm
        ),
    )


__all__ = [
    "FrozenGeneratedInterfaceKey",
    "GeneratedLocalComponentKey",
    "GeneratedLocalFragmentKey",
    "LoweredFrozenInterfaceMatch",
    "MIXED_SOURCE_LOWERING_SCHEMA",
    "MixedSourceLowering",
    "MixedSourceLoweringError",
    "lower_mixed_source",
]
