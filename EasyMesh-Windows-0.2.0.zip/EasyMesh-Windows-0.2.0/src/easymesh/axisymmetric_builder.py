"""Build a material-aware axisymmetric volume mesh from a ``SectionPlan``.

The planar topology covers the complete xy disk.  Sweeping the centre-crossing
section by 180 degrees is geometrically equivalent to assigning every planar
radial region its section material and extruding it through the configured,
possibly non-uniform, z levels.  Only material-filled cells and the nodes they
reference are emitted; voids never become Gmsh entities or elements.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
from typing import Any, TYPE_CHECKING
import unicodedata

from .gmsh_builder import _load_gmsh, _mesh_is_reflection_symmetric, _percentile
from .gmsh_runtime import preview_mesh_file
from .output_artifacts import (
    atomic_output_path,
    atomic_write_text,
    exclusive_output_lock,
    file_artifact,
    normalized_mesh_output,
)
from .parameters import MAX_DEMO_ESTIMATED_ELEMENTS, MeshParameters, UM_TO_MM
from .quality import classify_mesh_quality
from .section import SectionPlan
from .topology import (
    Face2D,
    TopologyPlan,
    build_topology_with_radial_targets,
)

if TYPE_CHECKING:
    from .axisymmetric import AxisymmetricMeshParameters


_POSITION_DECIMALS = 10
_ALL_SOLIDS_PHYSICAL_NAME = "ALL_SOLID_VOLUMES"
_RESERVED_MATERIAL_PHYSICAL_PREFIXES = (
    "COMPONENT_",
    "TEMPLATE_",
    "TRANSITION_",
    "HM_",
    "BUMP_",
    "MATERIAL_",
    "REGION_",
)


def _canonical_position(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be finite")
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be finite") from error
    if not math.isfinite(parsed):
        raise ValueError(f"{field_name} must be finite")
    rounded = round(parsed, _POSITION_DECIMALS)
    return 0.0 if rounded == 0.0 else rounded


def _positive_size(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be a positive finite number")
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field_name} must be a positive finite number") from error
    if not math.isfinite(parsed) or parsed <= 0.0:
        raise ValueError(f"{field_name} must be a positive finite number")
    return parsed


@dataclass(frozen=True, slots=True)
class _ResolvedParameters:
    source: object
    section_plan: SectionPlan
    z_levels_um: tuple[float, ...]
    target_xy_um: float
    effective_radial_sizes_um: tuple[float, ...]
    model_name: str
    planar_parameters: MeshParameters


def _resolve_parameters(parameters: object) -> _ResolvedParameters:
    section_plan = getattr(parameters, "section_plan", None)
    if not isinstance(section_plan, SectionPlan):
        raise TypeError("parameters.section_plan must be a SectionPlan")
    radial_breakpoints = tuple(
        _canonical_position(value, field_name="radial breakpoint")
        for value in section_plan.radius_breakpoints_um
    )
    radial_region_count = max(0, len(radial_breakpoints) - 1)
    if radial_region_count == 0 or section_plan.max_height_um <= 0.0:
        raise ValueError("section_plan must describe a non-empty volume")

    try:
        raw_levels = tuple(getattr(parameters, "z_levels_um"))
    except (AttributeError, TypeError) as error:
        raise TypeError("parameters.z_levels_um must be an iterable") from error
    z_levels = tuple(
        _canonical_position(value, field_name="z level") for value in raw_levels
    )
    if len(z_levels) < 2:
        raise ValueError("z_levels_um must contain at least two levels")
    if any(end <= start for start, end in zip(z_levels, z_levels[1:])):
        raise ValueError("z_levels_um must be strictly increasing")

    physical_z = {
        _canonical_position(value, field_name="section z breakpoint")
        for value in section_plan.z_breakpoints_um
    }
    missing_z = tuple(sorted(physical_z.difference(z_levels)))
    if missing_z:
        raise ValueError(
            "z_levels_um must preserve every section material boundary: "
            + ", ".join(f"{value:g}" for value in missing_z)
        )
    highest_z = _canonical_position(
        section_plan.max_height_um, field_name="section height"
    )
    if z_levels[0] != 0.0 or z_levels[-1] != highest_z:
        raise ValueError(
            "z_levels_um must start at 0 and end at the section maximum height"
        )

    target_xy = _positive_size(
        getattr(parameters, "target_xy_um", None), field_name="target_xy_um"
    )
    raw_radial_sizes = getattr(
        parameters,
        "effective_radial_sizes_um",
        getattr(parameters, "effective_radial_sizes", None),
    )
    if raw_radial_sizes is None:
        radial_sizes = (target_xy,) * radial_region_count
    else:
        try:
            radial_sizes = tuple(
                _positive_size(value, field_name="radial target size")
                for value in raw_radial_sizes
            )
        except TypeError as error:
            raise TypeError(
                "effective_radial_sizes must be an inner-to-outer iterable"
            ) from error
    if len(radial_sizes) != radial_region_count:
        raise ValueError(
            "effective_radial_sizes must contain one value per radial interval"
        )

    model_name = getattr(parameters, "model_name", "axisymmetric_layer_model")
    if not isinstance(model_name, str) or not model_name.strip():
        raise ValueError("model_name must not be empty")
    model_name = model_name.strip()

    planar_source = getattr(parameters, "to_planar_parameters", None)
    planar_parameters = planar_source() if callable(planar_source) else None
    if not isinstance(planar_parameters, MeshParameters):
        planar_parameters = MeshParameters(
            diameters_um=section_plan.diameters_um,
            thickness_um=section_plan.max_height_um,
            target_xy_um=target_xy,
            target_z_um=section_plan.max_height_um,
            model_name=model_name,
        )
    if planar_parameters.diameters_um != section_plan.diameters_um:
        raise ValueError("planar parameters must use the section radial boundaries")
    if planar_parameters.target_xy_um != getattr(parameters, "planar_reference_target_um", target_xy):
        raise ValueError("planar parameters must use the mesh-size reference")

    return _ResolvedParameters(
        source=parameters,
        section_plan=section_plan,
        z_levels_um=z_levels,
        target_xy_um=target_xy,
        effective_radial_sizes_um=radial_sizes,
        model_name=model_name,
        planar_parameters=planar_parameters,
    )


@dataclass(frozen=True, slots=True)
class PlannedVolumeElement:
    """One material-filled HEX8 or WEDGE6 in the discrete volume plan."""

    component: str
    material: str
    radial_region: int
    z_slab: int
    face_index: int
    node_tags: tuple[int, ...]

    def __post_init__(self) -> None:
        if not self.component:
            raise ValueError("element component must not be empty")
        if not self.material:
            raise ValueError("element material must not be empty")
        if len(self.node_tags) not in (6, 8):
            raise ValueError("a planned element must be WEDGE6 or HEX8")
        if len(set(self.node_tags)) != len(self.node_tags):
            raise ValueError("an element must not repeat a node")
        if any(tag <= 0 for tag in self.node_tags):
            raise ValueError("node tags must be positive")

    @property
    def kind(self) -> str:
        return "WEDGE6" if len(self.node_tags) == 6 else "HEX8"

    @property
    def gmsh_element_type(self) -> int:
        # Gmsh first-order element type IDs: Hexahedron 8=5, Prism 6=6.
        return 6 if len(self.node_tags) == 6 else 5


@dataclass(frozen=True, slots=True)
class AxisymmetricElementPlan:
    """Pure-Python node and material-element plan, before Gmsh is initialized."""

    topology: TopologyPlan
    z_levels_um: tuple[float, ...]
    node_tags: tuple[int, ...]
    coordinates_mm: tuple[tuple[float, float, float], ...]
    elements: tuple[PlannedVolumeElement, ...]
    component_physical_names: tuple[tuple[str, str], ...]
    material_physical_names: tuple[tuple[str, str], ...]
    symmetry_ok: bool

    @property
    def node_count(self) -> int:
        return len(self.node_tags)

    @property
    def element_count(self) -> int:
        return len(self.elements)

    @property
    def hex_count(self) -> int:
        return sum(element.kind == "HEX8" for element in self.elements)

    @property
    def wedge_count(self) -> int:
        return sum(element.kind == "WEDGE6" for element in self.elements)

    @property
    def material_element_counts(self) -> dict[str, int]:
        return dict(Counter(element.material for element in self.elements))

    @property
    def component_element_counts(self) -> dict[str, int]:
        return dict(Counter(element.component for element in self.elements))

    @property
    def physical_name_by_component(self) -> dict[str, str]:
        return dict(self.component_physical_names)

    @property
    def physical_name_by_material(self) -> dict[str, str]:
        return dict(self.material_physical_names)


def _material_token(material: str) -> str:
    ascii_name = (
        unicodedata.normalize("NFKD", material)
        .encode("ascii", "ignore")
        .decode("ascii")
        .upper()
    )
    token = re.sub(r"[^A-Z0-9]+", "_", ascii_name).strip("_")
    if not token:
        token = "X" + hashlib.sha1(material.encode("utf-8")).hexdigest()[:8].upper()
    return token


def _physical_name_map(
    values: tuple[str, ...],
    *,
    prefix: str,
) -> dict[str, str]:
    """Return collision-safe, deterministic names under one group prefix."""

    result: dict[str, str] = {}
    used: set[str] = set()
    for value in values:
        if value in result:
            continue
        base = f"{prefix}_{_material_token(value)}"
        candidate = base
        if candidate in used:
            suffix = hashlib.sha1(value.encode("utf-8")).hexdigest()[:8].upper()
            candidate = f"{base}_{suffix}"
            counter = 2
            while candidate in used:
                candidate = f"{base}_{suffix}_{counter}"
                counter += 1
        result[value] = candidate
        used.add(candidate)
    return result


def material_physical_name_map(materials: tuple[str, ...]) -> dict[str, str]:
    """Map each Layer material to its unchanged Gmsh Physical Group name.

    Gmsh writes Physical Names inside double quotes without escaping embedded
    quotes or line-control characters.  Reject those values before generation
    instead of silently publishing a name that changes when the MSH is opened
    again.  EasyMesh's component, layout, transition, HyperMesh, legacy
    material/region, and aggregate namespaces remain reserved so a raw Layer
    material cannot be mistaken for another classification family.
    """

    result: dict[str, str] = {}
    for material in materials:
        if (
            not isinstance(material, str)
            or not material
            or material != material.strip()
        ):
            raise ValueError(
                "Layer material Physical Group names must be non-empty and trimmed"
            )
        if '"' in material or not material.isprintable():
            raise ValueError(
                "Layer material Physical Group names must contain only printable "
                "characters and no double quote"
            )
        normalized = material.upper()
        if (
            normalized == _ALL_SOLIDS_PHYSICAL_NAME
            or normalized.startswith(_RESERVED_MATERIAL_PHYSICAL_PREFIXES)
        ):
            raise ValueError(
                f"Layer material name {material!r} conflicts with a reserved "
                "Physical Group name"
            )
        result.setdefault(material, material)
    return result


def component_physical_name_map(components: tuple[str, ...]) -> dict[str, str]:
    """Return collision-safe, deterministic ``COMPONENT_<token>`` names."""

    return _physical_name_map(components, prefix="COMPONENT")


def _signed_twice_area(
    coordinates_mm: tuple[tuple[float, float], ...], face: Face2D
) -> float:
    points = tuple(coordinates_mm[node] for node in face.node_ids)
    return sum(
        points[index][0] * points[(index + 1) % len(points)][1]
        - points[(index + 1) % len(points)][0] * points[index][1]
        for index in range(len(points))
    )


def _identity_at(
    section_plan: SectionPlan,
    radius_um: float,
    z_um: float,
) -> tuple[str, str] | None:
    column = section_plan.column_at_radius(radius_um)
    for span in column.spans:
        if span.z_bottom_um <= z_um < span.z_top_um:
            return (span.component, span.material)
    return None


def _build_topology(parameters: _ResolvedParameters) -> TopologyPlan:
    topology = build_topology_with_radial_targets(
        parameters.planar_parameters,
        parameters.effective_radial_sizes_um,
        getattr(parameters.source, "effective_radial_policies", None),
        angular_target_sizes_um=getattr(parameters.source, "effective_angular_sizes_um", None),
    )
    if tuple(topology.radial_target_sizes_um) != parameters.effective_radial_sizes_um:
        raise RuntimeError("topology did not retain the requested radial target sizes")
    return topology


def _plan_elements(
    parameters: _ResolvedParameters,
    topology: TopologyPlan,
) -> AxisymmetricElementPlan:
    if not isinstance(topology, TopologyPlan):
        raise TypeError("topology must be a TopologyPlan")
    if not topology.symmetry_ok:
        raise RuntimeError("the planar topology is not reflection symmetric")

    section_plan = parameters.section_plan
    radial_breakpoints = tuple(
        _canonical_position(value, field_name="radial breakpoint")
        for value in section_plan.radius_breakpoints_um
    )
    region_count = len(radial_breakpoints) - 1
    if tuple(topology.radial_target_sizes_um) != parameters.effective_radial_sizes_um:
        raise ValueError("topology radial targets do not match the configuration")
    if (
        topology.sector_count != parameters.planar_parameters.sector_count
        or topology.symmetry_axes_deg
        != parameters.planar_parameters.symmetry_axes_deg
    ):
        raise ValueError("topology symmetry mode does not match the configuration")
    topology_radii = tuple(ring.radius_um for ring in topology.rings)
    radius_tolerance = 1.0e-8
    missing_physical_radii = tuple(
        radius
        for radius in radial_breakpoints[1:]
        if not any(
            math.isclose(radius, candidate, rel_tol=0.0, abs_tol=radius_tolerance)
            for candidate in topology_radii
        )
    )
    if missing_physical_radii or not math.isclose(
        topology_radii[-1],
        radial_breakpoints[-1],
        rel_tol=0.0,
        abs_tol=radius_tolerance,
    ):
        raise ValueError(
            "topology must preserve every section physical radius and outer boundary"
        )
    if any(face.region < 0 or face.region >= region_count for face in topology.faces):
        raise ValueError("a topology face has no matching section radial interval")

    for face in topology.faces:
        if len(face.node_ids) not in (3, 4):
            raise ValueError("the planar topology must contain only triangles and quads")
        if len(set(face.node_ids)) != len(face.node_ids):
            raise ValueError("a planar face repeats a node")
        if any(node < 0 or node >= len(topology.coordinates_mm) for node in face.node_ids):
            raise ValueError("a planar face references an unknown node")
        if _signed_twice_area(topology.coordinates_mm, face) <= 0.0:
            raise ValueError("a planar face is not positively oriented")
        region_inner = radial_breakpoints[face.region]
        region_outer = radial_breakpoints[face.region + 1]
        for node in face.node_ids:
            x_mm, y_mm = topology.coordinates_mm[node]
            radius_um = math.hypot(x_mm, y_mm) / UM_TO_MM
            if not (
                region_inner - radius_tolerance
                <= radius_um
                <= region_outer + radius_tolerance
            ):
                raise ValueError(
                    "a topology face crosses its section radial interval"
                )

    projected_cell_upper_bound = len(topology.faces) * (
        len(parameters.z_levels_um) - 1
    )
    if projected_cell_upper_bound > MAX_DEMO_ESTIMATED_ELEMENTS:
        raise ValueError(
            "axisymmetric element upper bound exceeds the demo safety limit "
            f"{MAX_DEMO_ESTIMATED_ELEMENTS:,}; increase an R, Z, or global XY size"
        )

    raw_elements: list[
        tuple[str, str, int, int, int, tuple[tuple[int, int], ...]]
    ] = []
    used_logical_nodes: set[tuple[int, int]] = set()
    signatures: set[tuple[int, tuple[tuple[int, int], ...]]] = set()
    for z_slab, (z_start, z_end) in enumerate(
        zip(parameters.z_levels_um, parameters.z_levels_um[1:])
    ):
        z_midpoint = 0.5 * (z_start + z_end)
        for face_index, face in enumerate(topology.faces):
            radial_start = radial_breakpoints[face.region]
            radial_end = radial_breakpoints[face.region + 1]
            radius_midpoint = 0.5 * (radial_start + radial_end)
            identity = _identity_at(section_plan, radius_midpoint, z_midpoint)
            if identity is None:
                continue
            component, material = identity
            bottom = tuple((z_slab, node) for node in face.node_ids)
            top = tuple((z_slab + 1, node) for node in face.node_ids)
            logical_connectivity = bottom + top
            signature = (len(logical_connectivity), tuple(sorted(logical_connectivity)))
            if signature in signatures:
                raise RuntimeError("the volume plan contains a duplicate element")
            signatures.add(signature)
            used_logical_nodes.update(logical_connectivity)
            raw_elements.append(
                (
                    component,
                    material,
                    face.region,
                    z_slab,
                    face_index,
                    logical_connectivity,
                )
            )

    if not raw_elements:
        raise ValueError("the section and z levels do not contain any solid cells")
    if len(raw_elements) > MAX_DEMO_ESTIMATED_ELEMENTS:
        raise ValueError(
            "axisymmetric element count exceeds the demo safety limit "
            f"{MAX_DEMO_ESTIMATED_ELEMENTS:,}"
        )

    ordered_logical_nodes = tuple(sorted(used_logical_nodes))
    node_tag_by_key = {
        key: index for index, key in enumerate(ordered_logical_nodes, start=1)
    }
    coordinates = tuple(
        (
            topology.coordinates_mm[node_2d][0],
            topology.coordinates_mm[node_2d][1],
            parameters.z_levels_um[z_index] * UM_TO_MM,
        )
        for z_index, node_2d in ordered_logical_nodes
    )
    coordinate_keys = {
        tuple(round(value, 14) for value in coordinate) for coordinate in coordinates
    }
    if len(coordinate_keys) != len(coordinates):
        raise RuntimeError("the volume plan contains duplicate nodes")

    elements = tuple(
        PlannedVolumeElement(
            component=component,
            material=material,
            radial_region=region,
            z_slab=z_slab,
            face_index=face_index,
            node_tags=tuple(node_tag_by_key[key] for key in logical_connectivity),
        )
        for component, material, region, z_slab, face_index, logical_connectivity in raw_elements
    )
    referenced_tags = {tag for element in elements for tag in element.node_tags}
    node_tags = tuple(range(1, len(coordinates) + 1))
    if referenced_tags != set(node_tags):
        raise RuntimeError("the volume plan contains orphan or missing nodes")

    active_materials = set(element.material for element in elements)
    active_components = set(element.component for element in elements)
    component_order = tuple(
        component
        for component in section_plan.components
        if component in active_components
    )
    material_order = tuple(
        material for material in section_plan.materials if material in active_materials
    )
    component_physical_names = component_physical_name_map(component_order)
    physical_names = material_physical_name_map(material_order)
    return AxisymmetricElementPlan(
        topology=topology,
        z_levels_um=parameters.z_levels_um,
        node_tags=node_tags,
        coordinates_mm=coordinates,
        elements=elements,
        component_physical_names=tuple(component_physical_names.items()),
        material_physical_names=tuple(physical_names.items()),
        symmetry_ok=topology.symmetry_ok,
    )


def plan_axisymmetric_elements(
    parameters: "AxisymmetricMeshParameters | object",
    topology: TopologyPlan | None = None,
) -> AxisymmetricElementPlan:
    """Create the material-aware node/element plan without importing Gmsh."""

    resolved = _resolve_parameters(parameters)
    return _plan_elements(resolved, topology or _build_topology(resolved))


@dataclass(frozen=True, slots=True)
class AxisymmetricBuildSummary:
    mesh_path: str
    report_path: str
    parameters_path: str
    node_count: int
    element_count: int
    hex_count: int
    wedge_count: int
    volume_count: int
    two_dimensional_element_count: int
    element_types: tuple[str, ...]
    physical_volume_groups: dict[str, int]
    component_volume_groups: dict[str, int]
    material_element_counts: dict[str, int]
    component_element_counts: dict[str, int]
    min_scaled_jacobian: float
    p01_scaled_jacobian: float
    median_scaled_jacobian: float
    min_sicn: float
    min_sige: float
    min_jacobian_determinant: float
    duplicate_node_count: int
    symmetry_ok: bool
    topology_symmetry_ok: bool
    symmetry_axes_deg: tuple[int, ...]
    quality_warnings: tuple[str, ...]
    quality_advisories: tuple[str, ...]
    quality_classification: str
    z_levels_um: tuple[float, ...]
    radial_target_sizes_um: tuple[float, ...]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["element_types"] = list(self.element_types)
        data["symmetry_axes_deg"] = list(self.symmetry_axes_deg)
        data["quality_warnings"] = list(self.quality_warnings)
        data["quality_advisories"] = list(self.quality_advisories)
        data["z_levels_um"] = list(self.z_levels_um)
        data["radial_target_sizes_um"] = list(self.radial_target_sizes_um)
        return data


def _add_discrete_mesh(
    gmsh: Any,
    plan: AxisymmetricElementPlan,
) -> tuple[dict[str, int], dict[str, int]]:
    material_names = tuple(material for material, _name in plan.material_physical_names)
    component_names = tuple(
        component for component, _name in plan.component_physical_names
    )
    if not material_names or not component_names:
        raise RuntimeError("the element plan has no components or materials")
    entity_keys = tuple(
        dict.fromkeys((element.component, element.material) for element in plan.elements)
    )
    entities = {
        key: gmsh.model.addDiscreteEntity(3, index)
        for index, key in enumerate(entity_keys, start=1)
    }
    # Classify each node exactly once, as required by Gmsh.  Nodes incident to
    # only one component/material pair belong to that entity.  At a shared
    # interface there is no lower-dimensional discrete entity (the output is
    # intentionally volume-elements-only), so choose the first incident pair
    # in Layer order deterministically.  Elements in the other volume continue
    # to reference that shared conformal node.
    incident_entities: dict[int, set[tuple[str, str]]] = {
        tag: set() for tag in plan.node_tags
    }
    for element in plan.elements:
        for tag in element.node_tags:
            incident_entities[tag].add((element.component, element.material))
    entity_rank = {key: index for index, key in enumerate(entity_keys)}
    owner_by_tag = {
        tag: min(keys, key=entity_rank.__getitem__)
        for tag, keys in incident_entities.items()
    }
    coordinate_by_tag = dict(zip(plan.node_tags, plan.coordinates_mm))
    for key in entity_keys:
        owned_tags = [tag for tag in plan.node_tags if owner_by_tag[tag] == key]
        if not owned_tags:
            continue
        owned_coordinates = [
            value for tag in owned_tags for value in coordinate_by_tag[tag]
        ]
        gmsh.model.mesh.addNodes(
            3,
            entities[key],
            owned_tags,
            owned_coordinates,
        )

    grouped: dict[tuple[tuple[str, str], int], list[tuple[int, ...]]] = {}
    for element in plan.elements:
        key = (element.component, element.material)
        grouped.setdefault((key, element.gmsh_element_type), []).append(element.node_tags)
    next_tag = 1
    for key in entity_keys:
        for element_type in (5, 6):
            connectivity = grouped.get((key, element_type), ())
            if not connectivity:
                continue
            tags = list(range(next_tag, next_tag + len(connectivity)))
            gmsh.model.mesh.addElementsByType(
                entities[key],
                element_type,
                tags,
                [node for element in connectivity for node in element],
            )
            next_tag += len(connectivity)

    palette = (
        (226, 93, 93),
        (244, 162, 97),
        (233, 196, 106),
        (42, 157, 143),
        (69, 123, 157),
        (106, 76, 147),
    )
    material_group_counts: dict[str, int] = {}
    material_counts = plan.material_element_counts
    material_physical_names = plan.physical_name_by_material
    for material in material_names:
        physical_name = material_physical_names[material]
        physical_tag = gmsh.model.addPhysicalGroup(
            3,
            [entities[key] for key in entity_keys if key[1] == material],
        )
        gmsh.model.setPhysicalName(3, physical_tag, physical_name)
        material_group_counts[physical_name] = material_counts[material]

    component_group_counts: dict[str, int] = {}
    component_counts = plan.component_element_counts
    component_physical_names = plan.physical_name_by_component
    for index, component in enumerate(component_names):
        component_entities = [
            entities[key] for key in entity_keys if key[0] == component
        ]
        physical_name = component_physical_names[component]
        physical_tag = gmsh.model.addPhysicalGroup(3, component_entities)
        gmsh.model.setPhysicalName(3, physical_tag, physical_name)
        component_group_counts[physical_name] = component_counts[component]
        gmsh.model.setColor(
            [(3, entity) for entity in component_entities],
            *palette[index % len(palette)],
            255,
        )
    all_tag = gmsh.model.addPhysicalGroup(3, list(entities.values()))
    gmsh.model.setPhysicalName(3, all_tag, _ALL_SOLIDS_PHYSICAL_NAME)
    return material_group_counts, component_group_counts


def _summarize_mesh(
    gmsh: Any,
    parameters: _ResolvedParameters,
    plan: AxisymmetricElementPlan,
    mesh_path: Path,
    report_path: Path,
    parameter_path: Path,
    physical_volume_groups: dict[str, int],
    component_volume_groups: dict[str, int],
) -> AxisymmetricBuildSummary:
    surface_entities = tuple(gmsh.model.getEntities(2))
    _, surface_tags, _ = gmsh.model.mesh.getElements(2)
    two_dimensional_count = sum(len(tags) for tags in surface_tags)
    if surface_entities or two_dimensional_count:
        raise RuntimeError("axisymmetric mesh must not contain independent 2D entities")

    element_types, element_tags, _ = gmsh.model.mesh.getElements(3)
    allowed = {"Hexahedron 8", "Prism 6"}
    type_names: list[str] = []
    type_counts: Counter[str] = Counter()
    all_element_tags: list[int] = []
    for element_type, tags in zip(element_types, element_tags):
        name, dimension, order, _, _, _ = gmsh.model.mesh.getElementProperties(
            int(element_type)
        )
        name = str(name)
        if dimension != 3 or order != 1 or name not in allowed:
            raise RuntimeError(f"unsupported axisymmetric volume element: {name}")
        type_names.append(name)
        type_counts[name] += len(tags)
        all_element_tags.extend(int(tag) for tag in tags)
    if len(all_element_tags) != plan.element_count:
        raise RuntimeError("Gmsh element count differs from the material plan")

    scaled_jacobians = sorted(
        float(value)
        for value in gmsh.model.mesh.getElementQualities(all_element_tags, "minSJ")
    )
    sicn = [
        float(value)
        for value in gmsh.model.mesh.getElementQualities(all_element_tags, "minSICN")
    ]
    sige = [
        float(value)
        for value in gmsh.model.mesh.getElementQualities(all_element_tags, "minSIGE")
    ]
    determinants = [
        float(value)
        for value in gmsh.model.mesh.getElementQualities(all_element_tags, "minDetJac")
    ]
    min_scaled_jacobian = min(scaled_jacobians)
    min_sicn = min(sicn)
    min_sige = min(sige)
    quality = classify_mesh_quality(min_scaled_jacobian, min_sicn, min_sige)
    if min(determinants) <= 0.0 or not quality.is_valid:
        raise RuntimeError(
            "axisymmetric mesh contains an invalid element: "
            f"minDetJac={min(determinants):.6g}, "
            f"minSJ={min_scaled_jacobian:.6g}, "
            f"minSICN={min_sicn:.6g}, minSIGE={min_sige:.6g}"
        )

    duplicate_nodes = tuple(gmsh.model.mesh.getDuplicateNodes())
    if duplicate_nodes:
        raise RuntimeError(
            f"axisymmetric mesh contains {len(duplicate_nodes)} duplicate nodes"
        )
    node_tags, coordinates, _ = gmsh.model.mesh.getNodes()
    if len(node_tags) != plan.node_count:
        raise RuntimeError("Gmsh node count differs from the material-only plan")
    axes = plan.topology.symmetry_axes_deg
    coordinate_symmetry = _mesh_is_reflection_symmetric(coordinates, axes)
    if not coordinate_symmetry or not plan.symmetry_ok:
        raise RuntimeError("axisymmetric mesh failed reflection-symmetry validation")

    material_counts = plan.material_element_counts
    physical_names = plan.physical_name_by_material
    expected_physical_counts = {
        physical_names[material]: count for material, count in material_counts.items()
    }
    if physical_volume_groups != expected_physical_counts:
        raise RuntimeError("material physical-group counts differ from the element plan")
    component_counts = plan.component_element_counts
    component_physical_names = plan.physical_name_by_component
    expected_component_counts = {
        component_physical_names[component]: count
        for component, count in component_counts.items()
    }
    if component_volume_groups != expected_component_counts:
        raise RuntimeError("component physical-group counts differ from the element plan")

    return AxisymmetricBuildSummary(
        mesh_path=str(mesh_path),
        report_path=str(report_path),
        parameters_path=str(parameter_path),
        node_count=len(node_tags),
        element_count=len(all_element_tags),
        hex_count=type_counts["Hexahedron 8"],
        wedge_count=type_counts["Prism 6"],
        volume_count=len(gmsh.model.getEntities(3)),
        two_dimensional_element_count=two_dimensional_count,
        element_types=tuple(type_names),
        physical_volume_groups=physical_volume_groups,
        component_volume_groups=component_volume_groups,
        material_element_counts=material_counts,
        component_element_counts=component_counts,
        min_scaled_jacobian=min_scaled_jacobian,
        p01_scaled_jacobian=_percentile(scaled_jacobians, 0.01),
        median_scaled_jacobian=statistics.median(scaled_jacobians),
        min_sicn=min_sicn,
        min_sige=min_sige,
        min_jacobian_determinant=min(determinants),
        duplicate_node_count=0,
        symmetry_ok=coordinate_symmetry,
        topology_symmetry_ok=plan.topology.symmetry_ok,
        symmetry_axes_deg=axes,
        quality_warnings=quality.quality_warnings,
        quality_advisories=quality.quality_advisories,
        quality_classification=quality.classification,
        z_levels_um=parameters.z_levels_um,
        radial_target_sizes_um=parameters.effective_radial_sizes_um,
    )


def build_axisymmetric_mesh(
    parameters: "AxisymmetricMeshParameters | object",
    mesh_path: str | Path,
    *,
    preview: bool = False,
    verbose: bool = False,
    topology: TopologyPlan | None = None,
    job_id: str | None = None,
) -> AxisymmetricBuildSummary:
    """Generate one layer mesh while locking its complete artifact bundle."""

    output = normalized_mesh_output(mesh_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with exclusive_output_lock(output):
        summary = _build_axisymmetric_mesh_locked(
            parameters,
            output,
            verbose=verbose,
            topology=topology,
            job_id=job_id,
        )
    if preview:
        preview_mesh_file(output, verbose=verbose)
    return summary


def _build_axisymmetric_mesh_locked(
    parameters: "AxisymmetricMeshParameters | object",
    mesh_path: str | Path,
    *,
    verbose: bool = False,
    topology: TopologyPlan | None = None,
    job_id: str | None = None,
) -> AxisymmetricBuildSummary:
    """Generate, verify, and write the layer-driven HEX8/WEDGE6 mesh."""

    resolved = _resolve_parameters(parameters)
    element_plan = _plan_elements(resolved, topology or _build_topology(resolved))
    output = normalized_mesh_output(mesh_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    report_path = output.with_suffix(".report.json")
    parameter_path = output.with_suffix(".parameters.json")

    gmsh = _load_gmsh()
    initialized = False
    try:
        gmsh.initialize()
        initialized = True
        gmsh.option.setNumber("General.Terminal", 1 if verbose else 0)
        gmsh.option.setNumber("Mesh.MshFileVersion", 4.1)
        gmsh.option.setNumber("Mesh.Binary", 0)
        gmsh.option.setNumber("Mesh.ElementOrder", 1)
        gmsh.option.setNumber("Mesh.SaveAll", 1)
        gmsh.model.add(resolved.model_name)

        material_groups, component_groups = _add_discrete_mesh(gmsh, element_plan)
        gmsh.model.mesh.renumberNodes()
        gmsh.model.mesh.renumberElements()
        summary = _summarize_mesh(
            gmsh,
            resolved,
            element_plan,
            output,
            report_path,
            parameter_path,
            material_groups,
            component_groups,
        )
        with atomic_output_path(output) as temporary_mesh:
            gmsh.write(str(temporary_mesh))
            mesh_artifact = file_artifact(
                temporary_mesh,
                published_path=output,
            )
            parameter_payload = (
                parameters.to_dict()
                if callable(getattr(parameters, "to_dict", None))
                else {}
            )
            atomic_write_text(
                parameter_path,
                json.dumps(parameter_payload, indent=2, ensure_ascii=False),
            )
            report_payload: dict[str, object] = {
                "parameters": parameter_payload,
                "quality": summary.to_dict(),
                "mesh_artifact": mesh_artifact,
            }
            if job_id is not None:
                report_payload["job_id"] = job_id
            atomic_write_text(
                report_path,
                json.dumps(report_payload, indent=2, ensure_ascii=False),
            )
            # Publish the MSH last.  It is the bundle commit marker: if either
            # sidecar write fails, ``atomic_output_path`` discards this prepared
            # mesh and leaves the previously committed mesh in place.  This
            # ordering is significant when two terminal-air-gap variants have
            # identical MSH bytes but different lossless sidecar geometry.

        return summary
    finally:
        if initialized:
            gmsh.finalize()


__all__ = [
    "AxisymmetricBuildSummary",
    "AxisymmetricElementPlan",
    "PlannedVolumeElement",
    "build_axisymmetric_mesh",
    "component_physical_name_map",
    "material_physical_name_map",
    "plan_axisymmetric_elements",
]
