from __future__ import annotations

import hashlib
import math
from bisect import bisect_left, bisect_right
from collections.abc import Iterable, Mapping
from typing import Any

from PySide6.QtCore import QEvent, QPoint, QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import (
    QColor,
    QMouseEvent,
    QPainter,
    QPalette,
    QPaintEvent,
    QPen,
    QResizeEvent,
    QWheelEvent,
)
from PySide6.QtWidgets import QApplication, QFrame, QLabel, QSizePolicy, QWidget

from .mesh_controls import ControlAxis, MeshControlInterval
from .preview_style import component_pen, mesh_pen


def _value(item: object, name: str, default: Any = None) -> Any:
    """Read a section-model field from either a dataclass/object or a mapping."""

    if isinstance(item, Mapping):
        return item.get(name, default)
    return getattr(item, name, default)


def _first_value(item: object, names: tuple[str, ...], default: Any = None) -> Any:
    for name in names:
        value = _value(item, name, None)
        if value is not None:
            return value
    return default


def _items(value: object | None) -> tuple[object, ...]:
    if value is None or isinstance(value, (str, bytes)):
        return ()
    try:
        return tuple(value)  # type: ignore[arg-type]
    except TypeError:
        return ()


class SectionPreview(QWidget):
    """Paint the complete diameter section represented by a ``SectionPlan``.

    ``SectionPlan`` stores only non-negative radial columns. Mirroring each
    column about the centre axis produces the full [-R, R] section; sweeping
    that full section by 180 degrees produces the intended axisymmetric solid.
    Material fills and true layer interfaces are painted separately so radial
    planning breakpoints are not mistaken for geometry or mesh lines.
    """

    z_interval_activated = Signal(object, float)

    _KNOWN_COLORS = {
        "al": QColor("#aeb8c4"),
        "aluminum": QColor("#aeb8c4"),
        "aluminium": QColor("#aeb8c4"),
        "cu": QColor("#d77b3f"),
        "copper": QColor("#d77b3f"),
        "pi": QColor("#e4aa3a"),
        "psv2": QColor("#8e78c9"),
    }
    _MIN_ZOOM = 1.0
    _MAX_ZOOM = 16.0
    _ZOOM_STEP = 1.2

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._plan: object | None = None
        self._z_mesh_levels_um: tuple[float, ...] = ()
        self._z_mesh_visible = True
        self._z_mesh_segments: tuple[tuple[float, float, float], ...] = ()
        self._mesh_projection: tuple[float, float, float] | None = None
        self._mesh_tooltip_active = False
        self._mesh_tooltip_label = QLabel(self)
        self._mesh_tooltip_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._mesh_tooltip_label.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._mesh_tooltip_label.setTextFormat(Qt.TextFormat.PlainText)
        self._mesh_tooltip_label.setBackgroundRole(QPalette.ColorRole.ToolTipBase)
        self._mesh_tooltip_label.setForegroundRole(QPalette.ColorRole.ToolTipText)
        self._mesh_tooltip_label.setAutoFillBackground(True)
        self._mesh_tooltip_label.setFrameShape(QFrame.Shape.Box)
        self._mesh_tooltip_label.setMargin(6)
        self._mesh_tooltip_label.hide()
        self._z_label_hitboxes = {}
        self._selected_z_key = None
        self._selected_height_um = None
        self._control_intervals: tuple[MeshControlInterval, ...] = ()
        self._overridden_control_keys: frozenset[tuple[str, float, float]] = frozenset()
        self._message = "载入 .layer 定义后显示截面"
        self._zoom_factor = self._MIN_ZOOM
        self._pan_offset_px = QPointF()
        self._drag_position: QPointF | None = None
        self._click_press_position: QPointF | None = None
        self._click_moved = False
        self._last_visible_geometry_box = QRectF()
        self._visible_control_identifiers: tuple[str, ...] = ()
        self._visible_control_leader_identifiers: tuple[str, ...] = ()
        # The widget shares a responsive splitter with two interval tables.
        # A large hard minimum makes Qt overlap siblings on compact laptop
        # screens; painting already adapts to the available rectangle.
        self.setMinimumSize(240, 160)
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setToolTip(
            "单击截面或 Z 编号定位区间；滚轮以指针为中心缩放，拖拽平移，双击空白处恢复全图；"
            "勾选“Z 网格”显示实际厚度分层，悬停显示单元厚度，放大可查看细小单元"
        )

    def sizeHint(self) -> QSize:
        return QSize(620, 470)

    def set_plan(self, plan: object | None, message: str = "") -> None:
        if plan is not self._plan:
            self.reset_view(update=False)
            self._z_mesh_levels_um = ()
            self._z_mesh_segments = ()
        self._plan = plan
        self._message = message
        self.update()

    def set_z_mesh_levels(self, levels_um: Iterable[float]) -> None:
        """Use the mesher's final schedule, including interval overrides/merges."""

        levels = tuple(float(value) for value in levels_um)
        if any(not math.isfinite(value) for value in levels) or any(
            upper <= lower for lower, upper in zip(levels, levels[1:])
        ):
            raise ValueError("Z mesh levels must be finite and strictly increasing")
        if levels == self._z_mesh_levels_um:
            return
        self._z_mesh_levels_um = levels
        self._hide_mesh_tooltip()
        by_height: dict[float, list[tuple[float, float]]] = {}
        for x0, x1, z0, z1, material, _layer in self._model_rectangles():
            if material is None:
                continue
            for z in levels[bisect_left(levels, z0):bisect_right(levels, z1)]:
                by_height.setdefault(z, []).append((x0, x1))
        segments = []
        for z, intervals in sorted(by_height.items()):
            runs: list[tuple[float, float]] = []
            for x0, x1 in sorted(intervals):
                if runs and x0 <= runs[-1][1]:
                    runs[-1] = (runs[-1][0], max(runs[-1][1], x1))
                else:
                    runs.append((x0, x1))
            segments.extend((x0, x1, z) for x0, x1 in runs)
        self._z_mesh_segments = tuple(segments)
        self.update()

    def set_z_mesh_visible(self, visible: bool) -> None:
        self._z_mesh_visible = bool(visible)
        self._hide_mesh_tooltip()
        self.update()

    def cell_thickness_at(self, position: QPointF) -> float | None:
        """Resolve the actual Z cell under the pointer, excluding empty space."""
        if not self._z_mesh_visible or len(self._z_mesh_levels_um) < 2 or self._mesh_projection is None:
            return None
        if not self._view_boxes()[1].contains(position):
            return None
        center_x, base_y, scale = self._mesh_projection
        x = (position.x() - center_x) / scale
        z = (base_y - position.y()) / scale
        levels = self._z_mesh_levels_um
        if z < levels[0] or z > levels[-1]:
            return None
        index = min(len(levels) - 2, bisect_right(levels, z) - 1)
        lower, upper = levels[index:index + 2]
        midpoint = (lower + upper) / 2
        if any(material is not None and x0 <= x <= x1 and z0 <= midpoint < z1
               for x0, x1, z0, z1, material, _layer in self._model_rectangles()):
            return upper - lower
        return None

    def _hide_mesh_tooltip(self) -> None:
        if self._mesh_tooltip_active:
            self._mesh_tooltip_label.hide()
            self._mesh_tooltip_active = False

    def _show_mesh_tooltip(self, position: QPointF, text: str) -> None:
        # Move even when the text is unchanged within a cell. Native tooltips
        # can keep their old position when repeatedly shown with the same text.
        label = self._mesh_tooltip_label
        label.setText(text)
        label.adjustSize()
        anchor = position.toPoint() + QPoint(14, 18)
        x = min(anchor.x(), self.width() - label.width() - 4)
        y = anchor.y()
        if y + label.height() > self.height() - 4:
            y = position.toPoint().y() - label.height() - 10
        label.move(max(4, x), max(4, y))
        label.show()
        label.raise_()
        self._mesh_tooltip_active = True

    def _mesh_hover_enabled(self) -> bool:
        return bool(self._z_mesh_levels_um)

    def cell_tooltip_at(self, position: QPointF) -> str | None:
        thickness = self.cell_thickness_at(position)
        if thickness is None:
            return None
        _cx, by, scale = self._mesh_projection
        z = (by - position.y()) / scale
        interval = next((i for i in self._control_intervals
                         if i.axis is ControlAxis.Z and (i.start_um <= z < i.end_um
                         or z == i.end_um == self._z_mesh_levels_um[-1])), None)
        prefix = f"{interval.identifier} · " if interval is not None else ""
        return f"{prefix}厚度：{thickness:.6g} µm"

    def event(self, event) -> bool:
        if event.type() == QEvent.Type.ToolTip and self._mesh_hover_enabled():
            text = self.cell_tooltip_at(QPointF(event.pos()))
            if text is not None:
                self._show_mesh_tooltip(QPointF(event.pos()), text)
            else:
                self._hide_mesh_tooltip()
            event.accept()
            return True
        return super().event(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._hide_mesh_tooltip()
        super().leaveEvent(event)

    def hideEvent(self, event) -> None:  # noqa: N802
        self._hide_mesh_tooltip()
        super().hideEvent(event)

    @property
    def z_mesh_levels_um(self) -> tuple[float, ...]:
        return self._z_mesh_levels_um

    @property
    def zoom_factor(self) -> float:
        """Current geometry magnification; labels always retain their font size."""

        return self._zoom_factor

    @property
    def visible_control_identifiers(self) -> tuple[str, ...]:
        """Interval identifiers painted in the latest preview frame."""

        return self._visible_control_identifiers

    @property
    def visible_control_leader_identifiers(self) -> tuple[str, ...]:
        """Painted interval identifiers whose text uses a leader line."""

        return self._visible_control_leader_identifiers

    def reset_view(self, *, update: bool = True) -> None:
        """Return to the fitted full-section view."""

        self._zoom_factor = self._MIN_ZOOM
        self._mesh_projection = None
        self._z_label_hitboxes = {}
        self._hide_mesh_tooltip()
        self._pan_offset_px = QPointF()
        self._drag_position = None
        self._click_press_position = None
        self._click_moved = False
        self._last_visible_geometry_box = QRectF()
        self._visible_control_identifiers = ()
        self._visible_control_leader_identifiers = ()
        self.unsetCursor()
        if update:
            self.update()

    def _view_boxes(self) -> tuple[QRectF, QRectF, bool]:
        outer = QRectF(self.rect()).adjusted(14.0, 12.0, -14.0, -12.0)
        compact = outer.width() < 400.0 or outer.height() < 280.0
        title_height = 32.0 if compact else 56.0
        footer_height = 30.0 if compact else 92.0
        side_gutter = 12.0 if compact else 72.0
        right_gutter = 12.0 if compact else 28.0
        plot_box = outer.adjusted(
            side_gutter,
            title_height,
            -right_gutter,
            -footer_height,
        )
        return outer, plot_box, compact

    @staticmethod
    def _bounded_pan(plot_box: QRectF, zoom: float, x: float, y: float) -> QPointF:
        max_x = max(0.0, 0.5 * plot_box.width() * (zoom - 1.0))
        max_y = max(0.0, 0.5 * plot_box.height() * (zoom - 1.0))
        return QPointF(
            max(-max_x, min(max_x, x)),
            max(-max_y, min(max_y, y)),
        )

    @staticmethod
    def _projection_is_fully_visible(
        first: float,
        second: float,
        viewport_start: float,
        viewport_end: float,
        minimum_span: float,
    ) -> bool:
        """Return whether both projection endpoints and its minimum span are visible."""

        lower, upper = sorted((first, second))
        tolerance = 1e-7
        return (
            math.isfinite(lower + upper)
            and lower >= viewport_start - tolerance
            and upper <= viewport_end + tolerance
            and upper - lower >= minimum_span
        )

    def wheelEvent(self, event: QWheelEvent) -> None:  # noqa: N802 - Qt API
        self._hide_mesh_tooltip()
        if self._plan is None:
            event.ignore()
            return

        delta = event.angleDelta().y()
        if delta == 0:
            delta = event.pixelDelta().y()
        if delta == 0:
            event.ignore()
            return

        steps = max(-4.0, min(4.0, delta / 120.0))
        old_zoom = self._zoom_factor
        new_zoom = max(
            self._MIN_ZOOM,
            min(self._MAX_ZOOM, old_zoom * self._ZOOM_STEP**steps),
        )
        if math.isclose(new_zoom, old_zoom, rel_tol=1e-12, abs_tol=1e-12):
            event.accept()
            return
        if math.isclose(new_zoom, self._MIN_ZOOM):
            self.reset_view()
            event.accept()
            return

        _outer, plot_box, _compact = self._view_boxes()
        anchor = event.position()
        anchor_box = self._last_visible_geometry_box.intersected(plot_box)
        if anchor_box.isValid() and not anchor_box.isEmpty():
            anchor = QPointF(
                max(anchor_box.left(), min(anchor_box.right(), anchor.x())),
                max(anchor_box.top(), min(anchor_box.bottom(), anchor.y())),
            )
        elif not plot_box.contains(anchor):
            anchor = plot_box.center()
        old_center = plot_box.center() + self._pan_offset_px
        ratio = new_zoom / old_zoom
        pan_x = anchor.x() - plot_box.center().x() - ratio * (
            anchor.x() - old_center.x()
        )
        pan_y = anchor.y() - plot_box.center().y() - ratio * (
            anchor.y() - old_center.y()
        )
        self._zoom_factor = new_zoom
        self._pan_offset_px = self._bounded_pan(plot_box, new_zoom, pan_x, pan_y)
        self.update()
        event.accept()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802 - Qt API
        if event.button() == Qt.MouseButton.LeftButton:
            self._click_press_position = event.position()
            self._click_moved = False
        if event.button() == Qt.MouseButton.LeftButton and self._zoom_factor > 1.0:
            self._drag_position = event.position()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802 - Qt API
        if self._click_press_position is not None:
            distance = (event.position() - self._click_press_position).manhattanLength()
            self._click_moved |= distance >= QApplication.startDragDistance()
        if self._drag_position is None:
            if self._mesh_hover_enabled():
                text = self.cell_tooltip_at(event.position())
                if text is None:
                    self._hide_mesh_tooltip()
                else:
                    self._show_mesh_tooltip(event.position(), text)
            super().mouseMoveEvent(event)
            return
        if not self._click_moved:
            event.accept()
            return
        delta = event.position() - self._drag_position
        self._hide_mesh_tooltip()
        self._drag_position = event.position()
        _outer, plot_box, _compact = self._view_boxes()
        self._pan_offset_px = self._bounded_pan(
            plot_box,
            self._zoom_factor,
            self._pan_offset_px.x() + delta.x(),
            self._pan_offset_px.y() + delta.y(),
        )
        self.update()
        event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802 - Qt API
        if event.button() == Qt.MouseButton.LeftButton:
            pressed = self._click_press_position
            clicked = (pressed is not None and not self._click_moved
                       and (event.position() - pressed).manhattanLength() < QApplication.startDragDistance())
            was_dragging = self._drag_position is not None
            self._drag_position = None
            self._click_press_position = None
            self.unsetCursor()
            if clicked:
                if self._activate_interval_at(event.position()):
                    event.accept()
                    return
            if was_dragging:
                event.accept()
                return
        super().mouseReleaseEvent(event)

    def _activate_interval_at(self, position):
        hit = self.z_interval_at(position)
        if hit is None:
            return False
        self.z_interval_activated.emit(*hit)
        return True

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:  # noqa: N802 - Qt API
        if event.button() == Qt.MouseButton.LeftButton:
            hit = self.z_interval_at(event.position())
            if hit is not None:
                self._drag_position = None
                self.unsetCursor()
                self._click_press_position = None
                event.accept()
                return
        if event.button() == Qt.MouseButton.LeftButton and self._zoom_factor > 1.0:
            self.reset_view()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def z_interval_at(self, position):
        for key, rect in self._z_label_hitboxes.items():
            if rect.contains(position):
                return key, (key[1] + key[2]) / 2
        if self._mesh_projection is None or not self._view_boxes()[1].contains(position):
            return None
        cx, by, scale = self._mesh_projection
        x, z = (position.x() - cx) / scale, (by - position.y()) / scale
        if not any(material is not None and x0 <= x <= x1 and z0 <= z <= z1
                   for x0, x1, z0, z1, material, _identity in self._model_rectangles()):
            return None
        vertical = [i for i in self._control_intervals if i.axis is ControlAxis.Z]
        for interval in vertical:
            if interval.start_um <= z < interval.end_um:
                return interval.key, z
        if vertical and math.isclose(z, vertical[-1].end_um):
            return vertical[-1].key, vertical[-1].midpoint_um
        return None

    def set_selected_z_interval(self, key, height_um=None, *, ensure_visible=False):
        self._selected_z_key = key
        self._selected_height_um = height_um
        if ensure_visible and key is not None and self._mesh_projection is not None:
            _cx, by, scale = self._mesh_projection
            y = by - (key[1] + key[2]) / 2 * scale
            plot = self._view_boxes()[1]
            if (not plot.top() <= y <= plot.bottom()
                    or self._last_visible_geometry_box.isEmpty()):
                self.reset_view(update=False)
        self.update()

    def material_names(self):
        materials = []
        for layer in _items(_value(self._plan, "layers", ())):
            material = _value(layer, "material", None)
            if isinstance(material, str) and material.strip():
                materials.append(material.strip())
        materials.extend(rect[4] for rect in self._model_rectangles() if rect[4] is not None)
        return tuple(dict.fromkeys(materials))

    def material_palette(self):
        return self._material_colors(self.material_names())

    def resizeEvent(self, event: QResizeEvent) -> None:  # noqa: N802 - Qt API
        super().resizeEvent(event)
        if self._zoom_factor > 1.0:
            _outer, plot_box, _compact = self._view_boxes()
            self._pan_offset_px = self._bounded_pan(
                plot_box,
                self._zoom_factor,
                self._pan_offset_px.x(),
                self._pan_offset_px.y(),
            )

    def set_control_intervals(
        self,
        control_intervals: Iterable[MeshControlInterval],
        overridden_keys: Iterable[tuple[str, float, float]] = (),
    ) -> None:
        """Install interval controls without changing the section geometry."""

        self._control_intervals = tuple(control_intervals)
        self._overridden_control_keys = frozenset(overridden_keys)
        self._hide_mesh_tooltip()
        self.update()

    @staticmethod
    def _material_key(material: str) -> str:
        return material.strip().casefold()

    @staticmethod
    def _oklab_coordinates(color: QColor) -> tuple[float, float, float]:
        """Return perceptually uniform coordinates for categorical spacing."""

        def linear_srgb(channel: int) -> float:
            value = channel / 255.0
            if value <= 0.04045:
                return value / 12.92
            return ((value + 0.055) / 1.055) ** 2.4

        red, green, blue = (
            linear_srgb(channel)
            for channel in (color.red(), color.green(), color.blue())
        )
        light = 0.4122214708 * red + 0.5363325363 * green + 0.0514459929 * blue
        medium = 0.2119034982 * red + 0.6806995451 * green + 0.1073969566 * blue
        short = 0.0883024619 * red + 0.2817188376 * green + 0.6299787005 * blue
        light_root, medium_root, short_root = (
            value ** (1.0 / 3.0) for value in (light, medium, short)
        )
        return (
            0.2104542553 * light_root
            + 0.7936177850 * medium_root
            - 0.0040720468 * short_root,
            1.9779984951 * light_root
            - 2.4285922050 * medium_root
            + 0.4505937099 * short_root,
            0.0259040371 * light_root
            + 0.7827717662 * medium_root
            - 0.8086757660 * short_root,
        )

    @classmethod
    def _perceptual_color_distance(cls, first: QColor, second: QColor) -> float:
        return math.dist(
            cls._oklab_coordinates(first),
            cls._oklab_coordinates(second),
        )

    @staticmethod
    def _material_color_candidates() -> tuple[QColor, ...]:
        """Build two balanced color rings for large categorical sections."""

        return tuple(
            QColor.fromHsv((hue + offset) % 360, saturation, value)
            for hue in range(0, 360, 15)
            for offset, saturation, value in (
                (0, 145, 220),
                (7, 185, 185),
            )
        )

    @classmethod
    def _material_colors(cls, materials: Iterable[str]) -> dict[str, QColor]:
        """Assign stable colors while maximizing separation within one plan."""

        material_keys = list(
            dict.fromkeys(cls._material_key(str(material)) for material in materials)
        )
        assigned = {
            key: QColor(cls._KNOWN_COLORS[key])
            for key in material_keys
            if key in cls._KNOWN_COLORS
        }
        used_coordinates = [
            cls._oklab_coordinates(color) for color in assigned.values()
        ]
        candidates = cls._material_color_candidates()
        available = [
            (index, color, cls._oklab_coordinates(color))
            for index, color in enumerate(candidates)
        ]
        unknown_keys = sorted(
            (key for key in material_keys if key not in assigned),
            key=lambda key: hashlib.sha256(key.encode("utf-8")).digest(),
        )

        for key in unknown_keys:
            digest = hashlib.sha256(key.encode("utf-8")).digest()
            if not available:
                hue = int.from_bytes(digest[:2], "big") % 360
                assigned[key] = QColor.fromHsv(hue, 145, 220)
                used_coordinates.append(cls._oklab_coordinates(assigned[key]))
                continue

            preferred_index = int.from_bytes(digest[:2], "big") % len(candidates)

            def candidate_score(
                candidate: tuple[int, QColor, tuple[float, float, float]],
            ) -> float:
                original_index, _color, coordinates = candidate
                separation = min(
                    (math.dist(coordinates, used) for used in used_coordinates),
                    default=1.0,
                )
                cyclic_offset = min(
                    (original_index - preferred_index) % len(candidates),
                    (preferred_index - original_index) % len(candidates),
                )
                # The digest only breaks near-ties; perceptual separation is
                # always the dominant part of the assignment.
                return separation - 0.00015 * cyclic_offset

            selected_position, (
                _original_index,
                selected_color,
                selected_coordinates,
            ) = max(
                enumerate(available),
                key=lambda entry: candidate_score(entry[1]),
            )
            del available[selected_position]
            assigned[key] = QColor(selected_color)
            used_coordinates.append(selected_coordinates)

        return assigned

    @classmethod
    def _material_color(cls, material: str) -> QColor:
        key = cls._material_key(material)
        known = cls._KNOWN_COLORS.get(key)
        if known is not None:
            return QColor(known)
        return cls._material_colors((material,))[key]

    def _model_rectangles(
        self,
    ) -> list[tuple[float, float, float, float, str | None, object]]:
        if self._plan is None:
            return []
        rectangles: list[
            tuple[float, float, float, float, str | None, object]
        ] = []
        for column in _items(_value(self._plan, "columns", ())):
            try:
                r0 = float(_first_value(column, ("r0_um", "inner_radius_um", "radius_min_um")))
                r1 = float(_first_value(column, ("r1_um", "outer_radius_um", "radius_max_um")))
            except (TypeError, ValueError):
                continue
            radial_min, radial_max = sorted((abs(r0), abs(r1)))
            if not math.isfinite(radial_min + radial_max) or radial_max <= radial_min:
                continue
            solid_spans = _items(_value(column, "spans", ()))
            air_gaps = _items(_value(column, "air_gaps", ()))
            for span, is_air_gap in (
                *((span, False) for span in solid_spans),
                *((span, True) for span in air_gaps),
            ):
                try:
                    z0 = float(_first_value(span, ("z0_um", "z_bottom_um", "bottom_um")))
                    z1 = float(_first_value(span, ("z1_um", "z_top_um", "top_um")))
                except (TypeError, ValueError):
                    continue
                z_min, z_max = sorted((z0, z1))
                if not math.isfinite(z_min + z_max) or z_max <= z_min:
                    continue
                raw_material = None if is_air_gap else _value(span, "material", None)
                material = (
                    raw_material.strip()
                    if isinstance(raw_material, str) and raw_material.strip()
                    else None
                )
                layer_index = _value(span, "component", _value(span, "layer_index", material))
                rectangles.append((radial_min, radial_max, z_min, z_max, material, layer_index))
                rectangles.append((-radial_max, -radial_min, z_min, z_max, material, layer_index))
        return rectangles

    def paintEvent(self, event: QPaintEvent) -> None:  # noqa: N802 - Qt API
        del event
        self._visible_control_identifiers = ()
        self._visible_control_leader_identifiers = ()
        self._z_label_hitboxes = {}
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        background = self.palette().color(self.backgroundRole())
        painter.fillRect(self.rect(), background)

        outer, plot_box, compact = self._view_boxes()
        border = self.palette().color(self.foregroundRole())
        border.setAlpha(55)
        painter.setPen(QPen(border, 1.0))
        painter.drawRoundedRect(outer, 8.0, 8.0)

        rectangles = self._model_rectangles()
        if not rectangles:
            self._last_visible_geometry_box = QRectF()
            painter.setPen(self.palette().color(self.foregroundRole()))
            painter.drawText(
                outer.adjusted(24.0, 24.0, -24.0, -24.0),
                Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap,
                self._message or "当前定义没有可显示的实体截面",
            )
            return

        materials = self.material_names()
        material_colors = self._material_colors(materials)

        def material_color(material: str) -> QColor:
            return material_colors[self._material_key(material)]

        inferred_radius = max(max(abs(rect[0]), abs(rect[1])) for rect in rectangles)
        inferred_min_z = min(rect[2] for rect in rectangles)
        inferred_max_z = max(rect[3] for rect in rectangles)
        try:
            radius = float(_value(self._plan, "max_radius_um", inferred_radius))
        except (TypeError, ValueError):
            radius = inferred_radius
        try:
            max_height = float(
                _first_value(
                    self._plan,
                    ("construction_height_um", "max_height_um"),
                    inferred_max_z,
                )
            )
        except (TypeError, ValueError):
            max_height = inferred_max_z
        radius = max(radius, inferred_radius)
        min_z = min(0.0, inferred_min_z)
        max_z = max(max_height, inferred_max_z)
        height = max_z - min_z
        if not math.isfinite(radius + height) or radius <= 0.0 or height <= 0.0:
            self._last_visible_geometry_box = QRectF()
            error_color = (
                QColor("#ff8a80")
                if background.lightness() < 128
                else QColor("#b42318")
            )
            painter.setPen(error_color)
            painter.drawText(outer, Qt.AlignmentFlag.AlignCenter, "截面尺寸无效")
            return

        fit_scale = min(plot_box.width() / (2.0 * radius), plot_box.height() / height)
        scale = fit_scale * self._zoom_factor
        geometry_width = 2.0 * radius * scale
        pan = self._bounded_pan(
            plot_box,
            self._zoom_factor,
            self._pan_offset_px.x(),
            self._pan_offset_px.y(),
        )
        center_x = plot_box.center().x() + pan.x()
        model_mid_z = 0.5 * (min_z + max_z)
        base_y = plot_box.center().y() + pan.y() + model_mid_z * scale
        self._mesh_projection = (center_x, base_y, scale)
        self._last_visible_geometry_box = QRectF(
            center_x - radius * scale,
            base_y - max_z * scale,
            2.0 * radius * scale,
            height * scale,
        ).intersected(plot_box)

        heading_color = self.palette().color(self.foregroundRole())
        painter.setPen(heading_color)
        heading_font = painter.font()
        heading_font.setBold(True)
        painter.setFont(heading_font)
        painter.drawText(
            QRectF(outer.left() + 18.0, outer.top() + 7.0, outer.width() - 36.0, 24.0),
            Qt.AlignmentFlag.AlignCenter,
            "完整直径截面" if compact else "过圆心的完整直径截面 · 180° 扫掠母截面",
        )
        heading_font.setBold(False)
        painter.setFont(heading_font)
        if self._zoom_factor > 1.0:
            painter.setPen(heading_color)
            painter.drawText(
                QRectF(outer.right() - 70.0, outer.top() + 7.0, 52.0, 24.0),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                f"{self._zoom_factor:.1f}×",
            )

        def pixel_rect(x0: float, x1: float, z0: float, z1: float) -> QRectF:
            left = center_x + x0 * scale
            right = center_x + x1 * scale
            top = base_y - z1 * scale
            bottom = base_y - z0 * scale
            return QRectF(left, top, right - left, bottom - top)

        # Keep enlarged geometry inside the plot viewport.  Text and legends
        # are painted after restoring the painter, so their font size and
        # placement remain independent of geometry magnification.
        painter.save()
        painter.setClipRect(plot_box)

        # Rectangles only contribute material fill.  Their radial edges are
        # planning breakpoints, not geometry boundaries, so they must never be
        # stroked individually. Disable antialiasing during these adjacent fills
        # as well, otherwise sub-pixel edges can leave hairline seams between
        # two rectangles of the same material.
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        painter.setPen(Qt.PenStyle.NoPen)
        for x0, x1, z0, z1, material, _layer_index in rectangles:
            if material is not None:
                painter.fillRect(pixel_rect(x0, x1, z0, z1), material_color(material))
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        # Mesh lines stay inside solid spans, including disconnected solids and
        # holes. Draw before interfaces so material boundaries stay prominent.
        if self._z_mesh_visible:
            painter.setPen(mesh_pen())
            for x0, x1, z in self._z_mesh_segments:
                y = base_y - z * scale
                if plot_box.top() <= y <= plot_box.bottom():
                    painter.drawLine(QPointF(center_x + x0 * scale, y),
                                     QPointF(center_x + x1 * scale, y))

        # Build the exact arrangement induced by every x/z breakpoint.  An
        # interface exists only if the layer identity differs on its two sides,
        # or if one side is solid and the other is empty.  This deliberately
        # suppresses internal radial lines in a continuous layer (for example
        # the flat Cu top across r=15/25/30/31 in bumpcell.layer).
        x_values = sorted({value for rect in rectangles for value in rect[:2]})
        z_values = sorted({value for rect in rectangles for value in rect[2:4]})
        x_indices = {value: index for index, value in enumerate(x_values)}
        z_indices = {value: index for index, value in enumerate(z_values)}
        cells: list[list[tuple[object, str] | None]] = [
            [None] * (len(x_values) - 1) for _ in range(len(z_values) - 1)
        ]
        for x0, x1, z0, z1, material, layer_index in rectangles:
            if material is None:
                continue
            identity = (layer_index, material)
            for z_index in range(z_indices[z0], z_indices[z1]):
                for x_index in range(x_indices[x0], x_indices[x1]):
                    cells[z_index][x_index] = identity

        painter.setPen(component_pen())

        def differs(first: tuple[object, str] | None, second: tuple[object, str] | None) -> bool:
            return first != second and (first is not None or second is not None)

        def true_runs(flags: list[bool]) -> list[tuple[int, int]]:
            runs: list[tuple[int, int]] = []
            start: int | None = None
            for index, enabled in enumerate((*flags, False)):
                if enabled and start is None:
                    start = index
                elif not enabled and start is not None:
                    runs.append((start, index))
                    start = None
            return runs

        # Vertical exterior edges and identity interfaces.
        for boundary_index, x_value in enumerate(x_values):
            flags: list[bool] = []
            for z_index in range(len(z_values) - 1):
                left = cells[z_index][boundary_index - 1] if boundary_index > 0 else None
                right = (
                    cells[z_index][boundary_index]
                    if boundary_index < len(x_values) - 1
                    else None
                )
                flags.append(differs(left, right))
            for start, end in true_runs(flags):
                painter.drawLine(
                    int(round(center_x + x_value * scale)),
                    int(round(base_y - z_values[start] * scale)),
                    int(round(center_x + x_value * scale)),
                    int(round(base_y - z_values[end] * scale)),
                )

        # Horizontal exterior edges and identity interfaces.
        for boundary_index, z_value in enumerate(z_values):
            flags = []
            for x_index in range(len(x_values) - 1):
                below = cells[boundary_index - 1][x_index] if boundary_index > 0 else None
                above = (
                    cells[boundary_index][x_index]
                    if boundary_index < len(z_values) - 1
                    else None
                )
                flags.append(differs(below, above))
            for start, end in true_runs(flags):
                painter.drawLine(
                    int(round(center_x + x_values[start] * scale)),
                    int(round(base_y - z_value * scale)),
                    int(round(center_x + x_values[end] * scale)),
                    int(round(base_y - z_value * scale)),
                )

        if self._selected_z_key is not None:
            _, lower, upper = self._selected_z_key
            painter.setPen(QPen(QColor("#1688e8"), 2., Qt.PenStyle.DashLine))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRect(pixel_rect(-radius, radius, lower, upper))
        painter.restore()

        dark_theme = background.lightness() < 128
        axis_color = QColor("#70b7ff") if dark_theme else QColor("#326fa8")
        axis_pen = QPen(axis_color, 1.4, Qt.PenStyle.DashLine)
        painter.setPen(axis_pen)
        axis_top = base_y - max_z * scale - 8.0
        axis_bottom = base_y - min_z * scale + 10.0
        painter.save()
        painter.setClipRect(plot_box)
        painter.drawLine(
            int(round(center_x)),
            int(round(axis_top)),
            int(round(center_x)),
            int(round(axis_bottom)),
        )
        painter.restore()
        axis_label_rect = QRectF(center_x + 6.0, axis_top - 2.0, 58.0, 20.0)
        if (
            not compact
            and plot_box.left() <= center_x <= plot_box.right()
            and outer.contains(axis_label_rect)
        ):
            painter.setPen(axis_color)
            painter.drawText(
                axis_label_rect,
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                "中心轴",
            )

        dimension_color = self.palette().color(self.foregroundRole())
        dimension_color.setAlpha(180)
        painter.setPen(dimension_color)
        left_x = center_x - geometry_width / 2.0
        right_x = center_x + geometry_width / 2.0
        label_y = base_y - min_z * scale + 6.0
        if not compact:
            radius_labels = (
                (left_x, QRectF(left_x - 35.0, label_y, 70.0, 20.0), "−R"),
                (center_x, QRectF(center_x - 25.0, label_y, 50.0, 20.0), "0"),
                (right_x, QRectF(right_x - 35.0, label_y, 70.0, 20.0), "+R"),
            )
            for anchor_x, label_rect, text in radius_labels:
                if plot_box.left() <= anchor_x <= plot_box.right() and outer.contains(
                    label_rect
                ):
                    painter.drawText(label_rect, Qt.AlignmentFlag.AlignCenter, text)
            painter.drawText(
                QRectF(outer.right() - 190.0, outer.top() + 31.0, 172.0, 19.0),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                f"R={radius:g} µm · H={height:g} µm",
            )

        def spread_positions(
            natural: list[float],
            lower: float,
            upper: float,
            preferred_gap: float,
        ) -> list[float]:
            """Spread fixed-size labels near their natural anchor positions."""

            if not natural:
                return []
            indexed = sorted(enumerate(natural), key=lambda item: item[1])
            gap = (
                min(preferred_gap, max(0.0, (upper - lower) / (len(indexed) - 1)))
                if len(indexed) > 1
                else 0.0
            )
            placed_sorted: list[float] = []
            for _index, target in indexed:
                minimum = lower if not placed_sorted else placed_sorted[-1] + gap
                placed_sorted.append(max(minimum, min(target, upper)))
            if placed_sorted[-1] > upper:
                shift = placed_sorted[-1] - upper
                placed_sorted = [value - shift for value in placed_sorted]
            for index in range(len(placed_sorted) - 2, -1, -1):
                placed_sorted[index] = min(
                    placed_sorted[index],
                    placed_sorted[index + 1] - gap,
                )
            if placed_sorted[0] < lower:
                shift = lower - placed_sorted[0]
                placed_sorted = [value + shift for value in placed_sorted]
            result = [0.0] * len(natural)
            for (original_index, _target), value in zip(indexed, placed_sorted):
                result[original_index] = value
            return result

        # Fixed-size labels are selected from the *current projected view*.
        # Compact fitted views intentionally omit them; once the user zooms,
        # each dimension appears as soon as both endpoints are visible. Radial
        # text may be moved into the annotation lane and connected by a leader,
        # so a narrow interval does not need to contain its own label. If either
        # endpoint leaves the viewport, the whole annotation (bracket, ticks,
        # projection, leader and text) disappears instead of leaving a clipped
        # or misleading fragment.
        fitted_annotation_mode = not compact and math.isclose(
            self._zoom_factor,
            self._MIN_ZOOM,
            rel_tol=1e-9,
            abs_tol=1e-9,
        )
        controls_allowed = (
            (
                fitted_annotation_mode
                or self._zoom_factor > self._MIN_ZOOM + 1e-9
            )
            and self._last_visible_geometry_box.isValid()
            and not self._last_visible_geometry_box.isEmpty()
        )
        font_metrics = painter.fontMetrics()
        label_height = max(18.0, float(font_metrics.height() + 2))
        radial_projections: list[tuple[MeshControlInterval, float, float, float]] = []
        vertical_projections: list[tuple[MeshControlInterval, float, float, float]] = []
        if controls_allowed:
            for interval in self._control_intervals:
                if (
                    interval.axis is ControlAxis.RADIAL
                    and 0.0 <= interval.start_um < interval.end_um <= radius
                ):
                    label_width = max(
                        30.0,
                        float(font_metrics.horizontalAdvance(interval.identifier) + 10),
                    )
                    positive = (
                        center_x + interval.start_um * scale,
                        center_x + interval.end_um * scale,
                    )
                    negative = (
                        center_x - interval.end_um * scale,
                        center_x - interval.start_um * scale,
                    )
                    if fitted_annotation_mode:
                        radial_projections.append(
                            (interval, *positive, label_width)
                        )
                        continue
                    for start_x, end_x in (positive, negative):
                        if self._projection_is_fully_visible(
                            start_x,
                            end_x,
                            plot_box.left(),
                            plot_box.right(),
                            1.0,
                        ):
                            radial_projections.append(
                                (interval, start_x, end_x, label_width)
                            )
                            break
                elif (
                    interval.axis is ControlAxis.Z
                    and min_z <= interval.start_um < interval.end_um <= max_z
                ):
                    start_y = base_y - interval.start_um * scale
                    end_y = base_y - interval.end_um * scale
                    if fitted_annotation_mode or self._projection_is_fully_visible(
                        start_y,
                        end_y,
                        plot_box.top(),
                        plot_box.bottom(),
                        label_height + 4.0,
                    ):
                        label_width = max(
                            43.0,
                            float(font_metrics.horizontalAdvance(interval.identifier) + 10),
                        )
                        vertical_projections.append(
                            (interval, start_y, end_y, label_width)
                        )

        regular_marker = QColor("#b7c4ce") if dark_theme else QColor("#526b7a")
        regular_marker.setAlpha(175)
        boundary_marker = QColor("#d0dae0") if dark_theme else QColor("#78909c")
        boundary_marker.setAlpha(120)
        override_marker = QColor("#ffbd59") if dark_theme else QColor("#d97706")

        # Annotations are fixed-pixel overlays. Geometry magnifies underneath
        # them, while text and line widths remain unchanged.
        painter.save()
        painter.setClipRect(outer)

        radial_boundaries = sorted(
            {
                value
                for _interval, start_x, end_x, _width in radial_projections
                for value in (start_x, end_x)
            }
        )
        if compact:
            radial_label_y = outer.bottom() - label_height - 2.0
            bracket_y = radial_label_y - 5.0
        else:
            bracket_y = plot_box.bottom() + 9.0
            radial_label_y = bracket_y + 8.0
        geometry_bottom = (
            self._last_visible_geometry_box.bottom()
            if self._last_visible_geometry_box.isValid()
            else plot_box.bottom()
        )
        painter.setPen(QPen(boundary_marker, 0.9, Qt.PenStyle.DashLine))
        for boundary_x in radial_boundaries:
            painter.drawLine(
                int(round(boundary_x)),
                int(round(geometry_bottom + 2.0)),
                int(round(boundary_x)),
                int(round(bracket_y + 4.0)),
            )

        radial_natural_x = [
            0.5 * (start_x + end_x)
            for _interval, start_x, end_x, _width in radial_projections
        ]
        radial_label_gap = max(
            (width for _interval, _start, _end, width in radial_projections),
            default=30.0,
        ) + 2.0
        if fitted_annotation_mode:
            radial_label_lower = center_x + 13.0
            radial_label_upper = min(outer.right() - 20.0, right_x - 3.0)
        else:
            # Zoomed labels live in a fixed-pixel lane. Keep the complete text
            # inside the preview and spread neighbouring labels even when the
            # underlying interval is only a few pixels wide; the existing
            # leader line preserves the association with its bracket.
            maximum_label_width = max(
                (width for _interval, _start, _end, width in radial_projections),
                default=30.0,
            )
            radial_label_lower = outer.left() + maximum_label_width / 2.0 + 2.0
            radial_label_upper = outer.right() - maximum_label_width / 2.0 - 2.0
        radial_label_x = spread_positions(
            radial_natural_x,
            radial_label_lower,
            radial_label_upper,
            radial_label_gap,
        )
        leader_identifiers: list[str] = []
        for (interval, start_x, end_x, label_width), natural_x, placed_x in zip(
            radial_projections,
            radial_natural_x,
            radial_label_x,
        ):
            overridden = interval.key in self._overridden_control_keys
            color = override_marker if overridden else regular_marker
            painter.setPen(QPen(color, 2.2 if overridden else 1.25))
            painter.drawLine(
                int(round(start_x)),
                int(round(bracket_y)),
                int(round(end_x)),
                int(round(bracket_y)),
            )
            painter.drawLine(
                int(round(start_x)), int(round(bracket_y - 4.0)),
                int(round(start_x)), int(round(bracket_y + 4.0)),
            )
            painter.drawLine(
                int(round(end_x)), int(round(bracket_y - 4.0)),
                int(round(end_x)), int(round(bracket_y + 4.0)),
            )
            if not math.isclose(natural_x, placed_x, abs_tol=0.5):
                leader_identifiers.append(interval.identifier)
                painter.setPen(QPen(color, 1.0, Qt.PenStyle.DashLine))
                painter.drawLine(
                    int(round(natural_x)),
                    int(round(bracket_y + 3.0)),
                    int(round(placed_x)),
                    int(round(radial_label_y)),
                )
            label_rect = QRectF(
                placed_x - label_width / 2.0,
                radial_label_y,
                label_width,
                label_height,
            )
            if overridden:
                painter.fillRect(label_rect.adjusted(1.0, 1.0, -1.0, -1.0), QColor("#fff0b8"))
            painter.setPen(color)
            painter.drawText(label_rect, Qt.AlignmentFlag.AlignCenter, interval.identifier)

        vertical_boundaries = sorted(
            {
                value
                for _interval, start_y, end_y, _width in vertical_projections
                for value in (start_y, end_y)
            }
        )
        z_label_width = max(
            (width for _interval, _start, _end, width in vertical_projections),
            default=43.0,
        )
        z_label_x = outer.left() + 5.0
        z_bracket_x = z_label_x + z_label_width + 5.0
        geometry_left = (
            self._last_visible_geometry_box.left()
            if self._last_visible_geometry_box.isValid()
            else plot_box.left()
        )
        painter.setPen(QPen(boundary_marker, 0.9, Qt.PenStyle.DashLine))
        for boundary_y in vertical_boundaries:
            painter.drawLine(
                int(round(z_bracket_x - 4.0)), int(round(boundary_y)),
                int(round(geometry_left - 2.0)), int(round(boundary_y)),
            )

        vertical_natural_y = [
            0.5 * (start_y + end_y)
            for _interval, start_y, end_y, _width in vertical_projections
        ]
        vertical_label_y = (
            spread_positions(
                vertical_natural_y,
                plot_box.top() + label_height / 2.0,
                plot_box.bottom() - label_height / 2.0,
                label_height,
            )
            if fitted_annotation_mode
            else vertical_natural_y
        )
        for (interval, start_y, end_y, label_width), natural_y, placed_y in zip(
            vertical_projections,
            vertical_natural_y,
            vertical_label_y,
        ):
            overridden = interval.key in self._overridden_control_keys
            color = override_marker if overridden else regular_marker
            painter.setPen(QPen(color, 2.2 if overridden else 1.25))
            painter.drawLine(
                int(round(z_bracket_x)), int(round(end_y)),
                int(round(z_bracket_x)), int(round(start_y)),
            )
            painter.drawLine(
                int(round(z_bracket_x - 4.0)), int(round(start_y)),
                int(round(z_bracket_x + 4.0)), int(round(start_y)),
            )
            painter.drawLine(
                int(round(z_bracket_x - 4.0)), int(round(end_y)),
                int(round(z_bracket_x + 4.0)), int(round(end_y)),
            )
            if not math.isclose(natural_y, placed_y, abs_tol=0.5):
                leader_identifiers.append(interval.identifier)
                painter.setPen(QPen(color, 1.0, Qt.PenStyle.DashLine))
                painter.drawLine(
                    int(round(z_bracket_x - 3.0)),
                    int(round(natural_y)),
                    int(round(z_label_x + label_width)),
                    int(round(placed_y)),
                )
            label_rect = QRectF(
                z_label_x,
                placed_y - label_height / 2.0,
                label_width,
                label_height,
            )
            self._z_label_hitboxes[interval.key] = QRectF(label_rect)
            if interval.key == self._selected_z_key:
                painter.fillRect(label_rect, QColor("#cdeaff"))
                color = QColor("#0867b1")
            elif overridden:
                painter.fillRect(label_rect.adjusted(1.0, 1.0, -1.0, -1.0), QColor("#fff0b8"))
            elif compact:
                painter.fillRect(label_rect.adjusted(1.0, 1.0, -1.0, -1.0), background)
            painter.setPen(color)
            painter.drawText(label_rect, Qt.AlignmentFlag.AlignCenter, interval.identifier)

        painter.restore()
        self._visible_control_identifiers = tuple(
            interval.identifier
            for interval, *_rest in (*radial_projections, *vertical_projections)
        )
        self._visible_control_leader_identifiers = tuple(leader_identifiers)

        legend_y = outer.bottom() - 28.0
        legend_x = outer.left() + 20.0
        painter.setFont(heading_font)
        if not (compact and radial_projections):
            for material in materials:
                text_width = painter.fontMetrics().horizontalAdvance(material)
                item_width = 18.0 + text_width + 18.0
                if legend_x + item_width > outer.right() - 12.0:
                    painter.setPen(dimension_color)
                    painter.drawText(
                        QRectF(legend_x, legend_y, 24.0, 18.0),
                        Qt.AlignmentFlag.AlignCenter,
                        "…",
                    )
                    break
                painter.fillRect(
                    QRectF(legend_x, legend_y + 3.0, 12.0, 12.0),
                    material_color(material),
                )
                painter.setPen(dimension_color)
                painter.drawText(
                    QRectF(legend_x + 17.0, legend_y, text_width + 4.0, 18.0),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    material,
                )
                legend_x += item_width
