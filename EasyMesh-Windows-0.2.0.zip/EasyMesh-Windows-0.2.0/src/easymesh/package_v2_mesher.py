"""Generate one conformal TET4 mesh from audited Package V2 geometry.

The production backend accepts Box fragments and the revision-2 rectangular
frame extrusion.  Frames are constructed as one strictly interior through-cut
before their instance placement is applied.  All fragments are built in one
isolated OpenCASCADE model, fused per Component, and then fragmented together
exactly once.  Provenance is recovered exclusively from OCC Boolean maps;
coordinate proximity and post-mesh node merging are never used as repairs.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import re
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Sequence

from .gmsh_runtime import isolated_gmsh_model
from .output_artifacts import (
    atomic_output_path,
    exclusive_output_lock,
    file_artifact,
    normalized_mesh_output,
)
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalGeneratedGeometry,
    CanonicalGeometryFragment,
    CanonicalRigidPlacement,
    CanonicalRectangularFrameExtrusion,
    audit_canonical_geometry,
)
from .quality import QualityAssessment, classify_mesh_quality
from .volume_mesh import ELEMENT_SPECS, ElementKind, VolumeMesh, load_volume_mesh


_ALL_SOLIDS = "ALL_SOLID_VOLUMES"
_MATERIAL_PREFIX = "MATERIAL_"
_COMPONENT_PREFIX = "COMPONENT_"
_MASS_REL_TOLERANCE = 1.0e-9
_MASS_ABS_TOLERANCE = 1.0e-18
_MAX_GMSH_INTEGER = 2_147_483_647
_MAX_GENERATED_COMPONENT_COUNT = 512
_MAX_GENERATED_FRAGMENT_COUNT = 4_096
_MAX_FRAGMENTS_PER_COMPONENT = 2_048
_SUPPORTED_FRAGMENT_ROOT_TYPES = (
    CanonicalBox,
    CanonicalRectangularFrameExtrusion,
)


class GeneratedMeshError(RuntimeError):
    """Raised when generated geometry cannot be meshed without ambiguity."""


def _finite_positive(value: object, *, field_name: str) -> float:
    if isinstance(value, bool):
        raise GeneratedMeshError(f"{field_name} must be a positive finite number")
    try:
        number = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise GeneratedMeshError(
            f"{field_name} must be a positive finite number"
        ) from error
    if not math.isfinite(number) or number <= 0.0:
        raise GeneratedMeshError(f"{field_name} must be a positive finite number")
    return number


def _positive_integer(value: object, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise GeneratedMeshError(f"{field_name} must be a positive integer")
    return value


@dataclass(frozen=True, slots=True)
class GeneratedTetMeshControls:
    """Small deterministic control surface for the generated TET4 mesher."""

    target_edge_mm: float
    random_seed: int = 1
    optimize: bool = True
    maximum_element_count: int = 2_000_000

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "target_edge_mm",
            _finite_positive(self.target_edge_mm, field_name="target_edge_mm"),
        )
        if isinstance(self.random_seed, bool) or not isinstance(self.random_seed, int):
            raise GeneratedMeshError("random_seed must be an integer")
        if not 0 <= self.random_seed <= _MAX_GMSH_INTEGER:
            raise GeneratedMeshError(
                f"random_seed must be between 0 and {_MAX_GMSH_INTEGER}"
            )
        if not isinstance(self.optimize, bool):
            raise GeneratedMeshError("optimize must be boolean")
        maximum = _positive_integer(
            self.maximum_element_count,
            field_name="maximum_element_count",
        )
        if maximum > _MAX_GMSH_INTEGER:
            raise GeneratedMeshError(
                "maximum_element_count exceeds the supported Gmsh integer range"
            )
        object.__setattr__(self, "maximum_element_count", maximum)


@dataclass(frozen=True, slots=True, order=True)
class GeneratedComponentKey:
    instance_id: str
    component_id: str

    def __post_init__(self) -> None:
        for field_name in ("instance_id", "component_id"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise GeneratedMeshError(
                    f"generated component {field_name} must be non-empty"
                )
            object.__setattr__(self, field_name, value.strip())


@dataclass(frozen=True, slots=True)
class GeneratedInterfaceAudit:
    first: GeneratedComponentKey
    second: GeneratedComponentKey
    occ_surface_count: int
    triangle_face_count: int
    interface_node_count: int
    numbered_face_sha256: str


@dataclass(frozen=True, slots=True)
class GeneratedMeshSummary:
    mesh_path: str
    node_count: int
    tet_count: int
    volume_count: int
    component_volume_counts: Mapping[GeneratedComponentKey, int]
    component_occ_volume_mm3: Mapping[GeneratedComponentKey, float]
    component_reopened_tet_volume_mm3: Mapping[GeneratedComponentKey, float]
    component_element_counts: Mapping[GeneratedComponentKey, int]
    material_element_counts: Mapping[str, int]
    component_physical_names: Mapping[GeneratedComponentKey, str]
    material_physical_names: Mapping[str, str]
    interfaces: tuple[GeneratedInterfaceAudit, ...]
    duplicate_node_count: int
    min_jacobian_determinant: float
    min_scaled_jacobian: float
    min_sicn: float
    min_sige: float
    quality_classification: str
    quality_warnings: tuple[str, ...]
    quality_advisories: tuple[str, ...]
    numbered_mesh_sha256: str
    mesh_artifact: Mapping[str, str | int]
    written_mesh_reopened_verified: bool

    def __post_init__(self) -> None:
        for field_name in (
            "component_volume_counts",
            "component_occ_volume_mm3",
            "component_reopened_tet_volume_mm3",
            "component_element_counts",
            "material_element_counts",
            "component_physical_names",
            "material_physical_names",
            "mesh_artifact",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, Mapping):
                raise GeneratedMeshError(f"{field_name} must be a mapping")
            object.__setattr__(self, field_name, MappingProxyType(dict(value)))


@dataclass(frozen=True, slots=True)
class _ComponentInput:
    key: GeneratedComponentKey
    material: str
    fragments: tuple[CanonicalGeometryFragment, ...]


@dataclass(frozen=True, slots=True)
class _OccOwnership:
    volume_owner: Mapping[int, GeneratedComponentKey]
    component_volumes: Mapping[GeneratedComponentKey, tuple[int, ...]]
    component_material: Mapping[GeneratedComponentKey, str]
    component_volume_mm3: Mapping[GeneratedComponentKey, float]
    interface_surfaces: Mapping[
        tuple[GeneratedComponentKey, GeneratedComponentKey], tuple[int, ...]
    ]


@dataclass(frozen=True, slots=True)
class _QualityEvidence:
    min_jacobian_determinant: float
    min_scaled_jacobian: float
    min_sicn: float
    min_sige: float
    assessment: QualityAssessment


def _load_gmsh() -> Any:
    try:
        import gmsh  # type: ignore
    except ModuleNotFoundError as error:  # pragma: no cover - dependency failure
        raise RuntimeError("Gmsh is required for Package V2 meshing") from error
    return gmsh


def _canonical_inputs(
    geometries: Sequence[CanonicalGeneratedGeometry],
) -> tuple[_ComponentInput, ...]:
    if isinstance(geometries, (str, bytes)):
        raise GeneratedMeshError("geometries must be a sequence")
    try:
        raw = tuple(geometries)
    except TypeError as error:
        raise GeneratedMeshError("geometries must be a sequence") from error
    if not raw:
        raise GeneratedMeshError("at least one generated geometry is required")
    if any(type(value) is not CanonicalGeneratedGeometry for value in raw):
        raise GeneratedMeshError(
            "geometries must contain CanonicalGeneratedGeometry values"
        )
    component_count = sum(len(value.components) for value in raw)
    if component_count > _MAX_GENERATED_COMPONENT_COUNT:
        raise GeneratedMeshError(
            "generated Component count exceeds the mesher limit: "
            f"{component_count} > {_MAX_GENERATED_COMPONENT_COUNT}"
        )
    fragment_count = sum(
        len(component.fragments)
        for geometry in raw
        for component in geometry.components
    )
    if fragment_count > _MAX_GENERATED_FRAGMENT_COUNT:
        raise GeneratedMeshError(
            "generated geometry fragment count exceeds the mesher limit: "
            f"{fragment_count} > {_MAX_GENERATED_FRAGMENT_COUNT}"
        )
    for geometry in raw:
        for component in geometry.components:
            if len(component.fragments) > _MAX_FRAGMENTS_PER_COMPONENT:
                raise GeneratedMeshError(
                    "one generated Component exceeds the fragment limit: "
                    f"{len(component.fragments)} > "
                    f"{_MAX_FRAGMENTS_PER_COMPONENT}"
                )
    instance_ids = tuple(value.instance_id for value in raw)
    if len(set(instance_ids)) != len(instance_ids):
        raise GeneratedMeshError(
            "generated geometry instance identifiers must be unique"
        )

    components: list[_ComponentInput] = []
    keys: set[GeneratedComponentKey] = set()
    material_casefold: dict[str, str] = {}
    for geometry in raw:
        audit_canonical_geometry(geometry)
        for component in geometry.components:
            key = GeneratedComponentKey(geometry.instance_id, component.component_id)
            if key in keys:
                raise GeneratedMeshError(f"duplicate generated component {key!r}")
            keys.add(key)
            folded = component.material_name.casefold()
            previous = material_casefold.setdefault(folded, component.material_name)
            if previous != component.material_name:
                raise GeneratedMeshError(
                    "material identifiers must be unique ignoring case: "
                    f"{previous!r} and {component.material_name!r}"
                )
            for fragment in component.fragments:
                if type(fragment.root) not in _SUPPORTED_FRAGMENT_ROOT_TYPES:
                    raise GeneratedMeshError(
                        "generated mesher supports CanonicalBox and "
                        "CanonicalRectangularFrameExtrusion only: "
                        f"{key!r}/{fragment.fragment_id}"
                    )
                if type(fragment.placement) is not CanonicalRigidPlacement:
                    raise GeneratedMeshError(
                        f"fragment {fragment.fragment_id!r} has invalid placement"
                    )
            components.append(
                _ComponentInput(
                    key,
                    component.material_name,
                    component.fragments,
                )
            )
    return tuple(components)


def _safe_token(value: str, *, limit: int = 22) -> str:
    token = re.sub(r"[^A-Z0-9]+", "_", value.upper()).strip("_")
    return (token or "ID")[:limit]


def _component_physical_name(key: GeneratedComponentKey) -> str:
    source = f"{key.instance_id}\0{key.component_id}"
    suffix = hashlib.sha256(source.encode("utf-8")).hexdigest()[:12].upper()
    return (
        f"{_COMPONENT_PREFIX}{_safe_token(key.instance_id)}_"
        f"{_safe_token(key.component_id)}_{suffix}"
    )


def _material_physical_name(material: str) -> str:
    suffix = hashlib.sha256(material.encode("utf-8")).hexdigest()[:10].upper()
    return f"{_MATERIAL_PREFIX}{_safe_token(material, limit=32)}_{suffix}"


def _mass_close(left: float, right: float) -> bool:
    return math.isclose(
        left,
        right,
        rel_tol=_MASS_REL_TOLERANCE,
        abs_tol=_MASS_ABS_TOLERANCE,
    )


def _capped_term(
    coefficient: float,
    factors: Sequence[float],
    *,
    cap: float,
) -> float:
    value = coefficient
    for factor in factors:
        if not math.isfinite(factor) or factor < 0.0:
            return cap
        if factor != 0.0 and value > cap / factor:
            return cap
        value *= factor
    return min(value, cap)


def _generated_element_preflight_estimate(
    components: Sequence[_ComponentInput],
    controls: GeneratedTetMeshControls,
) -> int:
    """Return a capped conservative estimate using volume/surface/edge scales.

    This is deliberately an early resource guard, not a promise of the final
    TET count.  The exact post-generation limit remains mandatory.
    """

    cap = float(controls.maximum_element_count + 1)
    total = 0.0
    for component in components:
        for fragment in component.fragments:
            for size_xyz_mm in _fragment_preflight_box_sizes(fragment.root):
                ratios = tuple(
                    size / controls.target_edge_mm for size in size_xyz_mm
                )
                if any(not math.isfinite(value) for value in ratios):
                    return controls.maximum_element_count + 1
                rx, ry, rz = ratios
                terms = (
                    _capped_term(24.0, (rx, ry, rz), cap=cap),
                    _capped_term(16.0, (rx, ry), cap=cap),
                    _capped_term(16.0, (ry, rz), cap=cap),
                    _capped_term(16.0, (rz, rx), cap=cap),
                    _capped_term(16.0, (rx,), cap=cap),
                    _capped_term(16.0, (ry,), cap=cap),
                    _capped_term(16.0, (rz,), cap=cap),
                    32.0,
                )
                for term in terms:
                    if total >= cap - term:
                        return controls.maximum_element_count + 1
                    total += term
    if not math.isfinite(total):
        return controls.maximum_element_count + 1
    return math.ceil(total)


def _frame_wall_sizes(
    frame: CanonicalRectangularFrameExtrusion,
) -> tuple[tuple[float, float, float], ...]:
    outer_x, outer_y = frame.outer_size_xy_mm
    offset_x, offset_y = frame.opening_offset_xy_mm
    opening_x, opening_y = frame.opening_size_xy_mm
    far_x = outer_x - offset_x - opening_x
    far_y = outer_y - offset_y - opening_y
    return (
        (offset_x, outer_y, frame.height_mm),
        (far_x, outer_y, frame.height_mm),
        (opening_x, offset_y, frame.height_mm),
        (opening_x, far_y, frame.height_mm),
    )


def _fragment_preflight_box_sizes(
    root: object,
) -> tuple[tuple[float, float, float], ...]:
    if type(root) is CanonicalBox:
        return (root.size_xyz_mm,)
    if type(root) is CanonicalRectangularFrameExtrusion:
        return _frame_wall_sizes(root)
    raise GeneratedMeshError("unsupported generated fragment in preflight")


def _fragment_analytic_volume(root: object) -> float:
    if type(root) is CanonicalBox:
        value = math.prod(root.size_xyz_mm)
    elif type(root) is CanonicalRectangularFrameExtrusion:
        value = math.fsum(
            width * depth * height
            for width, depth, height in _frame_wall_sizes(root)
        )
    else:
        raise GeneratedMeshError("unsupported generated fragment volume")
    if not math.isfinite(value) or value <= 0.0:
        raise GeneratedMeshError("generated fragment has non-positive analytic volume")
    return value


def _apply_placement(
    gmsh: Any,
    tag: int,
    placement: CanonicalRigidPlacement,
) -> None:
    pivot = placement.pivot_xyz_mm
    axes = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
    for angle, axis in zip(placement.rotation_deg_xyz, axes):
        if angle == 0.0:
            continue
        gmsh.model.occ.rotate(
            [(3, tag)],
            *pivot,
            *axis,
            math.radians(angle),
        )
    if any(value != 0.0 for value in placement.translation_xyz_mm):
        gmsh.model.occ.translate(
            [(3, tag)],
            *placement.translation_xyz_mm,
        )


def _apply_box(gmsh: Any, fragment: CanonicalGeometryFragment) -> int:
    box = fragment.root
    assert type(box) is CanonicalBox
    tag = int(gmsh.model.occ.addBox(*box.origin_xyz_mm, *box.size_xyz_mm))
    _apply_placement(gmsh, tag, fragment.placement)
    return tag


def _volume_tags(
    dim_tags: Iterable[tuple[int, int]],
    *,
    context: str,
) -> tuple[int, ...]:
    values = tuple((int(dimension), int(tag)) for dimension, tag in dim_tags)
    if any(dimension != 3 for dimension, _tag in values):
        raise GeneratedMeshError(f"{context} returned a non-volume entity")
    tags = tuple(tag for _dimension, tag in values)
    if not tags or len(set(tags)) != len(tags):
        raise GeneratedMeshError(f"{context} returned empty or duplicate volumes")
    return tags


def _apply_rectangular_frame(
    gmsh: Any,
    fragment: CanonicalGeometryFragment,
) -> int:
    frame = fragment.root
    assert type(frame) is CanonicalRectangularFrameExtrusion
    x, y, z = frame.outer_origin_xyz_mm
    outer_x, outer_y = frame.outer_size_xy_mm
    offset_x, offset_y = frame.opening_offset_xy_mm
    opening_x, opening_y = frame.opening_size_xy_mm
    outer_tag = int(gmsh.model.occ.addBox(x, y, z, outer_x, outer_y, frame.height_mm))
    opening_tag = int(
        gmsh.model.occ.addBox(
            x + offset_x,
            y + offset_y,
            z,
            opening_x,
            opening_y,
            frame.height_mm,
        )
    )
    output, provenance = gmsh.model.occ.cut(
        [(3, outer_tag)],
        [(3, opening_tag)],
        removeObject=True,
        removeTool=True,
    )
    output_tags = _volume_tags(output, context="rectangular frame through-cut")
    if len(output_tags) != 1 or len(provenance) != 2:
        raise GeneratedMeshError(
            "rectangular frame through-cut did not produce one provenanced volume"
        )
    output_set = set(output_tags)
    base_map = _volume_tags(
        provenance[0],
        context="rectangular frame base provenance",
    )
    if set(base_map) != output_set or provenance[1]:
        raise GeneratedMeshError(
            "rectangular frame through-cut returned an ambiguous provenance map"
        )
    tag = output_tags[0]
    _apply_placement(gmsh, tag, fragment.placement)
    return tag


def _apply_fragment(gmsh: Any, fragment: CanonicalGeometryFragment) -> int:
    if type(fragment.root) is CanonicalBox:
        return _apply_box(gmsh, fragment)
    if type(fragment.root) is CanonicalRectangularFrameExtrusion:
        return _apply_rectangular_frame(gmsh, fragment)
    raise GeneratedMeshError(
        f"fragment {fragment.fragment_id!r} has an unsupported geometry root"
    )


def _direct_boundary(gmsh: Any, dimension: int, tags: Iterable[int]) -> set[int]:
    dim_tags = [(dimension, int(tag)) for tag in tags]
    if not dim_tags:
        return set()
    return {
        int(tag)
        for child_dimension, tag in gmsh.model.getBoundary(
            dim_tags,
            oriented=False,
            recursive=False,
            combined=False,
        )
        if int(child_dimension) == dimension - 1
    }


def _canonical_pair(
    first: GeneratedComponentKey,
    second: GeneratedComponentKey,
) -> tuple[GeneratedComponentKey, GeneratedComponentKey]:
    return (first, second) if first < second else (second, first)


def _contact_topology(
    gmsh: Any,
    component_volumes: Mapping[GeneratedComponentKey, tuple[int, ...]],
) -> dict[tuple[GeneratedComponentKey, GeneratedComponentKey], tuple[int, ...]]:
    surfaces_by_component = {
        key: _direct_boundary(gmsh, 3, volumes)
        for key, volumes in component_volumes.items()
    }
    curves_by_component = {
        key: _direct_boundary(gmsh, 2, surfaces)
        for key, surfaces in surfaces_by_component.items()
    }
    points_by_component = {
        key: _direct_boundary(gmsh, 1, curves)
        for key, curves in curves_by_component.items()
    }

    surface_incidence: dict[int, list[GeneratedComponentKey]] = {}
    for key, surfaces in surfaces_by_component.items():
        for surface in surfaces:
            surface_incidence.setdefault(surface, []).append(key)
    for surface, owners in surface_incidence.items():
        unique = set(owners)
        if len(owners) != len(unique) or len(unique) > 2:
            raise GeneratedMeshError(
                f"OCC surface {surface} has non-manifold Component incidence"
            )

    interfaces: dict[
        tuple[GeneratedComponentKey, GeneratedComponentKey], tuple[int, ...]
    ] = {}
    keys = tuple(component_volumes)
    for first_index, first in enumerate(keys):
        for second in keys[first_index + 1 :]:
            pair = _canonical_pair(first, second)
            shared_surfaces = surfaces_by_component[first].intersection(
                surfaces_by_component[second]
            )
            shared_curves = curves_by_component[first].intersection(
                curves_by_component[second]
            )
            shared_points = points_by_component[first].intersection(
                points_by_component[second]
            )
            if not shared_surfaces:
                if shared_curves or shared_points:
                    kind = "edge" if shared_curves else "point"
                    raise GeneratedMeshError(
                        f"generated Components {first!r} and {second!r} have "
                        f"{kind}-only contact"
                    )
                continue
            interface_curves = _direct_boundary(gmsh, 2, shared_surfaces)
            interface_points = _direct_boundary(gmsh, 1, interface_curves)
            if shared_curves.difference(interface_curves) or shared_points.difference(
                interface_points
            ):
                raise GeneratedMeshError(
                    f"generated Components {first!r} and {second!r} have an "
                    "additional edge/point-only contact"
                )
            interfaces[pair] = tuple(sorted(shared_surfaces))
    return interfaces


def _build_occ_ownership(
    gmsh: Any,
    components: tuple[_ComponentInput, ...],
) -> _OccOwnership:
    union_volumes: dict[GeneratedComponentKey, tuple[int, ...]] = {}
    union_masses: dict[GeneratedComponentKey, float] = {}
    fragment_mass_bounds: dict[GeneratedComponentKey, tuple[float, float]] = {}
    component_material = {component.key: component.material for component in components}

    for component in components:
        fragment_masses = tuple(
            _fragment_analytic_volume(fragment.root)
            for fragment in component.fragments
        )
        if any(
            not math.isfinite(value) or value <= 0.0
            for value in fragment_masses
        ):
            raise GeneratedMeshError(
                f"Component {component.key!r} has an invalid fragment mass"
            )
        fragment_mass_sum = sum(fragment_masses)
        if not math.isfinite(fragment_mass_sum):
            raise GeneratedMeshError(
                f"Component {component.key!r} fragment mass sum is non-finite"
            )
        fragment_mass_bounds[component.key] = (
            max(fragment_masses),
            fragment_mass_sum,
        )
        fragment_tags = tuple(
            _apply_fragment(gmsh, fragment) for fragment in component.fragments
        )
        for fragment, tag, expected_mass in zip(
            component.fragments,
            fragment_tags,
            fragment_masses,
        ):
            actual_mass = float(gmsh.model.occ.getMass(3, tag))
            if not math.isfinite(actual_mass) or actual_mass <= 0.0:
                raise GeneratedMeshError(
                    f"fragment {fragment.fragment_id!r} has non-positive OCC mass"
                )
            if not _mass_close(actual_mass, expected_mass):
                raise GeneratedMeshError(
                    f"fragment {fragment.fragment_id!r} OCC mass differs from "
                    "its canonical analytic volume"
                )
        if len(fragment_tags) == 1:
            output_tags = fragment_tags
        else:
            output, fragment_map = gmsh.model.occ.fuse(
                [(3, fragment_tags[0])],
                [(3, tag) for tag in fragment_tags[1:]],
                removeObject=True,
                removeTool=True,
            )
            output_tags = _volume_tags(
                output,
                context=f"Component {component.key!r} union",
            )
            if len(fragment_map) != len(fragment_tags):
                raise GeneratedMeshError(
                    f"Component {component.key!r} union returned an incomplete map"
                )
            mapped_outputs: set[int] = set()
            output_tag_set = set(output_tags)
            for mapping in fragment_map:
                local_tags: set[int] = set()
                for dimension, tag_value in mapping:
                    if int(dimension) != 3:
                        raise GeneratedMeshError(
                            f"Component {component.key!r} union map contains "
                            "a non-volume entity"
                        )
                    tag = int(tag_value)
                    if tag not in output_tag_set:
                        raise GeneratedMeshError(
                            f"Component {component.key!r} union map references "
                            "an unknown output volume"
                        )
                    if tag in local_tags:
                        raise GeneratedMeshError(
                            f"Component {component.key!r} union map contains "
                            "a duplicate output volume"
                        )
                    local_tags.add(tag)
                # Empty entries are valid for redundant/contained or
                # face-touching fragments in OCC. Component ownership, not
                # per-fragment entity survival, is the production contract.
                mapped_outputs.update(local_tags)
            if mapped_outputs != output_tag_set:
                raise GeneratedMeshError(
                    f"Component {component.key!r} union map does not cover "
                    "every output volume"
                )
        union_volumes[component.key] = tuple(sorted(output_tags))

    gmsh.model.occ.synchronize()
    current_after_union = {
        int(tag) for dimension, tag in gmsh.model.getEntities(3) if int(dimension) == 3
    }
    recorded_after_union = {
        tag for tags in union_volumes.values() for tag in tags
    }
    if current_after_union != recorded_after_union:
        raise GeneratedMeshError(
            "Component union left orphan or unrecorded OCC volumes"
        )
    for key, volumes in union_volumes.items():
        masses = tuple(float(gmsh.model.occ.getMass(3, tag)) for tag in volumes)
        if any(not math.isfinite(value) or value <= 0.0 for value in masses):
            raise GeneratedMeshError(f"Component {key!r} union has non-positive mass")
        union_masses[key] = sum(masses)
        minimum_mass, maximum_mass = fragment_mass_bounds[key]
        if (
            union_masses[key] < minimum_mass
            and not _mass_close(union_masses[key], minimum_mass)
        ) or (
            union_masses[key] > maximum_mass
            and not _mass_close(union_masses[key], maximum_mass)
        ):
            raise GeneratedMeshError(
                f"Component {key!r} union mass is outside fragment bounds"
            )

    flattened: list[tuple[GeneratedComponentKey, int]] = [
        (key, tag)
        for key in (component.key for component in components)
        for tag in union_volumes[key]
    ]
    flattened_tags = tuple(tag for _key, tag in flattened)
    if len(flattened_tags) != len(set(flattened_tags)):
        raise GeneratedMeshError(
            "different Components reference the same pre-fragment OCC volume"
        )
    if len(components) > 1:
        first_tag = flattened[0][1]
        output, mappings = gmsh.model.occ.fragment(
            [(3, first_tag)],
            [(3, tag) for _key, tag in flattened[1:]],
            removeObject=True,
            removeTool=True,
        )
        fragment_output_tags = _volume_tags(
            output,
            context="cross-Component fragment",
        )
        if len(mappings) != len(flattened):
            raise GeneratedMeshError(
                "cross-Component fragment returned an incomplete provenance map"
            )
        gmsh.model.occ.synchronize()
        final_entities = {
            int(tag)
            for dimension, tag in gmsh.model.getEntities(3)
            if int(dimension) == 3
        }
        if set(fragment_output_tags) != final_entities:
            raise GeneratedMeshError(
                "cross-Component fragment output differs from final OCC volumes"
            )
        owners: dict[int, set[GeneratedComponentKey]] = {
            tag: set() for tag in final_entities
        }
        for (key, _input_tag), mapping in zip(flattened, mappings):
            local_tags: set[int] = set()
            for dimension, tag_value in mapping:
                if int(dimension) != 3:
                    raise GeneratedMeshError(
                        "cross-Component fragment map contains a non-volume entity"
                    )
                tag = int(tag_value)
                if tag not in final_entities:
                    raise GeneratedMeshError(
                        "cross-Component fragment map references a removed volume"
                    )
                if tag in local_tags:
                    raise GeneratedMeshError(
                        "cross-Component fragment map contains a duplicate volume"
                    )
                local_tags.add(tag)
                owners[tag].add(key)
        missing = sorted(tag for tag, values in owners.items() if not values)
        if missing:
            raise GeneratedMeshError(
                f"cross-Component fragment lost provenance for volume {missing[0]}"
            )
        overlaps = sorted(tag for tag, values in owners.items() if len(values) != 1)
        if overlaps:
            rendered = sorted(owners[overlaps[0]])
            raise GeneratedMeshError(
                "generated Components overlap in positive volume "
                f"{overlaps[0]}: {rendered!r}"
            )
        volume_owner = {tag: next(iter(values)) for tag, values in owners.items()}
    else:
        gmsh.model.occ.synchronize()
        only_key = components[0].key
        volume_owner = {tag: only_key for tag in union_volumes[only_key]}

    component_volumes: dict[GeneratedComponentKey, list[int]] = {
        component.key: [] for component in components
    }
    for tag, key in volume_owner.items():
        component_volumes[key].append(tag)
    canonical_component_volumes = {
        key: tuple(sorted(tags)) for key, tags in component_volumes.items()
    }
    for key, volumes in canonical_component_volumes.items():
        if not volumes:
            raise GeneratedMeshError(f"Component {key!r} has no final OCC volume")
        final_mass = sum(float(gmsh.model.occ.getMass(3, tag)) for tag in volumes)
        if not _mass_close(final_mass, union_masses[key]):
            raise GeneratedMeshError(
                f"cross-Component Boolean changed Component {key!r} mass: "
                f"{union_masses[key]:.17g} -> {final_mass:.17g}"
            )
        volume_surfaces = {
            volume: _direct_boundary(gmsh, 3, (volume,)) for volume in volumes
        }
        volume_curves = {
            volume: _direct_boundary(gmsh, 2, volume_surfaces[volume])
            for volume in volumes
        }
        volume_points = {
            volume: _direct_boundary(gmsh, 1, volume_curves[volume])
            for volume in volumes
        }
        for first_index, first_volume in enumerate(volumes):
            for second_volume in volumes[first_index + 1 :]:
                shared_surfaces = volume_surfaces[first_volume].intersection(
                    volume_surfaces[second_volume]
                )
                if shared_surfaces:
                    raise GeneratedMeshError(
                        f"Component {key!r} union left an internal OCC surface"
                    )
                shared_curves = volume_curves[first_volume].intersection(
                    volume_curves[second_volume]
                )
                shared_points = volume_points[first_volume].intersection(
                    volume_points[second_volume]
                )
                if shared_curves or shared_points:
                    kind = "edge" if shared_curves else "point"
                    raise GeneratedMeshError(
                        f"Component {key!r} has {kind}-only internal contact"
                    )

    interfaces = _contact_topology(gmsh, canonical_component_volumes)
    return _OccOwnership(
        MappingProxyType(dict(volume_owner)),
        MappingProxyType(canonical_component_volumes),
        MappingProxyType(component_material),
        MappingProxyType(dict(union_masses)),
        MappingProxyType(interfaces),
    )


def _add_physical_groups(
    gmsh: Any,
    ownership: _OccOwnership,
) -> tuple[
    dict[GeneratedComponentKey, str],
    dict[str, str],
]:
    component_names = {
        key: _component_physical_name(key) for key in ownership.component_volumes
    }
    materials = sorted(set(ownership.component_material.values()))
    material_names = {
        material: _material_physical_name(material) for material in materials
    }
    all_names = [*component_names.values(), *material_names.values(), _ALL_SOLIDS]
    folded = [name.casefold() for name in all_names]
    if len(set(folded)) != len(folded):
        raise GeneratedMeshError("generated Physical Group names collide")

    next_tag = 1
    for material in materials:
        entities = sorted(
            tag
            for key, tags in ownership.component_volumes.items()
            if ownership.component_material[key] == material
            for tag in tags
        )
        tag = int(gmsh.model.addPhysicalGroup(3, entities, next_tag))
        gmsh.model.setPhysicalName(3, tag, material_names[material])
        next_tag += 1
    for key in sorted(ownership.component_volumes):
        tag = int(
            gmsh.model.addPhysicalGroup(
                3,
                list(ownership.component_volumes[key]),
                next_tag,
            )
        )
        gmsh.model.setPhysicalName(3, tag, component_names[key])
        next_tag += 1
    all_entities = sorted(ownership.volume_owner)
    tag = int(gmsh.model.addPhysicalGroup(3, all_entities, next_tag))
    gmsh.model.setPhysicalName(3, tag, _ALL_SOLIDS)
    return component_names, material_names


def _tet_faces(connectivity: Sequence[int]) -> tuple[tuple[int, int, int], ...]:
    local_faces = ELEMENT_SPECS[4][2]
    return tuple(
        tuple(sorted(int(connectivity[index]) for index in local_face))
        for local_face in local_faces
    )


def _numbered_face_sha256(faces: Iterable[tuple[int, int, int]]) -> str:
    digest = hashlib.sha256()
    for face in sorted(faces):
        digest.update(f"{face[0]},{face[1]},{face[2]}\n".encode("ascii"))
    return digest.hexdigest()


def _component_boundary_faces_current(
    gmsh: Any,
    ownership: _OccOwnership,
    *,
    maximum_element_count: int,
) -> tuple[
    dict[GeneratedComponentKey, set[tuple[int, int, int]]],
    dict[GeneratedComponentKey, int],
    list[int],
]:
    boundary: dict[GeneratedComponentKey, set[tuple[int, int, int]]] = {}
    element_counts: dict[GeneratedComponentKey, int] = {}
    all_element_tags: list[int] = []
    total_count = 0
    for key, volumes in ownership.component_volumes.items():
        faces: Counter[tuple[int, int, int]] = Counter()
        count = 0
        for volume in volumes:
            element_types, tag_blocks, connectivity_blocks = (
                gmsh.model.mesh.getElements(3, volume)
            )
            for element_type_value, tags, raw_connectivity in zip(
                element_types,
                tag_blocks,
                connectivity_blocks,
            ):
                element_type = int(element_type_value)
                properties = gmsh.model.mesh.getElementProperties(element_type)
                if (
                    element_type != 4
                    or int(properties[1]) != 3
                    or int(properties[2]) != 1
                ):
                    raise GeneratedMeshError(
                        f"Component {key!r} contains non-first-order TET4 elements"
                    )
                block_count = len(tags)
                if total_count > maximum_element_count - block_count:
                    raise GeneratedMeshError(
                        "generated mesh exceeds the "
                        f"{maximum_element_count} element limit"
                    )
                total_count += block_count
                flat = tuple(int(value) for value in raw_connectivity)
                if len(flat) != 4 * len(tags):
                    raise GeneratedMeshError("TET4 connectivity length is inconsistent")
                for index, element_tag in enumerate(tags):
                    connectivity = flat[4 * index : 4 * index + 4]
                    faces.update(_tet_faces(connectivity))
                    all_element_tags.append(int(element_tag))
                    count += 1
        if not count:
            raise GeneratedMeshError(f"Component {key!r} has no TET4 elements")
        if any(value > 2 for value in faces.values()):
            raise GeneratedMeshError(f"Component {key!r} has non-manifold TET faces")
        boundary[key] = {face for face, value in faces.items() if value == 1}
        element_counts[key] = count
    if len(all_element_tags) != len(set(all_element_tags)):
        raise GeneratedMeshError("generated mesh contains duplicate element tags")
    return boundary, element_counts, all_element_tags


def _quality_evidence(gmsh: Any, element_tags: Sequence[int]) -> _QualityEvidence:
    if not element_tags:
        raise GeneratedMeshError("generated mesh contains no volume elements")
    minima: dict[str, float] = {}
    for name in ("minDetJac", "minSJ", "minSICN", "minSIGE"):
        raw_values = gmsh.model.mesh.getElementQualities(element_tags, name)
        if len(raw_values) != len(element_tags):
            raise GeneratedMeshError(
                f"generated mesh returned an incomplete {name} quality block"
            )
        minimum = math.inf
        for raw_value in raw_values:
            value = float(raw_value)
            if not math.isfinite(value) or value <= 0.0:
                raise GeneratedMeshError(
                    f"generated mesh contains an invalid {name} quality value"
                )
            minimum = min(minimum, value)
        minima[name] = minimum
    assessment = classify_mesh_quality(
        minima["minSJ"],
        minima["minSICN"],
        minima["minSIGE"],
    )
    if not assessment.is_valid:
        raise GeneratedMeshError(
            "generated mesh contains invalid signed quality metrics"
        )
    return _QualityEvidence(
        minima["minDetJac"],
        minima["minSJ"],
        minima["minSICN"],
        minima["minSIGE"],
        assessment,
    )


def _surface_triangles(gmsh: Any, surfaces: Sequence[int]) -> set[tuple[int, int, int]]:
    triangles: set[tuple[int, int, int]] = set()
    for surface in surfaces:
        element_types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
            2, surface
        )
        if not tag_blocks:
            raise GeneratedMeshError(f"interface surface {surface} has no triangles")
        for element_type_value, tags, raw_connectivity in zip(
            element_types,
            tag_blocks,
            connectivity_blocks,
        ):
            element_type = int(element_type_value)
            properties = gmsh.model.mesh.getElementProperties(element_type)
            if element_type != 2 or int(properties[1]) != 2 or int(properties[2]) != 1:
                raise GeneratedMeshError(
                    f"interface surface {surface} contains non-TRI3 elements"
                )
            flat = tuple(int(value) for value in raw_connectivity)
            if len(flat) != 3 * len(tags):
                raise GeneratedMeshError("TRI3 connectivity length is inconsistent")
            for index in range(len(tags)):
                face = tuple(sorted(flat[3 * index : 3 * index + 3]))
                if face in triangles:
                    raise GeneratedMeshError("interface TRI3 is duplicated")
                triangles.add(face)  # type: ignore[arg-type]
    return triangles


def _audit_current_mesh(
    gmsh: Any,
    ownership: _OccOwnership,
    *,
    maximum_element_count: int,
) -> tuple[
    dict[GeneratedComponentKey, int],
    tuple[GeneratedInterfaceAudit, ...],
    int,
    _QualityEvidence,
]:
    duplicate_nodes = tuple(int(tag) for tag in gmsh.model.mesh.getDuplicateNodes())
    if duplicate_nodes:
        raise GeneratedMeshError(
            f"generated mesh contains {len(duplicate_nodes)} duplicate nodes"
        )
    boundaries, element_counts, element_tags = _component_boundary_faces_current(
        gmsh,
        ownership,
        maximum_element_count=maximum_element_count,
    )
    quality = _quality_evidence(gmsh, element_tags)

    expected_pairs = set(ownership.interface_surfaces)
    interface_audits: list[GeneratedInterfaceAudit] = []
    keys = tuple(ownership.component_volumes)
    for first_index, first in enumerate(keys):
        for second in keys[first_index + 1 :]:
            pair = _canonical_pair(first, second)
            shared_faces = boundaries[first].intersection(boundaries[second])
            surfaces = ownership.interface_surfaces.get(pair, ())
            if not surfaces:
                if shared_faces:
                    raise GeneratedMeshError(
                        f"mesh created an unplanned interface for {pair!r}"
                    )
                continue
            surface_faces = _surface_triangles(gmsh, surfaces)
            if not shared_faces or shared_faces != surface_faces:
                raise GeneratedMeshError(
                    f"shared TRI interface for {pair!r} differs across Components"
                )
            surface_nodes = {tag for face in surface_faces for tag in face}
            for key in pair:
                volume_nodes: set[int] = set()
                for volume in ownership.component_volumes[key]:
                    volume_nodes.update(
                        int(tag)
                        for tag in gmsh.model.mesh.getNodes(
                            3, volume, includeBoundary=True
                        )[0]
                    )
                if not surface_nodes.issubset(volume_nodes):
                    raise GeneratedMeshError(
                        f"interface nodes are not shared by Component {key!r}"
                    )
            interface_audits.append(
                GeneratedInterfaceAudit(
                    pair[0],
                    pair[1],
                    len(surfaces),
                    len(surface_faces),
                    len(surface_nodes),
                    _numbered_face_sha256(surface_faces),
                )
            )
            expected_pairs.discard(pair)
    if expected_pairs:
        raise GeneratedMeshError("an OCC interface pair was not audited")
    return (
        element_counts,
        tuple(sorted(interface_audits, key=lambda value: (value.first, value.second))),
        len(duplicate_nodes),
        quality,
    )


def _physical_membership_maps(
    component_names: Mapping[GeneratedComponentKey, str],
    material_names: Mapping[str, str],
) -> tuple[dict[str, GeneratedComponentKey], dict[str, str]]:
    return (
        {name: key for key, name in component_names.items()},
        {name: material for material, name in material_names.items()},
    )


def _signed_tet_volume(
    points: Sequence[Sequence[float]],
) -> float:
    if len(points) != 4 or any(len(point) != 3 for point in points):
        raise GeneratedMeshError("TET4 volume audit requires four 3-D points")
    origin = points[0]
    a = tuple(points[1][axis] - origin[axis] for axis in range(3))
    b = tuple(points[2][axis] - origin[axis] for axis in range(3))
    c = tuple(points[3][axis] - origin[axis] for axis in range(3))
    return math.fsum(
        (
            a[0] * (b[1] * c[2] - b[2] * c[1]),
            -a[1] * (b[0] * c[2] - b[2] * c[0]),
            a[2] * (b[0] * c[1] - b[1] * c[0]),
        )
    ) / 6.0


def _boundary_faces_from_volume_mesh(
    mesh: VolumeMesh,
    component_by_name: Mapping[str, GeneratedComponentKey],
    material_by_name: Mapping[str, str],
    expected_material_by_component: Mapping[GeneratedComponentKey, str],
) -> tuple[
    dict[GeneratedComponentKey, set[tuple[int, int, int]]],
    dict[GeneratedComponentKey, int],
    dict[str, int],
    dict[GeneratedComponentKey, float],
]:
    faces: dict[GeneratedComponentKey, Counter[tuple[int, int, int]]] = {
        key: Counter() for key in component_by_name.values()
    }
    if set(expected_material_by_component) != set(faces):
        raise GeneratedMeshError(
            "reopened Component/Material expectations are incomplete"
        )
    component_counts = {key: 0 for key in component_by_name.values()}
    material_counts = {material: 0 for material in material_by_name.values()}
    component_volumes = {key: 0.0 for key in component_by_name.values()}
    component_volume_corrections = {
        key: 0.0 for key in component_by_name.values()
    }
    node_by_tag = mesh.node_map()
    for element in mesh.elements:
        if element.kind is not ElementKind.TET4:
            raise GeneratedMeshError(
                "reopened generated mesh contains non-TET4 elements"
            )
        names = set(element.physical_names)
        component_matches = [
            component_by_name[name] for name in names if name in component_by_name
        ]
        material_matches = [
            material_by_name[name] for name in names if name in material_by_name
        ]
        if len(component_matches) != 1 or len(material_matches) != 1:
            raise GeneratedMeshError(
                "reopened element must belong to exactly one Component and Material"
            )
        if _ALL_SOLIDS not in names or len(names) != 3:
            raise GeneratedMeshError(
                "reopened element Physical Group membership is incomplete"
            )
        key = component_matches[0]
        material = material_matches[0]
        if expected_material_by_component[key] != material:
            raise GeneratedMeshError(
                "reopened Component/Material assignment differs from the "
                f"generated model for {key!r}"
            )
        component_counts[key] += 1
        material_counts[material] += 1
        try:
            points = tuple(
                node_by_tag[tag].coordinates for tag in element.node_tags
            )
        except KeyError as error:
            raise GeneratedMeshError(
                "reopened TET4 references a missing mesh node"
            ) from error
        signed_volume = _signed_tet_volume(points)
        if not math.isfinite(signed_volume) or signed_volume <= 0.0:
            raise GeneratedMeshError(
                "reopened generated mesh contains a non-positive TET4 volume"
            )
        current = component_volumes[key]
        updated = current + signed_volume
        if abs(current) >= abs(signed_volume):
            component_volume_corrections[key] += (
                current - updated
            ) + signed_volume
        else:
            component_volume_corrections[key] += (
                signed_volume - updated
            ) + current
        component_volumes[key] = updated
        faces[key].update(_tet_faces(element.node_tags))
    for key, count in component_counts.items():
        if count == 0:
            raise GeneratedMeshError(f"reopened Component {key!r} is empty")
    for material, count in material_counts.items():
        if count == 0:
            raise GeneratedMeshError(f"reopened Material {material!r} is empty")
    boundaries: dict[GeneratedComponentKey, set[tuple[int, int, int]]] = {}
    for key, counter in faces.items():
        if any(value > 2 for value in counter.values()):
            raise GeneratedMeshError(
                f"reopened Component {key!r} has non-manifold TET faces"
            )
        boundaries[key] = {face for face, value in counter.items() if value == 1}
    audited_volumes = {
        key: component_volumes[key] + component_volume_corrections[key]
        for key in component_volumes
    }
    if any(
        not math.isfinite(value) or value <= 0.0
        for value in audited_volumes.values()
    ):
        raise GeneratedMeshError(
            "reopened Component TET4 volume evidence is invalid"
        )
    return boundaries, component_counts, material_counts, audited_volumes


def _numbered_mesh_sha256(mesh: VolumeMesh) -> str:
    payload = {
        "schema": "easymesh-package-v2-generated-tet4-numbered-v1",
        "dimensional_element_counts": list(mesh.dimensional_element_counts),
        "nodes": [
            [
                node.tag,
                0.0 if node.x == 0.0 else node.x,
                0.0 if node.y == 0.0 else node.y,
                0.0 if node.z == 0.0 else node.z,
            ]
            for node in mesh.nodes
        ],
        "elements": [
            [
                element.tag,
                element.kind.value,
                list(element.node_tags),
                sorted(element.physical_names),
            ]
            for element in mesh.elements
        ],
    }
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _reopen_gmsh_evidence(
    gmsh: Any,
    path: Path,
    *,
    expected_element_count: int,
) -> tuple[int, _QualityEvidence]:
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_package_v2_generated_reopen",
        number_options={"General.Terminal": 0.0},
    ):
        gmsh.merge(str(path))
        duplicate_count = len(tuple(gmsh.model.mesh.getDuplicateNodes()))
        _types, tag_blocks, _connectivity = gmsh.model.mesh.getElements(3)
        element_tags = [int(tag) for block in tag_blocks for tag in block]
        if len(element_tags) != expected_element_count:
            raise GeneratedMeshError(
                "reopened Gmsh element count differs from the parsed MSH"
            )
        if len(element_tags) != len(set(element_tags)):
            raise GeneratedMeshError(
                "reopened generated MSH contains duplicate element tags"
            )
        return duplicate_count, _quality_evidence(gmsh, element_tags)


def _same_quality(left: _QualityEvidence, right: _QualityEvidence) -> bool:
    metric_fields = (
        "min_jacobian_determinant",
        "min_scaled_jacobian",
        "min_sicn",
        "min_sige",
    )
    return all(
        math.isclose(
            getattr(left, field_name),
            getattr(right, field_name),
            rel_tol=1.0e-12,
            abs_tol=0.0,
        )
        for field_name in metric_fields
    ) and left.assessment == right.assessment


def _validate_reopened(
    gmsh: Any,
    path: Path,
    *,
    component_names: Mapping[GeneratedComponentKey, str],
    material_names: Mapping[str, str],
    expected_material_by_component: Mapping[GeneratedComponentKey, str],
    expected_component_volume_mm3: Mapping[GeneratedComponentKey, float],
    expected_interfaces: tuple[GeneratedInterfaceAudit, ...],
    expected_quality: _QualityEvidence,
) -> tuple[
    VolumeMesh,
    dict[GeneratedComponentKey, int],
    dict[str, int],
    dict[GeneratedComponentKey, float],
    str,
    _QualityEvidence,
]:
    mesh = load_volume_mesh(path)
    if mesh.dimensional_element_counts[:3] != (0, 0, 0):
        raise GeneratedMeshError(
            "reopened generated MSH contains independent 0-D/1-D/2-D elements"
        )
    duplicate_count, reopened_quality = _reopen_gmsh_evidence(
        gmsh,
        path,
        expected_element_count=len(mesh.elements),
    )
    if duplicate_count:
        raise GeneratedMeshError("reopened generated MSH contains duplicate nodes")
    if not _same_quality(reopened_quality, expected_quality):
        raise GeneratedMeshError(
            "reopened generated MSH quality differs from the written model"
        )
    component_by_name, material_by_name = _physical_membership_maps(
        component_names, material_names
    )
    (
        boundaries,
        component_counts,
        material_counts,
        component_volumes,
    ) = _boundary_faces_from_volume_mesh(
        mesh,
        component_by_name,
        material_by_name,
        expected_material_by_component,
    )
    if set(component_volumes) != set(expected_component_volume_mm3):
        raise GeneratedMeshError(
            "reopened Component volume evidence is incomplete"
        )
    for key, expected_volume in expected_component_volume_mm3.items():
        if not _mass_close(component_volumes[key], expected_volume):
            raise GeneratedMeshError(
                f"reopened TET4 volume differs from OCC mass for {key!r}"
            )
    expected_by_pair = {
        (value.first, value.second): value for value in expected_interfaces
    }
    actual_pairs: set[tuple[GeneratedComponentKey, GeneratedComponentKey]] = set()
    keys = tuple(sorted(boundaries))
    for first_index, first in enumerate(keys):
        for second in keys[first_index + 1 :]:
            faces = boundaries[first].intersection(boundaries[second])
            pair = (first, second)
            expected = expected_by_pair.get(pair)
            if expected is None:
                if faces:
                    raise GeneratedMeshError(
                        f"reopened MSH contains an unplanned interface {pair!r}"
                    )
                continue
            if (
                len(faces) != expected.triangle_face_count
                or _numbered_face_sha256(faces) != expected.numbered_face_sha256
            ):
                raise GeneratedMeshError(
                    f"reopened MSH interface {pair!r} differs from the written model"
                )
            actual_pairs.add(pair)
    if actual_pairs != set(expected_by_pair):
        raise GeneratedMeshError("reopened MSH is missing a generated interface")
    return (
        mesh,
        component_counts,
        material_counts,
        component_volumes,
        _numbered_mesh_sha256(mesh),
        reopened_quality,
    )


def build_generated_tet_mesh(
    geometries: Sequence[CanonicalGeneratedGeometry],
    output_path: str | Path,
    *,
    controls: GeneratedTetMeshControls,
    verbose: bool = False,
) -> GeneratedMeshSummary:
    """Build, atomically publish, reopen, and verify one generated TET4 mesh."""

    if type(controls) is not GeneratedTetMeshControls:
        raise GeneratedMeshError("controls must be GeneratedTetMeshControls")
    if not isinstance(verbose, bool):
        raise GeneratedMeshError("verbose must be boolean")
    components = _canonical_inputs(geometries)
    preflight_estimate = _generated_element_preflight_estimate(components, controls)
    if preflight_estimate > controls.maximum_element_count:
        raise GeneratedMeshError(
            "generated element preflight estimate exceeds the configured limit: "
            f"{preflight_estimate} > {controls.maximum_element_count}"
        )

    gmsh = _load_gmsh()
    output = normalized_mesh_output(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "General.NumThreads": 1.0,
        "Geometry.OCCBooleanPreserveNumbering": 1.0,
        "Mesh.MshFileVersion": 4.1,
        "Mesh.Binary": 0.0,
        "Mesh.SaveAll": 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm": 6.0,
        "Mesh.Algorithm3D": 1.0,
        "Mesh.RandomSeed": float(controls.random_seed),
        "Mesh.MaxNumThreads1D": 1.0,
        "Mesh.MaxNumThreads2D": 1.0,
        "Mesh.MaxNumThreads3D": 1.0,
        "Mesh.MeshSizeMin": controls.target_edge_mm,
        "Mesh.MeshSizeMax": controls.target_edge_mm,
        "Mesh.MeshSizeFromPoints": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.Optimize": 1.0 if controls.optimize else 0.0,
    }
    with exclusive_output_lock(output):
        with isolated_gmsh_model(
            gmsh,
            "__easymesh_package_v2_generated",
            number_options=options,
        ):
            try:
                ownership = _build_occ_ownership(gmsh, components)
            except GeneratedMeshError:
                raise
            except Exception as error:
                raise GeneratedMeshError(
                    "Gmsh could not construct the generated OCC geometry"
                ) from error
            component_names, material_names = _add_physical_groups(gmsh, ownership)
            try:
                gmsh.model.mesh.generate(3)
                if controls.optimize:
                    gmsh.model.mesh.optimize("", force=True, niter=2)
            except Exception as error:
                raise GeneratedMeshError(
                    "Gmsh could not generate the TET4 mesh"
                ) from error
            gmsh.model.mesh.renumberNodes()
            gmsh.model.mesh.renumberElements()
            (
                in_memory_component_counts,
                interfaces,
                duplicate_count,
                quality,
            ) = _audit_current_mesh(
                gmsh,
                ownership,
                maximum_element_count=controls.maximum_element_count,
            )

            with atomic_output_path(output) as temporary_mesh:
                gmsh.write(str(temporary_mesh))
                (
                    reopened,
                    component_counts,
                    material_counts,
                    reopened_component_volumes,
                    numbered_mesh_sha256,
                    reopened_quality,
                ) = _validate_reopened(
                    gmsh,
                    temporary_mesh,
                    component_names=component_names,
                    material_names=material_names,
                    expected_material_by_component=ownership.component_material,
                    expected_component_volume_mm3=ownership.component_volume_mm3,
                    expected_interfaces=interfaces,
                    expected_quality=quality,
                )
                if component_counts != in_memory_component_counts:
                    raise GeneratedMeshError(
                        "reopened Component element counts differ from the live model"
                    )
                artifact = file_artifact(temporary_mesh, published_path=output)

            node_count = len(reopened.nodes)
            tet_count = len(reopened.elements)
            return GeneratedMeshSummary(
                mesh_path=str(output),
                node_count=node_count,
                tet_count=tet_count,
                volume_count=len(ownership.volume_owner),
                component_volume_counts={
                    key: len(tags) for key, tags in ownership.component_volumes.items()
                },
                component_occ_volume_mm3=ownership.component_volume_mm3,
                component_reopened_tet_volume_mm3=reopened_component_volumes,
                component_element_counts=component_counts,
                material_element_counts=material_counts,
                component_physical_names=component_names,
                material_physical_names=material_names,
                interfaces=interfaces,
                duplicate_node_count=duplicate_count,
                min_jacobian_determinant=(
                    reopened_quality.min_jacobian_determinant
                ),
                min_scaled_jacobian=reopened_quality.min_scaled_jacobian,
                min_sicn=reopened_quality.min_sicn,
                min_sige=reopened_quality.min_sige,
                quality_classification=(
                    reopened_quality.assessment.classification
                ),
                quality_warnings=(
                    reopened_quality.assessment.quality_warnings
                ),
                quality_advisories=(
                    reopened_quality.assessment.quality_advisories
                ),
                numbered_mesh_sha256=numbered_mesh_sha256,
                mesh_artifact=artifact,
                written_mesh_reopened_verified=True,
            )


__all__ = [
    "GeneratedComponentKey",
    "GeneratedInterfaceAudit",
    "GeneratedMeshError",
    "GeneratedMeshSummary",
    "GeneratedTetMeshControls",
    "build_generated_tet_mesh",
]
