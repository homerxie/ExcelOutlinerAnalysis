"""Read and instantiate reusable first-order Gmsh volume-mesh samples.

The loader deliberately keeps the sample volume elements unchanged.  Its job is
to turn a Gmsh MSH 4.1 file into immutable, solver-independent data, identify
the skin of the *union* of all volume entities, and retain enough provenance to
extend each material laterally from that skin.

Only first-order HEX8 and WEDGE6 (Gmsh ``Prism 6``) volume elements are
accepted.  A sample may be very anisotropic; the only element-quality
requirement imposed here is a strictly positive Jacobian determinant.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Iterable, Mapping, Sequence

from .output_artifacts import exclusive_artifact_lock
from .volume_mesh import (
    ELEMENT_SPECS,
    ElementKind,
    MeshNode,
    PhysicalGroup,
    VolumeElement,
    VolumeMesh,
    VolumeMeshError,
    load_volume_mesh,
)


class SampleMeshError(ValueError):
    """Raised when a sample cannot be represented by the supported data model."""


@dataclass(frozen=True, slots=True)
class BoundaryFace:
    """An outward-oriented face on the skin of the complete volume union."""

    node_tags: tuple[int, ...]
    owner_element_tag: int
    owner_entity_tag: int
    physical_groups: tuple[PhysicalGroup, ...]

    @property
    def kind(self) -> str:
        return "TRI3" if len(self.node_tags) == 3 else "QUAD4"

    @property
    def physical_names(self) -> tuple[str, ...]:
        return tuple(group.name for group in self.physical_groups)


@dataclass(frozen=True, slots=True)
class OuterAdjacentEntity:
    """A volume entity adjacent to one outer-cylinder z interval."""

    entity_tag: int
    physical_groups: tuple[PhysicalGroup, ...]

    @property
    def physical_names(self) -> tuple[str, ...]:
        return tuple(group.name for group in self.physical_groups)


@dataclass(frozen=True, slots=True)
class OuterSurfaceInterval:
    """Outer lateral faces spanning one exact pair of source z levels."""

    z_min: float
    z_max: float
    adjacent_entities: tuple[OuterAdjacentEntity, ...]
    physical_names: tuple[str, ...]
    face_node_tags: tuple[tuple[int, ...], ...]


@dataclass(frozen=True, slots=True)
class OuterBoundary:
    """Description of the cylindrical/polygonal docking edge of a sample.

    ``relative_node_coordinates`` are ordered exactly like ``node_tags`` and
    are relative to ``center_xy``.  Keeping them in the loaded template avoids
    losing a bit through subtracting a large instance translation later.
    """

    center_xy: tuple[float, float]
    radius: float
    node_tags: tuple[int, ...]
    z_levels: tuple[float, ...]
    node_tags_by_z: tuple[tuple[float, tuple[int, ...]], ...]
    relative_node_coordinates: tuple[tuple[float, float, float], ...]
    surface_intervals: tuple[OuterSurfaceInterval, ...]
    declared_void_intervals: tuple[tuple[float, float], ...] = ()
    declared_air_gap_regions: tuple[tuple[float, float, float, float], ...] = ()

    @property
    def void_intervals(self) -> tuple[tuple[float, float], ...]:
        """Exact Z slabs where the declared outer cylinder has no solid sidewall.

        A normal solid template has one ``surface_intervals`` entry for every
        consecutive pair of ``z_levels``.  Air gaps deliberately have no
        volume element (and therefore no lateral face) in the corresponding
        pair.  Keeping the missing pair as geometry, instead of inventing an
        AIR material, lets layout generation leave that exterior slab empty.
        """

        occupied = {
            (interval.z_min, interval.z_max)
            for interval in self.surface_intervals
        }
        return tuple(
            (z_min, z_max)
            for z_min, z_max in zip(self.z_levels, self.z_levels[1:])
            if (z_min, z_max) not in occupied
            and any(
                gap_min <= z_min and z_max <= gap_max
                for gap_min, gap_max in self.declared_void_intervals
            )
        )

    @property
    def undeclared_missing_intervals(self) -> tuple[tuple[float, float], ...]:
        """Missing sidewall slabs not authorized by trusted air-gap metadata."""

        occupied = {
            (interval.z_min, interval.z_max)
            for interval in self.surface_intervals
        }
        declared = set(self.void_intervals)
        return tuple(
            interval
            for interval in zip(self.z_levels, self.z_levels[1:])
            if interval not in occupied and interval not in declared
        )


@dataclass(frozen=True, slots=True)
class SampleMesh:
    """Immutable reusable sample mesh extracted from one MSH 4.1 file."""

    source_path: Path
    nodes: tuple[MeshNode, ...]
    elements: tuple[VolumeElement, ...]
    boundary_faces: tuple[BoundaryFace, ...]
    entity_physical_groups: Mapping[int, tuple[PhysicalGroup, ...]]
    outer_boundary: OuterBoundary
    min_jacobian_determinant: float

    def node_map(self) -> dict[int, MeshNode]:
        """Return a mutable lookup assembled from the immutable node tuple."""

        return {node.tag: node for node in self.nodes}


@dataclass(frozen=True, slots=True)
class SampleMeshInstance:
    """An XY-translated and globally retagged copy of a sample mesh."""

    mesh: SampleMesh
    translation_xy: tuple[float, float]
    node_tag_map: Mapping[int, int]
    element_tag_map: Mapping[int, int]
    entity_tag_map: Mapping[int, int]

    @property
    def nodes(self) -> tuple[MeshNode, ...]:
        return self.mesh.nodes

    @property
    def elements(self) -> tuple[VolumeElement, ...]:
        return self.mesh.elements

    @property
    def boundary_faces(self) -> tuple[BoundaryFace, ...]:
        return self.mesh.boundary_faces

    @property
    def outer_boundary(self) -> OuterBoundary:
        return self.mesh.outer_boundary


def _average(points: Sequence[MeshNode]) -> tuple[float, float, float]:
    inverse = 1.0 / len(points)
    return (
        sum(point.x for point in points) * inverse,
        sum(point.y for point in points) * inverse,
        sum(point.z for point in points) * inverse,
    )


def _newell_normal(points: Sequence[MeshNode]) -> tuple[float, float, float]:
    nx = ny = nz = 0.0
    for left, right in zip(points, (*points[1:], points[0])):
        nx += (left.y - right.y) * (left.z + right.z)
        ny += (left.z - right.z) * (left.x + right.x)
        nz += (left.x - right.x) * (left.y + right.y)
    return (nx, ny, nz)


def _orient_face_outward(
    face_node_tags: tuple[int, ...],
    element: VolumeElement,
    nodes: Mapping[int, MeshNode],
) -> tuple[int, ...]:
    face_points = tuple(nodes[tag] for tag in face_node_tags)
    element_points = tuple(nodes[tag] for tag in element.node_tags)
    face_center = _average(face_points)
    element_center = _average(element_points)
    normal = _newell_normal(face_points)
    outward = tuple(face_center[index] - element_center[index] for index in range(3))
    dot = sum(normal[index] * outward[index] for index in range(3))
    normal_norm = math.sqrt(sum(value * value for value in normal))
    outward_norm = math.sqrt(sum(value * value for value in outward))
    if normal_norm == 0.0 or outward_norm == 0.0:
        raise SampleMeshError(
            f"element {element.tag} 包含退化或无法定向的边界面 {face_node_tags}"
        )
    # A very small dot relative to the two vector lengths means that the
    # proposed face does not geometrically bound this convex first-order cell.
    if abs(dot) <= normal_norm * outward_norm * 1.0e-12:
        raise SampleMeshError(
            f"element {element.tag} 的边界面法向不确定 {face_node_tags}"
        )
    return face_node_tags if dot > 0.0 else tuple(reversed(face_node_tags))


def _extract_boundary_faces(
    elements: Sequence[VolumeElement],
    nodes: Mapping[int, MeshNode],
) -> tuple[BoundaryFace, ...]:
    occurrences: dict[
        tuple[int, ...], list[tuple[VolumeElement, tuple[int, ...]]]
    ] = {}
    for element in elements:
        _, _, local_faces = ELEMENT_SPECS[element.gmsh_type]
        for local_face in local_faces:
            face = tuple(element.node_tags[index] for index in local_face)
            occurrences.setdefault(tuple(sorted(face)), []).append((element, face))

    non_manifold = [key for key, owners in occurrences.items() if len(owners) > 2]
    if non_manifold:
        raise SampleMeshError(
            "sample mesh 的体并集含非流形面（三个或更多体单元共享同一面）："
            f"{non_manifold[0]}"
        )

    boundary_faces: list[BoundaryFace] = []
    for key, owners in occurrences.items():
        if len(owners) != 1:
            continue
        element, face = owners[0]
        boundary_faces.append(
            BoundaryFace(
                node_tags=_orient_face_outward(face, element, nodes),
                owner_element_tag=element.tag,
                owner_entity_tag=element.entity_tag,
                physical_groups=element.physical_groups,
            )
        )
    boundary_faces.sort(
        key=lambda face: (
            face.owner_element_tag,
            len(face.node_tags),
            tuple(sorted(face.node_tags)),
        )
    )
    return tuple(boundary_faces)


@dataclass(frozen=True, slots=True)
class _OuterGeometryHint:
    """Axisymmetric sidecar geometry that cannot survive as volume elements."""

    z_levels: tuple[float, ...] = ()
    void_intervals: tuple[tuple[float, float], ...] = ()
    outer_radius: float | None = None
    air_gap_regions: tuple[tuple[float, float, float, float], ...] = ()


def _looks_like_air_gap_layer_text(layer_text: object) -> bool:
    if not isinstance(layer_text, str):
        return False
    for source_line in layer_text.splitlines():
        line = source_line.split("#", 1)[0].strip().lstrip("\ufeff")
        if not line:
            continue
        fields = [field.strip() for field in line.split(",")]
        if len(fields) >= 2 and fields[0] == "+" and not fields[1]:
            return True
    return False


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


_AXISYMMETRIC_PARAMETERS_SCHEMA = "easymesh.axisymmetric_mesh_parameters/v1"
_AXISYMMETRIC_POSITION_DECIMALS = 10


def _is_axisymmetric_parameter_payload(payload: object) -> bool:
    """Recognize only EasyMesh's namespaced axisymmetric parameter schema."""

    return (
        isinstance(payload, dict)
        and payload.get("schema") == _AXISYMMETRIC_PARAMETERS_SCHEMA
    )


def _axisymmetric_um_to_mm(value: object) -> float:
    """Match the 10-decimal micron coordinates written into the source MSH."""

    canonical_um = round(float(value), _AXISYMMETRIC_POSITION_DECIMALS)
    return 0.0 if canonical_um == 0.0 else canonical_um * 1.0e-3


def _validate_axisymmetric_sidecar_bundle(
    source_path: Path,
    parameter_payload: dict[str, object],
    report: dict[str, object],
) -> None:
    """Require one EasyMesh report to bind parameters to these exact MSH bytes."""

    report_path = source_path.with_suffix(".report.json")
    if report.get("parameters") != parameter_payload:
        raise SampleMeshError(
            f"EasyMesh report.parameters 与参数旁车不一致：{report_path}"
        )
    artifact = report.get("mesh_artifact")
    if not isinstance(artifact, dict):
        raise SampleMeshError(f"air-gap report 缺少 mesh_artifact：{report_path}")
    try:
        artifact_path = Path(str(artifact["path"])).expanduser().resolve()
    except KeyError as error:
        raise SampleMeshError(
            f"air-gap report.mesh_artifact 缺少 path：{report_path}"
        ) from error
    if artifact_path != source_path:
        raise SampleMeshError(
            "air-gap report.mesh_artifact.path 未绑定当前模板："
            f"{artifact_path} != {source_path}"
        )
    size_bytes = artifact.get("size_bytes")
    if (
        not isinstance(size_bytes, int)
        or isinstance(size_bytes, bool)
        or size_bytes != source_path.stat().st_size
    ):
        raise SampleMeshError(
            f"air-gap report.mesh_artifact.size_bytes 与当前模板不一致：{report_path}"
        )
    sha256 = artifact.get("sha256")
    if (
        not isinstance(sha256, str)
        or len(sha256) != 64
        or sha256.lower() != _sha256_file(source_path)
    ):
        raise SampleMeshError(
            f"air-gap report.mesh_artifact SHA-256 与当前模板不一致：{report_path}"
        )


def _load_outer_geometry_hint(source_path: Path) -> _OuterGeometryHint:
    """Recover declared outer air gaps from an axisymmetric parameter sidecar.

    Most voids are recoverable from a missing MSH lateral-face interval.  A
    terminal air gap has no node at its far elevation, however, so the existing
    ``<mesh>.parameters.json`` is the only lossless source for that level.  Old
    and third-party meshes remain geometry-only inputs: a sidecar is consulted
    only when its Layer text visibly contains the dedicated empty-name record.
    """

    parameter_path = source_path.with_suffix(".parameters.json")
    report_path = source_path.with_suffix(".report.json")

    parameter_payload: object = None
    parameter_error: Exception | None = None
    if parameter_path.is_file():
        try:
            parameter_payload = json.loads(
                parameter_path.read_text(encoding="utf-8")
            )
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            parameter_error = error

    report_payload: object = None
    report_error: Exception | None = None
    if report_path.is_file():
        try:
            report_payload = json.loads(report_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            report_error = error

    parameter_has_air_gap = (
        _is_axisymmetric_parameter_payload(parameter_payload)
        and _looks_like_air_gap_layer_text(parameter_payload.get("layer_text"))
    )
    reported_parameters = (
        report_payload.get("parameters")
        if isinstance(report_payload, dict)
        else None
    )
    report_has_air_gap = (
        _is_axisymmetric_parameter_payload(reported_parameters)
        and _looks_like_air_gap_layer_text(reported_parameters.get("layer_text"))
    )
    if not parameter_has_air_gap and not report_has_air_gap:
        # Ordinary/third-party templates remain geometry-only inputs.  Files
        # with unrelated JSON next to them are deliberately ignored.  Legacy
        # solid-only EasyMesh bundles predate artifact hashes and are likewise
        # safe to load because they cannot authorize a missing outer slab.
        return _OuterGeometryHint()

    if not parameter_path.is_file() or not report_path.is_file():
        raise SampleMeshError(
            "可识别的 EasyMesh 轴对称模板必须同时带有同名 "
            f"parameters.json 和 report.json：{source_path}"
        )
    if parameter_error is not None or not isinstance(parameter_payload, dict):
        raise SampleMeshError(
            f"EasyMesh 轴对称参数旁车不可读：{parameter_path}"
        ) from parameter_error
    if report_error is not None or not isinstance(report_payload, dict):
        raise SampleMeshError(
            f"EasyMesh 轴对称报告旁车不可读：{report_path}"
        ) from report_error
    _validate_axisymmetric_sidecar_bundle(
        source_path,
        parameter_payload,
        report_payload,
    )
    if not _looks_like_air_gap_layer_text(parameter_payload.get("layer_text")):
        return _OuterGeometryHint()

    # Import lazily: ordinary sample loading should not depend on Layer parsing,
    # and this also avoids a module-level dependency cycle.
    try:
        from .axisymmetric import AxisymmetricMeshParameters

        parameters = AxisymmetricMeshParameters.from_dict(parameter_payload)
        plan = parameters.section_plan
        # Layer footprints create radial breakpoints even when an instruction
        # is a no-op.  Such empty trailing columns must not hide a real gap at
        # the mesh docking radius, nor may they enlarge that radius by
        # themselves.  The outer construction column is therefore the
        # outermost column containing an actual solid or reserved-void span.
        outer_column = next(
            column
            for column in reversed(plan.columns)
            if column.spans or column.air_gaps
        )
        raw_gaps = tuple(getattr(outer_column, "air_gaps", ()))
        air_gap_regions = tuple(
            (
                _axisymmetric_um_to_mm(column.inner_radius_um),
                _axisymmetric_um_to_mm(column.outer_radius_um),
                _axisymmetric_um_to_mm(gap.z_bottom_um),
                _axisymmetric_um_to_mm(gap.z_top_um),
            )
            for column in plan.columns
            for gap in getattr(column, "air_gaps", ())
        )
        void_intervals = tuple(
            (
                _axisymmetric_um_to_mm(gap.z_bottom_um),
                _axisymmetric_um_to_mm(gap.z_top_um),
            )
            for gap in raw_gaps
        )
        z_levels = tuple(
            sorted(
                {
                    value
                    for interval in void_intervals
                    for value in interval
                }
            )
        )
    except (AttributeError, IndexError, TypeError, ValueError) as error:
        raise SampleMeshError(
            f"无法从 air-gap 参数旁车恢复模板外缘几何：{parameter_path}"
        ) from error
    if any(z_max <= z_min for z_min, z_max in void_intervals):
        raise SampleMeshError(f"air-gap 参数旁车包含无效外缘区间：{parameter_path}")
    return _OuterGeometryHint(
        z_levels=z_levels,
        void_intervals=void_intervals,
        outer_radius=(
            _axisymmetric_um_to_mm(outer_column.outer_radius_um)
            if raw_gaps
            else None
        ),
        air_gap_regions=air_gap_regions,
    )


def _extract_outer_boundary(
    boundary_faces: Sequence[BoundaryFace],
    nodes: Mapping[int, MeshNode],
    geometry_hint: _OuterGeometryHint = _OuterGeometryHint(),
) -> OuterBoundary:
    boundary_node_tags = sorted(
        {node_tag for face in boundary_faces for node_tag in face.node_tags}
    )
    if not boundary_node_tags:
        raise SampleMeshError("sample mesh 的体并集没有边界面")
    boundary_nodes = tuple(nodes[tag] for tag in boundary_node_tags)
    min_x = min(node.x for node in boundary_nodes)
    max_x = max(node.x for node in boundary_nodes)
    min_y = min(node.y for node in boundary_nodes)
    max_y = max(node.y for node in boundary_nodes)
    center_x = (min_x + max_x) * 0.5
    center_y = (min_y + max_y) * 0.5
    radii = {
        tag: math.hypot(nodes[tag].x - center_x, nodes[tag].y - center_y)
        for tag in boundary_node_tags
    }
    radius = max(radii.values())
    radial_tolerance = max(radius * 1.0e-8, (max_x - min_x + max_y - min_y) * 1.0e-12, 1.0e-12)
    if geometry_hint.outer_radius is not None and not math.isclose(
        radius,
        geometry_hint.outer_radius,
        rel_tol=1.0e-8,
        abs_tol=radial_tolerance,
    ):
        raise SampleMeshError(
            "air-gap 参数旁车声明的最大半径没有可复用的实体 docking ring："
            f"declared={geometry_hint.outer_radius:g} mm, mesh={radius:g} mm"
        )
    all_z = [nodes[tag].z for tag in boundary_node_tags]
    z_scale = max(max(all_z) - min(all_z), max(abs(value) for value in all_z), 1.0)
    z_tolerance = z_scale * 1.0e-12

    lateral_faces: list[BoundaryFace] = []
    for face in boundary_faces:
        face_z = tuple(nodes[tag].z for tag in face.node_tags)
        if max(face_z) - min(face_z) <= z_tolerance:
            continue
        if all(abs(radii[tag] - radius) <= radial_tolerance for tag in face.node_tags):
            lateral_faces.append(face)

    faces_by_interval: dict[tuple[float, float], list[BoundaryFace]] = {}
    for face in lateral_faces:
        z_values = tuple(nodes[tag].z for tag in face.node_tags)
        interval = (min(z_values), max(z_values))
        faces_by_interval.setdefault(interval, []).append(face)

    for gap_min, gap_max in geometry_hint.void_intervals:
        for solid_min, solid_max in faces_by_interval:
            if min(gap_max, solid_max) > max(gap_min, solid_min) + z_tolerance:
                raise SampleMeshError(
                    "air-gap 参数旁车与模板外缘实体侧壁重叠："
                    f"gap=({gap_min:g}, {gap_max:g}) mm, "
                    f"solid=({solid_min:g}, {solid_max:g}) mm"
                )

    outer_node_tags = tuple(
        sorted({tag for face in lateral_faces for tag in face.node_tags})
    )
    candidate_z_levels = {
        *(nodes[tag].z for tag in nodes),
        *geometry_hint.z_levels,
        *(value for interval in geometry_hint.void_intervals for value in interval),
    }
    # An unrelated interior material surface must not split one unsplit outer
    # QUAD4.  Levels inside a real outer face are therefore ignored; levels in
    # missing face intervals are retained as explicit void geometry.
    z_levels = tuple(
        sorted(
            z_level
            for z_level in candidate_z_levels
            if not any(
                z_min + z_tolerance < z_level < z_max - z_tolerance
                for z_min, z_max in faces_by_interval
            )
        )
    )
    node_tags_by_z = tuple(
        (
            z_level,
            tuple(tag for tag in outer_node_tags if nodes[tag].z == z_level),
        )
        for z_level in z_levels
    )
    relative_coordinates = tuple(
        (nodes[tag].x - center_x, nodes[tag].y - center_y, nodes[tag].z)
        for tag in outer_node_tags
    )

    intervals: list[OuterSurfaceInterval] = []
    for (z_min, z_max), faces in sorted(faces_by_interval.items()):
        adjacent_by_entity: dict[int, tuple[PhysicalGroup, ...]] = {}
        for face in faces:
            adjacent_by_entity[face.owner_entity_tag] = face.physical_groups
        adjacent_entities = tuple(
            OuterAdjacentEntity(entity_tag, groups)
            for entity_tag, groups in sorted(adjacent_by_entity.items())
        )
        physical_names = tuple(
            sorted(
                {
                    group.name
                    for groups in adjacent_by_entity.values()
                    for group in groups
                }
            )
        )
        intervals.append(
            OuterSurfaceInterval(
                z_min=z_min,
                z_max=z_max,
                adjacent_entities=adjacent_entities,
                physical_names=physical_names,
                face_node_tags=tuple(
                    face.node_tags
                    for face in sorted(
                        faces,
                        key=lambda item: (
                            item.owner_element_tag,
                            tuple(sorted(item.node_tags)),
                        ),
                    )
                ),
            )
        )
    outer_boundary = OuterBoundary(
        center_xy=(center_x, center_y),
        radius=radius,
        node_tags=outer_node_tags,
        z_levels=z_levels,
        node_tags_by_z=node_tags_by_z,
        relative_node_coordinates=relative_coordinates,
        surface_intervals=tuple(intervals),
        declared_void_intervals=geometry_hint.void_intervals,
        declared_air_gap_regions=geometry_hint.air_gap_regions,
    )
    if outer_boundary.undeclared_missing_intervals:
        raise SampleMeshError(
            "模板存在未由可信 air-gap 旁车声明的缺失外缘侧壁；"
            "可能存在内部裂缝"
        )
    return outer_boundary


def _sample_from_volume_mesh(
    volume_mesh: VolumeMesh,
    geometry_hint: _OuterGeometryHint = _OuterGeometryHint(),
) -> SampleMesh:
    # Keep the template representation free of unrelated/orphan source nodes,
    # matching the historical SampleMesh behavior.
    elements = volume_mesh.elements
    referenced_tags = {tag for element in elements for tag in element.node_tags}
    nodes = tuple(
        node for node in volume_mesh.nodes if node.tag in referenced_tags
    )
    node_lookup = {node.tag: node for node in nodes}
    boundary_faces = _extract_boundary_faces(elements, node_lookup)
    outer_boundary = _extract_outer_boundary(
        boundary_faces,
        node_lookup,
        geometry_hint,
    )
    return SampleMesh(
        source_path=volume_mesh.source_path,
        nodes=nodes,
        elements=elements,
        boundary_faces=boundary_faces,
        entity_physical_groups=volume_mesh.entity_physical_groups,
        outer_boundary=outer_boundary,
        min_jacobian_determinant=volume_mesh.min_jacobian_determinant,
    )


def load_sample_mesh(path: str | Path) -> SampleMesh:
    """Load one reusable Gmsh MSH 4.1 template through the Gmsh API.

    If Gmsh is already initialized, the function uses a temporary independent
    model and restores the caller's current model.  It therefore does not clear
    a model that a GUI or builder is currently assembling.
    """

    source_path = Path(path).expanduser().resolve()
    try:
        # Axisymmetric builders publish the MSH last under this same bundle
        # lock.  Holding it across both volume parsing and sidecar validation
        # prevents one layout read from combining two concurrently published
        # template generations.
        with exclusive_artifact_lock(source_path):
            volume_mesh = load_volume_mesh(source_path)
            return _sample_from_volume_mesh(
                volume_mesh,
                _load_outer_geometry_hint(volume_mesh.source_path),
            )
    except SampleMeshError:
        raise
    except VolumeMeshError as exc:
        raise SampleMeshError(str(exc)) from exc


def build_global_tag_map(tags: Iterable[int], start: int = 1) -> Mapping[int, int]:
    """Build a deterministic consecutive global-tag map."""

    if start < 1:
        raise ValueError("global tag start 必须大于等于 1")
    unique_tags = sorted({int(tag) for tag in tags})
    return MappingProxyType(
        {tag: start + index for index, tag in enumerate(unique_tags)}
    )


def instantiate_sample_mesh(
    template: SampleMesh,
    dx: float,
    dy: float,
    *,
    node_tag_start: int = 1,
    element_tag_start: int = 1,
    entity_tag_start: int | None = None,
) -> SampleMeshInstance:
    """Translate a template in XY and assign collision-free global tags.

    There is intentionally no ``dz`` argument.  Every source z coordinate and
    every outer component interval is copied bit-for-bit, which prevents an
    instance operation from changing component-surface heights.
    """

    dx = float(dx)
    dy = float(dy)
    if not math.isfinite(dx) or not math.isfinite(dy):
        raise ValueError("sample mesh XY 平移量必须是有限数")
    node_tag_map = build_global_tag_map(
        (node.tag for node in template.nodes), node_tag_start
    )
    element_tag_map = build_global_tag_map(
        (element.tag for element in template.elements), element_tag_start
    )
    entity_tags = tuple(template.entity_physical_groups)
    if entity_tag_start is None:
        entity_tag_map: Mapping[int, int] = MappingProxyType(
            {tag: tag for tag in sorted(entity_tags)}
        )
    else:
        entity_tag_map = build_global_tag_map(entity_tags, entity_tag_start)

    nodes = tuple(
        MeshNode(
            tag=node_tag_map[node.tag],
            x=node.x + dx,
            y=node.y + dy,
            # Copy, do not arithmetically translate, the source z value.
            z=node.z,
        )
        for node in template.nodes
    )
    elements = tuple(
        VolumeElement(
            tag=element_tag_map[element.tag],
            kind=element.kind,
            gmsh_type=element.gmsh_type,
            node_tags=tuple(node_tag_map[tag] for tag in element.node_tags),
            entity_tag=entity_tag_map[element.entity_tag],
            physical_groups=element.physical_groups,
            min_jacobian_determinant=element.min_jacobian_determinant,
        )
        for element in template.elements
    )
    boundary_faces = tuple(
        BoundaryFace(
            node_tags=tuple(node_tag_map[tag] for tag in face.node_tags),
            owner_element_tag=element_tag_map[face.owner_element_tag],
            owner_entity_tag=entity_tag_map[face.owner_entity_tag],
            physical_groups=face.physical_groups,
        )
        for face in template.boundary_faces
    )
    source_outer = template.outer_boundary
    outer_boundary = OuterBoundary(
        center_xy=(source_outer.center_xy[0] + dx, source_outer.center_xy[1] + dy),
        radius=source_outer.radius,
        node_tags=tuple(node_tag_map[tag] for tag in source_outer.node_tags),
        # Exact source values: component-surface heights cannot change.
        z_levels=source_outer.z_levels,
        node_tags_by_z=tuple(
            (
                z_level,
                tuple(node_tag_map[tag] for tag in tags),
            )
            for z_level, tags in source_outer.node_tags_by_z
        ),
        relative_node_coordinates=source_outer.relative_node_coordinates,
        surface_intervals=tuple(
            OuterSurfaceInterval(
                z_min=interval.z_min,
                z_max=interval.z_max,
                adjacent_entities=tuple(
                    OuterAdjacentEntity(
                        entity_tag=entity_tag_map[adjacent.entity_tag],
                        physical_groups=adjacent.physical_groups,
                    )
                    for adjacent in interval.adjacent_entities
                ),
                physical_names=interval.physical_names,
                face_node_tags=tuple(
                    tuple(node_tag_map[tag] for tag in face)
                    for face in interval.face_node_tags
                ),
            )
            for interval in source_outer.surface_intervals
        ),
        declared_void_intervals=source_outer.declared_void_intervals,
        declared_air_gap_regions=source_outer.declared_air_gap_regions,
    )
    entity_physical_groups = MappingProxyType(
        {
            entity_tag_map[tag]: groups
            for tag, groups in template.entity_physical_groups.items()
        }
    )
    instance_mesh = SampleMesh(
        source_path=template.source_path,
        nodes=nodes,
        elements=elements,
        boundary_faces=boundary_faces,
        entity_physical_groups=entity_physical_groups,
        outer_boundary=outer_boundary,
        min_jacobian_determinant=template.min_jacobian_determinant,
    )
    return SampleMeshInstance(
        mesh=instance_mesh,
        translation_xy=(dx, dy),
        node_tag_map=node_tag_map,
        element_tag_map=element_tag_map,
        entity_tag_map=entity_tag_map,
    )


def outer_node_coordinate_signature(
    mesh: SampleMesh | SampleMeshInstance,
    *,
    ndigits: int | None = None,
) -> tuple[tuple[float, float, float], ...]:
    """Return a translation-invariant outer-edge coordinate signature.

    By default comparison is exact, including every z level.  ``ndigits`` is an
    explicit opt-in tolerance for templates produced by different CAD paths.
    """

    outer = mesh.outer_boundary
    coordinates = outer.relative_node_coordinates
    if ndigits is not None:
        coordinates = tuple(
            tuple(round(value, ndigits) for value in coordinate)  # type: ignore[misc]
            for coordinate in coordinates
        )
    return tuple(sorted(coordinates))


def edge_component_stack_signature(
    mesh: SampleMesh | SampleMeshInstance,
    *,
    ndigits: int | None = None,
) -> tuple[tuple[float, float, tuple[str, ...]], ...]:
    """Return the z-interval/material signature of the outer lateral surface."""

    signature: list[tuple[float, float, tuple[str, ...]]] = []
    for interval in mesh.outer_boundary.surface_intervals:
        z_min = interval.z_min
        z_max = interval.z_max
        if ndigits is not None:
            z_min = round(z_min, ndigits)
            z_max = round(z_max, ndigits)
        signature.append((z_min, z_max, interval.physical_names))
    return tuple(signature)


def outer_ring_xy_signatures(
    mesh: SampleMesh | SampleMeshInstance,
    *,
    ndigits: int | None = None,
) -> tuple[tuple[float, tuple[tuple[float, float], ...]], ...]:
    """Return the relative XY ring pattern at every exact outer z level.

    The z values are never rounded: component-surface heights are an exact
    compatibility constraint.  ``ndigits`` applies only to the relative XY
    coordinates and is an explicit opt-in tolerance for geometry written by
    different CAD paths.
    """

    outer = mesh.outer_boundary
    if len(outer.node_tags) != len(outer.relative_node_coordinates):
        raise SampleMeshError("外缘 node tags 与相对坐标数量不一致")
    relative_by_tag = {
        tag: coordinate
        for tag, coordinate in zip(
            outer.node_tags, outer.relative_node_coordinates
        )
    }
    if tuple(z for z, _ in outer.node_tags_by_z) != outer.z_levels:
        raise SampleMeshError("外缘 node_tags_by_z 与 z_levels 不一致")

    signatures: list[tuple[float, tuple[tuple[float, float], ...]]] = []
    seen_tags: set[int] = set()
    for z_level, tags in outer.node_tags_by_z:
        # A declared air-gap level can legitimately have no volume node at the
        # outer radius (notably the far end of a terminal gap).  Preserve the
        # empty signature; adjacent solid slabs still provide their exact ring.
        xy_coordinates: list[tuple[float, float]] = []
        for tag in tags:
            if tag in seen_tags:
                raise SampleMeshError(f"外缘节点 {tag} 出现在多个 z levels")
            seen_tags.add(tag)
            try:
                relative_x, relative_y, node_z = relative_by_tag[tag]
            except KeyError as exc:
                raise SampleMeshError(
                    f"外缘 z={z_level:g} 引用了未知节点 {tag}"
                ) from exc
            if node_z != z_level:
                raise SampleMeshError(
                    f"外缘节点 {tag} 的 z={node_z:g} 与 ring level {z_level:g} 不一致"
                )
            if ndigits is not None:
                relative_x = round(relative_x, ndigits)
                relative_y = round(relative_y, ndigits)
            xy_coordinates.append((relative_x, relative_y))
        signatures.append((z_level, tuple(sorted(xy_coordinates))))
    if seen_tags != set(outer.node_tags):
        raise SampleMeshError("部分外缘节点未归入任何 z-level XY ring")
    return tuple(signatures)


def _validate_constant_ring_pattern(
    mesh: SampleMesh | SampleMeshInstance,
    *,
    ndigits: int | None,
) -> None:
    signatures = outer_ring_xy_signatures(mesh, ndigits=ndigits)
    if not signatures:
        raise SampleMeshError("模板没有可识别的外圆柱 XY rings")
    populated = tuple((z, pattern) for z, pattern in signatures if pattern)
    if not populated:
        raise SampleMeshError("模板没有可识别的非空外圆柱 XY ring")
    reference_pattern = populated[0][1]
    for z_level, pattern in populated[1:]:
        if pattern != reference_pattern:
            raise SampleMeshError(
                "同一 sample mesh 各 component surface 的外缘 XY ring pattern "
                f"必须恒定；z={z_level:g} 与首层不同"
            )


def validate_compatible_outer_boundaries(
    meshes: Sequence[SampleMesh | SampleMeshInstance],
    *,
    ndigits: int | None = None,
    require_identical_node_pattern: bool = False,
    require_identical_radius: bool = True,
) -> None:
    """Validate docking geometry and component stacks across sample meshes.

    This is intended for validating the high/medium/low sample library before
    layout generation.  Different templates may use different circumferential
    resolutions (for example 32/40/64 nodes). By default they must have the
    same radius, exact z levels, and physical-material stack, while
    every template must independently repeat its own XY ring pattern at every
    z level. Set ``require_identical_radius=False`` for layouts that intentionally
    mix template diameters. Set ``require_identical_node_pattern=True`` only when
    all templates are expected to share identical circumferential nodes.
    """

    if not meshes:
        raise ValueError("至少需要一个 sample mesh 才能验证外缘兼容性")
    first = meshes[0]
    if not first.outer_boundary.surface_intervals:
        source_path = (
            first.mesh.source_path
            if isinstance(first, SampleMeshInstance)
            else first.source_path
        )
        raise SampleMeshError(f"模板没有可识别的外圆柱侧面：{source_path}")
    if first.outer_boundary.undeclared_missing_intervals:
        raise SampleMeshError(
            "模板存在未由可信 air-gap 旁车声明的缺失外缘侧壁；"
            "可能存在内部裂缝"
        )
    _validate_constant_ring_pattern(first, ndigits=ndigits)
    coordinate_signature = outer_node_coordinate_signature(first, ndigits=ndigits)
    component_signature = edge_component_stack_signature(first, ndigits=ndigits)
    z_levels = first.outer_boundary.z_levels
    radius = first.outer_boundary.radius
    for mesh in meshes[1:]:
        if not mesh.outer_boundary.surface_intervals:
            raise SampleMeshError("模板没有可识别的外圆柱侧面")
        if mesh.outer_boundary.undeclared_missing_intervals:
            raise SampleMeshError(
                "模板存在未由可信 air-gap 旁车声明的缺失外缘侧壁；"
                "可能存在内部裂缝"
            )
        _validate_constant_ring_pattern(mesh, ndigits=ndigits)
        candidate_radius = mesh.outer_boundary.radius
        radii_match = (
            round(candidate_radius, ndigits) == round(radius, ndigits)
            if ndigits is not None
            else math.isclose(
                candidate_radius,
                radius,
                rel_tol=1.0e-12,
                abs_tol=1.0e-14,
            )
        )
        if require_identical_radius and not radii_match:
            raise SampleMeshError("sample mesh 外缘 radius 不一致")
        if mesh.outer_boundary.z_levels != z_levels:
            raise SampleMeshError("sample mesh 外缘 component surface 的 z levels 不一致")
        if (
            require_identical_node_pattern
            and outer_node_coordinate_signature(mesh, ndigits=ndigits)
            != coordinate_signature
        ):
            raise SampleMeshError("sample mesh 外缘节点坐标 signature 不一致")
        if edge_component_stack_signature(mesh, ndigits=ndigits) != component_signature:
            raise SampleMeshError("sample mesh 外缘 material/component stack 不一致")


__all__ = [
    "BoundaryFace",
    "ElementKind",
    "MeshNode",
    "OuterAdjacentEntity",
    "OuterBoundary",
    "OuterSurfaceInterval",
    "PhysicalGroup",
    "SampleMesh",
    "SampleMeshError",
    "SampleMeshInstance",
    "VolumeElement",
    "build_global_tag_map",
    "edge_component_stack_signature",
    "instantiate_sample_mesh",
    "load_sample_mesh",
    "outer_node_coordinate_signature",
    "outer_ring_xy_signatures",
    "validate_compatible_outer_boundaries",
]
