"""Shared line styles for section and XY material/mesh previews."""

from PySide6.QtGui import QColor, QPen


def mesh_pen():
    color = QColor("#111827")
    color.setAlpha(105)
    pen = QPen(color, .75)
    pen.setCosmetic(True)
    return pen


def component_pen():
    color = QColor("#111827")
    color.setAlpha(225)
    pen = QPen(color, 1.6)
    pen.setCosmetic(True)
    return pen
