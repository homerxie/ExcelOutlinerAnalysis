"""Interpret Gmsh's signed element-quality metrics.

``minSICN`` is sensitive to both distortion and anisotropic aspect ratio. A
low value on its own therefore does not mean that an otherwise orthogonal
thin-film mesh is malformed. ``minSJ`` and ``minSIGE`` are used here to
separate that advisory case from a shape-distortion warning.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Literal


QUALITY_WARNING_THRESHOLD = 0.30
QualityClassification = Literal[
    "acceptable",
    "aspect_ratio",
    "distortion",
    "invalid",
]


@dataclass(frozen=True, slots=True)
class QualityAssessment:
    """Classification and user-facing messages for three signed metrics."""

    classification: QualityClassification
    quality_warnings: tuple[str, ...]
    quality_advisories: tuple[str, ...]
    invalid_metrics: tuple[str, ...]

    @property
    def is_valid(self) -> bool:
        return self.classification != "invalid"


def classify_mesh_quality(
    min_scaled_jacobian: float,
    min_sicn: float,
    min_sige: float,
    *,
    threshold: float = QUALITY_WARNING_THRESHOLD,
) -> QualityAssessment:
    """Classify quality without treating aspect ratio alone as distortion."""

    if not math.isfinite(threshold) or threshold <= 0.0:
        raise ValueError("quality threshold must be a positive finite number")

    metrics = {
        "minSJ": float(min_scaled_jacobian),
        "minSICN": float(min_sicn),
        "minSIGE": float(min_sige),
    }
    invalid_metrics = tuple(
        name
        for name, value in metrics.items()
        if not math.isfinite(value) or value <= 0.0
    )
    rendered = (
        f"minSJ={metrics['minSJ']:.3f}，"
        f"minSICN={metrics['minSICN']:.3f}，"
        f"minSIGE={metrics['minSIGE']:.3f}"
    )
    if invalid_metrics:
        return QualityAssessment(
            classification="invalid",
            quality_warnings=(
                "网格包含倒置、退化或无法评估的单元："
                f"{rendered}；有符号质量指标必须全部大于 0。",
            ),
            quality_advisories=(),
            invalid_metrics=invalid_metrics,
        )

    if metrics["minSJ"] < threshold or metrics["minSIGE"] < threshold:
        return QualityAssessment(
            classification="distortion",
            quality_warnings=(
                "存在明显形状扭曲的单元："
                f"{rendered}（警告阈值 {threshold:.2f}）；"
                "建议检查局部网格尺寸和相邻区间的尺寸过渡。",
            ),
            quality_advisories=(),
            invalid_metrics=(),
        )

    if metrics["minSICN"] < threshold:
        return QualityAssessment(
            classification="aspect_ratio",
            quality_warnings=(),
            quality_advisories=(
                "质量指标更可能由单元高长宽比主导："
                f"{rendered}（minSICN 低于 {threshold:.2f}，"
                "但 minSJ/minSIGE 保持良好）；"
                "minSICN 不是纯长宽比指标，仍可能同时受到剪切或扭曲影响。"
                "若短方向沿薄层或主要场梯度方向、长方向上的场变化缓慢，"
                "这种各向异性可能可以接受，建议通过网格收敛验证确认。",
            ),
            invalid_metrics=(),
        )

    return QualityAssessment(
        classification="acceptable",
        quality_warnings=(),
        quality_advisories=(),
        invalid_metrics=(),
    )


__all__ = [
    "QUALITY_WARNING_THRESHOLD",
    "QualityAssessment",
    "QualityClassification",
    "classify_mesh_quality",
]
