"""Gmsh-owned two-dimensional shell for a rectangular UF envelope.

This module creates no three-dimensional mesh connectivity.  OpenCASCADE
constructs one analytic (or complete locked-annulus-authoritative) UF slice,
Gmsh meshes
its complete boundary, and explicitly locked TRI3/QUAD4 patches replace the
corresponding generated surface meshes verbatim.  The returned shell is a
geometry-and-facet contract suitable for combining its boundary with docking
facets before a separate closed-shell volume fill.

The implementation is deliberately component-role neutral.  Locked patches
are identified only by geometric side names: ``base``, ``cap``,
``die_x_min``, ``die_x_max``, ``die_y_min`` and ``die_y_max``.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from statistics import median
from types import MappingProxyType
from typing import Any, TypeAlias

from .gmsh_runtime import isolated_gmsh_model
from .occ_locked_hybrid import (
    ConstrainedHybridError,
    _all_nodes,
    _coordinate_key,
    _face_key,
    _finite,
    _load_gmsh,
    _surface_shell_is_watertight,
)
from .occ_uf_conformal import (
    _COORDINATE_TOLERANCE_MM,
    _OCC_TOLERANCE_MM,
    _PreparedInput,
    _PreparedRuledCorrespondence,
    _add_geometry_authority_uf_slice,
    _add_locked_patch_surface,
    _facet_area,
    _install_locked_curves,
    _locked_base_maximum_outside_distance,
    _on_die_wall,
    _prepare_inputs,
    _prepare_ruled_correspondence,
    _replace_locked_surfaces,
    _slice_radius,
    PlanarAnnulusRuledCorrespondence,
)
from .uf_skin import RectangularUfEnvelope


Point3D: TypeAlias = tuple[float, float, float]
FaceKey: TypeAlias = tuple[int, ...]

_TRI3 = 2
_QUAD4 = 3
_SURFACE_TYPES = {_TRI3: (3, "TRI3"), _QUAD4: (4, "QUAD4")}
_SIDE_ORDER = (
    "base",
    "cap",
    "die_x_min",
    "die_x_max",
    "die_y_min",
    "die_y_max",
    "outer_free",
)


@dataclass(frozen=True, slots=True)
class GmshUfSurfaceShell:
    """Audited first-order 2D boundary of one UF slice."""

    node_coordinates: Mapping[int, Point3D]
    source_node_id_by_local_id: Mapping[int, int]
    boundary_facets: tuple[tuple[int, ...], ...]
    locked_facets_by_side: Mapping[str, tuple[tuple[int, ...], ...]]
    free_facets: tuple[tuple[int, ...], ...]
    facets_by_geometric_side: Mapping[str, tuple[tuple[int, ...], ...]]
    triangle_count: int
    quad_count: int
    locked_triangle_count: int
    locked_quad_count: int
    free_triangle_count: int
    free_quad_count: int
    target_size_mm: float
    near_size_mm: float
    transition_distance_mm: float
    background_field_kind: str
    geometry_authority: str
    cad_surface_area_mm2: float
    analytic_surface_area_mm2: float
    mesh_surface_area_mm2: float
    mesh_to_cad_area_relative_error: float
    cad_to_analytic_area_relative_error: float
    watertight: bool
    consistently_oriented: bool
    boundary_edge_count: int
    bad_edge_count: int
    removed_duplicate_node_count: int
    duplicate_node_count: int
    duplicate_facet_count: int
    volume_element_count: int

    def __post_init__(self) -> None:
        for field_name in (
            "node_coordinates",
            "source_node_id_by_local_id",
            "locked_facets_by_side",
            "facets_by_geometric_side",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, Mapping):
                raise ConstrainedHybridError(
                    f"UF surface shell {field_name} must be a mapping"
                )
            object.__setattr__(self, field_name, MappingProxyType(dict(value)))
        if self.watertight is not True or self.consistently_oriented is not True:
            raise ConstrainedHybridError("UF surface shell must be closed and oriented")
        if (
            self.bad_edge_count
            or self.duplicate_node_count
            or self.duplicate_facet_count
            or self.volume_element_count
        ):
            raise ConstrainedHybridError(
                "UF surface shell audit contains duplicate, open or 3D evidence"
            )

    @property
    def node_count(self) -> int:
        return len(self.node_coordinates)

    @property
    def facet_count(self) -> int:
        return len(self.boundary_facets)

    @property
    def locked_facet_count(self) -> int:
        return self.locked_triangle_count + self.locked_quad_count

    @property
    def free_facet_count(self) -> int:
        return self.free_triangle_count + self.free_quad_count


def _edge_key(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def _validate_sizes(
    prepared: _PreparedInput,
    target_size_mm: float,
    transition_distance_mm: float,
    near_size_mm: float | None,
) -> tuple[float, float, float]:
    target_size = _finite(target_size_mm, name="UF shell target size")
    transition_distance = _finite(
        transition_distance_mm,
        name="UF shell transition distance",
    )
    if near_size_mm is None:
        locked_edges = tuple(
            math.dist(
                prepared.coordinates[first],
                prepared.coordinates[second],
            )
            for patch in prepared.patches
            for facet in patch.facets
            for first, second in zip(facet, (*facet[1:], facet[0]))
        )
        near_size = (
            min(target_size, median(locked_edges))
            if locked_edges
            else target_size
        )
    else:
        near_size = _finite(near_size_mm, name="UF shell near size")
    if (
        target_size <= 0.0
        or near_size <= 0.0
        or near_size > target_size
        or transition_distance <= 0.0
    ):
        raise ConstrainedHybridError(
            "UF shell sizes and transition distance must be positive, with "
            "near_size <= target_size"
        )
    return target_size, near_size, transition_distance


def _build_occ_boundary(
    gmsh: Any,
    prepared: _PreparedInput,
    correspondence: _PreparedRuledCorrespondence | None,
    force_partial_locked_sides: Sequence[str],
    contact_partition_loops=(),
    swept_root=None,
) -> tuple[int, dict[int, int], str]:
    if swept_root is None:
        volume_tag, _analytic_volume, geometry_authority = _add_geometry_authority_uf_slice(
            gmsh, prepared, correspondence, force_partial_locked_sides=force_partial_locked_sides)
    else:
        from .package_v2_swept_fillet import occ_add
        volume_tag, = occ_add(gmsh, swept_root)
        geometry_authority = "elliptical_cross_section_sweep"
    patch_surfaces = tuple(
        _add_locked_patch_surface(gmsh, prepared, patch)
        for patch in prepared.patches
    )
    surface_by_patch: dict[int, int] = {}
    from .gmsh_planar_contact_partition import add_occ_contact_surfaces
    contact_surfaces = add_occ_contact_surfaces(gmsh, contact_partition_loops)
    if not patch_surfaces and not contact_surfaces:
        gmsh.model.occ.synchronize()
        return volume_tag, surface_by_patch, geometry_authority

    _outputs, maps = gmsh.model.occ.fragment(
        [(3, volume_tag)],
        [(2, surface) for surface in (*patch_surfaces, *contact_surfaces)],
        removeObject=True,
        removeTool=True,
    )
    gmsh.model.occ.synchronize()
    volumes = tuple(int(tag) for dimension, tag in gmsh.model.getEntities(3))
    if len(volumes) != 1:
        raise ConstrainedHybridError(
            "locked boundary imprints split the UF shell geometry"
        )
    volume_tag = volumes[0]
    boundary_surfaces = {
        int(tag)
        for dimension, tag in gmsh.model.getBoundary(
            [(3, volume_tag)],
            oriented=False,
            recursive=False,
        )
        if int(dimension) == 2
    }
    detached = {
        int(tag)
        for dimension, tag in gmsh.model.getEntities(2)
        if int(dimension) == 2 and int(tag) not in boundary_surfaces
    }
    if detached:
        gmsh.model.occ.remove(
            [(2, tag) for tag in sorted(detached)],
            recursive=True,
        )
        gmsh.model.occ.synchronize()
    if len(maps) != 1 + len(prepared.patches) + len(contact_surfaces):
        raise ConstrainedHybridError("OCC returned inconsistent UF shell maps")
    for patch_index, (patch, mapping) in enumerate(
        zip(prepared.patches, maps[1:])
    ):
        mapped = {
            int(tag)
            for dimension, tag in mapping
            if int(dimension) == 2 and int(tag) in boundary_surfaces
        }
        if len(mapped) != 1:
            raise ConstrainedHybridError(
                f"locked UF shell side {patch.side} component "
                f"{patch.component_index} did not map to one surface"
            )
        surface_by_patch[patch_index] = mapped.pop()
    if surface_by_patch:
        _install_locked_curves(gmsh, prepared, surface_by_patch)
    return volume_tag, surface_by_patch, geometry_authority


def _configure_background_field(
    gmsh: Any,
    surface_by_patch: Mapping[int, int],
    *,
    target_size: float,
    near_size: float,
    transition_distance: float,
) -> str:
    if surface_by_patch and near_size < target_size:
        distance = int(gmsh.model.mesh.field.add("Distance"))
        gmsh.model.mesh.field.setNumbers(
            distance,
            "SurfacesList",
            list(surface_by_patch.values()),
        )
        threshold = int(gmsh.model.mesh.field.add("Threshold"))
        for name, value in (
            ("InField", distance),
            ("SizeMin", near_size),
            ("SizeMax", target_size),
            ("DistMin", 0.0),
            ("DistMax", transition_distance),
        ):
            gmsh.model.mesh.field.setNumber(threshold, name, value)
        gmsh.model.mesh.field.setAsBackgroundMesh(threshold)
        return "Distance+Threshold"
    field = int(gmsh.model.mesh.field.add("MathEval"))
    gmsh.model.mesh.field.setString(field, "F", f"{target_size:.17g}")
    gmsh.model.mesh.field.setAsBackgroundMesh(field)
    return "MathEvalConstant"


def _raw_surface_records(
    gmsh: Any,
    surfaces: Sequence[int],
) -> tuple[tuple[int, int, tuple[int, ...]], ...]:
    records: list[tuple[int, int, tuple[int, ...]]] = []
    for surface in surfaces:
        types, tag_blocks, connectivity_blocks = gmsh.model.mesh.getElements(
            2,
            surface,
        )
        for raw_type, raw_tags, raw_connectivity in zip(
            types,
            tag_blocks,
            connectivity_blocks,
        ):
            gmsh_type = int(raw_type)
            spec = _SURFACE_TYPES.get(gmsh_type)
            if spec is None:
                raise ConstrainedHybridError(
                    f"UF shell contains unsupported surface type {gmsh_type}"
                )
            node_count, _name = spec
            connectivity = tuple(int(node) for node in raw_connectivity)
            if len(connectivity) != node_count * len(raw_tags):
                raise ConstrainedHybridError(
                    "UF shell surface connectivity is inconsistent"
                )
            for index, raw_tag in enumerate(raw_tags):
                start = index * node_count
                records.append(
                    (
                        gmsh_type,
                        int(raw_tag),
                        connectivity[start : start + node_count],
                    )
                )
    if not records:
        raise ConstrainedHybridError("Gmsh produced an empty UF surface shell")
    return tuple(records)


def _analytic_surface_area(prepared: _PreparedInput) -> float:
    envelope = prepared.envelope
    height = prepared.z_max - prepared.z_min
    bottom_radius = _slice_radius(envelope, prepared.z_min)
    top_radius = max(0.0, _slice_radius(envelope, prepared.z_max))
    perimeter = 2.0 * (envelope.die_width + envelope.die_length)
    base_area = perimeter * bottom_radius + math.pi * bottom_radius**2
    cap_area = perimeter * top_radius + math.pi * top_radius**2
    die_area = perimeter * height
    slope = envelope.fillet_width / envelope.height
    outer_area = math.sqrt(1.0 + slope * slope) * (
        perimeter * height
        + math.pi * height * (bottom_radius + top_radius)
    )
    return base_area + cap_area + die_area + outer_area


def _classify_geometric_side(
    facet: Sequence[int],
    coordinates: Mapping[int, Point3D],
    prepared: _PreparedInput,
) -> str:
    tolerance = _OCC_TOLERANCE_MM
    if all(
        abs(coordinates[node][2] - prepared.z_min) <= tolerance
        for node in facet
    ):
        return "base"
    if all(
        abs(coordinates[node][2] - prepared.z_max) <= tolerance
        for node in facet
    ):
        return "cap"
    envelope = prepared.envelope
    points = tuple(coordinates[node] for node in facet)
    x_min = envelope.center_x - envelope.half_die_width
    x_max = envelope.center_x + envelope.half_die_width
    y_min = envelope.center_y - envelope.half_die_length
    y_max = envelope.center_y + envelope.half_die_length
    for side, axis, value, tangent_axis, tangent_bounds in (
        ("die_x_min", 0, x_min, 1, (y_min, y_max)),
        ("die_x_max", 0, x_max, 1, (y_min, y_max)),
        ("die_y_min", 1, y_min, 0, (x_min, x_max)),
        ("die_y_max", 1, y_max, 0, (x_min, x_max)),
    ):
        if all(
            abs(point[axis] - value) <= tolerance
            and tangent_bounds[0] - tolerance
            <= point[tangent_axis]
            <= tangent_bounds[1] + tolerance
            and prepared.z_min - tolerance
            <= point[2]
            <= prepared.z_max + tolerance
            for point in points
        ):
            return side
    if _on_die_wall(facet, coordinates, envelope):  # pragma: no cover
        raise ConstrainedHybridError("UF die-wall facet side is ambiguous")
    return "outer_free"


def _edge_audit(
    facets: Sequence[Sequence[int]],
) -> tuple[int, int, bool]:
    undirected: Counter[tuple[int, int]] = Counter()
    directed: Counter[tuple[int, int]] = Counter()
    for facet in facets:
        for first, second in zip(facet, (*facet[1:], facet[0])):
            undirected[_edge_key(first, second)] += 1
            directed[first, second] += 1
    bad = sum(count != 2 for count in undirected.values())
    oriented = bad == 0 and all(
        directed[first, second] == 1 and directed[second, first] == 1
        for first, second in undirected
    )
    return len(undirected), bad, oriented


def _finalize_shell(
    gmsh: Any,
    prepared: _PreparedInput,
    volume_tag: int,
    geometry_authority: str,
    background_field_kind: str,
    *,
    target_size: float,
    near_size: float,
    transition_distance: float,
    removed_duplicate_node_count: int,
    swept_root=None,
) -> GmshUfSurfaceShell:
    volume_types, volume_tags, _volume_connectivity = gmsh.model.mesh.getElements(
        3,
        volume_tag,
    )
    volume_element_count = sum(len(tags) for tags in volume_tags)
    if len(volume_types) or volume_element_count:
        raise ConstrainedHybridError(
            "UF surface shell generator created forbidden 3D connectivity"
        )
    boundary_surfaces = tuple(
        sorted(
            int(tag)
            for dimension, tag in gmsh.model.getBoundary(
                [(3, volume_tag)],
                oriented=False,
                recursive=False,
            )
            if int(dimension) == 2
        )
    )
    records = _raw_surface_records(gmsh, boundary_surfaces)
    gmsh_coordinates = _all_nodes(gmsh)
    used_gmsh_nodes = {node for _type, _tag, nodes in records for node in nodes}
    if not used_gmsh_nodes:
        raise ConstrainedHybridError("UF surface shell has no referenced nodes")
    coordinate_owner: dict[tuple[float, float, float], int] = {}
    for gmsh_tag in used_gmsh_nodes:
        key = _coordinate_key(gmsh_coordinates[gmsh_tag])
        if key in coordinate_owner:
            raise ConstrainedHybridError("UF surface shell has coincident nodes")
        coordinate_owner[key] = gmsh_tag

    gmsh_source_by_tag: dict[int, int] = {}
    for source_id, point in prepared.coordinates.items():
        gmsh_tag = coordinate_owner.get(_coordinate_key(point))
        if gmsh_tag is None or math.dist(gmsh_coordinates[gmsh_tag], point) > (
            _COORDINATE_TOLERANCE_MM
        ):
            raise ConstrainedHybridError("Gmsh changed a locked UF shell node")
        gmsh_source_by_tag[gmsh_tag] = source_id
    ordered_gmsh = tuple(
        sorted(
            used_gmsh_nodes,
            key=lambda tag: (_coordinate_key(gmsh_coordinates[tag]), tag),
        )
    )
    local_by_gmsh = {
        gmsh_tag: local_id
        for local_id, gmsh_tag in enumerate(ordered_gmsh, start=1)
    }
    coordinates = {
        local_by_gmsh[tag]: gmsh_coordinates[tag] for tag in ordered_gmsh
    }
    source_by_local = {
        local_by_gmsh[gmsh_tag]: source_id
        for gmsh_tag, source_id in gmsh_source_by_tag.items()
    }
    # The locked contract is authoritative.  Gmsh/OCC can round a decimal by
    # one binary ulp even when the geometric point is unchanged; expose the
    # caller's exact coordinate tuple for every retained source node.
    for local_id, source_id in source_by_local.items():
        coordinates[local_id] = prepared.coordinates[source_id]

    boundary_by_key: dict[FaceKey, tuple[int, ...]] = {}
    kind_by_key: dict[FaceKey, str] = {}
    for gmsh_type, _element_tag, gmsh_nodes in records:
        cycle = tuple(local_by_gmsh[node] for node in gmsh_nodes)
        key = _face_key(cycle)
        if key in boundary_by_key:
            raise ConstrainedHybridError("UF surface shell has duplicate facets")
        boundary_by_key[key] = cycle
        kind_by_key[key] = _SURFACE_TYPES[gmsh_type][1]

    local_by_source = {source: local for local, source in source_by_local.items()}
    locked_by_side_lists: dict[str, list[tuple[int, ...]]] = {}
    locked_keys: set[FaceKey] = set()
    for patch in prepared.patches:
        mapped = tuple(
            tuple(local_by_source[node] for node in facet)
            for facet in patch.facets
        )
        keys = {_face_key(facet) for facet in mapped}
        if len(keys) != len(mapped) or not keys.issubset(boundary_by_key):
            raise ConstrainedHybridError(
                f"Gmsh changed the locked UF shell {patch.side} facets"
            )
        if locked_keys.intersection(keys):
            raise ConstrainedHybridError("locked UF shell facets overlap")
        locked_keys.update(keys)
        locked_by_side_lists.setdefault(patch.side, []).extend(mapped)
    locked_by_side = {
        side: tuple(facets) for side, facets in locked_by_side_lists.items()
    }

    free_keys = set(boundary_by_key).difference(locked_keys)
    side_keys: dict[str, set[FaceKey]] = {side: set() for side in _SIDE_ORDER}
    for key, facet in boundary_by_key.items():
        side_keys[_classify_geometric_side(facet, coordinates, prepared)].add(key)
    if set().union(*side_keys.values()) != set(boundary_by_key):
        raise ConstrainedHybridError("UF surface shell classification is incomplete")
    for patch in prepared.patches:
        patch_keys = {
            _face_key(facet) for facet in locked_by_side[patch.side]
        }
        if not patch_keys.issubset(side_keys[patch.side]):
            raise ConstrainedHybridError(
                f"locked UF shell {patch.side} escaped its geometric side"
            )
    authoritative_sides = {
        "locked_base_annulus_to_analytic_cap": "base",
        "locked_base_annulus_to_zero_width_apex": "base",
        "locked_cap_annulus_to_analytic_base": "cap",
        "locked_base_and_cap_annuli_with_verified_ruled_correspondence": (
            "base",
            "cap",
        ),
    }.get(geometry_authority, ())
    if isinstance(authoritative_sides, str):
        authoritative_sides = (authoritative_sides,)
    for authoritative_side in authoritative_sides:
        authoritative_keys = {
            _face_key(facet)
            for facet in locked_by_side[authoritative_side]
        }
        if side_keys[authoritative_side] != authoritative_keys:
            raise ConstrainedHybridError(
                f"locked UF shell {authoritative_side} authority acquired "
                "additional boundary facets"
            )
    # This bound belongs to the immutable prepared base, not to each free
    # node. Recomputing it rebuilt and traversed the same annulus thousands
    # of times. Keep lazy evaluation so empty/free-of-die cases retain their
    # original validation behavior.
    locked_base_maximum_distance: float | None = None
    for key in side_keys["outer_free"]:
        for node in boundary_by_key[key]:
            x_value, y_value, z_value = coordinates[node]
            top_height = prepared.envelope.top_height(x_value, y_value)
            if swept_root is not None:
                from .package_v2_swept_fillet import on_outer_surface
                valid = on_outer_surface(swept_root, coordinates[node], 5.0 * _OCC_TOLERANCE_MM)
            elif geometry_authority.startswith("analytic_envelope"):
                valid = abs(z_value - top_height) <= 5.0 * _OCC_TOLERANCE_MM
            elif geometry_authority in {
                "locked_cap_annulus_to_analytic_base",
                "locked_base_and_cap_annuli_with_verified_ruled_correspondence",
            }:
                valid = (
                    prepared.envelope.is_outside_die(x_value, y_value)
                    and prepared.envelope.outside_distance(x_value, y_value)
                    <= _slice_radius(prepared.envelope, prepared.z_min)
                    + 5.0 * _OCC_TOLERANCE_MM
                    and prepared.z_min - 5.0 * _OCC_TOLERANCE_MM
                    <= z_value
                    <= prepared.z_max + 5.0 * _OCC_TOLERANCE_MM
                )
            elif geometry_authority in {
                "locked_base_annulus_to_analytic_cap",
                "locked_base_annulus_to_zero_width_apex",
            }:
                outside_die = prepared.envelope.is_outside_die(x_value, y_value)
                if outside_die and locked_base_maximum_distance is None:
                    locked_base_maximum_distance = _locked_base_maximum_outside_distance(prepared)
                valid = (
                    outside_die
                    and prepared.envelope.outside_distance(x_value, y_value)
                    <= locked_base_maximum_distance
                    + 5.0 * _OCC_TOLERANCE_MM
                    and prepared.z_min - 5.0 * _OCC_TOLERANCE_MM
                    <= z_value
                    <= prepared.z_max + 5.0 * _OCC_TOLERANCE_MM
                )
            else:  # pragma: no cover - geometry-authority dispatch is exhaustive
                valid = (
                    prepared.envelope.contains_xy(x_value, y_value)
                    and z_value <= top_height + 5.0 * _OCC_TOLERANCE_MM
                )
            if not valid:
                raise ConstrainedHybridError(
                    "Gmsh UF shell free-surface node escaped the negotiated "
                    "geometry authority"
                )

    ordered_keys = tuple(sorted(boundary_by_key))
    boundary_facets = tuple(boundary_by_key[key] for key in ordered_keys)
    free_facets = tuple(boundary_by_key[key] for key in sorted(free_keys))
    edge_count, bad_edges, oriented = _edge_audit(boundary_facets)
    if bad_edges or not oriented:
        raise ConstrainedHybridError(
            "UF surface shell is not a consistently oriented closed shell"
        )
    _surface_shell_is_watertight(gmsh)

    cad_area = math.fsum(
        float(gmsh.model.occ.getMass(2, surface))
        for surface in boundary_surfaces
    )
    mesh_area = math.fsum(
        _facet_area(facet, coordinates) for facet in boundary_facets
    )
    if swept_root is None:
        analytic_area = _analytic_surface_area(prepared)
    else:
        from .package_v2_swept_fillet import surface_area
        analytic_area = surface_area(swept_root)
    if any(
        not math.isfinite(value) or value <= 0.0
        for value in (cad_area, mesh_area, analytic_area)
    ):
        raise ConstrainedHybridError("UF surface shell area evidence is invalid")

    triangle_count = sum(len(facet) == 3 for facet in boundary_facets)
    quad_count = sum(len(facet) == 4 for facet in boundary_facets)
    locked_triangle_count = sum(
        len(facet) == 3
        for facets in locked_by_side.values()
        for facet in facets
    )
    locked_quad_count = sum(
        len(facet) == 4
        for facets in locked_by_side.values()
        for facet in facets
    )
    free_triangle_count = sum(len(facet) == 3 for facet in free_facets)
    free_quad_count = sum(len(facet) == 4 for facet in free_facets)
    if (
        triangle_count + quad_count != len(boundary_facets)
        or locked_triangle_count + locked_quad_count != len(locked_keys)
        or free_triangle_count + free_quad_count != len(free_facets)
        or len(locked_keys) + len(free_keys) != len(boundary_facets)
    ):
        raise ConstrainedHybridError("UF surface shell facet counts are inconsistent")

    duplicate_nodes = len(tuple(gmsh.model.mesh.getDuplicateNodes()))
    duplicate_facets = len(boundary_facets) - len(boundary_by_key)
    return GmshUfSurfaceShell(
        node_coordinates=MappingProxyType(coordinates),
        source_node_id_by_local_id=MappingProxyType(source_by_local),
        boundary_facets=boundary_facets,
        locked_facets_by_side=MappingProxyType(locked_by_side),
        free_facets=free_facets,
        facets_by_geometric_side=MappingProxyType(
            {
                side: tuple(boundary_by_key[key] for key in sorted(side_keys[side]))
                for side in _SIDE_ORDER
            }
        ),
        triangle_count=triangle_count,
        quad_count=quad_count,
        locked_triangle_count=locked_triangle_count,
        locked_quad_count=locked_quad_count,
        free_triangle_count=free_triangle_count,
        free_quad_count=free_quad_count,
        target_size_mm=target_size,
        near_size_mm=near_size,
        transition_distance_mm=transition_distance,
        background_field_kind=background_field_kind,
        geometry_authority=geometry_authority,
        cad_surface_area_mm2=cad_area,
        analytic_surface_area_mm2=analytic_area,
        mesh_surface_area_mm2=mesh_area,
        mesh_to_cad_area_relative_error=abs(mesh_area - cad_area) / cad_area,
        cad_to_analytic_area_relative_error=(
            abs(cad_area - analytic_area) / analytic_area
        ),
        watertight=True,
        consistently_oriented=oriented,
        boundary_edge_count=edge_count,
        bad_edge_count=bad_edges,
        removed_duplicate_node_count=removed_duplicate_node_count,
        duplicate_node_count=duplicate_nodes,
        duplicate_facet_count=duplicate_facets,
        volume_element_count=volume_element_count,
    )


def generate_rectangular_uf_surface_shell(
    locked_node_coordinates: Mapping[int, Sequence[float]],
    locked_boundary_facets: Mapping[str, Sequence[Sequence[int]]],
    envelope: RectangularUfEnvelope,
    z_min_mm: float,
    z_max_mm: float,
    *,
    target_size_mm: float,
    transition_distance_mm: float,
    near_size_mm: float | None = None,
    two_boundary_correspondence: PlanarAnnulusRuledCorrespondence | None = None,
    force_partial_locked_sides: Sequence[str] = (),
    contact_partition_loops=(),
    swept_root=None,
    verbose: bool = False,
) -> GmshUfSurfaceShell:
    """Generate an exact, locked-patch-preserving UF boundary shell.

    Only Gmsh 1D/2D meshing is invoked.  The OCC volume exists solely to define
    one unambiguous closed boundary and is audited to contain zero volume
    elements before the result is returned.  A complete planar locked base or
    cap annulus can define that boundary; partial patches remain imprints on
    the analytic envelope.  If both endpoint annuli are complete, an explicit
    ``two_boundary_correspondence`` must prove their ruled outer and inner
    strips without altering either endpoint mesh.

    When ``swept_root`` is supplied, its four-side elliptical sweep defines
    the CAD and analytic area. The envelope only prepares planar locks.
    """

    if not isinstance(verbose, bool):
        raise ConstrainedHybridError("UF shell verbose flag must be boolean")
    try:
        forced_partial = tuple(force_partial_locked_sides)
    except TypeError as error:
        raise ConstrainedHybridError(
            "force_partial_locked_sides must be a sequence"
        ) from error
    if (
        len(set(forced_partial)) != len(forced_partial)
        or any(side not in {"base", "cap"} for side in forced_partial)
    ):
        raise ConstrainedHybridError(
            "force_partial_locked_sides may contain base and cap once each"
        )
    prepared = _prepare_inputs(
        locked_node_coordinates,
        locked_boundary_facets,
        envelope,
        z_min_mm,
        z_max_mm,
    )
    locked_planar_sides = {patch.side for patch in prepared.patches}
    missing_forced = set(forced_partial).difference(locked_planar_sides)
    if missing_forced:
        raise ConstrainedHybridError(
            "force_partial_locked_sides references a side without a locked patch"
        )
    prepared_correspondence = _prepare_ruled_correspondence(
        prepared,
        two_boundary_correspondence,
    )
    target_size, near_size, transition_distance = _validate_sizes(
        prepared,
        target_size_mm,
        transition_distance_mm,
        near_size_mm,
    )
    options = {
        "General.Terminal": 1.0 if verbose else 0.0,
        "Mesh.ElementOrder": 1.0,
        "Mesh.Algorithm": 5.0,
        "Mesh.MeshOnlyEmpty": 1.0,
        "Mesh.MeshSizeMin": near_size,
        "Mesh.MeshSizeMax": target_size,
        "Mesh.MeshSizeExtendFromBoundary": 0.0,
        "Mesh.MeshSizeFromCurvature": 0.0,
        "Mesh.MeshSizeFromPoints": 0.0,
    }
    gmsh = _load_gmsh()
    with isolated_gmsh_model(
        gmsh,
        "__easymesh_occ_uf_surface_shell",
        number_options=options,
    ):
        try:
            volume_tag, surface_by_patch, geometry_authority = _build_occ_boundary(
                gmsh,
                prepared,
                prepared_correspondence,
                forced_partial,
                contact_partition_loops,
                swept_root,
            )
            background_field_kind = _configure_background_field(
                gmsh,
                surface_by_patch,
                target_size=target_size,
                near_size=near_size,
                transition_distance=transition_distance,
            )
            gmsh.model.mesh.generate(2)
            if surface_by_patch:
                _replace_locked_surfaces(gmsh, prepared, surface_by_patch)
            duplicates = tuple(gmsh.model.mesh.getDuplicateNodes())
            if duplicates:
                # A ruled authority shell can contain coincident generated CAD
                # classifications where projected outer points collapse onto
                # one point on the opposite analytic boundary.  They are not
                # caller nodes (duplicate locked coordinates were rejected in
                # preparation).
                # Let Gmsh canonicalize its own 2D connectivity, then expose
                # both the cleanup count and the mandatory zero final count.
                gmsh.model.mesh.removeDuplicateNodes()
            return _finalize_shell(
                gmsh,
                prepared,
                volume_tag,
                geometry_authority,
                background_field_kind,
                target_size=target_size,
                near_size=near_size,
                transition_distance=transition_distance,
                removed_duplicate_node_count=len(duplicates),
                swept_root=swept_root,
            )
        except ConstrainedHybridError:
            raise
        except Exception as error:  # pragma: no cover - Gmsh runtime failure
            raise ConstrainedHybridError(
                "Gmsh could not generate the rectangular UF surface shell"
            ) from error


__all__ = [
    "GmshUfSurfaceShell",
    "generate_rectangular_uf_surface_shell",
]
