"""Bind actual surface authorities to jointly planned Orth components."""

from dataclasses import replace

from .package_v2_geometry import CanonicalRectangularUnderfillFillet
from .package_v2_orthogonal_domain_planning import (
    OrthogonalInput,
    OrthogonalQuad,
    OrthogonalConstraintError,
    plan_orthogonal_domain,
    key,
)
from .package_v2_orthogonal_domain_materializer import materialize_orthogonal_domain


def execution_groups(context, plan):
    orth = {
        c
        for c, r in context.lowering.component_mesh_requirements.items()
        if r.volume_topology == "orthogonal_hex"
    }
    neighbors = {c: set() for c in orth}
    for authority in plan.authority_plan.authorities:
        a, b = authority.producer_component_id, authority.consumer_component_id
        if a in orth and b in orth:
            neighbors[a].add(b)
            neighbors[b].add(a)
    groups = {}
    while orth:
        group = set()
        todo = [min(orth)]
        while todo:
            c = todo.pop()
            if c in group:
                continue
            group.add(c)
            todo.extend(neighbors[c] - group)
        orth -= group
        # Existing pure Fillet stacks already share their complete candidate
        # endpoint decomposition. Keep that proven adapter and its diagnostics.
        fragments = [
            f
            for c in group
            for f in context.lowering.canonical_components_by_global_id[c].fragments
        ]
        pure_fillet = all(
            isinstance(f.root, CanonicalRectangularUnderfillFillet) for f in fragments
        )
        single_per_component = all(
            len(context.lowering.canonical_components_by_global_id[c].fragments) == 1
            for c in group
        )
        cap_stack = all(
            a.producer_side_name in {"z_min", "z_max"}
            and a.consumer_side_name in {"z_min", "z_max"}
            and all(v.covers_complete_side for v in a.side_coverages)
            for a in plan.authority_plan.authorities
            if a.producer_component_id in group and a.consumer_component_id in group
        )
        external_count = sum(
            a.consumer_component_id in group and a.producer_component_id not in group
            for a in plan.authority_plan.authorities
        )
        external_count += sum(
            interface.generated_component_global_id in group
            for interface in context.frozen_patches_by_interface
        )
        if pure_fillet and single_per_component and cap_stack and external_count <= 1:
            continue
        ordered = tuple(c for c in plan.component_order if c in group)
        groups.update({c: ordered for c in group})
    return groups


def incoming_external(plan, group):
    members = set(group)
    return tuple(
        a.face_pair_id
        for a in plan.authority_plan.authorities
        if a.consumer_component_id in members and a.producer_component_id not in members
    )


def materialize_group(context, execution_plan, group, patches, *, verbose=False):
    from .package_v2_mixed_source_executor import _partial_contact_boundary_loops
    from .package_v2_mixed_mesh_assembly import frozen_node_semantic_token

    lowering = context.lowering
    members = set(group)
    inputs = []
    locks = []
    contact = []
    tokens = {}
    for c in group:
        component = lowering.canonical_components_by_global_id[c]
        control = lowering.component_mesh_controls_by_global_id[c]
        for fragment in component.fragments:
            inputs.append(
                OrthogonalInput(
                    c,
                    fragment,
                    component.material_name,
                    control.mesh_priority,
                    control.target_edge_mm,
                    control.strategy,
                )
            )
            contact.extend(
                (fragment.fragment_id, loop)
                for loop in _partial_contact_boundary_loops(
                    context, execution_plan, c, fragment
                )
            )
    for pair, patch in patches.items():
        if (
            patch.consumer_side.component_id in members
            and patch.producer_side.component_id not in members
        ):
            target = patch.consumer_side.fragment_id
        elif (
            patch.producer_side.component_id in members
            and patch.consumer_side.component_id not in members
        ):
            # An already published outgoing face in a surface-level dependency
            # cycle is now immutable too; the final group must reproduce it.
            target = patch.producer_side.fragment_id
        else:
            continue
        for face in patch.facets:
            locks.append(
                OrthogonalQuad(
                    patch.producer_side.component_id,
                    target,
                    pair,
                    tuple(patch.node_coordinates_package_mm[n] for n in face),
                    tuple(patch.semantic_tokens_by_node_id[n] for n in face),
                )
            )
    for interface, values in context.frozen_patches_by_interface.items():
        if interface.generated_component_global_id not in members:
            continue
        for patch in values:
            for face in patch.facets:
                ids = face.source_node_tags
                locks.append(
                    OrthogonalQuad(
                        interface.frozen_component_global_id,
                        patch.target_fragment_id,
                        str(interface),
                        tuple(patch.node_coordinates[n] for n in ids),
                        tuple(frozen_node_semantic_token(n) for n in ids),
                    )
                )
    fragment_ids = {v.fragment.fragment_id for v in inputs}
    for edge in context.mesh_ordering.shared_edge_authorities:
        if edge.fragment_id not in fragment_ids:
            continue
        for point, token in zip(edge.partition_points_package_mm, edge.semantic_tokens):
            tokens[(edge.fragment_id, key(point))] = token
    planned = plan_orthogonal_domain(inputs, locked_quads=locks, contact_points=contact)
    return materialize_orthogonal_domain(planned, extra_tokens=tokens, verbose=verbose)


def publish_group(context, plan, components):
    """Retoken once at authority edges, propagating the identity to the group."""
    from .package_v2_mixed_source_executor import _retoken_outgoing_surfaces

    aliases = {}
    for c, component in components.items():
        authorities = tuple(
            plan.authority_plan.authority_by_face_pair_id[f]
            for f in plan.outgoing_face_pair_ids_by_component[c]
        )
        updated, _ = _retoken_outgoing_surfaces(
            context,
            component,
            context.lowering.canonical_components_by_global_id[c],
            authorities,
        )
        for fid, fragment in updated.fragments_by_id.items():
            original = {
                n.local_node_id: n.semantic_token
                for n in component.fragments_by_id[fid].nodes
            }
            for node in fragment.nodes:
                old = original[node.local_node_id]
                if old is not None and node.semantic_token != old:
                    aliases[old] = node.semantic_token
    output = {}
    patches = []
    for c, component in components.items():
        fragments = {
            fid: replace(
                f,
                nodes=tuple(
                    replace(
                        n,
                        semantic_token=aliases.get(n.semantic_token, n.semantic_token),
                    )
                    for n in f.nodes
                ),
            )
            for fid, f in component.fragments_by_id.items()
        }
        component = replace(component, fragments_by_id=fragments)
        authorities = tuple(
            plan.authority_plan.authority_by_face_pair_id[f]
            for f in plan.outgoing_face_pair_ids_by_component[c]
        )
        updated, produced = _retoken_outgoing_surfaces(
            context,
            component,
            context.lowering.canonical_components_by_global_id[c],
            authorities,
        )
        output[c] = updated
        patches.extend(produced)
    return output, tuple(patches)


def store_patch(patches, patch):
    previous = patches.get(patch.face_pair_id)
    if previous is not None:

        def signature(p):
            return {
                frozenset(
                    (p.semantic_tokens_by_node_id[n], p.node_coordinates_package_mm[n])
                    for n in f
                )
                for f in p.facets
            }

        if signature(previous) != signature(patch):
            raise OrthogonalConstraintError(
                "orth_locked_interface_conflict",
                "最终 Orth 计划改变了已提供给相邻组件的固定接口。",
                components=(patch.producer_side.component_id,),
                sources=(
                    {
                        "component_id": patch.consumer_side.component_id,
                        "interface_id": patch.face_pair_id,
                    },
                ),
            )
    patches[patch.face_pair_id] = patch
