"""Neutral generated-only adapter for the role-free mixed executor.

This module contains no package role, material meaning, stack position or
underfill routing.  It only gives source-local generated identities a
collision-safe global namespace, derives real common-face contracts from the
canonical solids and invokes the same executor used by mixed Frozen/generated
Sources.  The resulting fragments are assembled, serialized and reopened by
the common mixed-mesh audit path.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from pathlib import Path
from types import MappingProxyType
from typing import Mapping, Sequence

from .component_interface import (
    ComponentMeshRequirement,
    negotiate_component_interface,
)
from .generated_interface_continuity import (
    plan_generated_interface_continuity,
    resolve_package_frame_sweep_directions,
)
from .package_assembly import GeneratedComponentMeshControl
from .package_v2_adjacency_execution import (
    plan_component_adjacency_execution,
)
from .package_v2_component_adjacency import extract_component_adjacencies
from .package_v2_geometry import (
    CanonicalBox,
    CanonicalUnion,
    CanonicalDifference,
    CanonicalComponentGeometry,
    CanonicalGeneratedGeometry,
    CanonicalGeometryFragment,
    CanonicalRectangularFrameExtrusion,
    CanonicalRectangularUnderfillFillet,
    audit_canonical_geometry,
)
from .package_v2_mesher import GeneratedComponentKey
from .package_v2_mesh_ordering import plan_mesh_ordering
from .package_v2_mesh_settings import (
    DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM,
    validate_interface_geometry_tolerance_mm,
)
from .package_v2_mixed_execution_context import MixedExecutionContext
from .package_v2_mixed_mesh_assembly import (
    MixedMeshWriteResult,
    write_mixed_volume_mesh,
)
from .package_v2_mixed_mesh_audit import (
    MixedMeshReopenAudit,
    audit_reopened_mixed_volume_mesh,
)
from .package_v2_mixed_source_executor import (
    MixedSourceExecutionResult,
    execute_role_free_mixed_source,
)
from .package_v2_mixed_source_lowering import (
    GeneratedLocalComponentKey,
    GeneratedLocalFragmentKey,
    MixedSourceLowering,
)


class GeneratedRoleFreeMeshError(RuntimeError):
    """Generated-only inputs cannot satisfy the common executor contract."""


@dataclass(frozen=True, slots=True)
class GeneratedRoleFreeMeshRun:
    context: MixedExecutionContext
    execution: MixedSourceExecutionResult
    write_result: MixedMeshWriteResult
    reopen_audit: MixedMeshReopenAudit
    key_by_global_component_id: Mapping[str, GeneratedComponentKey]
    global_component_id_by_key: Mapping[GeneratedComponentKey, str]
    canonical_fragment_count_by_key: Mapping[GeneratedComponentKey, int]
    analytic_target_volume_mm3_by_key: Mapping[GeneratedComponentKey, float]

    def __post_init__(self) -> None:
        for field_name in (
            "key_by_global_component_id",
            "global_component_id_by_key",
            "canonical_fragment_count_by_key",
            "analytic_target_volume_mm3_by_key",
        ):
            object.__setattr__(
                self,
                field_name,
                MappingProxyType(dict(getattr(self, field_name))),
            )


def _global_identifier(
    prefix: str,
    instance_id: str,
    local_id: str,
) -> str:
    digest = hashlib.sha256(
        f"{prefix}\0{instance_id}\0{local_id}".encode("utf-8")
    ).hexdigest()[:16]
    return f"{prefix}_{digest}_{local_id}"


def _fragment_analytic_volume_mm3(fragment: CanonicalGeometryFragment) -> float:
    root = fragment.root
    if type(root) is CanonicalBox:
        value = math.prod(root.size_xyz_mm)
    elif type(root) is CanonicalRectangularFrameExtrusion:
        outer_area = math.prod(root.outer_size_xy_mm)
        opening_area = math.prod(root.opening_size_xy_mm)
        value = (outer_area - opening_area) * root.height_mm
    elif type(root) is CanonicalRectangularUnderfillFillet:
        if root.uses_elliptical_sweep:
            from .package_v2_swept_fillet import volume
            return volume(root)
        die_x, die_y = root.die_size_xy_mm
        toe = root.toe_width_mm
        top = root.top_width_mm
        height = root.wall_height_mm
        value = height * (
            (die_x + die_y) * (toe + top)
            + math.pi * (toe * toe + toe * top + top * top) / 3.0
        )
    elif type(root) in {CanonicalUnion, CanonicalDifference}:
        from .package_v2_orthogonal_domain_planning import root_boxes

        value = math.fsum(math.prod(b - a for a, b in box) for box in root_boxes(root))
    else:
        raise GeneratedRoleFreeMeshError(
            "generated role-free execution supports rectilinear CSG, Box, Frame and "
            "RectangularUnderfillFillet roots"
        )
    if not math.isfinite(value) or value <= 0.0:
        raise GeneratedRoleFreeMeshError(
            "canonical fragment has a non-positive analytic target volume"
        )
    return value


def _build_context(
    geometries: Sequence[CanonicalGeneratedGeometry],
    mesh_controls: Mapping[GeneratedComponentKey, GeneratedComponentMeshControl],
    interface_geometry_tolerance_mm: float,
) -> tuple[
    MixedExecutionContext,
    Mapping[str, GeneratedComponentKey],
    Mapping[GeneratedComponentKey, str],
    Mapping[GeneratedComponentKey, int],
    Mapping[GeneratedComponentKey, float],
]:
    try:
        tolerance = validate_interface_geometry_tolerance_mm(
            interface_geometry_tolerance_mm
        )
    except ValueError as error:
        raise GeneratedRoleFreeMeshError(str(error)) from error
    if isinstance(geometries, (str, bytes)):
        raise GeneratedRoleFreeMeshError("geometries must be a sequence")
    try:
        values = tuple(geometries)
    except TypeError as error:
        raise GeneratedRoleFreeMeshError("geometries must be a sequence") from error
    if not values or any(
        type(value) is not CanonicalGeneratedGeometry for value in values
    ):
        raise GeneratedRoleFreeMeshError(
            "geometries must contain CanonicalGeneratedGeometry values"
        )
    if not isinstance(mesh_controls, Mapping):
        raise GeneratedRoleFreeMeshError("mesh_controls must be a mapping")
    instance_ids = tuple(value.instance_id for value in values)
    if len(instance_ids) != len(set(instance_ids)):
        raise GeneratedRoleFreeMeshError(
            "generated instance identifiers must be unique"
        )

    local_components: dict[
        GeneratedLocalComponentKey, CanonicalComponentGeometry
    ] = {}
    global_components: dict[str, CanonicalComponentGeometry] = {}
    global_component_id_by_local: dict[GeneratedLocalComponentKey, str] = {}
    local_fragments: dict[
        GeneratedLocalFragmentKey, CanonicalGeometryFragment
    ] = {}
    global_fragments: dict[str, CanonicalGeometryFragment] = {}
    global_fragment_id_by_local: dict[GeneratedLocalFragmentKey, str] = {}
    key_by_global_component_id: dict[str, GeneratedComponentKey] = {}
    global_component_id_by_key: dict[GeneratedComponentKey, str] = {}
    fragment_count_by_key: dict[GeneratedComponentKey, int] = {}
    analytic_volume_by_key: dict[GeneratedComponentKey, float] = {}

    expected_keys: set[GeneratedComponentKey] = set()
    for geometry in values:
        audit_canonical_geometry(geometry)
        for component in geometry.components:
            key = GeneratedComponentKey(
                geometry.instance_id,
                component.component_id,
            )
            if key in expected_keys:
                raise GeneratedRoleFreeMeshError(
                    "generated Component identities are not unique"
                )
            expected_keys.add(key)
            local_component_key = GeneratedLocalComponentKey(
                geometry.instance_id,
                component.component_id,
            )
            global_component_id = _global_identifier(
                "component",
                geometry.instance_id,
                component.component_id,
            )
            global_component_fragments: list[CanonicalGeometryFragment] = []
            analytic_values: list[float] = []
            for fragment in component.fragments:
                if type(fragment.root) not in {
                    CanonicalBox,
                    CanonicalUnion,
                    CanonicalDifference,
                    CanonicalRectangularFrameExtrusion,
                    CanonicalRectangularUnderfillFillet,
                }:
                    raise GeneratedRoleFreeMeshError(
                        "generated role-free execution supports canonical Box, "
                        "Frame and RectangularUnderfillFillet roots"
                    )
                local_fragment_key = GeneratedLocalFragmentKey(
                    geometry.instance_id,
                    fragment.fragment_id,
                )
                global_fragment_id = _global_identifier(
                    "fragment",
                    geometry.instance_id,
                    fragment.fragment_id,
                )
                if (
                    local_fragment_key in local_fragments
                    or global_fragment_id in global_fragments
                ):
                    raise GeneratedRoleFreeMeshError(
                        "generated fragment identities are not unique"
                    )
                global_fragment = CanonicalGeometryFragment(
                    global_fragment_id,
                    fragment.root,
                    fragment.placement,
                )
                local_fragments[local_fragment_key] = fragment
                global_fragments[global_fragment_id] = global_fragment
                global_fragment_id_by_local[
                    local_fragment_key
                ] = global_fragment_id
                global_component_fragments.append(global_fragment)
                analytic_values.append(_fragment_analytic_volume_mm3(fragment))
            global_component = CanonicalComponentGeometry(
                global_component_id,
                component.material_name,
                tuple(global_component_fragments),
            )
            local_components[local_component_key] = component
            global_components[global_component_id] = global_component
            global_component_id_by_local[
                local_component_key
            ] = global_component_id
            key_by_global_component_id[global_component_id] = key
            global_component_id_by_key[key] = global_component_id
            fragment_count_by_key[key] = len(component.fragments)
            analytic_volume_by_key[key] = math.fsum(analytic_values)

    if set(mesh_controls) != expected_keys:
        missing = sorted(expected_keys.difference(mesh_controls))
        extra = sorted(set(mesh_controls).difference(expected_keys))
        raise GeneratedRoleFreeMeshError(
            "mesh_controls must match generated Components exactly; "
            f"missing={missing!r}, extra={extra!r}"
        )

    global_requirements: dict[str, ComponentMeshRequirement] = {}
    controls: dict[str, GeneratedComponentMeshControl] = {}
    for key in sorted(expected_keys):
        control = mesh_controls[key]
        if type(control) is not GeneratedComponentMeshControl:
            raise GeneratedRoleFreeMeshError(
                f"mesh control for {key!r} must be GeneratedComponentMeshControl"
            )
        global_id = global_component_id_by_key[key]
        global_requirement = ComponentMeshRequirement(
            global_id,
            control.volume_topology.value,
            control.target_edge_mm,
            control.transition_distance_mm,
        )
        global_requirements[global_id] = global_requirement
        controls[global_id] = control

    ordered_components = tuple(
        global_components[component_id]
        for component_id in sorted(global_components)
    )
    try:
        adjacencies = extract_component_adjacencies(
            ordered_components,
            interface_namespace="generated/source",
            interface_geometry_tolerance_mm=tolerance,
        )
        policies = tuple(
            negotiate_component_interface(
                adjacency,
                global_requirements[adjacency.first_component_id],
                global_requirements[adjacency.second_component_id],
            )
            for adjacency in adjacencies
        )
        sweep_directions = resolve_package_frame_sweep_directions(
            global_components,
            controls,
        )
        continuity = plan_generated_interface_continuity(
            policies,
            global_requirements,
            interface_geometry_tolerance_mm=tolerance,
            sweep_direction_xyz_by_component=sweep_directions,
        )
        adjacency_execution = plan_component_adjacency_execution(
            global_components,
            global_requirements,
            adjacencies,
            policies,
            interface_geometry_tolerance_mm=tolerance,
        )
    except Exception as error:
        raise GeneratedRoleFreeMeshError(
            "generated-only common-face lowering failed from canonical geometry "
            f"and Component-local sizing: {error}"
        ) from error

    lowering = MixedSourceLowering(
        "generated-only-role-free",
        "generated-only-no-frozen-source",
        "generated-only-no-frozen-snapshot",
        {value.instance_id: value for value in values},
        local_components,
        global_components,
        global_component_id_by_local,
        local_fragments,
        global_fragments,
        global_fragment_id_by_local,
        controls,
        global_requirements,
        adjacencies,
        policies,
        continuity,
        {},
        interface_geometry_tolerance_mm=tolerance,
    )
    try:
        ordering = plan_mesh_ordering(
            global_components,
            controls,
            global_requirements,
            adjacency_execution,
            continuity,
            {},
            {},
        )
    except Exception as error:
        raise GeneratedRoleFreeMeshError(
            f"generated-only mesh-priority preflight failed: {error}"
        ) from error
    return (
        MixedExecutionContext(
            lowering,
            adjacency_execution,
            MappingProxyType({}),
            ordering,
            tolerance,
        ),
        MappingProxyType(key_by_global_component_id),
        MappingProxyType(global_component_id_by_key),
        MappingProxyType(fragment_count_by_key),
        MappingProxyType(analytic_volume_by_key),
    )


def execute_generated_role_free_mesh(
    geometries: Sequence[CanonicalGeneratedGeometry],
    mesh_controls: Mapping[GeneratedComponentKey, GeneratedComponentMeshControl],
    output_path: str | Path,
    *,
    minimum_quality: float = 0.03,
    maximum_element_count: int = 2_000_000,
    interface_geometry_tolerance_mm: float = (
        DEFAULT_INTERFACE_GEOMETRY_TOLERANCE_MM
    ),
    verbose: bool = False,
) -> GeneratedRoleFreeMeshRun:
    """Materialize, assemble, write and reopen one generated-only structure."""

    (
        context,
        key_by_global_component_id,
        global_component_id_by_key,
        fragment_count_by_key,
        analytic_volume_by_key,
    ) = _build_context(
        geometries,
        mesh_controls,
        interface_geometry_tolerance_mm,
    )
    try:
        execution = execute_role_free_mixed_source(context, verbose=verbose)
    except Exception as error:
        raise GeneratedRoleFreeMeshError(
            f"generated-only role-free execution failed: {error}"
        ) from error
    if not execution.complete:
        rendered = "; ".join(
            f"{value.component_id}:{value.kind}:{value.detail}"
            for value in execution.pending_dependencies
        )
        raise GeneratedRoleFreeMeshError(
            "generated-only role-free execution has unresolved dependencies: "
            + rendered
        )
    element_count = sum(
        len(fragment.elements) for fragment in execution.component_fragments
    )
    if element_count > maximum_element_count:
        raise GeneratedRoleFreeMeshError(
            "generated-only role-free execution exceeds maximum_element_count"
        )
    try:
        write_result = write_mixed_volume_mesh(
            output_path,
            execution.component_fragments,
            frozen_mesh=None,
            declared_seams=execution.declared_seams,
            expected_complete_support_plane_interfaces=(
                execution.expected_complete_support_plane_interfaces
            ),
            interface_geometry_tolerance_mm=(
                execution.interface_geometry_tolerance_mm
            ),
            verbose=verbose,
        )
        reopen_audit = audit_reopened_mixed_volume_mesh(
            output_path,
            write_result.plan,
            context.lowering.component_mesh_requirements,
            minimum_quality=minimum_quality,
            verbose=verbose,
        )
    except Exception as error:
        raise GeneratedRoleFreeMeshError(
            f"generated-only mixed MSH publication or reopen audit failed: {error}"
        ) from error
    return GeneratedRoleFreeMeshRun(
        context,
        execution,
        write_result,
        reopen_audit,
        key_by_global_component_id,
        global_component_id_by_key,
        fragment_count_by_key,
        analytic_volume_by_key,
    )


__all__ = [
    "GeneratedRoleFreeMeshError",
    "GeneratedRoleFreeMeshRun",
    "execute_generated_role_free_mesh",
]
