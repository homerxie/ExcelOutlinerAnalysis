"""Non-authoritative quality observations and presentation of saved evidence.

Missing historical metrics remain missing; an observation is never acceptance.
This module does not change the mesh, quality floor or report-ready checks.
"""
from __future__ import annotations

import math
import re

METRICS = ("minDetJac", "minSJ", "minSICN", "minSIGE")
QUALITY_PROGRESS_PREFIX = "质量数据："
_REPORT_NAMES = ("minimum_jacobian_determinant", "minimum_scaled_jacobian", "minimum_sicn", "minimum_sige")


def component_quality_observation(component):
    """Measure returned connectivity without altering it or claiming final acceptance."""
    from collections import defaultdict
    from .gmsh_runtime import isolated_gmsh_model
    from .occ_locked_hybrid import _load_gmsh
    gmsh = _load_gmsh()
    minima = {}
    for fragment in component.fragments_by_id.values():
        with isolated_gmsh_model(gmsh, "__easymesh_component_quality_observation",
                                 number_options={"General.Terminal": 0.}):
            entity = gmsh.model.addDiscreteEntity(3)
            gmsh.model.mesh.addNodes(3, entity,
                [node.local_node_id for node in fragment.nodes],
                [v for node in fragment.nodes for v in node.coordinates_mm])
            groups = defaultdict(list)
            for element in fragment.elements:
                groups[element.gmsh_type].append(element)
            for kind, elements in groups.items():
                gmsh.model.mesh.addElementsByType(entity, kind,
                    [element.local_element_id for element in elements],
                    [node for element in elements for node in element.node_ids])
            tags = [element.local_element_id for element in fragment.elements]
            for metric in METRICS:
                values = gmsh.model.mesh.getElementQualities(tags, metric)
                if len(values) and all(math.isfinite(v) for v in values):
                    minima[metric] = min(minima.get(metric, math.inf), float(min(values)))
    return minima


def emit_quality_snapshot(candidate, iteration, *, phase="优化后"):
    from .gmsh_candidate_runtime import emit_candidate_event

    arrays = (candidate.determinants, candidate.scaled_jacobian, candidate.sicn, candidate.sige)
    values = {}
    for name, array in zip(METRICS, arrays):
        value = min(array) if array else None
        values[name] = value if value is not None and math.isfinite(value) else None
    emit_candidate_event({
        "stage": "quality_snapshot", "state": "measured", "iteration": iteration,
        "measurement_phase": phase, "metrics": values,
        "element_count": len(candidate.elements),
    })


def _key(label):
    return re.sub(r"^attempt=\d+/", "", str(label))


def _metrics_from_text(text):
    values = {}
    for metric in METRICS:
        found = re.search(r"(?<![A-Za-z])" + metric + r"=([+\-\d.eE]+)", text)
        if found:
            try:
                value = float(found[1])
                if math.isfinite(value):
                    values[metric] = value
            except ValueError:
                pass
    return values


def quality_rows_from_events(events):
    rows = []
    latest = {}
    labels = {}
    component_rows = {}
    for event in events:
        stage = str(event.get("stage", ""))
        if stage in {"component", "contact_validation"}:
            component = event.get("component_id", "未记录")
            row = component_rows.get(component)
            if row is None:
                row = {"component": component, "candidate": event.get("candidate", "组件生成"),
                       "iteration": "组件", "phase": "组件生成", "metrics": {},
                       "element_count": None, "status": "生成中", "detail": ""}
                rows.append(row)
                component_rows[component] = row
            if stage == "contact_validation":
                row.update(phase="接触面检查", status="接触边界未对齐，已中止",
                           detail=str(event.get("detail", "")))
                continue
            row.update(metrics=dict(event.get("metrics", {})), element_count=event.get("element_count"),
                       detail=str(event.get("detail", "")))
            row["status"] = {"completed": "生成完成，待整包审计", "failed": "组件生成失败"}.get(event.get("state"), "生成中")
            continue
        label = str(event.get("candidate", ""))
        if not label and stage.endswith("/audit"):
            label = stage[:-6]
        key = (event.get("component_id"), _key(label))
        state = event.get("state")
        # Older audit events omitted the component. Match them only when the
        # candidate label identifies exactly one observed component.
        if key[0] is None and stage != "quality_snapshot" and state != "started":
            matches = [existing for existing in latest if existing[1] == key[1]]
            if len(matches) == 1:
                key = matches[0]
        if stage == "candidate" and state == "started":
            labels[key] = label
            # Old reports reuse labels after changing adapter variants.
            latest.pop(key, None)
        if (stage == "quality_snapshot" and state not in ("failed", "timeout")) or (stage == "candidate" and state == "completed" and key not in latest):
            metric_values = event.get("metrics", {})
            row = {
                "component": event.get("component_id", "未记录"),
                "candidate": labels.get(key, label),
                "iteration": event.get("iteration", "候选结束"),
                "phase": event.get("measurement_phase", "历史候选"),
                "metrics": dict(metric_values) if isinstance(metric_values, dict) else {},
                "element_count": event.get("element_count"),
                "status": "观测值，尚未验收", "detail": "",
            }
            rows.append(row)
            latest[key] = row
        audit = stage.endswith("/audit") or stage == "candidate_audit"
        if audit or stage == "candidate_selection":
            if state == "failed" and key not in latest:
                row = {"component": event.get("component_id", "未记录"), "candidate": label,
                       "iteration": "未完成", "phase": "候选审计", "metrics": {},
                       "element_count": None, "status": "审计失败", "detail": ""}
                rows.append(row)
                latest[key] = row
            if state in ("failed", "completed", "accepted") and key in latest:
                row = latest[key]
                detail = str(event.get("detail", ""))
                row["detail"] = detail
                if not row["metrics"]:
                    row["metrics"] = _metrics_from_text(detail)
                row["status"] = "审计失败" if state == "failed" else "候选审计通过" if stage != "candidate_selection" else "选中"
        if state in ("timeout", "failed") and not audit and key[1]:
            if key in latest:
                latest[key]["status"] = "超时/中止" if state == "timeout" else "失败/取消"
                latest[key]["detail"] = str(event.get("detail", ""))
            elif stage == "candidate" or event.get("candidate"):
                rows.append({"component": event.get("component_id", "未记录"), "candidate": label,
                             "iteration": "未完成", "phase": stage, "metrics": {},
                             "element_count": None, "status": "失败/超时", "detail": str(event.get("detail", ""))})
    return rows


def quality_rows_from_report(report):
    execution = report.get("execution", {})
    rows = quality_rows_from_events(execution.get("candidate_execution_events", []))
    components = execution.get("components", {})
    if isinstance(components, list):
        # Generated-only reports use a list and only persist component SICN.
        for item in components:
            exempt = item.get("orthogonal_sicn_aspect_ratio_exempted") or item.get("orthogonal_hex_continuation_sicn_aspect_ratio_exempted")
            rows.append({"component": f"{item.get('instance_id', '')}/{item.get('component_id', '')}",
                         "candidate": "最终重开", "iteration": "最终", "phase": "组件最终网格",
                         "metrics": {"minSICN": item.get("minimum_sicn")},
                         "element_count": item.get("element_count"),
                         "status": "通过（Orth 长宽比豁免）" if exempt else "报告观测值", "detail": ""})
        quality = execution.get("quality", {})
        if quality:
            names = ("minimum_determinant", *_REPORT_NAMES[1:])
            rows.append({"component": "整包", "candidate": "最终重开", "iteration": "最终", "phase": "全部单元",
                         "metrics": {m: quality.get(n) for m, n in zip(METRICS, names)},
                         "element_count": execution.get("element_count"),
                         "status": "通过（按策略审计）" if quality.get("strategy_aware_floor_met") else "未证明通过",
                         "detail": ""})
        return rows
    for component, item in components.items():
        # Older adapter diagnostics only stored their metrics in text.
        for evidence in item.get("backend_evidence_by_fragment_id", {}).values():
            for index, attempt in enumerate(evidence.get("candidate_attempts", []), 1):
                if "stage=adapter,failed=" in attempt:
                    transition = attempt.split("transition=(", 1)[1] if "transition=(" in attempt else ""
                    rows.append({"component": component, "candidate": f"过渡层候选 {index}",
                                 "iteration": "历史候选", "phase": "过渡层", "metrics": _metrics_from_text(transition),
                                 "status": "审计失败", "detail": attempt, "element_count": None})
    audited = execution.get("reopened_audit", {})
    if audited.get("strategy_aware_quality_floor_met"):
        for row in rows:
            if (row["iteration"] == "组件" and row["status"] == "生成完成，待整包审计"
                    and row["component"] in audited.get("component_quality", {})):
                row["status"] = "生成完成；最终审计通过"
    for component, quality in audited.get("component_quality", {}).items():
        exempt = component in audited.get("orthogonal_sicn_aspect_ratio_exemptions", {})
        rows.append({"component": component, "candidate": "最终重开", "iteration": "最终", "phase": "组件最终网格",
                     "metrics": {m: quality.get(n) for m, n in zip(METRICS, _REPORT_NAMES)},
                     "element_count": sum(components.get(component, {}).get("final_element_kind_counts", {}).values()) or None,
                     "status": "通过（Orth 长宽比豁免）" if exempt else "已验收", "detail": ""})
    if audited:
        rows.append({"component": "整包", "candidate": "最终重开", "iteration": "最终", "phase": "全部单元",
                     "metrics": {m: audited.get(n) for m, n in zip(METRICS, _REPORT_NAMES)},
                     "element_count": audited.get("element_count"),
                     "status": "通过（按策略审计）" if audited.get("strategy_aware_quality_floor_met") else "未证明通过",
                     "detail": "全局最低 SICN 可能来自已证明正交的长条 HEX，不能据此放宽 Hybrid 门槛。"})
    return rows
