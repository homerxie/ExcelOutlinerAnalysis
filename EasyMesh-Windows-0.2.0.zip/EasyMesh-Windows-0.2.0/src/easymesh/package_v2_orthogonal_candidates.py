"""Compact, lossless candidate HEX partitions, independent of cell ownership.

Cells outside the current component remain available in this pool while other
components are generated. A future complementary component can classify these
same boxes against its own geometry and reuse their exact interface partition.
Only assigned volume cells enter the final MSH; the pool survives in the report.
"""

from dataclasses import dataclass
import math
from typing import Iterator


def orthogonal_execution_metadata(result, write_result):
    """Use final MSH element IDs in diagnostics for both worker routes."""
    numbered = {
        (e.source_fragment_key, e.source_local_element_id): e.output_tag
        for e in write_result.plan.elements
    }
    warnings = []
    grids = {}
    for component_id, component in sorted(result.components_by_id.items()):
        for fragment_id, grid in component.orthogonal_candidate_grids.items():
            grids[fragment_id] = {**grid.to_dict(), "component_id": component_id}
        for fragment_id, evidence in component.backend_evidence_by_fragment_id.items():
            warnings.extend({**warning, "component_id": component_id, "fragment_id": fragment_id}
                            for warning in evidence.get("strategy_warnings", ()))
            def locate(value):
                if isinstance(value, dict):
                    record = {key: locate(item) for key, item in value.items()}
                    if "element_id" in record:
                        record["local_element_id"] = record["element_id"]
                        record["element_id"] = numbered[(fragment_id, record["element_id"])]
                    return record
                if isinstance(value, (tuple, list)):
                    return [locate(item) for item in value]
                return value
            for warning in evidence.get("mesh_warnings", ()):
                local_ids = warning.get("element_ids", ())
                warnings.append({
                    **locate(warning), "component_id": component_id,
                    "element_set_name": "ORTH_MESH_WARNINGS",
                    "local_element_ids": list(local_ids),
                    "element_ids": [numbered[(fragment_id, i)] for i in local_ids],
                })
    return {"mesh_warnings": warnings, "orthogonal_candidate_grids": grids}


@dataclass(frozen=True, slots=True)
class OrthogonalCandidateGrid:
    fragment_id: str
    xy_cells_mm: tuple[tuple[tuple[float, float], tuple[float, float]], ...]
    z_levels_mm: tuple[float, ...]
    assigned_xy_indices_by_layer: tuple[tuple[int, ...], ...]
    translation_xyz_mm: tuple[float, float, float]
    rotation_deg_xyz: tuple[float, float, float]
    pivot_xyz_mm: tuple[float, float, float]

    def __post_init__(self):
        xy = tuple(tuple(tuple(float(v) for v in axis) for axis in cell) for cell in self.xy_cells_mm)
        z = tuple(float(v) for v in self.z_levels_mm)
        assigned = tuple(tuple(layer) for layer in self.assigned_xy_indices_by_layer)
        if not self.fragment_id or not xy or len(set(xy)) != len(xy):
            raise ValueError("candidate grid needs an identity and unique XY cells")
        if any(len(cell) != 2 or any(len(axis) != 2 or not all(map(math.isfinite, axis)) or axis[0] >= axis[1] for axis in cell) for cell in xy):
            raise ValueError("candidate XY bounds must be finite positive rectangles")
        if len(z) < 2 or not all(map(math.isfinite, z)) or any(a >= b for a, b in zip(z, z[1:])):
            raise ValueError("candidate Z levels must be finite and increasing")
        if len(assigned) != len(z) - 1 or any(
            len(set(layer)) != len(layer) or any(type(i) is not int or not 0 <= i < len(xy) for i in layer)
            for layer in assigned
        ):
            raise ValueError("candidate assignment indices do not match the partition")
        object.__setattr__(self, "xy_cells_mm", xy)
        object.__setattr__(self, "z_levels_mm", z)
        object.__setattr__(self, "assigned_xy_indices_by_layer", tuple(tuple(sorted(layer)) for layer in assigned))
        for name in ("translation_xyz_mm", "rotation_deg_xyz", "pivot_xyz_mm"):
            values = tuple(float(v) for v in getattr(self, name))
            if len(values) != 3 or not all(map(math.isfinite, values)):
                raise ValueError("candidate placement must have three finite coordinates")
            object.__setattr__(self, name, values)

    @classmethod
    def from_dict(cls, value):
        """Reload the complete candidate pool saved in a worker report."""
        if value.get("schema") == "easymesh-orthogonal-block-candidates-v1":
            return OrthogonalBlockCandidates.from_dict(value)
        if value.get("schema") != "easymesh-orthogonal-candidate-grid-v1" or value.get("coordinate_frame") != "component_local_mm":
            raise ValueError("unsupported candidate grid schema or coordinate frame")
        return cls(value["fragment_id"], value["xy_cells_mm"], value["z_levels_mm"],
                   value["assigned_xy_indices_by_layer"], **value["placement"])

    @classmethod
    def from_mesh(cls, fragment, mesh):
        xy = mesh.candidate_xy_cells_mm
        index_by_xy = {bounds: index for index, bounds in enumerate(xy)}
        z = mesh.audit.z_levels_mm
        index_by_z = {round(value, 12): index for index, value in enumerate(z[:-1])}
        assigned = [set() for _ in z[:-1]]
        for cell in mesh.elements:
            bounds = cell.bounds_xyz_mm
            assigned[index_by_z[round(bounds[2][0], 12)]].add(index_by_xy[bounds[:2]])
        placement = fragment.placement
        return cls(fragment.fragment_id, xy, z, tuple(tuple(sorted(layer)) for layer in assigned),
                   placement.translation_xyz_mm, placement.rotation_deg_xyz, placement.pivot_xyz_mm)

    @property
    def candidate_cell_count(self):
        return len(self.xy_cells_mm) * (len(self.z_levels_mm) - 1)

    @property
    def assigned_cell_count(self):
        return sum(map(len, self.assigned_xy_indices_by_layer))

    def cells(self, *, unassigned_only=False) -> Iterator[tuple]:
        """Yield stable (XY index, Z index), local bounds, and assignment flag."""
        for k, (lower, upper) in enumerate(zip(self.z_levels_mm, self.z_levels_mm[1:])):
            assigned = set(self.assigned_xy_indices_by_layer[k])
            for i, xy in enumerate(self.xy_cells_mm):
                owned = i in assigned
                if not unassigned_only or not owned:
                    yield (i, k), (*xy, (lower, upper)), owned

    def to_dict(self):
        return {
            "schema": "easymesh-orthogonal-candidate-grid-v1",
            "fragment_id": self.fragment_id,
            "coordinate_frame": "component_local_mm",
            "cell_key": "[xy_cell_index, z_layer_index] (zero based)",
            "xy_cells_mm": self.xy_cells_mm,
            "z_levels_mm": self.z_levels_mm,
            "assigned_xy_indices_by_layer": self.assigned_xy_indices_by_layer,
            "candidate_cell_count": self.candidate_cell_count,
            "assigned_cell_count": self.assigned_cell_count,
            "unassigned_cell_count": self.candidate_cell_count - self.assigned_cell_count,
            "unassigned_policy": "available_for_complementary_geometry; excluded_from_final_volume_unless_assigned",
            "placement": {
                "translation_xyz_mm": self.translation_xyz_mm,
                "rotation_deg_xyz": self.rotation_deg_xyz,
                "pivot_xyz_mm": self.pivot_xyz_mm,
            },
        }


@dataclass(frozen=True)
class OrthogonalBlockCandidates:
    """General three-axis local partitions, without a global Z-layer assumption."""

    fragment_id: str
    bounds_package_mm: tuple
    assigned_indices: tuple

    def __post_init__(self):
        bounds = tuple(
            tuple(tuple(float(v) for v in span) for span in box)
            for box in self.bounds_package_mm
        )
        assigned = tuple(self.assigned_indices)
        if (
            not self.fragment_id
            or not bounds
            or len(set(bounds)) != len(bounds)
            or any(
                len(box) != 3
                or any(
                    len(span) != 2
                    or not all(map(math.isfinite, span))
                    or span[0] >= span[1]
                    for span in box
                )
                for box in bounds
            )
            or len(set(assigned)) != len(assigned)
            or any(type(i) is not int or not 0 <= i < len(bounds) for i in assigned)
        ):
            raise ValueError("invalid orthogonal block candidate pool")
        object.__setattr__(self, "bounds_package_mm", bounds)
        object.__setattr__(self, "assigned_indices", tuple(sorted(assigned)))

    @property
    def candidate_cell_count(self):
        return len(self.bounds_package_mm)

    @property
    def assigned_cell_count(self):
        return len(self.assigned_indices)

    def cells(self, *, unassigned_only=False):
        assigned = set(self.assigned_indices)
        for i, bounds in enumerate(self.bounds_package_mm):
            if not unassigned_only or i not in assigned:
                yield i, bounds, i in assigned

    def to_dict(self):
        return {
            "schema": "easymesh-orthogonal-block-candidates-v1",
            "fragment_id": self.fragment_id,
            "coordinate_frame": "package_mm",
            "bounds_package_mm": self.bounds_package_mm,
            "assigned_indices": self.assigned_indices,
            "candidate_cell_count": self.candidate_cell_count,
            "assigned_cell_count": self.assigned_cell_count,
            "unassigned_cell_count": self.candidate_cell_count
            - self.assigned_cell_count,
        }

    @classmethod
    def from_dict(cls, value):
        if (
            value.get("schema") != "easymesh-orthogonal-block-candidates-v1"
            or value.get("coordinate_frame") != "package_mm"
        ):
            raise ValueError(
                "unsupported orthogonal block candidate schema or coordinate frame"
            )
        return cls(
            value["fragment_id"], value["bounds_package_mm"], value["assigned_indices"]
        )
